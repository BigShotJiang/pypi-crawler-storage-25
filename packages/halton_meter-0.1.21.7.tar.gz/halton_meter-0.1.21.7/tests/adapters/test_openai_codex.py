"""
Unit tests for OpenAICodexAdapter (sibling of OpenAIAdapter).

Fixtures under tests/fixtures/openai_codex/ are SYNTHETIC — see
the README in that directory. They were hand-constructed for the dev3
landing because the user's @openai/codex session that triggered the
investigation pre-dates the adapter and produced no captured bodies.
Real-traffic confirmation is expected in dev4 once the dev3 wheel is
deployed.
"""

from __future__ import annotations

import json
from pathlib import Path

from mitmproxy import http
from mitmproxy.test import tflow, tutils

from halton_meter.adapters.base import ProviderAdapter
from halton_meter.adapters.openai_codex import (
    _FALLBACK_MODEL,
    OpenAICodexAdapter,
)
from halton_meter.proxy import ADAPTER_REGISTRY

FIXTURES = Path(__file__).parent.parent / "fixtures" / "openai_codex"

CODEX_HOST = "chatgpt.com"


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_flow(
    path: str,
    request_body: dict | bytes | None = None,
    response_body: str | bytes | None = None,
    content_type: str = "application/json",
) -> http.HTTPFlow:
    if isinstance(request_body, dict):
        req_content = json.dumps(request_body).encode()
    elif isinstance(request_body, (bytes, bytearray)):
        req_content = bytes(request_body)
    else:
        req_content = b""

    req = tutils.treq(host=CODEX_HOST, port=443, path=path)
    req.content = req_content

    flow = tflow.tflow(req=req)

    if response_body is not None:
        if isinstance(response_body, str):
            resp_bytes = response_body.encode()
        else:
            resp_bytes = response_body
        flow.response = tutils.tresp(content=resp_bytes)
        flow.response.headers["content-type"] = content_type

    return flow


def _read_fixture(name: str) -> str:
    return (FIXTURES / name).read_text(encoding="utf-8")


# ---------------------------------------------------------------------------
# Protocol / registry
# ---------------------------------------------------------------------------


def test_adapter_satisfies_provider_protocol():
    adapter = OpenAICodexAdapter()
    assert isinstance(adapter, ProviderAdapter)
    assert adapter.name == "openai"
    assert adapter.domains == [CODEX_HOST]


def test_adapter_registered_in_registry():
    """Verify the sibling adapter is wired into the proxy dispatch list."""
    instances = [a for a in ADAPTER_REGISTRY if isinstance(a, OpenAICodexAdapter)]
    assert len(instances) == 1, (
        "OpenAICodexAdapter should appear exactly once in ADAPTER_REGISTRY"
    )


# ---------------------------------------------------------------------------
# matches() / matches_url()
# ---------------------------------------------------------------------------


def test_matches_exact_host_and_port_suffix():
    a = OpenAICodexAdapter()
    assert a.matches(CODEX_HOST)
    assert a.matches(f"{CODEX_HOST}:443")


def test_matches_rejects_subdomain_lookalikes():
    a = OpenAICodexAdapter()
    assert not a.matches("evil.chatgpt.com")
    assert not a.matches("chatgpt.com.evil.com")
    # Public OpenAI host belongs to the sibling adapter, not this one.
    assert not a.matches("api.openai.com")


def test_matches_url_accepts_only_billable_codex_paths():
    """Dev4 narrowing: only ``/backend-api/codex/responses`` is metered.

    Catalogue and telemetry sub-paths produce no recoverable usage and
    were polluting cost aggregations in dev3 — explicitly rejected now.
    """
    a = OpenAICodexAdapter()
    assert a.matches_url(CODEX_HOST, "/backend-api/codex/responses")
    # With a query string.
    assert a.matches_url(CODEX_HOST, "/backend-api/codex/responses?x=1")


def test_matches_url_rejects_codex_noise_paths():
    """Dev4 regression: noise paths observed in the dev3 daemon log.

    ``/codex/models`` is the SKU catalogue (GET, no usage),
    ``/codex/analytics-events/events`` is telemetry (POST, no usage),
    and both arrive with ``model=codex-unknown`` because the request
    body has no ``"model"`` field — they need to be dropped at adapter
    dispatch, not metered at $0.
    """
    a = OpenAICodexAdapter()
    for path in (
        "/backend-api/codex/models",
        "/backend-api/codex/models?client_version=0.128.0",
        "/backend-api/codex/analytics-events/events",
        "/backend-api/codex/something-else",
    ):
        assert not a.matches_url(CODEX_HOST, path), path


def test_matches_url_rejects_non_codex_paths_on_same_host():
    """The classic ChatGPT site (/api/conversation, /backend-api/conversation,
    etc.) lives on chatgpt.com but is NOT under /backend-api/codex/.
    Rejecting those keeps the DB free of non-billable rows."""
    a = OpenAICodexAdapter()
    for path in (
        "/api/conversation",
        "/backend-api/conversation",
        "/backend-api/accounts",
        "/",
        "/some/other/path",
    ):
        assert not a.matches_url(CODEX_HOST, path), path


def test_matches_url_rejects_wrong_host():
    a = OpenAICodexAdapter()
    assert not a.matches_url("api.openai.com", "/backend-api/codex/responses")


# ---------------------------------------------------------------------------
# parse_request — model extraction + stream flag
# ---------------------------------------------------------------------------


def test_parse_request_extracts_model_from_top_level():
    a = OpenAICodexAdapter()
    body = json.loads(_read_fixture("request_body_with_model.json"))
    flow = _make_flow(
        "/backend-api/codex/responses",
        request_body=body,
    )
    meta = a.parse_request(flow)
    assert meta.provider == "openai"
    assert meta.model == "gpt-5.3-codex"
    assert meta.stream is False


def test_parse_request_falls_back_when_model_missing():
    a = OpenAICodexAdapter()
    body = json.loads(_read_fixture("request_body_no_model.json"))
    flow = _make_flow(
        "/backend-api/codex/responses",
        request_body=body,
    )
    meta = a.parse_request(flow)
    assert meta.model == _FALLBACK_MODEL


def test_parse_request_stream_flag_from_body():
    a = OpenAICodexAdapter()
    flow = _make_flow(
        "/backend-api/codex/responses",
        request_body={"model": "gpt-5.3-codex", "stream": True},
    )
    meta = a.parse_request(flow)
    assert meta.stream is True


def test_parse_request_handles_non_json_body():
    """Must not raise on garbage; falls back to the placeholder model."""
    a = OpenAICodexAdapter()
    flow = _make_flow(
        "/backend-api/codex/responses",
        request_body=b"not-json",
    )
    meta = a.parse_request(flow)
    assert meta.model == _FALLBACK_MODEL
    assert meta.stream is False


# ---------------------------------------------------------------------------
# parse_response — non-streaming
# ---------------------------------------------------------------------------


def test_parse_response_basic_top_level_usage():
    a = OpenAICodexAdapter()
    flow = _make_flow(
        "/backend-api/codex/responses",
        request_body={"model": "gpt-5.3-codex"},
        response_body=_read_fixture("responses_basic.json"),
    )
    req_meta = a.parse_request(flow)
    resp = a.parse_response(flow, req_meta)
    assert resp.input_tokens == 1234
    assert resp.output_tokens == 56
    assert resp.thinking_tokens == 12
    assert resp.cache_read_tokens == 100
    assert resp.tokens_complete is True


def test_parse_response_wrapped_response_shape():
    """Some Codex backend builds may wrap the response under a top-level
    ``response`` key — the adapter must accept both shapes."""
    a = OpenAICodexAdapter()
    flow = _make_flow(
        "/backend-api/codex/responses",
        request_body={"model": "gpt-5.3-codex"},
        response_body=_read_fixture("responses_wrapped.json"),
    )
    req_meta = a.parse_request(flow)
    resp = a.parse_response(flow, req_meta)
    assert resp.input_tokens == 200
    assert resp.output_tokens == 40
    assert resp.thinking_tokens == 5
    assert resp.cache_read_tokens == 60
    assert resp.tokens_complete is True


def test_parse_response_no_usage_marks_incomplete():
    a = OpenAICodexAdapter()
    flow = _make_flow(
        "/backend-api/codex/responses",
        request_body={"model": "gpt-5.3-codex"},
        response_body=json.dumps({"id": "resp_x", "output": []}),
    )
    req_meta = a.parse_request(flow)
    resp = a.parse_response(flow, req_meta)
    assert resp.tokens_complete is False
    assert resp.input_tokens == 0
    assert resp.output_tokens == 0


# ---------------------------------------------------------------------------
# parse_response — streaming SSE
# ---------------------------------------------------------------------------


def test_parse_response_sse_extracts_usage_from_response_completed():
    a = OpenAICodexAdapter()
    flow = _make_flow(
        "/backend-api/codex/responses",
        request_body={"model": "gpt-5.3-codex", "stream": True},
        response_body=_read_fixture("stream_responses.txt"),
        content_type="text/event-stream",
    )
    req_meta = a.parse_request(flow)
    assert req_meta.stream is True
    resp = a.parse_response(flow, req_meta)
    assert resp.input_tokens == 500
    assert resp.output_tokens == 80
    assert resp.thinking_tokens == 16
    assert resp.cache_read_tokens == 64
    assert resp.tokens_complete is True


def test_parse_response_sse_no_usage_marks_incomplete():
    """Truncated stream / client-closed-early — no chunk carries usage."""
    a = OpenAICodexAdapter()
    flow = _make_flow(
        "/backend-api/codex/responses",
        request_body={"model": "gpt-5.3-codex", "stream": True},
        response_body=_read_fixture("stream_responses_no_usage.txt"),
        content_type="text/event-stream",
    )
    req_meta = a.parse_request(flow)
    resp = a.parse_response(flow, req_meta)
    assert resp.tokens_complete is False
    assert resp.input_tokens == 0
    assert resp.output_tokens == 0


# ---------------------------------------------------------------------------
# Defensive: parse_response must never raise
# ---------------------------------------------------------------------------


def test_parse_response_never_raises_on_garbage_body():
    a = OpenAICodexAdapter()
    flow = _make_flow(
        "/backend-api/codex/responses",
        request_body={"model": "gpt-5.3-codex"},
        response_body=b"\x00\x01garbage-not-json",
    )
    req_meta = a.parse_request(flow)
    resp = a.parse_response(flow, req_meta)
    assert resp.tokens_complete is False
