"""
Unit tests for GeminiCodeAssistAdapter (sibling of GeminiAdapter).

Fixtures under tests/fixtures/gemini_code_assist/ are SYNTHETIC — see
the README in that directory. They were hand-constructed for the dev2
landing because the user's gemini-cli session that triggered the
investigation pre-dates the adapter and produced no captured bodies.
Real-traffic confirmation is expected in dev3 once the dev2 wheel is
deployed.
"""

from __future__ import annotations

import json
from pathlib import Path

from mitmproxy import http
from mitmproxy.test import tflow, tutils

from halton_meter.adapters.base import ProviderAdapter
from halton_meter.adapters.gemini_code_assist import (
    _FALLBACK_MODEL,
    GeminiCodeAssistAdapter,
)
from halton_meter.proxy import ADAPTER_REGISTRY

FIXTURES = Path(__file__).parent.parent / "fixtures" / "gemini_code_assist"

CODE_ASSIST_HOST = "cloudcode-pa.googleapis.com"


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_flow(
    path: str,
    request_body: dict | bytes | None = None,
    response_body: str | bytes | None = None,
    content_type: str = "application/json",
) -> http.HTTPFlow:
    if isinstance(request_body, dict):
        req_content = json.dumps(request_body).encode()
    elif isinstance(request_body, (bytes, bytearray)):
        req_content = bytes(request_body)
    else:
        req_content = b""

    req = tutils.treq(host=CODE_ASSIST_HOST, port=443, path=path)
    req.content = req_content

    flow = tflow.tflow(req=req)

    if response_body is not None:
        if isinstance(response_body, str):
            resp_bytes = response_body.encode()
        else:
            resp_bytes = response_body
        flow.response = tutils.tresp(content=resp_bytes)
        flow.response.headers["content-type"] = content_type

    return flow


def _read_fixture(name: str) -> str:
    return (FIXTURES / name).read_text(encoding="utf-8")


# ---------------------------------------------------------------------------
# Protocol / registry
# ---------------------------------------------------------------------------


def test_adapter_satisfies_provider_protocol():
    adapter = GeminiCodeAssistAdapter()
    assert isinstance(adapter, ProviderAdapter)
    assert adapter.name == "gemini"
    assert adapter.domains == [CODE_ASSIST_HOST]


def test_adapter_registered_in_registry():
    """Verify the sibling adapter is wired into the proxy dispatch list."""
    instances = [a for a in ADAPTER_REGISTRY if isinstance(a, GeminiCodeAssistAdapter)]
    assert len(instances) == 1, (
        "GeminiCodeAssistAdapter should appear exactly once in ADAPTER_REGISTRY"
    )


# ---------------------------------------------------------------------------
# matches() / matches_url()
# ---------------------------------------------------------------------------


def test_matches_exact_host_and_port_suffix():
    a = GeminiCodeAssistAdapter()
    assert a.matches(CODE_ASSIST_HOST)
    assert a.matches(f"{CODE_ASSIST_HOST}:443")


def test_matches_rejects_subdomain_lookalikes():
    a = GeminiCodeAssistAdapter()
    # Substring-style spoofs must not match.
    assert not a.matches("evil.cloudcode-pa.googleapis.com")
    assert not a.matches("cloudcode-pa.googleapis.com.evil.com")
    # Public Gemini host belongs to the sibling adapter, not this one.
    assert not a.matches("generativelanguage.googleapis.com")


def test_matches_url_accepts_billable_paths():
    a = GeminiCodeAssistAdapter()
    assert a.matches_url(CODE_ASSIST_HOST, "/v1internal:generateContent")
    assert a.matches_url(CODE_ASSIST_HOST, "/v1internal:streamGenerateContent")
    assert a.matches_url(CODE_ASSIST_HOST, "/v1internal:streamGenerateContent?alt=sse")


def test_matches_url_rejects_control_plane_paths():
    """The control-plane endpoints observed in 2026-05-04 are free —
    rejecting them keeps the DB free of $0 rows for non-inference traffic."""
    a = GeminiCodeAssistAdapter()
    for path in (
        "/v1internal:loadCodeAssist",
        "/v1internal:retrieveUserQuota",
        "/v1internal:listExperiments",
        "/v1internal:fetchAdminControls",
        "/v1internal:countTokens",
    ):
        assert not a.matches_url(CODE_ASSIST_HOST, path), path


def test_matches_url_rejects_wrong_host():
    a = GeminiCodeAssistAdapter()
    assert not a.matches_url(
        "generativelanguage.googleapis.com", "/v1internal:generateContent"
    )


# ---------------------------------------------------------------------------
# parse_request — model extraction + stream flag
# ---------------------------------------------------------------------------


def test_parse_request_extracts_model_from_top_level():
    a = GeminiCodeAssistAdapter()
    body = json.loads(_read_fixture("request_body_with_model.json"))
    flow = _make_flow(
        "/v1internal:generateContent",
        request_body=body,
    )
    meta = a.parse_request(flow)
    assert meta.provider == "gemini"
    assert meta.model == "gemini-3-flash-preview"
    assert meta.stream is False


def test_parse_request_falls_back_when_model_missing():
    a = GeminiCodeAssistAdapter()
    body = json.loads(_read_fixture("request_body_no_model.json"))
    flow = _make_flow(
        "/v1internal:generateContent",
        request_body=body,
    )
    meta = a.parse_request(flow)
    assert meta.model == _FALLBACK_MODEL


def test_parse_request_stream_flag_from_path():
    a = GeminiCodeAssistAdapter()
    flow = _make_flow(
        "/v1internal:streamGenerateContent?alt=sse",
        request_body={"model": "gemini-3-flash-preview"},
    )
    meta = a.parse_request(flow)
    assert meta.stream is True


def test_parse_request_stream_flag_from_alt_sse_query_only():
    """If a future client uses generateContent with alt=sse, still treat as stream."""
    a = GeminiCodeAssistAdapter()
    flow = _make_flow(
        "/v1internal:generateContent?alt=sse",
        request_body={"model": "gemini-3-flash-preview"},
    )
    meta = a.parse_request(flow)
    assert meta.stream is True


def test_parse_request_handles_non_json_body():
    """Must not raise on garbage; falls back to the placeholder model."""
    a = GeminiCodeAssistAdapter()
    flow = _make_flow(
        "/v1internal:generateContent",
        request_body=b"not-json",
    )
    meta = a.parse_request(flow)
    assert meta.model == _FALLBACK_MODEL
    assert meta.stream is False


# ---------------------------------------------------------------------------
# parse_response — non-streaming
# ---------------------------------------------------------------------------


def test_parse_response_basic_top_level_usage():
    a = GeminiCodeAssistAdapter()
    flow = _make_flow(
        "/v1internal:generateContent",
        request_body={"model": "gemini-3-flash-preview"},
        response_body=_read_fixture("generate_content_basic.json"),
    )
    req_meta = a.parse_request(flow)
    resp = a.parse_response(flow, req_meta)
    assert resp.input_tokens == 21943
    assert resp.output_tokens == 92
    assert resp.thinking_tokens == 0
    assert resp.cache_read_tokens == 0
    assert resp.tokens_complete is True


def test_parse_response_wrapped_response_shape():
    """Some Code Assist client builds wrap the public-API response under
    a top-level ``response`` key — the adapter must accept both shapes."""
    a = GeminiCodeAssistAdapter()
    flow = _make_flow(
        "/v1internal:generateContent",
        request_body={"model": "gemini-3-flash-preview"},
        response_body=_read_fixture("generate_content_wrapped.json"),
    )
    req_meta = a.parse_request(flow)
    resp = a.parse_response(flow, req_meta)
    assert resp.input_tokens == 100
    assert resp.output_tokens == 50
    assert resp.thinking_tokens == 25
    assert resp.cache_read_tokens == 30
    assert resp.tokens_complete is True


def test_parse_response_no_usage_metadata_marks_incomplete():
    a = GeminiCodeAssistAdapter()
    flow = _make_flow(
        "/v1internal:generateContent",
        request_body={"model": "gemini-3-flash-preview"},
        response_body=json.dumps({"candidates": []}),
    )
    req_meta = a.parse_request(flow)
    resp = a.parse_response(flow, req_meta)
    assert resp.tokens_complete is False
    assert resp.input_tokens == 0
    assert resp.output_tokens == 0


# ---------------------------------------------------------------------------
# parse_response — streaming SSE
# ---------------------------------------------------------------------------


def test_parse_response_sse_extracts_usage_from_final_chunk():
    a = GeminiCodeAssistAdapter()
    flow = _make_flow(
        "/v1internal:streamGenerateContent?alt=sse",
        request_body={"model": "gemini-3-flash-preview"},
        response_body=_read_fixture("stream_generate_content.txt"),
        content_type="text/event-stream",
    )
    req_meta = a.parse_request(flow)
    assert req_meta.stream is True
    resp = a.parse_response(flow, req_meta)
    assert resp.input_tokens == 250
    assert resp.output_tokens == 12
    assert resp.tokens_complete is True


def test_parse_response_sse_no_usage_marks_incomplete():
    """Truncated stream / client-closed-early — no chunk carries usageMetadata."""
    a = GeminiCodeAssistAdapter()
    flow = _make_flow(
        "/v1internal:streamGenerateContent?alt=sse",
        request_body={"model": "gemini-3-flash-preview"},
        response_body=_read_fixture("stream_generate_content_no_usage.txt"),
        content_type="text/event-stream",
    )
    req_meta = a.parse_request(flow)
    resp = a.parse_response(flow, req_meta)
    assert resp.tokens_complete is False
    assert resp.input_tokens == 0
    assert resp.output_tokens == 0


# ---------------------------------------------------------------------------
# Defensive: parse_response must never raise
# ---------------------------------------------------------------------------


def test_parse_response_never_raises_on_garbage_body():
    a = GeminiCodeAssistAdapter()
    flow = _make_flow(
        "/v1internal:generateContent",
        request_body={"model": "gemini-3-flash-preview"},
        response_body=b"\x00\x01garbage-not-json",
    )
    req_meta = a.parse_request(flow)
    resp = a.parse_response(flow, req_meta)
    assert resp.tokens_complete is False
