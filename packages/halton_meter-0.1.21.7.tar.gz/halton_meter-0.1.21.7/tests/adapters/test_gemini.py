"""
Unit tests for GeminiAdapter.

All tests use recorded fixtures — no live network calls. Flows are constructed
with mitmproxy's tflow/tutils helpers, which produce fully typed HTTPFlow
objects without touching the network.

Fixture files in tests/fixtures/gemini/:
  generate_content_basic.json              — non-streaming with cachedContentTokenCount > 0
  generate_content_thinking.json           — Gemini 2.5 with thoughtsTokenCount populated
  stream_generate_content.txt              — well-formed JSON-array stream
  stream_generate_content_truncated.txt    — partial array (tokens_complete=False)
  embed_content.json                       — embeddings (totalTokenCount only)
  generate_content_high_context.json       — promptTokenCount > 200_000 (tiered rate)
  generate_content_multimodal.json         — promptTokensDetails with IMAGE modality
  generate_content_no_usage_metadata.json  — older API shape WITHOUT usageMetadata
"""

from __future__ import annotations

import json
import logging
import time
from pathlib import Path

from mitmproxy import http
from mitmproxy.test import tflow, tutils

from halton_meter.adapters.base import ProviderAdapter, RequestMetadata
from halton_meter.adapters.gemini import GeminiAdapter
from halton_meter.adapters.openai import OpenAIAdapter
from halton_meter.pricing import compute_cost_millicents
from halton_meter.pricing.matrix import GEMINI_TIERED_RATES
from halton_meter.proxy import ADAPTER_REGISTRY

FIXTURES = Path(__file__).parent.parent / "fixtures" / "gemini"

GEMINI_HOST = "generativelanguage.googleapis.com"


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_flow(
    path: str = "/v1beta/models/gemini-2.5-pro:generateContent",
    request_body: dict | None = None,
    response_body: str | bytes | None = None,
    content_type: str = "application/json",
) -> http.HTTPFlow:
    req_content = (
        json.dumps(request_body or {}).encode()
        if request_body is not None
        else b""
    )
    req = tutils.treq(host=GEMINI_HOST, port=443, path=path)
    req.content = req_content

    flow = tflow.tflow(req=req)

    if response_body is not None:
        body_bytes = (
            response_body.encode() if isinstance(response_body, str) else response_body
        )
        flow.response = http.Response.make(
            200,
            body_bytes,
            {"Content-Type": content_type},
        )

    return flow


def _make_request_meta(
    model: str = "gemini-2.5-pro", stream: bool = False
) -> RequestMetadata:
    return RequestMetadata(
        provider="gemini",
        model=model,
        stream=stream,
        started_at=time.monotonic() - 0.5,
    )


# ---------------------------------------------------------------------------
# matches() / matches_url()
# ---------------------------------------------------------------------------


class TestMatches:
    def test_matches_exact_host(self) -> None:
        assert GeminiAdapter().matches(GEMINI_HOST) is True

    def test_matches_host_with_port(self) -> None:
        assert GeminiAdapter().matches(f"{GEMINI_HOST}:443") is True

    def test_does_not_match_vertex_ai(self) -> None:
        # Vertex AI is intentionally NOT matched — separate adapter when it surfaces.
        assert GeminiAdapter().matches("aiplatform.googleapis.com") is False

    def test_rejects_trailing_suffix_injection(self) -> None:
        assert GeminiAdapter().matches(f"{GEMINI_HOST}.evil.com") is False

    def test_rejects_leading_subdomain_injection(self) -> None:
        assert GeminiAdapter().matches(f"evil.{GEMINI_HOST}") is False


class TestMatchesUrl:
    def test_accepts_v1beta_generate_content(self) -> None:
        assert (
            GeminiAdapter().matches_url(
                GEMINI_HOST, "/v1beta/models/gemini-2.5-pro:generateContent"
            )
            is True
        )

    def test_accepts_v1beta_stream_generate_content(self) -> None:
        assert (
            GeminiAdapter().matches_url(
                GEMINI_HOST, "/v1beta/models/gemini-2.5-pro:streamGenerateContent"
            )
            is True
        )

    def test_accepts_v1beta_embed_content(self) -> None:
        assert (
            GeminiAdapter().matches_url(
                GEMINI_HOST, "/v1beta/models/text-embedding-004:embedContent"
            )
            is True
        )

    def test_accepts_v1beta_batch_embed_contents(self) -> None:
        assert (
            GeminiAdapter().matches_url(
                GEMINI_HOST, "/v1beta/models/text-embedding-004:batchEmbedContents"
            )
            is True
        )

    def test_accepts_v1_path(self) -> None:
        # Future-stable v1 API path is also accepted.
        assert (
            GeminiAdapter().matches_url(
                GEMINI_HOST, "/v1/models/gemini-2.5-pro:generateContent"
            )
            is True
        )

    def test_rejects_unknown_action(self) -> None:
        assert (
            GeminiAdapter().matches_url(
                GEMINI_HOST, "/v1beta/models/gemini-2.5-pro:countTokens"
            )
            is False
        )

    def test_rejects_other_host(self) -> None:
        assert (
            GeminiAdapter().matches_url(
                "api.openai.com", "/v1beta/models/gemini-2.5-pro:generateContent"
            )
            is False
        )

    def test_rejects_non_models_path(self) -> None:
        assert GeminiAdapter().matches_url(GEMINI_HOST, "/v1beta/cachedContents") is False


# ---------------------------------------------------------------------------
# parse_request()
# ---------------------------------------------------------------------------


class TestParseRequest:
    def test_extracts_model_from_v1beta_path(self) -> None:
        flow = _make_flow(
            path="/v1beta/models/gemini-2.5-pro:generateContent",
            request_body={"contents": []},
        )
        meta = GeminiAdapter().parse_request(flow)
        assert meta.provider == "gemini"
        assert meta.model == "gemini-2.5-pro"
        assert meta.stream is False

    def test_extracts_model_from_v1_path(self) -> None:
        flow = _make_flow(
            path="/v1/models/gemini-3.1-pro-preview:generateContent",
            request_body={"contents": []},
        )
        meta = GeminiAdapter().parse_request(flow)
        assert meta.model == "gemini-3.1-pro-preview"
        assert meta.stream is False

    def test_stream_flag_set_for_stream_generate_content(self) -> None:
        flow = _make_flow(
            path="/v1beta/models/gemini-2.5-pro:streamGenerateContent",
            request_body={"contents": []},
        )
        meta = GeminiAdapter().parse_request(flow)
        assert meta.stream is True

    def test_embeddings_request_no_stream(self) -> None:
        flow = _make_flow(
            path="/v1beta/models/text-embedding-004:embedContent",
            request_body={"content": {"parts": [{"text": "hello"}]}},
        )
        meta = GeminiAdapter().parse_request(flow)
        assert meta.model == "text-embedding-004"
        assert meta.stream is False

    def test_unrecognised_path_returns_unknown_model(self) -> None:
        req = tutils.treq(host=GEMINI_HOST, port=443, path="/some/other/path")
        req.content = b""
        flow = tflow.tflow(req=req)
        meta = GeminiAdapter().parse_request(flow)
        assert meta.model == "unknown"
        assert meta.stream is False

    def test_path_with_query_string(self) -> None:
        flow = _make_flow(
            path="/v1beta/models/gemini-2.5-pro:generateContent?alt=sse",
            request_body={"contents": []},
        )
        meta = GeminiAdapter().parse_request(flow)
        assert meta.model == "gemini-2.5-pro"


# ---------------------------------------------------------------------------
# parse_response() — non-streaming
# ---------------------------------------------------------------------------


class TestParseResponseNonStreaming:
    def test_basic_with_cache(self) -> None:
        body = (FIXTURES / "generate_content_basic.json").read_text()
        flow = _make_flow(response_body=body)
        meta = GeminiAdapter().parse_response(flow, _make_request_meta())
        assert meta.input_tokens == 52
        assert meta.output_tokens == 9
        assert meta.thinking_tokens == 0
        assert meta.cache_read_tokens == 30
        assert meta.cache_write_tokens == 0
        assert meta.tokens_complete is True
        assert meta.latency_ms > 0

    def test_thinking_tokens_extracted(self) -> None:
        body = (FIXTURES / "generate_content_thinking.json").read_text()
        flow = _make_flow(response_body=body)
        meta = GeminiAdapter().parse_response(flow, _make_request_meta())
        assert meta.input_tokens == 78
        assert meta.output_tokens == 16
        assert meta.thinking_tokens == 412
        assert meta.tokens_complete is True

    def test_no_usage_metadata_marks_incomplete(self) -> None:
        # Older API shape without usageMetadata — must not crash.
        body = (FIXTURES / "generate_content_no_usage_metadata.json").read_text()
        flow = _make_flow(response_body=body)
        meta = GeminiAdapter().parse_response(flow, _make_request_meta())
        assert meta.input_tokens == 0
        assert meta.output_tokens == 0
        assert meta.tokens_complete is False

    def test_multimodal_logs_modality(self, monkeypatch) -> None:
        body = (FIXTURES / "generate_content_multimodal.json").read_text()
        flow = _make_flow(response_body=body)

        # Capture the structlog event without depending on stdlib caplog.
        events: list[tuple[str, dict]] = []
        from halton_meter.adapters import gemini as gemini_mod

        def _capture(event, **kwargs):  # type: ignore[no-untyped-def]
            events.append((event, kwargs))

        monkeypatch.setattr(gemini_mod.log, "info", _capture)

        meta = GeminiAdapter().parse_response(flow, _make_request_meta())
        # Rolled-up promptTokenCount used for v1.
        assert meta.input_tokens == 1287
        assert meta.output_tokens == 13
        assert meta.tokens_complete is True
        # Multimodal log line fires with non-text modalities.
        assert any(e[0] == "adapter.gemini.multimodal_input_detected" for e in events)
        modalities_logged = [
            e[1].get("modalities") for e in events
            if e[0] == "adapter.gemini.multimodal_input_detected"
        ]
        assert any("IMAGE" in (m or []) for m in modalities_logged)

    def test_empty_body_marks_incomplete(self) -> None:
        flow = _make_flow(response_body="")
        meta = GeminiAdapter().parse_response(flow, _make_request_meta())
        assert meta.tokens_complete is False

    def test_truncated_json_marks_incomplete(self) -> None:
        flow = _make_flow(response_body='{"usageMetadata": {"promptTokenCount":')
        meta = GeminiAdapter().parse_response(flow, _make_request_meta())
        assert meta.tokens_complete is False


# ---------------------------------------------------------------------------
# parse_response() — streaming JSON-array
# ---------------------------------------------------------------------------


class TestParseResponseStreaming:
    def test_well_formed_stream(self) -> None:
        body = (FIXTURES / "stream_generate_content.txt").read_text()
        flow = _make_flow(
            path="/v1beta/models/gemini-2.5-pro:streamGenerateContent",
            response_body=body,
        )
        meta = GeminiAdapter().parse_response(
            flow, _make_request_meta(stream=True)
        )
        assert meta.input_tokens == 11
        assert meta.output_tokens == 4
        assert meta.tokens_complete is True

    def test_truncated_stream_marks_incomplete(self, caplog) -> None:
        body = (FIXTURES / "stream_generate_content_truncated.txt").read_text()
        flow = _make_flow(
            path="/v1beta/models/gemini-2.5-pro:streamGenerateContent",
            response_body=body,
        )
        with caplog.at_level(logging.DEBUG):
            meta = GeminiAdapter().parse_response(
                flow, _make_request_meta(stream=True)
            )
        assert meta.input_tokens == 0
        assert meta.output_tokens == 0
        assert meta.tokens_complete is False

    def test_empty_stream_marks_incomplete(self) -> None:
        flow = _make_flow(
            path="/v1beta/models/gemini-2.5-pro:streamGenerateContent",
            response_body="",
        )
        meta = GeminiAdapter().parse_response(
            flow, _make_request_meta(stream=True)
        )
        assert meta.tokens_complete is False


# ---------------------------------------------------------------------------
# parse_response() — embeddings
# ---------------------------------------------------------------------------


class TestParseResponseEmbeddings:
    def test_embed_content(self) -> None:
        body = (FIXTURES / "embed_content.json").read_text()
        flow = _make_flow(
            path="/v1beta/models/text-embedding-004:embedContent",
            response_body=body,
        )
        meta = GeminiAdapter().parse_response(
            flow, _make_request_meta(model="text-embedding-004")
        )
        assert meta.input_tokens == 27
        assert meta.output_tokens == 0
        assert meta.tokens_complete is True


# ---------------------------------------------------------------------------
# Pricing integration
# ---------------------------------------------------------------------------


class TestPricingIntegration:
    def test_compute_cost_positive_for_known_model(self) -> None:
        cost = compute_cost_millicents(
            model="gemini-2.5-pro",
            input_tokens=52,
            output_tokens=9,
            thinking_tokens=0,
            cache_read_tokens=30,
            cache_write_tokens=0,
        )
        assert cost is not None
        assert cost > 0

    def test_thinking_tokens_billed_at_output_rate(self) -> None:
        # GEMINI_RATES sets thinking == output for every entry; verify by
        # computing two ways.
        cost_via_thinking = compute_cost_millicents(
            model="gemini-2.5-pro",
            input_tokens=78,
            output_tokens=16,
            thinking_tokens=412,
            cache_read_tokens=0,
            cache_write_tokens=0,
        )
        cost_via_output = compute_cost_millicents(
            model="gemini-2.5-pro",
            input_tokens=78,
            output_tokens=16 + 412,
            thinking_tokens=0,
            cache_read_tokens=0,
            cache_write_tokens=0,
        )
        assert cost_via_thinking is not None
        assert cost_via_thinking == cost_via_output

    def test_tiered_rate_fires_above_200k(self) -> None:
        # Sanity-check: the high-context tier exists and is more expensive
        # per-input-token than the standard tier.
        tiered = GEMINI_TIERED_RATES["gemini-2.5-pro"]
        assert tiered.high_context.input > tiered.standard.input

        # Cost just above the threshold uses the high-context input rate.
        cost_high = compute_cost_millicents(
            model="gemini-2.5-pro",
            input_tokens=250_000,
            output_tokens=120,
            thinking_tokens=0,
            cache_read_tokens=0,
            cache_write_tokens=0,
        )
        # Cost just below the threshold uses the standard rate.
        cost_low = compute_cost_millicents(
            model="gemini-2.5-pro",
            input_tokens=200_000,
            output_tokens=120,
            thinking_tokens=0,
            cache_read_tokens=0,
            cache_write_tokens=0,
        )
        assert cost_high is not None
        assert cost_low is not None
        # The 250k request must cost more than the 200k request — both
        # because it has more input tokens AND because the per-token rate is
        # higher.
        assert cost_high > cost_low

    def test_high_context_fixture_drives_tiered_rate(self) -> None:
        body = (FIXTURES / "generate_content_high_context.json").read_text()
        flow = _make_flow(response_body=body)
        meta = GeminiAdapter().parse_response(flow, _make_request_meta())
        assert meta.input_tokens == 250_000
        assert meta.tokens_complete is True
        # Cost computed off the parsed counts uses the high_context tier.
        cost = compute_cost_millicents(
            model="gemini-2.5-pro",
            input_tokens=meta.input_tokens,
            output_tokens=meta.output_tokens,
            thinking_tokens=meta.thinking_tokens,
            cache_read_tokens=meta.cache_read_tokens,
            cache_write_tokens=meta.cache_write_tokens,
        )
        # Hand-compute the expected cost using the high_context rates.
        tiered = GEMINI_TIERED_RATES["gemini-2.5-pro"]
        expected = (
            meta.input_tokens * tiered.high_context.input
            + meta.output_tokens * tiered.high_context.output
        ) // 1_000_000
        assert cost == expected


# ---------------------------------------------------------------------------
# Wiring
# ---------------------------------------------------------------------------


class TestWiring:
    def test_adapter_in_registry(self) -> None:
        assert any(isinstance(a, GeminiAdapter) for a in ADAPTER_REGISTRY)

    def test_adapter_satisfies_protocol(self) -> None:
        assert isinstance(GeminiAdapter(), ProviderAdapter)

    def test_registry_order_gemini_after_openai(self) -> None:
        # First-match-wins; Gemini sits after OpenAI in the registry.
        positions = {type(a).__name__: i for i, a in enumerate(ADAPTER_REGISTRY)}
        assert positions["GeminiAdapter"] > positions["OpenAIAdapter"]

    def test_gemini_adapter_matches_valid_paths(self) -> None:
        # Issue #2: path filtering moved into adapter.matches_url()
        adapter = GeminiAdapter()
        assert adapter.matches_url(GEMINI_HOST, "/v1beta/models/gemini-2.5-pro:generateContent")
        assert adapter.matches_url(GEMINI_HOST, "/v1/models/text-embedding-004:embedContent")
        # Invalid paths should not match
        assert not adapter.matches_url(GEMINI_HOST, "/invalid/path")

    def test_openai_adapter_does_not_match_gemini_paths(self) -> None:
        # Sanity — adapter routing is host-scoped, not path-scoped.
        assert (
            OpenAIAdapter().matches_url(
                GEMINI_HOST, "/v1beta/models/gemini-2.5-pro:generateContent"
            )
            is False
        )
