"""
Unit tests for AnthropicAdapter.

All tests use recorded fixtures — no live network calls. Flows are constructed
with mitmproxy's tflow/tutils helpers, which produce fully typed HTTPFlow objects
without touching the network.

Fixture files are in tests/fixtures/anthropic/:
  non_streaming_response.json    — standard non-streaming response with usage
  non_streaming_with_cache.json  — non-streaming with cache_creation + cache_read
  streaming_response.txt         — SSE stream with message_start + message_delta
  streaming_with_thinking.txt    — SSE stream including thinking_tokens
  streaming_with_cache.txt       — SSE stream with cache_creation + cache_read
  error_response.json            — Anthropic error body (no usage fields)
"""

from __future__ import annotations

import json
import time
from pathlib import Path

import pytest
from mitmproxy import http
from mitmproxy.test import tflow, tutils

from halton_meter.adapters.anthropic import AnthropicAdapter
from halton_meter.adapters.base import RequestMetadata

FIXTURES = Path(__file__).parent.parent / "fixtures" / "anthropic"


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_flow(
    path: str = "/v1/messages",
    request_body: dict | None = None,
    response_body: str | bytes | None = None,
    content_type: str = "application/json",
) -> http.HTTPFlow:
    """
    Build a minimal HTTPFlow for testing.

    request_body is serialised to JSON and set as request content.
    response_body is set as the response content with the given content_type.
    """
    req_content = (
        json.dumps(request_body or {}).encode()
        if request_body is not None
        else b""
    )
    req = tutils.treq(host="api.anthropic.com", port=443, path=path)
    req.content = req_content

    flow = tflow.tflow(req=req)

    if response_body is not None:
        body_bytes = (
            response_body.encode() if isinstance(response_body, str) else response_body
        )
        flow.response = http.Response.make(
            200,
            body_bytes,
            {"Content-Type": content_type},
        )

    return flow


def _make_request_meta(model: str = "claude-haiku-4-5", stream: bool = False) -> RequestMetadata:
    """Create a RequestMetadata with a started_at set slightly in the past."""
    return RequestMetadata(
        provider="anthropic",
        model=model,
        stream=stream,
        started_at=time.monotonic() - 0.5,  # simulate 500ms request time
    )


# ---------------------------------------------------------------------------
# matches()
# ---------------------------------------------------------------------------


class TestMatches:
    def test_matches_exact_host(self) -> None:
        adapter = AnthropicAdapter()
        assert adapter.matches("api.anthropic.com") is True

    def test_matches_host_with_port(self) -> None:
        # Some Anthropic SDK versions send "api.anthropic.com:443"
        adapter = AnthropicAdapter()
        assert adapter.matches("api.anthropic.com:443") is True

    def test_does_not_match_other_host(self) -> None:
        adapter = AnthropicAdapter()
        assert adapter.matches("api.openai.com") is False

    def test_does_not_match_partial(self) -> None:
        adapter = AnthropicAdapter()
        assert adapter.matches("notapi.anthropic.com") is False


class TestMatchesRejectsHostSuffix:
    """
    Adversarial host-match tests (P0-2 / P2-3, 2026-04-30).

    A naive `startswith("api.anthropic.com")` would match attacker-controlled
    hosts like `api.anthropic.com.evil.com`. A naive `endswith` would match
    `evil.api.anthropic.com`. We require exact equality plus an explicit
    port-suffix carve-out.
    """

    def test_rejects_trailing_suffix_injection(self) -> None:
        adapter = AnthropicAdapter()
        assert adapter.matches("api.anthropic.com.evil.com") is False

    def test_rejects_leading_subdomain_injection(self) -> None:
        adapter = AnthropicAdapter()
        assert adapter.matches("evil.api.anthropic.com") is False

    def test_accepts_exact_host(self) -> None:
        adapter = AnthropicAdapter()
        assert adapter.matches("api.anthropic.com") is True

    def test_accepts_exact_host_with_port(self) -> None:
        adapter = AnthropicAdapter()
        assert adapter.matches("api.anthropic.com:443") is True


# ---------------------------------------------------------------------------
# parse_request()
# ---------------------------------------------------------------------------


class TestParseRequest:
    def test_extracts_model_and_stream_false(self) -> None:
        adapter = AnthropicAdapter()
        flow = _make_flow(
            request_body={"model": "claude-haiku-4-5", "stream": False, "messages": []}
        )
        meta = adapter.parse_request(flow)
        assert meta.provider == "anthropic"
        assert meta.model == "claude-haiku-4-5"
        assert meta.stream is False

    def test_extracts_stream_true(self) -> None:
        adapter = AnthropicAdapter()
        flow = _make_flow(
            request_body={"model": "claude-sonnet-4-5", "stream": True, "messages": []}
        )
        meta = adapter.parse_request(flow)
        assert meta.stream is True

    def test_empty_body_returns_unknown_model(self) -> None:
        # Non-JSON body (e.g. GET /v1/models) should not crash
        adapter = AnthropicAdapter()
        req = tutils.treq(host="api.anthropic.com", port=443, path="/v1/models")
        req.content = b""
        flow = tflow.tflow(req=req)
        meta = adapter.parse_request(flow)
        assert meta.model == "unknown"
        assert meta.stream is False

    def test_non_json_body_returns_unknown_model(self) -> None:
        adapter = AnthropicAdapter()
        req = tutils.treq(host="api.anthropic.com", port=443, path="/v1/messages")
        req.content = b"not-json"
        flow = tflow.tflow(req=req)
        meta = adapter.parse_request(flow)
        assert meta.model == "unknown"

    def test_started_at_is_recent(self) -> None:
        adapter = AnthropicAdapter()
        before = time.monotonic()
        flow = _make_flow(request_body={"model": "claude-haiku-4-5", "messages": []})
        meta = adapter.parse_request(flow)
        after = time.monotonic()
        assert before <= meta.started_at <= after


# ---------------------------------------------------------------------------
# parse_response() — non-streaming
# ---------------------------------------------------------------------------


class TestParseResponseNonStreaming:
    def test_parses_non_streaming_fixture(self) -> None:
        fixture = (FIXTURES / "non_streaming_response.json").read_text()
        adapter = AnthropicAdapter()
        flow = _make_flow(response_body=fixture)
        meta = adapter.parse_response(flow, _make_request_meta())
        assert meta.input_tokens == 18
        assert meta.output_tokens == 7
        assert meta.thinking_tokens == 0
        assert meta.cache_read_tokens == 0
        assert meta.tokens_complete is True

    def test_latency_is_positive(self) -> None:
        fixture = (FIXTURES / "non_streaming_response.json").read_text()
        adapter = AnthropicAdapter()
        flow = _make_flow(response_body=fixture)
        meta = adapter.parse_response(flow, _make_request_meta())
        assert meta.latency_ms > 0

    def test_error_body_returns_zero_tokens_incomplete(self) -> None:
        # Error responses have no "usage" key — should return zeros with tokens_complete=True
        # (the body is valid JSON, just missing usage — defaults to 0, not incomplete)
        fixture = (FIXTURES / "error_response.json").read_text()
        adapter = AnthropicAdapter()
        flow = _make_flow(response_body=fixture)
        meta = adapter.parse_response(flow, _make_request_meta())
        assert meta.input_tokens == 0
        assert meta.output_tokens == 0
        assert meta.tokens_complete is True  # JSON parsed fine, usage just absent

    def test_empty_body_sets_tokens_complete_false(self) -> None:
        # Completely empty body cannot be JSON-decoded → tokens_complete=False
        adapter = AnthropicAdapter()
        flow = _make_flow(response_body="")
        # Empty string → json.loads("") raises → tokens_complete=False
        meta = adapter.parse_response(flow, _make_request_meta())
        assert meta.tokens_complete is False

    def test_truncated_json_sets_tokens_complete_false(self) -> None:
        adapter = AnthropicAdapter()
        flow = _make_flow(response_body='{"usage": {"input_tokens":')  # truncated
        meta = adapter.parse_response(flow, _make_request_meta())
        assert meta is not None
        assert meta.tokens_complete is False

    def test_skip_returns_none_when_model_unknown_and_zero_tokens(self) -> None:
        """When the request body had no model AND the response carries no
        usage tokens, the adapter signals "skip this row" by returning None.
        See decisions.md 2026-05-02 ("NULL cost handling in report
        aggregation"). The error_response fixture has zero tokens; combine
        with model='unknown' and the row is dropped entirely.
        """
        fixture = (FIXTURES / "error_response.json").read_text()
        adapter = AnthropicAdapter()
        flow = _make_flow(response_body=fixture)
        result = adapter.parse_response(flow, _make_request_meta(model="unknown"))
        assert result is None

    def test_no_skip_when_model_known_even_if_zero_tokens(self) -> None:
        """Defensive: a known model + zero tokens (e.g. an error response on
        a real call) must NOT be skipped — the row records the failed call."""
        fixture = (FIXTURES / "error_response.json").read_text()
        adapter = AnthropicAdapter()
        flow = _make_flow(response_body=fixture)
        meta = adapter.parse_response(
            flow, _make_request_meta(model="claude-haiku-4-5")
        )
        assert meta is not None
        assert meta.input_tokens == 0
        assert meta.output_tokens == 0

    def test_no_skip_when_model_unknown_but_tokens_present(self) -> None:
        """Defensive: model=unknown but real tokens present (unlikely but
        possible if request body parse failed yet response is a normal usage
        block) — keep the row, do not skip."""
        fixture = (FIXTURES / "non_streaming_response.json").read_text()
        adapter = AnthropicAdapter()
        flow = _make_flow(response_body=fixture)
        meta = adapter.parse_response(flow, _make_request_meta(model="unknown"))
        assert meta is not None
        assert meta.input_tokens == 18
        assert meta.output_tokens == 7


# ---------------------------------------------------------------------------
# parse_response() — streaming SSE
# ---------------------------------------------------------------------------


class TestParseResponseStreaming:
    def test_parses_streaming_fixture(self) -> None:
        fixture = (FIXTURES / "streaming_response.txt").read_text()
        adapter = AnthropicAdapter()
        flow = _make_flow(response_body=fixture, content_type="text/event-stream")
        meta = adapter.parse_response(flow, _make_request_meta(stream=True))
        assert meta.input_tokens == 15
        assert meta.output_tokens == 9
        assert meta.thinking_tokens == 0
        assert meta.cache_read_tokens == 0
        assert meta.tokens_complete is True

    def test_parses_streaming_with_thinking_tokens(self) -> None:
        fixture = (FIXTURES / "streaming_with_thinking.txt").read_text()
        adapter = AnthropicAdapter()
        flow = _make_flow(response_body=fixture, content_type="text/event-stream")
        meta = adapter.parse_response(flow, _make_request_meta(stream=True))
        assert meta.input_tokens == 42
        assert meta.output_tokens == 7
        assert meta.thinking_tokens == 318
        assert meta.tokens_complete is True

    def test_empty_sse_body_returns_zeros(self) -> None:
        adapter = AnthropicAdapter()
        flow = _make_flow(response_body="", content_type="text/event-stream")
        meta = adapter.parse_response(flow, _make_request_meta(stream=True))
        # Empty SSE body: _parse_sse returns (0,0,0,0), no exception → tokens_complete=True
        assert meta.input_tokens == 0
        assert meta.output_tokens == 0
        assert meta.tokens_complete is True

    def test_sse_with_malformed_data_lines_skipped(self) -> None:
        # Lines with invalid JSON in data: field should be skipped, not crash
        sse_body = (
            "event: message_start\n"
            "data: {invalid json}\n"
            "\n"
            "event: message_delta\n"
            'data: {"type": "message_delta", "usage": {"output_tokens": 5}}\n'
            "\n"
        )
        adapter = AnthropicAdapter()
        flow = _make_flow(response_body=sse_body, content_type="text/event-stream")
        meta = adapter.parse_response(flow, _make_request_meta(stream=True))
        # message_start data was invalid JSON so input_tokens stays 0
        # message_delta parsed fine
        assert meta.input_tokens == 0
        assert meta.output_tokens == 5
        assert meta.tokens_complete is True


# ---------------------------------------------------------------------------
# Cache-token extraction (P0-2, 2026-04-30)
# ---------------------------------------------------------------------------


# Each row: (fixture_filename, content_type, expected_cache_read,
#            expected_cache_write, expected_input, expected_output)
_CACHE_FIXTURES = [
    pytest.param(
        "non_streaming_response.json",
        "application/json",
        0,
        0,
        18,
        7,
        id="non_streaming_no_cache",
    ),
    pytest.param(
        "non_streaming_with_cache.json",
        "application/json",
        256,
        1024,
        11,
        13,
        id="non_streaming_with_cache",
    ),
    pytest.param(
        "streaming_response.txt",
        "text/event-stream",
        0,
        0,
        15,
        9,
        id="sse_no_cache",
    ),
    pytest.param(
        "streaming_with_cache.txt",
        "text/event-stream",
        512,
        2048,
        21,
        4,
        id="sse_with_cache",
    ),
]


class TestCacheTokenExtraction:
    """
    Parametrised: cache_read_tokens + cache_write_tokens populate correctly
    for both non-streaming and SSE paths, including the no-cache case.

    Decision B (2026-04-30): cache_creation_input_tokens is a flat int in
    Anthropic's response usage; we map it 1:1 to cache_write_tokens.
    """

    @pytest.mark.parametrize(
        "fixture_name,content_type,exp_cache_read,exp_cache_write,exp_input,exp_output",
        _CACHE_FIXTURES,
    )
    def test_cache_tokens_populated(
        self,
        fixture_name: str,
        content_type: str,
        exp_cache_read: int,
        exp_cache_write: int,
        exp_input: int,
        exp_output: int,
    ) -> None:
        fixture = (FIXTURES / fixture_name).read_text()
        adapter = AnthropicAdapter()
        flow = _make_flow(response_body=fixture, content_type=content_type)
        is_stream = "event-stream" in content_type
        meta = adapter.parse_response(flow, _make_request_meta(stream=is_stream))

        assert meta.input_tokens == exp_input
        assert meta.output_tokens == exp_output
        assert meta.cache_read_tokens == exp_cache_read
        assert meta.cache_write_tokens == exp_cache_write
        assert meta.tokens_complete is True
