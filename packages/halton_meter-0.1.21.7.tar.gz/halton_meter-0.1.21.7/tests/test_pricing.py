"""Tests for ``halton_meter.pricing.compute_cost_millicents``.

Covers:

* The public kwarg surface (``cache_read_tokens`` + ``cache_write_tokens``).
* A golden hand-computed cost across input + output + thinking +
  cache_read + cache_write against a real seeded rate sheet.
* The sum-first-then-divide truncation fix: a request with many small
  line items where the *old* per-line ``// 1_000_000`` formula would have
  undercounted by a known delta and the new sum-first formula matches the
  hand-computed total to the millicent.
* The ``cache_write_tokens=0`` default — passing zero must equal omitting
  the kwarg entirely.

See memory/plans/2026-04-30-daemon-audit-remediation.md (P0-3) for the
rationale behind each case.
"""

from __future__ import annotations

from halton_meter.pricing import compute_cost_millicents
from halton_meter.pricing.matrix import ANTHROPIC_RATES


def test_returns_none_for_unknown_model() -> None:
    """Unknown model -> None (so the column stores NULL, not a wrong 0)."""
    assert (
        compute_cost_millicents(
            model="not-a-real-model",
            input_tokens=100,
            output_tokens=100,
            thinking_tokens=0,
            cache_read_tokens=0,
            cache_write_tokens=0,
        )
        is None
    )


def test_golden_mixed_request_against_known_rate_sheet() -> None:
    """Hand-computed millicents for a mixed request against ``claude-sonnet-4-6``.

    Rate sheet (millicents per million tokens):
        input        = 300_000   ($3.00 / MTok)
        output       = 1_500_000 ($15.00 / MTok)
        thinking     = 1_500_000 ($15.00 / MTok)
        cache_read   = 30_000    ($0.30 / MTok)
        cache_write  = 375_000   (1.25x input, $3.75 / MTok)

    Tokens:
        input        = 12_345
        output       = 6_789
        thinking     = 2_500
        cache_read   = 98_765
        cache_write  = 4_321

    Numerators (tokens * rate):
        12_345 * 300_000   =  3_703_500_000
         6_789 * 1_500_000 = 10_183_500_000
         2_500 * 1_500_000 =  3_750_000_000
        98_765 * 30_000    =  2_962_950_000
         4_321 * 375_000   =  1_620_375_000
                            ----------------
                            = 22_220_325_000

    Cost = 22_220_325_000 // 1_000_000 = 22_220 millicents ($0.2222).
    """
    # Rate-sheet sanity guard. If the seeded matrix changes these numbers
    # the hand-computation in the docstring is invalidated and this test
    # must be re-derived (loud failure rather than silent drift).
    rates = ANTHROPIC_RATES["claude-sonnet-4-6"]
    assert rates.input == 300_000
    assert rates.output == 1_500_000
    assert rates.thinking == 1_500_000
    assert rates.cache_read == 30_000
    assert rates.cache_write == 375_000

    cost = compute_cost_millicents(
        model="claude-sonnet-4-6",
        input_tokens=12_345,
        output_tokens=6_789,
        thinking_tokens=2_500,
        cache_read_tokens=98_765,
        cache_write_tokens=4_321,
    )
    assert cost == 22_220


def test_sum_first_beats_per_line_truncation() -> None:
    """Many small line items: sum-first gets +3 millicents over per-line.

    Rate sheet for ``claude-haiku-4-5`` (millicents per million tokens):
        input        =   100_000   ($1.00 / MTok)
        output       =   500_000   ($5.00 / MTok)
        thinking     =   500_000   ($5.00 / MTok)
        cache_read   =    10_000   ($0.10 / MTok)
        cache_write  =   125_000   (1.25x input, $1.25 / MTok)

    Tokens chosen so each per-line product is < 1_000_000 (so the OLD
    per-line ``// 1_000_000`` rounded every term down to zero):
        input        = 9    -> 9   * 100_000 =   900_000  (old: 0)
        output       = 1    -> 1   * 500_000 =   500_000  (old: 0)
        thinking     = 1    -> 1   * 500_000 =   500_000  (old: 0)
        cache_read   = 99   -> 99  * 10_000  =   990_000  (old: 0)
        cache_write  = 7    -> 7   * 125_000 =   875_000  (old: 0)
                                              ----------
        sum                                  = 3_765_000

    New (sum-first): 3_765_000 // 1_000_000 = 3 millicents.
    Old (per-line):  0 + 0 + 0 + 0 + 0       = 0 millicents.
    Delta proven: 3 millicents undercounted by the old formula.
    """
    rates = ANTHROPIC_RATES["claude-haiku-4-5"]
    assert rates.input == 100_000
    assert rates.output == 500_000
    assert rates.thinking == 500_000
    assert rates.cache_read == 10_000
    assert rates.cache_write == 125_000

    input_tokens = 9
    output_tokens = 1
    thinking_tokens = 1
    cache_read_tokens = 99
    cache_write_tokens = 7

    cost = compute_cost_millicents(
        model="claude-haiku-4-5",
        input_tokens=input_tokens,
        output_tokens=output_tokens,
        thinking_tokens=thinking_tokens,
        cache_read_tokens=cache_read_tokens,
        cache_write_tokens=cache_write_tokens,
    )

    # Sum-first hand-computed total:
    expected_numerator = (
        input_tokens * rates.input
        + output_tokens * rates.output
        + thinking_tokens * rates.thinking
        + cache_read_tokens * rates.cache_read
        + cache_write_tokens * rates.cache_write
    )
    assert expected_numerator == 3_765_000
    assert cost == expected_numerator // 1_000_000 == 3

    # Reproduce what the OLD per-line truncation would have returned and
    # assert the delta is exactly the +3 millicents we expected.
    old_per_line = (
        input_tokens * rates.input // 1_000_000
        + output_tokens * rates.output // 1_000_000
        + thinking_tokens * rates.thinking // 1_000_000
        + cache_read_tokens * rates.cache_read // 1_000_000
        + cache_write_tokens * rates.cache_write // 1_000_000
    )
    assert old_per_line == 0
    assert cost - old_per_line == 3


def test_cache_write_zero_kwarg_equals_default() -> None:
    """Passing ``cache_write_tokens=0`` must equal omitting the kwarg."""
    common = {
        "model": "claude-sonnet-4-6",
        "input_tokens": 1_000,
        "output_tokens": 500,
        "thinking_tokens": 0,
        "cache_read_tokens": 250,
    }
    with_explicit_zero = compute_cost_millicents(**common, cache_write_tokens=0)
    with_default = compute_cost_millicents(**common)
    assert with_explicit_zero == with_default
    assert with_explicit_zero is not None
    assert with_explicit_zero > 0


def test_cache_write_tokens_contribute_to_cost() -> None:
    """Non-zero ``cache_write_tokens`` must increase the total monotonically.

    Guards against a regression where the new kwarg was accepted but
    silently dropped from the formula.
    """
    base = compute_cost_millicents(
        model="claude-opus-4-7",
        input_tokens=1_000,
        output_tokens=500,
        thinking_tokens=0,
        cache_read_tokens=0,
        cache_write_tokens=0,
    )
    with_writes = compute_cost_millicents(
        model="claude-opus-4-7",
        input_tokens=1_000,
        output_tokens=500,
        thinking_tokens=0,
        cache_read_tokens=0,
        cache_write_tokens=10_000,
    )
    assert base is not None and with_writes is not None
    rates = ANTHROPIC_RATES["claude-opus-4-7"]
    expected_delta = 10_000 * rates.cache_write // 1_000_000
    assert with_writes - base == expected_delta


# ---------------------------------------------------------------------------
# Gemini resolver tests (v0.1.12).
#
# Verify that compute_cost_millicents now resolves Gemini models and
# applies the correct tier (standard vs high_context) based on input_tokens.
# ---------------------------------------------------------------------------


def test_compute_cost_millicents_gemini_standard_tier() -> None:
    """gemini-2.5-pro at 100k input tokens uses standard (≤200k) rates.

    Standard rates: $1.25/$10 input/output.
    Rate sheet (millicents/MTok): input=125_000, output=1_000_000.

    Numerator = 100_000 * 125_000 + 500_000 * 1_000_000
              = 12_500_000_000 + 500_000_000_000
              = 512_500_000_000
    Cost = 512_500_000_000 // 1_000_000 = 512_500 millicents.
    """
    from halton_meter.pricing.matrix import GEMINI_RATES

    rates = GEMINI_RATES["gemini-2.5-pro"]
    assert rates.input == 125_000  # $1.25/MTok sanity check

    cost = compute_cost_millicents(
        model="gemini-2.5-pro",
        input_tokens=100_000,
        output_tokens=500_000,
        thinking_tokens=0,
        cache_read_tokens=0,
        cache_write_tokens=0,
    )
    assert cost is not None
    expected_numerator = 100_000 * rates.input + 500_000 * rates.output
    assert cost == expected_numerator // 1_000_000 == 512_500


def test_compute_cost_millicents_gemini_high_context_tier() -> None:
    """gemini-2.5-pro at 300k input tokens uses high_context (>200k) rates.

    High-context rates: $2.50/$15 input/output.
    Rate sheet (millicents/MTok): input=250_000, output=1_500_000.

    Numerator = 300_000 * 250_000 + 500_000 * 1_500_000
              = 75_000_000_000 + 750_000_000_000
              = 825_000_000_000
    Cost = 825_000_000_000 // 1_000_000 = 825_000 millicents.
    """
    from halton_meter.pricing.matrix import GEMINI_TIERED_RATES

    tiered = GEMINI_TIERED_RATES["gemini-2.5-pro"]
    hc = tiered.high_context
    assert hc.input == 250_000  # $2.50/MTok sanity check

    cost = compute_cost_millicents(
        model="gemini-2.5-pro",
        input_tokens=300_000,
        output_tokens=500_000,
        thinking_tokens=0,
        cache_read_tokens=0,
        cache_write_tokens=0,
    )
    assert cost is not None
    expected_numerator = 300_000 * hc.input + 500_000 * hc.output
    assert cost == expected_numerator // 1_000_000 == 825_000


def test_compute_cost_millicents_gemini_exactly_at_threshold() -> None:
    """gemini-2.5-pro at exactly 200k input tokens uses STANDARD rates.

    The tier boundary is exclusive: input_tokens > 200_000 → high_context.
    At exactly 200_000 the standard rates apply.

    Standard: input=125_000, output=1_000_000 millicents/MTok.
    Numerator = 200_000 * 125_000 + 1_000_000 * 1_000_000
              = 25_000_000_000 + 1_000_000_000_000
              = 1_025_000_000_000
    Cost = 1_025_000_000_000 // 1_000_000 = 1_025_000 millicents.
    """
    from halton_meter.pricing.matrix import GEMINI_RATES, GEMINI_TIERED_RATES

    tiered = GEMINI_TIERED_RATES["gemini-2.5-pro"]
    assert tiered.threshold_tokens == 200_000

    cost = compute_cost_millicents(
        model="gemini-2.5-pro",
        input_tokens=200_000,
        output_tokens=1_000_000,
        thinking_tokens=0,
        cache_read_tokens=0,
        cache_write_tokens=0,
    )
    assert cost is not None
    std = GEMINI_RATES["gemini-2.5-pro"]
    expected_numerator = 200_000 * std.input + 1_000_000 * std.output
    assert cost == expected_numerator // 1_000_000 == 1_025_000

    # Cross-check: high_context would give a different (larger) value.
    hc = tiered.high_context
    hc_cost = (200_000 * hc.input + 1_000_000 * hc.output) // 1_000_000
    assert cost < hc_cost, "at-threshold should use standard, not high_context"


def test_compute_cost_millicents_gemini_single_tier() -> None:
    """gemini-3.1-flash-lite-preview (no surcharge) resolves via GEMINI_RATES.

    $0.25/$1.50 input/output → 25_000 / 150_000 millicents/MTok.

    Numerator = 1_000_000 * 25_000 + 1_000_000 * 150_000
              = 25_000_000_000 + 150_000_000_000
              = 175_000_000_000
    Cost = 175_000_000_000 // 1_000_000 = 175_000 millicents.
    """
    from halton_meter.pricing.matrix import GEMINI_RATES

    rates = GEMINI_RATES["gemini-3.1-flash-lite-preview"]
    assert rates.input == 25_000   # $0.25/MTok
    assert rates.output == 150_000  # $1.50/MTok

    cost = compute_cost_millicents(
        model="gemini-3.1-flash-lite-preview",
        input_tokens=1_000_000,
        output_tokens=1_000_000,
        thinking_tokens=0,
        cache_read_tokens=0,
        cache_write_tokens=0,
    )
    assert cost is not None
    expected_numerator = 1_000_000 * rates.input + 1_000_000 * rates.output
    assert cost == expected_numerator // 1_000_000 == 175_000


def test_compute_cost_millicents_gemini_returns_none_for_unknown() -> None:
    """An unrecognised Gemini-style model name must return None."""
    cost = compute_cost_millicents(
        model="gemini-unknown-model-xyz",
        input_tokens=1_000,
        output_tokens=500,
        thinking_tokens=0,
        cache_read_tokens=0,
        cache_write_tokens=0,
    )
    assert cost is None
