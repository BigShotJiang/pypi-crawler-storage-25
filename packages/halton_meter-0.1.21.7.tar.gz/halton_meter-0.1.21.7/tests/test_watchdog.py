"""Tests for ``halton_meter.watchdog`` (layer 2 of the connectivity-on-crash fix).

State machine tests are pure-logic with no I/O. Side-effect tests
mock ``subprocess.run`` and ``urllib.request.urlopen``. Real subprocess
only inside the optional ``requires_launchd`` integration, which is
hard-skipped in this commit (Vikrant's auto-memory is explicit that
touching his real system proxy in tests is off-limits).
"""

from __future__ import annotations

import io
import json
import shutil
import subprocess
import urllib.error
from typing import Any

import pytest

from halton_meter import watchdog


@pytest.fixture(autouse=True)
def _stub_mitm_io(monkeypatch: pytest.MonkeyPatch, request: pytest.FixtureRequest) -> None:
    """Default-safe MITM stubs.

    The new v0.1.16 P0.2 code paths in ``run_watchdog`` call
    ``_probe_mitm_port`` (real TCP connect) and ``_kickstart_daemon``
    (real ``launchctl kickstart -k``) on every tick. Without this
    fixture, every existing test that exercises ``run_watchdog`` would
    (a) hammer the dev machine's real loopback ports, and (b) on the
    5th MITM-fail tick, kickstart the operator's real halton-meter
    launchd job — which would sever the in-flight Claude Code session.
    Tests that specifically exercise the MITM path opt out by name
    prefix (``test_probe_mitm_port_*``) and override the stubs
    explicitly otherwise.
    """
    if request.node.name.startswith("test_probe_mitm_port_"):
        # Probe-unit tests need the real function under test; just
        # ensure kickstart can never fire from them.
        monkeypatch.setattr(watchdog, "_kickstart_daemon", lambda: True)
        return
    monkeypatch.setattr(watchdog, "_probe_mitm_port", lambda _h, _p: True)
    monkeypatch.setattr(watchdog, "_kickstart_daemon", lambda: True)


# --------------------------------------------------------------------------- #
# State machine                                                                #
# --------------------------------------------------------------------------- #


def test_state_machine_starts_healthy() -> None:
    sm = watchdog.WatchdogStateMachine()
    assert sm.state is watchdog.WatchdogState.HEALTHY
    assert sm.fail_count == 0
    assert sm.success_count == 0


def test_first_fail_moves_to_degrading() -> None:
    sm = watchdog.WatchdogStateMachine()
    t = sm.record_health(success=False)
    assert sm.state is watchdog.WatchdogState.DEGRADING
    assert t.from_ is watchdog.WatchdogState.HEALTHY
    assert t.to is watchdog.WatchdogState.DEGRADING
    assert t.fail_count == 1
    assert t.should_disable_proxy_now is False


def test_success_during_degrading_returns_to_healthy_and_resets_fail_count() -> None:
    sm = watchdog.WatchdogStateMachine()
    sm.record_health(success=False)
    sm.record_health(success=False)
    assert sm.fail_count == 2
    t = sm.record_health(success=True)
    assert sm.state is watchdog.WatchdogState.HEALTHY
    assert sm.fail_count == 0
    assert t.from_ is watchdog.WatchdogState.DEGRADING
    assert t.to is watchdog.WatchdogState.HEALTHY


def test_five_consecutive_fails_transition_to_proxy_disabled_and_signal_disable() -> None:
    sm = watchdog.WatchdogStateMachine()
    transitions = [sm.record_health(success=False) for _ in range(5)]
    assert sm.state is watchdog.WatchdogState.PROXY_DISABLED
    # Disable signal fires exactly on the 5th fail (the
    # DEGRADING -> PROXY_DISABLED edge) and not before.
    assert [t.should_disable_proxy_now for t in transitions] == [
        False,
        False,
        False,
        False,
        True,
    ]


def test_disable_signal_emitted_only_once_per_transition() -> None:
    sm = watchdog.WatchdogStateMachine()
    for _ in range(5):
        sm.record_health(success=False)
    # Continued failures from PROXY_DISABLED must NOT re-emit disable.
    for _ in range(10):
        t = sm.record_health(success=False)
        assert t.should_disable_proxy_now is False


def test_first_success_in_proxy_disabled_moves_to_recovering() -> None:
    sm = watchdog.WatchdogStateMachine()
    for _ in range(5):
        sm.record_health(success=False)
    assert sm.state is watchdog.WatchdogState.PROXY_DISABLED
    t = sm.record_health(success=True)
    assert sm.state is watchdog.WatchdogState.RECOVERING
    assert t.from_ is watchdog.WatchdogState.PROXY_DISABLED
    assert t.to is watchdog.WatchdogState.RECOVERING
    assert sm.success_count == 1


def test_fail_in_recovering_returns_to_proxy_disabled_and_resets_success_count() -> None:
    sm = watchdog.WatchdogStateMachine()
    for _ in range(5):
        sm.record_health(success=False)
    sm.record_health(success=True)
    sm.record_health(success=True)
    assert sm.success_count == 2
    t = sm.record_health(success=False)
    assert sm.state is watchdog.WatchdogState.PROXY_DISABLED
    assert sm.success_count == 0
    assert t.should_disable_proxy_now is False


def test_three_consecutive_successes_in_recovering_return_to_healthy() -> None:
    sm = watchdog.WatchdogStateMachine()
    for _ in range(5):
        sm.record_health(success=False)
    sm.record_health(success=True)
    sm.record_health(success=True)
    t = sm.record_health(success=True)
    assert sm.state is watchdog.WatchdogState.HEALTHY
    assert t.from_ is watchdog.WatchdogState.RECOVERING
    assert t.to is watchdog.WatchdogState.HEALTHY
    assert sm.fail_count == 0
    assert sm.success_count == 0


def test_flapping_in_degrading_never_reaches_proxy_disabled() -> None:
    sm = watchdog.WatchdogStateMachine()
    # Pattern: fail, succeed, fail, succeed, ... never accumulates 5 fails.
    for _ in range(20):
        sm.record_health(success=False)
        sm.record_health(success=True)
    assert sm.state is watchdog.WatchdogState.HEALTHY


def test_flapping_in_recovering_resets_success_count() -> None:
    sm = watchdog.WatchdogStateMachine()
    for _ in range(5):
        sm.record_health(success=False)
    # Pattern: succeed, fail, succeed, fail — never gets 3 successes in a row.
    for _ in range(10):
        sm.record_health(success=True)
        sm.record_health(success=False)
    # Last call was fail -> back in PROXY_DISABLED.
    assert sm.state is watchdog.WatchdogState.PROXY_DISABLED


# --------------------------------------------------------------------------- #
# disable_system_proxy                                                         #
# --------------------------------------------------------------------------- #


def test_disable_system_proxy_calls_networksetup_per_combo(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    calls: list[list[str]] = []

    def fake_run(argv: list[str], *_a: Any, **_kw: Any) -> Any:
        calls.append(list(argv))
        return subprocess.CompletedProcess(argv, 0, stdout="", stderr="")

    monkeypatch.setattr(watchdog.subprocess, "run", fake_run)

    watchdog.disable_system_proxy(["Wi-Fi", "Ethernet"])

    expected = {
        ("networksetup", "-setsecurewebproxystate", "Wi-Fi", "off"),
        ("networksetup", "-setwebproxystate", "Wi-Fi", "off"),
        ("networksetup", "-setsecurewebproxystate", "Ethernet", "off"),
        ("networksetup", "-setwebproxystate", "Ethernet", "off"),
    }
    assert {tuple(c) for c in calls} == expected


def test_disable_system_proxy_attempts_all_even_when_one_raises(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    calls: list[list[str]] = []

    def flaky(argv: list[str], *_a: Any, **_kw: Any) -> Any:
        calls.append(list(argv))
        if "Wi-Fi" in argv:
            raise OSError("simulated")
        return subprocess.CompletedProcess(argv, 0, stdout="", stderr="")

    monkeypatch.setattr(watchdog.subprocess, "run", flaky)

    watchdog.disable_system_proxy(["Wi-Fi", "Ethernet"])
    # All four combos still attempted.
    assert len(calls) == 4


# --------------------------------------------------------------------------- #
# poll_health                                                                  #
# --------------------------------------------------------------------------- #


class _FakeResp:
    def __init__(self, status: int, body: bytes) -> None:
        self.status = status
        self._body = body

    def read(self) -> bytes:
        return self._body

    def __enter__(self) -> _FakeResp:
        return self

    def __exit__(self, *_a: Any) -> None:
        return None


def test_poll_health_returns_true_for_200_ok_payload(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    body = json.dumps({"status": "ok", "version": "x"}).encode("utf-8")

    def fake_urlopen(_url: str, timeout: float = 0) -> _FakeResp:
        return _FakeResp(200, body)

    monkeypatch.setattr(watchdog.urllib.request, "urlopen", fake_urlopen)
    assert watchdog.poll_health(8765) is True


def test_poll_health_returns_false_on_url_error(monkeypatch: pytest.MonkeyPatch) -> None:
    def raiser(_url: str, timeout: float = 0) -> Any:
        raise urllib.error.URLError("connection refused")

    monkeypatch.setattr(watchdog.urllib.request, "urlopen", raiser)
    assert watchdog.poll_health(8765) is False


def test_poll_health_returns_false_on_socket_timeout(monkeypatch: pytest.MonkeyPatch) -> None:
    def raiser(_url: str, timeout: float = 0) -> Any:
        raise TimeoutError("timed out")

    monkeypatch.setattr(watchdog.urllib.request, "urlopen", raiser)
    assert watchdog.poll_health(8765) is False


def test_poll_health_returns_false_on_500(monkeypatch: pytest.MonkeyPatch) -> None:
    def fake_urlopen(_url: str, timeout: float = 0) -> _FakeResp:
        return _FakeResp(500, b"boom")

    monkeypatch.setattr(watchdog.urllib.request, "urlopen", fake_urlopen)
    assert watchdog.poll_health(8765) is False


def test_poll_health_returns_false_on_malformed_json(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    def fake_urlopen(_url: str, timeout: float = 0) -> _FakeResp:
        return _FakeResp(200, b"<html>not json</html>")

    monkeypatch.setattr(watchdog.urllib.request, "urlopen", fake_urlopen)
    assert watchdog.poll_health(8765) is False


def test_poll_health_returns_false_on_generic_exception(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    def raiser(_url: str, timeout: float = 0) -> Any:
        raise RuntimeError("anything else")

    monkeypatch.setattr(watchdog.urllib.request, "urlopen", raiser)
    # Must not propagate.
    assert watchdog.poll_health(8765) is False


def test_poll_health_returns_false_on_wrong_status_field(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    body = json.dumps({"status": "degraded"}).encode("utf-8")

    def fake_urlopen(_url: str, timeout: float = 0) -> _FakeResp:
        return _FakeResp(200, body)

    monkeypatch.setattr(watchdog.urllib.request, "urlopen", fake_urlopen)
    assert watchdog.poll_health(8765) is False


# --------------------------------------------------------------------------- #
# snapshot_interfaces                                                          #
# --------------------------------------------------------------------------- #


def test_snapshot_interfaces_non_macos_returns_empty(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(watchdog.sys, "platform", "linux")
    assert watchdog.snapshot_interfaces(8765) == []


def test_snapshot_interfaces_returns_matching_interfaces(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(watchdog.sys, "platform", "darwin")

    def fake_read(iface: str, *, secure: bool = True) -> tuple[bool, str | None, int | None]:
        if iface == "Wi-Fi":
            return (True, "127.0.0.1", 8080)
        if iface == "Ethernet":
            return (True, "10.0.0.5", 3128)  # someone else's proxy
        return (False, None, None)

    monkeypatch.setattr(watchdog.system_proxy, "read_proxy_target", fake_read)
    assert watchdog.snapshot_interfaces(8080) == ["Wi-Fi"]


def test_snapshot_interfaces_returns_empty_when_nothing_points_at_us(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(watchdog.sys, "platform", "darwin")
    monkeypatch.setattr(
        watchdog.system_proxy,
        "read_proxy_target",
        lambda _iface, *, secure=True: (False, None, None),
    )
    assert watchdog.snapshot_interfaces(8080) == []


def test_snapshot_interfaces_matches_listen_port_not_api_port(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """2B.10.5 regression. ``snapshot_interfaces`` must match against the
    proxy listener port (``daemon.listen_port``, default 8080), NOT the
    FastAPI ``/health`` port (``daemon.api_port``, default 8765). The
    OS stores the listener address on each network service; matching
    against ``api_port`` would always return empty on a real install
    where the two ports are distinct."""
    monkeypatch.setattr(watchdog.sys, "platform", "darwin")

    def fake_read(iface: str, *, secure: bool = True) -> tuple[bool, str | None, int | None]:
        # Exactly the shape Vikrant's Mac sees post-install: each
        # interface points at the mitmproxy listener (8080), not the
        # API (8765).
        if iface == "Wi-Fi":
            return (True, "127.0.0.1", 8080)
        return (False, None, None)

    monkeypatch.setattr(watchdog.system_proxy, "read_proxy_target", fake_read)
    monkeypatch.setattr(
        watchdog.system_proxy,
        "_macos_interfaces",
        lambda: ("Wi-Fi", "Thunderbolt Bridge"),
    )

    # The new contract: pass listen_port → matches.
    assert watchdog.snapshot_interfaces(8080) == ["Wi-Fi"]

    # The bug: passing api_port → no match (was the silent failure
    # mode prior to 2B.10.5).
    assert watchdog.snapshot_interfaces(8765) == []


# --------------------------------------------------------------------------- #
# run_watchdog                                                                 #
# --------------------------------------------------------------------------- #


def test_run_watchdog_exits_zero_when_no_interfaces(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(watchdog, "snapshot_interfaces", lambda _port: [])
    rc = watchdog.run_watchdog(8765)
    assert rc == 0


def test_run_watchdog_uses_listen_port_for_snapshot_and_api_port_for_health(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """2B.10.5: ``run_watchdog`` must snapshot interfaces on
    ``listen_port`` (proxy listener) and poll ``/health`` on
    ``api_port`` (FastAPI). Two distinct ports, two distinct purposes."""
    snapshot_calls: list[int] = []
    health_calls: list[int] = []

    def fake_snapshot(port: int) -> list[str]:
        snapshot_calls.append(port)
        return ["Wi-Fi"]

    def fake_poll(port: int, timeout: float = 1.0) -> bool:
        health_calls.append(port)
        return True

    monkeypatch.setattr(watchdog, "snapshot_interfaces", fake_snapshot)
    monkeypatch.setattr(watchdog, "poll_health", fake_poll)
    monkeypatch.setattr(watchdog.time, "sleep", lambda _s: None)
    # v0.1.13: pin the per-tick port re-resolve so the dev machine's
    # real ~/.halton-meter/runtime.toml does not leak into this unit
    # test. Caller-supplied ports are the contract under test.
    monkeypatch.setattr(
        watchdog,
        "_resolve_runtime_ports",
        lambda fallback_api, fallback_listen: (fallback_api, fallback_listen),
    )

    rc = watchdog.run_watchdog(8765, listen_port=8080, max_polls=3)
    assert rc == 0
    assert snapshot_calls == [8080], (
        "snapshot_interfaces should be called with listen_port (8080)"
    )
    assert health_calls == [8765, 8765, 8765], (
        "poll_health should be called with api_port (8765)"
    )


def test_run_watchdog_disables_proxy_after_threshold(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(watchdog, "snapshot_interfaces", lambda _port: ["Wi-Fi"])
    # First poll succeeds to latch the 2B.10.8 cold-start gate open;
    # subsequent polls all fail to drive the DEGRADING ->
    # PROXY_DISABLED edge.
    poll_results = iter([True] + [False] * 20)
    monkeypatch.setattr(
        watchdog, "poll_health", lambda _port, timeout=1.0: next(poll_results)
    )
    # Don't actually sleep.
    monkeypatch.setattr(watchdog.time, "sleep", lambda _s: None)

    disable_calls: list[list[str]] = []

    def fake_disable(interfaces: list[str]) -> None:
        disable_calls.append(list(interfaces))

    monkeypatch.setattr(watchdog, "disable_system_proxy", fake_disable)

    rc = watchdog.run_watchdog(8765, max_polls=10)
    assert rc == 0
    # Disabled exactly once across the 10 polls.
    assert disable_calls == [["Wi-Fi"]]


def test_run_watchdog_does_not_disable_during_cold_start_before_first_success(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """2B.10.8: the watchdog must NOT call ``disable_system_proxy``
    when the state machine reaches PROXY_DISABLED before any
    successful ``/health`` response has been observed.

    Cold-start race: launchd ``RunAtLoad`` starts the watchdog
    concurrently with the daemon, and on Python 3.14 the daemon takes
    several seconds before ``/health`` answers 200. Without this gate,
    the watchdog's first 5 failed polls would tear down the user's
    system proxy moments after ``halton-meter start``."""
    monkeypatch.setattr(watchdog, "snapshot_interfaces", lambda _port: ["Wi-Fi"])
    # Always unhealthy; daemon never comes up during the test window.
    monkeypatch.setattr(watchdog, "poll_health", lambda _port, timeout=1.0: False)
    monkeypatch.setattr(watchdog.time, "sleep", lambda _s: None)

    disable_calls: list[list[str]] = []
    monkeypatch.setattr(
        watchdog,
        "disable_system_proxy",
        lambda interfaces: disable_calls.append(list(interfaces)),
    )

    rc = watchdog.run_watchdog(8765, max_polls=10)
    assert rc == 0
    # State machine fired PROXY_DISABLED at fail #5 but the gate
    # suppressed the actual disable because no success was ever seen.
    assert disable_calls == [], (
        "watchdog must not disable proxy if it has never seen a healthy "
        "/health response — the daemon may simply still be starting"
    )


def test_run_watchdog_disables_after_first_success_then_failures(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """2B.10.8: once the watchdog has observed at least one successful
    ``/health`` response, the cold-start gate latches open and the
    normal disable-on-threshold behaviour applies for the rest of the
    process lifetime."""
    monkeypatch.setattr(watchdog, "snapshot_interfaces", lambda _port: ["Wi-Fi"])
    # First poll succeeds (daemon is up); subsequent polls all fail
    # (daemon froze after coming up).
    poll_results = iter([True] + [False] * 20)

    def fake_poll(_port: int, timeout: float = 1.0) -> bool:
        return next(poll_results)

    monkeypatch.setattr(watchdog, "poll_health", fake_poll)
    monkeypatch.setattr(watchdog.time, "sleep", lambda _s: None)

    disable_calls: list[list[str]] = []
    monkeypatch.setattr(
        watchdog,
        "disable_system_proxy",
        lambda interfaces: disable_calls.append(list(interfaces)),
    )

    rc = watchdog.run_watchdog(8765, max_polls=10)
    assert rc == 0
    # 1 success (latches gate open) + 5 failures (DEGRADING ->
    # PROXY_DISABLED edge) = exactly one disable, then 4 more failures
    # in PROXY_DISABLED that don't re-disable.
    assert disable_calls == [["Wi-Fi"]], (
        "after first success, watchdog must disable proxy exactly once "
        "on the DEGRADING -> PROXY_DISABLED edge"
    )


def test_run_watchdog_never_disables_when_healthy(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(watchdog, "snapshot_interfaces", lambda _port: ["Wi-Fi"])
    monkeypatch.setattr(watchdog, "poll_health", lambda _port, timeout=1.0: True)
    monkeypatch.setattr(watchdog.time, "sleep", lambda _s: None)

    disable_calls: list[list[str]] = []
    monkeypatch.setattr(
        watchdog,
        "disable_system_proxy",
        lambda interfaces: disable_calls.append(list(interfaces)),
    )

    rc = watchdog.run_watchdog(8765, max_polls=20)
    assert rc == 0
    assert disable_calls == []


# --------------------------------------------------------------------------- #
# poll_once                                                                    #
# --------------------------------------------------------------------------- #


def test_poll_once_returns_zero_when_healthy(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(watchdog, "poll_health", lambda _port, timeout=1.0: True)
    assert watchdog.poll_once(8765) == 0


def test_poll_once_returns_one_when_unhealthy(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(watchdog, "poll_health", lambda _port, timeout=1.0: False)
    assert watchdog.poll_once(8765) == 1


# --------------------------------------------------------------------------- #
# Integration test (hard-skipped: do not touch user's real system proxy)       #
# --------------------------------------------------------------------------- #


@pytest.mark.skipif(
    shutil.which("launchctl") is None,
    reason="launchctl unavailable — integration test only meaningful on macOS",
)
def test_real_launchd_watchdog_smoke_disabled() -> None:
    """Placeholder.

    A real watchdog-vs-frozen-daemon smoke test would need a tmp-path
    plist and a fake ``networksetup`` binary on PATH to avoid touching
    the user's real system proxy. Vikrant's ``feedback_dont_kill_proxy.md``
    auto-memory is explicit that we do not run kill-based or SIGSTOP
    smoke tests against the live daemon from CI; the user-runnable
    ``daemon/scripts/smoke_layer_2.sh`` covers that path manually.
    """
    pytest.skip("integration disabled to honour 'don't kill proxy' auto-memory")


# --------------------------------------------------------------------------- #
# Runtime port resolution (v0.1.13)                                            #
# --------------------------------------------------------------------------- #


def _write_runtime_toml(path: Any, *, edge_port: int, api_port: int) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        "[daemon]\n"
        f"edge_port = {edge_port}\n"
        f"api_port = {api_port}\n"
        "internal_port = 8090\n",
        encoding="utf-8",
    )


def test_resolve_runtime_ports_reads_runtime_toml(
    tmp_path: Any, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Watchdog must pick up the daemon's fallback ports out of
    ``runtime.toml`` rather than reporting hard-coded defaults."""
    rt = tmp_path / "runtime.toml"
    _write_runtime_toml(rt, edge_port=8082, api_port=8766)
    monkeypatch.setattr(watchdog, "load_effective_config", lambda: __import__(
        "halton_meter.port_alloc", fromlist=["load_effective_config"]
    ).load_effective_config(runtime_path=rt))

    api_port, listen_port = watchdog._resolve_runtime_ports(8765, 8081)
    assert (api_port, listen_port) == (8766, 8082)


def test_resolve_runtime_ports_falls_back_when_missing(
    tmp_path: Any, monkeypatch: pytest.MonkeyPatch
) -> None:
    """No runtime.toml → return supplied fallback (defaults), don't raise."""
    missing = tmp_path / "no-such-runtime.toml"
    monkeypatch.setattr(
        watchdog,
        "load_effective_config",
        lambda: __import__(
            "halton_meter.port_alloc", fromlist=["load_effective_config"]
        ).load_effective_config(runtime_path=missing, config_path=tmp_path / "no.toml"),
    )

    api_port, listen_port = watchdog._resolve_runtime_ports(8765, 8081)
    assert (api_port, listen_port) == (8765, 8081)


def test_resolve_runtime_ports_swallows_exceptions(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    def boom() -> Any:
        raise RuntimeError("disk on fire")

    monkeypatch.setattr(watchdog, "load_effective_config", boom)
    # Must return the supplied fallback, never raise.
    assert watchdog._resolve_runtime_ports(8765, 8081) == (8765, 8081)


def test_run_watchdog_picks_up_port_change_mid_run(
    tmp_path: Any, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Per-tick re-read: if runtime.toml changes after the watchdog
    starts, the next tick honours the new ports. Validates the
    'reads the runtime ports file at startup AND on each tick'
    acceptance criterion."""
    rt = tmp_path / "runtime.toml"
    _write_runtime_toml(rt, edge_port=8081, api_port=8765)

    from halton_meter import port_alloc

    monkeypatch.setattr(
        watchdog,
        "load_effective_config",
        lambda: port_alloc.load_effective_config(
            runtime_path=rt, config_path=tmp_path / "no-config.toml"
        ),
    )

    snapshot_calls: list[int] = []

    def fake_snapshot(port: int) -> list[str]:
        snapshot_calls.append(port)
        # Only the original port has interfaces; new port → empty,
        # which forces the loop to exit cleanly.
        return ["Wi-Fi"] if port == 8081 else []

    monkeypatch.setattr(watchdog, "snapshot_interfaces", fake_snapshot)
    monkeypatch.setattr(watchdog, "poll_health", lambda _p, timeout=1.0: True)
    monkeypatch.setattr(watchdog.time, "sleep", lambda _s: None)

    # Rewrite runtime.toml after the first poll by patching poll_health
    # to flip the file as a side-effect on call #2.
    poll_count = {"n": 0}

    def flipping_poll(_port: int, timeout: float = 1.0) -> bool:
        poll_count["n"] += 1
        if poll_count["n"] == 2:
            _write_runtime_toml(rt, edge_port=8082, api_port=8766)
        return True

    monkeypatch.setattr(watchdog, "poll_health", flipping_poll)

    rc = watchdog.run_watchdog(8765, listen_port=8081, max_polls=10)
    assert rc == 0
    # Startup snapshot used 8081; after the file flip, a tick re-snapshots
    # against 8082 (and returns [] → clean exit).
    assert 8081 in snapshot_calls
    assert 8082 in snapshot_calls


def test_main_uses_runtime_toml_for_port_defaults(
    tmp_path: Any, monkeypatch: pytest.MonkeyPatch
) -> None:
    """``main()`` (the launchd entry point) must consult
    ``load_effective_config`` so the runtime.toml fallback ports flow
    through into ``run_watchdog``. Regression for the trial-run noise
    where the watchdog kept logging the defaults."""
    rt = tmp_path / "runtime.toml"
    _write_runtime_toml(rt, edge_port=8082, api_port=8766)

    from halton_meter import port_alloc

    monkeypatch.setattr(
        watchdog,
        "load_effective_config",
        lambda: port_alloc.load_effective_config(
            runtime_path=rt, config_path=tmp_path / "no-config.toml"
        ),
    )
    monkeypatch.setattr(watchdog, "_install_signal_handlers", lambda: None)

    captured: dict[str, int] = {}

    def fake_run(api_port: int, *, listen_port: int | None = None) -> int:
        captured["api_port"] = api_port
        captured["listen_port"] = listen_port if listen_port is not None else -1
        return 0

    monkeypatch.setattr(watchdog, "run_watchdog", fake_run)

    rc = watchdog.main()
    assert rc == 0
    assert captured == {"api_port": 8766, "listen_port": 8082}


# Make BytesIO importable in this module so the fake response object's
# read() shape stays close to urllib.response.addinfourl's contract;
# unused otherwise.
_ = io


# --------------------------------------------------------------------------- #
# v0.1.16 P0.2 — MITM port probe + restart-with-cap                            #
# --------------------------------------------------------------------------- #


def test_probe_mitm_port_returns_true_on_successful_connect(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    class _FakeSock:
        def __enter__(self) -> _FakeSock:
            return self

        def __exit__(self, *_a: Any) -> None:
            return None

    monkeypatch.setattr(
        watchdog.socket, "create_connection", lambda _addr, timeout=0.5: _FakeSock()
    )
    assert watchdog._probe_mitm_port("127.0.0.1", 8090) is True


def test_probe_mitm_port_returns_false_on_connection_refused(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    def raiser(_addr: Any, timeout: float = 0.5) -> Any:
        raise ConnectionRefusedError("nope")

    monkeypatch.setattr(watchdog.socket, "create_connection", raiser)
    assert watchdog._probe_mitm_port("127.0.0.1", 8090) is False


def test_probe_mitm_port_returns_false_on_oserror(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    def raiser(_addr: Any, timeout: float = 0.5) -> Any:
        raise OSError("network unreachable")

    monkeypatch.setattr(watchdog.socket, "create_connection", raiser)
    assert watchdog._probe_mitm_port("127.0.0.1", 8090) is False


def test_probe_mitm_port_returns_false_on_timeout(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    def raiser(_addr: Any, timeout: float = 0.5) -> Any:
        raise TimeoutError("timed out")

    monkeypatch.setattr(watchdog.socket, "create_connection", raiser)
    assert watchdog._probe_mitm_port("127.0.0.1", 8090) is False


def test_probe_mitm_port_does_not_raise_on_unexpected_exception(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    def raiser(_addr: Any, timeout: float = 0.5) -> Any:
        raise RuntimeError("anything else")

    monkeypatch.setattr(watchdog.socket, "create_connection", raiser)
    assert watchdog._probe_mitm_port("127.0.0.1", 8090) is False


def _make_log_capture(
    monkeypatch: pytest.MonkeyPatch,
) -> list[tuple[str, str, dict[str, Any]]]:
    """Capture structlog calls without coupling to its internals.

    Returns a list of ``(level, event, kwargs)`` tuples in call order.
    """
    captured: list[tuple[str, str, dict[str, Any]]] = []

    class _Logger:
        def info(self, event: str, **kw: Any) -> None:
            captured.append(("info", event, kw))

        def warning(self, event: str, **kw: Any) -> None:
            captured.append(("warning", event, kw))

        def error(self, event: str, **kw: Any) -> None:
            captured.append(("error", event, kw))

    monkeypatch.setattr(watchdog, "log", _Logger())
    return captured


def test_run_watchdog_logs_mitm_unhealthy_once_after_three_consecutive_failures(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """3 consecutive MITM probe failures while /health is up → ERROR
    log fires exactly once for the streak (not on every subsequent
    tick)."""
    monkeypatch.setattr(watchdog, "snapshot_interfaces", lambda _p: ["Wi-Fi"])
    monkeypatch.setattr(watchdog, "poll_health", lambda _p, timeout=1.0: True)
    monkeypatch.setattr(watchdog.time, "sleep", lambda _s: None)
    # MITM always fails → unhealthy.
    monkeypatch.setattr(watchdog, "_probe_mitm_port", lambda _h, _p: False)

    kickstart_calls: list[int] = []
    monkeypatch.setattr(
        watchdog,
        "_kickstart_daemon",
        lambda: kickstart_calls.append(1) or True,
    )

    events = _make_log_capture(monkeypatch)

    # 4 polls: ticks 1-3 hit WARN threshold (logged once); tick 4 still
    # below RESTART threshold (5) so no kickstart yet.
    rc = watchdog.run_watchdog(8765, listen_port=8090, max_polls=4)
    assert rc == 0
    unhealthy = [e for e in events if e[1] == "watchdog.mitm_unhealthy"]
    assert len(unhealthy) == 1, (
        f"expected exactly one mitm_unhealthy log, got {len(unhealthy)}: {unhealthy}"
    )
    assert kickstart_calls == [], "should not restart before 5-fail threshold"


def test_run_watchdog_kickstarts_on_five_consecutive_mitm_failures(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(watchdog, "snapshot_interfaces", lambda _p: ["Wi-Fi"])
    monkeypatch.setattr(watchdog, "poll_health", lambda _p, timeout=1.0: True)
    monkeypatch.setattr(watchdog.time, "sleep", lambda _s: None)
    monkeypatch.setattr(watchdog, "_probe_mitm_port", lambda _h, _p: False)

    kickstart_calls: list[int] = []
    monkeypatch.setattr(
        watchdog,
        "_kickstart_daemon",
        lambda: (kickstart_calls.append(1) or True),
    )

    rc = watchdog.run_watchdog(8765, listen_port=8090, max_polls=5)
    assert rc == 0
    assert kickstart_calls == [1], (
        "kickstart must fire exactly once on the 5th consecutive MITM failure"
    )


def test_run_watchdog_respects_restart_cap_per_hour(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """3 restarts within an hour → 4th attempt does NOT call kickstart
    and logs ``watchdog.restart_cap_exceeded``."""
    monkeypatch.setattr(watchdog, "snapshot_interfaces", lambda _p: ["Wi-Fi"])
    monkeypatch.setattr(watchdog, "poll_health", lambda _p, timeout=1.0: True)
    monkeypatch.setattr(watchdog.time, "sleep", lambda _s: None)
    monkeypatch.setattr(watchdog, "_probe_mitm_port", lambda _h, _p: False)
    # Clock barely advances — all restarts fall inside the 1-hour window.
    fake_now = {"t": 1000.0}

    def fake_monotonic() -> float:
        fake_now["t"] += 0.1
        return fake_now["t"]

    monkeypatch.setattr(watchdog.time, "monotonic", fake_monotonic)

    kickstart_calls: list[int] = []
    monkeypatch.setattr(
        watchdog,
        "_kickstart_daemon",
        lambda: (kickstart_calls.append(1) or True),
    )
    events = _make_log_capture(monkeypatch)

    # MITM fail counter resets after each restart attempt, so we need
    # 5 failed ticks per restart attempt. 4 attempts x 5 ticks = 20.
    rc = watchdog.run_watchdog(8765, listen_port=8090, max_polls=20)
    assert rc == 0
    assert len(kickstart_calls) == 3, (
        f"cap is 3 restarts/hour; got {len(kickstart_calls)} kickstarts"
    )
    cap_logs = [e for e in events if e[1] == "watchdog.restart_cap_exceeded"]
    assert len(cap_logs) >= 1, "must log restart_cap_exceeded when cap reached"


def test_run_watchdog_resets_consecutive_counter_on_successful_probe(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """A single successful MITM probe between failures resets the
    consecutive-failure counter so the WARN/RESTART thresholds restart
    from zero."""
    monkeypatch.setattr(watchdog, "snapshot_interfaces", lambda _p: ["Wi-Fi"])
    monkeypatch.setattr(watchdog, "poll_health", lambda _p, timeout=1.0: True)
    monkeypatch.setattr(watchdog.time, "sleep", lambda _s: None)

    # Pattern: F F F F S F F F F  — never 5 consecutive failures.
    seq = iter([False, False, False, False, True, False, False, False, False])
    monkeypatch.setattr(watchdog, "_probe_mitm_port", lambda _h, _p: next(seq))

    kickstart_calls: list[int] = []
    monkeypatch.setattr(
        watchdog,
        "_kickstart_daemon",
        lambda: (kickstart_calls.append(1) or True),
    )

    rc = watchdog.run_watchdog(8765, listen_port=8090, max_polls=9)
    assert rc == 0
    assert kickstart_calls == [], (
        "successful probe must reset the consecutive-fail counter"
    )


# --------------------------------------------------------------------------- #
# v0.1.19.dev1 (Phase 2 Bug B): /health-failure-driven kickstart              #
# --------------------------------------------------------------------------- #


def test_run_watchdog_kickstarts_on_sustained_health_failure(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """First tick green, then sustained red /health → kickstart fires
    exactly once at HEALTH_FAIL_THRESHOLD_RESTART (8 ticks)."""
    monkeypatch.setattr(watchdog, "snapshot_interfaces", lambda _p: ["Wi-Fi"])
    monkeypatch.setattr(watchdog.time, "sleep", lambda _s: None)
    # MITM port is fine — isolate the new branch from the existing one.
    monkeypatch.setattr(watchdog, "_probe_mitm_port", lambda _h, _p: True)

    health_calls = {"n": 0}

    def health(_p: int, timeout: float = 1.0) -> bool:
        health_calls["n"] += 1
        # Tick 1 succeeds (proves daemon was alive once); ticks 2+ fail.
        return health_calls["n"] == 1

    monkeypatch.setattr(watchdog, "poll_health", health)

    kickstart_calls: list[int] = []
    monkeypatch.setattr(
        watchdog,
        "_kickstart_daemon",
        lambda: (kickstart_calls.append(1) or True),
    )

    # 9 ticks: 1 green, 8 red → one kickstart at the 9th tick (8 fails).
    rc = watchdog.run_watchdog(8765, listen_port=8090, max_polls=9)
    assert rc == 0
    assert kickstart_calls == [1], (
        "kickstart must fire exactly once after 8 consecutive /health "
        "failures following at least one success"
    )


def test_run_watchdog_does_not_health_kickstart_during_cold_start(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """If /health has NEVER returned green, the watchdog must not
    kickstart on /health failure — that's the cold-start race we
    explicitly tolerate."""
    monkeypatch.setattr(watchdog, "snapshot_interfaces", lambda _p: ["Wi-Fi"])
    monkeypatch.setattr(watchdog.time, "sleep", lambda _s: None)
    monkeypatch.setattr(watchdog, "_probe_mitm_port", lambda _h, _p: True)
    # /health never returns green.
    monkeypatch.setattr(watchdog, "poll_health", lambda _p, timeout=1.0: False)

    kickstart_calls: list[int] = []
    monkeypatch.setattr(
        watchdog,
        "_kickstart_daemon",
        lambda: (kickstart_calls.append(1) or True),
    )

    rc = watchdog.run_watchdog(8765, listen_port=8090, max_polls=15)
    assert rc == 0
    assert kickstart_calls == [], (
        "no kickstart during cold-start (no successful /health observed yet)"
    )


def test_run_watchdog_health_kickstart_respects_restart_cap(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """The health-restart branch must respect the same per-hour cap."""
    monkeypatch.setattr(watchdog, "snapshot_interfaces", lambda _p: ["Wi-Fi"])
    monkeypatch.setattr(watchdog.time, "sleep", lambda _s: None)
    monkeypatch.setattr(watchdog, "_probe_mitm_port", lambda _h, _p: True)

    fake_now = {"t": 1000.0}

    def fake_monotonic() -> float:
        fake_now["t"] += 0.1
        return fake_now["t"]

    monkeypatch.setattr(watchdog.time, "monotonic", fake_monotonic)

    health_calls = {"n": 0}

    def health(_p: int, timeout: float = 1.0) -> bool:
        health_calls["n"] += 1
        return health_calls["n"] == 1

    monkeypatch.setattr(watchdog, "poll_health", health)

    kickstart_calls: list[int] = []
    monkeypatch.setattr(
        watchdog,
        "_kickstart_daemon",
        lambda: (kickstart_calls.append(1) or True),
    )
    events = _make_log_capture(monkeypatch)

    # 1 green + (8-fail-streak then reset) x 4 = 1 + 32 ticks, but we cap
    # at 3 restarts.
    rc = watchdog.run_watchdog(8765, listen_port=8090, max_polls=33)
    assert rc == 0
    assert len(kickstart_calls) == 3, (
        f"cap is 3 health restarts/hour; got {len(kickstart_calls)}"
    )
    cap_logs = [e for e in events if e[1] == "watchdog.health_restart_cap_exceeded"]
    assert len(cap_logs) >= 1
