"""Tests for ``halton_meter.lifecycle`` (Phase 2B.8).

All OS-level subprocess calls are mocked. No real ``launchctl``,
``lsof``, ``networksetup``, ``security``, ``systemctl``, ``ps``, or
``os.kill`` invocations against live processes.
"""

from __future__ import annotations

import json
import subprocess
from pathlib import Path
from typing import Any

import pytest
from click.testing import CliRunner

from halton_meter import lifecycle, system_proxy
from halton_meter.cli import cli
from halton_meter.config import HaltonConfig

# --------------------------------------------------------------------------- #
# Helpers / fixtures                                                          #
# --------------------------------------------------------------------------- #


def _completed(rc: int = 0, stdout: str = "", stderr: str = "") -> subprocess.CompletedProcess:
    return subprocess.CompletedProcess(
        args=["mock"], returncode=rc, stdout=stdout, stderr=stderr
    )


def _make_cfg(tmp_path: Path) -> HaltonConfig:
    return HaltonConfig.model_validate(
        {
            "daemon": {
                "listen_host": "127.0.0.1",
                "listen_port": 9080,
                "api_host": "127.0.0.1",
                "api_port": 8765,
                "log_path": str(tmp_path / "daemon.log"),
            },
            "storage": {"db_path": str(tmp_path / "db.sqlite")},
        }
    )


@pytest.fixture(autouse=True)
def _reset_macos_interfaces_cache() -> Any:
    """Reset the per-process enumeration cache between tests so cache
    presets in one test do not leak into the next (2B.7.2 / 2B.7.3)."""
    system_proxy._MACOS_INTERFACES_CACHE = None
    yield
    system_proxy._MACOS_INTERFACES_CACHE = None


@pytest.fixture
def macos(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(lifecycle.sys, "platform", "darwin")
    # Preset the dynamic-enumeration cache (2B.7.2) so existing
    # stop/networksetup-call-count tests exercise the 4-interface
    # fallback deterministically without an extra
    # ``networksetup -listallnetworkservices`` call inflating counts.
    monkeypatch.setattr(
        system_proxy, "_MACOS_INTERFACES_CACHE", system_proxy._MACOS_INTERFACE_FALLBACK
    )


@pytest.fixture
def installed_plists(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> tuple[Path, Path]:
    daemon_plist = tmp_path / "com.haltonlabs.meter.plist"
    watchdog_plist = tmp_path / "com.haltonlabs.meter.watchdog.plist"
    edge_plist = tmp_path / "com.haltonlabs.meter.edge.plist"
    daemon_plist.write_text("<plist/>")
    watchdog_plist.write_text("<plist/>")
    edge_plist.write_text("<plist/>")
    monkeypatch.setattr(
        lifecycle, "_macos_paths", lambda: (daemon_plist, tmp_path, tmp_path)
    )
    monkeypatch.setattr(lifecycle, "_macos_watchdog_plist_path", lambda: watchdog_plist)
    monkeypatch.setattr(lifecycle, "_macos_edge_plist_path", lambda: edge_plist)
    return daemon_plist, watchdog_plist


@pytest.fixture
def absent_plists(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    daemon_plist = tmp_path / "missing.plist"
    watchdog_plist = tmp_path / "missing-watchdog.plist"
    edge_plist = tmp_path / "missing-edge.plist"
    monkeypatch.setattr(
        lifecycle, "_macos_paths", lambda: (daemon_plist, tmp_path, tmp_path)
    )
    monkeypatch.setattr(lifecycle, "_macos_watchdog_plist_path", lambda: watchdog_plist)
    monkeypatch.setattr(lifecycle, "_macos_edge_plist_path", lambda: edge_plist)


@pytest.fixture
def cfg_loaded(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> HaltonConfig:
    cfg = _make_cfg(tmp_path)
    monkeypatch.setattr(lifecycle, "load_config", lambda: cfg)
    return cfg


# --------------------------------------------------------------------------- #
# start: macOS                                                                #
# --------------------------------------------------------------------------- #


def test_start_macos_not_installed_returns_error(
    macos: None, absent_plists: None, cfg_loaded: HaltonConfig
) -> None:
    rc = lifecycle.start()
    assert rc == 1


def test_start_macos_port_held_by_orphan_returns_error(
    macos: None,
    installed_plists: tuple[Path, Path],
    cfg_loaded: HaltonConfig,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    # No daemon running.
    monkeypatch.setattr(lifecycle, "_detect_live_daemon", lambda: False)
    monkeypatch.setattr(lifecycle, "_detect_live_watchdog", lambda: False)
    # v0.1.21.4: short-circuit gates on /health, not on
    # _detect_live_daemon. Force /health unhealthy to fall through to
    # the port-conflict check.
    monkeypatch.setattr(
        lifecycle, "_poll_health_with_latency", lambda port, timeout=1.0: (False, None)
    )
    # Both labels are unknown to launchctl → no managed PIDs.
    monkeypatch.setattr(lifecycle, "_launchctl_label_pid", lambda label: None)
    # Port 8765 held by an external PID 99999.
    monkeypatch.setattr(
        lifecycle,
        "_lsof_pids_on_port",
        lambda port: [99999] if port == 8765 else [],
    )
    monkeypatch.setattr(lifecycle, "_process_name", lambda pid: "ghost")

    rc = lifecycle.start()
    assert rc == 1


def test_start_macos_already_running_is_idempotent(
    macos: None,
    installed_plists: tuple[Path, Path],
    cfg_loaded: HaltonConfig,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    # v0.1.21.4: short-circuit on /health alone. _detect_live_daemon
    # / _detect_live_watchdog no longer gate the short-circuit.
    monkeypatch.setattr(
        lifecycle, "_poll_health_with_latency", lambda port, timeout=1.0: (True, 4.5)
    )
    monkeypatch.setattr(
        lifecycle,
        "_launchctl_label_pid",
        lambda label: 81234 if label == lifecycle._LABEL else 81235,
    )
    monkeypatch.setattr(
        lifecycle, "_launchctl_kickstart",
        lambda label, kill_existing=True: (0, ""),
    )

    rc = lifecycle.start()
    assert rc == 0


def test_start_macos_full_load_succeeds(
    macos: None,
    installed_plists: tuple[Path, Path],
    cfg_loaded: HaltonConfig,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    # Initially nothing running, no port conflicts.
    monkeypatch.setattr(lifecycle, "_detect_live_daemon", lambda: False)
    monkeypatch.setattr(lifecycle, "_detect_live_watchdog", lambda: False)
    # v0.1.21.4: short-circuit checks /health first; force unhealthy
    # so we fall through to the full bootstrap+kickstart path.
    monkeypatch.setattr(
        lifecycle, "_poll_health_with_latency", lambda port, timeout=1.0: (False, None)
    )
    monkeypatch.setattr(lifecycle, "_lsof_pids_on_port", lambda port: [])

    # After load, launchctl reports live PIDs.
    pid_state = {"daemon": 4242, "watchdog": 4243}

    def fake_pid(label: str) -> int | None:
        if label == lifecycle._LABEL:
            return pid_state["daemon"]
        if label == lifecycle._WATCHDOG_LABEL:
            return pid_state["watchdog"]
        return None

    monkeypatch.setattr(lifecycle, "_launchctl_label_pid", fake_pid)
    monkeypatch.setattr(lifecycle, "_our_managed_pids", lambda: set())

    # Mock launchctl unload + load -w.
    run_calls: list[list[str]] = []

    def fake_run(argv: list[str], **_kw: Any) -> subprocess.CompletedProcess:
        run_calls.append(argv)
        return _completed(0)

    monkeypatch.setattr(lifecycle.subprocess, "run", fake_run)

    # /health comes up immediately. v0.1.21 swapped _wait_for_health
    # for _start_probe_health (3-tick poll, 8s ceiling, returns elapsed
    # ms in addition to per-poll latency).
    monkeypatch.setattr(
        lifecycle, "_start_probe_health",
        lambda port: (True, 3.2, 5.0),
    )

    # System-proxy + capture.
    monkeypatch.setattr(
        lifecycle, "_system_proxy_state",
        lambda host, port: ("enabled", "127.0.0.1:9080 on Wi-Fi"),
    )
    monkeypatch.setattr(
        lifecycle, "_latest_capture",
        lambda db_path: lifecycle._LatestCapture(found=False, db_missing=True),
    )

    rc = lifecycle.start()
    assert rc == 0
    # v0.1.21.3: bootout-then-bootstrap-then-kickstart for each label.
    # ``_launchctl_reload`` always boots-out first to clear any stale
    # registration (bootstrap returns rc=5 EIO on already-loaded), then
    # bootstraps. ``kickstart -k`` forces an immediate start regardless
    # of ``RunAtLoad=False``. Two labels: daemon + watchdog.
    bootout_calls = [argv for argv in run_calls if "bootout" in argv]
    bootstrap_calls = [argv for argv in run_calls if "bootstrap" in argv]
    kickstart_calls = [argv for argv in run_calls if "kickstart" in argv]
    assert len(bootout_calls) == 2
    assert len(bootstrap_calls) == 2
    assert len(kickstart_calls) == 2
    # Order per label: bootout precedes bootstrap.
    first_bootout = run_calls.index(bootout_calls[0])
    first_bootstrap = run_calls.index(bootstrap_calls[0])
    assert first_bootout < first_bootstrap


def test_start_macos_health_probe_uses_runtime_toml_port(
    macos: None,
    installed_plists: tuple[Path, Path],
    cfg_loaded: HaltonConfig,
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    """Regression for the v0.1.14 bug: when the daemon falls back from
    the default 8765 to 8766 (because 8765 was busy at bind time) and
    persists the new tuple to ``runtime.toml``, the post-load health
    probe must consult the effective ports overlay — not the stale
    ``cfg`` captured before ``launchctl load`` ran. Mirrors the
    watchdog fix in commit 5c7d244.
    """
    monkeypatch.setattr(lifecycle, "_detect_live_daemon", lambda: False)
    monkeypatch.setattr(lifecycle, "_detect_live_watchdog", lambda: False)
    # v0.1.21.4: force short-circuit /health to unhealthy (this test
    # wants the full bootstrap path).
    monkeypatch.setattr(
        lifecycle, "_poll_health_with_latency", lambda port, timeout=1.0: (False, None)
    )
    monkeypatch.setattr(lifecycle, "_lsof_pids_on_port", lambda port: [])
    monkeypatch.setattr(lifecycle, "_launchctl_label_pid", lambda label: 4242)
    monkeypatch.setattr(lifecycle, "_our_managed_pids", lambda: set())
    monkeypatch.setattr(lifecycle.subprocess, "run", lambda *a, **kw: _completed(0))

    # Two cfg loads happen inside `_start_macos`:
    #   1. before launchctl load — sees the bare config defaults.
    #   2. after launchctl load — must see the runtime.toml fallback
    #      that the daemon's startup persisted.
    # We swap the patched `load_effective_config` between calls.
    rt = tmp_path / "runtime.toml"
    rt.write_text(
        "[daemon]\n"
        "edge_port = 8082\n"
        "internal_port = 8090\n"
        "api_port = 8766\n",
        encoding="utf-8",
    )
    from halton_meter import port_alloc

    call_count = {"n": 0}

    def fake_loader() -> HaltonConfig:
        call_count["n"] += 1
        if call_count["n"] == 1:
            # Pre-load: bare defaults (no runtime.toml exists yet).
            return port_alloc.load_effective_config(
                runtime_path=tmp_path / "missing-runtime.toml",
                config_path=tmp_path / "missing-config.toml",
            )
        # Post-load: daemon has just written runtime.toml with 8766.
        return port_alloc.load_effective_config(
            runtime_path=rt, config_path=tmp_path / "missing-config.toml"
        )

    monkeypatch.setattr(lifecycle, "load_effective_config", fake_loader)

    # Capture which port the health probe actually targeted.
    probed_ports: list[int] = []

    def fake_health(port: int) -> tuple[bool, float, float]:
        probed_ports.append(port)
        return (True, 1.0, 1.5)

    # v0.1.21: probe entry point is _start_probe_health (was
    # _wait_for_health pre-v0.1.21).
    monkeypatch.setattr(lifecycle, "_start_probe_health", fake_health)
    monkeypatch.setattr(
        lifecycle,
        "_system_proxy_state",
        lambda host, port: ("enabled", "127.0.0.1:8082 on Wi-Fi"),
    )
    monkeypatch.setattr(
        lifecycle,
        "_latest_capture",
        lambda db_path: lifecycle._LatestCapture(found=False, db_missing=True),
    )

    rc = lifecycle.start()
    assert rc == 0
    assert probed_ports == [8766], (
        "post-load health probe must read api_port from runtime.toml "
        "(8766), not the stale pre-load default (8765)"
    )


def test_start_macos_health_never_comes_up_returns_error(
    macos: None,
    installed_plists: tuple[Path, Path],
    cfg_loaded: HaltonConfig,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(lifecycle, "_detect_live_daemon", lambda: False)
    monkeypatch.setattr(lifecycle, "_detect_live_watchdog", lambda: False)
    # v0.1.21.4: short-circuit /health unhealthy → fall through to
    # the full path; the post-load probe remains the failure surface.
    monkeypatch.setattr(
        lifecycle, "_poll_health_with_latency", lambda port, timeout=1.0: (False, None)
    )
    monkeypatch.setattr(lifecycle, "_lsof_pids_on_port", lambda port: [])
    monkeypatch.setattr(lifecycle, "_launchctl_label_pid", lambda label: None)
    monkeypatch.setattr(lifecycle, "_our_managed_pids", lambda: set())
    monkeypatch.setattr(lifecycle.subprocess, "run", lambda *a, **kw: _completed(0))
    monkeypatch.setattr(
        lifecycle, "_start_probe_health",
        lambda port: (False, None, 8000.0),
    )

    err_log_called: list[int] = []
    monkeypatch.setattr(
        lifecycle, "_print_err_log_tail", lambda console, lines=20: err_log_called.append(1)
    )

    rc = lifecycle.start()
    assert rc == 1
    assert err_log_called == [1]


# --------------------------------------------------------------------------- #
# stop: macOS                                                                 #
# --------------------------------------------------------------------------- #


def test_stop_macos_not_installed_is_idempotent(
    macos: None,
    absent_plists: None,
    cfg_loaded: HaltonConfig,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Even with no plists installed, `stop` resets the system proxy.

    A user who runs `stop` after a hard crash that left the proxy stuck
    wants the proxy off regardless of plist state — same recovery
    posture as `uninstall`.
    """
    run_calls: list[list[str]] = []

    def fake_run(argv: list[str], **_kw: Any) -> subprocess.CompletedProcess:
        run_calls.append(argv)
        return _completed(0)

    monkeypatch.setattr(lifecycle.subprocess, "run", fake_run)
    monkeypatch.setattr(lifecycle, "_lsof_pids_on_port", lambda port: [])
    monkeypatch.setattr(lifecycle.time, "sleep", lambda _s: None)

    rc = lifecycle.stop()
    assert rc == 0
    networksetup_calls = [argv for argv in run_calls if argv and argv[0] == "networksetup"]
    # 4 fallback interfaces x (secure, unsecure) variants → 8 calls.
    assert len(networksetup_calls) == 8


def test_stop_macos_unloads_both_plists(
    macos: None,
    installed_plists: tuple[Path, Path],
    cfg_loaded: HaltonConfig,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    run_calls: list[list[str]] = []

    def fake_run(argv: list[str], **_kw: Any) -> subprocess.CompletedProcess:
        run_calls.append(argv)
        return _completed(0)

    monkeypatch.setattr(lifecycle.subprocess, "run", fake_run)
    monkeypatch.setattr(lifecycle, "_lsof_pids_on_port", lambda port: [])
    monkeypatch.setattr(lifecycle.time, "sleep", lambda _s: None)

    rc = lifecycle.stop()
    assert rc == 0
    # v0.1.21.2: modern ``launchctl bootout`` replaces legacy ``unload``.
    bootout_argvs = [argv for argv in run_calls if "bootout" in argv]
    assert len(bootout_argvs) == 2


def test_stop_macos_kills_orphan_port_holders(
    macos: None,
    installed_plists: tuple[Path, Path],
    cfg_loaded: HaltonConfig,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(lifecycle.subprocess, "run", lambda *a, **kw: _completed(0))
    monkeypatch.setattr(lifecycle.time, "sleep", lambda _s: None)
    # Port 8765 held by 7777 even after unload.
    seen: dict[int, int] = {8765: 7777}
    monkeypatch.setattr(
        lifecycle, "_lsof_pids_on_port", lambda port: [seen[port]] if port in seen else []
    )

    kills: list[tuple[int, int]] = []

    def fake_kill(pid: int, sig: int) -> None:
        kills.append((pid, sig))
        # First SIGTERM: still alive; signal-0 probe also must succeed.
        # On SIGKILL or after timeout, simulate process gone.
        if sig == 0:
            # liveness probe: process still alive within the wait loop.
            return
        if sig == lifecycle._signal.SIGKILL:
            return

    monkeypatch.setattr(lifecycle.os, "kill", fake_kill)
    # Skip the wait loop.
    times = iter([0.0, 100.0])
    monkeypatch.setattr(lifecycle.time, "monotonic", lambda: next(times, 100.0))

    rc = lifecycle.stop()
    assert rc == 0
    # SIGTERM to 7777 then SIGKILL escalation.
    sent = {(pid, sig) for pid, sig in kills if sig != 0}
    assert (7777, lifecycle._signal.SIGTERM) in sent


def test_stop_macos_resets_system_proxy_after_unload(
    macos: None,
    installed_plists: tuple[Path, Path],
    cfg_loaded: HaltonConfig,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """`stop` must reset the system proxy, and only after unloading the plists.

    Inverted from the original 2B.8 contract — leaving the proxy
    pointed at a now-dead listener breaks every HTTPS-via-system-proxy
    client on the machine.
    """
    run_calls: list[list[str]] = []

    def fake_run(argv: list[str], **_kw: Any) -> subprocess.CompletedProcess:
        run_calls.append(list(argv))
        return _completed(0)

    monkeypatch.setattr(lifecycle.subprocess, "run", fake_run)
    monkeypatch.setattr(lifecycle, "_lsof_pids_on_port", lambda port: [])
    monkeypatch.setattr(lifecycle.time, "sleep", lambda _s: None)

    rc = lifecycle.stop()
    assert rc == 0

    # Networksetup must run for every fallback interface, both proxy variants, all `off`.
    networksetup_calls = [argv for argv in run_calls if argv and argv[0] == "networksetup"]
    # 4 fallback interfaces x 2 variants = 8.
    assert len(networksetup_calls) == 8
    expected_pairs = {
        (iface, variant)
        for iface in system_proxy._MACOS_INTERFACE_FALLBACK
        for variant in ("-setsecurewebproxystate", "-setwebproxystate")
    }
    seen_pairs = {(argv[2], argv[1]) for argv in networksetup_calls}
    assert seen_pairs == expected_pairs
    for argv in networksetup_calls:
        assert argv[3] == "off"

    # Ordering: every networksetup call must come AFTER the last
    # launchctl bootout, so the daemon is dead before the proxy goes off
    # (closes the brief window where new traffic would hit a dying listener).
    last_unload_idx = max(
        i
        for i, argv in enumerate(run_calls)
        if argv and argv[0] == "launchctl" and "bootout" in argv
    )
    first_networksetup_idx = min(
        i for i, argv in enumerate(run_calls) if argv and argv[0] == "networksetup"
    )
    assert first_networksetup_idx > last_unload_idx


def test_stop_macos_preserves_sentinel_file(
    macos: None,
    installed_plists: tuple[Path, Path],
    cfg_loaded: HaltonConfig,
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    """`stop` must NOT delete the proxy-managed sentinel — that's `uninstall`'s job.

    Preserving it means the daemon's Option-1 startup re-enable will
    fire on the next `halton-meter start`.
    """
    sentinel = tmp_path / "proxy-managed"
    sentinel.touch()

    real_unlink = Path.unlink
    unlinked: list[str] = []

    def tracking_unlink(self: Path, *args: Any, **kwargs: Any) -> None:
        unlinked.append(str(self))
        real_unlink(self, *args, **kwargs)

    monkeypatch.setattr(Path, "unlink", tracking_unlink)
    monkeypatch.setattr(lifecycle.subprocess, "run", lambda *a, **kw: _completed(0))
    monkeypatch.setattr(lifecycle, "_lsof_pids_on_port", lambda port: [])
    monkeypatch.setattr(lifecycle.time, "sleep", lambda _s: None)

    rc = lifecycle.stop()
    assert rc == 0
    assert sentinel.exists()
    assert str(sentinel) not in unlinked


def test_stop_macos_proxy_reset_runs_even_when_unload_fails(
    macos: None,
    installed_plists: tuple[Path, Path],
    cfg_loaded: HaltonConfig,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """If `launchctl unload` fails, system-proxy reset must still run.

    Same best-effort recovery posture as `uninstall` — the proxy reset
    is the load-bearing line, never gated on prior step success.
    """
    run_calls: list[list[str]] = []

    def fake_run(argv: list[str], **_kw: Any) -> subprocess.CompletedProcess:
        run_calls.append(list(argv))
        if argv and argv[0] == "launchctl" and "unload" in argv:
            return _completed(1, stderr="launchctl: Could not unload service")
        return _completed(0)

    monkeypatch.setattr(lifecycle.subprocess, "run", fake_run)
    monkeypatch.setattr(lifecycle, "_lsof_pids_on_port", lambda port: [])
    monkeypatch.setattr(lifecycle.time, "sleep", lambda _s: None)

    rc = lifecycle.stop()
    assert rc == 0
    networksetup_calls = [argv for argv in run_calls if argv and argv[0] == "networksetup"]
    # 4 fallback interfaces x 2 variants = 8 calls.
    assert len(networksetup_calls) == 8


def test_stop_macos_resets_proxy_on_vikrants_mac_shape(
    macos: None,
    installed_plists: tuple[Path, Path],
    cfg_loaded: HaltonConfig,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Regression for 2B.7.3: `stop` on a Mac whose enumerated services
    are Wi-Fi / Thunderbolt Bridge / iPhone USB (Vikrant's MacBook) must
    reset the proxy on those three interfaces and MUST NOT call
    networksetup against a non-existent ``Ethernet`` service."""
    # Override the FALLBACK preset baked into the `macos` fixture.
    monkeypatch.setattr(
        system_proxy,
        "_MACOS_INTERFACES_CACHE",
        ("Wi-Fi", "Thunderbolt Bridge", "iPhone USB"),
    )
    run_calls: list[list[str]] = []

    def fake_run(argv: list[str], **_kw: Any) -> subprocess.CompletedProcess:
        run_calls.append(list(argv))
        return _completed(0)

    monkeypatch.setattr(lifecycle.subprocess, "run", fake_run)
    monkeypatch.setattr(lifecycle, "_lsof_pids_on_port", lambda port: [])
    monkeypatch.setattr(lifecycle.time, "sleep", lambda _s: None)

    rc = lifecycle.stop()
    assert rc == 0

    networksetup_calls = [argv for argv in run_calls if argv and argv[0] == "networksetup"]
    # 3 interfaces x 2 variants = 6.
    assert len(networksetup_calls) == 6
    seen_ifaces = {argv[2] for argv in networksetup_calls}
    assert seen_ifaces == {"Wi-Fi", "Thunderbolt Bridge", "iPhone USB"}
    assert "Ethernet" not in seen_ifaces


def test_stop_macos_no_networksetup_calls_when_enum_empty(
    macos: None,
    installed_plists: tuple[Path, Path],
    cfg_loaded: HaltonConfig,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Regression for 2B.7.3: when dynamic enumeration yields an empty
    tuple, `stop` must not shell out to networksetup at all — graceful
    degradation rather than a flurry of bad-argument failures."""
    monkeypatch.setattr(system_proxy, "_MACOS_INTERFACES_CACHE", ())
    run_calls: list[list[str]] = []

    def fake_run(argv: list[str], **_kw: Any) -> subprocess.CompletedProcess:
        run_calls.append(list(argv))
        return _completed(0)

    monkeypatch.setattr(lifecycle.subprocess, "run", fake_run)
    monkeypatch.setattr(lifecycle, "_lsof_pids_on_port", lambda port: [])
    monkeypatch.setattr(lifecycle.time, "sleep", lambda _s: None)

    rc = lifecycle.stop()
    assert rc == 0

    networksetup_calls = [argv for argv in run_calls if argv and argv[0] == "networksetup"]
    assert networksetup_calls == []


# --------------------------------------------------------------------------- #
# status: macOS                                                               #
# --------------------------------------------------------------------------- #


@pytest.fixture
def status_macos_healthy(
    macos: None,
    installed_plists: tuple[Path, Path],
    cfg_loaded: HaltonConfig,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(
        lifecycle, "_launchctl_label_pid",
        lambda label: 81234 if label == lifecycle._LABEL else 81235,
    )
    monkeypatch.setattr(lifecycle, "_launchctl_label_known", lambda label: True)
    monkeypatch.setattr(
        lifecycle, "_poll_health_with_latency",
        lambda port, timeout=1.0: (True, 3.0),
    )
    # v0.1.16 Q4.3: status now probes the MITM listener via TCP. Stub
    # to "open" so the healthy fixture stays healthy without binding a
    # real socket on :8090.
    monkeypatch.setattr(
        lifecycle, "_probe_mitm_listener",
        lambda host, port, timeout=0.5: True,
    )
    monkeypatch.setattr(
        lifecycle, "_system_proxy_state",
        lambda host, port: ("enabled", "127.0.0.1:9080 on Wi-Fi"),
    )
    monkeypatch.setattr(lifecycle, "_is_cert_trusted", lambda: True)
    # Sentinel present.
    sentinel = Path("/tmp/halton-meter-test-sentinel-status")
    sentinel.touch()
    monkeypatch.setattr(lifecycle, "_proxy_managed_sentinel_path", lambda: sentinel)
    monkeypatch.setattr(
        lifecycle, "_latest_capture",
        lambda db_path: lifecycle._LatestCapture(
            found=True, db_missing=False, timestamp_iso="2026-04-29T12:00:00Z",
            seconds_ago=25.0, model="claude-opus-4-7", project="halton-meter",
            cost_usd_minor_units=8790, captured_last_hour=12, captured_last_day=4208,
        ),
    )


def test_status_macos_healthy_returns_zero(status_macos_healthy: None) -> None:
    rc = lifecycle.status()
    assert rc == 0


def test_status_macos_edge_row_present_when_healthy(
    status_macos_healthy: None, capsys: pytest.CaptureFixture[str]
) -> None:
    """2C.2 (v0.1.6): the status table includes an explicit Edge row
    showing the user-facing port. Without this row, a stopped/dead
    edge would be invisible until apps started failing."""
    lifecycle.status()
    out = capsys.readouterr().out
    assert "Edge" in out
    assert ":8081" in out  # default edge_port

    # The Daemon row also surfaces internal_port now (was only api_port).
    assert "internal=:8090" in out


def test_status_macos_edge_row_shows_chain_target_ok(
    status_macos_healthy: None,
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
) -> None:
    """v0.1.7 Gap 0: when the edge sidecar's chain_port matches the
    cfg.daemon.internal_port, the row carries `chain :PORT ✓`."""
    from halton_meter import port_alloc as _port_alloc

    monkeypatch.setattr(
        _port_alloc,
        "read_edge_state_toml",
        lambda *a, **kw: {"edge_port": 8081, "chain_port": 8090, "pid": 81235},
    )
    rc = lifecycle.status()
    out = capsys.readouterr().out
    assert rc == 0
    assert "chain :8090" in out
    assert "✓" in out


def test_status_macos_edge_row_marks_stale_chain(
    status_macos_healthy: None,
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
) -> None:
    """v0.1.7 Gap 0: when the edge's bound chain_port differs from the
    daemon's actual internal_port, the row says STALE and status returns
    non-zero. Pre-fix this state was completely invisible."""
    from halton_meter import port_alloc as _port_alloc

    monkeypatch.setattr(
        _port_alloc,
        "read_edge_state_toml",
        lambda *a, **kw: {"edge_port": 8081, "chain_port": 8091, "pid": 81235},
    )
    rc = lifecycle.status()
    out = capsys.readouterr().out
    assert rc != 0  # stale chain forces non-healthy
    assert "chain :8091" in out
    assert "✗" in out
    assert "stale chain" in out


def test_status_macos_edge_not_installed_marks_unhealthy(
    macos: None,
    cfg_loaded: HaltonConfig,
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    """When the edge plist is missing the Edge row reports not-installed
    and status returns non-zero — apps would fail with ConnectionRefused."""
    daemon_plist = tmp_path / "com.haltonlabs.meter.plist"
    watchdog_plist = tmp_path / "com.haltonlabs.meter.watchdog.plist"
    edge_plist = tmp_path / "missing-edge.plist"
    daemon_plist.write_text("<plist/>")
    watchdog_plist.write_text("<plist/>")
    monkeypatch.setattr(
        lifecycle, "_macos_paths", lambda: (daemon_plist, tmp_path, tmp_path)
    )
    monkeypatch.setattr(lifecycle, "_macos_watchdog_plist_path", lambda: watchdog_plist)
    monkeypatch.setattr(lifecycle, "_macos_edge_plist_path", lambda: edge_plist)
    monkeypatch.setattr(lifecycle, "_launchctl_label_pid", lambda label: 81234)
    monkeypatch.setattr(lifecycle, "_launchctl_label_known", lambda label: True)
    monkeypatch.setattr(
        lifecycle, "_poll_health_with_latency",
        lambda port, timeout=1.0: (True, 3.0),
    )
    monkeypatch.setattr(
        lifecycle, "_system_proxy_state", lambda host, port: ("enabled", "ok"),
    )
    monkeypatch.setattr(lifecycle, "_is_cert_trusted", lambda: True)
    monkeypatch.setattr(lifecycle, "_proxy_managed_sentinel_path", lambda: Path("/nope"))
    monkeypatch.setattr(
        lifecycle, "_latest_capture",
        lambda db_path: lifecycle._LatestCapture(found=False, db_missing=False),
    )

    rc = lifecycle.status()
    assert rc == 1


def test_stop_macos_explains_apps_still_work_via_edge(
    macos: None,
    installed_plists: tuple[Path, Path],
    cfg_loaded: HaltonConfig,
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
) -> None:
    """2C.2 (v0.1.6): stop output makes the new behaviour explicit —
    apps continue working in passthrough via the still-running edge
    proxy. Stop never restarts apps; the edge is the reason it doesn't
    have to."""
    monkeypatch.setattr(lifecycle.subprocess, "run", lambda *a, **kw: _completed(0))
    monkeypatch.setattr(lifecycle, "_lsof_pids_on_port", lambda port: [])
    monkeypatch.setattr(lifecycle.time, "sleep", lambda _s: None)

    rc = lifecycle.stop()
    assert rc == 0
    out = capsys.readouterr().out
    # v0.1.21 reframed copy: lead with "Edge proxy still running" + the
    # un-metered tunnel-through promise; no longer "Apps still work".
    assert "Edge proxy still running" in out
    # Test cfg uses port 9080 — assert the resolved edge_port appears.
    assert f":{cfg_loaded.daemon.edge_port}" in out
    assert "halton-meter start" in out
    assert "un-metered" in out
    assert "Sentinel preserved" in out


def test_status_macos_daemon_loaded_but_unhealthy_returns_one(
    macos: None,
    installed_plists: tuple[Path, Path],
    cfg_loaded: HaltonConfig,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(lifecycle, "_launchctl_label_pid", lambda label: 81234)
    monkeypatch.setattr(lifecycle, "_launchctl_label_known", lambda label: True)
    monkeypatch.setattr(
        lifecycle, "_poll_health_with_latency",
        lambda port, timeout=1.0: (False, None),
    )
    monkeypatch.setattr(
        lifecycle, "_system_proxy_state", lambda host, port: ("enabled", "ok"),
    )
    monkeypatch.setattr(lifecycle, "_is_cert_trusted", lambda: True)
    monkeypatch.setattr(lifecycle, "_proxy_managed_sentinel_path", lambda: Path("/nope"))
    monkeypatch.setattr(
        lifecycle, "_latest_capture",
        lambda db_path: lifecycle._LatestCapture(found=False, db_missing=False),
    )

    rc = lifecycle.status()
    assert rc == 1


def test_status_macos_proxy_disabled_returns_one(
    macos: None,
    installed_plists: tuple[Path, Path],
    cfg_loaded: HaltonConfig,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(lifecycle, "_launchctl_label_pid", lambda label: 1)
    monkeypatch.setattr(lifecycle, "_launchctl_label_known", lambda label: True)
    monkeypatch.setattr(
        lifecycle, "_poll_health_with_latency",
        lambda port, timeout=1.0: (True, 1.0),
    )
    monkeypatch.setattr(
        lifecycle, "_system_proxy_state", lambda host, port: ("disabled", "off"),
    )
    monkeypatch.setattr(lifecycle, "_is_cert_trusted", lambda: True)
    monkeypatch.setattr(lifecycle, "_proxy_managed_sentinel_path", lambda: Path("/nope"))
    monkeypatch.setattr(
        lifecycle, "_latest_capture",
        lambda db_path: lifecycle._LatestCapture(found=False, db_missing=True),
    )

    rc = lifecycle.status()
    assert rc == 1


def test_status_macos_proxy_pointed_elsewhere_returns_one(
    macos: None,
    installed_plists: tuple[Path, Path],
    cfg_loaded: HaltonConfig,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(lifecycle, "_launchctl_label_pid", lambda label: 1)
    monkeypatch.setattr(lifecycle, "_launchctl_label_known", lambda label: True)
    monkeypatch.setattr(
        lifecycle, "_poll_health_with_latency",
        lambda port, timeout=1.0: (True, 1.0),
    )
    monkeypatch.setattr(
        lifecycle, "_system_proxy_state",
        lambda host, port: ("pointed elsewhere", "system proxy on but address=10.0.0.1:3128"),
    )
    monkeypatch.setattr(lifecycle, "_is_cert_trusted", lambda: True)
    monkeypatch.setattr(lifecycle, "_proxy_managed_sentinel_path", lambda: Path("/nope"))
    monkeypatch.setattr(
        lifecycle, "_latest_capture",
        lambda db_path: lifecycle._LatestCapture(found=False, db_missing=True),
    )

    rc = lifecycle.status()
    assert rc == 1


def test_status_macos_database_missing(
    macos: None,
    installed_plists: tuple[Path, Path],
    cfg_loaded: HaltonConfig,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(lifecycle, "_launchctl_label_pid", lambda label: 1)
    monkeypatch.setattr(lifecycle, "_launchctl_label_known", lambda label: True)
    monkeypatch.setattr(
        lifecycle, "_poll_health_with_latency",
        lambda port, timeout=1.0: (True, 1.0),
    )
    monkeypatch.setattr(
        lifecycle, "_system_proxy_state", lambda host, port: ("enabled", "ok"),
    )
    monkeypatch.setattr(lifecycle, "_is_cert_trusted", lambda: True)
    monkeypatch.setattr(lifecycle, "_proxy_managed_sentinel_path", lambda: Path("/nope"))
    monkeypatch.setattr(
        lifecycle, "_latest_capture",
        lambda db_path: lifecycle._LatestCapture(found=False, db_missing=True),
    )

    runner = CliRunner()
    result = runner.invoke(cli, ["status"])
    assert "database not found" in result.output


def test_status_macos_database_empty(
    macos: None,
    installed_plists: tuple[Path, Path],
    cfg_loaded: HaltonConfig,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(lifecycle, "_launchctl_label_pid", lambda label: 1)
    monkeypatch.setattr(lifecycle, "_launchctl_label_known", lambda label: True)
    monkeypatch.setattr(
        lifecycle, "_poll_health_with_latency",
        lambda port, timeout=1.0: (True, 1.0),
    )
    monkeypatch.setattr(
        lifecycle, "_system_proxy_state", lambda host, port: ("enabled", "ok"),
    )
    monkeypatch.setattr(lifecycle, "_is_cert_trusted", lambda: True)
    monkeypatch.setattr(lifecycle, "_proxy_managed_sentinel_path", lambda: Path("/nope"))
    monkeypatch.setattr(
        lifecycle, "_latest_capture",
        lambda db_path: lifecycle._LatestCapture(found=False, db_missing=False),
    )

    runner = CliRunner()
    result = runner.invoke(cli, ["status"])
    assert "no captures yet" in result.output


def test_status_json_output(status_macos_healthy: None) -> None:
    runner = CliRunner()
    result = runner.invoke(cli, ["status", "--json"])
    assert result.exit_code == 0
    # Last JSON object on stdout — Rich console may have leading/trailing
    # whitespace but no other text in --json mode.
    payload = json.loads(result.output.strip())
    assert payload["healthy"] is True
    assert payload["platform"] == "darwin"
    assert "components" in payload
    assert any(c["name"] == "Daemon" for c in payload["components"])
    assert payload["captured_last_hour"] == 12
    assert payload["captured_last_day"] == 4208


# --------------------------------------------------------------------------- #
# v0.1.10 Gap 16 — graceful-uninstall status detection                        #
# --------------------------------------------------------------------------- #


@pytest.fixture
def graceful_uninstall_state(
    macos: None,
    cfg_loaded: HaltonConfig,
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    """Materialise the post-`uninstall --graceful` filesystem signature.

    Edge plist + sentinel + daemon plist all absent on disk; edge label
    has a live PID; daemon label is unknown to launchctl.
    """
    daemon_plist = tmp_path / "missing-daemon.plist"
    watchdog_plist = tmp_path / "missing-watchdog.plist"
    edge_plist = tmp_path / "missing-edge.plist"
    sentinel = tmp_path / "missing-sentinel"
    monkeypatch.setattr(
        lifecycle, "_macos_paths", lambda: (daemon_plist, tmp_path, tmp_path)
    )
    monkeypatch.setattr(lifecycle, "_macos_watchdog_plist_path", lambda: watchdog_plist)
    monkeypatch.setattr(lifecycle, "_macos_edge_plist_path", lambda: edge_plist)
    monkeypatch.setattr(lifecycle, "_proxy_managed_sentinel_path", lambda: sentinel)
    monkeypatch.setattr(
        lifecycle,
        "_launchctl_label_pid",
        lambda label: 90210 if label == lifecycle._EDGE_LABEL else None,
    )
    # daemon label unknown → returncode != 0 from `launchctl list`
    monkeypatch.setattr(
        lifecycle,
        "_launchctl_label_known",
        lambda label: False,
    )
    monkeypatch.setattr(
        lifecycle,
        "_latest_capture",
        lambda db_path: lifecycle._LatestCapture(found=False, db_missing=True),
    )


def test_status_macos_graceful_uninstall_renders_single_row(
    graceful_uninstall_state: None, capsys: pytest.CaptureFixture[str]
) -> None:
    """When all four detection conditions hold, `status` emits a single
    `Graceful uninstall` row instead of the standard 8-row table, and
    exits HEALTHY (0) — graceful is an explicit user-state, not drift."""
    rc = lifecycle.status()
    out = capsys.readouterr().out
    assert rc == 0
    assert "Graceful uninstall" in out
    assert "edge in passthrough" in out
    assert "PID 90210" in out
    # Standard rows must NOT appear.
    assert "Watchdog" not in out
    assert "System proxy" not in out
    assert "Cert trust" not in out
    # HEALTHY verdict, not BROKEN.
    assert "HEALTHY" in out
    assert "BROKEN" not in out


def test_status_macos_graceful_uninstall_json_payload(
    graceful_uninstall_state: None,
) -> None:
    """JSON output mirrors the rendered table — one component row,
    HEALTHY summary, healthy=True."""
    runner = CliRunner()
    result = runner.invoke(cli, ["status", "--json"])
    assert result.exit_code == 0
    payload = json.loads(result.output.strip())
    assert payload["healthy"] is True
    assert len(payload["components"]) == 1
    assert payload["components"][0]["name"] == "Graceful uninstall"
    assert payload["components"][0]["state"] == "edge in passthrough"
    assert payload["health_summary"]["severity"] == "HEALTHY"


def test_status_macos_graceful_partial_falls_through_to_standard_table(
    macos: None,
    cfg_loaded: HaltonConfig,
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
    capsys: pytest.CaptureFixture[str],
) -> None:
    """Partial graceful state (sentinel still present) is NOT graceful —
    it is drift. The standard render must fire so the user sees the
    inconsistency, not a misleading HEALTHY graceful row."""
    daemon_plist = tmp_path / "missing-daemon.plist"
    watchdog_plist = tmp_path / "missing-watchdog.plist"
    edge_plist = tmp_path / "missing-edge.plist"
    # Sentinel is present — breaks the four-of-four detection.
    sentinel = tmp_path / "proxy-managed"
    sentinel.touch()
    monkeypatch.setattr(
        lifecycle, "_macos_paths", lambda: (daemon_plist, tmp_path, tmp_path)
    )
    monkeypatch.setattr(lifecycle, "_macos_watchdog_plist_path", lambda: watchdog_plist)
    monkeypatch.setattr(lifecycle, "_macos_edge_plist_path", lambda: edge_plist)
    monkeypatch.setattr(lifecycle, "_proxy_managed_sentinel_path", lambda: sentinel)
    monkeypatch.setattr(
        lifecycle,
        "_launchctl_label_pid",
        lambda label: 90210 if label == lifecycle._EDGE_LABEL else None,
    )
    monkeypatch.setattr(lifecycle, "_launchctl_label_known", lambda label: False)
    monkeypatch.setattr(
        lifecycle, "_is_cert_trusted", lambda: True,
    )
    monkeypatch.setattr(
        lifecycle, "_system_proxy_state", lambda host, port: ("disabled", "off"),
    )
    monkeypatch.setattr(
        lifecycle, "_latest_capture",
        lambda db_path: lifecycle._LatestCapture(found=False, db_missing=True),
    )

    rc = lifecycle.status()
    out = capsys.readouterr().out
    assert rc != 0  # standard render reports the wall of "not installed"
    assert "Graceful uninstall" not in out
    # Standard table rows present.
    assert "Daemon" in out
    assert "Watchdog" in out


# --------------------------------------------------------------------------- #
# Linux                                                                       #
# --------------------------------------------------------------------------- #


def test_status_linux_skips_proxy_row(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    monkeypatch.setattr(lifecycle.sys, "platform", "linux")
    monkeypatch.setattr(lifecycle.os, "name", "posix")
    cfg = _make_cfg(tmp_path)
    monkeypatch.setattr(lifecycle, "load_config", lambda: cfg)

    # Pretend systemd units exist + active.
    daemon_unit = tmp_path / "halton-meter.service"
    watchdog_unit = tmp_path / "halton-meter-watchdog.service"
    daemon_unit.write_text("")
    watchdog_unit.write_text("")
    monkeypatch.setattr(lifecycle, "_linux_unit_path", lambda: daemon_unit)
    monkeypatch.setattr(lifecycle, "_linux_watchdog_unit_path", lambda: watchdog_unit)
    monkeypatch.setattr(lifecycle, "_systemctl_is_active", lambda unit: "active")
    monkeypatch.setattr(
        lifecycle, "_latest_capture",
        lambda db_path: lifecycle._LatestCapture(found=False, db_missing=True),
    )

    runner = CliRunner()
    result = runner.invoke(cli, ["status", "--json"])
    payload = json.loads(result.output.strip())
    component_names = {c["name"] for c in payload["components"]}
    assert "System proxy" not in component_names
    assert "Daemon" in component_names
    assert "Watchdog" in component_names


# --------------------------------------------------------------------------- #
# Windows                                                                     #
# --------------------------------------------------------------------------- #


def test_start_windows_unsupported(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(lifecycle.sys, "platform", "win32")
    monkeypatch.setattr(lifecycle.os, "name", "nt")
    rc = lifecycle.start()
    assert rc == 0


def test_stop_windows_unsupported(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(lifecycle.sys, "platform", "win32")
    monkeypatch.setattr(lifecycle.os, "name", "nt")
    rc = lifecycle.stop()
    assert rc == 0


def test_status_windows_unsupported(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(lifecycle.sys, "platform", "win32")
    monkeypatch.setattr(lifecycle.os, "name", "nt")
    rc = lifecycle.status()
    assert rc == 0


# --------------------------------------------------------------------------- #
# v0.1.3 P0-8 — mode-aware health summary                                     #
# --------------------------------------------------------------------------- #


def _row(name: str, state: str) -> lifecycle._ComponentRow:
    return lifecycle._ComponentRow(name, state, "")


class TestComputeHealthSummaryMacos:
    def test_env_only_healthy_when_daemon_and_cert_ok(self) -> None:
        rows = [
            _row("Daemon", "healthy"),
            _row("Cert trust", "trusted"),
            _row("System proxy", "disabled"),
            _row("Sentinel file", "missing"),
        ]
        summary = lifecycle._compute_health_summary_macos(rows, "env-only")
        assert summary.severity == "HEALTHY"
        assert "halton-meter run" in summary.message

    def test_env_only_broken_when_cert_not_trusted(self) -> None:
        rows = [
            _row("Daemon", "healthy"),
            _row("Cert trust", "not trusted"),
            _row("System proxy", "disabled"),
        ]
        summary = lifecycle._compute_health_summary_macos(rows, "env-only")
        assert summary.severity == "BROKEN"

    def test_full_broken_when_proxy_enabled_but_cert_untrusted(self) -> None:
        """Witnessed totaljobs.com regression: proxy enabled at us but
        cert is not trusted -> SecTrust rejects, browsing dies."""
        rows = [
            _row("Daemon", "healthy"),
            _row("Cert trust", "not trusted"),
            _row("System proxy", "enabled"),
        ]
        summary = lifecycle._compute_health_summary_macos(rows, "full")
        assert summary.severity == "BROKEN"
        assert "cert" in summary.message.lower()

    def test_full_inconsistent_when_proxy_not_enabled(self) -> None:
        rows = [
            _row("Daemon", "healthy"),
            _row("Cert trust", "trusted"),
            _row("System proxy", "disabled"),
        ]
        summary = lifecycle._compute_health_summary_macos(rows, "full")
        assert summary.severity == "INCONSISTENT"

    def test_full_healthy_when_all_signals_good(self) -> None:
        rows = [
            _row("Daemon", "healthy"),
            _row("Cert trust", "trusted"),
            _row("System proxy", "enabled"),
        ]
        summary = lifecycle._compute_health_summary_macos(rows, "full")
        assert summary.severity == "HEALTHY"

    def test_apps_healthy_when_proxy_disabled_and_cert_trusted(self) -> None:
        """v0.1.5 (2B.16): apps mode is HEALTHY when daemon + cert ok AND
        system proxy is DISABLED on our interfaces (apps mode promises
        to leave the system proxy alone)."""
        rows = [
            _row("Daemon", "healthy"),
            _row("Cert trust", "trusted"),
            _row("System proxy", "disabled"),
        ]
        summary = lifecycle._compute_health_summary_macos(rows, "apps")
        assert summary.severity == "HEALTHY"
        assert "apps" in summary.message.lower()

    def test_apps_broken_when_proxy_enabled_drift(self) -> None:
        """v0.1.5 (2B.16): apps mode + system proxy enabled = BROKEN
        drift. The user is running stale full-mode state."""
        rows = [
            _row("Daemon", "healthy"),
            _row("Cert trust", "trusted"),
            _row("System proxy", "enabled"),
        ]
        summary = lifecycle._compute_health_summary_macos(rows, "apps")
        assert summary.severity == "BROKEN"
        assert "stale" in summary.message.lower() or "drift" in summary.message.lower()

    def test_apps_broken_when_cert_not_trusted(self) -> None:
        rows = [
            _row("Daemon", "healthy"),
            _row("Cert trust", "not trusted"),
            _row("System proxy", "disabled"),
        ]
        summary = lifecycle._compute_health_summary_macos(rows, "apps")
        assert summary.severity == "BROKEN"
        assert "cert" in summary.message.lower()

    def test_unknown_mode_returns_inconsistent(self) -> None:
        rows = [
            _row("Daemon", "healthy"),
            _row("Cert trust", "trusted"),
            _row("System proxy", "enabled"),
        ]
        summary = lifecycle._compute_health_summary_macos(rows, None)
        assert summary.severity == "INCONSISTENT"

    def test_daemon_unhealthy_dominates(self) -> None:
        rows = [
            _row("Daemon", "loaded"),  # not healthy
            _row("Cert trust", "trusted"),
            _row("System proxy", "enabled"),
        ]
        summary = lifecycle._compute_health_summary_macos(rows, "full")
        assert summary.severity == "BROKEN"
        assert "daemon" in summary.message.lower()


def test_status_report_to_json_dict_includes_health_summary() -> None:
    report = lifecycle._StatusReport(
        healthy=True,
        platform="darwin",
        health_summary=lifecycle._HealthSummary(
            "HEALTHY", "env-var-only mode is healthy."
        ),
    )
    payload = report.to_json_dict()
    assert "health_summary" in payload
    assert payload["health_summary"]["severity"] == "HEALTHY"


def test_status_report_to_json_dict_omits_health_summary_when_none() -> None:
    report = lifecycle._StatusReport(healthy=True, platform="darwin")
    payload = report.to_json_dict()
    assert "health_summary" not in payload


# --------------------------------------------------------------------------- #
# v0.1.4 (2B.15) P0-5 — auto-port-fallback in status                           #
# --------------------------------------------------------------------------- #


class TestPortStatusRow:
    """Effective ports row marks auto-fallback explicitly so the user
    knows their tools must target the actual port, not the marketed
    default."""

    def test_default_ports_show_default_state(self) -> None:
        # v0.1.6: user-facing proxy default is now 8081 (was 8080); the
        # daemon's mitmproxy listener still binds it at this stage of
        # the rollout (W4 flips it to internal_port 8090).
        row = lifecycle._port_status_row(8081, 8765)
        assert row.name == "Effective ports"
        assert row.state == "default"
        assert "8081" in row.detail
        assert "8765" in row.detail
        assert "fallback" not in row.detail.lower()

    def test_listen_port_fallback_marked(self) -> None:
        # 8082 is one above the v0.1.6 default 8081 -> fallback.
        row = lifecycle._port_status_row(8082, 8765)
        assert row.state == "fallback"
        assert "8082" in row.detail
        assert "fell back" in row.detail.lower()
        assert "8081" in row.detail  # v0.1.6 default we fell back from

    def test_api_port_fallback_marked(self) -> None:
        row = lifecycle._port_status_row(8081, 8766)
        assert row.state == "fallback"
        assert "8766" in row.detail
        assert "fell back" in row.detail.lower()
        assert "8765" in row.detail  # default we fell back from

    def test_both_ports_fallback_listed(self) -> None:
        row = lifecycle._port_status_row(8083, 8767)
        assert row.state == "fallback"
        # Both fallback notes present.
        assert "8083" in row.detail
        assert "8767" in row.detail
        assert "8081" in row.detail  # v0.1.6 default
        assert "8765" in row.detail


# --------------------------------------------------------------------------- #
# v0.1.16 Q4.3 — MITM listener TCP probe + banner precedence (Bug 1)           #
# --------------------------------------------------------------------------- #


class TestProbeMitmListener:
    """The TCP probe is the only signal that catches the Bug 1 silent
    death: the asyncio MITM acceptor died but FastAPI `/health` is still
    UP. Defensive — must never raise."""

    def test_probe_returns_true_when_socket_opens(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        import socket as _socket

        class _FakeSock:
            def close(self) -> None:
                self.closed = True

        captured: dict = {}

        def _fake_create_connection(addr, timeout):  # type: ignore[no-untyped-def]
            captured["addr"] = addr
            captured["timeout"] = timeout
            return _FakeSock()

        monkeypatch.setattr(_socket, "create_connection", _fake_create_connection)
        assert lifecycle._probe_mitm_listener("127.0.0.1", 8090) is True
        assert captured["addr"] == ("127.0.0.1", 8090)
        assert captured["timeout"] == 0.5

    def test_probe_returns_false_on_connection_refused(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        import socket as _socket

        def _refuse(addr, timeout):  # type: ignore[no-untyped-def]
            raise ConnectionRefusedError("nope")

        monkeypatch.setattr(_socket, "create_connection", _refuse)
        assert lifecycle._probe_mitm_listener("127.0.0.1", 8090) is False

    def test_probe_returns_false_on_timeout(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        import socket as _socket

        def _timeout(addr, timeout):  # type: ignore[no-untyped-def]
            raise TimeoutError("slow")

        monkeypatch.setattr(_socket, "create_connection", _timeout)
        assert lifecycle._probe_mitm_listener("127.0.0.1", 8090) is False

    def test_probe_returns_false_on_generic_oserror(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        import socket as _socket

        def _err(addr, timeout):  # type: ignore[no-untyped-def]
            raise OSError("generic")

        monkeypatch.setattr(_socket, "create_connection", _err)
        assert lifecycle._probe_mitm_listener("127.0.0.1", 8090) is False

    def test_probe_swallows_unexpected_exceptions(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Even if a wildly unexpected exception escapes, the probe must
        return False — never raise into the status command."""
        import socket as _socket

        def _kaboom(addr, timeout):  # type: ignore[no-untyped-def]
            raise RuntimeError("totally unexpected")

        monkeypatch.setattr(_socket, "create_connection", _kaboom)
        assert lifecycle._probe_mitm_listener("127.0.0.1", 8090) is False


class TestMitmBannerPrecedence:
    """Banner precedence (v0.1.16 Q4.3, Bug 1):

        daemon-down  >  MITM-down  >  existing mode-aware verdict

    Daemon-down dominates so we never double-warn (the existing message
    already tells the user to run start). MITM-down fires BROKEN with a
    distinct, action-oriented message."""

    def test_banner_broken_when_daemon_healthy_and_mitm_unresponsive(self) -> None:
        rows = [
            _row("Daemon", "healthy"),
            _row("MITM listener", "unresponsive"),
            _row("Cert trust", "trusted"),
            _row("System proxy", "enabled"),
        ]
        # Stuff a port into the row detail so the banner can extract it.
        rows[1] = lifecycle._ComponentRow(
            "MITM listener",
            "unresponsive",
            "127.0.0.1:8090 TCP connect failed — metering is OFF",
        )
        summary = lifecycle._compute_health_summary_macos(rows, "full")
        assert summary.severity == "BROKEN"
        assert "MITM listener" in summary.message
        assert ":8090" in summary.message
        assert "metering is OFF" in summary.message
        assert "halton-meter restart" in summary.message
        assert "daemon.err.log" in summary.message

    def test_banner_does_not_fire_when_daemon_healthy_and_mitm_healthy(self) -> None:
        rows = [
            _row("Daemon", "healthy"),
            _row("MITM listener", "healthy"),
            _row("Cert trust", "trusted"),
            _row("System proxy", "enabled"),
        ]
        summary = lifecycle._compute_health_summary_macos(rows, "full")
        assert summary.severity == "HEALTHY"
        assert "MITM" not in summary.message

    def test_daemon_down_banner_takes_precedence_over_mitm_down(self) -> None:
        """If the daemon row is unhealthy, the existing daemon-down
        message wins — no double-warn, no mention of MITM."""
        rows = [
            _row("Daemon", "loaded"),  # not healthy
            _row("MITM listener", "unresponsive"),
            _row("Cert trust", "trusted"),
            _row("System proxy", "enabled"),
        ]
        summary = lifecycle._compute_health_summary_macos(rows, "full")
        assert summary.severity == "BROKEN"
        assert "daemon" in summary.message.lower()
        assert "MITM" not in summary.message
        assert "halton-meter start" in summary.message

    def test_mitm_unresponsive_overrides_apps_mode_healthy_path(self) -> None:
        """Apps-mode + daemon healthy + cert trusted + proxy disabled is
        normally HEALTHY — but MITM-down still flips to BROKEN."""
        rows = [
            _row("Daemon", "healthy"),
            _row("MITM listener", "unresponsive"),
            _row("Cert trust", "trusted"),
            _row("System proxy", "disabled"),
        ]
        rows[1] = lifecycle._ComponentRow(
            "MITM listener", "unresponsive", "127.0.0.1:8090 TCP connect failed",
        )
        summary = lifecycle._compute_health_summary_macos(rows, "apps")
        assert summary.severity == "BROKEN"
        assert "MITM listener" in summary.message


def test_status_macos_renders_mitm_listener_row_when_healthy(
    status_macos_healthy: None, capsys: pytest.CaptureFixture[str]
) -> None:
    """v0.1.16 Q4.3: the status table includes a MITM listener row that
    reports healthy when the TCP probe succeeds."""
    rc = lifecycle.status()
    out = capsys.readouterr().out
    assert rc == 0
    assert "MITM listener" in out
    # Detail mentions the probed port (default internal_port 8090).
    assert ":8090" in out


def test_status_macos_mitm_unresponsive_flips_banner_to_broken(
    macos: None,
    installed_plists: tuple[Path, Path],
    cfg_loaded: HaltonConfig,
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
) -> None:
    """v0.1.16 Q4.3: when /health is up but the MITM port is silently
    dead, status flips BROKEN with the action-oriented banner. This is
    the exact silent-failure mode that bit us in the 0.1.15 soak."""
    monkeypatch.setattr(
        lifecycle, "_launchctl_label_pid",
        lambda label: 81234 if label == lifecycle._LABEL else 81235,
    )
    monkeypatch.setattr(lifecycle, "_launchctl_label_known", lambda label: True)
    monkeypatch.setattr(
        lifecycle, "_poll_health_with_latency",
        lambda port, timeout=1.0: (True, 3.0),
    )
    # Critical: MITM port unresponsive while /health is healthy.
    monkeypatch.setattr(
        lifecycle, "_probe_mitm_listener",
        lambda host, port, timeout=0.5: False,
    )
    monkeypatch.setattr(
        lifecycle, "_system_proxy_state",
        lambda host, port: ("enabled", "127.0.0.1:9080 on Wi-Fi"),
    )
    monkeypatch.setattr(lifecycle, "_is_cert_trusted", lambda: True)
    sentinel = Path("/tmp/halton-meter-test-sentinel-mitm-broken")
    sentinel.touch()
    monkeypatch.setattr(lifecycle, "_proxy_managed_sentinel_path", lambda: sentinel)
    monkeypatch.setattr(
        lifecycle, "_latest_capture",
        lambda db_path: lifecycle._LatestCapture(found=False, db_missing=False),
    )

    rc = lifecycle.status()
    out = capsys.readouterr().out
    assert rc == 1
    assert "BROKEN" in out
    assert "MITM listener" in out
    assert "unresponsive" in out
    assert "halton-meter restart" in out


# --------------------------------------------------------------------------- #
# v0.1.21 manual-start: branded panels + --quiet + STOPPED verdict            #
# --------------------------------------------------------------------------- #


def test_start_macos_success_renders_metering_active_panel(
    macos: None,
    installed_plists: tuple[Path, Path],
    cfg_loaded: HaltonConfig,
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
) -> None:
    """v0.1.21: success panel title is "Halton Meter — metering active"
    with the new mental-model body lines (PIDs, /health latency, edge
    port, stop hint)."""
    monkeypatch.setattr(lifecycle, "_detect_live_daemon", lambda: False)
    monkeypatch.setattr(lifecycle, "_detect_live_watchdog", lambda: False)
    monkeypatch.setattr(
        lifecycle, "_poll_health_with_latency", lambda port, timeout=1.0: (False, None)
    )
    monkeypatch.setattr(lifecycle, "_lsof_pids_on_port", lambda port: [])
    monkeypatch.setattr(
        lifecycle, "_launchctl_label_pid",
        lambda label: 9001 if label == lifecycle._LABEL else 9002,
    )
    monkeypatch.setattr(lifecycle, "_our_managed_pids", lambda: set())
    monkeypatch.setattr(lifecycle.subprocess, "run", lambda *a, **kw: _completed(0))
    monkeypatch.setattr(
        lifecycle, "_start_probe_health", lambda port: (True, 4.0, 5.0)
    )

    rc = lifecycle.start()
    out = capsys.readouterr().out
    assert rc == 0
    assert "metering active" in out
    assert "Daemon loaded" in out
    assert "9001" in out
    assert "Watchdog loaded" in out
    assert "halton-meter stop" in out


def test_start_macos_failure_renders_branded_failure_panel(
    macos: None,
    installed_plists: tuple[Path, Path],
    cfg_loaded: HaltonConfig,
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
) -> None:
    """v0.1.21: when /health does not respond within 8s, the failure
    panel surfaces (a) edge is still tunnelling fail-open and (b) the
    three retry steps."""
    monkeypatch.setattr(lifecycle, "_detect_live_daemon", lambda: False)
    monkeypatch.setattr(lifecycle, "_detect_live_watchdog", lambda: False)
    monkeypatch.setattr(
        lifecycle, "_poll_health_with_latency", lambda port, timeout=1.0: (False, None)
    )
    monkeypatch.setattr(lifecycle, "_lsof_pids_on_port", lambda port: [])
    monkeypatch.setattr(lifecycle, "_launchctl_label_pid", lambda label: None)
    monkeypatch.setattr(lifecycle, "_our_managed_pids", lambda: set())
    monkeypatch.setattr(lifecycle.subprocess, "run", lambda *a, **kw: _completed(0))
    monkeypatch.setattr(
        lifecycle, "_start_probe_health", lambda port: (False, None, 8000.0)
    )
    monkeypatch.setattr(lifecycle, "_print_err_log_tail", lambda *a, **kw: None)

    rc = lifecycle.start()
    out = capsys.readouterr().out
    assert rc == 1
    assert "daemon failed to start" in out
    assert "fail-open" in out
    assert "halton-meter doctor" in out
    assert "halton-meter stop && halton-meter start" in out


def test_start_macos_quiet_mode_emits_single_line_success(
    macos: None,
    installed_plists: tuple[Path, Path],
    cfg_loaded: HaltonConfig,
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
) -> None:
    """v0.1.21 ``--quiet``: scripts and shell-rc helpers see one line."""
    monkeypatch.setattr(lifecycle, "_detect_live_daemon", lambda: False)
    monkeypatch.setattr(lifecycle, "_detect_live_watchdog", lambda: False)
    monkeypatch.setattr(
        lifecycle, "_poll_health_with_latency", lambda port, timeout=1.0: (False, None)
    )
    monkeypatch.setattr(lifecycle, "_lsof_pids_on_port", lambda port: [])
    monkeypatch.setattr(lifecycle, "_launchctl_label_pid", lambda label: 4242)
    monkeypatch.setattr(lifecycle, "_our_managed_pids", lambda: set())
    monkeypatch.setattr(lifecycle.subprocess, "run", lambda *a, **kw: _completed(0))
    monkeypatch.setattr(
        lifecycle, "_start_probe_health", lambda port: (True, 1.0, 1.0)
    )

    rc = lifecycle.start(quiet=True)
    out = capsys.readouterr().out
    assert rc == 0
    # No box-drawing in quiet mode.
    assert "metering active" in out
    assert "│" not in out
    assert "╭" not in out


def test_start_macos_quiet_mode_emits_single_line_failure(
    macos: None,
    installed_plists: tuple[Path, Path],
    cfg_loaded: HaltonConfig,
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
) -> None:
    """v0.1.21 ``--quiet`` failure path mentions edge tunnelling so a
    script can grep the single line and know fail-open is intact."""
    monkeypatch.setattr(lifecycle, "_detect_live_daemon", lambda: False)
    monkeypatch.setattr(lifecycle, "_detect_live_watchdog", lambda: False)
    monkeypatch.setattr(
        lifecycle, "_poll_health_with_latency", lambda port, timeout=1.0: (False, None)
    )
    monkeypatch.setattr(lifecycle, "_lsof_pids_on_port", lambda port: [])
    monkeypatch.setattr(lifecycle, "_launchctl_label_pid", lambda label: None)
    monkeypatch.setattr(lifecycle, "_our_managed_pids", lambda: set())
    monkeypatch.setattr(lifecycle.subprocess, "run", lambda *a, **kw: _completed(0))
    monkeypatch.setattr(
        lifecycle, "_start_probe_health", lambda port: (False, None, 8000.0)
    )

    rc = lifecycle.start(quiet=True)
    out = capsys.readouterr().out
    assert rc == 1
    assert "edge tunnelling" in out
    assert "│" not in out


# --------------------------------------------------------------------------- #
# v0.1.21: STOPPED is a first-class verdict (info, not error)                 #
# --------------------------------------------------------------------------- #


class TestComputeHealthSummaryStoppedVerdict:
    """v0.1.21 manual-start: daemon not loaded + edge healthy = STOPPED."""

    def test_stopped_when_daemon_not_loaded_and_edge_healthy(self) -> None:
        rows = [
            _row("Daemon", "not loaded"),
            _row("Edge", "healthy"),
            _row("Cert trust", "trusted"),
            _row("System proxy", "disabled"),
        ]
        summary = lifecycle._compute_health_summary_macos(rows, "apps")
        assert summary.severity == "STOPPED"
        assert "halton-meter start" in summary.message
        assert "un-metered" in summary.message

    def test_loaded_but_unresponsive_still_broken(self) -> None:
        """Zombie signature (loaded, no PID-but-known) stays BROKEN —
        STOPPED is reserved for the clean post-reboot/post-stop path."""
        rows = [
            _row("Daemon", "loaded"),  # zombie state
            _row("Edge", "healthy"),
            _row("Cert trust", "trusted"),
        ]
        summary = lifecycle._compute_health_summary_macos(rows, "apps")
        assert summary.severity == "BROKEN"

    def test_status_macos_stopped_returns_zero_and_renders_info(
        self,
        macos: None,
        installed_plists: tuple[Path, Path],
        cfg_loaded: HaltonConfig,
        monkeypatch: pytest.MonkeyPatch,
        capsys: pytest.CaptureFixture[str],
    ) -> None:
        """End-to-end: post-reboot status (daemon not loaded, edge alive)
        renders STOPPED verdict and exits 0 — not BROKEN, not exit 1."""
        # Daemon: known plist, no PID, label unknown to launchctl.
        monkeypatch.setattr(
            lifecycle, "_launchctl_label_pid",
            lambda label: 4242 if label == lifecycle._EDGE_LABEL else None,
        )
        monkeypatch.setattr(
            lifecycle, "_launchctl_label_known",
            lambda label: label == lifecycle._EDGE_LABEL,
        )
        # Edge plist is present (auto-loaded).
        from halton_meter import install as _install
        edge_plist = Path.home() / "Library" / "LaunchAgents" / _install._EDGE_PLIST_NAME
        edge_plist.parent.mkdir(parents=True, exist_ok=True)
        edge_plist.write_text("<plist/>")
        monkeypatch.setattr(lifecycle, "_macos_edge_plist_path", lambda: edge_plist)
        # MITM probe → up (edge tunnels there during fail-open is fine).
        monkeypatch.setattr(lifecycle, "_probe_mitm_listener", lambda *a, **kw: True)
        monkeypatch.setattr(lifecycle, "_is_cert_trusted", lambda: True)
        monkeypatch.setattr(
            lifecycle, "_system_proxy_state",
            lambda host, port: ("disabled", "—"),
        )
        monkeypatch.setattr(
            lifecycle, "_latest_capture",
            lambda db_path: lifecycle._LatestCapture(found=False, db_missing=False),
        )

        rc = lifecycle.status()
        out = capsys.readouterr().out
        assert rc == 0, "STOPPED is an expected state — must exit 0"
        assert "STOPPED" in out
        assert "metering paused" in out
        assert "BROKEN" not in out


# --------------------------------------------------------------------------- #
# v0.1.21.2: modern launchctl verbs                                           #
# --------------------------------------------------------------------------- #


class TestModernLaunchctlVerbs:
    """v0.1.21.2: legacy ``launchctl load -w`` is a no-op on
    ``RunAtLoad=False`` plists. Switched to ``bootstrap`` / ``bootout``
    / ``kickstart`` against ``gui/$UID`` domain.
    """

    def test_bootstrap_invokes_correct_verb_and_domain(
        self, macos: None, monkeypatch: pytest.MonkeyPatch, tmp_path: Path
    ) -> None:
        captured: list[list[str]] = []

        def fake_run(argv: list[str], **_kw: Any) -> subprocess.CompletedProcess:
            captured.append(argv)
            return _completed(0)

        monkeypatch.setattr(lifecycle.subprocess, "run", fake_run)
        monkeypatch.setattr(lifecycle.os, "geteuid", lambda: 501)

        rc, _err = lifecycle._launchctl_bootstrap(tmp_path / "x.plist")
        assert rc == 0
        assert captured[-1][:3] == ["launchctl", "bootstrap", "gui/501"]
        assert captured[-1][-1] == str(tmp_path / "x.plist")

    def test_bootout_invokes_correct_verb_and_domain(
        self, macos: None, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        captured: list[list[str]] = []

        def fake_run(argv: list[str], **_kw: Any) -> subprocess.CompletedProcess:
            captured.append(argv)
            return _completed(0)

        monkeypatch.setattr(lifecycle.subprocess, "run", fake_run)
        monkeypatch.setattr(lifecycle.os, "geteuid", lambda: 501)

        rc, _err = lifecycle._launchctl_bootout("com.haltonlabs.meter")
        assert rc == 0
        assert captured[-1] == [
            "launchctl", "bootout", "gui/501/com.haltonlabs.meter",
        ]

    def test_kickstart_includes_dash_k_when_killing(
        self, macos: None, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        captured: list[list[str]] = []

        def fake_run(argv: list[str], **_kw: Any) -> subprocess.CompletedProcess:
            captured.append(argv)
            return _completed(0)

        monkeypatch.setattr(lifecycle.subprocess, "run", fake_run)
        monkeypatch.setattr(lifecycle.os, "geteuid", lambda: 501)

        rc, _err = lifecycle._launchctl_kickstart(
            "com.haltonlabs.meter", kill_existing=True
        )
        assert rc == 0
        assert captured[-1] == [
            "launchctl", "kickstart", "-k", "gui/501/com.haltonlabs.meter",
        ]

    def test_kickstart_omits_dash_k_when_not_killing(
        self, macos: None, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        captured: list[list[str]] = []

        def fake_run(argv: list[str], **_kw: Any) -> subprocess.CompletedProcess:
            captured.append(argv)
            return _completed(0)

        monkeypatch.setattr(lifecycle.subprocess, "run", fake_run)
        monkeypatch.setattr(lifecycle.os, "geteuid", lambda: 501)

        rc, _err = lifecycle._launchctl_kickstart(
            "com.haltonlabs.meter", kill_existing=False
        )
        assert rc == 0
        assert "-k" not in captured[-1]
        assert captured[-1][-1] == "gui/501/com.haltonlabs.meter"

    def test_start_macos_kickstart_failure_is_fatal(
        self,
        macos: None,
        installed_plists: tuple[Path, Path],
        cfg_loaded: HaltonConfig,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        """v0.1.21.2: kickstart is the load-bearing call. A non-zero
        kickstart exit MUST surface as a non-zero ``halton-meter start``
        exit (the v0.1.21.1 silent-failure regression).
        """
        monkeypatch.setattr(lifecycle, "_detect_live_daemon", lambda: False)
        monkeypatch.setattr(lifecycle, "_detect_live_watchdog", lambda: False)
        monkeypatch.setattr(
            lifecycle,
            "_poll_health_with_latency",
            lambda port, timeout=1.0: (False, None),
        )
        monkeypatch.setattr(lifecycle, "_lsof_pids_on_port", lambda port: [])
        monkeypatch.setattr(lifecycle, "_launchctl_label_pid", lambda label: None)
        monkeypatch.setattr(lifecycle, "_our_managed_pids", lambda: set())

        def fake_run(argv: list[str], **_kw: Any) -> subprocess.CompletedProcess:
            if "kickstart" in argv:
                return _completed(1, stderr="job failed to start")
            return _completed(0)

        monkeypatch.setattr(lifecycle.subprocess, "run", fake_run)
        rc = lifecycle.start()
        assert rc == 1


# --------------------------------------------------------------------------- #
# v0.1.21.2: dormant daemon → STOPPED verdict                                  #
# --------------------------------------------------------------------------- #


class TestDormantDaemonStopped:
    """v0.1.21.2: ``dormant`` (label registered, no live PID) is the
    post-reboot signature on a manual-start install whose plist
    auto-loaded at boot. The verdict must be STOPPED (not BROKEN)
    when edge is healthy.
    """

    def test_dormant_daemon_with_healthy_edge_returns_stopped(self) -> None:
        rows = [
            _row("Daemon", "dormant"),
            _row("Edge", "healthy"),
            _row("Cert trust", "trusted"),
            _row("System proxy", "disabled"),
        ]
        summary = lifecycle._compute_health_summary_macos(rows, "apps")
        assert summary.severity == "STOPPED"
        assert "halton-meter start" in summary.message

    def test_dormant_daemon_with_dead_edge_falls_through_to_broken(self) -> None:
        rows = [
            _row("Daemon", "dormant"),
            _row("Edge", "not loaded"),
            _row("Cert trust", "trusted"),
            _row("System proxy", "disabled"),
        ]
        summary = lifecycle._compute_health_summary_macos(rows, "apps")
        # No STOPPED — edge isn't healthy, fail-open is broken.
        assert summary.severity == "BROKEN"


# --------------------------------------------------------------------------- #
# v0.1.21.2: stale-chain → BROKEN verdict                                      #
# --------------------------------------------------------------------------- #


def test_edge_stale_chain_promotes_verdict_to_broken() -> None:
    """v0.1.21.2: edge ``stale chain`` row used to be flagged in the
    Component Health table only — top-line verdict stayed HEALTHY.
    Now it's BROKEN (silent metering loss is a credibility wall).
    """
    rows = [
        _row("Daemon", "healthy"),
        _row("Edge", "stale chain"),
        _row("Cert trust", "trusted"),
        _row("System proxy", "enabled"),
    ]
    summary = lifecycle._compute_health_summary_macos(rows, "apps")
    assert summary.severity == "BROKEN"
    assert "stale" in summary.message.lower()


# --------------------------------------------------------------------------- #
# v0.1.21.3: bootout-then-bootstrap idempotency                                #
# --------------------------------------------------------------------------- #


def test_launchctl_reload_calls_bootout_then_bootstrap(
    macos: None,
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    """``_launchctl_reload`` always calls bootout BEFORE bootstrap.

    v0.1.21.3 fix for the user-soak bug where ``launchctl bootstrap``
    on an already-registered label returns rc=5 EIO ("Input/output
    error") with neither "already" nor "loaded" in stderr — v0.1.21.2's
    substring detection missed it and false-failed init. Clearing
    first is robust and idempotent.
    """
    plist_path = tmp_path / "demo.plist"
    plist_path.write_text("<plist/>")
    label = "com.example.demo"

    calls: list[list[str]] = []

    def fake_run(argv: list[str], **_kw: Any) -> subprocess.CompletedProcess:
        calls.append(argv)
        if "print" in argv:
            # v0.1.21.4: simulate label absent → poll exits immediately.
            return _completed(1, stderr="Could not find specified service")
        return _completed(0)

    monkeypatch.setattr(lifecycle.subprocess, "run", fake_run)
    monkeypatch.setattr(lifecycle.time, "sleep", lambda _s: None)

    rc, err = lifecycle._launchctl_reload(plist_path, label)
    assert rc == 0
    assert err == ""
    # v0.1.21.4: order is bootout → print (poll until label absent) →
    # bootstrap. With print returning rc=1 on the first poll, exactly
    # three calls fire.
    assert len(calls) == 3
    assert calls[0][:2] == ["launchctl", "bootout"]
    assert calls[1][:2] == ["launchctl", "print"]
    assert calls[2][:2] == ["launchctl", "bootstrap"]
    assert str(plist_path) in calls[2]


def test_launchctl_reload_succeeds_when_bootout_fails(
    macos: None,
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    """Bootout of an unregistered label returns non-zero; reload still
    proceeds to bootstrap and reports the bootstrap rc.
    """
    plist_path = tmp_path / "demo.plist"
    plist_path.write_text("<plist/>")
    label = "com.example.demo"

    def fake_run(argv: list[str], **_kw: Any) -> subprocess.CompletedProcess:
        if "bootout" in argv:
            # Simulate "not loaded" — bootout rc=3 with stderr.
            return _completed(3, stderr="Could not find specified service")
        if "print" in argv:
            # v0.1.21.4: label was never loaded → print rc != 0.
            return _completed(1)
        return _completed(0)

    monkeypatch.setattr(lifecycle.subprocess, "run", fake_run)
    monkeypatch.setattr(lifecycle.time, "sleep", lambda _s: None)
    rc, err = lifecycle._launchctl_reload(plist_path, label)
    assert rc == 0
    assert err == ""


def test_launchctl_reload_propagates_real_bootstrap_failure(
    macos: None,
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    """If bootstrap returns non-zero AFTER the bootout (e.g. plist
    syntax error), surface the failure — that's a real error, not
    the "already loaded" steady-state we cleared.
    """
    plist_path = tmp_path / "demo.plist"
    plist_path.write_text("<plist/>")
    label = "com.example.demo"

    def fake_run(argv: list[str], **_kw: Any) -> subprocess.CompletedProcess:
        if "bootout" in argv:
            return _completed(0)
        if "print" in argv:
            return _completed(1)
        return _completed(112, stderr="Bootstrap failed: 5: Input/output error")

    monkeypatch.setattr(lifecycle.subprocess, "run", fake_run)
    monkeypatch.setattr(lifecycle.time, "sleep", lambda _s: None)
    rc, err = lifecycle._launchctl_reload(plist_path, label)
    assert rc == 112
    assert "Input/output" in err



def test_start_probe_health_uses_25s_ceiling(
    macos: None,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """v0.1.21.3 bumped the start probe ceiling from 10s to 25s for
    cold-start headroom on slow machines. Verify the deadline is set
    25s out from probe start.
    """
    monkeypatch.setattr(
        lifecycle, "_poll_health_with_latency",
        lambda p, timeout: (False, None),
    )

    t = [0.0]

    def fake_monotonic() -> float:
        return t[0]

    def fake_sleep(s: float) -> None:
        t[0] += s

    monkeypatch.setattr(lifecycle.time, "monotonic", fake_monotonic)
    monkeypatch.setattr(lifecycle.time, "sleep", fake_sleep)

    healthy, _last_ms, _elapsed = lifecycle._start_probe_health(api_port=8765)
    assert healthy is False
    # Loop must advance past 25s — v0.1.21.2's 10s ceiling would stop ~10s.
    assert t[0] >= 25.0


# --------------------------------------------------------------------------- #
# v0.1.21.4: async bootout + start short-circuit + own-edge recognition       #
# --------------------------------------------------------------------------- #


def test_launchctl_reload_polls_for_label_disappearance(
    macos: None,
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    """``_launchctl_reload`` polls ``launchctl print`` between bootout
    and bootstrap until the label is gone (rc != 0). On macOS, bootout
    is async and bootstrap on a still-loaded label returns rc=5 EIO.
    """
    plist_path = tmp_path / "demo.plist"
    plist_path.write_text("<plist/>")
    label = "com.example.demo"

    print_calls: list[int] = [0]

    def fake_run(argv: list[str], **_kw: Any) -> subprocess.CompletedProcess:
        if "print" in argv:
            print_calls[0] += 1
            # First 3 polls: label still present (bootout in flight).
            # 4th poll onward: rc != 0 (label gone).
            if print_calls[0] < 4:
                return _completed(0)
            return _completed(1)
        return _completed(0)

    monkeypatch.setattr(lifecycle.subprocess, "run", fake_run)
    monkeypatch.setattr(lifecycle.time, "sleep", lambda _s: None)

    rc, err = lifecycle._launchctl_reload(plist_path, label)
    assert rc == 0
    assert err == ""
    # Polled exactly until the label disappeared (4 polls).
    assert print_calls[0] == 4


def test_launchctl_reload_poll_timeout_proceeds_to_bootstrap(
    macos: None,
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    """When the poll never observes label disappearance, bootstrap
    still fires after ~20 polls (the 2s ceiling). Don't block forever.
    """
    plist_path = tmp_path / "demo.plist"
    plist_path.write_text("<plist/>")
    label = "com.example.demo"

    print_calls: list[int] = [0]
    bootstrap_fired: list[bool] = [False]

    def fake_run(argv: list[str], **_kw: Any) -> subprocess.CompletedProcess:
        if "print" in argv:
            print_calls[0] += 1
            return _completed(0)  # Always-loaded — never disappears.
        if "bootstrap" in argv:
            bootstrap_fired[0] = True
        return _completed(0)

    sleep_total: list[float] = [0.0]

    def fake_sleep(s: float) -> None:
        sleep_total[0] += s

    monkeypatch.setattr(lifecycle.subprocess, "run", fake_run)
    monkeypatch.setattr(lifecycle.time, "sleep", fake_sleep)

    rc, _err = lifecycle._launchctl_reload(plist_path, label)
    assert rc == 0
    # Polled to the ceiling (20) and then proceeded to bootstrap.
    assert print_calls[0] == 20
    assert bootstrap_fired[0] is True
    # Total simulated sleep <= 2s (20 polls of 0.1s each).
    assert sleep_total[0] <= 2.0 + 1e-6


def test_start_macos_short_circuits_on_health_alone(
    macos: None,
    installed_plists: tuple[Path, Path],
    cfg_loaded: HaltonConfig,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """v0.1.21.4: ``halton-meter start`` short-circuits to OK when
    /health responds 200, regardless of watchdog liveness. Reproduces
    the user-soak bug where a healthy daemon + dormant watchdog had
    ``start`` re-bootstrap and false-fail on its own running edge.
    """
    monkeypatch.setattr(
        lifecycle, "_poll_health_with_latency", lambda port, timeout=1.0: (True, 4.5)
    )

    def fake_pid(label: str) -> int | None:
        if label == lifecycle._LABEL:
            return 6968
        if label == lifecycle._WATCHDOG_LABEL:
            return 6969
        return None

    monkeypatch.setattr(lifecycle, "_launchctl_label_pid", fake_pid)

    bootstrap_attempts: list[str] = []

    def fake_run(argv: list[str], **_kw: Any) -> subprocess.CompletedProcess:
        if "bootstrap" in argv:
            bootstrap_attempts.append(" ".join(argv))
        return _completed(0)

    monkeypatch.setattr(lifecycle.subprocess, "run", fake_run)

    rc = lifecycle.start()
    assert rc == 0
    # Critical: no bootstrap fired — we short-circuited.
    assert bootstrap_attempts == []


def test_start_macos_short_circuit_kickstarts_dormant_watchdog(
    macos: None,
    installed_plists: tuple[Path, Path],
    cfg_loaded: HaltonConfig,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Daemon healthy, watchdog dormant → opportunistically kickstart
    the watchdog (cheap; brings the defensive layer back).
    """
    monkeypatch.setattr(
        lifecycle, "_poll_health_with_latency", lambda port, timeout=1.0: (True, 3.0)
    )

    pid_state = {"watchdog": None}

    def fake_pid(label: str) -> int | None:
        if label == lifecycle._LABEL:
            return 6968
        if label == lifecycle._WATCHDOG_LABEL:
            return pid_state["watchdog"]
        return None

    monkeypatch.setattr(lifecycle, "_launchctl_label_pid", fake_pid)

    kickstart_calls: list[str] = []

    def fake_kickstart(label: str, *, kill_existing: bool = True) -> tuple[int, str]:
        kickstart_calls.append(label)
        # Now watchdog has a PID.
        pid_state["watchdog"] = 7777
        return (0, "")

    monkeypatch.setattr(lifecycle, "_launchctl_kickstart", fake_kickstart)

    rc = lifecycle.start()
    assert rc == 0
    assert kickstart_calls == [lifecycle._WATCHDOG_LABEL]


def test_our_managed_pids_includes_edge_label(
    macos: None,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """v0.1.21.4: ``_our_managed_pids`` returns edge + userenv PIDs
    too, so ``_start_macos`` Step 3 doesn't false-flag our own running
    edge as an orphan port-squatter.
    """
    pid_map = {
        lifecycle._LABEL: 1001,
        lifecycle._WATCHDOG_LABEL: 1002,
        lifecycle._EDGE_LABEL: 6975,
        lifecycle._USERENV_LABEL: None,
    }
    monkeypatch.setattr(
        lifecycle, "_launchctl_label_pid", lambda label: pid_map.get(label)
    )
    pids = lifecycle._our_managed_pids()
    assert 1001 in pids
    assert 1002 in pids
    assert 6975 in pids, (
        "edge PID must be recognised as managed; otherwise `start` "
        "false-flags our own edge as a port-squatter (user-soak bug)."
    )


def test_start_macos_does_not_false_flag_own_edge(
    macos: None,
    installed_plists: tuple[Path, Path],
    cfg_loaded: HaltonConfig,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """End-to-end repro of the user-soak bug: edge PID 6975 holds the
    edge port, daemon is unhealthy at probe time (e.g. user just
    `stop`-ed the daemon), `start` must NOT refuse — PID 6975 is ours.
    """
    # /health unhealthy → falls through to port check.
    monkeypatch.setattr(
        lifecycle, "_poll_health_with_latency", lambda port, timeout=1.0: (False, None)
    )

    pid_map = {
        lifecycle._LABEL: None,
        lifecycle._WATCHDOG_LABEL: None,
        lifecycle._EDGE_LABEL: 6975,
        lifecycle._USERENV_LABEL: None,
    }
    monkeypatch.setattr(
        lifecycle, "_launchctl_label_pid", lambda label: pid_map.get(label)
    )

    # lsof reports our own edge holding the edge_port (9080 in
    # cfg_loaded.daemon.listen_port). 8765 is api_port — clear.
    def fake_lsof(port: int) -> list[int]:
        if port == 9080:
            return [6975]
        return []

    monkeypatch.setattr(lifecycle, "_lsof_pids_on_port", fake_lsof)
    monkeypatch.setattr(lifecycle.subprocess, "run", lambda *a, **kw: _completed(0))
    monkeypatch.setattr(
        lifecycle, "_start_probe_health", lambda port: (True, 1.0, 1.5)
    )
    monkeypatch.setattr(
        lifecycle,
        "_system_proxy_state",
        lambda host, port: ("enabled", "127.0.0.1:9080 on Wi-Fi"),
    )
    monkeypatch.setattr(
        lifecycle,
        "_latest_capture",
        lambda db_path: lifecycle._LatestCapture(found=False, db_missing=True),
    )

    rc = lifecycle.start()
    # Bug: was returning 1 because PID 6975 was treated as an orphan.
    assert rc == 0


def test_start_macos_still_refuses_real_squatter(
    macos: None,
    installed_plists: tuple[Path, Path],
    cfg_loaded: HaltonConfig,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Symmetry guard: a foreign Python process holding the edge port
    must STILL be rejected. The own-edge fix must not regress this.
    """
    monkeypatch.setattr(
        lifecycle, "_poll_health_with_latency", lambda port, timeout=1.0: (False, None)
    )
    # All our labels report no PID.
    monkeypatch.setattr(lifecycle, "_launchctl_label_pid", lambda label: None)
    monkeypatch.setattr(
        lifecycle,
        "_lsof_pids_on_port",
        lambda port: [99999] if port == 9080 else [],
    )
    monkeypatch.setattr(lifecycle, "_process_name", lambda pid: "rogue-python")

    rc = lifecycle.start()
    assert rc == 1
