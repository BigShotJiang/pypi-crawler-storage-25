"""Tests for the v0.1.13 PR3 background body-retention sweep.

Two angles:

* ``_run_sweep_once`` — single-shot helper. Asserts the structlog event
  shape and that the underlying purge function is invoked with the
  configured retention horizon.
* ``retention_sweep_loop`` — the long-lived loop. We drive it with a
  controllable async sleeper so the test can step the loop deterministically
  without waiting real seconds, then assert the sweep fired the expected
  number of times.

Both layers offload SQLite work via ``asyncio.to_thread``; the tests pass
in a stub purge function so no real DB is touched. Sister test file
``test_bodies_cli.py`` covers the ``purge_old_bodies`` integration end of
the same path against a real SQLite file.
"""

from __future__ import annotations

import asyncio
import logging
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any

import pytest
import structlog

from halton_meter.bodies import PurgeResult
from halton_meter.retention import _run_sweep_once, retention_sweep_loop


def _make_logger(records: list[dict[str, Any]]) -> structlog.stdlib.BoundLogger:
    """Configure a structlog instance that captures events into ``records``."""

    def _capture(_logger: Any, method_name: str, event_dict: dict[str, Any]) -> str:
        records.append({"_method": method_name, **event_dict})
        return ""

    structlog.configure(
        processors=[_capture],
        wrapper_class=structlog.stdlib.BoundLogger,
        logger_factory=structlog.stdlib.LoggerFactory(),
        cache_logger_on_first_use=False,
    )
    return structlog.get_logger("halton_meter.retention.test")


@pytest.mark.asyncio
async def test_run_sweep_once_logs_deleted_count(tmp_path: Path) -> None:
    """One sweep emits ``bodies.retention_sweep`` with deleted=N + elapsed_ms."""
    records: list[dict[str, Any]] = []
    log = _make_logger(records)

    db_path = tmp_path / "db.sqlite"

    captured_kwargs: dict[str, Any] = {}

    def fake_purge(path: Path, *, retention_days: int) -> PurgeResult:
        captured_kwargs["path"] = path
        captured_kwargs["retention_days"] = retention_days
        return PurgeResult(
            cutoff=datetime.now(tz=UTC) - timedelta(days=retention_days),
            rows_deleted=7,
            vacuumed=False,
            dry_run=False,
        )

    deleted = await _run_sweep_once(
        db_path,
        retention_days=42,
        log=log,
        purge_fn=fake_purge,
    )

    assert deleted == 7
    assert captured_kwargs == {"path": db_path, "retention_days": 42}

    assert len(records) == 1
    rec = records[0]
    assert rec["event"] == "bodies.retention_sweep"
    assert rec["deleted"] == 7
    assert rec["retention_days"] == 42
    assert isinstance(rec["elapsed_ms"], int)
    assert rec["elapsed_ms"] >= 0


@pytest.mark.asyncio
async def test_retention_loop_fires_each_tick(tmp_path: Path) -> None:
    """The loop calls the purge function once per scheduled tick.

    We control "time" via a fake sleeper that yields control on each
    iteration. After three controlled wakeups we cancel the task and
    assert the purge function fired three times (once per tick), each
    with the configured retention_days.
    """
    records: list[dict[str, Any]] = []
    log = _make_logger(records)

    call_count = 0

    def fake_purge(path: Path, *, retention_days: int) -> PurgeResult:
        nonlocal call_count
        call_count += 1
        return PurgeResult(
            cutoff=datetime.now(tz=UTC) - timedelta(days=retention_days),
            rows_deleted=call_count,  # arbitrary distinguishable value
            vacuumed=False,
            dry_run=False,
        )

    # Fake sleeper: each call yields control immediately so the loop body
    # runs on the very next event-loop pass. Limit to N iterations so the
    # loop terminates deterministically via CancelledError once we've
    # observed enough sweeps.
    ticks = 0
    target_ticks = 3
    done = asyncio.Event()

    async def fake_sleep(_seconds: float) -> None:
        nonlocal ticks
        ticks += 1
        if ticks > target_ticks:
            done.set()
            # Block forever once we've delivered the expected ticks; the
            # outer harness cancels the task after ``done`` is set.
            await asyncio.Event().wait()
        await asyncio.sleep(0)

    task = asyncio.create_task(
        retention_sweep_loop(
            tmp_path / "db.sqlite",
            retention_days=30,
            interval_seconds=999_999,  # never used — fake_sleep ignores it
            purge_fn=fake_purge,
            sleep_fn=fake_sleep,
            log=log,
        )
    )

    # Wait until we've observed the target number of ticks, then cancel.
    await asyncio.wait_for(done.wait(), timeout=2.0)
    task.cancel()
    with pytest.raises(asyncio.CancelledError):
        await task

    assert call_count == target_ticks

    # Each successful sweep emits exactly one log line.
    sweep_events = [r for r in records if r.get("event") == "bodies.retention_sweep"]
    assert len(sweep_events) == target_ticks
    for ev in sweep_events:
        assert ev["retention_days"] == 30


@pytest.mark.asyncio
async def test_retention_loop_swallows_purge_errors(tmp_path: Path) -> None:
    """A purge that raises is logged and the loop keeps running.

    Fail-open contract: a retention failure must NEVER take the daemon
    down. The next tick should still fire normally.
    """
    records: list[dict[str, Any]] = []
    log = _make_logger(records)
    # _run_sweep_once also routes through the standard logging module via
    # structlog's stdlib factory; silence it so pytest's log capture
    # doesn't surface the warning as a failure.
    logging.getLogger("halton_meter.retention.test").setLevel(logging.CRITICAL)

    call_idx = 0

    def fake_purge(path: Path, *, retention_days: int) -> PurgeResult:
        nonlocal call_idx
        call_idx += 1
        if call_idx == 1:
            msg = "simulated SQLite locked"
            raise RuntimeError(msg)
        return PurgeResult(
            cutoff=datetime.now(tz=UTC) - timedelta(days=retention_days),
            rows_deleted=0,
            vacuumed=False,
            dry_run=False,
        )

    ticks = 0
    target_ticks = 2
    done = asyncio.Event()

    async def fake_sleep(_seconds: float) -> None:
        nonlocal ticks
        ticks += 1
        if ticks > target_ticks:
            done.set()
            await asyncio.Event().wait()
        await asyncio.sleep(0)

    task = asyncio.create_task(
        retention_sweep_loop(
            tmp_path / "db.sqlite",
            retention_days=7,
            interval_seconds=999_999,
            purge_fn=fake_purge,
            sleep_fn=fake_sleep,
            log=log,
        )
    )

    await asyncio.wait_for(done.wait(), timeout=2.0)
    task.cancel()
    with pytest.raises(asyncio.CancelledError):
        await task

    # First call raised; second call returned cleanly. The loop should
    # have logged both: a failure event followed by a success.
    assert call_idx == target_ticks
    failed = [
        r
        for r in records
        if r.get("event") == "bodies.retention_sweep_failed"
    ]
    succeeded = [
        r for r in records if r.get("event") == "bodies.retention_sweep"
    ]
    assert len(failed) == 1
    assert len(succeeded) == 1
    assert succeeded[0]["deleted"] == 0
