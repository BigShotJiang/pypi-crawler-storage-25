"""
Tests for ~/.mitmproxy/mitmproxy-ca.pem private-key permission hardening.

mitmproxy-ca.pem contains the CA private key used to mint leaf certs for
intercepted TLS hosts. World-readable = anyone on the box can impersonate
any HTTPS site to any user with our CA trusted. This test pins 0o600 on
the .pem file and 0o700 on the parent directory.

Public certs (.cer/.p12/-cert.pem) carry no private-key material; we
deliberately do not touch them — they may legitimately stay at 0o644 so
other tools can read them for trust-chain inspection.
"""

from __future__ import annotations

import stat
import sys
from pathlib import Path

import pytest

import halton_meter.setup as setup_mod
from halton_meter.setup import tighten_mitmproxy_ca_permissions

pytestmark = pytest.mark.skipif(
    sys.platform == "win32",
    reason="POSIX file-mode bits don't apply on Windows",
)


def _redirect_ca(monkeypatch: pytest.MonkeyPatch, ca_dir: Path) -> None:
    """Point setup.MITMPROXY_CERT_PATH at a tmp ~/.mitmproxy clone."""
    monkeypatch.setattr(
        setup_mod, "MITMPROXY_CERT_PATH", ca_dir / "mitmproxy-ca-cert.pem"
    )


def test_tighten_ca_permissions_chmod_private_key_and_dir(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    ca_dir = tmp_path / ".mitmproxy"
    ca_dir.mkdir()
    ca_dir.chmod(0o755)

    private_key = ca_dir / "mitmproxy-ca.pem"
    private_key.write_text("-----BEGIN PRIVATE KEY-----\nfake\n-----END PRIVATE KEY-----\n")
    private_key.chmod(0o644)

    public_cert = ca_dir / "mitmproxy-ca-cert.cer"
    public_cert.write_bytes(b"\x00\x01")
    public_cert.chmod(0o644)

    _redirect_ca(monkeypatch, ca_dir)
    tighten_mitmproxy_ca_permissions()

    assert stat.S_IMODE(ca_dir.stat().st_mode) == 0o700
    assert stat.S_IMODE(private_key.stat().st_mode) == 0o600
    # Public cert unchanged — we deliberately don't touch it.
    assert stat.S_IMODE(public_cert.stat().st_mode) == 0o644


def test_tighten_ca_permissions_idempotent(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    ca_dir = tmp_path / ".mitmproxy"
    ca_dir.mkdir()
    ca_dir.chmod(0o700)

    private_key = ca_dir / "mitmproxy-ca.pem"
    private_key.write_text("x")
    private_key.chmod(0o600)

    _redirect_ca(monkeypatch, ca_dir)
    tighten_mitmproxy_ca_permissions()

    assert stat.S_IMODE(ca_dir.stat().st_mode) == 0o700
    assert stat.S_IMODE(private_key.stat().st_mode) == 0o600


def test_tighten_ca_permissions_no_dir_is_noop(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    ca_dir = tmp_path / ".mitmproxy-absent"
    _redirect_ca(monkeypatch, ca_dir)
    # Must not raise.
    tighten_mitmproxy_ca_permissions()
    assert not ca_dir.exists()


def test_generate_mitmproxy_cert_tightens_existing_cert(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """
    The skip-existing branch of generate_mitmproxy_cert still chmods.
    Pre-hardening installs left the .pem world-readable; this proves the
    next halton-meter init fixes it.
    """
    ca_dir = tmp_path / ".mitmproxy"
    ca_dir.mkdir()
    ca_dir.chmod(0o755)

    cert = ca_dir / "mitmproxy-ca-cert.pem"
    cert.write_text("public cert pem")
    cert.chmod(0o644)

    private_key = ca_dir / "mitmproxy-ca.pem"
    private_key.write_text("private key pem")
    private_key.chmod(0o644)

    _redirect_ca(monkeypatch, ca_dir)
    result = setup_mod.generate_mitmproxy_cert()

    assert result.done is True
    assert stat.S_IMODE(ca_dir.stat().st_mode) == 0o700
    assert stat.S_IMODE(private_key.stat().st_mode) == 0o600
