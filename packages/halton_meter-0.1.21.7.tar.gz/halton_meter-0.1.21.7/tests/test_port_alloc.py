"""Tests for ``halton_meter.port_alloc`` (v0.1.3 P0-5; v0.1.6 2C.2 split).

Auto-port-fallback: probe defaults; persist chosen tuple to runtime.toml;
honour user-pinned values from config.toml. The merged effective config
overlays defaults < runtime < config.toml.

v0.1.6 (2C.2): the user-facing proxy port was renamed
``listen_port`` -> ``edge_port`` and a new ``internal_port`` field was
added. Legacy ``listen_port`` keys in ``config.toml`` / ``runtime.toml``
are honoured as ``edge_port`` (deprecation warning logged for
``config.toml``; silent rewrite for ``runtime.toml`` on next persist).
"""

from __future__ import annotations

import socket
import textwrap
from pathlib import Path

import pytest

from halton_meter import port_alloc
from halton_meter.config import HaltonConfig


def _make_busy_listener(host: str, port: int) -> socket.socket:
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.bind((host, port))
    sock.listen(1)
    return sock


@pytest.fixture(autouse=True)
def _reset_legacy_warning(monkeypatch: pytest.MonkeyPatch) -> None:
    """The legacy `listen_port` deprecation warning is once-per-process;
    tests that expect to observe it (or to NOT observe it) need a clean
    latch each time. Ditto: tests that exercise legacy config.toml don't
    pollute later tests."""
    port_alloc._reset_legacy_warning_state()


# --------------------------------------------------------------------------- #
# allocate_ports                                                              #
# --------------------------------------------------------------------------- #


class TestAllocatePorts:
    def test_returns_defaults_when_all_three_free(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        runtime = tmp_path / "runtime.toml"
        cfg = HaltonConfig()
        # Stub the probe so we don't actually bind on the dev box.
        monkeypatch.setattr(port_alloc, "_is_port_free", lambda host, port: True)

        edge, internal, api = port_alloc.allocate_ports(
            cfg,
            edge_pinned=False,
            internal_pinned=False,
            api_pinned=False,
            runtime_path=runtime,
            persist=True,
        )
        assert edge == 8081
        assert internal == 8090
        assert api == 8765
        # When all three are at default, we do NOT write runtime.toml.
        assert not runtime.exists()

    def test_falls_back_when_edge_busy(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        runtime = tmp_path / "runtime.toml"
        cfg = HaltonConfig()

        # 8081 busy, 8082 free; 8090 free; 8765 free.
        def fake_probe(host: str, port: int) -> bool:
            return port not in (8081,)

        monkeypatch.setattr(port_alloc, "_is_port_free", fake_probe)

        edge, internal, api = port_alloc.allocate_ports(
            cfg,
            edge_pinned=False,
            internal_pinned=False,
            api_pinned=False,
            runtime_path=runtime,
        )
        assert edge == 8082
        assert internal == 8090
        assert api == 8765
        # runtime.toml persisted because edge drifted from default.
        assert runtime.exists()
        body = runtime.read_text(encoding="utf-8")
        assert "edge_port = 8082" in body
        assert "internal_port = 8090" in body
        assert "api_port = 8765" in body

    def test_falls_back_when_internal_busy(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        runtime = tmp_path / "runtime.toml"
        cfg = HaltonConfig()

        # 8090 busy, 8091 free; everything else free.
        def fake_probe(host: str, port: int) -> bool:
            return port != 8090

        monkeypatch.setattr(port_alloc, "_is_port_free", fake_probe)

        edge, internal, api = port_alloc.allocate_ports(
            cfg,
            edge_pinned=False,
            internal_pinned=False,
            api_pinned=False,
            runtime_path=runtime,
        )
        assert edge == 8081
        assert internal == 8091
        assert api == 8765
        assert runtime.exists()

    def test_falls_back_when_api_busy(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        runtime = tmp_path / "runtime.toml"
        cfg = HaltonConfig()

        def fake_probe(host: str, port: int) -> bool:
            return port != 8765

        monkeypatch.setattr(port_alloc, "_is_port_free", fake_probe)

        edge, internal, api = port_alloc.allocate_ports(
            cfg,
            edge_pinned=False,
            internal_pinned=False,
            api_pinned=False,
            runtime_path=runtime,
        )
        assert edge == 8081
        assert internal == 8090
        assert api == 8766
        assert runtime.exists()

    def test_pinned_edge_honoured_even_if_unavailable(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """When user pinned ``edge_port=8081`` in config.toml, we honour
        it regardless of availability — daemon will fail-fast on bind
        clash with a clear error rather than silently relocating."""
        runtime = tmp_path / "runtime.toml"
        cfg = HaltonConfig()  # default edge_port=8081
        monkeypatch.setattr(port_alloc, "_is_port_free", lambda host, port: False)

        edge, internal, api = port_alloc.allocate_ports(
            cfg,
            edge_pinned=True,  # pinned!
            internal_pinned=False,
            api_pinned=False,
            runtime_path=runtime,
        )
        # Edge is honoured (no probe).
        assert edge == 8081
        # Internal still falls back to default since every probe returns False.
        assert internal == 8090
        assert api == 8765

    def test_pinned_edge_in_internal_range_shifts_internal_probe(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Plan §8 Risk 4: if the user pinned ``edge_port=8095`` (within
        the default internal range 8090..8099), the internal probe range
        shifts to start at ``edge_port + 10`` = 8105 so we don't
        self-collide."""
        runtime = tmp_path / "runtime.toml"
        # Build a HaltonConfig with edge_port pinned at 8095. Use the
        # alias so we can also exercise the legacy kwarg path.
        from halton_meter.config import DaemonConfig
        from halton_meter.config import HaltonConfig as _HC

        cfg = _HC(daemon=DaemonConfig(edge_port=8095))

        # Probe answers True for 8105 only — proves we actually shifted.
        def fake_probe(host: str, port: int) -> bool:
            return port == 8105 or port == 8765

        monkeypatch.setattr(port_alloc, "_is_port_free", fake_probe)

        edge, internal, api = port_alloc.allocate_ports(
            cfg,
            edge_pinned=True,
            internal_pinned=False,
            api_pinned=False,
            runtime_path=runtime,
        )
        assert edge == 8095
        assert internal == 8105
        assert api == 8765

    def test_falls_back_to_default_when_every_candidate_busy(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """When all candidates busy: noisy fallback to default. Daemon
        will surface a clear bind error."""
        runtime = tmp_path / "runtime.toml"
        cfg = HaltonConfig()
        monkeypatch.setattr(port_alloc, "_is_port_free", lambda host, port: False)

        edge, internal, api = port_alloc.allocate_ports(
            cfg,
            edge_pinned=False,
            internal_pinned=False,
            api_pinned=False,
            runtime_path=runtime,
        )
        assert edge == 8081
        assert internal == 8090
        assert api == 8765

    def test_persist_false_skips_write(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        runtime = tmp_path / "runtime.toml"
        cfg = HaltonConfig()

        def fake_probe(host: str, port: int) -> bool:
            return port != 8081

        monkeypatch.setattr(port_alloc, "_is_port_free", fake_probe)

        edge, _internal, _api = port_alloc.allocate_ports(
            cfg,
            edge_pinned=False,
            internal_pinned=False,
            api_pinned=False,
            runtime_path=runtime,
            persist=False,
        )
        assert edge == 8082
        assert not runtime.exists()

    def test_legacy_listen_pinned_kwarg_maps_to_edge_pinned(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """v0.1.5 callers passing ``listen_pinned=`` continue to work —
        the value is mapped to ``edge_pinned=`` for one release window."""
        runtime = tmp_path / "runtime.toml"
        cfg = HaltonConfig()
        monkeypatch.setattr(port_alloc, "_is_port_free", lambda host, port: False)

        edge, _internal, _api = port_alloc.allocate_ports(
            cfg,
            listen_pinned=True,  # legacy kwarg
            api_pinned=False,
            runtime_path=runtime,
        )
        assert edge == 8081  # honoured the pin


# --------------------------------------------------------------------------- #
# load_effective_config                                                       #
# --------------------------------------------------------------------------- #


class TestLoadEffectiveConfig:
    def test_returns_defaults_when_neither_file_exists(
        self, tmp_path: Path
    ) -> None:
        cfg = port_alloc.load_effective_config(
            config_path=tmp_path / "missing-config.toml",
            runtime_path=tmp_path / "missing-runtime.toml",
        )
        assert cfg.daemon.edge_port == 8081
        assert cfg.daemon.internal_port == 8090
        assert cfg.daemon.api_port == 8765

    def test_runtime_overrides_defaults(self, tmp_path: Path) -> None:
        runtime = tmp_path / "runtime.toml"
        runtime.write_text(
            textwrap.dedent("""
                [daemon]
                edge_port = 8082
                internal_port = 8091
                api_port = 8766
            """),
            encoding="utf-8",
        )
        cfg = port_alloc.load_effective_config(
            config_path=tmp_path / "missing-config.toml",
            runtime_path=runtime,
        )
        assert cfg.daemon.edge_port == 8082
        assert cfg.daemon.internal_port == 8091
        assert cfg.daemon.api_port == 8766

    def test_config_overrides_runtime(self, tmp_path: Path) -> None:
        config = tmp_path / "config.toml"
        runtime = tmp_path / "runtime.toml"
        runtime.write_text(
            "[daemon]\nedge_port = 8082\napi_port = 8766\n",
            encoding="utf-8",
        )
        config.write_text(
            "[daemon]\nedge_port = 9999\n",
            encoding="utf-8",
        )
        cfg = port_alloc.load_effective_config(
            config_path=config, runtime_path=runtime
        )
        # config.toml's edge_port wins.
        assert cfg.daemon.edge_port == 9999
        # api_port not in config.toml -> takes from runtime.
        assert cfg.daemon.api_port == 8766

    def test_partial_runtime_only_one_port(self, tmp_path: Path) -> None:
        runtime = tmp_path / "runtime.toml"
        runtime.write_text(
            "[daemon]\nedge_port = 8085\n", encoding="utf-8"
        )
        cfg = port_alloc.load_effective_config(
            config_path=tmp_path / "missing.toml",
            runtime_path=runtime,
        )
        assert cfg.daemon.edge_port == 8085
        # api_port falls back to default because runtime didn't have it.
        assert cfg.daemon.api_port == 8765
        # internal_port also falls back to default.
        assert cfg.daemon.internal_port == 8090

    def test_garbage_runtime_ignored(self, tmp_path: Path) -> None:
        runtime = tmp_path / "runtime.toml"
        runtime.write_text("not valid toml = = = ", encoding="utf-8")
        cfg = port_alloc.load_effective_config(
            config_path=tmp_path / "missing.toml",
            runtime_path=runtime,
        )
        # Defaults preserved; garbage tomllib decode error swallowed.
        assert cfg.daemon.edge_port == 8081

    def test_legacy_listen_port_in_config_maps_to_edge(
        self, tmp_path: Path, caplog: pytest.LogCaptureFixture
    ) -> None:
        """v0.1.5 users with ``listen_port = 9000`` in config.toml see
        their pin honoured as ``edge_port`` (preserving the v0.1.5
        contract: the port my apps see is the port I pinned)."""
        config = tmp_path / "config.toml"
        config.write_text("[daemon]\nlisten_port = 9000\n", encoding="utf-8")
        cfg = port_alloc.load_effective_config(
            config_path=config,
            runtime_path=tmp_path / "missing-runtime.toml",
        )
        assert cfg.daemon.edge_port == 9000
        # internal_port still defaults.
        assert cfg.daemon.internal_port == 8090

    def test_legacy_listen_port_in_runtime_maps_silently(
        self, tmp_path: Path
    ) -> None:
        """v0.1.5 ``runtime.toml`` files with the legacy ``listen_port``
        key are read silently (no deprecation warning — the daemon owns
        runtime.toml and rewrites it on next persist)."""
        runtime = tmp_path / "runtime.toml"
        runtime.write_text(
            "[daemon]\nlisten_port = 8083\napi_port = 8767\n",
            encoding="utf-8",
        )
        cfg = port_alloc.load_effective_config(
            config_path=tmp_path / "missing-config.toml",
            runtime_path=runtime,
        )
        assert cfg.daemon.edge_port == 8083
        assert cfg.daemon.api_port == 8767


# --------------------------------------------------------------------------- #
# discover_and_persist_ports                                                  #
# --------------------------------------------------------------------------- #


class TestDiscoverAndPersistPorts:
    def test_detects_user_pinned_and_persists_only_runtime_drift(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        config = tmp_path / "config.toml"
        runtime = tmp_path / "runtime.toml"
        # User pins edge_port; api_port + internal_port are implicit.
        config.write_text(
            "[daemon]\nedge_port = 9000\n",
            encoding="utf-8",
        )

        # 9000 (pinned -> not probed). 8090 free; 8765 busy; 8766 free.
        def fake_probe(host: str, port: int) -> bool:
            if port == 8090:
                return True
            return port == 8766

        monkeypatch.setattr(port_alloc, "_is_port_free", fake_probe)

        edge, internal, api = port_alloc.discover_and_persist_ports(
            config_path=config, runtime_path=runtime
        )
        assert edge == 9000  # pinned
        assert internal == 8090
        assert api == 8766  # auto-allocated
        # runtime.toml persists the auto-allocated tuple.
        assert runtime.exists()
        body = runtime.read_text(encoding="utf-8")
        assert "api_port = 8766" in body
        assert "edge_port = 9000" in body
        assert "internal_port = 8090" in body


# --------------------------------------------------------------------------- #
# runtime.toml round-trip + migration                                         #
# --------------------------------------------------------------------------- #


def test_runtime_toml_round_trip(tmp_path: Path) -> None:
    runtime = tmp_path / "runtime.toml"
    port_alloc._write_runtime_toml(
        runtime, edge_port=8082, internal_port=8091, api_port=8770
    )
    rt = port_alloc._read_runtime_toml(runtime)
    assert rt == {"edge_port": 8082, "internal_port": 8091, "api_port": 8770}


def test_runtime_toml_legacy_listen_port_kwarg_back_compat(
    tmp_path: Path,
) -> None:
    """v0.1.5 callers passing only ``listen_port=`` continue to write a
    valid file. ``listen_port=`` maps to ``edge_port=`` and
    ``internal_port`` defaults to 8090. The on-disk file uses the
    canonical v0.1.6 keys."""
    runtime = tmp_path / "runtime.toml"
    port_alloc._write_runtime_toml(runtime, listen_port=8090, api_port=8770)
    body = runtime.read_text(encoding="utf-8")
    assert "edge_port = 8090" in body
    assert "internal_port = 8090" in body
    assert "api_port = 8770" in body
    # Re-read normalises to canonical keys.
    rt = port_alloc._read_runtime_toml(runtime)
    assert rt["edge_port"] == 8090
    assert rt["internal_port"] == 8090
    assert rt["api_port"] == 8770


def test_migrate_runtime_toml_v0_1_5_to_v0_1_6(tmp_path: Path) -> None:
    """Synthetic v0.1.5 runtime.toml -> rewritten with canonical keys."""
    runtime = tmp_path / "runtime.toml"
    runtime.write_text(
        "[daemon]\nlisten_port = 8081\napi_port = 8765\n",
        encoding="utf-8",
    )
    rewrote = port_alloc.migrate_runtime_toml(runtime)
    assert rewrote is True
    body = runtime.read_text(encoding="utf-8")
    assert "edge_port = 8081" in body
    assert "internal_port" in body
    assert "api_port = 8765" in body
    assert "listen_port" not in body


def test_migrate_runtime_toml_idempotent_on_canonical_file(
    tmp_path: Path,
) -> None:
    runtime = tmp_path / "runtime.toml"
    runtime.write_text(
        "[daemon]\nedge_port = 8081\ninternal_port = 8090\napi_port = 8765\n",
        encoding="utf-8",
    )
    before = runtime.read_text(encoding="utf-8")
    rewrote = port_alloc.migrate_runtime_toml(runtime)
    assert rewrote is False
    after = runtime.read_text(encoding="utf-8")
    assert before == after


def test_migrate_runtime_toml_missing_file_noop(tmp_path: Path) -> None:
    """Missing file -> False, no exception, no file created."""
    runtime = tmp_path / "missing.toml"
    rewrote = port_alloc.migrate_runtime_toml(runtime)
    assert rewrote is False
    assert not runtime.exists()


def test_migrate_runtime_toml_uses_collision_shifted_internal(
    tmp_path: Path,
) -> None:
    """If legacy ``listen_port`` was 8095 (within the default internal
    range 8090..8099), the migration picks an internal_port outside
    the collision window via ``_internal_probe_range_for``."""
    runtime = tmp_path / "runtime.toml"
    runtime.write_text(
        "[daemon]\nlisten_port = 8095\napi_port = 8765\n",
        encoding="utf-8",
    )
    rewrote = port_alloc.migrate_runtime_toml(runtime)
    assert rewrote is True
    body = runtime.read_text(encoding="utf-8")
    assert "edge_port = 8095" in body
    # Internal_port was shifted to 8105 (8095 + 10).
    assert "internal_port = 8105" in body


def test_write_runtime_toml_fsyncs_before_rename(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """PR 7 P2-2: ``_write_runtime_toml`` must fsync the temp-file fd
    before renaming it over the canonical path. Pins crash-safety —
    without fsync, a power loss between rename and disk-flush can
    leave runtime.toml present but empty.

    Spies on ``os.fsync`` and ``os.replace``; asserts fsync was
    called on the fd we wrote to AND that fsync's call ordered
    strictly before replace (mirrors system_proxy._atomic_write_json).
    v0.1.6: signature uses canonical ``edge_port=`` / ``internal_port=``.
    """
    import os as _os

    runtime = tmp_path / "runtime.toml"

    call_log: list[tuple[str, object]] = []

    real_fsync = _os.fsync
    real_replace = _os.replace
    real_write = _os.write

    written_fds: list[int] = []

    def spy_write(fd: int, data: bytes) -> int:
        written_fds.append(fd)
        return real_write(fd, data)

    def spy_fsync(fd: int) -> None:
        call_log.append(("fsync", fd))
        real_fsync(fd)

    def spy_replace(src: object, dst: object) -> None:
        call_log.append(("replace", (src, dst)))
        real_replace(src, dst)  # type: ignore[arg-type]

    monkeypatch.setattr(port_alloc.os, "write", spy_write)
    monkeypatch.setattr(port_alloc.os, "fsync", spy_fsync)
    monkeypatch.setattr(port_alloc.os, "replace", spy_replace)

    port_alloc._write_runtime_toml(
        runtime, edge_port=8082, internal_port=8091, api_port=8770
    )

    # (a) fsync was called.
    fsync_calls = [c for c in call_log if c[0] == "fsync"]
    assert fsync_calls, f"expected fsync to be called; got {call_log}"

    # (b) fsync was called on the same fd we wrote to.
    assert written_fds, "expected at least one os.write call"
    assert fsync_calls[0][1] == written_fds[0], (
        f"fsync fd {fsync_calls[0][1]} != write fd {written_fds[0]}"
    )

    # (c) fsync ordered strictly before replace — the whole point of
    # the atomic-write pattern.
    fsync_idx = next(i for i, c in enumerate(call_log) if c[0] == "fsync")
    replace_idx = next(i for i, c in enumerate(call_log) if c[0] == "replace")
    assert fsync_idx < replace_idx, (
        f"fsync must precede replace; got order {call_log}"
    )

    # And the file actually exists with the expected contents.
    assert runtime.exists()
    rt = port_alloc._read_runtime_toml(runtime)
    assert rt == {"edge_port": 8082, "internal_port": 8091, "api_port": 8770}


def test_remove_runtime_toml_idempotent(tmp_path: Path) -> None:
    target = tmp_path / "runtime.toml"
    # Missing -> no-op.
    port_alloc.remove_runtime_toml(target)
    # Exists -> removed.
    target.write_text("[daemon]\nedge_port = 8081\n", encoding="utf-8")
    assert target.exists()
    port_alloc.remove_runtime_toml(target)
    assert not target.exists()


def test_is_port_free_against_real_socket(tmp_path: Path) -> None:
    """Real socket round-trip: 0 means OS picks free port; we then
    confirm the same port returns False once we hold the listener."""
    # Pick an arbitrary high port the test harness probably isn't using.
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.bind(("127.0.0.1", 0))
    bound_port = sock.getsockname()[1]
    sock.listen(1)
    try:
        # While the socket holds the port, our probe must say "not free".
        assert port_alloc._is_port_free("127.0.0.1", bound_port) is False
    finally:
        sock.close()
    # After the socket releases, probe says "free" again (fallible on
    # SO_LINGER timing; assert weakly).
    # (Not asserting the True branch here to avoid timing flake on CI.)


# --------------------------------------------------------------------------- #
# Effective ports source-of-truth (v0.1.19.dev1, Phase 2 Bug B)               #
# --------------------------------------------------------------------------- #


class TestEffectivePorts:
    def test_round_trip_round(self, tmp_path: Path) -> None:
        path = tmp_path / "effective-ports.json"
        port_alloc.write_effective_ports(
            edge_port=8081,
            internal_port=8090,
            api_port=8765,
            pid=42,
            path=path,
        )
        out = port_alloc.read_effective_ports(path)
        assert out["edge_port"] == 8081
        assert out["internal_port"] == 8090
        assert out["api_port"] == 8765
        assert out["pid"] == 42
        assert out["schema_version"] == 1
        assert "bound_at" in out

    def test_missing_file_returns_empty(self, tmp_path: Path) -> None:
        assert port_alloc.read_effective_ports(tmp_path / "nope.json") == {}

    def test_corrupt_json_returns_empty(self, tmp_path: Path) -> None:
        path = tmp_path / "effective-ports.json"
        path.write_text("not json {{{")
        assert port_alloc.read_effective_ports(path) == {}

    def test_unknown_keys_tolerated(self, tmp_path: Path) -> None:
        # Forward-compat: a future version writes extra keys; today's
        # reader must not blow up.
        import json

        path = tmp_path / "effective-ports.json"
        path.write_text(
            json.dumps(
                {
                    "schema_version": 999,
                    "edge_port": 8081,
                    "internal_port": 8090,
                    "api_port": 8765,
                    "future_field": ["nested", "stuff"],
                }
            )
        )
        out = port_alloc.read_effective_ports(path)
        assert out["edge_port"] == 8081
        assert out["internal_port"] == 8090

    def test_edge_port_null_ok(self, tmp_path: Path) -> None:
        # Daemon-side write sets edge_port=None; reader filters non-int.
        path = tmp_path / "effective-ports.json"
        port_alloc.write_effective_ports(
            edge_port=None,
            internal_port=8090,
            api_port=8765,
            path=path,
        )
        out = port_alloc.read_effective_ports(path)
        assert "edge_port" not in out  # filtered: not an int
        assert out["internal_port"] == 8090
        assert out["api_port"] == 8765

    def test_remove_idempotent(self, tmp_path: Path) -> None:
        path = tmp_path / "effective-ports.json"
        port_alloc.write_effective_ports(
            edge_port=8081, internal_port=8090, api_port=8765, path=path
        )
        assert path.exists()
        port_alloc.remove_effective_ports(path)
        assert not path.exists()
        # Idempotent: a second remove on a missing file is a no-op.
        port_alloc.remove_effective_ports(path)
        assert not path.exists()

    def test_merge_edge_port_preserves_internal_api(self, tmp_path: Path) -> None:
        path = tmp_path / "effective-ports.json"
        # Daemon writes first (no edge port).
        port_alloc.write_effective_ports(
            edge_port=None, internal_port=8090, api_port=8765, path=path
        )
        # Edge merges its bound edge_port.
        port_alloc.merge_edge_port_into_effective_ports(8081, path=path)
        out = port_alloc.read_effective_ports(path)
        assert out["edge_port"] == 8081
        assert out["internal_port"] == 8090
        assert out["api_port"] == 8765

    def test_merge_edge_port_when_no_daemon_write_yet(self, tmp_path: Path) -> None:
        # Edge starts before daemon: merge writes a minimal file with only
        # edge_port; the daemon's later write will overlay internal/api.
        path = tmp_path / "effective-ports.json"
        port_alloc.merge_edge_port_into_effective_ports(8081, path=path)
        out = port_alloc.read_effective_ports(path)
        assert out["edge_port"] == 8081
        # internal_port and api_port absent (None gets filtered by reader).
        assert "internal_port" not in out
        assert "api_port" not in out

    def test_load_effective_config_prefers_effective_ports_over_runtime(
        self, tmp_path: Path
    ) -> None:
        runtime = tmp_path / "runtime.toml"
        runtime.write_text(
            textwrap.dedent(
                """
                [daemon]
                edge_port = 8082
                internal_port = 8091
                api_port = 8766
                """
            )
        )
        eff = tmp_path / "effective-ports.json"
        port_alloc.write_effective_ports(
            edge_port=8081, internal_port=8090, api_port=8765, path=eff
        )
        # Monkey-patch the module-level path so load_effective_config picks
        # up the test file.
        import halton_meter.port_alloc as pa

        original = pa.EFFECTIVE_PORTS_JSON_PATH
        pa.EFFECTIVE_PORTS_JSON_PATH = eff
        try:
            cfg = port_alloc.load_effective_config(
                config_path=tmp_path / "missing-config.toml",
                runtime_path=runtime,
            )
        finally:
            pa.EFFECTIVE_PORTS_JSON_PATH = original
        # effective-ports.json wins over runtime.toml.
        assert cfg.daemon.edge_port == 8081
        assert cfg.daemon.internal_port == 8090
        assert cfg.daemon.api_port == 8765

    def test_load_effective_config_falls_back_to_runtime_when_missing(
        self, tmp_path: Path
    ) -> None:
        runtime = tmp_path / "runtime.toml"
        runtime.write_text(
            textwrap.dedent(
                """
                [daemon]
                edge_port = 8082
                internal_port = 8091
                api_port = 8766
                """
            )
        )
        # No effective-ports.json — must fall back to runtime.toml.
        import halton_meter.port_alloc as pa

        original = pa.EFFECTIVE_PORTS_JSON_PATH
        pa.EFFECTIVE_PORTS_JSON_PATH = tmp_path / "absent.json"
        try:
            cfg = port_alloc.load_effective_config(
                config_path=tmp_path / "missing-config.toml",
                runtime_path=runtime,
            )
        finally:
            pa.EFFECTIVE_PORTS_JSON_PATH = original
        assert cfg.daemon.edge_port == 8082
        assert cfg.daemon.internal_port == 8091
        assert cfg.daemon.api_port == 8766


class TestPortConvergence:
    def test_stale_runtime_toml_removed_when_defaults_now_free(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """v0.1.19.dev1 Bug B: a previous boot wrote 8082/8091/8766 because
        the defaults were busy. Now defaults are free. The next boot's
        ``allocate_ports`` MUST remove the stale runtime.toml so readers
        do not keep overlaying the obsolete tuple on top of fresh defaults.
        """
        runtime = tmp_path / "runtime.toml"
        runtime.write_text(
            textwrap.dedent(
                """
                [daemon]
                edge_port = 8082
                internal_port = 8091
                api_port = 8766
                """
            )
        )
        # Stub the probe — defaults all free now.
        monkeypatch.setattr(port_alloc, "_is_port_free", lambda host, port: True)
        cfg = HaltonConfig()
        edge, internal, api = port_alloc.allocate_ports(
            cfg,
            edge_pinned=False,
            internal_pinned=False,
            api_pinned=False,
            runtime_path=runtime,
        )
        assert (edge, internal, api) == (
            port_alloc.EDGE_PORT_DEFAULT,
            port_alloc.INTERNAL_PORT_DEFAULT,
            port_alloc.API_PORT_DEFAULT,
        )
        # The stale file MUST be gone.
        assert not runtime.exists(), (
            "stale runtime.toml left on disk; readers would lock the "
            "daemon into the stale tuple"
        )
