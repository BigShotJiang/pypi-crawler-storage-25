"""
Redaction canary smoke test — standing requirement for every adapter.

Parametrised over every adapter in ``ADAPTER_REGISTRY`` so future adapter
PRs auto-participate without test changes. The cardinal-rule we enforce
here: an adapter MUST NOT smuggle request-body / request-header content
into the structured metadata it emits, into structured-log records, or
into any other string-serialisable side effect of ``parse_request`` /
``parse_response``.

How: we inject a synthetic high-entropy canary string into the request
headers (``Authorization`` + ``X-Api-Key``) and the request body. We then
run the adapter's ``parse_request`` and ``parse_response`` against a
canonical synthetic flow for that adapter. Finally we assert the canary
appears in zero of:

  * the ``RequestMetadata`` / ``ResponseMetadata`` field values,
  * any structlog record captured during the call,
  * the model_dump_json() serialisation of either metadata object.

The canary is a non-matching, recognisable sentinel: it does NOT match any
of the secret-detector regexes in ``halton_meter.redaction.credentials``,
so a leak through this test is a leak through the redaction layer's
fallback behaviour and not a regex-matching artefact.

When adding a new adapter:
  * Add an entry to ``ADAPTER_FLOWS`` mapping the adapter class to the
    canonical (path, request_body, response_body, content_type) flow it
    expects to see in production. The test will pick it up automatically.

When this test fails:
  * The adapter is leaking request content into metadata or logs.
  * Cardinal-rule violation — patch the adapter, do not loosen the test.
"""

from __future__ import annotations

import json
from typing import Any

import pytest
import structlog
from mitmproxy import http
from mitmproxy.test import tflow, tutils

from halton_meter.adapters import (
    AnthropicAdapter,
    GeminiAdapter,
    GeminiCodeAssistAdapter,
    OpenAIAdapter,
    OpenAICodexAdapter,
    XAIAdapter,
)
from halton_meter.proxy import ADAPTER_REGISTRY

# ---------------------------------------------------------------------------
# Canary
# ---------------------------------------------------------------------------

# Sentinel string. Picked to NOT match any redaction regex (no leading
# ``sk-ant-``, no AKIA prefix, no Bearer header context outside this test).
# A bare ``sk-FAKE-…`` is recognisable in failure messages and avoids
# colliding with any adapter's own marker tokens.
CANARY: str = "sk-FAKE-REDACTION-CANARY-DO-NOT-MATCH"


# ---------------------------------------------------------------------------
# Per-adapter canonical flow descriptors.
#
# Keyed by the adapter CLASS (not instance) so registry-order changes do
# not silently lose coverage. Every adapter currently in ADAPTER_REGISTRY
# must have an entry here — a missing entry fails the registry-coverage
# guard below.
# ---------------------------------------------------------------------------


def _json(obj: dict[str, Any]) -> bytes:
    return json.dumps(obj).encode()


# Each entry: (host, path, request_body_bytes, response_body_bytes, content_type)
ADAPTER_FLOWS: dict[type, tuple[str, str, bytes, bytes, str]] = {
    AnthropicAdapter: (
        "api.anthropic.com",
        "/v1/messages",
        _json(
            {
                "model": "claude-opus-4-7",
                "messages": [{"role": "user", "content": f"hello {CANARY}"}],
                "max_tokens": 10,
            }
        ),
        _json(
            {
                "id": "msg_x",
                "model": "claude-opus-4-7",
                "content": [{"type": "text", "text": "hi"}],
                "usage": {"input_tokens": 10, "output_tokens": 5},
            }
        ),
        "application/json",
    ),
    OpenAIAdapter: (
        "api.openai.com",
        "/v1/chat/completions",
        _json(
            {
                "model": "gpt-4.1",
                "messages": [{"role": "user", "content": f"hello {CANARY}"}],
            }
        ),
        _json(
            {
                "id": "chatcmpl-x",
                "model": "gpt-4.1",
                "choices": [{"message": {"content": "hi"}}],
                "usage": {"prompt_tokens": 10, "completion_tokens": 5, "total_tokens": 15},
            }
        ),
        "application/json",
    ),
    GeminiAdapter: (
        "generativelanguage.googleapis.com",
        "/v1beta/models/gemini-2.5-pro:generateContent",
        _json(
            {
                "contents": [{"parts": [{"text": f"hello {CANARY}"}]}],
            }
        ),
        _json(
            {
                "candidates": [{"content": {"parts": [{"text": "hi"}]}}],
                "usageMetadata": {
                    "promptTokenCount": 10,
                    "candidatesTokenCount": 5,
                    "totalTokenCount": 15,
                },
            }
        ),
        "application/json",
    ),
    GeminiCodeAssistAdapter: (
        "cloudcode-pa.googleapis.com",
        "/v1internal:generateContent",
        _json(
            {
                "model": "gemini-3-flash-preview",
                "request": {
                    "contents": [{"parts": [{"text": f"hello {CANARY}"}]}],
                },
            }
        ),
        _json(
            {
                "response": {
                    "candidates": [{"content": {"parts": [{"text": "hi"}]}}],
                    "usageMetadata": {
                        "promptTokenCount": 10,
                        "candidatesTokenCount": 5,
                        "totalTokenCount": 15,
                    },
                }
            }
        ),
        "application/json",
    ),
    OpenAICodexAdapter: (
        "chatgpt.com",
        "/backend-api/codex/responses",
        _json(
            {
                "model": "gpt-5.3-codex",
                "input": [{"role": "user", "content": f"hello {CANARY}"}],
            }
        ),
        _json(
            {
                "id": "resp_x",
                "model": "gpt-5.3-codex",
                "usage": {
                    "input_tokens": 10,
                    "output_tokens": 5,
                    "input_tokens_details": {"cached_tokens": 0},
                    "output_tokens_details": {"reasoning_tokens": 0},
                    "total_tokens": 15,
                },
            }
        ),
        "application/json",
    ),
    XAIAdapter: (
        "api.x.ai",
        "/v1/chat/completions",
        _json(
            {
                "model": "grok-4",
                "messages": [{"role": "user", "content": f"hello {CANARY}"}],
            }
        ),
        _json(
            {
                "id": "chatcmpl-x",
                "model": "grok-4",
                "choices": [{"message": {"content": "hi"}}],
                "usage": {"prompt_tokens": 10, "completion_tokens": 5, "total_tokens": 15},
            }
        ),
        "application/json",
    ),
}


# ---------------------------------------------------------------------------
# Registry coverage guard
# ---------------------------------------------------------------------------


def test_every_registered_adapter_has_a_canary_flow() -> None:
    """Every adapter wired into ``ADAPTER_REGISTRY`` must have a flow
    descriptor in ``ADAPTER_FLOWS`` so it auto-participates in the
    canary smoke test. New-adapter PRs that forget to add a descriptor
    fail here — the redaction guarantee is a STANDING requirement, not
    an opt-in.
    """
    registered_classes = {type(a) for a in ADAPTER_REGISTRY}
    described_classes = set(ADAPTER_FLOWS.keys())
    missing = registered_classes - described_classes
    assert not missing, (
        f"adapters in ADAPTER_REGISTRY without a redaction-canary flow: "
        f"{sorted(c.__name__ for c in missing)} — add an entry to "
        f"daemon/tests/security/test_redaction.py::ADAPTER_FLOWS"
    )


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _build_flow(
    host: str,
    path: str,
    request_body: bytes,
    response_body: bytes,
    content_type: str,
) -> http.HTTPFlow:
    """Construct a synthetic mitmproxy flow with the canary in headers
    and body."""
    req = tutils.treq(host=host, port=443, path=path)
    req.content = request_body
    # Canary in BOTH common header surfaces — every adapter must ignore.
    req.headers["Authorization"] = f"Bearer {CANARY}"
    req.headers["X-Api-Key"] = CANARY
    req.headers["X-Custom-Canary"] = CANARY

    flow = tflow.tflow(req=req)
    flow.response = tutils.tresp(content=response_body)
    flow.response.headers["content-type"] = content_type
    return flow


def _stringify(value: Any) -> str:
    """Best-effort string-serialise any side-effect carrier so we can
    grep the canary out of it."""
    if value is None:
        return ""
    if isinstance(value, (str, bytes, bytearray)):
        return value.decode() if isinstance(value, (bytes, bytearray)) else value
    try:
        return json.dumps(value, default=str)
    except (TypeError, ValueError):
        return repr(value)


# ---------------------------------------------------------------------------
# Parametrised canary smoke
# ---------------------------------------------------------------------------


@pytest.mark.parametrize(
    "adapter",
    ADAPTER_REGISTRY,
    ids=lambda a: type(a).__name__,
)
def test_adapter_does_not_leak_canary_into_metadata_or_logs(
    adapter: Any,
    caplog: pytest.LogCaptureFixture,
) -> None:
    """For every adapter in the registry: inject the canary into request
    headers + body, run parse_request + parse_response, and assert the
    canary does NOT surface in any string-serialisable output.

    Surfaces checked (zero leaks permitted):
      1. RequestMetadata field values (provider/model/stream/started_at).
      2. ResponseMetadata field values (token counts/latency_ms/etc).
      3. ``model_dump_json()`` of both — catches any field a future
         metadata schema adds without the test maintainer noticing.
      4. Every captured log record's message + structlog event-dict
         (via caplog).
    """
    cls = type(adapter)
    if cls not in ADAPTER_FLOWS:
        pytest.skip(f"no canary flow for {cls.__name__} (registry-guard test enforces presence)")

    host, path, req_body, resp_body, content_type = ADAPTER_FLOWS[cls]
    flow = _build_flow(host, path, req_body, resp_body, content_type)

    # Configure structlog -> stdlib logging so caplog captures records.
    # Save & restore the global config so this test does not bleed into
    # other tests' logging behaviour (structlog.configure is process-
    # global; without restore the daemon's own structlog setup is
    # clobbered for the rest of the session).
    saved_config = structlog.get_config()
    structlog.configure(
        processors=[
            structlog.stdlib.add_log_level,
            structlog.processors.JSONRenderer(),
        ],
        wrapper_class=structlog.stdlib.BoundLogger,
        logger_factory=structlog.stdlib.LoggerFactory(),
        cache_logger_on_first_use=False,
    )
    try:
        with caplog.at_level("DEBUG"):
            req_meta = adapter.parse_request(flow)
            resp_meta = adapter.parse_response(flow, req_meta)
    finally:
        structlog.configure(**saved_config)

    # Surface 1+2+3: structured metadata fields and their JSON
    # serialisation.
    assert CANARY not in _stringify(req_meta.model_dump()), (
        f"{cls.__name__}: canary leaked into RequestMetadata.model_dump()"
    )
    assert CANARY not in req_meta.model_dump_json(), (
        f"{cls.__name__}: canary leaked into RequestMetadata.model_dump_json()"
    )
    if resp_meta is not None:
        assert CANARY not in _stringify(resp_meta.model_dump()), (
            f"{cls.__name__}: canary leaked into ResponseMetadata.model_dump()"
        )
        assert CANARY not in resp_meta.model_dump_json(), (
            f"{cls.__name__}: canary leaked into ResponseMetadata.model_dump_json()"
        )

    # Surface 4: every captured log record. Check both the rendered
    # message and the raw extras (record.__dict__) to catch structlog
    # event-dict fields the rendered message may have stripped.
    for record in caplog.records:
        rendered = record.getMessage()
        assert CANARY not in rendered, (
            f"{cls.__name__}: canary leaked into log message: {rendered!r}"
        )
        for key, val in record.__dict__.items():
            if key in ("args", "exc_info", "stack_info"):
                continue
            assert CANARY not in _stringify(val), (
                f"{cls.__name__}: canary leaked into log record field "
                f"{key!r}: {_stringify(val)!r}"
            )
