"""Daemon observability primitives — heartbeat + asyncio task crash hook.

Closes the silent-failure observability gap surfaced by the v0.1.15 soak
(see ``memory/plans/2026-05-02-v0.1.16-stability-cycle.md`` § Q4).

Two primitives:

* :func:`install_task_crash_handler` overrides ``loop.set_exception_handler``
  so any asyncio task that crashes emits a structured ``daemon.task_crashed``
  log line (today: silent, traceback swallowed). Wraps any previously
  installed handler so the default behaviour still runs after we log.
* :func:`heartbeat_loop` is the coroutine wired by the daemon at startup.
  Every 30 seconds it emits one INFO ``daemon.heartbeat`` line carrying
  listener / DB / FD state. A monitorable signal that any tail / log
  collector can consume.

Both are designed to NEVER raise from the daemon's perspective:

* The crash handler logs and re-raises into the previous handler — the
  asyncio default itself just logs to stderr; we never swallow.
* Every heartbeat probe is wrapped: a probe failure flips that one
  field to ``False`` but the heartbeat still emits.
"""

from __future__ import annotations

import asyncio
import os
import sqlite3
from collections.abc import Callable
from pathlib import Path
from typing import Any

import structlog

log = structlog.get_logger("halton_meter.observability")

# Heartbeat cadence — Q4.1 spec: every 30 seconds.
HEARTBEAT_INTERVAL_SECONDS = 30.0


# ---------------------------------------------------------------------------
# Asyncio task crash hook
# ---------------------------------------------------------------------------


def install_task_crash_handler(
    loop: asyncio.AbstractEventLoop | None = None,
) -> Callable[[asyncio.AbstractEventLoop, dict[str, Any]], None] | None:
    """Install a ``loop.set_exception_handler`` that logs task crashes.

    Returns the previous handler so callers can restore it on shutdown
    (rarely needed — the loop is torn down with the process). Idempotent:
    calling twice replaces our handler with a fresh one but still wraps
    whatever was installed before this call.

    The handler logs ``daemon.task_crashed`` at ERROR with the task name,
    exception type, message, and traceback. It then chains to the
    previous handler (or asyncio's default) so we never swallow an
    exception we ought to surface.

    Crucially, the handler itself MUST NOT raise — exception handlers
    that throw inside asyncio's loop trip the loop into an unrecoverable
    state. Every branch is defensive.
    """
    if loop is None:
        loop = asyncio.get_event_loop()

    previous = loop.get_exception_handler()

    def _handler(
        loop_: asyncio.AbstractEventLoop, context: dict[str, Any]
    ) -> None:
        try:
            exception = context.get("exception")
            task = context.get("task") or context.get("future")
            task_name: str | None = None
            if task is not None:
                # asyncio.Task has get_name(); Future does not.
                getter = getattr(task, "get_name", None)
                if callable(getter):
                    try:
                        task_name = getter()
                    except Exception:  # pragma: no cover — defensive
                        task_name = None

            exc_type = type(exception).__name__ if exception is not None else None
            exc_msg = str(exception) if exception is not None else None
            message = context.get("message")

            log.error(
                "daemon.task_crashed",
                task=task_name,
                exception_type=exc_type,
                exception_message=exc_msg,
                message=message,
                exc_info=exception,
            )
        except Exception as exc:  # pragma: no cover — defensive
            # Last-ditch stderr write; handler must never raise.
            try:
                import sys as _sys

                print(
                    f"[halton-meter] task_crashed handler internal error: {exc}",
                    file=_sys.stderr,
                    flush=True,
                )
            except Exception:
                pass

        # Chain to the previous handler (or asyncio's default) so we
        # NEVER swallow the exception's downstream effects. The default
        # handler logs the traceback to stderr — we want both.
        try:
            if previous is not None:
                previous(loop_, context)
            else:
                loop_.default_exception_handler(context)
        except Exception:  # pragma: no cover — defensive
            pass

    loop.set_exception_handler(_handler)
    return previous


# ---------------------------------------------------------------------------
# Listener heartbeat
# ---------------------------------------------------------------------------


def _probe_port_listening(port: int) -> bool:
    """Return True iff the current process holds a LISTEN socket on
    ``port``. Uses ``psutil`` introspection of the process's own socket
    table — zero network syscalls, no risk of looping back through the
    proxy itself.
    """
    try:
        import psutil  # type: ignore[import-untyped]

        proc = psutil.Process(os.getpid())
        # ``net_connections`` is the modern API; ``connections`` works on
        # older psutil. Prefer the newer name when available.
        getter = getattr(proc, "net_connections", None) or proc.connections
        for conn in getter(kind="tcp"):
            status = getattr(conn, "status", None)
            laddr = getattr(conn, "laddr", None)
            if status == "LISTEN" and laddr is not None and laddr.port == port:
                return True
        return False
    except Exception:
        return False


def _probe_db_readable(db_path: Path) -> bool:
    """Return True iff the SQLite DB at ``db_path`` accepts a read.

    The probe is read-only by design (Q4.1 brief: heartbeat MUST NOT be
    a write path). Uses sync sqlite3 in a fresh connection so it can run
    from inside the heartbeat task without contending for any aiosqlite
    connection pool.
    """
    try:
        # ``uri=True`` + ``mode=ro`` opens read-only; if the file exists
        # but cannot be opened, this raises. If the file doesn't exist,
        # this also raises — which is the correct False answer.
        uri = f"file:{db_path}?mode=ro"
        with sqlite3.connect(uri, uri=True, timeout=1.0) as conn:
            cur = conn.execute("SELECT COUNT(*) FROM requests LIMIT 1")
            cur.fetchone()
        return True
    except Exception:
        return False


def _probe_open_fds() -> int:
    """Return a rough count of currently open file descriptors for this
    process. Used as an early-warning signal for FD exhaustion (Bug 4).

    Returns ``-1`` on failure rather than raising — the heartbeat must
    always emit a line.
    """
    try:
        import psutil  # type: ignore[import-untyped]

        proc = psutil.Process(os.getpid())
        files = 0
        conns = 0
        try:
            files = len(proc.open_files())
        except Exception:
            files = 0
        try:
            getter = getattr(proc, "net_connections", None) or proc.connections
            conns = len(getter(kind="inet"))
        except Exception:
            conns = 0
        return files + conns
    except Exception:
        return -1


def emit_heartbeat(
    *,
    mitm_port: int,
    api_port: int,
    db_path: Path,
    probe_mitm: Callable[[int], bool] = _probe_port_listening,
    probe_api: Callable[[int], bool] = _probe_port_listening,
    probe_db: Callable[[Path], bool] = _probe_db_readable,
    probe_fds: Callable[[], int] = _probe_open_fds,
) -> dict[str, Any]:
    """Emit one ``daemon.heartbeat`` log line and return the payload.

    Pure dispatch — every probe is wrapped so a probe failure never
    aborts the heartbeat. Returned dict mirrors the logged payload so
    tests can assert on it without parsing log records.

    The probe callables are injectable so unit tests can drive the
    heartbeat without spinning up real listeners or a real SQLite file.
    """
    try:
        mitm_listening = bool(probe_mitm(mitm_port))
    except Exception:
        mitm_listening = False
    try:
        api_listening = bool(probe_api(api_port))
    except Exception:
        api_listening = False
    try:
        db_readable = bool(probe_db(db_path))
    except Exception:
        db_readable = False
    try:
        open_fds = int(probe_fds())
    except Exception:
        open_fds = -1

    payload: dict[str, Any] = {
        "mitm_port": mitm_port,
        "mitm_listening": mitm_listening,
        "api_port": api_port,
        "api_listening": api_listening,
        # Q4.1 brief uses ``db_writeable`` in the example log line; we
        # probe read-only (a write probe would make the heartbeat itself
        # a write path, which the brief explicitly forbids). The field
        # name mirrors what the brief specified so consumers / log
        # tailers can rely on a stable key.
        "db_writeable": db_readable,
        "open_fds": open_fds,
    }
    try:
        log.info("daemon.heartbeat", **payload)
    except Exception:  # pragma: no cover — defensive
        pass
    return payload


async def heartbeat_loop(
    *,
    mitm_port: int,
    api_port: int,
    db_path: Path,
    interval: float = HEARTBEAT_INTERVAL_SECONDS,
    probe_mitm: Callable[[int], bool] = _probe_port_listening,
    probe_api: Callable[[int], bool] = _probe_port_listening,
    probe_db: Callable[[Path], bool] = _probe_db_readable,
    probe_fds: Callable[[], int] = _probe_open_fds,
) -> None:
    """Long-lived asyncio task: emit a heartbeat every ``interval`` seconds.

    Cancellable on daemon shutdown. Per-tick failures are absorbed (the
    loop never dies because of a bad probe).
    """
    while True:
        try:
            await asyncio.sleep(interval)
            emit_heartbeat(
                mitm_port=mitm_port,
                api_port=api_port,
                db_path=db_path,
                probe_mitm=probe_mitm,
                probe_api=probe_api,
                probe_db=probe_db,
                probe_fds=probe_fds,
            )
        except asyncio.CancelledError:
            raise
        except Exception as exc:  # pragma: no cover — defensive
            try:
                log.warning("daemon.heartbeat_tick_error", error=str(exc))
            except Exception:
                pass
