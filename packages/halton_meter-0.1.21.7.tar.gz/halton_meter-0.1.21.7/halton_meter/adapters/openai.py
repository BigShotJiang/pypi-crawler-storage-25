"""
OpenAI provider adapter.

Handles api.openai.com — chat completions, the Responses API, and embeddings.
Both non-streaming JSON and streaming SSE bodies are parsed in a single pass
after mitmproxy has accumulated the full body.

Endpoints in scope (multi-provider PR1, 2026-05-02):
  POST /v1/chat/completions   — primary chat surface (streaming + non-streaming)
  POST /v1/responses           — Responses API (o-series reasoning models live here)
  POST /v1/embeddings          — input-token-only billing

Endpoints filtered OUT via ``matches_url``:
  /v1/moderations              — free endpoint; would clutter the DB with $0 rows.

Token count locations in the OpenAI API:

Non-streaming chat completions / responses:
    response body → top-level "usage" object:
        prompt_tokens                                    → input_tokens
        completion_tokens                                → output_tokens
        completion_tokens_details.reasoning_tokens       → thinking_tokens (o-series)
        prompt_tokens_details.cached_tokens              → cache_read_tokens
    (No "cache write" concept — caches are auto-managed server-side. cache_write=0.)

Streaming chat completions (SSE, gated by stream_options.include_usage=true):
    Walk ``data: {…}`` chunks; the FINAL chunk before ``data: [DONE]`` carries
    the ``usage`` object. If the client did NOT set include_usage=true, no
    chunk carries usage and we mark tokens_complete=False (logged as
    ``adapter.openai.streaming_no_usage_block`` so the gap can be quantified).

Streaming Responses API (SSE):
    Walk events; the ``response.completed`` event payload (typed via
    ``"type": "response.completed"`` on its data object) carries ``usage``
    on the nested ``response`` object.

Embeddings:
    response body → "usage" object: prompt_tokens (only). output_tokens=0.
    No stream concept.

Reasoning tokens (o1 / o1-pro / o3 / o3-mini / o4-mini):
    OpenAI bills these at the same rate as completion tokens. Captured in
    ``thinking_tokens``; the pricing path routes ``thinking_tokens`` through
    the model's ``thinking`` rate which we set equal to ``output`` for
    every OpenAI model in ``OPENAI_RATES``.
"""

from __future__ import annotations

import json
import time
from typing import Any, ClassVar

import structlog
from mitmproxy import http

from halton_meter.adapters.base import RequestMetadata, ResponseMetadata

log = structlog.get_logger()


class OpenAIAdapter:
    """
    Adapter for api.openai.com.

    Stateless and pure: ``parse_request`` and ``parse_response`` never raise,
    never touch the filesystem, and never make network calls. Parse failures
    return zero-valued metadata with ``tokens_complete=False`` so the daemon
    keeps logging the request shell rather than dropping it.
    """

    name: ClassVar[str] = "openai"
    domains: ClassVar[list[str]] = ["api.openai.com"]

    def matches(self, host: str) -> bool:
        """Match api.openai.com exactly, with optional :port suffix.

        Same exact-match-plus-port-carve-out shape as the Anthropic adapter
        — guards against ``api.openai.com.evil.com`` and
        ``evil.api.openai.com``.
        """
        return host == "api.openai.com" or host.startswith("api.openai.com:")

    def matches_url(self, host: str, path: str) -> bool:
        """Path-level filter on top of ``matches(host)``.

        Accepts the three metering-relevant endpoints (chat completions,
        responses, embeddings). Explicitly rejects /v1/moderations (free
        endpoint) and everything else on api.openai.com.
        """
        if not self.matches(host):
            return False
        # Billable endpoints. Use startswith so query-string variants pass through.
        if path.startswith("/v1/chat/completions"):
            return True
        if path.startswith("/v1/responses"):
            return True
        if path.startswith("/v1/embeddings"):
            return True
        # Everything else (including /v1/moderations and other non-billable paths)
        return False

    def parse_request(self, flow: http.HTTPFlow) -> RequestMetadata:
        """Extract model name and stream flag from the request body.

        Both /v1/chat/completions and /v1/responses use the same JSON body
        shape: ``{"model": "...", "stream": true|false, ...}``. Embeddings
        carry ``model`` but no ``stream`` flag — defaults to False.

        Non-JSON or empty bodies return defaults; never raises.
        """
        model = "unknown"
        stream = False
        try:
            body = flow.request.get_text(strict=False) or ""
            if body:
                data = json.loads(body)
                model = data.get("model", "unknown")
                stream = bool(data.get("stream", False))
        except (json.JSONDecodeError, UnicodeDecodeError):
            # Non-JSON body (e.g. multipart audio uploads on out-of-scope
            # endpoints) is expected; skip silently.
            pass

        return RequestMetadata(
            provider=self.name,
            model=model,
            stream=stream,
            started_at=time.monotonic(),
        )

    def parse_response(
        self,
        flow: http.HTTPFlow,
        request_meta: RequestMetadata,
    ) -> ResponseMetadata:
        """Extract token counts from the completed response body.

        Three branches:
          1. Non-streaming JSON  — parse body, read usage object.
          2. Streaming chat completions (SSE) — walk ``data:`` chunks,
             find the chunk with usage. Mark tokens_complete=False if no
             chunk carries usage (client did not set include_usage=true).
          3. Streaming Responses API (SSE) — walk events, find the
             ``response.completed`` payload, pull usage from it.

        Embeddings flow through branch 1 (no streaming).
        """
        latency_ms = (time.monotonic() - request_meta.started_at) * 1000
        content_type = flow.response.headers.get("content-type", "")
        is_sse = "text/event-stream" in content_type
        path = flow.request.path or ""

        input_tokens = 0
        output_tokens = 0
        thinking_tokens = 0
        cache_read_tokens = 0
        cache_write_tokens = 0
        tokens_complete = True

        try:
            body = flow.response.get_text(strict=False) or ""

            if is_sse:
                is_responses_api = path.startswith("/v1/responses")
                (
                    input_tokens,
                    output_tokens,
                    thinking_tokens,
                    cache_read_tokens,
                    tokens_complete,
                ) = self._parse_sse(body, is_responses_api=is_responses_api)
            else:
                data = json.loads(body)
                usage = data.get("usage") or {}
                (
                    input_tokens,
                    output_tokens,
                    thinking_tokens,
                    cache_read_tokens,
                ) = self._extract_usage_fields(usage)

        except Exception as exc:
            tokens_complete = False
            log.error(
                "adapter.parse_response.failed",
                provider=self.name,
                error=str(exc),
                exc_info=True,
            )

        return ResponseMetadata(
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            thinking_tokens=thinking_tokens,
            cache_read_tokens=cache_read_tokens,
            cache_write_tokens=cache_write_tokens,
            tokens_complete=tokens_complete,
            latency_ms=latency_ms,
        )

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _extract_usage_fields(usage: dict[str, Any]) -> tuple[int, int, int, int]:
        """Pull (input, output, thinking, cache_read) from an OpenAI usage object.

        OpenAI ships TWO usage shapes:
          - Chat Completions / Embeddings:
              prompt_tokens, completion_tokens,
              prompt_tokens_details.cached_tokens,
              completion_tokens_details.reasoning_tokens
          - Responses API:
              input_tokens, output_tokens,
              input_tokens_details.cached_tokens,
              output_tokens_details.reasoning_tokens

        Both are accepted. Each lookup falls through ``or 0`` so any missing
        nested block is treated as zero. Embeddings responses carry only
        ``prompt_tokens`` and the helper correctly returns zeros for the
        other three.
        """
        input_tokens = int(
            usage.get("prompt_tokens", usage.get("input_tokens", 0)) or 0
        )
        output_tokens = int(
            usage.get("completion_tokens", usage.get("output_tokens", 0)) or 0
        )

        completion_details = (
            usage.get("completion_tokens_details")
            or usage.get("output_tokens_details")
            or {}
        )
        thinking_tokens = int(completion_details.get("reasoning_tokens", 0) or 0)

        prompt_details = (
            usage.get("prompt_tokens_details")
            or usage.get("input_tokens_details")
            or {}
        )
        cache_read_tokens = int(prompt_details.get("cached_tokens", 0) or 0)

        return input_tokens, output_tokens, thinking_tokens, cache_read_tokens

    def _parse_sse(
        self, body: str, *, is_responses_api: bool
    ) -> tuple[int, int, int, int, bool]:
        """Walk SSE chunks and return (input, output, thinking, cache_read, complete).

        For chat completions, the ``usage`` object lives on the FINAL
        ``data: {…}`` chunk (when the client set
        ``stream_options.include_usage=true``). The earlier chunks have
        ``"usage": null`` or no key at all — we keep walking and use the
        last non-null value seen.

        For the Responses API, ``usage`` is carried on the
        ``response.completed`` event's ``response`` object.

        ``complete`` is False if no usage block is found in the stream
        (the common case when clients don't opt into ``include_usage``).
        """
        input_tokens = 0
        output_tokens = 0
        thinking_tokens = 0
        cache_read_tokens = 0
        found_usage = False

        for raw_line in body.splitlines():
            line = raw_line.strip()
            if not line.startswith("data:"):
                continue
            raw_data = line[len("data:") :].strip()
            if raw_data in ("[DONE]", ""):
                continue
            try:
                payload = json.loads(raw_data)
            except json.JSONDecodeError:
                continue

            usage = self._extract_usage_payload(
                payload, is_responses_api=is_responses_api
            )
            if usage:
                found_usage = True
                (
                    input_tokens,
                    output_tokens,
                    thinking_tokens,
                    cache_read_tokens,
                ) = self._extract_usage_fields(usage)

        if not found_usage:
            log.debug(
                "adapter.openai.streaming_no_usage_block",
                provider=self.name,
                hint="client likely did not set stream_options.include_usage=true",
            )
            return (0, 0, 0, 0, False)

        return (input_tokens, output_tokens, thinking_tokens, cache_read_tokens, True)

    @staticmethod
    def _extract_usage_payload(
        payload: dict[str, Any], *, is_responses_api: bool
    ) -> dict[str, Any] | None:
        """Pull the ``usage`` dict out of one SSE chunk.

        Chat completions: payload root carries ``"usage": {...}`` (or null
        on intermediate chunks) on the final chunk when include_usage=true.

        Responses API: the ``response.completed`` event's data payload has
        ``"type": "response.completed"`` and a nested ``response`` object
        whose ``usage`` field carries the totals.
        """
        if is_responses_api:
            if payload.get("type") == "response.completed":
                response_obj = payload.get("response") or {}
                usage = response_obj.get("usage")
                if isinstance(usage, dict):
                    return usage
            return None

        # Chat completions
        usage = payload.get("usage")
        if isinstance(usage, dict):
            return usage
        return None
