"""
Google Gemini provider adapter.

Handles ``generativelanguage.googleapis.com`` — generateContent (non-streaming),
streamGenerateContent (streaming JSON-array, NOT SSE), and embedContent /
batchEmbedContents (embeddings).

Endpoints in scope (multi-provider PR3, 2026-05-02):
  POST /v1beta/models/<model>:generateContent        — non-streaming chat
  POST /v1beta/models/<model>:streamGenerateContent  — streaming JSON-array
  POST /v1beta/models/<model>:embedContent           — single embedding
  POST /v1beta/models/<model>:batchEmbedContents     — batched embeddings
  (also accept /v1/... — Google's future-stable API path.)

Endpoints deferred (file as follow-ups):
  Vertex AI (``aiplatform.googleapis.com``) — different request/auth shape.

Token count locations in the Gemini API:

Non-streaming (generateContent / embedContent / batchEmbedContents):
    response body → top-level "usageMetadata" object:
        promptTokenCount             → input_tokens
        candidatesTokenCount         → output_tokens
        cachedContentTokenCount      → cache_read_tokens (optional)
        thoughtsTokenCount           → thinking_tokens (Gemini 2.5+, optional)
    Embeddings emit only ``totalTokenCount`` (mapped to input_tokens).
    cache_write_tokens is always 0 — Gemini context caching is a SEPARATE
    ``POST /v1beta/cachedContents`` API, not surfaced on inference responses.

Streaming (:streamGenerateContent):
    NOT SSE. The response body is a JSON ARRAY ``[{...},{...},{...}]`` of
    incremental chunks. mitmproxy gives us the full body — we parse it as
    JSON and pull ``usageMetadata`` from the LAST element. If parsing fails
    (truncated array, client closed early), tokens_complete=False and a
    ``adapter.gemini.streaming_parse_failed`` log line fires for
    observability.

Tiered pricing (>200k input tokens):
    ``compute_cost_millicents`` already routes via ``GEMINI_TIERED_RATES`` —
    the adapter just needs to feed the right ``input_tokens`` count.

Multimodal:
    ``usageMetadata.promptTokensDetails`` may break input down by modality
    (TEXT / IMAGE / AUDIO / VIDEO). For v1, we use the rolled-up
    ``promptTokenCount`` and accept the under-count for non-text input. We
    log ``adapter.gemini.multimodal_input_detected`` when non-text modalities
    are present so the gap can be quantified.
"""

from __future__ import annotations

import json
import re
import time
from typing import Any, ClassVar

import structlog
from mitmproxy import http

from halton_meter.adapters.base import RequestMetadata, ResponseMetadata

log = structlog.get_logger()


# Match the model id out of paths like:
#   /v1beta/models/gemini-2.5-pro:generateContent
#   /v1/models/gemini-3.1-pro-preview:streamGenerateContent
#   /v1beta/models/text-embedding-004:embedContent
_MODEL_PATH_RE = re.compile(r"/v1(?:beta)?/models/(?P<model>[^:?]+):(?P<action>[^?/]+)")


class GeminiAdapter:
    """
    Adapter for ``generativelanguage.googleapis.com``.

    Stateless and pure: ``parse_request`` and ``parse_response`` never raise,
    never touch the filesystem, and never make network calls. Parse failures
    return zero-valued metadata with ``tokens_complete=False`` so the daemon
    keeps logging the request shell rather than dropping it.
    """

    name: ClassVar[str] = "gemini"
    domains: ClassVar[list[str]] = ["generativelanguage.googleapis.com"]

    def matches(self, host: str) -> bool:
        """Match the public Gemini API host exactly, with optional :port suffix.

        Same exact-match-plus-port-carve-out shape as the Anthropic and
        OpenAI adapters — guards against
        ``generativelanguage.googleapis.com.evil.com`` and
        ``evil.generativelanguage.googleapis.com``. Vertex
        (``aiplatform.googleapis.com``) is intentionally NOT matched
        — different request shape, deferred to a follow-up.
        """
        return host == "generativelanguage.googleapis.com" or host.startswith(
            "generativelanguage.googleapis.com:"
        )

    def matches_url(self, host: str, path: str) -> bool:
        """Path-level filter on top of ``matches(host)``.

        Requires the strict Gemini model API format:
          /v1{beta}?/models/<model>:<action>
        where action is one of: generateContent, streamGenerateContent,
        embedContent, batchEmbedContents.

        Other paths on generativelanguage.googleapis.com are rejected
        (e.g. /v1beta/cachedContents, /v1/models list, etc.).
        """
        if not self.matches(host):
            return False
        match = _MODEL_PATH_RE.search(path)
        if match is None:
            return False
        action = match.group("action")
        return action in {
            "generateContent",
            "streamGenerateContent",
            "embedContent",
            "batchEmbedContents",
        }

    def parse_request(self, flow: http.HTTPFlow) -> RequestMetadata:
        """Extract model name and stream flag from the URL path.

        Unlike OpenAI/Anthropic, Gemini puts the model in the URL — never the
        body. The request body carries only the prompt (``contents``) and
        generation config. The action suffix (``:streamGenerateContent``)
        determines the stream flag; embeddings and non-streaming
        generateContent are stream=False.
        """
        model = "unknown"
        stream = False
        try:
            path = flow.request.path or ""
            match = _MODEL_PATH_RE.search(path)
            if match is not None:
                model = match.group("model")
                stream = match.group("action") == "streamGenerateContent"
        except Exception:  # pragma: no cover — defensive only
            pass

        return RequestMetadata(
            provider=self.name,
            model=model,
            stream=stream,
            started_at=time.monotonic(),
        )

    def parse_response(
        self,
        flow: http.HTTPFlow,
        request_meta: RequestMetadata,
    ) -> ResponseMetadata:
        """Extract token counts from the completed response body.

        Three branches:
          1. Streaming (:streamGenerateContent) — JSON array, find last
             element's usageMetadata.
          2. Embeddings (:embedContent / :batchEmbedContents) — read
             ``usageMetadata.totalTokenCount`` into input_tokens.
          3. Non-streaming generateContent — read the four usageMetadata
             fields into the standard slots.
        """
        latency_ms = (time.monotonic() - request_meta.started_at) * 1000
        path = flow.request.path or ""

        input_tokens = 0
        output_tokens = 0
        thinking_tokens = 0
        cache_read_tokens = 0
        cache_write_tokens = 0  # Gemini context caching is a separate API.
        tokens_complete = True

        try:
            body = flow.response.get_text(strict=False) or ""

            if request_meta.stream or ":streamGenerateContent" in path:
                (
                    input_tokens,
                    output_tokens,
                    thinking_tokens,
                    cache_read_tokens,
                    tokens_complete,
                ) = self._parse_streaming(body)
            elif ":embedContent" in path or ":batchEmbedContents" in path:
                input_tokens, tokens_complete = self._parse_embeddings(body)
            else:
                data = json.loads(body) if body else {}
                usage = data.get("usageMetadata") or {}
                if not usage:
                    # Older API shape / error response without usageMetadata —
                    # don't crash, just mark incomplete.
                    tokens_complete = False
                else:
                    (
                        input_tokens,
                        output_tokens,
                        thinking_tokens,
                        cache_read_tokens,
                    ) = self._extract_usage_fields(usage)

        except Exception as exc:
            tokens_complete = False
            log.error(
                "adapter.parse_response.failed",
                provider=self.name,
                error=str(exc),
                exc_info=True,
            )

        return ResponseMetadata(
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            thinking_tokens=thinking_tokens,
            cache_read_tokens=cache_read_tokens,
            cache_write_tokens=cache_write_tokens,
            tokens_complete=tokens_complete,
            latency_ms=latency_ms,
        )

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _extract_usage_fields(
        self, usage: dict[str, Any]
    ) -> tuple[int, int, int, int]:
        """Pull (input, output, thinking, cache_read) from a usageMetadata dict.

        Logs ``adapter.gemini.multimodal_input_detected`` if
        ``promptTokensDetails`` is present and contains non-text modalities,
        so we can quantify how often the v1 text-only rolled-up count
        under-prices a multimodal request.
        """
        input_tokens = int(usage.get("promptTokenCount", 0) or 0)
        output_tokens = int(usage.get("candidatesTokenCount", 0) or 0)
        thinking_tokens = int(usage.get("thoughtsTokenCount", 0) or 0)
        cache_read_tokens = int(usage.get("cachedContentTokenCount", 0) or 0)

        details = usage.get("promptTokensDetails")
        if isinstance(details, list) and details:
            non_text = [
                d
                for d in details
                if isinstance(d, dict)
                and str(d.get("modality", "")).upper() not in ("", "TEXT")
            ]
            if non_text:
                log.info(
                    "adapter.gemini.multimodal_input_detected",
                    provider=self.name,
                    modalities=[d.get("modality") for d in non_text],
                    hint="v1 uses rolled-up promptTokenCount; modal under-count accepted",
                )

        return input_tokens, output_tokens, thinking_tokens, cache_read_tokens

    def _parse_streaming(self, body: str) -> tuple[int, int, int, int, bool]:
        """Parse the streamed JSON array, return (input, output, thinking, cache_read, complete).

        :streamGenerateContent returns a single JSON array of chunk objects
        (NOT SSE). The final chunk carries ``usageMetadata``. If the array is
        truncated (e.g. client closed early), ``json.loads`` fails — we log
        ``adapter.gemini.streaming_parse_failed`` and return zero-valued
        tokens with tokens_complete=False.
        """
        if not body.strip():
            return (0, 0, 0, 0, False)

        try:
            chunks = json.loads(body)
        except json.JSONDecodeError as exc:
            log.debug(
                "adapter.gemini.streaming_parse_failed",
                provider=self.name,
                error=str(exc),
                hint="truncated JSON array (client closed early?)",
            )
            return (0, 0, 0, 0, False)

        if not isinstance(chunks, list) or not chunks:
            return (0, 0, 0, 0, False)

        # Walk from the end — the usageMetadata block lives on the final chunk
        # that carries one. Some intermediate chunks omit it.
        for chunk in reversed(chunks):
            if not isinstance(chunk, dict):
                continue
            usage = chunk.get("usageMetadata")
            if isinstance(usage, dict) and usage:
                (
                    input_tokens,
                    output_tokens,
                    thinking_tokens,
                    cache_read_tokens,
                ) = self._extract_usage_fields(usage)
                return (
                    input_tokens,
                    output_tokens,
                    thinking_tokens,
                    cache_read_tokens,
                    True,
                )

        # Array parsed cleanly but no chunk carried usageMetadata.
        return (0, 0, 0, 0, False)

    @staticmethod
    def _parse_embeddings(body: str) -> tuple[int, bool]:
        """Parse an embedContent / batchEmbedContents response.

        Embeddings emit ``usageMetadata.totalTokenCount`` (single field —
        no input/output split). Mapped to ``input_tokens``; output_tokens
        is always 0 for embeddings.
        """
        if not body:
            return (0, False)
        try:
            data = json.loads(body)
        except json.JSONDecodeError:
            return (0, False)

        usage = data.get("usageMetadata") or {}
        if not usage:
            return (0, False)
        total = int(usage.get("totalTokenCount", 0) or 0)
        return (total, True)
