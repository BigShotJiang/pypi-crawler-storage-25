"""
xAI (Grok) provider adapter.

Handles ``api.x.ai`` — both the OpenAI-compatible chat-completions surface and
the Anthropic-compatible messages surface, on the same host.

Endpoints in scope (multi-provider PR4, 2026-05-02):
  POST /v1/chat/completions   — OpenAI-shape body, OpenAI-shape response.
  POST /v1/messages           — Anthropic-shape body, Anthropic-shape response.

Implementation: rather than copy the OpenAI/Anthropic SSE + usage-extraction
logic, this adapter URL-dispatches into instances of OpenAIAdapter and
AnthropicAdapter held as private siblings, then OVERRIDES
``RequestMetadata.provider`` to ``"xai"`` so DB rows attribute correctly.
The siblings' parsing is reused as-is — both shapes match xAI 1:1.

This keeps the file thin (~110 LOC) and means any future fix to OpenAI's or
Anthropic's parsing flows through to xAI for free. The contract is:
  * Token shape = sibling shape (no xAI-specific quirks today).
  * Provider name = "xai" regardless of which sibling parsed.
  * URL-dispatch ordering: ``/v1/chat/completions`` → OpenAI sibling;
    ``/v1/messages`` → Anthropic sibling. Anything else → defaults with
    ``tokens_complete=False`` (defensive; ``matches_url`` filters first).

xAI does NOT expose prompt caching today — both shapes return ``cached_tokens``
/ ``cache_read_input_tokens`` as 0 or absent. Reasoning tokens are also not
exposed (Grok does not surface reasoning the way o-series does). Both fields
are still pulled by the sibling parsers — they will simply be 0 on every xAI
response, which is correct.
"""

from __future__ import annotations

import time
from typing import ClassVar

import structlog
from mitmproxy import http

from halton_meter.adapters.anthropic import AnthropicAdapter
from halton_meter.adapters.base import RequestMetadata, ResponseMetadata
from halton_meter.adapters.openai import OpenAIAdapter

log = structlog.get_logger()


# Module-level sibling instances. Both adapters are stateless; reusing a single
# instance is safe and avoids per-request allocation in the hot path.
_OPENAI_SIBLING = OpenAIAdapter()
_ANTHROPIC_SIBLING = AnthropicAdapter()


class XAIAdapter:
    """
    Adapter for ``api.x.ai`` (xAI / Grok).

    Stateless and pure: ``parse_request`` and ``parse_response`` never raise,
    never touch the filesystem, and never make network calls. Parse failures
    return zero-valued metadata with ``tokens_complete=False`` so the daemon
    keeps logging the request shell rather than dropping it.
    """

    name: ClassVar[str] = "xai"
    domains: ClassVar[list[str]] = ["api.x.ai"]

    def matches(self, host: str) -> bool:
        """Match api.x.ai exactly, with optional :port suffix.

        Same exact-match-plus-port-carve-out shape as the other adapters —
        guards against ``api.x.ai.evil.com`` and ``evil.api.x.ai``.
        """
        return host == "api.x.ai" or host.startswith("api.x.ai:")

    def matches_url(self, host: str, path: str) -> bool:
        """Path-level filter on top of ``matches(host)``.

        Accepts the two inference shapes xAI exposes:
          /v1/chat/completions  — OpenAI-compatible
          /v1/messages          — Anthropic-compatible
        Everything else is rejected (matches OpenAI's posture toward
        non-billable paths like /v1/moderations).
        """
        if not self.matches(host):
            return False
        return path.startswith("/v1/chat/completions") or path.startswith(
            "/v1/messages"
        )

    def parse_request(self, flow: http.HTTPFlow) -> RequestMetadata:
        """Delegate to the matching sibling parser, override provider to 'xai'.

        Both xAI URL shapes carry the model in the request BODY (NOT the URL,
        unlike Gemini). The sibling parsers already extract model + stream
        correctly — we just need to relabel the provider field.
        """
        path = flow.request.path or ""
        if path.startswith("/v1/messages"):
            sibling_meta = _ANTHROPIC_SIBLING.parse_request(flow)
        elif path.startswith("/v1/chat/completions"):
            sibling_meta = _OPENAI_SIBLING.parse_request(flow)
        else:
            # Defensive: matches_url should have filtered this. Return defaults
            # rather than raising so the proxy hot path stays fail-open.
            return RequestMetadata(
                provider=self.name,
                model="unknown",
                stream=False,
                started_at=time.monotonic(),
            )
        return sibling_meta.model_copy(update={"provider": self.name})

    def parse_response(
        self,
        flow: http.HTTPFlow,
        request_meta: RequestMetadata,
    ) -> ResponseMetadata:
        """Delegate to the matching sibling parser based on URL path.

        ``ResponseMetadata`` carries no provider field, so no relabel needed
        — the sibling output is returned as-is. The provider attribution is
        already pinned in the ``RequestMetadata`` we received.
        """
        path = flow.request.path or ""
        try:
            if path.startswith("/v1/messages"):
                return _ANTHROPIC_SIBLING.parse_response(flow, request_meta)
            if path.startswith("/v1/chat/completions"):
                return _OPENAI_SIBLING.parse_response(flow, request_meta)
        except Exception as exc:  # pragma: no cover — siblings already swallow
            log.error(
                "adapter.parse_response.failed",
                provider=self.name,
                error=str(exc),
                exc_info=True,
            )
        # Defensive default: matches_url should have filtered unknown paths.
        return ResponseMetadata(
            tokens_complete=False,
            latency_ms=(time.monotonic() - request_meta.started_at) * 1000,
        )
