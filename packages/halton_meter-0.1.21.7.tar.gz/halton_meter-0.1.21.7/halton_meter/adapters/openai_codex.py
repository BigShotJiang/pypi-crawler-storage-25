"""
OpenAI Codex backend adapter (sibling of OpenAIAdapter).

Handles ``chatgpt.com`` — the ChatGPT-backend surface that the
``@openai/codex`` CLI uses when signed in with a ChatGPT account
(Plus / Pro / Team / Enterprise plans). This is a separate host
from the public OpenAI API (``api.openai.com``) and uses an
account-scoped, undocumented control-plane wrapper, so it is
implemented as a sibling adapter rather than broadening
:class:`OpenAIAdapter`.

Background — investigation 2026-05-04:

    User ran ``@openai/codex`` v0.128.0; ``halton-meter report``
    showed zero Codex rows. Root cause: the daemon cleanly
    intercepted every byte but the public-API ``OpenAIAdapter``
    rejected ``chatgpt.com`` in :meth:`matches`, so requests fell
    out at adapter dispatch (``addon.no_adapter_match`` in
    ``daemon.out.log`` 2026-05-04 17:13:33). See ADR
    ``memory/decisions.md`` 2026-05-04 entry "v0.1.19.dev2:
    Gemini Code Assist sibling adapter…" — the OpenAI Codex
    surface follows the same sibling-adapter shape (see the
    extension note appended to that ADR for dev3).

Endpoints in scope (billable):
  POST /backend-api/codex/responses          — Responses-API-shape
                                                (streaming + non-streaming)

Path matching (narrowed in dev4): only the exact
``/backend-api/codex/responses`` path is metered. dev3 was wider
(``startswith("/backend-api/codex/")``) and produced noise rows
from ``/backend-api/codex/models`` (catalogue GET — surfaced the
6 codex SKUs the user observed) and
``/backend-api/codex/analytics-events/events`` (telemetry POSTs).
Both arrive carrying ``model=codex-unknown`` and zero usage,
contaminating the cost aggregations. Narrowing to the single
billable path is the correct safety default once the surface is
characterised. Future Codex-billable paths (e.g. an ``edits``
endpoint) will need explicit additions to the allow-list rather
than blanket-prefix matching. The classic ChatGPT site
(``/api/conversation`` etc.) lives on ``chatgpt.com`` too and
remains correctly ignored.

Two important deltas vs ``OpenAIAdapter`` (the public-API sibling):

1. **Host is ``chatgpt.com``, not ``api.openai.com``.** The OpenAI
   Codex CLI tunnels through the ChatGPT backend's account-scoped
   wrapper rather than the public API; a separate ``matches`` is
   the right shape (host-pinning stays narrow).

2. **Path namespace is ``/backend-api/codex/*``, not ``/v1/*``.**
   The wire body shape is expected to match the Responses API
   (``input_tokens``/``output_tokens``/``output_tokens_details.
   reasoning_tokens``/``input_tokens_details.cached_tokens``)
   based on the ``responses`` action name; we land blind on this
   assumption and log ``adapter.openai_codex.model_observed`` on
   every hit to confirm the on-the-wire shape from real traffic.

Token-count locations (assumed Responses-API shape):

Non-streaming (``/backend-api/codex/responses``):
    Response body root → ``"usage"`` (Responses-API shape).
    Reasoning tokens at ``output_tokens_details.reasoning_tokens``.
    Cached input at ``input_tokens_details.cached_tokens``.

Streaming (``/backend-api/codex/responses`` with SSE
``content-type: text/event-stream``):
    Standard SSE. The ``response.completed`` event carries
    ``usage`` on its nested ``response`` object — same idiom as
    the public Responses API. ``[DONE]`` sentinel may or may not
    be present — handled either way. Reuses the OpenAI sibling's
    ``_extract_usage_fields`` static helper to keep the
    field-name knowledge in one place.

Pricing-matrix coupling: ``name = "openai"`` (same provider id as
``OpenAIAdapter``) so reports aggregate cleanly across the two
surfaces. The model id we extract from the body must match an
``OPENAI_RATES`` entry — see ``pricing/matrix.py`` for the 6
Codex SKUs (``gpt-5.5``, ``gpt-5.4``, ``gpt-5.4-mini``,
``gpt-5.3-codex``, ``gpt-5.2``, ``codex-auto-review``) plus the
``codex-unknown`` adapter fallback row. Rates are mapped to the
closest comparable public-API tier — see the comment block in
``pricing/matrix.py`` for the per-SKU rationale.

Contract guarantees (same as every other adapter): stateless,
pure, must-not-raise. Parse failures return zero-valued metadata
with ``tokens_complete=False`` rather than crashing the proxy
hot path.
"""

from __future__ import annotations

import json
import time
from typing import Any, ClassVar

import structlog
from mitmproxy import http

from halton_meter.adapters.base import RequestMetadata, ResponseMetadata
from halton_meter.adapters.openai import OpenAIAdapter

log = structlog.get_logger()


_HOST = "chatgpt.com"
# Narrowed in dev4 (memory/decisions.md 2026-05-04 dev4 entry): the only
# billable path on this surface today. Catalogue (``/codex/models``) and
# telemetry (``/codex/analytics-events/events``) paths are explicitly
# excluded — they produce zero-usage rows that pollute cost aggregations.
# Add new entries here when an additional billable Codex endpoint is
# observed (e.g. ``/backend-api/codex/edits``).
_BILLABLE_PATHS: frozenset[str] = frozenset({"/backend-api/codex/responses"})

# Fallback model id when the request body carries no recognisable
# model field. Surfaces in reports as ``model='codex-unknown'``
# so the user can spot misclassification. Pricing path falls back
# to the TEMP- placeholder (see pricing/matrix.py).
_FALLBACK_MODEL = "codex-unknown"


class OpenAICodexAdapter:
    """
    Adapter for ``chatgpt.com`` (OpenAI Codex CLI / ChatGPT backend).

    Sibling of :class:`OpenAIAdapter`; both share ``name="openai"`` so
    cost reports aggregate across the two surfaces. Both stay live —
    a user may use the public OpenAI API (``api.openai.com``) and the
    Codex CLI (``chatgpt.com``) from the same machine.
    """

    name: ClassVar[str] = "openai"
    domains: ClassVar[list[str]] = [_HOST]

    def matches(self, host: str) -> bool:
        """Match ``chatgpt.com`` exactly, with optional ``:port`` suffix.

        Same exact-match-plus-port-carve-out shape as the sibling
        adapters — guards against ``chatgpt.com.evil.com`` and
        ``evil.chatgpt.com``.
        """
        return host == _HOST or host.startswith(f"{_HOST}:")

    def matches_url(self, host: str, path: str) -> bool:
        """Path-level filter — only the billable Codex endpoints.

        Narrowed in dev4 to the explicit ``_BILLABLE_PATHS`` allow-list.
        Drops noise rows from ``/backend-api/codex/models`` (catalogue
        GET) and ``/backend-api/codex/analytics-events/events``
        (telemetry POST), both of which arrive with no recoverable
        model id and zero usage. The query-string suffix is tolerated
        (``path.split("?", 1)[0]``) so ``/responses?...`` still matches.
        """
        if not self.matches(host):
            return False
        bare_path = path.split("?", 1)[0]
        return bare_path in _BILLABLE_PATHS

    def parse_request(self, flow: http.HTTPFlow) -> RequestMetadata:
        """Extract model id + stream flag.

        Stream flag: derived from the ``stream`` field in the JSON
        request body (Responses-API convention). Falls back to False
        if absent or non-boolean.

        Model id: from the JSON request body at the top-level
        ``"model"`` key (Responses-API convention). When absent we
        log ``adapter.openai_codex.model_observed`` with the
        fallback id so the user sees the entry surface and the
        operator gets a hint about real traffic shape (TEMP- marker
        for dev3; real fixture lands in dev4).
        """
        path = flow.request.path or ""
        model = _FALLBACK_MODEL
        stream = False
        try:
            body = flow.request.get_text(strict=False) or ""
            if body:
                data = json.loads(body)
                if isinstance(data, dict):
                    raw_model = data.get("model")
                    if isinstance(raw_model, str) and raw_model:
                        model = raw_model
                    stream = bool(data.get("stream", False))
        except (json.JSONDecodeError, UnicodeDecodeError):
            # Non-JSON body is unexpected on this surface — log and
            # use the fallback so the request still gets a row.
            log.debug(
                "adapter.openai_codex.request_body_not_json",
                host=_HOST,
                path=path,
            )

        # Always log the observed model so the operator can spot any
        # newly-shipped Codex SKU not yet seeded in OPENAI_RATES.
        # (TEMP-CODEX-DEV3 placeholders were replaced by real-mapped
        # rates in dev4 — see memory/decisions.md 2026-05-04 dev4 entry.)
        log.info(
            "adapter.openai_codex.model_observed",
            provider=self.name,
            model=model,
            stream=stream,
            path=path,
        )

        return RequestMetadata(
            provider=self.name,
            model=model,
            stream=stream,
            started_at=time.monotonic(),
        )

    def parse_response(
        self,
        flow: http.HTTPFlow,
        request_meta: RequestMetadata,
    ) -> ResponseMetadata:
        """Extract token counts from the completed response body.

        Two branches (mirrors the public Responses API):
          1. Streaming SSE — walk ``data:`` chunks; the
             ``response.completed`` event's ``response.usage`` wins.
          2. Non-streaming — single JSON object; pull top-level
             ``usage`` (Responses-API shape).
        """
        latency_ms = (time.monotonic() - request_meta.started_at) * 1000
        content_type = (
            flow.response.headers.get("content-type", "") if flow.response else ""
        )
        is_sse = "text/event-stream" in content_type or request_meta.stream

        input_tokens = 0
        output_tokens = 0
        thinking_tokens = 0
        cache_read_tokens = 0
        cache_write_tokens = 0  # OpenAI auto-manages caches server-side; no usage field.
        tokens_complete = True

        try:
            body = flow.response.get_text(strict=False) or ""

            if is_sse and body.lstrip().startswith("data:"):
                (
                    input_tokens,
                    output_tokens,
                    thinking_tokens,
                    cache_read_tokens,
                    tokens_complete,
                ) = self._parse_sse(body)
            else:
                data = json.loads(body) if body else {}
                usage = self._find_usage(data)
                if not usage:
                    tokens_complete = False
                else:
                    (
                        input_tokens,
                        output_tokens,
                        thinking_tokens,
                        cache_read_tokens,
                    ) = OpenAIAdapter._extract_usage_fields(usage)

        except Exception as exc:
            tokens_complete = False
            log.error(
                "adapter.parse_response.failed",
                provider=self.name,
                surface="codex",
                error=str(exc),
                exc_info=True,
            )

        return ResponseMetadata(
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            thinking_tokens=thinking_tokens,
            cache_read_tokens=cache_read_tokens,
            cache_write_tokens=cache_write_tokens,
            tokens_complete=tokens_complete,
            latency_ms=latency_ms,
        )

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _find_usage(data: Any) -> dict[str, Any] | None:
        """Pull a ``usage`` dict out of a non-streaming Codex body.

        Accepts BOTH shapes defensively:
          - top-level ``usage`` (chat-completions / Responses-API root)
          - ``response.usage`` (Responses-API event-payload shape, in
            case the backend wraps the same way the SSE event does)
        """
        if not isinstance(data, dict):
            return None
        usage = data.get("usage")
        if isinstance(usage, dict) and usage:
            return usage
        response = data.get("response")
        if isinstance(response, dict):
            inner = response.get("usage")
            if isinstance(inner, dict) and inner:
                return inner
        return None

    def _parse_sse(self, body: str) -> tuple[int, int, int, int, bool]:
        """Walk SSE chunks and return (input, output, thinking, cache_read, complete).

        Two payload shapes accepted per chunk:
          - Responses-API: ``{"type": "response.completed",
                              "response": {"usage": {...}}}``
          - Defensive fallback: top-level ``"usage"`` on any chunk
            (chat-completions style — unlikely on this surface but
            costs nothing to support).

        If no chunk carries a usage block, returns zeros +
        ``tokens_complete=False`` and emits
        ``adapter.openai_codex.streaming_no_usage_block``.
        """
        input_tokens = 0
        output_tokens = 0
        thinking_tokens = 0
        cache_read_tokens = 0
        found_usage = False

        for raw_line in body.splitlines():
            line = raw_line.strip()
            if not line.startswith("data:"):
                continue
            raw_data = line[len("data:") :].strip()
            if raw_data in ("[DONE]", ""):
                continue
            try:
                payload = json.loads(raw_data)
            except json.JSONDecodeError:
                continue

            usage = self._extract_chunk_usage(payload)
            if usage:
                found_usage = True
                (
                    input_tokens,
                    output_tokens,
                    thinking_tokens,
                    cache_read_tokens,
                ) = OpenAIAdapter._extract_usage_fields(usage)

        if not found_usage:
            log.debug(
                "adapter.openai_codex.streaming_no_usage_block",
                provider=self.name,
                hint=(
                    "no SSE chunk carried response.completed.usage; "
                    "client closed early?"
                ),
            )
            return (0, 0, 0, 0, False)

        return (input_tokens, output_tokens, thinking_tokens, cache_read_tokens, True)

    @staticmethod
    def _extract_chunk_usage(payload: dict[str, Any]) -> dict[str, Any] | None:
        """Pull the ``usage`` dict out of one Codex SSE chunk."""
        if not isinstance(payload, dict):
            return None
        # Responses-API: response.completed event with nested response.usage
        if payload.get("type") == "response.completed":
            response_obj = payload.get("response") or {}
            usage = response_obj.get("usage")
            if isinstance(usage, dict):
                return usage
        # Defensive fallback: top-level usage on any chunk
        usage = payload.get("usage")
        if isinstance(usage, dict):
            return usage
        return None
