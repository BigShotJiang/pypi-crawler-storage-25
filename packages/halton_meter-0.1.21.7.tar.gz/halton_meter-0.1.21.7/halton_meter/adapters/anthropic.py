"""
Anthropic provider adapter.

Handles api.anthropic.com — both non-streaming JSON responses and
streaming SSE responses (text/event-stream).

Token count locations in the Anthropic API:

Non-streaming:
    response body → top-level "usage" object:
        input_tokens, output_tokens, thinking_tokens (optional),
        cache_read_input_tokens (optional),
        cache_creation_input_tokens (optional)

Streaming SSE:
    message_start event → message.usage:
        input_tokens, thinking_tokens (optional),
        cache_read_input_tokens (optional),
        cache_creation_input_tokens (optional)
    message_delta event → usage:
        output_tokens

Note (Decision B, 2026-04-30): Anthropic's response usage exposes only the
flat `cache_creation_input_tokens` int — no 5m/1h TTL split — so we map it
1:1 to `cache_write_tokens`. See `pricing/matrix.py` for the TTL-limitation
comment block and the deferred extension point.

See spike.py for the full design rationale and edge-case notes.
"""

from __future__ import annotations

import json
import time
from typing import ClassVar

import structlog
from mitmproxy import http

from halton_meter.adapters.base import RequestMetadata, ResponseMetadata

log = structlog.get_logger()


class AnthropicAdapter:
    """
    Adapter for api.anthropic.com.

    Handles both non-streaming JSON responses and streaming SSE responses.
    All methods are safe to call from the mitmproxy hot path — they catch
    all exceptions internally and return zero-value metadata rather than raising.
    """

    name: ClassVar[str] = "anthropic"
    domains: ClassVar[list[str]] = ["api.anthropic.com"]

    def matches(self, host: str) -> bool:
        """
        Match api.anthropic.com exactly, with optional :port suffix.

        Tightened (P0-2 / P2-3, 2026-04-30) to reject host-suffix injection:
        a naive `startswith("api.anthropic.com")` would match attacker hosts
        like `api.anthropic.com.evil.com`, and any prefix-match (e.g.
        `endswith`) would match `evil.api.anthropic.com`. Use exact equality
        plus an explicit port-suffix carve-out for SDKs that send the host
        header as `api.anthropic.com:443`.
        """
        return host == "api.anthropic.com" or host.startswith("api.anthropic.com:")

    def matches_url(self, host: str, path: str) -> bool:
        """
        Path-level filter on top of ``matches(host)``.

        Anthropic exposes inference (and metering-relevant) requests at
        /v1/messages. All other endpoints on api.anthropic.com (OAuth, MCP,
        models list, etc.) are excluded — they were previously gated by the
        proxy's ``_is_inference_path`` filter, but now we enforce it here
        for stricter per-provider path matching (avoids cross-provider
        collisions in system-proxy mode).
        """
        if not self.matches(host):
            return False
        return path.startswith("/v1/messages")

    def parse_request(self, flow: http.HTTPFlow) -> RequestMetadata:
        """
        Extract model name and stream flag from the request body.

        Non-JSON bodies (e.g. GET /v1/models) are handled gracefully — model
        defaults to 'unknown' and stream to False.
        """
        model = "unknown"
        stream = False
        try:
            body = flow.request.get_text(strict=False) or ""
            if body:
                data = json.loads(body)
                model = data.get("model", "unknown")
                stream = bool(data.get("stream", False))
        except (json.JSONDecodeError, UnicodeDecodeError):
            # Non-JSON body is expected for non-messages endpoints
            pass

        return RequestMetadata(
            provider=self.name,
            model=model,
            stream=stream,
            started_at=time.monotonic(),
        )

    def parse_response(
        self,
        flow: http.HTTPFlow,
        request_meta: RequestMetadata,
    ) -> ResponseMetadata | None:
        """
        Extract token counts from the completed response body.

        mitmproxy accumulates the full body before calling response(), so SSE
        streams are parsed in a single pass here. Latency is computed from
        request_meta.started_at (set at request parse time).
        """
        latency_ms = (time.monotonic() - request_meta.started_at) * 1000
        content_type = flow.response.headers.get("content-type", "")
        is_sse = "text/event-stream" in content_type

        input_tokens = 0
        output_tokens = 0
        thinking_tokens = 0
        cache_read_tokens = 0
        cache_write_tokens = 0
        tokens_complete = True

        try:
            body = flow.response.get_text(strict=False) or ""

            if is_sse:
                (
                    input_tokens,
                    output_tokens,
                    thinking_tokens,
                    cache_read_tokens,
                    cache_write_tokens,
                ) = self._parse_sse(body)
            else:
                data = json.loads(body)
                usage = data.get("usage", {})
                input_tokens = usage.get("input_tokens", 0)
                output_tokens = usage.get("output_tokens", 0)
                # Anthropic returns thinking_tokens only when extended thinking is on
                thinking_tokens = usage.get("thinking_tokens", 0)
                cache_read_tokens = usage.get("cache_read_input_tokens", 0)
                # Anthropic exposes cache writes as a flat int (no 5m/1h split
                # in response usage). Decision B (decisions.md 2026-04-30):
                # map 1:1 to cache_write_tokens.
                cache_write_tokens = usage.get("cache_creation_input_tokens", 0)

        except Exception as exc:
            tokens_complete = False
            log.error(
                "adapter.parse_response.failed",
                provider=self.name,
                error=str(exc),
                exc_info=True,
            )

        # Skip the row entirely when the request+response combo carries no
        # meterable signal: model unknown (request body lacked "model" or
        # was non-JSON) AND zero input/output tokens (response had no
        # usage block, e.g. an early error before token accounting).
        # These rows previously polluted reports with model=unknown,
        # cost=NULL entries that poisoned grand-total cost aggregation.
        # See decisions.md 2026-05-02 ("NULL cost handling in report
        # aggregation").
        if (
            request_meta.model == "unknown"
            and input_tokens == 0
            and output_tokens == 0
        ):
            log.info(
                "adapter.parse_response.skip_noise",
                provider=self.name,
                reason="model_unknown_and_zero_tokens",
            )
            return None

        return ResponseMetadata(
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            thinking_tokens=thinking_tokens,
            cache_read_tokens=cache_read_tokens,
            cache_write_tokens=cache_write_tokens,
            tokens_complete=tokens_complete,
            latency_ms=latency_ms,
        )

    def _parse_sse(self, body: str) -> tuple[int, int, int, int, int]:
        """
        Walk SSE lines and accumulate token counts.

        Returns (input_tokens, output_tokens, thinking_tokens,
        cache_read_tokens, cache_write_tokens).

        Token locations in the Anthropic SSE stream:
          message_start → message.usage.input_tokens
                        → message.usage.thinking_tokens  (optional)
                        → message.usage.cache_read_input_tokens  (optional)
                        → message.usage.cache_creation_input_tokens  (optional)
          message_delta → usage.output_tokens

        Blank lines separate SSE events. Lines starting with "event:" set the
        current event type; lines starting with "data:" carry the payload JSON.
        """
        input_tokens = 0
        output_tokens = 0
        thinking_tokens = 0
        cache_read_tokens = 0
        cache_write_tokens = 0

        current_event: str | None = None
        for raw_line in body.splitlines():
            line = raw_line.strip()

            if line.startswith("event:"):
                current_event = line[len("event:") :].strip()

            elif line.startswith("data:"):
                raw_data = line[len("data:") :].strip()
                if raw_data in ("[DONE]", ""):
                    continue
                try:
                    payload = json.loads(raw_data)
                except json.JSONDecodeError:
                    continue

                event_type = payload.get("type", current_event or "")

                if event_type == "message_start":
                    msg_usage = payload.get("message", {}).get("usage", {})
                    input_tokens += msg_usage.get("input_tokens", 0)
                    # Anthropic returns thinking_tokens here when extended thinking is active;
                    # field is absent (not 0) when thinking is off — treat absence as 0.
                    thinking_tokens += msg_usage.get("thinking_tokens", 0)
                    cache_read_tokens += msg_usage.get("cache_read_input_tokens", 0)
                    # Decision B (2026-04-30): cache writes are a flat int in
                    # response usage (no 5m/1h split); map 1:1 to cache_write.
                    cache_write_tokens += msg_usage.get(
                        "cache_creation_input_tokens", 0
                    )

                elif event_type == "message_delta":
                    delta_usage = payload.get("usage", {})
                    output_tokens += delta_usage.get("output_tokens", 0)

            elif line == "":
                # Blank line marks the end of an SSE event block
                current_event = None

        return (
            input_tokens,
            output_tokens,
            thinking_tokens,
            cache_read_tokens,
            cache_write_tokens,
        )
