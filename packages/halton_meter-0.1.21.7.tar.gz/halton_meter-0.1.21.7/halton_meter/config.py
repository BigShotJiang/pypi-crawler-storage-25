"""
Config loading for Halton Meter daemon.

Reads ~/.halton-meter/config.toml on startup. Missing file is not an error —
defaults are applied. Config is validated with Pydantic and frozen after load.
"""

from __future__ import annotations

import tomllib
from pathlib import Path

from pydantic import BaseModel, ConfigDict, Field


class DaemonConfig(BaseModel):
    model_config = ConfigDict(frozen=True, populate_by_name=True)

    listen_host: str = Field(default="127.0.0.1")
    # The user-facing proxy port. This is what gets injected into apps'
    # ``HTTPS_PROXY`` env var (launchctl env / shell rc / `halton-meter
    # run`). v0.1.6 (2C.2): renamed from ``listen_port`` to ``edge_port``
    # because v0.1.6 splits the proxy port (now owned by the edge process)
    # from the metering daemon's mitmproxy listener (now on
    # ``internal_port``). Pydantic alias keeps legacy ``listen_port``
    # readable in tests / programmatic constructors. The TOML loaders in
    # ``port_alloc`` translate the legacy key with a deprecation warning.
    edge_port: int = Field(default=8081, alias="listen_port")
    # Internal mitmproxy listener port (v0.1.6+). The metering daemon
    # binds this; only the edge proxy talks to it (loopback only). Apps
    # never see this port — it's not advertised in any env var.
    internal_port: int = Field(default=8090)
    # Health-cache TTL the edge proxy uses for the daemon's /health probe.
    # Plan §12.3: 1000ms healthy / 200ms unhealthy / invalidate-on-refused.
    # Only the healthy TTL is user-tunable; the unhealthy TTL is fixed
    # because making recovery slower has no upside.
    edge_health_ttl_ms: int = Field(default=1000)
    log_path: str = Field(default="~/.halton-meter/daemon.log")
    # FastAPI HTTP API listener (Phase 2B.1+). The dashboard reads from this
    # over loopback. Kept on a separate port from the proxy listener so a
    # browser hitting the API never accidentally goes through mitmproxy.
    api_host: str = Field(default="127.0.0.1")
    api_port: int = Field(default=8765)


class StorageConfig(BaseModel):
    model_config = ConfigDict(frozen=True)

    db_path: str = Field(default="~/.halton-meter/db.sqlite")


class SyncConfig(BaseModel):
    model_config = ConfigDict(frozen=True)

    # Phase 1+: backend sync settings
    backend_url: str = Field(default="")
    batch_interval_seconds: int = Field(default=60)
    batch_size: int = Field(default=100, description="Records per POST batch")
    api_key: str = Field(default="")
    enabled: bool = Field(
        default=True,
        description="Set False to disable sync even if backend_url is set",
    )


class CorsConfig(BaseModel):
    """CORS settings for the daemon's FastAPI app (Phase 2B.1+)."""

    model_config = ConfigDict(frozen=True)

    allow_origins: list[str] = Field(default_factory=lambda: ["http://localhost:3000"])


class BodiesConfig(BaseModel):
    """Per-prompt body-capture settings (v0.1.13+).

    Master switch ``enabled`` wins over per-project ``project_settings``
    rows: ``enabled=False`` here disables capture across the board, no
    exceptions. Per-project opt-out is the exception within the master-on
    case. See ``memory/plans/2026-05-01-body-capture.md`` open question
    #10 (operator confirmed: master wins).
    """

    model_config = ConfigDict(frozen=True)

    enabled: bool = Field(
        default=True,
        description="Master switch for body capture. Per-project opt-out is "
        "honoured only when this is True.",
    )
    max_body_bytes: int = Field(
        default=512 * 1024,
        description="Per-body cap. Bodies larger than this are truncated; "
        "the original size is preserved in request_body_bytes / "
        "response_body_bytes.",
    )
    retention_days: int = Field(
        default=90,
        description="Default --older-than for `halton-meter bodies purge`.",
    )
    cache_ttl_seconds: int = Field(
        default=300,
        description="In-memory cache TTL for project_settings reads on the "
        "hot path. Picks up CLI changes within this window without daemon "
        "restart.",
    )


class TaggingConfig(BaseModel):
    """Project attribution and smart-default settings (v0.1.17+, Issue #3).

    Controls how unattributed traffic is handled and provides process-based
    heuristics for intelligent project assignment. When standard attribution
    signals (env vars, .haltonrc, git, cwd) all fail, these settings determine
    the fallback behaviour.
    """

    model_config = ConfigDict(frozen=True)

    default_project: str = Field(
        default="misc",
        description="Fallback project name when all attribution steps fail. "
        "Set to empty string to keep the old 'unattributed' literal. "
        "Recommended: 'misc', 'uncategorized', or your catch-all project slug.",
    )
    enable_process_heuristics: bool = Field(
        default=True,
        description="When True, detect the originating process name and check "
        "process_mappings before falling back to default_project. Helps capture "
        "unattributed traffic from known tools (e.g., 'claude' -> 'dev').",
    )
    process_mappings: dict[str, str] = Field(
        default_factory=lambda: {
            "claude": "dev",
            "cursor": "dev",
            "windsurf": "dev",
            "code": "dev",
            "python": "scripts",
            "python3": "scripts",
            "node": "scripts",
            "npx": "scripts",
            "uvx": "scripts",
        },
        description="Mapping of process names (basenames without path, lowercase) "
        "to project slugs. Examples: {'python': 'scripts', 'claude': 'dev'}. "
        "Only consulted when enable_process_heuristics=True and all earlier "
        "attribution steps fail. Process names are normalized (lowercase, "
        "path-stripped) before lookup.",
    )


class HaltonConfig(BaseModel):
    """Top-level config model. Loaded once at daemon startup."""

    model_config = ConfigDict(frozen=True)

    daemon: DaemonConfig = Field(default_factory=DaemonConfig)
    storage: StorageConfig = Field(default_factory=StorageConfig)
    sync: SyncConfig = Field(default_factory=SyncConfig)
    cors: CorsConfig = Field(default_factory=CorsConfig)
    bodies: BodiesConfig = Field(default_factory=BodiesConfig)
    tagging: TaggingConfig = Field(default_factory=TaggingConfig)


_DEFAULT_CONFIG_PATH = Path("~/.halton-meter/config.toml").expanduser()


def load_config(path: Path | None = None) -> HaltonConfig:
    """
    Load config from TOML file. Returns defaults if the file does not exist.

    Args:
        path: Override the config file path. Defaults to ~/.halton-meter/config.toml.

    Returns:
        Validated, frozen HaltonConfig instance.
    """
    config_path = path or _DEFAULT_CONFIG_PATH

    if not config_path.exists():
        return HaltonConfig()

    with config_path.open("rb") as fh:
        raw = tomllib.load(fh)

    return HaltonConfig.model_validate(raw)
