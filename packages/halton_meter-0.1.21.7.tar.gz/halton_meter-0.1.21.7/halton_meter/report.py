"""
Report formatting logic for Halton Meter CLI — Halton brand language.

Visual style (v0.1.20.dev0 — superseded the 2026-05-01 Bloomberg Terminal
aesthetic, which used cyan headers + gold money values):

  - Halton brand orange (#ea7d2e) for product headline + money values
  - Header blue (#7aa2d8) for table headers
  - Bright white for numeric alignment columns
  - Rounded box style for all tables (brand box.ROUNDED, not SIMPLE_HEAD)
  - Shared OK / WARN tokens for ticks + advisories — identical to status
    and doctor so green/yellow read the same across surfaces
  - Brand colours come from halton_meter.branding; never inline hex here

Money display: 1 USD = 100_000 millicents. Always show 6dp so sub-cent
amounts (e.g. 4 millicents = $0.000040) are never rounded to zero — this
is the load-bearing significant-digit highlighting; do NOT change the
format string without updating the test fixtures and the audit story.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import UTC, datetime
from typing import NamedTuple

from rich.console import Console

from halton_meter import __version__
from halton_meter.branding import (
    BRAND_ORANGE,
    HEADER_BLUE,
    MUTED,
    NUMERIC,
    OK,
    WARN,
    brand_table,
)
from halton_meter.models import LogRecord

# Local aliases keep the render functions readable without polluting the
# brand-language module. New colour tokens MUST land in branding.py first.
_BRAND = BRAND_ORANGE       # money values + headline accent
_HEADER = HEADER_BLUE       # table headers + key labels
_OK = OK                    # ✓ ticks
_WARN = WARN                # ⚠ advisories
_MUTED = MUTED              # secondary text
_WHITE = NUMERIC            # high-contrast right-aligned numbers

# Conversion constant — see memory/patterns.md and decisions.md 2026-04-28
_MILLICENTS_PER_USD: int = 100_000


def format_usd(millicents: int | None) -> str:
    """
    Format millicents as a USD string with 6 decimal places.

    6dp is required so that tiny values (e.g. 4 millicents = $0.000040) are
    visible rather than rounded to $0.0000.

    Args:
        millicents: Cost in millicents, or None if unknown.

    Returns:
        USD string like "$0.000040", or "N/A" if millicents is None.
    """
    if millicents is None:
        return "N/A"
    dollars = millicents / _MILLICENTS_PER_USD
    return f"${dollars:.6f}"


# ---------------------------------------------------------------------------
# Aggregation helpers
# ---------------------------------------------------------------------------


@dataclass
class ProjectStats:
    """Aggregated stats for a single project.

    Cost-handling policy (see decisions.md 2026-05-02 — "NULL cost handling
    in report aggregation"): records with ``cost_millicents is None`` are
    EXCLUDED from cost totals but STILL counted in ``requests`` /
    ``input_tokens`` / ``output_tokens`` / ``incomplete_count``. The number
    of cost-excluded records is tracked in ``cost_excluded_count`` so the
    renderer can surface a footnote. Previous behaviour (a single None row
    poisoning the entire grand total to ``None``) is gone.
    """

    project: str
    requests: int = 0
    input_tokens: int = 0
    output_tokens: int = 0
    cost_millicents: int = 0
    cost_excluded_count: int = 0
    latency_sum_ms: float = 0.0
    incomplete_count: int = 0

    def add(self, record: LogRecord) -> None:
        """Merge a single LogRecord into this stats bucket."""
        self.requests += 1
        self.input_tokens += record.input_tokens
        self.output_tokens += record.output_tokens
        if record.cost_millicents is None:
            self.cost_excluded_count += 1
        else:
            self.cost_millicents += record.cost_millicents
        self.latency_sum_ms += record.latency_ms
        if not record.tokens_complete:
            self.incomplete_count += 1

    @property
    def avg_latency_ms(self) -> float:
        """Average latency in milliseconds, or 0 if no requests."""
        return self.latency_sum_ms / self.requests if self.requests else 0.0


@dataclass
class ModelStats:
    """Aggregated stats for a single model.

    See ``ProjectStats`` for the NULL-cost handling policy.
    """

    model: str
    requests: int = 0
    input_tokens: int = 0
    output_tokens: int = 0
    cost_millicents: int = 0
    cost_excluded_count: int = 0

    def add(self, record: LogRecord) -> None:
        """Merge a single LogRecord into this stats bucket."""
        self.requests += 1
        self.input_tokens += record.input_tokens
        self.output_tokens += record.output_tokens
        if record.cost_millicents is None:
            self.cost_excluded_count += 1
        else:
            self.cost_millicents += record.cost_millicents


class ReportData(NamedTuple):
    """
    Processed data ready to render into a report.

    Produced by :func:`build_report_data` from a list of LogRecords.
    """

    records: list[LogRecord]
    total_requests: int
    total_input_tokens: int
    total_output_tokens: int
    total_cost_millicents: int
    cost_excluded_count: int  # records with NULL cost — excluded from cost totals only
    date_from: str | None  # ISO 8601 string of oldest record
    date_to: str | None  # ISO 8601 string of newest record
    incomplete_count: int
    project_stats: list[ProjectStats]
    model_stats: list[ModelStats]


def build_report_data(records: list[LogRecord]) -> ReportData:
    """
    Aggregate a list of LogRecords into a ReportData summary.

    Args:
        records: LogRecords to aggregate (order does not matter).

    Returns:
        ReportData with totals, per-project, and per-model breakdowns.
    """
    if not records:
        return ReportData(
            records=[],
            total_requests=0,
            total_input_tokens=0,
            total_output_tokens=0,
            total_cost_millicents=0,
            cost_excluded_count=0,
            date_from=None,
            date_to=None,
            incomplete_count=0,
            project_stats=[],
            model_stats=[],
        )

    project_map: dict[str, ProjectStats] = {}
    model_map: dict[str, ModelStats] = {}

    total_input = 0
    total_output = 0
    total_cost: int = 0
    cost_excluded_count = 0
    incomplete_count = 0
    dates: list[str] = []

    for rec in records:
        # project bucket
        if rec.project not in project_map:
            project_map[rec.project] = ProjectStats(project=rec.project)
        project_map[rec.project].add(rec)

        # model bucket
        if rec.model not in model_map:
            model_map[rec.model] = ModelStats(model=rec.model)
        model_map[rec.model].add(rec)

        # totals — NULL cost rows are excluded from the cost sum but still
        # contribute to request / token counts. See decisions.md 2026-05-02
        # ("NULL cost handling in report aggregation").
        total_input += rec.input_tokens
        total_output += rec.output_tokens
        if rec.cost_millicents is None:
            cost_excluded_count += 1
        else:
            total_cost += rec.cost_millicents
        if not rec.tokens_complete:
            incomplete_count += 1
        dates.append(rec.requested_at)

    dates_sorted = sorted(dates)
    date_from = dates_sorted[0] if dates_sorted else None
    date_to = dates_sorted[-1] if dates_sorted else None

    return ReportData(
        records=records,
        total_requests=len(records),
        total_input_tokens=total_input,
        total_output_tokens=total_output,
        total_cost_millicents=total_cost,
        cost_excluded_count=cost_excluded_count,
        date_from=date_from,
        date_to=date_to,
        incomplete_count=incomplete_count,
        project_stats=sorted(project_map.values(), key=lambda s: s.project),
        model_stats=sorted(model_map.values(), key=lambda s: s.model),
    )


# ---------------------------------------------------------------------------
# Rendering
# ---------------------------------------------------------------------------


def _format_date(iso_str: str | None) -> str:
    """Render an ISO 8601 string as a short human-readable date."""
    if iso_str is None:
        return "—"
    try:
        dt = datetime.fromisoformat(iso_str.replace("Z", "+00:00"))
        return dt.astimezone(UTC).strftime("%Y-%m-%d %H:%M UTC")
    except ValueError:
        return iso_str


def render_report(
    data: ReportData,
    console: Console,
    *,
    empty_hint: str | None = None,
) -> None:
    """
    Print the full report to *console* using rich formatting.

    Bloomberg Terminal aesthetic: bright cyan headers, gold for money,
    high-contrast bright white numbers, minimal grid tables. Designed to
    feel native in a financial terminal — dense, professional, scannable.

    Args:
        data: Pre-aggregated ReportData from :func:`build_report_data`.
        console: Rich Console to print to.
        empty_hint: Pre-rendered Rich markup string to show when there
            are no records. Callers (typically the CLI) are expected to
            tailor this to actual daemon state — see
            :func:`halton_meter.cli._empty_records_hint`. If None, falls
            back to a generic line. (2B.12.1)
    """
    _render_header(data, console)

    if data.total_requests == 0:
        if empty_hint is None:
            empty_hint = (
                f"[{_MUTED}]no records yet. Run[/] "
                f"[bold]halton-meter start[/] "
                f"[{_MUTED}]to begin metering, then route an LLM API "
                f"call through your client.[/]"
            )
        console.print(empty_hint + "\n")
        return

    _render_summary(data, console)
    _render_project_table(data, console)
    _render_model_table(data, console)


def _render_header(data: ReportData, console: Console) -> None:
    """Bloomberg-style header — cyan product name, gold version, clean date range."""
    range_str = ""
    if data.date_from and data.date_to:
        range_str = (
            f" [{_MUTED}]· "
            f"{_format_date(data.date_from)} → {_format_date(data.date_to)}[/]"
        )
    console.print()
    console.print(
        f"[bold {_BRAND}]halton-meter[/] "
        f"[{_BRAND}]v{__version__}[/] "
        f"[{_MUTED}]· cost report[/]{range_str}"
    )
    console.print()


def _render_summary(data: ReportData, console: Console) -> None:
    """Bloomberg-style summary — bright cyan labels, gold for cost, clean ✓ ticks."""
    project_count = len(data.project_stats)
    model_count = len(data.model_stats)
    project_word = "project" if project_count == 1 else "projects"
    model_word = "model" if model_count == 1 else "models"

    console.print(
        f"  [{_OK}]✓[/] "
        f"[{_WHITE}]{data.total_requests:,}[/] "
        f"[{_MUTED}]requests across[/] "
        f"[{_WHITE}]{project_count}[/] [{_MUTED}]{project_word} ·[/] "
        f"[{_WHITE}]{model_count}[/] [{_MUTED}]{model_word}[/]"
    )
    console.print(
        f"  [{_OK}]✓[/] "
        f"[{_MUTED}]Tokens:[/] "
        f"[{_WHITE}]{data.total_input_tokens:,}[/] [{_MUTED}]in ·[/] "
        f"[{_WHITE}]{data.total_output_tokens:,}[/] [{_MUTED}]out[/]"
    )
    console.print(
        f"  [{_OK}]✓[/] "
        f"[{_MUTED}]Total cost:[/] "
        f"[bold {_BRAND}]{format_usd(data.total_cost_millicents)}[/]"
    )
    if data.incomplete_count > 0:
        console.print(
            f"  [{_WARN}]⚠[/] "
            f"[{_WARN}]{data.incomplete_count} incomplete record(s) — "
            f"token counts may be partial[/]"
        )
    if data.cost_excluded_count > 0:
        # NULL-cost rows (unrecognised model / no pricing rate) are still
        # counted in requests + tokens but excluded from cost totals.
        # See decisions.md 2026-05-02.
        record_word = "record" if data.cost_excluded_count == 1 else "records"
        console.print(
            f"  [{_MUTED}]·[/] "
            f"[{_MUTED}]{data.cost_excluded_count} {record_word} with "
            f"unrecognised model / no pricing — counted in totals but "
            f"excluded from cost[/]"
        )
    console.print()


def _render_project_table(data: ReportData, console: Console) -> None:
    """Brand-language grid — rounded box, blue header, brand-orange cost
    column, right-aligned numerics in bright_white. Numeric alignment is
    preserved verbatim from the previous Bloomberg layout — only the
    colour palette changes."""
    # show_edge=False keeps the table reading as a "by project" grid
    # rather than a boxed sub-panel; the parent report frame is the
    # visual container.
    table = brand_table(show_edge=False)
    table.add_column(
        f"[{_HEADER}]by project[/]",
        no_wrap=True,
        style=_WHITE,
    )
    table.add_column("requests", justify="right", style=_WHITE)
    table.add_column("in", justify="right", style=_WHITE)
    table.add_column("out", justify="right", style=_WHITE)
    table.add_column("cost", justify="right", style=_BRAND)
    table.add_column("avg latency", justify="right", style=_WHITE)

    for s in data.project_stats:
        table.add_row(
            s.project,
            f"{s.requests:,}",
            f"{s.input_tokens:,}",
            f"{s.output_tokens:,}",
            format_usd(s.cost_millicents),
            f"{s.avg_latency_ms:.0f}ms",
        )

    console.print(table)


def _render_model_table(data: ReportData, console: Console) -> None:
    """Brand-language grid — rounded box, blue header, brand-orange cost
    column. Mirrors the project table's geometry; the only difference is
    the absent latency column (per-model latency averages aren't
    meaningful here)."""
    table = brand_table(show_edge=False)
    table.add_column(
        f"[{_HEADER}]by model[/]",
        no_wrap=True,
        style=_WHITE,
    )
    table.add_column("requests", justify="right", style=_WHITE)
    table.add_column("in", justify="right", style=_WHITE)
    table.add_column("out", justify="right", style=_WHITE)
    table.add_column("cost", justify="right", style=_BRAND)

    for s in data.model_stats:
        table.add_row(
            s.model,
            f"{s.requests:,}",
            f"{s.input_tokens:,}",
            f"{s.output_tokens:,}",
            format_usd(s.cost_millicents),
        )

    console.print(table)
    console.print()


# ---------------------------------------------------------------------------
# Date filtering helper (used by CLI)
# ---------------------------------------------------------------------------


def filter_records_by_days(records: list[LogRecord], since_days: int) -> list[LogRecord]:
    """
    Return records whose requested_at is within the last *since_days* days.

    A value of 0 returns no records (nothing happened "0 days ago").
    A value of 30 returns records from the last 30 days (default).

    Args:
        records: Full list of LogRecords to filter.
        since_days: Number of days to look back. 0 returns empty list.

    Returns:
        Filtered list of LogRecords.
    """
    if since_days <= 0:
        return []

    now = datetime.now(UTC)
    cutoff_ts = now.timestamp() - (since_days * 86400)

    result: list[LogRecord] = []
    for rec in records:
        try:
            dt = datetime.fromisoformat(rec.requested_at.replace("Z", "+00:00"))
            if dt.timestamp() >= cutoff_ts:
                result.append(rec)
        except ValueError:
            # If we can't parse the date, include the record (safe default)
            result.append(rec)
    return result
