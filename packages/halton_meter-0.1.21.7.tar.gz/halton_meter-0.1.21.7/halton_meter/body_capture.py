"""Hot-path body-capture support for the mitmproxy addon.

Pure helpers; no I/O on the synchronous code paths except a TTL-cached
SQLite lookup for the per-project opt-out. The actual write to the
``request_bodies`` table happens via ``StorageManager.write_body_record``
(see ``halton_meter.storage.repo``) so the schema layer stays the single
source of truth for table writes.

Scope guards (these are load-bearing — read before changing):

  * **Fail open.** Every code path here catches its own exceptions and
    returns a sentinel/None rather than raising. The proxy hot path catches
    again defensively, so this is belt-and-braces — but the explicit
    fail-open here makes the contract local and testable.
  * **No headers stored.** Only the request body and the response body
    land in SQLite. Authorization headers are NOT captured. Callers must
    not pass them in.
  * **Pure-buffer assumption.** mitmproxy is configured WITHOUT
    ``stream_large_bodies``; both ``flow.request.content`` and
    ``flow.response.content`` are fully buffered by the time the addon
    sees them. The capture functions here read the full body in one
    go — they are not chunk-aware. If you ever flip mitmproxy into
    streaming mode, this whole module needs revisiting.
  * **Master-switch wins.** ``HaltonConfig.bodies.enabled = False``
    short-circuits everything. ``BodyCaptureCache.is_enabled_for`` returns
    False unconditionally in that case; per-project opt-in cannot override.

PR2 wires this into ``HaltonAddon`` (``halton_meter.proxy``). PR1's
schema, redaction module, CLI, and BodiesConfig are already in place.
The rcfile-side ``body_capture = off`` override (open-question #6 sign-off)
is **not implemented in PR2**: the production attribution path runs in
the edge process and the daemon-side resolver doesn't see the rcfile in
the edge case. Wiring rcfile body_capture through the edge attribution
store is filed as a follow-up. The SQLite ``project_settings`` source-of-
truth is fully wired and is the canonical opt-out for v0.1.13.
"""

from __future__ import annotations

import json
import sqlite3
import time
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path

import structlog

from halton_meter.adapters.base import RequestMetadata
from halton_meter.redaction import RedactionHit, redact_credentials
from halton_meter.redaction.credentials import summarise_hits

log = structlog.get_logger()


# --------------------------------------------------------------------------- #
# Captured-body container                                                     #
# --------------------------------------------------------------------------- #


@dataclass(frozen=True)
class CapturedBody:
    """One side (request OR response) of a captured exchange.

    ``text`` is the post-redaction, post-truncation string we'll write to
    SQLite. ``original_bytes`` is the pre-truncation byte size (so the
    dashboard can surface "stored 124 KB / 1.2 MB"). ``content_type`` is
    whatever the headers say.

    Both ``text`` and ``content_type`` may be None on failure paths;
    ``capture_error`` carries the reason. The row will still be written so
    downstream consumers can tell "we tried and failed" from "no row".
    """

    text: str | None
    original_bytes: int
    truncated: bool
    content_type: str | None
    redaction_hits: list[RedactionHit]
    capture_error: str | None  # e.g. "request_decode_failed"

    @property
    def redacted(self) -> bool:
        return bool(self.redaction_hits)


@dataclass(frozen=True)
class PendingCapture:
    """What we stash in ``HaltonAddon._pending`` between request and response.

    Replaces the prior ``tuple[RequestMetadata, str]``. ``request_body`` is
    None when capture is opted out for this project (we still write the
    counts row, but we never touch the body table). ``request_body`` is also
    None when the request hook ran into a decode/redaction failure — those
    cases are recorded into a body row only if we have something useful to
    write; for a complete capture-error case we still write the response-side
    capture-error row so the operator sees "we tried" rather than nothing.
    """

    meta: RequestMetadata
    requested_at: str
    request_body: CapturedBody | None  # None == opted out


# --------------------------------------------------------------------------- #
# Capture function (pure)                                                     #
# --------------------------------------------------------------------------- #


def _content_type(message: object) -> str | None:
    """Best-effort content-type extraction from a mitmproxy request/response."""
    try:
        headers = getattr(message, "headers", None)
        if headers is None:
            return None
        ct = headers.get("content-type")
        if ct is None:
            return None
        return str(ct)[:255]
    except Exception:
        return None


def _is_binary_content_type(ct: str | None) -> bool:
    """Heuristic: skip body capture for clearly-binary content types.

    JSON, SSE, plaintext, form-encoded, XML are all in scope. Anything
    starting with ``image/`` / ``audio/`` / ``video/`` / a few known
    binary MIMEs is not. We keep this list tight on purpose — when in
    doubt, capture; truncation handles the rest.
    """
    if not ct:
        return False
    lower = ct.lower()
    return (
        lower.startswith("image/")
        or lower.startswith("audio/")
        or lower.startswith("video/")
        or lower.startswith("application/octet-stream")
        or lower.startswith("application/x-protobuf")
    )


def capture_body(
    message: object,
    *,
    max_bytes: int,
    side: str,  # "request" | "response"
) -> CapturedBody:
    """Read, truncate, redact one side of an HTTP exchange.

    ``message`` is a mitmproxy ``http.Request`` or ``http.Response``.
    Never raises — the caller's defence-in-depth should catch anyway, but
    every error here turns into a CapturedBody with ``capture_error`` set.

    Truncation is byte-accurate: we read raw ``content`` bytes, slice at
    ``max_bytes``, then UTF-8 decode (replacing invalid sequences). This
    matches how mitmproxy's ``get_text`` behaves under decode errors.
    """
    content_type = _content_type(message)

    if _is_binary_content_type(content_type):
        return CapturedBody(
            text=None,
            original_bytes=0,
            truncated=False,
            content_type=content_type,
            redaction_hits=[],
            capture_error="binary_body_skipped",
        )

    raw_attr = "content"
    try:
        raw = getattr(message, raw_attr, None)
        if raw is None:
            return CapturedBody(
                text=None,
                original_bytes=0,
                truncated=False,
                content_type=content_type,
                redaction_hits=[],
                capture_error=None,
            )
        if not isinstance(raw, bytes):
            # mitmproxy sometimes hands us str; coerce to bytes for the
            # truncation length math.
            raw_bytes = str(raw).encode("utf-8", errors="replace")
        else:
            raw_bytes = raw
    except Exception as exc:
        log.warning(
            "addon.body_capture.read_failed",
            side=side,
            error=str(exc),
        )
        return CapturedBody(
            text=None,
            original_bytes=0,
            truncated=False,
            content_type=content_type,
            redaction_hits=[],
            capture_error=f"{side}_read_failed",
        )

    original = len(raw_bytes)
    if original <= max_bytes:
        sliced = raw_bytes
        truncated = False
    else:
        sliced = raw_bytes[:max_bytes]
        truncated = True

    try:
        text = sliced.decode("utf-8", errors="replace")
    except Exception as exc:
        log.warning(
            "addon.body_capture.decode_failed",
            side=side,
            error=str(exc),
        )
        return CapturedBody(
            text=None,
            original_bytes=original,
            truncated=truncated,
            content_type=content_type,
            redaction_hits=[],
            capture_error=f"{side}_decode_failed",
        )

    try:
        redacted_text, hits = redact_credentials(text)
    except Exception as exc:
        # Fail closed on this one — drop the body rather than write one we
        # can't certify. Plan: "Set capture_error=redaction_failed. Do
        # NOT write the body. Mark redaction_applied=False."
        log.error(
            "addon.body_capture.redaction_failed",
            side=side,
            error=str(exc),
            exc_info=True,
        )
        return CapturedBody(
            text=None,
            original_bytes=original,
            truncated=truncated,
            content_type=content_type,
            redaction_hits=[],
            capture_error="redaction_failed",
        )

    return CapturedBody(
        text=redacted_text,
        original_bytes=original,
        truncated=truncated,
        content_type=content_type,
        redaction_hits=hits,
        capture_error=None,
    )


def merge_redaction_summary(
    request_hits: list[RedactionHit],
    response_hits: list[RedactionHit],
) -> str | None:
    """Combine the per-side redaction counts into a single JSON map.

    Returns None when nothing was redacted (so the column stays NULL and
    we don't pay JSON-overhead bytes per row). The map is the canonical
    storage shape for ``request_bodies.redaction_summary``.
    """
    if not request_hits and not response_hits:
        return None
    summary = summarise_hits(request_hits + response_hits)
    if not summary:
        return None
    return json.dumps(summary, sort_keys=True)


# --------------------------------------------------------------------------- #
# Per-project opt-out cache (5-min TTL)                                       #
# --------------------------------------------------------------------------- #


class BodyCaptureCache:
    """In-memory TTL cache over ``project_settings.body_capture_enabled``.

    Hot-path lookup is a dict get; misses fall through to a single SQLite
    SELECT on the project's slug. The TTL means a CLI flip (``halton-meter
    project <slug> set body-capture off``) takes effect within
    ``cache_ttl_seconds`` (default 5 min) without daemon restart.

    Master switch (``HaltonConfig.bodies.enabled``) wins:
    ``is_enabled_for`` returns False whenever ``master_enabled`` is False,
    regardless of the per-project value.

    Default ON when no row exists (matches the column default).
    """

    def __init__(
        self,
        db_path: Path,
        master_enabled: bool,
        ttl_seconds: int = 300,
    ) -> None:
        self._db_path = db_path
        self._master_enabled = master_enabled
        self._ttl_seconds = ttl_seconds
        # project slug → (cached value, expiry monotonic ts)
        self._cache: dict[str, tuple[bool, float]] = {}

    @property
    def master_enabled(self) -> bool:
        return self._master_enabled

    def is_enabled_for(self, project_slug: str) -> bool:
        """Return True iff body capture should run for ``project_slug``.

        Master switch wins. Then the SQLite source of truth (cached).
        Default ON when there's no row.
        """
        if not self._master_enabled:
            return False
        if not project_slug:
            # Defensive: an empty / whitespace project name resolves to
            # ``unattributed`` upstream. Capture for that bucket too — the
            # operator can opt out by setting body-capture off on the
            # ``unattributed`` slug if they want.
            project_slug = project_slug or ""

        now = time.monotonic()
        cached = self._cache.get(project_slug)
        if cached is not None and cached[1] > now:
            return cached[0]

        enabled = self._read_db_value(project_slug)
        self._cache[project_slug] = (enabled, now + self._ttl_seconds)
        return enabled

    def invalidate(self, project_slug: str | None = None) -> None:
        """Drop cached entries.

        Call with a slug to drop one entry; call with no args to drop the
        whole cache (e.g. on test teardown). The TTL also expires entries
        on its own; this is just for explicit/test-driven flushing.
        """
        if project_slug is None:
            self._cache.clear()
        else:
            self._cache.pop(project_slug, None)

    def _read_db_value(self, project_slug: str) -> bool:
        """SQLite SELECT for a project's body_capture_enabled flag.

        Precedence (after the master switch, which is checked by the
        caller ``is_enabled_for``):

          1. ``project_settings.body_capture_enabled`` for the matching
             ``projects.slug`` — the canonical CLI-driven opt-out.
          2. ``attribution_log.body_capture_enabled`` on the most recent
             row for ``project_name = project_slug`` — the rcfile-driven
             opt-out plumbed through the edge in B1 (2026-05-02). The
             edge writes one row per CONNECT keyed by source port; we
             pick the freshest by ``created_at`` for the project name
             the daemon's tagger resolved.
          3. Default ON.

        Default-ON also applies when the DB file is missing or any
        read raises. The function never raises — fail-open. Both
        queries run in a single connection to amortise open cost.
        """
        if not self._db_path.exists():
            return True
        try:
            with sqlite3.connect(str(self._db_path)) as conn:
                conn.row_factory = sqlite3.Row
                cur = conn.execute(
                    "SELECT ps.body_capture_enabled "
                    "FROM projects p "
                    "LEFT JOIN project_settings ps ON ps.project_id = p.id "
                    "WHERE p.slug = ?",
                    (project_slug,),
                )
                ps_row = cur.fetchone()
                # If the project_settings row exists with an explicit
                # value, it wins — the CLI is the canonical surface.
                if ps_row is not None:
                    bce = ps_row["body_capture_enabled"]
                    if bce is not None:
                        return bool(bce)

                # Fallback: attribution_log freshest row for this
                # project. The edge writes ``body_capture_enabled``
                # alongside ``project_name`` from the resolved
                # ``.haltonrc``. Table is small (low hundreds of rows
                # at peak, opportunistic prune every 50 writes), so the
                # ORDER BY scan is cheap; we don't add an index here.
                # If the table doesn't exist yet (greenfield), the
                # OperationalError lands in the except block below and
                # we default ON.
                cur = conn.execute(
                    "SELECT body_capture_enabled "
                    "FROM attribution_log "
                    "WHERE project_name = ? "
                    "ORDER BY created_at DESC LIMIT 1",
                    (project_slug,),
                )
                attr_row = cur.fetchone()
        except sqlite3.Error as exc:
            log.warning(
                "addon.body_capture.optout_lookup_failed",
                project=project_slug,
                error=str(exc),
            )
            return True

        if attr_row is not None:
            bce = attr_row["body_capture_enabled"]
            if bce is not None:
                return bool(bce)

        return True  # no signal anywhere — default ON


# --------------------------------------------------------------------------- #
# Helper for the addon: capture metadata for the requests-bodies row write.  #
# --------------------------------------------------------------------------- #


@dataclass(frozen=True)
class BodyRecord:
    """Plain shape passed to ``StorageManager.write_body_record``.

    Decoupled from the SQLAlchemy model so the proxy hot path doesn't import
    the storage models directly (matches how ``LogRecord`` works for the
    counts row).
    """

    request_id: str
    request_body: str | None
    response_body: str | None
    request_body_bytes: int
    response_body_bytes: int
    request_content_type: str | None
    response_content_type: str | None
    request_truncated: bool
    response_truncated: bool
    redaction_applied: bool
    capture_error: str | None
    redaction_summary: str | None  # JSON string or None
    captured_at: datetime


def build_body_record(
    *,
    request_id: str,
    request_body: CapturedBody | None,
    response_body: CapturedBody | None,
) -> BodyRecord | None:
    """Combine the two captured sides into a single ``BodyRecord``.

    Returns None when both sides are None (don't write a body row when
    nothing was captured — the counts row already lands separately).

    A side that captured a body successfully overrides ``capture_error``
    when both sides have errors; otherwise the response-side capture_error
    is preserved (the operator usually cares more about the response).
    """
    if request_body is None and response_body is None:
        return None

    rb_text = request_body.text if request_body else None
    sb_text = response_body.text if response_body else None
    rb_bytes = request_body.original_bytes if request_body else 0
    sb_bytes = response_body.original_bytes if response_body else 0
    rb_ct = request_body.content_type if request_body else None
    sb_ct = response_body.content_type if response_body else None
    rb_trunc = bool(request_body.truncated) if request_body else False
    sb_trunc = bool(response_body.truncated) if response_body else False

    redaction_applied = (
        (request_body is not None and request_body.redacted)
        or (response_body is not None and response_body.redacted)
    )
    summary = merge_redaction_summary(
        request_body.redaction_hits if request_body else [],
        response_body.redaction_hits if response_body else [],
    )

    capture_error: str | None = None
    if response_body is not None and response_body.capture_error:
        capture_error = response_body.capture_error
    elif request_body is not None and request_body.capture_error:
        capture_error = request_body.capture_error

    return BodyRecord(
        request_id=request_id,
        request_body=rb_text,
        response_body=sb_text,
        request_body_bytes=rb_bytes,
        response_body_bytes=sb_bytes,
        request_content_type=rb_ct,
        response_content_type=sb_ct,
        request_truncated=rb_trunc,
        response_truncated=sb_trunc,
        redaction_applied=redaction_applied,
        capture_error=capture_error,
        redaction_summary=summary,
        captured_at=datetime.now(tz=UTC),
    )
