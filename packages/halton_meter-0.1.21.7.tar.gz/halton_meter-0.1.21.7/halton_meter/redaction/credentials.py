"""Deterministic credential redaction.

Pure-function regex pass over a UTF-8 string. Returns the redacted text plus
a list of ``RedactionHit`` records describing each substitution. Used by
the proxy hot path's body-capture step (PR2) to scrub known credential
shapes from captured bodies BEFORE they hit SQLite.

Scope is **credentials only** by product call (operator, 2026-05-01). No
PII detection — names, emails, addresses, phone numbers stay as-is. The
prompt-optimisation use case wants the prose intact.

Patterns and ordering decisions live in ``memory/plans/2026-05-01-body-capture.md``.
A few highlights worth understanding before touching this file:

  * **Order matters.** More specific patterns are tested first. ``sk-ant-…``
    must match BEFORE ``sk-…`` so an Anthropic SK is not mis-categorised
    as ``openai_key``.
  * **AWS secret-key only fires when paired with an access key.** The
    40-char base64-ish shape has very high false-positive risk (matches
    SHA256 hashes, base64 image data, JWT segments, …). We only run that
    pattern when the same body already contained an ``AKIA…`` access
    key. Open-question #2 sign-off, 2026-05-01.
  * **Stripe publishable keys are redacted.** They're public per Stripe's
    docs but we strip them anyway for defensive consistency. Open-question
    #3 sign-off, 2026-05-01.
  * **Replacement is length-non-preserving.** ``[REDACTED:<category>]``
    rather than e.g. asterisks. We don't try to preserve original length
    (that itself leaks information about the secret).
  * **Reads are plaintext-as-stored.** Bodies land in SQLite already
    redacted; ``halton-meter bodies show`` returns exactly the bytes we
    wrote. One redaction pass per body, not on every read.
"""

from __future__ import annotations

import re
from collections import Counter
from dataclasses import dataclass


@dataclass(frozen=True)
class RedactionHit:
    """One credential substitution.

    ``span`` is the (start, end) range in the **original** input string —
    convenient for tests and audit. ``placeholder`` is the literal text
    that replaced the match.
    """

    category: str
    span: tuple[int, int]
    placeholder: str


# ---------------------------------------------------------------------------
# Pattern set (ordered: most specific first).
#
# Each entry: (category, compiled regex, placeholder).
#
# IMPORTANT: when adding a pattern, prepend it if it could be confused with
# an entry already in the list (e.g. a more-specific anthropic_key prefix
# beats the generic openai_key sk- prefix).
# ---------------------------------------------------------------------------

_PLACEHOLDER_FMT = "[REDACTED:{category}]"


def _ph(category: str) -> str:
    return _PLACEHOLDER_FMT.format(category=category)


# Anthropic before OpenAI — sk-ant- is a strict prefix of sk-, so the more
# specific match must be tested first.
_ANTHROPIC_KEY_RE = re.compile(r"sk-ant-[A-Za-z0-9_-]{20,}")
# Stripe (live/test) before OpenAI — sk_live_ / sk_test_ have the
# underscore form that openai_key's hyphen pattern would not match anyway,
# but ordering keeps the categorisation principled.
_STRIPE_SECRET_RE = re.compile(r"sk_(?:live|test)_[A-Za-z0-9]{24,}")
# OpenAI catch-all sk- shape. Comes after the more specific sk-ant- and
# sk_(live|test)_ entries so they win.
_OPENAI_KEY_RE = re.compile(r"sk-[A-Za-z0-9_-]{20,}")
# AWS access key. Standard 16-char shape after the AKIA prefix.
_AWS_ACCESS_KEY_RE = re.compile(r"AKIA[0-9A-Z]{16}")
# AWS secret key — 40-char base64-ish blob. ONLY applied when an
# AKIA access key was already found in the same body (open Q#2).
# The character class for the body of the key is ``[A-Za-z0-9/+]``; the
# ``=`` padding character is allowed only as the terminator (which the
# 40-char shape does not require). Boundary lookarounds exclude the same
# character class on either side so the regex won't match inside a
# longer base64 blob — but we deliberately do NOT exclude ``=`` from the
# lookbehind, because the conventional config-file shape places ``=``
# (assignment operator) immediately before the value.
_AWS_SECRET_KEY_RE = re.compile(r"(?<![A-Za-z0-9/+])[A-Za-z0-9/+]{40}(?![A-Za-z0-9/+])")
# JWT — three base64url segments separated by dots, first starts with
# eyJ which is the literal "{" base64-encoded.
_JWT_RE = re.compile(r"eyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+")
# GitHub fine-grained / classic PAT. Covers ghp_, gho_, ghu_, ghs_, ghr_.
_GITHUB_PAT_RE = re.compile(r"gh[pousr]_[A-Za-z0-9]{36}")
# Stripe publishable. Public per Stripe's docs — we redact anyway (open Q#3).
_STRIPE_PUBLISHABLE_RE = re.compile(r"pk_(?:live|test)_[A-Za-z0-9]{24,}")
# Google API key.
_GOOGLE_API_KEY_RE = re.compile(r"AIza[A-Za-z0-9_-]{35}")
# xAI (Grok) key. Standard shape is ``xai-`` followed by ~80 alphanumeric
# chars. Use a 40+ char floor — long enough to avoid prose like
# ``xai-team`` or ``xai-roadmap`` getting hit, short enough that any real
# key (which is much longer) is still caught. Added 2026-05-02 alongside
# the multi-provider adapter PR2.
_XAI_KEY_RE = re.compile(r"xai-[A-Za-z0-9]{40,}")
# Generic Bearer-token catch-all. Lower priority than the specific
# patterns above (those should already have redacted the actual token).
# Substitutes only the token portion, leaving the literal
# Authorization/Bearer prefix intact.
_BEARER_TOKEN_RE = re.compile(
    r"(?P<prefix>(?i:authorization|bearer)[\s:]+)(?P<token>[A-Za-z0-9._-]{20,})"
)


# Ordered for deterministic application. The function below applies each
# in order against the (mutating) text and resolves spans against the
# pre-substitution input via offset bookkeeping.
_PATTERNS: tuple[tuple[str, re.Pattern[str], str], ...] = (
    ("anthropic_key", _ANTHROPIC_KEY_RE, _ph("anthropic_key")),
    ("stripe_secret", _STRIPE_SECRET_RE, _ph("stripe_secret")),
    ("openai_key", _OPENAI_KEY_RE, _ph("openai_key")),
    ("aws_access_key", _AWS_ACCESS_KEY_RE, _ph("aws_access_key")),
    ("jwt", _JWT_RE, _ph("jwt")),
    ("github_pat", _GITHUB_PAT_RE, _ph("github_pat")),
    ("stripe_publishable", _STRIPE_PUBLISHABLE_RE, _ph("stripe_publishable")),
    ("google_api_key", _GOOGLE_API_KEY_RE, _ph("google_api_key")),
    ("xai_key", _XAI_KEY_RE, _ph("xai_key")),
    # bearer_token applied last; specific tokens above will already have
    # been replaced (a placeholder like ``[REDACTED:openai_key]`` is too
    # short to match the 20+ char bearer token regex anyway).
)


def redact_credentials(text: str) -> tuple[str, list[RedactionHit]]:
    """Return ``(redacted_text, hits)``.

    Pure function. Empty input → ``("", [])``. Input must be a ``str``;
    callers that hold ``bytes`` should ``.decode("utf-8", errors="replace")``
    first. Never raises under normal use; defensive programming in the
    caller (the proxy hot path) catches the unexpected case anyway.

    ``hits`` carries spans into the **original** input, not the post-redaction
    text — convenient for tests and audit. Categories appear in the order
    they were detected (one pattern at a time, left-to-right within each
    pattern).
    """
    if not text:
        return "", []

    # Per-pattern application against a mutating buffer. We track a parallel
    # offset map so that ``span`` in the returned hits points back into the
    # original input even though substitution shifts indices in the buffer.
    redacted = text
    hits: list[RedactionHit] = []

    # Detect AKIA access keys first. If none, we skip the high-FP-risk
    # 40-char secret-key pattern entirely (open Q#2 sign-off).
    saw_aws_access_key = bool(_AWS_ACCESS_KEY_RE.search(text))

    for category, pattern, placeholder in _PATTERNS:
        # Walk the original text to compute spans (so test assertions hit
        # the input as the caller passed it). Then perform the substitution
        # on the redacted buffer.
        for match in pattern.finditer(text):
            hits.append(
                RedactionHit(
                    category=category,
                    span=match.span(),
                    placeholder=placeholder,
                )
            )
        # Substitute on the working buffer. Use a simple sub so the
        # placeholder is identical to the one recorded in hits.
        if pattern is _BEARER_TOKEN_RE:
            # Special case: replace only the token group, keep the prefix.
            redacted = pattern.sub(rf"\g<prefix>{placeholder}", redacted)
        else:
            redacted = pattern.sub(placeholder, redacted)

    # AWS secret key — only when an access key was already in the body.
    if saw_aws_access_key:
        sk_placeholder = _ph("aws_secret_key")
        # Match against the original text for span reporting; substitute
        # on the working buffer the same way.
        for match in _AWS_SECRET_KEY_RE.finditer(text):
            # Skip if the match overlaps a position already redacted by a
            # more-specific pattern — guard against double-categorising the
            # 40-char trailing portion of an OpenAI key for example.
            if _is_in_existing_hit(match.span(), hits):
                continue
            hits.append(
                RedactionHit(
                    category="aws_secret_key",
                    span=match.span(),
                    placeholder=sk_placeholder,
                )
            )
        # On the working buffer, redact only the spans whose text still
        # matches (i.e. weren't already replaced by another category).
        redacted = _AWS_SECRET_KEY_RE.sub(sk_placeholder, redacted)

    # Bearer token last — applied to the working buffer. Pre-redacted
    # placeholders like "[REDACTED:openai_key]" don't match the 20+ char
    # alphanumeric pattern, so this can't double-redact a real token.
    placeholder = _ph("bearer_token")
    for match in _BEARER_TOKEN_RE.finditer(text):
        # Skip if the bearer's token group overlaps a more specific hit
        # already recorded.
        token_span = match.span("token")
        if _is_in_existing_hit(token_span, hits):
            continue
        hits.append(
            RedactionHit(
                category="bearer_token",
                span=token_span,
                placeholder=placeholder,
            )
        )
    redacted = _BEARER_TOKEN_RE.sub(rf"\g<prefix>{placeholder}", redacted)

    return redacted, hits


def _is_in_existing_hit(
    span: tuple[int, int], hits: list[RedactionHit]
) -> bool:
    """Return True when ``span`` overlaps any prior hit's span."""
    s, e = span
    for h in hits:
        hs, he = h.span
        if s < he and hs < e:
            return True
    return False


def summarise_hits(hits: list[RedactionHit]) -> dict[str, int]:
    """Counts of redactions per category. Convenient for the
    ``redaction_summary`` JSON column. Empty input → ``{}``.
    """
    if not hits:
        return {}
    return dict(Counter(h.category for h in hits))
