"""Credential redaction for captured request/response bodies.

Public surface:

    from halton_meter.redaction import RedactionHit, redact_credentials

The module is regex-only (no third-party deps). Patterns and behaviour are
documented in ``credentials.py`` and in
``memory/plans/2026-05-01-body-capture.md``.
"""

from __future__ import annotations

from halton_meter.redaction.credentials import (
    RedactionHit,
    redact_credentials,
)

__all__ = ["RedactionHit", "redact_credentials"]
