"""Halton Meter brand language for terminal surfaces.

The single source of truth for visual tokens (colours, box style, icons,
table padding) and small builder helpers (``brand_panel``, ``brand_table``,
``brand_progress``) used across the daily-driven CLI surfaces.

Why this lives in its own module
--------------------------------
Visual unification across ``status`` / ``doctor`` / ``report`` / lifecycle
surfaces was previously inconsistent: ``report`` shipped a Bloomberg
Terminal palette (cyan + gold), ``status`` used Rich default styles, and
the lifecycle panels picked colours per-call. Phase 0.5 of the v0.2
roadmap asked for a single brand language: rounded boxes, brand-orange
accents (``#ea7d2e``), consistent semantic colour assignments.

Adding a new surface? Use ``brand_panel`` / ``brand_table`` / the colour
tokens — never hard-code hex values or pick arbitrary Rich named colours.
That keeps every surface visually coherent without any single render site
needing to know the full palette.

See ``daemon/docs/brand-language.md`` for the contributor-facing spec.

Pure helpers — no I/O, no Rich state mutation, no implicit Console use.
Callers pass a ``Console`` in. Returns Rich renderables / styles strings.
"""

from __future__ import annotations

from typing import Any

from rich import box
from rich.panel import Panel
from rich.progress import (
    BarColumn,
    Progress,
    ProgressColumn,
    SpinnerColumn,
    Task,
    TaskProgressColumn,
    TextColumn,
    TimeElapsedColumn,
)
from rich.table import Table
from rich.text import Text

# ---------------------------------------------------------------------------
# Colour tokens
# ---------------------------------------------------------------------------
#
# Single source of truth. If a render site needs a colour, it imports from
# here. New colours land here first, with a one-line rationale.

#: Halton brand orange. Used for headlines, primary borders, money values
#: in cost reports, and the chevron accent. Hex form so Rich renders the
#: exact brand colour rather than a 256-colour approximation.
BRAND_ORANGE: str = "#ea7d2e"

#: Soft slate-blue for headers and labels in tables. Pairs cleanly with
#: brand orange without competing for attention.
HEADER_BLUE: str = "#7aa2d8"

#: High-contrast neutral for primary numeric content (token counts, request
#: counts, dates). Reads as bright on dark terminals and ink-black on light
#: terminals because Rich's ``bright_white`` resolves per-terminal.
NUMERIC: str = "bright_white"

#: Subdued grey for secondary text — labels, units, captions, footnotes.
MUTED: str = "grey58"

#: Status semantics. Reused identically across status / doctor / report.
OK: str = "bright_green"
WARN: str = "#f0c674"  # amber
ERROR: str = "#e06c75"  # soft red — reads better than pure red on dark bg
INFO: str = HEADER_BLUE

#: Standard box style across panels and tables. Rounded corners are the
#: brand signature.
BOX_STYLE = box.ROUNDED

#: Padding tuple for tables — vertical 0, horizontal 2. Matches the Phase 0.5
#: spec and gives readable density without feeling cramped.
TABLE_PADDING: tuple[int, int] = (0, 2)

# ---------------------------------------------------------------------------
# Iconography
# ---------------------------------------------------------------------------
#
# We expose both glyph and plain forms. The doctor module already has its
# own glyph/plain split for legacy reasons; new surfaces use these.

ICON_OK: str = "✓"
ICON_WARN: str = "⚠"
ICON_ERROR: str = "✗"
ICON_INFO: str = "ℹ"  # noqa: RUF001 — intentional Unicode glyph
ICON_BULLET: str = "•"
ICON_CHEVRON: str = "›"  # noqa: RUF001 — intentional Unicode glyph

# ---------------------------------------------------------------------------
# Severity → colour mapping helpers
# ---------------------------------------------------------------------------


def severity_color(severity: str) -> str:
    """Map a severity-ish string to its brand colour token.

    Accepts the union of strings used across status / doctor / lifecycle
    today: ``HEALTHY``, ``INCONSISTENT``, ``BROKEN``, ``healthy``,
    ``warn``, ``error``, ``ok``, ``info``. Unknown severities fall through
    to ``MUTED`` so render sites never crash.
    """
    s = severity.strip().lower()
    if s in ("healthy", "ok", "success", "green"):
        return OK
    if s in ("inconsistent", "warn", "warning", "yellow"):
        return WARN
    if s in ("broken", "error", "fail", "failed", "red"):
        return ERROR
    # v0.1.21: ``stopped`` is the manual-start "metering paused"
    # verdict. Render in INFO blue — calmer than amber/red, distinct
    # from OK green.
    if s in ("info", "blue", "stopped"):
        return INFO
    return MUTED


# ---------------------------------------------------------------------------
# Panel / Table / Progress factories
# ---------------------------------------------------------------------------


def brand_panel(
    body: Any,
    *,
    title: str | None = None,
    severity: str = "info",
    expand: bool = False,
    padding: tuple[int, int] = (1, 2),
) -> Panel:
    """Build a brand-language Panel.

    Rounded corners, severity-driven border colour, brand-orange title
    when severity is ``info`` or unset (the default for "neutral" panels
    like ``halton-meter start`` summary), severity colour otherwise.

    Args:
        body: Renderable or markup string for the body.
        title: Panel title (omitted if None).
        severity: One of ``ok`` / ``warn`` / ``error`` / ``info``. Drives
            border + title colour. Unknown severities fall through to
            ``MUTED``.
        expand: Whether the panel stretches to console width (default False
            — panels shrink to fit). NEVER pass a hardcoded ``width``.
        padding: Inner padding tuple. Default ``(1, 2)`` reads cleanly.
    """
    border = severity_color(severity) if severity != "info" else BRAND_ORANGE
    title_markup: str | None
    if title is None:
        title_markup = None
    else:
        # Brand-orange titles on info; severity colour otherwise.
        colour = BRAND_ORANGE if severity == "info" else severity_color(severity)
        title_markup = f"[bold {colour}]{title}[/bold {colour}]"
    return Panel(
        body,
        title=title_markup,
        border_style=border,
        box=BOX_STYLE,
        expand=expand,
        padding=padding,
    )


def brand_table(
    *,
    title: str | None = None,
    show_lines: bool = False,
    expand: bool = False,
    show_edge: bool = True,
) -> Table:
    """Build a brand-language Table shell.

    Caller adds columns + rows. We pre-set: rounded box, brand padding,
    blue header style, optional brand-orange title.

    Args:
        title: Optional table title; rendered in brand orange + bold.
        show_lines: Inter-row dividers. Default off (denser).
        expand: Stretch to console width. Default off (table shrinks to
            content).
        show_edge: Outer border. Default on; pass False for "grid only"
            layouts (used in the report's by-project / by-model tables).
    """
    title_markup: str | None
    if title is None:
        title_markup = None
    else:
        title_markup = f"[bold {BRAND_ORANGE}]{title}[/bold {BRAND_ORANGE}]"
    table = Table(
        title=title_markup,
        box=BOX_STYLE,
        show_lines=show_lines,
        expand=expand,
        show_edge=show_edge,
        padding=TABLE_PADDING,
        header_style=f"bold {HEADER_BLUE}",
    )
    return table


def brand_progress(*, transient: bool = True) -> Progress:
    """Build a brand-language Progress bar.

    Spinner + description + bar + percent + elapsed. Bar uses brand
    orange for the completed portion and muted grey for the remainder.

    Args:
        transient: Whether to clear the bar on completion. Default True
            (cleaner final output).
    """
    return Progress(
        SpinnerColumn(style=BRAND_ORANGE),
        TextColumn("[progress.description]{task.description}"),
        BarColumn(
            complete_style=BRAND_ORANGE,
            finished_style=OK,
            pulse_style=BRAND_ORANGE,
        ),
        TaskProgressColumn(),
        TimeElapsedColumn(),
        transient=transient,
    )


class _SubSecondElapsedColumn(ProgressColumn):
    """Elapsed-time column that renders sub-second precision.

    Default ``TimeElapsedColumn`` formats as ``H:MM:SS`` which loses
    information for sub-second phases (cert checks frequently complete
    in <100ms). The brand reference shows ``2.1s`` / ``800ms`` style
    timings on the right edge — readable signal for fast no-ops while
    still legible for slower work.

    Format rules:
      * < 1s          → ``Nms``  (e.g. ``230ms``)
      * < 60s         → ``N.Ns`` (e.g. ``2.1s``)
      * >= 60s        → ``H:MM:SS`` (fall back to default)
    """

    def render(self, task: Task) -> Text:
        elapsed = task.finished_time if task.finished else task.elapsed
        if elapsed is None:
            return Text("--", style=MUTED)
        if elapsed < 1.0:
            label = f"{int(elapsed * 1000)}ms"
        elif elapsed < 60.0:
            label = f"{elapsed:.1f}s"
        else:
            mins, secs = divmod(int(elapsed), 60)
            hrs, mins = divmod(mins, 60)
            label = (
                f"{hrs}:{mins:02d}:{secs:02d}"
                if hrs
                else f"{mins}:{secs:02d}"
            )
        return Text(label, style=MUTED)


def brand_phase_progress() -> Progress:
    """Build a brand-language per-phase Progress with persisted lines.

    Layout: ``[spinner]  description …                    elapsed``.

    Each call site adds one task per phase via ``progress.add_task(desc,
    total=1)``. While the task is incomplete the orange spinner shows;
    once the caller marks it complete (``progress.update(task_id,
    completed=1)`` or ``advance=1``), Rich's ``SpinnerColumn`` swaps the
    spinner glyph for the ``finished_text`` (a brand-coloured ``✓``)
    and freezes the elapsed time. ``transient=False`` keeps every
    completed line on screen — this is the v0.1.20.dev3 mockup shape.

    No bar / percent column: per-phase work is single-shot, the bar
    would just sit at 0% then jump to 100%. The elapsed column is the
    informative bit.

    Reuses ``BRAND_ORANGE`` for the spinner + finished glyph and
    ``MUTED`` for the elapsed timing so the right edge reads as
    secondary text.
    """
    return Progress(
        SpinnerColumn(
            style=BRAND_ORANGE,
            finished_text=f"[{OK}]{ICON_OK}[/{OK}]",
        ),
        TextColumn("[progress.description]{task.description}"),
        _SubSecondElapsedColumn(),
        transient=False,
    )


# ---------------------------------------------------------------------------
# Headline helper
# ---------------------------------------------------------------------------


def brand_headline(product: str, version: str, subtitle: str | None = None) -> str:
    """Build the standard ``halton-meter v0.1.20 · subtitle`` headline.

    Brand orange product, muted version, muted subtitle. Returned as a
    Rich markup string; caller controls when / where to print.
    """
    parts = [f"[bold {BRAND_ORANGE}]{product}[/bold {BRAND_ORANGE}]"]
    parts.append(f"[{MUTED}]v{version}[/{MUTED}]")
    if subtitle:
        parts.append(f"[{MUTED}]· {subtitle}[/{MUTED}]")
    return " ".join(parts)
