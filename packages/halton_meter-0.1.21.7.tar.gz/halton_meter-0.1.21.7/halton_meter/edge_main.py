"""
Entry point for ``halton-meter edge``.

The edge proxy runs as a separate launchd-supervised process (its own
plist lands in W3). This module is the bridge between the CLI/plist
ProgramArguments and the asyncio event loop that runs
:class:`halton_meter.edge.EdgeProxy`.

W1 deliberately leaves edge_host/edge_port/internal_host/internal_port
as constructable defaults. W2 wires them from the merged effective
config (defaults < runtime.toml < config.toml) once the
``edge_port`` / ``internal_port`` config keys land.
"""

from __future__ import annotations

import asyncio
import signal
import sys

import structlog

from halton_meter.edge import EdgeConfig, EdgeProxy

log = structlog.get_logger(__name__)


async def run_edge(config: EdgeConfig) -> int:
    """Run the edge proxy until cancelled. Returns process exit code.

    On SIGINT / SIGTERM the listener is closed and the function returns
    0. Any unexpected error returns 1.
    """
    proxy = EdgeProxy(config)
    try:
        bound_port = await proxy.start()
    except OSError as exc:
        # Bind failure (port already in use, no permission, etc.). Print
        # a clear message to stderr — launchd captures this in
        # StandardErrorPath.
        print(
            f"[halton-meter-edge] bind failed on "
            f"{config.edge_host}:{config.edge_port}: {exc}",
            file=sys.stderr,
            flush=True,
        )
        return 1

    # v0.1.7 Gap 0: persist the chain target sidecar so doctor/status
    # can detect a stale-chain INCONSISTENT state (the failure mode
    # documented in 2026-05-01-edge-passthrough-lockin-bug.md).
    proxy.write_initial_state(bound_edge_port=bound_port)

    # v0.1.19.dev1 (Phase 2 Bug B): merge the edge's kernel-confirmed
    # bound edge_port into the shared effective-ports.json so readers
    # (`_apply-user-env`, status, doctor) publish the actually-listening
    # port — not the stale runtime.toml fallback the daemon may have
    # written before the edge re-bound.
    try:
        from halton_meter.port_alloc import merge_edge_port_into_effective_ports

        merge_edge_port_into_effective_ports(bound_port)
    except Exception as exc:  # pragma: no cover - defensive
        log.warning("edge.effective_ports_merge_failed", error=str(exc))

    print(
        f"[halton-meter-edge] listening on "
        f"{config.edge_host}:{bound_port} -> "
        f"{config.internal_host}:{config.internal_port}",
        file=sys.stderr,
        flush=True,
    )

    loop = asyncio.get_running_loop()
    stop_event = asyncio.Event()

    def _request_stop() -> None:
        stop_event.set()

    # Best-effort signal handler install. Some platforms (Windows) don't
    # support add_signal_handler; the launchd plist is macOS-only for
    # v0.1.6 so this is fine in practice.
    for sig in (signal.SIGINT, signal.SIGTERM):
        try:
            loop.add_signal_handler(sig, _request_stop)
        except (NotImplementedError, RuntimeError):
            pass

    serve_task = asyncio.create_task(proxy.serve_forever(), name="edge-serve")
    stop_task = asyncio.create_task(stop_event.wait(), name="edge-stop-wait")
    # v0.1.8 Gap 10: poll runtime.toml so the edge re-resolves the chain
    # target the moment the daemon rebinds, with zero failed CONNECTs.
    # Stdlib-only mtime polling — see EdgeProxy.watch_runtime_toml.
    watch_task = asyncio.create_task(
        proxy.watch_runtime_toml(), name="edge-runtime-watch"
    )

    try:
        done, _pending = await asyncio.wait(
            {serve_task, stop_task}, return_when=asyncio.FIRST_COMPLETED
        )
        if stop_task in done:
            log.info("edge.shutdown_signal_received")
        # If serve_task completed (cancelled or error), surface that.
        if serve_task in done and not serve_task.cancelled():
            try:
                serve_task.result()
            except asyncio.CancelledError:
                pass
            except Exception as exc:  # pragma: no cover - defensive
                log.error("edge.serve_failed", error=str(exc), exc_info=True)
                return 1
    finally:
        await proxy.stop()
        for task in (serve_task, watch_task):
            if not task.done():
                task.cancel()
                try:
                    await task
                except (asyncio.CancelledError, Exception):
                    pass
        # v0.1.7 Gap 0: clean up the sidecar so a leftover file with a
        # dead PID doesn't fool the doctor on next status. Best-effort.
        try:
            from halton_meter.port_alloc import remove_edge_state_toml

            if config.state_path is not None:
                remove_edge_state_toml(config.state_path)
        except Exception:  # pragma: no cover - defensive
            pass
    return 0


def main() -> int:
    """Synchronous entry point used by the CLI subcommand and the plist.

    Resolves the edge config from the merged effective config
    (defaults < runtime.toml < config.toml). Falls back to literal
    defaults if the config layer raises (paranoid: a broken config.toml
    must never prevent the edge from binding its port — the cardinal
    rule applies to the edge as much as to the daemon).
    """
    try:
        from halton_meter.port_alloc import load_effective_config

        cfg = load_effective_config()
        config = EdgeConfig.from_halton_config(cfg)
    except Exception as exc:  # pragma: no cover - defensive
        print(
            f"[halton-meter-edge] config load failed ({exc}); "
            "falling back to defaults",
            file=sys.stderr,
            flush=True,
        )
        config = EdgeConfig()
    try:
        return asyncio.run(run_edge(config))
    except KeyboardInterrupt:
        return 0
