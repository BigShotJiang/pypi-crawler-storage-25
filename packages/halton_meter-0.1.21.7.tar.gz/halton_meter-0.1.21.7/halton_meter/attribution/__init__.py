"""Shared attribution layer logic.

The per-layer pure functions used by both the daemon-side
``halton_meter.tagging`` resolver and the edge-side
``halton_meter.edge_attribution`` resolver live in
:mod:`halton_meter.attribution.layers`. Both call sites delegate here
so attribution semantics stay in lock-step across the two resolution
paths.

Smart Attribution v0.3 PR1 — pure refactor (2026-05-02). No behaviour
change. Future PRs (e.g. PR2: layers 4 + 6 + 6.5) extend this module.
"""

from __future__ import annotations
