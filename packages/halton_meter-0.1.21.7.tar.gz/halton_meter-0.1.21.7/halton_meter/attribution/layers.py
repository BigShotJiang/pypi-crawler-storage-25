"""Per-layer attribution helpers — pure functions shared by both resolvers.

This module is the canonical home for the per-layer logic that
``halton_meter.tagging.resolve_project`` (daemon-side, bypass path)
and ``halton_meter.edge_attribution._resolve_via_psutil`` (edge-side,
production hot path) both apply.

Every function here is **pure**:

* Inputs are passed explicitly (cwd, env mapping, cmdline list).
* No imports of psutil, mitmproxy, sqlite, or any I/O-coupled module.
* Filesystem reads are limited to the path arguments the caller hands
  in (``.haltonrc`` walk, IDE workspace path validation).
* Never raises — every layer either returns a value or ``None``.

Layers covered today (PR1 — extracted from the existing implementations):

* Layer 1 — :func:`resolve_via_env` (``HALTON_PROJECT`` env var).
* Layer 2 — :func:`resolve_via_haltonrc` (``.haltonrc`` walked upward
  from a starting directory; returns the project field plus the
  ``body_capture`` flag — the body_capture parsing already lived in
  ``edge_attribution._read_haltonrc`` and stays the canonical form
  here so both resolvers agree).
* Layer 3 helpers — :func:`extract_workspace_path_from_cmdline` and the
  decode helpers it composes (:func:`decode_windsurf_workspace_id`,
  :func:`decode_file_uri`, :func:`decode_workspace_value`). Note:
  ``edge_attribution`` still owns the actual cmdline sniff because it
  needs to call ``proc.cmdline()`` first; only the pure decode logic
  is shared here. The post-sniff "re-run layer 2 against workspace
  path" step is also implemented via the shared
  :func:`resolve_via_haltonrc` — there is no separate function.
* Layer 7 — :func:`resolve_via_workdir_basename` (cwd basename
  fallback, with the leading-dot strip rule from v0.1.8 Gap 6).
* Slug normaliser — :func:`normalise_project_slug` (the v0.1.8 Gap 6
  rule: strip leading dots, fall through to ``"unattributed"`` if
  empty). The v0.3 plan calls for a richer normaliser; PR1 keeps the
  existing behaviour bit-for-bit and PR2 will extend it.

PR2 (2026-05-02) added:

* Layer 4 — :func:`resolve_via_git` (walk upward looking for a
  ``.git`` entry; emit the parent directory's basename only —
  Option A locked, never concatenates branch info). Per-cwd memo
  in :data:`_GIT_CACHE` for the lifetime of the process.
* Layer 6 — :func:`resolve_via_container` (Linux/Kubernetes
  container detection, gated on real container signals; the
  dev-laptop regression case must return ``None``).
* Layer 6.5 — :func:`resolve_via_mac_sandbox` (matched-process cwd
  under ``~/Library/Containers/<bundle-id>/Data`` →
  ``mac:<bundle-id>``; addresses the "every sandboxed Mac AI app
  collapses to ``Data``" diagnostic from Brief D, 2026-05-02).
* :func:`normalise_project_slug` extended to the v0.3 rules
  (lower-case, replace ``[^a-z0-9:_/-]`` with ``-``, collapse
  repeats, strip leading/trailing ``-``, truncate to 64 chars,
  fall back to ``"unattributed"`` if empty).

Layers explicitly NOT in this module:

* Layer 0 — edge attribution store cache lookup
  (``halton_meter.attribution_store``).
* Layer 5 — monorepo workspace detection. PARKED indefinitely
  per Vikrant 2026-05-02. Do not implement until explicitly unparked.
* Layer 8 — terminal ``"unattributed"`` (a sentinel; see
  :data:`UNATTRIBUTED`).
"""

from __future__ import annotations

import os
import re
from collections.abc import Callable, Mapping
from pathlib import Path

import structlog

log = structlog.get_logger(__name__)

# ---------------------------------------------------------------------------
# Constants — duplicated from the original modules so this file can stand on
# its own. The originals (``tagging._RCFILE_NAME`` etc.) remain for back-
# compat but now reference these.
# ---------------------------------------------------------------------------

RCFILE_NAME = ".haltonrc"
ENV_VAR = "HALTON_PROJECT"
UNATTRIBUTED = "unattributed"

# IDE-args sniff (Layer 3 helpers). GUI-launched IDEs (Windsurf, Cursor,
# VS Code, JetBrains-with-LSP) spawn helpers whose cwd is the app bundle,
# not the user's project — the workspace path lives in argv. Three
# argument shapes covered:
#
# 1. Windsurf:  ``--workspace_id file_<encoded_path>`` — see
#    :func:`decode_windsurf_workspace_id` for the encoding.
# 2. VS Code / Cursor: ``--folder-uri file://<absolute_path>`` and
#    ``--folder <path>``. URL-encoded paths are decoded.
# 3. Generic ``--workspace <path>`` / ``--project <path>``.
WORKSPACE_FLAGS = (
    "--workspace_id",
    "--folder-uri",
    "--folder",
    "--workspace",
    "--project",
)


# ---------------------------------------------------------------------------
# Slug normaliser (v0.1.8 Gap 6 rule — PR1 keeps existing behaviour)
# ---------------------------------------------------------------------------


# Allowed character class. The plan's "Output-format rules" listed
# ``[a-z0-9:_/-]`` but Brief D's Layer 6.5 emits ``mac:ai.perplexity.mac``
# (and reverse-DNS bundle ids in general) which require ``.`` to survive.
# Dots are always safe in URL paths under percent-encoding-free routing
# (FastAPI / Starlette handle them transparently) so the practical risk
# of permitting them is nil. Leading-dot collapse is still enforced via
# the explicit dot-strip step below — a basename of ``.halton-meter``
# still becomes ``halton-meter``.
_SLUG_ALLOWED_RE = re.compile(r"[^a-z0-9:._/-]")
_SLUG_DASH_COLLAPSE_RE = re.compile(r"-{2,}")
_SLUG_MAX_LEN = 64


def normalise_project_slug(name: str) -> str:
    """Canonical slug normaliser (v0.3 rules).

    Steps, applied in order:

    1. Lower-case the input.
    2. Strip leading dots — the v0.1.8 Gap 6 rule, kept explicit so
       a cwd basename of ``.halton-meter`` does not become
       ``-halton-meter`` (which would then strip back to
       ``halton-meter`` anyway, but the explicit dot-strip preserves
       the existing log shape and makes the rule grep-able).
    3. Replace any character outside ``[a-z0-9:_/-]`` with ``-``.
    4. Collapse runs of two-or-more ``-`` to a single ``-``.
    5. Strip leading and trailing ``-``.
    6. Truncate to 64 characters (and re-strip trailing ``-`` in case
       the truncation cut mid-run; vanishingly rare but cheap).
    7. If the result is empty, return :data:`UNATTRIBUTED`.

    The ``:`` and ``/`` characters survive intact because they are
    reserved for layer-specific suffixes — ``mac:<bundle>``,
    ``k8s:<pod>``, future ``<repo>:<branch>`` if Option A ever flips.

    Examples:

    * ``".halton-meter"`` → ``"halton-meter"``
    * ``"my project name"`` → ``"my-project-name"``
    * ``"Foo Bar/baz"`` → ``"foo-bar/baz"``
    * ``"k8s:checkout-pod-abc"`` → ``"k8s:checkout-pod-abc"``
    * ``""`` / ``"   "`` / ``"..."`` → ``"unattributed"``
    """
    if not name:
        return UNATTRIBUTED
    s = name.strip().lower()
    while s.startswith("."):
        s = s[1:]
    s = _SLUG_ALLOWED_RE.sub("-", s)
    s = _SLUG_DASH_COLLAPSE_RE.sub("-", s)
    s = s.strip("-")
    if len(s) > _SLUG_MAX_LEN:
        s = s[:_SLUG_MAX_LEN].rstrip("-")
    if not s:
        return UNATTRIBUTED
    return s


# ---------------------------------------------------------------------------
# Layer 1 — HALTON_PROJECT env var
# ---------------------------------------------------------------------------


def resolve_via_env(env: Mapping[str, str]) -> str | None:
    """Return the sanitised ``HALTON_PROJECT`` value from ``env`` or ``None``.

    ``env`` is the originating process's environ on the edge path, or
    ``os.environ`` on the daemon's bypass path. Empty / whitespace-only
    values fall through (treated as unset).
    """
    raw = env.get(ENV_VAR, "").strip()
    if not raw:
        return None
    return normalise_project_slug(raw)


# ---------------------------------------------------------------------------
# Layer 2 — .haltonrc walked upward
# ---------------------------------------------------------------------------


def _parse_body_capture_value(raw: str) -> bool | None:
    """Decode a ``body_capture`` rcfile value.

    Accepts the boolean spellings used in our docs and CLI help:
    ``off/on``, ``false/true``, ``no/yes``, ``0/1``, ``disabled/enabled``.
    Returns ``None`` for anything we don't recognise — caller falls
    back to the master-on default. Case-insensitive.
    """
    v = raw.strip().lower()
    if v in ("off", "false", "no", "0", "disabled"):
        return False
    if v in ("on", "true", "yes", "1", "enabled"):
        return True
    return None


def resolve_via_haltonrc(start_dir: str) -> tuple[str | None, bool | None]:
    """Walk upward from ``start_dir`` looking for a ``.haltonrc``.

    Returns ``(project, body_capture_enabled)``. Either field is
    ``None`` when the corresponding line is missing from the resolved
    rcfile (or when no rcfile exists upward from ``start_dir``). The
    first rcfile found wins for both fields — we do NOT keep walking
    past a hit looking for a separate ``body_capture`` line, so a
    user who puts both in the same file is the supported pattern.

    Simple ``key: <value>`` line scan, no YAML dependency. The
    ``body_capture`` field also accepts the ``key = value`` shape
    used in user-facing examples.

    The daemon-side resolver only consumes the project field; it
    projects the tuple via :func:`resolve_via_haltonrc_project_only`.
    """
    try:
        current = Path(start_dir).resolve()
    except OSError:
        return (None, None)
    while True:
        rc_file = current / RCFILE_NAME
        if rc_file.is_file():
            project: str | None = None
            body_capture: bool | None = None
            try:
                content = rc_file.read_text(encoding="utf-8")
                for line in content.splitlines():
                    stripped = line.strip()
                    if stripped.startswith("project:"):
                        value = stripped[len("project:"):].strip()
                        if value and project is None:
                            project = value
                    elif stripped.startswith("body_capture:"):
                        value = stripped[len("body_capture:"):].strip()
                        parsed = _parse_body_capture_value(value)
                        if parsed is not None and body_capture is None:
                            body_capture = parsed
                    elif stripped.startswith("body_capture"):
                        # ``body_capture = off`` form (whitespace-tolerant).
                        rest = stripped[len("body_capture"):].lstrip()
                        if rest.startswith("="):
                            value = rest[1:].strip()
                            parsed = _parse_body_capture_value(value)
                            if parsed is not None and body_capture is None:
                                body_capture = parsed
            except OSError as exc:
                log.debug(
                    "attribution.rcfile_read_error",
                    path=str(rc_file),
                    error=str(exc),
                )
            if project is not None:
                log.debug(
                    "attribution.rcfile_found",
                    path=str(rc_file),
                    project=project,
                )
            return (project, body_capture)
        parent = current.parent
        if parent == current:
            return (None, None)
        current = parent


def resolve_via_haltonrc_project_only(start_dir: str) -> str | None:
    """Project-field-only projection of :func:`resolve_via_haltonrc`.

    Used by the daemon-side bypass resolver, which has no use for the
    body_capture flag (body capture is gated at the edge).
    """
    project, _ = resolve_via_haltonrc(start_dir)
    return project


# ---------------------------------------------------------------------------
# Layer 3 — IDE workspace sniff (decode helpers only; the cmdline lookup
# itself stays in edge_attribution.py because it needs psutil to read
# proc.cmdline()).
# ---------------------------------------------------------------------------


def decode_windsurf_workspace_id(value: str) -> str | None:
    """Decode a Windsurf ``--workspace_id`` value to an absolute path.

    Format observed in production:
    ``file_Users_stack_Documents_haltonlabs_meter`` decodes to
    ``/Users/stack/Documents/haltonlabs-meter``. Underscores stand in
    for both path separators (``/``) AND dashes inside a single
    segment (``halton-meter`` → ``halton_meter``), which makes the
    split ambiguous from the string alone. We resolve the ambiguity
    by backtracking against the real filesystem: at each level we
    pick the directory that exists, joining tokens with ``-`` when
    needed to match.

    Returns ``None`` when the prefix is missing, the path can't be
    grounded under any existing directory, or the decode fails for
    any reason. Never raises — attribution must not block accept.
    """
    if not value.startswith("file_"):
        return None
    tail = value[len("file_") :]
    if not tail:
        return None
    tokens = tail.split("_")
    if not tokens:
        return None

    def _norm(name: str) -> str:
        """Squash ``-`` and ``_`` so encoded vs real dir names compare equal."""
        return name.replace("-", "_")

    def _walk(prefix: Path, remaining: list[str]) -> Path | None:
        if not remaining:
            return prefix if prefix.is_dir() else None
        # List children of ``prefix`` once and find directories whose
        # normalised name equals the underscore-joined first N tokens
        # for some N. Greedy LONGEST match wins ('halton-meter-cloud'
        # over 'halton'). Listing the directory beats brute-forcing
        # 2^(N-1) separator combinations and tolerates dir names that
        # mix ``_`` and ``-`` arbitrarily — both encode to ``_`` in
        # Windsurf's scheme so we cannot recover the original spelling
        # from the token string alone.
        try:
            children = {_norm(p.name): p for p in prefix.iterdir() if p.is_dir()}
        except (OSError, PermissionError):
            return None
        for n in range(len(remaining), 0, -1):
            key = "_".join(remaining[:n])
            child = children.get(key)
            if child is not None:
                result = _walk(child, remaining[n:])
                if result is not None:
                    return result
        return None

    try:
        result = _walk(Path("/"), tokens)
    except OSError:
        return None
    return str(result) if result is not None else None


def decode_file_uri(value: str) -> str | None:
    """Decode a ``file://`` URI to a local path."""
    if not value.startswith("file://"):
        return None
    from urllib.parse import unquote, urlparse

    try:
        parsed = urlparse(value)
        path = unquote(parsed.path)
    except (ValueError, UnicodeDecodeError):
        return None
    return path or None


def decode_workspace_value(flag: str, value: str) -> str | None:
    """Apply the decoding strategy appropriate to ``flag``.

    * ``--workspace_id`` → fuzzy filesystem decode (Windsurf-shaped).
    * ``file://`` prefix → URL-decode the path; accepted only if the
      decoded path exists on disk.
    * Plain path forms → accepted only if the path exists on disk
      (filters out arg values that aren't paths).
    """
    if flag == "--workspace_id":
        return decode_windsurf_workspace_id(value)
    if value.startswith("file://"):
        decoded = decode_file_uri(value)
        if decoded and Path(decoded).is_dir():
            return decoded
        return None
    try:
        if value and Path(value).is_dir():
            return value
    except OSError:
        return None
    return None


def extract_workspace_path_from_cmdline(cmdline: list[str]) -> str | None:
    """Walk an IDE helper process's argv looking for a workspace path.

    Recognises the flags listed in :data:`WORKSPACE_FLAGS`, in both
    space-separated (``--flag value``) and ``=`` joined
    (``--flag=value``) forms. Returns the first decode-able match,
    or ``None``.
    """
    if not cmdline:
        return None
    i = 0
    while i < len(cmdline):
        token = cmdline[i]
        flag, _, inline_value = token.partition("=")
        if flag in WORKSPACE_FLAGS:
            if inline_value:
                value = inline_value
            elif i + 1 < len(cmdline):
                value = cmdline[i + 1]
                i += 1
            else:
                i += 1
                continue
            decoded = decode_workspace_value(flag, value)
            if decoded:
                return decoded
        i += 1
    return None


# ---------------------------------------------------------------------------
# Layer 4 — Git repo basename (Option A LOCKED, never concatenates branch)
# ---------------------------------------------------------------------------


# Per-cwd memo. No TTL — the v0.3 plan's "edge restart clears" semantics
# are sufficient because the cache key is the originating process's cwd
# and processes very rarely chdir between accept events. If eviction ever
# becomes a concern (long-lived edge + very wide cwd churn), revisit.
_GIT_CACHE: dict[str, str | None] = {}


def clear_git_cache() -> None:
    """Drop every entry in the per-cwd git memo.

    Test-only helper. Production code should not need this — the cache is
    keyed on cwd, processes rarely chdir between accept events, and edge
    restart clears it implicitly. Tests that mutate the filesystem to
    create/destroy ``.git`` markers under the same path must call this in
    teardown to avoid leaking memoised ``None``/repo-name across cases.
    """
    _GIT_CACHE.clear()


def _walk_for_git_root(start_dir: str) -> Path | None:
    """Walk upward from ``start_dir`` looking for a ``.git`` entry.

    Returns the directory CONTAINING the ``.git`` (file or dir), not
    the ``.git`` itself — that directory's basename IS the repo name
    under Option A. Returns ``None`` when no ``.git`` is found before
    hitting the filesystem root.

    Pure walk (no subprocess). The v0.3 plan's perf budget assumed
    ``git rev-parse --show-toplevel``; the walk is faster (no fork,
    no PATH lookup) and well within budget.
    """
    try:
        current = Path(start_dir).resolve()
    except OSError:
        return None
    while True:
        # ``.git`` is a directory in normal repos and a file in
        # worktrees (``gitdir: ...`` pointer). Both shapes count.
        try:
            if (current / ".git").exists():
                return current
        except OSError:
            return None
        parent = current.parent
        if parent == current:
            return None
        current = parent


def resolve_via_git(cwd: str) -> str | None:
    """Walk upward from ``cwd`` for a git repo; return the repo basename.

    Option A LOCKED 2026-05-02 — branch info is intentionally
    dropped. The output is the basename of the directory containing
    ``.git``. ``None`` when ``cwd`` is outside any git repo.

    Memoised per-cwd in :data:`_GIT_CACHE` — repeated resolutions
    against the same cwd avoid the filesystem walk on every accept.
    """
    if not cwd:
        return None
    if cwd in _GIT_CACHE:
        return _GIT_CACHE[cwd]
    root = _walk_for_git_root(cwd)
    if root is None:
        _GIT_CACHE[cwd] = None
        return None
    basename = root.name
    if not basename:
        _GIT_CACHE[cwd] = None
        return None
    slug = normalise_project_slug(basename)
    if slug == UNATTRIBUTED:
        _GIT_CACHE[cwd] = None
        return None
    _GIT_CACHE[cwd] = slug
    return slug


# ---------------------------------------------------------------------------
# Layer 6 — Linux/Kubernetes container detection (gated correctly)
# ---------------------------------------------------------------------------


def _default_container_fs_probe(path: str) -> bool:
    """Return whether ``path`` exists. Default probe for the live system.

    Tests inject a fake to drive the gate without writing real
    ``/.dockerenv`` / ``/proc/1/cgroup`` files.
    """
    try:
        return os.path.exists(path)
    except OSError:
        return False


def _read_proc1_cgroup(fs_probe: Callable[[str], bool]) -> str:
    """Read ``/proc/1/cgroup`` if the probe says it exists. Return ``""`` else.

    Errors swallow to ``""`` — attribution must never raise.
    """
    if not fs_probe("/proc/1/cgroup"):
        return ""
    try:
        with open("/proc/1/cgroup", encoding="utf-8") as f:
            return f.read()
    except OSError:
        return ""


def resolve_via_container(
    env: Mapping[str, str],
    fs_probe: Callable[[str], bool] | None = None,
) -> str | None:
    """Linux/Kubernetes container detection.

    Fires only when at least one of these is true:

    * ``/.dockerenv`` exists (canonical Docker marker).
    * ``KUBERNETES_SERVICE_HOST`` is set in ``env``.
    * ``/proc/1/cgroup`` exists AND contains ``docker`` /
      ``kubepods`` / ``containerd``.

    When gated-in, returns ``k8s:<HOSTNAME>`` if
    ``KUBERNETES_SERVICE_HOST`` is set, else ``docker:<HOSTNAME>``.
    Returns ``None`` when ``HOSTNAME`` is empty in either case (don't
    emit ``k8s:`` with an empty suffix).

    The dev-laptop regression case — none of the gates fire — MUST
    return ``None``. Without that path the v0.3 draft's bug recurs
    (every developer laptop tagged ``k8s:<machinename>``).

    ``env`` is the matched process's environ at the edge, or
    ``os.environ`` on the daemon's bypass path. ``fs_probe`` is for
    testability; production code passes ``None`` and we use the real
    filesystem.
    """
    probe = fs_probe if fs_probe is not None else _default_container_fs_probe
    has_dockerenv = probe("/.dockerenv")
    k8s_host = env.get("KUBERNETES_SERVICE_HOST", "").strip()
    cgroup_text = _read_proc1_cgroup(probe)
    has_container_cgroup = any(
        marker in cgroup_text for marker in ("docker", "kubepods", "containerd")
    )

    if not (has_dockerenv or k8s_host or has_container_cgroup):
        return None

    hostname = env.get("HOSTNAME", "").strip()
    if not hostname:
        return None

    prefix = "k8s" if k8s_host else "docker"
    return normalise_project_slug(f"{prefix}:{hostname}")


# ---------------------------------------------------------------------------
# Layer 6.5 — macOS sandbox container bundle id (Brief D, 2026-05-02)
# ---------------------------------------------------------------------------


_MAC_CONTAINERS_RE = re.compile(
    r"^/Users/[^/]+/Library/Containers/(?P<bundle>[A-Za-z0-9][A-Za-z0-9._-]*)/Data(?:/|$)"
)


def resolve_via_mac_sandbox(cwd: str) -> str | None:
    """Detect a sandboxed macOS app's cwd and return ``mac:<bundle-id>``.

    Sandboxed Mac apps (Perplexity desktop, ChatGPT desktop, Microsoft
    Teams agent, every system XPC service) chdir into
    ``~/Library/Containers/<bundle-id>/Data`` (or a deeper subpath).
    Layer 7's basename fallback collapses every one of them into a
    single fake project named ``Data``; this layer recovers the
    bundle id instead.

    Returns ``None`` when:

    * ``cwd`` is outside ``/Users/<user>/Library/Containers/.../Data``
      (path-shape gate).
    * The captured bundle id contains no ``.`` (bundle ids are
      reverse-DNS by convention; the dot is the cheap sanity check
      against fixtures or test paths that happen to live under the
      Containers tree).

    The ``mac:`` prefix mirrors the ``k8s:`` / ``docker:`` shape from
    Layer 6 and prevents collision with a user project that happens to
    be named ``ai.perplexity.mac``.
    """
    if not cwd:
        return None
    m = _MAC_CONTAINERS_RE.match(cwd)
    if not m:
        return None
    bundle = m.group("bundle")
    # Reverse-DNS bundle ids always contain at least one dot. Reject
    # anything else as a defensive guard against test fixtures or
    # weird paths that happen to live under Library/Containers/.
    if "." not in bundle:
        return None
    return normalise_project_slug(f"mac:{bundle}")


# ---------------------------------------------------------------------------
# Layer 7 — workdir basename
# ---------------------------------------------------------------------------


def resolve_via_workdir_basename(cwd: str) -> str | None:
    """Return the sanitised basename of ``cwd``, or ``None`` if empty.

    The v0.1.8 Gap 6 leading-dot rule applies via
    :func:`normalise_project_slug`. A cwd like ``"/"`` (basename = ``""``)
    returns ``None`` so the caller can fall through to
    :data:`UNATTRIBUTED`.
    """
    basename = Path(cwd).name
    if not basename:
        return None
    return normalise_project_slug(basename)
