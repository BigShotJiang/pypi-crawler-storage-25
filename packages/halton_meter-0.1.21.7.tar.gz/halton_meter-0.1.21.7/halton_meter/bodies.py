"""CLI helpers for the ``halton-meter bodies`` subcommands.

Three operations:

  * **show <id>** — prints the captured request/response bodies, content
    types, capture flags, and redaction summary for a single request.
  * **stats** — high-level counts: how many body rows, oldest/newest,
    total captured bytes, truncation count, redaction breakdown.
  * **purge --older-than Nd [--vacuum] [--dry-run]** — TTL-driven cleanup
    of captured bodies. Counts rows are untouched.

These talk to SQLite directly via ``sqlite3`` rather than going through the
async SQLAlchemy stack — we want the CLI to work even when the daemon is
running, and synchronous reads are simpler / safer here. WAL mode is
already on, so the daemon's writers don't block our reads.

PR1 ships these as inert plumbing: the table is created (migration in
``storage/repo.py``) but nothing writes to it until PR2 wires the proxy
hot path. The CLI handles the empty-table case gracefully so the operator
can sanity-check the install before bodies start landing.
"""

from __future__ import annotations

import json
import re
import sqlite3
from collections import Counter
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from pathlib import Path

DEFAULT_DB_PATH = Path("~/.halton-meter/db.sqlite").expanduser()


# --------------------------------------------------------------------------- #
# Time-string parsing for --older-than                                        #
# --------------------------------------------------------------------------- #


_DURATION_RE = re.compile(r"^\s*(\d+)\s*([dhm])\s*$", re.IGNORECASE)


def parse_duration(spec: str) -> timedelta:
    """Parse e.g. ``'30d'`` / ``'12h'`` / ``'45m'`` → ``timedelta``.

    Supports days (``d``), hours (``h``), minutes (``m``). Plain integers
    are interpreted as days for ergonomic CLI use (``--older-than 7`` ==
    ``--older-than 7d``).
    """
    spec = spec.strip()
    if not spec:
        msg = "duration required (e.g. 30d, 12h, 45m)"
        raise ValueError(msg)
    if spec.isdigit():
        return timedelta(days=int(spec))
    m = _DURATION_RE.match(spec)
    if m is None:
        msg = f"invalid duration {spec!r}; expected like 30d, 12h, 45m"
        raise ValueError(msg)
    n = int(m.group(1))
    unit = m.group(2).lower()
    if unit == "d":
        return timedelta(days=n)
    if unit == "h":
        return timedelta(hours=n)
    return timedelta(minutes=n)


# --------------------------------------------------------------------------- #
# Inspection: `bodies show <id>`                                              #
# --------------------------------------------------------------------------- #


@dataclass(frozen=True)
class BodyRow:
    request_id: str
    request_body: str | None
    response_body: str | None
    request_body_bytes: int
    response_body_bytes: int
    request_content_type: str | None
    response_content_type: str | None
    request_truncated: bool
    response_truncated: bool
    streaming_incomplete: bool
    redaction_applied: bool
    capture_error: str | None
    redaction_summary: str | None
    captured_at: str


def _connect(db_path: Path) -> sqlite3.Connection:
    conn = sqlite3.connect(str(db_path))
    conn.row_factory = sqlite3.Row
    # Foreign keys aren't strictly needed for reads, but turn them on so
    # the connection has consistent behaviour with the daemon's writers.
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def fetch_body(db_path: Path, request_id: str) -> BodyRow | None:
    """Return the body row for ``request_id``, or None when absent.

    Absent is the normal case for any request captured before the
    body-capture feature shipped, or for projects that have body capture
    opted out. Callers display "no body captured for request <id>".
    """
    if not db_path.exists():
        return None
    with _connect(db_path) as conn:
        cur = conn.execute(
            "SELECT request_id, request_body, response_body, "
            "request_body_bytes, response_body_bytes, "
            "request_content_type, response_content_type, "
            "request_truncated, response_truncated, "
            "streaming_incomplete, redaction_applied, "
            "capture_error, redaction_summary, captured_at "
            "FROM request_bodies WHERE request_id = ?",
            (request_id,),
        )
        row = cur.fetchone()
        if row is None:
            return None
        return BodyRow(
            request_id=row["request_id"],
            request_body=row["request_body"],
            response_body=row["response_body"],
            request_body_bytes=int(row["request_body_bytes"] or 0),
            response_body_bytes=int(row["response_body_bytes"] or 0),
            request_content_type=row["request_content_type"],
            response_content_type=row["response_content_type"],
            request_truncated=bool(row["request_truncated"]),
            response_truncated=bool(row["response_truncated"]),
            streaming_incomplete=bool(row["streaming_incomplete"]),
            redaction_applied=bool(row["redaction_applied"]),
            capture_error=row["capture_error"],
            redaction_summary=row["redaction_summary"],
            captured_at=str(row["captured_at"] or ""),
        )


# --------------------------------------------------------------------------- #
# Stats: `bodies stats`                                                       #
# --------------------------------------------------------------------------- #


@dataclass(frozen=True)
class ProjectBodyStats:
    """Per-project rollup of captured-body storage. Used by ``bodies stats``."""

    project_slug: str
    row_count: int
    total_captured_bytes: int
    redaction_applied_count: int


@dataclass(frozen=True)
class BodyStats:
    row_count: int
    total_captured_bytes: int  # sum of request_body_bytes + response_body_bytes
    oldest_captured_at: str | None
    newest_captured_at: str | None
    truncated_request_count: int
    truncated_response_count: int
    capture_error_count: int
    redaction_summary_totals: dict[str, int]
    redaction_applied_count: int = 0
    per_project: tuple[ProjectBodyStats, ...] = ()

    @property
    def redaction_applied_pct(self) -> float:
        """Percent of body rows that had at least one redaction applied.

        0.0 when no rows. Computed at display time so the dataclass stays
        a pure value object.
        """
        if self.row_count == 0:
            return 0.0
        return 100.0 * self.redaction_applied_count / self.row_count


def fetch_stats(db_path: Path) -> BodyStats:
    """Aggregate body-row stats for the operator demo / `bodies stats` CLI."""
    empty = BodyStats(
        row_count=0,
        total_captured_bytes=0,
        oldest_captured_at=None,
        newest_captured_at=None,
        truncated_request_count=0,
        truncated_response_count=0,
        capture_error_count=0,
        redaction_summary_totals={},
        redaction_applied_count=0,
        per_project=(),
    )
    if not db_path.exists():
        return empty
    with _connect(db_path) as conn:
        # Existence guard for greenfield DBs that haven't migrated yet.
        try:
            cur = conn.execute(
                "SELECT COUNT(*) AS n, "
                "       COALESCE(SUM(request_body_bytes), 0) AS rb, "
                "       COALESCE(SUM(response_body_bytes), 0) AS sb, "
                "       MIN(captured_at) AS oldest, "
                "       MAX(captured_at) AS newest, "
                "       SUM(CASE WHEN request_truncated THEN 1 ELSE 0 END) AS rt, "
                "       SUM(CASE WHEN response_truncated THEN 1 ELSE 0 END) AS st, "
                "       SUM(CASE WHEN capture_error IS NOT NULL THEN 1 ELSE 0 END) AS ce, "
                "       SUM(CASE WHEN redaction_applied THEN 1 ELSE 0 END) AS ra "
                "FROM request_bodies"
            )
        except sqlite3.OperationalError:
            return empty
        row = cur.fetchone()
        n = int(row["n"] or 0)
        if n == 0:
            return empty

        # Per-project breakdown joins request_bodies → requests → projects.
        # Defensive try/except: a sufficiently-old DB might not have the
        # joined tables, in which case we surface zero-project stats and
        # leave the rest of the rollup populated.
        per_project: list[ProjectBodyStats] = []
        try:
            pp_cur = conn.execute(
                "SELECT p.slug AS slug, "
                "       COUNT(*) AS n, "
                "       COALESCE(SUM(rb.request_body_bytes), 0) "
                "         + COALESCE(SUM(rb.response_body_bytes), 0) AS bytes, "
                "       SUM(CASE WHEN rb.redaction_applied THEN 1 ELSE 0 END) AS ra "
                "FROM request_bodies rb "
                "JOIN requests r ON r.id = rb.request_id "
                "JOIN projects p ON p.id = r.project_id "
                "GROUP BY p.slug "
                "ORDER BY n DESC, p.slug ASC"
            )
            for prow in pp_cur:
                per_project.append(
                    ProjectBodyStats(
                        project_slug=str(prow["slug"]),
                        row_count=int(prow["n"] or 0),
                        total_captured_bytes=int(prow["bytes"] or 0),
                        redaction_applied_count=int(prow["ra"] or 0),
                    )
                )
        except sqlite3.OperationalError:
            per_project = []

        # Aggregate redaction_summary across rows. Each row stores a JSON
        # map; we sum per-category counts.
        summary_totals: Counter[str] = Counter()
        cur = conn.execute(
            "SELECT redaction_summary FROM request_bodies "
            "WHERE redaction_summary IS NOT NULL"
        )
        for srow in cur:
            try:
                payload = json.loads(srow["redaction_summary"])
            except (json.JSONDecodeError, TypeError):
                continue
            if not isinstance(payload, dict):
                continue
            for category, count in payload.items():
                if isinstance(category, str) and isinstance(count, int):
                    summary_totals[category] += count

        return BodyStats(
            row_count=n,
            total_captured_bytes=int(row["rb"] or 0) + int(row["sb"] or 0),
            oldest_captured_at=str(row["oldest"]) if row["oldest"] else None,
            newest_captured_at=str(row["newest"]) if row["newest"] else None,
            truncated_request_count=int(row["rt"] or 0),
            truncated_response_count=int(row["st"] or 0),
            capture_error_count=int(row["ce"] or 0),
            redaction_summary_totals=dict(summary_totals),
            redaction_applied_count=int(row["ra"] or 0),
            per_project=tuple(per_project),
        )


# --------------------------------------------------------------------------- #
# Purge: `bodies purge --older-than Nd [--vacuum] [--dry-run]`                #
# --------------------------------------------------------------------------- #


@dataclass(frozen=True)
class PurgeResult:
    cutoff: datetime
    rows_deleted: int
    vacuumed: bool
    dry_run: bool


def purge_old_bodies(
    db_path: Path,
    older_than: timedelta,
    *,
    dry_run: bool = False,
    vacuum: bool = False,
    now: datetime | None = None,
) -> PurgeResult:
    """Delete body rows older than ``now - older_than``.

    The corresponding ``requests`` rows are left intact — counts/cost is the
    metering record, body retention is a separate concern.

    ``vacuum``: run ``VACUUM`` after the delete. Blocks the SQLite file
    while it runs, so this is opt-in. Document in CLI help.

    ``dry_run``: count the rows that would be deleted but don't delete.

    Idempotent — running twice with the same cutoff deletes zero rows on
    the second pass.
    """
    cutoff = (now or datetime.now(tz=UTC)) - older_than
    cutoff_iso = cutoff.replace(tzinfo=UTC).astimezone(UTC).isoformat()

    if not db_path.exists():
        return PurgeResult(
            cutoff=cutoff, rows_deleted=0, vacuumed=False, dry_run=dry_run,
        )

    with _connect(db_path) as conn:
        try:
            count_row = conn.execute(
                "SELECT COUNT(*) FROM request_bodies WHERE captured_at < ?",
                (cutoff_iso,),
            ).fetchone()
        except sqlite3.OperationalError:
            return PurgeResult(
                cutoff=cutoff, rows_deleted=0, vacuumed=False, dry_run=dry_run,
            )
        n = int(count_row[0] or 0)

        if dry_run or n == 0:
            return PurgeResult(
                cutoff=cutoff, rows_deleted=n, vacuumed=False, dry_run=dry_run,
            )

        conn.execute(
            "DELETE FROM request_bodies WHERE captured_at < ?",
            (cutoff_iso,),
        )
        conn.commit()
        vacuumed = False
        if vacuum:
            # VACUUM cannot run inside a transaction; commit just happened.
            conn.execute("VACUUM")
            vacuumed = True

    return PurgeResult(
        cutoff=cutoff, rows_deleted=n, vacuumed=vacuumed, dry_run=False,
    )
