"""First-run UX orchestrator: ``halton-meter init``.

Phase 2B.7. Closes the "I forgot to run setup after install" footgun
by chaining the existing :mod:`halton_meter.setup`,
:func:`halton_meter.system_proxy.enable_system_proxy_if_managed`, and
:func:`halton_meter.install.install` into a single command with proper
admin elevation and a Rich-rendered summary.

v0.1.3 mode pivot (P0-3): two install modes are supported.

* env-var-only (default — no flag): cert + certifi + plists. NO system-
  proxy enable, NO launchctl setenv, NO shell-rc append. Coverage is
  scoped to whatever the user explicitly routes via ``halton-meter run
  <command>``. Cannot break browsers / GUI apps because we never touch
  their proxy state.
* ``--gui``: env-var-only PLUS system-proxy enable PLUS launchctl
  setenv user-domain (so GUI apps spawned via Spotlight/Dock see the
  proxy + cert env vars) PLUS optional idempotent shell-rc append.
  Broader coverage; may break HSTS browser sites if the cert isn't
  trusted by SecTrust at TLS evaluation time (the P0-1 cert-trust
  invariant catches that and refuses to flip the system proxy on).

The single source of truth for which mode the user is on is
``~/.halton-meter/install-mode`` (file content: ``gui`` or ``env-only``).
``halton-meter uninstall`` reads it and only reverses what was set up.

Pure orchestrator — no new functionality lives here that isn't a thin
wrapper over the existing modules. Idempotent; each step independently
resumable. See ``memory/decisions.md`` 2026-04-29 entry "Phase 2B.7
first-run UX design" for the architectural decisions.
"""

from __future__ import annotations

import contextlib
import os
import subprocess
import sys
from pathlib import Path
from typing import Any

import structlog
from rich.console import Console
from rich.panel import Panel

log = structlog.get_logger()

# Exit codes
_EXIT_OK = 0
_EXIT_SETUP_FAILED = 1
_EXIT_PROXY_FAILED = 1
_EXIT_INSTALL_FAILED = 1
_EXIT_SUDO_NOT_PRECACHED = 2

_DAEMON_LABEL = "com.haltonlabs.meter"

# v0.1.20.dev2: Rich progress wrap for init's silent phases.
#
# When set to a truthy value, ``halton-meter init`` falls back to the
# v0.1.20.dev1 line-by-line printing path (``[halton-meter] plist
# unchanged: ...`` etc. visible on stderr; setup checklist printed via
# ``render_result``). The default behaviour for end users is the
# brand-language progress bar that hides the diagnostic chatter.
#
# Test seam: the existing ~89 init tests assert behaviour, not the
# intermediate diagnostic strings, so they pass with the progress wrap
# active. This env var exists for any future test (or debugging
# session) that needs the legacy printing back; it is intentionally
# not documented in user-facing docs.
_NO_PROGRESS_ENV = "_HALTON_INIT_NO_PROGRESS"


def _progress_disabled(*, non_interactive: bool, console: Console) -> bool:
    """Decide whether the init flow should skip the brand_progress wrap.

    Disable progress when:
      * the opt-out env var is set (test / debugging),
      * the run is non-interactive (CI / scripted installs — log-style
        stderr output is friendlier to log scrapers than a live spinner),
      * the console is not attached to a TTY (``Console.is_terminal`` is
        False — e.g. piped output, captured stdout in tests).
    """
    if os.environ.get(_NO_PROGRESS_ENV):
        return True
    if non_interactive:
        return True
    # Rich exposes ``is_terminal`` (False for record=True / file=StringIO
    # captures). Defensive getattr for unusual Console subclasses.
    if not getattr(console, "is_terminal", False):
        return True
    return False

# v0.1.3 P0-3 — install-mode sentinel.
# v0.1.5 (2B.16): three-mode model. ``apps`` is new (shell-rc +
# launchctl env, NO system proxy — covers terminals + apps spawned from
# them, but does NOT touch browser / GUI-app traffic). ``full`` is the
# new canonical name for what v0.1.3/v0.1.4 called ``gui`` (everything:
# system proxy + launchctl env + shell-rc). ``MODE_GUI`` is kept as a
# read-only legacy alias — the migration helper rewrites the sentinel
# from ``gui`` to ``full`` on next ``init``.
INSTALL_MODE_PATH = Path("~/.halton-meter/install-mode").expanduser()
MODE_ENV_ONLY = "env-only"
MODE_APPS = "apps"
MODE_FULL = "full"
MODE_GUI = "gui"  # legacy alias for ``full``; v0.1.3/v0.1.4 sentinel value.

# Canonical mode set (the only values ever WRITTEN to the sentinel).
_CANONICAL_MODES = (MODE_ENV_ONLY, MODE_APPS, MODE_FULL)
# Legacy mode set (read-tolerant; mapped onto a canonical mode).
_LEGACY_MODE_ALIASES = {MODE_GUI: MODE_FULL}

# v0.1.3 P0-3 — idempotent shell-rc append. Marker comments bracket the block
# we own; any block found between these markers is replaced when the user
# re-runs init, and removed when the user uninstalls.
SHELL_RC_BLOCK_BEGIN = "# >>> halton-meter env vars (managed) >>>"
SHELL_RC_BLOCK_END = "# <<< halton-meter env vars (managed) <<<"


def _detect_live_daemon() -> bool:
    """Return True if launchd reports a live ``com.haltonlabs.meter`` agent.

    Uses ``launchctl print gui/<uid>/<label>`` rather than
    ``launchctl list | grep`` — the print form returns a non-zero exit
    code when the label is unknown, which is more reliable than parsing
    list output. macOS-only; returns False on other platforms.
    """
    if sys.platform != "darwin":
        return False
    try:
        uid = os.getuid()
    except AttributeError:
        return False
    try:
        result = subprocess.run(
            ["launchctl", "print", f"gui/{uid}/{_DAEMON_LABEL}"],
            capture_output=True,
            timeout=5,
            check=False,
        )
    except (OSError, subprocess.SubprocessError):
        return False
    return result.returncode == 0


def _sudo_pre_cached() -> bool:
    """Return True if a non-interactive ``sudo -n true`` succeeds.

    Used in non-interactive mode to detect the keychain-trust footgun
    early: when osascript is unavailable, ``setup.run_setup`` falls
    back to ``sudo security ...`` which deadlocks on a sudo password
    prompt when there is no TTY.
    """
    try:
        result = subprocess.run(
            ["sudo", "-n", "true"],
            capture_output=True,
            timeout=5,
            check=False,
        )
    except (OSError, subprocess.SubprocessError):
        return False
    return result.returncode == 0


def _osascript_available_for_init() -> bool:
    """Return True iff ``osascript`` is on PATH (macOS-only check).

    v0.1.4 (2B.15) P0-2: the cert-trust step prefers the osascript GUI
    admin dialog. When osascript is present (the normal case on every
    macOS install), the init flow can elevate without pre-cached
    sudo — so the preflight should not bail on
    ``not _sudo_pre_cached()`` alone.

    Test seam: separate from setup._osascript_available so init's
    fixtures don't have to monkey-patch the setup module.
    """
    import shutil

    return shutil.which("osascript") is not None


def _render_panel_success(
    console: Console,
    *,
    setup_done: bool,
    install_done: bool,
    mode: str,
    proxy_done: bool = False,
    setenv_done: bool = False,
    shell_rc_status: str | None = None,
    proxy_skipped_running_daemon: bool = False,
    listen_port: int | None = None,
    api_port: int | None = None,
) -> None:
    """Render the post-init success panel.

    v0.1.4 (2B.15) extras:
      * P0-5: when ``listen_port`` / ``api_port`` differ from the
        marketed defaults, surface the auto-fallback inline so the
        user knows their tools must target the actual port.
      * P0-6: env-var-only success footer now includes a
        copy-pasteable "Try it now" block — a smoke-test command and
        a follow-up report command — so a brand-new user can confirm
        end-to-end metering works in two commands.
    """
    from halton_meter.branding import (
        BRAND_ORANGE,
        ICON_CHEVRON,
        ICON_OK,
        ICON_WARN,
        MUTED,
        OK,
        WARN,
        brand_panel,
    )
    from halton_meter.port_alloc import API_PORT_DEFAULT, LISTEN_PORT_DEFAULT

    ok_bullet = f"[{OK}]{ICON_OK}[/{OK}] "
    warn_bullet = f"[{WARN}]{ICON_WARN}[/{WARN}] "

    rows: list[str] = []
    rows.append(f"{ok_bullet} Cert + keychain trust + certifi patched")

    install_label = "OS supervisor (launchd) installed & loaded"
    if proxy_skipped_running_daemon:
        install_label += f" [{WARN}](skipped — live daemon running)[/{WARN}]"
    install_bullet = ok_bullet if install_done else warn_bullet
    rows.append(f"{install_bullet} {install_label}")

    # --full only: system-proxy bullet sits above the launchctl row.
    if mode == MODE_FULL:
        proxy_bullet = ok_bullet if proxy_done else warn_bullet
        rows.append(f"{proxy_bullet} System proxy points at halton-meter")

    # apps + full: launchctl + shell-rc bullets.
    if mode in (MODE_APPS, MODE_FULL):
        env_bullet = ok_bullet if setenv_done else warn_bullet
        rows.append(
            f"{env_bullet} launchctl user-domain env set "
            "(GUI/Spotlight coverage)"
        )

        if shell_rc_status is not None:
            if shell_rc_status in ("appended", "replaced", "unchanged"):
                rows.append(
                    f"{ok_bullet} Shell rc appended — new shells will "
                    "inherit proxy vars"
                )
            elif shell_rc_status == "declined":
                rows.append(
                    f"[{WARN}]~[/{WARN}]  Shell rc declined — "
                    f"[{MUTED}]env vars only active in current shell[/{MUTED}]"
                )
            elif shell_rc_status == "missing-rc":
                rows.append(
                    f"[{WARN}]~[/{WARN}]  Shell rc not found — "
                    f"[{MUTED}]skipped[/{MUTED}]"
                )
            elif shell_rc_status == "skipped":
                rows.append(
                    f"[{WARN}]~[/{WARN}]  Shell rc skipped "
                    f"[{MUTED}](--no-shell-rc / non-interactive)[/{MUTED}]"
                )
            elif shell_rc_status == "reconciled":
                # env-only path leaks here only via reconcile in apps/full;
                # render as a neutral muted note.
                pass
            else:
                rows.append(
                    f"[{WARN}]~[/{WARN}]  Shell rc: "
                    f"[{MUTED}]{shell_rc_status}[/{MUTED}]"
                )

    # P0-5: surface auto-port-fallback when applicable.
    if listen_port is not None and api_port is not None:
        listen_fallback = listen_port != LISTEN_PORT_DEFAULT
        api_fallback = api_port != API_PORT_DEFAULT
        if listen_fallback or api_fallback:
            rows.append(
                f"[{WARN}]~[/{WARN}]  Effective ports: "
                f"proxy=:{listen_port}, api=:{api_port} "
                f"[{MUTED}](fallback from busy default "
                f":{LISTEN_PORT_DEFAULT}/:{API_PORT_DEFAULT})[/{MUTED}]"
            )

    # Tagline. Brand-orange — drives the brand voice on the success
    # surface that gets shown to clients. Blank line above and below
    # to set it apart from the bullets and the next-steps list.
    tagline = (
        f"\n\n[bold {BRAND_ORANGE}]"
        "Your LLM API spend is now under full governance."
        f"[/bold {BRAND_ORANGE}]"
    )

    # Next-steps block. Mode-aware: env-only keeps its existing copy
    # (try-it-now smoke test); apps/full surface a focused 3-line
    # next-step list with chevrons.
    chev = f"[{BRAND_ORANGE}]{ICON_CHEVRON}[/{BRAND_ORANGE}]"
    em_dash = "—"
    if mode == MODE_ENV_ONLY:
        # env-only keeps the legacy "Try it now" smoke-test block — a
        # brand-new user can confirm end-to-end metering in two
        # commands without re-running init in a broader mode.
        next_steps = (
            f"[bold]Try it now (smoke test):[/bold]\n"
            f"  {chev} [bold]halton-meter run -- curl -sS "
            "https://api.anthropic.com/v1/messages -o /dev/null[/bold]\n"
            f"  {chev} [bold]halton-meter report[/bold]   "
            f"[{MUTED}]{em_dash} inspect captured rows[/{MUTED}]\n\n"
            f"[{MUTED}]Next steps:[/{MUTED}]\n"
            f"  {chev} [bold]halton-meter init --apps[/bold]   "
            f"[{MUTED}]{em_dash} terminal + Spotlight-app coverage[/{MUTED}]\n"
            f"  {chev} [bold]halton-meter init --full[/bold]   "
            f"[{MUTED}]{em_dash} broadest coverage (browsers + GUI apps)[/{MUTED}]"
        )
    elif mode == MODE_APPS:
        # v0.1.21 (2026-05-05): lead with `halton-meter start` so the
        # user's first move maps onto the manual-start architecture.
        # Init still loads the plists and verifies /health; the
        # difference is REBOOT no longer auto-starts the daemon, so
        # `start` is the canonical "begin metering" verb from now on.
        next_steps = (
            f"[{MUTED}]Next steps:[/{MUTED}]\n"
            f"  {chev} [bold]halton-meter start[/bold]          "
            f"[{MUTED}]{em_dash} begin metering for this session[/{MUTED}]\n"
            f"  {chev} [bold]halton-meter status[/bold]         "
            f"[{MUTED}]{em_dash} verify everything is healthy[/{MUTED}]\n"
            f"  {chev} [bold]halton-meter report[/bold]         "
            f"[{MUTED}]{em_dash} see real cost attribution[/{MUTED}]\n"
            f"  {chev} [bold]halton-meter init --full[/bold]    "
            f"[{MUTED}]{em_dash} add browser coverage later[/{MUTED}]"
        )
    else:  # MODE_FULL
        next_steps = (
            f"[{MUTED}]Next steps:[/{MUTED}]\n"
            f"  {chev} [bold]halton-meter start[/bold]          "
            f"[{MUTED}]{em_dash} begin metering for this session[/{MUTED}]\n"
            f"  {chev} [bold]halton-meter status[/bold]         "
            f"[{MUTED}]{em_dash} verify everything is healthy[/{MUTED}]\n"
            f"  {chev} [bold]halton-meter report[/bold]         "
            f"[{MUTED}]{em_dash} see real cost attribution[/{MUTED}]\n"
            f"  {chev} [bold]halton-meter init --apps[/bold]    "
            f"[{MUTED}]{em_dash} revert to apps-only (no system proxy)[/{MUTED}]"
        )

    body = "\n".join(rows) + tagline + "\n\n" + next_steps

    # v0.1.20.dev1: render through brand_panel so init's celebratory
    # final card sits in the same visual language as status / doctor.
    severity = "ok" if (setup_done and install_done) else "warn"
    title = (
        "Onboarding Complete"
        if severity == "ok"
        else f"halton-meter init ({mode})"
    )
    console.print(brand_panel(body, title=title, severity=severity))


def _render_panel_failure(console: Console, title: str, message: str) -> None:
    console.print(
        Panel(
            message,
            title=f"halton-meter init — {title}",
            border_style="red",
            expand=False,
        )
    )


# v0.1.21.5: surface the latest install.err.log entries inside the
# "supervisor install failed" panel. The wrapping subprocess capture
# sometimes obscures the launchctl stderr that ``install.py`` emitted
# to its own stderr, leaving the user with the unhelpful "See messages
# above." copy. Reading the persisted log lets the panel inline the
# real diagnostic.
_INSTALL_ERR_LOG = Path.home() / ".halton-meter" / "install.err.log"


def _read_latest_install_error(max_lines: int = 10) -> str | None:
    """Return up to ``max_lines`` from the tail of ``install.err.log``.

    None if the file doesn't exist or can't be read. Best-effort — the
    panel's fallback copy renders if this returns None.
    """
    try:
        if not _INSTALL_ERR_LOG.exists():
            return None
        with _INSTALL_ERR_LOG.open("r", encoding="utf-8", errors="replace") as fh:
            lines = fh.readlines()
        if not lines:
            return None
        tail = lines[-max_lines:]
        return "".join(tail).rstrip()
    except OSError:
        return None


# --------------------------------------------------------------------------- #
# Install-mode sentinel + GUI-only helpers (v0.1.3 P0-3)                       #
# --------------------------------------------------------------------------- #


def write_install_mode(mode: str) -> None:
    """Write the install-mode sentinel atomically.

    ``mode`` must be one of the canonical modes (``MODE_ENV_ONLY``,
    ``MODE_APPS``, ``MODE_FULL``). Legacy ``MODE_GUI`` is rejected here
    on write — the migration path is read-side only (see
    :func:`read_install_mode`). Best-effort: a write failure is logged
    but not raised — the daemon's ``proxy-managed`` sentinel (handled
    separately by ``setup.run_setup(managed=...)``) is the load-bearing
    gate. Install-mode is a hint for uninstall + doctor.
    """
    if mode not in _CANONICAL_MODES:
        raise ValueError(
            f"unknown install mode: {mode!r}; "
            f"expected one of {_CANONICAL_MODES}"
        )
    try:
        INSTALL_MODE_PATH.parent.mkdir(parents=True, exist_ok=True)
        tmp = INSTALL_MODE_PATH.with_suffix(".tmp")
        tmp.write_text(mode + "\n", encoding="utf-8")
        os.replace(tmp, INSTALL_MODE_PATH)
    except OSError as exc:
        log.warning("init.install_mode.write_failed", mode=mode, error=str(exc))


def read_install_mode() -> str | None:
    """Read the install-mode sentinel. Returns ``None`` if absent / unreadable.

    v0.1.5 (2B.16) migration: a sentinel value of ``"gui"`` (the
    v0.1.3/v0.1.4 name) is read-tolerated and reported as the new
    canonical name ``"full"`` — without rewriting the file. The
    ``init`` flow calls :func:`migrate_legacy_mode_sentinel` on entry
    so the on-disk file is rewritten to ``"full"`` on the next init
    run; until that rewrite, every reader sees the canonical name.
    """
    try:
        if not INSTALL_MODE_PATH.exists():
            return None
        content = INSTALL_MODE_PATH.read_text(encoding="utf-8").strip()
    except OSError:
        return None
    if content in _CANONICAL_MODES:
        return content
    if content in _LEGACY_MODE_ALIASES:
        canonical = _LEGACY_MODE_ALIASES[content]
        log.info(
            "init.install_mode.legacy_alias_read",
            stored=content,
            reported=canonical,
        )
        return canonical
    return None


def migrate_legacy_mode_sentinel() -> str | None:
    """v0.1.5 (2B.16): rewrite a legacy ``gui`` sentinel to ``full``.

    Idempotent: a no-op when the on-disk sentinel is already canonical
    (or absent / unreadable). Returns the legacy value that was found
    (e.g. ``"gui"``) when a rewrite happened, or ``None`` otherwise —
    callers can use the return value to log a one-line deprecation
    notice in the init flow output.

    Best-effort: any write failure is logged and swallowed; the
    read path still maps the legacy alias to the canonical name on
    every read, so a rewrite failure here does not block correct
    behaviour downstream.
    """
    try:
        if not INSTALL_MODE_PATH.exists():
            return None
        content = INSTALL_MODE_PATH.read_text(encoding="utf-8").strip()
    except OSError:
        return None
    if content not in _LEGACY_MODE_ALIASES:
        return None
    canonical = _LEGACY_MODE_ALIASES[content]
    try:
        write_install_mode(canonical)
    except (OSError, ValueError) as exc:
        log.warning(
            "init.install_mode.migrate_failed",
            stored=content,
            error=str(exc),
        )
        return None
    log.info(
        "init.install_mode.migrated",
        stored=content,
        rewritten=canonical,
    )
    return content


def remove_install_mode() -> None:
    """Remove the install-mode sentinel. Idempotent."""
    try:
        INSTALL_MODE_PATH.unlink()
    except FileNotFoundError:
        pass
    except OSError as exc:
        log.warning("init.install_mode.remove_failed", error=str(exc))


def build_env_vars(listen_host: str, listen_port: int, certifi_bundle: Path) -> dict[str, str]:
    """Construct the proxy + cert env vars halton-meter wants in --apps/--full mode.

    ``NO_PROXY=localhost,127.0.0.1`` is critical: it prevents our own
    /health probes from tarpitting through the proxy at us. The certifi-
    patched bundle path covers Anthropic SDK + most Python tools.

    v0.1.5.1: extended set of CA env vars for tools that don't read
    SSL_CERT_FILE. Witnessed 2026-04-30: ``git push`` failed with
    "unable to get local issuer certificate" because git (Homebrew/
    OpenSSL build) reads ``GIT_SSL_CAINFO`` not ``SSL_CERT_FILE``.
    Same shape applies to ``CURL_CA_BUNDLE`` (curl) and
    ``AWS_CA_BUNDLE`` (AWS SDK).

    Per-tool env var mapping:
      * NODE_EXTRA_CA_CERTS — Node.js (claude code / windsurf / cursor)
      * SSL_CERT_FILE — OpenSSL CLI / Python ssl module
      * REQUESTS_CA_BUNDLE — Python `requests`
      * GIT_SSL_CAINFO — git (Homebrew OpenSSL build)
      * CURL_CA_BUNDLE — curl
      * AWS_CA_BUNDLE — AWS SDK / boto3
    """
    proxy_url = f"http://{listen_host}:{listen_port}"
    bundle = str(certifi_bundle)
    return {
        "HTTPS_PROXY": proxy_url,
        "HTTP_PROXY": proxy_url,
        "NO_PROXY": "localhost,127.0.0.1",
        "NODE_EXTRA_CA_CERTS": bundle,
        "SSL_CERT_FILE": bundle,
        "REQUESTS_CA_BUNDLE": bundle,
        "GIT_SSL_CAINFO": bundle,
        "CURL_CA_BUNDLE": bundle,
        "AWS_CA_BUNDLE": bundle,
    }


def detect_shell_rc() -> Path | None:
    """Return the path of the user's shell rc file, or ``None`` if undetected.

    Heuristic: read ``$SHELL`` and map ``zsh`` -> ``~/.zshrc``, ``bash`` ->
    ``~/.bashrc``. Anything else returns ``None`` (we never edit a fish /
    exotic-shell rc; the user can append the block manually).
    """
    shell = os.environ.get("SHELL", "")
    if shell.endswith("zsh"):
        return Path.home() / ".zshrc"
    if shell.endswith("bash"):
        return Path.home() / ".bashrc"
    return None


def _build_shell_rc_block(env_vars: dict[str, str]) -> str:
    """Build the marker-bracketed block of ``export KEY="VAL"`` lines."""
    lines = [SHELL_RC_BLOCK_BEGIN]
    for key in (
        "HTTPS_PROXY",
        "HTTP_PROXY",
        "NO_PROXY",
        "NODE_EXTRA_CA_CERTS",
        "SSL_CERT_FILE",
        "REQUESTS_CA_BUNDLE",
        "GIT_SSL_CAINFO",
        "CURL_CA_BUNDLE",
        "AWS_CA_BUNDLE",
    ):
        if key not in env_vars:
            continue
        # Use shlex.quote to handle paths with spaces.
        import shlex

        lines.append(f"export {key}={shlex.quote(env_vars[key])}")
    lines.append(SHELL_RC_BLOCK_END)
    return "\n".join(lines) + "\n"


def append_coverage_block_to_rc(rc_path: Path, env_vars: dict[str, str]) -> str:
    """Idempotently write the coverage block into the given shell rc file.

    Returns one of:
      * ``"appended"`` — block was not present; appended.
      * ``"replaced"`` — block was present; content replaced (env-var
        values may have drifted, e.g. port changed).
      * ``"unchanged"`` — block was present and content matches.
      * ``"missing-rc"`` — rc file does not exist; cannot append safely
        (we never create a shell rc that didn't exist — the user may
        have intentionally deleted it).
    """
    if not rc_path.exists():
        return "missing-rc"
    block = _build_shell_rc_block(env_vars)
    existing = rc_path.read_text(encoding="utf-8")

    if SHELL_RC_BLOCK_BEGIN in existing:
        # Replace the existing block.
        before, _sep, rest = existing.partition(SHELL_RC_BLOCK_BEGIN)
        _block_body, _sep2, after = rest.partition(SHELL_RC_BLOCK_END)
        # Handle both `MARKER\n` and `MARKER\n\n` after-states cleanly.
        after = after.lstrip("\n")
        new_content = before.rstrip() + ("\n\n" if before.strip() else "") + block
        if after:
            new_content = new_content.rstrip() + "\n\n" + after
        # Idempotency check: was the on-disk block already byte-identical?
        # Reconstruct what the block-only section would have been.
        old_block = SHELL_RC_BLOCK_BEGIN + _block_body + SHELL_RC_BLOCK_END + "\n"
        if old_block.strip() == block.strip():
            return "unchanged"
        rc_path.write_text(new_content, encoding="utf-8")
        return "replaced"

    # No block present; append at the end (preserve trailing newline norms).
    if not existing.endswith("\n"):
        existing += "\n"
    new_content = existing + "\n" + block
    rc_path.write_text(new_content, encoding="utf-8")
    return "appended"


def remove_coverage_block_from_rc(rc_path: Path) -> bool:
    """Remove every marker-bracketed block from ``rc_path``. Returns True
    iff at least one block was found and removed. Idempotent — missing
    block / missing file returns False without error.

    v0.1.4 (2B.15) loops until no marker remains. The pre-v0.1.3 install
    paths could append multiple blocks to ``~/.zshrc`` (one per
    ``init --gui`` invocation, before the marker-replace logic landed).
    Witnessed: 6 ``halton-meter`` mentions across multiple bracketed
    blocks. The earlier single-pass remove only stripped one of them —
    the rest of the stale blocks would survive uninstall and continue
    to set ``HTTPS_PROXY`` on every new shell.
    """
    try:
        if not rc_path.exists():
            return False
        existing = rc_path.read_text(encoding="utf-8")
    except OSError:
        return False
    if SHELL_RC_BLOCK_BEGIN not in existing:
        return False

    new_content = existing
    while SHELL_RC_BLOCK_BEGIN in new_content:
        before, _sep, rest = new_content.partition(SHELL_RC_BLOCK_BEGIN)
        _block_body, _sep2, after = rest.partition(SHELL_RC_BLOCK_END)
        after = after.lstrip("\n")
        # Collapse double newlines from the join boundary.
        rebuilt = before.rstrip() + ("\n" if after else "")
        if after:
            rebuilt += after
        # Defensive: a malformed block (BEGIN with no matching END) would
        # have ``_block_body`` swallow the rest of the file and ``after``
        # be empty. Detect that case and bail rather than infinite-loop:
        # if rebuilt still contains BEGIN, something is wrong with the
        # rc shape; just write what we have and stop.
        if SHELL_RC_BLOCK_BEGIN in rebuilt and rebuilt == new_content:
            break
        new_content = rebuilt

    rc_path.write_text(new_content, encoding="utf-8")
    return True


def _is_live_install() -> bool:
    """Return True iff this machine already has a live halton-meter install.

    v0.1.19.dev1 (Phase 2 Bug C): used by ``init`` to choose between
    repair-in-place and destructive rollback when the post-install
    self-test fails. A "live install" is any of:

    * an install-mode sentinel exists (``apps`` / ``full`` / legacy
      ``gui``); OR
    * launchd reports the daemon agent is loaded (live process).

    The ``apps``/``full`` modes additionally write user-domain env
    vars; their absence does not disqualify a "live" install since
    the sentinel and live daemon are the load-bearing signals.

    Pre-fix, ``init`` would unconditionally call
    ``install_module.uninstall(purge=False)`` on a self-test failure,
    which tore down a working-but-degraded daemon + watchdog + edge +
    userenv plus the system proxy state. The user's recovery path
    became "lose every running supervisor and rebuild from scratch"
    even when the actual problem was a port mismatch the daemon
    itself could fix on the next launchctl kickstart.
    """
    try:
        if read_install_mode() is not None:
            return True
    except Exception:
        pass
    if sys.platform == "darwin" and _detect_live_daemon():
        return True
    return False


# --------------------------------------------------------------------------- #
# Squatter reaper (v0.1.19.dev2 — Phase 2)                                    #
# --------------------------------------------------------------------------- #
#
# Targets a narrow failure mode observed in the wild: a halton-meter
# daemon / edge / watchdog process from a previous launchctl bootout
# survives the bootout (zombie / detached child) and continues to hold
# one of the marketed default ports (8081 edge, 8090 daemon, 8765 api).
# When repair-mode init runs ``launchctl kickstart`` on a fresh plist,
# the new process fails to bind because the squatter still owns the
# port; the self-test re-run reports unhealthy and the install rolls
# back unnecessarily.
#
# Scope guarantees (recorded in memory/decisions.md 2026-05-04 — "Init
# squatter reaper: own-process scope only"):
#
#   1. We reap ONLY processes whose ``ps -o comm=`` matches a small
#      hard-coded allowlist of halton-meter-owned binaries. An
#      unrelated process holding the port (a developer's local
#      service, another vendor's proxy, etc.) is NEVER touched —
#      we log and bail to the existing fallback path.
#
#   2. We reap with user consent in interactive runs. Non-interactive
#      runs (and ``--clean`` runs) auto-consent: the user already
#      asked for repair, and the holder is a stale instance of our
#      own software.
#
#   3. SIGTERM with a 2s grace window, then SIGKILL. Idempotent:
#      a no-op when the holder PID belongs to the current process
#      (we never reap ourselves).
#
# The reaper is invoked from within ``_repair_live_install`` BEFORE
# the launchctl kickstart, so the kickstart-spawned daemon finds an
# empty port and binds the marketed default rather than auto-falling
# back to 8082 / 8091.

# Halton-meter-owned process names. ``ps -o comm=`` returns just the
# basename of the executable; for ``python3 -m halton_meter.cli`` that's
# ``python3`` (or ``python``). The cli-args check is intentionally NOT
# done here — name-only matching is the safety boundary, and a stricter
# match (cmdline contains "halton_meter") is layered on top in
# :func:`_is_halton_meter_pid` for the python-binary cases.
_HALTON_OWNED_NAMES: frozenset[str] = frozenset(
    {
        "halton-meter",
        "halton-meter-edge",
        "halton-meter-watchdog",
    }
)

# Python interpreter names — match-by-name alone is NOT sufficient
# (any python script could be holding the port). For these we also
# require the cmdline to mention ``halton_meter``.
_PYTHON_INTERPRETER_NAMES: frozenset[str] = frozenset(
    {"python", "python3", "python3.11", "python3.12", "python3.13", "python3.14"}
)

# Default ports the reaper inspects on every repair invocation. We
# keep this list narrow (only the three marketed defaults) so a
# misconfigured non-default port never becomes a reap target.
_DEFAULT_PORTS_TO_INSPECT: tuple[int, ...] = (8081, 8090, 8765)


def _process_cmdline(pid: int) -> str:
    """Best-effort: return the full ``ps`` cmdline for ``pid``. Empty on error."""
    try:
        result = subprocess.run(
            ["ps", "-o", "command=", "-p", str(pid)],
            capture_output=True,
            text=True,
            timeout=3,
            check=False,
        )
    except (OSError, subprocess.SubprocessError):
        return ""
    return (result.stdout or "").strip()


def _is_our_process(proc: Any) -> bool:
    """Identify halton-meter-owned processes regardless of binary path.

    v0.1.20.1 cold-boot resilience: under pipx,
    ``psutil.Process.exe()`` returns the Python interpreter path,
    indistinguishable from any other Python process. The pre-existing
    :func:`_is_halton_meter_pid` ``ps -o comm=`` based check works for
    most cases but missed the launchd-spawned daemon process under
    certain shellenv permutations, leading to ``unrelated_holder``
    false-positives that cascaded into port drift on init repair.

    Match instead by launchd job label (``XPC_SERVICE_NAME`` in the
    process env) or by argv substring. Either signal alone is
    sufficient. ``psutil.AccessDenied`` from ``environ()`` falls
    through to the cmdline check rather than raising.
    """
    import psutil as _psutil

    try:
        try:
            env = proc.environ()
            xpc = env.get("XPC_SERVICE_NAME", "")
            if xpc.startswith("com.haltonlabs.meter"):
                return True
        except (_psutil.NoSuchProcess, _psutil.AccessDenied):
            # macOS often denies environ() for cross-user / sandboxed
            # processes — fall through to the cmdline check.
            pass

        cmdline = " ".join(proc.cmdline())
        for sub in (
            "halton-meter daemon",
            "halton-meter edge",
            "halton-meter watchdog",
            "halton-meter _apply-user-env",
        ):
            if sub in cmdline:
                return True
    except (_psutil.NoSuchProcess, _psutil.AccessDenied):
        pass
    return False


def _is_halton_meter_pid(pid: int) -> bool:
    """Return True iff ``pid`` is a halton-meter-owned process.

    Two-stage match (the cardinal-rule-correct safety boundary):

      1. ``ps -o comm=`` → if the basename is in the
         halton-meter-owned name allowlist, accept directly.
      2. If the basename is a python interpreter, require the full
         cmdline (``ps -o command=``) to contain ``halton_meter`` —
         this catches ``python -m halton_meter.cli`` /
         ``python -m halton_meter.edge_main`` / etc. without
         accidentally matching every python script on the system.

    Any other process name is REJECTED. We also explicitly reject
    the current process (we never reap ourselves).
    """
    if pid <= 0:
        return False
    if pid == os.getpid():
        return False

    # Use the lifecycle module's helper for ``comm`` extraction so the
    # behaviour is consistent with the existing port-conflict detection
    # in ``halton-meter start``.
    from halton_meter.lifecycle import _process_name

    name = _process_name(pid)
    if not name or name == "unknown":
        return False
    basename = os.path.basename(name)
    if basename in _HALTON_OWNED_NAMES:
        return True
    if basename in _PYTHON_INTERPRETER_NAMES:
        cmdline = _process_cmdline(pid)
        return "halton_meter" in cmdline
    return False


def _reap_squatters_on_default_ports(
    console: Console, *, non_interactive: bool, auto_consent: bool
) -> int:
    """Detect halton-meter-owned squatters on the default ports and reap them.

    Returns the number of processes reaped. Zero when no squatter is
    present (the common case). Best-effort: any failure on a single
    port / pid logs and continues.

    Consent rules:
      * non_interactive=True OR auto_consent=True → no prompt, reap.
      * Interactive → prompt y/N before each unique PID; declined PIDs
        are left in place and the function returns whatever was
        reaped before the decline.

    Safety: ``_is_halton_meter_pid`` gates every reap. An unrelated
    process holding the port is logged
    (``init.repair.squatter.unrelated_holder``) and skipped.
    """
    import signal
    import time as _time

    from halton_meter.lifecycle import _lsof_pids_on_port, _process_name

    reaped = 0
    seen_pids: set[int] = set()

    for port in _DEFAULT_PORTS_TO_INSPECT:
        holders = _lsof_pids_on_port(port)
        if not holders:
            continue
        for pid in holders:
            if pid in seen_pids:
                continue
            seen_pids.add(pid)

            if not _is_halton_meter_pid(pid):
                # v0.1.20.1: pipx + launchd permutations leave the
                # ``ps -o comm=`` check unable to distinguish the
                # halton-meter daemon from a generic ``python3`` —
                # ``Process.exe()`` returns the interpreter, not the
                # entry-point. Try the multi-signal heuristic
                # (``XPC_SERVICE_NAME`` + argv substring) before
                # writing the process off as unrelated. Witnessed:
                # cold-boot zombie cascade where init's squatter
                # detector logged ``unrelated_holder`` for our own
                # zombie daemon, falling back to :8082 / :8091 ports.
                import psutil as _psutil

                recognised = False
                try:
                    proc = _psutil.Process(pid)
                    recognised = _is_our_process(proc)
                except (_psutil.NoSuchProcess, _psutil.AccessDenied):
                    recognised = False

                if recognised:
                    log.info(
                        "init.repair.squatter.own_process_recognised",
                        port=port,
                        pid=pid,
                        process=_process_name(pid),
                    )
                    # Fall through to the reap path below.
                else:
                    # Hard safety boundary: never touch unrelated processes.
                    log.info(
                        "init.repair.squatter.unrelated_holder",
                        port=port,
                        pid=pid,
                        process=_process_name(pid),
                    )
                    console.print(
                        f"[dim]repair: port {port} held by PID {pid} "
                        f"({_process_name(pid)}) — not halton-meter-owned, "
                        f"leaving in place.[/dim]"
                    )
                    continue

            # Squatter is one of ours. Confirm consent if interactive.
            proc_name = _process_name(pid)
            console.print(
                f"[yellow]repair: detected halton-meter squatter on "
                f":{port} (PID {pid}, {proc_name}).[/yellow]"
            )
            if not (non_interactive or auto_consent):
                try:
                    answer = console.input(
                        f"Reap halton-meter PID {pid} holding :{port}? [Y/n]: "
                    )
                except EOFError:
                    answer = ""
                if answer.strip().lower() in {"n", "no"}:
                    console.print(
                        f"[dim]repair: declined to reap PID {pid}; leaving "
                        f"in place.[/dim]"
                    )
                    continue

            # SIGTERM with a 2s grace window, then SIGKILL.
            try:
                os.kill(pid, signal.SIGTERM)
                log.info(
                    "init.repair.squatter.sigterm",
                    port=port,
                    pid=pid,
                    process=proc_name,
                )
            except (OSError, ProcessLookupError) as exc:
                # Already gone is success.
                log.info(
                    "init.repair.squatter.already_gone",
                    pid=pid,
                    error=str(exc),
                )
                reaped += 1
                continue

            # 2s grace window.
            grace_deadline = _time.monotonic() + 2.0
            while _time.monotonic() < grace_deadline:
                try:
                    os.kill(pid, 0)  # liveness probe
                except (OSError, ProcessLookupError):
                    break
                _time.sleep(0.1)
            else:
                # Still alive; escalate.
                try:
                    os.kill(pid, signal.SIGKILL)
                    log.info(
                        "init.repair.squatter.sigkill",
                        pid=pid,
                        process=proc_name,
                    )
                except (OSError, ProcessLookupError):
                    pass

            reaped += 1
            console.print(
                f"[green]repair: reaped halton-meter PID {pid} on "
                f":{port}.[/green]"
            )

    return reaped


def _repair_live_install(
    console: Console,
    *,
    mode: str,
    platform: str,
    non_interactive: bool = False,
    clean: bool = False,
) -> bool:
    """Attempt an in-place repair of a degraded live install.

    Returns True iff the second self-test passes after the repair.
    Steps:

    1. Re-run port discovery so ``runtime.toml`` and
       ``effective-ports.json`` reflect a fresh probe.
    2. Re-apply the user-domain env vars (apps/full mode only).
    3. (v0.1.19.dev2) Reap halton-meter-owned squatters on the
       marketed default ports — see :func:`_reap_squatters_on_default_ports`
       for the strict own-process-only safety boundary.
    4. ``launchctl kickstart -k`` the daemon agent so it picks up the
       refreshed ports + sentinel.
    5. Re-run the self-test once. Caller acts on the result.

    Best-effort: any individual step that raises is logged and the
    function continues. We never make the system MORE broken than
    when we found it.
    """
    console.print(
        "[yellow]Self-test failed on a live install — attempting "
        "repair-in-place before any destructive rollback.[/yellow]"
    )

    # Step 1: refresh port discovery.
    try:
        from halton_meter.port_alloc import discover_and_persist_ports

        discover_and_persist_ports()
    except Exception as exc:
        console.print(f"[dim]repair: port re-discovery failed: {exc}[/dim]")

    # Step 2: re-apply env vars (only for apps / full).
    if mode in (MODE_APPS, MODE_FULL) and platform == "darwin":
        try:
            from halton_meter import system_proxy
            from halton_meter.port_alloc import load_effective_config
            from halton_meter.setup import _certifi_bundle_path

            cfg = load_effective_config()
            env_vars = build_env_vars(
                cfg.daemon.listen_host,
                cfg.daemon.edge_port,
                _certifi_bundle_path(),
            )
            system_proxy.setenv_user_domain(env_vars)
        except Exception as exc:
            console.print(f"[dim]repair: setenv_user_domain failed: {exc}[/dim]")

    # Step 3 (v0.1.19.dev2): reap halton-meter-owned squatters on the
    # marketed default ports BEFORE the kickstart. Strict own-process
    # safety boundary in ``_is_halton_meter_pid``: never reaches an
    # unrelated holder. Auto-consents in non-interactive runs and in
    # ``--clean`` runs (the user has already opted into recovery).
    if platform == "darwin":
        try:
            _reap_squatters_on_default_ports(
                console,
                non_interactive=non_interactive,
                auto_consent=clean,
            )
        except Exception as exc:
            log.warning("init.repair.squatter.failed", error=str(exc))
            console.print(f"[dim]repair: squatter reap failed: {exc}[/dim]")

    # Step 4: kickstart the daemon agent so it picks up fresh ports.
    if platform == "darwin":
        try:
            target = f"gui/{os.getuid()}/{_DAEMON_LABEL}"
            subprocess.run(
                ["launchctl", "kickstart", "-k", target],
                capture_output=True,
                timeout=5,
                check=False,
            )
        except Exception as exc:
            console.print(f"[dim]repair: launchctl kickstart failed: {exc}[/dim]")

    # Step 5: re-run self-test once.
    try:
        retry_failures = _run_self_test(mode=mode, platform=platform, console=console)
    except Exception as exc:
        console.print(
            f"[red]repair: self-test re-run raised {type(exc).__name__}: {exc}[/red]"
        )
        return False
    if not retry_failures:
        console.print("[green]Repair succeeded; install is healthy.[/green]")
        return True
    console.print(
        "[yellow]Repair did not bring the install back to a healthy "
        "state.[/yellow]"
    )
    return False


def init(
    *,
    non_interactive: bool = False,
    gui: bool = False,
    full: bool = False,
    apps: bool = False,
    no_shell_rc: bool = False,
    clean: bool = False,
    console: Console | None = None,
) -> int:
    """First-run setup. Three modes (v0.1.5 2B.16):

    * env-var-only (default — no flag): cert + certifi + plists. NO
      system-proxy enable, NO launchctl setenv, NO shell-rc append.
      Coverage = whatever the user explicitly routes via ``halton-meter
      run``.
    * ``--apps`` (NEW in v0.1.5): cert + certifi + plists + launchctl
      setenv user-domain + idempotent shell-rc append. NO system proxy.
      Covers Spotlight/Dock-spawned apps (which inherit launchctl env)
      and new terminals (which inherit the shell-rc block) — but does
      NOT touch browsers / GUI apps that don't inherit launchctl env.
      Cannot break HSTS browsing because we never flip the system
      proxy.
    * ``--full`` (was ``--gui`` in v0.1.3/v0.1.4): everything above
      PLUS system-proxy enable. Broadest coverage; the only mode that
      can break HSTS browser sites if cert isn't trusted by SecTrust.
      ``--gui`` is kept as a deprecated alias for ``--full``.

    Idempotent across all three modes; each step independently
    resumable. Returns a process exit code (0 = success).

    Linux: keychain step is skipped (platform-guarded inside ``run_setup``),
    system proxy is not auto-managed (we print a hint), systemd unit is
    installed via :func:`install.install`.

    Windows: prints "not yet supported" and exits 0.
    """
    if console is None:
        console = Console()

    platform = sys.platform

    # v0.1.20.dev2: brand headline at the very top of the run. Mirrors the
    # ``status`` / ``doctor`` surfaces.
    try:
        from halton_meter import __version__ as _hm_version
        from halton_meter.branding import brand_headline as _brand_headline

        _subtitle = "init"
        if full or gui:
            _subtitle = "init --full"
        elif apps:
            _subtitle = "init --apps"
        console.print(_brand_headline("halton-meter", _hm_version, _subtitle))
        console.print()
    except Exception:
        # Branding failures must never abort the install.
        pass

    # v0.1.19.dev1 (Phase 2 Bug C): snapshot live-install status BEFORE
    # we touch any state. ``_is_live_install`` checks the sentinel + a
    # live launchd agent; the Bug-A fix below moves the sentinel write
    # earlier in the flow, so by step 7 the sentinel always exists. We
    # need the pre-init snapshot to know whether the user already had
    # a working-but-degraded install at the moment they ran ``init``.
    _was_live_install_at_start = _is_live_install()

    # v0.1.5 (2B.16): three-mode pivot. ``gui`` is the legacy alias for
    # ``full``; both flags select the full mode. ``apps`` selects the
    # new env-only-but-with-apps-coverage mode. Mutual exclusion is
    # enforced at the CLI layer; defensive check here too.
    selected = sum(1 for f in (apps, full or gui) if f)
    if selected > 1:
        console.print(
            "[red]Pass at most one of --apps / --full (--gui is a "
            "deprecated alias for --full).[/red]"
        )
        return _EXIT_INSTALL_FAILED
    if full or gui:
        mode = MODE_FULL
        if gui and not full:
            console.print(
                "[yellow]--gui is deprecated; use --full. Continuing with "
                "--full semantics.[/yellow]"
            )
    elif apps:
        mode = MODE_APPS
    else:
        mode = MODE_ENV_ONLY

    # Migrate any legacy ``gui`` sentinel from a v0.1.3/v0.1.4 install
    # so downstream readers (this run, status, doctor) see the canonical
    # ``full`` value. Best-effort; never raises.
    migrated = migrate_legacy_mode_sentinel()
    if migrated is not None:
        console.print(
            f"[dim](migrated install-mode sentinel: {migrated!r} -> "
            f"{MODE_FULL!r})[/dim]"
        )

    # Windows stub.
    if platform == "win32" or os.name == "nt":
        console.print(
            "[yellow]halton-meter init is not yet supported on Windows; "
            "tracked for Phase 2.x.[/yellow]"
        )
        return _EXIT_OK

    # Non-interactive admin-rights check (macOS only).
    #
    # v0.1.4 (2B.15) P0-2: the cert-trust step now prefers the macOS GUI
    # admin dialog (osascript). The dialog works even when sudo is not
    # pre-cached, so the v0.1.3 preflight that bailed on
    # ``not _sudo_pre_cached()`` was hostile to new users.
    #
    # Bail-fast guard: only exit 2 when BOTH osascript is unavailable
    # (broken macOS install or non-macOS) AND sudo is not cached. In
    # that case the cert-trust step would deadlock on a password
    # prompt with no TTY. On every other configuration (osascript
    # present, interactive run, or sudo pre-cached) we proceed and
    # let the cert-trust step elevate via whichever path works.
    if (
        non_interactive
        and platform == "darwin"
        and not _osascript_available_for_init()
        and not _sudo_pre_cached()
    ):
        console.print(
            "[red]halton-meter init --non-interactive cannot elevate "
            "to install the CA cert: osascript is unavailable AND sudo "
            "is not pre-cached.[/red]\n"
            "Pre-cache sudo with [bold]sudo -v[/bold] before running, or "
            "run [bold]halton-meter init[/bold] interactively (the GUI "
            "admin dialog will appear)."
        )
        return _EXIT_SUDO_NOT_PRECACHED

    # Step 1 — detect a live daemon (macOS only). Refreshing the plist
    # via launchctl unload+load-w briefly restarts the process, which
    # severs any in-flight Claude Code stream.
    skip_install_due_to_running_daemon = False
    if platform == "darwin" and _detect_live_daemon():
        # v0.1.20.dev5: explicit disruption messaging. The previous copy
        # ("briefly dropping any live API connection") understated the
        # impact — any LLM CLI session currently open will need to be
        # restarted, and in --full mode browser tabs / GUI apps with
        # active LLM connections may also need a refresh.
        from halton_meter.branding import (
            ICON_BULLET as _ICON_BULLET,
        )
        from halton_meter.branding import (
            brand_panel as _brand_panel,
        )

        bullet = _ICON_BULLET
        warning_lines = [
            "A halton-meter daemon is currently running.",
            "",
            "Refreshing the plist will restart it.",
            "Active LLM CLI sessions will lose their",
            "connection and need to be restarted:",
            "",
            f"  {bullet} Claude Code",
            f"  {bullet} OpenAI Codex CLI",
            f"  {bullet} Gemini CLI",
            f"  {bullet} any Anthropic / OpenAI / Gemini SDK scripts",
            "    currently making requests",
            "",
            "Existing requests in flight will fail.",
        ]
        if mode == MODE_FULL:
            warning_lines.extend(
                [
                    "",
                    "Because --full reconfigures the system proxy,",
                    "browser tabs and GUI apps with active LLM",
                    "connections (e.g. Claude.ai, ChatGPT) may also",
                    "need a refresh.",
                ]
            )
        warning = "\n".join(warning_lines)

        console.print(
            _brand_panel(
                warning,
                title="halton-meter init — live daemon detected",
                severity="warn",
            )
        )
        if non_interactive:
            console.print(
                "[dim]--non-interactive: proceeding with plist refresh.[/dim]"
            )
        else:
            try:
                proceed = console.input(
                    "Continue and restart the daemon? [y/N]: "
                )
            except EOFError:
                proceed = ""
            if proceed.strip().lower() not in {"y", "yes"}:
                console.print(
                    "[yellow]Skipped supervisor refresh.[/yellow] Cert and proxy "
                    "steps did not run because the user declined."
                )
                _render_panel_success(
                    console,
                    setup_done=True,
                    install_done=False,
                    mode=mode,
                    proxy_done=True,
                    proxy_skipped_running_daemon=True,
                )
                return _EXIT_OK

    # P0-5: probe + persist effective ports BEFORE setup / proxy / install
    # so every downstream caller (system proxy enable, env-var
    # construction, plist content if any) sees the discovered values.
    if platform == "darwin":
        try:
            from halton_meter.port_alloc import discover_and_persist_ports

            discover_and_persist_ports()
        except OSError:
            pass

    # v0.1.20.dev3: wrap the silent phases in a brand_phase_progress UI
    # for TTY users. Each phase is its own persistent line with the
    # description on the left and elapsed time on the right; the spinner
    # is replaced by a green ✓ once the phase completes. Falls back to
    # the legacy line-by-line printing when progress is disabled (CI /
    # non-interactive / piped output / opt-out env var) — the test
    # suite runs with non_interactive=True and so always takes the
    # fallback path.
    use_progress = not _progress_disabled(
        non_interactive=non_interactive, console=console
    )

    # Suppress the install module's diagnostic ``[halton-meter] ...`` prints
    # while progress is active; they would otherwise tear holes in the
    # rendered phase lines.
    from halton_meter import install as _install_module

    progress_ctx: Any = contextlib.nullcontext(None)
    if use_progress:
        from halton_meter.branding import brand_phase_progress

        progress_ctx = brand_phase_progress()

    setup_result = None
    install_rc: int | None = None
    proxy_done = False
    proxy_failed_exc: RuntimeError | None = None
    setenv_done = False
    env_vars: dict[str, str] | None = None
    rc_path: Path | None = None
    shell_rc_status: str | None = None

    def _run_phase(progress: Any, desc: str, fn: Any) -> Any:
        """Run ``fn`` as a persistent progress phase. Returns fn()'s value.

        Outside progress mode (``progress is None``), runs ``fn`` directly
        without any UI mutation — preserves legacy behaviour for tests +
        non-interactive runs.
        """
        if progress is None:
            return fn()
        task_id = progress.add_task(desc, total=1)
        try:
            return fn()
        finally:
            progress.update(task_id, completed=1)

    try:
        with progress_ctx as progress:
            if use_progress:
                _install_module.set_quiet(True)

            # Step 2 — cert + keychain + certifi.
            #
            # Progress mode: render three independent phase lines so the
            # user sees per-step timings matching the brand reference.
            # Legacy mode: call ``run_setup`` once so the existing test
            # suite's ``run_setup``/``render_result`` monkeypatches keep
            # firing exactly as before.
            from halton_meter.setup import (
                PROXY_MANAGED_SENTINEL,
                SetupResult,
                _is_macos,
                _not_supported_step,
                generate_mitmproxy_cert,
                patch_certifi,
                run_setup,
                trust_cert_macos,
            )

            if progress is not None:
                # Per-phase fan-out. Mirrors run_setup()'s ordering and
                # sentinel-write semantics so the post-condition is
                # identical.
                cert_gen = _run_phase(
                    progress,
                    "Generating mitmproxy CA cert",
                    lambda: generate_mitmproxy_cert(force=False),
                )
                if _is_macos():
                    cert_trust = _run_phase(
                        progress,
                        "Trusting cert in macOS keychain",
                        lambda: trust_cert_macos(force=False, console=console),
                    )
                else:
                    cert_trust = _not_supported_step(
                        "Trust cert in macOS keychain"
                    )
                certifi_patch = _run_phase(
                    progress,
                    "Patching certifi bundle",
                    lambda: patch_certifi(force=False),
                )
                setup_result = SetupResult(
                    cert_generated=cert_gen,
                    cert_trusted=cert_trust,
                    certifi_patched=certifi_patch,
                )
                # Replicate run_setup's PROXY_MANAGED_SENTINEL write
                # (managed=(mode == MODE_FULL)).
                if (
                    (mode == MODE_FULL)
                    and _is_macos()
                    and setup_result.all_done()
                ):
                    try:
                        PROXY_MANAGED_SENTINEL.parent.mkdir(
                            parents=True, exist_ok=True
                        )
                        PROXY_MANAGED_SENTINEL.touch(exist_ok=True)
                    except OSError:
                        pass
            else:
                setup_result = run_setup(
                    force=False,
                    managed=(mode == MODE_FULL),
                    console=console,
                )

            # Step 3 — system proxy enable. Skipped in env-only AND apps modes.
            if mode == MODE_FULL and platform == "darwin" and setup_result.all_done():
                def _do_proxy() -> None:
                    nonlocal proxy_done, proxy_failed_exc
                    try:
                        _enable_system_proxy_for_init(console=console)
                        proxy_done = True
                    except RuntimeError as exc:
                        proxy_failed_exc = exc

                _run_phase(progress, "Enabling system proxy", _do_proxy)

            # v0.1.19.dev1 (Phase 2 Bug A): write install-mode sentinel
            # BEFORE bootstrapping plists. On Linux the keychain step is
            # a "not supported" stub (cert_trusted.done=False) but cert
            # generation + certifi patching succeeded — that's enough
            # to continue.
            _setup_ok_for_install = (
                setup_result.cert_generated.done
                and setup_result.certifi_patched.done
                and (platform != "darwin" or setup_result.all_done())
            )
            if _setup_ok_for_install and proxy_failed_exc is None:
                effective_mode = mode
                if mode == MODE_FULL and platform != "darwin":
                    effective_mode = MODE_APPS
                write_install_mode(effective_mode)

                # Step 4 — supervisor install + (apps/full on darwin)
                # immediate launchctl setenv. Folded into a single phase
                # line so the user sees one timed "Configuring launchd
                # supervisors" entry covering daemon + watchdog + edge +
                # userenv plist writes, launchctl unload/load sequence,
                # and the immediate user-domain env application.
                def _do_install() -> None:
                    nonlocal install_rc, setenv_done, env_vars
                    install_rc = _install_module.install()
                    if (
                        install_rc == 0
                        and mode in (MODE_APPS, MODE_FULL)
                        and platform == "darwin"
                    ):
                        from halton_meter import system_proxy
                        from halton_meter.port_alloc import load_effective_config
                        from halton_meter.setup import _certifi_bundle_path

                        cfg = load_effective_config()
                        env_vars = build_env_vars(
                            cfg.daemon.listen_host,
                            cfg.daemon.edge_port,
                            _certifi_bundle_path(),
                        )
                        rcs = system_proxy.setenv_user_domain(env_vars)
                        setenv_done = bool(rcs) and all(
                            rc == 0 for rc in rcs.values()
                        )

                _run_phase(
                    progress,
                    "Configuring launchd supervisors",
                    _do_install,
                )
    finally:
        if use_progress:
            _install_module.set_quiet(False)

    # Render the setup checklist now that the progress UI has cleared.
    # In progress mode the user gets a tidy post-completion summary; in
    # legacy mode this prints in line with the rest of the flow.
    from halton_meter.setup import render_result as _render_setup_result

    if setup_result is not None:
        _render_setup_result(setup_result, console)

    if setup_result is None or not setup_result.all_done():
        if platform == "darwin":
            _render_panel_failure(
                console,
                "setup did not complete",
                "One or more setup steps failed; see the checklist above.\n"
                "The system proxy and OS supervisor were not touched.",
            )
            return _EXIT_SETUP_FAILED
        if not (
            setup_result.cert_generated.done and setup_result.certifi_patched.done
        ):
            _render_panel_failure(
                console,
                "setup did not complete",
                "Cert generation or certifi patching failed; see the checklist above.",
            )
            return _EXIT_SETUP_FAILED

    # v0.1.20.dev2: steps 3 (system proxy enable) and 4 (supervisor
    # install) ran inside the progress block above. Surface their
    # failure modes here, after progress has cleared, with proper
    # brand_panel error rendering.
    if proxy_failed_exc is not None:
        _render_panel_failure(
            console,
            "system proxy enable failed",
            f"{proxy_failed_exc}\n\n"
            "The OS supervisor was not installed. Re-run "
            "[bold]halton-meter init --full[/bold] to retry, or run "
            "[bold]halton-meter init --apps[/bold] for terminal+app "
            "coverage without system proxy, or "
            "[bold]halton-meter init[/bold] (no flag) for env-var-only "
            "mode.",
        )
        return _EXIT_PROXY_FAILED

    # Linux --full downgrade: surface the user-visible note now (the
    # progress block already wrote ``apps`` to the sentinel for us).
    if mode == MODE_FULL and platform != "darwin":
        console.print(
            "[yellow]Linux:[/yellow] --full system-proxy management is not "
            "yet implemented. Falling back to apps mode for this "
            "platform; the launchctl-equivalent env vars + shell-rc "
            "still cover terminals + most CLI tools."
        )
        mode = MODE_APPS  # downgrade for downstream branches.

    if install_rc is None:
        # Defensive: install never ran (setup or proxy failed earlier).
        # The setup-fail branch above should have returned; reaching here
        # means a logic gap. Surface as install failure rather than
        # silently succeeding.
        _render_panel_failure(
            console,
            "supervisor install did not run",
            "Internal: install step was skipped. Re-run "
            "[bold]halton-meter init[/bold].",
        )
        return _EXIT_INSTALL_FAILED
    if install_rc != 0:
        latest = _read_latest_install_error()
        if latest is not None:
            body = (
                f"halton-meter install exited with code {install_rc}.\n\n"
                "launchctl stderr:\n"
                f"{latest}\n\n"
                f"Full log: {_INSTALL_ERR_LOG}"
            )
        else:
            body = (
                f"halton-meter install exited with code {install_rc}. "
                "See messages above."
            )
        _render_panel_failure(
            console,
            "supervisor install failed",
            body,
        )
        return _EXIT_INSTALL_FAILED

    # Step 5 — shell-rc append: only in interactive sessions, only
    # when the user consents, and never in --no-shell-rc mode. The
    # prompt itself is always outside the progress UI so the input
    # remains visible. The actual file write — when accepted — is
    # rendered as its own "Writing shell rc block" phase line so the
    # user sees it land alongside the earlier per-phase lines.
    rc_append_decision: str | None = None  # "accept" / "decline" / None
    if mode in (MODE_APPS, MODE_FULL) and platform == "darwin":
        if no_shell_rc or non_interactive:
            shell_rc_status = "skipped"
        else:
            rc_path = detect_shell_rc()
            if rc_path is None:
                shell_rc_status = "missing-rc"
            else:
                try:
                    answer = console.input(
                        f"Append idempotent env-var block to "
                        f"[bold]{rc_path}[/bold]? "
                        "(y/N): "
                    )
                except EOFError:
                    answer = ""
                rc_append_decision = (
                    "accept"
                    if answer.strip().lower() in {"y", "yes"}
                    else "decline"
                )

    # Step 5b + Step 6 — write shell-rc block (if accepted) and
    # reconcile + sentinel re-write + self-test. Wrapped in one
    # brand_phase_progress block: the shell-rc write surfaces as a
    # persisted phase line; reconcile + self-test stay silent under
    # set_quiet so cross-mode-sweep chatter and self-test internals
    # don't tear holes in the rendered phase lines.
    progress_ctx3: Any = contextlib.nullcontext(None)
    if use_progress:
        from halton_meter.branding import brand_phase_progress as _bp3

        progress_ctx3 = _bp3()
    try:
        if use_progress:
            _install_module.set_quiet(True)
        with progress_ctx3 as p3:
            if (
                rc_append_decision == "accept"
                and rc_path is not None
                and env_vars is not None
            ):
                def _do_shell_rc() -> None:
                    nonlocal shell_rc_status
                    shell_rc_status = append_coverage_block_to_rc(
                        rc_path, env_vars
                    )

                _run_phase(p3, "Writing shell rc block", _do_shell_rc)
            elif rc_append_decision == "decline":
                shell_rc_status = "declined"

            if platform == "darwin":
                # v0.1.5 (2B.16) P0-1: three-mode reconciliation
                # invariant. Silent — no phase line. Sweep stale
                # state from prior installs in a different mode.
                _reconcile_to_mode(mode, console)
                if mode == MODE_ENV_ONLY:
                    shell_rc_status = "reconciled"

            # Idempotent sentinel re-write (load-bearing write happened
            # earlier, before the plist bootstrap).
            write_install_mode(mode)

            # v0.1.20.1: apps-mode sentinel (mirror of proxy-managed).
            # Lifecycle status reads both files to render mode-aware
            # detail. Mode-transition cleanup happens in
            # ``_reconcile_to_mode`` above (full→apps drops
            # proxy-managed). Safe to write unconditionally for the
            # current mode; failures are best-effort.
            _write_mode_sentinel_for_mode(mode)

            # Self-test (P0-6) — silent.
            failures = _run_self_test(
                mode=mode, platform=platform, console=console
            )
    finally:
        if use_progress:
            _install_module.set_quiet(False)

    if failures:
        _render_self_test_failure_panel(console, failures)
        was_live = _was_live_install_at_start
        if was_live and not clean:
            repaired = _repair_live_install(
                console,
                mode=mode,
                platform=platform,
                non_interactive=non_interactive,
                clean=clean,
            )
            if repaired:
                # Fall through to success panel below.
                pass
            else:
                console.print(
                    "[red]Repair could not bring the install back to "
                    "healthy.[/red] Re-run "
                    "[bold]halton-meter uninstall && halton-meter init "
                    "--clean[/bold] (or pass [bold]--clean[/bold] to "
                    "this command) to perform a destructive rebuild.\n"
                    "Existing supervisors and system-proxy state have "
                    "been left in place."
                )
                return _EXIT_INSTALL_FAILED
        else:
            _rollback_install(console)
            return _EXIT_INSTALL_FAILED

    # P0-5: load the effective ports so the success panel can mark
    # auto-fallback. Best-effort — fall back to (None, None) on any
    # error so the panel still renders (without the ports row).
    effective_listen_port: int | None = None
    effective_api_port: int | None = None
    try:
        from halton_meter.port_alloc import load_effective_config

        eff = load_effective_config()
        effective_listen_port = int(eff.daemon.edge_port)
        effective_api_port = int(eff.daemon.api_port)
    except Exception:
        pass

    _render_panel_success(
        console,
        setup_done=True,
        install_done=True,
        mode=mode,
        proxy_done=proxy_done,
        setenv_done=setenv_done,
        shell_rc_status=shell_rc_status,
        proxy_skipped_running_daemon=skip_install_due_to_running_daemon,
        listen_port=effective_listen_port,
        api_port=effective_api_port,
    )
    return _EXIT_OK


# --------------------------------------------------------------------------- #
# Self-test (P0-6) and rollback                                               #
# --------------------------------------------------------------------------- #


def _run_self_test(
    *, mode: str, platform: str, console: Console
) -> list[Any]:
    """Run the post-install self-test. Returns the list of FATAL failures
    (empty list = pass)."""
    from halton_meter import health
    from halton_meter.port_alloc import load_effective_config

    cfg = load_effective_config()
    api_host = cfg.daemon.api_host
    api_port = cfg.daemon.api_port
    listen_host = cfg.daemon.listen_host
    listen_port = cfg.daemon.edge_port

    checks: list[Any] = []

    # Universally applicable.
    checks.append(health.check_daemon_health(api_host, api_port))
    if platform == "darwin":
        checks.append(health.check_cert_trusted_macos())
        checks.append(health.check_plists_loaded_macos())
    checks.append(health.check_install_mode_sentinel())
    checks.append(health.check_port_persisted())

    # apps + full both require launchctl env. full additionally requires
    # the system proxy to point at us.
    if mode == MODE_FULL and platform == "darwin":
        checks.append(
            health.check_system_proxy_points_at_us(
                listen_host=listen_host, listen_port=listen_port
            )
        )
    if mode in (MODE_APPS, MODE_FULL) and platform == "darwin":
        checks.append(
            health.check_launchctl_env_var(
                key="HTTPS_PROXY",
                expected_substr=str(listen_port),
            )
        )

    # Filter to fatal failures only.
    return [c for c in checks if not c.ok and c.severity == "fatal"]


def _render_self_test_failure_panel(
    console: Console, failures: list[Any]
) -> None:
    body_lines = ["Self-test detected unrecoverable problems:"]
    for c in failures:
        body_lines.append(f"  [red]✗[/red] [bold]{c.name}[/bold] — {c.message}")
    body_lines.append(
        "\n[bold]Rolling back the install[/bold] so the system is left in a "
        "coherent state. After remediation, re-run [bold]halton-meter init[/bold]."
    )
    console.print(
        Panel(
            "\n".join(body_lines),
            title="halton-meter init — self-test failed",
            border_style="red",
            expand=False,
        )
    )


def _rollback_install(console: Console) -> None:
    """Best-effort uninstall used by P0-6 self-test rollback."""
    try:
        from halton_meter import install as install_module

        install_module.uninstall(purge=False, include_logs=False)
    except Exception as exc:
        console.print(
            "[red]warning:[/red] rollback uninstall raised "
            f"{type(exc).__name__}: {exc}\n"
            "  Run [bold]halton-meter uninstall[/bold] manually if needed."
        )


def _write_mode_sentinel_for_mode(mode: str) -> None:
    """v0.1.20.1: write the mode-marker sentinel for ``mode``.

    Mirrors ``setup.PROXY_MANAGED_SENTINEL`` which has been the
    full-mode marker since v0.1.4. Writing a parallel
    ``apps-managed`` for apps mode lets ``halton-meter status``
    distinguish the two healthy installed states without consulting
    ``install-mode`` (which is the source of truth, but a separate
    file with different load semantics — keeping the status row
    self-contained avoids cross-module ordering bugs witnessed during
    init repair).

    Content for both: ``<mode>\n<ISO-8601 timestamp>\n``. ``proxy-managed``
    is left empty for compatibility with v0.1.4-era inspections that
    only check for file existence (still valid here — both files only
    matter for existence, content is informational).

    Best-effort: any OSError is swallowed and logged. The
    install-mode sentinel + live launchd agent remain the load-bearing
    signals.
    """
    from datetime import UTC, datetime

    from halton_meter.setup import APPS_MANAGED_SENTINEL, PROXY_MANAGED_SENTINEL

    if mode == MODE_FULL:
        target = PROXY_MANAGED_SENTINEL
    elif mode == MODE_APPS:
        target = APPS_MANAGED_SENTINEL
    else:
        return  # env-only writes neither

    try:
        target.parent.mkdir(parents=True, exist_ok=True)
        ts = datetime.now(UTC).isoformat(timespec="seconds")
        target.write_text(f"{mode}\n{ts}\n", encoding="utf-8")
    except OSError as exc:
        log.warning(
            "init.mode_sentinel_write_failed",
            mode=mode,
            path=str(target),
            error=str(exc),
        )


def _reconcile_to_mode(target_mode: str, console: Console) -> None:
    """v0.1.5 (2B.16) P0-1: idempotently bring four mode-specific surfaces
    into agreement with ``target_mode``, sweeping any stale state from a
    prior install in a different mode.

    The four surfaces:

    1. **proxy-managed sentinel** (``~/.halton-meter/system-proxy``).
       Present iff target is ``full``. Drives the daemon's startup
       ``enable_system_proxy_if_managed`` — leaving it set in a non-full
       mode causes the daemon to re-enable the system proxy on every
       launch.
    2. **system proxy state** (per-interface ``networksetup``). Pointing
       at us iff target is ``full``. Disabled (or restored from
       snapshot) for env-only and apps modes.
    3. **launchctl user-domain env vars** (HTTPS_PROXY et al). Set iff
       target is in ``(apps, full)``. Unset for env-only.
    4. **shell-rc block** (marker-bracketed export block in the user's
       shell rc). Present iff target is in ``(apps, full)``. Removed
       for env-only.

    The setenv/shell-rc step in :func:`init` is additive (writes the
    block) for apps/full; the calls below for those modes are no-ops on
    those two surfaces because the apps/full step already wrote the
    correct content. The non-trivial work is the sweeping in the OTHER
    direction (e.g. apps mode arrives with a stale system proxy from a
    prior full install — must be torn down).

    Each step swallows its own errors and logs — none of them blocks
    the rest. The function never raises.

    The 9-cell mode-transition matrix
    (env-only / apps / full -> env-only / apps / full) is covered by
    this single function: each cell is a (target_mode, current state)
    pair, and the function ensures the four surfaces match the target
    regardless of where they started.
    """
    from halton_meter import system_proxy
    from halton_meter.install import (
        _USERENV_LABEL,
        _macos_userenv_plist_path,
        _proxy_managed_sentinel_path,
        _resolve_daemon_listener,
    )

    want_proxy = target_mode == MODE_FULL
    want_env = target_mode in (MODE_APPS, MODE_FULL)
    want_shell_rc = target_mode in (MODE_APPS, MODE_FULL)
    label = f"({target_mode})"

    # 1. Sentinel: present iff full. (env-only and apps both want it
    #    absent.)
    try:
        sentinel = _proxy_managed_sentinel_path()
        if not want_proxy and sentinel.exists():
            sentinel.unlink()
            console.print(
                f"[dim]{label}: removed proxy-managed sentinel from prior "
                f"--full install[/dim]"
            )
    except Exception as exc:
        log.warning("init.reconcile.sentinel_remove_failed", error=str(exc))

    # 1b. v0.1.20.1: apps-managed sentinel symmetric mirror. Present
    # iff apps. env-only and full both want it absent.
    want_apps_marker = target_mode == MODE_APPS
    try:
        from halton_meter.setup import APPS_MANAGED_SENTINEL

        if not want_apps_marker and APPS_MANAGED_SENTINEL.exists():
            APPS_MANAGED_SENTINEL.unlink()
            console.print(
                f"[dim]{label}: removed apps-managed sentinel from prior "
                f"--apps install[/dim]"
            )
    except Exception as exc:
        log.warning("init.reconcile.apps_sentinel_remove_failed", error=str(exc))

    # 2. System proxy. Disable on every interface currently pointing at
    #    us if the target mode doesn't want it.
    if not want_proxy:
        try:
            our_host, our_port = _resolve_daemon_listener()
            restored = system_proxy.restore_system_proxy(our_host, our_port)
            if not restored:
                # No snapshot. Still need to turn off any interface that
                # currently points at our listener.
                for iface in system_proxy._macos_interfaces():
                    for secure in (True, False):
                        enabled, host, port = system_proxy._read_macos_proxy(
                            iface, secure=secure
                        )
                        if enabled and system_proxy._proxy_targets_us(
                            host, port, our_host, our_port
                        ):
                            system_proxy._disable_macos_proxy(iface)
                            console.print(
                                f"[dim]{label}: disabled stale system proxy "
                                f"on {iface}[/dim]"
                            )
                            break
        except Exception as exc:
            log.warning("init.reconcile.proxy_disable_failed", error=str(exc))

    # 3. launchctl user-domain env vars. Sweep iff target doesn't want
    #    them. (apps / full set them in step 5 of init; the sweep here
    #    fires only in env-only mode.)
    if not want_env:
        try:
            system_proxy.unsetenv_user_domain(system_proxy.GUI_LAUNCHCTL_ENV_KEYS)
        except Exception as exc:
            log.warning("init.reconcile.unsetenv_failed", error=str(exc))

    # 5. v0.1.19 Task 0.1: userenv login agent. Present iff target wants
    #    env vars (apps/full). Sweep for env-only — the agent has no
    #    purpose without launchctl env vars to re-apply, and leaving it
    #    loaded would waste a login-time spawn for no work.
    if not want_env:
        try:
            import subprocess

            userenv_plist = _macos_userenv_plist_path()
            if userenv_plist.exists():
                subprocess.run(
                    ["launchctl", "unload", str(userenv_plist)],
                    capture_output=True,
                    check=False,
                )
                userenv_plist.unlink()
                console.print(
                    f"[dim]{label}: removed userenv login agent from prior "
                    f"--apps/--full install[/dim]"
                )
        except Exception as exc:
            log.warning(
                "init.reconcile.userenv_remove_failed",
                error=str(exc),
                label=_USERENV_LABEL,
            )

    # 4. Shell-rc block. Remove iff target doesn't want it. (apps / full
    #    write the block in step 5 of init; the removal here fires only
    #    in env-only mode.)
    if not want_shell_rc:
        try:
            rc_path = detect_shell_rc()
            if rc_path is not None and remove_coverage_block_from_rc(rc_path):
                console.print(
                    f"[dim]{label}: removed halton-meter env block from "
                    f"{rc_path}[/dim]"
                )
        except Exception as exc:
            log.warning("init.reconcile.rc_remove_failed", error=str(exc))


# Back-compat alias preserved so any out-of-tree callers (and the
# existing v0.1.4 tests until they're updated) continue to work.
def _reconcile_env_only_mode(console: Console) -> None:
    """Legacy alias from v0.1.4. v0.1.5 (2B.16): forwards to
    :func:`_reconcile_to_mode` with ``MODE_ENV_ONLY``."""
    _reconcile_to_mode(MODE_ENV_ONLY, console)


def _enable_system_proxy_for_init(*, console: Console) -> None:
    """Eagerly enable the macOS system proxy, elevating via osascript when needed.

    Reads the current address and only invokes the admin GUI prompt
    when the address actually differs from ``(daemon.listen_host,
    daemon.listen_port)``. The state-toggle is run un-elevated since it
    doesn't require admin.

    Reads the EFFECTIVE config (v0.1.3 P0-5) so a runtime.toml override
    is honoured — if 8080 was busy and the daemon allocated 8081, the
    system proxy is pointed at 8081.

    Raises :class:`RuntimeError` on any failure (matches the
    ``eager=True`` contract of
    :func:`halton_meter.system_proxy.enable_system_proxy_if_managed`).
    """
    from halton_meter import system_proxy
    from halton_meter.port_alloc import load_effective_config

    cfg = load_effective_config()
    host = cfg.daemon.listen_host
    port = cfg.daemon.edge_port

    # 2B.11: snapshot pre-install system-proxy state BEFORE the first
    # ``networksetup -setsecurewebproxy`` mutation so ``halton-meter
    # uninstall`` can restore it. Skipped silently if the snapshot file
    # already exists (the first capture wins — a re-run of ``init``
    # against a system whose proxy is already pointed at us must NOT
    # overwrite the original state). Best-effort: any failure during
    # the snapshot path is logged but does not block init.
    system_proxy.snapshot_system_proxy()

    # Iterate only the interfaces we know to set. If every iface either
    # already has the correct address or we successfully set it via
    # osascript, the eager call afterwards just toggles state and
    # returns without raising.
    address_was_set_via_admin = False
    for iface in system_proxy._macos_interfaces():
        for secure, set_target in (
            (True, "-setsecurewebproxy"),
            (False, "-setwebproxy"),
        ):
            _enabled, current_host, current_port = system_proxy._read_macos_proxy(
                iface, secure=secure
            )
            if system_proxy._proxy_targets_us(
                current_host, current_port, host, port
            ):
                continue
            # Try direct first — modern macOS allows networksetup without admin.
            # Fall back to osascript-wrapped admin only if the direct call fails
            # with a permission-flavoured error (older / MDM-locked machines).
            direct_argv = [
                "networksetup", set_target, iface, host, str(port)
            ]
            direct_result = subprocess.run(
                direct_argv, capture_output=True, text=True, check=False
            )
            if direct_result.returncode == 0:
                log.info(
                    "init.proxy.address_set",
                    iface=iface,
                    variant=set_target,
                    admin=False,
                )
                continue
            # Any non-zero rc warrants an elevation retry. The earlier
            # stderr-substring heuristic missed cases like rc=4 with
            # empty stderr (observed 2026-04-30 on modern macOS Ethernet
            # interfaces), so we now treat every networksetup failure as
            # a candidate for elevation. If the elevated retry also
            # fails, run_with_admin raises with the actual reason —
            # which is more useful than guessing here. See
            # decisions.md 2026-04-30 (2B.7.1).
            log.info(
                "init.proxy.elevation_retry_widened",
                iface=iface,
                variant=set_target,
                rc=direct_result.returncode,
                stderr_was_empty=not (direct_result.stderr or "").strip(),
            )
            # Escalate via osascript admin dialog.
            if not address_was_set_via_admin:
                console.print(
                    "[dim]The system proxy address could not be set without "
                    "admin rights on this macOS configuration. You'll see a "
                    "password dialog in a moment.[/dim]"
                )
                address_was_set_via_admin = True
            system_proxy.run_with_admin(
                direct_argv,
                prompt_reason=(
                    "halton-meter wants to point your system proxy at the "
                    "local metering daemon"
                ),
            )
            log.info(
                "init.proxy.address_set",
                iface=iface,
                variant=set_target,
                admin=True,
            )

    # Now run the eager pass: addresses are correct (either already or
    # just-set), so this should only toggle state-on, which doesn't need
    # admin. Any non-zero from the toggle raises.
    system_proxy.enable_system_proxy_if_managed(host, port, eager=True)
