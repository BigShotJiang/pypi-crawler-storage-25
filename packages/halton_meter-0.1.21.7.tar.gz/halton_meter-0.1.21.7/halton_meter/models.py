"""
Pydantic models for Halton Meter local log records.

LogRecord maps 1:1 to the `requests` table in schema.sql.
All money fields are integers in millicents (1 USD = 100_000 millicents).
See memory/decisions.md 2026-04-28 for the money-storage decision.
"""

from __future__ import annotations

from pydantic import BaseModel, ConfigDict, Field


class LogRecord(BaseModel):
    """
    A single captured LLM API request/response pair.

    Stored in SQLite at ~/.halton-meter/logs.db. Synced to the backend in
    Phase 1. cost_millicents is nullable — NULL means we have no pricing
    rate for this model (e.g. unknown model, or Phase 0 pricing matrix
    doesn't cover it).
    """

    model_config = ConfigDict(frozen=True)

    id: str = Field(description="UUID v4 — unique record identifier")
    project: str = Field(description="Project tag resolved by tagging.py")
    provider: str = Field(description="Provider name, e.g. 'anthropic'")
    model: str = Field(description="Model identifier as returned by the provider")

    input_tokens: int = Field(default=0, description="Prompt tokens including system and tools")
    output_tokens: int = Field(default=0, description="Completion tokens")
    thinking_tokens: int = Field(
        default=0,
        description="Extended thinking tokens (Anthropic) or reasoning tokens (OpenAI o-series)",
    )
    cache_read_tokens: int = Field(
        default=0,
        description="Cache READ tokens (Anthropic: usage.cache_read_input_tokens).",
    )
    cache_write_tokens: int = Field(
        default=0,
        description=(
            "Cache WRITE tokens (Anthropic: usage.cache_creation_input_tokens). "
            "See pricing/matrix.py for the 5m/1h TTL-limitation note."
        ),
    )

    cost_millicents: int | None = Field(
        default=None,
        description=(
            "Computed cost in millicents (1 USD = 100_000). "
            "NULL if model is unknown or not in the pricing matrix."
        ),
    )

    tokens_complete: bool = Field(
        default=True,
        description="False if response body was truncated and token counts may be partial",
    )
    latency_ms: float = Field(default=0.0, description="End-to-end latency in milliseconds")

    requested_at: str = Field(description="ISO 8601 UTC timestamp when the request was made")
    recorded_at: str = Field(description="ISO 8601 UTC timestamp when the record was written")

    # Phase 3: request disposition. 'success' | 'error' | 'blocked_by_policy'
    status: str = Field(default="success", description="Request disposition")

    # Smart Attribution observability (added 2026-05-02). Both fields are
    # populated by ``tagging.resolve_project_with_meta`` on the proxy hot
    # path so the ``requests`` table records WHICH attribution layer fired
    # for each row. Defaults are ``None`` so legacy callers (tests,
    # backfill) keep working without source-edits; the daemon's hot path
    # always supplies both.
    attribution_method: str | None = Field(
        default=None,
        description=(
            "Which attribution layer resolved the project. One of: "
            "'edge_store', 'env', 'rcfile', 'ide_sniff', 'git', 'container', "
            "'mac_sandbox', 'workdir', 'unattributed'. None when the writer "
            "did not supply a method (legacy / backfill path)."
        ),
    )
    source_workdir: str | None = Field(
        default=None,
        description=(
            "The cwd that was used as input to the layer that won. "
            "None for cache hits ('edge_store' — the original method's "
            "source_workdir was recorded ONCE at edge time and is not "
            "currently re-surfaced on cache hit; tracked as a follow-up) "
            "and for env-var hits (no cwd consulted)."
        ),
    )
