"""Background retention sweep for captured request/response bodies.

Runs inside the daemon process as a long-lived asyncio task. Once per
``interval_seconds`` (default: one day) it deletes ``request_bodies`` rows
older than ``HaltonConfig.bodies.retention_days``. The corresponding
``requests`` rows are left untouched — bodies have a TTL, counts/cost is
the metering record and persists forever.

Design:

* Idempotent. The underlying ``DELETE WHERE captured_at < ?`` is safe to
  run mid-write (SQLite WAL serialises with the proxy hot path's writers
  cleanly).
* Fail-open. Any exception is caught, logged, and the loop continues.
  A retention sweep failure must NEVER bring down the daemon.
* Background-thread offload. The actual SQLite work happens via
  ``asyncio.to_thread`` so the proxy event loop is not blocked while the
  delete runs. At 90-day default retention with hundreds of req/day the
  per-tick delete is small (zero rows on the steady-state day-after-90),
  but the offload keeps the hot path safe regardless.
* Logged via the project's standard ``structlog`` pattern with the dotted
  event name ``bodies.retention_sweep``. See ``memory/patterns.md``.

Tested via ``daemon/tests/test_retention_sweep.py``: a synthetic clock
fast-forwards the loop, a stub purge function records its invocations,
and we assert the expected sweep cadence + log line shape.
"""

from __future__ import annotations

import asyncio
import time
from collections.abc import Awaitable, Callable
from datetime import timedelta
from pathlib import Path

import structlog

from halton_meter.bodies import PurgeResult, purge_old_bodies

# Default tick: once a day. Configurable for tests so we can drive the
# loop in milliseconds rather than days.
_DEFAULT_INTERVAL_SECONDS = 24 * 60 * 60

# A purge function shaped like ``purge_old_bodies`` — kept abstract so
# tests can substitute a stub without touching SQLite.
PurgeFn = Callable[..., PurgeResult]


def _default_purge(db_path: Path, *, retention_days: int) -> PurgeResult:
    """Production purge: delete rows older than ``retention_days``."""
    return purge_old_bodies(
        db_path,
        older_than=timedelta(days=retention_days),
        dry_run=False,
        vacuum=False,
    )


async def _run_sweep_once(
    db_path: Path,
    *,
    retention_days: int,
    log: structlog.stdlib.BoundLogger,
    purge_fn: PurgeFn = _default_purge,
) -> int:
    """Run one purge sweep and emit the standard log line.

    Returns the number of rows deleted (or 0 on failure). Errors are
    logged and swallowed — the caller's loop must keep running.
    """
    started = time.monotonic()
    try:
        result = await asyncio.to_thread(
            purge_fn, db_path, retention_days=retention_days
        )
    except Exception as exc:  # pragma: no cover — defensive
        elapsed_ms = int((time.monotonic() - started) * 1000)
        log.warning(
            "bodies.retention_sweep_failed",
            error=str(exc),
            elapsed_ms=elapsed_ms,
        )
        return 0

    elapsed_ms = int((time.monotonic() - started) * 1000)
    log.info(
        "bodies.retention_sweep",
        deleted=result.rows_deleted,
        retention_days=retention_days,
        elapsed_ms=elapsed_ms,
    )
    return result.rows_deleted


async def retention_sweep_loop(
    db_path: Path,
    *,
    retention_days: int,
    interval_seconds: float = _DEFAULT_INTERVAL_SECONDS,
    purge_fn: PurgeFn = _default_purge,
    sleep_fn: Callable[[float], Awaitable[None]] | None = None,
    log: structlog.stdlib.BoundLogger | None = None,
) -> None:
    """Long-lived loop: run a retention sweep every ``interval_seconds``.

    Cancellable via the standard asyncio task cancellation. Never raises
    out of the loop body — any exception in the sweep is logged and the
    loop continues. The first sweep runs after ``interval_seconds`` (not
    on startup) so the daemon doesn't hammer SQLite during boot when
    other init work is also running.
    """
    sleeper = sleep_fn or asyncio.sleep
    bound_log = log or structlog.get_logger("halton_meter.retention")

    while True:
        try:
            await sleeper(interval_seconds)
        except asyncio.CancelledError:
            raise
        try:
            await _run_sweep_once(
                db_path,
                retention_days=retention_days,
                log=bound_log,
                purge_fn=purge_fn,
            )
        except asyncio.CancelledError:
            raise
        except Exception as exc:  # pragma: no cover — defensive
            bound_log.warning(
                "bodies.retention_sweep_loop_error", error=str(exc)
            )
