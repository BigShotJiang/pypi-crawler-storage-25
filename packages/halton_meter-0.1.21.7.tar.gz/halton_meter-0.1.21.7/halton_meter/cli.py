"""
Halton Meter CLI entry point.

Commands (Phase 0):
  daemon   — start the local proxy
  version  — print version
  report   — print cost report from local SQLite logs
  setup    — install CA cert, configure system proxy (Step 0.10)
"""

from __future__ import annotations

import asyncio
import os
import socket
import subprocess
import sys
from pathlib import Path

import click
from rich.console import Console

from halton_meter import __version__
from halton_meter.config import load_config
from halton_meter.doctor import doctor_cmd as _doctor_cmd_impl

console = Console()

# Exit codes
_EXIT_DAEMON_ALREADY_RUNNING = 1


def _silence_structlog_for_cli() -> None:
    """Route structlog events to a no-op logger for the current process.

    Used by short-lived read-only CLI commands (e.g. ``report``) that
    open the daemon's storage layer to read SQLite. Storage init emits
    ``storage.initialised`` at INFO; with structlog's default
    PrintLoggerFactory that lands on stdout and pollutes the report.

    The long-running daemon process configures structlog separately; this
    silencer only affects the process that calls it. Idempotent.
    """
    import logging

    import structlog

    structlog.configure(
        wrapper_class=structlog.make_filtering_bound_logger(logging.WARNING),
        logger_factory=structlog.PrintLoggerFactory(file=sys.stderr),
        cache_logger_on_first_use=True,
    )


# --------------------------------------------------------------------------- #
# Pre-flight: refuse to start a second daemon instance (2B.12)                #
# --------------------------------------------------------------------------- #


def _launchctl_managed_pid(label: str = "com.haltonlabs.meter") -> int | None:
    """Return the PID launchctl reports for ``label``, or None.

    Lightweight mirror of :func:`halton_meter.lifecycle._launchctl_label_pid`
    duplicated here to keep the CLI module's imports cheap (cli.py is on the
    hot path for every ``halton-meter ...`` invocation; lifecycle.py pulls
    in rich tables, sqlite3, etc.).
    """
    if sys.platform != "darwin":
        return None
    try:
        result = subprocess.run(
            ["launchctl", "list", label],
            capture_output=True,
            text=True,
            timeout=5,
            check=False,
        )
    except (OSError, subprocess.SubprocessError):
        return None
    if result.returncode != 0:
        return None
    for raw_line in result.stdout.splitlines():
        line = raw_line.strip()
        if line.startswith('"PID"'):
            _, _, rhs = line.partition("=")
            value = rhs.strip().rstrip(";").strip()
            if value == "-" or not value:
                return None
            try:
                return int(value)
            except ValueError:
                return None
    return None


def _api_port_is_bound(host: str, port: int, timeout: float = 0.1) -> bool:
    """Return True if ``host:port`` accepts a TCP connection within ``timeout``.

    Used as the second pre-flight signal: even if launchctl doesn't report
    a managed daemon (e.g. user ran a foreground ``halton-meter daemon`` in
    another terminal, or a stray process holds the port), the bind would
    fail and crash uvicorn — which historically tripped the proxy-cleanup
    handler and clobbered a live install's system-proxy state.
    """
    try:
        with socket.create_connection((host, port), timeout=timeout):
            return True
    except (OSError, TimeoutError):
        return False


def _health_ok(api_host: str, api_port: int, timeout: float = 0.5) -> bool:
    """Return True iff GET ``/health`` on ``api_host:api_port`` returns 200 OK."""
    import json as _j
    import urllib.error
    import urllib.request

    url = f"http://{api_host}:{api_port}/health"
    try:
        with urllib.request.urlopen(url, timeout=timeout) as resp:
            if getattr(resp, "status", None) != 200:
                return False
            body = resp.read()
            try:
                payload = _j.loads(body.decode("utf-8"))
            except (ValueError, UnicodeDecodeError):
                return False
            return isinstance(payload, dict) and payload.get("status") == "ok"
    except (urllib.error.URLError, TimeoutError, OSError):
        return False
    except Exception:
        return False


def _system_proxy_enabled(listen_host: str, listen_port: int) -> bool:
    """Return True iff the macOS system proxy on any active interface
    currently points at our listener.

    Linux / Windows: returns False (managed via env vars; we don't probe
    those from the CLI side here).
    """
    if sys.platform != "darwin":
        return False
    try:
        from halton_meter import system_proxy

        for iface in system_proxy._macos_interfaces():
            for secure in (True, False):
                enabled, host, port = system_proxy._read_macos_proxy(
                    iface, secure=secure
                )
                if not enabled:
                    continue
                if system_proxy._proxy_targets_us(host, port, listen_host, listen_port):
                    return True
    except Exception:
        return False
    return False


def _empty_records_hint(cfg: object) -> str:
    """Build a Rich-markup hint string for the empty-records branch of
    ``halton-meter report`` (and any future caller).

    Three branches based on actual daemon state — never recommend
    ``halton-meter daemon`` to the end user (that's a foreground/dev
    command). (2B.12.1)
    """
    daemon_up = _health_ok(cfg.daemon.api_host, cfg.daemon.api_port)
    proxy_on = (
        _system_proxy_enabled(cfg.daemon.listen_host, cfg.daemon.edge_port)
        if daemon_up
        else False
    )

    muted = "bright_black"
    if daemon_up and proxy_on:
        return (
            f"[{muted}]daemon is running and the system proxy is enabled. "
            f"Make an LLM API call through your client (Claude Code, an "
            f"SDK, curl with HTTPS_PROXY set, etc.) — captures will appear "
            f"here.[/]"
        )
    if daemon_up and not proxy_on:
        return (
            f"[{muted}]daemon is running but the system proxy is disabled. "
            f"Run[/] [bold]halton-meter start[/] [{muted}]to enable "
            f"metering, then make an LLM API call.[/]"
        )
    return (
        f"[{muted}]daemon is not running. Run[/] [bold]halton-meter start[/] "
        f"[{muted}]to begin metering. (Initial install:[/] "
        f"[bold]halton-meter init[/][{muted}].)[/]"
    )


def _preflight_or_exit(api_host: str, api_port: int) -> None:
    """Refuse to start the daemon if another instance is already running.

    Emits a clear hint message and exits with
    :data:`_EXIT_DAEMON_ALREADY_RUNNING` if launchctl reports a live
    ``com.haltonlabs.meter`` PID, OR if the configured API port is
    already bound. Crucially this runs BEFORE any cleanup handlers
    (atexit, signal) are registered, so a refusal does not touch the
    live install's system-proxy state. (2B.12)

    Self-recognition (v0.1.3 fix): if we ARE the launchd-spawned
    instance, the preflight must not refuse itself. launchd sets
    ``XPC_SERVICE_NAME`` to the plist label in our env, and
    ``launchctl list <label>`` reports OUR pid. Either signal means
    "the only instance launchctl knows about is us — proceed."
    Without this, the preflight ate its own tail: every launchd
    spawn refused itself, KeepAlive respawned, infinite loop.
    """
    if os.environ.get("XPC_SERVICE_NAME") == "com.haltonlabs.meter":
        return  # we are the launchd-spawned daemon; proceed.

    managed_pid = _launchctl_managed_pid()
    if managed_pid is not None and managed_pid == os.getpid():
        return  # launchctl reports us as the managed instance; proceed.

    port_busy = _api_port_is_bound(api_host, api_port)

    if managed_pid is None and not port_busy:
        return  # nothing else running; proceed.

    lines = ["halton-meter daemon: another instance is already running."]
    if managed_pid is not None:
        lines.append(
            f"  Managed by launchd: PID {managed_pid} "
            f"(label com.haltonlabs.meter)"
        )
    elif port_busy:
        lines.append(
            f"  Port {api_host}:{api_port} is bound by another process."
        )
    lines.append("")
    lines.append(
        "Use `halton-meter status` to inspect, `halton-meter stop` to halt the"
    )
    lines.append(
        "managed daemon, or `halton-meter uninstall` for full removal. The"
    )
    lines.append(
        "`halton-meter daemon` subcommand is for foreground/dev runs only."
    )
    # Plain stderr — no rich formatting so error-recovery scripts can grep.
    print("\n".join(lines), file=sys.stderr, flush=True)
    sys.exit(_EXIT_DAEMON_ALREADY_RUNNING)


def _is_first_run() -> bool:
    """Detect whether halton-meter has never been onboarded on this host.

    Heuristic — three independent signals, all of which are present on
    even a partially-onboarded install. If NONE are present the user has
    never run ``init`` and we should surface the welcome panel. We avoid
    using a single sentinel because each of the three lifecycle phases
    (cert install, plist install, first request landing in SQLite)
    creates one of them at different points in the flow; a fresh ``pipx
    install`` has none.
    """
    home = Path.home() / ".halton-meter"
    proxy_managed = home / "proxy-managed"
    db = home / "db.sqlite"
    if proxy_managed.exists() or db.exists():
        return False
    # Any plist on disk → already gone through `init`/`start`.
    plist_dir = Path.home() / "Library" / "LaunchAgents"
    if plist_dir.exists():
        for p in plist_dir.iterdir():
            name = p.name
            if name.startswith("com.haltonlabs.meter"):
                return False
    return True


def _welcome_suppressed() -> bool:
    """Honour the welcome opt-out signals.

    Skip the panel when:
      * stdout is not a TTY (scripts / pipes / CI),
      * ``HALTON_NO_WELCOME=1`` is set,
      * ``_HALTON_INIT_NO_PROGRESS`` is set (already a brand-wide opt-out
        for ornamental TTY output during init/CI).
    """
    if not sys.stdout.isatty():
        return True
    if os.environ.get("HALTON_NO_WELCOME"):
        return True
    if os.environ.get("_HALTON_INIT_NO_PROGRESS"):
        return True
    return False


def _print_welcome_panel() -> None:
    """Render the first-run welcome 'install poster'.

    NOTE: this surface intentionally diverges from the standard brand
    language used elsewhere (rounded box via ``brand_panel``). It is a
    one-off marketing surface — a poster a user sees exactly once on a
    fresh ``pipx install`` — so it uses ``box.SQUARE`` and a hand-built
    layout rather than the operational ``brand_panel`` / ``brand_table``
    helpers. Do NOT unify this with ``brand_panel``: the divergence is
    deliberate. See decisions.md (2026-05-04, dev6) for rationale.
    """
    from rich import box
    from rich.console import Group
    from rich.panel import Panel
    from rich.text import Text

    from halton_meter.branding import BRAND_ORANGE, MUTED, OK

    # Fixed width matches the user's mockup (68 outer chars, ``padding=(1, 3)``
    # leaves an inner content width of 60 columns). The divider rule is sized
    # to match the inner width.
    outer_width = 68
    inner_width = outer_width - 2 - (3 * 2)  # 2 borders + 2 * 3 padding = 60

    py_ver = (
        f"{sys.version_info.major}.{sys.version_info.minor}."
        f"{sys.version_info.micro}"
    )

    # Headline row: "HALTON METER" left, version right-justified.
    headline = Text()
    headline.append("HALTON METER", style=f"bold {BRAND_ORANGE}")
    version_label = f"v{__version__}"
    pad = inner_width - len("HALTON METER") - len(version_label)
    if pad < 1:
        pad = 1
    headline.append(" " * pad)
    headline.append(version_label, style=MUTED)

    # Status tick line.
    status_line = Text()
    status_line.append("✓", style=OK)
    status_line.append(f"  Installed cleanly on Python {py_ver}")

    # Tagline paragraph — user's exact words. Em-dash kept inline default.
    tagline_a = Text("Now tracking usage across your invoices with zero friction.")
    tagline_b = Text("Built for solo operators and small teams who want fair,")
    tagline_c = Text("transparent billing — nothing more, nothing less.")

    # Divider line spanning the inner width.
    divider = Text("─" * inner_width, style=MUTED)

    # Commands block.
    ready_label = Text("Ready when you are:", style=f"bold {BRAND_ORANGE}")

    def _cmd_row(cmd: str, explanation: str) -> Text:
        # Indent two spaces, command in bright_white, arrow + explanation muted.
        # Pad cmd column so arrows align: longest cmd is "halton-meter onboard"
        # (20 chars), but mockup pads to ~30 before the arrow. We pad to 30.
        cmd_col_width = 30
        line = Text()
        line.append("  ")
        line.append(cmd, style="bright_white")
        gap = cmd_col_width - len(cmd)
        if gap < 1:
            gap = 1
        line.append(" " * gap)
        line.append(f"→ {explanation}", style=MUTED)
        return line

    cmd_onboard = _cmd_row("halton-meter onboard", "set up your first meter")
    cmd_status = _cmd_row("halton-meter status", "see current usage")
    cmd_help = _cmd_row("halton-meter --help", "full command list")

    closing = Text("Welcome to the studio.")

    body = Group(
        headline,
        Text(""),
        status_line,
        Text(""),
        tagline_a,
        tagline_b,
        tagline_c,
        Text(""),
        divider,
        Text(""),
        ready_label,
        cmd_onboard,
        cmd_status,
        cmd_help,
        Text(""),
        closing,
    )

    panel = Panel(
        body,
        box=box.SQUARE,
        border_style=BRAND_ORANGE,
        padding=(1, 3),
        width=outer_width,
        expand=False,
    )
    console.print(panel)


def _maybe_print_welcome() -> None:
    """Print the welcome panel iff this is a first run and TTY/env permit.

    Called from the click group callback (bare ``halton-meter``) and
    from the read-only commands (``status`` / ``doctor`` / ``report``)
    that a curious new user is most likely to try before discovering
    ``init``. Idempotent and cheap (a small handful of filesystem stats).
    """
    if _welcome_suppressed():
        return
    if not _is_first_run():
        return
    _print_welcome_panel()


@click.group(invoke_without_command=True)
@click.version_option(__version__, prog_name="halton-meter")
@click.pass_context
def cli(ctx: click.Context) -> None:
    """Halton Meter — local LLM API cost attribution proxy."""
    # v0.1.20.dev5: first-run welcome panel. On bare ``halton-meter`` we
    # render the welcome (when applicable) BEFORE click's default help
    # output so a brand-new user sees the onboarding surface, not a wall
    # of subcommand names.
    if ctx.invoked_subcommand is None:
        # Bare ``halton-meter`` is the front-door surface — always show
        # the welcome poster regardless of onboarded state. Daily users
        # invoke specific subcommands so this isn't noisy. Suppression
        # via TTY/HALTON_NO_WELCOME/_HALTON_INIT_NO_PROGRESS still applies.
        if not _welcome_suppressed():
            _print_welcome_panel()
        click.echo(ctx.get_help())


@cli.command()
@click.option(
    "--host",
    default=None,
    help="Override listen host (default from config or 127.0.0.1).",
)
@click.option(
    "--port",
    default=None,
    type=int,
    help="Override listen port (default from config or 8080).",
)
@click.option(
    "--config",
    "config_path",
    default=None,
    type=click.Path(exists=False, dir_okay=False),
    help="Path to config.toml (default: ~/.halton-meter/config.toml).",
)
def daemon(host: str | None, port: int | None, config_path: str | None) -> None:
    """Start the Halton Meter proxy daemon."""
    from pathlib import Path

    from halton_meter.graceful_shutdown import check_graceful_shutdown_sentinel
    from halton_meter.port_alloc import (
        discover_and_persist_ports,
        load_effective_config,
    )

    # v0.1.16 Issue #1: check graceful shutdown sentinel before starting.
    # If the user ran `halton-meter stop` recently (< 30 seconds), respect
    # their intent and stay down. This prevents surprising auto-restart on
    # reboot after deliberate shutdown.
    if check_graceful_shutdown_sentinel():
        console.print(
            "[yellow]Graceful shutdown active.[/yellow] "
            "Daemon staying down (user ran `stop` or `uninstall` recently)."
        )
        sys.exit(0)

    # v0.1.3 P0-5: load the merged effective config (defaults < runtime <
    # config.toml), then run port discovery for whichever ports aren't
    # pinned, then re-load so the daemon binds to the chosen pair.
    cfg_path_obj = Path(config_path) if config_path else None
    if config_path is None:
        # Standard install path: do auto-fallback if needed.
        try:
            discover_and_persist_ports()
        except OSError:
            # Persistence is best-effort; continue with whatever was already
            # in runtime.toml + config.toml.
            pass
        cfg = load_effective_config()
        # v0.1.19.dev1 (Phase 2 Bug B): write the shared effective-ports
        # source-of-truth file. This is the file every other component
        # (edge, watchdog, _apply-user-env, status, doctor) consults so
        # they all see the same port tuple the daemon is about to bind
        # to. The bind itself happens in _run_daemon below — we write
        # here BEFORE the bind so a downstream reader that races our
        # startup sees the chosen tuple. ``edge_port`` is set to None
        # because the daemon process does not bind the edge listener;
        # the edge process merges its own bound port via
        # ``merge_edge_port_into_effective_ports``.
        from halton_meter.port_alloc import write_effective_ports

        write_effective_ports(
            edge_port=None,
            internal_port=int(cfg.daemon.internal_port),
            api_port=int(cfg.daemon.api_port),
        )
    else:
        # Explicit --config: legacy path — honour the user-supplied file
        # exactly, no auto-fallback.
        cfg = load_config(cfg_path_obj)

    # CLI flags override config values. We reconstruct a new config rather than
    # mutating the frozen Pydantic model.
    if host is not None or port is not None:
        from halton_meter.config import DaemonConfig, HaltonConfig

        daemon_cfg = DaemonConfig(
            listen_host=host or cfg.daemon.listen_host,
            edge_port=port or cfg.daemon.edge_port,
            internal_port=cfg.daemon.internal_port,
            edge_health_ttl_ms=cfg.daemon.edge_health_ttl_ms,
            log_path=cfg.daemon.log_path,
        )
        cfg = HaltonConfig(
            daemon=daemon_cfg,
            storage=cfg.storage,
            sync=cfg.sync,
        )

    # 2B.12: refuse to start if another instance is already running. MUST run
    # before _run_daemon — which registers proxy-cleanup handlers — because
    # otherwise a uvicorn bind failure on the conflicting port triggers the
    # cleanup handler on this (failing) instance and disables the LIVE
    # install's system proxy.
    _preflight_or_exit(cfg.daemon.api_host, cfg.daemon.api_port)

    sys.exit(asyncio.run(_run_daemon(cfg)) or 0)


def _http_get_returns_200(url: str, timeout: float) -> bool:
    """Synchronous helper: GET ``url``; True iff status is 200.

    Defensive — never raises. Used from ``_http_probe_health`` via
    ``run_in_executor`` to keep the event loop unblocked.
    """
    import urllib.request

    try:
        with urllib.request.urlopen(url, timeout=timeout) as resp:
            return getattr(resp, "status", None) == 200
    except Exception:
        return False


async def _http_probe_health(host: str, port: int, timeout: float = 1.0) -> bool:
    """Confirm the FastAPI ``/health`` endpoint returns 200 OK.

    Stronger guarantee than TCP connect — proves the app is routing,
    not just that uvicorn bound the socket. v0.1.21.3: replaces the
    api-port TCP probe in ``_probe_listeners_post_bind`` because
    uvicorn binds before route registration, which made the TCP probe
    succeed during a window where ``/health`` was still refusing.
    """
    url = f"http://{host}:{port}/health"
    try:
        loop = asyncio.get_running_loop()
        return await loop.run_in_executor(
            None, lambda: _http_get_returns_200(url, timeout)
        )
    except Exception:
        return False


async def _probe_listeners_post_bind(
    *,
    api_host: str,
    api_port: int,
    mitm_host: str,
    mitm_port: int,
    shutdown_event: asyncio.Event,
    delay_s: float = 0.25,
    startup_t0: float | None = None,
    mitm_ready_event: asyncio.Event | None = None,
    mitm_ready_timeout_s: float = 15.0,
) -> None:
    """One-shot post-bind health probe for the daemon's listeners.

    Sleeps ``delay_s`` to let mitmproxy + uvicorn finish attaching, then
    attempts a loopback TCP connection to each port. On success: returns
    silently. On failure: logs ``daemon.startup.health_probe_failed``,
    flags ``shutdown_event._halton_probe_failed = True``, and sets the
    event to trigger orderly teardown with a non-zero exit. The asyncio
    owner reads the flag in its ``finally`` to decide the exit code.

    No retry. The probe is defence-in-depth against the v0.1.20
    cold-boot zombie (PID alive, neither port bound). Retry-with-backoff
    around DumpMaster construction would paper over the symptom; here
    we want a fast, deterministic exit so launchd respawns with backoff.

    v0.1.21.2: gated on ``mitm_ready_event`` if provided. The probe
    fires AFTER mitmproxy signals it has finished construction (i.e.
    ``mitm_construct_end`` has been emitted) — without this gate the
    probe could TCP-connect the MITM port before mitm has had a chance
    to bind, racing it on a cold boot and false-killing a healthy
    startup. ``mitm_ready_timeout_s`` bounds the wait: if the event
    never fires the probe still trips its failure path so launchd
    respawns rather than the daemon hanging silently.
    """
    import socket as _socket

    import structlog as _structlog_local

    log = _structlog_local.get_logger("halton_meter.cli.startup_probe")

    # v0.1.21.2: wait for mitmproxy to signal listener readiness BEFORE
    # the probe TCP-connects. The proxy startup path sets this event
    # inside ``run_proxy`` after DumpMaster construction returns. If the
    # event never fires (pathological mitm hang) we time out at
    # ``mitm_ready_timeout_s`` and fall through to the probe — which
    # will TCP-fail and trigger orderly shutdown.
    if mitm_ready_event is not None:
        try:
            await asyncio.wait_for(
                mitm_ready_event.wait(), timeout=mitm_ready_timeout_s
            )
        except TimeoutError:
            log.error(
                "daemon.startup.probe_timeout",
                mitm_port=mitm_port,
                timeout_s=mitm_ready_timeout_s,
            )
            shutdown_event._halton_probe_failed = True  # type: ignore[attr-defined]
            shutdown_event.set()
            return
        except asyncio.CancelledError:
            return

    try:
        await asyncio.sleep(delay_s)
    except asyncio.CancelledError:
        return

    # v0.1.21.3: api-port probe upgrades from TCP-connect to HTTP GET
    # /health. uvicorn binds the listen socket BEFORE the FastAPI app
    # finishes wiring routes — a TCP connect succeeds in that window
    # but `/health` connection-refuses for another 1-2s. The user-soak
    # symptom: ``daemon.startup.ready`` fires, ``halton-meter status``
    # 1-2s later sees /health refused. HTTP GET is the stronger
    # guarantee that the app is actually routing. Retry up to 5x with
    # 200ms backoff to give a cold start ~1s of grace for the uvicorn
    # bind → app-ready transition.
    api_target = "127.0.0.1" if api_host in ("0.0.0.0", "::") else api_host
    mitm_target = "127.0.0.1" if mitm_host in ("0.0.0.0", "::") else mitm_host

    failed: list[tuple[str, int, str]] = []

    # mitm: TCP-connect (mitmproxy is not an HTTP origin server).
    try:
        await asyncio.to_thread(
            lambda h=mitm_target, p=mitm_port: _socket.create_connection(
                (h, p), timeout=1.0
            ).close()
        )
    except asyncio.CancelledError:
        return
    except OSError as exc:
        failed.append(("mitm", mitm_port, str(exc)))

    # api: HTTP GET /health with 5 retries / 200ms backoff.
    api_ok = False
    api_last_err = ""
    for _attempt in range(5):
        try:
            api_ok = await _http_probe_health(api_target, api_port, timeout=1.0)
        except asyncio.CancelledError:
            return
        if api_ok:
            break
        api_last_err = "non-200 or refused"
        try:
            await asyncio.sleep(0.2)
        except asyncio.CancelledError:
            return
    if not api_ok:
        failed.append(("api", api_port, api_last_err))

    if failed:
        for label, port, err in failed:
            log.error(
                "daemon.startup.health_probe_failed",
                listener=label,
                port=port,
                error=err,
            )
        # Flag the event before setting it so the awaiting coroutine
        # sees the failure in its ``finally`` block.
        shutdown_event._halton_probe_failed = True  # type: ignore[attr-defined]
        shutdown_event.set()
        return

    # v0.1.21.1: the probe succeeding is the only signal that BOTH
    # listeners are bound and accepting connections — i.e. the daemon
    # is actually ready to serve. Emit ``daemon.startup.ready`` here
    # so ``daemon.err.log`` carries an unambiguous "fully up" line
    # with total startup latency.
    import time as _time_local

    total_ms: int | None = None
    if startup_t0 is not None:
        total_ms = round((_time_local.perf_counter() - startup_t0) * 1000)
    log.info(
        "daemon.startup.ready",
        mitm_port=mitm_port,
        api_port=api_port,
        total_startup_ms=total_ms,
    )


def _configure_daemon_logging() -> None:
    """Configure structlog for the long-running daemon process.

    v0.1.21.1: every event from the daemon process must carry an
    ISO-8601 timestamp so ``daemon.err.log`` is diagnosable without
    a separate timestamp per stderr write. Output goes to stderr
    (which launchd routes to ``daemon.err.log``); foreground runs
    see the same lines on the terminal.

    Idempotent — calling twice replaces the config. Distinct from
    :func:`_silence_structlog_for_cli` which is for short-lived read
    commands like ``halton-meter report``.
    """
    import logging

    import structlog

    structlog.configure(
        processors=[
            structlog.contextvars.merge_contextvars,
            structlog.processors.add_log_level,
            structlog.processors.TimeStamper(fmt="iso", utc=True),
            structlog.processors.StackInfoRenderer(),
            structlog.processors.format_exc_info,
            structlog.dev.ConsoleRenderer(colors=False),
        ],
        wrapper_class=structlog.make_filtering_bound_logger(logging.INFO),
        logger_factory=structlog.PrintLoggerFactory(file=sys.stderr),
        cache_logger_on_first_use=True,
    )


async def _run_daemon(cfg: object) -> int:
    """Run proxy + FastAPI HTTP API + optional sync workers concurrently.

    The proxy hot path and the FastAPI app run in the same asyncio event
    loop, in the same Python process. mitmproxy listens on
    ``daemon.proxy_port``; uvicorn serves the FastAPI app on
    ``daemon.api_port``. The two are independent — if uvicorn crashes the
    proxy stays up, and vice versa. On Ctrl-C / SIGTERM the loop's
    ``add_signal_handler`` sets an ``asyncio.Event``; we cancel both
    tasks, await their teardown, and return 0.

    v0.1.21.1: every startup phase emits a structured
    ``daemon.startup.phase`` event with an ISO-8601 timestamp so we
    can diagnose where a cold-boot zombie hangs by tailing
    ``daemon.err.log``. An ``atexit`` hook fires no matter how the
    process dies (clean exit, SIGTERM, SystemExit, unhandled
    exception) and emits a ``daemon.exit`` event with reason +
    uptime. See ``decisions.md`` 2026-05-05 -- "Startup phase
    instrumentation".

    Returns the desired process exit code. ``0`` on clean shutdown
    (signal-driven or task-completed); non-zero on a startup health
    probe failure.
    """
    import atexit
    import os as _os
    import sys
    import time as _time
    import traceback as _traceback
    from pathlib import Path as _Path

    import structlog as _structlog
    import uvicorn

    from halton_meter import __version__ as _hm_version
    from halton_meter import attribution_store
    from halton_meter.api import create_app
    from halton_meter.proxy import run_proxy
    from halton_meter.system_proxy import (
        enable_system_proxy_if_managed,
        install_proxy_cleanup,
    )

    _configure_daemon_logging()
    _startup_log = _structlog.get_logger("halton_meter.cli.startup")
    _startup_t0 = _time.perf_counter()
    _startup_log.info(
        "daemon.startup.phase",
        phase="entered",
        pid=_os.getpid(),
        version=_hm_version,
        argv=list(sys.argv),
    )

    # ``atexit`` is the safety net: it fires regardless of how the
    # process exits (clean return, sys.exit, unhandled exception,
    # SIGINT/SIGTERM after our signal handler runs). Register before
    # any other setup so a crash in the lines below still produces
    # exit telemetry.
    _exit_state: dict[str, object] = {"reason": "unknown", "code": None}

    def _log_exit_reason() -> None:
        try:
            uptime_s = round(_time.perf_counter() - _startup_t0, 3)
            _structlog.get_logger("halton_meter.cli.exit").info(
                "daemon.exit",
                reason=str(_exit_state.get("reason", "unknown")),
                code=_exit_state.get("code"),
                uptime_s=uptime_s,
            )
        except Exception:  # pragma: no cover — atexit must never raise
            pass

    atexit.register(_log_exit_reason)

    # 2026-05-01 fix: SQLite-backed attribution store, swapping out the
    # v0.1.13 in-memory cache + HTTP transport (which was racing the
    # mitmproxy ``request()`` hook in production and landing every row
    # as ``unattributed``). The store points at the same SQLite file
    # the daemon already uses for everything else; the edge process
    # writes into the same file under ``BEGIN IMMEDIATE``. Both
    # processes coordinate via the file rather than via in-process
    # state. The module is a singleton — ``set_db_path`` wires it; the
    # daemon's tagger and the edge both look up the path through the
    # same module globals.
    _db_path_resolved = _Path(str(cfg.storage.db_path)).expanduser()
    attribution_store.set_db_path(_db_path_resolved)
    _startup_log.info(
        "daemon.startup.phase",
        phase="storage_initialised",
        db_path=str(_db_path_resolved),
    )

    # Background task to evict stale attribution rows. Without this
    # the table would grow forever as ephemeral ports rotate.
    # 60-second cycle deleting rows older than 5 minutes is generous
    # but bounded; on a developer machine the table never exceeds a
    # few hundred rows. ``write`` also evicts opportunistically on a
    # 1-in-50 cadence — this loop is belt-and-braces.
    _attr_log = _structlog.get_logger("halton_meter.cli.attribution")

    async def _evict_attributions_loop() -> None:
        while True:
            try:
                await asyncio.sleep(60.0)
                deleted = attribution_store.evict_stale()
                if deleted:
                    _attr_log.info("attribution.evicted", rows_deleted=deleted)
            except asyncio.CancelledError:
                raise
            except Exception as exc:  # pragma: no cover — defensive
                _attr_log.warning("attribution.evict_loop_error", error=str(exc))

    _evict_task = asyncio.create_task(
        _evict_attributions_loop(), name="halton-attribution-evict"
    )
    # Keep a reference so the task isn't GC'd during the daemon's life.
    _ = _evict_task

    # v0.1.13 PR3: daily retention sweep for captured bodies. Runs in a
    # background asyncio task; offloads the actual SQLite delete to a
    # worker thread (`asyncio.to_thread`) so the proxy hot path is not
    # blocked. Fail-open: any sweep failure is logged via structlog
    # (event ``bodies.retention_sweep`` / ``bodies.retention_sweep_failed``)
    # and the loop keeps running. Disabled when bodies capture is
    # globally off — no point sweeping a table that nothing writes to.
    if cfg.bodies.enabled:
        from halton_meter.retention import retention_sweep_loop

        _retention_task = asyncio.create_task(
            retention_sweep_loop(
                _Path(str(cfg.storage.db_path)).expanduser(),
                retention_days=int(cfg.bodies.retention_days),
            ),
            name="halton-bodies-retention",
        )
        _ = _retention_task

    # Layer 2 (Option 1): if the user has opted in to managed proxying
    # (sentinel file present), re-enable the macOS system proxy on
    # startup. This closes the loop with the watchdog: watchdog disables
    # the proxy when the daemon freezes; launchd revives the daemon;
    # daemon re-enables the proxy here so metering resumes. Without this,
    # the watchdog would silently leave metering off forever after a
    # freeze. Sentinel-gated and silent on non-macOS / if the user never
    # ran ``halton-meter setup``. Must run BEFORE install_proxy_cleanup
    # so the cleanup handler picks up the now-enabled state.
    # Note: the system proxy points at the *proxy listener* (mitmproxy,
    # default :8080), not the FastAPI HTTP API (default :8765). The
    # watchdog polls ``api_port`` for liveness but disables the proxy
    # that points at ``listen_port`` — same as install_proxy_cleanup
    # below. The brief specified ``api_port`` here; we use ``listen_port``
    # so the re-enable mirrors what layer 1's cleanup actually toggles.
    # (Reported back to the operator.)
    enable_system_proxy_if_managed(
        host=cfg.daemon.listen_host,
        port=cfg.daemon.edge_port,
    )

    # Best-effort: if the macOS system proxy is currently pointed at our
    # listener, register handlers that reset it on shutdown so a daemon
    # exit doesn't take the user's HTTPS traffic with it. Hard-coded to
    # macOS for now; Linux + Windows ports land in 2B.5/2B.6.
    proxy_cleanup = install_proxy_cleanup(
        cfg.daemon.listen_host,
        cfg.daemon.edge_port,
    )

    # Phase 2B.3 deletes the cloud-sync and policy-sync workers entirely:
    # SQLite is the canonical store in v1.0; there is no backend to push to
    # or to pull policies from. The legacy backend_url config key is kept
    # only so existing config.toml files don't blow up on load.
    #
    # The dev-only Postgres preservation sync (HALTON_PG_URL → pg_sync.PgSyncer)
    # was removed when the dashboard / Postgres surface moved to the separate
    # halton-meter-cloud repo on 2026-05-01. The Phase 3 hosted ingest path
    # will reintroduce a sync worker against that surface, not via this hook.

    # --- FastAPI app over uvicorn, alongside mitmproxy in this event loop ---
    app = create_app(cfg)
    uvicorn_config = uvicorn.Config(
        app,
        host=cfg.daemon.api_host,
        port=cfg.daemon.api_port,
        log_level="warning",
        lifespan="on",
        # Don't let uvicorn install signal handlers — the daemon process
        # already handles Ctrl-C through mitmproxy / asyncio.run.
        access_log=False,
    )
    uvicorn_server = uvicorn.Server(uvicorn_config)
    # uvicorn's default install_signal_handlers() conflicts with mitmproxy
    # in the same process; suppress it so Ctrl-C falls through to the
    # outer asyncio.run handler and shuts both servers down together.
    uvicorn_server.install_signal_handlers = lambda: None  # type: ignore[method-assign]

    _startup_log.info(
        "daemon.startup.phase",
        phase="fastapi_serve_begin",
        api_host=cfg.daemon.api_host,
        api_port=int(cfg.daemon.api_port),
    )
    api_task = asyncio.create_task(uvicorn_server.serve(), name="halton-api")

    # v0.1.20.1: asyncio-native signal handling. The previous
    # implementation registered a synchronous ``signal.signal`` handler
    # in ``install_proxy_cleanup`` that called ``sys.exit(0)``. That
    # raced uvicorn's ``capture_signals`` re-raise during loop teardown
    # and produced the cold-boot zombie observed in daemon.err.log
    # (lines 3526-3599 on 2026-05-04). Loop-aware handlers set an
    # ``asyncio.Event`` and return immediately — the coroutine below
    # races against that event and tears down deterministically.
    shutdown_requested = asyncio.Event()
    loop = asyncio.get_running_loop()
    _signal_log = _structlog.get_logger("halton_meter.cli.signal")
    import signal as _signal_mod

    def _on_signal(signame: str) -> None:
        # v0.1.21.1: log BEFORE setting the event so the err log
        # shows the trigger ahead of the orderly-shutdown chatter.
        # ``daemon.shutdown.signal`` is the canonical event name for
        # signal-driven shutdown; ``daemon.signal_received`` is kept
        # as a back-compat alias for any tail consumer that already
        # filters on it.
        _signal_log.info(
            "daemon.shutdown.signal",
            signum=int(getattr(_signal_mod, signame, 0)) or None,
            signal=signame,
        )
        _signal_log.info("daemon.signal_received", signal=signame)
        _exit_state["reason"] = "signal"
        _exit_state["code"] = signame
        shutdown_requested.set()

    for _sig, _name in (
        (_signal_mod.SIGTERM, "SIGTERM"),
        (_signal_mod.SIGINT, "SIGINT"),
    ):
        try:
            loop.add_signal_handler(_sig, _on_signal, _name)
        except (NotImplementedError, RuntimeError) as exc:
            # Windows / non-main-thread runners. Fall back to atexit-only;
            # the daemon is macOS / Linux only, so this is defence in depth.
            _signal_log.warning(
                "daemon.signal_handler_unavailable",
                signal=_name,
                error=str(exc),
            )

    print(
        f"[halton-meter] HTTP API listening on "
        f"http://{cfg.daemon.api_host}:{cfg.daemon.api_port}",
        file=sys.stderr,
        flush=True,
    )

    # macOS-only recovery hint. install_proxy_cleanup covers clean exit +
    # SIGINT/SIGTERM + atexit but not SIGKILL/segfault/OOM/power-loss; the
    # `halton-meter stop`/`uninstall` UX that closes that gap is scheduled
    # for 2B.6. Until then, the user needs the manual recovery one-liner
    # visible at daemon startup.
    if sys.platform == "darwin":
        print(
            "[halton-meter] First-time setup: run `halton-meter init` "
            "(one command does cert + proxy + supervisor)",
            file=sys.stderr,
            flush=True,
        )
        print(
            "[halton-meter] Status check anytime: `halton-meter status`",
            file=sys.stderr,
            flush=True,
        )
        print(
            "[halton-meter] If the daemon crashes hard, recover with:\n"
            "[halton-meter]   preferred:   halton-meter uninstall\n"
            "[halton-meter]   fallback:    unset HTTPS_PROXY HTTP_PROXY && "
            "networksetup -setsecurewebproxystate Wi-Fi off\n"
            "[halton-meter] Layer 2 watchdog: a sibling 'halton-meter watchdog' "
            "process polls /health every 1.5s and will disable the system\n"
            "[halton-meter]   proxy after ~7.5s of unresponsiveness so your "
            "traffic flows direct to providers (untracked, but flowing).",
            file=sys.stderr,
            flush=True,
        )

    # v0.1.21.2: gate the post-bind probe on mitmproxy's listener
    # readiness signal. ``run_proxy`` sets this event after the
    # DumpMaster bind returns so the probe never races mitm
    # construction.
    mitm_ready_event = asyncio.Event()
    proxy_task = asyncio.create_task(
        run_proxy(cfg, mitm_ready_event=mitm_ready_event), name="halton-proxy"
    )
    shutdown_task = asyncio.create_task(
        shutdown_requested.wait(), name="halton-shutdown-wait"
    )

    # Defence-in-depth: post-bind health probe. Fires once after the
    # listeners have had a moment to attach. If either probe fails, we
    # request shutdown and return non-zero so launchd respawns under
    # ``SuccessfulExit=False``. Distinct from the watchdog's ongoing
    # ``/health`` polling — this catches the cold-boot zombie where the
    # daemon process is alive but neither port is bound (witnessed on
    # v0.1.20: PID 716 alive, neither :8090 nor :8765 bound).
    probe_task = asyncio.create_task(
        _probe_listeners_post_bind(
            api_host=cfg.daemon.api_host,
            api_port=int(cfg.daemon.api_port),
            mitm_host=cfg.daemon.listen_host,
            mitm_port=int(cfg.daemon.internal_port),
            shutdown_event=shutdown_requested,
            startup_t0=_startup_t0,
            mitm_ready_event=mitm_ready_event,
        ),
        name="halton-startup-probe",
    )

    exit_code = 0
    _wait_failed: BaseException | None = None
    try:
        done, _pending = await asyncio.wait(
            {proxy_task, api_task, shutdown_task},
            return_when=asyncio.FIRST_COMPLETED,
        )
        # If the shutdown event fired we exit cleanly. If a worker task
        # finished first (e.g. proxy or uvicorn died), we still treat
        # this as a normal teardown and return 0 — launchd will respawn
        # under SuccessfulExit=False and the watchdog handles the user
        # facing fallout. Probe failure is the only path that returns
        # non-zero, signalled below.
        for t in done:
            if t is proxy_task or t is api_task:
                exc = t.exception()
                if exc is not None and not isinstance(exc, asyncio.CancelledError):
                    _signal_log.warning(
                        "daemon.task_exited_with_error",
                        task=t.get_name(),
                        error=str(exc),
                    )
                    # v0.1.21.1: capture the first task-level exception so
                    # the atexit hook records ``reason="exception"`` rather
                    # than ``reason="normal"`` for what is really a worker
                    # death.
                    if _wait_failed is None:
                        _wait_failed = exc
    except SystemExit as exc:
        # Should never fire from inside the daemon — log it loudly so
        # we know if a code path ever calls sys.exit() unexpectedly.
        _exit_state["reason"] = "system_exit"
        _exit_state["code"] = exc.code
        _structlog.get_logger("halton_meter.cli.exit").warning(
            "daemon.exit",
            reason="system_exit",
            code=exc.code,
        )
        raise
    except BaseException as exc:
        _exit_state["reason"] = "exception"
        _exit_state["code"] = type(exc).__name__
        _structlog.get_logger("halton_meter.cli.exit").error(
            "daemon.exit",
            reason="exception",
            exc_type=type(exc).__name__,
            exc_msg=str(exc),
            traceback=_traceback.format_exc(),
        )
        raise
    finally:
        # Cancel everything that's still running and wait for orderly
        # teardown. The 5s budget here covers the in-process work; the
        # 30s uvicorn drain budget below covers the HTTP graceful close.
        for t in (proxy_task, shutdown_task, probe_task):
            if not t.done():
                t.cancel()

        # Signal uvicorn to shut down and wait for it to drain.
        uvicorn_server.should_exit = True
        try:
            # 2B.10.1: 30s budget — Python 3.14 cold-start can push
            # uvicorn's serve()-task drain past the old 5s. Same grace
            # window we give launchd via ``ExitTimeOut: 30``.
            await asyncio.wait_for(api_task, timeout=30.0)
        except (TimeoutError, asyncio.CancelledError):
            api_task.cancel()
        except Exception as exc:  # pragma: no cover — defensive
            _signal_log.warning("daemon.api_drain_error", error=str(exc))
            api_task.cancel()

        # Drain the cancelled tasks so we don't leak coroutines.
        try:
            await asyncio.wait(
                {proxy_task, shutdown_task, probe_task},
                timeout=5.0,
            )
        except Exception as exc:  # pragma: no cover — defensive
            _signal_log.warning("daemon.task_drain_error", error=str(exc))

        # Reset system proxy on the way out (idempotent — also runs via
        # atexit handler in case we don't reach this finally).
        if proxy_cleanup is not None:
            try:
                proxy_cleanup()
            except Exception as exc:  # pragma: no cover — defensive
                _signal_log.warning("daemon.proxy_cleanup_error", error=str(exc))

        # If the post-bind probe fired before the shutdown_event, it
        # set a flag on the event AND raised — we surface its exit code
        # through ``_probe_failed_flag`` set on the shutdown event.
        if getattr(shutdown_requested, "_halton_probe_failed", False):
            exit_code = 1
            # Distinct exit reason — easier to grep than a generic
            # "normal exit_code=1".
            _exit_state["reason"] = "probe_failed"
            _exit_state["code"] = 1

    # v0.1.21.1: nail down the exit reason for the atexit hook. Signal-
    # driven shutdowns already set reason="signal" inside _on_signal;
    # exception paths set "exception"/"system_exit" above; probe failure
    # was just set in the finally. Anything else is a worker task
    # completing on its own (proxy died / uvicorn died) — distinguish
    # that from a clean shutdown_requested-triggered exit.
    if _exit_state["reason"] == "unknown":
        if _wait_failed is not None:
            _exit_state["reason"] = "task_exited"
            _exit_state["code"] = type(_wait_failed).__name__
        else:
            _exit_state["reason"] = "normal"
            _exit_state["code"] = exit_code

    return exit_code


@cli.command()
def version() -> None:
    """Print the halton-meter version."""
    console.print(f"halton-meter {__version__}")


@cli.command()
@click.option(
    "--project",
    default=None,
    help="Filter to one project (default: all projects).",
)
@click.option(
    "--since",
    "since_days",
    default=30,
    type=int,
    show_default=True,
    help="Only show records from the last N days. 0 returns nothing.",
)
@click.option(
    "--db",
    "db_path",
    default=None,
    type=click.Path(exists=False, dir_okay=False),
    help="Override DB path (default: from config).",
)
@click.option(
    "--config",
    "config_path",
    default=None,
    type=click.Path(exists=False, dir_okay=False),
    help="Path to config.toml (default: ~/.halton-meter/config.toml).",
)
def report(
    project: str | None,
    since_days: int,
    db_path: str | None,
    config_path: str | None,
) -> None:
    """Print a formatted cost and token report from local SQLite logs."""
    from pathlib import Path

    from halton_meter.report import build_report_data, filter_records_by_days, render_report
    from halton_meter.storage import StorageManager

    _maybe_print_welcome()

    # v0.1.20.dev4: silence structlog INFO events (e.g. "storage.initialised")
    # leaking into the report's Rich output. The daemon process configures
    # logging to file; this short-lived read-only CLI uses structlog's
    # default (PrintLogger -> stdout/stderr), which clutters the report.
    # Drop anything below WARNING for this invocation only.
    _silence_structlog_for_cli()

    cfg = load_config(Path(config_path) if config_path else None)
    resolved_db = db_path or cfg.storage.db_path

    async def _run() -> None:
        async with StorageManager(resolved_db) as storage:
            records = await storage.read_records(project=project, limit=10_000)

        filtered = filter_records_by_days(records, since_days)
        data = build_report_data(filtered)
        # 2B.12.1: tailor the empty-state hint to actual daemon state so
        # we never recommend `halton-meter daemon` (a dev-mode command)
        # to the end user.
        hint = _empty_records_hint(cfg) if data.total_requests == 0 else None
        render_report(data, console, empty_hint=hint)

    asyncio.run(_run())


@cli.command()
@click.option(
    "--once",
    is_flag=True,
    default=False,
    help="Run a single health poll and exit 0 (healthy) or 1 (unhealthy).",
)
@click.option(
    "--port",
    "port",
    default=None,
    type=int,
    help="Override api_port (default from config or 8765).",
)
@click.option(
    "--listen-port",
    "listen_port",
    default=None,
    type=int,
    help="Override the proxy listener port used to identify managed "
    "interfaces (default from config or 8080).",
)
def watchdog(once: bool, port: int | None, listen_port: int | None) -> None:
    """Layer 2 connectivity watchdog: poll /health, disable proxy on freeze.

    Runs as a separate launchd-supervised process. Polls the daemon's
    /health endpoint on ``api_port`` (default 8765) every 1.5s; after
    5 consecutive failures (~7.5s) it disables the macOS system proxy
    so the user's traffic flows direct to providers. Re-enable is the
    daemon's job on its next startup (gated on the ``proxy-managed``
    sentinel).

    Two distinct ports, two distinct purposes: ``api_port`` for
    ``/health`` polling, ``listen_port`` (default 8080) for matching
    interfaces in ``snapshot_interfaces``. The system proxy on each
    network service stores the mitmproxy listener address, not the
    HTTP API address. (2B.10.5)
    """
    import sys as _sys

    from halton_meter import watchdog as watchdog_module

    if port is None or listen_port is None:
        try:
            cfg = load_config()
            if port is None:
                port = cfg.daemon.api_port
            if listen_port is None:
                # Watchdog identifies "managed interfaces" by the proxy
                # listener address — that's the user-facing edge port
                # (post-v0.1.6 rename). v0.1.5 callers passing
                # ``--listen-port`` continue to work; the kwarg name is
                # preserved on the watchdog command for back-compat.
                listen_port = cfg.daemon.edge_port
        except Exception:
            if port is None:
                port = 8765
            if listen_port is None:
                listen_port = 8081

    if once:
        _sys.exit(watchdog_module.poll_once(port))

    watchdog_module._install_signal_handlers()
    # Pass the daemon's internal MITM port so the watchdog probes the
    # right socket for Bug 1 (silent MITM death). Edge port keeps its
    # original role (system-proxy interface tracking).
    try:
        _internal = load_config().daemon.internal_port
    except Exception:
        _internal = 8090
    _sys.exit(
        watchdog_module.run_watchdog(
            port, listen_port=listen_port, internal_port=_internal
        )
    )


@cli.command()
def install() -> None:
    """Install the OS-level supervisor (launchd / systemd) for the daemon.

    Writes a launchd plist (macOS) or systemd user unit (Linux) so the
    daemon revives within ~1s of any exit, including SIGKILL / segfault.
    Layer 1 of the three-layer connectivity-on-crash fix.
    """
    import sys as _sys

    from halton_meter import install as install_module

    _sys.exit(install_module.install())


@cli.command()
def edge() -> None:
    """Run the edge proxy (Phase 2C.2 / v0.1.6).

    The edge proxy owns the user-facing proxy port (the one that lives
    in apps' ``HTTPS_PROXY`` env var). It chains traffic through the
    metering daemon when alive, otherwise opens direct passthrough
    tunnels so the user's apps keep working across daemon stop /
    crash / upgrade. See ``memory/plans/2026-04-30-edge-proxy-decoupling.md``
    for the full design.

    Normally run via launchd plist (``com.haltonlabs.meter.edge``).
    The CLI subcommand exists for development + diagnostics.
    """
    import sys as _sys

    from halton_meter.edge_main import main as edge_main

    _sys.exit(edge_main())


@cli.command()
@click.option(
    "--purge",
    is_flag=True,
    default=False,
    help=(
        "Also delete ~/.halton-meter/ (config, sentinel, runtime state). "
        "The SQLite database is preserved unless --include-logs is also given."
    ),
)
@click.option(
    "--include-logs",
    "include_logs",
    is_flag=True,
    default=False,
    help=(
        "With --purge, also delete db.sqlite and its WAL siblings. "
        "Logged usage data is permanently destroyed."
    ),
)
@click.option(
    "--yes",
    "assume_yes",
    is_flag=True,
    default=False,
    help="Skip interactive confirmation prompts. For scripted/CI uninstall.",
)
@click.option(
    "--graceful",
    is_flag=True,
    default=False,
    help=(
        "macOS only (v0.1.9 Gap 11): leave the edge process running in "
        "pure-passthrough mode through the next reboot so apps with "
        "HTTPS_PROXY baked into their env keep working. Daemon + "
        "watchdog are still torn down."
    ),
)
def uninstall(
    purge: bool, include_logs: bool, assume_yes: bool, graceful: bool
) -> None:
    """Remove the supervisor entry and restore the system proxy.

    The system-proxy step restores the captured pre-install state from
    ``~/.halton-meter/system_state.json`` (written by ``halton-meter
    init``). If no snapshot exists, falls back to disabling the system
    proxy on every active interface — the load-bearing one-command
    recovery path if a hard crash left the user's machine pointed at a
    dead daemon.

    Three-tier data removal (2B.11):

    \b
    * default:                supervisor + sentinel + proxy restore.
                              ~/.halton-meter/ preserved (config + logs).
    * --purge:                also delete ~/.halton-meter/ EXCEPT db.sqlite
                              (+ WAL siblings). Cost data is the product.
    * --purge --include-logs: also delete db.sqlite. Permanent.
    """
    import sys as _sys
    from pathlib import Path

    from halton_meter import install as install_module
    from halton_meter.branding import (
        BRAND_ORANGE,
        ERROR,
        NUMERIC,
        WARN,
        brand_panel,
    )

    if include_logs and not purge:
        console.print(
            f"[{ERROR}]--include-logs requires --purge.[/{ERROR}] "
            "Run [bold]halton-meter uninstall --purge --include-logs[/bold] to delete logs."
        )
        _sys.exit(2)

    if purge and not assume_yes:
        if include_logs:
            db_path = Path("~/.halton-meter/db.sqlite").expanduser()
            records, projects = install_module.count_request_records(db_path)
            # Brand-language confirmation panel — error severity surfaces
            # the destructive nature; brand-orange title keeps it visually
            # consistent with `start` / `stop` panels.
            console.print(
                brand_panel(
                    f"About to delete [bold {NUMERIC}]db.sqlite[/bold {NUMERIC}] with "
                    f"[bold {NUMERIC}]{records:,}[/bold {NUMERIC}] requests across "
                    f"[bold {NUMERIC}]{projects:,}[/bold {NUMERIC}] projects.\n"
                    f"[dim]This data is permanently destroyed and cannot be recovered.[/dim]",
                    title="halton-meter uninstall — destructive",
                    severity="error",
                )
            )
            try:
                response = console.input(
                    f"Type [bold {BRAND_ORANGE}]delete[/bold {BRAND_ORANGE}] to confirm: "
                )
            except EOFError:
                response = ""
            if response.strip() != "delete":
                console.print(f"[{WARN}]Aborted.[/{WARN}] Nothing was changed.")
                _sys.exit(1)
        else:
            console.print(
                brand_panel(
                    "About to delete [bold]~/.halton-meter/[/bold] "
                    "(config, sentinel, runtime state).\n"
                    f"[dim]db.sqlite is [bold {NUMERIC}]preserved[/bold {NUMERIC}] — "
                    "use --include-logs to also delete it.[/dim]",
                    title="halton-meter uninstall --purge",
                    severity="warn",
                )
            )
            try:
                response = console.input(
                    f"Type [bold {BRAND_ORANGE}]yes[/bold {BRAND_ORANGE}] to confirm: "
                )
            except EOFError:
                response = ""
            if response.strip().lower() != "yes":
                console.print(f"[{WARN}]Aborted.[/{WARN}] Nothing was changed.")
                _sys.exit(1)

    _sys.exit(
        install_module.uninstall(
            purge=purge, include_logs=include_logs, graceful=graceful
        )
    )


@cli.command()
@click.option(
    "--quiet",
    "quiet",
    is_flag=True,
    default=False,
    help=(
        "Suppress branded panels; emit a single-line status. "
        "Useful for scripts, shell-rc helpers, and quick smoke tests. "
        "Exit codes are unchanged (0 = healthy, 1 = failed)."
    ),
)
def start(quiet: bool) -> None:
    """Start the halton-meter daemon + watchdog via launchd.

    v0.1.21 manual-start: the daemon and watchdog plists do NOT load at
    login. Run this command when you sit down to work to begin metering.
    Edge + userenv plists are auto-loaded so the fail-open pass-through
    path is alive even when metering is off.
    """
    import sys as _sys

    from halton_meter.lifecycle import start as start_fn

    _sys.exit(start_fn(console=console, quiet=quiet))


@cli.command()
def stop() -> None:
    """Stop the halton-meter daemon + watchdog and reset the system proxy.

    Pauses metering. Plists stay installed; sentinel is preserved. Run
    `halton-meter start` to resume — the daemon's startup will re-enable
    the system proxy via the managed-mode sentinel.

    For full removal, use `halton-meter uninstall` instead.
    """
    import sys as _sys

    from halton_meter.lifecycle import stop as stop_fn

    _sys.exit(stop_fn(console=console))


@cli.command()
@click.option(
    "--json",
    "json_output",
    is_flag=True,
    help="Emit machine-readable JSON instead of a Rich table.",
)
def status(json_output: bool) -> None:
    """Show daemon, watchdog, system proxy, and capture state."""
    import sys as _sys

    from halton_meter.lifecycle import status as status_fn

    # v0.1.20.dev5: first-run welcome. JSON consumers must never see it,
    # and ``_maybe_print_welcome`` already gates on TTY + env vars.
    if not json_output:
        _maybe_print_welcome()

    _sys.exit(status_fn(console=console, json_output=json_output))


@cli.command(name="reset-proxy")
def reset_proxy_cmd() -> None:
    """Layer-4 escape hatch: disable the system proxy unconditionally.

    Sentinel-blind, config-independent. Safe to run when the daemon has
    never been installed, when ``~/.halton-meter/config.toml`` is missing
    or corrupt, and when nothing is currently listening on the proxy
    port. Used by the launchd ``ExitTimeOut`` shutdown path and the
    systemd ``ExecStop=`` hook so a system reboot / logout / hard-stop
    leaves the user's network connectivity intact even if the daemon's
    in-process handlers never ran.
    """
    import sys as _sys

    from halton_meter.system_proxy import reset_proxy_minimal

    _sys.exit(reset_proxy_minimal())


@cli.command(name="rescue")
@click.option(
    "--apps/--no-apps",
    "apps",
    default=True,
    help="Re-run init in --apps mode after the reset (default).",
)
@click.option(
    "--full",
    "full",
    is_flag=True,
    default=False,
    help="Re-run init in --full mode instead of --apps.",
)
def rescue_cmd(apps: bool, full: bool) -> None:
    """Force-reset launchd state and re-run init from scratch.

    For the case where init keeps failing with launchctl errors and the
    user wants a clean reset without going through uninstall +
    reinstall. More aggressive than `init --clean` because it doesn't
    trust the previous install's state at all:

      1. ``launchctl bootout`` every halton-meter label (best-effort).
      2. SIGKILL any orphan halton-meter daemon/edge/watchdog process.
      3. Wait 2s for the kernel to release the proxy ports.
      4. Re-run ``halton-meter init`` (--apps by default; --full if
         requested) with --clean.
    """
    import os as _os
    import signal as _signal
    import subprocess as _subprocess
    import sys as _sys
    import time as _time

    from rich.panel import Panel as _Panel

    from halton_meter.install import (
        _EDGE_LABEL,
        _LABEL,
        _USERENV_LABEL,
        _WATCHDOG_LABEL,
    )
    from halton_meter.lifecycle import _gui_uid, _launchctl_bootout

    if full:
        apps = False

    actions: list[str] = []

    # Step 1 — bootout every label, best-effort.
    for label in (_LABEL, _WATCHDOG_LABEL, _EDGE_LABEL, _USERENV_LABEL):
        try:
            rc, err = _launchctl_bootout(label)
            actions.append(
                f"bootout {label}: rc={rc}"
                + (f" ({err})" if err else "")
            )
        except (OSError, _subprocess.SubprocessError) as exc:
            actions.append(f"bootout {label}: error {exc}")

    # Step 2 — SIGKILL any orphan halton-meter daemon/edge/watchdog
    # process. Use ``pgrep -f`` so we match argv even if argv[0] is the
    # python interpreter.
    killed: list[int] = []
    self_pid = _os.getpid()
    if _sys.platform == "darwin" or _sys.platform.startswith("linux"):
        for pattern in (
            "halton_meter.run",
            "halton_meter.watchdog",
            "halton_meter.edge_main",
            "halton-meter daemon",
            "halton-meter watchdog",
            "halton-meter edge",
        ):
            try:
                result = _subprocess.run(
                    ["pgrep", "-f", pattern],
                    capture_output=True,
                    text=True,
                    timeout=5,
                    check=False,
                )
            except (OSError, _subprocess.SubprocessError):
                continue
            for line in (result.stdout or "").splitlines():
                line = line.strip()
                if not line.isdigit():
                    continue
                pid = int(line)
                if pid == self_pid:
                    continue
                try:
                    _os.kill(pid, _signal.SIGKILL)
                    killed.append(pid)
                except ProcessLookupError:
                    pass
                except PermissionError:
                    actions.append(f"SIGKILL pid={pid}: permission denied")
    if killed:
        actions.append(f"SIGKILL pids: {', '.join(str(p) for p in killed)}")
    else:
        actions.append("SIGKILL pids: none found")

    # Step 3 — wait 2s for the kernel to release the proxy ports.
    _time.sleep(2.0)
    actions.append("waited 2s for port release")

    uid = _gui_uid() if _sys.platform == "darwin" else None
    body = "\n".join(f"  - {a}" for a in actions)
    body += f"\n\nuid: {uid if uid is not None else 'n/a'}"
    body += "\n\nRe-running halton-meter init --clean"
    body += f" {'--full' if full else '--apps'}…"
    console.print(
        _Panel(
            body,
            title="halton-meter rescue — reset complete",
            border_style="yellow",
            expand=False,
        )
    )

    # Step 4 — re-run init from scratch with --clean.
    from halton_meter.init import init as init_fn

    rc = init_fn(
        non_interactive=True,
        apps=apps,
        full=full,
        gui=False,
        no_shell_rc=False,
        clean=True,
        console=console,
    )
    _sys.exit(rc)


cli.add_command(_doctor_cmd_impl)


@cli.command(name="_apply-user-env", hidden=True)
def _apply_user_env_cmd() -> None:
    """Internal: re-apply launchctl user-domain env vars at login.

    v0.1.19 Task 0.1: invoked by ``com.haltonlabs.meter.userenv.plist``
    at every login so ``--apps`` / ``--full`` mode survives reboot
    (macOS clears the launchctl user-domain env on logout). Hidden from
    ``--help`` because end users should never run it directly.

    Behaviour:

    * Reads install-mode sentinel; no-ops in env-only mode (defensive —
      the userenv plist should not exist in env-only mode, but if a
      prior install left one behind we don't want to clobber the env).
    * Loads effective ports via ``port_alloc.load_effective_config``.
    * Builds env vars via ``init.build_env_vars`` (single source of
      truth — same shape as ``init --apps``).
    * Calls ``system_proxy.setenv_user_domain``.
    * Logs result counts to ``daemon.log`` via structlog.

    Exit code is 0 even on partial setenv failures: this runs at login
    and must never block the user's session start. Per-key launchctl
    failures are logged for ``halton-meter doctor`` to surface later.
    Exits 1 only on catastrophic failure (e.g. config unreadable).
    """
    import sys as _sys

    import structlog

    log = structlog.get_logger()

    try:
        from halton_meter import system_proxy
        from halton_meter.init import (
            MODE_APPS,
            MODE_FULL,
            build_env_vars,
            read_install_mode,
        )
        from halton_meter.port_alloc import load_effective_config
        from halton_meter.setup import _certifi_bundle_path
    except Exception as exc:
        # Import-time catastrophe — log to stderr (structlog may not be
        # configured yet) and exit 1. This should never happen in a
        # working install but we surface it loudly if it does.
        print(
            f"[halton-meter _apply-user-env] import failed: {exc}",
            file=_sys.stderr,
        )
        _sys.exit(1)

    try:
        mode = read_install_mode()
    except Exception as exc:
        log.error("userenv.read_mode_failed", error=str(exc), exc_info=True)
        _sys.exit(1)

    if mode not in (MODE_APPS, MODE_FULL):
        # Defensive: the plist should not be installed in env-only mode.
        # If it is, log + exit clean rather than overwriting the user's
        # launchctl env.
        log.info("userenv.skipped_wrong_mode", mode=mode)
        _sys.exit(0)

    try:
        cfg = load_effective_config()
    except Exception as exc:
        log.error("userenv.load_config_failed", error=str(exc), exc_info=True)
        _sys.exit(1)

    try:
        env_vars = build_env_vars(
            cfg.daemon.listen_host,
            cfg.daemon.edge_port,
            _certifi_bundle_path(),
        )
    except Exception as exc:
        log.error("userenv.build_env_failed", error=str(exc), exc_info=True)
        _sys.exit(1)

    try:
        rcs = system_proxy.setenv_user_domain(env_vars)
    except Exception as exc:
        # Never raise out of a login-time agent. Log + exit 0 so the
        # user's session continues; doctor will surface the failure.
        log.error("userenv.setenv_raised", error=str(exc), exc_info=True)
        _sys.exit(0)

    failures = {k: rc for k, rc in rcs.items() if rc != 0}
    if failures:
        log.warning(
            "userenv.partial_failure",
            mode=mode,
            keys_total=len(rcs),
            keys_failed=len(failures),
            rcs=failures,
        )
    else:
        log.info(
            "userenv.applied",
            mode=mode,
            keys_total=len(rcs),
            edge_port=int(cfg.daemon.edge_port),
        )
    _sys.exit(0)


@cli.command(
    name="run",
    context_settings={"ignore_unknown_options": True, "allow_interspersed_args": False},
)
@click.argument("cmd", nargs=-1, type=click.UNPROCESSED)
@click.option(
    "--shell",
    "use_shell",
    is_flag=True,
    default=False,
    help="Spawn the user's $SHELL with the metering env vars set "
    "(interactive subshell mode).",
)
@click.option(
    "--preflight-timeout",
    type=float,
    default=3.0,
    show_default=True,
    help="Seconds to wait for the daemon's /health endpoint before refusing.",
)
def run_cmd(cmd: tuple[str, ...], use_shell: bool, preflight_timeout: float) -> None:
    """Run an arbitrary command with the proxy + cert env vars set so it
    is metered through the local daemon.

    Examples:

      halton-meter run claude                  # meter Claude Code
      halton-meter run -- python my_script.py  # arbitrary command
      halton-meter run --shell                 # interactive subshell
    """
    import sys as _sys

    from halton_meter.run import run_cmd as _run

    rc = _run(cmd, use_shell=use_shell, preflight_timeout=preflight_timeout)
    # os.execvpe replaces this process on success; only refusal paths
    # return — _sys.exit propagates them cleanly.
    _sys.exit(rc)


@cli.command(name="init")
@click.option(
    "--non-interactive",
    is_flag=True,
    default=False,
    help="Skip the live-daemon prompt; assume yes. For CI / scripted installs.",
)
@click.option(
    "--apps",
    "apps",
    is_flag=True,
    default=False,
    help=(
        "v0.1.5 (2B.16): cert + plists + launchctl setenv user-domain + "
        "shell-rc append. NO system proxy. Covers Spotlight/Dock-spawned "
        "apps + new shells. Cannot break HSTS browsing because the "
        "system proxy is never flipped."
    ),
)
@click.option(
    "--full",
    "full",
    is_flag=True,
    default=False,
    help=(
        "Opt in to system-proxy + launchctl env + shell-rc mode. Broadest "
        "coverage — browsers, GUI apps, terminals. May break HSTS browser "
        "sites if the cert isn't trusted by SecTrust. Replaces the "
        "v0.1.3/v0.1.4 --gui flag."
    ),
)
@click.option(
    "--gui",
    "gui",
    is_flag=True,
    default=False,
    hidden=True,
    help="Deprecated alias for --full (kept for v0.1.3/v0.1.4 back-compat).",
)
@click.option(
    "--no-shell-rc",
    "no_shell_rc",
    is_flag=True,
    default=False,
    help=(
        "Skip the shell rc append step in --apps / --full modes. "
        "(No effect in env-var-only mode — that mode never edits shell rc.)"
    ),
)
@click.option(
    "--clean",
    "clean",
    is_flag=True,
    default=False,
    help=(
        "v0.1.19.dev1: opt in to destructive rollback when the post-install "
        "self-test fails on a live install. Default behaviour now repairs "
        "in place (re-probes ports, re-applies env, kickstarts the daemon, "
        "re-runs self-test); use --clean to force the v0.1.5 behaviour of "
        "tearing down every supervisor and rebuilding from scratch."
    ),
)
def init_cmd(
    non_interactive: bool,
    apps: bool,
    full: bool,
    gui: bool,
    no_shell_rc: bool,
    clean: bool,
) -> None:
    """First-run setup. Three modes:

      * default (no flag): env-var-only. Safest. Use ``halton-meter run``
        to meter a CLI / SDK client.
      * ``--apps``: env vars set system-wide for terminals + Spotlight-
        spawned apps. NO system proxy.
      * ``--full``: env vars + system proxy. Broadest coverage; may
        break HSTS browser sites if cert isn't trusted by SecTrust.
    """
    if sum(1 for f in (apps, full, gui) if f) > 1:
        click.echo(
            "Error: pass at most one of --apps / --full "
            "(--gui is a deprecated alias for --full).",
            err=True,
        )
        raise click.exceptions.Exit(2)

    import sys as _sys

    from halton_meter.init import init as init_fn

    _sys.exit(
        init_fn(
            non_interactive=non_interactive,
            apps=apps,
            full=full,
            gui=gui,
            no_shell_rc=no_shell_rc,
            clean=clean,
            console=console,
        )
    )


@cli.command(name="onboard")
@click.option(
    "--non-interactive",
    is_flag=True,
    default=False,
    help="Skip the live-daemon prompt; assume yes. For CI / scripted installs.",
)
@click.option(
    "--full",
    "full",
    is_flag=True,
    default=False,
    help=(
        "Promote to system-proxy mode (equivalent to `init --full`). "
        "Default onboard mode is `init --apps` — covers Claude Code, "
        "Codex, Gemini CLI + Spotlight/Dock-spawned apps without "
        "touching the system proxy."
    ),
)
@click.option(
    "--no-shell-rc",
    "no_shell_rc",
    is_flag=True,
    default=False,
    help="Skip the shell rc append step.",
)
@click.option(
    "--clean",
    "clean",
    is_flag=True,
    default=False,
    help=(
        "Opt in to destructive rollback if the post-install self-test "
        "fails on a live install. Default behaviour repairs in place."
    ),
)
def onboard_cmd(
    non_interactive: bool,
    full: bool,
    no_shell_rc: bool,
    clean: bool,
) -> None:
    """Set up your first meter (alias for `init --apps`)."""
    import sys as _sys

    from halton_meter.init import init as init_fn

    # Friendly default: --apps mode unless caller opts into --full.
    apps = not full

    _sys.exit(
        init_fn(
            non_interactive=non_interactive,
            apps=apps,
            full=full,
            gui=False,
            no_shell_rc=no_shell_rc,
            clean=clean,
            console=console,
        )
    )


@cli.command()
@click.option(
    "--check",
    "check_only",
    is_flag=True,
    default=False,
    help="Print current state of each setup step without modifying anything.",
)
@click.option(
    "--force",
    is_flag=True,
    default=False,
    help="Re-run all steps even if already done.",
)
def setup(check_only: bool, force: bool) -> None:
    """One-time setup: generate CA cert, trust in keychain, patch certifi."""
    from halton_meter.setup import check_steps, render_result, run_setup

    if check_only:
        result = check_steps()
    else:
        result = run_setup(force=force, console=console)

    render_result(result, console)


# --------------------------------------------------------------------------- #
# v0.1.9 Gap 12 — `halton-meter retag`                                        #
# --------------------------------------------------------------------------- #


@cli.command(name="retag")
@click.option(
    "--from",
    "from_slug",
    default=None,
    help=(
        "Source project slug to rewrite. Defaults to '.halton-meter' — "
        "the canonical bug name from the v0.1.8 Gap 6 fix."
    ),
)
@click.option(
    "--to",
    "to_slug",
    default=None,
    help="Destination project slug. Defaults to 'unattributed'.",
)
@click.option(
    "--apply",
    "apply_change",
    is_flag=True,
    default=False,
    help="Actually rewrite rows. Without this flag the command is dry-run.",
)
@click.option(
    "--db",
    "db_path",
    default=None,
    type=click.Path(),
    help="Path to db.sqlite. Defaults to ~/.halton-meter/db.sqlite.",
)
@click.option(
    "--force",
    is_flag=True,
    default=False,
    help=(
        "Skip the live-daemon guard. The daemon may write fresh rows "
        "concurrently; counts may shift."
    ),
)
def retag_cmd(
    from_slug: str | None,
    to_slug: str | None,
    apply_change: bool,
    db_path: str | None,
    force: bool,
) -> None:
    """Rewrite historical request rows from one project slug to another.

    Common case: fix the v0.1.7/v0.1.8 ``.halton-meter`` rows.

    \b
    Examples:
      halton-meter retag                       # dry-run: '.halton-meter' -> 'unattributed'
      halton-meter retag --apply               # apply the rename
      halton-meter retag --from foo --to bar --apply
    """
    import sys as _sys
    from pathlib import Path as _Path

    from halton_meter.retag import (
        DEFAULT_DB_PATH,
        DEFAULT_FROM_SLUG,
        DEFAULT_TO_SLUG,
        RetagError,
        daemon_health_ok,
        retag_project,
    )

    from_eff = from_slug or DEFAULT_FROM_SLUG
    to_eff = to_slug or DEFAULT_TO_SLUG
    db_eff = _Path(db_path).expanduser() if db_path else DEFAULT_DB_PATH

    # Live-daemon guard (skippable with --force). We probe /health on
    # the configured api host:port; if the daemon is up, refuse.
    if not force and apply_change:
        try:
            cfg = load_config()
            if daemon_health_ok(cfg.daemon.api_host, cfg.daemon.api_port):
                console.print(
                    "[yellow]halton-meter daemon is running.[/yellow] "
                    "Stop it first for a clean retag: "
                    "[bold]halton-meter stop[/bold] "
                    "(then `halton-meter start` again afterwards). "
                    "Pass [bold]--force[/bold] to override."
                )
                _sys.exit(2)
        except Exception:
            # Config load failure is fine — the user may not have a
            # config.toml; fall through and proceed.
            pass

    try:
        plan = retag_project(
            db_path=db_eff,
            from_slug=from_eff,
            to_slug=to_eff,
            apply=apply_change,
        )
    except RetagError as exc:
        console.print(f"[red]retag refused:[/red] {exc}")
        _sys.exit(2)

    if not plan.from_project_existed:
        console.print(
            f"[bright_black]No project with slug '{plan.from_slug}' found in "
            f"{db_eff}; nothing to retag.[/bright_black]"
        )
        _sys.exit(0)

    if plan.applied:
        console.print(
            f"[green]Retagged {plan.rows_updated:,} rows[/green] "
            f"from '{plan.from_slug}' to '{plan.to_slug}'."
        )
        if plan.to_project_created:
            console.print(
                f"  Created project row for '{plan.to_slug}'."
            )
        if plan.from_project_deleted:
            console.print(
                f"  Removed empty source project row '{plan.from_slug}'."
            )
    else:
        console.print(
            f"[bold]Dry-run:[/bold] would retag {plan.rows_matched:,} rows "
            f"from '{plan.from_slug}' to '{plan.to_slug}'."
        )
        if plan.to_project_created:
            console.print(
                f"  Would create project row for '{plan.to_slug}'."
            )
        console.print(
            "  Re-run with [bold]--apply[/bold] to execute. "
            "Tip: stop halton-meter first (`halton-meter stop`) for a "
            "clean retag."
        )
    _sys.exit(0)


# --------------------------------------------------------------------------- #
# v0.1.12 — `halton-meter recompute-costs`                                    #
# --------------------------------------------------------------------------- #


@cli.command(name="recompute-costs")
@click.option(
    "--db",
    "db_path",
    default=None,
    help="Path to SQLite database. Defaults to ~/.halton-meter/logs.db.",
)
@click.option(
    "--dry-run",
    is_flag=True,
    default=False,
    help="Show what would change without writing to the database.",
)
def recompute_costs_cmd(db_path: str | None, dry_run: bool) -> None:
    """Recompute stored costs for all captured requests using current rates.

    Fixes historical rows where model rates have changed - for example the
    Opus 4.1 3x undercount in v0.1.5-v0.1.10 ($5/$25 stored vs the correct
    $15/$75), and retroactively applies the Gemini >200k tier surcharge to
    rows whose input_tokens exceeded 200 000 tokens.

    Safe to run while the daemon is running, but for best results stop it
    first (`halton-meter stop`) to avoid write contention.

    Idempotent: running twice is safe; the second pass updates zero rows.
    """
    import sys as _sys
    from pathlib import Path as _Path

    from rich.table import Table

    from halton_meter.recompute_costs import RecomputeResult, format_usd, recompute_costs

    # Resolve DB path — same pattern as `retag` command.
    if db_path is not None:
        db_eff = _Path(db_path)
    else:
        db_eff = _Path("~/.halton-meter/logs.db").expanduser()
        try:
            cfg = load_config()
            if cfg.storage.db_path:
                db_eff = _Path(cfg.storage.db_path).expanduser()
        except Exception:
            # Config load failure is fine — the user may not have a
            # config.toml; fall through and use the default path.
            pass

    if not db_eff.exists():
        console.print(f"[red]Database not found:[/red] {db_eff}")
        _sys.exit(2)

    try:
        result: RecomputeResult = recompute_costs(db_path=db_eff, dry_run=dry_run)
    except Exception as exc:
        console.print(f"[red]recompute-costs failed:[/red] {exc}")
        _sys.exit(1)

    if result.rows_updated == 0:
        console.print("[green]Nothing to update — all costs are current.[/green]")
        console.print(f"  Scanned {result.rows_scanned:,} rows.")
        _sys.exit(0)

    table = Table(title="Cost recomputation summary")
    table.add_column("Metric", style="bold")
    table.add_column("Value", justify="right")
    table.add_row("Rows scanned", f"{result.rows_scanned:,}")
    action = "Would update" if dry_run else "Rows updated"
    table.add_row(action, f"{result.rows_updated:,}")
    table.add_row("Old total (changed rows)", format_usd(result.old_total_millicents))
    table.add_row("New total (changed rows)", format_usd(result.new_total_millicents))
    console.print(table)

    if dry_run:
        console.print(
            "[bright_black]Dry run — no changes written. "
            "Re-run without --dry-run to apply.[/bright_black]"
        )

    _sys.exit(0)


# --------------------------------------------------------------------------- #
# v0.1.13 — `halton-meter bodies …` and `halton-meter project … set …`        #
# --------------------------------------------------------------------------- #


def _format_bytes(n: int) -> str:
    """Render a byte count for human consumption.

    Picks the largest unit at which the value is >= 1, two-decimal
    formatted. Display-only — never round-tripped back into storage.
    """
    if n < 1024:
        return f"{n:,} B"
    units = ("KB", "MB", "GB", "TB")
    value = float(n) / 1024.0
    unit_idx = 0
    while value >= 1024.0 and unit_idx < len(units) - 1:
        value /= 1024.0
        unit_idx += 1
    return f"{value:,.2f} {units[unit_idx]}"


def _resolve_db_path(db_path: str | None) -> Path:
    """Resolve the SQLite path: --db flag → config → default."""
    if db_path is not None:
        return Path(db_path).expanduser()
    try:
        cfg = load_config()
        if cfg.storage.db_path:
            return Path(cfg.storage.db_path).expanduser()
    except Exception:
        pass
    return Path("~/.halton-meter/db.sqlite").expanduser()


def _fetch_request_header(db_path: Path, request_id: str) -> dict[str, str | None]:
    """Look up provider/model/project_slug for a request id.

    Used by ``halton-meter bodies show`` to give the operator at-a-glance
    context without forcing a separate ``halton-meter report`` cross-ref.
    Returns an empty dict's worth of None values when the row is absent
    or the DB hasn't migrated. Read-only; never raises.
    """
    import sqlite3 as _sq3

    out: dict[str, str | None] = {
        "provider": None,
        "model": None,
        "project_slug": None,
    }
    if not db_path.exists():
        return out
    try:
        conn = _sq3.connect(str(db_path))
        try:
            conn.row_factory = _sq3.Row
            cur = conn.execute(
                "SELECT r.provider AS provider, "
                "       r.model AS model, "
                "       p.slug AS project_slug "
                "FROM requests r "
                "LEFT JOIN projects p ON p.id = r.project_id "
                "WHERE r.id = ?",
                (request_id,),
            )
            row = cur.fetchone()
            if row is not None:
                out["provider"] = row["provider"]
                out["model"] = row["model"]
                out["project_slug"] = row["project_slug"]
        finally:
            conn.close()
    except Exception:
        pass
    return out


def _format_redaction_badges(body: object) -> str:
    """Build a single-line rich-markup badge string for a body row.

    Surfaces the redaction categories that fired (one badge each), plus
    truncation badges per side, plus a streaming-incomplete badge. Empty
    string when nothing notable fired so the caller can skip the line.
    """
    import json as _json

    parts: list[str] = []

    # Redaction categories — parse the JSON map written at capture time.
    raw_summary = getattr(body, "redaction_summary", None)
    if raw_summary:
        try:
            payload = _json.loads(raw_summary)
            if isinstance(payload, dict):
                for category, count in sorted(payload.items()):
                    if not isinstance(category, str):
                        continue
                    label = (
                        f"{category} x{int(count)}"
                        if isinstance(count, int) and count > 1
                        else category
                    )
                    parts.append(f"[red]●[/red] redacted: {label}")
        except (ValueError, TypeError):
            # Malformed JSON — surface a single generic badge so the
            # operator knows redaction was logged, even if we can't
            # break it down. Defensive; the writer should always emit
            # well-formed JSON.
            parts.append("[red]●[/red] redaction summary: <unparseable>")
    elif getattr(body, "redaction_applied", False):
        parts.append("[red]●[/red] redaction applied")

    if getattr(body, "request_truncated", False):
        parts.append("[yellow]▲[/yellow] request truncated")
    if getattr(body, "response_truncated", False):
        parts.append("[yellow]▲[/yellow] response truncated")
    if getattr(body, "streaming_incomplete", False):
        parts.append("[yellow]▲[/yellow] streaming incomplete")

    return "  ".join(parts)


@cli.group(name="bodies")
def bodies_group() -> None:
    """Inspect, summarise, and purge captured request/response bodies.

    Bodies are captured per-request alongside the existing counts/cost
    rows when body capture is enabled (master switch
    ``HaltonConfig.bodies.enabled`` AND per-project ``project_settings``).
    Default ON.
    """


@bodies_group.command(name="show")
@click.argument("request_id")
@click.option(
    "--db",
    "db_path",
    default=None,
    type=click.Path(),
    help="Path to db.sqlite. Defaults to ~/.halton-meter/db.sqlite.",
)
@click.option(
    "--format",
    "output_format",
    type=click.Choice(["text", "json"]),
    default="text",
    help="Output format. ``json`` is convenient for piping.",
)
@click.option(
    "--raw",
    is_flag=True,
    default=False,
    help="Print the request and response bodies verbatim (post-redaction, "
    "post-truncation), one after the other. Useful for confirming "
    "redaction without rich formatting in the way.",
)
def bodies_show_cmd(
    request_id: str,
    db_path: str | None,
    output_format: str,
    raw: bool,
) -> None:
    """Show the captured bodies for a single request id."""
    import json as _j
    import sys as _sys

    from halton_meter.bodies import fetch_body

    db_eff = _resolve_db_path(db_path)
    body = fetch_body(db_eff, request_id)
    if body is None:
        if output_format == "json":
            _sys.stdout.write(_j.dumps({"request_id": request_id, "found": False}))
            _sys.stdout.write("\n")
        else:
            console.print(
                f"[bright_black]No body captured for request "
                f"{request_id}.[/bright_black] "
                "Reasons: pre-feature row, project opted out, or capture failed."
            )
        _sys.exit(0)

    if raw:
        if body.request_body is not None:
            _sys.stdout.write("--- request_body ---\n")
            _sys.stdout.write(body.request_body)
            _sys.stdout.write("\n")
        if body.response_body is not None:
            _sys.stdout.write("--- response_body ---\n")
            _sys.stdout.write(body.response_body)
            _sys.stdout.write("\n")
        return

    if output_format == "json":
        payload = {
            "request_id": body.request_id,
            "found": True,
            "request_body": body.request_body,
            "response_body": body.response_body,
            "request_body_bytes": body.request_body_bytes,
            "response_body_bytes": body.response_body_bytes,
            "request_content_type": body.request_content_type,
            "response_content_type": body.response_content_type,
            "request_truncated": body.request_truncated,
            "response_truncated": body.response_truncated,
            "streaming_incomplete": body.streaming_incomplete,
            "redaction_applied": body.redaction_applied,
            "capture_error": body.capture_error,
            "redaction_summary": body.redaction_summary,
            "captured_at": body.captured_at,
        }
        _sys.stdout.write(_j.dumps(payload, indent=2))
        _sys.stdout.write("\n")
        return

    # Pretty (rich) panelled output (v0.1.13 PR3).
    #
    # Layout:
    #   1. Header panel: provider / model / project / captured_at, looked
    #      up from the joined ``requests`` row when available so the
    #      operator doesn't need to cross-reference a separate report.
    #   2. Redaction-badge line: one badge per category that fired, plus
    #      a TRUNCATED badge per side, plus a streaming-incomplete badge
    #      when relevant. Hidden when nothing fired.
    #   3. Request body panel.
    #   4. Response body panel.
    #
    # Long bodies (> 4 KB) are clipped in the panel with a tail marker;
    # use --raw or --format json to get the full content. The panel is
    # for at-a-glance auditing, not bulk inspection.
    from rich.panel import Panel
    from rich.table import Table
    from rich.text import Text

    header_meta = _fetch_request_header(db_eff, body.request_id)

    header = Table(show_header=False, box=None, pad_edge=False)
    header.add_column("k", style="bold")
    header.add_column("v")
    header.add_row("Request id", body.request_id)
    header.add_row("Provider", header_meta.get("provider") or "-")
    header.add_row("Model", header_meta.get("model") or "-")
    header.add_row("Project", header_meta.get("project_slug") or "-")
    header.add_row("Captured at", body.captured_at or "-")
    header.add_row("Request content-type", body.request_content_type or "-")
    header.add_row("Response content-type", body.response_content_type or "-")
    if body.capture_error:
        header.add_row("Capture error", body.capture_error)
    console.print(Panel(header, title="Captured body", border_style="cyan"))

    badges = _format_redaction_badges(body)
    if badges:
        console.print(badges)

    _PANEL_PREVIEW_BYTES = 4096

    def _maybe_clip(s: str | None) -> Text:
        if s is None:
            return Text("(no body captured)", style="bright_black")
        if len(s) > _PANEL_PREVIEW_BYTES:
            head = s[:_PANEL_PREVIEW_BYTES]
            tail_note = (
                f"\n... [{len(s) - _PANEL_PREVIEW_BYTES:,} more chars; "
                "use --raw or --format json for full body]"
            )
            t = Text(head)
            t.append(tail_note, style="bright_black")
            return t
        return Text(s)

    req_subtitle = (
        f"{len(body.request_body or ''):,} chars stored "
        f"(orig {body.request_body_bytes:,} bytes)"
        + ("  [yellow]TRUNCATED[/yellow]" if body.request_truncated else "")
    )
    console.print(
        Panel(
            _maybe_clip(body.request_body),
            title="Request body",
            subtitle=req_subtitle,
            border_style="green",
        )
    )

    rsp_subtitle = (
        f"{len(body.response_body or ''):,} chars stored "
        f"(orig {body.response_body_bytes:,} bytes)"
        + ("  [yellow]TRUNCATED[/yellow]" if body.response_truncated else "")
    )
    console.print(
        Panel(
            _maybe_clip(body.response_body),
            title="Response body",
            subtitle=rsp_subtitle,
            border_style="magenta",
        )
    )


@bodies_group.command(name="stats")
@click.option(
    "--db",
    "db_path",
    default=None,
    type=click.Path(),
    help="Path to db.sqlite. Defaults to ~/.halton-meter/db.sqlite.",
)
@click.option(
    "--format",
    "output_format",
    type=click.Choice(["text", "json"]),
    default="text",
    help="Output format. ``json`` is convenient for piping.",
)
def bodies_stats_cmd(db_path: str | None, output_format: str) -> None:
    """Summarise captured-body storage. Useful for the operator demo."""
    import json as _j
    import sys as _sys

    from halton_meter.bodies import fetch_stats

    db_eff = _resolve_db_path(db_path)
    stats = fetch_stats(db_eff)

    # Resolve retention horizon for display. Defaults match BodiesConfig.
    try:
        retention_days = int(load_config().bodies.retention_days)
    except Exception:
        retention_days = 90

    if output_format == "json":
        _sys.stdout.write(
            _j.dumps(
                {
                    "row_count": stats.row_count,
                    "total_captured_bytes": stats.total_captured_bytes,
                    "oldest_captured_at": stats.oldest_captured_at,
                    "newest_captured_at": stats.newest_captured_at,
                    "truncated_request_count": stats.truncated_request_count,
                    "truncated_response_count": stats.truncated_response_count,
                    "capture_error_count": stats.capture_error_count,
                    "redaction_summary_totals": stats.redaction_summary_totals,
                    "redaction_applied_count": stats.redaction_applied_count,
                    "redaction_applied_pct": stats.redaction_applied_pct,
                    "retention_days": retention_days,
                    "per_project": [
                        {
                            "project_slug": p.project_slug,
                            "row_count": p.row_count,
                            "total_captured_bytes": p.total_captured_bytes,
                            "redaction_applied_count": p.redaction_applied_count,
                        }
                        for p in stats.per_project
                    ],
                },
                indent=2,
            )
        )
        _sys.stdout.write("\n")
        return

    from rich.table import Table

    if stats.row_count == 0:
        console.print(
            "[bright_black]No body rows captured yet.[/bright_black] "
            "(Either body capture is disabled, or no metered traffic has "
            "flowed through the proxy since the feature was enabled.)"
        )
        return

    table = Table(title="Body capture stats")
    table.add_column("Metric", style="bold")
    table.add_column("Value", justify="right")
    table.add_row("Body rows", f"{stats.row_count:,}")
    table.add_row(
        "Total captured (bytes, original sizes)",
        _format_bytes(stats.total_captured_bytes),
    )
    table.add_row("Oldest captured_at", stats.oldest_captured_at or "-")
    table.add_row("Newest captured_at", stats.newest_captured_at or "-")
    table.add_row("Truncated requests", f"{stats.truncated_request_count:,}")
    table.add_row("Truncated responses", f"{stats.truncated_response_count:,}")
    table.add_row("Capture errors", f"{stats.capture_error_count:,}")
    table.add_row(
        "Redaction applied",
        f"{stats.redaction_applied_count:,} rows "
        f"({stats.redaction_applied_pct:.1f}%)",
    )
    table.add_row(
        "Retention horizon",
        f"{retention_days} days "
        f"(daily background sweep when daemon is running)",
    )
    console.print(table)

    if stats.per_project:
        pt = Table(title="Per-project breakdown")
        pt.add_column("Project", style="bold")
        pt.add_column("Body rows", justify="right")
        pt.add_column("Total bytes", justify="right")
        pt.add_column("Redaction applied", justify="right")
        for p in stats.per_project:
            pct = (
                100.0 * p.redaction_applied_count / p.row_count
                if p.row_count
                else 0.0
            )
            pt.add_row(
                p.project_slug,
                f"{p.row_count:,}",
                _format_bytes(p.total_captured_bytes),
                f"{p.redaction_applied_count:,} ({pct:.1f}%)",
            )
        console.print(pt)

    if stats.redaction_summary_totals:
        rt = Table(title="Redactions by category")
        rt.add_column("Category", style="bold")
        rt.add_column("Total", justify="right")
        for cat, count in sorted(
            stats.redaction_summary_totals.items(), key=lambda kv: -kv[1]
        ):
            rt.add_row(cat, f"{count:,}")
        console.print(rt)


@bodies_group.command(name="purge")
@click.option(
    "--older-than",
    "older_than",
    default=None,
    help="Cutoff age. Examples: '30d', '12h', '45m'. Plain integers mean "
    "days. Defaults to HaltonConfig.bodies.retention_days (90 days).",
)
@click.option(
    "--vacuum",
    is_flag=True,
    default=False,
    help="Run VACUUM after deleting. Reclaims disk but BLOCKS THE SQLITE "
    "FILE while it runs — opt-in. Skip on large DBs unless disk pressure "
    "is real.",
)
@click.option(
    "--dry-run",
    is_flag=True,
    default=False,
    help="Print the count of rows that would be deleted without "
    "deleting them.",
)
@click.option(
    "--db",
    "db_path",
    default=None,
    type=click.Path(),
    help="Path to db.sqlite. Defaults to ~/.halton-meter/db.sqlite.",
)
def bodies_purge_cmd(
    older_than: str | None,
    vacuum: bool,
    dry_run: bool,
    db_path: str | None,
) -> None:
    """Delete body rows older than the given age. Counts rows are untouched."""
    import sys as _sys

    from halton_meter.bodies import parse_duration, purge_old_bodies

    db_eff = _resolve_db_path(db_path)

    # Resolve --older-than: explicit value > config retention_days > 90 days.
    if older_than is not None:
        try:
            cutoff_age = parse_duration(older_than)
        except ValueError as exc:
            console.print(f"[red]invalid --older-than:[/red] {exc}")
            _sys.exit(2)
    else:
        try:
            cfg = load_config()
            days = int(cfg.bodies.retention_days)
        except Exception:
            days = 90
        from datetime import timedelta

        cutoff_age = timedelta(days=days)

    result = purge_old_bodies(
        db_eff,
        older_than=cutoff_age,
        dry_run=dry_run,
        vacuum=vacuum,
    )

    if result.dry_run:
        console.print(
            f"[bold]Dry-run:[/bold] would delete {result.rows_deleted:,} body "
            f"rows older than {result.cutoff.isoformat()}."
        )
        return

    if result.rows_deleted == 0:
        console.print(
            f"[green]Nothing to purge — no body rows older than "
            f"{result.cutoff.isoformat()}.[/green]"
        )
        return

    msg = f"[green]Deleted {result.rows_deleted:,} body rows[/green]"
    if result.vacuumed:
        msg += " and ran VACUUM"
    msg += f" (older than {result.cutoff.isoformat()})."
    console.print(msg)


@cli.group(name="project")
def project_group() -> None:
    """Per-project settings (body capture toggle, etc.)."""


@project_group.command(name="show")
@click.argument("slug")
@click.option(
    "--db",
    "db_path",
    default=None,
    type=click.Path(),
    help="Path to db.sqlite. Defaults to ~/.halton-meter/db.sqlite.",
)
def project_show_cmd(slug: str, db_path: str | None) -> None:
    """Print the current settings for a project."""
    import sys as _sys

    from halton_meter.project_settings_cli import fetch_settings

    db_eff = _resolve_db_path(db_path)
    settings = fetch_settings(db_eff, slug)
    if settings is None:
        console.print(
            f"[bright_black]No project with slug "
            f"'{slug}'.[/bright_black] "
            "(A row will be auto-created on the project's first capture.)"
        )
        _sys.exit(0)

    from rich.table import Table

    table = Table(title=f"Project settings — {settings.project_slug}")
    table.add_column("Field", style="bold")
    table.add_column("Value")
    table.add_row("project_id", settings.project_id)
    table.add_row("slug", settings.project_slug)
    suffix = "" if settings.updated_at else "  (default)"
    table.add_row(
        "body_capture_enabled",
        ("on" if settings.body_capture_enabled else "off") + suffix,
    )
    table.add_row("updated_at", settings.updated_at or "-")
    console.print(table)


@project_group.command(name="set")
@click.argument("slug")
@click.argument("setting")
@click.argument("value")
@click.option(
    "--db",
    "db_path",
    default=None,
    type=click.Path(),
    help="Path to db.sqlite. Defaults to ~/.halton-meter/db.sqlite.",
)
def project_set_cmd(
    slug: str, setting: str, value: str, db_path: str | None
) -> None:
    """Set a project setting.

    Currently the only supported setting is ``body-capture`` with values
    ``on`` / ``off``. Auto-creates the project row if absent.
    """
    import sys as _sys

    from halton_meter.project_settings_cli import set_body_capture

    if setting != "body-capture":
        console.print(
            f"[red]Unknown setting '{setting}'.[/red] "
            "Supported: body-capture."
        )
        _sys.exit(2)

    v = value.strip().lower()
    if v not in {"on", "off"}:
        console.print(
            f"[red]Invalid value '{value}'.[/red] "
            "Use 'on' or 'off'."
        )
        _sys.exit(2)
    enabled = v == "on"

    db_eff = _resolve_db_path(db_path)
    result = set_body_capture(db_eff, slug, enabled=enabled)

    state = "on" if enabled else "off"
    if result.previous_value is None:
        msg = f"[green]Set body-capture for '{result.project_slug}' to {state}.[/green]"
    elif result.previous_value == enabled:
        msg = (
            f"[bright_black]body-capture for '{result.project_slug}' is "
            f"already {state}; no change.[/bright_black]"
        )
    else:
        prev_state = "on" if result.previous_value else "off"
        msg = (
            f"[green]body-capture for '{result.project_slug}' "
            f"flipped {prev_state} -> {state}.[/green]"
        )
    if result.project_created:
        msg += f"  (Created project row for '{result.project_slug}'.)"
    console.print(msg)
    console.print(
        "[bright_black]The running daemon (if any) picks up this change "
        "within ~5 minutes (HaltonConfig.bodies.cache_ttl_seconds).[/bright_black]"
    )
