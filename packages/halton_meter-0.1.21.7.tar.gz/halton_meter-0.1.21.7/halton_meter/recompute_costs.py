"""
v0.1.12 — ``halton-meter recompute-costs`` one-shot CLI logic.

Recomputes ``cost_usd_minor_units`` for every captured request row using
the current bundled pricing matrix (``compute_cost_millicents``). Designed
to fix two categories of historical undercount:

1. **Opus 4.1 3x undercount (v0.1.5 → v0.1.10)**: rows captured before
   the v0.1.11 fix was deployed were stored at $5/$25 (the wrong rate);
   the correct Anthropic-published rate is $15/$75.

2. **Gemini >200k tier** (v0.1.12): rows captured before the tiered
   resolver landed were stored at the lower-tier (≤200k) rate regardless
   of input_tokens. This pass retroactively applies the high-context rate
   to rows where input_tokens > 200_000.

The operation is **idempotent**: it compares each stored cost against what
``compute_cost_millicents`` returns today. Rows that already match are
skipped. Running twice in a row updates zero rows on the second pass.

Uses stdlib ``sqlite3`` only — no SQLAlchemy. Mirrors the isolation
pattern in ``retag.py``: ``BEGIN IMMEDIATE`` + explicit COMMIT/ROLLBACK
so we play nicely with a running daemon (WAL mode).

Schema invariant relied upon:
  requests(id, model, input_tokens, output_tokens, thinking_tokens,
           cache_read_tokens, cache_write_tokens, cost_usd_minor_units)
"""

from __future__ import annotations

import sqlite3
from dataclasses import dataclass
from pathlib import Path

import structlog

from halton_meter.pricing import compute_cost_millicents

log = structlog.get_logger()


@dataclass(frozen=True)
class RecomputeResult:
    """Summary returned by :func:`recompute_costs`."""

    rows_scanned: int
    """Total rows read from the requests table (where cost IS NOT NULL)."""

    rows_updated: int
    """Rows whose stored cost differed from the current matrix value.
    If ``dry_run=True``, no writes occurred but this count still reflects
    how many *would* have been updated.
    """

    old_total_millicents: int
    """Sum of the original ``cost_usd_minor_units`` values for the rows
    that were (or would be) updated. Zero if ``rows_updated == 0``."""

    new_total_millicents: int
    """Sum of the recomputed costs for those same rows.
    Zero if ``rows_updated == 0``."""


def recompute_costs(db_path: Path, dry_run: bool = False) -> RecomputeResult:
    """Recompute stored costs for all captured requests using current rates.

    Args:
        db_path: Path to the SQLite database (e.g. ~/.halton-meter/logs.db).
        dry_run: If True, identify rows that need updating but do not write.
                 The returned ``RecomputeResult.rows_updated`` still reflects
                 the count of rows that *would* be changed.

    Returns:
        :class:`RecomputeResult` summarising the operation.

    Raises:
        sqlite3.Error: If the database cannot be opened or the transaction
            fails (after a ROLLBACK attempt).
    """
    conn = sqlite3.connect(str(db_path), timeout=10.0)
    try:
        # Match the daemon's pragmas for WAL-mode compatibility.
        conn.execute("PRAGMA foreign_keys = ON")
        conn.execute("PRAGMA busy_timeout = 5000")
        conn.execute("BEGIN IMMEDIATE")
        try:
            rows = conn.execute(
                "SELECT id, model, input_tokens, output_tokens, "
                "thinking_tokens, cache_read_tokens, cache_write_tokens, "
                "cost_usd_minor_units "
                "FROM requests "
                "WHERE cost_usd_minor_units IS NOT NULL"
            ).fetchall()

            updates: list[tuple[int, str]] = []  # (new_cost, id)
            old_total: int = 0
            new_total: int = 0

            for row in rows:
                (
                    row_id,
                    model,
                    input_tokens,
                    output_tokens,
                    thinking_tokens,
                    cache_read_tokens,
                    cache_write_tokens,
                    stored_cost,
                ) = row

                new_cost = compute_cost_millicents(
                    model=model,
                    input_tokens=int(input_tokens or 0),
                    output_tokens=int(output_tokens or 0),
                    thinking_tokens=int(thinking_tokens or 0),
                    cache_read_tokens=int(cache_read_tokens or 0),
                    cache_write_tokens=int(cache_write_tokens or 0),
                )

                # Skip rows whose model is not in the bundled matrix —
                # do NOT zero them out; NULL is the correct sentinel.
                if new_cost is None:
                    continue

                if new_cost != int(stored_cost):
                    updates.append((new_cost, row_id))
                    old_total += int(stored_cost)
                    new_total += new_cost

            if not dry_run:
                for new_cost, row_id in updates:
                    conn.execute(
                        "UPDATE requests SET cost_usd_minor_units = ? WHERE id = ?",
                        (new_cost, row_id),
                    )

            conn.execute("COMMIT")

        except Exception:
            conn.execute("ROLLBACK")
            raise

    finally:
        conn.close()

    log.info(
        "recompute_costs.complete",
        rows_scanned=len(rows),
        rows_updated=len(updates),
        dry_run=dry_run,
    )

    return RecomputeResult(
        rows_scanned=len(rows),
        rows_updated=len(updates),
        old_total_millicents=old_total,
        new_total_millicents=new_total,
    )


def format_usd(millicents: int) -> str:
    """Format a millicent value as a USD string with 6 decimal places.

    Six decimal places ensures sub-cent precision is visible (useful when
    reviewing small corrections like per-row recompute deltas).

    Example: 5_250 → "$0.052500"
    """
    dollars = millicents / 100_000
    return f"${dollars:,.6f}"
