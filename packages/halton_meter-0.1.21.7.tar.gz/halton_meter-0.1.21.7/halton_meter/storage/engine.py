"""
Async SQLAlchemy engine + session factory for the daemon's SQLite store.

WAL pragma + FK + synchronous=NORMAL are set on every connection by way of
an event listener; this keeps the proxy hot-path writers and the FastAPI
readers from blocking each other.

Engines are cached per database path. The daemon process opens exactly one
engine; tests open many (one per tmp_path / in-memory URL).
"""

from __future__ import annotations

import shutil
import stat
from pathlib import Path

import structlog
from sqlalchemy import event
from sqlalchemy.ext.asyncio import (
    AsyncEngine,
    AsyncSession,
    async_sessionmaker,
    create_async_engine,
)

log = structlog.get_logger()

DEFAULT_DB_PATH = Path("~/.halton-meter/db.sqlite").expanduser()
LEGACY_DB_PATH = Path("~/.halton-meter/logs.db").expanduser()


# Cache: db url string → (engine, sessionmaker). Tests use this to share
# engines across requests within a single TestClient run; the daemon
# process touches it exactly once at startup.
_ENGINES: dict[str, tuple[AsyncEngine, async_sessionmaker[AsyncSession]]] = {}


# File-mode contract for the SQLite store + its sidecars + the parent dir.
# DB rows can contain post-redaction request bodies, model names, project
# slugs, prompt summaries, and costs — sensitive on a multi-user Linux box.
# Owner-only read/write on the files; owner-only rwx on the directory so
# even a directory listing requires owner perms. Idempotent: re-applied on
# every daemon start, cheap when already correct.
_DB_FILE_MODE = 0o600
_DB_DIR_MODE = 0o700
_DB_SIDECAR_SUFFIXES = ("-wal", "-shm")


def _tighten_db_permissions(db_path: Path) -> None:
    """
    Enforce 0o600 on db.sqlite + its WAL/SHM sidecars and 0o700 on the parent
    directory. Logs every chmod and never raises — perms hardening is best
    effort and must not block storage init on exotic filesystems.
    """
    parent = db_path.parent
    try:
        if parent.exists():
            current = stat.S_IMODE(parent.stat().st_mode)
            if current != _DB_DIR_MODE:
                try:
                    parent.chmod(_DB_DIR_MODE)
                    log.info(
                        "storage.permissions.tightened",
                        path=str(parent),
                        from_mode=oct(current),
                        to_mode=oct(_DB_DIR_MODE),
                    )
                except OSError as exc:
                    log.warning(
                        "storage.permissions.chmod_failed",
                        path=str(parent),
                        error=str(exc),
                    )
    except OSError as exc:  # pragma: no cover — defensive
        log.warning("storage.permissions.stat_failed", path=str(parent), error=str(exc))

    targets = [db_path] + [
        db_path.with_name(db_path.name + suffix) for suffix in _DB_SIDECAR_SUFFIXES
    ]
    for target in targets:
        try:
            if not target.exists():
                continue
            current = stat.S_IMODE(target.stat().st_mode)
            if current == _DB_FILE_MODE:
                continue
            try:
                target.chmod(_DB_FILE_MODE)
                log.info(
                    "storage.permissions.tightened",
                    path=str(target),
                    from_mode=oct(current),
                    to_mode=oct(_DB_FILE_MODE),
                )
            except OSError as exc:
                log.warning(
                    "storage.permissions.chmod_failed",
                    path=str(target),
                    error=str(exc),
                )
        except OSError as exc:  # pragma: no cover — defensive
            log.warning(
                "storage.permissions.stat_failed", path=str(target), error=str(exc)
            )


def _resolve_url(db_path: str | Path | None) -> str:
    """Translate a filesystem path (or ':memory:'/URL) into an aiosqlite URL."""
    if db_path is None:
        return f"sqlite+aiosqlite:///{DEFAULT_DB_PATH}"
    if isinstance(db_path, str) and db_path.startswith("sqlite"):
        return db_path
    if isinstance(db_path, str) and db_path == ":memory:":
        return "sqlite+aiosqlite:///:memory:"
    p = Path(db_path).expanduser()
    return f"sqlite+aiosqlite:///{p}"


def _install_pragmas(dbapi_connection: object, _conn_record: object) -> None:
    """Apply per-connection SQLite pragmas. Runs on every fresh connection."""
    cursor = dbapi_connection.cursor()  # type: ignore[attr-defined]
    try:
        cursor.execute("PRAGMA journal_mode=WAL")
        cursor.execute("PRAGMA foreign_keys=ON")
        cursor.execute("PRAGMA synchronous=NORMAL")
    finally:
        cursor.close()


def create_engine_for(db_path: str | Path | None) -> tuple[
    AsyncEngine, async_sessionmaker[AsyncSession]
]:
    """
    Build (or fetch) the AsyncEngine + sessionmaker for ``db_path``.

    Idempotent — calling twice with the same path returns the same engine.
    Safe to call from multiple coroutines; aiosqlite's pool is goroutine-safe.
    """
    url = _resolve_url(db_path)
    cached = _ENGINES.get(url)
    if cached is not None:
        return cached

    # Ensure the parent directory exists for file-backed databases, then
    # tighten perms on the directory + db file + WAL/SHM sidecars. Mode
    # enforcement runs idempotently on every engine creation so an existing
    # too-permissive db (created by a pre-hardening release) gets fixed at
    # next daemon start without requiring re-init.
    if not url.endswith(":memory:"):
        # Strip "sqlite+aiosqlite:///" prefix to recover the path.
        fs_path = Path(url.removeprefix("sqlite+aiosqlite:///"))
        if str(fs_path) and str(fs_path) != ":memory:":
            fs_path.parent.mkdir(parents=True, exist_ok=True)
            try:
                fs_path.parent.chmod(_DB_DIR_MODE)
            except OSError as exc:
                log.warning(
                    "storage.permissions.chmod_failed",
                    path=str(fs_path.parent),
                    error=str(exc),
                )
            _tighten_db_permissions(fs_path)

    engine = create_async_engine(
        url,
        echo=False,
        pool_pre_ping=True,
        # SQLite is single-writer; small pool is plenty.
        pool_size=5,
        max_overflow=10,
        future=True,
    )

    # Install pragmas on the underlying sync engine; aiosqlite proxies the
    # event through to its sync connection.
    @event.listens_for(engine.sync_engine, "connect")
    def _on_connect(dbapi_connection: object, connection_record: object) -> None:
        _install_pragmas(dbapi_connection, connection_record)

    sessionmaker = async_sessionmaker(
        bind=engine,
        expire_on_commit=False,
        autoflush=False,
        autocommit=False,
    )

    _ENGINES[url] = (engine, sessionmaker)
    return engine, sessionmaker


async def dispose_engines() -> None:
    """Dispose all cached engines. Used on daemon shutdown and in tests."""
    for engine, _ in list(_ENGINES.values()):
        try:
            await engine.dispose()
        except Exception as exc:  # pragma: no cover — defensive
            log.warning("storage.dispose_engine_failed", error=str(exc))
    _ENGINES.clear()


def migrate_legacy_db_if_present(
    new_path: Path = DEFAULT_DB_PATH,
    legacy_path: Path = LEGACY_DB_PATH,
) -> bool:
    """
    Copy the legacy ``logs.db`` into place at ``db.sqlite`` if the new file
    does not yet exist and the legacy one does.

    Returns True when a migration happened. We copy rather than rename so the
    user has a fallback if anything goes wrong; the legacy file is left in
    place untouched. The collapse to a shared schema (project_id FK etc.) is
    NOT performed here — the new SQLAlchemy ``create_all`` runs idempotently
    on top of the copied DB and adds the new tables; the legacy ``requests``
    rows survive but use the old ``project TEXT`` column shape (see ADR
    note in progress.md). This is acceptable for the v1.0 fresh-install path
    where the legacy DB is empty in practice.
    """
    if new_path.exists():
        return False
    if not legacy_path.exists():
        return False
    new_path.parent.mkdir(parents=True, exist_ok=True)
    try:
        shutil.copy2(legacy_path, new_path)
        log.info(
            "storage.legacy_db_migrated",
            legacy=str(legacy_path),
            new=str(new_path),
        )
        return True
    except Exception as exc:  # pragma: no cover — defensive
        log.warning(
            "storage.legacy_db_migrate_failed",
            error=str(exc),
            legacy=str(legacy_path),
        )
        return False
