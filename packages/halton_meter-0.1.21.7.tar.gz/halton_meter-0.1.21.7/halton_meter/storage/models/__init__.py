"""SQLAlchemy 2.0 models for the daemon's SQLite store.

Ported from haltonlabs/halton-meter-cloud:backend/app/models/ with PG → SQLite
type translations:

  * UUID         → String(36)  (UUIDv4 strings)
  * JSONB        → JSON        (SQLAlchemy generic; SQLite JSON1 backs it)
  * TIMESTAMPTZ  → DateTime    (UTC ISO-8601 in SQLite)
  * Numeric      → Float       (variance_pct only — for everything else, money
                                stays in INTEGER millicents per architecture)
"""

from __future__ import annotations

from halton_meter.storage.models.audit_event import AuditEvent
from halton_meter.storage.models.base import Base
from halton_meter.storage.models.policy import Policy
from halton_meter.storage.models.pricing_rate import PricingRate
from halton_meter.storage.models.project import Project
from halton_meter.storage.models.project_settings import ProjectSettings
from halton_meter.storage.models.reconciliation import ReconciliationRecord
from halton_meter.storage.models.request import Request
from halton_meter.storage.models.request_body import RequestBody

__all__ = [
    "AuditEvent",
    "Base",
    "Policy",
    "PricingRate",
    "Project",
    "ProjectSettings",
    "ReconciliationRecord",
    "Request",
    "RequestBody",
]
