"""Request model — one row per captured LLM API call.

This is the union of:
  * the daemon's existing `requests` table (proxy hot-path writer)
  * the cloud backend's `requests` table (FK to projects, FastAPI reader)

The daemon's old `project TEXT` slug is replaced by `project_id` (FK to
projects). The proxy write path auto-creates the row in `projects` on first
sighting via `services.ingest._get_or_create_project`.
"""

from __future__ import annotations

import uuid
from datetime import UTC, datetime
from typing import TYPE_CHECKING

from sqlalchemy import (
    BigInteger,
    Boolean,
    DateTime,
    Float,
    ForeignKey,
    Index,
    Integer,
    String,
    Text,
)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from halton_meter.storage.models.base import Base

if TYPE_CHECKING:
    from halton_meter.storage.models.request_body import RequestBody


def _uuid4_str() -> str:
    return str(uuid.uuid4())


def _utcnow() -> datetime:
    return datetime.now(tz=UTC)


class Request(Base):
    __tablename__ = "requests"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=_uuid4_str)
    project_id: Mapped[str] = mapped_column(
        String(36),
        ForeignKey("projects.id", ondelete="RESTRICT"),
        nullable=False,
        index=True,
    )

    provider: Mapped[str] = mapped_column(String(64), nullable=False)
    model: Mapped[str] = mapped_column(String(255), nullable=False)
    mode: Mapped[str] = mapped_column(String(32), nullable=False, default="standard")

    input_tokens: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    output_tokens: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    thinking_tokens: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    # Cache READ tokens (Anthropic: usage.cache_read_input_tokens).
    # Renamed from `cached_tokens` 2026-04-30 (decisions.md); ambiguous name
    # would become a bug once `cache_write_tokens` exists alongside it.
    cache_read_tokens: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    # Cache WRITE tokens (Anthropic: usage.cache_creation_input_tokens).
    # Single field by design — see pricing/matrix.py for the TTL note.
    cache_write_tokens: Mapped[int] = mapped_column(Integer, nullable=False, default=0)

    # Cost in millicents: 1 USD = 100_000 millicents. NULL if model unknown.
    cost_usd_minor_units: Mapped[int | None] = mapped_column(BigInteger, nullable=True)

    # Stored as REAL — daemon's existing schema has latency_ms as float, not int.
    latency_ms: Mapped[float | None] = mapped_column(Float, nullable=True)
    tokens_complete: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)

    requested_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, index=True
    )
    recorded_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, default=_utcnow
    )

    source_machine: Mapped[str | None] = mapped_column(Text, nullable=True)
    source_workdir: Mapped[str | None] = mapped_column(Text, nullable=True)
    attribution_method: Mapped[str | None] = mapped_column(String(32), nullable=True)
    status: Mapped[str] = mapped_column(String(32), nullable=False, default="success")

    project: Mapped[Project] = relationship(  # noqa: F821 — forward ref
        "Project", back_populates="requests"
    )
    # Optional 1:1 to the captured request/response bodies. Body rows live
    # in a separate table so retention / purges don't touch the counts row.
    # uselist=False because of the strict 1:1 (PK = request_id on the body
    # side); cascade=delete-orphan + ON DELETE CASCADE in the body's FK so
    # purging a request drops its body atomically.
    body: Mapped[RequestBody | None] = relationship(
        "RequestBody",
        back_populates="request",
        uselist=False,
        lazy="select",
        cascade="all, delete-orphan",
    )

    __table_args__ = (
        Index("idx_requests_project_requested_at", "project_id", "requested_at"),
        Index("idx_requests_provider_model_requested_at", "provider", "model", "requested_at"),
    )
