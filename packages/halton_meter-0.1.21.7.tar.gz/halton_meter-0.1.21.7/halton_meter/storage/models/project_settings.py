"""ProjectSettings model — per-project knobs that don't belong on Project itself.

Currently one knob: ``body_capture_enabled``. Default ON; missing row also
means ON. Opt-out is an explicit, persistent action.

The hot path consults a TTL-cached read of this table to decide whether to
capture bodies for a given project. The ``.haltonrc`` file may also carry a
``body_capture = off`` line for ergonomic per-directory override; the rcfile
override is checked alongside this row at request time (the rcfile read is
already part of attribution, so we don't pay for it twice).

The ``HaltonConfig.bodies.enabled`` master switch wins over per-project: if
the master is False, no bodies are captured anywhere regardless of this
row's value. See ``memory/plans/2026-05-01-body-capture.md`` open question
#10 (operator-confirmed: master wins).
"""

from __future__ import annotations

from datetime import UTC, datetime

from sqlalchemy import Boolean, DateTime, ForeignKey, String
from sqlalchemy.orm import Mapped, mapped_column

from halton_meter.storage.models.base import Base


def _utcnow() -> datetime:
    return datetime.now(tz=UTC)


class ProjectSettings(Base):
    __tablename__ = "project_settings"

    project_id: Mapped[str] = mapped_column(
        String(36),
        ForeignKey("projects.id", ondelete="CASCADE"),
        primary_key=True,
    )
    body_capture_enabled: Mapped[bool] = mapped_column(
        Boolean, nullable=False, default=True,
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, default=_utcnow,
    )
