"""CLI helpers for ``halton-meter project <slug> set body-capture <on|off>``
and ``halton-meter project <slug> show``.

Same approach as ``bodies.py``: synchronous ``sqlite3`` reads/writes so the
CLI works whether or not the daemon is running. Default-ON is enforced at
three levels (column default, missing-row level, missing-rcfile-line level)
— this CLI only ever toggles the SQLite source of truth.

The daemon's hot path (PR2) reads via a TTL-cached lookup, so a CLI flip
takes effect within ``HaltonConfig.bodies.cache_ttl_seconds`` (default 5
minutes) without requiring a daemon restart.
"""

from __future__ import annotations

import sqlite3
import uuid
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path

DEFAULT_DB_PATH = Path("~/.halton-meter/db.sqlite").expanduser()


@dataclass(frozen=True)
class ProjectSettingsRow:
    project_id: str
    project_slug: str
    body_capture_enabled: bool
    updated_at: str | None


@dataclass(frozen=True)
class SetBodyCaptureResult:
    project_slug: str
    project_existed: bool
    project_created: bool
    previous_value: bool | None  # None if no settings row existed
    new_value: bool


def _connect(db_path: Path) -> sqlite3.Connection:
    conn = sqlite3.connect(str(db_path))
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def fetch_settings(db_path: Path, slug: str) -> ProjectSettingsRow | None:
    """Return the settings row for ``slug``, or None when no row.

    Note that "no row" is the default-ON case — body capture is enabled
    until the operator explicitly sets it off. The CLI's ``project show``
    surfaces this as ``body_capture_enabled: True (default)``.
    """
    if not db_path.exists():
        return None
    with _connect(db_path) as conn:
        try:
            cur = conn.execute(
                "SELECT p.id AS project_id, p.slug AS project_slug, "
                "       ps.body_capture_enabled AS bce, "
                "       ps.updated_at AS updated_at "
                "FROM projects p "
                "LEFT JOIN project_settings ps ON ps.project_id = p.id "
                "WHERE p.slug = ?",
                (slug,),
            )
        except sqlite3.OperationalError:
            return None
        row = cur.fetchone()
        if row is None:
            return None
        bce = row["bce"]
        if bce is None:
            return ProjectSettingsRow(
                project_id=row["project_id"],
                project_slug=row["project_slug"],
                body_capture_enabled=True,  # default
                updated_at=None,
            )
        return ProjectSettingsRow(
            project_id=row["project_id"],
            project_slug=row["project_slug"],
            body_capture_enabled=bool(bce),
            updated_at=str(row["updated_at"]) if row["updated_at"] else None,
        )


def set_body_capture(
    db_path: Path, slug: str, enabled: bool
) -> SetBodyCaptureResult:
    """Set ``project_settings.body_capture_enabled`` for the project at ``slug``.

    Auto-creates the ``projects`` row if absent (matches the daemon's
    write_record pattern). The caller's CLI surface always presents this
    as a no-op or an upsert; we never raise NotFound, because the operator
    legitimately wants to pre-seed an opt-out before the project has its
    first capture.
    """
    if not db_path.exists():
        # Touch the parent and create an empty file so the migration can
        # land tables on first daemon boot. CLI happens before any daemon
        # boot only on the rarest fresh-install path; in practice this
        # branch isn't hit in production.
        db_path.parent.mkdir(parents=True, exist_ok=True)

    now_iso = datetime.now(tz=UTC).isoformat()
    with _connect(db_path) as conn:
        # Look up existing row.
        cur = conn.execute(
            "SELECT id FROM projects WHERE slug = ?", (slug,)
        )
        proj_row = cur.fetchone()
        project_existed = proj_row is not None
        project_created = False
        if proj_row is None:
            project_id = str(uuid.uuid4())
            conn.execute(
                "INSERT INTO projects (id, name, slug, created_at) "
                "VALUES (?, ?, ?, ?)",
                (project_id, slug, slug, now_iso),
            )
            project_created = True
        else:
            project_id = proj_row["id"]

        # Existing settings row?
        cur = conn.execute(
            "SELECT body_capture_enabled FROM project_settings "
            "WHERE project_id = ?",
            (project_id,),
        )
        prev_row = cur.fetchone()
        previous_value: bool | None
        if prev_row is None:
            previous_value = None
            conn.execute(
                "INSERT INTO project_settings "
                "(project_id, body_capture_enabled, updated_at) "
                "VALUES (?, ?, ?)",
                (project_id, 1 if enabled else 0, now_iso),
            )
        else:
            previous_value = bool(prev_row["body_capture_enabled"])
            conn.execute(
                "UPDATE project_settings "
                "SET body_capture_enabled = ?, updated_at = ? "
                "WHERE project_id = ?",
                (1 if enabled else 0, now_iso, project_id),
            )
        conn.commit()

    return SetBodyCaptureResult(
        project_slug=slug,
        project_existed=project_existed,
        project_created=project_created,
        previous_value=previous_value,
        new_value=enabled,
    )
