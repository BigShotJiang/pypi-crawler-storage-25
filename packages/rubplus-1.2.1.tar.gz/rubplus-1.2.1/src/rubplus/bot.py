"""
RubPlus - Official Rubika Bot API Wrapper
Version 1.2.1
"""

import httpx
import asyncio
import json
import os
from datetime import datetime
from typing import Dict, Any, Optional, Callable, List


class RubPlus:
    
    def __init__(self, token: str, debug: bool = False, skip_old_messages: bool = True):
        self.token = token
        self.debug = debug
        self.skip_old_messages = skip_old_messages
        self._base_url = f"https://botapi.rubika.ir/v3/{token}"
        
        self._client = httpx.AsyncClient(timeout=60.0)
        self._handlers: Dict[str, Callable] = {}
        self._running = False
        self._offset: Optional[str] = None
        self._offset_file = "rubplus_offset.json"
        self._start_time = int(datetime.now().timestamp())
        
        self._load_offset()
        self._processed_count = 0
        
        print(f"✅ RubPlus v1.2.1 آماده شد")
        print(f"📡 توکن: {token[:15]}...{token[-10:]}")
        print(f"⏰ زمان شروع: {datetime.now().strftime('%H:%M:%S')}")
        print("-" * 40)
    
    def _load_offset(self) -> None:
        try:
            if os.path.exists(self._offset_file):
                with open(self._offset_file, 'r') as f:
                    data = json.load(f)
                    self._offset = data.get('offset')
        except:
            pass
    
    def _save_offset(self, offset: str) -> None:
        try:
            with open(self._offset_file, 'w') as f:
                json.dump({'offset': offset}, f)
        except:
            pass
    
    def on(self, event: str) -> Callable:
        def decorator(func: Callable) -> Callable:
            self._handlers[event] = func
            return func
        return decorator
    
    async def send_message(self, chat_id: str, text: str, reply_to: Optional[str] = None, keyboard: Optional[Any] = None, auto_delete: Optional[int] = None) -> Dict[str, Any]:
        data = {"chat_id": chat_id, "text": text}
        if reply_to:
            data["reply_to_message_id"] = reply_to
        if keyboard and hasattr(keyboard, 'to_dict'):
            data["chat_keypad"] = keyboard.to_dict()
            data["chat_keypad_type"] = "New"
        
        result = await self._post("sendMessage", data)
        
        if auto_delete and result.get("status") == "OK":
            msg_id = result.get("data", {}).get("message_id")
            if msg_id:
                asyncio.create_task(self._auto_delete(chat_id, msg_id, auto_delete))
        
        return result
    
    async def delete(self, chat_id: str, message_id: str) -> Dict[str, Any]:
        data = {"chat_id": chat_id, "message_id": message_id}
        return await self._post("deleteMessage", data)
    
    async def edit_text(self, chat_id: str, message_id: str, text: str) -> Dict[str, Any]:
        data = {"chat_id": chat_id, "message_id": message_id, "text": text}
        return await self._post("editMessageText", data)
    
    async def forward(self, from_chat: str, to_chat: str, message_id: str) -> Dict[str, Any]:
        data = {"from_chat_id": from_chat, "to_chat_id": to_chat, "message_id": message_id}
        return await self._post("forwardMessage", data)
    
    async def _auto_delete(self, chat_id: str, message_id: str, delay: int):
        await asyncio.sleep(delay)
        try:
            await self.delete(chat_id, message_id)
        except:
            pass
    
    async def poll(self, chat_id: str, question: str, options: List[str], is_anonymous: bool = True, multiple: bool = False) -> Dict[str, Any]:
        data = {
            "chat_id": chat_id,
            "question": question,
            "options": options,
            "is_anonymous": is_anonymous,
            "allows_multiple_answers": multiple
        }
        return await self._post("sendPoll", data)
    
    async def location(self, chat_id: str, lat: float, lon: float) -> Dict[str, Any]:
        data = {"chat_id": chat_id, "latitude": str(lat), "longitude": str(lon)}
        return await self._post("sendLocation", data)
    
    async def contact(self, chat_id: str, phone: str, first_name: str, last_name: str = "") -> Dict[str, Any]:
        data = {"chat_id": chat_id, "phone_number": phone, "first_name": first_name}
        if last_name:
            data["last_name"] = last_name
        return await self._post("sendContact", data)
    
    async def photo(self, chat_id: str, file_path: str, caption: str = "") -> Dict[str, Any]:
        from .methods.file import FileMethods
        return await FileMethods(self._client, self._base_url).send_photo(chat_id, file_path, caption)
    
    async def video(self, chat_id: str, file_path: str, caption: str = "") -> Dict[str, Any]:
        from .methods.file import FileMethods
        return await FileMethods(self._client, self._base_url).send_video(chat_id, file_path, caption)
    
    async def audio(self, chat_id: str, file_path: str, caption: str = "") -> Dict[str, Any]:
        from .methods.file import FileMethods
        return await FileMethods(self._client, self._base_url).send_audio(chat_id, file_path, caption)
    
    async def document(self, chat_id: str, file_path: str, caption: str = "") -> Dict[str, Any]:
        from .methods.file import FileMethods
        return await FileMethods(self._client, self._base_url).send_document(chat_id, file_path, caption)
    
    async def ban(self, chat_id: str, user_id: str) -> Dict[str, Any]:
        data = {"chat_id": chat_id, "user_id": user_id}
        return await self._post("banChatMember", data)
    
    async def unban(self, chat_id: str, user_id: str) -> Dict[str, Any]:
        data = {"chat_id": chat_id, "user_id": user_id}
        return await self._post("unbanChatMember", data)
    
    async def set_keypad(self, chat_id: str, keyboard: Any) -> Dict[str, Any]:
        data = {"chat_id": chat_id, "chat_keypad": keyboard.to_dict(), "chat_keypad_type": "New"}
        return await self._post("editChatKeypad", data)
    
    async def remove_keypad(self, chat_id: str) -> Dict[str, Any]:
        data = {"chat_id": chat_id, "chat_keypad_type": "Remove"}
        return await self._post("editChatKeypad", data)
    
    async def me(self) -> Dict[str, Any]:
        return await self._post("getMe", {})
    
    async def chat_info(self, chat_id: str) -> Dict[str, Any]:
        data = {"chat_id": chat_id}
        return await self._post("getChat", data)
    
    async def leave(self, chat_id: str) -> Dict[str, Any]:
        data = {"chat_id": chat_id}
        return await self._post("leaveChat", data)
    
    async def commands(self, cmds: List[Dict[str, str]]) -> Dict[str, Any]:
        data = {"bot_commands": cmds}
        return await self._post("setCommands", data)
    
    async def _post(self, method: str, data: Dict[str, Any]) -> Dict[str, Any]:
        url = f"{self._base_url}/{method}"
        try:
            response = await self._client.post(url, json=data)
            return response.json()
        except Exception as e:
            return {"status": "ERROR", "error": str(e)}
    
    async def _poll(self) -> None:
        print("\n🚀 ربات شروع به کار کرد...")
        self._running = True
        
        while self._running:
            try:
                data = {"limit": 50}
                if self._offset:
                    data["offset_id"] = self._offset
                
                result = await self._post("getUpdates", data)
                
                if result.get("status") == "OK":
                    updates = result.get("data", {}).get("updates", [])
                    next_offset = result.get("data", {}).get("next_offset_id")
                    
                    for update in updates:
                        if update.get("type") == "NewMessage":
                            message = update.get("new_message", {})
                            chat_id = update.get("chat_id")
                            msg_time = int(message.get("time", 0))
                            
                            if self.skip_old_messages and msg_time <= self._start_time:
                                continue
                            
                            message["chat_id"] = chat_id
                            
                            async def reply_func(text, rid=message.get("message_id"), cid=chat_id):
                                return await self.send_message(cid, text, rid)
                            
                            message["reply"] = reply_func
                            
                            if "message" in self._handlers:
                                await self._handlers["message"](message)
                                self._processed_count += 1
                    
                    if next_offset and next_offset != self._offset:
                        self._offset = next_offset
                        self._save_offset(next_offset)
                
                await asyncio.sleep(1)
                
            except KeyboardInterrupt:
                break
            except Exception as e:
                if self.debug:
                    print(f"⚠️ خطا: {e}")
                await asyncio.sleep(5)
    
    def run(self) -> None:
        try:
            asyncio.run(self._poll())
        except KeyboardInterrupt:
            print(f"\n👋 ربات متوقف شد")
            print(f"📊 جمعاً {self._processed_count} رویداد جدید پردازش شد")