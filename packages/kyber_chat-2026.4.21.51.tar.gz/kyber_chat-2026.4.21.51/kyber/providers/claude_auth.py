"""Claude Pro/Max subscription auth via the official Claude Code CLI store.

Kyber does not run its own OAuth flow. When the user runs ``claude``
(the ``@anthropic-ai/claude-code`` CLI) once and signs in, that CLI
writes credentials to:

* macOS: the login Keychain, service ``"Claude Code-credentials"``,
  account = the user's macOS username. Value is the JSON below.
* Linux / WSL: ``~/.claude/.credentials.json`` at mode 0600.

Either location holds the same JSON envelope::

    {
      "claudeAiOauth": {
        "accessToken":  "sk-ant-oat01-...",
        "refreshToken": "sk-ant-ort01-...",
        "expiresAt":    1776811242135,          # ms since epoch
        "scopes":       ["user:inference", ...],
        "subscriptionType": "max",              # "pro" | "max"
        "rateLimitTier":    "default_claude_max_5x"
      }
    }

Refresh uses Anthropic's OAuth token endpoint (the same one the Claude
Code CLI uses). On success we write the new tokens back to whichever
store we read them from, so Claude Code and Kyber stay in sync.
"""

from __future__ import annotations

import getpass
import json
import logging
import os
import platform
import subprocess
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import httpx

logger = logging.getLogger(__name__)

# Where the Claude Code CLI stores its token on Linux.
CLAUDE_AUTH_FILE = Path.home() / ".claude" / ".credentials.json"

# Matches what the Claude Code CLI writes to macOS Keychain.
KEYCHAIN_SERVICE = "Claude Code-credentials"

# Anthropic OAuth client id the Claude Code CLI uses. Public constant
# — same client_id Hermes uses, same one baked into the official CLI.
CLAUDE_OAUTH_CLIENT_ID = "9d1c250a-e61b-44d9-88ed-5944d1962f5e"

# The CLI calls api.anthropic.com's console-facing oauth endpoint.
# console.anthropic.com and platform.claude.com both accept the same
# refresh flow; we use console.anthropic.com because the CLI does.
CLAUDE_OAUTH_TOKEN_URL = "https://console.anthropic.com/v1/oauth/token"

# Refresh any time the access token has less than this many seconds left.
REFRESH_SKEW_SECONDS = 60


class ClaudeAuthError(RuntimeError):
    """Raised when Claude Code credentials can't be loaded or refreshed."""

    def __init__(self, message: str, *, relogin_required: bool = False) -> None:
        super().__init__(message)
        self.relogin_required = relogin_required


@dataclass
class ClaudeTokens:
    access_token: str
    refresh_token: str
    expires_at_ms: int  # milliseconds since epoch, as stored by Claude Code
    scopes: list[str]
    subscription_type: str = ""
    rate_limit_tier: str = ""

    # Metadata: where these tokens were loaded from, so we write back to
    # the same place on refresh.
    source: str = ""  # "keychain" | "file"
    source_account: str = ""  # macOS Keychain account name


def _is_macos() -> bool:
    return platform.system() == "Darwin"


# ── macOS Keychain (primary on Darwin) ────────────────────────────────


def _keychain_read() -> tuple[str, str] | None:
    """Return ``(json_string, account_name)`` from Keychain, or None.

    Uses the stock ``security`` CLI. ``-w`` prints the password value to
    stdout. The first ``security find-generic-password`` call without
    ``-w`` is what we parse the account name from.
    """
    try:
        meta = subprocess.run(
            ["security", "find-generic-password", "-s", KEYCHAIN_SERVICE],
            capture_output=True,
            text=True,
            timeout=5,
        )
        if meta.returncode != 0:
            return None
        account = ""
        for line in meta.stdout.splitlines():
            line = line.strip()
            if line.startswith('"acct"<blob>='):
                account = line.split("=", 1)[1].strip().strip('"')
                break

        value = subprocess.run(
            ["security", "find-generic-password", "-s", KEYCHAIN_SERVICE, "-w"],
            capture_output=True,
            text=True,
            timeout=5,
        )
        if value.returncode != 0:
            return None
        blob = (value.stdout or "").strip()
        if not blob:
            return None
        return blob, account
    except (OSError, subprocess.SubprocessError):
        return None


def _keychain_write(blob: str, account: str) -> bool:
    """Upsert Claude Code credentials back into the Keychain.

    ``-U`` updates existing entries or creates new ones. We preserve the
    account name we read, or fall back to the macOS username so at least
    a best-effort write succeeds.
    """
    acct = account or getpass.getuser() or os.environ.get("USER") or ""
    if not acct:
        return False
    try:
        result = subprocess.run(
            [
                "security",
                "add-generic-password",
                "-U",
                "-s",
                KEYCHAIN_SERVICE,
                "-a",
                acct,
                "-w",
                blob,
            ],
            capture_output=True,
            text=True,
            timeout=5,
        )
        return result.returncode == 0
    except (OSError, subprocess.SubprocessError):
        return False


# ── Linux / WSL filesystem ────────────────────────────────────────────


def _file_read() -> str | None:
    if not CLAUDE_AUTH_FILE.is_file():
        return None
    try:
        return CLAUDE_AUTH_FILE.read_text(encoding="utf-8")
    except OSError:
        return None


def _file_write(blob: str) -> bool:
    try:
        CLAUDE_AUTH_FILE.parent.mkdir(parents=True, exist_ok=True)
        tmp = CLAUDE_AUTH_FILE.with_suffix(CLAUDE_AUTH_FILE.suffix + ".tmp")
        tmp.write_text(blob, encoding="utf-8")
        os.chmod(tmp, 0o600)
        os.replace(tmp, CLAUDE_AUTH_FILE)
        os.chmod(CLAUDE_AUTH_FILE, 0o600)
        return True
    except OSError:
        return False


# ── Public: find / load / save / refresh ──────────────────────────────


def find_claude_auth() -> bool:
    """Return True when Claude Code credentials exist on this machine.

    Cheap probe the installer and dashboard use to decide whether the
    ``claude_subscription`` provider can start. Does not return the
    tokens themselves — only whether something resembling a signed-in
    credential exists.
    """
    if _is_macos():
        if _keychain_read() is not None:
            return True
    return _file_read() is not None


def load_tokens() -> ClaudeTokens:
    """Load credentials from Keychain (macOS) or file (Linux). Raises on miss."""
    blob: str | None = None
    source = ""
    account = ""

    if _is_macos():
        result = _keychain_read()
        if result is not None:
            blob, account = result
            source = "keychain"

    if blob is None:
        blob = _file_read()
        if blob is not None:
            source = "file"

    if blob is None:
        raise ClaudeAuthError(
            "No Claude Code credentials found. Install the CLI with "
            "`npm i -g @anthropic-ai/claude-code` and run `claude` once to sign in.",
            relogin_required=True,
        )

    try:
        data = json.loads(blob)
    except json.JSONDecodeError as e:
        raise ClaudeAuthError(f"Claude credentials are malformed JSON: {e}") from e

    oauth = data.get("claudeAiOauth") or {}
    access = str(oauth.get("accessToken") or "")
    refresh = str(oauth.get("refreshToken") or "")
    expires_raw = oauth.get("expiresAt")
    if not access or not refresh:
        raise ClaudeAuthError(
            "Claude credentials are missing accessToken/refreshToken. "
            "Run `claude` to sign in again.",
            relogin_required=True,
        )
    try:
        expires_ms = int(expires_raw) if expires_raw is not None else 0
    except (TypeError, ValueError):
        expires_ms = 0

    scopes = oauth.get("scopes") or []
    if not isinstance(scopes, list):
        scopes = []

    return ClaudeTokens(
        access_token=access,
        refresh_token=refresh,
        expires_at_ms=expires_ms,
        scopes=[str(s) for s in scopes],
        subscription_type=str(oauth.get("subscriptionType") or ""),
        rate_limit_tier=str(oauth.get("rateLimitTier") or ""),
        source=source,
        source_account=account,
    )


def _save_tokens(tokens: ClaudeTokens, raw: dict[str, Any]) -> None:
    """Persist refreshed tokens back to the store we read them from.

    Keeps the original non-token fields in the blob (subscriptionType etc)
    so the Claude Code CLI doesn't notice the rewrite. Best-effort — a
    failed write doesn't block the in-memory tokens from being used.
    """
    oauth = raw.setdefault("claudeAiOauth", {})
    oauth["accessToken"] = tokens.access_token
    oauth["refreshToken"] = tokens.refresh_token
    oauth["expiresAt"] = tokens.expires_at_ms
    blob = json.dumps(raw, separators=(",", ":"))

    if tokens.source == "keychain":
        if not _keychain_write(blob, tokens.source_account):
            logger.warning("Could not update Claude Code keychain entry")
        return
    if tokens.source == "file":
        if not _file_write(blob):
            logger.warning("Could not update ~/.claude/.credentials.json")
        return
    logger.debug("No source recorded for Claude tokens; skipping persist")


def _expires_soon(expires_at_ms: int, skew_s: int = REFRESH_SKEW_SECONDS) -> bool:
    if expires_at_ms <= 0:
        # No expiry stamp → assume valid; API will tell us if not.
        return False
    now_ms = int(time.time() * 1000)
    return expires_at_ms <= now_ms + (skew_s * 1000)


async def refresh_tokens(
    tokens: ClaudeTokens, *, timeout_seconds: float = 20.0
) -> ClaudeTokens:
    """Exchange refresh_token for a new access_token and persist it."""
    timeout = httpx.Timeout(max(5.0, float(timeout_seconds)))
    async with httpx.AsyncClient(
        timeout=timeout, headers={"Accept": "application/json"}
    ) as client:
        resp = await client.post(
            CLAUDE_OAUTH_TOKEN_URL,
            json={
                "grant_type": "refresh_token",
                "refresh_token": tokens.refresh_token,
                "client_id": CLAUDE_OAUTH_CLIENT_ID,
            },
        )

    if resp.status_code != 200:
        snippet = (resp.text or "")[:300]
        if resp.status_code in (400, 401, 403):
            raise ClaudeAuthError(
                f"Claude refresh token rejected (HTTP {resp.status_code}). "
                "Run `claude` to sign in again.",
                relogin_required=True,
            )
        raise ClaudeAuthError(
            f"Claude token refresh failed (HTTP {resp.status_code}): {snippet}"
        )

    try:
        payload = resp.json()
    except ValueError as e:
        raise ClaudeAuthError(f"Refresh response wasn't JSON: {e}") from e

    new_access = str(payload.get("access_token") or "")
    if not new_access:
        raise ClaudeAuthError("Refresh response missing access_token.")
    new_refresh = str(payload.get("refresh_token") or tokens.refresh_token)
    # Anthropic returns expires_in (seconds); Claude Code stores ms-from-epoch.
    expires_in = payload.get("expires_in")
    try:
        expires_at_ms = int(time.time() * 1000 + int(expires_in) * 1000) if expires_in else 0
    except (TypeError, ValueError):
        expires_at_ms = 0

    updated = ClaudeTokens(
        access_token=new_access,
        refresh_token=new_refresh,
        expires_at_ms=expires_at_ms,
        scopes=tokens.scopes,
        subscription_type=tokens.subscription_type,
        rate_limit_tier=tokens.rate_limit_tier,
        source=tokens.source,
        source_account=tokens.source_account,
    )

    # Re-read the original blob so we don't clobber non-token fields
    # (subscriptionType, rateLimitTier, etc.) the CLI cares about.
    if tokens.source == "keychain":
        existing = _keychain_read()
        raw_existing = json.loads(existing[0]) if existing else {}
    elif tokens.source == "file":
        raw_existing = json.loads(_file_read() or "{}")
    else:
        raw_existing = {}
    try:
        _save_tokens(updated, raw_existing)
    except Exception:  # pragma: no cover — non-fatal
        logger.warning("Saving refreshed Claude tokens failed", exc_info=True)
    return updated


async def ensure_fresh_tokens(
    tokens: ClaudeTokens | None = None,
) -> ClaudeTokens:
    """Return tokens whose access_token is still valid; refresh if expiring."""
    current = tokens or load_tokens()
    if _expires_soon(current.expires_at_ms):
        return await refresh_tokens(current)
    return current


def claude_subscription_info() -> dict[str, Any]:
    """Read-only sugar: return plan + scope info for the dashboard card."""
    try:
        tokens = load_tokens()
    except ClaudeAuthError:
        return {"authenticated": False}
    return {
        "authenticated": True,
        "source": tokens.source,
        "subscription_type": tokens.subscription_type or None,
        "rate_limit_tier": tokens.rate_limit_tier or None,
        "scopes": tokens.scopes,
        "expires_at_ms": tokens.expires_at_ms,
    }
