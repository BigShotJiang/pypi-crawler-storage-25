"""Claude Pro/Max subscription provider (Anthropic Messages API + OAuth).

This is the Claude-side parallel to :mod:`kyber.providers.codex_provider`.
Shared shape: we read credentials that the **official CLI** (Claude Code,
``@anthropic-ai/claude-code``) has already stored, send requests bearing
that OAuth token, and the user's Pro/Max subscription covers usage — no
API-key bill, no separate console sign-up.

Kyber's agent engine speaks OpenAI chat-completions shape (``messages``,
``tools``, ``tool_calls``). Anthropic's Messages API doesn't — it uses
``content`` parts (``text``, ``tool_use``, ``tool_result``), keeps
``system`` as a top-level field, and wants ``tools`` with a bare
``input_schema`` rather than the nested ``function`` object. This module
translates both directions so the rest of Kyber stays unchanged.

Auth-side quirks vs a plain Anthropic API key:

* ``Authorization: Bearer <accessToken>`` (not ``x-api-key``).
* An ``anthropic-beta`` header that includes ``oauth-2025-04-20`` —
  without it Anthropic rejects OAuth-bearing requests.
* ``user-agent: claude-cli/...`` plus ``x-app: cli`` so the request
  looks like it came from the official CLI (the OAuth scope the
  subscription grants is ``user:inference`` with that client context).
"""

from __future__ import annotations

import json
import logging
from typing import Any

import httpx

from kyber.providers.base import LLMProvider, LLMResponse, ToolCallRequest
from kyber.providers.claude_auth import (
    ClaudeAuthError,
    ClaudeTokens,
    ensure_fresh_tokens,
    load_tokens,
    refresh_tokens,
)

logger = logging.getLogger(__name__)

CLAUDE_API_BASE = "https://api.anthropic.com/v1"

# Pretend-to-be-the-CLI headers. The exact numeric versions aren't
# policy-enforced, but we stay close to what the real CLI advertises so
# Anthropic's server-side heuristics accept the OAuth token.
CLAUDE_CLI_USER_AGENT = "claude-cli/2.1.74 (external, cli)"
CLAUDE_APP = "cli"
CLAUDE_ANTHROPIC_VERSION = "2023-06-01"
CLAUDE_ANTHROPIC_BETA = ",".join(
    [
        "interleaved-thinking-2025-05-14",
        "fine-grained-tool-streaming-2025-05-14",
        "claude-code-20250219",
        "oauth-2025-04-20",
    ]
)

DEFAULT_MODEL = "claude-sonnet-4-6"
# Pessimistic fallback for when ``/v1/models`` is unreachable (offline
# installer, rate-limited token, etc.). Kept intentionally short — the
# dynamic catalog is the source of truth; these are just enough to get
# the user into a working state. Update when Anthropic deprecates any
# of these.
FALLBACK_MODELS = (
    "claude-opus-4-7",
    "claude-sonnet-4-6",
    "claude-opus-4-6",
    "claude-haiku-4-5",
    "claude-sonnet-4-5",
)

DEFAULT_TIMEOUT_SECONDS = 600.0


# ── Model catalog ────────────────────────────────────────────────────


async def fetch_available_models(timeout_seconds: float = 15.0) -> list[str]:
    """Return model IDs available to the current Claude subscription.

    Calls Anthropic's public ``/v1/models`` endpoint with the OAuth
    bearer token from Claude Code. Returns deduplicated, newest-first
    model IDs. Falls back to :data:`FALLBACK_MODELS` if the endpoint
    is unreachable (network blip, 401 before refresh, etc.) so the
    installer and dashboard can still make progress.
    """
    try:
        tokens = await ensure_fresh_tokens()
    except ClaudeAuthError as e:
        logger.warning("Cannot fetch Claude models — no valid login: %s", e)
        return list(FALLBACK_MODELS)

    timeout = httpx.Timeout(max(5.0, float(timeout_seconds)))
    try:
        async with httpx.AsyncClient(timeout=timeout) as client:
            resp = await client.get(
                f"{CLAUDE_API_BASE.rstrip('/')}/models",
                headers=_build_headers(tokens),
            )
    except httpx.HTTPError as e:
        logger.warning("Claude models fetch failed: %s", e)
        return list(FALLBACK_MODELS)

    if resp.status_code != 200:
        logger.warning(
            "Claude models fetch returned HTTP %s: %s",
            resp.status_code,
            resp.text[:200],
        )
        return list(FALLBACK_MODELS)

    try:
        payload = resp.json()
    except ValueError:
        return list(FALLBACK_MODELS)

    # Anthropic wraps entries under ``data`` with ``id`` / ``display_name`` /
    # ``created_at``. We return just the ids so the dropdown shows
    # "claude-opus-4-7" rather than a verbose label.
    entries = payload.get("data") or payload.get("models") or []
    seen: set[str] = set()
    out: list[str] = []
    # Sort by created_at descending so the newest model lands first.
    try:
        entries = sorted(
            entries,
            key=lambda m: str(m.get("created_at") or ""),
            reverse=True,
        )
    except Exception:
        pass
    for entry in entries:
        if not isinstance(entry, dict):
            continue
        model_id = str(entry.get("id") or entry.get("name") or "")
        if model_id and model_id not in seen:
            seen.add(model_id)
            out.append(model_id)
    return out or list(FALLBACK_MODELS)


# ── Message shape translation ────────────────────────────────────────


def _messages_to_anthropic(
    messages: list[dict[str, Any]],
) -> tuple[str | None, list[dict[str, Any]]]:
    """Split chat-completions messages into (system, anthropic_messages).

    Anthropic keeps ``system`` off the messages array. Multiple system
    messages get merged into a single top-level string (separated by
    blank lines) so a caller building progressive prompts (``identity``,
    ``workspace bootstrap``, ``live context``) doesn't lose content.

    Role mapping:

    * ``system``     → merged into returned ``system`` string.
    * ``user``       → ``{"role": "user", "content": [...]}``.
    * ``assistant``  → ``{"role": "assistant", "content": [...]}``.
      If the assistant message has ``tool_calls``, each one becomes a
      ``tool_use`` content part alongside any text.
    * ``tool``       → folded into the immediately-following
      ``{"role": "user", "content": [{"type": "tool_result", ...}]}``.
      Anthropic requires ``tool_result`` to live inside a ``user`` turn.
    """
    system_parts: list[str] = []
    out: list[dict[str, Any]] = []
    pending_tool_results: list[dict[str, Any]] = []

    def _flush_tool_results() -> None:
        """Turn queued tool_result parts into a single user turn."""
        if not pending_tool_results:
            return
        out.append({"role": "user", "content": list(pending_tool_results)})
        pending_tool_results.clear()

    for msg in messages:
        role = msg.get("role")
        content = msg.get("content")

        if role == "system":
            text = _coerce_to_text(content)
            if text.strip():
                system_parts.append(text)
            continue

        if role == "tool":
            call_id = str(msg.get("tool_call_id") or "")
            if not call_id:
                continue
            pending_tool_results.append(
                {
                    "type": "tool_result",
                    "tool_use_id": call_id,
                    "content": _coerce_to_text(content) or "",
                }
            )
            continue

        # Any non-tool turn flushes queued tool results first.
        _flush_tool_results()

        if role == "user":
            out.append({"role": "user", "content": _user_content_parts(content)})
            continue

        if role == "assistant":
            parts: list[dict[str, Any]] = []
            text = _coerce_to_text(content)
            if text:
                parts.append({"type": "text", "text": text})
            for tc in msg.get("tool_calls") or []:
                fn = tc.get("function") or {}
                tool_id = str(tc.get("id") or "")
                name = str(fn.get("name") or "")
                args_raw = fn.get("arguments")
                if isinstance(args_raw, str):
                    try:
                        args = json.loads(args_raw) if args_raw.strip() else {}
                    except json.JSONDecodeError:
                        args = {}
                elif isinstance(args_raw, dict):
                    args = args_raw
                else:
                    args = {}
                if tool_id and name:
                    parts.append(
                        {
                            "type": "tool_use",
                            "id": tool_id,
                            "name": name,
                            "input": args,
                        }
                    )
            if not parts:
                # Anthropic rejects empty content; skip empty assistant messages.
                continue
            out.append({"role": "assistant", "content": parts})
            continue

        # Unknown roles: coerce to a user text turn so nothing is lost.
        text = _coerce_to_text(content)
        if text:
            out.append({"role": "user", "content": [{"type": "text", "text": text}]})

    _flush_tool_results()

    system_str = "\n\n".join(p for p in system_parts if p.strip()) or None
    return system_str, out


def _user_content_parts(content: Any) -> list[dict[str, Any]]:
    """Normalize a chat-completions user ``content`` field into Anthropic parts."""
    if isinstance(content, str):
        return [{"type": "text", "text": content}]
    if isinstance(content, list):
        parts: list[dict[str, Any]] = []
        for item in content:
            if not isinstance(item, dict):
                continue
            if item.get("type") in ("text", "input_text") and isinstance(
                item.get("text"), str
            ):
                parts.append({"type": "text", "text": item["text"]})
        if parts:
            return parts
    # Fallback — never leave an empty content array.
    return [{"type": "text", "text": _coerce_to_text(content)}]


def _coerce_to_text(content: Any) -> str:
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        parts = []
        for item in content:
            if isinstance(item, dict):
                t = item.get("text")
                if isinstance(t, str):
                    parts.append(t)
        return "".join(parts)
    if content is None:
        return ""
    return str(content)


def _tools_to_anthropic(tools: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Convert OpenAI-style tool defs to Anthropic tool defs.

    Input ``{"type": "function", "function": {"name", "description", "parameters"}}``
    becomes ``{"name", "description", "input_schema"}`` at the top level.
    """
    out: list[dict[str, Any]] = []
    for t in tools or []:
        if not isinstance(t, dict):
            continue
        if t.get("type") == "function" and isinstance(t.get("function"), dict):
            fn = t["function"]
            out.append(
                {
                    "name": fn.get("name") or "",
                    "description": fn.get("description") or "",
                    "input_schema": fn.get("parameters")
                    or {"type": "object", "properties": {}},
                }
            )
        elif "name" in t and "input_schema" in t:
            # Already in Anthropic shape — pass through.
            out.append(t)
    return out


def _parse_anthropic_response(payload: dict[str, Any]) -> LLMResponse:
    """Map a ``/v1/messages`` response back to our generic ``LLMResponse``."""
    text_parts: list[str] = []
    tool_calls: list[ToolCallRequest] = []

    for block in payload.get("content") or []:
        if not isinstance(block, dict):
            continue
        if block.get("type") == "text" and isinstance(block.get("text"), str):
            text_parts.append(block["text"])
        elif block.get("type") == "tool_use":
            tool_calls.append(
                ToolCallRequest(
                    id=str(block.get("id") or ""),
                    name=str(block.get("name") or ""),
                    arguments=block.get("input") or {},
                )
            )

    usage_raw = payload.get("usage") or {}
    usage = {
        "prompt_tokens": int(usage_raw.get("input_tokens", 0) or 0),
        "completion_tokens": int(usage_raw.get("output_tokens", 0) or 0),
        "total_tokens": (
            int(usage_raw.get("input_tokens", 0) or 0)
            + int(usage_raw.get("output_tokens", 0) or 0)
        ),
    }

    # Anthropic's ``stop_reason``: end_turn, tool_use, max_tokens, stop_sequence
    stop_reason = str(payload.get("stop_reason") or "stop")
    finish_reason = {
        "end_turn": "stop",
        "max_tokens": "length",
        "stop_sequence": "stop",
        "tool_use": "tool_calls",
    }.get(stop_reason, stop_reason)

    return LLMResponse(
        content="".join(text_parts) if text_parts else None,
        tool_calls=tool_calls,
        finish_reason=finish_reason,
        usage=usage,
    )


# ── Provider ─────────────────────────────────────────────────────────


class ClaudeProvider(LLMProvider):
    """Anthropic Messages API, authenticated by the user's Claude subscription.

    Transparently refreshes the OAuth access token when it's close to
    expiring, and retries once on 401 in case the cached token went
    stale between requests.
    """

    def __init__(
        self,
        default_model: str | None = None,
        timeout: float = DEFAULT_TIMEOUT_SECONDS,
        api_base: str | None = None,
    ):
        super().__init__(api_key=None, api_base=api_base or CLAUDE_API_BASE)
        self._default_model = default_model or DEFAULT_MODEL
        self._timeout = httpx.Timeout(max(10.0, float(timeout)))
        self._tokens: ClaudeTokens | None = None

    def get_default_model(self) -> str:
        return self._default_model

    async def _get_tokens(self) -> ClaudeTokens:
        if self._tokens is None:
            self._tokens = load_tokens()
        self._tokens = await ensure_fresh_tokens(self._tokens)
        return self._tokens

    async def chat(
        self,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]] | None = None,
        model: str | None = None,
        tool_choice: Any | None = None,
        max_tokens: int = 16384,
        temperature: float = 0.7,
    ) -> LLMResponse:
        model_name = model or self._default_model
        system, anthropic_messages = _messages_to_anthropic(messages)

        body: dict[str, Any] = {
            "model": model_name,
            "messages": anthropic_messages,
            "max_tokens": int(max_tokens),
        }
        if system:
            body["system"] = system
        if tools:
            body["tools"] = _tools_to_anthropic(tools)
            if tool_choice is not None:
                body["tool_choice"] = _map_tool_choice(tool_choice)
        # Temperature is intentionally omitted. The newer reasoning
        # models (claude-opus-4-7, claude-sonnet-4-6) reject the field
        # outright with HTTP 400. Letting Anthropic's server-side
        # default stand gives consistent behaviour across every model
        # the subscription exposes. Kept as a parameter on the signature
        # for ``LLMProvider.chat`` compatibility.
        _ = temperature

        payload = await self._post_with_retry(body)
        return _parse_anthropic_response(payload)

    async def _post_with_retry(self, body: dict[str, Any]) -> dict[str, Any]:
        tokens = await self._get_tokens()
        for attempt in (1, 2):
            headers = _build_headers(tokens)
            async with httpx.AsyncClient(timeout=self._timeout) as client:
                resp = await client.post(
                    f"{self.api_base.rstrip('/')}/messages",
                    headers=headers,
                    content=json.dumps(body),
                )

            if resp.status_code == 200:
                try:
                    return resp.json()
                except ValueError as e:
                    raise RuntimeError(f"Claude returned non-JSON response: {e}") from e

            if resp.status_code == 401 and attempt == 1:
                logger.info(
                    "Claude returned 401; refreshing OAuth token and retrying"
                )
                try:
                    tokens = await refresh_tokens(tokens)
                    self._tokens = tokens
                except ClaudeAuthError:
                    raise
                continue

            # 429s from Anthropic on the OAuth path mean the shared
            # subscription bucket is exhausted — often because another
            # client (Claude Code, another Kyber instance) is using the
            # same login concurrently. Surface a message that actually
            # tells the user what to do instead of the raw JSON blob.
            if resp.status_code == 429:
                retry_after = resp.headers.get("retry-after")
                hint = (
                    "Your Claude subscription's rate-limit bucket is full. "
                    "This bucket is shared with anything else signed in as "
                    "you (e.g. Claude Code). "
                )
                if retry_after:
                    hint += f"Anthropic asks you to retry after {retry_after}s. "
                hint += (
                    "Switch Kyber's provider to ChatGPT/Codex, a raw API key, "
                    "or claude-haiku-4-5 while the window resets."
                )
                raise RuntimeError(hint)

            snippet = (resp.text or "")[:500]
            raise RuntimeError(f"Claude API error (HTTP {resp.status_code}): {snippet}")

        raise RuntimeError("Claude API call failed after retry")


def _map_tool_choice(choice: Any) -> dict[str, Any] | None:
    """Translate OpenAI-style tool_choice to Anthropic's shape."""
    if isinstance(choice, str):
        if choice == "auto":
            return {"type": "auto"}
        if choice == "required":
            return {"type": "any"}
        if choice == "none":
            return {"type": "none"}
    if isinstance(choice, dict):
        # {"type": "function", "function": {"name": "X"}} → {"type": "tool", "name": "X"}
        fn = (choice.get("function") or {}) if choice.get("type") == "function" else {}
        name = fn.get("name") if isinstance(fn, dict) else None
        if name:
            return {"type": "tool", "name": name}
    return None


def _build_headers(tokens: ClaudeTokens) -> dict[str, str]:
    return {
        "Authorization": f"Bearer {tokens.access_token}",
        "Content-Type": "application/json",
        "Accept": "application/json",
        "anthropic-version": CLAUDE_ANTHROPIC_VERSION,
        "anthropic-beta": CLAUDE_ANTHROPIC_BETA,
        "user-agent": CLAUDE_CLI_USER_AGENT,
        "x-app": CLAUDE_APP,
    }
