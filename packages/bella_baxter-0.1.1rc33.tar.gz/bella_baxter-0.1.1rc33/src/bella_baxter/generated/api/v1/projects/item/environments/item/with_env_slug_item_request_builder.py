from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.base_request_builder import BaseRequestBuilder
from kiota_abstractions.base_request_configuration import RequestConfiguration
from kiota_abstractions.default_query_parameters import QueryParameters
from kiota_abstractions.get_path_parameters import get_path_parameters
from kiota_abstractions.method import Method
from kiota_abstractions.request_adapter import RequestAdapter
from kiota_abstractions.request_information import RequestInformation
from kiota_abstractions.request_option import RequestOption
from kiota_abstractions.serialization import Parsable, ParsableFactory
from typing import Any, Optional, TYPE_CHECKING, Union
from warnings import warn

if TYPE_CHECKING:
    from .......models.environment_operation_response import EnvironmentOperationResponse
    from .......models.environment_response import EnvironmentResponse
    from .......models.update_environment_command import UpdateEnvironmentCommand
    from .copy.copy_request_builder import CopyRequestBuilder
    from .groups.groups_request_builder import GroupsRequestBuilder
    from .leases.leases_request_builder import LeasesRequestBuilder
    from .lease_policy.lease_policy_request_builder import LeasePolicyRequestBuilder
    from .providers.providers_request_builder import ProvidersRequestBuilder
    from .secrets.secrets_request_builder import SecretsRequestBuilder
    from .ssh.ssh_request_builder import SshRequestBuilder
    from .totp.totp_request_builder import TotpRequestBuilder
    from .users.users_request_builder import UsersRequestBuilder

class WithEnvSlugItemRequestBuilder(BaseRequestBuilder):
    """
    Builds and executes requests for operations under /api/v1/projects/{-id}/environments/{envSlug}
    """
    def __init__(self,request_adapter: RequestAdapter, path_parameters: Union[str, dict[str, Any]]) -> None:
        """
        Instantiates a new WithEnvSlugItemRequestBuilder and sets the default values.
        param path_parameters: The raw url or the url-template parameters for the request.
        param request_adapter: The request adapter to use to execute the requests.
        Returns: None
        """
        super().__init__(request_adapter, "{+baseurl}/api/v1/projects/{%2Did}/environments/{envSlug}", path_parameters)
    
    async def delete(self,request_configuration: Optional[RequestConfiguration[QueryParameters]] = None) -> Optional[EnvironmentOperationResponse]:
        """
        DELETE_api_v1_projects_projectRef_environments_envSlug
        param request_configuration: Configuration for the request such as headers, query parameters, and middleware options.
        Returns: Optional[EnvironmentOperationResponse]
        """
        request_info = self.to_delete_request_information(
            request_configuration
        )
        if not self.request_adapter:
            raise Exception("Http core is null") 
        from .......models.environment_operation_response import EnvironmentOperationResponse

        return await self.request_adapter.send_async(request_info, EnvironmentOperationResponse, None)
    
    async def get(self,request_configuration: Optional[RequestConfiguration[QueryParameters]] = None) -> Optional[EnvironmentResponse]:
        """
        GET_api_v1_projects_projectRef_environments_envSlug
        param request_configuration: Configuration for the request such as headers, query parameters, and middleware options.
        Returns: Optional[EnvironmentResponse]
        """
        request_info = self.to_get_request_information(
            request_configuration
        )
        if not self.request_adapter:
            raise Exception("Http core is null") 
        from .......models.environment_response import EnvironmentResponse

        return await self.request_adapter.send_async(request_info, EnvironmentResponse, None)
    
    async def put(self,body: UpdateEnvironmentCommand, request_configuration: Optional[RequestConfiguration[QueryParameters]] = None) -> Optional[EnvironmentOperationResponse]:
        """
        PUT_api_v1_projects_projectRef_environments_envSlug
        param body: The request body
        param request_configuration: Configuration for the request such as headers, query parameters, and middleware options.
        Returns: Optional[EnvironmentOperationResponse]
        """
        if body is None:
            raise TypeError("body cannot be null.")
        request_info = self.to_put_request_information(
            body, request_configuration
        )
        if not self.request_adapter:
            raise Exception("Http core is null") 
        from .......models.environment_operation_response import EnvironmentOperationResponse

        return await self.request_adapter.send_async(request_info, EnvironmentOperationResponse, None)
    
    def to_delete_request_information(self,request_configuration: Optional[RequestConfiguration[QueryParameters]] = None) -> RequestInformation:
        """
        DELETE_api_v1_projects_projectRef_environments_envSlug
        param request_configuration: Configuration for the request such as headers, query parameters, and middleware options.
        Returns: RequestInformation
        """
        request_info = RequestInformation(Method.DELETE, self.url_template, self.path_parameters)
        request_info.configure(request_configuration)
        request_info.headers.try_add("Accept", "application/json")
        return request_info
    
    def to_get_request_information(self,request_configuration: Optional[RequestConfiguration[QueryParameters]] = None) -> RequestInformation:
        """
        GET_api_v1_projects_projectRef_environments_envSlug
        param request_configuration: Configuration for the request such as headers, query parameters, and middleware options.
        Returns: RequestInformation
        """
        request_info = RequestInformation(Method.GET, self.url_template, self.path_parameters)
        request_info.configure(request_configuration)
        request_info.headers.try_add("Accept", "application/json")
        return request_info
    
    def to_put_request_information(self,body: UpdateEnvironmentCommand, request_configuration: Optional[RequestConfiguration[QueryParameters]] = None) -> RequestInformation:
        """
        PUT_api_v1_projects_projectRef_environments_envSlug
        param body: The request body
        param request_configuration: Configuration for the request such as headers, query parameters, and middleware options.
        Returns: RequestInformation
        """
        if body is None:
            raise TypeError("body cannot be null.")
        request_info = RequestInformation(Method.PUT, self.url_template, self.path_parameters)
        request_info.configure(request_configuration)
        request_info.headers.try_add("Accept", "application/json")
        request_info.set_content_from_parsable(self.request_adapter, "application/json", body)
        return request_info
    
    def with_url(self,raw_url: str) -> WithEnvSlugItemRequestBuilder:
        """
        Returns a request builder with the provided arbitrary URL. Using this method means any other path or query parameters are ignored.
        param raw_url: The raw URL to use for the request builder.
        Returns: WithEnvSlugItemRequestBuilder
        """
        if raw_url is None:
            raise TypeError("raw_url cannot be null.")
        return WithEnvSlugItemRequestBuilder(self.request_adapter, raw_url)
    
    @property
    def copy(self) -> CopyRequestBuilder:
        """
        The copy property
        """
        from .copy.copy_request_builder import CopyRequestBuilder

        return CopyRequestBuilder(self.request_adapter, self.path_parameters)
    
    @property
    def groups(self) -> GroupsRequestBuilder:
        """
        The groups property
        """
        from .groups.groups_request_builder import GroupsRequestBuilder

        return GroupsRequestBuilder(self.request_adapter, self.path_parameters)
    
    @property
    def lease_policy(self) -> LeasePolicyRequestBuilder:
        """
        The leasePolicy property
        """
        from .lease_policy.lease_policy_request_builder import LeasePolicyRequestBuilder

        return LeasePolicyRequestBuilder(self.request_adapter, self.path_parameters)
    
    @property
    def leases(self) -> LeasesRequestBuilder:
        """
        The leases property
        """
        from .leases.leases_request_builder import LeasesRequestBuilder

        return LeasesRequestBuilder(self.request_adapter, self.path_parameters)
    
    @property
    def providers(self) -> ProvidersRequestBuilder:
        """
        The providers property
        """
        from .providers.providers_request_builder import ProvidersRequestBuilder

        return ProvidersRequestBuilder(self.request_adapter, self.path_parameters)
    
    @property
    def secrets(self) -> SecretsRequestBuilder:
        """
        The secrets property
        """
        from .secrets.secrets_request_builder import SecretsRequestBuilder

        return SecretsRequestBuilder(self.request_adapter, self.path_parameters)
    
    @property
    def ssh(self) -> SshRequestBuilder:
        """
        The ssh property
        """
        from .ssh.ssh_request_builder import SshRequestBuilder

        return SshRequestBuilder(self.request_adapter, self.path_parameters)
    
    @property
    def totp(self) -> TotpRequestBuilder:
        """
        The totp property
        """
        from .totp.totp_request_builder import TotpRequestBuilder

        return TotpRequestBuilder(self.request_adapter, self.path_parameters)
    
    @property
    def users(self) -> UsersRequestBuilder:
        """
        The users property
        """
        from .users.users_request_builder import UsersRequestBuilder

        return UsersRequestBuilder(self.request_adapter, self.path_parameters)
    
    @dataclass
    class WithEnvSlugItemRequestBuilderDeleteRequestConfiguration(RequestConfiguration[QueryParameters]):
        """
        Configuration for the request such as headers, query parameters, and middleware options.
        """
        warn("This class is deprecated. Please use the generic RequestConfiguration class generated by the generator.", DeprecationWarning)
    
    @dataclass
    class WithEnvSlugItemRequestBuilderGetRequestConfiguration(RequestConfiguration[QueryParameters]):
        """
        Configuration for the request such as headers, query parameters, and middleware options.
        """
        warn("This class is deprecated. Please use the generic RequestConfiguration class generated by the generator.", DeprecationWarning)
    
    @dataclass
    class WithEnvSlugItemRequestBuilderPutRequestConfiguration(RequestConfiguration[QueryParameters]):
        """
        Configuration for the request such as headers, query parameters, and middleware options.
        """
        warn("This class is deprecated. Please use the generic RequestConfiguration class generated by the generator.", DeprecationWarning)
    

