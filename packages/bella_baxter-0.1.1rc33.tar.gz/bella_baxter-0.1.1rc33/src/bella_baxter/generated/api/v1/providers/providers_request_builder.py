from __future__ import annotations
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.base_request_builder import BaseRequestBuilder
from kiota_abstractions.base_request_configuration import RequestConfiguration
from kiota_abstractions.default_query_parameters import QueryParameters
from kiota_abstractions.get_path_parameters import get_path_parameters
from kiota_abstractions.method import Method
from kiota_abstractions.request_adapter import RequestAdapter
from kiota_abstractions.request_information import RequestInformation
from kiota_abstractions.request_option import RequestOption
from kiota_abstractions.serialization import Parsable, ParsableFactory
from typing import Any, Optional, TYPE_CHECKING, Union
from warnings import warn

if TYPE_CHECKING:
    from ....models.create_provider_command import CreateProviderCommand
    from ....models.provider_operation_response import ProviderOperationResponse
    from ....models.provider_response import ProviderResponse
    from .catalog.catalog_request_builder import CatalogRequestBuilder
    from .init_system.init_system_request_builder import InitSystemRequestBuilder
    from .item.with_provider_slug_item_request_builder import WithProviderSlugItemRequestBuilder
    from .regions.regions_request_builder import RegionsRequestBuilder
    from .search.search_request_builder import SearchRequestBuilder

class ProvidersRequestBuilder(BaseRequestBuilder):
    """
    Builds and executes requests for operations under /api/v1/providers
    """
    def __init__(self,request_adapter: RequestAdapter, path_parameters: Union[str, dict[str, Any]]) -> None:
        """
        Instantiates a new ProvidersRequestBuilder and sets the default values.
        param path_parameters: The raw url or the url-template parameters for the request.
        param request_adapter: The request adapter to use to execute the requests.
        Returns: None
        """
        super().__init__(request_adapter, "{+baseurl}/api/v1/providers", path_parameters)
    
    def by_provider_slug(self,provider_slug: str) -> WithProviderSlugItemRequestBuilder:
        """
        Gets an item from the bella_baxter.generated.api.v1.providers.item collection
        param provider_slug: Unique identifier of the item
        Returns: WithProviderSlugItemRequestBuilder
        """
        if provider_slug is None:
            raise TypeError("provider_slug cannot be null.")
        from .item.with_provider_slug_item_request_builder import WithProviderSlugItemRequestBuilder

        url_tpl_params = get_path_parameters(self.path_parameters)
        url_tpl_params["providerSlug"] = provider_slug
        return WithProviderSlugItemRequestBuilder(self.request_adapter, url_tpl_params)
    
    async def get(self,request_configuration: Optional[RequestConfiguration[QueryParameters]] = None) -> Optional[list[ProviderResponse]]:
        """
        GET_api_v1_providers
        param request_configuration: Configuration for the request such as headers, query parameters, and middleware options.
        Returns: Optional[list[ProviderResponse]]
        """
        request_info = self.to_get_request_information(
            request_configuration
        )
        if not self.request_adapter:
            raise Exception("Http core is null") 
        from ....models.provider_response import ProviderResponse

        return await self.request_adapter.send_collection_async(request_info, ProviderResponse, None)
    
    async def post(self,body: CreateProviderCommand, request_configuration: Optional[RequestConfiguration[QueryParameters]] = None) -> Optional[ProviderOperationResponse]:
        """
        POST_api_v1_providers
        param body: The request body
        param request_configuration: Configuration for the request such as headers, query parameters, and middleware options.
        Returns: Optional[ProviderOperationResponse]
        """
        if body is None:
            raise TypeError("body cannot be null.")
        request_info = self.to_post_request_information(
            body, request_configuration
        )
        if not self.request_adapter:
            raise Exception("Http core is null") 
        from ....models.provider_operation_response import ProviderOperationResponse

        return await self.request_adapter.send_async(request_info, ProviderOperationResponse, None)
    
    def to_get_request_information(self,request_configuration: Optional[RequestConfiguration[QueryParameters]] = None) -> RequestInformation:
        """
        GET_api_v1_providers
        param request_configuration: Configuration for the request such as headers, query parameters, and middleware options.
        Returns: RequestInformation
        """
        request_info = RequestInformation(Method.GET, self.url_template, self.path_parameters)
        request_info.configure(request_configuration)
        request_info.headers.try_add("Accept", "application/json")
        return request_info
    
    def to_post_request_information(self,body: CreateProviderCommand, request_configuration: Optional[RequestConfiguration[QueryParameters]] = None) -> RequestInformation:
        """
        POST_api_v1_providers
        param body: The request body
        param request_configuration: Configuration for the request such as headers, query parameters, and middleware options.
        Returns: RequestInformation
        """
        if body is None:
            raise TypeError("body cannot be null.")
        request_info = RequestInformation(Method.POST, self.url_template, self.path_parameters)
        request_info.configure(request_configuration)
        request_info.headers.try_add("Accept", "application/json")
        request_info.set_content_from_parsable(self.request_adapter, "application/json", body)
        return request_info
    
    def with_url(self,raw_url: str) -> ProvidersRequestBuilder:
        """
        Returns a request builder with the provided arbitrary URL. Using this method means any other path or query parameters are ignored.
        param raw_url: The raw URL to use for the request builder.
        Returns: ProvidersRequestBuilder
        """
        if raw_url is None:
            raise TypeError("raw_url cannot be null.")
        return ProvidersRequestBuilder(self.request_adapter, raw_url)
    
    @property
    def catalog(self) -> CatalogRequestBuilder:
        """
        The catalog property
        """
        from .catalog.catalog_request_builder import CatalogRequestBuilder

        return CatalogRequestBuilder(self.request_adapter, self.path_parameters)
    
    @property
    def init_system(self) -> InitSystemRequestBuilder:
        """
        The initSystem property
        """
        from .init_system.init_system_request_builder import InitSystemRequestBuilder

        return InitSystemRequestBuilder(self.request_adapter, self.path_parameters)
    
    @property
    def regions(self) -> RegionsRequestBuilder:
        """
        The regions property
        """
        from .regions.regions_request_builder import RegionsRequestBuilder

        return RegionsRequestBuilder(self.request_adapter, self.path_parameters)
    
    @property
    def search(self) -> SearchRequestBuilder:
        """
        The search property
        """
        from .search.search_request_builder import SearchRequestBuilder

        return SearchRequestBuilder(self.request_adapter, self.path_parameters)
    
    @dataclass
    class ProvidersRequestBuilderGetRequestConfiguration(RequestConfiguration[QueryParameters]):
        """
        Configuration for the request such as headers, query parameters, and middleware options.
        """
        warn("This class is deprecated. Please use the generic RequestConfiguration class generated by the generator.", DeprecationWarning)
    
    @dataclass
    class ProvidersRequestBuilderPostRequestConfiguration(RequestConfiguration[QueryParameters]):
        """
        Configuration for the request such as headers, query parameters, and middleware options.
        """
        warn("This class is deprecated. Please use the generic RequestConfiguration class generated by the generator.", DeprecationWarning)
    

