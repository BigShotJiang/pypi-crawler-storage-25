"""Solomon's Mise en Place: installable starter kit for an agent kitchen."""

__version__ = "0.6.0"
