"""sourcecode — Deterministic codebase context maps for AI coding agents."""

__version__ = "1.31.15"
