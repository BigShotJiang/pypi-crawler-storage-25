"""Tests for picolayer.docker_runner — Docker test runner."""

from __future__ import annotations

import json
import subprocess
from pathlib import Path
from typing import Any
from unittest.mock import MagicMock

import pytest

from picolayer.docker_runner import (
    DockerError,
    RunResult,
    _collect_results,
    check_docker,
    ensure_image,
)


class TestCheckDocker:
    """Tests for check_docker."""

    def test_success_when_docker_available(self, mocker: Any) -> None:
        mocker.patch("subprocess.run", return_value=MagicMock(returncode=0))
        # Should not raise
        check_docker()

    def test_raises_when_docker_not_installed(self, mocker: Any) -> None:
        mocker.patch("subprocess.run", side_effect=FileNotFoundError)
        with pytest.raises(DockerError, match="not installed"):
            check_docker()

    def test_raises_when_daemon_not_running(self, mocker: Any) -> None:
        mocker.patch(
            "subprocess.run",
            side_effect=subprocess.CalledProcessError(1, "docker info"),
        )
        with pytest.raises(DockerError, match="not running"):
            check_docker()


class TestEnsureImage:
    """Tests for ensure_image."""

    def test_does_nothing_when_image_exists(self, mocker: Any) -> None:
        mocker.patch("subprocess.run", return_value=MagicMock(returncode=0))
        ensure_image("test-image:latest")
        # Only docker image inspect should be called, not pull
        subprocess.run.assert_called_once()  # type: ignore[attr-defined]

    def test_pulls_image_when_missing(self, mocker: Any) -> None:
        inspect_result = MagicMock(returncode=1)
        pull_result = MagicMock(returncode=0)
        mocker.patch("subprocess.run", side_effect=[inspect_result, pull_result])
        ensure_image("test-image:latest")
        assert subprocess.run.call_count == 2  # type: ignore[attr-defined]

    def test_raises_on_pull_failure(self, mocker: Any) -> None:
        inspect_result = MagicMock(returncode=1)
        mocker.patch(
            "subprocess.run",
            side_effect=[
                inspect_result,
                subprocess.CalledProcessError(1, "docker pull"),
            ],
        )
        with pytest.raises(DockerError, match="Failed to pull"):
            ensure_image("test-image:latest")


class TestCollectResults:
    """Tests for _collect_results."""

    def test_parses_results_json(self, tmp_path: Path) -> None:
        results_data = {
            "status": "completed",
            "result": "passed",
            "output": "All 3 tests passed",
            "error_message": None,
        }
        results_file = tmp_path / "results.json"
        results_file.write_text(json.dumps(results_data))

        # Add an artifact file
        artifact = tmp_path / "log.xml"
        artifact.write_text("<xml>log</xml>")

        result = _collect_results(tmp_path, exit_code=0)
        assert result.status == "completed"
        assert result.result == "passed"
        assert result.output == "All 3 tests passed"
        assert "log.xml" in result.artifacts
        assert result.artifacts["log.xml"] == str(artifact)

    def test_error_when_no_results_file(self, tmp_path: Path) -> None:
        result = _collect_results(tmp_path, exit_code=1)
        assert result.status == "error"
        assert "exited with code 1" in (result.error_message or "")

    def test_defaults_unknown_status(self, tmp_path: Path) -> None:
        results_file = tmp_path / "results.json"
        results_file.write_text(json.dumps({"output": "something"}))
        result = _collect_results(tmp_path, exit_code=0)
        assert result.status == "unknown"

    def test_multiple_artifacts(self, tmp_path: Path) -> None:
        results_file = tmp_path / "results.json"
        results_file.write_text(json.dumps({"status": "completed", "result": "passed"}))

        for name in ["log.xml", "output.txt", "screenshot.png"]:
            (tmp_path / name).write_text("data")

        result = _collect_results(tmp_path, exit_code=0)
        assert len(result.artifacts) == 3
        for name in ["log.xml", "output.txt", "screenshot.png"]:
            assert name in result.artifacts


class TestRunResult:
    """Tests for the RunResult dataclass."""

    def test_defaults(self) -> None:
        result = RunResult(status="pending")
        assert result.result is None
        assert result.output is None
        assert result.error_message is None
        assert result.artifacts == {}

    def test_with_all_fields(self) -> None:
        result = RunResult(
            status="completed",
            result="passed",
            output="output text",
            error_message=None,
            artifacts={"log.xml": "/tmp/log.xml"},
        )
        assert result.status == "completed"
        assert result.artifacts["log.xml"] == "/tmp/log.xml"


class TestRunTestAdditionalFirmware:
    """Tests for additional_firmware parameter in run_test."""

    def test_additional_firmware_copies_to_serve_dir(self, tmp_path: Path, mocker: Any) -> None:
        """Additional firmware files should be copied to the serve directory."""
        from picolayer.docker_runner import run_test

        firmware = tmp_path / "firmware.elf"
        firmware.write_bytes(b"\x7fELF")
        test_file = tmp_path / "test.robot"
        test_file.write_text("*** Test Cases ***\n")
        extra_fw = tmp_path / "peripheral.elf"
        extra_fw.write_bytes(b"\x7fELF-extra")

        # Track what files get copied to serve_dir
        copied_files: list[tuple[str, str]] = []
        original_copy_to = __import__("picolayer.docker_runner", fromlist=["_copy_to"])._copy_to

        def tracking_copy(src: Path, dst: Path) -> None:
            copied_files.append((src.name, dst.name))
            original_copy_to(src, dst)

        mocker.patch("picolayer.docker_runner._copy_to", side_effect=tracking_copy)

        # Mock subprocess.run so Docker doesn't actually run
        mock_proc = MagicMock(returncode=0)
        mocker.patch("subprocess.run", return_value=mock_proc)

        # Mock serve_directory to return a fixed port
        from contextlib import contextmanager

        @contextmanager
        def mock_serve(path: Path):  # type: ignore[no-untyped-def]
            yield 9999

        mocker.patch("picolayer.docker_runner.serve_directory", side_effect=mock_serve)

        run_test(
            firmware=firmware,
            test_script=test_file,
            picolayer_config="board: stm32f4_discovery",
            timeout_seconds=60,
            additional_firmware=[extra_fw],
        )

        # firmware.elf, test.robot, and peripheral.elf should all be copied
        copied_names = {name for name, _ in copied_files}
        assert "firmware.elf" in copied_names
        assert "test.robot" in copied_names
        assert "peripheral.elf" in copied_names

    def test_additional_firmware_env_var_set(self, tmp_path: Path, mocker: Any) -> None:
        """ADDITIONAL_FIRMWARE_URLS env var should be set when extra firmware is given."""
        from picolayer.docker_runner import run_test

        firmware = tmp_path / "firmware.elf"
        firmware.write_bytes(b"\x7fELF")
        test_file = tmp_path / "test.robot"
        test_file.write_text("*** Test Cases ***\n")
        extra1 = tmp_path / "central.elf"
        extra1.write_bytes(b"\x7fELF")
        extra2 = tmp_path / "peripheral.elf"
        extra2.write_bytes(b"\x7fELF")

        # Capture the docker command to inspect env vars
        captured_cmd: list[str] = []

        def capture_run(cmd: list[str], **kwargs: Any) -> MagicMock:
            captured_cmd.extend(cmd)
            return MagicMock(returncode=0)

        mocker.patch("subprocess.run", side_effect=capture_run)

        from contextlib import contextmanager

        @contextmanager
        def mock_serve(path: Path):  # type: ignore[no-untyped-def]
            yield 8888

        mocker.patch("picolayer.docker_runner.serve_directory", side_effect=mock_serve)

        run_test(
            firmware=firmware,
            test_script=test_file,
            picolayer_config="board: stm32f4_discovery",
            timeout_seconds=60,
            additional_firmware=[extra1, extra2],
        )

        # Find ADDITIONAL_FIRMWARE_URLS in the docker command env flags
        cmd_str = " ".join(captured_cmd)
        assert "ADDITIONAL_FIRMWARE_URLS=" in cmd_str

        # Extract the JSON value and verify structure
        for i, arg in enumerate(captured_cmd):
            if arg == "-e" and i + 1 < len(captured_cmd):
                next_arg = captured_cmd[i + 1]
                if next_arg.startswith("ADDITIONAL_FIRMWARE_URLS="):
                    urls_json = next_arg.split("=", 1)[1]
                    urls = json.loads(urls_json)
                    assert "central.elf" in urls
                    assert "peripheral.elf" in urls
                    assert "host.docker.internal:8888" in urls["central.elf"]
                    assert "host.docker.internal:8888" in urls["peripheral.elf"]
                    break
        else:
            pytest.fail("ADDITIONAL_FIRMWARE_URLS not found in docker command")

    def test_no_additional_firmware_no_env_var(self, tmp_path: Path, mocker: Any) -> None:
        """Without additional firmware, ADDITIONAL_FIRMWARE_URLS should not be set."""
        from picolayer.docker_runner import run_test

        firmware = tmp_path / "firmware.elf"
        firmware.write_bytes(b"\x7fELF")
        test_file = tmp_path / "test.robot"
        test_file.write_text("*** Test Cases ***\n")

        captured_cmd: list[str] = []

        def capture_run(cmd: list[str], **kwargs: Any) -> MagicMock:
            captured_cmd.extend(cmd)
            return MagicMock(returncode=0)

        mocker.patch("subprocess.run", side_effect=capture_run)

        from contextlib import contextmanager

        @contextmanager
        def mock_serve(path: Path):  # type: ignore[no-untyped-def]
            yield 7777

        mocker.patch("picolayer.docker_runner.serve_directory", side_effect=mock_serve)

        run_test(
            firmware=firmware,
            test_script=test_file,
            picolayer_config="board: stm32f4_discovery",
            timeout_seconds=60,
        )

        cmd_str = " ".join(captured_cmd)
        assert "ADDITIONAL_FIRMWARE_URLS" not in cmd_str
