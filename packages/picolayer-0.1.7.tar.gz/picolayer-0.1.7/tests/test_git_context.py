"""Tests for ``picolayer.git_context`` — best-effort git metadata capture."""

from __future__ import annotations

import subprocess
from pathlib import Path

import pytest

from picolayer.git_context import GitContext, _parse_remote, collect_git_context


def _git(workdir: Path, *args: str) -> None:
    """Run a git command in workdir, raising on failure."""
    subprocess.run(
        ["git", *args],
        cwd=str(workdir),
        check=True,
        capture_output=True,
    )


def _has_git() -> bool:
    try:
        subprocess.run(["git", "--version"], check=True, capture_output=True)
        return True
    except (FileNotFoundError, subprocess.CalledProcessError):
        return False


pytestmark = pytest.mark.skipif(not _has_git(), reason="git binary not available")


class TestParseRemote:
    def test_https_github(self) -> None:
        assert _parse_remote("https://github.com/octocat/hello.git") == "octocat/hello"

    def test_ssh_github(self) -> None:
        assert _parse_remote("git@github.com:octocat/hello-world.git") == "octocat/hello-world"

    def test_ssh_protocol_github(self) -> None:
        assert _parse_remote("ssh://git@github.com/octocat/foo") == "octocat/foo"

    def test_non_github_remote_returned_verbatim(self) -> None:
        assert (
            _parse_remote("https://gitlab.com/group/project.git")
            == "https://gitlab.com/group/project"
        )

    def test_none_returns_none(self) -> None:
        assert _parse_remote(None) is None
        assert _parse_remote("") is None


class TestCollectGitContext:
    def test_non_repo_returns_local_label(self, tmp_path: Path) -> None:
        ctx = collect_git_context(tmp_path)
        assert isinstance(ctx, GitContext)
        assert ctx.repo == f"local:{tmp_path.name}"
        assert ctx.ref is None
        assert ctx.sha is None

    def test_real_git_repo_with_github_remote(self, tmp_path: Path) -> None:
        repo = tmp_path / "demo-project"
        repo.mkdir()
        _git(repo, "init", "-q", "-b", "main")
        _git(repo, "config", "user.email", "test@example.com")
        _git(repo, "config", "user.name", "Test")
        _git(repo, "config", "commit.gpgsign", "false")
        _git(
            repo,
            "remote",
            "add",
            "origin",
            "git@github.com:picolayer/example.git",
        )
        (repo / "README.md").write_text("hello")
        _git(repo, "add", "README.md")
        _git(repo, "commit", "-q", "-m", "init")

        ctx = collect_git_context(repo)
        assert ctx.repo == "picolayer/example"
        assert ctx.ref == "main"
        assert ctx.sha is not None
        assert len(ctx.sha) == 40

    def test_repo_without_remote_uses_dir_label(self, tmp_path: Path) -> None:
        repo = tmp_path / "no-remote"
        repo.mkdir()
        _git(repo, "init", "-q", "-b", "trunk")
        _git(repo, "config", "user.email", "test@example.com")
        _git(repo, "config", "user.name", "Test")
        _git(repo, "config", "commit.gpgsign", "false")
        (repo / "x.txt").write_text("x")
        _git(repo, "add", "x.txt")
        _git(repo, "commit", "-q", "-m", "init")

        ctx = collect_git_context(repo)
        assert ctx.repo == "local:no-remote"
        assert ctx.ref == "trunk"
        assert ctx.sha is not None
