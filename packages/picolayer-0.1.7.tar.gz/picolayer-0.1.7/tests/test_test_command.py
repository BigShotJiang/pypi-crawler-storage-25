"""Tests for picolayer test command — config validation and error paths."""

from __future__ import annotations

from pathlib import Path
from typing import Any
from unittest.mock import MagicMock, patch

from typer.testing import CliRunner

from picolayer.app import app

runner = CliRunner()


class TestTestCommandValidation:
    """Tests for input validation in the test command."""

    def test_missing_firmware(self, tmp_path: Path) -> None:
        test_file = tmp_path / "test.robot"
        test_file.write_text("*** Test Cases ***\n")
        config_file = tmp_path / "picolayer.yml"
        config_file.write_text("board: stm32f4_discovery\n")

        result = runner.invoke(
            app,
            [
                "test",
                "--firmware",
                str(tmp_path / "nonexistent.elf"),
                "--test-script",
                str(test_file),
                "--config",
                str(config_file),
            ],
        )
        assert result.exit_code == 1
        assert "Firmware not found" in result.output

    def test_missing_test_script(self, tmp_path: Path) -> None:
        firmware = tmp_path / "firmware.elf"
        firmware.write_bytes(b"\x7fELF")
        config_file = tmp_path / "picolayer.yml"
        config_file.write_text("board: stm32f4_discovery\n")

        result = runner.invoke(
            app,
            [
                "test",
                "--firmware",
                str(firmware),
                "--test-script",
                str(tmp_path / "nonexistent.robot"),
                "--config",
                str(config_file),
            ],
        )
        assert result.exit_code == 1
        assert "Test script not found" in result.output

    def test_missing_config(self, tmp_path: Path) -> None:
        firmware = tmp_path / "firmware.elf"
        firmware.write_bytes(b"\x7fELF")
        test_file = tmp_path / "test.robot"
        test_file.write_text("*** Test Cases ***\n")

        result = runner.invoke(
            app,
            [
                "test",
                "--firmware",
                str(firmware),
                "--test-script",
                str(test_file),
                "--config",
                str(tmp_path / "missing.yml"),
            ],
        )
        assert result.exit_code == 1
        assert "Config not found" in result.output


class TestPicolayerConfigValidation:
    """Tests for picolayer.yml content validation."""

    def _invoke_test(self, tmp_path: Path, config_content: str) -> Any:
        firmware = tmp_path / "firmware.elf"
        firmware.write_bytes(b"\x7fELF")
        test_file = tmp_path / "test.robot"
        test_file.write_text("*** Test Cases ***\n")
        config_file = tmp_path / "picolayer.yml"
        config_file.write_text(config_content)

        return runner.invoke(
            app,
            [
                "test",
                "--firmware",
                str(firmware),
                "--test-script",
                str(test_file),
                "--config",
                str(config_file),
            ],
        )

    def test_invalid_yaml(self, tmp_path: Path) -> None:
        result = self._invoke_test(tmp_path, "board: [invalid yaml\n")
        assert result.exit_code == 1
        assert "Invalid YAML" in result.output

    def test_yaml_not_a_mapping(self, tmp_path: Path) -> None:
        # A bare string is parsed as a scalar by yaml.safe_load, not a dict
        result = self._invoke_test(tmp_path, "just a string\n")
        assert result.exit_code == 1
        assert "YAML mapping" in result.output

    def test_no_board_or_hardware(self, tmp_path: Path) -> None:
        result = self._invoke_test(tmp_path, "timeout: 300\n")
        assert result.exit_code == 1
        assert "Must specify either" in result.output

    def test_both_board_and_hardware(self, tmp_path: Path) -> None:
        result = self._invoke_test(
            tmp_path, "board: stm32f4_discovery\nhardware:\n  platform: stm32\n"
        )
        assert result.exit_code == 1
        assert "Cannot specify both" in result.output

    def test_unknown_board(self, tmp_path: Path) -> None:
        result = self._invoke_test(tmp_path, "board: nonexistent_board\n")
        assert result.exit_code == 1
        assert "Unknown board" in result.output

    def test_valid_config_proceeds_to_docker(self, tmp_path: Path) -> None:
        """A valid config should proceed past validation to Docker check."""
        mock_check_docker = MagicMock()
        mock_check_docker.side_effect = Exception("docker not available")

        with patch("picolayer.docker_runner.check_docker", mock_check_docker):
            self._invoke_test(tmp_path, "board: stm32f4_discovery\ntimeout: 300\n")

        # Should have gotten past config validation (the error is from Docker check)
        mock_check_docker.assert_called_once()


class TestTestCommandLocalMode:
    """Tests for local Docker execution path."""

    def test_docker_not_available(self, tmp_path: Path) -> None:
        firmware = tmp_path / "firmware.elf"
        firmware.write_bytes(b"\x7fELF")
        test_file = tmp_path / "test.robot"
        test_file.write_text("*** Test Cases ***\n")
        config_file = tmp_path / "picolayer.yml"
        config_file.write_text("board: stm32f4_discovery\n")

        from picolayer.docker_runner import DockerError

        with patch(
            "picolayer.docker_runner.check_docker",
            side_effect=DockerError("Docker is not installed."),
        ):
            result = runner.invoke(
                app,
                [
                    "test",
                    "--firmware",
                    str(firmware),
                    "--test-script",
                    str(test_file),
                    "--config",
                    str(config_file),
                ],
            )
        assert result.exit_code == 1
        assert "Docker is not installed" in result.output


class TestTestCommandRemoteMode:
    """Tests for remote API execution path."""

    def test_remote_not_logged_in(self, tmp_path: Path, tmp_config_dir: Path) -> None:
        firmware = tmp_path / "firmware.elf"
        firmware.write_bytes(b"\x7fELF")
        test_file = tmp_path / "test.robot"
        test_file.write_text("*** Test Cases ***\n")
        config_file = tmp_path / "picolayer.yml"
        config_file.write_text("board: stm32f4_discovery\n")

        result = runner.invoke(
            app,
            [
                "test",
                "--firmware",
                str(firmware),
                "--test-script",
                str(test_file),
                "--config",
                str(config_file),
                "--remote",
            ],
        )
        assert result.exit_code == 1
        assert "Not logged in" in result.output

    def test_remote_with_api_error(
        self, tmp_path: Path, tmp_config_dir: Path, saved_config: Any
    ) -> None:
        saved_config({"auth": {"api_key": "test-key", "api_endpoint": "https://api.test.dev"}})

        firmware = tmp_path / "firmware.elf"
        firmware.write_bytes(b"\x7fELF")
        test_file = tmp_path / "test.robot"
        test_file.write_text("*** Test Cases ***\n")
        config_file = tmp_path / "picolayer.yml"
        config_file.write_text("board: stm32f4_discovery\n")

        from picolayer.api_client import ApiError

        mock_client = MagicMock()
        mock_client.upload_file.side_effect = ApiError(500, "Upload failed")
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)

        with patch("picolayer.api_client.PicolayerClient", return_value=mock_client):
            result = runner.invoke(
                app,
                [
                    "test",
                    "--firmware",
                    str(firmware),
                    "--test-script",
                    str(test_file),
                    "--config",
                    str(config_file),
                    "--remote",
                ],
            )
        assert result.exit_code == 1
        assert "API error" in result.output


class TestDisplayResult:
    """Tests for _display_result helper."""

    def test_passed_result(self, capsys: Any) -> None:
        from picolayer.commands.test import _display_result

        _display_result("completed", "passed", "All tests passed", None)
        # _display_result uses Rich console, so we don't check capsys here
        # Just verify no exception is raised

    def test_failed_result(self) -> None:
        from picolayer.commands.test import _display_result

        _display_result("completed", "failed", "1 test failed", "Assertion error")

    def test_error_result(self) -> None:
        from picolayer.commands.test import _display_result

        _display_result("error", None, None, "Container crashed")

    def test_truncates_long_output(self) -> None:
        from picolayer.commands.test import _display_result

        long_output = "x" * 5000
        # Should not raise — output is truncated at 2000 chars internally
        _display_result("completed", "passed", long_output, None)


class TestJsonOutput:
    """Tests for the ``picolayer test --json`` flag."""

    def test_missing_firmware_emits_json_error(self, tmp_path: Path) -> None:
        import json as _json

        test_file = tmp_path / "test.robot"
        test_file.write_text("*** Test Cases ***\n")
        config_file = tmp_path / "picolayer.yml"
        config_file.write_text("board: stm32f4_discovery\n")

        result = runner.invoke(
            app,
            [
                "test",
                "--firmware",
                str(tmp_path / "missing.elf"),
                "--test-script",
                str(test_file),
                "--config",
                str(config_file),
                "--json",
            ],
        )
        assert result.exit_code != 0
        payload = _json.loads(result.stdout)
        assert payload["ok"] is False
        assert "Firmware not found" in payload["error"]

    def test_invalid_yaml_emits_json_error(self, tmp_path: Path) -> None:
        import json as _json

        firmware = tmp_path / "firmware.elf"
        firmware.write_bytes(b"\x7fELF")
        test_file = tmp_path / "test.robot"
        test_file.write_text("*** Test Cases ***\n")
        config_file = tmp_path / "picolayer.yml"
        config_file.write_text("board: [unclosed\n")

        result = runner.invoke(
            app,
            [
                "test",
                "--firmware",
                str(firmware),
                "--test-script",
                str(test_file),
                "--config",
                str(config_file),
                "--json",
            ],
        )
        assert result.exit_code != 0
        payload = _json.loads(result.stdout)
        assert payload["ok"] is False
        assert "Invalid YAML" in payload["error"]

    def test_local_run_emits_json_payload(self, tmp_path: Path) -> None:
        import json as _json

        firmware = tmp_path / "firmware.elf"
        firmware.write_bytes(b"\x7fELF")
        test_file = tmp_path / "test.robot"
        test_file.write_text("*** Test Cases ***\n")
        config_file = tmp_path / "picolayer.yml"
        config_file.write_text("board: stm32f4_discovery\n")

        from picolayer.docker_runner import RunResult

        run_result = RunResult(
            status="completed",
            result="passed",
            output="ok",
            error_message=None,
            artifacts={"uart0_transcript.txt": str(tmp_path / "uart0.txt")},
        )

        with (
            patch("picolayer.commands.test.check_docker", create=True),
            patch("picolayer.commands.test.ensure_image", create=True),
            patch("picolayer.commands.test.run_test", create=True, return_value=run_result),
        ):
            # The patches above are no-ops; the real lookups happen inside _run_local.
            with (
                patch("picolayer.docker_runner.check_docker"),
                patch("picolayer.docker_runner.ensure_image"),
                patch("picolayer.docker_runner.run_test", return_value=run_result),
            ):
                result = runner.invoke(
                    app,
                    [
                        "test",
                        "--firmware",
                        str(firmware),
                        "--test-script",
                        str(test_file),
                        "--config",
                        str(config_file),
                        "--json",
                    ],
                )
        assert result.exit_code == 0
        payload = _json.loads(result.stdout)
        assert payload["ok"] is True
        assert payload["mode"] == "local"
        assert payload["result"] == "passed"
        assert payload["status"] == "completed"
        assert any(a["name"] == "uart0_transcript.txt" for a in payload["artifacts"])


class TestAdditionalFirmwareFlag:
    """Tests for the ``--additional-firmware`` CLI option."""

    def test_additional_firmware_missing_file_exits(self, tmp_path: Path) -> None:
        firmware = tmp_path / "firmware.elf"
        firmware.write_bytes(b"\x7fELF")
        test_file = tmp_path / "test.robot"
        test_file.write_text("*** Test Cases ***\n")
        config_file = tmp_path / "picolayer.yml"
        config_file.write_text("board: stm32f4_discovery\n")

        result = runner.invoke(
            app,
            [
                "test",
                "--firmware",
                str(firmware),
                "--test-script",
                str(test_file),
                "--config",
                str(config_file),
                "--additional-firmware",
                str(tmp_path / "nonexistent_peripheral.elf"),
            ],
        )
        assert result.exit_code == 1
        assert "Additional firmware not found" in result.output

    def test_additional_firmware_passed_to_local_runner(self, tmp_path: Path) -> None:
        firmware = tmp_path / "firmware.elf"
        firmware.write_bytes(b"\x7fELF")
        extra_fw = tmp_path / "peripheral.elf"
        extra_fw.write_bytes(b"\x7fELF")
        test_file = tmp_path / "test.robot"
        test_file.write_text("*** Test Cases ***\n")
        config_file = tmp_path / "picolayer.yml"
        config_file.write_text("board: stm32f4_discovery\n")

        from picolayer.docker_runner import RunResult

        run_result = RunResult(
            status="completed",
            result="passed",
            output="ok",
            error_message=None,
        )

        mock_run_test = MagicMock(return_value=run_result)
        with (
            patch("picolayer.docker_runner.check_docker"),
            patch("picolayer.docker_runner.ensure_image"),
            patch("picolayer.docker_runner.run_test", mock_run_test),
        ):
            result = runner.invoke(
                app,
                [
                    "test",
                    "--firmware",
                    str(firmware),
                    "--test-script",
                    str(test_file),
                    "--config",
                    str(config_file),
                    "--additional-firmware",
                    str(extra_fw),
                    "--json",
                ],
            )
        assert result.exit_code == 0
        # Verify run_test was called with additional_firmware containing the extra file
        call_kwargs = mock_run_test.call_args.kwargs
        assert len(call_kwargs["additional_firmware"]) == 1
        assert call_kwargs["additional_firmware"][0].name == "peripheral.elf"

    def test_multiple_additional_firmware_flags(self, tmp_path: Path) -> None:
        firmware = tmp_path / "firmware.elf"
        firmware.write_bytes(b"\x7fELF")
        extra1 = tmp_path / "central.elf"
        extra1.write_bytes(b"\x7fELF")
        extra2 = tmp_path / "peripheral.elf"
        extra2.write_bytes(b"\x7fELF")
        test_file = tmp_path / "test.robot"
        test_file.write_text("*** Test Cases ***\n")
        config_file = tmp_path / "picolayer.yml"
        config_file.write_text("board: stm32f4_discovery\n")

        from picolayer.docker_runner import RunResult

        run_result = RunResult(status="completed", result="passed", output="ok", error_message=None)
        mock_run_test = MagicMock(return_value=run_result)
        with (
            patch("picolayer.docker_runner.check_docker"),
            patch("picolayer.docker_runner.ensure_image"),
            patch("picolayer.docker_runner.run_test", mock_run_test),
        ):
            result = runner.invoke(
                app,
                [
                    "test",
                    "--firmware",
                    str(firmware),
                    "--test-script",
                    str(test_file),
                    "--config",
                    str(config_file),
                    "--additional-firmware",
                    str(extra1),
                    "--additional-firmware",
                    str(extra2),
                    "--json",
                ],
            )
        assert result.exit_code == 0
        call_kwargs = mock_run_test.call_args.kwargs
        names = {p.name for p in call_kwargs["additional_firmware"]}
        assert names == {"central.elf", "peripheral.elf"}

    def test_additional_firmware_remote_uploads_and_submits(
        self, tmp_path: Path, tmp_config_dir: Path, saved_config: Any
    ) -> None:
        saved_config({"auth": {"api_key": "test-key", "api_endpoint": "https://api.test.dev"}})

        firmware = tmp_path / "firmware.elf"
        firmware.write_bytes(b"\x7fELF")
        extra_fw = tmp_path / "peripheral.elf"
        extra_fw.write_bytes(b"\x7fELF")
        test_file = tmp_path / "test.robot"
        test_file.write_text("*** Test Cases ***\n")
        config_file = tmp_path / "picolayer.yml"
        config_file.write_text("board: stm32f4_discovery\n")

        from picolayer.api_client import ArtifactList, JobInfo

        mock_client = MagicMock()
        # upload_file returns a different URL per call
        mock_client.upload_file.side_effect = [
            "https://s3.example.com/firmware.elf",
            "https://s3.example.com/test.robot",
            "https://s3.example.com/peripheral.elf",
        ]
        mock_client.submit_job.return_value = JobInfo(
            job_id="job-123", status="completed", result="passed", output="ok"
        )
        mock_client.get_job.return_value = JobInfo(
            job_id="job-123", status="completed", result="passed", output="ok"
        )
        mock_client.get_artifacts.return_value = ArtifactList(
            job_id="job-123", artifacts=[], is_streaming=False
        )
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)

        with (
            patch("picolayer.api_client.PicolayerClient", return_value=mock_client),
            patch("picolayer.git_context.collect_git_context") as mock_git,
        ):
            mock_git.return_value = MagicMock(repo="test/repo", ref="refs/heads/main")
            result = runner.invoke(
                app,
                [
                    "test",
                    "--firmware",
                    str(firmware),
                    "--test-script",
                    str(test_file),
                    "--config",
                    str(config_file),
                    "--remote",
                    "--additional-firmware",
                    str(extra_fw),
                    "--json",
                ],
            )

        assert result.exit_code == 0
        # upload_file called 3 times: firmware, test script, additional firmware
        assert mock_client.upload_file.call_count == 3
        # submit_job should include additional_firmware_urls
        submit_kwargs = mock_client.submit_job.call_args.kwargs
        assert submit_kwargs["additional_firmware_urls"] == {
            "peripheral.elf": "https://s3.example.com/peripheral.elf"
        }


class TestAutoDetectFirmwareFromConfig:
    """Tests for auto-detection of additional firmware from renode.machines."""

    def test_machines_list_firmware_auto_detected(self, tmp_path: Path) -> None:
        firmware = tmp_path / "firmware.elf"
        firmware.write_bytes(b"\x7fELF")
        extra_fw = tmp_path / "peripheral.elf"
        extra_fw.write_bytes(b"\x7fELF")
        test_file = tmp_path / "test.robot"
        test_file.write_text("*** Test Cases ***\n")
        config_file = tmp_path / "picolayer.yml"
        config_file.write_text(
            "board: stm32f4_discovery\n"
            "renode:\n"
            "  machines:\n"
            "    - name: peripheral\n"
            "      firmware: peripheral.elf\n"
        )

        from picolayer.docker_runner import RunResult

        run_result = RunResult(status="completed", result="passed", output="ok", error_message=None)
        mock_run_test = MagicMock(return_value=run_result)
        with (
            patch("picolayer.docker_runner.check_docker"),
            patch("picolayer.docker_runner.ensure_image"),
            patch("picolayer.docker_runner.run_test", mock_run_test),
        ):
            result = runner.invoke(
                app,
                [
                    "test",
                    "--firmware",
                    str(firmware),
                    "--test-script",
                    str(test_file),
                    "--config",
                    str(config_file),
                    "--json",
                ],
            )
        assert result.exit_code == 0
        call_kwargs = mock_run_test.call_args.kwargs
        assert len(call_kwargs["additional_firmware"]) == 1
        assert call_kwargs["additional_firmware"][0].name == "peripheral.elf"

    def test_machines_dict_firmware_auto_detected(self, tmp_path: Path) -> None:
        firmware = tmp_path / "firmware.elf"
        firmware.write_bytes(b"\x7fELF")
        extra_fw = tmp_path / "sensor_node.elf"
        extra_fw.write_bytes(b"\x7fELF")
        test_file = tmp_path / "test.robot"
        test_file.write_text("*** Test Cases ***\n")
        config_file = tmp_path / "picolayer.yml"
        config_file.write_text(
            "board: stm32f4_discovery\n"
            "renode:\n"
            "  machines:\n"
            "    sensor:\n"
            "      firmware: sensor_node.elf\n"
        )

        from picolayer.docker_runner import RunResult

        run_result = RunResult(status="completed", result="passed", output="ok", error_message=None)
        mock_run_test = MagicMock(return_value=run_result)
        with (
            patch("picolayer.docker_runner.check_docker"),
            patch("picolayer.docker_runner.ensure_image"),
            patch("picolayer.docker_runner.run_test", mock_run_test),
        ):
            result = runner.invoke(
                app,
                [
                    "test",
                    "--firmware",
                    str(firmware),
                    "--test-script",
                    str(test_file),
                    "--config",
                    str(config_file),
                    "--json",
                ],
            )
        assert result.exit_code == 0
        call_kwargs = mock_run_test.call_args.kwargs
        assert len(call_kwargs["additional_firmware"]) == 1
        assert call_kwargs["additional_firmware"][0].name == "sensor_node.elf"

    def test_primary_firmware_excluded_from_additional(self, tmp_path: Path) -> None:
        """If a machine's firmware matches the primary --firmware, skip it."""
        firmware = tmp_path / "firmware.elf"
        firmware.write_bytes(b"\x7fELF")
        test_file = tmp_path / "test.robot"
        test_file.write_text("*** Test Cases ***\n")
        config_file = tmp_path / "picolayer.yml"
        config_file.write_text(
            "board: stm32f4_discovery\n"
            "renode:\n"
            "  machines:\n"
            "    - name: main\n"
            "      firmware: firmware.elf\n"
        )

        from picolayer.docker_runner import RunResult

        run_result = RunResult(status="completed", result="passed", output="ok", error_message=None)
        mock_run_test = MagicMock(return_value=run_result)
        with (
            patch("picolayer.docker_runner.check_docker"),
            patch("picolayer.docker_runner.ensure_image"),
            patch("picolayer.docker_runner.run_test", mock_run_test),
        ):
            result = runner.invoke(
                app,
                [
                    "test",
                    "--firmware",
                    str(firmware),
                    "--test-script",
                    str(test_file),
                    "--config",
                    str(config_file),
                    "--json",
                ],
            )
        assert result.exit_code == 0
        call_kwargs = mock_run_test.call_args.kwargs
        # Primary firmware should NOT appear in additional_firmware
        assert len(call_kwargs["additional_firmware"]) == 0

    def test_config_without_renode_machines_no_additional(self, tmp_path: Path) -> None:
        """A config without renode.machines should not add any additional firmware."""
        firmware = tmp_path / "firmware.elf"
        firmware.write_bytes(b"\x7fELF")
        test_file = tmp_path / "test.robot"
        test_file.write_text("*** Test Cases ***\n")
        config_file = tmp_path / "picolayer.yml"
        config_file.write_text("board: stm32f4_discovery\ntimeout: 300\n")

        from picolayer.docker_runner import RunResult

        run_result = RunResult(status="completed", result="passed", output="ok", error_message=None)
        mock_run_test = MagicMock(return_value=run_result)
        with (
            patch("picolayer.docker_runner.check_docker"),
            patch("picolayer.docker_runner.ensure_image"),
            patch("picolayer.docker_runner.run_test", mock_run_test),
        ):
            result = runner.invoke(
                app,
                [
                    "test",
                    "--firmware",
                    str(firmware),
                    "--test-script",
                    str(test_file),
                    "--config",
                    str(config_file),
                    "--json",
                ],
            )
        assert result.exit_code == 0
        call_kwargs = mock_run_test.call_args.kwargs
        assert call_kwargs["additional_firmware"] == []

    def test_missing_auto_detected_firmware_exits(self, tmp_path: Path) -> None:
        """If renode.machines references a firmware file that doesn't exist, fail."""
        firmware = tmp_path / "firmware.elf"
        firmware.write_bytes(b"\x7fELF")
        test_file = tmp_path / "test.robot"
        test_file.write_text("*** Test Cases ***\n")
        config_file = tmp_path / "picolayer.yml"
        config_file.write_text(
            "board: stm32f4_discovery\n"
            "renode:\n"
            "  machines:\n"
            "    - name: ghost\n"
            "      firmware: ghost_node.elf\n"
        )

        result = runner.invoke(
            app,
            [
                "test",
                "--firmware",
                str(firmware),
                "--test-script",
                str(test_file),
                "--config",
                str(config_file),
            ],
        )
        assert result.exit_code == 1
        assert "Additional firmware not found" in result.output

    def test_duplicate_firmware_deduplicated(self, tmp_path: Path) -> None:
        """Explicit --additional-firmware that matches a config machine is not duplicated."""
        firmware = tmp_path / "firmware.elf"
        firmware.write_bytes(b"\x7fELF")
        extra_fw = tmp_path / "peripheral.elf"
        extra_fw.write_bytes(b"\x7fELF")
        test_file = tmp_path / "test.robot"
        test_file.write_text("*** Test Cases ***\n")
        config_file = tmp_path / "picolayer.yml"
        config_file.write_text(
            "board: stm32f4_discovery\n"
            "renode:\n"
            "  machines:\n"
            "    - name: peripheral\n"
            "      firmware: peripheral.elf\n"
        )

        from picolayer.docker_runner import RunResult

        run_result = RunResult(status="completed", result="passed", output="ok", error_message=None)
        mock_run_test = MagicMock(return_value=run_result)
        with (
            patch("picolayer.docker_runner.check_docker"),
            patch("picolayer.docker_runner.ensure_image"),
            patch("picolayer.docker_runner.run_test", mock_run_test),
        ):
            result = runner.invoke(
                app,
                [
                    "test",
                    "--firmware",
                    str(firmware),
                    "--test-script",
                    str(test_file),
                    "--config",
                    str(config_file),
                    "--additional-firmware",
                    str(extra_fw),
                    "--json",
                ],
            )
        assert result.exit_code == 0
        call_kwargs = mock_run_test.call_args.kwargs
        # Should only have one entry, not a duplicate
        assert len(call_kwargs["additional_firmware"]) == 1


class TestCollectAdditionalFirmwareFromConfig:
    """Unit tests for _collect_additional_firmware_from_config."""

    def test_no_renode_section(self) -> None:
        from picolayer.commands.test import _collect_additional_firmware_from_config

        result = _collect_additional_firmware_from_config({"board": "stm32"}, Path("/tmp"))
        assert result == []

    def test_no_machines_key(self) -> None:
        from picolayer.commands.test import _collect_additional_firmware_from_config

        result = _collect_additional_firmware_from_config(
            {"renode": {"some_other": "value"}}, Path("/tmp")
        )
        assert result == []

    def test_machines_list(self, tmp_path: Path) -> None:
        from picolayer.commands.test import _collect_additional_firmware_from_config

        data = {
            "renode": {
                "machines": [
                    {"name": "central", "firmware": "central.elf"},
                    {"name": "peripheral", "firmware": "peripheral.elf"},
                ]
            }
        }
        result = _collect_additional_firmware_from_config(data, tmp_path)
        assert len(result) == 2
        assert result[0] == (tmp_path / "central.elf").resolve()
        assert result[1] == (tmp_path / "peripheral.elf").resolve()

    def test_machines_dict(self, tmp_path: Path) -> None:
        from picolayer.commands.test import _collect_additional_firmware_from_config

        data = {
            "renode": {
                "machines": {
                    "central": {"firmware": "central.elf"},
                    "sensor": {"firmware": "sensor.elf"},
                }
            }
        }
        result = _collect_additional_firmware_from_config(data, tmp_path)
        assert len(result) == 2
        names = {p.name for p in result}
        assert names == {"central.elf", "sensor.elf"}

    def test_deduplicates_same_firmware(self, tmp_path: Path) -> None:
        from picolayer.commands.test import _collect_additional_firmware_from_config

        data = {
            "renode": {
                "machines": [
                    {"name": "a", "firmware": "shared.elf"},
                    {"name": "b", "firmware": "shared.elf"},
                ]
            }
        }
        result = _collect_additional_firmware_from_config(data, tmp_path)
        assert len(result) == 1

    def test_skips_entries_without_firmware(self, tmp_path: Path) -> None:
        from picolayer.commands.test import _collect_additional_firmware_from_config

        data = {
            "renode": {
                "machines": [
                    {"name": "no-fw"},
                    {"name": "has-fw", "firmware": "fw.elf"},
                ]
            }
        }
        result = _collect_additional_firmware_from_config(data, tmp_path)
        assert len(result) == 1
        assert result[0].name == "fw.elf"

    def test_resolves_relative_to_config_dir(self, tmp_path: Path) -> None:
        from picolayer.commands.test import _collect_additional_firmware_from_config

        subdir = tmp_path / "build"
        subdir.mkdir()
        data = {"renode": {"machines": [{"name": "x", "firmware": "build/output.elf"}]}}
        result = _collect_additional_firmware_from_config(data, tmp_path)
        assert len(result) == 1
        assert result[0] == (tmp_path / "build" / "output.elf").resolve()
