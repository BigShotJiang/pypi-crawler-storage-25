# CLI — Agent Guide

Python CLI tool (`picolayer`) for scaffolding projects, running local Docker tests, and submitting remote tests to the Picolayer API.

## Architecture Role

Standalone pip-installable CLI. Talks to the Picolayer API for remote test submission and authentication. Runs local tests via Docker using the executor container image.

## Key Files

| File | Purpose |
|------|---------|
| `picolayer/app.py` | Typer app definition, top-level command group |
| `picolayer/commands/login.py` | `picolayer login` — store and validate API key |
| `picolayer/commands/init.py` | `picolayer init` — interactive board selection, generates `picolayer.yml` |
| `picolayer/commands/test.py` | `picolayer test` — local Docker or `--remote` API execution |
| `picolayer/boards.py` | Embedded board catalog (synced from executor's `board_catalog/catalog.py`) |
| `picolayer/config.py` | Read/write `~/.picolayer/config.toml` |
| `picolayer/api_client.py` | HTTP client for the Picolayer REST API |
| `picolayer/docker_runner.py` | Docker container lifecycle for local test execution |
| `picolayer/file_server.py` | Temporary HTTP server for serving files to Docker containers |

## Commands

- `picolayer login` — Prompt for API key, validate against API, store in `~/.picolayer/config.toml`
- `picolayer init` — Display board catalog, prompt for selection, generate `picolayer.yml`
- `picolayer test --firmware <path> --test-script <path>` — Run tests locally via Docker
- `picolayer test --remote --firmware <path> --test-script <path>` — Submit to cloud API, poll for results

## Local Development

```bash
cd cli
uv sync
uv run picolayer --help
```

## Testing

```bash
cd cli
uv run pytest
```

- Uses `typer.testing.CliRunner` for command tests
- Uses `httpx.MockTransport` for API client tests
- Uses `unittest.mock` for subprocess/Docker mocks
- Uses `monkeypatch` + `tmp_path` for config file isolation

## Conventions

- Follows the same Python patterns as `services/api/` and `containers/renode-executor/`
- Build system: `hatchling`
- Ruff config: line-length 100, select E/W/F/I/C/B/UP
- All functions have type annotations
- `from __future__ import annotations` in all modules

## Pitfalls

- **Board catalog sync** — The embedded board list in `boards.py` must stay in sync with `containers/renode-executor/board_catalog/catalog.py`. When adding a board to the executor, update the CLI too.
- **Local Docker networking** — Uses `host.docker.internal` to expose the temp HTTP server to containers. Works on Docker Desktop (macOS/Windows) and Linux with `--add-host`.
- **API key creation** — API keys are created via the dashboard (WorkOS widget), not via the CLI. The CLI only stores and validates them.
- **Remote test submission** — The CLI auto-detects git metadata via `picolayer.git_context` (cwd's `git remote get-url origin` + `git symbolic-ref HEAD`) and forwards `github_repo` / `github_ref` so the dashboard's Run History columns aren't blank for local agent-triggered runs. Falls back to `local:<dir>` when the cwd isn't a git checkout.
