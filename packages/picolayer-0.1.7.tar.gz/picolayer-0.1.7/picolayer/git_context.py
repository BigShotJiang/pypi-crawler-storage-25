"""Best-effort git context detection for run submissions.

When the CLI submits a job from a developer's laptop or an AI agent's working
directory, we want the dashboard's Run History to still show *something*
useful in the Repository / Ref columns. This module shells out to ``git`` in
the cwd and returns whatever it can. All failures are silent — git context is
optional, never required.
"""

from __future__ import annotations

import os
import re
import subprocess
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class GitContext:
    """Snapshot of the git state at the cwd at submission time."""

    repo: str | None = None
    """``owner/name`` for GitHub-style remotes, otherwise the cwd basename."""

    ref: str | None = None
    """Symbolic ref (e.g. ``main``) or short SHA when detached."""

    sha: str | None = None
    """Full commit SHA, if any."""


_GITHUB_RE = re.compile(
    r"""
    (?:git@github\.com:|https?://github\.com/|ssh://git@github\.com/)
    (?P<owner>[^/]+)/
    (?P<name>[^/]+?)
    (?:\.git)?$
    """,
    re.VERBOSE,
)


def collect_git_context(cwd: Path | None = None) -> GitContext:
    """Return git metadata for ``cwd`` (defaults to the current directory).

    Always returns a ``GitContext``; missing fields are ``None``. The repo
    label falls back to ``local:<cwd-name>`` when the directory isn't a git
    checkout, so the dashboard can still distinguish "ran from CLI in
    project foo" from "ran from CI".
    """
    workdir = Path(cwd) if cwd is not None else Path.cwd()

    if not _is_git_repo(workdir):
        return GitContext(repo=f"local:{workdir.name}")

    repo = _parse_remote(_run(workdir, "config", "--get", "remote.origin.url"))
    ref = _run(workdir, "symbolic-ref", "--short", "HEAD") or _run(
        workdir, "rev-parse", "--short", "HEAD"
    )
    sha = _run(workdir, "rev-parse", "HEAD")

    return GitContext(
        repo=repo or f"local:{workdir.name}",
        ref=ref or None,
        sha=sha or None,
    )


def _is_git_repo(workdir: Path) -> bool:
    return _run(workdir, "rev-parse", "--is-inside-work-tree") == "true"


def _run(workdir: Path, *args: str) -> str | None:
    """Run a git subcommand silently and return the trimmed stdout, or None."""
    try:
        result = subprocess.run(
            ["git", *args],
            cwd=str(workdir),
            capture_output=True,
            text=True,
            timeout=5,
            check=False,
            env={**os.environ, "GIT_TERMINAL_PROMPT": "0"},
        )
    except (FileNotFoundError, OSError, subprocess.SubprocessError):
        return None
    if result.returncode != 0:
        return None
    out = result.stdout.strip()
    return out or None


def _parse_remote(remote: str | None) -> str | None:
    """Convert a remote URL into ``owner/name`` for GitHub remotes.

    Non-GitHub remotes are returned verbatim with the trailing ``.git``
    stripped, so the dashboard can still display *something*.
    """
    if not remote:
        return None
    match = _GITHUB_RE.search(remote)
    if match:
        return f"{match.group('owner')}/{match.group('name')}"
    cleaned = remote.removesuffix(".git").strip()
    return cleaned or None
