"""Run Renode executor tests locally via Docker."""

from __future__ import annotations

import json
import platform
import shutil
import subprocess
import tempfile
import uuid
from dataclasses import dataclass, field
from pathlib import Path
from typing import IO

from picolayer.file_server import serve_directory

DEFAULT_IMAGE = "picolayer/renode-executor:latest"


class DockerError(Exception):
    """Raised when a Docker operation fails."""


@dataclass
class RunResult:
    """Result of a local Docker test execution."""

    status: str
    result: str | None = None
    output: str | None = None
    error_message: str | None = None
    artifacts: dict[str, str] = field(default_factory=dict)


def check_docker() -> None:
    """Verify Docker is available and running."""
    try:
        subprocess.run(
            ["docker", "info"],
            capture_output=True,
            check=True,
        )
    except FileNotFoundError:
        raise DockerError("Docker is not installed. Install Docker to run local tests.") from None
    except subprocess.CalledProcessError:
        raise DockerError("Docker daemon is not running. Start Docker and try again.") from None


def ensure_image(image: str = DEFAULT_IMAGE) -> None:
    """Pull the executor image if not already available locally."""
    result = subprocess.run(
        ["docker", "image", "inspect", image],
        capture_output=True,
    )
    if result.returncode != 0:
        try:
            subprocess.run(
                ["docker", "pull", image],
                check=True,
            )
        except subprocess.CalledProcessError as e:
            raise DockerError(f"Failed to pull image {image}: {e}") from e


def run_test(
    *,
    firmware: Path,
    test_script: Path,
    picolayer_config: str,
    timeout_seconds: int = 300,
    image: str = DEFAULT_IMAGE,
    stdout: IO[str] | None = None,
    additional_firmware: list[Path] | None = None,
) -> RunResult:
    """Run a test inside the executor Docker container.

    Serves firmware and test files via a temporary HTTP server, runs the
    container with the appropriate env vars, and collects results from a
    mounted volume.
    """
    firmware = firmware.resolve()
    test_script = test_script.resolve()

    with (
        tempfile.TemporaryDirectory(prefix="picolayer-serve-") as serve_dir_str,
        tempfile.TemporaryDirectory(prefix="picolayer-results-") as results_dir_str,
    ):
        serve_dir = Path(serve_dir_str)
        results_dir = Path(results_dir_str)

        _copy_to(firmware, serve_dir / firmware.name)
        _copy_to(test_script, serve_dir / test_script.name)

        # Copy additional firmware files into the serve directory
        resolved_additional: list[Path] = []
        for af in additional_firmware or []:
            resolved = af.resolve()
            _copy_to(resolved, serve_dir / resolved.name)
            resolved_additional.append(resolved)

        job_id = f"local-{uuid.uuid4().hex[:8]}"

        with serve_directory(serve_dir) as port:
            env = {
                "JOB_ID": job_id,
                "TENANT_ID": "local",
                "FIRMWARE_S3_URL": f"http://host.docker.internal:{port}/{firmware.name}",
                "TEST_SCRIPT": test_script.name,
                "TEST_SCRIPT_S3_URL": (f"http://host.docker.internal:{port}/{test_script.name}"),
                "PICOLAYER_CONFIG": picolayer_config,
                "TEST_TYPE": "auto",
                "TIMEOUT_SECONDS": str(timeout_seconds),
                "RESULTS_S3_PREFIX": "s3://local-bucket/local/results",
                # The executor creates boto3 clients unconditionally; provide
                # dummy AWS config so it doesn't crash before reaching the
                # actual test execution code (DynamoDB/S3 calls are skipped
                # when no table/bucket is configured).
                "AWS_DEFAULT_REGION": "us-east-1",
                "AWS_ACCESS_KEY_ID": "local",
                "AWS_SECRET_ACCESS_KEY": "local",
            }

            # Build ADDITIONAL_FIRMWARE_URLS env var for multi-node tests
            if resolved_additional:
                additional_urls: dict[str, str] = {}
                for af in resolved_additional:
                    additional_urls[af.name] = f"http://host.docker.internal:{port}/{af.name}"
                env["ADDITIONAL_FIRMWARE_URLS"] = json.dumps(additional_urls)

            cmd = ["docker", "run", "--rm"]
            # On Linux, host.docker.internal requires --add-host
            if platform.system() == "Linux":
                cmd.extend(["--add-host", "host.docker.internal:host-gateway"])
            for key, value in env.items():
                cmd.extend(["-e", f"{key}={value}"])
            cmd.extend(["-v", f"{results_dir}:/tmp/results"])
            cmd.append(image)

            try:
                proc = subprocess.run(
                    cmd,
                    capture_output=stdout is None,
                    stdout=stdout,
                    stderr=subprocess.STDOUT if stdout else None,
                    timeout=timeout_seconds + 60,
                )
            except subprocess.TimeoutExpired:
                return RunResult(status="timeout", error_message="Container execution timed out")

        return _collect_results(results_dir, proc.returncode)


def _copy_to(src: Path, dst: Path) -> None:
    """Copy a file to a destination."""
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dst)


def _collect_results(results_dir: Path, exit_code: int) -> RunResult:
    """Read results.json from the mounted volume."""
    results_file = results_dir / "results.json"
    if results_file.exists():
        data = json.loads(results_file.read_text())
        artifacts = {}
        for p in results_dir.iterdir():
            if p.name != "results.json":
                artifacts[p.name] = str(p)
        return RunResult(
            status=data.get("status", "unknown"),
            result=data.get("result"),
            output=data.get("output"),
            error_message=data.get("error_message"),
            artifacts=artifacts,
        )

    # No results file — container likely failed before writing results
    return RunResult(
        status="error",
        error_message=f"Container exited with code {exit_code}, no results produced",
    )
