"""``picolayer test`` — run firmware tests locally or remotely."""

from __future__ import annotations

import json
import sys
import time
from pathlib import Path
from typing import Annotated, Any

import typer
import yaml
from rich.console import Console

from picolayer.boards import BOARD_NAMES

# Force Rich to render plain text when stdout isn't a live terminal (e.g.
# ``picolayer test --remote > file``, ``| tail``, CI logs, or anything that
# pipes stdout). The default Rich ``Console()`` uses ``Live`` for
# ``console.status()`` which silently swallows progress output and
# **buffers** until the context manager exits — that's what made
# ``picolayer test --remote --json | tail`` hang with zero output for
# minutes at a time.
console = Console(force_terminal=sys.stdout.isatty(), force_interactive=sys.stdout.isatty())

# Stderr console — used for progress pings in ``--json`` mode so the
# customer still sees the job id / status as the run progresses without
# corrupting the JSON document on stdout.
err_console = Console(stderr=True, force_terminal=sys.stderr.isatty())

TERMINAL_STATUSES = {"completed", "failed", "error", "timeout"}

# Cap the remote-polling loop at a sensible wall-clock time so the CLI
# never hangs forever when a backend job gets stuck. 20 minutes is
# comfortably longer than the default executor budget (5 min) plus queue
# latency, and short enough that a human-driven run still sees an error
# within one coffee refill.
DEFAULT_REMOTE_WAIT_SECONDS = 20 * 60


def _emit_error(message: str, json_output: bool) -> None:
    """Print an error to stderr (text) or stdout (JSON)."""
    if json_output:
        typer.echo(json.dumps({"ok": False, "error": message}))
    else:
        console.print(f"[red]{message}[/red]")


def _load_picolayer_config(
    config_path: Path, *, json_output: bool = False
) -> tuple[dict[str, Any], str]:
    """Load and validate picolayer.yml, returning (parsed dict, raw YAML)."""
    if not config_path.exists():
        _emit_error(
            f"Config not found: {config_path}. Run `picolayer init` to create one.", json_output
        )
        raise typer.Exit(code=1)

    raw = config_path.read_text()
    try:
        data = yaml.safe_load(raw)
    except yaml.YAMLError as e:
        _emit_error(f"Invalid YAML in {config_path}: {e}", json_output)
        raise typer.Exit(code=1) from None

    if not isinstance(data, dict):
        _emit_error(f"{config_path} must be a YAML mapping.", json_output)
        raise typer.Exit(code=1)

    board = data.get("board")
    hardware = data.get("hardware")
    if board and hardware:
        _emit_error("Cannot specify both 'board' and 'hardware' in picolayer.yml.", json_output)
        raise typer.Exit(code=1)
    if not board and not hardware:
        _emit_error("Must specify either 'board' or 'hardware' in picolayer.yml.", json_output)
        raise typer.Exit(code=1)
    if board and str(board) not in BOARD_NAMES:
        _emit_error(
            f"Unknown board '{board}'. Run `picolayer init` for supported boards.", json_output
        )
        raise typer.Exit(code=1)

    return data, raw


def _collect_additional_firmware_from_config(data: dict[str, Any], config_dir: Path) -> list[Path]:
    """Extract firmware paths from ``renode.machines`` entries in picolayer.yml.

    Each machine entry may have a ``firmware`` field whose value is resolved
    relative to the config file's parent directory.  Returns a deduplicated
    list of resolved :class:`Path` objects (skipping any that don't exist on
    disk so the caller can decide how to handle them).
    """
    renode = data.get("renode")
    if not isinstance(renode, dict):
        return []
    machines = renode.get("machines")
    if not isinstance(machines, (list, dict)):
        return []

    # machines can be a list of dicts or a dict keyed by machine name
    entries: list[dict[str, Any]] = []
    if isinstance(machines, list):
        entries = [m for m in machines if isinstance(m, dict)]
    else:
        entries = [v for v in machines.values() if isinstance(v, dict)]

    seen: set[Path] = set()
    result: list[Path] = []
    for entry in entries:
        fw = entry.get("firmware")
        if not fw:
            continue
        resolved = (config_dir / fw).resolve()
        if resolved not in seen:
            seen.add(resolved)
            result.append(resolved)
    return result


def test(
    firmware: Annotated[
        Path,
        typer.Option("--firmware", "-f", help="Path to firmware ELF file"),
    ],
    test_script: Annotated[
        Path,
        typer.Option("--test-script", "-t", help="Path to test file (.robot or .resc)"),
    ],
    config: Annotated[
        Path,
        typer.Option("--config", "-c", help="Path to picolayer.yml"),
    ] = Path("picolayer.yml"),
    remote: Annotated[
        bool,
        typer.Option("--remote", "-r", help="Submit to Picolayer cloud instead of local Docker"),
    ] = False,
    image: Annotated[
        str,
        typer.Option("--image", help="Docker image for local tests"),
    ] = "picolayer/renode-executor:latest",
    poll_interval: Annotated[
        int,
        typer.Option("--poll-interval", help="Seconds between status polls (remote mode)"),
    ] = 5,
    max_wait: Annotated[
        int,
        typer.Option(
            "--max-wait",
            help="Maximum seconds to wait for a remote job to finish before giving up.",
        ),
    ] = DEFAULT_REMOTE_WAIT_SECONDS,
    json_output: Annotated[
        bool,
        typer.Option(
            "--json",
            help="Emit a single JSON document on stdout instead of Rich-formatted text. "
            "Suppresses interactive UI; suitable for scripting and AI agents.",
        ),
    ] = False,
    additional_firmware: Annotated[
        list[Path] | None,
        typer.Option(
            "--additional-firmware",
            help="Path to additional firmware file (can be specified multiple times "
            "for multi-device tests).",
        ),
    ] = None,
) -> None:
    """Run firmware tests locally via Docker or remotely via the Picolayer API."""
    # Validate paths
    if not firmware.exists():
        _emit_error(f"Firmware not found: {firmware}", json_output)
        raise typer.Exit(code=1)
    if not test_script.exists():
        _emit_error(f"Test script not found: {test_script}", json_output)
        raise typer.Exit(code=1)

    data, raw_config = _load_picolayer_config(config, json_output=json_output)
    timeout_seconds = int(data.get("timeout", 300))

    # Build the combined additional firmware list: explicit CLI flags first,
    # then any paths auto-detected from renode.machines in picolayer.yml.
    all_additional: list[Path] = list(additional_firmware or [])
    config_firmware = _collect_additional_firmware_from_config(data, config.resolve().parent)
    # Only add config-derived paths that aren't already in the explicit list
    # and that differ from the primary firmware.
    primary_resolved = firmware.resolve()
    explicit_resolved = {p.resolve() for p in all_additional}
    for cf in config_firmware:
        if cf != primary_resolved and cf not in explicit_resolved:
            all_additional.append(cf)
            explicit_resolved.add(cf)

    # Validate that all additional firmware files exist
    for af in all_additional:
        if not af.exists():
            _emit_error(f"Additional firmware not found: {af}", json_output)
            raise typer.Exit(code=1)

    if remote:
        _run_remote(
            firmware,
            test_script,
            raw_config,
            timeout_seconds,
            poll_interval,
            max_wait=max_wait,
            json_output=json_output,
            additional_firmware=all_additional,
        )
    else:
        _run_local(
            firmware,
            test_script,
            raw_config,
            timeout_seconds,
            image,
            json_output=json_output,
            additional_firmware=all_additional,
        )


def _run_local(
    firmware: Path,
    test_script: Path,
    picolayer_config: str,
    timeout_seconds: int,
    image: str,
    *,
    json_output: bool = False,
    additional_firmware: list[Path] | None = None,
) -> None:
    """Run tests locally inside a Docker container."""
    from picolayer.docker_runner import DockerError, RunResult, check_docker, ensure_image, run_test

    try:
        check_docker()
    except DockerError as e:
        _emit_error(str(e), json_output)
        raise typer.Exit(code=1) from None

    if not json_output:
        with console.status("Pulling executor image..."):
            try:
                ensure_image(image)
            except DockerError as e:
                _emit_error(str(e), json_output)
                raise typer.Exit(code=1) from None
    else:
        try:
            ensure_image(image)
        except DockerError as e:
            _emit_error(str(e), json_output)
            raise typer.Exit(code=1) from None

    if not json_output:
        console.print(f"Running test with [cyan]{firmware.name}[/cyan]...")
    result: RunResult = run_test(
        firmware=firmware,
        test_script=test_script,
        picolayer_config=picolayer_config,
        timeout_seconds=timeout_seconds,
        image=image,
        stdout=None if json_output else sys.stdout,
        additional_firmware=additional_firmware or [],
    )

    if json_output:
        payload = {
            "ok": result.result == "passed",
            "mode": "local",
            "status": result.status,
            "result": result.result,
            "output": result.output,
            "error_message": result.error_message,
            "artifacts": [
                {"name": name, "path": str(path)} for name, path in (result.artifacts or {}).items()
            ],
        }
        typer.echo(json.dumps(payload))
    else:
        _display_result(result.status, result.result, result.output, result.error_message)
        if result.artifacts:
            first_path = Path(next(iter(result.artifacts.values())))
            console.print(f"\n[dim]Artifacts in {first_path.parent}[/dim]")

    if result.result != "passed":
        raise typer.Exit(code=1)


def _run_remote(  # noqa: C901  (rich + JSON branches inflate the cyclomatic count)
    firmware: Path,
    test_script: Path,
    picolayer_config: str,
    timeout_seconds: int,
    poll_interval: int,
    *,
    max_wait: int = DEFAULT_REMOTE_WAIT_SECONDS,
    json_output: bool = False,
    additional_firmware: list[Path] | None = None,
) -> None:
    """Submit a test to the Picolayer cloud API and stream results."""
    from picolayer.api_client import ApiError, PicolayerClient
    from picolayer.config import get_api_endpoint, get_api_key
    from picolayer.git_context import collect_git_context

    api_key = get_api_key()
    if not api_key:
        _emit_error("Not logged in. Run `picolayer login` first.", json_output)
        raise typer.Exit(code=1)

    endpoint = get_api_endpoint()
    # Capture git metadata for the Run History columns. Falls back to a
    # ``local:<dir>`` label when the cwd isn't a git checkout.
    git = collect_git_context()

    try:
        with PicolayerClient(api_key, endpoint) as client:
            # Upload files. Only use Rich's ``console.status`` spinner when
            # stdout is a real terminal — otherwise the Live display swallows
            # the progress output and makes the whole upload look frozen
            # under a pipe or file redirect.
            use_spinner = (not json_output) and console.is_terminal
            if use_spinner:
                with console.status("Uploading firmware..."):
                    firmware_url = client.upload_file(firmware)
                console.print(f"  Uploaded [cyan]{firmware.name}[/cyan]")
                with console.status("Uploading test script..."):
                    test_script_url = client.upload_file(test_script)
                console.print(f"  Uploaded [cyan]{test_script.name}[/cyan]")
            else:
                firmware_url = client.upload_file(firmware)
                if not json_output:
                    console.print(f"  Uploaded {firmware.name}")
                test_script_url = client.upload_file(test_script)
                if not json_output:
                    console.print(f"  Uploaded {test_script.name}")

            # Upload additional firmware files and build the URL mapping
            additional_firmware_urls: dict[str, str] = {}
            for af in additional_firmware or []:
                if use_spinner:
                    with console.status(f"Uploading {af.name}..."):
                        af_url = client.upload_file(af)
                    console.print(f"  Uploaded [cyan]{af.name}[/cyan]")
                else:
                    af_url = client.upload_file(af)
                    if not json_output:
                        console.print(f"  Uploaded {af.name}")
                additional_firmware_urls[af.name] = af_url

            # Submit job
            if use_spinner:
                with console.status("Submitting job..."):
                    job = client.submit_job(
                        firmware_url=firmware_url,
                        test_script=test_script.name,
                        test_script_url=test_script_url,
                        test_type="auto",
                        timeout_seconds=timeout_seconds,
                        picolayer_config=picolayer_config,
                        github_repo=git.repo,
                        github_ref=git.ref,
                        additional_firmware_urls=additional_firmware_urls or None,
                    )
                console.print(f"  Job [bold]{job.job_id}[/bold] submitted")
            else:
                job = client.submit_job(
                    firmware_url=firmware_url,
                    test_script=test_script.name,
                    test_script_url=test_script_url,
                    test_type="auto",
                    timeout_seconds=timeout_seconds,
                    picolayer_config=picolayer_config,
                    github_repo=git.repo,
                    github_ref=git.ref,
                    additional_firmware_urls=additional_firmware_urls or None,
                )
                if not json_output:
                    console.print(f"  Job {job.job_id} submitted")

            # Poll for results. We honour ``max_wait`` in both modes so the
            # CLI never hangs indefinitely when a backend job gets stuck, and
            # we ping stderr in ``--json`` mode so the customer sees the job
            # id and status without polluting the JSON document on stdout.
            deadline = time.monotonic() + max_wait
            seen_lines = 0
            poll_count = 0
            last_status: str | None = None
            timed_out = False

            if json_output:
                err_console.print(f"[dim]polling job {job.job_id} (max_wait={max_wait}s)[/dim]")
                while True:
                    job = client.get_job(job.job_id)
                    if job.status != last_status:
                        err_console.print(f"[dim]  {job.job_id}: {job.status}[/dim]")
                        last_status = job.status
                    if job.status in TERMINAL_STATUSES:
                        break
                    if time.monotonic() >= deadline:
                        timed_out = True
                        break
                    time.sleep(poll_interval)
            elif console.is_terminal:
                with console.status("Waiting for results...") as status:
                    while True:
                        job = client.get_job(job.job_id)
                        status.update(f"Status: [yellow]{job.status}[/yellow]")
                        poll_count += 1
                        if poll_count % 6 == 0:
                            seen_lines = _stream_artifacts(client, job.job_id, seen_lines)
                        if job.status in TERMINAL_STATUSES:
                            break
                        if time.monotonic() >= deadline:
                            timed_out = True
                            break
                        time.sleep(poll_interval)
                _stream_artifacts(client, job.job_id, seen_lines)
            else:
                # Stdout is redirected (pipe, file, CI log). Rich's
                # ``console.status`` would swallow progress output here — so
                # just print a plain line per status transition instead.
                console.print(f"Polling {job.job_id} (max_wait={max_wait}s)")
                while True:
                    job = client.get_job(job.job_id)
                    if job.status != last_status:
                        console.print(f"  {job.job_id}: {job.status}")
                        last_status = job.status
                    poll_count += 1
                    if poll_count % 6 == 0:
                        seen_lines = _stream_artifacts(client, job.job_id, seen_lines)
                    if job.status in TERMINAL_STATUSES:
                        break
                    if time.monotonic() >= deadline:
                        timed_out = True
                        break
                    time.sleep(poll_interval)
                _stream_artifacts(client, job.job_id, seen_lines)

            if timed_out:
                message = (
                    f"Remote job {job.job_id} did not finish within {max_wait}s "
                    f"(last status: {job.status}). Re-run with --max-wait or "
                    f"inspect the dashboard."
                )
                _emit_error(message, json_output)
                raise typer.Exit(code=2)

            artifacts = client.get_artifacts(job.job_id)

            if json_output:
                payload: dict[str, Any] = {
                    "ok": job.result == "passed",
                    "mode": "remote",
                    "job_id": job.job_id,
                    "status": job.status,
                    "result": job.result,
                    "output": job.output,
                    "error_message": job.error_message,
                    "artifacts": [
                        {
                            "name": a.name,
                            "size_bytes": a.size_bytes,
                            "content_type": a.content_type,
                            "download_url": a.download_url,
                        }
                        for a in artifacts.artifacts
                    ],
                }
                typer.echo(json.dumps(payload))
            else:
                _display_result(job.status, job.result, job.output, job.error_message)
                if artifacts.artifacts:
                    dest_dir = Path("picolayer-results") / job.job_id
                    dest_dir.mkdir(parents=True, exist_ok=True)
                    for artifact in artifacts.artifacts:
                        dest = dest_dir / artifact.name
                        client.download_artifact(artifact.download_url, dest)
                    console.print(f"\n[dim]Artifacts saved to {dest_dir}[/dim]")

            if job.result != "passed":
                raise typer.Exit(code=1)

    except ApiError as e:
        _emit_error(f"API error: {e.detail}", json_output)
        raise typer.Exit(code=1) from None


def _stream_artifacts(
    client: object,
    job_id: str,
    seen_lines: int,
) -> int:
    """Fetch transcript artifacts and print new lines. Returns updated line count."""
    from picolayer.api_client import PicolayerClient

    assert isinstance(client, PicolayerClient)
    try:
        artifact_list = client.get_artifacts(job_id)
        for artifact in artifact_list.artifacts:
            if artifact.name.endswith("_transcript.txt"):
                import httpx

                resp = httpx.get(artifact.download_url)
                if resp.status_code == 200:
                    lines = resp.text.splitlines()
                    for line in lines[seen_lines:]:
                        console.print(f"  [dim]UART>[/dim] {line}")
                    return len(lines)
    except httpx.HTTPError:
        console.print(f"[dim red]Failed to fetch artifacts for job {job_id}[/dim red]")
    except Exception as exc:
        console.print(f"[dim red]Artifact streaming error: {exc}[/dim red]")
    return seen_lines


def _display_result(
    status: str,
    result: str | None,
    output: str | None,
    error_message: str | None,
) -> None:
    """Print a formatted test result summary."""
    console.print()
    if result == "passed":
        console.print("[bold green]PASSED[/bold green]")
    elif result == "failed":
        console.print("[bold red]FAILED[/bold red]")
    else:
        console.print(f"[bold yellow]{status.upper()}[/bold yellow]")

    if output:
        console.print(f"\n[dim]Output:[/dim]\n{output[:2000]}")
    if error_message:
        console.print(f"\n[red]Error:[/red] {error_message}")
