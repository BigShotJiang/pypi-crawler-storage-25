#!/usr/bin/env python3
"""
Anki CLI - A comprehensive command-line interface for Anki via AnkiConnect
Requires: Anki with AnkiConnect plugin installed (https://ankiweb.net/shared/info/2055492159)

Full API Reference: https://github.com/FooSoft/anki-connect
"""

import json
import urllib.request
import urllib.error
import argparse
import sys
from typing import Any, Optional

ANKICONECT_URL = "http://localhost:8765"

def invoke(action: str, params: Optional[dict] = None) -> Any:
    """Invoke an AnkiConnect API action"""
    request_body = {
        "action": action,
        "version": 6
    }
    if params:
        request_body["params"] = params

    try:
        data = json.dumps(request_body).encode('utf-8')
        req = urllib.request.Request(ANKICONECT_URL, data=data,
                                      headers={'Content-Type': 'application/json'})
        with urllib.request.urlopen(req, timeout=30) as response:
            result = json.loads(response.read().decode('utf-8'))
            if "error" in result and result["error"]:
                raise Exception(result["error"])
            return result.get("result")
    except urllib.error.URLError as e:
        print(f"Error: Cannot connect to AnkiConnect at {ANKICONECT_URL}", file=sys.stderr)
        print("Make sure Anki is running with AnkiConnect plugin installed.", file=sys.stderr)
        sys.exit(1)
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)

def cmd_version(args):
    """Get AnkiConnect version"""
    result = invoke("version")
    print(f"AnkiConnect API Version: {result}")

def cmd_sync(args):
    """Sync Anki with AnkiWeb"""
    result = invoke("sync")
    print("Sync completed" if result is not None else "Sync failed or not needed")

def cmd_profiles(args):
    """List all profiles"""
    profiles = invoke("getProfiles")
    if profiles:
        print("Profiles:")
        for p in profiles:
            print(f"  - {p}")
    else:
        print("No profiles found")

def cmd_deck_list(args):
    """List all decks"""
    decks = invoke("deckNames")
    if decks:
        print("Decks:")
        for deck in decks:
            print(f"  - {deck}")
    else:
        print("No decks found")

def cmd_deck_ids(args):
    """List all decks with IDs"""
    decks = invoke("deckNamesAndIds")
    if decks:
        print("Decks:")
        for name, id in decks.items():
            print(f"  - {name} (ID: {id})")
    else:
        print("No decks found")

def cmd_deck_stats(args):
    """Get deck statistics"""
    stats = invoke("getDeckStats", {"deckName": args.deck})
    if stats:
        print(f"Deck: {args.deck}")
        print(f"  Total cards: {stats.get('total', 'N/A')}")
        print(f"  New: {stats.get('new', 'N/A')}")
        print(f"  Learning: {stats.get('learning', 'N/A')}")
        print(f"  Review: {stats.get('review', 'N/A')}")
    else:
        print("No stats found")

def cmd_create_deck(args):
    """Create a new deck"""
    result = invoke("createDeck", {"deck": args.name})
    if result:
        print(f"Deck '{args.name}' created with ID: {result}")
    else:
        print("Failed to create deck")

def cmd_delete_deck(args):
    """Delete decks"""
    result = invoke("deleteDecks", {"decks": args.decks, "cardsToo": args.cards})
    print(f"Deleted {len(args.decks)} decks")

def cmd_model_list(args):
    """List all note models"""
    models = invoke("modelNames")
    if models:
        print("Models:")
        for model in models:
            print(f"  - {model}")
    else:
        print("No models found")

def cmd_model_fields(args):
    """Get model field names"""
    fields = invoke("modelFieldNames", {"modelName": args.model})
    if fields:
        print(f"Fields for model '{args.model}':")
        for field in fields:
            print(f"  - {field}")
    else:
        print("No fields found")

def cmd_create_model(args):
    """Create a new note model"""
    fields = args.fields.split(",") if args.fields else []
    templates = []
    if args.css:
        with open(args.css, 'r', encoding='utf-8') as f:
            css = f.read()
    else:
        css = ""

    result = invoke("createModel", {
        "modelName": args.name,
        "inOrderFields": fields,
        "css": css,
        "cardCount": 1
    })
    if result:
        print(f"Model '{args.name}' created")
    else:
        print("Failed to create model")

def cmd_find_cards(args):
    """Search for cards"""
    cards = invoke("findCards", {"query": args.query})
    if cards:
        print(f"Found {len(cards)} cards:")
        for card_id in cards[:args.limit]:
            print(f"  - {card_id}")
        if len(cards) > args.limit:
            print(f"  ... and {len(cards) - args.limit} more")
    else:
        print("No cards found")

def cmd_find_notes(args):
    """Search for notes"""
    notes = invoke("findNotes", {"query": args.query})
    if notes:
        print(f"Found {len(notes)} notes:")
        for note_id in notes[:args.limit]:
            print(f"  - {note_id}")
        if len(notes) > args.limit:
            print(f"  ... and {len(notes) - args.limit} more")
    else:
        print("No notes found")

def cmd_cards_info(args):
    """Get card information"""
    info = invoke("cardsInfo", {"cards": [int(args.card_id)]})
    if info and len(info) > 0:
        card = info[0]
        print(f"Card ID: {card['cardId']}")
        print(f"Note ID: {card['note']}")
        print(f"Deck: {card['deckName']}")
        print(f"Type: {card['type']}")
        print(f"Queue: {card['queue']}")
        print(f"Dues: {card['due']}")
        print(f"Interval: {card['interval']}")
        print(f"Reps: {card['reps']}")
        print(f"Lapses: {card['lapses']}")
    else:
        print("Card not found")

def cmd_notes_info(args):
    """Get note information"""
    note_ids = [int(n) for n in args.note_ids]
    info = invoke("notesInfo", {"notes": note_ids})
    if info:
        for note in info:
            print(f"Note ID: {note['noteId']}")
            print(f"  Deck: {note['deckName']}")
            print(f"  Model: {note['modelName']}")
            print(f"  Tags: {', '.join(note['tags'])}")
            print(f"  Fields:")
            for field_name, field_value in note['fields'].items():
                print(f"    {field_name}: {field_value}")
            print()
    else:
        print("No notes found")

def cmd_add_note(args):
    """Add a new note"""
    note = {
        "deckName": args.deck,
        "modelName": args.model,
        "fields": {},
        "tags": args.tags.split(",") if args.tags else [],
        "options": {}
    }

    # Parse fields (format: FieldName:Value)
    for field in args.fields:
        if ":" in field:
            key, value = field.split(":", 1)
            note["fields"][key] = value

    result = invoke("addNote", {"note": note})
    if result:
        print(f"Note added with ID: {result}")
    else:
        print("Failed to add note. Make sure deck and model exist.")

def cmd_add_notes(args):
    """Add multiple notes from a file"""
    notes = []
    with open(args.file, 'r', encoding='utf-8') as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith('#'):
                continue
            parts = line.split(args.delimiter)
            if len(parts) >= 2:
                note = {
                    "deckName": args.deck,
                    "modelName": args.model,
                    "fields": {"Front": parts[0], "Back": parts[1]},
                    "tags": args.tags.split(",") if args.tags else []
                }
                notes.append(note)

    if notes:
        results = invoke("addNotes", {"notes": notes})
        print(f"Added {len([r for r in results if r])} of {len(notes)} notes")
    else:
        print("No notes to add")

def cmd_update_note_fields(args):
    """Update note fields"""
    fields = {}
    for field in args.fields:
        if ":" in field:
            key, value = field.split(":", 1)
            fields[key] = value

    result = invoke("updateNoteFields", {
        "note": {
            "id": int(args.note_id),
            "fields": fields
        }
    })
    print(f"Note {args.note_id} updated")

def cmd_get_note_tags(args):
    """Get tags for a note"""
    tags = invoke("getNoteTags", {"note": int(args.note_id)})
    if tags:
        print(f"Tags for note {args.note_id}:")
        for tag in tags:
            print(f"  - {tag}")
    else:
        print("No tags found")

def cmd_add_tags(args):
    """Add tags to notes"""
    note_ids = [int(n) for n in args.note_ids]
    result = invoke("addTags", {"notes": note_ids, "tags": args.tags})
    print(f"Added tags to {len(note_ids)} notes")

def cmd_remove_tags(args):
    """Remove tags from notes"""
    note_ids = [int(n) for n in args.note_ids]
    result = invoke("removeTags", {"notes": note_ids, "tags": args.tags})
    print(f"Removed tags from {len(note_ids)} notes")

def cmd_clear_unused_tags(args):
    """Clear unused tags"""
    result = invoke("clearUnusedTags")
    print("Cleared unused tags")

def cmd_replace_tags(args):
    """Replace tags on notes"""
    note_ids = [int(n) for n in args.note_ids]
    result = invoke("replaceTags", {
        "notes": note_ids,
        "tagToReplace": args.old_tag,
        "newTag": args.new_tag
    })
    print(f"Replaced tag '{args.old_tag}' with '{args.new_tag}'")

def cmd_delete_notes(args):
    """Delete notes"""
    note_ids = [int(n) for n in args.note_ids]
    result = invoke("deleteNotes", {"notes": note_ids})
    print(f"Deleted {result} notes")

def cmd_suspend(args):
    """Suspend notes"""
    note_ids = [int(n) for n in args.note_ids]
    result = invoke("suspendNotes", {"notes": note_ids})
    print(f"Suspended {len(note_ids)} notes")

def cmd_unsuspend(args):
    """Unsuspend notes"""
    note_ids = [int(n) for n in args.note_ids]
    result = invoke("unsuspendNotes", {"notes": note_ids})
    print(f"Unsuspended {len(note_ids)} notes")

def cmd_are_suspended(args):
    """Check if notes are suspended"""
    note_ids = [int(n) for n in args.note_ids]
    results = invoke("areSuspended", {"notes": note_ids})
    for note_id, suspended in zip(note_ids, results):
        print(f"Note {note_id}: {'Suspended' if suspended else 'Not suspended'}")

def cmd_are_due(args):
    """Check if cards are due"""
    card_ids = [int(n) for n in args.card_ids]
    results = invoke("areDue", {"cards": card_ids})
    for card_id, due in zip(card_ids, results):
        print(f"Card {card_id}: {'Due' if due else 'Not due'}")

def cmd_set_due_date(args):
    """Set due date for cards"""
    card_ids = [int(n) for n in args.card_ids]
    result = invoke("setDueDate", {
        "cards": card_ids,
        "days": args.days
    })
    print(f"Set due date for {len(card_ids)} cards")

def cmd_forget_cards(args):
    """Reset cards to new state"""
    card_ids = [int(n) for n in args.card_ids]
    result = invoke("forgetCards", {"cards": card_ids, "deleteData": args.delete_data})
    print(f"Reset {len(card_ids)} cards to new state")

def cmd_relearn_cards(args):
    """Reset cards to relearning state"""
    card_ids = [int(n) for n in args.card_ids]
    result = invoke("relearnCards", {"cards": card_ids})
    print(f"Set {len(card_ids)} cards to relearning state")

def cmd_answer_card(args):
    """Answer a card (for review)"""
    result = invoke("answerCard", {"card": int(args.card_id), "ease": int(args.ease)})
    print(f"Card {args.card_id} answered with ease {args.ease}")

def cmd_gui_add_cards(args):
    """Open Add Cards dialog"""
    result = invoke("guiAddCards", {"note": {
        "deckName": args.deck,
        "modelName": args.model,
        "fields": {},
        "tags": args.tags.split(",") if args.tags else []
    }})
    print("Add Cards dialog opened")

def cmd_gui_edit_note(args):
    """Open Edit Note dialog"""
    result = invoke("guiEditNote", {"note": int(args.note_id)})
    if result:
        print(f"Edit dialog opened for note {args.note_id}")
    else:
        print("Note not found")

def cmd_gui_current_card(args):
    """Get current card being reviewed"""
    card = invoke("guiCurrentCard")
    if card:
        print(f"Card ID: {card.get('cardId', 'N/A')}")
        print(f"Deck: {card.get('deckName', 'N/A')}")
        print(f"Question: {card.get('question', 'N/A')[:100]}...")
        print(f"Answer: {card.get('answer', 'N/A')[:100]}...")
    else:
        print("No card is currently being reviewed")

def cmd_gui_show_question(args):
    """Show question of current card"""
    invoke("guiShowQuestion")
    print("Question shown")

def cmd_gui_show_answer(args):
    """Show answer of current card"""
    invoke("guiShowAnswer")
    print("Answer shown")

def cmd_gui_start_timer(args):
    """Start the review timer"""
    invoke("guiStartCardTimer")
    print("Timer started")

def cmd_gui_deck_browser(args):
    """Open Deck Browser"""
    invoke("guiDeckBrowser")
    print("Deck Browser opened")

def cmd_gui_deck_overview(args):
    """Open Deck Overview"""
    invoke("guiDeckOverview", {"name": args.deck})
    print(f"Deck Overview opened for '{args.deck}'")

def cmd_gui_deck_review(args):
    """Start reviewing a deck"""
    invoke("guiDeckReview", {"name": args.deck})
    print(f"Deck Review started for '{args.deck}'")

def cmd_gui_browse(args):
    """Open Browser with search"""
    invoke("guiBrowse", {"query": args.query})
    print(f"Browser opened with query: {args.query}")

def cmd_gui_exit(args):
    """Close Anki"""
    invoke("guiExitAnki")
    print("Anki is closing")

def cmd_gui_undo(args):
    """Undo last action"""
    invoke("guiUndo")
    print("Undo performed")

def cmd_check_database(args):
    """Check database for corruption"""
    invoke("guiCheckDatabase")
    print("Database check initiated")

def cmd_today_stats(args):
    """Get today's review count"""
    result = invoke("getNumCardsReviewedToday")
    print(f"Cards reviewed today: {result}")

def cmd_reviews_by_day(args):
    """Get reviews by day"""
    result = invoke("getNumCardsReviewedByDay")
    if result:
        print("Reviews by day:")
        for day, count in result:
            print(f"  {day}: {count} cards")

def cmd_collection_stats(args):
    """Get collection statistics as HTML"""
    html = invoke("getCollectionStatsHTML")
    if html:
        print("Collection Statistics (HTML):")
        print(html[:500] + "..." if len(html) > 500 else html)
    else:
        print("No stats available")

def cmd_media_files(args):
    """List media files"""
    files = invoke("getMediaFilesNames")
    if files:
        print("Media files:")
        for f in files[:args.limit]:
            print(f"  - {f}")
        if len(files) > args.limit:
            print(f"  ... and {len(files) - args.limit} more")
    else:
        print("No media files found")

def cmd_store_media(args):
    """Store a media file"""
    result = invoke("storeMediaFile", {
        "filename": args.filename,
        "data": args.data,  # Base64 encoded
        "deleteExisting": args.delete
    })
    print(f"Media file stored: {args.filename}")

def cmd_export_package(args):
    """Export a deck as .apkg"""
    result = invoke("exportPackage", {
        "deck": args.deck,
        "path": args.path
    })
    print(f"Exported deck '{args.deck}' to {args.path}")

def cmd_import_package(args):
    """Import a .apkg file"""
    result = invoke("importPackage", {"path": args.path})
    print(f"Imported package from {args.path}")

def cmd_multi(args):
    """Execute multiple actions in one request"""
    actions = []
    with open(args.file, 'r', encoding='utf-8') as f:
        for line in f:
            line = line.strip()
            if line and not line.startswith('#'):
                action = json.loads(line)
                actions.append(action)

    result = invoke("multi", {"actions": actions})
    if result:
        print(f"Executed {len(result)} actions:")
        for i, r in enumerate(result):
            if r.get('error'):
                print(f"  [{i}] Error: {r['error']}")
            else:
                print(f"  [{i}] OK: {r.get('result', 'N/A')}")

def main():
    parser = argparse.ArgumentParser(
        prog="anki-cli",
        description="Command-line interface for Anki via AnkiConnect"
    )
    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # ===== Version & System =====
    p = subparsers.add_parser("version", help="Get AnkiConnect version")
    p.set_defaults(func=cmd_version)

    p = subparsers.add_parser("sync", help="Sync with AnkiWeb")
    p.set_defaults(func=cmd_sync)

    p = subparsers.add_parser("profiles", help="List all profiles")
    p.set_defaults(func=cmd_profiles)

    p = subparsers.add_parser("check-database", help="Check database for corruption")
    p.set_defaults(func=cmd_check_database)

    # ===== Deck Operations =====
    p = subparsers.add_parser("deck-list", help="List all decks")
    p.set_defaults(func=cmd_deck_list)

    p = subparsers.add_parser("deck-ids", help="List all decks with IDs")
    p.set_defaults(func=cmd_deck_ids)

    p = subparsers.add_parser("deck-stats", help="Get deck statistics")
    p.add_argument("deck", help="Deck name")
    p.set_defaults(func=cmd_deck_stats)

    p = subparsers.add_parser("create-deck", help="Create a new deck")
    p.add_argument("name", help="Deck name")
    p.set_defaults(func=cmd_create_deck)

    p = subparsers.add_parser("delete-deck", help="Delete decks")
    p.add_argument("decks", nargs="+", help="Deck names to delete")
    p.add_argument("--cards", action="store_true", help="Also delete cards")
    p.set_defaults(func=cmd_delete_deck)

    # ===== Model Operations =====
    p = subparsers.add_parser("model-list", help="List all note models")
    p.set_defaults(func=cmd_model_list)

    p = subparsers.add_parser("model-fields", help="Get model field names")
    p.add_argument("model", help="Model name")
    p.set_defaults(func=cmd_model_fields)

    p = subparsers.add_parser("create-model", help="Create a new note model")
    p.add_argument("name", help="Model name")
    p.add_argument("fields", help="Comma-separated field names")
    p.add_argument("--css", help="Path to CSS file")
    p.set_defaults(func=cmd_create_model)

    # ===== Note/Card Search =====
    p = subparsers.add_parser("find-cards", help="Search for cards")
    p.add_argument("query", help="Search query (Anki search syntax)")
    p.add_argument("--limit", "-l", type=int, default=20, help="Max results to show")
    p.set_defaults(func=cmd_find_cards)

    p = subparsers.add_parser("find-notes", help="Search for notes")
    p.add_argument("query", help="Search query (Anki search syntax)")
    p.add_argument("--limit", "-l", type=int, default=20, help="Max results to show")
    p.set_defaults(func=cmd_find_notes)

    p = subparsers.add_parser("cards-info", help="Get card information")
    p.add_argument("card_id", help="Card ID")
    p.set_defaults(func=cmd_cards_info)

    p = subparsers.add_parser("notes-info", help="Get note information")
    p.add_argument("note_ids", nargs="+", help="Note IDs")
    p.set_defaults(func=cmd_notes_info)

    # ===== Note Operations =====
    p = subparsers.add_parser("add-note", help="Add a new note")
    p.add_argument("--deck", "-d", required=True, help="Deck name")
    p.add_argument("--model", "-m", default="Basic", help="Model name")
    p.add_argument("--tags", "-t", default="", help="Comma-separated tags")
    p.add_argument("fields", nargs="+", help="Fields in FieldName:Value format")
    p.set_defaults(func=cmd_add_note)

    p = subparsers.add_parser("add-notes", help="Add multiple notes from file")
    p.add_argument("--deck", "-d", required=True, help="Deck name")
    p.add_argument("--model", "-m", default="Basic", help="Model name")
    p.add_argument("--tags", "-t", default="", help="Comma-separated tags")
    p.add_argument("--delimiter", default="\\t", help="Field delimiter")
    p.add_argument("file", help="File with notes (one per line)")
    p.set_defaults(func=cmd_add_notes)

    p = subparsers.add_parser("update-note", help="Update note fields")
    p.add_argument("note_id", help="Note ID")
    p.add_argument("fields", nargs="+", help="Fields in FieldName:Value format")
    p.set_defaults(func=cmd_update_note_fields)

    p = subparsers.add_parser("get-note-tags", help="Get tags for a note")
    p.add_argument("note_id", help="Note ID")
    p.set_defaults(func=cmd_get_note_tags)

    p = subparsers.add_parser("add-tags", help="Add tags to notes")
    p.add_argument("note_ids", nargs="+", help="Note IDs")
    p.add_argument("tags", help="Tags to add")
    p.set_defaults(func=cmd_add_tags)

    p = subparsers.add_parser("remove-tags", help="Remove tags from notes")
    p.add_argument("note_ids", nargs="+", help="Note IDs")
    p.add_argument("tags", help="Tags to remove")
    p.set_defaults(func=cmd_remove_tags)

    p = subparsers.add_parser("clear-tags", help="Clear unused tags")
    p.set_defaults(func=cmd_clear_unused_tags)

    p = subparsers.add_parser("replace-tags", help="Replace tags on notes")
    p.add_argument("note_ids", nargs="+", help="Note IDs")
    p.add_argument("old_tag", help="Tag to replace")
    p.add_argument("new_tag", help="New tag")
    p.set_defaults(func=cmd_replace_tags)

    p = subparsers.add_parser("delete-notes", help="Delete notes")
    p.add_argument("note_ids", nargs="+", help="Note IDs to delete")
    p.set_defaults(func=cmd_delete_notes)

    # ===== Card State Operations =====
    p = subparsers.add_parser("suspend", help="Suspend notes")
    p.add_argument("note_ids", nargs="+", help="Note IDs to suspend")
    p.set_defaults(func=cmd_suspend)

    p = subparsers.add_parser("unsuspend", help="Unsuspend notes")
    p.add_argument("note_ids", nargs="+", help="Note IDs to unsuspend")
    p.set_defaults(func=cmd_unsuspend)

    p = subparsers.add_parser("are-suspended", help="Check if notes are suspended")
    p.add_argument("note_ids", nargs="+", help="Note IDs")
    p.set_defaults(func=cmd_are_suspended)

    p = subparsers.add_parser("are-due", help="Check if cards are due")
    p.add_argument("card_ids", nargs="+", help="Card IDs")
    p.set_defaults(func=cmd_are_due)

    p = subparsers.add_parser("set-due-date", help="Set due date for cards")
    p.add_argument("card_ids", nargs="+", help="Card IDs")
    p.add_argument("days", type=int, help="Days from now (negative for past)")
    p.set_defaults(func=cmd_set_due_date)

    p = subparsers.add_parser("forget", help="Reset cards to new state")
    p.add_argument("card_ids", nargs="+", help="Card IDs")
    p.add_argument("--delete-data", action="store_true", help="Delete learning data")
    p.set_defaults(func=cmd_forget_cards)

    p = subparsers.add_parser("relearn", help="Reset cards to relearning state")
    p.add_argument("card_ids", nargs="+", help="Card IDs")
    p.set_defaults(func=cmd_relearn_cards)

    p = subparsers.add_parser("answer", help="Answer a card")
    p.add_argument("card_id", help="Card ID")
    p.add_argument("ease", type=int, choices=[1, 2, 3, 4], help="Ease rating (1-4)")
    p.set_defaults(func=cmd_answer_card)

    # ===== GUI Operations =====
    p = subparsers.add_parser("gui-add", help="Open Add Cards dialog")
    p.add_argument("--deck", "-d", help="Deck name")
    p.add_argument("--model", "-m", help="Model name")
    p.add_argument("--tags", "-t", help="Tags")
    p.set_defaults(func=cmd_gui_add_cards)

    p = subparsers.add_parser("gui-edit", help="Open Edit Note dialog")
    p.add_argument("note_id", help="Note ID")
    p.set_defaults(func=cmd_gui_edit_note)

    p = subparsers.add_parser("gui-current", help="Get current card being reviewed")
    p.set_defaults(func=cmd_gui_current_card)

    p = subparsers.add_parser("gui-question", help="Show question of current card")
    p.set_defaults(func=cmd_gui_show_question)

    p = subparsers.add_parser("gui-answer", help="Show answer of current card")
    p.set_defaults(func=cmd_gui_show_answer)

    p = subparsers.add_parser("gui-timer", help="Start the review timer")
    p.set_defaults(func=cmd_gui_start_timer)

    p = subparsers.add_parser("gui-browser", help="Open Browser with search")
    p.add_argument("query", help="Search query")
    p.set_defaults(func=cmd_gui_browse)

    p = subparsers.add_parser("gui-deck-browser", help="Open Deck Browser")
    p.set_defaults(func=cmd_gui_deck_browser)

    p = subparsers.add_parser("gui-deck-overview", help="Open Deck Overview")
    p.add_argument("deck", help="Deck name")
    p.set_defaults(func=cmd_gui_deck_overview)

    p = subparsers.add_parser("gui-review", help="Start reviewing a deck")
    p.add_argument("deck", help="Deck name")
    p.set_defaults(func=cmd_gui_deck_review)

    p = subparsers.add_parser("gui-undo", help="Undo last action")
    p.set_defaults(func=cmd_gui_undo)

    p = subparsers.add_parser("gui-exit", help="Close Anki")
    p.set_defaults(func=cmd_gui_exit)

    # ===== Statistics =====
    p = subparsers.add_parser("today-stats", help="Get today's review count")
    p.set_defaults(func=cmd_today_stats)

    p = subparsers.add_parser("reviews-by-day", help="Get reviews by day")
    p.set_defaults(func=cmd_reviews_by_day)

    p = subparsers.add_parser("collection-stats", help="Get collection statistics")
    p.set_defaults(func=cmd_collection_stats)

    # ===== Media Operations =====
    p = subparsers.add_parser("media-list", help="List media files")
    p.add_argument("--limit", "-l", type=int, default=20, help="Max files to show")
    p.set_defaults(func=cmd_media_files)

    p = subparsers.add_parser("media-store", help="Store a media file")
    p.add_argument("filename", help="Filename to save as")
    p.add_argument("data", help="Base64 encoded data")
    p.add_argument("--delete", action="store_true", help="Delete existing file")
    p.set_defaults(func=cmd_store_media)

    # ===== Import/Export =====
    p = subparsers.add_parser("export", help="Export a deck as .apkg")
    p.add_argument("deck", help="Deck name")
    p.add_argument("path", help="Output path")
    p.set_defaults(func=cmd_export_package)

    p = subparsers.add_parser("import", help="Import a .apkg file")
    p.add_argument("path", help="File path")
    p.set_defaults(func=cmd_import_package)

    # ===== Advanced =====
    p = subparsers.add_parser("multi", help="Execute multiple actions from file")
    p.add_argument("file", help="File with JSON actions (one per line)")
    p.set_defaults(func=cmd_multi)

    args = parser.parse_args()

    if args.command is None:
        parser.print_help()
        sys.exit(0)

    args.func(args)

if __name__ == "__main__":
    main()
