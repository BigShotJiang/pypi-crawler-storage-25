# llm-consensus 🗳️

**Stop trusting one LLM. Start trusting the crowd.**

`llm-consensus` queries multiple language models simultaneously via [OpenRouter](https://openrouter.ai), semantically clusters their responses, and returns a high-confidence consensus answer — complete with a confidence score, agreement rate, and dissent detection.

```python
from llm_consensus import Consensus

c = Consensus(api_key="sk-or-...")
result = c.ask("Is it safe to take ibuprofen with coffee?")

print(result.answer)        # The winning answer
print(result.confidence)    # e.g. 0.87
print(result.summary())
```

```
CONSENSUS (87% confidence, 80% agreement)
  Answer: Yes, taking ibuprofen with coffee is generally safe for most people...
  Models: 5/5 responded
  Clusters: 2 distinct viewpoints
  ⚠  Dissent detected (1 minority view)
```

---

## Why?

Single LLMs hallucinate, have biases, and can be confidently wrong.  
**Consensus voting across diverse models reduces individual model error** — the same insight behind ensemble methods in ML.

| Scenario | Single LLM | llm-consensus |
|---|---|---|
| Factual Q&A | May hallucinate confidently | High agreement = high trust signal |
| Controversial topics | One model's bias | Surfaces genuine disagreement |
| Medical / legal / financial | Single point of failure | Minority views flagged explicitly |
| Code review | One perspective | Multiple architectural opinions |

---

## Installation

```bash
pip install llm-consensus
```

For better semantic clustering (optional, recommended):
```bash
pip install "llm-consensus[rich-embeddings]"
```

Without `rich-embeddings`, clustering uses TF-IDF cosine similarity (fast, no GPU needed). With it, `sentence-transformers` provides much better semantic grouping.

---

## Quick Start

### 1. Pick a model panel

```python
from llm_consensus import Consensus, OPENROUTER_MODELS

# Built-in presets
c = Consensus(api_key="sk-or-...", models="balanced")   # default
c = Consensus(api_key="sk-or-...", models="fast")        # cheap & quick
c = Consensus(api_key="sk-or-...", models="power")       # best models
c = Consensus(api_key="sk-or-...", models="diverse")     # max diversity

# Or bring your own list
c = Consensus(
    api_key="sk-or-...",
    models=[
        "openai/gpt-4o",
        "anthropic/claude-3.5-sonnet",
        "google/gemini-pro-1.5",
    ]
)
```

### 2. Ask a question

```python
result = c.ask("What year did the Berlin Wall fall?")
print(result.answer)          # "The Berlin Wall fell in 1989."
print(result.agreement_rate)  # 1.0 — unanimous
print(result.is_unanimous)    # True
```

### 3. Read the full result

```python
result = c.ask("Should I use tabs or spaces in Python?")

# The winning answer
print(result.answer)

# Confidence breakdown
print(f"Confidence:   {result.confidence:.0%}")
print(f"Agreement:    {result.agreement_rate:.0%}")
print(f"Models:       {result.models_succeeded}/{result.models_queried}")

# All distinct viewpoints
for i, cluster in enumerate(result.clusters):
    print(f"\nViewpoint {i+1} ({cluster.size} models agree):")
    print(f"  {cluster.representative[:120]}")
    print(f"  Models: {', '.join(cluster.model_names)}")

# Minority views (never ignore these)
if result.has_dissent:
    print("\n⚠  Dissenting views:")
    for view in result.dissenting_views:
        print(f"  - {view[:100]}")
```

### 4. Async usage

```python
import asyncio
from llm_consensus import Consensus

async def main():
    c = Consensus(api_key="sk-or-...", models="balanced")
    result = await c.ask_async("Explain quantum entanglement in one sentence.")
    print(result.summary())

asyncio.run(main())
```

### 5. Structured output

```python
result = c.ask_structured(
    question="Is Python or Rust better for systems programming? Rate your confidence.",
    schema_hint='Return JSON: {"verdict": str, "confidence": float, "reasoning": str}',
)
# Models are prompted to return structured JSON — consensus is on the parsed content
print(result.answer)
```

---

## Configuration

```python
c = Consensus(
    api_key="sk-or-...",
    models="balanced",
    similarity_threshold=0.72,  # 0=anything groups together, 1=exact match only
    max_tokens=512,             # per model
    timeout=30.0,               # seconds per model
    system_prompt="You are a medical expert. Answer precisely.",
)
```

---

## Model Presets

| Preset | Models | Cost | Speed | Best for |
|---|---|---|---|---|
| `"fast"` | 4 × 7-9B models | $ | ⚡⚡⚡ | High-volume, factual Q&A |
| `"balanced"` | 5 mixed models | $$ | ⚡⚡ | General use (default) |
| `"power"` | 5 frontier models | $$$$ | ⚡ | High-stakes decisions |
| `"diverse"` | 6 diverse models | $$ | ⚡⚡ | Surfacing disagreement |

---

## How It Works

```
Question ──┬──► Model A ──► "Paris"           ─┐
           ├──► Model B ──► "Paris, France"    ─┤ Cluster 1 (size=3, score=0.94)
           ├──► Model C ──► "The city of Paris"─┘
           ├──► Model D ──► "Lyon"              ── Cluster 2 (size=1, score=1.0)  ← dissent
           └──► Model E ──► "Paris"             ── Cluster 1 (merged)

Winner: Cluster 1  →  confidence = 0.75 * 0.94 = 0.71
```

1. **Parallel querying** — all models called concurrently via `httpx.AsyncClient`
2. **Semantic clustering** — TF-IDF cosine similarity (or `sentence-transformers`)  
3. **Voting** — largest cluster wins; its best answer is the consensus
4. **Confidence scoring** — `agreement_rate × internal_coherence`
5. **Dissent reporting** — minority clusters surfaced explicitly

---

## Use Cases

- **Medical / legal / financial Q&A** — flag when models disagree before trusting an answer
- **Fact-checking** — unanimous agreement is a strong truth signal
- **Code review** — surface multiple architectural opinions
- **Debate preparation** — use `diverse` preset to find genuine counterarguments
- **RAG validation** — verify retrieved context against model consensus
- **Exam generation** — high-confidence questions, flag ambiguous ones

---

## License

MIT
