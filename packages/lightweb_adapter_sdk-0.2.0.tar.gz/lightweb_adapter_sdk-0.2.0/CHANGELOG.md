# Changelog

All notable changes to the Lightweb adapter SDK are documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/), and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html). See [`CONVENTIONS.md`](CONVENTIONS.md) §1 for the SDK's specific versioning discipline, including what counts as a breaking change.

Breaking changes are flagged with `**BREAKING:**` at the start of the entry, even within their category.

The SDK is in 0.x until its contract has been validated by at least one production adapter. Per [`CONVENTIONS.md`](CONVENTIONS.md) §1.3, breaking changes may land in minor (0.X → 0.(X+1)) releases while in 0.x; pin against a specific minor version.

## [0.2.0] - 2026-05-20

### Changed (BREAKING)

- **`current_state` semantics: echo → observed app state.** The
  `current_state` field on `AppAccount` (returned by `apply()` and
  `list_accounts()`) is now observed app state — what the adapter reads
  back from the target app — rather than an echo of the applied
  entitlements. This aligns the reference adapter and conformance suite
  with the contract specification in `docs/contract.md` §2.2 and §2.6
  (already stated since 0.1.3). Adapter authors must implement
  `current_state` as observed app state; adapters that echo entitlements
  will fail the new conformance assertions. `current_state` holds only
  adapter-controlled, drift-relevant observed properties (not
  user-controlled varying data such as storage usage); the reference
  adapter's `current_state` no longer includes `storage_used_mb`.
- **BREAKING:** New required `adapter_observed_state_example` conformance
  fixture. Adapter authors must provide this fixture in their
  `conftest.py`: a dict declaring a known desired→observed example that
  the observed-state conformance tests assert against. Without this
  fixture, tests that verify `current_state` is observed (not echoed)
  will fail with fixture-not-found errors.
- **BREAKING:** Reworked and added conformance tests:
  - `test_apply_creates_account_on_first_call`: removed echo assertion;
    now asserts only account-creation (AppAccount, status "active").
  - `test_apply_current_state_is_observed_not_desired` (NEW): asserts
    that the declared observed key IS present and the desired key IS
    absent in `current_state`. Pure-echo adapters fail.
  - `test_apply_current_state_consistent_with_read_back` (NEW): asserts
    that `apply()`'s `current_state` matches `list_accounts()` read-back
    for the same member.
  - `test_apply_replaces_state_rather_than_merging`: now asserts on
    observed projection of dropped key being absent.
  - `test_list_accounts_current_state_is_observed_not_desired` (NEW):
    asserts observed-state shape for listed accounts.
  - `test_reconcile_account_exists_entitlements_differ`: TRANSITIONAL
    markers removed; `expected`/`actual` stay in entitlement-value terms
    via the adapter's reverse mapping.

### Fixed

- Unit tests that inspected the fake server's internal state now use
  observed-state keys (`storage_quota_mb`, `seat_count`,
  `feature_x_enabled`) instead of desired feature keys.

## [0.1.3] - 2026-05-20

### Fixed

- Contract §2.2 internal inconsistency on `current_state` shape (introduced in 0.1.2). The 0.1.2 contract revision added prose describing `current_state` as a feature-key echo of the entitlements (`current_state[feature_key] = applied_value`), which directly contradicted the §2.2 example — present since before 0.1.0 — showing observed app values (`storage_used_mb`, `sharing_enabled`). The contract now consistently describes `current_state` as observed app state across §2.2 and §2.6.

### Documentation

- Contract §2.2 `current_state` prose rewritten: `current_state` is observed app state (what the adapter reads back from the target app), not an echo of the entitlements. This is what lets the reconciler (§2.4, §2.6) detect drift between desired and actual state — an echo would deprive the reconciler of an independent observation. The semantic intent is now stated explicitly with rationale.
- Contract §2.6 `list_accounts` example's `current_state` is now non-empty, showing the observed-value shape (matching §2.2). Previously empty (`{}`), which gave adapter authors no signal about the intended shape — the root cause of the original inconsistency, since the §2.2 example showed observed values while §2.6 showed nothing.
- Transitional note added to §2.2: the observed-state semantics are the contract's intent, but the 0.1.x conformance suite and reference adapter still implement the echo shape. 0.2.0 will redesign both to assert and demonstrate observed-state semantics. Adapter authors targeting 0.2.0 should implement `current_state` as observed app state.
- Conformance tests `test_apply.py` and `test_reconcile.py` carry transitional comments marking the `current_state` echo-shape assertions as 0.1.x behavior pending the 0.2.0 redesign. The assertions are NOT marked xfail — the reference adapter still echoes in 0.1.x, so they still pass.

### Known transitional gap

- For the 0.1.3 release window, the contract docs describe observed-state semantics (the destination) while the conformance suite still asserts echo-shape (the 0.1.x reality) and the reference adapter still implements echo. This gap is intentional and bounded: docs lead toward the 0.2.0 destination; conformance and reference adapter follow in 0.2.0's breaking redesign. Adapters in development should target observed-state semantics.

## [0.1.2] - 2026-05-20

### Fixed

- Conformance tests `test_apply_creates_account_on_first_call`, `test_apply_idempotent`, `test_apply_replaces_state_rather_than_merging`, `test_reconcile_account_exists_entitlements_match`, `test_reconcile_account_exists_entitlements_differ`, and `test_reconcile_account_absent_entitlements_non_empty` no longer hard-code the reference adapter's feature keys (`"exampleapp.storage_gb"`, `"exampleapp.user_count"`). The contract uses `feature_key` as a key in a key-value bag (`current_state`); the namespace is adapter-defined (`nextcloud.storage_gb`, `matrix.federation_enabled`, etc.). The previous tests rejected contract-compliant adapter implementations whose feature keys differed from the reference's. Surfaced by NextCloud adapter implementation work; same shape as the `external_id` fix in 0.1.1.

### Added

- **BREAKING:** New `adapter_feature_keys` conformance-suite fixture. Adapter authors who re-export the conformance tests must provide this fixture in their `conftest.py`: a `list[str]` returning the feature keys the adapter handles, in `capabilities()` declaration order. Existing conftests without this fixture will see fixture-missing errors on conformance test runs after upgrading.
- `test_apply_replaces_state_rather_than_merging` now `pytest.skip`s for adapters that declare fewer than 2 feature keys (the replacement test inherently requires ≥2 keys to exercise the drop-a-key semantic). Adapter authors with single-feature-key adapters should track that this conformance test is skipped in their suite.

### Documentation

- New section in `docs/conformance.md` documenting the `adapter_feature_keys` fixture requirement and the single-key-adapter skip behavior for the replacement test.
- Contract §2 now states explicitly that feature_key namespacing is adapter-defined (the contract treats `current_state` as a key-value bag; each adapter owns its own namespace).

## [0.1.1] - 2026-05-19

### Fixed

- Conformance tests `test_external_id_immutable_across_apply` and `test_external_id_immutable_across_reconcile` no longer assert on a specific `external_id` transformation. The contract requires the mapping to be stable across calls and deterministic; it does not specify a derivation rule. The previous assertions rejected contract-compliant adapter implementations whose `external_id` derivation differed from the reference adapter's (e.g., `external_id = member_id` with no transformation). Surfaced by NextCloud's adapter implementation work.

### Documentation

- New contract §2.7 "Implementing methods against async-native target APIs" documents the canonical pattern for adapters whose target API exposes only async client libraries (NextCloud's OCS, Matrix's async SDK, etc.). The pattern: one long-lived worker thread per adapter instance running its own event loop; sync adapter methods submit coroutines via `asyncio.run_coroutine_threadsafe` and block on the result; construction happens in `__init__`; cleanup via an adapter-defined `close()` method (not part of the Adapter Protocol). Includes a transcription-ready code sketch.
- Contract §3 now states explicitly that the `external_id` derivation is adapter-defined (the contract requires stability and determinism, not a specific transformation rule).

## [0.1.0] - 2026-05-19

### Changed

- Conformance suite is now fully adapter-agnostic: conformance tests no longer import from `lightweb_adapter_sdk.reference`. State inspection uses `list_accounts()` instead of `get_account()`. Fault injection uses the `FaultControl` Protocol instead of `FakeExampleAppServer.set_unreachable()`.
- `ExampleAppUnreachable` now inherits from `AdapterUnreachable` to maintain compatibility with conformance assertions on the base type.

### Changed (BREAKING)

- `EventEnvelope.event_type` semantics: now follows the pattern `entitlements.<entity>.<verb>` (matching what the platform emits), not `entitlements.<app>.<verb>`. The class shape is unchanged; the docstring and parsing logic differ.
- `EventEnvelope.member_id` source: now extracted from the platform envelope's `data.member_id` field, not from `subject.id`. The class shape is unchanged.

### Removed (BREAKING)

- `app_from_event_type(event_type: str) -> str` — helper's premise was incorrect (assumed app name in middle segment of event_type; in reality, middle segment is the entity type). No replacement; adapters know their own app and do not extract it from events.

### Added

- `AdapterUnreachable` exception in `lightweb_adapter_sdk.types` — a base exception type for target-app unreachability. Adapter authors should raise this or a subclass when their adapter detects the target app is unreachable.
- `FaultControl` Protocol in `lightweb_adapter_sdk.conformance.fault_control` — defines the interface for fault injection in conformance tests (`inject_unreachable`, `inject_rate_limit`, `inject_auth_failure`, `reset`).
- `ReferenceFaultControl` in `lightweb_adapter_sdk.reference.fault_control` — reference implementation of `FaultControl` for the example adapter.
- `is_entitlement_change_event(env: EventEnvelope) -> bool` — returns `True` for the curated set of event types that trigger member-state-changing entitlement re-derivation. Adapter consumers use this to filter events that warrant a re-apply, ignoring informational events like `app_account.created` and `feature_key.registry_reloaded`.
- PEP 561 `py.typed` marker. Downstream consumers' type checkers will now pick up SDK type annotations.
- `nats-py >= 2.6` declared as runtime dependency for `JetStreamEventConsumer`. (The dependency was used at runtime by `JetStreamEventConsumer` since Round 4 began but was not declared in `pyproject.toml`; declaration was missed during the contract-reshape work. No API change.)
