# Supervisor-side edits between rounds

Some changes don't fit inside a round's scope but need to land before the next round starts. Examples observed across rounds:

- Canonical-document strengthening based on retrospective findings (e.g., `CLAUDE.md` edits between rounds).
- Contract-shape changes mandated by mid-round supervisor decisions (e.g., the `reconcile()` signature change mid-Round 1).
- Infrastructure fixes surfaced during operator-side verification (e.g., the Makefile `uv run` fix after Round 2).
- Workflow-state advancement after wrap (the round-status line update).
- Small mechanical additions that smooth a future round (e.g., `@runtime_checkable` on the `Adapter` Protocol between Rounds 1 and 2).

These land as supervisor-side commits on `main` directly, applied by the operator under the supervisor's explicit instructions.

## Workflow

The workflow for supervisor-side edits is **full-file output**, not patch-style instructions:

1. **Operator uploads the current on-disk version of any file the supervisor will edit.** The supervisor cannot safely produce edits against a remembered or inferred file state; the upload provides the verified baseline.
2. **Supervisor confirms the upload matches expected state** before editing. A mismatch (wrong line count, wrong section headers, missing recent edits) means the upload is stale or the on-disk version has diverged; the supervisor stops and asks for re-verification rather than editing against the wrong baseline.
3. **Supervisor applies the edits and outputs the complete revised file as a markdown file output.** Not a diff, not a patch, not before/after blocks — the full file in its post-edit state.
4. **Operator downloads the revised file and replaces the on-disk version with it.** No interpretation step; the file is the deliverable.
5. **Operator commits on `main`** with a Conventional Commits-prefixed message the supervisor provides.
6. **Operator pastes the resulting commit hash** back to the supervisor chat.

## Why full-file output

This workflow replaced an earlier patch-based approach that used before/after blocks or explicit per-step deletion-and-insertion lists. The patch-based approach repeatedly produced partial application — vestigial content left in place when it should have been removed, new content landing in the wrong section of a file with repeated section names, anchors not matching the actual current text. Round 3's retrospective item R3-4 surfaced this; the response (move to explicit per-step lists) helped but didn't eliminate the failure mode. The further response (full-file output) sidesteps it entirely:

- **No partial application risk.** The operator gets a complete file. There is no "did the deletion step happen" because there is no separate deletion step; there is just file replacement.
- **No anchor drift.** The supervisor's anchors are internal to the file being produced; whether the upload matches expected state is verified before edits begin, not during application.
- **Single review surface.** The supervisor reads the revised file as the final state. The operator reads the same file as the deliverable. There is no mental composition of "before + changes = after" required.
- **State verification is upstream of editing.** The "is the upload current?" question is asked once before edits start, not implicitly at every patch anchor.

The trade is volume — the supervisor produces complete files even when changes are small. This trade is worth it for the partial-application failure mode it eliminates.

## When this workflow doesn't fit

A few cases where the workflow needs adjustment:

- **Very large files where the edit is mechanical and localized.** For files in the thousands of lines where a one-line change is needed, full-file output is overkill. In these cases, the supervisor may produce a minimal `sed`-style or `git apply`-style patch instead — but only after verifying current state of the target region. This is a documented exception, not the default.
- **Multi-file edits that need to land atomically.** When several files change together (e.g., a CLAUDE.md edit that references a new file the same edit creates), the supervisor produces all files in one message. The operator downloads them all and commits as one logical change.
- **Edits during an active session worktree, not between rounds.** Mid-round corrections happen in the implementer's session; the supervisor doesn't produce supervisor-side patches against in-flight worktrees. (If the supervisor needs to correct CLAUDE.md mid-round, the operator applies the edit in the main worktree on `main`, and the implementer picks it up on the next session.)

## Discipline boundary

Supervisor-side edits are small in scope and bounded in impact: single-line decorator additions, recipe-line fixes, workflow-state updates, retrospective-driven `CLAUDE.md` clarifications. Substantive feature work, new contract shape, or anything that produces deliverables doesn't fit this pattern — that belongs in a round.

The rule of thumb: if the change would benefit from an implementer's session-summary scrutiny (decisions surfaced, design questions captured, exit criteria verified), it's a round. If the change is mechanical and self-evident, it's a supervisor-side edit.

## Commit-message hygiene

Conventional Commits prefix on every commit per `CONVENTIONS.md` §3.1. One logical change per commit unless the changes are mechanically interlocked (e.g., two related Makefile recipe lines, or a CLAUDE.md edit and the supporting-file edit it cross-references).

Backticks and shell-special characters in commit messages need shell-safe quoting if the operator passes the message on the command line. `git commit -m "docs(claude): add \`--amend\`-after-push note"` may lose the backticks depending on shell. When backticks matter, use `git commit -m "$(cat <<'EOF'`-style heredoc, or use a commit message file via `git commit -F message.txt`. The escaping isn't the supervisor's responsibility to specify, but the supervisor is aware of the failure mode and can include the heredoc form in suggested commit messages when backticks are load-bearing.

## State verification before drafting

The supervisor verifies the current state of any file targeted by an edit before drafting the edit. This means asking the operator for the actual current content — not relying on file uploads from earlier in the conversation that may be stale. Round 5's retrospective consolidation surfaced this directly: the supervisor (working from a stale upload) was about to produce edits against pre-correction anchors that no longer matched the on-disk file. The verification step is one or two upload requests; it protects against editing-against-wrong-baseline, which is the most expensive failure mode the workflow can hit.
