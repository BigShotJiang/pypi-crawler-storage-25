# Adapter Contract

## 1. Introduction

The adapter contract is the interface between the Lightweb entitlements
service and the services that provision those entitlements into target
applications.  It is specified in prose here and expressed in Python in
`src/lightweb_adapter_sdk/adapter/`.  Every adapter — first-party or
third-party — implements the six methods declared in this document.

The contract derives from the HLD §4 ("App Adapters").  Where this
document and the HLD diverge, this document is authoritative for the
SDK; the HLD is authoritative for platform-side consumers that do not
install the SDK.

## 2. The Six Methods

### 2.1 `capabilities()`

**Signature.** Takes no arguments; returns `Capabilities`.

**Semantic contract.** Returns static metadata describing the adapter's
scope: the app it targets, the feature keys it enforces, and any
operational constraints (e.g. maximum concurrent applies).  Called once
at adapter registration.

**Feature key namespacing.** Each adapter declares its own
`feature_keys` — the namespace and naming scheme are adapter-defined.
NextCloud declares `nextcloud.*` keys (e.g. `nextcloud.storage_gb`);
Matrix declares `matrix.*` keys; the reference adapter declares
`exampleapp.*` keys.  The contract treats `feature_key` strings as
opaque identifiers within the adapter's namespace.  Adapters should
not handle feature keys outside their declared namespace — the
entitlements service routes events to adapters by app, so an adapter
only ever sees entitlements for feature keys it has declared.

**Idempotency.** Repeated calls with no intervening configuration
changes return an equivalent result.

**Error modes.** Should not raise.  All required information is static
configuration available at adapter startup.

**Example.**

```json
{
     "app": "nextcloud",
     "feature_keys": ["nextcloud.storage_gb", "nextcloud.sharing_enabled"],
     "enforcement": {
         "nextcloud.storage_gb": "hard",
         "nextcloud.sharing_enabled": "soft"
     },
     "limits": {"max_concurrent_apply": 10},
     "schema_version": 1
}
```

### 2.2 `apply(member, entitlements)`

**Signature.** Takes `member: Member` and `entitlements: list[Entitlement]`;
returns `AppAccount`.

**Semantic contract.** Idempotently makes the target app's state match
the desired entitlements.  Creates accounts that should exist; updates
quotas that have changed; adjusts feature flags.  Returns the resulting
`AppAccount` data (`external_id` and current state) so the entitlements
service can record the provisioned reality.

When called with an empty `entitlements` list, ensures the account
exists with status `"active"` and `current_state` reflecting no
entitlements.  This is distinct from `disable` which sets status to
`"disabled"`.

**`current_state` is observed app state, not an echo of entitlements.**
The `current_state` field on the returned `AppAccount` describes what
the adapter observes in the target app after the apply — the app's
actual representation of the account, read back from the app.  Its keys
are adapter-defined app-side property names (per §2.1's namespacing
discussion), and its values are the app's observed values, which may
differ in both name and form from the entitlements that were applied.

For example, an adapter applying `nextcloud.storage_gb = 50` may
observe the app reporting the quota as `storage_quota_mb = 51200` — a
different property name and a different unit (megabytes) from the
entitlement (gigabytes), but describing the same adapter-controlled
limit.  `current_state` records what the app actually holds, which is
what lets the entitlements service and the reconciler (§2.4, §2.6)
detect drift between desired and actual state.  An adapter that simply
echoed the entitlements back as `current_state` would deprive the
reconciler of an independent observation to compare against.

**`current_state` holds drift-relevant, adapter-controlled properties
only.**  The reconciler (§2.6) uses `current_state` as its drift
baseline: it enumerates accounts, compares observed against desired,
and issues corrective `apply()` calls to converge.  Every property in
`current_state` must therefore be one the adapter can converge on by
re-applying — quotas the adapter set, account-enabled state, group
memberships the adapter manages.  User-controlled, varying data that
the adapter cannot converge on — current storage *usage*, last-login
time, message counts — is NOT part of `current_state`: it is a
measurement, not a convergence target, and including it would pollute
the drift baseline with perpetual non-actionable drift.  An adapter
that wants to expose such telemetry does so through a separate channel,
not `current_state`.

**Idempotency.** Calling `apply` repeatedly with the same arguments
produces the same result.  The method receives current desired state
(not deltas), so repeated invocation is safe.  This property is
required both for the adapter contract and for the JetStream consumer,
which delivers events at least once.

**Error modes.** Should raise on target-app unreachable or authentication
failure.  Partial application is acceptable only if the adapter's
internal state remains consistent for a retry.

**Example.**

Given a member with two entitlements (`nextcloud.storage_gb` = 50,
`nextcloud.sharing_enabled` = `true`), a correct apply ensures the
NextCloud account has 50 GB quota and sharing enabled, then returns
`current_state` reflecting the app's observed properties (here, the
quota as the app reports it — renamed and in megabytes — and the
sharing flag):

```json
{
     "member_id": "mem_AbCdEf123456789012",
     "app": "nextcloud",
     "external_id": "alice",
     "status": "active",
     "last_reconciled_at": "2026-05-15T10:30:00Z",
     "current_state": {"storage_quota_mb": 51200, "sharing_enabled": true}
}
```

### 2.3 `disable(member)`

**Signature.** Takes `member: Member`; returns nothing.

**Semantic contract.** Soft-disables a member's access while preserving
data.  Blocks the member from using the target app without destroying
the account or its data.  Reversible by a subsequent `apply`.

**Idempotency.** Calling disable multiple times has the same effect as
calling it once.  A no-op if the member is already disabled or has no
account in this app.

**Error modes.** Should raise on target-app unreachable.  Should NOT
raise when the member has no account.

**Example.**

After calling `disable()` for an active member, the account's status in
the target app reflects disabled access (e.g., NextCloud account locked,
Matrix account deactivated), but the account and its data remain intact.

### 2.4 `reconcile(member, entitlements)`

**Signature.** Takes `member: Member` and `entitlements: list[Entitlement]`;
returns `DriftReport`.

**Semantic contract.** Read-only drift detection: compare the target
app's current state for `member` against the desired state described by
`entitlements`.  Returns a structured `DriftReport` enumerating each
discrepancy as a `DriftFinding`.  An empty `findings` list means no
drift.  Never mutates the target app.

The `entitlements` argument is the same shape passed to `apply` —
current desired state, not deltas.  The reconciler passes the entitlements
it currently knows for the member; the adapter does not fetch them on
its own.  This avoids a race between the reconciler's view of
entitlements and the adapter's fetch, and keeps the comparison
principled across all adapter implementations.

The four cases an adapter handles, by (account-presence × entitlements-presence):

- **Account exists, entitlements non-empty.** The expected case.  For
  each entitlement, compare its value against the account's current
  state.  Mismatches produce `value_mismatch` findings.  If the
  account's status is `"disabled"` despite non-empty entitlements,
  that is a `state_mismatch`.
- **Account exists, entitlements empty.** The member has no
  entitlements for this app, but an account exists from prior
  provisioning.  This is correct state, not drift.  Return an empty
  `DriftReport`.
- **Account absent, entitlements non-empty.** The member should have
  an account but does not.  Return a single `missing_in_app` finding
  with severity `critical`.
- **Account absent, entitlements empty.** The member legitimately has
  no account, no expectation, no drift.  Return an empty `DriftReport`.

A return with empty findings means the adapter was able to contact the
target app and found no drift; it is not a fallback for unreachability.
When the target app is unreachable, raises an adapter-specific exception
rather than returning a misleadingly empty report.

A `DriftFinding`'s `feature_key` field is the adapter-namespaced key
of the mismatched feature (per §2.1).  The `expected` and `actual`
values are the desired value from the entitlements argument and the
actual value found in the target app, respectively; the contract makes
no claim about value types beyond what the corresponding `Entitlement`
specifies.

**Idempotency.** Repeated calls with unchanged inputs return the same
report (modulo clock drift in `reconciled_at`).

**Error modes.** Should raise when the target app is unreachable.  A
successful return with `findings=[]` must mean the adapter was able to
contact the target app and found no discrepancies given the entitlements
passed in.

**Example.**

A member with one entitlement (`nextcloud.storage_gb` = 50) whose
account currently reports 25 GB:

```json
{
     "member_id": "mem_AbCdEf123456789012",
     "app": "nextcloud",
     "findings": [
         {
             "kind": "value_mismatch",
             "feature_key": "nextcloud.storage_gb",
             "expected": 50,
             "actual": 25,
             "severity": "critical"
         }
     ],
     "reconciled_at": "2026-05-15T10:30:00Z"
}
```

### 2.5 `health()`

**Signature.** Takes no arguments; returns `HealthStatus`.

**Semantic contract.** Reports adapter and target-app reachability.
Returns a `HealthStatus` with two boolean signals:

- `healthy`: `True` only when the adapter is responding AND
  `app_reachable` is `True` (strict conjunction).
- `app_reachable`: the target app's API responded.

The method itself must not raise.  If the adapter cannot perform the
health check, return `healthy=False` with `app_reachable=False` and use
`details` to explain.

**Idempotency.** Repeated calls with unchanged infrastructure state
return consistent results.

**Error modes.** The method must not raise.  A return value with
`healthy=False` is the only failure channel.

**Example.** Adapter is running but the target app is down:

```json
{
     "healthy": false,
     "app_reachable": false,
     "details": {"nextcloud_api": "connection refused"}
}
```

### 2.6 `list_accounts(cursor)`

**Signature.** Takes `cursor: str | None` (defaults to `None`); returns
`AccountListPage`.

**Semantic contract.** Pages through every account in the target app.
Used by the reconciler for whole-system drift detection.  Returns a
window of accounts and a `next_cursor` for pagination (`None` when no
more pages).

Each returned `AppAccount` carries the same `current_state` shape as
`apply()` returns (per §2.2): observed app state, not an echo of
entitlements.  This is what makes `list_accounts()` usable for
whole-system drift detection — the reconciler reads observed state for
every account in one pass and compares against desired state, skipping
per-member `reconcile()` calls where the observed state already matches.

An expired or invalid cursor returns an empty page with
`next_cursor=None` rather than raising.

**Idempotency.** Repeated calls with the same cursor return the same
page of accounts, assuming no concurrent modifications in the target app.

**Error modes.** Should raise on target-app unreachable.

**Example.** First page (cursor = `None`).  Note `current_state`
carries observed app properties, the same shape `apply()` returns:

```json
{
     "accounts": [
         {
             "member_id": "mem_AbCdEf123456789012",
             "app": "nextcloud",
             "external_id": "alice",
             "status": "active",
             "last_reconciled_at": "2026-05-15T10:30:00Z",
             "current_state": {"storage_quota_mb": 51200, "sharing_enabled": true}
         }
     ],
     "next_cursor": "eyJpZCI6IDJ9"
}
```

### 2.7 Implementing methods against async-native target APIs

The six methods above are declared synchronous (`def`, not `async def`)
on the `Adapter` Protocol.  This is deliberate: the contract is
polyglot (per §7), and sync method signatures map cleanly to the
contract's Go and TypeScript expressions.  Async semantics live at the
event-consumer boundary (`EventConsumer.consume`, which is `async def`),
not at the adapter-method boundary.

Adapter authors whose target API exposes only async client libraries
(NextCloud's OCS client, Matrix's async SDK, etc.) must therefore
bridge async-to-sync inside the adapter.  This section documents the
canonical bridging pattern.

**What not to do.** A per-call `asyncio.run(coro)` inside a sync adapter
method fails when the caller already owns an event loop — and the
JetStream event consumer always does, because `EventConsumer.consume`
is `async def`.  `asyncio.run` cannot be called from a coroutine; the
nested-loop case raises `RuntimeError`.  A new event loop per call is
also wrong: it's wasteful, and it doesn't compose with adapter state
that has a longer lifetime than a single method call.

**The pattern.** Each adapter instance owns a long-lived worker thread
that runs its own event loop.  Sync adapter methods submit coroutines
to that loop via `asyncio.run_coroutine_threadsafe` and block on the
result.  The calling thread (whatever it is — usually the JetStream
consumer's worker, but it could be anything) is decoupled from the
adapter's internal event loop.

**Construction.** The worker thread and event loop are created in
`__init__`.  An `Adapter` instance is operational from the moment of
construction; there is no separate `start()` step.  This matches the
implicit contract that the six methods are callable as soon as the
adapter exists.

Construction failures (thread creation refused, async client
initialization failed, OAuth token rejected) surface as exceptions from
`__init__`.  The contract assumes that *if you have an `Adapter`
instance, it is operational*: adapters should not gracefully degrade to
a non-functional state.  Surface failures at construction, not at first
method call.

**Cleanup.** The worker thread is created as a daemon, so it dies with
the process if no explicit cleanup happens.  Adapters whose target API
warrants graceful cleanup (in-flight requests should complete, OAuth
sessions should be closed) should expose a `close()` method that signals
the loop to stop, waits for in-flight work to complete with a bounded
timeout, and joins the worker thread.

`close()` is **not** part of the `Adapter` Protocol.  Sync-target
adapters don't need it; forcing every adapter to implement it would
bloat the contract.  Async-target adapters expose it as a convention,
and long-running services that hold adapter references (the JetStream
consumer) call it during their own shutdown.

**Sketch.** A complete async-bridging adapter looks roughly like this.
This is the template for transcription, not a helper class — adapter
authors copy this skeleton and fill in the target-API-specific bodies.

```python
import asyncio
import threading
from concurrent.futures import Future
from typing import Any

from lightweb_adapter_sdk.types import (
    AppAccount,
    Capabilities,
    Entitlement,
    HealthStatus,
    Member,
)


class AsyncBridgedAdapter:
    """Skeleton for an adapter whose target API requires async I/O."""

    def __init__(self, async_client: Any) -> None:
        """Construct the adapter and bring its worker thread online.

        The worker thread and event loop are created here.  After this
        returns, all six Adapter Protocol methods are callable.

        Construction failures (thread creation, async client setup,
        authentication) surface as exceptions; the adapter does not
        construct in a degraded state.
        """
        self._async_client = async_client
        self._loop: asyncio.AbstractEventLoop = asyncio.new_event_loop()
        self._loop_thread = threading.Thread(
            target=self._run_loop,
            name=f"{type(self).__name__}-loop",
            daemon=True,
        )
        self._loop_thread.start()
        self._closed = False

    def _run_loop(self) -> None:
        """Worker thread target: run the event loop until stopped."""
        asyncio.set_event_loop(self._loop)
        try:
            self._loop.run_forever()
        finally:
            self._loop.close()

    def _submit(self, coro: Any) -> Any:
        """Submit a coroutine to the worker loop and block on the result.

        Exceptions raised inside the coroutine re-raise on the calling
        thread when ``.result()`` is called.
        """
        if self._closed:
            raise RuntimeError("adapter has been closed")
        future: Future[Any] = asyncio.run_coroutine_threadsafe(coro, self._loop)
        return future.result()  # blocks until the coroutine completes

    def close(self, timeout: float = 30.0) -> None:
        """Shut down the worker loop and join the thread.

        Safe to call multiple times.  Not part of the Adapter Protocol;
        a convention for async-target adapters whose cleanup matters.
        """
        if self._closed:
            return
        self._closed = True
        self._loop.call_soon_threadsafe(self._loop.stop)
        self._loop_thread.join(timeout=timeout)

    # ----- Adapter Protocol methods (synchronous) ----------------------

    def apply(self, member: Member, entitlements: list[Entitlement]) -> AppAccount:
        return self._submit(self._apply_async(member, entitlements))

    def health(self) -> HealthStatus:
        return self._submit(self._health_async())

    # (and similarly for capabilities, disable, reconcile, list_accounts)

    # ----- Async implementations (private) -----------------------------

    async def _apply_async(
        self, member: Member, entitlements: list[Entitlement]
    ) -> AppAccount:
        """The actual async work — uses self._async_client with await."""
        # ... await self._async_client.create_account(...) ...
        # ... await self._async_client.set_quota(...) ...
        raise NotImplementedError

    async def _health_async(self) -> HealthStatus:
        """The actual async health check — uses self._async_client."""
        raise NotImplementedError
```

The pattern above is what NextCloud's adapter (and any other
async-target adapter) inherits.  The `_submit` helper centralizes the
async-to-sync bridging; the public sync methods are thin wrappers; the
private `_*_async` methods do the actual work using `await` against
the target API's async client.

**Why this composes correctly.** When the JetStream consumer (running
in its own event loop) calls `adapter.apply(...)`, the call goes
through:

1. The consumer's event loop is executing `consume()`.
2. `consume()` calls `adapter.apply(member, entitlements)` synchronously.
3. `apply` calls `self._submit(self._apply_async(...))`.
4. `_submit` schedules the coroutine on the *adapter's worker thread's
   event loop* (not the consumer's), and waits for the result on the
   consumer's worker thread.
5. The adapter's worker thread runs the coroutine, which `await`s
   against the OCS / Matrix / etc. async client.
6. The result returns through `future.result()` to the consumer's
   thread, then to `consume()`'s execution context.

Two event loops, two threads, no nesting.  The consumer's loop is
never blocked on the adapter's async work; the adapter's loop is
never blocked on the consumer.

## 3. Identity Mapping

Every adapter maintains a stable mapping between the platform's
`member_id` and the app's notion of identity (NextCloud usernames,
Matrix MXIDs, Gitea usernames).  The mapping is set once at
provisioning time and never changes — even if a member's email or display
name changes later.

This discipline is what keeps audit trails coherent and what prevents
accidental account fusing during recovery scenarios.  The `external_id`
on `AppAccount` is the canonical name for this mapping and is immutable
for the lifetime of the (member, app) pair.

The contract requires the mapping to be **stable** (set once at
provisioning, never changes thereafter) and **deterministic** (the same
member produces the same `external_id` when re-derived).  The contract
does NOT specify a transformation rule — each adapter chooses how to
derive `external_id` from `member_id` (strip the `mem_` prefix and
lowercase, use the member's display name, use a UUID, use `member_id`
unchanged, etc.).  Adapters should document their specific choice in
their own docs.

## 4. Schema Evolution

Adapters use a Kubernetes-controller-style discipline that allows safe
schema evolution: each adapter records the schema version it last applied
(in `Capabilities.schema_version`), and when the deployed adapter is
newer, the next reconciliation pass naturally upgrades each member to the
new schema.

There is no big-bang migration; the system self-heals over the next
reconciliation cycle.  The `schema_version` field in `Capabilities` is
the only version field required — the reconciler compares it against the
version it last saw for each member and treats any change as a signal to
re-apply the current desired state with the new adapter's logic.

## 5. Error Handling

The contract draws a line between error conventions that are part of the
contract and those that are adapter-specific.

**Contract-level error conventions:**

- Methods that mutate state (`apply`, `disable`) raise on target-app
  unreachable or authentication failure.
- `reconcile` raises on target-app unreachable; it must not return a
  misleadingly empty report.
- `health` never raises.  Unavailability is communicated through the
  return value (`healthy=False`).
- `list_accounts` raises on target-app unreachable but returns an empty
  page for an invalid or expired cursor.
- `capabilities` should never raise.

**Adapter-specific conventions:**

- The SDK provides `AdapterUnreachable` in `lightweb_adapter_sdk.types`
  as a base exception for target-app unreachability.  Adapter authors
  should raise `AdapterUnreachable` or a subclass when their adapter
  detects that the target app is unreachable.  Conformance tests
  assert on this base type, so adapter fakes must raise it (or a
  subclass) for the conformance suite to exercise error handling.
- Other adapter-specific exception types (e.g., for auth failures or
  rate limits) are adapter-defined.  The contract requires raising on
  these conditions but does not mandate shared exception classes for
  them.  Adapter authors may define their own exception classes (e.g.,
  `NextCloudConnectionError`, `MatrixAuthError`).  Over HTTP surfaces,
  the adapter should return 5xx status codes (503 for unreachable,
  401/403 for auth failures).

## 6. Idempotency

The adapter contract requires idempotency twice over:

1. **Contract-level.** The `apply` method is idempotent because it
   receives current desired state rather than deltas.  Calling
   `apply(member, entitlements)` repeatedly with the same arguments
   produces the same result.  This is a fundamental property: the
   entitlements resolver may call apply more than once in a session.

2. **Consumer-level.** Each adapter maintains a durable JetStream
   consumer subscribed to entitlement-changed events.  JetStream
   delivers events at least once, meaning the same event may arrive
   more than once.  The adapter must be idempotent at the consumer
   level — processing the same event a second time must produce the
   same result as the first.

Both constraints are satisfied by the same property: applying current
state is safe regardless of how many times it happens.

Conformance to the idempotency requirement is verified by the shared
test suite (Round 3).  Until mechanized, the supervisor enforces this
on checkpoint and wrap review.

## 7. JSON Serialization

The contract is JSON-shape, not Python-class.  Adapter authors may use
any serialization mechanism that produces the same JSON shapes.  The
Python SDK uses Pydantic v2 models for convenience, but a Go or
TypeScript adapter satisfies the contract by serving the same JSON over
HTTP and consuming the same JetStream subjects.

See `CONVENTIONS.md` §5 ("Python expression of the contract") and §8
("Cross-language stance") for the full posture.

**Datetimes.** Any field whose type includes `datetime` serializes to
an ISO-8601 string in JSON (e.g., `"2026-05-15T10:30:00Z"`).  The
models with datetime fields are `AppAccount` (`last_reconciled_at`),
`DriftReport` (`reconciled_at`), and `EventEnvelope` (`occurred_at`).

**EventEnvelope and the platform envelope.** The platform publishes
events with a shape that differs from `EventEnvelope` in two respects:

- The platform envelope carries `subject: {type, id}` and
  `data: {member_id, ...}`.  The SDK's `EventEnvelope` flattens
  these: `member_id` is sourced from `data.member_id` (not
  `subject.id`), and `subject` is omitted entirely.  A non-Python
  adapter parsing the platform envelope should read
  `data.member_id` to get the same value.

- The platform's `context` field is preserved for tracing and
  correlation propagation.  The platform's `data` field (beyond
  `member_id`) is intentionally omitted — adapters re-fetch current
  desired state from the entitlements service on event receipt; the
  envelope is a signal, not state.

- `event_type` follows the platform pattern
  `entitlements.<entity>.<verb>` (e.g.,
  `"entitlements.member.entitlements_changed"`), where `<entity>` is
  the subject type (`member`, `subscription`, `operator_grant`), not
  the target app.

See the `EventEnvelope` type documentation for the full divergence
rationale.  The platform's JSON Schemas in
`../lightweb-platform/libs/events/schemas/entitlements/` are the
authoritative source for the on-wire shapes.

**`is_entitlement_change_event` helper.** The SDK provides a free
function `is_entitlement_change_event(env: EventEnvelope) -> bool`
that returns `True` for the curated set of event types that trigger
member-state-changing entitlement re-derivation.  Adapter consumers
use this to filter events that warrant a re-apply, ignoring
informational events like `entitlements.app_account.created` and
`entitlements.feature_key.registry_reloaded`.
