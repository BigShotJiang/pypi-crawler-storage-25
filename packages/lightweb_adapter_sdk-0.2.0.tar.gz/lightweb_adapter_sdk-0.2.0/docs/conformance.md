# Conformance Suite

The conformance suite is the mechanical expression of `docs/contract.md`.
Every test maps to a specific contract claim; every passing test is a
proof that the adapter satisfies that claim.

## 1. What the conformance suite is (and isn't)

The conformance suite tests **contract claims** — behaviors that every
adapter must implement regardless of target app. It does **not** test
reference-adapter specifics (feature keys, enforcement types, external_id
derivation) or app-specific integration behavior.

Reference-adapter specifics live in `tests/unit/test_reference_adapter.py`.
App-specific integration tests belong in each adapter's own test
directory.

## 2. Installation

The conformance suite ships as part of the main SDK package:

```bash
pip install lightweb-adapter-sdk
```

No optional extras are needed — `pytest` and `pytest-asyncio` are
declared as main runtime dependencies (since 0.1.0) because they are
required to import the conformance test modules.

## 3. Wiring the fixtures

Adapter authors must provide five pytest fixtures in their
`tests/conftest.py`:

```python
# tests/conftest.py
import pytest
from lightweb_adapter_sdk.conformance.fault_control import FaultControl
from my_adapter import MyAdapter, MyFakeServer

@pytest.fixture
def adapter_under_test():
    server = MyFakeServer()
    return MyAdapter(server)

@pytest.fixture
def adapter_fake_server(adapter_under_test):
    return adapter_under_test._server

@pytest.fixture
def adapter_fault_control(
    adapter_fake_server: MyFakeServer,
    request: pytest.FixtureRequest,
) -> FaultControl:
    """Provide fault-injection control for conformance tests.

    Implement the FaultControl Protocol by delegating to the fake
    server's fault-injection methods. Teardown resets the server.
    """
    # ... implement the three inject_* methods and reset() ...
    request.addfinalizer(control.reset)
    return control

@pytest.fixture
def adapter_feature_keys() -> list[str]:
    """Feature keys the adapter handles, in capabilities() declaration order.

    Conformance tests that exercise apply/reconcile use this fixture
    to parameterize the feature keys they pass in entitlements and
    assert on. The list MUST match what the adapter's capabilities()
    returns as feature_keys.
    """
    return ["myapp.storage_gb", "myapp.user_count"]

@pytest.fixture
def adapter_observed_state_example() -> dict[str, Any]:
    """A known desired→observed example for observed-state conformance.

    ``entitlement`` (containing only ``feature_key`` and ``value``) is
    applied; the resulting ``current_state`` MUST contain
    ``observed_key_present`` and MUST NOT contain
    ``desired_key_absent``.  A pure-echo adapter fails the second
    assertion.

    ``observed_keys`` maps feature keys to their observed property
    projections, used by the replacement-vs-merging test.
    """
    from typing import Any

    return {
        "entitlement": {"feature_key": "myapp.storage_gb", "value": 50},
        "observed_key_present": "myapp_storage_quota_mb",
        "desired_key_absent": "myapp.storage_gb",
        "observed_keys": {
            "myapp.storage_gb": ["myapp_storage_quota_mb"],
            "myapp.user_count": ["myapp_seat_count"],
        },
    }
```

**Requirements for adapter authors:**

1. The fake server **must** support fault injection. The conformance
   suite uses the `FaultControl` Protocol (`lightweb_adapter_sdk.conformance.fault_control`)
   with three fault modes: `inject_unreachable()`, `inject_rate_limit()`,
   and `inject_auth_failure()`. The `inject_unreachable()` mode is the
   only one exercised by current conformance tests
   (`test_apply_raises_when_unreachable`,
   `test_reconcile_raises_when_unreachable_not_vacuous_empty`,
   `test_list_accounts_raises_when_unreachable`,
   `test_health_strict_conjunction_when_app_unreachable`).

2. The adapter **must** expose its server via `._server`. The
   `adapter_fake_server` fixture accesses this attribute. If the adapter
   uses a different internal attribute name, expose the server through
   `._server` (even if it is a property forwarding to the internal name).

3. The `adapter_fault_control` fixture must implement the `FaultControl`
   Protocol. Each `inject_*` method either injects the fault (returning
   normally) or raises `NotImplementedError` if the fault mode is not
   supported. The `reset()` method restores the server to normal
   operating mode and is called automatically in fixture teardown.

4. The `adapter_feature_keys` fixture (added in 0.1.2) returns the
    list of feature keys the adapter handles, matching its
    `capabilities()` declaration. Conformance tests that exercise
    `apply()` and `reconcile()` use this fixture to parameterize the
    feature keys they work with, avoiding hard-coded reference-adapter
    feature keys.

5. The `adapter_observed_state_example` fixture (added in 0.2.0)
    declares a known desired→observed example.  Conformance tests
    that verify `current_state` is observed app state (not an echo of
    entitlements) use this fixture to assert that the declared
    observed key IS present and the declared desired key IS absent.
    Adapter authors must implement this fixture with values that match
    their adapter's actual desired→observed transformation.

    The suite asserts **subset** semantics on observed keys:
    `union(observed_keys.values()) ⊆ current_state.keys()`.
    Adapters MAY include observed keys not declared in
    `observed_keys` (e.g. an account-enabled flag derived from no
    single feature key, group memberships). No exact-match assertion
    on `current_state` keys is performed.

If any requirement is unmet, conformance tests that depend on the
corresponding fixture will fail with `AttributeError`,
`NotImplementedError`, or pytest fixture-not-found errors rather
than exercising the adapter's behavior.

**Single-feature-key adapters.** Adapters that declare only one
feature key in `capabilities()` will skip
`test_apply_replaces_state_rather_than_merging` — that test
inherently requires ≥2 feature keys to exercise the drop-a-key
replacement semantic. The test reports as skipped (not failed); the
remaining conformance tests run as normal. Adapter authors with
single-key adapters should track this gap and consider whether their
adapter eventually needs a second feature key for full conformance
coverage.

## 4. Running the suite

Import all conformance tests and collect them as normal pytest tests:

```python
# tests/test_conformance.py
from lightweb_adapter_sdk.conformance import (
    test_capabilities_idempotent,  # noqa: F401
    test_capabilities_schema_version_declared,  # noqa: F401
    test_apply_creates_account_on_first_call,  # noqa: F401
    test_apply_current_state_consistent_with_read_back,  # noqa: F401
    test_apply_current_state_is_observed_not_desired,  # noqa: F401
    test_apply_empty_entitlements_creates_active_account,  # noqa: F401
    test_apply_idempotent,  # noqa: F401
    test_apply_raises_when_unreachable,  # noqa: F401
    test_apply_replaces_state_rather_than_merging,  # noqa: F401
    test_disable_sets_status_disabled,  # noqa: F401
    test_disable_idempotent,  # noqa: F401
    test_disable_noop_for_missing_account,  # noqa: F401
    test_external_id_immutable_across_apply,  # noqa: F401
    test_external_id_immutable_across_reconcile,  # noqa: F401
    test_health_never_raises,  # noqa: F401
    test_health_strict_conjunction_when_app_reachable,  # noqa: F401
    test_health_strict_conjunction_when_app_unreachable,  # noqa: F401
    test_list_accounts_current_state_is_observed_not_desired,  # noqa: F401
    test_list_accounts_invalid_cursor_returns_empty,  # noqa: F401
    test_list_accounts_paginates,  # noqa: F401
    test_list_accounts_preserves_member_id,  # noqa: F401
    test_list_accounts_raises_when_unreachable,  # noqa: F401
    test_reconcile_account_exists_entitlements_match,  # noqa: F401
    test_reconcile_account_exists_entitlements_differ,  # noqa: F401
    test_reconcile_account_absent_entitlements_non_empty,  # noqa: F401
    test_reconcile_account_absent_entitlements_empty,  # noqa: F401
    test_reconcile_raises_when_unreachable_not_vacuous_empty,  # noqa: F401
)
```

Run with:

```bash
pytest tests/test_conformance.py -v
```

Or via the Makefile target (if available):

```bash
make test-conformance
```

**JSON-shape stance.** The conformance suite enforces `docs/contract.md`
§7's JSON-shape-not-Python-class principle implicitly: all assertions
use JSON-translatable properties (string equality, numeric comparison,
list membership). No test asserts Python object identity or requires
Pydantic model internals.

## 5. Reading failures

Most failures indicate a genuine contract violation — the adapter does
not satisfy the claim and needs a code fix. The common
non-contract-violation failure modes are:

- **`AttributeError` on `adapter_under_test._server`** — the adapter
  does not expose its server through `._server`. Fix by adding a
  `._server` property that forwards to the internal server attribute.

- **`NotImplementedError` from a `FaultControl` method** — the
  `adapter_fault_control` fixture's implementation declared a fault
  mode unsupported. Either implement the fault mode in the fake
  server or accept that the corresponding conformance test will
  fail.

- **`fixture 'adapter_feature_keys' not found`** — the conftest is
  missing the `adapter_feature_keys` fixture (added in 0.1.2). Add
  it per §3.

## 6. Out of scope

The following are explicitly **not** covered by the conformance suite:

- **Schema evolution.** Changes to Pydantic model fields, serialization
  formats, or wire formats over time are out of scope. Schema evolution
  is verified by platform-level integration tests; see `docs/contract.md`
  §4 for the discipline.

- **JetStream event consumption.** How the adapter consumes or produces
  JetStream events is covered by a separate set of conformance tests
  (`test_event_consumer_*`) that follow the same fixture-and-import
  pattern but exercise the async `EventConsumer` Protocol rather than
  the sync `Adapter` Protocol.

- **App-specific integration.** Feature-key mappings, authentication
  flows, and app-specific error handling are not contract claims.

## 7. SemVer protection

Conformance test names, the fixture interface (`adapter_under_test`,
`adapter_fake_server`, `adapter_fault_control`, `adapter_feature_keys`,
`adapter_observed_state_example`),
the `._server` access pattern, and the `FaultControl` Protocol surface
are all SemVer-protected per `CONVENTIONS.md` §1.5. Changes to
conformance test names are breaking changes. Adding a new conformance
test is also a breaking change unless the test is introduced as
optional first. Adding a new required fixture (as 0.1.2 does with
`adapter_feature_keys`) is a breaking change to the adapter-author
setup contract; pinned adapters will not see fixture-missing errors,
but upgrades require updating the conftest.

Adapter authors should pin the SDK version when adopting the
conformance suite.
