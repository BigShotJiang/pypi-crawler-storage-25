# Testkit

## Introduction

The testkit is a set of helpers for adapter authors writing tests for
their Lightweb adapters during development.  It provides:

- **Structural tests** — parameterized functions that verify an adapter
  satisfies the ``Adapter`` Protocol and returns well-shaped output.
- **``FakeEntitlementsService``** — an in-process fake of the platform's
  entitlements service, for staging state in tests that drive
  ``apply()`` or ``reconcile()``.

The testkit is the **development-feedback layer**, not the conformance
gate.  It answers "does this adapter look like an adapter?" — fast,
lightweight checks you run while writing code.  The conformance suite
(Round 3) answers "does this adapter implement the contract correctly?"
— comprehensive behavioral tests run at CI time as a pass/fail gate.

Passing the testkit's structural tests is necessary but not sufficient
for a production-ready adapter.  You still need to pass the conformance
suite before your adapter is ready for production use.

See ``docs/contract.md`` for the canonical contract specification that
the testkit's structural tests check against.

## Installation

Install the testkit as an optional extra:

```bash
pip install lightweb-adapter-sdk[testkit]
```

The bare ``pip install lightweb-adapter-sdk`` does **not** pull in
``pytest`` or any testkit functionality.  This is deliberate:
production environments that install the SDK should not have test
dependencies as transitive dependencies.  The testkit's test functions
are for development use only — production code should never import from
``lightweb_adapter_sdk.testkit``.

## The ``adapter_under_test`` fixture

The testkit's structural tests are parameterized over an
``adapter_under_test`` fixture.  Adapter authors provide this fixture
in their ``conftest.py``:

```python
# adapter author's tests/conftest.py
import pytest
from my_adapter import MyAdapter, MyAppServer

@pytest.fixture
def adapter_under_test():
    server = MyAppServer()
    return MyAdapter(server)
```

Pytest's collection picks up the imported test functions, parameterizes
them with the user's fixture, and runs them.  No metaclasses, no
plugin registration, no class inheritance.  The fixture name
``adapter_under_test`` is part of the SDK's public API and is
SemVer-protected.

Adapter authors re-export the test functions in their own
``tests/test_structural.py``:

```python
# adapter author's tests/test_structural.py
from lightweb_adapter_sdk.testkit import (
    test_satisfies_protocol,  # noqa: F401
    test_capabilities_returns_well_shaped,  # noqa: F401
    test_health_is_callable,  # noqa: F401
    test_list_accounts_initial_page,  # noqa: F401
)
```

Pytest collects these by import; ruff does not understand the
pytest-collection pattern and flags them as unused imports.  The
``# noqa: F401`` comment is expected and is the standard fix.

## The four structural tests

### ``test_satisfies_protocol``

**What it checks.**  The adapter structurally satisfies the ``Adapter``
Protocol by passing an ``isinstance(adapter, Adapter)`` check against
the ``@runtime_checkable`` Protocol.

**What it does not check.**  Behavioral correctness — whether the
adapter's methods produce the right results for specific inputs.  That
is conformance-suite territory.

**When it would fail.**  If the adapter is missing any of the six
required methods, or if a method's signature does not match the
Protocol (e.g., wrong parameter types or return type).

### ``test_capabilities_returns_well_shaped``

**What it checks.**  ``capabilities()`` returns a ``Capabilities``
instance with at least one feature key, and the ``enforcement`` dict
contains entries for every feature key declared.

**What it does not check.**  Whether the feature keys are correct for
the target app, or whether the enforcement levels are appropriate.
Those are behavioral questions for the conformance suite.

**When it would fail.**  If ``capabilities()`` returns ``None`` or a
non-``Capabilities`` object, returns zero feature keys, or has an
``enforcement`` dict missing entries for declared feature keys.

### ``test_health_is_callable``

**What it checks.**  ``health()`` returns a ``HealthStatus`` instance
without raising.

**What it does not check.**  The strict-conjunction logic (whether
``healthy`` is ``True`` only when both adapter and app are reachable),
or whether the ``details`` dict contains useful information.  Those
are behavioral questions for the conformance suite.

**When it would fail.**  If ``health()`` raises an exception, or
returns a non-``HealthStatus`` object.

### ``test_list_accounts_initial_page``

**What it checks.**  ``list_accounts(cursor=None)`` returns an
``AccountListPage`` instance with a ``list`` of accounts and a
``next_cursor`` that is either ``None`` or a string.

**What it does not check.**  Pagination semantics (whether cursors
advance correctly), the number of accounts per page, or the contents
of individual accounts.  Those are behavioral questions for the
conformance suite.

**When it would fail.**  If ``list_accounts()`` raises, returns a
non-``AccountListPage`` object, returns a non-list ``accounts``, or
has a ``next_cursor`` that is neither ``None`` nor a string.

## The fake entitlements service

The ``FakeEntitlementsService`` class is an in-process fake of the
platform's entitlements service.  Adapter authors use it in tests that
drive ``apply()`` or ``reconcile()`` with realistic data, or to
verify the adapter's outgoing ``upsert_app_account`` calls.

### Staging entitlements

```python
from lightweb_adapter_sdk.testkit import FakeEntitlementsService
from lightweb_adapter_sdk.types import Entitlement

fake = FakeEntitlementsService()

ent = Entitlement(
    member_id="mem_AbCdEf123456789012",
    feature_key="nextcloud.storage_gb",
    value=50,
    source_type="subscription",
    source_id="sub_test",
)
fake.set_member_entitlements("mem_AbCdEf123456789012", "nextcloud", [ent])

# The adapter reads these on event receipt:
retrieved = fake.get_member_entitlements("mem_AbCdEf123456789012", "nextcloud")
assert len(retrieved) == 1
```

``set_member_entitlements`` replaces any prior entitlements for that
 ``(member, app)`` pair.  ``get_member_entitlements`` returns a copy
 of the stored list (preventing accidental mutation through the
 returned reference) and returns an empty list for unknown keys.

### Recording provisioned reality

```python
from lightweb_adapter_sdk.types import AppAccount
from datetime import datetime, timezone

account = AppAccount(
    member_id="mem_AbCdEf123456789012",
    app="nextcloud",
    external_id="alice",
    status="active",
    last_reconciled_at=datetime.now(timezone.utc),
    current_state={"storage_gb": 50},
)
returned = fake.upsert_app_account(account)
assert returned.member_id == "mem_AbCdEf123456789012"

stored = fake.get_app_account("mem_AbCdEf123456789012", "nextcloud")
assert stored is not None
assert stored.external_id == "alice"
```

``upsert_app_account`` stores the account by ``(member_id, app)``;
subsequent calls with the same key update the existing record.
``get_app_account`` returns ``None`` for unknown keys.

## Beyond the testkit

The testkit's structural tests verify that an adapter looks like an
adapter.  They do not verify that the adapter implements the contract
correctly.  For that, adapter authors need the conformance suite — a
comprehensive set of behavioral tests covering every contract claim in
``docs/contract.md``, run at CI time as a pass/fail gate.  The
conformance suite is Round 3 and does not yet exist; documentation
for how to wire it into your CI will be available when it ships.
