# Named wrap procedures

Procedures followed when the user invokes them by name at end-of-round / end-of-session, to land the work in a session worktree onto `main`. The phrases below are exact triggers; if the user types one, follow the corresponding procedure.

Four procedures, scoped by what they touch:

- **`wrap worktree`** — local-only. Lands work on local `main`, removes the session worktree, attempts branch deletion. No network. This is the default for round wrap; it succeeds independent of network availability and leaves push as a separate operator-driven step.
- **`wrap worktree and push`** — local plus push. Same as `wrap worktree`, but includes pushing `main` to origin as an interleaved step. Use when push connectivity is known-reliable. Stops cleanly if push fails, leaving local state recoverable.
- **`retry push`** — post-network-restored recovery. Use after a `wrap worktree` invocation when push was deferred (or after a `wrap worktree and push` invocation that stopped at the push step). Pushes `main`, pushes any unpushed tags, completes the branch deletion if it was previously blocked.
- **`manual release`** — publish a tagged release to PyPI. Used after the release-tooling commits (CHANGELOG promotion, version-affecting changes) are on `main`. Builds, verifies in a clean environment, publishes, and pushes the tag. Distinct from the wrap procedures above: it operates on `main` directly (no session worktree), and its failure modes are packaging/publishing rather than merge/push.

These procedures stop on any precondition failure or step error. Don't try to recover by force, hard reset, or `--force` flags — surface the actual error and let the user decide.

If the harness can't run git commands, the operator runs them and pastes verbatim output back. The procedure's preconditions and steps remain the same.

## "wrap worktree"

Merge the current session worktree's branch into `main` and safely retire the worktree. Local-only — no push step.

Preconditions (refuse and report if any fail):

- The current shell is inside a session worktree, not the `main` worktree.
- `git status --porcelain` in the session worktree returns nothing (clean).
- The session branch is ahead of `main` by at least one commit and has no commits on `main` it lacks (i.e., a fast-forward merge is possible).
- The `main` worktree's working tree is clean. Do not auto-clean shared state.

Steps:

1. Capture the session branch and worktree paths:
   ```
   SESSION_BRANCH=$(git rev-parse --abbrev-ref HEAD)
   SESSION_PATH=$(git rev-parse --show-toplevel)
   MAIN_PATH=$(git worktree list --porcelain | awk '/^worktree / {p=$2} /^branch refs\/heads\/main$/ {print p}')
   ```
2. `cd "$MAIN_PATH"`.
3. Verify `git status --porcelain` in `main` is empty. Stop if not.
4. `git merge --ff-only "$SESSION_BRANCH"`. Stop if not fast-forwardable; resolving non-trivial merges is out of scope for this procedure.
5. `git worktree remove "$SESSION_PATH"`. Removes the worktree directory and unregisters it. After this, the original shell CWD is invalid; subsequent commands run from `$MAIN_PATH`.
6. `git branch -d "$SESSION_BRANCH"`. Use `-d` (safe). Never `-D`. The branch is reachable from local `main` (since step 4 fast-forward-merged it), so `-d`'s safety check should pass on HEAD-reachability. **Expected failure mode:** if `-d` fails because git's safety check consults the upstream tracking branch and `origin/main` is behind local `main`, leave the branch and report. The branch will be deletable after `retry push` lands the missing commits on origin.
7. Report: session branch retired (or "branch deletion deferred pending push" if step 6 failed), worktree removed, `main` now at `<sha>`.

Local-only `wrap worktree` is the default for round wrap when push connectivity is unreliable. The deferred branch deletion isn't a problem — `retry push` cleans it up once network returns.

## "wrap worktree and push"

Same intent as `wrap worktree`, but interleaves a push so that branch deletion's upstream-merge check passes deterministically and so that a push failure leaves the work recoverable.

Preconditions: same as `wrap worktree`, plus `git remote get-url origin` succeeds (a remote named `origin` is configured).

Steps (these replace the steps in `wrap worktree` — don't run `wrap worktree` first):

1. Capture the session branch and worktree paths:
   ```
   SESSION_BRANCH=$(git rev-parse --abbrev-ref HEAD)
   SESSION_PATH=$(git rev-parse --show-toplevel)
   MAIN_PATH=$(git worktree list --porcelain | awk '/^worktree / {p=$2} /^branch refs\/heads\/main$/ {print p}')
   ```
2. `cd "$MAIN_PATH"`.
3. Verify `git status --porcelain` in `main` is empty. Stop if not.
4. `git merge --ff-only "$SESSION_BRANCH"`. Stop if not fast-forwardable.
5. `git push origin main` (or `git push -u origin main` on first push if upstream tracking isn't set). Stop if push fails — pushing before removing the worktree means a network/auth failure leaves the work recoverable; pushing before deleting the branch means `git branch -d`'s upstream check passes regardless of git's check-order policy.
6. `git worktree remove "$SESSION_PATH"`. Subsequent commands run from `$MAIN_PATH`.
7. `git branch -d "$SESSION_BRANCH"`. Use `-d` (safe). Never `-D`.
8. Report: session branch retired, worktree removed, `main` now at `<sha>`, pushed to `origin/main`.

Never `--force` or `--force-with-lease` unless the user has explicitly asked for it in this turn.

## "retry push"

Recovery procedure for the post-network-blocked state. Use after a `wrap worktree` invocation when push was deferred, or after a `wrap worktree and push` invocation that stopped at the push step. Lands the deferred pushes and completes any branch deletion that was blocked by `origin/main` being behind local `main`.

Preconditions (refuse and report if any fail):

- The current shell is inside the `main` worktree, not a session worktree. (`retry push` runs after session worktrees have been removed.)
- `git status --porcelain` in `main` is empty.
- `git remote get-url origin` succeeds.
- Local `main` is ahead of `origin/main` by at least one commit (i.e., there is something to push).

Steps:

1. `git push origin main`. Stop if push fails.
2. **Optional but recommended:** push any local tags that should be on origin. To list tags missing from origin:
   ```
   git ls-remote --tags origin | awk '{print $2}' | sed 's|refs/tags/||' | sort > /tmp/origin-tags
   git tag | sort > /tmp/local-tags
   comm -23 /tmp/local-tags /tmp/origin-tags
   ```
   If the diff lists tags that should be on origin (typically release-candidate or release tags created locally during wrap), push them: `git push origin <tag-name>` for each, or `git push origin --tags` to push all local tags. Stop if any push fails.
3. **Complete any deferred branch deletions.** List local branches that don't exist on origin (potentially the session branches `wrap worktree` couldn't delete):
   ```
   git branch | grep -v '^\*' | tr -d ' ' | sort > /tmp/local-branches
   git ls-remote --heads origin | awk '{print $2}' | sed 's|refs/heads/||' | sort > /tmp/origin-branches
   comm -23 /tmp/local-branches /tmp/origin-branches
   ```
   For each session branch (matching `claude/*`) the diff lists, run `git branch -d <branch-name>`. Use `-d`, never `-D`. Stop on any deletion failure and report which branches still exist.
4. Report: pushed commits to `origin/main`, pushed tags (list them), deleted branches (list them).

`retry push` is idempotent — running it when there's nothing to push or no branches to delete is a no-op. It's safe to run any time after network connectivity is restored.

## "manual release"

Publish a tagged release of the SDK to PyPI. Used after the release-affecting commits — the CHANGELOG promotion (`[Unreleased]` → `[X.Y.Z]`) and any version-affecting source/doc changes — are already on `main`. This procedure does not produce those commits; it tags, builds, verifies, publishes, and pushes.

This procedure operates on `main` directly (not in a session worktree). It was exercised for the 0.1.0, 0.1.1, 0.1.2, and 0.1.3 releases; the steps below incorporate the disciplines those releases surfaced.

**Execution note — one step per message.** Each numbered halt-block below is run as its own operator turn: run the block, paste the verbatim output, wait for confirmation before the next block. Do NOT batch multiple halt-blocks into one message. The 0.1.1 release surfaced the failure mode where two blocks sent together (publish + post-publish verify) led to the operator running the second and skipping the first; PyPI didn't have the version and the verify failed confusingly. One block, one paste, one confirmation.

Preconditions (refuse and report if any fail):

- The current shell is inside the `main` worktree, on `main`, with `git status --porcelain` empty.
- The CHANGELOG's top versioned entry matches the version about to be released, and the `[Unreleased]` section has been promoted.
- A PyPI API token is available. After the first release, this is a **project-scoped** token (created once the project exists on PyPI), not an account-scoped one. The token is never typed on a command line or pasted into chat (see step 6).

Steps:

1. **Tag before build (hard rule).** Tag the release on the CHANGELOG-promotion commit (current HEAD), then verify the tag resolves cleanly:
   ```
   git tag -a vX.Y.Z -m "Release X.Y.Z"
   git describe
   ```
   `git describe` must return exactly `vX.Y.Z` with no `-N-g<sha>` suffix. **Rationale:** hatch-vcs derives the package version from the most recent tag reachable from HEAD. If HEAD is past the most recent tag (i.e., you build before tagging), hatch-vcs produces a dev local-version identifier like `X.Y.Z.devN+g<sha>`, and PyPI rejects the upload (PEP 440 forbids local-version identifiers on the index). Tag first, every time. This was the 0.1.1 failure.

2. **Clean `dist/`.** `make build` does not clean stale artifacts, and `uv publish dist/*` globs everything in `dist/` — a stale wheel from a prior build would be uploaded alongside the new one.
   ```
   rm -f dist/lightweb_adapter_sdk-*
   ```

3. **Build.**
   ```
   make build
   ls -la dist/
   ```
   Verify `dist/` contains exactly the `X.Y.Z` wheel and sdist with clean version strings (no `.devN+g<sha>`). Stop if the version is wrong — that means the tag wasn't picked up (re-check step 1).

4. **Clean-environment install verification (load-bearing, not optional).** Install the freshly built wheel into a throwaway environment and exercise the import surface. This catches packaging defects that the dev environment cannot surface — the 0.1.0 release shipped a pytest-as-runtime-dep defect that only appeared in a clean install, because `[dev]` always had pytest present.
   ```
   uv venv /tmp/sdk-release-verify --python 3.12
   source /tmp/sdk-release-verify/bin/activate
   python -m ensurepip
   python -m pip install dist/lightweb_adapter_sdk-X.Y.Z-py3-none-any.whl
   python -c "from lightweb_adapter_sdk.types import AdapterUnreachable; print('imports OK')"
   python -c "from lightweb_adapter_sdk.conformance import test_apply_idempotent; print('conformance re-export OK')"
   python -m pip show lightweb-adapter-sdk
   deactivate
   ```
   Notes: `uv venv` produces a venv without a pip console script, so use `python -m ensurepip` then `python -m pip` (not bare `pip`). For releases that fix a specific defect, add a check that inspects the published behavior (e.g. `inspect.getsource` to confirm a removed assertion is actually absent). Stop if any import fails or `pip show` reports the wrong version/dependencies.

5. **Build the publish command without leaking the token.** The token never appears on a command line or in chat. Use `read -s` chained so the export and publish run only after a successful read, with cleanup always at the end:
   ```
   read -rs UV_PUBLISH_TOKEN && export UV_PUBLISH_TOKEN && uv publish dist/* ; unset UV_PUBLISH_TOKEN
   ```
   Paste the token at the silent prompt (it is not echoed), press enter. **Rationale for the chaining:** the 0.1.1 release leaked a token by running `UV_PUBLISH_TOKEN=pypi-... uv publish` with the literal value on the command line — it entered shell history and chat scrollback and had to be revoked. The 0.1.3 release stumbled on a two-step `read -s` then separate `export`/`publish` where `uv publish` ran before the variable was exported and fell back to an interactive username prompt. The `&&`-chained single line avoids both: token never on the command line, and publish runs only after a successful read+export. If `uv publish` ever prompts for a username, the token was not in the environment — Ctrl-C out, do not type the token at the prompt, and re-run the chained line.

   Successful output shows `Uploading lightweb_adapter_sdk-X.Y.Z-py3-none-any.whl` and `...tar.gz` lines with no error after them. `uv publish` signals success by absence of error, not by a "done" line.

6. **Post-publish verification from PyPI (not from the local wheel).** Confirm PyPI actually serves the new version — the upload appearing to succeed is not the same as the version being live (the 0.1.1 release had a publish that didn't happen, surfaced only by this step).
   ```
   sleep 15
   uv venv /tmp/sdk-pypi-verify --python 3.12
   source /tmp/sdk-pypi-verify/bin/activate
   python -m ensurepip
   python -m pip install lightweb-adapter-sdk==X.Y.Z
   python -c "import lightweb_adapter_sdk; print('installed X.Y.Z from PyPI')"
   python -m pip show lightweb-adapter-sdk | grep -i version
   deactivate
   ```
   The `pip install ...==X.Y.Z` resolving and downloading from PyPI (not a cached wheel) confirms the version is live. Stop and investigate if PyPI reports "no matching distribution" — the publish did not land.

7. **Push the commits and tag to origin.**
   ```
   git push origin main
   git push origin vX.Y.Z
   ```
   Run as two commands so a failure on either is isolated. The tag push lands the release tag on Gitea origin.

8. Report: version X.Y.Z published to PyPI (verified live), `main` and `vX.Y.Z` pushed to origin.

**Token rotation (first release only).** The first-ever upload of a new project requires an account-scoped token (PyPI can't create a project-scoped token for a project that doesn't exist yet). Immediately after the first successful release, create a project-scoped token for the project and revoke the account-scoped one. Subsequent releases use the project-scoped token.
