# Conformance and contract-doc audit discipline

The conformance suite expresses contract claims that every adapter must satisfy regardless of target app. Two recurring failure classes have shown up across rounds and releases: conformance tests asserting on reference-adapter-specific values (so a contract-compliant adapter that differs from the reference is wrongly rejected), and contract documentation that is internally inconsistent or stale. This document defines the audits that catch both.

The discipline traces to Round 4.1's adapter-agnosticism redesign, whose original audit was incomplete in ways that surfaced repeatedly during the 0.1.x release cycles (the `external_id` literal-string assertion in 0.1.1, the `feature_key` literal-key assertions in 0.1.2, the `current_state` prose-vs-example inconsistency in 0.1.3). Each was a different dimension of the same underlying concern. The five dimensions below are the consolidated audit.

## The five dimensions

A complete adapter-agnosticism / contract-coherence audit covers all five:

1. **Imports.** Conformance test modules do not import from `lightweb_adapter_sdk.reference`. Enforced mechanically by `tests/unit/test_conformance_independence.py`. This was the original Round 3 concern.

2. **Helper structure.** Conformance test helpers (`_make_member`, `_make_entitlement`, etc.) do not bake in reference-adapter specifics as non-overridable defaults. A helper whose default `feature_key="exampleapp.storage_gb"` is reference-specific; if tests rely on the default rather than a fixture-supplied value, the coupling is hidden in the helper. (Resolved in 0.1.2 by making `feature_key` a required parameter and threading it from the `adapter_feature_keys` fixture.)

3. **Assertion values.** Conformance test assertions do not assert on reference-adapter-specific literal values. This is the dimension Round 4.1's original audit missed. See the grep below. Each literal-equality assertion must be classified contract-required (keep) or adapter-discretionary (fix).

4. **Documentation references to deprecated patterns.** When a code surface is renamed or replaced, the docs that reference it are updated in the same change. The 0.1.2 conformance.md revision caught three stale references (the removed `[testkit]` extra, `set_unreachable()` replaced by the `FaultControl` Protocol). A renamed fixture/method/function leaves stale doc references unless audited.

5. **Contract-doc internal consistency (prose vs. example).** Contract documentation prose describing a field must agree with every example showing that field — repo-wide, not just within the edited section, because contract sections cross-reference each other. The 0.1.3 inconsistency (a §2.2 prose paragraph describing `current_state` as a feature-key echo while the §2.2 example showed observed app values, and the §2.6 example showed nothing) was self-introduced by a 0.1.2 doc edit that changed prose without checking the adjacent example. This dimension is doc-side and is NOT caught by the assertion grep — it requires its own scan.

## The greps (dimensions 3 and 4)

Assertion-value audit (dimension 3):

```
grep -rn "^[[:space:]]*assert .* == [\"']" src/lightweb_adapter_sdk/conformance/
grep -rn "^[[:space:]]*assert .* == [0-9]" src/lightweb_adapter_sdk/conformance/
```

Classify each result:

- **Contract-required (KEEP):** the literal is a value the contract itself specifies. Examples: status strings (`"active"`, `"disabled"`), `DriftFinding.kind` values (`"value_mismatch"`, `"missing_in_app"`), severities (`"critical"`), page counts in pagination tests, finding-list lengths in known-scenario tests.
- **Adapter-discretionary (FIX):** the literal is a value the reference adapter happens to produce but the contract does not require. Examples: feature keys (`"exampleapp.storage_gb"`), `external_id` derivations, any value whose form is the adapter's choice. These get parameterized via a fixture (the adapter declares the value; the test asserts against the fixture-supplied value, not a literal).

Documentation-reference audit (dimension 4), run whenever a code surface is renamed or removed:

```
grep -rn "<old-surface-name>" docs/
```

If the old name appears in docs, update those references in the same change.

## Contract-doc consistency audit (dimension 5)

When editing contract-doc prose that describes a field, scan all examples repo-wide that contain that field and verify the prose's claims match every example's shape:

```
grep -rn "<field-name>" docs/contract.md
```

Read each match in context. Prose paragraphs describing the field and JSON/code examples showing the field must agree. A prose change in one section can break consistency with an example in another section (sections cross-reference). Empty examples (`{}`) are an active source of inconsistency — they give adapter authors no signal about the intended shape, and a reader fills the gap by intuiting from a different section's example. Contract examples for a field should be concrete (non-empty) wherever the field's shape carries meaning; an empty example is acceptable only when emptiness is the point being illustrated.

## When to run the audit

Three trigger points. The audit is mechanical (the greps are seconds); run it rather than deferring.

1. **Before any conformance-affecting SDK round closes.** Part of the round's exit criteria.
2. **Before tagging any release** (`manual release` step 0, conceptually — run the audit before the CHANGELOG promotion that precedes tagging).
3. **Whenever an adapter author surfaces an adapter-agnosticism or contract-coherence finding.** Audit other instances of the same class IN the same release cycle — do not queue. The 0.1.1→0.1.2 sequence is the cautionary case: 0.1.1 fixed one instance of the assertion-value class and queued the class-wide audit as a retrospective item; NextCloud surfaced a second instance before the queued audit fired, forcing a 0.1.2 follow-on. When you fix an instance of a class, run the class-wide audit as part of that fix's cycle. The queued-audit pattern is acceptable only when the audit genuinely can't be run during the cycle, which for mechanical greps is almost never.

## Cross-repo note

Dimensions 4 and 5 (documentation references; prose-vs-example consistency) are not SDK-specific. They apply to any documentation with examples — platform conventions docs, the HLD, adapter-side docs. The platform supervisor has queued the prose-vs-example audit as a candidate discipline on the platform side. A discipline surfaced on one side of the cross-supervisor relationship is evaluated for the other.
