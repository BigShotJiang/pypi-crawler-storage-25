```
[SUPERVISOR]
Round: 0
Scope: round-prompt
Platform repo: ../lightweb-platform
Platform repo HEAD: <OPERATOR: fill in with `git -C ../lightweb-platform rev-parse HEAD` at prompt-creation time>
Date: <OPERATOR: fill in with YYYY-MM-DD>
```

# Round 0 — Contract definition

**Status:** Active.
**Previous round:** None. This is the first round of the adapter-sdk repo.
**Working tree state:** `main` is at the initial commit; the SDK repo contains only the foundational documents and license: `README.md`, `LICENSE`, `CHANGELOG.md`, `ARCHITECTURE.md`, `CONVENTIONS.md`, `CLAUDE.md`, `CONTRIBUTING.md`, `.gitignore`, and `docs/round-prompt-template.md`. No `src/`, no `tests/`, no `pyproject.toml`, no `Makefile`, no `docs/contract.md`. You will create the initial code-level structure.

## Required reading

Read these files in full, in order. Do not skim. Do not infer content from filenames.

1. `CLAUDE.md` — already read if you reached this prompt.
2. `ARCHITECTURE.md` — repo orientation.
3. `CONVENTIONS.md` — read in full; particularly §1 (versioning), §5 (Python expression of the contract), §6 (dependencies), §7 (licensing), §8 (cross-language stance). Key portions are inlined in §3 below for immediate reference but the canonical version is in the file.
4. `$PLATFORM_REPO/docs/hld.md` — §3 (entitlements) and §4 (adapters) in full. Both are inlined below; the canonical version is in the platform repo at the recorded HEAD.
5. `$PLATFORM_REPO/docs/services/entitlements/dd.md` — §3.2 (Member), §3.5 (Entitlement), §3.6 (FeatureKey), §3.8 (AppAccount). All four are inlined below; reading the full §3 in the file is also encouraged for adjacent context but not required.
6. `$PLATFORM_REPO/libs/domain-types/` (if present) — read the existing type definitions. The SDK's `types/` aligns with these, with intentional divergences specified in deliverable 5 below. If the directory does not exist, flag this in the session summary and proceed against the field lists specified in deliverable 5 as canonical.
7. `$PLATFORM_REPO/libs/events/schemas/` (if present) — read the existing entitlement-changed event schemas. The `EventEnvelope` type you define in `types/` aligns with what these schemas publish. If the directory does not yet exist, the SDK's event envelope is the canonical shape; flag this in the session summary.
8. This round prompt — finish reading before starting work.

Note: `docs/contract.md` does not yet exist. You are creating it in this round. The Protocol in `src/lightweb_adapter_sdk/adapter/` does not yet exist. You are creating it.

## Inlined context

Inlined content below is verbatim from the recorded canonical source. Treat as authoritative for the duration of this round.

### From `$PLATFORM_REPO/docs/hld.md` §3.1 (the entitlements data model)

> The core insight underlying the model: separate what someone is paying for from what they are allowed to do from what is actually been provisioned. These three concepts look the same on day one and diverge by month six. Modeling them as separate entities from the start avoids painful retrofits later.
>
> **Member, Plan, PlanVersion, Subscription.** Members are humans (and businesses, with type discrimination). Plans are sellable bundles, versioned so that changing 'what Gold includes' does not rewrite history. Subscriptions are the contracts linking members to plan versions, with billing state.
>
> **Entitlement.** The atomic permission. Each row is (member, feature_key, value, source) — and crucially, multiple sources can grant the same feature key for the same member. A member could have NextCloud storage from their subscription, plus an extra grant from a referral promo, plus role-based capacity from being a beta tester. The source field tracks why each entitlement exists; when the source ends, that entitlement evaporates.
>
> **FeatureKey registry.** A small lookup table defining every possible feature with its value type, merge rule (how multiple sources combine), and enforcement level. The registry is a contract: plans can only grant keys that exist in it; adapters can only enforce keys they declare in their capabilities. See Appendix A for the registry schema and the initial set of keys. Each key carries a default value that members without any contributing source still see; defaults produce effective values at the API layer rather than being materialized as entitlement rows, so the registry table doesn't bloat with one default row per (member, key) pair.
>
> **AppAccount.** The provisioned reality. For each (member, app) pair where the entitlement exists, a record of the actual account in that app — its external_id, its current quota, when it was last reconciled. This is what closes the loop between 'what should be' (entitlements) and 'what is' (the app).
>
> **MemberSeat.** Business plans hold the subscription; individual members occupy seats on the business. A seat-holder's effective entitlements are the union of their personal subscriptions and the seats they occupy, computed by the same resolver that handles individual entitlements. Seats are first-class sources: each entitlement derived from a seat carries that seat's identifier, so revoking a seat removes its contributions cleanly the same way cancelling a subscription does. Seat creation is gated by the business's effective _platform.business_seats value, enforced by the resolver at write time. The seat mechanism is invisible to apps and to Keycloak.

### From `$PLATFORM_REPO/docs/hld.md` §4 (app adapters)

> Adapters are where the platform's clean entitlement model meets the messy reality of each app's API. Get the adapter contract right and adding the seventh app is a week of work; get it wrong and every new app is a month of debugging.
>
> ## The contract
>
> Every adapter implements a small, fixed interface — six methods, no more:
>
> - **capabilities() —** declares which feature keys this adapter handles, what enforcement it offers, what its operational limits are.
>
> - **apply(member, entitlements) —** idempotent. Makes the target app's state match the desired entitlements. Creates accounts that should exist; updates quotas that have changed. Returns the resulting AppAccount data (external_id and current state) so the entitlements service can record the provisioned reality alongside the desired entitlement.
>
> - **disable(member) —** soft-disable. Blocks access while preserving data. Reversible by a subsequent apply.
>
> - **reconcile(member) —** read-only. Returns a structured drift report comparing app state to expected state. Never mutates.
>
> - **health() —** the adapter and its target app are reachable.
>
> - **list_accounts(cursor) —** optional. Pages through every account in the app for whole-system reconciliation.
>
> Notably absent: there is no delete. Deletion is destructive, asymmetric, and almost always wrong as an automatic action. When a subscription cancels, the adapter disables; deletion is a separate, gated, human-approved workflow that runs much later. Keeping deletion out of the adapter interface prevents a whole category of accidental data loss.
>
> ## Two interfaces, one core
>
> Each adapter exposes both a REST API and an MCP server, backed by the same in-process logic. The entitlements service and the reconciler call the REST API on the hot path of every change. SysAdmin agents (running in the agent runtime) use the MCP server for read-only investigation — answering questions like 'what does NextCloud actually say this user's quota is?' without granting mutation rights. This separation is the same pattern the document recommends for every layer of the platform: REST is the contract for code; MCP is the contract for agents. Adapters are also event consumers: each maintains a durable JetStream consumer subscribed to entitlement-changed events for its app, and pulls current desired state from the entitlements service when an event arrives. Idempotency is required twice over — once because the adapter contract receives desired state rather than deltas, and again because at-least-once delivery means the same event may be consumed more than once. Both constraints are satisfied by the same property: applying current state is safe regardless of how many times it happens.
>
> ## Identity mapping
>
> Every adapter has to maintain a stable mapping between the platform's member_id and the app's notion of identity (NextCloud usernames, Matrix MXIDs, Gitea usernames). The mapping is set once at provisioning time and never changes — even if a member's email or display name changes later. This is what keeps audit trails coherent and what prevents accidental account fusing during recovery scenarios.
>
> ## Schema evolution
>
> Adapters use the same Kubernetes-controller-style discipline that allows safe schema evolution: each adapter records the schema version it last applied, and when the deployed adapter is newer, the next reconciliation pass naturally upgrades each member to the new schema. There is no big-bang migration; the system self-heals over the next reconciliation cycle. Conformance to the adapter contract is verified by a shared test suite — every adapter implementation, including community-contributed ones, runs the same battery of tests against the six-method interface. This is what makes the contract a real commitment rather than a written one.

### From `$PLATFORM_REPO/docs/services/entitlements/dd.md` §3.2 (Member)

> The Member is the entity the service exists for. A member is identified externally by their `public_id` (`mem_<base58>`) and internally by their Keycloak user ID.
>
> Two member types: `individual` and `business`. The HLD §3.1 commits to "Members are humans (and businesses, with type discrimination)." Concretely:
>
> - An `individual` member can hold subscriptions and seats, occupy seats in business members.
> - A `business` member can hold subscriptions; its seats are occupied by `individual` members linked via `member_seats` rows.
>
> A Member also has mirrored fields from external systems: `display_name` (from Keycloak), `billing_email` (from Lago). These are convenience mirrors; the canonical source remains the external system.
>
> A Member has a `status` field (`active | archived`). Archive is for the rare case where a member's data should be hidden from active operations but not hard-deleted (compliance requests, dispute holds). Most members live at `active` for their entire lifecycle.
>
> There is no `email` column on the Member directly. Email-as-identity is Keycloak's; `billing_email` may differ.

### From `$PLATFORM_REPO/docs/services/entitlements/dd.md` §3.5 (Entitlement)

> The Entitlement row is the atomic permission. Each row asserts that a specific Member has a specific value for a specific FeatureKey, derived from a specific source.
>
> ```
> (member_id, feature_key, value, source_type, source_id, created_at)
> ```
>
> Crucially:
>
> - Multiple rows can exist for the same (`member_id`, `feature_key`) pair — one per source contributing. The resolver writes one row per contribution. Effective merged values are computed at read time (HLD §3.2) using the FeatureKey's `merge_rule`.
> - `source_type` is enum: `subscription | subscription_state | seat | operator_grant`.
> - `source_id` is text — the public_id of the source row.
> - The unique constraint is `(member_id, feature_key, source_type, source_id)`. A single source can produce at most one row per feature key.
>
> Default values from the registry are *not* stored as entitlement rows. Per HLD §3.1's clarification, defaults produce effective values at the API layer rather than being materialized.

### From `$PLATFORM_REPO/docs/services/entitlements/dd.md` §3.6 (FeatureKey)

> The FeatureKey table mirrors the registry — every key in the active registry has one row. Schema follows HLD Appendix A with the additions from the HLD revision:
>
> - `key` (primary key from the registry's perspective; bigint `id` for FK efficiency).
> - `app`: which adapter owns this (`nextcloud`, `gitea`, `_platform`, etc.).
> - `value_type`: `bool | int | enum | string_set`.
> - `merge_rule`: `or | and | sum | max | min | precedence | union`.
> - `default_value`: `jsonb`.
> - `enum_values`: `text[]` (required when `value_type = enum`).
> - `precedence_order`: `text[]` (required when `merge_rule = precedence`; ordered lowest-to-highest).
> - `requires`: `text[]` (other feature keys this depends on).
> - `enforcement`: `hard | soft | advisory`.
> - `reset_period`: `none | monthly | daily | hourly`.
> - `status`: `active | deprecated | experimental`.
> - `admin_only`: bool.
> - `layer`: `core | community` (determined by source directory at registry load time, not by an in-file field).

### From `$PLATFORM_REPO/docs/services/entitlements/dd.md` §3.8 (AppAccount)

> An AppAccount records the provisioned reality for a (Member, app) pair. Per HLD §3.1, it closes the loop between "what should be" (entitlements) and "what is" (the app).
>
> Fields:
> - `member_id`, `app`: identify the relationship.
> - `external_id`: the app's username, MXID, etc. Set once at provisioning; never changes.
> - `status`: `active | disabled | deleted`. `disabled` is the soft-disable state from `disable(member)`; `deleted` is the rare destructive case.
> - `last_reconciled_at`: when the reconciler last verified this account.
> - `current_state`: opaque jsonb written by the adapter — the adapter's record of what's actually in the app (current quota, last login, etc.).
>
> Two unique constraints: a member has at most one account per app (`UNIQUE (member_id, app)`); an app's `external_id` maps to at most one member (`UNIQUE (app, external_id)`).
>
> AppAccount rows are written via the internal endpoint `POST /v1/internal/app-accounts/upsert`, called by adapters after their `apply()` succeeds. The entitlements service does not write AppAccount rows directly; adapters report; the service stores.

### From `CONVENTIONS.md` §1.2 (what counts as a breaking change)

> For a Protocol-based contract, "breaking" is broader than for a typical library. The following are all breaking changes that require a major release:
>
> - Removing or renaming any of the six contract methods.
> - Changing a method's signature: parameter types, parameter names, return type, raised exceptions.
> - Adding a required method to the Protocol. (Adding an optional method is additive; adding a required one breaks every existing adapter.)
> - Changing the shape of any type in `types/` in a way that an existing caller could observe — adding a required field, removing a field, changing a field's type, narrowing a union.
> - Changing the JetStream event envelope schema in a way that existing consumers parse differently.
> - Promoting a conformance test from optional to required.
> - Changing the semantic contract of any method, even when the signature is unchanged. ("Idempotent" becoming "best-effort" is breaking. "Returns drift report" becoming "raises on drift" is breaking.)
>
> When in doubt, treat the change as breaking. The cost of an unnecessary major release is reputational; the cost of a missed major is downstream pain.

This matters in Round 0 because: every shape decision you make is what gets versioned forward. Lock in only what you're confident about; surface ambiguity rather than committing to a shape that will need breaking later.

### From `CONVENTIONS.md` §5.1 (Python-default, contract-implementable-anywhere)

> This SDK is the Python expression of the contract. The contract itself — the six methods, the event envelope, the AppAccount upsert call shape, the conformance behaviors — is implementable in any language that can speak HTTP and JetStream. Non-Python implementations are not currently shipped, but the door is left open from day one.
>
> Concrete consequences:
>
> - **The contract specification in `docs/contract.md` is language-neutral.** It describes shapes, behaviors, and protocols in prose, not in Python syntax. The Python code in `src/` is one realization of that specification.
> - **The conformance suite tests contract conformance, not Python conformance.** Where possible, conformance tests exercise an adapter via its HTTP and JetStream surfaces, not by importing its Python module. This is the property that lets a future Go or TypeScript adapter run the same suite.
> - **Python-specific affordances stay out of the Protocol.** No `__init__` requirements on adapter implementations. No reliance on Pydantic validators in the contract itself (Pydantic appears in `types/` as a serialization mechanism; the contract is shape-level). No async-vs-sync split in the Protocol that would not translate.

This matters in Round 0 because: the Protocol's design and `docs/contract.md`'s phrasing both need to read as language-neutral. The Python expression is one realization; the prose says what the contract *is*.

## Scope

This round produces six deliverables. Each is committed during work as it reaches a verifiable state — see commit triggers in `CLAUDE.md` §"Commit discipline".

### Deliverable 1: `pyproject.toml`

Declares the package metadata and dependencies. Specifically:

- Project name: `lightweb-adapter-sdk`.
- Package directory: `lightweb_adapter_sdk` (under `src/`).
- Version: `0.0.0`. (Not `0.1.0` — that's Round 5's release.)
- Python: `>=3.12`.
- Build backend: `hatchling`.
- Runtime dependencies: `pydantic >= 2.0` only. No other runtime deps in Round 0.
- Dev dependencies (under `[project.optional-dependencies]` with key `dev`, so `pip install -e ".[dev]"` resolves them): `mypy`, `ruff`, `pytest`, `pytest-asyncio`, `hypothesis`.
- Project URLs: repository, documentation (placeholders are fine).
- License: `Apache-2.0`.

No `lightweb-platform` dependency. Verify this explicitly.

Workspace tool: this round uses standard `pip` against `pyproject.toml`'s `[project.optional-dependencies]`. No `uv`, no `poetry`, no `pdm`. If a workspace tool is later adopted SDK-wide, it lands as its own scoped change.

### Deliverable 2: `Makefile`

Targets:

- `install` — runs `pip install -e ".[dev]"`. Installs the SDK in editable mode along with dev dependencies.
- `typecheck` — runs `mypy --strict src/`.
- `format` — runs `ruff format src/`.
- `format-check` — runs `ruff format --check src/`. Used by exit criteria and (eventually) CI; non-mutating.
- `lint` — runs `ruff check src/`.
- `clean` — removes `__pycache__/`, `*.egg-info/`, `dist/`, `build/`, `.mypy_cache/`, `.ruff_cache/`.

No `test` or `test-*` targets in Round 0; tests come in Round 1. The `Makefile` targets reference only `src/` (not `tests/`); when Round 1 adds a `tests/` directory, the targets are extended as part of that round's scope.

### Deliverable 3: `src/lightweb_adapter_sdk/__init__.py`

Empty file establishing the package. May export top-level types if you choose, but only after the types in deliverable 5 are defined. If unsure, leave empty.

### Deliverable 4: `src/lightweb_adapter_sdk/adapter/__init__.py`

Defines `Adapter` as a `typing.Protocol` with six methods. Signatures derived from HLD §4 inlined above:

```python
from typing import Protocol

class Adapter(Protocol):
    def capabilities(self) -> Capabilities: ...
    def apply(self, member: Member, entitlements: list[Entitlement]) -> AppAccount: ...
    def disable(self, member: Member) -> None: ...
    def reconcile(self, member: Member) -> DriftReport: ...
    def health(self) -> HealthStatus: ...
    def list_accounts(self, cursor: str | None = None) -> AccountListPage: ...
```

Each method has a docstring stating: the semantic contract, the idempotency requirement (where applicable), the error modes. The exact wording of the docstring matches the corresponding section in `docs/contract.md` (deliverable 6) for behavioral claims. Match the words; the Protocol's docstring and `docs/contract.md`'s prose are written together and reviewed as one unit.

Use `typing.Protocol` from the standard library. Do **not** use `abc.ABC` or any base class. Adapter authors satisfy the contract structurally.

### Deliverable 5: `src/lightweb_adapter_sdk/types/__init__.py`

Defines Pydantic v2 models for the shared types. Each model has a class-level docstring.

The models, with their fields:

**`Member`**
- `member_id: str` — the public ID (`mem_<base58>`).
- `member_type: Literal["individual", "business"]`.
- `external_ids: dict[str, str]` — per-app identity mapping (key: app name, value: external ID in that app). Empty for newly created members.
- `enabled: bool` — whether the member is currently active. Maps to the dd.md `status` field; `enabled=True` corresponds to `active`, `enabled=False` to `archived`.
- `display_name: str | None` — mirror from Keycloak; may be absent during early provisioning.

The choice of `enabled: bool` vs. the dd.md `status` enum is deliberate for the adapter-facing API: adapters don't need the full lifecycle taxonomy, only "should this member have access right now." Document this divergence in the model's docstring and capture it as a decision-log entry.

**`FeatureKey`**
- `key: str` — the registry key (e.g., `"nextcloud.storage_gb"`).
- `app: str` — which adapter owns this (`"nextcloud"`, `"_platform"`, etc.).
- `value_type: Literal["bool", "int", "enum", "string_set"]`.
- `merge_rule: Literal["or", "and", "sum", "max", "min", "precedence", "union"]`.
- `default_value: bool | int | str | list[str] | None` — registry-defined default. Type union reflects the four `value_type` options plus None as a "no default" signal.
- `enum_values: list[str] | None` — required when `value_type == "enum"`, otherwise None.
- `precedence_order: list[str] | None` — required when `merge_rule == "precedence"`, otherwise None. Ordered lowest-to-highest.
- `requires: list[str]` — other feature keys this depends on. Empty by default.
- `enforcement: Literal["hard", "soft", "advisory"]`.
- `reset_period: Literal["none", "monthly", "daily", "hourly"]`.

Note: the SDK's `FeatureKey` mirrors the registry-side definition that adapters consume; it does not include `status`, `admin_only`, or `layer` (those are platform-side operational concerns, not adapter-facing). Document this in the docstring and capture as a decision-log entry.

**`Entitlement`**
- `member_id: str`.
- `feature_key: str` — the key string, not the full `FeatureKey` model. (Adapters look up the `FeatureKey` by key when they need merge rules or value types.)
- `value: bool | int | str | list[str]` — the per-source value. Union covers the four `value_type` options.
- `source_type: Literal["subscription", "subscription_state", "seat", "operator_grant"]`.
- `source_id: str` — public ID of the source row.

Note the SDK's `Entitlement` does *not* include `created_at` — adapters consume current desired state, not historical state. The dd.md timestamp is a platform-side concern.

**`AppAccount`** (per dd.md §3.8 inlined above)
- `member_id: str`.
- `app: str`.
- `external_id: str` — set once at provisioning; never changes.
- `status: Literal["active", "disabled", "deleted"]`.
- `last_reconciled_at: datetime | None` — null when never reconciled. Serialized as ISO-8601 string in JSON.
- `current_state: dict[str, Any]` — opaque jsonb the adapter writes.

**`DriftFinding`** (helper type for `DriftReport`)
- `kind: Literal["missing_in_app", "value_mismatch", "orphan_in_app", "identity_mismatch", "state_mismatch"]` — the five kinds of drift from the platform's drift taxonomy.
- `feature_key: str | None` — null for kinds that aren't feature-key-specific (e.g., `identity_mismatch`).
- `expected: Any` — what the entitlement says should be the case.
- `actual: Any` — what the app reports.
- `severity: Literal["info", "warning", "critical"]`.

**`DriftReport`**
- `member_id: str`.
- `app: str`.
- `findings: list[DriftFinding]` — empty list means no drift detected.
- `reconciled_at: datetime` — when the reconcile call was made. Serialized as ISO-8601 string in JSON.

**`Capabilities`** (returned from `capabilities()`)
- `app: str` — the app this adapter targets.
- `feature_keys: list[str]` — registry keys this adapter handles.
- `enforcement: dict[str, Literal["hard", "soft", "advisory"]]` — per-feature-key enforcement level.
- `limits: dict[str, int | str]` — adapter-specific operational limits (e.g., `{"max_concurrent_apply": 10}`). Open shape; adapter-defined.
- `schema_version: int` — per HLD §4's schema-evolution rule; the version this adapter is built against.

**`HealthStatus`**
- `healthy: bool` — overall.
- `app_reachable: bool` — the target app's API is reachable.
- `details: dict[str, str]` — free-form, adapter-defined.

**`AccountListPage`**
- `accounts: list[AppAccount]`.
- `next_cursor: str | None` — null when no more pages.

**`EventEnvelope`** (the JetStream event shape adapters consume)
- `event_id: str` — unique per event; used for dedup.
- `event_type: str` — e.g., `"entitlements.changed"`. Adapter authors filter by this.
- `member_id: str` — the affected member.
- `app: str` — which adapter app the event targets.
- `occurred_at: datetime` — when the event was generated. Serialized as ISO-8601 string in JSON.
- `schema_version: int` — the envelope schema version.

Note: the event *payload* (what changed about the member) is intentionally minimal — adapters re-fetch current desired state via the entitlements service's API on event receipt (per HLD §4 inlined above, "pulls current desired state from the entitlements service when an event arrives"). The envelope is signal, not state.

Round 0 defines `EventEnvelope` as a type only; the consumer helpers (durable consumer setup, dedup logic) are Round 4.

### Deliverable 6: `docs/contract.md`

The canonical prose specification of the contract. Structure:

1. **Introduction.** One paragraph: what the contract is, why it exists, where it sits in the platform. Reference HLD §4 by section number.
2. **The six methods.** One section per method (`capabilities`, `apply`, `disable`, `reconcile`, `health`, `list_accounts`). Each section includes:
   - Method signature in language-neutral prose.
   - Semantic contract: what the method must do.
   - Idempotency requirement: applicable to `apply`, `disable`, `reconcile`, `health`, `list_accounts` (all should be idempotent in the relevant sense; specify what "idempotent" means for each).
   - Error modes: what conditions cause failure, what should be raised or returned, what state changes are allowed on partial failure.
   - Examples: at minimum, one example showing a successful call and what it should produce.
3. **Identity mapping.** The rule from HLD §4: external_id is set once at provisioning and never changes. Explain why (audit trail coherence, prevention of accidental account fusing).
4. **Schema evolution.** The rule from HLD §4: adapters record their schema version; reconciliation upgrades members to newer schemas. Explain the `schema_version` field on `Capabilities`.
5. **Error handling.** Conventions for surfacing failures: HTTP status codes for the REST surface, exception types for in-process consumers. Explicit about what's part of the contract (the error contract) vs. what's adapter-specific (the exception class hierarchy within an adapter).
6. **Idempotency.** The twice-over requirement from HLD §4. Explicit about how it's tested (Round 3's conformance suite).
7. **JSON serialization.** The rule that the contract is JSON-shape, not Python-class. How a non-Python adapter satisfies the contract by serving the same JSON over HTTP and consuming the same JetStream subjects. Reference `CONVENTIONS.md` §5 and §8 by section number.

Each section is written in language-neutral prose. The Python type names appear when relevant (e.g., "the `Capabilities` model returned from `capabilities()`") but the prose does not lean on Python syntax to convey behavior.

The docstrings in the Protocol (deliverable 4) and the sections in this document agree on behavioral claims. When you write the Protocol docstring for `apply()`, the section in `docs/contract.md` on `apply()` uses the same words for the same things.

## Out of scope

- **No reference adapter implementation.** That's Round 1.
- **No testkit.** That's Round 2.
- **No tests of any kind.** Round 0's verification is type-check + documentation review only. If you find yourself writing `import pytest`, stop and surface.
- **No `src/lightweb_adapter_sdk/events/` module** beyond the `EventEnvelope` type defined in `types/`. The consumer helpers (durable consumer naming, dedup-by-event-id, async loop) are Round 4.
- **No `src/lightweb_adapter_sdk/reference/` module.** The reference adapter is Round 1.
- **No `src/lightweb_adapter_sdk/testkit/` module.** Round 2.
- **No `CHANGELOG.md` entries.** First entry lands with the first release in Round 5.
- **No GitHub Actions, Forgejo Actions, or CI configuration.** Round 5 handles release tooling. Round 0 just makes `make typecheck` and `make lint` runnable locally.
- **No drift-detection test comparing the Protocol docstrings against `docs/contract.md`.** That test is Round 1's deliverable. Round 0's enforcement of the docstring/prose match is manual: you do it by hand in the exit-criteria verification, and the supervisor reviews it.
- **No `__all__` exports** in any `__init__.py`. Round 0's modules are not yet a stable public-API surface; explicit re-exports come when the package's structure is more mature (likely Round 2 or 5).
- **No `tests/` directory.** Round 1 creates it; Round 0's `Makefile` targets operate on `src/` only.

## Exit criteria

A literal checklist. The session summary copies this with marks filled in and verbatim verification output where applicable.

- [ ] `make install` succeeds. (Verbatim output in session summary.)
- [ ] `make typecheck` returns success with zero errors over `src/`. (Verbatim output in session summary.)
- [ ] `make lint` returns success. (Verbatim output in session summary.)
- [ ] `make format-check` reports no formatting drift. (Verbatim output in session summary.)
- [ ] Every method in the `Adapter` Protocol has a docstring.
- [ ] Every type in `types/` has a class-level docstring.
- [ ] `docs/contract.md` has all seven sections listed in scope deliverable 6. (Confirm by listing the table of contents in the session summary.)
- [ ] **Per-method docstring/prose alignment table.** For each of the six Protocol methods, the session summary includes a small table showing: method name, the docstring's behavioral-claim sentence(s), the corresponding sentence(s) from `docs/contract.md`, whether they match. This is the manual enforcement of contract-bubbles-back-from-reference until Round 1 mechanizes it.
- [ ] `pyproject.toml` declares no `lightweb-platform` dependency. (Confirm by quoting the dependency list verbatim in the session summary.)
- [ ] No `__all__` exports in any `__init__.py`.
- [ ] Working tree clean. (Verbatim `git status --porcelain` output in session summary.)
- [ ] All work committed across multiple logical commits, not a single giant commit.

## Watch items for Round 0

These supplement the watch-list in `CLAUDE.md` and apply specifically to this round.

- **Pydantic v2, not v1.** Model definitions use `BaseModel` from `pydantic` (v2 in the pinned version), with v2 syntax (`Annotated[...]`, `Field(...)`, `model_config`). No v1 patterns (`@validator`, `Config` nested class, `parse_obj`).
- **Protocol, not ABC.** `typing.Protocol`, not `abc.ABC`. No inheritance from the SDK's class hierarchy required.
- **Docstring/prose alignment.** Write the Protocol docstring for a method and the corresponding `docs/contract.md` section together, in the same pass. Reviewing them as a pair at the time of writing is what catches drift early. The supervisor will review them as one unit at checkpoint 3.
- **No platform-repo imports.** Verify `pyproject.toml`. Verify no `from lightweb_platform import` anywhere in `src/`.
- **No tests in Round 0.** If you find yourself reaching for `pytest`, stop. Round 0's verification is type-check and documentation review only.
- **JSON-shape, not Python-class.** Field types in `types/` should serialize to obvious JSON shapes. Anything that requires custom `model_serializer`/`model_validator` calls is suspect — surface it as a design question and stop before adding it.
- **Type unions are JSON-portable.** `bool | int | str | list[str]` is a JSON-portable union. `datetime` fields are acceptable because Pydantic v2's default serialization is ISO-8601 string — but if you find yourself adding a custom serializer to make a datetime JSON-portable, that's a signal something else is wrong; surface it. Document the ISO-8601 format in the docstring of each model that has a datetime field.
- **No platform-side data model concepts that adapters don't need.** `Member` doesn't have `keycloak_id`. `Entitlement` doesn't have `created_at`. `FeatureKey` doesn't have `status` or `admin_only`. Adapter-facing types include only what adapters use. Surface any divergence from `$PLATFORM_REPO/libs/domain-types/` explicitly per the surfacing requirement below.
- **No `EventEnvelope` consumer logic.** Round 0 defines the type. Round 4 adds the consumer.

## Checkpoints

Stop and produce a checkpoint summary at each of these points. The operator pastes the summary to the supervisor; the supervisor approves continuing or asks for changes.

### Checkpoint 1: Toolchain wired

After `pyproject.toml`, `Makefile`, and `src/lightweb_adapter_sdk/__init__.py` are committed.

Checkpoint summary covers:

- List of created files.
- Output of `make install` (verbatim).
- Output of `make typecheck` (verbatim; trivially succeeds on empty `src/`).
- Output of `make lint` (verbatim; trivially succeeds).
- Output of `make format-check` (verbatim; trivially succeeds).
- The dependency list from `pyproject.toml` (verbatim, both runtime and dev).
- Any decisions added to `decisions-log/<session-slug>.md` so far.

Do not begin deliverable 4 (Protocol) until this checkpoint clears.

### Checkpoint 2: Protocol and types committed

After `src/lightweb_adapter_sdk/adapter/__init__.py` and `src/lightweb_adapter_sdk/types/__init__.py` are committed.

Checkpoint summary covers:

- The Protocol's six method signatures (verbatim, including type annotations and docstrings).
- The types' field lists (verbatim, one model at a time).
- Output of `make typecheck` (verbatim; expected to succeed).
- Output of `make lint` (verbatim; expected to succeed).
- Decisions added to `decisions-log/<session-slug>.md` since checkpoint 1.

Do not begin `docs/contract.md` until this checkpoint clears. The supervisor reviews the docstrings briefly at this checkpoint and selects **three methods** for full docstring/prose comparison at checkpoint 3. The supervisor's selection is in the `[SUPERVISOR]` response to this checkpoint.

### Checkpoint 3: `docs/contract.md` drafted

After `docs/contract.md` is drafted in full.

Checkpoint summary covers:

- The table of contents from `docs/contract.md` (verbatim, the seven sections).
- The full text (verbatim) of the three method sections the supervisor selected at checkpoint 2.
- A draft of the "Per-method docstring/prose alignment table" for all six methods (per exit criteria).
- Output of `make lint` and `make typecheck` (still expected to succeed).
- Decisions added to `decisions-log/<session-slug>.md` since checkpoint 2.

The supervisor reviews the three selected method sections against the corresponding Protocol docstrings. If they match, the round proceeds to final session summary. If they don't, the supervisor identifies the divergences and the implementer revises in the same session (no new checkpoint; the supervisor approves once the revisions land).

## Things to surface in the session summary

Beyond the standard session summary template in `CLAUDE.md` §"Session summary template":

- **Decisions I almost made without asking.** Required section, even if empty (in which case write "None"). This is the load-bearing defense against barreling through. Scan back through every type field, every method signature, every word choice in `docs/contract.md` — and flag any that you made without clear pre-specification in this prompt or the inlined content.
- **Verbatim comparison against `$PLATFORM_REPO/libs/domain-types/`.** If the directory exists, for each type the SDK defines (`Member`, `FeatureKey`, `Entitlement`, `AppAccount`), quote the corresponding shape from `libs/domain-types/` verbatim in the session summary, then state whether the prompt's field list **matches**, **narrows** (drops fields the prompt justifies dropping), **omits without justification**, or **contradicts** (uses different types or names for the same concept). Surface contradictions and unjustified omissions as design questions. A "no divergences found" summary is acceptable only if it's preceded by the verbatim quotes — confirmation without the quoted source is insufficient. If `libs/domain-types/` does not exist, state that and proceed.
- **Pydantic v2 model shape concerns.** Any field whose Pydantic-side shape requires non-trivial serialization (custom validators, custom serializers, discriminator-based unions) is a candidate for "violates the JSON-shape-not-Python-class stance." List each.
- **Contract decisions made while writing `docs/contract.md`.** Specifically, where the inlined HLD §4 content was silent or ambiguous and you made a call. Examples beyond the three pre-flagged below: what HTTP status code `health()` reports when the adapter is up but the target app is down; whether `list_accounts()` with a cursor for a since-deleted page returns empty or raises; what `disable()` does when called for a member who has no AppAccount yet.
- **The platform-repo HEAD comparison.** The HEAD recorded in this prompt's `[SUPERVISOR]` block vs. the HEAD when you ran the pre-flight check. They should match. If they differ, the operator updated something mid-round; flag it.
- **`EventEnvelope` shape vs. `$PLATFORM_REPO/libs/events/schemas/`.** If the schemas directory exists and has an entitlement-changed event schema, compare verbatim per the instruction above for `libs/domain-types/`. If the SDK's `EventEnvelope` diverges from the published schema, surface the divergence. If the directory doesn't exist, flag that the SDK is defining the canonical envelope shape in absence of a platform-side schema.

## Closing notes from supervisor

This is the first round in the adapter-sdk repo. The contract decisions you make here are load-bearing in a way that subsequent rounds' decisions are not — the Protocol's shape, the types' field lists, and `docs/contract.md`'s phrasing all become the things SemVer protects in `CONVENTIONS.md` §1.2. A breaking change to any of them after the first release costs adapter authors real work.

The most important discipline for this round is: when you're about to make a decision and you're not sure whether it's settled by the prompt, write the decision into `decisions-log/<session-slug>.md` and flag it in the checkpoint or session summary's "Decisions I almost made without asking" section. The cost of an unnecessary flag is a sentence; the cost of an unflagged decision is a future breaking change.

Three specific places where I expect contract gaps to surface. For each, write what you decide and flag it in the session summary; do not leave them implicit:

1. **What does `apply()` return when called with an empty `entitlements` list?** Plausibly the right answer is "an `AppAccount` with status `active`, `current_state` reflecting no entitlements" — i.e., the adapter ensures the account exists even with zero entitlements. But this is not stated explicitly in HLD §4. Possibilities to weigh: (a) ensure-account-exists as above; (b) treat empty-list as equivalent to `disable(member)`; (c) raise an error since the call is ambiguous.

2. **What does `reconcile()` do when the target app is unreachable?** Possibilities: (a) raise an adapter-specific exception (the call cannot do its job); (b) return a `DriftReport` with a single `state_mismatch` finding marking the unreachability; (c) return an empty `DriftReport` with `reconciled_at` set (silently misleading; surface this as wrong if you consider it). The contract should not leave callers guessing.

3. **What does `health()` report when the adapter is up but the target app is down?** `healthy: false, app_reachable: false` is the obvious choice, but consider whether `healthy` is a strict conjunction of "adapter responding" and "app reachable," or whether the adapter being up alone is sufficient for `healthy: true` with `app_reachable: false` as a separate signal. The contract should be explicit about how the two booleans relate.

None of the three is settled in the prompt. The right answer to each is: write what you think is right, flag it, the supervisor reviews. Other ambiguities will surface during writing; flag them the same way.

Expect this round to take longer than later rounds. The deliverable count is small, but every word in `docs/contract.md` and every field in `types/` will be re-read for years. Take the time.
