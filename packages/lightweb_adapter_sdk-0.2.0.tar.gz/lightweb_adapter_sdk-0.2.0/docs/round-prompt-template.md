# Round prompt template

This document defines the structure of round prompts the supervisor produces and the implementer receives. The supervisor uses this as a writing template; the implementer reads it to know what to expect at session start.

This is the first place the `[SUPERVISOR]` block convention is defined. All supervisor-authored communications (round prompts, mid-session resolutions, halt directives, wrap approvals) use the same block header convention.

## The `[SUPERVISOR]` block

Every message from the supervisor begins with a fenced block:

```
[SUPERVISOR]
Round: <N>
Scope: <round-prompt | ambiguity-resolution | halt | wrap-approval>
Platform repo: <absolute or relative path to lightweb-platform checkout>
Platform repo HEAD: <commit hash at time of prompt creation>
Date: <YYYY-MM-DD>
```

Followed by a blank line, then the body of the message.

The block is mechanical. The implementer recognizes a real supervisor message by the literal `[SUPERVISOR]` opener; anything pasted by the operator without this block is operator-relayed information, not supervisor-direct, and the implementer should ask for the literal supervisor text if direction matters.

**Scope values:**

- **`round-prompt`** — a full round to execute. The body follows the round-prompt structure below.
- **`ambiguity-resolution`** — an answer to a question the implementer surfaced mid-session, or a checkpoint approval. The body answers the question (or approves the checkpoint) and indicates whether to continue or wait for further input.
- **`halt`** — an instruction to stop work immediately and report current state. The body explains why.
- **`wrap-approval`** — the supervisor has reviewed the session summary and approves running the wrap procedure. The body may include final notes or "wrap and push" vs "wrap" (local only).

**Platform repo and HEAD.** These pin the version of the platform monorepo's documents the round was specified against. If the implementer reads `$PLATFORM_REPO/docs/hld.md` during the round, it's reading the version at the recorded HEAD. If the platform repo has moved on between when the prompt was written and when the round is executed, the operator updates the round prompt rather than letting the implementer execute against a different version.

## Round prompt structure

A round prompt with `Scope: round-prompt` follows this structure. Sections are ordered; the implementer reads them in order.

### 1. Round identification

```markdown
# Round <N> — <short title>

**Status:** Active.
**Previous round:** Round <N-1> wrapped on <date>. Summary at: <link or path>.
**Working tree state:** main is at <commit hash>; the SDK repo is clean.
```

### 2. Required reading

A literal numbered list of files the implementer reads in full before starting. Paths are relative to the SDK repo root unless prefixed with `$PLATFORM_REPO/`.

```markdown
## Required reading

Read these files in full, in order. Do not skim. Do not infer content from filenames.

1. `CLAUDE.md` — already read if you reached this prompt.
2. `ARCHITECTURE.md` — repo orientation.
3. `CONVENTIONS.md` — sections X.Y, X.Z as listed in §3 below.
4. `docs/contract.md` — the contract specification.
5. `$PLATFORM_REPO/docs/hld.md` — section §4 specifically; the supervisor has inlined the relevant portions in §3 below for convenience but the canonical version is in the platform repo.
6. This round prompt — finish reading before starting work.
```

If the round depends on files not yet created (Round 0 creates `docs/contract.md`, so it can't appear in the read list for Round 0), the read list says so explicitly: "The Protocol in `src/lightweb_adapter_sdk/adapter/` does not yet exist; you will create it."

### 3. Inlined context

This is the section that varies most by round. The supervisor inlines, verbatim, the canonical-document content the round depends on. Inlining rather than referencing serves two purposes: the implementer has the canonical text in immediate context (no need to read across many files at high cognitive load), and the round prompt is self-contained (auditable later as "what was the spec at the time this round was executed").

For early rounds, inline generously. The trimming criterion is concrete: when the implementer is consistently producing summaries that demonstrate full read-through of referenced documents — specific quotes, accurate cross-references, no signs of pattern-matching from filenames alone — the next round's prompt can rely on references rather than inlining. This criterion is implementer-agnostic; a more capable model will satisfy it faster than a less capable one, but the criterion is the same.

The format is a sequence of fenced blocks, each labeled with its source:

```markdown
## Inlined context

### From `CONVENTIONS.md` §1.2 (what counts as a breaking change)

> [verbatim quote, multi-paragraph]

### From `$PLATFORM_REPO/docs/hld.md` §4 (app adapters)

> [verbatim quote, multi-paragraph]

### From `$PLATFORM_REPO/docs/services/entitlements/dd.md` §3.8 (AppAccount)

> [verbatim quote]
```

The implementer treats inlined content as authoritative for the duration of the round. If the implementer needs to read more from any source, it can — but the round's design decisions are made against what's inlined.

### 4. Scope

A numbered list of deliverables, each concrete enough to be checkable.

```markdown
## Scope

This round produces:

1. `src/lightweb_adapter_sdk/adapter/__init__.py` — defines a `typing.Protocol` named `Adapter` with the six method signatures from §3 above. Docstrings on each method match the prose specification in `docs/contract.md` word-for-word where the prose names a specific behavior.
2. `src/lightweb_adapter_sdk/types/__init__.py` — defines Pydantic v2 models for the shared types: `Member`, `FeatureKey`, `Entitlement`, `AppAccount`, `DriftReport`, `Capability`. Fields match the platform monorepo's `libs/domain-types/` as of the recorded HEAD; types diverge only where noted in §3.
3. `docs/contract.md` — the canonical prose specification of the contract. Structure: introduction, then one section per method, then sections on identity mapping, schema evolution, error handling, idempotency. Each method section includes signature, semantic contract, idempotency requirement, error modes, examples.
4. `pyproject.toml` — declares the package, its dependencies (pydantic v2, no others required for Round 0), Python version (3.12+), and the build backend.
5. `Makefile` — minimal targets: `install`, `typecheck`, `format`, `lint`, `clean`. No test targets in Round 0 (no tests yet).

Each deliverable is committed during work as it reaches a verifiable state — see the commit triggers in `CLAUDE.md` §"Commit discipline."
```

The implementer treats this list as exhaustive. Anything that looks "obviously needed but not listed" is surfaced as a design question, not added.

#### Mechanical-check deliverables

A round may deliver a mechanical check — a test, CI guard, or `ast`-based validator that enforces some discipline going forward. Round 3's contract-docstring drift test and Round 4's conformance-independence check are examples.

Mechanical-check deliverables need framing that allows for an outcome the round prompt didn't anticipate: the check fails on the existing codebase, and making it pass requires a design change rather than an implementation fix. The framing should explicitly say what happens in that case. Two patterns work:

**Pattern A — absolute rule from the start.** The check is expected to pass cleanly against the existing codebase. The round prompt's exit criteria require the check to pass. If the check fails, the implementer surfaces immediately; the supervisor decides whether to re-scope the round to include the design fix that would make the check pass, or to retract the deliverable.

```markdown
Deliverable N: <check description>. The check is expected to pass against
the current codebase. If it fails on existing code, stop and surface as
a design question — do not modify existing code to satisfy the check
without supervisor sign-off.
```

**Pattern B — regression-guard with explicit baseline.** The check is expected to fail on the existing codebase; the round prompt scopes the check as a regression guard with a documented baseline of known violations. New violations beyond the baseline fail the check; existing violations are grandfathered. The deliverable includes documenting the baseline and the work to remove it eventually.

```markdown
Deliverable N: <check description>, scoped as a regression guard.
The check tolerates the existing N violations (listed in
_BASELINE_VIOLATIONS in the check's source) and fails only if new
violations appear beyond the baseline. The baseline reflects
[decision-log reference] and is removed when [follow-up round
description] lands.
```

The patterns are mutually exclusive — pick one in the round prompt. Don't write a deliverable that's "implement an absolute check" and then re-scope mid-round if it fails. The re-scope is fine, but it should happen via the supervisor surfacing the change, not the implementer routing around the check.

If the round prompt is silent about which pattern applies, the implementer defaults to Pattern A: a check that fails on existing code is a design-surfacing event, surface as a design question rather than modify code to make it pass.

### 5. Out of scope

What the implementer is *not* doing in this round. Stating this prevents scope creep.

```markdown
## Out of scope

- No reference adapter implementation. That's Round 1.
- No testkit. That's Round 2.
- No tests of any kind. Round 0's verification is type-check and documentation review.
- No `events/` module. The event envelope is defined in `types/` in Round 0 (as a type); the consumer helpers are Round 4.
- No `CHANGELOG.md` entries. The first changelog entry lands with the first release in Round 5.
```

### 6. Exit criteria

A literal checklist the implementer runs and the supervisor verifies.

```markdown
## Exit criteria

- [ ] `make typecheck` returns success with zero errors over `src/`.
- [ ] `make lint` returns success.
[... full checklist ...]
- [ ] Working tree clean.
- [ ] All work committed.
```

The implementer's session summary copies this checklist with completion marks and verbatim verification output for the automated checks.

**Mapping to checkpoints.** Each checkpoint specification (§8 below) names which exit-criteria items are expected to land by that checkpoint. The implementer's checkpoint summary shows verbatim `ls` (or equivalent) evidence for those items, per the checkpoint summary template in `CLAUDE.md` §"Checkpoints." Items not yet expected at a given checkpoint don't appear in that checkpoint's progress section; items missing at wrap that the prompt expected earlier are a discipline gap to surface in retrospective.

The mapping is the round prompt's call. Small rounds may map nothing per checkpoint and rely on wrap review; large rounds (Round 3 onward, in practice) gain meaningfully from the mapping because deliverable misses surfaced at wrap-eve are expensive to address.

### 7. Watch items

Round-specific things the supervisor will look for in the session summary. These supplement the watch-list in `CLAUDE.md`.

```markdown
## Watch items for Round 0

- **Pydantic v2, not v1.** The model definitions use `BaseModel` from `pydantic` (which is v2 in the SDK's pinned version), with field types using v2 syntax (`Annotated[...]`, `Field(...)`, model_config). No v1 patterns (`@validator`, `Config` class).
- **Protocol, not ABC.** `typing.Protocol`, not `abc.ABC`. Adapter authors satisfy the contract structurally; they don't inherit from the SDK.
- **Docstring/prose alignment.** The contract-bubbles-back-from-reference watch (CLAUDE.md) starts here. The Protocol's docstrings and `docs/contract.md` are written together; the supervisor reviews them as one unit.
- **No platform-repo imports.** This is Round 0; the temptation is low. But `pyproject.toml` is being written in this round; verify no `lightweb-platform` dependency lands there.
```

### 8. Checkpoints

Round-specific pause points where the implementer stops, produces a checkpoint summary, and waits for supervisor approval before continuing. Most rounds have three; small rounds may have one or none; large rounds may have more.

Round 0's checkpoints, as an example:

```markdown
## Checkpoints

Stop and produce a checkpoint summary at each of these points. The operator pastes the summary to the supervisor; the supervisor either approves continuing or asks for changes.

1. **After `pyproject.toml` and `Makefile` are committed.** Checkpoint summary: list of created files, output of `make install` and `make typecheck` (the latter trivially succeeding on an empty src tree).

   *Exit-criteria items expected by this checkpoint:* `pyproject.toml` exists; `Makefile` exists; `make typecheck` returns success on an empty src tree.

2. **After the Protocol and types are committed.** Checkpoint summary: the Protocol's method signatures, the types' field lists, output of `make typecheck`. Specifically: do not begin `docs/contract.md` until this checkpoint clears. The Protocol's docstrings should be present but minimal at this checkpoint; the supervisor will review them against the prose in step 3.

   *Exit-criteria items expected by this checkpoint:* `src/lightweb_adapter_sdk/adapter/__init__.py` exists with all six Protocol methods; `src/lightweb_adapter_sdk/types/__init__.py` exists with the shared types; every Protocol method has a docstring (minimal acceptable here, sharpened in step 3); `make typecheck` returns success on the populated src tree.

3. **After `docs/contract.md` is drafted.** Checkpoint summary: the table of contents, plus three method sections quoted in full (chosen by the supervisor in checkpoint 2 response). The supervisor reviews these against the Protocol docstrings before final wrap.

   *Exit-criteria items expected by this checkpoint:* `docs/contract.md` has sections per the table-of-contents check; Protocol method docstrings and the corresponding contract.md prose align on terminology; all other items not yet listed are checked at wrap.
```

### 9. Things to surface in the session summary

Beyond the standard session summary template in `CLAUDE.md`, this section names specific things the supervisor wants flagged from this round.

```markdown
## Things to surface

- Any contract decision you made while writing the Protocol or `docs/contract.md` that wasn't pre-specified in this prompt or the inlined HLD §4 content. (See "Decisions I almost made without asking" in the session summary template.)
- Any place where the Pydantic v2 model shape diverges from the platform's `libs/domain-types/`. Even small divergences — name a field differently, narrow a type — are surfaced explicitly.
- Anywhere the JSON-shape-not-Python-class stance was awkward. If you found yourself wanting to add Pydantic validators or `model_config` settings that aren't expressible as JSON Schema, surface it.
- The platform-repo HEAD recorded in this prompt vs. the HEAD when you read the inlined content. If they match, note it; if they differ for any reason (operator updated the path mid-session), flag it.
```

### 10. Closing notes from supervisor

Free-form supervisor commentary. May be empty. Used for things like "this is the first round, expect rough edges, document everything you weren't sure about" or "the SemVer stance in CONVENTIONS.md §1 came up in supervisor review; pay extra attention to ensuring nothing in Round 0 commits us to a shape we can't break before 1.0."

## A worked example

A complete worked example of a round prompt — the prompt that started Round 0, with all ten template sections filled in — lives in [`docs/examples/round-0-prompt.md`](examples/round-0-prompt.md). It's a long file (~170 lines) and intentionally so: Round 0 is the foundational round and its prompt establishes the template's voice and structure. Later rounds' prompts are shorter as the implementer's reliable read radius grows; the Round 0 prompt is the maximalist reference.

Read the worked example when drafting a new round prompt. Don't transcribe it section-by-section — adapt for the round's actual content.

## When to depart from the template

The template is a default, not a constraint. Specific cases where the supervisor departs:

- **Ambiguity-resolution messages** are short; they answer a question and indicate continue/wait. They have a `[SUPERVISOR]` block but no scope/watch items/checkpoints structure.
- **Halt directives** are short and explanatory: why stop, what to report, what not to do meanwhile.
- **Wrap-approval messages** are short and explicit: "approved, wrap and push" or "approved, wrap only (don't push yet)" or "not yet approved, here's what needs changing."
- **Cleanup rounds** between major rounds may be small enough not to need full structure. The supervisor's call.

The structure is the default; deviations are deliberate and noted.
