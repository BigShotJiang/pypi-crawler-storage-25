# Event Consumer Module

The event consumer module enables adapters to react to JetStream events that signal entitlement changes. This document covers the module's architecture, components, and usage patterns.

## Overview

The event consumer module sits alongside the core adapter contract (`Adapter` Protocol) as a separate, independent Protocol (`EventConsumer`). An adapter may implement `Adapter` without `EventConsumer` (e.g., a pull-only adapter) and vice versa.

```
src/lightweb_adapter_sdk/
├── adapter/                    # Adapter Protocol (six methods)
├── event_consumer/            # EventConsumer Protocol + implementations
│   ├── protocol.py            # EventConsumer Protocol definition
│   ├── parser.py              # Raw JetStream payload → EventEnvelope
│   ├── dedup.py               # In-memory LRU deduplication cache
│   └── jetstream.py           # JetStream-backed consumer (NATS)
├── reference/
│   └── event_consumer.py      # ReferenceEventConsumer for ExampleApp
└── testkit/
    ├── fake_event_source.py   # FakeEventSource for testing
    └── fake_entitlements.py   # FakeEntitlementsService
```

## Components

### EventConsumer Protocol

Defined in `event_consumer/protocol.py`. A structural Protocol with a single method:

```python
@runtime_checkable
class EventConsumer(Protocol):
    async def consume(self, envelope: EventEnvelope) -> None: ...
```

The adapter's responsibility is narrow: receive a parsed, deduped, filtered `EventEnvelope`, fetch current desired state from the entitlements service, and invoke the adapter's `apply()`.

**Idempotency requirement:** The same envelope may be delivered more than once if dedup state is lost (e.g., consumer restart with empty cache). The SDK's default dedup absorbs this; this requirement is the contractual backstop.

### Parser

Defined in `event_consumer/parser.py`. Transforms raw JetStream JSON payloads into `EventEnvelope` instances.

**Platform envelope shape** (per `libs/events/schemas/entitlements/_envelope.json`):

```json
{
    "id": "<event-id>",
    "type": "entitlements.<entity>.<verb>",
    "specversion": "1.0",
    "time": "2026-05-17T12:00:00Z",
    "source": "service:entitlements",
    "subject": {"type": "member", "id": "mem_..."},
    "data": {"member_id": "mem_...", ...},
    "context": {"trace_context": "..."}
}
```

**SDK EventEnvelope** (flattened):

```python
EventEnvelope(
    event_id="evt-123",
    event_type="entitlements.member.entitlements_changed",
    event_version="1.0",
    occurred_at=datetime(2026, 5, 17, 12, 0, 0, tzinfo=timezone.utc),
    emitted_by="service:entitlements",
    member_id="mem_abc",
    context={"trace_context": "trace-xyz"},
)
```

Key transformation: `data.member_id` is flattened to the top level as `member_id`; `subject` is omitted entirely.

**Error handling:** Raises `ParseError` (a `ValueError` subclass) for invalid JSON, missing required fields, invalid `data.member_id`, or unparseable `time` fields.

### Deduplication Cache

Defined in `event_consumer/dedup.py`. An in-memory LRU cache that tracks seen `event_id` values and evicts oldest entries when the cache reaches its configured size limit.

- **Implementation:** `collections.OrderedDict` with `move_to_end` on access and `popitem(last=False)` on overflow.
- **Default size:** 10,000 events.
- **O(1) operations:** `is_seen()`, `record()`, `clear()`.

```python
cache = EventDedupCache(max_size=5000)
if not cache.is_seen(envelope.event_id):
    await consumer.consume(envelope)
    cache.record(envelope.event_id)
```

### JetStreamEventConsumer

Defined in `event_consumer/jetstream.py`. A concrete implementation that connects to NATS/JetStream, subscribes to entitlement-changed event subjects, and dispatches parsed/deduped/filtered events to an `EventConsumer` (typically the adapter).

**Subscription pattern:** The SDK defaults to a single wildcard subscription to `"entitlements.>"` with app-level filtering via `is_entitlement_change_event()`. This is simpler than multiple subscriptions and the filter exists anyway.

**Durable naming:** The SDK defaults to `"<app>-adapter"` derived from the adapter's `capabilities().app`, ensuring deterministic durable names across deployments for platform delivery-state tracking.

```python
consumer = JetStreamEventConsumer(
    nats_url="nats://localhost:4222",
    adapter=adapter,
    consumer=adapter,  # adapter implements both Adapter and EventConsumer
    # subscription_subjects defaults to ("entitlements.",)
    # durable_name defaults to "<app>-adapter"
    # cache defaults to EventDedupCache() with max 10,000
)
await consumer.start()
# ... run ...
await consumer.stop()
```

**Message handling flow:**

1. Raw JetStream message arrives → `handle_event(raw_payload)`
2. Parse → `EventEnvelope` (or log error and ack)
3. Check dedup → skip if seen
4. Filter via `is_entitlement_change_event()` → skip non-change events (but still record in dedup)
5. Call `consumer.consume(envelope)` → log errors, ack on success, nak on failure

### ReferenceEventConsumer

Defined in `reference/event_consumer.py`. The reference implementation of the `EventConsumer` Protocol for the `ExampleApp` adapter. Demonstrates the apply-pattern: on each change event, fetches the member's current entitlements from a (fake or real) entitlements service and invokes `ExampleApp.apply()`.

```python
consumer = ReferenceEventConsumer(
    adapter=example_app_adapter,
    entitlements_client=fake_entitlements_service,
)
await consumer.consume(envelope)
```

### Testkit

**FakeEventSource** (`testkit/fake_event_source.py`): In-process fake that publishes `EventEnvelope` instances as raw JetStream-style JSON bytes, allowing tests to drive event consumer behavior without a real NATS/JetStream connection.

**FakeEntitlementsService** (`testkit/fake_entitlements.py`): In-process fake of the platform's entitlements service. Provides staging of member entitlements and recording of provisioned reality via `upsert_app_account()`. Includes `_member_cache` for event consumer tests.

## Event Type Filtering

The `is_entitlement_change_event()` helper (from `types/__init__.py`) returns `True` for events that trigger member-state-changing entitlement re-derivation:

- `entitlements.member.entitlements_changed`
- `entitlements.member.archived`
- `entitlements.subscription.created`
- `entitlements.subscription.state_changed`
- `entitlements.subscription.cancelled`
- `entitlements.operator_grant.created`
- `entitlements.operator_grant.revoked`

Excluded (informational, not member-scoped):
- `entitlements.app_account.created` (adapter-reflexive)
- `entitlements.feature_key.registry_reloaded` (registry maintenance)

## Dependencies

- `nats-py >= 2.6` — declared in `pyproject.toml` for `JetStreamEventConsumer`. The `py.typed` marker in nats-py 2.6+ ensures clean type checking.
- `pydantic >= 2.0` — for `EventEnvelope` and other shared types.

## Testing

Conformance tests are in `tests/unit/test_event_consumer_conformance.py` and cover:

- `EventDedupCache`: LRU eviction, max_size enforcement, is_seen/record/clear.
- `parse_envelope`: valid payloads, missing fields, invalid JSON, invalid time, missing member_id, context preservation.
- `JetStreamEventConsumer.handle_event`: parsing, dedup, filtering, error handling (using `FakeEventSource` without real NATS).
- `ReferenceEventConsumer`: consume method, apply/reconcile flow.
- `FakeEventSource`: publish, publish_async, registered consumers.
- `FakeEntitlementsService`: set_member, get_member, entitlements CRUD.

## Usage Pattern

```python
from lightweb_adapter_sdk.event_consumer.jetstream import JetStreamEventConsumer
from lightweb_adapter_sdk.event_consumer.protocol import EventConsumer
from lightweb_adapter_sdk.types import EventEnvelope

class MyAdapter(Adapter, EventConsumer):
    def capabilities(self) -> Capabilities: ...
    def apply(self, member, entitlements) -> AppAccount: ...
    # ... other Adapter methods ...

    async def consume(self, envelope: EventEnvelope) -> None:
        # Fetch current desired state from entitlements service
        member = self.entitlements_client.get_member(envelope.member_id)
        entitlements = self.entitlements_client.list_entitlements(envelope.member_id)
        # Apply the changes
        self.apply(member, entitlements)

# Wire up
adapter = MyAdapter(...)
consumer = JetStreamEventConsumer(
    nats_url=os.environ["NATS_URL"],
    adapter=adapter,
    consumer=adapter,
)
await consumer.start()
```
