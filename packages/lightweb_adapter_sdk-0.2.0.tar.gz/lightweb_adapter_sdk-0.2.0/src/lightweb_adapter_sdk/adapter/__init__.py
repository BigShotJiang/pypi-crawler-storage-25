"""The adapter contract as a structural Protocol.

Every adapter must implement the six methods declared here.
See docs/contract.md for the prose specification.
"""

from typing import Protocol, runtime_checkable

from lightweb_adapter_sdk.types import (
    AccountListPage,
    AppAccount,
    Capabilities,
    DriftReport,
    Entitlement,
    HealthStatus,
    Member,
)


@runtime_checkable
class Adapter(Protocol):
    """Protocol defining the six-method adapter contract.

    This is a structural Protocol, not a base class.  Adapter authors
    are not required to inherit from this class; any class that
    implements the six methods with matching signatures satisfies
    the contract.
    """

    def capabilities(self) -> Capabilities:
        """Declare which feature keys this adapter handles and its limits.

        Returns static metadata describing the adapter's scope: the app
        it targets, the feature keys it enforces, and any operational
        constraints (e.g. maximum concurrent applies).  Called once at
        adapter registration.

        Idempotent: repeated calls with no intervening configuration
        changes return an equivalent result.

        Error modes: should not raise.  All required information is
        static configuration available at adapter startup.
        """

    def apply(self, member: Member, entitlements: list[Entitlement]) -> AppAccount:
        """Idempotently make the target app's state match the desired entitlements.

        Creates accounts that should exist; updates quotas that have
        changed; adjusts feature flags.  Returns the resulting
        ``AppAccount`` data (``external_id`` and current state) so the
        entitlements service can record the provisioned reality.

        When called with an empty ``entitlements`` list, ensures the
        account exists with status ``"active"`` and ``current_state``
        reflecting no entitlements.  (Distinct from ``disable`` which
        sets status to ``"disabled"``.)

        Error modes: should raise on target-app unreachable or
        authentication failure.  Partial application is acceptable only
        if the adapter's internal state remains consistent for a retry.
        """

    def disable(self, member: Member) -> None:
        """Soft-disable a member's access while preserving data.

        Blocks the member from using the target app without destroying
        the account or its data.  Reversible by a subsequent ``apply``.

        Idempotent: calling disable multiple times has the same effect
        as calling it once.  A no-op if the member is already disabled
        or has no account in this app.

        Error modes: should raise on target-app unreachable.  Should
        NOT raise when the member has no account.
        """

    def reconcile(self, member: Member, entitlements: list[Entitlement]) -> DriftReport:
        """Read-only drift detection: compare app state to desired state.

        Compares the target app's current state for ``member`` against
        the desired state described by ``entitlements``.  Returns a
        structured ``DriftReport`` enumerating each discrepancy as a
        ``DriftFinding``.  An empty ``findings`` list means no drift.
        Never mutates the target app.

        The ``entitlements`` argument is the same shape passed to
        ``apply`` — current desired state, not deltas.  The reconciler
        passes the entitlements it currently knows for the member; the
        adapter does not fetch them on its own.

        Four cases by (account-presence x entitlements-presence):
        account-exists & entitlements-non-empty is the expected case
        (compare and report mismatches); account-exists & entitlements-empty
        means correct no-entitlements state (no drift); account-absent &
        entitlements-non-empty produces a ``missing_in_app`` finding;
        account-absent & entitlements-empty is correct no-account state
        (no drift).

        A return with empty findings means the adapter was able to
        contact the target app and found no drift; it is not a fallback
        for unreachability.  When the target app is unreachable, raises
        an adapter-specific exception rather than returning a
        misleadingly empty report.

        Idempotent: repeated calls with unchanged inputs return the
        same report (modulo clock drift in ``reconciled_at``).
        """

    def health(self) -> HealthStatus:
        """Report adapter and target-app reachability.

        Returns a ``HealthStatus`` with two boolean signals:
          - ``healthy``: ``True`` only when the adapter is responding AND
            ``app_reachable`` is ``True`` (strict conjunction).
          - ``app_reachable``: the target app's API responded.

        The method itself must not raise.  If the adapter cannot perform
        the health check, return ``healthy=False`` with
        ``app_reachable=False`` and use ``details`` to explain.
        """

    def list_accounts(self, cursor: str | None = None) -> AccountListPage:
        """Page through every account in the target app.

        Used by the reconciler for whole-system drift detection.
        Returns a window of accounts and a ``next_cursor`` for
        pagination (``None`` when no more pages).

        An expired or invalid cursor returns an empty page with
        ``next_cursor=None`` rather than raising.

        Error modes: should raise on target-app unreachable.
        """
