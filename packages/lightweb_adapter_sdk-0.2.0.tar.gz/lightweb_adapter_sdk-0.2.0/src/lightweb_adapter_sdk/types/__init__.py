"""Pydantic models that constitute the adapter contract's shared types.

These models are the Python expression of the contract shapes described
in docs/contract.md. A non-Python adapter satisfies the contract by
producing and consuming the same JSON shapes; it is not required to use
Pydantic. See docs/contract.md §7 and CONVENTIONS.md §5 and §8.
"""

from datetime import datetime
from typing import Any, Literal

from pydantic import BaseModel


class Member(BaseModel):
    """Adapter-facing view of a Member.

    Divergences from the platform data model (dd.md §3.2):

    - The dd.md ``status`` field (``active | archived``) is represented as
      ``enabled: bool`` here.  Adapters only need a binary signal: should
      this member have access right now?  The full lifecycle taxonomy
      (archived vs. suspended vs. ...) is a platform-side concern.

    - ``keycloak_id`` is omitted; adapters never need the Keycloak
      internal identifier.

    - ``billing_email`` is omitted; adapters never interact with Lago.
    """

    member_id: str
    """The public ID (``mem_<base58>``)."""

    member_type: Literal["individual", "business"]
    """Type discriminator."""

    external_ids: dict[str, str]
    """Per-app identity mapping (key: app name, value: external ID).

    Empty for members who have not yet been provisioned in any app.
    """

    enabled: bool
    """Whether the member is currently active.

    Maps to the platform ``status`` field: ``enabled=True`` corresponds
    to ``active``, ``enabled=False`` to ``archived``.
    """

    display_name: str | None = None
    """Mirror from Keycloak as of the last sync.

    May be absent during early provisioning, and may be stale if a
    member updated their Keycloak profile after the last sync.
    """


class FeatureKey(BaseModel):
    """Registry-defined feature key as consumed by adapters.

    Divergences from the platform FeatureKey table (dd.md §3.6):

    - ``status`` (``active | deprecated | experimental``) is omitted;
      it is a platform-side operational concern for registry lifecycle.
      An adapter only ever sees keys it is configured to handle.

    - ``admin_only`` is omitted; visibility control is a platform-side
      access-control concern, not an adapter concern.

    - ``layer`` (``core | community``) is omitted; determined by source
      directory at registry load time, not an adapter concern.
    """

    key: str
    """Registry key (e.g., ``nextcloud.storage_gb``)."""

    app: str
    """Which adapter owns this key (``nextcloud``, ``_platform``, etc.)."""

    value_type: Literal["bool", "int", "enum", "string_set"]
    """The type of value this key carries."""

    merge_rule: Literal["or", "and", "sum", "max", "min", "precedence", "union"]
    """How multiple sources contribute to the effective value."""

    default_value: bool | int | str | list[str] | None = None
    """Registry-defined default when no source contributes a value.

    ``None`` means no default (the key must have at least one source,
    or the effective value is undefined).
    """

    enum_values: list[str] | None = None
    """Valid enum values; required when ``value_type == "enum"``."""

    precedence_order: list[str] | None = None
    """Ordering for the ``precedence`` merge rule; lowest-to-highest.

    Required when ``merge_rule == "precedence"``.
    """

    requires: list[str] = []
    """Other feature keys this key depends on. Empty by default."""

    enforcement: Literal["hard", "soft", "advisory"]
    """How strictly violations are enforced.

    - ``hard``: violation is an error that must be surfaced.
    - ``soft``: violation is logged but does not block operation.
    - ``advisory``: violation is recorded for reporting only.
    """

    reset_period: Literal["none", "monthly", "daily", "hourly"]
    """How often quotas for this key reset. ``none`` means never."""


class Entitlement(BaseModel):
    """A single source's contribution to a member's effective entitlements.

    Divergences from the platform Entitlement row (dd.md §3.5):

    - ``created_at`` is omitted. Adapters consume current desired state,
      not historical state. The timestamp is a platform-side concern
      used by the resolver and audit trail.
    """

    member_id: str
    """The public ID of the member this entitlement belongs to."""

    feature_key: str
    """The registry key, as a string (not the full FeatureKey model).

    Adapters look up the FeatureKey definition by key when they need
    merge rules, value types, or enforcement levels.
    """

    value: bool | int | str | list[str]
    """The per-source value. Type corresponds to the FeatureKey's value_type."""

    source_type: Literal["subscription", "subscription_state", "seat", "operator_grant"]
    """Category of the source that produced this entitlement."""

    source_id: str
    """Public ID of the source row (e.g., subscription public_id)."""


class AppAccount(BaseModel):
    """Provisioned reality for a (member, app) pair.

    Records what the adapter last reported as the actual state in the
    target app.  Written by the adapter via the internal upsert endpoint
    after ``apply()`` succeeds.  See dd.md §3.8.

    The ``last_reconciled_at`` field is serialized as an ISO-8601 string
    when converted to JSON.
    """

    member_id: str
    """The public ID of the member this account belongs to."""

    app: str
    """The target app identifier."""

    external_id: str
    """The app's notion of identity (username, MXID, etc.).

    Set once at provisioning time; never changes.  This is what keeps
    audit trails coherent and prevents accidental account fusing.
    """

    status: Literal["active", "disabled", "deleted"]
    """Current account state. ``deleted`` is rare and human-approved."""

    last_reconciled_at: datetime | None = None
    """When the reconciler last verified this account.

    Serialized as ISO-8601 string in JSON.  ``None`` when never reconciled.
    """

    current_state: dict[str, Any] = {}
    """Opaque adapter-written snapshot of the app's current state.

    Typically contains current quota, last login, or similar diagnostic
    fields.  Shape is adapter-defined.
    """


class DriftFinding(BaseModel):
    """A single discrepancy between desired and actual state."""

    kind: Literal[
        "missing_in_app",
        "value_mismatch",
        "orphan_in_app",
        "identity_mismatch",
        "state_mismatch",
    ]
    """Category of drift detected.

    - ``missing_in_app``: entitlement exists but app has no corresponding resource.
    - ``value_mismatch``: resource exists but the value differs from expected.
    - ``orphan_in_app``: resource in app but no corresponding entitlement.
    - ``identity_mismatch``: external_id in app does not match expected identity.
    - ``state_mismatch``: overall account state (enabled/disabled) does not match.
    """

    feature_key: str | None = None
    """The feature key involved, or ``None`` for non-key-specific findings."""

    expected: Any
    """What the entitlements say should be the case."""

    actual: Any
    """What the target app currently reports."""

    severity: Literal["info", "warning", "critical"]
    """How urgent the drift is."""


class DriftReport(BaseModel):
    """Structured drift report returned by ``reconcile()``.

    The ``reconciled_at`` field is serialized as an ISO-8601 string
    when converted to JSON.
    """

    member_id: str
    """The member this report covers."""

    app: str
    """The target app."""

    findings: list[DriftFinding]
    """List of drift findings. Empty means no drift detected."""

    reconciled_at: datetime
    """When the reconcile call was made.  Serialized as ISO-8601 string."""


class Capabilities(BaseModel):
    """Declaration of what an adapter can handle."""

    app: str
    """The target app this adapter provisions for."""

    feature_keys: list[str]
    """Registry keys this adapter handles."""

    enforcement: dict[str, Literal["hard", "soft", "advisory"]]
    """Per-feature-key enforcement level."""

    limits: dict[str, int | str]
    """Adapter-specific operational limits (e.g., ``max_concurrent_apply``)."""

    schema_version: int
    """Schema version this adapter is built against for evolution handling.

    Per HLD §4, adapters record this version so that a newer deployment
    can naturally upgrade each member during the next reconciliation pass.
    """


class HealthStatus(BaseModel):
    """Health check result for an adapter and its target app."""

    healthy: bool
    """Overall health. True only when both adapter and target app are
    responding.
    """

    app_reachable: bool
    """Whether the target app's API is reachable."""

    details: dict[str, str] = {}
    """Free-form, adapter-defined diagnostic details."""


class AccountListPage(BaseModel):
    """Paginated result of ``list_accounts()``."""

    accounts: list[AppAccount]
    """Accounts in this page."""

    next_cursor: str | None = None
    """Cursor for the next page of results. ``None`` when exhausted."""


class EventEnvelope(BaseModel):
    """JetStream event consumed by adapters.

    The platform publishes events with a shape that differs from this
    model in two respects:

    - The platform envelope carries ``subject: {type, id}`` and
      ``data: {member_id, ...}``.  This model flattens both:
      ``member_id`` is sourced from ``data.member_id`` (not
      ``subject.id``), and ``subject`` is omitted entirely.
      A non-Python adapter parsing the platform envelope should read
      ``data.member_id`` to get the same value.

    - The platform's ``context`` field is preserved for tracing and
      correlation propagation.  Most adapters ignore it.

    - The platform's ``data`` field (beyond ``member_id``) is not
      included.  Adapters re-fetch current desired state from the
      entitlements service on event receipt; the envelope is a signal,
      not state.

    ``event_type`` follows the platform pattern
    ``entitlements.<entity>.<verb>`` (e.g.,
    ``"entitlements.member.entitlements_changed"``), where ``<entity>``
    is the subject type (``member``, ``subscription``,
    ``operator_grant``), not the target app.

    All datetime fields serialize as ISO-8601 strings in JSON.
    """

    event_id: str
    """Unique identifier; used for dedup."""

    event_type: str
    """Event type (e.g., ``"entitlements.changed"``)."""

    event_version: str
    """Payload-shape version (e.g., ``"1.0"``).

    Tracks how the event *data* shape evolves.  Envelope-shape
    versioning is implicit — the SDK ships against a specific
    platform envelope schema and that pairing is what gets SemVer'd.
    """

    occurred_at: datetime
    """When the event was generated.  Serialized as ISO-8601 string."""

    emitted_by: str
    """Service that emitted this event (e.g., ``"service:entitlements"``).

    Adapters typically do not filter on this field, but it is preserved
    for audit and unusual-event-handling cases.
    """

    member_id: str
    """Affected member.  Sourced from the platform envelope's
    ``data.member_id`` (see class docstring for the reshape rationale).
    """

    context: dict[str, Any] | None = None
    """Opaque tracing and correlation data.

    Preserved for distributed-tracing propagation.  Most adapters
    do not need to read this field; if an adapter makes outgoing HTTP
    calls to the entitlements service and needs to propagate a trace,
    it should forward the ``trace_context`` sub-field.
    """


_ENTITLEMENT_CHANGE_EVENT_TYPES: frozenset[str] = frozenset(
    (
        "entitlements.member.entitlements_changed",
        "entitlements.member.archived",
        "entitlements.subscription.created",
        "entitlements.subscription.state_changed",
        "entitlements.subscription.cancelled",
        "entitlements.operator_grant.created",
        "entitlements.operator_grant.revoked",
    )
)


def is_entitlement_change_event(env: EventEnvelope) -> bool:
    """Return ``True`` if this event triggers member-state-changing entitlement re-derivation.

    The curated set covers events that change a member's desired
    entitlements and warrant a re-apply by the adapter consumer:

    - ``entitlements.member.entitlements_changed``
    - ``entitlements.member.archived``
    - ``entitlements.subscription.created``
    - ``entitlements.subscription.state_changed``
    - ``entitlements.subscription.cancelled``
    - ``entitlements.operator_grant.created``
    - ``entitlements.operator_grant.revoked``

    Excludes ``entitlements.app_account.created`` (adapter-reflexive —
    the adapter that created the account already finished its apply;
    other adapters don't care) and
    ``entitlements.feature_key.registry_reloaded`` (registry maintenance,
    not member-scoped).
    """
    return env.event_type in _ENTITLEMENT_CHANGE_EVENT_TYPES


class AdapterUnreachable(Exception):
    """The target app is unreachable.

    Raised by adapter methods that make HTTP requests when the target
    app cannot be contacted. Adapter authors should raise this exception
    (or a subclass) when their adapter detects that the target app is
    unreachable. Conformance tests assert on this base type.
    """


__all__ = [
    "Member",
    "FeatureKey",
    "Entitlement",
    "AppAccount",
    "DriftFinding",
    "DriftReport",
    "Capabilities",
    "HealthStatus",
    "AccountListPage",
    "EventEnvelope",
    "is_entitlement_change_event",
    "AdapterUnreachable",
]
