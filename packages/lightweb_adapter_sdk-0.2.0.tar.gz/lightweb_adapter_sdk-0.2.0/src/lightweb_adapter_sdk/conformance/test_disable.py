"""Conformance tests for ``disable()``.

Covers:
- Sets status to disabled (contract §2.3).
- Idempotency: multiple calls have same effect as one (contract §2.3).
- No-op for missing account: does not raise (contract §2.3, §5).
"""

from lightweb_adapter_sdk.adapter import Adapter
from lightweb_adapter_sdk.types import AppAccount, Entitlement, Member


def _make_member(member_id: str = "mem_TestMember012345678901") -> Member:
    return Member(
        member_id=member_id,
        member_type="individual",
        external_ids={},
        enabled=True,
    )


def _make_entitlement(
    member_id: str,
    feature_key: str = "exampleapp.storage_gb",
    value: int = 50,
) -> Entitlement:
    return Entitlement(
        member_id=member_id,
        feature_key=feature_key,
        value=value,
        source_type="subscription",
        source_id="sub_test",
    )


def _find_account_by_member(
    adapter_under_test: Adapter,
    member_id: str,
) -> AppAccount | None:
    """Find an account in list_accounts() by member_id.

    Returns the first account whose member_id matches, or None.
    """
    cursor: str | None = None
    while cursor is not None or True:
        page = adapter_under_test.list_accounts(cursor=cursor)
        for account in page.accounts:
            if account.member_id == member_id:
                return account
        if page.next_cursor is None:
            break
        cursor = page.next_cursor
    return None


def test_disable_sets_status_disabled(
    adapter_under_test: Adapter,
) -> None:
    """``disable()`` sets the account status to disabled.

    Contract §2.3: "Soft-disables a member's access while preserving
    data. Blocks the member from using the target app."
    """
    member = _make_member()
    entitlement = _make_entitlement(member.member_id)

    adapter_under_test.apply(member, [entitlement])
    adapter_under_test.disable(member)

    account = _find_account_by_member(adapter_under_test, member.member_id)
    assert account is not None
    assert account.status == "disabled"

    # Reversible by apply
    restore_result = adapter_under_test.apply(member, [entitlement])
    assert restore_result.status == "active"


def test_disable_idempotent(
    adapter_under_test: Adapter,
) -> None:
    """Multiple ``disable()`` calls have same effect as one.

    Contract §2.3: "Calling disable multiple times has the same effect
    as calling it once."
    """
    member = _make_member()
    entitlement = _make_entitlement(member.member_id)

    adapter_under_test.apply(member, [entitlement])
    adapter_under_test.disable(member)
    adapter_under_test.disable(member)
    adapter_under_test.disable(member)

    account = _find_account_by_member(adapter_under_test, member.member_id)
    assert account is not None
    assert account.status == "disabled"


def test_disable_noop_for_missing_account(
    adapter_under_test: Adapter,
) -> None:
    """``disable()`` is a no-op for members without an account; does not raise.

    Contract §2.3 + §5: "Should NOT raise when the member has no
    account."
    """
    member = _make_member()

    # Should not raise
    adapter_under_test.disable(member)

    # No account was created
    acc = _find_account_by_member(adapter_under_test, member.member_id)
    assert acc is None
