"""Conformance tests for ``health()``.

Covers:
- Never raises (contract §2.5, §5).
- Strict conjunction: healthy=True only when both adapter and app are reachable
  (contract §2.5).
"""

from lightweb_adapter_sdk.adapter import Adapter
from lightweb_adapter_sdk.conformance.fault_control import FaultControl
from lightweb_adapter_sdk.types import HealthStatus


def test_health_never_raises(adapter_under_test: Adapter) -> None:
    """``health()`` never raises, even when the app is down.

    Contract §2.5: "The method itself must not raise. A return value
    with ``healthy=False`` is the only failure channel."
    """
    # Should not raise under any circumstances
    status = adapter_under_test.health()
    assert isinstance(status, HealthStatus)


def test_health_strict_conjunction_when_app_reachable(
    adapter_under_test: Adapter,
) -> None:
    """When app is reachable, healthy=True and app_reachable=True.

    Contract §2.5: "``healthy``: ``True`` only when the adapter is
    responding AND ``app_reachable`` is ``True`` (strict conjunction)."
    """
    status = adapter_under_test.health()

    assert status.healthy is True
    assert status.app_reachable is True


def test_health_strict_conjunction_when_app_unreachable(
    adapter_under_test: Adapter,
    adapter_fault_control: FaultControl,
) -> None:
    """When app is unreachable, healthy=False and app_reachable=False.

    Contract §2.5: strict conjunction — both must be True for healthy.
    """
    adapter_fault_control.inject_unreachable()

    status = adapter_under_test.health()

    assert status.healthy is False
    assert status.app_reachable is False
