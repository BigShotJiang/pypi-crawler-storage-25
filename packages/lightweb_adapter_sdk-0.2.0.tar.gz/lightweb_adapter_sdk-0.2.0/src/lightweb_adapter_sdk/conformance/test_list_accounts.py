"""Conformance tests for ``list_accounts()``.

Covers:
- Pagination: pages advance correctly with cursors (contract §2.6).
- Invalid cursor returns empty page (contract §2.6).
- Raises on target-app unreachable (contract §2.6, §5).
- Preserves provisioned member_id (contract §2.6).
- ``current_state`` is observed app state, not an echo of entitlements
  (contract §2.6, which references §2.2's observed-state shape).

Requires the ``adapter_observed_state_example`` fixture.
"""

import pytest

from lightweb_adapter_sdk.adapter import Adapter
from lightweb_adapter_sdk.conformance.fault_control import FaultControl
from typing import Any

from lightweb_adapter_sdk.types import (
    AdapterUnreachable,
    AccountListPage,
    Entitlement,
    Member,
)


def _make_member(member_id: str = "mem_TestMember012345678901") -> Member:
    return Member(
        member_id=member_id,
        member_type="individual",
        external_ids={},
        enabled=True,
    )


def test_list_accounts_paginates(
    adapter_under_test: Adapter,
) -> None:
    """``list_accounts()`` pages through accounts with cursors.

    Contract §2.6: "Returns a window of accounts and a ``next_cursor``
    for pagination (``None`` when no more pages)."
    """
    # Create 25 accounts
    for i in range(25):
        member = _make_member(f"mem_Member{i:020d}")
        adapter_under_test.apply(member, [])

    page1 = adapter_under_test.list_accounts()
    assert isinstance(page1, AccountListPage)
    assert len(page1.accounts) == 10
    assert page1.next_cursor is not None

    page2 = adapter_under_test.list_accounts(cursor=page1.next_cursor)
    assert len(page2.accounts) == 10
    assert page2.next_cursor is not None

    page3 = adapter_under_test.list_accounts(cursor=page2.next_cursor)
    assert len(page3.accounts) == 5
    assert page3.next_cursor is None


def test_list_accounts_invalid_cursor_returns_empty(
    adapter_under_test: Adapter,
) -> None:
    """Invalid or expired cursor returns empty page, not an exception.

    Contract §2.6: "An expired or invalid cursor returns an empty page
    with ``next_cursor=None`` rather than raising."
    """
    result = adapter_under_test.list_accounts(cursor="not-a-real-cursor")

    assert isinstance(result, AccountListPage)
    assert result.accounts == []
    assert result.next_cursor is None


def test_list_accounts_raises_when_unreachable(
    adapter_under_test: Adapter,
    adapter_fault_control: FaultControl,
) -> None:
    """``list_accounts()`` raises when target app is unreachable.

    Contract §2.6 + §5: "Should raise on target-app unreachable."
    """
    adapter_fault_control.inject_unreachable()

    with pytest.raises(AdapterUnreachable):
        adapter_under_test.list_accounts()


def test_list_accounts_preserves_member_id(
    adapter_under_test: Adapter,
) -> None:
    """list_accounts() returns accounts whose member_id matches what was provisioned.

    Contract §2.6: list_accounts pages through every account in the
    target app; accounts returned must be identifiable by their
    provisioned member_id (order is not contract-specified).
    """
    member_a = Member(
        member_id="mem_AliceMember0123456789012",
        member_type="individual",
        external_ids={},
        enabled=True,
    )
    member_b = Member(
        member_id="mem_BobBobBob0123456789012345",
        member_type="individual",
        external_ids={},
        enabled=True,
    )
    adapter_under_test.apply(member_a, [])
    adapter_under_test.apply(member_b, [])

    page = adapter_under_test.list_accounts()

    returned_member_ids = {account.member_id for account in page.accounts}
    assert member_a.member_id in returned_member_ids
    assert member_b.member_id in returned_member_ids


def test_list_accounts_current_state_is_observed_not_desired(
    adapter_under_test: Adapter,
    adapter_observed_state_example: dict[str, Any],
) -> None:
    """``list_accounts()`` returns observed app state, not an echo of entitlements.

    Contract §2.6: "Each returned ``AppAccount`` carries the same
    ``current_state`` shape as ``apply()`` returns (per §2.2):
    observed app state, not an echo of entitlements."

    The ``adapter_observed_state_example`` fixture declares a known
    desired→observed example; this test asserts that a listed account's
    ``current_state`` contains the declared observed key and not the
    declared desired key.

    The suite asserts subset semantics: declared ``observed_keys`` must
    be present in ``current_state``; adapters may expose additional
    observed properties not declared in the fixture (e.g. account-enabled
    state, group memberships that derive from no single feature key).
    """
    example = adapter_observed_state_example
    member = _make_member()
    entitlement = Entitlement(
        member_id=member.member_id,
        feature_key=example["entitlement"]["feature_key"],
        value=example["entitlement"]["value"],
        source_type="subscription",
        source_id="sub_test",
    )
    adapter_under_test.apply(member, [entitlement])

    page: AccountListPage = adapter_under_test.list_accounts()
    listed_account = None
    for acc in page.accounts:
        if acc.member_id == member.member_id:
            listed_account = acc
            break

    assert listed_account is not None
    assert example["observed_key_present"] in listed_account.current_state
    assert example["desired_key_absent"] not in listed_account.current_state
