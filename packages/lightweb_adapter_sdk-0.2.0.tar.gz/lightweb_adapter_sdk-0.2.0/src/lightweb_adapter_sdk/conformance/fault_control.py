"""Fault injection abstraction for the conformance suite.

Adapter authors provide an implementation of this Protocol via the
``adapter_fault_control`` conftest fixture, scoped to a single test's
lifetime. Conformance tests call methods on this fixture to inject
fault conditions; each adapter author decides which fault modes their
fake server supports.

Methods declare named fault modes. Implementations either inject the
fault (returning normally) or raise ``NotImplementedError`` if the
fault mode is not supported. Conformance tests that require a fault
mode the adapter doesn't support should skip via a helper.
"""

from __future__ import annotations

from typing import Protocol, runtime_checkable


@runtime_checkable
class FaultControl(Protocol):
    """Adapter authors provide an implementation via the
    ``adapter_fault_control`` conftest fixture, scoped to a single
    test's lifetime.
    """

    def inject_unreachable(self) -> None:
        """Inject a fault condition where the target app is unreachable.

        Subsequent calls to adapter methods that make HTTP requests
        should raise the adapter's unreachable exception (see
        ``lightweb_adapter_sdk.types.AdapterUnreachable``).
        """

    def inject_rate_limit(self) -> None:
        """Inject a fault condition where the target app returns 429.

        Subsequent calls to adapter methods should raise the adapter's
        rate-limit exception.
        """

    def inject_auth_failure(self) -> None:
        """Inject a fault condition where the target app returns 401/403.

        Subsequent calls to adapter methods should raise the adapter's
        authentication-failure exception.
        """

    def reset(self) -> None:
        """Reset the adapter's fake server to normal operating mode.

        Called automatically in fixture teardown so individual tests
        don't need to.
        """
