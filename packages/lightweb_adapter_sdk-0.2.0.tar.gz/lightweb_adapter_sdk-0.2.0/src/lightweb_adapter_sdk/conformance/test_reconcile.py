"""Conformance tests for ``reconcile()``.

Covers the four-case matrix from contract §2.4:
- Account exists, entitlements non-empty: compare and report mismatches.
- Account exists, entitlements empty: no drift.
- Account absent, entitlements non-empty: missing_in_app finding.
- Account absent, entitlements empty: no drift.
- Target app unreachable: raises, does not return empty report.

Requires the ``adapter_feature_keys`` fixture: a list of feature keys
the adapter handles, in declaration order.  See docs/conformance.md
for the fixture interface.
"""

from datetime import datetime

import pytest

from lightweb_adapter_sdk.adapter import Adapter
from lightweb_adapter_sdk.conformance.fault_control import FaultControl
from lightweb_adapter_sdk.types import (
    AdapterUnreachable,
    DriftReport,
    DriftFinding,
    Entitlement,
    Member,
)


def _make_member(member_id: str = "mem_TestMember012345678901") -> Member:
    return Member(
        member_id=member_id,
        member_type="individual",
        external_ids={},
        enabled=True,
    )


def _make_entitlement(
    member_id: str,
    feature_key: str,
    value: int = 50,
) -> Entitlement:
    return Entitlement(
        member_id=member_id,
        feature_key=feature_key,
        value=value,
        source_type="subscription",
        source_id="sub_test",
    )


def test_reconcile_account_exists_entitlements_match(
    adapter_under_test: Adapter,
    adapter_feature_keys: list[str],
) -> None:
    """Reconcile returns empty findings when app state matches entitlements.

    Contract §2.4: account-exists & entitlements-non-empty is the
    expected case; if values match, no drift.
    """
    feature_key = adapter_feature_keys[0]
    member = _make_member()
    entitlement = _make_entitlement(member.member_id, feature_key, 50)

    adapter_under_test.apply(member, [entitlement])
    report = adapter_under_test.reconcile(member, [entitlement])

    assert isinstance(report, DriftReport)
    assert report.findings == []
    assert report.member_id == member.member_id
    assert isinstance(report.reconciled_at, datetime)


def test_reconcile_account_exists_entitlements_differ(
    adapter_under_test: Adapter,
    adapter_feature_keys: list[str],
) -> None:
    """Reconcile reports value_mismatch when app state diverges from entitlements.

    Contract §2.4: for each entitlement, compare against current state;
    mismatches produce ``value_mismatch`` findings.

    The ``expected`` and ``actual`` values are in entitlement-value terms
    (not observed-shape), per contract §2.4.
    """
    feature_key = adapter_feature_keys[0]
    member = _make_member()
    adapter_under_test.apply(
        member,
        [_make_entitlement(member.member_id, feature_key, 50)],
    )
    report = adapter_under_test.reconcile(
        member,
        [_make_entitlement(member.member_id, feature_key, 100)],
    )

    assert len(report.findings) == 1
    finding = report.findings[0]
    assert isinstance(finding, DriftFinding)
    assert finding.kind == "value_mismatch"
    assert finding.feature_key == feature_key
    assert finding.expected == 100
    assert finding.actual == 50
    assert finding.severity == "critical"


def test_reconcile_account_absent_entitlements_non_empty(
    adapter_under_test: Adapter,
    adapter_feature_keys: list[str],
) -> None:
    """Reconcile reports missing_in_app when account is absent but entitlements exist.

    Contract §2.4: account-absent & entitlements-non-empty produces a
    ``missing_in_app`` finding with severity ``critical``.
    """
    feature_key = adapter_feature_keys[0]
    member = _make_member()

    report = adapter_under_test.reconcile(
        member,
        [_make_entitlement(member.member_id, feature_key, 50)],
    )

    assert len(report.findings) == 1
    finding = report.findings[0]
    assert isinstance(finding, DriftFinding)
    assert finding.kind == "missing_in_app"
    assert finding.severity == "critical"


def test_reconcile_account_absent_entitlements_empty(
    adapter_under_test: Adapter,
) -> None:
    """Reconcile returns empty findings when no account and no entitlements.

    Contract §2.4: account-absent & entitlements-empty is correct
    no-account state (no drift).
    """
    member = _make_member()

    report = adapter_under_test.reconcile(member, [])

    assert isinstance(report, DriftReport)
    assert report.findings == []


def test_reconcile_raises_when_unreachable_not_vacuous_empty(
    adapter_under_test: Adapter,
    adapter_fault_control: FaultControl,
) -> None:
    """Reconcile raises on unreachable, does not return empty report.

    Contract §2.4 + §5: "When the target app is unreachable, raises
    an adapter-specific exception rather than returning a misleadingly
    empty report."
    """
    adapter_fault_control.inject_unreachable()

    with pytest.raises(AdapterUnreachable):
        adapter_under_test.reconcile(_make_member(), [])
