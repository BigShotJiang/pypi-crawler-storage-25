"""Conformance tests for ``capabilities()``.

Covers:
- Idempotency of repeated calls (contract §2.1).
- Presence of ``schema_version`` in the response (contract §4,
  Decision C: only the presence is tested, not the version-change
  trigger mechanism).
"""

from lightweb_adapter_sdk.adapter import Adapter
from lightweb_adapter_sdk.types import Capabilities


def test_capabilities_idempotent(adapter_under_test: Adapter) -> None:
    """Repeated calls to ``capabilities()`` return equivalent results.

    Contract §2.1: "Repeated calls with no intervening configuration
    changes return an equivalent result."
    """
    result1 = adapter_under_test.capabilities()
    result2 = adapter_under_test.capabilities()

    assert result1.app == result2.app
    assert result1.feature_keys == result2.feature_keys
    assert result1.enforcement == result2.enforcement
    assert result1.limits == result2.limits
    assert result1.schema_version == result2.schema_version


def test_capabilities_schema_version_declared(adapter_under_test: Adapter) -> None:
    """``capabilities()`` returns a ``schema_version`` as an integer.

    Contract §4: adapters record the schema version they last applied
    in ``Capabilities.schema_version``.  Decision C: we test presence
    and type, not the version-change-trigger-reapply mechanism.
    """
    caps = adapter_under_test.capabilities()
    assert isinstance(caps, Capabilities)
    assert isinstance(caps.schema_version, int)
    assert caps.schema_version >= 0
