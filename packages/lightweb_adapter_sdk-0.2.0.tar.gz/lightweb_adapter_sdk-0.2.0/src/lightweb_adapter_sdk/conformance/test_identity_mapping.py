"""Conformance tests for identity mapping discipline.

Covers:
- ``external_id`` is immutable across ``apply()`` calls (contract §3).
- ``external_id`` is immutable across ``reconcile()`` (contract §3).

Contract §3: "The mapping is set once at provisioning time and never
changes — even if a member's email or display name changes later."
"""

from lightweb_adapter_sdk.adapter import Adapter
from lightweb_adapter_sdk.types import Entitlement, Member


def _make_member(member_id: str = "mem_TestMember012345678901") -> Member:
    return Member(
        member_id=member_id,
        member_type="individual",
        external_ids={},
        enabled=True,
    )


def _make_entitlement(
    member_id: str,
    feature_key: str = "exampleapp.storage_gb",
    value: int = 50,
) -> Entitlement:
    return Entitlement(
        member_id=member_id,
        feature_key=feature_key,
        value=value,
        source_type="subscription",
        source_id="sub_test",
    )


def test_external_id_immutable_across_apply(
    adapter_under_test: Adapter,
) -> None:
    """``external_id`` does not change across repeated ``apply()`` calls.

    Contract §3: "The ``external_id`` on ``AppAccount`` is the canonical
    name for this mapping and is immutable for the lifetime of the
    (member, app) pair."

    The contract requires the mapping to be stable across calls and
    deterministic per member; it does NOT specify a transformation rule.
    Each adapter chooses how to derive ``external_id`` from ``member_id``
    (or from another stable identity source).  This test asserts only on
    stability, not on the specific derivation.
    """
    member = _make_member("mem_IdentityTestMember01234567890")
    entitlement = _make_entitlement(member.member_id)

    result1 = adapter_under_test.apply(member, [entitlement])
    result2 = adapter_under_test.apply(member, [entitlement])

    assert result1.external_id == result2.external_id


def test_external_id_immutable_across_reconcile(
    adapter_under_test: Adapter,
) -> None:
    """``external_id`` is stable through ``apply`` then ``reconcile``.

    Contract §3: identity mapping is set once at provisioning and never
    changes.  ``reconcile`` must not alter the external_id.
    """
    member = _make_member("mem_IdentityTestMember01234567890")
    entitlement = _make_entitlement(member.member_id)

    apply_result = adapter_under_test.apply(member, [entitlement])
    reconcile_result = adapter_under_test.reconcile(member, [entitlement])

    # reconcile returns a DriftReport, not an AppAccount; we verify
    # identity stability by re-applying and confirming the external_id
    # matches, then confirm reconcile produced no drift findings.
    apply_result2 = adapter_under_test.apply(member, [entitlement])
    assert apply_result.external_id == apply_result2.external_id
    assert reconcile_result.findings == []
