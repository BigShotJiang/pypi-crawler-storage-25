"""Conformance tests for the EventConsumer Protocol.

Adapter authors providing event consumers verify their implementation
against these tests by providing an ``event_consumer_under_test``
fixture in their conftest.py.

Maps to contract claims:
- test_consumer_satisfies_protocol → docs/contract.md §6.2 (consumer protocol shape)
- test_consume_invokes_apply_for_change_events → docs/contract.md §6.2 (apply re-invocation)
- test_consume_is_idempotent_at_event_level → docs/contract.md §6.2 (consumer-level idempotency)
- test_consume_handles_non_change_events_gracefully → see note in test docstring
"""

from datetime import datetime, timezone
from typing import Any

import pytest

from lightweb_adapter_sdk.event_consumer.protocol import EventConsumer
from lightweb_adapter_sdk.types import EventEnvelope


def _make_change_envelope(
    member_id: str = "mem_TestMember012345678901",
) -> EventEnvelope:
    return EventEnvelope(
        event_id="evt-conformance-1",
        event_type="entitlements.member.entitlements_changed",
        event_version="1.0",
        occurred_at=datetime(2026, 5, 18, 12, 0, 0, tzinfo=timezone.utc),
        emitted_by="service:entitlements",
        member_id=member_id,
        context=None,
    )


def _make_non_change_envelope(
    member_id: str = "mem_TestMember012345678901",
) -> EventEnvelope:
    return EventEnvelope(
        event_id="evt-conformance-2",
        event_type="entitlements.app_account.created",
        event_version="1.0",
        occurred_at=datetime(2026, 5, 18, 12, 0, 0, tzinfo=timezone.utc),
        emitted_by="service:entitlements",
        member_id=member_id,
        context=None,
    )


def test_consumer_satisfies_protocol(event_consumer_under_test: EventConsumer) -> None:
    """The consumer satisfies the @runtime_checkable EventConsumer Protocol.

    Contract: any class implementing async def consume(self, envelope) -> None
    satisfies EventConsumer structurally.
    """
    assert isinstance(event_consumer_under_test, EventConsumer)


@pytest.mark.asyncio
async def test_consume_invokes_apply_for_change_events(
    event_consumer_under_test: EventConsumer,
    adapter_under_test: Any,  # type kept loose; Round 3's fixture shape
    adapter_fake_server: Any,  # type kept loose; Round 3's fixture shape
) -> None:
    """Given a change envelope, the consumer triggers an apply for the member.

    Contract claim §6.2: on receipt of an entitlement-change event, the
    consumer fetches current desired state and invokes the adapter's
    apply(). Verified by post-condition: the fake server has an account
    for the event's member after consume() returns.
    """
    envelope = _make_change_envelope()
    await event_consumer_under_test.consume(envelope)

    # Post-condition: an account exists for this member
    # (the adapter under test's apply() was invoked).
    # The exact lookup mechanism depends on the adapter's fake server's
    # state-inspection surface — see D8 (conformance adapter-agnosticism
    # redesign) for the in-progress abstraction work. For now, the
    # reference fake's `get_account` is the canonical lookup.
    assert adapter_fake_server.get_account(envelope.member_id[4:].lower()) is not None


@pytest.mark.asyncio
async def test_consume_is_idempotent_at_event_level(
    event_consumer_under_test: EventConsumer,
    adapter_under_test: Any,
    adapter_fake_server: Any,
) -> None:
    """Calling consume() twice with the same envelope is safe and produces
    the same end state as a single call.

    Contract claim §6.2: consumers must be idempotent because at-least-once
    delivery means duplicates. The SDK's default dedup absorbs duplicates
    at the JetStream layer; this test verifies the consumer itself is
    idempotent as the contractual backstop.
    """
    envelope = _make_change_envelope()

    await event_consumer_under_test.consume(envelope)
    state_after_first = adapter_fake_server.get_account(envelope.member_id[4:].lower())

    await event_consumer_under_test.consume(envelope)
    state_after_second = adapter_fake_server.get_account(envelope.member_id[4:].lower())

    assert state_after_first is not None
    assert state_after_second is not None
    # End state is the same: same external_id, same status, same state dict.
    assert state_after_first.external_id == state_after_second.external_id
    assert state_after_first.status == state_after_second.status
    assert state_after_first.state == state_after_second.state


@pytest.mark.asyncio
async def test_consume_handles_non_change_events_gracefully(
    event_consumer_under_test: EventConsumer,
) -> None:
    """The consumer is safe to call with a non-change envelope.

    Note on filter discipline: the SDK's JetStreamEventConsumer applies
    `is_entitlement_change_event` upstream, so in production EventConsumer
    implementations receive only change events. This test verifies that
    calling consume() with a non-change envelope does not raise — i.e.,
    the consumer's defensive contract is honored even if upstream
    filtering is bypassed (test harness, bug, or alternative consumer
    infrastructure that doesn't filter).

    Implementations may either no-op for non-change events or process them
    idempotently as if they were change events; both satisfy the contract.
    """
    envelope = _make_non_change_envelope()
    # Must not raise. End-state is not asserted (implementations may
    # legitimately differ on whether to process or skip).
    await event_consumer_under_test.consume(envelope)
