"""Conformance test suite for the Lightweb adapter contract.

Every adapter must pass these tests to be considered conformant.
The suite is the mechanical expression of ``docs/contract.md``.

Adapter authors import these test functions in their own
``tests/test_conformance.py`` and provide the required fixtures
in their ``conftest.py``. See ``docs/conformance.md`` for usage
instructions.
"""

from lightweb_adapter_sdk.conformance.test_apply import (
    test_apply_creates_account_on_first_call,
    test_apply_current_state_consistent_with_read_back,
    test_apply_current_state_is_observed_not_desired,
    test_apply_empty_entitlements_creates_active_account,
    test_apply_idempotent,
    test_apply_replaces_state_rather_than_merging,
    test_apply_raises_when_unreachable,
)
from lightweb_adapter_sdk.conformance.test_capabilities import (
    test_capabilities_idempotent,
    test_capabilities_schema_version_declared,
)
from lightweb_adapter_sdk.conformance.test_disable import (
    test_disable_idempotent,
    test_disable_noop_for_missing_account,
    test_disable_sets_status_disabled,
)
from lightweb_adapter_sdk.conformance.test_health import (
    test_health_never_raises,
    test_health_strict_conjunction_when_app_reachable,
    test_health_strict_conjunction_when_app_unreachable,
)
from lightweb_adapter_sdk.conformance.test_identity_mapping import (
    test_external_id_immutable_across_apply,
    test_external_id_immutable_across_reconcile,
)
from lightweb_adapter_sdk.conformance.test_list_accounts import (
    test_list_accounts_current_state_is_observed_not_desired,
    test_list_accounts_invalid_cursor_returns_empty,
    test_list_accounts_paginates,
    test_list_accounts_preserves_member_id,
    test_list_accounts_raises_when_unreachable,
)
from lightweb_adapter_sdk.conformance.test_reconcile import (
    test_reconcile_account_absent_entitlements_empty,
    test_reconcile_account_absent_entitlements_non_empty,
    test_reconcile_account_exists_entitlements_differ,
    test_reconcile_account_exists_entitlements_match,
    test_reconcile_raises_when_unreachable_not_vacuous_empty,
)
from lightweb_adapter_sdk.conformance.test_event_consumer import (
    test_consumer_satisfies_protocol,
    test_consume_invokes_apply_for_change_events,
    test_consume_is_idempotent_at_event_level,
    test_consume_handles_non_change_events_gracefully,
)

__all__ = [
    # capabilities
    "test_capabilities_idempotent",
    "test_capabilities_schema_version_declared",
    # apply
    "test_apply_creates_account_on_first_call",
    "test_apply_current_state_consistent_with_read_back",
    "test_apply_current_state_is_observed_not_desired",
    "test_apply_empty_entitlements_creates_active_account",
    "test_apply_idempotent",
    "test_apply_replaces_state_rather_than_merging",
    "test_apply_raises_when_unreachable",
    # disable
    "test_disable_idempotent",
    "test_disable_noop_for_missing_account",
    "test_disable_sets_status_disabled",
    # reconcile
    "test_reconcile_account_exists_entitlements_match",
    "test_reconcile_account_exists_entitlements_differ",
    "test_reconcile_account_absent_entitlements_non_empty",
    "test_reconcile_account_absent_entitlements_empty",
    "test_reconcile_raises_when_unreachable_not_vacuous_empty",
    # health
    "test_health_never_raises",
    "test_health_strict_conjunction_when_app_reachable",
    "test_health_strict_conjunction_when_app_unreachable",
    # list_accounts
    "test_list_accounts_current_state_is_observed_not_desired",
    "test_list_accounts_invalid_cursor_returns_empty",
    "test_list_accounts_paginates",
    "test_list_accounts_preserves_member_id",
    "test_list_accounts_raises_when_unreachable",
    # identity_mapping
    "test_external_id_immutable_across_apply",
    "test_external_id_immutable_across_reconcile",
    # event_consumer
    "test_consumer_satisfies_protocol",
    "test_consume_invokes_apply_for_change_events",
    "test_consume_is_idempotent_at_event_level",
    "test_consume_handles_non_change_events_gracefully",
]
