"""Conformance tests for ``apply()``.

Covers:
- Creates account on first call (contract §2.2).
- ``current_state`` is observed app state, not an echo of entitlements
  (contract §2.2).
- Empty entitlements list produces active account (contract §2.2).
- Idempotency: repeated calls with same args produce same result
  (contract §2.2, §6.1).
- State replacement semantics: dropping a key from entitlements
  removes it from the account's current_state (contract §2.2).
- Consistency: ``apply``'s ``current_state`` matches ``list_accounts``
  read-back for the same member (contract §2.2 + §2.6).
- Raises on target-app unreachable (contract §2.2, §5).

Requires the ``adapter_feature_keys`` and ``adapter_observed_state_example``
fixtures: see docs/conformance.md for the fixture interface.
"""

import pytest

from lightweb_adapter_sdk.adapter import Adapter
from lightweb_adapter_sdk.conformance.fault_control import FaultControl
from typing import Any

from lightweb_adapter_sdk.types import (
    AdapterUnreachable,
    AccountListPage,
    AppAccount,
    Entitlement,
    Member,
)


def _make_member(member_id: str = "mem_TestMember012345678901") -> Member:
    return Member(
        member_id=member_id,
        member_type="individual",
        external_ids={},
        enabled=True,
    )


def _make_entitlement(
    member_id: str,
    feature_key: str,
    value: int = 50,
) -> Entitlement:
    return Entitlement(
        member_id=member_id,
        feature_key=feature_key,
        value=value,
        source_type="subscription",
        source_id="sub_test",
    )


def test_apply_creates_account_on_first_call(
    adapter_under_test: Adapter,
    adapter_feature_keys: list[str],
) -> None:
    """``apply()`` creates an account on first call.

    Contract §2.2: "Creates accounts that should exist."
    """
    feature_key = adapter_feature_keys[0]
    member = _make_member("mem_MyTestMember01234567890")
    entitlement = _make_entitlement(member.member_id, feature_key, 50)

    result = adapter_under_test.apply(member, [entitlement])

    assert isinstance(result, AppAccount)
    assert result.status == "active"


def test_apply_current_state_is_observed_not_desired(
    adapter_under_test: Adapter,
    adapter_observed_state_example: dict[str, Any],
) -> None:
    """``apply()`` returns observed app state, not an echo of entitlements.

    Contract §2.2: "``current_state`` is observed app state, not an echo
    of entitlements."  A pure-echo adapter (one that returns the applied
    entitlements as ``current_state``) fails this test.

    The ``adapter_observed_state_example`` fixture declares a known
    desired→observed example; this test asserts that the declared
    observed key IS present and the desired key IS absent.
    """
    example = adapter_observed_state_example
    member = _make_member()
    entitlement = Entitlement(
        member_id=member.member_id,
        feature_key=example["entitlement"]["feature_key"],
        value=example["entitlement"]["value"],
        source_type="subscription",
        source_id="sub_test",
    )

    result = adapter_under_test.apply(member, [entitlement])

    assert isinstance(result, AppAccount)
    assert result.status == "active"
    assert example["observed_key_present"] in result.current_state
    assert example["desired_key_absent"] not in result.current_state


def test_apply_empty_entitlements_creates_active_account(
    adapter_under_test: Adapter,
) -> None:
    """``apply()`` with empty entitlements creates an active account.

    Contract §2.2: "When called with an empty ``entitlements`` list,
    ensures the account exists with status ``\"active\"`` and
    ``current_state`` reflecting no entitlements."
    """
    member = _make_member()

    result = adapter_under_test.apply(member, [])

    assert isinstance(result, AppAccount)
    assert result.status == "active"
    assert result.current_state == {}


def test_apply_idempotent(
    adapter_under_test: Adapter,
    adapter_feature_keys: list[str],
) -> None:
    """Repeated ``apply()`` calls with same args produce same result.

    Contract §2.2 + §6.1: "Calling ``apply`` repeatedly with the same
    arguments produces the same result."
    """
    feature_key = adapter_feature_keys[0]
    member = _make_member()
    entitlement = _make_entitlement(member.member_id, feature_key, 50)

    result1 = adapter_under_test.apply(member, [entitlement])
    result2 = adapter_under_test.apply(member, [entitlement])

    assert result1.external_id == result2.external_id
    assert result1.status == result2.status
    # Idempotency of current_state holds regardless of echo-vs-observed shape:
    # repeated apply with same args produces the same current_state.
    assert result1.current_state == result2.current_state


def test_apply_replaces_state_rather_than_merging(
    adapter_under_test: Adapter,
    adapter_feature_keys: list[str],
    adapter_observed_state_example: dict[str, Any],
) -> None:
    """``apply()`` replaces state, not merges.

    Contract §2.2: dropping a key from entitlements removes it from
    the account's current_state.

    Requires the adapter to handle ≥2 feature keys.  Adapters with a
    single feature key cannot exercise the replacement semantics (there
    is nothing to drop); this test skips in that case.

    Asserts on the OBSERVED projection of the dropped key being absent,
    not on feature-key presence, to maintain adapter-agnosticism.
    """
    if len(adapter_feature_keys) < 2:
        pytest.skip(
            "Test requires adapter to handle ≥2 feature keys; "
            f"adapter declares {len(adapter_feature_keys)}"
        )

    key_a, key_b = adapter_feature_keys[0], adapter_feature_keys[1]
    member = _make_member()

    result1 = adapter_under_test.apply(
        member,
        [
            _make_entitlement(member.member_id, key_a, 50),
            _make_entitlement(member.member_id, key_b, 10),
        ],
    )
    # After the first apply, current_state should be non-empty.
    assert result1.current_state != {}

    result2 = adapter_under_test.apply(
        member,
        [_make_entitlement(member.member_id, key_a, 50)],
    )
    # After dropping key_b, the observed projection of key_b should
    # be absent from current_state.  The fixture declares
    # ``observed_keys`` mapping feature keys to their observed
    # projections; we assert that none of key_b's observed keys
    # appear in the result.
    #
    # The suite asserts subset semantics: union(observed_keys.values())
    # ⊆ current_state.keys(). Adapters MAY include observed keys not
    # declared in observed_keys (e.g. an enabled flag derived from no
    # feature key). No exact-match assertion on current_state keys.
    observed_for_b = adapter_observed_state_example.get(
        "observed_keys", {}
    ).get(key_b, [key_b])
    for obs_key in observed_for_b:
        assert obs_key not in result2.current_state, (
            f"Observed key {obs_key} for dropped entitlement {key_b} "
            "should not be in current_state"
        )


def test_apply_current_state_consistent_with_read_back(
    adapter_under_test: Adapter,
    adapter_feature_keys: list[str],
) -> None:
    """``apply``'s ``current_state`` matches ``list_accounts`` read-back.

    Contract §2.2 + §2.6: both methods return ``current_state`` as
    observed app state.  An immediate ``list_accounts()`` for the same
    member must return an account whose ``current_state`` equals the
    one returned by ``apply()``.

    Read back ONLY through contract methods (``apply`` + ``list_accounts``),
    not through the fake's ``get_account``, to maintain adapter-agnosticism.
    """
    feature_key = adapter_feature_keys[0]
    member = _make_member("mem_ConsistencyCheck01234567890")
    entitlement = _make_entitlement(member.member_id, feature_key, 50)

    apply_result = adapter_under_test.apply(member, [entitlement])

    page: AccountListPage = adapter_under_test.list_accounts()
    listed_account = None
    for acc in page.accounts:
        if acc.member_id == member.member_id:
            listed_account = acc
            break

    assert listed_account is not None
    assert listed_account.current_state == apply_result.current_state


def test_apply_raises_when_unreachable(
    adapter_under_test: Adapter,
    adapter_fault_control: FaultControl,
) -> None:
    """``apply()`` raises when target app is unreachable.

    Contract §2.2 + §5: "Should raise on target-app unreachable."
    """
    adapter_fault_control.inject_unreachable()

    with pytest.raises(AdapterUnreachable):
        adapter_under_test.apply(_make_member(), [])
