"""Reference implementation of the FaultControl Protocol.

Wraps a ``FakeExampleAppServer`` and implements the
``FaultControl`` Protocol by delegating to the fake's existing
``set_unreachable`` method. Rate-limit and auth-failure fault modes
are not supported by the reference fake server and raise
``NotImplementedError``.
"""

from __future__ import annotations

from lightweb_adapter_sdk.conformance.fault_control import FaultControl
from lightweb_adapter_sdk.reference.fake_server import FakeExampleAppServer


class ReferenceFaultControl(FaultControl):
    """Reference implementation of FaultControl for the ExampleApp fake server."""

    def __init__(self, server: FakeExampleAppServer) -> None:
        self._server = server

    def inject_unreachable(self) -> None:
        self._server.set_unreachable(True)

    def inject_rate_limit(self) -> None:
        raise NotImplementedError(
            "ReferenceFakeServer does not support rate-limit injection"
        )

    def inject_auth_failure(self) -> None:
        raise NotImplementedError(
            "ReferenceFakeServer does not support auth-failure injection"
        )

    def reset(self) -> None:
        self._server.set_unreachable(False)
