"""In-memory fake server for the ExampleApp reference adapter.

Not an HTTP server; not persistent; not async.  A plain Python class
holding a dict-of-accounts and supporting the operations the adapter
calls during provisioning, reconcile, and health checks.

The internal ``Account`` dataclass is distinct from the SDK's
``AppAccount`` model.  The adapter's job is to translate between the
fake's internal shape and the contract's ``AppAccount`` model on the
way out.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Literal

AccountStatus = Literal["active", "disabled"]


class FakeServerUnreachable(Exception):
    """Raised by the fake when ``set_unreachable(True)`` has been called."""


@dataclass(frozen=True)
class Account:
    """Internal account representation for the fake server.

    Carries the minimal state the fake needs to track per account.
    The adapter translates this to ``AppAccount`` on the way out.
    """

    member_id: str
    external_id: str
    status: AccountStatus = "active"
    state: dict[str, Any] = field(default_factory=dict)


class FakeExampleAppServer:
    """In-memory state container the ExampleApp adapter provisions against.

    Identity mapping is immutable: once ``create_account(...)`` is called,
    the (member_id, external_id) pair is recorded and subsequent calls
    with the same member_id return the existing account (insertion order
    preserved for pagination).

    The fake models a desired→observed state transformation: the adapter
    passes desired entitlements (feature keys), but the server stores
    observed app-side properties. This is what lets the conformance suite
    verify that adapters return observed state, not an echo of entitlements.
    """

    PAGE_SIZE = 10

    # Mapping from desired feature keys to observed property names.
    # Each key maps to a dict of observed properties (name → value transform).
    # This is the adapter-internal mapping that reconcile() also needs.
    OBSERVED_STATE_MAPPING: dict[str, dict[str, Any]] = {
        "exampleapp.storage_gb": {
            "storage_quota_mb": lambda v: v * 1024,
        },
        "exampleapp.user_count": {
            "seat_count": lambda v: v,
        },
        "exampleapp.feature_enabled": {
            "feature_x_enabled": lambda v: v,
        },
    }

    def __init__(self) -> None:
        self._accounts: dict[str, Account] = {}
        self._insertion_order: list[str] = []
        self._unreachable = False

    # -- Test-only controls --------------------------------------------------

    def set_unreachable(self, unreachable: bool) -> None:
        """Signal that the target app is (un)reachable.

        When ``unreachable`` is ``True``, every state-query and statemutation
        method raises ``FakeServerUnreachable`` until ``set_unreachable(False)``
        is called.  Test-only control; never called by the adapter itself.
        """
        self._unreachable = unreachable

    # -- State queries -------------------------------------------------------

    def _check_unreachable(self) -> None:
        if self._unreachable:
            raise FakeServerUnreachable("target app is unreachable")

    def get_account(self, external_id: str) -> Account | None:
        self._check_unreachable()
        return self._accounts.get(external_id)

    def list_accounts(
        self, cursor: str | None = None
    ) -> tuple[list[Account], str | None]:
        self._check_unreachable()

        if cursor is not None:
            try:
                start_idx = self._insertion_order.index(cursor) + 1
            except ValueError:
                return ([], None)
        else:
            start_idx = 0

        page = [
            self._accounts[eid]
            for eid in self._insertion_order[start_idx : start_idx + self.PAGE_SIZE]
        ]

        if not page:
            return ([], None)

        last_in_page = page[-1].external_id
        if last_in_page == self._insertion_order[-1]:
            return (page, None)

        return (page, last_in_page)

    # -- State mutations -----------------------------------------------------

    def create_account(
        self,
        member_id: str,
        external_id: str,
    ) -> Account:
        self._check_unreachable()
        if external_id not in self._accounts:
            account = Account(
                member_id=member_id,
                external_id=external_id,
            )
            self._accounts[external_id] = account
            self._insertion_order.append(external_id)
        return self._accounts[external_id]

    def replace_account_state(self, external_id: str, state: dict[str, Any]) -> Account:
        """Replace the account's state dict entirely (no merge).

        Transforms desired entitlement-state into observed app-state before
        storing. This models the real-world scenario where the target app
        represents properties differently than the entitlement schema.

        Implements the contract's match semantics: if desired state
        drops a key, the target's state reflects that drop.
        """
        self._check_unreachable()
        account = self._accounts[external_id]
        observed = self._transform_desired_to_observed(state)
        updated = Account(
            member_id=account.member_id,
            external_id=account.external_id,
            status=account.status,
            state=observed,
        )
        self._accounts[external_id] = updated
        return updated

    def _transform_desired_to_observed(
        self, desired_state: dict[str, Any]
    ) -> dict[str, Any]:
        """Transform desired entitlement keys into observed app-side properties.

        Each feature key maps to one or more observed properties. The
        transformation is deterministic and reversible enough that
        reconcile() can recover the entitlement-comparable value.
        """
        observed: dict[str, Any] = {}
        for feature_key, value in desired_state.items():
            mapping = self.OBSERVED_STATE_MAPPING.get(feature_key)
            if mapping is None:
                # Unknown feature key — store as-is (graceful degradation).
                observed[feature_key] = value
                continue
            for observed_key, transform in mapping.items():
                observed[observed_key] = transform(value)
        return observed

    def set_account_status(self, external_id: str, status: AccountStatus) -> Account:
        self._check_unreachable()
        account = self._accounts[external_id]
        updated = Account(
            member_id=account.member_id,
            external_id=account.external_id,
            status=status,
            state=account.state,
        )
        self._accounts[external_id] = updated
        return updated
