"""Reference adapter for a fictional ExampleApp.

The first implementation of the ``Adapter`` Protocol; the SDK's
conformance suite runs against this as the known-good implementation.
"""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Any, Callable, Literal, cast

from lightweb_adapter_sdk.types import (
    AccountListPage,
    AppAccount,
    Capabilities,
    DriftFinding,
    DriftReport,
    Entitlement,
    HealthStatus,
    Member,
)
from lightweb_adapter_sdk.types import AdapterUnreachable

from .fake_server import FakeExampleAppServer, FakeServerUnreachable


# -- Adapter-specific exceptions -------------------------------------------


_ENFORCEMENT_TYPE = Literal["hard", "soft", "advisory"]


class ExampleAppError(Exception):
    """Base exception for ExampleApp adapter errors."""


class ExampleAppUnreachable(ExampleAppError, AdapterUnreachable):
    """The target app is unreachable.

    Subclasses both ExampleAppError (for adapter-internal hierarchy)
    and AdapterUnreachable (for conformance-test compatibility).
    """


# -- External ID derivation ------------------------------------------------


def _derive_external_id(member: Member) -> str:
    """Produce a deterministic external_id from a member.

    Implementation of the Round 1 contract decision: external_id is a
    deterministic transformation of ``member.member_id``.
    """
    eid = member.member_id
    if eid.startswith("mem_"):
        eid = eid[4:]
    return eid.lower()


# -- Reference adapter -----------------------------------------------------


class ExampleApp:
    """Reference adapter for a fictional ExampleApp.

    The first implementation of the ``Adapter`` Protocol; the SDK's
    conformance suite runs against this as the known-good implementation.
    """

    APP_NAME = "exampleapp"
    FEATURE_KEYS: list[str] = [
        "exampleapp.storage_gb",
        "exampleapp.user_count",
        "exampleapp.feature_enabled",
    ]
    ENFORCEMENT: dict[str, _ENFORCEMENT_TYPE] = cast(
        dict[str, _ENFORCEMENT_TYPE],
        {
            "exampleapp.storage_gb": "hard",
            "exampleapp.user_count": "hard",
            "exampleapp.feature_enabled": "soft",
        },
    )
    _KNOWN_KEYS: set[str] = set(FEATURE_KEYS)

    # Reverse mapping: observed property name → (feature_key, reverse_transform).
    # Used by reconcile() to recover the entitlement-comparable value from
    # observed state. Only includes observed keys that correspond to
    # entitlements; observed keys with no entitlement counterpart are
    # not reversible and are omitted.
    _OBSERVED_TO_ENTITLEMENT: dict[
        str, tuple[str, Callable[[Any], Any]]
    ] = {
        "storage_quota_mb": ("exampleapp.storage_gb", lambda v: v // 1024),
        "seat_count": ("exampleapp.user_count", lambda v: v),
        "feature_x_enabled": ("exampleapp.feature_enabled", lambda v: v),
    }

    def __init__(self, server: FakeExampleAppServer) -> None:
        self._server = server

    def _observed_to_entitlement_value(
        self, observed_state: dict[str, Any], feature_key: str
    ) -> Any:
        """Recover the entitlement-comparable value from observed state.

        Looks up each observed property that maps to the given feature_key,
        applies the reverse transform, and returns the first match.
        Returns None if no observed property maps to this feature key.
        """
        for observed_key, (mapped_key, reverse_transform) in (
            self._OBSERVED_TO_ENTITLEMENT.items()
        ):
            if mapped_key == feature_key and observed_key in observed_state:
                return reverse_transform(observed_state[observed_key])
        return None

    def capabilities(self) -> Capabilities:
        """Declare which feature keys this adapter handles and its limits.

        Returns static metadata describing the adapter's scope: the app
        it targets, the feature keys it enforces, and any operational
        constraints (e.g. maximum concurrent applies).  Called once at
        adapter registration.

        Idempotent: repeated calls with no intervening configuration
        changes return an equivalent result.

        Error modes: should not raise.  All required information is
        static configuration available at adapter startup.
        """
        return Capabilities(
            app=self.APP_NAME,
            feature_keys=[*self.FEATURE_KEYS],
            enforcement={**self.ENFORCEMENT},
            limits={"max_concurrent_apply": 5},
            schema_version=1,
        )

    def apply(self, member: Member, entitlements: list[Entitlement]) -> AppAccount:
        """Idempotently make the target app's state match the desired entitlements.

        Creates accounts that should exist; updates quotas that have
        changed; adjusts feature flags.  Returns the resulting
        ``AppAccount`` data (``external_id`` and current state) so the
        entitlements service can record the provisioned reality.

        When called with an empty ``entitlements`` list, ensures the
        account exists with status ``"active"`` and ``current_state``
        reflecting no entitlements.  (Distinct from ``disable`` which
        sets status to ``"disabled"``.)

        Error modes: should raise on target-app unreachable or
        authentication failure.  Partial application is acceptable only
        if the adapter's internal state remains consistent for a retry.
        """
        try:
            external_id = _derive_external_id(member)
            self._server.create_account(member.member_id, external_id)

            state: dict[str, Any] = {}
            for ent in entitlements:
                if ent.feature_key in self._KNOWN_KEYS:
                    state[ent.feature_key] = ent.value

            self._server.replace_account_state(external_id, state)
            self._server.set_account_status(external_id, "active")

            # Read back the observed state (not the desired state we just wrote).
            # create_account + replace_account_state guarantee the account exists.
            account = self._server.get_account(external_id)
            assert account is not None

            return AppAccount(
                member_id=member.member_id,
                app=self.APP_NAME,
                external_id=external_id,
                status="active",
                last_reconciled_at=None,
                current_state={**account.state},
            )
        except FakeServerUnreachable as exc:
            raise ExampleAppUnreachable("target app is unreachable") from exc

    def disable(self, member: Member) -> None:
        """Soft-disable a member's access while preserving data.

        Blocks the member from using the target app without destroying
        the account or its data.  Reversible by a subsequent ``apply``.

        Idempotent: calling disable multiple times has the same effect
        as calling it once.  A no-op if the member is already disabled
        or has no account in this app.

        Error modes: should raise on target-app unreachable.  Should
        NOT raise when the member has no account.
        """
        try:
            external_id = _derive_external_id(member)
            account = self._server.get_account(external_id)
            if account is None:
                return
            self._server.set_account_status(external_id, "disabled")
        except FakeServerUnreachable as exc:
            raise ExampleAppUnreachable("target app is unreachable") from exc

    def reconcile(self, member: Member, entitlements: list[Entitlement]) -> DriftReport:
        """Read-only drift detection: compare app state to desired state.

        Compares the target app's current state for ``member`` against
        the desired state described by ``entitlements``.  Returns a
        structured ``DriftReport`` enumerating each discrepancy as a
        ``DriftFinding``.  An empty ``findings`` list means no drift.
        Never mutates the target app.

        The ``entitlements`` argument is the same shape passed to
        ``apply`` -- current desired state, not deltas.  The reconciler
        passes the entitlements it currently knows for the member; the
        adapter does not fetch them on its own.

        Four cases by (account-presence x entitlements-presence):
        account-exists and entitlements-non-empty is the expected case
        (compare and report mismatches); account-exists and
        entitlements-empty means correct no-entitlements state (no
        drift); account-absent and entitlements-non-empty produces a
        ``missing_in_app`` finding; account-absent and entitlements-empty
        is correct no-account state (no drift).

        A return with empty findings means the adapter was able to
        contact the target app and found no drift; it is not a fallback
        for unreachability.  When the target app is unreachable, raises
        an adapter-specific exception rather than returning a
        misleadingly empty report.

        Idempotent: repeated calls with unchanged inputs return the
        same report (modulo clock drift in ``reconciled_at``).
        """
        try:
            external_id = _derive_external_id(member)
            account = self._server.get_account(external_id)
            now = datetime.now(timezone.utc)

            if account is None:
                if entitlements:
                    return DriftReport(
                        member_id=member.member_id,
                        app=self.APP_NAME,
                        findings=[
                            DriftFinding(
                                kind="missing_in_app",
                                feature_key=None,
                                expected={"status": "active"},
                                actual=None,
                                severity="critical",
                            )
                        ],
                        reconciled_at=now,
                    )
                return DriftReport(
                    member_id=member.member_id,
                    app=self.APP_NAME,
                    findings=[],
                    reconciled_at=now,
                )

            if entitlements:
                findings: list[DriftFinding] = []

                if account.status == "disabled":
                    findings.append(
                        DriftFinding(
                            kind="state_mismatch",
                            feature_key=None,
                            expected="active",
                            actual="disabled",
                            severity="warning",
                        )
                    )

                for ent in entitlements:
                    if ent.feature_key not in self._KNOWN_KEYS:
                        continue
                    # Read the observed property for this entitlement and
                    # convert back to the entitlement-comparable value.
                    actual_value = self._observed_to_entitlement_value(
                        account.state, ent.feature_key
                    )
                    if actual_value != ent.value:
                        findings.append(
                            DriftFinding(
                                kind="value_mismatch",
                                feature_key=ent.feature_key,
                                expected=ent.value,
                                actual=actual_value,
                                severity="critical",
                            )
                        )

                return DriftReport(
                    member_id=member.member_id,
                    app=self.APP_NAME,
                    findings=findings,
                    reconciled_at=now,
                )

            return DriftReport(
                member_id=member.member_id,
                app=self.APP_NAME,
                findings=[],
                reconciled_at=now,
            )
        except FakeServerUnreachable as exc:
            raise ExampleAppUnreachable("target app is unreachable") from exc

    def health(self) -> HealthStatus:
        """Report adapter and target-app reachability.

        Returns a ``HealthStatus`` with two boolean signals:
        - ``healthy``: ``True`` only when the adapter is responding AND
          ``app_reachable`` is ``True`` (strict conjunction).
        - ``app_reachable``: the target app's API responded.

        The method itself must not raise.  If the adapter cannot perform
        the health check, return ``healthy=False`` with
        ``app_reachable=False`` and use ``details`` to explain.
        """
        try:
            self._server.get_account("__healthcheck__")
            reachable = True
        except FakeServerUnreachable:
            reachable = False

        return HealthStatus(
            healthy=reachable,
            app_reachable=reachable,
            details={"exampleapp_api": "ok" if reachable else "unreachable"},
        )

    def list_accounts(self, cursor: str | None = None) -> AccountListPage:
        """Page through every account in the target app.

        Used by the reconciler for whole-system drift detection.
        Returns a window of accounts and a ``next_cursor`` for
        pagination (``None`` when no more pages).

        An expired or invalid cursor returns an empty page with
        ``next_cursor=None`` rather than raising.

        Error modes: should raise on target-app unreachable.
        """
        try:
            accounts, next_cursor = self._server.list_accounts(cursor)
            return AccountListPage(
                accounts=[
                    AppAccount(
                        member_id=acc.member_id,
                        app=self.APP_NAME,
                        external_id=acc.external_id,
                        status=acc.status,
                        last_reconciled_at=None,
                        current_state={**acc.state},
                    )
                    for acc in accounts
                ],
                next_cursor=next_cursor,
            )
        except FakeServerUnreachable as exc:
            raise ExampleAppUnreachable("target app is unreachable") from exc
