"""Reference event consumer for ExampleApp.

This is the reference implementation of the ``EventConsumer`` Protocol
for the ``ExampleApp`` adapter.  It is used by the conformance suite
to verify event consumer behavior.

Demonstrates the apply-pattern: on each change event, fetches the
member's current entitlements from a (fake or real) entitlements
service and invokes ExampleApp.apply().
"""

from __future__ import annotations

from lightweb_adapter_sdk.event_consumer.protocol import EventConsumer
from lightweb_adapter_sdk.reference import ExampleApp
from lightweb_adapter_sdk.testkit import FakeEntitlementsService
from lightweb_adapter_sdk.types import EventEnvelope


class ReferenceEventConsumer(EventConsumer):
    """Reference EventConsumer for ExampleApp.

    Demonstrates the apply-pattern: on each change event, fetches the
    member's current entitlements from a (fake or real) entitlements
    service and invokes ExampleApp.apply().

    Args:
        adapter: The ExampleApp adapter instance.
        entitlements_client: A ``FakeEntitlementsService`` (or real
            client) that provides the member's current desired state.
    """

    def __init__(
        self,
        adapter: ExampleApp,
        entitlements_client: FakeEntitlementsService,
    ) -> None:
        self._adapter = adapter
        self._entitlements = entitlements_client

    async def consume(self, envelope: EventEnvelope) -> None:
        """Fetch current entitlements for the member and call apply().

        Calls back to the entitlements service for the member's current
        desired state, then invokes the adapter's apply() with that
        state.  The envelope is a signal, not state.
        """
        member = self._entitlements.get_member(envelope.member_id)
        entitlements = self._entitlements.list_entitlements(envelope.member_id)
        self._adapter.apply(member, entitlements)
