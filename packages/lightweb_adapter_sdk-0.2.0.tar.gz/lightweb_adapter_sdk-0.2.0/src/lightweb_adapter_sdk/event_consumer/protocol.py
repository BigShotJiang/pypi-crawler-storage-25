"""The EventConsumer Protocol.

Every adapter that reacts to JetStream events implements this Protocol
in addition to ``Adapter``.  The two Protocols are independent — an
adapter may implement ``Adapter`` without ``EventConsumer`` (e.g. a
pull-only adapter) and vice versa.
"""

from typing import Protocol, runtime_checkable

from lightweb_adapter_sdk.types import EventEnvelope


@runtime_checkable
class EventConsumer(Protocol):
    """Protocol defining the event-consumer contract for adapters.

    This is a structural Protocol, not a base class.  Adapter authors
    are not required to inherit from this class; any class that
    implements the method with a matching signature satisfies
    the contract.

    The SDK's consumer infrastructure (``JetStreamEventConsumer``) is
    responsible for parsing raw JetStream payloads, deduplicating events,
    and filtering by ``is_entitlement_change_event``.  The adapter's
    responsibility is narrow: receive a parsed, deduped, filtered
    ``EventEnvelope``, fetch current desired state from the entitlements
    service, and invoke ``apply()``.
    """

    async def consume(self, envelope: EventEnvelope) -> None:
        """Process a single filtered, deduped event.

        Called by the SDK's consumer infrastructure for each event that:
        - Has been parsed from JetStream into an EventEnvelope.
        - Has not been seen before (passed dedup).
        - Returns True from is_entitlement_change_event.

        The consumer's implementation should call back to the entitlements
        service for the member's current desired state and invoke the
        adapter's apply() with that state. The envelope is a signal,
        not state — adapters re-fetch from authoritative source.

        Must be idempotent — the same envelope may be delivered more than
        once if dedup state is lost (e.g. consumer restart with empty cache).
        The SDK's default dedup absorbs this; this requirement is the
        contractual backstop.
        """
