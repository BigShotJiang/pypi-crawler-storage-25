"""JetStream consumer implementation.

This module provides ``JetStreamEventConsumer``, a concrete
implementation that connects to NATS/JetStream, subscribes to
entitlement-changed event subjects, and dispatches parsed/deduped/
filtered events to an ``EventConsumer`` (typically the adapter).

Requires the ``nats-py`` package (declared in ``pyproject.toml``).

Subscription pattern: the SDK defaults to a single wildcard subscription
to ``"entitlements.>"`` with app-level filtering via
``is_entitlement_change_event``.  This is simpler than 7 separate
subscriptions and the filter exists anyway.

Durable naming: the SDK defaults to ``"<app>-adapter"`` derived from
the adapter's ``capabilities().app``, ensuring deterministic durable
names across deployments for platform delivery-state tracking.
"""

from __future__ import annotations

import asyncio
import logging
from typing import TYPE_CHECKING, Any, Final

from nats.errors import TimeoutError

from lightweb_adapter_sdk.adapter import Adapter
from lightweb_adapter_sdk.event_consumer.dedup import EventDedupCache
from lightweb_adapter_sdk.event_consumer.parser import ParseError, parse_envelope
from lightweb_adapter_sdk.event_consumer.protocol import EventConsumer
from lightweb_adapter_sdk.types import EventEnvelope, is_entitlement_change_event

if TYPE_CHECKING:
    from nats.js import JetStreamContext

logger = logging.getLogger(__name__)


class JetStreamConnectionError(Exception):
    """The JetStream connection is unavailable or misconfigured."""


_DEFAULT_SUBSCRIPTION_SUBJECTS: Final[tuple[str, ...]] = ("entitlements.>",)


def _default_durable_name(adapter: Adapter) -> str:
    """Derive durable consumer name from adapter capabilities.

    The platform tracks delivery state per durable name; deterministic
    naming via adapter's ``capabilities().app`` prevents replay on
    redeploy.
    """
    caps = adapter.capabilities()
    return f"{caps.app}-adapter"


class JetStreamEventConsumer:
    """JetStream-backed event consumer that drives an EventConsumer.

    Connects to a NATS cluster, subscribes to entitlement-changed event
    subjects, parses raw messages, deduplicates, filters by
    ``is_entitlement_change_event``, and dispatches to the adapter's
    ``EventConsumer.consume()`` method.

    The SDK's default subscription pattern is a single wildcard
    ``"entitlements.>"`` with app-level filtering.  The SDK's default
    durable name is ``"<app>-adapter"`` derived from the adapter's
    capabilities.

    Args:
        nats_url: The NATS server URL (e.g. ``"nats://localhost:4222"``).
        adapter: The adapter that implements ``Adapter``.  Used for
            ``capabilities()`` (to derive the default durable name) and
            as the object whose ``EventConsumer.consume()`` is called.
            May be the same object as ``consumer``.
        consumer: The ``EventConsumer`` that processes parsed, deduped,
            filtered envelopes.  Typically the adapter itself (if it
            implements both Protocols).
        subscription_subjects: JetStream subjects to subscribe to.
            Defaults to ``("entitlements.>",)`` — a single wildcard
            with app-level filtering via ``is_entitlement_change_event``.
        durable_name: The durable consumer name.  Defaults to
            ``"<app>-adapter"`` derived from ``adapter.capabilities().app``.
        cache: An optional ``EventDedupCache`` instance.  If not
            provided, a default cache (max 10,000) is created.
        connect_timeout: Seconds to wait for JetStream connection.
            Defaults to 10.
        subscribe_timeout: Seconds to wait for subscription.
            Defaults to 10.
    """

    def __init__(
        self,
        nats_url: str,
        adapter: Adapter,
        consumer: EventConsumer,
        subscription_subjects: tuple[str, ...] | None = None,
        durable_name: str | None = None,
        cache: EventDedupCache | None = None,
        connect_timeout: float = 10.0,
        subscribe_timeout: float = 10.0,
    ) -> None:
        self._nats_url = nats_url
        self._adapter = adapter
        self._consumer = consumer
        self._subscription_subjects = (
            subscription_subjects
            if subscription_subjects is not None
            else _DEFAULT_SUBSCRIPTION_SUBJECTS
        )
        self._durable_name = (
            durable_name if durable_name is not None else _default_durable_name(adapter)
        )
        self._cache = cache or EventDedupCache()
        self._connect_timeout = connect_timeout
        self._subscribe_timeout = subscribe_timeout
        self._nc: Any = None
        self._js: JetStreamContext | None = None
        self._subscriptions: list[Any] = []
        self._running = False

    async def start(self) -> None:
        """Start consuming events from JetStream.

        Connects to the NATS cluster, creates (or resumes) the durable
        consumer, subscribes to the configured subjects, and begins
        processing messages via callbacks.
        """
        if self._running:
            return

        import nats

        try:
            self._nc = await asyncio.wait_for(
                nats.connect(self._nats_url),
                timeout=self._connect_timeout,
            )
        except (TimeoutError, OSError) as exc:
            raise JetStreamConnectionError(
                f"Failed to connect to NATS at {self._nats_url}: {exc}"
            ) from exc

        try:
            self._js = self._nc.jetstream()
        except Exception as exc:
            await self._nc.close()
            raise JetStreamConnectionError(
                f"Failed to get JetStream context: {exc}"
            ) from exc

        # Subscribe to each configured subject
        for subject in self._subscription_subjects:
            try:
                sub = await asyncio.wait_for(
                    self._js.subscribe(
                        subject,
                        durable=self._durable_name,
                        cb=self._on_message,
                    ),
                    timeout=self._subscribe_timeout,
                )
                self._subscriptions.append(sub)
            except (TimeoutError, Exception) as exc:
                await self._nc.close()
                raise JetStreamConnectionError(
                    f"Failed to subscribe to {subject}: {exc}"
                ) from exc

        self._running = True
        logger.info(
            "JetStreamEventConsumer started: subjects=%s, durable=%s",
            self._subscription_subjects,
            self._durable_name,
        )

    async def stop(self) -> None:
        """Stop consuming events and clean up resources.

        Drains all subscriptions, closes the NATS connection.
        Safe to call multiple times (idempotent).  Does not raise.
        """
        if not self._running:
            return
        self._running = False

        for sub in self._subscriptions:
            try:
                await sub.drain()
            except Exception:
                pass
        self._subscriptions.clear()

        if self._nc is not None:
            try:
                await self._nc.close()
            except Exception:
                pass
            self._nc = None

        self._js = None
        logger.info("JetStreamEventConsumer stopped")

    async def handle_event(self, raw_payload: bytes) -> None:
        """Process a single raw JetStream message.

        Parses the envelope, checks dedup, filters by
        ``is_entitlement_change_event``, and dispatches to the
        ``EventConsumer.consume()`` method if the event warrants it.

        All errors are logged and the event is acknowledged to
        JetStream to prevent infinite redelivery.
        """
        envelope: EventEnvelope | None = None
        try:
            envelope = parse_envelope(raw_payload)
        except ParseError as exc:
            logger.error("Failed to parse event envelope: %s", exc)
            return

        if self._cache.is_seen(envelope.event_id):
            logger.debug("Duplicate event, skipping: %s", envelope.event_id)
            return

        if not is_entitlement_change_event(envelope):
            logger.debug(
                "Non-change event, recording dedup but not dispatching: %s",
                envelope.event_id,
            )
            self._cache.record(envelope.event_id)
            return

        try:
            await self._consumer.consume(envelope)
        except Exception:
            logger.exception(
                "Failed to consume event %s for member %s",
                envelope.event_id,
                envelope.member_id,
            )
            return

        self._cache.record(envelope.event_id)

    async def _on_message(self, msg: Any) -> None:
        """Internal callback for JetStream message delivery.

        Acknowledges the message after processing (or on error) to
        prevent infinite redelivery.
        """
        try:
            await self.handle_event(msg.data)
            try:
                msg.ack()
            except Exception:
                pass
        except Exception:
            try:
                msg.nak()
            except Exception:
                pass
