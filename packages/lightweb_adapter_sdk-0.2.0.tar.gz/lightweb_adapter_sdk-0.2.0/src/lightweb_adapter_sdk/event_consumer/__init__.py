"""JetStream event consumer infrastructure for adapters.

This module provides the ``EventConsumer`` Protocol, an envelope parser,
an in-memory deduplication cache, and a JetStream consumer implementation.
See ``docs/contract.md`` §6 (idempotency, consumer-level) and
``docs/event-consumer.md`` (Deliverable 12) for the full specification.
"""

from lightweb_adapter_sdk.event_consumer.dedup import EventDedupCache
from lightweb_adapter_sdk.event_consumer.jetstream import JetStreamEventConsumer
from lightweb_adapter_sdk.event_consumer.parser import parse_envelope
from lightweb_adapter_sdk.event_consumer.protocol import EventConsumer

__all__ = [
    "EventConsumer",
    "EventDedupCache",
    "JetStreamEventConsumer",
    "parse_envelope",
]
