"""In-memory event deduplication cache.

JetStream delivers events at-least-once, meaning the same event may
arrive multiple times.  This module provides ``EventDedupCache``, an
in-memory LRU cache that tracks seen ``event_id`` values and evicts
oldest entries when the cache reaches its configured size limit.

The implementation uses ``collections.OrderedDict`` for the LRU
eviction policy: ``move_to_end`` on access and ``popitem(last=False)``
on overflow.  This avoids external dependencies while providing
O(1) dedup checks.
"""

from __future__ import annotations

from collections import OrderedDict
from typing import Any


class EventDedupCache:
    """In-memory LRU cache for deduplicating JetStream events.

    Tracks ``event_id`` values and evicts the oldest entries when the
    cache reaches its configured size limit.

    Args:
        max_size: Maximum number of event IDs to track.  Defaults to
            10,000.  Events beyond this limit are evicted using an
            LRU policy (oldest first).
    """

    def __init__(self, max_size: int = 10_000) -> None:
        if max_size < 1:
            raise ValueError("max_size must be at least 1")
        self._max_size = max_size
        self._seen: OrderedDict[str, Any] = OrderedDict()

    def is_seen(self, event_id: str) -> bool:
        """Check whether this event_id has already been processed.

        Args:
            event_id: The unique event identifier from ``EventEnvelope``.

        Returns:
            ``True`` if the event_id is in the cache (already seen),
            ``False`` otherwise.
        """
        return event_id in self._seen

    def record(self, event_id: str) -> None:
        """Record an event_id as seen, evicting oldest if at capacity.

        Args:
            event_id: The unique event identifier to record.
        """
        if event_id in self._seen:
            # Move to end to refresh (LRU behavior)
            self._seen.move_to_end(event_id)
        else:
            if len(self._seen) >= self._max_size:
                # Evict oldest entry
                self._seen.popitem(last=False)
            self._seen[event_id] = None

    @property
    def size(self) -> int:
        """Current number of event IDs tracked."""
        return len(self._seen)

    @property
    def max_size(self) -> int:
        """Configured maximum cache size."""
        return self._max_size

    def clear(self) -> None:
        """Remove all tracked event IDs."""
        self._seen.clear()
