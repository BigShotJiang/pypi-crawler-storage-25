"""Envelope parser: raw JetStream payload → EventEnvelope.

The platform publishes JetStream messages as JSON with the following
shape (per ``libs/events/schemas/entitlements/_envelope.json``):

.. code-block:: json

   {
       "id": "<event-id>",
       "type": "entitlements.<entity>.<verb>",
       "specversion": "1.0",
       "time": "2026-05-17T12:00:00Z",
       "source": "service:entitlements",
       "subject": {"type": "member", "id": "mem_..."},
       "data": {"member_id": "mem_...", ...},
       "context": {"trace_context": "..."}
   }

This module parses that shape into the SDK's ``EventEnvelope``,
flattening ``data.member_id`` to the top level and omitting ``subject``
and ``data`` (beyond ``member_id``).
"""

from __future__ import annotations

import json
from datetime import datetime, timezone

from lightweb_adapter_sdk.types import EventEnvelope


class ParseError(ValueError):
    """The raw payload could not be parsed into an EventEnvelope."""


def parse_envelope(raw_payload: bytes) -> EventEnvelope:
    """Parse a raw JetStream message payload into an ``EventEnvelope``.

    Args:
        raw_payload: The raw bytes from JetStream, expected to be
            UTF-8 encoded JSON matching the platform envelope schema.

    Returns:
        A fully-populated ``EventEnvelope``.

    Raises:
        ParseError: If the payload is not valid JSON, is missing
            required fields, or has an unexpected shape.
    """
    try:
        data = json.loads(raw_payload)
    except (json.JSONDecodeError, TypeError) as exc:
        raise ParseError(f"Payload is not valid JSON: {exc}") from exc

    # Required top-level fields
    for field in ("id", "type", "specversion", "time", "source"):
        if field not in data:
            raise ParseError(f"Missing required field: {field}")

    # data.member_id is the source for EventEnvelope.member_id
    if "data" not in data or not isinstance(data["data"], dict):
        raise ParseError("Missing or invalid 'data' field")
    if "member_id" not in data["data"]:
        raise ParseError("Missing 'data.member_id' field")

    member_id = data["data"]["member_id"]
    if not isinstance(member_id, str):
        raise ParseError(
            f"'data.member_id' must be a string, got {type(member_id).__name__}"
        )

    # context is optional but preserved when present
    context = data.get("context")
    if context is not None and not isinstance(context, dict):
        raise ParseError("'context' must be an object when present")

    # Parse time — accept ISO-8601 strings
    time_str = data["time"]
    try:
        occurred_at = datetime.fromisoformat(time_str)
        if occurred_at.tzinfo is None:
            occurred_at = occurred_at.replace(tzinfo=timezone.utc)
    except (ValueError, TypeError) as exc:
        raise ParseError(f"Invalid 'time' field: {time_str}: {exc}") from exc

    return EventEnvelope(
        event_id=data["id"],
        event_type=data["type"],
        event_version=data["specversion"],
        occurred_at=occurred_at,
        emitted_by=data["source"],
        member_id=member_id,
        context=context,
    )
