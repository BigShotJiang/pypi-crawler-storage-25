"""In-process fake of the platform's entitlements service.

Adapter authors use this in their tests to stage entitlements and
verify ``apply()`` / ``reconcile()`` behavior with realistic data.
The fake is in-memory only — no HTTP, no persistence.

See docs/testkit.md for usage instructions.
"""

from __future__ import annotations

from lightweb_adapter_sdk.types import AppAccount, Entitlement, Member


class FakeEntitlementsService:
    """In-process fake of the platform's entitlements service.

    Provides the two surfaces adapters interact with:
    - Staging member entitlements (what the adapter reads on event receipt).
    - Recording provisioned reality via ``upsert_app_account``.
    """

    def __init__(self) -> None:
        self._entitlements: dict[tuple[str, str], list[Entitlement]] = {}
        self._app_accounts: dict[tuple[str, str], AppAccount] = {}
        self._member_cache: dict[str, Member] = {}

    # -- State staging (test setup) ------------------------------------------

    def set_member_entitlements(
        self,
        member_id: str,
        app: str,
        entitlements: list[Entitlement],
    ) -> None:
        """Stage entitlements for a member. Used in test setup.

        Replaces any prior entitlements for that ``(member, app)`` pair.
        Idempotent.
        """
        self._entitlements[(member_id, app)] = list(entitlements)

    def get_member_entitlements(
        self,
        member_id: str,
        app: str,
    ) -> list[Entitlement]:
        """Read staged entitlements. The adapter calls this on event receipt.

        Returns a copy to prevent accidental mutation of fake state.
        Returns an empty list for unknown keys; never raises.
        """
        return list(self._entitlements.get((member_id, app), []))

    # -- AppAccount upsert (called by adapter after apply() succeeds) --------

    def upsert_app_account(self, account: AppAccount) -> AppAccount:
        """Record provisioned reality. Stores and returns the account.

        Accepts an ``AppAccount`` instance only. Stores by
        ``(member_id, app)``; subsequent calls with the same key
        update the existing record.
        """
        key = (account.member_id, account.app)
        self._app_accounts[key] = account
        return account

    def get_app_account(
        self,
        member_id: str,
        app: str,
    ) -> AppAccount | None:
        """Read recorded provisioned reality. Used in test assertions.

        Returns ``None`` for unknown keys; never raises.
        """
        return self._app_accounts.get((member_id, app))

    # -- Member lookup (for event consumer tests) ----------------------------

    def set_member(self, member: Member) -> None:
        """Stage a member record. Used in test setup for event consumer tests.

        The member is cached and returned by ``get_member``.
        """
        self._member_cache[member.member_id] = member

    def get_member(self, member_id: str) -> Member:
        """Read the staged member record.

        Returns a default Member for unknown IDs (enabled, individual,
        no external IDs) to support event consumer tests that don't
        explicitly stage a member.
        """
        return self._member_cache.get(
            member_id,
            Member(
                member_id=member_id,
                member_type="individual",
                external_ids={},
                enabled=True,
            ),
        )

    def list_entitlements(self, member_id: str) -> list[Entitlement]:
        """Return all staged entitlements for a member across all apps.

        Returns a copy to prevent accidental mutation of fake state.
        Returns an empty list for unknown members; never raises.
        """
        result: list[Entitlement] = []
        for (_mid, _app), ents in self._entitlements.items():
            if _mid == member_id:
                result.extend(ents)
        return result
