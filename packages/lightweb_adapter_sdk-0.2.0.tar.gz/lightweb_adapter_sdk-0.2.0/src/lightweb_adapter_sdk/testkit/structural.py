"""Structural tests for adapter authors.

Each function is a parameterized test that checks one structural
property of an adapter.  Adapter authors import these and re-export
them in their own ``tests/test_structural.py``, providing an
``adapter_under_test`` fixture in their ``conftest.py``.

See docs/testkit.md for usage instructions.
"""

from __future__ import annotations

from lightweb_adapter_sdk.adapter import Adapter
from lightweb_adapter_sdk.types import (
    AccountListPage,
    Capabilities,
    HealthStatus,
)


def test_satisfies_protocol(adapter_under_test: Adapter) -> None:
    """The adapter structurally satisfies the Adapter Protocol.

    Uses ``isinstance`` against the ``@runtime_checkable`` Adapter
    Protocol.  Does not verify behavioral correctness; that is
    conformance-suite territory.
    """
    assert isinstance(adapter_under_test, Adapter)


def test_capabilities_returns_well_shaped(
    adapter_under_test: Adapter,
) -> None:
    """``capabilities()`` returns a ``Capabilities`` instance with at
    least one feature key, and enforcement entries matching the feature
    keys.
    """
    caps = adapter_under_test.capabilities()
    assert isinstance(caps, Capabilities)
    assert len(caps.feature_keys) >= 1
    for key in caps.feature_keys:
        assert key in caps.enforcement


def test_health_is_callable(adapter_under_test: Adapter) -> None:
    """``health()`` returns a ``HealthStatus`` instance without raising.

    Does not verify the strict-conjunction or specific reachability
    behavior; that is conformance-suite territory.
    """
    status = adapter_under_test.health()
    assert isinstance(status, HealthStatus)


def test_list_accounts_initial_page(adapter_under_test: Adapter) -> None:
    """``list_accounts(cursor=None)`` returns an ``AccountListPage`` instance.

    Does not verify pagination semantics or specific account contents;
    that is conformance-suite territory.
    """
    page = adapter_under_test.list_accounts()
    assert isinstance(page, AccountListPage)
    assert isinstance(page.accounts, list)
    assert page.next_cursor is None or isinstance(page.next_cursor, str)
