"""Testkit for adapter authors.

Import from this module to test your adapter during development:

- Structural tests: ``test_satisfies_protocol``,
  ``test_capabilities_returns_well_shaped``,
  ``test_health_is_callable``, ``test_list_accounts_initial_page``.
- ``FakeEntitlementsService``: an in-process fake of the platform's
  entitlements service for staging state in tests that drive
  ``apply()`` or ``reconcile()``.

Adapter authors re-export the test functions in their own
``tests/test_structural.py`` and provide an ``adapter_under_test``
fixture in their ``conftest.py``.

See docs/testkit.md for full usage instructions.
"""

from lightweb_adapter_sdk.testkit.fake_entitlements import FakeEntitlementsService
from lightweb_adapter_sdk.testkit.fake_event_source import FakeEventSource
from lightweb_adapter_sdk.testkit.structural import (
    test_capabilities_returns_well_shaped,
    test_health_is_callable,
    test_list_accounts_initial_page,
    test_satisfies_protocol,
)

__all__ = [
    "FakeEntitlementsService",
    "FakeEventSource",
    "test_satisfies_protocol",
    "test_capabilities_returns_well_shaped",
    "test_health_is_callable",
    "test_list_accounts_initial_page",
]
