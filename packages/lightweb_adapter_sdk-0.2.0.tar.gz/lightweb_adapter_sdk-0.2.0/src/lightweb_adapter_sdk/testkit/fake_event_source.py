"""Fake event source for testing event consumers.

Provides ``FakeEventSource``, an in-process fake that publishes
``EventEnvelope`` instances as raw JetStream-style JSON bytes,
allowing tests to drive event consumer behavior without a real
NATS/JetStream connection.
"""

from __future__ import annotations

import asyncio
import json

from typing import Any, Callable

from lightweb_adapter_sdk.types import EventEnvelope


class FakeEventSource:
    """In-process fake that publishes event envelopes as raw bytes.

    Simulates a JetStream stream by delivering events to registered
    callbacks (consumers).  Events are stored internally for inspection
    and can be published synchronously or asynchronously.

    Args:
        subject: The subject name this fake source publishes to
            (e.g. ``"entitlements.member.>"``).
    """

    def __init__(self, subject: str = "entitlements.test") -> None:
        self._subject = subject
        self._consumers: list[Callable[[bytes], Any]] = []
        self._published: list[tuple[EventEnvelope, bytes]] = []
        self._sequence = 0

    def register_consumer(self, callback: Callable[[bytes], Any]) -> None:
        """Register a consumer callback to receive published events.

        Args:
            callback: An async callable that accepts raw bytes
                (the JSON payload of the event).
        """
        self._consumers.append(callback)

    def _next_event_id(self) -> str:
        self._sequence += 1
        return f"evt-fake-{self._sequence:04d}"

    def publish(self, envelope: EventEnvelope) -> bytes:
        """Publish an event envelope as raw JSON bytes.

        Delivers the payload to all registered consumers synchronously.

        Args:
            envelope: The event envelope to publish.

        Returns:
            The raw JSON bytes that were published.
        """
        payload_dict = {
            "id": envelope.event_id,
            "type": envelope.event_type,
            "specversion": envelope.event_version,
            "time": envelope.occurred_at.isoformat(),
            "source": envelope.emitted_by,
            "data": {"member_id": envelope.member_id},
        }
        if envelope.context is not None:
            payload_dict["context"] = envelope.context

        raw = json.dumps(payload_dict).encode("utf-8")
        self._published.append((envelope, raw))

        for consumer in self._consumers:
            consumer(raw)

        return raw

    async def publish_async(self, envelope: EventEnvelope) -> bytes:
        """Publish an event envelope asynchronously.

        Delivers the payload to all registered consumers as async calls.

        Args:
            envelope: The event envelope to publish.

        Returns:
            The raw JSON bytes that were published.
        """
        payload_dict = {
            "id": envelope.event_id,
            "type": envelope.event_type,
            "specversion": envelope.event_version,
            "time": envelope.occurred_at.isoformat(),
            "source": envelope.emitted_by,
            "data": {"member_id": envelope.member_id},
        }
        if envelope.context is not None:
            payload_dict["context"] = envelope.context

        raw = json.dumps(payload_dict).encode("utf-8")
        self._published.append((envelope, raw))

        for consumer in self._consumers:
            if asyncio.iscoroutinefunction(consumer):
                await consumer(raw)
            else:
                consumer(raw)

        return raw

    @property
    def subject(self) -> str:
        """The subject this source publishes to."""
        return self._subject

    @property
    def published_events(self) -> list[tuple[EventEnvelope, bytes]]:
        """All events published, as (envelope, raw_bytes) tuples."""
        return list(self._published)

    @property
    def published_count(self) -> int:
        """Number of events published."""
        return len(self._published)

    def clear(self) -> None:
        """Clear all published events and registered consumers."""
        self._published.clear()
        self._consumers.clear()
        self._sequence = 0
