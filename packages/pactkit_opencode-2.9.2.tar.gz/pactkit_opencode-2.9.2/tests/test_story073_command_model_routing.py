"""
STORY-073: OpenCode Format Final Mile — Command Model Routing and Claude Code Residuals
Tests for command model routing (in opencode.json), project-init conditional, YAML comments, doc strings.
"""

import json

from pactkit.config import get_default_config
from pactkit.generators.deployer import deploy
from pactkit_opencode.deployer import OpenCodeDeployer

_resolve_opencode_model_id = OpenCodeDeployer._resolve_opencode_model_id


# ===========================================================================
# AC1: OpenCode model routing is in opencode.json command section
# ===========================================================================


class TestAC1CommandModel:
    """AC1: Model routing is in opencode.json command section (not frontmatter)."""

    def _deploy_with_providers(self, tmp_path):
        """Deploy with seeded provider config so model resolution works in CI."""
        out = tmp_path / "oc"
        out.mkdir(parents=True, exist_ok=True)
        providers = {
            "$schema": "https://opencode.ai/config.json",
            "provider": {
                "test-provider": {
                    "models": {
                        "claude-sonnet-4.6": {"name": "Sonnet"},
                        "claude-opus-4.6": {"name": "Opus"},
                        "claude-haiku-4.5": {"name": "Haiku"},
                    }
                }
            },
        }
        (out / "opencode.json").write_text(json.dumps(providers))
        deploy(format="opencode", target=str(out))
        return out

    def test_no_model_only_entries_in_opencode_json(self, tmp_path):
        """Model-only command entries must NOT be written — OpenCode requires both model AND template."""
        out = self._deploy_with_providers(tmp_path)
        data = json.loads((out / "opencode.json").read_text())
        cmd_config = data.get("command", {})
        for cmd_name, cmd_val in cmd_config.items():
            if cmd_name.startswith("project-"):
                assert "template" in cmd_val, (
                    f"command.{cmd_name} has model but no template — OpenCode validation will fail"
                )

    def test_frontmatter_has_no_model(self, tmp_path):
        """Command frontmatter should NOT contain model: (routing is in opencode.json)."""
        out = self._deploy_with_providers(tmp_path)
        content = (out / "commands" / "project-act.md").read_text()
        import re
        matches = list(re.finditer(r'---\n(.*?)\n---', content, re.DOTALL))
        assert matches, "No frontmatter found"
        for m in matches:
            if "description:" in m.group(1):
                frontmatter = m.group(1)
                break
        else:
            frontmatter = matches[-1].group(1)
        for line in frontmatter.strip().split("\n"):
            assert not line.strip().startswith("model:"), f"Unexpected model in frontmatter: {line}"


# ===========================================================================
# AC2: Plan command NOT in command routing
# ===========================================================================


class TestAC2PlanNoModel:
    """AC2: Commands that inherit main model have no model override in opencode.json."""

    def test_plan_not_in_command_routing(self, tmp_path):
        """project-plan has no entry in opencode.json command section (no model override needed).

        OpenCode auto-discovers commands from commands/*.md directory.
        JSON command entries are only for model routing overrides.
        """
        out = tmp_path / "oc"
        out.mkdir(parents=True, exist_ok=True)
        providers = {"$schema": "x", "provider": {"tp": {"models": {"claude-sonnet-4.6": {}}}}}
        (out / "opencode.json").write_text(json.dumps(providers))
        deploy(format="opencode", target=str(out))
        data = json.loads((out / "opencode.json").read_text())
        assert "project-plan" not in data.get("command", {})

    def test_clarify_not_in_command_routing(self, tmp_path):
        """project-clarify has no entry in opencode.json command section (no model override needed)."""
        out = tmp_path / "oc"
        out.mkdir(parents=True, exist_ok=True)
        providers = {"$schema": "x", "provider": {"tp": {"models": {"claude-sonnet-4.6": {}}}}}
        (out / "opencode.json").write_text(json.dumps(providers))
        deploy(format="opencode", target=str(out))
        data = json.loads((out / "opencode.json").read_text())
        assert "project-clarify" not in data.get("command", {})


# ===========================================================================
# AC3: Classic format has no model field
# ===========================================================================


class TestAC3ClassicNoModel:
    """AC3: Classic format commands never have model: field."""

    def test_classic_no_model(self, tmp_path):
        """Classic project-act SKILL.md has no model: field.
        pactkit 2.7.0: commands deploy to skills/{name}/SKILL.md in classic format."""
        out = tmp_path / "classic"
        deploy(format="classic", target=str(out))
        content = (out / "skills" / "project-act" / "SKILL.md").read_text()
        parts = content.split("---", 2)
        frontmatter = parts[1]
        for line in frontmatter.strip().split("\n"):
            assert not line.strip().startswith("model:"), f"Unexpected model: {line}"


# ===========================================================================
# AC4: project-init conditional (playbook text check)
# ===========================================================================


class TestAC4InitConditional:
    """AC4: project-init rendered per-format references the correct instructions file."""

    def test_init_has_conditional(self):
        """project-init playbook rendered for OpenCode contains 'OpenCode' and 'AGENTS.md'.

        After STORY-slim-074 DIP refactor, the raw template uses {DISPLAY_NAME} and
        {INSTRUCTIONS_FILE} placeholders instead of hardcoded format-specific strings.
        _render_prompt() injects the correct values at deploy time.
        """
        from pactkit.generators.deployer import _render_prompt
        from pactkit.profiles import get_profile
        from pactkit.prompts import COMMANDS_CONTENT

        profile = get_profile("opencode")
        init_content = _render_prompt(COMMANDS_CONTENT["project-init.md"], profile)
        assert "OpenCode" in init_content
        assert "AGENTS.md" in init_content
        # Rendered for classic: {DISPLAY_NAME} → 'Claude Code', {PROJECT_CONFIG_DIR} → '.claude'
        classic_content = _render_prompt(COMMANDS_CONTENT["project-init.md"], get_profile("classic"))
        assert "Claude Code" in classic_content or ".claude" in classic_content


# ===========================================================================
# AC5: YAML comments have no ~/.claude/
# ===========================================================================


class TestAC5YamlComments:
    """AC5: Generated pactkit.yaml comments don't reference ~/.claude/."""

    def test_default_yaml_no_claude_path(self):
        """generate_default_yaml() output has no ~/.claude/ in comments."""
        from pactkit.config import generate_default_yaml

        yaml_text = generate_default_yaml()
        for line in yaml_text.split("\n"):
            if line.strip().startswith("#"):
                assert "~/.claude/" not in line, f"Comment references ~/.claude/: {line}"

    def test_rewrite_yaml_no_claude_path(self, tmp_path, monkeypatch):
        """_rewrite_yaml() output has no ~/.claude/ in comments."""
        from pactkit.config import _rewrite_yaml

        monkeypatch.chdir(tmp_path)
        yaml_path = tmp_path / "test.yaml"
        _rewrite_yaml(yaml_path, get_default_config())
        content = yaml_path.read_text()
        for line in content.split("\n"):
            if line.strip().startswith("#"):
                assert "~/.claude/" not in line, f"Comment references ~/.claude/: {line}"


# ===========================================================================
# AC6: User can override command model + resolver tests
# ===========================================================================


class TestAC6CommandModelOverride:
    """AC6: command_models in config and model resolver."""

    def test_default_config_has_command_models(self):
        """Default config includes command_models."""
        defaults = get_default_config()
        assert "command_models" in defaults
        assert isinstance(defaults["command_models"], dict)

    def test_resolve_model_id_sonnet(self):
        """_resolve_opencode_model_id resolves 'sonnet' to provider model ID."""
        providers = {
            "my-provider": {
                "models": {
                    "claude-sonnet-4.6": {"name": "Sonnet"},
                    "claude-opus-4.6": {"name": "Opus"},
                }
            }
        }
        result = _resolve_opencode_model_id("sonnet", providers)
        assert result == "my-provider/claude-sonnet-4.6"

    def test_resolve_model_id_haiku(self):
        """_resolve_opencode_model_id resolves 'haiku' to provider model ID."""
        providers = {"my-provider": {"models": {"claude-haiku-4.5": {"name": "Haiku"}}}}
        result = _resolve_opencode_model_id("haiku", providers)
        assert result == "my-provider/claude-haiku-4.5"

    def test_resolve_model_id_not_found(self):
        """_resolve_opencode_model_id returns None when model not found."""
        providers = {"my-provider": {"models": {"gpt-4": {"name": "GPT"}}}}
        result = _resolve_opencode_model_id("sonnet", providers)
        assert result is None

    def test_resolve_model_id_empty_providers(self):
        """_resolve_opencode_model_id returns None with empty providers."""
        result = _resolve_opencode_model_id("sonnet", {})
        assert result is None


# ===========================================================================
# R4: Skills.py doc string update
# ===========================================================================


class TestR4DocStrings:
    """R4: skills.py doc strings mention both paths."""

    def test_skills_mention_opencode_path(self):
        """Skill doc strings use {SKILLS_ROOT} template variable (STORY-slim-006).
        The actual path is injected at deploy time via _render_prompt()."""
        from pactkit.prompts import skills as skills_mod

        full_text = ""
        for attr_name in dir(skills_mod):
            val = getattr(skills_mod, attr_name)
            if isinstance(val, str) and "Script location" in val:
                full_text += val
        if full_text:
            # After STORY-slim-006, skills use {BOARD_CMD}/{VISUALIZE_CMD}/{SCAFFOLD_CMD} placeholders
            has_placeholder = (
                "{BOARD_CMD}" in full_text or "{VISUALIZE_CMD}" in full_text or "{SCAFFOLD_CMD}" in full_text
            )
            assert has_placeholder, "Skill SKILL.md should use {BOARD_CMD}/{VISUALIZE_CMD}/{SCAFFOLD_CMD} placeholders"
