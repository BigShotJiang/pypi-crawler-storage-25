# pactkit-opencode

> PactKit PDCA workflow framework adapted for [OpenCode](https://opencode.ai).

[![PyPI version](https://badge.fury.io/py/pactkit-opencode.svg)](https://pypi.org/project/pactkit-opencode/)
[![Python 3.10+](https://img.shields.io/badge/python-3.10+-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

## What is this?

**pactkit-opencode** brings the [PactKit](https://pactkit.dev) spec-driven development workflow to OpenCode IDE. It deploys:

- **Commands** (`commands/*.md`) — 11 PDCA workflow commands, auto-discovered by OpenCode (invoked via `/project-plan`, `/project-act`, etc.)
- **Skills** (`skills/*/SKILL.md`) — 10 embedded skills loaded by AI agent on demand
- **Agents** (`agents/*.md`) — 9 specialized agent definitions
- **Rules** (`rules/*.md`) — Governance rules loaded per-command

## Installation

```bash
pip install pactkit
```

> `pactkit-opencode` is automatically installed as a dependency of `pactkit`.

## Quick Start

```bash
# Deploy PactKit to OpenCode (~/.config/opencode/)
pactkit init --format opencode

# Update when pactkit is upgraded
pactkit upgrade --format opencode
```

Then in OpenCode, use commands like:

```
/project-plan "Add user authentication"
/project-act STORY-001
/project-done
```

## What Gets Deployed

```
~/.config/opencode/
├── AGENTS.md              # Global constitution
├── rules/                 # Governance rule modules
├── commands/              # 11 PDCA command playbooks (auto-discovered by OpenCode)
├── agents/                # 9 agent definitions (mode: subagent)
├── skills/                # 10 skill packages (AI agent loads on demand)
└── opencode.json          # Global config (model routing, instructions)

./                         # Project root
├── .opencode/
│   ├── pactkit.yaml       # Project config
│   └── AGENTS.local.md    # Your custom instructions (never overwritten)
```

## OpenCode Architecture

OpenCode has two separate mechanisms for extending the AI assistant:

| Mechanism | Location | Invocation | Purpose |
|-----------|----------|------------|---------|
| **Commands** | `commands/*.md` | User types `/command-name` | PDCA workflow entry points |
| **Skills** | `skills/*/SKILL.md` | AI agent loads via `skill()` | Embedded tools (visualize, board, scaffold) |

Commands are auto-discovered from `commands/*.md` — no `opencode.json` configuration needed.

## Key Differences from Claude Code

| Feature | Claude Code | OpenCode |
|---------|-------------|----------|
| Commands | Skills-only (`skills/project-*/SKILL.md`) | Dual: `commands/` + `skills/` |
| Config dir | `~/.claude/` | `~/.config/opencode/` |
| Agent format | Native multi-agent | `mode: subagent` |
| Model routing | Via skill frontmatter | Via `opencode.json` command entries |
| Rule loading | `@import` directives | Inline embedding per command |

## Development

```bash
git clone https://github.com/pactkit/pactkit-opencode.git
cd pactkit-opencode
pip install -e .
pytest tests/ -v
```

## License

MIT License - see [LICENSE](LICENSE) for details.

## Related Projects

- [PactKit](https://pactkit.dev) — Core framework
- [pactkit-codex](https://github.com/pactkit/pactkit-codex) — Adapter for OpenAI Codex CLI
- [OpenCode](https://opencode.ai) — AI-powered coding IDE
