"""OpenCode deployer — generates OpenCode-native configuration.

Extracted from pactkit core (STORY-slim-058).
"""

import json
import re
from pathlib import Path

from pactkit import __version__, prompts
from pactkit.config import (
    VALID_AGENTS,
    VALID_COMMANDS,
    VALID_RULES,
    VALID_SKILLS,
    auto_merge_config_file,
    load_config,
)
from pactkit.generators.deploy_base import DeployerBase, register_deployer
from pactkit.generators.deployer import (
    _cleanup_legacy,
    _deploy_agents,
    _deploy_ci,
    _deploy_commands,
    _deploy_rules,
    _deploy_skills,
)
from pactkit.profiles import get_profile
from pactkit.prompts.rules import CREDENTIAL_SAFETY_FILE
from pactkit.utils import atomic_write

# Commands excluded from OpenCode deployment (require multi-agent capabilities)
OPENCODE_EXCLUDED_COMMANDS = {"project-sprint"}


class OpenCodeDeployer(DeployerBase):
    """OpenCode deployment — generate OpenCode-native configuration (STORY-069).

    OpenCode (anomalyco/opencode) is an open-source AI coding assistant that supports
    multiple LLM providers. This deployment mode generates OpenCode-native files:
    - AGENTS.md (slim header — rules loaded via instructions)
    - rules/ directory with modular rule files (STORY-071 R6)
    - opencode.json (global config with instructions: ["rules/*.md"])
    - agents/ directory
    - commands/ directory (PDCA commands, invoked via /command-name)
    - skills/ directory (embedded skills like pactkit-board, pactkit-visualize)

    STORY-slim-008: Aligned with _deploy_classic() feature set:
    - Reads pactkit.yaml for selective deployment (R1)
    - Calls auto_merge_config_file() for automatic config updates (R2)
    - Calls _cleanup_legacy() to remove stale skill files (R3)
    - Generates project-level AGENTS.md when not in preview mode (R4)
    - Prints MCP server recommendations (R5)
    """

    profile = get_profile("opencode")

    def deploy(self, config=None, target=None):
        opencode_root = Path(target) if target else Path.home() / ".config" / "opencode"

        print("🚀 PactKit OpenCode Deployment")

        # Prepare directories
        agents_dir = opencode_root / "agents"
        skills_dir = opencode_root / "skills"
        commands_dir = opencode_root / "commands"
        rules_dir = opencode_root / "rules"

        for d in [opencode_root, agents_dir, skills_dir, commands_dir, rules_dir]:
            d.mkdir(parents=True, exist_ok=True)

        # STORY-slim-008 R1+R2: Load config from project-level pactkit.yaml
        from pactkit.config import find_pactkit_yaml

        project_yaml = find_pactkit_yaml()

        if project_yaml is not None:
            auto_added = auto_merge_config_file(project_yaml)
            for item in auto_added:
                print(f"  -> Auto-added: {item}")
            cfg = load_config(project_yaml)
        else:
            cfg = {}

        enabled_agents = cfg.get("agents", sorted(VALID_AGENTS))
        enabled_skills = cfg.get("skills", sorted(VALID_SKILLS))
        enabled_commands = cfg.get("commands", sorted(VALID_COMMANDS))
        enabled_rules = cfg.get("rules", sorted(VALID_RULES))

        # Filter out excluded commands (project-sprint requires multi-agent)
        enabled_commands = [c for c in enabled_commands if c not in OPENCODE_EXCLUDED_COMMANDS]

        # Deploy embedded skills (pactkit-board, pactkit-visualize, etc.)
        n_skills = _deploy_skills(skills_dir, enabled_skills, profile=self.profile)
        _cleanup_legacy(skills_dir)
        # Clean up legacy command skills from skills/ directory (migrated to commands/)
        self._cleanup_command_skills(skills_dir)

        # Apply CLI-to-script replacement to deployed embedded skill SKILL.md files
        for skill_md in skills_dir.glob("*/SKILL.md"):
            content = skill_md.read_text(encoding="utf-8")
            replaced = _replace_cli_with_scripts(content)
            if replaced != content:
                atomic_write(skill_md, replaced)

        # Deploy commands to commands/ directory (OpenCode uses /command-name to invoke)
        n_commands = _deploy_commands(commands_dir, enabled_commands, profile=self.profile, config=cfg)

        # Apply CLI-to-script replacement to deployed command files
        for cmd_md in commands_dir.glob("*.md"):
            content = cmd_md.read_text(encoding="utf-8")
            replaced = _replace_cli_with_scripts(content)
            if replaced != content:
                atomic_write(cmd_md, replaced)

        n_rules = _deploy_rules(opencode_root, enabled_rules, profile=self.profile)
        self._deploy_agents_md_inline(opencode_root)

        providers = self._load_opencode_providers(opencode_root)
        if not providers:
            providers = self._load_opencode_providers(
                Path(self.profile.global_config_dir).expanduser()
            )
        command_models = cfg.get("command_models", {})
        self._update_global_opencode_json(
            opencode_root,
            command_models=command_models,
            providers=providers,
            enabled_commands=enabled_commands,
        )

        n_agents = _deploy_agents(agents_dir, enabled_agents, profile=self.profile)

        ci_config = cfg.get("ci", {})
        ci_provider = ci_config.get("provider", "none") if isinstance(ci_config, dict) else "none"
        project_root = Path.cwd()
        _deploy_ci(ci_provider, project_root, cfg)

        print(
            f"\n✅ OpenCode: {n_agents} Agents, {n_skills} Skills, "
            f"{n_commands} Commands → {opencode_root}"
        )

        if target is None:
            self._generate_project_agents_md()

        self._print_mcp_recommendations_opencode()

    # --- OpenCode-specific helpers ---

    @staticmethod
    def _generate_project_agents_md():
        """Generate project-level AGENTS.md if it does not exist (STORY-slim-008 R4)."""
        project_root = Path.cwd()
        if project_root.resolve() == Path.home().resolve():
            return
        agents_md_path = project_root / "AGENTS.md"
        if agents_md_path.exists():
            return
        project_name = project_root.name
        content = f"# {project_name}\n\n@./docs/product/context.md\noutput MUST use Chinese\n"
        atomic_write(agents_md_path, content)

    @staticmethod
    def _deploy_agents_md_inline(opencode_root):
        """Generate AGENTS.md with on-demand @reference index (STORY-slim-009 R3)."""
        ref_lines = []
        ondemand_descriptions = {
            "08-architecture-principles.md": "Architecture decisions, SOLID/DRY patterns",
            "04-routing-table.md": "Agent/command routing table",
            "06-mcp-integration.md": "MCP server integration guide",
            "05-workflow-conventions.md": "PDCA workflow conventions",
            "07-shared-protocols.md": "PDCA shared protocols (test mapping, visualize, context.md format)",
            "03-file-atlas.md": "File atlas (project file locations)",
        }
        for filename in sorted(prompts.RULES_ONDEMAND_FILES.values()):
            desc = ondemand_descriptions.get(filename, filename)
            ref_lines.append(f"- {desc}: @rules/{filename}")

        core_names = ", ".join(
            f.replace(".md", "") for f in sorted(prompts.RULES_CORE_FILES.values())
        )

        lines = [
            f"# PactKit Global Constitution (v{__version__} Modular)",
            "",
            f"Core rules ({core_names}) are always loaded via `instructions`.",
            "",
            "## On-Demand Rules",
            "",
            "CRITICAL: When you encounter a file reference below (e.g., @rules/xxx.md), "
            "use your Read tool to load it on a need-to-know basis. "
            "Do NOT preemptively load all references — use lazy loading based on actual need.",
            "",
            *ref_lines,
            "",
            "## Quick Reference",
            "",
            "- **Specs** (`docs/specs/`) are the source of truth",
            "- **Sprint Board**: `docs/product/sprint_board.md`",
            "- **Architecture**: `docs/architecture/graphs/`",
            "- **Commands**: Type `/` followed by command name (e.g., `/project-plan`)",
            "",
            "> **TIP**: Run `/project-init` to set up project governance and enable cross-session context.",
            "",
        ]
        atomic_write(opencode_root / "AGENTS.md", "\n".join(lines))

    @staticmethod
    def _deploy_opencode_json(opencode_root):
        """Generate opencode.json project configuration (STORY-071 R1/R2)."""
        config = {
            "$schema": "https://opencode.ai/config.json",
            "instructions": ["AGENTS.md", "docs/product/context.md"],
            "agent": {
                "build": {"model": "inherit"},
                "plan": {"model": "inherit"},
            },
            "permission": {
                "edit": "allow",
                "bash": {
                    "*": "allow",
                    "rm -rf /*": "deny",
                    "rm -rf /Users/*": "deny",
                    "rm -rf /System/*": "deny",
                    "sudo rm *": "deny",
                    "sudo mkfs *": "deny",
                    "curl * | sh": "deny",
                    "wget * | sh": "deny",
                },
                "read": {
                    "*": "allow",
                    "*.env": "deny",
                    "*.env.*": "deny",
                    "*.env.example": "allow",
                },
            },
            "mcp": {
                "context7": {
                    "type": "remote",
                    "url": "https://mcp.context7.com/mcp",
                },
            },
        }
        content = json.dumps(config, indent=2, ensure_ascii=False) + "\n"
        atomic_write(opencode_root / "opencode.json", content)

    @staticmethod
    def _resolve_opencode_model_id(short_name, providers):
        """Resolve a short model name to a full provider/model-id (STORY-073)."""
        if not short_name or not providers:
            return None
        keyword = short_name.lower()
        for provider_name, provider_data in providers.items():
            models = provider_data.get("models", {})
            for model_id in models:
                if keyword in model_id.lower():
                    return f"{provider_name}/{model_id}"
        return None

    @staticmethod
    def _load_opencode_providers(opencode_root):
        """Load provider config from opencode.json for model resolution."""
        json_path = opencode_root / "opencode.json"
        if json_path.is_file():
            try:
                data = json.loads(json_path.read_text(encoding="utf-8"))
                return data.get("provider", {})
            except (json.JSONDecodeError, OSError):
                pass
        return {}

    @staticmethod
    def _update_global_opencode_json(
        opencode_root, command_models=None, providers=None, enabled_commands=None
    ):
        """Update global opencode.json with instructions, command templates, and model routing."""
        json_path = opencode_root / "opencode.json"
        config = {}

        if json_path.is_file():
            try:
                config = json.loads(json_path.read_text(encoding="utf-8"))
            except (json.JSONDecodeError, OSError):
                config = {}

        config.setdefault("$schema", "https://opencode.ai/config.json")

        credential_path = f"rules/{CREDENTIAL_SAFETY_FILE}"
        existing = [
            i
            for i in config.get("instructions", [])
            if i != "rules/*.md" and not (i.startswith("rules/") and i != credential_path)
        ]
        if credential_path not in existing:
            existing.append(credential_path)
        config["instructions"] = existing

        # OpenCode auto-discovers commands from commands/*.md directory.
        # opencode.json "command" section requires BOTH "model" AND "template" fields.
        # Since we don't control template content (it's inline prompt text, not a file path),
        # we must NOT write model-only entries — they cause OpenCode validation errors.
        # Clean up any PactKit-managed command entries that lack template.
        cmd_config = config.get("command", {})
        for cmd_name in list(cmd_config):
            if cmd_name.startswith("project-") and "template" not in cmd_config[cmd_name]:
                del cmd_config[cmd_name]

        if cmd_config:
            config["command"] = cmd_config
        else:
            config.pop("command", None)

        content = json.dumps(config, indent=2, ensure_ascii=False) + "\n"
        atomic_write(json_path, content)

    @staticmethod
    def _print_mcp_recommendations_opencode():
        """Print MCP server recommendations for OpenCode deployment (STORY-071 R4)."""
        print("\n📦 MCP Server Configuration (add to opencode.json):")
        print()
        print("  Remote MCP (no install needed):")
        print('    "context7": { "type": "remote", "url": "https://mcp.context7.com/mcp" }')
        print()
        print("  Local MCP (requires npx):")
        print(
            '    "memory":     { "type": "local", "command": '
            '["npx", "-y", "@modelcontextprotocol/server-memory"] }'
        )
        print(
            '    "playwright":  { "type": "local", "command": '
            '["npx", "-y", "@playwright/mcp"] }'
        )
        print(
            '    "puppeteer":   { "type": "local", "command": '
            '["npx", "-y", "@anthropic/mcp-puppeteer"] }'
        )

    @staticmethod
    def _cleanup_command_skills(skills_dir):
        """Remove legacy command skills from skills/ directory.

        Previously, PDCA commands were deployed as skills/{name}/SKILL.md.
        Now they are in commands/{name}.md. Clean up the old entries.
        """
        for d in skills_dir.iterdir():
            if d.is_dir() and d.name.startswith("project-"):
                import shutil
                shutil.rmtree(d)


# --- Module-level helper functions ---

_VIZ_SCRIPT = "python3 ~/.config/opencode/skills/pactkit-visualize/scripts/visualize.py"
_BOARD_SCRIPT = "python3 ~/.config/opencode/skills/pactkit-board/scripts/board.py"
_SCAFFOLD_SCRIPT = "python3 ~/.config/opencode/skills/pactkit-scaffold/scripts/scaffold.py"

# CLI subcommands that map to skill scripts (order matters: longer patterns first)
_CLI_TO_SCRIPT = [
    # visualize variants
    ("Run `pactkit visualize --lazy`", f"Run `{_VIZ_SCRIPT}` (file, `--mode class`, `--mode call` if source changed)"),
    ("Run `pactkit visualize", f"Run `{_VIZ_SCRIPT}"),
    ("Run `visualize --focus", f"Run `{_VIZ_SCRIPT} --focus"),
    ("Run `visualize --mode", f"Run `{_VIZ_SCRIPT} --mode"),
    ("Run `visualize`", f"Run `{_VIZ_SCRIPT}`"),
    # board
    ("Run `python3 ~/.config/opencode/skills/pactkit-board/scripts/board.py", f"Run `{_BOARD_SCRIPT}"),
    # scaffold
    ("Run `python3 ~/.config/opencode/skills/pactkit-scaffold/scripts/scaffold.py", f"Run `{_SCAFFOLD_SCRIPT}"),
    # pactkit CLI → manual fallback hint
    ("Run `pactkit clean`", "Run language-specific cleanup (e.g., `find . -name '__pycache__' -exec rm -rf {} +` for Python)"),
]


def _replace_cli_with_scripts(content):
    """Replace pactkit CLI and bare visualize commands with direct OpenCode script paths."""
    for old, new in _CLI_TO_SCRIPT:
        content = content.replace(old, new)
    # Handle backtick-wrapped bare `visualize` with flags
    content = re.sub(
        r'`visualize (--(?:focus|mode|entry))',
        rf'`{_VIZ_SCRIPT} \1',
        content,
    )
    return content


# Auto-register when this module is imported
register_deployer("opencode", OpenCodeDeployer, force=True)
