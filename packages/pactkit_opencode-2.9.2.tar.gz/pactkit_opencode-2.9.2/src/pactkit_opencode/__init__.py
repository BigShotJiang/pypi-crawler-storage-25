"""PactKit adapter for OpenCode IDE.

Auto-registers OpenCodeDeployer via entry_points when imported.
"""

from pactkit_opencode.deployer import OpenCodeDeployer

__all__ = ["OpenCodeDeployer"]
