# Cos Comparison

[![Python 3.8+](https://img.shields.io/badge/python-3.8+-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

**Local similarity comparison for feature extraction – biologically inspired, zero‑training edge / pattern detection.**

## Core Idea

Information is produced by **local comparison** in raw data.  
This module implements the **center‑surround antagonism** mechanism from neuroscience, extracting edges, textures, and keypoints using only sliding window similarity.

The main formula (cosine‑modulated similarity):

$$ \text{cosmod} = \frac{2\,(A\cdot B)}{\|A\|^2 + \|B\|^2} $$

- Spurt for real AGI
- No training, no labels, no backpropagation
- Works on 1D, 2D, 3D, 4D data (audio, images, video, volumes)
- Supports passive (reflex) and active (template matching) modes
- Pure Python core + optional NumPy / C acceleration

## Installation

```bash
pip install cos-comparison
