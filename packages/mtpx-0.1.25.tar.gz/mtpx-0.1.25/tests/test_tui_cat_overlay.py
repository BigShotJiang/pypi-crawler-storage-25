import io
import os
import sys


sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from mtp.cli.tui_cat import CatEngine


class _TermSize:
    def __init__(self, columns, lines):
        self.columns = columns
        self.lines = lines


def test_response_mode_clears_overlay_from_top(monkeypatch):
    engine = CatEngine()
    engine.state = "response"
    region = engine._compute_region(80, 24)
    assert region is not None

    buffer = io.StringIO()
    monkeypatch.setattr("mtp.cli.tui_cat.sys.stdout", buffer)
    monkeypatch.setattr("mtp.cli.tui_cat.shutil.get_terminal_size", lambda: _TermSize(80, 24))
    monkeypatch.setattr(engine, "_render_scene", lambda pixels: None)
    monkeypatch.setattr(engine, "_render_sidebar", lambda *args: None)

    engine._draw_frame()

    output = buffer.getvalue()
    assert f"\033[1;{region['start_x']}H\033[K" in output
    assert f"\033[{region['bottom'] + 1};{region['start_x']}H\033[K" in output


def test_resize_clears_old_overlay_region(monkeypatch):
    engine = CatEngine()
    engine.state = "idle"

    sizes = iter([_TermSize(80, 24), _TermSize(100, 24)])
    buffer = io.StringIO()
    monkeypatch.setattr("mtp.cli.tui_cat.sys.stdout", buffer)
    monkeypatch.setattr("mtp.cli.tui_cat.shutil.get_terminal_size", lambda: next(sizes))
    monkeypatch.setattr(engine, "_render_scene", lambda pixels: None)
    monkeypatch.setattr(engine, "_render_sidebar", lambda *args: None)

    old_region = engine._compute_region(80, 24)
    new_region = engine._compute_region(100, 24)
    assert old_region is not None
    assert new_region is not None

    engine._draw_frame()
    buffer.seek(0)
    buffer.truncate(0)

    engine._draw_frame()

    output = buffer.getvalue()
    assert f"\033[1;{old_region['start_x']}H\033[K" in output
    assert f"\033[1;{new_region['start_x']}H\033[K" in output
