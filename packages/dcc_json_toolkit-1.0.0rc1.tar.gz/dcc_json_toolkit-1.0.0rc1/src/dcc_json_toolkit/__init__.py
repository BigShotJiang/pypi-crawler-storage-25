"""Package to support direct conversion among DCC and .json files."""

from .dcc_schema import DccSchema

__all__ = ["DccSchema"]
