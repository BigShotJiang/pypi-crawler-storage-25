"""Metadata of the package."""

__pkg_name__ = "DccJsonToolkit"
__version__ = "1.0.0-rc.1"
