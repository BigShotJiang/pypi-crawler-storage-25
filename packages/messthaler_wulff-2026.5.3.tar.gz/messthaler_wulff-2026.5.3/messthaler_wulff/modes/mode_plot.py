from argparse import ArgumentParser

import mydefaults
from matplotlib.pyplot import show

from messthaler_wulff.math.bravais import plot_bravais_points, ax_bravais, Bravais, plot_bravais_lines
from messthaler_wulff.parsing import crystals
from messthaler_wulff.parsing.graphs import GraphType


def lines(bravais: Bravais, crystal):
    crystal = set(crystal)
    lines = set()

    for point in crystal:
        for i in range(bravais.degree):
            n = bravais.neighbor(point, i)
            if n in crystal:
                lines.add((point, n))

    return frozenset(lines)


@mydefaults.sub_command
def plot(parser: ArgumentParser) -> mydefaults.MAGIC:
    GraphType.add_args(parser)
    parser.add_argument("mode")

    crystals.add_args(parser)
    parser.add_argument("-o", "--orthogonal", action="store_true")
    parser.add_argument("-a", "--axis", action="store_true")
    parser.add_argument("-n", "--node-color", default="black")
    parser.add_argument("-e", "--edge-color", default="black")
    parser.add_argument("--node-alpha", default=1.0, type=float)
    parser.add_argument("--edge-alpha", default=1.0, type=float)

    args = yield

    assert set(args.mode) <= set("plc")

    graph_type = GraphType.from_args(args)
    bravais = graph_type.bravais()
    crystal = crystals.from_args(args)
    ax = ax_bravais(bravais)
    ax.set_proj_type('ortho' if args.orthogonal else 'persp')

    if not args.axis:
        ax.axis("off")

    if "p" in args.mode:
        plot_bravais_points(bravais, crystal, ax, args.node_color, args.node_alpha)

    if "l" in args.mode:
        plot_bravais_lines(bravais, lines(bravais, crystal), ax, args.edge_color, args.edge_alpha)

    show()
