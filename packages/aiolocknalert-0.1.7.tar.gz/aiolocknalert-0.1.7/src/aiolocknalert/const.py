"""Constants for aiolocknalert."""

# ── HTTP bridge ───────────────────────────────────────────────────────────────
DEFAULT_API_PORT: int = 443
DEFAULT_TIMEOUT: int = 10

# ── MQTT config keys ──────────────────────────────────────────────────────────
# Same string values as homeassistant.const / the HA MQTT component so the HA
# integration can pass its config dict through without remapping keys.
CONF_BIRTH_MESSAGE = "birth_message"
CONF_BROKER = "broker"
CONF_CERTIFICATE = "certificate"
CONF_CLIENT_CERT = "client_cert"
CONF_CLIENT_ID = "client_id"
CONF_CLIENT_KEY = "client_key"
CONF_KEEPALIVE = "keepalive"
CONF_PASSWORD = "password"
CONF_PORT = "port"
CONF_PROTOCOL = "protocol"
CONF_TLS_INSECURE = "tls_insecure"
CONF_TRANSPORT = "transport"
CONF_USERNAME = "username"
CONF_WILL_MESSAGE = "will_message"
CONF_WS_HEADERS = "ws_headers"
CONF_WS_PATH = "ws_path"

# ── MQTT protocol versions ────────────────────────────────────────────────────
PROTOCOL_31 = "3.1"
PROTOCOL_311 = "3.1.1"
PROTOCOL_5 = "5"

# ── MQTT transport ────────────────────────────────────────────────────────────
TRANSPORT_TCP = "tcp"
TRANSPORT_WEBSOCKETS = "websockets"

# ── MQTT defaults ─────────────────────────────────────────────────────────────
DEFAULT_BIRTH: dict[str, str] = {}
DEFAULT_ENCODING = "utf-8"
DEFAULT_KEEPALIVE = 60
DEFAULT_PORT = 1883
DEFAULT_PROTOCOL = PROTOCOL_311
DEFAULT_QOS = 0
DEFAULT_TRANSPORT = TRANSPORT_TCP
DEFAULT_WILL: dict[str, str] = {}
DEFAULT_WS_HEADERS: dict[str, str] = {}
DEFAULT_WS_PATH = "/mqtt"

# ── Integration identity ──────────────────────────────────────────────────────
DOMAIN = "aiolocknalert"

# ── Dispatcher signal names ───────────────────────────────────────────────────
# Use these as the signal keys when calling async_dispatcher_send / connect
# in the HA integration.
MQTT_CONNECTION_STATE = f"{DOMAIN}_connection_state"
MQTT_PROCESSED_SUBSCRIPTIONS = f"{DOMAIN}_processed_subscriptions"
