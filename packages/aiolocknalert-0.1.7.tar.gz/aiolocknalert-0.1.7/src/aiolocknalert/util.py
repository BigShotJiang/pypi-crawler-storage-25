"""Utilities for aiolocknalert."""

import asyncio
import contextlib
from collections.abc import Callable, Coroutine, Generator, Iterable
from typing import Any, TypeVar

_T = TypeVar("_T")


class EnsureJobAfterCooldown:
    """Debounce a coroutine: run only after calls stop arriving for `timeout` seconds.

    Drop-in replacement for the HA helper of the same name — no HA dependency.
    """

    def __init__(
        self,
        timeout: float,
        job: Callable[[], Coroutine[Any, Any, None]],
    ) -> None:
        self._timeout = timeout
        self._job = job
        self._task: asyncio.Task[None] | None = None

    def set_timeout(self, timeout: float) -> None:
        self._timeout = timeout

    def async_schedule(self) -> None:
        if self._task:
            self._task.cancel()
        self._task = asyncio.ensure_future(self._run())

    async def _run(self) -> None:
        await asyncio.sleep(self._timeout)
        self._task = None
        await self._job()

    async def async_execute(self) -> None:
        await self.async_cleanup()
        await self._job()

    async def async_cleanup(self) -> None:
        if self._task:
            self._task.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await self._task
            self._task = None


def get_file_path(option: str, value: str | None) -> str | None:
    """Return the config value for a file-path option, or None if unset."""
    return value


def chunked_or_all(
    iterable: Iterable[_T], size: int
) -> Generator[list[_T], None, None]:
    """Yield successive non-overlapping chunks of at most `size` items."""
    chunk: list[_T] = []
    for item in iterable:
        chunk.append(item)
        if len(chunk) >= size:
            yield chunk
            chunk = []
    if chunk:
        yield chunk
