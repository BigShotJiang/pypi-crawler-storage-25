"""Data models for aiolocknalert MQTT."""

from collections.abc import Callable, Coroutine
from dataclasses import dataclass
from typing import Any

type PublishPayloadType = str | bytes | bytearray | int | float | None
type SubscribePayloadType = str | bytes | bytearray
type MessageCallbackType = Callable[["ReceiveMessage"], Coroutine[Any, Any, None] | None]


@dataclass(slots=True, frozen=True)
class PublishMessage:
    """Outgoing MQTT message."""

    topic: str
    payload: PublishPayloadType
    qos: int
    retain: bool


@dataclass(slots=True, frozen=True)
class ReceiveMessage:
    """Incoming MQTT message delivered to a subscription callback."""

    topic: str
    payload: SubscribePayloadType
    qos: int
    retain: bool
    subscribed_topic: str
    timestamp: float
