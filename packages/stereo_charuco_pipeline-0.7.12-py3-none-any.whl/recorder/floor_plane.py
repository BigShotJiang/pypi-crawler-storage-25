"""
Floor plane estimation from stereo floor recording.

Builds scene_model.toml that encodes the floor plane equation in the
calibration world frame. This enables ray-floor intersection to recover
accurate metric depth for standing/walking persons at 1-4m range,
bypassing the 6cm baseline triangulation limit.

Usage:
  from recorder.floor_plane import build_floor_plane, load_scene_model
  ok = build_floor_plane(video1, video2, camera_array_toml, output_toml)
  plane = load_scene_model(output_toml)
"""
from __future__ import annotations

import logging
import math
from pathlib import Path
from typing import Optional

import cv2
import numpy as np

logger = logging.getLogger(__name__)


# ── Camera parameter loading ────────────────────────────────────────────────

def _parse_toml_cameras(path: Path) -> dict:
  """Parse camera_array.toml without tomli/tomllib dependency."""
  cameras: dict = {}
  cur_port: Optional[int] = None
  cur: dict = {}

  for line in path.read_text(encoding="utf-8").splitlines():
    line = line.strip()
    if line.startswith("[cameras."):
      if cur_port is not None:
        cameras[cur_port] = cur
      cur_port = int(line.strip("[]").split(".")[1])
      cur = {}
    elif cur_port is not None and "=" in line:
      k, _, v = line.partition("=")
      k, v = k.strip(), v.strip()
      if v.startswith("[["):
        try:
          rows = []
          for part in v[2:-2].split("], ["):
            rows.append([float(x.strip()) for x in part.split(",")])
          cur[k] = rows
        except Exception:
          pass
      elif v.startswith("["):
        try:
          cur[k] = [float(x.strip()) for x in v[1:-1].split(",")]
        except Exception:
          pass
      else:
        try:
          cur[k] = float(v)
        except Exception:
          cur[k] = v.strip('"')

  if cur_port is not None:
    cameras[cur_port] = cur

  return cameras


def load_camera_array(toml_path: Path) -> dict[int, dict]:
  """
  Load camera intrinsics and extrinsics from camera_array.toml.

  Returns dict port → {K, D, R, t, C, P} where:
    K  = intrinsic matrix (3x3)
    D  = distortion coefficients (5,)
    R  = world-to-camera rotation (3x3)
    t  = world-to-camera translation (3,)
    C  = camera centre in world frame (3,)
    P  = projection matrix K @ [R|t] (3x4)
  """
  raw = _parse_toml_cameras(toml_path)
  result: dict[int, dict] = {}

  for port, cam in raw.items():
    K = np.array(cam["matrix"], dtype=np.float64)
    D = np.array(cam.get("distortions", [0, 0, 0, 0, 0]), dtype=np.float64)
    rvec = np.array(cam["rotation"], dtype=np.float64)
    R, _ = cv2.Rodrigues(rvec)
    # camera_array.toml stores the camera centre in world frame (C)
    # world-to-camera translation: t = -R @ C
    C = np.array(cam["translation"], dtype=np.float64)
    t = -(R @ C)
    Rt = np.hstack([R, t.reshape(3, 1)])
    P = K @ Rt
    result[port] = {"K": K, "D": D, "R": R, "t": t, "C": C, "P": P}

  return result


# ── ChArUco corner detection ────────────────────────────────────────────────

def _enhance_frame(frame: np.ndarray) -> np.ndarray:
  """Apply CLAHE contrast enhancement (helps in dark/low-contrast environments)."""
  lab = cv2.cvtColor(frame, cv2.COLOR_BGR2LAB)
  l, a, b = cv2.split(lab)
  clahe = cv2.createCLAHE(clipLimit=3.0, tileGridSize=(8, 8))
  l = clahe.apply(l)
  return cv2.cvtColor(cv2.merge([l, a, b]), cv2.COLOR_LAB2BGR)


def _detect_aruco_centres(
  frame: np.ndarray,
  dict_name: str = "DICT_4X4_100",
  min_markers: int = 4,
) -> tuple[Optional[np.ndarray], Optional[np.ndarray]]:
  """
  Detect ArUco marker centres in frame.
  Applies CLAHE enhancement and relaxed detection parameters for robustness
  in dark or distant-board scenarios.

  Returns (centres Nx2, ids N) or (None, None) if fewer than min_markers detected.
  """
  aruco_dict = cv2.aruco.getPredefinedDictionary(
    getattr(cv2.aruco, dict_name, cv2.aruco.DICT_4X4_100)
  )
  params = cv2.aruco.DetectorParameters()
  # Relaxed parameters for small/distant markers in variable lighting
  params.adaptiveThreshWinSizeMin = 3
  params.adaptiveThreshWinSizeMax = 53
  params.adaptiveThreshWinSizeStep = 10
  params.minMarkerPerimeterRate = 0.01
  params.cornerRefinementMethod = cv2.aruco.CORNER_REFINE_SUBPIX

  # Try original frame first, fall back to CLAHE-enhanced
  corners, ids, _ = cv2.aruco.detectMarkers(frame, aruco_dict, parameters=params)
  if ids is None or len(ids) < min_markers:
    enhanced = _enhance_frame(frame)
    corners, ids, _ = cv2.aruco.detectMarkers(enhanced, aruco_dict, parameters=params)

  if ids is None or len(ids) < min_markers:
    return None, None

  centres = np.array(
    [c[0].mean(axis=0) for c in corners], dtype=np.float64
  )
  return centres, ids.flatten()


# ── Stereo triangulation ────────────────────────────────────────────────────

def triangulate_matched(
  pts1: np.ndarray,  # Nx2
  pts2: np.ndarray,  # Nx2
  cam1: dict,
  cam2: dict,
) -> np.ndarray:
  """
  Triangulate matched 2D points from two cameras.
  Points are undistorted before triangulation.

  Returns 3D points in world frame, shape Nx3.
  """
  pts1_u = cv2.undistortPoints(
    pts1.reshape(-1, 1, 2), cam1["K"], cam1["D"], P=cam1["K"]
  ).reshape(-1, 2)
  pts2_u = cv2.undistortPoints(
    pts2.reshape(-1, 1, 2), cam2["K"], cam2["D"], P=cam2["K"]
  ).reshape(-1, 2)

  pts4d = cv2.triangulatePoints(cam1["P"], cam2["P"], pts1_u.T, pts2_u.T)
  pts3d = (pts4d[:3] / pts4d[3]).T  # Nx3
  return pts3d


# ── Plane fitting ───────────────────────────────────────────────────────────

def fit_plane_svd(pts: np.ndarray) -> tuple[np.ndarray, float, float]:
  """
  Fit a plane to 3D points using SVD (least-squares).

  Returns (normal_unit, offset_d, rmse_m) where the plane is
    normal . X + d = 0
  """
  centroid = pts.mean(axis=0)
  _, _, Vt = np.linalg.svd(pts - centroid)
  normal = Vt[-1]          # row of smallest singular value
  normal /= np.linalg.norm(normal)
  d = -float(normal @ centroid)
  residuals = pts @ normal + d
  rmse = float(math.sqrt(np.mean(residuals ** 2)))
  return normal, d, rmse


# ── Main builder ────────────────────────────────────────────────────────────

def build_floor_plane(
  video_path_1: Path,
  video_path_2: Path,
  camera_array_toml: Path,
  output_toml: Path,
  dict_name: str = "DICT_4X4_100",
  sample_every: int = 3,
  on_progress=None,
) -> bool:
  """
  Build floor plane model from stereo floor recording.

  The charuco board must be placed flat on the floor so every detected
  corner is a floor point. At least 4 matched markers per frame are
  required for triangulation.

  Args:
    video_path_1:      port_1.mp4 (floor recording)
    video_path_2:      port_2.mp4 (floor recording)
    camera_array_toml: path to camera_array.toml from stereo calibration
    output_toml:       where to write scene_model.toml
    dict_name:         ArUco dictionary (must match the charuco board)
    sample_every:      process every Nth frame pair
    on_progress:       optional callback(str) for progress messages

  Returns True on success.
  """
  def _log(msg: str):
    logger.info(msg)
    if on_progress:
      on_progress(msg)

  _log("Loading camera array parameters...")
  try:
    cameras = load_camera_array(camera_array_toml)
  except Exception as e:
    _log(f"[ERROR] Failed to load camera_array.toml: {e}")
    return False

  if len(cameras) < 2:
    _log(f"[ERROR] Need 2 cameras, found {len(cameras)}")
    return False

  ports = sorted(cameras.keys())
  port1, port2 = ports[0], ports[1]
  cam1, cam2 = cameras[port1], cameras[port2]

  cap1 = cv2.VideoCapture(str(video_path_1))
  cap2 = cv2.VideoCapture(str(video_path_2))

  if not cap1.isOpened():
    _log(f"[ERROR] Cannot open video: {video_path_1}")
    return False
  if not cap2.isOpened():
    _log(f"[ERROR] Cannot open video: {video_path_2}")
    cap1.release()
    return False

  floor_pts: list[np.ndarray] = []
  n_frames = 0
  n_detected = 0

  _log("Detecting ArUco markers and triangulating floor points...")

  while True:
    ret1, frame1 = cap1.read()
    ret2, frame2 = cap2.read()
    if not ret1 or not ret2:
      break

    n_frames += 1
    if n_frames % sample_every != 0:
      continue

    centres1, ids1 = _detect_aruco_centres(frame1, dict_name, min_markers=3)
    centres2, ids2 = _detect_aruco_centres(frame2, dict_name, min_markers=3)

    if centres1 is None or ids1 is None or centres2 is None or ids2 is None:
      continue

    # Match by marker ID
    id_set1 = set(ids1.tolist())
    id_set2 = set(ids2.tolist())
    common = sorted(id_set1 & id_set2)

    if len(common) < 3:
      continue

    m1 = np.array(
      [centres1[np.where(ids1 == mid)[0][0]] for mid in common]
    )
    m2 = np.array(
      [centres2[np.where(ids2 == mid)[0][0]] for mid in common]
    )

    pts3d = triangulate_matched(m1, m2, cam1, cam2)

    # Keep only points in front of cameras within a reasonable range
    for pt in pts3d:
      z_in_cam1 = float(cam1["R"][2] @ pt + cam1["t"][2])
      if 0.1 < z_in_cam1 < 8.0:
        floor_pts.append(pt)

    n_detected += 1
    if n_frames % 30 == 0:
      _log(f"  {n_frames} frames scanned, {n_detected} with detections, "
           f"{len(floor_pts)} floor points")

  cap1.release()
  cap2.release()

  if len(floor_pts) < 9:
    _log(f"[ERROR] Only {len(floor_pts)} floor points (need ≥9). "
         "Place board flat on floor within 1m of cameras, ensure both cameras see it.")
    return False

  _log(f"Collected {len(floor_pts)} floor points. Fitting plane...")

  pts = np.array(floor_pts, dtype=np.float64)
  normal, d, rmse = fit_plane_svd(pts)
  centroid = pts.mean(axis=0)

  # Orient normal toward camera 1 (normal should point upward toward cameras)
  if float(normal @ (cam1["C"] - centroid)) < 0:
    normal = -normal
    d = -d

  quality = (
    "excellent" if rmse < 0.005
    else "good" if rmse < 0.015
    else "ok" if rmse < 0.03
    else "poor"
  )
  comment = {
    "excellent": "Floor plane very well constrained.",
    "good":      "Floor plane well constrained.",
    "ok":        "Usable. For better accuracy, place board flat and re-record.",
    "poor":      "High residual. Board may not have been flat. Re-record.",
  }[quality]

  _log(f"Floor plane: normal=[{normal[0]:.4f}, {normal[1]:.4f}, {normal[2]:.4f}]  "
       f"d={d:.4f}m  RMSE={rmse*100:.1f}cm  quality={quality}")

  # Write scene_model.toml
  output_toml.parent.mkdir(parents=True, exist_ok=True)
  content = f"""# Scene model — floor plane for depth-extended 3D reconstruction
# Generated by floor_plane.build_floor_plane()
#
# Plane equation in stereo world frame:
#   normal[0]*x + normal[1]*y + normal[2]*z + offset = 0
#
# Usage: ray from camera origin through 2D ankle pixel,
#        intersect with this plane → metric 3D ankle position.

[floor_plane]
normal = [{normal[0]:.10f}, {normal[1]:.10f}, {normal[2]:.10f}]
offset = {d:.10f}
centroid = [{centroid[0]:.6f}, {centroid[1]:.6f}, {centroid[2]:.6f}]
rmse_m = {rmse:.6f}
n_points = {len(floor_pts)}
n_frames_with_detection = {n_detected}
camera_array_source = "{camera_array_toml.name}"
quality = "{quality}"
comment = "{comment}"
"""
  output_toml.write_text(content, encoding="utf-8")
  _log(f"Saved → {output_toml}")
  return True


# ── Scene model loader ──────────────────────────────────────────────────────

def load_scene_model(toml_path: Path) -> dict:
  """
  Load scene_model.toml. Returns dict with:
    normal  : np.ndarray (3,)
    offset  : float
    quality : str
  """
  data: dict = {}
  for line in toml_path.read_text(encoding="utf-8").splitlines():
    line = line.strip()
    if "=" in line and not line.startswith("#") and not line.startswith("["):
      k, _, v = line.partition("=")
      k, v = k.strip(), v.strip().strip('"')
      if v.startswith("["):
        try:
          data[k] = [float(x.strip()) for x in v[1:-1].split(",")]
        except Exception:
          pass
      else:
        try:
          data[k] = float(v)
        except Exception:
          data[k] = v

  floor = {
    "normal": np.array(data.get("normal", [0, -1, 0]), dtype=np.float64),
    "offset": float(data.get("offset", 0.0)),
    "quality": str(data.get("quality", "unknown")),
    "rmse_m": float(data.get("rmse_m", -1.0)),
  }
  return floor


# ── Ray-floor intersection ──────────────────────────────────────────────────

def ray_floor_intersection(
  pt2d: np.ndarray,      # (2,) pixel coordinate in camera
  cam: dict,             # camera dict from load_camera_array()
  floor_plane: dict,     # from load_scene_model()
) -> Optional[np.ndarray]:
  """
  Project 2D pixel through camera and intersect with floor plane.

  Returns 3D point in world frame, or None if ray is parallel to floor.
  """
  # Undistort pixel → normalised ray direction in camera frame
  pt_u = cv2.undistortPoints(
    pt2d.reshape(1, 1, 2).astype(np.float64),
    cam["K"], cam["D"],
  ).reshape(2)
  # Ray in camera frame: direction (x_n, y_n, 1)
  ray_cam = np.array([pt_u[0], pt_u[1], 1.0], dtype=np.float64)
  ray_cam /= np.linalg.norm(ray_cam)

  # Transform ray direction to world frame
  # world = R^T @ cam  (R is world-to-cam rotation)
  R = cam["R"]
  ray_world = R.T @ ray_cam
  ray_world /= np.linalg.norm(ray_world)

  # Camera centre in world frame
  origin = cam["C"]

  # Intersect: origin + λ * ray_world with plane normal·X + d = 0
  n = floor_plane["normal"]
  d = floor_plane["offset"]

  denom = float(n @ ray_world)
  if abs(denom) < 1e-8:
    return None  # Ray parallel to floor

  lam = -float(n @ origin + d) / denom
  if lam < 0:
    return None  # Intersection behind camera

  return origin + lam * ray_world
