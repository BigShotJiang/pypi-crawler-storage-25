[![Build status](https://github.com/P2GX/stratiphy/workflows/CI/badge.svg)](https://github.com/P2GX/stratiphy/actions/workflows/python_ci.yml)
[![GitHub release](https://img.shields.io/github/release/P2GX/stratiphy.svg)](https://github.com/P2GX/stratiphy/releases)
![PyPi downloads](https://img.shields.io/pypi/dm/stratiphy.svg?label=Pypi%20downloads)
![PyPI - Python Version](https://img.shields.io/pypi/pyversions/stratiphy)

# Stratiphy

A Python package for phenotype-driven clustering of cohorts for discovery of novel disease subgroups.

See our documentation for the [setup](https://p2gx.github.io/stratiphy/stable/setup.html) instructions,
a [tutorial](https://p2gx.github.io/stratiphy/stable/tutorial.html) with an end-to-end genotype-phenotype association analysis,
and a comprehensive [user guide](https://p2gx.github.io/stratiphy/stable/user-guide/index.html) with everything else.

The documentation comes in two flavors:

- [Stable documentation](https://p2gx.github.io/stratiphy/stable/) (last release on `main` branch)
- [Latest documentation](https://p2gx.github.io/stratiphy/latest) (bleeding edge, latest commit on `development` branch)
