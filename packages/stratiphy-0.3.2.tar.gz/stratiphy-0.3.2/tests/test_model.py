import typing

import pytest

from stratiphy.model import SampleLabels


class TestSampleLabels:
    @pytest.mark.parametrize(
        "left_label, left_meta, right_label, right_meta, is_lt, is_eq, is_gt",
        [
            # Left     Right        L<R    L=E   L>R
            ("B", "A", "B", "B", True, False, False),
            ("B", "B", "B", "B", False, True, False),
            ("B", "C", "B", "B", False, False, True),
            ("B", None, "A", None, False, False, True),
            ("B", None, "B", None, False, True, False),
            ("B", None, "C", None, True, False, False),
            ("B", None, "B", "A", True, False, False),
        ],
    )
    def test_comparison(
        self,
        left_label: str,
        left_meta: typing.Optional[str],
        right_label: str,
        right_meta: typing.Optional[str],
        is_lt: bool,
        is_eq: bool,
        is_gt: bool,
    ):
        left = SampleLabels(label=left_label, meta_label=left_meta)
        right = SampleLabels(label=right_label, meta_label=right_meta)

        assert (left < right) == is_lt
        assert (left == right) == is_eq
        assert (right == left) == is_eq
        assert (left > right) == is_gt
