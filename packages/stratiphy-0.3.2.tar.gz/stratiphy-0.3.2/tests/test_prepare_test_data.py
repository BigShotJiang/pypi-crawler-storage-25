import json
import pathlib
import typing

import hpotk
import pytest

from stratiphy.config import configure_workflow
from stratiphy.io import StratiphyJSONEncoder
from stratiphy.model import Sample


@pytest.mark.skip("Run manually only on demand")
def test_run_col3a1(
    col3a1_samples: typing.Sequence[Sample],
    fpath_col3a1_results_json: str,
    fpath_col3a1_results_protobuf: str,
):
    """
    Run to generate the real-life result files for the *COL3A1* cohort.
    The results serialized into the provided locations and then used as fixtures in the test suite.

    Assumes existence of reasonably recent resources in the `data` subfolder
    of the top-level repo folder (not tracked by Git).
    """

    fpath_data = pathlib.Path("data")
    fpath_hpo = fpath_data.joinpath("hp.json")
    hpo = hpotk.load_minimal_ontology(str(fpath_hpo))
    workflow = configure_workflow(
        hpo=hpo,
        rand_cohorts=100,
    )

    result = workflow.run(
        samples=col3a1_samples,
        k_clusters=(2, 3, 4),
    )

    result.to_protobuf(fpath_col3a1_results_protobuf)
    with open(fpath_col3a1_results_json, "w") as fh:
        json.dump(
            result,
            fh,
            cls=StratiphyJSONEncoder,
            indent=2,
        )
