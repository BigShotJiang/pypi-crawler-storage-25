import typing
from json import JSONDecoder, JSONEncoder

import hpotk
import numpy as np

from stratiphy.analysis.explain import TermAssociation
from stratiphy.analysis.gap import GapValues
from stratiphy.analysis.split import SplitCheckResult
from stratiphy.model import PhenotypicFeature, Sample, SampleLabels
from stratiphy.workflow import ClusteringWorkflowResult, ClusteringWorkflowMetadata

# Fields of consensus clustering workflow result.
_CCWR_FIELDS = (
    "affinityMatrix",
    "clusterLabels",
    "sortOrder",
    "gapValues",
    "splitCheck",
    "termAssociations",
    "metadata",
)

_TAS_FIELDS = (
    "termId",
    "counts",
    "pval",
    "correctedPval",
)


class StratiphyJSONEncoder(JSONEncoder):
    """
    `StratiphyJSONEncoder` helps to encode stratiphy types into a JSON message.

    The encoder is supposed to be used along with Python's `json` module via the `cls` parameter of :func:`json.dump`
    or :func:`json.dumps`.
    """

    def default(self, o):
        if isinstance(o, ClusteringWorkflowResult):
            return {
                "affinityMatrix": o.affinity_matrix,
                "clusterLabels": o.cluster_labels,
                "sortOrder": o.sort_order,
                "gapValues": o.gap_data,
                "splitCheck": o.split_check,
                "termAssociations": o.term_associations,
                "metadata": o.metadata,
            }
        elif isinstance(o, ClusteringWorkflowMetadata):
            return {
                "stratiphyVersion": o.stratiphy_version,
                "hpoVersion": o.hpo_version,
            }
        elif isinstance(o, GapValues):
            return {
                "logWkData": o.log_wk_data,
                "logWkRand": o.log_wk_rand,
            }
        elif isinstance(o, SplitCheckResult):
            return {
                "shouldSplit": o.should_split,
                "splitProba": o.split_proba,
            }
        elif isinstance(o, TermAssociation):
            return {
                "termId": o.term_id.value,
                "counts": o.counts,
                "pval": o.pval,
                "correctedPval": o.corrected_pval,
            }
        elif isinstance(o, np.ndarray):
            return o.tolist()

        elif isinstance(o, Sample):
            return {
                "labels": o.labels,
                "phenotypicFeatures": o.phenotypic_features,
            }
        elif isinstance(o, PhenotypicFeature):
            return {
                "identifier": o.identifier.value,
                "isPresent": o.is_present,
            }
        elif isinstance(o, SampleLabels):
            return {
                "label": o.label,
                "metaLabel": o.meta_label,
            }
        else:
            return super().default(o)


class StratiphyJSONDecoder(JSONDecoder):
    """
    `StratiphyJSONDecoder` helps to decode stratiphy types from a JSON message.

    The decoder is supposed to be used along with Python's `json` module via the `cls` parameter of :func:`json.load`
    or :func:`json.loads`.
    """

    def __init__(
        self,
        *args: typing.Any,
        **kwargs: typing.Any,
    ):
        super().__init__(
            *args,
            object_hook=StratiphyJSONDecoder.stratiphy_object_hook,
            **kwargs,
        )

    @staticmethod
    def stratiphy_object_hook(obj: typing.Dict[typing.Any, typing.Any]) -> typing.Any:
        if all(attr in obj.keys() for attr in _CCWR_FIELDS):
            return ClusteringWorkflowResult(
                affinity_matrix=obj["affinityMatrix"],
                cluster_labels=obj["clusterLabels"],
                sort_order=obj["sortOrder"],
                gap_values=obj["gapValues"],
                split_check=obj["splitCheck"],
                term_associations=obj["termAssociations"],
                metadata=obj["metadata"],
            )
        elif all(attr in obj.keys() for attr in ("stratiphyVersion", "hpoVersion")):
            return ClusteringWorkflowMetadata(
                stratiphy_version=obj["stratiphyVersion"],
                hpo_version=obj["hpoVersion"],
            )
        elif all(attr in obj.keys() for attr in ("logWkData", "logWkRand")):
            return GapValues(
                log_wk_data={int(k): data for k, data in obj["logWkData"].items()},
                log_wk_rand={int(k): data for k, data in obj["logWkRand"].items()},
            )
        elif all(attr in obj.keys() for attr in ("shouldSplit", "splitProba")):
            return SplitCheckResult(
                should_split=obj["shouldSplit"],
                split_proba=obj["splitProba"],
            )
        elif all(attr in obj.keys() for attr in _TAS_FIELDS):
            return TermAssociation(
                term_id=hpotk.TermId.from_curie(obj["termId"]),
                counts={int(k): v for k, v in obj["counts"].items()},
                pval=obj["pval"],
                corrected_pval=obj["correctedPval"],
            )
        elif all(attr in obj.keys() for attr in ("labels", "phenotypicFeatures")):
            return Sample.from_raw_parts(
                labels=obj["labels"],
                phenotypic_features=obj["phenotypicFeatures"],
            )
        elif all(attr in obj.keys() for attr in ("identifier", "isPresent")):
            return PhenotypicFeature.from_values(
                identifier=obj["identifier"],
                is_present=obj["isPresent"],
            )
        elif all(attr in obj.keys() for attr in ("label", "metaLabel")):
            return SampleLabels(
                label=obj["label"],
                meta_label=obj["metaLabel"],
            )
        else:
            return obj
