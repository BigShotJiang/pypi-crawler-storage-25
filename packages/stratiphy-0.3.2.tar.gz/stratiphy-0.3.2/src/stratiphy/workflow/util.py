import math
import typing

import numpy as np
from scipy.cluster.hierarchy import leaves_list, linkage


def compute_sort_order(
    a: np.ndarray,
    is_distance=False,
    method: typing.Literal["single", "complete", "average", "weighted", "centroid", "median"] = "average",
) -> np.ndarray:
    """
    Compute the optimal ordering of the rows/columns of a similarity/distance matrix
    for placing most similar entries together.

    .. note::
      We use SciPy hierarchical clustering to compute the sort order.


    :param a: a Numpy array with shape `(n, n)` with similarities or distances between `n` samples.
    :param is_distance: a flag to indicate if the entries correspond to similarities or distances.
    :param method: the linkage method to use for hierarchical clustering. See documentation of
      :func:`scipy.cluster.hierarchy.linkage` for the supported method values.
    """
    if not isinstance(a, np.ndarray):
        raise ValueError(f"`a` must be a square Numpy array but was {type(a)}")
    if len(a.shape) != 2:
        raise ValueError(f"`a` must be a square Numpy array but the provided array had {len(a.shape)} dimensions")
    if a.shape[0] != a.shape[1]:
        raise ValueError(f"`a` must be a square Numpy array but the provided array had shape={a.shape} (not square)")

    # Let's convert the similarity matrix into the condensed distance matrix that Scipy needs.
    if is_distance:
        dm = a
    else:
        dm = np.max(a) - a
    condensed_dm = dm[np.triu_indices(n=len(dm), k=1)]

    # Compute the linkage matrix,
    Z = linkage(condensed_dm, method=method, optimal_ordering=True)
    # and return the order of the dendrogram leaves.
    return leaves_list(Z)


def refine_cluster_ids(
    cluster_ids: typing.Mapping[int, np.ndarray],
) -> typing.Mapping[int, np.ndarray]:
    # Precondition: `cluster_ids` must meet all typical cluster id requirements
    # The first cluster id is `0` and the following values grow in increments of one.
    if len(cluster_ids) <= 1:
        # No work to be done
        return cluster_ids

    ks = sorted(cluster_ids)
    processed = {
        ks[0]: cluster_ids[ks[0]],
    }
    for k in ks[1:]:
        reference = processed[k - 1]
        current = cluster_ids[k]

        # Compute the reassignment dictionary
        reassignment = {}
        for cid in np.argsort(np.bincount(reference))[::-1]:
            # We iterate over cluster IDs, starting from the most-frequently occurring cid.
            # Then we find `best_match`, the most-frequently occurring `cid` in the `current` identifiers
            # that has not already been claimed by another cluster ID (hence the inner argsort).
            bincount_candidate = np.bincount(current[reference == cid])
            for best_match in np.argsort(bincount_candidate)[::-1]:
                if best_match not in reassignment:
                    reassignment[best_match] = cid
                    break

        # Add random reassignment to the missing values
        current_uq = set(current)
        for key, val in zip(
            current_uq.difference(reassignment),
            current_uq.difference(reassignment.values()),
        ):
            reassignment[key] = val

        # Apply the reassignment
        reassigned = np.empty(
            shape=current.shape,
            dtype=int,
        )
        for old, new in reassignment.items():
            reassigned[current == old] = new
        processed[k] = reassigned

    return processed


def merge_labels(
    a: np.ndarray,
    b: np.ndarray,
) -> np.ndarray:
    assert a.shape == b.shape
    rb = np.copy(b)

    nuql = len(np.unique(a))
    n = len(np.unique(b)) - nuql
    assert n >= 0

    ai, _ = _make_idxs(a)

    for _ in range(n):
        bi, ib = _make_idxs(rb)
        c = np.zeros(
            shape=(nuql, len(np.unique(rb))),
            dtype=int,
        )
        for av, bv in zip(a, rb):
            c[ai[int(av)], bi[int(bv)]] += 1
        tom = np.argmax(
            np.sum(
                c,
                axis=1,
            )
        )
        ca, cb = np.argsort(c[tom])[-2:]
        rb[rb == ib[int(cb)]] = ib[int(ca)]

    return rb


def _make_idxs(
    a: np.ndarray,
) -> typing.Tuple[
    typing.Mapping[int, int],
    typing.Mapping[int, int],
]:
    d, D = {}, {}
    i = 0
    for v in np.unique(a):
        d[int(v)] = i
        D[i] = int(v)
        i += 1
    return d, D


def compute_dimension(
    n: int,
) -> int:
    """
    Compute the dimension of a dense affinity matrix given length of its condensed matrix.
    """
    if n < 0:
        return -1

    val = ((math.sqrt(1 + 8 * n)) - 1) / 2
    dim = int(val)
    return dim if math.isclose(val, dim) else -1


def from_dense_to_condensed(
    a: np.ndarray,
):
    """
    Convert the dense matrix into a condensed form.
    """
    n = len(a)
    return a[np.triu_indices(n=n)]


def from_condensed_to_dense(
    a: np.ndarray,
    out: typing.Optional[np.ndarray] = None,
) -> np.ndarray:
    """
    Convert condensed affinity matrix (upper-right triangle) to a dense matrix.

    Write the matrix into `out`, if provided.

    :param a: condensed affinity matrix.
    :param out: the matrix to write into or `None` if a new matrix should be allocated.
    :raises ValueError: if `a` has invalid length
    """
    dim = compute_dimension(len(a))
    if dim >= 0:
        if out is None:
            t = np.zeros(
                shape=(dim, dim),
                dtype=a.dtype,
            )
        else:
            if out.ndim != 2 or out.shape != (dim, dim):
                raise ValueError(f"Cannot write a ({dim}, {dim}) matrix into `out` with shape {out.shape}")
            t = out

        i = 0
        for r in range(dim):
            for c in range(r, dim):
                t[r, c] = a[i]
                if r != c:
                    t[c, r] = t[r, c]
                i += 1
        return t
    else:
        raise ValueError(f"A matrix with shape {a.shape} is not a valid condensed matrix")
