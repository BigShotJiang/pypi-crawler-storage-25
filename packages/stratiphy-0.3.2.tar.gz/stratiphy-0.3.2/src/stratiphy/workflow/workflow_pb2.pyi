from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Iterable as _Iterable, Mapping as _Mapping, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class ClusteringWorkflowResult(_message.Message):
    __slots__ = ("affinity_matrix", "cluster_labels", "sort_order", "gap_values", "split_check", "term_associations", "metadata")
    class ClusterLabels(_message.Message):
        __slots__ = ("k", "labels")
        K_FIELD_NUMBER: _ClassVar[int]
        LABELS_FIELD_NUMBER: _ClassVar[int]
        k: int
        labels: _containers.RepeatedScalarFieldContainer[int]
        def __init__(self, k: _Optional[int] = ..., labels: _Optional[_Iterable[int]] = ...) -> None: ...
    class TermAssociations(_message.Message):
        __slots__ = ("k", "associations")
        K_FIELD_NUMBER: _ClassVar[int]
        ASSOCIATIONS_FIELD_NUMBER: _ClassVar[int]
        k: int
        associations: _containers.RepeatedCompositeFieldContainer[TermAssociation]
        def __init__(self, k: _Optional[int] = ..., associations: _Optional[_Iterable[_Union[TermAssociation, _Mapping]]] = ...) -> None: ...
    AFFINITY_MATRIX_FIELD_NUMBER: _ClassVar[int]
    CLUSTER_LABELS_FIELD_NUMBER: _ClassVar[int]
    SORT_ORDER_FIELD_NUMBER: _ClassVar[int]
    GAP_VALUES_FIELD_NUMBER: _ClassVar[int]
    SPLIT_CHECK_FIELD_NUMBER: _ClassVar[int]
    TERM_ASSOCIATIONS_FIELD_NUMBER: _ClassVar[int]
    METADATA_FIELD_NUMBER: _ClassVar[int]
    affinity_matrix: _containers.RepeatedScalarFieldContainer[float]
    cluster_labels: _containers.RepeatedCompositeFieldContainer[ClusteringWorkflowResult.ClusterLabels]
    sort_order: _containers.RepeatedScalarFieldContainer[int]
    gap_values: GapValues
    split_check: SplitCheck
    term_associations: _containers.RepeatedCompositeFieldContainer[ClusteringWorkflowResult.TermAssociations]
    metadata: ClusteringWorkflowMetadata
    def __init__(self, affinity_matrix: _Optional[_Iterable[float]] = ..., cluster_labels: _Optional[_Iterable[_Union[ClusteringWorkflowResult.ClusterLabels, _Mapping]]] = ..., sort_order: _Optional[_Iterable[int]] = ..., gap_values: _Optional[_Union[GapValues, _Mapping]] = ..., split_check: _Optional[_Union[SplitCheck, _Mapping]] = ..., term_associations: _Optional[_Iterable[_Union[ClusteringWorkflowResult.TermAssociations, _Mapping]]] = ..., metadata: _Optional[_Union[ClusteringWorkflowMetadata, _Mapping]] = ...) -> None: ...

class GapValues(_message.Message):
    __slots__ = ("log_wk_data", "log_wk_rand")
    class LogWkRand(_message.Message):
        __slots__ = ("k", "values")
        K_FIELD_NUMBER: _ClassVar[int]
        VALUES_FIELD_NUMBER: _ClassVar[int]
        k: int
        values: _containers.RepeatedScalarFieldContainer[float]
        def __init__(self, k: _Optional[int] = ..., values: _Optional[_Iterable[float]] = ...) -> None: ...
    class LogWkDataEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: int
        value: float
        def __init__(self, key: _Optional[int] = ..., value: _Optional[float] = ...) -> None: ...
    LOG_WK_DATA_FIELD_NUMBER: _ClassVar[int]
    LOG_WK_RAND_FIELD_NUMBER: _ClassVar[int]
    log_wk_data: _containers.ScalarMap[int, float]
    log_wk_rand: _containers.RepeatedCompositeFieldContainer[GapValues.LogWkRand]
    def __init__(self, log_wk_data: _Optional[_Mapping[int, float]] = ..., log_wk_rand: _Optional[_Iterable[_Union[GapValues.LogWkRand, _Mapping]]] = ...) -> None: ...

class SplitCheck(_message.Message):
    __slots__ = ("should_split", "split_proba")
    SHOULD_SPLIT_FIELD_NUMBER: _ClassVar[int]
    SPLIT_PROBA_FIELD_NUMBER: _ClassVar[int]
    should_split: bool
    split_proba: float
    def __init__(self, should_split: bool = ..., split_proba: _Optional[float] = ...) -> None: ...

class TermAssociation(_message.Message):
    __slots__ = ("term_id", "counts", "pval", "corrected_pval")
    class CountsEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: int
        value: int
        def __init__(self, key: _Optional[int] = ..., value: _Optional[int] = ...) -> None: ...
    TERM_ID_FIELD_NUMBER: _ClassVar[int]
    COUNTS_FIELD_NUMBER: _ClassVar[int]
    PVAL_FIELD_NUMBER: _ClassVar[int]
    CORRECTED_PVAL_FIELD_NUMBER: _ClassVar[int]
    term_id: str
    counts: _containers.ScalarMap[int, int]
    pval: float
    corrected_pval: float
    def __init__(self, term_id: _Optional[str] = ..., counts: _Optional[_Mapping[int, int]] = ..., pval: _Optional[float] = ..., corrected_pval: _Optional[float] = ...) -> None: ...

class ClusteringWorkflowMetadata(_message.Message):
    __slots__ = ("stratiphy_version", "hpo_version")
    STRATIPHY_VERSION_FIELD_NUMBER: _ClassVar[int]
    HPO_VERSION_FIELD_NUMBER: _ClassVar[int]
    stratiphy_version: str
    hpo_version: str
    def __init__(self, stratiphy_version: _Optional[str] = ..., hpo_version: _Optional[str] = ...) -> None: ...
