import abc
import dataclasses
import logging
import os
import pathlib
import typing
from collections import Counter
from types import NoneType

import hpotk
import numpy as np
import tqdm

import stratiphy
from stratiphy.analysis.explain import FisherExplainMethod, TermAssociation
from stratiphy.analysis.gap import GapValues
from stratiphy.analysis.simulate import SyntheticCohortGenerator
from stratiphy.analysis.split import GapValSplitCheck, SplitCheckResult
from stratiphy.cluster import SimilarityMatrixClustering
from stratiphy.model import Phenotyped, Sample
from stratiphy.preprocessing.validate import SampleValidator
from stratiphy.semsim import SimilarityMatrix, SimilarityMatrixCreator, SimilarityMatrixCreatorFactory

from . import workflow_pb2 as pbw
from .util import compute_sort_order, from_dense_to_condensed, refine_cluster_ids


@dataclasses.dataclass(frozen=True)
class ClusteringWorkflowMetadata:
    """
    Metadata for clustering workflow.
    """

    stratiphy_version: str
    """
    Semantic versioning identifier, e.g. `0.3.0`.
    """

    hpo_version: typing.Optional[str]
    """
    HPO release identifier, e.g. `v2026-02-16`. Should always be present.
    """


class ClusteringWorkflowResult:
    """
    A container for :class:`ClusteringWorkflow` results.
    """

    def __init__(
        self,
        affinity_matrix: typing.Union[
            np.ndarray,
            typing.Sequence[float],
        ],
        cluster_labels: typing.Mapping[
            int,
            typing.Union[
                np.ndarray,
                typing.Sequence[int],
            ],
        ],
        sort_order: typing.Optional[typing.Union[np.ndarray, typing.Sequence[int]]],
        gap_values: typing.Optional[GapValues],
        split_check: typing.Optional[SplitCheckResult],
        term_associations: typing.Mapping[int, typing.Sequence[TermAssociation]],
        metadata: typing.Optional[ClusteringWorkflowMetadata],
    ):
        self._affinity_matrix = np.array(affinity_matrix)
        self._cluster_labels = {int(k): np.array(cl) for k, cl in cluster_labels.items()}
        self._sort_order = None if sort_order is None else np.array(sort_order)

        if gap_values is not None:
            assert isinstance(gap_values, GapValues)
        self._gap_data = gap_values

        if split_check is not None:
            assert isinstance(split_check, SplitCheckResult)
        self._split_check = split_check

        self._associations = {
            int(k): sorted(tas, key=TermAssociation.p_val_comparator) for k, tas in term_associations.items()
        }
        if metadata is not None:
            assert isinstance(metadata, ClusteringWorkflowMetadata)
        self._metadata = metadata

    @property
    def affinity_matrix(self) -> np.ndarray:
        """
        Get the affinity matrix in the condensed format.

        The condensed format contains only the upper triangle of the symmetric square similarity matrix,
        including the diagonal with self-similarities.

        Use :attr:`~stratiphy.workflow.util.from_condensed_to_dense` to convert into a dense matrix.

        :return: the affinity matrix in the condensed format.
        """
        return self._affinity_matrix

    @property
    def cluster_labels(self) -> typing.Mapping[int, np.ndarray]:
        """
        Get mapping from *k* clusters to a cluster ID array.

        The mapping includes cluster labels for each *k* clusters tested by the workflow,
        as described in :attr:`~stratiphy.consensus.workflow.ConsensusClusteringWorkflowResult.k_clusters`

        Each cluster label array has a shape of :math:`(n,)` where :math:`n` is the cohort size.
        The array values denote cluster membership of the sample.
        The value is an `int` in range :math:`[0,k)`.

        :return: a mapping of cluster ID arrays.
        """
        return self._cluster_labels

    @property
    def sort_order(self) -> typing.Optional[np.ndarray]:
        """
        Get an array for sorting the cohort such that the most similar samples are adjacent.

        :return: a Numpy array with shape `(n, )` where `n` is the cohort size
        or `None` if the sort order was not computed.
        """
        return self._sort_order

    @property
    def gap_data(self) -> typing.Optional[GapValues]:
        return self._gap_data

    @property
    def split_check(self) -> typing.Optional[SplitCheckResult]:
        return self._split_check

    @property
    def term_associations(self) -> typing.Mapping[int, typing.Sequence[TermAssociation]]:
        return self._associations

    @property
    def metadata(self) -> typing.Optional[ClusteringWorkflowMetadata]:
        return self._metadata

    def to_protobuf(
        self,
        out: typing.Union[str, pathlib.Path, typing.BinaryIO],
    ):
        pb_stuff = pbw.ClusteringWorkflowResult(
            affinity_matrix=self._affinity_matrix,
            cluster_labels=(
                pbw.ClusteringWorkflowResult.ClusterLabels(
                    k=k,
                    labels=labels,
                )
                for k, labels in self._cluster_labels.items()
            ),
            sort_order=self._sort_order,
            gap_values=ClusteringWorkflowResult._to_pbgv(self._gap_data) if self._gap_data else None,
            split_check=pbw.SplitCheck(
                should_split=self._split_check.should_split,
                split_proba=self._split_check.split_proba,
            )
            if self._split_check
            else None,
            term_associations=(ClusteringWorkflowResult._to_tas(k, ta) for k, ta in self._associations.items()),
            metadata=None
            if self._metadata is None
            else pbw.ClusteringWorkflowMetadata(
                stratiphy_version=self._metadata.stratiphy_version,
                hpo_version=self._metadata.hpo_version,
            ),
        )

        if isinstance(out, (str, pathlib.Path)):
            with open(out, "wb") as fh:
                fh.write(pb_stuff.SerializeToString())
        elif hasattr(out, "write") and callable(out.write):
            out.write(pb_stuff.SerializeToString())
        else:
            raise ValueError("Unsupported output type")

    @staticmethod
    def from_protobuf(
        val: typing.Union[str, pathlib.Path, typing.BinaryIO],
    ) -> "ClusteringWorkflowResult":
        cwr = pbw.ClusteringWorkflowResult()
        if isinstance(val, (str, pathlib.Path)):
            with open(val, "rb") as fh:
                cwr.ParseFromString(fh.read())
        elif hasattr(val, "read") and callable(val.read):
            cwr.ParseFromString(val.read())
        else:
            raise ValueError("Unsupported input type")

        if cwr.HasField("gap_values"):
            gap_values = ClusteringWorkflowResult._from_pbgv(cwr.gap_values)
        else:
            gap_values = None

        if cwr.HasField("split_check"):
            split_check = SplitCheckResult(
                should_split=cwr.split_check.should_split,
                split_proba=cwr.split_check.split_proba,
            )
        else:
            split_check = None

        return ClusteringWorkflowResult(
            affinity_matrix=np.array(cwr.affinity_matrix),
            cluster_labels={cl.k: cl.labels for cl in cwr.cluster_labels},
            sort_order=None if len(cwr.sort_order) == 0 else cwr.sort_order,
            gap_values=gap_values,
            split_check=split_check,
            term_associations=ClusteringWorkflowResult._from_tas(cwr.term_associations),
            metadata=ClusteringWorkflowMetadata(
                stratiphy_version=cwr.metadata.stratiphy_version,
                hpo_version=cwr.metadata.hpo_version,
            ),
        )

    @staticmethod
    def _check_array_sequences_are_both_none_or_equal(
        lefts: typing.Optional[typing.Iterable[np.ndarray]],
        rights: typing.Optional[typing.Iterable[np.ndarray]],
    ) -> bool:
        if lefts is None and rights is None:
            return True
        else:
            if lefts is not None and rights is not None:
                return all(np.array_equal(left, right) for left, right in zip(lefts, rights))
            else:
                return False

    @staticmethod
    def _check_arrays_are_both_none_or_equal(
        left: typing.Optional[np.ndarray],
        right: typing.Optional[np.ndarray],
    ) -> bool:
        if left is None and right is None:
            return True
        else:
            if left is not None and right is not None:
                return np.array_equal(left, right)
            else:
                return False

    @staticmethod
    def _check_arrays_are_both_none_or_close(
        left: typing.Optional[np.ndarray],
        right: typing.Optional[np.ndarray],
    ) -> bool:
        if left is None and right is None:
            return True
        else:
            if left is not None and right is not None:
                return np.allclose(left, right)
            else:
                return False

    @staticmethod
    def _to_tas(
        k: int,
        associations: typing.Sequence[TermAssociation],
    ) -> pbw.ClusteringWorkflowResult.TermAssociations:
        return pbw.ClusteringWorkflowResult.TermAssociations(
            k=k,
            associations=(
                pbw.TermAssociation(
                    term_id=ta.term_id.value,
                    counts=ta.counts,
                    pval=ta.pval,
                    corrected_pval=ta.corrected_pval,
                )
                for ta in associations
            ),
        )

    @staticmethod
    def _from_tas(
        pb_tas: typing.Sequence[pbw.ClusteringWorkflowResult.TermAssociations],
    ) -> typing.Mapping[int, typing.Sequence[TermAssociation]]:
        return {
            tas.k: [
                TermAssociation(
                    term_id=hpotk.TermId.from_curie(ta.term_id),
                    counts=dict(ta.counts),
                    pval=float(ta.pval),
                    corrected_pval=float(ta.corrected_pval) if ta.HasField("corrected_pval") else None,
                )
                for ta in tas.associations
            ]
            for tas in pb_tas
        }

    @staticmethod
    def _to_pbgv(
        gd: GapValues,
    ) -> pbw.GapValues:
        return pbw.GapValues(
            log_wk_data=gd.log_wk_data,
            log_wk_rand=(
                pbw.GapValues.LogWkRand(
                    k=k,
                    values=vals,
                )
                for k, vals in gd.log_wk_rand.items()
            ),
        )

    @staticmethod
    def _from_pbgv(
        gv: pbw.GapValues,
    ) -> GapValues:
        return GapValues(
            log_wk_data=gv.log_wk_data,
            log_wk_rand={r.k: r.values for r in gv.log_wk_rand},
        )

    def __eq__(self, other):
        return (
            isinstance(other, ClusteringWorkflowResult)
            and ClusteringWorkflowResult._check_arrays_are_both_none_or_close(
                self._affinity_matrix,
                other._affinity_matrix,
            )
            and all(np.array_equal(this, other) for this, other in zip(self._cluster_labels, other._cluster_labels))
            and ClusteringWorkflowResult._check_arrays_are_both_none_or_equal(
                self._sort_order,
                other._sort_order,
            )
            and self._gap_data == other._gap_data
            and self._split_check == other._split_check
            and self._associations == other._associations
            and self._metadata == other._metadata
        )

    def __repr__(self):
        return (
            "ClusteringWorkflowResult("
            f"cluster_labels={self._cluster_labels}, "
            f"similarity_matrix={self._affinity_matrix}, "
            f"sort_order={self._sort_order}, "
            f"gap_data={self._gap_data}, "
            f"split_check={self._split_check}, "
            f"term_associations={self._associations}, "
            f"metadata={self._metadata}"
            ")"
        )

    def __str__(self):
        return (
            "ClusteringWorkflowResult("
            f"cluster_labels={self._cluster_labels}, "
            f"similarity_matrix={self._affinity_matrix.shape}, "
            f"sort_order={None if self._sort_order is None else self._sort_order.shape}, "
            f"gap_data={self._gap_data}, "
            f"split_check={self._split_check}, "
            f"term_associations={self._associations}, "
            f"metadata={self._metadata}"
            ")"
        )


class ClusteringWorkflow(
    metaclass=abc.ABCMeta,
):
    def __init__(
        self,
        validator: typing.Optional[SampleValidator] = None,
    ):
        assert validator is None or isinstance(validator, SampleValidator)
        self.validator = validator
        self._logger = logging.getLogger(__name__ + "." + self.__class__.__name__)

    @abc.abstractmethod
    def run(
        self,
        samples: typing.Sequence[Sample],
        k_clusters: typing.Sequence[int],
    ) -> ClusteringWorkflowResult:
        pass

    @staticmethod
    def _check_k_clusters(
        k_clusters: typing.Sequence[int],
    ):
        """
        Ensure that `k_clusters` is not empty and each `k` is an `int` greater than or equal to `2`.
        """
        if isinstance(k_clusters, typing.Sequence):
            if len(k_clusters) == 0:
                raise ValueError("`k_clusters` must not be an empty sequence!")

            for i, k in enumerate(k_clusters):
                if not isinstance(k, int) or k < 2:
                    raise ValueError(f"`k` must be an int greater than or equal to 2 but the element #{i} was {k}")

            unique = set(k_clusters)
            if len(unique) != len(k_clusters):
                counter = Counter(k_clusters)
                more = [val for count, val in counter.items() if count > 1]
                raise ValueError(
                    "`k_clusters` must contain unique elements "
                    f"but the following values were present more than once: {more}"
                )
        else:
            raise ValueError(f"`k_clusters` should be a sequence but was {type(k_clusters)}")

    def _check_samples(
        self,
        samples: typing.Sequence[Sample],
    ):
        """
        Perform initial Q/C on the samples to ensure the data has no logical errors and meets the requirement.

        Specifically, we check that:
        * all HPO terms are present in the ontology
        * all HPO terms use current (not obsolete) term ID
        * the terms are descendants of *Phenotypic abnormality* and not other HPO branches
          such as *Mode of inheritance*, *Clinical modifier*, etc.
        * the terms do not violate the annotation propagation rule

        :return: a mapping with list of :class:`hpotk.validate.ValidationResult` per sample label. Only labels
                with failing samples are present
        """
        if self.validator:
            validation_results = {}
            for i, sample in enumerate(samples):
                results = self.validator.validate(sample)
                if not results.is_ok():
                    validation_results[sample.labels.label_summary()] = results

            if validation_results:
                longest_sample_id = max([len(sample) for sample in validation_results.keys()])
                lines = ["Unable to run consensus clustering due to samples did not pass the input Q/C:"]
                for sample_label, results in validation_results.items():
                    for result in results.results:
                        label = sample_label.ljust(longest_sample_id, " ")
                        line = f"{label}: {result.level:<5}: {result.message}"
                        lines.append(line)
                line = os.linesep.join(lines)
                raise ValueError(line)


class BaseClusteringWorkflow(
    ClusteringWorkflow,
    metaclass=abc.ABCMeta,
):
    # NOT PART OF THE PUBLIC API

    PROMPT_WIDTH = 70
    """
    Width of the prompt shown by `tqdm`.
    """

    def __init__(
        self,
        hpo_version: typing.Optional[str],
        clustering: SimilarityMatrixClustering,
        cohort_generator: typing.Optional[SyntheticCohortGenerator[Sample]] = None,
        rand_iter: typing.Optional[int] = None,
        split_check: typing.Optional[GapValSplitCheck] = None,
        explain_method: typing.Optional[FisherExplainMethod] = None,
        validator: typing.Optional[SampleValidator] = None,
    ):
        super().__init__(
            validator=validator,
        )
        self._hpo_version = hpo_version
        assert isinstance(clustering, SimilarityMatrixClustering)
        self._clustering = clustering
        assert isinstance(cohort_generator, (SyntheticCohortGenerator, NoneType))
        self._cohort_generator = cohort_generator
        if rand_iter is not None:
            assert isinstance(rand_iter, int) and rand_iter > 0
        self._rand_iter = rand_iter
        if split_check is not None:
            assert isinstance(split_check, GapValSplitCheck)
        self._split_check = split_check
        if explain_method is not None:
            assert isinstance(explain_method, FisherExplainMethod)
        self._explain_method = explain_method

    @abc.abstractmethod
    def _compute_similarity_matrix(
        self,
        samples: typing.Sequence[Sample],
    ) -> SimilarityMatrix:
        """
        Compute the similarity matrix for the `samples`.
        """
        ...

    @abc.abstractmethod
    def _compute_similarity_matrices(
        self,
        cohorts: typing.Sequence[typing.Sequence[Phenotyped]],
        report_progress: bool = False,
    ) -> typing.Sequence[SimilarityMatrix]:
        """
        Compute the similarity matrices for the `cohorts`.
        """
        ...

    def run(
        self,
        samples: typing.Sequence[Sample],
        k_clusters: typing.Sequence[int],
    ) -> ClusteringWorkflowResult:
        self._logger.debug("Got %d samples", len(samples))
        self._logger.debug("Partitioning into %s clusters", k_clusters)

        self._logger.info("Computing the similarity matrix")
        similarity_matrix = self._compute_similarity_matrix(
            samples=samples,
        )

        self._logger.debug("Computing the sort order")
        sort_order = compute_sort_order(
            a=similarity_matrix.similarity_matrix,
            is_distance=False,
            method="average",
        )

        self._logger.debug("Clustering the cohort")
        cluster_labels = self._compute_cluster_labels(
            similarity_matrix=similarity_matrix,
            k_clusters=k_clusters,
            report_progress=True,
        )

        # Compute randomized cohort metrics
        if self._cohort_generator is not None:
            assert isinstance(self._rand_iter, int)
            randomized_cohorts = tuple(
                self._cohort_generator.generate(samples)
                for _ in tqdm.tqdm(
                    iterable=range(self._rand_iter),
                    total=self._rand_iter,
                    desc=f"Generating {self._rand_iter} randomized cohorts".ljust(BaseClusteringWorkflow.PROMPT_WIDTH),
                )
            )

            randomized_similarity_matrices = tuple(
                sm.similarity_matrix
                for sm in self._compute_similarity_matrices(
                    randomized_cohorts,
                    report_progress=True,
                )
            )

            self._logger.debug("Computing gap scores")
            gap_values = GapValues.from_similarity_matrices(
                sm=similarity_matrix.similarity_matrix,
                sm_randomized=randomized_similarity_matrices,
                cluster_labels=cluster_labels,
            )
        else:
            self._logger.debug("Skipping random cohort generation and computing of the gap scores")
            gap_values = None

        if self._split_check is not None and gap_values is not None:
            self._logger.debug("Executing split check")
            split_check = self._split_check.check(gap_values)
        else:
            self._logger.debug("Skipping split check")
            split_check = None

        if self._explain_method is not None:
            self._logger.info("Computing term-cluster associations")
            term_asssociations = self._explain_associations(
                samples=samples,
                cluster_labels=cluster_labels,
                report_progress=True,
            )
        else:
            self._logger.info("Skipping term-cluster association analysis")
            term_asssociations = {}

        affinity_matrix = from_dense_to_condensed(
            similarity_matrix.similarity_matrix,
        )
        return ClusteringWorkflowResult(
            affinity_matrix=affinity_matrix,
            cluster_labels=cluster_labels,
            sort_order=sort_order,
            gap_values=gap_values,
            split_check=split_check,
            term_associations=term_asssociations,
            metadata=ClusteringWorkflowMetadata(
                stratiphy_version=stratiphy.__version__,
                hpo_version=self._hpo_version,
            ),
        )

    def _compute_cluster_labels(
        self,
        similarity_matrix: SimilarityMatrix,
        k_clusters: typing.Sequence[int],
        report_progress: bool = False,
    ) -> typing.Mapping[int, np.ndarray]:
        iterable = (
            (
                tqdm.tqdm(
                    k_clusters,
                    desc=f"Computing cluster labels for {k_clusters}".ljust(BaseClusteringWorkflow.PROMPT_WIDTH),
                )
            )
            if report_progress
            else k_clusters
        )

        assert isinstance(self._clustering, SimilarityMatrixClustering)
        cluster_labels = {
            k_clusters: self._clustering.cluster_similarity_matrix(
                similarity_matrix=similarity_matrix.similarity_matrix,
                k_clusters=k_clusters,
            ).cluster_labels
            for k_clusters in iterable
        }

        return refine_cluster_ids(cluster_labels)

    def _explain_associations(
        self,
        samples: typing.Sequence[Sample],
        cluster_labels: typing.Mapping[int, np.ndarray],
        report_progress: bool = False,
    ) -> typing.Mapping[int, typing.Sequence[TermAssociation]]:
        assert self._explain_method is not None

        iterable = (
            (
                tqdm.tqdm(
                    cluster_labels.items(),
                    desc="Computing term associations".ljust(BaseClusteringWorkflow.PROMPT_WIDTH),
                )
            )
            if report_progress
            else cluster_labels.items()
        )

        return {
            k: self._explain_method.explain(
                samples=samples,
                cluster_labels=clabs,
            )
            for k, clabs in iterable
        }


class SimClusteringWorkflow(BaseClusteringWorkflow):
    def __init__(
        self,
        hpo_version: typing.Optional[str],
        smcf: SimilarityMatrixCreatorFactory,
        clustering: SimilarityMatrixClustering,
        cohort_generator: typing.Optional[SyntheticCohortGenerator[Sample]] = None,
        rand_iter: typing.Optional[int] = None,
        split_check: typing.Optional[GapValSplitCheck] = None,
        explain_method: typing.Optional[FisherExplainMethod] = None,
        validator: typing.Optional[SampleValidator] = None,
    ):
        super().__init__(
            hpo_version,
            clustering,
            cohort_generator,
            rand_iter,
            split_check,
            explain_method,
            validator,
        )
        self._smcf = smcf
        self._smc: typing.Optional[SimilarityMatrixCreator] = None

    def _compute_similarity_matrix(
        self,
        samples: typing.Sequence[Sample],
    ) -> SimilarityMatrix:
        if self._smc is None:
            self._smc = self._smcf.create(samples)
            return self._smc.calculate_matrix(
                samples=samples,
            )
        else:
            # This is probably a bug.
            raise ValueError("Cannot recompute semantic similarity creator after it has been computed")

    def _compute_similarity_matrices(
        self,
        cohorts: typing.Sequence[typing.Sequence[Phenotyped]],
        report_progress: bool = False,
    ) -> typing.Sequence[SimilarityMatrix]:
        if self._smc is None:
            raise ValueError("Not yet fitted")
        else:
            if report_progress:
                iterable = tqdm.tqdm(
                    iterable=cohorts,
                    desc="Computing semantic similarity".ljust(BaseClusteringWorkflow.PROMPT_WIDTH),
                )
            else:
                iterable = cohorts

            return tuple(self._smc.calculate_matrix(cohort) for cohort in iterable)
