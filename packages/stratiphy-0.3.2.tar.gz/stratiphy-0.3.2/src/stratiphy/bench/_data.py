import hpotk as ht

from stratiphy.model import PhenotypicFeature, SampleLabels
from ._model import BenchSample


def get_lmna_EDMD3_III_4() -> BenchSample:
    """
    Sample with EDMD3 with 8 phenotypic features (all present).
    """
    label = "III-4"
    pfs = [
        ("HP:0000651", True),
        ("HP:0002321", True),
        ("HP:0003401", True),
        ("HP:0005115", True),
        ("HP:0008997", True),
        ("HP:0008994", True),
        ("HP:0008946", True),
        ("HP:0003724", True),
    ]
    di = "EMERY-DREIFUSS MUSCULAR DYSTROPHY 3, AUTOSOMAL RECESSIVE; EDMD3"
    return BenchSample(SampleLabels(label), [make_spf(*pf) for pf in pfs], di)


def get_lmna_HGPS_DB392() -> BenchSample:
    """
    Sample with HGPS with 6 phenotypic features (3 present 3 excluded).
    """
    label = "DB392"
    pfs = [
        ("HP:0001072", True),
        ("HP:0001808", True),
        ("HP:0000278", False),
        ("HP:0000164", False),
        ("HP:0011025", False),
        ("HP:0004322", True),
    ]
    di = "HUTCHINSON-GILFORD PROGERIA SYNDROME; HGPS"
    return BenchSample(SampleLabels(label), [make_spf(*pf) for pf in pfs], di)


def get_lmna_HGPS_Patient_3() -> BenchSample:
    """
    Sample with HGPS with 10 phenotypic features (8 present 2 excluded).
    """
    label = "Patient 3"
    pfs = [
        ("HP:0000819", False),
        ("HP:0004322", True),
        ("HP:0007495", True),
        ("HP:0003124", True),
        ("HP:0004950", False),
        ("HP:0000444", True),
        ("HP:0000275", True),
        ("HP:0002213", True),
        ("HP:0005590", True),
        ("HP:0008887", True),
    ]
    di = "HUTCHINSON-GILFORD PROGERIA SYNDROME; HGPS"
    return BenchSample(SampleLabels(label), [make_spf(*pf) for pf in pfs], di)


def get_lmna_FPLD2_patient_A() -> BenchSample:
    """
    Sample with FPLD2 with 9 phenotypic features (7 present 2 excluded).
    """
    label = "patient A"
    pfs = [
        ("HP:0000287", True),
        ("HP:0000819", True),
        ("HP:0003635", True),
        ("HP:0000822", False),
        ("HP:0000956", False),
        ("HP:0003233", True),
        ("HP:0002155", True),
        ("HP:0040217", True),
        ("HP:0025691", True),
    ]
    di = "LIPODYSTROPHY, FAMILIAL PARTIAL, TYPE 2; FPLD2"
    return BenchSample(SampleLabels(label), [make_spf(*pf) for pf in pfs], di)


def get_lmna_FPLD2_patient_B() -> BenchSample:
    """
    Sample with FPLD2 with 10 phenotypic features (7 present 2 excluded).
    """
    label = "patient B"
    pfs = [
        ("HP:0000287", True),
        ("HP:0003635", True),
        ("HP:0000819", True),
        ("HP:0000822", False),
        ("HP:0000956", False),
        ("HP:0003233", True),
        ("HP:0002155", True),
        ("HP:0025691", True),
        ("HP:0040217", True),
        ("HP:0001397", True),
    ]
    di = "LIPODYSTROPHY, FAMILIAL PARTIAL, TYPE 2; FPLD2"
    return BenchSample(SampleLabels(label), [make_spf(*pf) for pf in pfs], di)


def get_fbn1_marfan_D27() -> BenchSample:
    """
    Sample with Marfan syndrome with 8 phenotypic features (8 present).
    """
    label = "D27"
    pfs = [
        ("HP:0000098", True),
        ("HP:0001083", True),
        ("HP:0000768", True),
        ("HP:0000218", True),
        ("HP:0000268", True),
        ("HP:0000545", True),
        ("HP:0002616", True),
        ("HP:0002108", True),
    ]
    di = "Marfan syndrome"
    return BenchSample(SampleLabels(label), [make_spf(*pf) for pf in pfs], di)


def get_fbn1_marfan_D1() -> BenchSample:
    """
    Sample with Marfan syndrome with 8 phenotypic features (8 present).
    """
    label = "D1"
    pfs = [
        ("HP:0000098", True),
        ("HP:0001382", True),
        ("HP:0001083", True),
        ("HP:0000218", True),
        ("HP:0000268", True),
        ("HP:0011003", True),
        ("HP:0002616", True),
        ("HP:0001653", True),
    ]
    di = "Marfan syndrome"
    return BenchSample(SampleLabels(label), [make_spf(*pf) for pf in pfs], di)


def get_fbn1_elf_RWT() -> BenchSample:
    """
    Sample with FPLD2 with 10 phenotypic features (3 present 3 excluded).
    """
    label = "RWT"
    pfs = [
        ("HP:0000768", False),
        ("HP:0000767", False),
        ("HP:0002650", False),
        ("HP:0001166", False),
        ("HP:0000218", False),
        ("HP:0001382", True),
        ("HP:0001634", False),
        ("HP:0001083", True),
        ("HP:0000545", True),
        ("HP:0000486", True),
        ("HP:0000501", False),
        ("HP:0000974", True),
        ("HP:0001065", True),
        ("HP:0100790", True),
        ("HP:0002616", False),
    ]
    di = "Ectopia lentis, familial"
    return BenchSample(SampleLabels(label), [make_spf(*pf) for pf in pfs], di)


def make_spf(curie: str, status: bool) -> PhenotypicFeature:
    return PhenotypicFeature.from_values(ht.TermId.from_curie(curie), status)
