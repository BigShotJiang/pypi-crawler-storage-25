import argparse
import gzip
import json
import logging
import os
import pathlib
import sys
import typing

import hpotk
from google.protobuf.json_format import Parse
from phenopackets.schema.v2 import Phenopacket

import stratiphy
from stratiphy.io import StratiphyJSONDecoder, StratiphyJSONEncoder
from stratiphy.model import Sample
from stratiphy.preprocessing.sanitize import Controversy, sanitize_samples
from stratiphy.util import setup_logging

from ._bencher import (
    CohortData,
    PHSpectralBencher,
)
from ._io import parse_phenopacket
from ._model import BenchSample

PROG = "stratiphy"
DEFAULT_DATA_PATH = "data"
DEFAULT_HPO_PATH = "hp.json"
DEFAULT_IC_MICA_PATH = "term-pair-similarity.csv.gz"
DEFAULT_SAMPLES_PATH = "samples.json.gz"
DEFAULT_LABELS_PATH = "labels.json.gz"

logger = logging.getLogger(PROG)

parser = argparse.ArgumentParser(
    prog=PROG,
    formatter_class=argparse.RawTextHelpFormatter,
    description="Phenotype-driven stratification of patient cohorts",
    epilog="Find more info at https://P2GX.github.io/stratiphy/stable",
)

parser.add_argument(
    "-v",
    "--verbosity",
    action="count",
    default=0,
    help="increase verbosity",
)

parser.add_argument(
    "--version",
    action="version",
    version="%(prog)s {version}".format(version=stratiphy.__version__),
)

parser.add_argument(
    "-d",
    "--data",
    type=pathlib.Path,
    default=pathlib.Path(os.getcwd()).joinpath(DEFAULT_DATA_PATH),
    help=f"path to the data folder (default: {DEFAULT_DATA_PATH})",
)

subparsers = parser.add_subparsers(
    dest="command",
)

# #################### ------------ preprocess ------------ ####################
parser_preprocess = subparsers.add_parser(
    "preprocess",
    description="Preprocess phenopacket cohort",
)

subparsers_preprocess = parser_preprocess.add_subparsers(
    dest="command_preprocess",
)

# #################### ------- preprocess | sanitize ------ ####################
parser_preprocess_sanitize = subparsers_preprocess.add_parser(
    "sanitize",
    help="sanitize phenopackets",
)
parser_preprocess_sanitize.add_argument(
    "--controversy",
    type=str,
    default="small",
    choices=("high", "moderate", "small", "none"),
    help="try to sanitize issues with controversy less than this threshold",
)
parser_preprocess_sanitize.add_argument(
    "--out",
    type=pathlib.Path,
    default=pathlib.Path(os.getcwd()),
    help="folder for storing the preprocessed files",
)
parser_preprocess_sanitize.add_argument(
    "phenopackets",
    nargs="+",
    type=pathlib.Path,
    help="phenopacket JSON files with case reports for clustering",
)


def preprocess_sanitize(
    hpo: hpotk.MinimalOntology,
    controversy: typing.Literal["high", "moderate", "small", "none"],
    outdir: pathlib.Path,
    phenopackets: typing.Sequence[pathlib.Path],
) -> int:
    os.makedirs(
        outdir,
        exist_ok=True,
    )
    assert controversy.lower() in ("high", "moderate", "small", "none")

    # Read phenopackets
    logger.info("Reading phenopackets")
    logger.debug(
        "Phenopacket paths: %s",
        list(str(pp) for pp in phenopackets),
    )
    samples: typing.Sequence[BenchSample] = []
    for fpath_pp in phenopackets:
        with open(fpath_pp) as fh:
            samples.append(
                parse_phenopacket(
                    Parse(
                        fh.read(),
                        Phenopacket(),
                    )
                )
            )
    logger.info("Read %d phenopackets", len(samples))

    # Sanitize
    logger.info("Sanitizing samples")
    level = Controversy[controversy.upper()]
    logger.debug("Fixing sanity issues at or below %s level of controversy", level.name.lower())
    sanitation_result = sanitize_samples(
        samples=samples,
        hpo=hpo,
        threshold=level,
    )

    for sample, actions in sanitation_result.get_samples_and_actions():
        print(f"Sample: {sample.labels}")
        for action in actions:
            print(f" - {action}")

    # Samples

    fs = outdir.joinpath(DEFAULT_SAMPLES_PATH).absolute()
    logger.info("Serializing the sanitized samples to %s", fs)
    dump_samples(
        sanitation_result.sanitized_samples,
        fs,
    )
    logger.info("Wrote the samples to %s", fs)

    # Labels
    fl = outdir.joinpath(DEFAULT_LABELS_PATH).absolute()
    logger.info("Serializing labels to %s", fl)
    dump_labels(
        [s.disease for s in samples],
        fl,
    )

    return 0


# #################### ------- preprocess | merge ------ ####################
parser_preprocess_merge = subparsers_preprocess.add_parser(
    "merge",
    help="merge samples",
)

parser_preprocess_merge.add_argument(
    "--sample",
    action="append",
    help="prefix of samples and labels to merge",
)
parser_preprocess_merge.add_argument(
    "--out",
    type=pathlib.Path,
    help="prefix for storing merged samples and labels",
)


def preprocess_merge(
    out: pathlib.Path,
    samples: typing.Sequence[pathlib.Path],
) -> int:
    cohort_samples = []
    cohort_labels = []
    for cohort, labels in zip(*load_cohorts(samples)):
        cohort_samples.extend(cohort)
        cohort_labels.extend(labels)

    fs = pathlib.Path(str(out) + "." + DEFAULT_SAMPLES_PATH)
    logger.info("Storing merged samples at %s", fs)
    dump_samples(
        cohort_samples,
        fs,
    )

    fl = pathlib.Path(str(out) + "." + DEFAULT_LABELS_PATH)
    logger.info("Storing merged labels at %s", fs)
    dump_labels(
        cohort_labels,
        fl,
    )

    return 0


# #################### ------------ bench ------------ ####################
parser_bench = subparsers.add_parser(
    "bench",
    help="execute the benchmark",
)

parser_bench.add_argument(
    "--sample",
    action="append",
    required=True,
    help="prefix of samples and labels to use for benching",
)
parser_bench.add_argument(
    "--out",
    type=pathlib.Path,
    metavar="out.json.gz",
    required=True,
    help="file for storing bench results",
)

subparsers_bench = parser_bench.add_subparsers(
    dest="command_bench",
)

# #################### --------  bench | phsp  --------- ####################
parser_bench_ph = subparsers_bench.add_parser(
    "phsp",
    help="bench ph spectral clustering",
)


# ################################### main ######################################


def main():
    argv = sys.argv[1:]

    if len(argv) == 0:
        parser.print_help()
        sys.exit(1)

    args = parser.parse_args(argv)

    setup_logging(
        logger,
        args.verbosity,
    )

    if args.command == "preprocess":
        if args.command_preprocess == "sanitize":
            hpo = hpotk.load_minimal_ontology(
                os.path.join(args.data, "hp.json"),
            )
            sys.exit(
                preprocess_sanitize(
                    hpo=hpo,
                    controversy=args.controversy,
                    outdir=args.outdir,
                    phenopackets=args.phenopackets,
                ),
            )
        elif args.command_preprocess == "merge":
            sys.exit(
                preprocess_merge(
                    out=args.out,
                    samples=args.sample,
                )
            )
        else:
            parser.print_help()
            sys.exit(1)

    elif args.command == "bench":
        fpath_hpo = pathlib.Path(args.data).joinpath(DEFAULT_HPO_PATH)

        cohorts = load_cohorts(args.sample)
        ks = (2, 3, 4, 5, 6)

        logger.info(
            "Loaded %d cohorts",
            len(cohorts),
        )

        if args.command_bench not in ("phsp",):
            parser.print_help()
            sys.exit(1)

        if args.command_bench == "phsp":
            logger.info("Benching phsp")

            bencher = PHSpectralBencher(
                fpath_hpo,
            )
        else:
            parser.print_help()
            sys.exit(1)

        bencher.bench(
            cohorts,
            ks,
            args.out,
        )
        logger.info("Wrote output to %s", args.out)
    else:
        parser.print_help()
        sys.exit(1)


def load_samples(
    fpath: pathlib.Path,
) -> typing.Sequence[Sample]:
    with gzip.open(fpath) as fh:
        return json.load(
            fh,
            cls=StratiphyJSONDecoder,
        )


def dump_samples(
    samples: typing.Sequence[Sample],
    fpath: pathlib.Path,
):
    with gzip.open(fpath, "wt") as fh:
        json.dump(
            samples,
            fh,
            cls=StratiphyJSONEncoder,
        )


def load_labels(
    fpath: pathlib.Path,
) -> typing.Sequence[str]:
    with gzip.open(fpath) as fh:
        return json.load(
            fh,
        )


def dump_labels(
    labels: typing.Sequence[str],
    fpath: pathlib.Path,
):
    with gzip.open(fpath, "wt") as fh:
        json.dump(
            labels,
            fh,
            cls=StratiphyJSONEncoder,
        )


def load_cohorts(
    cohorts: typing.Sequence[pathlib.Path],
) -> typing.Sequence[CohortData]:
    values = []

    for fpath_cohort in cohorts:
        fp = pathlib.Path(str(fpath_cohort) + "." + DEFAULT_SAMPLES_PATH)
        logger.debug("Reading samples from %s", fp)
        cohort = load_samples(fp)

        fp = pathlib.Path(str(fpath_cohort) + "." + DEFAULT_LABELS_PATH)
        logger.debug("Reading labels from %s", fp)
        labels = load_labels(fp)

        values.append(
            CohortData(
                name=str(fpath_cohort),
                cohort=cohort,
                labels=labels,
            )
        )

    return tuple(values)
