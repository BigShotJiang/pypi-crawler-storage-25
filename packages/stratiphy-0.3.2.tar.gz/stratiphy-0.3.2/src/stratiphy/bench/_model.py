import dataclasses
import typing

from json import JSONEncoder

from stratiphy.model import Sample, PhenotypicFeature, SampleLabels


class BenchSample(Sample):
    def __init__(
        self,
        labels: SampleLabels,
        phenotypic_features: typing.Iterable[PhenotypicFeature],
        disease: str,
    ):
        super().__init__(
            labels,
            phenotypic_features,
        )
        self._disease = disease

    @property
    def disease(self) -> str:
        return self._disease

    def __eq__(self, value: object) -> bool:
        return (
            isinstance(value, BenchSample)
            and self._labels == value._labels
            and self._pfs == value._pfs
            and self._disease == value._disease
        )

    def __str__(self):
        return (
            f"BenchSample(label={self.labels}, "
            f"disease={self.disease}, "
            f"phenotypic_features={len(self.phenotypic_features)})"
        )

    def __repr__(self):
        return (
            f"BenchSample(labels={repr(self.labels)}, "
            f"disease={self.disease}, "
            f"phenotypic_features={self.phenotypic_features})"
        )


@dataclasses.dataclass(frozen=True)
class BenchResult:
    name: str
    k_pred: int
    k_true: int
    sample_labels: typing.Sequence[str]
    labels_true: typing.Sequence[str]
    k2labels: typing.Mapping[int, typing.Sequence[int]]


class BenchEncoder(JSONEncoder):
    def default(self, o):
        if isinstance(o, BenchResult):
            return {
                "name": o.name,
                "k_true": o.k_true,
                "k_pred": o.k_pred,
                "sample_labels": o.sample_labels,
                "labels_true": o.labels_true,
                "k2labels": o.k2labels,
            }
