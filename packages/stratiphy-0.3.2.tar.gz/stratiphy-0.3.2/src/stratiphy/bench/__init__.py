"""
A package for using in benchmarks and *NOT* targeted for a production use.

The API is subject to change at *any time*!
"""
