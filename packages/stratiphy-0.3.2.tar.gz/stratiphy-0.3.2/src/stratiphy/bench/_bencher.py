import abc
import dataclasses
import gzip
import json
import pathlib
import typing

import hpotk
import tqdm
from sklearn.cluster import SpectralClustering

from stratiphy.model import Sample
from stratiphy.semsim import SetSimSimilarityMatrixCreatorFactory

from ._model import BenchEncoder, BenchResult


@dataclasses.dataclass(frozen=True)
class CohortData:
    name: str
    cohort: typing.Sequence[Sample]
    labels: typing.Sequence[str]


class Bencher(
    metaclass=abc.ABCMeta,
):
    @abc.abstractmethod
    def _compute_k2labels(
        self,
        cohort: typing.Sequence[Sample],
        ks: typing.Sequence[int],
    ) -> typing.Mapping[int, typing.Sequence[int]]: ...

    @abc.abstractmethod
    def _choose_best_k(
        self,
        cohort: typing.Sequence[Sample],
    ) -> int: ...

    def bench(
        self,
        cohorts: typing.Sequence[CohortData],
        ks: typing.Sequence[int],
        out: pathlib.Path,
    ):
        """
        Bench the cohorts given some ground truth cluster labels.
        """
        brs = []

        for cohort in tqdm.tqdm(
            cohorts,
            total=len(cohorts),
        ):
            k_pred = self._choose_best_k(
                cohort=cohort.cohort,
            )
            k2labels = self._compute_k2labels(
                cohort.cohort,
                ks,
            )

            brs.append(
                BenchResult(
                    name=cohort.name,
                    k_pred=k_pred,
                    k_true=len(set(cohort.labels)),
                    sample_labels=tuple(str(s.labels) for s in cohort.cohort),
                    labels_true=cohort.labels,
                    k2labels=k2labels,
                )
            )

        Bencher.write_out(
            brs,
            out,
        )

    @staticmethod
    def write_out(
        brs: typing.Sequence[BenchResult],
        out: pathlib.Path,
    ):
        with gzip.open(out, "wt") as fh:
            json.dump(
                brs,
                fh,
                cls=BenchEncoder,
            )


class PHSpectralBencher(Bencher):
    def __init__(
        self,
        fpath_hpo: pathlib.Path,
    ):
        self._hpo = hpotk.load_minimal_ontology(str(fpath_hpo))
        self._setup = SetSimSimilarityMatrixCreatorFactory(self._hpo)

    def _choose_best_k(
        self,
        cohort: typing.Sequence[Sample],
    ) -> int:
        return -1

    def _compute_k2labels(
        self,
        cohort: typing.Sequence[Sample],
        ks: typing.Sequence[int],
    ) -> typing.Mapping[int, typing.Sequence[int]]:
        smc = self._setup.create(cohort)

        X = smc.calculate_matrix(cohort).similarity_matrix

        k2labels = {}
        for k in ks:
            c = SpectralClustering(
                n_clusters=k,
                affinity="precomputed",
            ).fit(X)
            # IGNORE: we run fit in the line above
            k2labels[k] = c.labels_.tolist()  # pyright: ignore[reportOptionalMemberAccess]

        return k2labels
