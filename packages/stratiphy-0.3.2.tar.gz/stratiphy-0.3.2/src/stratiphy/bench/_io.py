from stratiphy.model import PhenotypicFeature, SampleLabels

from ._model import BenchSample


from phenopackets.schema.v2.phenopackets_pb2 import Phenopacket


def parse_phenopacket(
    phenopacket: Phenopacket,
) -> BenchSample:
    return _map_phenopacket_to_bench_sample(phenopacket)


def _map_phenopacket_to_bench_sample(
    phenopacket: Phenopacket,
) -> BenchSample:
    if not isinstance(phenopacket, Phenopacket):
        raise ValueError(f"Expected an argument with type {Phenopacket} but got {type(phenopacket)}")
    labels = SampleLabels(label=phenopacket.subject.id, meta_label=phenopacket.id)
    phenotypic_features = []
    for feature in phenopacket.phenotypic_features:
        phenotypic_features.append(
            PhenotypicFeature.from_values(
                feature.type.id,
                is_present=not feature.excluded,
            )
        )

    d = None
    if len(phenopacket.diseases) == 0:
        # fall back to interpretation
        if len(phenopacket.interpretations) != 0:
            i = phenopacket.interpretations[0]
            if hasattr(i, "diagnosis") and hasattr(i.diagnosis, "disease"):
                d = i.diagnosis.disease
    elif len(phenopacket.diseases) == 1:
        d = phenopacket.diseases[0].term

    if d is not None and d.id != "" and d.label != "":
        disease = d.label
    else:
        raise ValueError(
            f"Phenopacket must contain exactly one disease, either in `diseases` or `interpretations. `"
            f"However, saw {len(phenopacket.diseases)} diseases "
            f"and {len(phenopacket.interpretations)} interpretations"
        )

    return BenchSample(labels, phenotypic_features, disease)
