import dataclasses
import typing

import hpotk
from hpotk.constants.hpo.base import PHENOTYPIC_ABNORMALITY

from stratiphy.model import Phenotyped
from stratiphy.semsim import calculate_cic


@dataclasses.dataclass(frozen=True)
class CohortSummary:
    tid2cic: typing.Mapping[hpotk.TermId, float]
    tot_cic: float
    scores: typing.Sequence[float]


class Summarize:
    def __init__(
        self,
        hpo: hpotk.MinimalOntology,
        root: hpotk.TermId = PHENOTYPIC_ABNORMALITY,
    ) -> None:
        self._hpo = hpo
        self._root = root

    def summarize(
        self,
        cohort: typing.Sequence[Phenotyped],
    ) -> CohortSummary:
        cic = calculate_cic(
            cohort=cohort,
            hpo=self._hpo,
            root=self._root,
        )
        scores = []
        module = set()
        for sample in cohort:
            for pf in sample.phenotypic_features:
                module.add(pf.identifier)
                if pf.is_present:
                    module.update(self._hpo.graph.get_ancestors(pf))
                else:
                    module.update(self._hpo.graph.get_descendants(pf))

            module.intersection_update(cic)
            scores.append(sum(cic[tid] for tid in module))
            module.clear()

        return CohortSummary(
            tid2cic=cic,
            tot_cic=sum(cic.values()),
            scores=scores,
        )
