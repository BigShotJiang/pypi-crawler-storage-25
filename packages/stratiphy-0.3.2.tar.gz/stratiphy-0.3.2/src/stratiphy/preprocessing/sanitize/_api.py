import abc
import typing

from stratiphy.model import Sample

from ._model import Suggestion


class Sanitation(typing.Iterable[Suggestion], metaclass=abc.ABCMeta):
    """
    Sanitation iteratively provides suggestions to sanitize the provided :class:`stratiphy.model.Sample` and keeps track
    of the elected updates.

    The sanitized `Sample` can be accessed during or following the sanitation using :attr:`sample` property.
    """

    @property
    @abc.abstractmethod
    def sample(self) -> Sample:
        """
        Get the sample possibly in its current state, with or without all sanitations applied.
        """
        pass


class SampleSanitizer(metaclass=abc.ABCMeta):
    """
    Sample sanitizer provides :class:`Sanitation` to perform iterative fixing of the errors in the input data.
    """

    @abc.abstractmethod
    def sanitize(self, sample: Sample) -> Sanitation:
        """
        Create the sanitation object for the provided `sample`.
        """
        pass
