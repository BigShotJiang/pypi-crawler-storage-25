"""
The ``stratiphy.preprocessing.sanitize`` package implements checking and fixing common errors in the input data,
such as using obsolete ontology term identifiers, or logical inconsistencies.
"""

from ._api import SampleSanitizer, Sanitation
from ._convenience import create_sanitizer, sanitize_samples, SampleSanitationResult
from ._model import Suggestion, Action, Controversy

__all__ = [
    "SampleSanitizer",
    "Sanitation",
    "Suggestion",
    "Action",
    "Controversy",
    "create_sanitizer",
    "sanitize_samples",
    "SampleSanitationResult",
]
