import typing

import hpotk

from stratiphy.model import Sample

from ._model import Controversy
from ._api import SampleSanitizer
from ._impl import SimpleSampleSanitizer


class SampleSanitationResult:
    """
    A container for returning results of sanitation of multiple samples.

    The container includes the sanitized samples and the sanitations performed on the samples.
    """

    def __init__(
        self,
        samples: typing.Sequence[Sample],
        sanitation_actions: typing.Sequence[typing.Sequence[str]],
    ):
        if len(samples) != len(sanitation_actions):
            raise ValueError(
                f"Mismatch between the number of samples and sanitation actions: {len(samples)} != {len(sanitation_actions)}"
            )
        self._samples = tuple(samples)
        self._sanitation_actions = tuple(sanitation_actions)

    @property
    def sanitized_samples(self) -> typing.Sequence[Sample]:
        """
        Get a sequence of sanitized samples.
        """
        return self._samples

    def get_samples_and_actions(
        self,
    ) -> typing.Iterator[typing.Tuple[Sample, typing.Sequence[str]]]:
        """
        Get an iterator over the samples that were sanitized (leaving out the untouched samples)

        :return: an iterator with tuples with :class:`stratiphy.model.Sample` and a sequence of the applied sanitations.
        """
        for i, actions in enumerate(self._sanitation_actions):
            if len(actions) > 0:
                yield self._samples[i], actions

    def sample_was_sanitized(self, sample_idx: int) -> bool:
        """
        Test if the sample stored under `sample_idx` was sanitized.

        :param sample_idx: index of the sample in the provided sample sequence.
        :return: `True` if a sample was sanitized or `False` otherwise.
        """
        return len(self.actions_performed_on_sample(sample_idx)) != 0

    def actions_performed_on_sample(self, sample_idx: int) -> typing.Sequence[str]:
        """
        Get a sequence of actions that were performed on a sample stored under given `sample_idx`.

        The sequence is empty if no sanitation was necessary for the sample.

        :param sample_idx: index of the sample in the provided sample sequence.
        :return: a `str` sequence with actions performed on the sample.
        """
        return self._sanitation_actions[self._check_index_bounds(sample_idx)]

    def _check_index_bounds(self, idx: int) -> int:
        if isinstance(idx, int):
            if idx < len(self._sanitation_actions):
                return idx
            else:
                raise ValueError(
                    f"Sample index {idx} out of bounds for output of validation of {len(self._sanitation_actions)} samples"
                )
        else:
            raise ValueError(f"sample index must be an `int` but was {type(idx)}")


def sanitize_samples(
    samples: typing.Iterable[Sample],
    hpo: hpotk.MinimalOntology,
    threshold: Controversy = Controversy.HIGH,
) -> SampleSanitationResult:
    """
    A utility function to sanitize `samples`. The sanitation actions with controversy below the `threshold`
    will be applied automatically.

    The function iterates over the samples and reports the progress on standard output.
    If there is a need for sanitation action with a controversy at or above `threshold`, the function presents the user
    with options and asks for the action code. The action *must* be taken, otherwise the sanitation quits and
    the results, including sanitized samples, will *not* be obtained.

    The sanitation workflow may take a considerable time if there are many highly controversial issues with the samples.
    The results are not available until all issues are resolved, so please plan accordingly.

    :param samples: an iterable with samples to sanitize.
    :param hpo: an HPO ontology.
    :param threshold: the controversy threshold to apply.
    :return: sanitation results in :class:`SanitizedSamples` container.
    """
    sanitizer = SimpleSampleSanitizer(hpo)

    sanitized = []
    sample_actions = []
    for i, sample in enumerate(samples):
        sanitation = sanitizer.sanitize(sample)
        actions = []

        header_printed = False
        for suggestion in sanitation:
            if not header_printed:
                header_printed = True

            if suggestion.controversy.at_or_above_threshold(threshold):
                while True:
                    code = input(suggestion.prepare_prompt())
                    if code in suggestion.codes():
                        break
                    else:
                        print("Please try again")
            else:
                code = suggestion.get_default_action_code()

            if code is None:
                raise ValueError(
                    f"BUG: unable to proceed with sanitation of {sample.labels}. Please report to developers."
                )

            suggestion.perform(code)
            action = suggestion.action_by_code(code)
            if action:
                actions.append(action.name)

        sanitized.append(sanitation.sample)
        sample_actions.append(tuple(actions))

    return SampleSanitationResult(sanitized, sample_actions)


def create_sanitizer(hpo: hpotk.MinimalOntology) -> SampleSanitizer:
    """
    Create simple sanitizer that uses HPO to sanitize samples.
    """
    return SimpleSampleSanitizer(hpo)
