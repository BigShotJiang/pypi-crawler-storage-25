import abc
import copy
import typing

import hpotk
from hpotk import MinimalOntology, TermId
from hpotk.constants.hpo.base import PHENOTYPIC_ABNORMALITY
from collections import deque

from stratiphy.model import Sample, PhenotypicFeature
from ._api import SampleSanitizer, Sanitation
from ._model import Suggestion, Action, Controversy


class TermIdWithLevel(hpotk.model.Identified):
    def __init__(self, identifier: TermId, level: int):
        self._id = identifier
        self._level = level

    @property
    def identifier(self) -> TermId:
        return self._id

    @property
    def level(self):
        return self._level

    def __repr__(self):
        return f"TermIdWithLevel(id={self._id}, level={self._level})"

    def __str__(self):
        return repr(self)


class SuggestionGenerator(metaclass=abc.ABCMeta):
    """
    `SuggestionGenerator` checks the phenotypic features in the provided sample and suggests a fix.

    ``None`` is returned if the sample is logically consistent.
    """

    @abc.abstractmethod
    def generate(self, sample: Sample) -> typing.Optional[Suggestion]:
        pass

    @staticmethod
    def _walk_present_phenotypic_features(s: Sample) -> typing.Iterable[typing.Tuple[int, TermId]]:
        return map(
            lambda d: (d[0], d[1].identifier), filter(lambda d: d[1].is_present, enumerate(s.phenotypic_features))
        )

    @staticmethod
    def _walk_excluded_phenotypic_features(s: Sample) -> typing.Iterable[typing.Tuple[int, TermId]]:
        return map(
            lambda d: (d[0], d[1].identifier), filter(lambda d: d[1].is_excluded, enumerate(s.phenotypic_features))
        )


class HpoAwareSuggestionGenerator(SuggestionGenerator, metaclass=abc.ABCMeta):
    """
    A base class for suggestion generators that need :class:`MinimalOntology` to work.
    """

    def __init__(self, hpo: MinimalOntology):
        self._hpo = hpo

    def _find_ancestor(self, query: TermId, candidates: typing.Iterable[TermId]) -> typing.Sequence[TermId]:
        """
        Test if any of the `candidates` is an ancestor of the `query` and return the ancestor(s) from the highest
        ontology level.

        For instance, for a subject annotated with *Focal clonic seizure*, *Focal-onset seizure*, and *Motor seizure*,
        the method must return both *Focal-onset seizure* and *Motor seizure* since they are at the same HPO level due
        to being children of *Seizure*.

        :param query: a term ID of interest, to figure out the ancestors for.
        :param candidates: all annotations, *including* the `query`.
        :return: a sequence of the candidate ancestors
        """
        # Let's start from the candidate and bubble up the hierarchy up to the root, recording all visited vertices.
        # These are, essentially, the ancestors of the `query`.
        visited = set(self._hpo.graph.get_ancestors(query, include_source=True))
        ancs = visited.intersection(candidates)
        if len(ancs) == 1:
            # No matches apart from `query` term, hence no ancestors, so we're done here!
            return ()

        # The sample is annotated with a query and its ancestor(s). We must find the upper level ancestors.
        # Let's descend from the root in a breadth-first manner, while keeping track of the graph level.
        current = TermIdWithLevel(self._hpo.graph.root, 0)
        queue = deque((current,))
        candidates = []
        level = None
        while queue:
            current: TermIdWithLevel = queue.popleft()
            if level is not None and current.level > level:
                # `level` is not `None` if we found a hit before. If the node is on a level above the first hit,
                # then it cannot be what we're looking for because we're doing breadth-first search, and we found
                # a node on above level. Therefore, we can break.
                break
            if current.identifier in ancs:
                if level is None:
                    # This is the level of the first (and possibly more) candidates.
                    level = current.level
                if level == current.level:
                    candidates.append(current.identifier)

            for child in self._hpo.graph.get_children(current):
                if child in visited:
                    # We don't need to traverse the entire HPO graph, only the ancestors of the `query`.
                    queue.append(TermIdWithLevel(child, current.level + 1))

        return candidates

    def _get_term_name_uppercase(self, identifier: TermId) -> str:
        return self._hpo.get_term(identifier).name.upper()

    @staticmethod
    def _index_of_feature(feature: TermId, sample: Sample) -> int:
        for idx, pf in enumerate(sample.phenotypic_features):
            if feature == pf.identifier:
                # TODO - this can lead to an issue if the sample has a term ID in both states - present and excluded.
                #  Finding the first one is all we do here!
                return idx
        raise ValueError(f"{feature} is not among phenotypic features of subject `{sample.labels}`")

    @staticmethod
    def _remove_some(
        code_to_remove: typing.Mapping[str, typing.Iterable[int]], sample: Sample
    ) -> typing.Callable[[str], None]:
        def _impl(code: str):
            try:
                indices_to_remove = code_to_remove[code]
            except KeyError:
                # Likely a programming error!
                raise ValueError(f"Unexpected code {code}")
            for i in sorted(indices_to_remove, reverse=True):
                sample.delete_feature_at(i)

        return _impl

    def _build_actions_and_handler(
        self, sample: Sample, corpus: typing.Collection[TermId]
    ) -> typing.Tuple[typing.Sequence[Action], typing.Callable[[str], None]]:
        """
        Implementation note: the first `corpus` item is set as the default action. The calling code must ensure the `corpus`
        is appropriately sorted.
        """
        actions = []
        code_to_remove = {}
        action_names = set()  # To ensure we report an action/suggestion only once.
        idx = 0
        for item in corpus:
            # We must get rid of all ancestors and descendants, and we propose to keep the rest.
            to_remove = list(filter(lambda d: d in corpus, self._hpo.graph.get_ancestors(item)))
            to_remove.extend(filter(lambda d: d in corpus, self._hpo.graph.get_descendants(item)))
            to_keep = tuple(filter(lambda t: t not in to_remove, corpus))

            to_keep_names = ", ".join(sorted(map(self._get_term_name_uppercase, to_keep)))
            if len(to_remove) == (len(corpus) - 1):
                if len(to_remove) == 1:
                    to_remove_names = self._get_term_name_uppercase(to_remove[0])
                else:
                    to_remove_names = "the rest"
            else:
                to_remove_names = ", ".join(sorted(map(self._get_term_name_uppercase, to_remove)))

            name = f"keep {to_keep_names} and remove {to_remove_names}."
            if name not in action_names:
                actions.append(Action(str(idx), name, is_default=idx == 0))
                code_to_remove[str(idx)] = map(lambda t: self._index_of_feature(t, sample), to_remove)
                action_names.add(name)
                idx += 1

        handler = self._remove_some(code_to_remove, sample)
        return actions, handler


class UnknownFeatureSuggestionGenerator(HpoAwareSuggestionGenerator):
    """
    `UnknownFeatureSuggestionGenerator` suggests replacement of the term IDs that are not in the version of HPO which
    is in use in the suggestion generator.
    """

    TITLE = "Unknown term id"

    def generate(self, sample: Sample) -> typing.Optional[Suggestion]:
        """
        Go through all phenotypic features and suggest removal of the phenotypic feature with an unknown term ID or
        replacing of the term ID with a CURIE from the current ontology.

        :return: a suggestion if there is still work to do or `None` if all features were checked to use OK IDs.
        """
        for pf in sample.phenotypic_features:
            term = self._hpo.get_term(pf.identifier)
            if term is None:
                # Phenotypic feature `pf` has a term from a newer ontology version.
                message = (
                    f"Sample `{sample.labels}` is annotated with '{pf.identifier}' which is not a term as of HPO v{self._hpo.version}. "
                    f"The term id is either wrong or it corresponds to a term introduced in a later HPO version. "
                    f"We can remove the term ID or replace it with a similar term ID.\n"
                    f"Remove the ID '{pf.identifier}'?"
                )
                actions = (
                    Action("y", f"remove the term ID '{pf.identifier}'", is_default=True),
                    # This will just loop ad infinitum as of now, until the user finally chooses `y`.
                    Action("n", "replace with a similar term ID"),
                )
                handler = self._remove_or_replace_with_another(sample, pf)

                return Suggestion(self.TITLE, message, Controversy.HIGH, actions, handler)

        return None

    @staticmethod
    def _remove_or_replace_with_another(
        sample: Sample,
        pf: PhenotypicFeature,
    ) -> typing.Callable[[str], None]:
        def _impl(code: str):
            if code == "y":
                idx = HpoAwareSuggestionGenerator._index_of_feature(pf.identifier, sample)
                sample.delete_feature_at(idx)
            elif code == "n":
                while True:
                    curie = input("Provide CURIE for new term: ")
                    try:
                        pf.identifier = TermId.from_curie(curie)
                        break
                    except ValueError as ve:
                        print(f"Sorry, {curie} did not work: {ve.args}")
                        print("Let's try one more time")
            else:
                raise ValueError(f"Unexpected code {code}")

        return _impl


class ObsoleteFeatureSuggestionGenerator(HpoAwareSuggestionGenerator):
    """
    `ObsoleteFeatureSuggestionGenerator` suggests replacement of the obsolete term IDs with the current IDs.
    """

    TITLE = "Obsolete term id"

    def generate(self, sample: Sample) -> typing.Optional[Suggestion]:
        """
        Go through all phenotypic features and suggest replacement with the current term ID if the feature uses
        an obsolete ID.

        :return: a suggestion if there is still work to do or `None` if all features were checked to use current IDs.
        """
        for pf in sample.phenotypic_features:
            term = self._hpo.get_term(pf.identifier)
            if term.identifier != pf.identifier:
                # suggest replacement
                message = (
                    f"Sample `{sample.labels}` is annotated with '{pf.identifier}' "
                    f"- an obsolete term ID for {term.name.upper()}. "
                    f"Replace with the current ID '{term.identifier}'?"
                )
                actions = (
                    Action("y", f"replace with current id '{term.identifier}'", is_default=True),
                    # This will just loop ad infinitum as of now, until the user finally chooses `y`.
                    Action("n", "keep the obsolete ID"),
                )
                handler = self._replace_with_primary(pf, term.identifier)

                return Suggestion(self.TITLE, message, Controversy.NONE, actions, handler)

        return None

    @staticmethod
    def _replace_with_primary(
        pf: PhenotypicFeature,
        replacement: TermId,
    ) -> typing.Callable[[str], None]:
        def _impl(code: str):
            if code == "y":
                pf.identifier = replacement
            elif code == "n":
                pass
            else:
                raise ValueError(f"Unexpected code {code}")

        return _impl


class PhenotypicAbnormalitySuggestionGenerator(HpoAwareSuggestionGenerator):
    """
    Phenotypic abnormality suggestion generator checks that all phenotypic features are descendants
    of the Phenotypic abnormality.

    The suggestions are of *no* :class:`Controversy`.
    """

    TITLE = "Not a phenotypic abnormality"

    def generate(self, sample: Sample) -> typing.Optional[Suggestion]:
        for idx, pf in enumerate(sample.phenotypic_features):
            if not any(
                (
                    ancestor == PHENOTYPIC_ABNORMALITY
                    for ancestor in self._hpo.graph.get_ancestors(pf, include_source=True)
                )
            ):
                term = self._hpo.get_term(pf.identifier)
                # suggest dropping
                message = (
                    f"Subject {sample.labels} is annotated with '{term.name}' "
                    "which is not a phenotypic feature (a descendant of Phenotypic abnormality). "
                    "Should we remove it?"
                )
                actions = (Action("y", f"remove {term.name}", is_default=True), Action("n", f"keep {term.name}"))
                code_to_remove = {"y": (idx,), "n": ()}
                handler = self._remove_some(code_to_remove, sample)

                return Suggestion(self.TITLE, message, Controversy.NONE, actions, handler)

        return None


class ExcludedFeatureSuggestionGenerator(HpoAwareSuggestionGenerator):
    """
    `ExcludedFeatureSuggestionGenerator` points out logical inconsistencies between a subset or all excluded features
    and suggests fix.

    The suggestions are of *small* :class:`Controversy`.
    """

    TITLE = "Excluded feature inconsistency"

    def __init__(self, hpo: MinimalOntology):
        super().__init__(hpo)
        self._checked = set()

    def generate(self, sample: Sample) -> typing.Optional[Suggestion]:
        all_excluded_feature_ids = frozenset(sample.excluded_phenotypic_feature_ids())
        for idx, excluded_feature_id in self._walk_excluded_phenotypic_features(sample):
            if excluded_feature_id in self._checked:
                # We checked before that `excluded_feature_id` has no ancestors or descendants among the excluded features.
                continue

            ancestors = self._find_ancestor(excluded_feature_id, all_excluded_feature_ids)
            if len(ancestors) > 0:
                # The original seed annotation had an excluded ancestor, therefore a conflict must be resolved.
                # Let's generate the suggestions.
                return self._generate_suggestion(ancestors, sample)
            else:
                # The loop above did not find any ancestor of the `current` annotation.
                # Therefore, it makes no point to use it as a seed term again.
                self._checked.add(excluded_feature_id)

        return None

    def _generate_suggestion(self, ancestors: typing.Sequence[TermId], sample: Sample) -> Suggestion:
        excluded_feature_ids = set(sample.excluded_phenotypic_feature_ids())
        corpus = list(ancestors)
        for ancestor in ancestors:
            for descendant in self._hpo.graph.get_descendants(ancestor):
                if descendant in excluded_feature_ids and descendant not in corpus:
                    corpus.append(descendant)

        seed_names = ", ".join(map(self._get_term_name_uppercase, ancestors))
        candidate_names = ", ".join(
            map(lambda t: self._hpo.get_term(t).name.upper(), filter(lambda t: t not in ancestors, corpus))
        )
        msg = (
            f"Subject `{sample.labels}` cannot be annotated with excluded {seed_names} and the "
            f"excluded descendant(s): {candidate_names}.\n"
            f"Only some term(s) can be kept. Which ones?"
        )

        actions, handler = self._build_actions_and_handler(sample, corpus)

        return Suggestion(self.TITLE, msg, Controversy.SMALL, actions, handler)


class PresentFeatureSuggestionGenerator(HpoAwareSuggestionGenerator):
    """
    `PresentFeatureSuggestionGenerator` points out inconsistencies between the present phenotypic features.

    The suggestions are of *small* :class:`Controversy`.
    """

    TITLE = "Present feature inconsistency"

    def __init__(self, hpo: MinimalOntology):
        super().__init__(hpo)
        self._checked = set()

    def generate(self, sample: Sample) -> typing.Optional[Suggestion]:
        all_present_feature_ids = frozenset(sample.observed_phenotypic_feature_ids())
        for idx, present_feature_id in self._walk_present_phenotypic_features(sample):
            if present_feature_id in self._checked:
                # We checked before that `present_feature_id` has no ancestors or descendants among the excluded features.
                continue

            ancestors = self._find_ancestor(present_feature_id, all_present_feature_ids)
            if len(ancestors) > 0:
                # The `present_feature_id` had an ancestor, therefore a conflict must be resolved.
                # Let's generate the sugestions.
                return self._generate_suggestion(ancestors, sample)
            else:
                # The loop above did not find any ancestor of the `current` annotation.
                # Therefore, it makes no point to use it as a seed term again.
                self._checked.add(present_feature_id)

        return None

    def _generate_suggestion(self, ancestors: typing.Sequence[TermId], sample: Sample) -> Suggestion:
        present_feature_ids = set(sample.observed_phenotypic_feature_ids())
        # Note that by definition, the ancestors *are* on the same level.
        # Now, let's find the most specific term(s) - the term(s) that are furthest away from the ancestors.
        seed_ids = self._find_deepest_descendants(ancestors, present_feature_ids)

        # candidate_ids include seed_ids and their ancestors
        candidate_ids = self._prepare_item_corpus(seed_ids, present_feature_ids)

        seed_names = ", ".join(sorted(map(self._get_term_name_uppercase, seed_ids)))
        candidate_names = ", ".join(
            sorted(
                map(lambda t: self._hpo.get_term(t).name.upper(), filter(lambda t: t not in seed_ids, candidate_ids))
            )
        )
        msg = (
            f"Subject `{sample.labels}` cannot be annotated with {seed_names} and the "
            f"ancestor(s): {candidate_names}.\n"
            f"Only some term(s) can be kept. Which ones?"
        )

        actions, handler = self._build_actions_and_handler(sample, candidate_ids)
        return Suggestion(self.TITLE, msg, Controversy.SMALL, actions, handler)

    def _find_deepest_descendants(
        self, ancestors: typing.Sequence[TermId], present_feature_ids: typing.Container[TermId]
    ) -> typing.Collection[TermId]:
        """
        Perform a breadth-first search where we start from the `ancestors` and we keep track of the minimum number
        of steps to get into an item from `present_feature_ids`.
        """
        steps = {}
        queue = deque(map(lambda anc: TermIdWithLevel(anc, 0), ancestors))
        while queue:
            current = queue.popleft()
            if current.identifier in present_feature_ids:
                n_steps = steps.get(current.identifier, current.level)
                # We take the shortest path from any ancestor to the current node.
                steps[current.identifier] = min(n_steps, current.level)

            for child in self._hpo.graph.get_children(current):
                queue.append(TermIdWithLevel(child, current.level + 1))

        max_level = max(steps.values())
        return list((term_id for term_id, level in steps.items() if level == max_level))

    def _prepare_item_corpus(
        self, descendants: typing.Iterable[TermId], present_feature_ids: typing.Container[TermId]
    ) -> typing.Sequence[TermId]:
        items = list(descendants)
        ancestors = set()
        for item in items:
            ancestors.update(filter(lambda a: a in present_feature_ids, self._hpo.graph.get_ancestors(item)))
        items.extend(sorted(ancestors))

        return items


class ExcludedPresentFeaturesSuggestionGenerator(HpoAwareSuggestionGenerator):
    """
    Check if `Sample` is annotated with an excluded feature and the same feature in present status,
    or with one or more observed descendant(s).
    """

    TITLE = "Present vs. excluded inconsistency"

    def __init__(self, hpo: MinimalOntology):
        super().__init__(hpo)
        self._checked_excluded: typing.Set[TermId] = set()

    def generate(self, sample: Sample) -> typing.Optional[Suggestion]:
        for ef_idx, ex_pf in enumerate(sample.phenotypic_features):
            if ex_pf.is_present or ex_pf.identifier in self._checked_excluded:
                continue

            present_indices = []
            for i, obs_pf in enumerate(sample.phenotypic_features):
                if obs_pf.is_present and (
                    obs_pf.identifier == ex_pf.identifier or self._hpo.graph.is_ancestor_of(ex_pf, obs_pf)
                ):
                    present_indices.append(i)

            if present_indices:
                # suggest removal of the observed or the excluded feature
                observed_ids = tuple(sample.phenotypic_features[i].identifier for i in present_indices)
                present_msg = self._concat_term_names(observed_ids)
                excluded_name = self._hpo.get_term(ex_pf).name.upper()
                message = (
                    f"Subject {sample.labels} is annotated with present {present_msg} which "
                    f"is logically inconsistent with the exclusion of {excluded_name} "
                    f"because exclusion of {excluded_name} also implies exclusion of its descendants, "
                    f"including {present_msg}"
                )
                actions = (
                    Action("p", "Keep the present feature(s): " + present_msg),
                    Action("e", "Keep excluded " + excluded_name),
                )

                handler = self._remove_term_groups(sample, present_indices, (ef_idx,))

                return Suggestion(self.TITLE, message, Controversy.HIGH, actions, handler)

            self._checked_excluded.add(ex_pf.identifier)  # We won't look at this one again

    def _concat_term_names(self, observed_ids: typing.Collection[TermId]):
        if len(observed_ids) == 1:
            return self._hpo.get_term(next(iter(observed_ids))).name.upper()
        elif len(observed_ids) == 2:
            return " and ".join(map(lambda t: self._hpo.get_term(t).name.upper(), observed_ids))
        else:
            join = ", ".join(map(lambda t: self._hpo.get_term(t).name.upper(), observed_ids))
            ridx = join.rfind(",")
            return join[:ridx] + ", and" + join[ridx + 1 :]

    @staticmethod
    def _remove_term_groups(
        sample: Sample, present_idx: typing.Iterable[int], excluded_idx: typing.Iterable[int]
    ) -> typing.Callable[[str], None]:
        # NOTE: we always must remove the largest index first to prevent shifting of items in the list,
        # hence `reverse` below.
        def _impl(code: str):
            if code == "p":
                # Keeping the present, hence removing the excluded.
                for i in sorted(excluded_idx, reverse=True):
                    sample.delete_feature_at(i)
            elif code == "e":
                # Keeping the excluded, hence removing the present.
                for i in sorted(present_idx, reverse=True):
                    sample.delete_feature_at(i)
            else:
                raise ValueError(f"Unexpected code {code}")

        return _impl


class SuggestionProvider(typing.Iterator[Suggestion]):
    """
    Provides suggestions with fixes for found issues.

    First, the provider checks if all term IDs are in fact in the HPO. Then, the obsolete term IDs are mapped
    to the current versions. Then, we check if all features represent Phenotypic abnormalities
    (not modes of inheritance, modifier, etc.).
    Last, we resolve issues between the excluded features, the issues between excluded and present features,
    and the issues between the present features.
    """

    def __init__(self, hpo: MinimalOntology, sample: Sample):
        self._sample = sample
        self._unknown = UnknownFeatureSuggestionGenerator(hpo)
        self._obsolete = ObsoleteFeatureSuggestionGenerator(hpo)
        self._non_phenotypic_abnormality = PhenotypicAbnormalitySuggestionGenerator(hpo)
        self._excluded = ExcludedFeatureSuggestionGenerator(hpo)
        self._excluded_present = ExcludedPresentFeaturesSuggestionGenerator(hpo)
        self._present = PresentFeatureSuggestionGenerator(hpo)

    def __next__(self) -> Suggestion:
        suggestion = self._unknown.generate(self._sample)
        if suggestion is not None:
            return suggestion

        suggestion = self._obsolete.generate(self._sample)
        if suggestion is not None:
            return suggestion

        suggestion = self._non_phenotypic_abnormality.generate(self._sample)
        if suggestion is not None:
            return suggestion

        suggestion = self._excluded.generate(self._sample)
        if suggestion is not None:
            return suggestion

        suggestion = self._excluded_present.generate(self._sample)
        if suggestion is not None:
            return suggestion

        suggestion = self._present.generate(self._sample)
        if suggestion is not None:
            return suggestion

        raise StopIteration


class SimpleSanitation(Sanitation):
    """
    A `Sanitation` implementation that uses :class:`SuggestionProvider` and :class:`Sample`.
    """

    def __init__(self, hpo: MinimalOntology, sample: Sample):
        self._hpo = hpo
        # We must not modify the inputted sample.
        self._sample = copy.copy(sample)

    def __iter__(self) -> typing.Iterator[Suggestion]:
        return SuggestionProvider(self._hpo, self._sample)

    @property
    def sample(self) -> Sample:
        """
        Get the :class:`Sample` with the updates.
        """
        return self._sample


class SimpleSampleSanitizer(SampleSanitizer):
    def __init__(self, hpo: MinimalOntology):
        self._hpo = hpotk.util.validate_instance(hpo, MinimalOntology, "hpo")

    def sanitize(self, sample: Sample) -> Sanitation:
        return SimpleSanitation(self._hpo, sample)
