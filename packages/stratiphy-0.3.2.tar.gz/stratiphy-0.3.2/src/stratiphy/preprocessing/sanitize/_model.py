"""
The model classes of the `sanitation` module.
"""

import enum
import os
import typing


class Controversy(enum.Enum):
    """
    `Controversy` rates the risk of choosing an incorrect :class:`Action` to fix an issue in the :class:`stratiphy.model.Sample`.
    """

    NONE = 1
    """
    The action is not controversial at all and should always be performed. 
    """

    SMALL = 2
    """
    The action is a little controversial but still can be performed automatically even in strict scenarios.
    """

    MODERATE = 3
    """
    The action is somewhat controversial but can be performed automatically in lenient scenarios. 
    """

    HIGH = 4
    """
    The action is controversial and must *always* be consulted with the user before proceeding further!
    """

    @property
    def emo(self) -> str:
        """
        Get the emoticon for this controversy level (e.g. 😱 for ``Controversy.HIGH``).
        """
        if self == Controversy.HIGH:
            return "😱"
        elif self == Controversy.MODERATE:
            return "😧"
        elif self == Controversy.SMALL:
            return "🤔"
        elif self == Controversy.NONE:
            return "😎"
        else:
            # Should be
            raise ValueError(f"Unknown controversy {self}")

    def at_or_above_threshold(self, threshold) -> bool:
        """
        Test if the controversy is at or above the provided `threshold`.

        :param threshold: the threshold value.
        :return: a `bool` with the result or `NotImplemented` if `threshold` is not an instance of `Controversy`.
        """
        if isinstance(threshold, Controversy):
            return self.value >= threshold.value
        return NotImplemented


class Action:
    """
    `Action` represents an activity that can be taken to fix an issue with a :class:`stratiphy.model.Sample`.

    `Action` has a :attr:`code` - a `str` for unique identification of the action in the context
    of the enclosing `Suggestion`.
    The action is described by its :attr:`name`.
    At most one of the actions :attr:`is_default` and can be performed automatically if the :class:`Controversy` of the enclosing `Suggestion` is below user-provided threshold.
    """

    def __init__(
        self,
        code: str,
        name: str,
        is_default: bool = False,
    ):
        assert isinstance(code, str)
        self._code = code

        assert isinstance(name, str)
        self._name = name

        assert isinstance(is_default, bool)
        self._is_default = is_default

    @property
    def code(self) -> str:
        """
        Get the action code (e.g. `0`, `1`, `y`, `n`, ...).
        """
        return self._code

    @property
    def name(self) -> str:
        """
        Get the description of the action (e.g. *Keep HIGH MYOPIA and remove MYOPIA*).
        """
        return self._name

    @property
    def is_default(self) -> bool:
        """
        Return `True` if this action is the default action or `False` otherwise.
        """
        return self._is_default

    def __hash__(self):
        return hash((self._code, self._name, self._is_default))

    def __eq__(self, other):
        return (
            isinstance(other, Action)
            and self.code == other.code
            and self.name == other.name
            and self.is_default == other.is_default
        )

    def __repr__(self):
        return f"Action(code={self._code}, name={self._name}, is_default={self._is_default})"

    def __str__(self):
        return repr(self)


def prepare_default_action(actions: typing.Iterable[Action]) -> typing.Optional[str]:
    code = None
    for action in actions:
        if action.is_default:
            if code is not None:
                raise ValueError("More than one default actions!")
            else:
                code = action.code

    return code


class Suggestion:
    """
    `Suggestion` represents an issue found in a `Sample`, the level of :class:`Controversy` of the issue,
    and a collection of :class:`Action` objects that can be taken to fix it.

    There must be 2 or more actions to choose from, otherwise it makes no sense to make the suggestion, right?
    Also, at most 1 action must be marked as *default*.
    """

    def __init__(
        self,
        title: str,
        message: str,
        controversy: Controversy,
        actions: typing.Collection[Action],
        handler: typing.Callable[[str], None],
    ):
        self._title = title
        self._message = message
        self._controversy = controversy
        self._actions = self._check_actions(actions)
        self._default_action = prepare_default_action(actions)
        self._handler = handler

    @staticmethod
    def _check_actions(actions: typing.Collection[Action]):
        if len(actions) < 2:
            raise ValueError(f"There must be at least 2 actions to choose from but we got {len(actions)}!")
        codes = set()
        for action in actions:
            if action.code in codes:
                raise ValueError(f"Non-unique code {action.code} in action {action}")
            codes.add(action.code)
        return tuple(actions)

    @property
    def title(self) -> str:
        """
        Get the title of the issue.
        """
        return self._title

    @property
    def message(self) -> str:
        """
        Get the message with the issue description.
        """
        return self._message

    @property
    def controversy(self) -> Controversy:
        """
        Get the controversy of the issue.
        """
        return self._controversy

    @property
    def actions(self) -> typing.Sequence[Action]:
        """
        Get a sequence of actions available to fix the suggestion.
        """
        return self._actions

    def action_by_code(self, code: str) -> typing.Optional[Action]:
        """
        Get the :class:`Action` corresponding to given `code`.

        :returns: the `Action` or `None` if no `Action` with the `code` exists .
        """
        for action in self._actions:
            if action.code == code:
                return action
        return None

    def codes(self) -> typing.Generator[str, None, None]:
        """
        Get a generator with the action condes.

        :return: the generator with action codes.
        """
        return (a.code for a in self._actions)

    def _choices(self) -> str:
        return os.linesep.join((f" - [{a.code}] {a.name}" for a in self._actions))

    def _codes(self) -> str:
        return "[" + "/".join((a.code for a in self._actions)) + "]"

    def prepare_prompt(self) -> str:
        """
        Prepare prompt consisting of the

        :return: a prompt `str`.
        """
        return f"""{self._controversy.emo} {self._title}

{self._message}

Your choices are:
{self._choices()}
{self._codes()}: """

    def perform(self, code: str):
        """
        Perform the action associated with the action `code`.
        """
        self._handler(code)

    def get_default_action_code(self) -> typing.Optional[str]:
        """
        Get the code of the default action.

        :return: the code `str` or `None` if no action is set as default.
        """
        return self._default_action

    def __repr__(self):
        return (
            f"Suggestion(title={self._title}, "
            f"message={self._message}, "
            f"controversy={self._controversy}, "
            f"actions={self._actions}, "
            f"handler={self._handler})"
        )

    def __str__(self):
        return (
            f"Suggestion(title={self._title}, "
            f"message={self._message}, "
            f"controversy={self._controversy}, "
            f"actions={self._actions})"
        )
