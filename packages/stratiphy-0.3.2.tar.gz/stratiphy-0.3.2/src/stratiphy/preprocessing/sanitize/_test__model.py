import pytest

from hpotk import TermId

from stratiphy.model import SampleLabels, Sample, PhenotypicFeature

from ._model import Controversy


class TestSanitizeModel:
    """
    Tests of non-public types such as :class:`MutableSample` or :class:`MutablePhenotypicFeature`.
    """

    @pytest.fixture(scope="function")  # !!
    def sample(self) -> Sample:
        return Sample.from_raw_parts(
            labels=SampleLabels("A"),
            phenotypic_features=(
                # Focal clonic seizure
                PhenotypicFeature.from_values(TermId.from_curie("HP:0002266"), True),
                # Arachnodactyly
                PhenotypicFeature.from_values(TermId.from_curie("HP:0001166"), True),
            ),
        )

    def test_replace_term_id_at(
        self,
        sample: Sample,
    ):
        assert sample.phenotypic_features[0].identifier.value == "HP:0002266"

        sample.replace_term_id_at(TermId.from_curie("HP:0001250"), 0)  # Seizure
        assert sample.phenotypic_features[0].identifier.value == "HP:0001250"

    def test_replace_term_id_at__throws_when_out_of_bounds(
        self,
        sample: Sample,
    ):
        with pytest.raises(ValueError) as e:
            sample.replace_term_id_at(TermId.from_curie("HP:0001250"), -1)
        assert e.value.args == ("i must be an int in range [0, 2) but was -1",)

        with pytest.raises(ValueError) as e:
            sample.replace_term_id_at(TermId.from_curie("HP:0001250"), 2)
        assert e.value.args == ("i must be an int in range [0, 2) but was 2",)

        with pytest.raises(ValueError) as e:
            # noinspection PyTypeChecker
            sample.replace_term_id_at(TermId.from_curie("HP:0001250"), 1.0)
        assert e.value.args == ("i must be an int in range [0, 2) but was 1.0",)

    @pytest.mark.parametrize(
        "indices,expected_len",
        [
            ((0,), 1),
            ((1,), 1),
            ((1, 0), 0),
            ((0, 0), 0),
        ],
    )
    def test_delete_feature_at(
        self,
        sample: Sample,
        indices,
        expected_len,
    ):
        assert len(sample.phenotypic_features) == 2
        for idx in indices:
            sample.delete_feature_at(idx)
        assert len(sample.phenotypic_features) == expected_len

    @pytest.mark.parametrize("idx", [(-1,), (2,)])
    def test_delete_feature_at__throws_when_out_of_bounds(
        self,
        sample: Sample,
        idx,
    ):
        assert len(sample.phenotypic_features) == 2
        with pytest.raises(ValueError) as e:
            sample.delete_feature_at(idx)

        assert e.value.args == (f"i must be an int in range [0, 2) but was {idx}",)

    @pytest.mark.parametrize(
        "curie,is_present,expected",
        [
            ("HP:1", True, True),
            ("HP:1", False, False),
            ("HP:2", True, False),
            ("HP:2", False, True),
            ("HP:3", True, True),
            ("HP:3", False, False),
            ("HP:4", True, False),
            ("HP:4", False, True),
        ],
    )
    def test_delete_feature(self, curie: str, is_present: bool, expected: bool):
        term_id = TermId.from_curie(curie)
        sample = Sample.from_raw_parts(
            SampleLabels("A"),
            (
                PhenotypicFeature.from_values(TermId.from_curie("HP:1"), True),
                PhenotypicFeature.from_values(TermId.from_curie("HP:2"), False),
                PhenotypicFeature.from_values(TermId.from_curie("HP:3"), True),
                PhenotypicFeature.from_values(TermId.from_curie("HP:4"), False),
            ),
        )

        if expected:
            iterator = sample.observed_phenotypic_features() if is_present else sample.excluded_phenotypic_features()
            assert any(term_id == pf.identifier for pf in iterator)

        actual = sample.delete_feature(term_id, is_present)
        assert actual == expected

        if expected:
            iterator = sample.observed_phenotypic_features() if is_present else sample.excluded_phenotypic_features()
            assert not any(term_id == pf.identifier for pf in iterator)

    @pytest.mark.parametrize(
        "controversy,threshold,expected",
        [
            (Controversy.NONE, Controversy.NONE, True),
            (Controversy.NONE, Controversy.SMALL, False),
            (Controversy.NONE, Controversy.MODERATE, False),
            (Controversy.NONE, Controversy.HIGH, False),
            (Controversy.SMALL, Controversy.NONE, True),
            (Controversy.SMALL, Controversy.SMALL, True),
            (Controversy.SMALL, Controversy.MODERATE, False),
            (Controversy.SMALL, Controversy.HIGH, False),
            (Controversy.MODERATE, Controversy.NONE, True),
            (Controversy.MODERATE, Controversy.SMALL, True),
            (Controversy.MODERATE, Controversy.MODERATE, True),
            (Controversy.MODERATE, Controversy.HIGH, False),
            (Controversy.HIGH, Controversy.NONE, True),
            (Controversy.HIGH, Controversy.SMALL, True),
            (Controversy.HIGH, Controversy.MODERATE, True),
            (Controversy.HIGH, Controversy.HIGH, True),
        ],
    )
    def test_compare_controversy(
        self,
        controversy: Controversy,
        threshold: Controversy,
        expected: bool,
    ):
        assert controversy.at_or_above_threshold(threshold) == expected
