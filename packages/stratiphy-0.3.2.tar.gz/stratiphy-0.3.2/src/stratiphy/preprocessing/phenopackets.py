import os
import io
import pathlib
import typing

from hpotk import TermId
from google.protobuf.message import Message
from google.protobuf.json_format import Parse
from phenopackets.schema.v2.phenopackets_pb2 import Phenopacket, Cohort

from stratiphy.model import Sample, PhenotypicFeature, SampleLabels


_MESSAGE = typing.TypeVar("_MESSAGE", bound=Message)
"""
A generic type that extends Protobuf's `Message`.
"""


def read_phenopacket_dir(
    pp_dir: typing.Union[str, pathlib.Path],
) -> typing.Sequence[Sample]:
    """
    Transform phenopackets located in the `pp_dir` directory into samples.

    Note, the function considers only the JSON files located in the directory.

    **Example**

    Let's load two test phenopackets from `docs/data/phenopackets`.

    >>> import os
    >>> pp_dir = os.path.join('docs', 'data', 'phenopackets')


    >>> from stratiphy.preprocessing.phenopackets import read_phenopacket_dir
    >>> cohort = read_phenopacket_dir(pp_dir)
    >>> len(cohort)
    2

    The loading fails if the path does not point to an existing directory:

    >>> read_phenopacket_dir('foo')
    Traceback (most recent call last):
      ...
    ValueError: Not a directory: foo

    or if no phenopackets could be loaded:

    >>> read_phenopacket_dir('docs')
    Traceback (most recent call last):
      ...
    ValueError: No phenopackets could be loaded

    :param pp_dir: path to folder with phenopacket JSON files.
    :return: sequence of samples corresponding to the phenopackets.
    :raises ValueError: if no phenopackets were loaded or in case of any other loading issue.
    """
    if not os.path.isdir(pp_dir):
        raise ValueError(f"Not a directory: {pp_dir}")

    samples = []
    for entry in os.listdir(pp_dir):
        fpath = os.path.join(pp_dir, entry)
        if os.path.isfile(fpath) and fpath.endswith(".json"):
            sample = read_phenopacket(fpath)
            samples.append(sample)

    if len(samples) == 0:
        raise ValueError("No phenopackets could be loaded")

    return samples


def read_phenopacket(
    phenopacket: typing.Union[Phenopacket, pathlib.Path, str],
) -> Sample:
    """
    Read phenopacket into a :class:`stratiphy.model.Sample`.

    .. note::

      The function works only in the `full` stratiphy mode.
      See the :ref:`FAQ <rstfaq-installation-modes>` section for more info.

    :param phenopacket: a Phenopacket object, or a path to a phenopacket JSON file.
    :return: the parsed sample
    :raises: IOError in case of IO issues or a ValueError if the input is not a proper `Phenopacket`
    """
    if isinstance(phenopacket, (str, pathlib.Path)):
        phenopacket = _read_protobuf_message(phenopacket, Phenopacket())
    elif isinstance(phenopacket, Phenopacket):
        pass
    else:
        raise ValueError(f"Expected a `Phenopacket` or a file path but got {phenopacket}")

    return _parse_phenopacket(phenopacket)


def read_cohort(
    cohort: typing.Union[Cohort, pathlib.Path, str],
) -> typing.Sequence[Sample]:
    """
    Read `cohort` into a sequence of :class:`stratiphy.model.Sample` objects.

    .. note::

      The function works only in the `full` stratiphy mode.
      See the :ref:`FAQ <rstfaq-installation-modes>` section for more info.

    :param cohort: a Cohort object or a path to a cohort JSON file.
    :return: a sequence of :class:`stratiphy.model.Sample` objects that correspond to the cohort members.
    :raises: IOError in case of IO issues or a ValueError if the input is not a proper `Cohort`.
    """
    if isinstance(cohort, (str, pathlib.Path)):
        cohort = _read_protobuf_message(cohort, Cohort())
    elif isinstance(cohort, Cohort):
        pass
    else:
        raise ValueError(f"Expected a `Cohort` or a file path but got {cohort}")

    return _parse_cohort(cohort)


def _read_protobuf_message(
    payload: typing.Union[typing.IO, str, pathlib.Path],
    message: _MESSAGE,
    encoding: str = "utf-8",
) -> _MESSAGE:
    """
    Read Protobuf data from ``payload`` and store in the provided ``message``.

    :param payload: a `str` pointing to a JSON file with the `message`, or the actual JSON `str`,
           or IO wrapper (either text or binary) with the JSON content.
    :param message: protobuf object to be filled with the input data.
    :param encoding: encoding to parse binary or file inputs.
    :return: the `message` parameter filled with the input data.
    """

    if isinstance(payload, (str, pathlib.Path)):
        if os.path.isfile(payload):
            with open(payload, "r", encoding=encoding) as handle:
                return _read_protobuf_message(handle, message)
        elif os.path.isdir(payload):
            raise ValueError(f"Cannot read protobuf message from a directory {payload}. Please provide a file instead")
        else:
            raise ValueError(f"Unrecognized payload {payload}")
    elif isinstance(payload, (typing.TextIO, io.TextIOBase)):
        return Parse(payload.read(), message)
    elif isinstance(payload, (typing.BinaryIO, io.BufferedIOBase)):
        return Parse(payload.read().decode(encoding), message)
    else:
        raise ValueError(
            f"Expected a path to phenopacket JSON, phenopacket JSON `str`, or an IO wrapper but got {payload}"
        )


def _parse_phenopacket(
    phenopacket: Phenopacket,
) -> Sample:
    """
    Extract the relevant parts of a phenopacket into :class:`stratiphy.model.Sample`. The function uses `subject.id` for
    the `sample.identifier` and the `type.id` and `excluded` attributes of phenopacket's `PhenotypicFeature`s
    for `sample.phenotypic_features`.

    :raises: a `ValueError` if the input is not a `Phenopacket`.
    """
    labels = SampleLabels(label=phenopacket.subject.id, meta_label=phenopacket.id)

    phenotypic_features = (
        PhenotypicFeature.from_values(
            TermId.from_curie(feature.type.id),
            is_present=not feature.excluded,
        )
        for feature in phenopacket.phenotypic_features
    )

    return Sample.from_raw_parts(labels, phenotypic_features)


def _parse_cohort(
    cohort: Cohort,
) -> typing.Sequence[Sample]:
    """
    Extract :class:`stratiphy.model.Sample`s from a `Cohort` into a sequence of `stratiphy.model.Sample`s.
    Each cohort member is transformed into one `stratiphy.model.Sample`.

    :raises: a `ValueError` if the input is not a `Cohort`.
    """
    return tuple(_parse_phenopacket(member) for member in cohort.members)
