"""
The ``stratiphy.preprocessing`` package provides several optional functions for preparing the input for the clustering.
"""
