import abc
import logging
import typing

import hpotk
from hpotk.validate import ValidationResults

from stratiphy.model import Sample


class SampleValidator(metaclass=abc.ABCMeta):
    @staticmethod
    def default_validator(hpo: hpotk.MinimalOntology):
        """
        Create a default sample validator for checking that the HPO terms are current,
        descendants of Phenotypic abnormality, and the absence of violation of the annotation propagation rule.

        :param hpo: HPO to use for the Q/C checks.
        :return: a `SampleValidator` instance.
        """
        return SimpleSampleValidator(hpo)

    @abc.abstractmethod
    def validate(self, sample: Sample) -> ValidationResults:
        """
        Validate that the sample meets Q/C requirements for consensus clustering.
        """
        pass


def validate_samples(
    validator: SampleValidator,
    samples: typing.Union[Sample, typing.Iterable[Sample]],
):
    """
    A utility function for running validation on a sample or a collection of samples.

    Any issues are printed to STDERR along with the index of the offending sample(s).
    The function prints `All n samples are OK` if all samples pass the validation.

    :param validator: the validator to use.
    :param samples: a sample or an iterable with samples to check.
    :raise ValueError: if `samples` is not an instance of `Sample` or an iterable.
    """
    if hasattr(samples, "__iter__"):
        singular = False
    elif isinstance(samples, Sample):
        samples = (samples,)
        singular = True
    else:
        raise ValueError(f"`samples` must be an iterable or an instance of `Sample` but was {type(samples)}")

    all_are_ok = True
    i = None
    for sample in samples:
        if i is None:
            i = 0
        vr = validator.validate(sample)
        if not vr.is_ok():
            all_are_ok = False
            msg = (
                f"{sample.labels} failed the validation" if singular else f"#{i}: {sample.labels} failed the validation"
            )
            print(msg)
            for result in sorted(vr.results, key=lambda res: res.message):
                print(f"{sample.labels.label_summary():<35} - {result.level.name:<5} - {result.message}")
        i += 1

    if i is None:
        print("No samples to validate!")
    elif all_are_ok:
        msg = f"Sample {samples[0].labels} is OK" if singular else f"All {i} samples are OK"
        print(msg)
    else:
        pass  # We print nothing since we reported the issues in the loop.


class SimpleSampleValidator(SampleValidator):
    """
    Simple sample validator uses `hpo-toolkit` to validate the requirements.

    Specifically, we check that:

        * all HPO terms are present in the ontology
        * all HPO terms use current (not obsolete) term ID
        * the terms are descendants of *Phenotypic abnormality* and not other HPO branches
          such as *Mode of inheritance*, *Clinical modifier*, etc.
        * the terms do not violate the annotation propagation rule

    :param hpo: hpo-toolkit's representation of Human Phenotype Ontology.
    """

    def __init__(
        self,
        hpo: hpotk.ontology.MinimalOntology,
    ):
        if not isinstance(hpo, hpotk.MinimalOntology):
            raise ValueError(f"`hpo` must be an instance of `hpotk.MinimalOntology` but got {type(hpo)}")
        self._hpo = hpo
        self._validation_runner = self._create_validation_runner(hpo)
        self._logger = logging.getLogger(__name__)

    def validate(
        self,
        sample: Sample,
    ) -> hpotk.validate.ValidationResults:
        """
        Perform initial Q/C on the samples to ensure the data has no logical errors and meets the requirement.

        :return: a mapping with list of :class:`hpotk.validate.ValidationResult` per sample label. Only labels
          with failing samples are present
        """
        missing_terms = self._check_missing_terms(sample)
        if len(missing_terms) > 0:
            # We cannot proceed with the validation if we have an unknown term ID in the sample
            return hpotk.validate.ValidationResults(missing_terms)
        else:
            # Run other validators
            return self._validation_runner.validate_all(sample.phenotypic_features)

    @staticmethod
    def _create_validation_runner(
        hpo: hpotk.ontology.MinimalOntology,
    ) -> hpotk.validate.ValidationRunner:
        runners = (
            hpotk.validate.ObsoleteTermIdsValidator(hpo),
            hpotk.validate.PhenotypicAbnormalityValidator(hpo),
            hpotk.validate.AnnotationPropagationValidator(hpo),
        )

        return hpotk.validate.ValidationRunner(runners)

    def _check_missing_terms(
        self,
        sample: Sample,
    ) -> typing.Sequence[hpotk.validate.ValidationResult]:
        missing_terms = []
        for j, pf in enumerate(sample.phenotypic_features):
            if self._hpo.get_term(pf.identifier) is None:
                # Returns `None` for unknown/missing term IDs
                missing_result = hpotk.validate.ValidationResult(
                    hpotk.validate.ValidationLevel.ERROR,
                    "missing_term",
                    f"Term ID {pf.identifier.value} (#{j} in {sample.labels}) "
                    f"is not present in HPO v{self._hpo.version}",
                )
                missing_terms.append(missing_result)

        return missing_terms
