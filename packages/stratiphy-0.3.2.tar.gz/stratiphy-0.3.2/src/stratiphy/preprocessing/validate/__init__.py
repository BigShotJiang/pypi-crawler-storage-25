"""
The ``stratiphy.preprocessing.validate`` package provides QC checks to ensure the input data meet the requirements.
"""

from ._base import SampleValidator, validate_samples

__all__ = ["SampleValidator", "validate_samples"]
