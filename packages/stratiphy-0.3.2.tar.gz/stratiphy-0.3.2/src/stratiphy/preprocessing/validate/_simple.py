import warnings


warnings.warn(
    "SimpleSampleValidator has been deprecated. "
    "Obtain the validator by calling `SampleValidator.default_validator` instead",
    DeprecationWarning,
    stacklevel=2,
)
