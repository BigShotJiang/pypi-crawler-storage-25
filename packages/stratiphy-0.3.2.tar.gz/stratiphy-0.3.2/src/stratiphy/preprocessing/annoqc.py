import dataclasses
import typing

import hpotk

from stratiphy.model import Phenotyped


@dataclasses.dataclass(frozen=True)
class AnnotationConsistencyScore:
    """
    Includes the per-individual annotation coverage scores for a cohort.
    """

    scores: typing.Sequence[float]
    """
    Scores are non-negative values where higher means better annotation consistency.
    """

    merged_size: int
    """
    The size of the **merged set** - the union of the present HPO terms 
    (including ancestors) that annotate the cohort members.
    """

    def mean(self) -> float:
        """
        Compute the mean score.

        The mean is `NaN` if the cohort is empty
        or if all individuals are annotated only with excluded HPO terms.
        """
        return float("nan") if self.merged_size == 0 else sum(self.scores) / len(self.scores)


class AnnotationConsistency:
    """
    Compute per-individual annotation coverage scores relative to the cohort.
    """

    def __init__(
        self,
        hpo: hpotk.MinimalOntology,
    ):
        assert isinstance(hpo, hpotk.MinimalOntology)
        self._hpo = hpo

    def compute(
        self,
        cohort: typing.Sequence[Phenotyped],
    ) -> AnnotationConsistencyScore:
        corpus = set()
        for sample in cohort:
            for term_id in sample.observed_phenotypic_feature_ids():
                corpus.add(term_id)
                corpus.update(self._hpo.graph.get_ancestors(term_id))

        scores = []
        for sample in cohort:
            coverage = set()
            for pf in sample.phenotypic_features:
                coverage.add(pf.identifier)
                if pf.is_present:
                    # Observed terms: propagate upward
                    coverage.update(self._hpo.graph.get_ancestors(pf))
                else:
                    # Excluded terms: propagate downward
                    coverage.update(self._hpo.graph.get_descendants(pf))

            score = len(coverage.intersection(corpus)) / len(corpus)
            scores.append(score)

        return AnnotationConsistencyScore(
            scores=scores,
            merged_size=len(corpus),
        )
