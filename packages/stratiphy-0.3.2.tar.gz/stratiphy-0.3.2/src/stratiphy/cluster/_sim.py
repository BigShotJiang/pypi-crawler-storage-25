import abc
import typing

import hpotk.util
import numpy as np

from stratiphy.model import Phenotyped
from stratiphy.semsim import SimilarityMatrixCreator

from ._base import ClusteringAlgorithm, ClusterMembershipAware


class SimilarityMatrixClusteringResult(ClusterMembershipAware):
    """
    A container for :class:`SimilarityMatrixClustering` results.
    """

    def __init__(self, similarity_matrix: np.ndarray, cluster_labels: np.ndarray):
        self._sm = similarity_matrix
        self._cl = cluster_labels

    @property
    def similarity_matrix(self) -> np.ndarray:
        """
        Get a symmetric similarity matrix. The matrix has :math:`(n_{samples}, n_{samples})` shape.
        """
        return self._sm

    @property
    def cluster_labels(self) -> np.ndarray:
        """
        Get an array of shape :math:`(n_{samples}, )` with indices of sample cluster membership.
        """
        return self._cl

    def __eq__(self, other):
        return isinstance(other, SimilarityMatrixClusteringResult) and self._sm == other._sm and self._cl == other._cl

    def __str__(self):
        return f"SimilarityMatrixClusteringResult(cluster_labels={self._cl}, similarity_matrix={self._sm})"

    def __repr__(self):
        return str(self)


class SimilarityMatrixClustering(metaclass=abc.ABCMeta):
    """
    `SimilarityMatrixClustering` clusters a provided similarity matrix into `k` clusters.

    The similarity matrix must be a symmetric positive semi-definite real matrix with `0` denoting no similarity
    and higher values representing higher similarity.
    """

    @abc.abstractmethod
    def cluster_similarity_matrix(
        self, similarity_matrix: np.ndarray, k_clusters: int
    ) -> SimilarityMatrixClusteringResult:
        """
        Cluster the `similarity_matrix` into `k_clusters`.

        :param similarity_matrix: array of shape `(n_samples, n_samples)` with similarities between samples to cluster.
        :param k_clusters: the number of clusters to form.
        :return: :class:`SimilarityMatrixClusteringResult` with the clustering results.
        """
        pass


class SimilarityMatrixClusteringAlgorithm(ClusteringAlgorithm[SimilarityMatrixClusteringResult]):
    """
    An implementation of a clustering algorithm that starts with a similarity matrix :math:`(n_{samples}, n_{samples})`
    as opposed to a feature matrix with shape :math:`(n_{samples}, n_{features})`.
    """

    def __init__(self, sim_matrix_creator: SimilarityMatrixCreator, sim_matrix_clustering: SimilarityMatrixClustering):
        self._sim_matrix_creator = hpotk.util.validate_instance(
            sim_matrix_creator, SimilarityMatrixCreator, "sim_matrix_creator"
        )
        self._sim_matrix_clustering = hpotk.util.validate_instance(
            sim_matrix_clustering, SimilarityMatrixClustering, "sim_matrix_clustering"
        )

    @property
    def similarity_matrix_creator(self) -> SimilarityMatrixCreator:
        """
        Get the similarity matrix creator for generating similarity matrix for samples.
        """
        return self._sim_matrix_creator

    def cluster(self, samples: typing.Sequence[Phenotyped], k_clusters: int) -> SimilarityMatrixClusteringResult:
        sm = self._sim_matrix_creator.calculate_matrix(samples)
        return self._sim_matrix_clustering.cluster_similarity_matrix(sm.similarity_matrix, k_clusters)
