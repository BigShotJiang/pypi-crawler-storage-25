"""
A module with the API of the clustering for the purpose of Stratiphy as well as with the implementations
of several clustering algorithms.
"""

from ._base import ClusteringAlgorithm, ClusterMembershipAware
from ._sim import SimilarityMatrixClustering, SimilarityMatrixClusteringAlgorithm, SimilarityMatrixClusteringResult
from ._sklearn_sim import SpectralSimilarityMatrixClustering


__all__ = [
    "SpectralSimilarityMatrixClustering",
    "ClusteringAlgorithm",
    "ClusterMembershipAware",
    "SimilarityMatrixClustering",
    "SimilarityMatrixClusteringAlgorithm",
    "SimilarityMatrixClusteringResult",
]
