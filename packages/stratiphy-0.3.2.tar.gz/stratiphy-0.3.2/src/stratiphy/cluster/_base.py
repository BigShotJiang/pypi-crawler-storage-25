import abc
import typing

import numpy as np

from stratiphy.model import Phenotyped


class ClusterMembershipAware(metaclass=abc.ABCMeta):
    """
    The implementors have cluster assignments for the clustered entities.
    """

    @property
    @abc.abstractmethod
    def cluster_labels(self) -> np.ndarray:
        """
        Get an ndarray of shape :math:`(n_{samples}, )` with indices of sample cluster membership.
        """
        pass


T = typing.TypeVar("T", bound=ClusterMembershipAware)


class ClusteringAlgorithm(typing.Generic[T], metaclass=abc.ABCMeta):
    """
    `ClusteringAlgorithm` is generic over the type of the produced results with `ClusterMembershipAware` being
    the upper bound.
    """

    @abc.abstractmethod
    def cluster(self, samples: typing.Sequence[Phenotyped], k_clusters: int) -> T:
        """
        Cluster a sequence of `samples` into `k_clusters`.

        :param samples: a sequence of :class:`Phenotyped` entities to cluster.
        :param k_clusters: the number of clusters to form.
        :return: an instance of :class:`ClusterMembershipAware` with the clustering results.
        """
        pass
