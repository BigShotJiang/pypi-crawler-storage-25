import warnings

from sklearn.cluster import SpectralClustering
from ._sim import SimilarityMatrixClustering, SimilarityMatrixClusteringResult


class SpectralSimilarityMatrixClustering(SimilarityMatrixClustering):
    """
    An implementation of spectral clustering powered by :class:`sklearn.cluster.SpectralClustering` from Scikit learn.
    """

    def __init__(self):
        # Suppress the warning below regarding not fully connected graph.
        #   sklearn/manifold/_spectral_embedding.py:274: UserWarning: Graph is not fully connected, spectral embedding may not work as expected.
        #   sklearn/manifold/_spectral_embedding.py:301: UserWarning: Graph is not fully connected, spectral embedding may not work as expected.
        # Disconnected graph should not really be an issue in our case, because there is nothing wrong about
        # the affinity/similarity matrix being a block matrix.
        warnings.simplefilter("ignore", category=UserWarning, lineno=274)
        warnings.simplefilter("ignore", category=UserWarning, lineno=301)
        warnings.simplefilter("ignore", category=UserWarning, lineno=324)
        warnings.simplefilter("ignore", category=UserWarning, lineno=328)
        warnings.simplefilter("ignore", category=UserWarning, lineno=329)

    def cluster_similarity_matrix(self, similarity_matrix, k_clusters) -> SimilarityMatrixClusteringResult:
        clusterer = SpectralClustering(
            n_clusters=k_clusters,
            affinity="precomputed",
        )
        clusterer.fit(similarity_matrix)
        return SimilarityMatrixClusteringResult(
            similarity_matrix=similarity_matrix,
            cluster_labels=clusterer.labels_,
        )
