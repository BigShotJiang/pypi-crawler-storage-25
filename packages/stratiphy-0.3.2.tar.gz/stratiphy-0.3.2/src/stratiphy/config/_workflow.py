import hpotk

from stratiphy.analysis.explain import FisherExplainMethod
from stratiphy.analysis.simulate import SyntheticCohortGenerator
from stratiphy.analysis.split import GapValSplitCheck, GapValSplitCheckParams
from stratiphy.cluster import SpectralSimilarityMatrixClustering
from stratiphy.preprocessing.validate import SampleValidator
from stratiphy.semsim import SetSimSimilarityMatrixCreatorFactory
from stratiphy.workflow import ClusteringWorkflow, SimClusteringWorkflow


def configure_workflow(
    hpo: hpotk.MinimalOntology,
    rand_cohorts: int = 200,
    mc_iter: int = 1_000_000,
) -> ClusteringWorkflow:
    """
    Configure default clustering workflow.

    :param hpo: HPO.
    :param rand_cohorts: the random cohort count for computing the gap score and testing if .
    :param mc_iter: the count of Monte Carlo trials to estimate p value for a term-cluster association.
    """
    # Configure components.
    return SimClusteringWorkflow(
        hpo_version=f"v{hpo.version}",
        smcf=SetSimSimilarityMatrixCreatorFactory(
            hpo,
        ),
        clustering=SpectralSimilarityMatrixClustering(),
        cohort_generator=SyntheticCohortGenerator(
            hpo=hpo,
        ),
        rand_iter=rand_cohorts,
        split_check=GapValSplitCheck(
            GapValSplitCheckParams.vanilla(),
        ),
        explain_method=FisherExplainMethod(
            hpo=hpo,
            n_resamples=mc_iter,
        ),
        validator=SampleValidator.default_validator(hpo),
    )
