"""
Split check module.
"""

import dataclasses
import typing

import numpy as np

from .gap import GapValues


@dataclasses.dataclass(frozen=True)
class SplitCheckResult:
    """
    Outcome of the :class:`~stratiphy.consensus.split.SplitCheck`.
    """

    should_split: bool
    """
    `True` if the presence of >=2 clusters is detected.
    """
    split_proba: float
    """
    A probability that the cohort should be split.

    A `float` in range `[0,1].
    """

    def __post_init__(self):
        assert isinstance(self.should_split, bool)
        assert isinstance(self.split_proba, float)
        assert 0.0 <= self.split_proba <= 1.0, "Not in range of `[0,1]`"


@dataclasses.dataclass(frozen=True)
class GapValSplitCheckParams:
    scaler_mean: np.ndarray
    scaler_scale: np.ndarray
    logreg_intercept: np.ndarray
    logreg_coef: np.ndarray

    def __post_init__(self):
        # Check the dimensions
        assert self.scaler_mean.shape == (3,)
        assert self.scaler_scale.shape == (3,)

        assert self.logreg_intercept.shape == (1,)
        assert self.logreg_coef.shape == (1, 3)

    def __eq__(self, value):
        return (
            isinstance(value, GapValSplitCheckParams)
            and np.allclose(self.scaler_mean, value.scaler_mean)
            and np.allclose(self.scaler_scale, value.scaler_scale)
            and np.allclose(self.logreg_intercept, value.logreg_intercept)
            and np.allclose(self.logreg_coef, value.logreg_coef)
        )

    @staticmethod
    def vanilla() -> "GapValSplitCheckParams":
        return GapValSplitCheckParams.from_dict(
            {
                "scaler_mean": np.array(
                    [
                        -0.17211586969512546,
                        0.08445582304088128,
                        0.21133898443579097,
                    ]
                ),
                "scaler_scale": np.array(
                    [
                        0.12890452939369212,
                        0.10183573935493637,
                        0.09765281389053497,
                    ]
                ),
                "logreg_intercept": np.array(
                    [
                        4.567677657732608,
                    ]
                ),
                "logreg_coef": np.array(
                    [
                        [
                            -4.74978980294152,
                            0.5694487078736222,
                            1.6862607721180223,
                        ]
                    ]
                ),
            }
        )

    @staticmethod
    def from_dict(
        val: typing.Mapping[str, typing.Any],
    ) -> "GapValSplitCheckParams":
        return GapValSplitCheckParams(
            scaler_mean=np.array(val["scaler_mean"]),
            scaler_scale=np.array(val["scaler_scale"]),
            logreg_intercept=np.array(val["logreg_intercept"]),
            logreg_coef=np.array(val["logreg_coef"]),
        )

    def as_dict(self) -> typing.Mapping[str, typing.Any]:
        return {
            "scaler_mean": self.scaler_mean.tolist(),
            "scaler_scale": self.scaler_scale.tolist(),
            "logreg_intercept": self.logreg_intercept.tolist(),
            "logreg_coef": self.logreg_coef.tolist(),
        }


class GapValSplitCheck:
    """
    Split check backed by the Gap statistic.
    """

    def __init__(
        self,
        params: GapValSplitCheckParams,
    ):
        assert isinstance(params, GapValSplitCheckParams)
        self._params = params
        self._threshold = 0.5  # The LR was trained with class weights.

    def check(
        self,
        gd: GapValues,
    ) -> SplitCheckResult:
        gaps = gd.compute_gap_values()
        # The order is crucial!
        x = np.array(
            [
                gaps[1],
                gaps[2],
                gaps[3],
            ]
        )
        return self.check_features(x)

    def check_features(
        self,
        x: np.ndarray,
    ) -> SplitCheckResult:
        proba = self._compute_proba(self._scale(x))

        return SplitCheckResult(
            should_split=bool(proba[0] >= self._threshold),
            split_proba=float(proba[0]),
        )

    def _scale(
        self,
        x: np.ndarray,
    ) -> np.ndarray:
        return (x - self._params.scaler_mean) / self._params.scaler_scale

    def _compute_proba(
        self,
        x: np.ndarray,
    ) -> np.ndarray:
        return 1 / (1 + np.exp(-(self._params.logreg_intercept + np.sum(x * self._params.logreg_coef))))
