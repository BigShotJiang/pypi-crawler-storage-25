import dataclasses
import math
import typing

import hpotk
import numpy as np
import pandas as pd
import scipy.stats as st
from hpotk.constants.hpo.base import PHENOTYPIC_ABNORMALITY
from statsmodels.stats import multitest

from stratiphy.model import Sample


@dataclasses.dataclass(
    frozen=True,
)
class TermAssociation:
    """
    Represents data for assessing relevance of an HPO term with respect to clusters.
    """

    __slots__ = [
        "term_id",
        "counts",
        "pval",
        "corrected_pval",
    ]

    term_id: hpotk.TermId
    """
    The HPO term ID.
    """

    counts: typing.Mapping[int, int]
    """
    Mapping from the cluster ID to the count of individuals annotated with the HPO term
    within the cluster.
    """

    pval: float
    """
    A p value obtained from testing of HPO term counts in clusters.
    """

    corrected_pval: typing.Optional[float]
    """
    A p value corrected for multiple testing.
    """

    def __eq__(self, value: object) -> bool:
        # The NaNs should be considered equal for the purpose of `TermAssociation` value equality.
        return (
            isinstance(value, TermAssociation)
            and self.term_id == value.term_id
            and self.counts == value.counts
            and ((math.isnan(self.pval) and math.isnan(value.pval)) or math.isclose(self.pval, value.pval))
            and (
                self.corrected_pval is None and value.corrected_pval is None
                if self.corrected_pval is None or value.corrected_pval is None
                else (
                    (math.isnan(self.corrected_pval) and math.isnan(value.corrected_pval))
                    or math.isclose(self.corrected_pval, value.corrected_pval)
                )
            )
        )

    @staticmethod
    def p_val_comparator(ta: "TermAssociation") -> typing.Tuple[float, str]:
        """
        A `key function <https://docs.python.org/3/howto/sorting.html#key-functions>`_
        for sorting `TermAssociation` collections in ascending order.

        The term associations where `pval==float("nan")` are assumed to be the largest.
        """
        if math.isnan(ta.pval):
            return (float("inf"), ta.term_id.value)
        else:
            return (ta.pval, ta.term_id.value)


class TermCounter:
    def __init__(
        self,
        hpo: hpotk.MinimalOntology,
    ) -> None:
        self._hpo = hpo

    def count(
        self,
        terms: typing.Collection[hpotk.TermId],
        samples: typing.Sequence[Sample],
        cluster_labels: np.ndarray,
    ) -> pd.DataFrame:
        assert cluster_labels.ndim == 1 and len(cluster_labels) == len(samples)
        ucl = np.unique(cluster_labels)
        count = pd.DataFrame(
            index=pd.Index(
                terms,
                name="term_id",
            ),
            columns=ucl,
            data=0,
        )
        for cid, sample in zip(cluster_labels, samples):
            for query in terms:
                if any(
                    self._hpo.graph.is_ancestor_of_or_equal_to(query, tid)
                    for tid in sample.observed_phenotypic_feature_ids()
                ):
                    count.loc[query, cid] = count.loc[query, cid] + 1  # type: ignore

        return count


class TermFilter:
    def __init__(
        self,
        hpo: hpotk.MinimalOntology,
    ) -> None:
        self._hpo = hpo

    def filter(
        self,
        counts: pd.DataFrame,
    ) -> typing.Collection[hpotk.TermId]:
        marked = set()

        # Remove terms with the exactly same counts
        # as one of their children.
        for tid, cnts in counts.iterrows():
            for child in self._hpo.graph.get_children(tid):
                if child in counts.index:
                    child_cnts = counts.loc[child]
                    if cnts.equals(child_cnts):
                        marked.add(tid)
        # TODO: add more filters, e.g. to remove the terms with lack of a nominal power.

        return marked


class TermTest:
    def __init__(
        self,
        seed: typing.Optional[typing.Union[np.random.RandomState, int]] = None,
        n_resamples: int = 100_000,
    ) -> None:
        if seed is None:
            rng = np.random.default_rng()
        elif isinstance(seed, int):
            rng = np.random.default_rng(seed)
        elif isinstance(seed, np.random.RandomState):
            rng = seed
        else:
            raise ValueError("`rng` must be an `int` or `np.random.RandomState`")

        self._method = st.MonteCarloMethod(
            n_resamples=n_resamples,
            # Note: rvs must be left unspecified for the downstream `fisher_exact` use.
            rng=rng,
        )

    def test(
        self,
        counts: pd.DataFrame,
        cluster_labels: np.ndarray,
        to_ignore: typing.Container[hpotk.TermId],
    ) -> pd.Series:
        """
        Apply Fisher exact test on the per-cluster HPO term counts.
        """
        _, nucl = np.unique(
            cluster_labels,
            return_counts=True,
        )

        pvals = pd.Series(
            index=counts.index,
        )
        arr = np.empty(
            shape=(
                2,
                len(nucl),
            ),
            dtype=np.int32,
        )
        for tid in counts.index:
            if tid not in to_ignore:
                count = counts.loc[tid]
                arr[0, :] = count
                arr[1, :] = nucl - count
                res = st.fisher_exact(
                    arr,
                    method=self._method,
                )
                pvals[tid] = res.pvalue  # type: ignore
            else:
                pvals[tid] = np.nan

        return pvals


class FisherExplainMethod:
    _HPO_COUNTS_COLNAME = "hpo_counts"
    _PVAL_COLNAME = "pval"
    _CORRECTED_PVAL_COLNAME = "corrected_pval"
    _STATISTIC_COLNAME = "statistic"

    def __init__(
        self,
        hpo: hpotk.MinimalOntology,
        seed: typing.Optional[typing.Union[np.random.RandomState, int]] = None,
        fwer_alpha: float = 0.05,
        n_resamples: int = 99_999,
        mtc_method: typing.Literal[
            "bonferroni",
            "fdr_bh",
        ] = "fdr_bh",
    ):
        self._hpo = hpo
        self._blacklist = tuple(self._hpo.graph.get_ancestors(PHENOTYPIC_ABNORMALITY))
        if seed is None:
            rng = np.random.default_rng()
        elif isinstance(seed, int):
            rng = np.random.default_rng(seed)
        elif isinstance(seed, np.random.RandomState):
            rng = seed
        else:
            raise ValueError("`rng` must be an `int` or `np.random.RandomState`")
        self._method = st.MonteCarloMethod(
            n_resamples=n_resamples,
            # Note: rvs must be left unspecified for the downstream `fisher_exact` use.
            rng=rng,
        )
        assert 0.0 <= fwer_alpha <= 1.0, "`fwer_alpha` should be in range [0, 1]"
        self._fwer_alpha = fwer_alpha
        self._counter = TermCounter(hpo)
        self._filter = TermFilter(hpo)
        self._test = TermTest(
            seed=seed,
            n_resamples=n_resamples,
        )
        self._mtc_method = mtc_method

    def explain(
        self,
        samples: typing.Sequence[Sample],
        cluster_labels: np.ndarray,
    ) -> typing.Sequence[TermAssociation]:
        """
        Test for association of HPO term with the cluster assignments.

        The returned data frame looks like this:
        ```
                       pval  corrected_pval
        term_id
        HP:0033127  0.00002         0.00238
        HP:0012758  0.00018         0.00578
        HP:0000944  0.00024         0.00578
        HP:0031263  0.00026         0.00578
        HP:0003808  0.00029         0.00578
        ```

        :param samples: a sequence of samples
        :param cluster_labels: a 1D Numpy array of cluster labels, one per sample
        :return: a data frame with nominal and corrected p values for the terms
        """
        # find the terms to test
        terms = self._find_terms_to_test(samples)

        # count the annotated individuals per cluster
        counts = self._counter.count(
            terms,
            samples,
            cluster_labels,
        )

        # filter out the terms with counts identical
        # to their children (AKA. HPO MTC filter (GPSEA))
        to_ignore = self._filter.filter(counts)

        # test
        pvals = self._test.test(
            counts,
            cluster_labels,
            to_ignore,
        )

        # multiple testing correction
        corrected = self._apply_mtc(
            pvals,
            to_ignore,
        )

        return tuple(
            TermAssociation(
                term_id=term_id,  # type: ignore
                counts=counts.loc[term_id].to_dict(),  # type: ignore
                pval=pvals[term_id],  # type: ignore
                corrected_pval=corrected[term_id],  # type: ignore
            )
            for term_id in terms
        )

    def _find_terms_to_test(
        self,
        samples: typing.Sequence[Sample],
    ) -> typing.Collection[hpotk.TermId]:
        terms = set()
        for sample in samples:
            for tid in sample.observed_phenotypic_feature_ids():
                if self._hpo.graph.is_ancestor_of(PHENOTYPIC_ABNORMALITY, tid):
                    terms.add(tid)
                    terms.update(
                        filter(
                            lambda t: t not in self._blacklist,
                            self._hpo.graph.get_ancestors(tid),
                        )
                    )

        return terms

    def _count_per_cluster(
        self,
        terms: typing.Collection[hpotk.TermId],
        samples: typing.Sequence[Sample],
        cluster_labels: np.ndarray,
    ) -> pd.DataFrame:
        ucl = np.unique(cluster_labels)
        count = pd.DataFrame(
            index=pd.Index(
                terms,
                name="term_id",
            ),
            columns=ucl,
            data=0,
        )
        for cid, sample in zip(cluster_labels, samples):
            for query in terms:
                if any(
                    self._hpo.graph.is_ancestor_of_or_equal_to(query, tid)
                    for tid in sample.observed_phenotypic_feature_ids()
                ):
                    count.loc[query, cid] = count.loc[query, cid] + 1  # type: ignore

        return count

    def _pretest_filter(
        self,
        counts: pd.DataFrame,
    ) -> typing.Collection[hpotk.TermId]:
        marked = set()

        # Remove terms with the exactly same counts
        # as one of their children.
        for tid, cnts in counts.iterrows():
            for child in self._hpo.graph.get_children(tid):
                if child in counts.index:
                    child_cnts = counts.loc[child]
                    if cnts.equals(child_cnts):
                        marked.add(tid)
        # TODO: add more filters, e.g. to remove the terms with lack of a nominal power.

        return marked

    def _compute_pvals(
        self,
        counts: pd.DataFrame,
        cluster_labels: np.ndarray,
        to_ignore: typing.Collection[hpotk.TermId],
    ) -> pd.Series:
        """
        Apply Fisher exact test on the per-cluster HPO term counts.
        """
        _, nucl = np.unique(
            cluster_labels,
            return_counts=True,
        )

        pvals = pd.Series(
            index=counts.index,
        )
        arr = np.empty(
            shape=(
                2,
                len(nucl),
            ),
            dtype=np.int32,
        )
        for tid in counts.index:
            if tid not in to_ignore:
                count = counts.loc[tid]
                arr[0, :] = count
                arr[1, :] = nucl - count
                res = st.fisher_exact(
                    arr,
                    method=self._method,
                )
                pvals[tid] = res.pvalue  # type: ignore
            else:
                pvals[tid] = np.nan

        return pvals

    def _apply_mtc(
        self,
        pvals: pd.Series,
        to_ignore: typing.Collection[hpotk.TermId],
    ) -> pd.Series:
        query = pvals[~pvals.index.isin(to_ignore)]
        _, pval_corrected, _, _ = multitest.multipletests(
            pvals=query,
            alpha=self._fwer_alpha,
            method=self._mtc_method,
        )
        assert isinstance(query, pd.Series)
        return pd.Series(
            data=pval_corrected,
            index=query.index,
            name=FisherExplainMethod._CORRECTED_PVAL_COLNAME,
        ).reindex(pvals.index)
