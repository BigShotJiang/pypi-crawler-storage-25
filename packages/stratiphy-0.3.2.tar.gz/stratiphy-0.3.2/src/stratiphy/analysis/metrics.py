import typing

import numpy as np

from stratiphy.util import validate_2d_square_array


def silhouette_score_from_similarity_matrix(
    similarity_matrix: np.ndarray,
    labels: typing.Sequence[int],
) -> float:
    """
    Compute the silhouette score given a similarity matrix and labels.

    The silhouette score is a measure of how similar an object is to its own cluster (cohesion)
    compared to other clusters (separation). The silhouette score ranges from -1 (indicating incorrect clustering)
    to 1 (indicating highly dense clustering), with 0 indicating overlapping clusters.

    :param similarity_matrix: A square matrix where the element (i, j) represents the similarity between sample i and sample j.
    :param labels: List of cluster labels for each sample.

    Returns:
    :param: Silhouette score averaged across all samples.
    """
    validate_2d_square_array(similarity_matrix, name="similarity_matrix")

    n_samples = similarity_matrix.shape[0]

    if n_samples != len(labels):
        raise ValueError("The size of the similarity matrix does not match with the size of the labels.")

    uniq_labels = np.unique(labels)
    if len(uniq_labels) == 1:
        return 0
    labels = np.array(labels)

    # Convert the similarity matrix to a distance matrix
    distance_matrix = 1.0 / (similarity_matrix / np.max(similarity_matrix))

    silhouette_values = []

    for i in range(n_samples):
        same_cluster_indices = np.where(labels == labels[i])[0]

        if len(same_cluster_indices) == 1:  # Edge case: only member of its cluster
            silhouette_values.append(0)  # Set silhouette value to 0
            continue

        a_i = np.mean([distance_matrix[i, j] for j in same_cluster_indices if i != j])

        b_i_values = []
        for label in uniq_labels:
            if label != labels[i]:
                different_cluster_indices = np.where(labels == label)[0]
                b_i_values.append(np.mean([distance_matrix[i, j] for j in different_cluster_indices]))
        b_i = min(b_i_values)

        silhouette_values.append((b_i - a_i) / max(a_i, b_i))

    return np.nanmean(silhouette_values)  # Use nanmean to ignore nan values
