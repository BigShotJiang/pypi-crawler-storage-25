import dataclasses
import typing

import numpy as np


@dataclasses.dataclass(frozen=True)
class GapValues:
    """
    Container of values for Gap statistic computation.
    """

    @staticmethod
    def from_similarity_matrices(
        sm: np.ndarray,
        sm_randomized: typing.Iterable[np.ndarray],
        cluster_labels: typing.Mapping[int, np.ndarray],
    ) -> "GapValues":
        """
        Compute `GapValues` from primary data.

        :param sm: similarity matrix of data.
        :param sm_randomized: similarity matrices of randomized data.
        :param cluster_labels:
        """
        k_to_cluster_labels = dict(cluster_labels)

        if 1 not in k_to_cluster_labels:
            shape = (len(sm),)
            k_to_cluster_labels[1] = np.zeros(shape=shape, dtype=int)

        log_wk_data = {}  # k to $log_{W_k}$
        log_wk_rand = {}  # k to sequence of $log_{W_k}$ values

        for k, cl in k_to_cluster_labels.items():
            log_wk_data[k] = np.log(_compute_wk(sm, cl))
            log_wk_rand[k] = tuple(np.log(_compute_wk(smr, cl)) for smr in sm_randomized)

        return GapValues(
            log_wk_data=log_wk_data,
            log_wk_rand=log_wk_rand,
        )

    log_wk_data: typing.Mapping[int, float]
    """
    A mapping from $k$ to $log(W_k)$ obtained from data.
    """

    log_wk_rand: typing.Mapping[int, typing.Sequence[float]]
    """
    A sequence with *n* mappings from $k$ to $log(W_k)$ for each
    of *n* datasets sampled from a reference distribution.
    """

    def __post_init__(self):
        assert len(set(self.log_wk_data)) == len(self.log_wk_data)  # Keys must be unique
        assert set(self.log_wk_data) == set(self.log_wk_rand)
        assert len(self.log_wk_data) == len(self.log_wk_rand)

        if len(self.log_wk_rand) > 0:
            # We have the same number of log_W_k values for all *k*s
            lengths = tuple(len(val) for val in self.log_wk_rand.values())
            assert all(length == lengths[0] for length in lengths)

    @property
    def randomized_cohort_count(self) -> int:
        """
        Get the randomized cohort count.
        """
        return len(self.log_wk_rand)

    def compute_expected_rand_log_wk(self) -> typing.Mapping[int, float]:
        return {k: _compute_mean(vals) for k, vals in self.log_wk_rand.items()}

    def compute_gap_values(self) -> typing.Mapping[int, float]:
        """
        Compute the gap values - the difference between :math:`log(W_k)`
        and the expected value of :math:`log(W_k)` of datasets sampled from a reference distribution.
        """
        gap_values = {}

        for k, log_wk in self.log_wk_data.items():
            # We negate the gap values because we work with similarities
            # and not with distances.
            #
            # We expect to get smaller similarities between the null dataset members.
            gap_values[k] = log_wk - _compute_mean(self.log_wk_rand[k])

        return gap_values


def _compute_mean(
    vals: typing.Collection[typing.Union[float, int]],
) -> float:
    if len(vals) == 0:
        raise ValueError("`vals` must not be empty")
    else:
        return sum(vals) / len(vals)


def _compute_wk(
    sm: np.ndarray,
    cluster_labels: np.ndarray,
) -> float:
    # `sm` is a square matrix ...
    assert sm.ndim == 2 and sm.shape[0] == sm.shape[1]
    # ... and we have a label for each item.
    assert cluster_labels.ndim == 1 and cluster_labels.shape[0] == sm.shape[0]

    w_k = 0.0

    for cluster_id in np.unique(cluster_labels):
        mask = cluster_labels == cluster_id
        relevant = sm[mask, :][:, mask]
        w_k += np.sum(
            relevant[
                np.triu_indices(
                    n=len(relevant),
                    k=1,  # Skip self-similarities
                )
            ]
        )

    return w_k
