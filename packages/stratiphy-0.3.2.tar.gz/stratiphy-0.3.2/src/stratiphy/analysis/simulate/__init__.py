"""
A package with methods for generating synthetic subjects such that certain criteria are met.
"""

from ._impl import SyntheticSampleGenerator, SyntheticCohortGenerator, pool_present_and_excluded_features

__all__ = [
    "SyntheticSampleGenerator",
    "pool_present_and_excluded_features",
    "SyntheticCohortGenerator",
]
