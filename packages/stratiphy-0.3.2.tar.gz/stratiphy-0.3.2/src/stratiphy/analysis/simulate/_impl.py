import abc
import copy
import logging
import typing
from collections import Counter

import hpotk
import numpy as np

from stratiphy.model import Phenotyped, PhenotypicFeature


def pool_present_and_excluded_features(
    samples: typing.Iterable[Phenotyped],
) -> typing.Tuple[typing.Sequence[hpotk.TermId], typing.Sequence[hpotk.TermId]]:
    """
    Pool phenotypic feature identifiers from given `samples` into sequences of observed and excluded term IDs.

    The sequences contain unique term IDs (no duplicates).

    :param samples: an iterable with phenotyped entities to pool.
    :return: a tuple with sequences of *present* and *excluded* term IDs.
    """
    # First, pool the phenotypic features to create corpora of present and excluded terms.
    present_terms: typing.Set[hpotk.TermId] = set()
    excluded_terms: typing.Set[hpotk.TermId] = set()
    for sample in samples:
        for feature in sample.phenotypic_features:
            if feature.is_present:
                present_terms.add(feature.identifier)
            else:
                excluded_terms.add(feature.identifier)

    # Then wrap in tuples and return
    return tuple(present_terms), tuple(excluded_terms)


def candidate_is_logically_consistent(
    hpo: hpotk.GraphAware,
    candidate: hpotk.TermId,
    candidate_status: bool,
    features: typing.Iterable[PhenotypicFeature],
) -> bool:
    for pf in features:
        if pf.identifier == candidate:
            # A candidate cannot be added if it is already among the features regardless of the status.
            return False

        if candidate_status:
            # Adding a present candidate.

            # A present candidate cannot be added if it is a descendant of an existing feature regardless of
            # the feature's status.
            if hpo.graph.is_ancestor_of(pf, candidate):
                return False

            if pf.is_present:
                # A present candidate cannot be added if it is an ancestor of a present feature.
                if hpo.graph.is_ancestor_of(candidate, pf):
                    return False

        else:
            # Adding an excluded candidate.

            # An excluded candidate cannot be added if it is an ancestor of an existing feature
            # regardless of the feature's status.
            if hpo.graph.is_ancestor_of(candidate, pf):
                return False
            if pf.is_present:
                # An excluded candidate cannot be added if it is a descendant of an excluded feature.
                if hpo.graph.is_ancestor_of(pf, candidate):
                    return False

    return True


class SyntheticSampleGenerator(
    metaclass=abc.ABCMeta,
):
    """
    `SyntheticSampleGenerator` generates a :class:`PhenotypicFeature` sequence from a corpus of present and excluded
    term IDs, ensuring lack of logical inconsistencies in the generated sequence.
    """

    @staticmethod
    def default_generator(
        hpo: hpotk.MinimalOntology,
        max_iter: typing.Optional[int] = 100,
        random_seed: typing.Optional[int] = None,
    ) -> "SyntheticSampleGenerator":
        return SimpleSyntheticSampleGenerator(
            hpo=hpo,
            max_iter=max_iter,
            random_seed=random_seed,
        )

    @abc.abstractmethod
    def sample_features(
        self,
        n_present: int,
        n_excluded: int,
        present: typing.Sequence[hpotk.TermId],
        excluded: typing.Sequence[hpotk.TermId],
    ) -> typing.Sequence[PhenotypicFeature]:
        """
        Sample a sequence of phenotypic features such that the features are logically consistent (do not violate
        the annotation propagation rule).

        :param n_present: the number of present features to sample.
        :param n_excluded: the number of excluded features to sample.
        :param present: the corpus of the present features to choose from.
        :param excluded: the corpus of the excluded features to choose from
        :return: a sequence of phenotypic features.
        """
        pass


class SimpleSyntheticSampleGenerator(SyntheticSampleGenerator):
    def __init__(
        self,
        hpo: hpotk.MinimalOntology,
        max_iter: typing.Optional[int] = 100,
        random_seed: typing.Optional[int] = None,
    ):
        assert isinstance(hpo, hpotk.MinimalOntology)
        self._hpo = hpo

        if random_seed is None:
            self._rng = np.random.default_rng()
        else:
            if isinstance(random_seed, int):
                self._rng = np.random.default_rng(random_seed)
            else:
                raise ValueError(f"`random_seed` must be an `int` or `None` but was {random_seed}")

        if max_iter is not None:
            if not isinstance(max_iter, int) or max_iter <= 0:
                raise ValueError(f"`max_iter` must be a positive `int` or `None` but was {max_iter}")
        self._max_iter = max_iter

        self._logger = logging.getLogger(__name__)

    def sample_features(
        self,
        n_present: int,
        n_excluded: int,
        present: typing.Sequence[hpotk.TermId],
        excluded: typing.Sequence[hpotk.TermId],
    ) -> typing.Sequence[PhenotypicFeature]:
        features = []

        # First, choose the present features.
        n_sampled = 0
        for i in range(self._max_iter):
            if n_sampled == n_present:
                # We already have enough present features.
                break

            # Otherwise, let's sample.
            candidate = self._rng.choice(present)
            if candidate_is_logically_consistent(
                self._hpo,
                candidate,
                candidate_status=True,
                features=features,
            ):
                features.append(PhenotypicFeature.from_values(identifier=candidate, is_present=True))
                n_sampled += 1

        if n_sampled != n_present:
            self._logger.debug("Could not sample enough present features %d!=%d", n_sampled, n_present)

        # Next, choose the excluded features.
        n_sampled = 0
        for i in range(self._max_iter):
            if n_sampled == n_excluded:
                # We already have enough excluded features.
                break

            # Otherwise, let's sample
            candidate = self._rng.choice(excluded)
            if candidate_is_logically_consistent(
                self._hpo,
                candidate,
                candidate_status=False,
                features=features,
            ):
                features.append(PhenotypicFeature.from_values(identifier=candidate, is_present=False))
                n_sampled += 1

        if n_sampled != 0:
            self._logger.debug(
                "Could not sample enough excluded features %d!=%d",
                n_sampled,
                n_excluded,
            )

        # Last, return the results.
        return features


P = typing.TypeVar("P", bound=Phenotyped)


class SyntheticCohortGenerator(typing.Generic[P]):
    """
    Generate a synthetic cohort with similar characteristics to the provided samples.

    """

    def __init__(
        self,
        hpo: hpotk.MinimalOntology,
        max_iter: int = 500,
        random_seed: typing.Optional[int] = None,
    ):
        assert isinstance(hpo, hpotk.MinimalOntology)
        self._hpo = hpo

        if not isinstance(max_iter, int) or max_iter <= 0:
            raise ValueError(f"`max_iter` must be a positive `int` but was {max_iter}")
        self._max_iter = max_iter

        if random_seed is None:
            self._rng = np.random.default_rng()
        else:
            if isinstance(random_seed, int):
                self._rng = np.random.default_rng(random_seed)
            else:
                raise ValueError(f"`random_seed` must be an `int` or `None` but was {random_seed}")

    def generate(
        self,
        samples: typing.Sequence[P],
    ) -> typing.Sequence[P]:
        # Generate the same number of samples.
        #
        # Each sample has the same number of present and excluded features.
        # We prepare a corpus of present and excluded terms that are used in the samples.
        # We may take advantage of the ancestors/descendants (parameter).

        # Compute the feature distribution
        present, present_proba, excluded, excluded_proba = self._prepare_present_excluded(samples)

        synthetic_samples = []
        for sample in samples:
            synthetic_phenotypes = []
            target_present_count, target_excluded_count = sample.count_term_id_by_status()

            # First, choose the present features.
            n_sampled = 0
            for i in range(self._max_iter):
                if n_sampled == target_present_count:
                    # We already have enough present features.
                    break

                # Otherwise, let's sample.
                candidate = self._rng.choice(present, p=present_proba)
                if candidate_is_logically_consistent(
                    self._hpo,
                    candidate,
                    candidate_status=True,
                    features=synthetic_phenotypes,
                ):
                    synthetic_phenotypes.append(PhenotypicFeature.from_values(identifier=candidate, is_present=True))
                    n_sampled += 1

            # Next, choose the excluded features.
            n_sampled = 0
            for i in range(self._max_iter):
                if n_sampled == target_excluded_count:
                    # We already have enough excluded features.
                    break

                # Otherwise, let's sample
                candidate = self._rng.choice(excluded, p=excluded_proba)
                if candidate_is_logically_consistent(
                    self._hpo,
                    candidate,
                    candidate_status=False,
                    features=synthetic_phenotypes,
                ):
                    synthetic_phenotypes.append(PhenotypicFeature.from_values(identifier=candidate, is_present=False))
                    n_sampled += 1

            synthetic = copy.copy(sample)
            synthetic.phenotypic_features.clear()
            synthetic.phenotypic_features.extend(synthetic_phenotypes)
            synthetic_samples.append(synthetic)

        return synthetic_samples

    def _prepare_present_excluded(
        self,
        samples: typing.Sequence[Phenotyped],
    ) -> typing.Tuple[
        typing.Sequence[hpotk.TermId],
        typing.Sequence[float],
        typing.Sequence[hpotk.TermId],
        typing.Sequence[float],
    ]:
        present_count = Counter()
        excluded_count = Counter()
        for sample in samples:
            for pf in sample.phenotypic_features:
                if pf.is_present:
                    present_count[pf.identifier] += 1
                else:
                    excluded_count[pf.identifier] += 1

        total_present = sum(present_count.values())
        total_excluded = sum(excluded_count.values())
        present = np.array(list(present_count))
        present_proba = np.array(list(present_count[val] / total_present for val in present))
        excluded = np.array(list(excluded_count))
        excluded_proba = np.array(list(excluded_count[val] / total_excluded for val in excluded))

        return present, present_proba, excluded, excluded_proba
