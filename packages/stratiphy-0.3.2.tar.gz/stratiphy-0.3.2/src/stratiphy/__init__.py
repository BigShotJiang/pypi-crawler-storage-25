"""
The API documentation for the `stratiphy` Python package.

The API documentation is targeted for the advanced users wanting to use
`stratiphy` as a Python library. For general public, we recommend to use
the command-line interface (CLI).

See the [Tutorial](../../tutorial.md) and [User Guide](../../user-guide/index.md)
for an overview of the CLI main use cases.
"""

from importlib.metadata import version

__version__ = version("stratiphy")
