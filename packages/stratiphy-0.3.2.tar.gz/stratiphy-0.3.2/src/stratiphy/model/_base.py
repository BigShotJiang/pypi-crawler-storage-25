import abc
import copy
import typing

import hpotk
import hpotk.util
from hpotk.annotations import AnnotatedItem


class PhenotypicFeature(
    hpotk.model.Identified,
    hpotk.model.FrequencyAwareFeature,
):
    """
    Phenotypic feature represents a sign or symptom of the individual encoded into an HPO term.

    The value consists of a `term_id` and `status` (observed/excluded).
    The annotation is defined on the individual level, i.e. no aggregation has been performed.
    """

    @staticmethod
    def from_values(
        identifier: typing.Union[str, hpotk.model.TermId],
        is_present: bool,
    ) -> "PhenotypicFeature":
        """
        Create a new phenotypic feature from the identifier and the observation status.

        :param identifier: a CURIE `str` or :class:`hpotk.model.TermId` with the term ID.
        :param is_present: `True` if the phenotypic feature was *present* and `False` if it was *excluded*.
        :return: the new phenotypic feature.
        """
        if isinstance(identifier, str):
            identifier = hpotk.TermId.from_curie(identifier)
        elif isinstance(identifier, hpotk.TermId):
            pass
        else:
            raise ValueError(f"identifier must be a `hpotk.TermId` or `str` but got {type(identifier)}")

        if not isinstance(is_present, bool):
            raise ValueError(f"is_present must be a `bool` but got {type(is_present)}")

        return PhenotypicFeature(identifier, is_present)

    def __init__(
        self,
        identifier: hpotk.model.TermId,
        is_present: bool,
    ):
        self._identifier = identifier
        self._is_present = is_present

    @property
    def identifier(self) -> hpotk.model.TermId:
        """
        Get/set the term ID of the feature.
        """
        return self._identifier

    @identifier.setter
    def identifier(self, value: hpotk.model.TermId):
        self._identifier = value

    @property
    def is_present(self) -> bool:
        return self._is_present

    @property
    def numerator(self):
        return 1 if self._is_present else 0

    @property
    def denominator(self):
        # Phenotypic feature is always defined on an individual level.
        return 1

    def __copy__(self):
        """
        Phenotypic feature must support (shallow) copy to support modification in the perturb step.
        """
        return type(self)(self.identifier, self.is_present)

    def __eq__(self, other):
        """
        Two phenotypic features are equal if the `term_id` and `status` attributes are equal.
        """
        return (
            isinstance(other, PhenotypicFeature)
            and self.identifier == other.identifier
            and self.is_present == other.is_present
        )

    def __str__(self):
        return f"PhenotypicFeature(identifier={self.identifier}, is_present={self.is_present})"

    def __repr__(self):
        return f"PhenotypicFeature(identifier={self.identifier}, is_present={self._is_present})"

    # TODO - add additional attributes?

    def __hash__(self):
        return hash((self.identifier, self.is_present))


class Phenotyped(
    AnnotatedItem[PhenotypicFeature],
    metaclass=abc.ABCMeta,
):
    """
    A mixin class for entities that are annotated with phenotypic features.
    """

    @property
    @abc.abstractmethod
    def phenotypic_features(self) -> typing.MutableSequence[PhenotypicFeature]:
        """
        Get/set a sequence of the phenotypic features.
        """
        pass

    @property
    def annotations(self) -> typing.Collection[PhenotypicFeature]:
        return self.phenotypic_features

    def observed_phenotypic_features(self) -> typing.Iterator[PhenotypicFeature]:
        return filter(lambda pf: pf.is_present, self.phenotypic_features)

    def observed_phenotypic_feature_ids(self) -> typing.Iterator[hpotk.TermId]:
        return map(lambda pf: pf.identifier, self.observed_phenotypic_features())

    def observed_phenotypic_feature_indices(self) -> typing.Iterator[int]:
        return map(
            lambda x: x[0],
            filter(lambda x: x[1].is_present, enumerate(self.phenotypic_features)),
        )

    def observed_phenotypic_feature_count(self) -> int:
        return self._count_instances(self.observed_phenotypic_features())

    def excluded_phenotypic_features(self) -> typing.Iterator[PhenotypicFeature]:
        return filter(lambda pf: pf.is_excluded, self.phenotypic_features)

    def excluded_phenotypic_feature_ids(self) -> typing.Iterator[hpotk.TermId]:
        return map(lambda pf: pf.identifier, self.excluded_phenotypic_features())

    def excluded_phenotypic_feature_indices(self) -> typing.Iterator[int]:
        return map(
            lambda x: x[0],
            filter(lambda x: x[1].is_excluded, enumerate(self.phenotypic_features)),
        )

    def excluded_phenotypic_feature_count(self) -> int:
        return self._count_instances(self.excluded_phenotypic_features())

    def term_ids_by_status(
        self,
    ) -> typing.Tuple[typing.FrozenSet[hpotk.TermId], typing.FrozenSet[hpotk.TermId]]:
        """
        Get a tuple with frozen sets of present and excluded term IDs.
        """
        present, excluded = set(), set()
        for pf in self.phenotypic_features:
            if pf.is_present:
                present.add(pf.identifier)
            else:
                excluded.add(pf.identifier)

        return frozenset(present), frozenset(excluded)

    def term_id_indices_by_status(
        self,
    ) -> typing.Tuple[typing.Sequence[int], typing.Sequence[int]]:
        """
        Get a tuple of two sequences with indices of the present and excluded features.
        """
        present, excluded = [], []

        for i, pf in enumerate(self.phenotypic_features):
            if pf.is_present:
                present.append(i)
            else:
                excluded.append(i)

        return tuple(present), tuple(excluded)

    def count_term_id_by_status(self) -> typing.Tuple[int, int]:
        """
        Get a tuple with counts of the present and excluded features.

        :return: a tuple ``(n_present, n_excluded)`` with term id count by observation status.
        """
        n_present, n_excluded = 0, 0

        for pf in self.phenotypic_features:
            if pf.is_present:
                n_present += 1
            else:
                n_excluded += 1

        return n_present, n_excluded

    @staticmethod
    def _count_instances(iterator: typing.Iterator[typing.Any]) -> int:
        i = 0
        for _ in iterator:
            i += 1
        return i

    def replace_term_id_at(self, term_id: hpotk.TermId, i: int):
        self._check_phenotypic_feature_bound(i)
        self.phenotypic_features[i].identifier = term_id

    def delete_feature_at(self, i: int):
        self._check_phenotypic_feature_bound(i)
        del self.phenotypic_features[i]

    def _check_phenotypic_feature_bound(self, i):
        if not isinstance(i, int) or 0 > i or i >= len(self.phenotypic_features):
            raise ValueError(f"i must be an int in range [0, {len(self.phenotypic_features)}) but was {i}")

    def delete_feature(self, term_id: hpotk.TermId, is_present: bool) -> bool:
        for i, pf in enumerate(self.phenotypic_features):
            if pf.identifier == term_id and pf.is_present == is_present:
                del self.phenotypic_features[i]
                return True
        return False


class SampleLabels:
    """
    A data model for identifiers of a :class:`Sample`.

    `Sample` has a mandatory :attr:`label` and an optional :attr:`meta_label`.
    """

    def __init__(self, label: str, meta_label: typing.Optional[str] = None):
        self._label = hpotk.util.validate_instance(label, str, "label")
        self._meta_label = hpotk.util.validate_optional_instance(meta_label, str, "meta_label")

    @property
    def label(self) -> str:
        return self._label

    @property
    def meta_label(self) -> typing.Optional[str]:
        return self._meta_label

    def label_summary(self) -> str:
        """
        Summarize `label` and `meta_label` into a `str` where the sub-parts are inserted as ``<label>[<meta_label>]``.
        """
        return self._label if self._meta_label is None else f"{self._label}[{self._meta_label}]"

    def __eq__(self, other):
        return isinstance(other, SampleLabels) and self._label == other.label and self._meta_label == other._meta_label

    def __lt__(self, other):
        if isinstance(other, SampleLabels):
            if self._label < other._label:
                return True
            elif self._label == other._label:
                if self._meta_label is None or other._meta_label is None:
                    if self._meta_label == other._meta_label:
                        return False
                    else:
                        return True if self._meta_label is None else False  # `None` is less
                else:
                    return self._meta_label < other._meta_label
            return False
        else:
            return NotImplemented

    def __hash__(self):
        return hash((self._label, self._meta_label))

    def __str__(self):
        return self.label_summary()

    def __repr__(self):
        return f"SampleLabels(label={self._label}, meta_label={self._meta_label})"


class Labeled(metaclass=abc.ABCMeta):
    """
    A mixin class for entities that are labeled with identifier designed for human consumption.
    """

    @property
    @abc.abstractmethod
    def labels(self) -> SampleLabels:
        pass


class Sample(Phenotyped, Labeled):
    """
    `Sample` describes the requirements for the subject data, as far as Stratiphy is concerned.
    """

    @staticmethod
    def from_raw_parts(
        labels: typing.Union[SampleLabels, str],
        phenotypic_features: typing.Iterable[PhenotypicFeature],
    ) -> "Sample":
        """
        Create a `Sample` from `labels` and `phenotypic_features`.

        :param labels: sample labels.
        :param phenotypic_features: an iterable of phenotypic features.
        :return: the new sample.
        """
        if isinstance(labels, str):
            labels = SampleLabels(label=labels)

        return Sample(
            labels=labels,
            phenotypic_features=phenotypic_features,
        )

    def __init__(
        self,
        labels: SampleLabels,
        phenotypic_features: typing.Iterable[PhenotypicFeature],
    ):
        assert isinstance(labels, SampleLabels)
        self._labels = labels

        self._pfs = list(phenotypic_features)

    @property
    def labels(self) -> SampleLabels:
        return self._labels

    @property
    def phenotypic_features(self) -> typing.MutableSequence[PhenotypicFeature]:
        return self._pfs

    def __copy__(self):
        """
        Sample must support (shallow) copy to support modification in the perturb step.
        """
        # We pass along the label ref but we carbon copy each phenotypic feature
        return type(self)(
            self._labels,
            (copy.copy(feature) for feature in self.phenotypic_features),
        )

    def __eq__(self, other):
        return isinstance(other, Sample) and self._labels == other._labels and self._pfs == other._pfs

    def __hash__(self):
        return hash((self._labels, self._pfs))

    def __repr__(self):
        return f'Sample(labels="{repr(self.labels)}", phenotypic_features={self.phenotypic_features})'

    def __str__(self):
        return f"Sample(label={self.labels}, n_phenotypic_features={len(self.phenotypic_features)})"
