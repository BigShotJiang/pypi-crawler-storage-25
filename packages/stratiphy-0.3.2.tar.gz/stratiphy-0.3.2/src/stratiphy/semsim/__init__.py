"""
A module methods for calculating semantic similarity.

The module includes the abstractions such as :class:`SimilarityKernel` and :class:`SimilarityMeasure` which are used
by the rest of the Stratiphy code.

The module also provides semantic similarity implementations.

The module also includes a dummy kernel that returns random similarity (:class:`~stratiphy.semsim.DummySimilarityKernel`).
"""

from ._base import (
    SimilarityMatrix,
    SimilarityMatrixCreator,
    SimilarityMatrixCreatorFactory,
)
from ._ic import calculate_cic
from ._sts import SetSimSimilarityMatrixCreatorFactory

__all__ = [
    "SimilarityMatrix",
    "SimilarityMatrixCreator",
    "SimilarityMatrixCreatorFactory",
    "SetSimSimilarityMatrixCreatorFactory",
    "calculate_cic",
]
