import dataclasses
import typing
from collections import defaultdict

import hpotk

from stratiphy.model import Phenotyped

from ._base import (
    BaseSimilarityMatrixCreator,
    DistanceMeasure,
    ValueAdaptor,
)
from ._ic import calculate_cic


@dataclasses.dataclass(frozen=True)
class PETermCounts:
    n: typing.Mapping[hpotk.TermId, typing.Tuple[int, int]]
    m: int


class PETermAdaptor(
    ValueAdaptor[Phenotyped, PETermCounts],
):
    def __init__(
        self,
        hpo: hpotk.MinimalOntology,
        itr: typing.Container[hpotk.TermId],
    ):
        super().__init__()
        self._hpo = hpo
        self._itr = itr

    def adapt(
        self,
        val: Phenotyped,
    ) -> PETermCounts:
        n = defaultdict(lambda: [False, False])
        for pf in val.phenotypic_features:
            if pf.is_present:
                if pf.identifier in self._itr:
                    n[pf.identifier][0] = True
                    for anc in self._hpo.graph.get_ancestors(pf):
                        if anc in self._itr:
                            n[anc][0] = True
            else:
                if pf.identifier in self._itr:
                    n[pf.identifier][1] = True
                    for desc in self._hpo.graph.get_descendants(pf):
                        if desc in self._itr:
                            n[desc][1] = True

        return PETermCounts(
            n={term_id: (int(p), int(e)) for term_id, (p, e) in n.items()},
            m=1,
        )


class PEDistanceMeasure(
    DistanceMeasure[PETermCounts],
):
    def __init__(
        self,
        tici: typing.Mapping[hpotk.TermId, float],
    ):
        super().__init__()
        self._tici = dict(tici)
        self._tic = sum(tici.values())

    @property
    def max_dist(self) -> float:
        return self._tic

    def compute(
        self,
        a: PETermCounts,
        b: PETermCounts,
    ) -> float:
        m = a.m + b.m
        val = self.max_dist

        aa, bb = (a, b) if len(a.n) < len(b.n) else (b, a)
        for tid, naa in aa.n.items():
            nbb = bb.n.get(tid)
            if nbb is not None:
                if sum(nbb) == 0 or sum(naa) == 0:
                    # Should not happen in practice
                    continue
                else:
                    tra = ((nbb[0] + naa[0]) - (nbb[1] + naa[1])) / m
                    w = self._tici[tid]

                    val -= abs(tra) * w

        return val


class PESimilarityMatrixCreator(
    BaseSimilarityMatrixCreator[PETermCounts],
):
    def __init__(
        self,
        hpo: hpotk.MinimalOntology,
        root: hpotk.TermId,
        base: float,
    ):
        super().__init__(
            hpo=hpo,
            root=root,
            base=base,
        )
        itr = {
            root,
        }
        itr.update(hpo.graph.get_descendants(root))
        self._adaptor = PETermAdaptor(
            self._hpo,
            itr,
        )

    def _prepare_adaptor(
        self,
    ) -> ValueAdaptor[
        Phenotyped,
        PETermCounts,
    ]:
        return self._adaptor

    def _prepare_dm(
        self,
        samples: typing.Sequence[Phenotyped],
    ) -> DistanceMeasure[PETermCounts]:
        cic = calculate_cic(
            samples,
            hpo=self._hpo,
            root=self._root,
        )
        return PEDistanceMeasure(cic)
