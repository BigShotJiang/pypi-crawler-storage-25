import math
import typing
from collections import Counter

import hpotk

from stratiphy.model import Phenotyped


def calculate_ic(
    cohort: typing.Sequence[Phenotyped],
    hpo: hpotk.MinimalOntology,
    root: hpotk.TermId,
) -> typing.Mapping[hpotk.TermId, float]:
    """
    Compute information content for terms that annotate the cohort.
    """
    counts = Counter()

    for sample in cohort:
        for tid in sample.observed_phenotypic_feature_ids():
            counts[tid] += 1
            for anc in hpo.graph.get_ancestors(tid):
                counts[anc] += 1

    module = {root}
    module.update(hpo.graph.get_descendants(root))
    pop_cnt = counts[root]

    return {
        tid: math.log2(
            pop_cnt / c,
        )
        for tid, c in counts.items()
        if tid in module
    }


def calculate_cic(
    cohort: typing.Sequence[Phenotyped],
    hpo: hpotk.MinimalOntology,
    root: hpotk.TermId,
) -> typing.Mapping[hpotk.TermId, float]:
    ic = calculate_ic(
        cohort,
        hpo,
        root,
    )
    cic = {}
    for ti, val in ic.items():
        if ti == root:
            cic[ti] = 0.0
        else:
            parent_ics = tuple(ic[p] for p in hpo.graph.get_parents(ti))
            mean = sum(parent_ics) / len(parent_ics)
            cic[ti] = val - mean

    return cic
