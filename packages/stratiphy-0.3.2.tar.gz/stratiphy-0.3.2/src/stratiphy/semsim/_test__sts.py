import typing

import hpotk
import pytest

from ._sts import PDistanceMeasure


@pytest.fixture(scope="module")
def term_id2cond_ic() -> typing.Mapping[hpotk.TermId, float]:
    return prepare_term_id2cond_ic(
        [
            ("HP:0000", 0.0),
            ("HP:0100", 1.5),
            ("HP:0110", 1.0),
            ("HP:0200", 2.5),
            ("HP:0210", 4.0),
            ("HP:0220", 1.0),
        ]
    )


def prepare_term_id2cond_ic(
    vals: typing.Iterable[typing.Tuple[str, float]],
) -> typing.Mapping[hpotk.TermId, float]:
    return {hpotk.TermId.from_curie(curie): ic for curie, ic in vals}


class TestIntersectionDistanceMeasure:
    @pytest.fixture(scope="class")
    def measure(
        self,
        term_id2cond_ic: typing.Mapping[hpotk.TermId, float],
    ) -> PDistanceMeasure:
        return PDistanceMeasure(
            tici=term_id2cond_ic,
        )

    def test_max_dist(
        self,
        measure: PDistanceMeasure,
    ):
        assert measure.max_dist == pytest.approx(10.0)

    def test_compute(
        self,
        measure: PDistanceMeasure,
    ):
        a = create_set(
            [
                "HP:0000",
                "HP:0200",
                "HP:0210",
            ],
        )
        bc = create_set(
            [
                "HP:0000",
                "HP:0100",
                "HP:0200",
                "HP:0210",
                "HP:0220",
            ],
        )

        val = measure.compute(a, bc)

        assert val == pytest.approx(3.5, rel=1.0e-6)


def create_set(
    vals: typing.Iterable[str],
) -> typing.Set[hpotk.TermId]:
    return set(hpotk.TermId.from_curie(v) for v in vals)
