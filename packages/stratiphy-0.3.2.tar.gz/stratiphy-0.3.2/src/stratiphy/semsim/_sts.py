import typing

import hpotk
from hpotk.constants.hpo.base import PHENOTYPIC_ABNORMALITY

from stratiphy.model import Phenotyped

from ._base import (
    BaseSimilarityMatrixCreator,
    DistanceMeasure,
    SimilarityMatrixCreator,
    SimilarityMatrixCreatorFactory,
    ValueAdaptor,
)
from ._ic import calculate_cic


class PTermAdaptor(
    ValueAdaptor[Phenotyped, typing.Set[hpotk.TermId]],
):
    def __init__(
        self,
        hpo: hpotk.MinimalOntology,
        root: hpotk.TermId = PHENOTYPIC_ABNORMALITY,
    ):
        super().__init__()
        self._hpo = hpo
        self._ign = set(self._hpo.graph.get_ancestors(root))

    def adapt(
        self,
        val: Phenotyped,
    ) -> typing.Set[hpotk.TermId]:
        n = set()
        for pf in val.phenotypic_features:
            if pf.is_present:
                if pf.identifier not in n and pf.identifier not in self._ign:
                    n.add(pf.identifier)
                for anc in self._hpo.graph.get_ancestors(pf):
                    if anc not in n and anc not in self._ign:
                        n.add(anc)

        return n


class PDistanceMeasure(
    DistanceMeasure[typing.Set[hpotk.TermId]],
):
    def __init__(
        self,
        tici: typing.Mapping[hpotk.TermId, float],
    ):
        super().__init__()
        self._tici = dict(tici)
        self._tic = sum(tici.values())

    @property
    def max_dist(self) -> float:
        return self._tic

    def compute(
        self,
        a: typing.Set[hpotk.TermId],
        b: typing.Set[hpotk.TermId],
    ) -> float:
        return self.max_dist - sum(self._tici[tid] for tid in a.intersection(b))


class PEDistanceMeasure:
    pass


class SetSimSimilarityMatrixCreator(
    BaseSimilarityMatrixCreator[typing.Set[hpotk.TermId]],
):
    def _prepare_dm(
        self,
        samples: typing.Sequence[Phenotyped],
    ) -> DistanceMeasure[typing.Set[hpotk.TermId]]:
        cic = calculate_cic(
            samples,
            hpo=self._hpo,
            root=self._root,
        )

        return PDistanceMeasure(cic)

    def _prepare_adaptor(
        self,
    ) -> ValueAdaptor[
        Phenotyped,
        typing.Set[hpotk.TermId],
    ]:
        return PTermAdaptor(self._hpo)


class SetSimSimilarityMatrixCreatorFactory(
    SimilarityMatrixCreatorFactory,
):
    def __init__(
        self,
        hpo: hpotk.MinimalOntology,
        root: hpotk.TermId = PHENOTYPIC_ABNORMALITY,
        base: float = 2,
    ):
        self._hpo = hpo
        self._root = root
        self._base = base

    def create(
        self,
        samples: typing.Sequence[Phenotyped],
    ) -> SimilarityMatrixCreator:
        """
        Create a similarity matrix creator for the cohort.
        """
        return SetSimSimilarityMatrixCreator(
            hpo=self._hpo,
            root=self._root,
            base=self._base,
        )
