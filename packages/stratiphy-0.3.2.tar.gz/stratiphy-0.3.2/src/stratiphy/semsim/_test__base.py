import typing

import numpy as np

from stratiphy.model import Phenotyped
from ._base import SimilarityMatrix, SimilarityMatrixCreator
from ._base import SimpleSimilarityMatrix as TrueSimilarityMatrix


class TestSimilarityMatrixCreator:
    class QuacksLikeSimilarityMatrixCreatorDespiteNotExtendingIt:
        def calculate_matrix(self, samples: typing.Sequence[Phenotyped]) -> SimilarityMatrix:
            raise NotImplementedError("Just a dummy method that should not be called")

    class DoesNotQuackLikeSimilarityMatrixCreator:
        def recalculate_matrix(self, samples: typing.Sequence[Phenotyped]) -> SimilarityMatrix:
            raise ValueError("Should not be called anyway")

    def test_issubclass(self):
        assert issubclass(
            TestSimilarityMatrixCreator.QuacksLikeSimilarityMatrixCreatorDespiteNotExtendingIt, SimilarityMatrixCreator
        )
        assert not issubclass(
            TestSimilarityMatrixCreator.DoesNotQuackLikeSimilarityMatrixCreator, SimilarityMatrixCreator
        )

        assert not issubclass(
            SimilarityMatrixCreator, TestSimilarityMatrixCreator.QuacksLikeSimilarityMatrixCreatorDespiteNotExtendingIt
        )
        assert not issubclass(
            SimilarityMatrixCreator, TestSimilarityMatrixCreator.DoesNotQuackLikeSimilarityMatrixCreator
        )

        assert issubclass(SimilarityMatrixCreator, SimilarityMatrixCreator)


class TestSimilarityMatrix:
    class QuacksLikeSimilarityMatrixDespiteNotExtendingIt:
        @property
        def similarity_matrix(self) -> np.ndarray:
            raise NotImplementedError("Just a dummy method that should not be called")

    class DoesNotQuackLikeSimilarityMatrix:
        @property
        def whatever(self) -> np.ndarray:
            raise ValueError("Should not be called anyway")

    def test_issubclass(self):
        assert issubclass(TrueSimilarityMatrix, SimilarityMatrix)

        assert issubclass(TestSimilarityMatrix.QuacksLikeSimilarityMatrixDespiteNotExtendingIt, SimilarityMatrix)
        assert not issubclass(TestSimilarityMatrix.DoesNotQuackLikeSimilarityMatrix, SimilarityMatrix)
