import abc
import inspect
import typing

import hpotk
import numpy as np

from stratiphy.model import Phenotyped

T = typing.TypeVar("T")
U = typing.TypeVar("U")


class ValueAdaptor(
    typing.Generic[T, U],
    metaclass=abc.ABCMeta,
):
    """
    Adapt the value for clustering and describe how to reduce a value pair.

    - `T`: the input value type.
    - `U`: the working data type.
    """

    @abc.abstractmethod
    def adapt(
        self,
        val: T,
    ) -> U:
        """
        Map the value to the type suitable for clustering.
        """
        ...


class DistanceMeasure(
    typing.Generic[T],
    metaclass=abc.ABCMeta,
):
    """
    Measure to quantify *distance* of a pair of `T`.
    """

    @property
    @abc.abstractmethod
    def max_dist(self) -> float:
        """
        Maximum possible distance.

        While `float('inf')` is the theoretical maximum,
        some distance measures provide a natural upper bound
        (e.g. `1.0` in Jaccard index).
        """
        ...

    @abc.abstractmethod
    def compute(
        self,
        a: T,
        b: T,
    ) -> float:
        """
        Compute the distance.

        The distance must *not* be `NaN` or a negative value.
        It can be infinity.

        :return: a non-negative float representing the distance.
        """
        ...


class SimilarityMatrix(
    metaclass=abc.ABCMeta,
):
    """
    `SimilarityMatrix` is a container with sample similarities - a symmetric numpy ND array accessible
    through :func:`similarity_matrix`.
    The container is created by :class:`SimilarityMatrixCreator`.
    """

    @property
    @abc.abstractmethod
    def similarity_matrix(self) -> np.ndarray:
        """
        Get the similarity matrix.
        """
        pass

    @classmethod
    def __subclasshook__(cls, subclass):
        # Any object that has a `similarity_matrix` property is a similarity matrix.
        # That's all we will check for now!
        if hasattr(subclass, "similarity_matrix"):
            sm = getattr(subclass, "similarity_matrix")
            return isinstance(sm, property)

        return False


class SimilarityMatrixCreator(
    metaclass=abc.ABCMeta,
):
    """
    `SimilarityMatrixCreator` calculates a similarity matrix for a sequence of :class:`Phenotyped` entities.
    """

    @abc.abstractmethod
    def calculate_matrix(
        self,
        samples: typing.Sequence[Phenotyped],
    ) -> SimilarityMatrix:
        """Calculate the similarity matrix using a kernel function.

        :param samples: a list of samples to calculate the similarity for.
        :return: :class:`SimilarityMatrix` - a container with symmetric matrix with shape
          ``(len(samples), len(samples))`` with sample similarities and optional additional data.
        """
        pass

    @classmethod
    def __subclasshook__(cls, subclass):
        # Any object that has a `calculate_matrix` method is a similarity matrix creator
        # The method must take one argument except of `self`.
        # That's all we will check for now!
        if hasattr(subclass, "calculate_matrix"):
            cm = getattr(subclass, "calculate_matrix")
            if callable(cm):
                signature = inspect.signature(cm)
                params = signature.parameters
                return "self" in params and len(params) == 2

        return False


class BaseSimilarityMatrixCreator(
    typing.Generic[T],
    SimilarityMatrixCreator,
    metaclass=abc.ABCMeta,
):
    def __init__(
        self,
        hpo: hpotk.MinimalOntology,
        root: hpotk.TermId,
        base: float,
    ):
        self._hpo = hpo
        self._root = root
        self._base = base

    @abc.abstractmethod
    def _prepare_dm(
        self,
        samples: typing.Sequence[Phenotyped],
    ) -> DistanceMeasure[T]: ...

    @abc.abstractmethod
    def _prepare_adaptor(
        self,
    ) -> ValueAdaptor[
        Phenotyped,
        T,
    ]: ...

    def calculate_matrix(
        self,
        samples: typing.Sequence[Phenotyped],
    ) -> SimilarityMatrix:
        measure = self._prepare_dm(samples)
        adaptor = self._prepare_adaptor()
        nodes = tuple(adaptor.adapt(s) for s in samples)
        dist = np.zeros(shape=(len(samples), len(samples)))

        for i, a in enumerate(nodes):
            for j in range(i, len(nodes)):
                b = nodes[j]
                dist[i, j] = measure.compute(a, b)
                if i != j:
                    dist[j, i] = dist[i, j]

        return SimpleSimilarityMatrix(measure.max_dist - dist)


class SimilarityMatrixCreatorFactory(
    metaclass=abc.ABCMeta,
):
    """
    Local similarity matrix creator factory creates a similarity matrix creator for the given cohort.
    """

    @abc.abstractmethod
    def create(
        self,
        samples: typing.Sequence[Phenotyped],
    ) -> SimilarityMatrixCreator:
        """
        Create a similarity matrix creator for the cohort.
        """
        ...


class SimpleSimilarityMatrix(SimilarityMatrix):
    """
    A simple :class:`SimilarityMatrix` backed by a dense Numpy array.
    """

    # Not in the public API.

    def __init__(
        self,
        similarity_matrix: np.ndarray,
    ):
        self._similarity_matrix = similarity_matrix

    @property
    def similarity_matrix(self) -> np.ndarray:
        return self._similarity_matrix

    def __repr__(self):
        return f"SimpleSimilarityMatrix(similarity_matrix={self._similarity_matrix})"

    def __str__(self):
        return repr(self)
