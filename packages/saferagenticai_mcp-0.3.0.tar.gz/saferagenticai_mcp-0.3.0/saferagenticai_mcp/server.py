"""SaferAgenticAI MCP server — stdio transport, five tools.

Tools:
    list_suites              -> inventory of all 16 suites
    get_requirement(id)      -> one subgoal + its pattern, resolves pattern_id or display_id
    list_requirements(...)   -> filtered list (by suite, content_type, etc.)
    search_patterns(query)   -> keyword search over titles, descriptions, SFRs, patterns
    get_cross_references(id) -> adjacent patterns (explicit + inferred via SFR overlap)

Run: `saferagenticai-mcp` after `pip install -e .` in the server directory.
"""

from __future__ import annotations

import asyncio
import json
import re
from typing import Any

from .framework_loader import (
    FrameworkIndex,
    Subgoal,
    load_framework,
    newer_source_exists,
    subgoal_to_dict,
)

_index: FrameworkIndex | None = None


def _get_index() -> FrameworkIndex:
    """Return the cached framework index, hot-reloading if any source file changed.

    Cheap: stat-walk the suites/ and exemplars/ dirs (~230 files) each call.
    For an interactive Phase-3 review workflow this is what you want: edit
    a pattern, call the MCP, see updated answer — no restart.
    """
    global _index
    if _index is None:
        _index = load_framework()
    elif newer_source_exists(_index):
        _index = load_framework()
    return _index


# ---------------------------------------------------------------------------
# Tool handlers — pure Python, no MCP types.
# ---------------------------------------------------------------------------


def _tool_list_suites(idx: FrameworkIndex) -> dict:
    return {
        "framework_version": idx.version,
        "suite_count": len(idx.suites),
        "suites": sorted(idx.suites.values(), key=lambda s: s["id"]),
        "note": (
            "Drivers (D1-D9) describe properties a safe agentic AI should have. "
            "Inhibitors (I1-I7) describe harms to prevent or detect. "
            "Each suite contains multiple subgoals, each with SFRs and evidence requirements."
        ),
    }


def _fuzzy_candidates(idx: FrameworkIndex, id_str: str, limit: int = 5) -> list:
    """Return up to `limit` best-matching subgoals for a malformed/partial id.

    Strategy: score each subgoal by how well its pattern_id, display_id, or
    title matches `id_str`. Cheap substring + prefix heuristics — no ML.
    """
    needle = id_str.lower().strip()
    if not needle:
        return []

    scored: list[tuple[int, Subgoal]] = []
    for s in idx.subgoals.values():
        score = 0
        pid_low = s.pattern_id.lower()
        disp_low = s.display_id.lower()
        title_low = s.title.lower()

        if needle == pid_low or needle == disp_low:
            score += 1000
        if pid_low.startswith(needle) or disp_low.startswith(needle):
            score += 100
        if needle in pid_low:
            score += 50
        # Slug-only match: e.g. 'logging-of-internal-goals-activities-and'
        pid_slug = pid_low.split("::")[-1] if "::" in pid_low else pid_low
        if needle in pid_slug or pid_slug.startswith(needle[:30]):
            score += 40
        # Title-substring match
        if needle in title_low:
            score += 30
        # Partial-word overlap in title
        needle_words = {w for w in re.split(r"\W+", needle) if len(w) > 2}
        title_words = {w for w in re.split(r"\W+", title_low) if len(w) > 2}
        score += 5 * len(needle_words & title_words)

        if score > 0:
            scored.append((score, s))

    scored.sort(key=lambda t: -t[0])
    return scored[:limit]


def _tool_get_requirement(idx: FrameworkIndex, id_str: str, include_pattern: bool) -> dict:
    matches = idx.resolve_all(id_str)
    if matches:
        if len(matches) == 1:
            return {"match_count": 1, "subgoal": subgoal_to_dict(matches[0], include_pattern)}
        return {
            "match_count": len(matches),
            "note": (
                f"'{id_str}' matched {len(matches)} subgoals (display_id collision). "
                "Use pattern_id for an unambiguous lookup."
            ),
            "subgoals": [subgoal_to_dict(s, include_pattern) for s in matches],
        }

    # No exact match — fuzzy fall-through so the caller never has to guess.
    candidates = _fuzzy_candidates(idx, id_str, limit=5)
    if not candidates:
        return {
            "error": f"no subgoal found for '{id_str}'",
            "hint": "Call resolve_id with a keyword, or search_patterns.",
        }
    return {
        "match_count": 0,
        "note": (
            f"no exact match for '{id_str}'. Closest candidates shown — "
            "re-call with a pattern_id from this list."
        ),
        "candidates": [
            {
                "pattern_id": s.pattern_id,
                "display_id": s.display_id,
                "title": s.title,
                "suite_id": s.suite_id,
                "score": score,
            }
            for score, s in candidates
        ],
    }


def _meets_confidence(pattern_conf: str | None, min_conf: str) -> bool:
    order = {"low": 0, "medium": 1, "high": 2}
    if pattern_conf not in order:
        return False
    return order[pattern_conf] >= order[min_conf]


def _tool_list_requirements(idx: FrameworkIndex, **filters) -> dict:
    results: list[Subgoal] = list(idx.subgoals.values())

    if suite := filters.get("suite_id"):
        results = [s for s in results if s.suite_id == suite]
    if stype := filters.get("suite_type"):
        results = [s for s in results if s.suite_type == stype]
    if ctype := filters.get("content_type"):
        results = [s for s in results if s.content_type == ctype]
    if min_conf := filters.get("min_confidence"):
        results = [s for s in results if _meets_confidence(s.confidence, min_conf)]
    if filters.get("missing_pattern_only"):
        results = [s for s in results if not s.has_pattern]

    include_pattern = bool(filters.get("include_pattern", False))
    return {
        "match_count": len(results),
        "filters": {k: v for k, v in filters.items() if v is not None},
        "subgoals": [subgoal_to_dict(s, include_pattern) for s in results],
    }


def _count_occurrences(haystack: str, needles: list[str]) -> tuple[int, str]:
    """Return (count, best snippet) for lowercase substring matches."""
    h = haystack.lower()
    count = 0
    for n in needles:
        count += h.count(n)
    snippet = ""
    if count:
        for n in needles:
            i = h.find(n)
            if i >= 0:
                start = max(0, i - 60)
                end = min(len(haystack), i + 120)
                snippet = haystack[start:end].strip()
                break
    return count, snippet


FIELD_WEIGHTS = {
    "title": 10,
    "summary": 4,
    "sfr": 3,
    "description": 2,
    "body": 1,
}


def _tool_search_patterns(
    idx: FrameworkIndex, query: str, limit: int, verbosity: str = "full"
) -> dict:
    """Field-weighted keyword search.

    Weights: title 10x, summary 4x, SFR text 3x, description 2x, pattern body 1x.
    Returns the snippet from the highest-weighted field that matched,
    so callers see *why* the match was ranked high.

    `verbosity`:
        - "compact": id, display_id, suite_id, title, score, matched_in
          (no snippet, no confidence flags). ~70% smaller; use for triage.
        - "full" (default): adds snippet, confidence, needs_human_review.
    """
    terms = [t for t in re.split(r"\W+", query.lower()) if t]
    if not terms:
        return {"error": "empty query"}

    scored: list[tuple[int, Subgoal, str, str]] = []
    for s in idx.subgoals.values():
        total = 0
        best_snippet = ""
        best_field = ""

        # Title: heavy weight (10)
        c, snip = _count_occurrences(s.title, terms)
        if c:
            total += c * 10
            if snip and not best_snippet:
                best_snippet = snip
                best_field = "title"

        # Summary (if patterned): weight 4
        if s.pattern:
            summary = str(s.pattern.get("summary", ""))
            c, snip = _count_occurrences(summary, terms)
            if c:
                total += c * 4
                if snip and best_field in ("", "body"):
                    best_snippet = snip
                    best_field = "summary"

        # SFR text: weight 3
        for sfr in s.sfrs:
            txt = sfr.get("text", "")
            c, snip = _count_occurrences(txt, terms)
            if c:
                total += c * 3
                if snip and best_field in ("", "body", "description"):
                    best_snippet = snip
                    best_field = "sfr"

        # Description: weight 2
        c, snip = _count_occurrences(s.description, terms)
        if c:
            total += c * 2
            if snip and best_field in ("", "body"):
                best_snippet = snip
                best_field = "description"

        # Pattern body (everything else): weight 1
        if s.pattern:
            body = str(s.pattern)
            c, snip = _count_occurrences(body, terms)
            if c:
                total += c
                if snip and not best_snippet:
                    best_snippet = snip
                    best_field = "body"

        if total > 0:
            scored.append((total, s, best_snippet, best_field))

    scored.sort(key=lambda t: -t[0])
    top = scored[:limit]
    compact = verbosity == "compact"
    results = []
    for score, s, snippet, field in top:
        row = {
            "pattern_id": s.pattern_id,
            "display_id": s.display_id,
            "suite_id": s.suite_id,
            "title": s.title,
            "score": score,
            "matched_in": field,
        }
        if not compact:
            row["snippet"] = snippet
            row["confidence"] = s.pattern.get("confidence") if s.pattern else None
            row["needs_human_review"] = (
                s.pattern.get("needs_human_review") if s.pattern else None
            )
        results.append(row)
    out = {
        "query": query,
        "total_matches": len(scored),
        "returned": len(top),
        "results": results,
    }
    if compact:
        out["verbosity"] = "compact"
        out["next_step_hint"] = (
            "Pick a pattern_id and call get_requirement(id) for full pattern body, "
            "or re-call with verbosity='full' for snippets and confidence flags."
        )
    return out


def _tool_resolve_id(idx: FrameworkIndex, query: str, limit: int = 5) -> dict:
    """Resolve a loose reference (partial id, display_id, slug fragment, title) to candidates."""
    # Exact resolvers first
    exact = idx.resolve_all(query)
    if exact:
        return {
            "query": query,
            "resolved": True,
            "match_count": len(exact),
            "candidates": [
                {
                    "pattern_id": s.pattern_id,
                    "display_id": s.display_id,
                    "suite_id": s.suite_id,
                    "title": s.title,
                    "score": 1000,
                }
                for s in exact
            ],
        }
    # Fuzzy fallback
    scored = _fuzzy_candidates(idx, query, limit=limit)
    return {
        "query": query,
        "resolved": False,
        "match_count": len(scored),
        "candidates": [
            {
                "pattern_id": s.pattern_id,
                "display_id": s.display_id,
                "suite_id": s.suite_id,
                "title": s.title,
                "score": score,
            }
            for score, s in scored
        ],
    }


_STOPWORDS = {
    "a", "an", "the", "and", "or", "but", "to", "of", "for", "in", "on", "at",
    "by", "with", "that", "this", "is", "are", "was", "were", "be", "been",
    "being", "it", "its", "i", "we", "our", "my", "you", "your", "how", "what",
    "when", "where", "why", "do", "does", "did", "can", "should", "would",
    "will", "user", "users", "agent", "system", "systems", "ai",
}


def _tool_find_patterns_for_task(
    idx: FrameworkIndex, task: str, limit: int = 8, verbosity: str = "compact"
) -> dict:
    """Given a natural-language task description, return the most relevant patterns.

    Thin wrapper: extracts content words, runs field-weighted search, then
    groups results by suite so the caller sees which concerns a task spans.

    `verbosity` defaults to "compact" here: callers typically use this tool
    for triage, then drill into a chosen pattern_id with get_requirement().
    Pass "full" to inline snippets and confidence flags.
    """
    words = [w for w in re.split(r"\W+", task.lower()) if len(w) > 2 and w not in _STOPWORDS]
    if not words:
        return {"error": "task description too short after stop-word removal"}
    query = " ".join(words)

    search = _tool_search_patterns(idx, query, limit=limit, verbosity=verbosity)
    if "error" in search:
        return search

    # Group by suite, with suite title for context
    by_suite: dict[str, list] = {}
    for hit in search["results"]:
        by_suite.setdefault(hit["suite_id"], []).append(hit)

    suites_touched = []
    for suite_id in sorted(by_suite.keys()):
        suite_meta = idx.suites.get(suite_id, {})
        suites_touched.append(
            {
                "suite_id": suite_id,
                "suite_title": suite_meta.get("title", ""),
                "suite_type": suite_meta.get("type", ""),
                "patterns": by_suite[suite_id],
            }
        )

    return {
        "task": task,
        "keywords_used": words,
        "total_matches": search["total_matches"],
        "suites_touched": suites_touched,
        "flat_top": search["results"],
        "next_step_hint": (
            "For each pattern_id above, call get_requirement(id, include_pattern=true) "
            "to see its named design patterns, anti-patterns, and SFR anchors."
        ),
    }


def _tool_get_cross_references(
    idx: FrameworkIndex, id_str: str, include_inferred: bool
) -> dict:
    matches = idx.resolve_all(id_str)
    if not matches:
        return {"error": f"no subgoal found for '{id_str}'"}
    if len(matches) > 1:
        return {
            "error": f"'{id_str}' is ambiguous ({len(matches)} matches). Use a pattern_id.",
            "candidates": [m.pattern_id for m in matches],
        }
    s = matches[0]

    explicit: list[str] = []
    if s.pattern:
        refs = s.pattern.get("cross_references") or []
        if isinstance(refs, str):
            refs = [refs]
        explicit = [r for r in refs if r in idx.subgoals]

    inferred: list[dict] = []
    if include_inferred:
        # Suite neighbours (same suite, not the same subgoal)
        for pid in idx.by_suite.get(s.suite_id, []):
            if pid == s.pattern_id:
                continue
            if pid in explicit:
                continue
            inferred.append(
                {
                    "pattern_id": pid,
                    "reason": "same suite",
                    "display_id": idx.subgoals[pid].display_id,
                    "title": idx.subgoals[pid].title,
                }
            )

    return {
        "of": {
            "pattern_id": s.pattern_id,
            "display_id": s.display_id,
            "title": s.title,
        },
        "explicit_cross_references": [
            {
                "pattern_id": pid,
                "display_id": idx.subgoals[pid].display_id,
                "title": idx.subgoals[pid].title,
                "suite_id": idx.subgoals[pid].suite_id,
            }
            for pid in explicit
        ],
        "inferred_adjacent": inferred,
        "review_notes": s.pattern.get("review_notes") if s.pattern else None,
    }


def _tool_list_unreviewed(idx: FrameworkIndex, limit: int | None = None) -> dict:
    """Return patterns that have no `reviewed_by` field yet.

    Intended for Phase 3: Nell walks through unreviewed patterns.
    Sort order: low confidence first, then `needs_human_review: true`, then alpha.
    """
    unreviewed: list[Subgoal] = []
    for s in idx.subgoals.values():
        if not s.pattern:
            continue
        if s.pattern.get("reviewed_by"):
            continue
        unreviewed.append(s)

    def sort_key(s: Subgoal):
        p = s.pattern or {}
        conf = p.get("confidence", "medium")
        conf_rank = {"low": 0, "medium": 1, "high": 2}.get(conf, 1)
        needs = 0 if p.get("needs_human_review") else 1
        return (conf_rank, needs, s.pattern_id)

    unreviewed.sort(key=sort_key)
    if limit:
        unreviewed = unreviewed[:limit]

    total = sum(
        1 for s in idx.subgoals.values() if s.pattern and not s.pattern.get("reviewed_by")
    )
    return {
        "total_unreviewed": total,
        "returned": len(unreviewed),
        "subgoals": [
            {
                "pattern_id": s.pattern_id,
                "display_id": s.display_id,
                "suite_id": s.suite_id,
                "title": s.title,
                "confidence": s.confidence,
                "needs_human_review": (s.pattern or {}).get("needs_human_review", False),
                "content_type": s.content_type,
            }
            for s in unreviewed
        ],
        "next_step_hint": (
            "After reviewing a pattern, add `reviewed_by: <your name>` and "
            "`reviewed_on: <ISO date>` to its YAML. The server hot-reloads on "
            "file change."
        ),
    }


def _tool_review_stats(idx: FrameworkIndex) -> dict:
    """Return coverage stats: reviewed vs unreviewed, per suite, per confidence."""
    total = 0
    reviewed = 0
    per_suite_total: dict[str, int] = {}
    per_suite_reviewed: dict[str, int] = {}
    per_conf_total: dict[str, int] = {}
    per_conf_reviewed: dict[str, int] = {}
    flagged_for_review = 0
    flagged_reviewed = 0

    for s in idx.subgoals.values():
        if not s.pattern:
            continue
        total += 1
        suite = s.suite_id
        conf = s.confidence or "unknown"
        per_suite_total[suite] = per_suite_total.get(suite, 0) + 1
        per_conf_total[conf] = per_conf_total.get(conf, 0) + 1
        if s.pattern.get("needs_human_review"):
            flagged_for_review += 1
        if s.pattern.get("reviewed_by"):
            reviewed += 1
            per_suite_reviewed[suite] = per_suite_reviewed.get(suite, 0) + 1
            per_conf_reviewed[conf] = per_conf_reviewed.get(conf, 0) + 1
            if s.pattern.get("needs_human_review"):
                flagged_reviewed += 1

    pct = lambda r, t: round(100 * r / t, 1) if t else 0.0
    return {
        "total_patterns": total,
        "reviewed": reviewed,
        "unreviewed": total - reviewed,
        "percent_reviewed": pct(reviewed, total),
        "flagged_for_review": flagged_for_review,
        "flagged_and_reviewed": flagged_reviewed,
        "by_suite": {
            suite: {
                "total": per_suite_total[suite],
                "reviewed": per_suite_reviewed.get(suite, 0),
                "percent": pct(per_suite_reviewed.get(suite, 0), per_suite_total[suite]),
            }
            for suite in sorted(per_suite_total.keys())
        },
        "by_confidence": {
            c: {
                "total": per_conf_total[c],
                "reviewed": per_conf_reviewed.get(c, 0),
                "percent": pct(per_conf_reviewed.get(c, 0), per_conf_total[c]),
            }
            for c in ("low", "medium", "high")
            if c in per_conf_total
        },
        "validation_issues_at_load": len(idx.validation_issues),
        "sample_validation_issues": idx.validation_issues[:5],
    }


def _tool_get_reverse_references(idx: FrameworkIndex, id_str: str) -> dict:
    """Return patterns that reference the given pattern_id in their cross_references."""
    matches = idx.resolve_all(id_str)
    if not matches:
        return {"error": f"no subgoal found for '{id_str}'"}
    if len(matches) > 1:
        return {
            "error": f"'{id_str}' is ambiguous ({len(matches)} matches). Use a pattern_id.",
            "candidates": [m.pattern_id for m in matches],
        }
    target = matches[0]
    referrers = idx.reverse_xrefs.get(target.pattern_id, [])
    return {
        "of": {
            "pattern_id": target.pattern_id,
            "display_id": target.display_id,
            "title": target.title,
        },
        "referenced_by_count": len(referrers),
        "referenced_by": [
            {
                "pattern_id": pid,
                "display_id": idx.subgoals[pid].display_id,
                "suite_id": idx.subgoals[pid].suite_id,
                "title": idx.subgoals[pid].title,
            }
            for pid in referrers
        ],
    }


TOOL_HANDLERS = {
    "list_suites": lambda idx, args: _tool_list_suites(idx),
    "get_requirement": lambda idx, args: _tool_get_requirement(
        idx, id_str=args["id"], include_pattern=args.get("include_pattern", True)
    ),
    "list_requirements": lambda idx, args: _tool_list_requirements(idx, **args),
    "search_patterns": lambda idx, args: _tool_search_patterns(
        idx,
        query=args["query"],
        limit=args.get("limit", 10),
        verbosity=args.get("verbosity", "full"),
    ),
    "get_cross_references": lambda idx, args: _tool_get_cross_references(
        idx, id_str=args["id"], include_inferred=args.get("include_inferred", True)
    ),
    "resolve_id": lambda idx, args: _tool_resolve_id(
        idx, query=args["query"], limit=args.get("limit", 5)
    ),
    "find_patterns_for_task": lambda idx, args: _tool_find_patterns_for_task(
        idx,
        task=args["task"],
        limit=args.get("limit", 8),
        verbosity=args.get("verbosity", "compact"),
    ),
    "list_unreviewed": lambda idx, args: _tool_list_unreviewed(
        idx, limit=args.get("limit")
    ),
    "review_stats": lambda idx, args: _tool_review_stats(idx),
    "get_reverse_references": lambda idx, args: _tool_get_reverse_references(
        idx, id_str=args["id"]
    ),
}


def dispatch(name: str, arguments: dict) -> dict:
    """Call one tool. Returns the raw result dict; pure Python, no MCP types."""
    idx = _get_index()
    handler = TOOL_HANDLERS.get(name)
    if handler is None:
        return {"error": f"unknown tool: {name}"}
    try:
        return handler(idx, arguments or {})
    except Exception as e:
        return {"error": str(e), "tool": name}


# ---------------------------------------------------------------------------
# MCP wiring (only imported when the mcp package is installed)
# ---------------------------------------------------------------------------


def _build_mcp_server():
    """Lazily import mcp so this module is usable for local testing without it."""
    from mcp.server import Server
    from mcp.types import Tool, TextContent

    server = Server("saferagenticai")

    TOOLS = [
        Tool(
            name="list_suites",
            description=(
                "List all 16 suites in the SaferAgenticAI framework (9 drivers + 7 inhibitors) "
                "with subgoal counts and titles. Call this first to orient."
            ),
            inputSchema={"type": "object", "properties": {}, "additionalProperties": False},
        ),
        Tool(
            name="get_requirement",
            description=(
                "Retrieve one subgoal (framework normative content + Pattern layer guidance) "
                "by pattern_id (e.g., 'D3::idx2::sandboxing') or display_id (e.g., 'D3.2'). "
                "display_id may resolve to multiple subgoals — underlined variants share display_ids."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "id": {"type": "string"},
                    "include_pattern": {"type": "boolean", "default": True},
                },
                "required": ["id"],
                "additionalProperties": False,
            },
        ),
        Tool(
            name="list_requirements",
            description="List subgoals matching filters (suite_id, suite_type, content_type, min_confidence, missing_pattern_only).",
            inputSchema={
                "type": "object",
                "properties": {
                    "suite_id": {"type": "string"},
                    "suite_type": {"type": "string", "enum": ["driver", "inhibitor"]},
                    "content_type": {
                        "type": "string",
                        "enum": ["code-applicable", "governance", "process", "ecosystem"],
                    },
                    "min_confidence": {"type": "string", "enum": ["low", "medium", "high"]},
                    "missing_pattern_only": {"type": "boolean"},
                    "include_pattern": {"type": "boolean", "default": False},
                },
                "additionalProperties": False,
            },
        ),
        Tool(
            name="search_patterns",
            description=(
                "Field-weighted keyword search across the framework. Substring "
                "match on lowercased terms; field weights: title 10x, summary 4x, "
                "SFR text 3x, description 2x, pattern body 1x. `matched_in` "
                "reports the highest-weighted field that matched. No semantic / "
                "embedding search — known limitation, see /mcp.html. "
                "Use verbosity='compact' to drop snippets and confidence flags "
                "(~70% smaller payload) when triaging."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "query": {"type": "string", "minLength": 2},
                    "limit": {"type": "integer", "minimum": 1, "maximum": 50, "default": 10},
                    "verbosity": {
                        "type": "string",
                        "enum": ["compact", "full"],
                        "default": "full",
                    },
                },
                "required": ["query"],
                "additionalProperties": False,
            },
        ),
        Tool(
            name="get_cross_references",
            description=(
                "Return outgoing adjacencies for a pattern. `explicit_cross_references` "
                "are author-asserted (each pattern's `cross_references` YAML field). "
                "`inferred_adjacent` (when include_inferred=true) currently returns "
                "*same-suite siblings only* — it does not do semantic similarity. "
                "Treat inferred entries as 'neighbours worth scanning,' not as "
                "endorsed dependencies."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "id": {"type": "string"},
                    "include_inferred": {"type": "boolean", "default": True},
                },
                "required": ["id"],
                "additionalProperties": False,
            },
        ),
        Tool(
            name="resolve_id",
            description=(
                "Resolve a loose reference (partial id, display_id, slug fragment, "
                "or title keyword) to canonical pattern_id(s). Call this when you "
                "have a rough reference and need the exact id before calling "
                "get_requirement. Always returns candidates — never 'not found'."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "query": {"type": "string", "minLength": 1},
                    "limit": {"type": "integer", "minimum": 1, "maximum": 20, "default": 5},
                },
                "required": ["query"],
                "additionalProperties": False,
            },
        ),
        Tool(
            name="find_patterns_for_task",
            description=(
                "Given a natural-language task description (e.g., 'I'm building a "
                "tool-using agent that runs shell commands'), return the most relevant "
                "patterns grouped by suite. Use this as a starting point for any "
                "cross-cutting design question; then follow up with get_requirement "
                "on specific pattern_ids. Defaults to verbosity='compact' (cheap "
                "triage); pass 'full' to inline snippets and confidence flags."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "task": {"type": "string", "minLength": 5},
                    "limit": {"type": "integer", "minimum": 1, "maximum": 25, "default": 8},
                    "verbosity": {
                        "type": "string",
                        "enum": ["compact", "full"],
                        "default": "compact",
                    },
                },
                "required": ["task"],
                "additionalProperties": False,
            },
        ),
        Tool(
            name="list_unreviewed",
            description=(
                "Return patterns that have not been human-reviewed yet (no reviewed_by). "
                "Sorted low-confidence first, then needs_human_review flagged, then alpha. "
                "Use during Phase 3 review to pick the next pattern to examine."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "limit": {"type": "integer", "minimum": 1, "maximum": 250},
                },
                "additionalProperties": False,
            },
        ),
        Tool(
            name="review_stats",
            description=(
                "Coverage stats: total patterns, reviewed %, per-suite and per-confidence "
                "breakdown. Surfaces load-time validation issue count."
            ),
            inputSchema={"type": "object", "properties": {}, "additionalProperties": False},
        ),
        Tool(
            name="get_reverse_references",
            description=(
                "Return patterns that reference the given pattern_id in their "
                "cross_references. Complement to get_cross_references (outgoing); "
                "this shows incoming. Use to find all consumers of a given pattern."
            ),
            inputSchema={
                "type": "object",
                "properties": {"id": {"type": "string"}},
                "required": ["id"],
                "additionalProperties": False,
            },
        ),
    ]

    @server.list_tools()
    async def list_tools():
        return TOOLS

    @server.call_tool()
    async def call_tool(name: str, arguments: dict):
        result = dispatch(name, arguments or {})
        return [TextContent(type="text", text=json.dumps(result, indent=2, default=str))]

    return server


async def _run() -> None:
    from mcp.server.stdio import stdio_server

    server = _build_mcp_server()
    async with stdio_server() as (read, write):
        await server.run(read, write, server.create_initialization_options())


def main() -> None:
    asyncio.run(_run())


if __name__ == "__main__":
    main()
