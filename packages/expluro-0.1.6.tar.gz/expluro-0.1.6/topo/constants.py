APP_NAME = "expluro"
APP_DISPLAY_NAME = "Expluro"
APP_DIR = f".{APP_NAME}"
PROMPT = f"[{APP_NAME}] > "
