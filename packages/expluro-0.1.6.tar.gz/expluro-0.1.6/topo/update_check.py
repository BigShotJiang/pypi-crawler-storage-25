import importlib.metadata
import httpx


def check_for_update() -> str | None:
    """Returns the latest version string if newer than installed, else None."""
    try:
        installed = importlib.metadata.version("expluro")
        resp = httpx.get("https://pypi.org/pypi/expluro/json", timeout=3)
        if resp.status_code == 200:
            latest = resp.json()["info"]["version"]
            if _is_newer(latest, installed):
                return latest
    except Exception:
        pass
    return None


def _is_newer(latest: str, installed: str) -> bool:
    def parse(v: str) -> tuple:
        return tuple(int(x) for x in v.split("."))
    try:
        return parse(latest) > parse(installed)
    except Exception:
        return False
