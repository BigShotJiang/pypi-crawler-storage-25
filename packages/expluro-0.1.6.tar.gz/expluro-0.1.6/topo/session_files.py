"""
session_files.py — Claude Code session file utilities.

Claude Code stores sessions as JSONL files at:
  ~/.claude/projects/<cwd-hash>/<session-id>.jsonl

On branch switch we need to create a standalone copy of the parent session,
truncated at the branch point, so the new subprocess can --resume it.

We do NOT use the SDK's fork_session() because it adds forkedFrom fields to
every entry — Claude Code follows those back to the parent session and writes
new turns there instead of the new branch file.

Instead we hand-copy the relevant entries (user, attachment, assistant),
rewrite all UUIDs so there is no overlap with the parent file, and write a
clean file that Claude Code treats as an independent session.
"""
from __future__ import annotations

import json
import logging
import uuid
from pathlib import Path

logger = logging.getLogger(__name__)


def get_cc_project_dir(cwd: str) -> Path:
    """
    Return the Claude Code project directory for the given working directory.
    Claude Code maps cwd → ~/.claude/projects/<cwd-with-slashes-replaced-by-dashes>.
    """
    project_hash = cwd.replace("/", "-")
    return Path.home() / ".claude" / "projects" / project_hash


def get_session_file_path(session_id: str, cwd: str) -> Path | None:
    """Return the path to a session file, or None if it doesn't exist."""
    path = get_cc_project_dir(cwd) / f"{session_id}.jsonl"
    return path if path.exists() else None


def delete_session_file(session_id: str, cwd: str) -> bool:
    """
    Delete a session file from disk. Used when abandoning a branch that was
    never used — the copied session file would otherwise sit on disk consuming
    memory equal to the parent's full context.

    Returns True if the file was deleted, False if it didn't exist or deletion failed.
    """
    path = get_session_file_path(session_id, cwd)
    if not path:
        return False
    try:
        path.unlink()
        logger.info("session_files: deleted abandoned session file %s", session_id)
        return True
    except Exception as exc:
        logger.warning("session_files: failed to delete session file %s: %s", session_id, exc)
        return False


def fork_at_message_count(
    source_session_id: str,
    cwd: str,
    message_count: int,
) -> str | None:
    """
    Create a standalone branch session file copied from the source session,
    truncated to message_count conversation messages. Returns the new session
    ID or None on failure.

    Why not fork_session() from the SDK: it stamps forkedFrom on every entry,
    which causes Claude Code to resolve writes back to the parent session file.
    We need a file that looks like an independent session with no parent links.

    What we include: real user prompts, tool results, attachments, and all
    assistant responses (including intermediate tool_use steps) — everything
    that belongs to each collected turn.

    What we skip: queue-operation, last-prompt (internal bookkeeping that
    Claude Code re-creates for each subprocess run), and API error entries.

    All UUIDs are rewritten to fresh values so there is zero overlap with the
    parent session file.
    """
    source_path = get_session_file_path(source_session_id, cwd)
    if not source_path:
        logger.warning(
            "session_files: source session file not found for %s in %s",
            source_session_id, cwd,
        )
        return None

    try:
        entries = _collect_turns(source_path, message_count)
    except Exception as exc:
        logger.warning("session_files: failed to read session file: %s", exc)
        return None

    if not entries:
        logger.warning(
            "session_files: no entries collected from %s (message_count=%d)",
            source_session_id, message_count,
        )
        return None

    entries = _rewrite_uuids(entries)

    new_session_id = str(uuid.uuid4())
    dest_path = get_cc_project_dir(cwd) / f"{new_session_id}.jsonl"

    try:
        # Use 0o600 (owner read-write only) to match Claude Code's own session
        # file permissions. Claude Code validates permissions before resuming a
        # session file and silently rejects files with looser permissions.
        import os
        fd = os.open(str(dest_path), os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            for entry in entries:
                entry["sessionId"] = new_session_id
                f.write(json.dumps(entry, ensure_ascii=False) + "\n")
    except Exception as exc:
        logger.warning("session_files: failed to write branch session file: %s", exc)
        return None

    logger.info(
        "session_files: created branch session %s from %s (%d messages)",
        new_session_id, source_session_id, message_count,
    )
    return new_session_id


# ------------------------------------------------------------------
# Internal
# ------------------------------------------------------------------

def _collect_turns(path: Path, message_count: int) -> list[dict]:
    """
    Walk the session JSONL and collect entries up to message_count, where
    message_count = inherited_context_length = number of {role, content} pairs
    in materialized_context (user prompts + assistant text responses, 2 per
    exchange).

    Strategy: only count real user prompts (user entries with string content) —
    these map 1:1 with materialized_context user entries. Everything that
    follows a real user prompt (attachments, intermediate assistants with
    tool_use, tool results, final assistant response) belongs to that user's
    turn and is included wholesale. We stop when we've collected
    (message_count // 2) complete user turns, which corresponds to
    message_count materialized_context entries.

    This correctly handles multi-step tool use: a single materialized_context
    exchange may span many session file entries (tool_use → tool_result →
    tool_use → tool_result → final assistant). We include all of them.

    Skipped entirely: queue-operation, last-prompt (Claude Code regenerates
    these fresh each subprocess run), and API error assistant entries.
    """
    # materialized_context counts user prompts and assistant responses equally,
    # so message_count // 2 is the number of real user prompts to collect.
    # If message_count is odd (branch cut after a user message but before the
    # assistant response), we round up — better to include a complete turn than
    # leave a dangling user message with no assistant response.
    user_turns_needed = (message_count + 1) // 2

    result: list[dict] = []
    user_turns_collected = 0
    in_turn = False  # True after a real user prompt, collecting until next one

    with path.open(encoding="utf-8") as f:
        for raw in f:
            raw = raw.strip()
            if not raw:
                continue
            try:
                entry = json.loads(raw)
            except json.JSONDecodeError:
                continue

            t = entry.get("type", "")

            if t in ("queue-operation", "last-prompt"):
                continue

            if t == "user":
                content = entry.get("message", {}).get("content")

                if isinstance(content, str):
                    # Real user prompt — start of a new turn
                    if user_turns_collected >= user_turns_needed:
                        break
                    result.append(entry)
                    user_turns_collected += 1
                    in_turn = True
                else:
                    # Tool result — belongs to the current turn, include it
                    if in_turn:
                        result.append(entry)

            elif t in ("attachment", "assistant"):
                if t == "assistant" and entry.get("isApiErrorMessage"):
                    continue
                if in_turn:
                    result.append(entry)

    return result


def _rewrite_uuids(entries: list[dict]) -> list[dict]:
    """
    Replace every uuid and parentUuid with fresh values.

    Claude Code uses entry UUIDs to identify which session file to write
    new turns to. If the branch file shares UUIDs with the parent file,
    Claude Code may resolve writes to the parent. Fresh UUIDs make the
    branch file fully independent.

    parentUuid values that point to entries we included are remapped to the
    corresponding new UUID. parentUuid values that point to skipped entries
    (e.g. queue-operation) are set to the most recently included entry's
    new UUID so the chain remains intact.
    """
    old_to_new: dict[str, str] = {}
    last_new_uuid: str | None = None
    result: list[dict] = []

    for entry in entries:
        new_entry = dict(entry)

        old_uuid = entry.get("uuid")
        if old_uuid:
            fresh = str(uuid.uuid4())
            old_to_new[old_uuid] = fresh
            new_entry["uuid"] = fresh
            last_new_uuid = fresh

        old_parent = entry.get("parentUuid")
        if old_parent is not None:
            if old_parent in old_to_new:
                new_entry["parentUuid"] = old_to_new[old_parent]
            else:
                # parentUuid refers to a skipped entry — point to the most
                # recent entry we did include to keep the chain intact.
                new_entry["parentUuid"] = last_new_uuid

        result.append(new_entry)

    return result
