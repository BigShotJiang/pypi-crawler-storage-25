"""
picker.py — Arrow-key pickers for session selection and permission prompts.
"""
from __future__ import annotations

import datetime
from typing import Any

from prompt_toolkit import Application
from prompt_toolkit.formatted_text import HTML, to_formatted_text
from prompt_toolkit.key_binding import KeyBindings
from prompt_toolkit.layout import Layout
from prompt_toolkit.layout.containers import Window
from prompt_toolkit.layout.controls import FormattedTextControl


async def pick_option(header: str, options: list[tuple[str, Any]]) -> Any:
    """
    Generic arrow-key picker. Shows `header` then a list of labelled options.

    `options` is a list of (label, value) tuples.
    Returns the value of the selected option, or raises KeyboardInterrupt on cancel.
    """
    state = {"index": 0}

    def _render() -> HTML:
        lines = [f"{header}\n\n"]
        for i, (label, _) in enumerate(options):
            cursor = "<ansiwhite>▶ </ansiwhite>" if i == state["index"] else "  "
            fmt = f"<ansiwhite><b>{label}</b></ansiwhite>" if i == state["index"] else f"<ansiwhite>{label}</ansiwhite>"
            lines.append(f"  {cursor}{fmt}\n")
        lines.append("\n  <ansibrightblack>↑/↓ to navigate · Enter to select · Ctrl+C to cancel</ansibrightblack>\n")
        return HTML("".join(lines))

    kb = KeyBindings()

    @kb.add("up")
    def _up(event):
        state["index"] = (state["index"] - 1) % len(options)

    @kb.add("down")
    def _down(event):
        state["index"] = (state["index"] + 1) % len(options)

    @kb.add("enter")
    def _enter(event):
        event.app.exit(result=options[state["index"]][1])

    @kb.add("c-c")
    @kb.add("escape")
    def _cancel(event):
        event.app.exit(exception=KeyboardInterrupt())

    control = FormattedTextControl(text=lambda: to_formatted_text(_render()), focusable=True)
    layout = Layout(Window(content=control))
    app: Application = Application(layout=layout, key_bindings=kb, full_screen=False, mouse_support=False)
    return await app.run_async()


async def pick_node(nodes: list[dict[str, Any]], has_more: bool, current_node_id: str | None = None) -> "dict | None | str":
    """
    Arrow-key picker for node selection.
    Returns: selected node dict, None (cancelled), or the sentinel string "load_more".
    """
    LOAD_MORE = "__load_more__"
    choices: list[Any] = list(nodes)
    if has_more:
        choices.append(LOAD_MORE)

    state = {"index": 0}

    STATUS_COLOR = {
        "active": "ansigreen",
        "branched": "ansiyellow",
        "dead_end": "ansired",
        "merged": "ansicyan",
    }

    def _render() -> HTML:
        lines = ["<ansibrightblack>  Select a node:\n\n</ansibrightblack>"]
        for i, choice in enumerate(choices):
            cursor = "<ansiwhite>▶ </ansiwhite>" if i == state["index"] else "  "
            selected = i == state["index"]
            if choice is LOAD_MORE:
                lines.append(f"  {cursor}<ansibrightblack>Load more…</ansibrightblack>\n\n")
            else:
                is_current = choice.get("id") == current_node_id
                label = choice.get("label") or "(untitled)"
                truncated = label[:52] + ("…" if len(label) > 52 else "")
                node_id_short = str(choice.get("id", ""))[:8]
                status = choice.get("status", "active")
                sc = STATUS_COLOR.get(status, "ansibrightblack")
                msg_count = len(choice.get("materialized_context", []))
                time_str = _relative_time(choice.get("updated_at", ""))
                current_tag = "  <ansibrightblack>(current)</ansibrightblack>" if is_current else ""
                label_fmt = f"<ansiwhite><b>{truncated}</b></ansiwhite>" if selected else f"<ansiwhite>{truncated}</ansiwhite>"
                lines.append(f"  {cursor}{label_fmt}{current_tag}\n")
                time_part = f"  ·  {time_str}" if time_str else ""
                lines.append(f"       <ansibrightblack>{node_id_short}  ·  <{sc}>{status}</{sc}>  ·  {msg_count} msg{'s' if msg_count != 1 else ''}{time_part}</ansibrightblack>\n\n")
        lines.append("  <ansibrightblack>↑/↓ to navigate · Enter to select · Ctrl+C to cancel</ansibrightblack>\n")
        return HTML("".join(lines))

    kb = KeyBindings()

    @kb.add("up")
    def _up(event):
        state["index"] = (state["index"] - 1) % len(choices)

    @kb.add("down")
    def _down(event):
        state["index"] = (state["index"] + 1) % len(choices)

    @kb.add("enter")
    def _enter(event):
        event.app.exit(result=choices[state["index"]])

    @kb.add("c-c")
    @kb.add("escape")
    def _cancel(event):
        event.app.exit(exception=KeyboardInterrupt())

    control = FormattedTextControl(text=lambda: to_formatted_text(_render()), focusable=True)
    layout = Layout(Window(content=control))
    app: Application = Application(layout=layout, key_bindings=kb, full_screen=False, mouse_support=False)
    try:
        result = await app.run_async()
    except KeyboardInterrupt:
        return None
    if result is LOAD_MORE:
        return "load_more"
    return result


async def pick_message(context: list[dict[str, Any]]) -> int | None:
    """
    Arrow-key picker over a node's messages, shown in reverse order (latest first).
    User messages are shown for context but are not selectable — cursor only lands on
    assistant messages. Returns the original (forward) index of the selected message,
    or None if cancelled.
    """
    if not context:
        return None

    reversed_ctx = list(reversed(context))
    # Indices into reversed_ctx that the cursor can land on (assistant only)
    selectable = [i for i, m in enumerate(reversed_ctx) if m.get("role") == "assistant"]
    if not selectable:
        return None

    state = {"sel": 0}  # index into selectable[]

    def _render() -> HTML:
        active_display_idx = selectable[state["sel"]]
        lines = ["<ansibrightblack>  Branch after which response? (latest first):\n\n</ansibrightblack>"]
        for i, msg in enumerate(reversed_ctx):
            role = msg.get("role", "user")
            content = (msg.get("content") or "").replace("\n", " ").strip()
            is_active = i == active_display_idx
            if role == "assistant":
                cursor = "<ansiwhite>▶ </ansiwhite>" if is_active else "  "
                role_fmt = "<ansigreen>[assistant]</ansigreen>"
                text_fmt = f"<ansiwhite><b>{content[:64]}{'…' if len(content) > 64 else ''}</b></ansiwhite>" if is_active else f"<ansiwhite>{content[:64]}{'…' if len(content) > 64 else ''}</ansiwhite>"
                lines.append(f"  {cursor}{role_fmt}  {text_fmt}\n\n")
            else:
                # User message — display only, dimmed, no cursor
                lines.append(f"     <ansibrightblack>[user]  {content[:64]}{'…' if len(content) > 64 else ''}</ansibrightblack>\n\n")
        lines.append("  <ansibrightblack>↑/↓ to navigate · Enter to branch here · Ctrl+C to cancel</ansibrightblack>\n")
        return HTML("".join(lines))

    kb = KeyBindings()

    @kb.add("up")
    def _up(event):
        state["sel"] = (state["sel"] - 1) % len(selectable)

    @kb.add("down")
    def _down(event):
        state["sel"] = (state["sel"] + 1) % len(selectable)

    @kb.add("enter")
    def _enter(event):
        event.app.exit(result=selectable[state["sel"]])

    @kb.add("c-c")
    @kb.add("escape")
    def _cancel(event):
        event.app.exit(exception=KeyboardInterrupt())

    control = FormattedTextControl(text=lambda: to_formatted_text(_render()), focusable=True)
    layout = Layout(Window(content=control))
    app: Application = Application(layout=layout, key_bindings=kb, full_screen=False, mouse_support=False)
    try:
        display_index = await app.run_async()
    except KeyboardInterrupt:
        return None
    # Convert from reversed display index back to original forward index
    return len(context) - 1 - display_index


def _relative_time(dt_str: str) -> str:
    """Convert an ISO datetime string to a human-readable relative time."""
    try:
        dt = datetime.datetime.fromisoformat(dt_str.replace("Z", "+00:00"))
        dt = dt.replace(tzinfo=None) if dt.tzinfo else dt
        now = datetime.datetime.utcnow()
        delta = now - dt.replace(tzinfo=None)
        days = delta.days
        if days == 0:
            hours = delta.seconds // 3600
            if hours == 0:
                mins = delta.seconds // 60
                return f"{mins}m ago" if mins > 0 else "just now"
            return f"{hours}h ago"
        if days == 1:
            return "yesterday"
        if days < 7:
            return f"{days}d ago"
        if days < 30:
            return f"{days // 7}w ago"
        return f"{days // 30}mo ago"
    except Exception:
        return ""


async def pick_session(graphs: list[dict[str, Any]]) -> dict[str, Any] | None:
    """
    Show an interactive arrow-key picker.

    Returns the selected graph dict to resume, or None to start a new session.
    Raises KeyboardInterrupt if the user presses Ctrl+C or Escape.
    """
    # Choices: existing graphs + sentinel for "new"
    NEW_SESSION = object()
    choices: list[Any] = list(graphs) + [NEW_SESSION]
    state = {"index": 0, "result": NEW_SESSION, "done": False}

    def _render() -> HTML:
        count = len(graphs)
        session_word = "session" if count == 1 else "sessions"
        lines = [f"<ansibrightblack>  Found {count} existing {session_word} in this directory:\n\n</ansibrightblack>"]
        for i, choice in enumerate(choices):
            cursor = "<ansiwhite>▶ </ansiwhite>" if i == state["index"] else "  "
            selected = i == state["index"]
            if choice is NEW_SESSION:
                if i > 0:
                    lines.append("  <ansibrightblack>─────────────────────────────────────────────</ansibrightblack>\n")
                label = "<ansigreen>+ Start new session</ansigreen>"
                lines.append(f"  {cursor}{label}\n")
            else:
                name = choice.get("name", "Untitled")
                updated = _relative_time(choice.get("updated_at", ""))
                active_node = choice.get("active_node")
                name_fmt = f"<ansiwhite><b>{name}</b></ansiwhite>" if selected else f"<ansiwhite>{name}</ansiwhite>"
                time_fmt = f"<ansibrightblack>{updated}</ansibrightblack>" if updated else ""
                # Line 1: graph name + last active time
                lines.append(f"  {cursor}{name_fmt}    {time_fmt}\n")
                # Line 2: which node will be resumed
                if active_node and active_node.get("label"):
                    node_lbl = active_node["label"]
                    truncated = node_lbl[:60] + ("…" if len(node_lbl) > 60 else "")
                    node_id_short = active_node["id"][:8]
                    lines.append(f"       <ansibrightblack>↳ resume node {node_id_short}  ·  \"{truncated}\"</ansibrightblack>\n")
                elif active_node:
                    node_id_short = active_node["id"][:8]
                    lines.append(f"       <ansibrightblack>↳ resume node {node_id_short}  ·  (untitled)</ansibrightblack>\n")
                else:
                    lines.append(f"       <ansibrightblack>↳ no active node — will start a new node</ansibrightblack>\n")
                lines.append("\n")
        lines.append("  <ansibrightblack>↑/↓ to navigate · Enter to select · Ctrl+C to cancel</ansibrightblack>\n")
        return HTML("".join(lines))

    kb = KeyBindings()

    @kb.add("up")
    def _up(event):
        state["index"] = (state["index"] - 1) % len(choices)

    @kb.add("down")
    def _down(event):
        state["index"] = (state["index"] + 1) % len(choices)

    @kb.add("enter")
    def _enter(event):
        state["result"] = choices[state["index"]]
        state["done"] = True
        event.app.exit()

    @kb.add("c-c")
    @kb.add("escape")
    def _cancel(event):
        state["done"] = True
        event.app.exit(exception=KeyboardInterrupt())

    control = FormattedTextControl(text=lambda: to_formatted_text(_render()), focusable=True)
    layout = Layout(Window(content=control))

    app: Application = Application(layout=layout, key_bindings=kb, full_screen=False, mouse_support=False)
    await app.run_async()

    chosen = state["result"]
    if chosen is NEW_SESSION:
        return None
    return chosen
