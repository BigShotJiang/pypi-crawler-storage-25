import click
from topo.auth import is_authenticated, login_command
from topo.constants import APP_NAME, APP_DISPLAY_NAME
from topo.session import start_session


def _print_update_notice() -> None:
    import threading
    from rich.console import Console

    result = {}

    def _check():
        from topo.update_check import check_for_update
        result['latest'] = check_for_update()

    t = threading.Thread(target=_check, daemon=True)
    t.start()
    t.join(timeout=2)
    latest = result.get('latest')
    if latest:
        Console().print(f"\n  [bold yellow]⚡ New version available:[/bold yellow] [bold]{latest}[/bold]  →  pip install --upgrade expluro\n")


@click.group(invoke_without_command=True)
@click.option('--no-browser', is_flag=True, default=False, help='Do not open the graph in the browser.')
@click.pass_context
def cli(ctx: click.Context, no_browser: bool) -> None:
    f"""{APP_DISPLAY_NAME} — graph layer on top of your AI agent.

    Run `{APP_NAME}` to start an interactive session.
    Run `{APP_NAME} login` to authenticate first.
    """
    if ctx.invoked_subcommand is None:
        _print_update_notice()
        if not is_authenticated():
            click.echo(f"Not logged in. Run `{APP_NAME} login` first.")
            raise SystemExit(1)
        start_session(no_browser=no_browser)


@cli.command()
def login() -> None:
    """Authenticate with Expluro."""
    _print_update_notice()
    login_command()
