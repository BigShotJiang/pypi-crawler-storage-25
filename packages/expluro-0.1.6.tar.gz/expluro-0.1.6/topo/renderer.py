"""
Terminal renderer for topo CLI sessions.

Replaces the flat _render_event function in session.py with a stateful
TerminalRenderer class that mirrors claw-code's visual design:

  - Turn-level spinner  ("Thinking…" → "Done" / "Failed")
  - MarkdownStreamState  accumulates text chunks, renders at safe paragraph
                         / code-block boundaries so the user sees formatted
                         markdown live rather than raw text
  - Tool call lines      ✓ / ✗ printed after each tool completes
  - Thinking blocks      dim italic, capped at 200 chars
  - Turn summary         cost + turns on a dim Rule at the end of each turn

Usage:
    renderer = TerminalRenderer()
    renderer.start_turn()
    async for event in driver.receive():
        renderer.render(event)
    # spinner auto-finishes on result / error events
"""
from __future__ import annotations

import sys
import threading
import time
from typing import TYPE_CHECKING

from rich.console import Console
from rich.markup import escape
from rich.rule import Rule

if TYPE_CHECKING:
    from .drivers.base import DriverEvent

console = Console(highlight=False)


# ---------------------------------------------------------------------------
# Spinner — runs on a background thread so it doesn't block the async loop
# ---------------------------------------------------------------------------

_SPINNER_FRAMES = ["⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"]


class _Spinner:
    """
    Background-thread spinner that renders in-place using ANSI cursor control.
    Mirrors claw-code's Spinner: tick (update frame), finish (✓), fail (✗).
    Label can be updated live via set_label() so tool names show in real time.
    """

    def __init__(self, label: str) -> None:
        self._label = label
        self._lock = threading.Lock()
        self._stop = threading.Event()
        self._paused = threading.Event()  # set = paused
        self._thread = threading.Thread(target=self._run, daemon=True)

    def set_label(self, label: str) -> None:
        with self._lock:
            self._label = label

    def pause(self) -> None:
        """Stop spinner output temporarily (e.g. while showing a permission prompt)."""
        self._paused.set()
        time.sleep(0.09)  # let the thread finish its current write
        sys.stdout.write("\r\033[K")
        sys.stdout.flush()

    def resume(self) -> None:
        """Resume spinner output after a pause."""
        self._paused.clear()

    def start(self) -> None:
        self._thread.start()

    def _run(self) -> None:
        frame_idx = 0
        while not self._stop.is_set():
            if not self._paused.is_set():
                with self._lock:
                    label = self._label
                frame = _SPINNER_FRAMES[frame_idx % len(_SPINNER_FRAMES)]
                sys.stdout.write(f"\r\033[36m{frame}\033[0m \033[2m{label}\033[0m\033[K")
                sys.stdout.flush()
                frame_idx += 1
            time.sleep(0.08)

    def finish(self, label: str = "Done") -> None:
        self._stop.set()
        self._thread.join()
        sys.stdout.write(f"\r\033[32m✓\033[0m \033[2m{label}\033[0m\033[K\n")
        sys.stdout.flush()

    def fail(self, label: str = "Failed") -> None:
        self._stop.set()
        self._thread.join()
        sys.stdout.write(f"\r\033[31m✗\033[0m \033[2m{label}\033[0m\033[K\n")
        sys.stdout.flush()


# ---------------------------------------------------------------------------
# MarkdownStreamState — accumulates chunks, renders at safe boundaries
# ---------------------------------------------------------------------------

# Characters that signal a safe render boundary within a streaming response.
# We flush everything up to the last occurrence of these when a chunk arrives.
_SAFE_BOUNDARIES = ("\n\n", "\n```", "\n#", "\n-", "\n*", "\n>")


class _MarkdownStreamState:
    """
    Accumulates streaming text chunks and renders complete markdown blocks
    progressively — so the user sees formatted output as it arrives rather
    than waiting for the full response.

    Mirrors claw-code's MarkdownStreamState.push() / flush() pattern.
    """

    def __init__(self) -> None:
        self._pending = ""

    def push(self, delta: str) -> None:
        """Accept a new chunk and render any complete blocks."""
        self._pending += delta
        split = self._find_boundary()
        if split is None:
            return
        ready = self._pending[:split]
        self._pending = self._pending[split:]
        self._render(ready)

    def flush(self) -> None:
        """Render whatever is left at the end of the turn."""
        if self._pending.strip():
            self._render(self._pending)
        self._pending = ""

    def reset(self) -> None:
        self._pending = ""

    def _find_boundary(self) -> int | None:
        best = -1
        for marker in _SAFE_BOUNDARIES:
            idx = self._pending.rfind(marker)
            if idx > best:
                best = idx + len(marker)
        return best if best > 0 else None

    def _render(self, text: str) -> None:
        if not text.strip():
            return
        sys.stdout.write(text)
        sys.stdout.flush()


# ---------------------------------------------------------------------------
# Module-level spinner control — lets the driver pause the spinner before
# showing a permission prompt so the two don't race on stdout.
# ---------------------------------------------------------------------------

_active_spinner: _Spinner | None = None


def pause_active_spinner() -> None:
    if _active_spinner is not None:
        _active_spinner.pause()


def resume_active_spinner() -> None:
    if _active_spinner is not None:
        _active_spinner.resume()


# ---------------------------------------------------------------------------
# TerminalRenderer — main public class
# ---------------------------------------------------------------------------

class TerminalRenderer:
    """
    Stateful renderer for a topo CLI session.

    Call start_turn() before each prompt is sent, then render(event) for every
    DriverEvent.  The spinner, markdown state, and tool tracking are all reset
    automatically between turns.
    """

    def __init__(self) -> None:
        self._spinner: _Spinner | None = None
        self._md = _MarkdownStreamState()
        self._spinner_active = False

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def start_turn(self) -> None:
        """Start the turn-level spinner. Call once before driver.receive()."""
        global _active_spinner
        self._md.reset()
        self._spinner = _Spinner("Thinking…")
        _active_spinner = self._spinner
        self._spinner.start()
        self._spinner_active = True

    def render(self, event: "DriverEvent") -> None:
        """Dispatch a single DriverEvent to the appropriate renderer."""
        t = event.type

        if t == "text":
            self._on_text(event)
        elif t == "text_complete":
            self._on_text_complete(event)
        elif t == "thinking":
            self._on_thinking(event)
        elif t == "tool_use":
            self._on_tool_use(event)
        elif t == "tool_result":
            self._on_tool_result(event)
        elif t == "result":
            self._on_result(event)
        elif t == "rate_limit":
            self._on_rate_limit(event)
        elif t == "error":
            self._on_error(event)

    def stop_spinner_if_active(self) -> None:
        """Interrupt the spinner cleanly (e.g. on KeyboardInterrupt)."""
        if self._spinner and self._spinner_active:
            self._spinner.fail("Interrupted")
            self._spinner_active = False

    # ------------------------------------------------------------------
    # Event handlers
    # ------------------------------------------------------------------

    def _stop_spinner(self, success: bool = True, label: str = "") -> None:
        global _active_spinner
        if self._spinner and self._spinner_active:
            if success:
                self._spinner.finish(label or "Done")
            else:
                self._spinner.fail(label or "Failed")
            self._spinner_active = False
            self._spinner = None
            _active_spinner = None

    def _on_text(self, event: "DriverEvent") -> None:
        text = event.data.get("text", "")
        if not text:
            return
        # First text chunk — stop the spinner so output can flow
        if self._spinner_active:
            self._stop_spinner(success=True, label="")
            # Print a blank line to separate spinner line from content
            sys.stdout.write("\n")
            sys.stdout.flush()
        self._md.push(text)

    def _on_text_complete(self, event: "DriverEvent") -> None:
        # Flush any remaining buffered markdown from the streaming state
        self._md.flush()

    def _on_thinking(self, event: "DriverEvent") -> None:
        thinking = event.data.get("thinking", "")
        if not thinking:
            return
        # Pause spinner while printing, then resume — thinking doesn't end the turn
        if self._spinner and self._spinner_active:
            self._spinner.pause()
        snippet = thinking[:200]
        ellipsis = "…" if len(thinking) > 200 else ""
        console.print(f"[dim italic]💭 {escape(snippet)}{ellipsis}[/dim italic]")
        if self._spinner and self._spinner_active:
            self._spinner.resume()

    def _on_tool_use(self, event: "DriverEvent") -> None:
        name = event.data.get("tool_name", "")
        inp = event.data.get("tool_input", {})
        summary = _tool_summary(name, inp)
        label = f"{name}: {summary}…" if summary else f"{name}…"
        if self._spinner and self._spinner_active:
            self._spinner.set_label(label)
        elif not self._spinner_active:
            # Spinner already stopped (post-text tool call) — print a static line
            summary_str = f"  [dim]{escape(summary)}[/dim]" if summary else ""
            console.print(f"[cyan]⚙ {escape(name)}[/cyan]{summary_str}")

    def _on_tool_result(self, event: "DriverEvent") -> None:
        # Revert spinner label back to "Thinking…" while Claude processes the result
        if self._spinner and self._spinner_active:
            self._spinner.set_label("Thinking…")

    def _on_result(self, event: "DriverEvent") -> None:
        # Flush any remaining buffered markdown
        self._md.flush()
        # Spinner may still be active if the turn had no text output
        self._stop_spinner(success=True, label="Done")

        cost = event.data.get("cost_usd")
        turns = event.data.get("num_turns")
        is_error = event.data.get("is_error", False)

        parts = []
        if turns is not None:
            parts.append(f"{turns} turn{'s' if turns != 1 else ''}")
        if cost is not None:
            parts.append(f"${cost:.4f}")

        summary = "  ·  ".join(parts)
        if is_error:
            console.print(f"\n[dim red]{summary}[/dim red]" if summary else "")
        else:
            console.print(f"\n[dim]{summary}[/dim]" if summary else "")

    def _on_rate_limit(self, event: "DriverEvent") -> None:
        status = event.data.get("status", "")
        if status == "rejected":
            console.print("\n[red]Rate limit reached — waiting for reset…[/red]")
        else:
            console.print("\n[yellow]Approaching rate limit — responses may slow down.[/yellow]")

    def _on_error(self, event: "DriverEvent") -> None:
        self._md.flush()
        self._stop_spinner(success=False, label="Failed")
        msg = event.data.get("message", "Unknown error")
        console.print(f"\n[red]{escape(msg)}[/red]")


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _tool_summary(tool_name: str, inp: dict) -> str:
    """One-line summary of a tool call for display."""
    if tool_name in ("Read", "Edit", "Write", "MultiEdit"):
        return inp.get("file_path", inp.get("path", ""))
    if tool_name == "Bash":
        cmd = inp.get("command", "")
        return cmd[:80] + ("…" if len(cmd) > 80 else "")
    if tool_name in ("Glob", "Grep"):
        return inp.get("pattern", "")
    if tool_name == "WebSearch":
        return inp.get("query", "")
    if tool_name == "WebFetch":
        return inp.get("url", "")
    for v in inp.values():
        if isinstance(v, str):
            return v[:80]
    return ""
