"""
Claude driver — wraps the Claude Agent SDK (ClaudeSDKClient) to implement
the BaseDriver interface.

Permission model
----------------
permission_mode="bypassPermissions" prevents Claude Code from running tools
in a sandboxed environment (which blocks real filesystem/shell access in SDK
mode). The PreToolUse hook handles all permission decisions interactively:
returning continue_=False/decision="block" hard-stops the tool regardless of
bypass mode, and the reason field tells Claude the user denied it.

The user sees before each tool call:
    ⚙ Bash  git status
      Allow? [y]es / [n]o / [a]lways for Bash / [!] bypass all  _

[a] approvals carry forward parent → child on branch switch.
[!] bypass-all resets on each branch switch.
"""
from __future__ import annotations

import asyncio
import logging
from collections.abc import AsyncIterator
from typing import Any

from claude_agent_sdk.client import ClaudeSDKClient
from claude_agent_sdk.types import (
    AssistantMessage,
    ClaudeAgentOptions,
    HookContext,
    HookMatcher,
    RateLimitEvent,
    ResultMessage,
    StreamEvent,
    TextBlock,
    ThinkingBlock,
    ToolResultBlock,
    ToolUseBlock,
)

from .base import BaseDriver, DriverEvent, ToolHookPayload

logger = logging.getLogger(__name__)


class ClaudeDriver(BaseDriver):
    """Driver for Claude via the Claude Agent SDK."""

    name = "claude"

    def __init__(self) -> None:
        super().__init__()
        self._client: ClaudeSDKClient | None = None
        self._cwd: str | None = None
        # Set before connect() — mutually exclusive: prefer resume over injection
        self._resume_session_id: str | None = None      # --resume <id>
        self._injected_context: list[dict] = []          # fallback: --append-system-prompt
        # Permission tracking — populated at runtime
        self._always_allowed_tools: set[str] = set()     # tools the user said [a]lways
        self._bypass_all: bool = False                   # user said [!] bypass all

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    async def connect(self, cwd: str) -> None:
        self._cwd = cwd

        # Consume _resume_session_id — pass it as resume= to pick up the right session file.
        resume_id = self._resume_session_id
        self._resume_session_id = None

        # Fallback: if no resume ID, inject prior context via --append-system-prompt.
        system_prompt: dict | None = None
        if not resume_id and self._injected_context:
            n = len(self._injected_context)
            context_text = _format_context(self._injected_context)
            system_prompt = {"type": "preset", "append": context_text}
            self._injected_context = []
            logger.debug("ClaudeDriver: injecting %d messages via system prompt (fallback)", n)

        options = ClaudeAgentOptions(
            # bypassPermissions stops Claude Code from trying to render its own
            # permission UI (which is broken in SDK/non-TTY mode and causes
            # sandbox-restriction errors).  The PreToolUse hook handles all
            # permission decisions interactively via permissionDecision return value.
            permission_mode="bypassPermissions",
            cwd=cwd,
            hooks=self._build_hooks(),
            include_partial_messages=True,
            **({"resume": resume_id} if resume_id else {}),
            **({"system_prompt": system_prompt} if system_prompt else {}),
        )
        self._client = ClaudeSDKClient(options=options)
        await self._client.__aenter__()
        logger.debug("ClaudeDriver connected (cwd=%s, resume=%s)", cwd, resume_id)

    async def disconnect(self) -> None:
        if self._client:
            await self._client.__aexit__(None, None, None)
            self._client = None
            logger.debug("ClaudeDriver disconnected")

    # ------------------------------------------------------------------
    # Communication
    # ------------------------------------------------------------------

    async def send(self, prompt: str) -> None:
        if not self._client:
            raise RuntimeError("Driver not connected. Call connect() first.")
        await self._client.query(prompt)

    async def receive(self) -> AsyncIterator[DriverEvent]:  # type: ignore[override]
        if not self._client:
            raise RuntimeError("Driver not connected.")
        async for msg in self._client.receive_response():
            for event in _normalize(msg):
                yield event

    # ------------------------------------------------------------------
    # Context reset — called by session.py on branch switch
    # ------------------------------------------------------------------

    async def reset_context(
        self,
        messages: list[dict],
        *,
        cc_session_id: str | None = None,
        cc_session_initialized: bool = False,
        inherited_context_length: int = 0,
        cwd: str | None = None,
    ) -> str | None:
        """
        Disconnect the current subprocess and reconnect at the branch point.

        Strategy (in priority order):
          1. If cc_session_initialized — the node already has its own session file;
             just --resume it directly.
          2. If not initialized and inherited_context_length == 0 — root node;
             --resume the session file as-is (no truncation needed).
          3. If not initialized and inherited_context_length > 0 — fresh branch;
             copy+truncate the parent's session file, --resume the new file.
          4. Fallback (no session ID, or copy_and_truncate fails) — inject context
             via --append-system-prompt (lossy but better than nothing).

        Returns the new cc_session_id if a new session file was created, else None.
        """
        effective_cwd = cwd or self._cwd
        logger.info(
            "ClaudeDriver: resetting context (cc_session_id=%s, initialized=%s, length=%d)",
            cc_session_id, cc_session_initialized, inherited_context_length,
        )
        await self.disconnect()
        # On branch switch: tool-level approvals ("always allow Bash") carry forward
        # from parent → child since the user already made that trust decision for
        # this project. "Bypass all" does NOT carry forward — it's too broad to
        # silently inherit on a new branch.
        self._bypass_all = False

        new_session_id: str | None = None

        if cc_session_id and effective_cwd:
            if cc_session_initialized or inherited_context_length == 0:
                # Either already has its own file, or root node — resume directly.
                self._resume_session_id = cc_session_id
            else:
                # Fresh branch — copy+truncate the parent's session file.
                from ..session_files import fork_at_message_count
                new_session_id = fork_at_message_count(
                    cc_session_id, effective_cwd, inherited_context_length
                )
                if new_session_id:
                    self._resume_session_id = new_session_id
                    logger.info("ClaudeDriver: created branch session file → %s", new_session_id)
                else:
                    # copy_and_truncate failed (e.g. session file missing) — fall back.
                    logger.warning(
                        "ClaudeDriver: copy_and_truncate failed for %s, falling back to context injection",
                        cc_session_id,
                    )
                    self._injected_context = messages
        else:
            # No session ID available — inject via system prompt.
            self._injected_context = messages

        if effective_cwd:
            await self.connect(cwd=effective_cwd)

        return new_session_id

    # ------------------------------------------------------------------
    # Internal — permission prompt
    # ------------------------------------------------------------------

    async def _ask_permission(self, tool_name: str, tool_input: dict[str, Any]) -> bool:
        """
        Show an interactive arrow-key permission prompt.
        Returns True (allow) or False (deny).
        Fires from the PreToolUse hook so it works regardless of permission_mode.
        """
        if self._bypass_all or tool_name in self._always_allowed_tools:
            return True

        from ..picker import pick_option
        from ..renderer import pause_active_spinner, resume_active_spinner

        summary = _tool_input_summary(tool_name, tool_input)
        summary_line = f"\n  <ansibrightblack>  {summary}</ansibrightblack>" if summary else ""
        header = f"  <ansicyan>⚙ {tool_name}</ansicyan>  <ansibrightblack>wants to run:</ansibrightblack>{summary_line}"

        options: list[tuple[str, str]] = [
            ("Allow", "allow"),
            (f"Always allow {tool_name}", "always"),
            ("Deny", "deny"),
            ("Bypass all checks", "bypass"),
        ]

        pause_active_spinner()
        try:
            result = await pick_option(header, options)
        except KeyboardInterrupt:
            resume_active_spinner()
            logger.info("Permission: cancelled for %s", tool_name)
            return False
        resume_active_spinner()

        if result == "always":
            self._always_allowed_tools.add(tool_name)
            logger.info("Permission: always allow %s", tool_name)
            return True
        if result == "bypass":
            self._bypass_all = True
            logger.info("Permission: bypass all remaining checks")
            return True
        if result == "allow":
            return True

        logger.info("Permission: user denied %s", tool_name)
        return False

    # ------------------------------------------------------------------
    # Internal — hook wiring
    # ------------------------------------------------------------------

    def _build_hooks(self) -> dict:
        async def pre_tool_hook(
            hook_input: Any,  # SDK passes a raw dict, not a typed object
            session_id: str | None,
            ctx: HookContext,
        ) -> dict:
            try:
                # Normalise: SDK may pass a TypedDict or a plain dict
                if isinstance(hook_input, dict):
                    tool_name = hook_input.get("tool_name", "")
                    tool_input = hook_input.get("tool_input") or {}
                    tool_use_id = hook_input.get("tool_use_id", "")
                else:
                    tool_name = getattr(hook_input, "tool_name", "")
                    tool_input = getattr(hook_input, "tool_input", None) or {}
                    tool_use_id = getattr(hook_input, "tool_use_id", "")

                # Fire event-capture callbacks first (non-blocking)
                payload = ToolHookPayload(
                    tool_name=tool_name,
                    tool_input=tool_input,
                    tool_use_id=tool_use_id,
                    session_id=session_id,
                )
                for cb in self._pre_tool_hooks:
                    await cb(payload)

                # Permission prompt — use continue_=False/decision="block" to hard-stop
                # the tool. permissionDecision alone is ignored when bypassPermissions
                # is active; the hook control fields are respected independently.
                allowed = await self._ask_permission(tool_name, tool_input)
                if not allowed:
                    return {
                        "continue_": False,
                        "decision": "block",
                        "stopReason": f"Permission denied for {tool_name}.",
                        "reason": f"The user explicitly denied permission to run {tool_name}. Acknowledge this and ask if they would like to proceed differently.",
                    }
                return {"continue_": True}
            except Exception:
                logger.exception("pre_tool_hook error — allowing tool by default")
                return {"continue_": True}

        async def post_tool_hook(
            hook_input: Any,  # SDK passes a raw dict
            session_id: str | None,
            ctx: HookContext,
        ) -> dict:
            try:
                if isinstance(hook_input, dict):
                    tool_name = hook_input.get("tool_name", "")
                    tool_input = hook_input.get("tool_input") or {}
                    tool_use_id = hook_input.get("tool_use_id", "")
                    tool_output = hook_input.get("tool_response")
                else:
                    tool_name = getattr(hook_input, "tool_name", "")
                    tool_input = getattr(hook_input, "tool_input", None) or {}
                    tool_use_id = getattr(hook_input, "tool_use_id", "")
                    tool_output = getattr(hook_input, "tool_response", None)

                payload = ToolHookPayload(
                    tool_name=tool_name,
                    tool_input=tool_input,
                    tool_use_id=tool_use_id,
                    session_id=session_id,
                    tool_output=tool_output,
                    is_error=False,
                )
                for cb in self._post_tool_hooks:
                    await cb(payload)
            except Exception:
                logger.exception("post_tool_hook error")
            return {}

        return {
            "PreToolUse": [HookMatcher(matcher=None, hooks=[pre_tool_hook])],
            "PostToolUse": [HookMatcher(matcher=None, hooks=[post_tool_hook])],
        }


def _normalize(msg: Any) -> list[DriverEvent]:
    """Translate a raw SDK message into one or more normalized DriverEvents."""
    events: list[DriverEvent] = []

    if isinstance(msg, StreamEvent):
        # Partial streaming chunk — emit text deltas as they arrive so the
        # terminal and browser both see token-by-token output.
        delta = msg.event.get("delta", {})
        if msg.event.get("type") == "content_block_delta" and delta.get("type") == "text_delta":
            text = delta.get("text", "")
            if text:
                events.append(DriverEvent(
                    type="text",
                    data={"text": text, "session_id": msg.session_id},
                    raw=msg,
                ))
        return events

    if isinstance(msg, AssistantMessage):
        for block in msg.content:
            if isinstance(block, TextBlock):
                # Use the SDK-assembled full text for persistence.
                # Streaming display already happened via StreamEvent chunks.
                events.append(DriverEvent(
                    type="text_complete",
                    data={"text": block.text, "session_id": msg.session_id},
                    raw=msg,
                ))
            elif isinstance(block, ThinkingBlock):
                events.append(DriverEvent(
                    type="thinking",
                    data={"thinking": block.thinking, "session_id": msg.session_id},
                    raw=msg,
                ))
            elif isinstance(block, ToolUseBlock):
                events.append(DriverEvent(
                    type="tool_use",
                    data={
                        "tool_name": block.name,
                        "tool_input": block.input,
                        "tool_use_id": block.id,
                        "session_id": msg.session_id,
                    },
                    raw=msg,
                ))
            elif isinstance(block, ToolResultBlock):
                events.append(DriverEvent(
                    type="tool_result",
                    data={
                        "tool_use_id": block.tool_use_id,
                        "content": block.content,
                        "session_id": msg.session_id,
                    },
                    raw=msg,
                ))

    elif isinstance(msg, ResultMessage):
        events.append(DriverEvent(
            type="result",
            data={
                "cost_usd": msg.total_cost_usd,
                "num_turns": msg.num_turns,
                "stop_reason": msg.stop_reason,
                "is_error": msg.is_error,
                "session_id": msg.session_id,
            },
            raw=msg,
        ))

    elif isinstance(msg, RateLimitEvent):
        # "allowed" is an informational status ping — only surface warnings/rejections
        if msg.rate_limit_info.status != "allowed":
            events.append(DriverEvent(
                type="rate_limit",
                data={"status": msg.rate_limit_info.status, "info": msg.rate_limit_info.raw},
                raw=msg,
            ))

    return events


def _tool_input_summary(tool_name: str, inp: dict) -> str:
    """One-line summary of a tool call shown in the permission prompt."""
    if tool_name in ("Read", "Edit", "Write", "MultiEdit"):
        return inp.get("file_path", inp.get("path", ""))
    if tool_name == "Bash":
        cmd = inp.get("command", "")
        return cmd[:80] + ("…" if len(cmd) > 80 else "")
    if tool_name in ("Glob", "Grep"):
        return inp.get("pattern", "")
    if tool_name == "WebSearch":
        return inp.get("query", "")
    if tool_name == "WebFetch":
        return inp.get("url", "")
    for v in inp.values():
        if isinstance(v, str):
            return v[:80]
    return ""



def _format_context(messages: list[dict]) -> str:
    """
    Format a materialized_context list into a readable string for --append-system-prompt.
    The fresh subprocess will see this as part of its system prompt and use it as
    prior conversation context when continuing from a branch point.
    """
    if not messages:
        return ""
    lines = [
        "The following is prior conversation history from the branch point you are continuing from.",
        "Treat this as the beginning of your context and continue naturally:",
        "",
    ]
    for msg in messages:
        role = msg.get("role", "user")
        content = msg.get("content", "")
        # content can be a string or a list of blocks (Anthropic format)
        if isinstance(content, list):
            content = " ".join(
                block.get("text", "") for block in content
                if isinstance(block, dict) and block.get("type") == "text"
            )
        label = "User" if role == "user" else "Assistant"
        lines.append(f"[{label}]: {content}")
    return "\n".join(lines)
