"""
Session — the interactive REPL loop.

Wires together:
  - BackendClient   (register graph + node, stream events)
  - EventCapture    (hook into driver, write JSONL, send to backend)
  - ClaudeDriver    (Claude Agent SDK — first concrete driver)
  - TerminalRenderer (turn spinner, streaming markdown, tool lines)

To add a new tool driver: implement BaseDriver, add it to DRIVERS below.
"""
from __future__ import annotations

import asyncio
import datetime
import json
import logging
import os
import sys
import webbrowser
from pathlib import Path

import websockets
from prompt_toolkit import PromptSession
from prompt_toolkit.completion import WordCompleter
from prompt_toolkit.formatted_text import HTML
from prompt_toolkit.patch_stdout import patch_stdout as pt_patch_stdout
from prompt_toolkit.styles import Style
from rich.console import Console
from rich.rule import Rule

from .auth import get_access_token
from .backend import BackendClient, BackendError
from .constants import APP_NAME, PROMPT
from .capture import EventCapture
from .drivers.claude import ClaudeDriver
from .picker import pick_session, pick_node, pick_message
from .renderer import TerminalRenderer

logger = logging.getLogger(__name__)
console = Console()

# Driver registry — add new tool integrations here
DRIVERS = {
    "claude": ClaudeDriver,
}


FRONTEND_URL = os.getenv("TOPO_FRONTEND_URL", "https://expluro.com")
WS_BASE = os.getenv("TOPO_BASE_URL", "https://api.expluro.com").replace("https://", "wss://").replace("http://", "ws://")


def start_session(driver_name: str = "claude", cwd: str | None = None, no_browser: bool = False) -> None:
    """Entry point called by `topo` (no subcommand). Runs the async REPL."""
    asyncio.run(_run(driver_name=driver_name, cwd=cwd or str(Path.cwd()), no_browser=no_browser))


async def _run(driver_name: str, cwd: str, no_browser: bool = False) -> None:
    if driver_name not in DRIVERS:
        console.print(f"[red]Unknown driver '{driver_name}'. Available: {', '.join(DRIVERS)}[/red]")
        return

    backend = BackendClient()
    project_name = Path(cwd).name
    session_name = f"{project_name} · {datetime.datetime.now().strftime('%b %d %H:%M')}"

    # ----------------------------------------------------------------
    # Resolve graph + node — resume existing or start fresh
    # ----------------------------------------------------------------
    try:
        existing = await backend.list_graphs_for_path(cwd)
    except BackendError as exc:
        console.print(f"[red]Could not connect to Expluro backend: {exc.detail}[/red]")
        console.print("[dim]Start the backend or check your connection, then try again.[/dim]")
        await backend.aclose()
        return

    graph_id: str
    node_id: str
    resuming_session_id: str | None = None
    resuming_session_initialized: bool = False
    resuming_context: list = []
    resuming_inherited_len: int = 0

    try:
        if existing:
            chosen = await pick_session(existing)
            if chosen is not None:
                # Resume the chosen graph's active node
                graph_id = chosen["id"]
                active_node = chosen.get("active_node")
                if active_node:
                    node_id = active_node["id"]
                    resuming_session_id = active_node.get("cc_session_id") or None
                    resuming_session_initialized = active_node.get("cc_session_initialized", False)
                    # Fetch full node data (materialized_context not in list response)
                    node_data = await backend.checkout_node(node_id)
                    resuming_context = node_data.get("materialized_context", [])
                    resuming_inherited_len = node_data.get("inherited_context_length", 0)
                else:
                    # Graph exists but has no active node — create one
                    node = await backend.create_node(graph_id=graph_id)
                    node_id = node["id"]
            else:
                # User chose "new session"
                graph = await backend.create_graph(name=session_name, project_path=cwd)
                graph_id = graph["id"]
                node = await backend.create_node(graph_id=graph_id)
                node_id = node["id"]
        else:
            # No existing sessions for this path — create fresh
            graph = await backend.create_graph(name=session_name, project_path=cwd)
            graph_id = graph["id"]
            node = await backend.create_node(graph_id=graph_id)
            node_id = node["id"]
    except BackendError as exc:
        console.print(f"[red]Backend error: {exc.detail}[/red]")
        await backend.aclose()
        return
    except KeyboardInterrupt:
        await backend.aclose()
        return

    # ----------------------------------------------------------------
    # Wire up event capture
    # ----------------------------------------------------------------
    capture = EventCapture(
        backend=backend,
        graph_id=graph_id,
        node_id=node_id,
    )

    # Shared state for branch switching — written by WS listener, read by REPL
    switch_event: asyncio.Event = asyncio.Event()
    pending_switch: dict = {}  # {'node_id': str}
    is_streaming: dict = {'value': False}  # boxed bool so the closure can mutate it
    current_cc_session_id: dict = {'value': None}  # tracks latest session file ID for cleanup
    current_node_status: dict = {'value': 'active'}  # tracks whether current node is branched
    current_node_label: dict = {'value': None}  # tracks current node label for the prompt
    node_label_cache: dict = {}  # node_id -> label, so we can restore labels on switch-back
    node_session_cache: dict = {}  # node_id -> cc_session_id, set when we fork a session file for a branch
    cli_switch_pending: dict = {'node_id': None}  # CLI-initiated switch — WS listener skips this node_id to avoid loop

    # ----------------------------------------------------------------
    # Background WebSocket listener — watches for switch_node from browser
    # ----------------------------------------------------------------
    async def _ws_listener(stop: asyncio.Event) -> None:
        token = get_access_token()
        if not token:
            return
        url = f"{WS_BASE}/ws/graphs/{graph_id}/?token={token}"
        while not stop.is_set():
            try:
                async with websockets.connect(url) as ws:
                    logger.debug("CLI WebSocket connected to %s", url)
                    await ws.send(json.dumps({"type": "cli_connect"}))
                    while not stop.is_set():
                        try:
                            raw = await asyncio.wait_for(ws.recv(), timeout=1.0)
                        except asyncio.TimeoutError:
                            continue
                        try:
                            msg = json.loads(raw)
                        except json.JSONDecodeError:
                            continue
                        if msg.get("type") == "switch_node":
                            new_node_id = msg["node_id"]
                            # Skip events the CLI itself triggered to avoid double-processing
                            if cli_switch_pending['node_id'] == new_node_id:
                                cli_switch_pending['node_id'] = None
                                continue
                            is_abandoned = msg.get("abandoned", False)
                            # Delete the abandoned node's session file only if we actually
                            # forked one for it. If the branch was abandoned before the user
                            # typed anything, _handle_pending_switch never ran and no file
                            # was created — nothing to delete.
                            if is_abandoned and cwd:
                                abandoned_session = node_session_cache.pop(capture.node_id, None)
                                if abandoned_session:
                                    from .session_files import delete_session_file
                                    delete_session_file(abandoned_session, cwd)
                            pending_switch["node_id"] = new_node_id
                            pending_switch["notified"] = False
                            switch_event.set()
                            # Update toolbar immediately — restore cached label if we've been here before
                            current_node_label['value'] = node_label_cache.get(new_node_id)
                            current_node_status['value'] = 'active'
                            capture.switch_node(new_node_id)
                            # Print immediately unless mid-stream (would mangle output)
                            if not is_streaming['value']:
                                if is_abandoned:
                                    console.print(f"\n[dim]Branch discarded — back to node {new_node_id[:8]}[/dim]")
                                else:
                                    console.print(f"\n[bold yellow]⎇  Branch detected — switching to node {new_node_id[:8]}[/bold yellow]")
                                    console.print("[dim]Context reset to branch point. Continue your prompt.[/dim]\n")
                                pending_switch["notified"] = True
            except Exception as exc:
                if not stop.is_set():
                    logger.debug("CLI WebSocket disconnected (%s), reconnecting…", exc)
                    await asyncio.sleep(2)

    ws_stop = asyncio.Event()
    ws_task = asyncio.create_task(_ws_listener(ws_stop))

    # ----------------------------------------------------------------
    # Start driver
    # ----------------------------------------------------------------
    DriverClass = DRIVERS[driver_name]
    driver = DriverClass()
    capture.register(driver)  # hooks registered before connect

    resuming = bool(resuming_session_id or resuming_context)
    graph_name_set = resuming  # don't auto-rename if resuming an existing session
    console.print(Rule(f"[bold]{APP_NAME}[/bold] · {project_name} · {driver_name}"))
    console.print(f"[dim]Graph {graph_id[:8]}  Node {node_id[:8]}[/dim]")
    if resuming:
        console.print("[dim]Resuming previous session…[/dim]")

    if not no_browser:
        url = f"{FRONTEND_URL}/graphs/{graph_id}"
        console.print(f"[dim]Opening graph → {url}[/dim]")
        webbrowser.open(url)

    console.print("[dim]Type your prompt. /branch to branch, /checkout to navigate. Ctrl+C to end.[/dim]\n")

    # Build a prompt_toolkit session once — it owns the input line for the whole session.
    # patch_stdout=True tells prompt_toolkit to redraw the prompt after any write() call,
    # so WS notifications printed by the background task don't mangle the input line.
    _toolbar_style = Style.from_dict({'bottom-toolbar': 'bg:default fg:ansibrightblack noreverse'})

    def _toolbar() -> HTML:
        label = current_node_label['value']
        status = current_node_status['value']
        node_short = capture.node_id[:8] if capture.node_id else '--------'
        label_part = f" · {label[:40]}{'…' if label and len(label) > 40 else ''}" if label else ""
        status_badge = " [branched]" if status == 'branched' else ""
        border = '─' * 200  # prompt_toolkit clips to terminal width
        return HTML(
            f"<ansiwhite>{border}</ansiwhite>\n node {node_short}{label_part}{status_badge} \n"
        )

    _completer = WordCompleter(['/branch', '/checkout'], sentence=True)
    pt_session: PromptSession[str] = PromptSession(bottom_toolbar=_toolbar, style=_toolbar_style, completer=_completer)

    try:
        if resuming:
            await driver.reset_context(
                resuming_context,
                cc_session_id=resuming_session_id,
                cc_session_initialized=resuming_session_initialized,
                inherited_context_length=resuming_inherited_len,
                cwd=cwd,
            )
        else:
            await driver.connect(cwd=cwd)

        async def _handle_pending_switch(*, print_notification: bool = False) -> None:
            """
            Handle a pending branch switch if one is queued.
            Called at the top of the REPL loop and again after _read_prompt returns,
            because the browser may have sent switch_node while we were blocking on input.
            """
            if not switch_event.is_set():
                return
            switch_event.clear()
            new_node_id = pending_switch.pop("node_id", None)
            already_notified = pending_switch.pop("notified", False)
            # capture.node_id was already updated in the WS listener — just guard
            # against a stale event where the ID somehow matches current state.
            if not new_node_id:
                return
            if print_notification and not already_notified:
                console.print(f"\n[bold yellow]⎇  Branch detected — switching to node {new_node_id[:8]}[/bold yellow]")
                console.print("[dim]Context reset to branch point. Continue your prompt.[/dim]\n")
            try:
                result = await backend.checkout_node(new_node_id)
                current_node_status['value'] = result.get("status", "active")
                fetched_label = result.get("label") or None
                if fetched_label:
                    current_node_label['value'] = fetched_label
                    node_label_cache[new_node_id] = fetched_label
                new_cc_session_id = await driver.reset_context(
                    result.get("materialized_context", []),
                    cc_session_id=result.get("cc_session_id") or None,
                    cc_session_initialized=result.get("cc_session_initialized", False),
                    inherited_context_length=result.get("inherited_context_length", 0),
                    cwd=cwd,
                )
                # Persist the newly created session file ID so future checkouts
                # can --resume this node's own file instead of the parent's.
                if new_cc_session_id:
                    node_session_cache[new_node_id] = new_cc_session_id
                    try:
                        await backend.patch_node(new_node_id, {
                            "cc_session_id": new_cc_session_id,
                            "cc_session_initialized": True,
                        })
                    except Exception:
                        logger.warning(
                            "Failed to persist new cc_session_id for node %s", new_node_id
                        )
            except Exception:
                logger.warning("Failed to reset driver context for node %s", new_node_id)

        async def _handle_branch() -> None:
            """Branch from a chosen message on the current node (picker, latest-first)."""
            try:
                result = await backend.checkout_node(capture.node_id)
                ctx = result.get("materialized_context", [])
                inherited_len = result.get("inherited_context_length", 0)
                node_messages = ctx[inherited_len:]
                if not any(m.get("role") == "assistant" for m in node_messages):
                    console.print("[yellow]No assistant messages on this node to branch from.[/yellow]")
                    return
                picked = await pick_message(node_messages)
                if picked is None:
                    return
                branch_index = inherited_len + picked
                child = await backend.branch_node(capture.node_id, branch_index)
                child_id = child["id"]
                cli_switch_pending['node_id'] = child_id
                capture.switch_node(child_id)
                child_checkout = await backend.checkout_node(child_id)
                current_node_status['value'] = child_checkout.get("status", "active")
                current_node_label['value'] = child_checkout.get("label") or None
                new_cc_session_id = await driver.reset_context(
                    child_checkout.get("materialized_context", []),
                    cc_session_id=child_checkout.get("cc_session_id") or None,
                    cc_session_initialized=child_checkout.get("cc_session_initialized", False),
                    inherited_context_length=child_checkout.get("inherited_context_length", 0),
                    cwd=cwd,
                )
                if new_cc_session_id:
                    node_session_cache[child_id] = new_cc_session_id
                    try:
                        await backend.patch_node(child_id, {
                            "cc_session_id": new_cc_session_id,
                            "cc_session_initialized": True,
                        })
                    except Exception:
                        logger.warning("Failed to persist cc_session_id for branch node %s", child_id)
                console.print(f"[bold green]⎇  Branched → node {child_id[:8]}[/bold green]")
                console.print("[dim]New branch ready. Continue your prompt.[/dim]\n")
            except BackendError as exc:
                console.print(f"[red]Branch failed: {exc.detail}[/red]")
            except Exception as exc:
                logger.exception("Unexpected error during /branch")
                console.print(f"[red]Branch failed: {exc}[/red]")

        async def _handle_checkout(node_prefix: str | None = None) -> None:
            """Checkout a node by ID prefix, or via interactive picker."""
            try:
                if node_prefix:
                    result = await backend.list_nodes(graph_id, limit=100, offset=0)
                    nodes = result.get("results", [])
                    matches = [n for n in nodes if str(n.get("id", "")).startswith(node_prefix)]
                    if not matches:
                        console.print(f"[yellow]No node matching prefix '{node_prefix}'.[/yellow]")
                        return
                    if len(matches) > 1:
                        console.print(f"[yellow]Ambiguous prefix '{node_prefix}' — {len(matches)} matches. Use more characters.[/yellow]")
                        return
                    target = matches[0]
                else:
                    offset = 0
                    limit = 10
                    collected: list[dict] = []
                    while True:
                        result = await backend.list_nodes(graph_id, limit=limit, offset=offset)
                        batch = result.get("results", [])
                        collected.extend(batch)
                        has_more = result.get("has_more", False)
                        chosen = await pick_node(collected, has_more, current_node_id=capture.node_id)
                        if chosen is None:
                            return
                        if chosen == "load_more":
                            offset += limit
                            continue
                        target = chosen
                        break

                target_id = str(target.get("id", ""))
                if target_id == capture.node_id:
                    console.print("[dim]Already on this node.[/dim]")
                    return

                node_data = await backend.checkout_node(target_id)
                cli_switch_pending['node_id'] = target_id
                capture.switch_node(target_id)
                current_node_status['value'] = node_data.get("status", "active")
                fetched_label = node_data.get("label") or None
                current_node_label['value'] = fetched_label
                if fetched_label:
                    node_label_cache[target_id] = fetched_label

                new_cc_session_id = await driver.reset_context(
                    node_data.get("materialized_context", []),
                    cc_session_id=node_data.get("cc_session_id") or None,
                    cc_session_initialized=node_data.get("cc_session_initialized", False),
                    inherited_context_length=node_data.get("inherited_context_length", 0),
                    cwd=cwd,
                )
                if new_cc_session_id:
                    node_session_cache[target_id] = new_cc_session_id
                    try:
                        await backend.patch_node(target_id, {
                            "cc_session_id": new_cc_session_id,
                            "cc_session_initialized": True,
                        })
                    except Exception:
                        logger.warning("Failed to persist cc_session_id for checkout node %s", target_id)

                await backend.switch_node_notify(target_id)
                console.print(f"[bold cyan]→  Switched to node {target_id[:8]}[/bold cyan]")
                if fetched_label:
                    console.print(f"[dim]{fetched_label[:60]}{'…' if len(fetched_label) > 60 else ''}[/dim]")
                console.print()
            except BackendError as exc:
                console.print(f"[red]Checkout failed: {exc.detail}[/red]")
            except Exception as exc:
                logger.exception("Unexpected error during /checkout")
                console.print(f"[red]Checkout failed: {exc}[/red]")

        with pt_patch_stdout(raw=True):
            while True:
                # ---- Check for a pending branch switch from the browser ----
                await _handle_pending_switch()

                # ---- Read user input ----
                try:
                    prompt = await pt_session.prompt_async(PROMPT)
                except KeyboardInterrupt:
                    break
                except EOFError:
                    break

                if not prompt.strip():
                    continue

                # ---- Slash commands ----
                if prompt.strip().startswith('/'):
                    parts = prompt.strip().split(maxsplit=1)
                    cmd = parts[0].lower()
                    arg = parts[1] if len(parts) > 1 else None
                    if cmd == '/branch':
                        await _handle_branch()
                    elif cmd == '/checkout':
                        await _handle_checkout(node_prefix=arg)
                    else:
                        console.print(f"[yellow]Unknown command: {cmd}. Available: /branch, /checkout[/yellow]")
                    continue

                # ---- Re-check: branch may have arrived while prompt was blocking ----
                # Without this, the user's typed message goes to the old (parent) subprocess
                # instead of the newly switched branch subprocess.
                await _handle_pending_switch(print_notification=True)

                # ---- Auto-branch if current node is locked (branched) ----
                if current_node_status['value'] == 'branched':
                    try:
                        result = await backend.checkout_node(capture.node_id)
                        context_len = len(result.get("materialized_context", []))
                        child = await backend.branch_node(capture.node_id, context_len - 1)
                        child_id = child["id"]
                        capture.switch_node(child_id)
                        child_checkout = await backend.checkout_node(child_id)
                        current_node_status['value'] = child_checkout.get("status", "active")
                        current_node_label['value'] = child_checkout.get("label") or None
                        new_cc_session_id = await driver.reset_context(
                            child_checkout.get("materialized_context", []),
                            cc_session_id=child_checkout.get("cc_session_id") or None,
                            cc_session_initialized=child_checkout.get("cc_session_initialized", False),
                            inherited_context_length=child_checkout.get("inherited_context_length", 0),
                            cwd=cwd,
                        )
                        if new_cc_session_id:
                            current_cc_session_id['value'] = new_cc_session_id
                            try:
                                await backend.patch_node(child_id, {
                                    "cc_session_id": new_cc_session_id,
                                    "cc_session_initialized": True,
                                })
                            except Exception:
                                logger.warning("Failed to persist cc_session_id for auto-branch node %s", child_id)
                        console.print(f"[dim]Auto-branched → node {child_id[:8]}[/dim]")
                    except Exception:
                        logger.warning("Auto-branch failed for node %s — sending to branched node anyway", capture.node_id)



                # ---- Styled echo — erase prompt_toolkit's raw input line, replace with styled version ----
                lines_used = len(f"{PROMPT}{prompt}") // (console.width or 80) + 1
                sys.stdout.write(f"\033[{lines_used}A\033[J")
                sys.stdout.flush()
                console.print(f"[bold #6b7280 on #1f2937]  ›  [/bold #6b7280 on #1f2937][#e5e7eb on #1f2937]  {prompt.strip()}  [/#e5e7eb on #1f2937]\n")

                # ---- Record + send to driver ----
                # Set label from first message on this node if not yet known
                if not current_node_label['value']:
                    current_node_label['value'] = prompt.strip()[:80]
                    node_label_cache[capture.node_id] = current_node_label['value']
                # Auto-rename graph from first message if still using timestamp placeholder
                if not graph_name_set:
                    graph_name_set = True
                    new_name = ' '.join(prompt.strip().split()[:6])
                    try:
                        await backend.patch_graph(graph_id, {"name": new_name})
                    except Exception:
                        logger.warning("Failed to auto-rename graph %s", graph_id)
                try:
                    await capture.record_user_message(prompt.strip())
                    await driver.send(prompt.strip())
                except Exception as exc:
                    console.print(f"[red]Error sending prompt: {exc}[/red]")
                    continue

                # ---- Stream + record response ----
                is_streaming['value'] = True
                cc_session_id: str | None = None
                renderer = TerminalRenderer()
                renderer.start_turn()
                try:
                    async for event in driver.receive():
                        await capture.record_driver_event(event)
                        renderer.render(event)
                        # Capture the Claude Code session ID from the first event that has it.
                        # Every message type carries session_id in event.data.
                        if not cc_session_id and event.data.get("session_id"):
                            cc_session_id = event.data["session_id"]
                except KeyboardInterrupt:
                    renderer.stop_spinner_if_active()
                    console.print("\n[yellow]Interrupted.[/yellow]")
                except Exception as exc:
                    renderer.stop_spinner_if_active()
                    logger.exception("Error receiving response")
                    console.print(f"[red]Error: {exc}[/red]")
                finally:
                    is_streaming['value'] = False
                    # Persist the Claude Code session ID so checkout can --resume this node later.
                    if cc_session_id:
                        current_cc_session_id['value'] = cc_session_id
                        try:
                            await backend.patch_node(capture.node_id, {"cc_session_id": cc_session_id})
                        except Exception:
                            logger.warning("Failed to store cc_session_id for node %s", capture.node_id)
                    # If a branch arrived mid-stream, print the notification now
                    if switch_event.is_set():
                        deferred_id = pending_switch.get("node_id", "")
                        if deferred_id and not pending_switch.get("notified", False):
                            console.print(f"\n[bold yellow]⎇  Branch detected — switching to node {deferred_id[:8]}[/bold yellow]")
                            console.print("[dim]Context reset to branch point. Continue your prompt.[/dim]\n")

    finally:
        ws_stop.set()
        ws_task.cancel()
        await driver.disconnect()
        capture.close()
        await backend.aclose()
        console.print(Rule("[dim]Session ended[/dim]"))
        # Reset terminal state — prompt_toolkit raw mode can leave the terminal
        # garbled if the session exits uncleanly (Ctrl+C, subprocess crash, etc.)
        import subprocess
        subprocess.run(['stty', 'sane'], check=False, capture_output=True)



