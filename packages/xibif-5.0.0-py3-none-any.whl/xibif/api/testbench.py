"""Testbench API for XiBIF."""

import itertools
from importlib import import_module
from pydantic import ConfigDict, validate_call
from ..types import XibifPath, validate_XibifPath_exist, XibifRuntimeError, XibifDefaults
from ..logger import LoggerStage as LS, xibif_print_debug, xibif_print_info


def __get_hdltbgen() -> object:
    """Import the hdltbgen module, which is required for testbench generation.

    Returns:
        object: The imported hdltbgen module.

    Raises:
        XibifRuntimeError: If the hdltbgen module is not installed.
    """
    try:
        return import_module("hdltbgen")
    except ModuleNotFoundError as exc:
        raise XibifRuntimeError("This command requires the optional dependency 'hdltbgen'. Install it with: pip install \"xibif[testbench]\".") from exc


@validate_call(config=ConfigDict(strict=True))
@validate_XibifPath_exist
def testbench_generate(
    hdl_vhdl_file: XibifPath,
    hdl_tb_folder: XibifPath = XibifDefaults.HDL_TB_FOLDER,
    clock: list[str] | None = None,
    resetn: list[str] | None = None,
    resetp: list[str] | None = None,
) -> None:
    """Generate a testbench from a VHDL file.

    Args:
        hdl_vhdl_file (XibifPath): Path to the VHDL file.
        hdl_tb_folder (XibifPath, optional): Path to the directory containing the testbench files. Defaults to XibifDefaults.HDL_TB_FOLDER.
        clock (list[str] | None, optional): List of clocks. Defaults to None.
        resetn (list[str] | None, optional): List of negative resets. Defaults to None.
        resetp (list[str] | None, optional): List of positive resets. Defaults to None.

    Raises:
        XibifRuntimeError: An error occurred while creating the testbench.
    """
    # Try to import the hdltbgen module
    hdltbgen = __get_hdltbgen()

    xibif_print_info(f"Generating testbench for {hdl_vhdl_file} in {hdl_tb_folder}", stage=LS.TESTBENCH)

    # Generate clock, resetn, resetp strings
    clock = list(itertools.chain.from_iterable(["-c", clk] for clk in clock)) if clock is not None else []
    resetn = list(itertools.chain.from_iterable(["-rn", rn] for rn in resetn)) if resetn is not None else []
    resetp = list(itertools.chain.from_iterable(["-rp", rp] for rp in resetp)) if resetp is not None else []

    # Call the hdl testbench generator to generate the testbench
    arguments = ["-f", str(hdl_vhdl_file.as_posix()), "-t", "vhdl", "-v", "-o", str(hdl_tb_folder.as_posix()), *clock, *resetn, *resetp]
    arguments_csv = ["-f", str(hdl_vhdl_file.as_posix()), "-t", "csv", "-o", str(hdl_tb_folder.as_posix()), *clock, *resetn, *resetp]
    try:
        xibif_print_debug(f"Generating testbench with arguments: {arguments}", stage=LS.TESTBENCH)
        hdltbgen.from_argv(arguments)
        xibif_print_debug(f"Generating CSV with arguments: {arguments_csv}", stage=LS.TESTBENCH)
        hdltbgen.from_argv(arguments_csv)
    except Exception as exc:
        raise XibifRuntimeError("An error occurred while generating the testbench. Verify if the VHDL file contains valid VHDL code.") from exc


@validate_call(config=ConfigDict(strict=True))
@validate_XibifPath_exist
def testbench_analyze_source_file(
    hdl_vhdl_file: XibifPath,
) -> dict[str, list[str]]:
    """Analyze a VHDL source file to extract information about its ports and generics.

    Args:
        hdl_vhdl_file (XibifPath): Path to the VHDL file to be analyzed.

    Returns:
        dict[str, list[str]]: A dictionary containing lists of input ports, output ports, and generics found in the VHDL file.

    Raises:
        XibifRuntimeError: An error occurred while analyzing the VHDL file.
    """
    # Try to import the hdltbgen module
    hdltbgen = __get_hdltbgen()

    xibif_print_info(f"Analyzing VHDL source file {hdl_vhdl_file} for testbench generation", stage=LS.TESTBENCH)

    # Call the hdl testbench generator to analyze the source file
    parser = hdltbgen.parser.vhdl.Parser_VHDL(hdl_vhdl_file, False)
    try:
        parsed_vhdl = parser.parse()
    except Exception as exc:
        raise XibifRuntimeError("An error occurred while analyzing the VHDL file. Verify if the file contains valid VHDL code.") from exc

    # Generate a list of the ports found in the VHDL file
    input_ports = [port.name for port in parsed_vhdl.ports if port.direction == "in"]
    output_ports = [port.name for port in parsed_vhdl.ports if port.direction == "out"]
    generics = [generic.name for generic in parsed_vhdl.params]
    info = {"input": input_ports, "output": output_ports, "generic": generics}

    xibif_print_debug(f"Extracted information from VHDL file: {info}", stage=LS.TESTBENCH)
    return info
