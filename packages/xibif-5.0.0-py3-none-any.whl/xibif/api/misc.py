"""Misc API for various utility functions that do not fit into other categories."""

import shutil
import platform
import os
import stat
from datetime import datetime
import jinja2
from pydantic import ConfigDict, validate_call
from ..types import XibifPath, validate_XibifPath_exist, XibifDefaults, XibifRuntimeError
from ..logger import LoggerStage as LS, xibif_print_info, xibif_print_warning, xibif_print_debug
from ..project.models import XibifSettings
from ..deps import (
    DependencyCatalog,
    DependencyGroup as DG,
)

# Create dependency catalog instance
__DEPS = DependencyCatalog()


@validate_call(config=ConfigDict(strict=True))
def misc_create_backup(
    backup_folder: XibifPath = XibifDefaults.BACKUP_FOLDER,
) -> XibifPath:
    """Create a backup of the current project.

    Copies all contents of a XiBIF project directory (where the project file `.xibif` resides)
    to a backup directory, leaving the original directory untouched.

    Args:
        backup_folder (XibifPath, optional): The folder where the backup should be created. Defaults to XibifDefaults.BACKUP_FOLDER.

    Returns:
        XibifPath: The path to the created backup folder.

    Raises:
        XibifRuntimeError: If the generated backup sub-folder already exists.
    """
    # Generate a folder name based on the current date and time
    backup_sub_folder = backup_folder.joinpath(datetime.now().strftime("%Y-%m-%d_%H-%M-%S"))
    xibif_print_info(f"Creating a backup of the project at {backup_sub_folder}", stage=LS.MISC_CREATE_BACKUP)

    # Check that the backup folder does not already exist
    if backup_sub_folder.exists():
        raise XibifRuntimeError(f"Backup folder {backup_sub_folder} already exists. Please remove it or choose a different backup location.")

    # Copy the project files to the backup folder, ignoring thhe backup folder
    shutil.copytree(XibifPath("."), backup_sub_folder, ignore=shutil.ignore_patterns(backup_folder.name, ".git", "reports"))

    # Return the backup folder
    return backup_sub_folder


@validate_call(config=ConfigDict(strict=True))
@validate_XibifPath_exist
def misc_nuke_project_folder(
    project_folder: XibifPath = XibifDefaults.PROJECT_PATH,
) -> None:
    """Delete all files in the project folder.

    Args:
        project_folder (XibifPath, optional): The folder where the project is located. Defaults to XibifDefaults.PROJECT_PATH.
    """
    xibif_print_info(f"Nuking project folder at {project_folder}", stage=LS.MISC_NUKE_PROJECT)

    # Delete the full folder
    __misc_remove_folder(project_folder)

    xibif_print_info(f"Project folder at {project_folder} nuked successfully", stage=LS.MISC_NUKE_PROJECT)


@validate_call(config=ConfigDict(strict=True))
def misc_reset_project_folder(
    backup_folder: XibifPath = XibifDefaults.BACKUP_FOLDER,
    vivado_folder: XibifPath = XibifDefaults.VIVADO_FOLDER,
    vitis_folder: XibifPath = XibifDefaults.VITIS_FOLDER,
    src_folder: XibifPath = XibifDefaults.HDL_SRC_FOLDER,
    tb_folder: XibifPath = XibifDefaults.HDL_TB_FOLDER,
    reg_folder: XibifPath = XibifDefaults.REG_FOLDER,
    constraint_folder: XibifPath = XibifDefaults.CONSTRAINT_FOLDER,
    results_folder: XibifPath = XibifDefaults.RESULTS_FOLDER,
    demo_folder: XibifPath = XibifDefaults.SW_FOLDER,
    sigasi_folder: XibifPath = XibifDefaults.SIGASI_FOLDER,
    git_folder: XibifPath = XibifDefaults.GIT_FOLDER,
    project_folder: XibifPath = XibifDefaults.PROJECT_PATH,
) -> None:
    """Reset the project by deleting all generated files and folders, while keeping the project configuration file intact. A backup of the current project will be created before resetting.

    Be aware that whilst changing the overall project structure is possible, the workflow is best tested
    with the default folder configuration.

    Args:
        backup_folder (XibifPath): The folder where the backup should be created. Defaults to XibifDefaults.BACKUP_FOLDER.
        vivado_folder (XibifPath): The folder where the Vivado project is located. Defaults to XibifDefaults.VIVADO_FOLDER.
        vitis_folder (XibifPath): The folder where the Vitis project is located. Defaults to XibifDefaults.VITIS_FOLDER.
        src_folder (XibifPath): The folder where the HDL source files are located. Defaults to XibifDefaults.HDL_SRC_FOLDER.
        tb_folder (XibifPath): The folder where the HDL testbench files are located. Defaults to XibifDefaults.HDL_TB_FOLDER.
        reg_folder (XibifPath): The folder where the register configuration files are located. Defaults to XibifDefaults.REG_FOLDER.
        constraint_folder (XibifPath): The folder where the constraint files are located. Defaults to XibifDefaults.CONSTRAINT_FOLDER.
        results_folder (XibifPath): The folder where the results are stored. Defaults to XibifDefaults.RESULTS_FOLDER.
        demo_folder (XibifPath): The folder where the demo software files are located. Defaults to XibifDefaults.SW_FOLDER.
        sigasi_folder (XibifPath): The folder where the Sigasi project files are located. Defaults to XibifDefaults.SIGASI_FOLDER.
        git_folder (XibifPath): The folder where the Git repository is located. Defaults to XibifDefaults.GIT_FOLDER.
        project_folder (XibifPath): The folder where the project is located. Defaults to XibifDefaults.PROJECT_PATH.
    """
    xibif_print_info(f"Resetting project at {project_folder}", stage=LS.MISC_RESET_PROJECT)

    # Create a backup of the current project
    backup_folder = misc_create_backup(backup_folder=backup_folder)

    # Go through all relevant folders and delete them if they exist
    for folder in [vivado_folder, vitis_folder, src_folder, tb_folder, reg_folder, constraint_folder, results_folder, demo_folder, sigasi_folder, git_folder]:
        if folder.as_posix() != project_folder.as_posix():
            try:
                __misc_remove_folder(folder)
            except XibifRuntimeError:
                xibif_print_warning(f"Failed to remove folder at {folder}.", stage=LS.MISC_RESET_PROJECT)

    xibif_print_info(f"Project at {project_folder} reset successfully. Backup created at {backup_folder}", stage=LS.MISC_RESET_PROJECT)


@validate_call(config=ConfigDict(strict=True))
def misc_create_project_folder(
    vivado_folder: XibifPath = XibifDefaults.VIVADO_FOLDER,
    vitis_folder: XibifPath = XibifDefaults.VITIS_FOLDER,
    src_folder: XibifPath = XibifDefaults.HDL_SRC_FOLDER,
    tb_folder: XibifPath = XibifDefaults.HDL_TB_FOLDER,
    reg_folder: XibifPath = XibifDefaults.REG_FOLDER,
    constraint_folder: XibifPath = XibifDefaults.CONSTRAINT_FOLDER,
    results_folder: XibifPath = XibifDefaults.RESULTS_FOLDER,
    demo_folder: XibifPath = XibifDefaults.SW_FOLDER,
    sigasi_folder: XibifPath = XibifDefaults.SIGASI_FOLDER,
    git_folder: XibifPath = XibifDefaults.GIT_FOLDER,
    project_folder: XibifPath = XibifDefaults.PROJECT_PATH,
):
    """Create a XiBIF project directory.

    A XiBIF project directory contains all sub-directories that are relevant to
    a specific XiBIF project. When this function is invoked, all required directories
    are created if they do not exist.

    This command does not generate a `.xibif` project file!

    Args:
        vivado_folder (XibifPath): The folder where the Vivado project is located. Defaults to XibifDefaults.VIVADO_FOLDER.
        vitis_folder (XibifPath): The folder where the Vitis project is located. Defaults to XibifDefaults.VITIS_FOLDER.
        src_folder (XibifPath): The folder where the HDL source files are located. Defaults to XibifDefaults.HDL_SRC_FOLDER.
        tb_folder (XibifPath): The folder where the HDL testbench files are located. Defaults to XibifDefaults.HDL_TB_FOLDER.
        reg_folder (XibifPath): The folder where the register configuration files are located. Defaults to XibifDefaults.REG_FOLDER.
        constraint_folder (XibifPath): The folder where the constraint files are located. Defaults to XibifDefaults.CONSTRAINT_FOLDER.
        results_folder (XibifPath): The folder where the results are stored. Defaults to XibifDefaults.RESULTS_FOLDER.
        demo_folder (XibifPath): The folder where the demo software files are located. Defaults to XibifDefaults.SW_FOLDER.
        sigasi_folder (XibifPath): The folder where the Sigasi project files are located. Defaults to XibifDefaults.SIGASI_FOLDER.
        git_folder (XibifPath): The folder where the Git repository is located. Defaults to XibifDefaults.GIT_FOLDER.
        project_folder (XibifPath): The folder where the project is located. Defaults to XibifDefaults.PROJECT_PATH.
    """
    xibif_print_info(f"Creating project folder structure at {project_folder}", stage=LS.MISC_CREATE_PROJECT)

    # Create all relevant folders if they do not already exist
    for folder in [vivado_folder, vitis_folder, src_folder, tb_folder, reg_folder, constraint_folder, results_folder, demo_folder, sigasi_folder, git_folder]:
        folder.mkdir(parents=True, exist_ok=True)

    xibif_print_info(f"Project folder structure created successfully at {project_folder}", stage=LS.MISC_CREATE_PROJECT)


@validate_call(config=ConfigDict(strict=True))
@validate_XibifPath_exist
def misc_update_vitis_header_file(
    settings: XibifSettings,
    app_name: str = XibifDefaults.APP_NAME,
    vitis_folder: XibifPath = XibifDefaults.VITIS_FOLDER,
) -> None:
    """Update the project configuration header file

    Some project settings must be communicated to the processing system in
    a compatible format, i.e. a C-header file. When this function is invoked,
    a C-header file is generated that contains the relevat settings extracted
    from the `settings` parameter.

    Args:
        settings (XibifSettings): The current project settings to be applied to the Vitis header file.
        app_name (str, optional): The name of the application. Defaults to XibifDefaults.APP_NAME.
        vitis_folder (XibifPath, optional): The path to the Vitis project folder. Defaults to XibifDefaults.VITIS_FOLDER.
    """
    xibif_print_info("Updating Vitis header file with current project configuration", stage=LS.MISC_UPDATE_VITIS_HEADER_FILE)

    # Extract the relevant settings values and format them for the template
    mac = str(settings.mac).split(":")
    ip = str(settings.ip).split(".")
    netmask = str(settings.netmask).split(".")
    gateway = str(settings.gateway).split(".")

    # Get the template
    template_path = __DEPS.resolve(group=DG.PS_SETTINGS_TEMPLATE).as_path

    j2_env = jinja2.Environment(
        loader=jinja2.FileSystemLoader(searchpath=str(template_path.parent)),
        trim_blocks=True,
        lstrip_blocks=True,
    )
    j2_template = j2_env.get_template(template_path.name)

    # Render the template with the settings values
    rendered_header = j2_template.render(
        generation_date=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        mac_00=mac[0],
        mac_01=mac[1],
        mac_02=mac[2],
        mac_03=mac[3],
        mac_04=mac[4],
        mac_05=mac[5],
        ip_00=ip[0],
        ip_01=ip[1],
        ip_02=ip[2],
        ip_03=ip[3],
        netmask_00=netmask[0],
        netmask_01=netmask[1],
        netmask_02=netmask[2],
        netmask_03=netmask[3],
        gateway_00=gateway[0],
        gateway_01=gateway[1],
        gateway_02=gateway[2],
        gateway_03=gateway[3],
        timeout_dhcp_s=settings.timeout_dhcp,
        timeout_connection_drop_ms=settings.timeout_connection_drop_ms,
        connection_drop_flush_fifo="1" if settings.connection_drop_flush_fifo else "0",
        timeout_axi_firewall_clocks=settings.timeout_axi_firewall_clocks,
        enable_webserver="1" if settings.enable_webserver else "0",
    )

    # Write the rendered header to the Vitis folder
    settings_header_path = XibifDefaults.vitis_settings_header_path(app_name=app_name, vitis_folder=vitis_folder)
    settings_header_path.write_text(rendered_header, encoding="utf-8")

    xibif_print_info(f"Vitis header file updated at {settings_header_path}", stage=LS.MISC_UPDATE_VITIS_HEADER_FILE)


######################################################################################
# Internal helper functions for rmisc stuff, not part of the public API
######################################################################################


@validate_call(config=ConfigDict(strict=True))
def __misc_remove_folder_recursive(path: XibifPath) -> None:
    """Recursively remove a folder and all its contents.

    Args:
        path (XibifPath): The path to the folder to be removed.
    """
    if path.is_dir():
        for child in path.iterdir():
            __misc_remove_folder_recursive(XibifPath(child))

        try:
            path.rmdir()
        except (PermissionError, OSError):
            if platform.system() == "Windows":
                xibif_print_warning(f"PermissionError while removing folder at {path}. This might be caused because the folder is in use.", stage=LS.NO_CHANGE)
            else:
                raise XibifRuntimeError(f"PermissionError while removing folder at {path}.") from None
    else:
        try:
            path.unlink()
        except (PermissionError, OSError):
            if platform.system() == "Windows":
                xibif_print_warning(f"PermissionError while removing file at {path}. This might be caused because the file is in use.", stage=LS.NO_CHANGE)
            else:
                raise XibifRuntimeError(f"PermissionError while removing file at {path}.") from None


@validate_call(config=ConfigDict(strict=True))
def __misc_remove_folder(path: XibifPath) -> None:
    """Remove a folder and all its contents, ignoring read-only files.

    Args:
        path (XibifPath): The path to the folder to be removed.

    Raises:
        XibifRuntimeError: If the folder could not be removed.
    """
    xibif_print_debug(f"Removing folder at {path}", stage=LS.NO_CHANGE)

    if not path.exists():
        xibif_print_debug(f"Folder at {path} does not exist, skipping removal", stage=LS.NO_CHANGE)
        return

    def remove_readonly(func, path, _):
        "Clear the readonly bit and reattempt the removal"
        os.chmod(path, stat.S_IWRITE)
        func(path)

    try:
        shutil.rmtree(path, onerror=remove_readonly)
    except (PermissionError, OSError) as e:
        if platform.system() == "Windows":
            # Attempt to remove the folder recursively while ignoring permission errors, which might allow to remove at least some of the files in the folder and thus reduce the amount of manual cleanup that is required
            __misc_remove_folder_recursive(path)
        else:
            raise XibifRuntimeError(f"PermissionError while removing folder at {path}.") from e
    except Exception as e:
        raise XibifRuntimeError(f"Failed to remove folder at {path}.") from e
