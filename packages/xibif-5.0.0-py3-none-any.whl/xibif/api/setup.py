"""Setup API for XiBIF."""

import shutil
import git
from pydantic import ConfigDict, validate_call
from ..utils import get_clean_shell, get_clean_shell_batch_command, check_tool, get_xilinx_tool_paths
from ..shell.tools.vivado.shell import VivadoShell
from ..shell.tools.vitis.shell import VitisShell
from ..shell.models import ShellTool
from ..shell import ShellFactory, CommandSetFactory
from ..deps import (
    DependencyCatalog,
    DependencyContext as DC,
    DependencyGroup as DG,
)
from ..types import XilinxBoard, XilinxVersion, XibifPath, validate_XibifPath_exist, XibifEnvironmentError, XibifGeneratedFileError, XibifRuntimeError, XibifDefaults
from ..logger import LoggerStage as LS, xibif_print_debug, xibif_print_info, xibif_print_warning

# Create dependency catalog instance
__DEPS = DependencyCatalog()


@validate_call(config=ConfigDict(strict=True, arbitrary_types_allowed=True))
@validate_XibifPath_exist
def setup_vivado_project(
    project_name: str,
    board: XilinxBoard,
    xilinx_version: XilinxVersion,
    blockdesign: str = XibifDefaults.BLOCKDESIGN_NAME,
    vivado_folder: XibifPath = XibifDefaults.VIVADO_FOLDER,
    src_folder: XibifPath = XibifDefaults.HDL_SRC_FOLDER,
    constraint_folder: XibifPath = XibifDefaults.CONSTRAINT_FOLDER,
    results_folder: XibifPath = XibifDefaults.RESULTS_FOLDER,
    runtime: VivadoShell | None = None,
    xilinx_path: XibifPath | None = None,
) -> None:
    """Set up a Vivado project.

    Sets up a Vivado project with a specified name for a given Xilinx version. The project is
    created inside `vivado_folder`, source and constraint files are added automatically.

    Args:
        project_name (str): The name of the Vivado project to be created.
        board (XilinxBoard): The target FPGA board for the project.
        xilinx_version (XilinxVersion): The Xilinx version to determine the appropriate commands and shell configuration.
        blockdesign (str, optional): The name of the block design to be created. Defaults to XibifDefaults.BLOCKDESIGN_NAME.
        vivado_folder (XibifPath, optional): The folder where the Vivado project should be created. Defaults to XibifDefaults.VIVADO_FOLDER.
        src_folder (XibifPath, optional): The folder containing the HDL source files to be added to the project. Defaults to XibifDefaults.HDL_SRC_FOLDER.
        constraint_folder (XibifPath, optional): The folder containing the constraint files to be added to the project. Defaults to XibifDefaults.CONSTRAINT_FOLDER.
        results_folder (XibifPath, optional): The folder where the generated hardware files should be saved. Defaults to XibifDefaults.RESULTS_FOLDER.
        runtime (Union[VivadoShell, None], optional): An existing VivadoShell instance to use for executing commands. If None, a new shell will be created. Defaults to None.
        xilinx_path (XibifPath | None, optional): The path to the Xilinx installation directory. Required if runtime is None. Defaults to None.

    Raises:
        XibifEnvironmentError: If xilinx_path is not provided when runtime is None.
        XibifGeneratedFileError: If the expected hardware file is not generated after running the Vivado commands.
    """
    xibif_print_info(f"Setup vivado project at {vivado_folder}", stage=LS.SETUP_VIVADO)

    # Get commands for vivado
    commands = CommandSetFactory.get_command_set(tool=ShellTool.VIVADO, version=xilinx_version)

    # Prepare shell
    if runtime is None:
        if xilinx_path is None:
            raise XibifEnvironmentError("Xilinx path must be provided if no runtime shell is given.")

        # Open Vivado shell
        tool = ShellFactory.create_shell(
            tool_name=ShellTool.VIVADO,
            version=xilinx_version,
            executable=get_xilinx_tool_paths(xilinx_path=xilinx_path, xilinx_version=xilinx_version).vivado,
        )
    else:
        tool = runtime

    # Search files
    hdl_src_files = list(src_folder.glob("*.vhd"))
    constraint_files = list(constraint_folder.glob("*.xdc"))
    hardware_path = XibifDefaults.vivado_hardware_path(project_name=project_name, results_folder=results_folder)

    # Setup the Vivado project
    with tool:
        tool.logger_stage = LS.SETUP_VIVADO_PROJECT
        tool.run(commands.create_project(project_name=project_name, project_path=vivado_folder, board=board))
        tool.logger_stage = LS.SETUP_VIVADO_BLOCKDESIGN
        tool.run(commands.create_block_design(block_design_name=blockdesign))
        tool.run(commands.add_design_file(file_path=hdl_src_files))
        tool.run(commands.add_constraint_file(file_path=constraint_files))
        tool.run(commands.add_xibif_to_block_design(block_design_name=blockdesign, board=board))
        tool.run(commands.set_ooc_run(mode="None", block_design_name=blockdesign))
        tool.run(commands.save_block_design(block_design_name=blockdesign))
        tool.logger_stage = LS.SETUP_VIVADO_FINALIZE
        tool.run(commands.export_hardware(hardware_path=hardware_path, include_bitstream=False))

    # Check if the hardware file has been generated
    if not hardware_path.exists():
        raise XibifGeneratedFileError(f"Hardware file {hardware_path} does not exist. Please review the Vivado Log for possible error sources.")
    else:
        xibif_print_debug(f"Hardware file {hardware_path} has been generated.", stage=LS.SETUP_VIVADO_FINALIZE)


@validate_call(config=ConfigDict(strict=True, arbitrary_types_allowed=True))
@validate_XibifPath_exist
def setup_vitis_project(
    project_name: str,
    board: XilinxBoard,
    xilinx_version: XilinxVersion,
    platform_name: str = XibifDefaults.PLATFORM_NAME,
    app_name: str = XibifDefaults.APP_NAME,
    vitis_folder: XibifPath = XibifDefaults.VITIS_FOLDER,
    results_folder: XibifPath = XibifDefaults.RESULTS_FOLDER,
    runtime: VitisShell | None = None,
    xilinx_path: XibifPath | None = None,
    link: bool = False,
):
    """Set up a Vitis project.

    Sets up a Vitis project with the specified name for a given toolchain version.
    The project setup consists of creating the workspace, platform and application.
    The source files required for a XiBIF application to run are added automatically,
    the linker script is adjusted for the project's hardware target.

    After setup, the application is built.
    Args:
        project_name (str): The name of the Vitis project to be created.
        board (XilinxBoard): The target FPGA board for the project.
        xilinx_version (XilinxVersion): The Xilinx version to determine the appropriate commands and shell configuration.
        platform_name (str, optional): The name of the platform to be created. Defaults to XibifDefaults.PLATFORM_NAME.
        app_name (str, optional): The name of the application to be created. Defaults to XibifDefaults.APP_NAME.
        vitis_folder (XibifPath, optional): The folder where the Vitis project should be created. Defaults to XibifDefaults.VITIS_FOLDER.
        results_folder (XibifPath, optional): The folder where the generated application files should be saved. Defaults to XibifDefaults.RESULTS_FOLDER.
        runtime (Union[VitisShell, None], optional): An existing VitisShell instance to use for executing commands. If None, a new shell will be created. Defaults to None.
        xilinx_path (XibifPath | None, optional): The path to the Xilinx installation directory. Required if runtime is None. Defaults to None.
        link (bool): If True, create symbolic links instead of copying the files. Defaults to False.

    Raises:
        XibifEnvironmentError: If xilinx_path is not provided when runtime is None.
        XibifGeneratedFileError: If the expected application file is not generated after running the Vitis commands.
    """
    xibif_print_info(f"Setup Vitis project at {vitis_folder}", stage=LS.SETUP_VITIS)

    # Get commands for vitis
    commands = CommandSetFactory.get_command_set(tool=ShellTool.VITIS, version=xilinx_version)

    # Define context for dependency resolution
    ctx = DC(board=board, xilinx_version=xilinx_version)

    # Prepare shell
    if runtime is None:
        if xilinx_path is None:
            raise XibifEnvironmentError("Xilinx path must be provided if no runtime shell is given.")

        tool_name = "xsct" if xilinx_version in [XilinxVersion.V2023_1, XilinxVersion.V2023_2] else "vitis"

        # Open Vitis shell
        tool = ShellFactory.create_shell(
            tool_name=ShellTool.VITIS,
            version=xilinx_version,
            executable=get_xilinx_tool_paths(xilinx_path=xilinx_path, xilinx_version=xilinx_version)[tool_name],
            interpreter=get_clean_shell(__DEPS.resolve(group=DG.PS_SHELL, ctx=ctx).as_path),
            precommand=get_clean_shell_batch_command(get_xilinx_tool_paths(xilinx_path=xilinx_path, xilinx_version=xilinx_version).settings64_script),
        )
    else:
        tool = runtime

    # Gather dependency files
    mss_path = __DEPS.resolve(group=DG.PS_MSS, ctx=ctx).as_path if xilinx_version in (XilinxVersion.V2023_1, XilinxVersion.V2023_2) else XibifPath("")
    link_script = __DEPS.resolve(group=DG.PS_LINKER, ctx=ctx).as_path
    src_files = __DEPS.resolve(group=DG.PS_SRC, ctx=ctx).as_path
    header_files = __DEPS.resolve(group=DG.PS_HEADER, ctx=ctx).as_path

    # Define some additional paths
    fsbl_path = XibifDefaults.vitis_fsbl_path(results_folder=results_folder)
    temp_project_path = XibifDefaults.vitis_temp_project_path(project_name=project_name, vitis_folder=vitis_folder)
    hardware_path = XibifDefaults.vivado_hardware_path(project_name=project_name, results_folder=results_folder)

    # Move temp files
    shutil.move(vitis_folder.joinpath(app_name), temp_project_path)
    temp_header_files = list(temp_project_path.joinpath("src").glob("*.h"))
    temp_source_files = list(temp_project_path.joinpath("src").glob("*.c"))

    # Setup the Vitis project
    with tool:
        tool.logger_stage = LS.SETUP_VITIS_WORKSPACE
        tool.run(commands.create_workspace(workspace_path=vitis_folder))
        tool.logger_stage = LS.SETUP_VITIS_PLATFORM
        tool.run(commands.create_platform(platform_name=platform_name, hardware_path=hardware_path, board=board))
        tool.run(commands.create_domain(platform_name=platform_name, board=board))
        tool.run(commands.set_active_platform(platform_name=platform_name))
        tool.logger_stage = LS.SETUP_VITIS_DOMAIN
        tool.run(commands.set_active_domain(board=board))
        tool.run(commands.config_domain(mss_path=mss_path, board=board))
        tool.logger_stage = LS.SETUP_VITIS_APPLICATION
        tool.run(commands.create_application(app_name=app_name, platform_name=platform_name, board=board))
        tool.run(commands.add_file(app_name=app_name, file_path=src_files))
        tool.run(commands.add_file(app_name=app_name, file_path=header_files))
        tool.run(commands.add_file(app_name=app_name, file_path=temp_header_files))
        tool.run(commands.add_file(app_name=app_name, file_path=temp_source_files))
        tool.downgrade_errors = True  # Vitis < 2024.1 throws a lot of errors resulting from pragmas in the source files
        tool.run(commands.generate_platform())
        tool.downgrade_errors = False
        tool.run(commands.add_linker_script(app_name=app_name, file_path=link_script))
        tool.run(commands.set_application_config(app_name=app_name, config="Release"))
        tool.logger_stage = LS.SETUP_VITIS_BUILD
        tool.downgrade_errors = True  # Vitis < 2024.1 throws a lot of errors resulting from pragmas in the source files
        tool.run(commands.generate_application(app_name=app_name))
        tool.run(commands.copy_application(app_name=app_name, output_path=results_folder, platform_name=platform_name, workspace_path=vitis_folder, board=board))

    # Remove temp folder
    shutil.rmtree(temp_project_path)

    # Check if the imported files need to be replaced by links
    if link:
        for file in src_files + header_files:
            destination = XibifDefaults.vitis_src_folder_path(app_name, vitis_folder).joinpath(file.name)
            if destination.exists():
                destination.unlink()
            try:
                destination.symlink_to(file)
            except OSError:
                # If symlink creation fails (e.g., on Windows without admin rights), fall back to copying
                xibif_print_warning(f"Symlink creation failed for {file} -> {destination}. Falling back to copying.", stage=LS.NO_CHANGE)
                shutil.copy(file, destination.parent)

    # Check if the fsbl file has been generated
    if not fsbl_path.exists():
        raise XibifGeneratedFileError(f"FSBL file {fsbl_path} does not exist. Please review the Vitis Log for possible error sources.")

    else:
        xibif_print_debug(f"FSBL file {fsbl_path} has been generated.", stage=LS.SETUP_VITIS_FINALIZE)


@validate_call(config=ConfigDict(strict=True))
def setup_hdl_files(
    src_folder: XibifPath = XibifDefaults.HDL_SRC_FOLDER,
    tb_folder: XibifPath = XibifDefaults.HDL_TB_FOLDER,
    link: bool = False,
) -> None:
    """Setup XiBIF HDL files.

    Initiailies the XiBIF HDL dependencies in the specified folders.
    The XiBIF HDL dependencies contain all hardware descriptions of the FIFOs that
    are used for data streaming in the PL as well as open-source HDL code for AXI
    handling (see open-logic https://github.com/open-logic/open-logic)

    Args:
        src_folder (XibifPath): The target folder where the HDL source files should be copied. Defaults to XibifDefaults.HDL_SRC_FOLDER.
        tb_folder (XibifPath): The target folder where the HDL testbench files should be copied. Defaults to XibifDefaults.HDL_TB_FOLDER.
        link (bool): If True, create symbolic links instead of copying the files. Defaults to False.
    """
    xibif_print_info(f"Copy HDL source files to {src_folder}", stage=LS.SETUP_HDL)
    __DEPS.resolve(group=DG.FPGA_SRC).copy(destination=src_folder, link=link)

    xibif_print_info(f"Copy HDL testbench files to {tb_folder}", stage=LS.SETUP_HDL)
    __DEPS.resolve(group=DG.FPGA_TB).copy(destination=tb_folder, link=link)


@validate_call(config=ConfigDict(strict=True))
def setup_vunit_python_files(
    vunit_folder: XibifPath = XibifDefaults.HDL_TB_FOLDER,
    link: bool = False,
) -> None:
    """Setup Vunit files.

    Copies the XiBIF Vunit dependencies to the specified folder.

    Args:
        vunit_folder (XibifPath): The target folder where the VUNIT Python files should be copied. Defaults to XibifDefaults.HDL_TB_FOLDER.
        link (bool): If True, create symbolic links instead of copying the files. Defaults to False.
    """
    xibif_print_info(f"Copying VUNIT Python files to {vunit_folder}", stage=LS.SETUP_VUNIT)
    __DEPS.resolve(group=DG.FPGA_VUNIT_RUN).copy(destination=vunit_folder, link=link)


@validate_call(config=ConfigDict(strict=True))
def setup_constraint_files(
    board: XilinxBoard,
    constraint_folder: XibifPath = XibifDefaults.CONSTRAINT_FOLDER,
    link: bool = False,
) -> None:
    """Setup XiBIF constraint files.

    Copies the constraint files for an FPGA board to the specified folder.
    XiBIF uses chips rather than boards as targets. As a consequence, certain
    settings (e.g. the clock pin) must be manually defined in the constraint
    file.

    The constraint files are specific to one target only! There is no guarantee
    for compatibility when switching to another chip or board revision.

    Args:
        board (XilinxBoard): The board for which the constraint files should be copied.
        constraint_folder (XibifPath): The target folder where the constraint files should be copied. Defaults to XibifDefaults.CONSTRAINT_FOLDER.
        link (bool): If True, create symbolic links instead of copying the files. Defaults to False.
    """
    xibif_print_info(f"Copying constraint files for {board} to {constraint_folder}", stage=LS.SETUP_CONSTRAINTS)
    __DEPS.resolve(group=DG.FPGA_CONSTRAINT, ctx=DC(board=board)).copy(destination=constraint_folder, link=link)


@validate_call(config=ConfigDict(strict=True))
def setup_register_files(
    reg_folder: XibifPath = XibifDefaults.REG_FOLDER,
    link: bool = False,
) -> None:
    """Set up register dependencies.

    Copies the XiBIF user register configuration and definition files to the specified directory.

    Args:
        reg_folder (XibifPath): The target folder where the register files should be copied. Defaults to XibifDefaults.REG_FOLDER.
        link (bool): If True, create symbolic links instead of copying the files. Defaults to False.
    """
    xibif_print_info(f"Copy corsair register files to {reg_folder}", stage=LS.SETUP_REGS)
    __DEPS.resolve(group=DG.CORSAIR_USER_REGS).copy(destination=reg_folder, link=link)
    __DEPS.resolve(group=DG.CORSAIR_USER_CONFIG).copy(destination=reg_folder, link=link)


@validate_call(config=ConfigDict(strict=True))
def setup_demo_files(
    demo_folder: XibifPath = XibifDefaults.SW_FOLDER,
    link: bool = False,
):
    """Set up demo files.

    Copies demo software files to the specified folder. The demo files contain explanatory
    code snippets.

    Args:
        demo_folder (XibifPath): The target folder where the demo software files should be copied. Defaults to XibifDefaults.SW_FOLDER.
        link (bool): If True, create symbolic links instead of copying the files. Defaults to False.
    """
    xibif_print_info(f"Copy demo software files to {demo_folder}", stage=LS.SETUP_DEMO_FILES)
    __DEPS.resolve(group=DG.PYTHON_DEMO).copy(destination=demo_folder, link=link)


@validate_call(config=ConfigDict(strict=True))
def setup_sigasi_project(
    project_name: str,
    sigasi_folder: XibifPath = XibifDefaults.SIGASI_FOLDER,
    link: bool = False,
) -> None:
    """Set up a Sigasi project for the XiBIF project.

    Copies the Sigasi project files to the specified destination folder. The Sigasi project
    is set up such that all libraries and include directories are set up to work with a default
    XiBIF setup.

    Args:
        project_name (str): The name of the Sigasi project to be created.
        sigasi_folder (XibifPath): The target folder where the Sigasi project files should be copied. Defaults to XibifDefaults.SIGASI_FOLDER.
        link (bool): If True, create symbolic links instead of copying the files. Defaults to False.
    """
    xibif_print_info("Setting up Sigasi project", stage=LS.SETUP_SIGASI)
    __DEPS.resolve(group=DG.SIGASI_PROJECT, ctx=DC(project_name=project_name)).copy(destination=sigasi_folder, link=link)
    __DEPS.resolve(group=DG.SIGASI_SETTINGS).copy(destination=sigasi_folder.joinpath(".settings"), link=link)


@validate_call(config=ConfigDict(strict=True))
def setup_git_files(
    git_folder: XibifPath = XibifDefaults.GIT_FOLDER,
    link: bool = False,
) -> None:
    """Copy Git configuration files.

    Copies the Git configuration files to the specified destination folder. The main file
    to copy it the `.gitignore` file that is set up to ignore all files generated by the toolchain.

    Args:
        git_folder (XibifPath): The target folder where the Git files should be copied. Defaults to XibifDefaults.GIT_FOLDER.
        link (bool): If True, create symbolic links instead of copying the files. Defaults to False.
    """
    xibif_print_info(f"Copying Git files to {git_folder}", stage=LS.SETUP_GIT)
    __DEPS.resolve(group=DG.GIT_FILES).copy(destination=git_folder, link=link)


@validate_call(config=ConfigDict(strict=True))
def setup_git_repository(
    git_folder: XibifPath = XibifDefaults.GIT_FOLDER,
) -> None:
    """Initialize a Git repository.

    Initializes a Git repository in the specified folder if it does not exist.

    Args:
        git_folder (XibifPath): The target folder where the Git repository should be initialized. Defaults to XibifDefaults.GIT_FOLDER.

    Raises:
        XibifEnvironmentError: If Git is not installed or not found in the system path.
    """
    xibif_print_info(f"Setting up Git repository in {git_folder}", stage=LS.SETUP_GIT)

    # Check if git is installed
    if check_tool("git") is None:
        raise XibifEnvironmentError("Git is not installed or in the path variable. Please install git or add it to the path variable and try again.")

    # Check if the project is already a git repository
    try:
        _ = git.Repo(git_folder, search_parent_directories=True)
        xibif_print_info("Project is already a git repository.", stage=LS.SETUP_GIT)
    except git.InvalidGitRepositoryError:
        # Initialize a new git repository
        xibif_print_info("Initialize a new git repository.", stage=LS.SETUP_GIT)
        repo = git.Repo.init(git_folder)
        repo.git.add(A=True)
        repo.git.commit("--allow-empty", "-m", "Initial commit")


@validate_call(config=ConfigDict(strict=True))
def setup_openlogic_files(
    openlogic_folder: XibifPath = XibifDefaults.OPENLOGIC_FOLDER,
):
    """Add open-logic as a sub-module to the project.

    Adds open-logic as a sub-module to the project in the specified directory
    such that open-logic blocks can be used in the HDL design.

    Args:
        openlogic_folder (XibifPath): The target folder where the OpenLogic repository should be cloned as a Git submodule. Defaults to XibifDefaults.OPENLOGIC_FOLDER.

    Raises:
        XibifEnvironmentError: If Git is not installed or not found in the system path.
        XibifRuntimeError: If no Git repository is found in the target folder or any of its parent directories.
    """
    xibif_print_info(f"Cloning OpenLogic files to {openlogic_folder}", stage=LS.SETUP_OPENLOGIC)

    # Check if git is installed
    if check_tool("git") is None:
        raise XibifEnvironmentError("Git is not installed or in the path variable. Please install git or add it to the path variable and try again.")

    # Create target folder if it does not exist
    openlogic_folder.mkdir(parents=True, exist_ok=True)

    try:
        # Search for a git repository in the target folder and its parent directories
        repo = git.Repo(openlogic_folder, search_parent_directories=True)

        # Check if this repository is the open-logic repository itself
        if XibifPath(repo.working_tree_dir).name != ".git":
            xibif_print_debug(f"Git repository at {repo.working_tree_dir} is likely the open-logic repository itself.", stage=LS.SETUP_OPENLOGIC)
            repo = git.Repo(openlogic_folder.parent, search_parent_directories=True)

        xibif_print_debug(f"Found git repository at {repo.working_tree_dir}", stage=LS.SETUP_OPENLOGIC)

    except git.exc.InvalidGitRepositoryError as exc:
        raise XibifRuntimeError(f"No git repository found at {openlogic_folder} or any of its parent directories. Please initialize a git repository before setting up OpenLogic.") from exc

    # Skip adding if the submodule already exists
    for sm in repo.submodules:
        if sm.name == "open-logic":
            xibif_print_info("OpenLogic submodule already exists. Skipping.", stage=LS.SETUP_OPENLOGIC)
            return

    # Add open-logic as a submodule
    git.Submodule.add(
        repo=repo,
        name="open-logic",
        path=openlogic_folder,
        url="https://github.com/open-logic/open-logic.git",
        branch="main",
        clone_multi_options=["--recurse-submodules"],
    )


@validate_call(config=ConfigDict(strict=True, arbitrary_types_allowed=True))
@validate_XibifPath_exist
def setup_openlogic_vivado(
    project_name: str,
    xilinx_version: XilinxVersion,
    vivado_folder: XibifPath = XibifDefaults.VIVADO_FOLDER,
    openlogic_folder: XibifPath = XibifDefaults.OPENLOGIC_FOLDER,
    runtime: VivadoShell | None = None,
    xilinx_path: XibifPath | None = None,
) -> None:
    """Set up Vivado to use open-logic files.

    Sets up the XiBIF-required open-logic files in the Vivado project by importing
    the design files.

    Args:
        project_name (str): The name of the Vivado project where the OpenLogic files should be imported.
        xilinx_version (XilinxVersion): The Xilinx version to determine the appropriate commands and shell configuration.
        vivado_folder (XibifPath, optional): The folder where the Vivado project is located. Defaults to XibifDefaults.VIVADO_FOLDER.
        openlogic_folder (XibifPath, optional): The folder where the OpenLogic files are located. Defaults to XibifDefaults.OPENLOGIC_FOLDER.
        runtime (Union[VivadoShell, None], optional): An existing VivadoShell instance to use for executing commands. If None, a new shell will be created. Defaults to None.
        xilinx_path (XibifPath | None, optional): The path to the Xilinx installation directory. Required if runtime is None. Defaults to None.

    Raises:
        XibifEnvironmentError: If xilinx_path is not provided when runtime is None.
    """
    xibif_print_info(f"Add OpenLogic files to Vivado project at {vivado_folder}", stage=LS.SETUP_OPENLOGIC)

    # Get commands for vivado
    commands = CommandSetFactory.get_command_set(tool=ShellTool.VIVADO, version=xilinx_version)

    # Prepare shell
    if runtime is None:
        if xilinx_path is None:
            raise XibifEnvironmentError("Xilinx path must be provided if no runtime shell is given.")

        # Open Vivado shell
        tool = ShellFactory.create_shell(
            tool_name=ShellTool.VIVADO,
            version=xilinx_version,
            executable=get_xilinx_tool_paths(xilinx_path=xilinx_path, xilinx_version=xilinx_version).vivado,
        )
    else:
        tool = runtime

    # Create project path
    project_path = XibifDefaults.vivado_project_path(project_name=project_name, vivado_folder=vivado_folder)

    # Setup the Vivado project
    with tool:
        tool.logger_stage = LS.SETUP_OPENLOGIC_VIVADO
        tool.run(commands.open_project(project_path=project_path))
        tool.run(commands.run_file(file_path=XibifDefaults.openlogic_import_script_path(openlogic_folder=openlogic_folder)))
