"""XiBIF API - Main entry point for all API functions and classes."""

from importlib import import_module

__all__ = ["build", "flash", "register", "setup", "simulate", "testbench", "upgrade", "misc"]


def __getattr__(name: str):
    """Import API modules lazily so individual consumers only load what they need."""
    if name in __all__:
        module = import_module(f"{__name__}.{name}")
        globals()[name] = module
        return module
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
