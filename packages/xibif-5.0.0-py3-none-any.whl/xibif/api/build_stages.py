"""Build stage definitions and utilities for Vivado and Vitis projects."""

from enum import IntEnum, EnumMeta
from pydantic import validate_call, ConfigDict
from ..types import XibifValidationError


class ValidatedStageEnumMeta(EnumMeta):
    """Metaclass that validates stage enum values are unique across all stage enums."""

    _all_stage_values: dict[int, str] = {}

    def __new__(mcs, name, bases, namespace, **kwargs):
        cls = super().__new__(mcs, name, bases, namespace, **kwargs)

        # Validate all member values are unique
        for member in cls:
            if member.value in mcs._all_stage_values:
                raise XibifValidationError(f"Duplicate stage value {member.value} found: {name}.{member.name} conflicts with {mcs._all_stage_values[member.value]}")
            mcs._all_stage_values[member.value] = f"{name}.{member.name}"

        return cls


class VivadoStage(IntEnum, metaclass=ValidatedStageEnumMeta):
    """Enumeration of build stages for Vivado projects.

    Attributes:
        synthesize: Run synthesis on the design.
        implement: Run implementation (place and route).
        bitstream: Generate the bitstream file.
        export: Export the hardware design (XSA file).
        reportTiming: Generate timing reports.
        all: Run all stages in sequence.
    """

    blockdesign = 100
    synthesize = 101
    implement = 102
    bitstream = 103
    export = 104
    reportTiming = 105
    all = 106


class VitisStage(IntEnum, metaclass=ValidatedStageEnumMeta):
    """Enumeration of build stages for Vitis projects.

    Attributes:
        update: Update the platform with new hardware design.
        build: Build the application.
        export: Export the application and FSBL files.
        bootfile: Generate the BOOT.bin file.
        updateLaunch: Update launch configuration files.
        all: Run all stages in sequence.
    """

    update = 200
    build = 201
    export = 202
    bootfile = 203
    updateLaunch = 204
    all = 205


# Create an Union type for both stage enums
BuildStage = VivadoStage | VitisStage


@validate_call(config=ConfigDict(strict=True))
def get_stage_choices() -> list[str]:
    """Get a list of valid stage choices for command-line arguments.

    Returns:
        list[str]: A list of stage choices in the format 'vivado:stageName' or 'vitis:stageName' for all stages defined in VivadoStage and VitisStage enums, excluding the 'all' stage.
    """
    choices = []
    for stage in VivadoStage:
        if stage.name != "all":
            choices.append(f"vivado:{stage.name}")
    for stage in VitisStage:
        if stage.name != "all":
            choices.append(f"vitis:{stage.name}")
    return choices


@validate_call(config=ConfigDict(strict=True))
def parse_stage(
    stage_string: str,
) -> BuildStage:
    """Parse a stage string from command-line arguments into a BuildStage enum value.

    Args:
        stage_string (str): The stage string to parse, in the format 'vivado:stageName' or 'vitis:stageName'.

    Returns:
        BuildStage: The corresponding BuildStage enum value for the provided stage string.

    Raises:
        XibifValidationError: If the stage string is not in the correct format or if the stage name is not recognized.
    """
    if ":" not in stage_string:
        raise XibifValidationError(f"Stage string must be in format 'vivado:stageName' or 'vitis:stageName', got: {stage_string}")

    prefix, stage_name = stage_string.split(":", 1)

    if prefix == "vivado":
        try:
            return VivadoStage[stage_name]
        except KeyError as exc:
            raise XibifValidationError(f"Unknown Vivado stage: {stage_name}") from exc
    elif prefix == "vitis":
        try:
            return VitisStage[stage_name]
        except KeyError as exc:
            raise XibifValidationError(f"Unknown Vitis stage: {stage_name}") from exc
    else:
        raise XibifValidationError(f"Invalid stage prefix: {prefix}. Must be 'vivado' or 'vitis'")


@validate_call(config=ConfigDict(strict=True))
def get_stages_between(
    from_stage: BuildStage | None = None,
    to_stage: BuildStage | None = None,
) -> tuple[list[VivadoStage], list[VitisStage]]:
    """Get lists of Vivado and Vitis stages between the provided from_stage and to_stage.
    If from_stage or to_stage is None, it defaults to the start or end of the stage sequence respectively.

    Args:
        from_stage (BuildStage | None): The stage to start from (inclusive). If None, starts from the beginning of the stages.
        to_stage (BuildStage | None): The stage to end at (inclusive). If None, ends at the last stage.

    Returns:
        tuple[list[VivadoStage], list[VitisStage]]: A tuple containing two lists:
            - The first list contains the Vivado stages between from_stage and to_stage.
            - The second list contains the Vitis stages between from_stage and to_stage.
    """
    # Determine the value range
    if from_stage is None:
        from_value = 0
    else:
        from_value = from_stage.value

    if to_stage is None:
        to_value = VitisStage.all.value
    else:
        to_value = to_stage.value

    # Collect Vivado stages
    vivado_stages = []
    for stage in VivadoStage:
        if stage.name != "all" and from_value <= stage.value <= to_value:
            vivado_stages.append(stage)

    # Collect Vitis stages
    vitis_stages = []
    for stage in VitisStage:
        if stage.name != "all" and from_value <= stage.value <= to_value:
            vitis_stages.append(stage)

    return vivado_stages, vitis_stages


@validate_call(config=ConfigDict(strict=True))
def get_stages(
    stage_list: list[BuildStage],
) -> tuple[list[VivadoStage], list[VitisStage]]:
    """Get lists of Vivado and Vitis stages from the provided list of BuildStage values.

    Args:
        stage_list (list[BuildStage]): A list of BuildStage values to categorize into Vivado and Vitis stages.
    Returns:
        tuple[list[VivadoStage], list[VitisStage]]: A tuple containing two lists:
            - The first list contains the Vivado stages from the input list.
            - The second list contains the Vitis stages from the input list.

    Raises:
        XibifValidationError: If any item in the stage_list is not a valid BuildStage.
    """
    vivado_stages: list[VivadoStage] = []
    vitis_stages: list[VitisStage] = []

    for stage in stage_list:
        if isinstance(stage, VivadoStage):
            vivado_stages.append(stage)
        elif isinstance(stage, VitisStage):
            vitis_stages.append(stage)
        else:
            raise XibifValidationError(f"Invalid stage parameter: {stage}")

    return vivado_stages, vitis_stages
