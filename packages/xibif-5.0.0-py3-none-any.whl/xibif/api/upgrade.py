"""Upgrade API for XiBIF."""

from pydantic import validate_call, ConfigDict
from ..types import XibifPath, XibifUUID, XilinxVersion, XilinxBoard, XibifDefaults
from ..project.models import XibifSettings
from ..logger import LoggerStage as LS, xibif_print_info
from ..deps import (
    DependencyCatalog,
    DependencyContext as DC,
    DependencyGroup as DG,
)
from . import setup, register, misc

# Create dependency catalog instance
__DEPS = DependencyCatalog()


@validate_call(config=ConfigDict(strict=True, arbitrary_types_allowed=True))
def upgrade(
    board: XilinxBoard,
    xilinx_version: XilinxVersion,
    uuid: XibifUUID,
    settings: XibifSettings,
    app_name: str = XibifDefaults.APP_NAME,
    src_folder: XibifPath = XibifDefaults.HDL_SRC_FOLDER,
    tb_folder: XibifPath = XibifDefaults.HDL_TB_FOLDER,
    vitis_folder: XibifPath = XibifDefaults.VITIS_FOLDER,
    backup_folder: XibifPath = XibifDefaults.BACKUP_FOLDER,
) -> None:
    """Upgrade the VHDL and C source-files to the newest XiBIF version.

    Args:
        board (XilinxBoard): The target FPGA board for the project.
        xilinx_version (XilinxVersion): Version of the Xilinx tools.
        uuid (XibifUUID): UUID of the project, used for generating unique register files.
        settings (XibifSettings): Current project settings, used for updating the Vitis header file.
        app_name (str, optional): Name of the application folder in the Vitis workspace. Defaults to XibifDefaults.APP_NAME.
        src_folder (XibifPath, optional): Path to the new HDL source files. Defaults to XibifDefaults.HDL_SRC_FOLDER.
        tb_folder (XibifPath, optional): Path to the new HDL testbench files. Defaults to XibifDefaults.HDL_TB_FOLDER.
        vitis_folder (XibifPath, optional): Path to the Vitis workspace. Defaults to XibifDefaults.VITIS_FOLDER.
        backup_folder (XibifPath, optional): Path to store backups before upgrading. Defaults to XibifDefaults.BACKUP_FOLDER.
    """
    xibif_print_info("Starting upgrade process", stage=LS.STARTUP)

    # Define context for dependency resolution
    ctx = DC(board=board, xilinx_version=xilinx_version)

    # Generate a backup
    misc.misc_create_backup(backup_folder=backup_folder)

    # Copy the new HDL files
    xibif_print_info("Copying HDL files", stage=LS.UPGRADE_COPY_FILES)
    setup.setup_hdl_files(src_folder=src_folder, tb_folder=tb_folder)

    # Copy the new Software files
    xibif_print_info("Copying Software files", stage=LS.UPGRADE_COPY_FILES)
    __DEPS.resolve(group=DG.PS_SRC, ctx=ctx).copy(destination=vitis_folder.joinpath(app_name, "src"))
    __DEPS.resolve(group=DG.PS_HEADER, ctx=ctx).copy(destination=vitis_folder.joinpath(app_name, "src"))

    # Regenerate the header file
    xibif_print_info("Regenerate Header File", stage=LS.UPGRADE_GENERATE_HEADER)
    misc.misc_update_vitis_header_file(settings=settings)

    # Regenerate the registers
    xibif_print_info("Regenerate Registers", stage=LS.UPGRADE_GENERATE_REGISTERS)
    register.register_generate_stream(uuid=uuid)
    register.register_generate_user(uuid=uuid)
