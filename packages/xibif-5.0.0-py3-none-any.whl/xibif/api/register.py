"""Register API for XiBIF."""

import os
import hashlib
import re
import json
import yaml
from pydantic import ConfigDict, validate_call
from ..utils import get_xilinx_tool_paths
from ..shell.tools.vivado.shell import VivadoShell
from ..shell.models import ShellTool
from ..shell import ShellFactory, CommandSetFactory
from ..types import (
    XilinxVersion,
    XibifPath,
    validate_XibifPath_exist,
    XibifVersion,
    XibifUUID,
    XibifChecksum,
    XibifEnvironmentError,
    XibifInvalidPathError,
    XibifRegisterError,
    XibifDefaults,
    XibifDefaultsRegex,
)
from ..utils import get_version, igetattr
from ..logger import LoggerStage as LS, xibif_print_debug, xibif_print_info, xibif_print_warning, xibif_print_error
from ..corsair import corsair
from ..corsair import RegisterMap, Register, BitField, CorsairConfig, CorsairTarget
from ..deps import (
    DependencyCatalog,
    DependencyGroup as DG,
)

# Create dependency catalog instance
__DEPS = DependencyCatalog()


@validate_call(config=ConfigDict(strict=True))
@validate_XibifPath_exist
def register_get_checksum(
    cfg_path: XibifPath,
    reg_path: XibifPath | None = None,
) -> XibifChecksum:
    """Calculate checksum for a register configuration.

    The checksum for the register configuration can be used to validate a register configuration
    against a project file, verifying that they are compatible or have at the very least been
    generated at the same time.

    Args:
        cfg_path (XibifPath): The path to the configuration file for the register map, which defines the generator and path information for each target.
        reg_path (XibifPath | None, optional): An optional path to the register map file to use for the checksum calculation. If not provided, the register map path specified in the configuration file will be used.

    Returns:
        XibifChecksum: The calculated checksum for the register map.
    """

    # Read the configuration file and set the global configuration for corsair
    cfg = __register_read_cfg(cfg_path)
    corsair.config.set_globcfg(cfg)

    # Resolve the register map path based on the configuration and optional override
    reg_path_resolved = __register_resolve_reg_path(cfg=cfg, reg_path=reg_path)

    xibif_print_info(f"Calculating checksum for register file with config {cfg_path} and regmap {reg_path_resolved}", stage=LS.REGISTER_GET_CHECKSUM)

    # Read the register map and calculate the checksum
    regmap = __register_read_register_map(reg_path_resolved)
    checksum = XibifChecksum(hashlib.md5(str(regmap).encode()).hexdigest())
    xibif_print_debug(f"Calculated checksum: {checksum}", stage=LS.REGISTER_GET_CHECKSUM)

    return checksum


@validate_call(config=ConfigDict(strict=True))
@validate_XibifPath_exist
def register_generate_user(
    uuid: XibifUUID,
    cfg_path: XibifPath = XibifDefaults.REGISTER_USER_CFG,
    reg_path: XibifPath | None = None,
) -> None:
    """Generate register files for the user target.

    The given UUID is added to the registers to validate their existence
    during runtime.
    By default, the XiBIF default user registers are generated, which can be overwritten
    with the default parameters.

    Args:
        uuid (XibifUUID): The UUID value to set as the reset value for the UUID register in the user target.
        cfg_path (XibifPath, optional): The path to the configuration file for the user target, which defines the generator and path information for each target. Defaults to XibifDefaults.REGISTER_USER_CFG.
        reg_path (XibifPath | None, optional): An optional path to the register map file to use for the generation. If not provided, the register map path specified in the configuration file will be used.
    """
    # Read the config
    cfg = __register_read_cfg(cfg_path)
    corsair.config.set_globcfg(cfg)

    # Resolve the register map path based on the configuration and optional override
    reg_path_resolved = __register_resolve_reg_path(cfg, reg_path)

    xibif_print_info(f"Generating user register files with config {cfg_path} and regmap {reg_path_resolved}", stage=LS.REGISTER_GENERATE)

    # Read the register map
    regmap = __register_read_register_map(reg_path_resolved)

    # Add required registers if they are not already present
    regmap = __register_add_version_register(cfg, regmap, get_version())
    regmap = __register_add_uuid_register(cfg, regmap, uuid)

    # Write the updated register map back to the file
    __register_write_register_map(regmap, reg_path_resolved)

    # Update regmap path in the configuration to point to the resolved register map path
    cfg["regmap_path"] = reg_path_resolved

    # Read all targets
    targets = __register_read_target_from_cfg(cfg_path)

    # Make sure the minimum required user targets are present in the configuration and add them if they are not
    targets = __register_add_user_target_to_cfg(targets)

    # Resolve the target paths based on the configuration file location
    targets = __register_resolve_target_paths(targets, cfg)

    # Generate the targets
    __register_generate(targets, regmap)

    # Write the potentially updated configuration back to the file
    __register_write_config(targets, cfg)


@validate_call(config=ConfigDict(strict=True, arbitrary_types_allowed=True))
def register_generate_stream(
    uuid: XibifUUID,
) -> None:
    """Generate register files for the stream target.

    The given UUID is added to the register to validate their existence during runtime.

    Args:
        uuid (XibifUUID): The UUID value to set as the reset value for the UUID register in the stream target.
    """
    # Get path to the stream config file and register map file
    cfg_path = __DEPS.resolve(group=DG.CORSAIR_STREAM_CONFIG).as_path
    reg_path = __DEPS.resolve(group=DG.CORSAIR_STREAM_REGS).as_path

    xibif_print_info(f"Generating register files for stream target with config {cfg_path} and regmap {reg_path}", stage=LS.REGISTER_GENERATE)

    # Read the config
    cfg = __register_read_cfg(cfg_path)
    corsair.config.set_globcfg(cfg)

    # Read the register map
    regmap = __register_read_register_map(reg_path)

    # Add required registers if they are not already present
    regmap = __register_add_version_register(cfg, regmap, get_version())
    regmap = __register_add_uuid_register(cfg, regmap, uuid)

    # Update regmap path in the configuration to point to the resolved register map path
    cfg["regmap_path"] = reg_path

    # Read all targets
    targets = __register_read_target_from_cfg(cfg_path)

    # Make sure the minimum required stream targets are present in the configuration and add them if they are not
    targets = __register_add_stream_target_to_cfg(targets)

    # Resolve the target paths based on the configuration file location
    targets = __register_resolve_target_paths(targets, cfg)

    # Generate the targets
    __register_generate(targets, regmap)


@validate_call(config=ConfigDict(strict=True, arbitrary_types_allowed=True))
@validate_XibifPath_exist
def register_generate_custom(
    cfg_path: XibifPath,
    reg_path: XibifPath | None = None,
) -> None:
    """Generate register files for a custom target.

    Args:
        cfg_path (XibifPath): The path to the configuration file for the custom target, which defines the generator and path information for each target.
        reg_path (XibifPath | None, optional): An optional path to the register map file to use for the generation. If not provided, the register map path specified in the configuration file will be used.
    """
    # Read the config
    cfg = __register_read_cfg(cfg_path)
    corsair.config.set_globcfg(cfg)

    # Resolve the register map path based on the configuration and optional override
    reg_path_resolved = __register_resolve_reg_path(cfg, reg_path)

    xibif_print_info(f"Generating register files for custom target with config {cfg_path} and regmap {reg_path_resolved}", stage=LS.REGISTER_GENERATE)

    # Read the register map
    regmap = __register_read_register_map(reg_path_resolved)

    # Update regmap path in the configuration to point to the resolved register map path
    cfg["regmap_path"] = reg_path_resolved

    # Read all targets
    targets = __register_read_target_from_cfg(cfg_path)

    # Resolve the target paths based on the configuration file location
    targets = __register_resolve_target_paths(targets, cfg)

    # Generate the targets
    __register_generate(targets, regmap)


@validate_call(config=ConfigDict(strict=True, arbitrary_types_allowed=True))
@validate_XibifPath_exist
def register_generate_user_vivado(
    project_name: str,
    xilinx_version: XilinxVersion,
    blockdesign: str = XibifDefaults.BLOCKDESIGN_NAME,
    vivado_folder: XibifPath = XibifDefaults.VIVADO_FOLDER,
    disable_open_close: bool = False,
    runtime: VivadoShell | None = None,
    xilinx_path: XibifPath | None = None,
) -> None:
    """Update the Vivado project with the user-generated register files.

    Args:
        project_name (str): The name of the Vivado project to update.
        xilinx_version (XilinxVersion): The Xilinx version to determine the correct commands and tool paths.
        blockdesign (str, optional): The name of the block design in the Vivado project to update. Defaults to XibifDefaults.BLOCKDESIGN_NAME.
        vivado_folder (XibifPath, optional): The folder where the Vivado project is located. Defaults to XibifDefaults.VIVADO_FOLDER.
        disable_open_close (bool, optional): Whether to disable opening and closing the project in Vivado, which can be useful if this function is called multiple times in a row. Defaults to False.
        runtime (VivadoShell | None, optional): An optional VivadoShell instance to use for running the commands. If not provided, a new shell will be created. Defaults to None.
        xilinx_path (XibifPath | None, optional): An optional path to the Xilinx installation directory, required if no runtime shell is provided. Defaults to None.
    """
    xibif_print_info(f"Updating Vivado project with generated user register files for project '{project_name}' and Xilinx version {xilinx_version}", stage=LS.REGISTER_VIVADO)

    # Get commands for vivado
    commands = CommandSetFactory.get_command_set(tool=ShellTool.VIVADO, version=xilinx_version)

    # Prepare shell
    if runtime is None:
        if xilinx_path is None:
            raise XibifEnvironmentError("Xilinx path must be provided if no runtime shell is given.")

        # Open Vivado shell
        tool = ShellFactory.create_shell(tool_name=ShellTool.VIVADO, version=xilinx_version, executable=get_xilinx_tool_paths(xilinx_path=xilinx_path, xilinx_version=xilinx_version).vivado)
    else:
        tool = runtime

    # Generate some paths
    project_path = XibifDefaults.vivado_project_path(project_name=project_name, vivado_folder=vivado_folder)

    # Check if the project file exists, if not we cannot continue
    if not project_path.exists():
        raise XibifInvalidPathError(f"Vivado project file {project_path} does not exist.")

    # Update the Vivado project with the generated register files
    with tool:
        tool.logger_stage = LS.REGISTER_VIVADO

        # Open the project if it is not already open
        if not disable_open_close:
            tool.run(commands.open_project(project_path))

        # Update registers
        tool.run(commands.open_block_design(block_design_name=blockdesign))
        tool.run(commands.print_header(f"Update Blockdesign {blockdesign}"))
        tool.run(commands.update_module_reference(module_name="*XiBIF_REG_0*"))
        tool.run(commands.update_module_reference(module_name="*XiBIF_0*"))
        tool.run(commands.save_block_design(block_design_name=blockdesign))

        # Close project
        if not disable_open_close:
            xibif_print_debug(f"Closing Vivado project at {project_path}", stage=tool.logger_stage)
            tool.run(commands.close_project())


######################################################################################
# Internal helper functions for register handling
######################################################################################


@validate_call(config=ConfigDict(strict=True, arbitrary_types_allowed=True))
def __register_generate(
    target: CorsairTarget,
    regmap: RegisterMap,
) -> None:
    """Generate the register files for the selected targets based on the provided configuration and register map.

    Args:
        target (CorsairTarget): The target information read from the configuration file, containing the generator and path information for each target.
        cfg (CorsairConfig): The configuration dictionary containing the global configuration values for the register generation.
        regmap (RegisterMap): The register map containing the register and bitfield definitions to be used for the generation.
    """
    # Generate all targets
    for key, target_info in target.items():
        if "generator" not in target_info:
            xibif_print_error(f"No generator specified for target '{key}' in configuration. Skipping generation for this target.", stage=LS.NO_CHANGE)
            continue

        generator_name = target_info["generator"]

        gen_obj = igetattr(corsair.generators, generator_name, None)
        if gen_obj is None:
            xibif_print_error(f"Generator '{generator_name}' specified for target '{key}' not found in corsair generators. Skipping generation for this target.", stage=LS.NO_CHANGE)
            continue

        xibif_print_info(f"Generating target '{key}' using generator '{generator_name}' at path {target_info['path']}", stage=LS.NO_CHANGE)
        gen_obj(regmap, **target_info).generate()


@validate_call(config=ConfigDict(strict=True))
def __register_resolve_target_paths(
    targets: CorsairTarget,
    cfg: CorsairConfig,
) -> CorsairTarget:
    """Resolve the paths for the selected targets based on the provided configuration.

    Args:
        targets (CorsairTarget): The target information read from the configuration file, containing the generator and path information for each target.
        cfg (CorsairConfig): The configuration dictionary containing the global configuration values for the register generation.

    Returns:
        CorsairTarget: The updated target information with resolved paths for each target.
    """
    # Resolve all paths in the target configuration to absolute paths based on the configuration file location
    cfg_path = XibifPath(cfg["config_path"]).resolve()
    xibif_print_debug(f"Resolving target paths based on configuration path {cfg_path}", stage=LS.NO_CHANGE)

    for key, target_info in targets.items():
        if "path" in target_info:
            if not XibifPath(target_info["path"]).is_absolute():
                target_info["path"] = (cfg_path.parent.joinpath(target_info["path"])).resolve()
                xibif_print_debug(f"Resolved path for target '{key}': {target_info['path']}", stage=LS.NO_CHANGE)

    return targets


@validate_call(config=ConfigDict(strict=True))
@validate_XibifPath_exist
def __register_add_user_target_to_cfg(
    targets: CorsairTarget,
    app_name: str = XibifDefaults.APP_NAME,
    src_folder: XibifPath = XibifDefaults.HDL_SRC_FOLDER,
    vitis_folder: XibifPath = XibifDefaults.VITIS_FOLDER,
) -> CorsairConfig:
    """Add a user target to the configuration if it does not already exist, and set the paths and settings for the generated files.

    Args:
        targets (CorsairTarget): The current targets read from the configuration file.
        app_name (str, optional): The name of the application to use for the generated files. Defaults to XibifDefaults.APP_NAME.
        src_folder (XibifPath, optional): The folder where the generated HDL files should be placed. Defaults to XibifDefaults.HDL_SRC_FOLDER.
        vitis_folder (XibifPath, optional): The folder where the generated Vitis files should be placed. Defaults to XibifDefaults.VITIS_SRC_FOLDER.

    Returns:
        CorsairConfig: The updated configuration with the user target added if it did not already exist, or the original configuration if it already existed.
    """
    xibif_print_debug(f"Adding user target to configuration if not already present. Current targets: {targets}", stage=LS.NO_CHANGE)

    # Overwrite the required targets to ensure that everything is generated correctly for the user target
    targets["vhdl"] = {"read_filler": 0, "interface": "axil", "generator": "vhdl", "path": str(XibifDefaults.register_user_vhdl_path(src_folder=src_folder))}
    targets["c_header"] = {
        "prefix": "XIBIF_REG",
        "add_json": "True",
        "generator": "CHeader",
        "path": str(XibifDefaults.register_user_header_path(app_name=app_name, vitis_folder=vitis_folder)),
    }

    return targets


@validate_call(config=ConfigDict(strict=True))
@validate_XibifPath_exist
def __register_add_stream_target_to_cfg(
    targets: CorsairTarget,
    app_name: str = XibifDefaults.APP_NAME,
    src_folder: XibifPath = XibifDefaults.HDL_SRC_FOLDER,
    tb_folder: XibifPath = XibifDefaults.HDL_TB_FOLDER,
    vitis_folder: XibifPath = XibifDefaults.VITIS_FOLDER,
) -> CorsairConfig:
    """Add a stream target to the configuration if it does not already exist, and set the paths and settings for the generated files.

    Args:
        targets (CorsairTarget): The current targets read from the configuration file.
        app_name (str, optional): The name of the application to use for the generated files. Defaults to XibifDefaults.APP_NAME.
        src_folder (XibifPath, optional): The folder where the generated HDL files should be placed. Defaults to XibifDefaults.HDL_SRC_FOLDER.
        tb_folder (XibifPath, optional): The folder where the generated HDL testbench files should be placed. Defaults to XibifDefaults.HDL_TB_FOLDER.
        vitis_folder (XibifPath, optional): The folder where the generated Vitis files should be placed. Defaults to XibifDefaults.VITIS_SRC_FOLDER.

    Returns:
        CorsairConfig: The updated configuration with the stream target added if it did not already exist, or the original configuration if it already existed.
    """
    xibif_print_debug(f"Adding stream target to configuration if not already present. Current targets: {targets}", stage=LS.NO_CHANGE)

    # Overwrite the required targets to ensure that everything is generated correctly for the user target
    targets["vhdl"] = {"read_filler": 0, "interface": "axil", "generator": "vhdl", "path": str(XibifDefaults.register_stream_vhdl_path(src_folder=src_folder))}
    targets["vhdl_package"] = {
        "module_name": "XiBIF_stream_regs",
        "generator": "VhdlPackage",
        "path": str(XibifDefaults.register_stream_package_path(tb_folder=tb_folder)),
    }
    targets["c_header"] = {
        "prefix": "XIBIF_SREG",
        "add_json": "False",
        "generator": "CHeader",
        "path": str(XibifDefaults.register_stream_header_path(app_name=app_name, vitis_folder=vitis_folder)),
    }

    return targets


@validate_call(config=ConfigDict(strict=True, arbitrary_types_allowed=True))
def __register_add_version_register(
    cfg: CorsairConfig,
    regmap: RegisterMap,
    version: XibifVersion,
) -> RegisterMap:
    """Add a version register with the provided version as reset value if it does not already exist.

    Args:
        cfg (CorsairConfig): The current configuration dictionary.
        regmap (RegisterMap): The current register map to add the version register to if it does not already exist.
        version (XibifVersion): The version value to set as the reset value for the version register.

    Returns:
        RegisterMap: The updated register map with the version register added if it did not already exist, or the original register map if it already existed.
    """
    index = __register_find_register_idx_by_name(regmap, "version")
    if index is None:
        addr = __register_get_next_free_reg_address(cfg, regmap)

        version_reg = Register(
            name="version",
            description="Version Register",
            address=addr,
            data_width=cfg["data_width"],
        )
        major_field = BitField(
            name="maj",
            description="Major Version ID",
            reset=0,
            width=8,
            lsb=24,
            access="ro",
            hardware="n",
        )
        minor_field = BitField(
            name="min",
            description="Minor Version ID",
            reset=0,
            width=8,
            lsb=16,
            access="ro",
            hardware="n",
        )
        patch_field = BitField(
            name="patch",
            description="Patch ID",
            reset=0,
            width=8,
            lsb=8,
            access="ro",
            hardware="n",
        )
        revis_field = BitField(
            name="rev",
            description="Revision ID",
            reset=0,
            width=8,
            lsb=0,
            access="ro",
            hardware="n",
        )
        version_reg.add_bitfields([major_field, minor_field, patch_field, revis_field])
        regmap.add_registers(version_reg)
        index = __register_find_register_idx_by_name(regmap, "version")  # Recalculate the index after adding the register
        xibif_print_warning(f"Creating register 'version' at address {addr}.", stage=LS.NO_CHANGE)

    # set the reset value to the provided version
    xibif_print_debug(f"Set 'version' register reset value to {version}", stage=LS.NO_CHANGE)
    regmap.regs[index].bitfields[0].reset = version.revision
    regmap.regs[index].bitfields[1].reset = version.patch
    regmap.regs[index].bitfields[2].reset = version.minor
    regmap.regs[index].bitfields[3].reset = version.major

    return regmap


@validate_call(config=ConfigDict(strict=True, arbitrary_types_allowed=True))
def __register_add_uuid_register(
    cfg: CorsairConfig,
    regmap: RegisterMap,
    uuid: XibifUUID,
) -> RegisterMap:
    """Add a UUID register with the provided uuid as reset value if it does not already exist.

    Args:
        cfg (CorsairConfig): The current configuration dictionary.
        regmap (RegisterMap): The current register map to add the UUID register to if it does not already exist.
        uuid (XibifUUID): The UUID value to set as the reset value for the UUID register.

    Returns:
        RegisterMap: The updated register map with the UUID register added if it did not already exist, or the original register map if it already existed.
    """
    index = __register_find_register_idx_by_name(regmap, "UUID")
    if index is None:
        addr = __register_get_next_free_reg_address(cfg, regmap)

        uuid_reg = Register(
            name="UUID",
            description="UUID Register",
            address=addr,
            data_width=cfg["data_width"],
        )
        uuid_field = BitField(
            name="uuid",
            description="UUID",
            reset=0,
            width=32,
            lsb=0,
            access="ro",
            hardware="n",
        )
        uuid_reg.add_bitfields([uuid_field])
        regmap.add_registers(uuid_reg)
        index = __register_find_register_idx_by_name(regmap, "version")  # Recalculate the index after adding the register
        xibif_print_warning(f"Creating register 'UUID' at address {addr}.", stage=LS.NO_CHANGE)

    # set the reset value to the provided uuid
    xibif_print_debug(f"Set 'UUID' register reset value to {uuid}", stage=LS.NO_CHANGE)
    regmap.regs[index].bitfields[0].reset = uuid.uuid

    return regmap


@validate_call(config=ConfigDict(strict=True, arbitrary_types_allowed=True))
def __register_find_register_idx_by_name(
    regmap: RegisterMap,
    name: str,
) -> int | None:
    """Find the index of a register in the register map by its name.

    Args:
        regmap (RegisterMap): The register map to search.
        name (str): The name of the register to find.

    Returns:
        int | None: The index of the register if found, otherwise None.
    """
    index = next((i for i, r in enumerate(regmap.regs) if r.name == name), None)
    if index is None:
        xibif_print_warning(f"Register '{name}' not found in register map.", stage=LS.NO_CHANGE)
        xibif_print_debug(f"Available registers: {[r.name for r in regmap.regs]}", stage=LS.NO_CHANGE)
    return index


@validate_call(config=ConfigDict(strict=True, arbitrary_types_allowed=True))
def __register_get_next_free_reg_address(
    cfg: CorsairConfig,
    regmap: RegisterMap,
) -> int:
    """Calculate the next free register address based on the current register map and the address alignment specified in the configuration.

    Args:
        cfg (CorsairConfig): The configuration dictionary containing the address alignment information.
        regmap (RegisterMap): The current register map to determine the next free address.

    Returns:
        int: The next free register address.

    Raises:
        XibifRegisterError: If the address alignment information is missing or invalid in the configuration.
    """
    if (address_alignment := cfg.get("address_alignment", None)) is None:
        raise XibifRegisterError("No 'address_alignment' entry found in the configuration file.")

    # Calculate the multiplier
    if address_alignment == "data_width":
        if "data_width" not in cfg:
            raise XibifRegisterError("Address alignment is set to 'data_width' but no 'data_width' entry found in the configuration file.")

        multiplier = int(cfg["data_width"] / 8)

    elif isinstance(address_alignment, int):
        multiplier = address_alignment

    else:
        multiplier = 1

    xibif_print_debug(f"Calculating next free register address with address_alignment='{address_alignment}' and current number of registers={len(regmap.regs)}", stage=LS.NO_CHANGE)

    # Loop until we find an address that is not already used by a register, taking into account the address alignment
    addr = 0
    while any(r.address == addr for r in regmap.regs):
        addr += multiplier

    xibif_print_debug(f"Next free register address calculated: {addr}", stage=LS.NO_CHANGE)
    return addr


@validate_call(config=ConfigDict(strict=True))
@validate_XibifPath_exist
def __register_resolve_reg_path(
    cfg: CorsairConfig,
    reg_path: XibifPath | None = None,
) -> XibifPath:
    """Resolve the register map path based on the provided configuration and optional override.

    Args:
        cfg (CorsairConfig): The configuration dictionary containing potential register map path information.
        reg_path (XibifPath | None, optional): An optional override for the register map path. If None, the path will be resolved from the configuration. Defaults to None.

    Returns:
        XibifPath: The resolved register map path.

    Raises:
        XibifInvalidPathError: If the resolved register map path does not exist.
    """
    # If no register map path is provided, use the one from the configuration file
    xibif_print_debug(f"Resolving register map path with provided reg_path='{reg_path}' and configuration cfg={cfg}", stage=LS.NO_CHANGE)
    if reg_path is None:
        if "regmap_path" in cfg:
            reg_path = XibifPath(cfg["regmap_path"])

            if not reg_path.is_absolute():
                reg_path = XibifPath(cfg["config_path"]).parent.joinpath(cfg["regmap_path"])

            if not reg_path.exists():
                raise XibifInvalidPathError(f"Register map path provided in configuration file does not exist: {reg_path}")
        else:
            raise XibifInvalidPathError("No register map path provided and no 'regmap_path' entry found in the configuration file.")

    xibif_print_debug(f"Resolved register map path: {reg_path}", stage=LS.NO_CHANGE)
    return reg_path


@validate_call(config=ConfigDict(strict=True))
@validate_XibifPath_exist
def __register_read_cfg(
    config_path: XibifPath,
) -> CorsairConfig:
    """Read the configuration file and return it as a dictionary.

    Args:
        config_path (XibifPath): The path to the configuration file.

    Returns:
        CorsairConfig: The configuration as a dictionary.

    Raises:
        XibifRegisterError: If the configuration is invalid.
    """
    # Read config and save the config path in the config for later use
    cfg, _ = corsair.config.read_csrconfig(config_path)
    cfg["config_path"] = str(config_path)

    xibif_print_debug(f"Read configuration from {config_path}: {cfg}", stage=LS.NO_CHANGE)

    # Validate the configuration and raise an error if it is invalid
    if not __register_validate_config(cfg):
        raise XibifRegisterError(f"Configuration read from file {config_path} is invalid. Please check the configuration values and types.")
    return cfg


@validate_call(config=ConfigDict(strict=True))
@validate_XibifPath_exist
def __register_read_target_from_cfg(
    config_path: XibifPath,
) -> CorsairTarget:
    """Read the target information from the configuration file.

    Args:
        config_path (XibifPath): The path to the configuration file.

    Returns:
        CorsairTarget: The target information read from the configuration file.
    """
    _, targets = corsair.config.read_csrconfig(config_path)
    xibif_print_debug(f"Read targets from configuration {config_path}: {targets}", stage=LS.NO_CHANGE)
    return targets


@validate_call(config=ConfigDict(strict=True, arbitrary_types_allowed=True))
@validate_XibifPath_exist
def __register_read_register_map(
    regmap_path: XibifPath,
) -> RegisterMap:
    """Read the register map from the given file path.

    Args:
        regmap_path (XibifPath): The path to the register map file.

    Returns:
        RegisterMap: The register map read from the file.

    Raises:
        XibifRegisterError: If there is an error reading the register map from the file, or if the register map is invalid.
    """
    regmap = RegisterMap()
    try:
        regmap.read_file(regmap_path)
    except ValueError as e:
        raise XibifRegisterError(f"Cannot read register map from file {regmap_path}.") from e

    # Validate the register map and raise an error if it is invalid
    if not __register_validate_register_map(regmap):
        raise XibifRegisterError(f"Register map read from file {regmap_path} is invalid. Please check the register and bitfield names for illegal characters.")

    return regmap


@validate_call(config=ConfigDict(strict=True, arbitrary_types_allowed=True))
@validate_XibifPath_exist
def __register_write_register_map(
    regmap: RegisterMap,
    regmap_path: XibifPath,
) -> None:
    """Write the register map to the given file path.

    Args:
        regmap (RegisterMap): The register map to write to the file.
        regmap_path (XibifPath): The path to the register map file.
    """
    # Prepare data
    data = {"regmap": list(regmap.as_dict().values())}

    # Write the register map to the file
    if regmap_path.suffix == ".json":
        with open(regmap_path, "w") as f:
            json.dump(data, f, indent=4)
    elif regmap_path.suffix in [".yaml", ".yml"]:
        with open(regmap_path, "w") as f:
            yaml.dump(data, f)
    else:
        raise XibifRegisterError(f"Unsupported register map file format for file {regmap_path}. Supported formats are .json, .yaml and .yml.")

    xibif_print_info(f"Written register map to {regmap_path}", stage=LS.NO_CHANGE)


@validate_call(config=ConfigDict(strict=True))
def __register_write_config(
    targets: CorsairTarget,
    cfg: CorsairConfig,
) -> None:
    """
    Update the corsair configuration file for the selected targets with a path that is relative to the project root
    """
    # Make all paths in the target configuration relative to the configuration file location if they are on the same drive, otherwise keep them absolute
    cfg_path = XibifPath(cfg["config_path"])

    for t in targets:
        target_path = XibifPath(targets[t]["path"])
        if target_path.drive == cfg_path.parent.drive:
            targets[t]["path"] = os.path.relpath(target_path, start=cfg_path.parent).replace("\\", "/")
        else:
            targets[t]["path"] = str(target_path.resolve()).replace("\\", "/")
        xibif_print_debug(f"Resolved path for target '{t}': {targets[t]['path']}", stage=LS.NO_CHANGE)

    # make the regmap path relative to the configuration file location if it is on the same drive, otherwise keep it absolute
    regmap_path = XibifPath(cfg["regmap_path"])
    if regmap_path.drive == cfg_path.parent.drive:
        cfg["regmap_path"] = os.path.relpath(regmap_path, start=cfg_path.parent).replace("\\", "/")
    else:
        cfg["regmap_path"] = str(regmap_path.resolve()).replace("\\", "/")
    xibif_print_debug(f"Resolved register map path: {cfg['regmap_path']}", stage=LS.NO_CHANGE)

    # Remove config_path from cfg before writing, as it is only used internally and should not be part of the actual configuration file
    cfg.pop("config_path", None)

    # Write the updated configuration back to the file
    corsair.config.write_csrconfig(cfg_path, cfg, targets)

    xibif_print_info(f"Written updated configuration to {cfg_path}", stage=LS.NO_CHANGE)


@validate_call(config=ConfigDict(strict=True))
def __register_validate_config(
    cfg: CorsairConfig,
) -> bool:
    """Validate the configuration by checking for required fields and their types.

    Args:
        cfg (CorsairConfig): The configuration to validate.

    Returns:
        bool: True if the configuration is valid, False otherwise.
    """
    xibif_print_info("Validating configuration...", stage=LS.NO_CHANGE)
    # Check that the data_width is exactly 32
    if cfg["data_width"] not in [32, 64]:
        xibif_print_error(f"Invalid data_width '{cfg['data_width']}' in configuration! Only 32 and 64 are supported.", stage=LS.NO_CHANGE)
        return False

    return True


@validate_call(config=ConfigDict(strict=True, arbitrary_types_allowed=True))
def __register_validate_register_map(
    regmap: RegisterMap,
) -> bool:
    """Validate the register map by checking that all register, bitfield, and enum names conform to the specified naming rules.

    Args:
        regmap (RegisterMap): The register map to validate.

    Returns:
        bool: True if the register map is valid, False otherwise.
    """
    xibif_print_info("Validating register names...", stage=LS.NO_CHANGE)
    name_pattern = re.compile(XibifDefaultsRegex.REGISTER_NAME)

    def is_valid_name(name: str) -> bool:
        return bool(name_pattern.match(name))

    regs_dict = regmap.as_dict()

    for reg_name, reg in regs_dict.items():
        if not is_valid_name(reg_name):
            xibif_print_error(f"Register name '{reg_name}' contains illegal characters! Used Regexpattern = {XibifDefaultsRegex.REGISTER_NAME}", stage=LS.NO_CHANGE)
            return False

        for bitfield in reg["bitfields"]:
            bitfield_name = bitfield["name"]
            if not is_valid_name(bitfield_name):
                xibif_print_error(
                    f"Bitfield name '{bitfield_name}' of register '{reg_name}' contains illegal characters! Used Regexpattern = {XibifDefaultsRegex.REGISTER_NAME}",
                    stage=LS.NO_CHANGE,
                )
                return False

            for enum in bitfield["enums"]:
                enum_name = enum["name"]
                if not is_valid_name(enum_name):
                    xibif_print_error(f"Enum name '{enum_name}' of register '{reg_name}' contains illegal characters! Used Regexpattern = {XibifDefaultsRegex.REGISTER_NAME}", stage=LS.NO_CHANGE)
                    return False

    xibif_print_info("Register names are valid.", stage=LS.NO_CHANGE)
    return True
