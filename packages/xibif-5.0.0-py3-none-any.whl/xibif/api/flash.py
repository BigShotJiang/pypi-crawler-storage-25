"""Flash API for XiBIF."""

import time
from typing import Annotated
from pydantic import ConfigDict, Field, validate_call
from pydantic.networks import IPvAnyAddress
from ..utils import get_clean_shell, get_clean_shell_batch_command, get_xilinx_tool_paths
from ..shell.tools.vitis.shell import VitisShell
from ..shell.models import ShellTool
from ..shell import ShellFactory, CommandSetFactory
from ..types import XilinxBoard, XilinxVersion, XibifPath, validate_XibifPath_exist, XibifEnvironmentError, XibifInvalidPathError, XibifDefaults
from ..logger import LoggerStage as LS, xibif_print_debug, xibif_print_info, xibif_print_warning
from ..deps import (
    DependencyCatalog,
    DependencyContext as DC,
    DependencyGroup as DG,
)

# Create dependency catalog instance
__DEPS = DependencyCatalog()


@validate_call(config=ConfigDict(strict=True, arbitrary_types_allowed=True))
@validate_XibifPath_exist
def flash_hardware_server(
    project_name: str,
    board: XilinxBoard,
    xilinx_version: XilinxVersion,
    ip: IPvAnyAddress = "127.0.0.1",
    port: Annotated[int, Field(ge=1, le=65535)] = 3121,
    app_name: str = XibifDefaults.APP_NAME,
    results_folder: XibifPath = XibifDefaults.RESULTS_FOLDER,
    runtime: VitisShell | None = None,
    xilinx_path: XibifPath | None = None,
):
    """Flash an application to the FPGA.

    Flashes an application file (defaults to generated project application) to an FPGA using
    Xilinx Hardware Server. The server may run locally or remote, if so, the IP of the remote
    host must be specified.

    Note that the flashed application does not persist on the FPGA and is no longer available after
    a reboot.

    Args:
        project_name (str): The name of the project to flash.
        board (XilinxBoard): The target board for flashing.
        xilinx_version (XilinxVersion): The Xilinx version used for the project.
        ip (IPvAnyAddress, optional): The IP address of the hardware server. Defaults to '127.0.0.1'.
        port (int, optional): The port number of the hardware server. Defaults to 3121.
        app_name (str, optional): The name of the application to flash. Defaults to XibifDefaults.APP_NAME.
        results_folder (XibifPath, optional): The folder where the build results are located. Defaults to XibifDefaults.RESULTS_FOLDER.
        runtime (VitisShell | None, optional): An optional VitisShell instance to use for flashing. If None, a new shell will be created. Defaults to None.
        xilinx_path (XibifPath | None, optional): The path to the Xilinx tools installation. Required if runtime is None. Defaults to None.

    Raises:
        XibifEnvironmentError: If no runtime shell is provided and the Xilinx path is not given.
        XibifInvalidPathError: If any of the required files for flashing do not exist or are outdated.
    """

    xibif_print_info(f"Flashing XiBIF project {project_name} to hardware.", stage=LS.FLASH_GENERAL)

    # Get commands for vitis
    commands = CommandSetFactory.get_command_set(tool=ShellTool.VITIS_FLASH, version=xilinx_version)

    # Define context for dependency resolution
    ctx = DC(board=board, xilinx_version=xilinx_version)

    # Prepare shell
    if runtime is None:
        if xilinx_path is None:
            raise XibifEnvironmentError("Xilinx path must be provided if no runtime shell is given.")

        # Open Vitis shell
        tool = ShellFactory.create_shell(
            tool_name=ShellTool.VITIS_FLASH,
            version=xilinx_version,
            executable=get_xilinx_tool_paths(xilinx_path=xilinx_path, xilinx_version=xilinx_version).xsct,
            interpreter=get_clean_shell(__DEPS.resolve(group=DG.PS_SHELL, ctx=ctx).as_path),
            precommand=get_clean_shell_batch_command(get_xilinx_tool_paths(xilinx_path=xilinx_path, xilinx_version=xilinx_version).settings64_script),
        )
    else:
        tool = runtime

    # Generate some paths
    bitstream_path = XibifDefaults.vivado_bitstream_path(project_name=project_name, results_folder=results_folder)
    fsbl_path = XibifDefaults.vitis_fsbl_path(results_folder=results_folder)
    app_path = XibifDefaults.vitis_app_elf_path(app_name=app_name, results_folder=results_folder)
    hardware_path = XibifDefaults.vivado_hardware_path(project_name=project_name, results_folder=results_folder)

    # Check that the required files for flashing exist and are not too old
    if not bitstream_path.exists():
        raise XibifInvalidPathError(f"Bitstream file {bitstream_path} does not exist. Run the Vivado build stage to generate it before generating the bootfile.")

    if bitstream_path.stat().st_mtime < (time.time() - 3600):
        xibif_print_warning(f"Bitstream file {bitstream_path} is older than one hour!", stage=LS.FLASH_GENERAL)
        xibif_print_debug(f"Bitstream file timestamp: {bitstream_path.stat().st_mtime}", stage=LS.FLASH_GENERAL)

    if not hardware_path.exists():
        raise XibifInvalidPathError(f"Hardware XSA file {hardware_path} does not exist. Run the Vivado build stage to generate it before generating the bootfile.")

    if hardware_path.stat().st_mtime < (time.time() - 3600):
        xibif_print_warning(f"Hardware XSA file {hardware_path} is older than one hour!", stage=LS.FLASH_GENERAL)
        xibif_print_debug(f"Hardware XSA file timestamp: {hardware_path.stat().st_mtime}", stage=LS.FLASH_GENERAL)

    if not fsbl_path.exists():
        raise XibifInvalidPathError(f"FSBL ELF file {fsbl_path} does not exist. Run the Vitis build stage to generate it before generating the bootfile.")

    if fsbl_path.stat().st_mtime < (time.time() - 3600):
        xibif_print_warning(f"FSBL ELF file {fsbl_path} is older than one hour!", stage=LS.FLASH_GENERAL)
        xibif_print_debug(f"FSBL ELF file timestamp: {fsbl_path.stat().st_mtime}", stage=LS.FLASH_GENERAL)

    if not app_path.exists():
        raise XibifInvalidPathError(f"Application ELF file {app_path} does not exist. Run the Vitis build stage to generate it before generating the bootfile.")

    if app_path.stat().st_mtime < (time.time() - 3600):
        xibif_print_warning(f"Application ELF file {app_path} is older than one hour!", stage=LS.FLASH_GENERAL)
        xibif_print_debug(f"Application ELF file timestamp: {app_path.stat().st_mtime}", stage=LS.FLASH_GENERAL)

    # Flash the hardware
    with tool:
        tool.logger_stage = LS.FLASH_CONNECT
        tool.run(commands.connect_hwserver(hw_server=ip, port=port))
        tool.logger_stage = LS.FLASH_FLASH
        tool.run(commands.flash(board=board, hardware_path=hardware_path, fsbl_path=fsbl_path, bitstream_path=bitstream_path, elf_path=app_path))
        tool.logger_stage = LS.FLASH_PS
        tool.run(commands.connect_ps())
        tool.run(commands.disconnect())
