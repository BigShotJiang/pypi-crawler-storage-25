"""Build API for Vivado and Vitis project generation."""

import json
import xml.etree.ElementTree as ET
import time
import os
import shutil
from pydantic import ConfigDict, validate_call
from ..utils import get_clean_shell, get_clean_shell_batch_command, get_xilinx_tool_paths
from ..shell.tools.vivado.shell import VivadoShell
from ..shell.tools.vitis.shell import VitisShell
from ..shell.models import ShellTool
from ..shell import ShellFactory, CommandSetFactory
from ..types import XilinxBoard, XilinxVersion, XibifPath, validate_XibifPath_exist, XibifEnvironmentError, XibifGeneratedFileError, XibifInvalidPathError, XibifTimeoutError, XibifDefaults
from .build_stages import VivadoStage, VitisStage
from ..logger import LoggerStage as LS, xibif_print_debug, xibif_print_info, xibif_print_warning
from .misc import misc_create_backup
from .setup import setup_vitis_project
from ..deps import (
    DependencyCatalog,
    DependencyContext as DC,
    DependencyGroup as DG,
)

# Create dependency catalog instance
__DEPS = DependencyCatalog()


@validate_call(config=ConfigDict(strict=True, arbitrary_types_allowed=True))
@validate_XibifPath_exist
def build_vivado(
    project_name: str,
    xilinx_version: XilinxVersion,
    stages: list[VivadoStage] | None = None,
    blockdesign: str = XibifDefaults.BLOCKDESIGN_NAME,
    vivado_folder: XibifPath = XibifDefaults.VIVADO_FOLDER,
    results_folder: XibifPath = XibifDefaults.RESULTS_FOLDER,
    synthesize_run: str = XibifDefaults.SYNTHESIS_NAME,
    implementation_run: str = XibifDefaults.IMPLEMENTATION_NAME,
    disable_report: bool = False,
    disable_open_close: bool = False,
    runtime: VivadoShell | None = None,
    xilinx_path: XibifPath | None = None,
) -> None:
    """Build a Vivado project.

    Builds a Vivado project for the specified project name with the specified Xilinx version.
    If specific build stages are specified, only these stages are executed. When no stages are
    specified, the complete Vivado flow is executed.


    Args:
        project_name (str): The name of the project to build.
        xilinx_version (XilinxVersion): The version of the Xilinx tools to use for the build.
        stages (list[VivadoStage] | None): The stages of the build process to execute. If None, all stages will be executed.
        blockdesign (str): The name of the block design to build. Default is XibifDefaults.BLOCKDESIGN_NAME.
        vivado_folder (XibifPath): The folder where the Vivado project is located. Default is XibifDefaults.VIVADO_FOLDER.
        results_folder (XibifPath): The folder where the build results will be stored. Default is XibifDefaults.RESULTS_FOLDER.
        synthesize_run (str): The name of the synthesis run. Default is XibifDefaults.SYNTHESIS_NAME.
        implementation_run (str): The name of the implementation run. Default is XibifDefaults.IMPLEMENTATION_NAME.
        disable_report (bool): Whether to disable the generation of reports during the build process. Default is False.
        disable_open_close (bool): Whether to disable opening and closing the Vivado project during the build process. Default is False.
        runtime (VivadoShell | None): An optional VivadoShell instance to use for executing the build commands. If None, a new shell will be created. Default is None.
        xilinx_path (XibifPath | None): The path to the Xilinx tools installation. Required if runtime is None. Default is None.
    """

    xibif_print_info(f"Build Vivado project {project_name} with Xilinx version {xilinx_version.value}.", stage=LS.BUILD_VIVADO_GENERAL)

    # Get commands for vivado
    commands = CommandSetFactory.get_command_set(tool=ShellTool.VIVADO, version=xilinx_version)

    # Prepare shell
    if runtime is None:
        if xilinx_path is None:
            raise XibifEnvironmentError("Xilinx path must be provided if no runtime shell is given.")

        # Open Vivado shell
        tool = ShellFactory.create_shell(
            tool_name=ShellTool.VIVADO,
            version=xilinx_version,
            executable=get_xilinx_tool_paths(xilinx_path=xilinx_path, xilinx_version=xilinx_version).vivado,
        )
    else:
        tool = runtime

    # Prepare build stages
    if stages is None:
        stages = list(VivadoStage)
    elif VivadoStage.all in stages:
        stages = list(VivadoStage)
    xibif_print_debug(f"Vivado build stages: {[stage.value for stage in stages]}", stage=LS.BUILD_VIVADO_GENERAL)

    # Generate some paths
    hardware_path = XibifDefaults.vivado_hardware_path(project_name=project_name, results_folder=results_folder)
    bitstream_path = XibifDefaults.vivado_bitstream_path(project_name=project_name, results_folder=results_folder)
    ltx_path = XibifDefaults.vivado_ltx_path(project_name=project_name, results_folder=results_folder)
    project_path = XibifDefaults.vivado_project_path(project_name=project_name, vivado_folder=vivado_folder)
    full_synth_name = f"{project_name}_{synthesize_run}_synth"
    full_impl_name = f"{project_name}_{implementation_run}_impl"
    checkpoint_synth_path = XibifDefaults.vivado_checkpoint_path(checkpoint_name=full_synth_name, results_folder=results_folder)
    checkpoint_impl_path = XibifDefaults.vivado_checkpoint_path(checkpoint_name=full_impl_name, results_folder=results_folder)
    report_synth_path = list(results_folder.glob(f"{full_synth_name}*.rpt"))
    report_impl_path = list(results_folder.glob(f"{full_impl_name}*.rpt"))

    # Check if the project file exists, if not we cannot continue
    if not project_path.exists():
        raise XibifInvalidPathError(f"Vivado project file {project_path} does not exist.")

    # Check if output files already exist and remove them if necessary
    if VivadoStage.synthesize in stages:
        if checkpoint_synth_path.exists():
            checkpoint_synth_path.unlink()  # Remove old synthesis checkpoint
            xibif_print_debug(f"Removed old synthesis checkpoint at {checkpoint_synth_path}", stage=LS.BUILD_VIVADO_GENERAL)

        for report in report_synth_path:
            report.unlink()  # Remove old synthesis reports
            xibif_print_debug(f"Removed old synthesis report at {report}", stage=LS.BUILD_VIVADO_GENERAL)

    if VivadoStage.implement in stages:
        if checkpoint_impl_path.exists():
            checkpoint_impl_path.unlink()  # Remove old implementation checkpoint
            xibif_print_debug(f"Removed old implementation checkpoint at {checkpoint_impl_path}", stage=LS.BUILD_VIVADO_GENERAL)

        for report in report_impl_path:
            report.unlink()  # Remove old implementation reports
            xibif_print_debug(f"Removed old implementation report at {report}", stage=LS.BUILD_VIVADO_GENERAL)

    if VivadoStage.bitstream in stages:
        if bitstream_path.exists():
            bitstream_path.unlink()  # Remove old bitstream
            xibif_print_debug(f"Removed old bitstream at {bitstream_path}", stage=LS.BUILD_VIVADO_GENERAL)

        if ltx_path.exists():
            ltx_path.unlink()  # Remove old ltx file
            xibif_print_debug(f"Removed old ltx file at {ltx_path}", stage=LS.BUILD_VIVADO_GENERAL)

    if VivadoStage.export in stages:
        if hardware_path.exists():
            hardware_path.unlink()  # Remove old hardware description
            xibif_print_debug(f"Removed old hardware description at {hardware_path}", stage=LS.BUILD_VIVADO_GENERAL)

    # Run build stages
    with tool:

        # Open project
        tool.logger_stage = LS.BUILD_VIVADO_STARTUP
        if not disable_open_close:
            xibif_print_debug(f"Opening Vivado project at {project_path}", stage=tool.logger_stage)
            tool.run(commands.open_project(project_path=project_path))

        # Generate block design
        tool.logger_stage = LS.BUILD_VIVADO_BLOCKDESIGN
        if VivadoStage.blockdesign in stages:
            xibif_print_debug(f"Generating block design {blockdesign}", stage=tool.logger_stage)
            tool.run(commands.update_all_module_references(block_design_name=blockdesign))
            tool.run(commands.recreate_wrapper(block_design_name=blockdesign))

        # Synthesize
        tool.logger_stage = LS.BUILD_VIVADO_SYNTHESIZE
        if VivadoStage.synthesize in stages:
            xibif_print_debug(f"Running synthesis for run {synthesize_run}", stage=tool.logger_stage)
            tool.run(commands.synthesize(run=synthesize_run, noopen=disable_report))

            if not disable_report:
                xibif_print_debug(f"Writing synthesis checkpoint to {checkpoint_synth_path}", stage=tool.logger_stage)
                tool.run(commands.write_checkpoint(checkpoint_path=checkpoint_synth_path))
                tool.run(commands.report_all(prefix=full_synth_name, report_path=results_folder))

        # Implement
        tool.logger_stage = LS.BUILD_VIVADO_IMPLEMENTATION
        if VivadoStage.implement in stages and VivadoStage.bitstream in stages:
            xibif_print_debug(f"Running implementation and bitstream generator for run {implementation_run}", stage=tool.logger_stage)
            tool.run(commands.implement(run=implementation_run, to_bitstream=True, noopen=disable_report))
        elif VivadoStage.implement in stages:
            xibif_print_debug(f"Running implementation for run {implementation_run}", stage=tool.logger_stage)
            tool.run(commands.implement(run=implementation_run, to_bitstream=False, noopen=disable_report))

        if VivadoStage.implement in stages:
            if not disable_report:
                xibif_print_debug(f"Writing implementation checkpoint to {checkpoint_impl_path}", stage=tool.logger_stage)
                tool.run(commands.write_checkpoint(checkpoint_path=checkpoint_impl_path))
                tool.run(commands.report_all(prefix=full_impl_name, report_path=results_folder))

        # Bitstream
        tool.logger_stage = LS.BUILD_VIVADO_BITSTREAM
        if VivadoStage.bitstream in stages and VivadoStage.implement not in stages:
            xibif_print_debug(f"Running bitstream generation for run {implementation_run}", stage=tool.logger_stage)
            tool.run(commands.implement(run=implementation_run, noopen=disable_report))

        if VivadoStage.bitstream in stages:
            tool.run(commands.write_bitstream(bitstream_path=bitstream_path, run=implementation_run))  # Copy the generated bitstream to the results folder

        # Export hardware design
        tool.logger_stage = LS.BUILD_VIVADO_EXPORT
        if VivadoStage.export in stages:
            xibif_print_debug(f"Exporting hardware design to {hardware_path}", stage=tool.logger_stage)
            tool.run(commands.export_hardware(hardware_path=hardware_path, include_bitstream=True))

        # Report timing
        tool.logger_stage = LS.BUILD_VIVADO_TIMING
        if VivadoStage.reportTiming in stages:
            xibif_print_debug(f"Generating timing report for run {implementation_run}", stage=tool.logger_stage)
            if disable_report:
                xibif_print_warning("Timing report generation was requested but disable_report was set. Skipping timing report generation.", stage=tool.logger_stage)
            else:
                tool.run(commands.report_timing_run(run=implementation_run))

        # Close project
        tool.logger_stage = LS.BUILD_VIVADO_FINALIZE
        if not disable_open_close:
            xibif_print_debug(f"Closing Vivado project at {project_path}", stage=tool.logger_stage)
            tool.run(commands.close_project())

    # Check if output files were generated
    if VivadoStage.bitstream in stages and not bitstream_path.exists():
        raise XibifGeneratedFileError(f"Bitstream file {bitstream_path} was not generated. Review the Vivado logs for details.")

    if VivadoStage.export in stages and not hardware_path.exists():
        raise XibifGeneratedFileError(f"Hardware description file {hardware_path} was not generated. Review the Vivado logs for details.")


@validate_call(config=ConfigDict(strict=True, arbitrary_types_allowed=True))
@validate_XibifPath_exist
def build_vitis(
    project_name: str,
    board: XilinxBoard,
    xilinx_version: XilinxVersion,
    stages: list[VitisStage] | None = None,
    platform_name: str = XibifDefaults.PLATFORM_NAME,
    app_name: str = XibifDefaults.APP_NAME,
    vitis_folder: XibifPath = XibifDefaults.VITIS_FOLDER,
    results_folder: XibifPath = XibifDefaults.RESULTS_FOLDER,
    disable_open_close: bool = False,
    runtime: VitisShell | None = None,
    xilinx_path: XibifPath | None = None,
) -> None:
    """Build a Vitis project.

    Builds a Vitis project for the given project name with the specified Xilinx version.
    When specific stages are given, only those stages are executed. When no stages are
    given, the complete Vitis flow is executed.

    Args:
        project_name (str): The name of the project to build.
        board (XilinxBoard): The target Xilinx board for the build.
        xilinx_version (XilinxVersion): The version of the Xilinx tools to use for the build.
        stages (list[VitisStage] | None): The stages of the build process to execute. If None, all stages will be executed.
        platform_name (str): The name of the platform to build. Default is XibifDefaults.PLATFORM_NAME.
        app_name (str): The name of the application to build. Default is XibifDefaults.APP_NAME.
        vitis_folder (XibifPath): The folder where the Vitis project is located. Default is XibifDefaults.VITIS_FOLDER.
        results_folder (XibifPath): The folder where the build results will be stored. Default is XibifDefaults.RESULTS_FOLDER.
        disable_open_close (bool): Whether to disable opening and closing the Vitis project during the build process. Default is False.
        runtime (VitisShell | None): An optional VitisShell instance to use for executing the build commands. If None, a new shell will be created. Default is None.
        xilinx_path (XibifPath | None): The path to the Xilinx tools installation. Required if runtime is None. Default is None.
    """
    xibif_print_info(f"Build Vitis project {project_name} for board {board.value} with Xilinx version {xilinx_version.value}.", stage=LS.BUILD_VITIS_GENERAL)

    # Get commands for vitis
    commands = CommandSetFactory.get_command_set(tool=ShellTool.VITIS, version=xilinx_version)

    # Define context for dependency resolution
    ctx = DC(board=board, xilinx_version=xilinx_version)

    # Prepare shell
    if runtime is None:
        if xilinx_path is None:
            raise XibifEnvironmentError("Xilinx path must be provided if no runtime shell is given.")

        tool_name = "xsct" if xilinx_version in [XilinxVersion.V2023_1, XilinxVersion.V2023_2] else "vitis"

        # Open Vitis shell
        tool = ShellFactory.create_shell(
            tool_name=ShellTool.VITIS,
            version=xilinx_version,
            executable=get_xilinx_tool_paths(xilinx_path=xilinx_path, xilinx_version=xilinx_version)[tool_name],
            interpreter=get_clean_shell(__DEPS.resolve(group=DG.PS_SHELL, ctx=ctx).as_path),
            precommand=get_clean_shell_batch_command(get_xilinx_tool_paths(xilinx_path=xilinx_path, xilinx_version=xilinx_version).settings64_script),
        )
    else:
        tool = runtime

    # Prepare build stages
    if stages is None:
        stages = list(VitisStage)
    elif VitisStage.all in stages:
        stages = list(VitisStage)
    xibif_print_debug(f"Vitis build stages: {[stage.value for stage in stages]}", stage=LS.BUILD_VITIS_GENERAL)

    # Generate some paths
    hardware_path = XibifDefaults.vivado_hardware_path(project_name=project_name, results_folder=results_folder)
    bitstream_path = XibifDefaults.vivado_bitstream_path(project_name=project_name, results_folder=results_folder)
    fsbl_path = XibifDefaults.vitis_fsbl_path(results_folder=results_folder)
    app_path = XibifDefaults.vitis_app_elf_path(app_name=app_name, results_folder=results_folder)
    boot_path = XibifDefaults.vitis_bootfile_path(results_folder=results_folder)

    # Check if a warning for Vitis 2024.1 needs to be printed
    if xilinx_version == XilinxVersion.V2024_1:
        xibif_print_warning(
            "A bug exists in the Vitis 2024.1 API that misconfigures settings for the FreeRTOS and lwIP software running on the ARM core! The project needs to be manually corrected after setup.",
            stage=LS.BUILD_VITIS_GENERAL,
        )

    # Check the xsa file in case the user wants to update the platform
    if VitisStage.update in stages:
        if not hardware_path.exists():
            raise XibifInvalidPathError(f"Hardware description file {hardware_path} does not exist. Run the Vivado build stage to generate it before updating the platform.")

        if hardware_path.stat().st_mtime < (time.time() - 3600):
            xibif_print_warning(f"Hardware description file {hardware_path} is older than one hour!", stage=LS.BUILD_VITIS_GENERAL)
            xibif_print_debug(f"Hardware description file timestamp: {hardware_path.stat().st_mtime}", stage=LS.BUILD_VITIS_GENERAL)

    # Check the bitstream file in case the user wants to update the platform
    if VitisStage.bootfile in stages:
        if not bitstream_path.exists():
            raise XibifInvalidPathError(f"Bitstream file {bitstream_path} does not exist. Run the Vivado build stage to generate it before generating the bootfile.")

        if bitstream_path.stat().st_mtime < (time.time() - 3600):
            xibif_print_warning(f"Bitstream file {bitstream_path} is older than one hour!", stage=LS.BUILD_VITIS_GENERAL)
            xibif_print_debug(f"Bitstream file timestamp: {bitstream_path.stat().st_mtime}", stage=LS.BUILD_VITIS_GENERAL)

        if VitisStage.export not in stages:
            if not app_path.exists():
                raise XibifInvalidPathError(f"Application ELF file {app_path} does not exist. Run the build stage with export enabled or run the export stage before generating the bootfile.")

            if app_path.stat().st_mtime < (time.time() - 3600):
                xibif_print_warning(f"Application ELF file {app_path} is older than one hour!", stage=tool.logger_stage)
                xibif_print_debug(f"Application ELF file timestamp: {app_path.stat().st_mtime}", stage=tool.logger_stage)

    # Check if output files already exist and remove them if necessary
    if VitisStage.build in stages:
        if fsbl_path.exists():
            fsbl_path.unlink()  # Remove old FSBL ELF
            xibif_print_debug(f"Removed old FSBL ELF at {fsbl_path}", stage=LS.BUILD_VITIS_GENERAL)

        if app_path.exists():
            app_path.unlink()  # Remove old application ELF
            xibif_print_debug(f"Removed old application ELF at {app_path}", stage=LS.BUILD_VITIS_GENERAL)

    if VitisStage.export in stages:
        if boot_path.exists():
            boot_path.unlink()  # Remove old BOOT.bin
            xibif_print_debug(f"Removed old BOOT.bin at {boot_path}", stage=LS.BUILD_VITIS_GENERAL)

    # Run build stages
    with tool:
        # Open workspace
        tool.logger_stage = LS.BUILD_VITIS_STARTUP
        if not disable_open_close:
            xibif_print_debug(f"Opening Vitis workspace at {vitis_folder}", stage=tool.logger_stage)
            tool.run(commands.set_workspace(workspace_path=vitis_folder))

        # Update platform
        tool.logger_stage = LS.BUILD_VITIS_UPDATE
        if VitisStage.update in stages:
            xibif_print_debug(f"Updating platform {platform_name} with hardware design {hardware_path}", stage=tool.logger_stage)
            tool.run(commands.update_platform(app_name=app_name, platform_name=platform_name, hardware_path=hardware_path))

        # Build application
        tool.logger_stage = LS.BUILD_VITIS_BUILD
        if VitisStage.build in stages:
            xibif_print_debug(f"Building application {app_name} for platform {platform_name}", stage=tool.logger_stage)
            tool.run(commands.clean_application(app_name=app_name))
            tool.downgrade_errors = True  # Vitis < 2024.1 throws a lot of errors resulting from pragmas in the source files
            tool.run(commands.generate_platform())
            tool.downgrade_errors = False
            tool.run(commands.set_application_config(app_name=app_name, config="Release"))
            tool.downgrade_errors = True  # Vitis < 2024.1 throws a lot of errors resulting from pragmas in the source files
            tool.run(commands.generate_application(app_name=app_name))
            tool.downgrade_errors = False
            if not XibifPath(commands.get_elf_path(app_name, vitis_folder)).exists():
                raise XibifGeneratedFileError(f"Failed to build application {app_name}. Check the Vitis logs for details.")

        # Export application and FSBL
        tool.logger_stage = LS.BUILD_VITIS_EXPORT
        if VitisStage.export in stages:
            xibif_print_debug(f"Exporting application {app_name} and FSBL to {results_folder}", stage=tool.logger_stage)
            tool.run(commands.copy_application(app_name=app_name, output_path=results_folder, platform_name=platform_name, workspace_path=vitis_folder, board=board))

        # Generate BOOT.bin
        tool.logger_stage = LS.BUILD_VITIS_BOOTFILE
        if VitisStage.bootfile in stages:
            xibif_print_debug(f"Generating BOOT.bin for application {app_name} at {boot_path}", stage=tool.logger_stage)
            tool.run(commands.generate_bootfile(app_name=app_name, output_path=results_folder, bitstream_path=bitstream_path, board=board))

    # Fix path to bitstream in launch.json file
    if VitisStage.updateLaunch in stages:
        ide_folder = vitis_folder.joinpath(app_name).joinpath("_ide")
        xibif_print_debug(f"Looking for launch files in {ide_folder} to update bitstream path to {bitstream_path}", stage=LS.BUILD_VITIS_UPDATELAUNCH)
        launch_files = list(ide_folder.rglob("*.launch")) if xilinx_version in (XilinxVersion.V2023_1, XilinxVersion.V2023_2) else list(ide_folder.rglob("launch.json"))
        for launch_file in launch_files:
            xibif_print_info(f"Updating launch file at {launch_file}", stage=LS.BUILD_VITIS_UPDATELAUNCH)
            if xilinx_version in (XilinxVersion.V2023_1, XilinxVersion.V2023_2):
                if not _build_vitis_update_launch_xml(launch_file=launch_file, bitstream_path=bitstream_path):
                    xibif_print_warning(f"Warning: Could not parse launch file at {launch_file}. Bitstream path was not updated.", stage=LS.BUILD_VITIS_UPDATELAUNCH)
            else:
                if not _build_vitis_update_launch_json(launch_file=launch_file, bitstream_path=bitstream_path):
                    xibif_print_warning(f"Warning: Could not update launch.json at {launch_file}. Bitstream path was not updated.", stage=LS.BUILD_VITIS_UPDATELAUNCH)

    # Check if the output files were generated
    if VitisStage.export in stages and not app_path.exists():
        raise XibifGeneratedFileError(f"Application ELF file {app_path} was not generated. Review the Vitis logs for details.")

    if VitisStage.bootfile in stages and not boot_path.exists():
        raise XibifGeneratedFileError(f"Bootfile {boot_path} was not generated. Review the Vitis logs for details.")


def build_vitis_regenerate(
    project_name: str,
    board: XilinxBoard,
    xilinx_version: XilinxVersion,
    platform_name: str = XibifDefaults.PLATFORM_NAME,
    app_name: str = XibifDefaults.APP_NAME,
    vitis_folder: XibifPath = XibifDefaults.VITIS_FOLDER,
    results_folder: XibifPath = XibifDefaults.RESULTS_FOLDER,
    runtime: VitisShell | None = None,
    xilinx_path: XibifPath | None = None,
) -> None:
    """Regenerate a Vitis project.

    Regenerates a Vitis project from a given project name.
    When working with Vitis, it can occur that a Vitis project file gets corrupted. The usual,
    best workaround is to re-generate the existing project from scratch.

    Before the Vitis project is regenerated, a backup of the current Vitis project is generated.

    Args:
        project_name (str): The name of the project to regenerate.
        board (XilinxBoard): The target Xilinx board for the project.
        xilinx_version (XilinxVersion): The version of the Xilinx tools to use for the project.
        platform_name (str): The name of the platform to build. Default is XibifDefaults.PLATFORM_NAME.
        app_name (str): The name of the application to build. Default is XibifDefaults.APP_NAME.
        vitis_folder (XibifPath): The folder where the Vitis project is located. Default is XibifDefaults.VITIS_FOLDER.
        results_folder (XibifPath): The folder where the build results will be stored. Default is XibifDefaults.RESULTS_FOLDER.
        runtime (VitisShell | None): An optional VitisShell instance to use for executing the build commands. If None, a new shell will be created. Default is None.
        xilinx_path (XibifPath | None): The path to the Xilinx tools installation. Required if runtime is None. Default is None.
    """
    xibif_print_info(f"Regenerating Vitis project {project_name} for board {board.value} with Xilinx version {xilinx_version.value}.", stage=LS.BUILD_VITIS_REGENERATE)
    xibif_print_warning(
        "User applied settings need to be re-applied after regeneration! This includes debug configurations, build settings and any other manual changes made to the project after setup.",
        stage=LS.BUILD_VITIS_REGENERATE,
    )

    # Create a backup of the current Vitis project before regenerating
    backup_path = misc_create_backup()

    # Get the path to the backup vitis folder
    vitis_src_folder_backup = backup_path.joinpath(os.path.relpath(vitis_folder, start=XibifPath(".")))
    xibif_print_debug(f"vitis_src_folder_backup: {vitis_src_folder_backup}", stage=LS.BUILD_VITIS_REGENERATE)

    # Define the path to the current vitis src folder
    vitis_src_folder = vitis_folder.joinpath(app_name).joinpath("src")
    xibif_print_debug(f"vitis_src_folder: {vitis_src_folder}", stage=LS.BUILD_VITIS_REGENERATE)

    # Remove the vitis folder
    shutil.rmtree(vitis_folder)

    # Create the new workspace
    vitis_src_folder.mkdir(parents=True, exist_ok=True)  # Create the src folder for the application

    # Copy the *.c and *.h files back
    for file in vitis_src_folder_backup.glob("*.c"):
        xibif_print_debug(f"Copying source file {file} to {vitis_src_folder}", stage=LS.BUILD_VITIS_REGENERATE)
        shutil.copy(file, vitis_src_folder)
    for file in vitis_src_folder_backup.glob("*.h"):
        xibif_print_debug(f"Copying header file {file} to {vitis_src_folder}", stage=LS.BUILD_VITIS_REGENERATE)
        shutil.copy(file, vitis_src_folder)

    # Regenerate the Vitis project using the setup function
    setup_vitis_project(
        project_name=project_name,
        board=board,
        xilinx_version=xilinx_version,
        platform_name=platform_name,
        app_name=app_name,
        vitis_folder=vitis_folder,
        results_folder=results_folder,
        runtime=runtime,
        xilinx_path=xilinx_path,
    )

    # Wait until lockfile is removed
    if not xilinx_version in (XilinxVersion.V2023_1, XilinxVersion.V2023_2):
        lockfile = XibifDefaults.vitis_lockfile_path(vitis_folder=vitis_folder)

        xibif_print_info(f"Lockfile {lockfile} exists. Waiting for it to be removed before proceeding.", stage=LS.BUILD_VITIS_GENERAL)
        time_start = time.time()
        while lockfile.exists():
            time.sleep(1)
            try:
                lockfile.unlink()  # Try to remove the lockfile in case it was left behind by a previous Vitis instance that did not shut down properly
            except PermissionError:
                pass  # If we don't have permission to remove the lockfile, it means Vitis is still running and we should keep waiting for it to be removed automatically when Vitis shuts down
            if time.time() - time_start > 120:  # Timeout after 2 minutes
                raise XibifTimeoutError(f"Timeout while waiting for lockfile {lockfile} to be removed. Please check if Vitis is still running and remove the lockfile if it is not.")


def _build_vitis_update_launch_xml(
    launch_file: XibifPath,
    bitstream_path: XibifPath,
) -> bool:
    """Helper function to update the bitstream path in a Vitis 2023 launch file (XML format).

    Args:
        launch_file (XibifPath): The path to the launch file to update.
        bitstream_path (XibifPath): The path to the bitstream file to set in the launch file.

    Returns:
        bool: True if the launch file was successfully updated, False otherwise.
    """
    try:
        tree = ET.parse(launch_file)
        root = tree.getroot()

        # Find and update the bitstream file attribute
        for attr in root.findall(".//stringAttribute[@key='com.xilinx.sdk.tcf.debug.uihw.bit.file']"):
            attr.set("value", str(bitstream_path))
        tree.write(launch_file, encoding="utf-8", xml_declaration=True)

        return True

    except ET.ParseError:
        return False


def _build_vitis_update_launch_json(
    launch_file: XibifPath,
    bitstream_path: XibifPath,
) -> bool:
    """Helper function to update the bitstream path in a Vitis 2024 and newer launch file (JSON format).

    Args:
        launch_file (XibifPath): The path to the launch file to update.
        bitstream_path (XibifPath): The path to the bitstream file to set in the launch file.

    Returns:
        bool: True if the launch file was successfully updated, False otherwise.
    """
    try:
        with open(launch_file, "r", encoding="utf-8") as f:
            config = json.load(f)

        for configuration in config.get("configurations", []):
            if "targetSetup" in configuration and "bitstreamFile" in configuration["targetSetup"]:
                configuration["targetSetup"]["bitstreamFile"] = str(bitstream_path)

        with open(launch_file, "w", encoding="utf-8") as f:
            json.dump(config, f, indent=2)

        return True

    except (json.JSONDecodeError, IOError):
        return False
