"""CLI-Wrapper for Corsair with XiBIF generator patches."""

import inspect
from . import generators as xibif_generators
from ._external import import_external_corsair

_corsair = import_external_corsair("corsair")
_corsair_main = import_external_corsair("corsair.__main__")


def apply_patches():
    """Overwrite generators in corsair with XiBIF versions."""
    for symbol_name, symbol_obj in vars(xibif_generators).items():
        if not inspect.isclass(symbol_obj):
            continue
        if not issubclass(symbol_obj, xibif_generators.Generator):
            continue
        setattr(_corsair.generators, symbol_name, symbol_obj)


def main():
    """Start the original corsair CLI after applying patches."""
    apply_patches()
    _corsair_main.main()
