"""XiBIF corsair extension - custom generators and templates

This module imports unmodified generators from corsair and adds 6 new custom generators:
  - Latex: LaTeX documentation with braces cleanup
  - Pdf: PDF documentation (requires reportlab)
  - GuiPython: GTK3-based GUI for register access
  - Matlab: MATLAB register access functions
  - VhdlPackage: VHDL package with register parameters
  - VunitVhdl: VUnit testbench for AXI-Lite interface
"""

import os
import json
from pathlib import Path
from importlib.metadata import version
import jinja2
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.lib import colors
from reportlab.platypus import (
    SimpleDocTemplate,
    Table,
    TableStyle,
    Paragraph,
    Spacer,
    PageBreak,
)
from reportlab.lib.enums import TA_CENTER

from ._external import import_external_corsair

_corsair = import_external_corsair("corsair")
utils = import_external_corsair("corsair.utils")
config = import_external_corsair("corsair.config")
corsair_generators = import_external_corsair("corsair.generators")

# Import all unchanged generators and base classes from corsair
Generator = corsair_generators.Generator
Json = corsair_generators.Json
Yaml = corsair_generators.Yaml
Txt = corsair_generators.Txt
Verilog = corsair_generators.Verilog
VerilogHeader = corsair_generators.VerilogHeader
SystemVerilogPackage = corsair_generators.SystemVerilogPackage
LbBridgeVerilog = corsair_generators.LbBridgeVerilog
LbBridgeVhdl = corsair_generators.LbBridgeVhdl
Markdown = corsair_generators.Markdown
Asciidoc = corsair_generators.Asciidoc
Wavedrom = corsair_generators.Wavedrom

# Use original corsair Jinja2; template path is passed explicitly.
CorsairJinja2 = corsair_generators.Jinja2
CorsairCHeader = corsair_generators.CHeader
CorsairVhdl = corsair_generators.Vhdl
CorsairPython = corsair_generators.Python

XIBIF_TEMPLATE_PATH = str(Path(__file__).parent / "templates")
CORSAIR_TEMPLATE_PATH = str(Path(corsair_generators.__file__).parent / "templates")
TEMPLATE_PATH = [XIBIF_TEMPLATE_PATH, CORSAIR_TEMPLATE_PATH]


class Jinja2(CorsairJinja2):
    """Override corsair Jinja2 with XiBIF template fallback.

    This extends corsair.generators.Jinja2 to search xibif_corsair templates first,
    then fall back to corsair templates. This allows customization of existing templates.
    """

    def render(self, template, template_vars=None, templates_path=None, **kwargs) -> str:
        """Render text with Jinja2, searching xibif_corsair templates first, then corsair templates.

        Args:
            template (str): Jinja2 template filename
            template_vars (dict, optional): Dictionary with variables for Jinja2 rendering. Defaults to None.
            templates_path (str or list of str, optional): Optional path(s) to search for templates. If not provided, will search xibif_corsair/templates then corsair/templates. Defaults to None.
            **kwargs: Additional keyword arguments for compatibility with corsair generators (e.g. for passing config variables)

        Returns:
            str: The rendered text
        """
        if template_vars is None:
            template_vars = kwargs.pop("vars", None)
        if template_vars is None:
            template_vars = {}

        if not templates_path:
            search_path = list(TEMPLATE_PATH)
        elif isinstance(templates_path, (str, Path)):
            search_path = [str(templates_path), CORSAIR_TEMPLATE_PATH]
        else:
            search_path = [str(path) for path in templates_path]
            if CORSAIR_TEMPLATE_PATH not in search_path:
                search_path.append(CORSAIR_TEMPLATE_PATH)

        j2_env = jinja2.Environment(
            loader=jinja2.FileSystemLoader(searchpath=search_path),
            trim_blocks=True,
            lstrip_blocks=True,
        )
        j2_env.globals.update(zip=zip)
        j2_template = j2_env.get_template(template)
        return j2_template.render(template_vars)


# ============================================================================
# NEW/MODIFIED GENERATORS
# ============================================================================
class CHeader(CorsairCHeader):
    """Override corsair CHeader to use xibif/corsair templates.

    Create C header file with register map defines.

    :param rmap: Register map object
    :type rmap: :class:`corsair.RegisterMap`
    :param path: Path to the output file
    :type path: str
    :param prefix: Prefix for the all defines and types. If empty output file name will be used.
    :type prefix: str
    """

    def __init__(self, rmap=None, path="regs.h", prefix="CSR", add_json=False, **args):
        super().__init__(rmap=rmap, path=path, prefix=prefix, **args)
        self.add_json = add_json

    def generate(self):
        """Generate C header file with register map definitions."""
        self.validate()
        j2_template = "c_header.j2"
        j2_vars = {
            "corsair_ver": "xibif_" + version("xibif"),
            "rmap": self.rmap,
            "prefix": self.prefix.upper(),
            "file_name": utils.get_file_name(self.path),
            "config": config.globcfg,
        }
        if self.add_json:
            j2_vars["rmap_json"] = json.dumps(self.rmap.as_dict(), separators=(",", ":"))
        self.render_to_file(j2_template, j2_vars, self.path, templates_path=TEMPLATE_PATH)


class Vhdl(CorsairVhdl):
    """Override corsair Vhdl to use xibif/corsair templates.

    Create VHDL file with register map.

    :param rmap: Register map object
    :type rmap: :class:`corsair.RegisterMap`
    :param path: Path to the output file
    :type path: str
    :param read_filler: Numeric value to return if wrong address was read
    :type read_filler: int
    :param interface: Register map bus protocol. Use one of: `axil`, `apb`, `amm`, `lb`
    :type interface: str
    """

    def __init__(self, rmap=None, path="regs.vhd", read_filler=0, interface="axil", **args):
        super().__init__(rmap=rmap, path=path, read_filler=read_filler, interface=interface, **args)

    def generate(self):
        """Generate VHDL file with register map."""
        self.validate()
        j2_template = "regmap_vhdl.j2"
        j2_vars = {
            "corsair_ver": "xibif_" + version("xibif"),
            "rmap": self.rmap,
            "module_name": utils.get_file_name(self.path),
            "read_filler": utils.str2int(self.read_filler),
            "interface": self.interface,
            "config": config.globcfg,
        }

        if config.globcfg["address_increment"] == "data_width":
            j2_vars["config"]["address_increment"] = config.globcfg["data_width"] // 8
        if config.globcfg["address_alignment"] == "data_width":
            j2_vars["config"]["address_alignment"] = config.globcfg["data_width"] // 8

        self.render_to_file(j2_template, j2_vars, self.path, templates_path=TEMPLATE_PATH)


class Python(CorsairPython):
    """Override corsair Python to use xibif/corsair templates.

    Create Python file to access register map via some interface.

    :param rmap: Register map object
    :type rmap: :class:`corsair.RegisterMap`
    :param path: Path to the output file
    :type path: str
    """

    def __init__(self, rmap=None, path="regs.py", **args):
        super().__init__(rmap=rmap, path=path, **args)

    def generate(self):
        """Generate Python file with register map access functions."""
        self.validate()
        j2_template = "regmap_py.j2"
        j2_vars = {
            "corsair_ver": "xibif_" + version("xibif"),
            "rmap": self.rmap,
            "config": config.globcfg,
        }
        self.render_to_file(j2_template, j2_vars, self.path, templates_path=TEMPLATE_PATH)


class Latex(Generator, Jinja2, Wavedrom):
    """Create documentation for a register map in Latex.

    :param rmap: Register map object
    :type rmap: :class:`corsair.RegisterMap`
    :param path: Path to the output file
    :type path: str
    :param title: Document title
    :type title: str
    :param print_images: Enable generating images for bit fields of a register
    :type print_images: bool
    :param image_dir: Path to directory where all images will be saved
    :type image_dir: str
    :param print_conventions: Enable generating table with register access modes explained
    :type print_conventions: bool
    """

    def __init__(
        self,
        rmap=None,
        path="regs.md",
        title="Register map",
        print_images=True,
        image_dir="regs_img",
        print_conventions=True,
        **args,
    ):
        super().__init__(rmap, **args)
        self.path = path
        self.title = title
        self.print_images = print_images
        self.image_dir = image_dir
        self.print_conventions = print_conventions

    def generate(self):
        """Generate LaTeX documentation file with register map details."""
        filename = utils.get_file_name(self.path)
        self.validate()
        j2_template = "regmap_latex.j2"
        j2_vars = {
            "corsair_ver": "xibif_" + version("xibif"),
            "rmap": self.rmap,
            "print_images": utils.str2bool(self.print_images),
            "print_conventions": utils.str2bool(self.print_conventions),
            "image_dir": self.image_dir,
            "filename": filename,
            "title": self.title,
            "config": config.globcfg,
        }
        self.render_to_file(j2_template, j2_vars, self.path, templates_path=TEMPLATE_PATH)

        # Fix LaTeX braces
        with open(self.path, "r") as file:
            filedata = file.read()
        filedata = filedata.replace("{ ", "{").replace(" }", "}")
        with open(self.path, "w") as file:
            file.write(filedata)

        if self.print_images:
            self.draw_regs(Path(self.path).parent / self.image_dir, self.rmap)


class Pdf(Generator, Wavedrom):
    """Create documentation for a register map in PDF format.

    :param rmap: Register map object
    :type rmap: :class:`corsair.RegisterMap`
    :param path: Path to the output file
    :type path: str
    :param title: Document title
    :type title: str
    :param print_images: Enable generating images for bit fields of a register
    :type print_images: bool
    :param image_dir: Path to directory where all images will be saved (temporary)
    :type image_dir: str
    :param print_conventions: Enable generating table with register access modes explained
    :type print_conventions: bool
    :param invert_bitfields: If True, LSB comes first in bitfield tables; if False (default), MSB comes first
    :type invert_bitfields: bool
    """

    def __init__(
        self,
        rmap=None,
        path="regs.pdf",
        title="Register map",
        print_images=True,
        image_dir="regs_img_tmp",
        print_conventions=True,
        invert_bitfields=False,
        **args,
    ):
        super().__init__(rmap, **args)
        self.path = path
        regmap_filename = os.path.splitext(os.path.basename(config.globcfg["regmap_path"]))[0].upper()
        self.title = f"{title} {regmap_filename}"
        self.print_images = print_images
        self.image_dir = image_dir
        self.print_conventions = print_conventions
        self.invert_bitfields = invert_bitfields

    def generate(self):
        """Generate PDF documentation file with register map details."""
        self.validate()

        utils.create_dirs(self.path)
        doc = SimpleDocTemplate(
            self.path,
            pagesize=A4,
            rightMargin=72,
            leftMargin=72,
            topMargin=72,
            bottomMargin=18,
        )

        elements = []
        styles = getSampleStyleSheet()
        title_style = ParagraphStyle(
            "CustomTitle",
            parent=styles["Heading1"],
            fontSize=24,
            textColor=colors.HexColor("#2C3E50"),
            spaceAfter=30,
            alignment=TA_CENTER,
        )
        heading_style = ParagraphStyle(
            "CustomHeading",
            parent=styles["Heading2"],
            fontSize=16,
            textColor=colors.HexColor("#34495E"),
            spaceAfter=12,
            spaceBefore=12,
        )
        table_header_color = colors.HexColor("#2980B9")

        # Title Page
        elements.append(Spacer(1, 2 * inch))
        elements.append(Paragraph(self.title, title_style))
        elements.append(
            Paragraph(
                "Register Map Documentation",
                ParagraphStyle(
                    "Subtitle",
                    parent=styles["Heading2"],
                    fontSize=14,
                    textColor=colors.HexColor("#7F8C8D"),
                    spaceAfter=12,
                    alignment=TA_CENTER,
                ),
            )
        )
        elements.append(Spacer(1, 0.5 * inch))
        elements.append(Paragraph(f"Generated by Corsair xibif_{version('xibif')}", styles["Normal"]))
        elements.append(PageBreak())

        # Table of Contents
        elements.append(Paragraph("Table of Contents", heading_style))
        elements.append(Spacer(1, 12))

        toc_data = [["Address", "Name", "Access", "Reset"]]
        for reg in self.rmap:
            access = reg.bitfields[0].access if reg.bitfields else "rw"
            link = f'<link href="#{reg.name}" color="blue">{reg.name}</link>'
            reset_digits = config.globcfg["data_width"] // 4 + (1 if config.globcfg["data_width"] % 4 else 0)
            reset_str = f"0x{reg.reset:0{reset_digits}X}".lower()

            toc_data.append(
                [
                    f"0x{reg.address:X}",
                    Paragraph(link, styles["Normal"]),
                    access,
                    reset_str,
                ]
            )

        toc_table = Table(toc_data, colWidths=[1.2 * inch, 2.3 * inch, 1 * inch, 1.5 * inch])
        toc_table.setStyle(
            TableStyle(
                [
                    ("BACKGROUND", (0, 0), (-1, 0), table_header_color),
                    ("TEXTCOLOR", (0, 0), (-1, 0), colors.whitesmoke),
                    ("ALIGN", (0, 0), (-1, -1), "LEFT"),
                    ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
                    ("FONTSIZE", (0, 0), (-1, 0), 12),
                    ("BOTTOMPADDING", (0, 0), (-1, 0), 12),
                    ("BACKGROUND", (0, 1), (-1, -1), colors.white),
                    ("GRID", (0, 0), (-1, -1), 1, colors.black),
                ]
            )
        )
        elements.append(toc_table)
        elements.append(PageBreak())

        # General Configuration
        elements.append(Paragraph("General Configuration", heading_style))
        reset_style = ""
        reset_cfg = config.globcfg["register_reset"]
        if "async" in reset_cfg:
            reset_style += "Asynchronous "
        elif "sync" in reset_cfg:
            reset_style += "Synchronous "
        if "pos" in reset_cfg:
            reset_style += "active-high"
        elif "neg" in reset_cfg:
            reset_style += "active-low"

        config_data = [
            ["Parameter", "Value"],
            ["Base Address", f"0x{config.globcfg['base_address']:X}"],
            ["Address Width", f"{config.globcfg['address_width']} bits"],
            ["Data Width", f"{config.globcfg['data_width']} bits"],
            ["Reset Style", reset_style],
        ]
        config_table = Table(config_data, colWidths=[3 * inch, 3 * inch])
        config_table.setStyle(
            TableStyle(
                [
                    ("BACKGROUND", (0, 0), (-1, 0), table_header_color),
                    ("TEXTCOLOR", (0, 0), (-1, 0), colors.whitesmoke),
                    ("ALIGN", (0, 0), (-1, -1), "LEFT"),
                    ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
                    ("FONTSIZE", (0, 0), (-1, 0), 12),
                    ("BOTTOMPADDING", (0, 0), (-1, 0), 12),
                    ("BACKGROUND", (0, 1), (-1, -1), colors.white),
                    ("GRID", (0, 0), (-1, -1), 1, colors.black),
                ]
            )
        )
        elements.append(config_table)
        elements.append(Spacer(1, 20))

        # Registers
        elements.append(Paragraph("Registers", heading_style))
        elements.append(Spacer(1, 12))

        for reg in self.rmap:
            reg_title = f"0x{reg.address:X}: {reg.name}"
            reg_para = Paragraph(f'<a name="{reg.name}"/>{reg_title}', styles["Heading1"])
            elements.append(reg_para)

            if reg.description:
                elements.append(Paragraph(reg.description, styles["Normal"]))
                elements.append(Spacer(1, 6))

            if len(reg.bitfields) > 0:
                bf_data = [["Bits", "Name", "SW", "HW", "Reset", "Description"]]
                bitfields_list = list(reg)
                if not utils.str2bool(self.invert_bitfields):
                    bitfields_list = list(reversed(bitfields_list))

                for bf in bitfields_list:
                    bits_str = f"{bf.msb}:{bf.lsb}" if bf.msb != bf.lsb else f"{bf.lsb}"
                    reset_val = (reg.reset >> bf.lsb) & ((1 << bf.width) - 1)
                    bf_data.append(
                        [
                            bits_str,
                            bf.name,
                            bf.access,
                            bf.hardware,
                            f"0x{reset_val:X}",
                            bf.description,
                        ]
                    )

                bf_table = Table(
                    bf_data,
                    colWidths=[
                        0.6 * inch,
                        1 * inch,
                        0.7 * inch,
                        0.7 * inch,
                        0.6 * inch,
                        2.4 * inch,
                    ],
                )
                bf_table.setStyle(
                    TableStyle(
                        [
                            ("BACKGROUND", (0, 0), (-1, 0), table_header_color),
                            ("TEXTCOLOR", (0, 0), (-1, 0), colors.whitesmoke),
                            ("ALIGN", (0, 0), (-1, -1), "LEFT"),
                            ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
                            ("FONTSIZE", (0, 0), (-1, -1), 9),
                            ("BOTTOMPADDING", (0, 0), (-1, 0), 12),
                            ("BACKGROUND", (0, 1), (-1, -1), colors.white),
                            ("GRID", (0, 0), (-1, -1), 1, colors.black),
                            ("VALIGN", (0, 0), (-1, -1), "TOP"),
                        ]
                    )
                )
                elements.append(bf_table)
                elements.append(Spacer(1, 10))

            elements.append(Spacer(1, 20))

        doc.build(elements)


class GuiPython(Generator, Jinja2):
    """Create a Gtk 3.0 GUI in Python for the register map.

    :param rmap: Register map object
    :type rmap: :class:`corsair.RegisterMap`
    :param path: Path to the output file
    :type path: str
    :param default_read: Whether to enable read ability on startup
    :type default_read: bool
    :param default_write: Whether to enable write ability on startup
    :type default_write: bool
    :param default_reset: Whether to enable reset ability on startup
    :type default_reset: bool
    :param default_readback: Whether to enable register readback on startup
    :type default_readback: bool
    :param read_on_startup: Whether to read registers on startup
    :type read_on_startup: bool
    :param show_reg_address: Whether to show register addresses
    :type show_reg_address: bool
    :param show_reg_name: Whether to show register names
    :type show_reg_name: bool
    :param show_field_name: Whether to show field names
    :type show_field_name: bool
    """

    def __init__(
        self,
        rmap=None,
        path="regs.py",
        default_read=True,
        default_write=True,
        default_reset=False,
        default_readback=True,
        read_on_startup=True,
        show_reg_address=True,
        show_reg_name=True,
        show_field_name=True,
        **args,
    ):
        super().__init__(rmap, **args)
        self.path = path
        self.default_read = utils.str2bool(default_read)
        self.default_write = utils.str2bool(default_write)
        self.default_reset = utils.str2bool(default_reset)
        self.default_readback = utils.str2bool(default_readback)
        self.read_on_startup = utils.str2bool(read_on_startup)
        self.show_reg_address = utils.str2bool(show_reg_address)
        self.show_reg_name = utils.str2bool(show_reg_name)
        self.show_field_name = utils.str2bool(show_field_name)

    def generate(self):
        """Generate GTK3-based GUI Python file for register access."""
        self.validate()
        j2_template = "gui_py.j2"
        j2_vars = {
            "corsair_ver": "xibif_" + version("xibif"),
            "rmap": self.rmap,
            "config": config.globcfg,
            "default_read": self.default_read,
            "default_write": self.default_write,
            "default_reset": self.default_reset,
            "default_readback": self.default_readback,
            "read_on_startup": self.read_on_startup,
            "show_reg_address": self.show_reg_address,
            "show_reg_name": self.show_reg_name,
            "show_field_name": self.show_field_name,
            "regmap_name": utils.get_file_name(self.path),
        }
        self.render_to_file(j2_template, j2_vars, self.path, templates_path=TEMPLATE_PATH)


class Matlab(Generator, Jinja2):
    """Create Matlab file to access register map via some interface.

    :param rmap: Register map object
    :type rmap: :class:`corsair.RegisterMap`
    :param path: Path to the output file
    :type path: str
    """

    def __init__(self, rmap=None, path="regs.m", **args):
        super().__init__(rmap, **args)
        self.path = path

    def generate(self):
        """Generate MATLAB file with register map and individual register files."""
        self.validate()
        prefix = Path(self.path).stem

        if not os.path.exists(Path(self.path).parent.joinpath(prefix)):
            os.makedirs(Path(self.path).parent.joinpath(prefix))

        for reg in self.rmap:
            j2_template = "regmap_reg_matlab.j2"
            j2_vars = {
                "corsair_ver": "xibif_" + version("xibif"),
                "reg": reg,
                "config": config.globcfg,
            }
            self.render_to_file(
                j2_template,
                j2_vars,
                Path(self.path).parent.joinpath(prefix + "/" + reg.name.capitalize() + ".m"),
                templates_path=TEMPLATE_PATH,
            )

        j2_template = "regmap_matlab.j2"
        j2_vars = {
            "corsair_ver": version("xibif"),
            "rmap": self.rmap,
            "regmapname": prefix,
            "config": config.globcfg,
        }
        self.render_to_file(j2_template, j2_vars, self.path, templates_path=TEMPLATE_PATH)


class VhdlPackage(Generator, Jinja2):
    """Create a VHDL package with register map parameters.

    :param rmap: Register map object
    :type rmap: :class:`corsair.RegisterMap`
    :param path: Path to the output file
    :type path: str
    :param prefix: Prefix for the all parameters and types. If empty output file name will be used.
    :type prefix: str
    :param module_name: Name of the register map module
    :type module_name: str
    """

    def __init__(self, rmap=None, path="regs_pkg.vhd", prefix="CSR", module_name="regs", **args):
        super().__init__(rmap, **args)
        self.path = path
        self.prefix = prefix
        self.module_name = module_name

    def generate(self):
        """Generate VHDL package file with register map parameters."""
        self.validate()
        j2_template = "vhdl_package.j2"
        j2_vars = {
            "corsair_ver": "xibif_" + version("xibif"),
            "rmap": self.rmap,
            "prefix": self.prefix.upper(),
            "file_name": utils.get_file_name(self.path),
            "module_name": self.module_name,
            "config": config.globcfg,
        }
        self.render_to_file(j2_template, j2_vars, self.path, templates_path=TEMPLATE_PATH)


class VunitVhdl(Generator, Jinja2):
    """Create VUnit VHDL testbench for register map with AXI-Lite interface.

    :param rmap: Register map object
    :type rmap: :class:`corsair.RegisterMap`
    :param path: Path to the output file
    :type path: str
    :param module_name: Name of the register map module to test
    :type module_name: str
    :param interface: Register map bus protocol. Only 'axil' is supported for now.
    :type interface: str
    """

    def __init__(
        self,
        rmap=None,
        path="regs_tb.vhd",
        module_name="regs",
        interface="axil",
        **args,
    ):
        super().__init__(rmap, **args)
        self.path = path
        self.module_name = module_name
        self.interface = interface

    def validate(self):
        """Validate the VunitVhdl generator configuration.

        Ensures that the interface is set to 'axil' as it's the only supported
        interface for VUnit VHDL testbench generation.

        :raises AssertionError: If interface is not 'axil'
        """
        super().validate()
        assert self.interface == "axil", "Only 'axil' interface is supported for VunitVhdl generator!"

    def generate(self):
        """Generate VUnit VHDL testbench file for AXI-Lite register map testing."""
        self.validate()
        j2_template = "vunit_vhdl.j2"
        j2_vars = {
            "corsair_ver": "xibif_" + version("xibif"),
            "rmap": self.rmap,
            "module_name": self.module_name,
            "interface": self.interface,
            "config": config.globcfg,
        }
        self.render_to_file(j2_template, j2_vars, self.path, templates_path=TEMPLATE_PATH)


# ============================================================================
# PUBLIC SYMBOLS
# ============================================================================
__all__ = [
    # Base classes (imported from corsair)
    "Generator",
    "Jinja2",
    "Wavedrom",
    # Imported from corsair
    "Json",
    "Yaml",
    "Txt",
    "Verilog",
    "VerilogHeader",
    "SystemVerilogPackage",
    "LbBridgeVerilog",
    "LbBridgeVhdl",
    "Markdown",
    "Asciidoc",
    # Overridden from corsair (with xibif/corsair templates)
    "CHeader",
    "Vhdl",
    "Python",
    # New/custom generators
    "Latex",
    "Pdf",
    "GuiPython",
    "Matlab",
    "VhdlPackage",
    "VunitVhdl",
]
