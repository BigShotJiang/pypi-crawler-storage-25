"""Helpers for loading the external corsair package without resolving to xibif.corsair."""

from __future__ import annotations

import sys
from importlib import import_module
from pathlib import Path


def import_external_corsair(module_name: str = "corsair"):
    """Import the external corsair package while excluding the local XiBIF package root from search."""
    package_root = str(Path(__file__).resolve().parents[1])
    original_sys_path = list(sys.path)
    sys.path = [path for path in sys.path if Path(path).resolve() != Path(package_root).resolve()]
    try:
        return import_module(module_name)
    finally:
        sys.path = original_sys_path
