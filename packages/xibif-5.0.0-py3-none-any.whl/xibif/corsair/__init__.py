"""XiBIF extensions as a proxy for ``corsair``.

During import, XiBIF generators are patched into ``corsair.generators``.
All symbols not present in ``xibif.corsair`` are transparently
passed on to the original ``corsair`` package.
"""

from .cli import apply_patches
from ..types import XibifPath
from ._external import import_external_corsair

_corsair = import_external_corsair("corsair")

apply_patches()

# Expose commonly used corsair symbols at the top level of xibif.corsair for convenience
corsair = _corsair
generators = _corsair.generators
CorsairConfig = dict[str, str | int | bool | XibifPath]
CorsairTarget = dict[str, dict[str, str | int | bool | XibifPath]]
RegisterMap = corsair.RegisterMap
Register = corsair.Register
BitField = corsair.BitField


def __getattr__(name):
    """Passes unknown attributes to ``corsair``"""
    return getattr(_corsair, name)


def __dir__():
    """Combines local and passed-on attributes for autocomplete."""
    local = set(globals().keys())
    delegated = set(dir(_corsair))
    return sorted(local | delegated)


__all__ = ["apply_patches", "generators"]
