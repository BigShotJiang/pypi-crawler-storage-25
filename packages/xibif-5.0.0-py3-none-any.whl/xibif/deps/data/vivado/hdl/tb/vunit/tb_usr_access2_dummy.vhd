---------------------------------------------------------------------------------------------------
-- Project:  XiBIF
-- Customer: Generic
---------------------------------------------------------------------------------------------------
-- Description:
-- Simulation dummy for Xilinx primitive USR_ACCESSE2
-- Provides a stable model for testbench/VUnit runs
---------------------------------------------------------------------------------------------------
-- Created: 2026-03-06
---------------------------------------------------------------------------------------------------

library ieee;
use ieee.std_logic_1164.all;

package VCOMPONENTS is
    component USR_ACCESSE2 is
        port(
			CFGCLK    : out std_ulogic;
            DATA      : out std_logic_vector(31 downto 0);
			DATAVALID : out std_ulogic
        );
    end component USR_ACCESSE2;
end package VCOMPONENTS;

package body VCOMPONENTS is
end package body VCOMPONENTS;

library ieee;
use ieee.std_logic_1164.all;

entity USR_ACCESSE2 is
	port(
		CFGCLK    : out std_ulogic;
		DATA      : out std_logic_vector(31 downto 0);
		DATAVALID : out std_ulogic
	);
end entity USR_ACCESSE2;

architecture dummy of USR_ACCESSE2 is
begin
	CFGCLK    <= '0';
	DATA      <= (others => '0');
	DATAVALID <= '0';
end architecture dummy;
