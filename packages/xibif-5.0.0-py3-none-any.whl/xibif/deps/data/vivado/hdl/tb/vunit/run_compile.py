"""VUnit compilation runner for VHDL design files."""

import sys
from logging import Filter
from loguru import logger
from vunit import VUnit
from vunit.library import Library
from vunit.project import LOGGER
from xibif import XibifProject
from xibif.types.utils import XibifPath
from xibif.utils import get_xilinx_tool_paths


class FilterPrimaryDesignAll(Filter):
    """A log filter to suppress specific warnings related to primary design units in VUnit."""

    def __init__(self):
        super().__init__()

    def filter(self, record):
        if "failed to find a primary design unit 'all'" in record.getMessage():
            return False
        return True


def add_files_with_order(library: Library, base_path: XibifPath):
    """Add VHDL source files to a library with optional dependency ordering.

    Args:
        library (Library): The VUnit library to which the source files will be added.
        base_path (XibifPath): The base path where the VHDL source files are located. The function will look for a file named 'vhdl_analyze_order' in this path to determine the order of compilation. If this file does not exist, all VHDL files in the base path will be added without specific ordering.
    """
    files = list(base_path.glob("*.vhd"))
    files = [w.as_posix() for w in files]

    path_order = XibifPath(base_path).joinpath("vhdl_analyze_order")

    last_file = None
    if path_order.exists():
        order = [XibifPath(base_path).joinpath(f"{l.strip()}") for l in path_order.read_text().splitlines()]
        for f in order:
            if f.exists():
                src = library.add_source_files(str(f))
                if last_file:
                    src.add_dependency_on(last_file)
                last_file = src
                files.remove(f.as_posix())

    # Add remaining files that were not in the order list
    for designfile in files:
        src = library.add_source_files(str(designfile))
        if last_file:
            src.add_dependency_on(last_file)
        last_file = src


# Setup logger
logger.remove()

# Open Xibif Project
project = XibifProject()
if __file__ != "<stdin>":
    project.path = XibifPath(__file__).parent.resolve()
else:
    project.path = XibifPath.cwd()

print(f"Loading xibif project from {project.path}")
project.load_config()
XibifPath.set_root(project.path.absolute().resolve())

# Create VUnit instance by parsing command line arguments
# Check if additional arguments are provided
additional_args = ["-k", "--compile"]
argv = sys.argv[1:] + additional_args
vu = VUnit.from_argv(argv=argv)
vu.add_vhdl_builtins()

# Add logger filter to suppress specific warnings
LOGGER.addFilter(FilterPrimaryDesignAll())

# A container for all libraries in the VUnit framework
libraries = {}

# Create libraries
libraries["unisim"] = vu.add_library("unisim")
libraries["unifast"] = vu.add_library("unifast")
libraries["secureip"] = vu.add_library("secureip")
libraries["unimacro"] = vu.add_library("unimacro")

vivado_path = get_xilinx_tool_paths(xilinx_path=project.tooling.xilinx_path, xilinx_version=project.tooling.xilinx_version).vivado
unisim_root = vivado_path.parent.parent.joinpath("data/vhdl/src/unisims")
unifast_root = vivado_path.parent.parent.joinpath("data/vhdl/src/unifast")
unimacro_root = vivado_path.parent.parent.joinpath("data/vhdl/src/unimacro")
secureip1_root = vivado_path.parent.parent.joinpath("data/vhdl/src/unisims/secureip")
secureip2_root = vivado_path.parent.parent.joinpath("data/vhdl/src/unifast/secureip")

# Add files in order
libraries["unisim"].add_source_files(str(unisim_root.joinpath("unisim_VPKG.vhd")))
libraries["unisim"].add_source_files(str(unisim_root.joinpath("unisim_retarget_VCOMP.vhd")))
add_files_with_order(libraries["unisim"], unisim_root.joinpath("primitive"))
add_files_with_order(libraries["unisim"], unisim_root.joinpath("retarget"))
add_files_with_order(libraries["unifast"], unifast_root.joinpath("primitive"))
add_files_with_order(libraries["unimacro"], unimacro_root)
add_files_with_order(libraries["secureip"], secureip1_root)
add_files_with_order(libraries["secureip"], secureip2_root)

print("------------------------------------------")
print("--------     Run Compilation      --------")
print("------------------------------------------")

# Enable coverage
vu.set_compile_option("nvc.a_flags", ["--relaxed"])
vu.set_compile_option("nvc.global_flags", ["-M", "1g"])
vu.set_compile_option("ghdl.a_flags", ["-frelaxed-rules", "-Wno-hide", "-Wno-shared", "-fsynopsys"])
vu.set_compile_option("modelsim.vcom_flags", ["+cover"])
vu.set_compile_option("modelsim.vlog_flags", ["+cover"])
vu.set_compile_option("enable_coverage", True)

# Run vunit function
vu.main()
