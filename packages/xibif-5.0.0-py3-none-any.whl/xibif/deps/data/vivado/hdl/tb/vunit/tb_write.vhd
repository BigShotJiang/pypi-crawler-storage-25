-- ----------------------------------------------------------------------------------------------------
-- brief: Testbench for entity Xibif_write
-- file: XiBIF_write_tb.vhd
-- author: lukas.leuenberger
-- ----------------------------------------------------------------------------------------------------
-- Copyright(c) 2025 by OST, Switzerland
-- All rights reserved.
-- ----------------------------------------------------------------------------------------------------
-- File history:
-- Version, Date, Author, Remarks
-- ----------------------------------------------------------------------------------------------------
-- 0.1, 03.10.2025, lukas.leuenberger, Auto-Created with hdltbgen 1.0.9
-- ----------------------------------------------------------------------------------------------------

-- Standard library ieee
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;
use std.textio.all;
use ieee.std_logic_textio.all;
use ieee.math_real.all;

-- VUnit test library
library vunit_lib;
context vunit_lib.vunit_context;

library olo;
use olo.olo_base_pkg_math.all;

-- This block implements the testbench for the block **Xibif_write**.
entity tb_write is
    generic(
        runner_cfg : string := runner_cfg_default; -- Generic for VUnit -- @suppress
        tb_path    : string := "hw\tb\vunit" -- Generic for VUnit -- @suppress
    );
end entity tb_write;

-- This is the testbench architecture of the **Xibif_write** block.
architecture tb of tb_write is
    ----------------------------------------------------------------------------------------------------
    -- Internal constants
    ----------------------------------------------------------------------------------------------------
    constant F_CLK_C : real := 100.0E6; -- Define the frequency of the clock
    constant T_CLK_C : time := (1.0 sec) / F_CLK_C; -- Calculate the period of a clockcycle
    constant DTS_C   : time := 1 ns;    -- Define a delta time for signal changes
    constant DTR_C   : time := 8 ns;    -- Define a delta time for signal changes

    constant FIFO_DEPTH_G_C     : positive := 512; -- Constant for the generic FIFO_DEPTH_G
    constant AXI_ADDR_WIDTH_G_C : positive := 16; -- Constant for the generic AXI_ADDR_WIDTH_G
    constant AXI_DATA_WIDTH_G_C : positive := 16; -- Constant for the generic AXI_DATA_WIDTH_G
    constant WORD_LEN_C         : integer  := AXI_DATA_WIDTH_G_C / 8; -- Word length in bytes

    constant NUM_TEST_RUNS_C : integer := 500; -- Number of times to run the random test

    ----------------------------------------------------------------------------------------------------
    -- Internal signals
    ----------------------------------------------------------------------------------------------------    
    -- Input signals
    signal tb_ClkxCI        : std_logic; -- Internal signal for input signal ClkxCI @suppress
    signal tb_RstxRBI       : std_logic; -- Internal signal for input signal RstxRBI @suppress
    signal tb_SoftReset     : std_logic; -- Internal signal for input signal SoftResetxRBI @suppress
    signal tb_CmdWr_Ready   : std_logic; -- Internal signal for input signal CmdWr_Ready @suppress
    signal tb_Wr_Done       : std_logic; -- Internal signal for input signal Wr_Done @suppress
    signal tb_Wr_Error      : std_logic; -- Internal signal for input signal Wr_Error @suppress
    signal tb_Wr_FIFO_Level : std_logic_vector(log2ceil(FIFO_DEPTH_G_C + 1) - 1 downto 0); -- Internal signal for input signal Wr_FIFO_Level @suppress
    signal tb_MemLow        : std_logic_vector(AXI_ADDR_WIDTH_G_C - 1 downto 0); -- Internal signal for input signal MemLowxDI @suppress
    signal tb_MemHigh       : std_logic_vector(AXI_ADDR_WIDTH_G_C - 1 downto 0); -- Internal signal for input signal MemHighxDI @suppress
    signal tb_Tail          : std_logic_vector(AXI_ADDR_WIDTH_G_C - 1 downto 0); -- Internal signal for input signal TailxDO @suppress

    -- Output signals
    signal tb_CmdWr_Addr    : std_logic_vector(AXI_ADDR_WIDTH_G_C - 1 downto 0); -- Internal signal for output signal CmdWr_Addr @suppress
    signal tb_CmdWr_Size    : std_logic_vector(log2ceil(FIFO_DEPTH_G_C + 1) - 1 downto 0); -- Internal signal for output signal CmdWr_Size @suppress
    signal tb_CmdWr_Valid   : std_logic; -- Internal signal for output signal CmdWr_Valid @suppress
    signal tb_Head          : std_logic_vector(AXI_ADDR_WIDTH_G_C - 1 downto 0); -- Internal signal for output signal HeadxDO @suppress
    signal tb_ErrorMemFull  : std_logic; -- Internal signal for output signal ErrorMemFullxDO @suppress
    signal tb_ErrorAXIWrite : std_logic; -- Internal signal for output signal ErrorAXIWritexDO @suppress
    signal tb_SoftResetDone : std_logic; -- Internal signal for output signal SoftResetDonexDO @suppress

    ----------------------------------------------------------------------------------------------------
    -- Internal constants, types and functions to convert a vector to a string
    ----------------------------------------------------------------------------------------------------
    type     charIndexedByMVL9_t is array (std_ulogic) of character; -- Type to convert a vector to a string
    constant MVL9_TO_CHAR_C      : charIndexedByMVL9_t := "UX01ZWLH-"; -- Constant to convert a vector to a string

    -- This function converts a std_ulogic_vector into a string.
    function to_string_std_ulogic_vector(value : std_ulogic_vector) return STRING is -- @suppress
        alias    ivalue   : std_ulogic_vector(1 to value'length) is value;
        variable result_v : string(1 to value'length + 2);
    begin
        if value'length < 1 then
            return "";
        else
            result_v(1)                := ''';
            result_v(value'length + 2) := ''';
            for i in ivalue'range loop
                result_v(i + 1) := MVL9_TO_CHAR_C(ivalue(i));
            end loop;
            return result_v;
        end if;
    end function to_string_std_ulogic_vector;

    -- This function converts a std_logic_vector into a string.
    function to_string_std_logic_vector(value : std_logic_vector) return string is -- @suppress
    begin
        return to_string_std_ulogic_vector(to_stdulogicvector(value));
    end function to_string_std_logic_vector;

    -- This function converts an unsigned value into a string.
    function to_string_unsigned(value : unsigned) return string is -- @suppress
    begin
        return to_string_std_ulogic_vector(std_ulogic_vector(value)) & " / " & Integer'image(to_integer(value));
    end function to_string_unsigned;

    -- This function converts a signed value into a string.
    function to_string_signed(value : signed) return string is -- @suppress
    begin
        return to_string_std_ulogic_vector(std_ulogic_vector(value)) & " / " & Integer'image(to_integer(value));
    end function to_string_signed;

    -- This function converts an integer value into a string.
    function to_string_integer(value : integer) return string is -- @suppress
    begin
        return Integer'image(value);
    end function to_string_integer;

    -- This function converts a positive value into a string.
    function to_string_positive(value : positive) return string is -- @suppress
    begin
        return Integer'image(value);
    end function to_string_positive;

    -- This function converts a natural value into a string.
    function to_string_natural(value : natural) return string is -- @suppress
    begin
        return Integer'image(value);
    end function to_string_natural;

    -- This function converts a std_logic value into a string.
    function to_string_std_logic(value : std_logic) return string is -- @suppress
    begin
        return std_logic'image(value);
    end function to_string_std_logic;

    -- This function converts a std_ulogic value into a string.
    function to_string_std_ulogic(value : std_ulogic) return string is -- @suppress
    begin
        return std_ulogic'image(value);
    end function to_string_std_ulogic;

begin
    -- Make a dut and map the ports to the correct signals
    inst_DUT : entity work.Xibif_write
        generic map(
            FIFO_DEPTH_G     => FIFO_DEPTH_G_C, -- Map the generic FIFO_DEPTH_G to the constant FIFO_DEPTH_G_C
            AXI_ADDR_WIDTH_G => AXI_ADDR_WIDTH_G_C, -- Map the generic AXI_ADDR_WIDTH_G to the constant AXI_ADDR_WIDTH_G_C
            AXI_DATA_WIDTH_G => AXI_DATA_WIDTH_G_C -- Map the generic AXI_DATA_WIDTH_G to the constant AXI_DATA_WIDTH_G_C
        )
        port map(
            ClkxCI        => tb_ClkxCI, -- Map the signal tb_ClkxCI to the port ClkxCI
            RstxRBI       => tb_RstxRBI, -- Map the signal tb_RstxRBI to the port RstxRBI
            SoftReset     => tb_SoftReset, -- Map the signal tb_SoftResetxRBI to the port SoftResetxRBI
            SoftResetDone => tb_SoftResetDone, -- Map the signal tb_SoftResetDonexDO to the port SoftResetDonexDO
            CmdWr_Addr    => tb_CmdWr_Addr, -- Map the signal tb_CmdWr_Addr to the port CmdWr_Addr
            CmdWr_Size    => tb_CmdWr_Size, -- Map the signal tb_CmdWr_Size to the port CmdWr_Size
            CmdWr_Valid   => tb_CmdWr_Valid, -- Map the signal tb_CmdWr_Valid to the port CmdWr_Valid
            CmdWr_Ready   => tb_CmdWr_Ready, -- Map the signal tb_CmdWr_Ready to the port CmdWr_Ready
            Wr_Done       => tb_Wr_Done, -- Map the signal tb_Wr_Done to the port Wr_Done
            Wr_Error      => tb_Wr_Error, -- Map the signal tb_Wr_Error to the port Wr_Error
            Wr_FIFOLevel  => tb_Wr_FIFO_Level, -- Map the signal tb_Wr_FIFO_Level to the port Wr_FIFO_Level
            MemLow        => tb_MemLow, -- Map the signal tb_MemLowxDI to the port MemLowxDI
            MemHigh       => tb_MemHigh, -- Map the signal tb_MemHighxDI to the port MemHighxDI
            Tail          => tb_Tail,   -- Map the signal tb_TailxDO to the port TailxDO
            Head          => tb_Head,   -- Map the signal tb_HeadxDO to the port HeadxDO
            ErrorMemFull  => tb_ErrorMemFull, -- Map the signal tb_ErrorMemFullxDO to the port ErrorMemFullxDO
            ErrorAXIWrite => tb_ErrorAXIWrite -- Map the signal tb_ErrorAXIWritexDO to the port ErrorAXIWritexDO
        );

    -- Apply a clock to the DUT
    proc_stimuliClk : process
    begin
        tb_ClkxCI <= '0';
        loop
            wait for (T_CLK_C / 2.0);
            tb_ClkxCI <= not tb_ClkxCI;
        end loop;
        wait;
    end process;

    -- Watchdog
    test_runner_watchdog(runner, 100 ms);

    -- Apply the testvectors to the DUT
    proc_applyTestvector : process
        -- Variables for random wraparound test  
        variable seed1_v, seed2_v     : integer range 1 to integer'high := 1;
        variable memLowVal_v          : natural range 0 to 2 ** AXI_ADDR_WIDTH_G_C - 1;
        variable memHighVal_v         : natural range 0 to 2 ** AXI_ADDR_WIDTH_G_C - 1;
        variable tailVal_v            : natural range 0 to 2 ** AXI_ADDR_WIDTH_G_C - 1;
        variable fifoLevel_v          : natural range 0 to FIFO_DEPTH_G_C;
        variable initialHead_v        : natural range 0 to 2 ** AXI_ADDR_WIDTH_G_C - 1;
        variable currentHead_v        : natural range 0 to 2 ** AXI_ADDR_WIDTH_G_C - 1;
        variable wraparoundOccurred_v : boolean                         := false;
        variable cmdAddr_v            : natural range 0 to 2 ** AXI_ADDR_WIDTH_G_C - 1;
        variable cmdSize_v            : natural range 0 to FIFO_DEPTH_G_C;
        variable delayCycles_v        : natural range 0 to 20;
        variable expectedHead_v       : natural range 0 to 2 ** AXI_ADDR_WIDTH_G_C - 1;
        variable bytesWritten_v       : natural range 0 to FIFO_DEPTH_G_C * WORD_LEN_C;

        -- Random natural number in range [min_val, max_val]
        impure function rand_natural(min_val : natural; max_val : natural) return natural is
            variable r_v : real;
        begin
            uniform(seed1_v, seed2_v, r_v);
            return min_val + integer(r_v * real(max_val - min_val));
        end function;

        -- Random memory address within given range (word-aligned)
        impure function rand_mem_addr(low_addr : natural; high_addr : natural) return natural is
            variable r_v          : real;
            variable addrRange_v : natural range 0 to 1048576;
        begin
            uniform(seed1_v, seed2_v, r_v);
            addrRange_v := (high_addr - low_addr) / WORD_LEN_C;
            return low_addr + (integer(r_v * real(addrRange_v)) * WORD_LEN_C);
        end function;

        -- Random FIFO level within given maximum
        impure function rand_fifo_level(max_level : natural) return natural is
        begin
            return integer(rand_natural(0, max_level));
        end function;

        -- Random tail position behind current head for circular buffer (for write operations)
        impure function rand_tail_position(current_head : natural; mem_low : natural; mem_high : natural) return natural is
            variable r_v : real;
        begin
            uniform(seed1_v, seed2_v, r_v);
            if current_head > mem_low + WORD_LEN_C then
                -- Head is not at beginning, place tail behind head
                return mem_low + integer(r_v * real((current_head - mem_low) / WORD_LEN_C)) * WORD_LEN_C;
            else
                -- Head is near beginning, wrap tail to end
                return current_head + WORD_LEN_C + integer(r_v * real((mem_high - current_head - WORD_LEN_C) / WORD_LEN_C)) * WORD_LEN_C;
            end if;
        end function;
    begin
        -- Setup the VUnit Runner
        test_runner_setup(runner, runner_cfg);

        -- Set all signals to a default value
        tb_RstxRBI       <= '1';
        tb_SoftReset     <= '1';
        tb_CmdWr_Ready   <= '0';
        tb_Wr_Done       <= '0';
        tb_Wr_Error      <= '0';
        tb_Wr_FIFO_Level <= (others => '0');
        tb_MemLow        <= (others => '0');
        tb_MemHigh       <= (others => '0');
        tb_Tail          <= (others => '0');

        while test_suite loop
            -- Reset DUT
            tb_RstxRBI <= '0';          -- Perform a positive reset (active high)
            wait until (rising_edge(tb_ClkxCI)); -- Wait for the first active clock edge
            tb_RstxRBI <= '1';          -- Clear the positive reset

            if run("write_single_value_ready") then
                for memLow in 0 to 16 loop
                    -- Apply  memLow, memHigh and tail pointer BEFORE reset
                    wait for DTS_C;
                    tb_MemLow        <= std_logic_vector(to_unsigned(memLow * WORD_LEN_C, AXI_ADDR_WIDTH_G_C));
                    tb_MemHigh       <= std_logic_vector(to_unsigned((memLow + 10) * WORD_LEN_C, AXI_ADDR_WIDTH_G_C));
                    tb_Tail          <= std_logic_vector(to_unsigned(memLow * WORD_LEN_C, AXI_ADDR_WIDTH_G_C));
                    tb_Wr_FIFO_Level <= std_logic_vector(to_unsigned(1, log2ceil(FIFO_DEPTH_G_C + 1)));

                    -- Reset DUT
                    tb_RstxRBI <= '0';  -- Perform a positive reset (active high)
                    wait until (rising_edge(tb_ClkxCI)); -- Wait for the first active clock edge                    
                    tb_RstxRBI <= '1';  -- Clear the positive reset
                    wait until (rising_edge(tb_ClkxCI)); -- Wait for reset to be processed

                    -- Check the head pointer after reset
                    wait for DTS_C + DTR_C;
                    check_equal(tb_Head, std_logic_vector(to_unsigned(memLow * WORD_LEN_C, AXI_ADDR_WIDTH_G_C)), "HeadxDO after reset wrong");
                    wait until (rising_edge(tb_ClkxCI));

                    -- We are ready to accept commands
                    wait for DTS_C;
                    tb_CmdWr_Ready <= '1';
                    tb_Wr_Done     <= '0';
                    tb_Wr_Error    <= '0';
                    wait until (rising_edge(tb_ClkxCI));

                    -- Wait for command to be issued
                    wait until (rising_edge(tb_ClkxCI));
                    wait for DTS_C + DTR_C;
                    check_equal(tb_CmdWr_Valid, '1', "CmdWr_Valid should be '1'");
                    check_equal(tb_CmdWr_Addr, std_logic_vector(to_unsigned(memLow * WORD_LEN_C, AXI_ADDR_WIDTH_G_C)), "CmdWr_Addr");
                    check_equal(tb_CmdWr_Size, std_logic_vector(to_unsigned(1, log2ceil(FIFO_DEPTH_G_C + 1))), "CmdWr_Size");
                    check_equal(tb_Head, std_logic_vector(to_unsigned(memLow * WORD_LEN_C, AXI_ADDR_WIDTH_G_C)), "HeadxDO");
                    check_equal(tb_ErrorMemFull, '0', "ErrorMemFullxDO");
                    check_equal(tb_ErrorAXIWrite, '0', "ErrorAXIWritexDO");

                    -- Disable ready and indicate that the command is done
                    wait for DTS_C;
                    tb_CmdWr_Ready <= '0';
                    wait until (rising_edge(tb_ClkxCI));
                    wait for DTS_C;
                    tb_Wr_Done     <= '1'; -- Command is done
                    wait until (rising_edge(tb_ClkxCI));
                    wait for DTS_C;
                    tb_Wr_Done     <= '0';
                    wait until (rising_edge(tb_ClkxCI)); -- Wait for state to change back to IDLE

                end loop;

            elsif run("write_burst_data") then
                -- Test writing multiple words in burst
                tb_MemLow        <= std_logic_vector(to_unsigned(0, AXI_ADDR_WIDTH_G_C));
                tb_MemHigh       <= std_logic_vector(to_unsigned(1024, AXI_ADDR_WIDTH_G_C));
                tb_Tail          <= std_logic_vector(to_unsigned(512, AXI_ADDR_WIDTH_G_C));
                tb_Wr_FIFO_Level <= std_logic_vector(to_unsigned(10, log2ceil(FIFO_DEPTH_G_C + 1))); -- 10 words available

                -- Reset DUT
                tb_RstxRBI <= '0';
                wait until (rising_edge(tb_ClkxCI));
                tb_RstxRBI <= '1';
                wait until (rising_edge(tb_ClkxCI));

                -- Start write operation
                wait for DTS_C;
                tb_CmdWr_Ready <= '1';
                wait until (rising_edge(tb_ClkxCI));

                -- Check command parameters
                wait until (rising_edge(tb_ClkxCI));
                wait for DTS_C + DTR_C;
                check_equal(tb_CmdWr_Valid, '1', "CmdWr_Valid should be '1' for burst");
                check_equal(tb_CmdWr_Addr, std_logic_vector(to_unsigned(0, AXI_ADDR_WIDTH_G_C)), "CmdWr_Addr for burst");
                check_equal(tb_CmdWr_Size, std_logic_vector(to_unsigned(10, log2ceil(FIFO_DEPTH_G_C + 1))), "CmdWr_Size should be 10");

                -- Complete the transaction
                wait for DTS_C;
                tb_CmdWr_Ready <= '0';
                wait until (rising_edge(tb_ClkxCI));
                wait for DTS_C;
                tb_Wr_Done     <= '1';
                wait until (rising_edge(tb_ClkxCI));
                wait for DTS_C;
                tb_Wr_Done     <= '0';
                wait until (rising_edge(tb_ClkxCI));

                -- Check head pointer updated correctly
                wait for DTS_C + DTR_C;
                check_equal(tb_Head, std_logic_vector(to_unsigned(10 * WORD_LEN_C, AXI_ADDR_WIDTH_G_C)), "HeadxDO after burst write (10*WORD_LEN_C)");

            elsif run("write_memory_full_error") then
                -- Test memory full condition
                tb_MemLow        <= std_logic_vector(to_unsigned(0, AXI_ADDR_WIDTH_G_C));
                tb_MemHigh       <= std_logic_vector(to_unsigned(1024, AXI_ADDR_WIDTH_G_C));
                tb_Tail          <= std_logic_vector(to_unsigned(2 * WORD_LEN_C, AXI_ADDR_WIDTH_G_C)); -- Tail very close to head
                tb_Wr_FIFO_Level <= std_logic_vector(to_unsigned(5, log2ceil(FIFO_DEPTH_G_C + 1))); -- Want to write 5 words

                -- Reset DUT
                tb_RstxRBI <= '0';
                wait until (rising_edge(tb_ClkxCI));
                tb_RstxRBI <= '1';
                wait until (rising_edge(tb_ClkxCI));

                -- Start write operation
                wait for DTS_C;
                tb_CmdWr_Ready <= '1';
                wait until (rising_edge(tb_ClkxCI));

                -- Check that memory full error is detected
                wait until (rising_edge(tb_ClkxCI));
                wait for DTS_C + DTR_C;
                check_equal(tb_CmdWr_Valid, '1', "CmdWr_Valid should be '1' even with memory full");
                check_equal(tb_CmdWr_Size, std_logic_vector(to_unsigned(1, log2ceil(FIFO_DEPTH_G_C + 1))), "CmdWr_Size should be limited to 1 word");
                check_equal(tb_ErrorMemFull, '0', "ErrorMemFull should be '0'");

                -- Complete the transaction
                wait for DTS_C;
                tb_CmdWr_Ready <= '0';
                wait until (rising_edge(tb_ClkxCI));
                wait for DTS_C;
                tb_Wr_Done     <= '1';
                wait until (rising_edge(tb_ClkxCI));
                wait for DTS_C;
                tb_Wr_Done     <= '0';
                tb_CmdWr_Ready <= '1';
                wait until (rising_edge(tb_ClkxCI));

                -- Check memory full error is now set
                wait for DTS_C + DTR_C;
                check_equal(tb_ErrorMemFull, '1', "ErrorMemFull should be '1' after memory full condition");

            elsif run("write_axi_error_handling") then
                -- Test AXI error handling
                tb_MemLow        <= std_logic_vector(to_unsigned(0, AXI_ADDR_WIDTH_G_C));
                tb_MemHigh       <= std_logic_vector(to_unsigned(1024, AXI_ADDR_WIDTH_G_C));
                tb_Tail          <= std_logic_vector(to_unsigned(512, AXI_ADDR_WIDTH_G_C));
                tb_Wr_FIFO_Level <= std_logic_vector(to_unsigned(3, log2ceil(FIFO_DEPTH_G_C + 1)));

                -- Reset DUT
                tb_RstxRBI <= '0';
                wait until (rising_edge(tb_ClkxCI));
                tb_RstxRBI <= '1';
                wait until (rising_edge(tb_ClkxCI));

                -- Start write operation
                wait for DTS_C;
                tb_CmdWr_Ready <= '1';
                wait until (rising_edge(tb_ClkxCI));
                wait until (rising_edge(tb_ClkxCI));

                -- Simulate AXI error
                wait for DTS_C;
                tb_CmdWr_Ready <= '0';
                wait until (rising_edge(tb_ClkxCI));
                wait for DTS_C;
                tb_Wr_Error    <= '1';
                wait until (rising_edge(tb_ClkxCI));

                -- Check error is captured
                wait for DTS_C + DTR_C;
                check_equal(tb_ErrorAXIWrite, '1', "ErrorAXIWritexDO should be '1' after AXI error");

                tb_Wr_Error <= '0';
                wait until (rising_edge(tb_ClkxCI));

            elsif run("write_address_wraparound") then
                -- Test address wraparound at memory boundary
                tb_MemLow        <= std_logic_vector(to_unsigned(25 * WORD_LEN_C, AXI_ADDR_WIDTH_G_C));
                tb_MemHigh       <= std_logic_vector(to_unsigned(30 * WORD_LEN_C, AXI_ADDR_WIDTH_G_C));
                tb_Tail          <= std_logic_vector(tb_MemLow);
                tb_Wr_FIFO_Level <= std_logic_vector(to_unsigned(8, log2ceil(FIFO_DEPTH_G_C + 1))); -- Want to write 8 words

                -- Reset DUT
                tb_RstxRBI <= '0';
                wait until (rising_edge(tb_ClkxCI));
                tb_RstxRBI <= '1';
                wait until (rising_edge(tb_ClkxCI));

                -- Check initial head position
                wait for DTS_C + DTR_C;
                check_equal(tb_Head, std_logic_vector(to_unsigned(25 * WORD_LEN_C, AXI_ADDR_WIDTH_G_C)), "Initial head position");

                -- Start write operation
                tb_CmdWr_Ready <= '1';
                wait until (rising_edge(tb_ClkxCI));

                -- Check command is limited by memory boundary
                wait until (rising_edge(tb_ClkxCI));
                wait for DTS_C + DTR_C;
                check_equal(tb_CmdWr_Valid, '1', "CmdWr_Valid should be '1'");
                check_equal(tb_CmdWr_Size, std_logic_vector(to_unsigned(6, log2ceil(FIFO_DEPTH_G_C + 1))), "CmdWr_Size should be limited by memory boundary (30-25+1=6 words)");

                -- Complete the transaction
                wait for DTS_C;
                tb_CmdWr_Ready   <= '0';
                wait until (rising_edge(tb_ClkxCI));
                wait for DTS_C;
                tb_Wr_FIFO_Level <= std_logic_vector(to_unsigned(3, log2ceil(FIFO_DEPTH_G_C + 1))); -- Want to write  3 more words
                tb_Wr_Done       <= '1';
                wait until (rising_edge(tb_ClkxCI));
                wait for DTS_C;
                tb_Wr_Done       <= '0';
                wait until (rising_edge(tb_ClkxCI));

                -- Check wraparound occurred
                wait for DTR_C;
                check_equal(tb_Head, std_logic_vector(to_unsigned(25 * WORD_LEN_C, AXI_ADDR_WIDTH_G_C)), "Head should wrap around to MemLow");

                -- Start another write operation
                wait for DTS_C;
                tb_CmdWr_Ready <= '1';
                wait until (rising_edge(tb_ClkxCI));
                wait until (rising_edge(tb_ClkxCI));
                wait for DTS_C + DTR_C;
                check_equal(tb_CmdWr_Valid, '1', "CmdWr_Valid should be '1' for second write");
                check_equal(tb_CmdWr_Size, std_logic_vector(to_unsigned(3, log2ceil(FIFO_DEPTH_G_C + 1))), "CmdWr_Size should be 3 for second write");
                check_equal(tb_CmdWr_Addr, std_logic_vector(to_unsigned(25 * WORD_LEN_C, AXI_ADDR_WIDTH_G_C)), "CmdWr_Addr should wrap around to MemLow");

                -- Complete the transaction
                wait for DTS_C;
                tb_CmdWr_Ready <= '0';
                wait until (rising_edge(tb_ClkxCI));
                wait for DTS_C;
                tb_Wr_Done     <= '1';
                wait until (rising_edge(tb_ClkxCI));
                wait for DTS_C;
                tb_Wr_Done     <= '0';
                wait until (rising_edge(tb_ClkxCI));

            elsif run("write_no_data_available") then
                -- Test behavior when no data is available in FIFO
                tb_MemLow        <= std_logic_vector(to_unsigned(0, AXI_ADDR_WIDTH_G_C));
                tb_MemHigh       <= std_logic_vector(to_unsigned(1024, AXI_ADDR_WIDTH_G_C));
                tb_Tail          <= std_logic_vector(to_unsigned(512, AXI_ADDR_WIDTH_G_C));
                tb_Wr_FIFO_Level <= std_logic_vector(to_unsigned(0, log2ceil(FIFO_DEPTH_G_C + 1))); -- No data available

                -- Reset DUT
                tb_RstxRBI <= '0';
                wait until (rising_edge(tb_ClkxCI));
                tb_RstxRBI <= '1';
                wait until (rising_edge(tb_ClkxCI));

                -- Try to start write operation
                wait for DTS_C;
                tb_CmdWr_Ready <= '1';
                wait until (rising_edge(tb_ClkxCI));
                wait until (rising_edge(tb_ClkxCI));
                wait for DTS_C + DTR_C;

                -- Check that no command is issued
                check_equal(tb_CmdWr_Valid, '0', "CmdWr_Valid should be '0' when no data available");
                check_equal(tb_ErrorMemFull, '0', "ErrorMemFullxDO should be '0'");
                check_equal(tb_ErrorAXIWrite, '0', "ErrorAXIWritexDO should be '0'");

            elsif run("write_master_not_ready") then
                -- Test behavior when AXI master is not ready
                tb_MemLow        <= std_logic_vector(to_unsigned(0, AXI_ADDR_WIDTH_G_C));
                tb_MemHigh       <= std_logic_vector(to_unsigned(1024, AXI_ADDR_WIDTH_G_C));
                tb_Tail          <= std_logic_vector(to_unsigned(512, AXI_ADDR_WIDTH_G_C));
                tb_Wr_FIFO_Level <= std_logic_vector(to_unsigned(5, log2ceil(FIFO_DEPTH_G_C + 1))); -- Data available

                -- Reset DUT
                tb_RstxRBI <= '0';
                wait until (rising_edge(tb_ClkxCI));
                tb_RstxRBI <= '1';
                wait until (rising_edge(tb_ClkxCI));

                -- Keep master not ready
                wait for DTS_C;
                tb_CmdWr_Ready <= '0';
                wait until (rising_edge(tb_ClkxCI));
                wait for DTS_C + DTR_C;

                -- Check that no command is issued
                check_equal(tb_CmdWr_Valid, '0', "CmdWr_Valid should be '0' when master not ready");

                -- Now make master ready
                tb_CmdWr_Ready <= '1';
                wait until (rising_edge(tb_ClkxCI));
                wait until (rising_edge(tb_ClkxCI));
                wait for DTS_C + DTR_C;

                -- Check that command is now issued
                check_equal(tb_CmdWr_Valid, '1', "CmdWr_Valid should be '1' when master becomes ready");

            elsif run("error_persistence_test") then
                -- Test that errors persist until reset
                tb_MemLow        <= std_logic_vector(to_unsigned(0, AXI_ADDR_WIDTH_G_C));
                tb_MemHigh       <= std_logic_vector(to_unsigned(1024, AXI_ADDR_WIDTH_G_C));
                tb_Tail          <= std_logic_vector(to_unsigned(4, AXI_ADDR_WIDTH_G_C)); -- Very close tail for memory full
                tb_Wr_FIFO_Level <= std_logic_vector(to_unsigned(5, log2ceil(FIFO_DEPTH_G_C + 1)));

                -- Reset DUT
                tb_RstxRBI <= '0';
                wait until (rising_edge(tb_ClkxCI));
                tb_RstxRBI <= '1';
                wait until (rising_edge(tb_ClkxCI));

                -- Trigger memory full error
                tb_CmdWr_Ready <= '1';
                wait until (rising_edge(tb_ClkxCI));
                wait until (rising_edge(tb_ClkxCI));
                wait for DTS_C + DTR_C;

                -- Complete transaction
                wait for DTS_C;
                tb_CmdWr_Ready <= '0';
                wait until (rising_edge(tb_ClkxCI));
                wait for DTS_C;
                tb_Wr_Done     <= '1';
                wait until (rising_edge(tb_ClkxCI));
                wait for DTS_C;
                tb_Wr_Done     <= '0';
                wait until (rising_edge(tb_ClkxCI));

                -- Check error not yet set
                check_equal(tb_ErrorMemFull, '0', "Memory full error should not be set yet");

                -- Start a new transaction that should trigger memory full
                wait for DTS_C;
                tb_CmdWr_Ready <= '1';
                wait until (rising_edge(tb_ClkxCI));

                -- Check error persists
                wait until (rising_edge(tb_ClkxCI));
                wait for DTS_C + DTR_C;
                check_equal(tb_ErrorMemFull, '1', "Memory full error should be set after second write");

                -- Reset should clear error
                tb_RstxRBI <= '0';
                wait until (rising_edge(tb_ClkxCI));
                tb_RstxRBI <= '1';
                wait until (rising_edge(tb_ClkxCI));
                wait for DTS_C + DTR_C;
                check_equal(tb_ErrorMemFull, '0', "Memory full error should be cleared after reset");

            elsif run("softreset_functionality") then
                -- Test soft reset functionality
                tb_MemLow        <= std_logic_vector(to_unsigned(100, AXI_ADDR_WIDTH_G_C));
                tb_MemHigh       <= std_logic_vector(to_unsigned(1024, AXI_ADDR_WIDTH_G_C));
                tb_Tail          <= std_logic_vector(to_unsigned(500, AXI_ADDR_WIDTH_G_C));
                tb_Wr_FIFO_Level <= std_logic_vector(to_unsigned(5, log2ceil(FIFO_DEPTH_G_C + 1)));

                -- Initial hard reset
                tb_RstxRBI <= '0';
                wait until (rising_edge(tb_ClkxCI));
                tb_RstxRBI <= '1';
                wait until (rising_edge(tb_ClkxCI));

                -- Check initial head position after hard reset
                wait for DTS_C + DTR_C;
                check_equal(tb_Head, std_logic_vector(to_unsigned(100, AXI_ADDR_WIDTH_G_C)), "Initial head position after hard reset");
                check_equal(tb_SoftResetDone, '0', "SoftResetDone should be '0' in IDLE state");

                -- Execute a write operation to change head position
                tb_CmdWr_Ready <= '1';
                wait until (rising_edge(tb_ClkxCI));
                wait until (rising_edge(tb_ClkxCI));
                wait for DTS_C + DTR_C;
                check_equal(tb_CmdWr_Valid, '1', "CmdWr_Valid should be '1'");

                -- Complete the write transaction
                tb_CmdWr_Ready <= '0';
                wait until (rising_edge(tb_ClkxCI));
                tb_Wr_Done     <= '1';
                wait until (rising_edge(tb_ClkxCI));
                tb_Wr_Done     <= '0';
                wait until (rising_edge(tb_ClkxCI));

                -- Check that head has moved
                wait for DTS_C + DTR_C;
                check(unsigned(tb_Head) > to_unsigned(100, AXI_ADDR_WIDTH_G_C), "Head should have moved from initial position");

                -- Now perform soft reset
                tb_SoftReset <= '0';    -- Assert soft reset (active low)
                wait until (rising_edge(tb_ClkxCI));
                wait until (rising_edge(tb_ClkxCI));

                -- Check that we're in RESET state
                wait for DTS_C + DTR_C;
                check_equal(tb_SoftResetDone, '1', "SoftResetDone should be '1' in RESET state");
                check_equal(tb_Head, std_logic_vector(to_unsigned(100, AXI_ADDR_WIDTH_G_C)), "Head should be reset to MemLow");

                -- Deassert soft reset
                tb_SoftReset <= '1';
                wait until (rising_edge(tb_ClkxCI));

                -- Check that we're back in IDLE state
                wait for DTS_C + DTR_C;
                check_equal(tb_SoftResetDone, '0', "SoftResetDone should be '0' after returning to IDLE");
                check_equal(tb_Head, std_logic_vector(to_unsigned(100, AXI_ADDR_WIDTH_G_C)), "Head should remain at MemLow after soft reset");

            elsif run("softreset_during_operation") then
                -- Test soft reset during active write operation
                tb_MemLow        <= std_logic_vector(to_unsigned(0, AXI_ADDR_WIDTH_G_C));
                tb_MemHigh       <= std_logic_vector(to_unsigned(1024, AXI_ADDR_WIDTH_G_C));
                tb_Tail          <= std_logic_vector(to_unsigned(512, AXI_ADDR_WIDTH_G_C));
                tb_Wr_FIFO_Level <= std_logic_vector(to_unsigned(10, log2ceil(FIFO_DEPTH_G_C + 1)));

                -- Initial reset
                tb_RstxRBI <= '0';
                wait until (rising_edge(tb_ClkxCI));
                tb_RstxRBI <= '1';
                wait until (rising_edge(tb_ClkxCI));

                -- Start a write operation
                tb_CmdWr_Ready <= '1';
                wait until (rising_edge(tb_ClkxCI));
                wait until (rising_edge(tb_ClkxCI));
                wait for DTS_C + DTR_C;
                check_equal(tb_CmdWr_Valid, '1', "CmdWr_Valid should be '1'");

                -- Accept the command but don't complete it yet
                tb_CmdWr_Ready <= '0';
                wait until (rising_edge(tb_ClkxCI));

                -- Now assert soft reset while in ISSUE_WRITE_CMD state
                tb_SoftReset <= '0';    -- Assert soft reset
                wait until (rising_edge(tb_ClkxCI));

                -- Check that we stay in this state
                wait for DTS_C + DTR_C;
                check_equal(tb_SoftResetDone, '0', "SoftResetDone should be '0' until current operation completes");

                -- Now complete the read operation
                tb_Wr_Done <= '1';
                wait until (rising_edge(tb_ClkxCI));
                tb_Wr_Done <= '0';
                wait until (rising_edge(tb_ClkxCI));
                wait until (rising_edge(tb_ClkxCI));

                -- Check that we are now in reset state
                wait for DTS_C + DTR_C;
                check_equal(tb_SoftResetDone, '1', "SoftResetDone should be '1' during soft reset");
                check_equal(tb_Head, std_logic_vector(to_unsigned(0, AXI_ADDR_WIDTH_G_C)), "Head should be reset to MemLow");
                check_equal(tb_CmdWr_Valid, '0', "CmdWr_Valid should be '0' during soft reset");

                -- Deassert soft reset
                tb_SoftReset <= '1';
                wait until (rising_edge(tb_ClkxCI));

                -- Check that we're back in IDLE state
                wait for DTS_C + DTR_C;
                check_equal(tb_SoftResetDone, '0', "SoftResetDone should be '0' after soft reset deasserted");

            elsif run("softreset_clears_errors") then
                -- Test that soft reset clears write errors
                tb_MemLow        <= std_logic_vector(to_unsigned(0, AXI_ADDR_WIDTH_G_C));
                tb_MemHigh       <= std_logic_vector(to_unsigned(1024, AXI_ADDR_WIDTH_G_C));
                tb_Tail          <= std_logic_vector(to_unsigned(512, AXI_ADDR_WIDTH_G_C));
                tb_Wr_FIFO_Level <= std_logic_vector(to_unsigned(5, log2ceil(FIFO_DEPTH_G_C + 1)));

                -- Initial reset
                tb_RstxRBI <= '0';
                wait until (rising_edge(tb_ClkxCI));
                tb_RstxRBI <= '1';
                wait until (rising_edge(tb_ClkxCI));

                -- Trigger an AXI write error
                tb_CmdWr_Ready <= '1';
                wait until (rising_edge(tb_ClkxCI));
                wait until (rising_edge(tb_ClkxCI));
                tb_CmdWr_Ready <= '0';
                wait until (rising_edge(tb_ClkxCI));
                tb_Wr_Error    <= '1';
                wait until (rising_edge(tb_ClkxCI));
                tb_Wr_Error    <= '0';
                wait until (rising_edge(tb_ClkxCI));

                -- Check that error is set
                wait for DTS_C + DTR_C;
                check_equal(tb_ErrorAXIWrite, '1', "ErrorAXIWrite should be '1' after error");

                -- Perform soft reset
                tb_SoftReset <= '0';    -- Assert soft reset
                wait until (rising_edge(tb_ClkxCI));
                wait until (rising_edge(tb_ClkxCI));
                wait for DTS_C + DTR_C;
                check_equal(tb_SoftResetDone, '1', "SoftResetDone should be '1'");

                -- Deassert soft reset
                tb_SoftReset <= '1';
                wait until (rising_edge(tb_ClkxCI));

                -- Check that error is cleared
                wait for DTS_C + DTR_C;
                check_equal(tb_ErrorAXIWrite, '0', "ErrorAXIWrite should be cleared after soft reset");

            elsif run("write_random_wraparound") then
                -- Test with random memory regions, FIFO levels and Tail positions 
                -- Run the test multiple times with different random configurations

                -- Run the test multiple times
                for run_count_v in 1 to NUM_TEST_RUNS_C loop
                    info("=== Starting test run " & integer'image(run_count_v) & " of " & integer'image(NUM_TEST_RUNS_C) & " ===");

                    -- Reset variables for this test run
                    wraparoundOccurred_v := false;

                    -- Generate random memory region (aligned to word boundaries)
                    -- Use reasonable address space: 0 to 64KB for testing
                    memLowVal_v  := rand_natural(0, 2 ** (AXI_ADDR_WIDTH_G_C - 1) / WORD_LEN_C) * WORD_LEN_C;
                    memHighVal_v := rand_natural(memLowVal_v / WORD_LEN_C + 10, 2 ** (AXI_ADDR_WIDTH_G_C) / WORD_LEN_C - 1) * WORD_LEN_C;

                    --info("Random memory region: Low=" & integer'image(mem_low_val_v) & ", High=" & integer'image(mem_high_val_v) & ", Size=" & integer'image((mem_high_val_v - mem_low_val_v) / WORD_LEN_C) & " words");

                    -- Set memory boundaries
                    tb_MemLow  <= std_logic_vector(to_unsigned(memLowVal_v, AXI_ADDR_WIDTH_G_C));
                    tb_MemHigh <= std_logic_vector(to_unsigned(memHighVal_v, AXI_ADDR_WIDTH_G_C));

                    -- Generate random initial tail position within memory region
                    tailVal_v := rand_mem_addr(memLowVal_v, memHighVal_v);
                    tb_Tail   <= std_logic_vector(to_unsigned(tailVal_v, AXI_ADDR_WIDTH_G_C));

                    -- Generate random initial FIFO level (data available for writing)
                    fifoLevel_v      := rand_fifo_level(FIFO_DEPTH_G_C); -- Data available in FIFO to write
                    tb_Wr_FIFO_Level <= std_logic_vector(to_unsigned(fifoLevel_v, log2ceil(FIFO_DEPTH_G_C + 1)));

                    --info("Initial setup: Tail=" & integer'image(tail_val_v) & ", FIFO_Level=" & integer'image(fifo_level_v));

                    -- Reset DUT for each test run to initialize head to MemLow
                    --info("Resetting DUT for test run " & integer'image(run_count_v));
                    tb_RstxRBI <= '0';
                    wait until (rising_edge(tb_ClkxCI));
                    tb_RstxRBI <= '1';
                    wait until (rising_edge(tb_ClkxCI));

                    -- Record initial head position
                    wait for DTS_C + DTR_C;
                    initialHead_v := to_integer(unsigned(tb_Head));
                    currentHead_v := initialHead_v;

                    --info("Initial head position: " & integer'image(initial_head_v));

                    -- Loop until wraparound occurs or max iterations reached
                    for iteration_count_v in 1 to 1000 loop

                        -- Generate new random tail position (must be behind current head for space to be available)
                        tailVal_v := rand_tail_position(currentHead_v, memLowVal_v, memHighVal_v);
                        tb_Tail   <= std_logic_vector(to_unsigned(tailVal_v, AXI_ADDR_WIDTH_G_C));

                        -- Generate new random FIFO level (data available for writing)
                        fifoLevel_v      := rand_fifo_level(FIFO_DEPTH_G_C / 2); -- Reasonable amount of data to write
                        tb_Wr_FIFO_Level <= std_logic_vector(to_unsigned(fifoLevel_v, log2ceil(FIFO_DEPTH_G_C + 1)));

                        --info("Run " & integer'image(run_count_v) & ", Iteration " & integer'image(iteration_count_v) & ": Tail=" & integer'image(tail_val_v) & ", Head=" & integer'image(current_head_v) & ", FIFO_Level=" & integer'image(fifo_level_v));

                        wait until (rising_edge(tb_ClkxCI));

                        -- Start write command if conditions are met (FIFO has data and space available)
                        if fifoLevel_v > 0 and tailVal_v /= currentHead_v then
                            tb_CmdWr_Ready <= '1';
                            wait until (rising_edge(tb_ClkxCI));

                            -- Wait for command to be issued (if any)
                            wait until (rising_edge(tb_ClkxCI));
                            wait for DTS_C + DTR_C;

                            if tb_CmdWr_Valid = '1' then
                                -- Extract command parameters for validation
                                cmdAddr_v := to_integer(unsigned(tb_CmdWr_Addr));
                                cmdSize_v := to_integer(unsigned(tb_CmdWr_Size));

                                --info("Command issued: Addr=" & integer'image(cmd_addr_v) & ", Size=" & integer'image(cmd_size_v));

                                -- Validation 1: CmdSize must be at least 1 and not exceed available FIFO data
                                check(cmdSize_v >= 1,
                                      "VALIDATION ERROR: CmdSize (" & integer'image(cmdSize_v) & ") must be at least 1");

                                -- Validation 2: CmdSize must not exceed available FIFO data
                                check(cmdSize_v <= fifoLevel_v,
                                      "VALIDATION ERROR: CmdSize (" & integer'image(cmdSize_v) & ") exceeds available FIFO data (" & integer'image(fifoLevel_v) & ")");

                                -- Validation 3: head + CmdSize should not exceed memory high boundary  
                                check((cmdAddr_v + (cmdSize_v - 1) * WORD_LEN_C) <= memHighVal_v,
                                      "VALIDATION ERROR: Command end (" & integer'image((cmdAddr_v + (cmdSize_v - 1) * WORD_LEN_C)) & ") exceeds memory high boundary (" & integer'image(memHighVal_v) & ")");

                                -- Accept the command
                                tb_CmdWr_Ready <= '0';
                                wait until (rising_edge(tb_ClkxCI));

                                -- Simulate command completion
                                wait for DTS_C;
                                tb_Wr_Done <= '1';
                                wait until (rising_edge(tb_ClkxCI));
                                wait for DTS_C;
                                tb_Wr_Done <= '0';
                                wait until (rising_edge(tb_ClkxCI));

                                -- Update current head position
                                wait for DTS_C + DTR_C;
                                wait until (rising_edge(tb_ClkxCI)); -- Extra wait for head update
                                wait for DTS_C;
                                currentHead_v := to_integer(unsigned(tb_Head));

                                --info("New head position: " & integer'image(current_head_v));

                                -- Validation 4: Check if head was correctly incremented
                                bytesWritten_v := cmdSize_v * WORD_LEN_C;

                                -- Calculate expected head position after write (like the hardware does)
                                expectedHead_v := cmdAddr_v + bytesWritten_v;

                                if expectedHead_v > memHighVal_v then
                                    -- Wraparound occurs when currHead >= MemHigh
                                    expectedHead_v       := memLowVal_v + (expectedHead_v - memHighVal_v - WORD_LEN_C);
                                    wraparoundOccurred_v := true;
                                end if;

                                check(currentHead_v = expectedHead_v,
                                      "HEAD ERROR: Expected head " & integer'image(expectedHead_v) & " but got " & integer'image(currentHead_v) & " (cmd_addr=" & integer'image(cmdAddr_v) & ", cmd_size=" & integer'image(cmdSize_v) & ", bytes=" & integer'image(bytesWritten_v) & ", mem_high=" & integer'image(memHighVal_v) & ")");
                            else
                                tb_CmdWr_Ready <= '0';
                                wait until (rising_edge(tb_ClkxCI));
                                --info("No command issued (FIFO empty or no space available)");
                            end if;
                        else
                            wait until (rising_edge(tb_ClkxCI));
                            --info("Skipping command (FIFO empty or no space available)");
                        end if;

                        -- Add some random delay between operations
                        delayCycles_v := rand_natural(1, 10);
                        for i in 1 to delayCycles_v loop
                            wait until (rising_edge(tb_ClkxCI));
                        end loop;

                    end loop;

                    -- Check that wraparound actually occurred for this run
                    check(wraparoundOccurred_v, "Wraparound should have occurred in run " & integer'image(run_count_v));

                    info("=== Test run " & integer'image(run_count_v) & " completed successfully ===");

                end loop;               -- End of test runs loop

                info("All " & integer'image(NUM_TEST_RUNS_C) & " random wraparound test runs completed successfully!");

            elsif run("fifo_level_zero") then
                -- Test case to hit condition: Wr_FIFO_Level = 0 (when no data available for write)
                tb_MemLow        <= std_logic_vector(to_unsigned(0, AXI_ADDR_WIDTH_G_C));
                tb_MemHigh       <= std_logic_vector(to_unsigned(1024, AXI_ADDR_WIDTH_G_C));
                tb_Tail          <= std_logic_vector(to_unsigned(WORD_LEN_C, AXI_ADDR_WIDTH_G_C)); -- Tail ahead
                tb_Wr_FIFO_Level <= std_logic_vector(to_unsigned(0, log2ceil(FIFO_DEPTH_G_C + 1))); -- No data in FIFO

                -- Reset DUT
                tb_RstxRBI <= '0';
                wait until (rising_edge(tb_ClkxCI));
                tb_RstxRBI <= '1';
                wait until (rising_edge(tb_ClkxCI));

                -- Try to start write operation with no data in FIFO
                wait for DTS_C;
                tb_CmdWr_Ready <= '1';
                wait until (rising_edge(tb_ClkxCI));

                -- Check that no command is issued because FIFO is empty
                wait for DTS_C + DTR_C;
                check_equal(tb_CmdWr_Valid, '0', "CmdWr_Valid should be '0' when FIFO is empty");

            elsif run("wr_error_condition") then
                -- Test case to hit condition: Wr_Error = '1'
                tb_MemLow        <= std_logic_vector(to_unsigned(0, AXI_ADDR_WIDTH_G_C));
                tb_MemHigh       <= std_logic_vector(to_unsigned(1024, AXI_ADDR_WIDTH_G_C));
                tb_Tail          <= std_logic_vector(to_unsigned(3 * WORD_LEN_C, AXI_ADDR_WIDTH_G_C)); -- Tail ahead
                tb_Wr_FIFO_Level <= std_logic_vector(to_unsigned(5, log2ceil(FIFO_DEPTH_G_C + 1))); -- Some data in FIFO

                -- Reset DUT
                tb_RstxRBI <= '0';
                wait until (rising_edge(tb_ClkxCI));
                tb_RstxRBI <= '1';
                wait until (rising_edge(tb_ClkxCI));

                -- Start write operation
                wait for DTS_C;
                tb_CmdWr_Ready <= '1';
                wait until (rising_edge(tb_ClkxCI));

                -- Wait for command to be issued
                wait until (rising_edge(tb_ClkxCI));
                wait for DTS_C + DTR_C;
                check_equal(tb_CmdWr_Valid, '1', "CmdWr_Valid should be '1'");

                -- Acknowledge command
                wait for DTS_C;
                tb_CmdWr_Ready <= '0';
                wait until (rising_edge(tb_ClkxCI));

                -- Signal write error instead of done
                wait for DTS_C;
                tb_Wr_Error <= '1';
                tb_Wr_Done  <= '0';
                wait until (rising_edge(tb_ClkxCI));

                -- Check that error is processed and state returns to IDLE
                wait for DTS_C + DTR_C;
                check_equal(tb_ErrorAXIWrite, '1', "ErrorAXIWritexDO should be '1' after Wr_Error");

                -- Clear error
                tb_Wr_Error <= '0';
                wait until (rising_edge(tb_ClkxCI));

            elsif run("memory_full_conditions") then
                -- Test case to hit specific memory full conditions 
                -- Test when head == memLow and tail == memHigh
                tb_MemLow        <= std_logic_vector(to_unsigned(0, AXI_ADDR_WIDTH_G_C));
                tb_MemHigh       <= std_logic_vector(to_unsigned(1024, AXI_ADDR_WIDTH_G_C));
                tb_Tail          <= std_logic_vector(to_unsigned(1024, AXI_ADDR_WIDTH_G_C)); -- Tail at MemHigh
                tb_Wr_FIFO_Level <= std_logic_vector(to_unsigned(5, log2ceil(FIFO_DEPTH_G_C + 1))); -- Some data to write

                -- Reset DUT (this sets head to memLow)
                tb_RstxRBI <= '0';
                wait until (rising_edge(tb_ClkxCI));
                tb_RstxRBI <= '1';
                wait until (rising_edge(tb_ClkxCI));

                -- Head should now be at MemLow (0), Tail at MemHigh (1024) - memory is full
                wait for DTS_C;
                tb_CmdWr_Ready <= '1';
                wait until (rising_edge(tb_ClkxCI));

                -- Check that memory full error is detected
                wait for DTS_C + DTR_C;
                check_equal(tb_ErrorMemFull, '1', "ErrorMemFull should be '1' when head=MemLow and tail=MemHigh");

            elsif run("address_variations") then
                -- Test various address combinations to improve toggle coverage
                for addr_test in 0 to 15 loop
                    -- Vary addresses to toggle more bits
                    tb_MemLow        <= std_logic_vector(to_unsigned(addr_test * 512, AXI_ADDR_WIDTH_G_C));
                    tb_MemHigh       <= std_logic_vector(to_unsigned((addr_test + 1) * 512 + 128, AXI_ADDR_WIDTH_G_C));
                    tb_Tail          <= std_logic_vector(to_unsigned(addr_test * 512 + (addr_test mod 8) * WORD_LEN_C, AXI_ADDR_WIDTH_G_C));
                    tb_Wr_FIFO_Level <= std_logic_vector(to_unsigned(addr_test mod 16 + 1, log2ceil(FIFO_DEPTH_G_C + 1)));

                    -- Reset DUT
                    tb_RstxRBI <= '0';
                    wait until (rising_edge(tb_ClkxCI));
                    tb_RstxRBI <= '1';
                    wait until (rising_edge(tb_ClkxCI));

                    -- Start write operation with varying size
                    wait for DTS_C;
                    tb_CmdWr_Ready <= '1';
                    wait until (rising_edge(tb_ClkxCI));

                    -- Check operation (only if not memory full)
                    wait until (rising_edge(tb_ClkxCI));
                    wait for DTS_C + DTR_C;
                    if tb_ErrorMemFull = '0' then
                        check_equal(tb_CmdWr_Valid, '1', "CmdWr_Valid should be '1' for test " & integer'image(addr_test));
                    end if;

                    -- Complete operation if valid
                    if tb_CmdWr_Valid = '1' then
                        wait for DTS_C;
                        tb_CmdWr_Ready <= '0';
                        tb_Wr_Done     <= '1';
                        wait until (rising_edge(tb_ClkxCI));
                        tb_Wr_Done <= '0';
                        wait until (rising_edge(tb_ClkxCI));
                    else
                        tb_CmdWr_Ready <= '0';
                        wait until (rising_edge(tb_ClkxCI));
                    end if;
                end loop;

            elsif run("state_transitions") then
                -- Test case for additional state coverage
                tb_MemLow        <= std_logic_vector(to_unsigned(0, AXI_ADDR_WIDTH_G_C));
                tb_MemHigh       <= std_logic_vector(to_unsigned(1024, AXI_ADDR_WIDTH_G_C));
                tb_Tail          <= std_logic_vector(to_unsigned(3 * WORD_LEN_C, AXI_ADDR_WIDTH_G_C)); -- Tail ahead
                tb_Wr_FIFO_Level <= std_logic_vector(to_unsigned(5, log2ceil(FIFO_DEPTH_G_C + 1))); -- Data to write

                -- Reset DUT
                tb_RstxRBI <= '0';
                wait until (rising_edge(tb_ClkxCI));
                tb_RstxRBI <= '1';
                wait until (rising_edge(tb_ClkxCI));

                -- Start write operation
                wait for DTS_C;
                tb_CmdWr_Ready <= '1';
                wait until (rising_edge(tb_ClkxCI));

                -- Wait for command to be issued 
                wait until (rising_edge(tb_ClkxCI));
                wait for DTS_C + DTR_C;
                check_equal(tb_CmdWr_Valid, '1', "CmdWr_Valid should be '1'");

                -- Clear ready to test different path
                tb_CmdWr_Ready <= '0';
                wait until (rising_edge(tb_ClkxCI));
                wait for DTS_C;
                
                -- Re-enable ready to complete operation
                tb_CmdWr_Ready <= '1';
                wait until (rising_edge(tb_ClkxCI));
                wait for DTS_C;

            elsif run("currsize_zero") then
                -- Test the condition where currSize_v = 0 (unaligned head pointer)
                info("Testing currSize_v = 0");
                
                -- Set memory bounds that would create alignment issues leading to currSize_v = 0
                tb_MemLow        <= std_logic_vector(to_unsigned(2001, AXI_ADDR_WIDTH_G_C)); -- Unaligned address
                tb_MemHigh       <= std_logic_vector(to_unsigned(2001, AXI_ADDR_WIDTH_G_C)); -- Same as MemLow to create zero range
                tb_Tail          <= std_logic_vector(to_unsigned(2001, AXI_ADDR_WIDTH_G_C)); -- Same unaligned tail
                tb_Wr_FIFO_Level <= std_logic_vector(to_unsigned(8, log2ceil(FIFO_DEPTH_G_C + 1))); -- FIFO has data
                
                -- Reset DUT
                tb_RstxRBI <= '0';
                wait until (rising_edge(tb_ClkxCI));
                tb_RstxRBI <= '1';
                wait until (rising_edge(tb_ClkxCI));
                
                -- Clear soft reset
                tb_SoftReset <= '0';
                wait until (rising_edge(tb_ClkxCI));
                tb_SoftReset <= '1';
                wait until (rising_edge(tb_ClkxCI));
                
                -- Try to trigger write when currSize_v would be 0 due to alignment
                wait for DTS_C;
                tb_CmdWr_Ready <= '1';
                wait until (rising_edge(tb_ClkxCI));
                
                -- Wait and check that no command is issued (because currSize_v = 0)
                wait until (rising_edge(tb_ClkxCI));
                wait for DTS_C + DTR_C;
                check_equal(tb_CmdWr_Valid, '0', "CmdWr_Valid should remain '0' when currSize_v = 0");
                
                info("currSize_v = 0 test completed");

            elsif run("error_expression") then
                -- Test to trigger p.errorAXIWrite = '1'
                info("Testing p.errorAXIWrite");
                
                -- Set up normal memory configuration
                tb_MemLow        <= std_logic_vector(to_unsigned(0, AXI_ADDR_WIDTH_G_C));
                tb_MemHigh       <= std_logic_vector(to_unsigned(1024, AXI_ADDR_WIDTH_G_C));
                tb_Tail          <= std_logic_vector(to_unsigned(0, AXI_ADDR_WIDTH_G_C)); -- Start at beginning
                tb_Wr_FIFO_Level <= std_logic_vector(to_unsigned(8, log2ceil(FIFO_DEPTH_G_C + 1))); -- FIFO has data
                
                -- Reset DUT
                tb_RstxRBI <= '0';
                wait until (rising_edge(tb_ClkxCI));
                tb_RstxRBI <= '1';
                wait until (rising_edge(tb_ClkxCI));
                
                -- Clear soft reset
                tb_SoftReset <= '0';
                wait until (rising_edge(tb_ClkxCI));
                tb_SoftReset <= '1';
                wait until (rising_edge(tb_ClkxCI));
                
                -- Start write operation
                wait for DTS_C;
                tb_CmdWr_Ready <= '1';
                wait until (rising_edge(tb_ClkxCI));
                
                -- Wait for command to be issued
                wait until (rising_edge(tb_ClkxCI));
                wait for DTS_C + DTR_C;
                check_equal(tb_CmdWr_Valid, '1', "CmdWr_Valid should be '1'");
                
                -- Simulate AXI write error to trigger p.errorAXIWrite = '1'
                wait for DTS_C;
                tb_CmdWr_Ready <= '0';
                tb_Wr_Error    <= '1';  -- Set error signal
                wait until (rising_edge(tb_ClkxCI));
                
                wait for DTS_C;
                tb_Wr_Done     <= '1';  -- Complete the transaction with error
                wait until (rising_edge(tb_ClkxCI));
                
                -- Clear signals
                wait for DTS_C;
                tb_Wr_Error    <= '0';
                tb_Wr_Done     <= '0';
                wait until (rising_edge(tb_ClkxCI));
                
                -- Allow state machine to process error and check result
                wait for DTS_C + DTR_C;
                check_equal(tb_ErrorAXIWrite, '1', "AXI Write Error should be set after Wr_Error");
                
                info("p.errorAXIWrite test completed");

            elsif run("persistent_error_expression") then
                -- Test to hit p.errorAXIWrite = '1'
                info("Starting persistent_error_expression test for p.errorAXIWrite");
                
                -- Setup normal operation first
                tb_MemLow  <= std_logic_vector(to_unsigned(0, AXI_ADDR_WIDTH_G_C));
                tb_MemHigh <= std_logic_vector(to_unsigned(1024, AXI_ADDR_WIDTH_G_C));
                tb_Tail    <= std_logic_vector(to_unsigned(100, AXI_ADDR_WIDTH_G_C));
                tb_Wr_FIFO_Level <= std_logic_vector(to_unsigned(10, log2ceil(FIFO_DEPTH_G_C + 1)));
                
                -- Reset sequence
                tb_RstxRBI <= '0';
                wait until (rising_edge(tb_ClkxCI));
                tb_RstxRBI <= '1';
                wait until (rising_edge(tb_ClkxCI));

                -- First, cause an AXI error to set p.errorAXIWrite = '1'
                tb_CmdWr_Ready <= '1';
                wait until (rising_edge(tb_ClkxCI));
                
                -- Wait for state machine to enter ISSUE_SEND_CMD
                wait until (rising_edge(tb_ClkxCI));
                wait for DTS_C + DTR_C;
                
                -- Trigger first error
                tb_Wr_Error <= '1';
                wait until (rising_edge(tb_ClkxCI));
                tb_Wr_Error <= '0';
                
                -- Wait for error to be processed (this sets p.errorAXIWrite = '1')
                wait for DTS_C + DTR_C;
                
                -- Now trigger another write command cycle to hit the p.errorAXIWrite = '1' case
                -- in the expression (p.errorAXIWrite or Wr_Error)
                tb_Tail <= std_logic_vector(to_unsigned(200, AXI_ADDR_WIDTH_G_C)); -- Change tail
                wait until (rising_edge(tb_ClkxCI));
                
                -- Wait for state machine processing
                wait for DTS_C + DTR_C;
                
                -- At this point p.errorAXIWrite should be '1' and we should hit that branch
                -- of the expression coverage
                
                info("persistent_error_expression test completed");

            end if;

        end loop;

        -- Cleanup the VUnit Runner
        test_runner_cleanup(runner);

        -- Wait forever
        wait;
    end process proc_applyTestvector;
end tb;
