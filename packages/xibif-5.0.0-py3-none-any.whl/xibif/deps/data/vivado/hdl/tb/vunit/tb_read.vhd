-- ----------------------------------------------------------------------------------------------------
-- brief: Testbench for entity Xibif_read
-- file: XiBIF_read_tb.vhd
-- author: lukas.leuenberger
-- ----------------------------------------------------------------------------------------------------
-- Copyright(c) 2025 by OST, Switzerland
-- All rights reserved.
-- ----------------------------------------------------------------------------------------------------
-- File history:
-- Version, Date, Author, Remarks
-- ----------------------------------------------------------------------------------------------------
-- 0.1, 06.10.2025, lukas.leuenberger, Auto-Created with hdltbgen 1.0.9
-- ----------------------------------------------------------------------------------------------------

-- Standard library ieee
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;
use std.textio.all;
use ieee.std_logic_textio.all;
use ieee.math_real.all;

-- VUnit test library
library vunit_lib;
context vunit_lib.vunit_context;

library olo;
use olo.olo_base_pkg_math.all;

-- This block implements the testbench for the block **Xibif_read**.
entity tb_read is
    generic(
        runner_cfg : string := runner_cfg_default; -- Generic for VUnit -- @suppress
        tb_path    : string := "hw\tb\vunit" -- Generic for VUnit -- @suppress
    );
end entity tb_read;

-- This is the testbench architecture of the **Xibif_read** block.
architecture tb of tb_read is
    ----------------------------------------------------------------------------------------------------
    -- Internal constants
    ----------------------------------------------------------------------------------------------------
    constant F_CLK_C : real := 100.0E6; -- Define the frequency of the clock
    constant T_CLK_C : time := (1.0 sec) / F_CLK_C; -- Calculate the period of a clockcycle
    constant DTS_C   : time := 1 ns;    -- Define a delta time for signal changes
    constant DTR_C   : time := 8 ns;    -- Define a delta time for signal changes

    constant FIFO_DEPTH_G_C     : positive := 512; -- Constant for the generic FIFO_DEPTH_G
    constant AXI_ADDR_WIDTH_G_C : positive := 16; -- Constant for the generic AXI_ADDR_WIDTH_G
    constant AXI_DATA_WIDTH_G_C : positive := 16; -- Constant for the generic AXI_DATA_WIDTH_G
    constant WORD_LEN_C         : integer  := AXI_DATA_WIDTH_G_C / 8; -- Word length in bytes

    constant NUM_TEST_RUNS_C : integer := 500; -- Number of times to run the random test    

    ----------------------------------------------------------------------------------------------------
    -- Internal signals
    ----------------------------------------------------------------------------------------------------    
    -- Input signals
    signal tb_ClkxCI        : std_logic; -- Internal signal for input signal ClkxCI @suppress
    signal tb_RstxRBI       : std_logic; -- Internal signal for input signal RstxRBI @suppress
    signal tb_CmdRd_Ready   : std_logic; -- Internal signal for input signal CmdRd_Ready @suppress
    signal tb_Rd_Done       : std_logic; -- Internal signal for input signal Rd_Done @suppress
    signal tb_Rd_Error      : std_logic; -- Internal signal for input signal Rd_Error @suppress
    signal tb_Rd_FIFO_Level : std_logic_vector(log2ceil(FIFO_DEPTH_G_C + 1) - 1 downto 0); -- Internal signal for input signal Rd_FIFO_Level @suppress
    signal tb_MemLowxDI     : std_logic_vector(AXI_ADDR_WIDTH_G_C - 1 downto 0); -- Internal signal for input signal MemLowxDI @suppress
    signal tb_MemHighxDI    : std_logic_vector(AXI_ADDR_WIDTH_G_C - 1 downto 0); -- Internal signal for input signal MemHighxDI @suppress
    signal tb_HeadxDI       : std_logic_vector(AXI_ADDR_WIDTH_G_C - 1 downto 0); -- Internal signal for input signal HeadxDI @suppress
    signal tb_SoftResetxRBI : std_logic; -- Internal signal for input signal SoftResetxRBI @suppress

    -- Output signals
    signal tb_CmdRd_Addr       : std_logic_vector(AXI_ADDR_WIDTH_G_C - 1 downto 0); -- Internal signal for output signal CmdRd_Addr @suppress
    signal tb_CmdRd_Size       : std_logic_vector(log2ceil(FIFO_DEPTH_G_C + 1) - 1 downto 0); -- Internal signal for output signal CmdRd_Size @suppress
    signal tb_CmdRd_Valid      : std_logic; -- Internal signal for output signal CmdRd_Valid @suppress
    signal tb_TailxDO          : std_logic_vector(AXI_ADDR_WIDTH_G_C - 1 downto 0); -- Internal signal for output signal TailxDO @suppress
    signal tb_ErrorAXIReadxDO  : std_logic; -- Internal signal for output signal ErrorAXIReadxDO @suppress
    signal tb_SoftResetDonexDO : std_logic; -- Internal signal for output signal SoftResetDonexDO @suppress

    ----------------------------------------------------------------------------------------------------
    -- Internal constants, types and functions to convert a vector to a string
    ----------------------------------------------------------------------------------------------------
    type     charIndexedByMVL9_t is array (std_ulogic) of character; -- Type to convert a vector to a string
    constant MVL9_TO_CHAR_C      : charIndexedByMVL9_t := "UX01ZWLH-"; -- Constant to convert a vector to a string

    -- This function converts a std_ulogic_vector into a string.
    function to_string_std_ulogic_vector(value : std_ulogic_vector) return STRING is -- @suppress
        alias    ivalue   : std_ulogic_vector(1 to value'length) is value;
        variable result_v : string(1 to value'length + 2);
    begin
        if value'length < 1 then
            return "";
        else
            result_v(1)                := ''';
            result_v(value'length + 2) := ''';
            for i in ivalue'range loop
                result_v(i + 1) := MVL9_TO_CHAR_C(ivalue(i));
            end loop;
            return result_v;
        end if;
    end function to_string_std_ulogic_vector;

    -- This function converts a std_logic_vector into a string.
    function to_string_std_logic_vector(value : std_logic_vector) return string is -- @suppress
    begin
        return to_string_std_ulogic_vector(to_stdulogicvector(value));
    end function to_string_std_logic_vector;

    -- This function converts an unsigned value into a string.
    function to_string_unsigned(value : unsigned) return string is -- @suppress
    begin
        return to_string_std_ulogic_vector(std_ulogic_vector(value)) & " / " & Integer'image(to_integer(value));
    end function to_string_unsigned;

    -- This function converts a signed value into a string.
    function to_string_signed(value : signed) return string is -- @suppress
    begin
        return to_string_std_ulogic_vector(std_ulogic_vector(value)) & " / " & Integer'image(to_integer(value));
    end function to_string_signed;

    -- This function converts an integer value into a string.
    function to_string_integer(value : integer) return string is -- @suppress
    begin
        return Integer'image(value);
    end function to_string_integer;

    -- This function converts a positive value into a string.
    function to_string_positive(value : positive) return string is -- @suppress
    begin
        return Integer'image(value);
    end function to_string_positive;

    -- This function converts a natural value into a string.
    function to_string_natural(value : natural) return string is -- @suppress
    begin
        return Integer'image(value);
    end function to_string_natural;

    -- This function converts a std_logic value into a string.
    function to_string_std_logic(value : std_logic) return string is -- @suppress
    begin
        return std_logic'image(value);
    end function to_string_std_logic;

    -- This function converts a std_ulogic value into a string.
    function to_string_std_ulogic(value : std_ulogic) return string is -- @suppress
    begin
        return std_ulogic'image(value);
    end function to_string_std_ulogic;

begin
    -- Make a dut and map the ports to the correct signals
    inst_DUT : entity work.Xibif_read
        generic map(
            FIFO_DEPTH_G     => FIFO_DEPTH_G_C, -- Map the generic FIFO_DEPTH_G to the constant FIFO_DEPTH_G_C
            AXI_ADDR_WIDTH_G => AXI_ADDR_WIDTH_G_C, -- Map the generic AXI_ADDR_WIDTH_G to the constant AXI_ADDR_WIDTH_G_C
            AXI_DATA_WIDTH_G => AXI_DATA_WIDTH_G_C -- Map the generic AXI_DATA_WIDTH_G to the constant AXI_DATA_WIDTH_G_C
        )
        port map(
            ClkxCI           => tb_ClkxCI, -- Map the signal tb_ClkxCI to the port ClkxCI
            RstxRBI          => tb_RstxRBI, -- Map the signal tb_RstxRBI to the port RstxRBI
            SoftReset    => tb_SoftResetxRBI, -- Map the signal tb_SoftResetxRBI to the port SoftResetxRBI
            SoftResetDonexDO => tb_SoftResetDonexDO, -- Map the signal tb_SoftResetDonexDO to the port SoftResetDonexDO
            CmdRd_Addr       => tb_CmdRd_Addr, -- Map the signal tb_CmdRd_Addr to the port CmdRd_Addr
            CmdRd_Size       => tb_CmdRd_Size, -- Map the signal tb_CmdRd_Size to the port CmdRd_Size
            CmdRd_Valid      => tb_CmdRd_Valid, -- Map the signal tb_CmdRd_Valid to the port CmdRd_Valid
            CmdRd_Ready      => tb_CmdRd_Ready, -- Map the signal tb_CmdRd_Ready to the port CmdRd_Ready
            Rd_Done          => tb_Rd_Done, -- Map the signal tb_Rd_Done to the port Rd_Done
            Rd_Error         => tb_Rd_Error, -- Map the signal tb_Rd_Error to the port Rd_Error
            Rd_FIFOLevel     => tb_Rd_FIFO_Level, -- Map the signal tb_Rd_FIFO_Level to the port Rd_FIFO_Level
            MemLow           => tb_MemLowxDI, -- Map the signal tb_MemLowxDI to the port MemLowxDI
            MemHigh          => tb_MemHighxDI, -- Map the signal tb_MemHighxDI to the port MemHighxDI
            Tail             => tb_TailxDO, -- Map the signal tb_TailxDO to the port TailxDO
            HeadxDI          => tb_HeadxDI, -- Map the signal tb_HeadxDI to the port HeadxDI
            ErrorAXIReadxDO  => tb_ErrorAXIReadxDO -- Map the signal tb_ErrorAXIReadxDO to the port ErrorAXIReadxDO
        );

    -- Apply a clock to the DUT
    proc_stimuliClk : process
    begin
        tb_ClkxCI <= '0';
        loop
            wait for (T_CLK_C / 2.0);
            tb_ClkxCI <= not tb_ClkxCI;
        end loop;
        wait;
    end process;

    -- Watchdog
    test_runner_watchdog(runner, 100 ms);

    -- Apply the testvectors to the DUT
    proc_applyTestvector : process
        -- Variables for random wraparound test  
        variable seed1_v, seed2_v      : integer range 1 to integer'high := 1;
        variable memLowVal_v         : natural range 0 to 2 ** AXI_ADDR_WIDTH_G_C - 1;
        variable memHighVal_v        : natural range 0 to 2 ** AXI_ADDR_WIDTH_G_C - 1;
        variable headVal_v            : natural range 0 to 2 ** AXI_ADDR_WIDTH_G_C - 1;
        variable fifoLevel_v          : natural range 0 to FIFO_DEPTH_G_C;
        variable initialTail_v        : natural range 0 to 2 ** AXI_ADDR_WIDTH_G_C - 1;
        variable currentTail_v        : natural range 0 to 2 ** AXI_ADDR_WIDTH_G_C - 1;
        variable wraparoundOccurred_v : boolean                         := false;
        variable cmdAddr_v            : natural range 0 to 2 ** AXI_ADDR_WIDTH_G_C - 1;
        variable cmdSize_v            : natural range 0 to FIFO_DEPTH_G_C;
        variable fifoSpace_v          : natural range 0 to FIFO_DEPTH_G_C;
        variable delayCycles_v        : natural range 0 to 20;
        variable expectedTail_v       : natural range 0 to 2 ** AXI_ADDR_WIDTH_G_C - 1;
        variable bytesRead_v          : natural range 0 to FIFO_DEPTH_G_C * WORD_LEN_C;

        -- Random natural number in range [min_val, max_val]
        impure function rand_natural(min_val : natural; max_val : natural) return natural is
            variable r_v : real;
        begin
            uniform(seed1_v, seed2_v, r_v);
            return min_val + integer(r_v * real(max_val - min_val));
        end function;

        -- Random memory address within given range (word-aligned)
        impure function rand_mem_addr(low_addr : natural; high_addr : natural) return natural is
            variable r_v          : real;
            variable addrRange_v : natural range 0 to 2 ** AXI_ADDR_WIDTH_G_C - 1;
        begin
            uniform(seed1_v, seed2_v, r_v);
            addrRange_v := (high_addr - low_addr) / WORD_LEN_C;
            return low_addr + (integer(r_v * real(addrRange_v)) * WORD_LEN_C);
        end function;

        -- Random FIFO level within given maximum
        impure function rand_fifo_level(max_level : natural) return natural is
        begin
            return integer(rand_natural(0, max_level));
        end function;

        -- Random head position ahead of current tail for circular buffer
        impure function rand_head_position(current_tail : natural; mem_low : natural; mem_high : natural) return natural is
            variable r_v : real;
        begin
            uniform(seed1_v, seed2_v, r_v);
            if current_tail + WORD_LEN_C < mem_high then
                -- No wraparound yet, place head ahead of tail
                return current_tail + WORD_LEN_C + integer(r_v * real((mem_high - current_tail - WORD_LEN_C) / WORD_LEN_C)) * WORD_LEN_C;
            else
                -- Tail is near end, wrap head to beginning
                return mem_low + integer(r_v * real((current_tail - mem_low) / WORD_LEN_C)) * WORD_LEN_C;
            end if;
        end function;

    begin
        -- Setup the VUnit Runner
        test_runner_setup(runner, runner_cfg);

        -- Set all signals to a default value
        tb_RstxRBI       <= '1';
        tb_CmdRd_Ready   <= '0';
        tb_Rd_Done       <= '0';
        tb_Rd_Error      <= '0';
        tb_Rd_FIFO_Level <= (others => '0');
        tb_MemLowxDI     <= (others => '0');
        tb_MemHighxDI    <= (others => '0');
        tb_HeadxDI       <= (others => '0');
        tb_SoftResetxRBI <= '1';

        while test_suite loop
            -- Reset DUT
            tb_RstxRBI <= '0';          -- Perform a positive reset (active high)
            wait until (rising_edge(tb_ClkxCI)); -- Wait for the first active clock edge
            tb_RstxRBI <= '1';          -- Clear the positive reset

            if run("read_single_value_ready") then
                for memLow in 0 to 16 loop
                    -- Set all inputs 
                    wait for DTS_C;
                    tb_MemLowxDI     <= std_logic_vector(to_unsigned(memLow * WORD_LEN_C, AXI_ADDR_WIDTH_G_C));
                    tb_MemHighxDI    <= std_logic_vector(to_unsigned((memLow + 10) * WORD_LEN_C, AXI_ADDR_WIDTH_G_C));
                    tb_HeadxDI       <= std_logic_vector(to_unsigned((memLow + 1) * WORD_LEN_C, AXI_ADDR_WIDTH_G_C)); -- Head one word ahead
                    tb_Rd_FIFO_Level <= std_logic_vector(to_unsigned(0, log2ceil(FIFO_DEPTH_G_C + 1))); -- FIFO empty

                    -- Reset DUT
                    tb_RstxRBI <= '0';  -- Perform a positive reset (active high)
                    wait until (rising_edge(tb_ClkxCI)); -- Wait for the first active clock edge                    
                    tb_RstxRBI <= '1';  -- Clear the positive reset
                    wait until (rising_edge(tb_ClkxCI)); -- Wait for reset to be processed

                    -- Check the tail pointer after reset
                    wait for DTS_C + DTR_C;
                    check_equal(tb_TailxDO, std_logic_vector(to_unsigned(memLow * WORD_LEN_C, AXI_ADDR_WIDTH_G_C)), "TailxDO after reset wrong");
                    wait until (rising_edge(tb_ClkxCI));

                    -- We are ready to accept commands
                    wait for DTS_C;
                    tb_CmdRd_Ready <= '1';
                    tb_Rd_Done     <= '0';
                    tb_Rd_Error    <= '0';
                    wait until (rising_edge(tb_ClkxCI));

                    -- Wait for command to be issued
                    wait until (rising_edge(tb_ClkxCI));
                    wait for DTS_C + DTR_C;
                    check_equal(tb_CmdRd_Valid, '1', "CmdRd_Valid should be '1'");
                    check_equal(tb_CmdRd_Addr, std_logic_vector(to_unsigned(memLow * WORD_LEN_C, AXI_ADDR_WIDTH_G_C)), "CmdRd_Addr");
                    check_equal(tb_CmdRd_Size, std_logic_vector(to_unsigned(1, log2ceil(FIFO_DEPTH_G_C + 1))), "CmdRd_Size");
                    check_equal(tb_TailxDO, std_logic_vector(to_unsigned(memLow * WORD_LEN_C, AXI_ADDR_WIDTH_G_C)), "TailxDO");
                    check_equal(tb_ErrorAXIReadxDO, '0', "ErrorAXIReadxDO");

                    -- Disable ready and indicate that the command is done
                    wait for DTS_C;
                    tb_CmdRd_Ready <= '0';
                    wait until (rising_edge(tb_ClkxCI));
                    wait for DTS_C;
                    tb_Rd_Done     <= '1'; -- Command is done
                    wait until (rising_edge(tb_ClkxCI));
                    wait for DTS_C;
                    tb_Rd_Done     <= '0';
                    wait until (rising_edge(tb_ClkxCI)); -- Wait for state to change back to IDLE

                end loop;

            elsif run("read_burst_data") then
                -- Test reading multiple words in burst
                tb_MemLowxDI     <= std_logic_vector(to_unsigned(0, AXI_ADDR_WIDTH_G_C));
                tb_MemHighxDI    <= std_logic_vector(to_unsigned(1024, AXI_ADDR_WIDTH_G_C));
                tb_HeadxDI       <= std_logic_vector(to_unsigned(10 * WORD_LEN_C, AXI_ADDR_WIDTH_G_C)); -- Head 10 words ahead
                tb_Rd_FIFO_Level <= std_logic_vector(to_unsigned(0, log2ceil(FIFO_DEPTH_G_C + 1))); -- FIFO empty

                -- Wait for clock edge before reset to ensure MemLowxDI is stable
                wait until (rising_edge(tb_ClkxCI));

                -- Reset DUT
                tb_RstxRBI <= '0';
                wait until (rising_edge(tb_ClkxCI));
                tb_RstxRBI <= '1';
                wait until (rising_edge(tb_ClkxCI));

                -- Start read operation
                wait for DTS_C;
                tb_CmdRd_Ready <= '1';
                wait until (rising_edge(tb_ClkxCI));

                -- Check command parameters
                wait until (rising_edge(tb_ClkxCI));
                wait for DTS_C + DTR_C;
                check_equal(tb_CmdRd_Valid, '1', "CmdRd_Valid should be '1' for burst");
                check_equal(tb_CmdRd_Addr, std_logic_vector(to_unsigned(0, AXI_ADDR_WIDTH_G_C)), "CmdRd_Addr for burst");
                check_equal(tb_CmdRd_Size, std_logic_vector(to_unsigned(10, log2ceil(FIFO_DEPTH_G_C + 1))), "CmdRd_Size should be 10");

                -- Complete the transaction
                wait for DTS_C;
                tb_CmdRd_Ready <= '0';
                wait until (rising_edge(tb_ClkxCI));
                wait for DTS_C;
                tb_Rd_Done     <= '1';
                wait until (rising_edge(tb_ClkxCI));
                wait for DTS_C;
                tb_Rd_Done     <= '0';
                wait until (rising_edge(tb_ClkxCI));

                -- Check tail pointer updated correctly
                wait for DTS_C + DTR_C;
                check_equal(tb_TailxDO, std_logic_vector(to_unsigned(10 * WORD_LEN_C, AXI_ADDR_WIDTH_G_C)), "TailxDO after burst read (10*WORD_LEN_C)");

            elsif run("read_fifo_full_condition") then
                -- Test FIFO full condition
                tb_MemLowxDI     <= std_logic_vector(to_unsigned(0, AXI_ADDR_WIDTH_G_C));
                tb_MemHighxDI    <= std_logic_vector(to_unsigned(1024, AXI_ADDR_WIDTH_G_C));
                tb_HeadxDI       <= std_logic_vector(to_unsigned(10 * WORD_LEN_C, AXI_ADDR_WIDTH_G_C)); -- Head ahead
                tb_Rd_FIFO_Level <= std_logic_vector(to_unsigned(FIFO_DEPTH_G_C, log2ceil(FIFO_DEPTH_G_C + 1))); -- FIFO full

                -- Reset DUT
                tb_RstxRBI <= '0';
                wait until (rising_edge(tb_ClkxCI));
                tb_RstxRBI <= '1';
                wait until (rising_edge(tb_ClkxCI));

                -- Try to start read operation
                wait for DTS_C;
                tb_CmdRd_Ready <= '1';
                wait until (rising_edge(tb_ClkxCI));

                -- Check that no command is issued when FIFO is full
                wait until (rising_edge(tb_ClkxCI));
                wait for DTS_C + DTR_C;
                check_equal(tb_CmdRd_Valid, '0', "CmdRd_Valid should be '0' when FIFO is full");

            elsif run("read_axi_error_handling") then
                -- Test AXI error handling
                tb_MemLowxDI     <= std_logic_vector(to_unsigned(0, AXI_ADDR_WIDTH_G_C));
                tb_MemHighxDI    <= std_logic_vector(to_unsigned(1024, AXI_ADDR_WIDTH_G_C));
                tb_HeadxDI       <= std_logic_vector(to_unsigned(3 * WORD_LEN_C, AXI_ADDR_WIDTH_G_C)); -- Head ahead
                tb_Rd_FIFO_Level <= std_logic_vector(to_unsigned(0, log2ceil(FIFO_DEPTH_G_C + 1))); -- FIFO empty

                -- Reset DUT
                tb_RstxRBI <= '0';
                wait until (rising_edge(tb_ClkxCI));
                tb_RstxRBI <= '1';
                wait until (rising_edge(tb_ClkxCI));

                -- Start read operation
                wait for DTS_C;
                tb_CmdRd_Ready <= '1';
                wait until (rising_edge(tb_ClkxCI));

                -- Simulate AXI error
                wait until (rising_edge(tb_ClkxCI));
                wait for DTS_C;
                tb_CmdRd_Ready <= '0';
                wait until (rising_edge(tb_ClkxCI));
                wait for DTS_C;
                tb_Rd_Error    <= '1';
                wait until (rising_edge(tb_ClkxCI));

                -- Check error is captured
                wait for DTS_C + DTR_C;
                check_equal(tb_ErrorAXIReadxDO, '1', "ErrorAXIReadxDO should be '1' after AXI error");

                tb_Rd_Error <= '0';
                wait until (rising_edge(tb_ClkxCI));

            elsif run("read_address_wraparound") then
                -- Test address wraparound at memory boundary
                tb_MemLowxDI     <= std_logic_vector(to_unsigned(100, AXI_ADDR_WIDTH_G_C));
                tb_MemHighxDI    <= std_logic_vector(to_unsigned(120, AXI_ADDR_WIDTH_G_C)); -- Small memory region
                tb_HeadxDI       <= std_logic_vector(to_unsigned(100 + WORD_LEN_C, AXI_ADDR_WIDTH_G_C)); -- Head just ahead
                tb_Rd_FIFO_Level <= std_logic_vector(to_unsigned(0, log2ceil(FIFO_DEPTH_G_C + 1))); -- FIFO empty

                -- Wait for clock edge before reset to ensure MemLowxDI is stable
                wait until (rising_edge(tb_ClkxCI));

                -- Reset DUT
                tb_RstxRBI <= '0';
                wait until (rising_edge(tb_ClkxCI));
                tb_RstxRBI <= '1';
                wait until (rising_edge(tb_ClkxCI));

                -- Check initial tail position
                wait for DTS_C + DTR_C;
                check_equal(tb_TailxDO, std_logic_vector(to_unsigned(100, AXI_ADDR_WIDTH_G_C)), "Initial tail position");

                -- Start read operation
                tb_CmdRd_Ready <= '1';
                wait until (rising_edge(tb_ClkxCI));

                -- Check command is limited by memory boundary
                wait until (rising_edge(tb_ClkxCI));
                wait for DTS_C + DTR_C;
                check_equal(tb_CmdRd_Valid, '1', "CmdRd_Valid should be '1'");
                check_equal(tb_CmdRd_Size, std_logic_vector(to_unsigned(1, log2ceil(FIFO_DEPTH_G_C + 1))), "CmdRd_Size should be 1 word");

                -- Complete the transaction
                wait for DTS_C;
                tb_CmdRd_Ready <= '0';
                wait until (rising_edge(tb_ClkxCI));
                wait for DTS_C;
                tb_Rd_Done     <= '1';
                wait until (rising_edge(tb_ClkxCI));
                wait for DTS_C;
                tb_Rd_Done     <= '0';
                wait until (rising_edge(tb_ClkxCI));

                -- Check tail updated
                wait for DTR_C;
                check_equal(tb_TailxDO, std_logic_vector(to_unsigned(100 + WORD_LEN_C, AXI_ADDR_WIDTH_G_C)), "Tail should be updated");

            elsif run("read_no_data_available") then
                -- Test behavior when head equals tail (no data available)
                tb_MemLowxDI     <= std_logic_vector(to_unsigned(0, AXI_ADDR_WIDTH_G_C));
                tb_MemHighxDI    <= std_logic_vector(to_unsigned(1024, AXI_ADDR_WIDTH_G_C));
                tb_HeadxDI       <= std_logic_vector(to_unsigned(0, AXI_ADDR_WIDTH_G_C)); -- Head same as tail
                tb_Rd_FIFO_Level <= std_logic_vector(to_unsigned(0, log2ceil(FIFO_DEPTH_G_C + 1))); -- FIFO empty

                -- Reset DUT (sets tail to MemLow)
                tb_RstxRBI <= '0';
                wait until (rising_edge(tb_ClkxCI));
                tb_RstxRBI <= '1';
                wait until (rising_edge(tb_ClkxCI));

                -- Set head equal to tail after reset
                tb_HeadxDI <= std_logic_vector(to_unsigned(0, AXI_ADDR_WIDTH_G_C));

                -- Try to start read operation
                wait for DTS_C;
                tb_CmdRd_Ready <= '1';
                wait until (rising_edge(tb_ClkxCI));
                wait for DTS_C + DTR_C;
                wait until (rising_edge(tb_ClkxCI));

                -- Check that no command is issued
                check_equal(tb_CmdRd_Valid, '0', "CmdRd_Valid should be '0' when no data available");
                check_equal(tb_ErrorAXIReadxDO, '0', "ErrorAXIReadxDO should be '0'");

            elsif run("read_master_not_ready") then
                -- Test behavior when AXI master is not ready
                tb_MemLowxDI     <= std_logic_vector(to_unsigned(0, AXI_ADDR_WIDTH_G_C));
                tb_MemHighxDI    <= std_logic_vector(to_unsigned(1024, AXI_ADDR_WIDTH_G_C));
                tb_HeadxDI       <= std_logic_vector(to_unsigned(5 * WORD_LEN_C, AXI_ADDR_WIDTH_G_C)); -- Head ahead
                tb_Rd_FIFO_Level <= std_logic_vector(to_unsigned(0, log2ceil(FIFO_DEPTH_G_C + 1))); -- FIFO empty

                -- Reset DUT
                tb_RstxRBI <= '0';
                wait until (rising_edge(tb_ClkxCI));
                tb_RstxRBI <= '1';
                wait until (rising_edge(tb_ClkxCI));

                -- Keep master not ready
                wait for DTS_C;
                tb_CmdRd_Ready <= '0';
                wait until (rising_edge(tb_ClkxCI));
                wait for DTS_C + DTR_C;

                -- Check that no command is issued
                check_equal(tb_CmdRd_Valid, '0', "CmdRd_Valid should be '0' when master not ready");

                -- Now make master ready
                tb_CmdRd_Ready <= '1';
                wait until (rising_edge(tb_ClkxCI));
                wait until (rising_edge(tb_ClkxCI));
                wait for DTS_C + DTR_C;

                -- Check that command is now issued
                check_equal(tb_CmdRd_Valid, '1', "CmdRd_Valid should be '1' when master becomes ready");

            elsif run("error_persistence_test") then
                -- Test that errors persist until reset
                tb_MemLowxDI     <= std_logic_vector(to_unsigned(0, AXI_ADDR_WIDTH_G_C));
                tb_MemHighxDI    <= std_logic_vector(to_unsigned(1024, AXI_ADDR_WIDTH_G_C));
                tb_HeadxDI       <= std_logic_vector(to_unsigned(3 * WORD_LEN_C, AXI_ADDR_WIDTH_G_C));
                tb_Rd_FIFO_Level <= std_logic_vector(to_unsigned(0, log2ceil(FIFO_DEPTH_G_C + 1)));

                -- Reset DUT
                tb_RstxRBI <= '0';
                wait until (rising_edge(tb_ClkxCI));
                tb_RstxRBI <= '1';
                wait until (rising_edge(tb_ClkxCI));

                -- Trigger AXI read error
                tb_CmdRd_Ready <= '1';
                wait until (rising_edge(tb_ClkxCI));
                wait until (rising_edge(tb_ClkxCI));
                wait for DTS_C;
                tb_CmdRd_Ready <= '0';
                wait until (rising_edge(tb_ClkxCI));
                wait for DTS_C;
                tb_Rd_Error    <= '1';
                wait until (rising_edge(tb_ClkxCI));
                wait for DTS_C + DTR_C;
                check_equal(tb_ErrorAXIReadxDO, '1', "AXI read error should be set");

                -- Complete transaction
                wait for DTS_C;
                tb_Rd_Error <= '0';
                wait until (rising_edge(tb_ClkxCI));

                -- Check error persists
                wait for DTS_C + DTR_C;
                check_equal(tb_ErrorAXIReadxDO, '1', "AXI read error should persist after transaction");

                -- Reset should clear error
                tb_RstxRBI <= '0';
                wait until (rising_edge(tb_ClkxCI));
                tb_RstxRBI <= '1';
                wait until (rising_edge(tb_ClkxCI));
                wait for DTS_C + DTR_C;
                check_equal(tb_ErrorAXIReadxDO, '0', "AXI read error should be cleared after reset");

            elsif run("softreset_functionality") then
                -- Test soft reset functionality
                tb_MemLowxDI     <= std_logic_vector(to_unsigned(100, AXI_ADDR_WIDTH_G_C));
                tb_MemHighxDI    <= std_logic_vector(to_unsigned(1024, AXI_ADDR_WIDTH_G_C));
                tb_HeadxDI       <= std_logic_vector(to_unsigned(500, AXI_ADDR_WIDTH_G_C));
                tb_Rd_FIFO_Level <= std_logic_vector(to_unsigned(0, log2ceil(FIFO_DEPTH_G_C + 1)));

                -- Initial hard reset
                tb_RstxRBI <= '0';
                wait until (rising_edge(tb_ClkxCI));
                tb_RstxRBI <= '1';
                wait until (rising_edge(tb_ClkxCI));

                -- Check initial tail position after hard reset
                wait for DTS_C + DTR_C;
                check_equal(tb_TailxDO, std_logic_vector(to_unsigned(100, AXI_ADDR_WIDTH_G_C)), "Initial tail position after hard reset");
                check_equal(tb_SoftResetDonexDO, '0', "SoftResetDone should be '0' in IDLE state");

                -- Execute a read operation to change tail position
                tb_CmdRd_Ready <= '1';
                wait until (rising_edge(tb_ClkxCI));
                wait until (rising_edge(tb_ClkxCI));
                wait for DTS_C + DTR_C;
                check_equal(tb_CmdRd_Valid, '1', "CmdRd_Valid should be '1'");

                -- Complete the read transaction
                tb_CmdRd_Ready <= '0';
                wait until (rising_edge(tb_ClkxCI));
                tb_Rd_Done     <= '1';
                wait until (rising_edge(tb_ClkxCI));
                tb_Rd_Done     <= '0';
                wait until (rising_edge(tb_ClkxCI));

                -- Check that tail has moved
                wait for DTS_C + DTR_C;
                check(unsigned(tb_TailxDO) > to_unsigned(100, AXI_ADDR_WIDTH_G_C), "Tail should have moved from initial position");

                -- Now perform soft reset
                tb_SoftResetxRBI <= '0'; -- Assert soft reset (active low)
                wait until (rising_edge(tb_ClkxCI));
                wait until (rising_edge(tb_ClkxCI));

                -- Check that we're in RESET state
                wait for DTS_C + DTR_C;
                check_equal(tb_SoftResetDonexDO, '1', "SoftResetDone should be '1' in RESET state");
                check_equal(tb_TailxDO, std_logic_vector(to_unsigned(100, AXI_ADDR_WIDTH_G_C)), "Tail should be reset to MemLow");

                -- Deassert soft reset
                tb_SoftResetxRBI <= '1';
                wait until (rising_edge(tb_ClkxCI));

                -- Check that we're back in IDLE state
                wait for DTS_C + DTR_C;
                check_equal(tb_SoftResetDonexDO, '0', "SoftResetDone should be '0' after returning to IDLE");
                check_equal(tb_TailxDO, std_logic_vector(to_unsigned(100, AXI_ADDR_WIDTH_G_C)), "Tail should remain at MemLow after soft reset");

            elsif run("softreset_during_operation") then
                -- Test soft reset during active read operation
                tb_MemLowxDI     <= std_logic_vector(to_unsigned(0, AXI_ADDR_WIDTH_G_C));
                tb_MemHighxDI    <= std_logic_vector(to_unsigned(1024, AXI_ADDR_WIDTH_G_C));
                tb_HeadxDI       <= std_logic_vector(to_unsigned(10 * WORD_LEN_C, AXI_ADDR_WIDTH_G_C));
                tb_Rd_FIFO_Level <= std_logic_vector(to_unsigned(0, log2ceil(FIFO_DEPTH_G_C + 1)));

                -- Initial reset
                tb_RstxRBI <= '0';
                wait until (rising_edge(tb_ClkxCI));
                tb_RstxRBI <= '1';
                wait until (rising_edge(tb_ClkxCI));

                -- Start a read operation
                tb_CmdRd_Ready <= '1';
                wait until (rising_edge(tb_ClkxCI));
                wait until (rising_edge(tb_ClkxCI));
                wait for DTS_C + DTR_C;
                check_equal(tb_CmdRd_Valid, '1', "CmdRd_Valid should be '1'");

                -- Accept the command but don't complete it yet
                tb_CmdRd_Ready <= '0';
                wait until (rising_edge(tb_ClkxCI));

                -- Now assert soft reset while in ISSUE_READ_CMD state
                tb_SoftResetxRBI <= '0'; -- Assert soft reset
                wait until (rising_edge(tb_ClkxCI));
                wait until (rising_edge(tb_ClkxCI));

                -- Check that we stay in this state
                wait for DTS_C + DTR_C;
                check_equal(tb_SoftResetDonexDO, '0', "SoftResetDone should be '0' until current operation completes");

                -- Now complete the read operation
                tb_Rd_Done <= '1';
                wait until (rising_edge(tb_ClkxCI));
                tb_Rd_Done <= '0';
                wait until (rising_edge(tb_ClkxCI));
                wait until (rising_edge(tb_ClkxCI));

                -- Check that we are now in reset state
                wait for DTS_C + DTR_C;
                check_equal(tb_SoftResetDonexDO, '1', "SoftResetDone should be '1' during soft reset");
                check_equal(tb_TailxDO, std_logic_vector(to_unsigned(0, AXI_ADDR_WIDTH_G_C)), "Tail should be reset to MemLow");
                check_equal(tb_CmdRd_Valid, '0', "CmdRd_Valid should be '0' during soft reset");

                -- Deassert soft reset
                tb_SoftResetxRBI <= '1';
                wait until (rising_edge(tb_ClkxCI));

                -- Check that we're back in IDLE state
                wait for DTS_C + DTR_C;
                check_equal(tb_SoftResetDonexDO, '0', "SoftResetDone should be '0' after soft reset deasserted");

            elsif run("softreset_clears_errors") then
                -- Test that soft reset clears AXI read errors
                tb_MemLowxDI     <= std_logic_vector(to_unsigned(0, AXI_ADDR_WIDTH_G_C));
                tb_MemHighxDI    <= std_logic_vector(to_unsigned(1024, AXI_ADDR_WIDTH_G_C));
                tb_HeadxDI       <= std_logic_vector(to_unsigned(5 * WORD_LEN_C, AXI_ADDR_WIDTH_G_C));
                tb_Rd_FIFO_Level <= std_logic_vector(to_unsigned(0, log2ceil(FIFO_DEPTH_G_C + 1)));

                -- Initial reset
                tb_RstxRBI <= '0';
                wait until (rising_edge(tb_ClkxCI));
                tb_RstxRBI <= '1';
                wait until (rising_edge(tb_ClkxCI));

                -- Trigger an AXI read error
                tb_CmdRd_Ready <= '1';
                wait until (rising_edge(tb_ClkxCI));
                wait until (rising_edge(tb_ClkxCI));
                tb_CmdRd_Ready <= '0';
                wait until (rising_edge(tb_ClkxCI));
                tb_Rd_Error    <= '1';
                wait until (rising_edge(tb_ClkxCI));
                tb_Rd_Error    <= '0';
                wait until (rising_edge(tb_ClkxCI));

                -- Check that error is set
                wait for DTS_C + DTR_C;
                check_equal(tb_ErrorAXIReadxDO, '1', "ErrorAXIRead should be '1' after error");

                -- Perform soft reset
                tb_SoftResetxRBI <= '0'; -- Assert soft reset
                wait until (rising_edge(tb_ClkxCI));
                wait until (rising_edge(tb_ClkxCI));
                wait for DTS_C + DTR_C;
                check_equal(tb_SoftResetDonexDO, '1', "SoftResetDone should be '1'");

                -- Deassert soft reset
                tb_SoftResetxRBI <= '1';
                wait until (rising_edge(tb_ClkxCI));

                -- Check that error is cleared
                wait for DTS_C + DTR_C;
                check_equal(tb_ErrorAXIReadxDO, '0', "ErrorAXIRead should be cleared after soft reset");

            elsif run("read_random_wraparound") then
                -- Test with random memory regions, FIFO levels and Head positions 
                -- Run the test multiple times with different random configurations

                -- Run the test multiple times
                for run_count_v in 1 to NUM_TEST_RUNS_C loop
                    info("=== Starting test run " & integer'image(run_count_v) & " of " & integer'image(NUM_TEST_RUNS_C) & " ===");

                    -- Reset variables for this test run
                    wraparoundOccurred_v := false;

                    -- Generate random memory region (aligned to word boundaries)
                    -- Use full 16-bit address space: 0 to 65535 (2^16 - 1)
                    memLowVal_v  := rand_natural(0, 2 ** (AXI_ADDR_WIDTH_G_C - 1) / WORD_LEN_C) * WORD_LEN_C;
                    memHighVal_v := rand_natural(memLowVal_v / WORD_LEN_C + 10, 2 ** (AXI_ADDR_WIDTH_G_C) / WORD_LEN_C - 1) * WORD_LEN_C;

                    --info("Random memory region: Low=" & integer'image(mem_low_val_v) & ", High=" & integer'image(mem_high_val_v) & ", Size=" & integer'image((mem_high_val_v - mem_low_val_v) / WORD_LEN_C) & " words");

                    -- Set memory boundaries
                    tb_MemLowxDI  <= std_logic_vector(to_unsigned(memLowVal_v, AXI_ADDR_WIDTH_G_C));
                    tb_MemHighxDI <= std_logic_vector(to_unsigned(memHighVal_v, AXI_ADDR_WIDTH_G_C));

                    -- Generate random initial head position within memory region
                    headVal_v := rand_mem_addr(memLowVal_v, memHighVal_v);
                    tb_HeadxDI <= std_logic_vector(to_unsigned(headVal_v, AXI_ADDR_WIDTH_G_C));

                    -- Generate random initial FIFO level (leave more space for larger read commands)
                    fifoLevel_v     := rand_fifo_level(FIFO_DEPTH_G_C); -- Up to 1/2 of FIFO depth (more space available)
                    tb_Rd_FIFO_Level <= std_logic_vector(to_unsigned(fifoLevel_v, log2ceil(FIFO_DEPTH_G_C + 1)));

                    --info("Initial setup: Head=" & integer'image(head_val_v) & ", FIFO_Level=" & integer'image(fifo_level_v));

                    -- Reset DUT for each test run to initialize tail to MemLow
                    --info("Resetting DUT for test run " & integer'image(run_count_v));
                    tb_RstxRBI <= '0';
                    wait until (rising_edge(tb_ClkxCI));
                    tb_RstxRBI <= '1';
                    wait until (rising_edge(tb_ClkxCI));

                    -- Record initial tail position
                    wait for DTS_C + DTR_C;
                    initialTail_v := to_integer(unsigned(tb_TailxDO));
                    currentTail_v := initialTail_v;

                    --info("Initial tail position: " & integer'image(initial_tail_v));

                    -- Loop until wraparound occurs or max iterations reached
                    for iteration_count_v in 1 to 1000 loop

                        -- Generate new random head position (must be ahead of current tail for data to be available)
                        headVal_v := rand_head_position(currentTail_v, memLowVal_v, memHighVal_v);
                        tb_HeadxDI <= std_logic_vector(to_unsigned(headVal_v, AXI_ADDR_WIDTH_G_C));

                        -- Generate new random FIFO level (leave sufficient space for read commands)
                        fifoLevel_v     := rand_fifo_level(FIFO_DEPTH_G_C / 2); -- Leave space for larger commands
                        tb_Rd_FIFO_Level <= std_logic_vector(to_unsigned(fifoLevel_v, log2ceil(FIFO_DEPTH_G_C + 1)));

                        --info("Run " & integer'image(run_count_v) & ", Iteration " & integer'image(iteration_count_v) & ": Head=" & integer'image(head_val_v) & ", Tail=" & integer'image(current_tail_v) & ", FIFO_Level=" & integer'image(fifo_level_v));

                        wait until (rising_edge(tb_ClkxCI));

                        -- Start read command if conditions are met (FIFO not full and data available)
                        if fifoLevel_v < FIFO_DEPTH_G_C and headVal_v /= currentTail_v then
                            tb_CmdRd_Ready <= '1';
                            wait until (rising_edge(tb_ClkxCI));

                            -- Wait for command to be issued (if any)
                            wait until (rising_edge(tb_ClkxCI));
                            wait for DTS_C + DTR_C;

                            if tb_CmdRd_Valid = '1' then
                                -- Extract command parameters for validation
                                cmdAddr_v   := to_integer(unsigned(tb_CmdRd_Addr));
                                cmdSize_v   := to_integer(unsigned(tb_CmdRd_Size));
                                fifoSpace_v := FIFO_DEPTH_G_C - fifoLevel_v;

                                --info("Command issued: Addr=" & integer'image(cmd_addr_v) & ", Size=" & integer'image(cmd_size_v));

                                -- Validation 1: CmdSize must be at least 1 and not exceed available FIFO space
                                check(cmdSize_v >= 1,
                                      "VALIDATION ERROR: CmdSize (" & integer'image(cmdSize_v) & ") must be at least 1");

                                -- Validation 2: CmdSize must not exceed available FIFO space
                                check(cmdSize_v <= fifoSpace_v,
                                      "VALIDATION ERROR: CmdSize (" & integer'image(cmdSize_v) & ") exceeds available FIFO space (" & integer'image(fifoSpace_v) & ")");

                                -- Validation 3: tail + CmdSize should not exceed memory high boundary  
                                check((cmdAddr_v + (cmdSize_v - 1) * WORD_LEN_C) <= memHighVal_v,
                                      "VALIDATION ERROR: Command end (" & integer'image((cmdAddr_v + (cmdSize_v - 1) * WORD_LEN_C)) & ") exceeds memory high boundary (" & integer'image(memHighVal_v) & ")");

                                -- Accept the command
                                tb_CmdRd_Ready <= '0';
                                wait until (rising_edge(tb_ClkxCI));

                                -- Simulate command completion
                                wait for DTS_C;
                                tb_Rd_Done <= '1';
                                wait until (rising_edge(tb_ClkxCI));
                                wait for DTS_C;
                                tb_Rd_Done <= '0';
                                wait until (rising_edge(tb_ClkxCI));

                                -- Update current tail position
                                wait for DTS_C + DTR_C;
                                wait until (rising_edge(tb_ClkxCI)); -- Extra wait for tail update
                                wait for DTS_C;
                                currentTail_v := to_integer(unsigned(tb_TailxDO));

                                --info("New tail position: " & integer'image(current_tail_v));

                                -- Validation 4: Check if tail was correctly incremented
                                bytesRead_v := cmdSize_v * WORD_LEN_C;

                                -- Normal case - check for potential wraparound in calculation
                                expectedTail_v := cmdAddr_v + bytesRead_v;

                                if expectedTail_v > memHighVal_v then
                                    -- Wraparound should occur in calculation
                                    expectedTail_v       := memLowVal_v + (expectedTail_v - memHighVal_v - WORD_LEN_C);
                                    wraparoundOccurred_v := true;
                                end if;

                                check(currentTail_v = expectedTail_v,
                                      "TAIL ERROR: Expected tail " & integer'image(expectedTail_v) & " but got " & integer'image(currentTail_v) & " (cmd_addr=" & integer'image(cmdAddr_v) & ", cmd_size=" & integer'image(cmdSize_v) & ", bytes=" & integer'image(bytesRead_v) & ")");
                            else
                                tb_CmdRd_Ready <= '0';
                                wait until (rising_edge(tb_ClkxCI));
                                info("No command issued (FIFO full or no data available)");
                            end if;
                        else
                            wait until (rising_edge(tb_ClkxCI));
                            --info("Skipping command (FIFO full or no data available)");
                        end if;

                        -- Add some random delay between operations
                        delayCycles_v := rand_natural(1, 10);
                        for i in 1 to delayCycles_v loop
                            wait until (rising_edge(tb_ClkxCI));
                        end loop;

                    end loop;

                    -- Check that wraparound actually occurred for this run
                    check(wraparoundOccurred_v, "Wraparound should have occurred in run " & integer'image(run_count_v));

                    info("=== Test run " & integer'image(run_count_v) & " completed successfully ===");

                end loop;               -- End of test runs loop

                info("All " & integer'image(NUM_TEST_RUNS_C) & " random wraparound test runs completed successfully!");

            elsif run("fifo_zero") then
                -- Test case to hit condition: fifoSpace_v <= 0 
                tb_MemLowxDI     <= std_logic_vector(to_unsigned(0, AXI_ADDR_WIDTH_G_C));
                tb_MemHighxDI    <= std_logic_vector(to_unsigned(1024, AXI_ADDR_WIDTH_G_C));
                tb_HeadxDI       <= std_logic_vector(to_unsigned(WORD_LEN_C, AXI_ADDR_WIDTH_G_C)); -- Head ahead
                tb_Rd_FIFO_Level <= std_logic_vector(to_unsigned(FIFO_DEPTH_G_C, log2ceil(FIFO_DEPTH_G_C + 1))); -- FIFO completely full

                -- Reset DUT
                tb_RstxRBI <= '0';
                wait until (rising_edge(tb_ClkxCI));
                tb_RstxRBI <= '1';
                wait until (rising_edge(tb_ClkxCI));

                -- Try to start read operation with full FIFO
                wait for DTS_C;
                tb_CmdRd_Ready <= '1';
                wait until (rising_edge(tb_ClkxCI));

                -- Check that no command is issued because FIFO is full (fifoSpace_v = 0)
                wait until (rising_edge(tb_ClkxCI));
                wait for DTS_C + DTR_C;
                check_equal(tb_CmdRd_Valid, '0', "CmdRd_Valid should be '0' when FIFO is completely full");

            elsif run("rd_error_condition") then
                -- Test case to hit condition: Rd_Error = '1'
                tb_MemLowxDI     <= std_logic_vector(to_unsigned(0, AXI_ADDR_WIDTH_G_C));
                tb_MemHighxDI    <= std_logic_vector(to_unsigned(1024, AXI_ADDR_WIDTH_G_C));
                tb_HeadxDI       <= std_logic_vector(to_unsigned(3 * WORD_LEN_C, AXI_ADDR_WIDTH_G_C)); -- Head ahead
                tb_Rd_FIFO_Level <= std_logic_vector(to_unsigned(0, log2ceil(FIFO_DEPTH_G_C + 1))); -- FIFO empty

                -- Reset DUT
                tb_RstxRBI <= '0';
                wait until (rising_edge(tb_ClkxCI));
                tb_RstxRBI <= '1';
                wait until (rising_edge(tb_ClkxCI));

                -- Start read operation  
                wait for DTS_C;
                tb_CmdRd_Ready <= '1';
                wait until (rising_edge(tb_ClkxCI));

                -- Wait for command to be issued
                wait until (rising_edge(tb_ClkxCI));
                wait for DTS_C + DTR_C;
                check_equal(tb_CmdRd_Valid, '1', "CmdRd_Valid should be '1'");

                -- Acknowledge command
                wait for DTS_C;
                tb_CmdRd_Ready <= '0';
                wait until (rising_edge(tb_ClkxCI));

                -- Signal read error instead of done
                wait for DTS_C;
                tb_Rd_Error <= '1';
                tb_Rd_Done  <= '0';
                wait until (rising_edge(tb_ClkxCI));

                -- Check that error is processed and state returns to IDLE
                wait for DTS_C + DTR_C;
                check_equal(tb_ErrorAXIReadxDO, '1', "ErrorAXIReadxDO should be '1' after Rd_Error");

                -- Clear error
                tb_Rd_Error <= '0';
                wait until (rising_edge(tb_ClkxCI));

            elsif run("address_variations") then
                -- Test various address combinations to improve toggle coverage
                for addr_test in 0 to 15 loop
                    -- Vary addresses to toggle more bits
                    tb_MemLowxDI     <= std_logic_vector(to_unsigned(addr_test * 1024, AXI_ADDR_WIDTH_G_C));
                    tb_MemHighxDI    <= std_logic_vector(to_unsigned((addr_test + 1) * 1024 + 256, AXI_ADDR_WIDTH_G_C));
                    tb_HeadxDI       <= std_logic_vector(to_unsigned(addr_test * 1024 + WORD_LEN_C, AXI_ADDR_WIDTH_G_C));
                    tb_Rd_FIFO_Level <= std_logic_vector(to_unsigned(addr_test mod 32, log2ceil(FIFO_DEPTH_G_C + 1)));

                    -- Reset DUT
                    tb_RstxRBI <= '0';
                    wait until (rising_edge(tb_ClkxCI));
                    tb_RstxRBI <= '1';
                    wait until (rising_edge(tb_ClkxCI));

                    -- Start read operation with varying size
                    wait for DTS_C;
                    tb_CmdRd_Ready <= '1';
                    wait until (rising_edge(tb_ClkxCI));

                    -- Check operation
                    wait until (rising_edge(tb_ClkxCI));
                    wait for DTS_C + DTR_C;
                    if addr_test mod 32 < FIFO_DEPTH_G_C then -- Only if FIFO not full
                        check_equal(tb_CmdRd_Valid, '1', "CmdRd_Valid should be '1' for test " & integer'image(addr_test));
                    end if;

                    -- Complete operation
                    wait for DTS_C;
                    tb_CmdRd_Ready <= '0';
                    tb_Rd_Done     <= '1';
                    wait until (rising_edge(tb_ClkxCI));
                    tb_Rd_Done <= '0';
                    wait until (rising_edge(tb_ClkxCI));
                end loop;

            elsif run("state_transitions") then
                -- Test case for additional state coverage
                tb_MemLowxDI     <= std_logic_vector(to_unsigned(0, AXI_ADDR_WIDTH_G_C));
                tb_MemHighxDI    <= std_logic_vector(to_unsigned(1024, AXI_ADDR_WIDTH_G_C));
                tb_HeadxDI       <= std_logic_vector(to_unsigned(WORD_LEN_C, AXI_ADDR_WIDTH_G_C)); -- Head ahead
                tb_Rd_FIFO_Level <= std_logic_vector(to_unsigned(0, log2ceil(FIFO_DEPTH_G_C + 1))); -- FIFO empty

                -- Reset DUT
                tb_RstxRBI <= '0';
                wait until (rising_edge(tb_ClkxCI));
                tb_RstxRBI <= '1';
                wait until (rising_edge(tb_ClkxCI));

                -- Start read operation
                wait for DTS_C;
                tb_CmdRd_Ready <= '1';
                wait until (rising_edge(tb_ClkxCI));

                -- Wait for command to be issued
                wait until (rising_edge(tb_ClkxCI));
                wait for DTS_C + DTR_C;
                check_equal(tb_CmdRd_Valid, '1', "CmdRd_Valid should be '1'");

                -- Clear ready to test different path
                tb_CmdRd_Ready <= '0';
                wait until (rising_edge(tb_ClkxCI));
                wait for DTS_C;
                
                -- Re-enable ready to complete operation
                tb_CmdRd_Ready <= '1';
                wait until (rising_edge(tb_ClkxCI));
                wait for DTS_C;

            elsif run("currsize_zero") then
                -- Test the condition where currSize_v = 0 (unaligned head pointer) 
                info("Testing currSize_v = 0");
                
                -- Set memory bounds that would create alignment issues leading to currSize_v = 0
                tb_MemLowxDI     <= std_logic_vector(to_unsigned(1001, AXI_ADDR_WIDTH_G_C)); -- Unaligned address
                tb_MemHighxDI    <= std_logic_vector(to_unsigned(1001, AXI_ADDR_WIDTH_G_C)); -- Same as MemLow to create zero range
                tb_HeadxDI       <= std_logic_vector(to_unsigned(1001, AXI_ADDR_WIDTH_G_C)); -- Same unaligned head
                tb_Rd_FIFO_Level <= std_logic_vector(to_unsigned(8, log2ceil(FIFO_DEPTH_G_C + 1))); -- FIFO has space
                
                -- Reset DUT
                tb_RstxRBI <= '0';
                wait until (rising_edge(tb_ClkxCI));
                tb_RstxRBI <= '1';
                wait until (rising_edge(tb_ClkxCI));
                
                -- Clear soft reset
                tb_SoftResetxRBI <= '0';
                wait until (rising_edge(tb_ClkxCI));
                tb_SoftResetxRBI <= '1';
                wait until (rising_edge(tb_ClkxCI));
                
                -- Try to trigger read when currSize_v would be 0 due to alignment
                wait for DTS_C;
                tb_CmdRd_Ready <= '1';
                wait until (rising_edge(tb_ClkxCI));
                
                -- Wait and check that no command is issued (because currSize_v = 0)
                wait until (rising_edge(tb_ClkxCI));
                wait for DTS_C + DTR_C;
                check_equal(tb_CmdRd_Valid, '0', "CmdRd_Valid should remain '0' when currSize_v = 0");
                
                info("currSize_v = 0 branch test completed");

            elsif run("error_expression") then
                -- Test to trigger p.errorAXIRead = '1' 
                info("Testing p.errorAXIRead");
                
                -- Set up normal memory configuration
                tb_MemLowxDI     <= std_logic_vector(to_unsigned(0, AXI_ADDR_WIDTH_G_C));
                tb_MemHighxDI    <= std_logic_vector(to_unsigned(1024, AXI_ADDR_WIDTH_G_C));
                tb_HeadxDI       <= std_logic_vector(to_unsigned(WORD_LEN_C, AXI_ADDR_WIDTH_G_C)); -- Head ahead
                tb_Rd_FIFO_Level <= std_logic_vector(to_unsigned(0, log2ceil(FIFO_DEPTH_G_C + 1))); -- FIFO empty
                
                -- Reset DUT
                tb_RstxRBI <= '0';
                wait until (rising_edge(tb_ClkxCI));
                tb_RstxRBI <= '1';
                wait until (rising_edge(tb_ClkxCI));
                
                -- Clear soft reset
                tb_SoftResetxRBI <= '0';
                wait until (rising_edge(tb_ClkxCI));
                tb_SoftResetxRBI <= '1';
                wait until (rising_edge(tb_ClkxCI));
                
                -- Start read operation
                wait for DTS_C;
                tb_CmdRd_Ready <= '1';
                wait until (rising_edge(tb_ClkxCI));
                
                -- Wait for command to be issued
                wait until (rising_edge(tb_ClkxCI));
                wait for DTS_C + DTR_C;
                check_equal(tb_CmdRd_Valid, '1', "CmdRd_Valid should be '1'");
                
                -- Simulate AXI read error to trigger p.errorAXIRead = '1'
                wait for DTS_C;
                tb_CmdRd_Ready <= '0';
                tb_Rd_Error    <= '1';  -- Set error signal
                wait until (rising_edge(tb_ClkxCI));
                
                wait for DTS_C;
                tb_Rd_Done     <= '1';  -- Complete the transaction with error
                wait until (rising_edge(tb_ClkxCI));
                
                -- Clear signals
                wait for DTS_C;
                tb_Rd_Error    <= '0';
                tb_Rd_Done     <= '0';
                wait until (rising_edge(tb_ClkxCI));
                
                -- Allow state machine to process error and check result
                wait for DTS_C + DTR_C;
                check_equal(tb_ErrorAXIReadxDO, '1', "AXI Read Error should be set after Rd_Error");
                
                info("p.errorAXIRead expression coverage test completed");

            elsif run("persistent_error_expression") then
                -- Test to hit p.errorAXIRead = '1' 
                info("Starting persistent_error_expression test for p.errorAXIRead");
                
                -- Setup normal operation first
                tb_MemLowxDI  <= std_logic_vector(to_unsigned(0, AXI_ADDR_WIDTH_G_C));
                tb_MemHighxDI <= std_logic_vector(to_unsigned(1024, AXI_ADDR_WIDTH_G_C));
                tb_HeadxDI    <= std_logic_vector(to_unsigned(100, AXI_ADDR_WIDTH_G_C));
                tb_Rd_FIFO_Level <= std_logic_vector(to_unsigned(10, log2ceil(FIFO_DEPTH_G_C + 1)));
                
                -- Reset sequence
                tb_RstxRBI <= '0';
                wait until (rising_edge(tb_ClkxCI));
                tb_RstxRBI <= '1';
                wait until (rising_edge(tb_ClkxCI));

                -- First, cause an AXI error to set p.errorAXIRead = '1'
                tb_CmdRd_Ready <= '1';
                wait until (rising_edge(tb_ClkxCI));
                
                -- Wait for state machine to enter ISSUE_READ_CMD
                wait until (rising_edge(tb_ClkxCI));
                wait for DTS_C + DTR_C;
                
                -- Trigger first error
                tb_Rd_Error <= '1';
                wait until (rising_edge(tb_ClkxCI));
                tb_Rd_Error <= '0';
                
                -- Wait for error to be processed (this sets p.errorAXIRead = '1')
                wait for DTS_C + DTR_C;
                
                -- Now trigger another read command cycle to hit the p.errorAXIRead = '1' case
                -- in the expression (p.errorAXIRead or Rd_Error)
                tb_HeadxDI <= std_logic_vector(to_unsigned(200, AXI_ADDR_WIDTH_G_C)); -- Change head
                wait until (rising_edge(tb_ClkxCI));
                
                -- Wait for state machine processing
                wait for DTS_C + DTR_C;
                
                -- At this point p.errorAXIRead should be '1' and we should hit that branch
                -- of the expression coverage
                
                info("persistent_error_expression test completed");

            end if;

        end loop;

        -- Cleanup the VUnit Runner
        test_runner_cleanup(runner);

        -- Wait forever
        wait;
    end process proc_applyTestvector;
end tb;
