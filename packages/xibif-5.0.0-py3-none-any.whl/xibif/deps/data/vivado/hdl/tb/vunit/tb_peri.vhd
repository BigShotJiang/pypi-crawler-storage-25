---------------------------------------------------------------------------------------------------
-- Project:  XiBIF
-- Customer: Generic
---------------------------------------------------------------------------------------------------
-- Description: 
-- VUnit testbench for XiBIF_Peri block using open-logic verification components
-- Tests basic functionality of the XiBIF peripheral
---------------------------------------------------------------------------------------------------
-- Created: 2025-10-06
---------------------------------------------------------------------------------------------------

library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;
use ieee.math_real.all;

library vunit_lib;
context vunit_lib.vunit_context;
context vunit_lib.com_context;
context vunit_lib.vc_context;

library olo;
use olo.olo_base_pkg_math.all;
use olo.olo_base_pkg_logic.all;
use olo.olo_axi_pkg_protocol.all;
use olo.olo_test_pkg_axi.all;
use olo.olo_test_axi_master_pkg.all;
use olo.olo_test_axi_slave_pkg.all;

-- Register map packages
use work.tb_stream_regs_package.all;

---------------------------------------------------------------------------------------------------
-- Entity
---------------------------------------------------------------------------------------------------
entity tb_peri is
    generic(
        ENABLE_TO_PC_STREAM_G   : boolean := true; -- Enable AXI Stream from PL to PC
        ENABLE_FROM_PC_STREAM_G : boolean := true; -- Enable AXI Stream from PC to PL        
        runner_cfg              : string -- @suppress "Naming convention violation: generic name should match pattern '[A-Z0-9_]*_G'"
    );
end entity;

architecture tb of tb_peri is

    -----------------------------------------------------------------------------------------------
    -- Constants
    -----------------------------------------------------------------------------------------------
    constant FIFO_DEPTH_C      : positive                := 32;
    constant MAX_BURST_LEN_C   : positive                := 16;
    constant AXI_ADDR_WIDTH_C  : positive range 12 to 64 := 32;
    constant AXI_DATA_WIDTH_C  : positive range 8 to 64  := 32;
    constant AXIL_ADDR_WIDTH_C : positive range 8 to 32  := 10;
    constant AXIL_DATA_WIDTH_C : positive range 8 to 64  := 32;

    -----------------------------------------------------------------------------------------------
    -- AXI4-Lite Master Definition (for register access)
    -----------------------------------------------------------------------------------------------
    constant AXIL_ID_WIDTH_C   : integer := 0;
    constant AXIL_USER_WIDTH_C : integer := 0;
    constant AXIL_BYTE_WIDTH_C : integer := AXIL_DATA_WIDTH_C / 8;

    subtype AXIL_ID_RANGE_C   is natural range AXIL_ID_WIDTH_C - 1 downto 0; -- @suppress
    subtype AXIL_ADDR_RANGE_C is natural range AXIL_ADDR_WIDTH_C - 1 downto 0; -- @suppress
    subtype AXIL_USER_RANGE_C is natural range AXIL_USER_WIDTH_C - 1 downto 0; -- @suppress
    subtype AXIL_DATA_RANGE_C is natural range AXIL_DATA_WIDTH_C - 1 downto 0; -- @suppress
    subtype AXIL_BYTE_RANGE_C is natural range AXIL_BYTE_WIDTH_C - 1 downto 0; -- @suppress

    signal AxilMs : axi_ms_t(ar_id(AXIL_ID_RANGE_C), aw_id(AXIL_ID_RANGE_C),
                             ar_addr(AXIL_ADDR_RANGE_C), aw_addr(AXIL_ADDR_RANGE_C),
                             ar_user(AXIL_USER_RANGE_C), aw_user(AXIL_USER_RANGE_C), w_user(AXIL_USER_RANGE_C),
                             w_data(AXIL_DATA_RANGE_C),
                             w_strb(AXIL_BYTE_RANGE_C));

    signal AxilSm : axi_sm_t(r_id(AXIL_ID_RANGE_C), b_id(AXIL_ID_RANGE_C),
                             r_user(AXIL_USER_RANGE_C), b_user(AXIL_USER_RANGE_C),
                             r_data(AXIL_DATA_RANGE_C));

    -----------------------------------------------------------------------------------------------
    -- AXI4 Slave Definition (for memory interface)
    -----------------------------------------------------------------------------------------------
    constant AXI_ID_WIDTH_C   : integer := 0;
    constant AXI_USER_WIDTH_C : integer := 0;
    constant AXI_BYTE_WIDTH_C : integer := AXI_DATA_WIDTH_C / 8;

    subtype AXI_ID_RANGE_C   is natural range AXI_ID_WIDTH_C - 1 downto 0; -- @suppress
    subtype AXI_ADDR_RANGE_C is natural range AXI_ADDR_WIDTH_C - 1 downto 0; -- @suppress
    subtype AXI_USER_RANGE_C is natural range AXI_USER_WIDTH_C - 1 downto 0; -- @suppress
    subtype AXI_DATA_RANGE_C is natural range AXI_DATA_WIDTH_C - 1 downto 0; -- @suppress
    subtype AXI_BYTE_RANGE_C is natural range AXI_BYTE_WIDTH_C - 1 downto 0; -- @suppress

    signal AxiMsMem : axi_ms_t(ar_id(AXI_ID_RANGE_C), aw_id(AXI_ID_RANGE_C),
                               ar_addr(AXI_ADDR_RANGE_C), aw_addr(AXI_ADDR_RANGE_C),
                               ar_user(AXI_USER_RANGE_C), aw_user(AXI_USER_RANGE_C), w_user(AXI_USER_RANGE_C),
                               w_data(AXI_DATA_RANGE_C),
                               w_strb(AXI_BYTE_RANGE_C));

    signal AxiSmMem : axi_sm_t(r_id(AXI_ID_RANGE_C), b_id(AXI_ID_RANGE_C),
                               r_user(AXI_USER_RANGE_C), b_user(AXI_USER_RANGE_C),
                               r_data(AXI_DATA_RANGE_C));

    -----------------------------------------------------------------------------------------------
    -- TB Definitions
    -----------------------------------------------------------------------------------------------
    constant CLK_FREQUENCY_C : real := 100.0e6;
    constant CLK_PERIOD_C    : time := (1 sec) / CLK_FREQUENCY_C;

    -- *** Verification Components ***
    constant AXIL_MASTER_C : olo_test_axi_master_t := new_olo_test_axi_master(
        data_width => AXIL_DATA_WIDTH_C,
        addr_width => AXIL_ADDR_WIDTH_C,
        id_width   => AXIL_ID_WIDTH_C
    );

    constant AXI_SLAVE_C : olo_test_axi_slave_t := new_olo_test_axi_slave(
        data_width => AXI_DATA_WIDTH_C,
        addr_width => AXI_ADDR_WIDTH_C,
        id_width   => AXI_ID_WIDTH_C
    );

    constant AXIS_SLAVE_C : axi_stream_slave_t := new_axi_stream_slave(
        data_length  => AXI_DATA_WIDTH_C,
        stall_config => new_stall_config(0.0, 0, 0)
    );

    constant AXIS_MASTER_C : axi_stream_master_t := new_axi_stream_master(
        data_length  => AXI_DATA_WIDTH_C,
        stall_config => new_stall_config(0.0, 0, 0)
    );

    -----------------------------------------------------------------------------------------------
    -- Interface Signals
    -----------------------------------------------------------------------------------------------
    -- Control
    signal Clk : std_logic := '0';
    signal Rst : std_logic := '1';

    -- FIFO Level signals
    signal WrFIFOLevelxDO : std_logic_vector(AXIL_DATA_WIDTH_C - 1 downto 0);
    signal RdFIFOLevelxDO : std_logic_vector(AXIL_DATA_WIDTH_C - 1 downto 0);

    -- Status and Control signals
    signal SnCHostConnectedxDO : std_logic;
    signal SnCSoftwareResetxRO : std_logic;

    -- AXI Streams
    signal axisToPCTvalid   : std_logic;
    signal axisToPCTready   : std_logic;
    signal axisToPCtdata    : std_logic_vector(AXI_DATA_WIDTH_C - 1 downto 0);
    signal axisFromPCTvalid : std_logic;
    signal axisFromPCTready : std_logic;
    signal axisFromPCTdata  : std_logic_vector(AXI_DATA_WIDTH_C - 1 downto 0);

    -----------------------------------------------------------------------------------------------
    -- Funtion to convert boolean to integer
    -----------------------------------------------------------------------------------------------
    function toStd(b : boolean) return std_logic is
    begin
        if b then
            return '1';
        else
            return '0';
        end if;
    end function toStd;

    -----------------------------------------------------------------------------------------------
    -- Procedures for AXI-Stream
    -----------------------------------------------------------------------------------------------
    procedure pushWrData(
        signal net : inout network_t;
        startValue :       unsigned;
        increment  :       natural := 1;
        beats      :       natural := 1) is
        variable Data_v : unsigned(AXI_DATA_WIDTH_C - 1 downto 0);
    begin
        Data_v := resize(startValue, AXI_DATA_WIDTH_C);

        -- loop through beats
        for i in 0 to beats - 1 loop
            info("Pushing WrData " & integer'image(i) & " : " & to_hstring(Data_v));
            push_axi_stream(net, AXIS_MASTER_C, std_logic_vector(Data_v));
            Data_v := Data_v + increment;
        end loop;

    end procedure;

    procedure expectRdData(
        signal net : inout network_t;
        startValue :       unsigned;
        increment  :       natural := 1;
        beats      :       natural := 1) is
        variable Data_v : unsigned(AXI_DATA_WIDTH_C - 1 downto 0);
    begin
        Data_v := resize(startValue, AXI_DATA_WIDTH_C);

        -- loop through beats
        for i in 0 to beats - 1 loop
            info("Expecting RdData " & integer'image(i) & " : " & to_hstring(Data_v));
            check_axi_stream(net, AXIS_SLAVE_C, std_logic_vector(Data_v), blocking => false, msg => "RdData " & integer'image(i));
            Data_v := Data_v + increment;
        end loop;

    end procedure;

    procedure performReset(signal Rst : out std_logic) is
    begin
        Rst <= '0';
        wait until (rising_edge(Clk));
        Rst <= '1';
        wait until (rising_edge(Clk));
    end procedure;

begin

    -----------------------------------------------------------------------------------------------
    -- Clock
    -----------------------------------------------------------------------------------------------
    Clk <= not Clk after 0.5 * CLK_PERIOD_C;

    -----------------------------------------------------------------------------------------------
    -- DUT
    -----------------------------------------------------------------------------------------------
    inst_DUT : entity work.XiBIF_Peri
        generic map(
            ENABLE_TO_PC_STREAM_G   => ENABLE_TO_PC_STREAM_G,
            ENABLE_FROM_PC_STREAM_G => ENABLE_FROM_PC_STREAM_G,
            MAX_BURST_LEN_G         => MAX_BURST_LEN_C,
            FIFO_DEPTH_G            => FIFO_DEPTH_C,
            AXI_ADDR_WIDTH_G        => AXI_ADDR_WIDTH_C,
            AXI_DATA_WIDTH_G        => AXI_DATA_WIDTH_C,
            AXIL_ADDR_WIDTH_G       => AXIL_ADDR_WIDTH_C,
            AXIL_DATA_WIDTH_G       => AXIL_DATA_WIDTH_C
        )
        port map(
            -- Clock and Reset
            ClkxCI              => Clk,
            RstxRBI             => Rst,
            -- AXI Lite Slave 
            S_AXIL_awaddr       => AxilMs.aw_addr,
            S_AXIL_awvalid      => AxilMs.aw_valid,
            S_AXIL_awready      => AxilSm.aw_ready,
            S_AXIL_wdata        => AxilMs.w_data,
            S_AXIL_wstrb        => AxilMs.w_strb,
            S_AXIL_wvalid       => AxilMs.w_valid,
            S_AXIL_wready       => AxilSm.w_ready,
            S_AXIL_bvalid       => AxilSm.b_valid,
            S_AXIL_bready       => AxilMs.b_ready,
            S_AXIL_araddr       => AxilMs.ar_addr,
            S_AXIL_arvalid      => AxilMs.ar_valid,
            S_AXIL_arready      => AxilSm.ar_ready,
            S_AXIL_rdata        => AxilSm.r_data,
            S_AXIL_rvalid       => AxilSm.r_valid,
            S_AXIL_rready       => AxilMs.r_ready,
            S_AXIL_awprot       => AxilMs.aw_prot,
            S_AXIL_bresp        => AxilSm.b_resp,
            S_AXIL_arprot       => AxilMs.ar_prot,
            S_AXIL_rresp        => AxilSm.r_resp,
            -- AXI Streams
            AXIS_TO_PC_tvalid   => axisToPCTvalid,
            AXIS_TO_PC_tready   => axisToPCTready,
            AXIS_TO_PC_tdata    => axisToPCtdata,
            AXIS_FROM_PC_tvalid => axisFromPCTvalid,
            AXIS_FROM_PC_tready => axisFromPCTready,
            AXIS_FROM_PC_tdata  => axisFromPCTdata,
            -- AXI Master
            M_AXI_AWADDR        => AxiMsMem.aw_addr,
            M_AXI_AWLEN         => AxiMsMem.aw_len,
            M_AXI_AWCACHE       => AxiMsMem.aw_cache,
            M_AXI_AWPROT        => AxiMsMem.aw_prot,
            M_AXI_AWVALID       => AxiMsMem.aw_valid,
            M_AXI_AWREADY       => AxiSmMem.aw_ready,
            M_Axi_AwSize        => AxiMsMem.aw_size,
            M_Axi_AwBurst       => AxiMsMem.aw_burst,
            M_Axi_AwLock        => AxiMsMem.aw_lock,
            M_AXI_WDATA         => AxiMsMem.w_data,
            M_AXI_WSTRB         => AxiMsMem.w_strb,
            M_AXI_WLAST         => AxiMsMem.w_last,
            M_AXI_WVALID        => AxiMsMem.w_valid,
            M_AXI_WREADY        => AxiSmMem.w_ready,
            M_AXI_BRESP         => AxiSmMem.b_resp,
            M_AXI_BVALID        => AxiSmMem.b_valid,
            M_AXI_BREADY        => AxiMsMem.b_ready,
            M_AXI_ARADDR        => AxiMsMem.ar_addr,
            M_AXI_ARLEN         => AxiMsMem.ar_len,
            M_Axi_ArSize        => AxiMsMem.ar_size,
            M_Axi_ArBurst       => AxiMsMem.ar_burst,
            M_Axi_ArLock        => AxiMsMem.ar_lock,
            M_AXI_ARCACHE       => AxiMsMem.ar_cache,
            M_AXI_ARPROT        => AxiMsMem.ar_prot,
            M_AXI_ARVALID       => AxiMsMem.ar_valid,
            M_AXI_ARREADY       => AxiSmMem.ar_ready,
            M_AXI_RDATA         => AxiSmMem.r_data,
            M_AXI_RRESP         => AxiSmMem.r_resp,
            M_AXI_RLAST         => AxiSmMem.r_last,
            M_AXI_RVALID        => AxiSmMem.r_valid,
            M_AXI_RREADY        => AxiMsMem.r_ready,
            -- Register Ports and FIFO status info
            WrFIFOLevelxDO      => WrFIFOLevelxDO,
            RdFIFOLevelxDO      => RdFIFOLevelxDO,
            SnCHostConnectedxDO => SnCHostConnectedxDO,
            SnCSoftwareResetxRO => SnCSoftwareResetxRO
        );

    -----------------------------------------------------------------------------------------------
    -- Verification Components
    -----------------------------------------------------------------------------------------------

    -- AXI4-Lite Master VC (for register access)
    inst_axiLiteVC : entity olo.olo_test_axi_lite_master_vc
        generic map(
            instance => AXIL_MASTER_C
        )
        port map(
            Clk    => Clk,
            Axi_Ms => AxilMs,
            Axi_Sm => AxilSm
        );

    -- AXI4 Slave VC (memory interface)
    inst_axiVC : entity olo.olo_test_axi_slave_vc
        generic map(
            instance => AXI_SLAVE_C
        )
        port map(
            Clk    => Clk,
            Axi_Ms => AxiMsMem,
            Axi_Sm => AxiSmMem
        );

    -- AXI Stream Slave VC (From PC stream)
    inst_axisSlaveVC : entity vunit_lib.axi_stream_slave
        generic map(
            Slave => AXIS_SLAVE_C
        )
        port map(                       -- @suppress "Port map uses default values. Missing optional actuals: areset_n, tlast, and 5 more"
            AClk   => Clk,
            TValid => axisFromPCTvalid,
            TReady => axisFromPCTready,
            TData  => axisFromPCtdata
        );

    -- AXI Stream Master VC (To PC stream)
    inst_axisMasterVC : entity vunit_lib.axi_stream_master
        generic map(                    -- @suppress "Generic map uses default values. Missing optional actuals: drive_invalid, drive_invalid_val, drive_invalid_val_user"
            Master => AXIS_MASTER_C
        )
        port map(                       -- @suppress "Port map uses default values. Missing optional actuals: areset_n, tlast, and 5 more"
            AClk   => Clk,
            TValid => axisToPCTvalid,
            TReady => axisToPCTready,
            TData  => axisToPCTdata
        );

    -----------------------------------------------------------------------------------------------
    -- Main Test Process
    -----------------------------------------------------------------------------------------------
    main : process
        variable seed1_v, seed2_v     : integer := 999; -- @suppress "The type of a variable has to be constrained in size"
        variable randUnsigned_v       : unsigned(AXIL_DATA_WIDTH_C - 1 downto 0);
        variable memToPCLow_v         : unsigned(AXIL_DATA_WIDTH_C - 1 downto 0);
        variable memToPCHigh_v        : unsigned(AXIL_DATA_WIDTH_C - 1 downto 0);
        variable memFromPCLow_v       : unsigned(AXIL_DATA_WIDTH_C - 1 downto 0);
        variable memFromPCHigh_v      : unsigned(AXIL_DATA_WIDTH_C - 1 downto 0);
        variable expectedAddress_v    : unsigned(AXIL_DATA_WIDTH_C - 1 downto 0);
        variable expectedAddressOld_v : unsigned(AXIL_DATA_WIDTH_C - 1 downto 0);
        variable dataHandled_v        : unsigned(AXI_DATA_WIDTH_C - 1 downto 0);

        variable regsStream_v : csr_XiBIF_stream_regs_t := csr_xibif_stream_regs_reset;

        impure function rand_slv(len : integer) return std_logic_vector is
            variable r_v   : real;
            variable slv_v : std_logic_vector(len - 1 downto 0);
        begin
            for i in slv_v'range loop
                uniform(seed1_v, seed2_v, r_v);
                slv_v(i) := '1' when r_v > 0.5 else '0';
            end loop;
            return slv_v;
        end function;

        impure function rand_unsigned(len : integer) return unsigned is
        begin
            return unsigned(rand_slv(len));
        end function;

        procedure push_single_write(addr : csr_xibif_stream_regs_address_t) is
        begin
            push_single_write(net, AXIL_MASTER_C, unsigned(csr_xibif_stream_regs_address(addr)), unsigned(csr_xibif_stream_regs_get(regsStream_v, addr)));
        end procedure;

        procedure expect_single_read(addr : csr_xibif_stream_regs_address_t) is
        begin
            expect_single_read(net, AXIL_MASTER_C, unsigned(csr_xibif_stream_regs_address(addr)), unsigned(csr_xibif_stream_regs_get(regsStream_v, addr)));
        end procedure;

    begin
        test_runner_setup(runner, runner_cfg);

        while test_suite loop

            -- Reset
            performReset(Rst);
            regsStream_v := csr_xibif_stream_regs_reset;

            if run("test_basic_functionality") then
                -- Write some values to the memory registers and read them back
                regsStream_v.csr_fifo_from_pc_1.csr_low := rand_slv(AXIL_DATA_WIDTH_C);
                push_single_write(CSR_FIFO_FROM_PC_1);
                expect_single_read(CSR_FIFO_FROM_PC_1);

                regsStream_v.csr_fifo_from_pc_2.csr_high := rand_slv(AXIL_DATA_WIDTH_C);
                push_single_write(CSR_FIFO_FROM_PC_2);
                expect_single_read(CSR_FIFO_FROM_PC_2);

                regsStream_v.csr_fifo_to_pc_1.csr_low := rand_slv(AXIL_DATA_WIDTH_C);
                push_single_write(CSR_FIFO_TO_PC_1);
                expect_single_read(CSR_FIFO_TO_PC_1);

                regsStream_v.csr_fifo_to_pc_2.csr_high := rand_slv(AXIL_DATA_WIDTH_C);
                push_single_write(CSR_FIFO_TO_PC_2);
                expect_single_read(CSR_FIFO_TO_PC_2);

                -- Read AXi Registers
                regsStream_v.csr_axi_stream_1.csr_width := std_logic_vector(to_unsigned(AXIL_DATA_WIDTH_C, AXIL_DATA_WIDTH_C));
                expect_single_read(CSR_AXI_STREAM_1);
                regsStream_v.csr_axi_stream_2.csr_width := std_logic_vector(to_unsigned(FIFO_DEPTH_C, AXIL_DATA_WIDTH_C));
                expect_single_read(CSR_AXI_STREAM_2);

                -- Verify that the streams are correctly reported
                regsStream_v.csr_axi_stream_3.csr_enablefifofrompc := toStd(ENABLE_FROM_PC_STREAM_G);
                regsStream_v.csr_axi_stream_3.csr_enablefifotopc   := toStd(ENABLE_TO_PC_STREAM_G);
                expect_single_read(CSR_AXI_STREAM_3);

            elsif run("test_data_write_single") then
                -- Check if the stream is enabled
                if ENABLE_TO_PC_STREAM_G = true then -- @suppress "Redundant boolean equality check with true"
                    -- Generate memory adresses
                    memFromPCLow_v  := to_unsigned(10 * AXI_BYTE_WIDTH_C, AXIL_DATA_WIDTH_C);
                    memFromPCHigh_v := to_unsigned(20 * AXI_BYTE_WIDTH_C, AXIL_DATA_WIDTH_C);
                    memToPCLow_v    := to_unsigned(30 * AXI_BYTE_WIDTH_C, AXIL_DATA_WIDTH_C);
                    memToPCHigh_v   := to_unsigned(40 * AXI_BYTE_WIDTH_C, AXIL_DATA_WIDTH_C);

                    -- Setup high and low memory addresses
                    regsStream_v.csr_fifo_from_pc_1.csr_low  := std_logic_vector(memFromPCLow_v);
                    push_single_write(CSR_FIFO_FROM_PC_1);
                    regsStream_v.csr_fifo_from_pc_2.csr_high := std_logic_vector(memFromPCHigh_v);
                    push_single_write(CSR_FIFO_FROM_PC_2);
                    regsStream_v.csr_fifo_from_pc_4.csr_head := std_logic_vector(memFromPCLow_v);
                    push_single_write(CSR_FIFO_FROM_PC_4);
                    regsStream_v.csr_fifo_to_pc_1.csr_low    := std_logic_vector(memToPCLow_v);
                    push_single_write(CSR_FIFO_TO_PC_1);
                    regsStream_v.csr_fifo_to_pc_2.csr_high   := std_logic_vector(memToPCHigh_v);
                    push_single_write(CSR_FIFO_TO_PC_2);
                    regsStream_v.csr_fifo_to_pc_5.csr_tail   := std_logic_vector(memToPCLow_v);
                    push_single_write(CSR_FIFO_TO_PC_5);

                    -- Reset
                    regsStream_v.csr_reset.csr_enablehardreset := '1';
                    regsStream_v.csr_reset.csr_reset           := '0';
                    push_single_write(CSR_RESET);
                    regsStream_v.csr_reset.csr_enablehardreset := '0';
                    regsStream_v.csr_reset.csr_reset           := '1';
                    push_single_write(CSR_RESET);
                    wait_until_idle(net, as_sync(AXIL_MASTER_C));

                    -- Verify head and tail pointers are reset
                    regsStream_v.csr_fifo_from_pc_4.csr_head := std_logic_vector(memFromPCLow_v);
                    expect_single_read(CSR_FIFO_FROM_PC_4);
                    regsStream_v.csr_fifo_from_pc_5.csr_tail := std_logic_vector(memFromPCLow_v);
                    expect_single_read(CSR_FIFO_FROM_PC_5);
                    regsStream_v.csr_fifo_to_pc_4.csr_head   := std_logic_vector(memToPCLow_v);
                    expect_single_read(CSR_FIFO_TO_PC_4);
                    regsStream_v.csr_fifo_to_pc_5.csr_tail   := std_logic_vector(memToPCLow_v);
                    expect_single_read(CSR_FIFO_TO_PC_5);
                    wait_until_idle(net, as_sync(AXIL_MASTER_C));

                    -- Verify that the stream is not ready
                    check_equal(axisToPCTready, '0', "axisToPCTready should be 0 before halt condition is cleared.");

                    -- Remove halt condition and verify stream is ready
                    regsStream_v.csr_reset.csr_halt := '0';
                    push_single_write(CSR_RESET);
                    wait_until_idle(net, as_sync(AXIL_MASTER_C));
                    wait until rising_edge(Clk);
                    check_equal(axisToPCTready, '1', "axisToPCTready should be 1 after halt condition is cleared.");

                    -- Loop through the whole memory space + 2 to test wrap-around
                    expectedAddress_v := memToPCLow_v;
                    for i in 0 to to_integer((memToPCHigh_v - memToPCLow_v)) / AXI_BYTE_WIDTH_C + 2 loop
                        info("Iteration " & integer'image(i));

                        -- Write a single value to the FIFO
                        randUnsigned_v := rand_unsigned(AXIL_DATA_WIDTH_C);
                        pushWrData(net, randUnsigned_v);
                        wait_until_idle(net, as_sync(AXIS_MASTER_C));
                        wait until rising_edge(Clk);

                        -- Check FIFO levels
                        check_equal(WrFIFOLevelxDO, to_unsigned(1, AXIL_DATA_WIDTH_C), "WrFIFOLevelxDO after 1 write to AXI Stream");

                        -- Read back the value from the memory interface
                        info("Reading back the value from memory at address " & to_hstring(expectedAddress_v));
                        expect_single_write(net, AXI_SLAVE_C, expectedAddress_v, randUnsigned_v);
                        wait_until_idle(net, as_sync(AXI_SLAVE_C));
                        wait until rising_edge(Clk);

                        -- Check FIFO levels
                        check_equal(WrFIFOLevelxDO, to_unsigned(0, AXIL_DATA_WIDTH_C), "WrFIFOLevelxDO after 1 read from AXI Mem");

                        -- Increment expected address and check head
                        expectedAddress_v := expectedAddress_v + to_unsigned(AXI_BYTE_WIDTH_C, AXIL_DATA_WIDTH_C);
                        if expectedAddress_v > memToPCHigh_v then
                            expectedAddress_v := memToPCLow_v;
                        end if;

                        -- Check new head
                        regsStream_v.csr_fifo_to_pc_4.csr_head := std_logic_vector(expectedAddress_v);
                        expect_single_read(CSR_FIFO_TO_PC_4);

                        -- Check error status (should be 0)
                        regsStream_v.csr_fifo_to_pc_3.csr_error_axi     := '0';
                        regsStream_v.csr_fifo_to_pc_3.csr_error_memfull := '0';
                        expect_single_read(CSR_FIFO_TO_PC_3);

                        -- Increment tail to free up space
                        regsStream_v.csr_fifo_to_pc_5.csr_tail := std_logic_vector(expectedAddress_v);
                        push_single_write(CSR_FIFO_TO_PC_5);
                        wait_until_idle(net, as_sync(AXIL_MASTER_C));
                        wait_until_idle(net, as_sync(AXIS_MASTER_C));
                        wait_until_idle(net, as_sync(AXI_SLAVE_C));
                    end loop;
                end if;

            elsif run("test_data_write_fifo") then
                -- Check if the stream is enabled
                if ENABLE_TO_PC_STREAM_G = true then -- @suppress "Redundant boolean equality check with true"
                    -- Generate memory adresses
                    memFromPCLow_v  := to_unsigned(0 * AXI_BYTE_WIDTH_C, AXIL_DATA_WIDTH_C);
                    memFromPCHigh_v := memFromPCLow_v + to_unsigned((3 * FIFO_DEPTH_C) / 2 * AXI_BYTE_WIDTH_C, AXIL_DATA_WIDTH_C);
                    memToPCLow_v    := memFromPCHigh_v + to_unsigned(AXI_BYTE_WIDTH_C, AXIL_DATA_WIDTH_C);
                    memToPCHigh_v   := memToPCLow_v + to_unsigned((3 * FIFO_DEPTH_C) / 2 * AXI_BYTE_WIDTH_C, AXIL_DATA_WIDTH_C);

                    -- Setup high and low memory addresses
                    regsStream_v.csr_fifo_from_pc_1.csr_low  := std_logic_vector(memFromPCLow_v);
                    push_single_write(CSR_FIFO_FROM_PC_1);
                    regsStream_v.csr_fifo_from_pc_2.csr_high := std_logic_vector(memFromPCHigh_v);
                    push_single_write(CSR_FIFO_FROM_PC_2);
                    regsStream_v.csr_fifo_from_pc_4.csr_head := std_logic_vector(memFromPCLow_v);
                    push_single_write(CSR_FIFO_FROM_PC_4);
                    regsStream_v.csr_fifo_to_pc_1.csr_low    := std_logic_vector(memToPCLow_v);
                    push_single_write(CSR_FIFO_TO_PC_1);
                    regsStream_v.csr_fifo_to_pc_2.csr_high   := std_logic_vector(memToPCHigh_v);
                    push_single_write(CSR_FIFO_TO_PC_2);
                    regsStream_v.csr_fifo_to_pc_5.csr_tail   := std_logic_vector(memToPCLow_v);
                    push_single_write(CSR_FIFO_TO_PC_5);

                    -- Reset
                    regsStream_v.csr_reset.csr_enablehardreset := '1';
                    regsStream_v.csr_reset.csr_reset           := '0';
                    push_single_write(CSR_RESET);
                    regsStream_v.csr_reset.csr_enablehardreset := '0';
                    regsStream_v.csr_reset.csr_reset           := '1';
                    push_single_write(CSR_RESET);
                    wait_until_idle(net, as_sync(AXIL_MASTER_C));

                    -- Verify head and tail pointers are reset
                    regsStream_v.csr_fifo_from_pc_4.csr_head := std_logic_vector(memFromPCLow_v);
                    expect_single_read(CSR_FIFO_FROM_PC_4);
                    regsStream_v.csr_fifo_from_pc_5.csr_tail := std_logic_vector(memFromPCLow_v);
                    expect_single_read(CSR_FIFO_FROM_PC_5);
                    regsStream_v.csr_fifo_to_pc_4.csr_head   := std_logic_vector(memToPCLow_v);
                    expect_single_read(CSR_FIFO_TO_PC_4);
                    regsStream_v.csr_fifo_to_pc_5.csr_tail   := std_logic_vector(memToPCLow_v);
                    expect_single_read(CSR_FIFO_TO_PC_5);

                    -- Verify that the stream is not ready
                    check_equal(axisToPCTready, '0', "axisToPCTready should be 0 before halt condition is cleared.");

                    -- Remove halt condition and verify stream is ready
                    regsStream_v.csr_reset.csr_halt := '0';
                    push_single_write(CSR_RESET);
                    wait_until_idle(net, as_sync(AXIL_MASTER_C));
                    wait until rising_edge(Clk);
                    check_equal(axisToPCTready, '1', "axisToPCTready should be 1 after halt condition is cleared.");

                    -- Write a full vurst of FIFO_DEPTH_C values to the FIFO
                    info("Write first full FIFO burst of " & integer'image(FIFO_DEPTH_C) & " values");
                    randUnsigned_v := rand_unsigned(AXIL_DATA_WIDTH_C);
                    pushWrData(net, randUnsigned_v, 1, FIFO_DEPTH_C);
                    wait_until_idle(net, as_sync(AXIL_MASTER_C));
                    wait_until_idle(net, as_sync(AXIS_MASTER_C));
                    wait until rising_edge(Clk);

                    -- Check FIFO levels
                    check_equal(WrFIFOLevelxDO, to_unsigned(FIFO_DEPTH_C, AXIL_DATA_WIDTH_C), "WrFIFOLevelxDO after 1 write to AXI Stream");

                    -- First a single value is transferred
                    expect_single_write(net, AXI_SLAVE_C, memToPCLow_v, randUnsigned_v);

                    -- Read back the values from the memory interface
                    expectedAddress_v := memToPCLow_v + AXI_BYTE_WIDTH_C;
                    randUnsigned_v    := randUnsigned_v + to_unsigned(1, AXIL_DATA_WIDTH_C);
                    for i in 0 to (FIFO_DEPTH_C / MAX_BURST_LEN_C) - 1 loop
                        info("Iteration " & integer'image(i));
                        if i = (FIFO_DEPTH_C / MAX_BURST_LEN_C) - 1 then
                            -- Last burst might be smaller
                            expect_burst_write_aligned(net, AXI_SLAVE_C, expectedAddress_v, randUnsigned_v, 1, MAX_BURST_LEN_C - 1);
                            expectedAddress_v := expectedAddress_v + to_unsigned((MAX_BURST_LEN_C - 1) * AXI_BYTE_WIDTH_C, AXIL_DATA_WIDTH_C);
                        else
                            expect_burst_write_aligned(net, AXI_SLAVE_C, expectedAddress_v, randUnsigned_v, 1, MAX_BURST_LEN_C);
                            expectedAddress_v := expectedAddress_v + to_unsigned(MAX_BURST_LEN_C * AXI_BYTE_WIDTH_C, AXIL_DATA_WIDTH_C);
                        end if;
                        wait_until_idle(net, as_sync(AXI_SLAVE_C));

                        -- Increment expected values                    
                        randUnsigned_v := randUnsigned_v + to_unsigned(MAX_BURST_LEN_C, AXIL_DATA_WIDTH_C);
                    end loop;

                    -- Check new head
                    regsStream_v.csr_fifo_to_pc_4.csr_head := std_logic_vector(expectedAddress_v);
                    expect_single_read(CSR_FIFO_TO_PC_4);

                    -- Check error status (should be 0)
                    regsStream_v.csr_fifo_to_pc_3.csr_error_axi     := '0';
                    regsStream_v.csr_fifo_to_pc_3.csr_error_memfull := '0';
                    expect_single_read(CSR_FIFO_TO_PC_3);

                    -- Increment tail to free up space
                    regsStream_v.csr_fifo_to_pc_5.csr_tail := std_logic_vector(expectedAddress_v);
                    push_single_write(CSR_FIFO_TO_PC_5);
                    wait_until_idle(net, as_sync(AXIL_MASTER_C));

                    -- Write a full vurst of FIFO_DEPTH_C values to the FIFO
                    info("Write second full FIFO burst of " & integer'image(FIFO_DEPTH_C) & " values");
                    randUnsigned_v := rand_unsigned(AXIL_DATA_WIDTH_C);
                    pushWrData(net, randUnsigned_v, 1, FIFO_DEPTH_C);
                    wait_until_idle(net, as_sync(AXIL_MASTER_C));
                    wait_until_idle(net, as_sync(AXIS_MASTER_C));
                    wait until rising_edge(Clk);

                    -- Check FIFO levels
                    check_equal(WrFIFOLevelxDO, to_unsigned(FIFO_DEPTH_C, AXIL_DATA_WIDTH_C), "WrFIFOLevelxDO after 1 write to AXI Stream");

                    -- First a single value is transferred
                    expect_single_write(net, AXI_SLAVE_C, expectedAddress_v, randUnsigned_v);

                    -- Read back the values from the memory interface
                    expectedAddress_v := expectedAddress_v + AXI_BYTE_WIDTH_C;
                    randUnsigned_v    := randUnsigned_v + to_unsigned(1, AXIL_DATA_WIDTH_C);
                    dataHandled_v     := to_unsigned(1, AXI_DATA_WIDTH_C);

                    while dataHandled_v < to_unsigned(FIFO_DEPTH_C, AXI_DATA_WIDTH_C) loop
                        info("Data handled so far: " & integer'image(to_integer(dataHandled_v)));

                        -- Calculate length of next burst
                        info("Expected address: " & to_hstring(expectedAddress_v));
                        if expectedAddress_v + to_unsigned(MAX_BURST_LEN_C * AXI_BYTE_WIDTH_C, AXIL_DATA_WIDTH_C) > memToPCHigh_v then
                            -- Wrap around
                            expect_burst_write_aligned(net, AXI_SLAVE_C, expectedAddress_v, randUnsigned_v, 1, to_integer((memToPCHigh_v - expectedAddress_v) / to_unsigned(AXI_BYTE_WIDTH_C, AXIL_DATA_WIDTH_C) + 1));

                            -- Caclulate next expected values
                            dataHandled_v     := dataHandled_v + (memToPCHigh_v - expectedAddress_v) / to_unsigned(AXI_BYTE_WIDTH_C, AXI_DATA_WIDTH_C) + 1;
                            randUnsigned_v    := randUnsigned_v + (memToPCHigh_v - expectedAddress_v) / to_unsigned(AXI_BYTE_WIDTH_C, AXIL_DATA_WIDTH_C) + 1;
                            expectedAddress_v := memToPCLow_v;
                        else
                            if dataHandled_v + to_unsigned(MAX_BURST_LEN_C, AXI_DATA_WIDTH_C) >= to_unsigned(FIFO_DEPTH_C, AXI_DATA_WIDTH_C) then
                                -- Last burst might be smaller
                                expect_burst_write_aligned(net, AXI_SLAVE_C, expectedAddress_v, randUnsigned_v, 1, FIFO_DEPTH_C - to_integer(dataHandled_v));
                                expectedAddress_v := expectedAddress_v + to_unsigned((FIFO_DEPTH_C - to_integer(dataHandled_v)) * AXI_BYTE_WIDTH_C, AXIL_DATA_WIDTH_C);
                                dataHandled_v     := dataHandled_v + to_unsigned(FIFO_DEPTH_C - to_integer(dataHandled_v), AXI_DATA_WIDTH_C);
                                randUnsigned_v    := randUnsigned_v + to_unsigned(FIFO_DEPTH_C - to_integer(dataHandled_v), AXIL_DATA_WIDTH_C);
                            else
                                expect_burst_write_aligned(net, AXI_SLAVE_C, expectedAddress_v, randUnsigned_v, 1, MAX_BURST_LEN_C);
                                expectedAddress_v := expectedAddress_v + to_unsigned(MAX_BURST_LEN_C * AXI_BYTE_WIDTH_C, AXIL_DATA_WIDTH_C);
                                dataHandled_v     := dataHandled_v + to_unsigned(MAX_BURST_LEN_C, AXI_DATA_WIDTH_C);
                                randUnsigned_v    := randUnsigned_v + to_unsigned(MAX_BURST_LEN_C, AXIL_DATA_WIDTH_C);
                            end if;

                        end if;
                        wait_until_idle(net, as_sync(AXI_SLAVE_C));
                    end loop;

                    -- Check new head
                    regsStream_v.csr_fifo_to_pc_4.csr_head := std_logic_vector(expectedAddress_v);
                    expect_single_read(CSR_FIFO_TO_PC_4);

                    -- Check error status (should be 0)
                    regsStream_v.csr_fifo_to_pc_3.csr_error_axi     := '0';
                    regsStream_v.csr_fifo_to_pc_3.csr_error_memfull := '0';
                    expect_single_read(CSR_FIFO_TO_PC_3);

                    -- Increment tail to free up space
                    regsStream_v.csr_fifo_to_pc_5.csr_tail := std_logic_vector(expectedAddress_v);
                    push_single_write(CSR_FIFO_TO_PC_5);
                    wait_until_idle(net, as_sync(AXIL_MASTER_C));
                end if;

            elsif run("test_data_read_single") then
                -- Check if the stream is enabled
                if ENABLE_FROM_PC_STREAM_G = true then -- @suppress "Redundant boolean equality check with true"
                    -- Generate memory adresses
                    memFromPCLow_v  := to_unsigned(10 * AXI_BYTE_WIDTH_C, AXIL_DATA_WIDTH_C);
                    memFromPCHigh_v := to_unsigned(20 * AXI_BYTE_WIDTH_C, AXIL_DATA_WIDTH_C);
                    memToPCLow_v    := to_unsigned(30 * AXI_BYTE_WIDTH_C, AXIL_DATA_WIDTH_C);
                    memToPCHigh_v   := to_unsigned(40 * AXI_BYTE_WIDTH_C, AXIL_DATA_WIDTH_C);

                    -- Setup high and low memory addresses
                    regsStream_v.csr_fifo_from_pc_1.csr_low  := std_logic_vector(memFromPCLow_v);
                    push_single_write(CSR_FIFO_FROM_PC_1);
                    regsStream_v.csr_fifo_from_pc_2.csr_high := std_logic_vector(memFromPCHigh_v);
                    push_single_write(CSR_FIFO_FROM_PC_2);
                    regsStream_v.csr_fifo_from_pc_4.csr_head := std_logic_vector(memFromPCLow_v);
                    push_single_write(CSR_FIFO_FROM_PC_4);
                    regsStream_v.csr_fifo_to_pc_1.csr_low    := std_logic_vector(memToPCLow_v);
                    push_single_write(CSR_FIFO_TO_PC_1);
                    regsStream_v.csr_fifo_to_pc_2.csr_high   := std_logic_vector(memToPCHigh_v);
                    push_single_write(CSR_FIFO_TO_PC_2);
                    regsStream_v.csr_fifo_to_pc_5.csr_tail   := std_logic_vector(memToPCLow_v);
                    push_single_write(CSR_FIFO_TO_PC_5);

                    -- Reset
                    regsStream_v.csr_reset.csr_enablehardreset := '1';
                    regsStream_v.csr_reset.csr_reset           := '0';
                    push_single_write(CSR_RESET);
                    regsStream_v.csr_reset.csr_enablehardreset := '0';
                    regsStream_v.csr_reset.csr_reset           := '1';
                    push_single_write(CSR_RESET);
                    wait_until_idle(net, as_sync(AXIL_MASTER_C));

                    -- Verify head and tail pointers are reset
                    regsStream_v.csr_fifo_from_pc_4.csr_head := std_logic_vector(memFromPCLow_v);
                    expect_single_read(CSR_FIFO_FROM_PC_4);
                    regsStream_v.csr_fifo_from_pc_5.csr_tail := std_logic_vector(memFromPCLow_v);
                    expect_single_read(CSR_FIFO_FROM_PC_5);
                    regsStream_v.csr_fifo_to_pc_4.csr_head   := std_logic_vector(memToPCLow_v);
                    expect_single_read(CSR_FIFO_TO_PC_4);
                    regsStream_v.csr_fifo_to_pc_5.csr_tail   := std_logic_vector(memToPCLow_v);
                    expect_single_read(CSR_FIFO_TO_PC_5);
                    wait_until_idle(net, as_sync(AXIL_MASTER_C));

                    -- Verify that the stream is not valid
                    check_equal(axisFromPCTvalid, '0', "axisFromPCTvalid should be 0 before halt condition is cleared.");

                    -- Remove halt condition
                    regsStream_v.csr_reset.csr_halt := '0';
                    push_single_write(CSR_RESET);
                    wait_until_idle(net, as_sync(AXIL_MASTER_C));
                    wait until rising_edge(Clk);

                    -- Loop through the whole memory space + 1 to test wrap-around
                    expectedAddress_v := memFromPCLow_v;
                    for i in 0 to to_integer((memFromPCHigh_v - memFromPCLow_v)) / AXI_BYTE_WIDTH_C + 2 loop
                        info("Iteration " & integer'image(i));

                        -- Increment expected address
                        expectedAddressOld_v := expectedAddress_v;
                        expectedAddress_v    := expectedAddress_v + to_unsigned(AXI_BYTE_WIDTH_C, AXIL_DATA_WIDTH_C);
                        if expectedAddress_v > memFromPCHigh_v then
                            expectedAddress_v := memFromPCLow_v;
                        end if;

                        -- Write a single value over the AXI
                        randUnsigned_v                           := rand_unsigned(AXIL_DATA_WIDTH_C);
                        regsStream_v.csr_fifo_from_pc_4.csr_head := std_logic_vector(expectedAddress_v);
                        push_single_write(CSR_FIFO_FROM_PC_4); -- Inrement head
                        wait_until_idle(net, as_sync(AXIL_MASTER_C));
                        push_burst_read_aligned(net, AXI_SLAVE_C, expectedAddressOld_v, randUnsigned_v, 1, 1);
                        wait_until_idle(net, as_sync(AXI_SLAVE_C));
                        wait until rising_edge(Clk);

                        -- Check FIFO levels
                        check_equal(RdFIFOLevelxDO, to_unsigned(1, AXIL_DATA_WIDTH_C), "RdFIFOLevelxDO after 1 write to AXI Master");

                        -- Read back the value from the memory interface
                        expectRdData(net, randUnsigned_v);
                        wait_until_idle(net, as_sync(AXIS_SLAVE_C));
                        wait until rising_edge(Clk);
                        wait until rising_edge(Clk);

                        -- Check FIFO levels
                        check_equal(RdFIFOLevelxDO, to_unsigned(0, AXIL_DATA_WIDTH_C), "RdFIFOLevelxDO after 1 read from AXI Stream");

                        -- Check new tail
                        regsStream_v.csr_fifo_from_pc_5.csr_tail := std_logic_vector(expectedAddress_v);
                        expect_single_read(CSR_FIFO_FROM_PC_5);

                        -- Check error status (should be 0)
                        regsStream_v.csr_fifo_to_pc_3.csr_error_axi     := '0';
                        regsStream_v.csr_fifo_to_pc_3.csr_error_memfull := '0';
                        expect_single_read(CSR_FIFO_TO_PC_3);

                        -- Wait until all transactions are done
                        wait_until_idle(net, as_sync(AXIL_MASTER_C));
                        wait_until_idle(net, as_sync(AXIS_MASTER_C));
                        wait_until_idle(net, as_sync(AXI_SLAVE_C));
                    end loop;
                end if;

            elsif run("test_data_read_fifo") then
                -- Check if the stream is enabled
                if ENABLE_FROM_PC_STREAM_G = true then -- @suppress "Redundant boolean equality check with true"
                    -- Generate memory addresses (read test uses FROM_PC setup)
                    memFromPCLow_v  := to_unsigned(0 * AXI_BYTE_WIDTH_C, AXIL_DATA_WIDTH_C);
                    memFromPCHigh_v := memFromPCLow_v + to_unsigned((3 * FIFO_DEPTH_C) / 2 * AXI_BYTE_WIDTH_C, AXIL_DATA_WIDTH_C);
                    memToPCLow_v    := memFromPCHigh_v + to_unsigned(AXI_BYTE_WIDTH_C, AXIL_DATA_WIDTH_C);
                    memToPCHigh_v   := memToPCLow_v + to_unsigned((3 * FIFO_DEPTH_C) / 2 * AXI_BYTE_WIDTH_C, AXIL_DATA_WIDTH_C);

                    -- Setup high and low memory addresses  
                    regsStream_v.csr_fifo_from_pc_1.csr_low  := std_logic_vector(memFromPCLow_v);
                    push_single_write(CSR_FIFO_FROM_PC_1);
                    regsStream_v.csr_fifo_from_pc_2.csr_high := std_logic_vector(memFromPCHigh_v);
                    push_single_write(CSR_FIFO_FROM_PC_2);
                    regsStream_v.csr_fifo_from_pc_5.csr_tail := std_logic_vector(memFromPCLow_v);
                    push_single_write(CSR_FIFO_FROM_PC_5);
                    regsStream_v.csr_fifo_to_pc_1.csr_low    := std_logic_vector(memToPCLow_v);
                    push_single_write(CSR_FIFO_TO_PC_1);
                    regsStream_v.csr_fifo_to_pc_2.csr_high   := std_logic_vector(memToPCHigh_v);
                    push_single_write(CSR_FIFO_TO_PC_2);
                    regsStream_v.csr_fifo_to_pc_4.csr_head   := std_logic_vector(memToPCLow_v);
                    push_single_write(CSR_FIFO_TO_PC_4);

                    -- Reset
                    regsStream_v.csr_reset.csr_enablehardreset := '1';
                    regsStream_v.csr_reset.csr_reset           := '0';
                    push_single_write(CSR_RESET);
                    regsStream_v.csr_reset.csr_enablehardreset := '0';
                    regsStream_v.csr_reset.csr_reset           := '1';
                    push_single_write(CSR_RESET);
                    wait_until_idle(net, as_sync(AXIL_MASTER_C));

                    -- Verify head and tail pointers are reset
                    regsStream_v.csr_fifo_from_pc_4.csr_head := std_logic_vector(memFromPCLow_v);
                    expect_single_read(CSR_FIFO_FROM_PC_4);
                    regsStream_v.csr_fifo_from_pc_5.csr_tail := std_logic_vector(memFromPCLow_v);
                    expect_single_read(CSR_FIFO_FROM_PC_5);

                    -- Verify that the stream is not ready
                    check_equal(axisToPCTvalid, '0', "axisToPCTvalid should be 0 before halt condition is cleared.");

                    -- Remove halt condition and verify stream is ready
                    regsStream_v.csr_reset.csr_halt := '0';
                    push_single_write(CSR_RESET);
                    wait_until_idle(net, as_sync(AXIL_MASTER_C));
                    wait until rising_edge(Clk);

                    -- Write data to memory using burst transfers similar to test_data_write_fifo
                    info("Write full FIFO burst of " & integer'image(FIFO_DEPTH_C) & " values using bursts");
                    randUnsigned_v       := rand_unsigned(AXIL_DATA_WIDTH_C);
                    expectedAddressOld_v := randUnsigned_v; -- Store original start value for later use
                    expectedAddress_v    := memFromPCLow_v;

                    -- First write a single value
                    regsStream_v.csr_fifo_from_pc_4.csr_head := std_logic_vector(expectedAddress_v + to_unsigned(AXI_BYTE_WIDTH_C, AXIL_DATA_WIDTH_C));
                    push_single_write(CSR_FIFO_FROM_PC_4); -- Increment head
                    wait_until_idle(net, as_sync(AXIL_MASTER_C));
                    push_burst_read_aligned(net, AXI_SLAVE_C, expectedAddress_v, randUnsigned_v, 1, 1);
                    wait_until_idle(net, as_sync(AXI_SLAVE_C));
                    expectedAddress_v                        := expectedAddress_v + to_unsigned(AXI_BYTE_WIDTH_C, AXIL_DATA_WIDTH_C);
                    randUnsigned_v                           := randUnsigned_v + to_unsigned(1, AXIL_DATA_WIDTH_C);

                    -- Write remaining data using burst transfers
                    for i in 0 to (FIFO_DEPTH_C / MAX_BURST_LEN_C) - 1 loop
                        info("Burst iteration " & integer'image(i));
                        if i = (FIFO_DEPTH_C / MAX_BURST_LEN_C) - 1 then
                            -- Last burst might be smaller
                            regsStream_v.csr_fifo_from_pc_4.csr_head := std_logic_vector(expectedAddress_v + to_unsigned((MAX_BURST_LEN_C - 1) * AXI_BYTE_WIDTH_C, AXIL_DATA_WIDTH_C));
                            push_single_write(CSR_FIFO_FROM_PC_4);
                            wait_until_idle(net, as_sync(AXIL_MASTER_C));
                            push_burst_read_aligned(net, AXI_SLAVE_C, expectedAddress_v, randUnsigned_v, 1, MAX_BURST_LEN_C - 1);
                            expectedAddress_v                        := expectedAddress_v + to_unsigned((MAX_BURST_LEN_C - 1) * AXI_BYTE_WIDTH_C, AXIL_DATA_WIDTH_C);
                        else
                            regsStream_v.csr_fifo_from_pc_4.csr_head := std_logic_vector(expectedAddress_v + to_unsigned(MAX_BURST_LEN_C * AXI_BYTE_WIDTH_C, AXIL_DATA_WIDTH_C));
                            push_single_write(CSR_FIFO_FROM_PC_4);
                            wait_until_idle(net, as_sync(AXIL_MASTER_C));
                            push_burst_read_aligned(net, AXI_SLAVE_C, expectedAddress_v, randUnsigned_v, 1, MAX_BURST_LEN_C);
                            expectedAddress_v                        := expectedAddress_v + to_unsigned(MAX_BURST_LEN_C * AXI_BYTE_WIDTH_C, AXIL_DATA_WIDTH_C);
                        end if;
                        wait_until_idle(net, as_sync(AXI_SLAVE_C));

                        -- Increment expected values                    
                        randUnsigned_v := randUnsigned_v + to_unsigned(MAX_BURST_LEN_C, AXIL_DATA_WIDTH_C);
                    end loop;

                    -- Check FIFO level after all writes
                    wait until rising_edge(Clk);
                    check_equal(RdFIFOLevelxDO, to_unsigned(FIFO_DEPTH_C, AXIL_DATA_WIDTH_C), "RdFIFOLevelxDO after all burst writes to AXI Master");

                    info("Reading all " & integer'image(FIFO_DEPTH_C) & " values from AXI Stream (using expectRdData with increment)");

                    -- Read back all values from the AXI Stream interface using expectRdData with automatic increment
                    -- (Uses the original random start value and increment of 1 for FIFO_DEPTH_C beats)
                    expectRdData(net, expectedAddressOld_v, 1, FIFO_DEPTH_C); -- Use stored original start value
                    wait_until_idle(net, as_sync(AXIS_SLAVE_C));
                    wait until rising_edge(Clk);
                    wait until rising_edge(Clk);

                    -- Check FIFO level after reading all values
                    check_equal(RdFIFOLevelxDO, to_unsigned(0, AXIL_DATA_WIDTH_C), "RdFIFOLevelxDO after reading all values from AXI Stream");

                    -- Check final tail
                    regsStream_v.csr_fifo_from_pc_5.csr_tail := std_logic_vector(expectedAddress_v);
                    expect_single_read(CSR_FIFO_FROM_PC_5);

                    -- Check error status (should be 0)
                    regsStream_v.csr_fifo_from_pc_3.csr_error_axi     := '0';
                    regsStream_v.csr_fifo_from_pc_3.csr_error_memfull := '0';
                    expect_single_read(CSR_FIFO_FROM_PC_3);

                    -- Write a second full FIFO burst to test wrap-around behavior
                    info("Write second full FIFO burst of " & integer'image(FIFO_DEPTH_C) & " values using bursts (testing wrap-around)");
                    randUnsigned_v       := rand_unsigned(AXIL_DATA_WIDTH_C);
                    expectedAddressOld_v := randUnsigned_v; -- Store original start value for later use

                    -- Write data continuing from current expectedAddress_v (which should cause wrap-around)
                    dataHandled_v := to_unsigned(0, AXI_DATA_WIDTH_C);

                    -- Write values using burst transfers, handling wrap-around
                    while dataHandled_v < to_unsigned(FIFO_DEPTH_C, AXI_DATA_WIDTH_C) loop
                        info("Second burst - Data handled so far: " & integer'image(to_integer(dataHandled_v)));

                        -- Calculate length of next burst considering memory boundaries
                        if expectedAddress_v + to_unsigned(MAX_BURST_LEN_C * AXI_BYTE_WIDTH_C, AXIL_DATA_WIDTH_C) > memFromPCHigh_v then
                            -- Burst would exceed memory boundary, split it
                            regsStream_v.csr_fifo_from_pc_4.csr_head := std_logic_vector(expectedAddress_v + (memFromPCHigh_v - expectedAddress_v + AXI_BYTE_WIDTH_C));
                            push_single_write(CSR_FIFO_FROM_PC_4);
                            wait_until_idle(net, as_sync(AXIL_MASTER_C));
                            push_burst_read_aligned(net, AXI_SLAVE_C, expectedAddress_v, randUnsigned_v, 1, to_integer((memFromPCHigh_v - expectedAddress_v) / to_unsigned(AXI_BYTE_WIDTH_C, AXIL_DATA_WIDTH_C)) + 1);
                            wait_until_idle(net, as_sync(AXI_SLAVE_C));

                            -- Update counters
                            dataHandled_v     := dataHandled_v + (memFromPCHigh_v - expectedAddress_v) / to_unsigned(AXI_BYTE_WIDTH_C, AXI_DATA_WIDTH_C) + 1;
                            randUnsigned_v    := randUnsigned_v + (memFromPCHigh_v - expectedAddress_v) / to_unsigned(AXI_BYTE_WIDTH_C, AXIL_DATA_WIDTH_C) + 1;
                            expectedAddress_v := memFromPCLow_v; -- Wrap around to start
                        else
                            -- Normal burst within memory boundaries
                            if dataHandled_v + to_unsigned(MAX_BURST_LEN_C, AXI_DATA_WIDTH_C) > to_unsigned(FIFO_DEPTH_C, AXI_DATA_WIDTH_C) then
                                -- Last burst might be smaller
                                regsStream_v.csr_fifo_from_pc_4.csr_head := std_logic_vector(resize(expectedAddress_v + (to_unsigned(FIFO_DEPTH_C, AXI_DATA_WIDTH_C) - dataHandled_v) * to_unsigned(AXI_BYTE_WIDTH_C, AXIL_DATA_WIDTH_C), AXIL_DATA_WIDTH_C));
                                push_single_write(CSR_FIFO_FROM_PC_4);
                                wait_until_idle(net, as_sync(AXIL_MASTER_C));
                                push_burst_read_aligned(net, AXI_SLAVE_C, expectedAddress_v, randUnsigned_v, 1, to_integer(to_unsigned(FIFO_DEPTH_C, AXI_DATA_WIDTH_C) - dataHandled_v));
                                wait_until_idle(net, as_sync(AXI_SLAVE_C));

                                -- Update counters  
                                dataHandled_v     := to_unsigned(FIFO_DEPTH_C, AXI_DATA_WIDTH_C);
                                randUnsigned_v    := randUnsigned_v + (to_unsigned(FIFO_DEPTH_C, AXI_DATA_WIDTH_C) - dataHandled_v);
                                expectedAddress_v := resize(expectedAddress_v + (to_unsigned(FIFO_DEPTH_C, AXI_DATA_WIDTH_C) - dataHandled_v) * to_unsigned(AXI_BYTE_WIDTH_C, AXIL_DATA_WIDTH_C), AXIL_DATA_WIDTH_C);
                            else
                                regsStream_v.csr_fifo_from_pc_4.csr_head := std_logic_vector(expectedAddress_v + to_unsigned(MAX_BURST_LEN_C * AXI_BYTE_WIDTH_C, AXIL_DATA_WIDTH_C));
                                push_single_write(CSR_FIFO_FROM_PC_4);
                                wait_until_idle(net, as_sync(AXIL_MASTER_C));
                                push_burst_read_aligned(net, AXI_SLAVE_C, expectedAddress_v, randUnsigned_v, 1, MAX_BURST_LEN_C);
                                wait_until_idle(net, as_sync(AXI_SLAVE_C));

                                -- Update counters
                                dataHandled_v     := dataHandled_v + to_unsigned(MAX_BURST_LEN_C, AXI_DATA_WIDTH_C);
                                randUnsigned_v    := randUnsigned_v + to_unsigned(MAX_BURST_LEN_C, AXIL_DATA_WIDTH_C);
                                expectedAddress_v := expectedAddress_v + to_unsigned(MAX_BURST_LEN_C * AXI_BYTE_WIDTH_C, AXIL_DATA_WIDTH_C);
                            end if;
                        end if;
                    end loop;

                    -- Check FIFO level after all second burst writes
                    wait until rising_edge(Clk);
                    check_equal(RdFIFOLevelxDO, to_unsigned(FIFO_DEPTH_C, AXIL_DATA_WIDTH_C), "RdFIFOLevelxDO after second burst writes with wrap-around");

                    info("Reading all " & integer'image(FIFO_DEPTH_C) & " values from second burst (testing wrap-around)");

                    -- Read back all values from the second burst using expectRdData with automatic increment
                    expectRdData(net, expectedAddressOld_v, 1, FIFO_DEPTH_C); -- Use stored original start value
                    wait_until_idle(net, as_sync(AXIS_SLAVE_C));
                    wait until rising_edge(Clk);
                    wait until rising_edge(Clk);

                    -- Check FIFO level after reading all second burst values
                    check_equal(RdFIFOLevelxDO, to_unsigned(0, AXIL_DATA_WIDTH_C), "RdFIFOLevelxDO after reading all second burst values");

                    -- Check final tail after wrap-around test (should be from second burst memory area)
                    -- Note: expectedAddress_v tracks the memory location, not necessarily the tail register
                    info("Final expected address after wrap-around: " & to_hstring(expectedAddress_v));

                    -- Check error status (should still be 0)
                    regsStream_v.csr_fifo_from_pc_3.csr_error_axi     := '0';
                    regsStream_v.csr_fifo_from_pc_3.csr_error_memfull := '0';
                    expect_single_read(CSR_FIFO_FROM_PC_3);

                    -- Wait until all transactions are done
                    wait_until_idle(net, as_sync(AXIL_MASTER_C));
                    wait_until_idle(net, as_sync(AXIS_SLAVE_C));
                    wait_until_idle(net, as_sync(AXI_SLAVE_C));
                end if;

            elsif run("test_status_control_signals") then
                info("Testing Status and Control Signals via STATUS_CONTROL_TO_HW Register");

                -- Test 1: Test initial state of status and control signals
                info("Test 1: Checking initial state");
                check_equal(SnCHostConnectedxDO, '0', "SnCHostConnectedxDO should be '0' initially");
                check_equal(SnCSoftwareResetxRO, '0', "SnCSoftwareResetxRO should be '0' initially");

                -- Read the STATUS_CONTROL_TO_HW register and verify it reads 0x00000000 initially
                regsStream_v.csr_status_control_to_hw.csr_hostconnected := '0';
                regsStream_v.csr_status_control_to_hw.csr_softwarereset := '0';
                expect_single_read(CSR_STATUS_CONTROL_TO_HW);
                wait_until_idle(net, as_sync(AXIL_MASTER_C));

                -- Test 2: Set HostConnected bit (bit 0) and verify signal
                info("Test 2: Setting HostConnected bit");
                regsStream_v.csr_status_control_to_hw.csr_hostconnected := '1';
                regsStream_v.csr_status_control_to_hw.csr_softwarereset := '0';
                push_single_write(CSR_STATUS_CONTROL_TO_HW); -- Set bit 0
                wait_until_idle(net, as_sync(AXIL_MASTER_C));
                wait until rising_edge(Clk); -- Wait for register update

                check_equal(SnCHostConnectedxDO, '1', "SnCHostConnectedxDO should be '1' after setting bit 0");
                check_equal(SnCSoftwareResetxRO, '0', "SnCSoftwareResetxRO should still be '0'");

                -- Read back the register to verify the bit is set
                regsStream_v.csr_status_control_to_hw.csr_hostconnected := '1';
                regsStream_v.csr_status_control_to_hw.csr_softwarereset := '0';
                expect_single_read(CSR_STATUS_CONTROL_TO_HW);
                wait_until_idle(net, as_sync(AXIL_MASTER_C));

                -- Test 3: Test SoftwareReset pulse behavior (only high for one clock cycle)
                info("Test 3: Testing SoftwareReset pulse behavior");

                -- Check that SoftwareReset is initially low
                check_equal(SnCSoftwareResetxRO, '0', "SnCSoftwareResetxRO should be '0' before write");

                -- Write to trigger SoftwareReset (bit 1) while keeping HostConnected (bit 0)
                regsStream_v.csr_status_control_to_hw.csr_hostconnected := '1';
                regsStream_v.csr_status_control_to_hw.csr_softwarereset := '1';
                push_single_write(CSR_STATUS_CONTROL_TO_HW); -- Set bits 0 and 1
                wait_until_idle(net, as_sync(AXIL_MASTER_C));
                if SnCSoftwareResetxRO = '0' then
                    wait until rising_edge(Clk);
                end if;

                -- On the first rising edge after write, SoftwareReset should be high for exactly one cycle
                check_equal(SnCHostConnectedxDO, '1', "SnCHostConnectedxDO should be '1'");
                check_equal(SnCSoftwareResetxRO, '1', "SnCSoftwareResetxRO should be '1' for exactly one clock cycle");

                -- On the next rising edge, SoftwareReset should automatically go low (pulse behavior)
                wait until rising_edge(Clk);
                check_equal(SnCHostConnectedxDO, '1', "SnCHostConnectedxDO should remain '1'");
                check_equal(SnCSoftwareResetxRO, '0', "SnCSoftwareResetxRO should be '0' after one clock cycle (pulse behavior)");

                -- Wait a few more cycles to ensure it stays low
                for i in 1 to 5 loop
                    wait until rising_edge(Clk);
                    check_equal(SnCSoftwareResetxRO, '0', "SnCSoftwareResetxRO should remain '0' after pulse");
                end loop;

                -- Test 4: Test another SoftwareReset pulse 
                info("Test 4: Testing second SoftwareReset pulse");

                -- Write only the SoftwareReset bit (clear HostConnected) 
                regsStream_v.csr_status_control_to_hw.csr_hostconnected := '0';
                regsStream_v.csr_status_control_to_hw.csr_softwarereset := '1';
                push_single_write(CSR_STATUS_CONTROL_TO_HW); -- Set only bit 1
                wait_until_idle(net, as_sync(AXIL_MASTER_C));
                if SnCSoftwareResetxRO = '0' then
                    wait until rising_edge(Clk);
                end if;

                -- Check pulse behavior again
                check_equal(SnCHostConnectedxDO, '0', "SnCHostConnectedxDO should be '0' after clearing bit 0");
                check_equal(SnCSoftwareResetxRO, '1', "SnCSoftwareResetxRO should be '1' for exactly one clock cycle (second pulse)");

                wait until rising_edge(Clk);
                check_equal(SnCSoftwareResetxRO, '0', "SnCSoftwareResetxRO should be '0' after second pulse");

                -- Test 5: Test multiple consecutive writes to verify pulse behavior
                info("Test 5: Testing multiple consecutive SoftwareReset pulses");

                for pulse_num in 1 to 3 loop
                    info("  Pulse " & integer'image(pulse_num));

                    -- Ensure signal is low before write
                    check_equal(SnCSoftwareResetxRO, '0', "SnCSoftwareResetxRO should be '0' before pulse " & integer'image(pulse_num));

                    -- Trigger another pulse
                    regsStream_v.csr_status_control_to_hw.csr_hostconnected := '0';
                    regsStream_v.csr_status_control_to_hw.csr_softwarereset := '1';
                    push_single_write(CSR_STATUS_CONTROL_TO_HW); -- Set bit 1
                    wait_until_idle(net, as_sync(AXIL_MASTER_C));
                    if SnCSoftwareResetxRO = '0' then
                        wait until rising_edge(Clk);
                    end if;

                    -- Check pulse
                    check_equal(SnCSoftwareResetxRO, '1', "SnCSoftwareResetxRO should be high during pulse " & integer'image(pulse_num));

                    wait until rising_edge(Clk);
                    check_equal(SnCSoftwareResetxRO, '0', "SnCSoftwareResetxRO should be low after pulse " & integer'image(pulse_num));

                    -- Add some delay between pulses
                    for i in 1 to 2 loop
                        wait until rising_edge(Clk);
                    end loop;
                end loop;

                -- Test 6: Verify HostConnected remains stable during SoftwareReset pulses
                info("Test 6: Testing HostConnected stability during SoftwareReset pulses");

                -- Set HostConnected to '1'
                regsStream_v.csr_status_control_to_hw.csr_hostconnected := '1';
                regsStream_v.csr_status_control_to_hw.csr_softwarereset := '0';
                push_single_write(CSR_STATUS_CONTROL_TO_HW); -- Set bit 0
                wait_until_idle(net, as_sync(AXIL_MASTER_C));
                wait until rising_edge(Clk);
                check_equal(SnCHostConnectedxDO, '1', "SnCHostConnectedxDO should be '1'");

                -- Trigger SoftwareReset while keeping HostConnected
                regsStream_v.csr_status_control_to_hw.csr_hostconnected := '1';
                regsStream_v.csr_status_control_to_hw.csr_softwarereset := '1';
                push_single_write(CSR_STATUS_CONTROL_TO_HW); -- Set bits 0 and 1
                wait_until_idle(net, as_sync(AXIL_MASTER_C));
                if SnCSoftwareResetxRO = '0' then
                    wait until rising_edge(Clk);
                end if;   

                -- During and after the pulse, HostConnected should remain stable
                check_equal(SnCHostConnectedxDO, '1', "SnCHostConnectedxDO should remain '1' during pulse");
                check_equal(SnCSoftwareResetxRO, '1', "SnCSoftwareResetxRO should be '1' during pulse");

                wait until rising_edge(Clk);
                check_equal(SnCHostConnectedxDO, '1', "SnCHostConnectedxDO should remain '1' after pulse");
                check_equal(SnCSoftwareResetxRO, '0', "SnCSoftwareResetxRO should be '0' after pulse");

                -- Clear all bits
                regsStream_v.csr_status_control_to_hw.csr_hostconnected := '0';
                regsStream_v.csr_status_control_to_hw.csr_softwarereset := '0';
                push_single_write(CSR_STATUS_CONTROL_TO_HW);
                wait_until_idle(net, as_sync(AXIL_MASTER_C));
                wait until rising_edge(Clk);
                check_equal(SnCHostConnectedxDO, '0', "SnCHostConnectedxDO should be '0' after clearing all bits");
                check_equal(SnCSoftwareResetxRO, '0', "SnCSoftwareResetxRO should be '0' after clearing all bits");

                info("Status and Control signals test completed successfully");

            elsif run("test_coverage_enhancement_reset_expressions") then
                info("Testing reset expression coverage for XiBIF_Peri");

                -- Test the complex reset expressions specifically
                -- Target: (RstxRBI and (not EnablePeriHardReset)) or (RstxRBI and PerixRB)

                info("Testing EnablePeriHardReset = '0' path");
                -- First ensure EnablePeriHardReset = '0' (should be default)
                regsStream_v.csr_reset.csr_reset           := '0';
                regsStream_v.csr_reset.csr_resetdone       := '0';
                regsStream_v.csr_reset.csr_halt            := '0';
                regsStream_v.csr_reset.csr_enablehardreset := '0';
                push_single_write(CSR_RESET); -- EnableHardReset = 0, Reset = 0
                wait_until_idle(net, as_sync(AXIL_MASTER_C));
                wait for 10 * CLK_PERIOD_C;

                info("Testing EnablePeriHardReset = '1' path");
                -- Set EnablePeriHardReset = '1' to test other branch
                regsStream_v.csr_reset.csr_reset           := '0';
                regsStream_v.csr_reset.csr_resetdone       := '1';
                regsStream_v.csr_reset.csr_halt            := '0';
                regsStream_v.csr_reset.csr_enablehardreset := '0';
                push_single_write(CSR_RESET); -- EnableHardReset = 1, Reset = 0
                wait_until_idle(net, as_sync(AXIL_MASTER_C));
                wait for 10 * CLK_PERIOD_C;

                info("Testing PerixRB = '0' path (soft reset active)");
                -- Trigger soft reset by setting PerixRB = '0' 
                regsStream_v.csr_reset.csr_reset           := '0';
                regsStream_v.csr_reset.csr_resetdone       := '0';
                regsStream_v.csr_reset.csr_halt            := '0';
                regsStream_v.csr_reset.csr_enablehardreset := '0';
                push_single_write(CSR_RESET); -- EnableHardReset = 0, Reset = 0 (activates reset)
                wait_until_idle(net, as_sync(AXIL_MASTER_C));
                wait for 20 * CLK_PERIOD_C; -- Wait for reset to propagate

                info("Testing PerixRB = '1' path (soft reset inactive)");
                -- Release soft reset by setting PerixRB = '1'
                regsStream_v.csr_reset.csr_reset           := '1';
                regsStream_v.csr_reset.csr_resetdone       := '0';
                regsStream_v.csr_reset.csr_halt            := '0';
                regsStream_v.csr_reset.csr_enablehardreset := '0';
                push_single_write(CSR_RESET); -- EnableHardReset = 0, Reset = 1 (releases reset)
                wait_until_idle(net, as_sync(AXIL_MASTER_C));
                wait for 20 * CLK_PERIOD_C; -- Wait for reset release

                info("Testing PeriResetDone expression");
                -- Wait for PeriResetDone = PeriResetDoneRead and PeriResetDoneWrite
                wait for 50 * CLK_PERIOD_C; -- Give time for reset done signals to stabilize

            elsif run("test_coverage_enhancement_fifo_levels") then
                info("Testing FIFO level signal assignments and bit range expressions");

                -- Target: WrFIFOLevelxDO(WrFIFOLevel'range) and RdFIFOLevelxDO(RdFIFOLevel'range) 
                info("Testing FIFO level range expressions");

                -- Setup memory addresses first
                regsStream_v.csr_fifo_to_pc_1.csr_low    := std_logic_vector(to_unsigned(16#1000#, AXIL_DATA_WIDTH_C));
                push_single_write(CSR_FIFO_TO_PC_1);
                regsStream_v.csr_fifo_to_pc_2.csr_high   := std_logic_vector(to_unsigned(16#2000#, AXIL_DATA_WIDTH_C));
                push_single_write(CSR_FIFO_TO_PC_2);
                regsStream_v.csr_fifo_from_pc_1.csr_low  := std_logic_vector(to_unsigned(16#3000#, AXIL_DATA_WIDTH_C));
                push_single_write(CSR_FIFO_FROM_PC_1);
                regsStream_v.csr_fifo_from_pc_2.csr_high := std_logic_vector(to_unsigned(16#4000#, AXIL_DATA_WIDTH_C));
                push_single_write(CSR_FIFO_FROM_PC_2);
                wait_until_idle(net, as_sync(AXIL_MASTER_C));
                wait for 10 * CLK_PERIOD_C;

                -- Read FIFO level registers to exercise range expressions  
                regsStream_v.csr_fifo_to_pc_3.csr_error_axi       := '0';
                regsStream_v.csr_fifo_to_pc_3.csr_error_memfull   := '0';
                expect_single_read(CSR_FIFO_TO_PC_3); -- WrFIFOLevel
                regsStream_v.csr_fifo_from_pc_3.csr_error_axi     := '0';
                regsStream_v.csr_fifo_from_pc_3.csr_error_memfull := '0';
                expect_single_read(CSR_FIFO_FROM_PC_3); -- RdFIFOLevel
                wait_until_idle(net, as_sync(AXIL_MASTER_C));
                wait for 10 * CLK_PERIOD_C;

            elsif run("test_coverage_enhancement_axi_reset_expression") then
                info("Testing AXI master reset expression coverage");

                -- Target: "not"(RstxRBI) or PeriResetDone expression for AXI master reset
                info("Testing AXI master reset logic");

                -- Test with normal operation first (RstxRBI = '1', PeriResetDone will vary)
                regsStream_v.csr_version.csr_rev   := x"78"; -- @suppress "Constant width vector assigned to signal"
                regsStream_v.csr_version.csr_patch := x"56"; -- @suppress "Constant width vector assigned to signal"
                regsStream_v.csr_version.csr_min   := x"34"; -- @suppress "Constant width vector assigned to signal"
                regsStream_v.csr_version.csr_maj   := x"12"; -- @suppress "Constant width vector assigned to signal"
                push_single_write(CSR_VERSION);
                wait_until_idle(net, as_sync(AXIL_MASTER_C));
                wait for 5 * CLK_PERIOD_C;

                -- Trigger soft reset to test PeriResetDone part of expression
                regsStream_v.csr_reset.csr_reset           := '0';
                regsStream_v.csr_reset.csr_resetdone       := '0';
                regsStream_v.csr_reset.csr_halt            := '0';
                regsStream_v.csr_reset.csr_enablehardreset := '0';
                push_single_write(CSR_RESET); -- Activate soft reset
                wait_until_idle(net, as_sync(AXIL_MASTER_C));
                wait for 10 * CLK_PERIOD_C;

                -- Release soft reset
                regsStream_v.csr_reset.csr_reset           := '1';
                regsStream_v.csr_reset.csr_resetdone       := '0';
                regsStream_v.csr_reset.csr_halt            := '0';
                regsStream_v.csr_reset.csr_enablehardreset := '0';
                push_single_write(CSR_RESET); -- Release soft reset
                wait_until_idle(net, as_sync(AXIL_MASTER_C));
                wait for 20 * CLK_PERIOD_C; -- Wait for PeriResetDone to complete

            elsif run("test_coverage_enhancement_specific_expressions") then
                info("Testing specific boolean expressions from XiBIF_Peri");

                -- Test the exact boolean expressions: (RstxRBI and (not EnablePeriHardReset)) or (RstxRBI and PerixRB)
                -- First test: RstxRBI=1, EnablePeriHardReset=0, PerixRB=0 -> should give (1 and 1) or (1 and 0) = 1 or 0 = 1
                info("Test case 1: EnablePeriHardReset=0, PerixRB=0");
                regsStream_v.csr_reset.csr_reset           := '0';
                regsStream_v.csr_reset.csr_resetdone       := '0';
                regsStream_v.csr_reset.csr_halt            := '0';
                regsStream_v.csr_reset.csr_enablehardreset := '0';
                push_single_write(CSR_RESET); -- EnableHardReset=0, Reset=0
                wait_until_idle(net, as_sync(AXIL_MASTER_C));
                wait for 15 * CLK_PERIOD_C;

                -- Second test: RstxRBI=1, EnablePeriHardReset=1, PerixRB=0 -> should give (1 and 0) or (1 and 0) = 0 or 0 = 0
                info("Test case 2: EnablePeriHardReset=1, PerixRB=0");
                regsStream_v.csr_reset.csr_reset           := '0';
                regsStream_v.csr_reset.csr_resetdone       := '1';
                regsStream_v.csr_reset.csr_halt            := '0';
                regsStream_v.csr_reset.csr_enablehardreset := '0';
                push_single_write(CSR_RESET); -- EnableHardReset=1, Reset=0
                wait_until_idle(net, as_sync(AXIL_MASTER_C));
                wait for 15 * CLK_PERIOD_C;

                -- Third test: RstxRBI=1, EnablePeriHardReset=1, PerixRB=1 -> should give (1 and 0) or (1 and 1) = 0 or 1 = 1
                info("Test case 3: EnablePeriHardReset=1, PerixRB=1");
                regsStream_v.csr_reset.csr_reset           := '1';
                regsStream_v.csr_reset.csr_resetdone       := '1';
                regsStream_v.csr_reset.csr_halt            := '0';
                regsStream_v.csr_reset.csr_enablehardreset := '0';
                push_single_write(CSR_RESET); -- EnableHardReset=1, Reset=1
                wait_until_idle(net, as_sync(AXIL_MASTER_C));
                wait for 15 * CLK_PERIOD_C;

                -- Fourth test: RstxRBI=1, EnablePeriHardReset=0, PerixRB=1 -> should give (1 and 1) or (1 and 1) = 1 or 1 = 1
                info("Test case 4: EnablePeriHardReset=0, PerixRB=1");
                regsStream_v.csr_reset.csr_reset           := '1';
                regsStream_v.csr_reset.csr_resetdone       := '0';
                regsStream_v.csr_reset.csr_halt            := '0';
                regsStream_v.csr_reset.csr_enablehardreset := '0';
                push_single_write(CSR_RESET); -- EnableHardReset=0, Reset=1
                wait_until_idle(net, as_sync(AXIL_MASTER_C));
                wait for 15 * CLK_PERIOD_C;

            elsif run("test_coverage_enhancement_range_assignments") then
                info("Testing range assignment expressions");

                -- Target the range assignments: WrFIFOLevelxDO(WrFIFOLevel'range) and RdFIFOLevelxDO(RdFIFOLevel'range)
                info("Testing FIFO level range assignments");

                -- Setup some FIFO operations to change levels
                regsStream_v.csr_fifo_to_pc_1.csr_low  := std_logic_vector(to_unsigned(16#1000#, AXIL_DATA_WIDTH_C));
                push_single_write(CSR_FIFO_TO_PC_1);
                regsStream_v.csr_fifo_to_pc_2.csr_high := std_logic_vector(to_unsigned(16#2000#, AXIL_DATA_WIDTH_C));
                push_single_write(CSR_FIFO_TO_PC_2);
                wait_until_idle(net, as_sync(AXIL_MASTER_C));
                wait for 10 * CLK_PERIOD_C;

                -- Read FIFO levels multiple times to exercise range expressions
                regsStream_v.csr_fifo_to_pc_3.csr_error_axi       := '0';
                regsStream_v.csr_fifo_to_pc_3.csr_error_memfull   := '0';
                expect_single_read(CSR_FIFO_TO_PC_3);
                regsStream_v.csr_fifo_from_pc_3.csr_error_axi     := '0';
                regsStream_v.csr_fifo_from_pc_3.csr_error_memfull := '0';
                expect_single_read(CSR_FIFO_FROM_PC_3);
                wait_until_idle(net, as_sync(AXIL_MASTER_C));
                wait for 10 * CLK_PERIOD_C;

                -- Test with different FIFO configurations
                regsStream_v.csr_fifo_from_pc_1.csr_low  := std_logic_vector(to_unsigned(16#3000#, AXIL_DATA_WIDTH_C));
                push_single_write(CSR_FIFO_FROM_PC_1);
                regsStream_v.csr_fifo_from_pc_2.csr_high := std_logic_vector(to_unsigned(16#4000#, AXIL_DATA_WIDTH_C));
                push_single_write(CSR_FIFO_FROM_PC_2);
                wait_until_idle(net, as_sync(AXIL_MASTER_C));
                wait for 10 * CLK_PERIOD_C;

                regsStream_v.csr_fifo_to_pc_3.csr_error_axi     := '0';
                regsStream_v.csr_fifo_to_pc_3.csr_error_memfull := '0';

                expect_single_read(CSR_FIFO_TO_PC_3);
                regsStream_v.csr_fifo_from_pc_3.csr_error_axi     := '0';
                regsStream_v.csr_fifo_from_pc_3.csr_error_memfull := '0';
                expect_single_read(CSR_FIFO_FROM_PC_3);
                wait_until_idle(net, as_sync(AXIL_MASTER_C));
                wait for 10 * CLK_PERIOD_C;

            elsif run("test_coverage_enhancement_boolean_conditions") then
                info("Testing boolean AND expression: PeriResetDone <= PeriResetDoneRead and PeriResetDoneWrite");

                -- Test different combinations of PeriResetDoneRead and PeriResetDoneWrite
                -- This will test the "and" expression in different states

                info("Testing reset sequence to trigger PeriResetDone expression");

                -- Trigger reset state to exercise PeriResetDone logic
                regsStream_v.csr_reset.csr_reset           := '0';
                regsStream_v.csr_reset.csr_resetdone       := '0';
                regsStream_v.csr_reset.csr_halt            := '0';
                regsStream_v.csr_reset.csr_enablehardreset := '0';
                push_single_write(CSR_RESET); -- Activate soft reset
                wait_until_idle(net, as_sync(AXIL_MASTER_C));
                wait for 30 * CLK_PERIOD_C; -- Wait for reset to propagate and reset done signals to change

                -- Release reset to test the completion logic
                regsStream_v.csr_reset.csr_reset           := '1';
                regsStream_v.csr_reset.csr_resetdone       := '0';
                regsStream_v.csr_reset.csr_halt            := '0';
                regsStream_v.csr_reset.csr_enablehardreset := '0';
                push_single_write(CSR_RESET); -- Release soft reset
                wait_until_idle(net, as_sync(AXIL_MASTER_C));
                wait for 50 * CLK_PERIOD_C; -- Wait for both PeriResetDoneRead and PeriResetDoneWrite to complete

                -- Read some registers to ensure system is active and potentially change reset done states
                regsStream_v.csr_version.csr_rev   := x"38";
                regsStream_v.csr_version.csr_patch := x"15";
                regsStream_v.csr_version.csr_min   := x"37";
                regsStream_v.csr_version.csr_maj   := x"67";
                push_single_write(CSR_VERSION); -- Set version
                wait_until_idle(net, as_sync(AXIL_MASTER_C));
                wait for 10 * CLK_PERIOD_C;

                -- Test another reset cycle with different timing
                regsStream_v.csr_reset.csr_reset           := '0';
                regsStream_v.csr_reset.csr_resetdone       := '0';
                regsStream_v.csr_reset.csr_halt            := '0';
                regsStream_v.csr_reset.csr_enablehardreset := '0';
                push_single_write(CSR_RESET); -- Activate soft reset again
                wait_until_idle(net, as_sync(AXIL_MASTER_C));
                wait for 10 * CLK_PERIOD_C; -- Shorter wait time

                regsStream_v.csr_reset.csr_reset           := '1';
                regsStream_v.csr_reset.csr_resetdone       := '0';
                regsStream_v.csr_reset.csr_halt            := '0';
                regsStream_v.csr_reset.csr_enablehardreset := '0';

                push_single_write(CSR_RESET); -- Release soft reset quickly
                wait_until_idle(net, as_sync(AXIL_MASTER_C));
                wait for 30 * CLK_PERIOD_C; -- Wait for completion

            end if;
        end loop;

        test_runner_cleanup(runner);
    end process;

    -----------------------------------------------------------------------------------------------
    -- Timeout watchdog
    -----------------------------------------------------------------------------------------------
    test_runner_watchdog(runner, 1 ms);

end architecture;
