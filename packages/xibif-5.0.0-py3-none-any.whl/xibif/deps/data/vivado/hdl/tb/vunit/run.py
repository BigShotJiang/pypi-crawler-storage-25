"""VUnit test runner for XiBIF HDL testbenches."""

import subprocess
import time
import sys
import shutil
from loguru import logger

# For a Verilog project, change the next line to `from vunit.verilog import VUnit`
from vunit import VUnit

from xibif import XibifProject
from xibif.types.defaults import XibifDefaults
from xibif.types.utils import XibifPath


def post_run(results):
    """Post-run handler for saving simulation history and generating coverage reports."""
    print("------------------------------------------", flush=True)
    print("-------- Save simulation history ---------", flush=True)
    print("------------------------------------------", flush=True)
    if path_history.exists():
        shutil.rmtree(path_history)
    path_history.mkdir(parents=True, exist_ok=True)

    # Save the test history
    vu.export_items(["test_history"], str(path_history.as_posix()))

    print("------------------------------------------", flush=True)
    print("-------- Generate coverage report --------", flush=True)
    print("------------------------------------------", flush=True)
    path_coverage = XibifDefaults.SIMULATION_COVERAGE_FOLDER
    if path_coverage.exists():
        shutil.rmtree(path_coverage)
    path_coverage.mkdir(parents=True, exist_ok=True)

    coverage_txt_path = path_coverage.joinpath("coverage.txt")
    coverage_html_path = path_coverage.joinpath("coverage")
    coverage_html_path.mkdir(parents=True, exist_ok=True)

    if vu.get_simulator_name() == "ghdl":
        coverage_filename = path_coverage.joinpath("coverage_data")
        coverage_args = []

        if results._simulator_if._backend == "gcc":  # pylint: disable=protected-access
            coverage_report_html_cmd = f"gcovr -r {XibifDefaults.HDL_SRC_FOLDER} -a {path_coverage.joinpath('coverage_data')} --html-details {coverage_html_path.joinpath('index.html')}"
            coverage_report_txt_cmd = f"gcovr -r {XibifDefaults.HDL_SRC_FOLDER} -a {path_coverage.joinpath('coverage_data')} --txt {coverage_txt_path}"
        else:
            coverage_report_html_cmd = f"gcovr -r {XibifDefaults.HDL_SRC_FOLDER} -a {path_coverage.joinpath('coverage_data', 'gcovr.json')} --html-details {coverage_html_path.joinpath('index.html')}"
            coverage_report_txt_cmd = f"gcovr -r {XibifDefaults.HDL_SRC_FOLDER} -a {path_coverage.joinpath('coverage_data', 'gcovr.json')} --txt {coverage_txt_path}"

    elif vu.get_simulator_name() == "nvc":
        coverage_filename = path_coverage.joinpath("coverage_data")
        coverage_args = ["--merge-mode=union"]
        coverage_report_html_cmd = f"nvc --cover-report -o {coverage_html_path} {path_coverage.joinpath('coverage_data.ncdb')}"
        coverage_report_txt_cmd = None

    elif vu.get_simulator_name() == "modelsim":
        coverage_filename = path_coverage.joinpath("coverage_data.ucdb")
        coverage_args = ["-forceall", "-combinemax", "-mergedesigndiffs", "-silent"]

        names = [" -du=" + x.stem for x in hdlfiles]

        coverage_report_html_cmd = (
            f"vcover report -details {''.join(names)} -html -output {coverage_html_path} -dump -assert -directive -cvg -codeAll -annotate {path_coverage.joinpath('coverage_data.ucdb')}"
        )
        coverage_report_txt_cmd = f"vcover report{''.join(names)} -output {coverage_txt_path} -dump -assert -directive -cvg -codeAll {path_coverage.joinpath('coverage_data.ucdb')}"

    else:
        raise RuntimeError(f"Unsupported simulator: {vu.get_simulator_name()}")

    # Merge coverage data
    results.merge_coverage(file_name=coverage_filename.as_posix(), args=coverage_args)

    # Fix JSON file for gcovr if needed
    if vu.get_simulator_name() == "ghdl" and results._simulator_if._backend != "gcc":  # pylint: disable=protected-access
        coverage_json_path = path_coverage.joinpath("coverage_data", "gcovr.json")
        with open(coverage_json_path, "r") as f:
            coverage_data = f.read()
        # Normalize Windows path separators for valid JSON escaping.
        coverage_data = coverage_data.replace("\\", "/")
        # Force the gcovr format version expected by downstream tooling.
        coverage_data = coverage_data.replace('"gcovr/format_version": "0.6"', '"gcovr/format_version": "0.14"')
        with open(coverage_json_path, "w") as f:
            f.write(coverage_data)

    # Generate coverage report
    if coverage_report_html_cmd is not None:
        print(f"\t Command: {coverage_report_html_cmd}", flush=True)
        proc = subprocess.Popen(coverage_report_html_cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, universal_newlines=True)
        for line in proc.stdout:
            print(f"\t\t{line}", end="", flush=True)
        for line in proc.stderr:
            print(f"\t\t{line}", end="", flush=True)
        proc.wait()
        if proc.returncode != 0:
            raise RuntimeError("Error merging coverage!")

    if coverage_report_txt_cmd is not None:
        print(f"\t Command: {coverage_report_txt_cmd}", flush=True)
        proc = subprocess.Popen(coverage_report_txt_cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, universal_newlines=True)
        for line in proc.stdout:
            print(f"\t\t{line}", end="", flush=True)
        for line in proc.stderr:
            print(f"\t\t{line}", end="", flush=True)
        proc.wait()
        if proc.returncode != 0:
            raise RuntimeError("Error merging coverage!")

        if coverage_txt_path.exists():
            with open(coverage_txt_path, "r") as f:
                print(f.read(), flush=True)

    time.sleep(2.0)


# Setup logger
logger.remove()

# Open Xibif Project
project = XibifProject()
if __file__ != "<stdin>":
    project.path = XibifPath(__file__).parent.resolve()
else:
    project.path = XibifPath.cwd()

print(f"Loading xibif project from {project.path}")
project.load_config()
XibifPath.set_root(project.path.absolute().resolve())

pathVHDL = XibifDefaults.HDL_SRC_FOLDER
pathTB = XibifDefaults.HDL_TB_FOLDER
pathOpenLogic = XibifDefaults.OPENLOGIC_FOLDER

# Create VUnit instance by parsing command line arguments
# Check if additional arguments are provided
additional_args = ["-k", "--xunit-xml", XibifDefaults.SIMULATION_XML_FILE.as_posix(), "--xunit-xml-format", "bamboo", "-o", XibifDefaults.SIMULATION_VUNIT_OUTPUT_FOLDER.as_posix()]
argv = sys.argv[1:] + additional_args
vu = VUnit.from_argv(argv=argv)
vu.add_vhdl_builtins()
vu.add_com()
vu.add_verification_components()

# Import history if it exists
path_history = XibifDefaults.SIMULATION_HISTORY_FOLDER
if path_history.exists() and not any(arg.startswith("-g") for arg in argv):
    vu.import_items(str(path_history))

# A container for all libraries in the VUnit framework
libraries = {}

# Create libraries
libraries["worklib"] = vu.add_library("worklib")
libraries["olo"] = vu.add_library("olo")
libraries["unisim"] = vu.add_library("unisim")

# Add olo files
olo_files = list(pathOpenLogic.joinpath("src").glob("**/*.vhd"))
olo_files.extend(list(pathOpenLogic.joinpath("3rdParty", "en_cl_fix", "hdl").glob("*.vhd")))
olo_files.extend(list(pathOpenLogic.joinpath("test", "tb").glob("*.vhd")))
for designfile in olo_files:
    libraries["olo"].add_source_files(designfile.as_posix())

# Add dummy USR_ACCESSE2 for simulation
libraries["unisim"].add_source_files(pathTB.joinpath("tb_usr_access2_dummy.vhd").as_posix())

# Add design files
hdlfiles = list(pathVHDL.glob("**/*.vhd"))
hdlfiles.extend(list(pathVHDL.glob("**/*.vhdl")))
tbfiles = list(pathTB.glob("**/*.vhd"))
tbfiles.extend(list(pathTB.glob("**/*.vhdl")))
for designfile in hdlfiles:
    libraries["worklib"].add_source_files(designfile.as_posix())
for testfile in tbfiles:
    libraries["worklib"].add_source_files(testfile.as_posix())

print("------------------------------------------")
print("--------         HDL files        --------")
print("------------------------------------------")
print(hdlfiles)

print("------------------------------------------")
print("--------         TB files         --------")
print("------------------------------------------")
print(tbfiles)

print("------------------------------------------")
print("--------    Add specific tests    --------")
print("------------------------------------------")
print("Adding generic test benches for tb_peri")
tb = libraries["worklib"].test_bench("tb_peri")
tb.add_config(
    name="no_streams",
    generics={"ENABLE_TO_PC_STREAM_G": False, "ENABLE_From_PC_STREAM_G": False},
)
tb.add_config(
    name="to_pc_stream",
    generics={"ENABLE_TO_PC_STREAM_G": True, "ENABLE_FROM_PC_STREAM_G": False},
)
tb.add_config(
    name="from_pc_stream",
    generics={"ENABLE_TO_PC_STREAM_G": False, "ENABLE_FROM_PC_STREAM_G": True},
)
tb.add_config(
    name="all_streams",
    generics={"ENABLE_TO_PC_STREAM_G": True, "ENABLE_FROM_PC_STREAM_G": True},
)

print("------------------------------------------")
print("--------      Run Simulation      --------")
print("------------------------------------------")
# Enable coverage
vu.set_sim_option("nvc.elab_flags", ["--cover=statement,branch,toggle,expression,fsm-state,functional"])
vu.set_sim_option("ghdl.elab_flags", ["-frelaxed"])
vu.set_sim_option("enable_coverage", True)
vu.set_compile_option("nvc.a_flags", ["--relaxed"])
vu.set_compile_option("ghdl.a_flags", ["-frelaxed-rules", "-Wno-hide", "-Wno-shared"])
vu.set_compile_option("modelsim.vcom_flags", ["+cover"])
vu.set_compile_option("modelsim.vlog_flags", ["+cover"])
vu.set_compile_option("enable_coverage", True)

# Run vunit function
vu.main(post_run=post_run)
