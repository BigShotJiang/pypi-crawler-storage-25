-- ----------------------------------------------------------------------------------------------------
-- brief: FSM for write part of XiBIF
-- file: XiBIF_write.vhd
-- author: lukas.leuenberger
-- ----------------------------------------------------------------------------------------------------
-- Copyright(c) 2025 by OST, Switzerland
-- All rights reserved.
-- ----------------------------------------------------------------------------------------------------
-- File history:
-- Version, Date, Author, Remarks
-- ----------------------------------------------------------------------------------------------------
-- 0.1, 03.10.2025, lukas.leuenberger, First version
-- ----------------------------------------------------------------------------------------------------

library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

library olo;
use olo.olo_base_pkg_math.all;

entity Xibif_write is
    generic(
        FIFO_DEPTH_G     : positive := 1024;
        AXI_ADDR_WIDTH_G : positive := 32;
        AXI_DATA_WIDTH_G : positive := 32
    );
    port(
        -- Control Signals
        ClkxCI        : in  std_logic;
        RstxRBI       : in  std_logic;
        SoftReset     : in  std_logic;
        SoftResetDone : out std_logic;
        -- Comand signals to/from the olo_axi_master_simple
        CmdWr_Addr    : out std_logic_vector(AXI_ADDR_WIDTH_G - 1 downto 0);
        CmdWr_Size    : out std_logic_vector(log2ceil(FIFO_DEPTH_G + 1) - 1 downto 0);
        CmdWr_Valid   : out std_logic;
        CmdWr_Ready   : in  std_logic;
        Wr_Done       : in  std_logic;
        Wr_Error      : in  std_logic;
        Wr_FIFOLevel  : in  std_logic_vector(log2ceil(FIFO_DEPTH_G + 1) - 1 downto 0);
        -- Comand signals to/from the c-code over registers
        MemLow        : in  std_logic_vector(AXI_ADDR_WIDTH_G - 1 downto 0); -- Low or base adress of memory region
        MemHigh       : in  std_logic_vector(AXI_ADDR_WIDTH_G - 1 downto 0); -- High address of memory region
        Tail          : in  std_logic_vector(AXI_ADDR_WIDTH_G - 1 downto 0); -- Address of next readable word in memory, needed to check if FIFO full
        Head          : out std_logic_vector(AXI_ADDR_WIDTH_G - 1 downto 0); -- Address of next writable word in memory
        ErrorMemFull  : out std_logic;
        ErrorAXIWrite : out std_logic
    );
end entity Xibif_write;

architecture behavioral of Xibif_write is

    type fsmState_t is (RESET, IDLE, CALC_SEND_SIZE, ISSUE_SEND_CMD);
    type state_t is record
        state          : fsmState_t;
        head           : unsigned(AXI_ADDR_WIDTH_G - 1 downto 0);
        tailAheadSnap  : boolean;
        size           : unsigned(log2ceil(FIFO_DEPTH_G + 1) - 1 downto 0);
        valid          : std_logic;
        errorMemFull   : std_logic;
        errorAXIWrite  : std_logic;
        softResetDone  : std_logic;
        currSizeAhead  : unsigned(AXI_ADDR_WIDTH_G - 1 downto 0);
        currSizeBehind : unsigned(AXI_ADDR_WIDTH_G - 1 downto 0);
    end record state_t;

    constant INIT_STATE_C : state_t := (
        state          => RESET,
        head           => (others => '0'),
        tailAheadSnap  => false,
        size           => (others => '0'),
        valid          => '0',
        errorMemFull   => '0',
        errorAXIWrite  => '0',
        softResetDone  => '1',
        currSizeAhead  => (others => '0'),
        currSizeBehind => (others => '0')
    );

    constant WORD_LEN_C : unsigned(3 downto 0) := to_unsigned(AXI_DATA_WIDTH_G / 8, 4);

    signal p, n : state_t := INIT_STATE_C;
begin

    state_reg : process(ClkxCI)
    begin
        if rising_edge(ClkxCI) then
            if RstxRBI = '0' then
                p <= INIT_STATE_C;
            else
                p <= n;
            end if;
        end if;
    end process;

    next_logic : process(p, CmdWr_Ready, MemHigh, MemLow, Tail, Wr_Done, Wr_Error, Wr_FIFOLevel, SoftReset)
        variable currSize_v : unsigned(AXI_ADDR_WIDTH_G - 1 downto 0);
        variable currHead_v : unsigned(AXI_ADDR_WIDTH_G - 1 downto 0);
    begin
        -- Default assignments
        n <= p;

        -- Pre-calculated conditions to reduce timing paths
        n.tailAheadSnap  <= p.head < unsigned(Tail);
        n.currSizeAhead  <= minimum(resize((unsigned(Tail) - p.head - WORD_LEN_C) / WORD_LEN_C, AXI_ADDR_WIDTH_G), resize(unsigned(Wr_FIFOLevel), AXI_ADDR_WIDTH_G));
        n.currSizeBehind <= minimum(resize((unsigned(MemHigh) - p.head + WORD_LEN_C) / WORD_LEN_C, AXI_ADDR_WIDTH_G), resize(unsigned(Wr_FIFOLevel), AXI_ADDR_WIDTH_G));

        -- Outputs
        CmdWr_Addr    <= std_logic_vector(p.head);
        CmdWr_Size    <= std_logic_vector(p.size);
        CmdWr_Valid   <= p.valid;
        Head          <= std_logic_vector(p.head);
        ErrorMemFull  <= p.errorMemFull;
        ErrorAXIWrite <= p.errorAXIWrite;
        SoftResetDone <= p.softResetDone;

        case p.state is
            when RESET =>
                n               <= INIT_STATE_C;
                n.head          <= unsigned(MemLow); -- when reseted the first address that can be written to is the base address
                n.softResetDone <= '1';

                if SoftReset = '1' then
                    n.state         <= IDLE;
                    n.softResetDone <= '0';
                end if;

            when IDLE =>
                -- Perform soft reset if requested, otherwise check if we can send a command
                if SoftReset = '0' then
                    n.state <= RESET;
                else
                    if ((to_integer(unsigned(Wr_FIFOLevel)) > 0) and CmdWr_Ready = '1') then -- check if FIFO has data and AXI master is ready
                        -- Check where the tail is
                        if (((p.head = unsigned(MemLow)) and (unsigned(Tail) = unsigned(MemHigh))) or ((p.head + WORD_LEN_C) = unsigned(Tail))) then
                            -- The FIFO is full, cannot write more data
                            n.errorMemFull <= '1';
                        else
                            n.state <= CALC_SEND_SIZE;
                        end if;
                    end if;
                end if;

            when CALC_SEND_SIZE =>
                -- Calculate number of data to send from stable snapshots
                if p.tailAheadSnap then
                    -- Tail is in front - read until tail
                    currSize_v := p.currSizeAhead;
                else
                    -- Tail is behind - read until MemHigh
                    currSize_v := p.currSizeBehind;
                end if;

                -- The head might not be aligned to WORD_LEN_C, so we might end up with currSize_v = 0
                if currSize_v > 0 then
                    n.size  <= resize(currSize_v, log2ceil(FIFO_DEPTH_G + 1)); -- Store the calculated size
                    n.valid <= '1';

                    -- Switch the state
                    n.state <= ISSUE_SEND_CMD;
                else
                    n.state <= IDLE;
                end if;

            when ISSUE_SEND_CMD =>
                -- Reset valid after command has been sent
                n.valid <= '0';

                -- Wait for command to be finished
                if Wr_Done = '1' or Wr_Error = '1' then
                    -- Update head pointer
                    currHead_v := p.head + (resize(unsigned(p.size) * WORD_LEN_C, AXI_ADDR_WIDTH_G));

                    -- Check for wrap around
                    if currHead_v > unsigned(MemHigh) then
                        n.head <= unsigned(MemLow); -- This is correct because we always write until MemHigh which is handled in CALC_SEND_SIZE state;
                    else
                        n.head <= currHead_v;
                    end if;

                    n.state <= IDLE;
                end if;

                -- Save the error
                n.errorAXIWrite <= p.errorAXIWrite or Wr_Error;
        end case;
    end process;

end architecture behavioral;
