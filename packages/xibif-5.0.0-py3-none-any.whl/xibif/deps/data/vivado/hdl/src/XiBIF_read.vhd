-- ----------------------------------------------------------------------------------------------------
-- brief: FSM for read part of XiBIF
-- file: XiBIF_read.vhd
-- author: lukas.leuenberger
-- ----------------------------------------------------------------------------------------------------
-- Copyright(c) 2025 by OST, Switzerland
-- All rights reserved.
-- ----------------------------------------------------------------------------------------------------
-- File history:
-- Version, Date, Author, Remarks
-- ----------------------------------------------------------------------------------------------------
-- 0.1, 03.10.2025, lukas.leuenberger, First version
-- ----------------------------------------------------------------------------------------------------

library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

library olo;
use olo.olo_base_pkg_math.all;

entity Xibif_read is
    generic(
        FIFO_DEPTH_G     : positive := 1024;
        AXI_ADDR_WIDTH_G : positive := 32;
        AXI_DATA_WIDTH_G : positive := 32
    );
    port(
        -- Control Signals
        ClkxCI           : in  std_logic;
        RstxRBI          : in  std_logic;
        SoftReset        : in  std_logic;
        SoftResetDonexDO : out std_logic;
        -- Command signals to/from the olo_axi_master_simple
        CmdRd_Addr       : out std_logic_vector(AXI_ADDR_WIDTH_G - 1 downto 0);
        CmdRd_Size       : out std_logic_vector(log2ceil(FIFO_DEPTH_G + 1) - 1 downto 0);
        CmdRd_Valid      : out std_logic;
        CmdRd_Ready      : in  std_logic;
        Rd_Done          : in  std_logic;
        Rd_Error         : in  std_logic;
        Rd_FIFOLevel     : in  std_logic_vector(log2ceil(FIFO_DEPTH_G + 1) - 1 downto 0);
        -- Command signals to/from the c-code over registers
        MemLow           : in  std_logic_vector(AXI_ADDR_WIDTH_G - 1 downto 0); -- Low or base address of memory region
        MemHigh          : in  std_logic_vector(AXI_ADDR_WIDTH_G - 1 downto 0); -- High address of memory region
        Tail             : out std_logic_vector(AXI_ADDR_WIDTH_G - 1 downto 0); -- Address of next readable word in memory
        HeadxDI          : in  std_logic_vector(AXI_ADDR_WIDTH_G - 1 downto 0); -- Address of next writable word in memory
        ErrorAXIReadxDO  : out std_logic
    );
end entity Xibif_read;

architecture behavioral of Xibif_read is

    type fsmState_t is (RESET, IDLE, CALC_READ_SIZE, ISSUE_READ_CMD);
    type state_t is record
        state          : fsmState_t;
        tail           : unsigned(AXI_ADDR_WIDTH_G - 1 downto 0);
        headAheadSnap  : boolean;
        size           : unsigned(log2ceil(FIFO_DEPTH_G + 1) - 1 downto 0);
        valid          : std_logic;
        errorAXIRead   : std_logic;
        softResetDone  : std_logic;
        currSizeAhead  : unsigned(AXI_ADDR_WIDTH_G - 1 downto 0);
        currSizeBehind : unsigned(AXI_ADDR_WIDTH_G - 1 downto 0);
    end record state_t;

    constant INIT_STATE_C : state_t := (
        state          => RESET,
        tail           => (others => '0'),
        headAheadSnap  => false,
        size           => (others => '0'),
        valid          => '0',
        errorAXIRead   => '0',
        softResetDone  => '1',
        currSizeAhead  => (others => '0'),
        currSizeBehind => (others => '0')
    );

    constant WORD_LEN_C : unsigned(3 downto 0) := to_unsigned(AXI_DATA_WIDTH_G / 8, 4);

    signal p, n : state_t := INIT_STATE_C;
begin

    state_reg : process(ClkxCI)
    begin
        if rising_edge(ClkxCI) then
            if RstxRBI = '0' then
                p <= INIT_STATE_C;

            else
                p <= n;
            end if;
        end if;
    end process;

    next_logic : process(p, CmdRd_Ready, MemHigh, MemLow, HeadxDI, Rd_Done, Rd_Error, Rd_FIFOLevel, SoftReset)
        variable currSize_v  : unsigned(AXI_ADDR_WIDTH_G - 1 downto 0);
        variable currTail_v  : unsigned(AXI_ADDR_WIDTH_G - 1 downto 0);
        variable fifoSpace_v : unsigned(AXI_ADDR_WIDTH_G - 1 downto 0);
    begin
        -- Default assignments
        n <= p;

        -- Pre-calculated conditions to reduce timing paths
        fifoSpace_v      := to_unsigned(FIFO_DEPTH_G, AXI_ADDR_WIDTH_G) - resize(unsigned(Rd_FIFOLevel), AXI_ADDR_WIDTH_G);
        n.headAheadSnap  <= unsigned(HeadxDI) > p.tail;
        n.currSizeAhead  <= minimum(resize((unsigned(HeadxDI) - p.tail) / WORD_LEN_C, AXI_ADDR_WIDTH_G), fifoSpace_v);
        n.currSizeBehind <= minimum(resize((unsigned(MemHigh) - p.tail + WORD_LEN_C) / WORD_LEN_C, AXI_ADDR_WIDTH_G), fifoSpace_v);

        -- Outputs
        CmdRd_Addr       <= std_logic_vector(p.tail);
        CmdRd_Size       <= std_logic_vector(p.size);
        CmdRd_Valid      <= p.valid;
        Tail             <= std_logic_vector(p.tail);
        ErrorAXIReadxDO  <= p.errorAXIRead;
        SoftResetDonexDO <= p.softResetDone;

        case p.state is
            when RESET =>
                n               <= INIT_STATE_C;
                n.tail          <= unsigned(MemLow); -- when reset the first address that can be read from is the base address
                n.softResetDone <= '1';

                if SoftReset = '1' then
                    n.state         <= IDLE;
                    n.softResetDone <= '0';
                end if;

            when IDLE =>
                if SoftReset = '0' then
                    n.state <= RESET;
                else
                    if (fifoSpace_v > 0 and CmdRd_Ready = '1') then -- check if FIFO has space and AXI master is ready
                        -- Check where the head is
                        if (unsigned(HeadxDI) /= p.tail) then
                            n.state <= CALC_READ_SIZE;
                        end if;
                    end if;
                end if;

            when CALC_READ_SIZE =>
                -- Calculate number of data to read from pre-calculated values
                if p.headAheadSnap then
                    -- Head is in front - read until head
                    currSize_v := p.currSizeAhead;
                else
                    -- Head is behind (wrapped) - read until end of memory region
                    currSize_v := p.currSizeBehind;
                end if;

                -- The head might not be aligned to WORD_LEN_C, so we might end up with currSize_v = 0
                if currSize_v > 0 then
                    n.size  <= resize(currSize_v, log2ceil(FIFO_DEPTH_G + 1)); -- Store the calculated size
                    n.valid <= '1';

                    -- Switch the state
                    n.state <= ISSUE_READ_CMD;
                else
                    n.state <= IDLE;
                end if;

            when ISSUE_READ_CMD =>
                -- Reset valid after command has been sent
                n.valid <= '0';

                -- Wait for command to be finished
                if Rd_Done = '1' or Rd_Error = '1' then
                    -- Update tail pointer
                    currTail_v := p.tail + resize(unsigned(p.size) * WORD_LEN_C, AXI_ADDR_WIDTH_G);

                    -- Check for wrap around
                    if currTail_v > unsigned(MemHigh) then
                        n.tail <= unsigned(MemLow); -- This is correct because we always read until MemHigh which is handled in CALC_READ_SIZE state
                    else
                        n.tail <= currTail_v;
                    end if;

                    n.state <= IDLE;
                end if;

                -- Save the error
                n.errorAXIRead <= p.errorAXIRead or Rd_Error;
        end case;
    end process;

end architecture behavioral;
