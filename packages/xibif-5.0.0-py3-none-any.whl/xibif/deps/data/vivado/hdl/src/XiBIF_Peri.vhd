---------------------------------------------------------------------------------------------------
-- Project:  XiBIF
-- Customer: Generic
---------------------------------------------------------------------------------------------------
-- Description: 
-- XiBIF peripheral providing an AXI4-Stream source and sink for high throughput data and registers
-- for configuration. Connect the AXI4-Lite slave interface to a GP and the AXI4 master to an ACP 
-- port of the Zynq processing system.   
---------------------------------------------------------------------------------------------------
-- SZR,  2020-11-24  Updated to V2.0
-- PEFL, 2024-08-13  Updated to V3.0
-- LELU, 2025-10-03  Updated to V4.0 - Used new olo_axi_master_simple component
-- LELU: 2026-02-25  Updated to V4.1 - Added halt for AXI streams
---------------------------------------------------------------------------------------------------

library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;
use ieee.math_real.all;

library olo;
use olo.olo_base_pkg_math.all;

Library unisim;
use unisim.vcomponents.all;

entity XiBIF_Peri is
    generic(
        ENABLE_TO_PC_STREAM_G   : boolean                 := true; -- Enable AXI Stream from PL to PC
        ENABLE_FROM_PC_STREAM_G : boolean                 := true; -- Enable AXI Stream from PC to PL
        MAX_BURST_LEN_G         : positive range 1 to 256 := 256; -- Maximum length of a burst
        FIFO_DEPTH_G            : positive                := 1024;
        AXI_ADDR_WIDTH_G        : positive                := 32;
        AXI_DATA_WIDTH_G        : positive                := 32;
        AXIL_ADDR_WIDTH_G       : positive                := 10; 
        AXIL_DATA_WIDTH_G       : positive                := 32
    );
    port(
        -- Ports of Axi Slave Bus Interface S_AXIL
        ClkxCI              : in  std_logic;
        RstxRBI             : in  std_logic;
        -----------------------------------------------------------------------------------------------
        --- AXI Lite Slave 
        -----------------------------------------------------------------------------------------------
        S_AXIL_awaddr       : in  std_logic_vector(AXIL_ADDR_WIDTH_G - 1 downto 0);
        S_AXIL_awvalid      : in  std_logic;
        S_AXIL_awready      : out std_logic;
        S_AXIL_wdata        : in  std_logic_vector(AXIL_DATA_WIDTH_G - 1 downto 0);
        S_AXIL_wstrb        : in  std_logic_vector(AXIL_DATA_WIDTH_G / 8 - 1 downto 0);
        S_AXIL_wvalid       : in  std_logic;
        S_AXIL_wready       : out std_logic;
        S_AXIL_bvalid       : out std_logic                                           := '1';
        S_AXIL_bready       : in  std_logic;
        S_AXIL_araddr       : in  std_logic_vector(AXIL_ADDR_WIDTH_G - 1 downto 0);
        S_AXIL_arvalid      : in  std_logic;
        S_AXIL_arready      : out std_logic;
        S_AXIL_rdata        : out std_logic_vector(AXIL_DATA_WIDTH_G - 1 downto 0);
        S_AXIL_rvalid       : out std_logic;
        S_AXIL_rready       : in  std_logic;
        S_AXIL_awprot       : in  std_logic_vector(2 downto 0);
        S_AXIL_bresp        : out std_logic_vector(1 downto 0);
        S_AXIL_arprot       : in  std_logic_vector(2 downto 0);
        S_AXIL_rresp        : out std_logic_vector(1 downto 0);
        -----------------------------------------------------------------------------------------------
        --- AXI Streams
        -----------------------------------------------------------------------------------------------
        -- PL to PC
        AXIS_TO_PC_tvalid   : in  std_logic;
        AXIS_TO_PC_tready   : out std_logic;
        AXIS_TO_PC_tdata    : in  std_logic_vector(AXI_DATA_WIDTH_G - 1 downto 0);
        -- PC to PL
        AXIS_FROM_PC_tvalid : out std_logic;
        AXIS_FROM_PC_tready : in  std_logic;
        AXIS_FROM_PC_tdata  : out std_logic_vector(AXI_DATA_WIDTH_G - 1 downto 0);
        -----------------------------------------------------------------------------------------------
        --- AXI Master
        -----------------------------------------------------------------------------------------------

        -- Write Address
        M_AXI_AWADDR        : out std_logic_vector(AXI_ADDR_WIDTH_G - 1 downto 0); -- Master Interface Write Address
        M_AXI_AWLEN         : out std_logic_vector(7 downto 0); -- Burst length = AWLEN + 1
        M_AXI_AWCACHE       : out std_logic_vector(3 downto 0)                        := "0110"; -- Memory type. ("0110":  Write-through No-allocate)
        M_AXI_AWPROT        : out std_logic_vector(2 downto 0)                        := "000"; -- Protection type: unprivileged, secure, data
        M_AXI_AWVALID       : out std_logic; -- Write address valid. 
        M_AXI_AWREADY       : in  std_logic; -- Write address ready. 
        M_Axi_AwSize        : out std_logic_vector(2 downto 0);
        M_Axi_AwBurst       : out std_logic_vector(1 downto 0);
        M_Axi_AwLock        : out std_logic;
        -- Write Data
        M_AXI_WDATA         : out std_logic_vector(AXI_DATA_WIDTH_G - 1 downto 0); -- Master Interface Write Data.
        M_AXI_WSTRB         : out std_logic_vector(AXI_DATA_WIDTH_G / 8 - 1 downto 0) := (others => '1'); -- Write strobes. 
        M_AXI_WLAST         : out std_logic; -- Write last indicating last transfer in a write burst.
        M_AXI_WVALID        : out std_logic; -- Write valid. 
        M_AXI_WREADY        : in  std_logic; -- Write ready. 

        -- Write Response
        M_AXI_BRESP         : in  std_logic_vector(1 downto 0); -- Write response. 
        M_AXI_BVALID        : in  std_logic; -- Write response valid. 
        M_AXI_BREADY        : out std_logic; -- Response ready. 

        -- Read Address.
        M_AXI_ARADDR        : out std_logic_vector(AXI_ADDR_WIDTH_G - 1 downto 0); -- Read address. 
        M_AXI_ARLEN         : out std_logic_vector(7 downto 0); -- Burst length = ARLEN + 1. 
        M_Axi_ArSize        : out std_logic_vector(2 downto 0);
        M_Axi_ArBurst       : out std_logic_vector(1 downto 0);
        M_Axi_ArLock        : out std_logic;
        M_AXI_ARCACHE       : out std_logic_vector(3 downto 0)                        := "1010"; -- Memory type. ("1010":  Write-through No-allocate)
        M_AXI_ARPROT        : out std_logic_vector(2 downto 0); -- Protection type: unprivileged, secure, data
        M_AXI_ARVALID       : out std_logic; -- Write address valid. 
        M_AXI_ARREADY       : in  std_logic; -- Read address ready. 

        -- Read Data
        M_AXI_RDATA         : in  std_logic_vector(AXI_DATA_WIDTH_G - 1 downto 0); -- Master Read Data
        M_AXI_RRESP         : in  std_logic_vector(1 downto 0); -- Read response. 
        M_AXI_RLAST         : in  std_logic; -- Read last indicating last transfer in a read burst
        M_AXI_RVALID        : in  std_logic; -- Read valid. 
        M_AXI_RREADY        : out std_logic; -- Read ready. 

        -----------------------------------------------------------------------------------------------
        --- Register Ports and FIFO status info
        -----------------------------------------------------------------------------------------------
        WrFIFOLevelxDO      : out std_logic_vector(AXIL_DATA_WIDTH_G - 1 downto 0)    := (others => '0');
        RdFIFOLevelxDO      : out std_logic_vector(AXIL_DATA_WIDTH_G - 1 downto 0)    := (others => '0');
        -----------------------------------------------------------------------------------------------
        --- Status and Control ports
        -----------------------------------------------------------------------------------------------
        SnCHostConnectedxDO : out std_logic;
        SnCSoftwareResetxRO : out std_logic
    );
end entity XiBIF_Peri;

architecture behavioral of XiBIF_Peri is
    -----------------------------------------------------------------------------------------------
    -- Attributes for AXI
    -----------------------------------------------------------------------------------------------
    attribute X_INTERFACE_INFO                   : string;
    attribute X_INTERFACE_INFO of S_AXIL_awaddr  : signal is "xilinx.com:interface:aximm:1.0 S_AXIL AWADDR";
    attribute X_INTERFACE_INFO of S_AXIL_awvalid : signal is "xilinx.com:interface:aximm:1.0 S_AXIL AWVALID";
    attribute X_INTERFACE_INFO of S_AXIL_awready : signal is "xilinx.com:interface:aximm:1.0 S_AXIL AWREADY";
    attribute X_INTERFACE_INFO of S_AXIL_awprot  : signal is "xilinx.com:interface:aximm:1.0 S_AXIL AWPROT";

    attribute X_INTERFACE_INFO of S_AXIL_wdata  : signal is "xilinx.com:interface:aximm:1.0 S_AXIL WDATA";
    attribute X_INTERFACE_INFO of S_AXIL_wstrb  : signal is "xilinx.com:interface:aximm:1.0 S_AXIL WSTRB";
    attribute X_INTERFACE_INFO of S_AXIL_wvalid : signal is "xilinx.com:interface:aximm:1.0 S_AXIL WVALID";
    attribute X_INTERFACE_INFO of S_AXIL_wready : signal is "xilinx.com:interface:aximm:1.0 S_AXIL WREADY";

    attribute X_INTERFACE_INFO of S_AXIL_bvalid : signal is "xilinx.com:interface:aximm:1.0 S_AXIL BVALID";
    attribute X_INTERFACE_INFO of S_AXIL_bready : signal is "xilinx.com:interface:aximm:1.0 S_AXIL BREADY";
    attribute X_INTERFACE_INFO of S_AXIL_bresp  : signal is "xilinx.com:interface:aximm:1.0 S_AXIL BRESP";

    attribute X_INTERFACE_INFO of S_AXIL_araddr  : signal is "xilinx.com:interface:aximm:1.0 S_AXIL ARADDR";
    attribute X_INTERFACE_INFO of S_AXIL_arvalid : signal is "xilinx.com:interface:aximm:1.0 S_AXIL ARVALID";
    attribute X_INTERFACE_INFO of S_AXIL_arready : signal is "xilinx.com:interface:aximm:1.0 S_AXIL ARREADY";
    attribute X_INTERFACE_INFO of S_AXIL_arprot  : signal is "xilinx.com:interface:aximm:1.0 S_AXIL ARPROT";

    attribute X_INTERFACE_INFO of S_AXIL_rdata  : signal is "xilinx.com:interface:aximm:1.0 S_AXIL RDATA";
    attribute X_INTERFACE_INFO of S_AXIL_rvalid : signal is "xilinx.com:interface:aximm:1.0 S_AXIL RVALID";
    attribute X_INTERFACE_INFO of S_AXIL_rready : signal is "xilinx.com:interface:aximm:1.0 S_AXIL RREADY";
    attribute X_INTERFACE_INFO of S_AXIL_rresp  : signal is "xilinx.com:interface:aximm:1.0 S_AXIL RRESP";

    attribute X_INTERFACE_INFO of M_AXI_AWADDR  : signal is "xilinx.com:interface:aximm:1.0 M_AXI AWADDR";
    attribute X_INTERFACE_INFO of M_AXI_AWLEN   : signal is "xilinx.com:interface:aximm:1.0 M_AXI AWLEN";
    attribute X_INTERFACE_INFO of M_AXI_AWCACHE : signal is "xilinx.com:interface:aximm:1.0 M_AXI AWCACHE";
    attribute X_INTERFACE_INFO of M_AXI_AWPROT  : signal is "xilinx.com:interface:aximm:1.0 M_AXI AWPROT";
    attribute X_INTERFACE_INFO of M_AXI_AWVALID : signal is "xilinx.com:interface:aximm:1.0 M_AXI AWVALID";
    attribute X_INTERFACE_INFO of M_AXI_AWREADY : signal is "xilinx.com:interface:aximm:1.0 M_AXI AWREADY";
    attribute X_INTERFACE_INFO of M_Axi_AwSize  : signal is "xilinx.com:interface:aximm:1.0 M_AXI AwSize";
    attribute X_INTERFACE_INFO of M_Axi_AwBurst : signal is "xilinx.com:interface:aximm:1.0 M_AXI AwBurst";
    attribute X_INTERFACE_INFO of M_Axi_AwLock  : signal is "xilinx.com:interface:aximm:1.0 M_AXI AwLock";

    attribute X_INTERFACE_INFO of M_AXI_WDATA  : signal is "xilinx.com:interface:aximm:1.0 M_AXI WDATA";
    attribute X_INTERFACE_INFO of M_AXI_WSTRB  : signal is "xilinx.com:interface:aximm:1.0 M_AXI WSTRB";
    attribute X_INTERFACE_INFO of M_AXI_WLAST  : signal is "xilinx.com:interface:aximm:1.0 M_AXI WLAST";
    attribute X_INTERFACE_INFO of M_AXI_WVALID : signal is "xilinx.com:interface:aximm:1.0 M_AXI WVALID";
    attribute X_INTERFACE_INFO of M_AXI_WREADY : signal is "xilinx.com:interface:aximm:1.0 M_AXI WREADY";

    attribute X_INTERFACE_INFO of M_AXI_BRESP  : signal is "xilinx.com:interface:aximm:1.0 M_AXI BRESP";
    attribute X_INTERFACE_INFO of M_AXI_BVALID : signal is "xilinx.com:interface:aximm:1.0 M_AXI BVALID";
    attribute X_INTERFACE_INFO of M_AXI_BREADY : signal is "xilinx.com:interface:aximm:1.0 M_AXI BREADY";

    attribute X_INTERFACE_INFO of M_AXI_ARADDR  : signal is "xilinx.com:interface:aximm:1.0 M_AXI ARADDR";
    attribute X_INTERFACE_INFO of M_AXI_ARLEN   : signal is "xilinx.com:interface:aximm:1.0 M_AXI ARLEN";
    attribute X_INTERFACE_INFO of M_AXI_ARCACHE : signal is "xilinx.com:interface:aximm:1.0 M_AXI ARCACHE";
    attribute X_INTERFACE_INFO of M_AXI_ARPROT  : signal is "xilinx.com:interface:aximm:1.0 M_AXI ARPROT";
    attribute X_INTERFACE_INFO of M_AXI_ARVALID : signal is "xilinx.com:interface:aximm:1.0 M_AXI ARVALID";
    attribute X_INTERFACE_INFO of M_AXI_ARREADY : signal is "xilinx.com:interface:aximm:1.0 M_AXI ARREADY";
    attribute X_INTERFACE_INFO of M_Axi_ArSize  : signal is "xilinx.com:interface:aximm:1.0 M_AXI ArSize";
    attribute X_INTERFACE_INFO of M_Axi_ArBurst : signal is "xilinx.com:interface:aximm:1.0 M_AXI ArBurst";
    attribute X_INTERFACE_INFO of M_Axi_ArLock  : signal is "xilinx.com:interface:aximm:1.0 M_AXI ArLock";

    attribute X_INTERFACE_INFO of M_AXI_RDATA  : signal is "xilinx.com:interface:aximm:1.0 M_AXI RDATA ";
    attribute X_INTERFACE_INFO of M_AXI_RRESP  : signal is "xilinx.com:interface:aximm:1.0 M_AXI RRESP";
    attribute X_INTERFACE_INFO of M_AXI_RLAST  : signal is "xilinx.com:interface:aximm:1.0 M_AXI RLAST";
    attribute X_INTERFACE_INFO of M_AXI_RVALID : signal is "xilinx.com:interface:aximm:1.0 M_AXI RVALID";
    attribute X_INTERFACE_INFO of M_AXI_RREADY : signal is "xilinx.com:interface:aximm:1.0 M_AXI RREADY";

    attribute X_INTERFACE_INFO of AXIS_TO_PC_tdata    : signal is "xilinx.com:interface:axis:1.0 AXIS_TO_PC TDATA";
    attribute X_INTERFACE_INFO of AXIS_TO_PC_tvalid   : signal is "xilinx.com:interface:axis:1.0 AXIS_TO_PC TVALID";
    attribute X_INTERFACE_INFO of AXIS_TO_PC_tready   : signal is "xilinx.com:interface:axis:1.0 AXIS_TO_PC TREADY";
    attribute X_INTERFACE_INFO of AXIS_FROM_PC_tdata  : signal is "xilinx.com:interface:axis:1.0 AXIS_FROM_PC TDATA";
    attribute X_INTERFACE_INFO of AXIS_FROM_PC_tvalid : signal is "xilinx.com:interface:axis:1.0 AXIS_FROM_PC TVALID";
    attribute X_INTERFACE_INFO of AXIS_FROM_PC_tready : signal is "xilinx.com:interface:axis:1.0 AXIS_FROM_PC TREADY";
    attribute X_INTERFACE_INFO of ClkxCI              : signal is "xilinx.com:signal:clock:1.0 clkAXI_in CLK";
    attribute X_INTERFACE_INFO of RstxRBI             : signal is "xilinx.com:signal:reset:1.0 reset_in RST";

    attribute X_INTERFACE_PARAMETER            : string;
    attribute X_INTERFACE_PARAMETER of ClkxCI  : signal is "ASSOCIATED_BUSIF S_AXIL:M_AXI:AXIS_TO_PC:AXIS_FROM_PC, ASSOCIATED_RESET RstxRBI";
    attribute X_INTERFACE_PARAMETER of RstxRBI : signal is "POLARITY ACTIVE_LOW";

    --------------------------------------------------
    -- COMPONENT DECLARATIONS
    --------------------------------------------------
    component USR_ACCESSE2
        port(
            CFGCLK    : out std_ulogic;
            DATA      : out std_logic_vector(31 downto 0);
            DATAVALID : out std_ulogic
        );
    end component;

    --------------------------------------------------
    ---- Function to convert a boolean to std_logic
    --------------------------------------------------
    function toSl(b : boolean) return std_logic is
    begin
        if b then
            return '1';
        else
            return '0';
        end if;
    end function toSl;

    --------------------------------------------------
    ---- Signals for MM to stream link
    --------------------------------------------------
    signal ToPcLow          : std_logic_vector(AXIL_DATA_WIDTH_G - 1 downto 0);
    signal ToPcHigh         : std_logic_vector(AXIL_DATA_WIDTH_G - 1 downto 0);
    signal ToPcTail         : std_logic_vector(AXIL_DATA_WIDTH_G - 1 downto 0);
    signal ToPcHead         : std_logic_vector(AXIL_DATA_WIDTH_G - 1 downto 0);
    signal ToPcRd           : std_logic_vector(AXI_ADDR_WIDTH_G - 1 downto 0);
    signal ToPcErrorAXI     : std_logic;
    signal ToPcErrorMemFull : std_logic;

    signal FromPcLow      : std_logic_vector(AXIL_DATA_WIDTH_G - 1 downto 0);
    signal FromPcHigh     : std_logic_vector(AXIL_DATA_WIDTH_G - 1 downto 0);
    signal FromPcTail     : std_logic_vector(AXIL_DATA_WIDTH_G - 1 downto 0);
    signal FromPcHead     : std_logic_vector(AXIL_DATA_WIDTH_G - 1 downto 0);
    signal FromPcWr       : std_logic_vector(AXI_ADDR_WIDTH_G - 1 downto 0);
    signal FromPcErrorAXI : std_logic;

    signal PerixRB              : std_logic := '1';
    signal PeriResetDoneWrite   : std_logic := '0';
    signal PeriResetDoneRead    : std_logic := '0';
    signal PeriResetDone        : std_logic := '0';
    signal EnablePeriHardReset  : std_logic := '0';
    signal HaltStreams          : std_logic := '1';
    signal HaltAxisFromPCtvalid : std_logic := '0';
    signal HaltAxisFromPCtready : std_logic := '0';
    signal HaltAxisToPCtvalid   : std_logic := '0';
    signal HaltAxisToPCtready   : std_logic := '0';

    -----------------------------------------------------------------------------------------------
    --- Responses and errors
    -----------------------------------------------------------------------------------------------
    signal WrDone  : std_logic;
    signal WrError : std_logic;
    signal RdDone  : std_logic;
    signal RdError : std_logic;

    signal WrFIFOLevel : std_logic_vector(log2ceil(FIFO_DEPTH_G + 1) - 1 downto 0);
    signal RdFIFOLevel : std_logic_vector(log2ceil(FIFO_DEPTH_G + 1) - 1 downto 0);

    signal CmdWrAddr  : std_logic_vector(AXI_ADDR_WIDTH_G - 1 downto 0);
    signal CmdWrSize  : std_logic_vector(log2ceil(FIFO_DEPTH_G + 1) - 1 downto 0);
    signal CmdWrValid : std_logic;
    signal CmdWrReady : std_logic;

    signal CmdRdAddr  : std_logic_vector(AXI_ADDR_WIDTH_G - 1 downto 0);
    signal CmdRdSize  : std_logic_vector(log2ceil(FIFO_DEPTH_G + 1) - 1 downto 0);
    signal CmdRdValid : std_logic;
    signal CmdRdReady : std_logic;

    ------------------------------------------------------------------------------------------------
    -- Build timestamp
    ------------------------------------------------------------------------------------------------
    signal buildTimestamp : std_logic_vector(31 downto 0);

begin
    assert (AXIL_DATA_WIDTH_G = 32) report "AXIL_DATA_WIDTH must be 32" severity failure;
    assert (AXI_DATA_WIDTH_G = 32) report "AXI_DATA_WIDTH must be 32" severity failure;
    assert (AXI_ADDR_WIDTH_G <= AXIL_DATA_WIDTH_G) report "AXI_ADDR_WIDTH must be <= AXIL_DATA_WIDTH" severity failure;

    inst_regs : entity work.XiBIF_stream_regs
        generic map(
            ADDR_W => AXIL_ADDR_WIDTH_G,
            DATA_W => AXIL_DATA_WIDTH_G,
            STRB_W => AXIL_DATA_WIDTH_G / 8
        )
        port map(
            clk                                        => ClkxCI,
            rst                                        => RstxRBI,
            -- AXI Settings
            csr_axi_stream_1_width_in                  => std_logic_vector(to_unsigned(AXI_DATA_WIDTH_G, AXIL_DATA_WIDTH_G)),
            csr_axi_stream_2_width_in                  => std_logic_vector(to_unsigned(FIFO_DEPTH_G, AXIL_DATA_WIDTH_G)),
            csr_axi_stream_3_enablefifotopc_in         => toSl(ENABLE_TO_PC_STREAM_G),
            csr_axi_stream_3_enablefifofrompc_in       => toSl(ENABLE_FROM_PC_STREAM_G),
            -- Write
            csr_fifo_to_pc_1_low_out                   => ToPcLow,
            csr_fifo_to_pc_2_high_out                  => ToPcHigh,
            csr_fifo_to_pc_3_error_axi_in              => ToPcErrorAXI,
            csr_fifo_to_pc_3_error_memfull_in          => ToPcErrorMemFull,
            csr_fifo_to_pc_4_head_in                   => ToPcHead,
            csr_fifo_to_pc_5_tail_out                  => ToPcTail,
            -- Read
            csr_fifo_from_pc_1_low_out                 => FromPcLow,
            csr_fifo_from_pc_2_high_out                => FromPcHigh,
            csr_fifo_from_pc_3_error_axi_in            => FromPcErrorAXI,
            csr_fifo_from_pc_4_head_out                => FromPcHead,
            csr_fifo_from_pc_5_tail_in                 => FromPcTail,
            -- Status and Control
            csr_reset_reset_out                        => PerixRB,
            csr_reset_resetdone_in                     => PeriResetDone,
            csr_reset_enablehardreset_out              => EnablePeriHardReset,
            csr_reset_halt_out                         => HaltStreams,
            csr_status_control_to_hw_hostconnected_out => SnCHostConnectedxDO,
            csr_status_control_to_hw_softwarereset_out => SnCSoftwareResetxRO,
            -- AXI Lite Slave
            axil_awaddr                                => S_AXIL_awaddr,
            axil_awprot                                => S_AXIL_awprot,
            axil_awvalid                               => S_AXIL_awvalid,
            axil_awready                               => S_AXIL_awready,
            axil_wdata                                 => S_AXIL_wdata,
            axil_wstrb                                 => S_AXIL_wstrb,
            axil_wvalid                                => S_AXIL_wvalid,
            axil_wready                                => S_AXIL_wready,
            axil_bresp                                 => S_AXIL_bresp,
            axil_bvalid                                => S_AXIL_bvalid,
            axil_bready                                => S_AXIL_bready,
            axil_araddr                                => S_AXIL_araddr,
            axil_arprot                                => S_AXIL_arprot,
            axil_arvalid                               => S_AXIL_arvalid,
            axil_arready                               => S_AXIL_arready,
            axil_rdata                                 => S_AXIL_rdata,
            axil_rresp                                 => S_AXIL_rresp,
            axil_rvalid                                => S_AXIL_rvalid,
            axil_rready                                => S_AXIL_rready,
            csr_build_timestamp_timestamp_in => buildTimestamp
        );

    gen_disablePL2PC : if ENABLE_TO_PC_STREAM_G = false generate
        CmdWrAddr                               <= (others => '0');
        CmdWrSize                               <= (others => '0');
        CmdWrValid                              <= '0';
        ToPcHead(AXI_ADDR_WIDTH_G - 1 downto 0) <= ToPcTail(AXI_ADDR_WIDTH_G - 1 downto 0);
        ToPcErrorMemFull                        <= '0';
        ToPcErrorAXI                            <= '0';
        PeriResetDoneWrite                      <= '1';
        WrFIFOLevelxDO                          <= (others => '0');
    end generate gen_disablePL2PC;

    gen_enablePL2PC : if ENABLE_TO_PC_STREAM_G = true generate -- @suppress "Redundant boolean equality check with true"
        inst_write : entity work.Xibif_write
            generic map(
                FIFO_DEPTH_G     => FIFO_DEPTH_G,
                AXI_ADDR_WIDTH_G => AXI_ADDR_WIDTH_G,
                AXI_DATA_WIDTH_G => AXI_DATA_WIDTH_G
            )
            port map(
                ClkxCI        => ClkxCI,
                RstxRBI       => (RstxRBI and (not EnablePeriHardReset)) or (RstxRBI and PerixRB),
                Wr_FIFOLevel  => WrFIFOLevel,
                Wr_Done       => WrDone,
                Wr_Error      => WrError,
                CmdWr_Addr    => CmdWrAddr,
                CmdWr_Size    => CmdWrSize,
                CmdWr_Valid   => CmdWrValid,
                CmdWr_Ready   => CmdWrReady,
                MemLow        => ToPcLow(AXI_ADDR_WIDTH_G - 1 downto 0), -- Low or base adress of memory region
                MemHigh       => ToPcHigh(AXI_ADDR_WIDTH_G - 1 downto 0), -- High address of memory region
                Tail          => ToPcTail(AXI_ADDR_WIDTH_G - 1 downto 0), -- Address of next readable word
                Head          => ToPcHead(AXI_ADDR_WIDTH_G - 1 downto 0), -- Address of next writable word
                ErrorMemFull  => ToPcErrorMemFull,
                ErrorAXIWrite => ToPcErrorAXI,
                SoftResetDone => PeriResetDoneWrite,
                SoftReset     => PerixRB
            );

        WrFIFOLevelxDO(WrFIFOLevelxDO'high downto WrFIFOLevel'length) <= (others => '0');
        WrFIFOLevelxDO(WrFIFOLevel'range)                             <= WrFIFOLevel;
    end generate gen_enablePL2PC;

    gen_disablePC2PL : if ENABLE_FROM_PC_STREAM_G = false generate
        CmdRdAddr                                 <= (others => '0');
        CmdRdSize                                 <= (others => '0');
        CmdRdValid                                <= '0';
        FromPcTail(AXI_ADDR_WIDTH_G - 1 downto 0) <= FromPcHead(AXI_ADDR_WIDTH_G - 1 downto 0);
        FromPcErrorAXI                            <= '0';
        PeriResetDoneRead                         <= '1';
        RdFIFOLevelxDO                            <= (others => '0');
    end generate gen_disablePC2PL;

    gen_enablePC2PL : if ENABLE_FROM_PC_STREAM_G = true generate -- @suppress "Redundant boolean equality check with true"
        inst_read : entity work.Xibif_read
            generic map(
                FIFO_DEPTH_G     => FIFO_DEPTH_G,
                AXI_ADDR_WIDTH_G => AXI_ADDR_WIDTH_G,
                AXI_DATA_WIDTH_G => AXI_DATA_WIDTH_G
            )
            port map(
                ClkxCI           => ClkxCI,
                RstxRBI          => (RstxRBI and (not EnablePeriHardReset)) or (RstxRBI and PerixRB),
                Rd_FIFOLevel     => RdFIFOLevel,
                CmdRd_Addr       => CmdRdAddr,
                CmdRd_Size       => CmdRdSize,
                CmdRd_Valid      => CmdRdValid,
                CmdRd_Ready      => CmdRdReady,
                MemLow           => FromPcLow(AXI_ADDR_WIDTH_G - 1 downto 0),
                MemHigh          => FromPcHigh(AXI_ADDR_WIDTH_G - 1 downto 0),
                Tail             => FromPcTail(AXI_ADDR_WIDTH_G - 1 downto 0),
                ErrorAXIReadxDO  => FromPcErrorAXI,
                Rd_Done          => RdDone,
                Rd_Error         => RdError,
                HeadxDI          => FromPcHead(AXI_ADDR_WIDTH_G - 1 downto 0),
                SoftResetDonexDO => PeriResetDoneRead,
                SoftReset        => PerixRB
            );

        RdFIFOLevelxDO(RdFIFOLevelxDO'high downto RdFIFOLevel'length) <= (others => '0');
        RdFIFOLevelxDO(RdFIFOLevel'range)                             <= RdFIFOLevel;
    end generate gen_enablePC2PL;

    PeriResetDone <= PeriResetDoneRead and PeriResetDoneWrite;

    inst_axi : entity work.XiBIF_axi_master_simple
        generic map(
            AxiAddrWidth_g            => AXI_ADDR_WIDTH_G,
            AxiDataWidth_g            => AXI_DATA_WIDTH_G,
            AxiMaxBeats_g             => MAX_BURST_LEN_G,
            AxiMaxOpenTransactions_g  => 1,
            -- User Configuration
            UserTransactionSizeBits_g => log2ceil(FIFO_DEPTH_G + 1),
            DataFifoDepth_g           => FIFO_DEPTH_G,
            ImplRead_g                => ENABLE_FROM_PC_STREAM_G,
            ImplWrite_g               => ENABLE_TO_PC_STREAM_G,
            RamBehavior_g             => "RBW"
        )
        port map(
            -- Control Signals
            Clk           => ClkxCI,
            Rst           => "not"(RstxRBI) or PeriResetDone,
            -- Response
            Wr_Done       => WrDone,
            Wr_Error      => WrError,
            Rd_Done       => RdDone,
            Rd_Error      => RdError,
            -- Analog to Xibif FIFO to Mem
            -- User Command Interface
            CmdWr_Addr    => CmdWrAddr,
            CmdWr_Size    => CmdWrSize,
            CmdWr_LowLat  => '0',
            CmdWr_Valid   => CmdWrValid,
            CmdWr_Ready   => CmdWrReady,
            -- Write Data
            Wr_Data       => AXIS_TO_PC_tdata,
            Wr_Be         => (others => '1'),
            Wr_Valid      => HaltAxisToPCtvalid,
            Wr_Ready      => HaltAxisToPCtready,
            -- AXI Address Write Channel
            M_Axi_AwAddr  => M_AXI_AWADDR,
            M_Axi_AwLen   => M_AXI_AWLEN,
            M_Axi_AwSize  => M_Axi_AwSize,
            M_Axi_AwBurst => M_Axi_AwBurst,
            M_Axi_AwLock  => M_Axi_AwLock,
            M_Axi_AwCache => M_AXI_AWCACHE,
            M_Axi_AwProt  => M_AXI_AWPROT,
            M_Axi_AwValid => M_AXI_AWVALID,
            M_Axi_AwReady => M_AXI_AWREADY,
            -- AXI Write Data Channel
            M_Axi_WData   => M_AXI_WDATA,
            M_Axi_WStrb   => M_AXI_WSTRB,
            M_Axi_WLast   => M_AXI_WLAST,
            M_Axi_WValid  => M_AXI_WVALID,
            M_Axi_WReady  => M_AXI_WREADY,
            -- AXI Write Response Channel
            M_Axi_BResp   => M_AXI_BRESP,
            M_Axi_BValid  => M_AXI_BVALID,
            M_Axi_BReady  => M_AXI_BREADY,
            -- Analog to Xibif Mem to FIFO
            -- User Command Interface
            CmdRd_Addr    => CmdRdAddr,
            CmdRd_Size    => CmdRdSize,
            CmdRd_LowLat  => '0',
            CmdRd_Valid   => CmdRdValid,
            CmdRd_Ready   => CmdRdReady,
            -- Read Data
            Rd_Data       => AXIS_FROM_PC_tdata,
            --Rd_Last         => 
            Rd_Valid      => HaltAxisFromPCtvalid,
            Rd_Ready      => HaltAxisFromPCtready,
            -- AXI Read Address Channel
            M_Axi_ArAddr  => M_AXI_ARADDR,
            M_Axi_ArLen   => M_AXI_ARLEN,
            M_Axi_ArSize  => M_Axi_ArSize,
            M_Axi_ArBurst => M_Axi_ArBurst,
            M_Axi_ArLock  => M_Axi_ArLock,
            M_Axi_ArCache => M_AXI_ARCACHE,
            M_Axi_ArProt  => M_AXI_ARPROT,
            M_Axi_ArValid => M_AXI_ARVALID,
            M_Axi_ArReady => M_AXI_ARREADY,
            -- AXI Read Data Channel
            M_Axi_RData   => M_AXI_RDATA,
            M_Axi_RResp   => M_AXI_RRESP,
            M_Axi_RLast   => M_AXI_RLAST,
            M_Axi_RValid  => M_AXI_RVALID,
            M_Axi_RReady  => M_AXI_RREADY,
            -- FIFO Levels
            Wr_FIFOLevel  => WrFIFOLevel,
            Rd_FIFOLevel  => RdFIFOLevel,
            Rd_Last       => open
        );

    -- Do not allow any stream transactions when halt is active
    AXIS_FROM_PC_tvalid  <= HaltAxisFromPCtvalid and (not HaltStreams);
    HaltAxisFromPCtready <= AXIS_FROM_PC_tready and (not HaltStreams);
    HaltAxisToPCtvalid   <= AXIS_TO_PC_tvalid and (not HaltStreams);
    AXIS_TO_PC_tready    <= HaltAxisToPCtready and (not HaltStreams);

    -- Build timestamp
    inst_usrAccess : USR_ACCESSE2
        port map(
            CFGCLK    => open,
            DATA      => buildTimestamp,
            DATAVALID => open
        );
end behavioral;
