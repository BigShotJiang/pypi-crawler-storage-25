# ----------------------------------------------------------------------------
# ZCU104 XDC File
# ----------------------------------------------------------------------------

# ----------------------------------------------------------------------------
# Bitstream Configuration
# ----------------------------------------------------------------------------
set_property BITSTREAM.CONFIG.USR_ACCESS TIMESTAMP [current_design]

# ----------------------------------------------------------------------------
# Clock Source
# ----------------------------------------------------------------------------
set_property -dict {PACKAGE_PIN AH18 IOSTANDARD DIFF_SSTL12} [get_ports SysxCI_clk_p]

# ----------------------------------------------------------------------------
# Misc / Reference Nets
# ----------------------------------------------------------------------------
# set_property PACKAGE_PIN AD10     [get_ports "MGTRREF_224"] ;# Bank 224 - MGTRREF_R

# ----------------------------------------------------------------------------
# Numeric Net Names
# ----------------------------------------------------------------------------
#set_property PACKAGE_PIN B21      [get_ports "5N7582"] ;# Bank  28 VCCO - VCC1V8   - IO_L24N_T3U_N11_28
#set_property IOSTANDARD  LVCMOSxx [get_ports "5N7582"] ;# Bank  28 VCCO - VCC1V8   - IO_L24N_T3U_N11_28
#set_property PACKAGE_PIN B20      [get_ports "5N7577"] ;# Bank  28 VCCO - VCC1V8   - IO_L24P_T3U_N10_28
#set_property IOSTANDARD  LVCMOSxx [get_ports "5N7577"] ;# Bank  28 VCCO - VCC1V8   - IO_L24P_T3U_N10_28
#set_property PACKAGE_PIN A23      [get_ports "5N7578"] ;# Bank  28 VCCO - VCC1V8   - IO_L23N_T3U_N9_28
#set_property IOSTANDARD  LVCMOSxx [get_ports "5N7578"] ;# Bank  28 VCCO - VCC1V8   - IO_L23N_T3U_N9_28
#set_property PACKAGE_PIN A22      [get_ports "5N7569"] ;# Bank  28 VCCO - VCC1V8   - IO_L23P_T3U_N8_28
#set_property IOSTANDARD  LVCMOSxx [get_ports "5N7569"] ;# Bank  28 VCCO - VCC1V8   - IO_L23P_T3U_N8_28
#set_property PACKAGE_PIN B19      [get_ports "5N7570"] ;# Bank  28 VCCO - VCC1V8   - IO_L22N_T3U_N7_DBC_AD0N_28
#set_property IOSTANDARD  LVCMOSxx [get_ports "5N7570"] ;# Bank  28 VCCO - VCC1V8   - IO_L22N_T3U_N7_DBC_AD0N_28
#set_property PACKAGE_PIN B18      [get_ports "5N7565"] ;# Bank  28 VCCO - VCC1V8   - IO_L22P_T3U_N6_DBC_AD0P_28
#set_property IOSTANDARD  LVCMOSxx [get_ports "5N7565"] ;# Bank  28 VCCO - VCC1V8   - IO_L22P_T3U_N6_DBC_AD0P_28
#set_property PACKAGE_PIN A21      [get_ports "5N7709"] ;# Bank  28 VCCO - VCC1V8   - IO_L21N_T3L_N5_AD8N_28
#set_property IOSTANDARD  LVCMOSxx [get_ports "5N7709"] ;# Bank  28 VCCO - VCC1V8   - IO_L21N_T3L_N5_AD8N_28
#set_property PACKAGE_PIN A18      [get_ports "5N7704"] ;# Bank  28 VCCO - VCC1V8   - IO_L19P_T3L_N0_DBC_AD9P_28
#set_property IOSTANDARD  LVCMOSxx [get_ports "5N7704"] ;# Bank  28 VCCO - VCC1V8   - IO_L19P_T3L_N0_DBC_AD9P_28
#set_property PACKAGE_PIN B23      [get_ports "5N7581"] ;# Bank  28 VCCO - VCC1V8   - IO_T3U_N12_28
#set_property IOSTANDARD  LVCMOSxx [get_ports "5N7581"] ;# Bank  28 VCCO - VCC1V8   - IO_T3U_N12_28
#set_property PACKAGE_PIN F25      [get_ports "5N7703"] ;# Bank  28 VCCO - VCC1V8   - IO_T2U_N12_28
#set_property IOSTANDARD  LVCMOSxx [get_ports "5N7703"] ;# Bank  28 VCCO - VCC1V8   - IO_T2U_N12_28
#set_property PACKAGE_PIN G26      [get_ports "5N7702"] ;# Bank  28 VCCO - VCC1V8   - IO_L18N_T2U_N11_AD2N_28
#set_property IOSTANDARD  LVCMOSxx [get_ports "5N7702"] ;# Bank  28 VCCO - VCC1V8   - IO_L18N_T2U_N11_AD2N_28
#set_property PACKAGE_PIN G25      [get_ports "5N7694"] ;# Bank  28 VCCO - VCC1V8   - IO_L18P_T2U_N10_AD2P_28
#set_property IOSTANDARD  LVCMOSxx [get_ports "5N7694"] ;# Bank  28 VCCO - VCC1V8   - IO_L18P_T2U_N10_AD2P_28
#set_property PACKAGE_PIN C23      [get_ports "5N7693"] ;# Bank  28 VCCO - VCC1V8   - IO_L17N_T2U_N9_AD10N_28
#set_property IOSTANDARD  LVCMOSxx [get_ports "5N7693"] ;# Bank  28 VCCO - VCC1V8   - IO_L17N_T2U_N9_AD10N_28
#set_property PACKAGE_PIN D22      [get_ports "5N7690"] ;# Bank  28 VCCO - VCC1V8   - IO_L17P_T2U_N8_AD10P_28
#set_property IOSTANDARD  LVCMOSxx [get_ports "5N7690"] ;# Bank  28 VCCO - VCC1V8   - IO_L17P_T2U_N8_AD10P_28
#set_property PACKAGE_PIN D24      [get_ports "5N7688"] ;# Bank  28 VCCO - VCC1V8   - IO_L16N_T2U_N7_QBC_AD3N_28
#set_property IOSTANDARD  LVCMOSxx [get_ports "5N7688"] ;# Bank  28 VCCO - VCC1V8   - IO_L16N_T2U_N7_QBC_AD3N_28
#set_property PACKAGE_PIN E24      [get_ports "5N7682"] ;# Bank  28 VCCO - VCC1V8   - IO_L16P_T2U_N6_QBC_AD3P_28
#set_property IOSTANDARD  LVCMOSxx [get_ports "5N7682"] ;# Bank  28 VCCO - VCC1V8   - IO_L16P_T2U_N6_QBC_AD3P_28
#set_property PACKAGE_PIN C22      [get_ports "5N7681"] ;# Bank  28 VCCO - VCC1V8   - IO_L15N_T2L_N5_AD11N_28
#set_property IOSTANDARD  LVCMOSxx [get_ports "5N7681"] ;# Bank  28 VCCO - VCC1V8   - IO_L15N_T2L_N5_AD11N_28
#set_property PACKAGE_PIN C21      [get_ports "5N7678"] ;# Bank  28 VCCO - VCC1V8   - IO_L15P_T2L_N4_AD11P_28
#set_property IOSTANDARD  LVCMOSxx [get_ports "5N7678"] ;# Bank  28 VCCO - VCC1V8   - IO_L15P_T2L_N4_AD11P_28
#set_property PACKAGE_PIN G24      [get_ports "5N7676"] ;# Bank  28 VCCO - VCC1V8   - IO_L14N_T2L_N3_GC_28
#set_property IOSTANDARD  LVCMOSxx [get_ports "5N7676"] ;# Bank  28 VCCO - VCC1V8   - IO_L14N_T2L_N3_GC_28
#set_property PACKAGE_PIN G23      [get_ports "5N7672"] ;# Bank  28 VCCO - VCC1V8   - IO_L14P_T2L_N2_GC_28
#set_property IOSTANDARD  LVCMOSxx [get_ports "5N7672"] ;# Bank  28 VCCO - VCC1V8   - IO_L14P_T2L_N2_GC_28
#set_property PACKAGE_PIN F20      [get_ports "5N7532"] ;# Bank  28 VCCO - VCC1V8   - IO_L10N_T1U_N7_QBC_AD4N_28
#set_property IOSTANDARD  LVCMOSxx [get_ports "5N7532"] ;# Bank  28 VCCO - VCC1V8   - IO_L10N_T1U_N7_QBC_AD4N_28
#set_property PACKAGE_PIN G20      [get_ports "5N7533"] ;# Bank  28 VCCO - VCC1V8   - IO_L10P_T1U_N6_QBC_AD4P_28
#set_property IOSTANDARD  LVCMOSxx [get_ports "5N7533"] ;# Bank  28 VCCO - VCC1V8   - IO_L10P_T1U_N6_QBC_AD4P_28
#set_property PACKAGE_PIN D21      [get_ports "5N7524"] ;# Bank  28 VCCO - VCC1V8   - IO_L9N_T1L_N5_AD12N_28
#set_property IOSTANDARD  LVCMOSxx [get_ports "5N7524"] ;# Bank  28 VCCO - VCC1V8   - IO_L9N_T1L_N5_AD12N_28
#set_property PACKAGE_PIN D20      [get_ports "5N7525"] ;# Bank  28 VCCO - VCC1V8   - IO_L9P_T1L_N4_AD12P_28
#set_property IOSTANDARD  LVCMOSxx [get_ports "5N7525"] ;# Bank  28 VCCO - VCC1V8   - IO_L9P_T1L_N4_AD12P_28
#set_property PACKAGE_PIN H22      [get_ports "5N7520"] ;# Bank  28 VCCO - VCC1V8   - IO_L8N_T1L_N3_AD5N_28
#set_property IOSTANDARD  LVCMOSxx [get_ports "5N7520"] ;# Bank  28 VCCO - VCC1V8   - IO_L8N_T1L_N3_AD5N_28
#set_property PACKAGE_PIN H21      [get_ports "5N7521"] ;# Bank  28 VCCO - VCC1V8   - IO_L8P_T1L_N2_AD5P_28
#set_property IOSTANDARD  LVCMOSxx [get_ports "5N7521"] ;# Bank  28 VCCO - VCC1V8   - IO_L8P_T1L_N2_AD5P_28
#set_property PACKAGE_PIN D19      [get_ports "5N7512"] ;# Bank  28 VCCO - VCC1V8   - IO_L7N_T1L_N1_QBC_AD13N_28
#set_property IOSTANDARD  LVCMOSxx [get_ports "5N7512"] ;# Bank  28 VCCO - VCC1V8   - IO_L7N_T1L_N1_QBC_AD13N_28
#set_property PACKAGE_PIN E19      [get_ports "5N7513"] ;# Bank  28 VCCO - VCC1V8   - IO_L7P_T1L_N0_QBC_AD13P_28
#set_property IOSTANDARD  LVCMOSxx [get_ports "5N7513"] ;# Bank  28 VCCO - VCC1V8   - IO_L7P_T1L_N0_QBC_AD13P_28
#set_property PACKAGE_PIN E20      [get_ports "5N7726"] ;# Bank  28 VCCO - VCC1V8   - IO_T1U_N12_28
#set_property IOSTANDARD  LVCMOSxx [get_ports "5N7726"] ;# Bank  28 VCCO - VCC1V8   - IO_T1U_N12_28
#set_property PACKAGE_PIN H23      [get_ports "5N7508"] ;# Bank  28 VCCO - VCC1V8   - IO_T0U_N12_VRP_28
#set_property IOSTANDARD  LVCMOSxx [get_ports "5N7508"] ;# Bank  28 VCCO - VCC1V8   - IO_T0U_N12_VRP_28
#set_property PACKAGE_PIN H24      [get_ports "5N7509"] ;# Bank  28 VCCO - VCC1V8   - IO_L6N_T0U_N11_AD6N_28
#set_property IOSTANDARD  LVCMOSxx [get_ports "5N7509"] ;# Bank  28 VCCO - VCC1V8   - IO_L6N_T0U_N11_AD6N_28
#set_property PACKAGE_PIN J24      [get_ports "5N7500"] ;# Bank  28 VCCO - VCC1V8   - IO_L6P_T0U_N10_AD6P_28
#set_property IOSTANDARD  LVCMOSxx [get_ports "5N7500"] ;# Bank  28 VCCO - VCC1V8   - IO_L6P_T0U_N10_AD6P_28
#set_property PACKAGE_PIN H26      [get_ports "5N7501"] ;# Bank  28 VCCO - VCC1V8   - IO_L5N_T0U_N9_AD14N_28
#set_property IOSTANDARD  LVCMOSxx [get_ports "5N7501"] ;# Bank  28 VCCO - VCC1V8   - IO_L5N_T0U_N9_AD14N_28
#set_property PACKAGE_PIN J25      [get_ports "5N7496"] ;# Bank  28 VCCO - VCC1V8   - IO_L5P_T0U_N8_AD14P_28
#set_property IOSTANDARD  LVCMOSxx [get_ports "5N7496"] ;# Bank  28 VCCO - VCC1V8   - IO_L5P_T0U_N8_AD14P_28
#set_property PACKAGE_PIN K23      [get_ports "5N7497"] ;# Bank  28 VCCO - VCC1V8   - IO_L4N_T0U_N7_DBC_AD7N_28
#set_property IOSTANDARD  LVCMOSxx [get_ports "5N7497"] ;# Bank  28 VCCO - VCC1V8   - IO_L4N_T0U_N7_DBC_AD7N_28
#set_property PACKAGE_PIN K22      [get_ports "5N7488"] ;# Bank  28 VCCO - VCC1V8   - IO_L4P_T0U_N6_DBC_AD7P_28
#set_property IOSTANDARD  LVCMOSxx [get_ports "5N7488"] ;# Bank  28 VCCO - VCC1V8   - IO_L4P_T0U_N6_DBC_AD7P_28
#set_property PACKAGE_PIN J22      [get_ports "5N7489"] ;# Bank  28 VCCO - VCC1V8   - IO_L3N_T0L_N5_AD15N_28
#set_property IOSTANDARD  LVCMOSxx [get_ports "5N7489"] ;# Bank  28 VCCO - VCC1V8   - IO_L3N_T0L_N5_AD15N_28
#set_property PACKAGE_PIN J21      [get_ports "5N7484"] ;# Bank  28 VCCO - VCC1V8   - IO_L3P_T0L_N4_AD15P_28
#set_property IOSTANDARD  LVCMOSxx [get_ports "5N7484"] ;# Bank  28 VCCO - VCC1V8   - IO_L3P_T0L_N4_AD15P_28
#set_property PACKAGE_PIN K24      [get_ports "5N7485"] ;# Bank  28 VCCO - VCC1V8   - IO_L2N_T0L_N3_28
#set_property IOSTANDARD  LVCMOSxx [get_ports "5N7485"] ;# Bank  28 VCCO - VCC1V8   - IO_L2N_T0L_N3_28
#set_property PACKAGE_PIN L23      [get_ports "5N7476"] ;# Bank  28 VCCO - VCC1V8   - IO_L2P_T0L_N2_28
#set_property IOSTANDARD  LVCMOSxx [get_ports "5N7476"] ;# Bank  28 VCCO - VCC1V8   - IO_L2P_T0L_N2_28
#set_property PACKAGE_PIN L22      [get_ports "5N7477"] ;# Bank  28 VCCO - VCC1V8   - IO_L1N_T0L_N1_DBC_28
#set_property IOSTANDARD  LVCMOSxx [get_ports "5N7477"] ;# Bank  28 VCCO - VCC1V8   - IO_L1N_T0L_N1_DBC_28
#set_property PACKAGE_PIN L21      [get_ports "5N7472"] ;# Bank  28 VCCO - VCC1V8   - IO_L1P_T0L_N0_DBC_28
#set_property IOSTANDARD  LVCMOSxx [get_ports "5N7472"] ;# Bank  28 VCCO - VCC1V8   - IO_L1P_T0L_N0_DBC_28
#set_property PACKAGE_PIN A9       [get_ports "4N9784"] ;# Bank  68 VCCO - VADJ_FMC - IO_T3U_N12_68
#set_property IOSTANDARD  LVCMOSxx [get_ports "4N9784"] ;# Bank  68 VCCO - VADJ_FMC - IO_T3U_N12_68
#set_property PACKAGE_PIN G13      [get_ports "4N9781"] ;# Bank  68 VCCO - VADJ_FMC - IO_T2U_N12_68
#set_property IOSTANDARD  LVCMOSxx [get_ports "4N9781"] ;# Bank  68 VCCO - VADJ_FMC - IO_T2U_N12_68
#set_property PACKAGE_PIN G11      [get_ports "4N9820"] ;# Bank  68 VCCO - VADJ_FMC - IO_L13N_T2L_N1_GC_QBC_68
#set_property IOSTANDARD  LVCMOSxx [get_ports "4N9820"] ;# Bank  68 VCCO - VADJ_FMC - IO_L13N_T2L_N1_GC_QBC_68
#set_property PACKAGE_PIN H11      [get_ports "4N9817"] ;# Bank  68 VCCO - VADJ_FMC - IO_L13P_T2L_N0_GC_QBC_68
#set_property IOSTANDARD  LVCMOSxx [get_ports "4N9817"] ;# Bank  68 VCCO - VADJ_FMC - IO_L13P_T2L_N0_GC_QBC_68
#set_property PACKAGE_PIN G9       [get_ports "4N9823"] ;# Bank  68 VCCO - VADJ_FMC - IO_L11N_T1U_N9_GC_68
#set_property IOSTANDARD  LVCMOSxx [get_ports "4N9823"] ;# Bank  68 VCCO - VADJ_FMC - IO_L11N_T1U_N9_GC_68
#set_property PACKAGE_PIN H9       [get_ports "4N9826"] ;# Bank  68 VCCO - VADJ_FMC - IO_L11P_T1U_N8_GC_68
#set_property IOSTANDARD  LVCMOSxx [get_ports "4N9826"] ;# Bank  68 VCCO - VADJ_FMC - IO_L11P_T1U_N8_GC_68
#set_property PACKAGE_PIN D7       [get_ports "4N9778"] ;# Bank  68 VCCO - VADJ_FMC - IO_T1U_N12_68
#set_property IOSTANDARD  LVCMOSxx [get_ports "4N9778"] ;# Bank  68 VCCO - VADJ_FMC - IO_T1U_N12_68
#set_property PACKAGE_PIN K13      [get_ports "4N9759"] ;# Bank  68 VCCO - VADJ_FMC - IO_L6N_T0U_N11_AD6N_68
#set_property IOSTANDARD  LVCMOSxx [get_ports "4N9759"] ;# Bank  68 VCCO - VADJ_FMC - IO_L6N_T0U_N11_AD6N_68
#set_property PACKAGE_PIN L14      [get_ports "4N9760"] ;# Bank  68 VCCO - VADJ_FMC - IO_L6P_T0U_N10_AD6P_68
#set_property IOSTANDARD  LVCMOSxx [get_ports "4N9760"] ;# Bank  68 VCCO - VADJ_FMC - IO_L6P_T0U_N10_AD6P_68
#set_property PACKAGE_PIN J14      [get_ports "4N9755"] ;# Bank  68 VCCO - VADJ_FMC - IO_L5N_T0U_N9_AD14N_68
#set_property IOSTANDARD  LVCMOSxx [get_ports "4N9755"] ;# Bank  68 VCCO - VADJ_FMC - IO_L5N_T0U_N9_AD14N_68
#set_property PACKAGE_PIN K14      [get_ports "4N9756"] ;# Bank  68 VCCO - VADJ_FMC - IO_L5P_T0U_N8_AD14P_68
#set_property IOSTANDARD  LVCMOSxx [get_ports "4N9756"] ;# Bank  68 VCCO - VADJ_FMC - IO_L5P_T0U_N8_AD14P_68
#set_property PACKAGE_PIN J11      [get_ports "4N9771"] ;# Bank  68 VCCO - VADJ_FMC - IO_L4N_T0U_N7_DBC_AD7N_68
#set_property IOSTANDARD  LVCMOSxx [get_ports "4N9771"] ;# Bank  68 VCCO - VADJ_FMC - IO_L4N_T0U_N7_DBC_AD7N_68
#set_property PACKAGE_PIN K12      [get_ports "4N9772"] ;# Bank  68 VCCO - VADJ_FMC - IO_L4P_T0U_N6_DBC_AD7P_68
#set_property IOSTANDARD  LVCMOSxx [get_ports "4N9772"] ;# Bank  68 VCCO - VADJ_FMC - IO_L4P_T0U_N6_DBC_AD7P_68
#set_property PACKAGE_PIN L11      [get_ports "4N9767"] ;# Bank  68 VCCO - VADJ_FMC - IO_L3N_T0L_N5_AD15N_68
#set_property IOSTANDARD  LVCMOSxx [get_ports "4N9767"] ;# Bank  68 VCCO - VADJ_FMC - IO_L3N_T0L_N5_AD15N_68
#set_property PACKAGE_PIN L12      [get_ports "4N9768"] ;# Bank  68 VCCO - VADJ_FMC - IO_L3P_T0L_N4_AD15P_68
#set_property IOSTANDARD  LVCMOSxx [get_ports "4N9768"] ;# Bank  68 VCCO - VADJ_FMC - IO_L3P_T0L_N4_AD15P_68
#set_property PACKAGE_PIN J20      [get_ports "7N10213"] ;# Bank  67 VCCO - VADJ_FMC - IO_T3U_N12_67
#set_property IOSTANDARD  LVCMOSxx [get_ports "7N10213"] ;# Bank  67 VCCO - VADJ_FMC - IO_T3U_N12_67
#set_property PACKAGE_PIN J19      [get_ports "7N10210"] ;# Bank  67 VCCO - VADJ_FMC - IO_T2U_N12_67
#set_property IOSTANDARD  LVCMOSxx [get_ports "7N10210"] ;# Bank  67 VCCO - VADJ_FMC - IO_T2U_N12_67
#set_property PACKAGE_PIN D14      [get_ports "7N10403"] ;# Bank  67 VCCO - VADJ_FMC - IO_L11N_T1U_N9_GC_67
#set_property IOSTANDARD  LVCMOSxx [get_ports "7N10403"] ;# Bank  67 VCCO - VADJ_FMC - IO_L11N_T1U_N9_GC_67
#set_property PACKAGE_PIN D15      [get_ports "7N10406"] ;# Bank  67 VCCO - VADJ_FMC - IO_L11P_T1U_N8_GC_67
#set_property IOSTANDARD  LVCMOSxx [get_ports "7N10406"] ;# Bank  67 VCCO - VADJ_FMC - IO_L11P_T1U_N8_GC_67
#set_property PACKAGE_PIN F13      [get_ports "7N10612"] ;# Bank  67 VCCO - VADJ_FMC - IO_L10N_T1U_N7_QBC_AD4N_67
#set_property IOSTANDARD  LVCMOSxx [get_ports "7N10612"] ;# Bank  67 VCCO - VADJ_FMC - IO_L10N_T1U_N7_QBC_AD4N_67
#set_property PACKAGE_PIN G14      [get_ports "7N10614"] ;# Bank  67 VCCO - VADJ_FMC - IO_L10P_T1U_N6_QBC_AD4P_67
#set_property IOSTANDARD  LVCMOSxx [get_ports "7N10614"] ;# Bank  67 VCCO - VADJ_FMC - IO_L10P_T1U_N6_QBC_AD4P_67
#set_property PACKAGE_PIN E13      [get_ports "7N10207"] ;# Bank  67 VCCO - VADJ_FMC - IO_T1U_N12_67
#set_property IOSTANDARD  LVCMOSxx [get_ports "7N10207"] ;# Bank  67 VCCO - VADJ_FMC - IO_T1U_N12_67
#set_property PACKAGE_PIN C14      [get_ports "7N10204"] ;# Bank  67 VCCO - VADJ_FMC - IO_T0U_N12_VRP_67
#set_property IOSTANDARD  LVCMOSxx [get_ports "7N10204"] ;# Bank  67 VCCO - VADJ_FMC - IO_T0U_N12_VRP_67
#set_property PACKAGE_PIN B13      [get_ports "7N10197"] ;# Bank  67 VCCO - VADJ_FMC - IO_L4N_T0U_N7_DBC_AD7N_67
#set_property IOSTANDARD  LVCMOSxx [get_ports "7N10197"] ;# Bank  67 VCCO - VADJ_FMC - IO_L4N_T0U_N7_DBC_AD7N_67
#set_property PACKAGE_PIN B14      [get_ports "7N10198"] ;# Bank  67 VCCO - VADJ_FMC - IO_L4P_T0U_N6_DBC_AD7P_67
#set_property IOSTANDARD  LVCMOSxx [get_ports "7N10198"] ;# Bank  67 VCCO - VADJ_FMC - IO_L4P_T0U_N6_DBC_AD7P_67
#set_property PACKAGE_PIN A14      [get_ports "7N10193"] ;# Bank  67 VCCO - VADJ_FMC - IO_L3N_T0L_N5_AD15N_67
#set_property IOSTANDARD  LVCMOSxx [get_ports "7N10193"] ;# Bank  67 VCCO - VADJ_FMC - IO_L3N_T0L_N5_AD15N_67
#set_property PACKAGE_PIN A15      [get_ports "7N10194"] ;# Bank  67 VCCO - VADJ_FMC - IO_L3P_T0L_N4_AD15P_67
#set_property IOSTANDARD  LVCMOSxx [get_ports "7N10194"] ;# Bank  67 VCCO - VADJ_FMC - IO_L3P_T0L_N4_AD15P_67
#set_property PACKAGE_PIN B15      [get_ports "7N10185"] ;# Bank  67 VCCO - VADJ_FMC - IO_L2N_T0L_N3_67
#set_property IOSTANDARD  LVCMOSxx [get_ports "7N10185"] ;# Bank  67 VCCO - VADJ_FMC - IO_L2N_T0L_N3_67
#set_property PACKAGE_PIN B16      [get_ports "7N10186"] ;# Bank  67 VCCO - VADJ_FMC - IO_L2P_T0L_N2_67
#set_property IOSTANDARD  LVCMOSxx [get_ports "7N10186"] ;# Bank  67 VCCO - VADJ_FMC - IO_L2P_T0L_N2_67
#set_property PACKAGE_PIN A16      [get_ports "7N10181"] ;# Bank  67 VCCO - VADJ_FMC - IO_L1N_T0L_N1_DBC_67
#set_property IOSTANDARD  LVCMOSxx [get_ports "7N10181"] ;# Bank  67 VCCO - VADJ_FMC - IO_L1N_T0L_N1_DBC_67
#set_property PACKAGE_PIN A17      [get_ports "7N10182"] ;# Bank  67 VCCO - VADJ_FMC - IO_L1P_T0L_N0_DBC_67
#set_property IOSTANDARD  LVCMOSxx [get_ports "7N10182"] ;# Bank  67 VCCO - VADJ_FMC - IO_L1P_T0L_N0_DBC_67
#set_property PACKAGE_PIN AF10     [get_ports "7N10601"] ;# Bank  66 VCCO - VCC1V2   - IO_L19N_T3L_N1_DBC_AD9N_66
#set_property IOSTANDARD  LVCMOSxx [get_ports "7N10601"] ;# Bank  66 VCCO - VCC1V2   - IO_L19N_T3L_N1_DBC_AD9N_66
#set_property PACKAGE_PIN AC14     [get_ports "7N10603"] ;# Bank  66 VCCO - VCC1V2   - IO_T3U_N12_66
#set_property IOSTANDARD  LVCMOSxx [get_ports "7N10603"] ;# Bank  66 VCCO - VCC1V2   - IO_T3U_N12_66
#set_property PACKAGE_PIN AH8      [get_ports "7N10599"] ;# Bank  66 VCCO - VCC1V2   - IO_T2U_N12_66
#set_property IOSTANDARD  LVCMOSxx [get_ports "7N10599"] ;# Bank  66 VCCO - VCC1V2   - IO_T2U_N12_66
#set_property PACKAGE_PIN AJ12     [get_ports "7N10597"] ;# Bank  66 VCCO - VCC1V2   - IO_L13N_T2L_N1_GC_QBC_66
#set_property IOSTANDARD  LVCMOSxx [get_ports "7N10597"] ;# Bank  66 VCCO - VCC1V2   - IO_L13N_T2L_N1_GC_QBC_66
#set_property PACKAGE_PIN AL13     [get_ports "7N10593"] ;# Bank  66 VCCO - VCC1V2   - IO_L7N_T1L_N1_QBC_AD13N_66
#set_property IOSTANDARD  LVCMOSxx [get_ports "7N10593"] ;# Bank  66 VCCO - VCC1V2   - IO_L7N_T1L_N1_QBC_AD13N_66
#set_property PACKAGE_PIN AM13     [get_ports "7N10595"] ;# Bank  66 VCCO - VCC1V2   - IO_T1U_N12_66
#set_property IOSTANDARD  LVCMOSxx [get_ports "7N10595"] ;# Bank  66 VCCO - VCC1V2   - IO_T1U_N12_66
#set_property PACKAGE_PIN AP12     [get_ports "7N10591"] ;# Bank  66 VCCO - VCC1V2   - IO_L1N_T0L_N1_DBC_66
#set_property IOSTANDARD  LVCMOSxx [get_ports "7N10591"] ;# Bank  66 VCCO - VCC1V2   - IO_L1N_T0L_N1_DBC_66
#set_property PACKAGE_PIN AE19     [get_ports "6N12439"] ;# Bank  65 VCCO - VCC1V2   - IO_L19N_T3L_N1_DBC_AD9N_65
#set_property IOSTANDARD  LVCMOSxx [get_ports "6N12439"] ;# Bank  65 VCCO - VCC1V2   - IO_L19N_T3L_N1_DBC_AD9N_65
#set_property PACKAGE_PIN AE22     [get_ports "6N12442"] ;# Bank  65 VCCO - VCC1V2   - IO_T3U_N12_65
#set_property IOSTANDARD  LVCMOSxx [get_ports "6N12442"] ;# Bank  65 VCCO - VCC1V2   - IO_T3U_N12_65
#set_property PACKAGE_PIN AF20     [get_ports "6N12436"] ;# Bank  65 VCCO - VCC1V2   - IO_T2U_N12_65
#set_property IOSTANDARD  LVCMOSxx [get_ports "6N12436"] ;# Bank  65 VCCO - VCC1V2   - IO_T2U_N12_65
#set_property PACKAGE_PIN AH23     [get_ports "6N12433"] ;# Bank  65 VCCO - VCC1V2   - IO_L13N_T2L_N1_GC_QBC_65
#set_property IOSTANDARD  LVCMOSxx [get_ports "6N12433"] ;# Bank  65 VCCO - VCC1V2   - IO_L13N_T2L_N1_GC_QBC_65
#set_property PACKAGE_PIN AL21     [get_ports "6N12427"] ;# Bank  65 VCCO - VCC1V2   - IO_L7N_T1L_N1_QBC_AD13N_65
#set_property IOSTANDARD  LVCMOSxx [get_ports "6N12427"] ;# Bank  65 VCCO - VCC1V2   - IO_L7N_T1L_N1_QBC_AD13N_65
#set_property PACKAGE_PIN AH19     [get_ports "6N12430"] ;# Bank  65 VCCO - VCC1V2   - IO_T1U_N12_65
#set_property IOSTANDARD  LVCMOSxx [get_ports "6N12430"] ;# Bank  65 VCCO - VCC1V2   - IO_T1U_N12_65
#set_property PACKAGE_PIN AP20     [get_ports "6N12401"] ;# Bank  65 VCCO - VCC1V2   - IO_L1N_T0L_N1_DBC_65
#set_property IOSTANDARD  LVCMOSxx [get_ports "6N12401"] ;# Bank  65 VCCO - VCC1V2   - IO_L1N_T0L_N1_DBC_65
#set_property PACKAGE_PIN AA17     [get_ports "6N12707"] ;# Bank  64 VCCO - VCC1V2   - IO_T3U_N12_64
#set_property IOSTANDARD  LVCMOSxx [get_ports "6N12707"] ;# Bank  64 VCCO - VCC1V2   - IO_T3U_N12_64
#set_property PACKAGE_PIN AE17     [get_ports "6N12705"] ;# Bank  64 VCCO - VCC1V2   - IO_L15P_T2L_N4_AD11P_64
#set_property IOSTANDARD  LVCMOSxx [get_ports "6N12705"] ;# Bank  64 VCCO - VCC1V2   - IO_L15P_T2L_N4_AD11P_64
#set_property PACKAGE_PIN AP15     [get_ports "6N12788"] ;# Bank  64 VCCO - VCC1V2   - IO_L5N_T0U_N9_AD14N_64
#set_property IOSTANDARD  LVCMOSxx [get_ports "6N12788"] ;# Bank  64 VCCO - VCC1V2   - IO_L5N_T0U_N9_AD14N_64
#set_property PACKAGE_PIN AP16     [get_ports "6N12789"] ;# Bank  64 VCCO - VCC1V2   - IO_L5P_T0U_N8_AD14P_64
#set_property IOSTANDARD  LVCMOSxx [get_ports "6N12789"] ;# Bank  64 VCCO - VCC1V2   - IO_L5P_T0U_N8_AD14P_64
#set_property PACKAGE_PIN AN14     [get_ports "6N12782"] ;# Bank  64 VCCO - VCC1V2   - IO_L4N_T0U_N7_DBC_AD7N_64
#set_property IOSTANDARD  LVCMOSxx [get_ports "6N12782"] ;# Bank  64 VCCO - VCC1V2   - IO_L4N_T0U_N7_DBC_AD7N_64
#set_property PACKAGE_PIN AM14     [get_ports "6N12783"] ;# Bank  64 VCCO - VCC1V2   - IO_L4P_T0U_N6_DBC_AD7P_64
#set_property IOSTANDARD  LVCMOSxx [get_ports "6N12783"] ;# Bank  64 VCCO - VCC1V2   - IO_L4P_T0U_N6_DBC_AD7P_64
#set_property PACKAGE_PIN AN18     [get_ports "6N12780"] ;# Bank  64 VCCO - VCC1V2   - IO_L3N_T0L_N5_AD15N_64
#set_property IOSTANDARD  LVCMOSxx [get_ports "6N12780"] ;# Bank  64 VCCO - VCC1V2   - IO_L3N_T0L_N5_AD15N_64
#set_property PACKAGE_PIN AM18     [get_ports "6N12781"] ;# Bank  64 VCCO - VCC1V2   - IO_L3P_T0L_N4_AD15P_64
#set_property IOSTANDARD  LVCMOSxx [get_ports "6N12781"] ;# Bank  64 VCCO - VCC1V2   - IO_L3P_T0L_N4_AD15P_64
#set_property PACKAGE_PIN AP13     [get_ports "6N12774"] ;# Bank  64 VCCO - VCC1V2   - IO_L2N_T0L_N3_64
#set_property IOSTANDARD  LVCMOSxx [get_ports "6N12774"] ;# Bank  64 VCCO - VCC1V2   - IO_L2N_T0L_N3_64
#set_property PACKAGE_PIN AN13     [get_ports "6N12775"] ;# Bank  64 VCCO - VCC1V2   - IO_L2P_T0L_N2_64
#set_property IOSTANDARD  LVCMOSxx [get_ports "6N12775"] ;# Bank  64 VCCO - VCC1V2   - IO_L2P_T0L_N2_64
#set_property PACKAGE_PIN AP17     [get_ports "6N12772"] ;# Bank  64 VCCO - VCC1V2   - IO_L1N_T0L_N1_DBC_64
#set_property IOSTANDARD  LVCMOSxx [get_ports "6N12772"] ;# Bank  64 VCCO - VCC1V2   - IO_L1N_T0L_N1_DBC_64
#set_property PACKAGE_PIN AP18     [get_ports "6N12773"] ;# Bank  64 VCCO - VCC1V2   - IO_L1P_T0L_N0_DBC_64
#set_property IOSTANDARD  LVCMOSxxn [get_ports "6N12773"] ;# Bank  64 VCCO - VCC1V2   - IO_L1P_T0L_N0_DBC_64
# set_property PACKAGE_PIN C2       [get_ports "34N8749"] ;# Bank  88 VCCO - VCC3V3   - IO_L5N_HDGC_88
# set_property PACKAGE_PIN N9       [get_ports "34N8735"] ;# Bank  87 VCCO - VCC3V3   - IO_L2P_AD10P_87
# set_property IOSTANDARD  LVCMOS33 [get_ports "34N8735"] ;# Bank  87 VCCO - VCC3V3   - IO_L2P_AD10P_87
# set_property PACKAGE_PIN AN5      [get_ports "9N7450"] ;# Bank 223 - MGTHTXN0_223
# set_property PACKAGE_PIN AM3      [get_ports "9N7448"] ;# Bank 223 - MGTHTXN1_223
# set_property PACKAGE_PIN AL5      [get_ports "9N7446"] ;# Bank 223 - MGTHTXN2_223
# set_property PACKAGE_PIN AJ5      [get_ports "9N7444"] ;# Bank 223 - MGTHTXN3_223
# set_property PACKAGE_PIN AN6      [get_ports "9N7449"] ;# Bank 223 - MGTHTXP0_223
# set_property PACKAGE_PIN AM4      [get_ports "9N7447"] ;# Bank 223 - MGTHTXP1_223
# set_property PACKAGE_PIN AL6      [get_ports "9N7445"] ;# Bank 223 - MGTHTXP2_223
# set_property PACKAGE_PIN AJ6      [get_ports "9N7443"] ;# Bank 223 - MGTHTXP3_223
# set_property PACKAGE_PIN AD7      [get_ports "9N7442"] ;# Bank 223 - MGTREFCLK0N_223
# set_property PACKAGE_PIN AD8      [get_ports "9N7441"] ;# Bank 223 - MGTREFCLK0P_223
# set_property PACKAGE_PIN AC9      [get_ports "9N7455"] ;# Bank 223 - MGTREFCLK1N_223
# set_property PACKAGE_PIN AC10     [get_ports "9N7454"] ;# Bank 223 - MGTREFCLK1P_223
# set_property PACKAGE_PIN AH3      [get_ports "9N7412"] ;# Bank 224 - MGTHTXN0_224
# set_property PACKAGE_PIN AG5      [get_ports "9N7408"] ;# Bank 224 - MGTHTXN1_224
# set_property PACKAGE_PIN AE5      [get_ports "9N7404"] ;# Bank 224 - MGTHTXN2_224
# set_property PACKAGE_PIN AD3      [get_ports "9N7400"] ;# Bank 224 - MGTHTXN3_224
# set_property PACKAGE_PIN AH4      [get_ports "9N7411"] ;# Bank 224 - MGTHTXP0_224
# set_property PACKAGE_PIN AG6      [get_ports "9N7407"] ;# Bank 224 - MGTHTXP1_224
# set_property PACKAGE_PIN AE6      [get_ports "9N7403"] ;# Bank 224 - MGTHTXP2_224
# set_property PACKAGE_PIN AD4      [get_ports "9N7399"] ;# Bank 224 - MGTHTXP3_224
# set_property PACKAGE_PIN AB7      [get_ports "9N7396"] ;# Bank 224 - MGTREFCLK0N_224
# set_property PACKAGE_PIN AB8      [get_ports "9N7395"] ;# Bank 224 - MGTREFCLK0P_224
# set_property PACKAGE_PIN AA9      [get_ports "9N7386"] ;# Bank 224 - MGTREFCLK1N_224
# set_property PACKAGE_PIN AA10     [get_ports "9N7384"] ;# Bank 224 - MGTREFCLK1P_224
# set_property PACKAGE_PIN AC5      [get_ports "38N7665"] ;# Bank 225 - MGTHTXN0_225
# set_property PACKAGE_PIN AA5      [get_ports "38N7659"] ;# Bank 225 - MGTHTXN1_225
# set_property PACKAGE_PIN Y3       [get_ports "38N7653"] ;# Bank 225 - MGTHTXN2_225
# set_property PACKAGE_PIN W5       [get_ports "38N7647"] ;# Bank 225 - MGTHTXN3_225
# set_property PACKAGE_PIN AC6      [get_ports "38N7663"] ;# Bank 225 - MGTHTXP0_225
# set_property PACKAGE_PIN AA6      [get_ports "38N7657"] ;# Bank 225 - MGTHTXP1_225
# set_property PACKAGE_PIN Y4       [get_ports "38N7651"] ;# Bank 225 - MGTHTXP2_225
# set_property PACKAGE_PIN W6       [get_ports "38N7645"] ;# Bank 225 - MGTHTXP3_225
# set_property PACKAGE_PIN Y7       [get_ports "38N7641"] ;# Bank 225 - MGTREFCLK0N_225
# set_property PACKAGE_PIN Y8       [get_ports "38N7639"] ;# Bank 225 - MGTREFCLK0P_225
# set_property PACKAGE_PIN W9       [get_ports "38N7635"] ;# Bank 225 - MGTREFCLK1N_225
# set_property PACKAGE_PIN W10      [get_ports "38N7633"] ;# Bank 225 - MGTREFCLK1P_225
# set_property PACKAGE_PIN U5       [get_ports "38N7744"] ;# Bank 226 - MGTHTXN0_226
# set_property PACKAGE_PIN T3       [get_ports "38N7740"] ;# Bank 226 - MGTHTXN1_226
# set_property PACKAGE_PIN R5       [get_ports "38N8078"] ;# Bank 226 - MGTHTXN2_226
# set_property PACKAGE_PIN U6       [get_ports "38N7743"] ;# Bank 226 - MGTHTXP0_226
# set_property PACKAGE_PIN T4       [get_ports "38N7739"] ;# Bank 226 - MGTHTXP1_226
# set_property PACKAGE_PIN R6       [get_ports "38N8077"] ;# Bank 226 - MGTHTXP2_226
# set_property PACKAGE_PIN H3       [get_ports "38N8088"] ;# Bank 227 - MGTHTXN3_227
# set_property PACKAGE_PIN H4       [get_ports "38N8087"] ;# Bank 227 - MGTHTXP3_227

# ----------------------------------------------------------------------------
# UART
# ----------------------------------------------------------------------------
# set_property PACKAGE_PIN A20      [get_ports "UART2_TXD_FPGA_RXD"] ;# Bank  28 VCCO - VCC1V8   - IO_L21P_T3L_N4_AD8P_28
# set_property IOSTANDARD  LVCMOS18 [get_ports "UART2_TXD_FPGA_RXD"] ;# Bank  28 VCCO - VCC1V8   - IO_L21P_T3L_N4_AD8P_28
# set_property PACKAGE_PIN C19      [get_ports "UART2_RXD_FPGA_TXD"] ;# Bank  28 VCCO - VCC1V8   - IO_L20N_T3L_N3_AD1N_28
# set_property IOSTANDARD  LVCMOS18 [get_ports "UART2_RXD_FPGA_TXD"] ;# Bank  28 VCCO - VCC1V8   - IO_L20N_T3L_N3_AD1N_28
# set_property PACKAGE_PIN C18      [get_ports "UART2_RTS_B"] ;# Bank  28 VCCO - VCC1V8   - IO_L20P_T3L_N2_AD1P_28
# set_property IOSTANDARD  LVCMOS18 [get_ports "UART2_RTS_B"] ;# Bank  28 VCCO - VCC1V8   - IO_L20P_T3L_N2_AD1P_28
# set_property PACKAGE_PIN A19      [get_ports "UART2_CTS_B"] ;# Bank  28 VCCO - VCC1V8   - IO_L19N_T3L_N1_DBC_AD9N_28
# set_property IOSTANDARD  LVCMOS18 [get_ports "UART2_CTS_B"] ;# Bank  28 VCCO - VCC1V8   - IO_L19N_T3L_N1_DBC_AD9N_28

# ----------------------------------------------------------------------------
# SYSMON I2C
# ----------------------------------------------------------------------------

# ----------------------------------------------------------------------------
# PL Control / I2C
# ----------------------------------------------------------------------------
# set_property PACKAGE_PIN N12      [get_ports "PL_I2C1_SCL_LS"] ;# Bank  87 VCCO - VCC3V3   - IO_L1N_AD11N_87
# set_property IOSTANDARD  LVCMOS33 [get_ports "PL_I2C1_SCL_LS"] ;# Bank  87 VCCO - VCC3V3   - IO_L1N_AD11N_87
# set_property PACKAGE_PIN P12      [get_ports "PL_I2C1_SDA_LS"] ;# Bank  87 VCCO - VCC3V3   - IO_L1P_AD11P_87
# set_property IOSTANDARD  LVCMOS33 [get_ports "PL_I2C1_SDA_LS"] ;# Bank  87 VCCO - VCC3V3   - IO_L1P_AD11P_87

# ----------------------------------------------------------------------------
# GPIO
# ----------------------------------------------------------------------------
# set_property PACKAGE_PIN D5       [get_ports "GPIO_LED_0_LS"] ;# Bank  88 VCCO - VCC3V3   - IO_L11N_AD9N_88
# set_property IOSTANDARD  LVCMOS33 [get_ports "GPIO_LED_0_LS"] ;# Bank  88 VCCO - VCC3V3   - IO_L11N_AD9N_88
# set_property PACKAGE_PIN D6       [get_ports "GPIO_LED_1_LS"] ;# Bank  88 VCCO - VCC3V3   - IO_L11P_AD9P_88
# set_property IOSTANDARD  LVCMOS33 [get_ports "GPIO_LED_1_LS"] ;# Bank  88 VCCO - VCC3V3   - IO_L11P_AD9P_88
# set_property PACKAGE_PIN A5       [get_ports "GPIO_LED_2_LS"] ;# Bank  88 VCCO - VCC3V3   - IO_L10N_AD10N_88
# set_property IOSTANDARD  LVCMOS33 [get_ports "GPIO_LED_2_LS"] ;# Bank  88 VCCO - VCC3V3   - IO_L10N_AD10N_88
# set_property PACKAGE_PIN B5       [get_ports "GPIO_LED_3_LS"] ;# Bank  88 VCCO - VCC3V3   - IO_L10P_AD10P_88
# set_property IOSTANDARD  LVCMOS33 [get_ports "GPIO_LED_3_LS"] ;# Bank  88 VCCO - VCC3V3   - IO_L10P_AD10P_88
# set_property PACKAGE_PIN F4       [get_ports "GPIO_DIP_SW3"] ;# Bank  88 VCCO - VCC3V3   - IO_L9N_AD11N_88
# set_property IOSTANDARD  LVCMOS33 [get_ports "GPIO_DIP_SW3"] ;# Bank  88 VCCO - VCC3V3   - IO_L9N_AD11N_88
# set_property PACKAGE_PIN F5       [get_ports "GPIO_DIP_SW2"] ;# Bank  88 VCCO - VCC3V3   - IO_L9P_AD11P_88
# set_property IOSTANDARD  LVCMOS33 [get_ports "GPIO_DIP_SW2"] ;# Bank  88 VCCO - VCC3V3   - IO_L9P_AD11P_88
# set_property PACKAGE_PIN D4       [get_ports "GPIO_DIP_SW1"] ;# Bank  88 VCCO - VCC3V3   - IO_L8N_HDGC_88
# set_property IOSTANDARD  LVCMOS33 [get_ports "GPIO_DIP_SW1"] ;# Bank  88 VCCO - VCC3V3   - IO_L8N_HDGC_88
# set_property PACKAGE_PIN E4       [get_ports "GPIO_DIP_SW0"] ;# Bank  88 VCCO - VCC3V3   - IO_L8P_HDGC_88
# set_property IOSTANDARD  LVCMOS33 [get_ports "GPIO_DIP_SW0"] ;# Bank  88 VCCO - VCC3V3   - IO_L8P_HDGC_88
# set_property PACKAGE_PIN B4       [get_ports "GPIO_PB_SW0"] ;# Bank  88 VCCO - VCC3V3   - IO_L7N_HDGC_88
# set_property IOSTANDARD  LVCMOS33 [get_ports "GPIO_PB_SW0"] ;# Bank  88 VCCO - VCC3V3   - IO_L7N_HDGC_88
# set_property PACKAGE_PIN C4       [get_ports "GPIO_PB_SW1"] ;# Bank  88 VCCO - VCC3V3   - IO_L7P_HDGC_88
# set_property IOSTANDARD  LVCMOS33 [get_ports "GPIO_PB_SW1"] ;# Bank  88 VCCO - VCC3V3   - IO_L7P_HDGC_88
# set_property PACKAGE_PIN B3       [get_ports "GPIO_PB_SW2"] ;# Bank  88 VCCO - VCC3V3   - IO_L6N_HDGC_88
# set_property IOSTANDARD  LVCMOS33 [get_ports "GPIO_PB_SW2"] ;# Bank  88 VCCO - VCC3V3   - IO_L6N_HDGC_88
# set_property PACKAGE_PIN C3       [get_ports "GPIO_PB_SW3"] ;# Bank  88 VCCO - VCC3V3   - IO_L6P_HDGC_88
# set_property IOSTANDARD  LVCMOS33 [get_ports "GPIO_PB_SW3"] ;# Bank  88 VCCO - VCC3V3   - IO_L6P_HDGC_88

# ----------------------------------------------------------------------------
# CPU / Reset
# ----------------------------------------------------------------------------
# set_property PACKAGE_PIN M11      [get_ports "CPU_RESET"] ;# Bank  87 VCCO - VCC3V3   - IO_L4N_AD8N_87
# set_property IOSTANDARD  LVCMOS33 [get_ports "CPU_RESET"] ;# Bank  87 VCCO - VCC3V3   - IO_L4N_AD8N_87

# ----------------------------------------------------------------------------
# PMOD
# ----------------------------------------------------------------------------
# set_property PACKAGE_PIN G8       [get_ports "PMOD0_0"] ;# Bank  87 VCCO - VCC3V3   - IO_L12N_AD0N_87
# set_property IOSTANDARD  LVCMOS33 [get_ports "PMOD0_0"] ;# Bank  87 VCCO - VCC3V3   - IO_L12N_AD0N_87
# set_property PACKAGE_PIN H8       [get_ports "PMOD0_1"] ;# Bank  87 VCCO - VCC3V3   - IO_L12P_AD0P_87
# set_property IOSTANDARD  LVCMOS33 [get_ports "PMOD0_1"] ;# Bank  87 VCCO - VCC3V3   - IO_L12P_AD0P_87
# set_property PACKAGE_PIN G7       [get_ports "PMOD0_2"] ;# Bank  87 VCCO - VCC3V3   - IO_L11N_AD1N_87
# set_property IOSTANDARD  LVCMOS33 [get_ports "PMOD0_2"] ;# Bank  87 VCCO - VCC3V3   - IO_L11N_AD1N_87
# set_property PACKAGE_PIN H7       [get_ports "PMOD0_3"] ;# Bank  87 VCCO - VCC3V3   - IO_L11P_AD1P_87
# set_property IOSTANDARD  LVCMOS33 [get_ports "PMOD0_3"] ;# Bank  87 VCCO - VCC3V3   - IO_L11P_AD1P_87
# set_property PACKAGE_PIN G6       [get_ports "PMOD0_4"] ;# Bank  87 VCCO - VCC3V3   - IO_L10N_AD2N_87
# set_property IOSTANDARD  LVCMOS33 [get_ports "PMOD0_4"] ;# Bank  87 VCCO - VCC3V3   - IO_L10N_AD2N_87
# set_property PACKAGE_PIN H6       [get_ports "PMOD0_5"] ;# Bank  87 VCCO - VCC3V3   - IO_L10P_AD2P_87
# set_property IOSTANDARD  LVCMOS33 [get_ports "PMOD0_5"] ;# Bank  87 VCCO - VCC3V3   - IO_L10P_AD2P_87
# set_property PACKAGE_PIN J6       [get_ports "PMOD0_6"] ;# Bank  87 VCCO - VCC3V3   - IO_L9N_AD3N_87
# set_property IOSTANDARD  LVCMOS33 [get_ports "PMOD0_6"] ;# Bank  87 VCCO - VCC3V3   - IO_L9N_AD3N_87
# set_property PACKAGE_PIN J7       [get_ports "PMOD0_7"] ;# Bank  87 VCCO - VCC3V3   - IO_L9P_AD3P_87
# set_property IOSTANDARD  LVCMOS33 [get_ports "PMOD0_7"] ;# Bank  87 VCCO - VCC3V3   - IO_L9P_AD3P_87
# set_property PACKAGE_PIN J9       [get_ports "PMOD1_0"] ;# Bank  87 VCCO - VCC3V3   - IO_L8N_HDGC_AD4N_87
# set_property IOSTANDARD  LVCMOS33 [get_ports "PMOD1_0"] ;# Bank  87 VCCO - VCC3V3   - IO_L8N_HDGC_AD4N_87
# set_property PACKAGE_PIN K9       [get_ports "PMOD1_1"] ;# Bank  87 VCCO - VCC3V3   - IO_L8P_HDGC_AD4P_87
# set_property IOSTANDARD  LVCMOS33 [get_ports "PMOD1_1"] ;# Bank  87 VCCO - VCC3V3   - IO_L8P_HDGC_AD4P_87
# set_property PACKAGE_PIN K8       [get_ports "PMOD1_2"] ;# Bank  87 VCCO - VCC3V3   - IO_L7N_HDGC_AD5N_87
# set_property IOSTANDARD  LVCMOS33 [get_ports "PMOD1_2"] ;# Bank  87 VCCO - VCC3V3   - IO_L7N_HDGC_AD5N_87
# set_property PACKAGE_PIN L8       [get_ports "PMOD1_3"] ;# Bank  87 VCCO - VCC3V3   - IO_L7P_HDGC_AD5P_87
# set_property IOSTANDARD  LVCMOS33 [get_ports "PMOD1_3"] ;# Bank  87 VCCO - VCC3V3   - IO_L7P_HDGC_AD5P_87
# set_property PACKAGE_PIN L10      [get_ports "PMOD1_4"] ;# Bank  87 VCCO - VCC3V3   - IO_L6N_HDGC_AD6N_87
# set_property IOSTANDARD  LVCMOS33 [get_ports "PMOD1_4"] ;# Bank  87 VCCO - VCC3V3   - IO_L6N_HDGC_AD6N_87
# set_property PACKAGE_PIN M10      [get_ports "PMOD1_5"] ;# Bank  87 VCCO - VCC3V3   - IO_L6P_HDGC_AD6P_87
# set_property IOSTANDARD  LVCMOS33 [get_ports "PMOD1_5"] ;# Bank  87 VCCO - VCC3V3   - IO_L6P_HDGC_AD6P_87
# set_property PACKAGE_PIN M8       [get_ports "PMOD1_6"] ;# Bank  87 VCCO - VCC3V3   - IO_L5N_HDGC_AD7N_87
# set_property IOSTANDARD  LVCMOS33 [get_ports "PMOD1_6"] ;# Bank  87 VCCO - VCC3V3   - IO_L5N_HDGC_AD7N_87
# set_property PACKAGE_PIN M9       [get_ports "PMOD1_7"] ;# Bank  87 VCCO - VCC3V3   - IO_L5P_HDGC_AD7P_87
# set_property IOSTANDARD  LVCMOS33 [get_ports "PMOD1_7"] ;# Bank  87 VCCO - VCC3V3   - IO_L5P_HDGC_AD7P_87

# ----------------------------------------------------------------------------
# Clock Signals
# ----------------------------------------------------------------------------
# set_property PACKAGE_PIN E23      [get_ports "CLK_125_N"] ;# Bank  28 VCCO - VCC1V8   - IO_L13N_T2L_N1_GC_QBC_28
# set_property IOSTANDARD  LVDS     [get_ports "CLK_125_N"] ;# Bank  28 VCCO - VCC1V8   - IO_L13N_T2L_N1_GC_QBC_28
# set_property PACKAGE_PIN F23      [get_ports "CLK_125_P"] ;# Bank  28 VCCO - VCC1V8   - IO_L13P_T2L_N0_GC_QBC_28
# set_property IOSTANDARD  LVDS     [get_ports "CLK_125_P"] ;# Bank  28 VCCO - VCC1V8   - IO_L13P_T2L_N0_GC_QBC_28
# set_property PACKAGE_PIN AH17     [get_ports "CLK_300_N"] ;# Bank  64 VCCO - VCC1V2   - IO_L13N_T2L_N1_GC_QBC_64
# set_property IOSTANDARD  DIFF_SSTL12 [get_ports "CLK_300_N"] ;# Bank  64 VCCO - VCC1V2   - IO_L13N_T2L_N1_GC_QBC_64

# ----------------------------------------------------------------------------
# HDMI
# ----------------------------------------------------------------------------
# set_property PACKAGE_PIN F21      [get_ports "HDMI_TX_LVDS_OUT_N"] ;# Bank  28 VCCO - VCC1V8   - IO_L12N_T1U_N11_GC_28
# set_property IOSTANDARD  LVDS     [get_ports "HDMI_TX_LVDS_OUT_N"] ;# Bank  28 VCCO - VCC1V8   - IO_L12N_T1U_N11_GC_28
# set_property PACKAGE_PIN G21      [get_ports "HDMI_TX_LVDS_OUT_P"] ;# Bank  28 VCCO - VCC1V8   - IO_L12P_T1U_N10_GC_28
# set_property IOSTANDARD  LVDS     [get_ports "HDMI_TX_LVDS_OUT_P"] ;# Bank  28 VCCO - VCC1V8   - IO_L12P_T1U_N10_GC_28
# set_property PACKAGE_PIN E22      [get_ports "HDMI_REC_CLOCK_N"] ;# Bank  28 VCCO - VCC1V8   - IO_L11N_T1U_N9_GC_28
# set_property IOSTANDARD  LVDS     [get_ports "HDMI_REC_CLOCK_N"] ;# Bank  28 VCCO - VCC1V8   - IO_L11N_T1U_N9_GC_28
# set_property PACKAGE_PIN F22      [get_ports "HDMI_REC_CLOCK_P"] ;# Bank  28 VCCO - VCC1V8   - IO_L11P_T1U_N8_GC_28
# set_property IOSTANDARD  LVDS     [get_ports "HDMI_REC_CLOCK_P"] ;# Bank  28 VCCO - VCC1V8   - IO_L11P_T1U_N8_GC_28
# set_property PACKAGE_PIN E5       [get_ports "HDMI_RX_PWR_DET"] ;# Bank  88 VCCO - VCC3V3   - IO_L12N_AD8N_88
# set_property IOSTANDARD  LVCMOS33 [get_ports "HDMI_RX_PWR_DET"] ;# Bank  88 VCCO - VCC3V3   - IO_L12N_AD8N_88
# set_property PACKAGE_PIN F6       [get_ports "HDMI_RX_HPD"] ;# Bank  88 VCCO - VCC3V3   - IO_L12P_AD8P_88
# set_property IOSTANDARD  LVCMOS33 [get_ports "HDMI_RX_HPD"] ;# Bank  88 VCCO - VCC3V3   - IO_L12P_AD8P_88
# set_property IOSTANDARD  LVCMOS33 [get_ports "HDMI_RX_LS_OE"] ;# Bank  88 VCCO - VCC3V3   - IO_L5N_HDGC_88
# set_property PACKAGE_PIN D2       [get_ports "HDMI_RX_SNK_SCL"] ;# Bank  88 VCCO - VCC3V3   - IO_L5P_HDGC_88
# set_property IOSTANDARD  LVCMOS33 [get_ports "HDMI_RX_SNK_SCL"] ;# Bank  88 VCCO - VCC3V3   - IO_L5P_HDGC_88
# set_property PACKAGE_PIN E2       [get_ports "HDMI_RX_SNK_SDA"] ;# Bank  88 VCCO - VCC3V3   - IO_L4N_AD12N_88
# set_property IOSTANDARD  LVCMOS33 [get_ports "HDMI_RX_SNK_SDA"] ;# Bank  88 VCCO - VCC3V3   - IO_L4N_AD12N_88
# set_property PACKAGE_PIN E3       [get_ports "HDMI_TX_HPD"] ;# Bank  88 VCCO - VCC3V3   - IO_L4P_AD12P_88
# set_property IOSTANDARD  LVCMOS33 [get_ports "HDMI_TX_HPD"] ;# Bank  88 VCCO - VCC3V3   - IO_L4P_AD12P_88
# set_property PACKAGE_PIN A2       [get_ports "HDMI_TX_EN"] ;# Bank  88 VCCO - VCC3V3   - IO_L3N_AD13N_88
# set_property IOSTANDARD  LVCMOS33 [get_ports "HDMI_TX_EN"] ;# Bank  88 VCCO - VCC3V3   - IO_L3N_AD13N_88
# set_property PACKAGE_PIN A3       [get_ports "HDMI_TX_CEC"] ;# Bank  88 VCCO - VCC3V3   - IO_L3P_AD13P_88
# set_property IOSTANDARD  LVCMOS33 [get_ports "HDMI_TX_CEC"] ;# Bank  88 VCCO - VCC3V3   - IO_L3P_AD13P_88
# set_property PACKAGE_PIN B1       [get_ports "HDMI_TX_SRC_SCL"] ;# Bank  88 VCCO - VCC3V3   - IO_L2N_AD14N_88
# set_property IOSTANDARD  LVCMOS33 [get_ports "HDMI_TX_SRC_SCL"] ;# Bank  88 VCCO - VCC3V3   - IO_L2N_AD14N_88
# set_property PACKAGE_PIN C1       [get_ports "HDMI_TX_SRC_SDA"] ;# Bank  88 VCCO - VCC3V3   - IO_L2P_AD14P_88
# set_property IOSTANDARD  LVCMOS33 [get_ports "HDMI_TX_SRC_SDA"] ;# Bank  88 VCCO - VCC3V3   - IO_L2P_AD14P_88
# set_property PACKAGE_PIN D1       [get_ports "HDMI_CTL_SCL"] ;# Bank  88 VCCO - VCC3V3   - IO_L1N_AD15N_88
# set_property IOSTANDARD  LVCMOS33 [get_ports "HDMI_CTL_SCL"] ;# Bank  88 VCCO - VCC3V3   - IO_L1N_AD15N_88
# set_property PACKAGE_PIN E1       [get_ports "HDMI_CTL_SDA"] ;# Bank  88 VCCO - VCC3V3   - IO_L1P_AD15P_88
# set_property IOSTANDARD  LVCMOS33 [get_ports "HDMI_CTL_SDA"] ;# Bank  88 VCCO - VCC3V3   - IO_L1P_AD15P_88
# set_property PACKAGE_PIN N11      [get_ports "HDMI_8T49N241_LOL"] ;# Bank  87 VCCO - VCC3V3   - IO_L4P_AD8P_87
# set_property IOSTANDARD  LVCMOS33 [get_ports "HDMI_8T49N241_LOL"] ;# Bank  87 VCCO - VCC3V3   - IO_L4P_AD8P_87
# set_property PACKAGE_PIN M12      [get_ports "HDMI_8T49N241_RST"] ;# Bank  87 VCCO - VCC3V3   - IO_L3N_AD9N_87
# set_property IOSTANDARD  LVCMOS33 [get_ports "HDMI_8T49N241_RST"] ;# Bank  87 VCCO - VCC3V3   - IO_L3N_AD9N_87
# set_property PACKAGE_PIN N13      [get_ports "HDMI_TX_LS_OE"] ;# Bank  87 VCCO - VCC3V3   - IO_L3P_AD9P_87
# set_property IOSTANDARD  LVCMOS33 [get_ports "HDMI_TX_LS_OE"] ;# Bank  87 VCCO - VCC3V3   - IO_L3P_AD9P_87
# set_property PACKAGE_PIN N8       [get_ports "HDMI_TX_CT_HPD"] ;# Bank  87 VCCO - VCC3V3   - IO_L2N_AD10N_87
# set_property IOSTANDARD  LVCMOS33 [get_ports "HDMI_TX_CT_HPD"] ;# Bank  87 VCCO - VCC3V3   - IO_L2N_AD10N_87
# set_property PACKAGE_PIN U9       [get_ports "HDMI_DRU_CLOCK_C_N"] ;# Bank 226 - MGTREFCLK1N_226
# set_property PACKAGE_PIN U10      [get_ports "HDMI_DRU_CLOCK_C_P"] ;# Bank 226 - MGTREFCLK1P_226
# set_property PACKAGE_PIN N1       [get_ports "HDMI_RX0_C_N"] ;# Bank 227 - MGTHRXN0_227
# set_property PACKAGE_PIN L1       [get_ports "HDMI_RX1_C_N"] ;# Bank 227 - MGTHRXN1_227
# set_property PACKAGE_PIN J1       [get_ports "HDMI_RX2_C_N"] ;# Bank 227 - MGTHRXN2_227
# set_property PACKAGE_PIN N2       [get_ports "HDMI_RX0_C_P"] ;# Bank 227 - MGTHRXP0_227
# set_property PACKAGE_PIN L2       [get_ports "HDMI_RX1_C_P"] ;# Bank 227 - MGTHRXP1_227
# set_property PACKAGE_PIN J2       [get_ports "HDMI_RX2_C_P"] ;# Bank 227 - MGTHRXP2_227
# set_property PACKAGE_PIN M3       [get_ports "HDMI_TX0_N"] ;# Bank 227 - MGTHTXN0_227
# set_property PACKAGE_PIN L5       [get_ports "HDMI_TX1_N"] ;# Bank 227 - MGTHTXN1_227
# set_property PACKAGE_PIN K3       [get_ports "HDMI_TX2_N"] ;# Bank 227 - MGTHTXN2_227
# set_property PACKAGE_PIN M4       [get_ports "HDMI_TX0_P"] ;# Bank 227 - MGTHTXP0_227
# set_property PACKAGE_PIN L6       [get_ports "HDMI_TX1_P"] ;# Bank 227 - MGTHTXP1_227
# set_property PACKAGE_PIN K4       [get_ports "HDMI_TX2_P"] ;# Bank 227 - MGTHTXP2_227
# set_property PACKAGE_PIN T7       [get_ports "HDMI_8T49N241_OUT_C_N"] ;# Bank 227 - MGTREFCLK0N_227
# set_property PACKAGE_PIN T8       [get_ports "HDMI_8T49N241_OUT_C_P"] ;# Bank 227 - MGTREFCLK0P_227
# set_property PACKAGE_PIN R9       [get_ports "HDMI_RX_CLK_C_N"] ;# Bank 227 - MGTREFCLK1N_227
# set_property PACKAGE_PIN R10      [get_ports "HDMI_RX_CLK_C_P"] ;# Bank 227 - MGTREFCLK1P_227

# ----------------------------------------------------------------------------
# FMC
# ----------------------------------------------------------------------------
# set_property PACKAGE_PIN A11      [get_ports "FMC_LPC_LA23_N"] ;# Bank  68 VCCO - VADJ_FMC - IO_L24N_T3U_N11_68
# set_property IOSTANDARD  LVDS     [get_ports "FMC_LPC_LA23_N"] ;# Bank  68 VCCO - VADJ_FMC - IO_L24N_T3U_N11_68
# set_property PACKAGE_PIN B11      [get_ports "FMC_LPC_LA23_P"] ;# Bank  68 VCCO - VADJ_FMC - IO_L24P_T3U_N10_68
# set_property IOSTANDARD  LVDS     [get_ports "FMC_LPC_LA23_P"] ;# Bank  68 VCCO - VADJ_FMC - IO_L24P_T3U_N10_68
# set_property PACKAGE_PIN A7       [get_ports "FMC_LPC_LA27_N"] ;# Bank  68 VCCO - VADJ_FMC - IO_L23N_T3U_N9_68
# set_property IOSTANDARD  LVDS     [get_ports "FMC_LPC_LA27_N"] ;# Bank  68 VCCO - VADJ_FMC - IO_L23N_T3U_N9_68
# set_property PACKAGE_PIN A8       [get_ports "FMC_LPC_LA27_P"] ;# Bank  68 VCCO - VADJ_FMC - IO_L23P_T3U_N8_68
# set_property IOSTANDARD  LVDS     [get_ports "FMC_LPC_LA27_P"] ;# Bank  68 VCCO - VADJ_FMC - IO_L23P_T3U_N8_68
# set_property PACKAGE_PIN A10      [get_ports "FMC_LPC_LA21_N"] ;# Bank  68 VCCO - VADJ_FMC - IO_L22N_T3U_N7_DBC_AD0N_68
# set_property IOSTANDARD  LVDS     [get_ports "FMC_LPC_LA21_N"] ;# Bank  68 VCCO - VADJ_FMC - IO_L22N_T3U_N7_DBC_AD0N_68
# set_property PACKAGE_PIN B10      [get_ports "FMC_LPC_LA21_P"] ;# Bank  68 VCCO - VADJ_FMC - IO_L22P_T3U_N6_DBC_AD0P_68
# set_property IOSTANDARD  LVDS     [get_ports "FMC_LPC_LA21_P"] ;# Bank  68 VCCO - VADJ_FMC - IO_L22P_T3U_N6_DBC_AD0P_68
# set_property PACKAGE_PIN A6       [get_ports "FMC_LPC_LA24_N"] ;# Bank  68 VCCO - VADJ_FMC - IO_L21N_T3L_N5_AD8N_68
# set_property IOSTANDARD  LVDS     [get_ports "FMC_LPC_LA24_N"] ;# Bank  68 VCCO - VADJ_FMC - IO_L21N_T3L_N5_AD8N_68
# set_property PACKAGE_PIN B6       [get_ports "FMC_LPC_LA24_P"] ;# Bank  68 VCCO - VADJ_FMC - IO_L21P_T3L_N4_AD8P_68
# set_property IOSTANDARD  LVDS     [get_ports "FMC_LPC_LA24_P"] ;# Bank  68 VCCO - VADJ_FMC - IO_L21P_T3L_N4_AD8P_68
# set_property PACKAGE_PIN B8       [get_ports "FMC_LPC_LA26_N"] ;# Bank  68 VCCO - VADJ_FMC - IO_L20N_T3L_N3_AD1N_68
# set_property IOSTANDARD  LVDS     [get_ports "FMC_LPC_LA26_N"] ;# Bank  68 VCCO - VADJ_FMC - IO_L20N_T3L_N3_AD1N_68
# set_property PACKAGE_PIN B9       [get_ports "FMC_LPC_LA26_P"] ;# Bank  68 VCCO - VADJ_FMC - IO_L20P_T3L_N2_AD1P_68
# set_property IOSTANDARD  LVDS     [get_ports "FMC_LPC_LA26_P"] ;# Bank  68 VCCO - VADJ_FMC - IO_L20P_T3L_N2_AD1P_68
# set_property PACKAGE_PIN C6       [get_ports "FMC_LPC_LA25_N"] ;# Bank  68 VCCO - VADJ_FMC - IO_L19N_T3L_N1_DBC_AD9N_68
# set_property IOSTANDARD  LVDS     [get_ports "FMC_LPC_LA25_N"] ;# Bank  68 VCCO - VADJ_FMC - IO_L19N_T3L_N1_DBC_AD9N_68
# set_property PACKAGE_PIN C7       [get_ports "FMC_LPC_LA25_P"] ;# Bank  68 VCCO - VADJ_FMC - IO_L19P_T3L_N0_DBC_AD9P_68
# set_property IOSTANDARD  LVDS     [get_ports "FMC_LPC_LA25_P"] ;# Bank  68 VCCO - VADJ_FMC - IO_L19P_T3L_N0_DBC_AD9P_68
# set_property PACKAGE_PIN C11      [get_ports "FMC_LPC_LA19_N"] ;# Bank  68 VCCO - VADJ_FMC - IO_L18N_T2U_N11_AD2N_68
# set_property IOSTANDARD  LVDS     [get_ports "FMC_LPC_LA19_N"] ;# Bank  68 VCCO - VADJ_FMC - IO_L18N_T2U_N11_AD2N_68
# set_property PACKAGE_PIN D12      [get_ports "FMC_LPC_LA19_P"] ;# Bank  68 VCCO - VADJ_FMC - IO_L18P_T2U_N10_AD2P_68
# set_property IOSTANDARD  LVDS     [get_ports "FMC_LPC_LA19_P"] ;# Bank  68 VCCO - VADJ_FMC - IO_L18P_T2U_N10_AD2P_68
# set_property PACKAGE_PIN E12      [get_ports "FMC_LPC_LA20_N"] ;# Bank  68 VCCO - VADJ_FMC - IO_L17N_T2U_N9_AD10N_68
# set_property IOSTANDARD  LVDS     [get_ports "FMC_LPC_LA20_N"] ;# Bank  68 VCCO - VADJ_FMC - IO_L17N_T2U_N9_AD10N_68
# set_property PACKAGE_PIN F12      [get_ports "FMC_LPC_LA20_P"] ;# Bank  68 VCCO - VADJ_FMC - IO_L17P_T2U_N8_AD10P_68
# set_property IOSTANDARD  LVDS     [get_ports "FMC_LPC_LA20_P"] ;# Bank  68 VCCO - VADJ_FMC - IO_L17P_T2U_N8_AD10P_68
# set_property PACKAGE_PIN D10      [get_ports "FMC_LPC_LA18_CC_N"] ;# Bank  68 VCCO - VADJ_FMC - IO_L16N_T2U_N7_QBC_AD3N_68
# set_property IOSTANDARD  LVDS     [get_ports "FMC_LPC_LA18_CC_N"] ;# Bank  68 VCCO - VADJ_FMC - IO_L16N_T2U_N7_QBC_AD3N_68
# set_property PACKAGE_PIN D11      [get_ports "FMC_LPC_LA18_CC_P"] ;# Bank  68 VCCO - VADJ_FMC - IO_L16P_T2U_N6_QBC_AD3P_68
# set_property IOSTANDARD  LVDS     [get_ports "FMC_LPC_LA18_CC_P"] ;# Bank  68 VCCO - VADJ_FMC - IO_L16P_T2U_N6_QBC_AD3P_68
# set_property PACKAGE_PIN H12      [get_ports "FMC_LPC_LA22_N"] ;# Bank  68 VCCO - VADJ_FMC - IO_L15N_T2L_N5_AD11N_68
# set_property IOSTANDARD  LVDS     [get_ports "FMC_LPC_LA22_N"] ;# Bank  68 VCCO - VADJ_FMC - IO_L15N_T2L_N5_AD11N_68
# set_property PACKAGE_PIN H13      [get_ports "FMC_LPC_LA22_P"] ;# Bank  68 VCCO - VADJ_FMC - IO_L15P_T2L_N4_AD11P_68
# set_property IOSTANDARD  LVDS     [get_ports "FMC_LPC_LA22_P"] ;# Bank  68 VCCO - VADJ_FMC - IO_L15P_T2L_N4_AD11P_68
# set_property PACKAGE_PIN E10      [get_ports "FMC_LPC_LA17_CC_N"] ;# Bank  68 VCCO - VADJ_FMC - IO_L14N_T2L_N3_GC_68
# set_property IOSTANDARD  LVDS     [get_ports "FMC_LPC_LA17_CC_N"] ;# Bank  68 VCCO - VADJ_FMC - IO_L14N_T2L_N3_GC_68
# set_property PACKAGE_PIN F11      [get_ports "FMC_LPC_LA17_CC_P"] ;# Bank  68 VCCO - VADJ_FMC - IO_L14P_T2L_N2_GC_68
# set_property IOSTANDARD  LVDS     [get_ports "FMC_LPC_LA17_CC_P"] ;# Bank  68 VCCO - VADJ_FMC - IO_L14P_T2L_N2_GC_68
# set_property PACKAGE_PIN F10      [get_ports "FMC_LPC_CLK1_M2C_N"] ;# Bank  68 VCCO - VADJ_FMC - IO_L12N_T1U_N11_GC_68
# set_property IOSTANDARD  LVDS     [get_ports "FMC_LPC_CLK1_M2C_N"] ;# Bank  68 VCCO - VADJ_FMC - IO_L12N_T1U_N11_GC_68
# set_property PACKAGE_PIN G10      [get_ports "FMC_LPC_CLK1_M2C_P"] ;# Bank  68 VCCO - VADJ_FMC - IO_L12P_T1U_N10_GC_68
# set_property IOSTANDARD  LVDS     [get_ports "FMC_LPC_CLK1_M2C_P"] ;# Bank  68 VCCO - VADJ_FMC - IO_L12P_T1U_N10_GC_68
# set_property PACKAGE_PIN D9       [get_ports "FMC_LPC_LA30_N"] ;# Bank  68 VCCO - VADJ_FMC - IO_L10N_T1U_N7_QBC_AD4N_68
# set_property IOSTANDARD  LVDS     [get_ports "FMC_LPC_LA30_N"] ;# Bank  68 VCCO - VADJ_FMC - IO_L10N_T1U_N7_QBC_AD4N_68
# set_property PACKAGE_PIN E9       [get_ports "FMC_LPC_LA30_P"] ;# Bank  68 VCCO - VADJ_FMC - IO_L10P_T1U_N6_QBC_AD4P_68
# set_property IOSTANDARD  LVDS     [get_ports "FMC_LPC_LA30_P"] ;# Bank  68 VCCO - VADJ_FMC - IO_L10P_T1U_N6_QBC_AD4P_68
# set_property PACKAGE_PIN E8       [get_ports "FMC_LPC_LA32_N"] ;# Bank  68 VCCO - VADJ_FMC - IO_L9N_T1L_N5_AD12N_68
# set_property IOSTANDARD  LVDS     [get_ports "FMC_LPC_LA32_N"] ;# Bank  68 VCCO - VADJ_FMC - IO_L9N_T1L_N5_AD12N_68
# set_property PACKAGE_PIN F8       [get_ports "FMC_LPC_LA32_P"] ;# Bank  68 VCCO - VADJ_FMC - IO_L9P_T1L_N4_AD12P_68
# set_property IOSTANDARD  LVDS     [get_ports "FMC_LPC_LA32_P"] ;# Bank  68 VCCO - VADJ_FMC - IO_L9P_T1L_N4_AD12P_68
# set_property PACKAGE_PIN C8       [get_ports "FMC_LPC_LA33_N"] ;# Bank  68 VCCO - VADJ_FMC - IO_L8N_T1L_N3_AD5N_68
# set_property IOSTANDARD  LVDS     [get_ports "FMC_LPC_LA33_N"] ;# Bank  68 VCCO - VADJ_FMC - IO_L8N_T1L_N3_AD5N_68
# set_property PACKAGE_PIN C9       [get_ports "FMC_LPC_LA33_P"] ;# Bank  68 VCCO - VADJ_FMC - IO_L8P_T1L_N2_AD5P_68
# set_property IOSTANDARD  LVDS     [get_ports "FMC_LPC_LA33_P"] ;# Bank  68 VCCO - VADJ_FMC - IO_L8P_T1L_N2_AD5P_68
# set_property PACKAGE_PIN E7       [get_ports "FMC_LPC_LA31_N"] ;# Bank  68 VCCO - VADJ_FMC - IO_L7N_T1L_N1_QBC_AD13N_68
# set_property IOSTANDARD  LVDS     [get_ports "FMC_LPC_LA31_N"] ;# Bank  68 VCCO - VADJ_FMC - IO_L7N_T1L_N1_QBC_AD13N_68
# set_property PACKAGE_PIN F7       [get_ports "FMC_LPC_LA31_P"] ;# Bank  68 VCCO - VADJ_FMC - IO_L7P_T1L_N0_QBC_AD13P_68
# set_property IOSTANDARD  LVDS     [get_ports "FMC_LPC_LA31_P"] ;# Bank  68 VCCO - VADJ_FMC - IO_L7P_T1L_N0_QBC_AD13P_68
# set_property PACKAGE_PIN J10      [get_ports "FMC_LPC_LA29_N"] ;# Bank  68 VCCO - VADJ_FMC - IO_L2N_T0L_N3_68
# set_property IOSTANDARD  LVDS     [get_ports "FMC_LPC_LA29_N"] ;# Bank  68 VCCO - VADJ_FMC - IO_L2N_T0L_N3_68
# set_property PACKAGE_PIN K10      [get_ports "FMC_LPC_LA29_P"] ;# Bank  68 VCCO - VADJ_FMC - IO_L2P_T0L_N2_68
# set_property IOSTANDARD  LVDS     [get_ports "FMC_LPC_LA29_P"] ;# Bank  68 VCCO - VADJ_FMC - IO_L2P_T0L_N2_68
# set_property PACKAGE_PIN L13      [get_ports "FMC_LPC_LA28_N"] ;# Bank  68 VCCO - VADJ_FMC - IO_L1N_T0L_N1_DBC_68
# set_property IOSTANDARD  LVDS     [get_ports "FMC_LPC_LA28_N"] ;# Bank  68 VCCO - VADJ_FMC - IO_L1N_T0L_N1_DBC_68
# set_property PACKAGE_PIN M13      [get_ports "FMC_LPC_LA28_P"] ;# Bank  68 VCCO - VADJ_FMC - IO_L1P_T0L_N0_DBC_68
# set_property IOSTANDARD  LVDS     [get_ports "FMC_LPC_LA28_P"] ;# Bank  68 VCCO - VADJ_FMC - IO_L1P_T0L_N0_DBC_68
# set_property PACKAGE_PIN L16      [get_ports "FMC_LPC_LA04_N"] ;# Bank  67 VCCO - VADJ_FMC - IO_L24N_T3U_N11_67
# set_property IOSTANDARD  LVDS     [get_ports "FMC_LPC_LA04_N"] ;# Bank  67 VCCO - VADJ_FMC - IO_L24N_T3U_N11_67
# set_property PACKAGE_PIN L17      [get_ports "FMC_LPC_LA04_P"] ;# Bank  67 VCCO - VADJ_FMC - IO_L24P_T3U_N10_67
# set_property IOSTANDARD  LVDS     [get_ports "FMC_LPC_LA04_P"] ;# Bank  67 VCCO - VADJ_FMC - IO_L24P_T3U_N10_67
# set_property PACKAGE_PIN K18      [get_ports "FMC_LPC_LA03_N"] ;# Bank  67 VCCO - VADJ_FMC - IO_L23N_T3U_N9_67
# set_property IOSTANDARD  LVDS     [get_ports "FMC_LPC_LA03_N"] ;# Bank  67 VCCO - VADJ_FMC - IO_L23N_T3U_N9_67
# set_property PACKAGE_PIN K19      [get_ports "FMC_LPC_LA03_P"] ;# Bank  67 VCCO - VADJ_FMC - IO_L23P_T3U_N8_67
# set_property IOSTANDARD  LVDS     [get_ports "FMC_LPC_LA03_P"] ;# Bank  67 VCCO - VADJ_FMC - IO_L23P_T3U_N8_67
# set_property PACKAGE_PIN K15      [get_ports "FMC_LPC_LA10_N"] ;# Bank  67 VCCO - VADJ_FMC - IO_L22N_T3U_N7_DBC_AD0N_67
# set_property IOSTANDARD  LVDS     [get_ports "FMC_LPC_LA10_N"] ;# Bank  67 VCCO - VADJ_FMC - IO_L22N_T3U_N7_DBC_AD0N_67
# set_property PACKAGE_PIN L15      [get_ports "FMC_LPC_LA10_P"] ;# Bank  67 VCCO - VADJ_FMC - IO_L22P_T3U_N6_DBC_AD0P_67
# set_property IOSTANDARD  LVDS     [get_ports "FMC_LPC_LA10_P"] ;# Bank  67 VCCO - VADJ_FMC - IO_L22P_T3U_N6_DBC_AD0P_67
# set_property PACKAGE_PIN J17      [get_ports "FMC_LPC_LA05_N"] ;# Bank  67 VCCO - VADJ_FMC - IO_L21N_T3L_N5_AD8N_67
# set_property IOSTANDARD  LVDS     [get_ports "FMC_LPC_LA05_N"] ;# Bank  67 VCCO - VADJ_FMC - IO_L21N_T3L_N5_AD8N_67
# set_property PACKAGE_PIN K17      [get_ports "FMC_LPC_LA05_P"] ;# Bank  67 VCCO - VADJ_FMC - IO_L21P_T3L_N4_AD8P_67
# set_property IOSTANDARD  LVDS     [get_ports "FMC_LPC_LA05_P"] ;# Bank  67 VCCO - VADJ_FMC - IO_L21P_T3L_N4_AD8P_67
# set_property PACKAGE_PIN J15      [get_ports "FMC_LPC_LA07_N"] ;# Bank  67 VCCO - VADJ_FMC - IO_L20N_T3L_N3_AD1N_67
# set_property IOSTANDARD  LVDS     [get_ports "FMC_LPC_LA07_N"] ;# Bank  67 VCCO - VADJ_FMC - IO_L20N_T3L_N3_AD1N_67
# set_property PACKAGE_PIN J16      [get_ports "FMC_LPC_LA07_P"] ;# Bank  67 VCCO - VADJ_FMC - IO_L20P_T3L_N2_AD1P_67
# set_property IOSTANDARD  LVDS     [get_ports "FMC_LPC_LA07_P"] ;# Bank  67 VCCO - VADJ_FMC - IO_L20P_T3L_N2_AD1P_67
# set_property PACKAGE_PIN K20      [get_ports "FMC_LPC_LA02_N"] ;# Bank  67 VCCO - VADJ_FMC - IO_L19N_T3L_N1_DBC_AD9N_67
# set_property IOSTANDARD  LVDS     [get_ports "FMC_LPC_LA02_N"] ;# Bank  67 VCCO - VADJ_FMC - IO_L19N_T3L_N1_DBC_AD9N_67
# set_property PACKAGE_PIN L20      [get_ports "FMC_LPC_LA02_P"] ;# Bank  67 VCCO - VADJ_FMC - IO_L19P_T3L_N0_DBC_AD9P_67
# set_property IOSTANDARD  LVDS     [get_ports "FMC_LPC_LA02_P"] ;# Bank  67 VCCO - VADJ_FMC - IO_L19P_T3L_N0_DBC_AD9P_67
#set_property PACKAGE_PIN G16      [get_ports "FMC_LPC_LA09_N"] ;# Bank  67 VCCO - VADJ_FMC - IO_L18N_T2U_N11_AD2N_67
# set_property IOSTANDARD  LVDS     [get_ports "FMC_LPC_LA09_N"] ;# Bank  67 VCCO - VADJ_FMC - IO_L18N_T2U_N11_AD2N_67
# set_property PACKAGE_PIN H16      [get_ports "FMC_LPC_LA09_P"] ;# Bank  67 VCCO - VADJ_FMC - IO_L18P_T2U_N10_AD2P_67
# set_property IOSTANDARD  LVDS     [get_ports "FMC_LPC_LA09_P"] ;# Bank  67 VCCO - VADJ_FMC - IO_L18P_T2U_N10_AD2P_67
# set_property PACKAGE_PIN F18      [get_ports "FMC_LPC_LA12_N"] ;# Bank  67 VCCO - VADJ_FMC - IO_L17N_T2U_N9_AD10N_67
# set_property IOSTANDARD  LVDS     [get_ports "FMC_LPC_LA12_N"] ;# Bank  67 VCCO - VADJ_FMC - IO_L17N_T2U_N9_AD10N_67
# set_property PACKAGE_PIN G18      [get_ports "FMC_LPC_LA12_P"] ;# Bank  67 VCCO - VADJ_FMC - IO_L17P_T2U_N8_AD10P_67
# set_property IOSTANDARD  LVDS     [get_ports "FMC_LPC_LA12_P"] ;# Bank  67 VCCO - VADJ_FMC - IO_L17P_T2U_N8_AD10P_67
# set_property PACKAGE_PIN H17      [get_ports "FMC_LPC_LA01_CC_N"] ;# Bank  67 VCCO - VADJ_FMC - IO_L16N_T2U_N7_QBC_AD3N_67
# set_property IOSTANDARD  LVDS     [get_ports "FMC_LPC_LA01_CC_N"] ;# Bank  67 VCCO - VADJ_FMC - IO_L16N_T2U_N7_QBC_AD3N_67
# set_property PACKAGE_PIN H18      [get_ports "FMC_LPC_LA01_CC_P"] ;# Bank  67 VCCO - VADJ_FMC - IO_L16P_T2U_N6_QBC_AD3P_67
# set_property IOSTANDARD  LVDS     [get_ports "FMC_LPC_LA01_CC_P"] ;# Bank  67 VCCO - VADJ_FMC - IO_L16P_T2U_N6_QBC_AD3P_67
# set_property PACKAGE_PIN G19      [get_ports "FMC_LPC_LA06_N"] ;# Bank  67 VCCO - VADJ_FMC - IO_L15N_T2L_N5_AD11N_67
# set_property IOSTANDARD  LVDS     [get_ports "FMC_LPC_LA06_N"] ;# Bank  67 VCCO - VADJ_FMC - IO_L15N_T2L_N5_AD11N_67
# set_property PACKAGE_PIN H19      [get_ports "FMC_LPC_LA06_P"] ;# Bank  67 VCCO - VADJ_FMC - IO_L15P_T2L_N4_AD11P_67
# set_property IOSTANDARD  LVDS     [get_ports "FMC_LPC_LA06_P"] ;# Bank  67 VCCO - VADJ_FMC - IO_L15P_T2L_N4_AD11P_67
# set_property PACKAGE_PIN F15      [get_ports "FMC_LPC_LA13_N"] ;# Bank  67 VCCO - VADJ_FMC - IO_L14N_T2L_N3_GC_67
# set_property IOSTANDARD  LVDS     [get_ports "FMC_LPC_LA13_N"] ;# Bank  67 VCCO - VADJ_FMC - IO_L14N_T2L_N3_GC_67
# set_property PACKAGE_PIN G15      [get_ports "FMC_LPC_LA13_P"] ;# Bank  67 VCCO - VADJ_FMC - IO_L14P_T2L_N2_GC_67
# set_property IOSTANDARD  LVDS     [get_ports "FMC_LPC_LA13_P"] ;# Bank  67 VCCO - VADJ_FMC - IO_L14P_T2L_N2_GC_67
# set_property PACKAGE_PIN F16      [get_ports "FMC_LPC_LA00_CC_N"] ;# Bank  67 VCCO - VADJ_FMC - IO_L13N_T2L_N1_GC_QBC_67
# set_property IOSTANDARD  LVDS     [get_ports "FMC_LPC_LA00_CC_N"] ;# Bank  67 VCCO - VADJ_FMC - IO_L13N_T2L_N1_GC_QBC_67
# set_property PACKAGE_PIN F17      [get_ports "FMC_LPC_LA00_CC_P"] ;# Bank  67 VCCO - VADJ_FMC - IO_L13P_T2L_N0_GC_QBC_67
# set_property IOSTANDARD  LVDS     [get_ports "FMC_LPC_LA00_CC_P"] ;# Bank  67 VCCO - VADJ_FMC - IO_L13P_T2L_N0_GC_QBC_67
# set_property PACKAGE_PIN E14      [get_ports "FMC_LPC_CLK0_M2C_N"] ;# Bank  67 VCCO - VADJ_FMC - IO_L12N_T1U_N11_GC_67
# set_property IOSTANDARD  LVDS     [get_ports "FMC_LPC_CLK0_M2C_N"] ;# Bank  67 VCCO - VADJ_FMC - IO_L12N_T1U_N11_GC_67
# set_property PACKAGE_PIN E15      [get_ports "FMC_LPC_CLK0_M2C_P"] ;# Bank  67 VCCO - VADJ_FMC - IO_L12P_T1U_N10_GC_67
# set_property IOSTANDARD  LVDS     [get_ports "FMC_LPC_CLK0_M2C_P"] ;# Bank  67 VCCO - VADJ_FMC - IO_L12P_T1U_N10_GC_67
# set_property PACKAGE_PIN E17      [get_ports "FMC_LPC_LA08_N"] ;# Bank  67 VCCO - VADJ_FMC - IO_L9N_T1L_N5_AD12N_67
# set_property IOSTANDARD  LVDS     [get_ports "FMC_LPC_LA08_N"] ;# Bank  67 VCCO - VADJ_FMC - IO_L9N_T1L_N5_AD12N_67
# set_property PACKAGE_PIN E18      [get_ports "FMC_LPC_LA08_P"] ;# Bank  67 VCCO - VADJ_FMC - IO_L9P_T1L_N4_AD12P_67
# set_property IOSTANDARD  LVDS     [get_ports "FMC_LPC_LA08_P"] ;# Bank  67 VCCO - VADJ_FMC - IO_L9P_T1L_N4_AD12P_67
# set_property PACKAGE_PIN C17      [get_ports "FMC_LPC_LA16_N"] ;# Bank  67 VCCO - VADJ_FMC - IO_L8N_T1L_N3_AD5N_67
# set_property IOSTANDARD  LVDS     [get_ports "FMC_LPC_LA16_N"] ;# Bank  67 VCCO - VADJ_FMC - IO_L8N_T1L_N3_AD5N_67
# set_property PACKAGE_PIN D17      [get_ports "FMC_LPC_LA16_P"] ;# Bank  67 VCCO - VADJ_FMC - IO_L8P_T1L_N2_AD5P_67
# set_property IOSTANDARD  LVDS     [get_ports "FMC_LPC_LA16_P"] ;# Bank  67 VCCO - VADJ_FMC - IO_L8P_T1L_N2_AD5P_67
# set_property PACKAGE_PIN C16      [get_ports "FMC_LPC_LA15_N"] ;# Bank  67 VCCO - VADJ_FMC - IO_L7N_T1L_N1_QBC_AD13N_67
# set_property IOSTANDARD  LVDS     [get_ports "FMC_LPC_LA15_N"] ;# Bank  67 VCCO - VADJ_FMC - IO_L7N_T1L_N1_QBC_AD13N_67
# set_property PACKAGE_PIN D16      [get_ports "FMC_LPC_LA15_P"] ;# Bank  67 VCCO - VADJ_FMC - IO_L7P_T1L_N0_QBC_AD13P_67
# set_property IOSTANDARD  LVDS     [get_ports "FMC_LPC_LA15_P"] ;# Bank  67 VCCO - VADJ_FMC - IO_L7P_T1L_N0_QBC_AD13P_67
#set_property PACKAGE_PIN C12      [get_ports "FMC_LPC_LA14_N"] ;# Bank  67 VCCO - VADJ_FMC - IO_L6N_T0U_N11_AD6N_67
# set_property IOSTANDARD  LVDS     [get_ports "FMC_LPC_LA14_N"] ;# Bank  67 VCCO - VADJ_FMC - IO_L6N_T0U_N11_AD6N_67
# set_property PACKAGE_PIN C13      [get_ports "FMC_LPC_LA14_P"] ;# Bank  67 VCCO - VADJ_FMC - IO_L6P_T0U_N10_AD6P_67
# set_property IOSTANDARD  LVDS     [get_ports "FMC_LPC_LA14_P"] ;# Bank  67 VCCO - VADJ_FMC - IO_L6P_T0U_N10_AD6P_67
# set_property PACKAGE_PIN A12      [get_ports "FMC_LPC_LA11_N"] ;# Bank  67 VCCO - VADJ_FMC - IO_L5N_T0U_N9_AD14N_67
# set_property IOSTANDARD  LVDS     [get_ports "FMC_LPC_LA11_N"] ;# Bank  67 VCCO - VADJ_FMC - IO_L5N_T0U_N9_AD14N_67
# set_property PACKAGE_PIN A13      [get_ports "FMC_LPC_LA11_P"] ;# Bank  67 VCCO - VADJ_FMC - IO_L5P_T0U_N8_AD14P_67
# set_property IOSTANDARD  LVDS     [get_ports "FMC_LPC_LA11_P"] ;# Bank  67 VCCO - VADJ_FMC - IO_L5P_T0U_N8_AD14P_67
# set_property PACKAGE_PIN P3       [get_ports "FMC_LPC_DP0_M2C_N"] ;# Bank 226 - MGTHRXN3_226
# set_property PACKAGE_PIN P4       [get_ports "FMC_LPC_DP0_M2C_P"] ;# Bank 226 - MGTHRXP3_226
# set_property PACKAGE_PIN N5       [get_ports "FMC_LPC_DP0_C2M_N"] ;# Bank 226 - MGTHTXN3_226
# set_property PACKAGE_PIN N6       [get_ports "FMC_LPC_DP0_C2M_P"] ;# Bank 226 - MGTHTXP3_226
# set_property PACKAGE_PIN V7       [get_ports "FMC_LPC_GBTCLK0_M2C_C_N"] ;# Bank 226 - MGTREFCLK0N_226
# set_property PACKAGE_PIN V8       [get_ports "FMC_LPC_GBTCLK0_M2C_C_P"] ;# Bank 226 - MGTREFCLK0P_226

# ----------------------------------------------------------------------------
# DDR4
# ----------------------------------------------------------------------------
# set_property PACKAGE_PIN AC13     [get_ports "DDR4_SODIMM_DQ32"] ;# Bank  66 VCCO - VCC1V2   - IO_L24N_T3U_N11_66
# set_property IOSTANDARD  POD12    [get_ports "DDR4_SODIMM_DQ32"] ;# Bank  66 VCCO - VCC1V2   - IO_L24N_T3U_N11_66
# set_property PACKAGE_PIN AB13     [get_ports "DDR4_SODIMM_DQ33"] ;# Bank  66 VCCO - VCC1V2   - IO_L24P_T3U_N10_66
# set_property IOSTANDARD  POD12    [get_ports "DDR4_SODIMM_DQ33"] ;# Bank  66 VCCO - VCC1V2   - IO_L24P_T3U_N10_66
# set_property PACKAGE_PIN AF12     [get_ports "DDR4_SODIMM_DQ34"] ;# Bank  66 VCCO - VCC1V2   - IO_L23N_T3U_N9_66
# set_property IOSTANDARD  POD12    [get_ports "DDR4_SODIMM_DQ34"] ;# Bank  66 VCCO - VCC1V2   - IO_L23N_T3U_N9_66
# set_property PACKAGE_PIN AE12     [get_ports "DDR4_SODIMM_DQ35"] ;# Bank  66 VCCO - VCC1V2   - IO_L23P_T3U_N8_66
# set_property IOSTANDARD  POD12    [get_ports "DDR4_SODIMM_DQ35"] ;# Bank  66 VCCO - VCC1V2   - IO_L23P_T3U_N8_66
# set_property PACKAGE_PIN AD12     [get_ports "DDR4_SODIMM_DQS4_C"] ;# Bank  66 VCCO - VCC1V2   - IO_L22N_T3U_N7_DBC_AD0N_66
# set_property IOSTANDARD  DIFF_POD12 [get_ports "DDR4_SODIMM_DQS4_C"] ;# Bank  66 VCCO - VCC1V2   - IO_L22N_T3U_N7_DBC_AD0N_66
# set_property PACKAGE_PIN AC12     [get_ports "DDR4_SODIMM_DQS4_T"] ;# Bank  66 VCCO - VCC1V2   - IO_L22P_T3U_N6_DBC_AD0P_66
# set_property IOSTANDARD  DIFF_POD12 [get_ports "DDR4_SODIMM_DQS4_T"] ;# Bank  66 VCCO - VCC1V2   - IO_L22P_T3U_N6_DBC_AD0P_66
# set_property PACKAGE_PIN AF13     [get_ports "DDR4_SODIMM_DQ36"] ;# Bank  66 VCCO - VCC1V2   - IO_L21N_T3L_N5_AD8N_66
# set_property IOSTANDARD  POD12    [get_ports "DDR4_SODIMM_DQ36"] ;# Bank  66 VCCO - VCC1V2   - IO_L21N_T3L_N5_AD8N_66
# set_property PACKAGE_PIN AE13     [get_ports "DDR4_SODIMM_DQ37"] ;# Bank  66 VCCO - VCC1V2   - IO_L21P_T3L_N4_AD8P_66
# set_property IOSTANDARD  POD12    [get_ports "DDR4_SODIMM_DQ37"] ;# Bank  66 VCCO - VCC1V2   - IO_L21P_T3L_N4_AD8P_66
# set_property PACKAGE_PIN AE14     [get_ports "DDR4_SODIMM_DQ38"] ;# Bank  66 VCCO - VCC1V2   - IO_L20N_T3L_N3_AD1N_66
# set_property IOSTANDARD  POD12    [get_ports "DDR4_SODIMM_DQ38"] ;# Bank  66 VCCO - VCC1V2   - IO_L20N_T3L_N3_AD1N_66
# set_property PACKAGE_PIN AD14     [get_ports "DDR4_SODIMM_DQ39"] ;# Bank  66 VCCO - VCC1V2   - IO_L20P_T3L_N2_AD1P_66
# set_property IOSTANDARD  POD12    [get_ports "DDR4_SODIMM_DQ39"] ;# Bank  66 VCCO - VCC1V2   - IO_L20P_T3L_N2_AD1P_66
# set_property PACKAGE_PIN AF11     [get_ports "DDR4_SODIMM_DM4_B"] ;# Bank  66 VCCO - VCC1V2   - IO_L19P_T3L_N0_DBC_AD9P_66
# set_property IOSTANDARD  POD12    [get_ports "DDR4_SODIMM_DM4_B"] ;# Bank  66 VCCO - VCC1V2   - IO_L19P_T3L_N0_DBC_AD9P_66
# set_property PACKAGE_PIN AG8      [get_ports "DDR4_SODIMM_DQ40"] ;# Bank  66 VCCO - VCC1V2   - IO_L18N_T2U_N11_AD2N_66
# set_property IOSTANDARD  POD12    [get_ports "DDR4_SODIMM_DQ40"] ;# Bank  66 VCCO - VCC1V2   - IO_L18N_T2U_N11_AD2N_66
# set_property PACKAGE_PIN AF8      [get_ports "DDR4_SODIMM_DQ41"] ;# Bank  66 VCCO - VCC1V2   - IO_L18P_T2U_N10_AD2P_66
# set_property IOSTANDARD  POD12    [get_ports "DDR4_SODIMM_DQ41"] ;# Bank  66 VCCO - VCC1V2   - IO_L18P_T2U_N10_AD2P_66
# set_property PACKAGE_PIN AG10     [get_ports "DDR4_SODIMM_DQ42"] ;# Bank  66 VCCO - VCC1V2   - IO_L17N_T2U_N9_AD10N_66
# set_property IOSTANDARD  POD12    [get_ports "DDR4_SODIMM_DQ42"] ;# Bank  66 VCCO - VCC1V2   - IO_L17N_T2U_N9_AD10N_66
# set_property PACKAGE_PIN AG11     [get_ports "DDR4_SODIMM_DQ43"] ;# Bank  66 VCCO - VCC1V2   - IO_L17P_T2U_N8_AD10P_66
# set_property IOSTANDARD  POD12    [get_ports "DDR4_SODIMM_DQ43"] ;# Bank  66 VCCO - VCC1V2   - IO_L17P_T2U_N8_AD10P_66
# set_property PACKAGE_PIN AH9      [get_ports "DDR4_SODIMM_DQS5_C"] ;# Bank  66 VCCO - VCC1V2   - IO_L16N_T2U_N7_QBC_AD3N_66
# set_property IOSTANDARD  DIFF_POD12 [get_ports "DDR4_SODIMM_DQS5_C"] ;# Bank  66 VCCO - VCC1V2   - IO_L16N_T2U_N7_QBC_AD3N_66
# set_property PACKAGE_PIN AG9      [get_ports "DDR4_SODIMM_DQS5_T"] ;# Bank  66 VCCO - VCC1V2   - IO_L16P_T2U_N6_QBC_AD3P_66
# set_property IOSTANDARD  DIFF_POD12 [get_ports "DDR4_SODIMM_DQS5_T"] ;# Bank  66 VCCO - VCC1V2   - IO_L16P_T2U_N6_QBC_AD3P_66
# set_property PACKAGE_PIN AH13     [get_ports "DDR4_SODIMM_DQ44"] ;# Bank  66 VCCO - VCC1V2   - IO_L15N_T2L_N5_AD11N_66
# set_property IOSTANDARD  POD12    [get_ports "DDR4_SODIMM_DQ44"] ;# Bank  66 VCCO - VCC1V2   - IO_L15N_T2L_N5_AD11N_66
# set_property PACKAGE_PIN AG13     [get_ports "DDR4_SODIMM_DQ45"] ;# Bank  66 VCCO - VCC1V2   - IO_L15P_T2L_N4_AD11P_66
# set_property IOSTANDARD  POD12    [get_ports "DDR4_SODIMM_DQ45"] ;# Bank  66 VCCO - VCC1V2   - IO_L15P_T2L_N4_AD11P_66
# set_property PACKAGE_PIN AJ11     [get_ports "DDR4_SODIMM_DQ46"] ;# Bank  66 VCCO - VCC1V2   - IO_L14N_T2L_N3_GC_66
# set_property IOSTANDARD  POD12    [get_ports "DDR4_SODIMM_DQ46"] ;# Bank  66 VCCO - VCC1V2   - IO_L14N_T2L_N3_GC_66
# set_property PACKAGE_PIN AH11     [get_ports "DDR4_SODIMM_DQ47"] ;# Bank  66 VCCO - VCC1V2   - IO_L14P_T2L_N2_GC_66
# set_property IOSTANDARD  POD12    [get_ports "DDR4_SODIMM_DQ47"] ;# Bank  66 VCCO - VCC1V2   - IO_L14P_T2L_N2_GC_66
# set_property PACKAGE_PIN AH12     [get_ports "DDR4_SODIMM_DM5_B"] ;# Bank  66 VCCO - VCC1V2   - IO_L13P_T2L_N0_GC_QBC_66
# set_property IOSTANDARD  POD12    [get_ports "DDR4_SODIMM_DM5_B"] ;# Bank  66 VCCO - VCC1V2   - IO_L13P_T2L_N0_GC_QBC_66
# set_property PACKAGE_PIN AK9      [get_ports "DDR4_SODIMM_DQ48"] ;# Bank  66 VCCO - VCC1V2   - IO_L12N_T1U_N11_GC_66
# set_property IOSTANDARD  POD12    [get_ports "DDR4_SODIMM_DQ48"] ;# Bank  66 VCCO - VCC1V2   - IO_L12N_T1U_N11_GC_66
# set_property PACKAGE_PIN AJ9      [get_ports "DDR4_SODIMM_DQ49"] ;# Bank  66 VCCO - VCC1V2   - IO_L12P_T1U_N10_GC_66
# set_property IOSTANDARD  POD12    [get_ports "DDR4_SODIMM_DQ49"] ;# Bank  66 VCCO - VCC1V2   - IO_L12P_T1U_N10_GC_66
# set_property PACKAGE_PIN AK10     [get_ports "DDR4_SODIMM_DQ50"] ;# Bank  66 VCCO - VCC1V2   - IO_L11N_T1U_N9_GC_66
# set_property IOSTANDARD  POD12    [get_ports "DDR4_SODIMM_DQ50"] ;# Bank  66 VCCO - VCC1V2   - IO_L11N_T1U_N9_GC_66
# set_property PACKAGE_PIN AJ10     [get_ports "DDR4_SODIMM_DQ51"] ;# Bank  66 VCCO - VCC1V2   - IO_L11P_T1U_N8_GC_66
# set_property IOSTANDARD  POD12    [get_ports "DDR4_SODIMM_DQ51"] ;# Bank  66 VCCO - VCC1V2   - IO_L11P_T1U_N8_GC_66
# set_property PACKAGE_PIN AL8      [get_ports "DDR4_SODIMM_DQS6_C"] ;# Bank  66 VCCO - VCC1V2   - IO_L10N_T1U_N7_QBC_AD4N_66
# set_property IOSTANDARD  DIFF_POD12 [get_ports "DDR4_SODIMM_DQS6_C"] ;# Bank  66 VCCO - VCC1V2   - IO_L10N_T1U_N7_QBC_AD4N_66
# set_property PACKAGE_PIN AK8      [get_ports "DDR4_SODIMM_DQS6_T"] ;# Bank  66 VCCO - VCC1V2   - IO_L10P_T1U_N6_QBC_AD4P_66
# set_property IOSTANDARD  DIFF_POD12 [get_ports "DDR4_SODIMM_DQS6_T"] ;# Bank  66 VCCO - VCC1V2   - IO_L10P_T1U_N6_QBC_AD4P_66
# set_property PACKAGE_PIN AL12     [get_ports "DDR4_SODIMM_DQ52"] ;# Bank  66 VCCO - VCC1V2   - IO_L9N_T1L_N5_AD12N_66
# set_property IOSTANDARD  POD12    [get_ports "DDR4_SODIMM_DQ52"] ;# Bank  66 VCCO - VCC1V2   - IO_L9N_T1L_N5_AD12N_66
# set_property PACKAGE_PIN AK12     [get_ports "DDR4_SODIMM_DQ53"] ;# Bank  66 VCCO - VCC1V2   - IO_L9P_T1L_N4_AD12P_66
# set_property IOSTANDARD  POD12    [get_ports "DDR4_SODIMM_DQ53"] ;# Bank  66 VCCO - VCC1V2   - IO_L9P_T1L_N4_AD12P_66
# set_property PACKAGE_PIN AL10     [get_ports "DDR4_SODIMM_DQ54"] ;# Bank  66 VCCO - VCC1V2   - IO_L8N_T1L_N3_AD5N_66
# set_property IOSTANDARD  POD12    [get_ports "DDR4_SODIMM_DQ54"] ;# Bank  66 VCCO - VCC1V2   - IO_L8N_T1L_N3_AD5N_66
# set_property PACKAGE_PIN AL11     [get_ports "DDR4_SODIMM_DQ55"] ;# Bank  66 VCCO - VCC1V2   - IO_L8P_T1L_N2_AD5P_66
# set_property IOSTANDARD  POD12     [get_ports "DDR4_SODIMM_DQ55"] ;# Bank  66 VCCO - VCC1V2   - IO_L8P_T1L_N2_AD5P_66
# set_property PACKAGE_PIN AK13     [get_ports "DDR4_SODIMM_DM6_B"] ;# Bank  66 VCCO - VCC1V2   - IO_L7P_T1L_N0_QBC_AD13P_66
# set_property IOSTANDARD  POD12    [get_ports "DDR4_SODIMM_DM6_B"] ;# Bank  66 VCCO - VCC1V2   - IO_L7P_T1L_N0_QBC_AD13P_66
# set_property PACKAGE_PIN AM8      [get_ports "DDR4_SODIMM_DQ56"] ;# Bank  66 VCCO - VCC1V2   - IO_L6N_T0U_N11_AD6N_66
# set_property IOSTANDARD  POD12    [get_ports "DDR4_SODIMM_DQ56"] ;# Bank  66 VCCO - VCC1V2   - IO_L6N_T0U_N11_AD6N_66
# set_property PACKAGE_PIN AM9      [get_ports "DDR4_SODIMM_DQ57"] ;# Bank  66 VCCO - VCC1V2   - IO_L6P_T0U_N10_AD6P_66
# set_property IOSTANDARD  POD12    [get_ports "DDR4_SODIMM_DQ57"] ;# Bank  66 VCCO - VCC1V2   - IO_L6P_T0U_N10_AD6P_66
# set_property PACKAGE_PIN AM10     [get_ports "DDR4_SODIMM_DQ58"] ;# Bank  66 VCCO - VCC1V2   - IO_L5N_T0U_N9_AD14N_66
# set_property IOSTANDARD  POD12    [get_ports "DDR4_SODIMM_DQ58"] ;# Bank  66 VCCO - VCC1V2   - IO_L5N_T0U_N9_AD14N_66
# set_property PACKAGE_PIN AM11     [get_ports "DDR4_SODIMM_DQ59"] ;# Bank  66 VCCO - VCC1V2   - IO_L5P_T0U_N8_AD14P_66
# set_property IOSTANDARD  POD12    [get_ports "DDR4_SODIMM_DQ59"] ;# Bank  66 VCCO - VCC1V2   - IO_L5P_T0U_N8_AD14P_66
# set_property PACKAGE_PIN AN8      [get_ports "DDR4_SODIMM_DQS7_C"] ;# Bank  66 VCCO - VCC1V2   - IO_L4N_T0U_N7_DBC_AD7N_66
# set_property IOSTANDARD  DIFF_POD12 [get_ports "DDR4_SODIMM_DQS7_C"] ;# Bank  66 VCCO - VCC1V2   - IO_L4N_T0U_N7_DBC_AD7N_66
# set_property PACKAGE_PIN AN9      [get_ports "DDR4_SODIMM_DQS7_T"] ;# Bank  66 VCCO - VCC1V2   - IO_L4P_T0U_N6_DBC_AD7P_66
# set_property IOSTANDARD  DIFF_POD12 [get_ports "DDR4_SODIMM_DQS7_T"] ;# Bank  66 VCCO - VCC1V2   - IO_L4P_T0U_N6_DBC_AD7P_66
# set_property PACKAGE_PIN AP11     [get_ports "DDR4_SODIMM_DQ60"] ;# Bank  66 VCCO - VCC1V2   - IO_L3N_T0L_N5_AD15N_66
# set_property IOSTANDARD  POD12    [get_ports "DDR4_SODIMM_DQ60"] ;# Bank  66 VCCO - VCC1V2   - IO_L3N_T0L_N5_AD15N_66
# set_property PACKAGE_PIN AN11     [get_ports "DDR4_SODIMM_DQ61"] ;# Bank  66 VCCO - VCC1V2   - IO_L3P_T0L_N4_AD15P_66
# set_property IOSTANDARD  POD12    [get_ports "DDR4_SODIMM_DQ61"] ;# Bank  66 VCCO - VCC1V2   - IO_L3P_T0L_N4_AD15P_66
# set_property PACKAGE_PIN AP9      [get_ports "DDR4_SODIMM_DQ62"] ;# Bank  66 VCCO - VCC1V2   - IO_L2N_T0L_N3_66
# set_property IOSTANDARD  POD12    [get_ports "DDR4_SODIMM_DQ62"] ;# Bank  66 VCCO - VCC1V2   - IO_L2N_T0L_N3_66
# set_property PACKAGE_PIN AP10     [get_ports "DDR4_SODIMM_DQ63"] ;# Bank  66 VCCO - VCC1V2   - IO_L2P_T0L_N2_66
# set_property IOSTANDARD  POD12    [get_ports "DDR4_SODIMM_DQ63"] ;# Bank  66 VCCO - VCC1V2   - IO_L2P_T0L_N2_66
# set_property PACKAGE_PIN AN12     [get_ports "DDR4_SODIMM_DM7_B"] ;# Bank  66 VCCO - VCC1V2   - IO_L1P_T0L_N0_DBC_66
# set_property IOSTANDARD  POD12    [get_ports "DDR4_SODIMM_DM7_B"] ;# Bank  66 VCCO - VCC1V2   - IO_L1P_T0L_N0_DBC_66
# set_property PACKAGE_PIN AA20     [get_ports "DDR4_SODIMM_DQ8"] ;# Bank  65 VCCO - VCC1V2   - IO_L24N_T3U_N11_PERSTN0_65
# set_property IOSTANDARD  POD12   [get_ports "DDR4_SODIMM_DQ8"] ;# Bank  65 VCCO - VCC1V2   - IO_L24N_T3U_N11_PERSTN0_65
# set_property PACKAGE_PIN AA19     [get_ports "DDR4_SODIMM_DQ9"] ;# Bank  65 VCCO - VCC1V2   - IO_L24P_T3U_N10_PERSTN1_I2C_SDA_65
# set_property IOSTANDARD  POD12    [get_ports "DDR4_SODIMM_DQ9"] ;# Bank  65 VCCO - VCC1V2   - IO_L24P_T3U_N10_PERSTN1_I2C_SDA_65
# set_property PACKAGE_PIN AD19     [get_ports "DDR4_SODIMM_DQ10"] ;# Bank  65 VCCO - VCC1V2   - IO_L23N_T3U_N9_65
# set_property IOSTANDARD  POD12    [get_ports "DDR4_SODIMM_DQ10"] ;# Bank  65 VCCO - VCC1V2   - IO_L23N_T3U_N9_65
# set_property PACKAGE_PIN AC18     [get_ports "DDR4_SODIMM_DQ11"] ;# Bank  65 VCCO - VCC1V2   - IO_L23P_T3U_N8_I2C_SCLK_65
# set_property IOSTANDARD  POD12    [get_ports "DDR4_SODIMM_DQ11"] ;# Bank  65 VCCO - VCC1V2   - IO_L23P_T3U_N8_I2C_SCLK_65
# set_property PACKAGE_PIN AB18     [get_ports "DDR4_SODIMM_DQS1_C"] ;# Bank  65 VCCO - VCC1V2   - IO_L22N_T3U_N7_DBC_AD0N_65
# set_property IOSTANDARD  DIFF_POD12 [get_ports "DDR4_SODIMM_DQS1_C"] ;# Bank  65 VCCO - VCC1V2   - IO_L22N_T3U_N7_DBC_AD0N_65
# set_property PACKAGE_PIN AA18     [get_ports "DDR4_SODIMM_DQS1_T"] ;# Bank  65 VCCO - VCC1V2   - IO_L22P_T3U_N6_DBC_AD0P_65
# set_property IOSTANDARD  DIFF_POD12 [get_ports "DDR4_SODIMM_DQS1_T"] ;# Bank  65 VCCO - VCC1V2   - IO_L22P_T3U_N6_DBC_AD0P_65
# set_property PACKAGE_PIN AE20     [get_ports "DDR4_SODIMM_DQ12"] ;# Bank  65 VCCO - VCC1V2   - IO_L21N_T3L_N5_AD8N_65
# set_property IOSTANDARD  POD12    [get_ports "DDR4_SODIMM_DQ12"] ;# Bank  65 VCCO - VCC1V2   - IO_L21N_T3L_N5_AD8N_65
# set_property PACKAGE_PIN AD20     [get_ports "DDR4_SODIMM_DQ13"] ;# Bank  65 VCCO - VCC1V2   - IO_L21P_T3L_N4_AD8P_65
# set_property IOSTANDARD  POD12    [get_ports "DDR4_SODIMM_DQ13"] ;# Bank  65 VCCO - VCC1V2   - IO_L21P_T3L_N4_AD8P_65
# set_property PACKAGE_PIN AC19     [get_ports "DDR4_SODIMM_DQ14"] ;# Bank  65 VCCO - VCC1V2   - IO_L20N_T3L_N3_AD1N_65
# set_property IOSTANDARD  POD12    [get_ports "DDR4_SODIMM_DQ14"] ;# Bank  65 VCCO - VCC1V2   - IO_L20N_T3L_N3_AD1N_65
# set_property PACKAGE_PIN AB19     [get_ports "DDR4_SODIMM_DQ15"] ;# Bank  65 VCCO - VCC1V2   - IO_L20P_T3L_N2_AD1P_65
# set_property IOSTANDARD  POD12    [get_ports "DDR4_SODIMM_DQ15"] ;# Bank  65 VCCO - VCC1V2   - IO_L20P_T3L_N2_AD1P_65
# set_property PACKAGE_PIN AE18     [get_ports "DDR4_SODIMM_DM1_B"] ;# Bank  65 VCCO - VCC1V2   - IO_L19P_T3L_N0_DBC_AD9P_65
# set_property IOSTANDARD  POD12    [get_ports "DDR4_SODIMM_DM1_B"] ;# Bank  65 VCCO - VCC1V2   - IO_L19P_T3L_N0_DBC_AD9P_65
# set_property PACKAGE_PIN AE24     [get_ports "DDR4_SODIMM_DQ0"] ;# Bank  65 VCCO - VCC1V2   - IO_L18N_T2U_N11_AD2N_65
# set_property IOSTANDARD  POD12    [get_ports "DDR4_SODIMM_DQ0"] ;# Bank  65 VCCO - VCC1V2   - IO_L18N_T2U_N11_AD2N_65
# set_property PACKAGE_PIN AE23     [get_ports "DDR4_SODIMM_DQ1"] ;# Bank  65 VCCO - VCC1V2   - IO_L18P_T2U_N10_AD2P_65
# set_property IOSTANDARD  POD12    [get_ports "DDR4_SODIMM_DQ1"] ;# Bank  65 VCCO - VCC1V2   - IO_L18P_T2U_N10_AD2P_65
# set_property PACKAGE_PIN AF22     [get_ports "DDR4_SODIMM_DQ2"] ;# Bank  65 VCCO - VCC1V2   - IO_L17N_T2U_N9_AD10N_65
# set_property IOSTANDARD  POD12    [get_ports "DDR4_SODIMM_DQ2"] ;# Bank  65 VCCO - VCC1V2   - IO_L17N_T2U_N9_AD10N_65
# set_property PACKAGE_PIN AF21     [get_ports "DDR4_SODIMM_DQ3"] ;# Bank  65 VCCO - VCC1V2   - IO_L17P_T2U_N8_AD10P_65
# set_property IOSTANDARD  POD12    [get_ports "DDR4_SODIMM_DQ3"] ;# Bank  65 VCCO - VCC1V2   - IO_L17P_T2U_N8_AD10P_65
# set_property PACKAGE_PIN AG23     [get_ports "DDR4_SODIMM_DQS0_C"] ;# Bank  65 VCCO - VCC1V2   - IO_L16N_T2U_N7_QBC_AD3N_65
# set_property IOSTANDARD  DIFF_POD12 [get_ports "DDR4_SODIMM_DQS0_C"] ;# Bank  65 VCCO - VCC1V2   - IO_L16N_T2U_N7_QBC_AD3N_65
# set_property PACKAGE_PIN AF23     [get_ports "DDR4_SODIMM_DQS0_T"] ;# Bank  65 VCCO - VCC1V2   - IO_L16P_T2U_N6_QBC_AD3P_65
# set_property IOSTANDARD  DIFF_POD12[get_ports "DDR4_SODIMM_DQS0_T"] ;# Bank  65 VCCO - VCC1V2   - IO_L16P_T2U_N6_QBC_AD3P_65
# set_property PACKAGE_PIN AG20     [get_ports "DDR4_SODIMM_DQ4"] ;# Bank  65 VCCO - VCC1V2   - IO_L15N_T2L_N5_AD11N_65
# set_property IOSTANDARD  POD12    [get_ports "DDR4_SODIMM_DQ4"] ;# Bank  65 VCCO - VCC1V2   - IO_L15N_T2L_N5_AD11N_65
# set_property PACKAGE_PIN AG19     [get_ports "DDR4_SODIMM_DQ5"] ;# Bank  65 VCCO - VCC1V2   - IO_L15P_T2L_N4_AD11P_65
# set_property IOSTANDARD  POD12    [get_ports "DDR4_SODIMM_DQ5"] ;# Bank  65 VCCO - VCC1V2   - IO_L15P_T2L_N4_AD11P_65
# set_property PACKAGE_PIN AH21     [get_ports "DDR4_SODIMM_DQ6"] ;# Bank  65 VCCO - VCC1V2   - IO_L14N_T2L_N3_GC_65
# set_property IOSTANDARD  POD12    [get_ports "DDR4_SODIMM_DQ6"] ;# Bank  65 VCCO - VCC1V2   - IO_L14N_T2L_N3_GC_65
# set_property PACKAGE_PIN AG21     [get_ports "DDR4_SODIMM_DQ7"] ;# Bank  65 VCCO - VCC1V2   - IO_L14P_T2L_N2_GC_65
# set_property IOSTANDARD  POD12    [get_ports "DDR4_SODIMM_DQ7"] ;# Bank  65 VCCO - VCC1V2   - IO_L14P_T2L_N2_GC_65
# set_property PACKAGE_PIN AH22     [get_ports "DDR4_SODIMM_DM0_B"] ;# Bank  65 VCCO - VCC1V2   - IO_L13P_T2L_N0_GC_QBC_65
# set_property IOSTANDARD  POD12    [get_ports "DDR4_SODIMM_DM0_B"] ;# Bank  65 VCCO - VCC1V2   - IO_L13P_T2L_N0_GC_QBC_65
# set_property PACKAGE_PIN AJ22     [get_ports "DDR4_SODIMM_DQ16"] ;# Bank  65 VCCO - VCC1V2   - IO_L12N_T1U_N11_GC_65
# set_property IOSTANDARD  POD12    [get_ports "DDR4_SODIMM_DQ16"] ;# Bank  65 VCCO - VCC1V2   - IO_L12N_T1U_N11_GC_65
# set_property PACKAGE_PIN AJ21     [get_ports "DDR4_SODIMM_DQ17"] ;# Bank  65 VCCO - VCC1V2   - IO_L12P_T1U_N10_GC_65
# set_property IOSTANDARD  POD12    [get_ports "DDR4_SODIMM_DQ17"] ;# Bank  65 VCCO - VCC1V2   - IO_L12P_T1U_N10_GC_65
# set_property PACKAGE_PIN AK20     [get_ports "DDR4_SODIMM_DQ18"] ;# Bank  65 VCCO - VCC1V2   - IO_L11N_T1U_N9_GC_65
# set_property IOSTANDARD  POD12    [get_ports "DDR4_SODIMM_DQ18"] ;# Bank  65 VCCO - VCC1V2   - IO_L11N_T1U_N9_GC_65
# set_property PACKAGE_PIN AJ20     [get_ports "DDR4_SODIMM_DQ19"] ;# Bank  65 VCCO - VCC1V2   - IO_L11P_T1U_N8_GC_65
# set_property IOSTANDARD  POD12    [get_ports "DDR4_SODIMM_DQ19"] ;# Bank  65 VCCO - VCC1V2   - IO_L11P_T1U_N8_GC_65
# set_property PACKAGE_PIN AK23     [get_ports "DDR4_SODIMM_DQS2_C"] ;# Bank  65 VCCO - VCC1V2   - IO_L10N_T1U_N7_QBC_AD4N_65
# set_property IOSTANDARD  DIFF_POD12 [get_ports "DDR4_SODIMM_DQS2_C"] ;# Bank  65 VCCO - VCC1V2   - IO_L10N_T1U_N7_QBC_AD4N_65
# set_property PACKAGE_PIN AK22     [get_ports "DDR4_SODIMM_DQS2_T"] ;# Bank  65 VCCO - VCC1V2   - IO_L10P_T1U_N6_QBC_AD4P_65
# set_property IOSTANDARD  DIFF_POD12 [get_ports "DDR4_SODIMM_DQS2_T"] ;# Bank  65 VCCO - VCC1V2   - IO_L10P_T1U_N6_QBC_AD4P_65
# set_property PACKAGE_PIN AK19     [get_ports "DDR4_SODIMM_DQ20"] ;# Bank  65 VCCO - VCC1V2   - IO_L9N_T1L_N5_AD12N_65
# set_property IOSTANDARD  POD12    [get_ports "DDR4_SODIMM_DQ20"] ;# Bank  65 VCCO - VCC1V2   - IO_L9N_T1L_N5_AD12N_65
# set_property PACKAGE_PIN AJ19     [get_ports "DDR4_SODIMM_DQ21"] ;# Bank  65 VCCO - VCC1V2   - IO_L9P_T1L_N4_AD12P_65
# set_property IOSTANDARD  POD12    [get_ports "DDR4_SODIMM_DQ21"] ;# Bank  65 VCCO - VCC1V2   - IO_L9P_T1L_N4_AD12P_65
# set_property PACKAGE_PIN AL23     [get_ports "DDR4_SODIMM_DQ22"] ;# Bank  65 VCCO - VCC1V2   - IO_L8N_T1L_N3_AD5N_65
# set_property IOSTANDARD  POD12    [get_ports "DDR4_SODIMM_DQ22"] ;# Bank  65 VCCO - VCC1V2   - IO_L8N_T1L_N3_AD5N_65
# set_property PACKAGE_PIN AL22     [get_ports "DDR4_SODIMM_DQ23"] ;# Bank  65 VCCO - VCC1V2   - IO_L8P_T1L_N2_AD5P_65
# set_property IOSTANDARD  POD12    [get_ports "DDR4_SODIMM_DQ23"] ;# Bank  65 VCCO - VCC1V2   - IO_L8P_T1L_N2_AD5P_65
# set_property PACKAGE_PIN AL20     [get_ports "DDR4_SODIMM_DM2_B"] ;# Bank  65 VCCO - VCC1V2   - IO_L7P_T1L_N0_QBC_AD13P_65
# set_property IOSTANDARD  POD12    [get_ports "DDR4_SODIMM_DM2_B"] ;# Bank  65 VCCO - VCC1V2   - IO_L7P_T1L_N0_QBC_AD13P_65
# set_property PACKAGE_PIN AN23     [get_ports "DDR4_SODIMM_DQ24"] ;# Bank  65 VCCO - VCC1V2   - IO_L6N_T0U_N11_AD6N_65
# set_property IOSTANDARD  POD12    [get_ports "DDR4_SODIMM_DQ24"] ;# Bank  65 VCCO - VCC1V2   - IO_L6N_T0U_N11_AD6N_65
# set_property PACKAGE_PIN AM23     [get_ports "DDR4_SODIMM_DQ25"] ;# Bank  65 VCCO - VCC1V2   - IO_L6P_T0U_N10_AD6P_65
# set_property IOSTANDARD  POD12    [get_ports "DDR4_SODIMM_DQ25"] ;# Bank  65 VCCO - VCC1V2   - IO_L6P_T0U_N10_AD6P_65
# set_property PACKAGE_PIN AP23     [get_ports "DDR4_SODIMM_DQ26"] ;# Bank  65 VCCO - VCC1V2   - IO_L5N_T0U_N9_AD14N_65
# set_property IOSTANDARD  POD12    [get_ports "DDR4_SODIMM_DQ26"] ;# Bank  65 VCCO - VCC1V2   - IO_L5N_T0U_N9_AD14N_65
# set_property PACKAGE_PIN AN22     [get_ports "DDR4_SODIMM_DQ27"] ;# Bank  65 VCCO - VCC1V2   - IO_L5P_T0U_N8_AD14P_65
# set_property IOSTANDARD  POD12    [get_ports "DDR4_SODIMM_DQ27"] ;# Bank  65 VCCO - VCC1V2   - IO_L5P_T0U_N8_AD14P_65
# set_property PACKAGE_PIN AN21     [get_ports "DDR4_SODIMM_DQS3_C"] ;# Bank  65 VCCO - VCC1V2   - IO_L4N_T0U_N7_DBC_AD7N_65
# set_property IOSTANDARD  DIFF_POD12 [get_ports "DDR4_SODIMM_DQS3_C"] ;# Bank  65 VCCO - VCC1V2   - IO_L4N_T0U_N7_DBC_AD7N_65
# set_property PACKAGE_PIN AM21     [get_ports "DDR4_SODIMM_DQS3_T"] ;# Bank  65 VCCO - VCC1V2   - IO_L4P_T0U_N6_DBC_AD7P_SMBALERT_65
# set_property IOSTANDARD  DIFF_POD12 [get_ports "DDR4_SODIMM_DQS3_T"] ;# Bank  65 VCCO - VCC1V2   - IO_L4P_T0U_N6_DBC_AD7P_SMBALERT_65
# set_property PACKAGE_PIN AP22     [get_ports "DDR4_SODIMM_DQ28"] ;# Bank  65 VCCO - VCC1V2   - IO_L3N_T0L_N5_AD15N_65
# set_property IOSTANDARD  POD12    [get_ports "DDR4_SODIMM_DQ28"] ;# Bank  65 VCCO - VCC1V2   - IO_L3N_T0L_N5_AD15N_65
# set_property PACKAGE_PIN AP21     [get_ports "DDR4_SODIMM_DQ29"] ;# Bank  65 VCCO - VCC1V2   - IO_L3P_T0L_N4_AD15P_65
# set_property IOSTANDARD  POD12    [get_ports "DDR4_SODIMM_DQ29"] ;# Bank  65 VCCO - VCC1V2   - IO_L3P_T0L_N4_AD15P_65
# set_property PACKAGE_PIN AN19     [get_ports "DDR4_SODIMM_DQ30"] ;# Bank  65 VCCO - VCC1V2   - IO_L2N_T0L_N3_65
# set_property IOSTANDARD  POD12    [get_ports "DDR4_SODIMM_DQ30"] ;# Bank  65 VCCO - VCC1V2   - IO_L2N_T0L_N3_65
# set_property PACKAGE_PIN AM19     [get_ports "DDR4_SODIMM_DQ31"] ;# Bank  65 VCCO - VCC1V2   - IO_L2P_T0L_N2_65
# set_property IOSTANDARD  POD12    [get_ports "DDR4_SODIMM_DQ31"] ;# Bank  65 VCCO - VCC1V2   - IO_L2P_T0L_N2_65
# set_property PACKAGE_PIN AP19     [get_ports "DDR4_SODIMM_DM3_B"] ;# Bank  65 VCCO - VCC1V2   - IO_L1P_T0L_N0_DBC_65
# set_property IOSTANDARD  POD12    [get_ports "DDR4_SODIMM_DM3_B"] ;# Bank  65 VCCO - VCC1V2   - IO_L1P_T0L_N0_DBC_65
# set_property PACKAGE_PIN AD16     [get_ports "DDR4_SODIMM_PARITY"] ;# Bank  64 VCCO - VCC1V2   - IO_L24N_T3U_N11_64
# set_property IOSTANDARD  POD12    [get_ports "DDR4_SODIMM_PARITY"] ;# Bank  64 VCCO - VCC1V2   - IO_L24N_T3U_N11_64
# set_property PACKAGE_PIN AD17     [get_ports "DDR4_SODIMM_CKE0"] ;# Bank  64 VCCO - VCC1V2   - IO_L24P_T3U_N10_64
# set_property IOSTANDARD  SSTL12   [get_ports "DDR4_SODIMM_CKE0"] ;# Bank  64 VCCO - VCC1V2   - IO_L24P_T3U_N10_64
# set_property PACKAGE_PIN AB14     [get_ports "DDR4_SODIMM_RESET_B"] ;# Bank  64 VCCO - VCC1V2   - IO_L23N_T3U_N9_64
# set_property IOSTANDARD  LVCMOS12 [get_ports "DDR4_SODIMM_RESET_B"] ;# Bank  64 VCCO - VCC1V2   - IO_L23N_T3U_N9_64
# set_property PACKAGE_PIN AA14     [get_ports "DDR4_SODIMM_CAS_B"] ;# Bank  64 VCCO - VCC1V2   - IO_L23P_T3U_N8_64
# set_property IOSTANDARD  SSTL21   [get_ports "DDR4_SODIMM_CAS_B"] ;# Bank  64 VCCO - VCC1V2   - IO_L23P_T3U_N8_64
# set_property PACKAGE_PIN AA15     [get_ports "DDR4_SODIMM_CS0_B"] ;# Bank  64 VCCO - VCC1V2   - IO_L22N_T3U_N7_DBC_AD0N_64
# set_property IOSTANDARD  SSTL12   [get_ports "DDR4_SODIMM_CS0_B"] ;# Bank  64 VCCO - VCC1V2   - IO_L22N_T3U_N7_DBC_AD0N_64
# set_property PACKAGE_PIN AA16     [get_ports "DDR4_SODIMM_WE_B"] ;# Bank  64 VCCO - VCC1V2   - IO_L22P_T3U_N6_DBC_AD0P_64
# set_property IOSTANDARD  SSTL12   [get_ports "DDR4_SODIMM_WE_B"] ;# Bank  64 VCCO - VCC1V2   - IO_L22P_T3U_N6_DBC_AD0P_64
# set_property PACKAGE_PIN AB15     [get_ports "DDR4_SODIMM_ALERT_B"] ;# Bank  64 VCCO - VCC1V2   - IO_L21N_T3L_N5_AD8N_64
# set_property IOSTANDARD  POD12    [get_ports "DDR4_SODIMM_ALERT_B"] ;# Bank  64 VCCO - VCC1V2   - IO_L21N_T3L_N5_AD8N_64
# set_property PACKAGE_PIN AB16     [get_ports "DDR4_SODIMM_BG1"] ;# Bank  64 VCCO - VCC1V2   - IO_L21P_T3L_N4_AD8P_64
# set_property IOSTANDARD  SSTL12   [get_ports "DDR4_SODIMM_BG1"] ;# Bank  64 VCCO - VCC1V2   - IO_L21P_T3L_N4_AD8P_64
# set_property PACKAGE_PIN AC16     [get_ports "DDR4_SODIMM_BG0"] ;# Bank  64 VCCO - VCC1V2   - IO_L20N_T3L_N3_AD1N_64
# set_property IOSTANDARD  SSTL12   [get_ports "DDR4_SODIMM_BG0"] ;# Bank  64 VCCO - VCC1V2   - IO_L20N_T3L_N3_AD1N_64
# set_property PACKAGE_PIN AC17     [get_ports "DDR4_SODIMM_ACT_B"] ;# Bank  64 VCCO - VCC1V2   - IO_L20P_T3L_N2_AD1P_64
# set_property IOSTANDARD  SSTL12   [get_ports "DDR4_SODIMM_ACT_B"] ;# Bank  64 VCCO - VCC1V2   - IO_L20P_T3L_N2_AD1P_64
# set_property PACKAGE_PIN AE15     [get_ports "DDR4_SODIMM_ODT0"] ;# Bank  64 VCCO - VCC1V2   - IO_L19N_T3L_N1_DBC_AD9N_64
# set_property IOSTANDARD  SSTL12   [get_ports "DDR4_SODIMM_ODT0"] ;# Bank  64 VCCO - VCC1V2   - IO_L19N_T3L_N1_DBC_AD9N_64
# set_property PACKAGE_PIN AD15     [get_ports "DDR4_SODIMM_RAS_B"] ;# Bank  64 VCCO - VCC1V2   - IO_L19P_T3L_N0_DBC_AD9P_64
# set_property IOSTANDARD  SSTL12   [get_ports "DDR4_SODIMM_RAS_B"] ;# Bank  64 VCCO - VCC1V2   - IO_L19P_T3L_N0_DBC_AD9P_64
# set_property PACKAGE_PIN AH16     [get_ports "DDR4_SODIMM_A0"] ;# Bank  64 VCCO - VCC1V2   - IO_T2U_N12_64
# set_property IOSTANDARD  SSTL12   [get_ports "DDR4_SODIMM_A0"] ;# Bank  64 VCCO - VCC1V2   - IO_T2U_N12_64
# set_property PACKAGE_PIN AG14     [get_ports "DDR4_SODIMM_A1"] ;# Bank  64 VCCO - VCC1V2   - IO_L18N_T2U_N11_AD2N_64
# set_property IOSTANDARD  SSTL12   [get_ports "DDR4_SODIMM_A1"] ;# Bank  64 VCCO - VCC1V2   - IO_L18N_T2U_N11_AD2N_64
# set_property PACKAGE_PIN AG15     [get_ports "DDR4_SODIMM_A2"] ;# Bank  64 VCCO - VCC1V2   - IO_L18P_T2U_N10_AD2P_64
# set_property IOSTANDARD  SSTL12   [get_ports "DDR4_SODIMM_A2"] ;# Bank  64 VCCO - VCC1V2   - IO_L18P_T2U_N10_AD2P_64
# set_property PACKAGE_PIN AF15     [get_ports "DDR4_SODIMM_A3"] ;# Bank  64 VCCO - VCC1V2   - IO_L17N_T2U_N9_AD10N_64
# set_property IOSTANDARD  SSTL12   [get_ports "DDR4_SODIMM_A3"] ;# Bank  64 VCCO - VCC1V2   - IO_L17N_T2U_N9_AD10N_64
# set_property PACKAGE_PIN AF16     [get_ports "DDR4_SODIMM_A4"] ;# Bank  64 VCCO - VCC1V2   - IO_L17P_T2U_N8_AD10P_64
# set_property IOSTANDARD  SSTL12   [get_ports "DDR4_SODIMM_A4"] ;# Bank  64 VCCO - VCC1V2   - IO_L17P_T2U_N8_AD10P_64
# set_property PACKAGE_PIN AJ14     [get_ports "DDR4_SODIMM_A5"] ;# Bank  64 VCCO - VCC1V2   - IO_L16N_T2U_N7_QBC_AD3N_64
# set_property IOSTANDARD  SSTL12   [get_ports "DDR4_SODIMM_A5"] ;# Bank  64 VCCO - VCC1V2   - IO_L16N_T2U_N7_QBC_AD3N_64
# set_property PACKAGE_PIN AH14     [get_ports "DDR4_SODIMM_A6"] ;# Bank  64 VCCO - VCC1V2   - IO_L16P_T2U_N6_QBC_AD3P_64
# set_property IOSTANDARD  SSTL12   [get_ports "DDR4_SODIMM_A6"] ;# Bank  64 VCCO - VCC1V2   - IO_L16P_T2U_N6_QBC_AD3P_64
# set_property PACKAGE_PIN AF17     [get_ports "DDR4_SODIMM_A7"] ;# Bank  64 VCCO - VCC1V2   - IO_L15N_T2L_N5_AD11N_64
# set_property IOSTANDARD  SSTL12   [get_ports "DDR4_SODIMM_A7"] ;# Bank  64 VCCO - VCC1V2   - IO_L15N_T2L_N5_AD11N_64
# set_property PACKAGE_PIN AG18     [get_ports "DDR4_SODIMM_CK0_C"] ;# Bank  64 VCCO - VCC1V2   - IO_L14N_T2L_N3_GC_64
# set_property IOSTANDARD  DIFF_POD12 [get_ports "DDR4_SODIMM_CK0_C"] ;# Bank  64 VCCO - VCC1V2   - IO_L14N_T2L_N3_GC_64
# set_property PACKAGE_PIN AF18     [get_ports "DDR4_SODIMM_CK0_T"] ;# Bank  64 VCCO - VCC1V2   - IO_L14P_T2L_N2_GC_64
# set_property IOSTANDARD  DIFF_POD12 [get_ports "DDR4_SODIMM_CK0_T"] ;# Bank  64 VCCO - VCC1V2   - IO_L14P_T2L_N2_GC_64
# set_property PACKAGE_PIN AJ15     [get_ports "DDR4_SODIMM_CK1_C"] ;# Bank  64 VCCO - VCC1V2   - IO_L12N_T1U_N11_GC_64
# set_property IOSTANDARD  DIFF_POD12 [get_ports "DDR4_SODIMM_CK1_C"] ;# Bank  64 VCCO - VCC1V2   - IO_L12N_T1U_N11_GC_64
# set_property PACKAGE_PIN AJ16     [get_ports "DDR4_SODIMM_CK1_T"] ;# Bank  64 VCCO - VCC1V2   - IO_L12P_T1U_N10_GC_64
# set_property IOSTANDARD  DIFF_POD12 [get_ports "DDR4_SODIMM_CK1_T"] ;# Bank  64 VCCO - VCC1V2   - IO_L12P_T1U_N10_GC_64
# set_property PACKAGE_PIN AK17     [get_ports "DDR4_SODIMM_A8"] ;# Bank  64 VCCO - VCC1V2   - IO_L11N_T1U_N9_GC_64
# set_property IOSTANDARD  SSTL12   [get_ports "DDR4_SODIMM_A8"] ;# Bank  64 VCCO - VCC1V2   - IO_L11N_T1U_N9_GC_64
# set_property PACKAGE_PIN AJ17     [get_ports "DDR4_SODIMM_A9"] ;# Bank  64 VCCO - VCC1V2   - IO_L11P_T1U_N8_GC_64
# set_property IOSTANDARD  SSTL12   [get_ports "DDR4_SODIMM_A9"] ;# Bank  64 VCCO - VCC1V2   - IO_L11P_T1U_N8_GC_64
# set_property PACKAGE_PIN AK14     [get_ports "DDR4_SODIMM_A10"] ;# Bank  64 VCCO - VCC1V2   - IO_L10N_T1U_N7_QBC_AD4N_64
# set_property IOSTANDARD  SSTL12   [get_ports "DDR4_SODIMM_A10"] ;# Bank  64 VCCO - VCC1V2   - IO_L10N_T1U_N7_QBC_AD4N_64
# set_property PACKAGE_PIN AK15     [get_ports "DDR4_SODIMM_A11"] ;# Bank  64 VCCO - VCC1V2   - IO_L10P_T1U_N6_QBC_AD4P_64
# set_property IOSTANDARD  SSTL12   [get_ports "DDR4_SODIMM_A11"] ;# Bank  64 VCCO - VCC1V2   - IO_L10P_T1U_N6_QBC_AD4P_64
# set_property PACKAGE_PIN AL18     [get_ports "DDR4_SODIMM_A12"] ;# Bank  64 VCCO - VCC1V2   - IO_L9N_T1L_N5_AD12N_64
# set_property IOSTANDARD  SSTL12   [get_ports "DDR4_SODIMM_A12"] ;# Bank  64 VCCO - VCC1V2   - IO_L9N_T1L_N5_AD12N_64
# set_property PACKAGE_PIN AK18     [get_ports "DDR4_SODIMM_A13"] ;# Bank  64 VCCO - VCC1V2   - IO_L9P_T1L_N4_AD12P_64
# set_property IOSTANDARD  SSTL12   [get_ports "DDR4_SODIMM_A13"] ;# Bank  64 VCCO - VCC1V2   - IO_L9P_T1L_N4_AD12P_64
# set_property PACKAGE_PIN AL15     [get_ports "DDR4_SODIMM_BA0"] ;# Bank  64 VCCO - VCC1V2   - IO_L8N_T1L_N3_AD5N_64
# set_property IOSTANDARD  SSTL12   [get_ports "DDR4_SODIMM_BA0"] ;# Bank  64 VCCO - VCC1V2   - IO_L8N_T1L_N3_AD5N_64
# set_property PACKAGE_PIN AL16     [get_ports "DDR4_SODIMM_BA1"] ;# Bank  64 VCCO - VCC1V2   - IO_L8P_T1L_N2_AD5P_64
# set_property IOSTANDARD  SSTL12   [get_ports "DDR4_SODIMM_BA1"] ;# Bank  64 VCCO - VCC1V2   - IO_L8P_T1L_N2_AD5P_64
# set_property PACKAGE_PIN AM15     [get_ports "DDR4_SODIMM_CKE1"] ;# Bank  64 VCCO - VCC1V2   - IO_L7N_T1L_N1_QBC_AD13N_64
# set_property IOSTANDARD  SSTL12   [get_ports "DDR4_SODIMM_CKE1"] ;# Bank  64 VCCO - VCC1V2   - IO_L7N_T1L_N1_QBC_AD13N_64
# set_property PACKAGE_PIN AM16     [get_ports "DDR4_SODIMM_ODT1"] ;# Bank  64 VCCO - VCC1V2   - IO_L7P_T1L_N0_QBC_AD13P_64
# set_property IOSTANDARD  SSTL12   [get_ports "DDR4_SODIMM_ODT1"] ;# Bank  64 VCCO - VCC1V2   - IO_L7P_T1L_N0_QBC_AD13P_64
# set_property PACKAGE_PIN AL17     [get_ports "DDR4_SODIMM_CS1_B"] ;# Bank  64 VCCO - VCC1V2   - IO_T1U_N12_64
# set_property IOSTANDARD  SSTL12   [get_ports "DDR4_SODIMM_CS1_B"] ;# Bank  64 VCCO - VCC1V2   - IO_T1U_N12_64
# set_property PACKAGE_PIN AN16     [get_ports "DDR4_SODIMM_CS3_B"] ;# Bank  64 VCCO - VCC1V2   - IO_L6N_T0U_N11_AD6N_64
# set_property IOSTANDARD  SSTL12   [get_ports "DDR4_SODIMM_CS3_B"] ;# Bank  64 VCCO - VCC1V2   - IO_L6N_T0U_N11_AD6N_64
# set_property PACKAGE_PIN AN17     [get_ports "DDR4_SODIMM_CS2_B"] ;# Bank  64 VCCO - VCC1V2   - IO_L6P_T0U_N10_AD6P_64
# set_property IOSTANDARD  SSTL12   [get_ports "DDR4_SODIMM_CS2_B"] ;# Bank  64 VCCO - VCC1V2   - IO_L6P_T0U_N10_AD6P_64

# ----------------------------------------------------------------------------
# VRP / Power Reference
# ----------------------------------------------------------------------------
#set_property PACKAGE_PIN H14      [get_ports "VRP_68"] ;# Bank  68 VCCO - VADJ_FMC - IO_T0U_N12_VRP_68
#set_property IOSTANDARD  LVCMOSxx [get_ports "VRP_68"] ;# Bank  68 VCCO - VADJ_FMC - IO_T0U_N12_VRP_68
#set_property PACKAGE_PIN AP8      [get_ports "VRP_66"] ;# Bank  66 VCCO - VCC1V2   - IO_T0U_N12_VRP_66
#set_property IOSTANDARD  LVCMOSxx [get_ports "VRP_66"] ;# Bank  66 VCCO - VCC1V2   - IO_T0U_N12_VRP_66
#set_property PACKAGE_PIN AM20     [get_ports "VRP_65"] ;# Bank  65 VCCO - VCC1V2   - IO_T0U_N12_VRP_65
#set_property IOSTANDARD  LVCMOSxx [get_ports "VRP_65"] ;# Bank  65 VCCO - VCC1V2   - IO_T0U_N12_VRP_65
#set_property PACKAGE_PIN AP14     [get_ports "VRP_64"] ;# Bank  64 VCCO - VCC1V2   - IO_T0U_N12_VRP_64
# 3set_property IOSTANDARD  LVCMOSxx [get_ports "VRP_64"] ;# Bank  64 VCCO - VCC1V2   - IO_T0U_N12_VRP_64

# ----------------------------------------------------------------------------
# Other / Unclassified
# ----------------------------------------------------------------------------
# set_property PACKAGE_PIN AP3      [get_ports "GND"] ;# Bank 223 - MGTHRXN0_223
# set_property PACKAGE_PIN AN1      [get_ports "GND"] ;# Bank 223 - MGTHRXN1_223
# set_property PACKAGE_PIN AL1      [get_ports "GND"] ;# Bank 223 - MGTHRXN2_223
# set_property PACKAGE_PIN AK3      [get_ports "GND"] ;# Bank 223 - MGTHRXN3_223
# set_property PACKAGE_PIN AP4      [get_ports "GND"] ;# Bank 223 - MGTHRXP0_223
# set_property PACKAGE_PIN AN2      [get_ports "GND"] ;# Bank 223 - MGTHRXP1_223
# set_property PACKAGE_PIN AL2      [get_ports "GND"] ;# Bank 223 - MGTHRXP2_223
# set_property PACKAGE_PIN AK4      [get_ports "GND"] ;# Bank 223 - MGTHRXP3_223
# set_property PACKAGE_PIN AJ1      [get_ports "GND"] ;# Bank 224 - MGTHRXN0_224
# set_property PACKAGE_PIN AG1      [get_ports "GND"] ;# Bank 224 - MGTHRXN1_224
# set_property PACKAGE_PIN AF3      [get_ports "GND"] ;# Bank 224 - MGTHRXN2_224
# set_property PACKAGE_PIN AE1      [get_ports "GND"] ;# Bank 224 - MGTHRXN3_224
# set_property PACKAGE_PIN AJ2      [get_ports "GND"] ;# Bank 224 - MGTHRXP0_224
# set_property PACKAGE_PIN AG2      [get_ports "GND"] ;# Bank 224 - MGTHRXP1_224
# set_property PACKAGE_PIN AF4      [get_ports "GND"] ;# Bank 224 - MGTHRXP2_224
# set_property PACKAGE_PIN AE2      [get_ports "GND"] ;# Bank 224 - MGTHRXP3_224
# set_property PACKAGE_PIN AC1      [get_ports "GND"] ;# Bank 225 - MGTHRXN0_225
# set_property PACKAGE_PIN AB3      [get_ports "GND"] ;# Bank 225 - MGTHRXN1_225
# set_property PACKAGE_PIN AA1      [get_ports "GND"] ;# Bank 225 - MGTHRXN2_225
# set_property PACKAGE_PIN W1       [get_ports "GND"] ;# Bank 225 - MGTHRXN3_225
# set_property PACKAGE_PIN AC2      [get_ports "GND"] ;# Bank 225 - MGTHRXP0_225
# set_property PACKAGE_PIN AB4      [get_ports "GND"] ;# Bank 225 - MGTHRXP1_225
# set_property PACKAGE_PIN AA2      [get_ports "GND"] ;# Bank 225 - MGTHRXP2_225
# set_property PACKAGE_PIN W2       [get_ports "GND"] ;# Bank 225 - MGTHRXP3_225
# set_property PACKAGE_PIN V3       [get_ports "GND"] ;# Bank 226 - MGTHRXN0_226
# set_property PACKAGE_PIN U1       [get_ports "GND"] ;# Bank 226 - MGTHRXN1_226
# set_property PACKAGE_PIN R1       [get_ports "GND"] ;# Bank 226 - MGTHRXN2_226
# set_property PACKAGE_PIN V4       [get_ports "GND"] ;# Bank 226 - MGTHRXP0_226
# set_property PACKAGE_PIN U2       [get_ports "GND"] ;# Bank 226 - MGTHRXP1_226
# set_property PACKAGE_PIN R2       [get_ports "GND"] ;# Bank 226 - MGTHRXP2_226
# set_property PACKAGE_PIN G1       [get_ports "GND"] ;# Bank 227 - MGTHRXN3_227
# set_property PACKAGE_PIN G2       [get_ports "GND"] ;# Bank 227 - MGTHRXP3_227

