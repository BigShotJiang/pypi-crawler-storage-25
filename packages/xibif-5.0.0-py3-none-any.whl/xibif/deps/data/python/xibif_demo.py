"""
This file provides an easy example of basic usage of the
XibifConnection API.
"""

#############################################
# Basics                                    #
#############################################
from xibif_connection.api import XibifConnection

# you can obtain the IP and UUID of your board by
# observing the serial output during startup
IP = "192.168.1.10"  # multiple boards can connect to one host
UUID = 0x83DB3005  # the UUID verifies that you connect to the right board

board = XibifConnection(ip=IP, uuid=UUID)

# connect to the board using a socket
board.connect()

print(board.read_board_status())

# The following registers are available by default
# when you set up a XiBIF project.
for address in range(4):
    # AXI is byte-indexed, so reg1: 0x0, reg2: 0x4
    print(f"Reading register at address 0x{address*4:02X}: {board.read(address=address*4)}")

board.write(address=0x0C, value=100)
print(f"Register 0x0C={board.read(address=0x0C)}")

# the register at address 0x08 has its input connected
# to the output of register 0x0C
print(f"Register 0x08={board.read(address=0x08)}")

# reset the programmable logic on the FPGA
board.reset()

# end the connection gracefully
board.disconnect()


#############################################
# Registers with generated Registermap      #
#############################################
from regs import RegMap

board = XibifConnection(ip=IP, uuid=UUID)

# connect to the board using a socket
board.connect()

# Connect the generated RegisterMap to the board
regs = RegMap(board)

# The following registers are available by default
# when you set up a XiBIF project.
print(f"Reading register at address 0x08: {regs.register_1_bf.demo}")
print(f"Reading register at address 0x0C: {regs.register_2_bf.demo}")

regs.register_2_bf.demo = 42
print(f"Reading 0x0C={regs.register_2_bf.demo}")

# the register at address 0x08 has its input connected
# to the output of register 0x0C
print(f"Reading 0x08={regs.register_1_bf.demo}")

# end the connection gracefully
board.disconnect()


#############################################
# Context                                   #
#############################################
# alternatively, connect using a XibifSession to
# use Python contexts
from xibif_connection.api import XibifSession

with XibifSession(ip=IP, uuid=UUID) as board:
    # the connection to the board is automatically
    # established when entering a context
    for address in range(4):
        print(f"Reading register at address 0x{address*4:02X}: {board.read(address=address*4)}")

    board.write(address=0x0C, value=100)
    print(f"Register 0x0C={board.read(address=0x0C)}")
    print(f"Register 0x08={board.read(address=0x08)}")

    # the session is always disconnected automatically when
    # exiting the context

#############################################
# Streaming                                 #
#############################################
# and you probably also want to read/write larger chunks of data

try:
    import numpy as np
except ImportError:
    print("Numpy must be installed for streaming!")
    import sys

    sys.exit(1)

board = XibifConnection(ip=IP, uuid=UUID)
board.connect()

# ensure that there is no data in the stream FIFOs
board.flush_stream()

# generate a NumPy vector of N_WORDS random 32-bit integers
# the stream API operates on the uint32 datatype
N_WORDS = 100_000
tx = np.random.randint(0, 2**32, N_WORDS, dtype=np.uint32)
print(f"Writing {N_WORDS*4} bytes to the FPGA")
board.write_stream(tx)

# the default XiBIF project connects the read and write streams
# to form a loopback interface. This code below does not work if you
# have disconnected or disabled the streams
print(f"Reading {N_WORDS*4} bytes from the FPGA")
rx = np.array(board.read_stream(length=N_WORDS))

# compare TX and RX data
if np.any(rx != tx):
    print("Mismatch in transmitted and received data")
    print(rx[rx != tx])
else:
    print("Transmitted and received data match!")

board.disconnect()

# Find more examples in the xibif-connection repository!
# https://gitlab.com/xibif/xibif-connection
