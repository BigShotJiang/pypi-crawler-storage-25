/*
 * XiBIF_PhySpeed - PHY link speed helpers
 */

/*** Includes ******************************************************/
#include "XiBIF_PhySpeed.h"
#include <sleep.h>

/*** Externs *******************************************************/
extern u32 phymapemac0[32];
extern u32 phymapemac1[32];

/*** Function Definitions ******************************************/
/**
 * @brief Determines the speed for Xilinx PCS/PMA PHY.
 * @param xemacpsp Pointer to the XEmacPs instance.
 * @param phy_addr MDIO address of the PHY.
 * @return 10, 100, 1000 or XST_FAILURE.
 */
u32 get_Xilinx_pcs_pma_phy_speed(XEmacPs* xemacpsp, u32 phy_addr)
{

#if XPAR_GIGE_PCS_PMA_1000BASEX_CORE_PRESENT == 1 || XPAR_GIGE_PCS_PMA_SGMII_CORE_PRESENT == 1
    u16_t temp;
    u16 control;
    u16 status;
#endif

#if XPAR_GIGE_PCS_PMA_1000BASEX_CORE_PRESENT == 1
    XEmacPs_PhyWrite(xemacpsp, phy_addr, IEEE_PAGE_ADDRESS_REGISTER, 1);
    XEmacPs_PhyRead(xemacpsp, phy_addr, IEEE_PARTNER_ABILITIES_1_REG_OFFSET, &temp);
    if((temp & 0x0020) == 0x0020) {
        XEmacPs_PhyWrite(xemacpsp, phy_addr, IEEE_PAGE_ADDRESS_REGISTER, 0);
        return 1000;
    }
    else {
        XEmacPs_PhyWrite(xemacpsp, phy_addr, IEEE_PAGE_ADDRESS_REGISTER, 0);
        xil_printf("Link error, temp = %x\r\n", temp);
        return 0;
    }
#elif XPAR_GIGE_PCS_PMA_SGMII_CORE_PRESENT == 1
    xil_printf("Waiting for Link to be up; Polling for SGMII core Reg \r\n");
    XEmacPs_PhyRead(xemacpsp, phy_addr, IEEE_PARTNER_ABILITIES_1_REG_OFFSET, &temp);
    while(!(temp & 0x8000)) {
        XEmacPs_PhyRead(xemacpsp, phy_addr, IEEE_PARTNER_ABILITIES_1_REG_OFFSET, &temp);
    }
    if((temp & 0x0C00) == 0x0800) {
        return 1000;
    }
    else if((temp & 0x0C00) == 0x0400) {
        return 100;
    }
    else if((temp & 0x0C00) == 0x0000) {
        return 10;
    }
    else {
        xil_printf("get_IEEE_phy_speed(): Invalid speed bit value, Defaulting to "
                   "Speed = 10 Mbps\r\n");
        XEmacPs_PhyRead(xemacpsp, phy_addr, IEEE_CONTROL_REG_OFFSET, &temp);
        XEmacPs_PhyWrite(xemacpsp, phy_addr, IEEE_CONTROL_REG_OFFSET, 0x0100);
        return 10;
    }
#else
    (void)xemacpsp; // Remove unused warning
    (void)phy_addr; // Remove unused warning
#endif
    return 0;
}

/**
 * @brief Determines the PHY speed for TI PHYs.
 * @param xemacpsp Pointer to the XEmacPs instance.
 * @param phy_addr MDIO address of the PHY.
 * @return 10, 100, 1000 or XST_FAILURE.
 */
u32 get_TI_phy_speed(XEmacPs* xemacpsp, u32 phy_addr)
{
    u16 status_speed;

    XEmacPs_PhyRead(xemacpsp, phy_addr, PHY_STS, &status_speed);
    if((status_speed & 0xC000) == 0x8000) {
        return 1000;
    }
    else if((status_speed & 0xC000) == 0x4000) {
        return 100;
    }
    else {
        return 10;
    }

    return XST_SUCCESS;
}

/**
 * @brief Determines the PHY speed for Marvell PHYs.
 * @param xemacpsp Pointer to the XEmacPs instance.
 * @param phy_addr MDIO address of the PHY.
 * @return 10, 100, 1000 or XST_FAILURE.
 */
u32 get_Marvell_phy_speed(XEmacPs* xemacpsp, u32 phy_addr)
{
    u16 status_speed;
    u32 temp_speed;

    XEmacPs_PhyRead(xemacpsp, phy_addr, IEEE_SPECIFIC_STATUS_REG, &status_speed);
    if(status_speed & 0x400) {
        temp_speed = status_speed & IEEE_SPEED_MASK;

        if(temp_speed == IEEE_SPEED_1000)
            return 1000;
        else if(temp_speed == IEEE_SPEED_100)
            return 100;
        else
            return 10;
    }

    return XST_SUCCESS;
}

/**
 * @brief Determines the PHY speed for Realtek PHYs.
 * @param xemacpsp Pointer to the XEmacPs instance.
 * @param phy_addr MDIO address of the PHY.
 * @return 10, 100, 1000 or XST_FAILURE.
 */
u32 get_Realtek_phy_speed(XEmacPs* xemacpsp, u32 phy_addr)
{
    u16 control;
    u16 status;
    u16 status_speed;
    u32 temp_speed;
    u16 phy_identity;
    u32 timeout_counter = 0;
    u32 link_speed;

    //Identify PHY model
    XEmacPs_PhyRead(xemacpsp, phy_addr, PHY_IDENTIFIER_2_REG, &phy_identity);

    switch(phy_identity) {
    case PHY_REALTEK_RTL8211F: {
        xil_printf("Applying Zypo-Z7 Fix for Revision D. Thank you Digilent. \r\n");
        xil_printf("!!! Ignore previous Phy errors. !!! \r\n");
        xil_printf("Zypo-Z7 Rev D Fix: Start PHY autonegotiation \r\n");

        XEmacPs_PhyRead(xemacpsp, phy_addr, IEEE_AUTONEGO_ADVERTISE_REG, &control);
        control |= IEEE_ASYMMETRIC_PAUSE_MASK;
        control |= IEEE_PAUSE_MASK;
        control |= ADVERTISE_100;
        control |= ADVERTISE_10;
        XEmacPs_PhyWrite(xemacpsp, phy_addr, IEEE_AUTONEGO_ADVERTISE_REG, control);

        XEmacPs_PhyRead(xemacpsp, phy_addr, IEEE_1000_ADVERTISE_REG_OFFSET, &control);
        control |= ADVERTISE_1000;
        XEmacPs_PhyWrite(xemacpsp, phy_addr, IEEE_1000_ADVERTISE_REG_OFFSET, control);

        XEmacPs_PhyRead(xemacpsp, phy_addr, IEEE_CONTROL_REG_OFFSET, &control);
        control |= IEEE_CTRL_AUTONEGOTIATE_ENABLE;
        control |= IEEE_STAT_AUTONEGOTIATE_RESTART;
        XEmacPs_PhyWrite(xemacpsp, phy_addr, IEEE_CONTROL_REG_OFFSET, control);

        XEmacPs_PhyRead(xemacpsp, phy_addr, IEEE_CONTROL_REG_OFFSET, &control);
        control |= IEEE_CTRL_RESET_MASK;
        XEmacPs_PhyWrite(xemacpsp, phy_addr, IEEE_CONTROL_REG_OFFSET, control);

        while(1) {
            XEmacPs_PhyRead(xemacpsp, phy_addr, IEEE_CONTROL_REG_OFFSET, &control);
            if(control & IEEE_CTRL_RESET_MASK)
                continue;
            else
                break;
        }

        XEmacPs_PhyRead(xemacpsp, phy_addr, IEEE_STATUS_REG_OFFSET, &status);

        xil_printf("Zypo-Z7 Rev D Fix: Waiting for PHY to complete autonegotiation.\r\n");

        while(!(status & IEEE_STAT_AUTONEGOTIATE_COMPLETE)) {
            sleep(1);
            timeout_counter++;

            if(timeout_counter == 30) {
                xil_printf("Zypo-Z7 Rev D Fix: Auto negotiation error \r\n");
                return XST_FAILURE;
            }
            XEmacPs_PhyRead(xemacpsp, phy_addr, IEEE_STATUS_REG_OFFSET, &status);
        }
        xil_printf("Zypo-Z7 Rev D Fix: autonegotiation complete \r\n");

        //Switch to page 0xA43
        XEmacPs_PhyWrite(xemacpsp, phy_addr, RTL8211F_PAGSR, RTL8211F_PHYSR_PAGE);
        XEmacPs_PhyRead(xemacpsp, phy_addr, RTL8211F_PHYSR, &status_speed);

        //Switch back to default page
        XEmacPs_PhyWrite(xemacpsp, phy_addr, RTL8211F_PAGSR, 0);

        //If there is link
        if(status_speed & RTL8211F_PHYSR_LINK_MASK) {
            temp_speed = status_speed & RTL8211F_PHYSR_SPEED_MASK;

            if(temp_speed == RTL8211F_PHYSR_1000)
                link_speed = 1000;
            else if(temp_speed == RTL8211F_PHYSR_100)
                link_speed = 100;
            else
                link_speed = 10;

            xil_printf("Zypo-Z7 Rev D Fix: Set Operating Speed \r\n");
            XEmacPs_SetOperatingSpeed(xemacpsp, link_speed);
            /* Setting the operating speed of the MAC needs a delay. */
            {
                for(u32 wait = 0; wait < 20000; wait++)
                    ;
            }
            return link_speed;
        }
        break;
    }
    default: {
        XEmacPs_PhyRead(xemacpsp, phy_addr, IEEE_SPECIFIC_STATUS_REG, &status_speed);
        if(status_speed & 0x400) {
            temp_speed = status_speed & IEEE_SPEED_MASK;

            if(temp_speed == IEEE_SPEED_1000)
                return 1000;
            else if(temp_speed == IEEE_SPEED_100)
                return 100;
            else
                return 10;
        }
        break;
    }
    }

    return XST_FAILURE;
}

/**
 * @brief Determines the PHY speed for ADI ADIN1300.
 * @param xemacpsp Pointer to the XEmacPs instance.
 * @param phy_addr MDIO address of the PHY.
 * @return 10, 100, 1000 or XST_FAILURE.
 */
u32 get_Adi_phy_speed(XEmacPs* xemacpsp, u32 phy_addr)
{
    u16 status_speed;
    u32 temp_speed;

    XEmacPs_PhyRead(xemacpsp, phy_addr, ADIN1300_PHY_STS1, &status_speed);
    if(status_speed & ADIN1300_AN_DONE) {
        temp_speed = status_speed & ADIN1300_SPEED_MASK;

        if(temp_speed == ADIN1300_SPEED_1G)
            return 1000;
        else if(temp_speed == ADIN1300_SPEED_100M)
            return 100;
        else
            return 10;
    }

    return XST_SUCCESS;
}

/**
 * @brief Determines the current PHY link speed (Mbps).
 *
 * Reads PHY registers in a vendor-agnostic way and determines the current
 * link speed. Used by XiBIF to adjust clock dividers accordingly.
 *
 * @param xemacpsp Pointer to the XEmacPs instance of the active GEM.
 * @return 10, 100 or 1000 on success; XST_FAILURE on error.
 */
u32 get_IEEE_phy_speed(XEmacPs* xemacpsp)
{
    u16 phy_identity;
    u32 RetStatus;
    u32 phy_addr;
    u8 i;
    u32 phyfoundforemac0 = FALSE;
    u32 phyfoundforemac1 = FALSE;

    for(i = 31; i > 0; i--) {
        if(xemacpsp->Config.BaseAddress == XPAR_XEMACPS_0_BASEADDR) {
            if(phymapemac0[i] == TRUE) {
                phyfoundforemac0 = TRUE;
                phy_addr = i;
            }
        }
        else {
            if(phymapemac1[i] == TRUE) {
                phyfoundforemac1 = TRUE;
                phy_addr = i;
            }
        }
    }
    /* If no PHY was detected, use broadcast PHY address of 0 */
    if(xemacpsp->Config.BaseAddress == XPAR_XEMACPS_0_BASEADDR) {
        if(phyfoundforemac0 == FALSE)
            phy_addr = 0;
    }
    else {
        if(phyfoundforemac1 == FALSE)
            phy_addr = 0;
    }

    XEmacPs_PhyRead(xemacpsp, phy_addr, PHY_IDENTIFIER_1_REG, &phy_identity);
    if(phy_identity == PHY_TI_IDENTIFIER) {
        RetStatus = get_TI_phy_speed(xemacpsp, phy_addr);
    }
    else if(phy_identity == PHY_REALTEK_IDENTIFIER) {
        RetStatus = get_Realtek_phy_speed(xemacpsp, phy_addr);
    }
    else if(phy_identity == PHY_XILINX_PCS_PMA_ID1) {
        RetStatus = get_Xilinx_pcs_pma_phy_speed(xemacpsp, phy_addr);
    }
    else if(phy_identity == PHY_ADI_IDENTIFIER) {
        RetStatus = get_Adi_phy_speed(xemacpsp, phy_addr);
    }
    else {
        RetStatus = get_Marvell_phy_speed(xemacpsp, phy_addr);
    }

    return RetStatus;
}
