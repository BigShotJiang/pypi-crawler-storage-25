/*
 * XiBIF_Webserver.h
 *
 * Web server functionality for XiBIF.
 * Provides REST API for register access only (no static files).
 */

#ifndef XIBIF_WEBSERVER_H
#define XIBIF_WEBSERVER_H

/*** Includes ******************************************************/
#include "XiBIF.h"
#include "XiBIF_regs.h"
#include <FreeRTOS.h>
#include <ctype.h>
#include <errno.h>
#include <lwip/tcp.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <task.h>
#include <xil_types.h>

/**
 * @enum XiBIF_webKeepAlive_t
 * @brief Connection keep-alive mode for HTTP responses.
 */
typedef enum {
    XIBIF_WEB_CLOSE_CONNECTION = 0,
    XIBIF_WEB_KEEP_ALIVE = 1
} XiBIF_webKeepAlive_t;

/**
 * @enum XiBIF_webError_t
 * @brief HTTP error types for web server responses.
 */
typedef enum {
    XIBIF_WEB_ERR_BAD_REQUEST = 0,
    XIBIF_WEB_ERR_UNAUTHORIZED,
    XIBIF_WEB_ERR_NOT_FOUND,
    XIBIF_WEB_ERR_LENGTH_REQUIRED,
    XIBIF_WEB_ERR_INVALID_JSON,
    XIBIF_WEB_ERR_INVALID_PARAMS
} XiBIF_webError_t;

/**
 * @struct XiBIF_webErrorInfo_t
 * @brief HTTP error information structure.
 */
typedef struct {
    const char* status;
    const char* message;
} XiBIF_webErrorInfo_t;

/**
 * @brief Error information lookup table.
 */
static const XiBIF_webErrorInfo_t XiBIF_webErrorTable[] = {[XIBIF_WEB_ERR_BAD_REQUEST] = {"400 Bad Request", "Bad Request"}, [XIBIF_WEB_ERR_UNAUTHORIZED] = {"401 Unauthorized", "Invalid or missing bearer token"}, [XIBIF_WEB_ERR_NOT_FOUND] = {"404 Not Found", "Endpoint not found"}, [XIBIF_WEB_ERR_LENGTH_REQUIRED] = {"411 Length Required", "Length Required"}, [XIBIF_WEB_ERR_INVALID_JSON] = {"400 Bad Request", "Invalid JSON"}, [XIBIF_WEB_ERR_INVALID_PARAMS] = {"400 Bad Request", "Invalid width/lsb"}};

/**
 * @enum XiBIF_webMethod_t
 * @brief HTTP request methods supported by the web server.
 */
typedef enum {
    XIBIF_WEB_METHOD_GET = 0,
    XIBIF_WEB_METHOD_POST
} XiBIF_webMethod_t;

/*** Function Prototypes *******************************************/
/**
 * @brief Web server connection handler.
 *
 * Serves embedded web files directly from memory (no filesystem needed).
 * Supports GET requests for static files.
 * Supports POST requests for /register/read and /register/write with JSON body.
 *
 * @param p The socket descriptor (cast from (UINTPTR)) from which to read data.
 */
void XiBIF_webHandler(void* p);

/**
 * @brief XiBIF web own command handler.
 *
 * This function is called when an invalid webserver endpoint is accessed. It simply
 * sends a 404 Not Found error.
 *
 * @param type The HTTP method type (GET or POST).
 * @param url The requested URL.
 * @param size_url The size of the URL buffer.
 * @param body The request body (for POST requests).
 * @param size_body The size of the body buffer.
 * @param keep_alive Whether to keep the connection alive.
 * @param sd The socket descriptor from which the command was received.
 */
XiBIF_error_t XiBIF_webOwnCommandHandler(XiBIF_webMethod_t type, const char* url, u32 size_url, const char* body, u32 size_body, XiBIF_webKeepAlive_t keep_alive, int sd) __attribute__((weak));

#endif // XIBIF_WEBSERVER_H
