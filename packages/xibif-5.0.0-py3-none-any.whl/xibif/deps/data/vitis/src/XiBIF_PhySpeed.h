/*
 * XiBIF_PhySpeed - PHY link speed helpers
 */

#ifndef __XIBIF_PHYSPEED_H__
#define __XIBIF_PHYSPEED_H__

/*** Includes ******************************************************/
#include "xemacps.h"
#include "xil_printf.h"
#include "xparameters.h"

/*** PHY Register Defines ******************************************/
#define PHY_IDENTIFIER_1_REG 2
#define PHY_IDENTIFIER_2_REG 3

/*** PHY Vendor Identifiers ***************************************/
#define PHY_MARVELL_IDENTIFIER 0x0141
#define PHY_TI_IDENTIFIER 0x2000
#define PHY_ADI_IDENTIFIER 0x0283
#define PHY_REALTEK_IDENTIFIER 0x001c
#define PHY_XILINX_PCS_PMA_ID1 0x0174

/*** TI PHY specific registers ************************************/
#define PHY_REGCR 0x0D
#define PHY_ADDAR 0x0E
#define PHY_RGMIIDCTL 0x86
#define PHY_RGMIICTL 0x32
#define PHY_STS 0x11
#define PHY_TI_CR 0x10
#define PHY_TI_CFG4 0x31

#define PHY_REGCR_ADDR 0x001F
#define PHY_REGCR_DATA 0x401F
#define PHY_TI_CRVAL 0x5048
#define PHY_TI_CFG4RESVDBIT7 0x80

/*** ADI ADIN1300 PHY specific registers **************************/
#define ADIN1300_PHY_CTRL1 0x0012
#define ADIN1300_PHY_CTRL2 0x0016
#define ADIN1300_PHY_CTRL3 0x0017
#define ADIN1300_EXT_ADDR 0x0010
#define ADIN1300_EXT_DATA 0x0011
#define ADIN1300_PHY_STS1 0x001A

#define ADIN1300_RGMII_CFG 0xFF23
#define ADIN1300_RMII_CFG 0xFF24

#define ADIN1300_AUTO_MDI_EN 0x400
#define ADIN1300_MAN_MDIX_EN 0x200
#define ADIN1300_DIAG_CLK_EN 0x4

#define ADIN1300_LINKING_EN 0x2000

#define ADIN1300_RGMII_EN 0x0001
#define ADIN1300_RGMII_TXRX_TUNING_EN 0x0006
#define ADIN1300_RGMII_RX_DELAY_MASK 0x01C0
#define ADIN1300_RGMII_TX_DELAY_MASK 0x0038
#define ADIN1300_RGMII_RX_DELAY_VAL_2000PS 0x0
#define ADIN1300_RGMII_TX_DELAY_VAL_2000PS 0x0

#define ADIN1300_SPEED_RETRY_MASK 0x1C00
#define ADIN1300_SPEED_RETRY_FOUR 0x1000
#define ADIN1300_DOWNSPEED_EN 0x0C00

#define ADIN1300_AN_DONE 0x1000
#define ADIN1300_SPEED_MASK 0x0380
#define ADIN1300_SPEED_1G 0x0280
#define ADIN1300_SPEED_100M 0x0180
#define ADIN1300_SPEED_10M 0x0080

#define IEEE_CTRL_ISOLATE_DISABLE 0xFBFF
#define IEEE_SPEED_MASK 0xC000
#define IEEE_SPEED_1000 0x8000
#define IEEE_SPEED_100 0x4000
#define IEEE_SPECIFIC_STATUS_REG 17

/*** Realtek PHY specific registers *******************************/
#define PHY_REALTEK_RTL8211E 0xC915
#define PHY_REALTEK_RTL8211F 0xC916
#define RTL8211F_PAGSR (0x1f)
#define RTL8211F_PHYSR (0x1a)
#define RTL8211F_PHYSR_PAGE (0xa43)
#define RTL8211F_PHYSR_LINK_MASK (0x0004)
#define RTL8211F_PHYSR_SPEED_MASK (0x0030)
#define RTL8211F_PHYSR_1000 (0x0020)
#define RTL8211F_PHYSR_100 (0x0010)
#define RTL8211F_PHYSR_10 (0x0000)

/*** Platform base addresses **************************************/
#define ZYNQ_EMACPS_0_BASEADDR 0xE000B000
#define ZYNQ_EMACPS_1_BASEADDR 0xE000C000

#define ZYNQMP_EMACPS_0_BASEADDR 0xFF0B0000
#define ZYNQMP_EMACPS_1_BASEADDR 0xFF0C0000
#define ZYNQMP_EMACPS_2_BASEADDR 0xFF0D0000
#define ZYNQMP_EMACPS_3_BASEADDR 0xFF0E0000

#define GEM_VERSION_ZYNQMP 7

#define CRL_APB_GEM0_REF_CTRL 0xFF5E0050
#define CRL_APB_GEM1_REF_CTRL 0xFF5E0054
#define CRL_APB_GEM2_REF_CTRL 0xFF5E0058
#define CRL_APB_GEM3_REF_CTRL 0xFF5E005C

#define CRL_APB_GEM_DIV0_MASK 0x00003F00
#define CRL_APB_GEM_DIV0_SHIFT 8
#define CRL_APB_GEM_DIV1_MASK 0x003F0000
#define CRL_APB_GEM_DIV1_SHIFT 16

#define SLCR_LOCK_ADDR (XPS_SYS_CTRL_BASEADDR + 0x4)
#define SLCR_UNLOCK_ADDR (XPS_SYS_CTRL_BASEADDR + 0x8)
#define SLCR_GEM0_CLK_CTRL_ADDR (XPS_SYS_CTRL_BASEADDR + 0x140)
#define SLCR_GEM1_CLK_CTRL_ADDR (XPS_SYS_CTRL_BASEADDR + 0x144)
#define SLCR_LOCK_KEY_VALUE 0x767B
#define SLCR_UNLOCK_KEY_VALUE 0xDF0D
#define EMACPS_SLCR_DIV_MASK 0xFC0FC0FF

#define PQ_QUEUE_SIZE 4096

/*** IEEE define **************************************************/
#define ADVERTISE_10HALF 0x0020        /* Try for 10mbps half-duplex  */
#define ADVERTISE_1000XFULL 0x0020     /* Try for 1000BASE-X full-duplex */
#define ADVERTISE_10FULL 0x0040        /* Try for 10mbps full-duplex  */
#define ADVERTISE_1000XHALF 0x0040     /* Try for 1000BASE-X half-duplex */
#define ADVERTISE_100HALF 0x0080       /* Try for 100mbps half-duplex */
#define ADVERTISE_1000XPAUSE 0x0080    /* Try for 1000BASE-X pause    */
#define ADVERTISE_100FULL 0x0100       /* Try for 100mbps full-duplex */
#define ADVERTISE_1000XPSE_ASYM 0x0100 /* Try for 1000BASE-X asym pause */
#define ADVERTISE_100BASE4 0x0200      /* Try for 100mbps 4k packets  */
#define ADVERTISE_100_AND_10 (ADVERTISE_10FULL | ADVERTISE_100FULL | ADVERTISE_10HALF | ADVERTISE_100HALF)
#define ADVERTISE_100 (ADVERTISE_100FULL | ADVERTISE_100HALF)
#define ADVERTISE_10 (ADVERTISE_10FULL | ADVERTISE_10HALF)

#define ADVERTISE_1000 0x0300
#define IEEE_CONTROL_REG_OFFSET 0
#define IEEE_STATUS_REG_OFFSET 1
#define IEEE_AUTONEGO_ADVERTISE_REG 4
#define IEEE_1000_ADVERTISE_REG_OFFSET 9
#define IEEE_CTRL_RESET_MASK 0x8000
#define IEEE_CTRL_AUTONEGOTIATE_ENABLE 0x1000
#define IEEE_STAT_AUTONEGOTIATE_CAPABLE 0x0008
#define IEEE_STAT_AUTONEGOTIATE_COMPLETE 0x0020
#define IEEE_STAT_AUTONEGOTIATE_RESTART 0x0200
#define IEEE_ASYMMETRIC_PAUSE_MASK 0x0800
#define IEEE_PAUSE_MASK 0x0400

/*** Function Declarations ****************************************/
/**
 * @brief Determines the current PHY link speed (Mbps).
 *
 * Reads PHY registers in a vendor-agnostic way and determines the current
 * link speed. Used by XiBIF to adjust clock dividers accordingly.
 *
 * @param xemacpsp Pointer to the XEmacPs instance of the active GEM.
 * @return 10, 100 or 1000 on success; XST_FAILURE on error.
 */
u32 get_IEEE_phy_speed(XEmacPs* xemacpsp);
/**
 * @brief Determines the PHY speed for TI PHYs.
 * @param xemacpsp Pointer to the XEmacPs instance.
 * @param phy_addr MDIO address of the PHY.
 * @return 10, 100, 1000 or XST_FAILURE.
 */
u32 get_TI_phy_speed(XEmacPs* xemacpsp, u32 phy_addr);
/**
 * @brief Determines the PHY speed for Marvell PHYs.
 * @param xemacpsp Pointer to the XEmacPs instance.
 * @param phy_addr MDIO address of the PHY.
 * @return 10, 100, 1000 or XST_FAILURE.
 */
u32 get_Marvell_phy_speed(XEmacPs* xemacpsp, u32 phy_addr);
/**
 * @brief Determines the PHY speed for Realtek PHYs.
 * @param xemacpsp Pointer to the XEmacPs instance.
 * @param phy_addr MDIO address of the PHY.
 * @return 10, 100, 1000 or XST_FAILURE.
 */
u32 get_Realtek_phy_speed(XEmacPs* xemacpsp, u32 phy_addr);
/**
 * @brief Determines the PHY speed for ADI ADIN1300.
 * @param xemacpsp Pointer to the XEmacPs instance.
 * @param phy_addr MDIO address of the PHY.
 * @return 10, 100, 1000 or XST_FAILURE.
 */
u32 get_Adi_phy_speed(XEmacPs* xemacpsp, u32 phy_addr);
/**
 * @brief Determines the speed for Xilinx PCS/PMA PHY.
 * @param xemacpsp Pointer to the XEmacPs instance.
 * @param phy_addr MDIO address of the PHY.
 * @return 10, 100, 1000 or XST_FAILURE.
 */
u32 get_Xilinx_pcs_pma_phy_speed(XEmacPs* xemacpsp, u32 phy_addr);

/*** Type Declarations ********************************************/
#ifndef __XADAPTER_H_
/**
 * @enum ethernet_link_status
 * @brief Status of the Ethernet link.
 *
 * Mirror of the definition in netif/xadapter.h; only declared here if the
 * original header is not included.
 */
enum ethernet_link_status {
    ETH_LINK_UNDEFINED = 0, /**< status unknown */
    ETH_LINK_UP,            /**< link is up */
    ETH_LINK_DOWN,          /**< link is down */
    ETH_LINK_NEGOTIATING    /**< auto-negotiation in progress */
};
#endif

/* from netif/xadapter.h */
enum ethernet_link_status;

/* from netif/xpqueue.h */
/**
 * @brief Simple ring-buffer queue for Rx/Tx overflows.
 */
typedef struct {
    void* data[PQ_QUEUE_SIZE];
    int head, tail, len;
} pq_queue_t;

/* from netif/xemacpsif.h */
/**
 * @brief Internal state of the XEmacPs interface (excerpt).
 *
 * Replica of the structure from the lwIP Xilinx port; only the fields
 * used here are listed.
 */
typedef struct {
    XEmacPs emacps;

    /* queue to store overflow packets */
    pq_queue_t* recv_q;
    pq_queue_t* send_q;

    /* pointers to memory holding buffer descriptors (used only with SDMA) */
    void* rx_bdspace;
    void* tx_bdspace;

    unsigned int last_rx_frms_cntr;
    enum ethernet_link_status eth_link_status;
} xemacpsif_s;

#endif /* __XIBIF_PHYSPEED_H__ */
