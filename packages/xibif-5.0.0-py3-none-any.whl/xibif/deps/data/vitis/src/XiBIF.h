/*
 * XiBIF - Xilinx Board Interface
 *
 * XiBIF is a bridging IP between an Ethernet client, usually Python, and the PL part of Xilinx
 * FPGAs.
 *
 * Register Access
 * XiBIF provides register access using a simple protocol. The client can read and write registers.alignas
 * The registers are generated using corsair.
 *
 * Data Access
 * Two AXI-Stream busses provide high data throughput both from client to PL and reverse.
 */

#ifndef __XIBIF_H__
#define __XIBIF_H__

/*** Includes ******************************************************/
#include "FreeRTOS.h" // IWYU pragma: keep -- semphr.h needs FreeRTOS.h to be included before itself
#include "lwipopts.h"
#include "netif/xadapter.h" // IWYU pragma: keep - cannot be imported in XiBIF.c
#include "semphr.h"
#include "task.h"
#include "xparameters.h"
#if __has_include(<xiltimer.h>)
    #include <xiltimer.h>
#else
    #include <xtime_l.h>
#endif

/*** Global Defines ************************************************/
#include "XiBIF_PhySpeed.h"    // IWYU pragma: keep - Fix for PhySpeed
#include "XiBIF_regs.h"        // XiBIF User Register Defines
#include "XiBIF_stream_regs.h" // XiBIF Stream Register Defines
#include <xil_types.h>

#define REG_PORT 6
#define ECHO_PORT 7
#define WEB_PORT 80
#define MAX_PKT_SIZE (1 << 14)

#define XIBIF_RESTRICTED_COMMAND_ID_RANGE (128)

// Version ID of PL peripheral
// clang-format off
#define XIBIF_STREAM_VID                                                \
    (XIBIF_SREG_VERSION_MAJ_RESET << XIBIF_SREG_VERSION_MAJ_LSB |       \
     XIBIF_SREG_VERSION_MIN_RESET << XIBIF_SREG_VERSION_MIN_LSB |       \
     XIBIF_SREG_VERSION_PATCH_RESET << XIBIF_SREG_VERSION_PATCH_LSB |   \
     XIBIF_SREG_VERSION_REV_RESET << XIBIF_SREG_VERSION_REV_LSB)
// clang-format on

// Extract individual version fields
// clang-format off
#define XIBIF_VERSION_GET_MAJ(x)   (((x) & 0xFF000000) >> 24)
#define XIBIF_VERSION_GET_MIN(x)   (((x) & 0x00FF0000) >> 16)
#define XIBIF_VERSION_GET_PATCH(x) (((x) & 0x0000FF00) >> 8)
#define XIBIF_VERSION_GET_REV(x)   (((x) & 0x000000FF) >> 0)
// clang-format on

/**
 * An structure representing a XiBIF stream
 *
 * The structure contains the necessary data to perform
 * r/w operations on the stream.
 *
 * A stream constists of a hardware FIFO and memory mapped to RAM.
 */
typedef struct XiBIF_stream {
    u32 highAddress; /**< upper address of the stream memory region in RAM*/
    u32 lowAddress;  /**< lower address of the stream memory region in RAM */
    u32 fifoDepth;   /**< depth of the hardware FIFO */
    u8 enabled;      /**< indicates whether the stream is enabled */
    u32 size;        /**< Size of the memory region. Precomputed because it is not expected to change during operation.*/
} XiBIF_stream_t;

/**
* @brief Structure representing a XiBIF peripheral.
*/
typedef struct XiBIF_peri {
    volatile xibif_sreg_t* streamRegs; /**< Device base address for stream */
    volatile xibif_reg_t* userRegs;    /**< Device base address for register */

    u32 registerVersion; /**< version of the user register peripheral*/
    u32 streamVersion;   /**< version of the stream register peripheral*/
    u32 registerUuid;    /**< UUID of the user register peripheral*/
    u32 streamUuid;      /**< UUID of the stream register peripheral*/

    XiBIF_stream_t pc2plStream; /**< PC->PL stream */
    XiBIF_stream_t pl2pcStream; /**< PL->PC stream */

    u32 initialised;         /**< Peripheral initialised flag */
    SemaphoreHandle_t mutex; /**< Semaphore for write access */
    u8 ethernetLink;         /**< Signalizes if the ethernet link is up or down */
    u8 enableDebugOutput;    /**< Signalizes if debug output shall be printed or not */
} XiBIF_peri_t;

/**
 * @enum XiBIF_cmd_t
 * @brief XiBIF command identifiers.
 *
 * Defines all command types supported by the XiBIF interface.
 */
typedef enum {
    XCMD_STATUS = 0,          /**< Retrieve the current XiBIF status. */
    XCMD_STREAM_FLUSH = 1,    /**< Flush the specified stream. */
    XCMD_REG_READ = 2,        /**< Read a register value. */
    XCMD_REG_WRITE = 3,       /**< Write a value to a register. */
    XCMD_STREAM_READ = 4,     /**< Read data from a stream. */
    XCMD_STREAM_READ_ALL = 5, /**< Read all available data from a stream. */
    XCMD_STREAM_WRITE = 6,    /**< Write data to a stream. */
    XCMD_BITSTREAM_WRITE = 7, /**< Write a bitstream. */
    XCMD_STATUS_PRINT = 8,    /**< Print the current status information. */
    XCMD_DBG_PRINT_EN = 9,    /**< Enable debug output. */
    XCMD_SOFT_RESET = 10,     /**< Perform a software reset. */
    XCMD_AXI_READ = 11,       /**< Read data from a connected AXI block. */
    XCMD_AXI_WRITE = 12,      /**< Write data to a connected AXI block. */
    XCMD_REGMAP_GET = 13,     /**< Retrieve the register map. */
    XCMD_PERFORMANCE = 14     /**< Execute a performance test */
} XiBIF_cmd_t;

/**
 * @enum XiBIF_error_t
 * @brief XiBIF error codes.
 *
 * Defines status codes in the XiBIF software including success and errors.
 */
typedef enum {
    XIB_OK = 0,       /**< No error */
    XIB_ERROR = 1,    /**< Generic error type */
    XIB_ENODATA = 2,  /**< Tried to read data from socket but no data available */
    XIB_EVERSION = 3, /**< A hardware/software version mismatch that prevents operation */
    XIB_EINIT = 4     /**< An error occured during init */
} XiBIF_error_t;

/**
 * @enum XiBIF_response_status_t
 * @brief XiBIF response status codes.
 * 
 * Defines status codes for responses sent back to the client after processing a command, indicating
 * whether the command was executed successfully, if it was unauthorized, or if the command is not implemented.
 */
typedef enum {
    XRESP_OK = 0,                      /**< Command executed successfully. */
    XRESP_UNAUTHORIZED = 1,            /**< Command execution not authorized. */
    XRESP_COMMAND_NOT_IMPLEMENTED = 2, /**< Command is not implemented. */
    XRESP_FAILED = 3,                  /**< Command execution failed due to an error. */
    XRESP_INVALID_LENGTH = 4           /**< Command execution failed due to invalid payload length. */
} XiBIF_response_status_t;

/**
 * @enum XiBIF_axi_access_t
 * @brief Enumerates the possible AXI access statuses in the XiBIF system.
 *
 * This enumeration defines various statuses that can occur during AXI access
 * operations, including success, access violations, and specific error codes.
 *
 */
typedef enum {
    AXI_OK = 0,                 /**< No error */
    AXI_EACCRANGE = 1,          /**< AXI access outside allowed range */
    AXI_EXIBRANGE = 2,          /**< AXI access inside XiBIF range */
    AXI_EFIREWALL = 3,          /**< AXI firewall error */
    AXI_EFIREWALL_DATACODE = 4, /**< AXI firewall error with data DECODEE3_DEADFA11 */
    AXI_EALIGN = 5              /**< Address not aligned */
} XiBIF_axi_access_t;

/*** Defines for bitstream (Starting from Version 2024.1) ************************************************/
#ifndef XPAR_XDCFG_0_DEVICE_ID
    #define XPAR_XDCFG_0_DEVICE_ID XPAR_DEVCFG_BASEADDR
#endif

/*** Defines for clock frequency (Vitis 2023) ***********************/
#ifndef XPAR_CPU_CORE_CLOCK_FREQ_HZ
    #if defined(PLATFORM_ZYNQ)
        #define XPAR_CPU_CORE_CLOCK_FREQ_HZ XPAR_CPU_CORTEXA9_CORE_CLOCK_FREQ_HZ
    #elif defined(PLATFORM_ZYNQMP)
        #define XPAR_CPU_CORE_CLOCK_FREQ_HZ XPAR_PSU_CORTEXA53_0_CPU_CLK_FREQ_HZ
    #else
        #error "Platform not supported"
    #endif
#endif

/*** Function Prototypes *******************************************/

XiBIF_peri_t* XiBIF_getPeri();

// Setup
void XiBIF_setupMainTask();
void XiBIF();
XiBIF_error_t XiBIF_init(XiBIF_peri_t* peri, UINTPTR hw_base_stream, UINTPTR hw_base_reg);
XiBIF_error_t XiBIF_initPl2PcMemory(XiBIF_peri_t* peri, u32 base, u32 size);
XiBIF_error_t XiBIF_initPc2PlMemory(XiBIF_peri_t* peri, u32 base, u32 size);
XiBIF_error_t XiBIF_programBitstream(int sd, u32 length);

// Stream
XiBIF_error_t XiBIF_readStream(int sd, u32 length);
XiBIF_error_t XiBIF_writeStream(int sd, u32 length);
u32 XiBIF_streamGetHead(XiBIF_peri_t* peri, u32** head);
u32 XiBIF_streamGetTail(XiBIF_peri_t* peri, u32** tail);
u32 XiBIF_getFromPcSwFifoOcc(XiBIF_peri_t* peri);
u32 XiBIF_getToPcSwFifoOcc(XiBIF_peri_t* peri);

// Register
u32 XiBIF_getReg(XiBIF_peri_t* peri, u32 reg);
void XiBIF_setReg(XiBIF_peri_t* peri, u32 reg, u32 data);

// AXI Access
void XiBIF_getAXI(XiBIF_peri_t* peri, u32 addr, u32* data);
void XiBIF_setAXI(XiBIF_peri_t* peri, u32 addr, u32 value, u32 mask, u32* data);

// Network
void XiBIF_listener(void* p);
void XiBIF_dhcp_timer(struct netif* netif);
void XiBIF_resetrx(struct netif* netif);
void XiBIF_ledBlink(void* p);
void XiBIF_checkCon();
XiBIF_error_t XiBIF_writeRegistermap(int sd, XTime start_time);
void XiBIF_printIp(char* msg, ip_addr_t* ip) __attribute__((weak));
void XiBIF_printIpSettings(ip_addr_t* ip, ip_addr_t* mask, ip_addr_t* gw) __attribute__((weak));
void XiBIF_printVersion(const char* prefix, u32 version);
void XiBIF_printBuildTimestamp(const char* prefix, u32 timestamp);

// Checks
XiBIF_error_t XiBIF_checkStreamVersion(XiBIF_peri_t* peri);
XiBIF_error_t XiBIF_checkRegisterVersion(XiBIF_peri_t* peri);
XiBIF_error_t XiBIF_checkUUID(XiBIF_peri_t* peri);

XiBIF_error_t XiBIF_ownCommandHandler(u32 cmd, u32 length, int sd, XTime start_time) __attribute__((weak));

// Socket
XiBIF_error_t XiBIF_readSocketData(int sd, void* buf, size_t len);
XiBIF_error_t XiBIF_writeSocketData(int sd, void* buf, size_t len);
XiBIF_error_t XiBIF_writeResponse(int sd, XiBIF_cmd_t cmd, u32 length, XiBIF_response_status_t status, XTime start_time);
XiBIF_error_t XiBIF_readDummy(int sd, u32 length);

// Default debugging messages via UART.
// clang-format off
#define DBG_PRINT(...)\
    { \
        const XiBIF_peri_t* periDebug = XiBIF_getPeri(); \
        if(periDebug->enableDebugOutput) { \
            xil_printf("%d: ", __LINE__); \
            xil_printf(__VA_ARGS__); \
        } \
    }
// clang-format on

#endif
