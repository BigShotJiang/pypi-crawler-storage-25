#ifndef __MAIN_H
#define __MAIN_H

/*** Function Prototypes *******************************************/
void XiBIF_startUp() __attribute__((weak));

#endif