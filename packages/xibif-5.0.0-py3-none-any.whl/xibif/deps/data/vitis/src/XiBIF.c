/*
 * XiBIF - Xilinx Board Interface
 *
 * XiBIF is a bridging IP between an Ethernet client, usually Python, and the PL part of Xilinx
 * FPGAs.
 *
 * Register Access
 * XiBIF provides register access using a simple protocol. The client can read and write registers.alignas
 * The registers are generated using corsair.
 *
 * Data Access
 * Two AXI-Stream busses provide high data throughput both from client to PL and reverse.
 */
#include "XiBIF.h"
#include "XiBIF_Webserver.h"
#include "XiBIF_regs.h"
#include "XiBIF_settings.h"
#include "XiBIF_stream_regs.h"
#include "xemacps.h"
#include "xgpiops.h"
#include "xil_printf.h"
#include <sleep.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <xil_cache.h>
#include <xil_io.h>
#include <xil_printf.h>
#include <xil_types.h>
#include <xparameters.h>

#include "lwip/dhcp.h"
#include "lwip/init.h"
#include "lwip/sockets.h"
#ifdef PLATFORM_ZYNQ
    #include "xdevcfg.h"
#endif

#ifdef PLATFORM_ZYNQMP
    #include "xilfpga.h"
    #include "xilfpga_pcap.h"
#endif

// Define AXI_FIREWALL Stuff
#define AXI_FIREWALL_MI_SIDE_FAULT_STATUS (XPAR_AXI_FIREWALL_BASEADDR + 0x00)
#define AXI_FIREWALL_MI_SIDE_SOFT_FAULT_STATUS (XPAR_AXI_FIREWALL_BASEADDR + 0x04)
#define AXI_FIREWALL_MI_UNBLOCK_CONTROL (XPAR_AXI_FIREWALL_BASEADDR + 0x08)
#define AXI_FIREWALL_MAX_CONTINUOUS_RTRANSFERS_WAITS (XPAR_AXI_FIREWALL_BASEADDR + 0x30)
#define AXI_FIREWALL_MAX_WRITE_TO_BVALID_WAITS (XPAR_AXI_FIREWALL_BASEADDR + 0x34)
#define AXI_FIREWALL_MAX_ARREADY_WAITS (XPAR_AXI_FIREWALL_BASEADDR + 0x38)
#define AXI_FIREWALL_MAX_AWREADY_WAITS (XPAR_AXI_FIREWALL_BASEADDR + 0x3C)
#define AXI_FIREWALL_MAX_WREADY_WAITS (XPAR_AXI_FIREWALL_BASEADDR + 0x40)
#define AXI_FIREWALL_SI_SIDE_FAULT_STATUS (XPAR_AXI_FIREWALL_BASEADDR + 0x100)
#define AXI_FIREWALL_SI_UNBLOCK_CONTROL (XPAR_AXI_FIREWALL_BASEADDR + 0x108)
#define AXI_FIREWALL_MAX_CONTINUOUS_WTRANSFERS_WAITS (XPAR_AXI_FIREWALL_BASEADDR + 0x130)
#define AXI_FIREWALL_MAX_WVALID_TO_AWVALID_WAITS (XPAR_AXI_FIREWALL_BASEADDR + 0x134)
#define AXI_FIREWALL_MAX_RREADY_WAITS (XPAR_AXI_FIREWALL_BASEADDR + 0x138)
#define AXI_FIREWALL_MAX_BREADY_WAITS (XPAR_AXI_FIREWALL_BASEADDR + 0x13C)
#define AXI_FIREWALL_GLOBAL_INTERRUPT (XPAR_AXI_FIREWALL_BASEADDR + 0x200)
#define AXI_FIREWALL_MI_INTERRUPT (XPAR_AXI_FIREWALL_BASEADDR + 0x204)
#define AXI_FIREWALL_SI_INTERRUPT (XPAR_AXI_FIREWALL_BASEADDR + 0x208)
#define AXI_FIREWALL_TIMEOUT XIBIF_AXI_FIREWALL_TIMEOUT_CLOCKS

#if defined(PLATFORM_ZYNQ)
    #define XIBIF_AXI_ACCESS_START_RANGE 0x40000000
    #define XIBIF_AXI_ACCESS_STOP_RANGE 0x4FFFFFFF
#elif defined(PLATFORM_ZYNQMP)
    #define XIBIF_AXI_ACCESS_START_RANGE 0xA0000000
    #define XIBIF_AXI_ACCESS_STOP_RANGE 0xAFFFFFFF
#else
    #define XIBIF_AXI_ACCESS_START_RANGE 0xFFFFFFFF
    #define XIBIF_AXI_ACCESS_STOP_RANGE 0x00000000
#endif

// #undef LWIP_DHCP

// Defines for build time and date, set by the build system
#define BUILD_SEC ((__TIME__[6] - '0') * 10 + (__TIME__[7] - '0'))
#define BUILD_MIN ((__TIME__[3] - '0') * 10 + (__TIME__[4] - '0'))
#define BUILD_HOUR ((__TIME__[0] - '0') * 10 + (__TIME__[1] - '0'))

#define BUILD_DAY ((__DATE__[4] == ' ' ? 0 : (__DATE__[4] - '0')) * 10 + (__DATE__[5] - '0'))
#define BUILD_YEAR (((__DATE__[9] - '0') * 10 + (__DATE__[10] - '0')))
// clang-format off
#define BUILD_MONTH \
( \
 (__DATE__[0]=='J' && __DATE__[1]=='a' && __DATE__[2]=='n') ? 1  : \
 (__DATE__[0]=='F') ? 2  : \
 (__DATE__[0]=='M' && __DATE__[2]=='r') ? 3  : \
 (__DATE__[0]=='A' && __DATE__[1]=='p') ? 4  : \
 (__DATE__[0]=='M' && __DATE__[2]=='y') ? 5  : \
 (__DATE__[0]=='J' && __DATE__[2]=='n') ? 6  : \
 (__DATE__[0]=='J' && __DATE__[2]=='l') ? 7  : \
 (__DATE__[0]=='A' && __DATE__[2]=='g') ? 8  : \
 (__DATE__[0]=='S') ? 9  : \
 (__DATE__[0]=='O') ? 10 : \
 (__DATE__[0]=='N') ? 11 : \
 12 \
)
// clang-format on

// clang-format off
#define BUILD_TIMESTAMP \
( ((uint32_t)(BUILD_DAY  & 0x1F) << 27) | \
  ((uint32_t)(BUILD_MONTH& 0x0F) << 23) | \
  ((uint32_t)(BUILD_YEAR & 0x3F) << 17) | \
  ((uint32_t)(BUILD_HOUR & 0x1F) << 12) | \
  ((uint32_t)(BUILD_MIN  & 0x3F) << 6 ) | \
  ((uint32_t)(BUILD_SEC  & 0x3F))  \
)
// clang-format on

typedef struct XiBIFListenConfig {
    u32 port;               // Listen to port
    char* name;             // Thread name
    void (*handler)(void*); // Thread spawned for each connection
    u32 stackSize;
    u32 prio;
} XiBIF_ListenConfig_t;

static XiBIF_peri_t xibif_peri;

static struct netif server_netif;

// Listener configs must outlive XiBIF task stack
static XiBIF_ListenConfig_t regConf;
static XiBIF_ListenConfig_t echoConf;
static XiBIF_ListenConfig_t webConf;

/*** Function Declaration ******************************************/
void cmd_con(void* p);
void echo_con(void* p);

/*** Function Declaration for xilinx function **********************/
void xemacpsif_resetrx_on_no_rxdata(struct netif* netif);

/*** Local Functions ***********************************************/

/**
 * @brief Computes the minimum of two unsigned 32-bit integers.
 *
 * This function takes two unsigned 32-bit integers as input and returns the
 * smaller of the two.
 *
 * @param a The first unsigned 32-bit integer.
 * @param b The second unsigned 32-bit integer.
 * @return The smaller of the two unsigned 32-bit integers.
 */
static inline u32 min(u32 a, u32 b)
{
    if(a < b)
        return a;
    else
        return b;
}

/**
 * @brief Prints the IP address with a custom message.
 *
 * This function takes a custom message and an IP address, and prints them
 * together in a formatted manner.
 *
 * @param msg A pointer to a character array containing the custom message.
 * @param ip A pointer to an ip_addr_t structure containing the IP address.
 */
__attribute__((weak)) void XiBIF_printIp(char* msg, ip_addr_t* ip)
{
    xil_printf(msg);
    xil_printf("%d.%d.%d.%d\n\r", ip4_addr1(ip), ip4_addr2(ip), ip4_addr3(ip), ip4_addr4(ip));
}

/**
 * @brief Prints the IP settings including IP address, subnet mask, and gateway.
 *
 * @param ip Pointer to the IP address structure.
 * @param mask Pointer to the subnet mask structure.
 * @param gw Pointer to the gateway address structure.
 */
__attribute__((weak)) void XiBIF_printIpSettings(ip_addr_t* ip, ip_addr_t* mask, ip_addr_t* gw)
{
    XiBIF_printIp("Board IP: ", ip);
    XiBIF_printIp("Netmask : ", mask);
    XiBIF_printIp("Gateway : ", gw);
}

/*** Function Definition *******************************************/
/**
 * @brief Sets the link speed for the ethernet
 *
 * workaround for xilinx bug, see:
 * https://gitlab.com/xibif/xibif/-/merge_requests/302
 */
static void XiBIF_FixLinkSpeed(struct netif* netif)
{
    struct xemac_s* xemac = (struct xemac_s*)(netif->state);
    xemacpsif_s* xemacpsif = (xemacpsif_s*)(xemac->state);
    XEmacPs* xemacpsp = &(xemacpsif->emacps);

#if defined(PLATFORM_ZYNQ)
    u32 SlcrDiv0 = 0;
    u32 SlcrDiv1 = 0;
    u32 SlcrTxClkCntrl;
    u32 slcrBaseAddress = SLCR_GEM0_CLK_CTRL_ADDR; // cppcheck-suppress unreadVariable
#elif defined(PLATFORM_ZYNQMP)
    u32 CrlApbDiv0 = 0;
    u32 CrlApbDiv1 = 0;
    u32 CrlApbGemCtrl;
    u32 CrlApbBaseAddr = CRL_APB_GEM0_REF_CTRL;
#endif
    u32 gigeversion;
    u32 link_speed = get_IEEE_phy_speed(xemacpsp);

    if(link_speed == 1000) {
        xil_printf("Update Phy Speed to 1000Mbit \r\n");
#if defined(PLATFORM_ZYNQ)
        SlcrDiv0 = 8;
        SlcrDiv1 = 1;
#elif defined(PLATFORM_ZYNQMP)
        CrlApbDiv0 = 12;
        CrlApbDiv1 = 1;
#endif
    }
    else if(link_speed == 100) {
        xil_printf("Update Phy Speed to 100Mbit \r\n");
#if defined(PLATFORM_ZYNQ)
        SlcrDiv0 = 8;
        SlcrDiv1 = 5;
#elif defined(PLATFORM_ZYNQMP)
        CrlApbDiv0 = 60;
        CrlApbDiv1 = 1;
#endif
    }
    else if(link_speed != XST_FAILURE) {
        xil_printf("Update Phy Speed to 10Mbit \r\n");
#if defined(PLATFORM_ZYNQ)
        SlcrDiv0 = 8;
        SlcrDiv1 = 50;
#elif defined(PLATFORM_ZYNQMP)
        CrlApbDiv0 = 60;
        CrlApbDiv1 = 10;
#endif
    }
    else {
        xil_printf("Could not read Phy Speed.\r\n");
        return;
    }

#if defined(PLATFORM_ZYNQ)
    // Zybo Z20 Rev D Workaround
    if(link_speed != XST_FAILURE) {
        netif_set_link_up(netif);
        xemacpsif->eth_link_status = ETH_LINK_UP;
    }
#endif

    gigeversion = ((Xil_In32(XPAR_XEMACPS_0_BASEADDR + 0xFC)) >> 16) & 0xFFF;

#if defined(PLATFORM_ZYNQ)
    if(gigeversion == 2) {
        if(XPAR_XEMACPS_0_BASEADDR == ZYNQ_EMACPS_0_BASEADDR) {
            slcrBaseAddress = SLCR_GEM0_CLK_CTRL_ADDR;
        }
        else {
            slcrBaseAddress = SLCR_GEM1_CLK_CTRL_ADDR;
        }

        // SLCR Unlock
        Xil_Out32(SLCR_UNLOCK_ADDR, SLCR_UNLOCK_KEY_VALUE);

        // Clock Configuration
        SlcrTxClkCntrl = Xil_In32(slcrBaseAddress);
        SlcrTxClkCntrl &= EMACPS_SLCR_DIV_MASK;
        SlcrTxClkCntrl |= (SlcrDiv1 << 20);
        SlcrTxClkCntrl |= (SlcrDiv0 << 8);
        Xil_Out32(slcrBaseAddress, SlcrTxClkCntrl);

        // SCLR Lock
        Xil_Out32(SLCR_LOCK_ADDR, SLCR_LOCK_KEY_VALUE);
    }
#elif defined(PLATFORM_ZYNQMP)
    if(gigeversion == GEM_VERSION_ZYNQMP) {
        if(XPAR_XEMACPS_0_BASEADDR == ZYNQMP_EMACPS_0_BASEADDR) {
            CrlApbBaseAddr = CRL_APB_GEM0_REF_CTRL;
        }
        else if(XPAR_XEMACPS_0_BASEADDR == ZYNQMP_EMACPS_1_BASEADDR) {
            CrlApbBaseAddr = CRL_APB_GEM1_REF_CTRL;
        }
        else if(XPAR_XEMACPS_0_BASEADDR == ZYNQMP_EMACPS_2_BASEADDR) {
            CrlApbBaseAddr = CRL_APB_GEM2_REF_CTRL;
        }
        else if(XPAR_XEMACPS_0_BASEADDR == ZYNQMP_EMACPS_3_BASEADDR) {
            CrlApbBaseAddr = CRL_APB_GEM3_REF_CTRL;
        }

    // Clock Configuration
    #if defined(__aarch64__) && (EL1_NONSECURE == 1)
        XSmc_OutVar RegRead;
        RegRead = Xil_Smc(MMIO_READ_SMC_FID, (u64)(CrlApbBaseAddr), 0, 0, 0, 0, 0, 0);
        CrlApbGemCtrl = RegRead.Arg0 >> 32;
    #else
        CrlApbGemCtrl = Xil_In32(CrlApbBaseAddr);
    #endif
        CrlApbGemCtrl &= ~CRL_APB_GEM_DIV0_MASK;
        CrlApbGemCtrl |= CrlApbDiv0 << CRL_APB_GEM_DIV0_SHIFT;
        CrlApbGemCtrl &= ~CRL_APB_GEM_DIV1_MASK;
        CrlApbGemCtrl |= CrlApbDiv1 << CRL_APB_GEM_DIV1_SHIFT;
    #if defined(__aarch64__) && (EL1_NONSECURE == 1)
        Xil_Smc(MMIO_WRITE_SMC_FID, (u64)(CrlApbBaseAddr) | ((u64)(0xFFFFFFFF) << 32), (u64)CrlApbGemCtrl, 0, 0, 0, 0, 0);
        do {
            RegRead = Xil_Smc(MMIO_READ_SMC_FID, (u64)(CrlApbBaseAddr), 0, 0, 0, 0, 0, 0);
        } while((RegRead.Arg0 >> 32) != CrlApbGemCtrl);
    #else
        Xil_Out32(CrlApbBaseAddr, CrlApbGemCtrl);
    #endif
    }
#endif
    else {
        // Unsupported
        xil_printf("Could not set Phy Speed --> Unsupported. \r\n");
    }
}

/**
 * @brief Retrieves the peripheral interface.
 *
 * This function returns a pointer to the XiBIF peripheral interface.
 *
 * @return XiBIF_peri_t* Pointer to the XiBIF peripheral interface.
 */
XiBIF_peri_t* XiBIF_getPeri()
{ return &xibif_peri; }

/**
 * @brief Resets the FIFO of the specified XiBIF peripheral.
 *
 * This function performs a quick reset of the FIFO by writing to the reset
 * register of the specified XiBIF peripheral.
 *
 * @param peri Pointer to the XiBIF peripheral structure.
 */
static inline void XiBIF_resetFifo(XiBIF_peri_t* peri)
{
    // Reset only if at least one stream is enabled
    if(peri->pc2plStream.enabled == 0 && peri->pl2pcStream.enabled == 0) {
        xil_printf("No stream enabled. Not resetting.");
        return;
    }

    // Reset all blocks
    peri->streamRegs->RESET_bf.RESET = 0; // Do a quick reset

    // Reset head and tail pointers
    peri->streamRegs->FIFO_TO_PC_5_bf.TAIL = peri->pl2pcStream.lowAddress;
    peri->streamRegs->FIFO_FROM_PC_4_bf.HEAD = peri->pc2plStream.lowAddress;

    // Reset error flag
    peri->streamRegs->FIFO_FROM_PC_3_bf.ERROR_MEMFULL = 0;

    // Wait until everything is reset
    while(peri->streamRegs->RESET_bf.RESETDONE == 0) {
        asm("NOP");
    }

    peri->streamRegs->RESET_bf.RESET = 1;
    while(peri->streamRegs->RESET_bf.RESETDONE == 1) {
        asm("NOP");
    }
}

/**
 * @brief Advances the tail pointer of the stream by a specified number of
 * words.
 *
 * This function updates the tail pointer of the stream by the given number of
 * words. It reads the current tail pointer value, updates it, and then verifies
 * if the update was successful. If there is a mismatch in the expected tail
 * pointer value, it logs an error message.
 *
 * @param peri Pointer to the XiBIF peripheral structure.
 * @param n The number of units to advance the tail pointer.
 */
static inline void XiBIF_streamAdvanceTail(XiBIF_peri_t* peri, u32 n)
{
    u32 tail = peri->streamRegs->FIFO_TO_PC_5_bf.TAIL;
    tail += n;
    if(tail >= peri->pl2pcStream.highAddress) {
        tail -= peri->pl2pcStream.size;
    }
    peri->streamRegs->FIFO_TO_PC_5_bf.TAIL = tail;
}

/**
 * @brief Advances the head of the stream by a specified number of words.
 *
 * This function updates the head of the stream by the given number of words.
 * It reads the initial head position, updates the head position by writing `n`
 * to the appropriate register, and then reads the new head position. If the new
 * head position does not match the expected value, it prints a mismatch error
 * message.
 *
 * @param peri Pointer to the XiBIF peripheral structure.
 * @param n The number of units to advance the head.
 */
static inline void XiBIF_streamAdvanceHead(XiBIF_peri_t* peri, u32 n)
{
    u32 head = peri->streamRegs->FIFO_FROM_PC_4_bf.HEAD;
    head += n;
    if(head >= peri->pc2plStream.highAddress) {
        head -= peri->pc2plStream.size;
    }
    peri->streamRegs->FIFO_FROM_PC_4_bf.HEAD = head;
}

/**
 * @brief Listener function for XiBIF.
 *
 * This function is intended to be used as a listener in the XiBIF system.
 *
 * @param p A pointer to a XiBIF_ListenConfig_t structure, defining the port
 *          and handling thread function.
 */
void XiBIF_listener(void* p)
{
    int sd, sock, size;
    int yes = 1;
    XiBIF_ListenConfig_t* conf = (XiBIF_ListenConfig_t*)p;
    struct sockaddr_in address, remote;

    memset(&address, 0, sizeof(address));

    // Create a TCP/IP socket (SOCK_STREAM)
    if((sock = socket(AF_INET, SOCK_STREAM, 0)) < 0)
        return;

    address.sin_family = AF_INET;
    address.sin_port = htons(conf->port);
    address.sin_addr.s_addr = INADDR_ANY;

    // Allow quick rebinding after resets
    setsockopt(sock, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof(yes));

    if(bind(sock, (struct sockaddr*)&address, sizeof(address)) < 0) {
        DBG_PRINT("ERROR: lwip_bind failed!\r\n");
        close(sock);
        vTaskDelete(0);
    }

    // Allow a small backlog so browsers can open parallel connections
    listen(sock, 8);

    size = sizeof(remote);

    DBG_PRINT("Start listening for connections on port %d, spawning %s.\r\n", conf->port, conf->name);
    while(1) {
        if((sd = accept(sock, (struct sockaddr*)&remote, (socklen_t*)&size)) > 0) {
            /* Disable Nagle algorithm on this socket */
            if(setsockopt(sd, IPPROTO_TCP, TCP_NODELAY, &yes, sizeof(yes)) == -1) {
                xil_printf("ERROR: Failed to set socket option.");
            }

            // Log the accepted connection with peer address/port for debugging
            ip_addr_t remote_ip;
            remote_ip.addr = remote.sin_addr.s_addr;
            u16_t remote_port = ntohs(remote.sin_port);
            DBG_PRINT("Accept on port %d sock=%d from %d.%d.%d.%d:%u -> %s\r\n", conf->port, sd, ip4_addr1(&remote_ip), ip4_addr2(&remote_ip), ip4_addr3(&remote_ip), ip4_addr4(&remote_ip), remote_port, conf->name);

            DBG_PRINT("Spawning %s.\r\n", conf->name);
            sys_thread_new(conf->name, conf->handler, (void*)(UINTPTR)sd, conf->stackSize, conf->prio);
        }
    }
    // Delete task.
    DBG_PRINT("Delete listener on port %d, spawning %s.\r\n", conf->port, conf->name);
    close(sock);
    vTaskDelete(0);
}

#if (LWIP_DHCP == 1)
/**
 * @brief DHCP timer callback function for the specified network interface.
 *
 * This function is called periodically to handle DHCP-related tasks for the
 * given network interface. It is responsible for managing the DHCP lease,
 * renewing the lease, and handling any DHCP state transitions.
 *
 * @param netif Pointer to the network interface structure.
 */
void XiBIF_dhcp_timer(struct netif* netif)
{
    int mscnt = 0;
    u8 oldLinkState = 0;
    u8 currentLinkState = 0; // cppcheck-suppress unreadVariable
    uint8_t upTimeOutCounter = 0;
    uint32_t oldIP = 1; // Must be > 0 as workaround for Zybo Z20
    XiBIF_peri_t* peri = XiBIF_getPeri();

    while(1) {
        vTaskDelay(DHCP_FINE_TIMER_MSECS / portTICK_RATE_MS);
        dhcp_fine_tmr();
        mscnt += DHCP_FINE_TIMER_MSECS;
        if(mscnt >= DHCP_COARSE_TIMER_SECS * 1000) {
            dhcp_coarse_tmr();
            mscnt = 0;
        }

        currentLinkState = netif_is_link_up(netif);

        // Check if the link has changed
        if(oldLinkState != currentLinkState) {
            // Save the state
            oldLinkState = currentLinkState;

            // Save the state into the preriphery
            if(xSemaphoreTake(peri->mutex, (TickType_t)10) == pdTRUE) {
                peri->ethernetLink = currentLinkState;
                xSemaphoreGive(peri->mutex);
            }

            // Get the new state
            if(currentLinkState) {
                // Set the timeout counter
                upTimeOutCounter = XIBIF_TIMEOUT_DHCP_S;
            }
            else {
                // Reset the IP
                IP4_ADDR(&(netif->ip_addr), 0, 0, 0, 0);
                IP4_ADDR(&(netif->netmask), 0, 0, 0, 0);
                IP4_ADDR(&(netif->gw), 0, 0, 0, 0);
            }
        }

        // Check if the timeout counter is active
        if(upTimeOutCounter > 0) {
            // Check if the counter is zero
            if(--upTimeOutCounter == 0) {
                if((netif->ip_addr.addr) == 0) {
                    // Set a fixed IP in case we couldn't get one from the DHCP
                    IP4_ADDR(&(netif->ip_addr), XIBIF_DEFAULT_IP_00, XIBIF_DEFAULT_IP_01, XIBIF_DEFAULT_IP_02, XIBIF_DEFAULT_IP_03);
                    IP4_ADDR(&(netif->netmask), XIBIF_DEFAULT_NETMASK_00, XIBIF_DEFAULT_NETMASK_01, XIBIF_DEFAULT_NETMASK_02, XIBIF_DEFAULT_NETMASK_03);
                    IP4_ADDR(&(netif->gw), XIBIF_DEFAULT_GATEWAY_00, XIBIF_DEFAULT_GATEWAY_01, XIBIF_DEFAULT_GATEWAY_02, XIBIF_DEFAULT_GATEWAY_03);
                }
            }
        }

        // Print the IP
        if(oldIP != netif->ip_addr.addr) {
            XiBIF_printIpSettings(&(netif->ip_addr), &(netif->netmask), &(netif->gw));

            // Save the new IP
            oldIP = netif->ip_addr.addr;

            // Update speed settings
            XiBIF_FixLinkSpeed(netif);
        }
    }
}
#endif

/**
 * @brief Resets the RX (receive) functionality of the specified network
 * interface.
 *
 * This function is responsible for resetting the receive functionality of the
 * provided network interface. It ensures that the network interface is ready
 * to receive data again after the reset.
 * see https://docs.xilinx.com/r/en-US/oslib_rm/xemacpsif_resetrx_on_no_rxdata
 *
 * @param netif A pointer to the network interface structure that needs to be
 * reset.
 */
void XiBIF_resetrx(struct netif* netif)
{
    while(1) {
        vTaskDelay(10 / portTICK_RATE_MS);
        xemacpsif_resetrx_on_no_rxdata(netif);
    }
}

/**
 * @brief Sets up the main task for the XiBIF application.
     *
* This function creates a new task for the XiBIF application with a specified
* stack size, priority, and task name. The task is created using the FreeRTOS
* xTaskCreate function.
*
 * @note The task is created with a priority of DEFAULT_THREAD_PRIO - 1.
 */
void XiBIF_setupMainTask()
{ xTaskCreate(XiBIF, "XiBIF_App", 600, NULL, DEFAULT_THREAD_PRIO - 1, NULL); }

/**
 * @brief XiBIF Application thread.
 *
 * This thread initialises the required hardware and the TCP/IP connection.
 *
 * @param p Pointer to the data required for XiBIF operations.
 */
void XiBIF()
{
    /* Get peri */
    XiBIF_peri_t* peri = XiBIF_getPeri();
    /*
   * MUST have lower priority than the LWIP network thread, because the
   * initialisation function called by XiBIF is implemented with a busy wait,
   * which results in a dead lock is XiBIF has higher priority.
   */
    if(DEFAULT_THREAD_PRIO < uxTaskPriorityGet(NULL))
        xil_printf("WARNING: XiBIF main task priority MUST be lower than Ethernet "
                   "networking thread!\r\n");

    /* MAC address - Should be unique per board! */
    unsigned char mac_ethernet_address[] = {XIBIF_MAC_00, XIBIF_MAC_01, XIBIF_MAC_02, XIBIF_MAC_03, XIBIF_MAC_04, XIBIF_MAC_05};
    ip_addr_t ipaddr, netmask, gw;
    xil_printf("Running XiBIF V%d.%d (compiled on %s, %s)\r\n", XIBIF_SREG_VERSION_MAJ_RESET, XIBIF_SREG_VERSION_MIN_RESET, __DATE__, __TIME__);

    /* Initialize the AXI Firewall block */
    // Set Timeout ov AXI Firewall
    Xil_Out32(AXI_FIREWALL_MAX_CONTINUOUS_RTRANSFERS_WAITS, AXI_FIREWALL_TIMEOUT);
    Xil_Out32(AXI_FIREWALL_MAX_WRITE_TO_BVALID_WAITS, AXI_FIREWALL_TIMEOUT);
    Xil_Out32(AXI_FIREWALL_MAX_ARREADY_WAITS, AXI_FIREWALL_TIMEOUT);
    Xil_Out32(AXI_FIREWALL_MAX_AWREADY_WAITS, AXI_FIREWALL_TIMEOUT);
    Xil_Out32(AXI_FIREWALL_MAX_WREADY_WAITS, AXI_FIREWALL_TIMEOUT);
    Xil_Out32(AXI_FIREWALL_MAX_CONTINUOUS_WTRANSFERS_WAITS, AXI_FIREWALL_TIMEOUT);
    Xil_Out32(AXI_FIREWALL_MAX_WVALID_TO_AWVALID_WAITS, AXI_FIREWALL_TIMEOUT);
    Xil_Out32(AXI_FIREWALL_MAX_RREADY_WAITS, AXI_FIREWALL_TIMEOUT);
    Xil_Out32(AXI_FIREWALL_MAX_BREADY_WAITS, AXI_FIREWALL_TIMEOUT);
    Xil_Out32(AXI_FIREWALL_MI_INTERRUPT, 0xC0006000);
    Xil_Out32(AXI_FIREWALL_SI_INTERRUPT, 0xC0006000);
    Xil_Out32(AXI_FIREWALL_GLOBAL_INTERRUPT, 1);

    /*
   * Initialise hardware peripheral,
   * initialise software FIFO
   * and Start TCP/IP application threads.
   */
    if(XiBIF_init(peri, XPAR_XIBIF_BASEADDR, XPAR_XIBIF_REG_BASEADDR) != XIB_OK) {
        xil_printf("An error occured while initializing XiBIF!\r\n");
    }
    configASSERT(peri->initialised == 1);
    xil_printf("Successfully initialised XiBIF.\r\n");

    // Initialise lwIP before calling sys_thread_new
    lwip_init();

/* Initialise IP addresses to be used */
#if (LWIP_DHCP == 1)
    IP4_ADDR(&ipaddr, 0, 0, 0, 0);
    IP4_ADDR(&netmask, 0, 0, 0, 0);
    IP4_ADDR(&gw, 0, 0, 0, 0);
#else
    IP4_ADDR(&ipaddr, XIBIF_DEFAULT_IP_00, XIBIF_DEFAULT_IP_01, XIBIF_DEFAULT_IP_02, XIBIF_DEFAULT_IP_03);
    IP4_ADDR(&netmask, XIBIF_DEFAULT_NETMASK_00, XIBIF_DEFAULT_NETMASK_01, XIBIF_DEFAULT_NETMASK_02, XIBIF_DEFAULT_NETMASK_03);
    IP4_ADDR(&gw, XIBIF_DEFAULT_GATEWAY_00, XIBIF_DEFAULT_GATEWAY_01, XIBIF_DEFAULT_GATEWAY_02, XIBIF_DEFAULT_GATEWAY_03);

    /* print out IP settings of the board */
    XiBIF_printIpSettings(&ipaddr, &netmask, &gw);
#endif

    /* Add network interface to the netif_list, and set it as default */
    if(!xemac_add(&server_netif, &ipaddr, &netmask, &gw, mac_ethernet_address, XPAR_XEMACPS_0_BASEADDR)) {
        xil_printf("Error adding N/W interface. Killing XiBIF.\r\n");
        vTaskDelete(0);
        return;
    }

    netif_set_default(&server_netif); // Set network interface as default
    netif_set_up(&server_netif);      // Setup network interface

    /* start packet receive thread - required for lwIP operation */
    sys_thread_new("xemacif_input_thread", (void (*)(void*))xemacif_input_thread, &server_netif, 1024, DEFAULT_THREAD_PRIO);

    /* Reset RX on no Data - required for lwIP operation */
    /* see https://docs.xilinx.com/r/en-US/oslib_rm/xemacpsif_resetrx_on_no_rxdata
   */
    sys_thread_new("XiBIF_resetrx", (void (*)(void*))XiBIF_resetrx, &server_netif, 1024, DEFAULT_THREAD_PRIO);

#if (LWIP_DHCP == 1)
    dhcp_start(&server_netif);
    sys_thread_new("DHCP_tmr", (void (*)(void*))XiBIF_dhcp_timer, &server_netif, configMINIMAL_STACK_SIZE, DEFAULT_THREAD_PRIO);
#endif

    /* Setup system threads for connection handling */
    regConf.handler = cmd_con;
    regConf.name = "Cmd_con";
    regConf.port = REG_PORT;
    regConf.prio = DEFAULT_THREAD_PRIO - 1;
    regConf.stackSize = 2000;
    sys_thread_new("Reg_App", XiBIF_listener, &regConf, 2000, 3);

    echoConf.handler = echo_con;
    echoConf.name = "Echo_con";
    echoConf.port = ECHO_PORT;
    echoConf.prio = DEFAULT_THREAD_PRIO - 1;
    echoConf.stackSize = 2000;
    sys_thread_new("Echo_App", XiBIF_listener, &echoConf, 2000, 3);

    if(XIBIF_ENABLE_WEBSERVER == 1) {
        webConf.handler = XiBIF_webHandler;
        webConf.name = "Web_con";
        webConf.port = WEB_PORT;
        webConf.prio = DEFAULT_THREAD_PRIO - 1;
        webConf.stackSize = 2500;
        sys_thread_new("Web_App", XiBIF_listener, &webConf, 2500, 3);
    }

    xil_printf("\r\n");
    xil_printf("%6s %s\r\n", "Port", "Application");
    xil_printf("%6s %s\r\n", "------", "--------------------");
    xil_printf("%6d %s\r\n", REG_PORT, "Command access");
    xil_printf("%6d %s\r\n", ECHO_PORT, "Echo server (test connection)");
    if(XIBIF_ENABLE_WEBSERVER == 1) {
        xil_printf("%6d %s\r\n", WEB_PORT, "Web server");
    }
    xil_printf("\r\n");

    sys_thread_new("LedBlink_App", XiBIF_ledBlink, NULL, 2000, 2);
    sys_thread_new("CheckConnection_App", XiBIF_checkCon, NULL, 2000, 2);

    vTaskSuspend(NULL);
    DBG_PRINT("ERROR: XiBIF Main task closed!\r\n");
    vTaskDelete(NULL);
}

/**
 * @brief Reads data from a given socket into a buffer.
 *
 * @param sd The socket from which to read data.
 * @param buf A pointer to the buffer where the read data will be stored.
 * @param len The number of bytes to read from the socket.
 * @return XIB_OK if sucessful, other values if an error occurs.
 */
XiBIF_error_t XiBIF_readSocketData(int sd, void* buf, size_t len)
{
    ssize_t n;
    size_t k = 0;
    while(k < len) {
        n = read(sd, ((u8*)buf) + k, len - k);
        if(n <= 0) {
            if(n < 0) {
                xil_printf("%d: error reading from socket %d, closing socket\r\n", __LINE__, sd);
                return XIB_ERROR;
            }
            else {
                return XIB_ENODATA;
            }
        }
        k += n;
    }
    return XIB_OK;
}

/**
 * @brief Reads data from a given socket into a dummy buffer and discards it.
 * 
 * This function is used to read and discard a specified amount of data from the socket, which can be useful for handling cases where the data is not needed or to clear the socket buffer.
 * 
 * @param sd The socket from which to read data.
 * @param length The number of bytes to read and discard from the socket.
 * @return XIB_OK if the data was read successfully, otherwise returns XIB_ERROR.
 */
XiBIF_error_t XiBIF_readDummy(int sd, u32 length)
{
    u8* buffer;

    DBG_PRINT("Reading and discarding %d bytes.\r\n", length);

    // Get some memory
    buffer = pvPortMalloc(length);

    if(XiBIF_readSocketData(sd, buffer, length) != XIB_OK) {
        vPortFree(buffer);
        return XIB_ERROR;
    }

    // Free the memory again
    vPortFree(buffer);

    return XIB_OK;
}

/**
 * @brief Writes data from a buffer to a given socket.
 *
 * @param sd The socket to which to write data.
 * @param buf A pointer to the buffer containing the data to be written.
 * @param len The number of bytes to write to the socket.
 * @return XIB_OK if sucessful, other values if an error occurs.
 */
XiBIF_error_t XiBIF_writeSocketData(int sd, void* buf, size_t len)
{
    ssize_t n;
    size_t k = 0;
    while(k < len) {
        n = write(sd, ((u8*)buf) + k, len - k);
        if(n <= 0) {
            if(n < 0) {
                xil_printf("%d: error writing to socket %d, closing socket\r\n", __LINE__, sd);
                return XIB_ERROR;
            }
            else {
                return XIB_ENODATA;
            }
        }
        k += n;
    }
    return XIB_OK;
}

/**
 * @brief Writes a response header to a given socket.
 * The response header consists of a command and a length, which are sent as
 * two consecutive 32-bit unsigned integers.
 */
XiBIF_error_t XiBIF_writeResponse(int sd, XiBIF_cmd_t cmd, u32 length, XiBIF_response_status_t status, XTime start_time)
{
    u32 header[5];
    XTime end_time;
    u64 time_diff;

    DBG_PRINT("Writing response header: cmd=%d, status=%d, length=%d\r\n", cmd, status, length);

    XTime_GetTime(&end_time);
    time_diff = (u64)end_time - (u64)start_time;

    header[0] = (u32)cmd;
    header[1] = (u32)status;
    header[2] = length;
    header[3] = (u32)(0x00000000FFFFFFFF & (time_diff >> 32));
    header[4] = (u32)(0x00000000FFFFFFFF & time_diff);
    if(XiBIF_writeSocketData(sd, header, sizeof(header)) != XIB_OK) {
        xil_printf("%d: error writing response header to socket %d\r\n", __LINE__, sd);
        return XIB_ERROR;
    }

    return XIB_OK;
}

/**
 * @brief Handles an invalid length received from a client.
 * 
 * This function is called when an invalid length is received from a client. It reads and discards the specified amount of data from the socket, and then sends a response back to the client indicating that the length was invalid.
 * 
 * @param sd The socket from which the invalid length was received.
 * @param length The invalid length that was received.
 * @param cmd The command associated with the invalid length.
 * @return XIB_OK if the invalid length was handled successfully, otherwise returns XIB_ERROR
 */
static XiBIF_error_t XiBIF_writeResponeInvalidLength(int sd, u32 length, XiBIF_cmd_t cmd, XTime start_time)
{
    DBG_PRINT("Invalid length received: %d\r\n", length);

    if(XiBIF_readDummy(sd, length) != XIB_OK) {
        return XIB_ERROR;
    }

    if(XiBIF_writeResponse(sd, cmd, 0, XRESP_INVALID_LENGTH, start_time) != XIB_OK) {
        return XIB_ERROR;
    }

    return XIB_OK;
}

/**
 * @brief Sends a status response to a given socket.
 * 
 * This function gathers various status information from the provided peripheral
 * structure and sends it back to the client through the specified socket. The
 * status information includes register and stream versions, FIFO depths, occupancy, UUIDs, and stream enablement status.
 * 
 * @param sd The socket to which the status response will be sent.
 * @param peri A pointer to the XiBIF peripheral structure containing the status information.
 * @param start_time Timestamp when the current command has been received.
 * @return XIB_OK if the status response was sent successfully, otherwise returns XIB_ERROR.
 */
static XiBIF_error_t XiBIF_sendStatusResponse(int sd, XiBIF_peri_t* peri, XTime start_time)
{
    u32 data[19];

    data[0] = peri->registerVersion;
    data[1] = peri->streamVersion;
    data[2] = XIBIF_STREAM_VID;

    data[3] = peri->streamRegs->BUILD_TIMESTAMP_bf.TIMESTAMP;
    data[4] = BUILD_TIMESTAMP;

    data[5] = peri->registerUuid;
    data[6] = peri->streamUuid;

    data[7] = (u32)XIBIF_REG_WIDTH;
    data[8] = (u32)peri->streamRegs->AXI_STREAM_1_bf.WIDTH;

#if defined(PLATFORM_ZYNQ) || defined(PLATFORM_ZYNQMP)
    data[9] = 1; // Bitstream connection available
#else
    data[9] = 0; // Bitstream connection not available
#endif

    data[10] = peri->pl2pcStream.enabled;
    data[11] = peri->pl2pcStream.fifoDepth;
    data[12] = XiBIF_getToPcSwFifoOcc(peri) / sizeof(u32);
    data[13] = peri->streamRegs->FIFO_TO_PC_3;

    data[14] = peri->pc2plStream.enabled;
    data[15] = peri->pc2plStream.fifoDepth;
    data[16] = XiBIF_getFromPcSwFifoOcc(peri) / sizeof(u32);
    data[17] = peri->streamRegs->FIFO_FROM_PC_3;

    data[18] = (u32)XPAR_CPU_CORE_CLOCK_FREQ_HZ;

    if(XiBIF_writeResponse(sd, XCMD_STATUS, sizeof(data), XRESP_OK, start_time) != XIB_OK) {
        return XIB_ERROR;
    }
    if(XiBIF_writeSocketData(sd, data, sizeof(data)) != XIB_OK) {
        return XIB_ERROR;
    }

    return XIB_OK;
}

/**
 * @brief Sends a status response to a given socket.
 * 
 * This function gathers various status information from the provided peripheral
 * structure and sends it back to the client through the specified socket. The
 * status information includes register and stream versions, FIFO depths, occupancy, UUIDs, and stream enablement status.
 * 
 * @param sd The socket to which the status response will be sent.
 * @param peri A pointer to the XiBIF peripheral structure containing the status information.
 * @param repetition Number of read/write repetitions.
 * @param start_time Timestamp when the current command has been received.
 * @return XIB_OK if the status response was sent successfully, otherwise returns XIB_ERROR.
 */
XiBIF_error_t XiBIF_performanceTest(int sd, XiBIF_peri_t* peri, u32 repetition, XTime start_time)
{
    XTime start_time_user;
    XTime start_time_stream;
    XTime start_time_stream_write;
    XTime start_time_stream_read;
    XTime end_time_user;
    XTime end_time_stream;
    XTime end_time_stream_write;
    XTime end_time_stream_read;
    u32* head;
    u32* tail;
    u32 testData;
    u64 data[4];

    // Do perforamance measurements
    XTime_GetTime(&start_time_user);
    for(u32 i = 0; i < repetition; ++i) {
        testData = peri->userRegs->UUID_bf.UUID;
    }
    XTime_GetTime(&end_time_user);

    XTime_GetTime(&start_time_stream);
    for(u32 i = 0; i < repetition; ++i) {
        testData = peri->userRegs->UUID_bf.UUID;
    }
    XTime_GetTime(&end_time_stream);

    XiBIF_streamGetHead(peri, &head);
    XTime_GetTime(&start_time_stream_write);
    for(u32 i = 0; i < repetition; ++i) {
        *head = i;
#if defined(PLATFORM_ZYNQMP)
        Xil_DCacheFlushRange((UINTPTR)head, sizeof(u32));
#endif
    }
    XTime_GetTime(&end_time_stream_write);

    XiBIF_streamGetTail(peri, &tail);
    XTime_GetTime(&start_time_stream_read);
    for(u32 i = 0; i < repetition; ++i) {
#if defined(PLATFORM_ZYNQMP)
        Xil_DCacheInvalidateRange((UINTPTR)tail, sizeof(u32));
#endif
        testData = *tail;
    }
    XTime_GetTime(&end_time_stream_read);

    // Calculate time
    data[0] = (u64)end_time_user - (u64)start_time_user;
    data[1] = (u64)end_time_stream - (u64)start_time_stream;
    data[2] = (u64)end_time_stream_write - (u64)start_time_stream_write;
    data[3] = (u64)end_time_stream_read - (u64)start_time_stream_read;

    if(XiBIF_writeResponse(sd, XCMD_PERFORMANCE, sizeof(data), XRESP_OK, start_time) != XIB_OK) {
        return XIB_ERROR;
    }
    if(XiBIF_writeSocketData(sd, data, sizeof(data)) != XIB_OK) {
        return XIB_ERROR;
    }

    // Do not optimize this variable away
    (void)testData;

    return XIB_OK;
}

/**
 * @brief Reads data from an AXI register at a specified address and checks for firewall violations.
 * 
 * This function reads a 32-bit value from the AXI register at the given address and checks if the address is aligned and within the allowed range. It also checks for firewall violations by reading the firewall status registers. The result of the read operation and any errors are stored in the provided data array.
 * 
 * @param peri A pointer to the XiBIF peripheral structure.
 * @param addr The address of the AXI register to read from.
 * @param data A pointer to an array where the read data and status will be stored. The first element will contain the read data, and the second element will contain the status of the operation (e.g., AXI_OK, AXI_EALIGN, AXI_EACCRANGE, AXI_EFIREWALL, AXI_EFIREWALL_DATACODE).
 */
void XiBIF_getAXI(XiBIF_peri_t* peri, u32 addr, u32* data)
{
    u32 firewallStatus1;
    u32 firewallStatus2;

    // Check that the adrress is aligned
    if(addr % 4 == 0) {
        // Check that the address is in the allowed range
        if((XIBIF_AXI_ACCESS_START_RANGE <= addr) && (XIBIF_AXI_ACCESS_STOP_RANGE >= addr)) {
            if((((UINTPTR)(peri->streamRegs) <= addr) && (((UINTPTR)(peri->streamRegs) + XPAR_XIBIF_HIGHADDR - XPAR_XIBIF_BASEADDR) >= addr)) || (((UINTPTR)(peri->userRegs) <= addr) && (((UINTPTR)(peri->userRegs) + XPAR_XIBIF_REG_HIGHADDR - XPAR_XIBIF_REG_BASEADDR) >= addr))) {
                data[0] = 0;
                data[1] = AXI_EXIBRANGE;
            }
            else {
                // Read the data
                data[0] = Xil_In32(addr);

                // Check the firewall
                firewallStatus1 = Xil_In32(AXI_FIREWALL_MI_SIDE_FAULT_STATUS);
                firewallStatus2 = Xil_In32(AXI_FIREWALL_SI_SIDE_FAULT_STATUS);
                DBG_PRINT("Read AXI Firewall Status MI: 0x%08x, SI: 0x%08x \r\n", firewallStatus1, firewallStatus2);

                if(firewallStatus1 || firewallStatus2) {
                    data[1] = AXI_EFIREWALL;

                    // Unblock Firewall
                    Xil_Out32(AXI_FIREWALL_MI_UNBLOCK_CONTROL, 1);
                    Xil_Out32(AXI_FIREWALL_SI_UNBLOCK_CONTROL, 1);
                }
                else if((data[0] == 0xDEC0DEE3) || (data[0] == 0xDEADFA11)) {
                    data[1] = AXI_EFIREWALL_DATACODE;

                    // Unblock Firewall
                    Xil_Out32(AXI_FIREWALL_MI_UNBLOCK_CONTROL, 1);
                    Xil_Out32(AXI_FIREWALL_SI_UNBLOCK_CONTROL, 1);
                }
                else {
                    data[1] = AXI_OK;
                }
            }
        }
        else {
            data[0] = 0;
            data[1] = AXI_EACCRANGE;
        }
    }
    else {
        data[0] = 0;
        data[1] = AXI_EALIGN;
    }
}

/**
 * @brief Writes data to an AXI register at a specified address with a mask and checks for firewall violations.
 * 
 * This function writes a 32-bit value to the AXI register at the given address, applying a mask to the value if necessary. It checks if the address is aligned and within the allowed range, and also checks for firewall violations by reading the firewall status registers. The result of the write operation and any errors are stored in the provided data array.
 * 
 * @param peri A pointer to the XiBIF peripheral structure.
 * @param addr The address of the AXI register to write to.
 * @param value The value to be written to the AXI register.
 * @param mask A mask that specifies which bits of the value should be written. If the mask is 0xFFFFFFFF, the entire value will be written. Otherwise, only the bits specified by the mask will be updated in the register.
 * @param data A pointer to an array where the status of the operation will be stored.
 */
void XiBIF_setAXI(XiBIF_peri_t* peri, u32 addr, u32 value, u32 mask, u32* data)
{
    u32 firewallStatus1;
    u32 firewallStatus2;
    u32 dataRead;
    u32 dataMask;

    // Check that the address is aligned
    if(addr % 4 == 0) {
        // Check that the address is in the allowed range
        if((XIBIF_AXI_ACCESS_START_RANGE <= addr) && (XIBIF_AXI_ACCESS_STOP_RANGE >= addr)) {
            if((((UINTPTR)(peri->streamRegs) <= addr) && (((UINTPTR)(peri->streamRegs) + XPAR_XIBIF_HIGHADDR - XPAR_XIBIF_BASEADDR) >= addr)) || (((UINTPTR)(peri->userRegs) <= addr) && (((UINTPTR)(peri->userRegs) + XPAR_XIBIF_REG_HIGHADDR - XPAR_XIBIF_REG_BASEADDR) >= addr))) {
                data[0] = AXI_EXIBRANGE;
            }
            else {
                if(mask != 0xFFFFFFFF) {
                    dataRead = Xil_In32(addr); // Keep this separate to check for access error
                    dataMask = dataRead & (~mask);
                    dataMask |= (value & mask);
                }
                else {
                    dataRead = 0;
                    dataMask = value;
                }
                Xil_Out32(addr, dataMask);

                // Check the firewall
                firewallStatus1 = Xil_In32(AXI_FIREWALL_MI_SIDE_FAULT_STATUS);
                firewallStatus2 = Xil_In32(AXI_FIREWALL_SI_SIDE_FAULT_STATUS);
                DBG_PRINT("Write AXI Firewall Status MI: 0x%08x, SI: 0x%08x \r\n", firewallStatus1, firewallStatus2);

                if(firewallStatus1 || firewallStatus2) {
                    data[0] = AXI_EFIREWALL;

                    // Unblock Firewall
                    Xil_Out32(AXI_FIREWALL_MI_UNBLOCK_CONTROL, 1);
                    Xil_Out32(AXI_FIREWALL_SI_UNBLOCK_CONTROL, 1);
                }
                else if((dataRead == 0xDEC0DEE3) || (dataRead == 0xDEADFA11)) {
                    data[0] = AXI_EFIREWALL_DATACODE;

                    // Unblock Firewall
                    Xil_Out32(AXI_FIREWALL_MI_UNBLOCK_CONTROL, 1);
                    Xil_Out32(AXI_FIREWALL_SI_UNBLOCK_CONTROL, 1);
                }
                else {
                    data[0] = AXI_OK;
                }
            }
        }
        else {
            data[0] = AXI_EACCRANGE;
        }
    }
    else {
        data[0] = AXI_EALIGN;
    }
}

/**
 * @brief XiBIF register and status connection handler.
 *
 * Spawned for each connection, this thread handles register/stream read/write
 * and querying of status information.
 *
 * @param p The socket from which to read data.
 */
void cmd_con(void* p)
{
    int sd = (int)(UINTPTR)p;
    int closeCon = 0;
    u32 addr, data[2], cmd, mask, length, value, space, uuid;
    u32* head;
    XiBIF_peri_t* peri = XiBIF_getPeri();
    XTime start_time;

    // Signalize a new connection to the hardware
    peri->streamRegs->STATUS_CONTROL_TO_HW_bf.HOSTCONNECTED = 1;
    DBG_PRINT("Socket %d opened\r\n", sd);

    while(1) {
        /* Read command from socket */
        if(XiBIF_readSocketData(sd, &cmd, sizeof(cmd)) != XIB_OK) {
            break;
        }

        /* Save start time */
        XTime_GetTime(&start_time);

        /* Read UUID */
        if(XiBIF_readSocketData(sd, &uuid, sizeof(uuid)) != XIB_OK) {
            break;
        }

        /* Read length */
        if(XiBIF_readSocketData(sd, &length, sizeof(length)) != XIB_OK) {
            break;
        }

        DBG_PRINT("Received cmd: %d\r\n", cmd);
        DBG_PRINT("Received UUID: 0x%08x\r\n", uuid);
        DBG_PRINT("Received length: %d\r\n", length);

        /* Check UUID */
        if((uuid != (u32)XIBIF_REG_UUID_UUID_RESET)) {
            xil_printf("Invalid UUID received: 0x%08x\r\n", uuid);

            if(XiBIF_readDummy(sd, length) != XIB_OK) {
                break;
            }

            if(XiBIF_writeResponse(sd, cmd, 0, XRESP_UNAUTHORIZED, start_time) != XIB_OK) {
                break;
            }
            continue;
        }

        /* Handle request */
        switch(cmd) {
        case XCMD_STATUS:
            DBG_PRINT("XCMD_STATUS received\r\n");
            if(length != 0) {
                if(XiBIF_writeResponeInvalidLength(sd, length, XCMD_STATUS, start_time) != XIB_OK) {
                    closeCon = 1;
                }
                break;
            }

            if(XiBIF_sendStatusResponse(sd, peri, start_time) != XIB_OK) {
                closeCon = 1;
                break;
            }
            break;

        case XCMD_STREAM_FLUSH:
            DBG_PRINT("XCMD_STREAM_FLUSH received\r\n");
            if(length != 0) {
                if(XiBIF_writeResponeInvalidLength(sd, length, XCMD_STREAM_FLUSH, start_time) != XIB_OK) {
                    closeCon = 1;
                }
                break;
            }

            XiBIF_resetFifo(peri);

            if(XiBIF_writeResponse(sd, XCMD_STREAM_FLUSH, 0, XRESP_OK, start_time) != XIB_OK) {
                closeCon = 1;
                break;
            }
            break;

        case XCMD_REG_READ:
            DBG_PRINT("XCMD_REG_READ received\r\n");
            if(length == 0) {
                if(XiBIF_writeResponeInvalidLength(sd, length, XCMD_REG_READ, start_time) != XIB_OK) {
                    closeCon = 1;
                }
                break;
            }

            // Send response header first before sending the data, so the client knows to expect data
            if(XiBIF_writeResponse(sd, XCMD_REG_READ, length, XRESP_OK, start_time) != XIB_OK) {
                closeCon = 1;
                break;
            }

            while(length > 0) {
                length -= sizeof(u32);
                if(XiBIF_readSocketData(sd, &addr, sizeof(addr)) != XIB_OK) {
                    closeCon = 1;
                    break;
                }

                value = XiBIF_getReg(peri, addr);
                DBG_PRINT("Read register: 0x%08x, Data: 0x%08x\r\n", addr, value);

                if(XiBIF_writeSocketData(sd, &value, sizeof(value)) != XIB_OK) {
                    closeCon = 1;
                    break;
                }
            }
            break;

        case XCMD_REG_WRITE:
            DBG_PRINT("XCMD_REG_WRITE received\r\n");
            if((length == 0) || (length % (sizeof(u32) * 2) != 0)) {
                if(XiBIF_writeResponeInvalidLength(sd, length, XCMD_REG_WRITE, start_time) != XIB_OK) {
                    closeCon = 1;
                }
                break;
            }

            // Write reg first before responding
            while(length > 0) {
                length -= sizeof(u32) * 2;

                if(XiBIF_readSocketData(sd, &addr, sizeof(addr)) != XIB_OK) {
                    closeCon = 1;
                    break;
                }
                if(XiBIF_readSocketData(sd, &value, sizeof(value)) != XIB_OK) {
                    closeCon = 1;
                    break;
                }
                DBG_PRINT("Write register: 0x%08x, Data: 0x%08x\r\n", addr, value);
                XiBIF_setReg(peri, addr, value);
            }

            if(XiBIF_writeResponse(sd, XCMD_REG_WRITE, 0, XRESP_OK, start_time) != XIB_OK) {
                closeCon = 1;
                break;
            }

            break;

        case XCMD_STREAM_WRITE:
            DBG_PRINT("XCMD_STREAM_WRITE received\r\n");
            if((length == 0) || (length % (sizeof(u32)) != 0)) {
                if(XiBIF_writeResponeInvalidLength(sd, length, XCMD_STREAM_WRITE, start_time) != XIB_OK) {
                    closeCon = 1;
                }
                break;
            }

            DBG_PRINT("Requested to Write %4d bytes.\r\n", (u32)length);
            if(peri->pc2plStream.enabled == 0) {
                xil_printf("%d: ERROR writing to stream. Stream PC2PL is disabled.\r\n", __LINE__);

                if(XiBIF_writeResponse(sd, XCMD_STREAM_WRITE, 0, XRESP_FAILED, start_time) != XIB_OK) {
                    closeCon = 1;
                    break;
                }
                break;
            }

            // Check if there is enough space in the stream for the data, if yes send response immediately (for performance reasons)
            space = XiBIF_streamGetHead(peri, &head);

            if(space >= length) {
                if(XiBIF_writeResponse(sd, XCMD_STREAM_WRITE, 0, XRESP_OK, start_time) != XIB_OK) {
                    closeCon = 1;
                    break;
                }

                if(XiBIF_writeStream(sd, length) != XIB_OK) {
                    closeCon = 1;
                    break;
                }
            }
            else {
                if(XiBIF_writeStream(sd, length) != XIB_OK) {
                    closeCon = 1;
                    break;
                }
                if(XiBIF_writeResponse(sd, XCMD_STREAM_WRITE, 0, XRESP_OK, start_time) != XIB_OK) {
                    closeCon = 1;
                    break;
                }
            }
            break;

        case XCMD_STREAM_READ:
            DBG_PRINT("XCMD_STREAM_READ received\r\n");
            if(length != sizeof(u32)) {
                if(XiBIF_writeResponeInvalidLength(sd, length, XCMD_STREAM_READ, start_time) != XIB_OK) {
                    closeCon = 1;
                }
                break;
            }

            if(peri->pl2pcStream.enabled == 0) {
                xil_printf("%d: ERROR writing to stream. Stream PL2PC is disabled.\r\n", __LINE__);

                if(XiBIF_writeResponse(sd, XCMD_STREAM_READ, 0, XRESP_FAILED, start_time) != XIB_OK) {
                    closeCon = 1;
                    break;
                }
                break;
            }

            // Read the length of the data to read from the socket
            if(XiBIF_readSocketData(sd, &length, sizeof(length)) != XIB_OK) {
                closeCon = 1;
                break;
            }

            DBG_PRINT("Received data read request: %d bytes\r\n", length);

            if(XiBIF_writeResponse(sd, XCMD_STREAM_READ, length, XRESP_OK, start_time) != XIB_OK) {
                closeCon = 1;
                break;
            }

            if(XiBIF_readStream(sd, length) != XIB_OK) {
                closeCon = 1;
                break;
            }

            break;

        case XCMD_STREAM_READ_ALL:
            DBG_PRINT("XCMD_STREAM_READ_ALL received\r\n");
            if(length != 0) {
                if(XiBIF_writeResponeInvalidLength(sd, length, XCMD_STREAM_READ_ALL, start_time) != XIB_OK) {
                    closeCon = 1;
                }
                break;
            }

            if(peri->pl2pcStream.enabled == 0) {
                xil_printf("%d: ERROR writing to stream. Stream PL2PC is disabled.\r\n", __LINE__);

                if(XiBIF_writeResponse(sd, XCMD_STREAM_READ_ALL, 0, XRESP_FAILED, start_time) != XIB_OK) {
                    closeCon = 1;
                    break;
                }

                break;
            }

            // Get length of available data in the stream
            length = XiBIF_getToPcSwFifoOcc(peri);

            DBG_PRINT("Received data read all request: %d words\r\n", length);

            // Send header first so the client knows to expect data and how much
            if(XiBIF_writeResponse(sd, XCMD_STREAM_READ_ALL, length, XRESP_OK, start_time) != XIB_OK) {
                closeCon = 1;
                break;
            }

            // Send the data
            if(length > 0) {
                if(XiBIF_readStream(sd, length) != XIB_OK) {
                    closeCon = 1;
                    break;
                }
            }
            break;

        case XCMD_BITSTREAM_WRITE:
            DBG_PRINT("XCMD_BITSTREAM_WRITE received\r\n");
            if(length == 0) {
                if(XiBIF_writeResponeInvalidLength(sd, length, XCMD_BITSTREAM_WRITE, start_time) != XIB_OK) {
                    closeCon = 1;
                }
                break;
            }
#if defined(PLATFORM_ZYNQ) || defined(PLATFORM_ZYNQMP)
            if(XiBIF_programBitstream(sd, length) != XIB_OK) {
                closeCon = 1;
                break;
            }

            if(XiBIF_writeResponse(sd, XCMD_BITSTREAM_WRITE, 0, XRESP_OK, start_time) != XIB_OK) {
                closeCon = 1;
                break;
            }
#else
            // If bitstream loading is not supported, read and discard the data and return an error
            if(XiBIF_readDummy(sd, length) != XIB_OK) {
                closeCon = 1;
                break;
            }

            if(XiBIF_writeResponse(sd, XCMD_BITSTREAM_WRITE, 0, XRESP_FAILED, start_time) != XIB_OK) {
                closeCon = 1;
                break;
            }
#endif
            break;

        case XCMD_STATUS_PRINT: {
            DBG_PRINT("XCMD_STATUS_PRINT received\r\n");
            if(length != 0) {
                if(XiBIF_writeResponeInvalidLength(sd, length, XCMD_STATUS_PRINT, start_time) != XIB_OK) {
                    closeCon = 1;
                }
                break;
            }

            xil_printf("Running XiBIF V%d.%d\r\n", XIBIF_SREG_VERSION_MAJ_RESET, XIBIF_SREG_VERSION_MIN_RESET);
            XiBIF_printBuildTimestamp("Build timestamp hardware: ", peri->streamRegs->BUILD_TIMESTAMP_bf.TIMESTAMP);
            XiBIF_printBuildTimestamp("Build timestamp software: ", BUILD_TIMESTAMP);
            XiBIF_printVersion("Peripheral version", peri->registerVersion);
            XiBIF_printVersion("Stream version", peri->streamVersion);
            XiBIF_printVersion("Software version", XIBIF_STREAM_VID);
            xil_printf("UUID Peripheral: 0x%08x\r\n", peri->registerUuid);
            xil_printf("UUID Stream: 0x%08x\r\n", peri->streamUuid);
            xil_printf("PC->PL FIFO depth: %d\r\n", peri->pc2plStream.fifoDepth);
            xil_printf("PL->PC FIFO depth: %d\r\n", peri->pl2pcStream.fifoDepth);
            xil_printf("PC->PL FIFO occupancy: %d\r\n", XiBIF_getFromPcSwFifoOcc(peri));
            xil_printf("PL->PC FIFO occupancy: %d\r\n", XiBIF_getToPcSwFifoOcc(peri));
            xil_printf("PC->PL FIFO error MemFull: %d\r\n", peri->streamRegs->FIFO_FROM_PC_3_bf.ERROR_MEMFULL);
            xil_printf("PC->PL FIFO error AXI: %d\r\n", peri->streamRegs->FIFO_FROM_PC_3_bf.ERROR_AXI);
            xil_printf("PL->PC FIFO error MemFull: %d\r\n", peri->streamRegs->FIFO_TO_PC_3_bf.ERROR_MEMFULL);
            xil_printf("PL->PC FIFO error AXI: %d\r\n", peri->streamRegs->FIFO_TO_PC_3_bf.ERROR_AXI);

            if(XiBIF_writeResponse(sd, XCMD_STATUS_PRINT, 0, XRESP_OK, start_time) != XIB_OK) {
                closeCon = 1;
                break;
            }

            break;
        }
        case XCMD_DBG_PRINT_EN:
            DBG_PRINT("XCMD_DBG_PRINT_EN received\r\n");
            if(length != sizeof(u32)) {
                if(XiBIF_writeResponeInvalidLength(sd, length, XCMD_DBG_PRINT_EN, start_time) != XIB_OK) {
                    closeCon = 1;
                }
                break;
            }

            if(XiBIF_readSocketData(sd, &value, sizeof(value)) != XIB_OK) {
                closeCon = 1;
                break;
            }

            // Save the state into the preriphery
            if(xSemaphoreTake(peri->mutex, (TickType_t)10) == pdTRUE) {
                if(value == 0) {
                    peri->enableDebugOutput = 0;
                }
                else {
                    peri->enableDebugOutput = 1;
                }
                xSemaphoreGive(peri->mutex);
            }

            if(XiBIF_writeResponse(sd, XCMD_DBG_PRINT_EN, 0, XRESP_OK, start_time) != XIB_OK) {
                closeCon = 1;
                break;
            }

            break;

        case XCMD_SOFT_RESET:
            DBG_PRINT("XCMD_SOFT_RESET received\r\n");
            if(length != 0) {
                if(XiBIF_writeResponeInvalidLength(sd, length, XCMD_SOFT_RESET, start_time) != XIB_OK) {
                    closeCon = 1;
                }
                break;
            }

            peri->streamRegs->STATUS_CONTROL_TO_HW_bf.SOFTWARERESET = 1; // Do a software reset

            if(XiBIF_writeResponse(sd, XCMD_SOFT_RESET, 0, XRESP_OK, start_time) != XIB_OK) {
                closeCon = 1;
                break;
            }

            break;

        case XCMD_AXI_READ:
            DBG_PRINT("XCMD_AXI_READ received\r\n");
            if((length == 0) || (length % sizeof(u32) != 0)) {
                if(XiBIF_writeResponeInvalidLength(sd, length, XCMD_AXI_READ, start_time) != XIB_OK) {
                    closeCon = 1;
                }
                break;
            }

            // Send response header first before sending the data, so the client knows to expect data
            if(XiBIF_writeResponse(sd, XCMD_AXI_READ, length * 2, XRESP_OK, start_time) != XIB_OK) {
                closeCon = 1;
                break;
            }

            while(length > 0) {
                length -= sizeof(u32);
                if(XiBIF_readSocketData(sd, &addr, sizeof(addr)) != XIB_OK) {
                    closeCon = 1;
                    break;
                }

                XiBIF_getAXI(peri, addr, data);

                DBG_PRINT("Read AXI: 0x%08x, Data: 0x%08x, Error: 0x%08x \r\n", addr, data[0], data[1]);

                if(XiBIF_writeSocketData(sd, &data[0], sizeof(data[0]) * 2) != XIB_OK) {
                    closeCon = 1;
                    break;
                }
            }
            break;

        case XCMD_AXI_WRITE:
            DBG_PRINT("XCMD_AXI_WRITE received\r\n");
            if((length == 0) || (length % (sizeof(u32) * 3) != 0)) {
                if(XiBIF_writeResponeInvalidLength(sd, length, XCMD_AXI_WRITE, start_time) != XIB_OK) {
                    closeCon = 1;
                }
                break;
            }

            if(XiBIF_writeResponse(sd, XCMD_AXI_WRITE, length / 3, XRESP_OK, start_time) != XIB_OK) {
                closeCon = 1;
                break;
            }

            while(length > 0) {
                length -= sizeof(u32) * 3;

                if(XiBIF_readSocketData(sd, &addr, sizeof(addr)) != XIB_OK) {
                    closeCon = 1;
                    break;
                }
                if(XiBIF_readSocketData(sd, &value, sizeof(value)) != XIB_OK) {
                    closeCon = 1;
                    break;
                }
                if(XiBIF_readSocketData(sd, &mask, sizeof(mask)) != XIB_OK) {
                    closeCon = 1;
                    break;
                }

                XiBIF_setAXI(peri, addr, value, mask, data);

                DBG_PRINT("Write AXI: 0x%08x, Data: 0x%08x, Mask: 0x%08x, Error: 0x%08x\r\n", addr, value, mask, data[0]);

                if(XiBIF_writeSocketData(sd, &data[0], sizeof(data[0])) != XIB_OK) {
                    closeCon = 1;
                    break;
                }
            }

            break;

        case XCMD_REGMAP_GET:
            DBG_PRINT("XCMD_REGMAP_GET received\r\n");
            if(length != 0) {
                if(XiBIF_writeResponeInvalidLength(sd, length, XCMD_REGMAP_GET, start_time) != XIB_OK) {
                    closeCon = 1;
                }
                break;
            }

            DBG_PRINT("Returning register map!\r\n");
            if(XiBIF_writeRegistermap(sd, start_time)) {
                closeCon = 1;
                break;
            }
            break;

        case XCMD_PERFORMANCE:
            DBG_PRINT("XCMD_PERFORMANCE received\r\n");
            if(length != sizeof(u32)) {
                if(XiBIF_writeResponeInvalidLength(sd, length, XCMD_PERFORMANCE, start_time) != XIB_OK) {
                    closeCon = 1;
                }
                break;
            }

            if(XiBIF_readSocketData(sd, &value, sizeof(value)) != XIB_OK) {
                closeCon = 1;
                break;
            }

            DBG_PRINT("Executing performance test!\r\n");
            if(XiBIF_performanceTest(sd, peri, value, start_time)) {
                closeCon = 1;
                break;
            }
            break;

        default:
            if(cmd < XIBIF_RESTRICTED_COMMAND_ID_RANGE) {
                if(XiBIF_readDummy(sd, length) != XIB_OK) {
                    closeCon = 1;
                    break;
                }

                if(XiBIF_writeResponse(sd, cmd, 0, XRESP_FAILED, start_time) != XIB_OK) {
                    closeCon = 1;
                    break;
                }
            }
            else {
                if(XiBIF_ownCommandHandler(cmd, length, sd, start_time) != XIB_OK) {
                    closeCon = 1;
                    break;
                }
            }
            break;
        }

        if(closeCon)
            break;
    }

    // Signalize a closed connetion to the hardware
    peri->streamRegs->STATUS_CONTROL_TO_HW_bf.HOSTCONNECTED = 0;
    DBG_PRINT("Socket %d closed\r\n", sd);

    if(XIBIF_CONNECTION_DROP_FLUSH_FIFO != 0) {
        // Flush FIFO
        DBG_PRINT("Socket %d closed --> flushing FIFO\r\n", sd);
        XiBIF_resetFifo(peri);
    }

    /* close connection */
    close(sd);
    vTaskDelete(NULL);
}

/**
 * @brief XiBIF own command handler.
 *
 * This function is called when an invalid command is received. It simply
 * prints a message indicating that the command is ignored.
 *
 * @param cmd The command that was received.
 * @param length The length of the payload associated with the command.
 * @param sd The socket descriptor from which the command was received.
 * @param start_time Timestamp when the current command has been received.
 */
__attribute__((weak)) XiBIF_error_t XiBIF_ownCommandHandler(u32 cmd, u32 length, int sd, XTime start_time)
{
    (void)sd; // Remove unused warning
    xil_printf("Ignoring invalid command: 0x%08x\r\n", cmd);

    // Read and ignore the payload
    if(length > 0) {
        if(XiBIF_readDummy(sd, length) != XIB_OK) {
            xil_printf("%d: error reading dummy data for invalid command 0x%08x from socket %d\r\n", __LINE__, cmd, sd);
            return XIB_ERROR;
        }
    }

    // Send response header back to prevent client from waiting indefinitely
    if(XiBIF_writeResponse(sd, cmd, 0, XRESP_COMMAND_NOT_IMPLEMENTED, start_time) != XIB_OK) {
        xil_printf("%d: error writing response header to socket %d\r\n", __LINE__, sd);
        return XIB_ERROR;
    }

    return XIB_OK;
}

/**
 * @brief XiBIF connection checker
 *
 * Checks if the ethernet connection is still available. If not, it will be signalized to the hardware.
 *
 * @param p not used.
 */
void XiBIF_checkCon()
{
    XiBIF_peri_t* peri = XiBIF_getPeri();

    while(1) {
        if(peri->ethernetLink == 0) {
            // Signalize a closed connection to the hardware
            peri->streamRegs->STATUS_CONTROL_TO_HW_bf.HOSTCONNECTED = 0;
            DBG_PRINT("Connection dropped\r\n");

            if(XIBIF_CONNECTION_DROP_FLUSH_FIFO != 0) {
                // Flush FIFO
                DBG_PRINT("Connection dropped --> flushing FIFO\r\n");
                XiBIF_resetFifo(peri);
            }
        }
        vTaskDelay(XIBIF_TIMEOUT_CONNECTION_DROP_MS / portTICK_RATE_MS); // Timeout in ms
    }
}

/**
 * @brief XiBIF echo connection handler.
 *
 * Spawned for each connection, this thread simply echos back whatever is
 * received via Ethernet.
 *
 * @param p The socket from which to read data.
 */
void echo_con(void* p)
{
    int sd = (int)(UINTPTR)p;
    const int RECV_BUF_SIZE = 2048;
    char* buf = pvPortMalloc(RECV_BUF_SIZE);
    int n, nwrote;

    if(buf == NULL) {
        xil_printf("%d: error allocating memory, closing socket %d\r\n", __LINE__, sd);
        close(sd);
        vTaskDelete(NULL);
        return;
    }

    while(1) {
        /* read a max of RECV_BUF_SIZE bytes from socket */
        n = read(sd, buf, RECV_BUF_SIZE);
        if(n <= 0) {
            if(n < 0) {
                xil_printf("%d: error reading from socket %d, closing socket\r\n", __LINE__, sd);
            }
            break;
        }

        /* handle request */
        nwrote = write(sd, buf, n);
        if(nwrote < 0) {
            xil_printf("%s: ERROR responding to client echo request. received = %d, written = %d\r\n", __LINE__, n, nwrote);
            xil_printf("Closing socket %d\r\n", sd);
            break;
        }
    }

    vPortFree(buf);
    /* close connection */
    close(sd);
    vTaskDelete(NULL);
}

/**
 * @brief Simply blink the PS user led.
 *
 * This function is responsible for controlling the blinking of an LED.
 *
 * @param p Pointer to the parameters required for the LED blinking function.
 */
void XiBIF_ledBlink(void* p)
{
    (void)p; // Remove unused warning

    XGpioPs_Config* ConfigPtrPS = XGpioPs_LookupConfig(0);
    XGpioPs led;

    if(ConfigPtrPS == NULL) {
        xil_printf("ERROR: GPIO configuration not found.\r\n");
        vTaskDelete(NULL);
        return;
    }

    if(XGpioPs_CfgInitialize(&led, ConfigPtrPS, ConfigPtrPS->BaseAddr) != XST_SUCCESS) {
        xil_printf("ERROR: GPIO initialization failed.\r\n");
        vTaskDelete(NULL);
        return;
    }

    XGpioPs_SetDirectionPin(&led, 7, 1);
    XGpioPs_SetOutputEnablePin(&led, 7, 1);

    u32 state = 0;
    while(1) {
        state ^= 0x1;
        XGpioPs_WritePin(&led, 7, state);    // MIO7 = LD9
        vTaskDelay(1000 / portTICK_RATE_MS); // Blink delay in ms
    }
}
/**
 * @brief Initializes the XiBIF peripheral.
 *
 * @param peri Pointer to the XiBIF peripheral structure.
 * @param hw_base_stream Hardware base address for the stream.
 * @param hw_base_reg Hardware base address for the register.
 *
 * @return 0 on success, other values on failure.
 *
 * @note The memory for the stream buffers is statically allocated
 *       from 100 MB to 500 MB. Make sure no other software uses this range!
 */
XiBIF_error_t XiBIF_init(XiBIF_peri_t* peri, UINTPTR hw_base_stream, UINTPTR hw_base_reg)
{
    peri->enableDebugOutput = 0;
    peri->streamRegs = (xibif_sreg_t*)hw_base_stream;
    peri->userRegs = (xibif_reg_t*)hw_base_reg;

    xil_printf("Starting XiBIF Initialization...\r\n");
    XiBIF_printVersion("Software version", XIBIF_STREAM_VID);

    /*
   * Check compatibility between hardware and software
   * by comparing version registers
   */
    xil_printf("Starting hardware version checks...\r\n");
    if(XiBIF_checkStreamVersion(peri) != 0) {
        xil_printf("Stream version check failed. Aborting...\r\n");
        return XIB_EINIT;
    }
    xil_printf("Stream version ok.\r\n");

    if(XiBIF_checkRegisterVersion(peri) != 0) {
        xil_printf("Register version check failed. Aborting...\r\n");
        return XIB_EINIT;
    }
    xil_printf("Register version ok.\r\n");
    xil_printf("Hardware version check complete.\r\n");

    /*
   * Check and compare UUID in stream and user registers
   */
    xil_printf("Starting UUID check...\r\n");
    if(XiBIF_checkUUID(peri) != 0) {
        xil_printf("UUID check failed. Aborting...\r\n");
        return XIB_EINIT;
    }
    xil_printf("UUID check complete.\r\n");

    /*
     * Allocate memory for AXI streams and initialize the XiBIF hardware peripherals
     */
    peri->pl2pcStream.enabled = peri->streamRegs->AXI_STREAM_3_bf.ENABLEFIFOTOPC;
    peri->pc2plStream.enabled = peri->streamRegs->AXI_STREAM_3_bf.ENABLEFIFOFROMPC;
    peri->streamRegs->RESET_bf.HALT = 1;
    xil_printf("Starting memory allocation for data stream...\r\n");
    if(XiBIF_initPc2PlMemory(peri, 100 << 20, 200 << 20) != 0) {
        xil_printf("Failed to initialize PC->PL memory! Aborting...\r\n");
        return XIB_EINIT;
    }
    if(XiBIF_initPl2PcMemory(peri, 300 << 20, 200 << 20) != 0) {
        xil_printf("Failed to initialize PL->PC Memory! Aborting...\r\n");
        return XIB_EINIT;
    }
    peri->streamRegs->RESET_bf.HALT = 0;
    xil_printf("Memory allocation for data stream complete.\r\n");

    // Generate Mutex for write access
    peri->mutex = xSemaphoreCreateMutex();
    configASSERT(peri->mutex != NULL);

    peri->initialised = 1;

    xil_printf("Initialised XiBIF stream peripheral at address 0x%08x\r\n", hw_base_stream);
    xil_printf("Initialised XiBIF register peripheral at address 0x%08x\r\n", hw_base_reg);

    // Web server uses embedded files (no filesystem needed)
    xil_printf("Web server ready with embedded files\r\n");

    return XIB_OK;
}

/**
 * @brief Print a 32-bit register as a friendly string
 */
void XiBIF_printVersion(const char* prefix, u32 version)
{
    u32 major;
    u32 minor;
    u32 patch;
    u32 rev;

    major = XIBIF_VERSION_GET_MAJ(version);
    minor = XIBIF_VERSION_GET_MIN(version);
    patch = XIBIF_VERSION_GET_PATCH(version);
    rev = XIBIF_VERSION_GET_REV(version);
    if(rev != 0) {
        xil_printf("%s v%d.%d.%d-rev%d\r\n", prefix, (int)major, (int)minor, (int)patch, (int)rev);
        return;
    }
    xil_printf("%s v%d.%d.%d\r\n", prefix, (int)major, (int)minor, (int)patch);
}

/**
 * @brief Print a build timestamp from a 32-bit register as a friendly string
 */
void XiBIF_printBuildTimestamp(const char* prefix, u32 timestamp)
{ xil_printf("%s %02u.%02u.%02u %02u:%02u:%02u\r\n", prefix, (timestamp >> 27) & 0x1F, (timestamp >> 23) & 0x0F, ((timestamp >> 17) & 0x3F) + 2000, (timestamp >> 12) & 0x1F, (timestamp >> 6) & 0x3F, timestamp & 0x3F); }

/**
 * @brief Read the XiBIF stream version and check that it is compatible with the software
 */
XiBIF_error_t XiBIF_checkStreamVersion(XiBIF_peri_t* peri)
{
    uint32_t reg;

    reg = peri->streamRegs->VERSION;

    XiBIF_printVersion("Read Stream Version", reg);

    if((XIBIF_VERSION_GET_MAJ(reg) != XIBIF_VERSION_GET_MAJ(XIBIF_STREAM_VID)) || (XIBIF_VERSION_GET_MIN(reg) != XIBIF_VERSION_GET_MIN(XIBIF_STREAM_VID))) {
        xil_printf("The stream version at 0x%08x is not compatible with this software.\r\n", peri->streamRegs);

        if(reg == 0) {
            xil_printf("It is likely that there is no XiBIF stream peripheral!\r\n");
        }

        XiBIF_printVersion("Expected stream version (software)", XIBIF_STREAM_VID);
        XiBIF_printVersion("Actual stream version (hardware)", reg);
        return XIB_EVERSION;
    }
    else if(reg != XIBIF_STREAM_VID) {
        xil_printf("Warning: Stream version mismatch at 0x%08x\r\n", peri->streamRegs);

        XiBIF_printVersion("Expected stream version (software)", XIBIF_STREAM_VID);
        XiBIF_printVersion("Actual stream version (hardware)", reg);
        xil_printf("Continuing setup. Verify stream compatibility!\r\n");
    }
    else {
        xil_printf("Stream version matches software version\r\n");
    }
    peri->streamVersion = reg;

    return XIB_OK;
}

/**
 * @brief Read the XiBIF register version and check that it is compatible with the software
 */
XiBIF_error_t XiBIF_checkRegisterVersion(XiBIF_peri_t* peri)
{
    uint32_t reg;

    reg = peri->userRegs->VERSION;

    XiBIF_printVersion("Read Register Version", reg);

    if((XIBIF_VERSION_GET_MAJ(reg) != XIBIF_VERSION_GET_MAJ(XIBIF_STREAM_VID)) || (XIBIF_VERSION_GET_MIN(reg) != XIBIF_VERSION_GET_MIN(XIBIF_STREAM_VID))) {
        xil_printf("The register version at 0x%08x is not compatible with this software.\r\n", peri->userRegs);

        if(reg == 0) {
            xil_printf("It is likely that there is no XiBIF register peripheral!\r\n");
        }

        XiBIF_printVersion("Expected register version (software)", XIBIF_STREAM_VID);
        XiBIF_printVersion("Actual register version (hardware)", reg);
        return XIB_EVERSION;
    }
    else if(reg != XIBIF_STREAM_VID) {
        xil_printf("Warning: Stream version mismatch at 0x%08x\r\n", peri->userRegs);

        XiBIF_printVersion("Expected register version (software)", XIBIF_STREAM_VID);
        XiBIF_printVersion("Actual register version (hardware)", reg);
        xil_printf("Continuing setup. Verify register compatibility!\r\n");
    }
    else {
        xil_printf("Register version matches software version\r\n");
    }
    peri->registerVersion = reg;

    return XIB_OK;
}

/**
 * @brief Read the stream and register UUIDs and check that they are equal
 */
XiBIF_error_t XiBIF_checkUUID(XiBIF_peri_t* peri)
{

    u32 id_stream;
    u32 id_regs;

    id_stream = peri->streamRegs->UUID_bf.UUID;
    id_regs = peri->userRegs->UUID_bf.UUID;

    xil_printf("Read stream UUID: 0x%08x\r\n", id_stream);
    xil_printf("Read register UUID: 0x%08x\r\n", id_regs);
    if(id_stream != id_regs) {
        xil_printf("Stream and register UUIDs do not match!\r\n");
        return XIB_ERROR;
    }

    peri->streamUuid = id_stream;
    peri->registerUuid = id_regs;
    return XIB_OK;
}

/**
 * @brief Initialize PL -> PC memory
 *
 * This function initializes the PL -> PC hardware FIFO if enabled. The head
 * and tail poionter of the hardware FIFO is synchronized to the software.
 *
 * @param peri Pointer to a XiBIF peripheral
 * @param base Base address of the memory region to allocate for stream data
 * @param size Size in bytes of the memory region to allocate for stream data
 * @returns 0 if init is successful, non-zero otherwise
 */
XiBIF_error_t XiBIF_initPl2PcMemory(XiBIF_peri_t* peri, u32 base, u32 size)
{

    if(peri->pl2pcStream.enabled == 0) {
        peri->pl2pcStream.lowAddress = 0;
        peri->pl2pcStream.highAddress = 0;
        peri->pl2pcStream.fifoDepth = 0;
        peri->pl2pcStream.size = 0;
        xil_printf("PL2PC stream disabled.\r\n");
        return XIB_OK;
    }

    u32 reg;

    xil_printf("Allocation 0x%08x bytes of PL->PC memory at address 0x%08x...\r\n", size, base);
    peri->pl2pcStream.fifoDepth = peri->streamRegs->AXI_STREAM_2_bf.WIDTH;
    xil_printf("PL->PC hardware FIFO depth: 0x%08x\r\n", peri->pl2pcStream.fifoDepth);

    peri->pl2pcStream.lowAddress = base;
    peri->pl2pcStream.highAddress = base + size;
    peri->pl2pcStream.size = size;

    peri->streamRegs->FIFO_TO_PC_1_bf.LOW = peri->pl2pcStream.lowAddress;
    peri->streamRegs->FIFO_TO_PC_2_bf.HIGH = peri->pl2pcStream.highAddress;
    XiBIF_resetFifo(peri); // Is required to reset head and tail

    reg = peri->streamRegs->FIFO_TO_PC_4_bf.HEAD;
    if(reg != peri->pl2pcStream.lowAddress) {
        xil_printf("PL->PC head is not at the initial address 0x%08x but 0x%08x\r\n", peri->pl2pcStream.lowAddress, reg);
        return XIB_ERROR;
    }

    reg = peri->streamRegs->FIFO_TO_PC_5_bf.TAIL;
    if(reg != peri->pl2pcStream.lowAddress) {
        xil_printf("PL->PC tail is not at the initial address 0x%08x but 0x%08x\r\n", peri->pl2pcStream.lowAddress, reg);
        return XIB_ERROR;
    }

    xil_printf("Successfully allocated PL->PC memory.\r\n");

    return XIB_OK;
}

/**
 * @brief Initialize PC -> PL memory
 *
 * This function initializes the PC -> PL hardware FIFO if enabled. The head
 * and tail poionter of the hardware FIFO is synchronized to the software.
 *
 * @param peri Pointer to a XiBIF peripheral
 * @param base Base address of the memory region to allocate for stream data
 * @param size Size in bytes of the memory region to allocate for stream data
 * @returns 0 if init is successful, non-zero otherwise
 */
XiBIF_error_t XiBIF_initPc2PlMemory(XiBIF_peri_t* peri, u32 base, u32 size)
{

    if(peri->pc2plStream.enabled == 0) {
        peri->pc2plStream.lowAddress = 0;
        peri->pc2plStream.highAddress = 0;
        peri->pc2plStream.fifoDepth = 0;
        peri->pc2plStream.size = 0;
        xil_printf("PC2PL stream disabled.\r\n");
        return XIB_OK;
    }

    u32 reg;

    xil_printf("Allocation 0x%08x bytes of PC->PL memory at address 0x%08x...\r\n", size, base);

    peri->pc2plStream.fifoDepth = peri->streamRegs->AXI_STREAM_2_bf.WIDTH;
    xil_printf("PC->PL hardware FIFO depth: 0x%08x\r\n", peri->pc2plStream.fifoDepth);

    peri->pc2plStream.lowAddress = base;
    peri->pc2plStream.highAddress = base + size;
    peri->pc2plStream.size = size;

    peri->streamRegs->FIFO_FROM_PC_1_bf.LOW = peri->pc2plStream.lowAddress;
    peri->streamRegs->FIFO_FROM_PC_2_bf.HIGH = peri->pc2plStream.highAddress;
    XiBIF_resetFifo(peri); // Is required to reset head and tail

    reg = peri->streamRegs->FIFO_FROM_PC_4_bf.HEAD;
    if(reg != peri->pc2plStream.lowAddress) {
        xil_printf("PC->PL head is not at the initial address 0x%08x but 0x%08x\r\n", peri->pc2plStream.lowAddress, reg);
        return XIB_ERROR;
    }

    reg = peri->streamRegs->FIFO_FROM_PC_5_bf.TAIL;
    if(reg != peri->pc2plStream.lowAddress) {
        xil_printf("PC->PL tail is not at the initial address 0x%08x but 0x%08x\r\n", peri->pc2plStream.lowAddress, reg);
        return XIB_ERROR;
    }

    xil_printf("Successfully allocated PC->PL memory.\r\n");

    return XIB_OK;
}

/**
 * @brief Sets a register in the XiBIF peripheral.
 *
 * This function sets the specified register in the XiBIF peripheral to the
 * given data value. It first checks if the peripheral is initialized using an
 * assertion.
 *
 * @param peri Pointer to the XiBIF peripheral structure.
 * @param address Register address relative to register block.
 * @param data The data value to set the register to.
 */
void XiBIF_setReg(XiBIF_peri_t* peri, u32 address, u32 data)
{
    configASSERT(peri->initialised);
    volatile u32* ptr = (u32*)((UINTPTR)(peri->userRegs) + (address));

    DBG_PRINT("Set reg %03d (0x%08X) to 0x%08x\r\n", address, ptr, data);
    *ptr = data;
}

/**
 * @brief Reads a register value from a peripheral.
 *
 * This function reads the value of a specified register from a given
 * peripheral. It asserts that the peripheral has been initialized before
 * attempting to read the register.
 *
 * @param peri Pointer to the peripheral structure.
 * @param address Register address relative to register block.
 * @return The value of the specified register.
 */
u32 XiBIF_getReg(XiBIF_peri_t* peri, u32 address)
{
    configASSERT(peri->initialised);
    u32* ptr = (u32*)((UINTPTR)(peri->userRegs) + (address)); // cppcheck-suppress constVariablePointer

    return *ptr;
}

/**
 * @brief Programs the FPGA with a bitstream received over a socket.
 *
 * This function reads a bitstream from a socket and programs the FPGA with it.
 * It supports both Zynq and ZynqMP platforms.
 *
 * The function performs the following steps:
 * 1. Initializes the device configuration interface.
 * 2. Reads the length of the bitstream from the socket.
 * 3. Allocates memory for the bitstream.
 * 4. Reads the bitstream data from the socket.
 * 5. Programs the FPGA with the bitstream.
 * 6. Reinitializes the AXI peripheral.
 * 7. Frees the allocated memory.
 *
 * @note The function handles both Zynq and ZynqMP platforms differently.
 *       For Zynq, it uses the XDcfg driver, and for ZynqMP, it uses the XFpga
 * driver.
 *
 * @param sd The socket descriptor to read the bitstream from.
 * @return XIB_OK on success, other values on failure.
 */
XiBIF_error_t XiBIF_programBitstream(int sd, u32 length)
{
    u32 address_stream = XPAR_XIBIF_BASEADDR;
    u32 address_reg = XPAR_XIBIF_REG_BASEADDR;
    u8* buffer;
    XiBIF_peri_t* peri = XiBIF_getPeri();

#if defined(PLATFORM_ZYNQ)
    u32 IntrStsReg = 0;
    int Status;
    XDcfg_Config* ConfigPtr;
    XDcfg DcfgInstance; /*Instance of the Device Configuration*/

    // Initialize the device for programming
    // Get Configuration Pointer Information
    ConfigPtr = XDcfg_LookupConfig(XPAR_XDCFG_0_DEVICE_ID);
    if(ConfigPtr == NULL) {
        // Close connection and delete task
        DBG_PRINT("Closed Bitstream stream connection (socket %d).\r\n", sd);
        return XIB_ERROR;
    }

    // Initialize the Device Config
    Status = XDcfg_CfgInitialize(&DcfgInstance, ConfigPtr, ConfigPtr->BaseAddr);
    if(Status != XST_SUCCESS) {
        DBG_PRINT("Closed Bitstream stream connection (socket %d).\r\n", sd);
        return XIB_ERROR;
    }

    // The very first APB access to the Device Configuration Interface
    // block needs to be a write to the UNLOCK register with the value
    // of 0x757BDF0D.
    XDcfg_SetLockRegister(&DcfgInstance, 0x757BDF0D);

#elif defined(PLATFORM_ZYNQMP)
    int Status;
    XFpga XFpgaInstance = {0U};

    // Initialize the device for programming
    Status = XFpga_Initialize(&XFpgaInstance);
    if(Status != XST_SUCCESS) {
        DBG_PRINT("Closed Bitstream stream connection (socket %d).\r\n", sd);
        return XIB_ERROR;
    }
#endif

    // Receive the bitstream if we received a length
    if(length > 0) {
        // Remove the length of the two AXI addresses that are sent before the bitstream data
        length = length - 2 * sizeof(u32);

        // Get some memory
        buffer = pvPortMalloc(length);

        // Read the new axi-address of the XIBIF Stream
        if(XiBIF_readSocketData(sd, &address_stream, sizeof(address_stream)) != XIB_OK) {
            vPortFree(buffer);
            return XIB_ERROR;
        }

        // Read the new axi-address of the XIBIF Register
        if(XiBIF_readSocketData(sd, &address_reg, sizeof(address_reg)) != XIB_OK) {
            vPortFree(buffer);
            return XIB_ERROR;
        }

        /* handle request */
        if(XiBIF_readSocketData(sd, buffer, length) != XIB_OK) {
            xil_printf("%d: error reading from socket %d, closing socket\r\n", __LINE__, sd);
            vPortFree(buffer);
            return XIB_ERROR;
        }

#if defined(PLATFORM_ZYNQ)
        // Clear DMA and PCAP Done Interrupts
        XDcfg_IntrClear(&DcfgInstance, (XDCFG_IXR_DMA_DONE_MASK | XDCFG_IXR_D_P_DONE_MASK));

        // Download bitstream in non secure mode
        Status = XDcfg_Transfer(&DcfgInstance, (u32*)&buffer[0], length >> 2, (u32*)XDCFG_DMA_INVALID_ADDRESS, 0, XDCFG_NON_SECURE_PCAP_WRITE);
        if(Status != XST_SUCCESS) {
            xil_printf("Error programming bitstream.\r\n");
            vPortFree(buffer);
            return XIB_ERROR;
        }

        // Poll DMA Done Interrupt
        while((IntrStsReg & XDCFG_IXR_DMA_DONE_MASK) != XDCFG_IXR_DMA_DONE_MASK)
            IntrStsReg = XDcfg_IntrGetStatus(&DcfgInstance);

        // Poll PCAP Done Interrupt
        while((IntrStsReg & XDCFG_IXR_D_P_DONE_MASK) != XDCFG_IXR_D_P_DONE_MASK)
            IntrStsReg = XDcfg_IntrGetStatus(&DcfgInstance);

#elif defined(PLATFORM_ZYNQMP)
        // Download bitstream in non secure mode
        Status = XFpga_BitStream_Load(&XFpgaInstance, (UINTPTR)&buffer[0], (UINTPTR)NULL, length, XFPGA_FULLBIT_EN);
        if(Status != XST_SUCCESS) {
            xil_printf("Error programming bitstream.\r\n");
            vPortFree(buffer);
            return XIB_ERROR;
        }

        // Reset PL
        XFpga_PsPlGpioResetsLow();
        usleep(10);
        XFpga_PsPlGpioResetsHigh();
#endif

        // Reinit xibif
        if(XiBIF_init(peri, address_stream, address_reg) != XIB_OK) {
            xil_printf("An error occured while trying to re-initialize XiBIF after bitstream writing!");
        }
        configASSERT(peri->initialised == 1);

        // Free the memory
        vPortFree(buffer);
    }

    return XIB_OK;
}

/**
 * @brief Reads a stream of data from a given socket descriptor.
 *
 * This function reads data from a stream and writes it to a socket descriptor.
 * It continues reading until the specified length of data has been read.
 *
 * @param sd The socket descriptor to write the data to.
 * @param length The length of data to read from the stream.
 * @return XiBIF_error_t indicating success or failure of the operation.
 */
XiBIF_error_t XiBIF_readStream(int sd, u32 length)
{
    int n;
    u32* tail;
    u8 tmp;
    int errsv;
    XiBIF_peri_t* peri = XiBIF_getPeri();

    while(length > 0) {
        n = XiBIF_streamGetTail(peri, &tail);
        n = min(n, min(length, MAX_PKT_SIZE));

        if(n > 0) {
#if defined(PLATFORM_ZYNQMP)
            Xil_DCacheInvalidateRange((UINTPTR)tail, n);
#endif
            if(XiBIF_writeSocketData(sd, (u8*)tail, n) != XIB_OK) {
                return XIB_ERROR;
            }
            XiBIF_streamAdvanceTail(peri, n);
            length -= n;
            DBG_PRINT("Read %4d bytes from 0x%08x. %4d bytes remaining. \r\n", n, (u32)(UINTPTR)tail, length);
        }
        else if(recv(sd, &tmp, 1, MSG_PEEK | MSG_DONTWAIT) < 0) {
            errsv = errno;
            if(errsv != EAGAIN) {
                xil_printf("%d: ERROR connection was forcefully closed.\r\n", __LINE__);
                return XIB_ERROR;
            }
        }
        else {
            DBG_PRINT("Requested %5d bytes but no data available!\r\n", length);
        }
    }
    DBG_PRINT("Read request complete\r\n");
    return XIB_OK;
}

/**
 * @brief Writes a stream of data to a specified socket descriptor.
 *
 * This function writes a stream of data to a socket descriptor `sd` until the
 * specified length is exhausted. It reads data from the socket and writes it to
 * a buffer, managing cache invalidation and flushing as necessary.
 *
 * @param sd The socket descriptor to write data to.
 * @param length The total length of data to be written.
 * @return XiBIF_error_t indicating success or failure of the operation.
 */
XiBIF_error_t XiBIF_writeStream(int sd, u32 length)
{
    int n;
    u32* head;
    XiBIF_peri_t* peri = XiBIF_getPeri();

    while(length > 0) {
        n = XiBIF_streamGetHead(peri, &head);

        // Check if there is no more space available
        if(n == 0) {
            DBG_PRINT("No more space available, setting error flag.\r\n");
            peri->streamRegs->FIFO_FROM_PC_3_bf.ERROR_MEMFULL = 1;
        }

        n = min(n, length);

        if(n > 0) {
            if(XiBIF_readSocketData(sd, (u8*)head, n) != XIB_OK) {
                xil_printf("%d: ERROR responding to client stream write data request. Requested = %d\r\n", __LINE__, n);
                return XIB_ERROR;
            }
#if defined(PLATFORM_ZYNQMP)
            Xil_DCacheFlushRange((UINTPTR)head, n);
#endif
            XiBIF_streamAdvanceHead(peri, n);
            length -= n;
            DBG_PRINT("Wrote %4d bytes to 0x%08x. %4d bytes remaining \r\n", n, (u32)(UINTPTR)head, length);
        }
        else {
            DBG_PRINT("Requested %5d bytes but no more space available!\r\n", length);
        }
    }
    DBG_PRINT("Write request complete\r\n");
    return XIB_OK;
}

/**
 * @brief Retrieves the head of the stream for the specified peripheral.
 *
 * This function retrieves the head of the stream from the hardware base stream
 * address and calculates the distance to the tail.
 *
 * @param peri Pointer to the XiBIF peripheral structure.
 * @param head Pointer to a variable where the head address will be stored.
 * @return The number of bytes available to write to the stream.
 */
inline u32 XiBIF_streamGetHead(XiBIF_peri_t* peri, u32** head)
{
    *head = (u32*)(UINTPTR)peri->streamRegs->FIFO_FROM_PC_4_bf.HEAD;
    return (peri->pc2plStream.size - XiBIF_getFromPcSwFifoOcc(peri));
}

/**
 * @brief Retrieves the tail of the stream for the specified peripheral.
 *
 * This function retrieves the tail of the stream for the given peripheral and
 * stores the address of the tail in the provided pointer.
 *
 * @param peri Pointer to the XiBIFperipheral structure.
 * @param tail Pointer to a variable where the address of the tail will be
 * stored.
 * @return The number of bytes available to read from the stream.
 */
inline u32 XiBIF_streamGetTail(XiBIF_peri_t* peri, u32** tail)
{
    *tail = (u32*)(UINTPTR)peri->streamRegs->FIFO_TO_PC_5_bf.TAIL;
    return (XiBIF_getToPcSwFifoOcc(peri));
}

/**
 * @brief Retrieves the occupancy of the software FIFO from the PC.
 *
 * This function returns the current occupancy level of the software FIFO
 * associated with the specified peripheral.
 *
 * @param peri Pointer to the XiBIF_peri_t structure representing the
 * peripheral.
 * @return The occupancy level of the software FIFO.
 */
inline u32 XiBIF_getFromPcSwFifoOcc(XiBIF_peri_t* peri)
{
    u32 head = peri->streamRegs->FIFO_FROM_PC_4_bf.HEAD;
    u32 tail = peri->streamRegs->FIFO_FROM_PC_5_bf.TAIL;

    u32 fill = head - tail;
    DBG_PRINT("Stream from PC:\r\n");
    if(head < tail) {
        fill = peri->pc2plStream.size - (tail - head);
        DBG_PRINT("    Head < Tail\r\n");
    }
    else {
        DBG_PRINT("    Head >= Tail\r\n");
    }
    DBG_PRINT("    Head: 0x%08x\r\n", head);
    DBG_PRINT("    Tail: 0x%08x\r\n", tail);
    DBG_PRINT("    Fill: 0x%08x\r\n", fill);

    return fill;
}

/**
 * @brief Retrieves the occupancy of the software FIFO to the PC.
 *
 * This function returns the current occupancy level of the software FIFO
 * associated with the specified peripheral.
 *
 * @param peri Pointer to the XiBIF peripheral structure.
 * @return u32 Current occupancy of the ToPc software FIFO.
 */
inline u32 XiBIF_getToPcSwFifoOcc(XiBIF_peri_t* peri)
{
    u32 head = peri->streamRegs->FIFO_TO_PC_4_bf.HEAD;
    u32 tail = peri->streamRegs->FIFO_TO_PC_5_bf.TAIL;

    u32 fill = head - tail;

    DBG_PRINT("Stream to PC:\r\n");
    if(head < tail) {
        fill = peri->pl2pcStream.size - (tail - head);
        DBG_PRINT("    Head < Tail\r\n");
    }
    else {
        DBG_PRINT("    Head >= Tail\r\n");
    }
    DBG_PRINT("    Head: 0x%08x\r\n", head);
    DBG_PRINT("    Tail: 0x%08x\r\n", tail);
    DBG_PRINT("    Fill: 0x%08x\r\n", fill);

    return fill;
}

/**
 * @brief Writes the register map to a socket descriptor.
 *
 * This function sends the register map in JSON format to the specified
 * socket descriptor. It first sends the length of the register map, followed
 * by the actual register map data.
 *
 * @param sd The socket descriptor to which the register map will be sent.
 * @param start_time Timestamp when the current command has been started.
 * @return XiBIF_error_t indicating success or failure of the operation.
 */
XiBIF_error_t XiBIF_writeRegistermap(int sd, XTime start_time)
{
    const char* registermap = XIBIF_REG_RMAP_JSON;
    u32 length = strlen(registermap);
    u32 zeroPadding = 0;
    u32 requiredPadding = sizeof(u32) - length % sizeof(u32);

    // Write the header
    if(XiBIF_writeResponse(sd, XCMD_REGMAP_GET, length + requiredPadding, XRESP_OK, start_time) != XIB_OK) {
        return XIB_ERROR;
    }

    // Send the registermap JSON string
    if(XiBIF_writeSocketData(sd, (void*)registermap, length) != XIB_OK) {
        xil_printf("%d: ERROR sending registermap data.\r\n", __LINE__);
        return XIB_ERROR;
    }

    // Send the padding
    if(requiredPadding > 0) {
        if(XiBIF_writeSocketData(sd, &zeroPadding, requiredPadding) != XIB_OK) {
            xil_printf("%d: ERROR sending padding.\r\n", __LINE__);
            return XIB_ERROR;
        }
    }

    DBG_PRINT("Sent registermap: %d bytes\r\n", length + requiredPadding);
    return XIB_OK;
}
