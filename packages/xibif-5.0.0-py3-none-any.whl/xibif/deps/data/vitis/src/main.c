/*
 * Main file for XiBIF project
 */

#include "XiBIF.h"
#include "sleep.h"
#include "xil_io.h"
#include "xil_printf.h"

void print_initial_message()
{
    outbyte('\r');
    for(int cnt = 0; cnt < 200; ++cnt) {
        outbyte('\n');
    }
    xil_printf("Main file compiled on %s, %s\r\n", __DATE__, __TIME__);
}

__attribute__((weak)) void XiBIF_startUp()
{ asm("NOP"); }

static inline void Xbir_MaskWrite(u32 Reg, u32 Mask, u32 Val)
{
    u32 RegVal = Xil_In32(Reg) & (~Mask);

    RegVal |= (Val & Mask);
    Xil_Out32(Reg, RegVal);
}

#if defined(PLATFORM_ZYNQMP)
static inline void Xbir_MaskPoll(u32 Reg, u32 Mask, u32 Value)
{
    u32 count = 1;
    u32 RegVal = Xil_In32(Reg) & (Mask);
    while(RegVal != Value) {
        RegVal = Xil_In32(Reg) & (Mask);
        count += 1;
        usleep(1000);
        if(count >= 1000) {
            xil_printf("Timeout Reached while booting up PL.");
            break;
        }
    }
}
#endif

#if defined(PLATFORM_ZYNQ)
    #include <xil_misc_psreset_api.h>
    #ifndef XSLCR_FPGA_RST_CTRL_ADDR
        #define XSLCR_FPGA_RST_CTRL_ADDR (XSLCR_BASEADDR + 0x00000240U)
    #endif
    #ifndef XSLCR_LOCK_ADDR
        #define XSLCR_LOCK_ADDR (XSLCR_BASEADDR + 0x4)
    #endif
    #ifndef XSLCR_LOCK_CODE
        #define XSLCR_LOCK_CODE 0x0000767B
    #endif

void bootup()
{
    Xbir_MaskWrite(XSLCR_UNLOCK_ADDR, 0xFFFFFFFFU, XSLCR_UNLOCK_CODE);
    Xbir_MaskWrite(XSLCR_FPGA_RST_CTRL_ADDR, 0x0000000FU, 0x0000000FU);
    usleep(15);

    // and release the FPGA Reset Signal
    Xbir_MaskWrite(XSLCR_FPGA_RST_CTRL_ADDR, 0x0000000FU, 0x00000000U);
    Xbir_MaskWrite(XSLCR_LOCK_ADDR, 0xFFFFFFFFU, XSLCR_LOCK_CODE);
    usleep(5);
}

#elif defined(PLATFORM_ZYNQMP)
void bootup()
{
    /*SMMU_REG Interrrupt Enable: Followig register need to be written all the time to properly catch SMMU messages.*/
    Xbir_MaskWrite(0xFD5F0018, 0x8000001FU, 0x8000001FU);

    /*
    * PS-PL POWER UP REQUEST
    */
    /*
    * Register : REQ_PWRUP_INT_EN @ 0XFFD80118

    * Power-up Request Interrupt Enable for PL
    *  PSU_PMU_GLOBAL_REQ_PWRUP_INT_EN_PL                          1

    * Power-up Request Interrupt Enable Register. Writing a 1 to this location
    *  will unmask the interrupt.
    * (OFFSET, MASK, VALUE)      (0XFFD80118, 0x00800000U ,0x00800000U)
    */
    Xbir_MaskWrite(0XFFD80118, 0x00800000U, 0x00800000U);

    /*
    * Register : REQ_PWRUP_TRIG @ 0XFFD80120

    * Power-up Request Trigger for PL
    *  PSU_PMU_GLOBAL_REQ_PWRUP_TRIG_PL                            1

    * Power-up Request Trigger Register. A write of one to this location will
    * generate a power-up request to the PMU.
    * (OFFSET, MASK, VALUE)      (0XFFD80120, 0x00800000U ,0x00800000U)
    */
    Xbir_MaskWrite(0XFFD80120, 0x00800000U, 0x00800000U);

    /*
    * POLL ON PL POWER STATUS
    */
    /*
    * Register : REQ_PWRUP_STATUS @ 0XFFD80110

    * Power-up Request Status for PL
    *  PSU_PMU_GLOBAL_REQ_PWRUP_STATUS_PL                          1
    * (OFFSET, MASK, VALUE)      (0XFFD80110, 0x00800000U ,0x00000000U)
		*/
    Xbir_MaskPoll(0XFFD80110, 0x00800000U, 0x00000000U);

    /*
    * AFI RESET
    */
    /*
    * Register : RST_FPD_TOP @ 0XFD1A0100

    * AF_FM0 block level reset
    *  PSU_CRF_APB_RST_FPD_TOP_AFI_FM0_RESET                       0

    * AF_FM1 block level reset
    *  PSU_CRF_APB_RST_FPD_TOP_AFI_FM1_RESET                       0

    * AF_FM2 block level reset
    *  PSU_CRF_APB_RST_FPD_TOP_AFI_FM2_RESET                       0

    * AF_FM3 block level reset
    *  PSU_CRF_APB_RST_FPD_TOP_AFI_FM3_RESET                       0

    * AF_FM4 block level reset
    *  PSU_CRF_APB_RST_FPD_TOP_AFI_FM4_RESET                       0

    * AF_FM5 block level reset
    *  PSU_CRF_APB_RST_FPD_TOP_AFI_FM5_RESET                       0

    * FPD Block level software controlled reset
    * (OFFSET, MASK, VALUE)      (0XFD1A0100, 0x00001F80U ,0x00000000U)
    */
    Xbir_MaskWrite(0XFD1A0100, 0x00001F80U, 0x00000000U);

    /*
    * Register : RST_LPD_TOP @ 0XFF5E023C

    * AFI FM 6
    *  PSU_CRL_APB_RST_LPD_TOP_AFI_FM6_RESET                       0

    * Software control register for the LPD block.
    * (OFFSET, MASK, VALUE)      (0XFF5E023C, 0x00080000U ,0x00000000U)
    */
    Xbir_MaskWrite(0XFF5E023C, 0x00080000U, 0x00000000U);

    /*
    * AFIFM INTERFACE WIDTH
    */
    /*
    * Register : afi_fs @ 0XFD615000

    * Select the 32/64/128-bit data width selection for the Slave 0 00: 32-bit
    *  AXI data width (default) 01: 64-bit AXI data width 10: 128-bit AXI data
    *  width 11: reserved
    *  PSU_FPD_SLCR_AFI_FS_DW_SS0_SEL                              0x0

    * afi fs SLCR control register. This register is static and should not be
    * modified during operation.
    * (OFFSET, MASK, VALUE)      (0XFD615000, 0x00000300U ,0x00000000U)
    */
    Xbir_MaskWrite(0XFD615000, 0x00000300U, 0x00000000U);

    /*
    * Register : AFIFM_RDCTRL @ 0XFD360000

    * Configures the Read Channel Fabric interface width. 2'b11 : Reserved 2'b
    * 10 : 32-bit Fabric 2'b01 : 64-bit enabled 2'b00 : 128-bit enabled
    *  PSU_AFIFM0_AFIFM_RDCTRL_FABRIC_WIDTH                        0x0

    * Read Channel Control Register
    * (OFFSET, MASK, VALUE)      (0XFD360000, 0x00000003U ,0x00000000U)
    */
    Xbir_MaskWrite(0XFD360000, 0x00000003U, 0x00000000U);

    /*
    * Register : AFIFM_WRCTRL @ 0XFD360014

    * Configures the Write Channel Fabric interface width. 2'b11 : Reserved 2'
    * b10 : 32-bit Fabric 2'b01 : 64-bit enabled 2'b00 : 128-bit enabled
    *  PSU_AFIFM0_AFIFM_WRCTRL_FABRIC_WIDTH                        0x0

    * Write Channel Control Register
    * (OFFSET, MASK, VALUE)      (0XFD360014, 0x00000003U ,0x00000000U)
    */
    Xbir_MaskWrite(0XFD360014, 0x00000003U, 0x00000000U);
    usleep(1000);

    /*
    * PS PL RESET SEQUENCE
    */
    /*
    * FABRIC RESET USING EMIO
    */
    /*
    * Register : MASK_DATA_5_MSW @ 0XFF0A002C

    * Operation is the same as MASK_DATA_0_LSW[MASK_0_LSW]
    *  PSU_GPIO_MASK_DATA_5_MSW_MASK_5_MSW                         0x8000

    * Maskable Output Data (GPIO Bank5, EMIO, Upper 16bits)
    * (OFFSET, MASK, VALUE)      (0XFF0A002C, 0xFFFF0000U ,0x80000000U)
    */
    Xbir_MaskWrite(0XFF0A002C, 0xFFFFFFFFU, 0x80000000U);

    /*
    * Register : DIRM_5 @ 0XFF0A0344

    * Operation is the same as DIRM_0[DIRECTION_0]
    *  PSU_GPIO_DIRM_5_DIRECTION_5                                 0x80000000

    * Direction mode (GPIO Bank5, EMIO)
    * (OFFSET, MASK, VALUE)      (0XFF0A0344, 0xFFFFFFFFU ,0x80000000U)
    */
    Xbir_MaskWrite(0XFF0A0344, 0xFFFFFFFFU, 0x80000000U);

    /*
    * Register : OEN_5 @ 0XFF0A0348

    * Operation is the same as OEN_0[OP_ENABLE_0]
    *  PSU_GPIO_OEN_5_OP_ENABLE_5                                  0x80000000

    * Output enable (GPIO Bank5, EMIO)
    * (OFFSET, MASK, VALUE)      (0XFF0A0348, 0xFFFFFFFFU ,0x80000000U)
    */
    Xbir_MaskWrite(0XFF0A0348, 0xFFFFFFFFU, 0x80000000U);

    /*
    * Register : DATA_5 @ 0XFF0A0054

    * Output Data
    *  PSU_GPIO_DATA_5_DATA_5                                      0x80000000

    * Output Data (GPIO Bank5, EMIO)
    * (OFFSET, MASK, VALUE)      (0XFF0A0054, 0xFFFFFFFFU ,0x80000000U)
    */
    Xbir_MaskWrite(0XFF0A0054, 0xFFFFFFFFU, 0x80000000U);
    usleep(1000);

    /*
    * FABRIC RESET USING DATA_5 TOGGLE
    */
    /*
    * Register : DATA_5 @ 0XFF0A0054

    * Output Data
    *  PSU_GPIO_DATA_5_DATA_5                                      0X00000000

    * Output Data (GPIO Bank5, EMIO)
    * (OFFSET, MASK, VALUE)      (0XFF0A0054, 0xFFFFFFFFU ,0x00000000U)
    */
    Xbir_MaskWrite(0XFF0A0054, 0xFFFFFFFFU, 0x00000000U);
    usleep(1000);

    /*
    * FABRIC RESET USING DATA_5 TOGGLE
    */
    /*
    * Register : DATA_5 @ 0XFF0A0054

    * Output Data
    *  PSU_GPIO_DATA_5_DATA_5                                      0x80000000

    * Output Data (GPIO Bank5, EMIO)
    * (OFFSET, MASK, VALUE)      (0XFF0A0054, 0xFFFFFFFFU ,0x80000000U)
    */
    Xbir_MaskWrite(0XFF0A0054, 0xFFFFFFFFU, 0x80000000U);
    usleep(1000);

    /*
    * BOOT PIN HIGH
    */
    /*
    * Register : BOOT_PIN_CTRL @ 0XFF5E0250

    * Value driven onto the mode pins, when out_en = 1
    *  PSU_CRL_APB_BOOT_PIN_CTRL_OUT_VAL                           0X2

    * When 0, the pins will be inputs from the board to the PS. When 1, the PS
    *  will drive these pins
    *  PSU_CRL_APB_BOOT_PIN_CTRL_OUT_EN                            0X2

    * Used to control the mode pins after boot.
    * (OFFSET, MASK, VALUE)      (0XFF5E0250, 0x00000F0FU ,0x00000202U)
    */
    Xbir_MaskWrite(0XFF5E0250, 0x00000F0FU, 0x00000202U);
}
#else
void bootup()
{ sleep(10); }
#endif

int main()
{
    //Xil_DCacheDisable();
    //Xil_ICacheDisable();

    // Boot up PL and enable PS clocks --> perform reset
    bootup();

    XiBIF_startUp();

    print_initial_message();

    XiBIF_setupMainTask();

    xil_printf("PS up and running! Starting FreeRTOS scheduler.\r\n");
    vTaskStartScheduler();

    while(1) {
        // Infinite loop to keep the main function running
    }

    return 0;
}
