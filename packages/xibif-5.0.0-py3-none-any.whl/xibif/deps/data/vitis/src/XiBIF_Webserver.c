/*
 * XiBIF_Webserver.c
 *
 * Web server functionality for XiBIF.
 * Provides REST API for register access only (no static files served).
 */

#include "XiBIF_Webserver.h"
#include "XiBIF.h"
#include "XiBIF_settings.h"
#include <lwip/sockets.h>

/**
 * @brief Send data in chunks to avoid timeout.
 *
 * @param sd Socket descriptor
 * @param data Pointer to data
 * @param length Total length to send
 * @return XIB_OK on success, XIB_ERROR on error
 */
static XiBIF_error_t XiBIF_webSendData(int sd, const unsigned char* data, unsigned int length)
{
    int nwrote;
    unsigned int remaining = length;
    const unsigned char* ptr = data;
    unsigned int chunk_size;
    unsigned int sent_in_chunk;

    while(remaining > 0) {
        // Send in chunks, max MAX_PKT_SIZE at a time
        chunk_size = (remaining > MAX_PKT_SIZE) ? MAX_PKT_SIZE : remaining;
        sent_in_chunk = 0;

        while(sent_in_chunk < chunk_size) {
            nwrote = write(sd, ptr + sent_in_chunk, chunk_size - sent_in_chunk);

            if(nwrote <= 0) {
                xil_printf("%s: ERROR writing to socket. Tried = %u, written = %d\r\n", __FUNCTION__, chunk_size, nwrote);
                return XIB_ERROR;
            }
            sent_in_chunk += nwrote;
        }
        ptr += chunk_size;
        remaining -= chunk_size;
    }
    return XIB_OK;
}

/**
 * @brief Read data from socket until a specific number of bytes is received.
 * @param sd Socket descriptor
 * @param buffer Buffer to read into
 * @param length Number of bytes to read
 * @return Number of bytes read on success, -1 on error, 0 on connection closed
 */
static int XiBIF_webReadData(int sd, char* buffer, size_t length)
{
    size_t total = 0;
    int n;

    while(total < length) {
        n = read(sd, buffer + total, length - total);
        if(n <= 0) {
            if(n < 0) {
                DBG_PRINT("Socket read error on socket %d after %u bytes (n=%d, errno=%d)\r\n", sd, (unsigned int)total, n, errno);
            }
            return n; // error or connection closed
        }
        total += n;
    }

    return (int)total;
}

/**
 * @brief Read body of known length and zero-terminate.
 * @param sd Socket descriptor
 * @param buffer Destination buffer
 * @param buffer_size Size of destination buffer
 * @param length Number of payload bytes to read (must be < buffer_size)
 * @return XIB_OK on success, XIB_ERROR on error/close/overflow
 */
static XiBIF_error_t XiBIF_webReadBody(int sd, char* buffer, size_t buffer_size, u32 length)
{
    if(length >= buffer_size)
        return XIB_ERROR;

    if(XiBIF_webReadData(sd, buffer, length) <= 0)
        return XIB_ERROR;

    buffer[length] = '\0';
    return XIB_OK;
}

/**
 * @brief Read HTTP header byte by byte until CRLFCRLF or buffer full, with timeout.
 * @return Number of bytes read up to and including the header end (excluding body), -1 on timeout/error/close
 */
static int XiBIF_webReadHeader(int sd, char* request, size_t max_len)
{
    size_t total = 0;
    int n;
    TickType_t start_tick;
    TickType_t elapsed_ticks;
    const TickType_t timeout_ticks = pdMS_TO_TICKS(1000); // 1 s header timeout

    if(max_len == 0)
        return -1;

    start_tick = xTaskGetTickCount();

    while(total < max_len - 1) {
        n = read(sd, request + total, 1);
        if(n <= 0) {
            if(errno == EAGAIN || errno == EWOULDBLOCK) {
                elapsed_ticks = xTaskGetTickCount() - start_tick;
                if(elapsed_ticks >= timeout_ticks) {
                    return -1; // header read timeout
                }
                vTaskDelay(pdMS_TO_TICKS(1));
                continue;
            }
            return -1; // error or connection closed
        }
        total++;
        if(total < max_len) {
            request[total] = '\0';
        }

        // Check for CRLFCRLF (4 bytes)
        if(total >= 4 && request[total - 4] == '\r' && request[total - 3] == '\n' && request[total - 2] == '\r' && request[total - 1] == '\n') {
            return (int)total;
        }

        // Check for LFLF (2 bytes)
        if(total >= 2 && request[total - 2] == '\n' && request[total - 1] == '\n') {
            return (int)total;
        }
    }

    return (int)total;
}

/**
 * @brief Extract URL from HTTP request line.
 * @param request HTTP request buffer starting with "GET " or "POST "
 * @param url Buffer to store extracted URL
 * @param url_size Size of URL buffer
 * @return XIB_OK on success, XIB_ERROR on invalid URL
 */
static XiBIF_error_t XiBIF_webExtractUrl(const char* request, char* url, size_t url_size)
{
    const char* path_start;
    const char* path_end;
    int path_len;

    if(strncmp(request, "GET ", 4) == 0) {
        path_start = request + 4;
    }
    else if(strncmp(request, "POST ", 5) == 0) {
        path_start = request + 5;
    }
    else {
        return XIB_ERROR;
    }

    path_end = strchr(path_start, ' ');
    if(path_end == NULL)
        return XIB_ERROR;

    path_len = path_end - path_start;
    if(path_len <= 0 || path_len >= (int)url_size)
        return XIB_ERROR;

    strncpy(url, path_start, path_len);
    url[path_len] = '\0';

    return XIB_OK;
}

/**
 * @brief Parse Content-Length header value from HTTP request.
 * @return XIB_OK on success, XIB_ERROR on failure
 */
static XiBIF_error_t XiBIF_webParseContentLength(const char* req, u32* len)
{
    const char* p = req;

    /* Search for Content-Length header at start of a line */
    while(*p) {
        /* Check if this line starts with Content-Length: (case-insensitive) */
        if(strncasecmp(p, "Content-Length:", 15) == 0) {
            p += 15;
            while(*p == ' ' || *p == '\t')
                p++;
            *len = (u32)strtoul(p, NULL, 10);
            return XIB_OK;
        }

        /* Move to next line */
        p = strchr(p, '\n');
        if(!p)
            break;
        p++; /* Skip the \n */
    }

    return XIB_ERROR;
}

/**
 * @brief Parse a JSON u32 value from request body.
 * Handles both decimal and hexadecimal (0x...) formats.
 * @return XIB_OK on success, XIB_ERROR on failure
 */
static XiBIF_error_t XiBIF_webParseJsonU32(const char* body, const char* key, u32* out)
{
    char pattern[32];
    const char* p;
    int base;

    snprintf(pattern, sizeof(pattern), "\"%s\"", key);
    p = strstr(body, pattern);
    if(!p)
        return XIB_ERROR;
    p = strchr(p, ':');
    if(!p)
        return XIB_ERROR;
    p++;
    while(*p == ' ' || *p == '\t' || *p == '\r' || *p == '\n')
        p++;
    if(*p == '\"') {
        p++;
    }
    base = 10;
    if(p[0] == '0' && (p[1] == 'x' || p[1] == 'X'))
        base = 16;
    *out = (u32)strtoul(p, NULL, base);
    return XIB_OK;
}

/**
 * @brief Create a mask from a bit width.
 * Returns 0xFFFFFFFF for width >= 32.
 */
static u32 XiBIF_webMaskFromWidth(u32 width)
{
    if(width >= 32)
        return 0xFFFFFFFFu;
    return (1u << width) - 1u;
}

/**
 * @brief Validate register parameters (width and lsb).
 * @return XIB_OK if valid, XIB_ERROR if invalid
 */
static XiBIF_error_t XiBIF_webValidateRegisterParams(u32 lsb, u32 width)
{
    if(width == 0 || width > 32 || lsb >= 32 || (lsb + width) > 32)
        return XIB_ERROR;
    return XIB_OK;
}

/**
 * @brief Send HTTP response header.
 * @param sd Socket descriptor
 * @param status HTTP status line (e.g., "200 OK", "400 Bad Request")
 * @param content_type Content-Type header value
 * @param keep_alive Whether to keep connection alive
 * @param content_length Length of the response body
 * @return XIB_OK on success, XIB_ERROR on error
 */
static XiBIF_error_t XiBIF_webSendResponseHeader(int sd, const char* status, const char* content_type, XiBIF_webKeepAlive_t keep_alive, unsigned int content_length)
{
    char response_header[512];

    snprintf(response_header, sizeof(response_header),
             "HTTP/1.1 %s\r\n"
             "Content-Type: %s\r\n"
             "Content-Length: %u\r\n"
             "Connection: %s\r\n"
             "Access-Control-Allow-Origin: *\r\n"
             "Access-Control-Allow-Methods: GET, POST, OPTIONS\r\n"
             "Access-Control-Allow-Headers: Content-Type, Content-Length, Authorization\r\n"
             "Access-Control-Allow-Private-Network: true\r\n"
             "Access-Control-Max-Age: 3600\r\n" // Cache preflight for 1 hour
             "Private-Network-Access-Name: \"XiBIF Board\"\r\n"
             "Private-Network-Access-ID: \"%02X:%02X:%02X:%02X:%02X:%02X\"\r\n"
             "%s"
             "\r\n",
             status, content_type, content_length, keep_alive ? "keep-alive" : "close", XIBIF_MAC_00, XIBIF_MAC_01, XIBIF_MAC_02, XIBIF_MAC_03, XIBIF_MAC_04, XIBIF_MAC_05, keep_alive ? "Keep-Alive: timeout=5, max=20\r\n" : "");

    if(write(sd, response_header, strlen(response_header)) <= 0) {
        DBG_PRINT("Failed to send HTTP header\r\n");
        return XIB_ERROR;
    }

    return XIB_OK;
}

/**
 * @brief Send HTTP error response without closing connection.
 * @param sd Socket descriptor
 * @param error_type Error type from XiBIF_webError_t enum
 * @param keep_alive Whether to keep connection alive
 */
static void XiBIF_webSendError(int sd, XiBIF_webError_t error_type, XiBIF_webKeepAlive_t keep_alive)
{
    const XiBIF_webErrorInfo_t* error_info;

    error_info = &XiBIF_webErrorTable[error_type];

    if(XiBIF_webSendResponseHeader(sd, error_info->status, "text/plain", keep_alive, (unsigned int)strlen(error_info->message)) == XIB_OK) {
        write(sd, error_info->message, strlen(error_info->message));
    }

    DBG_PRINT("Sent error %s on socket %d\r\n", error_info->status, sd);
}

/**
 * @brief Send JSON response with status header.
 * @return XIB_OK on success, XIB_ERROR on error
 */
static XiBIF_error_t XiBIF_webSendJsonResponse(int sd, const char* json_body, XiBIF_webKeepAlive_t keep_alive)
{
    int body_len;

    body_len = strlen(json_body);

    if(XiBIF_webSendResponseHeader(sd, "200 OK", "application/json", keep_alive, (unsigned int)body_len) != XIB_OK) {
        return XIB_ERROR;
    }

    if(XiBIF_webSendData(sd, (const unsigned char*)json_body, (unsigned int)body_len) != XIB_OK) {
        DBG_PRINT("Failed to send JSON response\r\n");
        return XIB_ERROR;
    }

    return XIB_OK;
}

/**
 * @brief Check whether client requested connection close.
 * @return XIBIF_WEB_CLOSE_CONNECTION if client wants to close, XIBIF_WEB_KEEP_ALIVE otherwise
 */
static XiBIF_webKeepAlive_t XiBIF_webClientWantsClose(const char* request)
{
    const char* p;

    p = strstr(request, "Connection:");
    if(!p)
        return XIBIF_WEB_KEEP_ALIVE;

    p += strlen("Connection:");
    while(*p == ' ' || *p == '\t')
        p++;

    /* Case-insensitive check for "close" */
    if(strncasecmp(p, "close", 5) == 0) {
        return XIBIF_WEB_CLOSE_CONNECTION;
    }

    return XIBIF_WEB_KEEP_ALIVE;
}

/**
 * @brief Validate bearer token from Authorization header.
 * @param request HTTP request buffer containing headers
 * @return XIB_OK if token is valid, XIB_ERROR if invalid or missing
 */
static XiBIF_error_t XiBIF_webValidateBearerToken(const char* request)
{
    const char* auth_header;
    const char* token_start;
    u32 token_value;

    auth_header = strstr(request, "Authorization:");
    if(!auth_header) {
        auth_header = strstr(request, "authorization:");
        if(!auth_header) {
            DBG_PRINT("Missing Authorization header\r\n");
            return XIB_ERROR;
        }
    }

    auth_header += strlen("Authorization:");
    while(*auth_header == ' ' || *auth_header == '\t')
        auth_header++;

    if(strncasecmp(auth_header, "Bearer ", 7) != 0) {
        DBG_PRINT("Authorization header missing Bearer prefix\r\n");
        return XIB_ERROR;
    }

    token_start = auth_header + 7;
    while(*token_start == ' ' || *token_start == '\t')
        token_start++;

    token_value = (u32)strtoul(token_start, NULL, 10);

    if(token_value != XIBIF_REG_UUID_UUID_RESET) {
        DBG_PRINT("Invalid bearer token: %lu (expected %lu)\r\n", (unsigned long)token_value, (unsigned long)XIBIF_REG_UUID_UUID_RESET);
        return XIB_ERROR;
    }

    return XIB_OK;
}

/**
 * @brief XiBIF web own command handler.
 *
 * This function is called when an invalid webserver endpoint is accessed. It simply
 * sends a 404 Not Found error.
 *
 * @param type The HTTP method type (GET or POST).
 * @param url The requested URL.
 * @param size_url The size of the URL buffer.
 * @param body The request body (for POST requests).
 * @param size_body The size of the body buffer.
 * @param keep_alive Whether to keep the connection alive.
 * @param sd The socket descriptor from which the command was received.
 */
__attribute__((weak)) XiBIF_error_t XiBIF_webOwnCommandHandler(XiBIF_webMethod_t type, const char* url, u32 size_url, const char* body, u32 size_body, XiBIF_webKeepAlive_t keep_alive, int sd)
{
    (void)type;      // Remove unused warning
    (void)url;       // Remove unused warning
    (void)size_url;  // Remove unused warning
    (void)body;      // Remove unused warning
    (void)size_body; // Remove unused warning

    XiBIF_webSendError(sd, XIBIF_WEB_ERR_NOT_FOUND, keep_alive);
    return XIB_OK;
}

/**
 * @brief Web server connection handler.
 *
 * Persistent HTTP/1.1 on raw sockets: supports GET /register/map and POST
 * /register/read or /register/write with JSON body. Stays alive until the
 * client requests close or a timeout/error occurs. Other endpoints are
 * rejected.
 *
 * @param p The socket descriptor (cast from (UINTPTR)) from which to read data.
 */
void XiBIF_webHandler(void* p)
{
    int sd = (int)(UINTPTR)p;
    char request[2048];
    char url[256];
    int bytes_read;
    char body[1024];
    XiBIF_webKeepAlive_t keep_alive;
    u32 content_length;
    u32 address;
    u32 lsb;
    u32 width;
    u32 value;
    u32 reg;
    u32 mask;
    char resp_body[160];

    DBG_PRINT("Web connection opened on socket %d\r\n", sd);

    while(1) {
        // Read HTTP request header
        memset(request, 0, sizeof(request));
        memset(body, 0, sizeof(body));
        bytes_read = XiBIF_webReadHeader(sd, request, sizeof(request));

        if(bytes_read == 0) {
            // Clean close by client
            break;
        }

        if(bytes_read < 0) {
            // Check if it's a timeout (EAGAIN/EWOULDBLOCK) or real error
            if(errno != 0 && errno != EAGAIN && errno != EWOULDBLOCK) {
                DBG_PRINT("Socket error on socket %d (errno=%d)\r\n", sd, errno);
                break;
            }
            continue; // Timeout: continue waiting for next request (normal for keep-alive)
        }

        // Check if the connection should be kept alive
        keep_alive = XiBIF_webClientWantsClose(request);

        // Validate bearer token (skip for OPTIONS preflight)
        if(strncmp(request, "OPTIONS ", 8) != 0) {
            if(XiBIF_webValidateBearerToken(request) != XIB_OK) {
                XiBIF_webSendError(sd, XIBIF_WEB_ERR_UNAUTHORIZED, keep_alive);
                if(keep_alive == XIBIF_WEB_CLOSE_CONNECTION)
                    break;
                continue; // Keep connection alive, wait for next request
            }
        }

        // Get request
        if(strncmp(request, "GET ", 4) == 0) {
            if(XiBIF_webExtractUrl(request, url, sizeof(url)) != XIB_OK) {
                XiBIF_webSendError(sd, XIBIF_WEB_ERR_BAD_REQUEST, keep_alive);
                continue; // Keep connection alive
            }

            if(strcmp(url, "/register/map") == 0) {
                if(XiBIF_webSendJsonResponse(sd, XIBIF_REG_RMAP_JSON, keep_alive) != XIB_OK)
                    break; // Only break on real socket error
            }
            else {
                if(XiBIF_webOwnCommandHandler(XIBIF_WEB_METHOD_GET, url, sizeof(url) / sizeof(url[0]), NULL, 0, keep_alive, sd) != XIB_OK) // cppcheck-suppress knownConditionTrueFalse
                    break;
            }
        }
        else if(strncmp(request, "POST ", 5) == 0) {
            if(XiBIF_webExtractUrl(request, url, sizeof(url)) != XIB_OK) {
                XiBIF_webSendError(sd, XIBIF_WEB_ERR_BAD_REQUEST, keep_alive);
                continue; // Keep connection alive
            }

            content_length = 0;
            if(XiBIF_webParseContentLength(request, &content_length) != XIB_OK || content_length >= sizeof(body)) {
                DBG_PRINT("Content-Length parse failed or too large (len=%lu)\r\n", (unsigned long)content_length);
                XiBIF_webSendError(sd, XIBIF_WEB_ERR_LENGTH_REQUIRED, keep_alive);
                continue; // Keep connection alive
            }

            if(XiBIF_webReadBody(sd, body, sizeof(body), content_length) != XIB_OK) {
                DBG_PRINT("Body read error/close on socket %d (len=%lu, errno=%d)\r\n", sd, (unsigned long)content_length, errno);
                keep_alive = XIBIF_WEB_CLOSE_CONNECTION; // cppcheck-suppress unreadVariable // treat as close
                break;                                   // exit request loop
            }

            if(strcmp(url, "/register/read") == 0) {
                address = 0;
                lsb = 0;
                width = 0;
                if(XiBIF_webParseJsonU32(body, "address", &address) != XIB_OK || XiBIF_webParseJsonU32(body, "lsb", &lsb) != XIB_OK || XiBIF_webParseJsonU32(body, "width", &width) != XIB_OK) {
                    XiBIF_webSendError(sd, XIBIF_WEB_ERR_INVALID_JSON, keep_alive);
                    continue; // Keep connection alive
                }

                if(XiBIF_webValidateRegisterParams(lsb, width) != XIB_OK) {
                    XiBIF_webSendError(sd, XIBIF_WEB_ERR_INVALID_PARAMS, keep_alive);
                    continue; // Keep connection alive
                }

                reg = XiBIF_getReg(XiBIF_getPeri(), address);
                mask = XiBIF_webMaskFromWidth(width);
                value = (reg >> lsb) & mask;

                snprintf(resp_body, sizeof(resp_body), "{\"address\":%lu,\"lsb\":%lu,\"width\":%lu,\"value\":%lu}", (unsigned long)address, (unsigned long)lsb, (unsigned long)width, (unsigned long)value);

                if(XiBIF_webSendJsonResponse(sd, resp_body, keep_alive) != XIB_OK)
                    break;
            }
            else if(strcmp(url, "/register/write") == 0) {
                address = 0;
                lsb = 0;
                width = 0;
                value = 0;
                if(XiBIF_webParseJsonU32(body, "address", &address) != XIB_OK || XiBIF_webParseJsonU32(body, "lsb", &lsb) != XIB_OK || XiBIF_webParseJsonU32(body, "width", &width) != XIB_OK || XiBIF_webParseJsonU32(body, "value", &value) != XIB_OK) {
                    DBG_PRINT("JSON parse failed. Body: %s\r\n", body);
                    XiBIF_webSendError(sd, XIBIF_WEB_ERR_INVALID_JSON, keep_alive);
                    continue; // Keep connection alive
                }

                if(XiBIF_webValidateRegisterParams(lsb, width) != XIB_OK) {
                    XiBIF_webSendError(sd, XIBIF_WEB_ERR_INVALID_PARAMS, keep_alive);
                    continue; // Keep connection alive
                }

                reg = XiBIF_getReg(XiBIF_getPeri(), address);
                mask = XiBIF_webMaskFromWidth(width);
                reg &= ~(mask << lsb);
                reg |= (value & mask) << lsb;
                XiBIF_setReg(XiBIF_getPeri(), address, reg);

                snprintf(resp_body, sizeof(resp_body), "{\"address\":%lu,\"lsb\":%lu,\"width\":%lu,\"value\":%lu}", (unsigned long)address, (unsigned long)lsb, (unsigned long)width, (unsigned long)(value & mask));

                if(XiBIF_webSendJsonResponse(sd, resp_body, keep_alive) != XIB_OK)
                    break;
            }
            else {
                if(XiBIF_webOwnCommandHandler(XIBIF_WEB_METHOD_POST, url, sizeof(url) / sizeof(url[0]), body, sizeof(body) / sizeof(body[0]), keep_alive, sd) != XIB_OK) // cppcheck-suppress knownConditionTrueFalse
                    break;
            }
        }
        else if(strncmp(request, "OPTIONS ", 8) == 0) {
            // Handle CORS preflight request
            if(XiBIF_webSendResponseHeader(sd, "204 No Content", "text/plain", keep_alive, 0) != XIB_OK)
                break;
        }
        else {
            XiBIF_webSendError(sd, XIBIF_WEB_ERR_NOT_FOUND, keep_alive);
            // Continue keeping connection alive
        }

        if(keep_alive == XIBIF_WEB_CLOSE_CONNECTION)
            break;
    }

    close(sd);
    DBG_PRINT("Web connection closed on socket %d\r\n", sd);

    // Explicitly delete this task to ensure cleanup
    vTaskDelete(NULL);
}
