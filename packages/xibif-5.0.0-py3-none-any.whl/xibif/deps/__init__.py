"""Dependency management for XiBIF."""
from .catalog import DependencyCatalog
from .models import DependencyContext, DependencyPath, DependencyPathList, DependencyGroup
