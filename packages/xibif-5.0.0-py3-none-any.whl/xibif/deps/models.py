"""Defines data models for dependency rules and resolved paths in the XiBIF dependency management system."""

from enum import Enum, auto
from shutil import copy
from pydantic.dataclasses import dataclass
from pydantic import ConfigDict, validate_call, computed_field
from ..types import XibifPath, XilinxVersion, XilinxBoard
from ..logger import xibif_print_warning, LoggerStage as LS


class DependencyCopyMode(Enum):
    """Defines how to handle existing target files when copying dependencies."""

    OVERWRITE = auto()
    SKIP_EXISTING = auto()


class DependencyGroup(Enum):
    """Logical groups for dependencies, used for selection in the catalog."""

    FPGA_SRC = auto()
    FPGA_TB = auto()
    FPGA_VUNIT_COMPILE = auto()
    FPGA_VUNIT_RUN = auto()
    FPGA_CONSTRAINT = auto()
    PS_SRC = auto()
    PS_HEADER = auto()
    PS_MSS = auto()
    PS_LINKER = auto()
    PS_SHELL = auto()
    PS_SETTINGS_TEMPLATE = auto()
    PYTHON_DEMO = auto()
    SIGASI_PROJECT = auto()
    SIGASI_SETTINGS = auto()
    GIT_FILES = auto()
    CORSAIR_USER_REGS = auto()
    CORSAIR_USER_CONFIG = auto()
    CORSAIR_STREAM_REGS = auto()
    CORSAIR_STREAM_CONFIG = auto()
    CORSAIR_CUSTOM_CONFIG = auto()


@dataclass(frozen=True)
class DependencyContext:
    """Context for dependency resolution, used for conditional rules in the catalog."""

    board: XilinxBoard | None = None
    xilinx_version: XilinxVersion | None = None
    project_name: str = "XiBIF"


@dataclass(frozen=True)
class DependencyRule:
    """Defines a rule for resolving dependencies in the catalog, including selection criteria and copy behavior.

    Args:
        group (DependencyGroup): Logical group for this dependency, used for selection in the catalog.
        source (str): Package resource path to the dependency file or directory.
        boards (frozenset[XiBIFBoard]): Optional set of board identifiers for which this dependency is relevant. If None, applies to all boards.
        versions (frozenset[XiBIFXilinxVersion]): Optional set of Xilinx versions for which this dependency is relevant. If None, applies to all versions.
        copy_mode (DependencyCopyMode): Defines how to handle existing target files when copying this dependency.
        apply_replacements (bool): Whether to apply token replacements in this dependency after copying.
    """

    group: DependencyGroup
    source: str
    boards: frozenset[XilinxBoard] | None = None
    versions: frozenset[XilinxVersion] | None = None
    copy_mode: DependencyCopyMode = DependencyCopyMode.OVERWRITE
    apply_replacements: bool = False

    @validate_call(config=ConfigDict(strict=True))
    def matches(self, ctx: DependencyContext) -> bool:
        """Checks if this dependency rule matches the given context based on board and Xilinx version criteria.

        Args:
            ctx (DependencyContext): The context to check against this rule's criteria.

        Returns:
            bool: True if the rule matches the context, False otherwise.
        """
        if self.boards is not None and ctx.board not in self.boards:
            return False

        if self.versions is not None and ctx.xilinx_version not in self.versions:
            return False

        return True


@dataclass(frozen=True)
class DependencyPath:
    """Resolved dependency with a package resource path.

    Args:
        source (XibifPath): The resolved file system path to the dependency, obtained from the package resource.
        copy_mode (DependencyCopyMode): Defines how to handle existing target files when copying this dependency.
        replacement (dict[str, str] | None): Optional dictionary of token replacements to apply to the dependency file after copying, where keys are tokens to replace and values are their replacements.
    """

    source: XibifPath
    copy_mode: DependencyCopyMode = DependencyCopyMode.OVERWRITE
    replacement: dict[str, str] | None = None

    @validate_call(config=ConfigDict(strict=True))
    def copy(self, destination: XibifPath, link: bool = False) -> None:
        """Copy the dependency from source to destination, applying the specified copy mode and replacements.

        Args:
            destination (Path): The target directory where the dependency should be copied.
            link (bool): If True, create a symbolic link instead of copying the file. Defaults to False.
        """
        destination_full_path = destination.joinpath(self.source.name)
        destination.mkdir(parents=True, exist_ok=True)

        if self.copy_mode == DependencyCopyMode.SKIP_EXISTING and destination_full_path.exists():
            return

        if link:
            try:
                destination_full_path.symlink_to(self.source)
            except OSError:
                # If symlink creation fails (e.g., on Windows without admin rights), fall back to copying
                xibif_print_warning(f"Symlink creation failed for {self.source} -> {destination_full_path}. Falling back to copying.", stage=LS.NO_CHANGE)
                copy(self.source, destination)
        else:
            copy(self.source, destination)

        self._apply_replacements(file_path=destination_full_path)

    @validate_call(config=ConfigDict(strict=True))
    def _apply_replacements(self, file_path: XibifPath) -> None:
        """Apply token replacements to the copied dependency file, if any.

        Args:
            file_path (Path): The path to the copied dependency file where replacements should be applied.
        """
        if self.replacement is None:
            return

        if not file_path.exists():
            return

        content = file_path.read_text(encoding="utf-8")
        for key, value in self.replacement.items():
            content = content.replace(key, value)
        file_path.write_text(content, encoding="utf-8")

    @computed_field
    @property
    def as_path(self) -> XibifPath:
        """Provide access to the underlying Path object for this dependency.

        Returns:
            XibifPath: The Path object corresponding to the resolved dependency.
        """
        return self.source


@dataclass(frozen=True)
class DependencyPathList(list[DependencyPath]):
    """List of resolved dependency paths, with utility methods for access and copying.

    Args:
         dependencies (list[DependencyPath]): A list of resolved DependencyPath objects.
    """

    dependencies: list[DependencyPath]

    @validate_call(config=ConfigDict(strict=True))
    def copy(self, destination: XibifPath, link: bool = False) -> None:
        """Copy all dependencies in the list to their respective destinations.

        Args:
            destination (Path): The target directory where the dependencies should be copied.
            link (bool): If True, create symbolic links instead of copying the files. Defaults to False.
        """
        for dep in self.dependencies:
            dep.copy(destination=destination, link=link)

    @computed_field
    @property
    def as_path(self) -> list[XibifPath]:
        """Provide access to the underlying Path objects for all dependencies in the list.

        Returns:
            list[Path]: A list of Path objects corresponding to the resolved dependencies.
        """
        if len(self.dependencies) == 1:
            return self.dependencies[0].as_path
        else:
            return [dep.as_path for dep in self.dependencies]
