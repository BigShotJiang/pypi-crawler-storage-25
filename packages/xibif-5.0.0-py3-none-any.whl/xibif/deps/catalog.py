"""Dependency catalog and resolution logic for XiBIF."""

from importlib.resources import files
from collections.abc import Iterable
from pydantic import ConfigDict, validate_call
from .models import (
    DependencyContext,
    DependencyRule,
    DependencyPath,
    DependencyCopyMode,
    DependencyGroup,
    DependencyPathList,
)
from ..types import XibifPath, XilinxVersion, XilinxBoard


class DependencyCatalog:
    """Catalog of dependency rules, providing resolution based on context and group selection."""

    __rules: list[DependencyRule]

    @validate_call(config=ConfigDict(strict=True))
    def __init__(
        self,
        rules: list[DependencyRule] | None = None,
    ) -> None:
        """Initializes the dependency catalog with a list of rules. If no rules are provided, generates a default set of rules.

        Args:
            rules (list[DependencyRule] | None): Optional list of dependency rules to initialize the catalog with. If None, default rules will be generated.
        """
        if rules is None:
            rules = _generate_default_rules()
        self.__rules = rules

    @validate_call(config=ConfigDict(strict=True))
    def resolve(
        self,
        group: DependencyGroup,
        ctx: DependencyContext = DependencyContext(),
        replacements: dict[str, str] | None = None,
    ) -> DependencyPathList:
        """Resolves dependencies for the given group and context, returning a list of DependencyPath objects with source and target information.

        Args:
            group (DependencyGroup): The dependency group to resolve.
            ctx (DependencyContext): The context to use for resolving conditional rules.
            replacements (dict[str, str] | None): Optional dictionary of token replacements to apply to the resolved dependencies. If None, default replacements based on the context will be generated for rules that have apply_replacements=True.

        Returns:
            DependencyPathList: A list of resolved dependencies with source paths, target destinations, copy modes, and optional replacements.
        """

        # Generate resolved dependencies for the given group and context
        resolved: list[DependencyPath] = []
        for rule in self.__rules:
            if rule.group != group:
                continue
            if not rule.matches(ctx):
                continue

            # Generate replacement dictionary if needed
            replacement_dict = None
            if rule.apply_replacements:
                if replacements is None:
                    replacement_dict = _generate_default_replacements(ctx)
                else:
                    replacement_dict = replacements

            resolved.append(
                DependencyPath(
                    source=XibifPath(files("xibif").joinpath("deps/data").joinpath(rule.source)),
                    copy_mode=rule.copy_mode,
                    replacement=replacement_dict,
                )
            )

        return DependencyPathList(dependencies=resolved)


@validate_call(config=ConfigDict(strict=True))
def _generate_default_replacements(
    ctx: DependencyContext,
) -> dict[str, str]:
    """Generates a default replacement dictionary based on the given context.

    Args:
        ctx (DependencyContext): The context to generate replacements for.

    Returns:
        dict[str, str]: A dictionary of token replacements based on the context.
    """
    replacement_dict = {}
    if ctx.project_name is not None:
        replacement_dict["{PROJECT_NAME}"] = ctx.project_name
    if ctx.xilinx_version is not None:
        replacement_dict["{VIVADO_VERSION}"] = ctx.xilinx_version.value
    return replacement_dict


@validate_call(config=ConfigDict(strict=True))
def _generate_rule(
    group: DependencyGroup,
    sources: Iterable[str],
    boards: frozenset[XilinxBoard] | None = None,
    versions: frozenset[XilinxVersion] | None = None,
    copy_mode: DependencyCopyMode = DependencyCopyMode.OVERWRITE,
    apply_replacements: bool = False,
) -> list[DependencyRule]:
    """Helper function to generate dependency rules for multiple sources with the same settings.

    Args:
        group (DependencyGroup): Dependency group.
        sources (Iterable[str]): Iterable of source paths relative to the package data directory.
        boards (frozenset[XiBIFBoard]): Optional set of board identifiers for which this rule applies. If None, applies to all boards.
        versions (frozenset[XiBIFXilinxVersion]): Optional set of Xilinx versions for which this rule applies. If None, applies to all versions.
        copy_mode (DependencyCopyMode): Copy mode for this rule. Defaults to OVERWRITE.
        apply_replacements (bool): Whether to apply token replacements for this rule.

    Returns:
        list[DependencyRule]: List of DependencyRule objects for the given sources and settings.
    """
    rules: list[DependencyRule] = []
    for source in sources:
        if source:
            rule = DependencyRule(
                group=group,
                source=source,
                boards=boards,
                versions=versions,
                apply_replacements=apply_replacements,
                copy_mode=copy_mode,
            )
            rules.append(rule)
    return rules


@validate_call(config=ConfigDict(strict=True))
def _generate_default_rules() -> list[DependencyRule]:
    """Generates the default dependency rules for all groups.

    Returns:
        list[DependencyRule]: List of dependency rules.
    """

    rules: list[DependencyRule] = []

    ###################################################################################################################
    # FPGA sources and testbenches
    ###################################################################################################################
    rules.extend(
        _generate_rule(
            group=DependencyGroup.FPGA_SRC,
            sources=[
                "vivado/hdl/src/XiBIF_write.vhd",
                "vivado/hdl/src/XiBIF_read.vhd",
                "vivado/hdl/src/XiBIF_axi_master_simple.vhd",
                "vivado/hdl/src/XiBIF_Peri.vhd",
            ],
        )
    )

    rules.extend(
        _generate_rule(
            group=DependencyGroup.FPGA_TB,
            sources=[
                "vivado/hdl/tb/vunit/tb_axi_master_simple.vhd",
                "vivado/hdl/tb/vunit/tb_read.vhd",
                "vivado/hdl/tb/vunit/tb_write.vhd",
                "vivado/hdl/tb/vunit/tb_peri.vhd",
                "vivado/hdl/tb/vunit/tb_usr_access2_dummy.vhd",
            ],
        )
    )

    ####################################################################################################################
    # VUNIT scripts
    ####################################################################################################################
    rules.extend(
        _generate_rule(
            group=DependencyGroup.FPGA_VUNIT_COMPILE,
            sources=["vivado/hdl/tb/vunit/run_compile.py"],
        )
    )

    rules.extend(
        _generate_rule(
            group=DependencyGroup.FPGA_VUNIT_RUN,
            sources=["vivado/hdl/tb/vunit/run.py"],
        )
    )

    ####################################################################################################################
    # Constraints
    ####################################################################################################################
    rules.extend(
        _generate_rule(
            group=DependencyGroup.FPGA_CONSTRAINT,
            sources=["vivado/constraints/zedboard.xdc"],
            boards=frozenset({XilinxBoard.ZEDBOARD}),
        )
    )

    rules.extend(
        _generate_rule(
            group=DependencyGroup.FPGA_CONSTRAINT,
            sources=["vivado/constraints/zyboz10.xdc"],
            boards=frozenset({XilinxBoard.ZYBOZ710}),
        )
    )

    rules.extend(
        _generate_rule(
            group=DependencyGroup.FPGA_CONSTRAINT,
            sources=["vivado/constraints/zyboz20.xdc"],
            boards=frozenset({XilinxBoard.ZYBOZ720}),
        )
    )

    rules.extend(
        _generate_rule(
            group=DependencyGroup.FPGA_CONSTRAINT,
            sources=["vivado/constraints/zcu102.xdc"],
            boards=frozenset({XilinxBoard.ZCU102}),
        )
    )

    rules.extend(
        _generate_rule(
            group=DependencyGroup.FPGA_CONSTRAINT,
            sources=["vivado/constraints/zcu104.xdc"],
            boards=frozenset({XilinxBoard.ZCU104}),
        )
    )

    rules.extend(
        _generate_rule(
            group=DependencyGroup.FPGA_CONSTRAINT,
            sources=["vivado/constraints/kv260.xdc"],
            boards=frozenset({XilinxBoard.KV260}),
        )
    )

    ####################################################################################################################
    # PS files
    ####################################################################################################################
    rules.extend(
        _generate_rule(
            group=DependencyGroup.PS_SRC,
            sources=[
                "vitis/src/main.c",
                "vitis/src/XiBIF.c",
                "vitis/src/XiBIF_PhySpeed.c",
                "vitis/src/XiBIF_Webserver.c",
            ],
        )
    )
    rules.extend(
        _generate_rule(
            group=DependencyGroup.PS_HEADER,
            sources=[
                "vitis/src/main.h",
                "vitis/src/XiBIF.h",
                "vitis/src/XiBIF_settings.h",
                "vitis/src/XiBIF_PhySpeed.h",
                "vitis/src/XiBIF_Webserver.h",
            ],
        )
    )

    #####################################################################################################################
    # MSS scripts
    #####################################################################################################################
    rules.extend(
        _generate_rule(
            group=DependencyGroup.PS_MSS,
            sources=["vitis/src/board/7series/2023-1-system.mss"],
            boards=frozenset({XilinxBoard.ZEDBOARD, XilinxBoard.ZYBOZ710, XilinxBoard.ZYBOZ720}),
            versions=frozenset({XilinxVersion.V2023_1}),
        )
    )

    rules.extend(
        _generate_rule(
            group=DependencyGroup.PS_MSS,
            sources=["vitis/src/board/7series/2023-2-system.mss"],
            boards=frozenset({XilinxBoard.ZEDBOARD, XilinxBoard.ZYBOZ710, XilinxBoard.ZYBOZ720}),
            versions=frozenset({XilinxVersion.V2023_2}),
        )
    )

    rules.extend(
        _generate_rule(
            group=DependencyGroup.PS_MSS,
            sources=["vitis/src/board/ultrascalep/2023-1-system.mss"],
            boards=frozenset({XilinxBoard.ZCU102, XilinxBoard.ZCU104}),
            versions=frozenset({XilinxVersion.V2023_1}),
        )
    )

    rules.extend(
        _generate_rule(
            group=DependencyGroup.PS_MSS,
            sources=["vitis/src/board/ultrascalep/2023-2-system.mss"],
            boards=frozenset({XilinxBoard.ZCU102, XilinxBoard.ZCU104}),
            versions=frozenset({XilinxVersion.V2023_2}),
        )
    )

    rules.extend(
        _generate_rule(
            group=DependencyGroup.PS_MSS,
            sources=["vitis/src/board/ultrascalep/2023-1-system-kv260.mss"],
            boards=frozenset({XilinxBoard.KV260}),
            versions=frozenset({XilinxVersion.V2023_1}),
        )
    )

    rules.extend(
        _generate_rule(
            group=DependencyGroup.PS_MSS,
            sources=["vitis/src/board/ultrascalep/2023-2-system-kv260.mss"],
            boards=frozenset({XilinxBoard.KV260}),
            versions=frozenset({XilinxVersion.V2023_2}),
        )
    )

    ######################################################################################################################
    # Linker scripts
    ######################################################################################################################
    rules.extend(
        _generate_rule(
            group=DependencyGroup.PS_LINKER,
            sources=["vitis/src/board/ultrascalep/lscript.ld"],
            boards=frozenset({XilinxBoard.ZCU102, XilinxBoard.ZCU104, XilinxBoard.KV260}),
        )
    )
    rules.extend(
        _generate_rule(
            group=DependencyGroup.PS_LINKER,
            sources=["vitis/src/board/7series/lscript.ld"],
            boards=frozenset({XilinxBoard.ZEDBOARD, XilinxBoard.ZYBOZ710, XilinxBoard.ZYBOZ720}),
        )
    )

    #######################################################################################################################
    # PS settings template
    #######################################################################################################################
    rules.extend(
        _generate_rule(
            group=DependencyGroup.PS_SETTINGS_TEMPLATE,
            sources=["vitis/XiBIF_settings.j2"],
        )
    )

    #######################################################################################################################
    # Python demo script
    #######################################################################################################################
    rules.extend(
        _generate_rule(
            group=DependencyGroup.PYTHON_DEMO,
            sources=["python/xibif_demo.py"],
        )
    )

    #######################################################################################################################
    # Sigasi project and settings
    #######################################################################################################################
    rules.extend(
        _generate_rule(
            group=DependencyGroup.SIGASI_PROJECT,
            sources=[
                "sigasi/project.sigasi",
            ],
            apply_replacements=True,
        )
    )

    rules.extend(
        _generate_rule(
            group=DependencyGroup.SIGASI_SETTINGS,
            sources=[
                "sigasi/.settings/settings.json",
            ],
        )
    )

    #######################################################################################################################
    # Git files
    #######################################################################################################################
    rules.extend(
        _generate_rule(
            group=DependencyGroup.GIT_FILES,
            sources=[
                "git/.gitignore",
                "git/.gitlab-ci.yml",
            ],
            apply_replacements=True,
            copy_mode=DependencyCopyMode.SKIP_EXISTING,
        )
    )

    #######################################################################################################################
    # Corsair files
    #######################################################################################################################
    rules.extend(
        _generate_rule(
            group=DependencyGroup.CORSAIR_USER_REGS,
            sources=["corsair/xibif-regs.json"],
        )
    )
    rules.extend(
        _generate_rule(
            group=DependencyGroup.CORSAIR_USER_CONFIG,
            sources=["corsair/config-regs"],
        )
    )
    rules.extend(
        _generate_rule(
            group=DependencyGroup.CORSAIR_STREAM_REGS,
            sources=["corsair/xibif-stream.json"],
        )
    )
    rules.extend(
        _generate_rule(
            group=DependencyGroup.CORSAIR_STREAM_CONFIG,
            sources=["corsair/config-stream"],
        )
    )
    rules.extend(
        _generate_rule(
            group=DependencyGroup.CORSAIR_CUSTOM_CONFIG,
            sources=["corsair/config-custom"],
        )
    )

    ########################################################################################################################
    # Vitis Clean Shell Script
    ########################################################################################################################
    rules.extend(
        _generate_rule(
            group=DependencyGroup.PS_SHELL,
            sources=["vitis/clean_cmd.bat"],
        )
    )

    return rules
