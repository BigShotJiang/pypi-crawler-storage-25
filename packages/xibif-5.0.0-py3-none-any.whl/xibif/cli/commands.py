"""This module contains the command functions for the XiBIF CLI. Each function corresponds to a command that can be executed from the command line interface. The functions are responsible for parsing the arguments, performing the necessary actions, and returning the updated project state if applicable."""

from importlib.metadata import metadata
import webbrowser
import sys
import argparse
import shutil
import copy
from typing import Any
from datetime import datetime
from itertools import chain
from pydantic import ValidationError, ConfigDict, validate_call
from pydantic.networks import IPvAnyAddress
from ..utils import start_tool, check_tool_running_and_ask, get_default_xilinx_path, scan_xilinx_version, igetattr
from ..logger import LoggerStage as LS, xibif_print_debug, xibif_print_info, xibif_print_warning, xibif_print_error, get_user_temp_folder
from .. import api
from .. import XibifProject
from ..api.build_stages import VivadoStage, VitisStage, get_stages_between, get_stages
from ..types import XibifPath, XilinxVersion, VunitSimulator, XibifStartTool, XilinxBoard, XibifValidationError, XibifRegisterError, XibifRuntimeError, XibifDefaults, XibifChecksum
from ..types.defaults_messages import XibifDefaultsMessages
from ..types.messages import XibifMessage
from ..deps import DependencyCatalog, DependencyGroup
from ..project.models import XibifTooling
from ..utils import get_xilinx_tool_paths, get_version

# Create dependency catalog instance
__DEPS = DependencyCatalog()


@validate_call(config=ConfigDict(strict=True, arbitrary_types_allowed=True))
def new(
    _: XibifProject,
    args: argparse.Namespace,
) -> XibifProject:
    """Creates a new XiBIF project in the current directory or in the provided path.

    Args:
        args (argparse.Namespace): The arguments passed to the command.

    Returns:
        XibifProject: The created XiBIF project.
    """

    # Parse all arguments and get default values if they are not provided
    project_name = igetattr(args, "name", XibifDefaults.APP_NAME)
    project_path = igetattr(args, "path", XibifPath.cwd().resolve().joinpath(project_name))
    force = igetattr(args, "force", False)
    nuke = igetattr(args, "nuke", False)
    board = igetattr(args, "board", XilinxBoard.ZEDBOARD)
    xilinx_path = igetattr(args, "xilinx", get_default_xilinx_path())
    xilinx_version = igetattr(args, "version", scan_xilinx_version(get_default_xilinx_path()))
    dev_mode = igetattr(args, "dev_mode", False)

    xibif_print_info("Creating new project", stage=LS.STARTUP)

    # Initialize the project
    project = XibifProject()

    # Try to set the project name
    try:
        project.name = project_name
    except ValidationError as e:
        xibif_print_error(f"Invalid project name '{e.errors()[0]['input']}'. {e.errors()[0]['msg']}.", stage=LS.STARTUP)
        sys.exit(1)

    # Try to set the project path
    try:
        if project_path is None:
            project.project_path = XibifPath.cwd().resolve().joinpath(project.name)
        else:
            project.project_path = XibifPath(project_path).resolve()
    except ValidationError as e:
        xibif_print_error(f"Invalid project path '{e.errors()[0]['input']}'. {e.errors()[0]['msg']}.", stage=LS.STARTUP)
        sys.exit(1)
    except XibifValidationError as e:
        xibif_print_error(str(e), stage=LS.STARTUP)
        sys.exit(1)

    # Set the path globally
    XibifPath.set_root(project.project_path.resolve())

    # Set the board and tooling information
    project.board = XilinxBoard(board)

    try:
        project.tooling = XibifTooling(xilinx_version=XilinxVersion(xilinx_version), xilinx_path=XibifPath(xilinx_path))
    except ValueError as e:
        xibif_print_error(f"Invalid tooling information. {e}", stage=LS.STARTUP)
        sys.exit(1)
    except XibifValidationError as e:
        xibif_print_error(str(e), stage=LS.STARTUP)

    # Check if there is already a folder at the project path
    if project.project_path.exists():
        if nuke:
            api.misc.misc_nuke_project_folder()
        elif force:
            api.misc.misc_reset_project_folder()
        else:
            xibif_print_error(f"There is already a folder at {project.project_path}. Use --force to reset the project or --nuke to delete it completely.", stage=LS.STARTUP)
            sys.exit(1)

    # Setup default project structure
    api.misc.misc_create_project_folder()

    # Setup all files
    api.setup.setup_register_files(link=dev_mode)
    api.setup.setup_hdl_files(link=dev_mode)
    api.setup.setup_vunit_python_files(link=dev_mode)
    api.setup.setup_constraint_files(board=project.board, link=dev_mode)
    api.setup.setup_sigasi_project(project_name=project.name, link=dev_mode)
    api.setup.setup_demo_files(link=dev_mode)
    api.setup.setup_git_files(link=dev_mode)
    api.setup.setup_git_repository()
    api.setup.setup_openlogic_files()

    # Generate the register files
    api.register.register_generate_stream(uuid=project.uuid)
    api.register.register_generate_user(uuid=project.uuid)
    project.register.user_register_checksum = api.register.register_get_checksum(cfg_path=XibifDefaults.REGISTER_USER_CFG)

    # Setup the Vivado and Vitis projects
    api.setup.setup_vivado_project(project_name=project.name, board=project.board, xilinx_version=project.tooling.xilinx_version, xilinx_path=project.tooling.xilinx_path)
    api.setup.setup_vitis_project(project_name=project.name, board=project.board, xilinx_version=project.tooling.xilinx_version, xilinx_path=project.tooling.xilinx_path, link=dev_mode)
    api.setup.setup_openlogic_vivado(project_name=project.name, xilinx_version=project.tooling.xilinx_version, xilinx_path=project.tooling.xilinx_path)

    # Return the project object
    return project


@validate_call(config=ConfigDict(strict=True, arbitrary_types_allowed=True))
def register(
    project: XibifProject,
    args: argparse.Namespace,
) -> XibifProject:
    """Generates the register files for the XiBIF project.

    Args:
        project (XibifProject): The XiBIF project to work with.
        args (argparse.Namespace): The arguments passed to the command.

    Returns:
        XibifProject: The updated XiBIF project with the generated register information.
    """
    # Parse all arguments and get default values if they are not provided
    enable_custom = getattr(args, "enable_custom", None)
    disable_custom = getattr(args, "disable_custom", False)
    create_stream = getattr(args, "stream", False)
    create_user = getattr(args, "user", False)
    create_custom = getattr(args, "custom", False)

    xibif_print_info("Generating registers", stage=LS.STARTUP)

    # Check if at least one register type is selected for generation
    if (not create_stream) and (not create_user) and (not create_custom) and (enable_custom is None) and (not disable_custom):
        create_stream = True
        create_user = True
        create_custom = project.register.custom_register_enabled

    # Check if custom register generation is enabled and if the provided file name is valid
    if enable_custom is not None:
        try:
            path_custom = XibifDefaults.REG_FOLDER.joinpath(enable_custom)
        except ValidationError as e:
            xibif_print_error(f"Invalid project path '{e.errors()[0]['input']}'. {e.errors()[0]['msg']}.", stage=LS.STARTUP)
            sys.exit(1)
        except XibifValidationError as e:
            xibif_print_error(str(e), stage=LS.STARTUP)
            sys.exit(1)

        # Check if the custom register generation is already enabled
        if project.register.custom_register_enabled:
            xibif_print_warning(
                f"Custom register generation is already enabled with config file '{project.register.custom_register_config_name}'. Overwriting this setting with new file.", stage=LS.STARTUP
            )

        # Check if the file exists and copy it to the register folder if it does not
        if not path_custom.is_file():
            xibif_print_debug(f"Custom register config file '{path_custom}' does not exist.", stage=LS.STARTUP)
            __DEPS.resolve(group=DependencyGroup.CORSAIR_CUSTOM_CONFIG).copy(path_custom.parent)
            shutil.move(path_custom.parent.joinpath(__DEPS.resolve(group=DependencyGroup.CORSAIR_CUSTOM_CONFIG).as_path.name), path_custom)

        # Save the custom register config name to the project configuration
        project.register.custom_register_config_name = enable_custom
        project.register.custom_register_enabled = True

        xibif_print_info(f"Custom register generation enabled with config file '{path_custom}'.", stage=LS.STARTUP)

    # Check if custom register generation should be disabled
    if disable_custom:
        if not project.register.custom_register_enabled:
            xibif_print_warning("Custom register generation is already disabled.", stage=LS.STARTUP)
        else:
            project.register.custom_register_enabled = False
            project.register.custom_register_config_name = ""
            project.register.custom_register_checksum = XibifChecksum("0")

            xibif_print_info("Custom register generation disabled.", stage=LS.STARTUP)

    # Generate the selected register types
    try:
        if create_stream:
            api.register.register_generate_stream(uuid=project.uuid)

        if create_user:
            api.register.register_generate_user(uuid=project.uuid)

            if not check_tool_running_and_ask("vivado"):
                xibif_print_error("Project is not closed in Vivado. Please close the project in Vivado and try again.", stage=LS.NO_CHANGE)
                sys.exit(1)

            api.register.register_generate_user_vivado(project_name=project.name, xilinx_version=project.tooling.xilinx_version, xilinx_path=project.tooling.xilinx_path)
            project.register.user_register_checksum = api.register.register_get_checksum(cfg_path=XibifDefaults.REGISTER_USER_CFG)

        if create_custom:
            if project.register.custom_register_enabled:
                path_custom = XibifDefaults.REG_FOLDER.joinpath(project.register.custom_register_config_name)
                api.register.register_generate_custom(cfg_path=path_custom)
                project.register.custom_register_checksum = api.register.register_get_checksum(cfg_path=path_custom)
            else:
                xibif_print_error("Custom register generation is not enabled. Please enable it with --enable-custom <file_name> to generate custom registers.", stage=LS.STARTUP)
                sys.exit(1)

    except XibifRegisterError as e:
        xibif_print_error(str(e), stage=LS.NO_CHANGE)
        sys.exit(1)

    return project


@validate_call(config=ConfigDict(strict=True, arbitrary_types_allowed=True))
def build(
    project: XibifProject,
    args: argparse.Namespace,
) -> XibifProject:
    """Builds the Vivado and Vitis projects for the XiBIF project.

    Args:
        project (XibifProject): The XiBIF project to work with.
        args (argparse.Namespace): The arguments passed to the command.

    Returns:
        XibifProject: The updated XiBIF project after the build process.
    """
    # Parse all arguments and get default values if they are not provided
    stagesAttr = getattr(args, "stage", [])
    fromAttr = getattr(args, "from", None)
    toAttr = getattr(args, "to", None)
    nowarn = getattr(args, "nowarn", False)
    noreport = getattr(args, "noreport_vivado", False)
    fixvitis = getattr(args, "fix_vitis", False)

    xibif_print_info("Building XiBIF project", stage=LS.STARTUP)

    # Check if only fixvitis is selected without any stages and warn the user that this will only try to fix the Vitis workspace and not build the project
    if fixvitis and (stagesAttr or fromAttr or toAttr):
        xibif_print_error(
            "Cannot use --fix-vitis together with stage selection arguments. Please use --fix-vitis without any stage selection arguments to only try to fix the Vitis workspace without building the project.",
            stage=LS.STARTUP,
        )
        sys.exit(1)

    # Generate the build stages based on the provided arguments
    vivadoStages = []
    vitisStages = []

    # Check if there is a from to range
    if fromAttr or toAttr:
        vivadoStages, vitisStages = get_stages_between(from_stage=fromAttr, to_stage=toAttr)

        # Check if both lists are empty
        if not vivadoStages and not vitisStages:
            xibif_print_error("No stages found in the provided 'from'-'to' range! Did you mix up 'from' and 'to'?", stage=LS.STARTUP)
            sys.exit(1)

    # Add the provided stages
    stages_unpacked = [*chain(stagesAttr)]
    vivado_unpacked, vitis_unpacked = get_stages(stages_unpacked)
    vivadoStages.extend(vivado_unpacked)
    vitisStages.extend(vitis_unpacked)

    # Check if no stages where selected
    if not vivadoStages and not vitisStages and not fixvitis:
        vivadoStages = [VivadoStage.all]
        vitisStages = [VitisStage.all]

    # Print debug information
    xibif_print_debug(f"Vivado stages to build: {[stage.name for stage in vivadoStages]}", stage=LS.STARTUP)
    xibif_print_debug(f"Vitis stages to build: {[stage.name for stage in vitisStages]}", stage=LS.STARTUP)

    # Generate results folder in case it does not exist
    results_folder = XibifDefaults.RESULTS_FOLDER
    if not results_folder.exists():
        results_folder.mkdir(parents=True, exist_ok=True)

    # Check if the register files are up to date and warn the user if they are not
    if not nowarn:
        checksum_user = api.register.register_get_checksum(cfg_path=XibifDefaults.REGISTER_USER_CFG)
        if checksum_user != project.register.user_register_checksum:
            if not XibifMessage(title="User Register Outdated", message="The user register file has changed since the last generation!").ask("Do you want to continue?"):
                xibif_print_error("Regenerate the user registers using xibif register --user before building the project.", stage=LS.STARTUP)
                sys.exit(1)

        if project.register.custom_register_enabled:
            path_custom = XibifDefaults.REG_FOLDER.joinpath(project.register.custom_register_config_name)
            checksum_custom = api.register.register_get_checksum(cfg_path=path_custom)
            if checksum_custom != project.register.custom_register_checksum:
                if not XibifMessage(title="Custom Register Outdated", message="The custom register file has changed since the last generation!").ask("Do you want to continue?"):
                    xibif_print_error("Regenerate the custom registers using xibif register --custom before building the project.", stage=LS.STARTUP)
                    sys.exit(1)

    # Build the Vivado project if there are stages selected for Vivado
    if vivadoStages:
        xibif_print_info("Building Vivado", stage=LS.STARTUP)

        # Check if the project is open in Vivado and warn the user to close it before building
        if not nowarn and not check_tool_running_and_ask("vivado"):
            xibif_print_error("Project is not closed in Vivado. Please close the project in Vivado and try again.", stage=LS.NO_CHANGE)
            sys.exit(1)

        # Finally run the build for Vivado
        api.build.build_vivado(project_name=project.name, xilinx_version=project.tooling.xilinx_version, stages=vivadoStages, disable_report=noreport, xilinx_path=project.tooling.xilinx_path)

    # Build the Vitis project if there are stages selected for Vitis
    if vitisStages:
        xibif_print_info("Building Vitis", stage=LS.STARTUP)

        # Check if the project is open in Vitis and warn the user to close it before building
        if not nowarn and not check_tool_running_and_ask("vitis"):
            xibif_print_error("Project is not closed in Vitis. Please close the project in Vitis and try again.", stage=LS.NO_CHANGE)
            sys.exit(1)

        # Check if the Vitis workspace is in a broken state and warn the user to fix it before building
        if not nowarn and (project.vitis_path_check != XibifDefaults.VITIS_FOLDER):
            if not XibifDefaultsMessages.WARNING_MESSAGE_MOVED_VITIS.ask("Do you want to continue?"):
                xibif_print_error(
                    "The Vitis workspace was moved and might be in a broken state. Continue on your own risk. It is recommended to fix the Vitis workspace before building the project.",
                    stage=LS.NO_CHANGE,
                )
                sys.exit(1)
            else:
                xibif_print_info(
                    "Continuing with build. In case errors are experienced during the build, try to fix the Vitis workspace using 'xibif build --fix-vitis' and then build again.", stage=LS.NO_CHANGE
                )
                project.vitis_path_check = XibifDefaults.VITIS_FOLDER

        # Check if this is Vitis 2024.1 and warn the user about the known bugs in this version
        if not nowarn and project.tooling.xilinx_version == XilinxVersion.V2024_1:
            if not nowarn and not XibifDefaultsMessages.WARNING_MESSAGE_BUILD_VITIS_2024_1.ask("Did you already do this?"):
                xibif_print_error(
                    "User did not confirm that the Vitis project has been corrected. Please fix the Vitis workspace before building the project to avoid build failures due to Vitis bugs in version 2024.1.",
                    stage=LS.NO_CHANGE,
                )
                sys.exit(1)

        # Finally run the build for Vitis
        api.misc.misc_update_vitis_header_file(settings=project.settings)
        api.build.build_vitis(project_name=project.name, board=project.board, xilinx_version=project.tooling.xilinx_version, stages=vitisStages, xilinx_path=project.tooling.xilinx_path)

    # Try to fix the Vitis workspace if the flag is set
    if fixvitis:
        xibif_print_info("Fixing Vitis workspace", stage=LS.STARTUP)

        # Check if the project is open in Vitis and warn the user to close it before building
        if not nowarn and not check_tool_running_and_ask("vitis"):
            xibif_print_error("Project is not closed in Vitis. Please close the project in Vitis and try again.", stage=LS.NO_CHANGE)
            sys.exit(1)

        # Finally run the fix for the Vitis workspace
        api.build.build_vitis_regenerate(project_name=project.name, board=project.board, xilinx_version=project.tooling.xilinx_version, xilinx_path=project.tooling.xilinx_path)
        project.vitis_path_check = XibifDefaults.VITIS_FOLDER

    return project


@validate_call(config=ConfigDict(strict=True, arbitrary_types_allowed=True))
def flash(
    project: XibifProject,
    args: argparse.Namespace,
) -> XibifProject:
    """Flashes the generated bitstream and ELF file to the board using the Hardware Server.

    Args:
        project (XibifProject): The XiBIF project to work with.
        args (argparse.Namespace): The arguments passed to the command.

    Returns:
        XibifProject: The updated XiBIF project after the flash process.
    """

    # Parse all arguments and get default values if they are not provided
    ip = getattr(args, "hardware_server", IPvAnyAddress("127.0.0.1"))
    port = getattr(args, "port", 3121)

    xibif_print_info("Flashing XiBIF project", stage=LS.STARTUP)
    try:
        api.flash.flash_hardware_server(
            project_name=project.name,
            board=project.board,
            xilinx_version=project.tooling.xilinx_version,
            ip=ip,
            port=port,
            xilinx_path=project.tooling.xilinx_path,
        )
    except ValidationError as e:
        for error in e.errors():
            xibif_print_error(f"Error with parameter '{error['loc'][0]}': Invalid value '{error['input']}'. {error['msg']}.", stage=LS.NO_CHANGE)
        sys.exit(1)

    return project


@validate_call(config=ConfigDict(strict=True, arbitrary_types_allowed=True))
def simulate(
    project: XibifProject,
    args: argparse.Namespace,
) -> XibifProject:
    """Runs the simulation for the XiBIF project using VUnit.

    Args:
        project (XibifProject): The XiBIF project to work with.
        args (argparse.Namespace): The arguments passed to the command.

    Returns:
        XibifProject: The updated XiBIF project after the simulation process.
    """
    # Parse all arguments and get default values if they are not provided
    compile_libs = getattr(args, "compile", False)
    list_testbenches = getattr(args, "list", False)
    tb = getattr(args, "test", [])
    gui = getattr(args, "gui", False)
    simulator = getattr(args, "simulator", VunitSimulator.MODELSIM)

    # Generate results folder in case it does not exist
    results_folder = XibifDefaults.RESULTS_FOLDER
    if not results_folder.exists():
        results_folder.mkdir(parents=True, exist_ok=True)

    try:
        if list_testbenches:
            xibif_print_info("List all available testbenches", stage=LS.STARTUP)
            api.simulate.simulation_list_testbenches(simulator=simulator)

        if compile_libs:
            xibif_print_info("Compile simulation libraries", stage=LS.STARTUP)
            api.simulate.simulation_compile(simulator=simulator)

        if not compile_libs and not list_testbenches:
            xibif_print_info("Simulate XiBIF project", stage=LS.STARTUP)
            if gui and not tb:
                xibif_print_warning("GUI mode is only available with -t. Continue with disabled GUI mode.", stage=LS.STARTUP)
                gui = False

            if not api.simulate.simulation_run(testbench=tb, gui=gui, simulator=simulator):
                xibif_print_error("Simulation failed!", stage=LS.SIMULATION)
                sys.exit(1)

    except (XibifRuntimeError, XibifValidationError) as e:
        xibif_print_error(str(e), stage=LS.NO_CHANGE)
        sys.exit(1)

    return project


@validate_call(config=ConfigDict(strict=True, arbitrary_types_allowed=True))
def testbench(
    project: XibifProject,
    args: argparse.Namespace,
) -> XibifProject:
    """Generates a testbench from a VHDL file using the provided clock and reset signals.

    Args:
        project (XibifProject): The XiBIF project to work with.
        args (argparse.Namespace): The arguments passed to the command.

    Returns:
        XibifProject: The updated XiBIF project after the testbench generation process.
    """

    clock = getattr(args, "clock", [])
    resetn = getattr(args, "reset_negative", [])
    resetp = getattr(args, "reset_positive", [])
    file = getattr(args, "file", "")

    filePath = XibifDefaults.HDL_SRC_FOLDER.joinpath(file)
    if not filePath.exists():
        xibif_print_error(f"Provided file {filePath} does not exist!", stage=LS.STARTUP)
        sys.exit(1)

    xibif_print_info("Validate parameters", stage=LS.STARTUP)
    parsed_vhdl_file = api.testbench.testbench_analyze_source_file(filePath)

    # Verify that the provided clock and reset signals are actually present in the VHDL file
    if clock is None:
        clock = []
    if resetn is None:
        resetn = []
    if resetp is None:
        resetp = []
    for clk in clock:
        if clk not in parsed_vhdl_file["input"]:
            xibif_print_error(f"Provided clock signal '{clk}' not found in the VHDL file!", stage=LS.STARTUP)
            xibif_print_error(f"Available input signals in the VHDL file: {parsed_vhdl_file['input']}", stage=LS.STARTUP)
            sys.exit(1)
    for rst in resetn:
        if rst not in parsed_vhdl_file["input"]:
            xibif_print_error(f"Provided negative reset signal '{rst}' not found in the VHDL file!", stage=LS.STARTUP)
            xibif_print_error(f"Available input signals in the VHDL file: {parsed_vhdl_file['input']}", stage=LS.STARTUP)
            sys.exit(1)
    for rst in resetp:
        if rst not in parsed_vhdl_file["input"]:
            xibif_print_error(f"Provided positive reset signal '{rst}' not found in the VHDL file!", stage=LS.STARTUP)
            xibif_print_error(f"Available input signals in the VHDL file: {parsed_vhdl_file['input']}", stage=LS.STARTUP)
            sys.exit(1)

    xibif_print_info("Generate testbench", stage=LS.STARTUP)
    api.testbench.testbench_generate(hdl_vhdl_file=filePath, clock=clock, resetn=resetn, resetp=resetp)

    return project


@validate_call(config=ConfigDict(strict=True, arbitrary_types_allowed=True))
def log(
    project: XibifProject,
    _: argparse.Namespace,
) -> XibifProject:
    """Opens the log file for the current day.

    Args:
        project (XibifProject): The XiBIF project to work with.

    Returns:
        XibifProject: The same XiBIF project that was passed in, since this command does not modify the project.
    """
    # Generate the path to the log file based on the current date
    path_log_file = get_user_temp_folder().joinpath(f'xibif_{datetime.now().strftime("%Y-%m-%d")}.log')

    xibif_print_info(f"Open log file {path_log_file}", stage=LS.STARTUP)

    # Open the log file
    if path_log_file.exists():
        webbrowser.open(path_log_file.as_uri())
    else:
        xibif_print_error(f"Log file {path_log_file} does not exist.", stage=LS.STARTUP)
        sys.exit(1)

    return project


@validate_call(config=ConfigDict(strict=True, arbitrary_types_allowed=True))
def report(
    project: XibifProject,
    _: argparse.Namespace,
) -> XibifProject:
    """Creates a report of the current project state and opens the issue tracker to report an issue.

    Args:
        project (XibifProject): The XiBIF project to work with.

    Returns:
        XibifProject: The same XiBIF project that was passed in, since this command does not modify the project.
    """

    # Create a backup of the old workspace
    backup_path = api.misc.misc_create_backup()

    # Copy log files
    xibif_print_info("Copy log files", stage=LS.STARTUP)
    log_files = get_user_temp_folder().glob("xibif_*.log")
    for log_file in log_files:
        shutil.copy(log_file, backup_path.joinpath(log_file.name))

    # Package the whole folder
    xibif_print_info(f"Packaging {backup_path}", stage=LS.REPORT)
    XibifDefaults.REPORT_FOLDER.mkdir(parents=True, exist_ok=True)
    archive = XibifDefaults.REPORT_FOLDER.joinpath(f"{datetime.now().strftime('%Y-%m-%d-%H-%M-%S')}.zip")
    shutil.make_archive(archive, "zip", backup_path)

    # Print success message
    xibif_print_info(f"Packaged project at {archive}", stage=LS.REPORT)

    # Generate issues path
    xibif_print_info("Open Issue Tracker", stage=LS.REPORT)
    issues_url = metadata("xibif").json["project_url"][2].replace("Issues, ", "")
    issues_path = issues_url + "/new?issue[title]=Report%20Issue%20from%20XiBIF&issuable_template=report&issue[confidential]=true"

    # Open the URL
    xibif_print_info(f"Please report the issue at {issues_path}", stage=LS.REPORT)
    webbrowser.open(issues_path)

    return project


@validate_call(config=ConfigDict(strict=True, arbitrary_types_allowed=True))
def start(
    project: XibifProject,
    args: argparse.Namespace,
) -> XibifProject:
    """Starts the specified tool for the XiBIF project.

    Args:
        project (XibifProject): The XiBIF project to work with.
        args (argparse.Namespace): The arguments passed to the command.

    Returns:
        XibifProject: The same XiBIF project that was passed in, since this command does not modify the project.
    """
    # Parse all arguments and get default values if they are not provided
    tool = getattr(args, "tool", XibifStartTool.VIVADO)

    # Get the path to the tool binary
    tools = get_xilinx_tool_paths(xilinx_path=project.tooling.xilinx_path, xilinx_version=project.tooling.xilinx_version)

    # Start Vivado
    if tool == XibifStartTool.VIVADO:
        xibif_print_info("Starting Vivado", stage=LS.STARTUP)
        vivado_project_path = XibifDefaults.VIVADO_FOLDER.joinpath(f"{project.name}.xpr").resolve()
        start_tool(tools.vivado, cmdline_params=f"-mode gui {vivado_project_path}")

    # Start Vitis
    elif tool == XibifStartTool.VITIS:
        xibif_print_info("Starting Vitis", stage=LS.STARTUP)
        vitis_project_path = XibifDefaults.VITIS_FOLDER.resolve()
        if project.tooling.xilinx_version in [XilinxVersion.V2023_2]:
            start_tool(tools.vitis, cmdline_params=f"-classic --workspace {vitis_project_path}")
        elif project.tooling.xilinx_version in [XilinxVersion.V2023_1]:
            start_tool(tools.vitis, cmdline_params=f"--workspace {vitis_project_path}")
        else:
            start_tool(tools.vitis, cmdline_params=f"--workspace {vitis_project_path}")

    # Start Hardware Server
    elif tool == XibifStartTool.HARDWARE_SERVER:
        xibif_print_info("Starting Hardware Server", stage=LS.STARTUP)
        start_tool(tools.hw_server)

    return project


@validate_call(config=ConfigDict(strict=True, arbitrary_types_allowed=True))
def upgrade(
    project: XibifProject,
    _: argparse.Namespace,
) -> XibifProject:
    """Upgrades the XiBIF project to the latest version.

    Args:
        project (XibifProject): The XiBIF project to work with.

    Returns:
        XibifProject: The updated XiBIF project after the upgrade process.
    """
    xibif_print_info("Upgrade XiBIF project", stage=LS.STARTUP)
    api.upgrade.upgrade(board=project.board, xilinx_version=project.tooling.xilinx_version, uuid=project.uuid, settings=project.settings)

    # Upgrade the project version in the project configuration
    project.version = get_version()

    return project


@validate_call(config=ConfigDict(strict=True, arbitrary_types_allowed=True))
def settings(
    project: XibifProject,
    args: argparse.Namespace,
) -> XibifProject:
    """Prints out the current settings of the project or changes the settings based on the provided arguments.

    Args:
        project (XibifProject): The XiBIF project to work with.
        args (argparse.Namespace): The arguments passed to the command.

    Returns:
        XibifProject: The updated XiBIF project with the changed settings.
    """

    # Remove default arguments
    args_dict = vars(copy.deepcopy(args))
    for arg in ["project", "verbosity", "command", "func", "summary"]:
        if arg in args_dict:
            del args_dict[arg]

    # Check if there are no settings to change
    if not args_dict:
        # Print out all settings from the project
        xibif_print_info("Current settings:", stage=LS.STARTUP)
        __settings_print(project.settings)

    else:
        xibif_print_info("Change XiBIF settings", stage=LS.STARTUP)

        # Change the settings
        for arg, value in args_dict.items():
            xibif_print_info(f"Setting {arg} to {value}", stage=LS.STARTUP)
            setattr(project.settings, arg, value)

        # Regenerate the Vitis header file with the new settings
        api.misc.misc_update_vitis_header_file(settings=project.settings)

    return project


@validate_call(config=ConfigDict(strict=True, arbitrary_types_allowed=True))
def __settings_print(model: Any) -> None:
    """Prints out the settings for the project."""
    for field_name, field in model.model_fields.items():
        if field.json_schema_extra is not None:
            if field.json_schema_extra.get("hidden", False):
                continue
        field_description = field.description
        field_default = field.default
        field_value = getattr(model, field_name)
        arg_name = f"--{field_name}"
        xibif_print_info(f"{arg_name} ({field_description}, Default: {field_default}): {field_value}", stage=LS.STARTUP)
