"""This module contains the implementation of the CLI argument parser for the XiBIF application, utilizing the argparse library to define and manage command-line arguments and subcommands for various functionalities of the application."""

import argparse
from typing import Any
from importlib.metadata import metadata, version
from pydantic import ConfigDict, validate_call
from pydantic.networks import IPvAnyAddress
from .commands import new, build, flash, register, simulate, testbench, report, upgrade, settings, start, log
from ..project.models import XibifSettings
from ..utils import get_default_xilinx_path, scan_xilinx_version
from ..api.build_stages import get_stage_choices, parse_stage
from ..types import XilinxBoard, XilinxVersion, VunitSimulator, XibifStartTool
from ..logger import LoggerVerbosity


class BuildStageAction(argparse.Action):
    """Custom argparse action to handle build stage arguments, allowing for flexible input of build stages in the CLI."""

    def __init__(self, **kwargs):
        """Initializes the BuildStageAction with choices for build stages."""
        kwargs.setdefault("choices", tuple(get_stage_choices()))
        super().__init__(**kwargs)

    @validate_call(config=ConfigDict(strict=True, arbitrary_types_allowed=True))
    def __call__(self, parser: argparse.ArgumentParser, namespace: argparse.Namespace, values: Any, option_string: str | None = None) -> None:
        """Handles the conversion of input values into build stages and stores them in the namespace.

        Args:
            parser (argparse.ArgumentParser): The argument parser instance.
            namespace (argparse.Namespace): The namespace to store the parsed values.
            values (Any): The input values to be converted into build stages.
            option_string (str | None, optional): The option string that was used. Defaults to None.
        """
        # Convert value(s) back into Enum(s)
        if isinstance(values, list):
            value = [parse_stage(v) for v in values]
        else:
            value = parse_stage(values)

        if self.nargs in ("+", "*", "append"):
            items = getattr(namespace, self.dest, None)
            if items is None:
                items = []
            if isinstance(value, list):
                items.extend(value)
            else:
                items.append(value)
            setattr(namespace, self.dest, items)
        else:
            setattr(namespace, self.dest, value)


@validate_call(config=ConfigDict(strict=True, arbitrary_types_allowed=True))
def generate_parser() -> argparse.ArgumentParser:
    """Generates a parser for the CLI application.

    Returns:
        ArgumentParser: A parser for the CLI application
    """
    # Base parser
    parser = argparse.ArgumentParser(
        prog=metadata("xibif")["Name"],
        description=metadata("xibif")["Summary"],
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    parser.add_argument(
        "-v",
        "--version",
        action="version",
        version="%(prog)s v" + version("xibif"),
    )
    parser.add_argument(
        "-p",
        "--project",
        help="Specify the XiBIF project file to use",
    )
    parser.add_argument(
        "--verbosity",
        help="Set the verbosity of the console output",
        choices=LoggerVerbosity,
        default=LoggerVerbosity.INFO,
        type=LoggerVerbosity,
        action="store",
        required=False,
    )
    parser.add_argument(
        "--summary",
        help="Show only a summary of the log output",
        action="store_true",
        required=False,
    )

    # Add subparsers
    subparsers = parser.add_subparsers(
        title="subcommands",
        required=True,
        dest="command",
    )

    # New Project
    parser_new = subparsers.add_parser(
        "new",
        help="Create a new XiBIF project",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    parser_new.set_defaults(func=new)
    parser_new.add_argument(
        "-n",
        "--name",
        help="Name of the project. This name will be used for the tooling project files",
        action="store",
        type=str,
        required=True,
    )
    parser_new.add_argument(
        "-p",
        "--path",
        help="The path to the directory in which to create the project",
        action="store",
        type=str,
        required=False,
    )
    group_new = parser_new.add_mutually_exclusive_group()
    group_new.add_argument(
        "--force",
        help="Overwrite an existing XiBIF project (less destructive than --nuke)",
        action="store_true",
        required=False,
    )
    group_new.add_argument(
        "--nuke",
        help="Completely remove an existing XiBIF project (more destructive than --force)",
        action="store_true",
        required=False,
    )
    parser_new.add_argument(
        "-b",
        "--board",
        help="Name of the FPGA board for this project",
        choices=XilinxBoard,
        action="store",
        type=XilinxBoard,
        required=True,
    )
    parser_new.add_argument(
        "-x",
        "--xilinx",
        help="Path to the Xilinx installation folder",
        action="store",
        type=str,
        default=get_default_xilinx_path(),
    )
    parser_new.add_argument(
        "-v",
        "--version",
        help="Xilinx tooling version to use",
        choices=XilinxVersion,
        action="store",
        type=XilinxVersion,
        default=scan_xilinx_version(get_default_xilinx_path()),
    )
    parser_new.add_argument(
        "--dev-mode",
        help="Create a project in development mode (linking to the source files instead of copying them)",
        action="store_true",
        required=False,
    )

    # Build Flow
    parser_build = subparsers.add_parser(
        "build",
        help="Run all build steps for the XiBIF project",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    parser_build.set_defaults(func=build)
    parser_build.add_argument(
        "--nowarn",
        help="Disable the warnings about Vitis bugs and old registers",
        action="store_true",
        required=False,
    )
    parser_build.add_argument(
        "--noreport-vivado",
        help="Do not generate output reports for Vivado",
        action="store_true",
        required=False,
    )
    parser_build.add_argument(
        "--fix-vitis",
        help="Try to fix Vitis workspace in case it got corrupt",
        action="store_true",
        required=False,
    )
    parser_build.add_argument(
        "--stage",
        help="Build Vivado/Vitis project with the provided stage(s)",
        action=BuildStageAction,
        default=[],
        nargs="+",
        required=False,
    )
    parser_build.add_argument(
        "--from",
        help="Build the Vivado/Vitis project starting with the provided stage",
        action=BuildStageAction,
        required=False,
    )
    parser_build.add_argument(
        "--to",
        help="Build the Vivado/Vitis project stopping with the provided stage",
        action=BuildStageAction,
        required=False,
    )

    # Flash Flow
    parser_flash = subparsers.add_parser(
        "flash",
        help="Flash the FPGA with the generated bitstream",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    parser_flash.set_defaults(func=flash)
    parser_flash.add_argument(
        "-hw",
        "--hardware-server",
        help="Hostname or IP address of the computer running hardware server",
        action="store",
        type=IPvAnyAddress,
        required=False,
        default="127.0.0.1",
    )
    parser_flash.add_argument(
        "-p",
        "--port",
        help="Port of the hardware server",
        action="store",
        type=int,
        required=False,
        default=3121,
    )

    # Register Creation and manipulation
    parser_register = subparsers.add_parser(
        "register",
        help="Update the XiBIF Registers from the register files",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    parser_register.set_defaults(func=register)
    parser_register.add_argument(
        "-s",
        "--stream",
        help="Generate the XiBIF stream registers",
        action="store_true",
        required=False,
    )
    parser_register.add_argument(
        "-u",
        "--user",
        help="Generate the XiBIF user registers",
        action="store_true",
        required=False,
    )
    parser_register.add_argument(
        "-c",
        "--custom",
        help="Generate the custom registers",
        action="store_true",
        required=False,
    )
    group_register_custom = parser_register.add_mutually_exclusive_group()
    group_register_custom.add_argument(
        "--enable-custom",
        help="Enable generation of custom registers (provide file name)",
        type=str,
        action="store",
        required=False,
    )
    group_register_custom.add_argument(
        "--disable-custom",
        help="Disable generation of custom registers",
        action="store_true",
        required=False,
    )

    # Simulation flow
    parser_simulate = subparsers.add_parser(
        "simulation",
        help="Simulate all VHDL testbenches",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    parser_simulate.set_defaults(func=simulate)
    group_simulate = parser_simulate.add_mutually_exclusive_group()
    group_simulate.add_argument(
        "-c",
        "--compile",
        help="Compiles simulation libraries (xilinx and vunit)",
        action="store_true",
        required=False,
    )
    group_simulate.add_argument(
        "-l",
        "--list",
        help="List all available testbenches and testcases",
        action="store_true",
        required=False,
    )
    group_simulate.add_argument(
        "-t",
        "--test",
        help="Run only the specified testbench and testcase",
        action="append",
        type=str,
        required=False,
    )
    parser_simulate.add_argument(
        "-g",
        "--gui",
        help="Open the GUI for the simulation (only valid with -t)",
        action="store_true",
        required=False,
    )
    parser_simulate.add_argument(
        "-s",
        "--simulator",
        help="Simulator that shall be used (must be available on the path)",
        action="store",
        type=VunitSimulator,
        choices=VunitSimulator,
        default=VunitSimulator.MODELSIM,
        required=False,
    )

    # Testbench flow
    parser_testbench = subparsers.add_parser(
        "testbench",
        help="Generate a testbench from a VHDL file",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    parser_testbench.set_defaults(func=testbench)
    parser_testbench.add_argument(
        "-f",
        "--file",
        help="Name of the VHDL file to generate a testbench for",
        type=str,
        action="store",
        required=True,
    )
    parser_testbench.add_argument(
        "-c",
        "--clock",
        help="Name of clock signal(s)",
        type=str,
        action="append",
        required=False,
    )
    parser_testbench.add_argument(
        "-rn",
        "--reset-negative",
        help="Name of negative reset signal(s)",
        type=str,
        action="append",
        required=False,
    )
    parser_testbench.add_argument(
        "-rp",
        "--reset-positive",
        help="Name of positive reset signal(s)",
        type=str,
        action="append",
        required=False,
    )

    # Log
    parser_log = subparsers.add_parser(
        "log",
        help="Show the latest log file",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    parser_log.set_defaults(func=log)

    # Report issues
    parser_report = subparsers.add_parser(
        "report",
        help="Report an issue to XiBIF's GitLab page",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    parser_report.set_defaults(func=report)

    # Start
    parser_start = subparsers.add_parser(
        "start",
        help="Start a tool",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    parser_start.set_defaults(func=start)
    parser_start.add_argument(
        "tool",
        help="Tool to start",
        choices=XibifStartTool,
        type=XibifStartTool,
    )

    # Upgrade
    parser_upgrade = subparsers.add_parser(
        "upgrade",
        help="Upgrade the VHDL and C source-files to the newest XiBIF version",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    parser_upgrade.set_defaults(func=upgrade)

    # Settings
    parser_settings = subparsers.add_parser(
        "settings",
        help="Change the settings of the XiBIF project",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    parser_settings.set_defaults(func=settings)
    add_arguments_settings(parser_settings)

    return parser


@validate_call(config=ConfigDict(strict=True, arbitrary_types_allowed=True))
def add_arguments_settings(parser: argparse.ArgumentParser) -> None:
    """Adds arguments to the parser based on the fields of the Xibif Project.

    Args:
        parser (argparse.ArgumentParser): The argument parser to which the arguments should be added.
    """
    for field_name, field in XibifSettings.model_fields.items():
        if field.json_schema_extra is not None:
            if field.json_schema_extra.get("hidden", False):
                continue
        field_type = field.annotation
        field_description = field.description
        field_default = field.default
        arg_name = f"--{field_name}"

        if field_type == bool:
            parser.add_argument(arg_name, type=str, help=f"{field_description} (type: bool, default: {field_default})", default=argparse.SUPPRESS, action="store", choices=["True", "False"])
        else:
            parser.add_argument(arg_name, type=field_type, help=f"{field_description} (type: {field_type.__name__}, default: {field_default})", default=argparse.SUPPRESS, action="store")
