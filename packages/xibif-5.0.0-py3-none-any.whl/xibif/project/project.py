"""Module containing the XibifProject class, which represents a XiBIF project and manages the project configuration."""

import hashlib
import json
from pydantic import ValidationError, ConfigDict, validate_call
from ..logger import LoggerStage as LS, xibif_print_debug, xibif_print_warning
from .models import XibifConfig, XibifTooling, XibifSettings, XibifRegister
from ..types import XibifPath, XibifUUID, XibifVersion, XibifChecksum, XilinxBoard, XibifDefaults, XibifInvalidPathError, XibifValidationError, XibifChecksumError
from ..utils import get_version


class XibifProject:
    """Class representing a XiBIF project, responsible for managing the project configuration and providing methods to read and write the configuration to a file."""

    __path: XibifPath
    __config: XibifConfig = XibifConfig()

    @validate_call(config=ConfigDict(strict=True))
    def __init__(self, project_folder: XibifPath = XibifDefaults.PROJECT_PATH) -> None:
        """Initialize the XibifProject instance.

        Args:
            project_folder (XibifPath): Path to the project configuration file. Defaults to XibifDefaults.PROJECT_PATH.
        """
        # Save the project path for later use
        self.path = project_folder

    @validate_call(config=ConfigDict(strict=True))
    def write_config(self) -> None:
        """Write the current project configuration to a JSON file at the specified project path."""
        xibif_print_debug(f"Writing project configuration to {self.__path.joinpath(XibifDefaults.PROJECT_NAME)}", stage=LS.NO_CHANGE)

        # Calculate the checksum of the current configuration and update the config with the new checksum
        self.__config.checksum = self.checksum

        # Check if the project path exists else create it
        self.__path.mkdir(parents=True, exist_ok=True)
        with open(self.__path.joinpath(XibifDefaults.PROJECT_NAME), "w") as file:
            json.dump(self.__config.model_dump(mode="json"), file, indent=4)

    @validate_call(config=ConfigDict(strict=True))
    def load_config(self) -> None:
        """Load the project configuration from a JSON file at the specified project path."""
        xibif_print_debug(f"Loading project configuration from {self.__path.joinpath(XibifDefaults.PROJECT_NAME)}", stage=LS.NO_CHANGE)

        # Traverse the directory tree upward to look for a project file
        while not self.__path.joinpath(XibifDefaults.PROJECT_NAME).exists() and self.__path.parent != self.__path:
            xibif_print_warning(f"No project file found at {self.__path}! Traversing upward", stage=LS.NO_CHANGE)
            self.__path = self.__path.parent

        if not self.__path.joinpath(XibifDefaults.PROJECT_NAME).exists():
            raise XibifInvalidPathError(f"Project configuration file {self.__path.joinpath(XibifDefaults.PROJECT_NAME)} does not exist.")

        try:
            with open(self.__path.joinpath(XibifDefaults.PROJECT_NAME), "r") as file:
                data = json.load(file)
                # self.__config = TypeAdapter(XibifConfig).validate_python(data)
                self.__config = XibifConfig.model_validate(data)

        except (json.JSONDecodeError, ValidationError) as e:
            raise XibifValidationError(f"Failed to load project configuration from {self.__path.joinpath(XibifDefaults.PROJECT_NAME)}.") from e

        # Check the version of the loaded project and issue a warning if the project was created with a different version of xibif
        if self.__config.version_xibif != get_version():
            xibif_print_warning(
                f"Project configuration was created with xibif version {self.__config.version_xibif}, but current xibif version is {get_version()}. Consider upgrading the project configuration to the latest version.",
                stage=LS.STARTUP,
            )

        # Check if the checksum of the loaded configuration matches the calculated checksum of the current configuration
        if self.checksum != self.checksum_saved:
            raise XibifChecksumError(
                f"Checksum mismatch for project configuration at {self.__path.joinpath(XibifDefaults.PROJECT_NAME)}. The configuration file might be corrupted or manually edited."
            )

    @property
    @validate_call(config=ConfigDict(strict=True))
    def path(self) -> XibifPath:
        """Get the path to the project configuration file.

        Returns:
            XibifPath: The path to the project configuration file.
        """
        return self.__path

    @path.setter
    @validate_call(config=ConfigDict(strict=True))
    def path(self, path: XibifPath) -> None:
        """Set the path to the project configuration file.

        Args:
            path (XibifPath): The new path to the project configuration file.
        """
        self.__path = path

    @property
    @validate_call(config=ConfigDict(strict=True))
    def checksum(self) -> XibifChecksum:
        """Calculate and return the checksum of the current project configuration.

        Returns:
            XibifChecksum: The checksum of the current project configuration.
        """
        config_json = self.__config.model_dump(mode="json")
        config_json["checksum"] = "0"  # Set the checksum field to a fixed value to avoid it affecting the checksum calculation
        checksum = XibifChecksum(hashlib.md5(json.dumps(config_json).encode()).hexdigest())
        xibif_print_debug(f"Project: Calculated checksum: {checksum}", stage=LS.NO_CHANGE)
        return checksum

    @property
    @validate_call(config=ConfigDict(strict=True))
    def checksum_saved(self) -> XibifChecksum:
        """Get the checksum of the project configuration as saved in the project file.

        Returns:
            XibifChecksum: The checksum of the project configuration as saved in the project file.
        """
        xibif_print_debug(f"Project: Saved checksum: {self.__config.checksum}", stage=LS.NO_CHANGE)
        return self.__config.checksum

    @property
    @validate_call(config=ConfigDict(strict=True))
    def vitis_path_check(self) -> XibifPath:
        """Get the path to check for the Vitis project folder.

        Returns:
            XibifPath: The path to check for the Vitis project folder.
        """
        return self.__config.vitis_path_check

    @vitis_path_check.setter
    @validate_call(config=ConfigDict(strict=True))
    def vitis_path_check(self, vitis_path_check: XibifPath) -> None:
        """Set the path to check for the Vitis project folder.

        Args:
            vitis_path_check (XibifPath): The new path to check for the Vitis project folder.
        """
        self.__config.vitis_path_check = vitis_path_check

    @property
    @validate_call(config=ConfigDict(strict=True))
    def board(self) -> XilinxBoard:
        """Get the target FPGA board from the project configuration.

        Returns:
            XilinxBoard: The target FPGA board from the project configuration.
        """
        return self.__config.board

    @board.setter
    @validate_call(config=ConfigDict(strict=True))
    def board(self, board: XilinxBoard) -> None:
        """Set the target FPGA board in the project configuration.

        Args:
            board (XilinxBoard): The new target FPGA board to set in the project configuration.
        """
        self.__config.board = board

    @property
    @validate_call(config=ConfigDict(strict=True))
    def name(self) -> str:
        """Get the name of the project from the project configuration.

        Returns:
            str: The name of the project from the project configuration.
        """
        return self.__config.project_name

    @name.setter
    @validate_call(config=ConfigDict(strict=True))
    def name(self, name: str):
        """Set the name of the project in the project configuration.

        Args:
            name (str): The new name of the project to set in the project configuration.
        """
        self.__config.project_name = name

    @property
    @validate_call(config=ConfigDict(strict=True))
    def uuid(self) -> XibifUUID:
        """Get the UUID of the project from the project configuration.

        Returns:
            XibifUUID: The UUID of the project from the project configuration.
        """
        return self.__config.uuid

    @property
    @validate_call(config=ConfigDict(strict=True))
    def version(self) -> XibifVersion:
        """Get the version of the xibif tool from the project configuration.

        Returns:
            XibifVersion: The version of the xibif tool from the project configuration.
        """
        return self.__config.version_xibif

    @version.setter
    @validate_call(config=ConfigDict(strict=True))
    def version(self, version: XibifVersion) -> None:
        """Set the version of the xibif tool in the project configuration.

        Args:
            version (XibifVersion): The new version of the xibif tool to set in the project configuration.
        """
        self.__config.version_xibif = version

    @property
    @validate_call(config=ConfigDict(strict=True))
    def register(self) -> XibifRegister:
        """Get the register configuration from the project configuration.

        Returns:
            XibifRegister: The register configuration from the project configuration.
        """
        return self.__config.registers

    @register.setter
    @validate_call(config=ConfigDict(strict=True))
    def register(self, register: XibifRegister) -> None:
        """Set the register configuration in the project configuration.

        Args:
            register (XibifRegister): The new register configuration to set in the project configuration.
        """
        self.__config.registers = register

    @property
    @validate_call(config=ConfigDict(strict=True))
    def settings(self) -> XibifSettings:
        """Get the settings from the project configuration.

        Returns:
            XibifSettings: The settings from the project configuration.
        """
        return self.__config.settings

    @settings.setter
    @validate_call(config=ConfigDict(strict=True))
    def settings(self, settings: XibifSettings) -> None:
        """Set the settings in the project configuration.

        Args:
            settings (XibifSettings): The new settings to set in the project configuration.
        """
        self.__config.settings = settings

    @property
    @validate_call(config=ConfigDict(strict=True))
    def tooling(self) -> XibifTooling:
        """Get the tooling configuration from the project configuration.

        Returns:
            XibifTooling: The tooling configuration from the project configuration.
        """
        return self.__config.tooling

    @tooling.setter
    @validate_call(config=ConfigDict(strict=True))
    def tooling(self, tooling: XibifTooling) -> None:
        """Set the tooling configuration in the project configuration.

        Args:
            tooling (XibifTooling): The new tooling configuration to set in the project configuration.
        """
        self.__config.tooling = tooling
