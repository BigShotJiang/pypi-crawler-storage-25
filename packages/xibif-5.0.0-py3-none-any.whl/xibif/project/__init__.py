"""XiBIF project module - Main entry point for project management and operations."""

from .project import XibifProject
