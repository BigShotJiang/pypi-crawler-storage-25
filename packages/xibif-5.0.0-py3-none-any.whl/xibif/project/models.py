"""XiBIF Project Model definitions."""

import uuid
from datetime import datetime
from pydantic import BaseModel, Field, ConfigDict
from pydantic.networks import IPv4Address
from pydantic_extra_types.mac_address import MacAddress
from ..utils import generate_random_mac, get_version
from ..types import XilinxVersion, XilinxBoard, XibifPath, XibifChecksum, XibifUUID, XibifVersion, XibifDefaultsRegex, XibifDefaults


class XibifTooling(BaseModel):
    """Model for storing paths and versions of external binary tools."""

    model_config = ConfigDict(validate_assignment=True)

    xilinx_version: XilinxVersion | None = Field(default=None, description="Version of the Xilinx tools")
    xilinx_path: XibifPath | None = Field(default=None, description="Path to the Xilinx tools")


class XibifRegister(BaseModel):
    """Model for storing register configuration and checksums."""

    model_config = ConfigDict(validate_assignment=True)

    user_register_checksum: XibifChecksum = Field(default=XibifChecksum("0"), description="Checksum of the user registers")
    custom_register_enabled: bool = Field(default=False, description="Flag to indicate if custom registers are enabled")
    custom_register_config_name: str = Field(default="", description="Name of the custom register configuration file", pattern=XibifDefaultsRegex.PROJECT_NAME)
    custom_register_checksum: XibifChecksum = Field(default=XibifChecksum("0"), description="Checksum of the custom register configuration")


class XibifSettings(BaseModel):
    """Model for storing default settings for the project, including networking and timeouts."""

    model_config = ConfigDict(validate_assignment=True)

    mac: MacAddress = Field(default_factory=generate_random_mac, description="MAC address")
    ip: IPv4Address = Field(default=IPv4Address("192.168.1.10"), description="Default IP address")
    netmask: IPv4Address = Field(default=IPv4Address("255.255.255.0"), description="Default network mask")
    gateway: IPv4Address = Field(default=IPv4Address("192.168.1.1"), description="Default gateway")
    timeout_dhcp: int = Field(default=10, ge=1, le=255, description="DHCP timeout in seconds")
    timeout_connection_drop_ms: int = Field(default=1000, ge=1, le=65535, description="Connection drop timeout in milliseconds")
    connection_drop_flush_fifo: bool = Field(default=False, description="Flag to flush FIFO on connection drop")
    timeout_axi_firewall_clocks: int = Field(default=100, ge=1, le=65535, description="Timeout for AXI Firewall in clock cycles")
    enable_webserver: bool = Field(default=True, description="Enable embedded web server for register access")


class XibifConfig(BaseModel):
    """Top-level configuration model for XiBIF projects."""

    model_config = ConfigDict(validate_assignment=True)

    project_name: str = Field(default=XibifDefaults.APP_NAME, description="Name of the project", pattern=XibifDefaultsRegex.PROJECT_NAME)
    creation_date: str = Field(default=datetime.now().strftime("%Y-%m-%d_%H-%M-%S"), description="Creation date of the project")
    version_xibif: XibifVersion = Field(default=get_version(), description="Version of the xibif tool")
    checksum: XibifChecksum = Field(default=XibifChecksum("0"), description="Checksum of the project")
    uuid: XibifUUID = Field(default=XibifUUID((uuid.uuid1().int >> 32) & 0xFFFFFFFF), description="UUID of the project")
    board: XilinxBoard = Field(default=XilinxBoard.ZEDBOARD, description="Target FPGA board for the project")

    tooling: XibifTooling = Field(default=XibifTooling(), description="Configuration for external binary tools")
    registers: XibifRegister = Field(default=XibifRegister(), description="Configuration for registers")
    settings: XibifSettings = Field(default=XibifSettings(), description="Default settings for the project")

    vitis_path_check: XibifPath = Field(
        default=XibifDefaults.VITIS_FOLDER, description="Path to check for vitis project folder. This is used to check if the Vitis project might be in a broken state."
    )
