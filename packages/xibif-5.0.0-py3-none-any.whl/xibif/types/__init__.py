"""XiBIF types module."""

# pylint: disable=undefined-all-variable

from importlib import import_module

# Load utils first – XibifPath must be available before logger is imported
# (defaults_messages → messages → logger → logger/utils → types.XibifPath)
from .utils import XibifPath, XibifVersion, XibifUUID, XibifChecksum, validate_XibifPath_exist
from .boards import XilinxBoard
from .defaults_regex import XibifDefaultsRegex
from .exceptions import (
    XibifError,
    XibifEnvironmentError,
    XibifInvalidPathError,
    XibifGeneratedFileError,
    XibifRuntimeError,
    XibifTimeoutError,
    XibifRegisterError,
    XibifValidationError,
    XibifChecksumError,
)
from .tooling import XilinxVersion, VunitSimulator, XibifStartTool, XilinxToolPath
from .defaults import XibifDefaults

__all__ = [
    "XibifPath",
    "XibifVersion",
    "XibifUUID",
    "XibifChecksum",
    "validate_XibifPath_exist",
    "XilinxBoard",
    "XibifDefaultsRegex",
    "XibifError",
    "XibifEnvironmentError",
    "XibifInvalidPathError",
    "XibifGeneratedFileError",
    "XibifRuntimeError",
    "XibifTimeoutError",
    "XibifRegisterError",
    "XibifValidationError",
    "XibifChecksumError",
    "XilinxVersion",
    "VunitSimulator",
    "XibifStartTool",
    "XilinxToolPath",
    "XibifDefaults",
    "XibifMessage",
    "XibifDefaultsMessages",
]


def __getattr__(name: str):
    """Load message helpers lazily to avoid logger/type initialization cycles."""
    if name == "XibifMessage":
        return import_module(f"{__name__}.messages").XibifMessage
    if name == "XibifDefaultsMessages":
        return import_module(f"{__name__}.defaults_messages").XibifDefaultsMessages
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
