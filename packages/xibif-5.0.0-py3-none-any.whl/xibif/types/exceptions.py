"""
Custom exceptions for XibIF.
"""


class XibifError(Exception):
    """Base exception for all xibif-related errors."""


class XibifEnvironmentError(XibifError):
    """Exception raised for missing tools or packages in the environment."""


class XibifInvalidPathError(XibifError):
    """Exception raised for invalid file paths."""


class XibifGeneratedFileError(XibifError):
    """Exception raised when a generated file is not found or cannot be accessed."""


class XibifRuntimeError(XibifError):
    """Exception raised for errors that occur during the execution of xibif operations."""


class XibifTimeoutError(XibifError):
    """Exception raised when an operation exceeds the specified timeout duration."""


class XibifRegisterError(XibifError):
    """Exception raised for errors related to register handling."""


class XibifValidationError(XibifError):
    """Exception raised for validation errors in the project configuration."""


class XibifChecksumError(XibifError):
    """Exception raised for checksum mismatches in the project configuration."""
