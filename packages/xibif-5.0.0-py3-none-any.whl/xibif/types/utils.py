"""Utility types and path handling for XiBIF."""

from __future__ import annotations
import os
import platform
from os import PathLike
from pathlib import Path
import inspect
import functools
import re
from typing import Annotated, Any
from typing import ClassVar, TYPE_CHECKING
from collections.abc import Iterable
from pydantic import ConfigDict, validate_call, Field, model_serializer, model_validator
from pydantic.dataclasses import dataclass
from .exceptions import XibifValidationError, XibifInvalidPathError
from .defaults_regex import XibifDefaultsRegex

######################################################################################
# Data Types
######################################################################################
# Provide TypeHints for forwarded functions and attributes
XibifPathBase = Path if TYPE_CHECKING else PathLike


@dataclass(config=ConfigDict(validate_assignment=True))
class XibifPath(XibifPathBase):
    """Custom Path class for XiBIF that extends pathlib.Path with additional functionality."""

    __pathRoot: ClassVar[Path | XibifPath | None] = None
    __path: Path | XibifPath = Path()

    @validate_call(config=ConfigDict(strict=True, defer_build=True))
    def __init__(self, path: Path | str | XibifPath) -> None:
        """Initialize the XibifPath with a given path string or Path object.

        Args:
            path (Path | str | XibifPath): The path to initialize the XibifPath with..
        """
        self.__path = Path(path)

    def __post_init__(self) -> None:
        """Post-initialization method to validate the path against a regex pattern and ensure it does not contain invalid characters."""

        # Check if the path is valid according to the regex, if not raise an error
        if re.match(XibifDefaultsRegex.PATH, str(self.__path)) is None:
            raise XibifValidationError(f"Invalid path '{self.__path}'. Paths contains invalid characters. Regex used for validation: '{XibifDefaultsRegex.PATH}'.")

    @validate_call(config=ConfigDict(strict=True, defer_build=True))
    def __getattr__(self, name: str) -> Any:
        """Delegate attribute access to the underlying Path object, while ensuring that any returned Path objects are wrapped as XibifPath.

        Args:
            name (str): The name of the attribute being accessed.

        Returns:
            any: The value of the requested attribute, wrapped as XibifPath if it is a Path.
        """
        attr = getattr(self.__resolve(), name)  # Call resolve to get the absolute path before accessing the attribute

        # If the attribute is callable, wrap it to return XibifPath if it returns a Path
        if callable(attr):

            def wrapper(*args, **kwargs):
                result = attr(*args, **kwargs)

                # If the result is a Path, wrap it in XibifPath before returning
                if isinstance(result, Path):
                    return XibifPath(result)
                elif inspect.isgenerator(result) or isinstance(result, Iterable) and not isinstance(result, (str, bytes)):
                    return (XibifPath(p) if isinstance(p, Path) else p for p in result)
                return result

            return wrapper

        # If the attr is a Path, wrap it in XibifPath before returning
        elif isinstance(attr, Path):
            return XibifPath(attr)

        else:
            return attr

    @model_validator(mode="before")
    @classmethod
    def deserialize(cls, data: Any) -> Any:
        """Deserialize the XibifPath from a string or dict.

        Args:
            data (any): The data to deserialize, which can be a string or a dict.

        Returns:
            any: The deserialized data as a XibifPath object.
        """
        if isinstance(data, str):
            return {"_XibifPath__path": data}
        return data

    @model_serializer
    def serialize(self) -> str:
        """Serialize the XibifPath to a string.

        Returns:
            str: The string representation of the path, taking into account the root if set.
        """
        if self.__path.is_absolute() or self.__pathRoot is None:
            return self.__path.as_posix()
        else:
            return self.__pathRoot.joinpath(self.__path).as_posix()

    @validate_call(config=ConfigDict(strict=True, defer_build=True))
    def __fspath__(self) -> str:
        """Return the string representation of the path for compatibility with functions that expect a string path.

        Returns:
            str: The string representation of the path.
        """
        return str(self.__as_long(self.__resolve()))

    @validate_call(config=ConfigDict(strict=True, defer_build=True))
    def __str__(self) -> str:
        """Return the string representation of the path.

        Returns:
            str: The string representation of the path, taking into account the root if set.
        """
        if self.__path.is_absolute() or self.__pathRoot is None:
            return str(self.__path)
        else:
            return str(self.__pathRoot.joinpath(self.__path))

    @validate_call(config=ConfigDict(strict=True, defer_build=True))
    def __repr__(self) -> str:
        """Return the official string representation of the XibifPath object.

        Returns:
            str: The official string representation of the XibifPath object.
        """
        return f"XibifPath({self.__str__()!r})"

    @validate_call(config=ConfigDict(strict=True, defer_build=True))
    def __eq__(self, other: Any) -> bool:
        """Compare two XibifPath objects for equality, taking into account the root if set.

        Args:
            other (Any): The object to compare with.

        Returns:
            bool: True if the paths are equal, False otherwise.
        """

        if isinstance(other, XibifPath):
            return str(self) == str(other)
        elif isinstance(other, (str, Path)):
            return str(self) == str(XibifPath(other))
        return False

    @validate_call(config=ConfigDict(strict=True, defer_build=True))
    def __resolve(self) -> Path:
        """Resolve the path to an absolute path, taking into account the root if set.

        Returns:
            Path: The resolved absolute path.
        """
        if self.__pathRoot is None:
            if self.__path.is_absolute():
                return self.__as_long(self.__path)
            else:
                return self.__path
        else:
            return self.__as_long(self.__pathRoot.resolve().joinpath(self.__path))

    @validate_call(config=ConfigDict(strict=True, defer_build=True))
    def is_absolute(self) -> bool:
        """Check if the path is absolute.

        Returns:
                bool: True if the path is absolute, False otherwise.
        """
        return self.__path.is_absolute()

    @validate_call(config=ConfigDict(strict=True, defer_build=True))
    def stat(self) -> os.stat_result:
        """Return the stat result of the resolved path.

        Returns:
            os.stat_result: The stat result of the resolved path.
        """
        return self.__resolve().stat()

    @validate_call(config=ConfigDict(strict=True, defer_build=True))
    def __as_long(self, short_path: Path | XibifPath) -> Path:
        """Convert the path to a long path format for Windows compatibility.

        Args:
            short_path (Path): The original path to convert.

        Returns:
            Path: The converted long path.
        """
        if os.name == "nt":
            if not str(short_path).startswith("\\\\?\\"):
                return Path("\\\\?\\").joinpath(short_path)
            return short_path
        else:
            return short_path

    @validate_call(config=ConfigDict(strict=True, defer_build=True))
    def as_windows(self) -> XibifPath:
        """Convert a Unix-style path (/c/path) to a Windows-style path (C:/path).

        Returns:
            XibifPath: The converted Windows-style path.
        """
        path_str = self.resolve().as_posix()  # Convert XibifPath to Unix-style string
        if path_str.startswith("/"):
            drive, _, remainder = path_str[1:].partition("/")
            if len(drive) == 1 and drive.isalpha():
                return XibifPath(f"{drive.upper()}:/").joinpath(remainder)
        return self.resolve()

    @validate_call(config=ConfigDict(strict=True, defer_build=True))
    def as_tcl(self) -> str:
        """Convert the path to a string with forward slashes, and handle MSYS2/WSL-style paths on Windows.

        Returns:
            str: The path as a string with forward slashes, suitable for use in Tcl commands
        """
        # Convert XibifPath object to a string with forward slashes
        path_str = self.resolve().as_posix()

        if platform.system() == "Windows":
            # Handle MSYS2/WSL-style paths starting with /c/, /d/, etc.
            if path_str.startswith("/"):
                drive, _, remainder = path_str[1:].partition("/")
                if len(drive) == 1 and drive.isalpha():
                    # Convert /c/path to C:/path
                    path_str = f"{drive.upper()}:/{remainder}"

        return f'"{path_str}"'  # Wrap the path in double quotes for Tcl compatibility

    @classmethod
    @validate_call(config=ConfigDict(strict=True, defer_build=True))
    def set_root(cls, root: Path | str | XibifPath) -> None:
        """Set the root path for all XibifPath instances.

        Args:
            root (Path | str | XibifPath): The root path to set for all XibifPath instances."""
        cls.__pathRoot = Path(root)

    @classmethod
    def cwd(cls) -> XibifPath:
        """Get the current working directory as a XibifPath.

        Returns:
            XibifPath: The current working directory.
        """
        return cls(Path.cwd())


@dataclass(frozen=True)
class XibifVersion:
    """Data class to hold version information for XiBIF."""

    major: Annotated[int, Field(ge=0, le=255)] = 0
    minor: Annotated[int, Field(ge=0, le=255)] = 0
    patch: Annotated[int, Field(ge=0, le=255)] = 0
    revision: Annotated[int, Field(ge=0, le=255)] = 0

    def __str__(self) -> str:
        """Return the version as a string in the format 'major.minor.patch.revision'.

        Returns:
            str: The version string.
        """
        return f"{self.major}.{self.minor}.{self.patch}.{self.revision}"

    def __repr__(self) -> str:
        """Return the official string representation of the XibifVersion object.

        Returns:
            str: The official string representation of the XibifVersion object.
        """
        return f"XibifVersion(major={self.major}, minor={self.minor}, patch={self.patch}, revision={self.revision})"

    def __eq__(self, other: Any) -> bool:
        """Compare two XibifVersion objects for equality.

        Args:
            other (Any): The object to compare with.

        Returns:
            bool: True if versions are equal, False otherwise.
        """
        if isinstance(other, XibifVersion):
            return (self.major, self.minor, self.patch, self.revision) == (other.major, other.minor, other.patch, other.revision)
        return False


@dataclass(frozen=True)
class XibifUUID:
    """Data class to hold UUID information for XiBIF."""

    uuid: Annotated[int, Field(ge=0, le=2**32 - 1)] = 0

    @model_validator(mode="before")
    @classmethod
    def deserialize(cls, data: Any) -> Any:
        """Deserialize the UUID from an int or dict.

        Args:
            data (any): The data to deserialize, which can be an int or a dict.

        Returns:
            any: The deserialized data as a dict with a 'uuid' key.
        """
        if isinstance(data, int):
            return {"uuid": data}
        return data

    @model_serializer
    def serialize(self) -> int:
        """Serialize the UUID to an int.

        Returns:
            int: The UUID int.
        """
        return self.uuid

    def __str__(self) -> str:
        """Return the UUID as a hexadecimal string.

        Returns:
            str: The UUID string in hexadecimal format.
        """
        return f"{self.uuid}/0x{self.uuid:08X}"

    def __repr__(self) -> str:
        """Return the official string representation of the XibifUUID object.

        Returns:
            str: The official string representation of the XibifUUID object.
        """
        return f"XibifUUID(uuid={self.__str__()})"


@dataclass(config=ConfigDict(validate_assignment=True))
class XibifChecksum:
    """Data class to hold checksum information for XiBIF."""

    checksum: Annotated[str, Field(pattern=r"^[0-9a-fA-F]+$")] = "0"

    @model_validator(mode="before")
    @classmethod
    def deserialize(cls, data: Any) -> Any:
        """Deserialize the checksum from a string or dict.
        Args:
            data (any): The data to deserialize, which can be a string or a dict.
        Returns:
            any: The deserialized data as a dict with a 'checksum' key.
        """
        if isinstance(data, str):
            return {"checksum": data}
        return data

    @model_serializer
    def serialize(self) -> str:
        """Serialize the checksum to a string.

        Returns:
            str: The checksum string.
        """
        return self.checksum

    def __str__(self) -> str:
        """Return the checksum as a string.

        Returns:
            str: The checksum string.
        """
        return self.checksum

    def __repr__(self) -> str:
        """Return the official string representation of the XibifChecksum object.

        Returns:
            str: The official string representation of the XibifChecksum object.
        """
        return f"XibifChecksum(checksum={self.checksum})"

    def __eq__(self, other: Any) -> bool:
        """Compare two XibifChecksum objects for equality.

        Args:
            other (Any): The object to compare with.

        Returns:
            bool: True if checksums are equal, False otherwise.
        """
        if isinstance(other, XibifChecksum):
            return self.checksum == other.checksum
        elif isinstance(other, str):
            return self.checksum == other
        return False


######################################################################################
# Verifier Functions
######################################################################################
def validate_XibifPath_exist(func: callable) -> callable:
    """Decorator to validate that any argument of type XibifPath exists as a file or directory.

    Args:
        func (callable): The function to be decorated.

    Returns:
        callable: The decorated function with path validation.
    """

    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        # Bind the arguments to the function's signature to access their names and annotations
        sig = inspect.signature(func)
        bound_args = sig.bind(*args, **kwargs)
        bound_args.apply_defaults()

        # Loop through the bound arguments and check if any of them are of type XibifPath and if they exist
        for name, value in bound_args.arguments.items():
            if isinstance(value, XibifPath):
                if not value.exists():
                    raise XibifInvalidPathError(f"Path provided in argument '{name}' with value '{value}' does not exist.")

        return func(*args, **kwargs)

    return wrapper
