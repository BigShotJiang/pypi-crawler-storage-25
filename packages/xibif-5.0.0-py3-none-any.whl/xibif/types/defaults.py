"""Default configuration values for XiBIF."""

from typing import ClassVar
from pydantic.dataclasses import dataclass
from .utils import XibifPath


@dataclass(frozen=True)
class XibifDefaults:
    """Class to hold default values for various parameters used in XiBIF."""

    HW_FOLDER: ClassVar[XibifPath] = XibifPath("hw")
    REG_FOLDER: ClassVar[XibifPath] = HW_FOLDER.joinpath("regs")
    HDL_SRC_FOLDER: ClassVar[XibifPath] = HW_FOLDER.joinpath("src")
    HDL_TB_FOLDER: ClassVar[XibifPath] = HW_FOLDER.joinpath("tb")
    CONSTRAINT_FOLDER: ClassVar[XibifPath] = HW_FOLDER.joinpath("constraints")
    GIT_FOLDER: ClassVar[XibifPath] = XibifPath(".")
    VIVADO_FOLDER: ClassVar[XibifPath] = HW_FOLDER.joinpath("vivado")
    VITIS_FOLDER: ClassVar[XibifPath] = HW_FOLDER.joinpath("vitis")
    BLOCKDESIGN_NAME: ClassVar[str] = "xibif_bd"
    RESULTS_FOLDER: ClassVar[XibifPath] = HW_FOLDER.joinpath("results")
    APP_NAME: ClassVar[str] = "xibif"
    PLATFORM_NAME: ClassVar[str] = "xibif_platform"
    SIGASI_FOLDER: ClassVar[XibifPath] = XibifPath(".")
    SW_FOLDER: ClassVar[XibifPath] = XibifPath("sw")
    OPENLOGIC_FOLDER: ClassVar[XibifPath] = HW_FOLDER.joinpath("open-logic")
    SYNTHESIS_NAME: ClassVar[str] = ""  # Use the currently active run
    IMPLEMENTATION_NAME: ClassVar[str] = ""  # Use the currently active run
    BACKUP_FOLDER: ClassVar[XibifPath] = XibifPath("backup")
    REGEX_REGISTER_VALIDATION: ClassVar[str] = r"^[a-zA-Z][a-zA-Z0-9_]*$"
    REGEX_PATH_VALIDATION: ClassVar[str] = r"^[a-zA-Z0-9_\\\/\-\.:]+$"
    REGEX_PROJECT_NAME_VALIDATION: ClassVar[str] = r"^[\w\-]+$"
    PROJECT_NAME: ClassVar[str] = ".xibif"
    SIMULATION_HISTORY_FOLDER: ClassVar[XibifPath] = RESULTS_FOLDER.joinpath("test_history")
    SIMULATION_COVERAGE_FOLDER: ClassVar[XibifPath] = RESULTS_FOLDER.joinpath("coverage")
    SIMULATION_LIBRARY_FOLDER: ClassVar[XibifPath] = RESULTS_FOLDER.joinpath("libraries")
    SIMULATION_RUN_SCRIPT: ClassVar[XibifPath] = HDL_TB_FOLDER.joinpath("run.py")
    SIMULATION_XML_FILE: ClassVar[XibifPath] = RESULTS_FOLDER.joinpath("test_output.xml")
    SIMULATION_VUNIT_OUTPUT_FOLDER: ClassVar[XibifPath] = RESULTS_FOLDER.joinpath("vunit_out")
    PROJECT_PATH: ClassVar[XibifPath] = XibifPath(".")
    REGISTER_USER_CFG: ClassVar[XibifPath] = REG_FOLDER.joinpath("config-regs")
    REPORT_FOLDER: ClassVar[XibifPath] = XibifPath("reports")

    @classmethod
    def vivado_hardware_path(cls, project_name: str, results_folder: XibifPath = RESULTS_FOLDER) -> XibifPath:
        """Return the hardware export path (<project>.xsa).

        Args:
            project_name (str): The name of the project.
            results_folder (XibifPath, optional): The folder where the build results are located. Defaults to RESULTS_FOLDER.

        Returns:
            XibifPath: The path to the exported hardware file (.xsa).
        """
        return results_folder.joinpath(project_name).with_suffix(".xsa")

    @classmethod
    def vivado_bitstream_path(cls, project_name: str, results_folder: XibifPath = RESULTS_FOLDER) -> XibifPath:
        """Return the bitstream path (<project>.bit).

        Args:
            project_name (str): The name of the project.
            results_folder (XibifPath, optional): The folder where the build results are located. Defaults to RESULTS_FOLDER.

        Returns:
            XibifPath: The path to the generated bitstream file (.bit).
        """
        return results_folder.joinpath(project_name).with_suffix(".bit")

    @classmethod
    def vivado_ltx_path(cls, project_name: str, results_folder: XibifPath = RESULTS_FOLDER) -> XibifPath:
        """Return the probes file path (<project>.ltx).

        Args:
            project_name (str): The name of the project.
            results_folder (XibifPath, optional): The folder where the build results are located. Defaults to RESULTS_FOLDER.

        Returns:
            XibifPath: The path to the generated probes file (.ltx).
        """
        return results_folder.joinpath(project_name).with_suffix(".ltx")

    @classmethod
    def vivado_project_path(cls, project_name: str, vivado_folder: XibifPath = VIVADO_FOLDER) -> XibifPath:
        """Return the Vivado project path (<project>.xpr).

        Args:
            project_name (str): The name of the project.
            vivado_folder (XibifPath, optional): The folder where Vivado projects are stored. Defaults to VIVADO_FOLDER.

        Returns:
            XibifPath: The path to the Vivado project file (.xpr).
        """
        return vivado_folder.joinpath(project_name).with_suffix(".xpr")

    @classmethod
    def vivado_checkpoint_path(cls, checkpoint_name: str, results_folder: XibifPath = RESULTS_FOLDER) -> XibifPath:
        """Return the checkpoint path (<name>.dcp).

        Args:
            checkpoint_name (str): The name of the checkpoint.
            results_folder (XibifPath, optional): The folder where the build results are located. Defaults to RESULTS_FOLDER.

        Returns:
            XibifPath: The path to the checkpoint file (.dcp).
        """
        return results_folder.joinpath(checkpoint_name).with_suffix(".dcp")

    @classmethod
    def vitis_fsbl_path(cls, results_folder: XibifPath = RESULTS_FOLDER) -> XibifPath:
        """Return the exported FSBL path (fsbl.elf).

        Args:
            results_folder (XibifPath, optional): The folder where the build results are located. Defaults to RESULTS_FOLDER.

        Returns:
            XibifPath: The path to the exported FSBL ELF file (fsbl.elf).
        """
        return results_folder.joinpath("fsbl").with_suffix(".elf")

    @classmethod
    def vitis_app_elf_path(cls, app_name: str = APP_NAME, results_folder: XibifPath = RESULTS_FOLDER) -> XibifPath:
        """Return the exported application ELF path (<app>.elf).

        Args:
            app_name (str, optional): The name of the application. Defaults to APP_NAME.
            results_folder (XibifPath, optional): The folder where the build results are located. Defaults to RESULTS_FOLDER.

        Returns:
            XibifPath: The path to the exported application ELF file (<app>.elf).
        """
        return results_folder.joinpath(app_name).with_suffix(".elf")

    @classmethod
    def vitis_bootfile_path(cls, results_folder: XibifPath = RESULTS_FOLDER) -> XibifPath:
        """Return the generated BOOT file path (BOOT.BIN).

        Args:
            results_folder (XibifPath, optional): The folder where the build results are located. Defaults to RESULTS_FOLDER.

        Returns:
            XibifPath: The path to the generated BOOT file (BOOT.BIN).
        """
        return results_folder.joinpath("BOOT").with_suffix(".BIN")

    @classmethod
    def vitis_temp_project_path(cls, project_name: str, vitis_folder: XibifPath = VITIS_FOLDER) -> XibifPath:
        """Return the temporary Vitis project path (<project>.temp).

        Args:
            project_name (str): The name of the project.
            vitis_folder (XibifPath, optional): The folder where Vitis projects are stored. Defaults to VITIS_FOLDER.

        Returns:
            XibifPath: The path to the temporary Vitis project file (<project>.temp).
        """
        return vitis_folder.joinpath(project_name).with_suffix(".temp")

    @classmethod
    def vitis_lockfile_path(cls, vitis_folder: XibifPath = VITIS_FOLDER) -> XibifPath:
        """Return the Vitis workspace lockfile path (.lock).

        Args:
            vitis_folder (XibifPath, optional): The folder where Vitis projects are stored. Defaults to VITIS_FOLDER.

        Returns:
            XibifPath: The path to the Vitis workspace lockfile (.lock).
        """
        return vitis_folder.joinpath(".lock")

    @classmethod
    def vitis_settings_header_path(cls, app_name: str = APP_NAME, vitis_folder: XibifPath = VITIS_FOLDER) -> XibifPath:
        """Return the XiBIF settings header path in the Vitis app source folder.

        Args:
            app_name (str, optional): The name of the application. Defaults to APP_NAME.
            vitis_folder (XibifPath, optional): The folder where Vitis projects are stored. Defaults to VITIS_FOLDER.

        Returns:
            XibifPath: The path to the generated XiBIF settings header file in the Vitis app source folder.
        """
        return vitis_folder.joinpath(app_name, "src", "XiBIF_settings.h")

    @classmethod
    def vitis_src_folder_path(cls, app_name: str = APP_NAME, vitis_folder: XibifPath = VITIS_FOLDER) -> XibifPath:
        """Return the Vitis application source folder path.

        Args:
            app_name (str, optional): The name of the application. Defaults to APP_NAME.
            vitis_folder (XibifPath, optional): The folder where Vitis projects are stored. Defaults to VITIS_FOLDER.

        Returns:
            XibifPath: The path to the Vitis application source folder.
        """
        return vitis_folder.joinpath(app_name, "src")

    @classmethod
    def register_user_vhdl_path(cls, src_folder: XibifPath = HDL_SRC_FOLDER) -> XibifPath:
        """Return the generated user register VHDL path.

        Args:
            src_folder (XibifPath, optional): The folder where VHDL source files are stored. Defaults to HDL_SRC_FOLDER.

        Returns:
            XibifPath: The path to the generated user register VHDL file.
        """
        return src_folder.joinpath("XiBIF_regs.vhd")

    @classmethod
    def register_user_header_path(cls, app_name: str = APP_NAME, vitis_folder: XibifPath = VITIS_FOLDER) -> XibifPath:
        """Return the generated user register C header path.

        Args:
            app_name (str, optional): The name of the application. Defaults to APP_NAME.
            vitis_folder (XibifPath, optional): The folder where Vitis projects are stored. Defaults to VITIS_FOLDER.

        Returns:
            XibifPath: The path to the generated user register C header file in the Vitis app source folder.
        """
        return vitis_folder.joinpath(app_name, "src", "XiBIF_regs.h")

    @classmethod
    def register_stream_vhdl_path(cls, src_folder: XibifPath = HDL_SRC_FOLDER) -> XibifPath:
        """Return the generated stream register VHDL path.

        Args:
            src_folder (XibifPath, optional): The folder where VHDL source files are stored. Defaults to HDL_SRC_FOLDER.

        Returns:
            XibifPath: The path to the generated stream register VHDL file.
        """
        return src_folder.joinpath("XiBIF_stream_regs.vhd")

    @classmethod
    def register_stream_package_path(cls, tb_folder: XibifPath = HDL_TB_FOLDER) -> XibifPath:
        """Return the generated stream testbench package path.

        Args:
            tb_folder (XibifPath, optional): The folder where testbench files are stored. Defaults to HDL_TB_FOLDER.

        Returns:
            XibifPath: The path to the generated stream testbench package VHDL file.
        """
        return tb_folder.joinpath("tb_stream_regs_package.vhd")

    @classmethod
    def register_stream_header_path(cls, app_name: str = APP_NAME, vitis_folder: XibifPath = VITIS_FOLDER) -> XibifPath:
        """Return the generated stream register C header path.

        Args:
            app_name (str, optional): The name of the application. Defaults to APP_NAME.
            vitis_folder (XibifPath, optional): The folder where Vitis projects are stored. Defaults to VITIS_FOLDER.

        Returns:
            XibifPath: The path to the generated stream register C header file in the Vitis app source folder.
        """
        return vitis_folder.joinpath(app_name, "src", "XiBIF_stream_regs.h")

    @classmethod
    def openlogic_import_script_path(cls, openlogic_folder: XibifPath = OPENLOGIC_FOLDER) -> XibifPath:
        """Return the OpenLogic Vivado import script path.

        Args:
            openlogic_folder (XibifPath, optional): The folder where the OpenLogic repository is located. Defaults to OPENLOGIC_FOLDER.

        Returns:
            XibifPath: The path to the OpenLogic Vivado import script.
        """
        return openlogic_folder.joinpath("tools/vivado/import_sources.tcl")
