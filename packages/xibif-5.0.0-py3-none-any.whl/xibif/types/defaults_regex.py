"""Default regular expressions for validation in XiBIF."""

from typing import ClassVar
from pydantic.dataclasses import dataclass


@dataclass(frozen=True)
class XibifDefaultsRegex:
    """Class to hold default regular expressions for validation in XiBIF."""

    REGISTER_NAME: ClassVar[str] = r"^[a-zA-Z][a-zA-Z0-9_]*$"
    PATH: ClassVar[str] = r"^[a-zA-Z0-9_\\\/\-\.:~]+$"
    PROJECT_NAME: ClassVar[str] = r"^[\w\-]*$"
