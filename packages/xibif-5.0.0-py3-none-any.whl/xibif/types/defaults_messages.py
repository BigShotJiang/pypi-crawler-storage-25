"""Default messages for XiBIF prompts and warnings."""

from typing import ClassVar
from pydantic.dataclasses import dataclass
from .messages import XibifMessage


@dataclass(frozen=True)
class XibifDefaultsMessages:
    """Class to hold default messages for various prompts and warnings in XiBIF."""

    WARNING_MESSAGE_BUILD_VITIS_2024_1: ClassVar[XibifMessage] = XibifMessage(
        title="Vitis 2024.1 Build Warning",
        message=[
            "A bug exists in the Vitis 2024.1 API that misconfigures settings for the FreeRTOS and IP software running on the ARM core! The first build of the project will yield the desired results; all further builds will complete but be ill-configured, rendering your design useless. To alleviate this problem, open the Vitis workspace in Vitis 2024.1 and adjust the corresponding settings.",
            "",
            "Select the *_platform and the 'Settings' on the left side, and then 'vitis-comp.json'. In the middle window, select 'freertos_*'. Step through every item you can find in the dropdown. In 'freertos/lwip220' you will find that the second item has value 'SOCKET_API'. Note the quotes. For each value that has these quotes, you must remove them manually. After removing all the quotes from ALL sub-categories of the 'Board Support Package', save the project and close. You won't have to do it again.",
            "",
            "If you do not do this, your project WILL not work!",
            "",
            "You can disable this warning by specifying the --nowarn flag when building.",
        ],
    )

    WARNING_MESSAGE_MOVED_VITIS: ClassVar[XibifMessage] = XibifMessage(
        title="Vitis Workspace Moved Warning",
        message=[
            "XiBIF detected that you moved the workspace folder into a new location.",
            "",
            "This is a problem because Vitis likes to hardcode paths in the workspace. If you move the workspace, it is likely that the workspace will not work anymore.",
            "",
            "Why does it break you might ask? Well, only the Xilinx developers know. But looks like they never heard of relative paths.",
            "",
            "XiBIF can try to regenerate the workspace for you. But this is not guaranteed to work. Note, that this will reset all your settings in the workspace.",
            "",
            "You can disable this warning by specifying the --nowarn flag when building.",
        ],
    )

    WARNING_MESSAGE_SETUP_VITIS: ClassVar[XibifMessage] = XibifMessage(
        title="Vitis Platform Setup Warning",
        message=[
            "Note from Xibif: Running the create platform again in case the first one failed randomly providing a different error each time it fails.",
            "If the following command fails with a message stating that the platform already exists, this can be safely ignored.",
            "Fun Fact: It is also not possible to check if the platform has been created, as the command get_component returns a valid object even if the platform has not been created.",
        ],
    )
