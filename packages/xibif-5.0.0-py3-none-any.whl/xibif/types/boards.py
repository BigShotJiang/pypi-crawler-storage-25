"""Board type definitions for supported XiBIF FPGA targets."""

from enum import StrEnum


class XilinxBoard(StrEnum):
    """Enumeration of supported FPGA boards for XiBIF projects."""

    ZYBOZ710 = "zyboz710"
    ZYBOZ720 = "zyboz720"
    ZEDBOARD = "zedboard"
    ZCU102 = "zcu102"
    ZCU104 = "zcu104"
    KV260 = "kv260"
