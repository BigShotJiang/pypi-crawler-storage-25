"""Message display types for XiBIF user interaction."""

from typing import ClassVar
from pydantic import ConfigDict, validate_call
from colorama import Fore
from ..logger.logger_stages import LoggerStage as LS
from ..logger.models import LoggerVerbosity
from ..logger.utils import xibif_print, stop_periodic_logger, start_periodic_logger


class XibifMessage:
    """Class to display a formatted warning message with ASCII art and prompt the user for confirmation."""

    __WIDTH: ClassVar[int] = 80
    __HEADER_CHAR: ClassVar[str] = "="
    __title: str = ""
    __message: str | list[str] = ""

    @validate_call(config=ConfigDict(strict=True))
    def __init__(self, title: str, message: str | list[str]) -> None:
        """Initialize the message with a title and message body.

        Args:
            title (str): The title shown in the header bar.
            message (str | list[str]): The message body to display.
        """
        self.__title = title

        # Generate the message list if a single string is provided
        if isinstance(message, str):
            message = [message]

        # Split the message at newlines and flatten the list
        message = [line for msg in message for line in msg.split("\n")]

        # Split the message at whitespace to ensure no line exceeds the configured width
        message = self._split_at_whitespace(message, self.__WIDTH)

        # Pad message with empty lines to ensure a minimum of 3 lines (so the total with header >= 6)
        if len(message) < 3:
            message += [""] * (3 - len(message))

        # Store the processed message
        self.__message = message

    def __str__(self) -> str:
        """Return the formatted message with ASCII art and header as a string.

        Returns:
            str: The complete formatted message.
        """
        # Generate header
        left_padding = 1
        right_padding = self.__WIDTH - len(self.__title) - 3
        border = f"{self.__HEADER_CHAR}" * self.__WIDTH
        middle = f"{self.__HEADER_CHAR}{' ' * left_padding}{self.__title}{' ' * right_padding}{self.__HEADER_CHAR}"
        middle = middle.replace('"', '\\"')

        # Generate ASCII art scaled to fit the message (3 lines for header + message lines)
        ascii_art = self._generate_ascii_art(3 + len(self.__message))
        max_length = max(len(line) for line in ascii_art)

        # Combine ascii art with header and message
        combined_lines = []
        combined_lines.append(ascii_art[0].ljust(max_length) + border)
        combined_lines.append(ascii_art[1].ljust(max_length) + middle)
        combined_lines.append(ascii_art[2].ljust(max_length) + border)
        for line, message_line in zip(ascii_art[3:], self.__message):
            combined_lines.append(line.ljust(max_length) + message_line)

        return "\n".join(combined_lines)

    @validate_call(config=ConfigDict(strict=True))
    def ask(self, ask: str) -> bool:
        """Display a formatted warning message with ASCII art and prompt the user for a yes/no answer.

        Args:
            ask (str): The question to prompt the user with.

        Returns:
            bool: True if the user answered yes, False if no.
        """
        # Stop logger
        stop_periodic_logger()

        # Print the combined message
        for line in str(self).split("\n"):
            xibif_print(line, verbosity=LoggerVerbosity.WARNING, stage=LS.NO_CHANGE, force_print=True, color=Fore.YELLOW)

        # Print an empty line
        xibif_print("", verbosity=LoggerVerbosity.WARNING, stage=LS.NO_CHANGE, force_print=True, color=Fore.YELLOW)

        while True:
            xibif_print(f"{ask} [y/n]", verbosity=LoggerVerbosity.WARNING, stage=LS.NO_CHANGE, force_print=True, color=Fore.YELLOW)
            answer = input("")
            if answer.lower() in ["yes", "y"]:
                start_periodic_logger()
                return True
            elif answer.lower() in ["no", "n"]:
                start_periodic_logger()
                return False
            else:
                xibif_print("Please provide a valid answer! [y/n]", verbosity=LoggerVerbosity.WARNING, stage=LS.NO_CHANGE, force_print=True, color=Fore.YELLOW)

    @staticmethod
    @validate_call(config=ConfigDict(strict=True))
    def _generate_ascii_art(height: int) -> list[str]:
        """Generate stacked warning-triangle ASCII art to fill the given height.

        Triangle size is dynamic with a minimum of 6 lines and a maximum of 12.
        If the uncapped triangle size would exceed 12, empty separator lines are
        inserted between stacked triangles.

        Args:
            height (int): The desired number of lines (minimum 6).

        Returns:
            list[str]: The generated ASCII art lines, uniformly padded.
        """
        min_size = 6
        max_size = 12
        height = max(height, min_size)

        # Find the smallest triangle size >= min_size that evenly divides the height
        tri_size = min_size
        while height % tri_size != 0:
            tri_size += 1

        capped = tri_size > max_size
        if capped:
            # Keep triangles compact (<= max_size) and spread remaining lines as
            # empty separators between triangles.
            for candidate in range(max_size, min_size - 1, -1):
                triangle_count = (height + 1) // (candidate + 1)
                if triangle_count >= 2:
                    tri_size = candidate
                    break
            else:
                tri_size = min_size
                triangle_count = 1
        else:
            triangle_count = height // tri_size

        # Build one triangle of the chosen size
        triangle = []
        for i in range(tri_size):
            left_spaces = tri_size - i - 1
            inner = 2 * i

            if i == 0:
                core = "/\\"
            elif i == tri_size - 1:
                core = "/" + "-" * inner + "\\"
            elif i == tri_size - 2:
                core = "/" + "()".center(inner) + "\\"
            elif i in (1, tri_size - 3):
                core = "/" + " " * inner + "\\"
            else:
                core = "/" + "||".center(inner) + "\\"

            triangle.append("> " + " " * left_spaces + core)

        if not capped:
            lines = triangle * triangle_count
        else:
            total_gap_lines = height - (triangle_count * tri_size)
            gap_slots = triangle_count - 1
            base_gap = total_gap_lines // gap_slots
            extra_gap = total_gap_lines % gap_slots

            lines = []
            for idx in range(triangle_count):
                lines.extend(triangle)
                if idx < gap_slots:
                    # Spread remainder gaps uniformly across all separator slots.
                    distributed_extra = ((idx + 1) * extra_gap) // gap_slots - (idx * extra_gap) // gap_slots
                    gap_count = base_gap + distributed_extra
                    lines.extend(["> "] * gap_count)

        # Pad all lines to uniform width
        max_len = max(len(line) for line in lines)
        return [line.ljust(max_len + 1) for line in lines]

    @staticmethod
    @validate_call(config=ConfigDict(strict=True))
    def _split_at_whitespace(text: list[str], width: int) -> list[str]:
        """Split a list of strings at whitespace to ensure no line exceeds the configured width.

        Args:
            text (list[str]): The list of strings to split.
            width (int): The maximum allowed width of each line.

        Returns:
            list[str]: The list of strings split at whitespace boundaries.
        """
        result = []
        for line in text:
            while len(line) > width:
                split_pos = line.rfind(" ", 0, width)
                if split_pos == -1:
                    split_pos = width
                result.append(line[:split_pos].strip())
                line = line[split_pos:].strip()
            result.append(line)
        return result
