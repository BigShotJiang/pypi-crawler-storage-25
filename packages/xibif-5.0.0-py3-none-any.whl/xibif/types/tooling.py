"""Types and enumerations for tooling configuration."""

from enum import StrEnum
from pydantic import ConfigDict, validate_call
from pydantic.dataclasses import dataclass
from .utils import XibifPath


class XilinxVersion(StrEnum):
    """Enumeration of supported Xilinx versions for XiBIF projects."""

    V2023_1 = "2023.1"
    V2023_2 = "2023.2"
    V2024_1 = "2024.1"
    V2024_2 = "2024.2"
    V2025_1 = "2025.1"
    V2025_2 = "2025.2"


class VunitSimulator(StrEnum):
    """Enumeration of supported VUnit simulators for testbench generation."""

    MODELSIM = "modelsim"
    GHDL = "ghdl"
    NVC = "nvc"


class XibifStartTool(StrEnum):
    """Enumeration of supported tools to start when running the 'start' command."""

    VIVADO = "vivado"
    VITIS = "vitis"
    HARDWARE_SERVER = "hw_server"


@dataclass(config=ConfigDict(validate_assignment=True))
class XilinxToolPath:
    """Data class to store paths to Xilinx tools."""

    vivado: XibifPath | None = None
    vitis: XibifPath | None = None
    xsct: XibifPath | None = None
    cs_server: XibifPath | None = None
    hw_server: XibifPath | None = None
    settings64_script: XibifPath | None = None

    @validate_call(config=ConfigDict(strict=True))
    def items(self) -> tuple[str, XibifPath | None]:
        """Return an iterator of tool names and their corresponding paths.

        Returns:
            tuple[str, XibifPath | None]: An iterator of (tool_name, tool_path) pairs.
        """
        return ((f.name, getattr(self, f.name)) for f in self.__dataclass_fields__.values())  # pylint: disable=no-member

    @validate_call(config=ConfigDict(strict=True))
    def __getitem__(self, key: str) -> XibifPath | None:
        """Get a tool path by name using dict-style access.

        Args:
            key (str): The name of the tool to retrieve.

        Returns:
            XibifPath | None: The path to the requested tool, or None if not set.
        """
        return getattr(self, key)

    @validate_call(config=ConfigDict(strict=True))
    def __setitem__(self, key: str, value: XibifPath | None) -> None:
        """Set a tool path by name using dict-style access.

        Args:
            key (str): The name of the tool to set.
            value (XibifPath | None): The path to the tool to set.
        """
        setattr(self, key, value)
