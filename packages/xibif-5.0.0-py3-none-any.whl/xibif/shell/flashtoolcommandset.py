"""Abstract command set interface for flash tooling."""

from abc import abstractmethod
from .commandset import CommandSet


class FlashToolCommandSet(CommandSet):
    """Defines abstract flash-related commands."""

    @abstractmethod
    def disconnect(self, **kwargs) -> list[str] | str:
        """Disconnects from the hardware server in the shell environment."""

    @abstractmethod
    def connect_hwserver(self, **kwargs) -> list[str] | str:
        """Connects to the hardware server in the shell environment."""

    @abstractmethod
    def flash(self, **kwargs) -> list[str] | str:
        """Flashes the FPGA design onto the target hardware in the shell environment."""
