"""Abstract command set interface for processor-system tooling."""

import re
from abc import abstractmethod
from pydantic import ConfigDict, validate_call
from ..types import XibifPath, XilinxBoard
from .commandset import CommandSet


class PsToolCommandSet(CommandSet):
    """Defines abstract PS command operations and shared helpers."""

    @abstractmethod
    def set_workspace(self, **kwargs) -> list[str] | str:
        """Sets the current workspace in the shell environment."""

    @abstractmethod
    def create_workspace(self, **kwargs) -> list[str] | str:
        """Creates a new workspace in the shell environment."""

    @abstractmethod
    def create_platform(self, **kwargs) -> list[str] | str:
        """Creates a new platform in the shell environment."""

    @abstractmethod
    def set_active_platform(self, **kwargs) -> list[str] | str:
        """Sets the active platform in the shell environment."""

    @abstractmethod
    def create_domain(self, **kwargs) -> list[str] | str:
        """Creates a new domain in the shell environment."""

    @abstractmethod
    def set_active_domain(self, **kwargs) -> list[str] | str:
        """Sets the active domain in the shell environment."""

    @abstractmethod
    def create_application(self, **kwargs) -> list[str] | str:
        """Creates a new application in the shell environment."""

    @abstractmethod
    def set_active_application(self, **kwargs) -> list[str] | str:
        """Sets the active application in the shell environment."""

    @abstractmethod
    def add_file(self, **kwargs) -> list[str] | str:
        """Adds a file to the current application in the shell environment."""

    @abstractmethod
    def generate_platform(self, **kwargs) -> list[str] | str:
        """Generates the platform in the shell environment."""

    @abstractmethod
    def set_application_config(self, **kwargs) -> list[str] | str:
        """Sets the application configuration in the shell environment."""

    @abstractmethod
    def add_linker_script(self, **kwargs) -> list[str] | str:
        """Adds a linker script to the current application in the shell environment."""

    @abstractmethod
    def config_domain(self, **kwargs) -> list[str] | str:
        """Configs the domain in the shell environment."""

    @abstractmethod
    def update_platform(self, **kwargs) -> list[str] | str:
        """Updates the platform in the shell environment."""

    @abstractmethod
    def generate_application(self, **kwargs) -> list[str] | str:
        """Generates the application in the shell environment."""

    @abstractmethod
    def get_elf_path(self, **kwargs) -> list[str] | str:
        """Gets the path to the generated ELF file for the current application in the shell environment."""

    @abstractmethod
    def clean_application(self, **kwargs) -> list[str] | str:
        """Cleans the current application in the shell environment."""

    @abstractmethod
    def generate_bootfile(self, **kwargs) -> list[str] | str:
        """Generates a boot file (e.g., BIF) for the current application in the shell environment."""

    @abstractmethod
    def copy_application(self, **kwargs) -> list[str] | str:
        """Copies the current application to a specified location in the shell environment."""

    @classmethod
    @validate_call(config=ConfigDict(strict=True))
    def shorten_name(cls, name: str) -> str:
        """Shorten generated component names for improved readability.

        Args:
            name (str): The original name to be shortened.

        Returns:
            str: The shortened name.
        """
        name = name.replace("_platform", "_pf").replace("_system", "_sys")
        name = re.sub(r"(?<!^)[aeiou_](?!([A-Z]|$))", "", name)
        return name

    @classmethod
    @validate_call(config=ConfigDict(strict=True))
    def generate_bif(cls, bif_path: XibifPath, board: XilinxBoard, fsbl_path: XibifPath, bitstream_path: XibifPath, elf_path: XibifPath) -> None:
        """
        Generates a Boot Image File (BIF) for the given parameters.

        Args:
            bif_path (XibifPath): The path to save the BIF file.
            board (XilinxBoard): The name of the board.
            fsbl_path (XibifPath): The path to the FSBL file.
            bitstream_path (XibifPath): The path to the bitstream file.
            elf_path (XibifPath): The path to the ELF file.
        """
        with open(bif_path, "w") as f:
            if board in [XilinxBoard.ZYBOZ710, XilinxBoard.ZYBOZ720, XilinxBoard.ZEDBOARD]:
                f.write("//arch = zynq; split = false; format = BIN\n")
                f.write("the_ROM_image:\n")
                f.write("{\n")
                f.write(f"\t[bootloader]{fsbl_path.as_tcl()}\n")
                f.write(f"\t{bitstream_path.as_tcl()}\n")
                f.write(f"\t{elf_path.as_tcl()}\n")
                f.write("}\n")
            else:
                f.write("//arch = zynqmp; split = false; format = BIN\n")
                f.write("the_ROM_image:\n")
                f.write("{\n")
                f.write(f"\t[bootloader, destination_cpu=a53-0] {fsbl_path.as_tcl()}\n")
                f.write(f"\t[destination_device=pl] {bitstream_path.as_tcl()}\n")
                f.write(f"\t[destination_cpu=a53-0, exception_level=el-3] {elf_path.as_tcl()}\n")
                f.write("}\n")
