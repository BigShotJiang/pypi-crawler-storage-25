"""Factory class to create CommandSet instances based on tool and version."""

from pydantic import ConfigDict, validate_call
from .tools.vivado import commands as VivadoCommands
from .tools.vitis import commands as VitisCommands
from .tools.vitis_flash import commands as VitisFlashCommands
from .tools.python import commands as PythonCommands
from ..types import XilinxVersion, XibifRuntimeError
from .models import ShellTool
from .commandset import CommandSet


class CommandSetFactory:
    """Factory class to create CommandSet instances based on tool and version."""

    @staticmethod
    @validate_call(config=ConfigDict(strict=True))
    def get_command_set(tool: ShellTool, version: XilinxVersion | None = None) -> CommandSet:
        """Factory method to get the appropriate CommandSet instance based on the specified tool and version.

        Args:
            tool (ShellTool): The name of the shell tool to get the command set for (e.g., VIVADO, VITIS, PYTHON).
            version (XilinxVersion | None): The Xilinx version to determine the appropriate command set variant. Optional for tools that do not have version-specific command sets.

        Returns:
            CommandSet: An instance of the appropriate CommandSet subclass based on the tool and version.

        Raises:
            XibifRuntimeError: If no command set is defined for the given tool and version combination.
        """
        shell_mapping = {
            ShellTool.VIVADO: {
                XilinxVersion.V2023_1: VivadoCommands.v2023_1,
                XilinxVersion.V2023_2: VivadoCommands.v2023_2,
                XilinxVersion.V2024_1: VivadoCommands.v2024_1,
                XilinxVersion.V2024_2: VivadoCommands.v2024_2,
                XilinxVersion.V2025_1: VivadoCommands.v2025_1,
                XilinxVersion.V2025_2: VivadoCommands.v2025_2,
            },
            ShellTool.VITIS: {
                XilinxVersion.V2023_1: VitisCommands.v2023_1,
                XilinxVersion.V2023_2: VitisCommands.v2023_2,
                XilinxVersion.V2024_1: VitisCommands.v2024_1,
                XilinxVersion.V2024_2: VitisCommands.v2024_2,
                XilinxVersion.V2025_1: VitisCommands.v2025_1,
                XilinxVersion.V2025_2: VitisCommands.v2025_2,
            },
            ShellTool.VITIS_FLASH: {
                XilinxVersion.V2023_1: VitisFlashCommands.v2023_1,
                XilinxVersion.V2023_2: VitisFlashCommands.v2023_2,
                XilinxVersion.V2024_1: VitisFlashCommands.v2024_1,
                XilinxVersion.V2024_2: VitisFlashCommands.v2024_2,
                XilinxVersion.V2025_1: VitisFlashCommands.v2025_1,
                XilinxVersion.V2025_2: VitisFlashCommands.v2025_2,
            },
            ShellTool.PYTHON: PythonCommands.python,
        }

        try:
            if version is not None:
                return shell_mapping[tool][version]()
            else:
                if isinstance(shell_mapping[tool], dict):
                    raise XibifRuntimeError(f"No shell defined for {tool} version {version}")
                return shell_mapping[tool]()
        except KeyError as e:
            raise XibifRuntimeError(f"No shell defined for {tool} version {version}") from e
