"""Common base abstractions for shell command sets."""

from abc import ABC, abstractmethod
from pydantic import ConfigDict, validate_call
from .models import ShellHeaderAlignment


class CommandSet(ABC):
    """Base class that defines the shared command-set interface."""

    @staticmethod
    @abstractmethod
    def print_to_console(s: str) -> None:  # pragma: no cover
        """Prints a string to the console in the shell environment. This method should be implemented by subclasses to handle tool-specific console output.

        Args:
            s (str): The string to print to the console.
        """

    @classmethod
    @validate_call(config=ConfigDict(strict=True))
    def print_header(cls, title: str, width: int = 80, align: ShellHeaderAlignment = ShellHeaderAlignment.LEFT, header_char: str = "=") -> list[str]:
        """
        Prints a formatted header with a title, surrounded by rows of '=' characters.

        Args:
            title (str): The title to display in the header.
            width (int): The total width of the header, including the title and surrounding characters. Default is 80.
            align (ShellHeaderAlignment): The alignment of the title within the header. Default is ShellHeaderAlignment.LEFT.
            header_char (str): The character to use for the header border. Default is '='.

        Returns:
            list[str]: A list of strings representing the lines of the formatted header.
        """
        if width < len(title) + 4:
            width = len(title) + 5

        border = f"{header_char}" * width

        if align == ShellHeaderAlignment.LEFT:
            left_padding = 1
            right_padding = width - len(title) - 3
        elif align == ShellHeaderAlignment.CENTER:
            left_padding = (width - len(title) - 2) // 2
            right_padding = width - len(title) - 2 - left_padding
        else:  # align == ShellHeaderAlignment.RIGHT
            left_padding = width - len(title) - 3
            right_padding = 1

        title = title.replace('"', "")
        middle = f"{header_char}{' ' * left_padding}{title}{' ' * right_padding}{header_char}"
        return [
            cls.print_to_console(border),
            cls.print_to_console(middle),
            cls.print_to_console(border),
        ]
