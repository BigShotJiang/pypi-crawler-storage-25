"""Utility functions for shell operations, such as string filtering and searching."""

import re
from pydantic import ConfigDict, validate_call


@validate_call(config=ConfigDict(strict=True))
def filter_string(string: str, filter_list: list[str]) -> str:
    """Filter a string by removing all occurrences of the strings in the filter list.

    Args:
        string (str): The string to filter.
        filter_list (list[str]): A list of strings to remove from the input string.

    Returns:
        str: The filtered string with all occurrences of the filter list items removed.
    """
    for filter_pattern in filter_list:
        string = re.sub(filter_pattern, "", string)
    return string


@validate_call(config=ConfigDict(strict=True))
def search_string(string: str, filter_list: list[str]) -> tuple[int, str] | tuple[None, None]:
    """Search a string for any pattern in the filter list. Returns the index of the first matching pattern and the matched string, or None if no match is found.

    Args:
        string (str): The string to search.
        filter_list (list[str]): A list of regex patterns to search for in the input string.

    Returns:
        tuple[int, str] | tuple[None, None]: A tuple containing the index of the first matching pattern and the matched string, or (None, None) if no match is found.
    """
    for index, pattern in enumerate(filter_list):
        if re.match(pattern, string):
            return (index, string)

    return (None, None)
