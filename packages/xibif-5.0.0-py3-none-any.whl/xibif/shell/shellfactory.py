"""Factory class to create shell instances based on tool and version."""

from pydantic import ConfigDict, validate_call
from .shell import Shell
from .tools.vivado import shell as VivadoShell
from .tools.vitis import shell as VitisShell
from .tools.vitis_flash import shell as VitisFlashShell
from .tools.python import shell as PythonShell
from ..types import XilinxVersion, XibifPath, XibifRuntimeError
from .models import ShellTool


class ShellFactory:
    """Factory class to create shell instances based on tool and version."""

    @staticmethod
    @validate_call(config=ConfigDict(strict=True))
    def create_shell(tool_name: ShellTool, version: XilinxVersion | None = None, executable: XibifPath = None, interpreter: str = None, precommand: str = None) -> Shell:
        """Factory method to create a shell instance based on the specified tool and version.

        Args:
            tool_name (ShellTool): The name of the shell tool to create (e.g., VIVADO, VITIS, PYTHON).
            version (XilinxVersion | None): The Xilinx version to determine the appropriate shell variant. Optional for tools that do not have version-specific shells.
            executable (XibifPath): The path to the shell executable. Optional, as some shells may use a default executable.
            interpreter (str): The command to invoke the interpreter for this shell, if applicable. Optional.
            precommand (str): An optional command to run before starting the shell, such as setting up environment variables.

        Returns:
            Shell: An instance of the appropriate Shell subclass based on the tool and version.

        Raises:
            XibifRuntimeError: If no shell is defined for the given tool and version combination.
        """
        # Map tools and versions to shells
        shell_mapping = {
            ShellTool.VIVADO: {
                XilinxVersion.V2023_1: VivadoShell.tcl,
                XilinxVersion.V2023_2: VivadoShell.tcl,
                XilinxVersion.V2024_1: VivadoShell.tcl,
                XilinxVersion.V2024_2: VivadoShell.tcl,
                XilinxVersion.V2025_1: VivadoShell.tcl,
                XilinxVersion.V2025_2: VivadoShell.tcl,
            },
            ShellTool.VITIS: {
                XilinxVersion.V2023_1: VitisShell.tcl,
                XilinxVersion.V2023_2: VitisShell.tcl,
                XilinxVersion.V2024_1: VitisShell.python,
                XilinxVersion.V2024_2: VitisShell.python,
                XilinxVersion.V2025_1: VitisShell.python,
                XilinxVersion.V2025_2: VitisShell.python,
            },
            ShellTool.VITIS_FLASH: {
                XilinxVersion.V2023_1: VitisFlashShell.tcl,
                XilinxVersion.V2023_2: VitisFlashShell.tcl,
                XilinxVersion.V2024_1: VitisFlashShell.tcl,
                XilinxVersion.V2024_2: VitisFlashShell.tcl,
                XilinxVersion.V2025_1: VitisFlashShell.tcl,
                XilinxVersion.V2025_2: VitisFlashShell.tcl,
            },
            ShellTool.PYTHON: PythonShell.python,
        }

        try:
            if version is not None:
                return shell_mapping[tool_name][version](executable=executable, name=tool_name.name, interpreter=interpreter, precommand=precommand)
            else:
                if isinstance(shell_mapping[tool_name], dict):
                    raise XibifRuntimeError(f"No shell defined for {tool_name.name} and version None")
                return shell_mapping[tool_name](executable=executable, name=tool_name.name, interpreter=interpreter, precommand=precommand)
        except KeyError as e:
            raise XibifRuntimeError(f"No shell defined for {tool_name.name} and version {version.name}") from e
