"""Abstract command set interface for FPGA tooling."""

from abc import abstractmethod
from .commandset import CommandSet


class FpgaToolCommandSet(CommandSet):
    """Defines abstract FPGA command operations."""

    @abstractmethod
    def implement(self, **kwargs) -> list[str] | str:
        """Implements the FPGA design in the shell environment."""

    @abstractmethod
    def synthesize(self, **kwargs) -> list[str] | str:
        """Synthesizes the FPGA design in the shell environment."""

    @abstractmethod
    def generate_bitstream(self, **kwargs) -> list[str] | str:
        """Generates the bitstream for the FPGA design in the shell environment."""

    @abstractmethod
    def write_bitstream(self, **kwargs) -> list[str] | str:
        """Writes the generated bitstream to a file in the shell environment."""

    @abstractmethod
    def report_all(self, **kwargs) -> list[str] | str:
        """Generates all available reports for the FPGA design in the shell environment."""

    @abstractmethod
    def write_checkpoint(self, **kwargs) -> list[str] | str:
        """Writes a checkpoint file for the FPGA design in the shell environment."""

    @abstractmethod
    def add_design_file(self, **kwargs) -> list[str] | str:
        """Adds a design file to the current FPGA project in the shell environment."""

    @abstractmethod
    def add_simulation_file(self, **kwargs) -> list[str] | str:
        """Adds a simulation file to the current FPGA project in the shell environment."""

    @abstractmethod
    def add_constraint_file(self, **kwargs) -> list[str] | str:
        """Adds a constraint file to the current FPGA project in the shell environment."""

    @abstractmethod
    def remove_design_file(self, **kwargs) -> list[str] | str:
        """Removes a design file from the current FPGA project in the shell environment."""

    @abstractmethod
    def remove_simulation_file(self, **kwargs) -> list[str] | str:
        """Removes a simulation file from the current FPGA project in the shell environment."""

    @abstractmethod
    def remove_constraint_file(self, **kwargs) -> list[str] | str:
        """Removes a constraint file from the current FPGA project in the shell environment."""

    @abstractmethod
    def report_timing_run(self, **kwargs) -> list[str] | str:
        """Generates a timing report for the current FPGA design in the shell environment."""
