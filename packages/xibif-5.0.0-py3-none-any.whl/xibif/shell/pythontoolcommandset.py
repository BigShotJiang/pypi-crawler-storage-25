"""Abstract command set interface for Python tooling."""

from abc import abstractmethod
from ..types import XibifPath
from .commandset import CommandSet


class PythonToolCommandSet(CommandSet):
    """Defines abstract Python command operations."""

    @staticmethod
    @abstractmethod
    def run_file(file: XibifPath) -> list[str] | str:
        """Runs a Python file in the shell environment.

        Args:
            file (XibifPath): The Python file to execute.
        """

    @staticmethod
    @abstractmethod
    def change_directory(directory: XibifPath) -> list[str] | str:
        """Changes the current working directory in the shell environment.

        Args:
            directory (XibifPath): The target directory to change to.
        """
