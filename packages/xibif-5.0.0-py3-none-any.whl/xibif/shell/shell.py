"""Abstract base class and shared infrastructure for interactive tool shell wrappers."""

from __future__ import annotations
from abc import ABC, abstractmethod
import subprocess
import queue
import threading
import platform
from types import TracebackType
from colorama import Fore
from pydantic import ConfigDict, validate_call
from ..logger import LoggerStage as LS, xibif_print_error, xibif_print_debug, xibif_print_warning, xibif_print, LoggerVerbosity
from ..types import XibifPath, XibifValidationError
from .utils import filter_string, search_string


class Shell(ABC):
    """Abstract base class for interactive shell wrappers.

    Provides a common interface and threading infrastructure for launching, communicating with,
    and terminating interactive tool shells (e.g. Vivado, Vitis). Concrete subclasses must
    implement the abstract properties that define shell-specific startup arguments, ready
    signals, and open/close commands.
    """

    @validate_call(config=ConfigDict(strict=True, arbitrary_types_allowed=True))
    def send(self, command: str) -> None:
        """Send a command to the shell process via stdin.

        Args:
            command (str): The command string to send to the shell.
        """
        if self.process and self.process.stdin:
            xibif_print_debug("Execute Command: " + command, stage=self.__logger_stage, prefix=self._stdout_shell_text)
            self.process.stdin.write(f"{command}\n")
            self.process.stdin.flush()

    @validate_call(config=ConfigDict(strict=True))
    def __init__(self, executable: XibifPath, name: str, interpreter: str | None = None, precommand: str | None = None, quiet: bool = False) -> None:
        """Initialize the Shell with the given executable, name, and options.

        Args:
            executable (XibifPath): The path to the shell executable.
            name (str): The name of the shell, used for logging purposes.
            interpreter (str | None): An optional interpreter to use for launching the shell. Default is None.
            precommand (str | None): An optional pre-command to prepend before launching the shell. Default is None.
            quiet (bool): Whether to suppress output from the shell. Default is False.
        """
        self.executable = executable.as_windows() if platform.system() == "Windows" else executable
        self.interpreter = interpreter
        self.precommand = precommand
        self.name = name
        self.process = None
        self.quiet = quiet
        self.output_queue = queue.Queue()
        self.error_queue = queue.Queue()
        self.__logger_stage = LS.NO_CHANGE
        self.__downgrade_errors = False
        self.__keep_open = False

    @validate_call(config=ConfigDict(strict=True))
    def _open_interactive_shell(self) -> None:
        """Start the shell process with given arguments."""
        if self.process is None:
            shell_command = f"{self.executable} {' '.join(self._start_shell_arguments)}"
            if self.interpreter:
                if self.precommand:
                    shell_command = f'{self.interpreter} "{self.precommand} {shell_command}"'
                else:
                    shell_command = f'{self.interpreter} "{shell_command}"'
            xibif_print_debug(f"Starting shell: {shell_command}", stage=self.__logger_stage, prefix=self._stdout_shell_text)
            self.process = subprocess.Popen(
                shell_command,
                stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                shell=True,
                bufsize=1,  # Line-buffered
            )
            self._start_reading_threads()
            if isinstance(self._open_shell_command, list):
                for command in self._open_shell_command:
                    self.send(command)
            else:
                self.send(self._open_shell_command)

            self.wait_for_execution()

    @validate_call(config=ConfigDict(strict=True))
    def _close_interactive_shell(self) -> None:
        """Close the shell process."""
        if self.process:
            if isinstance(self._close_shell_command, list):
                for command in self._close_shell_command:
                    self.send(command)
            else:
                self.send(self._close_shell_command)
            self.process.stdin.close()
            self.process.wait()
            self.process = None

    @property
    def logger_stage(self) -> LS:
        """Return the current logger stage used to tag shell output messages.

        Returns:
            LS: The current logger stage.
        """
        return self.__logger_stage

    @logger_stage.setter
    def logger_stage(self, stage: LS) -> None:
        """Set the logger stage used to tag shell output messages.

        Args:
            stage (LS): The logger stage to set.
        """
        self.__logger_stage = stage

    @property
    def downgrade_errors(self) -> bool:
        """Return whether stderr lines from the shell are downgraded to info-level log messages.

        Returns:
            bool: True if stderr lines are downgraded to info-level, False if they are logged as errors.
        """
        return self.__downgrade_errors

    @downgrade_errors.setter
    def downgrade_errors(self, downgrade: bool) -> None:
        """Set whether stderr lines from the shell should be downgraded to info-level log messages.

        Args:
            downgrade (bool): True to downgrade stderr lines to info-level, False to log them as errors.
        """
        self.__downgrade_errors = downgrade

    @property
    def _stdout_shell_text(self) -> str:
        """Return the prefix text to use for stdout lines from this shell.

        Returns:
            str: The prefix text for stdout lines.
        """
        return self.name.upper()

    @property
    def _stderr_shell_text(self) -> str:
        """Return the prefix text to use for stderr lines from this shell.

        Returns:
            str: The prefix text for stderr lines.
        """
        return self.name.upper()

    @property
    @abstractmethod
    def _start_shell_arguments(self) -> list[str]:
        """Return the command-line arguments used to start the shell executable.

        Returns:
            list[str]: A list of command-line arguments for starting the shell.
        """

    @property
    @abstractmethod
    def _filter(self) -> list[str]:
        """Return a list of regex patterns to strip from shell output before logging.

        Returns:
            list[str]: A list of regex patterns to filter out from shell output."""

    @property
    @abstractmethod
    def _filter_ready(self) -> list[str]:
        """Return a list of regex patterns that signal the shell is ready for the next command.

        Returns:
            list[str]: A list of regex patterns that indicate shell readiness in the output.
        """

    @property
    @abstractmethod
    def _filter_upgrade_warning(self) -> list[str]:
        """Return a list of regex patterns that identify upgrade warning lines in shell output.

        Returns:
            list[str]: A list of regex patterns that identify upgrade warnings in shell output.
        """

    @property
    @abstractmethod
    def _command_ready(self) -> str:
        """Return the command to send to the shell in order to probe for readiness.
        Returns:
            str: The command string to send to the shell to check if it is ready for the next command.
        """

    @property
    @abstractmethod
    def _close_shell_command(self) -> str:
        """Return the command (or list of commands) used to close the shell."""

    @property
    @abstractmethod
    def _open_shell_command(self) -> str:
        """Return the command (or list of commands) to send after the shell has started."""

    @validate_call(config=ConfigDict(strict=True))
    def _get_output_from_shell(self, timeout: float = 1.0) -> str | None:
        """Get standard output from the shell.

        Args:
            timeout (float): Time in seconds to wait for output. Default is 1.0.

        Returns:
            str | None: The output string from the shell, or None if no output was received within the timeout.
        """
        try:
            response = self.output_queue.get(timeout=timeout)
            return response.strip()
        except queue.Empty:
            return None

    @validate_call(config=ConfigDict(strict=True))
    def _get_error_from_shell(self, timeout: float = 1.0) -> str | None:
        """Get standard error from the shell.

        Args:
            timeout (float): Time in seconds to wait for error output. Default is 1.0.

        Returns:
            str | None: The error string from the shell, or None if no error was received within the timeout.
        """
        try:
            error = self.error_queue.get(timeout=timeout)
            return error.strip()
        except queue.Empty:
            return None

    @validate_call(config=ConfigDict(strict=True))
    def _start_reading_threads(self) -> None:
        """Start threads for reading stdout and stderr."""
        threading.Thread(target=self._read_stdout, daemon=True).start()
        threading.Thread(target=self._read_stderr, daemon=True).start()

    @validate_call(config=ConfigDict(strict=True))
    def _read_stdout(self) -> None:
        """Read standard output and put it into the queue."""
        for line in self.process.stdout:
            line = filter_string(line.strip(), self._filter).strip()
            (idx, _) = search_string(line, self._filter_ready)
            if not self.quiet and idx is None:
                (idx_upgrade_warning, _) = search_string(line, self._filter_upgrade_warning) if self._filter_upgrade_warning else (None, None)
                if idx_upgrade_warning is not None:
                    xibif_print_warning(line, stage=self.__logger_stage, prefix=self._stdout_shell_text)
                else:
                    xibif_print(line, verbosity=LoggerVerbosity.INFO, stage=self.__logger_stage, prefix=self._stdout_shell_text, color=Fore.GREEN)
            self.output_queue.put(line)

    @validate_call(config=ConfigDict(strict=True))
    def _read_stderr(self) -> None:
        """Read standard error and put it into the queue."""
        for line in self.process.stderr:
            line = filter_string(line.strip(), self._filter).strip()
            (idx, _) = search_string(line, self._filter_ready)
            if not self.quiet and idx is None:
                if self.__downgrade_errors:
                    xibif_print(line, verbosity=LoggerVerbosity.INFO, stage=self.__logger_stage, prefix=self._stdout_shell_text, color=Fore.GREEN)
                else:
                    xibif_print_error(line, stage=self.__logger_stage, prefix=self._stderr_shell_text)
            self.error_queue.put(line)

    @validate_call(config=ConfigDict(strict=True, defer_build=True, arbitrary_types_allowed=True))
    def __enter__(self) -> Shell:
        """Enter the context manager.

        Returns:
            Shell: The shell instance.
        """
        if self.process is None:
            self._open_interactive_shell()
            self.__keep_open = False
        else:
            self.__keep_open = True
        return self

    @validate_call(config=ConfigDict(strict=True, arbitrary_types_allowed=True))
    def __exit__(self, exc_type: type[BaseException] | None, exc_value: BaseException | None, traceback: TracebackType | None) -> None:
        """Exit the context manager and close the shell.

        Args:
            exc_type (type[BaseException] | None): The exception type, if an exception was raised.
            exc_value (BaseException | None): The exception instance, if an exception was raised.
            traceback (TracebackType | None): The traceback, if an exception was raised.
        """
        if not self.__keep_open:
            self._close_interactive_shell()
        self.__keep_open = False

    @validate_call(config=ConfigDict(strict=True))
    def run(self, command: str | list[str | list]) -> None:
        """Send a command or a sequence of commands to the shell and wait for execution to complete.

        Args:
            command (str | list[str]): A single command string or a (nested) list of command strings to send to the shell.

        Raises:
            XibifValidationError: If the input command is not a string or a list of strings.
        """
        if isinstance(command, str):
            self.send(command)
        elif isinstance(command, list):
            self.__run_sequence(command)
        else:
            raise XibifValidationError("Invalid input for run: expected str or list[str]")
        self.wait_for_execution()

    @validate_call(config=ConfigDict(strict=True))
    def __run_sequence(self, sequence: list[str | list]) -> None:
        """Recursively send a sequence of commands to the shell.

        Args:
            sequence (list[str]): A list of command strings or nested lists thereof to send to the shell.

        Raises:
            XibifValidationError: If the input is not a list of strings or nested lists of strings.
        """
        for command in sequence:
            if isinstance(command, list):
                self.__run_sequence(command)
            elif isinstance(command, str):
                self.send(command)
            else:
                raise XibifValidationError("A command in the sequence is not of the expected type str or list[str]!")

    @validate_call(config=ConfigDict(strict=True))
    def wait_for_string(self, string: list[str]) -> tuple[int, str]:
        """Wait until one of the given strings appears in the shell output.

        Args:
            string (list[str]): A list of regex patterns to wait for in the shell output.

        Returns:
            tuple[int, str]: A tuple of the index of the matched pattern and the matched output line.
        """
        while True:
            data = self._get_output_from_shell(timeout=1.0)

            if data:
                (idx, result) = search_string(data, string)
                if idx is not None:
                    return (idx, result)

    @validate_call(config=ConfigDict(strict=True))
    def wait_for_execution(self) -> None:
        """Send the ready marker command and wait until the shell signals that execution is complete."""
        if self._command_ready is not None:
            self.send(self._command_ready)
            self.wait_for_string(self._filter_ready)
