"""Module for shell related models."""

from enum import Enum, auto


class ShellTool(Enum):
    """Enum for supported shell tools."""

    VIVADO = auto()
    VITIS = auto()
    VITIS_FLASH = auto()
    PYTHON = auto()


class ShellHeaderAlignment(Enum):
    """Enum for shell header alignment options."""

    LEFT = auto()
    CENTER = auto()
    RIGHT = auto()
