"""Module defining the VitisTclShell class, which manages a Vitis Tcl shell session, providing commands and filters specific to the Vitis Tcl environment."""

from pydantic import ConfigDict, validate_call
from ....shell import Shell


class VitisTclShell(Shell):
    """Class to manage a Vitis Tcl shell session, providing commands and filters specific to the Vitis Tcl environment."""

    @property
    @validate_call(config=ConfigDict(strict=True))
    def _start_shell_arguments(self) -> list[str]:
        """Return the arguments required to start the Vitis Tcl shell.

        Returns:
            list[str]: A list of command-line arguments to start the shell.
        """
        return ["-interactive"]

    @property
    @validate_call(config=ConfigDict(strict=True))
    def _filter(self) -> list[str]:
        """Return the list of regular expressions used to filter the shell output.

        Returns:
            list[str]: A list of regular expressions to filter the shell output.
        """
        return [r"xsct%\s*"]

    @property
    @validate_call(config=ConfigDict(strict=True))
    def _close_shell_command(self) -> str:
        """Return the command used to close the Vitis Tcl shell.

        Returns:
            str: The command to close the shell.
        """
        return "exit"

    @property
    @validate_call(config=ConfigDict(strict=True))
    def _open_shell_command(self) -> str:
        """Return the command used to open the Vitis Tcl shell.

        Returns:
            str: The command to open the shell.
        """
        return ""

    @property
    @validate_call(config=ConfigDict(strict=True))
    def _filter_ready(self) -> list[str]:
        """Return the list of regular expressions used to detect when the shell is ready for input.

        Returns:
            list[str]: A list of regular expressions to detect shell readiness.
        """
        return ["^.*%SCREADY%.*$"]

    @property
    @validate_call(config=ConfigDict(strict=True))
    def _command_ready(self) -> str:
        """Return the command used to signal that the shell is ready for the next command.

        Returns:
            str: The command to signal shell readiness.
        """
        return 'puts "%SCREADY%"'

    @property
    @validate_call(config=ConfigDict(strict=True))
    def _filter_upgrade_warning(self) -> list[str] | None:
        """Return the list of regular expressions used to filter out upgrade warnings from the shell output.

        Returns:
            list[str]: A list of regular expressions to filter out upgrade warnings.
        """
        return None
