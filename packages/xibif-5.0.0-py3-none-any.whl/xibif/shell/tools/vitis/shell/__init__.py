"""Shell tools for Vitis."""

from typing import Union
from .python import VitisPythonShell as python
from .tcl import VitisTclShell as tcl

VitisShell = Union[python, tcl]

__all__ = [
    "tcl",
    "python",
]
