from .v2023_1 import Vitis20231CommandSet as v2023_1
from .v2023_2 import Vitis20232CommandSet as v2023_2
from .v2024_1 import Vitis20241CommandSet as v2024_1
from .v2024_2 import Vitis20242CommandSet as v2024_2

from .v2025_1 import Vitis20251CommandSet as v2025_1
from .v2025_2 import Vitis20252CommandSet as v2025_2

__all__ = [
  'v2023_1',
  'v2023_2',
  'v2024_1',
  'v2024_2',
  'v2025_1',
  'v2025_2'
]
