"""Defines the Python command set for Vitis 2025.2, including implementations of abstract methods from the base Python command set and any version-specific commands or overrides."""

from pydantic import ConfigDict, validate_call
from .....types import XibifPath
from .base_python import VitisPythonCommandSet
from .....types.boards import XilinxBoard


class Vitis20252CommandSet(VitisPythonCommandSet):
    """Defines the Python command set for Vitis 2025.2, including implementations of abstract methods from the base Python command set and any version-specific commands or overrides."""

    @staticmethod
    @validate_call(config=ConfigDict(strict=True))
    def create_workspace(workspace_path: XibifPath) -> list[str] | str:
        """Create a new workspace in the Vitis Python shell environment.

        Args:
            workspace_path (XibifPath): The path to the workspace to be created.

        Returns:
            list[str] | str: A Python command that creates a new workspace at the specified path.
        """
        workspace_path = workspace_path.as_tcl()
        return [VitisPythonCommandSet.print_header(f"Set Workspace to {workspace_path}"), f"client.update_workspace({workspace_path})"]

    @staticmethod
    @validate_call(config=ConfigDict(strict=True))
    def set_workspace(workspace_path: XibifPath) -> list[str] | str:
        """Set the current workspace in the Vitis Python shell environment.

        Args:
            workspace_path (XibifPath): The path to the workspace to be set as active.

        Returns:
            list[str] | str: A Python command that sets the current workspace to the specified path.
        """
        workspace_path_tcl = workspace_path.as_tcl()
        return [Vitis20252CommandSet.create_workspace(workspace_path), f"client.set_workspace({workspace_path_tcl})"]

    @staticmethod
    @validate_call(config=ConfigDict(strict=True))
    def __get_domain_config_lib() -> list[str, str, str]:
        """Return a list of library configuration settings for the domain in the Vitis Python shell environment.

        Returns:
            list[str, str, str]: A list of tuples containing library configuration settings, where each tuple consists of the parameter name, value, and library name.
        """
        return [
            ["lwip220_temac_tcp_ip_tx_checksum_offload", "true", "lwip220"],
            ["lwip220_temac_tcp_ip_rx_checksum_offload", "true", "lwip220"],
            ["lwip220_temac_tcp_tx_checksum_offload", "true", "lwip220"],
            ["lwip220_memp_n_tcp_seg", "1024", "lwip220"],
            ["lwip220_tcp_snd_buf", "65535", "lwip220"],
            ["lwip220_temac_tcp_rx_checksum_offload", "true", "lwip220"],
            ["lwip220_tcp_keepalive", "true", "lwip220"],
            ["lwip220_memp_n_pbuf", "2048", "lwip220"],
            ["lwip220_pbuf_pool_size", "4096", "lwip220"],
            ["lwip220_mem_size", "524288", "lwip220"],
            ["lwip220_api_mode", "SOCKET_API", "lwip220"],
            ["lwip220_socket_mode_thread_prio", "3", "lwip220"],
            ["lwip220_tcp_wnd", "65535", "lwip220"],
            ["lwip220_dhcp", "true", "lwip220"],
        ]

    @staticmethod
    @validate_call(config=ConfigDict(strict=True))
    def __get_domain_config_os() -> list[str, str]:
        """Return a list of OS configuration settings for the domain in the Vitis Python shell environment.

        Returns:
            list[str, str]: A list of tuples containing OS configuration settings, where each tuple consists of the parameter name and value.
        """
        return [
            ["freertos_total_heap_size", "52428800"],
            ["freertos_queue_registry_size", "16"],
            ["freertos_tick_rate", "500"],
        ]

    @staticmethod
    @validate_call(config=ConfigDict(strict=True))
    def __get_domain_lib(board: XilinxBoard) -> list[str, str]:
        """Return a list of libraries to be added to the domain in the Vitis Python shell environment based on the specified Xilinx board.

        Args:
            board (XilinxBoard): The Xilinx board for which to determine the libraries to be added.

        Returns:
            list[str, str]: A list of tuples containing library names and their corresponding paths to be added to the domain.
        """
        if board in (XilinxBoard.ZCU104, XilinxBoard.ZCU102, XilinxBoard.KV260):
            return [
                ["xilfpga", "data/embeddedsw/lib/sw_services/xilfpga_v6_8"],
                ["lwip220", "data/embeddedsw/ThirdParty/sw_services/lwip220_v1_2"],
            ]
        else:
            return [
                ["lwip220", "data/embeddedsw/ThirdParty/sw_services/lwip220_v1_2"],
            ]

    @staticmethod
    @validate_call(config=ConfigDict(strict=True))
    def config_domain(mss_path: XibifPath, board: XilinxBoard) -> list[str] | str:  # pylint: disable=useless-type-doc disable=useless-param-doc disable=unused-argument
        """Configure the domain in the Vitis Python shell environment based on the specified Xilinx board.

        Args:
            mss_path (XibifPath): The path to the MSS file (ignored in Python command set).
            board (XilinxBoard): The Xilinx board for which to configure the domain.

        Returns:
            list[str] | str: A list of Python commands that configure the domain with the appropriate libraries and settings based on the specified board.
        """
        config_lib_settings = Vitis20252CommandSet.__get_domain_config_lib()
        config_os_settings = Vitis20252CommandSet.__get_domain_config_os()
        lib_settings = Vitis20252CommandSet.__get_domain_lib(board)

        return [
            VitisPythonCommandSet.print_header("Config Domain"),
            VitisPythonCommandSet.set_active_domain(board),
            'pathVitis = Path(os.environ.get("RDI_APPROOT"))',
            [f'domain.set_lib(lib_name="{lib_name}", path=str(pathVitis.joinpath("{path}")))' for (lib_name, path) in lib_settings],
            [f'domain.set_config(option="os", param="{param}", value="{value}")' for (param, value) in config_os_settings],
            [f'domain.set_config(option="lib", param="{param}", value="{value}", lib_name="{lib_name}")' for (param, value, lib_name) in config_lib_settings],
        ]
