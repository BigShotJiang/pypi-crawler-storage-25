"""Defines the base TCL command set for Vitis operations, including shared helper methods for workspace, platform, domain, and application management."""

from pydantic import ConfigDict, validate_call
from ....pstoolcommandset import PsToolCommandSet
from .....types import XilinxBoard, XibifPath, XibifValidationError


class VitisTclCommandSet(PsToolCommandSet):
    """Defines TCL command sets for Vitis operations, including shared helpers for board-specific setup and build workflow commands."""

    @staticmethod
    @validate_call(config=ConfigDict(strict=True))
    def __get_board_settings(board: XilinxBoard) -> dict:
        """Return a dictionary of board-specific settings based on the given Xilinx board.

        Args:
            board (XilinxBoard): The Xilinx board for which to retrieve settings.

        Returns:
            dict: A dictionary containing board-specific settings such as processor, architecture, and bootgen options.
        """
        board_settings = {}
        if board == XilinxBoard.ZEDBOARD:
            board_settings["processor"] = "ps7_cortexa9_0"
            board_settings["arch"] = "32-bit"
            board_settings["bootgen_options"] = ""
        elif board == XilinxBoard.ZYBOZ720:
            board_settings["processor"] = "ps7_cortexa9_0"
            board_settings["arch"] = "32-bit"
            board_settings["bootgen_options"] = ""
        elif board == XilinxBoard.ZYBOZ710:
            board_settings["processor"] = "ps7_cortexa9_0"
            board_settings["arch"] = "32-bit"
            board_settings["bootgen_options"] = ""
        elif board == XilinxBoard.ZCU104:
            board_settings["processor"] = "psu_cortexa53_0"
            board_settings["arch"] = "64-bit"
            board_settings["bootgen_options"] = "-arch zynqmp"
        elif board == XilinxBoard.ZCU102:
            board_settings["processor"] = "psu_cortexa53_0"
            board_settings["arch"] = "64-bit"
            board_settings["bootgen_options"] = "-arch zynqmp"
        elif board == XilinxBoard.KV260:
            board_settings["processor"] = "psu_cortexa53_0"
            board_settings["arch"] = "64-bit"
            board_settings["bootgen_options"] = "-arch zynqmp"

        return board_settings

    @staticmethod
    @validate_call(config=ConfigDict(strict=True))
    def print_to_console(s) -> list[str] | str:
        """Create a TCL print command for tool console output.

        Args:
            s (str): The string to be printed to the console.

        Returns:
            list[str] | str: A TCL command that prints the given string to the console.
        """
        return f'puts "{s}"'

    @staticmethod
    @validate_call(config=ConfigDict(strict=True))
    def set_workspace(workspace_path: XibifPath) -> list[str] | str:
        """Set and import the active workspace in the Vitis environment.

        Args:
            workspace_path (XibifPath): The path to the workspace to activate and import.

        Returns:
            list[str] | str: A list of TCL commands that set and import the workspace.
        """
        workspace_path_tcl = workspace_path.as_tcl()
        return [VitisTclCommandSet.create_workspace(workspace_path), f"importprojects {workspace_path_tcl}"]

    @staticmethod
    @validate_call(config=ConfigDict(strict=True))
    def create_workspace(workspace_path: XibifPath) -> list[str] | str:
        """Create or switch to a workspace in the Vitis environment.

        Args:
            workspace_path (XibifPath): The path to the workspace.

        Returns:
            list[str] | str: A list of TCL commands that set the workspace.
        """
        workspace_path = workspace_path.as_tcl()
        return [
            VitisTclCommandSet.print_header(f"Set Workspace to {workspace_path}"),
            f"setws {workspace_path}",
        ]

    @staticmethod
    @validate_call(config=ConfigDict(strict=True))
    def create_platform(platform_name: str, hardware_path: XibifPath, board: XilinxBoard) -> list[str] | str:
        """Create a platform in the Vitis environment based on platform name, hardware design path, and board type.

        Args:
            platform_name (str): The name of the platform to be created.
            hardware_path (XibifPath): The path to the hardware design file used for creating the platform.
            board (XilinxBoard): The type of Xilinx board for which the platform is being created.

        Returns:
            list[str] | str: A list of TCL commands that create the platform.
        """
        hardware_path = hardware_path.as_tcl()
        board_settings = VitisTclCommandSet.__get_board_settings(board)
        return [
            VitisTclCommandSet.print_header(f'Create Platform {VitisTclCommandSet.shorten_name(platform_name + "_platform")}'),
            f'platform create -name {VitisTclCommandSet.shorten_name(platform_name + "_platform")} -hw [file normalize {hardware_path}] -arch {board_settings["arch"]}',
        ]

    @staticmethod
    @validate_call(config=ConfigDict(strict=True))
    def set_active_platform(platform_name: str) -> list[str] | str:
        """Set the active platform in the Vitis environment.

        Args:
            platform_name (str): The name of the platform to be set as active.

        Returns:
            list[str] | str: A TCL command that sets the active platform.
        """
        return f'platform active {VitisTclCommandSet.shorten_name(platform_name + "_platform")}'

    @staticmethod
    @validate_call(config=ConfigDict(strict=True))
    def create_domain(platform_name: str, board: XilinxBoard) -> list[str] | str:  # pylint: disable=unused-argument # Platform name is used in Python command set, but not in TCL command set
        """Create a domain in the Vitis environment based on board-specific settings.

        Args:
            platform_name (str): The name of the platform associated with the domain. This parameter is currently unused in the TCL command set.
            board (XilinxBoard): The type of Xilinx board for which the domain is being created.

        Returns:
            list[str] | str: A list of TCL commands that create the domain.
        """
        board_settings = VitisTclCommandSet.__get_board_settings(board)
        return [
            VitisTclCommandSet.print_header(f'Create Domain freertos10_xilinx_{board_settings["processor"]}'),
            f'domain create -name freertos10_xilinx_{board_settings["processor"]} -proc {board_settings["processor"]}  -os freertos10_xilinx -arch {board_settings["arch"]} -runtime cpp -support-app empty_application -display-name freertos10_xilinx_{board_settings["processor"]}',
        ]

    @staticmethod
    @validate_call(config=ConfigDict(strict=True))
    def set_active_domain(board: XilinxBoard) -> list[str] | str:
        """Set the active domain in the Vitis environment based on board type.

        Args:
            board (XilinxBoard): The type of Xilinx board for which the domain is being set as active.

        Returns:
            list[str] | str: A TCL command that sets the active domain.
        """
        board_settings = VitisTclCommandSet.__get_board_settings(board)
        return f'domain active freertos10_xilinx_{board_settings["processor"]}'

    @staticmethod
    @validate_call(config=ConfigDict(strict=True))
    def config_domain(mss_path: XibifPath, board: XilinxBoard) -> list[str] | str:  # pylint: disable=unused-argument # board_name is not used in TCL command set, but is used in Python command set
        """Configure the active domain with an MSS file.

        Args:
            mss_path (XibifPath): The path to the MSS file used for domain configuration.
            board (XilinxBoard): The board type. This parameter is currently unused in the TCL command set.

        Returns:
            list[str] | str: A TCL command that applies the domain MSS configuration.
        """
        _ = board
        mss_path = mss_path.as_tcl()
        return f"domain config -mss [file normalize {mss_path}]"

    @staticmethod
    @validate_call(config=ConfigDict(strict=True))
    def create_application(app_name: str, platform_name: str, board: XilinxBoard) -> list[str] | str:
        """Create an application in the Vitis environment based on application name, platform, and board type.

        Args:
            app_name (str): The name of the application to be created.
            platform_name (str): The name of the platform for which the application is being created.
            board (XilinxBoard): The type of Xilinx board for which the application is being created.

        Returns:
            list[str] | str: A list of TCL commands that create the application.
        """
        board_settings = VitisTclCommandSet.__get_board_settings(board)
        return [
            VitisTclCommandSet.print_header(f"Create Application {app_name}"),
            f'app create -name {app_name} -platform {VitisTclCommandSet.shorten_name(platform_name + "_platform")} -domain freertos10_xilinx_{board_settings["processor"]} -template {{Empty Application(C)}}',
        ]

    @staticmethod
    @validate_call(config=ConfigDict(strict=True))
    def set_active_application(app_name: str) -> list[str] | str:  # pylint: disable=unused-argument
        """Set the active application in the Vitis environment.

        Args:
            app_name (str): The name of the application to be set as active.

        Returns:
            list[str] | str: An empty command string because explicit activation is not required in this TCL command set.
        """
        return ""

    @staticmethod
    @validate_call(config=ConfigDict(strict=True))
    def add_file(app_name: str, file_path: XibifPath | list[XibifPath]) -> list[str] | str:
        """Add one or multiple source files to an application in the Vitis environment.

        Args:
            app_name (str): The name of the application to which files are added.
            file_path (XibifPath): The path to a file or a list of file paths to import.

        Returns:
            list[str] | str: TCL command(s) that import the file(s) into the application.
        """
        if isinstance(file_path, XibifPath):
            file_path = file_path.as_tcl()
            return f"importsources -name {app_name} -path {file_path}"
        elif isinstance(file_path, list):
            return [f"importsources -name {app_name} -path {file.as_tcl()}" for file in file_path]

        return ""

    @staticmethod
    @validate_call(config=ConfigDict(strict=True))
    def generate_platform() -> list[str] | str:
        """Generate the active platform in the Vitis environment.

        Returns:
            list[str] | str:: TCL command(s) that generate the platform.
        """
        return [VitisTclCommandSet.print_header("Generate Platform"), "platform generate"]

    @staticmethod
    @validate_call(config=ConfigDict(strict=True))
    def set_application_config(app_name: str, config: str) -> list[str] | str:
        """Set the build configuration for an application in the Vitis environment.

        Args:
            app_name (str): The name of the application for which the configuration is being set.
            config (str): The configuration to set. Supported values are "Release" and "Debug".

        Returns:
            list[str] | str: A list of TCL commands that set the application configuration.

        Raises:
            XibifValidationError: If the given configuration is not supported.
        """
        if config in ("Release", "Debug"):
            return [VitisTclCommandSet.print_header(f"Set Application {app_name} to {config}"), f"app config -name {app_name} -set build-config {config}"]
        else:
            raise XibifValidationError(f"Configuration {config} not supported. Supported configurations are: Release, Debug")

    @staticmethod
    @validate_call(config=ConfigDict(strict=True))
    def add_linker_script(app_name: str, file_path: XibifPath) -> list[str] | str:
        """Add a linker script file to an application in the Vitis environment.

        Args:
            app_name (str): The name of the application to which the linker script should be added.
            file_path (XibifPath): The path to the linker script file.

        Returns:
            list[str] | str: A TCL command that imports the linker script.
        """
        file_path = file_path.as_tcl()
        return f"importsources -name {app_name} -path {file_path} -linker-script"

    @staticmethod
    @validate_call(config=ConfigDict(strict=True))
    def update_platform(app_name: str, platform_name: str, hardware_path: XibifPath) -> list[str] | str:
        """Update platform hardware in the Vitis environment.

        Args:
            app_name (str): The name of the application associated with the platform update.
            platform_name (str): The name of the platform to update.
            hardware_path (XibifPath): The path to the new hardware design file.

        Returns:
            list[str] | str: A list of TCL commands that update platform hardware.
        """
        hardware_path = hardware_path.as_tcl()
        return [VitisTclCommandSet.print_header(f"Update hardware {app_name}"), VitisTclCommandSet.set_active_platform(platform_name), f"platform config -updatehw {hardware_path}"]

    @staticmethod
    @validate_call(config=ConfigDict(strict=True))
    def generate_application(app_name: str) -> list[str] | str:
        """Generate an application build in the Vitis environment.

        Args:
            app_name (str): The name of the application to be generated.

        Returns:
            list[str] | str: A list of TCL commands that build the application.
        """
        return [VitisTclCommandSet.print_header(f"Generate Application {app_name}"), f"app build -name {app_name}"]

    @staticmethod
    @validate_call(config=ConfigDict(strict=True))
    def get_elf_path(app_name: str, workspace_path: XibifPath) -> XibifPath:
        """Get the path to the generated ELF file for an application.

        Args:
            app_name (str): The name of the application.
            workspace_path (XibifPath): The workspace path containing build outputs.

        Returns:
            XibifPath: The path to the generated ELF file.
        """
        return workspace_path.joinpath(f"{app_name}/Release/{app_name}.elf")

    @staticmethod
    @validate_call(config=ConfigDict(strict=True))
    def clean_application(app_name: str) -> list[str] | str:
        """Clean application build artifacts in the Vitis environment.

        Args:
            app_name (str): The name of the application to be cleaned.

        Returns:
            list[str] | str: A list of TCL commands that clean the application.
        """
        return [VitisTclCommandSet.print_header(f"Clean Application {app_name}"), f"app clean -name {app_name}"]

    @staticmethod
    @validate_call(config=ConfigDict(strict=True))
    def copy_application(  # pylint: disable=useless-type-doc disable=useless-param-doc disable=unused-argument
        app_name: str, output_path: XibifPath, platform_name: str, workspace_path: XibifPath, board: XilinxBoard
    ) -> list[str] | str:
        """Copy generated ELF artifacts for an application to the output directory.

        Args:
            app_name (str): The name of the application for which artifacts are copied.
            output_path (XibifPath): The directory where copied artifacts are stored.
            platform_name (str): The platform name used to locate generated FSBL artifacts.
            workspace_path (XibifPath): The workspace path containing build artifacts.
            board (XilinxBoard): The board type. This parameter is currently unused in the TCL command set.

        Returns:
            list[str] | str: A list of TCL commands that copy FSBL and application ELF files.
        """
        output_fsbl_path = output_path.joinpath("fsbl.elf").as_tcl()
        output_app_path = output_path.joinpath(f"{app_name}.elf").as_tcl()
        fsbl_path = (
            workspace_path.joinpath(
                f'{VitisTclCommandSet.shorten_name(platform_name + "_platform")}/export/{VitisTclCommandSet.shorten_name(platform_name + "_platform")}/sw/{VitisTclCommandSet.shorten_name(platform_name + "_platform")}/boot/fsbl.elf'
            )
        ).as_tcl()
        elf_path = VitisTclCommandSet.get_elf_path(app_name, workspace_path).as_tcl()
        return [VitisTclCommandSet.print_header(f"Copy Application {app_name}"), f"file copy -force {fsbl_path} {output_fsbl_path}", f"file copy -force {elf_path} {output_app_path}"]

    @staticmethod
    @validate_call(config=ConfigDict(strict=True))
    def generate_bootfile(app_name: str, output_path: XibifPath, bitstream_path: XibifPath, board: XilinxBoard) -> list[str] | str:
        """Generate a boot file for an application in the Vitis environment.

        Args:
            app_name (str): The name of the application.
            output_path (XibifPath): The output directory for generated boot artifacts.
            bitstream_path (XibifPath): The path to the bitstream file included in the boot image.
            board (XilinxBoard): The board type used to determine bootgen options.

        Returns:
            list[str] | str: A list of TCL commands that invoke bootgen to create BOOT.BIN.
        """
        board_settings = VitisTclCommandSet.__get_board_settings(board)
        VitisTclCommandSet.generate_bif(output_path.joinpath(f"{app_name}.bif"), board, output_path.joinpath("fsbl.elf"), bitstream_path, output_path.joinpath(f"{app_name}.elf"))

        bif_path = output_path.joinpath(f"{app_name}.bif").as_tcl()
        boot_path = output_path.joinpath("BOOT.BIN").as_tcl()

        return [VitisTclCommandSet.print_header(f"Generate bootfile {app_name}"), f'exec bootgen {board_settings["bootgen_options"]} -image {bif_path} -w -o i {boot_path}']
