"""Defines the base Python command set for Vitis operations, including shared helper methods and abstract methods that should be implemented by specific Vitis version command sets."""

from abc import abstractmethod
from pydantic import ConfigDict, validate_call
from ....pstoolcommandset import PsToolCommandSet
from .....types import XilinxBoard, XibifPath, XibifDefaultsMessages, XibifValidationError


class VitisPythonCommandSet(PsToolCommandSet):
    """Defines Python command sets for Vitis operations, including shared helpers and abstract methods that should be implemented by specific Vitis version command sets."""

    @staticmethod
    @validate_call(config=ConfigDict(strict=True))
    def __get_board_settings(board: XilinxBoard) -> dict:
        """Return a dictionary of board-specific settings based on the given Xilinx board.

        Args:
            board (XilinxBoard): The Xilinx board for which to retrieve settings.

        Returns:
            dict: A dictionary containing board-specific settings such as processor, architecture, FSBL type, and bootgen options.
        """
        board_settings = {}
        if board == XilinxBoard.ZEDBOARD:
            board_settings["processor"] = "ps7_cortexa9_0"
            board_settings["arch"] = "32-bit"
            board_settings["fsbl"] = "zynq_fsbl"
            board_settings["bootgen_options"] = ""
        elif board == XilinxBoard.ZYBOZ720:
            board_settings["processor"] = "ps7_cortexa9_0"
            board_settings["arch"] = "32-bit"
            board_settings["fsbl"] = "zynq_fsbl"
            board_settings["bootgen_options"] = ""
        elif board == XilinxBoard.ZYBOZ710:
            board_settings["processor"] = "ps7_cortexa9_0"
            board_settings["arch"] = "32-bit"
            board_settings["fsbl"] = "zynq_fsbl"
            board_settings["bootgen_options"] = ""
        elif board == XilinxBoard.ZCU104:
            board_settings["processor"] = "psu_cortexa53_0"
            board_settings["arch"] = "64-bit"
            board_settings["fsbl"] = "zynqmp_fsbl"
            board_settings["bootgen_options"] = "-arch zynqmp"
        elif board == XilinxBoard.ZCU102:
            board_settings["processor"] = "psu_cortexa53_0"
            board_settings["arch"] = "64-bit"
            board_settings["fsbl"] = "zynqmp_fsbl"
            board_settings["bootgen_options"] = "-arch zynqmp"
        elif board == XilinxBoard.KV260:
            board_settings["processor"] = "psu_cortexa53_0"
            board_settings["arch"] = "64-bit"
            board_settings["fsbl"] = "zynqmp_fsbl"
            board_settings["bootgen_options"] = "-arch zynqmp"

        return board_settings

    @staticmethod
    @validate_call(config=ConfigDict(strict=True))
    def print_to_console(s) -> list[str] | str:
        """Create a Python print command for tool console output.

        Args:
            s (str): The string to be printed to the console.

        Returns:
            list[str] | str: A Python command that prints the given string to the console with flushing enabled.
        """
        return f'print(r"{s}", flush=True)'

    @staticmethod
    @abstractmethod
    def set_workspace(workspace_path: XibifPath) -> list[str] | str:
        """Set the active workspace in the Vitis environment. This method should be implemented by subclasses to set the workspace based on the given workspace path."""

    @staticmethod
    @validate_call(config=ConfigDict(strict=True))
    def create_platform(platform_name: str, hardware_path: XibifPath, board: XilinxBoard) -> list[str] | str:
        """Create a platform in the Vitis environment based on the given platform name, hardware design path, and board type.

        Args:
            platform_name (str): The name of the platform to be created.
            hardware_path (XibifPath): The path to the hardware design file (e.g., HDF or XSA) to be used for creating the platform.
            board (XilinxBoard): The type of Xilinx board for which the platform is being created.

        Returns:
            list[str] | str: A list of Python commands that create the platform in the Vitis environment.
        """
        hardware_path = hardware_path.as_tcl()
        board_settings = VitisPythonCommandSet.__get_board_settings(board)
        return [
            VitisPythonCommandSet.print_header(f'Create Platform {VitisPythonCommandSet.shorten_name(platform_name + "_platform")}'),
            f'client.create_platform_component(name = "{VitisPythonCommandSet.shorten_name(platform_name + "_platform")}", hw_design = {hardware_path}, os = "freertos", cpu = "{board_settings["processor"]}", domain_name = "freertos10_xilinx_{board_settings["processor"]}")',
            [VitisPythonCommandSet.print_to_console(line) for line in str(XibifDefaultsMessages.WARNING_MESSAGE_SETUP_VITIS).split("\n")],
            f'client.create_platform_component(name = "{VitisPythonCommandSet.shorten_name(platform_name + "_platform")}", hw_design = {hardware_path}, os = "freertos", cpu = "{board_settings["processor"]}", domain_name = "freertos10_xilinx_{board_settings["processor"]}")',  # Second try in case first one fails randomly with a different error each time (Yes, it happens)
        ]

    @staticmethod
    @validate_call(config=ConfigDict(strict=True))
    def set_active_platform(platform_name: str) -> list[str] | str:
        """Set the active platform in the Vitis environment based on the given platform name.

        Args:
            platform_name (str): The name of the platform to be set as active.

        Returns:
            list[str] | str: A list of Python commands that set the active platform in the Vitis environment.
        """
        return [
            f'platform = client.get_component(name="{VitisPythonCommandSet.shorten_name(platform_name + "_platform")}")',
            f'xpfmPath = client.find_platform_in_repos("{VitisPythonCommandSet.shorten_name(platform_name + "_platform")}")',
        ]

    @staticmethod
    @validate_call(config=ConfigDict(strict=True))
    def create_domain(platform_name: str, board: XilinxBoard) -> list[str] | str:  # pylint: disable=useless-type-doc disable=useless-param-doc disable=unused-argument
        """Create a domain in the Vitis environment based on the given platform name and board type.

        Args:
            platform_name (str): The name of the platform for which the domain is being created.
            board (XilinxBoard): The type of Xilinx board for which the domain is being created. This parameter is currently unused in the Python command set but may be used in TCL command sets.

        Returns:
            list[str] | str: A list of Python commands that create the domain in the Vitis environment.
        """
        return [
            VitisPythonCommandSet.print_header(f'Create Domain {VitisPythonCommandSet.shorten_name(platform_name + "_system")}'),
            VitisPythonCommandSet.set_active_platform(platform_name),
            f'client.create_sys_project(name="{VitisPythonCommandSet.shorten_name(platform_name + "_system")}", platform=xpfmPath, template="empty_accelerated_application")',
        ]

    @staticmethod
    @validate_call(config=ConfigDict(strict=True))
    def set_active_domain(board: XilinxBoard) -> list[str] | str:
        """Set the active domain in the Vitis environment based on the given board type.

        Args:
            board (XilinxBoard): The type of Xilinx board for which the domain is being set as active.

        Returns:
            list[str] | str: A Python command that sets the active domain in the Vitis environment based on the processor type associated with the given board.
        """
        board_settings = VitisPythonCommandSet.__get_board_settings(board)
        return f'domain = platform.get_domain(name="freertos10_xilinx_{board_settings["processor"]}")'

    @staticmethod
    @validate_call(config=ConfigDict(strict=True))
    def create_application(app_name: str, platform_name: str, board: XilinxBoard) -> list[str] | str:
        """Create an application in the Vitis environment based on the given application name, platform name, and board type.

        Args:
            app_name (str): The name of the application to be created.
            platform_name (str): The name of the platform for which the application is being created.
            board (XilinxBoard): The type of Xilinx board for which the application is being created.

        Returns:
            list[str] | str: A list of Python commands that create the application in the Vitis environment.
        """
        board_settings = VitisPythonCommandSet.__get_board_settings(board)
        return [
            VitisPythonCommandSet.print_header(f"Create Application {app_name}"),
            f'sysProj = client.get_sys_project(name="{VitisPythonCommandSet.shorten_name(platform_name + "_system")}")',
            VitisPythonCommandSet.set_active_platform(platform_name),
            f'client.create_app_component(name="{app_name}", platform = xpfmPath, domain = "freertos10_xilinx_{board_settings["processor"]}")',
            f'sysProj.add_component(name="{app_name}")',
        ]

    @staticmethod
    @validate_call(config=ConfigDict(strict=True))
    def set_active_application(app_name: str) -> list[str] | str:
        """Set the active application in the Vitis environment based on the given application name.

        Args:
            app_name (str): The name of the application to be set as active.

        Returns:
            list[str] | str: A Python command that sets the active application in the Vitis environment by retrieving the component with the given application name from the client.
        """
        return f'comp = client.get_component(name="{app_name}")'

    @staticmethod
    @validate_call(config=ConfigDict(strict=True))
    def add_file(app_name: str, file_path: XibifPath | list[XibifPath]) -> list[str] | str:
        """Add a file or a list of files to the current application in the Vitis environment.

        Args:
            app_name (str): The name of the application to which the file(s) should be added.
            file_path (XibifPath | list[XibifPath]): The path to the file or a list of paths to the files that should be added to the application.

        Returns:
            list[str] | str: A list of Python commands that add the specified file(s) to the current application in the Vitis environment.
        """
        if isinstance(file_path, XibifPath):
            file_path = file_path.as_tcl()
            return [VitisPythonCommandSet.set_active_application(app_name), f'comp.import_files(from_loc={file_path}, dest_dir_in_cmp = "src")']
        elif isinstance(file_path, list):
            return [VitisPythonCommandSet.set_active_application(app_name), [f'comp.import_files(from_loc={file.as_tcl()}, dest_dir_in_cmp = "src")' for file in file_path]]

        return ""

    @staticmethod
    @validate_call(config=ConfigDict(strict=True))
    def generate_platform() -> list[str] | str:
        """Generate the platform in the Vitis environment.

        Returns:
            list[str] | str: A list of Python commands that generate the platform in the Vitis environment, including printing a header and building the platform.
        """
        return [VitisPythonCommandSet.print_header("Generate Platform"), "platform.build()"]

    @staticmethod
    @validate_call(config=ConfigDict(strict=True))
    def set_application_config(app_name: str, config: str) -> list[str] | str:
        """Set the application configuration in the Vitis environment based on the given application name and configuration type.

        Args:
            app_name (str): The name of the application for which the configuration is being set.
            config (str): The type of configuration to be set (e.g., "Release" or "Debug").

        Returns:
            list[str] | str: A list of Python commands that set the application configuration in the Vitis environment.

        Raises:
            XibifValidationError: If the given configuration is not supported. Supported configurations are "Release" and "Debug".
        """
        if config in ("Release", "Debug"):
            return [VitisPythonCommandSet.print_header(f"Set Application {app_name} to {config}")]
        else:
            raise XibifValidationError(f"Configuration {config} not supported. Supported configurations are: Release, Debug")

    @staticmethod
    @validate_call(config=ConfigDict(strict=True))
    def add_linker_script(app_name: str, file_path: XibifPath) -> list[str] | str:
        """Add a linker script to the current application in the Vitis environment based on the given application name and file path.

        Args:
            app_name (str): The name of the application to which the linker script should be added.
            file_path (XibifPath): The path to the linker script file that should be added to the application.

        Returns:
            list[str] | str: A list of Python commands that add the specified linker script to the current application in the Vitis environment.
        """
        return VitisPythonCommandSet.add_file(app_name, file_path)

    @staticmethod
    @validate_call(config=ConfigDict(strict=True))
    def update_platform(app_name: str, platform_name: str, hardware_path: XibifPath) -> list[str] | str:
        """Update the hardware design of the platform in the Vitis environment based on the given application name, platform name, and hardware design path.

        Args:
            app_name (str): The name of the application for which the platform hardware design should be updated.
            platform_name (str): The name of the platform to be updated.
            hardware_path (XibifPath): The path to the new hardware design file (e.g., HDF or XSA) that should be used for updating the platform.

        Returns:
            list[str] | str: A list of Python commands that update the hardware design of the platform in the Vitis environment.
        """
        hardware_path = hardware_path.as_tcl()
        return [
            VitisPythonCommandSet.print_header(f"Update hardware {app_name}"),
            VitisPythonCommandSet.set_active_platform(platform_name),
            f"platform.update_hw(hw_design={hardware_path})",
            f'sysProj = client.get_sys_project(name="{VitisPythonCommandSet.shorten_name(platform_name + "_system")}")',
            "sysProj.update_platform(xpfmPath)",
        ]

    @staticmethod
    @validate_call(config=ConfigDict(strict=True))
    def generate_application(app_name: str) -> list[str] | str:
        """Generate the application in the Vitis environment based on the given application name.

        Args:
            app_name (str): The name of the application to be generated.

        Returns:
            list[str] | str: A list of Python commands that generate the application in the Vitis environment.
        """
        return [
            VitisPythonCommandSet.print_header(f"Generate Application {app_name}"),
            VitisPythonCommandSet.set_active_application(app_name),
            "comp.build()",
        ]

    @staticmethod
    @validate_call(config=ConfigDict(strict=True))
    def clean_application(app_name: str) -> list[str] | str:
        """Clean the application in the Vitis environment based on the given application name.

        Args:
            app_name (str): The name of the application to be cleaned.

        Returns:
            list[str] | str: A list of Python commands that clean the application in the Vitis environment.
        """
        return [
            VitisPythonCommandSet.print_header(f"Clean Application {app_name}"),
            VitisPythonCommandSet.set_active_application(app_name),
            "comp.clean()",
        ]

    @staticmethod
    @validate_call(config=ConfigDict(strict=True))
    def get_elf_path(app_name: str, workspace_path: XibifPath) -> XibifPath:
        """Get the path to the generated ELF file for the current application in the Vitis environment based on the given application name and workspace path.

        Args:
            app_name (str): The name of the application for which to get the ELF file path.
            workspace_path (XibifPath): The path to the workspace where the application is located.

        Returns:
            XibifPath: The path to the generated ELF file for the current application in the Vitis environment.
        """
        return workspace_path.joinpath(f"{app_name}/build/{app_name}.elf")

    @staticmethod
    @validate_call(config=ConfigDict(strict=True))
    def copy_application(app_name: str, output_path: XibifPath, platform_name: str, workspace_path: XibifPath, board: XilinxBoard) -> list[str] | str:
        """Copy the generated ELF file for the current application to a specified location in the Vitis environment based on the given application name, output path, platform name, workspace path, and board type.

        Args:
            app_name (str): The name of the application for which to copy the ELF file.
            output_path (XibifPath): The path to the directory where the ELF file should be copied.
            platform_name (str): The name of the platform associated with the application.
            workspace_path (XibifPath): The path to the workspace where the application is located.
            board (XilinxBoard): The type of Xilinx board associated with the application.

        Returns:
            list[str] | str: A list of Python commands that copy the generated ELF file for the current application to the specified location in the Vitis environment.
        """
        board_settings = VitisPythonCommandSet.__get_board_settings(board)
        output_path = output_path.as_tcl()
        fsbl_path = workspace_path.joinpath(f'{VitisPythonCommandSet.shorten_name(platform_name + "_platform")}/{board_settings["fsbl"]}/build/fsbl.elf').as_tcl()
        elf_path = VitisPythonCommandSet.get_elf_path(app_name, workspace_path).as_tcl()
        return [VitisPythonCommandSet.print_header(f"Copy Application {app_name}"), f"shutil.copy({fsbl_path}, {output_path})", f"shutil.copy({elf_path}, {output_path})"]

    @staticmethod
    @validate_call(config=ConfigDict(strict=True))
    def generate_bootfile(app_name: str, output_path: XibifPath, bitstream_path: XibifPath, board: XilinxBoard) -> list[str] | str:
        """Generate a boot file (e.g., BIF) for the current application in the Vitis environment based on the given application name, output path, bitstream path, and board type.

        Args:
            app_name (str): The name of the application for which to generate the boot file.
            output_path (XibifPath): The path to the directory where the boot file should be generated.
            bitstream_path (XibifPath): The path to the bitstream file that should be included in the boot file.
            board (XilinxBoard): The type of Xilinx board associated with the application.

        Returns:
            list[str] | str: A list of Python commands that generate a boot file for the current application in the Vitis environment.
        """
        board_settings = VitisPythonCommandSet.__get_board_settings(board)
        VitisPythonCommandSet.generate_bif(output_path.joinpath(f"{app_name}.bif"), board, output_path.joinpath("fsbl.elf"), bitstream_path, output_path.joinpath(f"{app_name}.elf"))

        bif_path = output_path.joinpath(f"{app_name}.bif").as_tcl()
        boot_path = output_path.joinpath("BOOT.BIN").as_tcl()

        return [
            VitisPythonCommandSet.print_header(f"Generate bootfile {app_name}"),
            f'proc = subprocess.Popen(\'bootgen {board_settings["bootgen_options"]} -image {bif_path} -w -o i {boot_path}\', shell=True)',
            "proc.wait()",
        ]
