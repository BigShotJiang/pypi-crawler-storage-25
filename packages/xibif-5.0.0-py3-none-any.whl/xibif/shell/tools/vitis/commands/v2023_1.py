"""Defines the TCL command set for Vitis 2023.1, including implementations of abstract methods from the base TCL command set and any version-specific commands or overrides."""

from .base_tcl import VitisTclCommandSet


class Vitis20231CommandSet(VitisTclCommandSet):
    """Defines the TCL command set for Vitis 2023.1, including implementations of abstract methods from the base TCL command set and any version-specific commands or overrides."""
