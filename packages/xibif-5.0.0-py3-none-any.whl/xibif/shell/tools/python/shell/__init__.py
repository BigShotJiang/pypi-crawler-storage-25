from .python import PythonShell as python

__all__ = [
    'python'
]