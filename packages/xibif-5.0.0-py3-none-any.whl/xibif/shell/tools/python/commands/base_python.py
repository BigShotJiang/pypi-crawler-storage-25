"""Defines the command set for the Python shell environment, including commands for printing to the console, running files, changing directories, compiling VUnit libraries, adding command-line arguments, and setting environment variables."""

from pydantic import ConfigDict, validate_call
from .....types import XibifPath
from ....pythontoolcommandset import PythonToolCommandSet


class PythonCommandSet(PythonToolCommandSet):
    """Defines the command set for the Python shell environment, including commands for printing to the console, running files, changing directories, compiling VUnit libraries, adding command-line arguments, and setting environment variables."""

    @staticmethod
    @validate_call(config=ConfigDict(strict=True))
    def print_to_console(s) -> list[str] | str:
        """Return a Python command that prints a message to the console.

        Args:
            s (str): The message to be printed.

        Returns:
            list[str] | str: A Python command that prints the message to the console.
        """
        return f'puts "{s}"'

    @staticmethod
    @validate_call(config=ConfigDict(strict=True))
    def run_file(file: XibifPath) -> list[str] | str:
        """Return a Python command that runs a Python file.

        Args:
            file (XibifPath): The path to the Python file to be run.

        Returns:
            list[str] | str: A Python command that runs the specified Python file.
        """
        # Read all lines of the file and return a list of lines
        with open(file, "r") as f:
            lines = f.readlines()
        return lines

    @staticmethod
    @validate_call(config=ConfigDict(strict=True))
    def change_directory(directory: XibifPath) -> list[str] | str:
        """Return a Python command that changes the current working directory.

        Args:
            directory (XibifPath): The path to the directory to change to.

        Returns:
            list[str] | str: A Python command that changes the current working directory to the specified path.
        """
        return f'os.chdir("{str(directory.as_posix())}")'

    @staticmethod
    @validate_call(config=ConfigDict(strict=True))
    def compile_vunit_lib(results_folder: XibifPath) -> list[str] | str:
        """Return a list of Python commands that compile the VUnit library and specify the results folder.

        Args:
            results_folder (XibifPath): The path to the results folder for the VUnit compilation.

        Returns:
            list[str] | str: A list of Python commands that compile the VUnit library and specify the results folder.
        """
        return [
            "from vunit import VUnit",
            f'ui = VUnit.from_argv(argv=["-o", "{str(results_folder.as_posix())}", "--compile"])',
            "ui.add_vhdl_builtins()",
            "ui.main()",
        ]

    @staticmethod
    @validate_call(config=ConfigDict(strict=True))
    def add_argv(argv: list) -> list[str] | str:
        """Return a list of Python commands that add command-line arguments to the sys.argv list.

        Args:
            argv (list): A list of command-line arguments to be added to sys.argv.

        Returns:
            list[str] | str: A list of Python commands that add the specified command-line arguments to sys.argv.
        """
        if not isinstance(argv, list):
            return [f'sys.argv.append("{argv}")']
        else:
            return [f'sys.argv.append("{arg}")' for arg in argv]

    @staticmethod
    @validate_call(config=ConfigDict(strict=True))
    def add_env_var(name: list | str, value: list | str) -> list[str] | str:
        """Return a list of Python commands that set environment variables.

        Args:
            name (list): A list of environment variable names to be set.
            value (list): A list of values corresponding to the environment variable names.

        Returns:
            list[str] | str: A list of Python commands that set the specified environment variables to the specified values.
        """
        if not isinstance(name, list):
            return f'os.environ["{name}"] = "{value}"'
        else:
            return [f'os.environ["{var_name}"] = "{var_value}"' for (var_name, var_value) in zip(name, value)]
