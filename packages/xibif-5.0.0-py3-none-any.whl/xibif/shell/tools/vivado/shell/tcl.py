"""Defines the Vivado Tcl shell class, which manages a Vivado Tcl shell session and provides commands and filters specific to the Vivado Tcl environment."""

from pydantic import ConfigDict, validate_call
from ....shell import Shell


class VivadoTclShell(Shell):
    """Class to manage a Vivado Tcl shell session, providing commands and filters specific to the Vivado Tcl environment."""

    @property
    @validate_call(config=ConfigDict(strict=True))
    def _start_shell_arguments(self) -> list[str]:
        """Return the arguments required to start the Vivado Tcl shell.

        Returns:
            list[str]: A list of command-line arguments to start the shell.
        """
        return [
            "-mode",
            "tcl",
            "-nolog",
            "-nojournal",
        ]

    @property
    @validate_call(config=ConfigDict(strict=True))
    def _close_shell_command(self) -> str:
        """Return the command used to close the Vivado Tcl shell.

        Returns:
            str: The command to close the shell.
        """
        return "exit"

    @property
    @validate_call(config=ConfigDict(strict=True))
    def _open_shell_command(self) -> str:
        """Return the command used to open the Vivado Tcl shell.

        Returns:
            str: The command to open the shell.
        """
        return ""

    @property
    @validate_call(config=ConfigDict(strict=True))
    def _filter_ready(self) -> list[str]:
        """Return the list of regular expressions used to detect when the shell is ready for input.

        Returns:
            list[str]: A list of regular expressions to detect shell readiness.
        """
        return ["^.*%SCREADY%.*$"]

    @property
    @validate_call(config=ConfigDict(strict=True))
    def _command_ready(self) -> str:
        """Return the regular expression used to detect when a command has finished executing and the shell is ready for the next command.

        Returns:
            str: A regular expression to detect when the shell is ready for the next command.
        """
        return 'puts "%SCREADY%"'

    @property
    @validate_call(config=ConfigDict(strict=True))
    def _filter_upgrade_warning(self) -> list[str]:
        """Return the list of regular expressions used to filter out upgrade warnings from the shell output.

        Returns:
            list[str]: A list of regular expressions to filter out upgrade warnings.
        """
        return ["^.*CRITICAL WARNING:.*$"]

    @property
    @validate_call(config=ConfigDict(strict=True))
    def _filter(self) -> list[str]:
        """Return the list of regular expressions used to filter the shell output.

        Returns:
            list[str]: A list of regular expressions to filter the shell output.
        """
        return [""]
