from .tcl import VivadoTclShell as tcl

VivadoShell = tcl

__all__ = [
    'tcl',
]