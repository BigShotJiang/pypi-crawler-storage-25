from .kv260 import get_board_settings as get_kv260_settings
from .zcu102 import get_board_settings as get_zcu102_settings
from .zcu104 import get_board_settings as get_zcu104_settings
from .zedboard import get_board_settings as get_zedboard_settings
from .zyboz10 import get_board_settings as get_zyboz10_settings
from .zyboz20 import get_board_settings as get_zyboz20_settings
from ......types.boards import XilinxBoard

BOARD_SETTINGS_GETTERS = {
    XilinxBoard.ZEDBOARD: get_zedboard_settings,
    XilinxBoard.ZYBOZ720: get_zyboz20_settings,
    XilinxBoard.ZYBOZ710: get_zyboz10_settings,
    XilinxBoard.ZCU104: get_zcu104_settings,
    XilinxBoard.ZCU102: get_zcu102_settings,
    XilinxBoard.KV260: get_kv260_settings,
}
