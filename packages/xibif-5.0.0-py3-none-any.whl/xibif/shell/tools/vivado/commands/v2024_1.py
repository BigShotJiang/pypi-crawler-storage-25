"""Defines the Vivado 2023.2 Tcl command set, including implementations of abstract methods from the base Tcl command set and any version-specific commands or overrides."""

from .base_tcl import VivadoTclCommandSet


class Vivado20241CommandSet(VivadoTclCommandSet):
    """Defines the Tcl command set for Vivado 2024.1, including implementations of abstract methods from the base Tcl command set and any version-specific commands or overrides."""
