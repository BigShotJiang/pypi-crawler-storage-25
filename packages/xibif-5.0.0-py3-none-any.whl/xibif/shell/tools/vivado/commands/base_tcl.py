"""Defines the command set for the Vivado Tcl shell environment, including commands for project management, block design manipulation, file management, run control, and other operations specific to the Vivado Tcl environment."""

from pydantic import ConfigDict, validate_call
from .....types import XibifPath, XilinxBoard, XibifValidationError
from ....fpgatoolcommandset import FpgaToolCommandSet
from .board_settings import BOARD_SETTINGS_GETTERS


class VivadoTclCommandSet(FpgaToolCommandSet):
    """Defines the command set for the Vivado Tcl shell environment, including commands for project management, block design manipulation, file management, run control, and other operations specific to the Vivado Tcl environment."""

    @staticmethod
    @validate_call(config=ConfigDict(strict=True))
    def __get_board_settings(board: XilinxBoard) -> dict:
        """Return board-specific Vivado settings.

        Args:
            board (XilinxBoard): Target board identifier.

        Returns:
            dict: Board settings dictionary used to parameterize commands.
        """
        return BOARD_SETTINGS_GETTERS[board]()

    @staticmethod
    @validate_call(config=ConfigDict(strict=True))
    def print_to_console(s) -> list[str] | str:
        """Create a Tcl command that prints text to the console.

        Args:
            s (str): Message text.

        Returns:
            list[str] | str: Tcl puts command.
        """
        return f'puts "{s}"'

    @staticmethod
    @validate_call(config=ConfigDict(strict=True))
    def open_project(project_path: XibifPath) -> list[str] | str:
        """Open an existing Vivado project.

        Args:
            project_path (XibifPath): Path to the project file or directory.

        Returns:
            list[str] | str: Tcl commands to print a header and open the project.
        """
        project_path = project_path.as_tcl()
        return [VivadoTclCommandSet.print_header(f"Opening Project {project_path}"), f"open_project {project_path}"]

    @staticmethod
    @validate_call(config=ConfigDict(strict=True))
    def close_project() -> list[str] | str:
        """Close the current Vivado project.

        Returns:
            list[str] | str: Tcl command to close the project.
        """
        return "close_project"

    @staticmethod
    @validate_call(config=ConfigDict(strict=True))
    def check_device_installed(board: XilinxBoard) -> list[str] | str:
        """Check whether the required FPGA device files are installed.

        Args:
            board (XilinxBoard): Target board identifier.

        Returns:
            list[str] | str: Tcl command that raises an error if the part is unavailable.
        """
        board_settings = VivadoTclCommandSet.__get_board_settings(board)
        fpga = board_settings["fpga"]
        return f'if {{![llength [get_parts {fpga}]]}} {{ error "FPGA part {fpga} not installed. Please install the required device files via the Vivado Installer." }}'

    @staticmethod
    @validate_call(config=ConfigDict(strict=True))
    def create_project(project_name: str, project_path: XibifPath, board: XilinxBoard) -> list[str] | str:
        """Create a Vivado project configured for the selected board.

        Args:
            project_name (str): Name of the project.
            project_path (XibifPath): Output location for the project.
            board (XilinxBoard): Target board identifier.

        Returns:
            list[str] | str: Tcl commands to create and initialize the project.
        """
        project_path = project_path.as_tcl()
        board_settings = VivadoTclCommandSet.__get_board_settings(board)

        return [
            VivadoTclCommandSet.print_header(f"Creating Project {project_name}"),
            f'create_project {project_name} {project_path} -part {board_settings["fpga"]}',
            f'set_property part {board_settings["fpga"]} [current_project]',
            "set_property target_language VHDL [current_project]",
            "update_ip_catalog",
            "set_msg_config -id {Synth 8-327} -new_severity {CRITICAL WARNING}",  # Increase warning about latches to a critical warning
        ]

    @staticmethod
    @validate_call(config=ConfigDict(strict=True))
    def create_wrapper(block_design_name: str) -> list[str] | str:
        """Generate and import the HDL wrapper for a block design.

        Args:
            block_design_name (str): Block design name without extension.

        Returns:
            list[str] | str: Tcl commands to create wrapper and generate targets.
        """
        return [f"make_wrapper -files [get_files -quiet {block_design_name}.bd] -top -import -force", f"generate_target all [get_files -quiet {block_design_name}.bd]"]

    @staticmethod
    @validate_call(config=ConfigDict(strict=True))
    def recreate_wrapper(block_design_name: str) -> list[str] | str:
        """Remove and regenerate the HDL wrapper for a block design.

        Args:
            block_design_name (str): Block design name without extension.

        Returns:
            list[str] | str: Tcl commands to remove and recreate wrapper files.
        """
        return [f"remove_files -fileset sources_1 [get_files -quiet {block_design_name}_wrapper.vhd]", VivadoTclCommandSet.create_wrapper(block_design_name)]

    @staticmethod
    @validate_call(config=ConfigDict(strict=True))
    def create_block_design(block_design_name: str) -> list[str] | str:
        """Create a new block design and generate its wrapper.

        Args:
            block_design_name (str): Name of the block design.

        Returns:
            list[str] | str: Tcl commands to create, select, and wrap the block design.
        """
        return [
            VivadoTclCommandSet.print_header(f"Creating Block Design {block_design_name}"),
            f"create_bd_design {block_design_name}",
            f"current_bd_design {block_design_name}",
            VivadoTclCommandSet.create_wrapper(block_design_name),
        ]

    @staticmethod
    @validate_call(config=ConfigDict(strict=True))
    def open_block_design(block_design_name: str) -> list[str] | str:
        """Open an existing block design in Vivado.

        Args:
            block_design_name (str): Name of the block design.

        Returns:
            list[str] | str: Tcl commands to print a header and open the block design.
        """
        return [VivadoTclCommandSet.print_header(f"Opening Blockdesign {block_design_name}"), f"open_bd_design [get_files -quiet {block_design_name}.bd]"]

    @staticmethod
    @validate_call(config=ConfigDict(strict=True))
    def save_block_design(block_design_name: str) -> list[str] | str:
        """Validate and save a block design, then regenerate wrapper output.

        Args:
            block_design_name (str): Name of the block design.

        Returns:
            list[str] | str: Tcl commands to validate, save, and regenerate outputs.
        """
        return ["validate_bd_design", "regenerate_bd_layout", "save_bd_design", f"generate_target all [get_files -quiet {block_design_name}.bd]", VivadoTclCommandSet.create_wrapper(block_design_name)]

    @staticmethod
    @validate_call(config=ConfigDict(strict=True))
    def update_module_reference(module_name: str) -> list[str] | str:
        """Update an IP module reference in the current project.

        Args:
            module_name (str): Name or wildcard pattern of modules to update.

        Returns:
            list[str] | str: Tcl command to update module reference.
        """
        return f"update_module_reference [get_ips {module_name}]"

    @staticmethod
    @validate_call(config=ConfigDict(strict=True))
    def update_all_module_references(block_design_name: str) -> list[str] | str:
        """Update and save all locked module references for a block design.

        Args:
            block_design_name (str): Name of the block design.

        Returns:
            list[str] | str: Tcl command list for reporting, upgrading, and saving IP references.
        """
        return [
            VivadoTclCommandSet.open_block_design(block_design_name),
            VivadoTclCommandSet.print_header("Updating locked module references"),
            "report_ip_status -quiet",
            "upgrade_ip [get_ips];",
            "report_ip_status -quiet",
            VivadoTclCommandSet.update_module_reference("*"),
            VivadoTclCommandSet.save_block_design(block_design_name),
        ]

    @staticmethod
    @validate_call(config=ConfigDict(strict=True))
    def add_xibif_to_block_design(block_design_name: str, board: XilinxBoard) -> list[str] | str:
        """Insert XiBIF and required interconnect IP into a block design.

        Args:
            block_design_name (str): Name of the target block design.
            board (XilinxBoard): Target board identifier.

        Returns:
            list[str] | str: Tcl command sequence to instantiate, connect, and validate XiBIF components.
        """
        board_settings = VivadoTclCommandSet.__get_board_settings(board)
        return [
            VivadoTclCommandSet.print_header(f"Adding XiBIF to block design {block_design_name}"),
            "set_msg_config -id {BD 41-967} -new_severity {INFO}",
            "set_msg_config -id {BD 41-237} -new_severity {INFO}",
            f"current_bd_design {block_design_name}",
            "current_bd_instance [get_bd_cells /]",
            "set XiBIF [create_bd_cell -type module -reference XiBIF_Peri XiBIF]",
            "set XiBIF_REG [create_bd_cell -type module -reference XiBIF_regs XiBIF_REG]",
            "set axi_mem_intercon [create_bd_cell -type ip -vlnv xilinx.com:ip:smartconnect:1.0 axi_mem_intercon]",
            "set_property -dict [list CONFIG.NUM_MI {1} CONFIG.NUM_SI {1}] $axi_mem_intercon",
            "set peri [create_bd_cell -type ip -vlnv xilinx.com:ip:smartconnect:1.0 peri]",
            "set_property -dict [list CONFIG.NUM_MI {2} CONFIG.NUM_SI {1}] $peri",
            "set rst [create_bd_cell -type ip -vlnv xilinx.com:ip:proc_sys_reset:5.0 rst]",
            "set clk_wiz [create_bd_cell -type ip -vlnv xilinx.com:ip:clk_wiz:6.0 clk_wiz]",
            "set firewall [create_bd_cell -type ip -vlnv xilinx.com:ip:axi_firewall:1.2 axi_firewall]",
            "set_property -dict [list CONFIG.ENABLE_INITIAL_DELAY {0} CONFIG.ENABLE_PRESCALER {0} CONFIG.ENABLE_PROTOCOL_CHECKS {0} CONFIG.MASK_ERR_RESP {1}] $firewall",
            "set peri_firewall [create_bd_cell -type ip -vlnv xilinx.com:ip:smartconnect:1.0 peri_firewall]",
            "set_property -dict [list CONFIG.NUM_MI {1} CONFIG.NUM_SI {1}] $peri_firewall",
            f'set processing_system [create_bd_cell -type ip -vlnv {board_settings["processing_system"]} processing_system]',
            board_settings["cmd_add_xibif_1"],
            "connect_bd_intf_net -intf_net AXI [get_bd_intf_pins XiBIF/M_AXI] [get_bd_intf_pins axi_mem_intercon/S00_AXI]",
            "connect_bd_intf_net -intf_net AXIL0 [get_bd_intf_pins axi_firewall/S_AXI_CTL] [get_bd_intf_pins peri_firewall/M00_AXI]",
            "connect_bd_intf_net -intf_net AXIL1 [get_bd_intf_pins XiBIF/S_AXIL] [get_bd_intf_pins peri/M00_AXI]",
            "connect_bd_intf_net -intf_net AXIL2 [get_bd_intf_pins XiBIF_REG/axil] [get_bd_intf_pins peri/M01_AXI]",
            "connect_bd_intf_net -intf_net AXIGP [get_bd_intf_pins axi_firewall/M_AXI] [get_bd_intf_pins peri/S00_AXI]",
            "connect_bd_net -net MainxC [get_bd_pins XiBIF/ClkxCI] [get_bd_pins XiBIF_REG/clk] [get_bd_pins axi_mem_intercon/aclk] [get_bd_pins peri/aclk] [get_bd_pins clk_wiz/MainxC] [get_bd_pins processing_system/*aclk] [get_bd_pins rst/slowest_sync_clk] [get_bd_pins axi_firewall/aclk] [get_bd_pins peri_firewall/aclk]",
            "connect_bd_net -net areset_n [get_bd_pins XiBIF/RstxRBI] [get_bd_pins XiBIF_REG/rst] [get_bd_pins axi_mem_intercon/aresetn] [get_bd_pins peri/aresetn] [get_bd_pins rst/peripheral_aresetn] [get_bd_pins axi_firewall/aresetn] [get_bd_pins peri_firewall/aresetn]",
            board_settings["cmd_add_xibif_2"],
            "connect_bd_intf_net -intf_net AXIS [get_bd_intf_pins XiBIF/AXIS_FROM_PC] [get_bd_intf_pins XiBIF/AXIS_TO_PC]",
            "connect_bd_net -net demo_reg [get_bd_pins XiBIF_REG/csr_register_2_demo_out] [get_bd_pins XiBIF_REG/csr_register_1_demo_in]",
            "set_property CONFIG.CLK_DOMAIN [get_property CONFIG.CLK_DOMAIN [get_bd_intf_pins axi_mem_intercon/S00_AXI]] [get_bd_intf_pins XiBIF/M_AXI]",
            VivadoTclCommandSet.set_block_design_top(block_design_name),
            VivadoTclCommandSet.save_block_design(block_design_name),
            "set_property CONFIG.CLK_DOMAIN [get_property CONFIG.CLK_DOMAIN [get_bd_intf_pins axi_mem_intercon/S00_AXI]] [get_bd_intf_pins XiBIF/M_AXI]",  # Command needs to be repeated again after the first validation
            VivadoTclCommandSet.save_block_design(block_design_name),
        ]

    @staticmethod
    @validate_call(config=ConfigDict(strict=True))
    def set_block_design_top(block_design_name: str) -> list[str] | str:
        """Set the wrapper of a block design as top module.

        Args:
            block_design_name (str): Name of the block design.

        Returns:
            list[str] | str: Tcl command to set the fileset top property.
        """
        return f"set_property top {block_design_name}_wrapper [current_fileset]"

    @staticmethod
    @validate_call(config=ConfigDict(strict=True))
    def set_ooc_run(mode: str, block_design_name: str) -> list[str] | str:
        """Configure out-of-context synthesis checkpoint mode for a block design.

        Args:
            mode (str): OOC mode, one of "None", "Hierarchical", or "Singular".
            block_design_name (str): Name of the block design.

        Returns:
            list[str] | str: Tcl command that updates synthesis checkpoint mode.

        Raises:
            XibifValidationError: If mode is not one of the supported values.
        """
        if mode in {"None", "Hierarchical", "Singular"}:
            return f"set_property synth_checkpoint_mode {mode} [get_files -quiet {block_design_name}.bd]"
        else:
            raise XibifValidationError(f'Unexpected mode {mode}. Expecting one of {"None", "Hierarchical", "Singular"}')

    @staticmethod
    @validate_call(config=ConfigDict(strict=True))
    def export_hardware(hardware_path: XibifPath, include_bitstream: bool) -> list[str] | str:
        """Export hardware platform from the current Vivado project.

        Args:
            hardware_path (XibifPath): Destination path for exported hardware.
            include_bitstream (bool): Whether to include bitstream in export.

        Returns:
            list[str] | str: Tcl commands to write hardware platform files.
        """
        hardware_path = hardware_path.as_tcl()
        if include_bitstream:
            return [VivadoTclCommandSet.print_header(f"Exporting hardware to {hardware_path}"), f"write_hw_platform -fixed -force -include_bit -file {hardware_path}"]
        else:
            return [VivadoTclCommandSet.print_header(f"Exporting hardware to {hardware_path}"), f"write_hw_platform -fixed -force -file {hardware_path}"]

    @staticmethod
    @validate_call(config=ConfigDict(strict=True))
    def add_design_file(file_path: XibifPath | list[XibifPath]) -> list[str] | str:
        """Add one or more design source files to the project.

        Args:
            file_path (XibifPath): Path or list of paths to design files.

        Returns:
            list[str] | str: Tcl command that adds design files without recursion.
        """
        if isinstance(file_path, XibifPath):
            file_path = file_path.as_tcl()
            return f"add_files -norecurse {file_path}"
        elif isinstance(file_path, list):
            return f'add_files -norecurse {" ".join(file.as_tcl() for file in file_path)}'

        return ""

    @staticmethod
    @validate_call(config=ConfigDict(strict=True))
    def remove_design_file(file_path: XibifPath | list[XibifPath]) -> list[str] | str:
        """Remove one or more design source files from the project.

        Args:
            file_path (XibifPath): Path or list of paths to design files.

        Returns:
            list[str] | str: Tcl command that removes matching files.
        """
        if isinstance(file_path, XibifPath):
            file_path = file_path.as_tcl()
            return f"remove_files {file_path}"
        elif isinstance(file_path, list):
            return f'remove_filese {" ".join(file.as_tcl() for file in file_path)}'

    @staticmethod
    @validate_call(config=ConfigDict(strict=True))
    def remove_design_file_by_keyword(keyword: str) -> list[str] | str:
        """Remove design files by file query keyword.

        Args:
            keyword (str): Pattern passed to get_files.

        Returns:
            list[str] | str: Tcl command that removes all matching files.
        """
        return f"remove_files [get_files -quiet {keyword}]"

    @staticmethod
    @validate_call(config=ConfigDict(strict=True))
    def add_simulation_file(file_path: XibifPath | list[XibifPath]) -> list[str] | str:
        """Add one or more simulation files to the sim_1 fileset.

        Args:
            file_path (XibifPath): Path or list of paths to simulation files.

        Returns:
            list[str] | str: Tcl command that adds simulation files.
        """
        if isinstance(file_path, XibifPath):
            file_path = file_path.as_tcl()
            return f"add_files -fileset sim_1 -norecurse -quiet {file_path}"
        elif isinstance(file_path, list):
            return f'add_files -fileset sim_1 -norecurse -quiet {" ".join(file.as_tcl() for file in file_path)}'

    @staticmethod
    @validate_call(config=ConfigDict(strict=True))
    def remove_simulation_file(file_path: XibifPath) -> list[str] | str:
        """Remove simulation files from the project.

        Args:
            file_path (XibifPath): Path or list of paths to simulation files.

        Returns:
            list[str] | str: Tcl command list reusing generic file removal.
        """
        return [VivadoTclCommandSet.remove_design_file(file_path)]

    @staticmethod
    @validate_call(config=ConfigDict(strict=True))
    def add_constraint_file(file_path: XibifPath | list[XibifPath]) -> list[str] | str:
        """Read one or more unmanaged XDC constraint files.

        Args:
            file_path (XibifPath): Path or list of paths to constraint files.

        Returns:
            list[str] | str: Tcl command that reads XDC files.
        """
        if isinstance(file_path, XibifPath):
            file_path = file_path.as_tcl()
            return f"read_xdc -quiet -unmanaged {file_path}"
        elif isinstance(file_path, list):
            return f'read_xdc -unmanaged {" ".join(file.as_tcl() for file in file_path)}'

    @staticmethod
    @validate_call(config=ConfigDict(strict=True))
    def remove_constraint_file(file_path: XibifPath) -> list[str] | str:
        """Remove constraint files from the project.

        Args:
            file_path (XibifPath): Path or list of paths to constraint files.

        Returns:
            list[str] | str: Tcl command list reusing generic file removal.
        """
        return [VivadoTclCommandSet.remove_design_file(file_path)]

    @staticmethod
    @validate_call(config=ConfigDict(strict=True))
    def set_libary(file_path: XibifPath | list[XibifPath], library: str) -> list[str] | str:
        """Set the VHDL library property on one or more files.

        Args:
            file_path (XibifPath): Path or list of paths to source files.
            library (str): Library name to assign.

        Returns:
            list[str] | str: Tcl command that applies library property.
        """
        if isinstance(file_path, XibifPath):
            file_path = file_path.as_tcl()
            return f"set_property library {library} [get_files {file_path}]"
        elif isinstance(file_path, list):
            return f'set_property library {library} [get_files {" ".join(file.as_tcl() for file in file_path)}]'

    @staticmethod
    @validate_call(config=ConfigDict(strict=True))
    def set_property(file_path: XibifPath | list[XibifPath], property_name: str, value: str) -> list[str] | str:
        """Set an arbitrary file property on one or more files.

        Args:
            file_path (XibifPath): Path or list of paths to source files.
            property_name (str): Name of the property to set.
            value (str): Property value.

        Returns:
            list[str] | str: Tcl command that applies the property.
        """
        if isinstance(file_path, XibifPath):
            file_path = file_path.as_tcl()
            return f"set_property {property_name} {{{value}}} [get_files {file_path}]"
        elif isinstance(file_path, list):
            return f'set_property {property_name} {{{value}}} [get_files {" ".join(file.as_tcl() for file in file_path)}]'

    @staticmethod
    @validate_call(config=ConfigDict(strict=True))
    def reset_run(run: str) -> list[str] | str:
        """Reset a synthesis or implementation run.

        Args:
            run (str): Run name.

        Returns:
            list[str] | str: Tcl command that resets the run.
        """
        return f"reset_run {run}"

    @staticmethod
    @validate_call(config=ConfigDict(strict=True))
    def launch_runs(runs: list[str] | str, parameter: str = "") -> list[str] | str:
        """Launch one or multiple runs with optional parameters.

        Args:
            runs (list[str]): Run name or list of run names.
            parameter (str): Additional launch argument string.

        Returns:
            list[str] | str: Tcl launch command.
        """
        if isinstance(runs, str):
            return f"launch_runs {runs} {parameter}"
        elif isinstance(runs, list):
            return f'launch_runs {" ".join(str(run) for run in runs)} {parameter}'

    @staticmethod
    @validate_call(config=ConfigDict(strict=True))
    def wait_on_run(run: str) -> list[str] | str:
        """Wait until a run has finished.

        Args:
            run (str): Run name.

        Returns:
            list[str] | str: Tcl command that blocks until run completion.
        """
        return f"wait_on_run {run}"

    @staticmethod
    @validate_call(config=ConfigDict(strict=True))
    def check_run(run: str) -> list[str] | str:
        """Check run completion status and fail script on errors.

        Args:
            run (str): Run name.

        Returns:
            list[str] | str: Tcl commands that validate run status and print result.
        """
        return [
            f"set run_status [get_property STATUS [get_runs {run}]]",
            'if {[string match "*Complete*" $run_status] == 0} {',
            f'error "ERROR: Run {run} failed with status: $run_status"',
            "exit 1",
            "} else {",
            f'puts "Run {run} completed successfully with status: $run_status"',
            "}",
        ]

    @staticmethod
    @validate_call(config=ConfigDict(strict=True))
    def force_no_refresh(run: str) -> list[str] | str:
        """Disable automatic refresh requirement for a run object.

        Args:
            run (str): Run name.

        Returns:
            list[str] | str: Tcl command that clears needs_refresh.
        """
        return f"set_property needs_refresh false {run}"

    @staticmethod
    @validate_call(config=ConfigDict(strict=True))
    def open_run(run: str) -> list[str] | str:
        """Open a run only when it differs from the last opened run.

        Args:
            run (str): Run name.

        Returns:
            list[str] | str: Tcl command sequence that conditionally opens the run.
        """
        return [
            f'if {{[info exists last_run] && $last_run ne "{run}"}} {{',
            f"    open_run {run}",
            f"    set last_run {run}",
            "} elseif {![info exists last_run]} {",
            f"    open_run {run}",
            f"    set last_run {run}",
            "}",
        ]

    @staticmethod
    @validate_call(config=ConfigDict(strict=True))
    def implement(run: str | None, to_bitstream: bool = False, noopen: bool = False) -> list[str] | str:
        """Run implementation flow for a given run.

        Args:
            run (str): Run name, or empty to use current implementation run.
            to_bitstream (bool): Whether to stop at write_bitstream step.
            noopen (bool): Whether to skip opening run at the end.

        Returns:
            list[str] | str: Tcl commands for implementation and status checks.
        """
        if run in ("", None):
            run = "[current_run -implementation -quiet]"

        if to_bitstream:
            run_command = VivadoTclCommandSet.launch_runs(run, "-to_step write_bitstream")
        else:
            run_command = VivadoTclCommandSet.launch_runs(run)

        return [
            VivadoTclCommandSet.print_header(f"Implementing design {run}"),
            VivadoTclCommandSet.reset_run(run),
            run_command,
            VivadoTclCommandSet.wait_on_run(run),
            VivadoTclCommandSet.check_run(run),
            VivadoTclCommandSet.force_no_refresh(run),
            VivadoTclCommandSet.open_run(run) if not noopen else "",
        ]

    @staticmethod
    @validate_call(config=ConfigDict(strict=True))
    def synthesize(run: str | None, noopen: bool = False) -> list[str] | str:
        """Run synthesis flow for a given run.

        Args:
            run (str): Run name, or empty to use current synthesis run.
            noopen (bool): Whether to skip opening run at the end.

        Returns:
            list[str] | str: Tcl commands for synthesis and status checks.
        """
        if run in ("", None):
            run = "[current_run -synthesis -quiet]"

        return [
            VivadoTclCommandSet.print_header(f"Synthesizing design {run}"),
            VivadoTclCommandSet.reset_run(run),
            VivadoTclCommandSet.launch_runs(run),
            VivadoTclCommandSet.wait_on_run(run),
            VivadoTclCommandSet.check_run(run),
            VivadoTclCommandSet.force_no_refresh(run),
            VivadoTclCommandSet.open_run(run) if not noopen else "",
        ]

    @staticmethod
    @validate_call(config=ConfigDict(strict=True))
    def report_timing(prefix: str, report_path: XibifPath) -> list[str] | str:
        """Generate timing reports into the given report directory.

        Args:
            prefix (str): Filename prefix for output reports.
            report_path (XibifPath): Output directory for report files.

        Returns:
            list[str] | str: Tcl commands for timing summary and detailed timing report.
        """
        report_timing_summary = report_path.joinpath(f"{prefix}_timing_summary.rpt").as_tcl()
        report_timing = report_path.joinpath(f"{prefix}_timing.rpt").as_tcl()
        return [f"report_timing_summary -file {report_timing_summary}", f"report_timing -sort_by group -max_paths 100 -path_type summary -file {report_timing}"]

    @staticmethod
    @validate_call(config=ConfigDict(strict=True))
    def report_power(prefix: str, report_path: XibifPath) -> list[str] | str:
        """Generate a power report file.

        Args:
            prefix (str): Filename prefix for output report.
            report_path (XibifPath): Output directory for report file.

        Returns:
            list[str] | str: Tcl command that writes power report.
        """
        report_power = report_path.joinpath(f"{prefix}_power.rpt").as_tcl()
        return f"report_power -file {report_power}"

    @staticmethod
    @validate_call(config=ConfigDict(strict=True))
    def report_utilization(prefix: str, report_path: XibifPath) -> list[str] | str:
        """Generate a utilization report file.

        Args:
            prefix (str): Filename prefix for output report.
            report_path (XibifPath): Output directory for report file.

        Returns:
            list[str] | str: Tcl command that writes utilization report.
        """
        report_util = report_path.joinpath(f"{prefix}_util.rpt").as_tcl()
        return f"report_utilization -file {report_util}"

    @staticmethod
    @validate_call(config=ConfigDict(strict=True))
    def report_clock_utilization(prefix: str, report_path: XibifPath) -> list[str] | str:
        """Generate a clock utilization report file.

        Args:
            prefix (str): Filename prefix for output report.
            report_path (XibifPath): Output directory for report file.

        Returns:
            list[str] | str: Tcl command that writes clock utilization report.
        """
        report_clock_util = report_path.joinpath(f"{prefix}_clock_util.rpt").as_tcl()
        return f"report_clock_utilization -file {report_clock_util}"

    @staticmethod
    @validate_call(config=ConfigDict(strict=True))
    def report_drc(prefix: str, report_path: XibifPath) -> list[str] | str:
        """Generate a design rule check report file.

        Args:
            prefix (str): Filename prefix for output report.
            report_path (XibifPath): Output directory for report file.

        Returns:
            list[str] | str: Tcl command that writes DRC report.
        """
        report_drc = report_path.joinpath(f"{prefix}_drc.rpt").as_tcl()
        return f"report_drc -file {report_drc}"

    @staticmethod
    @validate_call(config=ConfigDict(strict=True))
    def report_all(prefix: str, report_path: XibifPath) -> list[str] | str:
        """Generate the standard set of implementation reports.

        Args:
            prefix (str): Filename prefix for output reports.
            report_path (XibifPath): Output directory for report files.

        Returns:
            list[str] | str: Tcl commands for timing, power, utilization, clock, and DRC reports.
        """
        return [
            VivadoTclCommandSet.report_timing(prefix, report_path),
            VivadoTclCommandSet.report_power(prefix, report_path),
            VivadoTclCommandSet.report_utilization(prefix, report_path),
            VivadoTclCommandSet.report_clock_utilization(prefix, report_path),
            VivadoTclCommandSet.report_drc(prefix, report_path),
        ]

    @staticmethod
    @validate_call(config=ConfigDict(strict=True))
    def write_checkpoint(checkpoint_path: XibifPath) -> list[str] | str:
        """Write a design checkpoint file.

        Args:
            checkpoint_path (XibifPath): Destination path for the checkpoint.

        Returns:
            list[str] | str: Tcl command that writes the checkpoint.
        """
        checkpoint_path = checkpoint_path.as_tcl()
        return f"write_checkpoint -force {checkpoint_path}"

    @staticmethod
    @validate_call(config=ConfigDict(strict=True))
    def write_bitstream(bitstream_path: XibifPath, run: str | None) -> list[str] | str:
        """Copy or generate bitstream and associated debug probes file.

        Args:
            bitstream_path (XibifPath): Destination path for the bitstream file.
            run (str): Run name, or empty to use current implementation run.

        Returns:
            list[str] | str: Tcl commands that copy existing outputs or write bitstream.
        """
        bitstream_path_changed = bitstream_path.as_tcl()
        ltxfile_path = bitstream_path.with_suffix(".ltx").as_tcl()

        if run in ("", None):
            run = "[current_run -implementation -quiet]"

        return [
            "set proj_name [get_property NAME [current_project]]",
            "set proj_dir [get_property DIRECTORY [current_project]]",
            "set top_name [get_property TOP [current_fileset]]",
            f"set run_name {run}",
            'set bitfile "${proj_dir}/${proj_name}.runs/${run_name}/${top_name}.bit"',
            'set ltxfile "${proj_dir}/${proj_name}.runs/${run_name}/${top_name}.ltx"',
            "if {[file exists $bitfile]} {",
            f"    file copy -force $bitfile {bitstream_path_changed}",
            "} else {",
            f"    write_bitstream -force {bitstream_path_changed}",
            "}",
            "if {[file exists $ltxfile]} {",
            f"    file copy -force $ltxfile {ltxfile_path}",
            "}",
        ]

    @staticmethod
    @validate_call(config=ConfigDict(strict=True))
    def generate_bitstream(run: str | None, noopen: bool = False) -> list[str] | str:
        """Launch write_bitstream step for a run and verify completion.

        Args:
            run (str): Run name, or empty to use current implementation run.
            noopen (bool): Whether to skip opening run at the end.

        Returns:
            list[str] | str: Tcl commands for bitstream generation and checks.
        """
        if run in ("", None):
            run = "[current_run -implementation -quiet]"

        return [
            VivadoTclCommandSet.print_header(f"Generating bitstream {run}"),
            VivadoTclCommandSet.launch_runs(run, "-to_step write_bitstream"),
            VivadoTclCommandSet.wait_on_run(run),
            VivadoTclCommandSet.check_run(run),
            VivadoTclCommandSet.force_no_refresh(run),
            VivadoTclCommandSet.open_run(run) if not noopen else "",
        ]

    @staticmethod
    @validate_call(config=ConfigDict(strict=True))
    def report_timing_run(run: str | None) -> list[str] | str:
        """Run timing checks for a completed implementation run.

        Args:
            run (str): Run name, or empty to use current implementation run.

        Returns:
            list[str] | str: Tcl commands for reporting timing and enforcing timing closure.
        """
        if run in ("", None):
            run = "[current_run -implementation -quiet]"
        return [
            VivadoTclCommandSet.print_header(f"Timing Report Summary for {run}"),
            VivadoTclCommandSet.open_run(run),
            "report_timing -delay_type min_max -path_type end -no_header -warn_on_violation",
            VivadoTclCommandSet.print_header(f"Check Timing Report for {run}"),
            "check_timing -no_header -exclude {no_input_delay no_output_delay partial_input_delay partial_output_delay} -verbose",
            VivadoTclCommandSet.print_header(f"Check Timing {run}"),
            f"set wns_number [get_property STATS.WNS [get_runs {run}]]",
            f"set whs_number [get_property STATS.WHS [get_runs {run}]]",
            "if {[expr {$wns_number < 0.0 || $whs_number < 0.0}]} {",
            'error "ERROR: Failed to meet timings."',
            "} else {",
            'puts "Timing is met."',
            "}",
        ]

    @staticmethod
    @validate_call(config=ConfigDict(strict=True))
    def run_file(file_path: XibifPath) -> list[str] | str:
        """Source and execute a Tcl script file.

        Args:
            file_path (XibifPath): Path to the Tcl script.

        Returns:
            list[str] | str: Tcl source command.
        """
        file_path = file_path.as_tcl()
        return f"source {file_path}"
