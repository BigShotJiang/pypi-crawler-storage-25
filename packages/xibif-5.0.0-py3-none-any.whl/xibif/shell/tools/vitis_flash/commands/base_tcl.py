"""Defines the command set for the Vitis Flash TCL shell environment, including commands for connecting to hardware servers and flashing devices."""

from typing import Annotated
from pydantic import ConfigDict, validate_call, Field
from pydantic.networks import IPvAnyAddress
from ....flashtoolcommandset import FlashToolCommandSet
from .....types import XibifPath, XilinxBoard


class VitisFlashTclCommandSet(FlashToolCommandSet):
    """Defines the command set for the Vitis Flash TCL shell environment, including commands for connecting to hardware servers andflashing devices."""

    @staticmethod
    @validate_call(config=ConfigDict(strict=True))
    def print_to_console(s) -> list[str] | str:
        """Return a TCL command that prints a message to the console.

        Args:
            s (str): The message to be printed.
        Returns:
            str: A TCL command that prints the message to the console.
        """
        return f'puts "{s}"'

    @staticmethod
    @validate_call(config=ConfigDict(strict=True))
    def disconnect() -> str:
        """Return a TCL command that disconnects from the hardware server.

        Returns:
            str: A TCL command that disconnects from the hardware server.
        """
        return [
            "if {$connected == 1} {",
            VitisFlashTclCommandSet.print_header("Disconnect"),
            "disconnect",
            "}",
        ]

    @staticmethod
    @validate_call(config=ConfigDict(strict=True))
    def connect_ps() -> list[str] | str:
        """Return a TCL command that connects to the processing system (PS) of the target device.

        Returns:
            list[str] | str: A TCL command that connects to the PS of the target device.
        """
        return [
            "if {$connected == 1} {",
            VitisFlashTclCommandSet.print_header("Connect to PS"),
            "con",
            "}",
        ]

    @staticmethod
    @validate_call(config=ConfigDict(strict=True))
    def connect_hwserver(hw_server: IPvAnyAddress, port: Annotated[int, Field(ge=1, le=65535)]) -> list[str] | str:
        """Return a list of TCL commands that connect to the Xilinx hardware server at the specified IP address and port.

        Args:
            hw_server (IPvAnyAddress): The IP address of the hardware server to connect to.
            port (Annotated[int, Field(ge=1, le=65535)]): The port number of the hardware server to connect to.

        Returns:
            list[str] | str: A list of TCL commands that connect to the hardware server.
        """
        return [
            VitisFlashTclCommandSet.print_header(f"Connect to Hardware Server {hw_server}:{port}"),
            f"connect -new -url TCP:{hw_server}:{port}",
            "if {[catch {targets} result]} {",
            '    puts "Error: Failed to connect to hardware server."',
            "    set connected 0",
            "} else {",
            '    puts "Successfully connected to hardware server."',
            "    set connected 1",
            "}",
        ]

    @staticmethod
    @validate_call(config=ConfigDict(strict=True))
    def flash(board: XilinxBoard, hardware_path: XibifPath, fsbl_path: XibifPath, bitstream_path: XibifPath, elf_path: XibifPath) -> list[str] | str:
        """Return a list of TCL commands that flash the target device with the specified hardware, FSBL, bitstream, and ELF files based on the specified Xilinx board.

        Args:
            board (XilinxBoard): The Xilinx board to be flashed.
            hardware_path (XibifPath): The path to the hardware description file (.hdf) for the target device.
            fsbl_path (XibifPath): The path to the FSBL ELF file for the target device.
            bitstream_path (XibifPath): The path to the bitstream file (.bit) for the target device.
            elf_path (XibifPath): The path to the application ELF file for the target device.

        Returns:
            list[str] | str: A list of TCL commands that flash the target device based on the specified board and file paths.
        """
        ps7_init_path = hardware_path.parent.joinpath("ps7_init.tcl").as_tcl()
        hardware_path = hardware_path.as_tcl()
        fsbl_path = fsbl_path.as_tcl()
        bitstream_path = bitstream_path.as_tcl()
        elf_path = elf_path.as_tcl()

        if board in {XilinxBoard.ZEDBOARD, XilinxBoard.ZYBOZ720, XilinxBoard.ZYBOZ710}:
            return [
                "if {$connected == 1} {",
                VitisFlashTclCommandSet.print_header(f"Flash {board.value}"),
                'targets -set -filter {name =~ "A* #0"}',
                "rst",
                "after 4000",
                f"fpga {bitstream_path}",
                f"loadhw {hardware_path}",
                f"source {ps7_init_path}",
                "ps7_init",
                "ps7_post_config",
                "after 4000",
                f"dow {elf_path}",
                "}",
            ]
        else:
            return [
                "if {$connected == 1} {",
                VitisFlashTclCommandSet.print_header(f"Flash {board.value}"),
                'targets -set -nocase -filter {name =~ "*PSU*"}',
                "mwr 0xff5e0200 0x0100",
                "rst -system",
                'targets -set -nocase -filter {name =~ "APU*"}',
                "rst -system",
                "after 4000",
                f"fpga -file {bitstream_path}",
                'targets -set -filter {name =~ "APU*"}',
                f"loadhw {hardware_path}",
                "configparams force-mem-access 1",
                'targets -set -nocase -filter {name =~ "APU*"}',
                "set mode [expr [mrd -value 0xFF5E0200] & 0xf]",
                'targets -set -nocase -filter {name =~ "*A53*#0"}',
                "rst -processor -clear-registers",
                "after 4000",
                f"dow {fsbl_path}",
                "set bp_37_20_fsbl_bp [bpadd -addr &XFsbl_Exit]",
                "con -block -timeout 60",
                "bpremove $bp_37_20_fsbl_bp",
                'targets -set -filter {name =~ "*A53*#0"}',
                "rst -processor",
                "after 4000",
                f"dow {elf_path}",
                "configparams force-mem-access 0",
                'targets -set -filter {name =~ "*A53*#0"}',
                "}",
            ]
