"""Defines the command set for the Vitis Flash TCL shell environment for Vitis 2025.1, including commands for connecting to hardware servers and flashing devices, as well as any version-specific commands or overrides."""

from .base_tcl import VitisFlashTclCommandSet


class Vitis20251FlashCommandSet(VitisFlashTclCommandSet):
    """Defines the command set for the Vitis Flash TCL shell environment for Vitis 2025.1, including commands for connecting to hardware servers and flashing devices, as well as any version-specific commands or overrides."""
