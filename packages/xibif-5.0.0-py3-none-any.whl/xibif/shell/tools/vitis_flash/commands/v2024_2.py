"""Defines the command set for the Vitis Flash TCL shell environment for Vitis 2024.1, including commands for connecting to hardware servers and flashing devices, as well as any version-specific commands or overrides."""

from .base_tcl import VitisFlashTclCommandSet


class Vitis20242FlashCommandSet(VitisFlashTclCommandSet):
    """Defines the command set for the Vitis Flash TCL shell environment for Vitis 2024.2, including commands for connecting to hardware servers and flashing devices, as well as any version-specific commands or overrides."""
