"""Utility functions for XiBIF."""

import os
import random
import platform
import getpass
from typing import Any
import subprocess
from importlib.metadata import version
import shutil
import psutil
from pydantic import ConfigDict, validate_call
from pydantic_extra_types.mac_address import MacAddress
from ..types import XilinxVersion, XilinxToolPath, XibifPath, XibifVersion
from ..types.messages import XibifMessage
from ..logger import LoggerStage as LS, xibif_print_debug, xibif_print_warning, xibif_print_error


@validate_call(config=ConfigDict(strict=True))
def get_version(version_str: str = version("xibif")) -> XibifVersion:
    """Parse a version string into a XibifVersion data class.

    Args:
        version_str (str): The version string to parse. Defaults to the version of the 'xibif' package.

    Returns:
        XibifVersion: A data class containing the major, minor, and patch version numbers.
    """
    version_full = version_str.split(".")

    # Check if the version is a pre-release
    if len(version_full) > 3:
        version_full[3] = version_full[3].split("+")[0].removeprefix("dev")
        while len(version_full) > 4:
            version_full.pop(4)
    else:
        version_full.append("0")

    return XibifVersion(
        major=int(version_full[0]),
        minor=int(version_full[1]),
        patch=int(version_full[2]),
        revision=int(version_full[3]),
    )


@validate_call(config=ConfigDict(strict=True))
def generate_random_mac() -> MacAddress:
    """Generate a random MAC address.

    Returns:
        MacAddress: A randomly generated MAC address.
    """
    mac_prefix = [0x00, 0x0A, 0x35]
    mac_suffix = [random.randint(0x00, 0xFF) for _ in range(3)]
    mac_address = mac_prefix + mac_suffix
    mac_address_str = ":".join(f"{byte:02x}" for byte in mac_address)
    return MacAddress(mac_address_str)


@validate_call(config=ConfigDict(strict=True))
def igetattr(obj: Any, attr: str, default=None) -> Any:
    """Case-insensitive getattr that returns a default value if the attribute is not found.

    Args:
        obj (any): The object to get the attribute from.
        attr (str): The name of the attribute to get.
        default (any, optional): The default value to return if the attribute is not found. Defaults to None.

    Returns:
        any: The value of the requested attribute, or the default value if the attribute is not found.
    """
    for a in dir(obj):
        if a.lower() == attr.lower():
            return getattr(obj, a)

    xibif_print_debug(f"Attribute '{attr}' not found in object of type '{type(obj).__name__}'. Returning default value: {default}", stage=LS.NO_CHANGE)
    return default


@validate_call(config=ConfigDict(strict=True))
def get_default_xilinx_path() -> XibifPath:
    """Get the default path to the Xilinx installation directory based on the operating system.

    Returns:
        XibifPath: The default path to the Xilinx installation directory for the current operating system.
    """
    system = platform.system()
    if system == "Windows":
        return XibifPath("C:\\Xilinx")
    elif system == "Linux":
        return XibifPath("/opt/Xilinx")
    elif system == "Darwin":
        return XibifPath("/Applications/Xilinx")
    else:
        return XibifPath("")


@validate_call(config=ConfigDict(strict=True))
def scan_xilinx_version(xilinx_path: XibifPath) -> XilinxVersion | None:
    """Scan the given Xilinx installation path for installed Xilinx tool versions and return the latest valid version found.

    Args:
        xilinx_path (XibifPath): The path to the Xilinx installation directory to scan for installed versions.

    Returns:
        XilinxVersion | None: The latest valid XilinxVersion found in the given installation path, or None if no valid version is found.
    """
    if not xilinx_path.is_dir():
        return None

    versions = set()

    # Strategy 1: Find versions prior to 2025.1
    # Structure: <path>/vivado/<version> and <path>/vitis/<version>
    vivado_path = xilinx_path.joinpath("vivado")
    vitis_path = xilinx_path.joinpath("vitis")
    if vivado_path.is_dir() and vitis_path.is_dir():
        vivado_versions = {p.name for p in vivado_path.glob("[0-9]*") if p.is_dir()}
        vitis_versions = {p.name for p in vitis_path.glob("[0-9]*") if p.is_dir()}
        versions.update(vivado_versions & vitis_versions)

    # Strategy 2: Find versions 2025.1 and later
    # Structure: <path>/<version>/vivado and <path>/<version>/vitis
    for version_dir in xilinx_path.glob("[0-9]*"):
        vivado_path = version_dir.joinpath("vivado")
        vitis_path = version_dir.joinpath("vitis")
        if version_dir.is_dir() and vivado_path.is_dir() and vitis_path.is_dir():
            versions.add(version_dir.name)

    # Filter for valid versions that are defined in the XilinxVersion
    enum_versions = {xv.value for xv in XilinxVersion}
    valid_versions = [v for v in versions if v in enum_versions]

    # Return the latest valid version found, or None if no valid version is found
    if valid_versions:
        return XilinxVersion(sorted(valid_versions, reverse=True)[0])

    return None


@validate_call(config=ConfigDict(strict=True))
def check_tool_running(tool_name: str) -> bool:
    """Check if a tool with the given name is currently running on the system.

    Args:
        tool_name (str): The name of the tool to check.

    Returns:
        bool: True if the tool is running, False otherwise.
    """
    # Get the current OS username
    current_user = getpass.getuser()
    tool_name = tool_name.lower()

    for proc in psutil.process_iter(["name", "cmdline", "username"]):
        try:
            # Check if the usernames matches
            if not current_user in (proc.info["username"] or "").lower():
                continue

            # Skip xibif processes to avoid false positives
            if "xibif" in (proc.info["name"] or "").lower():
                continue
            if any("xibif" in (arg or "").lower() for arg in (proc.info["cmdline"] or [])):
                continue

            # Check if tool matches
            if tool_name in (proc.info["name"] or "").lower():
                xibif_print_debug(f"Tool '{tool_name}' is running: {proc.info}", stage=LS.NO_CHANGE)
                return True

            if any(tool_name in (arg or "").lower() for arg in (proc.info["cmdline"] or [])):
                xibif_print_debug(f"Tool '{tool_name}' is running: {proc.info}", stage=LS.NO_CHANGE)
                return True

        except (psutil.NoSuchProcess, psutil.AccessDenied):
            continue
    return False


@validate_call(config=ConfigDict(strict=True))
def check_tool_running_and_ask(tool: str) -> bool:
    """
    Check if a tool is running in the background and ask the user if they want to continue.

    Args:
        tool (str): The name of the tool to check.

    Returns:
        bool: True if the user wants to continue, False otherwise.
    """
    if check_tool_running(tool):
        return XibifMessage(
            title="WARNING",
            message=f"It was detected that the tool '{tool}' is running in the background. \nThis might interfere with the current command. \nMake sure that you have your XiBIF project not open in this tool.",
        ).ask(ask="Is your project closed?")
    return True


@validate_call(config=ConfigDict(strict=True))
def start_tool(executable: XibifPath, cmdline_params: str | list[str] = "") -> None:
    """Starts a tool with command line parameters

    Args:
        executable (Path): The path to the executable of the tool.
        cmdline_params (str | list[str], optional): The command line parameters to pass to the tool. Defaults to ''.
    """
    xibif_print_debug(f"Starting tool: {executable} {cmdline_params}", stage=LS.NO_CHANGE)

    # Convert cmdline_params to a string if it is a list
    params = " ".join(cmdline_params) if isinstance(cmdline_params, list) else cmdline_params

    # Generate the command string based on the operating system
    if platform.system() == "Windows":
        path_to_cmd = XibifPath(os.getenv("windir")).joinpath("system32", "cmd.exe")
        cmd_string = f"{str(path_to_cmd)} /c start {executable} {params}"

    else:
        if check_tool("gnome-terminal") is not None:
            cmd_string = f'gnome-terminal -- bash -c "{executable} {params}; exec bash"'
        else:
            cmd_string = f'bash -c "{executable} {params}; exec bash"'

    # Start the tool
    xibif_print_debug(f"Executing command: {cmd_string}", stage=LS.NO_CHANGE)
    subprocess.Popen(cmd_string, shell=True)


@validate_call(config=ConfigDict(strict=True))
def check_tool(name: str) -> bool:
    """
    Check if a tool with the given name is available in the system.

    Args:
        name (str): The name of the tool to check.

    Returns:
        bool: True if the tool is available, False otherwise.
    """
    return shutil.which(name) is not None


@validate_call(config=ConfigDict(strict=True))
def check_windows_shell() -> bool:
    """Check if the current shell is a Windows shell (cmd or powershell) or a Unix-like shell (bash, zsh, etc.).

    Returns:
        bool: True if the current shell is a Windows shell, False if it is a Unix-like shell.
    """
    # Detect Shell
    if platform.system() == "Windows":
        if "PSModulePath" in os.environ:
            return True
        elif "cmd.exe" in os.getenv("COMSPEC").lower():
            return True
        else:  # MinGW
            return False
    else:  # POSIX (Linux, Mac, or MinGW)
        return False


@validate_call(config=ConfigDict(strict=True))
def get_xilinx_tool_paths(xilinx_path: XibifPath, xilinx_version: XilinxVersion) -> XilinxToolPath:
    """Given an installation path and a version, returns the absolute paths of the Xilinx tools as a dictionary.

    If the files are not found at the given installation, the function tries to fall back using 'which'.

    Args:
        xilinx_path (XibifPath): The path to the Xilinx installation directory.
        xilinx_version (XilinxVersion): The version of the Xilinx tools to get the paths for.

    Returns:
        XilinxToolPath: A data class containing the paths to the Xilinx tools.
    """
    # Get the name of the settings64 script based on the operating system
    settings64_name = "settings64.bat" if check_windows_shell() else "settings64.sh"

    # Since Version 2025.1 the tools are installed in a subfolder named "2025.1"
    if xilinx_version in [XilinxVersion.V2023_1, XilinxVersion.V2023_2, XilinxVersion.V2024_1, XilinxVersion.V2024_2]:
        basePathVivado = xilinx_path.joinpath("Vivado").joinpath(xilinx_version.value)
        basePathVitis = xilinx_path.joinpath("Vitis").joinpath(xilinx_version.value)
    else:
        basePathVivado = xilinx_path.joinpath(xilinx_version.value).joinpath("Vivado")
        basePathVitis = xilinx_path.joinpath(xilinx_version.value).joinpath("Vitis")

    # Generate paths for all tools
    tools = XilinxToolPath(
        vivado=basePathVivado.joinpath("bin", "vivado"),
        vitis=basePathVitis.joinpath("bin", "vitis"),
        xsct=basePathVitis.joinpath("bin", "xsct"),
        cs_server=basePathVivado.joinpath("bin", "cs_server"),
        hw_server=basePathVivado.joinpath("bin", "hw_server"),
        settings64_script=basePathVivado.joinpath(settings64_name),
    )

    # Verify if all tools exist, if not try to find them with 'which' and update the paths, if they cannot be found print an error and set them to None
    for tool, path in tools.items():
        if not path.exists():
            if tool != "settings64_script":
                fallback = shutil.which(tool)
            else:
                fallback = tools["vivado"].parent.parent.joinpath(settings64_name)
                if not fallback.exists():
                    fallback = None
            if fallback is None:
                xibif_print_error(f"Could not find a {tool} executable at '{path}' and no fallback found!", stage=LS.STARTUP)
                tools[tool] = None
            else:
                xibif_print_warning(f"Could not find a {tool} executable at '{path}', falling back to {fallback}", stage=LS.STARTUP)
                tools[tool] = XibifPath(fallback)

    return tools


@validate_call(config=ConfigDict(strict=True))
def get_clean_shell(path_clean_shell: XibifPath) -> str:
    """Get the command string to start a clean shell with the Xilinx settings script sourced.

    Args:
        path_clean_shell (XibifPath): The path to a script that creates a clean shell environment.

    Returns:
        str: The command string to start a clean shell with the Xilinx settings script sourced.
    """
    if check_windows_shell():
        return f"{XibifPath(os.getenv('windir')).joinpath('system32/cmd.exe')} /c {str(path_clean_shell)}"
    else:
        return "bash -c"


@validate_call(config=ConfigDict(strict=True))
def get_clean_shell_batch_command(command: str | XibifPath) -> str:
    """Get the command string to run a command in a clean shell with the Xilinx settings script sourced.

    Args:
        command (str | XibifPath): The command to run in the clean shell.

    Returns:
        str: The command string to run the given command in a clean shell with the Xilinx settings script sourced.
    """
    if isinstance(command, XibifPath):
        command = str(command)

    if check_windows_shell():
        return f"{command} && "
    else:
        return f"source {command} && "
