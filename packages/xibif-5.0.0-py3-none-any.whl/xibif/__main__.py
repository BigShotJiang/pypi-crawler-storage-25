"""Run XiBIF from command line with arguments."""

import os
import sys
import traceback
from colorama import Fore
from loguru import logger
from pydantic import ConfigDict, validate_call
from .cli.parser import generate_parser
from .logger import LoggerStage as LS, setup_logger, xibif_print_debug, xibif_print_error, start_periodic_logger
from .types import XibifPath, XibifChecksumError
from .types.messages import XibifMessage
from .project import XibifProject

__all__ = ["main"]


@validate_call(config=ConfigDict(strict=True, arbitrary_types_allowed=True))
def handle_error(error: Exception) -> None:
    """
    Send an error message to Sentry and exit the program.

    Args:
        error (str): The error message to send to Sentry.
    """

    # Print the error message
    traceback_str = "".join(traceback.format_exception(type(error), error, error.__traceback__))
    error_msg = XibifMessage(
        title="An unexpected error occurred",
        message=[
            "An unexpected error occurred during the execution of XiBIF.",
            "This might be a bug in XiBIF or an issue with your project configuration.",
            "If the problem persists, consider reporting it using 'xibif report'.",
            f"Error stack trace: {traceback_str}",
        ],
    )
    xibif_print_error(str(error_msg))

    # Exit the program
    sys.exit(1)


def main():
    """
    Main function that parses arguments and runs the command.
    """
    # parse arguments
    parser = generate_parser()
    args = parser.parse_args()

    # Setup logger
    setup_logger(verbosity=getattr(args, "verbosity", "info"), summary=getattr(args, "summary", False))

    # Print the command to the console
    xibif_print_debug(f"Starting XiBIF CLI: {args}", stage=LS.STARTUP)
    xibif_print_debug(f"OS Variables: {os.environ}", stage=LS.STARTUP)

    # Open the project file
    with logger.bind(prefix="XIBIF", color=Fore.RED).catch(onerror=lambda e: handle_error(e)):  # pylint: disable=unnecessary-lambda
        # Create project
        project = XibifProject()

        # These commands do not require a project to be loaded, so we can run them directly without loading a project file
        if args.command in ("new", "log"):
            start_periodic_logger()
            project = args.func(project, args)

        else:

            # Determine the project path
            project_path = XibifPath.cwd()

            if args.project is not None:
                project_path = XibifPath(args.project).absolute()

            project.path = project_path

            # Load the project configuration and handle checksum errors
            try:
                project.load_config()
            except XibifChecksumError as e:
                if args.command != "upgrade":  # Hide the checksum warning during an upgrade as new fields in the project might lead to a different checksum
                    if not XibifMessage(
                        title="Checksum Mismatch",
                        message=f"Checksum mismatch for project configuration at {project.path}. The configuration file might be corrupted or manually edited.",
                    ).ask(ask="Do you want to continue anyway?"):
                        xibif_print_error(f"Aborting due to checksum mismatch. {e}", stage=LS.NO_CHANGE)
                        sys.exit(1)

            # Set the root path for the XibifPath utility
            XibifPath.set_root(project.path.resolve())

            # Execute the command
            if hasattr(args, "func"):
                start_periodic_logger()
                project = args.func(project, args)
            else:
                parser.print_help()

        # Save the project file
        if not args.command in ("log"):
            project.write_config()


if __name__ == "__main__":
    main()
