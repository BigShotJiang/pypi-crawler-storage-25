# Directory Structure

## Directories

### api
The API functions for XiBIF abstracting sets of commands. Calls the shell abstractions.

### cli
The command-line interface presented to the user. Calls the API.

### deps
The dependencies of the package. All files in this directory will be packaged as the original data.

### shell
The abstraction of the tool shells. Lowest level interface of XiBIF.

### tests
Unit and integration tests for the Python source code.

## Files

### deps.py
Dependency manager that distributes data from `deps` to any calling object. The program must not depend on the structure of the dependency folder.

### utils.py
All sorts of utility functions.

### XibifProject.py
Contains the `XibifProject` object, defining project structure, setup and some other metadata. Read/writes files.