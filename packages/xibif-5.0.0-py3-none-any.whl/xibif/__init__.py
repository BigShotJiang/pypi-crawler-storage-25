"""XiBIF - Xilinx Build and Integration Framework - Main package initialization."""

# pylint: disable=undefined-all-variable

from importlib import import_module

from .project import XibifProject

__all__ = ["XibifAPI", "XibifProject"]


def __getattr__(name: str):
    """Load package-level exports lazily to avoid import cycles at package import time."""
    if name == "XibifAPI":
        return import_module(".api", __name__)
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
