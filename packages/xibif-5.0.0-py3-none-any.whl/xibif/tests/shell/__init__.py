"""Tests for xibif.shell."""
