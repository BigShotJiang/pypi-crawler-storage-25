"""Tests for flash tool command set abstractions."""

# pylint: disable=missing-function-docstring,missing-class-docstring

import unittest

from xibif.shell.flashtoolcommandset import FlashToolCommandSet


class DummyFlashCommandSet(FlashToolCommandSet):
    """Concrete flash command set for abstract API tests."""

    @staticmethod
    def print_to_console(s: str) -> str:
        return s

    def disconnect(self, **kwargs) -> str:
        return "disconnect"

    def connect_hwserver(self, **kwargs) -> str:
        return "connect"

    def flash(self, **kwargs) -> str:
        return "flash"


class FlashToolCommandSetTests(unittest.TestCase):
    """Ensure the abstract interface can be implemented coherently."""

    def test_concrete_subclass_returns_expected_commands(self) -> None:
        command_set = DummyFlashCommandSet()

        self.assertEqual(command_set.connect_hwserver(), "connect")
        self.assertEqual(command_set.flash(), "flash")
        self.assertEqual(command_set.disconnect(), "disconnect")
