"""Tests for shell string helpers."""

# pylint: disable=missing-function-docstring,missing-class-docstring

import unittest

from xibif.shell.utils import filter_string, search_string


class ShellUtilsTests(unittest.TestCase):
    """Verify filtering and search helpers."""

    def test_filter_string_removes_all_matching_patterns(self) -> None:
        self.assertEqual(filter_string("hello READY world", ["READY", "world"]), "hello  ")

    def test_search_string_returns_first_match(self) -> None:
        self.assertEqual(search_string("READY now", ["READY.*", "ERROR.*"]), (0, "READY now"))

    def test_search_string_returns_none_when_no_pattern_matches(self) -> None:
        self.assertEqual(search_string("running", ["READY", "ERROR"]), (None, None))
