"""Tests for shell factory resolution."""

# pylint: disable=missing-function-docstring,missing-class-docstring

from unittest.mock import patch
import unittest

from xibif.shell.models import ShellTool
from xibif.shell.shellfactory import ShellFactory
from xibif.types import XibifPath, XibifRuntimeError, XilinxVersion


class ShellFactoryTests(unittest.TestCase):
    """Validate shell selection by tool and version."""

    @patch("xibif.shell.shellfactory.VivadoShell.tcl", return_value="vivado-shell")
    def test_create_shell_returns_versioned_vivado_shell(self, mock_shell) -> None:
        shell = ShellFactory.create_shell(ShellTool.VIVADO, XilinxVersion.V2024_2, executable=XibifPath("vivado"))

        self.assertEqual(shell, "vivado-shell")
        mock_shell.assert_called_once()

    @patch("xibif.shell.shellfactory.PythonShell.python", return_value="python-shell")
    def test_create_shell_returns_python_shell_without_version(self, mock_shell) -> None:
        shell = ShellFactory.create_shell(ShellTool.PYTHON, executable=XibifPath("python"))

        self.assertEqual(shell, "python-shell")
        mock_shell.assert_called_once()

    def test_create_shell_raises_for_missing_version(self) -> None:
        with self.assertRaises(XibifRuntimeError):
            ShellFactory.create_shell(ShellTool.VIVADO, executable=XibifPath("vivado"))
