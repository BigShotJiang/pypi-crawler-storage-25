"""Tests for Python tool command set abstractions."""

# pylint: disable=missing-function-docstring,missing-class-docstring

import unittest

from xibif.shell.pythontoolcommandset import PythonToolCommandSet
from xibif.types import XibifPath


class DummyPythonCommandSet(PythonToolCommandSet):
    """Concrete Python command set for interface tests."""

    @staticmethod
    def print_to_console(s: str) -> str:
        return s

    @staticmethod
    def run_file(file: XibifPath) -> list[str]:
        return ["python", file.as_posix()]

    @staticmethod
    def change_directory(directory: XibifPath) -> str:
        return f"cd {directory.as_posix()}"


class PythonToolCommandSetTests(unittest.TestCase):
    """Ensure the abstract Python interface can be implemented."""

    def test_concrete_subclass_builds_expected_commands(self) -> None:
        command_set = DummyPythonCommandSet()

        self.assertTrue(command_set.change_directory(XibifPath("src")).endswith("/src") or command_set.change_directory(XibifPath("src")).endswith("\\src"))
        self.assertTrue(command_set.run_file(XibifPath("run.py"))[1].endswith("/run.py") or command_set.run_file(XibifPath("run.py"))[1].endswith("\\run.py"))
