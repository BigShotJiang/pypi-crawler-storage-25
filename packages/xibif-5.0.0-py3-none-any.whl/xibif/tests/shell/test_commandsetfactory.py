"""Tests for the command set factory."""

# pylint: disable=missing-function-docstring,missing-class-docstring

from unittest.mock import patch
import unittest

from xibif.shell.commandsetfactory import CommandSetFactory
from xibif.shell.models import ShellTool
from xibif.types import XibifRuntimeError, XilinxVersion


class CommandSetFactoryTests(unittest.TestCase):
    """Validate command set resolution."""

    @patch("xibif.shell.commandsetfactory.VivadoCommands.v2024_2", return_value="vivado-cmd")
    def test_get_command_set_returns_versioned_vivado_commands(self, mock_commands) -> None:
        result = CommandSetFactory.get_command_set(ShellTool.VIVADO, XilinxVersion.V2024_2)

        self.assertEqual(result, "vivado-cmd")
        mock_commands.assert_called_once()

    @patch("xibif.shell.commandsetfactory.PythonCommands.python", return_value="python-cmd")
    def test_get_command_set_returns_python_commands_without_version(self, mock_commands) -> None:
        result = CommandSetFactory.get_command_set(ShellTool.PYTHON)

        self.assertEqual(result, "python-cmd")
        mock_commands.assert_called_once()

    def test_get_command_set_raises_for_missing_version_mapping(self) -> None:
        with self.assertRaises(XibifRuntimeError):
            CommandSetFactory.get_command_set(ShellTool.VIVADO)
