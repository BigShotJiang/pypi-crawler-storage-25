"""Tests for FPGA tool command set abstractions."""

# pylint: disable=missing-function-docstring,missing-class-docstring

import unittest

from xibif.shell.fpgatoolcommandset import FpgaToolCommandSet


class DummyFpgaCommandSet(FpgaToolCommandSet):
    """Concrete FPGA command set for interface tests."""

    @staticmethod
    def print_to_console(s: str) -> str:
        return s

    def implement(self, **kwargs) -> str:
        return "implement"

    def synthesize(self, **kwargs) -> str:
        return "synthesize"

    def generate_bitstream(self, **kwargs) -> str:
        return "bitstream"

    def write_bitstream(self, **kwargs) -> str:
        return "write-bit"

    def report_all(self, **kwargs) -> str:
        return "report-all"

    def write_checkpoint(self, **kwargs) -> str:
        return "checkpoint"

    def add_design_file(self, **kwargs) -> str:
        return "add-design"

    def add_simulation_file(self, **kwargs) -> str:
        return "add-sim"

    def add_constraint_file(self, **kwargs) -> str:
        return "add-constraint"

    def remove_design_file(self, **kwargs) -> str:
        return "remove-design"

    def remove_simulation_file(self, **kwargs) -> str:
        return "remove-sim"

    def remove_constraint_file(self, **kwargs) -> str:
        return "remove-constraint"

    def report_timing_run(self, **kwargs) -> str:
        return "timing"


class FpgaToolCommandSetTests(unittest.TestCase):
    """Ensure the abstract FPGA interface can be implemented."""

    def test_concrete_subclass_exposes_expected_operations(self) -> None:
        command_set = DummyFpgaCommandSet()

        self.assertEqual(command_set.synthesize(), "synthesize")
        self.assertEqual(command_set.implement(), "implement")
        self.assertEqual(command_set.report_timing_run(), "timing")
