"""Tests for PS tool command set helpers."""

# pylint: disable=missing-function-docstring,missing-class-docstring

from pathlib import Path
import tempfile
import unittest

from xibif.shell.pstoolcommandset import PsToolCommandSet
from xibif.types import XibifPath, XilinxBoard


class DummyPsCommandSet(PsToolCommandSet):
    """Concrete PS command set for helper tests."""

    @staticmethod
    def print_to_console(s: str) -> str:
        return s

    def set_workspace(self, **kwargs):
        return "set_workspace"

    def create_workspace(self, **kwargs):
        return "create_workspace"

    def create_platform(self, **kwargs):
        return "create_platform"

    def set_active_platform(self, **kwargs):
        return "set_active_platform"

    def create_domain(self, **kwargs):
        return "create_domain"

    def set_active_domain(self, **kwargs):
        return "set_active_domain"

    def create_application(self, **kwargs):
        return "create_application"

    def set_active_application(self, **kwargs):
        return "set_active_application"

    def add_file(self, **kwargs):
        return "add_file"

    def generate_platform(self, **kwargs):
        return "generate_platform"

    def set_application_config(self, **kwargs):
        return "set_application_config"

    def add_linker_script(self, **kwargs):
        return "add_linker_script"

    def config_domain(self, **kwargs):
        return "config_domain"

    def update_platform(self, **kwargs):
        return "update_platform"

    def generate_application(self, **kwargs):
        return "generate_application"

    def get_elf_path(self, **kwargs):
        return "get_elf_path"

    def clean_application(self, **kwargs):
        return "clean_application"

    def generate_bootfile(self, **kwargs):
        return "generate_bootfile"

    def copy_application(self, **kwargs):
        return "copy_application"


class PsToolCommandSetTests(unittest.TestCase):
    """Verify shared PS command set helpers."""

    def test_shorten_name_compacts_generated_names(self) -> None:
        self.assertEqual(DummyPsCommandSet.shorten_name("demo_platform_system"), "dmpfsys")

    def test_generate_bif_writes_zynq_format(self) -> None:
        temp_dir = tempfile.TemporaryDirectory()
        self.addCleanup(temp_dir.cleanup)
        bif_path = XibifPath(Path(temp_dir.name) / "BOOT.bif")

        DummyPsCommandSet.generate_bif(
            bif_path=bif_path,
            board=XilinxBoard.ZEDBOARD,
            fsbl_path=XibifPath("fsbl.elf"),
            bitstream_path=XibifPath("demo.bit"),
            elf_path=XibifPath("app.elf"),
        )

        content = bif_path.read_text()
        self.assertIn("arch = zynq", content)
        self.assertIn("[bootloader]", content)
