"""Tests for command set formatting."""

# pylint: disable=missing-function-docstring,missing-class-docstring

import unittest

from xibif.shell.commandset import CommandSet
from xibif.shell.models import ShellHeaderAlignment


class DummyCommandSet(CommandSet):
    """Minimal command set implementation for testing headers."""

    @staticmethod
    def print_to_console(s: str) -> str:
        return s


class CommandSetTests(unittest.TestCase):
    """Verify header rendering behavior."""

    def test_print_header_left_alignment_uses_minimum_width(self) -> None:
        header = DummyCommandSet.print_header("AB", width=2)

        self.assertEqual(len(header), 3)
        self.assertEqual(header[0], "=" * 7)
        self.assertEqual(header[1], "= AB  =")

    def test_print_header_center_alignment_strips_quotes(self) -> None:
        header = DummyCommandSet.print_header('"Title"', width=12, align=ShellHeaderAlignment.CENTER, header_char="#")

        self.assertEqual(header[0], "#" * 12)
        self.assertEqual(header[1], "# Title  #")

    def test_print_header_right_alignment_places_padding_on_left(self) -> None:
        header = DummyCommandSet.print_header("Done", width=12, align=ShellHeaderAlignment.RIGHT)

        self.assertEqual(header[1], "=     Done =")
