"""Tests for the abstract shell implementation."""

# pylint: disable=missing-function-docstring,missing-class-docstring

from pathlib import Path
import queue
import unittest
from unittest.mock import MagicMock, Mock, call, patch

from pydantic import ValidationError

from xibif.shell.shell import Shell
from xibif.types import XibifPath


class DummyShell(Shell):
    """Concrete shell subclass for testing the shared base class."""

    @property
    def _start_shell_arguments(self) -> list[str]:
        return ["--batch"]

    @property
    def _filter(self) -> list[str]:
        return ["FILTER"]

    @property
    def _filter_ready(self) -> list[str]:
        return ["READY"]

    @property
    def _filter_upgrade_warning(self) -> list[str]:
        return []

    @property
    def _command_ready(self) -> str:
        return "echo READY"

    @property
    def _close_shell_command(self) -> str:
        return "quit"

    @property
    def _open_shell_command(self) -> str:
        return "open"

    def get_output_from_shell(self) -> str | None:
        """Expose shell output retrieval for tests without external protected access."""
        return self._get_output_from_shell()

    def get_error_from_shell(self) -> str | None:
        """Expose shell error retrieval for tests without external protected access."""
        return self._get_error_from_shell()


class ShellTests(unittest.TestCase):
    """Validate process lifecycle and command dispatch."""

    def setUp(self) -> None:
        self.shell = DummyShell(XibifPath(Path("shell.exe")), "dummy")

    @patch("xibif.shell.shell.Shell.wait_for_execution")
    @patch("xibif.shell.shell.Shell._start_reading_threads")
    @patch("xibif.shell.shell.subprocess.Popen")
    def test_context_manager_opens_and_closes_process(self, mock_popen, mock_start_threads, mock_wait_execution) -> None:
        process = MagicMock()
        mock_popen.return_value = process

        with self.shell as shell:
            self.assertEqual(shell.process, process)

        mock_popen.assert_called_once()
        mock_start_threads.assert_called_once()
        mock_wait_execution.assert_called_once()
        process.stdin.close.assert_called_once()
        process.wait.assert_called_once()

    @patch.object(DummyShell, "send")
    @patch.object(DummyShell, "wait_for_execution")
    def test_run_supports_nested_command_sequences(self, mock_wait, mock_send) -> None:
        self.shell.run([["cmd1", "cmd2"], "cmd3"])

        mock_send.assert_has_calls([call("cmd1"), call("cmd2"), call("cmd3")])
        mock_wait.assert_called_once()

    def test_run_rejects_invalid_command_type(self) -> None:
        with self.assertRaises(ValidationError):
            self.shell.run(123)

    def test_get_output_and_error_return_none_on_empty_queue(self) -> None:
        self.shell.output_queue = Mock(get=Mock(side_effect=queue.Empty))
        self.shell.error_queue = Mock(get=Mock(side_effect=queue.Empty))

        self.assertIsNone(self.shell.get_output_from_shell())
        self.assertIsNone(self.shell.get_error_from_shell())

    @patch("xibif.shell.shell.search_string", return_value=(0, "READY now"))
    @patch.object(DummyShell, "_get_output_from_shell", return_value="READY now")
    def test_wait_for_string_returns_match(self, mock_output, mock_search) -> None:
        self.assertEqual(self.shell.wait_for_string(["READY"]), (0, "READY now"))
        mock_output.assert_called_once_with(timeout=1.0)
        mock_search.assert_called_once_with("READY now", ["READY"])

    @patch.object(DummyShell, "send")
    @patch.object(DummyShell, "wait_for_string")
    def test_wait_for_execution_sends_ready_command(self, mock_wait_for_string, mock_send) -> None:
        self.shell.wait_for_execution()

        mock_send.assert_called_once_with("echo READY")
        mock_wait_for_string.assert_called_once_with(["READY"])
