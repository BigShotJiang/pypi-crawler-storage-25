"""Tests for shell enums."""

# pylint: disable=missing-function-docstring,missing-class-docstring

import unittest

from xibif.shell.models import ShellHeaderAlignment, ShellTool


class ShellModelsTests(unittest.TestCase):
    """Validate shell enum definitions."""

    def test_shell_tool_members_exist(self) -> None:
        self.assertEqual([tool.name for tool in ShellTool], ["VIVADO", "VITIS", "VITIS_FLASH", "PYTHON"])

    def test_alignment_members_exist(self) -> None:
        self.assertEqual([alignment.name for alignment in ShellHeaderAlignment], ["LEFT", "CENTER", "RIGHT"])
