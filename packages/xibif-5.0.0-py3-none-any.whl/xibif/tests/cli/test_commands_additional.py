"""Additional tests for CLI command functions."""

# pylint: disable=missing-function-docstring,missing-class-docstring

import argparse
from datetime import datetime
from pathlib import Path
import tempfile
from types import SimpleNamespace
from unittest.mock import patch
import unittest

from xibif.api.build_stages import VitisStage
from xibif.cli.commands import build, flash, log, new, register, report, settings, simulate, start, testbench, upgrade
from xibif.project.project import XibifProject
from xibif.project.models import XibifTooling
from xibif.types import XibifChecksum, XibifDefaults, XibifPath, XilinxBoard, XilinxVersion, XibifStartTool, VunitSimulator


class NewProjectFake:
    """Simple fake project model for exercising new() branches."""

    def __init__(self) -> None:
        self.project_name = ""
        self.project_path = XibifPath(".")
        self.board = XilinxBoard.ZEDBOARD
        self.tooling = XibifTooling()
        self.register = SimpleNamespace(user_register_checksum=XibifChecksum("0"))
        self.uuid = 1

    @property
    def name(self) -> str:
        return self.project_name or "xibif"

    @name.setter
    def name(self, value: str) -> None:
        self.project_name = value


class CommandsAdditionalTests(unittest.TestCase):
    """Cover additional command branches not touched in baseline tests."""

    def _project(self) -> XibifProject:
        project = XibifProject()
        project.name = "demo"
        project.tooling = XibifTooling(xilinx_version=XilinxVersion.V2024_2, xilinx_path=XibifPath("C:/Xilinx"))
        return project

    @patch("xibif.cli.commands.sys.exit", side_effect=SystemExit(1))
    @patch("xibif.cli.commands.xibif_print_error")
    @patch("xibif.cli.commands.XibifProject", return_value=NewProjectFake())
    def test_new_exits_when_project_folder_exists_without_force_or_nuke(self, _mock_project, _mock_error, _mock_exit) -> None:
        temp_dir = tempfile.TemporaryDirectory()
        self.addCleanup(temp_dir.cleanup)
        args = argparse.Namespace(
            name="demo",
            path=temp_dir.name,
            force=False,
            nuke=False,
            board=XilinxBoard.ZEDBOARD,
            xilinx="C:/Xilinx",
            version=XilinxVersion.V2024_2,
        )

        with self.assertRaises(SystemExit):
            new(XibifProject(), args)

    @patch("xibif.cli.commands.api.setup.setup_openlogic_vivado")
    @patch("xibif.cli.commands.api.setup.setup_vitis_project")
    @patch("xibif.cli.commands.api.setup.setup_vivado_project")
    @patch("xibif.cli.commands.api.register.register_get_checksum", return_value=XibifChecksum("abcd"))
    @patch("xibif.cli.commands.api.register.register_generate_user")
    @patch("xibif.cli.commands.api.register.register_generate_stream")
    @patch("xibif.cli.commands.api.setup.setup_openlogic_files")
    @patch("xibif.cli.commands.api.setup.setup_git_repository")
    @patch("xibif.cli.commands.api.setup.setup_git_files")
    @patch("xibif.cli.commands.api.setup.setup_demo_files")
    @patch("xibif.cli.commands.api.setup.setup_sigasi_project")
    @patch("xibif.cli.commands.api.setup.setup_constraint_files")
    @patch("xibif.cli.commands.api.setup.setup_vunit_python_files")
    @patch("xibif.cli.commands.api.setup.setup_hdl_files")
    @patch("xibif.cli.commands.api.setup.setup_register_files")
    @patch("xibif.cli.commands.api.misc.misc_create_project_folder")
    @patch("xibif.cli.commands.api.misc.misc_reset_project_folder")
    @patch("xibif.cli.commands.XibifProject", return_value=NewProjectFake())
    def test_new_with_force_resets_existing_project_folder(
        self,
        _mock_project,
        mock_reset,
        _mock_create_project_folder,
        _mock_setup_register_files,
        _mock_setup_hdl_files,
        _mock_setup_vunit,
        _mock_setup_constraints,
        _mock_setup_sigasi,
        _mock_setup_demo,
        _mock_setup_git_files,
        _mock_setup_git_repo,
        _mock_setup_openlogic,
        _mock_register_stream,
        _mock_register_user,
        _mock_register_checksum,
        _mock_setup_vivado,
        _mock_setup_vitis,
        _mock_setup_openlogic_vivado,
    ) -> None:
        temp_dir = tempfile.TemporaryDirectory()
        self.addCleanup(temp_dir.cleanup)
        args = argparse.Namespace(
            name="demo",
            path=temp_dir.name,
            force=True,
            nuke=False,
            board=XilinxBoard.ZEDBOARD,
            xilinx="C:/Xilinx",
            version=XilinxVersion.V2024_2,
        )

        new(XibifProject(), args)

        mock_reset.assert_called_once()

    @patch("xibif.cli.commands.api.setup.setup_openlogic_vivado")
    @patch("xibif.cli.commands.api.setup.setup_vitis_project")
    @patch("xibif.cli.commands.api.setup.setup_vivado_project")
    @patch("xibif.cli.commands.api.register.register_get_checksum", return_value=XibifChecksum("abcd"))
    @patch("xibif.cli.commands.api.register.register_generate_user")
    @patch("xibif.cli.commands.api.register.register_generate_stream")
    @patch("xibif.cli.commands.api.setup.setup_openlogic_files")
    @patch("xibif.cli.commands.api.setup.setup_git_repository")
    @patch("xibif.cli.commands.api.setup.setup_git_files")
    @patch("xibif.cli.commands.api.setup.setup_demo_files")
    @patch("xibif.cli.commands.api.setup.setup_sigasi_project")
    @patch("xibif.cli.commands.api.setup.setup_constraint_files")
    @patch("xibif.cli.commands.api.setup.setup_vunit_python_files")
    @patch("xibif.cli.commands.api.setup.setup_hdl_files")
    @patch("xibif.cli.commands.api.setup.setup_register_files")
    @patch("xibif.cli.commands.api.misc.misc_create_project_folder")
    @patch("xibif.cli.commands.api.misc.misc_nuke_project_folder")
    @patch("xibif.cli.commands.XibifProject", return_value=NewProjectFake())
    def test_new_with_nuke_deletes_existing_project_folder(
        self,
        _mock_project,
        mock_nuke,
        _mock_create_project_folder,
        _mock_setup_register_files,
        _mock_setup_hdl_files,
        _mock_setup_vunit,
        _mock_setup_constraints,
        _mock_setup_sigasi,
        _mock_setup_demo,
        _mock_setup_git_files,
        _mock_setup_git_repo,
        _mock_setup_openlogic,
        _mock_register_stream,
        _mock_register_user,
        _mock_register_checksum,
        _mock_setup_vivado,
        _mock_setup_vitis,
        _mock_setup_openlogic_vivado,
    ) -> None:
        temp_dir = tempfile.TemporaryDirectory()
        self.addCleanup(temp_dir.cleanup)
        args = argparse.Namespace(
            name="demo",
            path=temp_dir.name,
            force=False,
            nuke=True,
            board=XilinxBoard.ZEDBOARD,
            xilinx="C:/Xilinx",
            version=XilinxVersion.V2024_2,
        )

        new(XibifProject(), args)

        mock_nuke.assert_called_once()

    @patch("xibif.cli.commands.sys.exit", side_effect=SystemExit(1))
    @patch("xibif.cli.commands.XibifTooling", side_effect=ValueError("invalid tooling"))
    @patch("xibif.cli.commands.XibifProject", return_value=NewProjectFake())
    def test_new_exits_on_invalid_tooling_values(self, _mock_project, _mock_tooling, _mock_exit) -> None:
        temp_dir = tempfile.TemporaryDirectory()
        self.addCleanup(temp_dir.cleanup)
        args = argparse.Namespace(
            name="demo",
            path=str(Path(temp_dir.name) / "demo"),
            force=False,
            nuke=False,
            board=XilinxBoard.ZEDBOARD,
            xilinx="C:/Xilinx",
            version="not-a-version",
        )

        with self.assertRaises(SystemExit):
            new(XibifProject(), args)

    @patch("xibif.cli.commands.start_tool")
    @patch("xibif.cli.commands.get_xilinx_tool_paths")
    def test_start_vivado_uses_gui_project_argument(self, mock_get_tools, mock_start_tool) -> None:
        mock_get_tools.return_value = SimpleNamespace(vivado=XibifPath("C:/Xilinx/Vivado/bin/vivado"), vitis=XibifPath("vitis"), hw_server=XibifPath("hw"))
        project = self._project()
        args = argparse.Namespace(tool=XibifStartTool.VIVADO)

        start(project, args)

        self.assertTrue(mock_start_tool.call_args.kwargs["cmdline_params"].startswith("-mode gui"))

    @patch("xibif.cli.commands.start_tool")
    @patch("xibif.cli.commands.get_xilinx_tool_paths")
    def test_start_vitis_2023_2_uses_classic_mode(self, mock_get_tools, mock_start_tool) -> None:
        mock_get_tools.return_value = SimpleNamespace(vivado=XibifPath("vivado"), vitis=XibifPath("vitis"), hw_server=XibifPath("hw"))
        project = self._project()
        project.tooling = XibifTooling(xilinx_version=XilinxVersion.V2023_2, xilinx_path=XibifPath("C:/Xilinx"))
        args = argparse.Namespace(tool=XibifStartTool.VITIS)

        start(project, args)

        self.assertIn("-classic --workspace", mock_start_tool.call_args.kwargs["cmdline_params"])

    @patch("xibif.cli.commands.start_tool")
    @patch("xibif.cli.commands.get_xilinx_tool_paths")
    def test_start_hardware_server(self, mock_get_tools, mock_start_tool) -> None:
        hw_server = XibifPath("C:/Xilinx/Vivado/bin/hw_server")
        mock_get_tools.return_value = SimpleNamespace(vivado=XibifPath("vivado"), vitis=XibifPath("vitis"), hw_server=hw_server)

        start(self._project(), argparse.Namespace(tool=XibifStartTool.HARDWARE_SERVER))

        mock_start_tool.assert_called_once_with(hw_server)

    @patch("xibif.cli.commands.__settings_print")
    def test_settings_prints_when_no_mutations_requested(self, mock_settings_print) -> None:
        project = self._project()
        args = argparse.Namespace(project="ignored", verbosity="ignored", command="settings", func="ignored", summary=False)

        settings(project, args)

        mock_settings_print.assert_called_once_with(project.settings)

    @patch("xibif.cli.commands.api.misc.misc_update_vitis_header_file")
    def test_settings_updates_value_and_regenerates_header(self, mock_update_header) -> None:
        project = self._project()
        args = argparse.Namespace(enable_webserver=False)

        settings(project, args)

        self.assertFalse(project.settings.enable_webserver)
        mock_update_header.assert_called_once_with(settings=project.settings)

    @patch("xibif.cli.commands.api.simulate.simulation_compile")
    def test_simulate_compile_branch(self, mock_compile) -> None:
        project = self._project()
        args = argparse.Namespace(compile=True, list=False, test=[], gui=False, simulator=VunitSimulator.MODELSIM)

        simulate(project, args)

        mock_compile.assert_called_once_with(simulator=VunitSimulator.MODELSIM)

    @patch("xibif.cli.commands.api.simulate.simulation_list_testbenches")
    def test_simulate_list_branch(self, mock_list) -> None:
        project = self._project()
        args = argparse.Namespace(compile=False, list=True, test=[], gui=False, simulator=VunitSimulator.GHDL)

        simulate(project, args)

        mock_list.assert_called_once_with(simulator=VunitSimulator.GHDL)

    @patch("xibif.cli.commands.api.simulate.simulation_run", return_value=True)
    def test_simulate_gui_without_tb_disables_gui_and_runs(self, mock_run) -> None:
        project = self._project()
        args = argparse.Namespace(compile=False, list=False, test=[], gui=True, simulator=VunitSimulator.MODELSIM)

        simulate(project, args)

        mock_run.assert_called_once_with(testbench=[], gui=False, simulator=VunitSimulator.MODELSIM)

    @patch("xibif.cli.commands.sys.exit", side_effect=SystemExit(1))
    @patch("xibif.cli.commands.xibif_print_error")
    @patch("xibif.cli.commands.get_stages_between", return_value=([], []))
    def test_build_exits_when_from_to_has_no_stages(self, _mock_stages_between, _mock_print_error, _mock_exit) -> None:
        project = self._project()
        args = argparse.Namespace(stage=[], **{"from": "build-vivado", "to": "build-vivado"}, nowarn=True, noreport_vivado=False, fix_vitis=False)

        with self.assertRaises(SystemExit):
            build(project, args)

    @patch("xibif.cli.commands.api.build.build_vitis_regenerate")
    @patch("xibif.cli.commands.check_tool_running_and_ask", return_value=True)
    def test_build_fix_vitis_runs_regenerate(self, _mock_check_tool, mock_regenerate) -> None:
        project = self._project()
        project.vitis_path_check = XibifPath("moved")
        args = argparse.Namespace(stage=[], **{"from": None, "to": None}, nowarn=True, noreport_vivado=False, fix_vitis=True)

        build(project, args)

        mock_regenerate.assert_called_once()
        self.assertEqual(project.vitis_path_check, XibifDefaults.VITIS_FOLDER)

    @patch("xibif.cli.commands.sys.exit", side_effect=SystemExit(1))
    @patch("xibif.cli.commands.XibifMessage")
    @patch("xibif.cli.commands.api.register.register_get_checksum")
    def test_build_exits_on_outdated_user_register_if_user_declines(self, mock_checksum, mock_message, _mock_exit) -> None:
        project = self._project()
        project.register.user_register_checksum = XibifChecksum("0001")
        mock_checksum.return_value = XibifChecksum("0002")
        mock_message.return_value.ask.return_value = False
        args = argparse.Namespace(stage=[], **{"from": None, "to": None}, nowarn=False, noreport_vivado=False, fix_vitis=False)

        with self.assertRaises(SystemExit):
            build(project, args)

    @patch("xibif.cli.commands.api.build.build_vitis")
    @patch("xibif.cli.commands.api.misc.misc_update_vitis_header_file")
    @patch("xibif.cli.commands.XibifDefaultsMessages.WARNING_MESSAGE_MOVED_VITIS.ask", return_value=True)
    @patch("xibif.cli.commands.check_tool_running_and_ask", return_value=True)
    @patch("xibif.cli.commands.api.register.register_get_checksum")
    @patch("xibif.cli.commands.get_stages", return_value=([], [VitisStage.build]))
    def test_build_accepts_moved_vitis_and_resets_path_check(self, _mock_get_stages, mock_checksum, _mock_check_tool, _mock_ask_moved, mock_update_header, mock_build_vitis) -> None:
        project = self._project()
        project.vitis_path_check = XibifPath("moved")
        project.register.user_register_checksum = XibifChecksum("abcd")
        mock_checksum.return_value = XibifChecksum("abcd")
        args = argparse.Namespace(stage=["build-vitis"], **{"from": None, "to": None}, nowarn=False, noreport_vivado=False, fix_vitis=False)

        build(project, args)

        self.assertEqual(project.vitis_path_check, XibifDefaults.VITIS_FOLDER)
        mock_update_header.assert_called_once_with(settings=project.settings)
        mock_build_vitis.assert_called_once()

    @patch("xibif.cli.commands.sys.exit", side_effect=SystemExit(1))
    @patch("xibif.cli.commands.xibif_print_error")
    def test_register_custom_without_enable_exits(self, _mock_print_error, _mock_exit) -> None:
        project = self._project()
        args = argparse.Namespace(stream=False, user=False, custom=True, enable_custom=None, disable_custom=False)

        with self.assertRaises(SystemExit):
            register(project, args)

    def test_register_disable_custom_resets_state(self) -> None:
        project = self._project()
        project.register.custom_register_enabled = True
        project.register.custom_register_config_name = "custom_config"
        project.register.custom_register_checksum = XibifChecksum("abcd")
        args = argparse.Namespace(stream=False, user=False, custom=False, enable_custom=None, disable_custom=True)

        register(project, args)

        self.assertFalse(project.register.custom_register_enabled)
        self.assertEqual(project.register.custom_register_config_name, "")
        self.assertEqual(project.register.custom_register_checksum, XibifChecksum("0"))

    @patch("xibif.cli.commands.sys.exit", side_effect=SystemExit(1))
    @patch("xibif.cli.commands.check_tool_running_and_ask", return_value=False)
    @patch("xibif.cli.commands.api.register.register_generate_user")
    def test_register_user_exits_when_vivado_is_open(self, _mock_generate_user, _mock_check_tool, _mock_exit) -> None:
        project = self._project()
        args = argparse.Namespace(stream=False, user=True, custom=False, enable_custom=None, disable_custom=False)

        with self.assertRaises(SystemExit):
            register(project, args)

    @patch("xibif.cli.commands.shutil.move")
    @patch("xibif.cli.commands.__DEPS.resolve")
    def test_register_enable_custom_copies_default_file_when_missing(self, mock_resolve, mock_move) -> None:
        project = self._project()
        resolved_dep = SimpleNamespace(as_path=XibifPath("default_custom_cfg"), copy=lambda _path: None)
        mock_resolve.return_value = resolved_dep
        args = argparse.Namespace(stream=False, user=False, custom=False, enable_custom="custom_cfg", disable_custom=False)

        register(project, args)

        self.assertTrue(project.register.custom_register_enabled)
        self.assertEqual(project.register.custom_register_config_name, "custom_cfg")
        mock_move.assert_called_once()

    @patch("xibif.cli.commands.xibif_print_warning")
    @patch("xibif.cli.commands.shutil.move")
    @patch("xibif.cli.commands.__DEPS.resolve")
    def test_register_enable_custom_warns_when_already_enabled(self, mock_resolve, mock_move, mock_warning) -> None:
        project = self._project()
        project.register.custom_register_enabled = True
        project.register.custom_register_config_name = "old_cfg"
        resolved_dep = SimpleNamespace(as_path=XibifPath("default_custom_cfg"), copy=lambda _path: None)
        mock_resolve.return_value = resolved_dep
        args = argparse.Namespace(stream=False, user=False, custom=False, enable_custom="new_cfg", disable_custom=False)

        register(project, args)

        mock_warning.assert_called()
        mock_move.assert_called_once()

    @patch("xibif.cli.commands.sys.exit", side_effect=SystemExit(1))
    @patch("xibif.cli.commands.XibifDefaultsMessages.WARNING_MESSAGE_BUILD_VITIS_2024_1.ask", return_value=False)
    @patch("xibif.cli.commands.check_tool_running_and_ask", return_value=True)
    @patch("xibif.cli.commands.api.register.register_get_checksum")
    @patch("xibif.cli.commands.get_stages", return_value=([], [VitisStage.build]))
    def test_build_exits_when_vitis_2024_1_bug_warning_not_confirmed(self, _mock_get_stages, mock_checksum, _mock_check_tool, _mock_warning_ask, _mock_exit) -> None:
        project = self._project()
        project.tooling = XibifTooling(xilinx_version=XilinxVersion.V2024_1, xilinx_path=XibifPath("C:/Xilinx"))
        project.register.user_register_checksum = XibifChecksum("abcd")
        mock_checksum.return_value = XibifChecksum("abcd")
        args = argparse.Namespace(stage=["build-vitis"], **{"from": None, "to": None}, nowarn=False, noreport_vivado=False, fix_vitis=False)

        with self.assertRaises(SystemExit):
            build(project, args)

    @patch("xibif.cli.commands.sys.exit", side_effect=SystemExit(1))
    def test_testbench_exits_when_source_file_missing(self, _mock_exit) -> None:
        project = self._project()
        args = argparse.Namespace(clock=[], reset_negative=[], reset_positive=[], file="missing.vhd")

        with self.assertRaises(SystemExit):
            testbench(project, args)

    @patch("xibif.cli.commands.sys.exit", side_effect=SystemExit(1))
    @patch("xibif.cli.commands.api.testbench.testbench_analyze_source_file", return_value={"input": ["clk"]})
    def test_testbench_exits_on_invalid_clock(self, _mock_analyze, _mock_exit) -> None:
        project = self._project()
        temp_dir = tempfile.TemporaryDirectory()
        self.addCleanup(temp_dir.cleanup)
        src_dir = XibifPath(Path(temp_dir.name))
        src_dir.joinpath("demo.vhd").write_text("entity demo is end;", encoding="utf-8")
        args = argparse.Namespace(clock=["bad_clk"], reset_negative=[], reset_positive=[], file="demo.vhd")

        with patch.object(XibifDefaults, "HDL_SRC_FOLDER", src_dir):
            with self.assertRaises(SystemExit):
                testbench(project, args)

    @patch("xibif.cli.commands.api.testbench.testbench_generate")
    @patch("xibif.cli.commands.api.testbench.testbench_analyze_source_file", return_value={"input": ["clk", "rst_n", "rst_p"]})
    def test_testbench_runs_generate_on_valid_inputs(self, _mock_analyze, mock_generate) -> None:
        project = self._project()
        temp_dir = tempfile.TemporaryDirectory()
        self.addCleanup(temp_dir.cleanup)
        src_dir = XibifPath(Path(temp_dir.name))
        file_path = src_dir.joinpath("demo.vhd")
        file_path.write_text("entity demo is end;", encoding="utf-8")
        args = argparse.Namespace(clock=["clk"], reset_negative=["rst_n"], reset_positive=["rst_p"], file="demo.vhd")

        with patch.object(XibifDefaults, "HDL_SRC_FOLDER", src_dir):
            testbench(project, args)

        mock_generate.assert_called_once_with(hdl_vhdl_file=file_path, clock=["clk"], resetn=["rst_n"], resetp=["rst_p"])

    @patch("xibif.cli.commands.sys.exit", side_effect=SystemExit(1))
    @patch("xibif.cli.commands.get_user_temp_folder")
    def test_log_exits_when_log_file_missing(self, mock_temp_folder, _mock_exit) -> None:
        project = self._project()
        temp_dir = tempfile.TemporaryDirectory()
        self.addCleanup(temp_dir.cleanup)
        mock_temp_folder.return_value = XibifPath(temp_dir.name)

        with self.assertRaises(SystemExit):
            log(project, argparse.Namespace())

    @patch("xibif.cli.commands.webbrowser.open")
    @patch("xibif.cli.commands.get_user_temp_folder")
    def test_log_opens_today_log_file_when_present(self, mock_temp_folder, mock_open) -> None:
        project = self._project()
        temp_dir = tempfile.TemporaryDirectory()
        self.addCleanup(temp_dir.cleanup)
        folder = XibifPath(temp_dir.name)
        filename = f"xibif_{datetime.now().strftime('%Y-%m-%d')}.log"
        folder.joinpath(filename).write_text("log", encoding="utf-8")
        mock_temp_folder.return_value = folder

        log(project, argparse.Namespace())

        mock_open.assert_called_once()

    @patch("xibif.cli.commands.webbrowser.open")
    @patch("xibif.cli.commands.metadata")
    @patch("xibif.cli.commands.shutil.make_archive")
    @patch("xibif.cli.commands.get_user_temp_folder")
    @patch("xibif.cli.commands.api.misc.misc_create_backup")
    def test_report_copies_logs_packages_and_opens_issue_tracker(self, mock_backup, mock_temp_folder, mock_archive, mock_metadata, mock_open) -> None:
        project = self._project()
        temp_dir = tempfile.TemporaryDirectory()
        self.addCleanup(temp_dir.cleanup)
        base = Path(temp_dir.name)
        backup = XibifPath(base / "backup")
        backup.mkdir(parents=True, exist_ok=True)
        logs = XibifPath(base / "logs")
        logs.mkdir(parents=True, exist_ok=True)
        logs.joinpath("xibif_test.log").write_text("log", encoding="utf-8")
        mock_backup.return_value = backup
        mock_temp_folder.return_value = logs
        mock_metadata.return_value = SimpleNamespace(json={"project_url": ["", "", "Issues, https://example.invalid/issues"]})

        with patch.object(XibifDefaults, "REPORT_FOLDER", XibifPath(base / "report")):
            report(project, argparse.Namespace())

        mock_archive.assert_called_once()
        mock_open.assert_called_once()

    @patch("xibif.cli.commands.api.upgrade.upgrade")
    @patch("xibif.cli.commands.get_version")
    def test_upgrade_calls_api_and_updates_version(self, mock_get_version, mock_upgrade_api) -> None:
        project = self._project()
        old_version = project.version
        mock_get_version.return_value = old_version

        upgraded = upgrade(project, argparse.Namespace())

        mock_upgrade_api.assert_called_once()
        self.assertEqual(upgraded.version, old_version)

    @patch("xibif.cli.commands.sys.exit", side_effect=SystemExit(1))
    @patch("xibif.cli.commands.api.flash.flash_hardware_server", side_effect=Exception("fail"))
    def test_flash_propagates_unexpected_error(self, _mock_flash, _mock_exit) -> None:
        project = self._project()
        with self.assertRaises(Exception):
            flash(project, argparse.Namespace(hardware_server="127.0.0.1", port=3121))
