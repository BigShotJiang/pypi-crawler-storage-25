"""Tests for xibif.cli."""
