"""Tests for CLI command functions."""

# pylint: disable=missing-function-docstring,missing-class-docstring

import argparse
from pathlib import Path
import tempfile
from unittest.mock import patch
import unittest

from xibif.api.build_stages import VivadoStage
from xibif.cli.commands import build, new, register
from xibif.project.project import XibifProject
from xibif.project.models import XibifRegister, XibifSettings, XibifTooling
from xibif.types import XibifChecksum, XibifDefaults, XibifPath, XibifUUID, XilinxBoard, XilinxVersion


class FakeProject:
    """Minimal project stub for command tests."""

    def __init__(self) -> None:
        self.project_name = ""
        self.project_path = XibifPath(".")
        self.board = XilinxBoard.ZEDBOARD
        self.tooling = XibifTooling()
        self.register = XibifRegister()
        self.uuid = XibifUUID(1)
        self.settings = XibifSettings()
        self.vitis_path_check = XibifDefaults.VITIS_FOLDER

    @property
    def name(self) -> str:
        return self.project_name or "xibif"

    @name.setter
    def name(self, value: str) -> None:
        self.project_name = value


class CommandsTests(unittest.TestCase):
    """Validate high-level CLI command orchestration."""

    @patch("xibif.cli.commands.api.setup.setup_openlogic_vivado")
    @patch("xibif.cli.commands.api.setup.setup_vitis_project")
    @patch("xibif.cli.commands.api.setup.setup_vivado_project")
    @patch("xibif.cli.commands.api.register.register_get_checksum", return_value=XibifChecksum("abcd"))
    @patch("xibif.cli.commands.api.register.register_generate_user")
    @patch("xibif.cli.commands.api.register.register_generate_stream")
    @patch("xibif.cli.commands.api.setup.setup_openlogic_files")
    @patch("xibif.cli.commands.api.setup.setup_git_repository")
    @patch("xibif.cli.commands.api.setup.setup_git_files")
    @patch("xibif.cli.commands.api.setup.setup_demo_files")
    @patch("xibif.cli.commands.api.setup.setup_sigasi_project")
    @patch("xibif.cli.commands.api.setup.setup_constraint_files")
    @patch("xibif.cli.commands.api.setup.setup_vunit_python_files")
    @patch("xibif.cli.commands.api.setup.setup_hdl_files")
    @patch("xibif.cli.commands.api.setup.setup_register_files")
    @patch("xibif.cli.commands.api.misc.misc_create_project_folder")
    @patch("xibif.cli.commands.XibifProject", return_value=FakeProject())
    def test_new_creates_project_and_runs_setup_pipeline(
        self,
        _mock_project,
        mock_create_project_folder,
        _mock_setup_register_files,
        _mock_setup_hdl_files,
        _mock_setup_vunit,
        _mock_setup_constraints,
        _mock_setup_sigasi,
        _mock_setup_demo,
        _mock_setup_git_files,
        _mock_setup_git_repo,
        _mock_setup_openlogic,
        mock_register_stream,
        mock_register_user,
        _mock_register_checksum,
        mock_setup_vivado,
        mock_setup_vitis,
        _mock_setup_openlogic_vivado,
    ) -> None:
        temp_dir = tempfile.TemporaryDirectory()
        self.addCleanup(temp_dir.cleanup)
        args = argparse.Namespace(
            name="demo",
            path=str(Path(temp_dir.name) / "demo"),
            force=False,
            nuke=False,
            board=XilinxBoard.ZEDBOARD,
            xilinx="C:/Xilinx",
            version=XilinxVersion.V2024_2,
            dev_mode=False,
        )

        project = new(XibifProject(), args)

        self.assertEqual(project.name, "demo")
        mock_create_project_folder.assert_called_once()
        mock_setup_vivado.assert_called_once()
        mock_setup_vitis.assert_called_once()
        mock_register_stream.assert_called_once()
        mock_register_user.assert_called_once()

    @patch("xibif.cli.commands.api.setup.setup_openlogic_vivado")
    @patch("xibif.cli.commands.api.setup.setup_vitis_project")
    @patch("xibif.cli.commands.api.setup.setup_vivado_project")
    @patch("xibif.cli.commands.api.register.register_get_checksum", return_value=XibifChecksum("abcd"))
    @patch("xibif.cli.commands.api.register.register_generate_user")
    @patch("xibif.cli.commands.api.register.register_generate_stream")
    @patch("xibif.cli.commands.api.setup.setup_openlogic_files")
    @patch("xibif.cli.commands.api.setup.setup_git_repository")
    @patch("xibif.cli.commands.api.setup.setup_git_files")
    @patch("xibif.cli.commands.api.setup.setup_demo_files")
    @patch("xibif.cli.commands.api.setup.setup_sigasi_project")
    @patch("xibif.cli.commands.api.setup.setup_constraint_files")
    @patch("xibif.cli.commands.api.setup.setup_vunit_python_files")
    @patch("xibif.cli.commands.api.setup.setup_hdl_files")
    @patch("xibif.cli.commands.api.setup.setup_register_files")
    @patch("xibif.cli.commands.api.misc.misc_create_project_folder")
    @patch("xibif.cli.commands.XibifProject", return_value=FakeProject())
    def test_new_with_dev_mode_passes_link_true_to_setup_functions(
        self,
        _mock_project,
        mock_create_project_folder,
        mock_setup_register_files,
        mock_setup_hdl_files,
        mock_setup_vunit,
        mock_setup_constraints,
        mock_setup_sigasi,
        mock_setup_demo,
        mock_setup_git_files,
        mock_setup_git_repo,
        _mock_setup_openlogic,
        mock_register_stream,
        mock_register_user,
        _mock_register_checksum,
        _mock_setup_vivado,
        mock_setup_vitis,
        _mock_setup_openlogic_vivado,
    ) -> None:
        """When --dev-mode is enabled, setup functions should be called with link=True."""
        temp_dir = tempfile.TemporaryDirectory()
        self.addCleanup(temp_dir.cleanup)
        args = argparse.Namespace(
            name="demo",
            path=str(Path(temp_dir.name) / "demo"),
            force=False,
            nuke=False,
            board=XilinxBoard.ZEDBOARD,
            xilinx="C:/Xilinx",
            version=XilinxVersion.V2024_2,
            dev_mode=True,
        )

        project = new(XibifProject(), args)

        self.assertEqual(project.name, "demo")
        mock_create_project_folder.assert_called_once()
        
        # Verify that setup functions are called with link=True
        mock_setup_register_files.assert_called_once()
        self.assertTrue(mock_setup_register_files.call_args.kwargs.get("link"))
        
        mock_setup_hdl_files.assert_called_once()
        self.assertTrue(mock_setup_hdl_files.call_args.kwargs.get("link"))
        
        mock_setup_vunit.assert_called_once()
        self.assertTrue(mock_setup_vunit.call_args.kwargs.get("link"))
        
        mock_setup_constraints.assert_called_once()
        self.assertTrue(mock_setup_constraints.call_args.kwargs.get("link"))
        
        mock_setup_sigasi.assert_called_once()
        self.assertTrue(mock_setup_sigasi.call_args.kwargs.get("link"))
        
        mock_setup_demo.assert_called_once()
        self.assertTrue(mock_setup_demo.call_args.kwargs.get("link"))
        
        mock_setup_git_files.assert_called_once()
        self.assertTrue(mock_setup_git_files.call_args.kwargs.get("link"))
        
        mock_setup_vitis.assert_called_once()
        self.assertTrue(mock_setup_vitis.call_args.kwargs.get("link"))

    @patch("xibif.cli.commands.api.setup.setup_openlogic_vivado")
    @patch("xibif.cli.commands.api.setup.setup_vitis_project")
    @patch("xibif.cli.commands.api.setup.setup_vivado_project")
    @patch("xibif.cli.commands.api.register.register_get_checksum", return_value=XibifChecksum("abcd"))
    @patch("xibif.cli.commands.api.register.register_generate_user")
    @patch("xibif.cli.commands.api.register.register_generate_stream")
    @patch("xibif.cli.commands.api.setup.setup_openlogic_files")
    @patch("xibif.cli.commands.api.setup.setup_git_repository")
    @patch("xibif.cli.commands.api.setup.setup_git_files")
    @patch("xibif.cli.commands.api.setup.setup_demo_files")
    @patch("xibif.cli.commands.api.setup.setup_sigasi_project")
    @patch("xibif.cli.commands.api.setup.setup_constraint_files")
    @patch("xibif.cli.commands.api.setup.setup_vunit_python_files")
    @patch("xibif.cli.commands.api.setup.setup_hdl_files")
    @patch("xibif.cli.commands.api.setup.setup_register_files")
    @patch("xibif.cli.commands.api.misc.misc_create_project_folder")
    @patch("xibif.cli.commands.XibifProject", return_value=FakeProject())
    def test_new_without_dev_mode_passes_link_false_to_setup_functions(
        self,
        _mock_project,
        mock_create_project_folder,
        mock_setup_register_files,
        mock_setup_hdl_files,
        mock_setup_vunit,
        mock_setup_constraints,
        mock_setup_sigasi,
        mock_setup_demo,
        mock_setup_git_files,
        mock_setup_git_repo,
        _mock_setup_openlogic,
        mock_register_stream,
        mock_register_user,
        _mock_register_checksum,
        _mock_setup_vivado,
        mock_setup_vitis,
        _mock_setup_openlogic_vivado,
    ) -> None:
        """When --dev-mode is NOT enabled, setup functions should be called with link=False."""
        temp_dir = tempfile.TemporaryDirectory()
        self.addCleanup(temp_dir.cleanup)
        args = argparse.Namespace(
            name="demo",
            path=str(Path(temp_dir.name) / "demo"),
            force=False,
            nuke=False,
            board=XilinxBoard.ZEDBOARD,
            xilinx="C:/Xilinx",
            version=XilinxVersion.V2024_2,
            dev_mode=False,
        )

        project = new(XibifProject(), args)

        self.assertEqual(project.name, "demo")
        mock_create_project_folder.assert_called_once()
        
        # Verify that setup functions are called with link=False
        mock_setup_register_files.assert_called_once()
        self.assertFalse(mock_setup_register_files.call_args.kwargs.get("link"))
        
        mock_setup_hdl_files.assert_called_once()
        self.assertFalse(mock_setup_hdl_files.call_args.kwargs.get("link"))
        
        mock_setup_vunit.assert_called_once()
        self.assertFalse(mock_setup_vunit.call_args.kwargs.get("link"))
        
        mock_setup_constraints.assert_called_once()
        self.assertFalse(mock_setup_constraints.call_args.kwargs.get("link"))
        
        mock_setup_sigasi.assert_called_once()
        self.assertFalse(mock_setup_sigasi.call_args.kwargs.get("link"))
        
        mock_setup_demo.assert_called_once()
        self.assertFalse(mock_setup_demo.call_args.kwargs.get("link"))
        
        mock_setup_git_files.assert_called_once()
        self.assertFalse(mock_setup_git_files.call_args.kwargs.get("link"))
        
        mock_setup_vitis.assert_called_once()
        self.assertFalse(mock_setup_vitis.call_args.kwargs.get("link"))

    @patch("xibif.cli.commands.api.build.build_vitis")
    @patch("xibif.cli.commands.api.build.build_vivado")
    @patch("xibif.cli.commands.api.misc.misc_update_vitis_header_file")
    @patch("xibif.cli.commands.check_tool_running_and_ask", return_value=True)
    def test_build_defaults_to_full_vivado_and_vitis_build(self, mock_check_tool, mock_update_header, mock_build_vivado, mock_build_vitis) -> None:
        """A default build should run Vivado, Vitis and the header update path."""
        project = XibifProject()
        project.name = "demo"
        project.tooling = XibifTooling(xilinx_version=XilinxVersion.V2024_2, xilinx_path=XibifPath("C:/Xilinx"))
        project.register.user_register_checksum = XibifChecksum("abcd")
        args = argparse.Namespace(stage=[], **{"from": None, "to": None}, nowarn=True, noreport_vivado=False, fix_vitis=False)

        build(project, args)

        mock_check_tool.assert_not_called()
        mock_build_vivado.assert_called_once()
        mock_build_vitis.assert_called_once()
        mock_update_header.assert_called_once()

    @patch("xibif.cli.commands.sys.exit", side_effect=SystemExit(1))
    @patch("xibif.cli.commands.xibif_print_error")
    def test_build_rejects_fix_vitis_with_stage_selection(self, mock_print_error, mock_exit) -> None:
        """Fix-vitis must not be combined with explicit stage selection."""
        with self.assertRaises(SystemExit):
            build(XibifProject(), argparse.Namespace(stage=[VivadoStage.synthesize], **{"from": None, "to": None}, nowarn=True, noreport_vivado=False, fix_vitis=True))

        mock_print_error.assert_called_once()
        mock_exit.assert_called_once_with(1)

    @patch("xibif.cli.commands.api.register.register_get_checksum", return_value=XibifChecksum("abcd"))
    @patch("xibif.cli.commands.api.register.register_generate_user_vivado")
    @patch("xibif.cli.commands.api.register.register_generate_user")
    @patch("xibif.cli.commands.api.register.register_generate_stream")
    @patch("xibif.cli.commands.check_tool_running_and_ask", return_value=True)
    def test_register_defaults_to_stream_and_user_generation(self, mock_check_tool, mock_stream, mock_user, mock_user_vivado, mock_checksum) -> None:
        project = XibifProject()
        project.name = "demo"
        project.tooling = XibifTooling(xilinx_version=XilinxVersion.V2024_2, xilinx_path=XibifPath("C:/Xilinx"))
        args = argparse.Namespace(stream=False, user=False, custom=False, enable_custom=None, disable_custom=False)

        register(project, args)

        mock_check_tool.assert_called_once_with("vivado")
        mock_stream.assert_called_once()
        mock_user.assert_called_once()
        mock_user_vivado.assert_called_once()
        mock_checksum.assert_called_once()
