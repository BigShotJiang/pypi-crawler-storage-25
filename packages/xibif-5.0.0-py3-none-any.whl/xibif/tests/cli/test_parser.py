"""Tests for CLI parser generation."""

# pylint: disable=missing-function-docstring,missing-class-docstring

import argparse
from unittest.mock import patch
import unittest

from xibif.api.build_stages import VitisStage, VivadoStage
from xibif.cli.parser import BuildStageAction, add_arguments_settings, generate_parser
from xibif.logger.models import LoggerVerbosity
from xibif.types import XilinxBoard, XilinxVersion


class ParserTests(unittest.TestCase):
    """Validate CLI parser behavior."""

    @patch("xibif.cli.parser.metadata", return_value={"Name": "xibif", "Summary": "XiBIF"})
    @patch("xibif.cli.parser.version", return_value="1.2.3")
    @patch("xibif.cli.parser.scan_xilinx_version", return_value=XilinxVersion.V2024_2)
    @patch("xibif.cli.parser.get_default_xilinx_path", return_value="C:/Xilinx")
    def test_generate_parser_parses_new_command(self, mock_xilinx_path, mock_scan, mock_version, mock_metadata) -> None:
        parser = generate_parser()

        args = parser.parse_args(["new", "--name", "demo", "--board", "zedboard"])

        self.assertEqual(args.command, "new")
        self.assertEqual(args.board, XilinxBoard.ZEDBOARD)
        self.assertEqual(args.verbosity, LoggerVerbosity.INFO)
        self.assertGreaterEqual(mock_xilinx_path.call_count, 1)
        self.assertGreaterEqual(mock_scan.call_count, 1)
        mock_version.assert_called_once_with("xibif")
        self.assertGreaterEqual(mock_metadata.call_count, 1)

    def test_build_stage_action_parses_multiple_stages(self) -> None:
        parser = argparse.ArgumentParser()
        parser.add_argument("--stage", nargs="+", action=BuildStageAction, default=[])

        args = parser.parse_args(["--stage", "vivado:synthesize", "vitis:build"])

        self.assertEqual(args.stage, [VivadoStage.synthesize, VitisStage.build])

    def test_add_arguments_settings_adds_bool_and_scalar_fields(self) -> None:
        parser = argparse.ArgumentParser()

        add_arguments_settings(parser)
        args = parser.parse_args(["--enable_webserver", "False", "--timeout_dhcp", "11"])

        self.assertEqual(args.enable_webserver, "False")
        self.assertEqual(args.timeout_dhcp, 11)

    @patch("xibif.cli.parser.metadata", return_value={"Name": "xibif", "Summary": "XiBIF"})
    @patch("xibif.cli.parser.version", return_value="1.2.3")
    @patch("xibif.cli.parser.scan_xilinx_version", return_value=XilinxVersion.V2024_2)
    @patch("xibif.cli.parser.get_default_xilinx_path", return_value="C:/Xilinx")
    def test_generate_parser_recognizes_dev_mode_flag(self, mock_xilinx_path, mock_scan, mock_version, mock_metadata) -> None:
        """Parser should recognize and parse the --dev-mode flag."""
        parser = generate_parser()

        args = parser.parse_args(["new", "--name", "demo", "--board", "zedboard", "--dev-mode"])

        self.assertEqual(args.command, "new")
        self.assertTrue(args.dev_mode)

    @patch("xibif.cli.parser.metadata", return_value={"Name": "xibif", "Summary": "XiBIF"})
    @patch("xibif.cli.parser.version", return_value="1.2.3")
    @patch("xibif.cli.parser.scan_xilinx_version", return_value=XilinxVersion.V2024_2)
    @patch("xibif.cli.parser.get_default_xilinx_path", return_value="C:/Xilinx")
    def test_generate_parser_dev_mode_defaults_to_false(self, mock_xilinx_path, mock_scan, mock_version, mock_metadata) -> None:
        """Parser should default dev_mode to False when not provided."""
        parser = generate_parser()

        args = parser.parse_args(["new", "--name", "demo", "--board", "zedboard"])

        self.assertEqual(args.command, "new")
        self.assertFalse(args.dev_mode)
