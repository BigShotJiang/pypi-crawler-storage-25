"""Tests for logger models."""

# pylint: disable=missing-function-docstring,missing-class-docstring

import unittest

from xibif.logger.models import LoggerVerbosity


class LoggerModelsTests(unittest.TestCase):
    """Validate logger verbosity values."""

    def test_verbosity_enum_values_are_stable(self) -> None:
        self.assertEqual(LoggerVerbosity.DEBUG.value, "debug")
        self.assertEqual(LoggerVerbosity("warning"), LoggerVerbosity.WARNING)
