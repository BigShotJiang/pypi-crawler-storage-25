"""Tests for the unbuffered stream wrapper."""

# pylint: disable=missing-function-docstring,missing-class-docstring

from io import StringIO
import unittest

from xibif.logger.unbuffered_stream import UnbufferedStream


class RecordingStream(StringIO):
    """Simple stream that tracks flush calls."""

    def __init__(self) -> None:
        super().__init__()
        self.flush_calls = 0

    def flush(self) -> None:
        self.flush_calls += 1
        super().flush()


class UnbufferedStreamTests(unittest.TestCase):
    """Ensure writes are flushed immediately."""

    def test_write_flushes_stream(self) -> None:
        stream = RecordingStream()
        wrapper = UnbufferedStream(stream)

        wrapper.write("hello")

        self.assertEqual(stream.getvalue(), "hello")
        self.assertEqual(stream.flush_calls, 1)

    def test_writelines_flushes_stream(self) -> None:
        stream = RecordingStream()
        wrapper = UnbufferedStream(stream)

        wrapper.writelines(["a", "b"])

        self.assertEqual(stream.getvalue(), "ab")
        self.assertEqual(stream.flush_calls, 1)

    def test_attribute_access_is_forwarded(self) -> None:
        stream = RecordingStream()
        wrapper = UnbufferedStream(stream)

        self.assertTrue(callable(wrapper.seek))
