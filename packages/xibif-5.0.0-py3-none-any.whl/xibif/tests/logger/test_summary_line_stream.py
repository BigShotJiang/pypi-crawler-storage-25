"""Tests for the summary line stream."""

# pylint: disable=missing-function-docstring,missing-class-docstring,protected-access,unused-argument

from datetime import timedelta
from io import StringIO
from types import SimpleNamespace
from typing import Any, cast
from unittest.mock import patch
import unittest

from xibif.logger.logger_stages import LoggerStage
from xibif.logger.summary_line_stream import SummaryLineStream


def call_write_raw(stream: SummaryLineStream, message: SimpleNamespace) -> None:
    """Call the undecorated write implementation for focused unit tests."""
    raw_write = getattr(cast(Any, SummaryLineStream.write), "raw_function")
    raw_write(stream, message)


def call_print_summary_raw(stream: SummaryLineStream) -> None:
    """Call the undecorated final-summary implementation for focused unit tests."""
    raw_print = getattr(cast(Any, getattr(stream, "_SummaryLineStream__print_errors_and_warnings")), "raw_function")
    raw_print(stream)


class DummyTimer:
    """Small timer stub for deterministic tests."""

    def __init__(self, interval, callback) -> None:
        self.interval = interval
        self.callback = callback
        self.daemon = False
        self.started = False
        self.cancelled = False

    def start(self) -> None:
        """Mark the timer as started."""
        self.started = True

    def cancel(self) -> None:
        """Mark the timer as cancelled."""
        self.cancelled = True


class SummaryLineStreamTests(unittest.TestCase):
    """Verify summary and counter handling."""

    @patch("xibif.logger.summary_line_stream.atexit.register")
    @patch("xibif.logger.summary_line_stream.threading.Timer", side_effect=DummyTimer)
    @patch("xibif.logger.summary_line_stream.time.perf_counter", side_effect=[100.0, 103.0])
    @patch("xibif.logger.summary_line_stream.sys.stdout", new_callable=StringIO)
    @patch("builtins.print")
    def test_write_updates_stage_and_counts(self, mock_print, _mock_stdout, _mock_perf_counter, _mock_timer, mock_register) -> None:
        """Writing a warning should update counters, stage and summary output."""
        stream = SummaryLineStream(LoggerStage.STARTUP)
        message = SimpleNamespace(
            record={
                "extra": {"stage": LoggerStage.SHELL, "prefix": "TEST", "color": "", "force_print": False},
                "level": SimpleNamespace(name="WARNING"),
                "message": "careful",
                "elapsed": timedelta(seconds=5),
            }
        )

        call_write_raw(stream, message)

        self.assertEqual(getattr(stream, "_SummaryLineStream__stage"), LoggerStage.SHELL)
        self.assertEqual(getattr(stream, "_SummaryLineStream__counter")["WARNING"], 1)
        self.assertEqual(getattr(stream, "_SummaryLineStream__counter")["STEPS"], 1)
        self.assertEqual(len(getattr(stream, "_SummaryLineStream__errors_and_warnings")), 1)
        self.assertTrue(mock_print.called)
        mock_register.assert_called_once()

    @patch("xibif.logger.summary_line_stream.atexit.register")
    @patch("xibif.logger.summary_line_stream.threading.Timer", side_effect=DummyTimer)
    @patch("xibif.logger.summary_line_stream.time.perf_counter", return_value=100.0)
    @patch("xibif.logger.summary_line_stream.sys.stdout", new_callable=StringIO)
    def test_start_and_stop_toggle_timer_state(self, _mock_stdout, _mock_perf_counter, _mock_timer, _mock_register) -> None:
        """Starting and stopping the stream should toggle the timer lifecycle."""
        stream = SummaryLineStream(LoggerStage.STARTUP)

        stream.start()
        stream.stop()

        self.assertFalse(getattr(stream, "_SummaryLineStream__timer_started"))
        self.assertTrue(getattr(stream, "_SummaryLineStream__timer").cancelled)

    @patch("xibif.logger.summary_line_stream.atexit.register")
    @patch("xibif.logger.summary_line_stream.threading.Timer", side_effect=DummyTimer)
    @patch("xibif.logger.summary_line_stream.time.perf_counter", return_value=100.0)
    @patch("xibif.logger.summary_line_stream.sys.stdout", new_callable=StringIO)
    @patch("builtins.print")
    def test_print_errors_and_warnings_outputs_summary_section(self, mock_print, _mock_stdout, _mock_perf_counter, _mock_timer, _mock_register) -> None:
        """The final summary should print stored errors and move the stage to finished."""
        stream = SummaryLineStream(LoggerStage.STARTUP)
        getattr(stream, "_SummaryLineStream__counter")["STEPS"] = 1
        setattr(stream, "_SummaryLineStream__errors_and_warnings", [{"level": "ERROR", "stage": "Shell", "message": "broken", "elapsed_time": timedelta(seconds=9)}])

        call_print_summary_raw(stream)

        printed_text = "\n".join(str(call.args[0]) for call in mock_print.call_args_list if call.args)
        self.assertIn("Error and Warning Summary", printed_text)
        self.assertEqual(getattr(stream, "_SummaryLineStream__stage"), LoggerStage.FINISHED)
