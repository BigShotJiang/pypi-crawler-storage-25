"""Tests for logger stages."""

# pylint: disable=missing-function-docstring,missing-class-docstring

import unittest

from xibif.logger.logger_stages import LoggerStage


class LoggerStagesTests(unittest.TestCase):
    """Validate representative logger stages."""

    def test_special_and_regular_stages_are_available(self) -> None:
        self.assertEqual(LoggerStage.NO_CHANGE.value, "NO_CHANGE")
        self.assertEqual(LoggerStage.SHELL.value, "Shell")
        self.assertEqual(LoggerStage("Finished"), LoggerStage.FINISHED)
