"""Tests for logger utilities."""

# pylint: disable=missing-function-docstring,missing-class-docstring

from unittest.mock import patch
import unittest

from colorama import Fore

from xibif.logger.logger_stages import LoggerStage
from xibif.logger.models import LoggerVerbosity
from xibif.logger.utils import get_user_temp_folder, setup_logger, start_periodic_logger, stop_periodic_logger, xibif_print
from xibif.types import XibifPath


class LoggerUtilsTests(unittest.TestCase):
    """Test logger setup and message routing."""

    @patch("xibif.logger.utils.just_fix_windows_console")
    @patch("xibif.logger.utils.logger.add")
    @patch("xibif.logger.utils.logger.remove")
    def test_setup_logger_adds_file_and_stream_handlers(self, mock_remove, mock_add, mock_fix_console) -> None:
        setup_logger(verbosity=LoggerVerbosity.INFO, summary=True)

        mock_fix_console.assert_called_once()
        mock_remove.assert_called_once()
        self.assertEqual(mock_add.call_count, 2)

    @patch("xibif.logger.utils.logger.bind")
    def test_xibif_print_routes_info_messages(self, mock_bind) -> None:
        xibif_print(" hello ", verbosity=LoggerVerbosity.INFO, prefix="TEST", stage=LoggerStage.SHELL, color=Fore.GREEN)

        mock_bind.assert_called_once()
        mock_bind.return_value.info.assert_called_once_with("hello")

    @patch("xibif.logger.utils.logger.bind")
    def test_xibif_print_ignores_empty_messages(self, mock_bind) -> None:
        xibif_print("", verbosity=LoggerVerbosity.INFO)

        mock_bind.assert_not_called()

    @patch("xibif.logger.utils.__summary_stream.stop")
    @patch("xibif.logger.utils.__summary_stream.start")
    def test_periodic_logger_delegates_to_summary_stream(self, mock_start, mock_stop) -> None:
        start_periodic_logger()
        stop_periodic_logger()

        mock_start.assert_called_once()
        mock_stop.assert_called_once()

    def test_get_user_temp_folder_returns_xibif_path(self) -> None:
        temp_folder = get_user_temp_folder()

        self.assertIsInstance(temp_folder, XibifPath)
        self.assertIn("xibif", temp_folder.as_posix().lower())
