"""Tests for xibif.logger."""
