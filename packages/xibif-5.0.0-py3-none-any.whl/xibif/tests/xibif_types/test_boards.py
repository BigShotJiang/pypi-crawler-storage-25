"""Tests for board enums."""

# pylint: disable=missing-function-docstring,missing-class-docstring

import unittest

from xibif.types.boards import XilinxBoard


class XilinxBoardTests(unittest.TestCase):
    """Validate supported boards."""

    def test_board_values_are_stable(self) -> None:
        self.assertEqual(XilinxBoard.ZEDBOARD.value, "zedboard")
        self.assertEqual(XilinxBoard("kv260"), XilinxBoard.KV260)

    def test_all_supported_boards_are_present(self) -> None:
        self.assertEqual(
            {board.value for board in XilinxBoard},
            {"zyboz710", "zyboz720", "zedboard", "zcu102", "zcu104", "kv260"},
        )
