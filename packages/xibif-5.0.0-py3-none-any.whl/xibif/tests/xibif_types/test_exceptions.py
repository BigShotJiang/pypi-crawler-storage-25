"""Tests for the xibif exception hierarchy."""

# pylint: disable=missing-function-docstring,missing-class-docstring

import unittest

from xibif.types.exceptions import (
    XibifChecksumError,
    XibifEnvironmentError,
    XibifError,
    XibifGeneratedFileError,
    XibifInvalidPathError,
    XibifRegisterError,
    XibifRuntimeError,
    XibifTimeoutError,
    XibifValidationError,
)


class ExceptionsTests(unittest.TestCase):
    """Ensure all custom exceptions inherit from the same base type."""

    def test_all_custom_exceptions_inherit_from_xibif_error(self) -> None:
        exception_types = [
            XibifEnvironmentError,
            XibifInvalidPathError,
            XibifGeneratedFileError,
            XibifRuntimeError,
            XibifTimeoutError,
            XibifRegisterError,
            XibifValidationError,
            XibifChecksumError,
        ]

        for exception_type in exception_types:
            with self.subTest(exception_type=exception_type.__name__):
                self.assertTrue(issubclass(exception_type, XibifError))
