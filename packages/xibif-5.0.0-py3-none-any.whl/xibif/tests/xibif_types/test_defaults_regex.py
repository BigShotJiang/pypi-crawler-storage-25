"""Tests for validation regex defaults."""

# pylint: disable=missing-function-docstring,missing-class-docstring

import re
import unittest

from xibif.types.defaults_regex import XibifDefaultsRegex


class DefaultsRegexTests(unittest.TestCase):
    """Verify the most important regex contracts stay intact."""

    def test_project_name_regex_accepts_expected_values(self) -> None:
        self.assertIsNotNone(re.match(XibifDefaultsRegex.PROJECT_NAME, "xibif-demo_1"))
        self.assertIsNone(re.match(XibifDefaultsRegex.PROJECT_NAME, "demo project"))

    def test_path_regex_rejects_invalid_characters(self) -> None:
        self.assertIsNotNone(re.match(XibifDefaultsRegex.PATH, "folder/sub-folder/file.txt"))
        self.assertIsNone(re.match(XibifDefaultsRegex.PATH, "folder|invalid"))

    def test_register_name_regex_requires_leading_letter(self) -> None:
        self.assertIsNotNone(re.match(XibifDefaultsRegex.REGISTER_NAME, "Register_1"))
        self.assertIsNone(re.match(XibifDefaultsRegex.REGISTER_NAME, "1Register"))
