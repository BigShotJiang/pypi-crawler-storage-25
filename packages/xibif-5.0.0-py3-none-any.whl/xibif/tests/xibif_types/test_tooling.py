"""Tests for tooling enums and mapping container."""

# pylint: disable=missing-function-docstring,missing-class-docstring

import unittest

from xibif.types.tooling import XibifStartTool, VunitSimulator, XilinxToolPath, XilinxVersion
from xibif.types.utils import XibifPath


class ToolingTests(unittest.TestCase):
    """Validate tooling-related types."""

    def test_tool_path_supports_item_access(self) -> None:
        tool_paths = XilinxToolPath()
        vivado_path = XibifPath("C:/Xilinx/Vivado")

        tool_paths["vivado"] = vivado_path

        self.assertEqual(tool_paths["vivado"], vivado_path)
        self.assertIn(("vivado", vivado_path), tuple(tool_paths.items()))

    def test_enum_values_are_available(self) -> None:
        self.assertEqual(XilinxVersion("2024.2"), XilinxVersion.V2024_2)
        self.assertEqual(VunitSimulator("ghdl"), VunitSimulator.GHDL)
        self.assertEqual(XibifStartTool("hw_server"), XibifStartTool.HARDWARE_SERVER)
