"""Tests for packaged default messages."""

# pylint: disable=missing-function-docstring,missing-class-docstring

import unittest

from xibif.types.defaults_messages import XibifDefaultsMessages
from xibif.types.messages import XibifMessage


class DefaultsMessagesTests(unittest.TestCase):
    """Ensure default messages remain available as message objects."""

    def test_warning_messages_are_xibif_message_instances(self) -> None:
        self.assertIsInstance(XibifDefaultsMessages.WARNING_MESSAGE_BUILD_VITIS_2024_1, XibifMessage)
        self.assertIsInstance(XibifDefaultsMessages.WARNING_MESSAGE_MOVED_VITIS, XibifMessage)
        self.assertIsInstance(XibifDefaultsMessages.WARNING_MESSAGE_SETUP_VITIS, XibifMessage)

    def test_warning_message_contains_expected_heading(self) -> None:
        rendered = str(XibifDefaultsMessages.WARNING_MESSAGE_MOVED_VITIS)

        self.assertIn("Vitis Workspace Moved Warning", rendered)
