"""Tests for XiBIF utility types."""

# pylint: disable=missing-function-docstring,missing-class-docstring

from pathlib import Path
import tempfile
import unittest

from pydantic import ValidationError

from xibif.types import XibifInvalidPathError, XibifValidationError
from xibif.types.utils import XibifChecksum, XibifPath, XibifUUID, XibifVersion, validate_XibifPath_exist


class XibifPathTests(unittest.TestCase):
    """Test path wrapping, serialization and validation helpers."""

    def setUp(self) -> None:
        XibifPath.set_root(Path.cwd())

    def test_relative_path_uses_root_for_string_conversion(self) -> None:
        root = Path(tempfile.gettempdir()) / "xibif-root"
        XibifPath.set_root(root)

        path = XibifPath("subdir/file.txt")

        self.assertEqual(str(path), str(root / "subdir" / "file.txt"))

    def test_joinpath_returns_xibif_path(self) -> None:
        path = XibifPath("base").joinpath("child")

        self.assertIsInstance(path, XibifPath)
        self.assertTrue(path.as_posix().endswith("base/child"))

    def test_invalid_path_raises_validation_error(self) -> None:
        with self.assertRaises(XibifValidationError):
            XibifPath("invalid|path")

    def test_validate_path_exist_decorator_rejects_missing_paths(self) -> None:
        @validate_XibifPath_exist
        def consume(path: XibifPath) -> XibifPath:
            return path

        with self.assertRaises(XibifInvalidPathError):
            consume(XibifPath("definitely_missing_path"))


class UtilityValueTypesTests(unittest.TestCase):
    """Test utility value classes."""

    def test_version_equality_and_string_conversion(self) -> None:
        version = XibifVersion(1, 2, 3, 4)

        self.assertEqual(str(version), "1.2.3.4")
        self.assertEqual(version, XibifVersion(1, 2, 3, 4))

    def test_uuid_deserializes_from_int(self) -> None:
        uuid_value = XibifUUID(0x1234ABCD)

        self.assertEqual(str(uuid_value), "305441741/0x1234ABCD")

    def test_checksum_supports_string_comparison(self) -> None:
        checksum = XibifChecksum("deadbeef")

        self.assertEqual(checksum, "deadbeef")
        self.assertEqual(str(checksum), "deadbeef")

    def test_checksum_rejects_invalid_format(self) -> None:
        with self.assertRaises(ValidationError):
            XibifChecksum("not-hex")
