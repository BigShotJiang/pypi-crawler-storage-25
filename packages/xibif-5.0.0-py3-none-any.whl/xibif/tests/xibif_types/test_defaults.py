"""Tests for default values and paths."""

# pylint: disable=missing-function-docstring,missing-class-docstring

import unittest

from xibif.types.defaults import XibifDefaults
from xibif.types.utils import XibifPath


class DefaultsTests(unittest.TestCase):
    """Verify key default constants."""

    def test_defaults_are_composed_from_expected_paths(self) -> None:
        self.assertEqual(XibifDefaults.HW_FOLDER, XibifPath("hw"))
        self.assertEqual(XibifDefaults.REG_FOLDER, XibifPath("hw/regs"))
        self.assertEqual(XibifDefaults.SIMULATION_XML_FILE, XibifPath("hw/results/test_output.xml"))

    def test_default_project_file_name_and_app_name_are_stable(self) -> None:
        self.assertEqual(XibifDefaults.PROJECT_NAME, ".xibif")
        self.assertEqual(XibifDefaults.APP_NAME, "xibif")
