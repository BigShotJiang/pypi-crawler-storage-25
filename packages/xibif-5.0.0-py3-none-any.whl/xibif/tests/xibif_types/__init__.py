"""Tests for xibif.types."""
