"""Tests for user-facing message formatting and prompting."""

# pylint: disable=missing-function-docstring,missing-class-docstring,protected-access

from unittest.mock import patch
import unittest

from xibif.types.messages import XibifMessage


class XibifMessageTests(unittest.TestCase):
    """Test formatting and prompt handling."""

    def test_string_representation_contains_title_and_message(self) -> None:
        message = XibifMessage(title="Headline", message="Line one")

        rendered = str(message)

        self.assertIn("Headline", rendered)
        self.assertIn("Line one", rendered)

    def test_split_at_whitespace_wraps_long_lines(self) -> None:
        wrapped = getattr(XibifMessage, "_split_at_whitespace")(["one two three four five"], width=7)

        self.assertEqual(wrapped, ["one", "two", "three", "four", "five"])

    def test_generate_ascii_art_honors_requested_height(self) -> None:
        art = getattr(XibifMessage, "_generate_ascii_art")(9)

        self.assertEqual(len(art), 9)
        self.assertTrue(all(line.startswith("> ") for line in art))

    @patch("xibif.types.messages.start_periodic_logger")
    @patch("xibif.types.messages.stop_periodic_logger")
    @patch("xibif.types.messages.xibif_print")
    @patch("builtins.input", side_effect=["invalid", "y"])
    def test_ask_retries_until_valid_yes(self, mock_input, mock_print, mock_stop, mock_start) -> None:
        message = XibifMessage(title="Headline", message="Body")

        result = message.ask("Continue?")

        self.assertTrue(result)
        self.assertEqual(mock_input.call_count, 2)
        self.assertTrue(mock_print.called)
        mock_stop.assert_called_once()
        mock_start.assert_called_once()
