"""Targeted tests for xibif.corsair.generators."""

# pylint: disable=missing-function-docstring,missing-class-docstring,unused-argument

from pathlib import Path
import tempfile
from types import SimpleNamespace
from unittest.mock import patch
import unittest

import xibif.corsair.generators as gen


class CorsairGeneratorsTests(unittest.TestCase):
    """Cover lightweight branches in custom generator wrappers."""

    def setUp(self) -> None:
        self.temp_dir = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp_dir.cleanup)
        self.base = Path(self.temp_dir.name)

    def test_jinja2_render_uses_kwargs_vars_and_custom_path(self) -> None:
        template_dir = self.base / "tpl"
        template_dir.mkdir(parents=True, exist_ok=True)
        (template_dir / "hello.j2").write_text("Hello {{ name }}", encoding="utf-8")

        rendered = gen.Jinja2().render("hello.j2", templates_path=str(template_dir), vars={"name": "XiBIF"})

        self.assertEqual(rendered, "Hello XiBIF")

    def test_cheader_generate_adds_json_when_enabled(self) -> None:
        fake_rmap = SimpleNamespace(as_dict=lambda: {"regs": [1]})
        generator = gen.CHeader(rmap=fake_rmap, path="regs.h", add_json=True)

        with patch.object(gen.CHeader, "validate"), patch.object(gen.CHeader, "render_to_file") as mock_render:
            generator.generate()

        j2_vars = mock_render.call_args.args[1]
        self.assertIn("rmap_json", j2_vars)

    def test_vhdl_generate_calls_template_render(self) -> None:
        generator = gen.Vhdl(rmap=[], path="regs.vhd", read_filler=0, interface="axil")

        with (
            patch.dict(gen.config.globcfg, {"address_increment": "data_width", "address_alignment": "data_width", "data_width": 32}, clear=False),
            patch.object(gen.Vhdl, "validate"),
            patch.object(gen.Vhdl, "render_to_file") as mock_render,
        ):
            generator.generate()

        self.assertEqual(mock_render.call_args.args[0], "regmap_vhdl.j2")

    def test_python_generate_renders_expected_template(self) -> None:
        generator = gen.Python(rmap=[], path="regs.py")

        with patch.object(gen.Python, "validate"), patch.object(gen.Python, "render_to_file") as mock_render:
            generator.generate()

        self.assertEqual(mock_render.call_args.args[0], "regmap_py.j2")

    def test_matlab_generate_emits_per_register_and_main_files(self) -> None:
        reg1 = SimpleNamespace(name="regA")
        reg2 = SimpleNamespace(name="regB")
        generator = gen.Matlab(rmap=[reg1, reg2], path=str(self.base / "regs.m"))

        with (
            patch.object(gen.Matlab, "validate"),
            patch("xibif.corsair.generators.os.path.exists", return_value=False),
            patch("xibif.corsair.generators.os.makedirs") as mock_makedirs,
            patch.object(gen.Matlab, "render_to_file") as mock_render,
        ):
            generator.generate()

        mock_makedirs.assert_called_once()
        self.assertEqual(mock_render.call_count, 3)

    def test_vunitvhdl_validate_rejects_non_axil(self) -> None:
        generator = gen.VunitVhdl(rmap=[], interface="apb")

        with self.assertRaises(AssertionError):
            generator.validate()

    def test_latex_generate_rewrites_braces_and_draws_images(self) -> None:
        out_file = self.base / "regs.tex"
        generator = gen.Latex(rmap=[], path=str(out_file), print_images=True, image_dir="img")

        def _write_template(_template, _vars, path, templates_path=None):
            Path(path).write_text("A { spaced } value", encoding="utf-8")

        with patch.object(gen.Latex, "validate"), patch.object(gen.Latex, "render_to_file", side_effect=_write_template), patch.object(gen.Latex, "draw_regs") as mock_draw:
            generator.generate()

        self.assertEqual(out_file.read_text(encoding="utf-8"), "A {spaced} value")
        mock_draw.assert_called_once()

    def test_latex_generate_skips_draw_when_images_disabled(self) -> None:
        out_file = self.base / "regs_no_img.tex"
        generator = gen.Latex(rmap=[], path=str(out_file), print_images=False, image_dir="img")

        def _write_template(_template, _vars, path, templates_path=None):
            Path(path).write_text("X { y }", encoding="utf-8")

        with patch.object(gen.Latex, "validate"), patch.object(gen.Latex, "render_to_file", side_effect=_write_template), patch.object(gen.Latex, "draw_regs") as mock_draw:
            generator.generate()

        mock_draw.assert_not_called()

    def test_guipython_generate_renders_expected_template(self) -> None:
        generator = gen.GuiPython(rmap=[], path="gui.py", default_read="true", default_write="false", show_reg_name="true")

        with patch.object(gen.GuiPython, "validate"), patch.object(gen.GuiPython, "render_to_file") as mock_render:
            generator.generate()

        self.assertEqual(mock_render.call_args.args[0], "gui_py.j2")

    def test_vhdlpackage_generate_uses_uppercase_prefix(self) -> None:
        generator = gen.VhdlPackage(rmap=[], path="pkg.vhd", prefix="csr", module_name="mod")

        with patch.object(gen.VhdlPackage, "validate"), patch.object(gen.VhdlPackage, "render_to_file") as mock_render:
            generator.generate()

        j2_vars = mock_render.call_args.args[1]
        self.assertEqual(j2_vars["prefix"], "CSR")
        self.assertEqual(j2_vars["module_name"], "mod")

    def test_vunitvhdl_generate_renders_template_for_axil(self) -> None:
        generator = gen.VunitVhdl(rmap=[], path="tb.vhd", module_name="mod", interface="axil")

        with patch.object(gen.VunitVhdl, "validate"), patch.object(gen.VunitVhdl, "render_to_file") as mock_render:
            generator.generate()

        self.assertEqual(mock_render.call_args.args[0], "vunit_vhdl.j2")

    def test_pdf_generate_builds_document(self) -> None:
        out_file = self.base / "regs.pdf"
        cfg = {
            "regmap_path": "regs.yml",
            "base_address": 0,
            "address_width": 32,
            "data_width": 32,
            "register_reset": "sync_pos",
        }

        class _Doc:
            def __init__(self, *_args, **_kwargs):
                self.build_called = False

            def build(self, _elements):
                self.build_called = True

        fake_doc = _Doc()

        with patch.dict(gen.config.globcfg, cfg, clear=False):
            generator = gen.Pdf(rmap=[], path=str(out_file), print_images=False)

            with patch.object(gen.Pdf, "validate"), patch("xibif.corsair.generators.SimpleDocTemplate", return_value=fake_doc), patch("xibif.corsair.generators.utils.create_dirs"):
                generator.generate()

        self.assertTrue(fake_doc.build_called)
