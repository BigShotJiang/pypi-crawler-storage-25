"""Corsair tests package."""
