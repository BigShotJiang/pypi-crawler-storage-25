"""Tests for xibif.corsair package proxy helpers."""

# pylint: disable=missing-function-docstring,missing-class-docstring

from types import SimpleNamespace
from unittest.mock import patch
import unittest

import xibif.corsair as corsair_pkg


class CorsairInitTests(unittest.TestCase):
    """Verify delegated attribute access and dir composition."""

    def test_getattr_delegates_to_external_corsair(self) -> None:
        fake_external = SimpleNamespace(answer=42)

        with patch.object(corsair_pkg, "_corsair", fake_external):
            self.assertEqual(corsair_pkg.__getattr__("answer"), 42)

    def test_dir_combines_local_and_delegated_symbols(self) -> None:
        fake_external = SimpleNamespace(external_symbol=True)

        with patch.object(corsair_pkg, "_corsair", fake_external):
            names = corsair_pkg.__dir__()

        self.assertIn("apply_patches", names)
        self.assertIn("external_symbol", names)
