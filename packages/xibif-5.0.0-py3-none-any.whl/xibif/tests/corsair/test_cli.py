"""Tests for xibif.corsair.cli."""

# pylint: disable=missing-function-docstring,missing-class-docstring

from types import SimpleNamespace
from unittest.mock import MagicMock, patch
import unittest

from xibif.corsair import cli as corsair_cli


class CorsairCliTests(unittest.TestCase):
    """Verify patch injection and CLI delegation."""

    def test_apply_patches_injects_only_generator_subclasses(self) -> None:
        class BaseGenerator:
            pass

        class GoodGenerator(BaseGenerator):
            pass

        class OtherClass:
            pass

        fake_generators = SimpleNamespace(
            Generator=BaseGenerator,
            GoodGenerator=GoodGenerator,
            OtherClass=OtherClass,
            value=1,
        )
        fake_corsair = SimpleNamespace(generators=SimpleNamespace())

        with patch.object(corsair_cli, "xibif_generators", fake_generators), patch.object(corsair_cli, "_corsair", fake_corsair):
            corsair_cli.apply_patches()

        self.assertTrue(hasattr(fake_corsair.generators, "GoodGenerator"))
        self.assertFalse(hasattr(fake_corsair.generators, "OtherClass"))

    def test_main_calls_apply_patches_then_external_main(self) -> None:
        main_mock = MagicMock()
        fake_main_module = SimpleNamespace(main=main_mock)

        with patch.object(corsair_cli, "apply_patches") as patch_apply, patch.object(corsair_cli, "_corsair_main", fake_main_module):
            corsair_cli.main()

        patch_apply.assert_called_once()
        main_mock.assert_called_once()
