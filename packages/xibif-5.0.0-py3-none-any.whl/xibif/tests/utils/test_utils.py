"""Tests for xibif.utils.utils."""

# pylint: disable=missing-function-docstring,missing-class-docstring

from pathlib import Path
import tempfile
from unittest.mock import MagicMock, patch
import unittest

from xibif.types import XibifPath, XilinxVersion
from xibif.utils.utils import (
    check_tool,
    check_tool_running,
    check_tool_running_and_ask,
    check_windows_shell,
    generate_random_mac,
    get_clean_shell,
    get_clean_shell_batch_command,
    get_default_xilinx_path,
    get_version,
    get_xilinx_tool_paths,
    igetattr,
    scan_xilinx_version,
    start_tool,
)


class UtilsTests(unittest.TestCase):
    """Verify utility helper behavior and key branches."""

    def setUp(self) -> None:
        self.temp_dir = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp_dir.cleanup)
        self.temp_path = Path(self.temp_dir.name)

    def test_get_version_parses_dev_revision(self) -> None:
        version = get_version(version_str="1.2.3.dev4+abc.5")

        self.assertEqual(version.major, 1)
        self.assertEqual(version.minor, 2)
        self.assertEqual(version.patch, 3)
        self.assertEqual(version.revision, 4)

    def test_generate_random_mac_uses_xibif_prefix(self) -> None:
        mac = str(generate_random_mac())

        self.assertTrue(mac.startswith("00:0a:35:"))

    def test_igetattr_is_case_insensitive_and_returns_default(self) -> None:
        class Demo:
            Value = 42

        self.assertEqual(igetattr(Demo, "value"), 42)
        self.assertEqual(igetattr(Demo, "missing", default="fallback"), "fallback")

    @patch("xibif.utils.utils.platform.system", return_value="Windows")
    def test_get_default_xilinx_path_windows(self, _mock_system) -> None:
        normalized = str(get_default_xilinx_path()).replace("\\", "/")
        self.assertTrue(normalized.endswith("C:/Xilinx"))

    @patch("xibif.utils.utils.platform.system", return_value="Linux")
    def test_get_default_xilinx_path_linux(self, _mock_system) -> None:
        normalized = str(get_default_xilinx_path()).replace("\\", "/")
        self.assertTrue(normalized.endswith("/opt/Xilinx"))

    @patch("xibif.utils.utils.platform.system", return_value="Other")
    def test_get_default_xilinx_path_other(self, _mock_system) -> None:
        self.assertEqual(str(get_default_xilinx_path()), str(XibifPath("")))

    def test_scan_xilinx_version_returns_latest_supported(self) -> None:
        root = self.temp_path / "xilinx"
        (root / "vivado" / "2023.2").mkdir(parents=True, exist_ok=True)
        (root / "vitis" / "2023.2").mkdir(parents=True, exist_ok=True)
        (root / "2025.1" / "vivado").mkdir(parents=True, exist_ok=True)
        (root / "2025.1" / "vitis").mkdir(parents=True, exist_ok=True)

        scanned = scan_xilinx_version(XibifPath(root))

        self.assertEqual(scanned, XilinxVersion.V2025_1)

    def test_scan_xilinx_version_returns_none_for_missing_folder(self) -> None:
        scanned = scan_xilinx_version(XibifPath(self.temp_path / "does_not_exist"))

        self.assertIsNone(scanned)

    @patch("xibif.utils.utils.getpass.getuser", return_value="alice")
    @patch("xibif.utils.utils.psutil.process_iter")
    def test_check_tool_running_detects_tool_by_name(self, mock_process_iter, _mock_user) -> None:
        proc = MagicMock()
        proc.info = {"name": "vivado.exe", "cmdline": ["vivado.exe"], "username": "alice"}
        mock_process_iter.return_value = [proc]

        self.assertTrue(check_tool_running("vivado"))

    @patch("xibif.utils.utils.getpass.getuser", return_value="alice")
    @patch("xibif.utils.utils.psutil.process_iter")
    def test_check_tool_running_ignores_non_matching_entries(self, mock_process_iter, _mock_user) -> None:
        proc1 = MagicMock()
        proc1.info = {"name": "xibif", "cmdline": ["xibif"], "username": "alice"}
        proc2 = MagicMock()
        proc2.info = {"name": "other", "cmdline": ["other"], "username": "bob"}
        mock_process_iter.return_value = [proc1, proc2]

        self.assertFalse(check_tool_running("vivado"))

    @patch("xibif.utils.utils.XibifMessage")
    @patch("xibif.utils.utils.check_tool_running", return_value=True)
    def test_check_tool_running_and_ask_prompts_when_running(self, _mock_running, mock_message) -> None:
        message_instance = MagicMock()
        message_instance.ask.return_value = False
        mock_message.return_value = message_instance

        result = check_tool_running_and_ask("vivado")

        self.assertFalse(result)
        message_instance.ask.assert_called_once()

    @patch("xibif.utils.utils.check_tool_running", return_value=False)
    def test_check_tool_running_and_ask_returns_true_when_not_running(self, _mock_running) -> None:
        self.assertTrue(check_tool_running_and_ask("vivado"))

    @patch("xibif.utils.utils.subprocess.Popen")
    @patch("xibif.utils.utils.os.getenv", return_value="C:\\Windows")
    @patch("xibif.utils.utils.platform.system", return_value="Windows")
    def test_start_tool_windows_builds_cmd_start_command(self, _mock_system, _mock_getenv, mock_popen) -> None:
        start_tool(executable=XibifPath("C:/tool.exe"), cmdline_params=["-a", "1"])

        cmd_string = mock_popen.call_args.args[0]
        self.assertIn("cmd.exe /c start", cmd_string)
        self.assertIn("tool.exe", cmd_string)

    @patch("xibif.utils.utils.subprocess.Popen")
    @patch("xibif.utils.utils.check_tool", return_value=True)
    @patch("xibif.utils.utils.platform.system", return_value="Linux")
    def test_start_tool_linux_prefers_gnome_terminal(self, _mock_system, _mock_check_tool, mock_popen) -> None:
        start_tool(executable=XibifPath("/usr/bin/tool"), cmdline_params="--help")

        cmd_string = mock_popen.call_args.args[0]
        self.assertIn("gnome-terminal -- bash -c", cmd_string)

    @patch("xibif.utils.utils.shutil.which", return_value="/usr/bin/vivado")
    def test_check_tool_uses_which(self, _mock_which) -> None:
        self.assertTrue(check_tool("vivado"))

    @patch("xibif.utils.utils.platform.system", return_value="Windows")
    def test_check_windows_shell_detects_powershell_env(self, _mock_system) -> None:
        with patch.dict("xibif.utils.utils.os.environ", {"PSModulePath": "x"}, clear=True):
            self.assertTrue(check_windows_shell())

    @patch("xibif.utils.utils.platform.system", return_value="Windows")
    def test_check_windows_shell_detects_cmd(self, _mock_system) -> None:
        with patch.dict("xibif.utils.utils.os.environ", {"COMSPEC": "C:\\Windows\\System32\\cmd.exe"}, clear=True):
            self.assertTrue(check_windows_shell())

    @patch("xibif.utils.utils.platform.system", return_value="Linux")
    def test_check_windows_shell_returns_false_on_linux(self, _mock_system) -> None:
        self.assertFalse(check_windows_shell())

    @patch("xibif.utils.utils.check_windows_shell", return_value=True)
    def test_get_xilinx_tool_paths_uses_legacy_layout(self, _mock_windows_shell) -> None:
        xilinx_root = self.temp_path / "Xilinx"
        vivado_bin = xilinx_root / "Vivado" / "2024.2" / "bin"
        vitis_bin = xilinx_root / "Vitis" / "2024.2" / "bin"
        vivado_bin.mkdir(parents=True, exist_ok=True)
        vitis_bin.mkdir(parents=True, exist_ok=True)
        (vivado_bin / "vivado").write_text("tool", encoding="utf-8")
        (vitis_bin / "vitis").write_text("tool", encoding="utf-8")
        (vitis_bin / "xsct").write_text("tool", encoding="utf-8")
        (vivado_bin / "cs_server").write_text("tool", encoding="utf-8")
        (vivado_bin / "hw_server").write_text("tool", encoding="utf-8")
        (xilinx_root / "Vivado" / "2024.2" / "settings64.bat").write_text("tool", encoding="utf-8")

        paths = get_xilinx_tool_paths(XibifPath(xilinx_root), XilinxVersion.V2024_2)

        self.assertEqual(paths.vivado, XibifPath(vivado_bin / "vivado"))
        self.assertEqual(paths.vitis, XibifPath(vitis_bin / "vitis"))

    @patch("xibif.utils.utils.check_windows_shell", return_value=True)
    @patch("xibif.utils.utils.os.getenv", return_value="C:\\Windows")
    def test_get_clean_shell_windows(self, _mock_getenv, _mock_windows_shell) -> None:
        command = get_clean_shell(XibifPath("clean.bat"))

        self.assertIn("cmd.exe", command)

    @patch("xibif.utils.utils.check_windows_shell", return_value=False)
    def test_get_clean_shell_posix(self, _mock_windows_shell) -> None:
        self.assertEqual(get_clean_shell(XibifPath("clean.sh")), "bash -c")

    @patch("xibif.utils.utils.check_windows_shell", return_value=True)
    def test_get_clean_shell_batch_command_windows(self, _mock_windows_shell) -> None:
        self.assertEqual(get_clean_shell_batch_command("call settings64.bat"), "call settings64.bat && ")

    @patch("xibif.utils.utils.check_windows_shell", return_value=False)
    def test_get_clean_shell_batch_command_posix(self, _mock_windows_shell) -> None:
        self.assertEqual(get_clean_shell_batch_command("/opt/settings64.sh"), "source /opt/settings64.sh && ")
