"""Tests for the XibifProject class."""

# pylint: disable=missing-function-docstring,missing-class-docstring

import json
from pathlib import Path
import tempfile
from unittest.mock import patch
import unittest

from xibif.project.project import XibifProject
from xibif.types import XibifChecksumError, XibifDefaults, XibifInvalidPathError, XibifPath


class XibifProjectTests(unittest.TestCase):
    """Verify config persistence and loading behavior."""

    def setUp(self) -> None:
        self.temp_dir = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp_dir.cleanup)
        self.project_path = XibifPath(self.temp_dir.name)
        XibifPath.set_root(Path(self.temp_dir.name))

    @patch("xibif.project.project.get_version")
    def test_write_config_creates_project_file(self, mock_get_version) -> None:
        mock_get_version.return_value = "1.0.0.0"
        project = XibifProject(self.project_path)

        project.write_config()

        config_file = Path(self.temp_dir.name) / XibifDefaults.PROJECT_NAME
        self.assertTrue(config_file.exists())
        config_data = json.loads(config_file.read_text())
        self.assertEqual(config_data["project_name"], project.name)

    @patch("xibif.project.project.get_version")
    def test_load_config_traverses_upward(self, mock_get_version) -> None:
        mock_get_version.return_value = "1.0.0.0"
        project = XibifProject(self.project_path)
        project.write_config()

        nested_folder = Path(self.temp_dir.name) / "nested" / "deeper"
        nested_folder.mkdir(parents=True)
        loader = XibifProject(XibifPath(nested_folder))

        loader.load_config()

        self.assertEqual(loader.path, self.project_path)

    @patch("xibif.project.project.get_version")
    def test_load_config_raises_on_checksum_mismatch(self, mock_get_version) -> None:
        mock_get_version.return_value = "1.0.0.0"
        project = XibifProject(self.project_path)
        project.write_config()
        config_file = Path(self.temp_dir.name) / XibifDefaults.PROJECT_NAME
        data = json.loads(config_file.read_text())
        data["project_name"] = "modified"
        config_file.write_text(json.dumps(data))

        with self.assertRaises(XibifChecksumError):
            XibifProject(self.project_path).load_config()

    def test_load_config_raises_when_file_is_missing(self) -> None:
        with self.assertRaises(XibifInvalidPathError):
            XibifProject(self.project_path).load_config()
