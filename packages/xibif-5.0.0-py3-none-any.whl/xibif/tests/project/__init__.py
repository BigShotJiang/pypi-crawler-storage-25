"""Tests for xibif.project."""
