"""Tests for project models."""

# pylint: disable=missing-function-docstring,missing-class-docstring

import unittest

from pydantic import ValidationError

from xibif.project.models import XibifConfig, XibifRegister, XibifSettings, XibifTooling
from xibif.types import XibifPath, XilinxBoard, XilinxVersion


class ProjectModelsTests(unittest.TestCase):
    """Validate model defaults and constraints."""

    def test_tooling_accepts_version_and_path(self) -> None:
        tooling = XibifTooling(xilinx_version=XilinxVersion.V2024_2, xilinx_path=XibifPath("C:/Xilinx"))

        self.assertEqual(tooling.xilinx_version, XilinxVersion.V2024_2)
        self.assertEqual(tooling.xilinx_path, XibifPath("C:/Xilinx"))

    def test_register_defaults_disable_custom_config(self) -> None:
        register = XibifRegister()

        self.assertFalse(register.custom_register_enabled)
        self.assertEqual(register.custom_register_config_name, "")

    def test_settings_validate_numeric_ranges(self) -> None:
        with self.assertRaises(ValidationError):
            XibifSettings(timeout_dhcp=0)

    def test_config_uses_expected_defaults(self) -> None:
        config = XibifConfig()

        self.assertEqual(config.project_name, "xibif")
        self.assertEqual(config.board, XilinxBoard.ZEDBOARD)
