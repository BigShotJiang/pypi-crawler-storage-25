"""Tests for the CLI entry point."""

# pylint: disable=missing-function-docstring,missing-class-docstring

import argparse
from unittest.mock import MagicMock, patch
import unittest

from xibif.__main__ import handle_error, main
from xibif.types import XibifPath


class MainTests(unittest.TestCase):
    """Validate entry-point routing and error handling."""

    @patch("xibif.__main__.sys.exit", side_effect=SystemExit(1))
    @patch("xibif.__main__.xibif_print_error")
    def test_handle_error_prints_and_exits(self, mock_print_error, mock_exit) -> None:
        with self.assertRaises(SystemExit):
            handle_error(RuntimeError("boom"))

        mock_print_error.assert_called_once()
        mock_exit.assert_called_once_with(1)

    @patch("xibif.__main__.logger")
    @patch("xibif.__main__.start_periodic_logger")
    @patch("xibif.__main__.setup_logger")
    @patch("xibif.__main__.generate_parser")
    @patch("xibif.__main__.XibifProject")
    def test_main_does_not_write_config_for_log_command(self, mock_project_class, mock_generate_parser, mock_setup_logger, mock_start_logger, mock_logger) -> None:
        parser = MagicMock()
        args = argparse.Namespace(command="log", func=MagicMock(side_effect=lambda project, _args: project), verbosity="info", summary=False)
        parser.parse_args.return_value = args
        mock_generate_parser.return_value = parser
        project = MagicMock()
        mock_project_class.return_value = project
        bound_logger = MagicMock()
        bound_logger.catch.return_value.__enter__.return_value = None
        bound_logger.catch.return_value.__exit__.return_value = None
        mock_logger.bind.return_value = bound_logger

        main()

        mock_setup_logger.assert_called_once()
        mock_start_logger.assert_called_once()
        project.write_config.assert_not_called()

    @patch("xibif.__main__.logger")
    @patch("xibif.__main__.start_periodic_logger")
    @patch("xibif.__main__.setup_logger")
    @patch("xibif.__main__.generate_parser")
    @patch("xibif.__main__.XibifPath")
    @patch("xibif.__main__.XibifProject")
    def test_main_loads_and_writes_project_for_regular_command(self, mock_project_class, mock_xibif_path, mock_generate_parser, mock_setup_logger, mock_start_logger, mock_logger) -> None:
        parser = MagicMock()
        args = argparse.Namespace(command="build", func=MagicMock(side_effect=lambda project, _args: project), verbosity="info", summary=False, project=None)
        parser.parse_args.return_value = args
        mock_generate_parser.return_value = parser
        project = MagicMock()
        mock_project_class.return_value = project
        mock_xibif_path.cwd.return_value = XibifPath(".")
        bound_logger = MagicMock()
        bound_logger.catch.return_value.__enter__.return_value = None
        bound_logger.catch.return_value.__exit__.return_value = None
        mock_logger.bind.return_value = bound_logger

        main()

        mock_setup_logger.assert_called_once()
        project.load_config.assert_called_once()
        project.write_config.assert_called_once()
        mock_start_logger.assert_called_once()
