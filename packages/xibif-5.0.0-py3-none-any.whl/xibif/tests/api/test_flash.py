"""Tests for the flash API."""

# pylint: disable=missing-function-docstring,missing-class-docstring

from pathlib import Path
import tempfile
from types import SimpleNamespace
from unittest.mock import MagicMock, patch
import unittest

from xibif.api.flash import flash_hardware_server
from xibif.types import XibifEnvironmentError, XibifInvalidPathError, XibifPath, XilinxBoard, XilinxVersion


class FlashApiTests(unittest.TestCase):
    """Verify flashing preconditions and command flow."""

    def setUp(self) -> None:
        self.temp_dir = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp_dir.cleanup)
        self.results_folder = XibifPath(Path(self.temp_dir.name) / "results")
        self.results_folder.mkdir(parents=True, exist_ok=True)

    @patch("xibif.api.flash.get_xilinx_tool_paths")
    @patch("xibif.api.flash.ShellFactory.create_shell")
    @patch("xibif.api.flash.CommandSetFactory.get_command_set")
    def test_flash_requires_bitstream(self, mock_get_command_set, mock_create_shell, mock_get_tool_paths) -> None:
        mock_get_command_set.return_value = MagicMock()
        mock_create_shell.return_value = MagicMock()
        mock_get_tool_paths.return_value = SimpleNamespace(xsct=self.results_folder.joinpath("xsct.exe"), settings64_script=self.results_folder.joinpath("settings.bat"))
        self.results_folder.joinpath("xsct.exe").write_text("tool")
        self.results_folder.joinpath("settings.bat").write_text("tool")

        with self.assertRaises(XibifInvalidPathError):
            flash_hardware_server(
                project_name="demo",
                board=XilinxBoard.ZEDBOARD,
                xilinx_version=XilinxVersion.V2024_2,
                results_folder=self.results_folder,
                xilinx_path=self.results_folder,
            )

    def test_flash_requires_xilinx_path_if_runtime_is_none(self) -> None:
        with self.assertRaises(XibifEnvironmentError):
            flash_hardware_server(
                project_name="demo",
                board=XilinxBoard.ZEDBOARD,
                xilinx_version=XilinxVersion.V2024_2,
                results_folder=self.results_folder,
            )

    @patch("xibif.api.flash.get_xilinx_tool_paths")
    @patch("xibif.api.flash.ShellFactory.create_shell")
    @patch("xibif.api.flash.CommandSetFactory.get_command_set")
    def test_flash_with_runtime_requires_hardware_xsa_file(self, mock_get_command_set, mock_create_shell, mock_get_tool_paths) -> None:
        self.results_folder.joinpath("demo").with_suffix(".bit").write_text("data")
        mock_get_command_set.return_value = MagicMock()
        mock_create_shell.return_value = MagicMock()
        mock_get_tool_paths.return_value = SimpleNamespace(xsct=self.results_folder.joinpath("xsct.exe"), settings64_script=self.results_folder.joinpath("settings.bat"))
        self.results_folder.joinpath("xsct.exe").write_text("tool")
        self.results_folder.joinpath("settings.bat").write_text("tool")

        with self.assertRaises(XibifInvalidPathError):
            flash_hardware_server(
                project_name="demo",
                board=XilinxBoard.ZEDBOARD,
                xilinx_version=XilinxVersion.V2024_2,
                results_folder=self.results_folder,
                xilinx_path=self.results_folder,
            )

    @patch("xibif.api.flash.get_xilinx_tool_paths")
    @patch("xibif.api.flash.ShellFactory.create_shell")
    @patch("xibif.api.flash.CommandSetFactory.get_command_set")
    def test_flash_with_runtime_requires_fsbl_file(self, mock_get_command_set, mock_create_shell, mock_get_tool_paths) -> None:
        self.results_folder.joinpath("demo").with_suffix(".bit").write_text("data")
        self.results_folder.joinpath("demo").with_suffix(".xsa").write_text("data")
        mock_get_command_set.return_value = MagicMock()
        mock_create_shell.return_value = MagicMock()
        mock_get_tool_paths.return_value = SimpleNamespace(xsct=self.results_folder.joinpath("xsct.exe"), settings64_script=self.results_folder.joinpath("settings.bat"))
        self.results_folder.joinpath("xsct.exe").write_text("tool")
        self.results_folder.joinpath("settings.bat").write_text("tool")

        with self.assertRaises(XibifInvalidPathError):
            flash_hardware_server(
                project_name="demo",
                board=XilinxBoard.ZEDBOARD,
                xilinx_version=XilinxVersion.V2024_2,
                results_folder=self.results_folder,
                xilinx_path=self.results_folder,
            )

    @patch("xibif.api.flash.get_xilinx_tool_paths")
    @patch("xibif.api.flash.ShellFactory.create_shell")
    @patch("xibif.api.flash.CommandSetFactory.get_command_set")
    def test_flash_with_runtime_requires_application_elf_file(self, mock_get_command_set, mock_create_shell, mock_get_tool_paths) -> None:
        self.results_folder.joinpath("demo").with_suffix(".bit").write_text("data")
        self.results_folder.joinpath("demo").with_suffix(".xsa").write_text("data")
        self.results_folder.joinpath("fsbl").with_suffix(".elf").write_text("data")
        mock_get_command_set.return_value = MagicMock()
        mock_create_shell.return_value = MagicMock()
        mock_get_tool_paths.return_value = SimpleNamespace(xsct=self.results_folder.joinpath("xsct.exe"), settings64_script=self.results_folder.joinpath("settings.bat"))
        self.results_folder.joinpath("xsct.exe").write_text("tool")
        self.results_folder.joinpath("settings.bat").write_text("tool")

        with self.assertRaises(XibifInvalidPathError):
            flash_hardware_server(
                project_name="demo",
                board=XilinxBoard.ZEDBOARD,
                xilinx_version=XilinxVersion.V2024_2,
                results_folder=self.results_folder,
                xilinx_path=self.results_folder,
            )

    @patch("xibif.api.flash.get_xilinx_tool_paths")
    @patch("xibif.api.flash.ShellFactory.create_shell")
    @patch("xibif.api.flash.CommandSetFactory.get_command_set")
    def test_flash_runs_expected_commands(self, mock_get_command_set, mock_create_shell, mock_get_tool_paths) -> None:
        for suffix in [".bit", ".xsa"]:
            self.results_folder.joinpath("demo").with_suffix(suffix).write_text("data")
        self.results_folder.joinpath("fsbl").with_suffix(".elf").write_text("data")
        self.results_folder.joinpath("xibif").with_suffix(".elf").write_text("data")

        commands = MagicMock()
        commands.connect_hwserver.return_value = "connect"
        commands.flash.return_value = "flash"
        commands.connect_ps.return_value = "connect_ps"
        commands.disconnect.return_value = "disconnect"
        mock_get_command_set.return_value = commands

        runtime = MagicMock()
        runtime.__enter__.return_value = runtime
        runtime.__exit__.return_value = None
        mock_create_shell.return_value = runtime
        mock_get_tool_paths.return_value = SimpleNamespace(xsct=self.results_folder.joinpath("xsct.exe"), settings64_script=self.results_folder.joinpath("settings.bat"))
        self.results_folder.joinpath("xsct.exe").write_text("tool")
        self.results_folder.joinpath("settings.bat").write_text("tool")

        flash_hardware_server(
            project_name="demo",
            board=XilinxBoard.ZEDBOARD,
            xilinx_version=XilinxVersion.V2024_2,
            results_folder=self.results_folder,
            xilinx_path=self.results_folder,
        )

        commands.connect_hwserver.assert_called_once()
        commands.flash.assert_called_once()
        runtime.run.assert_called()

    @patch("xibif.api.flash.time.time", return_value=9_999_999_999)
    @patch("xibif.api.flash.get_xilinx_tool_paths")
    @patch("xibif.api.flash.ShellFactory.create_shell")
    @patch("xibif.api.flash.CommandSetFactory.get_command_set")
    def test_flash_allows_old_files_and_still_executes(self, mock_get_command_set, mock_create_shell, mock_get_tool_paths, _mock_time) -> None:
        for suffix in [".bit", ".xsa"]:
            self.results_folder.joinpath("demo").with_suffix(suffix).write_text("data")
        self.results_folder.joinpath("fsbl").with_suffix(".elf").write_text("data")
        self.results_folder.joinpath("xibif").with_suffix(".elf").write_text("data")

        commands = MagicMock()
        commands.connect_hwserver.return_value = "connect"
        commands.flash.return_value = "flash"
        commands.connect_ps.return_value = "connect_ps"
        commands.disconnect.return_value = "disconnect"
        mock_get_command_set.return_value = commands

        runtime = MagicMock()
        runtime.__enter__.return_value = runtime
        runtime.__exit__.return_value = None
        mock_create_shell.return_value = runtime
        mock_get_tool_paths.return_value = SimpleNamespace(xsct=self.results_folder.joinpath("xsct.exe"), settings64_script=self.results_folder.joinpath("settings.bat"))
        self.results_folder.joinpath("xsct.exe").write_text("tool")
        self.results_folder.joinpath("settings.bat").write_text("tool")

        flash_hardware_server(
            project_name="demo",
            board=XilinxBoard.ZEDBOARD,
            xilinx_version=XilinxVersion.V2024_2,
            results_folder=self.results_folder,
            xilinx_path=self.results_folder,
        )

        commands.connect_hwserver.assert_called_once()
        commands.flash.assert_called_once()
