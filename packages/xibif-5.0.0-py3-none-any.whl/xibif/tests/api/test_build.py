"""Tests for the build API."""

# pylint: disable=missing-function-docstring,missing-class-docstring

import json
from pathlib import Path
import tempfile
from types import SimpleNamespace
from unittest.mock import MagicMock, patch
import xml.etree.ElementTree as ET
import unittest

from xibif.api.build import _build_vitis_update_launch_json, _build_vitis_update_launch_xml, build_vitis, build_vitis_regenerate, build_vivado
from xibif.api.build_stages import VitisStage, VivadoStage
from xibif.types import XibifEnvironmentError, XibifGeneratedFileError, XibifInvalidPathError, XibifPath, XilinxBoard, XilinxToolPath, XilinxVersion


class BuildApiTests(unittest.TestCase):
    """Verify core build orchestration behavior."""

    def setUp(self) -> None:
        self.temp_dir = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp_dir.cleanup)
        self.temp_path = Path(self.temp_dir.name)
        self.vivado_folder = XibifPath(self.temp_path / "vivado")
        self.results_folder = XibifPath(self.temp_path / "results")
        self.vitis_folder = XibifPath(self.temp_path / "vitis")
        self.vivado_folder.mkdir(parents=True, exist_ok=True)
        self.results_folder.mkdir(parents=True, exist_ok=True)
        self.vitis_folder.mkdir(parents=True, exist_ok=True)

    @patch("xibif.api.build.get_xilinx_tool_paths")
    @patch("xibif.api.build.ShellFactory.create_shell")
    @patch("xibif.api.build.CommandSetFactory.get_command_set")
    def test_build_vivado_runs_requested_stage_with_runtime(self, mock_get_command_set, mock_create_shell, mock_get_tool_paths) -> None:
        commands = MagicMock()
        commands.synthesize.return_value = "synth"
        mock_get_command_set.return_value = commands
        runtime = MagicMock()
        runtime.__enter__.return_value = runtime
        runtime.__exit__.return_value = None
        mock_create_shell.return_value = runtime
        mock_get_tool_paths.return_value = SimpleNamespace(vivado=XibifPath(self.temp_path / "vivado.exe"))
        (self.temp_path / "vivado.exe").write_text("tool")
        (self.vivado_folder.joinpath("demo").with_suffix(".xpr")).write_text("project")

        build_vivado(
            project_name="demo",
            xilinx_version=XilinxVersion.V2024_2,
            stages=[VivadoStage.synthesize],
            vivado_folder=self.vivado_folder,
            results_folder=self.results_folder,
            disable_report=True,
            xilinx_path=XibifPath(self.temp_path),
        )

        commands.synthesize.assert_called_once_with(run="", noopen=True)
        runtime.run.assert_called()

    def test_build_vivado_requires_xilinx_path_without_runtime(self) -> None:
        (self.vivado_folder.joinpath("demo").with_suffix(".xpr")).write_text("project")

        with self.assertRaises(XibifEnvironmentError):
            build_vivado(
                project_name="demo",
                xilinx_version=XilinxVersion.V2024_2,
                stages=[VivadoStage.synthesize],
                vivado_folder=self.vivado_folder,
                results_folder=self.results_folder,
            )

    @patch("xibif.api.build.get_xilinx_tool_paths")
    @patch("xibif.api.build.ShellFactory.create_shell")
    @patch("xibif.api.build.CommandSetFactory.get_command_set")
    def test_build_vitis_requires_hardware_file_for_update(self, mock_get_command_set, mock_create_shell, mock_get_tool_paths) -> None:
        mock_get_command_set.return_value = MagicMock()
        mock_create_shell.return_value = MagicMock()
        mock_get_tool_paths.return_value = XilinxToolPath(
            vitis=XibifPath(self.temp_path / "vitis.exe"),
            xsct=XibifPath(self.temp_path / "xsct.exe"),
            settings64_script=XibifPath(self.temp_path / "settings.bat"),
        )
        for file_name in ["vitis.exe", "xsct.exe", "settings.bat"]:
            (self.temp_path / file_name).write_text("tool")

        with self.assertRaises(XibifInvalidPathError):
            build_vitis(
                project_name="demo",
                board=XilinxBoard.ZEDBOARD,
                xilinx_version=XilinxVersion.V2024_2,
                stages=[VitisStage.update],
                vitis_folder=self.vitis_folder,
                results_folder=self.results_folder,
                xilinx_path=XibifPath(self.temp_path),
            )

    def test_build_vitis_update_launch_json_updates_bitstream(self) -> None:
        launch = self.temp_path / "launch.json"
        launch.write_text(
            json.dumps(
                {
                    "configurations": [
                        {
                            "name": "app",
                            "targetSetup": {
                                "bitstreamFile": "old.bit",
                            },
                        }
                    ]
                }
            ),
            encoding="utf-8",
        )

        result = _build_vitis_update_launch_json(XibifPath(launch), XibifPath(self.temp_path / "new.bit"))

        self.assertTrue(result)
        parsed = json.loads(launch.read_text(encoding="utf-8"))
        self.assertTrue(parsed["configurations"][0]["targetSetup"]["bitstreamFile"].endswith("new.bit"))

    def test_build_vitis_update_launch_json_rejects_invalid_file(self) -> None:
        launch = self.temp_path / "launch.json"
        launch.write_text("{invalid json}", encoding="utf-8")

        self.assertFalse(_build_vitis_update_launch_json(XibifPath(launch), XibifPath(self.temp_path / "new.bit")))

    def test_build_vitis_update_launch_xml_updates_bitstream(self) -> None:
        launch = self.temp_path / "app.launch"
        launch.write_text(
            "<launchConfiguration><stringAttribute key='com.xilinx.sdk.tcf.debug.uihw.bit.file' value='old.bit'/></launchConfiguration>",
            encoding="utf-8",
        )

        result = _build_vitis_update_launch_xml(XibifPath(launch), XibifPath(self.temp_path / "new.bit"))

        self.assertTrue(result)
        root = ET.parse(launch).getroot()
        attr = root.find(".//stringAttribute")
        self.assertIsNotNone(attr)
        self.assertTrue(attr.get("value").endswith("new.bit"))

    def test_build_vitis_update_launch_xml_rejects_invalid_file(self) -> None:
        launch = self.temp_path / "app.launch"
        launch.write_text("<launchConfiguration>", encoding="utf-8")

        self.assertFalse(_build_vitis_update_launch_xml(XibifPath(launch), XibifPath(self.temp_path / "new.bit")))

    @patch("xibif.api.build.os.path.relpath", return_value="vitis/xibif/src")
    @patch("xibif.api.build.setup_vitis_project")
    @patch("xibif.api.build.misc_create_backup")
    def test_build_vitis_regenerate_restores_sources_and_calls_setup(self, mock_backup, mock_setup_vitis_project, _mock_relpath) -> None:
        project_name = "demo"
        app_name = "xibif"
        vitis_folder = XibifPath(self.temp_path / "vitis")
        src_folder = vitis_folder.joinpath(app_name, "src")
        src_folder.mkdir(parents=True, exist_ok=True)
        src_folder.joinpath("current.c").write_text("int main(void){return 0;}", encoding="utf-8")

        backup = XibifPath(self.temp_path / "backup")
        backup_src = backup.joinpath("vitis", app_name, "src")
        backup_src.mkdir(parents=True, exist_ok=True)
        backup_src.joinpath("restored.c").write_text("int a = 1;", encoding="utf-8")
        backup_src.joinpath("restored.h").write_text("#define A 1", encoding="utf-8")
        mock_backup.return_value = backup

        build_vitis_regenerate(
            project_name=project_name,
            board=XilinxBoard.ZEDBOARD,
            xilinx_version=XilinxVersion.V2024_2,
            app_name=app_name,
            vitis_folder=vitis_folder,
            results_folder=self.results_folder,
        )

        self.assertTrue(src_folder.joinpath("restored.c").exists())
        self.assertTrue(src_folder.joinpath("restored.h").exists())
        mock_setup_vitis_project.assert_called_once()

    @patch("xibif.api.build.get_xilinx_tool_paths")
    @patch("xibif.api.build.ShellFactory.create_shell")
    @patch("xibif.api.build.CommandSetFactory.get_command_set")
    def test_build_vivado_raises_if_bitstream_not_generated(self, mock_get_command_set, mock_create_shell, mock_get_tool_paths) -> None:
        commands = MagicMock()
        mock_get_command_set.return_value = commands
        runtime = MagicMock()
        runtime.__enter__.return_value = runtime
        runtime.__exit__.return_value = None
        mock_create_shell.return_value = runtime
        mock_get_tool_paths.return_value = SimpleNamespace(vivado=XibifPath(self.temp_path / "vivado.exe"))
        (self.temp_path / "vivado.exe").write_text("tool", encoding="utf-8")
        (self.vivado_folder.joinpath("demo").with_suffix(".xpr")).write_text("project", encoding="utf-8")

        with self.assertRaises(XibifGeneratedFileError):
            build_vivado(
                project_name="demo",
                xilinx_version=XilinxVersion.V2024_2,
                stages=[VivadoStage.bitstream],
                vivado_folder=self.vivado_folder,
                results_folder=self.results_folder,
                disable_report=True,
                xilinx_path=XibifPath(self.temp_path),
            )

    @patch("xibif.api.build.xibif_print_warning")
    @patch("xibif.api.build.get_xilinx_tool_paths")
    @patch("xibif.api.build.ShellFactory.create_shell")
    @patch("xibif.api.build.CommandSetFactory.get_command_set")
    def test_build_vivado_warns_when_timing_report_disabled(self, mock_get_command_set, mock_create_shell, mock_get_tool_paths, mock_warn) -> None:
        commands = MagicMock()
        mock_get_command_set.return_value = commands
        runtime = MagicMock()
        runtime.__enter__.return_value = runtime
        runtime.__exit__.return_value = None
        mock_create_shell.return_value = runtime
        mock_get_tool_paths.return_value = SimpleNamespace(vivado=XibifPath(self.temp_path / "vivado.exe"))
        (self.temp_path / "vivado.exe").write_text("tool", encoding="utf-8")
        (self.vivado_folder.joinpath("demo").with_suffix(".xpr")).write_text("project", encoding="utf-8")

        build_vivado(
            project_name="demo",
            xilinx_version=XilinxVersion.V2024_2,
            stages=[VivadoStage.reportTiming],
            vivado_folder=self.vivado_folder,
            results_folder=self.results_folder,
            disable_report=True,
            xilinx_path=XibifPath(self.temp_path),
        )

        mock_warn.assert_called()

    @patch("xibif.api.build.get_xilinx_tool_paths")
    @patch("xibif.api.build.ShellFactory.create_shell")
    @patch("xibif.api.build.CommandSetFactory.get_command_set")
    def test_build_vitis_bootfile_requires_app_if_export_not_selected(self, mock_get_command_set, mock_create_shell, mock_get_tool_paths) -> None:
        mock_get_command_set.return_value = MagicMock()
        mock_create_shell.return_value = MagicMock()
        mock_get_tool_paths.return_value = XilinxToolPath(
            vitis=XibifPath(self.temp_path / "vitis.exe"),
            xsct=XibifPath(self.temp_path / "xsct.exe"),
            settings64_script=XibifPath(self.temp_path / "settings.bat"),
        )
        for file_name in ["vitis.exe", "xsct.exe", "settings.bat"]:
            (self.temp_path / file_name).write_text("tool", encoding="utf-8")
        self.results_folder.joinpath("demo").with_suffix(".bit").write_text("bit", encoding="utf-8")

        with self.assertRaises(XibifInvalidPathError):
            build_vitis(
                project_name="demo",
                board=XilinxBoard.ZEDBOARD,
                xilinx_version=XilinxVersion.V2024_2,
                stages=[VitisStage.bootfile],
                vitis_folder=self.vitis_folder,
                results_folder=self.results_folder,
                xilinx_path=XibifPath(self.temp_path),
            )

    @patch("xibif.api.build._build_vitis_update_launch_json", return_value=False)
    @patch("xibif.api.build.xibif_print_warning")
    @patch("xibif.api.build.get_xilinx_tool_paths")
    @patch("xibif.api.build.ShellFactory.create_shell")
    @patch("xibif.api.build.CommandSetFactory.get_command_set")
    def test_build_vitis_update_launch_warns_if_json_update_fails(self, mock_get_command_set, mock_create_shell, mock_get_tool_paths, mock_warning, _mock_update_json) -> None:
        mock_get_command_set.return_value = MagicMock()
        runtime = MagicMock()
        runtime.__enter__.return_value = runtime
        runtime.__exit__.return_value = None
        mock_create_shell.return_value = runtime
        mock_get_tool_paths.return_value = XilinxToolPath(
            vitis=XibifPath(self.temp_path / "vitis.exe"),
            xsct=XibifPath(self.temp_path / "xsct.exe"),
            settings64_script=XibifPath(self.temp_path / "settings.bat"),
        )
        for file_name in ["vitis.exe", "xsct.exe", "settings.bat"]:
            (self.temp_path / file_name).write_text("tool", encoding="utf-8")
        launch_dir = self.vitis_folder.joinpath("xibif", "_ide")
        launch_dir.mkdir(parents=True, exist_ok=True)
        launch_dir.joinpath("launch.json").write_text("{}", encoding="utf-8")

        build_vitis(
            project_name="demo",
            board=XilinxBoard.ZEDBOARD,
            xilinx_version=XilinxVersion.V2024_2,
            stages=[VitisStage.updateLaunch],
            vitis_folder=self.vitis_folder,
            results_folder=self.results_folder,
            xilinx_path=XibifPath(self.temp_path),
        )

        mock_warning.assert_called()

    @patch("xibif.api.build._build_vitis_update_launch_xml", return_value=True)
    @patch("xibif.api.build.get_xilinx_tool_paths")
    @patch("xibif.api.build.ShellFactory.create_shell")
    @patch("xibif.api.build.CommandSetFactory.get_command_set")
    def test_build_vitis_update_launch_uses_xml_for_2023(self, mock_get_command_set, mock_create_shell, mock_get_tool_paths, mock_update_xml) -> None:
        mock_get_command_set.return_value = MagicMock()
        runtime = MagicMock()
        runtime.__enter__.return_value = runtime
        runtime.__exit__.return_value = None
        mock_create_shell.return_value = runtime
        mock_get_tool_paths.return_value = XilinxToolPath(
            vitis=XibifPath(self.temp_path / "vitis.exe"),
            xsct=XibifPath(self.temp_path / "xsct.exe"),
            settings64_script=XibifPath(self.temp_path / "settings.bat"),
        )
        for file_name in ["vitis.exe", "xsct.exe", "settings.bat"]:
            (self.temp_path / file_name).write_text("tool", encoding="utf-8")
        launch_dir = self.vitis_folder.joinpath("xibif", "_ide")
        launch_dir.mkdir(parents=True, exist_ok=True)
        launch_dir.joinpath("demo.launch").write_text("<launchConfiguration/>", encoding="utf-8")

        build_vitis(
            project_name="demo",
            board=XilinxBoard.ZEDBOARD,
            xilinx_version=XilinxVersion.V2023_2,
            stages=[VitisStage.updateLaunch],
            vitis_folder=self.vitis_folder,
            results_folder=self.results_folder,
            xilinx_path=XibifPath(self.temp_path),
        )

        mock_update_xml.assert_called_once()

    @patch("xibif.api.build.get_xilinx_tool_paths")
    @patch("xibif.api.build.ShellFactory.create_shell")
    @patch("xibif.api.build.CommandSetFactory.get_command_set")
    def test_build_vitis_export_raises_if_app_not_generated(self, mock_get_command_set, mock_create_shell, mock_get_tool_paths) -> None:
        commands = MagicMock()
        commands.copy_application.return_value = "copy"
        mock_get_command_set.return_value = commands
        runtime = MagicMock()
        runtime.__enter__.return_value = runtime
        runtime.__exit__.return_value = None
        mock_create_shell.return_value = runtime
        mock_get_tool_paths.return_value = XilinxToolPath(
            vitis=XibifPath(self.temp_path / "vitis.exe"),
            xsct=XibifPath(self.temp_path / "xsct.exe"),
            settings64_script=XibifPath(self.temp_path / "settings.bat"),
        )
        for file_name in ["vitis.exe", "xsct.exe", "settings.bat"]:
            (self.temp_path / file_name).write_text("tool", encoding="utf-8")

        with self.assertRaises(XibifGeneratedFileError):
            build_vitis(
                project_name="demo",
                board=XilinxBoard.ZEDBOARD,
                xilinx_version=XilinxVersion.V2024_2,
                stages=[VitisStage.export],
                vitis_folder=self.vitis_folder,
                results_folder=self.results_folder,
                xilinx_path=XibifPath(self.temp_path),
            )

    @patch("xibif.api.build.get_xilinx_tool_paths")
    @patch("xibif.api.build.ShellFactory.create_shell")
    @patch("xibif.api.build.CommandSetFactory.get_command_set")
    def test_build_vitis_bootfile_raises_if_boot_not_generated(self, mock_get_command_set, mock_create_shell, mock_get_tool_paths) -> None:
        commands = MagicMock()
        commands.generate_bootfile.return_value = "boot"
        mock_get_command_set.return_value = commands
        runtime = MagicMock()
        runtime.__enter__.return_value = runtime
        runtime.__exit__.return_value = None
        mock_create_shell.return_value = runtime
        mock_get_tool_paths.return_value = XilinxToolPath(
            vitis=XibifPath(self.temp_path / "vitis.exe"),
            xsct=XibifPath(self.temp_path / "xsct.exe"),
            settings64_script=XibifPath(self.temp_path / "settings.bat"),
        )
        for file_name in ["vitis.exe", "xsct.exe", "settings.bat"]:
            (self.temp_path / file_name).write_text("tool", encoding="utf-8")
        self.results_folder.joinpath("demo").with_suffix(".bit").write_text("bit", encoding="utf-8")
        self.results_folder.joinpath("xibif").with_suffix(".elf").write_text("elf", encoding="utf-8")

        with self.assertRaises(XibifGeneratedFileError):
            build_vitis(
                project_name="demo",
                board=XilinxBoard.ZEDBOARD,
                xilinx_version=XilinxVersion.V2024_2,
                stages=[VitisStage.bootfile],
                vitis_folder=self.vitis_folder,
                results_folder=self.results_folder,
                xilinx_path=XibifPath(self.temp_path),
            )

    @patch("xibif.api.build.get_xilinx_tool_paths")
    @patch("xibif.api.build.ShellFactory.create_shell")
    @patch("xibif.api.build.CommandSetFactory.get_command_set")
    def test_build_vitis_build_raises_if_generated_elf_missing(self, mock_get_command_set, mock_create_shell, mock_get_tool_paths) -> None:
        commands = MagicMock()
        commands.get_elf_path.return_value = str(self.results_folder.joinpath("missing.elf"))
        mock_get_command_set.return_value = commands
        runtime = MagicMock()
        runtime.__enter__.return_value = runtime
        runtime.__exit__.return_value = None
        mock_create_shell.return_value = runtime
        mock_get_tool_paths.return_value = XilinxToolPath(
            vitis=XibifPath(self.temp_path / "vitis.exe"),
            xsct=XibifPath(self.temp_path / "xsct.exe"),
            settings64_script=XibifPath(self.temp_path / "settings.bat"),
        )
        for file_name in ["vitis.exe", "xsct.exe", "settings.bat"]:
            (self.temp_path / file_name).write_text("tool", encoding="utf-8")

        with self.assertRaises(XibifGeneratedFileError):
            build_vitis(
                project_name="demo",
                board=XilinxBoard.ZEDBOARD,
                xilinx_version=XilinxVersion.V2024_2,
                stages=[VitisStage.build],
                vitis_folder=self.vitis_folder,
                results_folder=self.results_folder,
                xilinx_path=XibifPath(self.temp_path),
            )

    @patch("xibif.api.build.get_xilinx_tool_paths")
    @patch("xibif.api.build.ShellFactory.create_shell")
    @patch("xibif.api.build.CommandSetFactory.get_command_set")
    def test_build_vivado_report_timing_runs_when_enabled(self, mock_get_command_set, mock_create_shell, mock_get_tool_paths) -> None:
        commands = MagicMock()
        commands.report_timing_run.return_value = "timing"
        mock_get_command_set.return_value = commands
        runtime = MagicMock()
        runtime.__enter__.return_value = runtime
        runtime.__exit__.return_value = None
        mock_create_shell.return_value = runtime
        mock_get_tool_paths.return_value = SimpleNamespace(vivado=XibifPath(self.temp_path / "vivado.exe"))
        (self.temp_path / "vivado.exe").write_text("tool", encoding="utf-8")
        (self.vivado_folder.joinpath("demo").with_suffix(".xpr")).write_text("project", encoding="utf-8")

        build_vivado(
            project_name="demo",
            xilinx_version=XilinxVersion.V2024_2,
            stages=[VivadoStage.reportTiming],
            vivado_folder=self.vivado_folder,
            results_folder=self.results_folder,
            disable_report=False,
            xilinx_path=XibifPath(self.temp_path),
        )

        commands.report_timing_run.assert_called_once_with(run="")
