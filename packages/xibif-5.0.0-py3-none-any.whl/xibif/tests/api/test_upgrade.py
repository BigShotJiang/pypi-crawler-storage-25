"""Tests for the upgrade API."""

# pylint: disable=missing-function-docstring,missing-class-docstring

from unittest.mock import MagicMock, patch
import unittest

from xibif.api.upgrade import upgrade
from xibif.project.models import XibifSettings
from xibif.types import XibifUUID, XilinxBoard, XilinxVersion


class UpgradeApiTests(unittest.TestCase):
    """Verify the high-level upgrade workflow."""

    @patch("xibif.api.upgrade.register.register_generate_user")
    @patch("xibif.api.upgrade.register.register_generate_stream")
    @patch("xibif.api.upgrade.misc.misc_update_vitis_header_file")
    @patch("xibif.api.upgrade.setup.setup_hdl_files")
    @patch("xibif.api.upgrade.misc.misc_create_backup")
    @patch("xibif.api.upgrade.__DEPS.resolve")
    def test_upgrade_runs_backup_copy_and_regeneration(self, mock_resolve, mock_backup, mock_setup_hdl, mock_update_header, mock_stream, mock_user) -> None:
        dependency = MagicMock()
        mock_resolve.return_value = dependency
        settings = XibifSettings()

        upgrade(board=XilinxBoard.ZEDBOARD, xilinx_version=XilinxVersion.V2024_2, uuid=XibifUUID(1), settings=settings)

        mock_backup.assert_called_once()
        mock_setup_hdl.assert_called_once()
        self.assertEqual(dependency.copy.call_count, 2)
        mock_update_header.assert_called_once_with(settings=settings)
        mock_stream.assert_called_once()
        mock_user.assert_called_once()
