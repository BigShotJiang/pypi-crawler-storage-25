"""Tests for the register API."""

# pylint: disable=missing-function-docstring,missing-class-docstring,unused-argument

from pathlib import Path
import tempfile
from types import SimpleNamespace
from unittest.mock import MagicMock, patch
import unittest

import xibif.api.register as register_api
from xibif.api.register import register_generate_custom, register_generate_stream, register_generate_user, register_generate_user_vivado, register_get_checksum
from xibif.types import XibifChecksum, XibifInvalidPathError, XibifPath, XibifRegisterError, XibifUUID, XilinxVersion


class RegisterApiTests(unittest.TestCase):
    """Verify checksum and Vivado update behavior."""

    @patch("xibif.api.register.__register_read_register_map", return_value="register-map")
    @patch("xibif.api.register.__register_resolve_reg_path", return_value=XibifPath("resolved.reg"))
    @patch("xibif.api.register.corsair.config.set_globcfg")
    @patch("xibif.api.register.__register_read_cfg", return_value={"regmap_path": "regs.yml"})
    def test_register_get_checksum_hashes_register_map(self, mock_read_cfg, mock_set_globcfg, mock_resolve_path, mock_read_map) -> None:
        temp_dir = tempfile.TemporaryDirectory()
        self.addCleanup(temp_dir.cleanup)
        base = Path(temp_dir.name)
        cfg_path = XibifPath(base / "config.yml")
        reg_path = XibifPath(base / "regs.yml")
        cfg_path.write_text("cfg")
        reg_path.write_text("regs")

        checksum = register_get_checksum(cfg_path=cfg_path, reg_path=reg_path)

        self.assertIsInstance(checksum, XibifChecksum)
        self.assertEqual(str(checksum), "4b219ca594d66a855d1e17ac06a4e7f0")

    @patch("xibif.api.register.get_xilinx_tool_paths")
    @patch("xibif.api.register.ShellFactory.create_shell")
    @patch("xibif.api.register.CommandSetFactory.get_command_set")
    def test_register_generate_user_vivado_requires_project_file(self, mock_get_command_set, mock_create_shell, mock_get_tool_paths) -> None:
        temp_dir = tempfile.TemporaryDirectory()
        self.addCleanup(temp_dir.cleanup)
        vivado_folder = XibifPath(Path(temp_dir.name) / "vivado")
        vivado_folder.mkdir(parents=True)
        mock_get_command_set.return_value = MagicMock()
        mock_create_shell.return_value = MagicMock()
        mock_get_tool_paths.return_value = SimpleNamespace(vivado=XibifPath(Path(temp_dir.name) / "vivado.exe"))
        Path(temp_dir.name, "vivado.exe").write_text("tool")

        with self.assertRaises(XibifInvalidPathError):
            register_generate_user_vivado(
                project_name="demo",
                xilinx_version=XilinxVersion.V2024_2,
                vivado_folder=vivado_folder,
                xilinx_path=XibifPath(temp_dir.name),
            )

    @patch("xibif.api.register.get_xilinx_tool_paths")
    @patch("xibif.api.register.ShellFactory.create_shell")
    @patch("xibif.api.register.CommandSetFactory.get_command_set")
    def test_register_generate_user_vivado_updates_project(self, mock_get_command_set, mock_create_shell, mock_get_tool_paths) -> None:
        temp_dir = tempfile.TemporaryDirectory()
        self.addCleanup(temp_dir.cleanup)
        vivado_folder = XibifPath(Path(temp_dir.name) / "vivado")
        vivado_folder.mkdir(parents=True)
        vivado_folder.joinpath("demo").with_suffix(".xpr").write_text("project")
        commands = MagicMock()
        mock_get_command_set.return_value = commands
        runtime = MagicMock()
        runtime.__enter__.return_value = runtime
        runtime.__exit__.return_value = None
        mock_create_shell.return_value = runtime
        mock_get_tool_paths.return_value = SimpleNamespace(vivado=XibifPath(Path(temp_dir.name) / "vivado.exe"))
        Path(temp_dir.name, "vivado.exe").write_text("tool")

        register_generate_user_vivado(
            project_name="demo",
            xilinx_version=XilinxVersion.V2024_2,
            vivado_folder=vivado_folder,
            xilinx_path=XibifPath(temp_dir.name),
        )

        commands.update_module_reference.assert_any_call(module_name="*XiBIF_REG_0*")
        commands.save_block_design.assert_called_once()

    @patch("xibif.api.register.__register_write_config")
    @patch("xibif.api.register.__register_generate")
    @patch("xibif.api.register.__register_resolve_target_paths", return_value={"vhdl": {"path": "regs.vhd", "generator": "vhdl"}})
    @patch("xibif.api.register.__register_add_user_target_to_cfg", return_value={"vhdl": {"path": "regs.vhd", "generator": "vhdl"}})
    @patch("xibif.api.register.__register_read_target_from_cfg", return_value={"vhdl": {"path": "regs.vhd", "generator": "vhdl"}})
    @patch("xibif.api.register.__register_write_register_map")
    @patch("xibif.api.register.__register_add_uuid_register", return_value="regmap")
    @patch("xibif.api.register.__register_add_version_register", return_value="regmap")
    @patch("xibif.api.register.__register_read_register_map", return_value="regmap")
    @patch("xibif.api.register.__register_resolve_reg_path", return_value=XibifPath("resolved.reg"))
    @patch("xibif.api.register.corsair.config.set_globcfg")
    @patch("xibif.api.register.__register_read_cfg", return_value={"regmap_path": "regs.yml", "config_path": "cfg.yml"})
    def test_register_generate_user_runs_generation_pipeline(
        self,
        _mock_read_cfg,
        _mock_set_globcfg,
        _mock_resolve_reg_path,
        _mock_read_register_map,
        _mock_add_version,
        _mock_add_uuid,
        mock_write_register_map,
        _mock_read_targets,
        _mock_add_user_targets,
        _mock_resolve_target_paths,
        mock_generate,
        mock_write_cfg,
    ) -> None:
        temp_dir = tempfile.TemporaryDirectory()
        self.addCleanup(temp_dir.cleanup)
        cfg_path = XibifPath(Path(temp_dir.name) / "cfg.yml")
        reg_path = XibifPath(Path(temp_dir.name) / "regs.yml")
        cfg_path.write_text("cfg", encoding="utf-8")
        reg_path.write_text("regs", encoding="utf-8")

        register_generate_user(uuid=XibifUUID(1), cfg_path=cfg_path, reg_path=reg_path)

        mock_write_register_map.assert_called_once()
        mock_generate.assert_called_once()
        mock_write_cfg.assert_called_once()

    @patch("xibif.api.register.__register_generate")
    @patch("xibif.api.register.__register_resolve_target_paths", return_value={"vhdl": {"path": "regs.vhd", "generator": "vhdl"}})
    @patch("xibif.api.register.__register_add_stream_target_to_cfg", return_value={"vhdl": {"path": "regs.vhd", "generator": "vhdl"}})
    @patch("xibif.api.register.__register_read_target_from_cfg", return_value={"vhdl": {"path": "regs.vhd", "generator": "vhdl"}})
    @patch("xibif.api.register.__register_add_uuid_register", return_value="regmap")
    @patch("xibif.api.register.__register_add_version_register", return_value="regmap")
    @patch("xibif.api.register.__register_read_register_map", return_value="regmap")
    @patch("xibif.api.register.corsair.config.set_globcfg")
    @patch("xibif.api.register.__register_read_cfg", return_value={"regmap_path": "regs.yml", "config_path": "cfg.yml"})
    @patch("xibif.api.register.__DEPS.resolve")
    def test_register_generate_stream_runs_generation_pipeline(
        self,
        mock_resolve,
        _mock_read_cfg,
        _mock_set_globcfg,
        _mock_read_register_map,
        _mock_add_version,
        _mock_add_uuid,
        _mock_read_targets,
        _mock_add_stream_targets,
        _mock_resolve_target_paths,
        mock_generate,
    ) -> None:
        mock_resolve.side_effect = [
            SimpleNamespace(as_path=XibifPath("stream_cfg.yml")),
            SimpleNamespace(as_path=XibifPath("stream_regs.yml")),
        ]

        register_generate_stream(uuid=XibifUUID(1))

        mock_generate.assert_called_once()

    @patch("xibif.api.register.__register_generate")
    @patch("xibif.api.register.__register_resolve_target_paths", return_value={"vhdl": {"path": "regs.vhd", "generator": "vhdl"}})
    @patch("xibif.api.register.__register_read_target_from_cfg", return_value={"vhdl": {"path": "regs.vhd", "generator": "vhdl"}})
    @patch("xibif.api.register.__register_read_register_map", return_value="regmap")
    @patch("xibif.api.register.__register_resolve_reg_path", return_value=XibifPath("resolved.reg"))
    @patch("xibif.api.register.corsair.config.set_globcfg")
    @patch("xibif.api.register.__register_read_cfg", return_value={"regmap_path": "regs.yml", "config_path": "cfg.yml"})
    def test_register_generate_custom_runs_generation_pipeline(
        self,
        _mock_read_cfg,
        _mock_set_globcfg,
        _mock_resolve_reg_path,
        _mock_read_register_map,
        _mock_read_targets,
        _mock_resolve_target_paths,
        mock_generate,
    ) -> None:
        temp_dir = tempfile.TemporaryDirectory()
        self.addCleanup(temp_dir.cleanup)
        cfg_path = XibifPath(Path(temp_dir.name) / "cfg.yml")
        reg_path = XibifPath(Path(temp_dir.name) / "regs.yml")
        cfg_path.write_text("cfg", encoding="utf-8")
        reg_path.write_text("regs", encoding="utf-8")

        register_generate_custom(cfg_path=cfg_path, reg_path=reg_path)

        mock_generate.assert_called_once()

    def test_register_validate_config_supports_only_32_or_64(self) -> None:
        validate_config = getattr(register_api, "__register_validate_config")
        self.assertTrue(validate_config({"data_width": 32}))
        self.assertTrue(validate_config({"data_width": 64}))
        self.assertFalse(validate_config({"data_width": 16}))

    def test_register_get_next_free_reg_address_validates_alignment(self) -> None:
        get_next_addr = getattr(register_api, "__register_get_next_free_reg_address")
        get_next_addr_raw = get_next_addr.__wrapped__
        regmap = SimpleNamespace(regs=[SimpleNamespace(address=0), SimpleNamespace(address=4)])

        with self.assertRaises(XibifRegisterError):
            get_next_addr_raw({"data_width": 32}, regmap)

        addr = get_next_addr_raw({"address_alignment": 4, "data_width": 32}, regmap)
        self.assertEqual(addr, 8)

    def test_register_find_register_idx_by_name_returns_none_if_missing(self) -> None:
        find_idx = getattr(register_api, "__register_find_register_idx_by_name")
        find_idx_raw = find_idx.__wrapped__
        regmap = SimpleNamespace(regs=[SimpleNamespace(name="a"), SimpleNamespace(name="b")])

        self.assertEqual(find_idx_raw(regmap, "b"), 1)
        self.assertIsNone(find_idx_raw(regmap, "missing"))

    def test_register_resolve_reg_path_uses_config_value(self) -> None:
        resolve_path = getattr(register_api, "__register_resolve_reg_path")
        temp_dir = tempfile.TemporaryDirectory()
        self.addCleanup(temp_dir.cleanup)
        cfg_file = XibifPath(Path(temp_dir.name) / "cfg.yml")
        reg_file = XibifPath(Path(temp_dir.name) / "regs.yml")
        cfg_file.write_text("cfg", encoding="utf-8")
        reg_file.write_text("regs", encoding="utf-8")

        resolved = resolve_path({"config_path": str(cfg_file), "regmap_path": "regs.yml"})

        self.assertEqual(resolved, reg_file)

    def test_register_write_register_map_rejects_unsupported_suffix(self) -> None:
        write_regmap = getattr(register_api, "__register_write_register_map")
        write_regmap_raw = write_regmap.__wrapped__.__wrapped__
        temp_dir = tempfile.TemporaryDirectory()
        self.addCleanup(temp_dir.cleanup)
        invalid_file = XibifPath(Path(temp_dir.name) / "regs.txt")
        invalid_file.write_text("data", encoding="utf-8")
        regmap = MagicMock()
        regmap.as_dict.return_value = {}

        with self.assertRaises(XibifRegisterError):
            write_regmap_raw(regmap=regmap, regmap_path=invalid_file)

    def test_register_generate_helper_skips_missing_or_unknown_generators(self) -> None:
        generate_raw = getattr(register_api, "__register_generate").__wrapped__

        with patch("xibif.api.register.igetattr", return_value=None):
            generate_raw(
                {
                    "a": {},
                    "b": {"generator": "Unknown", "path": "out"},
                },
                "regmap",
            )

    def test_register_generate_helper_runs_found_generator(self) -> None:
        generate_raw = getattr(register_api, "__register_generate").__wrapped__
        gen_instance = MagicMock()
        gen_class = MagicMock(return_value=gen_instance)

        with patch("xibif.api.register.igetattr", return_value=gen_class):
            generate_raw({"a": {"generator": "Known", "path": "out"}}, "regmap")

        gen_instance.generate.assert_called_once()

    def test_register_resolve_target_paths_resolves_relative_entries(self) -> None:
        resolve_targets_raw = getattr(register_api, "__register_resolve_target_paths").__wrapped__
        temp_dir = tempfile.TemporaryDirectory()
        self.addCleanup(temp_dir.cleanup)
        cfg_file = XibifPath(Path(temp_dir.name) / "cfg.yml")
        cfg_file.write_text("cfg", encoding="utf-8")
        targets = {
            "rel": {"path": "rel/out.vhd"},
            "abs": {"path": str((Path(temp_dir.name) / "abs" / "out.vhd").resolve())},
        }

        resolved = resolve_targets_raw(targets, {"config_path": str(cfg_file)})

        self.assertTrue(XibifPath(resolved["rel"]["path"]).is_absolute())
        self.assertTrue(str(resolved["abs"]["path"]).endswith("out.vhd"))

    def test_register_add_user_and_stream_targets_overwrite_required_entries(self) -> None:
        add_user_raw = getattr(register_api, "__register_add_user_target_to_cfg").__wrapped__.__wrapped__
        add_stream_raw = getattr(register_api, "__register_add_stream_target_to_cfg").__wrapped__.__wrapped__
        temp_dir = tempfile.TemporaryDirectory()
        self.addCleanup(temp_dir.cleanup)
        base = Path(temp_dir.name)
        src_folder = XibifPath(base / "src")
        tb_folder = XibifPath(base / "tb")
        vitis_folder = XibifPath(base / "vitis")
        src_folder.mkdir(parents=True, exist_ok=True)
        tb_folder.mkdir(parents=True, exist_ok=True)
        vitis_folder.mkdir(parents=True, exist_ok=True)

        targets = {}
        user_targets = add_user_raw(targets, app_name="xibif", src_folder=src_folder, vitis_folder=vitis_folder)
        stream_targets = add_stream_raw(targets, app_name="xibif", src_folder=src_folder, tb_folder=tb_folder, vitis_folder=vitis_folder)

        self.assertIn("vhdl", user_targets)
        self.assertIn("c_header", user_targets)
        self.assertIn("vhdl_package", stream_targets)

    def test_register_add_version_and_uuid_register_update_existing_registers(self) -> None:
        add_version_raw = getattr(register_api, "__register_add_version_register").__wrapped__
        add_uuid_raw = getattr(register_api, "__register_add_uuid_register").__wrapped__
        version_reg = SimpleNamespace(name="version", bitfields=[SimpleNamespace(reset=0), SimpleNamespace(reset=0), SimpleNamespace(reset=0), SimpleNamespace(reset=0)])
        uuid_reg = SimpleNamespace(name="UUID", bitfields=[SimpleNamespace(reset=0)])
        regmap = SimpleNamespace(regs=[version_reg, uuid_reg])

        with patch("xibif.api.register.__register_find_register_idx_by_name", side_effect=[0, 1]):
            add_version_raw({"data_width": 32, "address_alignment": 4}, regmap, SimpleNamespace(major=1, minor=2, patch=3, revision=4))
            add_uuid_raw({"data_width": 32, "address_alignment": 4}, regmap, XibifUUID(7))

        self.assertEqual(version_reg.bitfields[0].reset, 4)
        self.assertEqual(version_reg.bitfields[3].reset, 1)
        self.assertEqual(uuid_reg.bitfields[0].reset, 7)

    @patch("xibif.api.register.__register_validate_config", return_value=True)
    @patch("xibif.api.register.corsair.config.read_csrconfig", return_value=({"data_width": 32}, {}))
    def test_register_read_cfg_adds_config_path(self, _mock_read_cfg, _mock_validate) -> None:
        temp_dir = tempfile.TemporaryDirectory()
        self.addCleanup(temp_dir.cleanup)
        cfg_file = XibifPath(Path(temp_dir.name) / "cfg.yml")
        cfg_file.write_text("cfg", encoding="utf-8")

        cfg = getattr(register_api, "__register_read_cfg")(cfg_file)

        self.assertIn("config_path", cfg)

    @patch("xibif.api.register.__register_validate_config", return_value=False)
    @patch("xibif.api.register.corsair.config.read_csrconfig", return_value=({"data_width": 32}, {}))
    def test_register_read_cfg_raises_for_invalid_config(self, _mock_read_cfg, _mock_validate) -> None:
        temp_dir = tempfile.TemporaryDirectory()
        self.addCleanup(temp_dir.cleanup)
        cfg_file = XibifPath(Path(temp_dir.name) / "cfg.yml")
        cfg_file.write_text("cfg", encoding="utf-8")

        with self.assertRaises(XibifRegisterError):
            getattr(register_api, "__register_read_cfg")(cfg_file)

    def test_register_validate_register_map_detects_invalid_names(self) -> None:
        validate_regmap_raw = getattr(register_api, "__register_validate_register_map").__wrapped__
        valid = SimpleNamespace(as_dict=lambda: {"good": {"bitfields": [{"name": "ok", "enums": [{"name": "A"}]}]}})
        invalid = SimpleNamespace(as_dict=lambda: {"bad-name!": {"bitfields": [{"name": "ok", "enums": []}]}})

        self.assertTrue(validate_regmap_raw(valid))
        self.assertFalse(validate_regmap_raw(invalid))

    def test_register_write_config_makes_paths_relative_if_same_drive(self) -> None:
        write_cfg_raw = getattr(register_api, "__register_write_config").__wrapped__
        temp_dir = tempfile.TemporaryDirectory()
        self.addCleanup(temp_dir.cleanup)
        base = Path(temp_dir.name)
        cfg_path = XibifPath(base / "cfg.yml")
        cfg_path.write_text("cfg", encoding="utf-8")
        targets = {"t": {"path": str(base / "out" / "f.vhd")}}
        cfg = {"config_path": str(cfg_path), "regmap_path": str(base / "regs.yml")}

        with patch("xibif.api.register.corsair.config.write_csrconfig") as mock_write:
            write_cfg_raw(targets, cfg)

        args = mock_write.call_args.args
        self.assertEqual(args[0], cfg_path)
        self.assertEqual(args[1]["regmap_path"], "regs.yml")
