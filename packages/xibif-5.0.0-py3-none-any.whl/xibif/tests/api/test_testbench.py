"""Tests for the testbench API."""

# pylint: disable=missing-function-docstring,missing-class-docstring

from pathlib import Path
import tempfile
from types import SimpleNamespace
from unittest.mock import MagicMock, patch
import unittest

from xibif.api.testbench import testbench_analyze_source_file, testbench_generate
from xibif.types import XibifPath, XibifRuntimeError


class TestbenchApiTests(unittest.TestCase):
    """Verify hdltbgen integration points."""

    @patch("xibif.api.testbench.__get_hdltbgen")
    def test_testbench_generate_builds_expected_argv(self, mock_get_hdltbgen) -> None:
        hdltbgen = MagicMock()
        mock_get_hdltbgen.return_value = hdltbgen
        temp_dir = tempfile.TemporaryDirectory()
        self.addCleanup(temp_dir.cleanup)
        base = Path(temp_dir.name)
        source = XibifPath(base / "demo.vhd")
        target = XibifPath(base / "tb")
        source.write_text("entity demo is end;")
        target.mkdir()

        testbench_generate(hdl_vhdl_file=source, hdl_tb_folder=target, clock=["clk"], resetn=["rst_n"], resetp=["rst_p"])

        first_call = hdltbgen.from_argv.call_args_list[0].args[0]
        self.assertIn("-c", first_call)
        self.assertIn("clk", first_call)
        self.assertIn("-rn", first_call)
        self.assertIn("-rp", first_call)

    @patch("xibif.api.testbench.__get_hdltbgen")
    def test_testbench_analyze_source_file_returns_ports_and_generics(self, mock_get_hdltbgen) -> None:
        parsed = SimpleNamespace(
            ports=[SimpleNamespace(name="clk", direction="in"), SimpleNamespace(name="data", direction="out")],
            params=[SimpleNamespace(name="WIDTH")],
        )
        parser = MagicMock()
        parser.parse.return_value = parsed
        hdltbgen = MagicMock()
        hdltbgen.parser.vhdl.Parser_VHDL.return_value = parser
        mock_get_hdltbgen.return_value = hdltbgen
        temp_dir = tempfile.TemporaryDirectory()
        self.addCleanup(temp_dir.cleanup)
        source = XibifPath(Path(temp_dir.name) / "demo.vhd")
        source.write_text("entity demo is end;")

        info = testbench_analyze_source_file(hdl_vhdl_file=source)

        self.assertEqual(info, {"input": ["clk"], "output": ["data"], "generic": ["WIDTH"]})

    @patch("xibif.api.testbench.__get_hdltbgen")
    def test_testbench_generate_wraps_generator_errors(self, mock_get_hdltbgen) -> None:
        hdltbgen = MagicMock()
        hdltbgen.from_argv.side_effect = RuntimeError("bad vhdl")
        mock_get_hdltbgen.return_value = hdltbgen
        temp_dir = tempfile.TemporaryDirectory()
        self.addCleanup(temp_dir.cleanup)
        source = XibifPath(Path(temp_dir.name) / "demo.vhd")
        target = XibifPath(Path(temp_dir.name) / "tb")
        source.write_text("entity demo is end;")
        target.mkdir()

        with self.assertRaises(XibifRuntimeError):
            testbench_generate(hdl_vhdl_file=source, hdl_tb_folder=target)

    @patch("xibif.api.testbench.import_module", side_effect=ModuleNotFoundError("hdltbgen"))
    def test_testbench_generate_raises_when_optional_dependency_missing(self, _mock_import_module) -> None:
        temp_dir = tempfile.TemporaryDirectory()
        self.addCleanup(temp_dir.cleanup)
        source = XibifPath(Path(temp_dir.name) / "demo.vhd")
        target = XibifPath(Path(temp_dir.name) / "tb")
        source.write_text("entity demo is end;")
        target.mkdir()

        with self.assertRaises(XibifRuntimeError):
            testbench_generate(hdl_vhdl_file=source, hdl_tb_folder=target)

    @patch("xibif.api.testbench.__get_hdltbgen")
    def test_testbench_analyze_source_file_wraps_parser_errors(self, mock_get_hdltbgen) -> None:
        parser = MagicMock()
        parser.parse.side_effect = RuntimeError("parse failed")
        hdltbgen = MagicMock()
        hdltbgen.parser.vhdl.Parser_VHDL.return_value = parser
        mock_get_hdltbgen.return_value = hdltbgen
        temp_dir = tempfile.TemporaryDirectory()
        self.addCleanup(temp_dir.cleanup)
        source = XibifPath(Path(temp_dir.name) / "demo.vhd")
        source.write_text("entity demo is end;")

        with self.assertRaises(XibifRuntimeError):
            testbench_analyze_source_file(hdl_vhdl_file=source)
