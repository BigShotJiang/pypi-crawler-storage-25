"""Tests for the setup API."""

# pylint: disable=missing-function-docstring,missing-class-docstring,unused-argument

from pathlib import Path
import tempfile
from types import SimpleNamespace
from unittest.mock import MagicMock, patch
import unittest
import git

from xibif.api.setup import (
    setup_constraint_files,
    setup_demo_files,
    setup_git_files,
    setup_git_repository,
    setup_hdl_files,
    setup_openlogic_files,
    setup_openlogic_vivado,
    setup_register_files,
    setup_sigasi_project,
    setup_vitis_project,
    setup_vivado_project,
    setup_vunit_python_files,
)
from xibif.types import XibifEnvironmentError, XibifGeneratedFileError, XibifPath, XibifRuntimeError, XilinxBoard, XilinxToolPath, XilinxVersion


class SetupApiTests(unittest.TestCase):
    """Verify setup orchestration and dependency copies."""

    @patch("xibif.api.setup.__DEPS.resolve")
    def test_setup_hdl_files_copies_source_and_testbench_files(self, mock_resolve) -> None:
        copy_target = MagicMock()
        mock_resolve.return_value = copy_target

        setup_hdl_files(src_folder=XibifPath("src"), tb_folder=XibifPath("tb"))

        self.assertEqual(copy_target.copy.call_count, 2)

    @patch("xibif.api.setup.get_xilinx_tool_paths")
    @patch("xibif.api.setup.ShellFactory.create_shell")
    @patch("xibif.api.setup.CommandSetFactory.get_command_set")
    def test_setup_vivado_project_raises_when_hardware_not_generated(self, mock_get_command_set, mock_create_shell, mock_get_tool_paths) -> None:
        temp_dir = tempfile.TemporaryDirectory()
        self.addCleanup(temp_dir.cleanup)
        base = Path(temp_dir.name)
        src_folder = XibifPath(base / "src")
        constraint_folder = XibifPath(base / "constraints")
        results_folder = XibifPath(base / "results")
        vivado_folder = XibifPath(base / "vivado")
        for folder in [src_folder, constraint_folder, results_folder, vivado_folder]:
            folder.mkdir(parents=True, exist_ok=True)
        src_folder.joinpath("file.vhd").write_text("vhdl")
        constraint_folder.joinpath("file.xdc").write_text("xdc")
        mock_get_command_set.return_value = MagicMock()
        runtime = MagicMock()
        runtime.__enter__.return_value = runtime
        runtime.__exit__.return_value = None
        mock_create_shell.return_value = runtime
        mock_get_tool_paths.return_value = SimpleNamespace(vivado=XibifPath(base / "vivado.exe"))
        (base / "vivado.exe").write_text("tool")

        with self.assertRaises(XibifGeneratedFileError):
            setup_vivado_project(
                project_name="demo",
                board=XilinxBoard.ZEDBOARD,
                xilinx_version=XilinxVersion.V2024_2,
                vivado_folder=vivado_folder,
                src_folder=src_folder,
                constraint_folder=constraint_folder,
                results_folder=results_folder,
                xilinx_path=XibifPath(base),
            )

    @patch("xibif.api.setup.check_tool", return_value=None)
    def test_setup_git_repository_requires_git(self, mock_check_tool) -> None:
        with self.assertRaises(XibifEnvironmentError):
            setup_git_repository(git_folder=XibifPath("repo"))

    @patch("xibif.api.setup.git.Repo")
    @patch("xibif.api.setup.check_tool", return_value="git")
    def test_setup_git_repository_skips_if_repository_exists(self, _mock_check_tool, mock_repo) -> None:
        setup_git_repository(git_folder=XibifPath("repo"))
        mock_repo.assert_called_once()

    @patch("xibif.api.setup.git.Repo.init")
    @patch("xibif.api.setup.git.Repo", side_effect=git.InvalidGitRepositoryError)
    @patch("xibif.api.setup.check_tool", return_value="git")
    def test_setup_git_repository_initializes_repository_if_missing(self, _mock_check_tool, _mock_repo, mock_repo_init) -> None:
        repo = MagicMock()
        mock_repo_init.return_value = repo

        setup_git_repository(git_folder=XibifPath("repo"))

        mock_repo_init.assert_called_once()
        repo.git.add.assert_called_once_with(A=True)
        repo.git.commit.assert_called_once()

    @patch("xibif.api.setup.__DEPS.resolve")
    def test_setup_copy_wrappers_call_dependency_copy(self, mock_resolve) -> None:
        copy_target = MagicMock()
        mock_resolve.return_value = copy_target

        setup_vunit_python_files(vunit_folder=XibifPath("tb"))
        setup_constraint_files(board=XilinxBoard.ZEDBOARD, constraint_folder=XibifPath("constraints"))
        setup_register_files(reg_folder=XibifPath("regs"))
        setup_demo_files(demo_folder=XibifPath("sw"))
        setup_sigasi_project(project_name="demo", sigasi_folder=XibifPath("sigasi"))
        setup_git_files(git_folder=XibifPath("git"))

        self.assertGreaterEqual(copy_target.copy.call_count, 8)

    @patch("xibif.api.setup.check_tool", return_value=None)
    def test_setup_openlogic_files_requires_git(self, _mock_check_tool) -> None:
        with self.assertRaises(XibifEnvironmentError):
            setup_openlogic_files(openlogic_folder=XibifPath("openlogic"))

    @patch("xibif.api.setup.git.Repo", side_effect=git.exc.InvalidGitRepositoryError)
    @patch("xibif.api.setup.check_tool", return_value="git")
    def test_setup_openlogic_files_requires_parent_repository(self, _mock_check_tool, _mock_repo) -> None:
        with self.assertRaises(XibifRuntimeError):
            setup_openlogic_files(openlogic_folder=XibifPath("openlogic"))

    @patch("xibif.api.setup.git.Submodule.add")
    @patch("xibif.api.setup.git.Repo")
    @patch("xibif.api.setup.check_tool", return_value="git")
    def test_setup_openlogic_files_adds_submodule_if_missing(self, _mock_check_tool, mock_repo_cls, mock_submodule_add) -> None:
        repo = MagicMock()
        repo.working_tree_dir = "repo"
        repo.submodules = []
        mock_repo_cls.return_value = repo

        setup_openlogic_files(openlogic_folder=XibifPath("openlogic"))

        mock_submodule_add.assert_called_once()

    @patch("xibif.api.setup.get_xilinx_tool_paths")
    @patch("xibif.api.setup.ShellFactory.create_shell")
    @patch("xibif.api.setup.CommandSetFactory.get_command_set")
    @patch("xibif.api.setup.__DEPS.resolve")
    def test_setup_vitis_project_raises_when_fsbl_missing(self, mock_resolve, mock_get_command_set, mock_create_shell, mock_get_tool_paths) -> None:
        temp_dir = tempfile.TemporaryDirectory()
        self.addCleanup(temp_dir.cleanup)
        base = Path(temp_dir.name)
        vitis_folder = XibifPath(base / "vitis")
        results_folder = XibifPath(base / "results")
        app_name = "xibif"
        vitis_folder.joinpath(app_name, "src").mkdir(parents=True, exist_ok=True)
        vitis_folder.joinpath(app_name, "src", "temp.h").write_text("#define A 1", encoding="utf-8")
        vitis_folder.joinpath(app_name, "src", "temp.c").write_text("int a = 1;", encoding="utf-8")
        results_folder.mkdir(parents=True, exist_ok=True)

        run_shell = MagicMock()
        run_shell.__enter__.return_value = run_shell
        run_shell.__exit__.return_value = None
        mock_create_shell.return_value = run_shell
        mock_get_command_set.return_value = MagicMock()
        mock_get_tool_paths.return_value = XilinxToolPath(
            vitis=XibifPath(base / "vitis.exe"),
            xsct=XibifPath(base / "xsct.exe"),
            settings64_script=XibifPath(base / "settings.bat"),
        )
        for file_name in ["vitis.exe", "xsct.exe", "settings.bat"]:
            (base / file_name).write_text("tool", encoding="utf-8")

        def resolve_side_effect(*args, **kwargs):
            group = kwargs.get("group")
            mapping = {
                "PS_SHELL": base / "shell.ps1",
                "PS_MSS": base / "mss.mss",
                "PS_LINKER": base / "lscript.ld",
                "PS_SRC": base / "src.c",
                "PS_HEADER": base / "header.h",
            }
            # group is enum, key by attribute name
            key = group.name
            path = mapping[key]
            path.write_text("data", encoding="utf-8")
            return SimpleNamespace(as_path=XibifPath(path))

        mock_resolve.side_effect = resolve_side_effect

        with self.assertRaises(XibifGeneratedFileError):
            setup_vitis_project(
                project_name="demo",
                board=XilinxBoard.ZEDBOARD,
                xilinx_version=XilinxVersion.V2024_2,
                vitis_folder=vitis_folder,
                results_folder=results_folder,
                app_name=app_name,
                xilinx_path=XibifPath(base),
            )

    def test_setup_openlogic_vivado_requires_xilinx_path_without_runtime(self) -> None:
        temp_dir = tempfile.TemporaryDirectory()
        self.addCleanup(temp_dir.cleanup)
        base = Path(temp_dir.name)
        vivado_folder = XibifPath(base / "vivado")
        openlogic_folder = XibifPath(base / "openlogic")
        vivado_folder.mkdir(parents=True, exist_ok=True)
        openlogic_folder.mkdir(parents=True, exist_ok=True)

        with self.assertRaises(XibifEnvironmentError):
            setup_openlogic_vivado(
                project_name="demo",
                xilinx_version=XilinxVersion.V2024_2,
                vivado_folder=vivado_folder,
                openlogic_folder=openlogic_folder,
            )

    @patch("xibif.api.setup.get_xilinx_tool_paths")
    @patch("xibif.api.setup.ShellFactory.create_shell")
    @patch("xibif.api.setup.CommandSetFactory.get_command_set")
    def test_setup_openlogic_vivado_with_runtime_executes_commands(self, mock_get_command_set, mock_create_shell, mock_get_tool_paths) -> None:
        temp_dir = tempfile.TemporaryDirectory()
        self.addCleanup(temp_dir.cleanup)
        base = Path(temp_dir.name)
        vivado_folder = XibifPath(base / "vivado")
        openlogic_folder = XibifPath(base / "openlogic")
        vivado_folder.mkdir(parents=True, exist_ok=True)
        openlogic_folder.joinpath("tools", "vivado").mkdir(parents=True, exist_ok=True)
        openlogic_folder.joinpath("tools", "vivado", "import_sources.tcl").write_text("puts ok", encoding="utf-8")
        commands = MagicMock()
        mock_get_command_set.return_value = commands
        runtime = MagicMock()
        runtime.__enter__.return_value = runtime
        runtime.__exit__.return_value = None
        mock_create_shell.return_value = runtime
        vivado_exe = XibifPath(base / "vivado.exe")
        vivado_exe.write_text("tool", encoding="utf-8")
        mock_get_tool_paths.return_value = SimpleNamespace(vivado=vivado_exe)

        setup_openlogic_vivado(
            project_name="demo",
            xilinx_version=XilinxVersion.V2024_2,
            vivado_folder=vivado_folder,
            openlogic_folder=openlogic_folder,
            xilinx_path=XibifPath(base),
        )

        commands.open_project.assert_called_once()
        commands.run_file.assert_called_once()

    # Tests for dev-mode (link parameter)
    @patch("xibif.api.setup.__DEPS.resolve")
    def test_setup_hdl_files_with_dev_mode_copies_with_link_true(self, mock_resolve) -> None:
        copy_target = MagicMock()
        mock_resolve.return_value = copy_target

        setup_hdl_files(src_folder=XibifPath("src"), tb_folder=XibifPath("tb"), link=True)

        # Verify copy was called with link=True
        self.assertEqual(copy_target.copy.call_count, 2)
        for call in copy_target.copy.call_args_list:
            self.assertEqual(call.kwargs.get("link"), True)

    @patch("xibif.api.setup.__DEPS.resolve")
    def test_setup_hdl_files_without_dev_mode_copies_with_link_false(self, mock_resolve) -> None:
        copy_target = MagicMock()
        mock_resolve.return_value = copy_target

        setup_hdl_files(src_folder=XibifPath("src"), tb_folder=XibifPath("tb"), link=False)

        # Verify copy was called with link=False
        self.assertEqual(copy_target.copy.call_count, 2)
        for call in copy_target.copy.call_args_list:
            self.assertEqual(call.kwargs.get("link"), False)

    @patch("xibif.api.setup.__DEPS.resolve")
    def test_setup_vunit_python_files_with_dev_mode_uses_link(self, mock_resolve) -> None:
        copy_target = MagicMock()
        mock_resolve.return_value = copy_target

        setup_vunit_python_files(vunit_folder=XibifPath("tb"), link=True)

        copy_target.copy.assert_called_once()
        self.assertEqual(copy_target.copy.call_args.kwargs.get("link"), True)

    @patch("xibif.api.setup.__DEPS.resolve")
    def test_setup_vunit_python_files_without_dev_mode_uses_copy(self, mock_resolve) -> None:
        copy_target = MagicMock()
        mock_resolve.return_value = copy_target

        setup_vunit_python_files(vunit_folder=XibifPath("tb"), link=False)

        copy_target.copy.assert_called_once()
        self.assertEqual(copy_target.copy.call_args.kwargs.get("link"), False)

    @patch("xibif.api.setup.__DEPS.resolve")
    def test_setup_constraint_files_with_dev_mode_uses_link(self, mock_resolve) -> None:
        copy_target = MagicMock()
        mock_resolve.return_value = copy_target

        setup_constraint_files(board=XilinxBoard.ZEDBOARD, constraint_folder=XibifPath("constraints"), link=True)

        copy_target.copy.assert_called_once()
        self.assertEqual(copy_target.copy.call_args.kwargs.get("link"), True)

    @patch("xibif.api.setup.__DEPS.resolve")
    def test_setup_constraint_files_without_dev_mode_uses_copy(self, mock_resolve) -> None:
        copy_target = MagicMock()
        mock_resolve.return_value = copy_target

        setup_constraint_files(board=XilinxBoard.ZEDBOARD, constraint_folder=XibifPath("constraints"), link=False)

        copy_target.copy.assert_called_once()
        self.assertEqual(copy_target.copy.call_args.kwargs.get("link"), False)

    @patch("xibif.api.setup.__DEPS.resolve")
    def test_setup_register_files_with_dev_mode_uses_link(self, mock_resolve) -> None:
        copy_target = MagicMock()
        mock_resolve.return_value = copy_target

        setup_register_files(reg_folder=XibifPath("regs"), link=True)

        # setup_register_files calls copy() twice
        self.assertEqual(copy_target.copy.call_count, 2)
        for call in copy_target.copy.call_args_list:
            self.assertEqual(call.kwargs.get("link"), True)

    @patch("xibif.api.setup.__DEPS.resolve")
    def test_setup_register_files_without_dev_mode_uses_copy(self, mock_resolve) -> None:
        copy_target = MagicMock()
        mock_resolve.return_value = copy_target

        setup_register_files(reg_folder=XibifPath("regs"), link=False)

        # setup_register_files calls copy() twice
        self.assertEqual(copy_target.copy.call_count, 2)
        for call in copy_target.copy.call_args_list:
            self.assertEqual(call.kwargs.get("link"), False)

    @patch("xibif.api.setup.__DEPS.resolve")
    def test_setup_demo_files_with_dev_mode_uses_link(self, mock_resolve) -> None:
        copy_target = MagicMock()
        mock_resolve.return_value = copy_target

        setup_demo_files(demo_folder=XibifPath("sw"), link=True)

        copy_target.copy.assert_called_once()
        self.assertEqual(copy_target.copy.call_args.kwargs.get("link"), True)

    @patch("xibif.api.setup.__DEPS.resolve")
    def test_setup_demo_files_without_dev_mode_uses_copy(self, mock_resolve) -> None:
        copy_target = MagicMock()
        mock_resolve.return_value = copy_target

        setup_demo_files(demo_folder=XibifPath("sw"), link=False)

        copy_target.copy.assert_called_once()
        self.assertEqual(copy_target.copy.call_args.kwargs.get("link"), False)

    @patch("xibif.api.setup.__DEPS.resolve")
    def test_setup_sigasi_project_with_dev_mode_uses_link(self, mock_resolve) -> None:
        copy_target = MagicMock()
        mock_resolve.return_value = copy_target

        setup_sigasi_project(project_name="demo", sigasi_folder=XibifPath("sigasi"), link=True)

        # setup_sigasi_project calls copy() twice
        self.assertEqual(copy_target.copy.call_count, 2)
        for call in copy_target.copy.call_args_list:
            self.assertEqual(call.kwargs.get("link"), True)

    @patch("xibif.api.setup.__DEPS.resolve")
    def test_setup_sigasi_project_without_dev_mode_uses_copy(self, mock_resolve) -> None:
        copy_target = MagicMock()
        mock_resolve.return_value = copy_target

        setup_sigasi_project(project_name="demo", sigasi_folder=XibifPath("sigasi"), link=False)

        # setup_sigasi_project calls copy() twice
        self.assertEqual(copy_target.copy.call_count, 2)
        for call in copy_target.copy.call_args_list:
            self.assertEqual(call.kwargs.get("link"), False)

    @patch("xibif.api.setup.__DEPS.resolve")
    def test_setup_git_files_with_dev_mode_uses_link(self, mock_resolve) -> None:
        copy_target = MagicMock()
        mock_resolve.return_value = copy_target

        setup_git_files(git_folder=XibifPath("git"), link=True)

        copy_target.copy.assert_called_once()
        self.assertEqual(copy_target.copy.call_args.kwargs.get("link"), True)

    @patch("xibif.api.setup.__DEPS.resolve")
    def test_setup_git_files_without_dev_mode_uses_copy(self, mock_resolve) -> None:
        copy_target = MagicMock()
        mock_resolve.return_value = copy_target

        setup_git_files(git_folder=XibifPath("git"), link=False)

        copy_target.copy.assert_called_once()
        self.assertEqual(copy_target.copy.call_args.kwargs.get("link"), False)

    @patch("xibif.api.setup.get_xilinx_tool_paths")
    @patch("xibif.api.setup.ShellFactory.create_shell")
    @patch("xibif.api.setup.CommandSetFactory.get_command_set")
    @patch("xibif.api.setup.__DEPS.resolve")
    def test_setup_vitis_project_with_dev_mode_stores_link_correctly(
        self, mock_resolve, mock_get_command_set, mock_create_shell, mock_get_tool_paths
    ) -> None:
        temp_dir = tempfile.TemporaryDirectory()
        self.addCleanup(temp_dir.cleanup)
        base = Path(temp_dir.name)
        vitis_folder = XibifPath(base / "vitis")
        results_folder = XibifPath(base / "results")
        app_name = "xibif"
        vitis_folder.joinpath(app_name, "src").mkdir(parents=True, exist_ok=True)
        vitis_folder.joinpath(app_name, "src", "temp.h").write_text("#define A 1", encoding="utf-8")
        vitis_folder.joinpath(app_name, "src", "temp.c").write_text("int a = 1;", encoding="utf-8")
        results_folder.mkdir(parents=True, exist_ok=True)

        # Create a real hardware file so the test doesn't fail on that check
        hardware_file = results_folder.joinpath("design_1_wrapper.xsa")
        hardware_file.write_text("hardware", encoding="utf-8")

        # Create FSBL file to pass the check
        fsbl_file = results_folder.joinpath("fsbl.elf")
        fsbl_file.write_text("fsbl", encoding="utf-8")

        run_shell = MagicMock()
        run_shell.__enter__.return_value = run_shell
        run_shell.__exit__.return_value = None
        mock_create_shell.return_value = run_shell
        mock_get_command_set.return_value = MagicMock()
        mock_get_tool_paths.return_value = XilinxToolPath(
            vitis=XibifPath(base / "vitis.exe"),
            xsct=XibifPath(base / "xsct.exe"),
            settings64_script=XibifPath(base / "settings.bat"),
        )
        for file_name in ["vitis.exe", "xsct.exe", "settings.bat"]:
            (base / file_name).write_text("tool", encoding="utf-8")

        def resolve_side_effect(*args, **kwargs):
            group = kwargs.get("group")
            mapping = {
                "PS_SHELL": base / "shell.ps1",
                "PS_MSS": base / "mss.mss",
                "PS_LINKER": base / "lscript.ld",
                "PS_SRC": [],  # Return empty list for file lists
                "PS_HEADER": [],  # Return empty list for file lists
            }
            # group is enum, key by attribute name
            key = group.name
            path = mapping.get(key)
            if isinstance(path, list):
                return SimpleNamespace(as_path=path)
            path.write_text("data", encoding="utf-8")
            return SimpleNamespace(as_path=XibifPath(path))

        mock_resolve.side_effect = resolve_side_effect

        # Call with link=True
        setup_vitis_project(
            project_name="demo",
            board=XilinxBoard.ZEDBOARD,
            xilinx_version=XilinxVersion.V2024_2,
            vitis_folder=vitis_folder,
            results_folder=results_folder,
            app_name=app_name,
            xilinx_path=XibifPath(base),
            link=True,
        )

        # Verify the test succeeded (no exception raised)
