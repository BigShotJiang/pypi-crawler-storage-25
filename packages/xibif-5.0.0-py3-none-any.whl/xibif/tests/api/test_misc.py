"""Tests for misc API helpers."""

# pylint: disable=missing-function-docstring,missing-class-docstring

from datetime import datetime
from pathlib import Path
import tempfile
from unittest.mock import MagicMock, patch
import unittest

import xibif.api.misc as misc_api
from xibif.api.misc import misc_create_backup, misc_create_project_folder, misc_nuke_project_folder, misc_reset_project_folder, misc_update_vitis_header_file
from xibif.project.models import XibifSettings
from xibif.types import XibifPath, XibifRuntimeError


class MiscApiTests(unittest.TestCase):
    """Verify filesystem helper behavior."""

    def setUp(self) -> None:
        self.temp_dir = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp_dir.cleanup)
        self.temp_path = Path(self.temp_dir.name)

    def test_create_project_folder_creates_all_requested_directories(self) -> None:
        folders = [XibifPath(self.temp_path / name) for name in ["vivado", "vitis", "src", "tb", "regs", "constraints", "results", "sw", "sigasi", "git"]]

        misc_create_project_folder(*folders, project_folder=XibifPath(self.temp_path))

        self.assertTrue(all(folder.exists() for folder in folders))

    @patch("xibif.api.misc.datetime")
    def test_create_backup_raises_when_timestamp_folder_exists(self, mock_datetime) -> None:
        backup_root = XibifPath(self.temp_path / "backup")
        backup_root.mkdir()
        mock_datetime.now.return_value = datetime(2026, 3, 27, 12, 0, 0)
        backup_root.joinpath("2026-03-27_12-00-00").mkdir()

        with self.assertRaises(XibifRuntimeError):
            misc_create_backup(backup_folder=backup_root)

    @patch("xibif.api.misc.shutil.copytree")
    @patch("xibif.api.misc.datetime")
    def test_create_backup_returns_timestamp_folder(self, mock_datetime, mock_copytree) -> None:
        backup_root = XibifPath(self.temp_path / "backup")
        backup_root.mkdir()
        mock_datetime.now.return_value = datetime(2026, 3, 27, 12, 0, 0)

        backup = misc_create_backup(backup_folder=backup_root)

        self.assertTrue(str(backup).endswith("2026-03-27_12-00-00"))
        mock_copytree.assert_called_once()

    @patch("xibif.api.misc.__misc_remove_folder")
    def test_misc_nuke_project_folder_calls_remove(self, mock_remove) -> None:
        misc_nuke_project_folder(project_folder=XibifPath(self.temp_path))
        mock_remove.assert_called_once()

    @patch("xibif.api.misc.misc_create_backup", return_value=XibifPath("backup/path"))
    @patch("xibif.api.misc.__misc_remove_folder")
    def test_misc_reset_project_folder_keeps_project_root(self, mock_remove, _mock_backup) -> None:
        project = XibifPath(self.temp_path)
        same = project
        other = XibifPath(self.temp_path / "other")

        misc_reset_project_folder(
            project_folder=project,
            vivado_folder=same,
            vitis_folder=other,
            src_folder=other,
            tb_folder=other,
            reg_folder=other,
            constraint_folder=other,
            results_folder=other,
            demo_folder=other,
            sigasi_folder=other,
            git_folder=other,
        )

        self.assertGreaterEqual(mock_remove.call_count, 1)

    def test_misc_remove_folder_helper_removes_existing_folder(self) -> None:
        folder = XibifPath(self.temp_path / "to_remove")
        folder.joinpath("sub").mkdir(parents=True, exist_ok=True)
        folder.joinpath("sub", "file.txt").write_text("data", encoding="utf-8")

        getattr(misc_api, "__misc_remove_folder")(folder)

        self.assertFalse(folder.exists())

    def test_misc_remove_folder_recursive_removes_tree(self) -> None:
        folder = XibifPath(self.temp_path / "to_remove_recursive")
        folder.joinpath("a", "b").mkdir(parents=True, exist_ok=True)
        folder.joinpath("a", "b", "f.txt").write_text("data", encoding="utf-8")

        getattr(misc_api, "__misc_remove_folder_recursive")(folder)

        self.assertFalse(folder.exists())

    @patch("xibif.api.misc.__DEPS.resolve")
    def test_update_vitis_header_file_renders_template_output(self, mock_resolve) -> None:
        template_dir = self.temp_path / "templates"
        template_dir.mkdir()
        template_path = template_dir / "settings.h.j2"
        template_path.write_text("IP={{ ip_00 }}.{{ ip_01 }}.{{ ip_02 }}.{{ ip_03 }}")
        mock_resolve.return_value = MagicMock(as_path=XibifPath(template_path))
        vitis_folder = XibifPath(self.temp_path / "vitis")
        vitis_folder.joinpath("app", "src").mkdir(parents=True)

        misc_update_vitis_header_file(settings=XibifSettings(), app_name="app", vitis_folder=vitis_folder)

        rendered = vitis_folder.joinpath("app", "src", "XiBIF_settings.h").read_text(encoding="utf-8")
        self.assertIn("IP=192.168.1.10", rendered)
