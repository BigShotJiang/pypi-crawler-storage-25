"""Tests for xibif.api."""
