"""Tests for build stage helpers."""

# pylint: disable=missing-function-docstring,missing-class-docstring

import unittest
from enum import IntEnum
import xibif.api

from xibif.api import build_stages
from xibif.api.build_stages import VitisStage, VivadoStage, get_stage_choices, get_stages, get_stages_between, parse_stage
from xibif.types import XibifValidationError


class BuildStagesTests(unittest.TestCase):
    """Validate build stage parsing and grouping."""

    def test_stage_choices_do_not_include_all(self) -> None:
        choices = get_stage_choices()

        self.assertIn("vivado:synthesize", choices)
        self.assertIn("vitis:update", choices)
        self.assertNotIn("vivado:all", choices)
        self.assertNotIn("vitis:all", choices)

    def test_parse_stage_returns_expected_enum(self) -> None:
        self.assertEqual(parse_stage("vivado:bitstream"), VivadoStage.bitstream)
        self.assertEqual(parse_stage("vitis:build"), VitisStage.build)

    def test_parse_stage_rejects_invalid_prefix(self) -> None:
        with self.assertRaises(XibifValidationError):
            parse_stage("python:run")

    def test_parse_stage_requires_prefix_separator(self) -> None:
        with self.assertRaises(XibifValidationError):
            parse_stage("vivado")

    def test_parse_stage_rejects_unknown_stage_name(self) -> None:
        with self.assertRaises(XibifValidationError):
            parse_stage("vivado:does_not_exist")
        with self.assertRaises(XibifValidationError):
            parse_stage("vitis:does_not_exist")

    def test_get_stages_between_splits_ranges_by_family(self) -> None:
        vivado_stages, vitis_stages = get_stages_between(VivadoStage.synthesize, VitisStage.export)

        self.assertEqual(vivado_stages, [VivadoStage.synthesize, VivadoStage.implement, VivadoStage.bitstream, VivadoStage.export, VivadoStage.reportTiming])
        self.assertEqual(vitis_stages, [VitisStage.update, VitisStage.build, VitisStage.export])

    def test_get_stages_groups_stage_list(self) -> None:
        vivado_stages, vitis_stages = get_stages([VivadoStage.synthesize, VitisStage.bootfile])

        self.assertEqual(vivado_stages, [VivadoStage.synthesize])
        self.assertEqual(vitis_stages, [VitisStage.bootfile])

    def test_get_stages_between_defaults_include_all_non_all_stages(self) -> None:
        vivado_stages, vitis_stages = get_stages_between()

        self.assertEqual(vivado_stages, [VivadoStage.blockdesign, VivadoStage.synthesize, VivadoStage.implement, VivadoStage.bitstream, VivadoStage.export, VivadoStage.reportTiming])
        self.assertEqual(vitis_stages, [VitisStage.update, VitisStage.build, VitisStage.export, VitisStage.bootfile, VitisStage.updateLaunch])

    def test_get_stages_raises_for_invalid_internal_stage(self) -> None:
        with self.assertRaises(XibifValidationError):
            get_stages.__wrapped__(["invalid_stage"])

    def test_api_lazy_getattr_loads_modules_and_rejects_unknown(self) -> None:
        module = xibif.api.__getattr__("build")

        self.assertEqual(module.__name__, "xibif.api.build")
        self.assertIs(xibif.api.build, module)

        with self.assertRaises(AttributeError):
            xibif.api.__getattr__("not_existing")

    def test_validated_stage_enum_meta_rejects_duplicate_values(self) -> None:
        with self.assertRaises(XibifValidationError):
            namespace = build_stages.ValidatedStageEnumMeta.__prepare__("DuplicateStage", (IntEnum,))
            namespace["__module__"] = __name__
            namespace["duplicate"] = VivadoStage.synthesize.value
            build_stages.ValidatedStageEnumMeta("DuplicateStage", (IntEnum,), namespace)
