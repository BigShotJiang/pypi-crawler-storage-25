"""Tests for the simulation API."""

# pylint: disable=missing-function-docstring,missing-class-docstring,unused-argument

from pathlib import Path
import tempfile
from unittest.mock import MagicMock, patch
import unittest

from xibif.api.simulate import simulation_clean_up_xml, simulation_compile, simulation_list_testbenches, simulation_run
from xibif.types import XibifPath, XibifRuntimeError, VunitSimulator


class SimulateApiTests(unittest.TestCase):
    """Verify simulation helpers and command orchestration."""

    def test_simulation_clean_up_xml_removes_blank_classname_cases(self) -> None:
        temp_dir = tempfile.TemporaryDirectory()
        self.addCleanup(temp_dir.cleanup)
        junit_file = XibifPath(Path(temp_dir.name) / "test.xml")
        junit_file.write_text("<testsuite><testcase classname=''/><testcase classname='ok'/></testsuite>")

        simulation_clean_up_xml(junit_file=junit_file)

        content = junit_file.read_text()
        self.assertNotIn("classname=''", content)
        self.assertIn('classname="ok"', content)

    @patch("xibif.api.simulate.__get_vunit")
    @patch("xibif.api.simulate.CommandSetFactory.get_command_set")
    @patch("xibif.api.simulate.ShellFactory.create_shell")
    def test_simulation_list_testbenches_runs_python_commands(self, mock_create_shell, mock_get_command_set, mock_get_vunit) -> None:
        commands = MagicMock()
        commands.add_env_var.return_value = "env"
        commands.change_directory.return_value = "cd"
        commands.add_argv.return_value = "argv"
        commands.run_file.return_value = "run"
        mock_get_command_set.return_value = commands
        shell = MagicMock()
        shell.__enter__.return_value = shell
        shell.__exit__.return_value = None
        mock_create_shell.return_value = shell
        temp_dir = tempfile.TemporaryDirectory()
        self.addCleanup(temp_dir.cleanup)
        run_file = XibifPath(Path(temp_dir.name) / "run.py")
        run_file.write_text("print('run')")

        simulation_list_testbenches(run_file=run_file, simulator=VunitSimulator.GHDL)

        commands.add_env_var.assert_called_once_with(name="VUNIT_SIMULATOR", value="ghdl")
        commands.run_file.assert_called_once_with(file=run_file)

    @patch("xibif.api.simulate.__get_vunit")
    @patch("xibif.api.simulate.CommandSetFactory.get_command_set")
    @patch("xibif.api.simulate.ShellFactory.create_shell")
    def test_simulation_run_returns_false_when_junit_contains_failure(self, mock_create_shell, mock_get_command_set, mock_get_vunit) -> None:
        commands = MagicMock()
        commands.add_env_var.return_value = "env"
        commands.change_directory.return_value = "cd"
        commands.add_argv.return_value = "argv"
        commands.run_file.return_value = "run"
        mock_get_command_set.return_value = commands
        shell = MagicMock()
        shell.__enter__.return_value = shell
        shell.__exit__.return_value = None
        mock_create_shell.return_value = shell
        temp_dir = tempfile.TemporaryDirectory()
        self.addCleanup(temp_dir.cleanup)
        base = Path(temp_dir.name)
        run_file = XibifPath(base / "run.py")
        junit_file = XibifPath(base / "result.xml")
        run_file.write_text("print('run')")
        junit_file.write_text("<testsuite><testcase classname='tb'><failure/></testcase></testsuite>")

        result = simulation_run(run_file=run_file, junit_file=junit_file)

        self.assertFalse(result)

    @patch("xibif.api.simulate.__get_vunit", side_effect=XibifRuntimeError("missing"))
    def test_simulation_run_propagates_runtime_error_when_vunit_missing(self, mock_get_vunit) -> None:
        with self.assertRaises(XibifRuntimeError):
            simulation_run(run_file=XibifPath("run.py"))

    @patch("xibif.api.simulate.__get_vunit")
    @patch("xibif.api.simulate.CommandSetFactory.get_command_set")
    @patch("xibif.api.simulate.ShellFactory.create_shell")
    def test_simulation_run_passes_testbench_and_gui_args_and_returns_true_without_junit(self, mock_create_shell, mock_get_command_set, _mock_get_vunit) -> None:
        commands = MagicMock()
        commands.add_env_var.return_value = "env"
        commands.change_directory.return_value = "cd"
        commands.add_argv.return_value = "argv"
        commands.run_file.return_value = "run"
        mock_get_command_set.return_value = commands
        shell = MagicMock()
        shell.__enter__.return_value = shell
        shell.__exit__.return_value = None
        mock_create_shell.return_value = shell
        temp_dir = tempfile.TemporaryDirectory()
        self.addCleanup(temp_dir.cleanup)
        base = Path(temp_dir.name)
        run_file = XibifPath(base / "run.py")
        junit_file = XibifPath(base / "missing.xml")
        run_file.write_text("print('run')", encoding="utf-8")

        result = simulation_run(testbench=["tb_a", "tb_b"], gui=True, run_file=run_file, junit_file=junit_file)

        self.assertTrue(result)
        commands.add_argv.assert_any_call(argv="tb_a")
        commands.add_argv.assert_any_call(argv="tb_b")
        commands.add_argv.assert_any_call(argv=["-g"])

    @patch("xibif.api.simulate.__get_vunit")
    @patch("xibif.api.simulate.CommandSetFactory.get_command_set")
    @patch("xibif.api.simulate.ShellFactory.create_shell")
    def test_simulation_run_returns_true_when_junit_contains_no_failures(self, mock_create_shell, mock_get_command_set, _mock_get_vunit) -> None:
        commands = MagicMock()
        commands.add_env_var.return_value = "env"
        commands.change_directory.return_value = "cd"
        commands.add_argv.return_value = "argv"
        commands.run_file.return_value = "run"
        mock_get_command_set.return_value = commands
        shell = MagicMock()
        shell.__enter__.return_value = shell
        shell.__exit__.return_value = None
        mock_create_shell.return_value = shell
        temp_dir = tempfile.TemporaryDirectory()
        self.addCleanup(temp_dir.cleanup)
        base = Path(temp_dir.name)
        run_file = XibifPath(base / "run.py")
        junit_file = XibifPath(base / "result.xml")
        run_file.write_text("print('run')", encoding="utf-8")
        junit_file.write_text("<testsuite><testcase classname='tb'/></testsuite>", encoding="utf-8")

        result = simulation_run(run_file=run_file, junit_file=junit_file)

        self.assertTrue(result)

    @patch("xibif.api.simulate.__get_vunit")
    def test_simulation_run_raises_if_run_file_missing(self, _mock_get_vunit) -> None:
        with self.assertRaises(XibifRuntimeError):
            simulation_run(run_file=XibifPath("missing_run.py"))

    @patch("xibif.api.simulate.__get_vunit")
    @patch("xibif.api.simulate.__DEPS.resolve")
    @patch("xibif.api.simulate.CommandSetFactory.get_command_set")
    @patch("xibif.api.simulate.ShellFactory.create_shell")
    @patch("xibif.api.simulate.shutil.move")
    @patch("xibif.api.simulate.shutil.rmtree")
    def test_simulation_compile_runs_compile_flow(self, _mock_rmtree, mock_move, mock_create_shell, mock_get_command_set, mock_resolve, _mock_get_vunit) -> None:
        commands = MagicMock()
        commands.add_env_var.return_value = "env"
        commands.change_directory.return_value = "cd"
        commands.add_argv.return_value = "argv"
        commands.run_file.return_value = "run"
        mock_get_command_set.return_value = commands
        shell = MagicMock()
        shell.__enter__.return_value = shell
        shell.__exit__.return_value = None
        mock_create_shell.return_value = shell
        temp_dir = tempfile.TemporaryDirectory()
        self.addCleanup(temp_dir.cleanup)
        run_file = XibifPath(Path(temp_dir.name) / "run_compile.py")
        run_file.write_text("print('compile')")
        mock_resolve.return_value = MagicMock(as_path=run_file)

        simulation_compile(library_folder=XibifPath(Path(temp_dir.name) / "libs"), simulator=VunitSimulator.MODELSIM)

        commands.add_argv.assert_called_once()
        mock_move.assert_called_once()

    @patch("xibif.api.simulate.__get_vunit")
    @patch("xibif.api.simulate.__DEPS.resolve")
    @patch("xibif.api.simulate.CommandSetFactory.get_command_set")
    @patch("xibif.api.simulate.ShellFactory.create_shell")
    @patch("xibif.api.simulate.shutil.move")
    @patch("xibif.api.simulate.shutil.rmtree")
    def test_simulation_compile_removes_existing_library_folder(self, mock_rmtree, mock_move, mock_create_shell, mock_get_command_set, mock_resolve, _mock_get_vunit) -> None:
        commands = MagicMock()
        commands.add_env_var.return_value = "env"
        commands.change_directory.return_value = "cd"
        commands.add_argv.return_value = "argv"
        commands.run_file.return_value = "run"
        mock_get_command_set.return_value = commands
        shell = MagicMock()
        shell.__enter__.return_value = shell
        shell.__exit__.return_value = None
        mock_create_shell.return_value = shell
        temp_dir = tempfile.TemporaryDirectory()
        self.addCleanup(temp_dir.cleanup)
        base = Path(temp_dir.name)
        run_file = XibifPath(base / "run_compile.py")
        run_file.write_text("print('compile')", encoding="utf-8")
        mock_resolve.return_value = MagicMock(as_path=run_file)
        library_folder = XibifPath(base / "libs")
        library_folder.mkdir(parents=True, exist_ok=True)

        simulation_compile(library_folder=library_folder, simulator=VunitSimulator.MODELSIM)

        self.assertGreaterEqual(mock_rmtree.call_count, 1)
        mock_rmtree.assert_any_call(library_folder)
        mock_move.assert_called_once()

    @patch("xibif.api.simulate.import_module", side_effect=ModuleNotFoundError("vunit"))
    def test_simulation_list_testbenches_raises_if_vunit_missing(self, _mock_import_module) -> None:
        temp_dir = tempfile.TemporaryDirectory()
        self.addCleanup(temp_dir.cleanup)
        run_file = XibifPath(Path(temp_dir.name) / "run.py")
        run_file.write_text("print('run')", encoding="utf-8")

        with self.assertRaises(XibifRuntimeError):
            simulation_list_testbenches(run_file=run_file)
