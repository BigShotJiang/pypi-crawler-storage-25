"""Models for the logger."""

from enum import StrEnum


class LoggerVerbosity(StrEnum):
    """Enum for logger verbosity levels."""

    DEBUG = "debug"
    INFO = "info"
    WARNING = "warning"
    ERROR = "error"
    NONE = "none"
