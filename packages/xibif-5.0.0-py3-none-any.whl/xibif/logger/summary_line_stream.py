"""SummaryLineStream is a custom stream for loguru that displays a summary line with the current stage, elapsed time, and counts of warnings and errors. It also handles printing individual log messages and can be configured to only show the summary line. The class uses a timer to update the summary line every second and stores all errors and warnings with their metadata to print a detailed summary at the end of the program execution."""

import time
import threading
from collections import Counter
import sys
import atexit
import loguru
from colorama import Fore, Style
from pydantic import ConfigDict, validate_call
from .logger_stages import LoggerStage as LS
from .unbuffered_stream import UnbufferedStream


class SummaryLineStream:
    """A custom stream for loguru that displays a summary line with the current stage, elapsed time, and counts of warnings and errors. It also handles printing individual log messages and can be configured to only show the summary line."""

    __CLEAR_LINE: str = "\033[2K\r"
    __counter: Counter | None = None
    __stage: LS = LS.STARTUP
    __start_time: float = 0
    __summary_only: bool = False
    __errors_and_warnings: list[dict] = []
    __timer: threading.Timer | None = None
    __timer_lock: threading.Lock = threading.Lock()

    @validate_call(config=ConfigDict(strict=True))
    def __init__(self, initial_stage: LS = LS.STARTUP, summary_only: bool = False) -> None:
        """Initialize the SummaryLineStream with an optional initial stage and summary-only mode.

        Args:
            initial_stage (LS): The initial stage to set for the logger. Defaults to LS.STARTUP.
            summary_only (bool): If True, only the summary line will be printed, and individual log messages will be suppressed. Defaults to False.
        """
        self.__counter = Counter()
        self.__stage = initial_stage
        self.__start_time = time.perf_counter()
        self.__summary_only = summary_only
        self.__errors_and_warnings = []  # List to store all errors and warnings with metadata
        self.__timer = threading.Timer(1.0, self.__display_summary)
        self.__timer.daemon = True
        self.__timer_lock = threading.Lock()
        self.__timer_started = False
        sys.stdout = UnbufferedStream(sys.stdout)

        # Register the print_errors_and_warnings function to be called at program exit
        atexit.register(self.__print_errors_and_warnings)

    @validate_call(config=ConfigDict(strict=True))
    def __del__(self) -> None:
        """Ensure that the timer is stopped when the object is deleted."""
        self.stop()

    @validate_call(config=ConfigDict(strict=True, arbitrary_types_allowed=True))
    def write(self, message: loguru._handler.Message) -> None:
        """Write a message to the stream, updating the summary line and handling errors/warnings as needed.

        Args:
            message (loguru._handler.Message): The loguru message object containing the log record and
            additional metadata.
        """
        # Reset the timer for the next summary update
        self.__reset_timer()

        # Get the payload from the loguru message
        record = message.record

        # Check if force print is requested
        force_print = record["extra"].get("force_print", False)

        # Update the current stage if provided
        if record["extra"].get("stage", LS.NO_CHANGE) != LS.NO_CHANGE:
            self.__stage = LS(record["extra"]["stage"])

        # Only do this when not force printing
        if not force_print:
            # Update counters based on log level
            self.__counter[record["level"].name] += 1
            self.__counter["STEPS"] += 1

            # Store errors and warnings with metadata
            if record["level"].name in ["ERROR", "WARNING"]:
                self.__errors_and_warnings.append({"level": record["level"].name, "stage": self.__stage.value, "message": record["message"], "elapsed_time": record["elapsed"]})

        # Print the message and summary
        if not self.__summary_only or force_print:
            self.__display_message(message=record["message"], color=record["extra"].get("color", ""), prefix=record["extra"].get("prefix", "XIBIF"))
        if not force_print:
            self.__display_summary()

    @validate_call(config=ConfigDict(strict=True))
    def __reset_timer(self) -> None:
        """Reset the timer for the next summary update."""
        with self.__timer_lock:
            self.__timer.cancel()
            self.__timer = threading.Timer(1.0, self.__display_summary)
            self.__timer.daemon = True
            if self.__timer_started:
                self.__timer.start()

    @validate_call(config=ConfigDict(strict=True))
    def flush(self) -> None:
        """Flush the stream."""
        sys.stdout.flush()

    @validate_call(config=ConfigDict(strict=True))
    def __display_message(self, message: str, color: str, prefix: str) -> None:
        """Check if the message is multiline and print it with the appropriate formatting.

        Args:
            message (str): The log message to be printed.
            color (str): The color code to be applied to the message.
            prefix (str): The prefix to be displayed before the message.
        """
        # Check if the message is multiline
        lines = message.splitlines()
        for line in lines:
            print(f"{self.__CLEAR_LINE}{color}[{prefix:^12}]{Style.RESET_ALL}\t{line}", flush=True)

    @validate_call(config=ConfigDict(strict=True))
    def __display_summary(self) -> None:
        """Calculate elapsed time, format the summary line with the current stage and counters, and print it."""
        elapsed = time.perf_counter() - self.__start_time
        mins, secs = divmod(int(elapsed), 60)
        timer_str = f"{mins:02d}:{secs:02d}"
        summary = f"{Fore.MAGENTA}[  SUMMARY   ]{Style.RESET_ALL}\t{timer_str} | {self.__stage.value} | Warnings: {self.__counter['WARNING']} | Errors: {self.__counter['ERROR']} | Steps: {self.__counter['STEPS']} "
        print(self.__CLEAR_LINE + summary, end="", flush=True)

        # Start timer again
        self.__reset_timer()

    @validate_call(config=ConfigDict(strict=True))
    def __print_errors_and_warnings(self) -> None:
        """Print a summary of all errors and warnings that were logged during the execution of the program, along with their stages and elapsed times."""
        # Set stage to finished
        self.__stage = LS.FINISHED

        # Print summary before errors and warnings
        if self.__counter["STEPS"] > 0:
            self.__display_summary()

        if not self.__errors_and_warnings:
            return

        # Find the longest names for formatting
        max_stage_length = max(len(entry["stage"]) for entry in self.__errors_and_warnings)
        max_message_length = max(len(line) for entry in self.__errors_and_warnings for line in entry["message"].splitlines())
        total_length = max_stage_length + max_message_length + 26

        # Print header
        print(f"\n{Fore.CYAN}{'='*total_length}")
        print(f"{'Error and Warning Summary':^{total_length}}")
        print(f"{'='*total_length}{Style.RESET_ALL}")

        for entry in self.__errors_and_warnings:
            # Format elapsed time
            elapsed_total_seconds = int(entry["elapsed_time"].total_seconds())
            elapsed_mins, elapsed_secs = divmod(elapsed_total_seconds, 60)
            elapsed_str = f"{elapsed_mins:02d}:{elapsed_secs:02d}"

            # Choose color based on level
            color = Fore.RED if entry["level"] == "ERROR" else Fore.YELLOW

            lines = entry["message"].splitlines()
            for line in lines:
                print(f"{color}[{entry['level']:^12}]{Style.RESET_ALL} | " f"{elapsed_str} | " f"{entry['stage']:{max_stage_length}} | " f"{line}")

        print(f"{Fore.CYAN}{'='*total_length}{Style.RESET_ALL}")

    @validate_call(config=ConfigDict(strict=True))
    def stop(self) -> None:
        """Stop the timer and cleanup."""
        self.__timer_started = False
        with self.__timer_lock:
            self.__timer.cancel()

    @validate_call(config=ConfigDict(strict=True))
    def start(self) -> None:
        """Start the timer mechanism."""
        self.__timer_started = True
        self.__reset_timer()

    @property
    @validate_call(config=ConfigDict(strict=True))
    def summary_only(self) -> bool:
        """Get the current value of the summary_only property.

        Returns:
            bool: The current value of summary_only, indicating whether only the summary line will be printed.
        """
        return self.__summary_only

    @summary_only.setter
    @validate_call(config=ConfigDict(strict=True))
    def summary_only(self, value: bool) -> None:
        """Set the value of the summary_only property.

        Args:
            value (bool): The new value for summary_only, indicating whether only the summary line should be printed.
        """
        self.__summary_only = value
