"""Utility functions for the XiBIF logger."""

import tempfile
import getpass
from loguru import logger
from colorama import Fore, just_fix_windows_console
from pydantic import ConfigDict, validate_call
from .logger_stages import LoggerStage as LS
from .models import LoggerVerbosity
from .summary_line_stream import SummaryLineStream
from ..types.utils import XibifPath

__summary_stream = SummaryLineStream(LS.STARTUP)


@validate_call(config=ConfigDict(strict=True))
def setup_logger(verbosity: LoggerVerbosity = LoggerVerbosity.INFO, summary: bool = False) -> None:
    """Setup the logger for the XiBIF package.

    Args:
        verbosity (LoggerVerbosity): The verbosity level for the logger (DEBUG, INFO, WARNING, ERROR, NONE). Defaults to LoggerVerbosity.INFO.
        summary (bool): If True, only the summary line will be printed, and individual log messages will be suppressed. Defaults to False.
    """
    # Initialize colorama for Windows compatibility and remove any existing loguru handlers
    just_fix_windows_console()
    logger.remove()

    # Add a file handler that writes logs to a file in the user's temp folder, with daily rotation and weekly retention
    logger.add(
        get_user_temp_folder().as_posix() + "/xibif_{time:YYYY-MM-DD}.log",
        rotation="1 day",
        retention="1 week",
        level="DEBUG",
        format="{time:YYYY-MM-DD HH:mm:ss.SSS} | {level} | {extra[prefix]} | {message}",
    )

    # Add the summary stream handler if verbosity is not NONE
    if verbosity != LoggerVerbosity.NONE:
        __summary_stream.summary_only = summary
        logger.add(__summary_stream, level=verbosity.upper(), format="{message}", colorize=False)


@validate_call(config=ConfigDict(strict=True))
def start_periodic_logger() -> None:
    """
    Start the periodic logger refresh.
    """
    __summary_stream.start()


@validate_call(config=ConfigDict(strict=True))
def stop_periodic_logger() -> None:
    """
    Stop the periodic logger refresh.
    """
    __summary_stream.stop()


@validate_call(config=ConfigDict(strict=True))
def xibif_print_debug(text: str, prefix: str = "XIBIF", stage: LS = LS.NO_CHANGE) -> None:
    """Print a debug message using the logger.

    Args:
        text (str): The message to print.
        prefix (str): The prefix to use for the log message. Defaults to "XIBIF".
        stage (LS): The logger stage to associate with the message. Defaults to LS.NO_CHANGE.
    """
    xibif_print(text=text, verbosity=LoggerVerbosity.DEBUG, prefix=prefix, stage=stage, color=Fore.BLUE)


@validate_call(config=ConfigDict(strict=True))
def xibif_print_info(text: str, prefix: str = "XIBIF", stage: LS = LS.NO_CHANGE) -> None:
    """Print an info message using the logger.

    Args:
        text (str): The message to print.
        prefix (str): The prefix to use for the log message. Defaults to "XIBIF".
        stage (LS): The logger stage to associate with the message. Defaults to LS.NO_CHANGE.
    """
    xibif_print(text=text, verbosity=LoggerVerbosity.INFO, prefix=prefix, stage=stage, color=Fore.BLUE)


@validate_call(config=ConfigDict(strict=True))
def xibif_print_warning(text: str, prefix: str = "XIBIF", stage: LS = LS.NO_CHANGE) -> None:
    """Print a warning message using the logger.

    Args:
        text (str): The message to print.
        prefix (str): The prefix to use for the log message. Defaults to "XIBIF".
        stage (LS): The logger stage to associate with the message. Defaults to LS.NO_CHANGE.
    """
    xibif_print(text=text, verbosity=LoggerVerbosity.WARNING, prefix=prefix, stage=stage, color=Fore.YELLOW)


@validate_call(config=ConfigDict(strict=True))
def xibif_print_error(text: str, prefix: str = "XIBIF", stage: LS = LS.NO_CHANGE) -> None:
    """Print an error message using the logger.

    Args:
        text (str): The message to print.
        prefix (str): The prefix to use for the log message. Defaults to "XIBIF".
        stage (LS): The logger stage to associate with the message. Defaults to LS.NO_CHANGE.
    """
    xibif_print(text=text, verbosity=LoggerVerbosity.ERROR, prefix=prefix, stage=stage, color=Fore.RED)


@validate_call(config=ConfigDict(strict=True))
def xibif_print(text: str, verbosity: LoggerVerbosity, prefix: str = "XIBIF", stage: LS = LS.NO_CHANGE, color: str = Fore.BLUE, force_print: bool = False) -> None:
    """Print a message using the logger.

    Args:
        text (str): The message to print.
        verbosity (LoggerVerbosity): The verbosity level for the message (DEBUG, INFO, WARNING, ERROR).
        prefix (str): The prefix to use for the log message. Defaults to "XIBIF".
        stage (LS): The logger stage to associate with the message. Defaults to LS.NO_CHANGE.
        color (str): The color to use for the log message. Defaults to Fore.BLUE.
        force_print (bool): If True, the message will be printed even if the summary_only mode is enabled. Defaults to False.
    """
    if __is_text(text):
        if verbosity == LoggerVerbosity.DEBUG:
            logger.bind(prefix=prefix, color=color, stage=stage, force_print=force_print).debug(text.strip())
        elif verbosity == LoggerVerbosity.INFO:
            logger.bind(prefix=prefix, color=color, stage=stage, force_print=force_print).info(text.strip())
        elif verbosity == LoggerVerbosity.WARNING:
            logger.bind(prefix=prefix, color=color, stage=stage, force_print=force_print).warning(text.strip())
        elif verbosity == LoggerVerbosity.ERROR:
            logger.bind(prefix=prefix, color=color, stage=stage, force_print=force_print).error(text.strip())


@validate_call(config=ConfigDict(strict=True))
def __is_text(text: str) -> bool:
    """Check if the given text is non-empty and not just a newline.

    Args:
        text (str): The text to check.

    Returns:
        bool: True if the text is non-empty and not just a newline, False otherwise.
    """
    return text not in {"", "\n"}


def get_user_temp_folder() -> XibifPath:
    """
    Get the user's temporary folder.

    Returns:
        XibifPath: The user's temporary folder.
    """
    return XibifPath(tempfile.gettempdir()).joinpath(getpass.getuser(), "xibif")
