"""A module that defines the UnbufferedStream class, which is a wrapper around a stream to make it unbuffered."""

from io import TextIOBase
from typing import Any
from pydantic import ConfigDict, validate_call


class UnbufferedStream:
    """
    A class to create an unbuffered stream.
    """

    __stream: TextIOBase = None

    @validate_call(config=ConfigDict(strict=True, arbitrary_types_allowed=True))
    def __init__(self, stream: TextIOBase) -> None:
        """Initialize the UnbufferedStream with the given stream.

        Args:
            stream (TextIOBase): The stream to be unbuffered.
        """
        self.__stream = stream

    @validate_call(config=ConfigDict(strict=True))
    def write(self, data: str) -> None:
        """Write data to the stream and flush it immediately.

        Args:
            data (str): The data to be written to the stream.
        """
        self.__stream.write(data)
        self.__stream.flush()

    @validate_call(config=ConfigDict(strict=True))
    def writelines(self, data: list[str]) -> None:
        """Write a list of strings to the stream and flush it immediately.

        Args:
            data (list[str]): The list of strings to be written to the stream.
        """
        self.__stream.writelines(data)
        self.__stream.flush()

    @validate_call(config=ConfigDict(strict=True))
    def __getattr__(self, attr: Any) -> Any:
        """Delegate attribute access to the underlying stream.

        Args:
            attr (Any): The attribute to be accessed.

        Returns:
            Any: The value of the accessed attribute from the underlying stream.
        """
        return getattr(self.__stream, attr)
