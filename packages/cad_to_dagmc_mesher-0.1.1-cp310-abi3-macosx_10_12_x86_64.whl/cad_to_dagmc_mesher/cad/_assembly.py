"""Multi-volume (imprinted assembly) meshing pipeline."""

from OCP.BRepAdaptor import BRepAdaptor_Surface
from OCP.BRepMesh import BRepMesh_IncrementalMesh
from OCP.BRepTools import BRepTools
from OCP.TopAbs import TopAbs_EDGE, TopAbs_FACE, TopAbs_REVERSED
from OCP.TopExp import TopExp_Explorer
from OCP.TopoDS import TopoDS

from cad_to_dagmc_mesher import mesh_faces_parallel

from ._classify import (
    _count_degenerate_edges,
    _face_has_seam_edges,
    _face_is_effectively_doubly_periodic,
    _face_normal_outward,
)
from ._evaluate import _cleanup_non_manifold, _evaluate_face_3d, _stitch_periodic_uv_mesh
from ._extract import _extract_brep_mesh_face, _extract_face
from ._meshadapt import _mesh_face_meshadapt
from ._optimize import _collapse_periodic_mesh_3d, _optimize_3d_mesh
from ._utils import _fix_normals_bfs, _merge_vertices_with_remap, _remap_tris


def _dedup_tris(tris: list[list[int]]) -> list[list[int]]:
    """Remove duplicate triangles (same sorted vertex triple)."""
    seen = set()
    result = []
    for t in tris:
        key = tuple(sorted(t))
        if key not in seen:
            seen.add(key)
            result.append(t)
    return result


def _imprint_assembly(assembly):
    """Imprint a CadQuery assembly using BOPAlgo_MakeConnected."""
    import cadquery as cq
    return cq.occ_impl.assembly.imprint(assembly)


def _get_solids(occ_shape):
    """Extract all solids from an OCC shape."""
    from OCP.TopAbs import TopAbs_SOLID
    solids = []
    exp = TopExp_Explorer(occ_shape, TopAbs_SOLID)
    while exp.More():
        solids.append(TopoDS.Solid_s(exp.Current()))
        exp.Next()
    return solids


def extract_assembly(
    assembly,
    tolerance: float = 0.01,
    angular_tolerance: float = 0.2,
    imprint: bool = True,
) -> dict:
    """Imprint a CadQuery assembly and extract face inputs with shared-face tracking.

    Parameters
    ----------
    assembly : cadquery.Assembly
        The CadQuery assembly to imprint and extract.
    tolerance : float
        Linear deflection tolerance for edge discretization.
    angular_tolerance : float
        Angular deflection tolerance for edge discretization.

    Returns
    -------
    dict
        Keys: ``face_inputs``, ``occ_faces``, ``solid_face_ids``,
        ``face_solid_ids``, ``face_reversed``, ``solid_names``,
        ``imprinted_compound``, ``_occ_faces_map``, ``_global_edge_map``.
    """
    if imprint:
        imprinted_compound, solids_with_ids = _imprint_assembly(assembly)
    else:
        # Skip imprinting — geometry is already prepared
        import cadquery as cq
        imprinted_compound = assembly
        solids_with_ids = {}
        for name, child in assembly.objects.items():
            if hasattr(child, "obj") and child.obj is not None:
                solids_with_ids[child.obj] = [name]
    occ_compound = getattr(imprinted_compound, "wrapped", imprinted_compound)

    solids = _get_solids(occ_compound)
    solid_names = {}
    for i, solid in enumerate(solids):
        solid_id = i + 1
        for shape, names in solids_with_ids.items():
            occ_s = getattr(shape, "wrapped", shape)
            if occ_s.IsEqual(solid):
                solid_names[solid_id] = names[0] if names else f"solid_{solid_id}"
                break
        else:
            solid_names[solid_id] = f"solid_{solid_id}"

    seen_faces = {}
    face_inputs = []
    occ_faces_map = {}
    solid_face_ids = {}
    face_solid_ids = {}
    face_reversed = {}
    next_face_id = 1
    # Build global edge index so shared edges get identical discretization
    from OCP.TopTools import TopTools_IndexedMapOfShape
    from OCP.TopExp import TopExp
    global_edge_map = TopTools_IndexedMapOfShape()
    TopExp.MapShapes_s(occ_compound, TopAbs_EDGE, global_edge_map)
    edge_params_cache = {"_edge_map": global_edge_map}

    for i, solid in enumerate(solids):
        solid_id = i + 1
        solid_face_ids[solid_id] = []

        face_exp = TopExp_Explorer(solid, TopAbs_FACE)
        while face_exp.More():
            occ_face = TopoDS.Face_s(face_exp.Current())
            face_hash = hash(occ_face)
            reversed = occ_face.Orientation() == TopAbs_REVERSED

            if face_hash in seen_faces:
                fid = seen_faces[face_hash]
            else:
                fid = next_face_id
                next_face_id += 1
                seen_faces[face_hash] = fid

                result = _extract_face(occ_face, fid, tolerance, angular_tolerance,
                                       edge_params_cache=edge_params_cache)
                if result is not None:
                    fi, occ_edge_list = result
                    if fi is not None:
                        face_inputs.append(fi)
                        occ_faces_map[fid] = occ_face
                        # Stash OCC edges for shared-edge harmonization
                        occ_faces_map[("occ_edges", fid)] = occ_edge_list

            solid_face_ids[solid_id].append(fid)
            face_reversed[(solid_id, fid)] = reversed

            if fid not in face_solid_ids:
                face_solid_ids[fid] = []
            if solid_id not in face_solid_ids[fid]:
                face_solid_ids[fid].append(solid_id)

            face_exp.Next()

    occ_faces = [occ_faces_map[fi.face_id] for fi in face_inputs]

    return {
        "face_inputs": face_inputs,
        "occ_faces": occ_faces,
        "solid_face_ids": solid_face_ids,
        "face_solid_ids": face_solid_ids,
        "face_reversed": face_reversed,
        "solid_names": solid_names,
        "imprinted_compound": occ_compound,
        "_occ_faces_map": occ_faces_map,
        "_global_edge_map": global_edge_map,
    }


def _harmonize_shared_edges(face_inputs, occ_faces, occ_faces_map=None):
    """Ensure shared OCC edges have identical discretization across faces.

    Uses OCC `IsSame()` to find shared edges. Picks the densest
    discretization and projects 3D points to the sparser face's UV.
    """
    from OCP.BRepAdaptor import BRepAdaptor_Surface
    from OCP.BRep import BRep_Tool
    from OCP.ShapeAnalysis import ShapeAnalysis_Surface
    from OCP.gp import gp_Pnt

    if occ_faces_map is None:
        return

    # Collect all (face_idx, edge_idx, occ_edge, n_points) tuples
    all_edges = []
    for fi_idx, fi in enumerate(face_inputs):
        fid = fi.face_id
        occ_edge_list = occ_faces_map.get(("occ_edges", fid), [])
        edges = fi.boundary_edges
        for ei_idx in range(min(len(edges), len(occ_edge_list))):
            all_edges.append((fi_idx, ei_idx, occ_edge_list[ei_idx], len(edges[ei_idx].uv_points)))

    # Group by shared identity (IsSame)
    groups = []  # each group is a list of (fi_idx, ei_idx, n_pts)
    used = set()
    for i, (fi_i, ei_i, occ_i, n_i) in enumerate(all_edges):
        if i in used:
            continue
        group = [(fi_i, ei_i, n_i)]
        used.add(i)
        for j, (fi_j, ei_j, occ_j, n_j) in enumerate(all_edges):
            if j in used:
                continue
            if occ_i.IsSame(occ_j):
                group.append((fi_j, ei_j, n_j))
                used.add(j)
        if len(group) > 1:
            groups.append(group)

    # For each group with mismatched point counts, harmonize
    for group in groups:
        counts = [g[2] for g in group]
        if len(set(counts)) == 1:
            continue  # already matching

        # Pick the densest edge
        dense_idx = max(range(len(group)), key=lambda k: group[k][2])
        dense_fi, dense_ei, _ = group[dense_idx]

        # Get 3D points from the dense edge
        dense_of = occ_faces[dense_fi]
        dense_surf = BRepAdaptor_Surface(dense_of)
        dense_uv = face_inputs[dense_fi].boundary_edges[dense_ei].uv_points
        pts_3d = []
        for uv in dense_uv:
            p = dense_surf.Value(uv[0], uv[1])
            pts_3d.append((p.X(), p.Y(), p.Z()))

        # Project to each other face in the group
        for k, (sparse_fi, sparse_ei, sparse_n) in enumerate(group):
            if k == dense_idx:
                continue
            sparse_of = occ_faces[sparse_fi]
            geom_surf = BRep_Tool.Surface_s(sparse_of)
            sa_surf = ShapeAnalysis_Surface(geom_surf)
            new_uv = []
            for p3d in pts_3d:
                uv = sa_surf.ValueOfUV(gp_Pnt(*p3d), 1e-6)
                new_uv.append([uv.X(), uv.Y()])
            edges = face_inputs[sparse_fi].boundary_edges
            edges[sparse_ei].uv_points = new_uv
            face_inputs[sparse_fi].boundary_edges = edges


def _subdivide_long_edges(face_input, occ_face, target_edge_length):
    """Subdivide boundary edges of a FaceInput so no edge exceeds target_edge_length.

    Evaluates the OCC surface at intermediate UV parameters to place new
    points on the actual curved surface. Modifies face_input in place.
    """
    from OCP.BRepAdaptor import BRepAdaptor_Surface

    surface = BRepAdaptor_Surface(occ_face)

    def _subdivide_edge(edge):
        pts = edge.uv_points
        if len(pts) < 2:
            return
        new_pts = [pts[0]]
        for i in range(len(pts) - 1):
            uv_a, uv_b = pts[i], pts[i + 1]
            # Compute 3D distance
            p_a = surface.Value(uv_a[0], uv_a[1])
            p_b = surface.Value(uv_b[0], uv_b[1])
            d = ((p_b.X() - p_a.X()) ** 2 + (p_b.Y() - p_a.Y()) ** 2
                 + (p_b.Z() - p_a.Z()) ** 2) ** 0.5
            if d <= target_edge_length:
                new_pts.append(pts[i + 1])
            else:
                # Subdivide uniformly in UV
                n_seg = max(2, int(d / target_edge_length + 0.5))
                for k in range(1, n_seg):
                    t = k / n_seg
                    u = uv_a[0] + t * (uv_b[0] - uv_a[0])
                    v = uv_a[1] + t * (uv_b[1] - uv_a[1])
                    new_pts.append([u, v])
                new_pts.append(pts[i + 1])
        edge.uv_points = new_pts

    # boundary_edges getter returns a copy, so modify + set back
    edges = face_input.boundary_edges
    for edge in edges:
        _subdivide_edge(edge)
    face_input.boundary_edges = edges

    holes = face_input.holes
    for hole in holes:
        for edge in hole:
            _subdivide_edge(edge)
    face_input.holes = holes


def _subdivide_shared_edges_only(face_input, occ_face, target_edge_length, fine_edge_ids):
    """Subdivide only the edges shared with fine faces (conformal boundary).

    Non-fine faces keep their coarse interior but need matching boundary
    points on edges shared with tet-meshed faces.
    """
    from OCP.BRepAdaptor import BRepAdaptor_Surface

    surface = BRepAdaptor_Surface(occ_face)

    def _maybe_subdivide(edge):
        if edge.edge_id not in fine_edge_ids:
            return
        pts = edge.uv_points
        if len(pts) < 2:
            return
        new_pts = [pts[0]]
        for i in range(len(pts) - 1):
            uv_a, uv_b = pts[i], pts[i + 1]
            p_a = surface.Value(uv_a[0], uv_a[1])
            p_b = surface.Value(uv_b[0], uv_b[1])
            d = ((p_b.X() - p_a.X()) ** 2 + (p_b.Y() - p_a.Y()) ** 2
                 + (p_b.Z() - p_a.Z()) ** 2) ** 0.5
            if d <= target_edge_length:
                new_pts.append(pts[i + 1])
            else:
                n_seg = max(2, int(d / target_edge_length + 0.5))
                for k in range(1, n_seg):
                    t = k / n_seg
                    u = uv_a[0] + t * (uv_b[0] - uv_a[0])
                    v = uv_a[1] + t * (uv_b[1] - uv_a[1])
                    new_pts.append([u, v])
                new_pts.append(pts[i + 1])
        edge.uv_points = new_pts

    edges = face_input.boundary_edges
    for edge in edges:
        _maybe_subdivide(edge)
    face_input.boundary_edges = edges

    holes = face_input.holes
    for hole in holes:
        for edge in hole:
            _maybe_subdivide(edge)
    face_input.holes = holes


def _refine_surface_to_edge_length(
    vertices: list[list[float]],
    triangles: list[list[int]],
    target_edge_length: float,
) -> tuple[list[list[float]], list[list[int]]]:
    """Refine a surface mesh so no edge exceeds ``target_edge_length``.

    Iteratively splits long edges by inserting midpoints.
    Delegates to the Rust implementation for performance.
    """
    from cad_to_dagmc_mesher import refine_surface_to_edge_length as _refine_rust
    new_verts, new_tris = _refine_rust(vertices, triangles, target_edge_length)
    return [list(v) for v in new_verts], [list(t) for t in new_tris]


def mesh_assembly(
    assembly,
    material_tags: list[str],
    tolerance: float = 0.03,
    angular_tolerance: float = 0.4,
    mesher: str = "auto",
    tet_volumes: list[str] | None = None,
    target_edge_length: float | None = None,
    imprint: bool = True,
) -> dict:
    """Imprint, mesh, and produce output compatible with ``vertices_to_h5m``.

    This is the main entry point for meshing a CadQuery assembly. It produces
    a watertight, conformal surface mesh suitable for DAGMC particle transport,
    and optionally fills selected volumes with tetrahedral elements for
    OpenMC unstructured mesh tallies.

    Parameters
    ----------
    assembly : cadquery.Assembly
        The CadQuery assembly to mesh. Must contain at least one solid.
    material_tags : list[str]
        One material tag per solid in the assembly (order matches solid order).
    tolerance : float
        Linear deflection tolerance for surface meshing (smaller = more triangles).
    angular_tolerance : float
        Angular deflection tolerance for surface meshing (smaller = more triangles).
    mesher : str
        Surface meshing backend: ``"auto"`` (default), ``"meshadapt"``, or
        ``"brepmesh"``.
    tet_volumes : list[str] or None
        Material tags of volumes to fill with tetrahedra. If ``None``, only
        surface meshing is performed.
    target_edge_length : float or None
        Target edge length for tet meshing. Required when ``tet_volumes`` is set.
        Controls both the surface triangle size on tet-meshed faces and the
        interior tet edge length.
    imprint : bool
        If ``True`` (default), imprint the assembly using BOPAlgo to create
        shared faces between touching solids. Set to ``False`` if the geometry
        is already imprinted (e.g. solids built from shared surfaces in
        CadQuery).

    Returns
    -------
    dict
        Always contains:

        - ``"vertices"`` — list of ``[x, y, z]`` coordinates
        - ``"triangles_by_solid_by_face"`` — ``{solid_id: {face_id: [[v0,v1,v2], ...]}}``
        - ``"material_tags"`` — copy of the input material tags

        When ``tet_volumes`` is set, also contains:

        - ``"tet_data"`` — ``{solid_id: {"vertices": [...], "tetrahedra": [...],
          "boundary_vertices": [...], "boundary_triangles": [...]}}``

    Examples
    --------
    Surface mesh only::

        result = mesh_assembly(assembly, ["steel", "water"])
        vertices_to_h5m(result["vertices"],
                        result["triangles_by_solid_by_face"],
                        result["material_tags"],
                        h5m_filename="dagmc.h5m")

    With tet meshing::

        result = mesh_assembly(assembly, ["steel", "water"],
                               tet_volumes=["steel"],
                               target_edge_length=0.5)
        # Surface mesh → DAGMC h5m
        vertices_to_h5m(...)
        # Tet mesh → VTK for OpenMC UnstructuredMesh
        td = result["tet_data"][1]
        write_vtk(td["vertices"], td["tetrahedra"])
    """
    if tet_volumes and target_edge_length is None:
        raise ValueError("target_edge_length is required when tet_volumes is specified")
    info = extract_assembly(assembly, tolerance, angular_tolerance, imprint=imprint)

    face_inputs = info["face_inputs"]
    occ_faces = info["occ_faces"]
    solid_face_ids = info["solid_face_ids"]
    face_solid_ids = info["face_solid_ids"]

    # Harmonize shared edge discretization across faces
    _harmonize_shared_edges(face_inputs, occ_faces, info.get("_occ_faces_map"))

    # Identify tet-meshed solids and which faces need fine meshing.
    # "Fine faces" = faces on tet-meshed solids (including shared faces).
    # Shared faces between tet and non-tet solids get fine mesh for conformality.
    _tet_solid_ids = set()
    _fine_face_ids = set()  # faces that need uniform triangles
    if tet_volumes and target_edge_length:
        for idx, tag in enumerate(material_tags):
            if tag in tet_volumes:
                _tet_solid_ids.add(idx + 1)
        for sid in _tet_solid_ids:
            for fid in solid_face_ids.get(sid, []):
                _fine_face_ids.add(fid)

    brep_face_set = set()
    meshadapt_face_set = set()
    periodic_face_ids = set()
    doubly_periodic_face_ids = set()
    for i, of in enumerate(occ_faces):
        surf = BRepAdaptor_Surface(of)
        doubly_periodic = surf.IsUPeriodic() and surf.IsVPeriodic()
        eff_doubly_periodic = _face_is_effectively_doubly_periodic(of)
        has_seam = _face_has_seam_edges(of)
        fid = face_inputs[i].face_id
        is_fine = fid in _fine_face_ids

        n_degen = _count_degenerate_edges(of)
        if n_degen > 0:
            # Route ALL degenerate faces to BRepMesh so the compound gets a
            # single consistent tessellation (MeshAdapt produces independent
            # vertices that don't match shared edges).
            brep_face_set.add(i)
        elif (doubly_periodic or eff_doubly_periodic) and has_seam:
            periodic_face_ids.add(fid)
            if doubly_periodic:
                doubly_periodic_face_ids.add(fid)
        elif has_seam and len(occ_faces) > 1:
            if False and is_fine:
                # DISABLED: CDT periodic path produces more open edges (210)
                # than BRepMesh (32). Keep seam faces on BRepMesh for now.
                # Route seam faces on tet-meshed solids through CDT periodic
                # path so the size field controls triangle size.
                periodic_face_ids.add(fid)
            else:
                brep_face_set.add(i)

    cdt_face_indices = [i for i in range(len(occ_faces))
                        if i not in brep_face_set and i not in meshadapt_face_set]

    # For fine faces: set adaptive size field + subdivide edges.
    # Also subdivide edges on NON-fine faces that share an edge with a fine
    # face (conformal boundary), but leave their interior coarse.
    if _fine_face_ids and target_edge_length:
        from ._size_field import compute_size_field

        # Build edge_id → face indices map to find shared edges
        edge_to_faces = {}
        for i, fi in enumerate(face_inputs):
            for e in fi.boundary_edges:
                edge_to_faces.setdefault(e.edge_id, []).append(i)
            for hole in fi.holes:
                for e in hole:
                    edge_to_faces.setdefault(e.edge_id, []).append(i)

        # Collect edge_ids that border any fine face
        fine_edge_ids = set()
        for i, fi in enumerate(face_inputs):
            if fi.face_id in _fine_face_ids:
                for e in fi.boundary_edges:
                    fine_edge_ids.add(e.edge_id)
                for hole in fi.holes:
                    for e in hole:
                        fine_edge_ids.add(e.edge_id)

        # Pass 1: Compute 3D subdivision points for each GLOBAL edge.
        # Subdivide once in 3D so shared edges get identical points.
        from OCP.BRepAdaptor import BRepAdaptor_Surface as _BAS
        from OCP.ShapeAnalysis import ShapeAnalysis_Surface as _SAS
        from OCP.BRep import BRep_Tool as _BRT
        from OCP.gp import gp_Pnt as _gp_Pnt

        # Get OCC edge lists per face for global edge ID lookup
        _occ_faces_map = info.get("_occ_faces_map", {})
        global_edge_map = info.get("_global_edge_map")

        edge_3d_points = {}  # global_edge_id → list of [x,y,z]
        for i, fi in enumerate(face_inputs):
            if fi.face_id not in _fine_face_ids:
                continue
            surface = _BAS(occ_faces[i])
            edges = fi.boundary_edges
            occ_edge_list = _occ_faces_map.get(("occ_edges", fi.face_id), [])
            for ei_idx, edge in enumerate(edges):
                # Get global edge ID
                gid = None
                if ei_idx < len(occ_edge_list):
                    gid = global_edge_map.FindIndex(occ_edge_list[ei_idx])
                if gid is None or gid <= 0:
                    gid = (fi.face_id, edge.edge_id)  # fallback: face-local
                if gid in edge_3d_points:
                    continue  # already subdivided by another face
                pts = edge.uv_points
                if len(pts) < 2:
                    continue
                pts_3d = []
                for uv in pts:
                    p = surface.Value(uv[0], uv[1])
                    pts_3d.append([p.X(), p.Y(), p.Z()])
                new_3d = [pts_3d[0]]
                for j in range(len(pts_3d) - 1):
                    a, b = pts_3d[j], pts_3d[j + 1]
                    d = sum((a[k] - b[k]) ** 2 for k in range(3)) ** 0.5
                    if d <= target_edge_length:
                        new_3d.append(pts_3d[j + 1])
                    else:
                        n_seg = max(2, int(d / target_edge_length + 0.5))
                        for k in range(1, n_seg):
                            t = k / n_seg
                            new_3d.append([
                                a[0] + t * (b[0] - a[0]),
                                a[1] + t * (b[1] - a[1]),
                                a[2] + t * (b[2] - a[2]),
                            ])
                        new_3d.append(pts_3d[j + 1])
                edge_3d_points[gid] = new_3d

        # Pass 2: For each face, subdivide edges using the SAME proportional
        # positions as the 3D subdivision. This avoids 3D→UV projection errors.
        # We store the subdivision ratios (not 3D points) per edge_id.
        edge_subdiv_ratios = {}  # edge_id → list of (segment_idx, list_of_t_values)
        for eid, pts_3d in edge_3d_points.items():
            # Compute cumulative arc length of original segments
            # (the new_3d list has original endpoints + inserted midpoints)
            # The ratios tell us where each new point falls relative to
            # the original segment endpoints.
            ratios = []  # (original_segment_index, fractional_position)
            # Rebuild: walk through the 3D points and figure out which
            # original segment each belongs to. Actually, the subdivision
            # inserts points proportionally within each segment, so we
            # just need the count per segment. Store as flat list of
            # (orig_seg_idx, t) pairs.
            pass  # Complex — use simpler approach below

        # Simpler approach: for each face, subdivide its edges in UV space
        # using the same 3D distances. This ensures all faces sharing an
        # edge get the SAME number of points at proportionally matching
        # positions along the 3D curve.
        for i, fi in enumerate(face_inputs):
            is_fine = fi.face_id in _fine_face_ids
            has_shared = any(e.edge_id in fine_edge_ids for e in fi.boundary_edges)

            if is_fine:
                sf = compute_size_field(
                    occ_faces[i], nu=20, nv=20,
                    max_h=target_edge_length,
                )
                fi.mode = ("adaptive", sf)

            if is_fine or has_shared:
                surface = _BAS(occ_faces[i])
                edges = fi.boundary_edges
                occ_edge_list = _occ_faces_map.get(("occ_edges", fi.face_id), [])
                for ei_idx, edge in enumerate(edges):
                    # Get global edge ID (same as Pass 1)
                    gid = None
                    if ei_idx < len(occ_edge_list):
                        gid = global_edge_map.FindIndex(occ_edge_list[ei_idx])
                    if gid is None or gid <= 0:
                        gid = (fi.face_id, edge.edge_id)
                    should_subdivide = is_fine or (edge.edge_id in fine_edge_ids)
                    if not should_subdivide:
                        continue
                    if gid not in edge_3d_points:
                        continue
                    n_target = len(edge_3d_points[gid])
                    pts = edge.uv_points
                    if len(pts) < 2 or n_target <= len(pts):
                        continue
                    # Compute 3D arc lengths along this face's UV parameterization
                    seg_lengths = []
                    for j in range(len(pts) - 1):
                        p0 = surface.Value(pts[j][0], pts[j][1])
                        p1 = surface.Value(pts[j + 1][0], pts[j + 1][1])
                        d = ((p1.X()-p0.X())**2 + (p1.Y()-p0.Y())**2 + (p1.Z()-p0.Z())**2)**0.5
                        seg_lengths.append(d)
                    total_len = sum(seg_lengths)
                    if total_len < 1e-12:
                        continue
                    # Distribute n_target-1 intervals uniformly along the arc
                    target_spacing = total_len / (n_target - 1)
                    new_uv = [pts[0]]
                    cum = 0.0
                    next_target = target_spacing
                    for j in range(len(pts) - 1):
                        seg_len = seg_lengths[j]
                        seg_start = cum
                        cum += seg_len
                        while next_target < cum - 1e-12 and len(new_uv) < n_target - 1:
                            frac = (next_target - seg_start) / seg_len if seg_len > 1e-12 else 0.5
                            u = pts[j][0] + frac * (pts[j+1][0] - pts[j][0])
                            v = pts[j][1] + frac * (pts[j+1][1] - pts[j][1])
                            new_uv.append([u, v])
                            next_target += target_spacing
                    new_uv.append(pts[-1])
                    edge.uv_points = new_uv
                fi.boundary_edges = edges

        # Re-harmonize after subdivision (subdivision may have changed point counts)
        _harmonize_shared_edges(face_inputs, occ_faces, info.get("_occ_faces_map"))

    all_vertices = []
    face_tris_global_raw = {}

    # MeshAdapt path
    if meshadapt_face_set:
        for idx in sorted(meshadapt_face_set):
            fi, of = face_inputs[idx], occ_faces[idx]
            result = _mesh_face_meshadapt(of, tolerance, angular_tolerance)
            if result is not None:
                verts, tris = result
                offset = len(all_vertices)
                all_vertices.extend(verts)
                global_tris = [
                    [t[0] + offset, t[1] + offset, t[2] + offset] for t in tris
                ]
                face_tris_global_raw[fi.face_id] = global_tris
            elif mesher == "auto":
                brep_face_set.add(idx)
            else:
                raise RuntimeError(
                    f"MeshAdapt failed on face {fi.face_id} and mesher='meshadapt' "
                    f"(no fallback)"
                )

    # BRepMesh path
    if brep_face_set:
        occ_compound = info.get("imprinted_compound")
        if occ_compound is not None:
            occ_compound = getattr(occ_compound, "wrapped", occ_compound)

            from OCP.Bnd import Bnd_Box
            from OCP.BRepBndLib import BRepBndLib
            bbox = Bnd_Box()
            BRepBndLib.Add_s(occ_compound, bbox)
            xmin, ymin, zmin, xmax, ymax, zmax = bbox.Get()
            diag = ((xmax-xmin)**2 + (ymax-ymin)**2 + (zmax-zmin)**2) ** 0.5
            scaled_tol = max(tolerance, diag * 0.004)
            scaled_ang = max(angular_tolerance, 0.2)

            BRepTools.Clean_s(occ_compound)
            BRepMesh_IncrementalMesh(occ_compound, scaled_tol, False, scaled_ang)

        for idx in list(cdt_face_indices):
            fid = face_inputs[idx].face_id
            if fid not in periodic_face_ids:
                brep_face_set.add(idx)
                cdt_face_indices.remove(idx)

        for idx in sorted(brep_face_set):
            fi, of = face_inputs[idx], occ_faces[idx]
            brep = _extract_brep_mesh_face(of)
            if brep is None:
                continue
            verts, tris = brep
            verts, tris = _optimize_3d_mesh(verts, tris, of, passes=3,
                                            tolerance=scaled_tol)
            # Close any remaining open edges from BRepMesh seam stitching
            verts, tris = _cleanup_non_manifold(verts, tris)
            offset = len(all_vertices)
            all_vertices.extend(verts)
            face_tris_global_raw[fi.face_id] = [
                [t[0] + offset, t[1] + offset, t[2] + offset] for t in tris
            ]

    # CDT path
    if cdt_face_indices:
        cdt_inputs = [face_inputs[i] for i in cdt_face_indices]
        cdt_occ = [occ_faces[i] for i in cdt_face_indices]
        from cad_to_dagmc_mesher import mesh_faces_dag
        face_outputs = mesh_faces_dag(cdt_inputs)
        for fi, fo, of in zip(cdt_inputs, face_outputs, cdt_occ):
            offset = len(all_vertices)
            if fi.face_id in periodic_face_ids:
                truly_periodic = fi.face_id in doubly_periodic_face_ids
                verts, tris = _stitch_periodic_uv_mesh(
                    fi, fo, of, fill_holes=truly_periodic)
                is_tet_face = fi.face_id in _fine_face_ids
                if not is_tet_face:
                    # Non-tet faces: collapse for minimal triangulation
                    cr = 0.48 if truly_periodic else 0.35
                    verts, tris = _collapse_periodic_mesh_3d(
                        verts, tris, of, passes=3, collapse_ratio=cr,
                        tolerance=tolerance)
                # else: tet faces keep the CDT's equilateral triangles
                verts, tris = _cleanup_non_manifold(verts, tris)
            else:
                verts, tris = _evaluate_face_3d(fi, fo, of)
            all_vertices.extend(verts)
            global_tris = [[t[0] + offset, t[1] + offset, t[2] + offset] for t in tris]
            if not _face_normal_outward(of):
                for t in global_tris:
                    t[0], t[1], t[2] = t[0], t[2], t[1]
            face_tris_global_raw[fi.face_id] = global_tris

    # Merge vertices + build output
    # Merge tolerance: use the mesh tolerance scaled up to catch near-duplicate
    # vertices from independent face discretizations on shared edges.
    merge_tol = None  # auto-computed from vertex extent
    all_vertices, remap = _merge_vertices_with_remap(all_vertices, tol=merge_tol)

    face_ref_count = {}
    for fids in solid_face_ids.values():
        for fid in fids:
            face_ref_count[fid] = face_ref_count.get(fid, 0) + 1

    if brep_face_set:
        complete = {}
        for solid_id, fids in solid_face_ids.items():
            solid_tris = {}
            for fid in fids:
                if fid not in face_tris_global_raw:
                    continue
                solid_tris[fid] = _dedup_tris(_remap_tris(face_tris_global_raw[fid], remap))
            complete[solid_id] = solid_tris
        _fix_normals_bfs(all_vertices, complete)

        shared_face_emitted = set()
        triangles_by_solid_by_face = {}
        for solid_id, fids in solid_face_ids.items():
            solid_tris = {}
            for fid in fids:
                if fid not in complete.get(solid_id, {}):
                    continue
                is_shared = face_ref_count.get(fid, 1) > 1
                if is_shared and fid in shared_face_emitted:
                    solid_tris[fid] = []
                else:
                    if is_shared:
                        shared_face_emitted.add(fid)
                    solid_tris[fid] = complete[solid_id][fid]
            triangles_by_solid_by_face[solid_id] = solid_tris
    else:
        shared_face_emitted = set()
        triangles_by_solid_by_face = {}
        for solid_id, fids in solid_face_ids.items():
            solid_tris = {}
            for fid in fids:
                if fid not in face_tris_global_raw:
                    continue
                is_shared = face_ref_count.get(fid, 1) > 1
                if is_shared and fid in shared_face_emitted:
                    solid_tris[fid] = []
                else:
                    if is_shared:
                        shared_face_emitted.add(fid)
                    solid_tris[fid] = _dedup_tris(_remap_tris(face_tris_global_raw[fid], remap))
            triangles_by_solid_by_face[solid_id] = solid_tris

    # Conformal boundary fix: close gaps between independently-meshed faces
    # that share OCC edges. BRepMesh and MeshAdapt produce independent
    # tessellations — this pass fills boundary holes to make them watertight.
    # (CadQuery bug #2020 workaround)
    from cad_to_dagmc_mesher import fill_boundary_holes as _fill_holes
    _all_global_tris = []
    _tri_origins = []  # (solid_id, face_id) per tri
    for sid, faces in triangles_by_solid_by_face.items():
        for fid, tris in faces.items():
            for t in tris:
                _all_global_tris.append(t)
                _tri_origins.append((sid, fid))

    if _all_global_tris:
        _closed = [list(t) for t in _fill_holes(all_vertices, _all_global_tris)]
        _n_added = len(_closed) - len(_all_global_tris)
        if _n_added > 0:
            # Assign new gap-filling triangles to the first solid's first face
            first_sid = next(iter(triangles_by_solid_by_face))
            first_fid = next(
                (fid for fid, tris in triangles_by_solid_by_face[first_sid].items()
                 if tris), None
            )
            if first_fid is not None:
                for t in _closed[len(_all_global_tris):]:
                    triangles_by_solid_by_face[first_sid][first_fid].append(t)

    # Per-volume tet meshing
    tet_data = {}
    if tet_volumes:
        from cad_to_dagmc_mesher import VolumeInput, mesh_volume

        # Identify which solids need tet meshing
        tet_solid_ids = set()
        for i, tag in enumerate(material_tags):
            if tag in tet_volumes:
                tet_solid_ids.add(i + 1)  # solid IDs are 1-based

        # Prepare volume inputs (sequential, fast)
        vol_inputs = {}  # sid → (VolumeInput, local_verts, local_tris)
        for sid in sorted(tet_solid_ids):
            solid_tris = []
            for fid in solid_face_ids.get(sid, []):
                tris_list = triangles_by_solid_by_face.get(sid, {}).get(fid, [])
                if not tris_list:
                    for other_sid in face_solid_ids.get(fid, []):
                        if other_sid != sid:
                            tris_list = triangles_by_solid_by_face.get(other_sid, {}).get(fid, [])
                            if tris_list:
                                break
                solid_tris.extend(tris_list)
            if not solid_tris:
                continue

            used_verts = sorted(set(v for t in solid_tris for v in t))
            global_to_local = {g: l for l, g in enumerate(used_verts)}
            local_verts = [all_vertices[g] for g in used_verts]
            local_tris = [
                [global_to_local[t[0]], global_to_local[t[1]], global_to_local[t[2]]]
                for t in solid_tris
            ]
            inp = VolumeInput(
                boundary_vertices=local_verts,
                boundary_triangles=local_tris,
                target_edge_length=target_edge_length,
            )
            vol_inputs[sid] = (inp, local_verts, local_tris)

        # Execute volume meshing in parallel (mesh_volume releases the GIL)
        def _mesh_one(args):
            sid, (inp, lv, lt) = args
            vol_out = mesh_volume(inp)
            return sid, vol_out, lv, lt

        if len(vol_inputs) > 1:
            from concurrent.futures import ThreadPoolExecutor
            with ThreadPoolExecutor() as pool:
                results = list(pool.map(_mesh_one, vol_inputs.items()))
        else:
            results = [_mesh_one(item) for item in vol_inputs.items()]

        for sid, vol_out, local_verts, local_tris in results:
            tet_verts = list(local_verts) + list(vol_out.interior_vertices)
            tet_data[sid] = {
                "vertices": tet_verts,
                "tetrahedra": vol_out.tetrahedra,
                "boundary_vertices": local_verts,
                "boundary_triangles": local_tris,
            }

    result = {
        "vertices": all_vertices,
        "triangles_by_solid_by_face": triangles_by_solid_by_face,
        "material_tags": list(material_tags),
    }
    if tet_data:
        result["tet_data"] = tet_data
    return result
