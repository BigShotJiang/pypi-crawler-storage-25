"""Face and wire extraction from OCC topology."""

import math

from OCP.BRep import BRep_Tool
from OCP.BRepAdaptor import BRepAdaptor_Curve, BRepAdaptor_Curve2d, BRepAdaptor_Surface
from OCP.BRepMesh import BRepMesh_IncrementalMesh
from OCP.BRepTools import BRepTools, BRepTools_WireExplorer
from OCP.GCPnts import GCPnts_AbscissaPoint, GCPnts_TangentialDeflection
from OCP.GeomAbs import GeomAbs_Plane
from OCP.TopAbs import TopAbs_FACE, TopAbs_WIRE, TopAbs_REVERSED
from OCP.TopExp import TopExp_Explorer
from OCP.TopLoc import TopLoc_Location
from OCP.TopoDS import TopoDS

from cad_to_dagmc_mesher import EdgeInput, FaceInput

from ._classify import (
    _count_degenerate_edges,
    _face_is_effectively_doubly_periodic,
)
from ._size_field import compute_size_field


class _AdvancingFrontFace:
    """Sentinel for doubly-periodic faces meshed by advancing front."""
    def __init__(self, face_id, occ_face):
        self.face_id = face_id
        self.occ_face = occ_face
        self.mode = "advancing_front"
        self.is_planar = False
        self.boundary_edges = []
        self.holes = []


class _StructuredGridFace:
    """Sentinel for doubly-periodic faces meshed by structured grid."""
    def __init__(self, face_id, occ_face):
        self.face_id = face_id
        self.occ_face = occ_face
        self.mode = "structured"
        self.is_planar = False
        self.boundary_edges = []
        self.holes = []


def extract_wire_edges(occ_face, occ_wire, tolerance, angular_tolerance,
                       edge_params_cache=None):
    """Extract ordered edges from a wire as :class:`cad_to_dagmc_mesher.EdgeInput` objects.

    Parameters
    ----------
    edge_params_cache : dict or None
        If provided, maps edge hash → list of 3D curve parameters.
        Shared edges reuse the cached parameters so all faces get
        identical discretization points (ensures conformal meshing).
    """
    edges = []
    edge_id = 0
    wire_exp = BRepTools_WireExplorer(occ_wire, occ_face)

    while wire_exp.More():
        occ_edge = wire_exp.Current()
        reversed = occ_edge.Orientation() == TopAbs_REVERSED

        curve2d = BRepAdaptor_Curve2d(occ_edge, occ_face)
        curve3d = BRepAdaptor_Curve(occ_edge)

        arc_length = GCPnts_AbscissaPoint.Length_s(curve3d)
        if arc_length < 1e-10:
            edge_id += 1
            wire_exp.Next()
            continue

        # Cache key: use global edge index from TopTools_IndexedMapOfShape
        # (passed via edge_params_cache["_edge_map"])
        edge_hash = id(occ_edge)  # fallback
        if edge_params_cache is not None:
            emap = edge_params_cache.get("_edge_map")
            if emap is not None:
                gid = emap.FindIndex(occ_edge)
                if gid > 0:
                    edge_hash = gid
        if edge_params_cache is not None and edge_hash in edge_params_cache:
            _, params = edge_params_cache[edge_hash]
        else:
            discretizer = GCPnts_TangentialDeflection(
                curve3d, tolerance, angular_tolerance
            )
            params = [discretizer.Parameter(i)
                      for i in range(1, discretizer.NbPoints() + 1)]
            if edge_params_cache is not None:
                edge_params_cache[edge_hash] = (occ_edge, params)

        uv_points = []
        for param in params:
            p = curve2d.Value(param)
            uv_points.append([p.X(), p.Y()])

        if len(uv_points) >= 2:
            edges.append(
                EdgeInput(
                    edge_id=edge_id,
                    uv_points=uv_points,
                    reversed=reversed,
                )
            )
        edge_id += 1
        wire_exp.Next()

    return edges


def extract_wire_occ_edges(occ_face, occ_wire):
    """Return the OCC edge objects from a wire in order (for IsSame matching)."""
    from OCP.GCPnts import GCPnts_AbscissaPoint
    result = []
    wire_exp = BRepTools_WireExplorer(occ_wire, occ_face)
    while wire_exp.More():
        occ_edge = wire_exp.Current()
        curve3d = BRepAdaptor_Curve(occ_edge)
        arc_length = GCPnts_AbscissaPoint.Length_s(curve3d)
        if arc_length >= 1e-10:
            result.append(occ_edge)
        wire_exp.Next()
    return result


def _build_singly_periodic_boundary(
    occ_face, surface, tolerance, angular_tolerance,
    u0s, u1s, v0s, v1s, n_u, n_v,
    *, effectively_doubly_periodic=False,
):
    """Build UV rectangle boundary for a singly-periodic face.

    Uses actual OCC edge discretization for the non-periodic direction
    and synthetic edges for the periodic direction seam.
    """
    u_periodic = surface.IsUPeriodic()

    real_edges_min = []
    real_edges_max = []

    wire_exp = TopExp_Explorer(occ_face, TopAbs_WIRE)
    if wire_exp.More():
        occ_wire = TopoDS.Wire_s(wire_exp.Current())
        we = BRepTools_WireExplorer(occ_wire, occ_face)
        while we.More():
            edge = we.Current()
            curve2d = BRepAdaptor_Curve2d(edge, occ_face)
            curve3d = BRepAdaptor_Curve(edge)

            p0 = curve2d.Value(curve2d.FirstParameter())
            p1 = curve2d.Value(curve2d.LastParameter())
            du = abs(p1.X() - p0.X())
            dv = abs(p1.Y() - p0.Y())

            if u_periodic:
                is_real_boundary = du > dv
            else:
                is_real_boundary = dv > du

            if is_real_boundary:
                arc_length = GCPnts_AbscissaPoint.Length_s(curve3d)
                if arc_length < 1e-10:
                    we.Next()
                    continue

                if effectively_doubly_periodic:
                    _tol = max(tolerance * 5.0, arc_length * 0.003)
                    _ang = max(angular_tolerance * 2.5, 0.5)
                else:
                    _tol = tolerance
                    _ang = angular_tolerance

                discretizer = GCPnts_TangentialDeflection(curve3d, _tol, _ang)
                uv_points = []
                for i in range(1, discretizer.NbPoints() + 1):
                    param = discretizer.Parameter(i)
                    p = curve2d.Value(param)
                    uv_points.append([p.X(), p.Y()])

                if len(uv_points) >= 2:
                    if u_periodic:
                        avg_v = sum(pt[1] for pt in uv_points) / len(uv_points)
                        mid_v = (v0s + v1s) / 2
                        if avg_v < mid_v:
                            real_edges_min.append(uv_points)
                        else:
                            real_edges_max.append(uv_points)
                    else:
                        avg_u = sum(pt[0] for pt in uv_points) / len(uv_points)
                        mid_u = (u0s + u1s) / 2
                        if avg_u < mid_u:
                            real_edges_min.append(uv_points)
                        else:
                            real_edges_max.append(uv_points)

            we.Next()

    if u_periodic:
        if real_edges_min:
            bottom_pts = real_edges_min[0]
            if bottom_pts[0][0] > bottom_pts[-1][0]:
                bottom_pts = list(reversed(bottom_pts))
        else:
            bottom_pts = [[u0s + i * (u1s - u0s) / n_u, v0s] for i in range(n_u + 1)]

        if real_edges_max:
            top_pts = real_edges_max[0]
            if top_pts[0][0] < top_pts[-1][0]:
                top_pts = list(reversed(top_pts))
        else:
            top_pts = [[u0s + i * (u1s - u0s) / n_u, v1s] for i in range(n_u, -1, -1)]

        v_pts = [v0s + i * (v1s - v0s) / n_v for i in range(n_v + 1)]
        right_pts = [[u1s, v] for v in v_pts]
        left_pts = [[u0s, v] for v in reversed(v_pts)]

        boundary_edges = [
            EdgeInput(edge_id=0, uv_points=bottom_pts, reversed=False),
            EdgeInput(edge_id=1, uv_points=right_pts, reversed=False),
            EdgeInput(edge_id=2, uv_points=top_pts, reversed=False),
            EdgeInput(edge_id=3, uv_points=left_pts, reversed=False),
        ]
    else:
        if real_edges_min:
            left_pts = real_edges_min[0]
            if left_pts[0][1] < left_pts[-1][1]:
                left_pts = list(reversed(left_pts))
        else:
            left_pts = [[u0s, v] for v in reversed(
                [v0s + i * (v1s - v0s) / n_v for i in range(n_v + 1)]
            )]

        if real_edges_max:
            right_pts = real_edges_max[0]
            if right_pts[0][1] > right_pts[-1][1]:
                right_pts = list(reversed(right_pts))
        else:
            right_pts = [[u1s, v] for v in
                [v0s + i * (v1s - v0s) / n_v for i in range(n_v + 1)]
            ]

        u_pts = [u0s + i * (u1s - u0s) / n_u for i in range(n_u + 1)]
        bottom_pts = [[u, v0s] for u in u_pts]
        top_pts = [[u, v1s] for u in reversed(u_pts)]

        boundary_edges = [
            EdgeInput(edge_id=0, uv_points=bottom_pts, reversed=False),
            EdgeInput(edge_id=1, uv_points=right_pts, reversed=False),
            EdgeInput(edge_id=2, uv_points=top_pts, reversed=False),
            EdgeInput(edge_id=3, uv_points=left_pts, reversed=False),
        ]

    return boundary_edges


def _extract_face(occ_face, face_id, tolerance, angular_tolerance,
                  edge_params_cache=None):
    """Build a FaceInput + metadata for a single OCC face."""
    surface = BRepAdaptor_Surface(occ_face)
    planar = surface.GetType() == GeomAbs_Plane
    doubly_periodic = surface.IsUPeriodic() and surface.IsVPeriodic()
    singly_periodic = (surface.IsUPeriodic() or surface.IsVPeriodic()) and not doubly_periodic

    effectively_doubly_periodic = False
    if singly_periodic and not planar:
        u0t = surface.FirstUParameter()
        u1t = surface.LastUParameter()
        v0t = surface.FirstVParameter()
        v1t = surface.LastVParameter()
        um_t = (u0t + u1t) * 0.5

        if surface.IsUPeriodic():
            p0 = surface.Value(um_t, v0t)
            p1 = surface.Value(um_t, v1t)
        else:
            vm_t = (v0t + v1t) * 0.5
            p0 = surface.Value(u0t, vm_t)
            p1 = surface.Value(u1t, vm_t)

        dist = ((p1.X() - p0.X())**2 + (p1.Y() - p0.Y())**2 + (p1.Z() - p0.Z())**2)**0.5
        effectively_doubly_periodic = dist < 1e-3

    use_uv_rectangle = (doubly_periodic or effectively_doubly_periodic) and not planar

    if use_uv_rectangle:
        from OCP.gp import gp_Pnt, gp_Vec

        u0s = surface.FirstUParameter()
        u1s = surface.LastUParameter()
        v0s = surface.FirstVParameter()
        v1s = surface.LastVParameter()

        _ang_scale = 0.4 / max(angular_tolerance, 1e-10)
        _base_epp = max(3, round(4 * _ang_scale))
        _epp = max(3, _base_epp - 1) if effectively_doubly_periodic else _base_epp
        sf = compute_size_field(occ_face, nu=20, nv=20, elements_per_2pi=_epp)

        um = (u0s + u1s) * 0.5
        vm = (v0s + v1s) * 0.5
        p, du_vec, dv_vec = gp_Pnt(), gp_Vec(), gp_Vec()
        surface.D1(um, vm, p, du_vec, dv_vec)
        sqrt_E = du_vec.Magnitude()
        sqrt_G = dv_vec.Magnitude()
        arc_u = sqrt_E * (u1s - u0s)
        arc_v = sqrt_G * (v1s - v0s)

        sorted_h = sorted(sf["target_h"])
        if effectively_doubly_periodic:
            repr_h = sorted_h[int(len(sorted_h) * 0.75)]
        else:
            repr_h = sum(sf["target_h"]) / len(sf["target_h"])

        n_u = max(8, int(math.ceil(arc_u / repr_h)))
        n_v = max(8, int(math.ceil(arc_v / repr_h)))

        if effectively_doubly_periodic:
            boundary_edges = _build_singly_periodic_boundary(
                occ_face, surface, tolerance, angular_tolerance,
                u0s, u1s, v0s, v1s, n_u, n_v,
                effectively_doubly_periodic=True,
            )
        else:
            u_pts = [u0s + i * (u1s - u0s) / n_u for i in range(n_u + 1)]
            v_pts = [v0s + i * (v1s - v0s) / n_v for i in range(n_v + 1)]

            boundary_edges = [
                EdgeInput(edge_id=0, uv_points=[[u, v0s] for u in u_pts], reversed=False),
                EdgeInput(edge_id=1, uv_points=[[u1s, v] for v in v_pts], reversed=False),
                EdgeInput(edge_id=2, uv_points=[[u, v1s] for u in reversed(u_pts)], reversed=False),
                EdgeInput(edge_id=3, uv_points=[[u0s, v] for v in reversed(v_pts)], reversed=False),
            ]

        fi = FaceInput(
            face_id=face_id,
            boundary_edges=boundary_edges,
            holes=[],
            is_planar=False,
            mode=("adaptive", sf),
        )
        return fi, []  # no OCC edges for periodic boundary builder

    # Non-periodic face: use actual OCC edges
    boundary_edges = []
    holes = []
    wire_idx = 0
    wire_exp = TopExp_Explorer(occ_face, TopAbs_WIRE)

    while wire_exp.More():
        occ_wire = TopoDS.Wire_s(wire_exp.Current())

        total_edge_count = 0
        we = BRepTools_WireExplorer(occ_wire, occ_face)
        while we.More():
            total_edge_count += 1
            we.Next()

        wire_edges = extract_wire_edges(
            occ_face, occ_wire, tolerance, angular_tolerance,
            edge_params_cache=edge_params_cache,
        )
        wire_occ = extract_wire_occ_edges(occ_face, occ_wire)

        if wire_idx == 0:
            boundary_edges = wire_edges
            boundary_occ_edges = wire_occ
        else:
            holes.append(wire_edges)
        wire_idx += 1
        wire_exp.Next()

    if not boundary_edges:
        return None, []

    mode = "coarse"
    if not planar:
        sf = compute_size_field(occ_face, nu=20, nv=20)
        mode = ("adaptive", sf)

    fi = FaceInput(
        face_id=face_id,
        boundary_edges=boundary_edges,
        holes=holes,
        is_planar=planar,
        mode=mode,
    )
    return fi, boundary_occ_edges


def _extract_brep_mesh_face(occ_face):
    """Extract triangulation from OCC's BRepMesh for a single face."""
    loc = TopLoc_Location()
    tri = BRep_Tool.Triangulation_s(occ_face, loc)
    if tri is None or tri.NbTriangles() == 0:
        return None

    transform = loc.Transformation() if not loc.IsIdentity() else None

    verts = []
    for i in range(1, tri.NbNodes() + 1):
        p = tri.Node(i)
        if transform is not None:
            p = p.Transformed(transform)
        verts.append([p.X(), p.Y(), p.Z()])

    tris = []
    for i in range(1, tri.NbTriangles() + 1):
        t = tri.Triangle(i)
        n1, n2, n3 = t.Get()
        tris.append([n1 - 1, n2 - 1, n3 - 1])

    return verts, tris


def extract_face_inputs(shape, tolerance=0.01, angular_tolerance=0.2):
    """Extract :class:`cad_to_dagmc_mesher.FaceInput` objects from an OCC shape.

    Returns ``(face_inputs, occ_faces)``.
    """
    occ_shape = getattr(shape, "wrapped", shape)

    face_inputs = []
    occ_faces = []

    face_exp = TopExp_Explorer(occ_shape, TopAbs_FACE)
    face_id = 0

    while face_exp.More():
        occ_face = TopoDS.Face_s(face_exp.Current())
        fi = _extract_face(occ_face, face_id, tolerance, angular_tolerance)
        if fi is not None:
            face_inputs.append(fi)
            occ_faces.append(occ_face)
        face_id += 1
        face_exp.Next()

    return face_inputs, occ_faces
