"""3D mesh optimization — BRepMesh post-processing and periodic collapse."""

import math
from collections import defaultdict

from OCP.BRep import BRep_Tool
from OCP.BRepAdaptor import BRepAdaptor_Surface
from OCP.ShapeAnalysis import ShapeAnalysis_Surface
from OCP.gp import gp_Pnt

from cad_to_dagmc_mesher import collapse_periodic_mesh_3d as _collapse_periodic_rust


def _optimize_3d_mesh(vertices, triangles, occ_face, passes=2, tolerance=None, angular_tolerance=0.4, collapse_ratio=0.3):
    """Optimize a BRepMesh triangulation via collapse, swap, and smooth.

    Uses OCC surface curvature for target sizing and projects vertices
    back to the exact surface after smoothing.

    Returns (vertices, triangles).
    """
    from cad_to_dagmc_mesher import optimize_mesh_3d

    if len(triangles) < 4:
        return vertices, triangles

    surface = BRepAdaptor_Surface(occ_face)
    geom_surface = BRep_Tool.Surface_s(occ_face)
    sa_surface = ShapeAnalysis_Surface(geom_surface)

    # Compute median edge length for max_h cap
    _init_lengths = []
    for t in triangles:
        for i in range(3):
            a, b = t[i], t[(i+1)%3]
            dx = vertices[a][0] - vertices[b][0]
            dy = vertices[a][1] - vertices[b][1]
            dz = vertices[a][2] - vertices[b][2]
            _init_lengths.append(math.sqrt(dx*dx + dy*dy + dz*dz))
    _init_lengths.sort()
    _median_h = _init_lengths[len(_init_lengths)//2] if _init_lengths else 1.0
    _max_h = _median_h * 3.0

    # Precompute a UV grid of curvature-based target_h values
    # Scale from default angular_tolerance=0.4: tighter → more elements
    _ang_scale = 0.4 / max(angular_tolerance, 1e-10)
    _elements_per_2pi = max(6, round(12 * _ang_scale))
    _grid_n = 20
    u0g = surface.FirstUParameter()
    u1g = surface.LastUParameter()
    v0g = surface.FirstVParameter()
    v1g = surface.LastVParameter()

    from OCP.BRepLProp import BRepLProp_SLProps as _SLProps
    _h_grid = []
    for iv in range(_grid_n):
        vp = v0g + iv * (v1g - v0g) / max(_grid_n - 1, 1)
        for iu in range(_grid_n):
            up = u0g + iu * (u1g - u0g) / max(_grid_n - 1, 1)
            props = _SLProps(surface, up, vp, 2, 1e-7)
            if props.IsCurvatureDefined():
                kappa = max(abs(props.MaxCurvature()), abs(props.MinCurvature()))
            else:
                kappa = 0.0
            if kappa > 1e-12:
                h = 2.0 * math.pi / (kappa * _elements_per_2pi)
                if tolerance is not None:
                    h_chordal = math.sqrt(8.0 * tolerance / kappa)
                    h = min(h, h_chordal)
            else:
                h = _max_h
            _h_grid.append(max(min(h, _max_h), 0.01))

    def _interp_target_h(u, v):
        fu = ((u - u0g) / (u1g - u0g) * (_grid_n - 1))
        fv = ((v - v0g) / (v1g - v0g) * (_grid_n - 1))
        fu = max(0.0, min(fu, _grid_n - 1.0))
        fv = max(0.0, min(fv, _grid_n - 1.0))
        iu = int(fu); iv = int(fv)
        iu1 = min(iu + 1, _grid_n - 1); iv1 = min(iv + 1, _grid_n - 1)
        su = fu - iu; sv = fv - iv
        v00 = _h_grid[iv * _grid_n + iu]
        v10 = _h_grid[iv * _grid_n + iu1]
        v01 = _h_grid[iv1 * _grid_n + iu]
        v11 = _h_grid[iv1 * _grid_n + iu1]
        return (1-su)*(1-sv)*v00 + su*(1-sv)*v10 + (1-su)*sv*v01 + su*sv*v11

    def _target_h_at_3d(x, y, z):
        uv = sa_surface.ValueOfUV(gp_Pnt(x, y, z), 1e-3)
        return _interp_target_h(uv.X(), uv.Y())

    target_h = [_target_h_at_3d(*v) for v in vertices]

    # Detect boundary vertices
    edge_count = defaultdict(int)
    for t in triangles:
        a, b, c = t
        edge_count[(min(a,b), max(a,b))] += 1
        edge_count[(min(b,c), max(b,c))] += 1
        edge_count[(min(a,c), max(a,c))] += 1
    boundary_verts = set()
    for (a, b), cnt in edge_count.items():
        if cnt == 1:
            boundary_verts.add(a)
            boundary_verts.add(b)

    # Reduce passes for complex topology faces
    total_edges = len(edge_count)
    boundary_edges = sum(1 for cnt in edge_count.values() if cnt == 1)
    if total_edges > 0:
        boundary_ratio = boundary_edges / total_edges
    else:
        boundary_ratio = 0.0
    if boundary_ratio > 0.15 and passes > 1:
        passes = 1

    # Reorder vertices so boundary come first
    bv_sorted = sorted(boundary_verts)
    iv_sorted = sorted(set(range(len(vertices))) - boundary_verts)
    perm = bv_sorted + iv_sorted
    inv_perm = [0] * len(vertices)
    for new_i, old_i in enumerate(perm):
        inv_perm[old_i] = new_i

    reordered_verts = [list(vertices[old]) for old in perm]
    reordered_target_h = [target_h[old] for old in perm]
    reordered_tris = [
        [inv_perm[t[0]], inv_perm[t[1]], inv_perm[t[2]]] for t in triangles
    ]
    num_boundary = len(bv_sorted)

    # Interleaved Rust optimisation + surface projection
    cur_verts = reordered_verts
    cur_tris = reordered_tris
    cur_target_h = reordered_target_h
    cur_nbdy = num_boundary

    for _pass in range(passes):
        cur_verts, cur_tris = optimize_mesh_3d(
            cur_verts, cur_tris, cur_target_h, cur_nbdy, 1, collapse_ratio,
        )

        # Project interior vertices onto the OCC surface
        _ec = defaultdict(int)
        for t in cur_tris:
            a, b, c = t
            _ec[(min(a,b), max(a,b))] += 1
            _ec[(min(b,c), max(b,c))] += 1
            _ec[(min(a,c), max(a,c))] += 1
        _bdy = set()
        for (a, b), cnt in _ec.items():
            if cnt == 1:
                _bdy.add(a)
                _bdy.add(b)

        for i in range(len(cur_verts)):
            if i in _bdy:
                continue
            x, y, z = cur_verts[i]
            uv = sa_surface.ValueOfUV(gp_Pnt(x, y, z), 1e-3)
            proj = geom_surface.Value(uv.X(), uv.Y())
            cur_verts[i] = [proj.X(), proj.Y(), proj.Z()]

        if len(cur_verts) != len(cur_target_h):
            cur_target_h = [_target_h_at_3d(*v) for v in cur_verts]
            cur_nbdy = len(_bdy)

    return cur_verts, cur_tris


def _collapse_periodic_mesh_3d(vertices, triangles, occ_face, passes=3,
                                collapse_ratio=0.7, tolerance=None):
    """Collapse-only 3D mesh optimization for stitched periodic faces.

    Delegates to the Rust implementation for performance.
    """
    if len(triangles) < 4:
        return vertices, triangles

    new_verts, new_tris = _collapse_periodic_rust(
        vertices, triangles, passes, collapse_ratio
    )
    return [list(v) for v in new_verts], [list(t) for t in new_tris]
