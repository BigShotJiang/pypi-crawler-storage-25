"""UV→3D evaluation and periodic seam stitching."""

from OCP.BRepAdaptor import BRepAdaptor_Surface
from OCP.TopAbs import TopAbs_REVERSED

from ._utils import _collect_wire_uv, _merge_vertices, _merge_vertices_with_remap


def _evaluate_face_3d(face_in, face_out, occ_face):
    """Evaluate one face's UV results to 3D.

    Returns (vertices_3d, triangles_local).
    """
    surface = BRepAdaptor_Surface(occ_face)

    all_boundary_uv = _collect_wire_uv(face_in.boundary_edges)
    for hole_edges in face_in.holes:
        all_boundary_uv.extend(_collect_wire_uv(hole_edges))

    verts = []
    for uv in all_boundary_uv:
        pt = surface.Value(uv[0], uv[1])
        verts.append([pt.X(), pt.Y(), pt.Z()])

    for uv in face_out.interior_uv_vertices:
        pt = surface.Value(uv[0], uv[1])
        verts.append([pt.X(), pt.Y(), pt.Z()])

    tris = [list(t) for t in face_out.triangles]
    return verts, tris


def _stitch_periodic_uv_mesh(face_in, face_out, occ_face, fill_holes=True):
    """Stitch a periodic UV mesh at its seam edges.

    Projects UV→3D, merges ONLY seam boundary vertices (not interior
    Steiner points), deduplicates triangles, and optionally fills
    boundary holes.

    Returns (vertices_3d, triangles_local).
    """
    from cad_to_dagmc_mesher import fill_boundary_holes as _fill_holes_rust

    surface = BRepAdaptor_Surface(occ_face)

    # Step 1: Project all UV vertices to 3D
    all_boundary_uv = _collect_wire_uv(face_in.boundary_edges)
    n_boundary = len(all_boundary_uv)
    all_uv = list(all_boundary_uv) + list(face_out.interior_uv_vertices)

    verts_3d_raw = []
    for uv in all_uv:
        pt = surface.Value(uv[0], uv[1])
        verts_3d_raw.append([pt.X(), pt.Y(), pt.Z()])

    # Step 2: Merge ONLY boundary vertices by 3D proximity (Rust).
    from cad_to_dagmc_mesher import merge_boundary_only_3d as _merge_bdy_rust
    merged_verts_raw, remap_list = _merge_bdy_rust(verts_3d_raw, n_boundary)
    merged_verts = [list(v) for v in merged_verts_raw]
    merge_map = {i: r for i, r in enumerate(remap_list)}

    # Step 3: Remap + deduplicate triangles
    seen = set()
    tris = []
    for t in face_out.triangles:
        a, b, c = merge_map[t[0]], merge_map[t[1]], merge_map[t[2]]
        if a == b or b == c or a == c:
            continue
        key = tuple(sorted([a, b, c]))
        if key not in seen:
            seen.add(key)
            tris.append([a, b, c])

    # Step 4: Clean non-manifold edges and fill holes (Rust)
    if tris and fill_holes:
        from cad_to_dagmc_mesher import cleanup_non_manifold as _cleanup_rust
        tris = [list(t) for t in _cleanup_rust(merged_verts, tris)]

    return merged_verts, tris


    # _merge_boundary_only_3d moved to Rust (cad_to_dagmc_mesher.merge_boundary_only_3d)
    # _remove_non_manifold_tris moved to Rust (part of cad_to_dagmc_mesher.cleanup_non_manifold)


def _cleanup_non_manifold(verts, tris):
    """Remove non-manifold triangles and close remaining holes (Rust)."""
    from cad_to_dagmc_mesher import cleanup_non_manifold as _cleanup_rust
    cleaned = [list(t) for t in _cleanup_rust(verts, tris)]
    return verts, cleaned


def _mesh_structured_grid(occ_face, n=40):
    """Mesh a doubly-periodic face with a structured UV grid."""
    from OCP.gp import gp_Pnt, gp_Vec

    surface = BRepAdaptor_Surface(occ_face)
    u0 = surface.FirstUParameter()
    u1 = surface.LastUParameter()
    v0 = surface.FirstVParameter()
    v1 = surface.LastVParameter()

    verts = []
    for j in range(n + 1):
        v_param = v0 + j * (v1 - v0) / n
        for i in range(n + 1):
            u_param = u0 + i * (u1 - u0) / n
            pt = surface.Value(u_param, v_param)
            verts.append([pt.X(), pt.Y(), pt.Z()])

    tris = []
    for j in range(n):
        for i in range(n):
            p00 = j * (n + 1) + i
            p10 = j * (n + 1) + i + 1
            p01 = (j + 1) * (n + 1) + i
            p11 = (j + 1) * (n + 1) + i + 1
            if (i + j) % 2 == 0:
                tris.append([p00, p10, p11])
                tris.append([p00, p11, p01])
            else:
                tris.append([p00, p10, p01])
                tris.append([p10, p11, p01])

    reversed_face = occ_face.Orientation() == TopAbs_REVERSED

    umid = (u0 + u1) / 2
    vmid = (v0 + v1) / 2
    p = gp_Pnt()
    du = gp_Vec()
    dv = gp_Vec()
    surface.D1(umid, vmid, p, du, dv)
    if len(tris) > 0 and len(verts) > tris[0][2]:
        a = verts[tris[0][0]]
        b = verts[tris[0][1]]
        c = verts[tris[0][2]]
        ab = [b[k]-a[k] for k in range(3)]
        ac = [c[k]-a[k] for k in range(3)]
        tri_n = [ab[1]*ac[2]-ab[2]*ac[1], ab[2]*ac[0]-ab[0]*ac[2], ab[0]*ac[1]-ab[1]*ac[0]]
        surf_n = [du.Y()*dv.Z()-du.Z()*dv.Y(), du.Z()*dv.X()-du.X()*dv.Z(), du.X()*dv.Y()-du.Y()*dv.X()]
        dot = sum(tri_n[k]*surf_n[k] for k in range(3))

        need_flip = (dot > 0 and reversed_face) or (dot < 0 and not reversed_face)
        if need_flip:
            for t in tris:
                t[0], t[1], t[2] = t[0], t[2], t[1]

    return verts, tris


def evaluate_3d(face_inputs, face_outputs, occ_faces):
    """Convert UV results back to 3D vertices and triangles.

    Returns ``(vertices_3d, triangles)``.
    """
    all_vertices_3d = []
    all_triangles = []

    for face_out, face_in, occ_face in zip(face_outputs, face_inputs, occ_faces):
        vertex_offset = len(all_vertices_3d)
        verts, tris = _evaluate_face_3d(face_in, face_out, occ_face)
        all_vertices_3d.extend(verts)
        for tri in tris:
            all_triangles.append([
                tri[0] + vertex_offset,
                tri[1] + vertex_offset,
                tri[2] + vertex_offset,
            ])

    all_vertices_3d, all_triangles = _merge_vertices(all_vertices_3d, all_triangles)
    return all_vertices_3d, all_triangles
