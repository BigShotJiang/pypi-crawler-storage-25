"""MeshAdapt surface meshing for faces with degenerate edges (sphere poles)."""

import math

from OCP.BRepAdaptor import BRepAdaptor_Surface
from OCP.gp import gp_Pnt, gp_Vec

from cad_to_dagmc_mesher import fill_boundary_holes as _fill_holes_rust

from ._size_field import compute_size_field
from ._utils import _merge_vertices_with_remap


def _mesh_face_meshadapt(occ_face, tolerance=0.01, angular_tolerance=0.2):
    """Mesh a face using the MeshAdapt algorithm instead of BRepMesh/CDT.

    Works in UV parametric space with the metric tensor for
    curvature-adaptive sizing.  For degenerate edges (sphere poles),
    uses a multi-ring pole fan triangulation with surface projection
    between MeshAdapt iterations for improved accuracy.

    Returns (vertices_3d, triangles) or None if MeshAdapt fails.
    """
    from cad_to_dagmc_mesher import meshadapt_face_init, meshadapt_face_step_py
    from OCP.BRepLProp import BRepLProp_SLProps
    from OCP.Bnd import Bnd_Box
    from OCP.BRepBndLib import BRepBndLib
    from OCP.ShapeAnalysis import ShapeAnalysis_Surface
    from OCP.BRep import BRep_Tool
    from OCP.Geom import Geom_Surface

    surface = BRepAdaptor_Surface(occ_face)
    u0 = surface.FirstUParameter()
    u1 = surface.LastUParameter()
    v0 = surface.FirstVParameter()
    v1 = surface.LastVParameter()

    # 1. Compute max_h from bounding box
    bbox = Bnd_Box()
    BRepBndLib.Add_s(occ_face, bbox)
    xmin, ymin, zmin, xmax, ymax, zmax = bbox.Get()
    diag = ((xmax-xmin)**2 + (ymax-ymin)**2 + (zmax-zmin)**2) ** 0.5
    max_h = max(diag * 0.15, 0.1)

    # Scale from defaults: tighter tolerance → more elements
    _tol_scale = 0.03 / max(tolerance, 1e-10)  # >1 when tighter than default
    _ang_scale = 0.4 / max(angular_tolerance, 1e-10)
    _scale = max(_tol_scale, _ang_scale)
    epp = max(8, round(15 * _scale))

    # 2. Compute curvature-adaptive size field
    meshadapt_chordal = max(tolerance, diag * 0.0013 / _scale)
    sf = compute_size_field(occ_face, nu=30, nv=30, elements_per_2pi=epp,
                            max_h=max_h, chordal_tolerance=meshadapt_chordal)

    # Fix degenerate metric tensor entries at poles
    nu_sf, nv_sf = sf["nu"], sf["nv"]
    for iv in range(nv_sf):
        for iu in range(nu_sf):
            idx = iv * nu_sf + iu
            E = sf["metric_e"][idx]
            G = sf["metric_g"][idx]
            if E < 1e-6 or G < 1e-6:
                for dv in range(1, nv_sf):
                    for direction in [1, -1]:
                        niv = iv + dv * direction
                        if 0 <= niv < nv_sf:
                            nidx = niv * nu_sf + iu
                            nE = sf["metric_e"][nidx]
                            nG = sf["metric_g"][nidx]
                            if nE >= 1e-6 and nG >= 1e-6:
                                sf["metric_e"][idx] = nE
                                sf["metric_f"][idx] = sf["metric_f"][nidx]
                                sf["metric_g"][idx] = nG
                                break
                    else:
                        continue
                    break

    # 3. Estimate boundary subdivision
    um = (u0 + u1) * 0.5
    vm = (v0 + v1) * 0.5
    p, du_vec, dv_vec = gp_Pnt(), gp_Vec(), gp_Vec()
    surface.D1(um, vm, p, du_vec, dv_vec)
    sqrt_E = du_vec.Magnitude()
    sqrt_G = dv_vec.Magnitude()
    arc_u = sqrt_E * (u1 - u0)
    arc_v = sqrt_G * (v1 - v0)

    valid_h = sorted(h for h in sf["target_h"] if h < max_h * 0.99)
    if valid_h:
        repr_h = valid_h[len(valid_h) // 2]
    else:
        repr_h = max_h
    n_u = max(8, int(math.ceil(arc_u / repr_h)))
    n_v = max(8, int(math.ceil(arc_v / repr_h)))

    # 4. Detect degenerate edges (poles)
    _p_test = gp_Pnt()
    _du_test = gp_Vec()
    _dv_test = gp_Vec()

    surface.D1((u0+u1)/2, v0, _p_test, _du_test, _dv_test)
    bottom_degenerate = _du_test.Magnitude() < 1e-6
    surface.D1((u0+u1)/2, v1, _p_test, _du_test, _dv_test)
    top_degenerate = _du_test.Magnitude() < 1e-6

    # 5. Build UV boundary polygon with pole inset
    v_range = v1 - v0
    pole_inset_frac = repr_h / (sqrt_G * v_range + 1e-30)
    pole_inset_frac = max(0.02, min(pole_inset_frac, 0.10))
    pole_inset = v_range * pole_inset_frac
    v0_eff = v0 + pole_inset if bottom_degenerate else v0
    v1_eff = v1 - pole_inset if top_degenerate else v1

    n_v_seam = n_v * 2
    u_pts = [u0 + i * (u1 - u0) / n_u for i in range(n_u + 1)]
    v_pts_seam = [v0_eff + i * (v1_eff - v0_eff) / n_v_seam
                  for i in range(n_v_seam + 1)]

    boundary_uv = [[u, v0_eff] for u in u_pts]
    for v in v_pts_seam[1:]:
        boundary_uv.append([u1, v])
    for u in reversed(u_pts[:-1]):
        boundary_uv.append([u, v1_eff])
    for v in reversed(v_pts_seam[1:-1]):
        boundary_uv.append([u0, v])

    if len(boundary_uv) < 3:
        return None

    # 6. Call MeshAdapt with surface projection between iterations
    n_boundary = len(boundary_uv)

    # Get the geometric surface for UV projection
    geom_surface = BRep_Tool.Surface_s(occ_face)
    sa_surface = ShapeAnalysis_Surface(geom_surface)

    try:
        verts_uv, tris = meshadapt_face_init(boundary_uv, sf)
    except Exception:
        return None

    if not verts_uv or not tris:
        return None

    for _iter in range(20):
        verts_uv, tris, changed = meshadapt_face_step_py(
            verts_uv, tris, sf)
        if not changed:
            break
        # Project interior vertices to exact surface, snap UV back
        for i in range(n_boundary, len(verts_uv)):
            u_cur, v_cur = verts_uv[i]
            pt3d = surface.Value(u_cur, v_cur)
            uv_exact = sa_surface.ValueOfUV(pt3d, 1e-6)
            verts_uv[i] = [uv_exact.X(), uv_exact.Y()]

    # 7. Add multi-ring pole fan triangles (Rust)
    from cad_to_dagmc_mesher import add_multi_ring_pole_fan as _pole_fan_rust
    eps_bdy = abs(v1 - v0) * 1e-6
    if bottom_degenerate:
        bdy_row = sorted([(uv[0], i) for i, uv in enumerate(verts_uv)
                          if abs(uv[1] - v0_eff) < eps_bdy])
        verts_uv, tris = _pole_fan_rust(
            verts_uv, tris, bdy_row, u0, u1, v0, v0_eff, False)
        verts_uv = [list(v) for v in verts_uv]
        tris = [list(t) for t in tris]

    if top_degenerate:
        bdy_row = sorted([(uv[0], i) for i, uv in enumerate(verts_uv)
                          if abs(uv[1] - v1_eff) < eps_bdy])
        verts_uv, tris = _pole_fan_rust(
            verts_uv, tris, bdy_row, u0, u1, v1, v1_eff, True)
        verts_uv = [list(v) for v in verts_uv]
        tris = [list(t) for t in tris]

    # 8. Evaluate UV vertices to 3D with chordal offset.
    # Flat triangles inscribe inside curved surfaces, causing volume deficit.
    # Offset each vertex outward along the surface normal by half the local
    # chordal error to compensate.
    from OCP.BRepLProp import BRepLProp_SLProps

    # Compute median curvature for adaptive offset factor
    _kappas = []
    for uv in verts_uv:
        props = BRepLProp_SLProps(surface, uv[0], uv[1], 2, 1e-7)
        if props.IsCurvatureDefined():
            k = max(abs(props.MaxCurvature()), abs(props.MinCurvature()))
            if k > 1e-12:
                _kappas.append(k)
    _kappas.sort()
    _median_kappa = _kappas[len(_kappas) // 2] if _kappas else 0.0

    verts_3d_raw = []
    vert_normals = []
    vert_offsets = []
    for uv in verts_uv:
        u_val, v_val = uv[0], uv[1]
        pt = surface.Value(u_val, v_val)
        x, y, z = pt.X(), pt.Y(), pt.Z()
        verts_3d_raw.append([x, y, z])

        props = BRepLProp_SLProps(surface, u_val, v_val, 2, 1e-7)
        if props.IsCurvatureDefined() and props.IsNormalDefined():
            kappa = max(abs(props.MaxCurvature()), abs(props.MinCurvature()))
            normal = props.Normal()
            vert_normals.append((normal.X(), normal.Y(), normal.Z()))

            if kappa > 1e-12:
                nu_sf, nv_sf = sf["nu"], sf["nv"]
                u_range_sf = sf["u_max"] - sf["u_min"]
                v_range_sf = sf["v_max"] - sf["v_min"]
                fu = max(0.0, min(1.0, (u_val - sf["u_min"]) / u_range_sf)) if u_range_sf > 0 else 0.5
                fv = max(0.0, min(1.0, (v_val - sf["v_min"]) / v_range_sf)) if v_range_sf > 0 else 0.5
                idx = min(int(fv * (nv_sf-1)), nv_sf-1) * nu_sf + min(int(fu * (nu_sf-1)), nu_sf-1)
                h_local = sf["target_h"][idx]

                chordal_err = h_local * h_local * kappa / 8.0
                # Adaptive factor: 0.75 for uniform curvature (sphere),
                # smoothly reducing for vertices where curvature exceeds
                # the median (ellipsoid poles). This prevents overcorrection
                # on non-uniform surfaces.
                _kappa_ratio = kappa / _median_kappa if _median_kappa > 1e-12 else 1.0
                _factor = 0.75 / max(1.0, _kappa_ratio ** 0.5)
                offset = min(chordal_err * _factor, meshadapt_chordal)
                vert_offsets.append(offset)
            else:
                vert_offsets.append(0.0)
        else:
            vert_normals.append((0.0, 0.0, 0.0))
            vert_offsets.append(0.0)
    # Per-vertex measurement overcorrects due to circular dependency.

    # Apply offsets
    for i in range(len(verts_3d_raw)):
        offset = vert_offsets[i] if i < len(vert_offsets) else 0.0
        if offset > 0.0 and i < len(vert_normals):
            nx, ny, nz = vert_normals[i]
            verts_3d_raw[i][0] += offset * nx
            verts_3d_raw[i][1] += offset * ny
            verts_3d_raw[i][2] += offset * nz

    # 9. Merge coincident 3D vertices (seam + pole stitching)
    merged_verts, merge_map = _merge_vertices_with_remap(verts_3d_raw)

    # Remap + deduplicate triangles
    seen = set()
    merged_tris = []
    for t in tris:
        a, b, c = merge_map[t[0]], merge_map[t[1]], merge_map[t[2]]
        if a == b or b == c or a == c:
            continue
        key = tuple(sorted([a, b, c]))
        if key not in seen:
            seen.add(key)
            merged_tris.append([a, b, c])

    if not merged_tris:
        return None

    # 10. Fill remaining topology holes using Rust
    merged_tris = [list(t) for t in _fill_holes_rust(merged_verts, merged_tris)]

    return merged_verts, merged_tris


    # _add_multi_ring_pole_fan moved to Rust (cad_to_dagmc_mesher.add_multi_ring_pole_fan)
