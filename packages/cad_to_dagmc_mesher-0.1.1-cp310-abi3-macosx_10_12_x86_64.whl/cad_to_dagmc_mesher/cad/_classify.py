"""Face classification helpers — detect seams, degenerate edges, periodicity."""

from OCP.BRepAdaptor import BRepAdaptor_Curve, BRepAdaptor_Surface
from OCP.BRepTools import BRepTools_WireExplorer
from OCP.GCPnts import GCPnts_AbscissaPoint
from OCP.GeomAbs import GeomAbs_Plane
from OCP.TopAbs import TopAbs_FACE, TopAbs_WIRE, TopAbs_REVERSED
from OCP.TopExp import TopExp_Explorer
from OCP.TopoDS import TopoDS


def _face_has_seam_edges(occ_face):
    """Check if a face has UV seams that cause non-manifold CDT meshes.

    Returns True for periodic surfaces, degenerate edges, or closed-curve edges.
    Planar faces never have seam issues.
    """
    surface = BRepAdaptor_Surface(occ_face)
    if surface.GetType() == GeomAbs_Plane:
        return False

    if surface.IsUPeriodic() or surface.IsVPeriodic():
        return True

    wire_exp = TopExp_Explorer(occ_face, TopAbs_WIRE)
    while wire_exp.More():
        occ_wire = TopoDS.Wire_s(wire_exp.Current())
        we = BRepTools_WireExplorer(occ_wire, occ_face)
        while we.More():
            edge = we.Current()
            c3d = BRepAdaptor_Curve(edge)
            arc_length = GCPnts_AbscissaPoint.Length_s(c3d)
            if arc_length < 1e-10:
                return True
            p0 = c3d.Value(c3d.FirstParameter())
            p1 = c3d.Value(c3d.LastParameter())
            dist = (
                (p1.X() - p0.X()) ** 2
                + (p1.Y() - p0.Y()) ** 2
                + (p1.Z() - p0.Z()) ** 2
            ) ** 0.5
            if dist < 1e-6 and arc_length > 1e-6:
                return True
            we.Next()
        wire_exp.Next()
    return False


def _face_has_degenerate_edges(occ_face):
    """Check if a face has degenerate edges (zero arc length)."""
    return _count_degenerate_edges(occ_face) > 0


def _count_degenerate_edges(occ_face):
    """Count the number of degenerate edges (zero arc length) on a face.

    Returns 0, 1, or 2+.  Used to distinguish:
    - 2 degenerate edges: full sphere / ellipsoid (both poles) — MeshAdapt OK
    - 1 degenerate edge: hemisphere (one pole) — needs BRepMesh
    """
    count = 0
    wire_exp = TopExp_Explorer(occ_face, TopAbs_WIRE)
    while wire_exp.More():
        occ_wire = TopoDS.Wire_s(wire_exp.Current())
        we = BRepTools_WireExplorer(occ_wire, occ_face)
        while we.More():
            edge = we.Current()
            c3d = BRepAdaptor_Curve(edge)
            arc_length = GCPnts_AbscissaPoint.Length_s(c3d)
            if arc_length < 1e-10:
                count += 1
            we.Next()
        wire_exp.Next()
    return count


def _face_is_effectively_doubly_periodic(occ_face):
    """Check if a singly-periodic face is effectively doubly-periodic.

    A singly-periodic face is effectively doubly-periodic if the
    non-periodic direction has a closed profile — i.e., the endpoints
    map to the same 3D point.
    """
    surface = BRepAdaptor_Surface(occ_face)
    if not (surface.IsUPeriodic() or surface.IsVPeriodic()):
        return False
    if surface.IsUPeriodic() and surface.IsVPeriodic():
        return False

    u0 = surface.FirstUParameter()
    u1 = surface.LastUParameter()
    v0 = surface.FirstVParameter()
    v1 = surface.LastVParameter()
    um = (u0 + u1) * 0.5

    if surface.IsUPeriodic():
        p0 = surface.Value(um, v0)
        p1 = surface.Value(um, v1)
    else:
        vm = (v0 + v1) * 0.5
        p0 = surface.Value(u0, vm)
        p1 = surface.Value(u1, vm)

    dist = ((p1.X() - p0.X())**2 + (p1.Y() - p0.Y())**2 + (p1.Z() - p0.Z())**2)**0.5
    return dist < 1e-3


def _face_normal_outward(occ_face):
    """Determine if CCW-in-UV maps to outward normals in 3D.

    Returns True if CCW-in-UV triangles already point outward.
    """
    from OCP.gp import gp_Pnt, gp_Vec

    surface = BRepAdaptor_Surface(occ_face)
    umid = (surface.FirstUParameter() + surface.LastUParameter()) / 2
    vmid = (surface.FirstVParameter() + surface.LastVParameter()) / 2

    p = gp_Pnt()
    du = gp_Vec()
    dv = gp_Vec()
    surface.D1(umid, vmid, p, du, dv)

    reversed = occ_face.Orientation() == TopAbs_REVERSED
    return not reversed


def _fix_face_normals(vertices, triangles, occ_face):
    """Fix triangle winding for a single face using OCC's surface normal.

    Modifies *triangles* in-place.
    """
    if not triangles:
        return

    surface = BRepAdaptor_Surface(occ_face)

    tri = triangles[0]
    a = vertices[tri[0]]
    b = vertices[tri[1]]
    c = vertices[tri[2]]

    ab = [b[i] - a[i] for i in range(3)]
    ac = [c[i] - a[i] for i in range(3)]
    tri_normal = [
        ab[1] * ac[2] - ab[2] * ac[1],
        ab[2] * ac[0] - ab[0] * ac[2],
        ab[0] * ac[1] - ab[1] * ac[0],
    ]

    umid = (surface.FirstUParameter() + surface.LastUParameter()) / 2
    vmid = (surface.FirstVParameter() + surface.LastVParameter()) / 2

    from OCP.gp import gp_Pnt, gp_Vec
    p = gp_Pnt()
    du = gp_Vec()
    dv = gp_Vec()
    surface.D1(umid, vmid, p, du, dv)
    occ_normal = [
        du.Y() * dv.Z() - du.Z() * dv.Y(),
        du.Z() * dv.X() - du.X() * dv.Z(),
        du.X() * dv.Y() - du.Y() * dv.X(),
    ]

    dot = sum(tri_normal[i] * occ_normal[i] for i in range(3))
    if dot < 0:
        for t in triangles:
            t[0], t[1], t[2] = t[0], t[2], t[1]
