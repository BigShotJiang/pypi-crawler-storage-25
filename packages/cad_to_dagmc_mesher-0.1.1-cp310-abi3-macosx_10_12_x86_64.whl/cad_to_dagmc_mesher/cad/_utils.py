"""Thin wrappers around Rust utility functions.

These convert between Python dicts/lists and the Rust function signatures.
"""

from cad_to_dagmc_mesher import (
    bbox_diagonal as _bbox_diagonal_rust,
    collect_wire_uv as _collect_wire_uv_rust,
    fill_boundary_holes as _fill_boundary_holes_rust,
    fix_normals_bfs as _fix_normals_bfs_rust,
    merge_vertices as _merge_vertices_rust,
    merge_vertices_between_faces as _merge_vertices_between_faces_rust,
    merge_vertices_with_remap as _merge_vertices_with_remap_rust,
    remap_tris as _remap_tris_rust,
)


def _remap_tris(
    tris: list[list[int]],
    remap: dict[int, int] | list[int],
    dedup: bool = False,
) -> list[list[int]]:
    """Remap triangle indices, filtering degenerates."""
    remap_list = list(remap.values()) if isinstance(remap, dict) else list(remap)
    return [list(t) for t in _remap_tris_rust(tris, remap_list, dedup, False)]


def _remap_tris_flipped(
    tris: list[list[int]],
    remap: dict[int, int] | list[int],
    dedup: bool = False,
) -> list[list[int]]:
    """Remap with flipped winding, filtering degenerates."""
    remap_list = list(remap.values()) if isinstance(remap, dict) else list(remap)
    return [list(t) for t in _remap_tris_rust(tris, remap_list, dedup, True)]


def _bbox_diagonal(vertices: list[list[float]]) -> float:
    """Return the bounding-box diagonal length of a vertex list."""
    if not vertices:
        return 0.0
    return _bbox_diagonal_rust(vertices)


def _merge_vertices_with_remap(
    vertices: list[list[float]],
    tol: float | None = None,
) -> tuple[list[list[float]], dict[int, int]]:
    """Merge duplicate 3D vertices, return ``(new_vertices, remap)``."""
    if not vertices:
        return [], {}
    new_verts, remap_list = _merge_vertices_with_remap_rust(vertices, tol)
    new_verts = [list(v) for v in new_verts]
    old_to_new = {i: r for i, r in enumerate(remap_list)}
    return new_verts, old_to_new


def _merge_vertices_between_faces(
    vertices: list[list[float]],
    face_vert_ranges: dict,
    tol: float | None = None,
) -> tuple[list[list[float]], dict[int, int]]:
    """Merge vertices from DIFFERENT faces only (not within a face)."""
    if not vertices:
        return [], {}
    face_ranges = list(face_vert_ranges.values())
    new_verts, remap_list = _merge_vertices_between_faces_rust(vertices, face_ranges, tol)
    new_verts = [list(v) for v in new_verts]
    old_to_new = {i: r for i, r in enumerate(remap_list)}
    return new_verts, old_to_new


def _merge_vertices(
    vertices: list[list[float]],
    triangles: list[list[int]],
    tol: float | None = None,
) -> tuple[list[list[float]], list[list[int]]]:
    """Merge duplicate 3D vertices and remap triangle indices."""
    if not vertices:
        return [], []
    new_verts, new_tris = _merge_vertices_rust(vertices, triangles, tol)
    return [list(v) for v in new_verts], [list(t) for t in new_tris]


def _collect_wire_uv(edges: list) -> list[list[float]]:
    """Collect UV points from boundary edges, deduplicating shared endpoints."""
    edge_pts = [list(e.uv_points) for e in edges]
    rev_flags = [bool(e.reversed) for e in edges]
    return [list(uv) for uv in _collect_wire_uv_rust(edge_pts, rev_flags)]


def _fix_normals_bfs(
    vertices: list[list[float]],
    triangles_by_solid_by_face: dict[int, dict[int, list[list[int]]]],
) -> None:
    """Fix triangle winding using BFS edge propagation + signed volume.

    Modifies ``triangles_by_solid_by_face`` in place.
    """
    result = _fix_normals_bfs_rust(vertices, triangles_by_solid_by_face)
    for solid_id in triangles_by_solid_by_face:
        for fid in triangles_by_solid_by_face[solid_id]:
            triangles_by_solid_by_face[solid_id][fid] = [
                list(t) for t in result[solid_id][fid]
            ]
