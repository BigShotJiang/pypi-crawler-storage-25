"""Volume (tetrahedral) meshing pipeline for OCC solids.

Uses shared edge discretization to produce a watertight surface mesh,
then fills the interior with tets. The surface triangles (at target_edge_length)
are the authoritative boundary for DAGMC tracking.
"""

from cad_to_dagmc_mesher import VolumeInput, mesh_volume, mesh_faces_parallel, close_open_edges

from ._evaluate import _evaluate_face_3d
from ._extract import extract_face_inputs_for_volume
from ._utils import _fix_normals_bfs, _merge_vertices_with_remap, _remap_tris


def mesh_volume_from_solid(
    solid_shape,
    target_edge_length: float,
    material_tag: str = "volume",
) -> dict:
    """Tet-mesh an OCC solid directly.

    Each geometric edge is discretized once at ``target_edge_length``,
    shared between adjacent faces. CDT Fine mode refines face interiors.
    The resulting watertight surface is then filled with tets.

    Parameters
    ----------
    solid_shape
        A CadQuery Shape/Solid or raw OCC ``TopoDS_Shape``.
    target_edge_length : float
        Target edge length for both surface triangles and tets.
    material_tag : str
        Material name for this solid.

    Notes
    -----
    When multiple adjacent solids are tet-meshed, shared faces between
    them will have independent triangulations. A future enhancement will
    constrain the second solid's shared-face triangulation to match the
    first solid's boundary, ensuring conformity at the interface.

    Returns
    -------
    dict
        ``"vertices"`` — list of ``[x, y, z]`` (boundary + interior)
        ``"tetrahedra"`` — list of ``[v0, v1, v2, v3]``
        ``"boundary_triangles"`` — list of ``[v0, v1, v2]``
        ``"triangles_by_solid_by_face"`` — ``{1: {face_id: [[v0,v1,v2]...]}}``
        ``"boundary_face_ids"`` — list of int (CAD face ID per triangle)
        ``"material_tags"`` — ``[material_tag]``
    """
    # Step 1: Extract face inputs with shared edge discretization
    face_inputs, occ_faces = extract_face_inputs_for_volume(
        solid_shape, target_edge_length
    )

    # Step 2: CDT mesh all faces (Fine mode, shared boundary points)
    face_outputs = mesh_faces_parallel(face_inputs)

    # Step 3: Evaluate UV→3D and merge vertices
    all_verts = []
    face_tris = {}
    for fi, fo, of in zip(face_inputs, face_outputs, occ_faces):
        verts, tris = _evaluate_face_3d(fi, fo, of)
        offset = len(all_verts)
        all_verts.extend(verts)
        face_tris[fi.face_id] = [
            [t[0] + offset, t[1] + offset, t[2] + offset] for t in tris
        ]

    all_verts, remap = _merge_vertices_with_remap(all_verts)
    for fid in face_tris:
        face_tris[fid] = _remap_tris(face_tris[fid], remap)

    # Fix normals and close any remaining open edges
    tris_by_solid_by_face_raw = {1: face_tris}
    _fix_normals_bfs(all_verts, tris_by_solid_by_face_raw)
    all_flat = [t for ts in face_tris.values() for t in ts]
    closed = [list(t) for t in close_open_edges(all_verts, all_flat)]
    if len(closed) > len(all_flat):
        extra = closed[len(all_flat):]
        max_fid = max(face_tris.keys()) if face_tris else 0
        face_tris[max_fid + 1] = extra

    # Flatten surface triangles, tracking face IDs
    flat_tris = []
    boundary_face_ids = []
    for fid, fid_tris in face_tris.items():
        flat_tris.extend(fid_tris)
        boundary_face_ids.extend([fid] * len(fid_tris))

    # Step 4: Volume mesh (skip boundary recovery)
    inp = VolumeInput(
        boundary_vertices=all_verts,
        boundary_triangles=flat_tris,
        target_edge_length=target_edge_length,
        skip_boundary_recovery=True,
    )
    vol_out = mesh_volume(inp)

    # Step 5: Build combined result
    combined_verts = list(all_verts) + list(vol_out.interior_vertices)
    triangles_by_solid_by_face = {1: face_tris}

    return {
        "vertices": combined_verts,
        "tetrahedra": vol_out.tetrahedra,
        "boundary_triangles": flat_tris,
        "triangles_by_solid_by_face": triangles_by_solid_by_face,
        "boundary_face_ids": boundary_face_ids,
        "material_tags": [material_tag],
    }
