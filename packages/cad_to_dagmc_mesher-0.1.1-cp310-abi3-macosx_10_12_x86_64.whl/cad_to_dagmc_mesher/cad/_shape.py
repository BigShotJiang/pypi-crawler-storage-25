"""Single-shape meshing pipeline."""

from OCP.BRepAdaptor import BRepAdaptor_Surface
from OCP.BRepMesh import BRepMesh_IncrementalMesh
from OCP.BRepTools import BRepTools
from OCP.GeomAbs import GeomAbs_Plane
from OCP.TopAbs import TopAbs_REVERSED

from cad_to_dagmc_mesher import mesh_faces_parallel

from ._classify import (
    _count_degenerate_edges,
    _face_has_seam_edges,
    _face_is_effectively_doubly_periodic,
    _face_normal_outward,
)
from ._evaluate import _cleanup_non_manifold, _evaluate_face_3d, _stitch_periodic_uv_mesh
from ._extract import _extract_brep_mesh_face, _extract_face, extract_face_inputs
from ._meshadapt import _mesh_face_meshadapt
from ._optimize import _collapse_periodic_mesh_3d, _optimize_3d_mesh
from ._utils import _fix_normals_bfs, _merge_vertices_with_remap, _remap_tris


def mesh_shape(
    shape,
    material_tag: str,
    tolerance: float = 0.03,
    angular_tolerance: float = 0.4,
    mesher: str = "auto",
) -> dict:
    """Mesh a single shape and return ``vertices_to_h5m``-compatible output.

    Parameters
    ----------
    shape
        A CadQuery Shape/Solid or raw OCC ``TopoDS_Shape``.
    material_tag : str
        Material name for this solid.
    tolerance : float
        Chordal deflection tolerance.
    angular_tolerance : float
        Angular deflection tolerance.
    mesher : str
        ``"auto"`` (default), ``"meshadapt"``, or ``"brepmesh"``.

    Returns
    -------
    dict
        ``{"vertices", "triangles_by_solid_by_face", "material_tags"}``
    """
    occ_shape = getattr(shape, "wrapped", shape)
    face_inputs, occ_faces = extract_face_inputs(shape, tolerance, angular_tolerance)

    multi_face = len(occ_faces) > 1

    brep_face_indices = []
    meshadapt_face_indices = []
    cdt_face_indices = []
    periodic_face_ids = set()
    doubly_periodic_face_ids = set()
    for i, of in enumerate(occ_faces):
        surf = BRepAdaptor_Surface(of)
        doubly_periodic = surf.IsUPeriodic() and surf.IsVPeriodic()
        eff_doubly_periodic = _face_is_effectively_doubly_periodic(of)
        has_seam = _face_has_seam_edges(of)

        n_degen = _count_degenerate_edges(of)
        if n_degen > 0:
            if n_degen >= 2 and mesher in ("meshadapt", "auto"):
                meshadapt_face_indices.append(i)
            else:
                brep_face_indices.append(i)
        elif (doubly_periodic or eff_doubly_periodic) and has_seam:
            cdt_face_indices.append(i)
            periodic_face_ids.add(face_inputs[i].face_id)
            if doubly_periodic:
                doubly_periodic_face_ids.add(face_inputs[i].face_id)
        elif has_seam and multi_face:
            brep_face_indices.append(i)
        else:
            cdt_face_indices.append(i)

    all_verts = []
    face_tris_raw = {}
    need_bfs_normals = False

    # MeshAdapt path
    if meshadapt_face_indices:
        succeeded = []
        for idx in meshadapt_face_indices:
            fi, of = face_inputs[idx], occ_faces[idx]
            result = _mesh_face_meshadapt(of, tolerance, angular_tolerance)
            if result is not None:
                verts, tris = result
                offset = len(all_verts)
                all_verts.extend(verts)
                global_tris = [
                    [t[0] + offset, t[1] + offset, t[2] + offset] for t in tris
                ]
                face_tris_raw[fi.face_id] = global_tris
                succeeded.append(idx)
            elif mesher == "auto":
                brep_face_indices.append(idx)
            else:
                raise RuntimeError(
                    f"MeshAdapt failed on face {fi.face_id} and mesher='meshadapt' "
                    f"(no fallback)"
                )
        if succeeded:
            need_bfs_normals = True

    # BRepMesh path
    if brep_face_indices:
        from OCP.Bnd import Bnd_Box
        from OCP.BRepBndLib import BRepBndLib
        bbox = Bnd_Box()
        BRepBndLib.Add_s(occ_shape, bbox)
        xmin, ymin, zmin, xmax, ymax, zmax = bbox.Get()
        diag = ((xmax-xmin)**2 + (ymax-ymin)**2 + (zmax-zmin)**2) ** 0.5
        # Scale BRepMesh parameters from defaults
        _ang_scale = 0.4 / max(angular_tolerance, 1e-10)
        scaled_tol = max(tolerance, diag * 0.004 / _ang_scale)
        scaled_ang = 0.2 / _ang_scale

        BRepTools.Clean_s(occ_shape)
        BRepMesh_IncrementalMesh(occ_shape, scaled_tol, False, scaled_ang)

        brep_extract = set(brep_face_indices)
        for idx in list(cdt_face_indices):
            fid = face_inputs[idx].face_id
            if fid not in periodic_face_ids:
                brep_extract.add(idx)
                cdt_face_indices.remove(idx)

        for idx in sorted(brep_extract):
            fi, of = face_inputs[idx], occ_faces[idx]
            brep = _extract_brep_mesh_face(of)
            if brep is None:
                continue
            verts, tris = brep

            surf = BRepAdaptor_Surface(of)
            _did_fan = False
            if surf.GetType() == GeomAbs_Plane and len(tris) > 10:
                from collections import Counter as _Ctr
                _ec = _Ctr()
                for t in tris:
                    for k in range(3):
                        a, b = t[k], t[(k+1) % 3]
                        _ec[(min(a,b), max(a,b))] += 1
                bdy_edges = [(a,b) for (a,b), c in _ec.items() if c == 1]
                if bdy_edges:
                    adj = {}
                    for a, b in bdy_edges:
                        adj.setdefault(a, []).append(b)
                        adj.setdefault(b, []).append(a)
                    start = bdy_edges[0][0]
                    loop = [start]
                    visited = {start}
                    cur = start
                    while True:
                        nxt = None
                        for nb in adj.get(cur, []):
                            if nb not in visited:
                                nxt = nb
                                break
                        if nxt is None:
                            break
                        loop.append(nxt)
                        visited.add(nxt)
                        cur = nxt
                    if len(loop) >= 3 and len(loop) == len(bdy_edges):
                        tris = [[loop[0], loop[i], loop[i+1]]
                                for i in range(1, len(loop)-1)]
                        _did_fan = True
            if not _did_fan:
                # Collapse ratio: aggressive for non-seam flat faces,
                # conservative for seam faces, very conservative for
                # faces with degenerate edges (poles) to preserve
                # accuracy at high-curvature regions.
                _ndeg = _count_degenerate_edges(of)
                if _ndeg > 0:
                    _cr = 0.3   # pole faces: same as seam
                elif _face_has_seam_edges(of):
                    _cr = 0.3   # seam faces: conservative
                else:
                    _cr = 0.45  # plain faces: aggressive
                verts, tris = _optimize_3d_mesh(verts, tris, of, passes=3,
                                                tolerance=scaled_tol,
                                                angular_tolerance=scaled_ang,
                                                collapse_ratio=_cr)

            offset = len(all_verts)
            all_verts.extend(verts)
            face_tris_raw[fi.face_id] = [
                [t[0] + offset, t[1] + offset, t[2] + offset] for t in tris
            ]
        need_bfs_normals = True

    # CDT path
    if cdt_face_indices:
        cdt_inputs = [face_inputs[i] for i in cdt_face_indices]
        cdt_occ = [occ_faces[i] for i in cdt_face_indices]
        face_outputs = mesh_faces_parallel(cdt_inputs)
        for fi, fo, of in zip(cdt_inputs, face_outputs, cdt_occ):
            offset = len(all_verts)
            if fi.face_id in periodic_face_ids:
                truly_periodic = fi.face_id in doubly_periodic_face_ids
                verts, tris = _stitch_periodic_uv_mesh(
                    fi, fo, of, fill_holes=truly_periodic)
                # Use gentler collapse for effectively-periodic faces to
                # preserve enough triangles for accurate particle tracking
                cr = 0.48 if truly_periodic else 0.35
                verts, tris = _collapse_periodic_mesh_3d(
                    verts, tris, of, passes=3, collapse_ratio=cr,
                    tolerance=tolerance)
                verts, tris = _cleanup_non_manifold(verts, tris)
            else:
                verts, tris = _evaluate_face_3d(fi, fo, of)
            all_verts.extend(verts)
            global_tris = [[t[0] + offset, t[1] + offset, t[2] + offset] for t in tris]
            if not _face_normal_outward(of):
                for t in global_tris:
                    t[0], t[1], t[2] = t[0], t[2], t[1]
            face_tris_raw[fi.face_id] = global_tris

    all_verts, remap = _merge_vertices_with_remap(all_verts)
    triangles_by_solid_by_face = {1: {}}
    for fid, tris in face_tris_raw.items():
        remapped = _remap_tris(tris, remap)
        # Dedup: global vertex merge can create duplicate triangles
        seen = set()
        deduped = []
        for t in remapped:
            key = tuple(sorted(t))
            if key not in seen:
                seen.add(key)
                deduped.append(t)
        triangles_by_solid_by_face[1][fid] = deduped

    if need_bfs_normals:
        _fix_normals_bfs(all_verts, triangles_by_solid_by_face)

    # Close any remaining open edges (from inter-face boundary mismatches
    # after global vertex merge)
    from cad_to_dagmc_mesher import close_open_edges as _close_open_rust
    all_tris = [t for fid_tris in triangles_by_solid_by_face[1].values()
                for t in fid_tris]
    closed = [list(t) for t in _close_open_rust(all_verts, all_tris)]
    if len(closed) > len(all_tris):
        # Extra triangles were added — put them in a synthetic face
        extra = closed[len(all_tris):]
        max_fid = max(triangles_by_solid_by_face[1].keys()) if triangles_by_solid_by_face[1] else 0
        triangles_by_solid_by_face[1][max_fid + 1] = extra

    return {
        "vertices": all_verts,
        "triangles_by_solid_by_face": triangles_by_solid_by_face,
        "material_tags": [material_tag],
    }
