"""ServerConfig -- runtime configuration for the signet proxy.

A single dataclass that holds every dial the server exposes. Construct
explicitly or via :meth:`from_env` to populate from environment variables
matching the canonical ``SIGNET_*`` namespace.

Attributes are intentionally simple types (str, int, bool, Path) so
configs serialize cleanly to YAML / JSON for declarative deployment.
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path

#: Values treated as truthy by :func:`_parse_bool_env`. Compared
#: case-insensitively after stripping surrounding whitespace, so
#: ``"YES"``, ``" on "``, ``"Enabled"`` all match. The CHANGELOG
#: documents ``SIGNET_SHADOW=1`` as the supported on-switch; this set
#: codifies the same UX across every bool-flag env var so callers don't
#: need to memorize which knob accepts which spelling.
_TRUTHY_ENV_VALUES: frozenset[str] = frozenset(
    {"1", "true", "yes", "on", "enabled"}
)


def _parse_bool_env(value: str) -> bool:
    """Parse an environment-variable value into a bool.

    Accepts ``1``/``true``/``yes``/``on``/``enabled`` as truthy
    (case-insensitive, surrounding whitespace stripped). Anything else
    -- including the empty string and ``"0"``/``"false"``/``"no"`` --
    is falsy. Centralized so every bool-flag env var has identical
    parsing semantics; previously each call site spelled
    ``v.lower() == "true"`` inline, which silently rejected ``"1"``
    even though the CHANGELOG documents ``SIGNET_SHADOW=1`` as valid.
    """
    return value.strip().lower() in _TRUTHY_ENV_VALUES


def _parse_int_env(name: str, value: str) -> int:
    """Parse an int env var, re-raising with the var name on failure.

    Bare ``int(value)`` raises ``ValueError: invalid literal for int()
    with base 10: 'abc'`` which doesn't tell the operator *which*
    SIGNET_* variable was bad (L8). Wrap the conversion so the message
    names the variable.
    """
    try:
        return int(value)
    except ValueError as exc:
        raise ValueError(
            f"{name} must be an integer; got {value!r} ({exc})"
        ) from exc


def _parse_float_env(name: str, value: str) -> float:
    """Parse a float env var, re-raising with the var name on failure.

    Same rationale as :func:`_parse_int_env` (L8) but for float fields.
    """
    try:
        return float(value)
    except ValueError as exc:
        raise ValueError(
            f"{name} must be a number; got {value!r} ({exc})"
        ) from exc


def _parse_hex_env(name: str, value: str) -> bytes:
    """Parse a hex-encoded bytes env var, naming the var on failure.

    ``bytes.fromhex`` raises ``ValueError: non-hexadecimal number
    found...`` with no var-name context (L8). Wrap so misconfigurations
    of e.g. SIGNET_HMAC_SECRET are immediately attributable.
    """
    try:
        return bytes.fromhex(value)
    except ValueError as exc:
        raise ValueError(
            f"{name} must be hex-encoded bytes (e.g. `openssl rand -hex 32`); "
            f"got value of length {len(value)} ({exc})"
        ) from exc


@dataclass
class ServerConfig:
    """Runtime configuration for :class:`signet.server.app.SignetApp`.

    Attributes:
        upstream_url: Base URL of the upstream LLM service. Must speak
            OpenAI chat-completions wire format. Examples:
            ``"https://api.openai.com/v1"``,
            ``"http://localhost:11434/v1"`` (Ollama),
            ``"http://localhost:8000/v1"`` (vLLM).
        upstream_api_key: Bearer token forwarded to the upstream.
            ``None`` to forward the caller's own ``Authorization`` header.
        host: Bind interface for the proxy. Defaults to ``127.0.0.1`` --
            change to ``0.0.0.0`` for non-loopback exposure (after
            considering the trust model in
            :doc:`docs/architecture`).
        port: Bind port. Defaults to 8443.
        request_timeout_s: Max seconds to wait for an upstream response.
            Streaming requests use this for the connect phase only;
            stream-body timeouts are handled separately.
        audit_log_path: Where to write the HMAC-chained audit log. Set
            to ``None`` to disable persistent audit (in-memory only,
            test harnesses).
        hmac_key_id: Identifier for the active HMAC key. Embedded in
            audit entries and receipts so verifiers know which key to
            use across rotations.
        hmac_secret: Raw HMAC secret. Required when
            ``audit_log_path`` is set. Generated via
            :meth:`signet.audit.keyring.Key.generate` if absent and
            ``allow_ephemeral_key`` is ``True``.
        allow_ephemeral_key: If ``True`` and ``hmac_secret`` is missing,
            generate a fresh key on startup. Useful for dev; never
            enable in production where audits must verify across
            restarts.
        receipt_header_name: HTTP header carrying the per-response
            signed decision summary. Defaults to ``X-Signet-Receipt``.
        emit_receipts: Whether to emit receipts at all. Defaults to
            ``True``; set ``False`` only for debug or when downstream
            cannot handle the additional header.
    """

    upstream_url: str = "http://localhost:11434/v1"
    upstream_api_key: str | None = None
    host: str = "127.0.0.1"
    port: int = 8443
    request_timeout_s: float = 120.0
    audit_log_path: Path | None = None
    hmac_key_id: str = "k1"
    hmac_secret: bytes | None = None
    allow_ephemeral_key: bool = False
    receipt_header_name: str = "X-Signet-Receipt"
    emit_receipts: bool = True
    upstream_label: str | None = None
    """Optional label surfaced in the ``X-Signet-Upstream`` response
    header so callers can finger-point upstream errors vs. signet
    errors at a glance. ``None`` (default) means ``X-Signet-Upstream``
    carries the host portion of ``upstream_url``."""
    cors_allowed_origins: tuple[str, ...] = ()
    """Origins permitted via ``Access-Control-Allow-Origin``. Empty
    (default) disables CORS entirely. Use ``("*",)`` to allow all
    origins (dev only). For browser-based callers in production,
    list the exact origins. signet emits the matching CORS preflight
    + credentialed-response headers via Starlette's CORSMiddleware."""
    cors_allowed_methods: tuple[str, ...] = ("GET", "POST", "OPTIONS")
    """HTTP methods allowed for CORS. Override only if you proxy
    additional methods through an embedded SignetApp."""
    cors_allowed_headers: tuple[str, ...] = (
        "Authorization",
        "Content-Type",
        "X-Commit-Owner",
        "X-Agent-Id",
        "X-Policy-Name",
        "X-Policy-Version",
        "X-Classification",
        "X-Caller-Clearance",
        "X-Signet-Session",
    )
    """Request headers callers can send via CORS. The default set
    covers signet's own attribution + classification headers."""
    cors_allow_credentials: bool = False
    """Whether to set ``Access-Control-Allow-Credentials: true``.
    Required when callers send cookies or HTTP auth via CORS;
    incompatible with ``cors_allowed_origins=("*",)`` per the spec."""
    shutdown_grace_seconds: float = 10.0
    """On lifespan shutdown (SIGTERM, uvicorn graceful stop), wait up
    to this many seconds for in-flight streaming responses to finish
    before tearing down the upstream HTTP client. Streams that don't
    complete by the deadline are abandoned; their audit rows are
    still written by the streaming generator's finally block. Set 0
    to skip the grace period (production should keep this > 0)."""
    max_request_body_bytes: int = 4 * 1024 * 1024
    """Hard cap on inbound request body size. Anything larger gets a
    413 before signet attempts to parse it. Default 4 MiB covers
    typical chat-completion bodies (a few-thousand-message conversation
    fits easily) and refuses obvious DoS payloads. Raise if you have
    legitimate use of long contexts as raw text in the request body."""
    strict_error_redaction: bool = True
    """When True (default), 4xx refusal bodies are coarsened to
    ``{"error": "refused", "correlation_id": "<entry_id>"}`` so the
    public response does not name the firing check, its reason, or the
    rule that tripped. The full detail still lands in the audit chain
    and the ``X-Signet-Receipt`` header -- incident response correlates
    via the entry ID. Turn off (``--no-strict-error-redaction`` or set
    ``False``) only for development, debugging integration issues, or
    deployments behind a fully-trusted client. ``signet serve --dev``
    flips this off automatically."""
    shadow: bool = False
    """When True, ADMISSION + INSPECTION + COMMITMENT block and escalate
    decisions are converted to allow at the response layer; the audit
    chain still records the original decision (with metadata.shadow=True),
    the response carries X-Signet-Shadow-* headers describing the
    would-be refusal, and the signet_shadow_would_have_blocked_total
    counter increments. Operators pilot signet in shadow mode against
    production traffic to see what would be blocked before flipping
    enforcement on."""
    realtime_enabled: bool = True
    """Whether to register the ``/v1/realtime`` WebSocket route.
    Defaults to ``True`` -- the route is always registered and FastAPI
    does not pre-allocate handlers, so deployments that never receive
    realtime traffic incur no cost. Set ``False`` to skip route
    registration entirely; deployments that want a hard guarantee
    against an opened WebSocket can flip this off. The HTTP routes
    are unaffected either way. When disabled, the route is still
    registered as a stub that immediately closes any incoming
    connection with code 1011 + reason ``"realtime endpoint disabled
    in config"`` so operators can distinguish "endpoint disabled" from
    "endpoint never registered" / network errors (R3)."""
    inspect_all_sse_lines: bool = False
    """Opt-in: feed ``event:``, ``id:``, ``retry:``, and ``:`` (comment)
    lines from upstream SSE frames into INSPECTION's accumulated text
    (S6). The SSE spec lets non-``data:`` lines smuggle text past
    classification scanners that only look at ``data:`` payloads --
    e.g. ``event: foo\\ndata: bar\\n\\n`` could carry a classification
    marker on the ``event:`` line that ScopeDriftCheck never sees.
    Default ``False`` preserves 0.1.6 behavior. Set ``True`` to harden
    against this side-channel; the tradeoff is slightly higher
    false-positive rate on legitimate event/id metadata that may
    coincide with sensitive substrings."""

    # Forwarded fields the user can tune via env-var: see _ENV_KEYS below.
    extra_forward_headers: tuple[str, ...] = field(
        default_factory=lambda: ("Authorization", "OpenAI-Beta", "OpenAI-Organization")
    )
    """Headers from the inbound request that are forwarded to the
    upstream verbatim. Owner-resolution and classification headers are
    consumed by signet itself and are NOT forwarded by default."""

    @classmethod
    def from_env(cls, env: dict[str, str] | None = None) -> ServerConfig:
        """Construct a config populated from environment variables.

        Recognized variables (all prefixed ``SIGNET_``). The list below
        matches the implementation 1:1 -- every variable parsed here is
        documented; nothing is silently swallowed. See the dataclass
        attribute docstrings for the meaning of each field.

        * ``SIGNET_UPSTREAM_URL`` → ``upstream_url`` (str)
        * ``SIGNET_UPSTREAM_API_KEY`` → ``upstream_api_key`` (str)
        * ``SIGNET_UPSTREAM_LABEL`` → ``upstream_label`` (str)
        * ``SIGNET_HOST`` → ``host`` (str)
        * ``SIGNET_PORT`` → ``port`` (int)
        * ``SIGNET_REQUEST_TIMEOUT_S`` → ``request_timeout_s`` (float)
        * ``SIGNET_AUDIT_LOG_PATH`` → ``audit_log_path`` (Path)
        * ``SIGNET_HMAC_KEY_ID`` → ``hmac_key_id`` (str)
        * ``SIGNET_HMAC_SECRET`` → ``hmac_secret`` (hex-encoded bytes;
          e.g. ``openssl rand -hex 32``)
        * ``SIGNET_ALLOW_EPHEMERAL_KEY`` → ``allow_ephemeral_key``
          (bool; see :func:`_parse_bool_env` for accepted spellings)
        * ``SIGNET_RECEIPT_HEADER_NAME`` → ``receipt_header_name`` (str)
        * ``SIGNET_EMIT_RECEIPTS`` → ``emit_receipts`` (bool)
        * ``SIGNET_MAX_REQUEST_BODY_BYTES`` → ``max_request_body_bytes``
          (int)
        * ``SIGNET_STRICT_ERROR_REDACTION`` → ``strict_error_redaction``
          (bool)
        * ``SIGNET_SHADOW`` → ``shadow`` (bool)
        * ``SIGNET_INSPECT_ALL_SSE_LINES`` → ``inspect_all_sse_lines``
          (bool; opt-in to feed non-``data:`` SSE lines into INSPECTION
          per S6)

        CLI-only env vars (NOT parsed here, deliberately):

        * ``SIGNET_LOG_FORMAT`` -- drives JSON-vs-text log formatting at
          process start in ``signet serve``. It configures the root
          logger before a ServerConfig is built, so it is not a
          ``ServerConfig`` field. Read it from your launcher; do not
          expect setting it here to take effect.
        * ``SIGNET_ANONYMIZE_SALT`` -- used by ``signet audit report``
          to salt owner pseudonymization. The audit-report CLI is a
          read-only tool that never instantiates ServerConfig, so this
          var is consumed at the CLI surface, not here.

        Both CLI-only vars are ignored by :meth:`from_env`. Promoting
        either to a ServerConfig field is roadmap (would require
        threading them through to the consuming surfaces); for now,
        document them in the deployment guide rather than silently
        drop them on a ServerConfig-shaped configuration. Variables
        not set fall back to dataclass defaults.

        Raises:
            ValueError: If a value present in ``env`` cannot be parsed
                into the field's type. Errors include the offending env
                var name so misconfigurations are easy to locate (L8).
        """
        e = env if env is not None else dict(os.environ)
        cfg = cls()

        if v := e.get("SIGNET_UPSTREAM_URL"):
            cfg.upstream_url = v
        if v := e.get("SIGNET_UPSTREAM_API_KEY"):
            cfg.upstream_api_key = v
        if v := e.get("SIGNET_HOST"):
            cfg.host = v
        if v := e.get("SIGNET_PORT"):
            cfg.port = _parse_int_env("SIGNET_PORT", v)
        if v := e.get("SIGNET_REQUEST_TIMEOUT_S"):
            cfg.request_timeout_s = _parse_float_env("SIGNET_REQUEST_TIMEOUT_S", v)
        if v := e.get("SIGNET_AUDIT_LOG_PATH"):
            cfg.audit_log_path = Path(v)
        if v := e.get("SIGNET_HMAC_KEY_ID"):
            cfg.hmac_key_id = v
        if v := e.get("SIGNET_HMAC_SECRET"):
            cfg.hmac_secret = _parse_hex_env("SIGNET_HMAC_SECRET", v)
        if v := e.get("SIGNET_ALLOW_EPHEMERAL_KEY"):
            cfg.allow_ephemeral_key = _parse_bool_env(v)
        if v := e.get("SIGNET_RECEIPT_HEADER_NAME"):
            cfg.receipt_header_name = v
        if v := e.get("SIGNET_EMIT_RECEIPTS"):
            cfg.emit_receipts = _parse_bool_env(v)
        if v := e.get("SIGNET_MAX_REQUEST_BODY_BYTES"):
            cfg.max_request_body_bytes = _parse_int_env(
                "SIGNET_MAX_REQUEST_BODY_BYTES", v
            )
        if v := e.get("SIGNET_UPSTREAM_LABEL"):
            cfg.upstream_label = v
        if v := e.get("SIGNET_STRICT_ERROR_REDACTION"):
            cfg.strict_error_redaction = _parse_bool_env(v)
        if v := e.get("SIGNET_SHADOW"):
            cfg.shadow = _parse_bool_env(v)
        if v := e.get("SIGNET_INSPECT_ALL_SSE_LINES"):
            cfg.inspect_all_sse_lines = _parse_bool_env(v)

        return cfg
