"""Pre-download PaddleOCR model files without initializing the engine.

PaddleOCR lazily downloads model files on first ``PaddleOCR()`` init.
This module downloads them directly so that:

1. The ``peekaboowin-setup`` command can pre-download models at install
   time without the 30-second init timeout.
2. Users on slow networks can download models separately before running
   the MCP server.

Model files are stored under ``~/.paddleocr/`` (or the platform equivalent).
PaddleOCR's ``maybe_download()`` simply checks for the presence of
``inference.pdiparams`` and ``inference.pdmodel`` — if they exist, it
skips the download.
"""

from __future__ import annotations

import os
import sys
import tarfile
import tempfile
import urllib.request
from pathlib import Path

import structlog

logger = structlog.get_logger(__name__)

# ---------------------------------------------------------------------------
# PaddleOCR model URLs (Chinese + English, v4)
# Source: paddleocr/ppocr/utils/network.py — maybe_download()
# ---------------------------------------------------------------------------

_BASE_URL = "https://paddleocr.bj.bcebos.com"
_RELEASE_BASE_URL = "https://github.com/wangneal/PeekabooWin/releases/download/ocr-models"
_MIRROR_BASE_URL_ENV = "PEEKABOOWIN_OCR_MODEL_BASE_URL"

# Model definitions: (subdir_name, url_paths)
# subdir_name = the directory PaddleOCR expects under ~/.paddleocr/
_MODELS: list[tuple[str, tuple[str, ...]]] = [
    # Detection model
    (
        "det/ch/ch_PP-OCRv4_det_infer",
        (
            f"{_RELEASE_BASE_URL}/ch_PP-OCRv4_det_infer.tar",
            f"{_BASE_URL}/PP-OCRv4/chinese/ch_PP-OCRv4_det_infer.tar",
        ),
    ),
    # Recognition model
    (
        "rec/ch/ch_PP-OCRv4_rec_infer",
        (
            f"{_RELEASE_BASE_URL}/ch_PP-OCRv4_rec_infer.tar",
            f"{_BASE_URL}/PP-OCRv4/chinese/ch_PP-OCRv4_rec_infer.tar",
        ),
    ),
    # Classification model (angle)
    (
        "cls/ch_ppocr_mobile_v2.0_cls_infer",
        (
            f"{_RELEASE_BASE_URL}/ch_ppocr_mobile_v2.0_cls_infer.tar",
            f"{_BASE_URL}/dygraph_v2.0/ch/ch_ppocr_mobile_v2.0_cls_infer.tar",
        ),
    ),
]


def get_paddleocr_model_dir() -> Path:
    """Return the PaddleOCR model root directory (``~/.paddleocr/``)."""
    return Path.home() / ".paddleocr"


def is_model_downloaded(model_subdir: str) -> bool:
    """Check if a specific model is already downloaded.

    PaddleOCR's ``maybe_download()`` checks for these two files.
    """
    model_dir = get_paddleocr_model_dir() / model_subdir
    params = model_dir / "inference.pdiparams"
    model = model_dir / "inference.pdmodel"
    return params.exists() and model.exists()


def all_models_ready() -> bool:
    """Return ``True`` if all required OCR models are present."""
    return all(is_model_downloaded(subdir) for subdir, _ in _MODELS)


def get_model_dirs() -> dict[str, str]:
    """Return PaddleOCR init arguments for the pre-downloaded model paths."""
    root = get_paddleocr_model_dir()
    return {
        "det_model_dir": str(root / _MODELS[0][0]),
        "rec_model_dir": str(root / _MODELS[1][0]),
        "cls_model_dir": str(root / _MODELS[2][0]),
    }


def _model_urls(urls: tuple[str, ...]) -> tuple[str, ...]:
    mirror_base_url = os.environ.get(_MIRROR_BASE_URL_ENV, "").strip().rstrip("/")
    if not mirror_base_url:
        return urls
    mirror_urls = tuple(f"{mirror_base_url}/{Path(url).name}" for url in urls)
    return mirror_urls + urls


def _is_within_directory(parent: Path, child: Path) -> bool:
    try:
        return os.path.commonpath([str(parent), str(child)]) == str(parent)
    except ValueError:
        return False


def _safe_extract_tar(tar: tarfile.TarFile, target_parent: Path) -> None:
    """Extract a tar archive without allowing path traversal or links."""
    resolved_parent = target_parent.resolve()
    for member in tar.getmembers():
        member_path = Path(member.name)
        if member_path.is_absolute() or member.issym() or member.islnk():
            raise RuntimeError(f"Unsafe tar member: {member.name}")
        destination = (resolved_parent / member.name).resolve()
        if not _is_within_directory(resolved_parent, destination):
            raise RuntimeError(f"Unsafe tar member: {member.name}")

    tar.extractall(path=str(resolved_parent))


def download_model(
    model_subdir: str,
    urls: str | tuple[str, ...],
    *,
    progress: bool = True,
) -> Path:
    """Download and extract a single PaddleOCR model.

    Args:
        model_subdir: Relative path under ``~/.paddleocr/``.
        urls: Download URL(s) for the model tar archive.
        progress: Print progress to stderr.

    Returns:
        The directory where the model was extracted.
    """
    target_dir = get_paddleocr_model_dir() / model_subdir

    if is_model_downloaded(model_subdir):
        if progress:
            print(f"  ✓ {model_subdir} (already downloaded)", file=sys.stderr)
        return target_dir

    if progress:
        print(f"  ↓ {model_subdir} ...", file=sys.stderr)

    target_dir.mkdir(parents=True, exist_ok=True)

    candidate_urls = (urls,) if isinstance(urls, str) else urls
    errors: list[str] = []

    for url in _model_urls(candidate_urls):
        if progress:
            print(f"    source: {url}", file=sys.stderr)
        try:
            with tempfile.NamedTemporaryFile(suffix=".tar", delete=False) as tmp:
                tmp_path = tmp.name
            try:
                urllib.request.urlretrieve(url, tmp_path)
                # Extract — tar contains a directory with the model files
                with tarfile.open(tmp_path, "r") as tar:
                    _safe_extract_tar(tar, target_dir.parent)
                if progress:
                    print(f"  ✓ {model_subdir}", file=sys.stderr)
                return target_dir
            finally:
                # Clean up temp file
                try:
                    os.unlink(tmp_path)
                except OSError:
                    pass
        except Exception as e:
            errors.append(f"{url}: {e}")
            logger.warning("model_download_failed", subdir=model_subdir, url=url, error=str(e))
            if progress:
                print(f"    failed: {e}", file=sys.stderr)

    message = "; ".join(errors)
    if progress:
        print(f"  ✗ {model_subdir}: {message}", file=sys.stderr)
    raise RuntimeError(message)

    return target_dir


def download_all_models(
    *,
    progress: bool = True,
) -> dict[str, str]:
    """Download all required PaddleOCR models.

    Returns:
        A dict mapping ``model_subdir`` → status (``"ok"`` / ``"skipped"`` / error message).
    """
    if progress:
        print("Downloading PaddleOCR models...", file=sys.stderr)

    results: dict[str, str] = {}
    for subdir, url in _MODELS:
        try:
            if is_model_downloaded(subdir):
                results[subdir] = "skipped"
                if progress:
                    print(f"  ✓ {subdir} (already downloaded)", file=sys.stderr)
            else:
                download_model(subdir, url, progress=progress)
                results[subdir] = "ok"
        except Exception as e:
            results[subdir] = str(e)

    ok_count = sum(1 for v in results.values() if v in ("ok", "skipped"))
    total = len(results)
    if progress:
        if ok_count == total:
            print(f"\nAll {total} models ready ✓", file=sys.stderr)
        else:
            failed = total - ok_count
            print(f"\n{ok_count}/{total} models ready, {failed} failed ✗", file=sys.stderr)

    return results
