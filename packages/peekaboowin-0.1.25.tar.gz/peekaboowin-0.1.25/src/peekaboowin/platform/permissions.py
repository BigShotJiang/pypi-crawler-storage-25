"""Permission checking and DPI awareness helpers."""

import ctypes
from ctypes import wintypes
from typing import Optional

import structlog

from peekaboowin.errors import PlatformError

logger = structlog.get_logger(__name__)


def enable_dpi_awareness() -> bool:
    """Enable per-monitor DPI awareness for the current process.

    Attempts DPI_AWARENESS_CONTEXT_PER_MONITOR_AWARE_V2 first,
    then falls back to DPI_AWARENESS_CONTEXT_PER_MONITOR_AWARE,
    then PROCESS_PER_MONITOR_DPI_AWARE.

    Returns:
        True if DPI awareness was enabled successfully.
    """
    try:
        # Try Per-Monitor V2 (Windows 10 Creators Update+)
        dpi_awareness_context = ctypes.c_int(-4)  # DPI_AWARENESS_CONTEXT_PER_MONITOR_AWARE_V2
        result = ctypes.windll.user32.SetProcessDpiAwarenessContext(dpi_awareness_context)
        if result:
            logger.info("dpi_awareness_set_per_monitor_v2")
            return True
    except Exception:
        pass

    try:
        # Fallback to Per-Monitor (Windows 8.1+)
        awareness = ctypes.c_int(2)  # PROCESS_PER_MONITOR_DPI_AWARE
        result = ctypes.windll.shcore.SetProcessDpiAwareness(awareness)
        if result == 0:
            logger.info("dpi_awareness_set_per_monitor")
            return True
    except Exception:
        pass

    logger.warning("dpi_awareness_failed_to_set")
    return False


def get_dpi_aware() -> bool:
    """Check if current process is DPI-aware."""
    try:
        result = ctypes.windll.user32.IsProcessDPIAware()
        if result:
            return True
        awareness = ctypes.c_int()
        success = ctypes.windll.shcore.GetProcessDpiAwareness(None, ctypes.byref(awareness))
        return success == 0 and awareness.value >= 1
    except Exception:
        return False


def check_elevation() -> bool:
    """Check if current process is running with elevated privileges.

    Returns:
        True if running as administrator.
    """
    try:
        return bool(ctypes.windll.shell32.IsUserAnAdmin())
    except Exception:
        return False


def is_elevated_window(hwnd: int) -> bool:
    """Check if a window belongs to an elevated process."""
    try:
        process_id = wintypes.DWORD()
        ctypes.windll.user32.GetWindowThreadProcessId(hwnd, ctypes.byref(process_id))

        process_handle = ctypes.windll.kernel32.OpenProcess(0x0400 | 0x0010, False, process_id.value)
        if not process_handle:
            return False

        try:
            token_handle = wintypes.HANDLE()
            if not ctypes.windll.kernel32.OpenProcessToken(process_handle, 0x0008, ctypes.byref(token_handle)):
                return False

            try:
                elevation = ctypes.c_int()
                size = ctypes.c_ulong(4)
                ctypes.windll.advapi32.GetTokenInformation(token_handle, 20, ctypes.byref(elevation), size, ctypes.byref(size))
                return elevation.value != 0
            finally:
                ctypes.windll.kernel32.CloseHandle(token_handle)
        finally:
            ctypes.windll.kernel32.CloseHandle(process_handle)
    except Exception:
        return False


def can_send_input_to(hwnd: int) -> bool:
    """Check if input can be sent to the specified window handle.

    Checks for UIPI (User Interface Privilege Isolation) restrictions.
    """
    try:
        process_id = wintypes.DWORD()
        thread_id = ctypes.windll.user32.GetWindowThreadProcessId(hwnd, ctypes.byref(process_id))
        if thread_id == 0:
            logger.warning("cannot_get_window_thread", hwnd=hwnd)
            return False

        PROCESS_QUERY_INFORMATION = 0x0400
        process_handle = ctypes.windll.kernel32.OpenProcess(PROCESS_QUERY_INFORMATION, False, process_id.value)
        if not process_handle:
            logger.warning("cannot_open_target_process", process_id=process_id.value)
            return False

        target_process_handle = wintypes.HANDLE()
        opened = ctypes.windll.kernel32.OpenProcessToken(process_handle, 0x0002, ctypes.byref(target_process_handle))
        if not opened:
            ctypes.windll.kernel32.CloseHandle(process_handle)
            logger.warning("cannot_open_target_process_token", process_id=process_id.value)
            return False

        try:
            # 查询目标进程的提升状态
            TokenElevation = 20
            elevation = ctypes.c_int()
            size = ctypes.c_ulong(4)
            result = ctypes.windll.advapi32.GetTokenInformation(
                target_process_handle, TokenElevation,
                ctypes.byref(elevation), size, ctypes.byref(size)
            )
            target_elevated = bool(result and elevation.value != 0)

            # 如果目标已提升，而自己没有提升，则不能发送输入
            if target_elevated and not check_elevation():
                logger.warning("target_window_elevated", hwnd=hwnd)
                return False

            return True
        finally:
            ctypes.windll.kernel32.CloseHandle(target_process_handle)
            ctypes.windll.kernel32.CloseHandle(process_handle)

    except Exception as e:
        logger.warning("failed_to_check_uipi", hwnd=hwnd, error=str(e))
        return False
