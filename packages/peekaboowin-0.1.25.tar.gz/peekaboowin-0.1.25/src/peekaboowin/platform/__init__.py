"""Platform layer - Windows API wrappers for PeekabooWin."""
