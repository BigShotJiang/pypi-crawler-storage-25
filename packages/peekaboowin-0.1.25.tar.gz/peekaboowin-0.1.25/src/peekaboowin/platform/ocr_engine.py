"""OCR engine abstraction layer with timeout protection and async initialization."""

from __future__ import annotations

import concurrent.futures
import inspect
import threading
from typing import TYPE_CHECKING, Any

import structlog

if TYPE_CHECKING:
    from PIL import Image

logger = structlog.get_logger(__name__)

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

_OCR_RECOGNIZE_TIMEOUT = 30  # seconds — OCR inference timeout

# PaddleOCR 2.x → 3.x parameter name mapping
# Source: paddleocr/_pipelines/ocr.py _DEPRECATED_PARAM_NAME_MAPPING
_V2_TO_V3_PARAM_MAP: dict[str, str] = {
    "det_model_dir": "text_detection_model_dir",
    "rec_model_dir": "text_recognition_model_dir",
    "cls_model_dir": "textline_orientation_model_dir",
    "use_angle_cls": "use_textline_orientation",
    "rec_batch_num": "text_recognition_batch_size",
    "cls_batch_num": "textline_orientation_batch_size",
}


def _get_paddleocr_version() -> tuple[int, int, int]:
    """Return PaddleOCR version as (major, minor, patch) tuple.

    Returns (0, 0, 0) if version cannot be determined (treat as 2.x).
    """
    try:
        import paddleocr  # type: ignore[import-untyped]

        ver_str = getattr(paddleocr, "__version__", "0.0.0")
        parts = ver_str.split(".")[:3]
        return tuple(int(p) for p in parts)  # type: ignore[return-value]
    except Exception:
        return (0, 0, 0)


def _check_paddle_version_compat(paddleocr_major: int) -> None:
    """Raise RuntimeError if PaddlePaddle version is incompatible.

    PaddleOCR 3.x requires PaddlePaddle >= 3.0.
    PaddleOCR 2.x requires PaddlePaddle >= 2.6, < 3.0.
    """
    try:
        import paddle  # type: ignore[import-untyped]

        pp_ver = getattr(paddle, "__version__", "0.0.0")
        pp_major = int(pp_ver.split(".")[0])
    except ImportError:
        # paddlepaddle not installed — let PaddleOCR's own import error surface
        return

    if paddleocr_major >= 3 and pp_major < 3:
        raise RuntimeError(
            f"PaddleOCR 3.x requires PaddlePaddle >= 3.0, "
            f"but PaddlePaddle {pp_ver} is installed. "
            f"This causes the 'set_optimization_level' AttributeError.\n"
            f"Fix: install compatible versions:\n"
            f"  uv tool install --python 3.12 git+https://github.com/wangneal/PeekabooWin "
            f"--upgrade --force \\\n"
            f'    --with "paddleocr>=2.8,<3.0" '
            f'--with "paddlepaddle>=2.6,<3.0"\n'
            f"  OR upgrade PaddlePaddle:\n"
            f'    --with "paddleocr>=3.0" '
            f'--with "paddlepaddle>=3.0"\n'
            f"Then run: peekaboowin-setup"
        )

    if paddleocr_major < 3 and pp_major >= 3:
        logger.warning(
            "paddle_version_mismatch",
            msg="PaddleOCR 2.x with PaddlePaddle 3.x — may work but untested",
        )


class OCREngine:
    """PaddleOCR wrapper with async initialization and inference timeout.

    Supports both PaddleOCR 2.x and 3.x with automatic version detection
    and parameter name mapping.
    """

    def __init__(self) -> None:
        self._engine: Any = None
        self._init_error: str | None = None
        self._initializing: bool = False
        self._init_event: threading.Event = threading.Event()
        self._engine_lock = threading.Lock()
        self._recognize_lock = threading.Lock()
        self._recognize_executor: concurrent.futures.ThreadPoolExecutor | None = None
        self._recognize_timed_out: bool = False
        self._paddleocr_major: int = 0  # set during init

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def start_init(self) -> None:
        """Start background initialization (non-blocking).

        Safe to call multiple times — subsequent calls are no-ops if
        initialization is already in progress or completed.
        """
        with self._engine_lock:
            if self._engine is not None or self._initializing:
                return
            self._initializing = True
            self._init_event.clear()
            threading.Thread(target=self._init_in_background, daemon=True).start()

    def wait_init(self, timeout: float | None = None) -> bool:
        """Block until initialization finishes.

        Args:
            timeout: Maximum seconds to wait. ``None`` means wait forever
                     (suitable for the ``setup`` command where the user is
                     watching the terminal).

        Returns:
            ``True`` if initialization succeeded, ``False`` on timeout or
             failure.  On failure the error message is available via
             :pyattr:`init_error`.
        """
        # If init hasn't been started yet, start it now (sync path).
        self.start_init()
        ok = self._init_event.wait(timeout=timeout)
        if not ok:
            return False  # timed out
        return self._engine is not None

    @property
    def init_error(self) -> str | None:
        """Return the initialization error message, if any."""
        return self._init_error

    @property
    def is_ready(self) -> bool:
        """Return ``True`` if the engine is initialized and ready to use."""
        return self._engine is not None

    @property
    def is_initializing(self) -> bool:
        """Return ``True`` if the engine is currently being initialized."""
        return self._initializing

    # ------------------------------------------------------------------
    # Core recognition
    # ------------------------------------------------------------------

    def recognize(self, image: Image.Image, lang: str = "ch") -> list[dict[str, Any]]:
        """Run OCR on *image* with inference timeout protection.

        Raises:
            RuntimeError: If the engine is not ready, is still initializing,
                          or inference times out.
        """
        engine = self._require_engine()
        img_array = self._pil_to_numpy(image)

        if self._recognize_timed_out:
            raise RuntimeError(
                "Previous OCR inference is still running after timeout; "
                "please retry later"
            )

        # PaddleOCR is not guaranteed to be thread-safe. Serialize inference
        # and reuse one worker so repeated timeouts don't create unbounded
        # abandoned threads. If a worker times out, no new worker is created
        # until that original call actually finishes.
        if not self._recognize_lock.acquire(blocking=False):
            raise RuntimeError("OCR engine is busy, please retry later")

        executor = self._get_recognize_executor()

        # PaddleOCR 3.x uses predict(), 2.x uses ocr()
        if self._paddleocr_major >= 3:
            future = executor.submit(engine.predict, img_array)
        else:
            future = executor.submit(engine.ocr, img_array, cls=True)

        try:
            result = future.result(timeout=_OCR_RECOGNIZE_TIMEOUT)
        except concurrent.futures.TimeoutError:
            logger.warning(
                "ocr_recognize_timeout", timeout=_OCR_RECOGNIZE_TIMEOUT
            )
            future.cancel()
            with self._engine_lock:
                self._recognize_timed_out = True
            future.add_done_callback(self._clear_recognize_timeout)
            raise RuntimeError(
                f"OCR inference timed out (> {_OCR_RECOGNIZE_TIMEOUT}s). "
                "Image may be too large or CPU too slow."
            ) from None
        finally:
            self._recognize_lock.release()

        return self._parse_result(result)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _require_engine(self) -> Any:
        """Return the PaddleOCR engine or raise ``RuntimeError``."""
        with self._engine_lock:
            if self._engine is not None:
                return self._engine
            if self._init_error:
                raise RuntimeError(
                    f"OCR engine initialization failed: {self._init_error}"
                )
            if self._initializing:
                raise RuntimeError(
                    "OCR engine is initializing, please retry later"
                )

        # Engine not started at all — trigger init and tell caller to retry
        self.start_init()
        raise RuntimeError("OCR engine is initializing, please retry later")

    def _model_dirs_or_error(self) -> dict[str, Any]:
        from peekaboowin.platform.ocr_model_downloader import (
            all_models_ready,
            get_model_dirs,
        )

        if not all_models_ready():
            raise RuntimeError(
                "OCR models are not downloaded. Run `peekaboowin-setup` first, "
                "or reinstall with OCR support."
            )
        return get_model_dirs()

    def _build_ocr_kwargs(self, paddleocr_major: int) -> dict[str, Any]:
        """Build PaddleOCR constructor kwargs based on detected version."""
        model_dirs = self._model_dirs_or_error()

        if paddleocr_major >= 3:
            # PaddleOCR 3.x: map old param names to new ones
            v3_kwargs: dict[str, Any] = {"lang": "ch"}
            for v2_key, v3_key in _V2_TO_V3_PARAM_MAP.items():
                if v2_key in model_dirs:
                    v3_kwargs[v3_key] = model_dirs[v2_key]
            # 3.x renamed use_angle_cls → use_textline_orientation
            v3_kwargs["use_textline_orientation"] = True
            return v3_kwargs
        else:
            # PaddleOCR 2.x: use original param names
            v2_kwargs: dict[str, Any] = {
                "use_angle_cls": True,
                "lang": "ch",
                **model_dirs,
            }
            # PaddleOCR 2.7+ removed show_log; only pass it if accepted
            from paddleocr import PaddleOCR  # type: ignore[import-untyped]

            sig = inspect.signature(PaddleOCR.__init__)
            if "show_log" in sig.parameters:
                v2_kwargs["show_log"] = False
            return v2_kwargs

    def _init_in_background(self) -> None:
        """Background thread: initialize PaddleOCR without timeout.

        Model downloading can take a long time on slow networks — we don't
        want to block MCP requests while waiting.
        """
        try:
            import paddleocr  # type: ignore[import-untyped]
            from paddleocr import PaddleOCR  # type: ignore[import-untyped]

            # --- PaddleOCR version detection ---
            ver = _get_paddleocr_version()
            paddleocr_major = ver[0]
            self._paddleocr_major = paddleocr_major

            logger.info(
                "paddleocr_version_detected",
                version=f"{ver[0]}.{ver[1]}.{ver[2]}",
                major=paddleocr_major,
            )

            # Check PaddlePaddle compatibility before attempting init
            _check_paddle_version_compat(paddleocr_major)

            # Build constructor kwargs for detected version
            ocr_kwargs = self._build_ocr_kwargs(paddleocr_major)

            logger.info("paddleocr_init_start", major=paddleocr_major, kwargs=list(ocr_kwargs.keys()))
            engine = PaddleOCR(**ocr_kwargs)

            with self._engine_lock:
                self._engine = engine
                self._initializing = False
            logger.info("paddleocr_initialized", major=paddleocr_major)

        except Exception as exc:
            # Special handling: if the error is set_optimization_level,
            # provide a more actionable message
            err_msg = str(exc)
            if "set_optimization_level" in err_msg:
                err_msg = (
                    "PaddleOCR / PaddlePaddle version mismatch: "
                    "'set_optimization_level' AttributeError means PaddlePaddle 2.x "
                    "is installed but PaddleOCR 3.x requires PaddlePaddle 3.x.\n"
                    "Fix: install compatible versions:\n"
                    "  uv tool install --python 3.12 git+https://github.com/wangneal/PeekabooWin "
       "--upgrade --force \\\n"
                    '    --with "paddleocr>=2.8,<3.0" '
                    '--with "paddlepaddle>=2.6,<3.0"\n'
                    "  Then run: peekaboowin-setup"
                )
            with self._engine_lock:
                self._init_error = err_msg
                self._initializing = False
            logger.warning("paddleocr_init_failed", error=err_msg)

        finally:
            self._init_event.set()

    def _get_recognize_executor(self) -> concurrent.futures.ThreadPoolExecutor:
        """Return the single OCR inference executor."""
        with self._engine_lock:
            if self._recognize_executor is None:
                self._recognize_executor = concurrent.futures.ThreadPoolExecutor(
                    max_workers=1,
                    thread_name_prefix="peekaboowin-ocr",
                )
            return self._recognize_executor

    def _clear_recognize_timeout(self, future: concurrent.futures.Future[Any]) -> None:
        """Mark OCR inference as available once a timed-out call finishes."""
        try:
            future.result()
        except Exception as exc:
            logger.warning("ocr_timed_out_future_finished", error=str(exc))
        with self._engine_lock:
            self._recognize_timed_out = False

    @staticmethod
    def _pil_to_numpy(image: Image.Image) -> Any:
        """Convert a PIL image to a numpy array suitable for PaddleOCR."""
        import numpy as np  # type: ignore[import-untyped]

        if image.mode != "RGB":
            image = image.convert("RGB")
        return np.array(image)

    @staticmethod
    def _parse_result(result: Any) -> list[dict[str, Any]]:
        """Parse PaddleOCR output into a list of text items.

        Handles both 2.x format (list of pages, each page is list of
        [box, (text, confidence)] tuples) and 3.x format (list of result
        dicts with 'rec_texts', 'rec_scores', 'dt_polys' keys).
        """
        items: list[dict[str, Any]] = []
        if not result:
            return items

        # PaddleOCR 3.x predict() returns a list of dicts
        # Keys: rec_texts, rec_scores, dt_polys
        if isinstance(result, list) and len(result) > 0 and isinstance(result[0], dict):
            for page in result:
                if not page:
                    continue
                texts = page.get("rec_texts", [])
                scores = page.get("rec_scores", [])
                polys = page.get("dt_polys", [])

                for i, text in enumerate(texts):
                    score = float(scores[i]) if i < len(scores) else 0.0
                    poly = polys[i] if i < len(polys) else []

                    # Convert polygon to bounding box (4 corner points)
                    box: list[list[float]] = []
                    if poly is not None and len(poly) >= 4:
                        # poly is typically shape (4, 2) for quadrilateral
                        if hasattr(poly, "tolist"):
                            poly = poly.tolist()
                        box = [
                            [round(float(p[0]), 1), round(float(p[1]), 1)]
                            for p in poly
                        ]

                    items.append(
                        {
                            "text": str(text),
                            "confidence": round(float(score), 4),
                            "box": box,
                        }
                    )
            return items

        # PaddleOCR 2.x ocr() returns list of pages
        for page in result:
            if not page:
                continue
            for line in page:
                if not line:
                    continue
                box_points = line[0] if len(line) > 0 else []
                text_info = line[1] if len(line) > 1 else ("", 0.0)

                items.append(
                    {
                        "text": text_info[0] if isinstance(text_info, (list, tuple)) else str(text_info),
                        "confidence": round(
                            float(text_info[1])
                            if isinstance(text_info, (list, tuple)) and len(text_info) > 1
                            else 0.0,
                            4,
                        ),
                        "box": [
                            [round(p[0], 1), round(p[1], 1)] for p in box_points
                        ]
                        if box_points
                        else [],
                    }
                )

        return items


# ---------------------------------------------------------------------------
# Module-level singleton
# ---------------------------------------------------------------------------

_engine_instance: OCREngine | None = None
_engine_lock = threading.Lock()


def get_ocr_engine() -> OCREngine:
    """Return the module-level OCR engine singleton."""
    global _engine_instance
    if _engine_instance is None:
        with _engine_lock:
            if _engine_instance is None:
                _engine_instance = OCREngine()
    return _engine_instance