"""Win32 window management operations."""

import ctypes
from ctypes import wintypes
from typing import Optional

import structlog

from peekaboowin.errors import PlatformError
from peekaboowin.models.elements import BoundingBox

logger = structlog.get_logger(__name__)

SW_RESTORE = 9


class RECT(ctypes.Structure):
    _fields_ = [("left", wintypes.LONG), ("top", wintypes.LONG), ("right", wintypes.LONG), ("bottom", wintypes.LONG)]


class WINDOWPLACEMENT(ctypes.Structure):
    _fields_ = [
        ("length", wintypes.UINT), ("flags", wintypes.UINT), ("showCmd", wintypes.UINT),
        ("ptMinPosition", wintypes.POINT), ("ptMaxPosition", wintypes.POINT),
        ("rcNormalPosition", RECT),
    ]


def get_window_rect(hwnd: int) -> tuple[int, int, int, int]:
    rect = RECT()
    if not ctypes.windll.user32.GetWindowRect(hwnd, ctypes.byref(rect)):
        error = ctypes.get_last_error()
        raise PlatformError(message="GetWindowRect failed", win_error_code=error, details={"hwnd": hwnd})
    return (rect.left, rect.top, rect.right, rect.bottom)


def set_foreground_window(hwnd: int) -> bool:
    target_tid = ctypes.windll.user32.GetWindowThreadProcessId(hwnd, None)
    current_tid = ctypes.windll.kernel32.GetCurrentThreadId()
    attached = False
    if target_tid != current_tid:
        ctypes.windll.user32.AttachThreadInput(current_tid, target_tid, True)
        attached = True
    try:
        ctypes.windll.user32.ShowWindow(hwnd, SW_RESTORE)
        result = ctypes.windll.user32.SetForegroundWindow(hwnd)
        return bool(result)
    finally:
        if attached:
            ctypes.windll.user32.AttachThreadInput(current_tid, target_tid, False)


def is_window(hwnd: int) -> bool:
    return bool(ctypes.windll.user32.IsWindow(hwnd))


def is_window_visible(hwnd: int) -> bool:
    return bool(ctypes.windll.user32.IsWindowVisible(hwnd))


def get_window_text(hwnd: int) -> str:
    length = ctypes.windll.user32.GetWindowTextLengthW(hwnd) + 1
    buffer = ctypes.create_unicode_buffer(length)
    ctypes.windll.user32.GetWindowTextW(hwnd, buffer, length)
    return buffer.value


def get_window_class(hwnd: int) -> str:
    buffer = ctypes.create_unicode_buffer(256)
    ctypes.windll.user32.GetClassNameW(hwnd, buffer, 256)
    return buffer.value


def get_window_thread_process_id(hwnd: int) -> tuple[int, int]:
    pid = wintypes.DWORD()
    tid = ctypes.windll.user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
    return (tid, pid.value)


def enum_windows() -> list[dict]:
    _enum_results: list[dict] = []
    _enum_foreground_hwnd: int = 0

    WNDENUMPROC = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)

    def _enum_window_callback(hwnd: int, _lParam: int) -> bool:
        nonlocal _enum_results, _enum_foreground_hwnd
        if not is_window_visible(hwnd) or not is_window(hwnd):
            return True
        try:
            title = get_window_text(hwnd)
            class_name = get_window_class(hwnd)
            _, pid = get_window_thread_process_id(hwnd)
            try:
                rect = get_window_rect(hwnd)
                bounds = BoundingBox(left=rect[0], top=rect[1], right=rect[2], bottom=rect[3])
            except PlatformError:
                bounds = None
            _enum_results.append({
                "hwnd": hwnd,
                "title": title,
                "class_name": class_name,
                "is_visible": True,
                "is_enabled": bool(ctypes.windll.user32.IsWindowEnabled(hwnd)),
                "bounds": bounds.to_tuple() if bounds else None,
                "process_id": pid,
            })
        except Exception as e:
            logger.debug("enum_window_callback_error", hwnd=hwnd, error=str(e))
        return True

    callback = WNDENUMPROC(_enum_window_callback)
    ctypes.windll.user32.EnumWindows(callback, 0)
    return _enum_results


def get_foreground_window_info() -> dict:
    hwnd = ctypes.windll.user32.GetForegroundWindow()
    if not hwnd:
        return {"hwnd": 0, "title": "", "class_name": "", "process_id": None}
    title = get_window_text(hwnd)
    class_name = get_window_class(hwnd)
    _, pid = get_window_thread_process_id(hwnd)
    try:
        rect = get_window_rect(hwnd)
        bounds = BoundingBox(left=rect[0], top=rect[1], right=rect[2], bottom=rect[3])
    except PlatformError:
        bounds = None
    return {
        "hwnd": hwnd,
        "title": title,
        "class_name": class_name,
        "is_visible": True,
        "is_enabled": bool(ctypes.windll.user32.IsWindowEnabled(hwnd)),
        "bounds": bounds.to_tuple() if bounds else None,
        "process_id": pid,
    }


def get_process_name(pid: int) -> Optional[str]:
    try:
        PROCESS_QUERY_INFORMATION = 0x0400
        PROCESS_VM_READ = 0x0010
        handle = ctypes.windll.kernel32.OpenProcess(PROCESS_QUERY_INFORMATION | PROCESS_VM_READ, False, pid)
        if not handle:
            return None
        try:
            buffer = ctypes.create_unicode_buffer(260)
            size = wintypes.DWORD(260)
            if ctypes.windll.psapi.GetModuleBaseNameW(handle, None, buffer, size):
                return buffer.value
            return None
        finally:
            ctypes.windll.kernel32.CloseHandle(handle)
    except Exception:
        return None
