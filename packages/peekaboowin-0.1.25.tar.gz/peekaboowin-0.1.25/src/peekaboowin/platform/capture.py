"""Screen capture using mss and Pillow."""

import ctypes
import struct
from ctypes import wintypes
from typing import Optional

import mss
import structlog
from PIL import Image

from peekaboowin.errors import PlatformError

logger = structlog.get_logger(__name__)

LOGPIXELSX = 88
LOGPIXELSY = 90

# PrintWindow flags
PW_RENDERFULLCONTENT = 0x00000002
SRCCOPY = 0x00CC0020
DIB_RGB_COLORS = 0
BI_RGB = 0

user32 = ctypes.windll.user32
gdi32 = ctypes.windll.gdi32
kernel32 = ctypes.windll.kernel32


class ScreenCapture:
    """Low-level screen capture using mss."""

    def __init__(self) -> None:
        self._mss: Optional[mss.mss] = None
        self._dpi_aware: Optional[bool] = None

    def _get_mss(self) -> mss.mss:
        if self._mss is None:
            self._mss = mss.mss()
        return self._mss

    def _is_dpi_aware(self) -> bool:
        if self._dpi_aware is None:
            try:
                result = ctypes.windll.user32.IsProcessDPIAware()
                self._dpi_aware = result if result else False
            except Exception:
                self._dpi_aware = False
        return self._dpi_aware

    def _get_monitor_dpi(self, monitor_index: int) -> float:
        try:
            sct = self._get_mss()
            monitors = sct.monitors
            mss_index = monitor_index + 1
            if mss_index >= len(monitors):
                return 1.0
            monitor = monitors[mss_index]
            device_name = monitor.get("name", "DISPLAY")
            dc = ctypes.windll.gdi32.CreateDCW("DISPLAY", device_name, None, None)
            if dc:
                try:
                    dpi_x = ctypes.windll.gdi32.GetDeviceCaps(dc, LOGPIXELSX)
                    return dpi_x / 96.0
                finally:
                    ctypes.windll.gdi32.DeleteDC(dc)
        except Exception as e:
            logger.warning("failed_to_get_monitor_dpi", monitor=monitor_index, error=str(e))
        return 1.0

    def _scale_coordinates(self, left: int, top: int, width: int, height: int, monitor_index: int = 0) -> tuple[int, int, int, int]:
        if self._is_dpi_aware():
            return left, top, width, height
        dpi_scale = self._get_monitor_dpi(monitor_index)
        if dpi_scale == 1.0:
            return left, top, width, height
        return (int(left * dpi_scale), int(top * dpi_scale), int(width * dpi_scale), int(height * dpi_scale))

    def capture_monitor(self, monitor_index: int = 0) -> Image.Image:
        try:
            sct = self._get_mss()
            monitor_num = monitor_index + 1
            monitors = sct.monitors
            if monitor_num >= len(monitors):
                raise PlatformError(message=f"Monitor {monitor_index} does not exist", details={"monitor_index": monitor_index})
            monitor = monitors[monitor_num]
            screenshot = sct.grab(monitor)
            return Image.frombytes("RGB", screenshot.size, screenshot.rgb)
        except Exception as e:
            logger.error("monitor_capture_failed", monitor=monitor_index, error=str(e))
            if isinstance(e, PlatformError):
                raise
            raise PlatformError(message=f"Failed to capture monitor {monitor_index}", details={"error": str(e)})

    def capture_region(self, left: int, top: int, width: int, height: int, monitor_index: int = 0) -> Image.Image:
        try:
            scaled_left, scaled_top, scaled_width, scaled_height = self._scale_coordinates(left, top, width, height, monitor_index)
            sct = self._get_mss()
            region = {"left": scaled_left, "top": scaled_top, "width": scaled_width, "height": scaled_height}
            screenshot = sct.grab(region)
            return Image.frombytes("RGB", screenshot.size, screenshot.rgb)
        except Exception as e:
            logger.error("region_capture_failed", error=str(e))
            if isinstance(e, PlatformError):
                raise
            raise PlatformError(message="Failed to capture screen region", details={"left": left, "top": top, "width": width, "height": height, "error": str(e)})

    @staticmethod
    def _is_blank_image(img: Image.Image) -> bool:
        """Detect if image is all-black (PrintWindow captured nothing)."""
        if img.mode == "RGBA":
            # Check RGB channels only, ignore alpha
            extrema = [img.getchannel(c).getextrema() for c in ("R", "G", "B")]
        else:
            extrema = img.getextrema()
        # If every channel's max value is 0, the image is all black
        return all(max_val == 0 for _, max_val in extrema)

    def _capture_window_printwindow(self, hwnd: int) -> Optional[Image.Image]:
        """Capture window using PrintWindow with PW_RENDERFULLCONTENT.

        Works for most desktop apps and some UWP/DirectComposition windows.
        Returns None if PrintWindow fails or produces a blank image.
        """
        class RECT(ctypes.Structure):
            _fields_ = [("left", wintypes.LONG), ("top", wintypes.LONG), ("right", wintypes.LONG), ("bottom", wintypes.LONG)]

        rect = RECT()
        if not user32.GetWindowRect(hwnd, ctypes.byref(rect)):
            logger.debug("printwindow_getrect_failed", hwnd=hwnd)
            return None

        width = rect.right - rect.left
        height = rect.bottom - rect.top
        if width <= 0 or height <= 0:
            logger.debug("printwindow_invalid_dims", hwnd=hwnd, width=width, height=height)
            return None

        # Create compatible DC and bitmap
        hdc_window = user32.GetWindowDC(hwnd)
        if not hdc_window:
            logger.debug("printwindow_getdc_failed", hwnd=hwnd)
            return None

        try:
            hdc_mem = gdi32.CreateCompatibleDC(hdc_window)
            if not hdc_mem:
                return None

            hbitmap = gdi32.CreateCompatibleBitmap(hdc_window, width, height)
            if not hbitmap:
                gdi32.DeleteDC(hdc_mem)
                return None

            old_bitmap = gdi32.SelectObject(hdc_mem, hbitmap)

            # Try PrintWindow with PW_RENDERFULLCONTENT first, then without flag
            success = user32.PrintWindow(hwnd, hdc_mem, PW_RENDERFULLCONTENT)
            if not success:
                success = user32.PrintWindow(hwnd, hdc_mem, 0)

            if not success:
                logger.debug("printwindow_failed", hwnd=hwnd)
                gdi32.SelectObject(hdc_mem, old_bitmap)
                gdi32.DeleteObject(hbitmap)
                gdi32.DeleteDC(hdc_mem)
                return None

            # Extract pixel data via GetDIBits (BGRA → RGBA)
            bmi = struct.pack("IiiHHIIiiII", 40, width, -height, 1, 32, BI_RGB, 0, 0, 0, 0)
            buf_size = width * height * 4
            pixel_buf = ctypes.create_string_buffer(buf_size)

            rows = gdi32.GetDIBits(
                hdc_mem, hbitmap, 0, height,
                pixel_buf, bmi, DIB_RGB_COLORS,
            )
            if rows == 0:
                logger.debug("printwindow_getdibits_failed", hwnd=hwnd)
                gdi32.SelectObject(hdc_mem, old_bitmap)
                gdi32.DeleteObject(hbitmap)
                gdi32.DeleteDC(hdc_mem)
                return None

            img = Image.frombytes("RGBA", (width, height), pixel_buf.raw, "raw", "BGRA")
            img = img.convert("RGB")

            # Cleanup GDI objects
            gdi32.SelectObject(hdc_mem, old_bitmap)
            gdi32.DeleteObject(hbitmap)
            gdi32.DeleteDC(hdc_mem)

            if self._is_blank_image(img):
                logger.debug("printwindow_blank_image", hwnd=hwnd)
                return None

            return img
        finally:
            user32.ReleaseDC(hwnd, hdc_window)

    def _capture_window_screen_crop(self, hwnd: int) -> Image.Image:
        """Capture window by screen region crop using mss (original method)."""
        class RECT(ctypes.Structure):
            _fields_ = [("left", wintypes.LONG), ("top", wintypes.LONG), ("right", wintypes.LONG), ("bottom", wintypes.LONG)]
        rect = RECT()
        result = user32.GetWindowRect(hwnd, ctypes.byref(rect))
        if not result:
            raise PlatformError(message="Failed to get window rect", details={"hwnd": hwnd, "error_code": ctypes.get_last_error()})
        left = rect.left
        top = rect.top
        width = rect.right - rect.left
        height = rect.bottom - rect.top
        if width <= 0 or height <= 0:
            raise PlatformError(message="Invalid window dimensions", details={"hwnd": hwnd, "width": width, "height": height})
        scaled_left, scaled_top, scaled_width, scaled_height = self._scale_coordinates(left, top, width, height)
        sct = self._get_mss()
        region = {"left": scaled_left, "top": scaled_top, "width": scaled_width, "height": scaled_height}
        screenshot = sct.grab(region)
        return Image.frombytes("RGB", screenshot.size, screenshot.rgb)

    def capture_window_by_hwnd(self, hwnd: int) -> Image.Image:
        try:
            # Strategy: PrintWindow first (captures actual window content including
            # some UWP/DirectComposition windows), fallback to mss screen crop.
            img = self._capture_window_printwindow(hwnd)
            if img is not None:
                logger.debug("window_capture_printwindow_ok", hwnd=hwnd)
                return img

            logger.debug("window_capture_fallback_mss", hwnd=hwnd)
            return self._capture_window_screen_crop(hwnd)
        except Exception as e:
            logger.error("window_capture_failed", hwnd=hwnd, error=str(e))
            if isinstance(e, PlatformError):
                raise
            raise PlatformError(message=f"Failed to capture window {hwnd}", details={"hwnd": hwnd, "error": str(e)})

    def list_monitors(self) -> list[dict]:
        try:
            sct = self._get_mss()
            monitors = sct.monitors
            result = []
            for i in range(1, len(monitors)):
                dpi_scale = self._get_monitor_dpi(i - 1)
                result.append({
                    "id": i - 1,
                    "name": monitors[i].get("name", ""),
                    "left": monitors[i].get("left", 0),
                    "top": monitors[i].get("top", 0),
                    "width": monitors[i].get("width", 0),
                    "height": monitors[i].get("height", 0),
                    "dpi_scale": dpi_scale,
                })
            return result
        except Exception as e:
            logger.error("failed_to_list_monitors", error=str(e))
            return []

    @staticmethod
    def image_to_base64(img: Image.Image, format: str, quality: int) -> str:
        import base64, io
        format_upper = format.upper()
        if format_upper not in ("PNG", "JPEG"):
            format_upper = "PNG"
        buffer = io.BytesIO()
        if format_upper == "JPEG":
            img = img.convert("RGB")
            img.save(buffer, format="JPEG", quality=quality)
        else:
            img.save(buffer, format="PNG")
        return base64.b64encode(buffer.getvalue()).decode("utf-8")


def image_to_base64(img: Image.Image, format: str, quality: int) -> str:
    return ScreenCapture.image_to_base64(img, format, quality)
