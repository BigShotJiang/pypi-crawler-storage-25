"""Win32 clipboard operations."""

import ctypes
import time
from ctypes import wintypes
from typing import Optional

import structlog

from peekaboowin.errors import PlatformError

logger = structlog.get_logger(__name__)

CF_UNICODETEXT = 13
GMEM_MOVEABLE = 0x0002
CLIPBOARD_RETRY_COUNT = 5
CLIPBOARD_RETRY_DELAY = 0.1


class Win32Clipboard:
    """Low-level clipboard operations using Win32 API."""

    _instance: Optional["Win32Clipboard"] = None

    def __new__(cls) -> "Win32Clipboard":
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._initialized = False
        return cls._instance

    def __init__(self) -> None:
        if self._initialized:
            return
        # use_last_error=True ensures ctypes.get_last_error() returns the real Win32 error
        self._user32 = ctypes.WinDLL("user32", use_last_error=True)
        self._kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
        # Set argtypes/restypes for correct 64-bit handle passing
        self._user32.OpenClipboard.argtypes = [wintypes.HWND]
        self._user32.OpenClipboard.restype = wintypes.BOOL
        self._user32.CloseClipboard.argtypes = []
        self._user32.CloseClipboard.restype = wintypes.BOOL
        self._user32.GetClipboardData.argtypes = [wintypes.UINT]
        self._user32.GetClipboardData.restype = wintypes.HANDLE
        self._user32.SetClipboardData.argtypes = [wintypes.UINT, wintypes.HANDLE]
        self._user32.SetClipboardData.restype = wintypes.HANDLE
        self._user32.EmptyClipboard.argtypes = []
        self._user32.EmptyClipboard.restype = wintypes.BOOL
        self._user32.IsClipboardFormatAvailable.argtypes = [wintypes.UINT]
        self._user32.IsClipboardFormatAvailable.restype = wintypes.BOOL
        self._kernel32.GlobalAlloc.argtypes = [wintypes.UINT, ctypes.c_size_t]
        self._kernel32.GlobalAlloc.restype = wintypes.HGLOBAL
        self._kernel32.GlobalLock.argtypes = [wintypes.HGLOBAL]
        self._kernel32.GlobalLock.restype = ctypes.c_void_p
        self._kernel32.GlobalUnlock.argtypes = [wintypes.HGLOBAL]
        self._kernel32.GlobalUnlock.restype = wintypes.BOOL
        self._initialized = True

    def _open_clipboard(self, hwnd: int = 0) -> bool:
        if not self._user32.OpenClipboard(hwnd):
            error = ctypes.get_last_error()
            raise PlatformError(message=f"Failed to open clipboard, error code: {error}", win_error_code=error)
        return True

    def _close_clipboard(self) -> None:
        self._user32.CloseClipboard()

    def _get_clipboard_data(self, format_id: int) -> Optional[ctypes.c_void_p]:
        return self._user32.GetClipboardData(format_id)

    def _set_clipboard_data(self, format_id: int, data: int) -> bool:
        return bool(self._user32.SetClipboardData(format_id, data))

    def _empty_clipboard(self) -> bool:
        return bool(self._user32.EmptyClipboard())

    def _global_alloc(self, flags: int, size: int) -> int:
        return self._kernel32.GlobalAlloc(flags, size)

    def _global_lock(self, hmem: int) -> ctypes.c_void_p:
        return self._kernel32.GlobalLock(hmem)

    def _global_unlock(self, hmem: int) -> bool:
        return bool(self._kernel32.GlobalUnlock(hmem))

    def _global_free(self, hmem: int) -> bool:
        return bool(self._kernel32.GlobalFree(hmem))

    def read_text(self) -> str:
        for attempt in range(CLIPBOARD_RETRY_COUNT):
            try:
                self._open_clipboard()
                try:
                    data_handle = self._get_clipboard_data(CF_UNICODETEXT)
                    if not data_handle:
                        return ""
                    mem_ptr = self._global_lock(data_handle)
                    if not mem_ptr:
                        return ""
                    try:
                        return ctypes.wstring_at(mem_ptr)
                    finally:
                        self._global_unlock(data_handle)
                finally:
                    self._close_clipboard()
            except PlatformError:
                if attempt < CLIPBOARD_RETRY_COUNT - 1:
                    logger.debug("clipboard_read_retry", attempt=attempt + 1)
                    time.sleep(CLIPBOARD_RETRY_DELAY)
                    continue
                raise
        return ""

    def write_text(self, text: str) -> None:
        text_bytes = (text + "\0").encode("utf-16-le")
        byte_count = len(text_bytes)
        for attempt in range(CLIPBOARD_RETRY_COUNT):
            try:
                self._open_clipboard()
                try:
                    if not self._empty_clipboard():
                        error = ctypes.get_last_error()
                        raise PlatformError(message=f"Failed to empty clipboard", win_error_code=error)
                    mem_handle = self._global_alloc(GMEM_MOVEABLE, byte_count)
                    if not mem_handle:
                        error = ctypes.get_last_error()
                        raise PlatformError(message=f"Failed to allocate global memory", win_error_code=error)
                    try:
                        mem_ptr = self._global_lock(mem_handle)
                        if not mem_ptr:
                            error = ctypes.get_last_error()
                            raise PlatformError(message=f"Failed to lock global memory", win_error_code=error)
                        try:
                            ctypes.memmove(mem_ptr, text_bytes, byte_count)
                        finally:
                            self._global_unlock(mem_handle)
                        if not self._set_clipboard_data(CF_UNICODETEXT, mem_handle):
                            error = ctypes.get_last_error()
                            raise PlatformError(message=f"Failed to set clipboard data", win_error_code=error)
                    finally:
                        pass  # Clipboard owns the handle after SetClipboardData
                finally:
                    self._close_clipboard()
                return
            except PlatformError:
                if attempt < CLIPBOARD_RETRY_COUNT - 1:
                    logger.debug("clipboard_write_retry", attempt=attempt + 1)
                    time.sleep(CLIPBOARD_RETRY_DELAY)
                    continue
                raise


_win32_clipboard: Optional[Win32Clipboard] = None


def get_win32_clipboard() -> Win32Clipboard:
    global _win32_clipboard
    if _win32_clipboard is None:
        _win32_clipboard = Win32Clipboard()
    return _win32_clipboard
