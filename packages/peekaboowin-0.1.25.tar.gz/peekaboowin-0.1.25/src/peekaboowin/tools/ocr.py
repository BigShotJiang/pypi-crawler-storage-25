"""OCR tools."""

import ctypes
from typing import Optional

import structlog

from peekaboowin.errors import ElementNotFoundError, InvalidParamsError
from peekaboowin.platform.win32_window import is_window
from peekaboowin.server import mcp
from peekaboowin.services.ocr_service import get_ocr_service
from peekaboowin.tools._common import tool_error_handler

logger = structlog.get_logger(__name__)


@mcp.tool()
@tool_error_handler("ocr_read")
def ocr_read(source: str = "screen", hwnd: Optional[int] = None, region: Optional[dict] = None, lang: str = "ch") -> dict:
    """OCR text recognition from screen, window, or region.

    Args:
        source: "screen" (full screen), "window" (specific window), or "region" (screen region).
                 Auto-inferred: if hwnd is provided → "window"; if region is provided → "region".
        hwnd: Window handle for source="window".
        region: Screen region dict for source="region", format: {"left": N, "top": N, "width": N, "height": N}.
        lang: OCR language, "ch" (Chinese/English mixed) or "en" (English).
    """
    if source not in ("screen", "window", "region"):
        raise InvalidParamsError(message="source must be 'screen', 'window', or 'region'", tool_name="ocr_read", param_name="source")
    # Auto-infer source when hwnd/region is provided but source is default "screen"
    if source == "screen":
        if hwnd is not None:
            source = "window"
        elif region is not None:
            source = "region"
    if source == "window":
        if hwnd is None or not isinstance(hwnd, int) or hwnd <= 0:
            raise InvalidParamsError(message="valid hwnd required for source='window'", tool_name="ocr_read", param_name="hwnd")
        # Validate hwnd exists
        if not is_window(hwnd):
            raise ElementNotFoundError(message=f"Window not found for hwnd: {hwnd}", element_description=f"hwnd:{hwnd}")
    if source == "region":
        if region is None or not isinstance(region, dict):
            raise InvalidParamsError(message="region dict required for source='region'", tool_name="ocr_read", param_name="region")
        required_keys = {"left", "top", "width", "height"}
        if not required_keys.issubset(region.keys()):
            raise InvalidParamsError(message="region must have left, top, width, height keys", tool_name="ocr_read", param_name="region")
        for key in required_keys:
            if not isinstance(region.get(key), (int, float)) or region[key] < 0:
                raise InvalidParamsError(message=f"region.{key} must be non-negative", tool_name="ocr_read", param_name=f"region.{key}")
        # Clamp oversized region to screen bounds
        screen_w = ctypes.windll.user32.GetSystemMetrics(0)
        screen_h = ctypes.windll.user32.GetSystemMetrics(1)
        if region["width"] > screen_w:
            region["width"] = screen_w
        if region["height"] > screen_h:
            region["height"] = screen_h
    if lang not in ("ch", "en"):
        raise InvalidParamsError(message="lang must be 'ch' or 'en'", tool_name="ocr_read", param_name="lang")
    service = get_ocr_service()
    result = service.ocr_read(source=source, hwnd=hwnd, region=region, lang=lang)
    return {
        "items": [{"text": item.text, "bbox": {"x": item.bbox.x, "y": item.bbox.y, "width": item.bbox.width, "height": item.bbox.height}, "confidence": item.confidence} for item in result.items],
        "source": result.source, "elapsed_ms": result.elapsed_ms,
    }
