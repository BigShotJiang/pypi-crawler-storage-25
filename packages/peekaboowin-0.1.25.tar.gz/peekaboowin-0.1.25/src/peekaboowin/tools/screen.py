"""Screen capture tools."""

import sys
from typing import Optional

import structlog

from peekaboowin import __version__
from peekaboowin.errors import InvalidParamsError
from peekaboowin.server import mcp
from peekaboowin.tools._common import tool_error_handler
from peekaboowin.config import get_config
from peekaboowin.platform.permissions import check_elevation, get_dpi_aware
from peekaboowin.services.screen_service import get_screen_service

logger = structlog.get_logger(__name__)


@mcp.tool()
@tool_error_handler("screenshot")
def screenshot(monitor: Optional[int] = None, region: Optional[dict] = None, image_format: Optional[str] = None, quality: Optional[int] = None) -> dict:
    """Capture screen or region screenshot.

    Args:
        monitor: Monitor index (0-based). None for default monitor.
        region: Screen region dict, format: {"left": N, "top": N, "width": N, "height": N}.
        image_format: "png" (default) or "jpeg".
        quality: JPEG quality 1-100 (default 85). Ignored for PNG.
    """
    logger.info("tool_called", tool="screenshot", monitor=monitor, region=region, format=image_format)
    if monitor is not None and (not isinstance(monitor, int) or monitor < 0):
        raise InvalidParamsError(message="monitor must be a non-negative integer", tool_name="screenshot", param_name="monitor")
    if region is not None:
        if not isinstance(region, dict):
            raise InvalidParamsError(message="region must be a dictionary", tool_name="screenshot", param_name="region")
        required_keys = {"left", "top", "width", "height"}
        if not required_keys.issubset(region.keys()):
            raise InvalidParamsError(message="region must have left, top, width, height keys", tool_name="screenshot", param_name="region", details={"required": list(required_keys)})
        for key in required_keys:
            if not isinstance(region[key], (int, float)) or (key in ("width", "height") and region[key] <= 0):
                raise InvalidParamsError(message=f"region.{key} must be a positive number", tool_name="screenshot", param_name=f"region.{key}")
    if image_format is not None and image_format.lower() not in ("png", "jpeg"):
        raise InvalidParamsError(message="image_format must be 'png' or 'jpeg'", tool_name="screenshot", param_name="image_format")
    if quality is not None and (not isinstance(quality, int) or quality < 1 or quality > 100):
        raise InvalidParamsError(message="quality must be an integer between 1 and 100", tool_name="screenshot", param_name="quality")
    service = get_screen_service()
    result = service.take_screenshot(monitor=monitor, region=region, format=image_format, quality=quality)
    return result


@mcp.tool()
@tool_error_handler("list_monitors")
def list_monitors() -> dict:
    service = get_screen_service()
    monitors = service.get_monitors()
    return {"monitors": monitors}


@mcp.tool()
@tool_error_handler("capture_window")
def capture_window(hwnd: int, image_format: Optional[str] = None, quality: Optional[int] = None, max_width: Optional[int] = None) -> dict:
    """Capture a screenshot of a specific window.

    Args:
        hwnd: Window handle (positive integer).
        image_format: "png" (default) or "jpeg".
        quality: JPEG quality 1-100 (default 85). Ignored for PNG.
        max_width: Maximum width in pixels, resized if larger (min 100).
    """
    if not isinstance(hwnd, int) or hwnd <= 0:
        raise InvalidParamsError(message="hwnd must be a positive integer", tool_name="capture_window", param_name="hwnd")
    if image_format is not None and image_format.lower() not in ("png", "jpeg"):
        raise InvalidParamsError(message="image_format must be 'png' or 'jpeg'", tool_name="capture_window", param_name="image_format")
    if quality is not None and (not isinstance(quality, int) or quality < 1 or quality > 100):
        raise InvalidParamsError(message="quality must be an integer between 1 and 100", tool_name="capture_window", param_name="quality")
    if max_width is not None and (not isinstance(max_width, int) or max_width < 100):
        raise InvalidParamsError(message="max_width must be >= 100", tool_name="capture_window", param_name="max_width")
    service = get_screen_service()
    return service.capture_window(hwnd=hwnd, format=image_format, quality=quality, max_width=max_width)


@mcp.tool()
@tool_error_handler("health_check")
def health_check() -> dict:
    config = get_config()
    dpi_aware = get_dpi_aware()
    elevation = "admin" if check_elevation() else "user"
    ocr_available = False
    ocr_status = "disabled"
    if config.ocr_enabled:
        try:
            import paddleocr  # noqa: F401
            ocr_available = True
            ocr_status = "enabled"
        except ImportError:
            ocr_available = False
            ocr_status = "not_installed"
    try:
        screen_service = get_screen_service()
        monitors = screen_service.get_monitors()
    except Exception:
        monitors = []
    return {
        "status": "ok", "version": __version__,
        "python_version": f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}",
        "platform": "Windows", "dpi_aware": dpi_aware, "elevation": elevation,
        "ocr_available": ocr_available, "ocr_status": ocr_status, "monitors": monitors,
        "config": {"ocr_enabled": config.ocr_enabled, "log_level": config.log_level,
                   "screenshot_format": config.screenshot_format, "screenshot_quality": config.screenshot_quality,
                   "screenshot_max_width": config.screenshot_max_width},
    }
