"""Shared utilities for MCP tool modules."""

import functools

import structlog

from peekaboowin.errors import InvalidParamsError, PeekabooWinError, ToolError

logger = structlog.get_logger(__name__)


def handle_tool_error(e: Exception, tool_name: str) -> dict:
    if isinstance(e, PeekabooWinError):
        return e.to_dict()
    logger.exception("tool_error", tool=tool_name, error=str(e))
    return ToolError(message=str(e), tool_name=tool_name, suggestions=["Check system requirements", "Verify target exists"]).to_dict()


def tool_error_handler(tool_name: str):
    """Decorator wrapping MCP tool functions with standardized error handling."""
    def decorator(func):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            try:
                return func(*args, **kwargs)
            except InvalidParamsError as e:
                return e.to_dict()
            except PeekabooWinError as e:
                return handle_tool_error(e, tool_name)
            except Exception as e:
                return handle_tool_error(e, tool_name)
        return wrapper
    return decorator
