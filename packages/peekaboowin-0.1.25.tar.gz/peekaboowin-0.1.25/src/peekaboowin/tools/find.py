"""Element finding tools."""

from typing import Optional

import structlog

from peekaboowin.errors import InvalidParamsError
from peekaboowin.services.uia_service import get_uia_service
from peekaboowin.tools._common import tool_error_handler
from peekaboowin.server import mcp

logger = structlog.get_logger(__name__)


@mcp.tool()
@tool_error_handler("find_element")
def find_element(name: Optional[str] = None, class_name: Optional[str] = None, automation_id: Optional[str] = None, scope: str = "descendants") -> dict:
    """Find a UI element by name, class name, or automation ID. Auto-falls back to OCR if UIA finds nothing."""
    logger.info("tool_find_element_called", name=name, class_name=class_name, automation_id=automation_id, scope=scope)
    service = get_uia_service()
    result = service.find_element_with_fallback(name=name, class_name=class_name, automation_id=automation_id, scope=scope)
    if result is None:
        raise InvalidParamsError(message="Element not found", tool_name="find_element", suggestions=["Try different search criteria"])
    return result


@mcp.tool()
@tool_error_handler("get_element_info")
def get_element_info(element_ref: str) -> dict:
    """Get detailed properties of a UI element. element_ref format: 'hwnd:NNNN', 'point:X,Y', or 'desktop'."""
    service = get_uia_service()
    return service.get_element_info(element_ref)


@mcp.tool()
@tool_error_handler("get_children")
def get_children(element_ref: str, depth: int = 1) -> dict:
    """Get child elements of a UI element. element_ref format: 'hwnd:NNNN', 'point:X,Y', or 'desktop'."""
    service = get_uia_service()
    return service.get_children(element_ref, depth=depth)


@mcp.tool()
@tool_error_handler("get_desktop")
def get_desktop(depth: int = 1) -> dict:
    """Get the desktop element tree with top-level windows."""
    service = get_uia_service()
    return service.get_desktop(depth=depth)
