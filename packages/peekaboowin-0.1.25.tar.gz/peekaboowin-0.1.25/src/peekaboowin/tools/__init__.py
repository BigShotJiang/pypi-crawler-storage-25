"""MCP tools for screen capture, element finding, input simulation, window management, and waiting."""

from peekaboowin.tools.screen import health_check

__all__ = ["health_check"]
