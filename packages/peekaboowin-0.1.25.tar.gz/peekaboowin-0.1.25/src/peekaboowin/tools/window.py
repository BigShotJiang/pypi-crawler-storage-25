"""Window management tools."""

from typing import Optional

import structlog

from peekaboowin.errors import InvalidParamsError
from peekaboowin.services.window_service import get_window_service
from peekaboowin.tools._common import tool_error_handler
from peekaboowin.server import mcp

logger = structlog.get_logger(__name__)


@mcp.tool()
@tool_error_handler("list_windows")
def list_windows() -> dict:
    """List all visible windows with title, class name, bounds, and process info."""
    service = get_window_service()
    return service.list_windows()


@mcp.tool()
@tool_error_handler("get_foreground_window")
def get_foreground_window() -> dict:
    """Get the current foreground (active) window info."""
    service = get_window_service()
    return service.get_foreground_window()


@mcp.tool()
@tool_error_handler("activate_window")
def activate_window(hwnd: int) -> dict:
    """Bring a window to the foreground. hwnd must be a positive integer."""
    if not isinstance(hwnd, int) or hwnd <= 0:
        raise InvalidParamsError(message="hwnd must be a positive integer", tool_name="activate_window", param_name="hwnd")
    service = get_window_service()
    return service.activate_window(hwnd)


@mcp.tool()
@tool_error_handler("move_window")
def move_window(hwnd: int, x: int, y: int) -> dict:
    """Move a window to the specified screen position."""
    if not isinstance(hwnd, int) or hwnd <= 0:
        raise InvalidParamsError(message="hwnd must be a positive integer", tool_name="move_window", param_name="hwnd")
    service = get_window_service()
    return service.move_window(hwnd, x, y)


@mcp.tool()
@tool_error_handler("resize_window")
def resize_window(hwnd: int, width: int, height: int) -> dict:
    """Resize a window. width and height must be positive."""
    if not isinstance(hwnd, int) or hwnd <= 0:
        raise InvalidParamsError(message="hwnd must be a positive integer", tool_name="resize_window", param_name="hwnd")
    if width <= 0 or height <= 0:
        raise InvalidParamsError(message="width and height must be positive", tool_name="resize_window", param_name="width/height")
    service = get_window_service()
    return service.resize_window(hwnd, width, height)


@mcp.tool()
@tool_error_handler("minimize_window")
def minimize_window(hwnd: int) -> dict:
    """Minimize a window."""
    if not isinstance(hwnd, int) or hwnd <= 0:
        raise InvalidParamsError(message="hwnd must be a positive integer", tool_name="minimize_window", param_name="hwnd")
    service = get_window_service()
    return service.minimize_window(hwnd)


@mcp.tool()
@tool_error_handler("maximize_window")
def maximize_window(hwnd: int) -> dict:
    """Maximize a window."""
    if not isinstance(hwnd, int) or hwnd <= 0:
        raise InvalidParamsError(message="hwnd must be a positive integer", tool_name="maximize_window", param_name="hwnd")
    service = get_window_service()
    return service.maximize_window(hwnd)


@mcp.tool()
@tool_error_handler("restore_window")
def restore_window(hwnd: int) -> dict:
    """Restore a window from minimized/maximized state."""
    if not isinstance(hwnd, int) or hwnd <= 0:
        raise InvalidParamsError(message="hwnd must be a positive integer", tool_name="restore_window", param_name="hwnd")
    service = get_window_service()
    return service.restore_window(hwnd)


@mcp.tool()
@tool_error_handler("close_window")
def close_window(hwnd: int) -> dict:
    """Close a window by sending WM_CLOSE."""
    if not isinstance(hwnd, int) or hwnd <= 0:
        raise InvalidParamsError(message="hwnd must be a positive integer", tool_name="close_window", param_name="hwnd")
    service = get_window_service()
    return service.close_window(hwnd)
