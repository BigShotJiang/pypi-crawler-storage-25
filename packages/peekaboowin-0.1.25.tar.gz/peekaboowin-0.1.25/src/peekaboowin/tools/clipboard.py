"""Clipboard tools."""

import time

import structlog

from peekaboowin.errors import InvalidParamsError
from peekaboowin.services.clipboard_service import get_clipboard_service
from peekaboowin.services.input_service import get_input_service
from peekaboowin.tools._common import tool_error_handler
from peekaboowin.server import mcp

logger = structlog.get_logger(__name__)


@mcp.tool()
@tool_error_handler("read_clipboard")
def read_clipboard() -> dict:
    """Read current text content from the clipboard."""
    service = get_clipboard_service()
    text = service.read_clipboard()
    return {"text": text, "success": True}


@mcp.tool()
@tool_error_handler("write_clipboard")
def write_clipboard(text: str) -> dict:
    """Write text to the clipboard."""
    if not text:
        raise InvalidParamsError(message="Text cannot be empty", tool_name="write_clipboard", param_name="text")
    service = get_clipboard_service()
    service.write_clipboard(text)
    return {"success": True}


@mcp.tool()
@tool_error_handler("paste_text")
def paste_text(text: str) -> dict:
    """Write text to clipboard and simulate Ctrl+V paste."""
    if not text:
        raise InvalidParamsError(message="Text cannot be empty", tool_name="paste_text", param_name="text")
    clipboard_service = get_clipboard_service()
    clipboard_service.write_clipboard(text)
    time.sleep(0.05)
    input_service = get_input_service()
    input_service.press_keys("ctrl+v")
    return {"success": True}
