"""Element data models for UIA element representation."""

import re
from enum import IntEnum
from typing import Optional

from pydantic import BaseModel, Field, field_validator


class BoundingBox(BaseModel):
    """Screen bounding box in pixels."""

    left: int = Field(description="Left coordinate")
    top: int = Field(description="Top coordinate")
    right: int = Field(description="Right coordinate")
    bottom: int = Field(description="Bottom coordinate")

    @property
    def width(self) -> int:
        return self.right - self.left

    @property
    def height(self) -> int:
        return self.bottom - self.top

    @property
    def x(self) -> int:
        return self.left

    @property
    def y(self) -> int:
        return self.top

    def to_tuple(self) -> tuple[int, int, int, int]:
        return (self.left, self.top, self.right, self.bottom)


class ControlType(IntEnum):
    """UIA control type IDs."""
    Button = 50000
    Calendar = 50001
    CheckBox = 50002
    ComboBox = 50003
    Edit = 50004
    Hyperlink = 50005
    Image = 50006
    ListItem = 50007
    List = 50008
    Menu = 50009
    MenuBar = 50010
    MenuItem = 50011
    ProgressBar = 50012
    RadioButton = 50013
    ScrollBar = 50014
    Slider = 50015
    Spinner = 50016
    StatusBar = 50017
    Tab = 50018
    TabItem = 50019
    Text = 50020
    ToolBar = 50021
    ToolTip = 50022
    Tree = 50023
    TreeItem = 50024
    Custom = 50025
    Group = 50026
    Thumb = 50027
    DataGrid = 50028
    DataItem = 50029
    Document = 50030
    SplitButton = 50031
    Window = 50032
    Pane = 50033
    Header = 50034
    HeaderItem = 50035
    Table = 50036
    TitleBar = 50037
    Separator = 50038
    SemanticZoom = 50039
    AppBar = 50040

    @classmethod
    def from_name(cls, name: str) -> Optional[int]:
        try:
            return cls[name].value
        except KeyError:
            return None


_HWND_RE = re.compile(r"^hwnd:\d+$")
_POINT_RE = re.compile(r"^point:\d+,\d+$")


class ElementRef(BaseModel):
    """Validates element reference formats."""

    ref: str = Field(description="Element reference string")

    @field_validator("ref")
    @classmethod
    def validate_ref(cls, v: str) -> str:
        if v == "desktop":
            return v
        if _HWND_RE.match(v):
            return v
        if _POINT_RE.match(v):
            return v
        raise ValueError("Invalid element_ref format: {}. Expected 'desktop', 'hwnd:NNNN', or 'point:X,Y'".format(v))

    @property
    def type(self) -> str:
        if self.ref == "desktop":
            return "desktop"
        if self.ref.startswith("hwnd:"):
            return "hwnd"
        if self.ref.startswith("point:"):
            return "point"
        return "unknown"

    @property
    def hwnd(self) -> Optional[int]:
        if self.type == "hwnd":
            return int(self.ref.split(":")[1])
        return None

    @property
    def point(self) -> Optional[tuple[int, int]]:
        if self.type == "point":
            parts = self.ref.split(":")[1].split(",")
            return (int(parts[0]), int(parts[1]))
        return None


class ElementInfo(BaseModel):
    """Full element information from UIA."""

    name: Optional[str] = Field(default=None, description="Element name")
    class_name: Optional[str] = Field(default=None, description="Window class name")
    automation_id: Optional[str] = Field(default=None, description="UIA automation ID")
    control_type: Optional[str] = Field(default=None, description="Control type name")
    is_enabled: bool = Field(default=True, description="Whether element is enabled")
    is_offscreen: bool = Field(default=False, description="Whether element is off-screen")
    bounding_box: Optional[BoundingBox] = Field(default=None, description="Element bounding box")
    process_id: Optional[int] = Field(default=None, description="Process ID")
    hwnd: Optional[int] = Field(default=None, description="Window handle")

    def to_dict(self) -> dict:
        result: dict = {}
        if self.name is not None:
            result["name"] = self.name
        if self.class_name is not None:
            result["class_name"] = self.class_name
        if self.automation_id is not None:
            result["automation_id"] = self.automation_id
        if self.control_type is not None:
            result["control_type"] = self.control_type
        result["is_enabled"] = self.is_enabled
        result["is_offscreen"] = self.is_offscreen
        if self.bounding_box:
            result["bounding_box"] = self.bounding_box.to_tuple()
        if self.process_id is not None:
            result["process_id"] = self.process_id
        if self.hwnd is not None:
            result["hwnd"] = self.hwnd
        return result

