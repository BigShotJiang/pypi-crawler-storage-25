"""Data models for PeekabooWin."""
