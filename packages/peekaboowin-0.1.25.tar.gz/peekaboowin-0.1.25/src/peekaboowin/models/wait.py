"""Wait/polling result models."""

from typing import Optional
from pydantic import BaseModel, Field


class WaitResult(BaseModel):
    """Result of a wait operation."""
    found: bool = Field(description="Whether element/window was found within timeout")
    element: Optional[dict] = Field(default=None, description="Element info if found")
    window: Optional[dict] = Field(default=None, description="Window info if found")
    elapsed_ms: float = Field(description="Time elapsed in milliseconds")
