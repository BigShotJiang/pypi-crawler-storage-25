"""OCR models."""

from pydantic import BaseModel, Field
from peekaboowin.models.elements import BoundingBox


class OCRTextItem(BaseModel):
    """Single OCR text recognition result."""
    text: str = Field(description="Recognized text content")
    bbox: BoundingBox = Field(description="Bounding box of text in image")
    confidence: float = Field(description="Recognition confidence score (0-1)")


class OCRReadResult(BaseModel):
    """OCR read operation result."""
    items: list[OCRTextItem] = Field(description="List of recognized text items")
    source: str = Field(description="OCR source (screen, window, region)")
    elapsed_ms: float = Field(description="Time taken for OCR in milliseconds")
