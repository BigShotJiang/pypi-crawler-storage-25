"""Window data models."""

from typing import Optional
from pydantic import BaseModel, Field
from peekaboowin.models.elements import BoundingBox


class WindowInfo(BaseModel):
    """Window information."""
    hwnd: int = Field(description="Window handle")
    title: str = Field(default="", description="Window title")
    class_name: str = Field(default="", description="Window class name")
    bounds: Optional[BoundingBox] = Field(default=None, description="Window bounding box")
    is_visible: bool = Field(default=True, description="Whether window is visible")
    is_enabled: bool = Field(default=True, description="Whether window is enabled")
    process_id: Optional[int] = Field(default=None, description="Process ID")
    process_name: Optional[str] = Field(default=None, description="Process name")

    def to_dict(self) -> dict:
        result = {
            "hwnd": self.hwnd,
            "title": self.title,
            "class_name": self.class_name,
            "is_visible": self.is_visible,
            "is_enabled": self.is_enabled,
        }
        if self.bounds:
            result["bounds"] = self.bounds.to_tuple()
        if self.process_id is not None:
            result["process_id"] = self.process_id
        if self.process_name is not None:
            result["process_name"] = self.process_name
        return result



