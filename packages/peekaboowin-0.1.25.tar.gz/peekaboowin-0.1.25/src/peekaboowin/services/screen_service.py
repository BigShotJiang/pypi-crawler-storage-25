"""Screen capture service using mss and Pillow."""

from typing import Optional

import structlog
from PIL import Image as PILImage

from peekaboowin.config import get_config
from peekaboowin.errors import PlatformError, ServiceError
from peekaboowin.platform.capture import ScreenCapture

logger = structlog.get_logger(__name__)


class ScreenService:
    """Business logic for screen capture operations."""

    _instance: Optional["ScreenService"] = None

    def __init__(self) -> None:
        self._capture = ScreenCapture()
        self._config = get_config()

    @classmethod
    def get_instance(cls) -> "ScreenService":
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    def _apply_max_width(self, img: PILImage.Image, max_width: int) -> PILImage.Image:
        if img.width > max_width:
            ratio = max_width / img.width
            new_height = int(img.height * ratio)
            return img.resize((max_width, new_height), PILImage.Resampling.LANCZOS)
        return img

    def take_screenshot(self, monitor: Optional[int] = None, region: Optional[dict] = None, format: Optional[str] = None, quality: Optional[int] = None, max_width: Optional[int] = None) -> dict:
        try:
            fmt = format or self._config.screenshot_format
            qual = quality if quality is not None else self._config.screenshot_quality
            max_w = max_width or self._config.screenshot_max_width
            fmt_lower = fmt.lower()
            if fmt_lower not in ("png", "jpeg"):
                fmt_lower = "png"
            if region is not None:
                img = self._capture.capture_region(left=region["left"], top=region["top"], width=region["width"], height=region["height"], monitor_index=monitor if monitor is not None else 0)
                monitor_idx = monitor if monitor is not None else 0
            elif monitor is not None:
                img = self._capture.capture_monitor(monitor)
                monitor_idx = monitor
            else:
                img = self._capture.capture_monitor(0)
                monitor_idx = 0
            img = self._apply_max_width(img, max_w)
            image_base64 = self._capture.image_to_base64(img, fmt_lower, qual)
            return {"image": image_base64, "width": img.size[0], "height": img.size[1], "format": fmt_lower.upper(), "monitor_index": monitor_idx}
        except PlatformError:
            raise
        except Exception as e:
            logger.error("screenshot_failed", error=str(e))
            raise ServiceError(message=f"Screenshot failed: {e}", service_name="ScreenService")

    def get_monitors(self) -> list[dict]:
        try:
            return self._capture.list_monitors()
        except Exception as e:
            logger.error("get_monitors_failed", error=str(e))
            return []

    def capture_window(self, hwnd: int, format: Optional[str] = None, quality: Optional[int] = None, max_width: Optional[int] = None) -> dict:
        try:
            fmt = format or self._config.screenshot_format
            qual = quality if quality is not None else self._config.screenshot_quality
            max_w = max_width or self._config.screenshot_max_width
            fmt_lower = fmt.lower()
            if fmt_lower not in ("png", "jpeg"):
                fmt_lower = "png"
            img = self._capture.capture_window_by_hwnd(hwnd)
            img = self._apply_max_width(img, max_w)
            image_base64 = self._capture.image_to_base64(img, fmt_lower, qual)
            return {"image": image_base64, "width": img.size[0], "height": img.size[1], "format": fmt_lower.upper()}
        except PlatformError:
            raise
        except Exception as e:
            logger.error("window_capture_failed", hwnd=hwnd, error=str(e))
            raise ServiceError(message=f"Window capture failed: {e}", service_name="ScreenService", details={"hwnd": hwnd})


def get_screen_service() -> ScreenService:
    return ScreenService.get_instance()
