"""Wait/Polling service for element and window state detection."""

import time
from typing import Optional

import structlog

from peekaboowin.config import get_config
from peekaboowin.errors import InvalidParamsError
from peekaboowin.models.wait import WaitResult
from peekaboowin.services.uia_service import get_uia_service
from peekaboowin.services.window_service import get_window_service

logger = structlog.get_logger(__name__)


class WaitService:
    """Business logic for wait/polling operations."""

    _instance: Optional["WaitService"] = None

    def __init__(self) -> None:
        self._config = get_config()
        self._uia_service = get_uia_service()
        self._window_service = get_window_service()

    @classmethod
    def get_instance(cls) -> "WaitService":
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    def wait_for_element(self, name=None, automation_id=None, class_name=None, control_type=None, timeout: float = 10.0, interval: float = 0.5, visible: bool = True) -> WaitResult:
        actual_timeout = timeout
        if interval <= 0:
            interval = 0.5
        start_time = time.monotonic()
        while True:
            elapsed = time.monotonic() - start_time
            if elapsed >= actual_timeout:
                return WaitResult(found=False, elapsed_ms=elapsed * 1000)
            try:
                element = self._uia_service.find_element(name=name, automation_id=automation_id, class_name=class_name)
                # 如果 UIA 找到了元素但 control_type 不匹配，不算找到
                if element is not None and control_type is not None:
                    if element.get("control_type") != control_type:
                        element = None
                found = element is not None
                if found == visible:
                    return WaitResult(found=found, element=element, elapsed_ms=elapsed * 1000)
            except Exception as e:
                logger.debug("wait_for_element_poll_error", error=str(e))
            time.sleep(interval)

    def wait_for_window(self, title=None, class_name=None, timeout: float = 10.0, interval: float = 0.5, appear: bool = True) -> WaitResult:
        if interval <= 0:
            interval = 0.5
        start_time = time.monotonic()
        while True:
            elapsed = time.monotonic() - start_time
            if elapsed >= timeout:
                return WaitResult(found=False, elapsed_ms=elapsed * 1000)
            try:
                windows_result = self._window_service.list_windows()
                windows = windows_result.get("windows", [])
                found = False
                found_window = None
                for w in windows:
                    if title and title.lower() not in w.get("title", "").lower():
                        continue
                    if class_name and w.get("class_name") != class_name:
                        continue
                    found = True
                    found_window = w
                    break
                if found == appear:
                    return WaitResult(found=found, window=found_window, elapsed_ms=elapsed * 1000)
            except Exception as e:
                logger.debug("wait_for_window_poll_error", error=str(e))
            time.sleep(interval)


def get_wait_service() -> WaitService:
    return WaitService.get_instance()
