"""Clipboard service for read/write operations."""

from typing import Optional

import structlog

from peekaboowin.errors import PlatformError, ServiceError
from peekaboowin.platform.clipboard import Win32Clipboard, get_win32_clipboard

logger = structlog.get_logger(__name__)


class ClipboardService:
    """Business logic for clipboard operations."""

    _instance: Optional["ClipboardService"] = None

    def __init__(self) -> None:
        try:
            self._win32_clipboard = get_win32_clipboard()
            logger.info("clipboard_service_initialized")
        except Exception as e:
            logger.error("clipboard_service_init_failed", error=str(e))
            raise ServiceError(message=f"Failed to initialize clipboard service: {e}", service_name="Clipboard")

    @classmethod
    def get_instance(cls) -> "ClipboardService":
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    def read_clipboard(self) -> str:
        try:
            text = self._win32_clipboard.read_text()
            logger.info("clipboard_service_read_success", text_length=len(text))
            return text
        except PlatformError as e:
            raise
        except Exception as e:
            raise ServiceError(message=f"Read clipboard operation failed: {e}", service_name="Clipboard")

    def write_clipboard(self, text: str) -> None:
        try:
            self._win32_clipboard.write_text(text)
            logger.info("clipboard_service_write_success", text_length=len(text))
        except PlatformError as e:
            raise
        except Exception as e:
            raise ServiceError(message=f"Write clipboard operation failed: {e}", service_name="Clipboard")


def get_clipboard_service() -> ClipboardService:
    return ClipboardService.get_instance()
