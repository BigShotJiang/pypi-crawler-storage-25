"""Error hierarchy for PeekabooWin.

All errors extend PeekabooWinError and follow:
  PlatformError -> ServiceError -> ToolError
"""

from typing import Any, Optional


class PeekabooWinError(Exception):
    """Base exception for all PeekabooWin errors."""

    def __init__(
        self,
        message: str = "An error occurred",
        error_code: str = "UNKNOWN",
        details: Optional[dict] = None,
    ):
        self.message = message
        self.error_code = error_code
        self.details = details or {}
        super().__init__(self.message)

    def to_dict(self) -> dict:
        return {
            "error": True,
            "error_code": self.error_code,
            "message": self.message,
            "details": self.details,
        }


class PlatformError(PeekabooWinError):
    """Low-level Windows API error."""

    def __init__(self, message: str = "Platform error", win_error_code: Optional[int] = None, details: Optional[dict] = None):
        details = details or {}
        if win_error_code is not None:
            details["win_error_code"] = win_error_code
        super().__init__(message=message, error_code="PLATFORM_ERROR", details=details)


class UIATimeoutError(PlatformError):
    """UIA operation timed out."""

    def __init__(self, message: str = "UIA operation timed out", details: Optional[dict] = None):
        super().__init__(message=message, win_error_code=None, details=details)


class ServiceError(PeekabooWinError):
    """Service layer error wrapping platform errors."""

    def __init__(self, message: str = "Service error", service_name: str = "Unknown", details: Optional[dict] = None):
        details = details or {}
        details["service"] = service_name
        super().__init__(message=message, error_code="SERVICE_ERROR", details=details)


class ToolError(PeekabooWinError):
    """MCP tool-level error."""

    def __init__(self, message: str = "Tool error", tool_name: str = "unknown", suggestions: Optional[list[str]] = None, details: Optional[dict] = None):
        details = details or {}
        details["tool"] = tool_name
        if suggestions:
            details["suggestions"] = suggestions
        super().__init__(message=message, error_code="TOOL_ERROR", details=details)


class InvalidParamsError(PeekabooWinError):
    """Invalid parameters passed to a tool or service."""

    def __init__(self, message: str = "Invalid parameters", tool_name: str = "unknown", param_name: Optional[str] = None, suggestions: Optional[list[str]] = None, details: Optional[dict] = None):
        details = details or {}
        details["tool"] = tool_name
        if param_name:
            details["param"] = param_name
        if suggestions:
            details["suggestions"] = suggestions
        super().__init__(message=message, error_code="INVALID_PARAMS", details=details)


class ElementNotFoundError(PeekabooWinError):
    """UI element not found."""

    def __init__(self, message: str = "Element not found", element_description: Optional[str] = None, details: Optional[dict] = None):
        details = details or {}
        if element_description:
            details["element"] = element_description
        super().__init__(message=message, error_code="ELEMENT_NOT_FOUND", details=details)


class PermissionBoundaryError(PeekabooWinError):
    """Cannot send input to elevated process from non-elevated process."""

    def __init__(self, message: str = "Permission boundary error", tool_name: str = "unknown", target_handle: Optional[int] = None, details: Optional[dict] = None):
        details = details or {}
        details["tool"] = tool_name
        if target_handle is not None:
            details["target_hwnd"] = target_handle
        super().__init__(message=message, error_code="PERMISSION_BOUNDARY", details=details)
