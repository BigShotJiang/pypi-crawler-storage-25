"""PeekabooWin - Windows 桌面自动化 MCP 服务器."""

from importlib.metadata import version as _pkg_version

try:
    __version__ = _pkg_version("peekaboowin")
except Exception:
    __version__ = "0.0.0"
