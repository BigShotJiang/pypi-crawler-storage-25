"""Tests for error hierarchy."""

from peekaboowin.errors import (
    PeekabooWinError,
    PlatformError,
    UIATimeoutError,
    ServiceError,
    ToolError,
    InvalidParamsError,
    ElementNotFoundError,
    PermissionBoundaryError,
)


class TestPeekabooWinError:
    """Base error class tests."""

    def test_default_values(self):
        err = PeekabooWinError()
        assert err.message == "An error occurred"
        assert err.error_code == "UNKNOWN"
        assert err.details == {}

    def test_custom_values(self):
        err = PeekabooWinError(
            message="test error",
            error_code="TEST",
            details={"key": "value"},
        )
        assert err.message == "test error"
        assert err.error_code == "TEST"
        assert err.details == {"key": "value"}

    def test_to_dict(self):
        err = PeekabooWinError(message="msg", error_code="C001", details={"x": 1})
        d = err.to_dict()
        assert d == {"error": True, "error_code": "C001", "message": "msg", "details": {"x": 1}}

    def test_str_representation(self):
        err = PeekabooWinError("something broke")
        assert str(err) == "something broke"

    def test_empty_details(self):
        err = PeekabooWinError()
        assert err.details == {}
        # Verify to_dict doesn't mutate internal state
        d1 = err.to_dict()
        d2 = err.to_dict()
        assert d1 == d2


class TestPlatformError:
    def test_default(self):
        err = PlatformError()
        assert err.error_code == "PLATFORM_ERROR"
        assert "win_error_code" not in err.details

    def test_with_win_error_code(self):
        err = PlatformError(win_error_code=5)
        assert err.details["win_error_code"] == 5

    def test_no_details_mutation(self):
        err = PlatformError(message="test", win_error_code=5)
        assert err.details["win_error_code"] == 5
        # Calling to_dict shouldn't add extra keys
        d = err.to_dict()
        assert d["details"]["win_error_code"] == 5


class TestUIATimeoutError:
    def test_inheritance(self):
        err = UIATimeoutError()
        assert isinstance(err, PlatformError)
        assert isinstance(err, PeekabooWinError)

    def test_default_message(self):
        err = UIATimeoutError()
        assert err.message == "UIA operation timed out"
        assert err.error_code == "PLATFORM_ERROR"

    def test_custom_message(self):
        err = UIATimeoutError(message="custom timeout msg", details={"timeout": 5.0})
        assert err.message == "custom timeout msg"
        assert err.details["timeout"] == 5.0


class TestServiceError:
    def test_default(self):
        err = ServiceError()
        assert err.error_code == "SERVICE_ERROR"
        assert err.details["service"] == "Unknown"

    def test_with_service_name(self):
        err = ServiceError(message="OCR failed", service_name="OCRService")
        assert err.details["service"] == "OCRService"
        assert err.message == "OCR failed"

    def test_to_dict_contains_service(self):
        err = ServiceError(service_name="ScreenService")
        d = err.to_dict()
        assert d["details"]["service"] == "ScreenService"


class TestToolError:
    def test_default(self):
        err = ToolError()
        assert err.error_code == "TOOL_ERROR"
        assert err.details["tool"] == "unknown"

    def test_with_suggestions(self):
        err = ToolError(
            message="click failed",
            tool_name="click",
            suggestions=["check coordinates", "ensure window is active"],
        )
        assert err.details["suggestions"] == ["check coordinates", "ensure window is active"]

    def test_no_suggestions(self):
        err = ToolError(tool_name="screenshot")
        assert "suggestions" not in err.details


class TestInvalidParamsError:
    def test_with_param_name(self):
        err = InvalidParamsError(tool_name="find_element", param_name="name")
        assert err.details["param"] == "name"
        assert err.details["tool"] == "find_element"

    def test_with_suggestions(self):
        err = InvalidParamsError(
            message="invalid ref format",
            suggestions=["use hwnd:N format", "use point:X,Y format"],
        )
        assert "suggestions" in err.details


class TestElementNotFoundError:
    def test_default(self):
        err = ElementNotFoundError()
        assert err.error_code == "ELEMENT_NOT_FOUND"

    def test_with_element_description(self):
        err = ElementNotFoundError(element_description="button#submit")
        assert err.details["element"] == "button#submit"

    def test_no_element_desc(self):
        err = ElementNotFoundError()
        assert "element" not in err.details


class TestPermissionBoundaryError:
    def test_default(self):
        err = PermissionBoundaryError()
        assert err.error_code == "PERMISSION_BOUNDARY"
        assert err.details["tool"] == "unknown"

    def test_with_target_handle(self):
        err = PermissionBoundaryError(tool_name="click", target_handle=12345)
        assert err.details["target_hwnd"] == 12345
