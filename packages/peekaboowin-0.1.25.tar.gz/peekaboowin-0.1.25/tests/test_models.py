"""Tests for all data models."""

from pydantic import ValidationError
import pytest

from peekaboowin.models.elements import (
    BoundingBox,
    ControlType,
    ElementRef,
    ElementInfo,
)
from peekaboowin.models.windows import (
    WindowInfo,
)
from peekaboowin.models.wait import WaitResult
from peekaboowin.models.ocr import OCRTextItem, OCRReadResult


# ============ BoundingBox ============

class TestBoundingBox:
    def test_constructor(self):
        b = BoundingBox(left=10, top=20, right=110, bottom=220)
        assert b.left == 10
        assert b.top == 20
        assert b.right == 110
        assert b.bottom == 220

    def test_width(self):
        assert BoundingBox(left=0, top=0, right=100, bottom=100).width == 100

    def test_height(self):
        b = BoundingBox(left=0, top=0, right=100, bottom=200)
        assert b.height == 200

    def test_x_y(self):
        b = BoundingBox(left=5, top=10, right=105, bottom=110)
        assert b.x == 5
        assert b.y == 10

    def test_to_tuple(self):
        b = BoundingBox(left=1, top=2, right=3, bottom=4)
        assert b.to_tuple() == (1, 2, 3, 4)

    def test_zero_dimensions(self):
        b = BoundingBox(left=0, top=0, right=0, bottom=0)
        assert b.width == 0
        assert b.height == 0
        assert b.to_tuple() == (0, 0, 0, 0)

    def test_negative_coordinates(self):
        b = BoundingBox(left=-10, top=-20, right=100, bottom=200)
        assert b.x == -10
        assert b.y == -20


# ============ ControlType ============

class TestControlType:
    def test_values(self):
        assert ControlType.Button.value == 50000
        assert ControlType.Window.value == 50032

    def test_from_name_found(self):
        assert ControlType.from_name("Button") == 50000
        assert ControlType.from_name("Window") == 50032

    def test_from_name_not_found(self):
        assert ControlType.from_name("NonExistent") is None

    def test_from_name_empty_string(self):
        assert ControlType.from_name("") is None


# ============ ElementRef ============

class TestElementRef:
    def test_desktop(self):
        ref = ElementRef(ref="desktop")
        assert ref.type == "desktop"
        assert ref.hwnd is None
        assert ref.point is None

    def test_hwnd(self):
        ref = ElementRef(ref="hwnd:12345")
        assert ref.type == "hwnd"
        assert ref.hwnd == 12345

    def test_point(self):
        ref = ElementRef(ref="point:100,200")
        assert ref.type == "point"
        assert ref.point == (100, 200)

    def test_invalid_format_raises(self):
        with pytest.raises(ValidationError):
            ElementRef(ref="invalid")

    def test_empty_string_raises(self):
        with pytest.raises(ValidationError):
            ElementRef(ref="")

    def test_hwnd_with_extra_chars_raises(self):
        with pytest.raises(ValidationError):
            ElementRef(ref="hwnd:abc")


# ============ ElementInfo ============

class TestElementInfo:
    def test_defaults(self):
        e = ElementInfo()
        assert e.name is None
        assert e.is_enabled is True
        assert e.is_offscreen is False

    def test_to_dict_partial(self):
        e = ElementInfo(name="submit", control_type="Button")
        d = e.to_dict()
        assert d["name"] == "submit"
        assert "bounding_box" not in d

    def test_to_dict_full(self):
        bbox = BoundingBox(left=0, top=0, right=100, bottom=50)
        e = ElementInfo(name="OK", class_name="Button", automation_id="123",
                        control_type="Button", is_enabled=True, is_offscreen=False,
                        bounding_box=bbox, process_id=1000, hwnd=12345)
        d = e.to_dict()
        assert d["bounding_box"] == (0, 0, 100, 50)
        assert d["process_id"] == 1000
        assert d["hwnd"] == 12345


# ============ WindowInfo ============

class TestWindowInfo:
    def test_defaults(self):
        win = WindowInfo(hwnd=12345)
        assert win.title == ""
        assert win.is_visible is True

    def test_to_dict_minimal(self):
        d = WindowInfo(hwnd=65552).to_dict()
        assert d["hwnd"] == 65552
        assert "bounds" not in d

    def test_to_dict_full(self):
        bbox = BoundingBox(left=0, top=0, right=800, bottom=600)
        win = WindowInfo(hwnd=12345, title="Notepad", class_name="Notepad",
                         bounds=bbox, process_id=1000, process_name="notepad.exe")
        d = win.to_dict()
        assert d["bounds"] == (0, 0, 800, 600)
        assert d["process_name"] == "notepad.exe"


# ============ Wait ============

class TestWaitResult:
    def test_found_with_element(self):
        r = WaitResult(found=True, element={"name": "OK"}, elapsed_ms=200.0)
        assert r.found is True
        assert r.element["name"] == "OK"

    def test_not_found(self):
        r = WaitResult(found=False, elapsed_ms=3000.0)
        assert r.found is False
        assert r.element is None


# ============ OCR ============

class TestOCRTextItem:
    def test_constructor(self):
        bbox = BoundingBox(left=0, top=0, right=50, bottom=20)
        item = OCRTextItem(text="Hello", bbox=bbox, confidence=0.95)
        assert item.text == "Hello"
        assert item.confidence == 0.95


class TestOCRReadResult:
    def test_constructor(self):
        bbox = BoundingBox(left=0, top=0, right=10, bottom=10)
        items = [OCRTextItem(text="Hello", bbox=bbox, confidence=0.9)]
        result = OCRReadResult(items=items, source="screen", elapsed_ms=150.0)
        assert len(result.items) == 1
        assert result.source == "screen"

    def test_empty_items(self):
        result = OCRReadResult(items=[], source="window", elapsed_ms=0.0)
        assert result.items == []
