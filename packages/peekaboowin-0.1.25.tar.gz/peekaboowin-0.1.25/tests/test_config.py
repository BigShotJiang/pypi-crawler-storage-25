"""Tests for configuration system."""

import os
from unittest.mock import patch

import pytest

from peekaboowin.config import PeekabooWinConfig, get_config


class TestPeekabooWinConfig:
    """Configuration model tests."""

    def test_default_values(self):
        config = PeekabooWinConfig()
        assert config.log_level == "info"
        assert config.log_format == "json"
        assert config.screenshot_format == "png"
        assert config.screenshot_quality == 85
        assert config.screenshot_max_width == 1920
        assert config.ocr_enabled is False
        assert config.ocr_language == "ch"
        assert config.ocr_use_gpu is False
        assert config.uia_timeout == 2.0
        assert config.uia_max_depth == 10
        assert config.input_click_delay == 0.05
        assert config.input_type_delay == 0.02

    def test_env_override_log_level(self):
        with patch.dict(os.environ, {"PEEKABOOWIN_LOG_LEVEL": "debug"}, clear=False):
            config = PeekabooWinConfig()
            assert config.log_level == "debug"

    def test_env_override_screenshot_format(self):
        with patch.dict(os.environ, {"PEEKABOOWIN_SCREENSHOT_FORMAT": "jpeg"}, clear=False):
            config = PeekabooWinConfig()
            assert config.screenshot_format == "jpeg"

    def test_env_override_ocr_enabled(self):
        with patch.dict(os.environ, {"PEEKABOOWIN_OCR_ENABLED": "true"}, clear=False):
            config = PeekabooWinConfig()
            assert config.ocr_enabled is True

    def test_env_override_ocr_language(self):
        with patch.dict(os.environ, {"PEEKABOOWIN_OCR_LANGUAGE": "en"}, clear=False):
            config = PeekabooWinConfig()
            assert config.ocr_language == "en"

    def test_env_override_uia_timeout(self):
        with patch.dict(os.environ, {"PEEKABOOWIN_UIA_TIMEOUT": "5.0"}, clear=False):
            config = PeekabooWinConfig()
            assert config.uia_timeout == 5.0

    def test_env_override_quality_valid_range(self):
        with patch.dict(os.environ, {"PEEKABOOWIN_SCREENSHOT_QUALITY": "50"}, clear=False):
            config = PeekabooWinConfig()
            assert config.screenshot_quality == 50

    @pytest.mark.parametrize("quality", [0, 101])
    def test_invalid_quality_out_of_range(self, quality):
        with patch.dict(os.environ, {"PEEKABOOWIN_SCREENSHOT_QUALITY": str(quality)}, clear=False):
            with pytest.raises(Exception):
                PeekabooWinConfig()

    def test_env_override_max_width(self):
        with patch.dict(os.environ, {"PEEKABOOWIN_SCREENSHOT_MAX_WIDTH": "3840"}, clear=False):
            config = PeekabooWinConfig()
            assert config.screenshot_max_width == 3840

    def test_env_override_use_gpu(self):
        with patch.dict(os.environ, {"PEEKABOOWIN_OCR_USE_GPU": "true"}, clear=False):
            config = PeekabooWinConfig()
            assert config.ocr_use_gpu is True

    def test_env_override_click_delay(self):
        with patch.dict(os.environ, {"PEEKABOOWIN_INPUT_CLICK_DELAY": "0.1"}, clear=False):
            config = PeekabooWinConfig()
            assert config.input_click_delay == 0.1

    def test_env_override_type_delay(self):
        with patch.dict(os.environ, {"PEEKABOOWIN_INPUT_TYPE_DELAY": "0.05"}, clear=False):
            config = PeekabooWinConfig()
            assert config.input_type_delay == 0.05

    def test_set_ocr_enabled(self):
        config = PeekabooWinConfig()
        assert config.ocr_enabled is False
        config.set_ocr_enabled(True)
        assert config.ocr_enabled is True
        config.set_ocr_enabled(False)
        assert config.ocr_enabled is False

    def test_multiple_env_overrides(self):
        with patch.dict(os.environ, {
            "PEEKABOOWIN_LOG_LEVEL": "error",
            "PEEKABOOWIN_OCR_LANGUAGE": "en",
            "PEEKABOOWIN_UIA_TIMEOUT": "3.0",
        }, clear=False):
            config = PeekabooWinConfig()
            assert config.log_level == "error"
            assert config.ocr_language == "en"
            assert config.uia_timeout == 3.0

    def test_extra_env_ignored(self):
        """Config should ignore unrelated env vars (extra='ignore')."""
        with patch.dict(os.environ, {"PEEKABOOWIN_UNKNOWN_FIELD": "value"}, clear=False):
            config = PeekabooWinConfig()
            assert not hasattr(config, "unknown_field")


class TestGetConfig:
    """Singleton config accessor tests."""

    def test_get_config_returns_instance(self):
        config = get_config()
        assert isinstance(config, PeekabooWinConfig)

    def test_get_config_is_singleton(self):
        get_config.cache_clear()
        c1 = get_config()
        c2 = get_config()
        assert c1 is c2

    def test_get_config_cache_clear(self):
        get_config.cache_clear()
        c1 = get_config()
        get_config.cache_clear()
        c2 = get_config()
        assert c1 is not c2

    def test_yaml_values_are_validated(self):
        get_config.cache_clear()
        with patch("peekaboowin.config._get_yaml_config_path", return_value="config.yaml"):
            with patch("peekaboowin.config._load_yaml_config", return_value={"screenshot_quality": 101}):
                with patch.dict(os.environ, {}, clear=True):
                    with pytest.raises(Exception):
                        get_config()
        get_config.cache_clear()

    def test_env_overrides_yaml(self):
        get_config.cache_clear()
        with patch("peekaboowin.config._get_yaml_config_path", return_value="config.yaml"):
            with patch("peekaboowin.config._load_yaml_config", return_value={"log_level": "debug", "screenshot_quality": 40}):
                with patch.dict(os.environ, {"PEEKABOOWIN_LOG_LEVEL": "error"}, clear=True):
                    config = get_config()
                    assert config.log_level == "error"
                    assert config.screenshot_quality == 40
        get_config.cache_clear()
