"""Tests for the PowerShell installer/update script."""

from pathlib import Path


def test_install_script_forces_tool_upgrade():
    script = Path("install.ps1").read_text(encoding="utf-8")

    assert '$GitHubPackage = "git+https://github.com/$Repo"' in script
    assert "$OcrPythonVersion = '3.12'" in script
    assert "uv tool install $GitHubPackage --upgrade --force" in script
    assert "uv tool install --python $OcrPythonVersion $GitHubPackage" in script
    assert "--with paddleocr --with $PaddlePaddleSpec" in script
    assert "uv tool install peekaboowin --upgrade --force" not in script


def test_install_script_verifies_version_without_starting_server():
    script = Path("install.ps1").read_text(encoding="utf-8")

    assert "peekaboowin --version" in script
    assert "uvx --upgrade --from $GitHubPackage peekaboowin --version" in script
    assert "Start-Process -FilePath \"peekaboowin\"" not in script


def test_install_script_does_not_put_upgrade_in_mcp_runtime_config():
    script = Path("install.ps1").read_text(encoding="utf-8")

    assert '"command": ["peekaboowin"]' in script
    assert '"command": ["uvx", "--upgrade", "peekaboowin", "-y"]' not in script
