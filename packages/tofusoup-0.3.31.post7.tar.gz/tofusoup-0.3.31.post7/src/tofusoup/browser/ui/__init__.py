# type: ignore
#
# SPDX-FileCopyrightText: Copyright (c) provide.io llc. All rights reserved.
# SPDX-License-Identifier: Apache-2.0
#

"""User Interface component for tfbrowser, built with Textual."""

from .app import TFBrowserApp  # Assuming TFBrowserApp will be the main app class

__all__ = [
    "TFBrowserApp",
]

# 🎨🖥️

# 🥣🔬🔚
