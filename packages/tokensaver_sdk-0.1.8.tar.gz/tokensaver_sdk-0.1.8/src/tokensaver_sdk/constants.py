"""Constants shared with the HTTP client (hosted product vs API surface)."""

from __future__ import annotations

# Must match `TokenSaver` default `base_url` after normalisation (no trailing slash).
DEFAULT_PUBLIC_API_BASE_URL = "https://api.tokensaver.fr/api/v1"

# Provider codes the pipeline API can route to when the deployment enables them
# (see backend `SUPPORTED_PROVIDERS`: openai, anthropic, google, mistral).
API_PIPELINE_LLM_PROVIDERS: frozenset[str] = frozenset(
    {"openai", "anthropic", "google", "mistral"},
)

# Hosted TokenSaver SaaS (demo / Free plan today): console only allows configuring an OpenAI key.
# The SDK applies the same rule when `base_url` is the default public API (matches the UI).
# Self-hosted or other `base_url` values are not restricted by this set.
HOSTED_SAAS_LLM_PROVIDERS: frozenset[str] = frozenset({"openai"})
