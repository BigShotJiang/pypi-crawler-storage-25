"""
TokenSaver SDK - Python client for the TokenSaver API.

This package only contains code intended for PyPI/open-source publication.
No local pipeline orchestration is implemented here; it is an API client.
"""

from tokensaver_sdk.client import (
    ERROR_HOSTED_LLM_PROVIDER,
    ERROR_LLM_MODEL_NOT_SUPPORTED,
    ERROR_RAG_FILE_NOT_FOUND,
    HISTORY_LOCAL,
    HISTORY_NONE,
    HISTORY_SERVER,
    HistoryMode,
    TokenSaver,
    TokenSaverClient,
)
from tokensaver_sdk.constants import (
    API_PIPELINE_LLM_PROVIDERS,
    DEFAULT_PUBLIC_API_BASE_URL,
    HOSTED_SAAS_LLM_PROVIDERS,
)
from tokensaver_sdk.errors import (
    AuthenticationError,
    ProviderKeyMissingError,
    QuotaExceededError,
    RateLimitError,
    ServerError,
    TimeoutError,
    TokenSaverError,
    ValidationError,
)
from tokensaver_sdk.types import (
    ContextView,
    MetricsView,
    PiiOptions,
    RagOptions,
    RunResult,
    TraceView,
)

__version__ = "0.1.8"
__all__ = [
    "TokenSaver",
    "TokenSaverClient",
    "API_PIPELINE_LLM_PROVIDERS",
    "DEFAULT_PUBLIC_API_BASE_URL",
    "HOSTED_SAAS_LLM_PROVIDERS",
    "ERROR_HOSTED_LLM_PROVIDER",
    "ERROR_LLM_MODEL_NOT_SUPPORTED",
    "ERROR_RAG_FILE_NOT_FOUND",
    "HISTORY_NONE",
    "HISTORY_LOCAL",
    "HISTORY_SERVER",
    "HistoryMode",
    "RunResult",
    "MetricsView",
    "TraceView",
    "ContextView",
    "RagOptions",
    "PiiOptions",
    "TokenSaverError",
    "AuthenticationError",
    "ProviderKeyMissingError",
    "QuotaExceededError",
    "RateLimitError",
    "ValidationError",
    "ServerError",
    "TimeoutError",
    "__version__",
]
