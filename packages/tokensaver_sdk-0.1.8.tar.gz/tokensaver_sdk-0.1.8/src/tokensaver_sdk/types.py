"""SDK response types."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Literal, TypedDict

# ----- POST /pipelines/run optional payloads (aligned with backend PipelineRunRequest) -----


class RagOptions(TypedDict, total=False):
    """RAG module options (``rag_options`` on pipeline run)."""

    document_ids: list[str]
    top_k: int
    query_image_url: str


class PiiOptions(TypedDict, total=False):
    """PII module options (``pii_options`` when ``use_pii_filter=True``)."""

    engine: Literal["gliner", "spacy"]
    strategy: Literal["mask", "replace", "remove"]
    confidence_threshold: float
    entity_types: list[str]
    language: Literal["fr", "en"]
    regex_fallback: bool


@dataclass
class MetricsView:
    cost_usd: float | None = None
    latency_ms: float | None = None
    cache_hit: bool | None = None
    tokens_input: int | None = None
    tokens_output: int | None = None
    tokens_total: int | None = None
    tokens_saved: int | None = None
    savings_ratio: float | None = None


@dataclass
class TraceView:
    request_id: str | None = None
    provider: str | None = None
    model: str | None = None


@dataclass
class ContextView:
    history_mode: Literal["none", "local", "server"] = "none"
    chat_id: str | None = None
    layers_used: list[str] = field(default_factory=list)


@dataclass
class RunResult:
    text: str
    raw: dict[str, Any] | None
    metrics: MetricsView
    trace: TraceView
    context: ContextView

    def to_dict(self) -> dict[str, Any]:
        return {
            "text": self.text,
            "raw": self.raw,
            "metrics": self.metrics.__dict__,
            "trace": self.trace.__dict__,
            "context": self.context.__dict__,
        }
