"""Typed SDK errors with backend payload normalization."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any


@dataclass
class TokenSaverError(Exception):
    code: str
    message: str
    status_code: int | None = None
    request_id: str | None = None
    raw: dict[str, Any] | str | None = None

    def __str__(self) -> str:  # pragma: no cover - trivial
        return self.message


@dataclass
class AuthenticationError(TokenSaverError):
    pass


@dataclass
class ProviderKeyMissingError(TokenSaverError):
    provider: str | None = None


@dataclass
class QuotaExceededError(TokenSaverError):
    quota_dimension: str | None = None
    limit: int | None = None
    current_usage: int | None = None
    retry_after_seconds: int | None = None


@dataclass
class RateLimitError(TokenSaverError):
    retry_after_seconds: int | None = None


@dataclass
class ValidationError(TokenSaverError):
    pass


@dataclass
class ServerError(TokenSaverError):
    pass


@dataclass
class TimeoutError(TokenSaverError):
    pass
