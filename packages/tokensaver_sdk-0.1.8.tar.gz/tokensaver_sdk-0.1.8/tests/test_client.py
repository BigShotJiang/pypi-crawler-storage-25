"""Tests du client TokenSaver (unitaires, sans appel réseau)."""

import json

import pytest

from tokensaver_sdk import (
    DEFAULT_PUBLIC_API_BASE_URL,
    ERROR_HOSTED_LLM_PROVIDER,
    ERROR_RAG_FILE_NOT_FOUND,
    TokenSaverClient,
)
from tokensaver_sdk.errors import ValidationError


def test_client_init():
    client = TokenSaverClient("https://api.example.com/api/v1", "test-key")
    assert client.base_url == "https://api.example.com/api/v1"
    assert client.api_key == "test-key"
    assert "Bearer test-key" in client._headers["Authorization"]
    assert client._default_provider_api_key is None


def test_client_init_default_provider_api_key():
    client = TokenSaverClient(
        "https://api.example.com/api/v1",
        "test-key",
        provider_api_key="sk-test",
    )
    assert client._default_provider_api_key == "sk-test"


def test_client_base_url_strips_trailing_slash():
    client = TokenSaverClient("https://api.example.com/api/v1/", "key")
    assert client.base_url == "https://api.example.com/api/v1"


def test_run_pipeline_returns_dict(httpx_mock):
    """run_pipeline appelle POST pipelines/run et renvoie le JSON."""
    httpx_mock.add_response(
        url="https://api.example.com/api/v1/pipelines/run",
        json={"response": "Hello", "model": "gpt-4o", "usage": {}, "cost": 0.01},
    )
    client = TokenSaverClient("https://api.example.com/api/v1", "key")
    out = client.run_pipeline("Hi", provider="openai", model="gpt-4o")
    assert out["response"] == "Hello"
    assert out["model"] == "gpt-4o"


def test_rag_upload_missing_file_raises_validation_error():
    """Fichier RAG absent → ValidationError RAG_FILE_NOT_FOUND (pas de requête HTTP)."""
    client = TokenSaverClient("https://api.example.com/api/v1", "key")
    with pytest.raises(ValidationError) as exc:
        client.rag_upload_document("/nonexistent/rag-doc.pdf")
    assert exc.value.code == ERROR_RAG_FILE_NOT_FOUND
    msg = exc.value.message.lower()
    assert "not found" in msg or "not a regular file" in msg
    assert exc.value.raw and "path" in exc.value.raw


def test_run_pipeline_sends_module_thresholds_and_options(httpx_mock):
    """Seuils RAG/cache, compression, PII et champs optionnels alignés sur l’API."""
    httpx_mock.add_response(
        url="https://api.example.com/api/v1/pipelines/run",
        json={"response": "ok", "model": "gpt-4o"},
    )
    client = TokenSaverClient("https://api.example.com/api/v1", "key")
    client.run_pipeline(
        "Hi",
        provider="openai",
        model="gpt-4o",
        use_rag=True,
        use_cache=True,
        use_compression=True,
        use_pii_filter=True,
        temperature=0.2,
        rag_similarity_threshold=0.55,
        cache_similarity_threshold=0.72,
        compression_level=4,
        rag_options={"document_ids": ["a"], "top_k": 8},
        pii_options={
            "engine": "gliner",
            "strategy": "mask",
            "confidence_threshold": 0.6,
            "entity_types": ["PERSON"],
            "language": "en",
            "regex_fallback": True,
        },
    )
    req = httpx_mock.get_requests()[0]
    body = json.loads(req.content.decode())
    assert body["temperature"] == 0.2
    assert body["rag_similarity_threshold"] == 0.55
    assert body["cache_similarity_threshold"] == 0.72
    assert body["compression_level"] == 4
    assert body["rag_options"]["top_k"] == 8
    assert body["pii_options"]["engine"] == "gliner"
    assert body["use_rag"] is True
    assert body["use_pii_filter"] is True


def test_run_pipeline_sends_provider_api_key_per_call_overrides_default(httpx_mock):
    httpx_mock.add_response(
        url="https://api.example.com/api/v1/pipelines/run",
        json={"response": "ok", "model": "gpt-4o"},
    )
    httpx_mock.add_response(
        url="https://api.example.com/api/v1/pipelines/run",
        json={"response": "ok", "model": "gpt-4o"},
    )
    client = TokenSaverClient(
        "https://api.example.com/api/v1",
        "key",
        provider_api_key="sk-default",
    )
    client.run_pipeline("Hi", provider="openai", model="gpt-4o", provider_api_key="sk-override")
    body = json.loads(httpx_mock.get_requests()[0].content.decode())
    assert body["provider_api_key"] == "sk-override"

    client.run_pipeline("Hi", provider="openai", model="gpt-4o")
    body2 = json.loads(httpx_mock.get_requests()[1].content.decode())
    assert body2["provider_api_key"] == "sk-default"


def test_default_hosted_url_rejects_non_openai_provider():
    """Hosted public API: only OpenAI matches console (demo / Free); no HTTP call."""
    client = TokenSaverClient(api_key="key")
    assert client.base_url == DEFAULT_PUBLIC_API_BASE_URL.rstrip("/")
    with pytest.raises(ValidationError) as exc:
        client.run_pipeline("Hi", provider="anthropic", model="claude-3-5-sonnet-latest")
    assert exc.value.code == ERROR_HOSTED_LLM_PROVIDER
    assert "openai" in exc.value.message.lower()
    with pytest.raises(ValidationError):
        client.estimate_cost(10, 10, "mistral", "mistral-small-latest")


def test_default_hosted_url_allows_openai_without_network(httpx_mock):
    httpx_mock.add_response(
        url=f"{DEFAULT_PUBLIC_API_BASE_URL.rstrip('/')}/pipelines/run",
        json={"response": "ok", "model": "gpt-4o"},
    )
    client = TokenSaverClient(api_key="key")
    out = client.run_pipeline("Hi", provider="openai", model="gpt-4o")
    assert out["response"] == "ok"


def test_custom_base_url_allows_non_openai_provider(httpx_mock):
    httpx_mock.add_response(
        url="https://api.example.com/api/v1/pipelines/run",
        json={"response": "from-anthropic", "model": "claude"},
    )
    client = TokenSaverClient("https://api.example.com/api/v1", "key")
    out = client.run_pipeline("Hi", provider="anthropic", model="claude-3-5-sonnet-latest")
    assert out["response"] == "from-anthropic"


def test_estimate_cost_returns_dict(httpx_mock):
    """estimate_cost appelle POST pricing/estimate et renvoie le JSON."""
    httpx_mock.add_response(
        url="https://api.example.com/api/v1/pricing/estimate",
        json={"cost_total": 1.5, "cost_input": 0.5, "cost_output": 1.0, "currency": "USD"},
    )
    client = TokenSaverClient("https://api.example.com/api/v1", "key")
    out = client.estimate_cost(100, 50, "openai", "gpt-4o")
    assert out["cost_total"] == 1.5
    assert out["currency"] == "USD"
