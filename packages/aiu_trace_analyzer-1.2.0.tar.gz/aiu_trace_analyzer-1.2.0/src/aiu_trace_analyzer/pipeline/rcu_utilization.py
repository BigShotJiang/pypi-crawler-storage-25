# Copyright 2024-2025 IBM Corporation

import os
import re
import copy
import json
from math import isclose
import pathlib
from enum import Flag, auto

import aiu_trace_analyzer.logger as aiulog
from aiu_trace_analyzer.types import TraceEvent, TraceWarning
from aiu_trace_analyzer.pipeline.context import AbstractContext
from aiu_trace_analyzer.pipeline.tools import PipelineContextTool
from aiu_trace_analyzer.pipeline.barrier import TwoPhaseWithBarrierContext
from aiu_trace_analyzer.pipeline.tools import KernelDetailsDB, AutopilotDetail

import pandas as pd
pd.set_option('display.max_rows', None)
pd.set_option('display.max_columns', None)
pd.set_option('display.width', None)

RCU_pt_util_counter_name = "PT Active"
RCU_pt_util_counter_unit = "Percent"

# for table fingerprint: include only event names that match this regex
_fprint_event_filter = r'^.*'

# default number of events for fingerprint of observed event stream
_default_fprint_len = 30

# default number of kernels for fingerprint of ideal cycles table
_table_data_limit = 500

# keep disabled until db-lookup feature is implemented
_kernel_db_feature_implemented = False

# kernel event name postfix
_kernel_event_name_postfix = " Cmpt Exec"


class RCUTableFingerprint():
    _separator = '_'

    def __init__(
            self,
            datalimit: int = -1,
            event_filter: str = r'',
            table_mode: str = "UNKN") -> None:
        self.datalimit = datalimit if datalimit > 0 else 1 << 31   # yes, it's not really unlimited...
        self.event_filter = re.compile(event_filter)
        self.table_mode = table_mode
        self.sim_weights = {
            "sequence": 0.5,
            "tab_len": 0.5,
            "total_time": 0.5
            }
        self.reset()

    def get(self) -> int:
        return self.hash

    def get_table_mode(self) -> str:
        return self.table_mode

    def add(self, data: str, time: float) -> None:
        if self.dataitems < self.datalimit and self.event_filter.search(data) is not None:
            aiulog.log(aiulog.DEBUG, f"adding to FP: {data}, Hash: {hash(data)}")
            converted = self._data_conversion(data)
            self.fprint_data += f"{converted}{self._separator}"
            self.data_hashes.append(converted)

        # item count and accumulated time needed for non-hash similarity checks
        self.dataitems += 1
        self.totaltime += time
        self._update_hash()

    def _data_conversion(self, data: str):
        # enough variety to build a rough 'alphabet' of kernel names
        # no big deal if some collisions occur
        return hash(data) % 65535

    def _update_hash(self) -> None:
        # hash based on data and totaltime (distinguish same sequence for different input sizes)
        self.hash = hash(self.fprint_data + str(self.totaltime))

    def reset(self) -> None:
        self.fprint_data: str = ""
        self.data_hashes: list[int] = []
        self.dataitems: int = 0
        self.totaltime = 0.0
        self._update_hash()

    def similarity(self, other) -> float:
        """
        similarity check happens under assumption:
         * self  == event stream fingerprint
         * other == ideal table fingerprint
        -> exclude criteria:
           * impossible: other.dataitems < self.dataitems
           * impossible: other.totaltime > self.totaltime
        """
        aiulog.log(aiulog.DEBUG, "FPRINT SIMILARITY: -----------------")
        # kernel sequence similarity
        sim_val = self.sim_weights["sequence"] * (1.0 if other.fprint_data.find(self.fprint_data) != -1 else 0.5)
        matched = "sub-sequence not found" if sim_val < self.sim_weights["sequence"] else "sub-sequence found"
        aiulog.log(
            aiulog.DEBUG, "   SIMVAL(sequence):",
            f"{sim_val}  <- ({matched}, {other.fprint_data.find(self.fprint_data)})")

        # table-length similarity
        if self.dataitems > other.dataitems:
            aiulog.log(
                aiulog.DEBUG, "   SIMVAL(tablelen):",
                f"{0.0}  <- (events={self.dataitems} > table={other.dataitems})")
            return 0.0

        sim_val += self.sim_weights["tab_len"] * (self.dataitems / other.dataitems)
        aiulog.log(
            aiulog.DEBUG, "   SIMVAL(tablelen):",
            f"{sim_val}  <- ({self.dataitems} / {other.dataitems} = {self.dataitems / other.dataitems})")

        # exclude table canditate if
        if other.totaltime > self.totaltime:
            aiulog.log(
                aiulog.DEBUG, "   SIMVAL(totaltim):",
                f"0.0  <- ({other.totaltime} / {self.totaltime} = {other.totaltime / self.totaltime})")
            return 0.0

        # total-time similarity
        if isclose(self.totaltime, 0.0, abs_tol=1e-9):
            zero_match_factor = int(isclose(other.totaltime, 0.0, abs_tol=1e-9)) * 1.0
            sim_val += self.sim_weights["total_time"] * zero_match_factor
        sim_val += self.sim_weights["total_time"] * (other.totaltime / self.totaltime)
        aiulog.log(
            aiulog.DEBUG, "   SIMVAL(totaltim):",
            f"{sim_val}  <- ({other.totaltime} / {self.totaltime} = {other.totaltime / self.totaltime})")
        return sim_val


class RCUKernelCategoryMap():
    def __init__(self) -> None:
        self.kernel_cat_map: dict[str, str] = {"other": "other"}

    def __getitem__(self, key: str) -> str:
        return self.kernel_cat_map[key]

    def __contains__(self, key: str) -> bool:
        return key in self.kernel_cat_map

    def add(self, key: str, value: str) -> str:
        if key not in self.kernel_cat_map:
            self.kernel_cat_map[key] = value
        elif value != self.kernel_cat_map[key]:
            aiulog.log(
                aiulog.WARN,
                "UTL: Kernel->Category map already has an entry with different category:",
                key, value, self.kernel_cat_map[key])
        return self.kernel_cat_map[key]

    def values(self):
        return self.kernel_cat_map.values()


class RCUAutopilotCounter():
    '''
    This tracks the accumulated time for kernels that belong to the same job.
    With autopilot=on, there still can be multiple kernels if this is a multi-aiu trace.
    '''
    def __init__(self, event: TraceEvent, ideal_dur: float) -> None:
        self.start = event["ts"]
        self.end = event["ts"] + event["dur"]
        self.pid = event["pid"]
        self.accum_time = event["dur"]
        self.ideal = ideal_dur

        # only accumulate time actually spent in event (excludes gaps between events)
        # hardcoded for now, full-span utilization can be computed from parent CPU wait events
        self.accumulate_event_time = True

    def update(self, event: TraceEvent, ideal_dur: float) -> tuple[float, float]:
        assert event["ts"] >= self.start, f"UTL: Event processing out-of-order: {self.start} <= {event}"
        assert event["pid"] == self.pid, f"UTL: Event PID mismatch. Expected {self.pid}, event: {event}"
        assert ideal_dur == self.ideal, f"UTL: Ideal duration mismatch. Expected {self.ideal}, got: {ideal_dur}"
        if event["ts"] < self.end:
            # warning: overlapping kernel events?
            aiulog.log(aiulog.WARN, "UTL: Overlapping kernel events detected. Overlap time[us]:",
                       self.end - event["ts"])

        self.start = min(self.start, event["ts"])
        self.end = max(self.end, event["ts"] + event["dur"])

        if self.accumulate_event_time:
            self.accum_time += event["dur"]
            # clamp the total duration to start-end to account for unexpected event overlap
            self.accum_time = min(self.accum_time, self.end - self.start)
        else:
            self.accum_time = self.end - self.start

        return self.start, self.end

    def compute_utilization(self) -> float:
        # return self.ideal / (self.end - self.start) * 100.0
        return self.ideal / self.accum_time * 100.0

    def create_counter_event(self, name: str, unit: str) -> tuple[TraceEvent, TraceEvent]:
        return (
            TraceEvent({
                "ph": "C",
                "ts": self.start,
                "pid": self.pid,
                "name": name,
                "args": {unit: self.compute_utilization()},
            }),
            TraceEvent({
                "ph": "C",
                "ts": self.end,
                "pid": self.pid,
                "name": name,
                "args": {unit: 0.0}
            })
        )


class RCUAutopilotRankJobTracker():
    def __init__(self) -> None:
        self.counters: dict[int, RCUAutopilotCounter] = {}
        self.hash_tracker: dict[int, tuple[int, int]] = {}

    def update(self, event: TraceEvent, ideal_dur: float, jobhash: int, rank: int) -> None:
        if jobhash not in self.counters:
            self.counters[jobhash] = RCUAutopilotCounter(event, ideal_dur)
        else:
            self.counters[jobhash].update(event, ideal_dur)
        self.job_tracking(jobhash, rank)

    def job_tracking(self, jobhash: int, rank: int) -> bool:
        '''
        check/update the job tracking per rank
        Keep the previous tracked job as is
        Update the current pending job (if different from previous)
        Fails if previous and current are already different - needs the old job to be 'emitted'
        '''
        if rank not in self.hash_tracker:
            self.hash_tracker[rank] = (jobhash, jobhash)
        new_job = (jobhash != self.hash_tracker[rank][1])
        assert not new_job or not self.new_job_pending(rank), f"UTL: new jobhash already in progress. {rank}:{jobhash}"
        self.hash_tracker[rank] = (self.hash_tracker[rank][0], jobhash)
        return new_job

    def new_job_pending(self, rank: int) -> bool:
        return rank in self.hash_tracker and self.hash_tracker[rank][0] != self.hash_tracker[rank][1]

    def get_completed(self) -> list[RCUAutopilotCounter]:
        rlist: list[RCUAutopilotCounter] = []
        for rank, tracker in self.hash_tracker.items():
            if self.new_job_pending(rank):
                # extract the counter for previous job
                completed_job = self.counters.pop(tracker[0], None)
                if completed_job:
                    rlist.append(completed_job)

                # update tracking to make previous job same as current
                self.hash_tracker[rank] = (tracker[1], tracker[1])

        return rlist

    def get_all(self) -> list[RCUAutopilotCounter]:
        return list(self.counters.values())


class RCUTableParseMode(Flag):
    ACTIVE_TABLE = auto()
    UNKNOWN = auto()
    PREFILL = auto()

    def get_phase(self):
        if self.UNKNOWN not in self:
            if self.PREFILL in self:
                return "TTFT"
            else:
                return "ITL"
        else:
            return "UNKN"

    def update(self, phase_str: str):
        if phase_str == "PREFILL":
            self |= RCUTableParseMode.PREFILL
            self &= ~RCUTableParseMode.UNKNOWN
        elif phase_str == "DECODING":
            self &= ~RCUTableParseMode.PREFILL
            self &= ~RCUTableParseMode.UNKNOWN
        else:
            self &= ~RCUTableParseMode.PREFILL
            self |= RCUTableParseMode.UNKNOWN
        return self


class RCUUtilizationContext(AbstractContext, PipelineContextTool):

    _start_pattern = re.compile(r' Ideal/Total Cycles ')
    _end_pattern = re.compile(r'====== Perf Summary End ======')
    _clock_scaling = re.compile(r'Ideal Clock Scaling:')
    _data_pattern = re.compile(r'^[_\-a-zA-Z\d]+ +\d+ *$')
    _ignore_pattern = re.compile(r'(Precompute|-LxPreload)')
    _category_splitter = re.compile(r'(\-opCat|\-NA$)')
    _autopilot_pattern = re.compile(r'DSM-AutoPilot BEGIN')
    _iteration_mode_pattern = re.compile(r'^\s+(DECODING|PREFILL)\s+$')
    _non_kernel_names = [""]

    _print_to_log = False

    def __init__(
            self,
            csv_fname: str,
            soc_freq: float,
            core_freq: float,
            compiler_info: str = None,
            kernel_db_url: str = "ai_kernel.db") -> None:

        super().__init__(warnings=[
            TraceWarning(
                name="util_100",
                text="UTL: Encountered {d[count]} Events with >100% utilization",
                data={"count": 0}
            ),
            TraceWarning(
                name="kernel_other",
                text="UTL: Found {d[count]} Events without a matching kernel category and accounted for 'other'",
                data={"count": 0}
            )
        ])

        self.autopilot = False
        self.csv_fname = self.generate_filename(csv_fname, "categories")
        self.tab_fname = self.generate_filename(csv_fname, "categories", "txt")
        self.kernel_db_url = kernel_db_url
        self._use_core_freq = True
        self.multi_table = -1  # assume no multitable case

        # if scale factor is unknown, set to -1.0 to later identify cycles that need subsequent rescaling
        self.scale_factor = soc_freq/core_freq
        self.cycle_to_clock_factor = 1.0/core_freq
        self.unscaled = False
        aiulog.log(aiulog.DEBUG, "UTL: Input Ideal Cycle To Clock factor", self.cycle_to_clock_factor)
        self.zero_counter_tracking = 0.0

        self.initialize_tables()

        try:
            if os.path.isfile(compiler_info):
                # Workload is running on current stack
                subdir, fpat = '/'.join(compiler_info.split('/')[:-1]), compiler_info.split('/')[-1]
                matches = list(pathlib.Path(subdir).rglob(fpat))
                if not matches:
                    raise FileNotFoundError(f"No files matching pattern: {fpat}")
                self.extract_tables(compiler_log=matches[0])
            elif os.path.isdir(compiler_info):
                # Workload is running on the Torch Spyre stack
                self.extract_tables_from_inductor_dir(compiler_info)
            else:
                raise ValueError(f"{compiler_info} Unrecognized compiler info file type. Expecting file or directory.")
        except (FileNotFoundError, PermissionError, IndexError, TypeError) as e:
            aiulog.log(aiulog.ERROR, "UTL: Unable to open/parse log file.", compiler_info, e)
        except ValueError as e:
            aiulog.log(aiulog.ERROR, e)

        for _, t in self.kernel_cycles.items():
            self.autopilot_detail = AutopilotDetail(t)
            self.table_hash = self.autopilot_detail.table_hash()

    def __del__(self) -> None:
        if self.is_enabled:
            if self.multi_table > 0:  # used as index, so 'n-1'
                aiulog.log(aiulog.WARN, f"UTL: {len(self.fingerprints)}/{self.multi_table+1} unique",
                           "tables with ideal cycles have been detected."
                           " Utilization results should be inspected carefully!!!!")
            if self.unscaled:
                aiulog.log(aiulog.WARN, "UTL: No ideal/real frequency unscaled (factor 1.0). "
                           "Utilization might be based on undefined data.")

        # dealing with the kernel_db only makes sense if we detected any table at all
        if _kernel_db_feature_implemented and len(self.kernel_cycles):
            self.kernel_db = KernelDetailsDB(self.kernel_db_url, self.autopilot)

            if self.autopilot:
                aiulog.log(aiulog.WARN, "UTL: Detected autopilot=1. "
                           "PT-activity/categories data will be attempted to get from previous runs with AP=0")
                self.categories = {}  # not implemented or self.kernel_db.retrieve(self.table_hash)
            else:
                self.kernel_db.insert(self.table_hash, self.categories)

        if len(self.categories.keys()) > 0:
            self.print_table_as_pd(self.categories)

    def initialize_tables(self) -> None:
        self.kernel_cycles: dict[int, dict[str, int]] = {}  # tables indexed by fingerprint
        self.categories = {}
        self.kernel_cat_map: dict[int, RCUKernelCategoryMap] = {}
        self.fingerprints: dict[int, RCUTableFingerprint] = {}
        self.hash_to_pid: dict[int, int] = {}

    def _start_init_table(self, table_mode: str) -> tuple[dict, RCUTableFingerprint]:
        self.multi_table += 1
        current_table = {}
        fprint = RCUTableFingerprint(
            datalimit=_table_data_limit,
            event_filter=_fprint_event_filter,
            table_mode=table_mode)  # use the first N (filtered) kernels as a fingerprint
        self.kernel_cat_map[0] = RCUKernelCategoryMap()  # new kernel-cat-map at temporary fprint key
        return current_table, fprint

    def _finish_add_table(self, fprint: RCUTableFingerprint, table: dict[str, int]) -> None:
        fprint_key = fprint.get()
        if fprint_key in self.kernel_cycles:
            aiulog.log(
                aiulog.WARN,
                "UTL: Fingerprint of current table already exists for previous table. "
                "Duplicated tables? Keeping the previous table only")
        else:
            aiulog.log(
                aiulog.INFO,
                f"UTL: Adding ideal cycles table ({fprint.get_table_mode()}) with fingerprint: {fprint_key}")
            aiulog.log(aiulog.DEBUG, f"UTL:    TablefprintStr: {fprint.fprint_data}")
        self.fingerprints[fprint_key] = fprint
        self.kernel_cycles[fprint_key] = copy.deepcopy(table)
        # re-assign temp kernel-cat-map to actual fingerprint
        self.kernel_cat_map[fprint_key] = self.kernel_cat_map.pop(0)
        fprint = None

    def _handle_category(self, kernel_and_cat) -> str:
        if len(kernel_and_cat) > 1:
            if kernel_and_cat[1] == "-opCat":
                return kernel_and_cat[-1]
            else:
                return "NotAvailable"
        else:
            return "Total"

    def _add_kernel(self,
                    kernel_and_cat: list[str],
                    cycles: int,
                    current_table: dict[str, int],
                    fprint: RCUTableFingerprint) -> RCUTableFingerprint:
        category = self._handle_category(kernel_and_cat)
        kernel = kernel_and_cat[0] + _kernel_event_name_postfix
        fprint.add(kernel, cycles * self.cycle_to_clock_factor)

        if kernel not in current_table:
            aiulog.log(aiulog.TRACE, "UTL: Kernel:", kernel)
            if cycles != 0:
                current_table[kernel] = cycles
        elif cycles != current_table[kernel]:
            aiulog.log(aiulog.WARN,
                       "UTL: Kernel already has an entry with different cycle count:",
                       kernel, cycles, current_table[kernel])

        if kernel not in self.kernel_cat_map[0]:
            self.kernel_cat_map[0].add(kernel, category)
        elif category != self.kernel_cat_map[0][kernel]:
            aiulog.log(aiulog.WARN,
                       "UTL: Kernel->Category map already has an entry with different category:",
                       kernel, category, self.kernel_cat_map[0][kernel])
        return fprint

    def _detect_autopilot_line(self, line: str) -> bool:
        if self._autopilot_pattern.search(line):
            if not self.autopilot:
                aiulog.log(
                    aiulog.WARN, "UTL: Detected autopilot=on. Event categorization, cycles table matching"
                    " and other utilization-related data might be unreliable.")
            self.autopilot = True
            return True
        return False

    def _check_obsolete_items(self, line: str) -> bool:
        if self._clock_scaling.search(line):
            aiulog.log(aiulog.WARN,
                       "UTL: Found obsolete 'Ideal Cycle Scaling' setting in logfile."
                       " This setting is ignored. Use '--freq=<soc>:<core>'.")
            return True
        return False

    def _handle_iteration_mode(
            self,
            iter_mode: re.Match,
            parse_mode: RCUTableParseMode) -> RCUTableParseMode:
        iteration_phase = iter_mode.group(1)
        parse_mode = parse_mode.update(iteration_phase)
        aiulog.log(aiulog.DEBUG, "DETECTED:", iteration_phase, "table to be next. Parsemode:", parse_mode)
        return parse_mode

    def _handle_start_table(
            self,
            parse_mode: RCUTableParseMode) -> tuple[
                RCUTableParseMode,
                dict[str, int],
                RCUTableFingerprint]:
        parse_mode |= RCUTableParseMode.ACTIVE_TABLE
        current_table, fprint = self._start_init_table(parse_mode.get_phase())
        aiulog.log(aiulog.DEBUG,
                   "UTL: Start of Ideal Cycle Count section detected. Parse mode:",
                   parse_mode, self.multi_table)
        return parse_mode, current_table, fprint

    def _process_table_line(self,
                            line: str,
                            fprint: RCUTableFingerprint,
                            parse_mode: RCUTableParseMode,
                            current_table: dict[str, int]) -> tuple[
                                bool,
                                bool,
                                dict[str, int],
                                RCUTableFingerprint]:

        # detect autopilot on/off
        if self._detect_autopilot_line(line):
            return True, parse_mode, current_table, fprint

        if self._check_obsolete_items(line):
            return True, parse_mode, current_table, fprint

        _iter_mode = self._iteration_mode_pattern.search(line)
        if _iter_mode is not None:
            parse_mode = self._handle_iteration_mode(_iter_mode, parse_mode)
            return True, parse_mode, current_table, fprint

        if self._start_pattern.search(line):
            parse_mode, current_table, fprint = self._handle_start_table(parse_mode)
            return True, parse_mode, current_table, fprint

        # don't bother checking for the end_pattern if we're not even in parse mode
        if RCUTableParseMode.ACTIVE_TABLE not in parse_mode:
            return True, parse_mode, current_table, fprint

        if self._end_pattern.search(line):
            aiulog.log(aiulog.DEBUG, "UTL: End of Ideal Cycle Count section detected. Stopping parse mode.")
            parse_mode &= ~RCUTableParseMode.ACTIVE_TABLE  # reset to scanning/no table
            self._finish_add_table(fprint, current_table)
            return True, parse_mode, current_table, fprint

        # This will need to be the last regex check because it skips everything else
        if not self._data_pattern.search(line) or self._ignore_pattern.search(line):
            return True, parse_mode, current_table, fprint

        ldata = re.split(" +", line)
        if len(ldata) < 2 or len(ldata) > 3:  # strange format includes newline as a 3rd column
            aiulog.log(
                aiulog.WARN,
                "UTL: found data pattern line with more than 2 columns. Check patterns.",
                ldata)
            return True, parse_mode, current_table, fprint

        cycles = int(ldata[1])
        kernel_and_cat = self._category_splitter.split(ldata[0])

        # Skip anything that's not a kernel name
        if kernel_and_cat[0] in self._non_kernel_names:
            return True, parse_mode, current_table, fprint

        fprint = self._add_kernel(kernel_and_cat, cycles, current_table, fprint)
        return True, parse_mode, current_table, fprint

    def extract_tables(self, compiler_log: pathlib.Path):

        parse_mode = RCUTableParseMode(RCUTableParseMode.UNKNOWN)
        self.multi_table = -1  # track if there might be multiple tables in the log
        current_table = {}
        fprint = None  # fingerprints created when a new table is detected
        with open(compiler_log, 'r') as cl:

            for line in cl:
                (
                    keep_parsing,
                    parse_mode,
                    current_table,
                    fprint
                ) = self._process_table_line(line, fprint, parse_mode, current_table)
                if not keep_parsing:
                    break

    def extract_tables_from_inductor_dir(self, inductor_spyre_dir: str):
        base = pathlib.Path(inductor_spyre_dir) / "inductor-spyre"
        current_table, fprint = self._start_init_table("UNKN")
        for kernel_dir in sorted(base.iterdir()):
            if not kernel_dir.is_dir():
                continue
            json_path = kernel_dir / "perf" / "ideal_cycles.json"
            if not json_path.exists():
                continue
            kernel_name = kernel_dir.name + _kernel_event_name_postfix
            with open(json_path) as f:
                entries = json.load(f)
            for entry in entries:
                cycles = entry["ideal_cycles"]
                category = entry["op_category"]
                fprint.add(kernel_name, cycles * self.cycle_to_clock_factor)
                if kernel_name not in current_table:
                    if cycles != 0:
                        current_table[kernel_name] = cycles
                if kernel_name not in self.kernel_cat_map[0]:
                    self.kernel_cat_map[0].add(kernel_name, category)
        self._finish_add_table(fprint, current_table)

    @staticmethod
    def _compute_row_stats(dur, total, ideal, ideal_total):
        dur_frac = 0 if isclose(total, 0.0, abs_tol=1e-9) else round(dur / total, 4)
        ideal_frac = 0 if isclose(ideal_total, 0.0, abs_tol=1e-9) else round(ideal / ideal_total, 4)
        pt_util = 0 if isclose(dur, 0.0, abs_tol=1e-9) else round(ideal / dur, 4)
        return dur_frac, ideal_frac, pt_util

    def print_table_as_pd(self, cat_tab):
        """
        Generate time breakdown along kernel categories

        Table columns
        ---------------------------
        .  Kernel Time: observed runtime of kernels
        .  Frac Time: ratio of the accumulated observed time of kernels in a category and
                      the total observed time of all kernels.
        .  Calls: number of kernels observed in a category
        .  Ideal Time: ideal time converted using core-clock frequency.
        .  Ideal Cycles: ideal cycle, as read from table.
        .  Frac Ideal: ratio of the accumulated ideal-time of kernels in a category and
                       the total ideal-time of all kernels.
        .  PT Util: ratio of the accumulated ideal-time of kernels in a category and
                    the accumulated observed-time of kernels in the same category.
        """

        title_row = ["Pid", "Phase", "Category", "Kernel_Time", "Frac_Time", "Calls",
                     "Ideal_Time", "Ideal_Cyc", "Frac_Ideal", "PT_Util"]
        aiulog.log(aiulog.DEBUG, "UTL: category title_row: ", title_row)

        list_of_list = []
        for p, data in cat_tab.items():
            if len(data) == 0:
                return

            pid, fp_key = self.hash_to_pid[p]
            try:
                phase = self.fingerprints[fp_key].get_table_mode()
            except KeyError:
                aiulog.log(aiulog.WARN, "UTL: Unexpected entry in category tables", fp_key)
                phase = "UNKN"
            total = data["Total"][0]
            ideal_total = data["Total"][1]

            for k, (dur, ideal, calls) in data.items():
                ideal_cyc = int(ideal / abs(self.cycle_to_clock_factor))

                # prevent div-by-zero exception
                dur_frac, ideal_frac, pt_util = RCUUtilizationContext._compute_row_stats(dur, total, ideal, ideal_total)

                # note: to sync the columns of value_row with title_row
                value_row = [pid, phase, k, dur, dur_frac, calls, round(ideal, 4), ideal_cyc, ideal_frac, pt_util]
                list_of_list.append(value_row)

                aiulog.log(aiulog.DEBUG, "UTL: category value_row: ", value_row)

        # the sorting places the "Total" row to the last of each section (section per pid) of the table.
        df = pd.DataFrame(list_of_list, columns=title_row)
        sorted_df = df.sort_values([title_row[0], title_row[1], title_row[3]],
                                   kind='stable', inplace=False, ignore_index=True)

        sorted_df.to_csv(self.csv_fname, index=False, header=True)                   # dump to CSV file
        print(sorted_df.to_string(index=False), file=open(self.tab_fname, 'w'))    # dump to TXT file

        aiulog.log(aiulog.INFO, "UTL: category table(s) created as CSV:", self.csv_fname)
        aiulog.log(aiulog.INFO, "UTL: category table(s) created as TXT:", self.tab_fname)

    # if there's no category table for the pid, create a new one from the known category keys
    def set_categories_for_pid(self, pid, fprint) -> None:
        cat_hash = hash(fprint+pid)
        if cat_hash in self.categories:
            return
        else:
            aiulog.log(aiulog.DEBUG, "UTL: Creating new categories table for", cat_hash)
            # always have the StcdpHbm category
            self.categories[cat_hash] = {"Total": (0.0, 0.0, 0), "StcdpHbm": (0.0, 0.0, 0)}
            self.hash_to_pid[cat_hash] = (pid, fprint)

        for cat in self.kernel_cat_map[fprint].values():
            self.categories[cat_hash][cat] = (0.0, 0.0, 0)

    def get_cycles(self, kernel: str, fprint: int) -> int:
        if len(self.kernel_cycles):
            rval = self.kernel_cycles[fprint].get(kernel, 0)
            return rval
        else:
            return 0

    def accumulate_categories(self, pid, kernel, ideal_dur, duration, fprint):
        if kernel not in self.kernel_cat_map[fprint]:
            self.issue_warning("kernel_other")
            kernel = "other"

        # ideal duration cannot be longer than actual duration
        # removing this item from accumulating in category
        # not issuing a warning because corresponding event handling already did that
        if ideal_dur > duration:
            ideal_dur = 0.0

        cat_hash = hash(fprint+pid)
        cat = self.kernel_cat_map[fprint][kernel]
        self.set_categories_for_pid(pid, fprint)
        aiulog.log(aiulog.TRACE, "UTL: ", kernel, cat, duration, ideal_dur, self.categories[cat_hash][cat])

        dur, i_dur, cnt = self.categories[cat_hash][cat]
        self.categories[cat_hash][cat] = (dur+duration, i_dur+ideal_dur, cnt+1)

        dur, i_dur, cnt = self.categories[cat_hash]["Total"]
        self.categories[cat_hash]["Total"] = (dur+duration, i_dur+ideal_dur, cnt+1)
        return cat

    def _add_final_zero_event(self, pending_zero: TraceEvent, final: bool = False) -> list[TraceEvent]:
        return [pending_zero] if final else []

    def handle_counter_overlap(
            self,
            counter: TraceEvent,
            trailing_zero: TraceEvent,
            final: bool = False) -> list[TraceEvent]:
        '''
        Expects a counter with utilization value and a corresponding zero-event to close the span.
        Returns a list of events based on previously tracked zero events.
         * regular: updates the zero_counter_tracking and returns an updated trailing zero-event for
           the previous counter plus the current counter.
         * if there's any overlap, the zero event (or both) are discarded and the tracking is updated as needed
         * if final is True, another trailing zero-event is created at the new self.zero_counter_tracking
        '''
        new_end = trailing_zero["ts"]
        has_pending_zero = (self.zero_counter_tracking > 0.0)

        # check for unexpected overlap
        if counter["ts"] <= self.zero_counter_tracking:
            new_start = self.zero_counter_tracking
            if new_end < new_start:
                # current counter is embedded in previously tracked event
                aiulog.log(
                    aiulog.WARN, "UTL: Counter embedding detected. Dropping embedded event."
                    "This is not technically possible and indicates a problem with the trace file.")
                return []  # dropping embedded counter

            self.zero_counter_tracking = new_end
            counter["ts"] = new_start  # push start of counter to end of previously tracked event
            return [counter] + self._add_final_zero_event(trailing_zero, final)

        # kind of the else branch as long as ^^^ returns
        revents = []
        if has_pending_zero:
            # no overlap, so we update zero_counter_tracking and reuse trailing_zero event to close previous span
            trailing_zero["ts"] = self.zero_counter_tracking
            revents = [trailing_zero]

        revents.append(counter)

        if final:
            # if there was a pending zero, we need to create a copy for the final event
            final_zero = copy.deepcopy(trailing_zero) if has_pending_zero else trailing_zero
            final_zero["ts"] = new_end
            revents.append(final_zero)

        self.zero_counter_tracking = new_end
        return revents


class MultiRCUUtilizationContext(TwoPhaseWithBarrierContext, PipelineContextTool):
    _name_converter = re.compile(r"\[N\]")
    _total_cycles_kernel_name = "Total"
    _utilization_fallback_value = 101.0
    """
    Create a warning about uncertain table matching
    if similarity of a job fingerprint and 2 tables differs by less than this tolerance
    """
    _similarity_tolerance = 0.2

    def __init__(
            self,
            csv_fname: str,
            soc_freq: float,
            core_freq: float,
            compiler_info: str = None) -> None:

        super().__init__(warnings=[
            # count the number of events with >100% utilization (indication of table mismatch)
            TraceWarning(
                name="util_100",
                text="UTL: Encountered {d[count]} Events with >100% utilization",
                data={"count": 0}
            ),
            # count the number of events where no corresponding table/fingerprint was found
            TraceWarning(
                name="kernel_nomatch",
                text="UTL: No matching Ideal Cycles table found for {d[count]} "
                     "Events. This might indicate a wrong frequency setting.",
                data={"count": 0}
            ),
            # count jobs with uncertain table match
            TraceWarning(
                name="uncertain_match",
                text="UTL: Detected uncertain Ideal Cycles table match for {d[count]} "
                     "jobs: {d[joblist]}",
                data={"count": 0, "joblist": set()},
                update_fn={"count": int.__add__, "joblist": set.union}
            )
        ])

        log_list = compiler_info.split(",")
        self.multi_log = (len(log_list) > 1)
        self.fingerprints: dict[int, RCUTableFingerprint] = {}   # fingerprints per job/file
        if self.multi_log:
            aiulog.log(aiulog.INFO, "UTL: Multi-AIU logs provided. Entries:", len(log_list))

        # event rank will be multiplied by this factor to make the key for the correct rcuctx
        # in single-log case: will turn everything into zero, otherwise use event rank
        self.rank_factor = 1 if self.multi_log else 0

        self.rcuctx: dict[int, RCUUtilizationContext] = {}
        for rank, log in enumerate(log_list):
            aiulog.log(aiulog.DEBUG, "UTL: Building kernel table for", rank)
            if self.multi_log:
                csv_basename = csv_fname + str(rank)
            else:
                csv_basename = csv_fname
            self.rcuctx[rank] = RCUUtilizationContext(
                csv_fname=csv_basename,
                soc_freq=soc_freq,
                core_freq=core_freq,
                compiler_info=log)

        self.counters = RCUAutopilotRankJobTracker()

    def enable(self) -> bool:
        rval = True
        for _, ctx in self.rcuctx.items():
            rval &= ctx.enable()
        return rval

    def extract_kernel_from_event_name(self, event: TraceEvent) -> str:
        rname = event["name"]
        rank = event["pid"] * self.rank_factor

        if self.rcuctx[rank].autopilot:
            rname = self._total_cycles_kernel_name

        # if a fn_idx was removed from the event name, we have to bring it back in to match the ideal cycles table entry
        if "[N]" in rname and "args" in event and "fn_idx" in event["args"]:
            rname = self._name_converter.sub(str(event["args"]["fn_idx"]), event["name"], count=1)

        if not rname.endswith(_kernel_event_name_postfix):
            rname += _kernel_event_name_postfix

        return rname

    def get_ideal_dur(self, kernel: str, pid: int, fingerprint: int) -> float:
        rank = pid * self.rank_factor
        return self.rcuctx[rank].get_cycles(kernel, fingerprint) * self.rcuctx[rank].cycle_to_clock_factor

    def accumulate_categories(self, pid, kernel, ideal_dur, duration, fprint):
        rank = pid * self.rank_factor
        return self.rcuctx[rank].accumulate_categories(pid, kernel, ideal_dur, duration, fprint)

    def fingerprint_add(self, job: int, kernel: str, time: float) -> None:
        if job not in self.fingerprints:
            self.fingerprints[job] = RCUTableFingerprint(_default_fprint_len, event_filter=_fprint_event_filter)

        self.fingerprints[job].add(kernel, time)

    def fingerprint_get(self, job: int) -> int:
        return self.fingerprints[job].get()

    # build a counter and a zero event
    # ignores input utilization if autopilot is enabled (separate computation, delayed counter creation)
    def make_utilization_event(self, event: TraceEvent, utilization: float, jobhash: int) -> list[TraceEvent]:
        revents: list[TraceEvent] = []
        log_str_100 = ""
        rank = event["pid"] * self.rank_factor

        if self.rcuctx[rank].autopilot:
            ideal = self.get_ideal_dur(
                self._total_cycles_kernel_name + _kernel_event_name_postfix,
                event["pid"],
                self.fingerprint_get(jobhash))
            self.counters.update(event, ideal, jobhash, rank)
            counters = self.counters.get_completed()
            for counter in counters:
                new_event, pending_zero = counter.create_counter_event(
                    RCU_pt_util_counter_name, RCU_pt_util_counter_unit)
                revents += self.rcuctx[rank].handle_counter_overlap(new_event, pending_zero)

        else:
            # TODO: this should be refactored to maybe use RCUAutopilotCounter, too
            revents = [TraceEvent({
                    "ph": "C",
                    "ts": event["ts"],
                    "pid": event["pid"],
                    "name": RCU_pt_util_counter_name,
                    "args": {RCU_pt_util_counter_unit: utilization},
                    "dur": event["dur"]  # temporary duration in cycles- remove before viz
                })]
            if utilization > 0.0:   # add a reset-to-zero event only if util is non-zero
                revents.append(TraceEvent({
                    "ph": "C",
                    "ts": event["ts"]+event["dur"],
                    "pid": event["pid"],
                    "name": RCU_pt_util_counter_name,
                    "args": {RCU_pt_util_counter_unit: 0.0}
                }))
            log_str_100 = f"(pid, utilization, event) {event['pid']}, {utilization}, {event}"

        revents = self._check_counter_sanity(revents, log_str_100)

        return revents

    def _check_counter_sanity(self, counters: list[TraceEvent], log_str: str) -> list[TraceEvent]:
        # check sanity of generated counter events
        for idx, counter in enumerate(counters):
            if counter["args"][RCU_pt_util_counter_unit] > 100.0:
                aiulog.log(aiulog.WARN, "UTL: Event with +100% utilization. "
                           "This could indicate a problem with table fingerprinting: ",
                           log_str, counter)
                self.issue_warning("util_100")
                counters[idx]["args"][RCU_pt_util_counter_unit] = self._utilization_fallback_value
        return counters

    def update_fprint_matches(self):
        for job, event_fprint in self.fingerprints.items():
            matching_fprints = []
            for table in self.rcuctx.values():
                for fprint in table.fingerprints.values():
                    matching_fprints.append((fprint, event_fprint.similarity(fprint)))

            if len(matching_fprints) == 0:
                continue

            matching_fprints.sort(key=(lambda x: x[1]), reverse=True)
            job_fprint, similar = matching_fprints[0]
            if similar < 0.8:
                # warn about low similarity value
                self.warnings["uncertain_match"].update({"count": 1, "joblist": [f"{job}:{similar:.2}"]})
            elif len(matching_fprints) > 1 and isclose(similar,
                                                       matching_fprints[1][1],
                                                       abs_tol=self._similarity_tolerance):
                # at least 2 tables with the same best similarity value (spit a warning)
                self.warnings["uncertain_match"].update({"count": 1, "joblist": [f"{job}:mm={len(matching_fprints)}"]})

            aiulog.log(aiulog.DEBUG, "UTL: (New) table-fprint for job", job, "to", job_fprint.get())
            self.fingerprints[job] = job_fprint

    def drain(self) -> list[TraceEvent]:
        # run fingerprint-similarity check for all jobs
        self.update_fprint_matches()

        revents = []
        for counter in self.counters.get_all():
            new_event, pending_zero = counter.create_counter_event(RCU_pt_util_counter_name, RCU_pt_util_counter_unit)
            rank = new_event["pid"] * self.rank_factor
            revents += self.rcuctx[rank].handle_counter_overlap(new_event, pending_zero, final=True)
            revents = self._check_counter_sanity(revents, "")

        return revents + super().drain()

    def generate_fprint_jobhash(self, event: TraceEvent) -> int:
        jobhash = event["args"]["jobhash"]
        if "correlation" in event["args"]:
            jobhash += event["args"]["correlation"]
        return jobhash


def compute_utilization_fingerprints(event: TraceEvent, context: AbstractContext) -> list[TraceEvent]:
    if event["ph"] != "X":
        return [event]

    assert isinstance(context, MultiRCUUtilizationContext)

    if PipelineContextTool.is_acc_event(event) and PipelineContextTool.is_acc_kernel(event):
        kernel_name = context.extract_kernel_from_event_name(event)

        context.fingerprint_add(context.generate_fprint_jobhash(event), kernel_name, event["dur"])
    return [event]


def compute_utilization(event: TraceEvent, context: AbstractContext) -> list[TraceEvent]:
    if event["ph"] != "X":
        return [event]

    assert isinstance(context, MultiRCUUtilizationContext)

    if not PipelineContextTool.is_acc_event(event) or not PipelineContextTool.is_acc_kernel(event):
        return [event]

    pid = event["pid"]
    kernel_name = context.extract_kernel_from_event_name(event)

    try:
        jobhash = context.generate_fprint_jobhash(event)
        job_fingerprint = context.fingerprint_get(jobhash)
    except KeyError:
        aiulog.log(aiulog.WARN, f"UTL: No matching fingerprint for job {event['args']['jobname']}."
                   " Unable to find a matching Ideal-cycles table.")
        return [event]

    try:
        ideal_dur = float(context.get_ideal_dur(kernel_name, pid, job_fingerprint))
    except KeyError:
        aiulog.log(aiulog.DEBUG, f"UTL: No kernel table matching fingerprint {job_fingerprint}:"
                   f" {context.fingerprints.keys()}/{context.fingerprints[jobhash].fprint_data} ")
        context.issue_warning("kernel_nomatch")
        ideal_dur = 0.0

    cmpt_dur = float(event["dur"])
    utilization = abs(ideal_dur/cmpt_dur) if not isclose(cmpt_dur, 0.0, abs_tol=1e-9) else 0.0

    detected_category = context.accumulate_categories(
            pid,
            kernel_name,
            ideal_dur,
            cmpt_dur,
            job_fingerprint)

    # prevent overwriting "cat" field in case events already have one
    if "cat" in event:
        event["args"]["user_cat"] = detected_category
    else:
        event["cat"] = detected_category

    util_counter = context.make_utilization_event(event, utilization*100.0, jobhash)

    if utilization > 0.0:
        # note: with autopilot on, the utilization is computed asynchronously.
        # In that case, this value could be unreliable
        event["args"]["pt_active"] = utilization
        event["args"]["core used"] = True

    return [event] + util_counter
