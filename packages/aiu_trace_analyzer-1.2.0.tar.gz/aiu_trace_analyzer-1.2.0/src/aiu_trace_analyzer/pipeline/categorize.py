# Copyright 2024-2025 IBM Corporation

from enum import Enum, auto

import aiu_trace_analyzer.logger as aiulog
from aiu_trace_analyzer.types import TraceEvent, TraceWarning
from aiu_trace_analyzer.pipeline.context import AbstractContext
from aiu_trace_analyzer.pipeline.tools import PipelineContextTool as pct
from aiu_trace_analyzer.pipeline.barrier import TwoPhaseWithBarrierContext


#################################################
# source from Josh
class EventClass(Enum):
    """Enumeration of event classification categories for trace analysis.

    This enum defines various event types used to categorize trace events
    in the AIU trace analyzer pipeline, including compute operations,
    data transfers, MultiAIU protocol operations, and synchronization primitives.
    """
    OTHER = auto()
    COMPUTE_PREP = auto()
    COMPUTE_EXEC = auto()
    DATA_IN = auto()
    DATA_OUT = auto()
    SEN_DATA_CONVERT = auto()
    MAIU_BARRIER = auto()
    MAIU_WIREUP = auto()
    ROUNDTRIP_FLEX = auto()
    ROUNDTRIP_AIU = auto()
    # Local serial setup (e.g., data structure updates)
    MAIU_PROTOCOL_SERIAL = auto()
    # Host DMA: Wait for 'DATA' signal
    MAIU_HDMA_PROTOCOL_WAIT_DATA = auto()
    # Host DMA: Wait for 'ACK' signal
    MAIU_HDMA_PROTOCOL_WAIT_ACK = auto()
    # Host DMA: Send 'Data' signal
    MAIU_HDMA_PROTOCOL_SIGNAL_DATA = auto()
    # Host DMA: Send 'ACK' signal
    MAIU_HDMA_PROTOCOL_SIGNAL_ACK = auto()
    # Host DMA: Waiting for the monitor to acknowledge they issued the delivery of the notice
    MAIU_HDMA_PROTOCOL_MONITOR_NOTICE = auto()
    # Host DMA: Data Send
    MAIU_HDMA_PROTOCOL_SEND_DATA = auto()
    # Host DMA: Data RECV
    MAIU_HDMA_PROTOCOL_RECV_DATA = auto()
    # P2P (R)DMA: Data Send
    MAIU_P2PRDMA_PROTOCOL_SEND_DATA = auto()
    # P2P (R)DMA: Data RECV
    MAIU_P2PRDMA_PROTOCOL_RECV_DATA = auto()
    # General Data Send
    MAIU_PROTOCOL_SEND_DATA = auto()
    # General Data Recv
    MAIU_PROTOCOL_RECV_DATA = auto()
    # General Data Signal
    MAIU_PROTOCOL_SIGNAL_DATA = auto()
    # General Ack Signal
    MAIU_PROTOCOL_SIGNAL_ACK = auto()

    def __str__(self):
        return self.name

    def __repr__(self):
        return f"EventClass.{self.name}"

    def toJson(self):
        return self.name

    @classmethod
    def from_string(cls, name: str) -> 'EventClass':
        """Deserialize EventClass from string name.

        Args:
            name: The string name of the EventClass member

        Returns:
            EventClass: The corresponding EventClass enum member

        Raises:
            ValueError: If the name doesn't match any EventClass member
        """
        try:
            return cls[name]
        except KeyError:
            raise ValueError(f"'{name}' is not a valid EventClass name")
# end source from Josh
########################################


class EventCategorizerContext(TwoPhaseWithBarrierContext):
    _BYTES_ENTRY = "bytes"

    def __init__(self, with_zero_align: bool = False):
        super().__init__(warnings=[
            TraceWarning(
                name="flex_mismatch",
                text="CAT: Found {d[count]} categorization mismatches compared to FLEX src classifier.",
                data={"count": 0}
            )])
        self.do_zero_align = 1.0 if with_zero_align else 0.0
        self.first_ts_per_rank: dict[int, float] = {}

    def is_collective_event(self, event: TraceEvent) -> bool:
        """Determine if an event is a collective communication event.

        Args:
            event: The trace event to check

        Returns:
            bool: True if the event is a collective communication event, False otherwise
        """
        return "CollGroup" in event["args"]

    def classify_flex(self, event: TraceEvent) -> (EventClass | None):   # noqa: C901
        """Classify trace events using FLEX dialect-based classification.

        This method is currently kept for verification of the dialect-based classifier.
        It categorizes events based on FLEX-specific naming patterns and collective
        communication protocols.

        Args:
            event: The trace event to classify

        Returns:
            EventClass: The classified event category

        Note:
            This is a reference implementation and should be maintained as-is to compare
            results for compatibility until eventually be removed. The noqa: C901 suppresses
            complexity warnings as the function intentionally has many branches for classification.
        """
        dialect = pct.get_dialect_of_event(event)
        if dialect is None or dialect.get("NAME") != "FLEX":
            return None
        event_class = EventClass.OTHER
        if "Cmpt Prep" in event["name"]:
            # TS1 TS2 --- --- ---
            event_class = EventClass.COMPUTE_PREP
        elif "Cmpt Exec" in event["name"]:
            # --- --- TS3 TS4 TS5
            event_class = EventClass.COMPUTE_EXEC
        elif "DmaI" in event["name"]:
            if "Cleanup Host DMA Wait for ACK" in event["name"]:
                event_class = EventClass.MAIU_HDMA_PROTOCOL_WAIT_ACK
            else:
                event_class = EventClass.DATA_IN
        elif "DmaO" in event["name"]:
            event_class = EventClass.DATA_OUT

        if "Compute of" in event["name"] and "SenFusedDeviceNode" not in event["name"]:
            event_class = EventClass.SEN_DATA_CONVERT
        if "PrepareAndSyncRdma" in event["name"]:
            event_class = EventClass.MAIU_WIREUP
        if "Barrier:" in event["name"]:
            event_class = EventClass.MAIU_BARRIER
        if "Flex RoundTrip" in event["name"]:
            event_class = EventClass.ROUNDTRIP_FLEX
        if "AIU Roundtrip" in event["name"]:
            event_class = EventClass.ROUNDTRIP_AIU

        if self.is_collective_event(event):
            if "Host DMA" in event["name"] or "HCOLL" in event["name"]:
                # PF mode
                if (
                    "Wdone DmaI" in event["name"] or
                    "Wait for Data Avail Notice" in event["name"] or
                    "Wait for Notice (gather notifications)" in event["name"] or
                    "R5 Wait DATA" in event["name"]
                   ):
                    event_class = EventClass.MAIU_HDMA_PROTOCOL_WAIT_DATA
                elif "Wait for ACK" in event["name"] or "R5 Wait ACK" in event["name"]:
                    event_class = EventClass.MAIU_HDMA_PROTOCOL_WAIT_ACK
                elif "Send ACK Instruction" in event["name"] or "R5 Send ACK" in event["name"]:
                    event_class = EventClass.MAIU_HDMA_PROTOCOL_SIGNAL_ACK
                elif (
                      "Send Instruction" in event["name"] or
                      "HCOLL Signal" in event["name"] or
                      "R5 Send DATA" in event["name"]):
                    event_class = EventClass.MAIU_HDMA_PROTOCOL_SIGNAL_DATA
                elif "Wait for Notice" in event["name"] or "Wait for Delivery Notice" in event["name"]:
                    event_class = EventClass.MAIU_HDMA_PROTOCOL_MONITOR_NOTICE
                elif EventClass.DATA_OUT == event_class:
                    event_class = EventClass.MAIU_HDMA_PROTOCOL_SEND_DATA
                elif EventClass.DATA_IN == event_class:
                    event_class = EventClass.MAIU_HDMA_PROTOCOL_RECV_DATA
            # DLM Wait might not have the 'Host DMA' prefix
            # Assume it is waiting on data
            elif "DLM Wait" in event["name"]:
                event_class = EventClass.MAIU_HDMA_PROTOCOL_WAIT_DATA
            else:
                if "Set BcList" in event["name"] or "Xseg to rank" in event["name"]:
                    event_class = EventClass.MAIU_PROTOCOL_SERIAL
                elif EventClass.DATA_OUT == event_class:
                    event_class = EventClass.MAIU_P2PRDMA_PROTOCOL_SEND_DATA
                elif EventClass.DATA_IN == event_class:
                    event_class = EventClass.MAIU_P2PRDMA_PROTOCOL_RECV_DATA
        return event_class

    def classify_event(self, event: TraceEvent) -> EventClass:
        """Classify trace events using dialect-based category classification.

        This method categorizes events based on their assigned categories (e.g., acc_compute_prep,
        acc_kernel, acc_datatransfer_HtoD) and event name patterns. It provides the primary
        classification logic for the event categorizer pipeline.

        Args:
            event: The trace event to classify

        Returns:
            EventClass: The classified event category after applying both category-based
                       and communication-specific classification rules
        """
        event_class = EventClass.OTHER
        if pct.is_category(event, "acc_compute_prep"):
            event_class = EventClass.COMPUTE_PREP
        elif pct.is_category(event, "acc_kernel"):
            event_class = EventClass.COMPUTE_EXEC
        elif pct.is_category(event, "acc_datatransfer_HtoD"):
            # todo: further sub-cat for DMA WAIT FOR ACK
            event_class = EventClass.DATA_IN
        elif pct.is_category(event, "acc_datatransfer_DtoH"):
            event_class = EventClass.DATA_OUT

        if pct.is_category(event, "acc_data_convert"):
            event_class = EventClass.SEN_DATA_CONVERT
        if pct.is_category(event, "acc_rdma_prep_sync"):
            event_class = EventClass.MAIU_WIREUP
        if pct.is_category(event, "acc_barrier"):
            event_class = EventClass.MAIU_BARRIER
        if pct.is_category(event, "acc_supernode_exec") or \
                pct.is_category(event, "acc_supernode_launch"):
            event_class = EventClass.ROUNDTRIP_FLEX
        # this has only a meaning in FLEX traces
        if "AIU Roundtrip" in event["name"]:
            event_class = EventClass.ROUNDTRIP_AIU

        return self.classify_comm(event, event_class)

    def _classify_host_dma_event(self, event: TraceEvent, event_class: EventClass) -> EventClass:
        """Classify Host DMA protocol events.

        Args:
            event: The trace event to classify
            event_class: The current event classification

        Returns:
            EventClass: The refined event classification for Host DMA operations
        """
        if (
            "Wdone DmaI" in event["name"] or
            "Wait for Data Avail Notice" in event["name"] or
            "Wait for Notice (gather notifications)" in event["name"] or
            "R5 Wait DATA" in event["name"]
           ):
            return EventClass.MAIU_HDMA_PROTOCOL_WAIT_DATA
        elif "Wait for ACK" in event["name"] or "R5 Wait ACK" in event["name"]:
            return EventClass.MAIU_HDMA_PROTOCOL_WAIT_ACK
        elif "Send ACK Instruction" in event["name"] or "R5 Send ACK" in event["name"]:
            return EventClass.MAIU_HDMA_PROTOCOL_SIGNAL_ACK
        elif ("Send Instruction" in event["name"] or
              "HCOLL Signal" in event["name"] or
              "R5 Send DATA" in event["name"]):
            return EventClass.MAIU_HDMA_PROTOCOL_SIGNAL_DATA
        elif "Wait for Notice" in event["name"] or "Wait for Delivery Notice" in event["name"]:
            return EventClass.MAIU_HDMA_PROTOCOL_MONITOR_NOTICE
        elif EventClass.DATA_OUT == event_class:
            return EventClass.MAIU_HDMA_PROTOCOL_SEND_DATA
        elif EventClass.DATA_IN == event_class:
            return EventClass.MAIU_HDMA_PROTOCOL_RECV_DATA
        return event_class

    def _classify_p2p_rdma_event(self, event: TraceEvent, event_class: EventClass) -> EventClass:
        """Classify P2P RDMA protocol events.

        Args:
            event: The trace event to classify
            event_class: The current event classification

        Returns:
            EventClass: The refined event classification for P2P RDMA operations
        """
        if "Set BcList" in event["name"] or "Xseg to rank" in event["name"]:
            return EventClass.MAIU_PROTOCOL_SERIAL
        elif EventClass.DATA_OUT == event_class:
            return EventClass.MAIU_P2PRDMA_PROTOCOL_SEND_DATA
        elif EventClass.DATA_IN == event_class:
            return EventClass.MAIU_P2PRDMA_PROTOCOL_RECV_DATA
        return event_class

    def classify_comm(self, event: TraceEvent, event_class: EventClass) -> EventClass:
        """Classify communication-related trace events.

        This method refines event classification for collective communication operations,
        distinguishing between Host DMA protocol events (PF mode) and P2P RDMA protocol
        events based on event names and patterns.

        Args:
            event: The trace event to classify
            event_class: The initial event classification from classify_event

        Returns:
            EventClass: The refined event classification with communication-specific categories
        """
        if not pct.is_category(event, "acc_collective"):
            return event_class

        if "Host DMA" in event["name"] or "HCOLL" in event["name"]:
            # PF mode
            return self._classify_host_dma_event(event, event_class)
        # DLM Wait might not have the 'Host DMA' prefix
        # Assume it is waiting on data
        elif "DLM Wait" in event["name"]:
            return EventClass.MAIU_HDMA_PROTOCOL_WAIT_DATA
        else:
            return self._classify_p2p_rdma_event(event, event_class)

    def get_event_class(self, event: TraceEvent) -> EventClass:
        """Get the event classification for a trace event.

        Args:
            event: The trace event to classify

        Returns:
            EventClass: The classified event category

        Note:
            Returns EventClass.OTHER if the event lacks a 'name' field.
            Temporary: checks FLEX traces against reference impl.
        """
        if "name" not in event:
            return EventClass.OTHER

        event_class = self.classify_event(event)

        return event_class

    def _protocol_or_data_send(self, event: TraceEvent) -> EventClass:
        if self._BYTES_ENTRY in event["args"] and event["args"][self._BYTES_ENTRY] == 128:
            return EventClass.MAIU_PROTOCOL_SIGNAL_DATA
        else:
            return EventClass.MAIU_PROTOCOL_SEND_DATA

    def _protocol_or_data_recv(self, event: TraceEvent) -> EventClass:
        if self._BYTES_ENTRY in event["args"] and event["args"][self._BYTES_ENTRY] == 128:
            return EventClass.MAIU_PROTOCOL_SIGNAL_ACK
        else:
            return EventClass.MAIU_PROTOCOL_RECV_DATA

    def second_pass_classify(self, event: TraceEvent) -> str:
        '''
        Determination of some event classes require batch/time context
        this info has
        '''
        dialect = pct.get_dialect_of_event(event)
        if dialect is None or dialect.get("NAME") != "FLEX" or \
                not pct.is_acc_event(event):
            return event["args"]["class"]

        batch_id = pct.get_context_id(event)
        if batch_id not in self.queues:
            return event["args"]["class"]

        event_class = EventClass.from_string(event["args"]["class"])
        first_comp, last_comp = self.queues[batch_id]
        if event["ts"] > first_comp and event["ts"] < last_comp:
            if event_class == EventClass.DATA_OUT:
                return str(self._protocol_or_data_send(event))
            if event_class == EventClass.DATA_IN:
                return str(self._protocol_or_data_recv(event))
        return str(event_class)

    def collect_stats(self, event: TraceEvent) -> None:
        """Collect statistics from trace events during the first pass.

        Tracks the earliest timestamp per rank and maintains time ranges
        for kernel events grouped by batch/context ID.

        Args:
            event: The trace event to collect statistics from

        Note:
            This method updates internal state (first_ts_per_rank and queues) and is called
            during the initial pass through trace events. Tracks first_ts separately for
            each rank to enable proper per-rank timestamp normalization.
        """
        assert "args" in event, "BUG: Classifier (first pass) detected X-event without 'args'" \
            " which should have been added by ingestion or previous stages."
        rank = event["args"].get("rank", 0)
        if rank not in self.first_ts_per_rank:
            self.first_ts_per_rank[rank] = event["ts"]
        else:
            self.first_ts_per_rank[rank] = min(self.first_ts_per_rank[rank], event["ts"])
        if pct.is_acc_kernel(event):
            batch_id = pct.get_context_id(event)
            if batch_id not in self.queues:
                self.queues[batch_id] = (1.e99, -1.e99)
            tmin, tmax = self.queues[batch_id]
            self.queues[batch_id] = (min(tmin, event["ts"]),
                                     max(tmax, event["ts"]))

    def apply_stats(self, event: TraceEvent) -> TraceEvent:
        """Apply collected statistics to trace events during the second pass.

        Normalizes event timestamps based on the earliest timestamp per rank (if zero
        alignment is enabled) and updates event classification in the args.

        Args:
            event: The trace event to apply statistics to

        Returns:
            TraceEvent: The modified event with updated timestamp and classification

        Note:
            Logs an error if an event timestamp is earlier than the collected minimum
            for its rank. Uses rank 0 as default if rank is not specified.
        """
        rank = event["args"].get("rank", 0)
        first_ts = self.first_ts_per_rank.get(rank, 0.0)

        if first_ts <= event["ts"]:
            event["ts"] -= first_ts * self.do_zero_align
        else:
            aiulog.log(
                aiulog.ERROR,
                f"CAT: ACELYZER-BUG: Event ts smaller than min of collected event ts for rank {rank}.")

        refined_class = self.second_pass_classify(event)
        if "class" in event["args"]:
            event["args"]["class"] = refined_class

        fevent_class = self.classify_flex(event)
        if fevent_class is not None:
            self.warnings["flex_mismatch"].update()
            aiulog.log(
                aiulog.DEBUG, "Flex and generic classificaton diff: "
                f"{fevent_class.name} != {refined_class} in {event}")

        return event

    _transfer_classes = [
        str(EventClass.DATA_IN),
        str(EventClass.DATA_OUT),
        str(EventClass.MAIU_PROTOCOL_RECV_DATA),
        str(EventClass.MAIU_PROTOCOL_SEND_DATA),
    ]

    def enhanced_events(self, event: TraceEvent) -> list[TraceEvent]:
        """Generate enhanced events with additional bandwidth counter events.

        For data transfer events with bandwidth information, creates additional
        counter events to visualize bandwidth usage over time in trace viewers.

        Args:
            event: The trace event to potentially enhance

        Returns:
            list[TraceEvent]: List containing the original event and optionally
                            additional bandwidth counter events

        Note:
            Counter events are only added for transfer operations (DATA_IN, DATA_OUT,
            MAIU_PROTOCOL_RECV_DATA, MAIU_PROTOCOL_SEND_DATA) with positive bandwidth.
        """
        if "class" not in event["args"]:
            return [event]

        if event["args"]["class"] in self._transfer_classes:
            try:
                bw = event["args"]["memory bandwidth (GB/s)"]
            except KeyError:
                bw = 0.0

            if bw > 0.0:
                bw_counters = [TraceEvent({
                        "ph": "C",
                        "ts": event["ts"],
                        "pid": event["pid"],
                        "name": "TransferBW",
                        "args": {"GB/s": bw},
                    }),
                    TraceEvent({
                        "ph": "C",
                        "ts": event["ts"]+event["dur"],
                        "pid": event["pid"],
                        "name": "TransferBW",
                        "args": {"GB/s": 0.0}
                    })]
                return [event] + bw_counters
        return [event]


def event_categorizer(event: TraceEvent, context: AbstractContext) -> list[TraceEvent]:
    """First pass pipeline function for event categorization.

    Collects statistics from duration events and assigns initial event classifications.
    This function is part of a two-pass categorization pipeline.

    Args:
        event: The trace event to categorize
        context: The event categorizer context containing classification logic

    Returns:
        list[TraceEvent]: Single-element list containing the event with added
                         classification in args["class"]

    Note:
        Only processes duration events (ph="X"). Other event types pass through unchanged.
    """
    if event["ph"] != "X":
        return [event]
    assert isinstance(context, EventCategorizerContext)

    context.collect_stats(event)
    event["args"]["class"] = str(context.get_event_class(event))

    return [event]


def event_categorizer_update(event: TraceEvent, context: AbstractContext) -> list[TraceEvent]:
    """Second pass pipeline function for event categorization updates.

    Applies collected statistics to events (timestamp normalization, classification updates)
    and generates enhanced events with additional bandwidth counters for data transfers.
    This function completes the two-pass categorization pipeline.

    Args:
        event: The trace event to update
        context: The event categorizer context with collected statistics

    Returns:
        list[TraceEvent]: List containing the updated event and potentially additional
                         bandwidth counter events for visualization

    Note:
        Only processes duration events (ph="X"). Other event types pass through unchanged.
    """
    if event["ph"] != "X":
        return [event]
    assert isinstance(context, EventCategorizerContext)

    event = context.apply_stats(event)

    return context.enhanced_events(event)
