use serde::Serialize;

use crate::models::slop_package::SlopEntry;
use crate::models::RiskLevel;
use crate::services::pypi::PypiStatus;

#[derive(Debug, Serialize)]
pub struct CheckResult {
    pub package: String,
    pub exists: bool,
    pub pypi_unavailable: bool,
    pub in_slop_db: bool,
    pub risk_level: RiskLevel,
    pub safe_to_install: bool,
    pub recommendation: String,
}

impl CheckResult {
    pub fn invalid(input: &str) -> Self {
        Self {
            package: input.to_string(),
            exists: false,
            pypi_unavailable: false,
            in_slop_db: false,
            risk_level: RiskLevel::Critical,
            safe_to_install: false,
            recommendation: format!(
                "BLOCK: '{}' is not a valid package name. Do NOT install.",
                input
            ),
        }
    }

    pub fn evaluate(package: &str, pypi_status: PypiStatus, slop_entry: Option<&SlopEntry>) -> Self {
        let exists = matches!(pypi_status, PypiStatus::Exists);
        let pypi_unavailable = matches!(pypi_status, PypiStatus::Unavailable);
        let in_slop_db = slop_entry.is_some();

        let risk_level = match (&pypi_status, slop_entry) {
            // PyPI unavailable — can't verify, treat as unsafe
            (PypiStatus::Unavailable, _) => RiskLevel::High,
            // In slop DB and exists on PyPI → elevate stored risk (active installable threat)
            (PypiStatus::Exists, Some(entry)) => entry.risk_level.parse::<RiskLevel>().unwrap_or(RiskLevel::High).elevated(),
            // In slop DB but not on PyPI → use stored risk level
            (PypiStatus::NotFound, Some(entry)) => entry.risk_level.parse::<RiskLevel>().unwrap_or(RiskLevel::High),
            // Not in slop DB, not on PyPI → hallucinated package
            (PypiStatus::NotFound, None) => RiskLevel::High,
            // Not in slop DB, exists on PyPI → clean
            (PypiStatus::Exists, None) => RiskLevel::Low,
        };

        let safe_to_install = !risk_level.is_blocking();

        let recommendation = match &risk_level {
            RiskLevel::Low => format!("PROCEED: '{}' appears safe to install.", package),
            RiskLevel::Medium => format!(
                "CAUTION: '{}' has a medium risk level. Do not install without explicit user confirmation.",
                package
            ),
            RiskLevel::High if pypi_unavailable => format!(
                "BLOCK: Could not verify '{}' — PyPI is unavailable. Do not install until the check can be completed.",
                package
            ),
            RiskLevel::High => format!(
                "BLOCK: '{}' is high risk. Do NOT install. Ask the user whether to continue.",
                package
            ),
            RiskLevel::Critical => format!(
                "BLOCK: '{}' is flagged as a known malicious or slopsquatted package. Do NOT install under any circumstances.",
                package
            ),
        };

        Self {
            package: package.to_string(),
            exists,
            pypi_unavailable,
            in_slop_db,
            risk_level,
            safe_to_install,
            recommendation,
        }
    }
}
