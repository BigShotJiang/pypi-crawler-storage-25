use serde::Deserialize;

#[derive(Debug, Deserialize)]
pub struct SlopEntry {
    pub risk_level: String,
    pub hallucination_count: u32,
    pub hallucinated_by: Vec<String>,
    pub notes: Option<String>,
}
