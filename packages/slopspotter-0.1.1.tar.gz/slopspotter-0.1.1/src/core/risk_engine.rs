use crate::models::CheckResult;
use crate::services::pypi::check_pypi;
use crate::services::slop_db::check_slop_db;

fn parse_package_name(input: &str) -> Option<String> {
    let name = input.trim();

    if name.is_empty() || name.len() > 214 {
        return None;
    }

    let name = name
        .split_once('@')
        .or_else(|| name.split_once("~="))
        .or_else(|| name.split_once("!="))
        .or_else(|| name.split_once("=="))
        .or_else(|| name.split_once(">="))
        .or_else(|| name.split_once("<="))
        .or_else(|| name.split_once('>'))
        .or_else(|| name.split_once('<'))
        .map(|(n, _)| n)
        .unwrap_or(name);

    let name = name.trim().to_lowercase();

    if name.chars().all(|c| c.is_alphanumeric() || matches!(c, '-' | '_' | '.')) {
        Some(name)
    } else {
        None
    }
}

pub async fn assess(package: &str) -> CheckResult {
    let Some(package) = parse_package_name(package) else {
        tracing::warn!(input = package, "invalid package name rejected");
        return CheckResult::invalid(package);
    };

    let package = package.as_str();
    let (pypi_status, slop_entry) = tokio::join!(check_pypi(package), check_slop_db(package));
    let result = CheckResult::evaluate(package, pypi_status, slop_entry.as_ref());
    tracing::info!(package, risk_level = ?result.risk_level, safe = result.safe_to_install, "assessment complete");
    result
}
