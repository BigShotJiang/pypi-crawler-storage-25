use std::sync::OnceLock;
use std::time::Duration;

use reqwest::Client;

use crate::models::slop_package::SlopEntry;

fn client() -> &'static Client {
    static CLIENT: OnceLock<Client> = OnceLock::new();
    CLIENT.get_or_init(|| {
        Client::builder()
            .timeout(Duration::from_secs(5))
            .user_agent(concat!(env!("CARGO_PKG_NAME"), "/", env!("CARGO_PKG_VERSION")))
            .build()
            .expect("Failed to build HTTP client")
    })
}

const API_BASE_URL: &str = "https://slopspotter-api-production.up.railway.app";

pub async fn check_slop_db(package: &str) -> Option<SlopEntry> {
    let url = format!("{}/v1/packages/{}", API_BASE_URL, package);

    match client().get(&url).send().await {
        Ok(resp) if resp.status().is_success() => {
            match resp.json::<SlopEntry>().await {
                Ok(entry) => Some(entry),
                Err(e) => {
                    tracing::warn!(package, error = %e, "failed to parse slop API response");
                    None
                }
            }
        }
        Ok(resp) if resp.status() == 404 => None,
        Ok(resp) => {
            tracing::warn!(package, status = %resp.status(), "unexpected slop API response");
            None
        }
        Err(e) => {
            tracing::warn!(package, error = %e, "slop API unavailable");
            None
        }
    }
}
