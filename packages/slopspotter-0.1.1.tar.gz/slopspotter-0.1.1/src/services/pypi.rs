use std::sync::OnceLock;
use std::time::Duration;

use reqwest::Client;

pub enum PypiStatus {
    Exists,
    NotFound,
    Unavailable,
}

fn client() -> &'static Client {
    static CLIENT: OnceLock<Client> = OnceLock::new();
    CLIENT.get_or_init(|| {
        Client::builder()
            .timeout(Duration::from_secs(5))
            .user_agent(concat!(env!("CARGO_PKG_NAME"), "/", env!("CARGO_PKG_VERSION")))
            .build()
            .expect("Failed to build HTTP client")
    })
}

pub async fn check_pypi(package: &str) -> PypiStatus {
    let url = format!("https://pypi.org/pypi/{}/json", package);

    match client().get(&url).send().await {
        Ok(resp) if resp.status().is_success() => PypiStatus::Exists,
        Ok(resp) if resp.status() == 404 => PypiStatus::NotFound,
        Ok(_) => {
            tracing::warn!(package, "PyPI returned unexpected status, treating as unavailable");
            PypiStatus::Unavailable
        }
        Err(e) => {
            tracing::warn!(package, error = %e, "PyPI check failed, treating as unavailable");
            PypiStatus::Unavailable
        }
    }
}
