use slopspotter::models::check_result::CheckResult;
use slopspotter::models::risk_level::RiskLevel;
use slopspotter::models::slop_package::SlopEntry;
use slopspotter::services::pypi::PypiStatus;

fn slop_entry(risk_level: &str) -> SlopEntry {
    SlopEntry {
        risk_level: risk_level.to_string(),
        hallucination_count: 1,
        hallucinated_by: vec!["gpt-4".to_string()],
        notes: None,
    }
}

// --- RiskLevel ---

#[test]
fn risk_level_from_str_valid() {
    assert!(matches!("low".parse::<RiskLevel>().unwrap(), RiskLevel::Low));
    assert!(matches!("medium".parse::<RiskLevel>().unwrap(), RiskLevel::Medium));
    assert!(matches!("high".parse::<RiskLevel>().unwrap(), RiskLevel::High));
    assert!(matches!("critical".parse::<RiskLevel>().unwrap(), RiskLevel::Critical));
}

#[test]
fn risk_level_from_str_case_insensitive() {
    assert!(matches!("LOW".parse::<RiskLevel>().unwrap(), RiskLevel::Low));
    assert!(matches!("HIGH".parse::<RiskLevel>().unwrap(), RiskLevel::High));
    assert!(matches!("CRITICAL".parse::<RiskLevel>().unwrap(), RiskLevel::Critical));
}

#[test]
fn risk_level_from_str_unknown_returns_err() {
    assert!("unknown".parse::<RiskLevel>().is_err());
    assert!("".parse::<RiskLevel>().is_err());
    assert!("garbage".parse::<RiskLevel>().is_err());
}

#[test]
fn risk_level_elevated() {
    assert!(matches!(RiskLevel::Low.elevated(), RiskLevel::Medium));
    assert!(matches!(RiskLevel::Medium.elevated(), RiskLevel::High));
    assert!(matches!(RiskLevel::High.elevated(), RiskLevel::Critical));
    assert!(matches!(RiskLevel::Critical.elevated(), RiskLevel::Critical));
}

#[test]
fn risk_level_is_blocking() {
    assert!(!RiskLevel::Low.is_blocking());
    assert!(RiskLevel::Medium.is_blocking());
    assert!(RiskLevel::High.is_blocking());
    assert!(RiskLevel::Critical.is_blocking());
}

#[test]
fn risk_level_exit_codes() {
    assert_eq!(RiskLevel::Low.exit_code(), 0);
    assert_eq!(RiskLevel::Medium.exit_code(), 1);
    assert_eq!(RiskLevel::High.exit_code(), 2);
    assert_eq!(RiskLevel::Critical.exit_code(), 3);
}

// --- CheckResult::evaluate ---

#[test]
fn clean_package_on_pypi_is_low_risk() {
    let result = CheckResult::evaluate("requests", PypiStatus::Exists, None);
    assert!(matches!(result.risk_level, RiskLevel::Low));
    assert!(result.safe_to_install);
    assert!(!result.in_slop_db);
    assert!(result.exists);
}

#[test]
fn hallucinated_package_not_on_pypi_is_high_risk() {
    let result = CheckResult::evaluate("fake-pkg", PypiStatus::NotFound, None);
    assert!(matches!(result.risk_level, RiskLevel::High));
    assert!(!result.safe_to_install);
    assert!(!result.exists);
}

#[test]
fn flagged_package_not_on_pypi_uses_stored_risk() {
    let entry = slop_entry("high");
    let result = CheckResult::evaluate("test-pkg", PypiStatus::NotFound, Some(&entry));
    assert!(matches!(result.risk_level, RiskLevel::High));
    assert!(!result.safe_to_install);
    assert!(result.in_slop_db);
}

#[test]
fn flagged_package_on_pypi_is_elevated_to_critical() {
    let entry = slop_entry("high");
    let result = CheckResult::evaluate("test-pkg", PypiStatus::Exists, Some(&entry));
    assert!(matches!(result.risk_level, RiskLevel::Critical));
    assert!(!result.safe_to_install);
    assert!(result.in_slop_db);
    assert!(result.exists);
}

#[test]
fn flagged_low_risk_on_pypi_elevates_to_medium() {
    let entry = slop_entry("low");
    let result = CheckResult::evaluate("test-pkg", PypiStatus::Exists, Some(&entry));
    assert!(matches!(result.risk_level, RiskLevel::Medium));
    assert!(!result.safe_to_install);
}

#[test]
fn flagged_critical_on_pypi_stays_critical() {
    let entry = slop_entry("critical");
    let result = CheckResult::evaluate("test-pkg", PypiStatus::Exists, Some(&entry));
    assert!(matches!(result.risk_level, RiskLevel::Critical));
    assert!(!result.safe_to_install);
}

#[test]
fn flagged_medium_not_on_pypi_uses_stored_risk() {
    let entry = slop_entry("medium");
    let result = CheckResult::evaluate("test-pkg", PypiStatus::NotFound, Some(&entry));
    assert!(matches!(result.risk_level, RiskLevel::Medium));
    assert!(!result.safe_to_install);
}

#[test]
fn pypi_unavailable_is_high_risk() {
    let result = CheckResult::evaluate("requests", PypiStatus::Unavailable, None);
    assert!(matches!(result.risk_level, RiskLevel::High));
    assert!(!result.safe_to_install);
    assert!(result.pypi_unavailable);
}

#[test]
fn pypi_unavailable_with_slop_entry_is_still_high_risk() {
    let entry = slop_entry("low");
    let result = CheckResult::evaluate("test-pkg", PypiStatus::Unavailable, Some(&entry));
    assert!(matches!(result.risk_level, RiskLevel::High));
    assert!(!result.safe_to_install);
    assert!(result.pypi_unavailable);
}

#[test]
fn recommendation_contains_package_name() {
    let result = CheckResult::evaluate("my-package", PypiStatus::Exists, None);
    assert!(result.recommendation.contains("my-package"));
}

#[test]
fn recommendation_proceed_for_low_risk() {
    let result = CheckResult::evaluate("requests", PypiStatus::Exists, None);
    assert!(result.recommendation.starts_with("PROCEED"));
}

#[test]
fn recommendation_block_for_high_risk() {
    let result = CheckResult::evaluate("fake-pkg", PypiStatus::NotFound, None);
    assert!(result.recommendation.starts_with("BLOCK"));
}

#[test]
fn recommendation_block_for_pypi_unavailable() {
    let result = CheckResult::evaluate("requests", PypiStatus::Unavailable, None);
    assert!(result.recommendation.starts_with("BLOCK"));
    assert!(result.recommendation.contains("PyPI is unavailable"));
}

// --- input validation ---

#[test]
fn invalid_package_name_with_special_chars_is_critical() {
    let result = CheckResult::invalid("../../etc/passwd");
    assert!(matches!(result.risk_level, RiskLevel::Critical));
    assert!(!result.safe_to_install);
}

#[test]
fn empty_package_name_is_invalid() {
    let result = CheckResult::invalid("");
    assert!(matches!(result.risk_level, RiskLevel::Critical));
    assert!(!result.safe_to_install);
}

#[test]
fn valid_package_names_are_accepted() {
    for name in &["requests", "my-package", "my_package", "my.package", "pkg123"] {
        let result = CheckResult::evaluate(name, PypiStatus::Exists, None);
        assert!(matches!(result.risk_level, RiskLevel::Low), "expected low for {}", name);
    }
}

// --- normalisation ---

#[test]
fn slop_entry_with_unknown_risk_defaults_to_high() {
    let entry = slop_entry("garbage-value");
    let result = CheckResult::evaluate("test-pkg", PypiStatus::NotFound, Some(&entry));
    assert!(matches!(result.risk_level, RiskLevel::High));
}
