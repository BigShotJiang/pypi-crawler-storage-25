use slopspotter::core::risk_engine::assess;
use slopspotter::models::risk_level::RiskLevel;

// These tests make real network calls to PyPI and the slop API.

#[tokio::test]
#[ignore]
async fn known_safe_package_is_low_risk() {
    let result = assess("requests").await;
    assert_eq!(result.package, "requests");
    assert!(result.exists);
    assert!(!result.in_slop_db);
    assert!(matches!(result.risk_level, RiskLevel::Low));
    assert!(result.safe_to_install);
}

#[tokio::test]
#[ignore]
async fn known_slop_package_is_blocked() {
    let result = assess("express-mongoose").await;
    assert_eq!(result.package, "express-mongoose");
    assert!(result.in_slop_db);
    assert!(!result.safe_to_install);
}

#[tokio::test]
#[ignore]
async fn nonexistent_package_is_high_risk() {
    let result = assess("this-package-does-not-exist-xyz-123456").await;
    assert!(!result.exists);
    assert!(!result.in_slop_db);
    assert!(matches!(result.risk_level, RiskLevel::High));
    assert!(!result.safe_to_install);
}

#[tokio::test]
#[ignore]
async fn version_suffix_is_stripped() {
    let with_version = assess("requests@2.31.0").await;
    let without_version = assess("requests").await;
    assert_eq!(with_version.package, without_version.package);
    assert_eq!(with_version.exists, without_version.exists);
}

#[tokio::test]
#[ignore]
async fn input_is_normalised_to_lowercase() {
    let lower = assess("requests").await;
    let upper = assess("REQUESTS").await;
    assert_eq!(lower.package, upper.package);
    assert_eq!(lower.exists, upper.exists);
    assert!(matches!(lower.risk_level, RiskLevel::Low));
    assert!(matches!(upper.risk_level, RiskLevel::Low));
}

#[tokio::test]
#[ignore]
async fn invalid_package_name_is_blocked() {
    let result = assess("../../etc/passwd").await;
    assert!(!result.safe_to_install);
    assert!(matches!(result.risk_level, RiskLevel::Critical));
}

#[tokio::test]
#[ignore]
async fn empty_package_name_is_blocked() {
    let result = assess("").await;
    assert!(!result.safe_to_install);
    assert!(matches!(result.risk_level, RiskLevel::Critical));
}
