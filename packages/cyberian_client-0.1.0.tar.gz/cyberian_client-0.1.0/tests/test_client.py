"""
Smoke tests for the Cyberian Client.

Uses httpx.MockTransport to fake the API. We're not testing the
coordinator's logic here (the TS test suite owns that) — just that
the client constructs the right requests and parses the right
responses.
"""
from __future__ import annotations

import json

import httpx
import numpy as np
import pytest

from cyberian import (
    ApiError,
    AuthError,
    Client,
    JobFailedError,
    QuotaError,
    RateLimitError,
    ServiceBusyError,
    TrialExpiredError,
    VerificationFailedError,
)


def make_client(handler):
    transport = httpx.MockTransport(handler)
    http = httpx.Client(
        base_url="https://api.test",
        transport=transport,
        headers={"Authorization": "Bearer cyb_test_" + "a" * 32, "Content-Type": "application/json"},
    )
    return Client(api_key="cyb_test_" + "a" * 32, base_url="https://api.test", http_client=http)


def test_client_rejects_non_cyb_key():
    with pytest.raises(AuthError):
        Client(api_key="not-a-cyberian-key")


def test_health():
    def handler(req):
        assert req.url.path == "/health"
        return httpx.Response(200, json={"ok": True, "service": "coordinator"})

    c = make_client(handler)
    assert c.health() == {"ok": True, "service": "coordinator"}


def test_get_account():
    def handler(req):
        assert req.url.path == "/account"
        assert req.headers["authorization"].startswith("Bearer cyb_test_")
        return httpx.Response(200, json={"tier": "free", "subscription_status": "trial"})

    c = make_client(handler)
    info = c.get_account()
    assert info["tier"] == "free"


def test_submit_job_serializes_body():
    captured = {}

    def handler(req):
        captured["body"] = json.loads(req.content)
        return httpx.Response(201, json={"id": "abc-123", "status": "EXECUTING"})

    c = make_client(handler)
    out = c.submit_job(spec_yaml="version: 1.0", input_texts=["a", "b"])
    assert out["id"] == "abc-123"
    assert captured["body"] == {"spec_yaml": "version: 1.0", "input_texts": ["a", "b"]}


def test_get_job_output_decodes_to_ndarray():
    # Pretend the server returned 6 floats = 3 rows × 2 cols.
    raw = np.array([[1.0, 2.0], [3.0, 4.0], [5.0, 6.0]], dtype=np.float32).tobytes()

    def handler(req):
        assert req.url.path == "/jobs/job-99/output"
        return httpx.Response(
            200,
            content=raw,
            headers={
                "x-cyberian-shape": "3,2",
                "x-cyberian-dtype": "float32",
                "content-type": "application/octet-stream",
            },
        )

    c = make_client(handler)
    arr = c.get_job_output("job-99")
    assert arr.shape == (3, 2)
    assert arr.dtype == np.float32
    assert arr[1, 0] == 3.0


def test_wait_for_completion_terminates_on_settled():
    seq = iter(["EXECUTING", "PROVING", "SETTLED"])

    def handler(req):
        return httpx.Response(200, json={"id": "j", "status": next(seq), "receipt_id": "r"})

    c = make_client(handler)
    final = c.wait_for_completion("j", poll_interval_sec=0.001, timeout_sec=2.0)
    assert final["status"] == "SETTLED"


def test_wait_for_completion_raises_on_failed():
    def handler(req):
        return httpx.Response(200, json={"id": "j", "status": "FAILED"})

    c = make_client(handler)
    with pytest.raises(JobFailedError):
        c.wait_for_completion("j", poll_interval_sec=0.001, timeout_sec=2.0)


def test_402_trial_expired_raises_typed():
    def handler(req):
        return httpx.Response(
            402,
            json={"error": "trial_expired", "message": "Your trial has ended"},
        )

    c = make_client(handler)
    with pytest.raises(TrialExpiredError):
        c.submit_job(spec_yaml="x", input_texts=["a"])


def test_402_quota_raises_quota_error():
    def handler(req):
        return httpx.Response(402, json={"error": "quota_exceeded", "message": "out of chunks"})

    c = make_client(handler)
    with pytest.raises(QuotaError):
        c.submit_job(spec_yaml="x", input_texts=["a"])


def test_413_oversize_raises_quota_error():
    def handler(req):
        return httpx.Response(413, json={"error": "request_too_large"})

    c = make_client(handler)
    with pytest.raises(QuotaError):
        c.submit_job(spec_yaml="x", input_texts=["a"])


def test_429_rate_limited_carries_retry_after():
    def handler(req):
        return httpx.Response(
            429,
            headers={"retry-after": "42"},
            json={"error": "rate_limited"},
        )

    c = make_client(handler)
    with pytest.raises(RateLimitError) as ei:
        c.submit_job(spec_yaml="x", input_texts=["a"])
    assert ei.value.retry_after_sec == 42


def test_503_busy_carries_retry_after():
    def handler(req):
        return httpx.Response(
            503,
            headers={"retry-after": "20"},
            json={"error": "service_busy"},
        )

    c = make_client(handler)
    with pytest.raises(ServiceBusyError) as ei:
        c.submit_job(spec_yaml="x", input_texts=["a"])
    assert ei.value.retry_after_sec == 20


def test_verify_outputs_422_raises_verification_failed():
    def handler(req):
        return httpx.Response(
            422,
            json={"error": "verification_failed", "reason": "commitments differ"},
        )

    c = make_client(handler)
    with pytest.raises(VerificationFailedError):
        c.verify_outputs(spec_yaml="x", input_texts=["a"], claimed_output_commitment="0" * 64)


def test_unknown_error_falls_through_to_apierror():
    def handler(req):
        return httpx.Response(418, json={"error": "i_am_a_teapot"})

    c = make_client(handler)
    with pytest.raises(ApiError):
        c.submit_job(spec_yaml="x", input_texts=["a"])
