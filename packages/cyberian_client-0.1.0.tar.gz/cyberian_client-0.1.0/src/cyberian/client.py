"""
Cyberian Systems client — Phase 2 SDK.

The Bearer key is the credential. There's no separate login; the key
is granted by /auth/register (use the /signup page on the website) or
issued by an operator.

Quick start:

    from cyberian import Client

    c = Client(api_key="cyb_trial_…")

    # One-shot: submit, wait, fetch receipt + outputs
    result = c.submit_and_wait(
        spec_yaml=open("spec.yaml").read(),
        input_texts=["sentence one", "sentence two"],
    )
    print(result.receipt["receipt_hash"])
    print(result.embeddings.shape)  # (2, 384)  for BGE-small

    # Or step-by-step
    job = c.submit_job(spec_yaml=…, input_texts=[…])
    final = c.wait_for_completion(job["id"])
    receipt = c.get_receipt(final["receipt_id"])
    verification = c.verify_receipt(final["receipt_id"])
    embeddings = c.get_job_output(final["id"])  # numpy ndarray

    # VaaS — verify a commitment for inference you ran yourself
    receipt = c.verify_outputs(
        spec_yaml=…,
        input_texts=[…],
        claimed_output_commitment="sha256-hex-of-your-output",
    )

    # Account info, key management
    info = c.get_account()
    new_key = c.rotate_key()
    c.revoke_key(key_id="abc123def456")
"""
from __future__ import annotations

import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import httpx
import numpy as np

from .exceptions import (
    ApiError,
    AuthError,
    CyberianError,
    JobFailedError,
    QuotaError,
    RateLimitError,
    ServiceBusyError,
    TrialExpiredError,
    VerificationFailedError,
)

DEFAULT_API_URL = "https://api.cyberiansystems.ai"


@dataclass
class JobResult:
    """Returned by submit_and_wait. Bundles the three things customers
    most often need at the end of a job: the final job state, the full
    receipt, and the decoded output embeddings."""

    job: dict[str, Any]
    receipt: dict[str, Any]
    embeddings: np.ndarray
    verification: dict[str, Any] | None = None


class Client:
    """Synchronous Cyberian Systems API client."""

    def __init__(
        self,
        api_key: str,
        *,
        base_url: str = DEFAULT_API_URL,
        timeout: float = 60.0,
        http_client: httpx.Client | None = None,
    ):
        if not api_key or not api_key.startswith("cyb_"):
            raise AuthError(
                "api_key must be a Cyberian Bearer key (starts with cyb_). "
                "Mint one via the /signup page or via /auth/register."
            )
        self.base_url = base_url.rstrip("/")
        self._owns_http = http_client is None
        self._http = http_client or httpx.Client(
            base_url=self.base_url,
            timeout=timeout,
            headers={
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json",
            },
        )

    # ─── core HTTP wrapper ────────────────────────────────────────────────

    def _request(
        self,
        method: str,
        path: str,
        *,
        json: Any = None,
        expect_json: bool = True,
    ) -> Any:
        try:
            resp = self._http.request(method, path, json=json)
        except httpx.RequestError as exc:
            raise ApiError(f"network error talking to {path}: {exc}") from exc

        if resp.status_code < 400:
            if not expect_json:
                return resp
            if resp.status_code == 204 or not resp.content:
                return None
            return resp.json()

        # 4xx/5xx — translate to typed exceptions.
        try:
            body = resp.json()
        except Exception:
            body = {"raw": resp.text}

        msg = body.get("message") or body.get("error") or f"HTTP {resp.status_code}"
        retry_after = int(resp.headers.get("retry-after", 0) or 0) or body.get("retry_after_sec", 0)

        if resp.status_code == 401 or resp.status_code == 403:
            raise AuthError(msg, status_code=resp.status_code, body=body)
        if resp.status_code == 402:
            err = (body.get("error") or "").lower()
            if "trial" in err:
                raise TrialExpiredError(msg, status_code=402, body=body)
            raise QuotaError(msg, status_code=402, body=body)
        if resp.status_code == 413:
            raise QuotaError(msg, status_code=413, body=body)
        if resp.status_code == 429:
            raise RateLimitError(msg, retry_after_sec=retry_after or 60, status_code=429, body=body)
        if resp.status_code == 503:
            raise ServiceBusyError(msg, retry_after_sec=retry_after or 30, status_code=503, body=body)
        raise ApiError(msg, status_code=resp.status_code, body=body)

    # ─── public surface ──────────────────────────────────────────────────

    def health(self) -> dict[str, Any]:
        """GET /health — connectivity probe; doesn't require auth."""
        return self._request("GET", "/health")

    def get_account(self) -> dict[str, Any]:
        """GET /account — tier, trial status, usage, key list."""
        return self._request("GET", "/account")

    def rotate_key(self) -> str:
        """POST /auth/keys/rotate — returns the NEW plaintext key. Old key
        remains valid until you call revoke_key with its key_id."""
        body = self._request("POST", "/auth/keys/rotate")
        return body["api_key"]

    def revoke_key(self, *, key_id: str) -> None:
        """POST /auth/keys/revoke — invalidate the key with the given 12-
        char key_id prefix. Idempotent."""
        self._request("POST", "/auth/keys/revoke", json={"key_id": key_id})

    def submit_job(
        self,
        *,
        spec_yaml: str | Path,
        input_texts: list[str],
    ) -> dict[str, Any]:
        """POST /jobs — submit a verified inference batch."""
        spec_text = _read_spec(spec_yaml)
        return self._request(
            "POST",
            "/jobs",
            json={"spec_yaml": spec_text, "input_texts": input_texts},
        )

    def get_job(self, job_id: str) -> dict[str, Any]:
        """GET /jobs/:id — current job status."""
        return self._request("GET", f"/jobs/{job_id}")

    def get_job_results(self, job_id: str) -> dict[str, Any]:
        """GET /jobs/:id/results — per-chunk progress (status, commitments)."""
        return self._request("GET", f"/jobs/{job_id}/results")

    def get_job_output(self, job_id: str) -> np.ndarray:
        """GET /jobs/:id/output — decoded float32 embeddings as a 2D ndarray.

        Shape is (total_input_texts, output_dimensions). Only available
        after the job reaches SETTLED.
        """
        resp = self._request("GET", f"/jobs/{job_id}/output", expect_json=False)
        shape_h = resp.headers.get("x-cyberian-shape", "")
        try:
            rows, cols = (int(p.strip()) for p in shape_h.split(","))
        except Exception as exc:
            raise ApiError(f"unexpected x-cyberian-shape header: {shape_h!r}") from exc
        return np.frombuffer(resp.content, dtype=np.float32).reshape(rows, cols)

    def get_receipt(self, receipt_id: str) -> dict[str, Any]:
        """GET /receipts/:id — full Merkle receipt JSON."""
        return self._request("GET", f"/receipts/{receipt_id}")

    def verify_receipt(self, receipt_id: str) -> dict[str, Any]:
        """GET /receipts/:id/verify — coordinator re-verifies the receipt's
        self-referential hash and the input/output Merkle roots from
        stored chunk commitments. Returns
        {valid, checks: {receipt_hash, input_root, output_root, proof_root}, errors}.
        """
        return self._request("GET", f"/receipts/{receipt_id}/verify")

    def wait_for_completion(
        self,
        job_id: str,
        *,
        poll_interval_sec: float = 2.0,
        timeout_sec: float = 600.0,
    ) -> dict[str, Any]:
        """Poll GET /jobs/:id until SETTLED, FAILED, or REFUNDED, or timeout.

        Raises JobFailedError on FAILED. Returns the final job dict.
        """
        deadline = time.monotonic() + timeout_sec
        terminal = {"SETTLED", "FAILED", "REFUNDED"}
        while True:
            job = self.get_job(job_id)
            if job["status"] in terminal:
                if job["status"] == "FAILED":
                    raise JobFailedError(job_id, body=job)
                return job
            if time.monotonic() > deadline:
                raise CyberianError(
                    f"Job {job_id} did not reach a terminal state in {timeout_sec}s "
                    f"(last status: {job['status']})"
                )
            time.sleep(poll_interval_sec)

    def submit_and_wait(
        self,
        *,
        spec_yaml: str | Path,
        input_texts: list[str],
        poll_interval_sec: float = 2.0,
        timeout_sec: float = 600.0,
        verify_receipt: bool = True,
    ) -> JobResult:
        """One-shot helper: submit_job → wait_for_completion → get_receipt
        → get_job_output → optionally verify_receipt. Most customers will
        only ever call this method.
        """
        job = self.submit_job(spec_yaml=spec_yaml, input_texts=input_texts)
        final = self.wait_for_completion(
            job["id"],
            poll_interval_sec=poll_interval_sec,
            timeout_sec=timeout_sec,
        )
        receipt = self.get_receipt(final["receipt_id"])
        embeddings = self.get_job_output(final["id"])
        verification = self.verify_receipt(final["receipt_id"]) if verify_receipt else None
        if verification and not verification.get("valid", False):
            raise VerificationFailedError(
                receipt_id=final["receipt_id"],
                checks=verification.get("checks", {}),
                errors=verification.get("errors", []),
            )
        return JobResult(
            job=final,
            receipt=receipt,
            embeddings=embeddings,
            verification=verification,
        )

    # ─── VaaS ────────────────────────────────────────────────────────────

    def verify_outputs(
        self,
        *,
        spec_yaml: str | Path,
        input_texts: list[str],
        claimed_output_commitment: str,
    ) -> dict[str, Any]:
        """POST /verify — Verification as a Service. You ran inference on
        your own infrastructure; we re-execute on ours and confirm your
        SHA-256 commitment matches.

        Phase 2 supports single-chunk only — input_texts.length must fit
        in one chunk per the spec's chunk_size.

        Returns the receipt on success (HTTP 200). Raises
        VerificationFailedError on commitment mismatch (HTTP 422).
        """
        spec_text = _read_spec(spec_yaml)
        try:
            return self._request(
                "POST",
                "/verify",
                json={
                    "spec_yaml": spec_text,
                    "input_texts": input_texts,
                    "claimed_output_commitment": claimed_output_commitment,
                },
            )
        except ApiError as exc:
            if exc.status_code == 422:
                raise VerificationFailedError(
                    receipt_id="(no receipt issued)",
                    checks={"output_match": False},
                    errors=[exc.body.get("reason") if isinstance(exc.body, dict) else str(exc.body)],
                ) from exc
            raise

    # ─── lifecycle ───────────────────────────────────────────────────────

    def close(self) -> None:
        if self._owns_http:
            self._http.close()

    def __enter__(self) -> "Client":
        return self

    def __exit__(self, *_: object) -> None:
        self.close()


def _read_spec(spec: str | Path) -> str:
    """Accept either a YAML string or a path to a YAML file."""
    if isinstance(spec, Path):
        return spec.read_text()
    if isinstance(spec, str):
        # Heuristic: treat as a path if it looks file-y AND the file exists.
        # Otherwise treat as inline YAML.
        if "\n" not in spec and len(spec) < 4096:
            try:
                p = Path(spec)
                if p.exists() and p.is_file():
                    return p.read_text()
            except (OSError, ValueError):
                pass
        return spec
    raise TypeError(f"spec_yaml must be str or Path, got {type(spec).__name__}")
