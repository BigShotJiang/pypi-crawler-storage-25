"""Cyberian Systems — Python client for the verified-inference API."""

from .client import Client, JobResult
from .exceptions import (
    ApiError,
    AuthError,
    CyberianError,
    JobFailedError,
    QuotaError,
    RateLimitError,
    ServiceBusyError,
    TrialExpiredError,
    VerificationFailedError,
)

__version__ = "0.1.0"

__all__ = [
    "Client",
    "JobResult",
    "CyberianError",
    "AuthError",
    "TrialExpiredError",
    "QuotaError",
    "RateLimitError",
    "ServiceBusyError",
    "JobFailedError",
    "VerificationFailedError",
    "ApiError",
]
