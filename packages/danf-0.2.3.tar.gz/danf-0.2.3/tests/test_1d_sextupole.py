"""Test 1D normal form: rotation + sextupole kick.

For a thin sextupole of strength k2 at a location with beta function β
and phase advance μ, the first-order ADTS (to leading order in k2) is:

  dν/dJ = -(3 k2² β³) / (16π) · [1 / sin(3μ)] (for a single sextupole)

Wait, actually for a simple one-turn map consisting of a rotation by μ
followed by a sextupole kick Δpx = -k2·x²/2, the detuning is:

  dν/dε = ... (need to derive)

Let's verify the normal form code by comparing with direct tracking
(tune vs amplitude from FFT).
"""

import numpy as np
from daceypy import DA

# Initialize DA: order 5, 2 variables (x, px)
DA.init(5, 2)

# Parameters
mu = 2 * np.pi * 0.31  # tune ν = 0.31 (not near any low-order resonance)
k2 = 10.0              # sextupole strength
L_sext = 0.1           # sextupole length (thin lens)
k2L = k2 * L_sext      # integrated strength

# Build the one-turn map:
# Step 1: Rotation by μ
# Step 2: Thin sextupole kick: px → px - (k2L/2) x²
x = DA(1)    # DA variable 1
px = DA(2)   # DA variable 2

# Rotation
x_rot = x * np.cos(mu) + px * np.sin(mu)
px_rot = -x * np.sin(mu) + px * np.cos(mu)

# Sextupole kick (thin lens)
x_final = x_rot
px_final = px_rot - (k2L / 2) * x_rot ** 2

print("=== One-turn DA map ===")
print(f"x'  = {x_final}")
print(f"px' = {px_final}")

# Verify: Jacobian should be the rotation matrix
J = np.array([
    [x_final.getCoefficient([1, 0]), x_final.getCoefficient([0, 1])],
    [px_final.getCoefficient([1, 0]), px_final.getCoefficient([0, 1])],
])
print(f"\nJacobian:\n{J}")
print(f"det(J) = {np.linalg.det(J):.6f} (should be 1 for symplectic)")

# Compute normal form
from danf import NormalForm
nf = NormalForm([x_final, px_final])
nf.compute()

print(f"\n=== Normal Form Results ===")
print(f"Tune: {nf.tunes[0]:.6f} (expected: {mu/(2*np.pi):.6f})")
print(f"Detuning (dν/dJ): {nf.detuning.get('dnux_dJx', 'N/A')}")
print(f"Detuning (dν/dε): {nf.detuning.get('dnux_depsx', 'N/A')}")

# Verify by tracking: measure tune at different amplitudes
print(f"\n=== Tracking verification ===")
from scipy.signal import find_peaks

for amp in [0.001, 0.002, 0.005, 0.01]:
    xx, ppx = amp, 0.0
    positions = []
    for _ in range(2048):
        xx_new = float(x_final.eval(np.array([xx, ppx])))
        ppx_new = float(px_final.eval(np.array([xx, ppx])))
        xx, ppx = xx_new, ppx_new
        positions.append(xx)

    # FFT to get tune
    positions = np.array(positions)
    spectrum = np.abs(np.fft.fft(positions))
    freqs = np.fft.fftfreq(len(positions))
    # Find the peak in positive frequencies
    pos_mask = freqs > 0
    peak_idx = np.argmax(spectrum[pos_mask])
    tune_tracked = freqs[pos_mask][peak_idx]

    J_val = amp**2 / 2  # action at this amplitude (β=1 in normalized coords)
    print(f"  amp={amp:.4f}, J={J_val:.6f}, tune={tune_tracked:.6f}")

nu0 = nf.tunes[0]
alpha = nf.detuning.get('dnux_dJx', 0)
print(f"\nPredicted: ν(J) = {nu0:.6f} + {alpha:.4f} · J")
print(f"At J=0.00005 (amp=0.01): ν = {nu0 + alpha * 0.00005:.6f}")
