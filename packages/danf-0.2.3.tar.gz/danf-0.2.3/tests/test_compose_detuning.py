"""Extract detuning by composing the DA map N times.

Compose M^N as DA, then extract the rotation angle as a function of J.
No normal form needed — pure DA composition.
"""
import numpy as np
from daceypy import DA

DA.init(5, 2)

nu = 0.31
mu = 2 * np.pi * nu
S = 1.0

x = DA(1)
px = DA(2)

# Build one-turn map
x_rot = x * np.cos(mu) + px * np.sin(mu)
px_rot = -x * np.sin(mu) + px * np.cos(mu)
x1 = x_rot
px1 = px_rot - (S / 2) * x_rot ** 2

# Compose N times: M^N
N = 8
xn, pxn = DA(x1), DA(px1)
for i in range(N - 1):
    xn_new = x1.eval([xn, pxn])
    pxn_new = px1.eval([xn, pxn])
    xn, pxn = xn_new, pxn_new

print(f"Composed {N} turns of the map.")

# Extract action-dependent rotation angle.
# After N turns: (xn, pxn) = R(N*mu(J)) * (x, px) + corrections
# The rotation angle can be extracted from:
# cos(N*mu(J)) = (x*xn + px*pxn) / (x^2 + px^2)
# sin(N*mu(J)) = (x*pxn - px*xn) / (x^2 + px^2)

# In DA: numerator = x*xn + px*pxn (DA polynomial)
# The linear part gives cos(N*mu0), the cubic part encodes the detuning.

# Let's use the atan2 approach via tracking at specific amplitudes:
for amp in [0.001, 0.01, 0.05, 0.1, 0.2, 0.3]:
    xn_val = float(xn.eval(np.array([amp, 0.0])))
    pxn_val = float(pxn.eval(np.array([amp, 0.0])))

    # Phase of z_N / z_0 where z = x + ipx
    z0 = amp  # (amp, 0) → z0 = amp/√2... actually z = (x+ipx)/√2
    zn = (xn_val + 1j * pxn_val)
    z0c = amp  # just x, px=0

    # Total phase advance after N turns:
    total_angle = np.angle(zn / z0c)
    # Average tune per turn:
    tune_per_turn = total_angle / (2 * np.pi * N)
    # Handle wrapping: tune should be near 0.31
    # N*nu = N*0.31 = 2.48 turns → angle = 2.48*2π = 15.58 rad
    # But angle wraps to [-π, π], so actual total angle = N*2π*nu mod 2π
    # We need: atan2(Im(zn/z0), Re(zn/z0)) gives the total angle mod 2π
    # The integer part is N*nu_integer

    # Better: compute the tune from the rotation matrix interpretation
    # After N turns with px0=0:
    # xn = A cos(N*2π*nu(J)) where A ≈ amp
    # pxn = -A sin(N*2π*nu(J))
    # So: N*2π*nu(J) = atan2(-pxn, xn) + 2π*k

    angle = np.arctan2(-pxn_val, xn_val)
    # The nominal angle is N*2π*0.31 = N*1.9478
    # modulo 2π: N*1.9478 mod 2π
    nominal = (N * mu) % (2 * np.pi)
    if nominal > np.pi:
        nominal -= 2 * np.pi
    # The angle should be close to nominal
    # Compute nu by unwrapping: angle = N*2π*nu mod 2π
    # nu = (angle + 2π*k) / (N*2π) for some integer k
    # We know nu ≈ 0.31, so N*nu ≈ N*0.31
    # Find k: k = round(N*0.31 - angle/(2π))
    k = round(N * nu - angle / (2 * np.pi))
    total_phase = angle + 2 * np.pi * k
    tune = total_phase / (2 * np.pi * N)

    J = amp ** 2 / 2
    print(f"amp={amp:.3f}, J={J:.6f}, tune={tune:.8f}")

# Fit
print("\nFitting ν(J) = ν₀ + α·J:")
amps_fit = [0.001, 0.01, 0.05, 0.1, 0.2, 0.3]
J_fit, nu_fit = [], []
for amp in amps_fit:
    xn_val = float(xn.eval(np.array([amp, 0.0])))
    pxn_val = float(pxn.eval(np.array([amp, 0.0])))
    angle = np.arctan2(-pxn_val, xn_val)
    k = round(N * nu - angle / (2 * np.pi))
    total_phase = angle + 2 * np.pi * k
    tune = total_phase / (2 * np.pi * N)
    J_fit.append(amp**2 / 2)
    nu_fit.append(tune)

coeffs = np.polyfit(J_fit, nu_fit, 2)
print(f"ν(J) = {coeffs[2]:.8f} + {coeffs[1]:.6f}·J + {coeffs[0]:.2f}·J²")
print(f"dν/dJ = {coeffs[1]:.8f}")
