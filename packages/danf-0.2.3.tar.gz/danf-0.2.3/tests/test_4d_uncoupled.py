"""Regression test: 4D NF on an uncoupled map must match 1D result.

When the 4D map is purely block-diagonal (no cross-plane coupling),
running `NormalForm` on it must reduce to independent 1D normal forms
on each plane. In particular dnuy_dJy in 4D == dnu/dJ in 1D when the
y-plane sub-map is identical.

This test caught a bug (Hamiltonian-recovery bias) in the previous
implementation of ``compute_detuning_2d`` that returned a result
~5/3 too large on this problem.
"""
import numpy as np
from daceypy import DA
from danf import NormalForm


def build_uncoupled_map(mu_x, mu_y, k2L):
    """x-plane: pure rotation. y-plane: rotation + thin sextupole."""
    x = DA(1); px = DA(2); y = DA(3); py = DA(4)
    xp = x * np.cos(mu_x) + px * np.sin(mu_x)
    pxp = -x * np.sin(mu_x) + px * np.cos(mu_x)
    yr = y * np.cos(mu_y) + py * np.sin(mu_y)
    pyr = -y * np.sin(mu_y) + py * np.cos(mu_y)
    yp = yr
    pyp = pyr - (k2L / 2) * yr ** 2
    return [xp, pxp, yp, pyp]


def build_1d_map(mu_y, k2L):
    y = DA(1); py = DA(2)
    yr = y * np.cos(mu_y) + py * np.sin(mu_y)
    pyr = -y * np.sin(mu_y) + py * np.cos(mu_y)
    return [yr, pyr - (k2L / 2) * yr ** 2]


def test_4d_uncoupled_matches_1d():
    mu_x = 2 * np.pi * 0.21
    mu_y = 2 * np.pi * 0.31
    k2L = 1.0

    DA.init(5, 4)
    nf4 = NormalForm(build_uncoupled_map(mu_x, mu_y, k2L))
    nf4.compute()

    DA.init(5, 2)
    nf1 = NormalForm(build_1d_map(mu_y, k2L))
    nf1.compute()

    ref = nf1.detuning['dnux_dJx']
    got = nf4.detuning['dnuy_dJy']
    assert abs(got - ref) < 1e-8, (
        f"4D danf dnuy_dJy = {got:.12f} != 1D ref {ref:.12f} "
        f"(ratio = {got / ref:.6f})"
    )
    assert abs(nf4.detuning['dnux_dJx']) < 1e-10, (
        f"4D dnux_dJx should be 0 on uncoupled map, got "
        f"{nf4.detuning['dnux_dJx']:.2e}"
    )
    assert abs(nf4.detuning['dnuy_dJx']) < 1e-10
    assert abs(nf4.detuning['dnux_dJy']) < 1e-10


if __name__ == "__main__":
    test_4d_uncoupled_matches_1d()
    print("PASSED: 4D NF on uncoupled map matches 1D reference.")
