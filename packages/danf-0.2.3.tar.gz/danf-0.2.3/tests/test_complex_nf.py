"""Test the complex-variable NF against tracking."""
import numpy as np
from daceypy import DA
import sys
sys.path.insert(0, "/home/evaletov/COSY/danf")
from danf.complex_nf import compute_detuning_1d

DA.init(5, 2)

nu = 0.31
mu = 2 * np.pi * nu
S = 1.0  # k₂L

x = DA(1)
px = DA(2)

x_rot = x * np.cos(mu) + px * np.sin(mu)
px_rot = -x * np.sin(mu) + px * np.cos(mu)
x_map = x_rot
px_map = px_rot - (S / 2) * x_rot ** 2

dnu_dJ, c21, nf_x, nf_px = compute_detuning_1d(x_map, px_map, nu)

print(f"c₂₁ = {c21:.8f}")
print(f"dν/dJ (complex NF) = {dnu_dJ:.8f}")

# Tracking verification
amps = [0.01, 0.02, 0.05, 0.1, 0.15, 0.2, 0.25, 0.3]
J_values, tunes = [], []

for amp in amps:
    xx, ppx = amp, 0.0
    n_turns = 16384
    positions = np.zeros(n_turns)
    alive = True
    for n in range(n_turns):
        xx_new = float(x_map.eval(np.array([xx, ppx])))
        ppx_new = float(px_map.eval(np.array([xx, ppx])))
        xx, ppx = xx_new, ppx_new
        positions[n] = xx
        if abs(xx) > 10:
            alive = False
            break
    if not alive:
        continue
    n_pad = n_turns * 32
    window = np.hanning(n_turns)
    spectrum = np.abs(np.fft.fft(positions * window, n=n_pad))
    freqs = np.fft.fftfreq(n_pad)
    pos = freqs > 0
    peak_idx = np.argmax(spectrum[pos])
    idx = np.where(pos)[0][peak_idx]
    if 1 <= idx < len(spectrum) - 1:
        y0 = np.log(spectrum[idx-1]+1e-30)
        y1 = np.log(spectrum[idx]+1e-30)
        y2 = np.log(spectrum[idx+1]+1e-30)
        delta = 0.5 * (y0 - y2) / (y0 - 2*y1 + y2)
        tune = freqs[idx] + delta * (freqs[1] - freqs[0])
    else:
        tune = freqs[idx]
    J_values.append(amp**2 / 2)
    tunes.append(tune)

J_arr = np.array(J_values)
nu_arr = np.array(tunes)
coeffs = np.polyfit(J_arr, nu_arr, 2)
dnu_dJ_tracking = coeffs[1]

print(f"dν/dJ (tracking)   = {dnu_dJ_tracking:.8f}")
print(f"\nSign match: {'YES' if np.sign(dnu_dJ) == np.sign(dnu_dJ_tracking) else 'NO'}")
print(f"Relative difference: {abs(dnu_dJ - dnu_dJ_tracking)/abs(dnu_dJ_tracking)*100:.2f}%")
