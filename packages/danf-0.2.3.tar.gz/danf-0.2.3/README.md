# DANF

Differential Algebra Normal Forms for symplectic maps, built on [DACEyPy](https://github.com/giovannipurpura/daceypy).

Computes amplitude-dependent tune shifts (detuning coefficients) of nonlinear symplectic maps via order-by-order normal form transformation in the complex eigenvector basis.

## Installation

```bash
pip install danf
```

## Quick Start

```python
import numpy as np
from daceypy import DA
from danf import NormalForm
from danf.elements import rotation, thin_sext, compose

# Initialize DA engine: order 7, 2 variables (x, px)
DA.init(7, 2)

# Build a one-turn map: rotation (tune 0.31) + sextupole kick (k2L = 1.0)
one_turn = compose(rotation(0.31), thin_sext(1.0))

# Compute the normal form
nf = NormalForm(one_turn)
nf.compute()

print(f"Tune: {nf.tunes[0]:.6f}")
print(f"dnu/dJ: {nf.detuning['dnux_dJx']:.8f}")
```

## API

### `NormalForm(da_map)`

Main class. Takes a list of DA objects (the symplectic map components) and computes the nonlinear normal form.

- `nf.compute()` - run the full computation
- `nf.tunes` - linear tunes
- `nf.detuning` - dict of amplitude-dependent tune shift coefficients

### `danf.elements`

Convenience functions for building DA maps: `rotation`, `thin_sext`, `thin_quad`, `thin_oct`, `drift`, `compose`.

### `compute_detuning_1d(da_x, da_px, tune)`

Low-level function for 1D normal form computation. Takes map components in normalized (Floquet) coordinates.

## Cross-Validation

Results verified against COSY INFINITY v10.2 (DANF procedure) to 10 significant figures:

| Quantity | DANF (Python) | COSY INFINITY |
|----------|---------------|---------------|
| dnu/dJ   | +0.0121104226 | +0.0121104226 |
