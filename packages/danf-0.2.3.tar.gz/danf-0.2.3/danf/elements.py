"""Standard accelerator elements as DA maps.

Each function returns a list of DA objects representing the symplectic map
components [x', px'] (1 DOF) or [x', px', y', py'] (2 DOF).
"""

import numpy as np
from daceypy import DA


def rotation(tune, ndof=1):
    """Linear rotation (betatron phase advance).

    Parameters
    ----------
    tune : float or array_like
        Fractional tune(s). Scalar for 1 DOF, pair for 2 DOF.
    ndof : int
        Number of degrees of freedom.

    Returns
    -------
    list of DA
        Map components.
    """
    if ndof == 1:
        mu = 2 * np.pi * tune
        c, s = np.cos(mu), np.sin(mu)
        x, px = DA(1), DA(2)
        return [c * x + s * px, -s * x + c * px]
    elif ndof == 2:
        tunes = np.atleast_1d(tune)
        if len(tunes) != 2:
            raise ValueError("2 DOF requires 2 tunes")
        result = []
        for k in range(2):
            mu = 2 * np.pi * tunes[k]
            c, s = np.cos(mu), np.sin(mu)
            xk = DA(2 * k + 1)
            pk = DA(2 * k + 2)
            result.extend([c * xk + s * pk, -s * xk + c * pk])
        return result
    else:
        raise ValueError(f"ndof must be 1 or 2, got {ndof}")


def thin_sext(k2L, ndof=1):
    """Thin sextupole kick.

    Kick: Δpx = -(k2L/2)·x², Δpy = +k2L·x·y  (for 2 DOF)

    Parameters
    ----------
    k2L : float
        Integrated sextupole strength (1/m²).
    ndof : int
        Number of degrees of freedom.

    Returns
    -------
    list of DA
        Map components.
    """
    if ndof == 1:
        x, px = DA(1), DA(2)
        return [x, px - (k2L / 2) * x ** 2]
    elif ndof == 2:
        x, px, y, py = DA(1), DA(2), DA(3), DA(4)
        return [x, px - (k2L / 2) * (x ** 2 - y ** 2),
                y, py + k2L * x * y]
    else:
        raise ValueError(f"ndof must be 1 or 2, got {ndof}")


def thin_quad(k1L, ndof=1):
    """Thin quadrupole kick.

    Kick: Δpx = -k1L·x, Δpy = +k1L·y  (for 2 DOF)

    Parameters
    ----------
    k1L : float
        Integrated quadrupole strength (1/m).
    ndof : int
        Number of degrees of freedom.

    Returns
    -------
    list of DA
        Map components.
    """
    if ndof == 1:
        x, px = DA(1), DA(2)
        return [x, px - k1L * x]
    elif ndof == 2:
        x, px, y, py = DA(1), DA(2), DA(3), DA(4)
        return [x, px - k1L * x, y, py + k1L * y]
    else:
        raise ValueError(f"ndof must be 1 or 2, got {ndof}")


def thin_oct(k3L, ndof=1):
    """Thin octupole kick.

    Kick: Δpx = -(k3L/6)·x³ (1 DOF)

    Parameters
    ----------
    k3L : float
        Integrated octupole strength (1/m³).
    ndof : int
        Number of degrees of freedom.

    Returns
    -------
    list of DA
        Map components.
    """
    if ndof == 1:
        x, px = DA(1), DA(2)
        return [x, px - (k3L / 6) * x ** 3]
    elif ndof == 2:
        x, px, y, py = DA(1), DA(2), DA(3), DA(4)
        return [x, px - (k3L / 6) * (x ** 3 - 3 * x * y ** 2),
                y, py + (k3L / 6) * (3 * x ** 2 * y - y ** 3)]
    else:
        raise ValueError(f"ndof must be 1 or 2, got {ndof}")


def drift(length, ndof=1):
    """Free-space drift.

    Parameters
    ----------
    length : float
        Drift length (m).
    ndof : int
        Number of degrees of freedom.

    Returns
    -------
    list of DA
        Map components (paraxial approximation: x' = x + L·px).
    """
    if ndof == 1:
        x, px = DA(1), DA(2)
        return [x + length * px, px]
    elif ndof == 2:
        x, px, y, py = DA(1), DA(2), DA(3), DA(4)
        return [x + length * px, px, y + length * py, py]
    else:
        raise ValueError(f"ndof must be 1 or 2, got {ndof}")


def compose(map1, map2):
    """Compose two maps: map2 ∘ map1 (apply map1 first, then map2).

    Parameters
    ----------
    map1, map2 : list of DA
        Map components (same dimension).

    Returns
    -------
    list of DA
        Composed map components.
    """
    if len(map1) != len(map2):
        raise ValueError(f"Map dimensions don't match: {len(map1)} vs {len(map2)}")
    return [map2[i].eval(map1) for i in range(len(map1))]
