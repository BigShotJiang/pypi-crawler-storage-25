"""2D (4-variable) complex-variable normal form via Lie algebra.

For a 4D symplectic map, the NF transformation must be canonical. This
requires deriving both delta_z1 and delta_z2 from a single Hamiltonian
generating function W, solved via the homological equation:

  {W, H_0} + h_n = 0

where h_n is the Hamiltonian perturbation at order n, H_0 = mu1*J1 + mu2*J2,
and the Poisson bracket gives:

  W_{k1l1k2l2} = h_n_{k1l1k2l2} / [i * (mu1*(k1-l1) + mu2*(k2-l2))]

The Hamiltonian perturbation h is recovered from the map residual R via:
  h_{k1l1k2l2} = i * R_z1_{k1,l1-1,k2,l2} / l1  (for l1 >= 1)
  h_{k1l1k2l2} = i * R_z2_{k1,l1,k2,l2-1} / l2  (for l2 >= 1)

The resulting transformation delta_zk = -i * dW/d(zk*) is guaranteed
canonical, preserving the symmetry of the detuning matrix.
"""

import numpy as np
from math import comb
from daceypy import DA


def _real_to_complex_1pair(a, b):
    """Expand u^a pu^b in (z, z*) for one DOF."""
    n = a + b
    sq2n = np.sqrt(2) ** n
    result = {}
    for r in range(a + 1):
        for s in range(b + 1):
            k = r + s
            l = (a - r) + (b - s)
            coeff = ((1j) ** b / sq2n
                     * comb(a, r) * comb(b, s) * (-1) ** (b - s))
            key = (k, l)
            result[key] = result.get(key, 0.0) + coeff
    return result


def real_to_complex_monomial_2d(a, b, c, d):
    """Expand u1^a pu1^b u2^c pu2^d in complex (k1,l1,k2,l2)."""
    pair1 = _real_to_complex_1pair(a, b)
    pair2 = _real_to_complex_1pair(c, d)
    result = {}
    for (k1, l1), c1 in pair1.items():
        for (k2, l2), c2 in pair2.items():
            key = (k1, l1, k2, l2)
            result[key] = result.get(key, 0.0) + c1 * c2
    return result


def _complex_to_real_1pair(k, l):
    """Express z^k z*^l in (u, pu) for one DOF."""
    n = k + l
    sq2n = np.sqrt(2) ** n
    result = {}
    for r in range(k + 1):
        for s in range(l + 1):
            a = r + s
            b = (k - r) + (l - s)
            coeff = (1.0 / sq2n
                     * comb(k, r) * (-1j) ** (k - r)
                     * comb(l, s) * (1j) ** (l - s))
            key = (a, b)
            result[key] = result.get(key, 0.0) + coeff
    return result


def complex_to_real_monomial_2d(k1, l1, k2, l2):
    """Express z1^k1 z1*^l1 z2^k2 z2*^l2 in real (a,b,c,d)."""
    pair1 = _complex_to_real_1pair(k1, l1)
    pair2 = _complex_to_real_1pair(k2, l2)
    result = {}
    for (a, b), c1 in pair1.items():
        for (c, d), c2 in pair2.items():
            key = (a, b, c, d)
            result[key] = result.get(key, 0.0) + c1 * c2
    return result


def extract_complex_coefficients_2d(da_map, dof_index, order):
    """Extract complex z-coefficients for z_{dof_index} at given order."""
    j = 2 * dof_index
    da_u = da_map[j]
    da_pu = da_map[j + 1]
    result = {}
    for da_comp, multiplier in [(da_u, 1.0 / np.sqrt(2)),
                                 (da_pu, -1j / np.sqrt(2))]:
        for mono in da_comp.getMonomials():
            if mono.order() != order:
                continue
            jj = mono.m_jj
            a, b, c, d = jj[0], jj[1], jj[2], jj[3]
            real_coeff = mono.m_coeff.value
            expansion = real_to_complex_monomial_2d(a, b, c, d)
            for key, conv_coeff in expansion.items():
                result[key] = result.get(key, 0j) + multiplier * real_coeff * conv_coeff
    return result


def _hamiltonian_from_map_residual(R_z1, R_z2, order):
    """Recover the Hamiltonian perturbation h from map residual (R_z1, R_z2).

    h_{k1,l1,k2,l2} = i * R_z1_{k1,l1-1,k2,l2} / l1   (l1 >= 1)
    h_{k1,l1,k2,l2} = i * R_z2_{k1,l1,k2,l2-1} / l2   (l2 >= 1)
    h_{k1,0,k2,0} = 0  (pure holomorphic terms: no contribution)
    """
    h = {}

    # Collect all possible indices at this order
    all_indices = set()
    for (k1, l1, k2, l2) in R_z1:
        if k1 + l1 + k2 + l2 == order:
            all_indices.add((k1, l1 + 1, k2, l2))  # shift l1
    for (k1, l1, k2, l2) in R_z2:
        if k1 + l1 + k2 + l2 == order:
            all_indices.add((k1, l1, k2, l2 + 1))  # shift l2

    for (k1, l1, k2, l2) in all_indices:
        if k1 + l1 + k2 + l2 != order + 1:
            continue
        if l1 == 0 and l2 == 0:
            continue  # pure holomorphic, skip

        if l1 >= 1:
            # Use z1 equation: h = i * R_z1_{k1,l1-1,k2,l2} / l1
            r_key = (k1, l1 - 1, k2, l2)
            if r_key in R_z1:
                h[(k1, l1, k2, l2)] = 1j * R_z1[r_key] / l1
                continue

        if l2 >= 1:
            # Use z2 equation: h = i * R_z2_{k1,l1,k2,l2-1} / l2
            r_key = (k1, l1, k2, l2 - 1)
            if r_key in R_z2:
                h[(k1, l1, k2, l2)] = 1j * R_z2[r_key] / l2
                continue

    return h


def _generating_function_from_hamiltonian(h, mu1, mu2):
    """Solve homological equation: W = h / [i*(mu1*(k1-l1) + mu2*(k2-l2))].

    Returns W (dict) and the residual resonant terms (dict).
    """
    W = {}
    for (k1, l1, k2, l2), h_kl in h.items():
        D = mu1 * (k1 - l1) + mu2 * (k2 - l2)
        if abs(D) > 1e-8:
            W[(k1, l1, k2, l2)] = h_kl / (1j * D)
        # else: resonant, skip (cannot eliminate)
    return W


def _transformation_from_W(W):
    """Compute delta_z1, delta_z2 from Hamiltonian generating function W.

    delta_z1 = -i * dW/dz1* = -i * sum l1 * W_{k1l1k2l2} z1^k1 z1*^{l1-1} z2^k2 z2*^l2
    delta_z2 = -i * dW/dz2* = -i * sum l2 * W_{k1l1k2l2} z1^k1 z1*^l1 z2^k2 z2*^{l2-1}
    """
    g_z1 = {}
    g_z2 = {}
    for (k1, l1, k2, l2), w_kl in W.items():
        if l1 >= 1:
            key1 = (k1, l1 - 1, k2, l2)
            g_z1[key1] = g_z1.get(key1, 0j) + (-1j) * l1 * w_kl
        if l2 >= 1:
            key2 = (k1, l1, k2, l2 - 1)
            g_z2[key2] = g_z2.get(key2, 0j) + (-1j) * l2 * w_kl
    return g_z1, g_z2


def _build_real_generating_function(g_z1, g_z2):
    """Convert complex generating functions to real DA components."""
    g = [DA(0.0) for _ in range(4)]  # g_u1, g_pu1, g_u2, g_pu2

    for g_complex, g_idx in [(g_z1, 0), (g_z2, 1)]:
        j = 2 * g_idx  # 0 for DOF 0, 2 for DOF 1
        for (k1, l1, k2, l2), c_kl in g_complex.items():
            real_exp = complex_to_real_monomial_2d(k1, l1, k2, l2)
            for (a, b, c, d), real_coeff in real_exp.items():
                full_coeff = c_kl * real_coeff
                exponents = [a, b, c, d]
                cur_u = g[j].getCoefficient(exponents)
                g[j].setCoefficient(exponents, cur_u + np.sqrt(2) * full_coeff.real)
                cur_pu = g[j + 1].getCoefficient(exponents)
                g[j + 1].setCoefficient(exponents, cur_pu - np.sqrt(2) * full_coeff.imag)

    return g


def compute_detuning_2d(da_map, tunes):
    """Compute the 2D detuning matrix using per-plane homological elimination.

    For each plane j, the order-n map residual R_zj is eliminated by a
    near-identity transformation T = id + g via the divisor equation:

      g_zj_{k1,l1,k2,l2} = -R_zj_{k1,l1,k2,l2}
                          / (lam_j - lam1^k1 * lam1*^l1 * lam2^k2 * lam2*^l2)

    This is the direct 4D generalization of the 1D algorithm in
    :func:`~danf.complex_nf.compute_detuning_1d`. Resonant terms
    (divisor ~ 0) are left in the NF and encode the detuning matrix.

    Note: the previous implementation recovered a single Hamiltonian h
    from the residuals and derived g = -i*dW/dz* from it. That preserves
    symplecticity of the transformation but introduces a systematic bias
    in the extracted detuning for polynomial maps (confirmed against
    multi-turn tracking and COSY INFINITY TS).

    Parameters
    ----------
    da_map : list of DA (length 4)
        [u1', pu1', u2', pu2'] in Floquet coordinates.
    tunes : array-like, length 2
        [nu1, nu2] fractional tunes.

    Returns
    -------
    detuning : dict
    nf_map : list of DA (length 4)
    """
    mu1 = 2 * np.pi * tunes[0]
    mu2 = 2 * np.pi * tunes[1]
    lam1 = np.exp(1j * mu1)
    lam2 = np.exp(1j * mu2)
    order = DA.getMaxOrder()

    cur = [DA(m) for m in da_map]

    for n in range(2, order + 1):
        R_z1 = extract_complex_coefficients_2d(cur, 0, n)
        R_z2 = extract_complex_coefficients_2d(cur, 1, n)

        if not R_z1 and not R_z2:
            continue

        g_z1 = {}
        g_z2 = {}
        for (k1, l1, k2, l2), f in R_z1.items():
            mon = lam1 ** k1 * np.conj(lam1) ** l1 * lam2 ** k2 * np.conj(lam2) ** l2
            divisor = lam1 - mon
            if abs(divisor) > 1e-10:
                g_z1[(k1, l1, k2, l2)] = -f / divisor

        for (k1, l1, k2, l2), f in R_z2.items():
            mon = lam1 ** k1 * np.conj(lam1) ** l1 * lam2 ** k2 * np.conj(lam2) ** l2
            divisor = lam2 - mon
            if abs(divisor) > 1e-10:
                g_z2[(k1, l1, k2, l2)] = -f / divisor

        if not g_z1 and not g_z2:
            continue

        g = _build_real_generating_function(g_z1, g_z2)

        # Apply T^{-1} o M o T via Picard iteration
        v = [DA(i + 1) for i in range(4)]

        T = [v[i] + g[i] for i in range(4)]

        Tinv = [DA(v[i]) for i in range(4)]
        for _ in range(order):
            Tinv = [v[i] - g[i].eval(Tinv) for i in range(4)]

        MoT = [cur[i].eval(T) for i in range(4)]
        cur = [Tinv[i].eval(MoT) for i in range(4)]

    # Extract detuning from order-3 NF coefficients
    c3_z1 = extract_complex_coefficients_2d(cur, 0, 3)
    c3_z2 = extract_complex_coefficients_2d(cur, 1, 3)

    c21_xx = c3_z1.get((2, 1, 0, 0), 0j)
    c21_xy = c3_z1.get((1, 0, 1, 1), 0j)
    c21_yy = c3_z2.get((0, 0, 2, 1), 0j)
    c21_yx = c3_z2.get((1, 1, 1, 0), 0j)

    dnux_dJx = (c21_xx / lam1).imag / (2 * np.pi)
    dnux_dJy = (c21_xy / lam1).imag / (2 * np.pi)
    dnuy_dJx = (c21_yx / lam2).imag / (2 * np.pi)
    dnuy_dJy = (c21_yy / lam2).imag / (2 * np.pi)

    return {
        'dnux_dJx': dnux_dJx, 'dnux_dJy': dnux_dJy,
        'dnuy_dJx': dnuy_dJx, 'dnuy_dJy': dnuy_dJy,
        'c21_xx': c21_xx, 'c21_xy': c21_xy,
        'c21_yx': c21_yx, 'c21_yy': c21_yy,
    }, cur
