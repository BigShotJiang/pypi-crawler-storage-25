"""Complex-variable normal form computation.

Solves the homological equation in the complex eigenvector basis (z, z*),
then converts back to real (x, px) coordinates for the DA map composition.

Convention: z = (x - i·px) / √2  (standard accelerator physics)
This gives eigenvalue λ = e^{+iμ} for a rotation by angle μ.
"""

import numpy as np
from math import comb
from daceypy import DA


def real_to_complex_monomial(a, b):
    """Expand x^a px^b in terms of z^k z*^l.

    z = (x - i·px)/√2  →  x = (z + z*)/√2,  px = i(z - z*)/√2

    Returns dict: {(k, l): coefficient} for all (k,l) with k+l = a+b.
    """
    n = a + b
    sq2n = np.sqrt(2) ** n
    result = {}

    # x^a = [(z + z*)/√2]^a = (1/√2)^a Σ_r C(a,r) z^r z*^{a-r}
    # px^b = [i(z - z*)/√2]^b = (i/√2)^b Σ_s C(b,s) z^s (-z*)^{b-s}
    #      = (i/√2)^b Σ_s C(b,s) (-1)^{b-s} z^s z*^{b-s}
    for r in range(a + 1):
        for s in range(b + 1):
            k = r + s
            l = (a - r) + (b - s)
            coeff = ((1j) ** b / sq2n
                     * comb(a, r)
                     * comb(b, s)
                     * (-1) ** (b - s))
            key = (k, l)
            result[key] = result.get(key, 0.0) + coeff

    return result


def complex_to_real_monomial(k, l):
    """Express z^k z*^l in terms of x^a px^b.

    z = (x - i·px)/√2,  z* = (x + i·px)/√2

    Returns dict: {(a, b): coefficient} for all (a,b) with a+b = k+l.
    """
    n = k + l
    sq2n = np.sqrt(2) ** n
    result = {}

    # z^k = [(x - i·px)/√2]^k = (1/√2)^k Σ_r C(k,r) x^r (-i·px)^{k-r}
    # z*^l = [(x + i·px)/√2]^l = (1/√2)^l Σ_s C(l,s) x^s (i·px)^{l-s}
    for r in range(k + 1):
        for s in range(l + 1):
            a = r + s
            b = (k - r) + (l - s)
            coeff = (1.0 / sq2n
                     * comb(k, r) * (-1j) ** (k - r)
                     * comb(l, s) * (1j) ** (l - s))
            key = (a, b)
            result[key] = result.get(key, 0.0) + coeff

    return result


def extract_complex_coefficients(da_x, da_px, order):
    """Extract complex coefficients of z^k z*^l from real DA map.

    The z-component of the map is z' = (x' - i·px') / √2.
    Returns dict: {(k, l): complex coefficient}.
    """
    nvar = DA.getMaxVariables()
    result = {}

    for da_comp, multiplier in [(da_x, 1.0 / np.sqrt(2)),
                                 (da_px, -1j / np.sqrt(2))]:
        for mono in da_comp.getMonomials():
            if mono.order() != order:
                continue
            a = mono.m_jj[0]
            b = mono.m_jj[1]
            real_coeff = mono.m_coeff.value

            expansion = real_to_complex_monomial(a, b)
            for (k, l), conv_coeff in expansion.items():
                key = (k, l)
                result[key] = result.get(key, 0j) + multiplier * real_coeff * conv_coeff

    return result


def build_real_generating_function(g_complex, nvar):
    """Convert complex generating function g(z,z*) to real DA maps g_x, g_px.

    g_complex: dict {(k, l): complex_coeff} for the z-component.
    With z = (x - i·px)/√2:
      x = √2·Re(z)  →  g_x = √2·Re(δz)
      px = -√2·Im(z) →  g_px = -√2·Im(δz)

    Returns (g_x_da, g_px_da) as DA objects.
    """
    pad = [0] * (nvar - 2) if nvar > 2 else []
    g_x = DA(0.0)
    g_px = DA(0.0)

    for (k, l), c_kl in g_complex.items():
        real_expansion = complex_to_real_monomial(k, l)
        for (a, b), real_coeff in real_expansion.items():
            full_coeff = c_kl * real_coeff
            exponents = [a, b] + pad
            g_x.setCoefficient(exponents,
                               g_x.getCoefficient(exponents)
                               + np.sqrt(2) * full_coeff.real)
            g_px.setCoefficient(exponents,
                                g_px.getCoefficient(exponents)
                                - np.sqrt(2) * full_coeff.imag)

    return g_x, g_px


def compute_detuning_1d(da_x, da_px, tune):
    """Compute first-order ADTS for a 1D symplectic map.

    Works by:
    1. Converting order-2 real map coefficients to complex (z, z*) basis
    2. Solving the homological equation in complex variables
    3. Applying the NF transformation via DA composition (Picard inverse)
    4. Extracting the detuning from the order-3 z²z* coefficient

    Convention: z = (x - i·px)/√2, eigenvalue λ = e^{+iμ}.

    Parameters
    ----------
    da_x, da_px : DA
        The one-turn map components in normalized coordinates.
    tune : float
        The linear tune (fractional part).

    Returns
    -------
    dnu_dJ : float
        The first-order amplitude-dependent tune shift dν/dJ.
    """
    mu = 2 * np.pi * tune
    lam = np.exp(1j * mu)
    nvar = DA.getMaxVariables()
    order = DA.getMaxOrder()

    cur_x = DA(da_x)
    cur_px = DA(da_px)

    for n in range(2, order + 1):
        c_coeffs = extract_complex_coefficients(cur_x, cur_px, n)

        if not c_coeffs:
            continue

        # Solve homological equation: R·g - g∘R = -M₂
        # → g_{kl} = -f_{kl} / (λ - λ^k·λ*^l)
        g_complex = {}
        for (k, l), f_kl in c_coeffs.items():
            if k + l != n:
                continue
            divisor = lam - lam ** k * np.conj(lam) ** l
            if abs(divisor) > 1e-10:
                g_complex[(k, l)] = -f_kl / divisor

        if not g_complex:
            continue

        g_x, g_px = build_real_generating_function(g_complex, nvar)

        # Apply T⁻¹ ∘ M ∘ T with exact inverse via Picard iteration
        x_var = DA(1)
        px_var = DA(2)

        T_x = x_var + g_x
        T_px = px_var + g_px

        # Picard iteration for T⁻¹: converges in 'order' steps
        Tinv_x = DA(x_var)
        Tinv_px = DA(px_var)
        for _ in range(order):
            Tinv_x = x_var - g_x.eval([Tinv_x, Tinv_px])
            Tinv_px = px_var - g_px.eval([Tinv_x, Tinv_px])

        # F ∘ T
        FoT_x = cur_x.eval([T_x, T_px])
        FoT_px = cur_px.eval([T_x, T_px])

        # T⁻¹ ∘ (F ∘ T)
        cur_x = Tinv_x.eval([FoT_x, FoT_px])
        cur_px = Tinv_px.eval([FoT_x, FoT_px])

    # Extract detuning from z²z* coefficient of NF map
    c_order3 = extract_complex_coefficients(cur_x, cur_px, 3)
    c21 = c_order3.get((2, 1), 0j)

    # z' = λz + c₂₁·z²z*  →  phase = μ + Im(c₂₁/λ)·|z|²
    # With J = |z|² = zz*: dν/dJ = Im(c₂₁/λ) / (2π)
    dnu_dJ = (c21 / lam).imag / (2 * np.pi)

    return dnu_dJ, c21, cur_x, cur_px
