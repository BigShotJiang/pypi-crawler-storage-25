"""Normal form computation for symplectic DA maps.

Algorithm: order-by-order elimination in the complex eigenvector basis.

For a 2n-dimensional symplectic map M expressed in phase space coordinates
(x1, px1, ..., xn, pxn), the normal form procedure:

1. Extracts the Jacobian matrix and eigendecomposes it to find tunes
   and the Courant-Snyder (Floquet) transformation.

2. Transforms the map to normalized coordinates where the linear part
   is a pure rotation.

3. Order by order, eliminates non-resonant monomials via near-identity
   canonical transformations, leaving only amplitude-dependent terms.

4. The surviving terms encode detuning coefficients (amplitude-dependent
   tune shifts) and resonance driving terms.

Reference: Bazzani, Servizi, Turchetti, "A Normal Form Approach to the
Theory of Nonlinear Betatronic Motion," CERN 94-02 (1994).
"""

import numpy as np
from daceypy import DA, array as DAarray

from danf.complex_nf import compute_detuning_1d


class NormalForm:
    """Compute the normal form of a symplectic map.

    Parameters
    ----------
    da_map : list of DA
        The symplectic map components [x', px', (y', py')].
        Must have 2 components (1 DOF) or 4 components (2 DOF).

    Attributes
    ----------
    ndof : int
        Number of degrees of freedom (1 or 2).
    tunes : ndarray
        Linear tunes [nu_x, (nu_y)].
    detuning : dict
        Amplitude-dependent tune shift coefficients.
    """

    def __init__(self, da_map):
        if isinstance(da_map, DAarray):
            self._map = [da_map[i] for i in range(len(da_map))]
        else:
            self._map = list(da_map)

        dim = len(self._map)
        if dim not in (2, 4):
            raise ValueError(f"Map must have 2 or 4 components, got {dim}")
        self.ndof = dim // 2

        self._order = DA.getMaxOrder()
        self._nvar = DA.getMaxVariables()

        self.tunes = None
        self.detuning = {}
        self._jacobian = None
        self._eigvals = None
        self._eigvecs = None
        self._cs_matrix = None
        self._cs_matrix_inv = None
        self._nf_map = None
        self._computed = False

    def compute(self):
        """Run the full normal form computation."""
        self._extract_jacobian()
        self._linear_normal_form()
        self._transform_to_floquet()
        self._nonlinear_normal_form()
        self._computed = True

    # ------------------------------------------------------------------
    # Step 1: Jacobian extraction
    # ------------------------------------------------------------------

    def _extract_jacobian(self):
        dim = 2 * self.ndof
        self._jacobian = np.zeros((dim, dim))
        for i in range(dim):
            lin = self._map[i].linear()
            self._jacobian[i, :dim] = lin[:dim]

    # ------------------------------------------------------------------
    # Step 2: Linear normal form (eigendecomposition)
    # ------------------------------------------------------------------

    def _linear_normal_form(self):
        M = self._jacobian
        eigenvalues, eigenvectors = np.linalg.eig(M)

        idx = _sort_eigenvalues(eigenvalues, self.ndof)
        eigenvalues = eigenvalues[idx]
        eigenvectors = eigenvectors[:, idx]

        self._eigvals = eigenvalues
        self._eigvecs = eigenvectors

        self.tunes = np.zeros(self.ndof)
        for k in range(self.ndof):
            lam = eigenvalues[2 * k]
            self.tunes[k] = np.angle(lam) / (2 * np.pi)
            if self.tunes[k] < 0:
                self.tunes[k] += 1.0

        self._cs_matrix = _build_real_cs_matrix(eigenvectors, self.ndof)
        self._cs_matrix_inv = np.linalg.inv(self._cs_matrix)

    # ------------------------------------------------------------------
    # Step 3: Transform to Floquet (normalized) coordinates
    # ------------------------------------------------------------------

    def _transform_to_floquet(self):
        dim = 2 * self.ndof
        S = self._cs_matrix
        Sinv = self._cs_matrix_inv

        w = [DA(i + 1) for i in range(dim)]
        phys = _matvec_da(S, w)
        mapped = [self._map[i].eval(phys) for i in range(dim)]
        self._nf_map = _matvec_da(Sinv, mapped)

        # The eigenvector-based CS matrix can produce either rotation
        # direction (tune nu or 1-nu). Extract the actual phase advance
        # from the Floquet map's linear part and update self.tunes.
        for k in range(self.ndof):
            j = 2 * k
            cos_mu = self._nf_map[j].getCoefficient(
                [int(i == j) for i in range(dim)])
            sin_mu = self._nf_map[j].getCoefficient(
                [int(i == j + 1) for i in range(dim)])
            mu = np.arctan2(sin_mu, cos_mu)
            if mu < 0:
                mu += 2 * np.pi
            self.tunes[k] = mu / (2 * np.pi)

    # ------------------------------------------------------------------
    # Step 4: Nonlinear normal form via complex-variable engine
    # ------------------------------------------------------------------

    def _nonlinear_normal_form(self):
        if self.ndof == 1:
            self._nonlinear_nf_1d()
        elif self.ndof == 2:
            self._nonlinear_nf_2d()

    def _nonlinear_nf_1d(self):
        dnu_dJ, c21, nf_x, nf_px = compute_detuning_1d(
            self._nf_map[0], self._nf_map[1], self.tunes[0]
        )

        self._nf_map = [nf_x, nf_px]

        self.detuning = {
            "dnux_dJx": dnu_dJ,
            "alpha_xx": dnu_dJ,
            "c21": c21,
        }

    def _nonlinear_nf_2d(self):
        from danf.complex_nf_2d import compute_detuning_2d

        detuning, nf_map = compute_detuning_2d(self._nf_map, self.tunes)
        self._nf_map = nf_map
        self.detuning = detuning


# ======================================================================
# Helper functions
# ======================================================================

def _sort_eigenvalues(eigenvalues, ndof):
    """Sort eigenvalues into pairs (λ, λ*) with Im(λ) > 0."""
    n = len(eigenvalues)
    used = [False] * n
    order = []

    for _ in range(ndof):
        best = None
        for i in range(n):
            if not used[i] and eigenvalues[i].imag > 0:
                if best is None or abs(eigenvalues[i].imag) > abs(eigenvalues[best].imag):
                    best = i

        if best is None:
            raise ValueError("Cannot find eigenvalue pair with positive imaginary part")

        lam = eigenvalues[best]
        used[best] = True
        order.append(best)

        conj_idx = None
        for i in range(n):
            if not used[i] and abs(eigenvalues[i] - lam.conjugate()) < 1e-10:
                conj_idx = i
                break
        if conj_idx is None:
            raise ValueError("Cannot find conjugate eigenvalue")
        used[conj_idx] = True
        order.append(conj_idx)

    return order


def _build_real_cs_matrix(eigenvectors, ndof):
    """Build real Courant-Snyder matrix from complex eigenvectors."""
    dim = 2 * ndof
    S = np.zeros((dim, dim))

    for k in range(ndof):
        v = eigenvectors[:, 2 * k]
        re_v = v.real
        im_v = v.imag

        j1 = 2 * k
        j2 = 2 * k + 1
        symp_prod = re_v[j1] * im_v[j2] - re_v[j2] * im_v[j1]

        scale = 1.0 / np.sqrt(abs(symp_prod))
        sign = np.sign(symp_prod)

        S[:, j1] = re_v * scale
        S[:, j2] = im_v * scale * sign

    return S


def _matvec_da(matrix, da_vec):
    """Multiply a numpy matrix by a vector of DA objects."""
    dim = len(da_vec)
    result = []
    for i in range(dim):
        s = DA(0.0)
        for j in range(dim):
            s = s + matrix[i, j] * da_vec[j]
        result.append(s)
    return result
