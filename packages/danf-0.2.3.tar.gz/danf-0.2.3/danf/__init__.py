"""DANF — Differential Algebra Normal Forms.

Nonlinear normal form analysis of symplectic maps using differential algebra.
Built on DACEyPy (DACE Python interface).

Inspired by COSY INFINITY (Berz, Makino, Michigan State University).
"""

from danf.normalform import NormalForm
from danf.complex_nf import compute_detuning_1d
from danf import elements

__version__ = "0.2.3"
__all__ = ["NormalForm", "compute_detuning_1d", "elements"]
