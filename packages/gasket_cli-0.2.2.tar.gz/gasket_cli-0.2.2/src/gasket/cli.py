"""Main CLI entry point for gasket."""

from __future__ import annotations

import click

from gasket.commands.run_act import run_act_command
from gasket.commands.setup import setup


@click.group()
@click.version_option(package_name="gasket-cli", prog_name="gasket")
def cli() -> None:
    """Gasket - Run GitHub Actions locally using nektos/act.

    A Python CLI tool that wraps nektos/act to execute GitHub Actions
    workflows locally via Docker.
    """
    pass


cli.add_command(run_act_command)
cli.add_command(setup)
