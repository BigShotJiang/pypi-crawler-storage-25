"""CLI command for running GitHub Actions locally using nektos/act."""

from __future__ import annotations

import sys

import click

from gasket.core.act_runner import find_act_executable, get_act_version, run_act


@click.command("run-act")
@click.option(
    "--event",
    "-e",
    type=click.Choice(
        ["push", "pull_request", "workflow_dispatch", "schedule", "release"],
        case_sensitive=False,
    ),
    default="push",
    help="Event type to trigger.",
)
@click.option(
    "--workflow",
    "-W",
    type=click.Path(),
    default=None,
    help="Specific workflow file or directory to run.",
)
@click.option(
    "--job",
    "-j",
    type=str,
    default=None,
    help="Specific job name to run.",
)
@click.option(
    "--secret",
    "-s",
    multiple=True,
    help="Secret in KEY=VALUE format. Can be specified multiple times.",
)
@click.option(
    "--secret-file",
    type=click.Path(exists=True),
    default=None,
    help="Path to secrets file (.env format).",
)
@click.option(
    "--var",
    multiple=True,
    help="Variable in KEY=VALUE format. Can be specified multiple times.",
)
@click.option(
    "--var-file",
    type=click.Path(exists=True),
    default=None,
    help="Path to variables file (.env format).",
)
@click.option(
    "--input",
    "inputs",
    multiple=True,
    help="Input in KEY=VALUE format for workflow_dispatch. Can be specified multiple times.",
)
@click.option(
    "--input-file",
    type=click.Path(exists=True),
    default=None,
    help="Path to inputs file (.env format).",
)
@click.option(
    "--event-file",
    type=click.Path(exists=True),
    default=None,
    help="Path to event JSON payload file.",
)
@click.option(
    "--platform",
    "-P",
    multiple=True,
    help="Platform override in RUNNER=IMAGE format (e.g. ubuntu-latest=node:16-buster-slim).",
)
@click.option(
    "--env",
    "env_vars",
    multiple=True,
    help="Environment variable in KEY=VALUE format.",
)
@click.option(
    "--env-file",
    type=click.Path(exists=True),
    default=None,
    help="Path to env file.",
)
@click.option(
    "--matrix",
    multiple=True,
    help="Matrix filter in KEY:VALUE format (e.g. node:16).",
)
@click.option(
    "--container-architecture",
    type=str,
    default=None,
    help="Container architecture (e.g. linux/amd64).",
)
@click.option(
    "--artifact-server-path",
    type=click.Path(),
    default=None,
    help="Path to enable artifact server.",
)
@click.option(
    "--dry-run",
    "-n",
    is_flag=True,
    default=False,
    help="Dry run mode - do not actually execute actions.",
)
@click.option(
    "--list",
    "-l",
    "list_only",
    is_flag=True,
    default=False,
    help="List workflows that would be triggered without running them.",
)
@click.option(
    "--verbose",
    "-v",
    is_flag=True,
    default=False,
    help="Enable verbose output.",
)
@click.option(
    "--offline",
    is_flag=True,
    default=False,
    help="Enable action offline mode (use cached actions).",
)
@click.option(
    "--timeout",
    type=int,
    default=600,
    help="Timeout in seconds (default: 600).",
)
def run_act_command(
    event: str,
    workflow: str | None,
    job: str | None,
    secret: tuple[str, ...],
    secret_file: str | None,
    var: tuple[str, ...],
    var_file: str | None,
    inputs: tuple[str, ...],
    input_file: str | None,
    event_file: str | None,
    platform: tuple[str, ...],
    env_vars: tuple[str, ...],
    env_file: str | None,
    matrix: tuple[str, ...],
    container_architecture: str | None,
    artifact_server_path: str | None,
    dry_run: bool,
    list_only: bool,
    verbose: bool,
    offline: bool,
    timeout: int,
) -> None:
    """Run GitHub Actions locally using nektos/act.

    Requires Docker to be running and act to be installed.
    Install act: https://github.com/nektos/act

    Examples:

        gasket run-act                          # Run push event workflows

        gasket run-act --event pull_request     # Run pull_request workflows

        gasket run-act --list                   # List workflows

        gasket run-act --dry-run                # Dry run only

        gasket run-act -j test                  # Run specific job

        gasket run-act -W .github/workflows/ci.yml  # Run specific workflow
    """
    # Check if act is installed
    act_path = find_act_executable()
    if not act_path:
        click.echo(
            click.style(
                "[ERROR] act executable not found. "
                "Install from https://github.com/nektos/act",
                fg="red",
            )
        )
        sys.exit(3)

    # Show version info
    version = get_act_version(act_path)
    if version:
        click.echo(click.style(f"[INFO] Using {version}", fg="cyan"))

    # Parse KEY=VALUE pairs from tuple options
    secrets_dict = _parse_key_value_pairs(secret)
    variables_dict = _parse_key_value_pairs(var)
    inputs_dict = _parse_key_value_pairs(inputs)
    platform_dict = _parse_key_value_pairs(platform)
    env_dict = _parse_key_value_pairs(env_vars)
    matrix_dict = _parse_key_value_pairs(matrix, separator=":")

    # Run act
    result = run_act(
        event=event,
        workflow_file=workflow,
        job=job,
        secrets=secrets_dict or None,
        secret_file=secret_file,
        variables=variables_dict or None,
        var_file=var_file,
        inputs=inputs_dict or None,
        input_file=input_file,
        event_file=event_file,
        platform=platform_dict or None,
        env_vars=env_dict or None,
        env_file=env_file,
        matrix=matrix_dict or None,
        container_architecture=container_architecture,
        artifact_server_path=artifact_server_path,
        dry_run=dry_run,
        list_only=list_only,
        verbose=verbose,
        action_offline_mode=offline,
        timeout=timeout,
    )

    # Display output
    if result.stdout:
        click.echo(result.stdout)

    if result.stderr:
        if result.success:
            click.echo(result.stderr)
        else:
            click.echo(click.style(result.stderr, fg="red"))

    # Summary
    if result.success:
        click.echo(click.style("[OK] act completed successfully", fg="green"))
    else:
        click.echo(
            click.style(
                f"[ERROR] act failed with exit code {result.return_code}",
                fg="red",
            )
        )

    sys.exit(0 if result.success else 1)


def _parse_key_value_pairs(
    pairs: tuple[str, ...],
    separator: str = "=",
) -> dict[str, str]:
    """Parse KEY=VALUE or KEY:VALUE pairs from CLI options.

    Args:
        pairs: Tuple of strings in KEY<sep>VALUE format.
        separator: Separator character (default: '=').

    Returns:
        Dictionary of parsed key-value pairs.
    """
    result: dict[str, str] = {}
    for pair in pairs:
        if separator in pair:
            key, value = pair.split(separator, 1)
            result[key.strip()] = value.strip()
    return result
