"""CLI command for setup and installation of gasket and its dependencies."""

from __future__ import annotations

import sys

import click

from gasket.core.act_installer import (
    add_to_path_instructions,
    check_docker_available,
    check_prerequisites,
    get_default_install_dir,
    install_act,
)
from gasket.core.act_runner import find_act_executable


@click.group("setup")
def setup() -> None:
    """Setup and install gasket dependencies.

    Check prerequisites, install act, and verify the environment
    is ready for running GitHub Actions locally.
    """
    pass


@setup.command("check")
@click.option(
    "--format",
    "-f",
    "output_format",
    type=click.Choice(["text", "json"], case_sensitive=False),
    default="text",
    help="Output format.",
)
def check_command(output_format: str) -> None:
    """Check if all prerequisites are installed.

    Verifies Python, act, Docker, and Git are available.
    """
    results = check_prerequisites()

    if output_format == "json":
        import json

        click.echo(json.dumps(results, indent=2))
        return

    click.echo(click.style("Prerequisite Check", bold=True))
    click.echo("-" * 40)

    all_ok = True
    for tool, info in results.items():
        installed = info.get("installed", False)
        if installed:
            version = info.get("version", "")
            path = info.get("path", "")
            version_str = f" ({version})" if version else ""
            click.echo(
                click.style(f"[OK] {tool}{version_str}", fg="green")
                + f" - {path}"
            )
            # Special check: Docker running
            if tool == "docker" and not info.get("running", True):
                click.echo(
                    click.style(
                        "  [WARN] Docker is installed but not running",
                        fg="yellow",
                    )
                )
                all_ok = False
        else:
            click.echo(click.style(f"[MISSING] {tool}", fg="red"))
            all_ok = False

    click.echo("-" * 40)
    if all_ok:
        click.echo(click.style("[OK] All prerequisites met", fg="green"))
    else:
        click.echo(
            click.style(
                "[WARN] Some prerequisites are missing. Run 'gasket setup install-act' to install act.",
                fg="yellow",
            )
        )


@setup.command("install-act")
@click.option(
    "--install-dir",
    type=click.Path(),
    default=None,
    help="Directory to install act into. Defaults to platform-specific location.",
)
@click.option(
    "--force",
    is_flag=True,
    default=False,
    help="Force reinstall even if act is already installed.",
)
def install_act_command(install_dir: str | None, force: bool) -> None:
    """Download and install nektos/act.

    Downloads the appropriate act binary for the current platform
    from GitHub releases and installs it locally.

    Requires internet access for download. Docker is required to run act.
    """
    # Check if already installed (unless --force)
    if not force:
        existing = find_act_executable()
        if existing:
            from gasket.core.act_runner import get_act_version

            version = get_act_version(existing) or "unknown"
            click.echo(
                click.style(
                    f"[OK] act is already installed: {existing} ({version})",
                    fg="green",
                )
            )
            click.echo("Use --force to reinstall.")
            return

    # Show what we're about to do
    target_dir = install_dir or str(get_default_install_dir())
    click.echo(click.style(f"[INFO] Installing act to {target_dir}", fg="cyan"))
    click.echo(click.style("[INFO] Downloading from GitHub releases...", fg="cyan"))

    def progress(downloaded: int, total: int) -> None:
        """Display download progress."""
        pct = int(downloaded / total * 100) if total else 0
        bar_len = 30
        filled = int(bar_len * downloaded / total) if total else 0
        bar = "#" * filled + "-" * (bar_len - filled)
        click.echo(f"\r  [{bar}] {pct}%", nl=False)

    # If force reinstall, pass install_dir to bypass the "already installed" check
    # by temporarily removing existing from consideration
    result = install_act(install_dir=install_dir, progress_callback=progress)
    click.echo()  # newline after progress bar

    if result.success:
        click.echo(click.style(f"[OK] {result.message}", fg="green"))
        if result.version:
            click.echo(click.style(f"[INFO] Version: {result.version}", fg="cyan"))

        # Check if act is in PATH
        from gasket.core.act_runner import find_act_executable as check_path

        if not check_path():
            from pathlib import Path

            instructions = add_to_path_instructions(Path(target_dir))
            click.echo(click.style("[WARN] act is not in your PATH", fg="yellow"))
            click.echo(instructions)

        # Docker check
        if not check_docker_available():
            click.echo(
                click.style(
                    "[WARN] Docker is not running. Docker is required to use act.",
                    fg="yellow",
                )
            )
    else:
        click.echo(click.style(f"[ERROR] {result.message}", fg="red"))
        sys.exit(1)


@setup.command("install-all")
@click.option(
    "--act-dir",
    type=click.Path(),
    default=None,
    help="Directory to install act into.",
)
def install_all_command(act_dir: str | None) -> None:
    """Install all dependencies (act) and verify the environment.

    This is a convenience command that runs install-act and then
    checks all prerequisites.
    """
    click.echo(click.style("=== gasket Setup ===", bold=True))
    click.echo()

    # Step 1: Install act
    click.echo(click.style("[1/3] Installing act...", fg="cyan"))
    act_result = install_act(install_dir=act_dir)
    if act_result.success:
        click.echo(click.style(f"  [OK] {act_result.message}", fg="green"))
    else:
        click.echo(click.style(f"  [ERROR] {act_result.message}", fg="red"))

    # Step 2: Check Docker
    click.echo(click.style("[2/3] Checking Docker...", fg="cyan"))
    if check_docker_available():
        click.echo(click.style("  [OK] Docker is running", fg="green"))
    else:
        click.echo(
            click.style(
                "  [WARN] Docker is not running. Install from https://docs.docker.com/get-docker/",
                fg="yellow",
            )
        )

    # Step 3: Verify
    click.echo(click.style("[3/3] Verifying installation...", fg="cyan"))
    results = check_prerequisites()
    all_ok = all(
        info.get("installed", False) for info in results.values()
    )
    if all_ok:
        click.echo(click.style("  [OK] All prerequisites met", fg="green"))
    else:
        missing = [
            tool for tool, info in results.items() if not info.get("installed", False)
        ]
        click.echo(
            click.style(
                f"  [WARN] Missing: {', '.join(missing)}", fg="yellow"
            )
        )

    click.echo()
    click.echo(click.style("=== Setup Complete ===", bold=True))
    click.echo("Run 'gasket setup check' to see full status.")
    click.echo("Run 'gasket run-act --list' to list available workflows.")


@setup.command("uninstall-act")
@click.option(
    "--install-dir",
    type=click.Path(),
    default=None,
    help="Directory where act is installed.",
)
@click.confirmation_option(prompt="Are you sure you want to uninstall act?")
def uninstall_act_command(install_dir: str | None) -> None:
    """Remove the act binary."""
    from pathlib import Path

    target = Path(install_dir) if install_dir else get_default_install_dir()
    if sys.platform == "win32":
        act_binary = target / "act.exe"
    else:
        act_binary = target / "act"

    if act_binary.exists():
        act_binary.unlink()
        click.echo(click.style(f"[OK] Removed {act_binary}", fg="green"))
    else:
        # Try finding wherever it is
        existing = find_act_executable()
        if existing:
            click.echo(
                click.style(
                    f"[INFO] act found at {existing} (not in default location).\n"
                    "Remove it manually or specify --install-dir.",
                    fg="cyan",
                )
            )
        else:
            click.echo(click.style("[INFO] act is not installed", fg="cyan"))
