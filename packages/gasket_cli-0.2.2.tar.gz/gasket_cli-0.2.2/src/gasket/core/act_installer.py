"""Installer for nektos/act - download and install act binary."""

from __future__ import annotations

import platform
import shutil
import stat
import subprocess
import sys
import tempfile
import urllib.request
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from gasket.core.act_runner import find_act_executable, get_act_version

# GitHub API for latest release
ACT_RELEASES_URL = "https://github.com/nektos/act/releases/latest"
ACT_DOWNLOAD_BASE = "https://github.com/nektos/act/releases/latest/download"

# Map (system, machine) -> act binary archive name
ACT_BINARY_MAP: dict[tuple[str, str], str] = {
    ("Windows", "AMD64"): "act_Windows_x86_64.zip",
    ("Windows", "x86_64"): "act_Windows_x86_64.zip",
    ("Windows", "ARM64"): "act_Windows_arm64.zip",
    ("Linux", "x86_64"): "act_Linux_x86_64.tar.gz",
    ("Linux", "aarch64"): "act_Linux_arm64.tar.gz",
    ("Linux", "armv7l"): "act_Linux_armv7.tar.gz",
    ("Darwin", "x86_64"): "act_Darwin_x86_64.tar.gz",
    ("Darwin", "arm64"): "act_Darwin_arm64.tar.gz",
}


@dataclass
class InstallResult:
    """Result of an installation operation.

    Attributes:
        success: Whether installation succeeded.
        tool: Name of the tool installed.
        version: Version installed.
        path: Installation path.
        message: Status message.
    """

    success: bool
    tool: str
    version: str = ""
    path: str = ""
    message: str = ""


def get_act_archive_name() -> str | None:
    """Determine the correct act binary archive for the current platform.

    Returns:
        Archive filename if platform is supported, None otherwise.
    """
    system = platform.system()
    machine = platform.machine()
    return ACT_BINARY_MAP.get((system, machine))


def get_default_install_dir() -> Path:
    """Get the default installation directory for act.

    On Windows: %LOCALAPPDATA%/Programs/act
    On Linux/macOS: ~/.local/bin

    Returns:
        Path to install directory.
    """
    if sys.platform == "win32":
        local_app_data = Path.home() / "AppData" / "Local" / "Programs" / "act"
        return local_app_data
    return Path.home() / ".local" / "bin"


def _download_file(url: str, dest: Path, progress_callback: Any = None) -> None:
    """Download a file from URL to destination.

    Args:
        url: URL to download from.
        dest: Destination file path.
        progress_callback: Optional callable(bytes_downloaded, total_bytes).
    """
    req = urllib.request.Request(url, headers={"User-Agent": "gasket"})
    with urllib.request.urlopen(req, timeout=60) as response:  # noqa: S310
        total = int(response.headers.get("Content-Length", 0))
        downloaded = 0
        with open(dest, "wb") as f:
            while True:
                chunk = response.read(8192)
                if not chunk:
                    break
                f.write(chunk)
                downloaded += len(chunk)
                if progress_callback and total:
                    progress_callback(downloaded, total)


def _extract_archive(archive_path: Path, dest_dir: Path) -> None:
    """Extract a tar.gz or zip archive.

    Args:
        archive_path: Path to archive file.
        dest_dir: Destination directory.
    """
    name = archive_path.name
    if name.endswith(".tar.gz") or name.endswith(".tgz"):
        import tarfile

        with tarfile.open(archive_path, "r:gz") as tar:
            # Security: prevent path traversal
            for member in tar.getmembers():
                member_path = Path(dest_dir / member.name).resolve()
                if not str(member_path).startswith(str(dest_dir.resolve())):
                    raise ValueError(f"Path traversal detected in archive: {member.name}")
            tar.extractall(dest_dir, filter="data")
    elif name.endswith(".zip"):
        import zipfile

        with zipfile.ZipFile(archive_path, "r") as zf:
            # Security: prevent path traversal
            for info in zf.infolist():
                member_path = Path(dest_dir / info.filename).resolve()
                if not str(member_path).startswith(str(dest_dir.resolve())):
                    raise ValueError(f"Path traversal detected in archive: {info.filename}")
            zf.extractall(dest_dir)


def install_act(
    install_dir: str | None = None,
    progress_callback: Any = None,
) -> InstallResult:
    """Download and install act binary.

    Args:
        install_dir: Directory to install act into. Uses default if None.
        progress_callback: Optional callable(bytes_downloaded, total_bytes).

    Returns:
        InstallResult with details.
    """
    # Check if already installed
    existing = find_act_executable()
    if existing:
        version = get_act_version(existing) or "unknown"
        return InstallResult(
            success=True,
            tool="act",
            version=version,
            path=existing,
            message=f"act is already installed at {existing} ({version})",
        )

    # Determine archive for platform
    archive_name = get_act_archive_name()
    if not archive_name:
        return InstallResult(
            success=False,
            tool="act",
            message=(
                f"Unsupported platform: {platform.system()} {platform.machine()}. "
                "Install act manually: https://github.com/nektos/act#installation"
            ),
        )

    # Setup install directory
    dest = Path(install_dir) if install_dir else get_default_install_dir()
    dest.mkdir(parents=True, exist_ok=True)

    download_url = f"{ACT_DOWNLOAD_BASE}/{archive_name}"

    try:
        with tempfile.TemporaryDirectory() as tmp_dir:
            tmp_path = Path(tmp_dir)
            archive_file = tmp_path / archive_name

            # Download
            _download_file(download_url, archive_file, progress_callback)

            # Extract
            _extract_archive(archive_file, tmp_path)

            # Find act binary in extracted files
            if sys.platform == "win32":
                act_binary = tmp_path / "act.exe"
            else:
                act_binary = tmp_path / "act"

            if not act_binary.exists():
                return InstallResult(
                    success=False,
                    tool="act",
                    message="act binary not found in downloaded archive",
                )

            # Move to install directory
            dest_binary = dest / act_binary.name
            shutil.move(str(act_binary), str(dest_binary))

            # Make executable on Unix
            if sys.platform != "win32":
                dest_binary.chmod(dest_binary.stat().st_mode | stat.S_IEXEC | stat.S_IXGRP | stat.S_IXOTH)

        # Verify installation
        version = get_act_version(str(dest_binary)) or "unknown"

        return InstallResult(
            success=True,
            tool="act",
            version=version,
            path=str(dest_binary),
            message=f"act installed successfully to {dest_binary}",
        )

    except urllib.error.URLError as e:
        return InstallResult(
            success=False,
            tool="act",
            message=f"Download failed: {e}",
        )
    except (OSError, ValueError) as e:
        return InstallResult(
            success=False,
            tool="act",
            message=f"Installation failed: {e}",
        )


def check_docker_available() -> bool:
    """Check if Docker is available and running.

    Returns:
        True if Docker is available.
    """
    docker_path = shutil.which("docker")
    if not docker_path:
        return False
    try:
        result = subprocess.run(
            [docker_path, "info"],
            capture_output=True,
            text=True,
            timeout=10,
        )
        return result.returncode == 0
    except (subprocess.TimeoutExpired, OSError):
        return False


def check_prerequisites() -> dict[str, dict[str, Any]]:
    """Check all prerequisites for running gasket with act.

    Returns:
        Dictionary with status of each prerequisite.
    """
    results: dict[str, dict[str, Any]] = {}

    # Python
    results["python"] = {
        "installed": True,
        "version": f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}",
        "path": sys.executable,
    }

    # act
    act_path = find_act_executable()
    if act_path:
        version = get_act_version(act_path) or "unknown"
        results["act"] = {
            "installed": True,
            "version": version,
            "path": act_path,
        }
    else:
        results["act"] = {
            "installed": False,
            "version": "",
            "path": "",
        }

    # Docker
    docker_path = shutil.which("docker")
    results["docker"] = {
        "installed": docker_path is not None,
        "running": check_docker_available() if docker_path else False,
        "path": docker_path or "",
    }

    # Git
    git_path = shutil.which("git")
    results["git"] = {
        "installed": git_path is not None,
        "path": git_path or "",
    }

    return results


def add_to_path_instructions(install_dir: Path) -> str:
    """Generate instructions for adding install directory to PATH.

    Args:
        install_dir: The directory where act was installed.

    Returns:
        Platform-specific instructions string.
    """
    dir_str = str(install_dir)
    if sys.platform == "win32":
        return (
            f"Add act to PATH by running (PowerShell as Admin):\n"
            f'  [Environment]::SetEnvironmentVariable("Path", '
            f'$env:Path + ";{dir_str}", "User")\n'
            f"Then restart your terminal."
        )
    shell = Path.home() / ".bashrc"
    if (Path.home() / ".zshrc").exists():
        shell = Path.home() / ".zshrc"
    return (
        f"Add act to PATH by adding this to {shell}:\n"
        f'  export PATH="{dir_str}:$PATH"\n'
        f"Then run: source {shell}"
    )
