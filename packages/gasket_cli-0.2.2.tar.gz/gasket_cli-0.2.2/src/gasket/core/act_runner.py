"""Runner for nektos/act - run GitHub Actions locally via Docker."""

from __future__ import annotations

import json
import shutil
import subprocess
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


@dataclass
class ActResult:
    """Result of running act.

    Attributes:
        success: Whether act ran successfully.
        command: The full command that was executed.
        stdout: Standard output from act.
        stderr: Standard error from act.
        return_code: Process return code.
        workflows_run: List of workflow names that were run.
    """

    success: bool = True
    command: list[str] = field(default_factory=list)
    stdout: str = ""
    stderr: str = ""
    return_code: int = 0
    workflows_run: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        """Convert result to a dictionary.

        Returns:
            Dictionary representation.
        """
        return {
            "success": self.success,
            "command": " ".join(self.command),
            "return_code": self.return_code,
            "stdout": self.stdout,
            "stderr": self.stderr,
            "workflows_run": self.workflows_run,
        }


def find_act_executable() -> str | None:
    """Find the act executable on the system.

    Checks PATH for 'act' binary. On Windows, also checks common
    installation paths (scoop, chocolatey, winget).

    Returns:
        Path to act executable if found, None otherwise.
    """
    act_path = shutil.which("act")
    if act_path:
        return act_path

    # Check common Windows installation paths
    import sys

    if sys.platform == "win32":
        common_paths = [
            Path.home() / "scoop" / "shims" / "act.exe",
            Path(r"C:\ProgramData\chocolatey\bin\act.exe"),
            Path.home() / "AppData" / "Local" / "Microsoft" / "WinGet" / "Links" / "act.exe",
        ]
        for p in common_paths:
            if p.exists():
                return str(p)

    return None


def get_act_version(act_path: str) -> str | None:
    """Get the version of act.

    Args:
        act_path: Path to the act executable.

    Returns:
        Version string if successful, None otherwise.
    """
    try:
        result = subprocess.run(
            [act_path, "--version"],
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=10,
        )
        if result.returncode == 0:
            return result.stdout.strip()
    except (subprocess.TimeoutExpired, OSError):
        pass
    return None


def build_act_command(
    act_path: str,
    event: str = "push",
    workflow_file: str | None = None,
    workflows_dir: str | None = None,
    job: str | None = None,
    secrets: dict[str, str] | None = None,
    secret_file: str | None = None,
    variables: dict[str, str] | None = None,
    var_file: str | None = None,
    inputs: dict[str, str] | None = None,
    input_file: str | None = None,
    event_file: str | None = None,
    platform: dict[str, str] | None = None,
    env_vars: dict[str, str] | None = None,
    env_file: str | None = None,
    matrix: dict[str, str] | None = None,
    artifact_server_path: str | None = None,
    container_architecture: str | None = None,
    dry_run: bool = False,
    list_only: bool = False,
    verbose: bool = False,
    action_offline_mode: bool = False,
    extra_args: list[str] | None = None,
) -> list[str]:
    """Build the act command line arguments.

    Args:
        act_path: Path to the act executable.
        event: Event type to trigger (push, pull_request, etc.).
        workflow_file: Specific workflow file to run.
        workflows_dir: Directory containing workflow files.
        job: Specific job name to run.
        secrets: Dictionary of secret name-value pairs.
        secret_file: Path to secrets file.
        variables: Dictionary of variable name-value pairs.
        var_file: Path to variables file.
        inputs: Dictionary of input name-value pairs for workflow_dispatch.
        input_file: Path to inputs file.
        event_file: Path to event JSON payload file.
        platform: Platform overrides (e.g. {"ubuntu-latest": "node:16-buster-slim"}).
        env_vars: Environment variables to pass.
        env_file: Path to env file.
        matrix: Matrix values to filter (e.g. {"node": "16"}).
        artifact_server_path: Path to enable artifact server.
        container_architecture: Container architecture (e.g. linux/amd64).
        dry_run: If True, only do a dry run (-n flag).
        list_only: If True, only list workflows (-l flag).
        verbose: If True, enable verbose output.
        action_offline_mode: If True, enable offline mode.
        extra_args: Additional CLI arguments to pass.

    Returns:
        List of command arguments.
    """
    cmd = [act_path, event]

    if workflow_file:
        cmd.extend(["-W", workflow_file])
    elif workflows_dir:
        cmd.extend(["-W", workflows_dir])

    if job:
        cmd.extend(["-j", job])

    if secrets:
        for key, value in secrets.items():
            cmd.extend(["-s", f"{key}={value}"])

    if secret_file:
        cmd.extend(["--secret-file", secret_file])

    if variables:
        for key, value in variables.items():
            cmd.extend(["--var", f"{key}={value}"])

    if var_file:
        cmd.extend(["--var-file", var_file])

    if inputs:
        for key, value in inputs.items():
            cmd.extend(["--input", f"{key}={value}"])

    if input_file:
        cmd.extend(["--input-file", input_file])

    if event_file:
        cmd.extend(["-e", event_file])

    if platform:
        for key, value in platform.items():
            cmd.extend(["-P", f"{key}={value}"])

    if env_vars:
        for key, value in env_vars.items():
            cmd.extend(["--env", f"{key}={value}"])

    if env_file:
        cmd.extend(["--env-file", env_file])

    if matrix:
        for key, value in matrix.items():
            cmd.extend(["--matrix", f"{key}={value}"])

    if artifact_server_path:
        cmd.extend(["--artifact-server-path", artifact_server_path])

    if container_architecture:
        cmd.extend(["--container-architecture", container_architecture])

    if dry_run:
        cmd.append("-n")

    if list_only:
        cmd.append("-l")

    if verbose:
        cmd.append("--verbose")

    if action_offline_mode:
        cmd.append("--action-offline-mode")

    if extra_args:
        cmd.extend(extra_args)

    return cmd


def run_act(
    event: str = "push",
    workflow_file: str | None = None,
    workflows_dir: str | None = None,
    job: str | None = None,
    secrets: dict[str, str] | None = None,
    secret_file: str | None = None,
    variables: dict[str, str] | None = None,
    var_file: str | None = None,
    inputs: dict[str, str] | None = None,
    input_file: str | None = None,
    event_file: str | None = None,
    platform: dict[str, str] | None = None,
    env_vars: dict[str, str] | None = None,
    env_file: str | None = None,
    matrix: dict[str, str] | None = None,
    artifact_server_path: str | None = None,
    container_architecture: str | None = None,
    dry_run: bool = False,
    list_only: bool = False,
    verbose: bool = False,
    action_offline_mode: bool = False,
    extra_args: list[str] | None = None,
    cwd: str | None = None,
    timeout: int = 600,
) -> ActResult:
    """Run act to execute GitHub Actions locally.

    Requires Docker to be running and act to be installed.

    Args:
        event: Event type to trigger (push, pull_request, etc.).
        workflow_file: Specific workflow file to run.
        workflows_dir: Directory containing workflow files.
        job: Specific job name to run.
        secrets: Dictionary of secret name-value pairs.
        secret_file: Path to secrets file.
        variables: Dictionary of variable name-value pairs.
        var_file: Path to variables file.
        inputs: Dictionary of input name-value pairs for workflow_dispatch.
        input_file: Path to inputs file.
        event_file: Path to event JSON payload file.
        platform: Platform overrides.
        env_vars: Environment variables to pass.
        env_file: Path to env file.
        matrix: Matrix values to filter.
        artifact_server_path: Path to enable artifact server.
        container_architecture: Container architecture.
        dry_run: If True, only do a dry run.
        list_only: If True, only list workflows.
        verbose: If True, enable verbose output.
        action_offline_mode: If True, enable offline mode.
        extra_args: Additional CLI arguments.
        cwd: Working directory to run act from.
        timeout: Timeout in seconds (default: 600).

    Returns:
        ActResult with execution details.
    """
    act_path = find_act_executable()
    if not act_path:
        return ActResult(
            success=False,
            stderr="act executable not found. Install from https://github.com/nektos/act",
            return_code=-1,
        )

    cmd = build_act_command(
        act_path=act_path,
        event=event,
        workflow_file=workflow_file,
        workflows_dir=workflows_dir,
        job=job,
        secrets=secrets,
        secret_file=secret_file,
        variables=variables,
        var_file=var_file,
        inputs=inputs,
        input_file=input_file,
        event_file=event_file,
        platform=platform,
        env_vars=env_vars,
        env_file=env_file,
        matrix=matrix,
        artifact_server_path=artifact_server_path,
        container_architecture=container_architecture,
        dry_run=dry_run,
        list_only=list_only,
        verbose=verbose,
        action_offline_mode=action_offline_mode,
        extra_args=extra_args,
    )

    try:
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            cwd=cwd,
            timeout=timeout,
        )
        return ActResult(
            success=result.returncode == 0,
            command=cmd,
            stdout=result.stdout,
            stderr=result.stderr,
            return_code=result.returncode,
        )
    except subprocess.TimeoutExpired:
        return ActResult(
            success=False,
            command=cmd,
            stderr=f"act timed out after {timeout} seconds",
            return_code=-2,
        )
    except OSError as e:
        return ActResult(
            success=False,
            command=cmd,
            stderr=f"Failed to execute act: {e}",
            return_code=-3,
        )


def list_workflows(
    workflows_dir: str | None = None,
    event: str = "push",
    cwd: str | None = None,
) -> ActResult:
    """List workflows that would be triggered by an event.

    Args:
        workflows_dir: Directory containing workflow files.
        event: Event type to check.
        cwd: Working directory.

    Returns:
        ActResult with workflow listing in stdout.
    """
    return run_act(
        event=event,
        workflows_dir=workflows_dir,
        list_only=True,
        cwd=cwd,
    )
