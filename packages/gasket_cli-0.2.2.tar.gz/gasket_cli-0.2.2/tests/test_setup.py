﻿"""Tests for the setup command and act_installer core module."""

from __future__ import annotations

from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest
from click.testing import CliRunner

from gasket.cli import cli
from gasket.core.act_installer import (
    InstallResult,
    add_to_path_instructions,
    check_docker_available,
    check_prerequisites,
    get_act_archive_name,
    get_default_install_dir,
    install_act,
)


@pytest.fixture
def runner():
    """Create a Click CLI test runner."""
    return CliRunner()


class TestGetActArchiveName:
    """Tests for platform detection of act archive."""

    @patch("gasket.core.act_installer.platform.system", return_value="Linux")
    @patch("gasket.core.act_installer.platform.machine", return_value="x86_64")
    def test_linux_x86_64(self, mock_machine, mock_system):
        """Should return Linux x86_64 archive."""
        assert get_act_archive_name() == "act_Linux_x86_64.tar.gz"

    @patch("gasket.core.act_installer.platform.system", return_value="Darwin")
    @patch("gasket.core.act_installer.platform.machine", return_value="arm64")
    def test_macos_arm64(self, mock_machine, mock_system):
        """Should return macOS arm64 archive."""
        assert get_act_archive_name() == "act_Darwin_arm64.tar.gz"

    @patch("gasket.core.act_installer.platform.system", return_value="Windows")
    @patch("gasket.core.act_installer.platform.machine", return_value="AMD64")
    def test_windows_amd64(self, mock_machine, mock_system):
        """Should return Windows x86_64 archive."""
        assert get_act_archive_name() == "act_Windows_x86_64.zip"

    @patch("gasket.core.act_installer.platform.system", return_value="FreeBSD")
    @patch("gasket.core.act_installer.platform.machine", return_value="x86_64")
    def test_unsupported_platform(self, mock_machine, mock_system):
        """Should return None for unsupported platform."""
        assert get_act_archive_name() is None


class TestGetDefaultInstallDir:
    """Tests for default installation directory."""

    @patch("gasket.core.act_installer.sys.platform", "win32")
    def test_windows_default(self):
        """Windows should use AppData/Local/Programs/act."""
        result = get_default_install_dir()
        assert "Programs" in str(result)
        assert "act" in str(result)

    @patch("gasket.core.act_installer.sys.platform", "linux")
    def test_linux_default(self):
        """Linux should use ~/.local/bin."""
        result = get_default_install_dir()
        assert ".local" in str(result)
        assert "bin" in str(result)


class TestInstallAct:
    """Tests for act installation."""

    @patch("gasket.core.act_installer.find_act_executable")
    @patch("gasket.core.act_installer.get_act_version")
    def test_already_installed(self, mock_version, mock_find):
        """Should skip if act is already installed."""
        mock_find.return_value = "/usr/bin/act"
        mock_version.return_value = "act version 0.2.87"
        result = install_act()
        assert result.success
        assert "already installed" in result.message

    @patch("gasket.core.act_installer.find_act_executable", return_value=None)
    @patch("gasket.core.act_installer.get_act_archive_name", return_value=None)
    def test_unsupported_platform(self, mock_archive, mock_find):
        """Should fail for unsupported platform."""
        result = install_act()
        assert not result.success
        assert "Unsupported" in result.message

    @patch("gasket.core.act_installer.find_act_executable", return_value=None)
    @patch("gasket.core.act_installer.get_act_archive_name", return_value="act_Linux_x86_64.tar.gz")
    @patch("gasket.core.act_installer._download_file")
    @patch("gasket.core.act_installer._extract_archive")
    @patch("gasket.core.act_installer.get_act_version", return_value="act version 0.2.87")
    def test_successful_install(
        self, mock_version, mock_extract, mock_download, mock_archive, mock_find, tmp_path
    ):
        """Should install successfully when download works."""
        # fake_extract creates the act binary in the internal temp dir
        # On Windows sys.platform == "win32", so it looks for act.exe
        import sys

        binary_name = "act.exe" if sys.platform == "win32" else "act"

        def fake_extract(archive, dest):
            act_bin = dest / binary_name
            act_bin.write_text("fake")

        mock_extract.side_effect = fake_extract

        result = install_act(install_dir=str(tmp_path))
        assert result.success
        assert "installed successfully" in result.message

    @patch("gasket.core.act_installer.find_act_executable", return_value=None)
    @patch("gasket.core.act_installer.get_act_archive_name", return_value="act_Linux_x86_64.tar.gz")
    @patch("gasket.core.act_installer._download_file")
    def test_download_failure(self, mock_download, mock_archive, mock_find, tmp_path):
        """Should handle download failure."""
        import urllib.error
        mock_download.side_effect = urllib.error.URLError("Connection refused")
        result = install_act(install_dir=str(tmp_path))
        assert not result.success
        assert "Download failed" in result.message


class TestCheckDockerAvailable:
    """Tests for Docker availability check."""

    @patch("gasket.core.act_installer.shutil.which", return_value=None)
    def test_docker_not_installed(self, mock_which):
        """Should return False when Docker is not installed."""
        assert not check_docker_available()

    @patch("gasket.core.act_installer.subprocess.run")
    @patch("gasket.core.act_installer.shutil.which", return_value="/usr/bin/docker")
    def test_docker_running(self, mock_which, mock_run):
        """Should return True when Docker is running."""
        mock_run.return_value = MagicMock(returncode=0)
        assert check_docker_available()

    @patch("gasket.core.act_installer.subprocess.run")
    @patch("gasket.core.act_installer.shutil.which", return_value="/usr/bin/docker")
    def test_docker_not_running(self, mock_which, mock_run):
        """Should return False when Docker is not running."""
        mock_run.return_value = MagicMock(returncode=1)
        assert not check_docker_available()


class TestCheckPrerequisites:
    """Tests for prerequisite checking."""

    @patch("gasket.core.act_installer.shutil.which")
    @patch("gasket.core.act_installer.find_act_executable", return_value=None)
    @patch("gasket.core.act_installer.check_docker_available", return_value=False)
    def test_returns_all_tools(self, mock_docker, mock_act, mock_which):
        """Should return status for all tools."""
        mock_which.return_value = None
        results = check_prerequisites()
        assert "python" in results
        assert "act" in results
        assert "docker" in results
        assert "git" in results
        assert results["python"]["installed"] is True


class TestAddToPathInstructions:
    """Tests for PATH instructions generation."""

    @patch("gasket.core.act_installer.sys.platform", "win32")
    def test_windows_instructions(self):
        """Should generate PowerShell instructions on Windows."""
        result = add_to_path_instructions(Path("C:/act"))
        assert "PowerShell" in result
        assert "SetEnvironmentVariable" in result

    @patch("gasket.core.act_installer.sys.platform", "linux")
    def test_linux_instructions(self):
        """Should generate shell rc instructions on Linux."""
        result = add_to_path_instructions(Path("/home/user/.local/bin"))
        assert "export PATH" in result


class TestInstallResult:
    """Tests for InstallResult dataclass."""

    def test_defaults(self):
        """Should have correct default values."""
        result = InstallResult(success=True, tool="act")
        assert result.success
        assert result.tool == "act"
        assert result.version == ""
        assert result.path == ""
        assert result.message == ""


class TestSetupCheckCLI:
    """Integration tests for 'prepush setup check' command."""

    @patch("gasket.core.act_installer.shutil.which")
    @patch("gasket.core.act_installer.find_act_executable", return_value="/usr/bin/act")
    @patch("gasket.core.act_installer.get_act_version", return_value="act version 0.2.87")
    @patch("gasket.core.act_installer.check_docker_available", return_value=True)
    def test_all_prerequisites_met(self, mock_docker, mock_version, mock_act, mock_which, runner):
        """Should show all OK when everything is installed."""
        mock_which.return_value = "/usr/bin/git"
        result = runner.invoke(cli, ["setup", "check"])
        assert result.exit_code == 0
        assert "[OK]" in result.output

    @patch("gasket.core.act_installer.shutil.which", return_value=None)
    @patch("gasket.core.act_installer.find_act_executable", return_value=None)
    @patch("gasket.core.act_installer.check_docker_available", return_value=False)
    def test_missing_prerequisites(self, mock_docker, mock_act, mock_which, runner):
        """Should show MISSING for missing tools."""
        result = runner.invoke(cli, ["setup", "check"])
        assert result.exit_code == 0
        assert "[MISSING]" in result.output

    @patch("gasket.core.act_installer.shutil.which")
    @patch("gasket.core.act_installer.find_act_executable", return_value="/usr/bin/act")
    @patch("gasket.core.act_installer.get_act_version", return_value="0.2.87")
    @patch("gasket.core.act_installer.check_docker_available", return_value=True)
    def test_json_format(self, mock_docker, mock_version, mock_act, mock_which, runner):
        """Should output JSON when --format json."""
        mock_which.return_value = "/usr/bin/git"
        result = runner.invoke(cli, ["setup", "check", "--format", "json"])
        assert result.exit_code == 0
        import json
        data = json.loads(result.output)
        assert "python" in data
        assert "act" in data


class TestSetupInstallActCLI:
    """Integration tests for 'prepush setup install-act' command."""

    @patch("gasket.commands.setup.find_act_executable", return_value="/usr/bin/act")
    @patch("gasket.commands.setup.install_act")
    def test_already_installed(self, mock_install, mock_find, runner):
        """Should skip when act is already installed."""
        with patch("gasket.core.act_runner.get_act_version", return_value="0.2.87"):
            result = runner.invoke(cli, ["setup", "install-act"])
        assert result.exit_code == 0
        assert "[OK]" in result.output
        assert "already installed" in result.output

    @patch("gasket.commands.setup.find_act_executable", return_value=None)
    @patch("gasket.commands.setup.install_act")
    @patch("gasket.commands.setup.check_docker_available", return_value=True)
    def test_successful_install(self, mock_docker, mock_install, mock_find, runner):
        """Should show success on install."""
        mock_install.return_value = InstallResult(
            success=True,
            tool="act",
            version="0.2.87",
            path="/home/user/.local/bin/act",
            message="act installed successfully to /home/user/.local/bin/act",
        )
        with patch("gasket.commands.setup.find_act_executable", return_value="/usr/bin/act"):
            result = runner.invoke(cli, ["setup", "install-act"])
        assert result.exit_code == 0
        assert "[OK]" in result.output

    @patch("gasket.commands.setup.find_act_executable", return_value=None)
    @patch("gasket.commands.setup.install_act")
    def test_failed_install(self, mock_install, mock_find, runner):
        """Should show error on failed install."""
        mock_install.return_value = InstallResult(
            success=False,
            tool="act",
            message="Unsupported platform",
        )
        result = runner.invoke(cli, ["setup", "install-act"])
        assert result.exit_code == 1
        assert "[ERROR]" in result.output


class TestSetupInstallAllCLI:
    """Integration tests for 'prepush setup install-all' command."""

    @patch("gasket.commands.setup.install_act")
    @patch("gasket.commands.setup.check_docker_available", return_value=True)
    @patch("gasket.commands.setup.check_prerequisites")
    def test_install_all(self, mock_check, mock_docker, mock_install, runner):
        """Should run all installation steps."""
        mock_install.return_value = InstallResult(
            success=True, tool="act", message="installed"
        )
        mock_check.return_value = {
            "python": {"installed": True},
            "act": {"installed": True},
            "docker": {"installed": True},
            "git": {"installed": True},
        }
        result = runner.invoke(cli, ["setup", "install-all"])
        assert result.exit_code == 0
        assert "Setup Complete" in result.output
