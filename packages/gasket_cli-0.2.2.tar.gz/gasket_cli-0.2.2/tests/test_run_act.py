﻿"""Tests for the run-act command and act_runner core module."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest
from click.testing import CliRunner

from gasket.cli import cli
from gasket.core.act_runner import (
    ActResult,
    build_act_command,
    find_act_executable,
    list_workflows,
    run_act,
)


@pytest.fixture
def runner():
    """Create a Click CLI test runner."""
    return CliRunner()


class TestBuildActCommand:
    """Tests for building act command arguments."""

    def test_basic_push_event(self):
        """Basic push event should produce minimal command."""
        cmd = build_act_command(act_path="act", event="push")
        assert cmd == ["act", "push"]

    def test_pull_request_event(self):
        """Pull request event should be in command."""
        cmd = build_act_command(act_path="act", event="pull_request")
        assert cmd == ["act", "pull_request"]

    def test_workflow_file(self):
        """Specific workflow file should use -W flag."""
        cmd = build_act_command(
            act_path="act",
            event="push",
            workflow_file=".github/workflows/ci.yml",
        )
        assert "-W" in cmd
        assert ".github/workflows/ci.yml" in cmd

    def test_job_filter(self):
        """Job filter should use -j flag."""
        cmd = build_act_command(act_path="act", event="push", job="test")
        assert "-j" in cmd
        assert "test" in cmd

    def test_secrets(self):
        """Secrets should use -s flag with KEY=VALUE format."""
        cmd = build_act_command(
            act_path="act",
            event="push",
            secrets={"MY_SECRET": "value123"},
        )
        assert "-s" in cmd
        assert "MY_SECRET=value123" in cmd

    def test_secret_file(self):
        """Secret file should use --secret-file flag."""
        cmd = build_act_command(
            act_path="act", event="push", secret_file="my.secrets"
        )
        assert "--secret-file" in cmd
        assert "my.secrets" in cmd

    def test_variables(self):
        """Variables should use --var flag."""
        cmd = build_act_command(
            act_path="act",
            event="push",
            variables={"MY_VAR": "val"},
        )
        assert "--var" in cmd
        assert "MY_VAR=val" in cmd

    def test_inputs(self):
        """Inputs should use --input flag."""
        cmd = build_act_command(
            act_path="act",
            event="workflow_dispatch",
            inputs={"NAME": "test"},
        )
        assert "--input" in cmd
        assert "NAME=test" in cmd

    def test_event_file(self):
        """Event file should use -e flag."""
        cmd = build_act_command(
            act_path="act", event="push", event_file="event.json"
        )
        assert "-e" in cmd
        assert "event.json" in cmd

    def test_platform_override(self):
        """Platform override should use -P flag."""
        cmd = build_act_command(
            act_path="act",
            event="push",
            platform={"ubuntu-latest": "node:16-buster-slim"},
        )
        assert "-P" in cmd
        assert "ubuntu-latest=node:16-buster-slim" in cmd

    def test_dry_run(self):
        """Dry run should add -n flag."""
        cmd = build_act_command(act_path="act", event="push", dry_run=True)
        assert "-n" in cmd

    def test_list_only(self):
        """List only should add -l flag."""
        cmd = build_act_command(act_path="act", event="push", list_only=True)
        assert "-l" in cmd

    def test_verbose(self):
        """Verbose should add --verbose flag."""
        cmd = build_act_command(act_path="act", event="push", verbose=True)
        assert "--verbose" in cmd

    def test_offline_mode(self):
        """Offline mode should add --action-offline-mode flag."""
        cmd = build_act_command(
            act_path="act", event="push", action_offline_mode=True
        )
        assert "--action-offline-mode" in cmd

    def test_container_architecture(self):
        """Container architecture should add corresponding flag."""
        cmd = build_act_command(
            act_path="act",
            event="push",
            container_architecture="linux/amd64",
        )
        assert "--container-architecture" in cmd
        assert "linux/amd64" in cmd

    def test_matrix_filter(self):
        """Matrix filter should use --matrix flag."""
        cmd = build_act_command(
            act_path="act",
            event="push",
            matrix={"node": "16"},
        )
        assert "--matrix" in cmd
        assert "node=16" in cmd

    def test_extra_args(self):
        """Extra args should be appended."""
        cmd = build_act_command(
            act_path="act",
            event="push",
            extra_args=["--rm", "--pull=false"],
        )
        assert "--rm" in cmd
        assert "--pull=false" in cmd

    def test_env_vars(self):
        """Environment variables should use --env flag."""
        cmd = build_act_command(
            act_path="act",
            event="push",
            env_vars={"NODE_ENV": "test"},
        )
        assert "--env" in cmd
        assert "NODE_ENV=test" in cmd

    def test_multiple_secrets(self):
        """Multiple secrets should each get their own -s flag."""
        cmd = build_act_command(
            act_path="act",
            event="push",
            secrets={"SECRET1": "val1", "SECRET2": "val2"},
        )
        s_indices = [i for i, v in enumerate(cmd) if v == "-s"]
        assert len(s_indices) == 2


class TestRunAct:
    """Tests for running act."""

    @patch("gasket.core.act_runner.find_act_executable")
    def test_act_not_found(self, mock_find):
        """Should return error when act is not installed."""
        mock_find.return_value = None
        result = run_act(event="push")
        assert not result.success
        assert "not found" in result.stderr
        assert result.return_code == -1

    @patch("gasket.core.act_runner.subprocess.run")
    @patch("gasket.core.act_runner.find_act_executable")
    def test_successful_run(self, mock_find, mock_run):
        """Should return success on exit code 0."""
        mock_find.return_value = "/usr/bin/act"
        mock_run.return_value = MagicMock(
            returncode=0,
            stdout="[CI/build] completed\n",
            stderr="",
        )
        result = run_act(event="push")
        assert result.success
        assert result.return_code == 0
        assert "completed" in result.stdout

    @patch("gasket.core.act_runner.subprocess.run")
    @patch("gasket.core.act_runner.find_act_executable")
    def test_failed_run(self, mock_find, mock_run):
        """Should return failure on non-zero exit code."""
        mock_find.return_value = "/usr/bin/act"
        mock_run.return_value = MagicMock(
            returncode=1,
            stdout="",
            stderr="Error: workflow not found",
        )
        result = run_act(event="push")
        assert not result.success
        assert result.return_code == 1

    @patch("gasket.core.act_runner.subprocess.run")
    @patch("gasket.core.act_runner.find_act_executable")
    def test_timeout(self, mock_find, mock_run):
        """Should handle timeout gracefully."""
        mock_find.return_value = "/usr/bin/act"
        mock_run.side_effect = __import__("subprocess").TimeoutExpired(
            cmd="act", timeout=10
        )
        result = run_act(event="push", timeout=10)
        assert not result.success
        assert result.return_code == -2
        assert "timed out" in result.stderr

    @patch("gasket.core.act_runner.subprocess.run")
    @patch("gasket.core.act_runner.find_act_executable")
    def test_os_error(self, mock_find, mock_run):
        """Should handle OS errors gracefully."""
        mock_find.return_value = "/usr/bin/act"
        mock_run.side_effect = OSError("Permission denied")
        result = run_act(event="push")
        assert not result.success
        assert result.return_code == -3
        assert "Permission denied" in result.stderr


class TestActResultToDict:
    """Tests for ActResult serialization."""

    def test_to_dict(self):
        """Should serialize all fields correctly."""
        result = ActResult(
            success=True,
            command=["act", "push"],
            stdout="output",
            stderr="",
            return_code=0,
            workflows_run=["ci.yml"],
        )
        d = result.to_dict()
        assert d["success"] is True
        assert d["command"] == "act push"
        assert d["return_code"] == 0
        assert d["stdout"] == "output"
        assert d["workflows_run"] == ["ci.yml"]


class TestRunActCLI:
    """Integration tests for the run-act CLI command."""

    @patch("gasket.commands.run_act.find_act_executable")
    def test_act_not_installed(self, mock_find, runner):
        """Should display error when act is not found."""
        mock_find.return_value = None
        result = runner.invoke(cli, ["run-act"])
        assert result.exit_code == 3
        assert "[ERROR]" in result.output
        assert "not found" in result.output

    @patch("gasket.commands.run_act.run_act")
    @patch("gasket.commands.run_act.get_act_version")
    @patch("gasket.commands.run_act.find_act_executable")
    def test_successful_run(self, mock_find, mock_version, mock_run, runner):
        """Should display success message on successful run."""
        mock_find.return_value = "/usr/bin/act"
        mock_version.return_value = "act version 0.2.87"
        mock_run.return_value = ActResult(
            success=True,
            command=["act", "push"],
            stdout="[CI/build] completed\n",
            stderr="",
            return_code=0,
        )
        result = runner.invoke(cli, ["run-act"])
        assert result.exit_code == 0
        assert "[OK]" in result.output

    @patch("gasket.commands.run_act.run_act")
    @patch("gasket.commands.run_act.get_act_version")
    @patch("gasket.commands.run_act.find_act_executable")
    def test_dry_run_flag(self, mock_find, mock_version, mock_run, runner):
        """Should pass dry-run flag to act."""
        mock_find.return_value = "/usr/bin/act"
        mock_version.return_value = "act version 0.2.87"
        mock_run.return_value = ActResult(success=True, return_code=0)
        result = runner.invoke(cli, ["run-act", "--dry-run"])
        assert result.exit_code == 0
        mock_run.assert_called_once()
        call_kwargs = mock_run.call_args
        assert call_kwargs.kwargs.get("dry_run") is True

    @patch("gasket.commands.run_act.run_act")
    @patch("gasket.commands.run_act.get_act_version")
    @patch("gasket.commands.run_act.find_act_executable")
    def test_list_flag(self, mock_find, mock_version, mock_run, runner):
        """Should pass list flag to act."""
        mock_find.return_value = "/usr/bin/act"
        mock_version.return_value = "act version 0.2.87"
        mock_run.return_value = ActResult(
            success=True,
            stdout="Stage  Job ID  Job name  Workflow name  Events\n",
            return_code=0,
        )
        result = runner.invoke(cli, ["run-act", "--list"])
        assert result.exit_code == 0

    @patch("gasket.commands.run_act.run_act")
    @patch("gasket.commands.run_act.get_act_version")
    @patch("gasket.commands.run_act.find_act_executable")
    def test_failed_run(self, mock_find, mock_version, mock_run, runner):
        """Should display error on failed run."""
        mock_find.return_value = "/usr/bin/act"
        mock_version.return_value = "act version 0.2.87"
        mock_run.return_value = ActResult(
            success=False,
            command=["act", "push"],
            stderr="Error: workflow failed",
            return_code=1,
        )
        result = runner.invoke(cli, ["run-act"])
        assert result.exit_code == 1
        assert "[ERROR]" in result.output

    @patch("gasket.commands.run_act.run_act")
    @patch("gasket.commands.run_act.get_act_version")
    @patch("gasket.commands.run_act.find_act_executable")
    def test_secret_option(self, mock_find, mock_version, mock_run, runner):
        """Should parse and pass secrets correctly."""
        mock_find.return_value = "/usr/bin/act"
        mock_version.return_value = "act version 0.2.87"
        mock_run.return_value = ActResult(success=True, return_code=0)
        result = runner.invoke(
            cli, ["run-act", "-s", "TOKEN=abc123", "-s", "KEY=val"]
        )
        assert result.exit_code == 0
        call_kwargs = mock_run.call_args.kwargs
        assert call_kwargs["secrets"] == {"TOKEN": "abc123", "KEY": "val"}

    @patch("gasket.commands.run_act.run_act")
    @patch("gasket.commands.run_act.get_act_version")
    @patch("gasket.commands.run_act.find_act_executable")
    def test_event_option(self, mock_find, mock_version, mock_run, runner):
        """Should pass event type correctly."""
        mock_find.return_value = "/usr/bin/act"
        mock_version.return_value = "act version 0.2.87"
        mock_run.return_value = ActResult(success=True, return_code=0)
        result = runner.invoke(cli, ["run-act", "--event", "pull_request"])
        assert result.exit_code == 0
        call_kwargs = mock_run.call_args.kwargs
        assert call_kwargs["event"] == "pull_request"
