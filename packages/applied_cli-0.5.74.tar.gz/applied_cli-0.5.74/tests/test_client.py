import json

import pytest

from applied_cli.client import AppliedClient


@pytest.mark.asyncio
async def test_ensure_test_conversation_creates_contact_backed_conversation(
    monkeypatch,
):
    client = AppliedClient(token="test-token")
    seen = {}

    async def fake_get_or_create_contact(email=None, name=None, phone=None):
        seen["contact"] = {
            "email": email,
            "name": name,
            "phone": phone,
        }
        return {"id": "contact-1"}

    async def fake_create_conversation(
        agent_id,
        is_test=True,
        metadata=None,
        conversation_type=None,
        contact_id=None,
    ):
        seen["conversation"] = {
            "agent_id": agent_id,
            "is_test": is_test,
            "metadata": metadata,
            "conversation_type": conversation_type,
            "contact_id": contact_id,
        }
        return {"id": "conv-1"}

    monkeypatch.setattr(client, "get_or_create_contact", fake_get_or_create_contact)
    monkeypatch.setattr(client, "create_conversation", fake_create_conversation)

    conversation = await client.ensure_test_conversation(
        agent_id="agent-1",
        contact_email="customer@example.com",
        contact_name="Customer Example",
        metadata={"order_id": "123"},
        conversation_type="email",
    )

    assert conversation == {"id": "conv-1"}
    assert seen["contact"] == {
        "email": "customer@example.com",
        "name": "Customer Example",
        "phone": None,
    }
    assert seen["conversation"] == {
        "agent_id": "agent-1",
        "is_test": True,
        "metadata": {
            "order_id": "123",
            "context": {
                "email": "customer@example.com",
                "name": "Customer Example",
            },
        },
        "conversation_type": "email",
        "contact_id": "contact-1",
    }


@pytest.mark.asyncio
async def test_ensure_test_conversation_returns_existing_id_without_creating_new_one(
    monkeypatch,
):
    client = AppliedClient(token="test-token")

    async def fail_get_or_create_contact(**kwargs):
        raise AssertionError("should not create or lookup a contact")

    async def fail_create_conversation(**kwargs):
        raise AssertionError("should not create a conversation")

    monkeypatch.setattr(client, "get_or_create_contact", fail_get_or_create_contact)
    monkeypatch.setattr(client, "create_conversation", fail_create_conversation)

    conversation = await client.ensure_test_conversation(
        agent_id="agent-1",
        conversation_id="conv-existing",
        contact_email="ignored@example.com",
    )

    assert conversation == {"id": "conv-existing"}


@pytest.mark.asyncio
async def test_query_conversations_serializes_metric_event_filter_payload(monkeypatch):
    client = AppliedClient(token="test-token")
    seen = {}

    async def fake_request(method, path, params=None, body=None, shop_id=None):
        seen["method"] = method
        seen["path"] = path
        seen["params"] = params
        return []

    monkeypatch.setattr(client, "_request", fake_request)

    await client.query_conversations(
        filters={
            "created_at": {
                "gte": "2026-03-22T16:50:00Z",
                "lte": "2026-03-22T19:00:00Z",
            },
            "runs__emitted_metric_events__contains": {
                "tool.run": {
                    "tool_name": ["Escalate Conversation"],
                    "success": ["False"],
                }
            },
        }
    )

    assert seen["method"] == "GET"
    assert seen["path"] == "/v1/conversations/"
    assert seen["params"]["created_at__gte"] == "2026-03-22T16:50:00Z"
    assert seen["params"]["created_at__lte"] == "2026-03-22T19:00:00Z"
    assert seen["params"]["runs__emitted_metric_events__contains"] == json.dumps(
        {
            "tool.run": {
                "tool_name": ["Escalate Conversation"],
                "success": ["False"],
            }
        },
        separators=(",", ":"),
        ensure_ascii=True,
    )


@pytest.mark.asyncio
async def test_analytics_report_posts_payload(monkeypatch):
    client = AppliedClient(token="test-token")
    seen = {}

    async def fake_request(method, path, params=None, body=None, shop_id=None):
        seen["method"] = method
        seen["path"] = path
        seen["body"] = body
        return {"ok": True}

    monkeypatch.setattr(client, "_request", fake_request)

    result = await client.analytics_report(
        {
            "view": "dashboard_rate_metrics",
            "model": "conversation",
            "group_by": "agent_revision_version",
        }
    )

    assert result == {"ok": True}
    assert seen == {
        "method": "POST",
        "path": "/v2/analytics/",
        "body": {
            "view": "dashboard_rate_metrics",
            "model": "conversation",
            "group_by": "agent_revision_version",
        },
    }


@pytest.mark.asyncio
async def test_analytics_sql_fails_fast_without_public_endpoint(monkeypatch):
    client = AppliedClient(token="test-token")

    async def fake_request(method, path, params=None, body=None, shop_id=None):
        raise AssertionError("analytics_sql should not call removed endpoints")

    monkeypatch.setattr(client, "_request", fake_request)

    with pytest.raises(ValueError, match="/v2/analytics/"):
        await client.analytics_sql(
            sql="SELECT count() AS total FROM conversation_latest_state",
            parameters={"resolution": "escalated"},
            max_rows=25,
        )


@pytest.mark.asyncio
async def test_analytics_query_uses_dashboard_rate_metrics(monkeypatch):
    client = AppliedClient(token="test-token")
    seen = {}

    async def fake_analytics_report(payload):
        seen["payload"] = payload
        return {
            "count": [
                {
                    "period": None,
                    "group": "escalated",
                    "denominator": 0,
                    "numerator": 4,
                    "rate": 4,
                }
            ]
        }

    monkeypatch.setattr(client, "analytics_report", fake_analytics_report)

    result = await client.analytics_query(
        group_by=["resolution"],
        metrics=["count"],
        filters=["agent_id=agent-1", "score=2"],
        start="2026-03-01",
        end="2026-03-31",
        limit=100,
    )

    assert result["rows"] == [{"resolution": "escalated", "count": 4}]
    assert result["dimensions"] == ["resolution"]
    assert result["metrics"] == ["count"]
    assert seen["payload"] == {
        "view": "dashboard_rate_metrics",
        "model": "conversation",
        "group_by": "resolution",
        "custom_rate_metrics_requests": [{"rate": "count", "numerator": "total"}],
        "start_date": "2026-03-01",
        "end_date": "2026-03-31",
        "conversation_filters": {"agent_id": "agent-1", "score": 2},
    }


@pytest.mark.asyncio
async def test_analytics_query_uses_automation_aggregates_for_intent_names(monkeypatch):
    client = AppliedClient(token="test-token")
    seen = {}

    async def fake_analytics_report(payload):
        seen["payload"] = payload
        return {
            "by_intent": [
                {"sublabel_name": "Returns", "total": 2},
                {"sublabel_name": "Returns", "total": 3},
                {"sublabel_name": "Shipping", "total": 1},
            ]
        }

    monkeypatch.setattr(client, "analytics_report", fake_analytics_report)

    result = await client.analytics_query(
        group_by=["sublabel_name"],
        metrics=["count"],
        start="2026-04-27",
        end="2026-05-01",
        limit=10,
    )

    assert result["columns"] == ["sublabel_name", "count"]
    assert result["rows"] == [
        {"sublabel_name": "Returns", "count": 5},
        {"sublabel_name": "Shipping", "count": 1},
    ]
    assert seen["payload"] == {
        "view": "automation_aggregates",
        "model": "conversation",
        "start_date": "2026-04-27",
        "end_date": "2026-05-01",
    }


@pytest.mark.asyncio
async def test_list_audit_batches_queries_new_batch_endpoint(monkeypatch):
    client = AppliedClient(token="test-token")
    seen = {}

    async def fake_request(method, path, params=None, body=None, shop_id=None):
        seen["method"] = method
        seen["path"] = path
        seen["params"] = params
        return {"results": [{"id": "audit-batch-1"}]}

    monkeypatch.setattr(client, "_request", fake_request)

    result = await client.list_audit_batches(
        target_type="conversation",
        status="in_progress",
        period_end_gte="2026-03-16",
        period_start_lte="2026-03-22",
    )

    assert result == [{"id": "audit-batch-1"}]
    assert seen == {
        "method": "GET",
        "path": "/v1/audit-batches/",
        "params": {
            "limit": 100,
            "target_type": "conversation",
            "status": "in_progress",
            "period_end__gte": "2026-03-16",
            "period_start__lte": "2026-03-22",
        },
    }


@pytest.mark.asyncio
async def test_update_audit_rating_patches_notes(monkeypatch):
    client = AppliedClient(token="test-token")
    seen = {}

    async def fake_request(method, path, params=None, body=None, shop_id=None):
        seen["method"] = method
        seen["path"] = path
        seen["body"] = body
        return {"id": "audit-rating-1", "notes": body["notes"]}

    monkeypatch.setattr(client, "_request", fake_request)

    result = await client.update_audit_rating(
        "audit-rating-1",
        notes="Root cause is missing payout tooling.",
        quality_score=2.0,
    )

    assert result == {
        "id": "audit-rating-1",
        "notes": "Root cause is missing payout tooling.",
    }
    assert seen == {
        "method": "PATCH",
        "path": "/v1/audit-ratings/audit-rating-1/",
        "body": {
            "notes": "Root cause is missing payout tooling.",
            "quality_score": 2.0,
        },
    }


@pytest.mark.asyncio
async def test_set_audit_rating_value_posts_metric_payload(monkeypatch):
    client = AppliedClient(token="test-token")
    seen = {}

    async def fake_request(method, path, params=None, body=None, shop_id=None):
        seen["method"] = method
        seen["path"] = path
        seen["body"] = body
        return {"ok": True}

    monkeypatch.setattr(client, "_request", fake_request)

    result = await client.set_audit_rating_value(
        "audit-rating-1",
        metric_field_id="field-1",
        value={"choice": "Needs action"},
    )

    assert result == {"ok": True}
    assert seen == {
        "method": "POST",
        "path": "/v1/audit-ratings/audit-rating-1/set-value/",
        "body": {
            "metric_field_id": "field-1",
            "value": {"choice": "Needs action"},
        },
    }


@pytest.mark.asyncio
async def test_list_knowledge_adds_content_source_and_content_presence_params(monkeypatch):
    client = AppliedClient(token="test-token")
    seen = {}

    async def fake_request(method, path, params=None, body=None, shop_id=None):
        seen["method"] = method
        seen["path"] = path
        seen["params"] = params
        return {"results": [{"id": "resp-1"}]}

    monkeypatch.setattr(client, "_request", fake_request)

    result = await client.list_knowledge(
        kb_type="qa",
        search="refund",
        content_id="content-1",
        source="https://help.example.com",
        has_content=True,
        limit=25,
    )

    assert result == [{"id": "resp-1"}]
    assert seen == {
        "method": "GET",
        "path": "/v1/responses/",
        "params": {
            "limit": 25,
            "type": "qa",
            "search": "refund",
            "content_id": "content-1",
            "source": "https://help.example.com",
            "content__isnull": "false",
        },
    }


@pytest.mark.asyncio
async def test_list_content_adds_source_param(monkeypatch):
    client = AppliedClient(token="test-token")
    seen = {}

    async def fake_request(method, path, params=None, body=None, shop_id=None):
        seen["method"] = method
        seen["path"] = path
        seen["params"] = params
        return {"results": [{"id": "content-1"}]}

    monkeypatch.setattr(client, "_request", fake_request)

    result = await client.list_content(
        content_type="Article",
        source="https://help.example.com",
        limit=50,
    )

    assert result == [{"id": "content-1"}]
    assert seen == {
        "method": "GET",
        "path": "/v1/content/",
        "params": {
            "limit": 50,
            "type": "Article",
            "source": "https://help.example.com",
        },
    }


@pytest.mark.asyncio
async def test_resync_content_posts_resync_endpoint(monkeypatch):
    client = AppliedClient(token="test-token")
    seen = {}

    async def fake_request(method, path, params=None, body=None, shop_id=None):
        seen["method"] = method
        seen["path"] = path
        seen["body"] = body
        return {"id": "content-1", "is_syncing": True}

    monkeypatch.setattr(client, "_request", fake_request)

    result = await client.resync_content("content-1")

    assert result == {"id": "content-1", "is_syncing": True}
    assert seen == {
        "method": "POST",
        "path": "/v1/content/content-1/resync/",
        "body": None,
    }


@pytest.mark.asyncio
async def test_pin_response_patches_pinned_field(monkeypatch):
    client = AppliedClient(token="test-token")
    seen = {}

    async def fake_request(method, path, params=None, body=None, shop_id=None):
        seen["method"] = method
        seen["path"] = path
        seen["body"] = body
        return {"id": "resp-1", "pinned": True}

    monkeypatch.setattr(client, "_request", fake_request)

    result = await client.pin_response("resp-1")

    assert result == {"id": "resp-1", "pinned": True}
    assert seen == {
        "method": "PATCH",
        "path": "/v1/responses/resp-1/",
        "body": {"pinned": True},
    }


@pytest.mark.asyncio
async def test_create_response_includes_chunk_text(monkeypatch):
    client = AppliedClient(token="test-token")
    seen = {}

    async def fake_request(method, path, params=None, body=None, shop_id=None):
        seen["method"] = method
        seen["path"] = path
        seen["body"] = body
        return {"id": "resp-1"}

    monkeypatch.setattr(client, "_request", fake_request)

    result = await client.create_response(
        kb_type="qa",
        question="Cover image guidelines",
        answer="Use a square cover image.",
        chunk_text="Raw article chunk.",
    )

    assert result == {"id": "resp-1"}
    assert seen == {
        "method": "POST",
        "path": "/v1/responses/",
        "body": {
            "type": "qa",
            "question": "Cover image guidelines",
            "answer": "Use a square cover image.",
            "active": True,
            "chunk_text": "Raw article chunk.",
        },
    }
