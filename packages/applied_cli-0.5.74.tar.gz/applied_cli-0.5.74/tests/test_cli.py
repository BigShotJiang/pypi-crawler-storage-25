from typer.testing import CliRunner

from applied_cli import __version__, cli

runner = CliRunner()


def test_version_flag_long():
    result = runner.invoke(cli.app, ["--version"])

    assert result.exit_code == 0
    assert result.stdout == f"applied {__version__}\n"


def test_version_flag_short():
    result = runner.invoke(cli.app, ["-V"])

    assert result.exit_code == 0
    assert result.stdout == f"applied {__version__}\n"


def test_analytics_sql_command_accepts_inline_sql(monkeypatch):
    seen = {}

    async def fake_analytics_sql(
        client,
        *,
        sql,
        parameters=None,
        limit=None,
        output_format="csv",
    ):
        seen["sql"] = sql
        seen["parameters"] = parameters
        seen["limit"] = limit
        seen["output_format"] = output_format
        return "ok-inline"

    monkeypatch.setattr(cli, "get_client", lambda shop_id=None: object())
    monkeypatch.setattr(cli.tools, "analytics_sql", fake_analytics_sql)

    result = runner.invoke(
        cli.app,
        [
            "analytics-sql",
            "--sql",
            "SELECT count() AS total FROM conversation_latest_state",
            "--param",
            'resolution="escalated"',
            "--param",
            "counts=[1,2]",
            "--limit",
            "25",
            "--format",
            "json",
        ],
    )

    assert result.exit_code == 0
    assert "ok-inline" in result.stdout
    assert seen == {
        "sql": "SELECT count() AS total FROM conversation_latest_state",
        "parameters": {"resolution": "escalated", "counts": [1, 2]},
        "limit": 25,
        "output_format": "json",
    }


def test_analytics_sql_command_accepts_sql_file(monkeypatch, tmp_path):
    query_file = tmp_path / "query.sql"
    query_file.write_text(
        "SELECT resolution, count() AS count FROM conversation_latest_state",
        encoding="utf-8",
    )
    seen = {}

    async def fake_analytics_sql(
        client,
        *,
        sql,
        parameters=None,
        limit=None,
        output_format="csv",
    ):
        seen["sql"] = sql
        return "ok-file"

    monkeypatch.setattr(cli, "get_client", lambda shop_id=None: object())
    monkeypatch.setattr(cli.tools, "analytics_sql", fake_analytics_sql)

    result = runner.invoke(cli.app, ["analytics-sql", "--file", str(query_file)])

    assert result.exit_code == 0
    assert "ok-file" in result.stdout
    assert seen["sql"] == query_file.read_text(encoding="utf-8")


def test_knowledge_command_fetches_single_item(monkeypatch):
    seen = {}

    async def fake_knowledge_get(client, knowledge_id, output_format="text"):
        seen["client"] = client
        seen["knowledge_id"] = knowledge_id
        seen["output_format"] = output_format
        return "ok-knowledge"

    monkeypatch.setattr(cli, "get_client", lambda shop_id=None: "client")
    monkeypatch.setattr(cli.tools, "knowledge_get", fake_knowledge_get)

    result = runner.invoke(cli.app, ["knowledge", "resp-1", "--format", "json"])

    assert result.exit_code == 0
    assert "ok-knowledge" in result.stdout
    assert seen == {
        "client": "client",
        "knowledge_id": "resp-1",
        "output_format": "json",
    }


def test_knowledge_command_passes_audit_filters(monkeypatch):
    seen = {}

    async def fake_knowledge_list(
        client,
        *,
        kb_type=None,
        search=None,
        linked_to=None,
        source=None,
        has_content=None,
        limit=100,
        fetch_all=False,
        full=False,
        output_format="csv",
    ):
        seen.update(
            {
                "client": client,
                "kb_type": kb_type,
                "search": search,
                "linked_to": linked_to,
                "source": source,
                "has_content": has_content,
                "limit": limit,
                "fetch_all": fetch_all,
                "full": full,
                "output_format": output_format,
            }
        )
        return "ok-list"

    monkeypatch.setattr(cli, "get_client", lambda shop_id=None: f"client-{shop_id}")
    monkeypatch.setattr(cli.tools, "knowledge_list", fake_knowledge_list)

    result = runner.invoke(
        cli.app,
        [
            "knowledge",
            "--type",
            "qa",
            "--search",
            "refund",
            "--linked-to",
            "content-1",
            "--source",
            "https://help.example.com",
            "--has-content",
            "--limit",
            "25",
            "--no-all",
            "--full",
            "--format",
            "json",
            "--shop-id",
            "shop-1",
        ],
    )

    assert result.exit_code == 0
    assert "ok-list" in result.stdout
    assert seen == {
        "client": "client-shop-1",
        "kb_type": "qa",
        "search": "refund",
        "linked_to": "content-1",
        "source": "https://help.example.com",
        "has_content": True,
        "limit": 25,
        "fetch_all": False,
        "full": True,
        "output_format": "json",
    }


def test_content_list_command_passes_source(monkeypatch):
    seen = {}

    async def fake_content_list(
        client,
        *,
        content_type=None,
        status=None,
        search=None,
        source=None,
        limit=100,
        fetch_all=False,
        full=False,
        output_format="csv",
    ):
        seen.update(
            {
                "client": client,
                "content_type": content_type,
                "status": status,
                "search": search,
                "source": source,
                "limit": limit,
                "fetch_all": fetch_all,
                "full": full,
                "output_format": output_format,
            }
        )
        return "ok-content"

    monkeypatch.setattr(cli, "get_client", lambda shop_id=None: "client")
    monkeypatch.setattr(cli.tools, "content_list", fake_content_list)

    result = runner.invoke(
        cli.app,
        [
            "content",
            "list",
            "--type",
            "Article",
            "--source",
            "https://help.example.com",
            "--format",
            "json",
            "--full",
        ],
    )

    assert result.exit_code == 0
    assert "ok-content" in result.stdout
    assert seen == {
        "client": "client",
        "content_type": "Article",
        "status": None,
        "search": None,
        "source": "https://help.example.com",
        "limit": 100,
        "fetch_all": True,
        "full": True,
        "output_format": "json",
    }


def test_content_resync_command_passes_wait(monkeypatch):
    seen = {}

    async def fake_content_resync(
        client,
        content_id,
        *,
        wait=False,
        poll_interval=2.0,
        timeout=300.0,
        output_format="text",
    ):
        seen.update(
            {
                "client": client,
                "content_id": content_id,
                "wait": wait,
                "poll_interval": poll_interval,
                "timeout": timeout,
                "output_format": output_format,
            }
        )
        return "ok-resync"

    monkeypatch.setattr(cli, "get_client", lambda shop_id=None: "client")
    monkeypatch.setattr(cli.tools, "content_resync", fake_content_resync)

    result = runner.invoke(
        cli.app,
        [
            "content-resync",
            "content-1",
            "--wait",
            "--poll-interval",
            "0.5",
            "--timeout",
            "10",
            "--format",
            "json",
        ],
    )

    assert result.exit_code == 0
    assert "ok-resync" in result.stdout
    assert seen == {
        "client": "client",
        "content_id": "content-1",
        "wait": True,
        "poll_interval": 0.5,
        "timeout": 10.0,
        "output_format": "json",
    }


def test_knowledge_pin_command_passes_unpin(monkeypatch):
    seen = {}

    async def fake_knowledge_pin(
        client,
        knowledge_id,
        *,
        pinned=True,
        output_format="text",
    ):
        seen.update(
            {
                "client": client,
                "knowledge_id": knowledge_id,
                "pinned": pinned,
                "output_format": output_format,
            }
        )
        return "ok-pin"

    monkeypatch.setattr(cli, "get_client", lambda shop_id=None: "client")
    monkeypatch.setattr(cli.tools, "knowledge_pin", fake_knowledge_pin)

    result = runner.invoke(
        cli.app,
        ["knowledge-pin", "resp-1", "--unpin", "--format", "json"],
    )

    assert result.exit_code == 0
    assert "ok-pin" in result.stdout
    assert seen == {
        "client": "client",
        "knowledge_id": "resp-1",
        "pinned": False,
        "output_format": "json",
    }


def test_content_update_command_passes_text(monkeypatch):
    seen = {}

    async def fake_content_update(
        client,
        content_id,
        *,
        text=None,
        title=None,
        description=None,
        status=None,
        output_format="text",
    ):
        seen.update(
            {
                "client": client,
                "content_id": content_id,
                "text": text,
                "title": title,
                "description": description,
                "status": status,
                "output_format": output_format,
            }
        )
        return "ok-content-update"

    monkeypatch.setattr(cli, "get_client", lambda shop_id=None: "client")
    monkeypatch.setattr(cli.tools, "content_update", fake_content_update)

    result = runner.invoke(
        cli.app,
        ["content-update", "content-1", "--text", "Corrected source", "--format", "json"],
    )

    assert result.exit_code == 0
    assert "ok-content-update" in result.stdout
    assert seen == {
        "client": "client",
        "content_id": "content-1",
        "text": "Corrected source",
        "title": None,
        "description": None,
        "status": None,
        "output_format": "json",
    }


def test_knowledge_link_command_passes_content_id(monkeypatch):
    seen = {}

    async def fake_knowledge_link(
        client,
        knowledge_id,
        *,
        content_id,
        output_format="text",
    ):
        seen.update(
            {
                "client": client,
                "knowledge_id": knowledge_id,
                "content_id": content_id,
                "output_format": output_format,
            }
        )
        return "ok-link"

    monkeypatch.setattr(cli, "get_client", lambda shop_id=None: "client")
    monkeypatch.setattr(cli.tools, "knowledge_link", fake_knowledge_link)

    result = runner.invoke(
        cli.app,
        ["knowledge-link", "resp-1", "--content", "content-1", "--format", "json"],
    )

    assert result.exit_code == 0
    assert "ok-link" in result.stdout
    assert seen == {
        "client": "client",
        "knowledge_id": "resp-1",
        "content_id": "content-1",
        "output_format": "json",
    }


def test_knowledge_protect_command_disables_autogeneration(monkeypatch):
    seen = {}

    async def fake_knowledge_protect(
        client,
        knowledge_id,
        *,
        protected=True,
        output_format="text",
    ):
        seen.update(
            {
                "client": client,
                "knowledge_id": knowledge_id,
                "protected": protected,
                "output_format": output_format,
            }
        )
        return "ok-protect"

    monkeypatch.setattr(cli, "get_client", lambda shop_id=None: "client")
    monkeypatch.setattr(cli.tools, "knowledge_protect", fake_knowledge_protect)

    result = runner.invoke(
        cli.app,
        ["knowledge-protect", "resp-1", "--format", "json"],
    )

    assert result.exit_code == 0
    assert "ok-protect" in result.stdout
    assert seen == {
        "client": "client",
        "knowledge_id": "resp-1",
        "protected": True,
        "output_format": "json",
    }


def test_knowledge_unprotect_command_enables_autogeneration(monkeypatch):
    seen = {}

    async def fake_knowledge_protect(
        client,
        knowledge_id,
        *,
        protected=True,
        output_format="text",
    ):
        seen.update(
            {
                "client": client,
                "knowledge_id": knowledge_id,
                "protected": protected,
                "output_format": output_format,
            }
        )
        return "ok-unprotect"

    monkeypatch.setattr(cli, "get_client", lambda shop_id=None: "client")
    monkeypatch.setattr(cli.tools, "knowledge_protect", fake_knowledge_protect)

    result = runner.invoke(
        cli.app,
        ["knowledge-unprotect", "resp-1", "--format", "json"],
    )

    assert result.exit_code == 0
    assert "ok-unprotect" in result.stdout
    assert seen == {
        "client": "client",
        "knowledge_id": "resp-1",
        "protected": False,
        "output_format": "json",
    }


def test_knowledge_create_command_passes_chunk_text(monkeypatch):
    seen = {}

    async def fake_knowledge_create(
        client,
        *,
        kb_type,
        question,
        answer,
        chunk_text=None,
        guardrail="",
        active=True,
        agent_ids=None,
        label_id=None,
        flow_id=None,
    ):
        seen.update(
            {
                "client": client,
                "kb_type": kb_type,
                "question": question,
                "answer": answer,
                "chunk_text": chunk_text,
                "guardrail": guardrail,
                "active": active,
                "agent_ids": agent_ids,
                "label_id": label_id,
                "flow_id": flow_id,
            }
        )
        return "ok-create"

    monkeypatch.setattr(cli, "get_client", lambda shop_id=None: "client")
    monkeypatch.setattr(cli.tools, "knowledge_create", fake_knowledge_create)

    result = runner.invoke(
        cli.app,
        [
            "knowledge-create",
            "--type",
            "qa",
            "--question",
            "Cover image guidelines",
            "--answer",
            "Use a square cover image.",
            "--chunk-text",
            "Raw article chunk.",
        ],
    )

    assert result.exit_code == 0
    assert "ok-create" in result.stdout
    assert seen["chunk_text"] == "Raw article chunk."
