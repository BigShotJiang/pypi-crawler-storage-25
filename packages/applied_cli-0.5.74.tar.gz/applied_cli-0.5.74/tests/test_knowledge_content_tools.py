import json

import pytest

from applied_cli import tools


class KnowledgeContentClient:
    def __init__(self):
        self.list_knowledge_kwargs = None
        self.list_content_kwargs = None
        self.update_response_kwargs = None
        self.create_response_kwargs = None
        self.update_content_kwargs = None
        self.pin_response_kwargs = None
        self.get_content_calls = 0
        self.resync_started = False
        self.knowledge_items = [
            {
                "id": "resp-1",
                "type": "qa",
                "question": "How do refunds work?",
                "answer": "Full refund answer " * 20,
                "chunk_text": "Refunds are available for eligible orders.",
                "content": {
                    "id": "content-1",
                "source_url": "https://help.example.com/refunds",
                "detail": "Original article detail",
                "remote_id": "etag-123",
                "last_synced_at": "2026-05-01T12:05:00Z",
            },
                "updated_at": "2026-05-01T12:00:00Z",
                "high_relevance_count_28d": 7,
                "active": True,
            },
            {
                "id": "resp-2",
                "type": "qa",
                "question": "Shipping",
                "answer": "Shipping answer",
                "content": {
                    "id": "content-2",
                    "source_url": "https://other.example.com/shipping",
                },
                "active": True,
            },
            {
                "id": "resp-3",
                "type": "qa",
                "question": "Manual",
                "answer": "Manual answer",
                "active": True,
            },
        ]
        self.content_items = [
            {
                "id": "content-1",
                "type": "Article",
                "title": "Refunds",
                "source_url": "https://help.example.com/refunds",
                "remote_id": "etag-123",
                "last_synced_at": "2026-05-01T12:05:00Z",
                "updated_at": "2026-05-01T12:00:00Z",
                "is_syncing": False,
            },
            {
                "id": "content-2",
                "type": "Article",
                "title": "Shipping",
                "source_url": "https://other.example.com/shipping",
            },
        ]

    async def list_knowledge(self, **kwargs):
        self.list_knowledge_kwargs = kwargs
        return list(self.knowledge_items)

    async def get_knowledge(self, knowledge_id):
        return next(item for item in self.knowledge_items if item["id"] == knowledge_id)

    async def get_knowledge_batch(self, knowledge_ids):
        return [
            item for item in self.knowledge_items if item.get("id") in set(knowledge_ids)
        ]

    async def create_response(self, **kwargs):
        self.create_response_kwargs = kwargs
        return {
            "id": "resp-new",
            "type": kwargs["kb_type"],
            "active": kwargs["active"],
            "question": kwargs["question"],
        }

    async def update_response(self, knowledge_id, **updates):
        self.update_response_kwargs = {
            "knowledge_id": knowledge_id,
            "updates": updates,
        }
        return {"id": knowledge_id, "type": "qa", "active": True}

    async def pin_response(self, knowledge_id, *, pinned=True):
        self.pin_response_kwargs = {
            "knowledge_id": knowledge_id,
            "pinned": pinned,
        }
        return {"id": knowledge_id, "pinned": pinned}

    async def list_content(self, **kwargs):
        self.list_content_kwargs = kwargs
        return list(self.content_items)

    async def resync_content(self, content_id):
        self.resync_started = True
        return {"id": content_id, "is_syncing": True}

    async def update_content(self, content_id, **updates):
        self.update_content_kwargs = {
            "content_id": content_id,
            "updates": updates,
        }
        return {"id": content_id, "title": "Refunds", "status": "Published", **updates}

    async def get_content(self, content_id):
        self.get_content_calls += 1
        if content_id == "content-1":
            return {
                "id": "content-1",
                "source_url": "https://help.example.com/refunds",
                "text": "Refunds are available for eligible orders. Current policy.",
                "is_syncing": self.resync_started and self.get_content_calls == 1,
            }
        return next(item for item in self.content_items if item["id"] == content_id)


@pytest.mark.asyncio
async def test_knowledge_list_json_keeps_full_fields_and_filters_locally():
    client = KnowledgeContentClient()

    result = await tools.knowledge_list(
        client,
        linked_to="content-1",
        source="https://help.example.com",
        has_content=True,
        fetch_all=True,
        output_format="json",
    )

    rows = json.loads(result)
    assert [row["id"] for row in rows] == ["resp-1"]
    assert rows[0]["answer"] == "Full refund answer " * 20
    assert rows[0]["chunk_text"] == "Refunds are available for eligible orders."
    assert rows[0]["content"]["id"] == "content-1"
    assert client.list_knowledge_kwargs["content_id"] == "content-1"
    assert client.list_knowledge_kwargs["source"] == "https://help.example.com"
    assert client.list_knowledge_kwargs["has_content"] is True


@pytest.mark.asyncio
async def test_knowledge_list_full_csv_includes_audit_fields():
    client = KnowledgeContentClient()

    result = await tools.knowledge_list(
        client,
        linked_to="content-1",
        full=True,
        output_format="csv",
    )

    assert result.startswith(
        "id,type,question,answer,chunk_text,content_id,content_source_url,"
        "content_detail,remote_id,last_synced_at,change_detection_status,"
        "would_skip_if_remote_unchanged,updated_at,high_relevance_count_28d,"
        "active,pinned"
    )
    assert "Original article detail" in result
    assert "etag-123" in result
    assert "tracked_by_remote_id" in result
    assert "7" in result


@pytest.mark.asyncio
async def test_knowledge_create_accepts_chunk_text():
    client = KnowledgeContentClient()

    result = await tools.knowledge_create(
        client,
        kb_type="qa",
        question="Cover image guidelines",
        answer="Use a square cover image.",
        chunk_text="Raw article section about square cover images.",
    )

    assert "# Created Knowledge Item" in result
    assert client.create_response_kwargs["chunk_text"] == (
        "Raw article section about square cover images."
    )


@pytest.mark.asyncio
async def test_knowledge_update_warns_when_answer_touches_linked_content():
    client = KnowledgeContentClient()

    result = await tools.knowledge_update(
        client,
        "resp-1",
        answer="Manual Explore edit",
    )

    assert "Warning: This response is linked to content ID content-1" in result
    assert client.update_response_kwargs == {
        "knowledge_id": "resp-1",
        "updates": {"answer": "Manual Explore edit"},
    }


@pytest.mark.asyncio
async def test_knowledge_update_pin_sets_pinned_field_without_warning():
    client = KnowledgeContentClient()

    result = await tools.knowledge_update(
        client,
        "resp-1",
        answer="Manual Explore edit",
        pin=True,
    )

    assert "Warning:" not in result
    assert client.update_response_kwargs["updates"] == {
        "answer": "Manual Explore edit",
        "pinned": True,
    }


@pytest.mark.asyncio
async def test_knowledge_pin_calls_client_pin_response():
    client = KnowledgeContentClient()

    result = await tools.knowledge_pin(
        client,
        "resp-1",
        pinned=False,
        output_format="json",
    )

    assert json.loads(result) == {"id": "resp-1", "pinned": False}
    assert client.pin_response_kwargs == {
        "knowledge_id": "resp-1",
        "pinned": False,
    }


@pytest.mark.asyncio
async def test_knowledge_link_sets_content_fk():
    client = KnowledgeContentClient()

    result = await tools.knowledge_link(
        client,
        "resp-3",
        content_id="content-1",
    )

    assert "# Linked Knowledge Item" in result
    assert client.update_response_kwargs == {
        "knowledge_id": "resp-3",
        "updates": {"content": "content-1"},
    }


@pytest.mark.asyncio
async def test_knowledge_protect_disables_linked_content_autogeneration():
    client = KnowledgeContentClient()

    result = await tools.knowledge_protect(
        client,
        "resp-1",
        output_format="json",
    )

    payload = json.loads(result)
    assert payload["protected"] is True
    assert payload["should_autogenerate_responses"] is False
    assert client.update_content_kwargs == {
        "content_id": "content-1",
        "updates": {"should_autogenerate_responses": False},
    }


@pytest.mark.asyncio
async def test_knowledge_unprotect_enables_linked_content_autogeneration():
    client = KnowledgeContentClient()

    result = await tools.knowledge_protect(
        client,
        "resp-1",
        protected=False,
        output_format="json",
    )

    payload = json.loads(result)
    assert payload["protected"] is False
    assert payload["should_autogenerate_responses"] is True
    assert client.update_content_kwargs == {
        "content_id": "content-1",
        "updates": {"should_autogenerate_responses": True},
    }


@pytest.mark.asyncio
async def test_content_list_filters_by_source():
    client = KnowledgeContentClient()

    result = await tools.content_list(
        client,
        source="https://help.example.com",
        output_format="json",
    )

    rows = json.loads(result)
    assert [row["id"] for row in rows] == ["content-1"]
    assert client.list_content_kwargs["source"] == "https://help.example.com"


@pytest.mark.asyncio
async def test_content_update_sets_text_source_of_truth():
    client = KnowledgeContentClient()

    result = await tools.content_update(
        client,
        "content-1",
        text="Corrected source text",
    )

    assert "# Updated Content" in result
    assert client.update_content_kwargs == {
        "content_id": "content-1",
        "updates": {"text": "Corrected source text"},
    }


@pytest.mark.asyncio
async def test_content_resync_wait_polls_until_not_syncing():
    client = KnowledgeContentClient()

    result = await tools.content_resync(
        client,
        "content-1",
        wait=True,
        poll_interval=0,
        timeout=1,
        output_format="json",
    )

    payload = json.loads(result)
    assert payload["completed"] is True
    assert client.get_content_calls == 2


@pytest.mark.asyncio
async def test_knowledge_diff_reports_answer_missing_from_current_source(monkeypatch):
    client = KnowledgeContentClient()

    async def fake_fetch_source_texts(urls, *, timeout=20.0):
        return {
            "https://help.example.com/refunds": {
                "ok": True,
                "text": "Refunds are available for eligible orders. Current policy.",
            }
        }

    monkeypatch.setattr(tools, "_fetch_source_texts", fake_fetch_source_texts)

    result = await tools.knowledge_diff(
        client,
        source="https://help.example.com",
        output_format="json",
    )

    payload = json.loads(result)
    assert payload["checked"] == 1
    assert payload["mismatch_count"] == 1
    assert payload["mismatches"][0]["id"] == "resp-1"
    assert payload["mismatches"][0]["checks"][0]["field"] == "answer"
