"""Applied Labs API client."""

import asyncio
import json
import os
import uuid
from typing import Any

import httpx

ACCESS_MODE_ENV_VAR = "APPLIED_ASSISTANT_ACCESS_MODE"
ASSISTANT_CONVERSATION_ENV_VAR = "APPLIED_ASSISTANT_CONVERSATION_ID"
FULL_ACCESS_MODE = "full_access"
DEFAULT_ACCESS_MODE = "default"
READ_ONLY_ACCESS_MODE = "read_only"
MUTATING_METHODS = {"POST", "PATCH", "DELETE", "PUT"}
OBJECT_COLLECTION_LABELS = {
    "agents": "Agent",
    "c": "Conversation",
    "conversations": "Conversation",
    "content": "Content",
    "flows": "Flow",
    "nodes": "Flow node",
    "edges": "Flow edge",
    "products": "Product",
    "responses": "Response",
    "tickets": "Ticket",
    "tools": "Tool",
}


def _normalize_access_mode(access_mode: str | None) -> str:
    if access_mode is None or not access_mode.strip():
        return FULL_ACCESS_MODE

    normalized = access_mode.strip().lower().replace("-", "_")
    if normalized in {FULL_ACCESS_MODE, DEFAULT_ACCESS_MODE, READ_ONLY_ACCESS_MODE}:
        return normalized
    return DEFAULT_ACCESS_MODE


def _json_safe(value: Any) -> Any:
    try:
        return json.loads(json.dumps(value, default=str, ensure_ascii=True))
    except (TypeError, ValueError):
        return str(value)


def _infer_change_action(method: str) -> str:
    method = method.upper()
    if method == "POST":
        return "add"
    if method == "DELETE":
        return "remove"
    return "update"


def _infer_object_reference(path: str, body: Any) -> tuple[str, str, str]:
    parts = [part for part in path.split("?", 1)[0].strip("/").split("/") if part]
    if parts and parts[0].startswith("v") and len(parts) > 1:
        parts = parts[1:]

    object_type = "DB object"
    object_id = ""
    for index, part in enumerate(parts):
        collection = part.replace("-", "_")
        if collection not in OBJECT_COLLECTION_LABELS:
            continue
        object_type = OBJECT_COLLECTION_LABELS[collection]
        if index + 1 < len(parts):
            candidate = parts[index + 1]
            if candidate.replace("-", "_") not in OBJECT_COLLECTION_LABELS:
                object_id = candidate

    object_name = ""
    if isinstance(body, dict):
        for key in ("name", "title", "label", "display_name", "displayName"):
            value = body.get(key)
            if isinstance(value, str) and value.strip():
                object_name = value.strip()
                break

    return object_type, object_id, object_name


def _candidate_after(before: Any, body: Any, after: Any) -> Any:
    if after is not None:
        return after
    if isinstance(before, dict) and isinstance(body, dict):
        return {**before, **body}
    return body or {}


class AppliedAPIError(Exception):
    """API error with details and recovery suggestions."""

    def __init__(
        self,
        message: str,
        status_code: int,
        detail: str | None = None,
        suggestion: str | None = None,
    ):
        self.status_code = status_code
        self.detail = detail
        self.suggestion = suggestion
        full_message = f"[{status_code}] {message}"
        if detail:
            full_message += f"\nDetail: {detail}"
        if suggestion:
            full_message += f"\n\n💡 Suggestion: {suggestion}"
        super().__init__(full_message)


def _get_error_suggestion(
    status_code: int,
    path: str,
    detail: str,
    body: dict | None,
) -> str | None:
    """Return actionable suggestion based on error context."""
    detail_lower = detail.lower() if detail else ""

    # Edge creation errors
    if "/edges" in path and status_code == 400:
        if "source" in detail_lower or "handle" in detail_lower:
            return (
                "Invalid source_handle. For branch nodes, valid handles are '1', '2', '3', etc. "
                "(matching comparison index) or 'default'. "
                "Run flow_get(flow_id) to see the node's output schema."
            )
        if "cycle" in detail_lower:
            return (
                "This edge would create a cycle. Check your flow graph - "
                "you may be connecting back to an ancestor node. "
                "Use flow_get(flow_id) to visualize the current edges."
            )
        if "target" in detail_lower:
            return "Target node not found. Verify the node_id exists with flow_get(flow_id)."

    # Node errors
    if "/nodes" in path:
        if status_code == 400:
            if "executor" in detail_lower or "name" in detail_lower:
                return (
                    "Invalid executor_type. Common types: 'completion' (Agent Response), "
                    "'structured_completion' (Analyze & Return Data), 'branch', 'code', "
                    "'http_request'. Run executor_list() to see all options."
                )
            if "metadata" in detail_lower:
                return (
                    "Invalid metadata format. Ensure metadata is a valid JSON object. "
                    "For branch nodes, include 'value' and 'comparisons'. "
                    "For code nodes, include 'language' and 'code'."
                )
        if status_code == 404:
            return "Node not found. Run flow_get(flow_id) to see all nodes in the flow."

    # Flow errors
    if "/flows" in path:
        if status_code == 404:
            return "Flow not found. Run flow_list(agent_id) to see available flows."
        if status_code == 400 and "trigger" in detail_lower:
            return (
                "Invalid trigger type. Common triggers: 'llm.call', 'webhook.receive', "
                "'conversation.escalated'. Check the flow_create documentation."
            )

    # Agent errors
    if "/agents" in path and status_code == 404:
        return "Agent not found. Run agent_list() to see available agents."

    # Conversation errors
    if "/conversations" in path and status_code == 404:
        return (
            "Conversation not found. The conversation_id may be wrong or the "
            "conversation may have been deleted."
        )

    # Generic suggestions
    if status_code == 401:
        return "Authentication failed. Check your API token or reconnect."
    if status_code == 403:
        return "Permission denied. You may not have access to this resource."
    if status_code == 500:
        return (
            "Server error. The flow may be corrupted. Consider creating a new flow "
            "with flow_create() and rebuilding - often faster than debugging."
        )

    return None


_EXPLICIT_FILTER_SUFFIXES = (
    "__in",
    "__nin",
    "__gte",
    "__lte",
    "__gt",
    "__lt",
    "__isnull",
    "__contains",
    "__not_contains",
    "__range",
)


def _filter_has_explicit_lookup(field: str) -> bool:
    return field.endswith(_EXPLICIT_FILTER_SUFFIXES)


def _serialize_filter_value(value: Any) -> str:
    if isinstance(value, (dict, list)):
        return json.dumps(value, separators=(",", ":"), ensure_ascii=True)
    if isinstance(value, bool):
        return str(value).lower()
    return str(value)


def _apply_query_filter(params: dict[str, Any], field: str, cond: Any) -> None:
    explicit_lookup = _filter_has_explicit_lookup(field)

    if isinstance(cond, dict):
        if any(key in cond for key in ("gte", "lte", "gt", "lt")):
            for key in ("gte", "lte", "gt", "lt"):
                if key in cond:
                    params[f"{field}__{key}"] = cond[key]
            return

        if "isnull" in cond and len(cond) == 1:
            params[f"{field}__isnull"] = str(cond["isnull"]).lower()
            return

        if "nin" in cond and len(cond) == 1:
            vals = cond["nin"]
            if isinstance(vals, list):
                params[f"{field}__nin"] = ",".join(str(v) for v in vals)
            else:
                params[f"{field}__nin"] = str(vals)
            return

        if "in" in cond and len(cond) == 1:
            vals = cond["in"]
            if isinstance(vals, list):
                params[f"{field}__in"] = ",".join(str(v) for v in vals)
            else:
                params[f"{field}__in"] = str(vals)
            return

        params[field] = _serialize_filter_value(cond)
        return

    if isinstance(cond, list):
        key = field if explicit_lookup else f"{field}__in"
        params[key] = (
            _serialize_filter_value(cond)
            if key.endswith(("__contains", "__not_contains"))
            else ",".join(str(c) for c in cond)
        )
        return

    key = field if explicit_lookup else f"{field}__in"
    params[key] = _serialize_filter_value(cond)


_ANALYTICS_DIMENSION_SQL = {
    "agent_id": "agent_id",
    "agent_name": "agent_name",
    "label_id": "label_id",
    "label_name": "label_name",
    "resolution": "resolution",
    "sentiment": "sentiment",
    "sublabel_id": "sublabel_id",
    "sublabel_name": "sublabel_name",
    "type": "type",
    "user_id": "user_id",
}
_ANALYTICS_AUTOMATION_DIMENSIONS = {
    "intent": "sublabel_name",
    "label_id": "label_id",
    "label_name": "label_name",
    "sublabel_id": "sublabel_id",
    "sublabel_name": "sublabel_name",
    "topic": "label_name",
}
_ANALYTICS_DASHBOARD_DIMENSIONS = {
    "agent_id": "agent_id",
    "label_id": "label_id",
    "resolution": "resolution",
    "sentiment": "sentiment",
    "sublabel_id": "sublabel_id",
    "type": "type",
    "user_id": "user_id",
}
_ANALYTICS_FILTER_SQL = {
    **_ANALYTICS_DIMENSION_SQL,
    "score": "score",
}
_ANALYTICS_METRIC_SQL = {
    "count": "count() AS count",
    "avg_score": "avgOrNull(score) AS avg_score",
    "avg_ttr": "avgOrNull(ttr_seconds) AS avg_ttr",
    "resolution_rate": (
        "if(count() > 0, "
        "round(countIf(resolution IN "
        "('hard_resolved', 'soft_resolved', 'human_resolved')) / count(), 4), "
        "0) AS resolution_rate"
    ),
}


def _sql_literal(value: Any) -> str:
    if value is None:
        return "NULL"
    if isinstance(value, bool):
        return "1" if value else "0"
    if isinstance(value, (int, float)):
        return str(value)
    return "'" + str(value).replace("\\", "\\\\").replace("'", "''") + "'"


def _decode_filter_value(value: str) -> Any:
    stripped = value.strip()
    if not stripped:
        return ""
    try:
        return json.loads(stripped)
    except json.JSONDecodeError:
        return stripped


def _build_legacy_analytics_sql(
    *,
    group_by: list[str],
    metrics: list[str] | None = None,
    filters: list[str] | None = None,
    start: str | None = None,
    end: str | None = None,
    limit: int | None = None,
) -> str:
    if not group_by:
        raise ValueError("group_by is required")

    select_parts: list[str] = []
    group_parts: list[str] = []
    for dimension in group_by:
        column = _ANALYTICS_DIMENSION_SQL.get(dimension)
        if column is None:
            raise ValueError(f"Unsupported analytics dimension: {dimension}")
        select_parts.append(f"{column} AS {dimension}")
        group_parts.append(column)

    metric_names = metrics or ["count"]
    for metric in metric_names:
        metric_sql = _ANALYTICS_METRIC_SQL.get(metric)
        if metric_sql is None:
            raise ValueError(f"Unsupported analytics metric: {metric}")
        select_parts.append(metric_sql)

    where_parts: list[str] = []
    if start:
        where_parts.append(f"created_at >= {_sql_literal(start)}")
    if end:
        where_parts.append(f"created_at <= {_sql_literal(end)}")

    for raw_filter in filters or []:
        if "=" not in raw_filter:
            raise ValueError(f"Invalid analytics filter: {raw_filter}")
        field, raw_value = raw_filter.split("=", 1)
        field = field.strip()
        column = _ANALYTICS_FILTER_SQL.get(field)
        if column is None:
            raise ValueError(f"Unsupported analytics filter field: {field}")

        value = _decode_filter_value(raw_value)
        if isinstance(value, list):
            if not value:
                where_parts.append("0 = 1")
            else:
                literals = ", ".join(_sql_literal(item) for item in value)
                where_parts.append(f"{column} IN ({literals})")
        elif value is None:
            where_parts.append(f"{column} IS NULL")
        else:
            where_parts.append(f"{column} = {_sql_literal(value)}")

    sql_parts = [
        f"SELECT {', '.join(select_parts)}",
        "FROM conversation_latest_state",
    ]
    if where_parts:
        sql_parts.append("WHERE " + " AND ".join(where_parts))
    sql_parts.append("GROUP BY " + ", ".join(group_parts))
    sql_parts.append("ORDER BY " + ", ".join(group_parts))
    if limit:
        sql_parts.append(f"LIMIT {int(limit)}")
    return "\n".join(sql_parts)


def _parse_legacy_analytics_filters(filters: list[str] | None) -> dict[str, Any]:
    parsed: dict[str, Any] = {}
    for raw_filter in filters or []:
        if "=" not in raw_filter:
            raise ValueError(f"Invalid analytics filter: {raw_filter}")
        field, raw_value = raw_filter.split("=", 1)
        field = field.strip()
        if field not in _ANALYTICS_FILTER_SQL:
            raise ValueError(f"Unsupported analytics filter field: {field}")
        parsed[field] = _decode_filter_value(raw_value)
    return parsed


def _validate_analytics_count_metrics(metrics: list[str] | None) -> list[str]:
    metric_names = metrics or ["count"]
    unsupported = [metric for metric in metric_names if metric != "count"]
    if unsupported:
        raise ValueError(
            "The current analytics endpoint only supports the count metric for "
            "applied analytics. Use applied analytics-report for richer metrics."
        )
    return metric_names


def _decode_dashboard_group(group: Any, expected_count: int) -> list[Any]:
    if expected_count == 1:
        return [group]
    if isinstance(group, str):
        try:
            decoded = json.loads(group)
        except json.JSONDecodeError:
            decoded = group
        if isinstance(decoded, list):
            return decoded
    if isinstance(group, list):
        return group
    return [group]


def _sort_analytics_rows(rows: list[dict[str, Any]], group_by: list[str]) -> None:
    def sort_key(row: dict[str, Any]) -> tuple[str, ...]:
        return tuple(
            "" if row.get(dimension) is None else str(row.get(dimension))
            for dimension in group_by
        )

    rows.sort(key=sort_key)


class AppliedClient:
    """Async client for Applied Labs API."""

    def __init__(
        self,
        token: str,
        shop_id: str | None = None,
        base_url: str = "https://api.appliedlabs.ai",
        timeout: float = 30.0,
        access_mode: str | None = None,
    ):
        self.token = token
        self.shop_id = shop_id
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.access_mode = _normalize_access_mode(
            access_mode
            if access_mode is not None
            else os.environ.get(ACCESS_MODE_ENV_VAR)
        )
        self.assistant_conversation_id = os.environ.get(
            ASSISTANT_CONVERSATION_ENV_VAR,
            "",
        ).strip()

    async def _record_access_mode_change(
        self,
        *,
        method: str,
        path: str,
        body: Any = None,
        before: Any = None,
        after: Any = None,
        shop_id: str | None = None,
        status: str,
    ) -> None:
        if not self.assistant_conversation_id or not self.token:
            return

        safe_body = _json_safe(body or {})
        safe_before = _json_safe(before if before is not None else {})
        safe_after = _json_safe(_candidate_after(before, body, after))
        object_type, object_id, object_name = _infer_object_reference(
            path,
            safe_body if safe_body else safe_after,
        )
        resolved_shop_id = shop_id or self.shop_id
        payload = {
            "access_mode": self.access_mode,
            "status": status,
            "object_type": object_type,
            "object_id": object_id,
            "object_name": object_name,
            "action": _infer_change_action(method),
            "before": safe_before,
            "after": safe_after,
            "diff": {"request_body": safe_body},
            "request_method": method.upper(),
            "request_path": path,
            "request_body": safe_body,
        }
        headers = {
            "Authorization": f"Bearer {self.token}",
            "Content-Type": "application/json",
        }
        if resolved_shop_id:
            headers["X-Shop-Id"] = resolved_shop_id

        timeout = (
            min(self.timeout, 10.0) if isinstance(self.timeout, int | float) else 10.0
        )
        diffs_url = (
            f"{self.base_url}/v1/threads/{self.assistant_conversation_id}/diffs/"
        )
        try:
            async with httpx.AsyncClient(timeout=timeout) as client:
                await client.post(
                    diffs_url,
                    headers=headers,
                    json=payload,
                )
        except Exception:
            # Do not let proposal logging mask the access-mode decision.
            return

    async def _fetch_current_object(
        self,
        *,
        method: str,
        path: str,
        shop_id: str | None = None,
    ) -> Any:
        if method.upper() not in {"PATCH", "PUT", "DELETE"}:
            return {}

        headers = {"Authorization": f"Bearer {self.token}"}
        resolved_shop_id = shop_id or self.shop_id
        if resolved_shop_id:
            headers["X-Shop-Id"] = resolved_shop_id

        timeout = (
            min(self.timeout, 10.0) if isinstance(self.timeout, int | float) else 10.0
        )
        try:
            async with httpx.AsyncClient(timeout=timeout) as client:
                response = await client.get(f"{self.base_url}{path}", headers=headers)
                if response.status_code >= 400:
                    return {}
                return response.json()
        except Exception:
            return {}

    async def _enforce_access_mode(
        self,
        method: str,
        path: str,
        *,
        body: Any = None,
        shop_id: str | None = None,
    ) -> None:
        method = method.upper()
        if method not in MUTATING_METHODS or self.access_mode == FULL_ACCESS_MODE:
            return

        requires_approval = self.access_mode == DEFAULT_ACCESS_MODE
        before = await self._fetch_current_object(
            method=method,
            path=path,
            shop_id=shop_id,
        )
        await self._record_access_mode_change(
            method=method,
            path=path,
            body=body,
            before=before,
            shop_id=shop_id,
            status="proposed" if requires_approval else "blocked",
        )
        error_code = (
            "requires_approval" if requires_approval else "read_only_access_mode"
        )
        message = (
            f"{method} {path} was not sent because Applied Assistant access mode "
            f"is {self.access_mode}."
        )
        detail = {
            "error": error_code,
            "requires_approval": requires_approval,
            "access_mode": self.access_mode,
            "method": method,
            "path": path,
            "message": message,
        }
        suggestion = (
            "Request approval or run with APPLIED_ASSISTANT_ACCESS_MODE=full_access "
            "before retrying this mutation."
            if requires_approval
            else "This environment is read-only. Re-run in full_access mode only when "
            "mutations are intended."
        )
        raise AppliedAPIError(
            message=f"{method} {path} blocked by access mode",
            status_code=403,
            detail=json.dumps(detail, separators=(",", ":"), ensure_ascii=True),
            suggestion=suggestion,
        )

    async def _request(
        self,
        method: str,
        path: str,
        params: dict[str, Any] | None = None,
        body: dict[str, Any] | None = None,
        shop_id: str | None = None,
    ) -> Any:
        """Make an authenticated API request."""
        method = method.upper()
        await self._enforce_access_mode(
            method,
            path,
            body=body,
            shop_id=shop_id,
        )
        headers = {
            "Authorization": f"Bearer {self.token}",
            "Content-Type": "application/json",
        }
        resolved_shop_id = shop_id or self.shop_id
        if resolved_shop_id:
            headers["X-Shop-Id"] = resolved_shop_id
        url = f"{self.base_url}{path}"
        before = None
        if method in MUTATING_METHODS and self.access_mode == FULL_ACCESS_MODE:
            before = await self._fetch_current_object(
                method=method,
                path=path,
                shop_id=resolved_shop_id,
            )

        async with httpx.AsyncClient(timeout=self.timeout) as client:
            if method == "GET":
                resp = await client.get(url, headers=headers, params=params)
            elif method == "POST":
                resp = await client.post(url, headers=headers, json=body or {})
            elif method == "PATCH":
                resp = await client.patch(url, headers=headers, json=body or {})
            elif method == "DELETE":
                resp = await client.request(
                    "DELETE", url, headers=headers, json=body if body else None
                )
            else:
                raise ValueError(f"Unsupported method: {method}")

            if resp.status_code >= 400:
                # Parse error detail from response
                detail = ""
                try:
                    err_data = resp.json()
                    if isinstance(err_data, dict):
                        raw_detail = (
                            err_data.get("detail") or err_data.get("error") or ""
                        )
                        # Ensure detail is a string (API may return dict)
                        if isinstance(raw_detail, dict):
                            detail = str(raw_detail)
                        else:
                            detail = raw_detail
                        if not detail and "message" in err_data:
                            detail = err_data["message"]
                        # Handle DRF validation errors
                        if not detail:
                            for key, val in err_data.items():
                                if isinstance(val, list):
                                    detail = f"{key}: {val[0]}"
                                    break
                except Exception:
                    detail = resp.text[:200] if resp.text else ""

                suggestion = _get_error_suggestion(resp.status_code, path, detail, body)

                raise AppliedAPIError(
                    message=f"{method} {path} failed",
                    status_code=resp.status_code,
                    detail=detail,
                    suggestion=suggestion,
                )

            result = None if resp.status_code == 204 else resp.json()

            if method in MUTATING_METHODS and self.access_mode == FULL_ACCESS_MODE:
                await self._record_access_mode_change(
                    method=method,
                    path=path,
                    body=body,
                    before=before,
                    after=result,
                    shop_id=shop_id,
                    status="applied",
                )
            return result

    async def _upload_request(
        self,
        method: str,
        path: str,
        files: dict[str, Any],
        data: dict[str, Any] | None = None,
    ) -> Any:
        """Make an authenticated multipart file upload request."""
        method = method.upper()
        await self._enforce_access_mode(method, path, body=data, shop_id=self.shop_id)
        headers = {
            "Authorization": f"Bearer {self.token}",
        }
        if self.shop_id:
            headers["X-Shop-Id"] = self.shop_id
        url = f"{self.base_url}{path}"
        before = None
        if method in MUTATING_METHODS and self.access_mode == FULL_ACCESS_MODE:
            before = await self._fetch_current_object(
                method=method,
                path=path,
                shop_id=self.shop_id,
            )

        async with httpx.AsyncClient(timeout=self.timeout) as client:
            resp = await client.request(
                method, url, headers=headers, files=files, data=data or {}
            )

            if resp.status_code >= 400:
                detail = ""
                try:
                    err_data = resp.json()
                    if isinstance(err_data, dict):
                        detail = str(
                            err_data.get("detail")
                            or err_data.get("error")
                            or err_data.get("message")
                            or ""
                        )
                except Exception:
                    detail = resp.text[:200] if resp.text else ""

                raise AppliedAPIError(
                    message=f"{method} {path} failed",
                    status_code=resp.status_code,
                    detail=detail,
                )

            result = None if resp.status_code == 204 else resp.json()

            if method in MUTATING_METHODS and self.access_mode == FULL_ACCESS_MODE:
                await self._record_access_mode_change(
                    method=method,
                    path=path,
                    body=data,
                    before=before,
                    after=result,
                    shop_id=self.shop_id,
                    status="applied",
                )
            return result

    def _require_shop_id(self, shop_id: str | None = None) -> str:
        resolved_shop_id = shop_id or self.shop_id
        if not resolved_shop_id:
            raise ValueError("shop_id is required")
        return resolved_shop_id

    def _normalize_response(self, data: Any) -> list[dict]:
        """Handle both list and paginated responses."""
        if isinstance(data, list):
            return data
        return data.get("results", [])

    def _merge_contact_context(
        self,
        metadata: dict[str, Any] | None = None,
        *,
        contact_email: str | None = None,
        contact_name: str | None = None,
        contact_phone: str | None = None,
    ) -> dict[str, Any]:
        """Merge contact fields into conversation metadata.context."""
        merged = dict(metadata or {})
        context = dict(merged.get("context") or {})

        if contact_email:
            context["email"] = contact_email
        if contact_name:
            context["name"] = contact_name
        if contact_phone:
            context["phone"] = contact_phone

        if context:
            merged["context"] = context

        return merged

    # -------------------------------------------------------------------------
    # Agents
    # -------------------------------------------------------------------------

    async def list_agents(self, limit: int = 100) -> list[dict]:
        """List all AI agents in the workspace."""
        data = await self._request(
            "GET",
            "/v1/agents/",
            params={"limit": limit, "ordering": "-created_at"},
        )
        return self._normalize_response(data)

    async def create_agent(
        self,
        name: str,
        modality: str,
        agent_type: str = "Customer Support",
        model: str = "GPT-4.1-mini",
        escalation_mode: str = "default",
        auto_reply: bool = False,
    ) -> dict:
        """Create a new agent."""
        body: dict[str, Any] = {
            "name": name,
            "modality": modality,
            "type": agent_type,
            "model": model,
            "escalation_mode": escalation_mode,
            "auto_reply": auto_reply,
        }
        return await self._request("POST", "/v1/agents/", body=body)

    async def update_agent(
        self,
        agent_id: str,
        **kwargs: Any,
    ) -> dict:
        """Update an agent's properties."""
        return await self._request("PATCH", f"/v1/agents/{agent_id}/", body=kwargs)

    async def update_agent_picture(
        self,
        agent_id: str,
        image_path: str,
    ) -> dict:
        """Update an agent's profile picture via file upload."""
        import mimetypes

        content_type = mimetypes.guess_type(image_path)[0] or "image/png"
        filename = image_path.rsplit("/", 1)[-1]
        with open(image_path, "rb") as f:
            files = {"profile_picture": (filename, f, content_type)}
            return await self._upload_request(
                "PATCH", f"/v1/agents/{agent_id}/", files=files
            )

    async def delete_agent(self, agent_id: str) -> None:
        """Delete an agent."""
        await self._request("DELETE", f"/v1/agents/{agent_id}/")

    # -------------------------------------------------------------------------
    # Connector Types
    # -------------------------------------------------------------------------

    async def list_connector_types(
        self,
        connector_type: str | None = None,
        include_schemas: bool = False,
    ) -> list[dict]:
        """List available connector types and their supported actions."""
        params: dict[str, Any] = {}
        if connector_type:
            params["type"] = connector_type
        if include_schemas:
            params["include_schemas"] = "true"
        data = await self._request("GET", "/v2/connectors/types/", params=params)
        return data if isinstance(data, list) else data.get("results", [data])

    # -------------------------------------------------------------------------
    # Taxonomy (topics, intents, flags)
    # -------------------------------------------------------------------------

    async def list_taxonomy(
        self,
        taxonomy_type: str = "all",
    ) -> list[dict]:
        """List conversation taxonomy: topics, intents, and flags."""
        params: dict[str, Any] = {}
        if taxonomy_type == "flags":
            params["is_flag"] = "true"
        elif taxonomy_type == "topics":
            params["is_flag"] = "false"
            params["parent_choice_id__isnull"] = "true"
        elif taxonomy_type == "intents":
            params["is_flag"] = "false"
            params["parent_choice_id__isnull"] = "false"

        data = await self._request("GET", "/v1/property-choices/", params=params)
        return self._normalize_response(data)

    async def create_taxonomy(
        self,
        name: str,
        parent_id: str | None = None,
        color: str | None = None,
        description: str | None = None,
        comments: str | None = None,
    ) -> dict:
        """Create a topic or intent (property choice)."""
        body: dict[str, Any] = {
            "name": name,
            "field_id": None,
            "color": color or "blue",
            "description": description or "",
            "comments": comments or "",
        }
        if parent_id:
            body["parent_choice_id"] = parent_id
        return await self._request("POST", "/v1/property-choices/", body=body)

    async def update_taxonomy(
        self,
        choice_id: str,
        **kwargs: Any,
    ) -> dict:
        """Update a topic or intent (property choice)."""
        return await self._request(
            "PATCH", f"/v1/property-choices/{choice_id}/", body=kwargs
        )

    async def delete_taxonomy(self, choice_id: str) -> None:
        """Delete a topic or intent (property choice)."""
        await self._request("DELETE", f"/v1/property-choices/{choice_id}/")

    # -------------------------------------------------------------------------
    # Analytics
    # -------------------------------------------------------------------------

    async def analytics_query(
        self,
        group_by: list[str],
        metrics: list[str] | None = None,
        filters: list[str] | None = None,
        start: str | None = None,
        end: str | None = None,
        limit: int | None = None,
    ) -> dict:
        """Run a grouped conversation count query through the analytics API."""
        if not group_by:
            raise ValueError("group_by is required")

        metric_names = _validate_analytics_count_metrics(metrics)
        parsed_filters = _parse_legacy_analytics_filters(filters)

        if all(dimension in _ANALYTICS_AUTOMATION_DIMENSIONS for dimension in group_by):
            data = await self._taxonomy_analytics_query(
                group_by=group_by,
                filters=parsed_filters,
                start=start,
                end=end,
                limit=limit,
            )
        else:
            data = await self._dashboard_analytics_query(
                group_by=group_by,
                filters=parsed_filters,
                start=start,
                end=end,
                limit=limit,
            )

        data["dimensions"] = group_by
        data["metrics"] = metric_names
        return data

    async def _taxonomy_analytics_query(
        self,
        *,
        group_by: list[str],
        filters: dict[str, Any],
        start: str | None,
        end: str | None,
        limit: int | None,
    ) -> dict:
        payload: dict[str, Any] = {
            "view": "automation_aggregates",
            "model": "conversation",
            **filters,
        }
        if start:
            payload["start_date"] = start
        if end:
            payload["end_date"] = end

        data = await self.analytics_report(payload)
        source_key = (
            "by_intent"
            if any(
                dimension in {"intent", "sublabel_id", "sublabel_name"}
                for dimension in group_by
            )
            else "by_topic"
        )

        grouped: dict[tuple[Any, ...], int] = {}
        for row in data.get(source_key, []):
            key = tuple(
                row.get(_ANALYTICS_AUTOMATION_DIMENSIONS[dimension])
                for dimension in group_by
            )
            grouped[key] = grouped.get(key, 0) + int(row.get("total") or 0)

        rows = [
            {
                **dict(zip(group_by, key, strict=False)),
                "count": count,
            }
            for key, count in grouped.items()
        ]
        _sort_analytics_rows(rows, group_by)

        total_rows = len(rows)
        if limit is not None:
            rows = rows[:limit]

        return {
            "columns": [*group_by, "count"],
            "rows": rows,
            "row_count": len(rows),
            "truncated": limit is not None and total_rows > len(rows),
        }

    async def _dashboard_analytics_query(
        self,
        *,
        group_by: list[str],
        filters: dict[str, Any],
        start: str | None,
        end: str | None,
        limit: int | None,
    ) -> dict:
        backend_group_by: list[str] = []
        unsupported: list[str] = []
        for dimension in group_by:
            backend_dimension = _ANALYTICS_DASHBOARD_DIMENSIONS.get(dimension)
            if backend_dimension is None:
                unsupported.append(dimension)
            else:
                backend_group_by.append(backend_dimension)

        if unsupported:
            raise ValueError(
                "Unsupported analytics dimension for the current endpoint: "
                + ", ".join(unsupported)
            )

        payload: dict[str, Any] = {
            "view": "dashboard_rate_metrics",
            "model": "conversation",
            "group_by": ",".join(backend_group_by),
            "custom_rate_metrics_requests": [
                {"rate": "count", "numerator": "total"},
            ],
        }
        if start:
            payload["start_date"] = start
        if end:
            payload["end_date"] = end
        if filters:
            payload["conversation_filters"] = filters

        data = await self.analytics_report(payload)
        rows: list[dict[str, Any]] = []
        for item in data.get("count", []):
            group_values = _decode_dashboard_group(item.get("group"), len(group_by))
            group_values = [*group_values, *([None] * len(group_by))][: len(group_by)]
            rows.append(
                {
                    **dict(zip(group_by, group_values, strict=False)),
                    "count": item.get("numerator", item.get("rate", 0)),
                }
            )
        _sort_analytics_rows(rows, group_by)

        total_rows = len(rows)
        if limit is not None:
            rows = rows[:limit]

        return {
            "columns": [*group_by, "count"],
            "rows": rows,
            "row_count": len(rows),
            "truncated": limit is not None and total_rows > len(rows),
        }

    async def analytics_sql(
        self,
        *,
        sql: str,
        parameters: dict[str, Any] | None = None,
        max_rows: int | None = None,
    ) -> dict:
        raise ValueError(
            "Raw analytics SQL is no longer available through the public API. "
            "Use applied analytics or applied analytics-report, which call /v2/analytics/."
        )

    async def analytics_metrics(
        self,
        metric_name: str,
        group_by: str | None = None,
        period: str | None = None,
        filters: list[str] | None = None,
        start: str | None = None,
        end: str | None = None,
        object_type: str = "conversation",
    ) -> dict:
        """Query metric_events_hour with optional property grouping and trending."""
        params: dict[str, Any] = {
            "metric_name": metric_name,
            "object_type": object_type,
        }
        if group_by:
            params["group_by"] = group_by
        if period:
            params["period"] = period
        if filters:
            params["filter"] = filters
        if start:
            params["start_date"] = start
        if end:
            params["end_date"] = end
        return await self._request("GET", "/v2/analytics/metrics/", params=params)

    async def analytics_report(self, payload: dict[str, Any]) -> dict:
        """Run a dashboard-style analytics report query."""
        return await self._request("POST", "/v2/analytics/", body=payload)

    # -------------------------------------------------------------------------
    # Conversations
    # -------------------------------------------------------------------------

    async def query_conversations(
        self,
        filters: dict[str, Any] | None = None,
        search: str | None = None,
        limit: int = 20,
        offset: int = 0,
        ordering: str = "-last_message_at",
        fetch_all: bool = False,
        shop_id: str | None = None,
    ) -> list[dict]:
        """Query conversations with filters.

        Args:
            filters: Filter conditions. Supports:
                - String/list: {"resolution": "escalated"} or {"resolution": ["escalated", "soft"]}
                - Range: {"score": {"gte": 1, "lte": 3}} or {"created_at": {"gte": "2024-01-01"}}
                - Null check: {"user_id": {"isnull": True}}
                - Negation: {"resolution": {"nin": ["escalated"]}}
            search: Full-text search across conversation content
            limit: Max results per page (default 20, max 100)
            offset: Pagination offset
            ordering: Sort order (default: -last_message_at)
            fetch_all: If True, paginate through all results

        Returns:
            List of conversations
        """
        params: dict[str, Any] = {
            "limit": min(limit, 100),
            "offset": offset,
            "ordering": ordering,
        }

        if search:
            params["search"] = search

        if filters:
            for field, cond in filters.items():
                _apply_query_filter(params, field, cond)

        if not fetch_all:
            data = await self._request(
                "GET",
                "/v1/conversations/",
                params=params,
                shop_id=shop_id,
            )
            return self._normalize_response(data)

        # Paginate through all results
        all_results: list[dict] = []
        current_offset = offset
        while True:
            params["offset"] = current_offset
            data = await self._request(
                "GET",
                "/v1/conversations/",
                params=params,
                shop_id=shop_id,
            )
            results = self._normalize_response(data)
            all_results.extend(results)

            # Check if there are more pages
            if isinstance(data, dict) and data.get("next"):
                current_offset += limit
            else:
                break

        return all_results

    async def get_conversation(
        self, conversation_id: str, *, shop_id: str | None = None
    ) -> dict:
        """Get a single conversation by ID."""
        return await self._request(
            "GET",
            f"/v1/conversations/{conversation_id}/",
            shop_id=shop_id,
        )

    async def get_messages(
        self,
        conversation_id: str | None = None,
        ticket_id: str | None = None,
        limit: int = 50,
        ordering: str = "created_at",
        shop_id: str | None = None,
    ) -> list[dict]:
        """Get messages for a conversation or ticket."""
        if not conversation_id and not ticket_id:
            raise ValueError("conversation_id or ticket_id is required")
        data = await self._request(
            "GET",
            "/v1/messages/",
            params={
                "conversation_id": conversation_id,
                "ticket_id": ticket_id,
                "limit": limit,
                "ordering": ordering,
            },
            shop_id=shop_id,
        )
        return self._normalize_response(data)

    async def get_conversation_references(
        self,
        conversation_id: str,
        *,
        shop_id: str | None = None,
    ) -> list[dict]:
        """Get message references attached to a conversation."""
        data = await self._request(
            "GET",
            f"/v1/conversations/{conversation_id}/references/",
            shop_id=shop_id,
        )
        return self._normalize_response(data)

    async def create_message(
        self,
        *,
        content: str,
        conversation_id: str | None = None,
        ticket_id: str | None = None,
        text: str | None = None,
        role: str = "assistant",
        user_id: str | None = None,
        agent_id: str | None = None,
        contact_id: str | None = None,
        attachments: list[str] | None = None,
        metadata: dict[str, Any] | None = None,
        shop_id: str | None = None,
    ) -> dict:
        """Create a message on a conversation or ticket."""
        if not conversation_id and not ticket_id:
            raise ValueError("conversation_id or ticket_id is required")

        resolved_shop_id = self._require_shop_id(shop_id)
        body: dict[str, Any] = {
            "shop_id": resolved_shop_id,
            "content": content,
            "text": text if text is not None else content,
            "role": role,
            "user_id": user_id,
            "agent_id": agent_id,
            "contact_id": contact_id,
        }
        if conversation_id:
            body["conversation_id"] = conversation_id
        if ticket_id:
            body["ticket_id"] = ticket_id
        if attachments is not None:
            body["attachments"] = attachments
        if metadata is not None:
            body["metadata"] = metadata

        return await self._request(
            "POST",
            "/v1/messages/",
            body=body,
            shop_id=resolved_shop_id,
        )

    async def reply_to_conversation(
        self,
        conversation_id: str,
        *,
        agent_id: str,
        content: str,
        text: str | None = None,
        metadata: dict[str, Any] | None = None,
        attachments: list[str] | None = None,
        shop_id: str | None = None,
    ) -> dict:
        """Send an assistant-authored reply on a conversation."""
        return await self.create_message(
            conversation_id=conversation_id,
            agent_id=agent_id,
            content=content,
            text=text,
            metadata=metadata,
            attachments=attachments,
            shop_id=shop_id,
        )

    async def add_ticket_note(
        self,
        ticket_id: str,
        *,
        agent_id: str,
        content: str,
        text: str | None = None,
        metadata: dict[str, Any] | None = None,
        attachments: list[str] | None = None,
        shop_id: str | None = None,
    ) -> dict:
        """Create an internal assistant note on a ticket."""
        return await self.create_message(
            ticket_id=ticket_id,
            agent_id=agent_id,
            content=content,
            text=text,
            metadata=metadata,
            attachments=attachments,
            shop_id=shop_id,
        )

    # -------------------------------------------------------------------------
    # Tickets
    # -------------------------------------------------------------------------

    async def query_tickets(
        self,
        filters: dict[str, Any] | None = None,
        limit: int = 20,
        shop_id: str | None = None,
    ) -> list[dict]:
        """Query tickets with filters."""
        params: dict[str, Any] = {"limit": min(limit, 100)}

        if filters:
            for field, cond in filters.items():
                if isinstance(cond, str):
                    params[f"{field}__in"] = cond

        data = await self._request(
            "GET",
            "/v1/tickets/",
            params=params,
            shop_id=shop_id,
        )
        return self._normalize_response(data)

    async def get_ticket(self, ticket_id: str, *, shop_id: str | None = None) -> dict:
        """Get a single ticket by ID."""
        return await self._request(
            "GET",
            f"/v1/tickets/{ticket_id}/",
            shop_id=shop_id,
        )

    async def update_ticket(
        self,
        ticket_id: str,
        *,
        shop_id: str | None = None,
        **updates: Any,
    ) -> dict:
        """Update a ticket."""
        body = {key: value for key, value in updates.items() if value is not None}
        return await self._request(
            "PATCH",
            f"/v1/tickets/{ticket_id}/",
            body=body,
            shop_id=shop_id,
        )

    async def update_conversation(
        self,
        conversation_id: str,
        *,
        shop_id: str | None = None,
        **updates: Any,
    ) -> dict:
        """Update a conversation."""
        body = {key: value for key, value in updates.items() if value is not None}
        return await self._request(
            "PATCH",
            f"/v1/conversations/{conversation_id}/",
            body=body,
            shop_id=shop_id,
        )

    # -------------------------------------------------------------------------
    # Knowledge Base
    # -------------------------------------------------------------------------

    async def list_knowledge(
        self,
        kb_type: str | None = None,
        search: str | None = None,
        content_id: str | None = None,
        source: str | None = None,
        has_content: bool | None = None,
        limit: int = 100,
        fetch_all: bool = False,
    ) -> list[dict]:
        """List knowledge base items.

        Args:
            kb_type: Filter by type
            search: Search query
            content_id: Filter by linked content ID
            source: Filter by linked content source URL
            has_content: Filter to content-linked or standalone items
            limit: Page size (default 100, max per request)
            fetch_all: If True, paginate through all results
        """
        params: dict[str, Any] = {"limit": limit}
        if kb_type:
            params["type"] = kb_type
        if search:
            params["search"] = search
        if content_id:
            params["content_id"] = content_id
        if source:
            params["source"] = source
        if has_content is not None:
            params["content__isnull"] = str(not has_content).lower()

        if not fetch_all:
            data = await self._request("GET", "/v1/responses/", params=params)
            return self._normalize_response(data)

        # Paginate through all results
        all_results: list[dict] = []
        page = 1
        while True:
            params["page"] = page
            data = await self._request("GET", "/v1/responses/", params=params)
            results = self._normalize_response(data)
            all_results.extend(results)

            # Check if there are more pages
            if isinstance(data, dict) and data.get("next"):
                page += 1
            else:
                break

        return all_results

    async def get_knowledge(self, knowledge_id: str) -> dict:
        """Get a single knowledge base item by ID with full details."""
        return await self._request("GET", f"/v1/responses/{knowledge_id}/")

    async def get_knowledge_batch(self, knowledge_ids: list[str]) -> list[dict]:
        """Get multiple knowledge base items by ID.

        Args:
            knowledge_ids: List of knowledge item UUIDs

        Returns:
            List of knowledge items (in same order as input IDs)
        """
        import asyncio

        async def fetch_one(kid: str) -> dict | None:
            try:
                return await self.get_knowledge(kid)
            except Exception:
                return None

        results = await asyncio.gather(*[fetch_one(kid) for kid in knowledge_ids])
        return [r for r in results if r is not None]

    # -------------------------------------------------------------------------
    # Content / Articles
    # -------------------------------------------------------------------------

    async def list_content(
        self,
        content_type: str | None = None,
        status: str | None = None,
        search: str | None = None,
        source: str | None = None,
        limit: int = 100,
        fetch_all: bool = False,
    ) -> list[dict]:
        """List content items (articles, products, documents, sites).

        Args:
            content_type: Filter by type - 'Article', 'Product', 'Document', 'Site'
            status: Filter by status - 'Published', 'Draft', 'Pending'
            search: Search query
            source: Filter by source URL/domain
            limit: Page size (default 100)
            fetch_all: If True, paginate through all results
        """
        params: dict[str, Any] = {"limit": limit}
        if content_type:
            params["type"] = content_type
        if status:
            params["status"] = status
        if search:
            params["search"] = search
        if source:
            params["source"] = source

        if not fetch_all:
            data = await self._request("GET", "/v1/content/", params=params)
            return self._normalize_response(data)

        # Paginate through all results
        all_results: list[dict] = []
        page = 1
        while True:
            params["page"] = page
            data = await self._request("GET", "/v1/content/", params=params)
            results = self._normalize_response(data)
            all_results.extend(results)

            if isinstance(data, dict) and data.get("next"):
                page += 1
            else:
                break

        return all_results

    async def get_content(self, content_id: str) -> dict:
        """Get a single content item by ID with full details."""
        return await self._request("GET", f"/v1/content/{content_id}/")

    async def get_content_batch(self, content_ids: list[str]) -> list[dict]:
        """Get multiple content items by ID.

        Args:
            content_ids: List of content UUIDs

        Returns:
            List of content items
        """
        import asyncio

        async def fetch_one(cid: str) -> dict | None:
            try:
                return await self.get_content(cid)
            except Exception:
                return None

        results = await asyncio.gather(*[fetch_one(cid) for cid in content_ids])
        return [r for r in results if r is not None]

    async def create_article(
        self,
        title: str,
        description: str = "",
        content: str = "",
        html: str = "",
    ) -> dict:
        """Create a new article.

        Args:
            title: Article title
            description: Article description/summary
            content: Article content as JSON (Novel editor format)
            html: Article content as HTML

        Returns:
            Created content with ID
        """
        # First create the content shell
        create_resp = await self._request(
            "POST",
            "/v1/content/",
            body={"type": "Article", "source": title},
        )
        content_id = create_resp.get("content", {}).get("id")
        if not content_id:
            raise AppliedAPIError(
                message="Failed to create article",
                status_code=500,
                detail="No content ID returned",
            )

        # Then update with full details
        return await self._request(
            "PATCH",
            f"/v1/content/{content_id}/",
            body={
                "title": title,
                "description": description,
                "content": content,
                "html": html,
                "text": html,  # Plain text fallback
            },
        )

    async def update_content(
        self,
        content_id: str,
        **kwargs: Any,
    ) -> dict:
        """Update a content item's properties."""
        return await self._request(
            "PATCH",
            f"/v1/content/{content_id}/",
            body=kwargs,
        )

    async def resync_content(self, content_id: str) -> dict:
        """Trigger a resync for a content item."""
        return await self._request("POST", f"/v1/content/{content_id}/resync/")

    async def delete_content(self, content_id: str) -> None:
        """Delete a content item."""
        await self._request("DELETE", f"/v1/content/{content_id}/")

    # -------------------------------------------------------------------------
    # Flows
    # -------------------------------------------------------------------------

    async def list_flows(
        self,
        agent_id: str | None = None,
        status: str | None = None,
        with_graph: bool = False,
        limit: int = 50,
    ) -> list[dict]:
        """List flows, optionally filtered by agent and status."""
        params: dict[str, Any] = {"limit": limit}
        if agent_id:
            params["agent_id"] = agent_id
        if status:
            params["status"] = status
        if with_graph:
            params["with_graph"] = "true"

        data = await self._request("GET", "/v1/flows/", params=params)
        return self._normalize_response(data)

    async def get_flow(self, flow_id: str) -> dict:
        """Get a single flow with its graph (nodes and edges)."""
        return await self._request("GET", f"/v1/flows/{flow_id}/")

    async def create_flow(
        self,
        agent_id: str,
        name: str,
        flow_type: str = "conversational",
        trigger: str = "llm.call",
        description: str = "",
    ) -> dict:
        """Create a new flow."""
        return await self._request(
            "POST",
            "/v1/flows/",
            body={
                "agent_id": agent_id,
                "name": name,
                "type": flow_type,
                "trigger": trigger,
                "description": description,
            },
        )

    async def update_flow(self, flow_id: str, **kwargs: Any) -> dict:
        """Update a flow's properties."""
        return await self._request("PATCH", f"/v1/flows/{flow_id}/", body=kwargs)

    async def delete_flow(self, flow_id: str) -> None:
        """Delete a flow."""
        await self._request("DELETE", f"/v1/flows/{flow_id}/")

    # -------------------------------------------------------------------------
    # Flow Nodes
    # -------------------------------------------------------------------------

    async def get_node(self, flow_id: str, node_id: str) -> dict | None:
        """Get a single node with full configuration.

        Returns None if node not found.
        """
        flow = await self.get_flow(flow_id)
        graph = flow.get("graph", {})
        nodes = graph.get("nodes", [])
        for node in nodes:
            if node.get("id") == node_id:
                return node
        return None

    async def create_node(
        self,
        flow_id: str,
        name: str,
        metadata: dict[str, Any] | None = None,
        description: str = "",
        prompt: str = "",
        guardrail: str = "",
    ) -> dict:
        """Create a node in a flow."""
        return await self._request(
            "POST",
            f"/v1/flows/{flow_id}/nodes/",
            body={
                "name": name,
                "metadata": metadata or {},
                "description": description,
                "prompt": prompt,
                "guardrail": guardrail,
            },
        )

    async def update_node(
        self,
        flow_id: str,
        node_id: str,
        merge_metadata: bool = True,
        **kwargs: Any,
    ) -> dict:
        """Update a node's properties.

        Args:
            flow_id: The flow UUID
            node_id: The node UUID
            merge_metadata: If True (default), merge new metadata with existing.
                           If False, replace metadata entirely.
            **kwargs: Fields to update (description, prompt, metadata)
        """
        # If merge_metadata and metadata is provided, fetch existing and merge
        if merge_metadata and "metadata" in kwargs and kwargs["metadata"]:
            node = await self.get_node(flow_id, node_id)
            if node:
                existing_metadata = node.get("data", {}).get("metadata", {})
                # Deep merge: existing values are overwritten by new values
                merged = {**existing_metadata, **kwargs["metadata"]}
                kwargs["metadata"] = merged

        return await self._request(
            "PATCH",
            f"/v1/flows/{flow_id}/nodes/",
            body={"id": node_id, **kwargs},
        )

    async def delete_node(self, flow_id: str, node_id: str) -> None:
        """Delete a node from a flow."""
        await self._request(
            "DELETE",
            f"/v1/flows/{flow_id}/nodes/",
            body={"id": node_id},
        )

    # -------------------------------------------------------------------------
    # Flow Edges
    # -------------------------------------------------------------------------

    async def create_edge(
        self,
        flow_id: str,
        source_node_id: str,
        target_node_id: str,
        source_handle: str | None = None,
        target_handle: str | None = None,
        label: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> dict:
        """Create an edge connecting two nodes."""
        body: dict[str, Any] = {
            "source": source_node_id,
            "target": target_node_id,
        }
        if source_handle:
            body["source_handle"] = source_handle
        if target_handle:
            body["target_handle"] = target_handle
        if label:
            body["label"] = label
        if metadata:
            body["metadata"] = metadata

        return await self._request(
            "POST",
            f"/v1/flows/{flow_id}/edges/",
            body=body,
        )

    async def update_edge(self, flow_id: str, edge_id: str, **kwargs: Any) -> dict:
        """Update an edge's properties."""
        return await self._request(
            "PATCH",
            f"/v1/flows/{flow_id}/edges/",
            body={"id": edge_id, **kwargs},
        )

    async def delete_edge(self, flow_id: str, edge_id: str) -> None:
        """Delete an edge from a flow."""
        await self._request(
            "DELETE",
            f"/v1/flows/{flow_id}/edges/",
            body={"id": edge_id},
        )

    # -------------------------------------------------------------------------
    # Contacts
    # -------------------------------------------------------------------------

    async def create_contact(
        self,
        email: str | None = None,
        name: str | None = None,
        phone: str | None = None,
        company: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> dict:
        """Create a contact record.

        Args:
            email: Contact email address
            name: Contact name
            phone: Contact phone number
            company: Company name
            metadata: Additional metadata

        Returns:
            Created contact with ID
        """
        body: dict[str, Any] = {}
        if email:
            body["email"] = email
        if name:
            body["name"] = name
        if phone:
            body["phone"] = phone
        if company:
            body["company"] = company
        if metadata:
            body["metadata"] = metadata

        return await self._request("POST", "/v1/contacts/", body=body)

    async def get_or_create_contact(
        self,
        email: str | None = None,
        name: str | None = None,
        phone: str | None = None,
    ) -> dict:
        """Get an existing contact by email/phone or create a new one.

        Searches by email first, then phone. If found, returns existing contact.
        If not found, creates a new contact with the provided details.

        Args:
            email: Contact email address
            name: Contact name
            phone: Contact phone number

        Returns:
            Contact record (existing or newly created)
        """
        # Try to find existing contact
        params: dict[str, Any] = {"limit": 1}
        if email:
            params["email"] = email
        elif phone:
            params["phone"] = phone
        else:
            # No identifier provided, create new contact
            return await self.create_contact(name=name)

        data = await self._request("GET", "/v1/contacts/", params=params)
        contacts = self._normalize_response(data)

        if contacts:
            return contacts[0]

        # Create new contact
        return await self.create_contact(email=email, name=name, phone=phone)

    # -------------------------------------------------------------------------
    # Flow Execution
    # -------------------------------------------------------------------------

    async def run_flow(
        self,
        flow_id: str,
        trigger_data: dict[str, Any] | None = None,
        wait: bool = False,
        wait_timeout: float = 60.0,
        poll_interval: float = 1.0,
    ) -> dict:
        """Execute a flow with trigger data.

        Args:
            flow_id: The flow UUID
            trigger_data: Trigger input data
            wait: If True, poll until the run completes and include spans
            wait_timeout: Max seconds to wait for completion (default 60)
            poll_interval: Seconds between polls (default 1)

        Returns:
            Flow run with spans if wait=True
        """
        body = {"trigger": trigger_data or {}}
        run = await self._request("POST", f"/v1/flows/{flow_id}/run/", body=body)

        if not wait:
            return run

        # Poll until completion
        run_id = run.get("id")
        if not run_id:
            return run

        elapsed = 0.0
        while elapsed < wait_timeout:
            run = await self.get_flow_run(run_id)
            status = run.get("status", "")
            if status in ("Success", "Failed", "Cancelled"):
                return run
            await asyncio.sleep(poll_interval)
            elapsed += poll_interval

        # Timeout - return current state
        return run

    async def list_flow_runs(
        self,
        flow_id: str | None = None,
        conversation_id: str | None = None,
        status: str | None = None,
        limit: int = 20,
    ) -> list[dict]:
        """List flow runs, optionally filtered by flow, conversation, and status."""
        params: dict[str, Any] = {"limit": limit, "ordering": "-started_at"}
        if flow_id:
            params["flow_id"] = flow_id
        if conversation_id:
            params["conversation_id"] = conversation_id
        if status:
            params["status"] = status

        data = await self._request("GET", "/v1/flow-runs/", params=params)
        return self._normalize_response(data)

    async def get_flow_run(self, flow_run_id: str) -> dict:
        """Get a flow run with execution spans and actions."""
        return await self._request("GET", f"/v1/flow-runs/{flow_run_id}/")

    async def run_node(
        self,
        flow_id: str,
        node_id: str,
        variables: dict[str, Any] | None = None,
        wait: bool = True,
        wait_timeout: float = 60.0,
        poll_interval: float = 1.0,
    ) -> dict:
        """Execute a single node in isolation with mock inputs.

        Args:
            flow_id: The flow UUID containing the node
            node_id: The node UUID to execute
            variables: Mock input variables for the node, e.g.:
                {"trigger": {"message": "test"}, "previous_node": {"result": "data"}}
            wait: If True, poll until completion and include spans
            wait_timeout: Max seconds to wait (default 60)
            poll_interval: Seconds between polls (default 1)

        Returns:
            Flow run result with spans showing node execution
        """
        body = {"trigger": variables.get("trigger", {}) if variables else {}}

        # Add non-trigger variables to flow_variables
        if variables:
            flow_vars = {k: v for k, v in variables.items() if k != "trigger"}
            if flow_vars:
                body["flow_variables"] = flow_vars

        # Use run_type=node query param
        run = await self._request(
            "POST",
            f"/v1/flows/{flow_id}/run/?run_type=node&node_id={node_id}",
            body=body,
        )

        if not wait:
            return run

        # Poll until completion
        run_id = run.get("id")
        if not run_id:
            return run

        elapsed = 0.0
        while elapsed < wait_timeout:
            run = await self.get_flow_run(run_id)
            status = run.get("status", "")
            if status in ("Success", "Failed", "Cancelled"):
                return run
            await asyncio.sleep(poll_interval)
            elapsed += poll_interval

        return run

    # -------------------------------------------------------------------------
    # Spans (OpenTelemetry traces via /v1/monitor/)
    # -------------------------------------------------------------------------

    async def get_spans(
        self,
        object_type: str,
        object_id: str,
    ) -> list[dict]:
        """Get OpenTelemetry spans for a flow-run or conversation.

        Args:
            object_type: 'flow-runs' or 'conversations'
            object_id: The flow_run_id or conversation_id
        """
        data = await self._request(
            "GET",
            "/v1/monitor/",
            params={"type": object_type, "id": object_id},
        )
        return data.get("spans", [])

    # -------------------------------------------------------------------------
    # Conversational Testing (via streaming /complete endpoint)
    # -------------------------------------------------------------------------

    async def create_conversation(
        self,
        agent_id: str,
        is_test: bool = True,
        metadata: dict[str, Any] | None = None,
        conversation_type: str | None = None,
        contact_id: str | None = None,
    ) -> dict[str, Any]:
        """Create a new conversation for an agent.

        Args:
            agent_id: The agent UUID
            is_test: Whether this is a test conversation (default True)
            metadata: Optional metadata for the conversation
            conversation_type: Optional type - 'email', 'web_chat', 'sms', etc.
            contact_id: Optional existing contact UUID to attach to the conversation

        Returns:
            Dict with conversation id
        """
        body: dict[str, Any] = {
            "agent_id": agent_id,
            "is_test": is_test,
        }
        if metadata:
            body["metadata"] = metadata
        if conversation_type:
            body["type"] = conversation_type
        if contact_id:
            body["contact_id"] = contact_id

        return await self._request("POST", "/v1/c/", body=body)

    async def ensure_test_conversation(
        self,
        agent_id: str,
        conversation_id: str | None = None,
        contact_email: str | None = None,
        contact_name: str | None = None,
        contact_phone: str | None = None,
        metadata: dict[str, Any] | None = None,
        conversation_type: str | None = None,
    ) -> dict[str, Any]:
        """Return an existing test conversation or create one backed by a real contact."""
        if conversation_id:
            return {"id": conversation_id}

        conversation_metadata = self._merge_contact_context(
            metadata,
            contact_email=contact_email,
            contact_name=contact_name,
            contact_phone=contact_phone,
        )

        contact_id = None
        if contact_email or contact_name or contact_phone:
            contact = await self.get_or_create_contact(
                email=contact_email,
                name=contact_name,
                phone=contact_phone,
            )
            contact_id = contact.get("id")

        return await self.create_conversation(
            agent_id=agent_id,
            is_test=True,
            metadata=conversation_metadata if conversation_metadata else None,
            conversation_type=conversation_type,
            contact_id=contact_id,
        )

    async def send_message(
        self,
        agent_id: str,
        message: str,
        conversation_id: str | None = None,
        contact_email: str | None = None,
        contact_name: str | None = None,
        contact_phone: str | None = None,
        flow_id: str | None = None,
        metadata: dict[str, Any] | None = None,
        conversation_type: str | None = None,
    ) -> dict[str, Any]:
        """Send a message to an agent and wait for the response.

        This calls the /complete endpoint (streaming) and consumes the full
        response. Use this for testing conversational flows.

        If no conversation_id is provided, a new conversation is created first.

        Args:
            agent_id: The agent UUID
            message: The user message to send
            conversation_id: Optional existing conversation to continue
            contact_email: Optional contact email for a real test contact when
                starting a new conversation
            contact_name: Optional contact name for the test contact
            contact_phone: Optional contact phone for the test contact
            flow_id: Optional flow UUID to force - bypasses routing and runs this flow
            metadata: Optional metadata dict for the conversation
            conversation_type: Optional type - 'email', 'web_chat', 'sms', etc.

        Returns:
            Dict with conversation_id, response, and status
        """
        path = f"/v1/agents/{agent_id}/complete/"
        await self._enforce_access_mode(
            "POST",
            path,
            body={
                "conversation_id": conversation_id or "",
                "message": message,
                "metadata": metadata or {},
                "flow_id": flow_id or "",
            },
        )

        conversation = await self.ensure_test_conversation(
            agent_id=agent_id,
            conversation_id=conversation_id,
            contact_email=contact_email,
            contact_name=contact_name,
            contact_phone=contact_phone,
            metadata=metadata,
            conversation_type=conversation_type,
        )
        result_conversation_id = conversation["id"]

        runtime_metadata = dict(metadata or {})
        if flow_id:
            runtime_metadata["state"] = {"flow_id": flow_id}

        # /complete endpoint uses AllowAny - no auth header needed
        headers: dict[str, str] = {
            "Content-Type": "application/json",
        }

        body: dict[str, Any] = {
            "conversation_id": result_conversation_id,
            "transcript": [
                {
                    "id": str(uuid.uuid4()),
                    "role": "user",
                    "content": message,
                    "text": message,
                    "format": "MARKDOWN",
                }
            ],
        }

        if runtime_metadata:
            body["metadata"] = runtime_metadata

        url = f"{self.base_url}{path}"

        response_text = ""

        async with (
            httpx.AsyncClient(timeout=120.0) as client,
            client.stream("POST", url, headers=headers, json=body) as response,
        ):
            response.raise_for_status()

            # v1 streaming format: JSON objects on each line
            async for line in response.aiter_lines():
                if not line:
                    continue

                try:
                    data = json.loads(line)
                    if "content" in data:
                        response_text += data["content"]
                except json.JSONDecodeError:
                    pass

        result = {
            "conversation_id": result_conversation_id,
            "response": response_text,
            "status": "success" if response_text else "empty",
        }
        if self.access_mode == FULL_ACCESS_MODE:
            await self._record_access_mode_change(
                method="POST",
                path=path,
                body=body,
                after=result,
                status="applied",
            )
        return result

    # -------------------------------------------------------------------------
    # Benchmarks
    # -------------------------------------------------------------------------

    async def list_benchmarks(
        self,
        agent_id: str | None = None,
        limit: int = 50,
    ) -> list[dict]:
        """List conversation benchmarks."""
        params: dict[str, Any] = {"limit": limit}
        if agent_id:
            params["agent_id"] = agent_id
        data = await self._request("GET", "/v1/conversation-benchmarks/", params=params)
        return self._normalize_response(data)

    async def get_benchmark(self, benchmark_id: str) -> dict:
        """Get a single benchmark by ID."""
        return await self._request(
            "GET", f"/v1/conversation-benchmarks/{benchmark_id}/"
        )

    async def create_benchmark(
        self,
        agent_id: str,
        name: str,
        description: str = "",
    ) -> dict:
        """Create a new benchmark."""
        return await self._request(
            "POST",
            "/v1/conversation-benchmarks/",
            body={
                "agent": agent_id,
                "name": name,
                "description": description,
            },
        )

    async def delete_benchmark(self, benchmark_id: str) -> None:
        """Delete a benchmark."""
        await self._request("DELETE", f"/v1/conversation-benchmarks/{benchmark_id}/")

    # -------------------------------------------------------------------------
    # Scenarios
    # -------------------------------------------------------------------------

    async def list_scenarios(
        self,
        benchmark_id: str | None = None,
        agent_id: str | None = None,
        pass_status: str | None = None,
        limit: int = 200,
        fetch_all: bool = True,
    ) -> list[dict]:
        """List conversation scenarios.

        Args:
            benchmark_id: Filter by benchmark UUID
            agent_id: Filter by agent UUID
            pass_status: Filter by pass status ('pass', 'fail', 'unrated')
            limit: Page size (default 200)
            fetch_all: If True, paginate through all results (default True)
        """
        params: dict[str, Any] = {"limit": limit}
        if benchmark_id:
            params["benchmark_id"] = benchmark_id
        if agent_id:
            params["agent_id"] = agent_id
        if pass_status:
            params["pass_status"] = pass_status

        if not fetch_all:
            data = await self._request(
                "GET", "/v1/conversation-scenarios/", params=params
            )
            return self._normalize_response(data)

        # Paginate through all results
        all_results: list[dict] = []
        page = 1
        while True:
            params["page"] = page
            data = await self._request(
                "GET", "/v1/conversation-scenarios/", params=params
            )
            results = self._normalize_response(data)
            all_results.extend(results)
            if isinstance(data, dict) and data.get("next"):
                page += 1
            else:
                break
        return all_results

    async def get_scenario(self, scenario_id: str) -> dict:
        """Get a single scenario by ID."""
        return await self._request("GET", f"/v1/conversation-scenarios/{scenario_id}/")

    async def create_scenario(
        self,
        input_conversation_id: str,
        name: str,
        benchmark_id: str | None = None,
        benchmark_name: str | None = None,
        agent_id: str | None = None,
    ) -> dict:
        """Create a scenario from an existing conversation.

        Args:
            input_conversation_id: Source conversation to use as scenario
            name: Scenario name
            benchmark_id: Optional benchmark UUID to add scenario to
            benchmark_name: Optional benchmark name (creates new if not exists)
            agent_id: Required if benchmark_name is provided (for new benchmark)
        """
        body: dict[str, Any] = {
            "input_conversation_id": input_conversation_id,
            "name": name,
        }
        if benchmark_id:
            body["benchmark_id"] = benchmark_id
        if benchmark_name:
            body["benchmark_name"] = benchmark_name
        if agent_id:
            body["agent_id"] = agent_id
        return await self._request("POST", "/v1/conversation-scenarios/", body=body)

    async def update_scenario(
        self,
        scenario_id: str,
        **kwargs: Any,
    ) -> dict:
        """Update a scenario's properties (ratings, name, etc.)."""
        return await self._request(
            "PATCH", f"/v1/conversation-scenarios/{scenario_id}/", body=kwargs
        )

    # -------------------------------------------------------------------------
    # Scenario Runs
    # -------------------------------------------------------------------------

    async def list_scenario_runs(
        self,
        scenario_id: str | None = None,
        benchmark_id: str | None = None,
        bulk_job_id: str | None = None,
        latest: bool = False,
        limit: int = 50,
    ) -> list[dict]:
        """List scenario runs."""
        params: dict[str, Any] = {"limit": limit}
        if scenario_id:
            params["scenario_id"] = scenario_id
        if benchmark_id:
            params["benchmark_id"] = benchmark_id
        if bulk_job_id:
            params["bulk_job_id"] = bulk_job_id
        if latest:
            params["latest"] = "true"
        data = await self._request("GET", "/v1/scenario-runs/", params=params)
        return self._normalize_response(data)

    async def get_scenario_run(self, run_id: str) -> dict:
        """Get a single scenario run by ID."""
        return await self._request("GET", f"/v1/scenario-runs/{run_id}/")

    async def update_scenario_run(
        self,
        run_id: str,
        **kwargs: Any,
    ) -> dict:
        """Update a scenario run's properties (ratings, feedback, etc.)."""
        return await self._request("PATCH", f"/v1/scenario-runs/{run_id}/", body=kwargs)

    async def delete_scenario(self, scenario_id: str) -> None:
        """Delete a scenario."""
        await self._request("DELETE", f"/v1/conversation-scenarios/{scenario_id}/")

    async def delete_scenario_run(self, run_id: str) -> None:
        """Delete a scenario run."""
        await self._request("DELETE", f"/v1/scenario-runs/{run_id}/")

    async def bulk_run_scenarios(
        self,
        scenario_ids: list[str] | None = None,
        benchmark_id: str | None = None,
        target_agent_id: str | None = None,
        contact_override: dict | None = None,
    ) -> dict:
        """Run multiple scenarios at once.

        Args:
            scenario_ids: List of scenario UUIDs to run
            benchmark_id: Run all scenarios in this benchmark
            target_agent_id: Optional agent to run against (for A/B testing)
            contact_override: Optional contact override dict, e.g.
                {"mode": "contact", "contact_id": "<uuid>"}
        """
        body: dict[str, Any] = {}
        if scenario_ids:
            body["scenario_ids"] = scenario_ids
        if benchmark_id:
            body["benchmark_id"] = benchmark_id
        if target_agent_id:
            body["target_agent_id"] = target_agent_id
        if contact_override:
            body["contact_override"] = contact_override
        return await self._request("POST", "/v1/scenario-runs/bulk-run/", body=body)

    async def get_scenario_bulk_run_status(self, job_id: str) -> dict:
        """Get the status of a bulk scenario run job."""
        return await self._request(
            "GET",
            "/v1/scenario-runs/bulk-status/",
            params={"job_id": job_id},
        )

    # -------------------------------------------------------------------------
    # Audits (AuditBatch / AuditRating)
    # -------------------------------------------------------------------------

    async def list_audit_metric_fields(
        self,
        *,
        is_active: bool | None = None,
        limit: int = 100,
    ) -> list[dict]:
        """List active audit metric field definitions."""
        params: dict[str, Any] = {"limit": limit, "ordering": "order"}
        if is_active is not None:
            params["is_active"] = str(is_active).lower()
        data = await self._request("GET", "/v1/audit-metric-fields/", params=params)
        return self._normalize_response(data)

    async def list_audit_rubrics(
        self,
        *,
        applies_to: str | None = None,
        is_active: bool | None = None,
        name: str | None = None,
        limit: int = 100,
    ) -> list[dict]:
        """List audit rubrics."""
        params: dict[str, Any] = {"limit": limit}
        if applies_to:
            params["applies_to"] = applies_to
        if is_active is not None:
            params["is_active"] = str(is_active).lower()
        if name:
            params["name"] = name
        data = await self._request("GET", "/v1/audit-rubrics/", params=params)
        return self._normalize_response(data)

    async def get_audit_rubric(self, rubric_id: str) -> dict:
        """Get a single audit rubric."""
        return await self._request("GET", f"/v1/audit-rubrics/{rubric_id}/")

    async def list_audit_batches(
        self,
        *,
        target_type: str | None = None,
        status: str | None = None,
        rubric_id: str | None = None,
        period_start_gte: str | None = None,
        period_start_lte: str | None = None,
        period_end_gte: str | None = None,
        period_end_lte: str | None = None,
        limit: int = 100,
    ) -> list[dict]:
        """List audit batches."""
        params: dict[str, Any] = {"limit": limit}
        if target_type:
            params["target_type"] = target_type
        if status:
            params["status"] = status
        if rubric_id:
            params["rubric"] = rubric_id
        if period_start_gte:
            params["period_start__gte"] = period_start_gte
        if period_start_lte:
            params["period_start__lte"] = period_start_lte
        if period_end_gte:
            params["period_end__gte"] = period_end_gte
        if period_end_lte:
            params["period_end__lte"] = period_end_lte
        data = await self._request("GET", "/v1/audit-batches/", params=params)
        return self._normalize_response(data)

    async def get_audit_batch(self, batch_id: str) -> dict:
        """Get a single audit batch."""
        return await self._request("GET", f"/v1/audit-batches/{batch_id}/")

    async def create_audit_batch(
        self,
        *,
        target_type: str,
        period_start: str,
        period_end: str,
        rubric_id: str | None = None,
        desired_sample_size: int | None = None,
        filters: dict[str, Any] | None = None,
        status: str | None = None,
    ) -> dict:
        """Create a new audit batch."""
        body: dict[str, Any] = {
            "target_type": target_type,
            "period_start": period_start,
            "period_end": period_end,
        }
        if rubric_id:
            body["rubric"] = rubric_id
        if desired_sample_size is not None:
            body["desired_sample_size"] = desired_sample_size
        if filters:
            body["filters"] = filters
        if status:
            body["status"] = status
        return await self._request("POST", "/v1/audit-batches/", body=body)

    async def calculate_audit_batch_size(
        self,
        *,
        target_type: str,
        period_start: str,
        period_end: str,
        rubric_id: str | None = None,
        filters: dict[str, Any] | None = None,
    ) -> dict:
        """Calculate how many targets match an audit batch definition."""
        body: dict[str, Any] = {
            "target_type": target_type,
            "period_start": period_start,
            "period_end": period_end,
            "filters": filters or {},
        }
        if rubric_id:
            body["rubric"] = rubric_id
        return await self._request(
            "POST",
            "/v1/audit-batches/calculate-size/",
            body=body,
        )

    async def populate_audit_batch(
        self,
        batch_id: str,
        *,
        limit: int | None = None,
        only_unaudited: bool = True,
    ) -> dict:
        """Populate an audit batch with sampled ratings."""
        body: dict[str, Any] = {"only_unaudited": only_unaudited}
        if limit is not None:
            body["limit"] = limit
        return await self._request(
            "POST",
            f"/v1/audit-batches/{batch_id}/populate/",
            body=body,
        )

    async def submit_audit_batch(self, batch_id: str) -> dict:
        """Submit an audit batch and lock it."""
        return await self._request("POST", f"/v1/audit-batches/{batch_id}/submit/")

    async def recalculate_audit_batch(
        self,
        batch_id: str,
        *,
        dimension_filters: dict[str, Any] | None = None,
    ) -> dict:
        """Recalculate audit aggregates for a batch."""
        body: dict[str, Any] = {}
        if dimension_filters:
            body["dimension_filters"] = dimension_filters
        return await self._request(
            "POST",
            f"/v1/audit-batches/{batch_id}/recalculate/",
            body=body,
        )

    async def list_audit_ratings(
        self,
        *,
        batch_id: str | None = None,
        target_type: str | None = None,
        audited_by_id: str | None = None,
        audited_by_isnull: bool | None = None,
        limit: int = 100,
    ) -> list[dict]:
        """List audit ratings."""
        params: dict[str, Any] = {"limit": limit}
        if batch_id:
            params["batch"] = batch_id
        if target_type:
            params["target_type"] = target_type
        if audited_by_id:
            params["audited_by"] = audited_by_id
        if audited_by_isnull is not None:
            params["audited_by__isnull"] = str(audited_by_isnull).lower()
        data = await self._request("GET", "/v1/audit-ratings/", params=params)
        return self._normalize_response(data)

    async def get_audit_rating(self, rating_id: str) -> dict:
        """Get a single audit rating."""
        return await self._request("GET", f"/v1/audit-ratings/{rating_id}/")

    async def update_audit_rating(
        self,
        rating_id: str,
        *,
        notes: str | None = None,
        quality_score: float | None = None,
    ) -> dict:
        """Update mutable audit rating fields like notes."""
        body = {
            key: value
            for key, value in {
                "notes": notes,
                "quality_score": quality_score,
            }.items()
            if value is not None
        }
        return await self._request(
            "PATCH", f"/v1/audit-ratings/{rating_id}/", body=body
        )

    async def set_audit_rating_value(
        self,
        rating_id: str,
        *,
        metric_field_id: str,
        value: Any,
    ) -> dict:
        """Set a single typed metric value on an audit rating."""
        return await self._request(
            "POST",
            f"/v1/audit-ratings/{rating_id}/set-value/",
            body={
                "metric_field_id": metric_field_id,
                "value": value,
            },
        )

    # -------------------------------------------------------------------------
    # Knowledge Base (Responses) - Create/Update
    # -------------------------------------------------------------------------

    async def create_response(
        self,
        kb_type: str,
        question: str,
        answer: str,
        chunk_text: str | None = None,
        guardrail: str = "",
        active: bool = True,
        agent_ids: list[str] | None = None,
        label_id: str | None = None,
        flow_id: str | None = None,
    ) -> dict:
        """Create a new knowledge base item.

        Args:
            kb_type: Type - 'qa', 'exact', 'escalate', 'context', 'greeting', 'signature'
            question: Trigger text / question
            answer: Response text / answer
            chunk_text: Raw retrieval chunk text
            guardrail: Optional guardrail instructions
            active: Whether the item is active (default True)
            agent_ids: Optional list of agent UUIDs to assign to
            label_id: Optional label UUID for categorization
            flow_id: Optional flow UUID to associate with
        """
        body: dict[str, Any] = {
            "type": kb_type,
            "question": question,
            "answer": answer,
            "active": active,
        }
        if chunk_text is not None:
            body["chunk_text"] = chunk_text
        if guardrail:
            body["guardrail"] = guardrail
        if agent_ids:
            body["agent_ids"] = agent_ids
        if label_id:
            body["label"] = label_id
        if flow_id:
            body["flow"] = flow_id
        return await self._request("POST", "/v1/responses/", body=body)

    async def update_response(
        self,
        response_id: str,
        **kwargs: Any,
    ) -> dict:
        """Update a knowledge base item's properties."""
        return await self._request(
            "PATCH", f"/v1/responses/{response_id}/", body=kwargs
        )

    async def pin_response(
        self,
        response_id: str,
        pinned: bool = True,
        *,
        field: str = "pinned",
    ) -> dict:
        """Mark a knowledge base response as pinned/manually managed."""
        return await self.update_response(response_id, **{field: pinned})

    async def delete_response(self, response_id: str) -> None:
        """Delete a knowledge base item."""
        await self._request("DELETE", f"/v1/responses/{response_id}/")

    # -------------------------------------------------------------------------
    # Products (Content type=Product)
    # -------------------------------------------------------------------------

    async def list_products(
        self,
        status: str | None = None,
        search: str | None = None,
        limit: int = 50,
    ) -> list[dict]:
        """List products."""
        params: dict[str, Any] = {"type": "Product", "limit": limit}
        if status:
            params["status"] = status
        if search:
            params["search"] = search
        data = await self._request("GET", "/v1/content/", params=params)
        return self._normalize_response(data)

    async def get_product(self, product_id: str) -> dict:
        """Get a single product by ID."""
        return await self._request("GET", f"/v1/content/{product_id}/")

    async def create_product(
        self,
        title: str,
        description: str = "",
        url: str = "",
        images: list[str] | None = None,
        price: str | None = None,
        compare_at_price: str | None = None,
        currency: str = "USD",
        rating: float | None = None,
        review_count: int | None = None,
        status: str = "Active",
        should_autogenerate_responses: bool = True,
        used_for_rag: bool = True,
    ) -> dict:
        """Create a new product.

        Args:
            title: Product name
            description: Product description
            url: Product page URL
            images: List of image URLs
            price: Current price (e.g. "29.99")
            compare_at_price: Original/compare price
            currency: Currency code (default "USD")
            rating: Average rating (e.g. 4.5)
            review_count: Number of reviews
            status: 'Active', 'Draft', 'Pending' (default 'Active')
            should_autogenerate_responses: Auto-generate Q&A (default True)
            used_for_rag: Include in knowledge base (default True)
        """
        # Build product JSON structure
        product_data: dict[str, Any] = {
            "title": title,
            "description": description,
            "currencyCode": currency,
            "onlineStoreUrl": url,
            "images": images or [],
            "variants": [],
        }

        # Add default variant with price
        if price:
            variant: dict[str, Any] = {
                "id": "default",
                "title": "Default",
                "price": price,
            }
            if compare_at_price:
                variant["compareAtPrice"] = compare_at_price
            product_data["variants"] = [variant]

        # Add reviews if provided
        if rating is not None or review_count is not None:
            product_data["reviews"] = {
                "rating": rating,
                "count": review_count or 0,
                "testimonials": [],
            }

        body: dict[str, Any] = {
            "type": "Product",
            "product": product_data,
            "status": status,
            "should_autogenerate_responses": should_autogenerate_responses,
            "used_for_rag": used_for_rag,
        }

        return await self._request("POST", "/v1/content/", body=body)

    async def update_product(
        self,
        product_id: str,
        **kwargs: Any,
    ) -> dict:
        """Update a product's properties."""
        return await self._request("PATCH", f"/v1/content/{product_id}/", body=kwargs)

    async def delete_product(self, product_id: str) -> None:
        """Delete a product."""
        await self._request("DELETE", f"/v1/content/{product_id}/")
