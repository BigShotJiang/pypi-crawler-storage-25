__version__ = "0.6.15"

from .boss import BOSS

__all__ = ["BOSS"]
