import subprocess
import time

from heros import RemoteHERO

from qcodes.instrument import Instrument
import pytest
import json
from unittest import mock
import os


class ExampleBaseVoltageSource(Instrument):
    _voltage: float = 0.0

    def __init__(self, name: str):
        super().__init__(name)

        self.add_parameter(
            "voltage",
            unit="V",
            abstract=False,
            get_cmd=self._get_voltage,
            set_cmd=self._set_voltage,
        )
        self.add_parameter("current", unit="A", get_cmd=None, set_cmd=None)

    def _get_voltage(self):
        return self._voltage

    def _set_voltage(self, value):
        self._voltage = value


@pytest.fixture()
def qcodes_env():
    boss_config = json.dumps(
        {
            "_id": "test_dev_qcodes",
            "classname": "tests.test_ext_libs.ExampleBaseVoltageSource",
            "arguments": {
                "parameters": ["voltage", "current"],
            },
        }
    )
    with mock.patch.dict(os.environ, {"BOSS_QCODES": boss_config}):
        yield


def test_qcodes(qcodes_env, cleanup):
    _boss_process = subprocess.Popen(
        [
            "python",
            "-m",
            "boss.starter",
            "-e",
            "BOSS_QCODES",
            "--realm=test",
        ],
        qcodes_env,
    )

    cleanup["boss"].append([_boss_process, None])
    time.sleep(2)

    hero = RemoteHERO("test_dev_qcodes", realm="test")
    cleanup["heros"].append(hero)

    assert hasattr(hero, "voltage")
    hero.voltage = 100
    assert hero.voltage == 100


@pytest.fixture()
def pylablib_env():
    boss_config = json.dumps(
        {
            "_id": "test_dev_pylablib",
            "classname": "pylablib.devices.interface.camera.ICamera",
            "arguments": {},
        }
    )
    with mock.patch.dict(os.environ, {"BOSS_PYLABLIB": boss_config}):
        yield


def test_pylablib(pylablib_env, cleanup):
    _boss_process = subprocess.Popen(
        [
            "python",
            "-m",
            "boss.starter",
            "-e",
            "BOSS_PYLABLIB",
            "--realm=test",
        ],
        pylablib_env,
    )

    cleanup["boss"].append([_boss_process, None])

    i = 0
    while i < 15:
        try:
            hero = RemoteHERO("test_dev_pylablib", realm="test")
            cleanup["heros"].append(hero)
            assert hasattr(hero, "open")
            hero.set_frame_format("array")
            assert hero.get_frame_format() == "array"
            break
        except NameError:
            time.sleep(0.5)
            i += 1
    else:
        raise
