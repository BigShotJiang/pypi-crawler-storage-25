"""
Warehouse Models Module
=======================

This module contains all warehouse-related database models and enums.

WAREHOUSE ID CONVENTIONS
------------------------

There are THREE distinct warehouse identifiers:

1. **Internal ID** (`warehouses.id`)
   - Type: Integer (auto-increment primary key)
   - Example: 8
   - Used for: Foreign key relationships within warehouse tables

2. **ERP Warehouse ID** (`warehouses.erp_warehouse_id`)
   - Type: String (unique)
   - Example: "AKAB-GGN", "AKAB-DEL"
   - Used for: ERP system integration, inventory storage, all business operations

3. **Medusa Location ID** (`warehouses.medusa_location_id`)
   - Type: String (unique)
   - Example: "sloc_01JG9F7XXXXXX"
   - Used for: Medusa platform stock location operations

ProductInventory.warehouse_id Convention (SIMPLIFIED)
------------------------------------------------------

The `ProductInventory.warehouse_id` column stores the **erp_warehouse_id directly**.

    ProductInventory.warehouse_id = warehouses.erp_warehouse_id  # e.g., "AKAB-GGN"

This simplified design:
- Eliminates ID conversion logic between services
- Makes inventory data human-readable (you can see "AKAB-GGN" instead of "8")
- Provides consistency across storehouse, estimo, and orderbox

Service-Specific Usage:

    +-------------+---------------------------+--------------------------------+
    | Service     | Context                   | Warehouse ID Format Used       |
    +-------------+---------------------------+--------------------------------+
    | Storehouse  | ERP webhook processing    | erp_warehouse_id (stored as-is)|
    | Storehouse  | ProductInventory storage  | erp_warehouse_id, e.g. AKAB-GGN|
    | Estimo      | Delivery estimation       | erp_warehouse_id from warehouse|
    | Estimo      | Inventory lookup          | erp_warehouse_id for query     |
    | Orderbox    | Allocation.warehouse_id   | erp_warehouse_id (for ERP)     |
    | Orderbox    | platform_location_id      | medusa_location_id (for Medusa)|
    | Helpr       | Redis inventory client    | erp_warehouse_id (in Redis key)|
    +-------------+---------------------------+--------------------------------+

Code Examples:

    # Storehouse: Store ERP warehouse ID directly
    values = [{
        "warehouse_id": data.warehouse_id,  # Already erp_warehouse_id from ERP webhook
        "sku": data.sku,
        "quantity": data.quantity,
    }]

    # Estimo: Query using erp_warehouse_id from warehouse object
    erp_warehouse_id = warehouse_data["warehouse"]["erp_warehouse_id"]
    stmt = select(ProductInventory.quantity).where(
        ProductInventory.warehouse_id == erp_warehouse_id,  # "AKAB-GGN"
        ProductInventory.sku == sku
    )

    # Orderbox: Storing ERP ID for order processing
    allocation = AllocationV3(
        warehouse_id=estimo_warehouse.erp_warehouse_id,  # "AKAB-GGN"
        platform_location_id=estimo_warehouse.medusa_location_id,  # "sloc_01JG9F7XXXXXX"
    )

    # Helpr Redis Client: Uses erp_warehouse_id in cache key
    key = f"inv:{erp_warehouse_id}:{sku}"  # "inv:AKAB-GGN:SKU001"
"""

from ..base import Base
from .enums import WarehouseStatus, DeliveryModeEnum, StateCodeEnum
from .warehouse import Warehouse
from .state_pincode_map import StatePincodeMap
from .warehouse_delivery_mode import WarehouseDeliveryMode
from .warehouse_delivery_mode_pincodes import WarehouseDeliveryModePincode
from .warehouse_servicable_states import WarehouseServiceableState
from .warehouse_pincode_delivery_times import WarehousePincodeDeliveryTimes
from .bulk_upload_log import BulkUploadLog, BulkOperationType, BulkOperationStatus
from .inventory import ProductInventory
from .inventory_log import InventoryLog, InventoryLogStatus
from .product_sku import Product, ProductPlatformMap, ProductSkuHierarchy
from .inventory_reservation import (
    InventoryReservation,
    ReservationStatus,
    ReservationSource,
    ReleaseReason,
)
from .inventory_event import (
    InventoryEvent,
    InventoryEventType,
    create_reserve_event,
    create_release_event,
    create_erp_update_event,
)
__all__ = [
    "Base",
    "WarehouseStatus",
    "DeliveryModeEnum",
    "StateCodeEnum",
    "Warehouse",
    "StatePincodeMap",
    "WarehouseDeliveryMode",
    "WarehouseDeliveryModePincode",
    "WarehouseServiceableState",
    "WarehousePincodeDeliveryTimes",
    "BulkUploadLog",
    "BulkOperationType",
    "BulkOperationStatus",
    "ProductInventory",
    "InventoryLog",
    "InventoryLogStatus",
    "Product",
    "ProductPlatformMap",
    "ProductSkuHierarchy",
    "InventoryReservation",
    "ReservationStatus",
    "ReservationSource",
    "ReleaseReason",
    "InventoryEvent",
    "InventoryEventType",
    "create_reserve_event",
    "create_release_event",
    "create_erp_update_event",
]