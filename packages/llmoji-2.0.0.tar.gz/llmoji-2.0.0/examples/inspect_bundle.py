"""Inspect the bundle that ``llmoji analyze`` produced before running
``llmoji upload``.

Run after ``llmoji analyze``::

    python examples/inspect_bundle.py

Prints the manifest summary plus one section per source-model
``.jsonl`` file at the bundle root, with each canonical kaomoji's
row inside. This is what would ship on ``llmoji upload`` (and
nothing else: the bundle is allowlisted to ``manifest.json`` plus
each top-level ``<source-model>.jsonl``).
"""

from __future__ import annotations

import json
import sys

from llmoji import paths
from llmoji._util import flatten_synthesis, iter_bundle_data_files


def main() -> int:
    bundle = paths.bundle_dir()
    manifest_path = bundle / "manifest.json"

    if not manifest_path.exists():
        print(
            f"no bundle at {bundle}; run `llmoji analyze` first.",
            file=sys.stderr,
        )
        return 2

    manifest = json.loads(manifest_path.read_text())
    print(f"bundle: {bundle}")
    print(f"  llmoji version:    {manifest.get('llmoji_version', '?')}")
    print(f"  lexicon version:   {manifest.get('lexicon_version', '?')}")
    print(f"  synthesis backend: {manifest.get('synthesis_backend', '?')}")
    print(f"  synthesis model:   {manifest.get('synthesis_model_id', '?')}")
    print(f"  generated at:      {manifest.get('generated_at', '?')}")
    print(f"  submitter id:      {manifest.get('submitter_id', '?')}")
    print(
        f"  total synth rows:  "
        f"{manifest.get('total_synthesized_rows', '?')}"
    )
    if providers := manifest.get("providers_seen"):
        print(f"  providers:         {', '.join(providers)}")
    if model_counts := manifest.get("model_counts"):
        print("  model counts:")
        for src_model, n in sorted(model_counts.items()):
            print(f"    {src_model:<40} {n} rows")
    if notes := manifest.get("notes"):
        print(f"  notes:             {notes}")
    print()

    data = list(iter_bundle_data_files(bundle))
    if not data:
        print("no source-model .jsonl files — bundle is empty.")
        return 2

    print("synthesis bags (the only content that ships):")
    print()
    for data_file, rows in data:
        print(f"  ── {data_file.name}  ({len(rows)} faces) ──")
        for row in rows:
            kao = row.get("kaomoji", "?")
            count = row.get("count", "?")
            synth = row.get("synthesis") or {}
            bag = flatten_synthesis(synth) if synth else (
                # Pre-v2 bundles carried free-form prose under
                # `synthesis_description`. Render that verbatim if
                # we're inspecting a legacy bundle.
                row.get("synthesis_description", "")
            )
            print(f"    {kao}   ({count} occurrences)")
            print(f"        {bag}")
        print()

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
