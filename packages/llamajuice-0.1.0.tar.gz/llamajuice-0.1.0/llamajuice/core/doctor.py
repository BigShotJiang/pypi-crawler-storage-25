"""juice doctor — diagnose every issue in one command.

Each check returns a DoctorResult. Every failure includes an actionable fix.
"""

from __future__ import annotations

import os
import shutil
import subprocess
import sys
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path

import httpx


class Status(Enum):
    OK = "OK"
    WARN = "WARN"
    FAIL = "FAIL"


@dataclass
class Fix:
    """A machine-readable fix that an agent can execute."""
    command: str              # shell command to run
    platform: str = "any"    # "win32", "linux", "any"
    requires_restart: bool = False
    destructive: bool = False
    description: str = ""    # human-readable explanation


@dataclass
class CheckResult:
    name: str
    status: Status
    message: str
    fix: str | None = None          # human-readable fix text
    fixes: list[Fix] | None = None  # machine-readable fixes for agents


@dataclass
class DoctorReport:
    checks: list[CheckResult] = field(default_factory=list)

    def add(self, result: CheckResult) -> None:
        self.checks.append(result)

    @property
    def ok_count(self) -> int:
        return sum(1 for c in self.checks if c.status == Status.OK)

    @property
    def warn_count(self) -> int:
        return sum(1 for c in self.checks if c.status == Status.WARN)

    @property
    def fail_count(self) -> int:
        return sum(1 for c in self.checks if c.status == Status.FAIL)

    def to_dict(self) -> dict:
        """Return a JSON-serializable dict for agent consumption."""
        checks = []
        for c in self.checks:
            entry = {
                "check": c.name.strip(),
                "status": c.status.value,
                "message": c.message,
            }
            if c.fix:
                entry["fix_human"] = c.fix
            if c.fixes:
                entry["fixes"] = [
                    {
                        "command": f.command,
                        "platform": f.platform,
                        "requires_restart": f.requires_restart,
                        "destructive": f.destructive,
                        "description": f.description,
                    }
                    for f in c.fixes
                ]
            checks.append(entry)

        return {
            "ok": self.ok_count,
            "warnings": self.warn_count,
            "failures": self.fail_count,
            "checks": checks,
        }


def check_gpu(report: DoctorReport) -> dict | None:
    """Check GPU detection and VRAM."""
    try:
        from llamajuice.core.gpu import detect_gpus
        gpus = detect_gpus()
    except Exception as e:
        report.add(CheckResult(
            "GPU", Status.FAIL, str(e),
            fix="Install NVIDIA drivers and ensure nvidia-smi is on PATH.",
            fixes=[
                Fix("winget install NVIDIA.NVIDIADriver", platform="win32",
                    description="Install NVIDIA drivers via winget"),
                Fix("sudo apt install nvidia-driver-550", platform="linux",
                    description="Install NVIDIA drivers via apt"),
            ],
        ))
        return None

    gpu = gpus[0]
    report.add(CheckResult(
        "GPU", Status.OK,
        f"{gpu.name} ({gpu.vram_total_gb} GB VRAM)",
    ))

    # Driver version
    report.add(CheckResult(
        "Driver", Status.OK,
        f"v{gpu.driver_version}",
    ))

    # CUDA version
    report.add(CheckResult(
        "CUDA", Status.OK,
        f"v{gpu.cuda_version}",
    ))

    # VRAM availability
    free_gb = round(gpu.vram_free_mb / 1024, 1)
    if free_gb < 2.0:
        report.add(CheckResult(
            "VRAM free", Status.WARN,
            f"{free_gb} GB free of {gpu.vram_total_gb} GB",
            fix="Close other GPU-using apps (LM Studio, games, etc) to free VRAM.",
            fixes=[],  # no automated fix — requires user judgement
        ))
    else:
        report.add(CheckResult(
            "VRAM free", Status.OK,
            f"{free_gb} GB free of {gpu.vram_total_gb} GB",
        ))

    return {
        "gpu": gpu,
        "vram_total_gb": gpu.vram_total_gb,
        "vram_free_gb": free_gb,
        "driver": gpu.driver_version,
        "cuda": gpu.cuda_version,
    }


def _check_windows_registry_env(name: str) -> str | None:
    """Check if an environment variable is set in the Windows registry (via setx)."""
    if sys.platform != "win32":
        return None
    try:
        result = subprocess.run(
            ["reg", "query", "HKCU\\Environment", "/v", name],
            capture_output=True, text=True, timeout=5,
        )
        if result.returncode == 0:
            # Output like: "    CUDA_VISIBLE_DEVICES    REG_SZ    0"
            for line in result.stdout.splitlines():
                if name in line:
                    parts = line.strip().split()
                    if len(parts) >= 3:
                        return parts[-1]
    except (subprocess.TimeoutExpired, FileNotFoundError):
        pass
    return None


def check_cuda_visible_devices(report: DoctorReport, gpu_info: dict | None) -> None:
    """Check CUDA_VISIBLE_DEVICES — critical for RTX 50-series."""
    val = os.environ.get("CUDA_VISIBLE_DEVICES")

    # On Windows, also check the registry (setx writes there but doesn't affect current shell)
    if val is None and sys.platform == "win32":
        reg_val = _check_windows_registry_env("CUDA_VISIBLE_DEVICES")
        if reg_val is not None:
            report.add(CheckResult(
                "CUDA_VISIBLE_DEVICES", Status.OK,
                f"set to '{reg_val}' (registry, takes effect on new terminals)",
            ))
            return

    if val is not None:
        report.add(CheckResult(
            "CUDA_VISIBLE_DEVICES", Status.OK,
            f"set to '{val}'",
        ))
    else:
        # Check if it's an RTX 50-series (Blackwell) — these need it
        gpu_name = gpu_info["gpu"].name if gpu_info else ""
        is_50_series = any(x in gpu_name for x in ["5050", "5060", "5070", "5080", "5090"])

        if is_50_series:
            report.add(CheckResult(
                "CUDA_VISIBLE_DEVICES", Status.WARN,
                "not set (RTX 50-series detected)",
                fix="Set CUDA_VISIBLE_DEVICES=0 in your environment. "
                    "RTX 50-series GPUs may report 0 VRAM to Ollama without this.\n"
                    "  Windows: setx CUDA_VISIBLE_DEVICES 0\n"
                    "  Linux:   echo 'export CUDA_VISIBLE_DEVICES=0' >> ~/.bashrc",
                fixes=[
                    Fix("setx CUDA_VISIBLE_DEVICES 0", platform="win32",
                        requires_restart=True, description="Set CUDA_VISIBLE_DEVICES permanently (requires terminal restart)"),
                    Fix("echo 'export CUDA_VISIBLE_DEVICES=0' >> ~/.bashrc && source ~/.bashrc",
                        platform="linux", requires_restart=True,
                        description="Set CUDA_VISIBLE_DEVICES permanently"),
                ],
            ))
        else:
            report.add(CheckResult(
                "CUDA_VISIBLE_DEVICES", Status.OK,
                "not set (not required for this GPU)",
            ))


def check_servers(report: DoctorReport) -> dict:
    """Check for running inference servers."""
    servers = {
        "Ollama": (11434, "/api/tags"),
        "LM Studio": (1234, "/health"),
        "llamajuice": (8080, "/health"),
    }

    running = {}
    for name, (port, health_path) in servers.items():
        try:
            resp = httpx.get(f"http://localhost:{port}{health_path}", timeout=2)
            if resp.status_code == 200:
                report.add(CheckResult(
                    name, Status.OK,
                    f"running on :{port}",
                ))
                running[name] = port
            else:
                report.add(CheckResult(
                    name, Status.OK,
                    f"not running on :{port}",
                ))
        except (httpx.ConnectError, httpx.TimeoutException):
            report.add(CheckResult(
                name, Status.OK,
                f"not running on :{port}",
            ))

    if not running:
        report.add(CheckResult(
            "Inference server", Status.WARN,
            "no inference server detected",
            fix="Start Ollama, LM Studio, or run 'juice serve <model>'.",
            fixes=[
                Fix("ollama serve", platform="any",
                    description="Start Ollama server"),
            ],
        ))

    return running


def check_ollama_models(report: DoctorReport, running: dict) -> None:
    """Check Ollama models and their capabilities."""
    if "Ollama" not in running:
        return

    try:
        resp = httpx.get("http://localhost:11434/api/tags", timeout=5)
        data = resp.json()
    except Exception:
        report.add(CheckResult(
            "Ollama models", Status.WARN,
            "could not query Ollama API",
        ))
        return

    models = data.get("models", [])
    if not models:
        report.add(CheckResult(
            "Ollama models", Status.WARN,
            "no models loaded in Ollama",
            fix="Pull a model: ollama pull qwen2.5:7b",
            fixes=[
                Fix("ollama pull qwen2.5:7b", platform="any",
                    description="Pull recommended tool-calling model"),
            ],
        ))
        return

    # Known tool-calling models
    tool_capable = {
        "qwen2.5", "qwen2.5-coder", "qwen3", "llama3.1", "llama3.2",
        "mistral", "granite3.1", "command-r",
    }
    no_tools = {"llama3", "gemma", "gemma2", "gemma3", "phi", "phi3", "deepseek-r1"}

    for m in models:
        name = m.get("name", "")
        size_gb = round(m.get("size", 0) / (1024**3), 1)
        base_name = name.split(":")[0].lower()

        has_tools = any(tc in base_name for tc in tool_capable)
        known_no_tools = any(nt in base_name for nt in no_tools)

        if has_tools:
            report.add(CheckResult(
                f"  {name}", Status.OK,
                f"{size_gb} GB, tool calling supported",
            ))
        elif known_no_tools:
            report.add(CheckResult(
                f"  {name}", Status.WARN,
                f"{size_gb} GB, no tool calling support",
                fix=f"For agents, use qwen2.5:7b or llama3.1:8b instead of {name}.",
                fixes=[
                    Fix("ollama pull qwen2.5:7b", platform="any",
                        description=f"Pull qwen2.5:7b as tool-calling replacement for {name}"),
                ],
            ))
        else:
            report.add(CheckResult(
                f"  {name}", Status.OK,
                f"{size_gb} GB, tool calling unknown",
            ))


def check_local_models(report: DoctorReport) -> None:
    """Check for locally available GGUF models."""
    from llamajuice.models.scanner import scan_local_models
    models = scan_local_models()

    if not models:
        report.add(CheckResult(
            "Local GGUFs", Status.WARN,
            "no GGUF models found (LM Studio or Ollama)",
            fix="Download models via LM Studio or Ollama, or run 'juice recommend'.",
            fixes=[
                Fix("ollama pull qwen2.5:7b", platform="any",
                    description="Pull a recommended model via Ollama"),
            ],
        ))
    else:
        report.add(CheckResult(
            "Local GGUFs", Status.OK,
            f"{len(models)} models found",
        ))


def check_llama_server_binary(report: DoctorReport) -> None:
    """Check if llama-server binary is installed."""
    from llamajuice.core.server import BIN_DIR

    if sys.platform == "win32":
        binary = BIN_DIR / "llama-server.exe"
    else:
        binary = BIN_DIR / "llama-server"

    if binary.exists():
        size_mb = round(binary.stat().st_size / (1024**2), 1)
        report.add(CheckResult(
            "llama-server", Status.OK,
            f"installed ({size_mb} MB) at {BIN_DIR}",
        ))

        # Check for CUDA DLLs on Windows
        if sys.platform == "win32":
            cuda_dll = BIN_DIR / "ggml-cuda.dll"
            if cuda_dll.exists():
                report.add(CheckResult(
                    "CUDA backend", Status.OK,
                    "ggml-cuda.dll found",
                ))
            else:
                report.add(CheckResult(
                    "CUDA backend", Status.WARN,
                    "ggml-cuda.dll not found",
                    fix="Run 'juice setup' to re-download with CUDA support.",
                    fixes=[
                        Fix("juice setup", platform="any",
                            description="Re-download llama-server with CUDA support"),
                    ],
                ))
    else:
        report.add(CheckResult(
            "llama-server", Status.WARN,
            "not installed",
            fix="Run 'juice setup' to download it.",
            fixes=[
                Fix("juice setup", platform="any",
                    description="Download llama-server binary"),
            ],
        ))


def check_whisper(report: DoctorReport) -> None:
    """Check Whisper dependencies for voice/audio support."""
    # faster-whisper
    try:
        import faster_whisper  # noqa: F401
        report.add(CheckResult(
            "faster-whisper", Status.OK,
            "installed",
        ))
    except ImportError:
        report.add(CheckResult(
            "faster-whisper", Status.OK,
            "not installed (optional, for voice features)",
        ))
        return  # skip further whisper checks

    # ffmpeg
    if shutil.which("ffmpeg"):
        report.add(CheckResult(
            "ffmpeg", Status.OK,
            "found on PATH",
        ))
    else:
        report.add(CheckResult(
            "ffmpeg", Status.WARN,
            "not found on PATH",
            fix="Install ffmpeg: https://ffmpeg.org/download.html\n"
                "  Windows: winget install ffmpeg\n"
                "  Linux:   sudo apt install ffmpeg",
            fixes=[
                Fix("winget install ffmpeg", platform="win32",
                    description="Install ffmpeg via winget"),
                Fix("sudo apt install ffmpeg", platform="linux",
                    description="Install ffmpeg via apt"),
            ],
        ))

    # cuBLAS — needed for GPU-accelerated Whisper
    # Can come from: pip nvidia-cublas-cu12, system CUDA toolkit, or DLLs on PATH
    cublas_found = False

    # Check pip-installed nvidia-cublas package first
    try:
        import nvidia.cublas  # noqa: F401
        cublas_found = True
        report.add(CheckResult(
            "cuBLAS (Whisper)", Status.OK,
            "found via pip (nvidia-cublas-cu12)",
        ))
    except ImportError:
        pass

    if not cublas_found and sys.platform == "win32":
        cublas = shutil.which("cublas64_12.dll")
        if cublas:
            cublas_found = True
            report.add(CheckResult(
                "cuBLAS (Whisper)", Status.OK,
                "found on PATH",
            ))
        else:
            # Check common locations
            nvidia_path = Path(os.environ.get("CUDA_PATH", "")) / "bin" / "cublas64_12.dll"
            if nvidia_path.exists():
                cublas_found = True
                report.add(CheckResult(
                    "cuBLAS (Whisper)", Status.OK,
                    f"found at {nvidia_path.parent}",
                ))

    if not cublas_found:
        report.add(CheckResult(
            "cuBLAS (Whisper)", Status.WARN,
            "not found (Whisper will use CPU)",
            fix="Install via pip: pip install nvidia-cublas-cu12\n"
                "  Or install CUDA Toolkit: winget install NVIDIA.CUDA (Windows)",
            fixes=[
                Fix("pip install nvidia-cublas-cu12", platform="any",
                    description="Install cuBLAS via pip (recommended)"),
                Fix("winget install NVIDIA.CUDA", platform="win32",
                    description="Install CUDA Toolkit (includes cuBLAS)"),
            ],
        ))


def run_doctor() -> DoctorReport:
    """Run all diagnostic checks and return the report."""
    report = DoctorReport()

    gpu_info = check_gpu(report)
    check_cuda_visible_devices(report, gpu_info)
    running = check_servers(report)
    check_ollama_models(report, running)
    check_local_models(report)
    check_llama_server_binary(report)
    check_whisper(report)

    return report
