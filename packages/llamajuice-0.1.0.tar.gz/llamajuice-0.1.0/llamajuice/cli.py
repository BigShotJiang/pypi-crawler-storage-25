"""llamajuice CLI — squeeze every last drop from your NVIDIA GPU."""

from __future__ import annotations

import sys
from pathlib import Path

import typer
from rich.box import ASCII
from rich.console import Console
from rich.table import Table

app = typer.Typer(
    name="juice",
    help="Squeeze every last drop from your NVIDIA GPU.",
    no_args_is_help=True,
)
console = Console()


def _resolve_model(model: str):
    """Resolve a model argument to a LocalModel or Path.

    Accepts:
      - A direct path to a .gguf file
      - A model name to fuzzy-match against locally installed models

    Returns a LocalModel (which may be an Ollama model with path=None).
    """
    from llamajuice.models.scanner import LocalModel, scan_local_models

    # Direct path
    path = Path(model).expanduser().resolve()
    if path.exists() and path.suffix == ".gguf":
        size_gb = round(path.stat().st_size / (1024**3), 1)
        return LocalModel(name=path.stem, path=path, size_gb=size_gb, source="local")

    # Fuzzy match against scanned models
    local = scan_local_models()
    if not local:
        console.print("  No local models found.", style="red bold")
        console.print("  Download a GGUF from HuggingFace, or install models via LM Studio or Ollama.")
        console.print("  Then run: juice serve path/to/model.gguf")
        console.print("\n  Run 'juice recommend' for model suggestions.\n")
        raise typer.Exit(1)

    query = model.lower().replace("-", "").replace("_", "").replace(" ", "").replace(":", "")

    # Exact-ish match first
    for m in local:
        normalized = m.name.lower().replace("-", "").replace("_", "").replace(" ", "").replace(":", "")
        if query == normalized or query in normalized:
            return m

    # No match — show what's available
    console.print(f"  Model '{model}' not found locally.\n", style="red bold")
    _print_local_models(local)
    raise typer.Exit(1)


def _print_local_models(models: list) -> None:
    """Print a table of locally available models."""
    table = Table(title="Your local models", box=ASCII)
    table.add_column("#", justify="right", style="dim")
    table.add_column("Name", style="cyan")
    table.add_column("Size", justify="right")
    table.add_column("Source")

    for i, m in enumerate(models, 1):
        table.add_row(str(i), m.name, f"{m.size_gb} GB", m.source)

    console.print(table)
    console.print("\n  Usage: juice serve <name or path>\n")


@app.command()
def serve(
    model: str = typer.Argument(
        ..., help="Model name (fuzzy matched) or path to a .gguf file"
    ),
    port: int = typer.Option(8080, help="Port for llama-server"),
    preset: str | None = typer.Option(None, help="VRAM preset (8gb, 12gb, 16gb, 24gb, code)"),
    ctx_size: int | None = typer.Option(None, "--ctx-size", help="Override context size"),
    verbose: bool = typer.Option(False, "--verbose", "-v", help="Show llama-server output"),
    no_verify: bool = typer.Option(False, "--no-verify", help="Skip GPU utilisation check"),
):
    """Launch a model with full GPU offload.

    Finds models from LM Studio and Ollama automatically:

        juice serve qwen2.5:7b    # Ollama model — loads via Ollama API
        juice serve gemma-3-4b    # LM Studio GGUF — launches llama-server
        juice serve ./model.gguf  # direct path — launches llama-server
    """
    from llamajuice.core.gpu import GPUError, detect_gpu

    try:
        resolved = _resolve_model(model)

        gpu = detect_gpu()
        console.print(f"  GPU:    {gpu.name}  {gpu.vram_total_gb} GB", style="green")
        console.print(f"  Model:  {resolved.name}  ({resolved.size_gb} GB, {resolved.source})", style="green")

        if resolved.source == "ollama" and resolved.path is None:
            # Ollama model — load it via Ollama API and keep it warm
            _serve_ollama(resolved.name, gpu, port)
        else:
            # GGUF file — launch llama-server
            _serve_llama_server(resolved.path, gpu, port, preset, ctx_size, verbose, no_verify)

    except GPUError as e:
        console.print(f"  FAIL: {e}", style="red bold")
        raise typer.Exit(1)
    except KeyboardInterrupt:
        console.print("\n  Shutting down.", style="yellow")


def _serve_ollama(model_name: str, gpu, port: int) -> None:
    """Load an Ollama model and keep it warm."""
    import httpx
    import signal
    import time

    ollama_url = "http://localhost:11434"

    # Check Ollama is running
    try:
        resp = httpx.get(f"{ollama_url}/api/tags", timeout=3)
        resp.raise_for_status()
    except Exception:
        console.print("  FAIL: Ollama is not running. Start it with: ollama serve", style="red bold")
        raise typer.Exit(1)

    # Load the model by sending a dummy request with keep_alive
    console.print(f"  Loading {model_name} via Ollama (first load may take a few seconds)...", style="yellow")
    try:
        resp = httpx.post(
            f"{ollama_url}/api/generate",
            json={"model": model_name, "prompt": "", "keep_alive": "30m"},
            timeout=120,
        )
    except Exception as e:
        console.print(f"  FAIL: Could not load model: {e}", style="red bold")
        raise typer.Exit(1)

    # Check VRAM after loading
    from llamajuice.core.gpu import detect_gpu
    gpu = detect_gpu()
    console.print(
        f"  VRAM:   {gpu.vram_used_gb}/{gpu.vram_total_gb} GB  "
        f"[{gpu.vram_bar(12)}]  {gpu.vram_pct}%",
        style="green",
    )

    console.print(f"  Server: http://localhost:11434/v1  (Ollama)", style="green")
    console.print(f"          Model loaded with 30m keep-alive")
    console.print(f"\n  Press Ctrl+C to stop.\n")

    # Block until Ctrl+C, periodically keep the model warm
    try:
        while True:
            time.sleep(300)  # every 5 min, ping to keep alive
            try:
                httpx.post(
                    f"{ollama_url}/api/generate",
                    json={"model": model_name, "prompt": "", "keep_alive": "30m"},
                    timeout=10,
                )
            except Exception:
                pass
    except KeyboardInterrupt:
        console.print("\n  Shutting down.", style="yellow")


def _serve_llama_server(model_path, gpu, port, preset, ctx_size, verbose, no_verify) -> None:
    """Launch llama-server with a GGUF file."""
    from llamajuice.core.gpu import GPUError
    from llamajuice.core.presets import PRESETS, ServerFlags, select_preset
    from llamajuice.core.server import GPUServer, _find_binary

    # Build flags
    flags = None
    if preset and preset in PRESETS:
        flags = PRESETS[preset]
    elif ctx_size is not None:
        _, base = select_preset(gpu)
        flags = ServerFlags(
            ngl=base.ngl,
            ctx_size=ctx_size,
            flash_attn=base.flash_attn,
            batch_size=base.batch_size,
            threads=base.threads,
            parallel=base.parallel,
            extra=base.extra,
        )

    # Auto-download binary if needed
    try:
        _find_binary()
    except GPUError:
        console.print("\n  llama-server binary not found. Downloading...", style="yellow")
        from scripts.download_server import download_server
        download_server()

    console.print(f"  Loading model to GPU (first load takes a few seconds)...", style="yellow")

    # Launch server
    server = GPUServer(
        model_path=model_path,
        port=port,
        preset=preset,
        flags=flags,
        verify_gpu=not no_verify,
    )

    console.print(
        f"  VRAM:   {server.gpu.vram_used_gb}/{server.gpu.vram_total_gb} GB  "
        f"[{server.gpu.vram_bar(12)}]  {server.gpu.vram_pct}%",
        style="green",
    )

    console.print(f"  Server: http://localhost:{port}/v1  ready", style="green")
    console.print(f"\n  Press Ctrl+C to stop.\n")

    server.launch(verbose=verbose)


@app.command()
def combo(
    main: str = typer.Option("qwen2.5:7b", help="Main model for complex tasks"),
    fast: str = typer.Option("qwen2.5:1.5b", help="Fast model for simple tasks"),
    backend: str = typer.Option("http://localhost:11434/v1", help="Backend server URL (Ollama)"),
    port: int = typer.Option(8080, help="Port for the combo proxy"),
):
    """Launch a multi-model proxy — fast model + main model, one endpoint.

    Routes automatically: simple questions go to the 1.5B (instant),
    complex reasoning and tool calls go to the 7B.

        juice combo
        juice combo --main qwen2.5:7b --fast qwen2.5:1.5b

    Your app connects to http://localhost:8080/v1 — it looks like one model.
    """
    import uvicorn

    from llamajuice.api.combo import app as combo_app, configure
    from llamajuice.core.router import ComboConfig

    config = ComboConfig(
        fast_model=fast,
        main_model=main,
        backend_url=backend,
        proxy_port=port,
    )
    configure(config)

    console.print(f"\n  juice combo\n")
    console.print(f"  Fast model:  {fast}", style="cyan")
    console.print(f"  Main model:  {main}", style="cyan")
    console.print(f"  Backend:     {backend}")
    console.print(f"  Proxy:       http://localhost:{port}/v1", style="green")
    console.print(f"\n  Simple tasks -> {fast} (instant)")
    console.print(f"  Complex/tools -> {main} (accurate)")
    console.print(f"\n  Stats: http://localhost:{port}/juice/stats")
    console.print(f"\n  Press Ctrl+C to stop.\n")

    uvicorn.run(combo_app, host="0.0.0.0", port=port, log_level="warning")


@app.command()
def models():
    """List your locally available GGUF models."""
    from llamajuice.models.scanner import scan_local_models

    local = scan_local_models()
    if not local:
        console.print("\n  No local models found.")
        console.print("  Install models via LM Studio or Ollama, or download GGUFs from HuggingFace.")
        console.print("\n  Run 'juice recommend' for suggestions.\n")
        return

    _print_local_models(local)


@app.command()
def setup():
    """Download the llama-server binary for your platform."""
    from scripts.download_server import download_server

    try:
        path = download_server()
        console.print(f"  llama-server ready at {path}", style="green")
    except Exception as e:
        console.print(f"  FAIL: {e}", style="red bold")
        raise typer.Exit(1)


@app.command()
def status():
    """Show GPU info and detected servers."""
    from llamajuice.core.gpu import GPUError, detect_gpus

    try:
        gpus = detect_gpus()
    except GPUError as e:
        console.print(f"  FAIL: {e}", style="red bold")
        raise typer.Exit(1)

    for gpu in gpus:
        console.print(f"\n  GPU {gpu.index}: {gpu.name}")
        vram_note = " (idle, no model loaded)" if gpu.vram_pct < 5 else ""
        console.print(f"  VRAM:   {gpu.vram_used_gb}/{gpu.vram_total_gb} GB  [{gpu.vram_bar(12)}]  {gpu.vram_pct}%{vram_note}")
        console.print(f"  Driver: {gpu.driver_version}  CUDA: {gpu.cuda_version}")

    # Check for running servers
    import httpx

    servers = [
        ("llamajuice", 8080, "/health"),
        ("Ollama", 11434, "/api/tags"),
        ("LM Studio", 1234, "/health"),
    ]
    console.print()
    for name, port, path in servers:
        try:
            resp = httpx.get(f"http://localhost:{port}{path}", timeout=2)
            if resp.status_code == 200:
                console.print(f"  {name} running on :{port}", style="green")
            else:
                console.print(f"  {name} not detected on :{port}", style="dim")
        except (httpx.ConnectError, httpx.TimeoutException):
            console.print(f"  {name} not detected on :{port}", style="dim")


@app.command()
def doctor(
    json_output: bool = typer.Option(False, "--json", help="Output as JSON for agent consumption"),
):
    """Diagnose your GPU, drivers, models, and dependencies.

    Catches every issue that wastes hours — GPU not detected, wrong model
    for tool calling, missing DLLs, context overflow risks.

    Use --json for machine-readable output that AI agents can act on.
    Each fix includes the exact command, target platform, and whether
    it requires a restart or is destructive.
    """
    import json

    from llamajuice.core.doctor import Status, run_doctor

    report = run_doctor()

    if json_output:
        print(json.dumps(report.to_dict(), indent=2))
        if report.fail_count > 0:
            raise typer.Exit(1)
        return

    console.print("\n  juice doctor\n")

    for check in report.checks:
        if check.status == Status.OK:
            style = "green"
            tag = " OK  "
        elif check.status == Status.WARN:
            style = "yellow"
            tag = " WARN"
        else:
            style = "red bold"
            tag = " FAIL"

        console.print(f"  [{tag}] {check.name}: {check.message}", style=style)

        if check.fix:
            for line in check.fix.split("\n"):
                console.print(f"          {line}", style="dim")

    console.print()
    console.print(
        f"  {report.ok_count} passed, {report.warn_count} warnings, {report.fail_count} failures\n"
    )

    if report.fail_count > 0:
        raise typer.Exit(1)


@app.command()
def recommend():
    """Suggest models for your GPU and use case."""
    from llamajuice.core.gpu import GPUError, detect_gpu
    from llamajuice.models.registry import list_models_for_vram

    try:
        gpu = detect_gpu()
    except GPUError as e:
        console.print(f"  FAIL: {e}", style="red bold")
        raise typer.Exit(1)

    available = list_models_for_vram(gpu.vram_total_gb)

    console.print(f"\n  Recommendations for {gpu.name} ({gpu.vram_total_gb} GB)\n")

    table = Table(box=ASCII)
    table.add_column("Model", style="cyan")
    table.add_column("Quant")
    table.add_column("Size", justify="right")
    table.add_column("Use case")

    for m in sorted(available, key=lambda x: x.size_gb):
        table.add_row(
            m.name,
            m.quant,
            f"{m.size_gb} GB",
            m.description,
        )

    console.print(table)

    console.print("\n  HuggingFace links:")
    for m in sorted(available, key=lambda x: x.size_gb):
        console.print(f"    {m.name}: huggingface.co/{m.repo_id}", style="dim")

    console.print("\n  Download from HuggingFace or install via LM Studio/Ollama, then:")
    console.print("  juice serve <model-name>\n", style="green")


@app.command()
def bench(
    url: str | None = typer.Argument(
        None, help="Server URL (e.g. http://localhost:11434/v1). Auto-detects if omitted."
    ),
    runs: int = typer.Option(3, help="Number of generation runs (first is warmup)"),
    no_tools: bool = typer.Option(False, "--no-tools", help="Skip tool call test"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
):
    """Benchmark local LLM performance on your hardware.

    Auto-detects running servers (Ollama, LM Studio, llamajuice) and
    benchmarks them all. Or point at a specific server:

        juice bench http://localhost:11434/v1
        juice bench                           # auto-detect all
    """
    import json as json_mod

    from llamajuice.core.benchmark import (
        bench_server,
        detect_and_bench_competitors,
        format_shareable,
    )
    from llamajuice.core.gpu import detect_gpu

    try:
        gpu = detect_gpu()
    except Exception:
        gpu = None

    if url:
        console.print(f"\n  Benchmarking {url}...\n")
        try:
            result = bench_server(url, server_name="server", runs=runs, test_tools=not no_tools)
            results = [result]
        except Exception as e:
            console.print(f"  FAIL: {e}", style="red bold")
            raise typer.Exit(1)
    else:
        console.print("\n  Detecting servers and benchmarking...\n")
        results = detect_and_bench_competitors()
        if not results:
            console.print("  No running servers with loaded models found.", style="red bold")
            console.print("  Start Ollama/LM Studio with a model loaded, or run 'juice serve <model>'.\n")
            raise typer.Exit(1)

    if json_output:
        output = {
            "gpu": gpu.name if gpu else None,
            "vram_gb": gpu.vram_total_gb if gpu else None,
            "results": [r.to_dict() for r in results],
        }
        print(json_mod.dumps(output, indent=2))
        return

    # Human-readable table
    if gpu:
        console.print(f"  Hardware: {gpu.name} ({gpu.vram_total_gb} GB)\n")

    table = Table(box=ASCII)
    table.add_column("Server", style="cyan")
    table.add_column("Model")
    table.add_column("tok/s", justify="right")
    table.add_column("TTFT", justify="right")
    table.add_column("VRAM", justify="right")
    table.add_column("Tools")

    for r in results:
        tool_str = "pass" if r.tool_call_pass else "FAIL"
        if r.tool_call_pass is None:
            tool_str = "skip"
        vram_str = f"{r.vram_used_gb}/{r.vram_total_gb} GB ({r.vram_pct}%)"
        table.add_row(
            r.server_name,
            r.model,
            f"{r.tok_per_sec:.1f}",
            f"{r.ttft_ms:.0f}ms",
            vram_str,
            tool_str,
        )

    console.print(table)

    # Per-run details
    for r in results:
        console.print(f"\n  {r.server_name} runs:")
        for run in r.runs:
            warmup = " (warmup)" if run.get("warmup") else ""
            console.print(
                f"    #{run['run']}: {run['tok_per_sec']} tok/s, "
                f"{run['ttft_ms']}ms TTFT, {run['tokens']} tokens{warmup}",
                style="dim",
            )

        if r.tool_call_error:
            console.print(f"    Tool call error: {r.tool_call_error}", style="yellow")

    # Shareable one-liner
    console.print(f"\n  {format_shareable(results, gpu)}\n")


def main():
    app()
