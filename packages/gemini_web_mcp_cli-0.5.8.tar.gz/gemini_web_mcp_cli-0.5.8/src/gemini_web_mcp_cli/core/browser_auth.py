"""Shared browser authentication helpers for CDP-backed Gemini sessions."""

from __future__ import annotations

import re
import time
from dataclasses import dataclass, field

from loguru import logger

from .cdp import (
    execute_cdp_command,
    find_or_create_gemini_page,
    get_page_cookies,
    navigate_to_url,
    run_js,
)
from .constants import COOKIE_1PSID, TOKEN_PATTERNS

GEMINI_APP_URL = "https://gemini.google.com/app"


@dataclass
class BrowserAuthStatus:
    """Observed auth state for a Chrome/CDP Gemini page."""

    ws_url: str | None = None
    url: str = ""
    raw_cookies: list[dict] = field(default_factory=list)
    cookies: dict[str, str] = field(default_factory=dict)
    access_token: str = ""
    synced_from_auth: bool = False
    error: str = ""

    @property
    def has_auth_cookie(self) -> bool:
        return bool(self.cookies.get(COOKIE_1PSID))

    @property
    def is_authenticated(self) -> bool:
        return bool(self.has_auth_cookie and self.access_token)


def load_saved_auth_state(profile_name: str | None):
    """Load saved auth.json state for a profile, returning None on failure."""
    try:
        from .auth import AuthManager
        from .profiles import ProfileManager

        pm = ProfileManager()
        am = AuthManager(profile_manager=pm, profile_name=profile_name)
        return am.load()
    except Exception as e:
        logger.debug(f"Browser auth: could not load saved auth state: {e}")
        return None


def cdp_cookies_from_saved(cookies: dict[str, str]) -> list[dict]:
    """Convert saved auth.json cookies into CDP Network.setCookies payloads."""
    cdp_cookies = []
    for name, value in cookies.items():
        if not value:
            continue
        cookie = {
            "name": name,
            "value": value,
            "path": "/",
            "secure": True,
            "httpOnly": True,
        }
        if name.startswith("__Host-"):
            cookie["url"] = "https://gemini.google.com/"
        else:
            cookie["domain"] = ".google.com"
        cdp_cookies.append(cookie)
    return cdp_cookies


def sync_saved_auth_to_chrome(
    ws_url: str,
    profile_name: str | None,
    *,
    wait_seconds: float = 3,
) -> bool:
    """Inject saved auth.json cookies into Chrome and reload Gemini."""
    state = load_saved_auth_state(profile_name)
    if not state or not state.cookies.get(COOKIE_1PSID):
        logger.debug("Browser auth: no saved auth cookies to sync")
        return False

    cdp_cookies = cdp_cookies_from_saved(state.cookies)
    if not cdp_cookies:
        return False

    execute_cdp_command(
        ws_url,
        "Network.setCookies",
        {"cookies": cdp_cookies},
    )
    navigate_to_url(ws_url, GEMINI_APP_URL)
    time.sleep(wait_seconds)
    logger.debug(f"Browser auth: synced {len(cdp_cookies)} saved cookies to Chrome")
    return True


def extract_browser_auth_status(ws_url: str) -> BrowserAuthStatus:
    """Inspect a Gemini CDP page for Google cookies and live SNlM0e."""
    status = BrowserAuthStatus(ws_url=ws_url)
    try:
        status.url = run_js(ws_url, "window.location.href") or ""
    except Exception:
        status.url = ""

    try:
        status.raw_cookies = get_page_cookies(ws_url)
        status.cookies = {
            c["name"]: c["value"]
            for c in status.raw_cookies
            if c.get("name") and c.get("value") and "google.com" in c.get("domain", "")
        }
    except Exception as e:
        status.error = f"cookie extraction failed: {e}"
        return status

    try:
        status.access_token = (
            run_js(ws_url, "window.WIZ_global_data?.SNlM0e || ''") or ""
        )
    except Exception as e:
        logger.debug(f"Browser auth: SNlM0e JS extraction failed: {e}")

    if not status.access_token:
        try:
            from .cdp import get_page_html

            html = get_page_html(ws_url)
            match = re.search(TOKEN_PATTERNS["snlm0e"], html)
            if match:
                status.access_token = match.group(1)
        except Exception as e:
            logger.debug(f"Browser auth: SNlM0e HTML extraction failed: {e}")

    return status


def ensure_browser_authenticated(
    ws_url: str,
    profile_name: str | None,
    *,
    sync_if_needed: bool = True,
) -> BrowserAuthStatus:
    """Return verified browser auth, optionally syncing saved cookies first."""
    status = extract_browser_auth_status(ws_url)
    if status.is_authenticated or not sync_if_needed:
        return status

    try:
        if sync_saved_auth_to_chrome(ws_url, profile_name):
            status = extract_browser_auth_status(ws_url)
            status.synced_from_auth = True
    except Exception as e:
        status.error = f"saved cookie sync failed: {e}"
        logger.debug(f"Browser auth: saved cookie sync failed: {e}")

    return status


def get_browser_auth_status_for_port(
    port: int,
    profile_name: str | None = None,
    *,
    sync_if_needed: bool = False,
) -> BrowserAuthStatus:
    """Find/create a Gemini page on a CDP port and inspect browser auth."""
    page = find_or_create_gemini_page(port)
    if not page:
        return BrowserAuthStatus(error="Gemini page not found")

    ws_url = page.get("webSocketDebuggerUrl")
    if not ws_url:
        return BrowserAuthStatus(error="Gemini page has no WebSocket URL")

    return ensure_browser_authenticated(
        ws_url,
        profile_name,
        sync_if_needed=sync_if_needed,
    )
