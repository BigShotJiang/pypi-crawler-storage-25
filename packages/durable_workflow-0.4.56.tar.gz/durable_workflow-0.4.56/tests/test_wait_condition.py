from __future__ import annotations

from durable_workflow import serializer, workflow
from durable_workflow.workflow import (
    CompleteWorkflow,
    FailWorkflow,
    WaitCondition,
    WorkflowContext,
    query_state,
    replay,
)


def _signal_received_event(name: str, args: list, workflow_sequence: int | None = None) -> dict:
    payload = {
        "signal_name": name,
        "value": serializer.envelope(args),
        "payload_codec": serializer.AVRO_CODEC,
    }
    if workflow_sequence is not None:
        payload["workflow_sequence"] = workflow_sequence

    return {
        "event_type": "SignalReceived",
        "payload": payload,
    }


@workflow.defn(name="wait-until-approved")
class WaitUntilApproved:
    def __init__(self) -> None:
        self.approved: bool = False

    @workflow.signal("approve")
    def on_approve(self) -> None:
        self.approved = True

    def run(self, ctx: WorkflowContext):  # type: ignore[no-untyped-def]
        yield ctx.wait_condition(lambda: self.approved, key="approved")
        return "approved"


@workflow.defn(name="wait-with-timeout")
class WaitWithTimeout:
    def __init__(self) -> None:
        self.approved: bool = False

    @workflow.signal("approve")
    def on_approve(self) -> None:
        self.approved = True

    def run(self, ctx: WorkflowContext):  # type: ignore[no-untyped-def]
        satisfied = yield ctx.wait_condition(
            lambda: self.approved,
            key="approved",
            timeout=30,
        )
        return "approved" if satisfied else "timed_out"


@workflow.defn(name="wait-immediate-true")
class WaitImmediateTrue:
    def run(self, ctx: WorkflowContext):  # type: ignore[no-untyped-def]
        satisfied = yield ctx.wait_condition(lambda: True, key="always")
        return "satisfied" if satisfied else "no"


@workflow.defn(name="activity-then-wait-for-approval")
class ActivityThenWaitForApproval:
    def __init__(self) -> None:
        self.activity_result: str | None = None
        self.approved_by: str | None = None

    @workflow.signal("approve")
    def approve(self, approved_by: str) -> None:
        self.approved_by = approved_by

    @workflow.query("state")
    def state(self) -> dict[str, str | None]:
        return {
            "activity_result": self.activity_result,
            "approved_by": self.approved_by,
        }

    def run(self, ctx: WorkflowContext):  # type: ignore[no-untyped-def]
        self.activity_result = yield ctx.schedule_activity("load-state", [])
        self.approved_by = None
        yield ctx.wait_condition(
            lambda: self.approved_by == "alice",
            key="approval",
            timeout=30,
        )

        return {
            "activity_result": self.activity_result,
            "approved_by": self.approved_by,
        }


@workflow.defn(name="two-stage-signal-wait")
class TwoStageSignalWait:
    def __init__(self) -> None:
        self.stage = "booting"
        self.name: str | None = None
        self.finished = False
        self.events: list[str] = []

    @workflow.signal("advance")
    def advance(self, name: str) -> None:
        self.name = name
        self.events.append(f"signal:{name}")

    @workflow.signal("finish")
    def finish(self) -> None:
        self.finished = True
        self.events.append("signal:finish")

    @workflow.query("state")
    def state(self) -> dict[str, object]:
        return {
            "stage": self.stage,
            "name": self.name,
            "finished": self.finished,
            "events": list(self.events),
        }

    def run(self, ctx: WorkflowContext):  # type: ignore[no-untyped-def]
        self.stage = "waiting-for-advance"
        self.events.append("started")
        yield ctx.wait_condition(lambda: self.name is not None, key="advance")

        self.stage = "waiting-for-finish"
        self.finished = False
        self.events.append(f"advanced:{self.name}")
        yield ctx.wait_condition(lambda: self.finished, key="finish")

        self.stage = "completed"
        self.events.append("finish")
        return self.state()


@workflow.defn(name="signal-counter-until-finished")
class SignalCounterUntilFinished:
    def __init__(self) -> None:
        self.count = 0
        self.done = False
        self.events: list[dict[str, object]] = []

    @workflow.signal("increment")
    def increment(self, amount: int) -> None:
        self.count += amount
        self.events.append({"signal": "increment", "amount": amount, "count": self.count})

    @workflow.signal("finish")
    def finish(self) -> None:
        self.done = True
        self.events.append({"signal": "finish", "count": self.count})

    @workflow.query("current")
    def current(self) -> dict[str, object]:
        return {
            "count": self.count,
            "done": self.done,
            "events": list(self.events),
        }

    def run(self, ctx: WorkflowContext):  # type: ignore[no-untyped-def]
        yield ctx.wait_condition(lambda: self.done, key="done")
        return self.current()


class TestCtxWaitCondition:
    def test_wait_condition_returns_dataclass_with_predicate_and_key(self) -> None:
        ctx = WorkflowContext(run_id="x")
        cmd = ctx.wait_condition(lambda: False, key="k", timeout=5.0)

        assert isinstance(cmd, WaitCondition)
        assert cmd.condition_key == "k"
        assert cmd.timeout_seconds == 5
        assert cmd.condition_definition_fingerprint is not None
        assert cmd.condition_definition_fingerprint.startswith("sha256:")
        assert callable(cmd.predicate)
        assert cmd.predicate() is False

    def test_wait_condition_rounds_timeout_up_to_whole_second(self) -> None:
        ctx = WorkflowContext(run_id="x")
        cmd = ctx.wait_condition(lambda: False, timeout=1.2)

        assert cmd.timeout_seconds == 2

    def test_wait_condition_zero_timeout_preserved(self) -> None:
        ctx = WorkflowContext(run_id="x")
        cmd = ctx.wait_condition(lambda: False, timeout=0)

        assert cmd.timeout_seconds == 0

    def test_wait_condition_no_timeout_remains_none(self) -> None:
        ctx = WorkflowContext(run_id="x")
        cmd = ctx.wait_condition(lambda: False)

        assert cmd.timeout_seconds is None
        assert cmd.condition_key is None


class TestWaitConditionToServerCommand:
    def test_emits_open_condition_wait_with_optional_fields(self) -> None:
        cmd = WaitCondition(
            predicate=lambda: True,
            condition_key="order",
            condition_definition_fingerprint="sha256:condition",
            timeout_seconds=60,
        )

        server_cmd = cmd.to_server_command("default")

        assert server_cmd == {
            "type": "open_condition_wait",
            "condition_key": "order",
            "condition_definition_fingerprint": "sha256:condition",
            "timeout_seconds": 60,
        }

    def test_emits_minimal_open_condition_wait_when_optional_fields_absent(self) -> None:
        cmd = WaitCondition(predicate=lambda: True)

        assert cmd.to_server_command("default") == {"type": "open_condition_wait"}


class TestReplayWaitCondition:
    def test_predicate_immediately_true_advances_without_emitting_command(self) -> None:
        outcome = replay(WaitImmediateTrue, [], [])

        assert len(outcome.commands) == 1
        assert isinstance(outcome.commands[0], CompleteWorkflow)
        assert outcome.commands[0].result == "satisfied"

    def test_predicate_false_with_no_history_emits_open_condition_wait(self) -> None:
        outcome = replay(WaitUntilApproved, [], [])

        assert len(outcome.commands) == 1
        cmd = outcome.commands[0]
        assert isinstance(cmd, WaitCondition)
        assert cmd.condition_key == "approved"
        assert cmd.timeout_seconds is None

    def test_signal_received_after_open_resolves_predicate_true_and_completes(self) -> None:
        history = [
            {
                "event_type": "ConditionWaitOpened",
                "payload": {"condition_wait_id": "wait-1", "condition_key": "approved"},
            },
            _signal_received_event("approve", []),
        ]

        outcome = replay(WaitUntilApproved, history, [])

        assert len(outcome.commands) == 1
        assert isinstance(outcome.commands[0], CompleteWorkflow)
        assert outcome.commands[0].result == "approved"

    def test_condition_timeout_timer_fired_resolves_wait_as_timed_out(self) -> None:
        history = [
            {
                "event_type": "ConditionWaitOpened",
                "payload": {"condition_wait_id": "wait-1", "condition_key": "approved"},
            },
            {
                "event_type": "TimerFired",
                "payload": {
                    "timer_kind": "condition_timeout",
                    "condition_wait_id": "wait-1",
                },
            },
        ]

        outcome = replay(WaitWithTimeout, history, [])

        assert len(outcome.commands) == 1
        assert isinstance(outcome.commands[0], CompleteWorkflow)
        assert outcome.commands[0].result == "timed_out"

    def test_condition_wait_satisfied_event_resolves_wait_even_if_predicate_false(self) -> None:
        history = [
            {
                "event_type": "ConditionWaitOpened",
                "payload": {"condition_wait_id": "wait-1", "condition_key": "approved"},
            },
            {
                "event_type": "ConditionWaitSatisfied",
                "payload": {"condition_wait_id": "wait-1"},
            },
        ]

        outcome = replay(WaitUntilApproved, history, [])

        assert len(outcome.commands) == 1
        assert isinstance(outcome.commands[0], CompleteWorkflow)
        assert outcome.commands[0].result == "approved"

    def test_signal_after_activity_result_applies_after_result_is_consumed(self) -> None:
        history = [
            {
                "event_type": "ActivityCompleted",
                "payload": {"result": '"loaded"'},
            },
            {
                "event_type": "ConditionWaitOpened",
                "payload": {"condition_wait_id": "wait-1", "condition_key": "approval"},
            },
            _signal_received_event("approve", ["alice"]),
        ]

        outcome = replay(ActivityThenWaitForApproval, history, [])

        assert len(outcome.commands) == 1
        assert isinstance(outcome.commands[0], CompleteWorkflow)
        assert outcome.commands[0].result == {
            "activity_result": "loaded",
            "approved_by": "alice",
        }
        assert query_state(ActivityThenWaitForApproval, history, [], "state") == {
            "activity_result": "loaded",
            "approved_by": "alice",
        }

    def test_signals_scope_to_the_condition_wait_open_when_they_arrived(self) -> None:
        history = [
            {
                "event_type": "ConditionWaitOpened",
                "payload": {"condition_wait_id": "wait-advance", "condition_key": "advance"},
            },
            _signal_received_event("advance", ["Ada"]),
            {
                "event_type": "ConditionWaitSatisfied",
                "payload": {"condition_wait_id": "wait-advance", "condition_key": "advance"},
            },
            {
                "event_type": "ConditionWaitOpened",
                "payload": {"condition_wait_id": "wait-finish", "condition_key": "finish"},
            },
            _signal_received_event("finish", []),
        ]

        expected = {
            "stage": "completed",
            "name": "Ada",
            "finished": True,
            "events": ["started", "signal:Ada", "advanced:Ada", "signal:finish", "finish"],
        }

        outcome = replay(TwoStageSignalWait, history, [])

        assert len(outcome.commands) == 1
        assert isinstance(outcome.commands[0], CompleteWorkflow)
        assert outcome.commands[0].result == expected
        assert query_state(TwoStageSignalWait, history, [], "state") == expected

    def test_repeated_physical_waits_for_one_logical_condition_replay_all_signals(self) -> None:
        history = [
            {
                "event_type": "ConditionWaitOpened",
                "payload": {"condition_wait_id": "wait-count-3", "condition_key": "done"},
            },
            _signal_received_event("increment", [3]),
            {
                "event_type": "ConditionWaitOpened",
                "payload": {"condition_wait_id": "wait-count-8", "condition_key": "done"},
            },
            _signal_received_event("increment", [5]),
            {
                "event_type": "ConditionWaitOpened",
                "payload": {"condition_wait_id": "wait-finish", "condition_key": "done"},
            },
            _signal_received_event("finish", []),
        ]

        expected = {
            "count": 8,
            "done": True,
            "events": [
                {"signal": "increment", "amount": 3, "count": 3},
                {"signal": "increment", "amount": 5, "count": 8},
                {"signal": "finish", "count": 8},
            ],
        }

        outcome = replay(SignalCounterUntilFinished, history, [])

        assert len(outcome.commands) == 1
        assert isinstance(outcome.commands[0], CompleteWorkflow)
        assert outcome.commands[0].result == expected
        assert query_state(SignalCounterUntilFinished, history, [], "current") == expected

    def test_repeated_physical_waits_keep_query_state_current_before_finish(self) -> None:
        history = [
            {
                "event_type": "ConditionWaitOpened",
                "payload": {"condition_wait_id": "wait-count-3", "condition_key": "done"},
            },
            _signal_received_event("increment", [3]),
            {
                "event_type": "ConditionWaitOpened",
                "payload": {"condition_wait_id": "wait-count-8", "condition_key": "done"},
            },
            _signal_received_event("increment", [5]),
        ]

        outcome = replay(SignalCounterUntilFinished, history, [])

        assert len(outcome.commands) == 1
        assert isinstance(outcome.commands[0], WaitCondition)
        assert query_state(SignalCounterUntilFinished, history, [], "current") == {
            "count": 8,
            "done": False,
            "events": [
                {"signal": "increment", "amount": 3, "count": 3},
                {"signal": "increment", "amount": 5, "count": 8},
            ],
        }

    def test_signal_received_before_next_wait_uses_declared_workflow_sequence(self) -> None:
        history = [
            {
                "event_type": "ConditionWaitOpened",
                "payload": {
                    "condition_wait_id": "wait-count-3",
                    "condition_key": "done",
                    "sequence": 1,
                },
            },
            _signal_received_event("increment", [3], workflow_sequence=1),
            _signal_received_event("finish", [], workflow_sequence=2),
            {
                "event_type": "ConditionWaitOpened",
                "payload": {
                    "condition_wait_id": "wait-finish",
                    "condition_key": "done",
                    "sequence": 2,
                },
            },
            {
                "event_type": "ConditionWaitSatisfied",
                "payload": {
                    "condition_wait_id": "wait-finish",
                    "condition_key": "done",
                    "sequence": 2,
                },
            },
        ]

        expected = {
            "count": 3,
            "done": True,
            "events": [
                {"signal": "increment", "amount": 3, "count": 3},
                {"signal": "finish", "count": 3},
            ],
        }

        outcome = replay(SignalCounterUntilFinished, history, [])

        assert len(outcome.commands) == 1
        assert isinstance(outcome.commands[0], CompleteWorkflow)
        assert outcome.commands[0].result == expected
        assert query_state(SignalCounterUntilFinished, history, [], "current") == expected

    def test_signal_received_before_reopened_wait_uses_next_wait_when_sequence_absent(self) -> None:
        history = [
            {
                "event_type": "ConditionWaitOpened",
                "payload": {
                    "condition_wait_id": "wait-count-3",
                    "condition_key": "done",
                    "sequence": 21,
                },
            },
            _signal_received_event("increment", [3]),
            _signal_received_event("finish", []),
            {
                "event_type": "ConditionWaitOpened",
                "payload": {
                    "condition_wait_id": "wait-finish",
                    "condition_key": "done",
                    "sequence": 22,
                    "timeout_seconds": 30,
                },
            },
            {
                "event_type": "TimerScheduled",
                "payload": {
                    "timer_kind": "condition_timeout",
                    "condition_wait_id": "wait-finish",
                    "condition_key": "done",
                    "sequence": 22,
                    "delay_seconds": 30,
                },
            },
        ]

        expected = {
            "count": 3,
            "done": True,
            "events": [
                {"signal": "increment", "amount": 3, "count": 3},
                {"signal": "finish", "count": 3},
            ],
        }

        outcome = replay(SignalCounterUntilFinished, history, [])

        assert len(outcome.commands) == 1
        assert isinstance(outcome.commands[0], CompleteWorkflow)
        assert outcome.commands[0].result == expected
        assert query_state(SignalCounterUntilFinished, history, [], "current") == expected

    def test_repeated_wait_after_activity_can_be_satisfied_by_later_signal(self) -> None:
        history = [
            {
                "event_type": "ActivityCompleted",
                "payload": {"result": '"loaded"'},
            },
            {
                "event_type": "ConditionWaitOpened",
                "payload": {"condition_wait_id": "wait-before-query", "condition_key": "approval"},
            },
            {
                "event_type": "ConditionWaitOpened",
                "payload": {"condition_wait_id": "wait-after-query", "condition_key": "approval"},
            },
            _signal_received_event("approve", ["alice"]),
        ]

        outcome = replay(ActivityThenWaitForApproval, history, [])

        assert len(outcome.commands) == 1
        assert isinstance(outcome.commands[0], CompleteWorkflow)
        assert outcome.commands[0].result == {
            "activity_result": "loaded",
            "approved_by": "alice",
        }
        assert query_state(ActivityThenWaitForApproval, history, [], "state") == {
            "activity_result": "loaded",
            "approved_by": "alice",
        }

    def test_open_with_no_resolution_and_predicate_false_re_emits_wait_condition(self) -> None:
        history = [
            {
                "event_type": "ConditionWaitOpened",
                "payload": {"condition_wait_id": "wait-1", "condition_key": "approved"},
            },
        ]

        outcome = replay(WaitUntilApproved, history, [])

        assert len(outcome.commands) == 1
        assert isinstance(outcome.commands[0], WaitCondition)

    def test_replay_rejects_changed_condition_key(self) -> None:
        history = [
            {
                "event_type": "ConditionWaitOpened",
                "payload": {"condition_wait_id": "wait-1", "condition_key": "old-key"},
            },
        ]

        outcome = replay(WaitUntilApproved, history, [])

        assert len(outcome.commands) == 1
        assert not isinstance(outcome.commands[0], CompleteWorkflow)
        cmd = outcome.commands[0]
        assert isinstance(cmd, FailWorkflow)
        assert cmd.exception_type == "NonDeterministicWaitCondition"
        assert "key changed" in cmd.message

    def test_replay_rejects_changed_condition_fingerprint(self) -> None:
        initial = replay(WaitUntilApproved, [], [])
        assert isinstance(initial.commands[0], WaitCondition)
        fingerprint = initial.commands[0].condition_definition_fingerprint
        assert fingerprint is not None
        history = [
            {
                "event_type": "ConditionWaitOpened",
                "payload": {
                    "condition_wait_id": "wait-1",
                    "condition_key": "approved",
                    "condition_definition_fingerprint": "sha256:different",
                },
            },
        ]

        outcome = replay(WaitUntilApproved, history, [])

        assert len(outcome.commands) == 1
        cmd = outcome.commands[0]
        assert isinstance(cmd, FailWorkflow)
        assert cmd.exception_type == "NonDeterministicWaitCondition"
        assert "predicate fingerprint changed" in cmd.message
        assert fingerprint in cmd.message

    def test_replay_accepts_matching_condition_fingerprint(self) -> None:
        initial = replay(WaitUntilApproved, [], [])
        assert isinstance(initial.commands[0], WaitCondition)
        fingerprint = initial.commands[0].condition_definition_fingerprint
        history = [
            {
                "event_type": "ConditionWaitOpened",
                "payload": {
                    "condition_wait_id": "wait-1",
                    "condition_key": "approved",
                    "condition_definition_fingerprint": fingerprint,
                },
            },
            _signal_received_event("approve", []),
        ]

        outcome = replay(WaitUntilApproved, history, [])

        assert len(outcome.commands) == 1
        assert isinstance(outcome.commands[0], CompleteWorkflow)
        assert outcome.commands[0].result == "approved"

    def test_condition_timeout_does_not_pollute_start_timer_resolved_results(self) -> None:
        @workflow.defn(name="wait-then-sleep")
        class WaitThenSleep:
            def __init__(self) -> None:
                self.approved = False

            @workflow.signal("approve")
            def on_approve(self) -> None:
                self.approved = True

            def run(self, ctx: WorkflowContext):  # type: ignore[no-untyped-def]
                yield ctx.wait_condition(lambda: self.approved, timeout=10)
                yield ctx.sleep(60)
                return "done"

        history = [
            {
                "event_type": "ConditionWaitOpened",
                "payload": {"condition_wait_id": "wait-1"},
            },
            {
                "event_type": "TimerFired",
                "payload": {
                    "timer_kind": "condition_timeout",
                    "condition_wait_id": "wait-1",
                },
            },
        ]

        outcome = replay(WaitThenSleep, history, [])

        # condition_timeout should not satisfy ctx.sleep — that would advance
        # the workflow past the sleep too. We expect to land at the sleep yield.
        assert len(outcome.commands) == 1
        from durable_workflow.workflow import StartTimer
        assert isinstance(outcome.commands[0], StartTimer)
        assert outcome.commands[0].delay_seconds == 60
