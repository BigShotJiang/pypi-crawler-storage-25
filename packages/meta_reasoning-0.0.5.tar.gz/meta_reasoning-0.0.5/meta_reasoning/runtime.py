"""
Reasoning Runtime — first-class reasoning as a computational process.

The runtime does for reasoning what the JVM does for Java:
separates the language from the control of execution.

Reasoning is no longer text that flows — it is a process with:
- Explicit states and typed transitions
- Forking as a native primitive
- Budget as a consumable resource
- Typed failures per state
- Full debuggability (breakpoints, replay, inspection)

The LLM does not choose to reflect. The runtime forces it.
"""

from __future__ import annotations

import copy
import json
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable

from .controller import CognitiveController
from .engine import CycleResult
from .ledger import EpistemicLedger
from .metrics import compute_metrics
from .mutations import generate_mutations
from .plugins import PluginRegistry
from .substrate import LLMBackend, Substrate
from .types import (
    CognitiveMetrics,
    CognitiveMove,
    LedgerEntry,
    Mutation,
    MutationType,
    StructuredOutput,
)


# ---------------------------------------------------------------------------
# Cognitive States
# ---------------------------------------------------------------------------

class CognitiveState(str, Enum):
    """Explicit states of the reasoning process.
    The model does not 'choose' to reflect. The runtime forces it."""
    INITIAL = "initial"
    ANALYSIS = "analysis"
    HYPOTHESIS = "hypothesis"
    VALIDATION = "validation"
    REFLECTION = "reflection"
    FINAL = "final"
    FAILED = "failed"
    BUDGET_EXHAUSTED = "budget_exhausted"


# ---------------------------------------------------------------------------
# Typed Failures
# ---------------------------------------------------------------------------

class FailureType(str, Enum):
    CONSTRAINT_VIOLATION = "constraint_violation"
    COGNITIVE_STALL = "cognitive_stall"
    BUDGET_EXCEEDED = "budget_exceeded"
    INVALID_TRANSITION = "invalid_transition"
    CONTRADICTION_DETECTED = "contradiction_detected"
    MAX_DEPTH_REACHED = "max_depth_reached"


@dataclass
class RuntimeFailure:
    """A typed, inspectable failure — not an exception, a first-class result."""
    type: FailureType
    state: CognitiveState
    message: str
    cycle: int
    metrics: CognitiveMetrics | None = None


# ---------------------------------------------------------------------------
# Budget
# ---------------------------------------------------------------------------

@dataclass
class ReasoningBudget:
    """Reasoning as a consumable resource. The runtime can say:
    'This task does not deserve more reasoning.' And stop."""
    max_tokens: int = 50000
    max_branches: int = 4
    max_depth: int = 10
    max_cycles: int = 8
    tokens_used: int = 0
    branches_used: int = 0
    depth_used: int = 0
    cycles_used: int = 0

    @property
    def exhausted(self) -> bool:
        return (
            self.tokens_used >= self.max_tokens
            or self.branches_used >= self.max_branches
            or self.depth_used >= self.max_depth
            or self.cycles_used >= self.max_cycles
        )

    def consume_cycle(self, token_estimate: int = 500) -> None:
        self.cycles_used += 1
        self.tokens_used += token_estimate
        self.depth_used += 1

    def consume_branch(self) -> None:
        self.branches_used += 1

    @property
    def remaining(self) -> dict[str, int]:
        return {
            "tokens": max(0, self.max_tokens - self.tokens_used),
            "branches": max(0, self.max_branches - self.branches_used),
            "depth": max(0, self.max_depth - self.depth_used),
            "cycles": max(0, self.max_cycles - self.cycles_used),
        }

    def summary(self) -> str:
        return (
            f"Budget: {self.cycles_used}/{self.max_cycles} cycles, "
            f"{self.branches_used}/{self.max_branches} branches, "
            f"{self.tokens_used}/{self.max_tokens} tokens"
        )


# ---------------------------------------------------------------------------
# Transition Rules
# ---------------------------------------------------------------------------

# Default allowed transitions. The runtime enforces these — the model cannot bypass them.
DEFAULT_TRANSITIONS: dict[CognitiveState, list[CognitiveState]] = {
    CognitiveState.INITIAL: [CognitiveState.ANALYSIS],
    CognitiveState.ANALYSIS: [CognitiveState.HYPOTHESIS, CognitiveState.REFLECTION, CognitiveState.FAILED],
    CognitiveState.HYPOTHESIS: [CognitiveState.VALIDATION, CognitiveState.REFLECTION, CognitiveState.FAILED],
    CognitiveState.VALIDATION: [CognitiveState.REFLECTION, CognitiveState.FINAL, CognitiveState.FAILED],
    CognitiveState.REFLECTION: [CognitiveState.ANALYSIS, CognitiveState.HYPOTHESIS, CognitiveState.FINAL, CognitiveState.FAILED],
    CognitiveState.FINAL: [],
    CognitiveState.FAILED: [],
    CognitiveState.BUDGET_EXHAUSTED: [],
}

# State-specific prompt instructions
STATE_INSTRUCTIONS: dict[CognitiveState, str] = {
    CognitiveState.ANALYSIS: "Analyze the problem. Decompose it. Identify key dimensions. Do NOT propose solutions yet.",
    CognitiveState.HYPOTHESIS: "Propose one or more hypotheses based on your analysis. Be explicit about assumptions.",
    CognitiveState.VALIDATION: "Validate your hypotheses. Look for evidence, counterexamples, and edge cases.",
    CognitiveState.REFLECTION: "Reflect on the reasoning so far. What was missed? What assumptions are fragile? What would change the conclusion?",
    CognitiveState.FINAL: "Synthesize your final answer. Be explicit about confidence and remaining uncertainties.",
}


# ---------------------------------------------------------------------------
# Transition Policy — metrics-driven, not text-driven
# ---------------------------------------------------------------------------

TransitionFn = Callable[[CognitiveState, CognitiveMetrics, ReasoningBudget], CognitiveState]


def default_transition_policy(
    current: CognitiveState,
    metrics: CognitiveMetrics,
    budget: ReasoningBudget,
) -> CognitiveState:
    """Decide the next state based on metrics, not text content."""
    if budget.exhausted:
        return CognitiveState.BUDGET_EXHAUSTED

    if metrics.constraint_violations > 2:
        return CognitiveState.FAILED

    match current:
        case CognitiveState.INITIAL:
            return CognitiveState.ANALYSIS

        case CognitiveState.ANALYSIS:
            if metrics.premature_closure > 0.7:
                return CognitiveState.REFLECTION  # too shallow, force reflection
            return CognitiveState.HYPOTHESIS

        case CognitiveState.HYPOTHESIS:
            if metrics.entropy < 1.0:
                return CognitiveState.REFLECTION  # too narrow, force reflection
            return CognitiveState.VALIDATION

        case CognitiveState.VALIDATION:
            if metrics.strategy_repetition > 0.5:
                return CognitiveState.REFLECTION  # stalling, force reflection
            if metrics.premature_closure < 0.4 and metrics.entropy > 1.5:
                return CognitiveState.FINAL  # good enough
            return CognitiveState.REFLECTION

        case CognitiveState.REFLECTION:
            if budget.remaining["cycles"] <= 1:
                return CognitiveState.FINAL  # budget pressure
            if metrics.depth_without_novelty >= 2:
                return CognitiveState.FINAL  # no new ground
            return CognitiveState.HYPOTHESIS  # loop back

        case _:
            return CognitiveState.FAILED


# ---------------------------------------------------------------------------
# State Snapshot — for forking and debugging
# ---------------------------------------------------------------------------

@dataclass
class StateSnapshot:
    """Complete frozen state of the runtime at a point in time.
    Can be cloned for forking."""
    state: CognitiveState
    cycle: int
    output: StructuredOutput | None
    metrics: CognitiveMetrics | None
    mutations: list[Mutation]
    budget: ReasoningBudget
    history: list[dict[str, Any]]

    def clone(self) -> StateSnapshot:
        return StateSnapshot(
            state=self.state,
            cycle=self.cycle,
            output=copy.deepcopy(self.output),
            metrics=copy.deepcopy(self.metrics),
            mutations=copy.deepcopy(self.mutations),
            budget=copy.deepcopy(self.budget),
            history=copy.deepcopy(self.history),
        )


# ---------------------------------------------------------------------------
# Fork Result
# ---------------------------------------------------------------------------

@dataclass
class ForkResult:
    """Result of a cognitive fork — two branches from the same state."""
    branch_id: int
    mutations_applied: list[Mutation]
    result: RuntimeResult


# ---------------------------------------------------------------------------
# Runtime Result
# ---------------------------------------------------------------------------

@dataclass
class RuntimeResult:
    """Complete result of a runtime execution."""
    task: str
    final_state: CognitiveState = CognitiveState.INITIAL
    states_visited: list[CognitiveState] = field(default_factory=list)
    cycles: list[dict[str, Any]] = field(default_factory=list)
    failures: list[RuntimeFailure] = field(default_factory=list)
    budget: ReasoningBudget = field(default_factory=ReasoningBudget)
    forks: list[ForkResult] = field(default_factory=list)

    @property
    def succeeded(self) -> bool:
        return self.final_state == CognitiveState.FINAL

    def summary(self) -> str:
        lines = [
            f"Runtime: {self.task}",
            f"  Final state:    {self.final_state.value}",
            f"  States visited: {' → '.join(s.value for s in self.states_visited)}",
            f"  Cycles:         {len(self.cycles)}",
            f"  Failures:       {len(self.failures)}",
            f"  Forks:          {len(self.forks)}",
            f"  {self.budget.summary()}",
        ]
        return "\n".join(lines)


# ---------------------------------------------------------------------------
# Reasoning Runtime
# ---------------------------------------------------------------------------

class ReasoningRuntime:
    """First-class reasoning runtime.

    The runtime is to reasoning what the JVM is to Java:
    it separates the language from the control of execution.

    The model does not choose states. The runtime forces transitions
    based on structural signals, not text content.
    """

    def __init__(
        self,
        backend: LLMBackend,
        budget: ReasoningBudget | None = None,
        transition_policy: TransitionFn | None = None,
        transitions: dict[CognitiveState, list[CognitiveState]] | None = None,
        policy: object | None = None,
        plugin_registry: PluginRegistry | None = None,
    ) -> None:
        self._substrate = Substrate(backend)
        self._budget = budget or ReasoningBudget()
        self._transition_fn = transition_policy or default_transition_policy
        self._transitions = transitions or DEFAULT_TRANSITIONS
        self._ledger = EpistemicLedger()
        self._controller = CognitiveController(
            ledger=self._ledger,
            policy=policy,
            plugin_registry=plugin_registry,
        )
        self._state = CognitiveState.INITIAL
        self._history: list[dict[str, Any]] = []
        self._snapshots: list[StateSnapshot] = []

    @property
    def state(self) -> CognitiveState:
        return self._state

    @property
    def budget(self) -> ReasoningBudget:
        return self._budget

    @property
    def ledger(self) -> EpistemicLedger:
        return self._ledger

    @property
    def snapshots(self) -> list[StateSnapshot]:
        return list(self._snapshots)

    def run(self, task: str) -> RuntimeResult:
        """Execute the full reasoning process as a state machine."""
        result = RuntimeResult(task=task, budget=self._budget)
        result.states_visited.append(self._state)

        while self._state not in (CognitiveState.FINAL, CognitiveState.FAILED, CognitiveState.BUDGET_EXHAUSTED):
            # Budget check
            if self._budget.exhausted:
                self._state = CognitiveState.BUDGET_EXHAUSTED
                result.failures.append(RuntimeFailure(
                    type=FailureType.BUDGET_EXCEEDED,
                    state=self._state,
                    message=self._budget.summary(),
                    cycle=self._controller.cycle,
                ))
                break

            # Determine next state
            next_state = self._transition_fn(self._state, self._last_metrics(), self._budget)

            # Validate transition
            allowed = self._transitions.get(self._state, [])
            if next_state not in allowed and next_state not in (CognitiveState.FAILED, CognitiveState.BUDGET_EXHAUSTED):
                result.failures.append(RuntimeFailure(
                    type=FailureType.INVALID_TRANSITION,
                    state=self._state,
                    message=f"Transition {self._state.value} → {next_state.value} not allowed",
                    cycle=self._controller.cycle,
                ))
                self._state = CognitiveState.FAILED
                break

            self._state = next_state
            result.states_visited.append(self._state)

            if self._state in (CognitiveState.FINAL, CognitiveState.FAILED, CognitiveState.BUDGET_EXHAUSTED):
                break

            # Execute cycle in current state
            cycle_data = self._execute_cycle(task)
            result.cycles.append(cycle_data)

            if cycle_data.get("failure"):
                result.failures.append(RuntimeFailure(
                    type=FailureType.CONSTRAINT_VIOLATION if cycle_data["metrics"]["constraint_violations"] > 0
                         else FailureType.COGNITIVE_STALL,
                    state=self._state,
                    message=cycle_data.get("failure_reason", ""),
                    cycle=cycle_data["cycle"],
                    metrics=self._last_metrics_obj(),
                ))
                if cycle_data["outcome"] == "failed":
                    self._state = CognitiveState.FAILED
                    break

        result.final_state = self._state
        return result

    def fork(self, task: str, branch_mutations: list[list[Mutation]]) -> list[ForkResult]:
        """Fork the current cognitive state into multiple branches.
        Each branch gets different mutations applied. Deterministic branching."""
        forks = []
        base_snapshot = self._take_snapshot()

        for i, mutations in enumerate(branch_mutations):
            self._budget.consume_branch()
            if self._budget.exhausted:
                break

            # Clone state
            snap = base_snapshot.clone()
            branch_runtime = ReasoningRuntime.__new__(ReasoningRuntime)
            branch_runtime._substrate = self._substrate
            branch_runtime._budget = copy.deepcopy(self._budget)
            branch_runtime._transition_fn = self._transition_fn
            branch_runtime._transitions = self._transitions
            branch_runtime._ledger = EpistemicLedger()
            branch_runtime._controller = CognitiveController(ledger=branch_runtime._ledger)
            branch_runtime._controller._active_mutations = list(mutations)
            branch_runtime._state = snap.state
            branch_runtime._history = copy.deepcopy(snap.history)
            branch_runtime._snapshots = []

            branch_result = branch_runtime.run(task)
            forks.append(ForkResult(branch_id=i, mutations_applied=mutations, result=branch_result))

        return forks

    def snapshot(self) -> StateSnapshot:
        """Take a snapshot of the current state for inspection or forking."""
        return self._take_snapshot()

    def _execute_cycle(self, task: str) -> dict[str, Any]:
        """Execute one cognitive cycle within the current state."""
        mutations = self._controller.get_mutations()
        state_instruction = STATE_INSTRUCTIONS.get(self._state, "")
        augmented_task = f"[STATE: {self._state.value}] {state_instruction}\n\nTask: {task}"

        history_summary = self._ledger.summary_for_prompt()
        output = self._substrate.generate(
            task=augmented_task,
            mutations=mutations,
            history_summary=history_summary or None,
        )

        metrics = self._controller.observe(output)
        outcome = self._controller.decide(output, metrics)
        self._budget.consume_cycle(token_estimate=len(output.content))

        # Save snapshot
        self._snapshots.append(self._take_snapshot())

        cycle_data = {
            "cycle": self._controller.cycle,
            "state": self._state.value,
            "outcome": outcome,
            "content": output.content,
            "moves": [m.value for m in output.reasoning_trace.moves],
            "depth": output.reasoning_trace.depth,
            "metrics": {
                "entropy": round(metrics.entropy, 4),
                "strategy_repetition": round(metrics.strategy_repetition, 4),
                "premature_closure": round(metrics.premature_closure, 4),
                "constraint_violations": metrics.constraint_violations,
                "dominant_move": metrics.dominant_move.value if metrics.dominant_move else None,
            },
            "mutations_applied": [m.to_prompt_constraint() for m in mutations],
            "budget_remaining": self._budget.remaining,
            "failure": outcome == "failed",
            "failure_reason": None,
        }

        if outcome == "failed":
            entry = self._ledger.entries[-1]
            cycle_data["failure_reason"] = entry.failure_reason

        self._history.append(cycle_data)
        return cycle_data

    def _take_snapshot(self) -> StateSnapshot:
        last_entry = self._ledger.entries[-1] if self._ledger.entries else None
        return StateSnapshot(
            state=self._state,
            cycle=self._controller.cycle,
            output=StructuredOutput(
                content=last_entry.trace.moves[0].value if last_entry else "",
                reasoning_trace=last_entry.trace if last_entry else None,
            ) if last_entry else None,
            metrics=last_entry.metrics if last_entry else None,
            mutations=self._controller.get_mutations(),
            budget=copy.deepcopy(self._budget),
            history=copy.deepcopy(self._history),
        )

    def _last_metrics(self) -> CognitiveMetrics:
        if self._ledger.entries:
            return self._ledger.entries[-1].metrics
        return CognitiveMetrics(
            entropy=0.0, strategy_repetition=0.0, depth_without_novelty=0,
            constraint_violations=0, premature_closure=1.0, dominant_move=None,
        )

    def _last_metrics_obj(self) -> CognitiveMetrics:
        return self._last_metrics()
