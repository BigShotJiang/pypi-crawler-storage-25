"""
Meta-Reasoning SDK

Reasoning is not a property of the model —
it is an emergent dynamic of external control.
"""

from .controller import CognitiveController
from .engine import CognitiveEngine, CycleResult, EngineResult
from .ledger import EpistemicLedger, FailureAtlas
from .metrics import compute_metrics
from .mutations import generate_mutations
from .substrate import LLMBackend, Substrate
from .types import (
    CognitiveMetrics,
    CognitiveMove,
    LedgerEntry,
    Mutation,
    MutationType,
    ReasoningTrace,
    StructuredOutput,
)

# Feature 1: Reasoning Debugger
from .debugger import ReasoningDebugger, DebugSnapshot, BreakpointFn

# Feature 2: Reasoning Policies
from .policies import ReasoningPolicy, PolicyRule, strict_diversity_policy, adversarial_policy

# Feature 3 & 4: Benchmarking & Fingerprinting
from .benchmark import (
    CognitiveFingerprint,
    BenchmarkResult,
    benchmark_models,
    fingerprint_from_result,
)

# Feature 6: Deterministic Replay
from .replay import ReplaySession, record_session

# Feature 7: Anti-Hallucination
from .hallucination import HallucinationRisk, assess_hallucination_risk

# Feature 8: Mutation Plugins
from .plugins import PluginRegistry, MutationPlugin, MetricPlugin, get_default_registry

# Feature 9: CI/CD for Reasoning
from .ci import (
    CognitiveCI,
    CIReport,
    CognitiveAssertionSpec,
    assert_min_entropy,
    assert_max_stall_rate,
    assert_max_closure,
    assert_no_total_stall,
    assert_min_move_diversity,
)

# Feature 10: Reasoning Runtime
from .runtime import (
    ReasoningRuntime,
    RuntimeResult,
    RuntimeFailure,
    CognitiveState,
    FailureType,
    ReasoningBudget,
    StateSnapshot,
    ForkResult,
    DEFAULT_TRANSITIONS,
    default_transition_policy,
)

__all__ = [
    # Core
    "CognitiveController",
    "CognitiveEngine",
    "CognitiveMetrics",
    "CognitiveMove",
    "CycleResult",
    "EngineResult",
    "EpistemicLedger",
    "LedgerEntry",
    "LLMBackend",
    "Mutation",
    "MutationType",
    "ReasoningTrace",
    "StructuredOutput",
    "Substrate",
    "compute_metrics",
    "generate_mutations",
    # Feature 1: Debugger
    "ReasoningDebugger",
    "DebugSnapshot",
    "BreakpointFn",
    # Feature 2: Policies
    "ReasoningPolicy",
    "PolicyRule",
    "strict_diversity_policy",
    "adversarial_policy",
    # Feature 3 & 4: Benchmark & Fingerprint
    "CognitiveFingerprint",
    "BenchmarkResult",
    "benchmark_models",
    "fingerprint_from_result",
    # Feature 5: Failure Atlas
    "FailureAtlas",
    # Feature 6: Replay
    "ReplaySession",
    "record_session",
    # Feature 7: Anti-Hallucination
    "HallucinationRisk",
    "assess_hallucination_risk",
    # Feature 8: Plugins
    "PluginRegistry",
    "MutationPlugin",
    "MetricPlugin",
    "get_default_registry",
    # Feature 9: CI/CD
    "CognitiveCI",
    "CIReport",
    "CognitiveAssertionSpec",
    "assert_min_entropy",
    "assert_max_stall_rate",
    "assert_max_closure",
    "assert_no_total_stall",
    "assert_min_move_diversity",
    # Feature 10: Runtime
    "ReasoningRuntime",
    "RuntimeResult",
    "RuntimeFailure",
    "CognitiveState",
    "FailureType",
    "ReasoningBudget",
    "StateSnapshot",
    "ForkResult",
    "DEFAULT_TRANSITIONS",
    "default_transition_policy",
]
