"""
REST endpoint for the Depth Estimation feature.

Registers ``POST /lifting/depth-estimation`` on the ``lifting_router`` exported
from this module.  Import the router in ``app.py`` and call
``app.include_router(lifting_router)``.
"""

import orjson
from fastapi import APIRouter, File, Form, UploadFile
from fastapi.responses import Response

from vizion3d.lifting import DepthEstimation, DepthEstimationCommand
from vizion3d.lifting.defaults import DEFAULT_DEPTH_MODEL_URL
from vizion3d.lifting.models import DepthEstimationAdvanceConfig

from .serialisation import (
    b64,
    o3d_depth_image_to_png_bytes,
    o3d_point_cloud_to_ply_bytes,
)

router = APIRouter()

# Set by configure_model() at server startup when --depth_model is passed on the CLI.
_model_override: str | None = None


def configure_model(path: str) -> None:
    """Set a server-wide default model path and pre-load it into handler memory.

    Called from ``app.run()`` when ``--depth_model`` is supplied on the command line.
    After this call the endpoint uses *path* whenever the caller omits
    ``model_backend`` from the form data.
    """
    global _model_override
    _model_override = path
    from vizion3d.lifting.handlers import DepthEstimationHandler

    DepthEstimationHandler.preload(path)


@router.post("/depth-estimation")
async def depth_estimation(
    image: UploadFile = File(...),
    model_backend: str | None = Form(None),
    return_depth_image: bool = Form(False),
    return_point_cloud: bool = Form(False),
    fx: float | None = Form(None),
    fy: float | None = Form(None),
    cx: float | None = Form(None),
    cy: float | None = Form(None),
):
    """Run monocular depth estimation on a single uploaded image.

    Args:
        image: The image file (any PIL-supported format).
        model_backend: Checkpoint URL or local path (defaults to the vizion3D release).
        return_depth_image: Include a base64-encoded 16-bit PNG depth image.
        return_point_cloud: Include a base64-encoded binary PLY point cloud.
        fx, fy, cx, cy: Camera intrinsics (auto-derived from image dimensions if omitted).

    Returns:
        JSON with ``depth_map``, ``min_depth``, ``max_depth``, ``backend_used``,
        and optional ``depth_image``, ``point_cloud_ply`` (base64).
    """
    image_bytes = await image.read()
    effective_backend = model_backend or _model_override or DEFAULT_DEPTH_MODEL_URL
    advanced_config = DepthEstimationAdvanceConfig(fx=fx, fy=fy, cx=cx, cy=cy)
    cmd = DepthEstimationCommand(
        image_input=image_bytes,
        model_backend=effective_backend,
        return_depth_image=return_depth_image,
        return_point_cloud=return_point_cloud,
        advanced_config=advanced_config,
    )
    result = DepthEstimation().run(cmd)
    payload = {
        "depth_map": result.depth_map,
        "min_depth": result.min_depth,
        "max_depth": result.max_depth,
        "backend_used": result.backend_used,
        "depth_image": b64(
            o3d_depth_image_to_png_bytes(result.depth_image)
            if result.depth_image is not None
            else None
        ),
        "point_cloud_ply": b64(
            o3d_point_cloud_to_ply_bytes(result.point_cloud)
            if result.point_cloud is not None
            else None
        ),
    }
    return Response(content=orjson.dumps(payload), media_type="application/json")
