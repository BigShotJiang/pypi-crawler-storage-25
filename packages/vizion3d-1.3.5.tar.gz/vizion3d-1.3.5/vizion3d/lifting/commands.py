from dataclasses import dataclass, field

from vizion3d.core.cqrs import Command

from .defaults import DEFAULT_DEPTH_MODEL_URL
from .models import DepthEstimationAdvanceConfig, DepthEstimationResult


@dataclass
class DepthEstimationCommand(Command[DepthEstimationResult]):
    """
    Command payload to trigger a depth estimation inference task.

    Attributes:
        image_input: The input image. Pass a file-path string or raw image bytes.
            The handler auto-detects which form is supplied.
        model_backend: Depth Anything V2 checkpoint URL or local path.  Defaults
            to the vizion3D release checkpoint (`depth_anything_v2_vitb.pth`),
            downloaded on first use and cached under `~/.cache/vizion3d/models/`.
            Set `VIZION3D_MODEL_CACHE` to override the cache directory.

        return_depth_image: When `True`, the result includes a 16-bit grayscale
            `open3d.geometry.Image` (dtype `uint16`).  Depth Anything V2 outputs
            inverse relative depth (higher = closer), so higher uint16 values
            correspond to closer pixels — closer = brighter.
            Requires Open3D (Python 3.12).
        return_raw_depth: When `True`, the result includes the raw depth array
            as a float32 numpy array of shape `(H, W)`.  Values are relative
            (not metric) for monocular depth — unmodified output from the model.
        return_point_cloud: When `True`, the result includes an
            `open3d.geometry.PointCloud` unprojected from the RGB-D image using
            the camera intrinsics in `advanced_config`. Point coordinates are in metres.
            Requires Open3D (Python 3.12).
        advanced_config: Camera intrinsics for point cloud unprojection. All fields
            auto-derive from image dimensions when left as ``None`` — only supply
            values for a real calibrated camera, e.g.
            ``advanced_config=DepthEstimationAdvanceConfig(fx=615.0, fy=615.0)``.
    """

    image_input: str | bytes
    model_backend: str = DEFAULT_DEPTH_MODEL_URL
    return_depth_image: bool = True
    return_raw_depth: bool = True
    return_point_cloud: bool = False
    advanced_config: DepthEstimationAdvanceConfig = field(
        default_factory=DepthEstimationAdvanceConfig
    )
