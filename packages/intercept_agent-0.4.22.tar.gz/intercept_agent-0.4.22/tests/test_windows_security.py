"""Tests for the C7 Windows security posture provider.

Runs on macOS / Linux CI by patching ``posture_agent.platforms.windows.run_ps``
(the import-site lookup) and the lazily imported ``winreg`` for SmartScreen.
The implementation degrades gracefully on every error path; these tests
cover each branch (success, permission denied, missing cmdlet, query failure,
empty response, registry unavailable).
"""

from __future__ import annotations

import sys
import types
from unittest.mock import MagicMock, patch

from posture_agent.platforms import windows
from posture_agent.platforms.powershell import PSError, PSResult


def _ok(data: object) -> PSResult:
    return PSResult(ok=True, data=data, error=None, stderr="", duration_ms=42)


def _err(kind: str, message: str = "boom") -> PSResult:
    return PSResult(
        ok=False,
        data=None,
        error=PSError(kind=kind, message=message),
        stderr=message,
        duration_ms=42,
    )


# ---------------------------------------------------------------------------
# disk_encryption
# ---------------------------------------------------------------------------


class TestDiskEncryption:
    async def test_disk_encryption_on(self):
        payload = {
            "MountPoint": "C:",
            "ProtectionStatus": 1,
            "VolumeStatus": "FullyEncrypted",
        }
        with patch(
            "posture_agent.platforms.windows.run_ps",
            return_value=_ok(payload),
        ):
            result = await windows.WindowsSecurityPosture().disk_encryption()

        assert result.enabled is True
        assert result.state == "on"
        assert result.product == "BitLocker"
        assert result.reason is None

    async def test_disk_encryption_off(self):
        payload = {
            "MountPoint": "C:",
            "ProtectionStatus": 0,
            "VolumeStatus": "FullyDecrypted",
        }
        with patch(
            "posture_agent.platforms.windows.run_ps",
            return_value=_ok(payload),
        ):
            result = await windows.WindowsSecurityPosture().disk_encryption()

        assert result.enabled is False
        assert result.state == "off"
        assert result.product == "BitLocker"

    async def test_disk_encryption_permission_denied(self):
        with patch(
            "posture_agent.platforms.windows.run_ps",
            return_value=_err("permission_denied", "Access is denied"),
        ):
            result = await windows.WindowsSecurityPosture().disk_encryption()

        assert result.enabled is None
        assert result.state == "unknown"
        assert result.product == "BitLocker"
        assert result.reason == "insufficient_privilege"

    async def test_disk_encryption_bitlocker_unavailable(self):
        # ``Get-BitLockerVolume`` is missing on Windows Home / older builds.
        with patch(
            "posture_agent.platforms.windows.run_ps",
            return_value=_err("cmdlet_not_found", "not recognized"),
        ):
            result = await windows.WindowsSecurityPosture().disk_encryption()

        assert result.enabled is None
        assert result.state == "unsupported"
        assert result.product == "BitLocker"
        assert result.reason == "bitlocker_unavailable"

    async def test_disk_encryption_query_failed(self):
        # Generic ``exit_nonzero`` (or timeout, parse_error, etc.) maps to
        # ``query_failed`` so callers get a stable, non-product-specific reason.
        with patch(
            "posture_agent.platforms.windows.run_ps",
            return_value=_err("exit_nonzero", "exit=2"),
        ):
            result = await windows.WindowsSecurityPosture().disk_encryption()

        assert result.enabled is None
        assert result.state == "unknown"
        assert result.product == "BitLocker"
        assert result.reason == "query_failed"

    async def test_disk_encryption_no_volume_returns_off(self):
        # Empty pipeline (``data=None``) means the system drive has no
        # BitLocker volume entry — treat as decrypted, not unknown.
        with patch(
            "posture_agent.platforms.windows.run_ps",
            return_value=_ok(None),
        ):
            result = await windows.WindowsSecurityPosture().disk_encryption()

        assert result.enabled is False
        assert result.state == "off"
        assert result.product == "BitLocker"


# ---------------------------------------------------------------------------
# firewall
# ---------------------------------------------------------------------------


class TestFirewall:
    async def test_firewall_all_enabled(self):
        payload = [
            {"Name": "Domain", "Enabled": True},
            {"Name": "Private", "Enabled": True},
            {"Name": "Public", "Enabled": True},
        ]
        with patch(
            "posture_agent.platforms.windows.run_ps",
            return_value=_ok(payload),
        ):
            result = await windows.WindowsSecurityPosture().firewall()

        assert result.enabled is True
        assert result.product == "Windows Defender Firewall"
        assert result.reason is None

    async def test_firewall_one_disabled(self):
        # ``enabled=True`` only when ALL profiles are enabled. A single
        # disabled profile means traffic on that network type is unfiltered.
        payload = [
            {"Name": "Domain", "Enabled": True},
            {"Name": "Private", "Enabled": True},
            {"Name": "Public", "Enabled": False},
        ]
        with patch(
            "posture_agent.platforms.windows.run_ps",
            return_value=_ok(payload),
        ):
            result = await windows.WindowsSecurityPosture().firewall()

        assert result.enabled is False
        assert result.product == "Windows Defender Firewall"

    async def test_firewall_single_profile_dict(self):
        # ``ConvertTo-Json`` collapses single objects to a dict instead of a
        # list — the impl must normalize before iterating.
        payload = {"Name": "Domain", "Enabled": True}
        with patch(
            "posture_agent.platforms.windows.run_ps",
            return_value=_ok(payload),
        ):
            result = await windows.WindowsSecurityPosture().firewall()

        assert result.enabled is True
        assert result.product == "Windows Defender Firewall"

    async def test_firewall_permission_denied(self):
        with patch(
            "posture_agent.platforms.windows.run_ps",
            return_value=_err("permission_denied", "Access is denied"),
        ):
            result = await windows.WindowsSecurityPosture().firewall()

        assert result.enabled is None
        assert result.product == "Windows Defender Firewall"
        assert result.reason == "insufficient_privilege"

    async def test_firewall_empty_response(self):
        with patch(
            "posture_agent.platforms.windows.run_ps",
            return_value=_ok(None),
        ):
            result = await windows.WindowsSecurityPosture().firewall()

        assert result.enabled is None
        assert result.product == "Windows Defender Firewall"
        assert result.reason == "empty_response"

    async def test_firewall_query_failed(self):
        # Generic failure (exit != 0, timeout, parse_error) maps to
        # ``query_failed`` — keeps the reason stable for downstream consumers.
        with patch(
            "posture_agent.platforms.windows.run_ps",
            return_value=_err("exit_nonzero", "exit=2"),
        ):
            result = await windows.WindowsSecurityPosture().firewall()

        assert result.enabled is None
        assert result.product == "Windows Defender Firewall"
        assert result.reason == "query_failed"


# ---------------------------------------------------------------------------
# app_signing (SmartScreen)
# ---------------------------------------------------------------------------


def _install_fake_winreg(
    *,
    open_key: object,
    query_value_ex: object,
) -> types.ModuleType:
    """Build a fake ``winreg`` module and install it under ``sys.modules``.

    Mirrors the helper used by ``test_windows_hardware.py`` — the lazy
    ``import winreg`` inside :meth:`_read_smartscreen_state` resolves against
    ``sys.modules['winreg']`` first.
    """
    fake = types.ModuleType("winreg")
    fake.HKEY_LOCAL_MACHINE = 0  # type: ignore[attr-defined]
    fake.KEY_READ = 0x20019  # type: ignore[attr-defined]
    fake.KEY_WOW64_64KEY = 0x0100  # type: ignore[attr-defined]
    fake.OpenKey = open_key  # type: ignore[attr-defined]
    fake.QueryValueEx = query_value_ex  # type: ignore[attr-defined]
    sys.modules["winreg"] = fake
    return fake


def _winreg_context_manager(value: object):
    cm = MagicMock()
    cm.__enter__ = MagicMock(return_value=value)
    cm.__exit__ = MagicMock(return_value=False)
    return cm


class TestAppSigning:
    async def test_app_signing_smartscreen_enforced(self):
        with patch.object(
            windows.WindowsSecurityPosture,
            "_read_smartscreen_state",
            return_value=True,
        ):
            result = await windows.WindowsSecurityPosture().app_signing()

        assert result.enforced is True
        assert result.state == "enforced"
        assert result.product == "SmartScreen"
        assert result.reason is None

    async def test_app_signing_smartscreen_disabled(self):
        with patch.object(
            windows.WindowsSecurityPosture,
            "_read_smartscreen_state",
            return_value=False,
        ):
            result = await windows.WindowsSecurityPosture().app_signing()

        assert result.enforced is False
        assert result.state == "disabled"
        assert result.product == "SmartScreen"

    async def test_app_signing_registry_unavailable(self):
        with patch.object(
            windows.WindowsSecurityPosture,
            "_read_smartscreen_state",
            return_value=None,
        ):
            result = await windows.WindowsSecurityPosture().app_signing()

        assert result.enforced is None
        assert result.state == "unknown"
        assert result.product == "SmartScreen"
        assert result.reason == "registry_unavailable"


# ---------------------------------------------------------------------------
# _read_smartscreen_state — direct registry-level coverage
# ---------------------------------------------------------------------------


class TestReadSmartscreenState:
    def teardown_method(self):
        sys.modules.pop("winreg", None)

    def test_smartscreen_state_off_when_value_off(self):
        key_handle = object()
        open_key = MagicMock(return_value=_winreg_context_manager(key_handle))
        query_value_ex = MagicMock(return_value=("Off", 1))
        _install_fake_winreg(open_key=open_key, query_value_ex=query_value_ex)

        with patch(
            "posture_agent.platforms.windows.platform.system",
            return_value="Windows",
        ):
            result = windows.WindowsSecurityPosture()._read_smartscreen_state()

        assert result is False
        query_value_ex.assert_called_once_with(key_handle, "SmartScreenEnabled")

    def test_smartscreen_state_default_true_when_value_missing(self):
        # Missing value defaults to enabled — SmartScreen ships on by default,
        # only an explicit "Off" disables it.
        key_handle = object()
        open_key = MagicMock(return_value=_winreg_context_manager(key_handle))
        query_value_ex = MagicMock(side_effect=FileNotFoundError("no such value"))
        _install_fake_winreg(open_key=open_key, query_value_ex=query_value_ex)

        with patch(
            "posture_agent.platforms.windows.platform.system",
            return_value="Windows",
        ):
            result = windows.WindowsSecurityPosture()._read_smartscreen_state()

        assert result is True

    def test_smartscreen_state_warn_returns_true(self):
        # Policy values "Warn" / "Block" leave SmartScreen enforced.
        key_handle = object()
        open_key = MagicMock(return_value=_winreg_context_manager(key_handle))
        query_value_ex = MagicMock(return_value=("Warn", 1))
        _install_fake_winreg(open_key=open_key, query_value_ex=query_value_ex)

        with patch(
            "posture_agent.platforms.windows.platform.system",
            return_value="Windows",
        ):
            result = windows.WindowsSecurityPosture()._read_smartscreen_state()

        assert result is True

    def test_smartscreen_state_returns_none_on_oserror(self):
        # Registry key entirely unreachable — caller surfaces
        # ``reason="registry_unavailable"``.
        open_key = MagicMock(side_effect=OSError("denied"))
        _install_fake_winreg(open_key=open_key, query_value_ex=MagicMock())

        with patch(
            "posture_agent.platforms.windows.platform.system",
            return_value="Windows",
        ):
            result = windows.WindowsSecurityPosture()._read_smartscreen_state()

        assert result is None

    def test_smartscreen_state_returns_none_on_non_windows(self):
        # No fake winreg installed — if the impl forgets the platform guard
        # the lazy ``import winreg`` raises ModuleNotFoundError on macOS.
        with patch(
            "posture_agent.platforms.windows.platform.system",
            return_value="Darwin",
        ):
            result = windows.WindowsSecurityPosture()._read_smartscreen_state()

        assert result is None
