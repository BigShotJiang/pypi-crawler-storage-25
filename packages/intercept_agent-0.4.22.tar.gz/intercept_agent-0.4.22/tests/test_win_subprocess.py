"""Tests for the Windows console-window suppression helper.

The helper is invoked from every subprocess call site in the agent so that
scheduled runs on Windows do not flash visible console windows (powershell.exe,
schtasks.exe, cmd.exe shims for npm/gcloud/az, the pip/uv upgrader, etc.). These
tests pin the cross-platform contract:

  * On Windows, the helper returns the ``CREATE_NO_WINDOW`` creationflag.
  * On macOS / Linux it returns an empty dict so the kwargs splat is a no-op.

The tests patch ``sys.platform`` so they run identically on every CI runner.
"""

from __future__ import annotations

import subprocess
from unittest.mock import patch

from posture_agent.utils import win_subprocess
from posture_agent.utils.win_subprocess import no_window_kwargs


class TestNoWindowKwargs:
    def test_returns_empty_dict_on_macos(self):
        """macOS / Linux: empty dict so subprocess kwargs are unchanged."""
        with patch.object(win_subprocess, "sys") as mock_sys:
            mock_sys.platform = "darwin"
            result = no_window_kwargs()
        assert result == {}

    def test_returns_empty_dict_on_linux(self):
        with patch.object(win_subprocess, "sys") as mock_sys:
            mock_sys.platform = "linux"
            result = no_window_kwargs()
        assert result == {}

    def test_returns_creationflags_on_windows(self):
        """Windows: a ``creationflags`` kwarg with CREATE_NO_WINDOW (0x08000000)."""
        # The real ``subprocess`` module on macOS does not define
        # CREATE_NO_WINDOW. Patch it in so the helper picks up the real
        # Win32 value when ``sys.platform == "win32"``.
        with (
            patch.object(win_subprocess, "sys") as mock_sys,
            patch.object(
                win_subprocess,
                "_CREATE_NO_WINDOW",
                0x08000000,
            ),
        ):
            mock_sys.platform = "win32"
            result = no_window_kwargs()

        assert "creationflags" in result
        # 0x08000000 is the documented CREATE_NO_WINDOW value. Asserting the
        # numeric value catches accidental changes to the helper that would
        # silently degrade Windows behavior back to popping consoles.
        assert result["creationflags"] == 0x08000000

    def test_returned_dict_is_splattable_into_subprocess_run(self):
        """The result must be ``**kwargs``-compatible on every platform.

        ``subprocess.run`` rejects unknown kwargs. On macOS the helper returns
        ``{}`` (always safe). On Windows it returns ``{"creationflags": ...}``
        which is a real, documented kwarg.
        """
        # macOS path — empty dict, real call should succeed.
        with patch.object(win_subprocess, "sys") as mock_sys:
            mock_sys.platform = "darwin"
            result = subprocess.run(
                ["true"],
                capture_output=True,
                **no_window_kwargs(),
            )
        assert result.returncode == 0

    def test_helper_does_not_import_win32_constant_eagerly(self):
        """``CREATE_NO_WINDOW`` is Win32-only; importing this module on macOS
        must not raise ``AttributeError``. Already proven by the fact that
        these tests import the module on macOS CI, but pin the contract
        explicitly so a future refactor doesn't reintroduce the bug.
        """
        # The constant is fetched via ``getattr(subprocess, ..., 0)`` at import
        # time. On non-Windows it falls back to ``0`` (which is also the
        # "no flags" value for ``CreateProcess``).
        assert isinstance(win_subprocess._CREATE_NO_WINDOW, int)
