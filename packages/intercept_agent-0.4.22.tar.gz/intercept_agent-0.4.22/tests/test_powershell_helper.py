"""Tests for the PowerShell helper.

These tests run on macOS / Linux CI by patching ``platform.system`` and
``subprocess.run`` — no real ``powershell.exe`` is invoked.
"""

from __future__ import annotations

import json
import subprocess
from types import SimpleNamespace
from unittest.mock import patch

from posture_agent.platforms.powershell import PSError, PSResult, run_ps


def _completed(stdout: str = "", stderr: str = "", returncode: int = 0):
    """Build a :class:`subprocess.CompletedProcess`-shaped object."""
    return SimpleNamespace(stdout=stdout, stderr=stderr, returncode=returncode)


class TestRunPSPlatformGuard:
    """Non-Windows hosts must short-circuit without invoking subprocess."""

    def test_run_ps_short_circuits_on_non_windows(self):
        with (
            patch("posture_agent.platforms.powershell.platform.system", return_value="Darwin"),
            patch("posture_agent.platforms.powershell.subprocess.run") as mock_run,
        ):
            result = run_ps("Get-Process")

        assert isinstance(result, PSResult)
        assert result.ok is False
        assert result.error is not None
        assert result.error.kind == "unsupported"
        assert "Darwin" in result.error.message
        assert mock_run.call_count == 0


class TestRunPSSuccess:
    """Successful invocations parse JSON stdout into ``PSResult.data``."""

    def test_run_ps_parses_json_on_success(self):
        payload = {"Name": "BitLocker", "Status": "On"}
        completed = _completed(stdout=json.dumps(payload), returncode=0)

        with (
            patch("posture_agent.platforms.powershell.platform.system", return_value="Windows"),
            patch("posture_agent.platforms.powershell.subprocess.run", return_value=completed),
        ):
            result = run_ps("Get-BitLockerVolume")

        assert result.ok is True
        assert result.error is None
        assert result.data == payload

    def test_run_ps_returns_raw_when_json_output_false(self):
        completed = _completed(stdout="raw text output\n", returncode=0)

        with (
            patch("posture_agent.platforms.powershell.platform.system", return_value="Windows"),
            patch("posture_agent.platforms.powershell.subprocess.run", return_value=completed),
        ):
            result = run_ps("Write-Output 'raw text output'", json_output=False)

        assert result.ok is True
        assert result.error is None
        assert result.data == "raw text output\n"

    def test_run_ps_handles_empty_json_stdout(self):
        """Empty stdout is a legitimate success state (e.g., zero rows)."""
        completed = _completed(stdout="", returncode=0)

        with (
            patch("posture_agent.platforms.powershell.platform.system", return_value="Windows"),
            patch("posture_agent.platforms.powershell.subprocess.run", return_value=completed),
        ):
            result = run_ps("Get-NoOp")

        assert result.ok is True
        assert result.data is None
        assert result.error is None


class TestRunPSErrorClassification:
    """Stderr signatures and exit codes must map to the right ``PSError.kind``."""

    def test_run_ps_classifies_cmdlet_not_found(self):
        stderr = (
            "Get-FakeCmdlet : The term 'Get-FakeCmdlet' is not recognized as the "
            "name of a cmdlet, function, script file, or operable program."
        )
        completed = _completed(stderr=stderr, returncode=1)

        with (
            patch("posture_agent.platforms.powershell.platform.system", return_value="Windows"),
            patch("posture_agent.platforms.powershell.subprocess.run", return_value=completed),
        ):
            result = run_ps("Get-FakeCmdlet")

        assert result.ok is False
        assert result.error is not None
        assert result.error.kind == "cmdlet_not_found"
        assert result.stderr == stderr

    def test_run_ps_classifies_permission_denied(self):
        stderr = "Get-BitLockerVolume : Access is denied."
        completed = _completed(stderr=stderr, returncode=1)

        with (
            patch("posture_agent.platforms.powershell.platform.system", return_value="Windows"),
            patch("posture_agent.platforms.powershell.subprocess.run", return_value=completed),
        ):
            result = run_ps("Get-BitLockerVolume")

        assert result.ok is False
        assert result.error is not None
        assert result.error.kind == "permission_denied"

    def test_run_ps_classifies_permission_denied_registry(self):
        stderr = "Get-ItemProperty : Requested registry access is not allowed."
        completed = _completed(stderr=stderr, returncode=1)

        with (
            patch("posture_agent.platforms.powershell.platform.system", return_value="Windows"),
            patch("posture_agent.platforms.powershell.subprocess.run", return_value=completed),
        ):
            result = run_ps("Get-ItemProperty HKLM:\\Foo")

        assert result.ok is False
        assert result.error is not None
        assert result.error.kind == "permission_denied"

    def test_run_ps_classifies_exit_nonzero_without_known_signature(self):
        completed = _completed(stderr="something went wrong", returncode=2)

        with (
            patch("posture_agent.platforms.powershell.platform.system", return_value="Windows"),
            patch("posture_agent.platforms.powershell.subprocess.run", return_value=completed),
        ):
            result = run_ps("Some-Command")

        assert result.ok is False
        assert result.error is not None
        assert result.error.kind == "exit_nonzero"
        assert "exit=2" in result.error.message

    def test_run_ps_handles_timeout(self):
        def raise_timeout(*_args, **_kwargs):
            raise subprocess.TimeoutExpired(cmd="powershell.exe", timeout=8.0)

        with (
            patch("posture_agent.platforms.powershell.platform.system", return_value="Windows"),
            patch("posture_agent.platforms.powershell.subprocess.run", side_effect=raise_timeout),
        ):
            result = run_ps("Start-Sleep -Seconds 999", timeout=0.01)

        assert result.ok is False
        assert result.error is not None
        assert result.error.kind == "timeout"

    def test_run_ps_handles_bad_json(self):
        completed = _completed(stdout="this is not json {{{", returncode=0)

        with (
            patch("posture_agent.platforms.powershell.platform.system", return_value="Windows"),
            patch("posture_agent.platforms.powershell.subprocess.run", return_value=completed),
        ):
            result = run_ps("Some-CmdletThatReturnsBadJson")

        assert result.ok is False
        assert result.error is not None
        assert result.error.kind == "parse_error"


class TestRunPSDuration:
    """``duration_ms`` must always be a non-negative integer."""

    def test_run_ps_records_duration(self):
        completed = _completed(stdout="{}", returncode=0)

        with (
            patch("posture_agent.platforms.powershell.platform.system", return_value="Windows"),
            patch("posture_agent.platforms.powershell.subprocess.run", return_value=completed),
        ):
            result = run_ps("Get-Anything")

        assert isinstance(result.duration_ms, int)
        assert result.duration_ms >= 0


class TestPSErrorDataclass:
    """Sanity check on the dataclass shape."""

    def test_pserror_is_frozen(self):
        err = PSError(kind="timeout", message="boom")
        try:
            err.kind = "other"  # type: ignore[misc]
        except Exception:
            return
        raise AssertionError("PSError should be frozen")
