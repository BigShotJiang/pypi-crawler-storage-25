"""Tests for AI tools collector with mocked dependencies.

The collector merges three sources into a single ``data`` list:

* desktop apps + AI CLIs from ``bundle.ides.installed_ai_tools()``
* AI extensions from each editor's ``--list-extensions``

Tests stub ``get_bundle`` so they can run on any OS without invoking
PowerShell or filesystem scans.
"""

import asyncio
from unittest.mock import AsyncMock, MagicMock, patch

from posture_agent.collectors.ai_tools import AIToolsCollector


def _stub_bundle(installed_ai_tools_result):
    """Build a MagicMock platform bundle that returns ``installed_ai_tools_result``.

    ``installed_ai_tools_result`` is the ``(tools, errors)`` tuple the
    bundle method should yield. The mock satisfies the
    ``bundle.ides.installed_ai_tools()`` chain used by the collector.
    """
    bundle = MagicMock()
    bundle.ides.installed_ai_tools = AsyncMock(return_value=installed_ai_tools_result)
    return bundle


class TestAIToolsBundleIntegration:
    """The collector consumes desktop + CLI tools from the platform bundle."""

    def test_desktop_apps_passed_through_from_bundle(self):
        collector = AIToolsCollector()
        bundle_tools = [
            {
                "name": "Claude Desktop",
                "type": "desktop",
                "binary": "",
                "version": "0.7.0",
            },
            {
                "name": "Cursor",
                "type": "desktop",
                "binary": "cursor",
                "version": "0.42.0",
            },
        ]

        with (
            patch(
                "posture_agent.collectors.ai_tools.get_bundle",
                return_value=_stub_bundle((bundle_tools, [])),
            ),
            patch("posture_agent.collectors.ai_tools.shutil.which", return_value=None),
        ):
            result = asyncio.run(collector.collect())

        names = {t["name"] for t in result.data if t["type"] == "desktop"}
        assert {"Claude Desktop", "Cursor"} == names

    def test_cli_tools_passed_through_from_bundle(self):
        collector = AIToolsCollector()
        bundle_tools = [
            {
                "name": "Claude Code",
                "type": "cli",
                "binary": "claude",
                "version": "1.0.0",
            },
        ]

        with (
            patch(
                "posture_agent.collectors.ai_tools.get_bundle",
                return_value=_stub_bundle((bundle_tools, [])),
            ),
            patch("posture_agent.collectors.ai_tools.shutil.which", return_value=None),
        ):
            result = asyncio.run(collector.collect())

        cli = [t for t in result.data if t["type"] == "cli"]
        assert len(cli) == 1
        assert cli[0]["name"] == "Claude Code"
        assert cli[0]["version"] == "1.0.0"

    def test_bundle_errors_propagate_to_collector_result(self):
        collector = AIToolsCollector()
        bundle_errors = ["Claude Desktop: boom"]

        with (
            patch(
                "posture_agent.collectors.ai_tools.get_bundle",
                return_value=_stub_bundle(([], bundle_errors)),
            ),
            patch("posture_agent.collectors.ai_tools.shutil.which", return_value=None),
        ):
            result = asyncio.run(collector.collect())

        assert any("Claude Desktop" in e for e in result.errors)

    def test_bundle_raises_collector_records_error(self):
        collector = AIToolsCollector()

        bundle = MagicMock()
        bundle.ides.installed_ai_tools = AsyncMock(side_effect=RuntimeError("kaboom"))

        with (
            patch("posture_agent.collectors.ai_tools.get_bundle", return_value=bundle),
            patch("posture_agent.collectors.ai_tools.shutil.which", return_value=None),
        ):
            result = asyncio.run(collector.collect())

        assert any("installed_ai_tools" in e for e in result.errors)

    def test_dedupe_collapses_same_name_and_type(self):
        """Bundle returning the same (name, type) twice is collapsed to one."""
        collector = AIToolsCollector()
        bundle_tools = [
            {"name": "Cursor", "type": "desktop", "binary": "cursor", "version": "0.42.0"},
            {"name": "Cursor", "type": "desktop", "binary": "cursor", "version": "0.42.0"},
        ]

        with (
            patch(
                "posture_agent.collectors.ai_tools.get_bundle",
                return_value=_stub_bundle((bundle_tools, [])),
            ),
            patch("posture_agent.collectors.ai_tools.shutil.which", return_value=None),
        ):
            result = asyncio.run(collector.collect())

        cursors = [t for t in result.data if t["name"] == "Cursor" and t["type"] == "desktop"]
        assert len(cursors) == 1


class TestAIToolsExtensionDetection:
    """Test AI extension detection from editors."""

    def test_detects_copilot_extension_in_vscode(self):
        collector = AIToolsCollector()

        def mock_which(binary):
            if binary == "code":
                return "/usr/local/bin/code"
            return None

        async def mock_run(cmd, *args):
            if cmd == "code" and args == ("--list-extensions", "--show-versions"):
                return (
                    "github.copilot@1.272.0\n"
                    "github.copilot-chat@0.27.3\n"
                    "ms-python.python@2024.0.1\n"
                )
            return None

        with (
            patch(
                "posture_agent.collectors.ai_tools.get_bundle",
                return_value=_stub_bundle(([], [])),
            ),
            patch("posture_agent.collectors.ai_tools.run_command", side_effect=mock_run),
            patch("posture_agent.collectors.ai_tools.shutil.which", side_effect=mock_which),
        ):
            result = asyncio.run(collector.collect())

        ext_tools = [t for t in result.data if t["type"] == "extension"]
        ext_names = {t["name"] for t in ext_tools}
        assert "github.copilot" in ext_names
        assert "github.copilot-chat" in ext_names
        # ms-python.python is NOT an AI extension
        assert "ms-python.python" not in ext_names

        # Versions are populated from the shim's `--show-versions` output,
        # matching what the IDE Extensions card displays.
        copilot = next(t for t in ext_tools if t["name"] == "github.copilot")
        assert copilot["version"] == "1.272.0"
        chat = next(t for t in ext_tools if t["name"] == "github.copilot-chat")
        assert chat["version"] == "0.27.3"

    def test_editor_not_installed_skipped(self):
        collector = AIToolsCollector()

        async def mock_run(cmd, *args):
            return None  # No editors found

        with (
            patch(
                "posture_agent.collectors.ai_tools.get_bundle",
                return_value=_stub_bundle(([], [])),
            ),
            patch("posture_agent.collectors.ai_tools.run_command", side_effect=mock_run),
            patch("posture_agent.collectors.ai_tools.shutil.which", return_value=None),
        ):
            result = asyncio.run(collector.collect())

        ext_tools = [t for t in result.data if t["type"] == "extension"]
        assert ext_tools == []

    def test_editor_list_extensions_returns_none(self):
        collector = AIToolsCollector()

        def mock_which(binary):
            if binary == "code":
                return "/usr/local/bin/code"
            return None

        async def mock_run(cmd, *args):
            if cmd == "code" and args == ("--list-extensions", "--show-versions"):
                return None  # Command fails
            return None

        with (
            patch(
                "posture_agent.collectors.ai_tools.get_bundle",
                return_value=_stub_bundle(([], [])),
            ),
            patch("posture_agent.collectors.ai_tools.run_command", side_effect=mock_run),
            patch("posture_agent.collectors.ai_tools.shutil.which", side_effect=mock_which),
        ):
            result = asyncio.run(collector.collect())

        ext_tools = [t for t in result.data if t["type"] == "extension"]
        assert ext_tools == []

    def test_editor_extension_exception_caught(self):
        collector = AIToolsCollector()

        def mock_which(binary):
            if binary == "code":
                return "/usr/local/bin/code"
            return None

        async def mock_run(cmd, *args):
            if cmd == "code" and args == ("--list-extensions", "--show-versions"):
                raise RuntimeError("code crashed")
            return None

        with (
            patch(
                "posture_agent.collectors.ai_tools.get_bundle",
                return_value=_stub_bundle(([], [])),
            ),
            patch("posture_agent.collectors.ai_tools.run_command", side_effect=mock_run),
            patch("posture_agent.collectors.ai_tools.shutil.which", side_effect=mock_which),
        ):
            result = asyncio.run(collector.collect())

        assert any("AI extensions (code)" in e for e in result.errors)

    def test_extension_editor_name_correct(self):
        """Extension entries should have the correct editor display name."""
        collector = AIToolsCollector()

        def mock_which(binary):
            if binary == "cursor":
                return "/usr/local/bin/cursor"
            return None

        async def mock_run(cmd, *args):
            if cmd == "cursor" and args == ("--list-extensions", "--show-versions"):
                return "sourcegraph.cody-ai@1.0.0\n"
            return None

        with (
            patch(
                "posture_agent.collectors.ai_tools.get_bundle",
                return_value=_stub_bundle(([], [])),
            ),
            patch("posture_agent.collectors.ai_tools.run_command", side_effect=mock_run),
            patch("posture_agent.collectors.ai_tools.shutil.which", side_effect=mock_which),
        ):
            result = asyncio.run(collector.collect())

        ext_tools = [t for t in result.data if t["type"] == "extension"]
        assert len(ext_tools) == 1
        assert ext_tools[0]["editor"] == "Cursor"
        assert ext_tools[0]["name"] == "sourcegraph.cody-ai"
