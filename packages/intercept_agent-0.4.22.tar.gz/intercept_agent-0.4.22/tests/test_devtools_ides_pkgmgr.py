"""Tests for dev_tools, IDEs, and package_managers collector error paths."""

import asyncio
from unittest.mock import patch

from posture_agent.collectors.dev_tools import (
    DevToolsCollector,
    _is_windows_store_stub_path,
)
from posture_agent.collectors.ides import IDECollector
from posture_agent.collectors.package_managers import PackageManagerCollector


class TestDevToolsCollectorErrors:
    """Test dev tools error handling."""

    def test_exception_during_detection_caught(self):
        collector = DevToolsCollector()

        def mock_which(binary):
            if binary == "git":
                raise RuntimeError("which broke")
            return None

        with (
            patch("posture_agent.collectors.dev_tools.shutil.which", side_effect=mock_which),
            patch("posture_agent.collectors.dev_tools.check_version", return_value=None),
        ):
            result = asyncio.run(collector.collect())

        assert any("Git" in e for e in result.errors)

    def test_slow_tool_uses_longer_timeout(self):
        """Tools in _SLOW_TOOLS should use 30s timeout."""
        collector = DevToolsCollector()
        captured_timeout = {}

        def mock_which(binary):
            if binary == "sbt":
                return "/usr/local/bin/sbt"
            return None

        async def mock_check(binary, flag, *, timeout=10.0):
            captured_timeout[binary] = timeout
            return "1.0.0"

        with (
            patch("posture_agent.collectors.dev_tools.shutil.which", side_effect=mock_which),
            patch("posture_agent.collectors.dev_tools.check_version", side_effect=mock_check),
        ):
            result = asyncio.run(collector.collect())

        assert captured_timeout.get("sbt") == 30.0


class TestWindowsStoreStubPathHelper:
    """Test the WindowsApps stub path helper (#623)."""

    def test_recognises_windowsapps_path(self):
        assert (
            _is_windows_store_stub_path(
                "C:\\Users\\dev\\AppData\\Local\\Microsoft\\WindowsApps\\python3.EXE"
            )
            is True
        )

    def test_case_insensitive(self):
        assert (
            _is_windows_store_stub_path(
                "C:\\Users\\dev\\AppData\\Local\\Microsoft\\windowsapps\\python3.exe"
            )
            is True
        )
        assert (
            _is_windows_store_stub_path(
                "c:\\users\\dev\\appdata\\local\\microsoft\\WINDOWSAPPS\\winget.EXE"
            )
            is True
        )

    def test_real_install_paths_not_flagged(self):
        assert _is_windows_store_stub_path("C:\\Python312\\python.exe") is False
        assert _is_windows_store_stub_path("/usr/local/bin/python3") is False
        assert _is_windows_store_stub_path("C:\\Program Files\\Git\\bin\\git.exe") is False

    def test_empty_path_not_flagged(self):
        assert _is_windows_store_stub_path("") is False


class TestDevToolsWindowsStoreStubFiltering:
    """Test that WindowsApps stub-with-no-version entries are dropped (#623)."""

    def test_windows_store_stub_with_empty_version_skipped(self):
        """python3 resolved to a WindowsApps stub with no version → skip."""
        collector = DevToolsCollector()

        stub_path = "C:\\Users\\dev\\AppData\\Local\\Microsoft\\WindowsApps\\python3.EXE"

        def mock_which(binary):
            if binary == "python3":
                return stub_path
            return None

        async def mock_check(binary, flag, *, timeout=10.0):
            return None  # stub returns no version

        with (
            patch("posture_agent.collectors.dev_tools.shutil.which", side_effect=mock_which),
            patch("posture_agent.collectors.dev_tools.check_version", side_effect=mock_check),
            patch("posture_agent.collectors.dev_tools.os.path.realpath", side_effect=lambda p: p),
        ):
            result = asyncio.run(collector.collect())

        names = [t["name"] for t in result.data]
        assert "Python" not in names
        # Also: no breadcrumb error spam for the stub we filtered
        assert not any("Python:" in e for e in result.errors)

    def test_real_install_with_empty_version_still_emitted(self):
        """A non-WindowsApps path with no version still gets a breadcrumb
        entry (legacy behaviour preserved for #623's B9 debugging)."""
        collector = DevToolsCollector()

        def mock_which(binary):
            if binary == "python3":
                return "C:\\Python312\\python.exe"
            return None

        async def mock_check(binary, flag, *, timeout=10.0):
            return None

        with (
            patch("posture_agent.collectors.dev_tools.shutil.which", side_effect=mock_which),
            patch("posture_agent.collectors.dev_tools.check_version", side_effect=mock_check),
            patch("posture_agent.collectors.dev_tools.os.path.realpath", side_effect=lambda p: p),
        ):
            result = asyncio.run(collector.collect())

        python_entries = [t for t in result.data if t["name"] == "Python"]
        assert len(python_entries) == 1
        assert python_entries[0]["version"] == ""
        assert any("Python:" in e for e in result.errors)

    def test_windows_store_stub_with_real_version_still_emitted(self):
        """Some Store-installed apps actually return a version; keep them."""
        collector = DevToolsCollector()

        stub_path = "C:\\Users\\dev\\AppData\\Local\\Microsoft\\WindowsApps\\python3.EXE"

        def mock_which(binary):
            if binary == "python3":
                return stub_path
            return None

        async def mock_check(binary, flag, *, timeout=10.0):
            return "3.12.1"

        with (
            patch("posture_agent.collectors.dev_tools.shutil.which", side_effect=mock_which),
            patch("posture_agent.collectors.dev_tools.check_version", side_effect=mock_check),
            patch("posture_agent.collectors.dev_tools.os.path.realpath", side_effect=lambda p: p),
        ):
            result = asyncio.run(collector.collect())

        python_entries = [t for t in result.data if t["name"] == "Python"]
        assert len(python_entries) == 1
        assert python_entries[0]["version"] == "3.12.1"

    def test_real_install_with_version_emitted_normally(self):
        """Sanity: standard install path with a version → reported as-is."""
        collector = DevToolsCollector()

        def mock_which(binary):
            if binary == "git":
                return "/usr/local/bin/git"
            return None

        async def mock_check(binary, flag, *, timeout=10.0):
            return "2.43.0"

        with (
            patch("posture_agent.collectors.dev_tools.shutil.which", side_effect=mock_which),
            patch("posture_agent.collectors.dev_tools.check_version", side_effect=mock_check),
            patch("posture_agent.collectors.dev_tools.os.path.realpath", side_effect=lambda p: p),
        ):
            result = asyncio.run(collector.collect())

        git_entries = [t for t in result.data if t["name"] == "Git"]
        assert len(git_entries) == 1
        assert git_entries[0]["version"] == "2.43.0"


class TestIDECollectorMocked:
    """Test IDE collector with mocked commands."""

    def test_ide_detected_via_app_bundle(self):
        collector = IDECollector()

        async def mock_run(cmd, *args):
            if cmd == "defaults" and "CFBundleShortVersionString" in args:
                return "15.2\n"
            if cmd == "which":
                return None
            return None

        # Mock the app path existence
        with (
            patch("posture_agent.platforms.macos.run_command", side_effect=mock_run),
            patch("posture_agent.platforms.macos.Path.exists", return_value=True),
            patch("posture_agent.platforms.macos.check_version", return_value=None),
        ):
            result = asyncio.run(collector.collect())

        # Should find IDEs (since all Path.exists returns True)
        assert isinstance(result.data, list)
        assert len(result.data) > 0

    def test_ide_exception_caught(self):
        collector = IDECollector()

        call_count = 0

        async def mock_run(cmd, *args):
            nonlocal call_count
            call_count += 1
            if cmd == "which" and args[0] == "code":
                raise RuntimeError("which error")
            return None

        with (
            patch("posture_agent.platforms.macos.run_command", side_effect=mock_run),
            patch("posture_agent.platforms.macos.check_version", return_value=None),
        ):
            result = asyncio.run(collector.collect())

        assert any("VS Code" in e for e in result.errors)


class TestPackageManagerCollectorErrors:
    """Test package manager error handling."""

    def test_exception_during_detection_caught(self):
        collector = PackageManagerCollector()

        def mock_which(binary):
            if binary == "brew":
                raise RuntimeError("which broke")
            return None

        with (
            patch("posture_agent.collectors.package_managers.shutil.which", side_effect=mock_which),
            patch("posture_agent.collectors.package_managers.check_version", return_value=None),
        ):
            result = asyncio.run(collector.collect())

        assert any("Homebrew" in e for e in result.errors)
