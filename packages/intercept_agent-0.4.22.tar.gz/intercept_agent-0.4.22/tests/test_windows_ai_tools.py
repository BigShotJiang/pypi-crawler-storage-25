"""Tests for the Windows ``installed_ai_tools`` discovery + helpers.

Runs on macOS / Linux CI by patching ``shutil.which``, ``check_version``, and
the ``run_ps`` helper at the import site
(``posture_agent.platforms.windows.run_ps``). Filesystem scans are exercised
via fake directory trees built under ``tmp_path``.
"""

from __future__ import annotations

from pathlib import Path
from unittest.mock import AsyncMock, patch

from posture_agent.platforms import windows
from posture_agent.platforms.powershell import PSError, PSResult


def _ps_ok(value: str) -> PSResult:
    return PSResult(ok=True, data=value, error=None, stderr="", duration_ms=1)


def _ps_err(kind: str = "exit_nonzero") -> PSResult:
    return PSResult(
        ok=False,
        data=None,
        error=PSError(kind=kind, message=""),
        stderr="",
        duration_ms=1,
    )


class TestExpandTemplate:
    """``$VAR`` placeholder resolution against the user's environment."""

    def test_resolves_localappdata(self, monkeypatch, tmp_path: Path):
        monkeypatch.setenv("LOCALAPPDATA", str(tmp_path / "AppData" / "Local"))
        result = windows._expand_template(r"$LOCALAPPDATA\Foo\Bar.exe")
        assert result == tmp_path / "AppData" / "Local" / "Foo" / "Bar.exe"

    def test_falls_back_when_env_missing(self, monkeypatch, tmp_path: Path):
        monkeypatch.delenv("LOCALAPPDATA", raising=False)
        monkeypatch.setattr(Path, "home", lambda: tmp_path)

        result = windows._expand_template(r"$LOCALAPPDATA\X.exe")
        assert result == tmp_path / "AppData" / "Local" / "X.exe"

    def test_unknown_token_left_untouched(self):
        # Unrecognised tokens do not raise; they just stay as-is so the
        # caller's `.exists()` check returns False naturally.
        result = windows._expand_template(r"$WAT\foo.exe")
        assert "$WAT" in str(result)


class TestGetExeVersion:
    """``Get-Item -LiteralPath '<path>'.VersionInfo.ProductVersion`` reads."""

    def test_returns_version_on_success(self):
        with patch(
            "posture_agent.platforms.windows.run_ps",
            return_value=_ps_ok("0.7.0"),
        ):
            assert windows._get_exe_version(r"C:\foo\bar.exe") == "0.7.0"

    def test_strips_whitespace(self):
        with patch(
            "posture_agent.platforms.windows.run_ps",
            return_value=_ps_ok("  1.2.3  \r\n"),
        ):
            assert windows._get_exe_version(r"C:\foo\bar.exe") == "1.2.3"

    def test_returns_none_on_powershell_error(self):
        with patch(
            "posture_agent.platforms.windows.run_ps",
            return_value=_ps_err("exit_nonzero"),
        ):
            assert windows._get_exe_version(r"C:\foo\bar.exe") is None

    def test_returns_none_on_non_string_data(self):
        # PowerShell could theoretically serialise as something weird;
        # the helper must reject anything that isn't a string.
        with patch(
            "posture_agent.platforms.windows.run_ps",
            return_value=PSResult(ok=True, data=42, error=None, stderr="", duration_ms=1),
        ):
            assert windows._get_exe_version(r"C:\foo\bar.exe") is None

    def test_returns_none_on_empty_string(self):
        with patch(
            "posture_agent.platforms.windows.run_ps",
            return_value=_ps_ok("   "),
        ):
            assert windows._get_exe_version(r"C:\foo\bar.exe") is None

    def test_empty_path_returns_none(self):
        # Don't even invoke PowerShell when the caller hands us an empty
        # string — guard against accidental injection of "$null".
        assert windows._get_exe_version("") is None

    def test_escapes_single_quotes_in_path(self):
        captured: dict[str, str] = {}

        def _fake_run(script, *, json_output=False):  # noqa: ARG001
            captured["script"] = script
            return _ps_ok("9.9.9")

        with patch("posture_agent.platforms.windows.run_ps", side_effect=_fake_run):
            assert windows._get_exe_version(r"C:\with'quote\app.exe") == "9.9.9"

        # Single quote must be doubled for PowerShell's -LiteralPath syntax
        # so the path is not closed prematurely.
        assert "with''quote" in captured["script"]


class TestInstalledAiToolsDesktopApps:
    """Scan of ``%LOCALAPPDATA%`` AI desktop apps."""

    async def test_no_apps_no_clis_returns_empty(self, tmp_path: Path, monkeypatch):
        monkeypatch.setenv("LOCALAPPDATA", str(tmp_path / "missing"))
        monkeypatch.setenv("APPDATA", str(tmp_path / "missing-roaming"))
        monkeypatch.setattr(Path, "home", lambda: tmp_path)

        with (
            patch("posture_agent.platforms.windows.shutil.which", return_value=None),
            patch(
                "posture_agent.platforms.windows.run_ps",
                return_value=_ps_err("cmdlet_not_found"),
            ),
        ):
            tools, errors = await windows.WindowsIDEDiscovery().installed_ai_tools()

        assert tools == []
        assert errors == []

    async def test_claude_desktop_detected_with_version(self, tmp_path: Path, monkeypatch):
        local = tmp_path / "AppData" / "Local"
        claude_exe = local / "AnthropicClaude" / "Claude.exe"
        claude_exe.parent.mkdir(parents=True)
        claude_exe.write_text("")

        monkeypatch.setenv("LOCALAPPDATA", str(local))
        monkeypatch.setenv("APPDATA", str(tmp_path / "missing-roaming"))
        monkeypatch.setattr(Path, "home", lambda: tmp_path)

        with (
            patch("posture_agent.platforms.windows.shutil.which", return_value=None),
            patch(
                "posture_agent.platforms.windows.run_ps",
                return_value=_ps_ok("0.7.0"),
            ),
        ):
            tools, errors = await windows.WindowsIDEDiscovery().installed_ai_tools()

        assert errors == []
        claude = next(t for t in tools if t["name"] == "Claude Desktop")
        assert claude["type"] == "desktop"
        assert claude["version"] == "0.7.0"
        assert claude["binary"] == ""

    async def test_chatgpt_desktop_detected_no_version(self, tmp_path: Path, monkeypatch):
        local = tmp_path / "AppData" / "Local"
        chatgpt_exe = local / "Programs" / "openai" / "ChatGPT.exe"
        chatgpt_exe.parent.mkdir(parents=True)
        chatgpt_exe.write_text("")

        monkeypatch.setenv("LOCALAPPDATA", str(local))
        monkeypatch.setenv("APPDATA", str(tmp_path / "missing-roaming"))
        monkeypatch.setattr(Path, "home", lambda: tmp_path)

        with (
            patch("posture_agent.platforms.windows.shutil.which", return_value=None),
            patch(
                "posture_agent.platforms.windows.run_ps",
                return_value=_ps_err("permission_denied"),
            ),
        ):
            tools, errors = await windows.WindowsIDEDiscovery().installed_ai_tools()

        # ChatGPT desktop reports even when version metadata read fails — a
        # detected tool with no version is more useful than no detection.
        chatgpt = next(t for t in tools if t["name"] == "ChatGPT Desktop")
        assert chatgpt["type"] == "desktop"
        assert chatgpt["version"] == ""
        assert errors == []

    async def test_cursor_desktop_falls_back_to_cli_version(self, tmp_path: Path, monkeypatch):
        """Metadata read fails, CLI shim succeeds — version comes from CLI."""
        local = tmp_path / "AppData" / "Local"
        cursor_exe = local / "Programs" / "cursor" / "Cursor.exe"
        cursor_exe.parent.mkdir(parents=True)
        cursor_exe.write_text("")

        monkeypatch.setenv("LOCALAPPDATA", str(local))
        monkeypatch.setenv("APPDATA", str(tmp_path / "missing-roaming"))
        monkeypatch.setattr(Path, "home", lambda: tmp_path)

        with (
            patch(
                "posture_agent.platforms.windows.shutil.which",
                side_effect=lambda b: r"C:\fake\cursor.cmd" if b == "cursor" else None,
            ),
            patch(
                "posture_agent.platforms.windows.run_ps",
                return_value=_ps_err("exit_nonzero"),
            ),
            patch(
                "posture_agent.platforms.windows.check_version",
                new=AsyncMock(return_value="0.42.0"),
            ),
        ):
            tools, errors = await windows.WindowsIDEDiscovery().installed_ai_tools()

        cursor = next(t for t in tools if t["name"] == "Cursor" and t["type"] == "desktop")
        assert cursor["version"] == "0.42.0"
        assert cursor["binary"] == "cursor"
        assert errors == []

    async def test_first_existing_path_wins(self, tmp_path: Path, monkeypatch):
        """When multiple candidate paths exist, the first match is used."""
        local = tmp_path / "AppData" / "Local"
        # Create only the *second* candidate (Programs subdir).
        second = local / "Programs" / "AnthropicClaude" / "Claude.exe"
        second.parent.mkdir(parents=True)
        second.write_text("")

        captured_paths: list[str] = []

        def _fake_run_ps(script, *, json_output=False):  # noqa: ARG001
            captured_paths.append(script)
            return _ps_ok("0.7.1")

        monkeypatch.setenv("LOCALAPPDATA", str(local))
        monkeypatch.setenv("APPDATA", str(tmp_path / "missing-roaming"))
        monkeypatch.setattr(Path, "home", lambda: tmp_path)

        with (
            patch("posture_agent.platforms.windows.shutil.which", return_value=None),
            patch("posture_agent.platforms.windows.run_ps", side_effect=_fake_run_ps),
        ):
            tools, errors = await windows.WindowsIDEDiscovery().installed_ai_tools()

        claude = next(t for t in tools if t["name"] == "Claude Desktop")
        assert claude["version"] == "0.7.1"
        assert errors == []
        # Confirm the resolved path was the second template (Programs subdir)
        # — the fake_run_ps only fires when an EXE was found.
        assert any("Programs" in s and "AnthropicClaude" in s for s in captured_paths)


class TestInstalledAiToolsCli:
    """Scan of AI CLIs on PATH."""

    async def test_claude_code_cli_detected(self, tmp_path: Path, monkeypatch):
        monkeypatch.setenv("LOCALAPPDATA", str(tmp_path / "missing"))
        monkeypatch.setenv("APPDATA", str(tmp_path / "missing-roaming"))
        monkeypatch.setattr(Path, "home", lambda: tmp_path)

        def _which(binary):
            return r"C:\Users\x\AppData\Roaming\npm\claude.cmd" if binary == "claude" else None

        with (
            patch("posture_agent.platforms.windows.shutil.which", side_effect=_which),
            patch(
                "posture_agent.platforms.windows.check_version",
                new=AsyncMock(return_value="1.0.5"),
            ),
            patch(
                "posture_agent.platforms.windows.run_ps",
                return_value=_ps_err("cmdlet_not_found"),
            ),
        ):
            tools, errors = await windows.WindowsIDEDiscovery().installed_ai_tools()

        cli = [t for t in tools if t["type"] == "cli"]
        assert len(cli) == 1
        assert cli[0]["name"] == "Claude Code"
        assert cli[0]["binary"] == "claude"
        assert cli[0]["version"] == "1.0.5"
        assert errors == []

    async def test_per_tool_failure_isolated_in_errors(self, tmp_path: Path, monkeypatch):
        """A raising ``check_version`` for one CLI doesn't stop the rest."""
        monkeypatch.setenv("LOCALAPPDATA", str(tmp_path / "missing"))
        monkeypatch.setenv("APPDATA", str(tmp_path / "missing-roaming"))
        monkeypatch.setattr(Path, "home", lambda: tmp_path)

        def _which(binary):
            return f"C:/x/{binary}.cmd" if binary in {"claude", "aider"} else None

        async def _check(binary, *_a, **_kw):
            if binary == "claude":
                raise RuntimeError("boom")
            return "0.50.0"

        with (
            patch("posture_agent.platforms.windows.shutil.which", side_effect=_which),
            patch("posture_agent.platforms.windows.check_version", new=_check),
            patch(
                "posture_agent.platforms.windows.run_ps",
                return_value=_ps_err("cmdlet_not_found"),
            ),
        ):
            tools, errors = await windows.WindowsIDEDiscovery().installed_ai_tools()

        names = [t["name"] for t in tools if t["type"] == "cli"]
        assert "Aider" in names
        assert any(err.startswith("Claude Code:") for err in errors)


class TestInstalledAiToolsDedupe:
    """Same tool name from desktop + CLI surfaces does not duplicate."""

    async def test_cursor_desktop_wins_over_cursor_cli(self, tmp_path: Path, monkeypatch):
        """Cursor is in both desktop and CLI lists — desktop entry wins
        because it scans first."""
        local = tmp_path / "AppData" / "Local"
        cursor_exe = local / "Programs" / "cursor" / "Cursor.exe"
        cursor_exe.parent.mkdir(parents=True)
        cursor_exe.write_text("")

        monkeypatch.setenv("LOCALAPPDATA", str(local))
        monkeypatch.setenv("APPDATA", str(tmp_path / "missing-roaming"))
        monkeypatch.setattr(Path, "home", lambda: tmp_path)

        with (
            patch(
                "posture_agent.platforms.windows.shutil.which",
                side_effect=lambda b: r"C:\fake\cursor.cmd" if b == "cursor" else None,
            ),
            patch(
                "posture_agent.platforms.windows.run_ps",
                return_value=_ps_ok("0.42.0"),
            ),
            patch(
                "posture_agent.platforms.windows.check_version",
                new=AsyncMock(return_value="0.42.0"),
            ),
        ):
            tools, _errors = await windows.WindowsIDEDiscovery().installed_ai_tools()

        cursor_entries = [t for t in tools if t["name"] == "Cursor"]
        assert len(cursor_entries) == 1
        assert cursor_entries[0]["type"] == "desktop"
