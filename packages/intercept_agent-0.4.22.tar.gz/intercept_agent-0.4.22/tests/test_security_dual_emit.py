"""Tests for the security collector's dual-emit (legacy + platform-neutral) keys.

C11 of issue #623. The agent's posture report must carry BOTH the macOS-specific
legacy keys (``filevault_enabled``, ``gatekeeper_enabled``) and the new platform-
neutral keys (``disk_encryption_*``, ``app_signing_*``, ``firewall_product``) so
old API instances keep working while new instances prefer the neutral fields.

These tests patch the ``SecurityPostureProvider`` on the platform bundle so they
can run on macOS / Linux CI and exercise both macOS- and Windows-shaped responses
without needing the actual hosts.
"""

from __future__ import annotations

import asyncio
from unittest.mock import patch

from posture_agent import platforms
from posture_agent.collectors.security import SecurityCollector
from posture_agent.platforms.base import (
    AppSigningStatus,
    DiskEncryptionStatus,
    FirewallStatus,
    SshAgentInfo,
)


class _FakeSecurity:
    """Minimal SecurityPostureProvider returning whatever the test wires up."""

    def __init__(
        self,
        *,
        disk: DiskEncryptionStatus,
        firewall: FirewallStatus,
        app_signing: AppSigningStatus,
    ) -> None:
        self._disk = disk
        self._firewall = firewall
        self._app_signing = app_signing

    async def disk_encryption(self) -> DiskEncryptionStatus:
        return self._disk

    async def firewall(self) -> FirewallStatus:
        return self._firewall

    async def app_signing(self) -> AppSigningStatus:
        return self._app_signing


class _FakeSshAgent:
    async def detect(self) -> SshAgentInfo:
        return SshAgentInfo(socket_path=None, agent_type="none", key_count=0)


def _patched_bundle(security_provider: _FakeSecurity):
    """Build a PlatformBundle with the given security provider and noop rest.

    The collector only touches `bundle.security` and `bundle.ssh_agent`, so the
    other slots can remain real (they are never invoked during these tests).
    """
    real = platforms.detect()
    return platforms.PlatformBundle(
        hardware=real.hardware,
        security=security_provider,
        ssh_agent=_FakeSshAgent(),
        ides=real.ides,
        mcp_paths=real.mcp_paths,
        path_expander=real.path_expander,
        scheduler=real.scheduler,
    )


def _run_with_bundle(bundle):
    """Run the security collector with the platform bundle replaced."""
    collector = SecurityCollector()

    async def _noop_run(cmd, *args):
        return None

    platforms.reset_bundle()
    try:
        with (
            patch("posture_agent.collectors.security.get_bundle", return_value=bundle),
            patch(
                "posture_agent.collectors.security.run_command",
                side_effect=_noop_run,
            ),
        ):
            return asyncio.run(collector.collect())
    finally:
        platforms.reset_bundle()


class TestDualEmitOnMacOS:
    """macOS strategy returns FileVault/Gatekeeper — both legacy + neutral keys
    must surface with the same value."""

    def test_security_dual_emits_filevault_on_macos(self):
        fake = _FakeSecurity(
            disk=DiskEncryptionStatus(enabled=True, state="on", product="FileVault"),
            firewall=FirewallStatus(enabled=True, product="ApplicationFirewall"),
            app_signing=AppSigningStatus(enforced=True, state="enforced", product="Gatekeeper"),
        )
        result = _run_with_bundle(_patched_bundle(fake))

        # Legacy + neutral both present, same value.
        assert result.data["filevault_enabled"] is True
        assert result.data["disk_encryption_enabled"] is True
        assert result.data["disk_encryption_state"] == "on"
        assert result.data["disk_encryption_product"] == "FileVault"

    def test_security_dual_emits_gatekeeper_on_macos(self):
        fake = _FakeSecurity(
            disk=DiskEncryptionStatus(enabled=False, state="off", product="FileVault"),
            firewall=FirewallStatus(enabled=False, product="ApplicationFirewall"),
            app_signing=AppSigningStatus(enforced=True, state="enforced", product="Gatekeeper"),
        )
        result = _run_with_bundle(_patched_bundle(fake))

        assert result.data["gatekeeper_enabled"] is True
        assert result.data["app_signing_enforced"] is True
        assert result.data["app_signing_state"] == "enforced"
        assert result.data["app_signing_product"] == "Gatekeeper"

    def test_filevault_off_macos_keeps_legacy_false(self):
        fake = _FakeSecurity(
            disk=DiskEncryptionStatus(enabled=False, state="off", product="FileVault"),
            firewall=FirewallStatus(enabled=True, product="ApplicationFirewall"),
            app_signing=AppSigningStatus(enforced=False, state="disabled", product="Gatekeeper"),
        )
        result = _run_with_bundle(_patched_bundle(fake))

        assert result.data["filevault_enabled"] is False
        assert result.data["disk_encryption_enabled"] is False
        assert result.data["disk_encryption_state"] == "off"
        assert result.data["disk_encryption_product"] == "FileVault"
        assert result.data["gatekeeper_enabled"] is False
        assert result.data["app_signing_enforced"] is False


class TestDualEmitOnWindows:
    """Windows strategy returns BitLocker/SmartScreen — legacy macOS keys must
    be False (there is no FileVault/Gatekeeper on Windows) while the neutral
    keys carry the real Windows answer."""

    def test_security_emits_legacy_false_on_windows(self):
        fake = _FakeSecurity(
            disk=DiskEncryptionStatus(enabled=True, state="on", product="BitLocker"),
            firewall=FirewallStatus(enabled=True, product="Windows Defender Firewall"),
            app_signing=AppSigningStatus(enforced=True, state="enforced", product="SmartScreen"),
        )
        result = _run_with_bundle(_patched_bundle(fake))

        # Legacy macOS-only keys are False on Windows...
        assert result.data["filevault_enabled"] is False
        assert result.data["gatekeeper_enabled"] is False
        # ...but the platform-neutral keys carry the real answer.
        assert result.data["disk_encryption_enabled"] is True
        assert result.data["disk_encryption_state"] == "on"
        assert result.data["disk_encryption_product"] == "BitLocker"
        assert result.data["app_signing_enforced"] is True
        assert result.data["app_signing_state"] == "enforced"
        assert result.data["app_signing_product"] == "SmartScreen"

    def test_bitlocker_off_windows_neutral_keys_track_state(self):
        fake = _FakeSecurity(
            disk=DiskEncryptionStatus(enabled=False, state="off", product="BitLocker"),
            firewall=FirewallStatus(enabled=False, product="Windows Defender Firewall"),
            app_signing=AppSigningStatus(enforced=False, state="disabled", product="SmartScreen"),
        )
        result = _run_with_bundle(_patched_bundle(fake))

        assert result.data["filevault_enabled"] is False
        assert result.data["disk_encryption_enabled"] is False
        assert result.data["disk_encryption_state"] == "off"
        assert result.data["disk_encryption_product"] == "BitLocker"
        assert result.data["gatekeeper_enabled"] is False
        assert result.data["app_signing_enforced"] is False
        assert result.data["app_signing_state"] == "disabled"
        assert result.data["app_signing_product"] == "SmartScreen"


class TestFirewallProductField:
    """`firewall_product` must be populated on every platform."""

    def test_firewall_includes_product_field_macos(self):
        fake = _FakeSecurity(
            disk=DiskEncryptionStatus(enabled=True, state="on", product="FileVault"),
            firewall=FirewallStatus(enabled=True, product="ApplicationFirewall"),
            app_signing=AppSigningStatus(enforced=True, state="enforced", product="Gatekeeper"),
        )
        result = _run_with_bundle(_patched_bundle(fake))

        assert result.data["firewall_enabled"] is True
        assert result.data["firewall_product"] == "ApplicationFirewall"

    def test_firewall_includes_product_field_windows(self):
        fake = _FakeSecurity(
            disk=DiskEncryptionStatus(enabled=True, state="on", product="BitLocker"),
            firewall=FirewallStatus(enabled=True, product="Windows Defender Firewall"),
            app_signing=AppSigningStatus(enforced=True, state="enforced", product="SmartScreen"),
        )
        result = _run_with_bundle(_patched_bundle(fake))

        assert result.data["firewall_enabled"] is True
        assert result.data["firewall_product"] == "Windows Defender Firewall"


class TestDualEmitUnknownState:
    """When a probe returns enabled=None (unknown / permission denied) the
    neutral key must reflect None, while the legacy key still degrades to False."""

    def test_disk_encryption_unknown_keeps_legacy_false_neutral_none(self):
        fake = _FakeSecurity(
            disk=DiskEncryptionStatus(
                enabled=None,
                state="unknown",
                product="BitLocker",
                reason="insufficient_privilege",
            ),
            firewall=FirewallStatus(enabled=True, product="Windows Defender Firewall"),
            app_signing=AppSigningStatus(enforced=True, state="enforced", product="SmartScreen"),
        )
        result = _run_with_bundle(_patched_bundle(fake))

        # Legacy key always boolean — degrades to False on Windows or unknown.
        assert result.data["filevault_enabled"] is False
        # Neutral key faithfully carries None when the probe could not decide.
        assert result.data["disk_encryption_enabled"] is None
        assert result.data["disk_encryption_state"] == "unknown"
        assert result.data["disk_encryption_product"] == "BitLocker"
        # Reason surfaces in errors so the caller can see why.
        assert any("insufficient_privilege" in e for e in result.errors)
