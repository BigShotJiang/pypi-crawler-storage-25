"""Tests for the C9 Windows IDE discovery provider.

Runs on macOS / Linux CI by patching ``shutil.which`` and the cross-platform
``check_version`` helper at the import site
(``posture_agent.platforms.windows.check_version``). JetBrains discovery is
exercised via fake directory trees built under ``tmp_path``.
"""

from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import AsyncMock, patch

from posture_agent.platforms import windows
from posture_agent.platforms.windows import _read_vscode_fork_version_from_shim


class TestPathResidentIdeDetection:
    """Shim discovery via ``shutil.which`` + ``check_version``."""

    async def test_no_shims_returns_empty(self):
        """When no binaries resolve and no JetBrains roots exist, return empty."""
        with (
            patch("posture_agent.platforms.windows.shutil.which", return_value=None),
            patch.object(
                windows.WindowsIDEDiscovery,
                "_discover_jetbrains",
                return_value=[],
            ),
        ):
            ides, errors = await windows.WindowsIDEDiscovery().installed_ides()

        assert ides == []
        assert errors == []

    async def test_vscode_detected_with_version(self):
        """``code`` shim resolved → VS Code entry with version."""

        def _which(binary):
            return (
                r"C:\Users\x\AppData\Local\Programs\VS Code\bin\code.cmd"
                if binary == "code"
                else None
            )

        with (
            patch("posture_agent.platforms.windows.shutil.which", side_effect=_which),
            patch(
                "posture_agent.platforms.windows.check_version",
                new=AsyncMock(return_value="1.96.0"),
            ),
            patch.object(
                windows.WindowsIDEDiscovery,
                "_discover_jetbrains",
                return_value=[],
            ),
        ):
            ides, errors = await windows.WindowsIDEDiscovery().installed_ides()

        assert errors == []
        names = [i["name"] for i in ides]
        assert "VS Code" in names
        vscode = next(i for i in ides if i["name"] == "VS Code")
        assert vscode["version"] == "1.96.0"
        assert vscode["binary"] == "code"

    async def test_cursor_and_windsurf_detected(self):
        def _which(binary):
            return f"C:/fake/{binary}.cmd" if binary in {"cursor", "windsurf"} else None

        with (
            patch("posture_agent.platforms.windows.shutil.which", side_effect=_which),
            patch(
                "posture_agent.platforms.windows.check_version",
                new=AsyncMock(return_value="0.42.0"),
            ),
            patch.object(
                windows.WindowsIDEDiscovery,
                "_discover_jetbrains",
                return_value=[],
            ),
        ):
            ides, _ = await windows.WindowsIDEDiscovery().installed_ides()

        names = {i["name"] for i in ides}
        assert {"Cursor", "Windsurf"}.issubset(names)

    async def test_check_version_failure_keeps_ide_with_blank_version(self):
        """If ``--version`` returns nothing, the IDE is still reported."""
        with (
            patch(
                "posture_agent.platforms.windows.shutil.which",
                side_effect=lambda b: "C:/x/code.cmd" if b == "code" else None,
            ),
            patch(
                "posture_agent.platforms.windows.check_version",
                new=AsyncMock(return_value=None),
            ),
            patch.object(
                windows.WindowsIDEDiscovery,
                "_discover_jetbrains",
                return_value=[],
            ),
        ):
            ides, errors = await windows.WindowsIDEDiscovery().installed_ides()

        assert errors == []
        vscode = next(i for i in ides if i["name"] == "VS Code")
        assert vscode["version"] == ""

    async def test_per_ide_failure_isolated_in_errors(self):
        """A raising ``check_version`` does not stop other IDEs from being reported."""

        def _which(binary):
            return f"C:/x/{binary}.cmd" if binary in {"code", "cursor"} else None

        async def _check(binary, *_args, **_kwargs):
            if binary == "code":
                raise RuntimeError("boom")
            return "1.0.0"

        with (
            patch("posture_agent.platforms.windows.shutil.which", side_effect=_which),
            patch("posture_agent.platforms.windows.check_version", new=_check),
            patch.object(
                windows.WindowsIDEDiscovery,
                "_discover_jetbrains",
                return_value=[],
            ),
        ):
            ides, errors = await windows.WindowsIDEDiscovery().installed_ides()

        names = [i["name"] for i in ides]
        assert "Cursor" in names
        assert any(err.startswith("VS Code:") for err in errors)


class TestJetBrainsToolboxDiscovery:
    """JetBrains Toolbox layout: ``<root>/<App>/ch-<n>/<version>/bin``."""

    async def test_toolbox_intellij_detected(self, tmp_path: Path, monkeypatch):
        toolbox = tmp_path / "AppData" / "Local" / "JetBrains" / "Toolbox" / "apps"
        intellij_dir = toolbox / "IntelliJ IDEA Community Edition" / "ch-0" / "2024.3.1" / "bin"
        intellij_dir.mkdir(parents=True)

        monkeypatch.setattr(
            windows,
            "_PATH_IDE_DEFINITIONS",
            [],
        )
        monkeypatch.setenv("LOCALAPPDATA", str(tmp_path / "AppData" / "Local"))
        monkeypatch.setenv("PROGRAMFILES", str(tmp_path / "missing-pf"))
        monkeypatch.setenv("PROGRAMFILES(X86)", str(tmp_path / "missing-pf86"))
        monkeypatch.setattr(Path, "home", lambda: tmp_path)

        ides, errors = await windows.WindowsIDEDiscovery().installed_ides()

        assert errors == []
        names = [i["name"] for i in ides]
        assert "IntelliJ IDEA" in names
        intellij = next(i for i in ides if i["name"] == "IntelliJ IDEA")
        assert intellij["version"] == "2024.3.1"

    async def test_toolbox_picks_highest_version(self, tmp_path: Path, monkeypatch):
        toolbox = tmp_path / "AppData" / "Local" / "JetBrains" / "Toolbox" / "apps"
        for ver in ("2023.2.1", "2024.1.0", "2024.3.1"):
            (toolbox / "PyCharm" / "ch-0" / ver / "bin").mkdir(parents=True)

        monkeypatch.setattr(windows, "_PATH_IDE_DEFINITIONS", [])
        monkeypatch.setenv("LOCALAPPDATA", str(tmp_path / "AppData" / "Local"))
        monkeypatch.setenv("PROGRAMFILES", str(tmp_path / "missing"))
        monkeypatch.setenv("PROGRAMFILES(X86)", str(tmp_path / "missing86"))
        monkeypatch.setattr(Path, "home", lambda: tmp_path)

        ides, _ = await windows.WindowsIDEDiscovery().installed_ides()

        pycharm = next(i for i in ides if i["name"] == "PyCharm")
        assert pycharm["version"] == "2024.3.1"


class TestJetBrainsStandaloneInstallerDiscovery:
    """``%PROGRAMFILES%\\JetBrains\\<App version>``."""

    async def test_program_files_jetbrains(self, tmp_path: Path, monkeypatch):
        pf = tmp_path / "Program Files"
        (pf / "JetBrains" / "GoLand 2024.2").mkdir(parents=True)
        (pf / "JetBrains" / "WebStorm 2024.3.1").mkdir(parents=True)

        monkeypatch.setattr(windows, "_PATH_IDE_DEFINITIONS", [])
        monkeypatch.setenv("LOCALAPPDATA", str(tmp_path / "missing-local"))
        monkeypatch.setenv("PROGRAMFILES", str(pf))
        monkeypatch.setenv("PROGRAMFILES(X86)", str(tmp_path / "missing-x86"))
        monkeypatch.setattr(Path, "home", lambda: tmp_path)

        ides, errors = await windows.WindowsIDEDiscovery().installed_ides()

        assert errors == []
        names = {i["name"] for i in ides}
        assert {"GoLand", "WebStorm"}.issubset(names)
        goland = next(i for i in ides if i["name"] == "GoLand")
        assert goland["version"] == "2024.2"
        webstorm = next(i for i in ides if i["name"] == "WebStorm")
        assert webstorm["version"] == "2024.3.1"

    async def test_unknown_jetbrains_dir_skipped(self, tmp_path: Path, monkeypatch):
        pf = tmp_path / "Program Files"
        (pf / "JetBrains" / "Mystery 2024.1").mkdir(parents=True)

        monkeypatch.setattr(windows, "_PATH_IDE_DEFINITIONS", [])
        monkeypatch.setenv("LOCALAPPDATA", str(tmp_path / "missing-local"))
        monkeypatch.setenv("PROGRAMFILES", str(pf))
        monkeypatch.setenv("PROGRAMFILES(X86)", str(tmp_path / "missing-x86"))
        monkeypatch.setattr(Path, "home", lambda: tmp_path)

        ides, errors = await windows.WindowsIDEDiscovery().installed_ides()

        assert errors == []
        assert ides == []


class TestPluginAndExtensionRoots:
    def test_jetbrains_plugin_root(self, monkeypatch, tmp_path: Path):
        monkeypatch.setenv("APPDATA", str(tmp_path / "Roaming"))
        monkeypatch.setattr(Path, "home", lambda: tmp_path)

        root = windows.WindowsIDEDiscovery().jetbrains_plugin_root()
        assert root == tmp_path / "Roaming" / "JetBrains"

    def test_jetbrains_plugin_root_falls_back_when_appdata_missing(
        self, monkeypatch, tmp_path: Path
    ):
        monkeypatch.delenv("APPDATA", raising=False)
        monkeypatch.setattr(Path, "home", lambda: tmp_path)

        root = windows.WindowsIDEDiscovery().jetbrains_plugin_root()
        assert root == tmp_path / "AppData" / "Roaming" / "JetBrains"

    def test_vscode_extension_root(self, monkeypatch, tmp_path: Path):
        monkeypatch.setattr(Path, "home", lambda: tmp_path)

        root = windows.WindowsIDEDiscovery().vscode_extension_root()
        assert root == tmp_path / ".vscode" / "extensions"


class TestVSCodeForkVersionFromShim:
    """Helper that reads the VS Code-family ``package.json`` directly.

    The cmd-shim ``--version`` invocation can drop output on Windows because
    the shim launches an Electron GUI binary; reading the bundled
    ``package.json`` is deterministic and subprocess-free.
    """

    def test_reads_version_from_package_json(self, tmp_path: Path):
        # Lay out a realistic VS Code install root.
        install_root = tmp_path / "Programs" / "Microsoft VS Code"
        bin_dir = install_root / "bin"
        bin_dir.mkdir(parents=True)
        shim = bin_dir / "code.cmd"
        shim.write_text("@echo off\r\n")

        pkg_dir = install_root / "resources" / "app"
        pkg_dir.mkdir(parents=True)
        (pkg_dir / "package.json").write_text(
            json.dumps({"name": "code-oss-dev", "version": "1.96.4"})
        )

        assert _read_vscode_fork_version_from_shim(str(shim)) == "1.96.4"

    def test_returns_none_when_package_json_missing(self, tmp_path: Path):
        install_root = tmp_path / "Programs" / "Microsoft VS Code"
        bin_dir = install_root / "bin"
        bin_dir.mkdir(parents=True)
        shim = bin_dir / "code.cmd"
        shim.write_text("@echo off\r\n")
        # Intentionally do not create resources/app/package.json.

        assert _read_vscode_fork_version_from_shim(str(shim)) is None

    def test_returns_none_when_package_json_invalid(self, tmp_path: Path):
        install_root = tmp_path / "Cursor"
        bin_dir = install_root / "bin"
        bin_dir.mkdir(parents=True)
        shim = bin_dir / "cursor.cmd"
        shim.write_text("@echo off\r\n")

        pkg_dir = install_root / "resources" / "app"
        pkg_dir.mkdir(parents=True)
        (pkg_dir / "package.json").write_text("{not valid json")

        assert _read_vscode_fork_version_from_shim(str(shim)) is None

    def test_returns_none_when_version_field_missing(self, tmp_path: Path):
        install_root = tmp_path / "Windsurf"
        bin_dir = install_root / "bin"
        bin_dir.mkdir(parents=True)
        shim = bin_dir / "windsurf.cmd"
        shim.write_text("@echo off\r\n")

        pkg_dir = install_root / "resources" / "app"
        pkg_dir.mkdir(parents=True)
        (pkg_dir / "package.json").write_text(json.dumps({"name": "windsurf"}))

        assert _read_vscode_fork_version_from_shim(str(shim)) is None

    def test_returns_none_for_empty_path(self):
        assert _read_vscode_fork_version_from_shim("") is None

    async def test_installed_ides_uses_package_json_for_vscode_family(self, tmp_path: Path):
        """End-to-end: VS Code shim resolved → package.json read → version returned
        without invoking the cmd shim's ``--version`` flag."""
        install_root = tmp_path / "Microsoft VS Code"
        bin_dir = install_root / "bin"
        bin_dir.mkdir(parents=True)
        shim = bin_dir / "code.cmd"
        shim.write_text("@echo off\r\n")

        pkg_dir = install_root / "resources" / "app"
        pkg_dir.mkdir(parents=True)
        (pkg_dir / "package.json").write_text(
            json.dumps({"name": "code-oss-dev", "version": "1.96.4"})
        )

        def _which(binary: str):
            return str(shim) if binary == "code" else None

        # AsyncMock guards against the shim ``--version`` fallback being
        # exercised at all when package.json yields a value.
        cmd_shim_invocation = AsyncMock(return_value="should-not-be-used")
        with (
            patch("posture_agent.platforms.windows.shutil.which", side_effect=_which),
            patch(
                "posture_agent.platforms.windows.check_version",
                new=cmd_shim_invocation,
            ),
            patch.object(
                windows.WindowsIDEDiscovery,
                "_discover_jetbrains",
                return_value=[],
            ),
        ):
            ides, errors = await windows.WindowsIDEDiscovery().installed_ides()

        assert errors == []
        vscode = next(i for i in ides if i["name"] == "VS Code")
        assert vscode["version"] == "1.96.4"
        cmd_shim_invocation.assert_not_awaited()

    async def test_installed_ides_falls_back_to_check_version_when_pkg_json_missing(
        self, tmp_path: Path
    ):
        """Portable / unusual installs without a bundled package.json must still
        fall through to the ``--version`` cmd shim invocation."""
        bin_dir = tmp_path / "portable" / "bin"
        bin_dir.mkdir(parents=True)
        shim = bin_dir / "code.cmd"
        shim.write_text("@echo off\r\n")
        # Note: no resources/app/package.json under tmp_path/portable.

        def _which(binary: str):
            return str(shim) if binary == "code" else None

        with (
            patch("posture_agent.platforms.windows.shutil.which", side_effect=_which),
            patch(
                "posture_agent.platforms.windows.check_version",
                new=AsyncMock(return_value="1.96.4"),
            ),
            patch.object(
                windows.WindowsIDEDiscovery,
                "_discover_jetbrains",
                return_value=[],
            ),
        ):
            ides, errors = await windows.WindowsIDEDiscovery().installed_ides()

        assert errors == []
        vscode = next(i for i in ides if i["name"] == "VS Code")
        assert vscode["version"] == "1.96.4"
