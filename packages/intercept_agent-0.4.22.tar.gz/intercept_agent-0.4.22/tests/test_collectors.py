"""Tests for posture agent collectors."""

import asyncio
from unittest.mock import patch

import pytest
from posture_agent.collectors.ai_tools import AIToolsCollector
from posture_agent.collectors.base import CollectorResult
from posture_agent.collectors.dev_tools import DevToolsCollector
from posture_agent.collectors.extensions import ExtensionCollector
from posture_agent.collectors.ides import IDECollector
from posture_agent.collectors.machine import MachineCollector
from posture_agent.collectors.mcp_servers import MCPServersCollector, detect_risk_indicators
from posture_agent.collectors.package_managers import PackageManagerCollector
from posture_agent.collectors.security import SecurityCollector


@pytest.fixture
def event_loop():
    loop = asyncio.new_event_loop()
    yield loop
    loop.close()


class TestMachineCollector:
    def test_collect_returns_result(self):
        collector = MachineCollector()
        result = asyncio.run(collector.collect())
        assert isinstance(result, CollectorResult)
        assert result.collector == "machine"
        assert "hostname" in result.data
        assert "os_name" in result.data
        assert "architecture" in result.data

    def test_collect_has_username(self):
        collector = MachineCollector()
        result = asyncio.run(collector.collect())
        assert "username" in result.data


class TestDevToolsCollector:
    def test_collect_returns_result(self):
        collector = DevToolsCollector()
        result = asyncio.run(collector.collect())
        assert isinstance(result, CollectorResult)
        assert result.collector == "dev_tools"
        assert isinstance(result.data, list)

    def test_finds_git(self):
        """Git should be installed on any dev machine."""
        collector = DevToolsCollector()
        result = asyncio.run(collector.collect())
        tool_names = [t["name"] for t in result.data]
        assert "Git" in tool_names


class TestSecurityCollector:
    def test_collect_returns_result(self):
        collector = SecurityCollector()
        result = asyncio.run(collector.collect())
        assert isinstance(result, CollectorResult)
        assert result.collector == "security"
        assert "git_signing_enabled" in result.data

    def test_has_ssh_info(self):
        collector = SecurityCollector()
        result = asyncio.run(collector.collect())
        assert "ssh_key_count" in result.data


class TestPackageManagerCollector:
    def test_collect_returns_result(self):
        collector = PackageManagerCollector()
        result = asyncio.run(collector.collect())
        assert isinstance(result, CollectorResult)
        assert result.collector == "package_managers"
        assert isinstance(result.data, list)


class TestIDECollector:
    def test_collect_returns_result(self):
        collector = IDECollector()
        result = asyncio.run(collector.collect())
        assert isinstance(result, CollectorResult)
        assert result.collector == "ides"
        assert isinstance(result.data, list)


class TestAIToolsCollector:
    def test_collect_returns_result(self):
        collector = AIToolsCollector()
        result = asyncio.run(collector.collect())
        assert isinstance(result, CollectorResult)
        assert result.collector == "ai_tools"
        assert isinstance(result.data, list)

    def test_cli_tool_definitions_contain_expected_tools(self):
        """The macOS bundle's AI CLI list covers the canonical tools."""
        from posture_agent.platforms.macos import AI_CLI_TOOLS_MACOS

        tool_binaries = {binary for _, binary, _ in AI_CLI_TOOLS_MACOS}
        expected_binaries = {
            "claude",
            "copilot",
            "aider",
            "kiro",
            "codex",
            "gemini",
            "q",
        }
        assert expected_binaries.issubset(tool_binaries), (
            f"Missing binaries: {expected_binaries - tool_binaries}"
        )

    def test_detects_copilot_cli(self):
        """GitHub Copilot CLI is detected via the platform bundle."""
        from unittest.mock import AsyncMock, MagicMock

        collector = AIToolsCollector()

        bundle = MagicMock()
        bundle.ides.installed_ai_tools = AsyncMock(
            return_value=(
                [
                    {
                        "name": "GitHub Copilot CLI",
                        "type": "cli",
                        "binary": "copilot",
                        "version": "1.0.0",
                    }
                ],
                [],
            )
        )

        with (
            patch("posture_agent.collectors.ai_tools.get_bundle", return_value=bundle),
            patch("posture_agent.collectors.ai_tools.shutil.which", return_value=None),
        ):
            result = asyncio.run(collector.collect())

        tools = [t for t in result.data if t["binary"] == "copilot"]
        assert len(tools) == 1
        assert tools[0]["name"] == "GitHub Copilot CLI"
        assert tools[0]["type"] == "cli"
        assert tools[0]["version"] == "1.0.0"

    def test_detects_kiro(self):
        """Kiro (AWS) is detected via the platform bundle."""
        from unittest.mock import AsyncMock, MagicMock

        collector = AIToolsCollector()

        bundle = MagicMock()
        bundle.ides.installed_ai_tools = AsyncMock(
            return_value=(
                [
                    {
                        "name": "Kiro",
                        "type": "cli",
                        "binary": "kiro",
                        "version": "0.1.0",
                    }
                ],
                [],
            )
        )

        with (
            patch("posture_agent.collectors.ai_tools.get_bundle", return_value=bundle),
            patch("posture_agent.collectors.ai_tools.shutil.which", return_value=None),
        ):
            result = asyncio.run(collector.collect())

        tools = [t for t in result.data if t["binary"] == "kiro"]
        assert len(tools) == 1
        assert tools[0]["name"] == "Kiro"
        assert tools[0]["type"] == "cli"
        assert tools[0]["version"] == "0.1.0"

    def test_detects_amazon_q_cli(self):
        """Amazon Q Developer CLI is detected via the platform bundle."""
        from unittest.mock import AsyncMock, MagicMock

        collector = AIToolsCollector()

        bundle = MagicMock()
        bundle.ides.installed_ai_tools = AsyncMock(
            return_value=(
                [
                    {
                        "name": "Amazon Q Developer CLI",
                        "type": "cli",
                        "binary": "q",
                        "version": "2.1.0",
                    }
                ],
                [],
            )
        )

        with (
            patch("posture_agent.collectors.ai_tools.get_bundle", return_value=bundle),
            patch("posture_agent.collectors.ai_tools.shutil.which", return_value=None),
        ):
            result = asyncio.run(collector.collect())

        tools = [t for t in result.data if t["binary"] == "q"]
        assert len(tools) == 1
        assert tools[0]["name"] == "Amazon Q Developer CLI"
        assert tools[0]["type"] == "cli"
        assert tools[0]["version"] == "2.1.0"

    def test_tool_not_found_skipped(self):
        """When the bundle reports no tools and no editor extensions exist,
        ``data`` is empty and no errors surface."""
        from unittest.mock import AsyncMock, MagicMock

        collector = AIToolsCollector()

        bundle = MagicMock()
        bundle.ides.installed_ai_tools = AsyncMock(return_value=([], []))

        with (
            patch("posture_agent.collectors.ai_tools.get_bundle", return_value=bundle),
            patch("posture_agent.collectors.ai_tools.shutil.which", return_value=None),
        ):
            result = asyncio.run(collector.collect())

        assert result.data == []
        assert result.errors == []

    def test_ai_extension_version_populated_from_shim(self):
        """AI extensions emit the version reported by `--list-extensions
        --show-versions`, matching the IDE Extensions card."""
        from unittest.mock import AsyncMock, MagicMock

        collector = AIToolsCollector()

        bundle = MagicMock()
        bundle.ides.installed_ai_tools = AsyncMock(return_value=([], []))

        async def fake_run_command(*args, **kwargs):
            # Simulate `code --list-extensions --show-versions` output for
            # a darkknight-style machine with Copilot + Copilot Chat.
            return "github.copilot@1.272.0\ngithub.copilot-chat@0.27.3\nms-python.python@2024.0.1\n"

        def fake_which(binary):
            return "/usr/local/bin/code" if binary == "code" else None

        with (
            patch("posture_agent.collectors.ai_tools.get_bundle", return_value=bundle),
            patch("posture_agent.collectors.ai_tools.shutil.which", side_effect=fake_which),
            patch(
                "posture_agent.collectors.ai_tools.run_command",
                side_effect=fake_run_command,
            ),
        ):
            result = asyncio.run(collector.collect())

        copilot = next(
            (t for t in result.data if t.get("name") == "github.copilot"),
            None,
        )
        assert copilot is not None
        assert copilot["type"] == "extension"
        assert copilot["editor"] == "VS Code"
        assert copilot["version"] == "1.272.0"

        chat = next(
            (t for t in result.data if t.get("name") == "github.copilot-chat"),
            None,
        )
        assert chat is not None
        assert chat["version"] == "0.27.3"

    def test_ai_extension_version_empty_when_shim_omits_version(self):
        """If the shim emits bare ids (older editor without
        `--show-versions` support), the AI tool entry falls back to
        ``version: ""`` rather than crashing."""
        from unittest.mock import AsyncMock, MagicMock

        collector = AIToolsCollector()

        bundle = MagicMock()
        bundle.ides.installed_ai_tools = AsyncMock(return_value=([], []))

        async def fake_run_command(*args, **kwargs):
            return "github.copilot\nms-python.python\n"

        def fake_which(binary):
            return "/usr/local/bin/code" if binary == "code" else None

        with (
            patch("posture_agent.collectors.ai_tools.get_bundle", return_value=bundle),
            patch("posture_agent.collectors.ai_tools.shutil.which", side_effect=fake_which),
            patch(
                "posture_agent.collectors.ai_tools.run_command",
                side_effect=fake_run_command,
            ),
        ):
            result = asyncio.run(collector.collect())

        copilot = next(
            (t for t in result.data if t.get("name") == "github.copilot"),
            None,
        )
        assert copilot is not None
        assert copilot["version"] == ""


class TestExtensionCollector:
    def test_collect_returns_result(self):
        collector = ExtensionCollector()
        result = asyncio.run(collector.collect())
        assert isinstance(result, CollectorResult)
        assert result.collector == "extensions"
        assert isinstance(result.data, dict)


class TestMCPServersCollector:
    def test_collect_returns_result(self):
        collector = MCPServersCollector()
        result = asyncio.run(collector.collect())
        assert isinstance(result, CollectorResult)
        assert result.collector == "mcp_servers"
        assert isinstance(result.data, list)

    def test_risk_indicators_detects_shell(self):
        server = {"command": "bash", "args": ["-c", "echo test"]}
        risks = detect_risk_indicators(server)
        assert "shell" in risks

    def test_risk_indicators_detects_credentials(self):
        server = {"command": "npx", "env": {"GITHUB_TOKEN": "xxx", "API_KEY": "yyy"}}
        risks = detect_risk_indicators(server)
        assert "credentials" in risks

    def test_risk_indicators_detects_network(self):
        server = {"transport": "sse", "url": "https://example.com/mcp"}
        risks = detect_risk_indicators(server)
        assert "network" in risks

    def test_risk_indicators_detects_filesystem(self):
        server = {"command": "node", "args": ["/path/to/server.js"]}
        risks = detect_risk_indicators(server)
        assert "filesystem" in risks
