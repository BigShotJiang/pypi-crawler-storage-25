"""Tests for config env overrides, agent_version, and logging setup."""

import logging
import os
import sys
from unittest.mock import patch

import pytest
from posture_agent.core.config import Settings
from posture_agent.core.logging import setup_agent_logging
from posture_agent.main import _get_os_version, _pip_user_bin_candidates


class TestSettingsEnvOverrides:
    """Test environment variable overrides for Settings."""

    def test_intercept_api_url_override(self):
        with patch.dict(os.environ, {"INTERCEPT_API_URL": "https://custom.example.com"}):
            settings = Settings()
        assert settings.api.url == "https://custom.example.com"

    def test_intercept_api_key_override(self):
        with patch.dict(os.environ, {"INTERCEPT_API_KEY": "hsk_test_override"}):
            settings = Settings()
        assert settings.api.api_key == "hsk_test_override"

    def test_intercept_tenant_id_override(self):
        with patch.dict(os.environ, {"INTERCEPT_TENANT_ID": "tenant-override-123"}):
            settings = Settings()
        assert settings.api.tenant_id == "tenant-override-123"

    def test_all_overrides_together(self):
        env = {
            "INTERCEPT_API_URL": "https://all.example.com",
            "INTERCEPT_API_KEY": "hsk_all_key",
            "INTERCEPT_TENANT_ID": "tenant-all",
        }
        with patch.dict(os.environ, env):
            settings = Settings()
        assert settings.api.url == "https://all.example.com"
        assert settings.api.api_key == "hsk_all_key"
        assert settings.api.tenant_id == "tenant-all"


class TestSettingsEnrolledEmail:
    """Test that `enrolled_email` loads from `~/.config/intercept/agent.yaml`."""

    def test_enrolled_email_loaded_from_user_config(self, tmp_path):
        """When the user config sets `api.enrolled_email`, Settings exposes it."""
        config_dir = tmp_path / ".config" / "intercept"
        config_dir.mkdir(parents=True)
        (config_dir / "agent.yaml").write_text(
            "api:\n"
            '  url: "http://localhost"\n'
            '  api_key: "hsk_test"\n'
            '  enrolled_email: "dev@example.com"\n'
        )
        with patch("pathlib.Path.home", return_value=tmp_path):
            settings = Settings()
        assert settings.api.enrolled_email == "dev@example.com"

    def test_enrolled_email_defaults_to_none(self, tmp_path):
        """When the user config has no `enrolled_email`, the field is None (not '')."""
        config_dir = tmp_path / ".config" / "intercept"
        config_dir.mkdir(parents=True)
        (config_dir / "agent.yaml").write_text(
            'api:\n  url: "http://localhost"\n  api_key: "hsk_test"\n'
        )
        with patch("pathlib.Path.home", return_value=tmp_path):
            settings = Settings()
        assert settings.api.enrolled_email is None


class TestSettingsAgentVersion:
    """Test agent_version property.

    The agent may be installed under either ``intercept-agent`` (prod PyPI)
    or ``intercept-agent-test`` (Test PyPI alias) — both must resolve a real
    version. When neither is installed (source checkout, frozen build), we
    fall back to the bundled ``VERSION`` file. ``"0.0.0"`` is the last-resort
    sentinel and indicates a bug.
    """

    def test_version_from_file(self):
        settings = Settings()
        version = settings.agent_version
        # Should return something version-like — never the 0.0.0 sentinel.
        assert version
        assert version != "0.0.0"
        parts = version.split(".")
        assert len(parts) >= 2  # At minimum major.minor

    def test_prefers_intercept_agent_metadata(self):
        """When `intercept-agent` is installed, its metadata wins."""
        from posture_agent.core import config as config_mod

        def fake_version(name):
            if name == "intercept-agent":
                return "9.9.9"
            raise config_mod.PackageNotFoundError(name)

        with patch.object(config_mod, "version", side_effect=fake_version):
            assert Settings().agent_version == "9.9.9"

    def test_falls_back_to_intercept_agent_test_metadata(self):
        """Test PyPI alias `intercept-agent-test` is recognised when prod is missing."""
        from posture_agent.core import config as config_mod

        def fake_version(name):
            if name == "intercept-agent-test":
                return "0.4.2"
            raise config_mod.PackageNotFoundError(name)

        with patch.object(config_mod, "version", side_effect=fake_version):
            assert Settings().agent_version == "0.4.2"

    def test_falls_back_to_bundled_version_file(self, tmp_path):
        """When neither distribution is installed, read the VERSION resource."""
        from posture_agent.core import config as config_mod

        def fake_version(name):
            raise config_mod.PackageNotFoundError(name)

        # Stub `importlib.resources.files("posture_agent") / "VERSION"` to a
        # tmp file so we don't depend on whether the test environment has a
        # `posture_agent/VERSION` resource on disk.
        sentinel = tmp_path / "VERSION"
        sentinel.write_text("1.2.3\n")

        class FakeTraversable:
            def __init__(self, path):
                self._path = path

            def joinpath(self, *parts):
                return FakeTraversable(self._path)

            def read_text(self, encoding="utf-8"):
                return self._path.read_text(encoding=encoding)

        with (
            patch.object(config_mod, "version", side_effect=fake_version),
            patch.object(config_mod, "files", return_value=FakeTraversable(sentinel)),
        ):
            assert Settings().agent_version == "1.2.3"

    def test_source_checkout_fallback_when_resource_missing(self, tmp_path):
        """When no metadata and no bundled resource, the source VERSION file wins."""
        from posture_agent.core import config as config_mod

        def fake_version(name):
            raise config_mod.PackageNotFoundError(name)

        def raising_files(_pkg):
            raise ModuleNotFoundError("posture_agent.VERSION resource missing")

        with (
            patch.object(config_mod, "version", side_effect=fake_version),
            patch.object(config_mod, "files", side_effect=raising_files),
        ):
            # Real source-checkout VERSION is at services/posture-agent/VERSION
            settings = Settings()
            v = settings.agent_version
        assert v
        assert v != "0.0.0"


class TestLoggingSetup:
    """Test logging setup function."""

    def test_default_text_format(self):
        setup_agent_logging()
        root_logger = logging.getLogger()
        assert root_logger.level == logging.INFO

    def test_debug_level(self):
        setup_agent_logging({"level": "DEBUG"})
        root_logger = logging.getLogger()
        assert root_logger.level == logging.DEBUG

    def test_json_format(self):
        setup_agent_logging({"level": "INFO", "console": {"format": "json"}})
        root_logger = logging.getLogger()
        # Check that a handler exists with JSON format
        handler = root_logger.handlers[-1]
        assert "timestamp" in handler.formatter._fmt

    def test_none_config(self):
        setup_agent_logging(None)
        root_logger = logging.getLogger()
        assert root_logger.level == logging.INFO


class TestGetOsVersion:
    """Test _get_os_version helper."""

    def test_darwin_returns_mac_ver(self):
        with (
            patch("platform.system", return_value="Darwin"),
            patch("platform.mac_ver", return_value=("15.2", ("", "", ""), "")),
        ):
            assert _get_os_version() == "15.2"

    def test_darwin_empty_mac_ver_falls_back(self):
        with (
            patch("platform.system", return_value="Darwin"),
            patch("platform.mac_ver", return_value=("", ("", "", ""), "")),
            patch("platform.release", return_value="24.0.0"),
        ):
            assert _get_os_version() == "24.0.0"

    def test_linux_returns_release(self):
        with (
            patch("platform.system", return_value="Linux"),
            patch("platform.release", return_value="6.1.0"),
        ):
            assert _get_os_version() == "6.1.0"


@pytest.mark.skipif(sys.platform != "darwin", reason="macOS-specific test")
class TestPipUserBinCandidates:
    """Test _pip_user_bin_candidates helper."""

    def test_darwin_includes_library_python(self, tmp_path):
        lib_python = tmp_path / "Library" / "Python" / "3.12"
        lib_python.mkdir(parents=True)

        with (
            patch("platform.system", return_value="Darwin"),
            patch("pathlib.Path.home", return_value=tmp_path),
        ):
            candidates = _pip_user_bin_candidates()

        # Should include macOS Library/Python path and .local/bin
        paths_str = [str(c) for c in candidates]
        assert any("Library/Python/3.12/bin" in p for p in paths_str)
        assert any(".local/bin" in p for p in paths_str)

    def test_darwin_no_library_python(self, tmp_path):
        # No Library/Python dir exists
        with (
            patch("platform.system", return_value="Darwin"),
            patch("pathlib.Path.home", return_value=tmp_path),
        ):
            candidates = _pip_user_bin_candidates()

        paths_str = [str(c) for c in candidates]
        # Should still have .local/bin fallback
        assert any(".local/bin" in p for p in paths_str)
