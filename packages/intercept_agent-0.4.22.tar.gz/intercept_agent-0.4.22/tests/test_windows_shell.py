"""Tests for the C10 Windows shell PATH expander.

Path expansion is exercised against fake user-profile trees built under
``tmp_path``. We never write real binaries; just empty directories whose
existence drives the filtering.
"""

from __future__ import annotations

from pathlib import Path

from posture_agent.platforms import windows


def _seed(root: Path, *segments: tuple[str, ...]) -> list[Path]:
    """Create directory chains under ``root`` and return their final paths."""
    out: list[Path] = []
    for parts in segments:
        d = root.joinpath(*parts)
        d.mkdir(parents=True, exist_ok=True)
        out.append(d)
    return out


class TestExpandedPath:
    def test_includes_existing_overlays(self, monkeypatch, tmp_path: Path):
        # Lay out a few overlay dirs that should be picked up.
        appdata = tmp_path / "AppData" / "Roaming"
        localappdata = tmp_path / "AppData" / "Local"
        programfiles = tmp_path / "Program Files"

        npm = appdata / "npm"
        cargo_bin = tmp_path / ".cargo" / "bin"
        git_cmd = programfiles / "Git" / "cmd"
        for d in (npm, cargo_bin, git_cmd):
            d.mkdir(parents=True)

        monkeypatch.setenv("PATH", r"C:\base;C:\windows")
        monkeypatch.setenv("APPDATA", str(appdata))
        monkeypatch.setenv("LOCALAPPDATA", str(localappdata))
        monkeypatch.setenv("PROGRAMFILES", str(programfiles))
        monkeypatch.setenv("PROGRAMFILES(X86)", str(tmp_path / "missing-x86"))
        monkeypatch.setattr(Path, "home", lambda: tmp_path)

        result = windows.WindowsShellPathExpander().expanded_path()

        assert result.startswith(r"C:\base;C:\windows")
        assert ";" in result  # Windows separator
        assert str(npm) in result
        assert str(cargo_bin) in result
        assert str(git_cmd) in result
        # A non-existent entry must not appear.
        assert str(localappdata / "nvs") not in result

    def test_filters_nonexistent(self, monkeypatch, tmp_path: Path):
        # No overlay dirs exist — only the base PATH should come back.
        monkeypatch.setenv("PATH", r"C:\base")
        monkeypatch.setenv("APPDATA", str(tmp_path / "missing-appdata"))
        monkeypatch.setenv("LOCALAPPDATA", str(tmp_path / "missing-localappdata"))
        monkeypatch.setenv("PROGRAMFILES", str(tmp_path / "missing-pf"))
        monkeypatch.setenv("PROGRAMFILES(X86)", str(tmp_path / "missing-pf86"))
        monkeypatch.setattr(Path, "home", lambda: tmp_path)

        result = windows.WindowsShellPathExpander().expanded_path()

        assert result == r"C:\base"

    def test_returns_overlays_only_when_path_empty(self, monkeypatch, tmp_path: Path):
        appdata = tmp_path / "AppData" / "Roaming"
        npm = appdata / "npm"
        npm.mkdir(parents=True)

        monkeypatch.setenv("PATH", "")
        monkeypatch.setenv("APPDATA", str(appdata))
        monkeypatch.setenv("LOCALAPPDATA", str(tmp_path / "missing-localappdata"))
        monkeypatch.setenv("PROGRAMFILES", str(tmp_path / "missing-pf"))
        monkeypatch.setenv("PROGRAMFILES(X86)", str(tmp_path / "missing-pf86"))
        monkeypatch.setattr(Path, "home", lambda: tmp_path)

        result = windows.WindowsShellPathExpander().expanded_path()

        # No leading separator, just the overlay.
        assert result == str(npm)


class TestPipUserBinCandidates:
    def test_finds_python311_scripts(self, monkeypatch, tmp_path: Path):
        appdata = tmp_path / "AppData" / "Roaming"
        scripts = appdata / "Python" / "Python311" / "Scripts"
        scripts.mkdir(parents=True)

        monkeypatch.setenv("APPDATA", str(appdata))
        monkeypatch.setattr(Path, "home", lambda: tmp_path)

        candidates = windows.WindowsShellPathExpander().pip_user_bin_candidates()

        assert (scripts / "intercept-agent.exe") in candidates

    def test_falls_back_when_no_python_root(self, monkeypatch, tmp_path: Path):
        appdata = tmp_path / "AppData" / "Roaming"
        # Do NOT create %APPDATA%\Python.

        monkeypatch.setenv("APPDATA", str(appdata))
        monkeypatch.setattr(Path, "home", lambda: tmp_path)

        candidates = windows.WindowsShellPathExpander().pip_user_bin_candidates()

        # Only the legacy fallback should appear.
        assert candidates == [appdata / "Python" / "Scripts" / "intercept-agent.exe"]

    def test_handles_multiple_python_versions(self, monkeypatch, tmp_path: Path):
        appdata = tmp_path / "AppData" / "Roaming"
        py311_scripts = appdata / "Python" / "Python311" / "Scripts"
        py312_scripts = appdata / "Python" / "Python312" / "Scripts"
        py311_scripts.mkdir(parents=True)
        py312_scripts.mkdir(parents=True)

        monkeypatch.setenv("APPDATA", str(appdata))
        monkeypatch.setattr(Path, "home", lambda: tmp_path)

        candidates = windows.WindowsShellPathExpander().pip_user_bin_candidates()

        assert (py311_scripts / "intercept-agent.exe") in candidates
        assert (py312_scripts / "intercept-agent.exe") in candidates
        # Sorted reverse so Python312 should come before Python311.
        py311_idx = candidates.index(py311_scripts / "intercept-agent.exe")
        py312_idx = candidates.index(py312_scripts / "intercept-agent.exe")
        assert py312_idx < py311_idx
