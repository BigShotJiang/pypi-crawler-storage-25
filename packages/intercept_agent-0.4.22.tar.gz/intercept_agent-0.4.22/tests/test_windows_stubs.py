"""Tests for the Windows platform stubs (C5).

Originally exercised the ``NotImplementedError`` stubs. As real
implementations have landed (C6-C12), only the factory-dispatch / bundle
shape tests remain here — the per-slot behavior is covered by dedicated
test files (test_windows_hardware, test_windows_security, etc.).

These tests run on macOS / Linux CI by patching ``platform.system``.
"""

from __future__ import annotations

from unittest.mock import patch

import pytest
from posture_agent import platforms
from posture_agent.platforms import windows
from posture_agent.platforms.base import PlatformBundle


class TestFactoryDispatch:
    """``platforms.detect()`` must dispatch to ``windows.bundle()`` on Windows."""

    def setup_method(self):
        platforms.reset_bundle()

    def teardown_method(self):
        platforms.reset_bundle()

    def test_factory_dispatches_to_windows_when_system_is_windows(self):
        with patch("posture_agent.platforms.platform.system", return_value="Windows"):
            bundle = platforms.detect()

        assert isinstance(bundle, PlatformBundle)
        assert bundle.hardware.os_name() == "Windows"
        assert isinstance(bundle.hardware, windows.WindowsHardware)
        assert isinstance(bundle.security, windows.WindowsSecurityPosture)
        assert isinstance(bundle.ssh_agent, windows.WindowsSshAgent)
        assert isinstance(bundle.ides, windows.WindowsIDEDiscovery)
        assert isinstance(bundle.mcp_paths, windows.WindowsMCPHostPaths)
        assert isinstance(bundle.path_expander, windows.WindowsShellPathExpander)
        assert isinstance(bundle.scheduler, windows.WindowsScheduler)

    def test_get_bundle_caches_windows_dispatch(self):
        with patch("posture_agent.platforms.platform.system", return_value="Windows"):
            first = platforms.get_bundle()
            second = platforms.get_bundle()
        assert first is second

    def test_unsupported_platform_still_raises(self):
        with patch("posture_agent.platforms.platform.system", return_value="FreeBSD"):
            with pytest.raises(platforms.UnsupportedPlatformError):
                platforms.detect()


class TestWindowsHardwareStubs:
    """``os_name`` returns ``Windows``; the remaining stubs landed in C6."""

    def test_os_name_returns_windows(self):
        hw = windows.WindowsHardware()
        assert hw.os_name() == "Windows"


class TestBundleFactory:
    """``windows.bundle()`` must build a structurally valid ``PlatformBundle``."""

    def test_bundle_returns_platform_bundle(self):
        b = windows.bundle()
        assert isinstance(b, PlatformBundle)
        assert b.hardware.os_name() == "Windows"
