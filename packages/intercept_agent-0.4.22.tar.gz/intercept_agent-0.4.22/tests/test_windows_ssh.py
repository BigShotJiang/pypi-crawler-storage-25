"""Tests for the C8 Windows SSH agent detector.

Runs on macOS / Linux CI by patching ``posture_agent.platforms.windows.run_ps``
(the import-site lookup). Covers all three priority paths plus the
graceful-degrade behaviour when PowerShell is unavailable or returns errors.
"""

from __future__ import annotations

from unittest.mock import patch

from posture_agent.platforms import windows
from posture_agent.platforms.powershell import PSError, PSResult


def _ok(data: object) -> PSResult:
    return PSResult(ok=True, data=data, error=None, stderr="", duration_ms=42)


def _err(kind: str, message: str = "boom") -> PSResult:
    return PSResult(
        ok=False,
        data=None,
        error=PSError(kind=kind, message=message),
        stderr=message,
        duration_ms=42,
    )


class TestWindowsSshAgentDetect:
    async def test_detect_windows_openssh_running(self):
        """Service status int 4 (Running) → windows_openssh."""
        with patch(
            "posture_agent.platforms.windows.run_ps",
            return_value=_ok({"Status": 4}),
        ):
            info = await windows.WindowsSshAgent().detect()

        assert info.agent_type == "windows_openssh"
        assert info.socket_path == r"\\.\pipe\openssh-ssh-agent"
        assert info.key_count is None

    async def test_detect_windows_openssh_running_string_status(self):
        """Service status as the serialized enum name ``"Running"``."""
        with patch(
            "posture_agent.platforms.windows.run_ps",
            return_value=_ok({"Status": "Running"}),
        ):
            info = await windows.WindowsSshAgent().detect()

        assert info.agent_type == "windows_openssh"
        assert info.socket_path == r"\\.\pipe\openssh-ssh-agent"

    async def test_detect_windows_openssh_stopped_falls_through_to_pageant(self):
        """ssh-agent stopped (Status=1) → check Pageant next; pageant proc found."""
        results = iter(
            [
                _ok({"Status": 1}),  # ssh-agent stopped
                _ok({"Id": 1234}),  # pageant.exe running
            ]
        )
        with patch(
            "posture_agent.platforms.windows.run_ps",
            side_effect=lambda *_args, **_kwargs: next(results),
        ):
            info = await windows.WindowsSshAgent().detect()

        assert info.agent_type == "pageant"
        assert info.socket_path is None
        assert info.key_count is None

    async def test_detect_pageant_only(self):
        """First call returns no service data; second call returns pageant."""
        results = iter(
            [
                _ok(None),  # ssh-agent missing
                _ok({"Id": 5678}),  # pageant.exe running
            ]
        )
        with patch(
            "posture_agent.platforms.windows.run_ps",
            side_effect=lambda *_args, **_kwargs: next(results),
        ):
            info = await windows.WindowsSshAgent().detect()

        assert info.agent_type == "pageant"
        assert info.socket_path is None

    async def test_detect_no_agent(self):
        """Neither service nor pageant present → agent_type=None."""
        results = iter([_ok(None), _ok(None)])
        with patch(
            "posture_agent.platforms.windows.run_ps",
            side_effect=lambda *_args, **_kwargs: next(results),
        ):
            info = await windows.WindowsSshAgent().detect()

        assert info.agent_type is None
        assert info.socket_path is None
        assert info.key_count is None

    async def test_detect_handles_powershell_failure(self):
        """Both PowerShell calls fail (e.g., unsupported / cmdlet missing)."""
        results = iter(
            [
                _err("unsupported", "powershell unavailable on Darwin"),
                _err("unsupported", "powershell unavailable on Darwin"),
            ]
        )
        with patch(
            "posture_agent.platforms.windows.run_ps",
            side_effect=lambda *_args, **_kwargs: next(results),
        ):
            info = await windows.WindowsSshAgent().detect()

        assert info.agent_type is None
        assert info.socket_path is None
        assert info.key_count is None
