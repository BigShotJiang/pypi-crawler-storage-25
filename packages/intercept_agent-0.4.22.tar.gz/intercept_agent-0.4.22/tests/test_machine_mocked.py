"""Tests for the machine collector with mocked commands."""

import asyncio
import sys
from unittest.mock import patch

import pytest
from posture_agent.collectors.machine import MachineCollector


@pytest.mark.skipif(sys.platform != "darwin", reason="macOS-specific test")
class TestMachineCollectorErrors:
    """Test error handling when system commands fail."""

    def test_cpu_brand_error_caught(self):
        collector = MachineCollector()

        async def mock_run(cmd, *args):
            if cmd == "sysctl" and args == ("-n", "machdep.cpu.brand_string"):
                raise RuntimeError("sysctl failed")
            if cmd == "sysctl" and args == ("-n", "hw.memsize"):
                return "17179869184\n"
            return None

        with (
            patch("posture_agent.platforms.macos.run_command", side_effect=mock_run),
            patch("posture_agent.platforms.base.os.cpu_count", return_value=8),
        ):
            result = asyncio.run(collector.collect())

        assert result.data["cpu_brand"] == ""
        assert any("CPU brand" in e for e in result.errors)
        assert result.data["cpu_cores"] == 8

    def test_cpu_cores_error_caught(self):
        collector = MachineCollector()

        async def mock_run(cmd, *args):
            if cmd == "sysctl" and args == ("-n", "machdep.cpu.brand_string"):
                return "Apple M3 Pro\n"
            if cmd == "sysctl" and args == ("-n", "hw.memsize"):
                return "17179869184\n"
            return None

        with (
            patch("posture_agent.platforms.macos.run_command", side_effect=mock_run),
            patch(
                "posture_agent.platforms.macos.logical_cpu_count",
                side_effect=RuntimeError("cpu_count failed"),
            ),
        ):
            result = asyncio.run(collector.collect())

        assert result.data["cpu_brand"] == "Apple M3 Pro"
        assert result.data["cpu_cores"] == 0
        assert any("CPU cores" in e for e in result.errors)

    def test_memory_error_caught(self):
        collector = MachineCollector()

        async def mock_run(cmd, *args):
            if cmd == "sysctl" and args == ("-n", "machdep.cpu.brand_string"):
                return "Apple M3 Pro\n"
            if cmd == "sysctl" and args == ("-n", "hw.memsize"):
                raise RuntimeError("sysctl failed")
            return None

        with (
            patch("posture_agent.platforms.macos.run_command", side_effect=mock_run),
            patch("posture_agent.platforms.base.os.cpu_count", return_value=12),
        ):
            result = asyncio.run(collector.collect())

        assert result.data["memory_gb"] == 0
        assert any("Memory" in e for e in result.errors)

    def test_cpu_count_none_falls_back_to_multiprocessing(self):
        """B2: when os.cpu_count() returns None we must NOT report 0.

        Mirrors the Windows-on-test scenario where ``hw.cpu_cores()`` was
        missing and the collector silently emitted ``cpu_cores=0``. With
        the fallback, a sensible value flows through whenever the OS
        reports nothing but Python can still derive a count.
        """
        collector = MachineCollector()

        async def mock_run(cmd, *args):
            if cmd == "sysctl" and args == ("-n", "machdep.cpu.brand_string"):
                return "Apple M3 Pro\n"
            if cmd == "sysctl" and args == ("-n", "hw.memsize"):
                return "17179869184\n"
            return None

        with (
            patch("posture_agent.platforms.macos.run_command", side_effect=mock_run),
            patch("posture_agent.platforms.base.os.cpu_count", return_value=None),
            patch("multiprocessing.cpu_count", return_value=12),
        ):
            result = asyncio.run(collector.collect())

        assert result.data["cpu_cores"] == 12

    def test_cpu_brand_returns_none(self):
        """When every CPU-count source fails, the agent reports 0 (=unknown).

        ``0`` is the schema's "unknown" sentinel — it is not an error.
        """
        collector = MachineCollector()

        async def mock_run(cmd, *args):
            if cmd == "sysctl" and args == ("-n", "machdep.cpu.brand_string"):
                return None
            if cmd == "sysctl" and args == ("-n", "hw.memsize"):
                return None
            return None

        with (
            patch("posture_agent.platforms.macos.run_command", side_effect=mock_run),
            patch("posture_agent.platforms.base.os.cpu_count", return_value=None),
            patch(
                "multiprocessing.cpu_count",
                side_effect=NotImplementedError("nothing reports cpu count"),
            ),
        ):
            result = asyncio.run(collector.collect())

        assert result.data["cpu_brand"] == ""
        assert result.data["cpu_cores"] == 0
        assert result.data["memory_gb"] == 0

    def test_memory_calculation(self):
        collector = MachineCollector()

        async def mock_run(cmd, *args):
            if cmd == "sysctl" and args == ("-n", "machdep.cpu.brand_string"):
                return "Apple M3 Max\n"
            if cmd == "sysctl" and args == ("-n", "hw.memsize"):
                # 36 GB
                return str(36 * 1024**3) + "\n"
            return None

        with (
            patch("posture_agent.platforms.macos.run_command", side_effect=mock_run),
            patch("posture_agent.platforms.base.os.cpu_count", return_value=16),
        ):
            result = asyncio.run(collector.collect())

        assert result.data["cpu_brand"] == "Apple M3 Max"
        assert result.data["cpu_cores"] == 16
        assert result.data["memory_gb"] == 36.0
