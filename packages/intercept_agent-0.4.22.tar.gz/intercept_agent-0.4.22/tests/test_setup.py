"""Tests for the setup (enrollment) CLI command."""

import os
import stat
import sys
from unittest.mock import MagicMock, patch

import httpx
import pytest
import yaml
from click.testing import CliRunner
from posture_agent.main import _mask_key, cli


class TestSetupTokenValidation:
    """Test token format validation."""

    def test_invalid_token_prefix_rejected(self):
        """A token not starting with hse_ should be rejected."""
        runner = CliRunner()
        result = runner.invoke(cli, ["setup", "--token", "bad_token_123"])
        assert result.exit_code == 1
        assert "Invalid enrollment token" in result.output
        assert "hse_" in result.output

    def test_empty_token_rejected(self):
        """An empty token should be rejected."""
        runner = CliRunner()
        result = runner.invoke(cli, ["setup", "--token", ""])
        assert result.exit_code == 1
        assert "Invalid enrollment token" in result.output

    def test_token_option_required(self):
        """The --token option is required."""
        runner = CliRunner()
        result = runner.invoke(cli, ["setup"])
        assert result.exit_code != 0
        assert "Missing option '--token'" in result.output


class TestSetupExistingConfig:
    """Test behavior when agent is already configured."""

    def test_existing_config_with_api_key_blocks_setup(self, tmp_path):
        """If agent.yaml already has an api_key, setup should refuse and
        emit a platform-independent reconfigure hint that references the
        current interpreter (`sys.executable -m posture_agent`) and the
        new `--force` flag. The legacy bare `intercept-agent` form must
        NOT appear in the suggestion -- it relies on the Scripts dir
        being on PATH which is unreliable on Windows."""
        config_dir = tmp_path / ".config" / "intercept"
        config_dir.mkdir(parents=True)
        config_file = config_dir / "agent.yaml"
        config_file.write_text(
            yaml.dump(
                {
                    "api": {"api_key": "hsk_existing_000", "url": "https://example.com"},
                }
            )
        )

        runner = CliRunner()
        with (
            patch("posture_agent.main.CONFIG_DIR", config_dir),
            patch("posture_agent.main.CONFIG_FILE", config_file),
        ):
            result = runner.invoke(cli, ["setup", "--token", "hse_validtoken"])

        assert result.exit_code == 1
        assert "already configured" in result.output
        # New hint must mention --force and the python -m form anchored to
        # the running interpreter.
        assert "--force" in result.output
        assert "-m posture_agent" in result.output
        assert sys.executable in result.output
        # Legacy bare console-script form must be gone from the suggestion.
        assert "intercept-agent uninstall" not in result.output
        assert "intercept-agent setup" not in result.output

    def test_existing_config_with_force_overwrites(self, tmp_path):
        """`setup --force` must wipe an existing config and re-enroll
        without complaining about the old api_key."""
        config_dir = tmp_path / ".config" / "intercept"
        logs_dir = config_dir / "logs"
        config_dir.mkdir(parents=True)
        logs_dir.mkdir(parents=True)
        config_file = config_dir / "agent.yaml"
        config_file.write_text(
            yaml.dump(
                {
                    "api": {
                        "api_key": "hsk_OLDKEY000000000",
                        "url": "https://old.example.com",
                    },
                }
            )
        )

        mock_response = MagicMock()
        mock_response.status_code = 201
        mock_response.json.return_value = {
            "api_key": "hsk_NEWKEY999999999",
            "tenant_id": "tenant-xyz",
        }
        mock_client = MagicMock()
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client.post.return_value = mock_response

        runner = CliRunner()
        with (
            patch("posture_agent.main.CONFIG_DIR", config_dir),
            patch("posture_agent.main.CONFIG_FILE", config_file),
            patch("posture_agent.main.PLIST_PATH", config_dir / "nonexistent.plist"),
            patch("posture_agent.main.get_machine_fingerprint", return_value="ab" * 16),
            patch("httpx.Client", return_value=mock_client),
            patch("posture_agent.main.get_settings") as mock_settings,
            patch("posture_agent.main.run_collection"),
        ):
            mock_settings.return_value.agent_version = "0.4.20"
            mock_settings.return_value.logging_config = {}
            mock_settings.return_value.debug = False
            mock_settings.return_value.schedule.interval_seconds = 3600
            mock_settings.return_value.api.url = "http://localhost"
            mock_settings.return_value.collectors = MagicMock()
            mock_settings.cache_clear = MagicMock()
            result = runner.invoke(
                cli,
                ["setup", "--token", "hse_newtoken", "--force"],
            )

        assert result.exit_code == 0, result.output
        # The "already configured" guard must not fire.
        assert "already configured" not in result.output
        # Config file must now contain the NEW key, not the old one.
        written = yaml.safe_load(config_file.read_text())
        assert written["api"]["api_key"] == "hsk_NEWKEY999999999"
        assert written["api"]["api_key"] != "hsk_OLDKEY000000000"

    def test_existing_config_without_api_key_allows_setup(self, tmp_path):
        """If agent.yaml exists but has no api_key, setup should proceed."""
        config_dir = tmp_path / ".config" / "intercept"
        logs_dir = config_dir / "logs"
        config_dir.mkdir(parents=True)
        logs_dir.mkdir(parents=True)
        config_file = config_dir / "agent.yaml"
        config_file.write_text(
            yaml.dump(
                {
                    "api": {"url": "http://localhost:8000"},
                }
            )
        )

        mock_response = MagicMock()
        mock_response.status_code = 201
        mock_response.json.return_value = {
            "api_key": "hsk_newkey_000000",
            "tenant_id": "tenant-abc",
        }

        mock_client = MagicMock()
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client.post.return_value = mock_response

        runner = CliRunner()
        with (
            patch("posture_agent.main.CONFIG_DIR", config_dir),
            patch("posture_agent.main.CONFIG_FILE", config_file),
            patch("posture_agent.main.get_machine_fingerprint", return_value="abcd1234" * 4),
            patch("httpx.Client", return_value=mock_client),
            patch("posture_agent.main.get_settings") as mock_settings,
            patch("posture_agent.main.run_collection"),
        ):
            mock_settings.return_value.agent_version = "0.3.8"
            mock_settings.return_value.logging_config = {}
            mock_settings.return_value.debug = False
            mock_settings.return_value.schedule.interval_seconds = 3600
            mock_settings.return_value.api.url = "http://localhost"
            mock_settings.return_value.collectors = MagicMock()
            mock_settings.cache_clear = MagicMock()
            result = runner.invoke(cli, ["setup", "--token", "hse_validtoken"])

        assert "already configured" not in result.output
        assert "Enrolled successfully" in result.output


def _make_mock_client(response):
    """Create a mock httpx.Client context manager."""
    mock_client = MagicMock()
    mock_client.__enter__ = MagicMock(return_value=mock_client)
    mock_client.__exit__ = MagicMock(return_value=False)
    mock_client.post.return_value = response
    return mock_client


def _make_error_client(error):
    """Create a mock httpx.Client that raises on post."""
    mock_client = MagicMock()
    mock_client.__enter__ = MagicMock(return_value=mock_client)
    mock_client.__exit__ = MagicMock(return_value=False)
    mock_client.post.side_effect = error
    return mock_client


class TestSetupEnrollment:
    """Test the enrollment HTTP call and response handling."""

    def _setup_mocks(self, tmp_path):
        """Set up common mocks for enrollment tests."""
        config_dir = tmp_path / ".config" / "intercept"
        logs_dir = config_dir / "logs"
        config_dir.mkdir(parents=True)
        logs_dir.mkdir(parents=True)
        config_file = config_dir / "agent.yaml"
        return config_dir, config_file

    def _run_setup(
        self,
        runner,
        config_dir,
        config_file,
        mock_client,
        token="hse_test",
        api_url=None,
        run_collection_side_effect=None,
    ):
        """Helper to run setup with common patches."""
        patches = [
            patch("posture_agent.main.CONFIG_DIR", config_dir),
            patch("posture_agent.main.CONFIG_FILE", config_file),
            patch("posture_agent.main.get_machine_fingerprint", return_value="ff" * 16),
            patch("httpx.Client", return_value=mock_client),
            patch("posture_agent.main.get_settings"),
        ]
        if run_collection_side_effect:
            patches.append(
                patch("posture_agent.main.run_collection", side_effect=run_collection_side_effect)
            )
        else:
            patches.append(patch("posture_agent.main.run_collection"))

        args = ["setup", "--token", token]
        if api_url:
            args.extend(["--api-url", api_url])

        with (
            patches[0],
            patches[1],
            patches[2],
            patches[3],
            patches[4] as mock_settings,
            patches[5],
        ):
            mock_settings.return_value.agent_version = "0.3.8"
            mock_settings.return_value.logging_config = {}
            mock_settings.return_value.debug = False
            mock_settings.return_value.schedule.interval_seconds = 3600
            mock_settings.return_value.api.url = "http://localhost"
            mock_settings.return_value.collectors = MagicMock()
            mock_settings.cache_clear = MagicMock()
            return runner.invoke(cli, args)

    def test_successful_enrollment(self, tmp_path):
        """A 201 response should write config and succeed."""
        config_dir, config_file = self._setup_mocks(tmp_path)

        mock_response = MagicMock()
        mock_response.status_code = 201
        mock_response.json.return_value = {
            "api_key": "hsk_enrolled_key_abc",
            "tenant_id": "tenant-123",
        }
        mock_client = _make_mock_client(mock_response)

        runner = CliRunner()
        result = self._run_setup(
            runner,
            config_dir,
            config_file,
            mock_client,
            token="hse_enrollment_token",
            api_url="https://test.example.com",
        )

        assert result.exit_code == 0
        assert "Enrolled successfully" in result.output
        assert f"Configuration saved to {config_file}" in result.output

        # Verify config file content
        assert config_file.exists()
        written_config = yaml.safe_load(config_file.read_text())
        assert written_config["api"]["api_key"] == "hsk_enrolled_key_abc"
        assert written_config["api"]["url"] == "https://test.example.com"
        assert "tenant_id" not in written_config.get("api", {})

    @pytest.mark.skipif(sys.platform != "darwin", reason="macOS-specific test")
    def test_config_file_permissions(self, tmp_path):
        """Config file should have 0600 permissions (owner read/write only)."""
        config_dir, config_file = self._setup_mocks(tmp_path)

        mock_response = MagicMock()
        mock_response.status_code = 201
        mock_response.json.return_value = {
            "api_key": "hsk_permstest",
            "tenant_id": "t-1",
        }
        mock_client = _make_mock_client(mock_response)

        runner = CliRunner()
        result = self._run_setup(runner, config_dir, config_file, mock_client)

        assert result.exit_code == 0
        file_mode = stat.S_IMODE(os.stat(config_file).st_mode)
        assert file_mode == 0o600, f"Expected 0600, got {oct(file_mode)}"

    def test_expired_token_410(self, tmp_path):
        """A 410 response should show expiration message."""
        config_dir, config_file = self._setup_mocks(tmp_path)

        mock_response = MagicMock()
        mock_response.status_code = 410
        mock_client = _make_mock_client(mock_response)

        runner = CliRunner()
        result = self._run_setup(runner, config_dir, config_file, mock_client)

        assert result.exit_code == 1
        assert "expired" in result.output.lower()
        assert "admin" in result.output.lower()

    def test_already_enrolled_409(self, tmp_path):
        """A 409 response should show the conflict detail."""
        config_dir, config_file = self._setup_mocks(tmp_path)

        mock_response = MagicMock()
        mock_response.status_code = 409
        mock_response.json.return_value = {"detail": "Machine already enrolled"}
        mock_client = _make_mock_client(mock_response)

        runner = CliRunner()
        result = self._run_setup(runner, config_dir, config_file, mock_client)

        assert result.exit_code == 1
        assert "already enrolled" in result.output.lower()

    def test_invalid_token_401(self, tmp_path):
        """A 401 response should show invalid token message."""
        config_dir, config_file = self._setup_mocks(tmp_path)

        mock_response = MagicMock()
        mock_response.status_code = 401
        mock_client = _make_mock_client(mock_response)

        runner = CliRunner()
        result = self._run_setup(runner, config_dir, config_file, mock_client)

        assert result.exit_code == 1
        assert "Invalid enrollment token" in result.output
        assert "admin" in result.output.lower()

    def test_validation_error_422(self, tmp_path):
        """A 422 response should show validation error message."""
        config_dir, config_file = self._setup_mocks(tmp_path)

        mock_response = MagicMock()
        mock_response.status_code = 422
        mock_client = _make_mock_client(mock_response)

        runner = CliRunner()
        result = self._run_setup(runner, config_dir, config_file, mock_client)

        assert result.exit_code == 1
        assert "Invalid request" in result.output

    def test_unexpected_error_status(self, tmp_path):
        """An unexpected status code should show the code in the message."""
        config_dir, config_file = self._setup_mocks(tmp_path)

        mock_response = MagicMock()
        mock_response.status_code = 500
        mock_client = _make_mock_client(mock_response)

        runner = CliRunner()
        result = self._run_setup(runner, config_dir, config_file, mock_client)

        assert result.exit_code == 1
        assert "500" in result.output
        assert "admin" in result.output.lower()

    def test_connection_error(self, tmp_path):
        """A connection error should show a helpful message."""
        config_dir, config_file = self._setup_mocks(tmp_path)
        mock_client = _make_error_client(httpx.ConnectError("Connection refused"))

        runner = CliRunner()
        result = self._run_setup(runner, config_dir, config_file, mock_client)

        assert result.exit_code == 1
        assert "Could not connect" in result.output

    def test_timeout_error(self, tmp_path):
        """A timeout error should show a helpful message."""
        config_dir, config_file = self._setup_mocks(tmp_path)
        mock_client = _make_error_client(httpx.TimeoutException("Timed out"))

        runner = CliRunner()
        result = self._run_setup(runner, config_dir, config_file, mock_client)

        assert result.exit_code == 1
        assert "timed out" in result.output.lower()

    def test_config_yaml_has_no_tenant_id(self, tmp_path):
        """The written config should not contain tenant_id."""
        config_dir, config_file = self._setup_mocks(tmp_path)

        mock_response = MagicMock()
        mock_response.status_code = 201
        mock_response.json.return_value = {
            "api_key": "hsk_notenant",
            "tenant_id": "tenant-should-not-be-in-config",
        }
        mock_client = _make_mock_client(mock_response)

        runner = CliRunner()
        result = self._run_setup(runner, config_dir, config_file, mock_client)

        assert result.exit_code == 0
        written_config = yaml.safe_load(config_file.read_text())
        assert "tenant_id" not in written_config.get("api", {})

    def test_default_api_url(self, tmp_path):
        """Without --api-url, the default production URL should be used."""
        config_dir, config_file = self._setup_mocks(tmp_path)

        mock_response = MagicMock()
        mock_response.status_code = 201
        mock_response.json.return_value = {
            "api_key": "hsk_default_url",
            "tenant_id": "t-1",
        }
        mock_client = _make_mock_client(mock_response)

        runner = CliRunner()
        result = self._run_setup(runner, config_dir, config_file, mock_client)

        assert result.exit_code == 0
        written_config = yaml.safe_load(config_file.read_text())
        assert "hijacksecurity.com" in written_config["api"]["url"]

    def test_first_collection_failure_does_not_fail_setup(self, tmp_path):
        """If the first collection fails, setup should still succeed."""
        config_dir, config_file = self._setup_mocks(tmp_path)

        mock_response = MagicMock()
        mock_response.status_code = 201
        mock_response.json.return_value = {
            "api_key": "hsk_first_fail",
            "tenant_id": "t-1",
        }
        mock_client = _make_mock_client(mock_response)

        runner = CliRunner()
        result = self._run_setup(
            runner,
            config_dir,
            config_file,
            mock_client,
            run_collection_side_effect=RuntimeError("API down"),
        )

        assert result.exit_code == 0
        assert "enrolled but first report failed" in result.output
        assert "retry automatically" in result.output


class TestSetupEnrolledEmail:
    """Test that the setup flow captures and persists `enrolled_email`."""

    def _setup_dirs(self, tmp_path):
        config_dir = tmp_path / ".config" / "intercept"
        logs_dir = config_dir / "logs"
        config_dir.mkdir(parents=True)
        logs_dir.mkdir(parents=True)
        config_file = config_dir / "agent.yaml"
        return config_dir, config_file

    def _run(self, runner, config_dir, config_file, mock_client):
        with (
            patch("posture_agent.main.CONFIG_DIR", config_dir),
            patch("posture_agent.main.CONFIG_FILE", config_file),
            patch("posture_agent.main.get_machine_fingerprint", return_value="ff" * 16),
            patch("httpx.Client", return_value=mock_client),
            patch("posture_agent.main.get_settings") as mock_settings,
            patch("posture_agent.main.run_collection"),
        ):
            mock_settings.return_value.agent_version = "0.4.14"
            mock_settings.return_value.logging_config = {}
            mock_settings.return_value.debug = False
            mock_settings.return_value.schedule.interval_seconds = 3600
            mock_settings.return_value.api.url = "http://localhost"
            mock_settings.return_value.collectors = MagicMock()
            mock_settings.cache_clear = MagicMock()
            return runner.invoke(cli, ["setup", "--token", "hse_validtoken"])

    def test_enrolled_email_persisted_to_yaml(self, tmp_path):
        """When the enroll response includes `enrolled_email`, it must land in agent.yaml."""
        config_dir, config_file = self._setup_dirs(tmp_path)

        mock_response = MagicMock()
        mock_response.status_code = 201
        mock_response.json.return_value = {
            "api_key": "hsk_with_email",
            "tenant_id": "tenant-uuid",
            "enrolled_email": "creator@example.com",
        }
        mock_client = _make_mock_client(mock_response)

        runner = CliRunner()
        result = self._run(runner, config_dir, config_file, mock_client)

        assert result.exit_code == 0
        written = yaml.safe_load(config_file.read_text())
        assert written["api"]["enrolled_email"] == "creator@example.com"
        assert written["api"]["api_key"] == "hsk_with_email"

    def test_missing_enrolled_email_does_not_crash(self, tmp_path):
        """Older identity service versions omit `enrolled_email` -- setup must not crash."""
        config_dir, config_file = self._setup_dirs(tmp_path)

        mock_response = MagicMock()
        mock_response.status_code = 201
        mock_response.json.return_value = {
            "api_key": "hsk_no_email",
            "tenant_id": "tenant-uuid",
            # No enrolled_email key
        }
        mock_client = _make_mock_client(mock_response)

        runner = CliRunner()
        result = self._run(runner, config_dir, config_file, mock_client)

        assert result.exit_code == 0
        written = yaml.safe_load(config_file.read_text())
        # Field should be absent from YAML when not provided by identity
        assert "enrolled_email" not in written.get("api", {})

    def test_null_enrolled_email_does_not_crash(self, tmp_path):
        """Identity may return `enrolled_email: null` if the creating user was deleted."""
        config_dir, config_file = self._setup_dirs(tmp_path)

        mock_response = MagicMock()
        mock_response.status_code = 201
        mock_response.json.return_value = {
            "api_key": "hsk_null_email",
            "tenant_id": "tenant-uuid",
            "enrolled_email": None,
        }
        mock_client = _make_mock_client(mock_response)

        runner = CliRunner()
        result = self._run(runner, config_dir, config_file, mock_client)

        assert result.exit_code == 0
        written = yaml.safe_load(config_file.read_text())
        # Null email should be omitted from YAML (cleaner than `enrolled_email: null`)
        assert "enrolled_email" not in written.get("api", {})


class TestSetupSchedulerInvocation:
    """Regression coverage for the launch-day Windows bug.

    Before 0.4.20 the installer resolved the ``intercept-agent`` console
    script via PATH and wrote that absolute path into the scheduled task
    (launchd ``ProgramArguments`` / schtasks ``/TR``). On Windows ``pip
    install --user`` lands the console script in
    ``%APPDATA%\\Python\\Python3xx\\Scripts``, which is NOT on the default
    PATH -- so the lookup failed and the installer printed
    ``intercept-agent not found. Pass --bin-path or add pip's bin dir to
    PATH.``. The fix is to always pass
    ``[sys.executable, "-m", "posture_agent", "collect", "--report"]`` to
    the scheduler, which is PATH-independent.

    These tests assert the contract: the recorded program_args must use
    ``sys.executable -m posture_agent`` and must NOT contain the literal
    ``intercept-agent`` token. One assertion per supported platform.
    """

    def _setup_dirs(self, tmp_path):
        config_dir = tmp_path / ".config" / "intercept"
        logs_dir = config_dir / "logs"
        config_dir.mkdir(parents=True)
        logs_dir.mkdir(parents=True)
        config_file = config_dir / "agent.yaml"
        return config_dir, config_file

    def _make_201_client(self):
        mock_response = MagicMock()
        mock_response.status_code = 201
        mock_response.json.return_value = {
            "api_key": "hsk_scheduler_test_000",
            "tenant_id": "t-1",
        }
        mock_client = MagicMock()
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client.post.return_value = mock_response
        return mock_client

    def _run_setup_capturing_scheduler(self, tmp_path):
        """Drive `setup` to completion with a fake scheduler. Returns the
        captured ``program_args`` and the full Click output."""
        config_dir, config_file = self._setup_dirs(tmp_path)

        captured: dict = {}

        class _FakeScheduler:
            def install(self, program_args, interval="hourly"):
                captured["program_args"] = list(program_args)
                captured["interval"] = interval

            def uninstall(self):
                pass

            def status(self):  # pragma: no cover - not exercised
                return None

        fake_bundle = MagicMock()
        fake_bundle.scheduler = _FakeScheduler()

        runner = CliRunner()
        with (
            patch("posture_agent.main.CONFIG_DIR", config_dir),
            patch("posture_agent.main.CONFIG_FILE", config_file),
            patch("posture_agent.main.get_machine_fingerprint", return_value="ab" * 16),
            patch("httpx.Client", return_value=self._make_201_client()),
            patch("posture_agent.main.get_settings") as mock_settings,
            patch("posture_agent.main.run_collection"),
            patch("posture_agent.main.get_bundle", return_value=fake_bundle),
        ):
            mock_settings.return_value.agent_version = "0.4.20"
            mock_settings.return_value.logging_config = {}
            mock_settings.return_value.debug = False
            mock_settings.return_value.schedule.interval_seconds = 3600
            mock_settings.return_value.api.url = "http://localhost"
            mock_settings.return_value.collectors = MagicMock()
            mock_settings.cache_clear = MagicMock()
            result = runner.invoke(cli, ["setup", "--token", "hse_validtoken"])

        return captured, result

    def _assert_uses_python_dash_m(self, captured):
        """Shared invariant: scheduled argv is `sys.executable -m posture_agent
        collect --report` and never the bare `intercept-agent` console
        script."""
        program_args = captured["program_args"]
        assert program_args[0] == sys.executable, (
            f"first arg must be sys.executable, got {program_args[0]!r}"
        )
        assert program_args[1] == "-m"
        assert program_args[2] == "posture_agent"
        assert program_args[3] == "collect"
        assert program_args[4] == "--report"
        # The whole point of the fix: no PATH-dependent console-script token.
        joined = " ".join(program_args)
        assert "intercept-agent" not in joined, (
            f"scheduled argv must not reference the intercept-agent "
            f"console script; got {joined!r}"
        )

    def test_setup_records_python_dash_m_on_darwin(self, tmp_path):
        """On macOS, setup must hand the scheduler `sys.executable -m
        posture_agent collect --report` and announce `Installing launchd
        schedule...`."""
        with patch("posture_agent.main.sys.platform", "darwin"):
            captured, result = self._run_setup_capturing_scheduler(tmp_path)

        assert result.exit_code == 0, result.output
        self._assert_uses_python_dash_m(captured)
        assert "Installing launchd schedule..." in result.output
        # The deprecated "intercept-agent not found / add pip's bin dir to
        # PATH" error must never fire under the new code path.
        assert "intercept-agent not found" not in result.output
        assert "add pip's bin dir to PATH" not in result.output

    def test_setup_records_python_dash_m_on_windows(self, tmp_path):
        """On Windows, setup must hand the scheduler `sys.executable -m
        posture_agent collect --report` and announce `Installing Windows
        Scheduled Task...` (NOT `launchd`)."""
        with patch("posture_agent.main.sys.platform", "win32"):
            captured, result = self._run_setup_capturing_scheduler(tmp_path)

        assert result.exit_code == 0, result.output
        self._assert_uses_python_dash_m(captured)
        assert "Installing Windows Scheduled Task..." in result.output
        assert "launchd" not in result.output
        assert "intercept-agent not found" not in result.output
        assert "add pip's bin dir to PATH" not in result.output

    def test_setup_records_python_dash_m_on_linux(self, tmp_path):
        """On Linux, setup must hand the scheduler `sys.executable -m
        posture_agent collect --report` and announce a systemd-flavored
        message (NOT `launchd`)."""
        with patch("posture_agent.main.sys.platform", "linux"):
            captured, result = self._run_setup_capturing_scheduler(tmp_path)

        assert result.exit_code == 0, result.output
        self._assert_uses_python_dash_m(captured)
        assert "Installing systemd user unit..." in result.output
        assert "launchd" not in result.output


class TestSetupHelp:
    """Test the setup command help output."""

    def test_setup_help(self):
        runner = CliRunner()
        result = runner.invoke(cli, ["setup", "--help"])
        assert result.exit_code == 0
        assert "--token" in result.output
        assert "--api-url" in result.output


class TestMaskKey:
    """Test the _mask_key helper."""

    def test_short_key(self):
        assert _mask_key("hsk_") == "hsk_..."

    def test_normal_key(self):
        result = _mask_key("hsk_a8kM12345678")
        assert result == "hsk_a8kM1234..."

    def test_exact_boundary(self):
        # 12 chars = boundary, len<=12 uses the short path (first 4 chars)
        assert _mask_key("hsk_a8kM1234") == "hsk_..."

    def test_longer_key(self):
        result = _mask_key("hsk_a8kM1234567890abcdef")
        assert result == "hsk_a8kM1234..."
        assert len(result) == 15
