"""Tests for the extension collector with mocked dependencies."""

import asyncio
import json
import zipfile
from unittest.mock import patch

from posture_agent.collectors.base import CollectorResult
from posture_agent.collectors.extensions import _EDITOR_CONFIGS, ExtensionCollector


class TestVSCodeExtensionsCLI:
    """Test VS Code extension collection via CLI."""

    def test_cli_with_versioned_extensions(self):
        collector = ExtensionCollector()

        def mock_which(binary):
            if binary == "code":
                return "/usr/local/bin/code"
            return None

        async def mock_run(cmd, *args):
            if cmd == "code" and args == ("--list-extensions", "--show-versions"):
                return (
                    "ms-python.python@2024.0.1\n"
                    "dbaeumer.vscode-eslint@2.4.4\n"
                    "esbenp.prettier-vscode\n"  # No version
                )
            return None

        with (
            patch("posture_agent.collectors.extensions.run_command", side_effect=mock_run),
            patch("posture_agent.collectors.extensions.shutil.which", side_effect=mock_which),
        ):
            result = asyncio.run(collector.collect())

        assert isinstance(result, CollectorResult)
        assert "vscode" in result.data
        exts = result.data["vscode"]
        assert {"id": "ms-python.python", "version": "2024.0.1"} in exts
        assert {"id": "dbaeumer.vscode-eslint", "version": "2.4.4"} in exts
        assert {"id": "esbenp.prettier-vscode", "version": ""} in exts

    def test_cli_empty_output(self):
        collector = ExtensionCollector()

        def mock_which(binary):
            if binary == "code":
                return "/usr/local/bin/code"
            return None

        async def mock_run(cmd, *args):
            if cmd == "code" and args == ("--list-extensions", "--show-versions"):
                return "\n\n"  # Empty lines
            return None

        with (
            patch("posture_agent.collectors.extensions.run_command", side_effect=mock_run),
            patch("posture_agent.collectors.extensions.shutil.which", side_effect=mock_which),
        ):
            result = asyncio.run(collector.collect())

        # Empty lines should not produce extensions
        assert result.data.get("vscode", []) == []

    def test_no_editors_installed(self, tmp_path):
        collector = ExtensionCollector()

        async def mock_run(cmd, *args):
            return None  # Nothing found

        # Override configs to use tmp_path so filesystem fallback finds nothing
        empty_configs = {
            binary: (key, tmp_path / f".{binary}" / "extensions")
            for binary, (key, _) in _EDITOR_CONFIGS.items()
        }
        empty_ext_dirs = {binary: cfg[1] for binary, cfg in empty_configs.items()}

        with (
            patch("posture_agent.collectors.extensions.run_command", side_effect=mock_run),
            patch("posture_agent.collectors.extensions.shutil.which", return_value=None),
            patch("posture_agent.collectors.extensions._EDITOR_CONFIGS", empty_configs),
            patch("posture_agent.collectors.extensions._EXT_DIRS", empty_ext_dirs),
            patch("posture_agent.collectors.extensions.Path.home", return_value=tmp_path),
        ):
            result = asyncio.run(collector.collect())

        assert result.data == {}


class TestVSCodeExtensionsFilesystem:
    """Test VS Code extension collection via filesystem fallback."""

    def test_filesystem_fallback(self, tmp_path):
        collector = ExtensionCollector()

        # Create fake extension dirs
        ext_dir = tmp_path / ".vscode" / "extensions"
        ext_dir.mkdir(parents=True)

        ext1 = ext_dir / "ms-python.python-2024.0.1"
        ext1.mkdir()
        (ext1 / "package.json").write_text(
            json.dumps(
                {
                    "publisher": "ms-python",
                    "name": "python",
                    "version": "2024.0.1",
                }
            )
        )

        ext2 = ext_dir / "dbaeumer.vscode-eslint-2.4.4"
        ext2.mkdir()
        (ext2 / "package.json").write_text(
            json.dumps(
                {
                    "publisher": "dbaeumer",
                    "name": "vscode-eslint",
                    "version": "2.4.4",
                }
            )
        )

        # Non-dir entry should be skipped
        (ext_dir / "some-file.txt").write_text("not a dir")

        # Dir without package.json should be skipped
        (ext_dir / "no-package").mkdir()

        async def mock_run(cmd, *args):
            return None  # CLI not available

        with (
            patch("posture_agent.collectors.extensions.run_command", side_effect=mock_run),
            patch("posture_agent.collectors.extensions.shutil.which", return_value=None),
            patch("posture_agent.collectors.extensions._EXT_DIRS", {"code": ext_dir}),
            patch(
                "posture_agent.collectors.extensions._EDITOR_CONFIGS",
                {
                    "code": ("vscode", ext_dir),
                },
            ),
        ):
            result = asyncio.run(collector.collect())

        assert "vscode" in result.data
        exts = result.data["vscode"]
        ext_ids = [e["id"] for e in exts]
        assert "dbaeumer.vscode-eslint" in ext_ids
        assert "ms-python.python" in ext_ids

    def test_filesystem_deduplicates_versions(self, tmp_path):
        collector = ExtensionCollector()

        ext_dir = tmp_path / ".vscode" / "extensions"
        ext_dir.mkdir(parents=True)

        # Two versions of the same extension
        ext_v1 = ext_dir / "pub.ext-1.0.0"
        ext_v1.mkdir()
        (ext_v1 / "package.json").write_text(
            json.dumps(
                {
                    "publisher": "pub",
                    "name": "ext",
                    "version": "1.0.0",
                }
            )
        )

        ext_v2 = ext_dir / "pub.ext-2.0.0"
        ext_v2.mkdir()
        (ext_v2 / "package.json").write_text(
            json.dumps(
                {
                    "publisher": "pub",
                    "name": "ext",
                    "version": "2.0.0",
                }
            )
        )

        async def mock_run(cmd, *args):
            return None

        with (
            patch("posture_agent.collectors.extensions.run_command", side_effect=mock_run),
            patch("posture_agent.collectors.extensions.shutil.which", return_value=None),
            patch("posture_agent.collectors.extensions._EXT_DIRS", {"code": ext_dir}),
            patch(
                "posture_agent.collectors.extensions._EDITOR_CONFIGS",
                {
                    "code": ("vscode", ext_dir),
                },
            ),
        ):
            result = asyncio.run(collector.collect())

        exts = result.data["vscode"]
        # Should only have one entry with the higher version
        assert len(exts) == 1
        assert exts[0]["version"] == "2.0.0"

    def test_filesystem_bad_json_skipped(self, tmp_path):
        collector = ExtensionCollector()

        ext_dir = tmp_path / ".vscode" / "extensions"
        ext_dir.mkdir(parents=True)

        bad_ext = ext_dir / "bad-ext"
        bad_ext.mkdir()
        (bad_ext / "package.json").write_text("not valid json {{{")

        async def mock_run(cmd, *args):
            return None

        with (
            patch("posture_agent.collectors.extensions.run_command", side_effect=mock_run),
            patch("posture_agent.collectors.extensions.shutil.which", return_value=None),
            patch("posture_agent.collectors.extensions._EXT_DIRS", {"code": ext_dir}),
            patch(
                "posture_agent.collectors.extensions._EDITOR_CONFIGS",
                {
                    "code": ("vscode", ext_dir),
                },
            ),
        ):
            result = asyncio.run(collector.collect())

        assert result.data.get("vscode", []) == []

    def test_filesystem_missing_publisher_skipped(self, tmp_path):
        collector = ExtensionCollector()

        ext_dir = tmp_path / ".vscode" / "extensions"
        ext_dir.mkdir(parents=True)

        ext = ext_dir / "no-publisher"
        ext.mkdir()
        (ext / "package.json").write_text(
            json.dumps(
                {
                    "name": "orphan-ext",
                    "version": "1.0.0",
                }
            )
        )

        async def mock_run(cmd, *args):
            return None

        with (
            patch("posture_agent.collectors.extensions.run_command", side_effect=mock_run),
            patch("posture_agent.collectors.extensions.shutil.which", return_value=None),
            patch("posture_agent.collectors.extensions._EXT_DIRS", {"code": ext_dir}),
            patch(
                "posture_agent.collectors.extensions._EDITOR_CONFIGS",
                {
                    "code": ("vscode", ext_dir),
                },
            ),
        ):
            result = asyncio.run(collector.collect())

        assert result.data.get("vscode", []) == []


class TestVSCodeExtensionCollectorErrors:
    """Test error handling in the extension collector."""

    def test_vscode_exception_caught(self):
        collector = ExtensionCollector()

        def mock_which(binary):
            if binary == "code":
                raise RuntimeError("fatal error")
            return None

        async def mock_run(cmd, *args):
            return None

        with (
            patch("posture_agent.collectors.extensions.run_command", side_effect=mock_run),
            patch("posture_agent.collectors.extensions.shutil.which", side_effect=mock_which),
        ):
            result = asyncio.run(collector.collect())

        assert any("vscode extensions" in e for e in result.errors)

    def test_jetbrains_exception_caught(self):
        collector = ExtensionCollector()

        async def mock_run(cmd, *args):
            return None

        with (
            patch("posture_agent.collectors.extensions.run_command", side_effect=mock_run),
            patch.object(
                collector, "_collect_jetbrains_plugins", side_effect=RuntimeError("JB error")
            ),
        ):
            result = asyncio.run(collector.collect())

        assert any("JetBrains plugins" in e for e in result.errors)


class TestJetBrainsPlugins:
    """Test JetBrains plugin collection."""

    def test_collects_plugins(self, tmp_path):
        collector = ExtensionCollector()

        jb_dir = tmp_path / "Library" / "Application Support" / "JetBrains"
        ide_dir = jb_dir / "IntelliJIdea2024.3"
        plugins_dir = ide_dir / "plugins"
        plugin1 = plugins_dir / "my-plugin"
        plugin1.mkdir(parents=True)

        async def mock_run(cmd, *args):
            return None

        with (
            patch("posture_agent.collectors.extensions.run_command", side_effect=mock_run),
            patch("posture_agent.collectors.extensions.shutil.which", return_value=None),
            patch("posture_agent.collectors.extensions.Path.home", return_value=tmp_path),
        ):
            result = asyncio.run(collector.collect())

        assert "jetbrains" in result.data
        plugins = result.data["jetbrains"]
        assert len(plugins) == 1
        assert plugins[0]["id"] == "my-plugin"
        assert plugins[0]["ide"] == "IntelliJIdea2024.3"

    def test_no_jetbrains_dir(self, tmp_path):
        collector = ExtensionCollector()

        async def mock_run(cmd, *args):
            return None

        with (
            patch("posture_agent.collectors.extensions.run_command", side_effect=mock_run),
            patch("posture_agent.collectors.extensions.shutil.which", return_value=None),
            patch("posture_agent.collectors.extensions.Path.home", return_value=tmp_path),
        ):
            result = asyncio.run(collector.collect())

        assert "jetbrains" not in result.data

    def test_jetbrains_non_dir_entry_skipped(self, tmp_path):
        collector = ExtensionCollector()

        jb_dir = tmp_path / "Library" / "Application Support" / "JetBrains"
        jb_dir.mkdir(parents=True)
        (jb_dir / "some_file.txt").write_text("not a dir")

        async def mock_run(cmd, *args):
            return None

        with (
            patch("posture_agent.collectors.extensions.run_command", side_effect=mock_run),
            patch("posture_agent.collectors.extensions.shutil.which", return_value=None),
            patch("posture_agent.collectors.extensions.Path.home", return_value=tmp_path),
        ):
            result = asyncio.run(collector.collect())

        assert "jetbrains" not in result.data

    def test_jetbrains_meta_artifact_folder_skipped(self, tmp_path):
        """``meta`` and ``META-INF`` folders are JetBrains metadata artifacts,
        not real plugins (#623)."""
        collector = ExtensionCollector()

        jb_dir = tmp_path / "Library" / "Application Support" / "JetBrains"
        ide_dir = jb_dir / "PyCharm2020.2"
        plugins_dir = ide_dir / "plugins"
        plugins_dir.mkdir(parents=True)

        # Artifact folders that must be filtered out
        (plugins_dir / "meta").mkdir()
        (plugins_dir / "META-INF").mkdir()
        (plugins_dir / "META-INF-extras").mkdir()

        # A legitimate plugin alongside the artifacts
        real_plugin = plugins_dir / "org.intellij.plugins.markdown"
        real_plugin.mkdir()

        async def mock_run(cmd, *args):
            return None

        with (
            patch("posture_agent.collectors.extensions.run_command", side_effect=mock_run),
            patch("posture_agent.collectors.extensions.shutil.which", return_value=None),
            patch("posture_agent.collectors.extensions.Path.home", return_value=tmp_path),
        ):
            result = asyncio.run(collector.collect())

        plugins = result.data.get("jetbrains", [])
        plugin_ids = [p["id"] for p in plugins]
        assert "meta" not in plugin_ids
        assert "META-INF" not in plugin_ids
        assert "META-INF-extras" not in plugin_ids
        assert "org.intellij.plugins.markdown" in plugin_ids

    def test_jetbrains_builtin_plugin_with_space_and_no_version_skipped(self, tmp_path):
        """Built-in bundled plugins like 'Shell Script' (folder name has a
        space and no parseable plugin.xml version) must be filtered (#623)."""
        collector = ExtensionCollector()

        jb_dir = tmp_path / "Library" / "Application Support" / "JetBrains"
        ide_dir = jb_dir / "PyCharm2024.2"
        plugins_dir = ide_dir / "plugins"
        plugins_dir.mkdir(parents=True)

        # Built-in plugin folder — display name with space, no lib/ jars
        (plugins_dir / "Shell Script").mkdir()
        # Another built-in style folder
        (plugins_dir / "Database Tools").mkdir()
        # Real plugin with proper id
        (plugins_dir / "com.example.real-plugin").mkdir()

        async def mock_run(cmd, *args):
            return None

        with (
            patch("posture_agent.collectors.extensions.run_command", side_effect=mock_run),
            patch("posture_agent.collectors.extensions.shutil.which", return_value=None),
            patch("posture_agent.collectors.extensions.Path.home", return_value=tmp_path),
        ):
            result = asyncio.run(collector.collect())

        plugins = result.data.get("jetbrains", [])
        plugin_ids = [p["id"] for p in plugins]
        assert "Shell Script" not in plugin_ids
        assert "Database Tools" not in plugin_ids
        assert "com.example.real-plugin" in plugin_ids

    def test_jetbrains_legitimate_plugin_with_no_version_still_emitted(self, tmp_path):
        """A real plugin id (no spaces, not metadata) with empty version is
        still reported — be defensive, only filter the artifacts (#623)."""
        collector = ExtensionCollector()

        jb_dir = tmp_path / "Library" / "Application Support" / "JetBrains"
        ide_dir = jb_dir / "IntelliJIdea2024.3"
        plugins_dir = ide_dir / "plugins"
        plugins_dir.mkdir(parents=True)

        # Legitimate plugin id, but no lib/ -> empty version
        (plugins_dir / "com.example.no-version-plugin").mkdir()

        async def mock_run(cmd, *args):
            return None

        with (
            patch("posture_agent.collectors.extensions.run_command", side_effect=mock_run),
            patch("posture_agent.collectors.extensions.shutil.which", return_value=None),
            patch("posture_agent.collectors.extensions.Path.home", return_value=tmp_path),
        ):
            result = asyncio.run(collector.collect())

        plugins = result.data.get("jetbrains", [])
        assert len(plugins) == 1
        assert plugins[0]["id"] == "com.example.no-version-plugin"
        assert plugins[0]["version"] == ""

    def test_is_jetbrains_artifact_folder_helper(self):
        """Static helper recognises metadata folder names case-insensitively."""
        assert ExtensionCollector._is_jetbrains_artifact_folder("meta") is True
        assert ExtensionCollector._is_jetbrains_artifact_folder("META") is True
        assert ExtensionCollector._is_jetbrains_artifact_folder("Meta") is True
        assert ExtensionCollector._is_jetbrains_artifact_folder("META-INF") is True
        assert ExtensionCollector._is_jetbrains_artifact_folder("meta-inf") is True
        assert ExtensionCollector._is_jetbrains_artifact_folder("META-INF-stuff") is True
        # Real plugin ids must NOT match
        assert ExtensionCollector._is_jetbrains_artifact_folder("metadata-plugin") is False
        assert ExtensionCollector._is_jetbrains_artifact_folder("com.example.plugin") is False
        assert ExtensionCollector._is_jetbrains_artifact_folder("Shell Script") is False


class TestJetBrainsPluginVersion:
    """Test JetBrains plugin version extraction from JAR files."""

    def test_extracts_version_from_jar(self, tmp_path):
        collector = ExtensionCollector()

        plugin_dir = tmp_path / "my-plugin"
        lib_dir = plugin_dir / "lib"
        lib_dir.mkdir(parents=True)

        jar_path = lib_dir / "plugin.jar"
        plugin_xml = "<idea-plugin>\n<version>1.2.3</version>\n</idea-plugin>"
        with zipfile.ZipFile(jar_path, "w") as zf:
            zf.writestr("META-INF/plugin.xml", plugin_xml)

        version = collector._get_jetbrains_plugin_version(plugin_dir)
        assert version == "1.2.3"

    def test_no_lib_dir_returns_empty(self, tmp_path):
        collector = ExtensionCollector()
        plugin_dir = tmp_path / "my-plugin"
        plugin_dir.mkdir()

        version = collector._get_jetbrains_plugin_version(plugin_dir)
        assert version == ""

    def test_jar_without_plugin_xml(self, tmp_path):
        collector = ExtensionCollector()

        plugin_dir = tmp_path / "my-plugin"
        lib_dir = plugin_dir / "lib"
        lib_dir.mkdir(parents=True)

        jar_path = lib_dir / "other.jar"
        with zipfile.ZipFile(jar_path, "w") as zf:
            zf.writestr("META-INF/MANIFEST.MF", "Manifest-Version: 1.0\n")

        version = collector._get_jetbrains_plugin_version(plugin_dir)
        assert version == ""

    def test_bad_zip_file_skipped(self, tmp_path):
        collector = ExtensionCollector()

        plugin_dir = tmp_path / "my-plugin"
        lib_dir = plugin_dir / "lib"
        lib_dir.mkdir(parents=True)

        # Write a non-zip file with .jar extension
        (lib_dir / "bad.jar").write_bytes(b"this is not a zip file")

        version = collector._get_jetbrains_plugin_version(plugin_dir)
        assert version == ""

    def test_plugin_xml_without_version(self, tmp_path):
        collector = ExtensionCollector()

        plugin_dir = tmp_path / "my-plugin"
        lib_dir = plugin_dir / "lib"
        lib_dir.mkdir(parents=True)

        jar_path = lib_dir / "plugin.jar"
        plugin_xml = "<idea-plugin>\n<name>My Plugin</name>\n</idea-plugin>"
        with zipfile.ZipFile(jar_path, "w") as zf:
            zf.writestr("META-INF/plugin.xml", plugin_xml)

        version = collector._get_jetbrains_plugin_version(plugin_dir)
        assert version == ""
