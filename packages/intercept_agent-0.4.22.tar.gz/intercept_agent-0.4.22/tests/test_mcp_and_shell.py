"""Tests for MCP server config parsing and shell utilities."""

import asyncio
import json
import sys
from pathlib import Path
from unittest.mock import patch

import pytest
from posture_agent.collectors.mcp_servers import (
    MCPServersCollector,
    detect_risk_indicators,
    parse_mcp_config,
)
from posture_agent.utils.shell import _get_expanded_path, check_version, run_command


class TestParseMCPConfig:
    """Test MCP config file parsing."""

    def test_parse_standard_config(self, tmp_path):
        config = {
            "mcpServers": {
                "github": {
                    "command": "npx",
                    "args": ["-y", "@modelcontextprotocol/server-github"],
                    "env": {"GITHUB_TOKEN": "xxx"},
                },
                "filesystem": {
                    "command": "node",
                    "args": ["/path/to/fs-server.js"],
                },
            }
        }
        config_path = tmp_path / "mcp.json"
        config_path.write_text(json.dumps(config))

        servers = parse_mcp_config(config_path, "claude")
        assert len(servers) == 2

        github_server = [s for s in servers if s["name"] == "github"][0]
        assert github_server["command"] == "npx"
        assert github_server["transport"] == "stdio"
        assert "GITHUB_TOKEN" in github_server["env_keys"]
        assert "credentials" in github_server["risk_indicators"]

    def test_parse_sse_transport(self, tmp_path):
        config = {
            "mcpServers": {
                "remote": {
                    "url": "https://example.com/mcp",
                    "transport": "sse",
                },
            }
        }
        config_path = tmp_path / "mcp.json"
        config_path.write_text(json.dumps(config))

        servers = parse_mcp_config(config_path, "claude")
        assert len(servers) == 1
        assert servers[0]["transport"] == "sse"
        assert servers[0]["url"] == "https://example.com/mcp"
        assert "network" in servers[0]["risk_indicators"]

    def test_parse_url_without_explicit_transport(self, tmp_path):
        config = {
            "mcpServers": {
                "remote": {
                    "url": "https://example.com/mcp",
                },
            }
        }
        config_path = tmp_path / "mcp.json"
        config_path.write_text(json.dumps(config))

        servers = parse_mcp_config(config_path, "claude")
        assert servers[0]["transport"] == "sse"  # default for url-based

    def test_parse_continue_format(self, tmp_path):
        config = {
            "mcpServers": {
                "my-server": {
                    "command": "node",
                    "args": ["server.js"],
                },
            }
        }
        config_path = tmp_path / "config.json"
        config_path.write_text(json.dumps(config))

        servers = parse_mcp_config(config_path, "continue")
        assert len(servers) == 1
        assert servers[0]["tool"] == "continue"

    def test_parse_invalid_json_raises(self, tmp_path):
        """``parse_mcp_config`` propagates ``JSONDecodeError`` so callers can
        surface a breadcrumb. Silent ``[]`` returns hid corrupted configs
        from the report ``errors`` list — see #623."""
        config_path = tmp_path / "mcp.json"
        config_path.write_text("not valid json {{{")

        with pytest.raises(json.JSONDecodeError):
            parse_mcp_config(config_path, "claude")

    def test_parse_missing_file_raises(self, tmp_path):
        """Missing files raise ``OSError`` — the collector pre-checks
        ``config_path.exists()`` so this code path only fires on a TOCTOU
        race or a permission-denied read; both should surface."""
        config_path = tmp_path / "nonexistent.json"
        with pytest.raises(OSError):
            parse_mcp_config(config_path, "claude")

    def test_parse_non_dict_server_skipped(self, tmp_path):
        config = {
            "mcpServers": {
                "valid": {"command": "node", "args": ["server.js"]},
                "invalid": "not a dict",
                "also-invalid": 42,
            }
        }
        config_path = tmp_path / "mcp.json"
        config_path.write_text(json.dumps(config))

        servers = parse_mcp_config(config_path, "claude")
        assert len(servers) == 1
        assert servers[0]["name"] == "valid"

    def test_parse_empty_mcp_servers(self, tmp_path):
        config = {"mcpServers": {}}
        config_path = tmp_path / "mcp.json"
        config_path.write_text(json.dumps(config))

        servers = parse_mcp_config(config_path, "claude")
        assert servers == []

    def test_parse_no_mcp_servers_key(self, tmp_path):
        config = {"other": "data"}
        config_path = tmp_path / "mcp.json"
        config_path.write_text(json.dumps(config))

        servers = parse_mcp_config(config_path, "claude")
        assert servers == []


class TestMCPCollectorPaths:
    """Test MCPServersCollector path scanning."""

    def test_collector_scans_standard_paths(self, tmp_path):
        collector = MCPServersCollector()

        # Create a claude mcp config
        claude_dir = tmp_path / ".claude"
        claude_dir.mkdir()
        config = {
            "mcpServers": {
                "test": {"command": "echo", "args": ["hello"]},
            }
        }
        (claude_dir / "mcp.json").write_text(json.dumps(config))

        with patch("pathlib.Path.home", return_value=tmp_path):
            result = asyncio.run(collector.collect())

        assert len(result.data) >= 1
        assert result.data[0]["name"] == "test"
        assert result.data[0]["tool"] == "claude"

    def test_collector_handles_exception_in_path(self, tmp_path):
        collector = MCPServersCollector()

        with (
            patch("pathlib.Path.home", return_value=tmp_path),
            patch(
                "posture_agent.collectors.mcp_servers.parse_mcp_config",
                side_effect=RuntimeError("parse error"),
            ),
        ):
            # Create a config file so the exists() check passes
            claude_dir = tmp_path / ".claude"
            claude_dir.mkdir()
            (claude_dir / "mcp.json").write_text("{}")

            result = asyncio.run(collector.collect())

        assert any("claude" in e for e in result.errors)

    def test_collector_finds_claude_code_dotfile(self, tmp_path):
        """``~/.claude.json`` is the canonical Claude Code CLI config FILE
        (not the legacy ``~/.claude/`` directory). It must surface even
        when the directory-style fallback is absent — see #623."""
        collector = MCPServersCollector()
        config = {
            "mcpServers": {
                "claude-code-srv": {"command": "node", "args": ["server.js"]},
            }
        }
        (tmp_path / ".claude.json").write_text(json.dumps(config))

        with patch("pathlib.Path.home", return_value=tmp_path):
            result = asyncio.run(collector.collect())

        assert any(s["name"] == "claude-code-srv" for s in result.data)
        assert all(s["tool"] == "claude" for s in result.data)
        assert all(".claude.json" in s["config_path"] for s in result.data)

    def test_collector_no_op_when_paths_missing(self, tmp_path):
        """No errors when no config files exist anywhere — most users do
        not have every client installed and we must not flood the report
        with breadcrumbs for every absent path."""
        collector = MCPServersCollector()

        with patch("pathlib.Path.home", return_value=tmp_path):
            result = asyncio.run(collector.collect())

        assert result.data == []
        assert result.errors == []

    def test_collector_records_corrupted_json_breadcrumb(self, tmp_path):
        """A real parse failure (corrupted JSON) MUST land in ``errors``
        with the breadcrumb format ``MCP config <path>: <message>``."""
        collector = MCPServersCollector()
        # Drop a corrupted file at one of the cross-platform standard
        # locations so the collector definitely visits it.
        (tmp_path / ".claude.json").write_text("not valid json {{{")

        with patch("pathlib.Path.home", return_value=tmp_path):
            result = asyncio.run(collector.collect())

        assert any(".claude.json" in e and e.startswith("MCP config ") for e in result.errors), (
            f"expected breadcrumb in errors, got {result.errors}"
        )


class _FakeMCPHostPaths:
    """Minimal MCPHostPaths implementation that returns whatever paths the
    test wires up — used to simulate a Windows or macOS bundle without
    standing up the real platform module."""

    def __init__(self, *, claude_desktop: Path, cursor: Path, vscode: list[Path]) -> None:
        self._claude = claude_desktop
        self._cursor = cursor
        self._vscode = vscode

    def claude_desktop_config(self) -> Path:
        return self._claude

    def cursor_mcp_config(self) -> Path:
        return self._cursor

    def vscode_mcp_config(self) -> list[Path]:
        return list(self._vscode)


def _bundle_with_mcp_paths(mcp_paths: _FakeMCPHostPaths):
    """Build a real PlatformBundle and swap only the ``mcp_paths`` slot.

    The collector only touches ``bundle.mcp_paths`` so the other slots can
    remain whatever the host platform bundle provides.
    """
    from posture_agent import platforms

    real = platforms.detect()
    return platforms.PlatformBundle(
        hardware=real.hardware,
        security=real.security,
        ssh_agent=real.ssh_agent,
        ides=real.ides,
        mcp_paths=mcp_paths,
        path_expander=real.path_expander,
        scheduler=real.scheduler,
    )


class TestMCPCollectorPlatformBundle:
    """The collector must invoke ``bundle.mcp_paths`` regardless of OS — no
    Darwin gate. Bug 1 of #623."""

    def test_collector_invokes_windows_claude_desktop_path(self, tmp_path):
        """Simulate a Windows bundle: Claude Desktop config under
        ``%APPDATA%\\Claude\\claude_desktop_config.json``. Before #623 the
        collector skipped this on Windows because of a ``platform.system()
        == "Darwin"`` gate."""
        appdata = tmp_path / "AppData" / "Roaming"
        claude_path = appdata / "Claude" / "claude_desktop_config.json"
        claude_path.parent.mkdir(parents=True)
        claude_path.write_text(
            json.dumps({"mcpServers": {"win-claude": {"command": "node", "args": ["a.js"]}}})
        )
        cursor_path = appdata / "Cursor" / "User" / "globalStorage" / "cursor.mcp" / "mcp.json"
        # cursor file deliberately does not exist for this test

        fake_paths = _FakeMCPHostPaths(claude_desktop=claude_path, cursor=cursor_path, vscode=[])
        collector = MCPServersCollector()

        from posture_agent import platforms as _platforms

        _platforms.reset_bundle()
        try:
            with (
                patch("pathlib.Path.home", return_value=tmp_path),
                patch(
                    "posture_agent.collectors.mcp_servers.get_bundle",
                    return_value=_bundle_with_mcp_paths(fake_paths),
                ),
            ):
                result = asyncio.run(collector.collect())
        finally:
            _platforms.reset_bundle()

        names = [s["name"] for s in result.data]
        assert "win-claude" in names
        win_claude = next(s for s in result.data if s["name"] == "win-claude")
        assert win_claude["tool"] == "claude-desktop"
        assert str(claude_path) == win_claude["config_path"]

    def test_collector_invokes_windows_cursor_path(self, tmp_path):
        """Cursor on Windows lives under
        ``%APPDATA%\\Cursor\\User\\globalStorage\\cursor.mcp\\mcp.json``."""
        appdata = tmp_path / "AppData" / "Roaming"
        claude_path = appdata / "Claude" / "claude_desktop_config.json"
        cursor_path = appdata / "Cursor" / "User" / "globalStorage" / "cursor.mcp" / "mcp.json"
        cursor_path.parent.mkdir(parents=True)
        cursor_path.write_text(
            json.dumps({"mcpServers": {"cursor-win": {"command": "npx", "args": []}}})
        )

        fake_paths = _FakeMCPHostPaths(claude_desktop=claude_path, cursor=cursor_path, vscode=[])
        collector = MCPServersCollector()

        from posture_agent import platforms as _platforms

        _platforms.reset_bundle()
        try:
            with (
                patch("pathlib.Path.home", return_value=tmp_path),
                patch(
                    "posture_agent.collectors.mcp_servers.get_bundle",
                    return_value=_bundle_with_mcp_paths(fake_paths),
                ),
            ):
                result = asyncio.run(collector.collect())
        finally:
            _platforms.reset_bundle()

        names = [s["name"] for s in result.data]
        assert "cursor-win" in names

    def test_collector_iterates_vscode_stable_and_insiders(self, tmp_path):
        """``vscode_mcp_config()`` returns a list — collector iterates so
        Stable and Insiders are both surfaced."""
        appdata = tmp_path / "AppData" / "Roaming"
        stable = appdata / "Code" / "User" / "mcp.json"
        insiders = appdata / "Code - Insiders" / "User" / "mcp.json"
        stable.parent.mkdir(parents=True)
        insiders.parent.mkdir(parents=True)
        stable.write_text(json.dumps({"mcpServers": {"vscode-stable": {"command": "node"}}}))
        insiders.write_text(json.dumps({"mcpServers": {"vscode-insiders": {"command": "node"}}}))

        fake_paths = _FakeMCPHostPaths(
            claude_desktop=tmp_path / "missing-claude.json",
            cursor=tmp_path / "missing-cursor.json",
            vscode=[stable, insiders],
        )
        collector = MCPServersCollector()

        from posture_agent import platforms as _platforms

        _platforms.reset_bundle()
        try:
            with (
                patch("pathlib.Path.home", return_value=tmp_path),
                patch(
                    "posture_agent.collectors.mcp_servers.get_bundle",
                    return_value=_bundle_with_mcp_paths(fake_paths),
                ),
            ):
                result = asyncio.run(collector.collect())
        finally:
            _platforms.reset_bundle()

        names = sorted(s["name"] for s in result.data)
        assert "vscode-stable" in names
        assert "vscode-insiders" in names
        # Both reported under the same `tool` value; config_path
        # disambiguates Stable vs Insiders.
        vscode_entries = [s for s in result.data if s["tool"] == "vscode"]
        assert len(vscode_entries) == 2
        paths = {s["config_path"] for s in vscode_entries}
        assert str(stable) in paths
        assert str(insiders) in paths

    def test_vscode_insiders_only(self, tmp_path):
        """If only Insiders is installed, Stable is silently skipped — no
        error breadcrumbs for absent variants."""
        appdata = tmp_path / "AppData" / "Roaming"
        stable = appdata / "Code" / "User" / "mcp.json"  # NOT created
        insiders = appdata / "Code - Insiders" / "User" / "mcp.json"
        insiders.parent.mkdir(parents=True)
        insiders.write_text(json.dumps({"mcpServers": {"only-insiders": {"command": "node"}}}))

        fake_paths = _FakeMCPHostPaths(
            claude_desktop=tmp_path / "missing-claude.json",
            cursor=tmp_path / "missing-cursor.json",
            vscode=[stable, insiders],
        )
        collector = MCPServersCollector()

        from posture_agent import platforms as _platforms

        _platforms.reset_bundle()
        try:
            with (
                patch("pathlib.Path.home", return_value=tmp_path),
                patch(
                    "posture_agent.collectors.mcp_servers.get_bundle",
                    return_value=_bundle_with_mcp_paths(fake_paths),
                ),
            ):
                result = asyncio.run(collector.collect())
        finally:
            _platforms.reset_bundle()

        names = [s["name"] for s in result.data]
        assert names == ["only-insiders"]
        assert result.errors == []


class TestVSCodeMCPConfigProtocol:
    """Protocol method ``vscode_mcp_config()`` must exist on every supported
    platform implementation and return the canonical OS-specific paths."""

    def test_macos_vscode_mcp_paths(self, monkeypatch, tmp_path):
        from posture_agent.platforms import macos

        monkeypatch.setattr(Path, "home", lambda: tmp_path)
        paths = macos.MacOSMCPHostPaths().vscode_mcp_config()

        assert paths == [
            tmp_path / "Library" / "Application Support" / "Code" / "User" / "mcp.json",
            tmp_path / "Library" / "Application Support" / "Code - Insiders" / "User" / "mcp.json",
        ]

    def test_windows_vscode_mcp_paths_uses_appdata(self, monkeypatch, tmp_path):
        from posture_agent.platforms import windows

        monkeypatch.setenv("APPDATA", str(tmp_path / "Roaming"))
        monkeypatch.setattr(Path, "home", lambda: tmp_path)

        paths = windows.WindowsMCPHostPaths().vscode_mcp_config()
        assert paths == [
            tmp_path / "Roaming" / "Code" / "User" / "mcp.json",
            tmp_path / "Roaming" / "Code - Insiders" / "User" / "mcp.json",
        ]

    def test_windows_vscode_mcp_paths_falls_back_when_appdata_unset(self, monkeypatch, tmp_path):
        from posture_agent.platforms import windows

        monkeypatch.delenv("APPDATA", raising=False)
        monkeypatch.setattr(Path, "home", lambda: tmp_path)

        paths = windows.WindowsMCPHostPaths().vscode_mcp_config()
        assert paths == [
            tmp_path / "AppData" / "Roaming" / "Code" / "User" / "mcp.json",
            tmp_path / "AppData" / "Roaming" / "Code - Insiders" / "User" / "mcp.json",
        ]


class TestDetectRiskIndicators:
    """Additional risk indicator tests."""

    def test_streamable_http_transport(self):
        server = {"transport": "streamable-http", "command": "node"}
        risks = detect_risk_indicators(server)
        assert "network" in risks

    def test_http_transport(self):
        server = {"transport": "http"}
        risks = detect_risk_indicators(server)
        assert "network" in risks

    def test_no_risks(self):
        server = {"command": "node", "args": ["server.js"]}
        risks = detect_risk_indicators(server)
        assert "shell" not in risks
        assert "credentials" not in risks
        assert "network" not in risks

    def test_backslash_path_in_args(self):
        server = {"command": "node", "args": ["C:\\Users\\test\\server.js"]}
        risks = detect_risk_indicators(server)
        assert "filesystem" in risks

    def test_deduplicates_risks(self):
        """Filesystem keyword in command AND path in args should not duplicate."""
        server = {"command": "file-server", "args": ["/tmp/data"]}
        risks = detect_risk_indicators(server)
        assert risks.count("filesystem") == 1


@pytest.mark.skipif(sys.platform != "darwin", reason="macOS-specific test")
class TestShellExpandedPath:
    """Test _get_expanded_path utility."""

    def test_includes_standard_paths(self):
        path = _get_expanded_path()
        assert "/opt/homebrew/bin" in path
        assert "/usr/local/bin" in path

    def test_deduplicates_path(self):
        path = _get_expanded_path()
        parts = path.split(":")
        assert len(parts) == len(set(parts))


class TestCheckVersion:
    """Test the check_version utility.

    ``check_version`` reads through :func:`_run_capture_both` so that
    older Python releases / the Microsoft Store ``python3.exe`` stub —
    which print the version banner to stderr — still report a version
    (B4). These tests patch ``_run_capture_both`` directly so the
    expected behavior is exercised on every host.
    """

    def test_extracts_version_from_first_line(self):
        async def mock_run(*args, **kwargs):
            return "git version 2.43.0\n"

        with patch("posture_agent.utils.shell._run_capture_both", side_effect=mock_run):
            version = asyncio.run(check_version("git", "--version"))

        assert version == "2.43.0"

    def test_extracts_version_from_subsequent_line(self):
        """For tools like grype that put version on a later line."""

        async def mock_run(*args, **kwargs):
            return "Application:  grype\nVersion:      0.107.1\n"

        with patch("posture_agent.utils.shell._run_capture_both", side_effect=mock_run):
            version = asyncio.run(check_version("grype", "version"))

        assert version == "0.107.1"

    def test_returns_none_on_no_output(self):
        async def mock_run(*args, **kwargs):
            return None

        with patch("posture_agent.utils.shell._run_capture_both", side_effect=mock_run):
            version = asyncio.run(check_version("nonexistent", "--version"))

        assert version is None

    def test_fallback_to_first_line(self):
        """When no version pattern found, returns first 50 chars."""

        async def mock_run(*args, **kwargs):
            return "some-tool no-version-here\n"

        with patch("posture_agent.utils.shell._run_capture_both", side_effect=mock_run):
            version = asyncio.run(check_version("some-tool", "--version"))

        assert version == "some-tool no-version-here"

    def test_multi_word_version_flag(self):
        """Multi-word flags like 'version --client' are split."""

        async def mock_run(*args, **kwargs):
            if args == ("kubectl", "version", "--client"):
                return "Client Version: v1.28.0\n"
            return None

        with patch("posture_agent.utils.shell._run_capture_both", side_effect=mock_run):
            version = asyncio.run(check_version("kubectl", "version --client"))

        assert version == "1.28.0"


class TestRunCommand:
    """Test run_command utility."""

    def test_successful_command(self):
        result = asyncio.run(run_command("echo", "hello"))
        assert result is not None
        assert "hello" in result

    def test_nonexistent_command(self):
        result = asyncio.run(run_command("nonexistent_command_xyz"))
        assert result is None

    def test_command_with_nonzero_exit(self):
        result = asyncio.run(run_command("false"))
        assert result is None


class TestCheckVersionStderr:
    """B4 — Python --version writes to stderr on older releases / MS Store stub."""

    def test_version_on_stderr_is_captured(self):
        """When stdout is empty but stderr has the banner, parse stderr."""
        from posture_agent.utils import shell as shell_mod

        async def fake_create_subprocess_exec(*args, **kwargs):
            class FakeProc:
                returncode = 0

                async def communicate(self):
                    # Simulates older Python: banner on stderr only.
                    return (b"", b"Python 3.12.0\n")

            return FakeProc()

        with patch.object(
            shell_mod.asyncio,
            "create_subprocess_exec",
            side_effect=fake_create_subprocess_exec,
        ):
            version = asyncio.run(check_version("python3", "--version"))

        assert version == "3.12.0"

    def test_version_on_stdout_with_nonzero_exit_is_captured(self):
        """MS Store python.exe stub may exit non-zero but still print a banner."""
        from posture_agent.utils import shell as shell_mod

        async def fake_create_subprocess_exec(*args, **kwargs):
            class FakeProc:
                returncode = 9009  # arbitrary nonzero — Windows Store stub variant

                async def communicate(self):
                    return (b"Python 3.12.0\n", b"")

            return FakeProc()

        with patch.object(
            shell_mod.asyncio,
            "create_subprocess_exec",
            side_effect=fake_create_subprocess_exec,
        ):
            version = asyncio.run(check_version("python3", "--version"))

        assert version == "3.12.0"

    def test_no_output_returns_none(self):
        """When the binary writes nothing, check_version returns None gracefully."""
        from posture_agent.utils import shell as shell_mod

        async def fake_create_subprocess_exec(*args, **kwargs):
            class FakeProc:
                returncode = 1

                async def communicate(self):
                    return (b"", b"")

            return FakeProc()

        with patch.object(
            shell_mod.asyncio,
            "create_subprocess_exec",
            side_effect=fake_create_subprocess_exec,
        ):
            version = asyncio.run(check_version("python3", "--version"))

        assert version is None

    def test_oserror_returns_none(self):
        """Microsoft Store stub binaries can raise OSError; we must not crash."""
        from posture_agent.utils import shell as shell_mod

        async def fake_create_subprocess_exec(*args, **kwargs):
            raise OSError(193, "%1 is not a valid Win32 application")

        with patch.object(
            shell_mod.asyncio,
            "create_subprocess_exec",
            side_effect=fake_create_subprocess_exec,
        ):
            version = asyncio.run(check_version("python3", "--version"))

        assert version is None


class TestResolveForExec:
    """B5/B6 — Windows ``.cmd`` / ``.bat`` shims need ``cmd.exe /c`` interpretation."""

    def test_no_op_on_non_windows(self):
        from posture_agent.utils import shell as shell_mod

        with patch.object(shell_mod.sys, "platform", "darwin"):
            assert shell_mod._resolve_for_exec(("npm", "--version")) == ("npm", "--version")

    def test_empty_args_returns_unchanged(self):
        from posture_agent.utils import shell as shell_mod

        with patch.object(shell_mod.sys, "platform", "win32"):
            assert shell_mod._resolve_for_exec(()) == ()

    def test_cmd_shim_is_wrapped_with_cmd_exe(self):
        """``npm.cmd`` / ``gcloud.cmd`` / ``az.cmd`` must invoke through cmd.exe."""
        from posture_agent.utils import shell as shell_mod

        shim_path = r"C:\Users\dev\AppData\Roaming\npm\npm.cmd"
        with (
            patch.object(shell_mod.sys, "platform", "win32"),
            patch.object(shell_mod.shutil, "which", return_value=shim_path),
            patch.object(shell_mod, "_get_env", return_value={"PATH": "stub"}),
        ):
            result = shell_mod._resolve_for_exec(("npm", "--version"))

        assert result == ("cmd.exe", "/c", shim_path, "--version")

    def test_bat_shim_is_wrapped_with_cmd_exe(self):
        from posture_agent.utils import shell as shell_mod

        shim_path = r"C:\Ruby\bin\gem.bat"
        with (
            patch.object(shell_mod.sys, "platform", "win32"),
            patch.object(shell_mod.shutil, "which", return_value=shim_path),
            patch.object(shell_mod, "_get_env", return_value={"PATH": "stub"}),
        ):
            result = shell_mod._resolve_for_exec(("gem", "--version"))

        assert result == ("cmd.exe", "/c", shim_path, "--version")

    def test_exe_uses_resolved_absolute_path(self):
        """For real .exe binaries, swap the bare name for the absolute path."""
        from posture_agent.utils import shell as shell_mod

        exe_path = r"C:\Program Files\Git\cmd\git.exe"
        with (
            patch.object(shell_mod.sys, "platform", "win32"),
            patch.object(shell_mod.shutil, "which", return_value=exe_path),
            patch.object(shell_mod, "_get_env", return_value={"PATH": "stub"}),
        ):
            result = shell_mod._resolve_for_exec(("git", "--version"))

        assert result == (exe_path, "--version")

    def test_unknown_binary_returned_unchanged(self):
        """When ``shutil.which`` cannot resolve, leave argv alone so the
        subprocess machinery raises its usual ``FileNotFoundError``."""
        from posture_agent.utils import shell as shell_mod

        with (
            patch.object(shell_mod.sys, "platform", "win32"),
            patch.object(shell_mod.shutil, "which", return_value=None),
            patch.object(shell_mod, "_get_env", return_value={"PATH": "stub"}),
        ):
            result = shell_mod._resolve_for_exec(("ghost", "--version"))

        assert result == ("ghost", "--version")

    def test_check_version_extracts_from_cmd_shim_output(self):
        """End-to-end: a Windows ``npm.cmd`` shim run through cmd.exe still
        produces a parseable version banner. We patch the subprocess so the
        test runs on macOS CI."""
        from posture_agent.utils import shell as shell_mod

        async def fake_create_subprocess_exec(*args, **kwargs):
            assert args[0] == "cmd.exe"
            assert args[1] == "/c"
            assert args[2].endswith(".cmd")

            class FakeProc:
                returncode = 0

                async def communicate(self):
                    return (b"10.8.2\n", b"")

            return FakeProc()

        shim_path = r"C:\Users\dev\AppData\Roaming\npm\npm.cmd"
        with (
            patch.object(shell_mod.sys, "platform", "win32"),
            patch.object(shell_mod.shutil, "which", return_value=shim_path),
            patch.object(shell_mod, "_get_env", return_value={"PATH": "stub"}),
            patch.object(
                shell_mod.asyncio,
                "create_subprocess_exec",
                side_effect=fake_create_subprocess_exec,
            ),
        ):
            version = asyncio.run(check_version("npm", "--version"))

        assert version == "10.8.2"


class TestCheckVersionInstallRedirect:
    """B7 — Microsoft Store ``python3.EXE`` stub prints a redirect prompt
    when no real Python is installed. Our B4 fix added stderr capture, which
    then surfaced the prompt as the version. ``check_version`` must
    recognize the redirect and return ``None`` instead.
    """

    # The exact stderr emitted by the Microsoft Store python3.exe stub on
    # Windows 11 25H2 when no Python is actually installed.
    _MS_STORE_PYTHON_STUB = (
        "Python was not found; run without arguments to install from the "
        "Microsoft Store, or disable this shortcut from Settings > Apps > "
        "Advanced app settings > App execution aliases.\n"
    )

    def _patch_subprocess(self, stdout: bytes, stderr: bytes, returncode: int = 0):
        """Helper: install a fake ``create_subprocess_exec`` that returns the given streams."""
        from posture_agent.utils import shell as shell_mod

        async def fake_create_subprocess_exec(*args, **kwargs):
            class FakeProc:
                pass

            proc = FakeProc()
            proc.returncode = returncode

            async def communicate():
                return (stdout, stderr)

            proc.communicate = communicate
            return proc

        return patch.object(
            shell_mod.asyncio,
            "create_subprocess_exec",
            side_effect=fake_create_subprocess_exec,
        )

    def test_microsoft_store_python_stub_returns_none(self):
        """The full Store-redirect prompt on stderr must yield ``None``."""
        with self._patch_subprocess(
            b"", self._MS_STORE_PYTHON_STUB.encode("utf-8"), returncode=9009
        ):
            version = asyncio.run(check_version("python3", "--version"))

        assert version is None

    def test_microsoft_store_python_stub_on_stdout_returns_none(self):
        """Some Store stub variants pipe the prompt to stdout — same result."""
        with self._patch_subprocess(
            self._MS_STORE_PYTHON_STUB.encode("utf-8"), b"", returncode=9009
        ):
            version = asyncio.run(check_version("python3", "--version"))

        assert version is None

    def test_real_python_version_still_extracted(self):
        """Regression guard — a genuine ``Python 3.12.5`` banner keeps working."""
        with self._patch_subprocess(b"Python 3.12.5\n", b""):
            version = asyncio.run(check_version("python3", "--version"))

        assert version == "3.12.5"

    def test_mixed_stub_and_semver_returns_none(self):
        """Authoritative gate: if any line of output looks like a Store
        redirect prompt, treat the binary as not-actually-installed even
        when a real semver is also present. The redirect copy is the
        signal that the binary is a stub."""
        # Both a stub line AND a real-looking version banner. The presence
        # of the redirect message wins.
        mixed = self._MS_STORE_PYTHON_STUB + "Python 3.12.5\n"
        with self._patch_subprocess(b"", mixed.encode("utf-8"), returncode=9009):
            version = asyncio.run(check_version("python3", "--version"))

        assert version is None

    def test_app_execution_aliases_only_message_returns_none(self):
        """Generic alias prompt (without 'Python was not found') still
        triggers the gate — covers Store stubs for non-Python aliased
        binaries."""
        msg = (
            "This program cannot run; manage it under "
            "Settings > Apps > Advanced app settings > App execution aliases.\n"
        )
        with self._patch_subprocess(b"", msg.encode("utf-8"), returncode=9009):
            version = asyncio.run(check_version("winget", "--version"))

        assert version is None

    def test_install_redirect_pattern_is_case_insensitive(self):
        """Match must be case-insensitive — Windows 11 has historically
        printed both ``"App execution aliases"`` and the lowercase form."""
        msg = "PYTHON WAS NOT FOUND; run without arguments to install...\n"
        with self._patch_subprocess(b"", msg.encode("utf-8"), returncode=9009):
            version = asyncio.run(check_version("python3", "--version"))

        assert version is None


class TestCheckVersionBareSemver:
    """B8 — npm/pnpm/yarn print a bare semver (``"10.8.2\\n"``) rather than
    a ``"<word> <semver>"`` banner. The original regex
    ``(\\d+\\.\\d+[\\.\\d]*)`` happened to match bare semver too, but only
    when the version string contained a ``.``-separated triple. Pinning
    that behavior with explicit regression tests keeps the npm path
    reliable as we tighten parsing for the install-redirect gate.
    """

    def test_bare_semver_npm_format(self):
        """``npm --version`` prints just the version on stdout."""

        async def mock_run(*args, **kwargs):
            return "10.8.2\n"

        with patch("posture_agent.utils.shell._run_capture_both", side_effect=mock_run):
            version = asyncio.run(check_version("npm", "--version"))

        assert version == "10.8.2"

    def test_bare_two_segment_version(self):
        """Some tools print ``"1.0\\n"`` — minimal valid semver."""

        async def mock_run(*args, **kwargs):
            return "1.0\n"

        with patch("posture_agent.utils.shell._run_capture_both", side_effect=mock_run):
            version = asyncio.run(check_version("tool", "--version"))

        assert version == "1.0"

    def test_bare_four_segment_version(self):
        """JetBrains-style 4-segment versions (e.g., ``"2024.3.1.1"``)."""

        async def mock_run(*args, **kwargs):
            return "2024.3.1.1\n"

        with patch("posture_agent.utils.shell._run_capture_both", side_effect=mock_run):
            version = asyncio.run(check_version("tool", "--version"))

        assert version == "2024.3.1.1"

    def test_bare_semver_with_pnpm_format(self):
        """pnpm prints the bare version too — same code path as npm."""

        async def mock_run(*args, **kwargs):
            return "9.15.0\n"

        with patch("posture_agent.utils.shell._run_capture_both", side_effect=mock_run):
            version = asyncio.run(check_version("pnpm", "--version"))

        assert version == "9.15.0"

    def test_word_then_semver_still_works(self):
        """Regression: the historic ``"<word> <semver>"`` shape must keep
        working alongside the bare-semver shape."""

        async def mock_run(*args, **kwargs):
            return "Python 3.12.5\n"

        with patch("posture_agent.utils.shell._run_capture_both", side_effect=mock_run):
            version = asyncio.run(check_version("python", "--version"))

        assert version == "3.12.5"


class TestExtensionlessShimUpgrade:
    """B9 (#623) — On Windows, ``shutil.which("npm")`` may return the
    extensionless ``npm`` Bash script (Node ships ``C:\\Program Files\\
    nodejs\\npm`` alongside ``npm.cmd``). ``CreateProcess`` cannot run the
    Bash variant. ``_resolve_for_exec`` must probe for a ``.cmd``/``.bat``
    sibling and prefer it.
    """

    def test_extensionless_path_upgrades_to_cmd_sibling(self, tmp_path):
        """When ``shutil.which`` returns an extensionless path on Windows,
        find the ``.cmd`` sibling and wrap it with ``cmd.exe /c``."""
        from posture_agent.utils import shell as shell_mod

        # Real files on disk so ``os.path.isfile`` actually fires.
        bare = tmp_path / "npm"
        cmd = tmp_path / "npm.cmd"
        bare.write_text("#!/bin/bash\nexec node ...\n")  # Bash shim body
        cmd.write_text("@echo off\nnpm-cli.js\n")

        with (
            patch.object(shell_mod.sys, "platform", "win32"),
            patch.object(shell_mod.shutil, "which", return_value=str(bare)),
            patch.object(shell_mod, "_get_env", return_value={"PATH": "stub"}),
        ):
            result = shell_mod._resolve_for_exec(("npm", "--version"))

        assert result == ("cmd.exe", "/c", str(cmd), "--version")

    def test_extensionless_path_upgrades_to_bat_sibling(self, tmp_path):
        """``.bat`` sibling is also a valid upgrade target."""
        from posture_agent.utils import shell as shell_mod

        bare = tmp_path / "tool"
        bat = tmp_path / "tool.bat"
        bare.write_text("#!/bin/bash\n")
        bat.write_text("@echo off\n")

        with (
            patch.object(shell_mod.sys, "platform", "win32"),
            patch.object(shell_mod.shutil, "which", return_value=str(bare)),
            patch.object(shell_mod, "_get_env", return_value={"PATH": "stub"}),
        ):
            result = shell_mod._resolve_for_exec(("tool", "--version"))

        assert result == ("cmd.exe", "/c", str(bat), "--version")

    def test_extensionless_path_upgrades_to_exe_sibling(self, tmp_path):
        """An ``.exe`` sibling is preferred over the bare script too —
        though .cmd/.bat are checked first per ``_WINDOWS_PROBE_EXTENSIONS``."""
        from posture_agent.utils import shell as shell_mod

        bare = tmp_path / "tool"
        exe = tmp_path / "tool.exe"
        bare.write_text("")
        exe.write_text("")

        with (
            patch.object(shell_mod.sys, "platform", "win32"),
            patch.object(shell_mod.shutil, "which", return_value=str(bare)),
            patch.object(shell_mod, "_get_env", return_value={"PATH": "stub"}),
        ):
            result = shell_mod._resolve_for_exec(("tool", "--version"))

        # ``.exe`` is not a shim → returned as the resolved absolute path,
        # not wrapped in cmd.exe.
        assert result == (str(exe), "--version")

    def test_extensionless_path_no_sibling_returned_unchanged(self, tmp_path):
        """When no sibling exists, leave the path as-is and let the subprocess
        machinery fail naturally — don't synthesize a fake path."""
        from posture_agent.utils import shell as shell_mod

        bare = tmp_path / "lonely"
        bare.write_text("#!/bin/bash\n")
        # No ``lonely.cmd``, ``lonely.bat``, or ``lonely.exe``.

        with (
            patch.object(shell_mod.sys, "platform", "win32"),
            patch.object(shell_mod.shutil, "which", return_value=str(bare)),
            patch.object(shell_mod, "_get_env", return_value={"PATH": "stub"}),
        ):
            result = shell_mod._resolve_for_exec(("lonely", "--version"))

        # No upgrade possible → falls through to the "not a shim" branch
        # and returns the resolved absolute path unwrapped. The subprocess
        # call will then fail with WinError 193 or similar.
        assert result == (str(bare), "--version")

    def test_path_with_extension_is_not_upgraded(self, tmp_path):
        """A path that already ends in ``.cmd``/``.bat``/``.exe`` is left
        alone — we only probe siblings when there's no extension."""
        from posture_agent.utils import shell as shell_mod

        cmd = tmp_path / "npm.cmd"
        cmd.write_text("@echo off\n")

        with (
            patch.object(shell_mod.sys, "platform", "win32"),
            patch.object(shell_mod.shutil, "which", return_value=str(cmd)),
            patch.object(shell_mod, "_get_env", return_value={"PATH": "stub"}),
        ):
            result = shell_mod._resolve_for_exec(("npm", "--version"))

        assert result == ("cmd.exe", "/c", str(cmd), "--version")


class TestCheckVersionShortFlagFallback:
    """B9 (#623) — Some shims ignore ``--version`` but accept ``-v``. When
    the canonical long form yields nothing parseable, retry once with the
    short form. The retry is bounded so there's no infinite loop.
    """

    def test_falls_back_to_dash_v_when_version_returns_empty(self):
        """``--version`` returns ``None`` → ``-v`` retry succeeds."""
        from posture_agent.utils import shell as shell_mod

        calls: list[tuple] = []

        async def mock_run(*args, **kwargs):
            calls.append(args)
            if args[1] == "--version":
                return None
            if args[1] == "-v":
                return "10.8.2\n"
            return None

        with patch.object(shell_mod, "_run_capture_both", side_effect=mock_run):
            version = asyncio.run(check_version("npm", "--version"))

        assert version == "10.8.2"
        # Both attempts were made, in order.
        assert calls[0] == ("npm", "--version")
        assert calls[1] == ("npm", "-v")

    def test_no_fallback_when_version_returns_real_semver(self):
        """``--version`` succeeds → ``-v`` is never invoked."""
        from posture_agent.utils import shell as shell_mod

        calls: list[tuple] = []

        async def mock_run(*args, **kwargs):
            calls.append(args)
            return "git version 2.43.0\n"

        with patch.object(shell_mod, "_run_capture_both", side_effect=mock_run):
            version = asyncio.run(check_version("git", "--version"))

        assert version == "2.43.0"
        assert calls == [("git", "--version")]

    def test_both_flags_fail_returns_none_no_loop(self):
        """``--version`` and ``-v`` both yield nothing → returns ``None``
        without infinite retry. Bounded fallback."""
        from posture_agent.utils import shell as shell_mod

        calls: list[tuple] = []

        async def mock_run(*args, **kwargs):
            calls.append(args)
            return None

        with patch.object(shell_mod, "_run_capture_both", side_effect=mock_run):
            version = asyncio.run(check_version("ghost", "--version"))

        assert version is None
        # Exactly two attempts: --version, then -v. No more.
        assert calls == [("ghost", "--version"), ("ghost", "-v")]

    def test_no_fallback_when_flag_is_not_dash_dash_version(self):
        """If the caller already passed a non-canonical flag (``-v``,
        ``version``, etc.) we don't invent another retry — they chose."""
        from posture_agent.utils import shell as shell_mod

        calls: list[tuple] = []

        async def mock_run(*args, **kwargs):
            calls.append(args)
            return None

        with patch.object(shell_mod, "_run_capture_both", side_effect=mock_run):
            version = asyncio.run(check_version("go", "version"))

        assert version is None
        assert calls == [("go", "version")]  # No ``-v`` retry.

    def test_dash_v_real_semver_beats_long_flag_garbage(self):
        """``--version`` returns a non-semver banner, ``-v`` returns a real
        semver. Prefer the real semver from the short flag."""
        from posture_agent.utils import shell as shell_mod

        async def mock_run(*args, **kwargs):
            if args[1] == "--version":
                # Some misconfigured shim that prints a help-like banner.
                return "Usage: foo [options]\n"
            if args[1] == "-v":
                return "1.2.3\n"
            return None

        with patch.object(shell_mod, "_run_capture_both", side_effect=mock_run):
            version = asyncio.run(check_version("foo", "--version"))

        assert version == "1.2.3"
