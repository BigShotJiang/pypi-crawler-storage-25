"""Tests for the C6 Windows hardware provider.

Runs on macOS / Linux CI by mocking ``platform.system()`` and the lazily
imported ``winreg`` / ``ctypes`` stdlib modules. The module under test is
written so that no Windows-only stdlib is touched until a method is invoked
on a Windows host, which lets these tests exercise every code path on a
non-Windows runner.
"""

from __future__ import annotations

import asyncio
import sys
import types
from unittest.mock import MagicMock, patch

from posture_agent.platforms import windows
from posture_agent.platforms.powershell import PSError, PSResult

# ---------------------------------------------------------------------------
# winreg fixture helpers
# ---------------------------------------------------------------------------


def _install_fake_winreg(
    *,
    open_key: object,
    query_value_ex: object,
) -> types.ModuleType:
    """Build a fake ``winreg`` module and install it under ``sys.modules``.

    The lazy import inside :meth:`WindowsHardware.machine_uuid` resolves
    against ``sys.modules['winreg']`` first, so injecting a stub there
    intercepts the lookup without needing a real ``winreg`` extension.
    """
    fake = types.ModuleType("winreg")
    fake.HKEY_LOCAL_MACHINE = 0  # type: ignore[attr-defined]
    fake.KEY_READ = 0x20019  # type: ignore[attr-defined]
    fake.KEY_WOW64_64KEY = 0x0100  # type: ignore[attr-defined]
    fake.OpenKey = open_key  # type: ignore[attr-defined]
    fake.QueryValueEx = query_value_ex  # type: ignore[attr-defined]
    sys.modules["winreg"] = fake
    return fake


def _winreg_context_manager(value: object):
    """Return a context-manager mock that ``OpenKey`` can return."""
    cm = MagicMock()
    cm.__enter__ = MagicMock(return_value=value)
    cm.__exit__ = MagicMock(return_value=False)
    return cm


# ---------------------------------------------------------------------------
# machine_uuid
# ---------------------------------------------------------------------------


class TestMachineUuid:
    def teardown_method(self):
        sys.modules.pop("winreg", None)

    def test_machine_uuid_reads_registry_when_present(self):
        key_handle = object()
        open_key = MagicMock(return_value=_winreg_context_manager(key_handle))
        query_value_ex = MagicMock(return_value=("ABC-123", 1))
        _install_fake_winreg(open_key=open_key, query_value_ex=query_value_ex)

        with patch("posture_agent.platforms.windows.platform.system", return_value="Windows"):
            result = asyncio.run(windows.WindowsHardware().machine_uuid())

        assert result == "ABC-123"
        open_key.assert_called_once()
        query_value_ex.assert_called_once_with(key_handle, "MachineGuid")

    def test_machine_uuid_returns_none_on_oserror(self):
        open_key = MagicMock(side_effect=OSError("denied"))
        _install_fake_winreg(open_key=open_key, query_value_ex=MagicMock())

        with patch("posture_agent.platforms.windows.platform.system", return_value="Windows"):
            result = asyncio.run(windows.WindowsHardware().machine_uuid())

        assert result is None

    def test_machine_uuid_returns_none_on_filenotfound(self):
        open_key = MagicMock(side_effect=FileNotFoundError("missing"))
        _install_fake_winreg(open_key=open_key, query_value_ex=MagicMock())

        with patch("posture_agent.platforms.windows.platform.system", return_value="Windows"):
            result = asyncio.run(windows.WindowsHardware().machine_uuid())

        assert result is None

    def test_machine_uuid_returns_none_when_value_empty(self):
        key_handle = object()
        open_key = MagicMock(return_value=_winreg_context_manager(key_handle))
        query_value_ex = MagicMock(return_value=("", 1))
        _install_fake_winreg(open_key=open_key, query_value_ex=query_value_ex)

        with patch("posture_agent.platforms.windows.platform.system", return_value="Windows"):
            result = asyncio.run(windows.WindowsHardware().machine_uuid())

        assert result is None

    def test_machine_uuid_returns_none_on_non_windows(self):
        # No fake winreg installed — if the impl forgets the platform guard
        # the lazy ``import winreg`` will raise ModuleNotFoundError on macOS.
        with patch("posture_agent.platforms.windows.platform.system", return_value="Darwin"):
            result = asyncio.run(windows.WindowsHardware().machine_uuid())

        assert result is None


# ---------------------------------------------------------------------------
# cpu_brand
# ---------------------------------------------------------------------------


class TestCpuBrand:
    """``cpu_brand`` prefers the friendly Win32_Processor.Name string and
    falls back to ``platform.processor()`` when PowerShell is unavailable
    or the cmdlet fails."""

    def _ps_ok(self, value: str) -> PSResult:
        return PSResult(ok=True, data=value, error=None, stderr="", duration_ms=10)

    def _ps_fail(self, kind: str = "exit_nonzero") -> PSResult:
        return PSResult(
            ok=False,
            data=None,
            error=PSError(kind=kind, message="boom"),
            stderr="boom",
            duration_ms=5,
        )

    def test_cpu_brand_returns_powershell_brand_string(self):
        # The user's reported AMD machine — Win32_Processor.Name returns the
        # clean marketing name rather than the family/model/stepping noise.
        ps = self._ps_ok("AMD Ryzen 9 5950X 16-Core Processor\r\n")
        with patch("posture_agent.platforms.windows.run_ps", return_value=ps):
            result = asyncio.run(windows.WindowsHardware().cpu_brand())
        assert result == "AMD Ryzen 9 5950X 16-Core Processor"

    def test_cpu_brand_strips_trailing_whitespace(self):
        ps = self._ps_ok("Intel(R) Core(TM) i9-13900K   ")
        with patch("posture_agent.platforms.windows.run_ps", return_value=ps):
            result = asyncio.run(windows.WindowsHardware().cpu_brand())
        assert result == "Intel(R) Core(TM) i9-13900K"

    def test_cpu_brand_falls_back_to_platform_processor_on_ps_failure(self):
        # Raw fallback strings get cleaned via _clean_processor_string before
        # being returned — see test cases below for the full transform table.
        with (
            patch(
                "posture_agent.platforms.windows.run_ps",
                return_value=self._ps_fail("cmdlet_not_found"),
            ),
            patch(
                "posture_agent.platforms.windows.platform.processor",
                return_value="AMD64 Family 23 Model 113 Stepping 0, AuthenticAMD",
            ),
        ):
            result = asyncio.run(windows.WindowsHardware().cpu_brand())
        assert result == "AMD64 (AMD)"

    def test_cpu_brand_falls_back_when_ps_returns_empty_string(self):
        with (
            patch(
                "posture_agent.platforms.windows.run_ps",
                return_value=self._ps_ok("   \r\n"),
            ),
            patch(
                "posture_agent.platforms.windows.platform.processor",
                return_value="Intel64 Family 6 Model 158 Stepping 13, GenuineIntel",
            ),
        ):
            result = asyncio.run(windows.WindowsHardware().cpu_brand())
        assert result == "Intel64 (Intel)"

    def test_cpu_brand_cleans_powershell_raw_arm64_string(self):
        # On virtualized Windows 11 ARM (Parallels/UTM on Apple Silicon),
        # Win32_Processor.Name itself returns the raw platform.processor()
        # shape — the post-process must clean it before returning.
        ps = self._ps_ok("ARMv8 (64-bit) Family 8 Model 0 Revision 0, Apple\r\n")
        with patch("posture_agent.platforms.windows.run_ps", return_value=ps):
            result = asyncio.run(windows.WindowsHardware().cpu_brand())
        assert result == "Apple Silicon (ARM64)"

    def test_cpu_brand_cleans_powershell_raw_amd64_string(self):
        # Defensive — if WMI ever hands back the raw shape on x64, we still
        # tidy it up rather than echo the noise back to the dashboard.
        ps = self._ps_ok("AMD64 Family 25 Model 1 Stepping 1, AuthenticAMD")
        with patch("posture_agent.platforms.windows.run_ps", return_value=ps):
            result = asyncio.run(windows.WindowsHardware().cpu_brand())
        assert result == "AMD64 (AMD)"

    def test_cpu_brand_falls_back_when_ps_returns_non_string(self):
        # ``run_ps(json_output=False)`` should always hand back a str on
        # success, but defend against a regression — a non-string ``data``
        # must not be returned verbatim.
        ps = PSResult(ok=True, data=12345, error=None, stderr="", duration_ms=10)
        with (
            patch("posture_agent.platforms.windows.run_ps", return_value=ps),
            patch(
                "posture_agent.platforms.windows.platform.processor",
                return_value="x86_64",
            ),
        ):
            result = asyncio.run(windows.WindowsHardware().cpu_brand())
        assert result == "x86_64"

    def test_cpu_brand_returns_unknown_when_everything_fails(self):
        with (
            patch(
                "posture_agent.platforms.windows.run_ps",
                return_value=self._ps_fail(),
            ),
            patch("posture_agent.platforms.windows.platform.processor", return_value=""),
        ):
            result = asyncio.run(windows.WindowsHardware().cpu_brand())
        assert result == "unknown"


# ---------------------------------------------------------------------------
# _clean_processor_string — raw → friendly brand transform
# ---------------------------------------------------------------------------


class TestCleanProcessorString:
    """Verifies the post-processing helper applied to both PS output (when it
    returns the raw ``platform.processor()`` shape) and the
    ``platform.processor()`` fallback. The motivating bug came from a
    virtualized Windows 11 ARM64 host on Apple Silicon — Parallels/UTM —
    where ``Win32_Processor.Name`` itself reports the raw shape rather than
    a marketing brand."""

    def test_cleans_apple_silicon_arm64(self):
        # The exact string the user's machine reported.
        result = windows._clean_processor_string(
            "ARMv8 (64-bit) Family 8 Model 0 Revision 0, Apple"
        )
        assert result == "Apple Silicon (ARM64)"

    def test_cleans_qualcomm_arm64(self):
        # Snapdragon-X laptops ("Copilot+" PCs).
        result = windows._clean_processor_string(
            "ARMv8 (64-bit) Family 8 Model 1 Revision 0, Qualcomm Technologies, Inc."
        )
        assert result == "Qualcomm Snapdragon (ARM64)"

    def test_cleans_generic_arm64_vendor(self):
        # Unknown vendor on ARM64 — fall back to ``<vendor> (ARM64)``.
        result = windows._clean_processor_string(
            "ARMv8 (64-bit) Family 8 Model 0 Revision 0, ARM Limited"
        )
        assert result == "ARM (ARM64)"

    def test_cleans_amd64_authenticamd(self):
        result = windows._clean_processor_string("AMD64 Family 25 Model 1 Stepping 1, AuthenticAMD")
        assert result == "AMD64 (AMD)"

    def test_cleans_intel64_genuineintel(self):
        result = windows._clean_processor_string(
            "Intel64 Family 6 Model 158 Stepping 13, GenuineIntel"
        )
        assert result == "Intel64 (Intel)"

    def test_real_amd_brand_passes_through(self):
        # Marketing brand from WMI must NOT be molested.
        assert (
            windows._clean_processor_string("AMD Ryzen 9 5950X 16-Core Processor")
            == "AMD Ryzen 9 5950X 16-Core Processor"
        )

    def test_real_intel_brand_passes_through(self):
        assert (
            windows._clean_processor_string("Intel(R) Core(TM) i9-13900K")
            == "Intel(R) Core(TM) i9-13900K"
        )

    def test_real_apple_silicon_marketing_brand_passes_through(self):
        # On a real Mac Pro running Windows ARM64 natively (rare but real),
        # Apple's brand string would already be friendly — don't break it.
        assert windows._clean_processor_string("Apple M3 Pro") == "Apple M3 Pro"

    def test_empty_string_returns_unknown(self):
        assert windows._clean_processor_string("") == "unknown"

    def test_none_returns_unknown(self):
        assert windows._clean_processor_string(None) == "unknown"

    def test_whitespace_only_returns_unknown(self):
        assert windows._clean_processor_string("   \r\n  ") == "unknown"

    def test_strips_surrounding_whitespace_before_match(self):
        # Trailing ``\r\n`` from Windows pipelines must not block the regex.
        result = windows._clean_processor_string(
            "  ARMv8 (64-bit) Family 8 Model 0 Revision 0, Apple  \r\n"
        )
        assert result == "Apple Silicon (ARM64)"

    def test_partial_raw_shape_passes_through(self):
        # Missing the trailing ``, <vendor>`` clause — not the raw shape we
        # know how to tidy. Pass through verbatim rather than guessing.
        assert (
            windows._clean_processor_string("AMD64 Family 25 Model 1 Stepping 1")
            == "AMD64 Family 25 Model 1 Stepping 1"
        )


# ---------------------------------------------------------------------------
# cpu_cores (B2 — was missing on WindowsHardware, silently reported 0)
# ---------------------------------------------------------------------------


class TestCpuCores:
    def test_cpu_cores_returns_os_count(self):
        with patch("posture_agent.platforms.base.os.cpu_count", return_value=8):
            result = asyncio.run(windows.WindowsHardware().cpu_cores())
        assert result == 8

    def test_cpu_cores_falls_back_to_multiprocessing(self):
        with (
            patch("posture_agent.platforms.base.os.cpu_count", return_value=None),
            patch("multiprocessing.cpu_count", return_value=4),
        ):
            result = asyncio.run(windows.WindowsHardware().cpu_cores())
        assert result == 4

    def test_cpu_cores_returns_zero_when_everything_fails(self):
        with (
            patch("posture_agent.platforms.base.os.cpu_count", return_value=None),
            patch(
                "multiprocessing.cpu_count",
                side_effect=NotImplementedError,
            ),
        ):
            result = asyncio.run(windows.WindowsHardware().cpu_cores())
        assert result == 0


# ---------------------------------------------------------------------------
# total_memory_bytes
# ---------------------------------------------------------------------------


class TestTotalMemoryBytes:
    def test_total_memory_bytes_calls_helper(self):
        with patch(
            "posture_agent.platforms.windows._global_memory_status_ex_total_phys",
            return_value=34_359_738_368,  # 32 GiB
        ):
            result = asyncio.run(windows.WindowsHardware().total_memory_bytes())

        assert result == 34_359_738_368

    def test_total_memory_bytes_returns_zero_on_failure(self):
        # Helper returns 0 on Win32 API failure; method must propagate.
        with patch(
            "posture_agent.platforms.windows._global_memory_status_ex_total_phys",
            return_value=0,
        ):
            result = asyncio.run(windows.WindowsHardware().total_memory_bytes())

        assert result == 0

    def test_global_memory_status_ex_returns_zero_on_non_windows(self):
        # The helper itself short-circuits on non-Windows so it can be safely
        # imported and called from macOS test runners. No ctypes invocation.
        with patch("posture_agent.platforms.windows.platform.system", return_value="Darwin"):
            result = windows._global_memory_status_ex_total_phys()

        assert result == 0


# ---------------------------------------------------------------------------
# os_version
# ---------------------------------------------------------------------------


class TestOsVersion:
    """``os_version`` returns just the marketing release + build (no
    leading ``"Windows "`` prefix — the web UI concatenates ``os_name``
    with ``os_version``, and a "Windows" prefix in the version field
    yields "Windows Windows 11 (Build 26200)"). The build number drives
    Windows 10 vs 11 detection: the kernel major version is still
    ``10.x`` on Windows 11, so we cannot trust slot 0 of
    :func:`platform.win32_ver`."""

    def test_os_version_windows_11_25h2_build_26200(self):
        # The user's reported machine — build 26200 is Windows 11 25H2.
        with patch(
            "posture_agent.platforms.windows.platform.win32_ver",
            return_value=("11", "10.0.26200", "", "Workstation"),
        ):
            assert windows.WindowsHardware().os_version() == "11 (Build 26200)"

    def test_os_version_windows_11_when_release_says_10(self):
        # 22631 is Windows 11 23H2 — but ``win32_ver`` reports release="10"
        # because the kernel major version is still 10.x. Build number is
        # the canonical signal.
        with patch(
            "posture_agent.platforms.windows.platform.win32_ver",
            return_value=("10", "10.0.22631", "", "Workstation"),
        ):
            assert windows.WindowsHardware().os_version() == "11 (Build 22631)"

    def test_os_version_windows_10_below_22000_threshold(self):
        # Build 19045 is Windows 10 22H2 — strictly below the 22000 cutoff.
        with patch(
            "posture_agent.platforms.windows.platform.win32_ver",
            return_value=("10", "10.0.19045", "", "Workstation"),
        ):
            assert windows.WindowsHardware().os_version() == "10 (Build 19045)"

    def test_os_version_22000_boundary_is_windows_11(self):
        # Build 22000 was the first Windows 11 release (RTM, October 2021).
        # Verify the boundary is inclusive.
        with patch(
            "posture_agent.platforms.windows.platform.win32_ver",
            return_value=("10", "10.0.22000", "", "Workstation"),
        ):
            assert windows.WindowsHardware().os_version() == "11 (Build 22000)"

    def test_os_version_falls_back_to_release_when_version_blank(self):
        # When win32_ver gives us only a bare release token, return that
        # alone (no "Windows " prefix in the version field).
        with patch(
            "posture_agent.platforms.windows.platform.win32_ver",
            return_value=("11", "", "", ""),
        ):
            assert windows.WindowsHardware().os_version() == "11"

    def test_os_version_returns_unknown_when_all_blank(self):
        # Nothing usable from win32_ver — must NOT echo back "Windows"
        # (that would still produce "Windows Windows" in the UI).
        with patch(
            "posture_agent.platforms.windows.platform.win32_ver",
            return_value=("", "", "", ""),
        ):
            assert windows.WindowsHardware().os_version() == "unknown"

    def test_os_version_strips_leading_windows_prefix_in_fallback(self):
        # Some Python builds report ``release="Windows 10"``. Strip the
        # leading "Windows " token so we never double-prefix in the UI.
        with patch(
            "posture_agent.platforms.windows.platform.win32_ver",
            return_value=("Windows 10", "", "", ""),
        ):
            assert windows.WindowsHardware().os_version() == "10"

    def test_os_version_handles_malformed_version_string(self):
        # If win32_ver returns something we can't parse a build out of, fall
        # back to whatever string it gave us rather than crashing.
        with patch(
            "posture_agent.platforms.windows.platform.win32_ver",
            return_value=("10", "garbage", "", ""),
        ):
            assert windows.WindowsHardware().os_version() == "10"

    def test_os_version_handles_two_segment_version(self):
        # "10.0" lacks the third segment — no build number, fall back to
        # whatever was provided.
        with patch(
            "posture_agent.platforms.windows.platform.win32_ver",
            return_value=("10", "10.0", "", ""),
        ):
            assert windows.WindowsHardware().os_version() == "10"


# ---------------------------------------------------------------------------
# os_name (sanity — covered by stub tests, repeated here for symmetry)
# ---------------------------------------------------------------------------


class TestOsName:
    def test_os_name_returns_windows(self):
        assert windows.WindowsHardware().os_name() == "Windows"
