"""Tests for :class:`posture_agent.platforms.windows.WindowsScheduler` (C12).

The scheduler shells out to ``schtasks.exe`` via :mod:`subprocess`. These tests
patch both ``subprocess.run`` (so no schtasks process is ever spawned) and
``platform.system`` (so the cross-platform guards behave as if running on
Windows). The tests run on macOS / Linux CI without modification.
"""

from __future__ import annotations

import subprocess
from types import SimpleNamespace
from unittest.mock import patch

import pytest
from posture_agent.platforms import windows
from posture_agent.platforms.base import (
    SchedulerStatus,
    UnsupportedPlatformError,
)


def _fake_proc(returncode: int = 0, stdout: str = "", stderr: str = "") -> SimpleNamespace:
    """Build a stand-in for ``subprocess.CompletedProcess`` with the given fields."""
    return SimpleNamespace(returncode=returncode, stdout=stdout, stderr=stderr)


# ---------------------------------------------------------------------------
# install()
# ---------------------------------------------------------------------------


class TestWindowsSchedulerInstall:
    def test_install_hourly_calls_schtasks_create(self):
        sched = windows.WindowsScheduler()
        captured: dict = {}

        def fake_run(cmd, *args, **kwargs):
            captured["cmd"] = cmd
            captured["kwargs"] = kwargs
            return _fake_proc(returncode=0, stdout="SUCCESS: ...")

        # The new scheduler API takes a full argv. The CLI builds this as
        # [sys.executable, "-m", "posture_agent", "collect", "--report"] so
        # scheduled runs route through the same interpreter the user ran
        # `setup` from, independent of PATH.
        program_args = [
            r"C:\Python311\python.exe",
            "-m",
            "posture_agent",
            "collect",
            "--report",
        ]

        with (
            patch(
                "posture_agent.platforms.windows.platform.system",
                return_value="Windows",
            ),
            patch(
                "posture_agent.platforms.windows.subprocess.run",
                side_effect=fake_run,
            ),
        ):
            sched.install(program_args)

        cmd = captured["cmd"]
        assert cmd[0] == "schtasks.exe"
        assert "/Create" in cmd
        # Schedule is HOURLY by default
        sc_idx = cmd.index("/SC")
        assert cmd[sc_idx + 1] == "HOURLY"
        # Task name is the canonical "Intercept Agent"
        tn_idx = cmd.index("/TN")
        assert cmd[tn_idx + 1] == "Intercept Agent"
        # /F is present so re-install is idempotent
        assert "/F" in cmd
        # The /TR action quotes the executable and appends remaining argv.
        # Critically, the literal "intercept-agent" must NOT appear -- the
        # scheduled task uses `python -m posture_agent` for PATH-independence.
        tr_idx = cmd.index("/TR")
        assert (
            cmd[tr_idx + 1]
            == r'"C:\Python311\python.exe" -m posture_agent collect --report'
        )
        assert "intercept-agent" not in cmd[tr_idx + 1]

    def test_install_passes_capture_and_timeout(self):
        sched = windows.WindowsScheduler()
        captured: dict = {}

        def fake_run(cmd, *args, **kwargs):
            captured["kwargs"] = kwargs
            return _fake_proc(returncode=0)

        with (
            patch(
                "posture_agent.platforms.windows.platform.system",
                return_value="Windows",
            ),
            patch(
                "posture_agent.platforms.windows.subprocess.run",
                side_effect=fake_run,
            ),
        ):
            sched.install([r"C:\Python311\python.exe", "-m", "posture_agent"])

        assert captured["kwargs"].get("capture_output") is True
        assert captured["kwargs"].get("text") is True
        assert captured["kwargs"].get("check") is False
        # Timeout is bounded; the exact value lives in the implementation.
        assert isinstance(captured["kwargs"].get("timeout"), int)
        assert captured["kwargs"]["timeout"] > 0

    def test_install_raises_on_failure(self):
        sched = windows.WindowsScheduler()

        def fake_run(cmd, *args, **kwargs):
            return _fake_proc(returncode=1, stderr="ERROR: Access is denied.")

        with (
            patch(
                "posture_agent.platforms.windows.platform.system",
                return_value="Windows",
            ),
            patch(
                "posture_agent.platforms.windows.subprocess.run",
                side_effect=fake_run,
            ),
            pytest.raises(RuntimeError) as excinfo,
        ):
            sched.install([r"C:\Python311\python.exe", "-m", "posture_agent"])

        # The error message surfaces the exit code and stderr so users can
        # diagnose without scraping captured logs.
        assert "schtasks /Create failed" in str(excinfo.value)
        assert "exit=1" in str(excinfo.value)
        assert "Access is denied" in str(excinfo.value)

    def test_install_raises_on_non_windows(self):
        sched = windows.WindowsScheduler()
        with (
            patch(
                "posture_agent.platforms.windows.platform.system",
                return_value="Darwin",
            ),
            pytest.raises(UnsupportedPlatformError),
        ):
            sched.install([r"C:\Python311\python.exe", "-m", "posture_agent"])

    def test_install_with_custom_interval_uppercases(self):
        """A non-'hourly' interval is forwarded uppercased so `daily` => `DAILY`."""
        sched = windows.WindowsScheduler()
        captured: dict = {}

        def fake_run(cmd, *args, **kwargs):
            captured["cmd"] = cmd
            return _fake_proc(returncode=0)

        with (
            patch(
                "posture_agent.platforms.windows.platform.system",
                return_value="Windows",
            ),
            patch(
                "posture_agent.platforms.windows.subprocess.run",
                side_effect=fake_run,
            ),
        ):
            sched.install(
                [r"C:\Python311\python.exe", "-m", "posture_agent"],
                interval="daily",
            )

        cmd = captured["cmd"]
        sc_idx = cmd.index("/SC")
        assert cmd[sc_idx + 1] == "DAILY"

    def test_install_quotes_python_path_with_spaces(self):
        """sys.executable under "Program Files" contains spaces. The /TR
        value must wrap the program in double quotes so schtasks tokenizes
        it as a single argument."""
        sched = windows.WindowsScheduler()
        captured: dict = {}

        def fake_run(cmd, *args, **kwargs):
            captured["cmd"] = cmd
            return _fake_proc(returncode=0)

        with (
            patch(
                "posture_agent.platforms.windows.platform.system",
                return_value="Windows",
            ),
            patch(
                "posture_agent.platforms.windows.subprocess.run",
                side_effect=fake_run,
            ),
        ):
            sched.install(
                [
                    r"C:\Program Files\Python311\python.exe",
                    "-m",
                    "posture_agent",
                    "collect",
                    "--report",
                ]
            )

        tr_idx = captured["cmd"].index("/TR")
        assert captured["cmd"][tr_idx + 1] == (
            r'"C:\Program Files\Python311\python.exe" -m posture_agent collect --report'
        )

    def test_install_rejects_empty_program_args(self):
        """An empty argv would produce a malformed /TR value -- reject it."""
        sched = windows.WindowsScheduler()
        with (
            patch(
                "posture_agent.platforms.windows.platform.system",
                return_value="Windows",
            ),
            pytest.raises(ValueError),
        ):
            sched.install([])

    def test_install_translates_seconds_to_hourly(self):
        """The CLI passes ``interval=str(interval_seconds)`` (e.g. ``"3600"``).

        The Windows scheduler must translate that to a valid schtasks
        ``/SC`` keyword (HOURLY) rather than passing the raw number,
        otherwise schtasks rejects with ``ERROR: Invalid Schedule Type
        specified.`` (exit 2147500037) -- the launch-day regression.
        """
        sched = windows.WindowsScheduler()
        captured: dict = {}

        def fake_run(cmd, *args, **kwargs):
            captured["cmd"] = cmd
            return _fake_proc(returncode=0)

        with (
            patch(
                "posture_agent.platforms.windows.platform.system",
                return_value="Windows",
            ),
            patch(
                "posture_agent.platforms.windows.subprocess.run",
                side_effect=fake_run,
            ),
        ):
            sched.install(
                [r"C:\Python311\python.exe", "-m", "posture_agent"],
                interval="3600",
            )

        cmd = captured["cmd"]
        sc_idx = cmd.index("/SC")
        assert cmd[sc_idx + 1] == "HOURLY", (
            f"3600s must translate to /SC HOURLY, got {cmd[sc_idx + 1]!r}"
        )
        # 3600s = 1h => /MO 1 keeps the cadence explicit in the Task
        # Scheduler GUI without changing the meaning.
        mo_idx = cmd.index("/MO")
        assert cmd[mo_idx + 1] == "1"
        # Critically: the bare seconds value must never reach /SC.
        assert "3600" not in cmd[sc_idx : sc_idx + 2]

    def test_install_translates_seconds_to_minute(self):
        """Sub-hour intervals translate to ``/SC MINUTE /MO <n>``."""
        sched = windows.WindowsScheduler()
        captured: dict = {}

        def fake_run(cmd, *args, **kwargs):
            captured["cmd"] = cmd
            return _fake_proc(returncode=0)

        with (
            patch(
                "posture_agent.platforms.windows.platform.system",
                return_value="Windows",
            ),
            patch(
                "posture_agent.platforms.windows.subprocess.run",
                side_effect=fake_run,
            ),
        ):
            # 30 minutes
            sched.install(
                [r"C:\Python311\python.exe", "-m", "posture_agent"],
                interval="1800",
            )

        cmd = captured["cmd"]
        sc_idx = cmd.index("/SC")
        assert cmd[sc_idx + 1] == "MINUTE"
        mo_idx = cmd.index("/MO")
        assert cmd[mo_idx + 1] == "30"

    def test_install_translates_seconds_to_daily(self):
        """86400s translates to ``/SC DAILY`` (with explicit ``/MO 1``)."""
        sched = windows.WindowsScheduler()
        captured: dict = {}

        def fake_run(cmd, *args, **kwargs):
            captured["cmd"] = cmd
            return _fake_proc(returncode=0)

        with (
            patch(
                "posture_agent.platforms.windows.platform.system",
                return_value="Windows",
            ),
            patch(
                "posture_agent.platforms.windows.subprocess.run",
                side_effect=fake_run,
            ),
        ):
            sched.install(
                [r"C:\Python311\python.exe", "-m", "posture_agent"],
                interval="86400",
            )

        cmd = captured["cmd"]
        sc_idx = cmd.index("/SC")
        assert cmd[sc_idx + 1] == "DAILY"
        mo_idx = cmd.index("/MO")
        assert cmd[mo_idx + 1] == "1"

    def test_install_keyword_daily_emits_no_modifier(self):
        """The bare ``"daily"`` keyword maps to ``/SC DAILY`` with no ``/MO``."""
        sched = windows.WindowsScheduler()
        captured: dict = {}

        def fake_run(cmd, *args, **kwargs):
            captured["cmd"] = cmd
            return _fake_proc(returncode=0)

        with (
            patch(
                "posture_agent.platforms.windows.platform.system",
                return_value="Windows",
            ),
            patch(
                "posture_agent.platforms.windows.subprocess.run",
                side_effect=fake_run,
            ),
        ):
            sched.install(
                [r"C:\Python311\python.exe", "-m", "posture_agent"],
                interval="daily",
            )

        cmd = captured["cmd"]
        sc_idx = cmd.index("/SC")
        assert cmd[sc_idx + 1] == "DAILY"
        # Keyword form intentionally omits /MO -- "every day" is the default.
        assert "/MO" not in cmd

    def test_translate_interval_unit(self):
        """Unit coverage for the seconds -> (/SC, /MO) helper."""
        # Bare keyword default.
        assert windows._translate_interval("hourly") == ("HOURLY", None)
        # Seconds-as-string from the CLI.
        assert windows._translate_interval("3600") == ("HOURLY", 1)
        assert windows._translate_interval("1800") == ("MINUTE", 30)
        assert windows._translate_interval("60") == ("MINUTE", 1)
        # Sub-minute floors to MINUTE/1 rather than crashing.
        assert windows._translate_interval("30") == ("MINUTE", 1)
        # Multi-hour divides evenly.
        assert windows._translate_interval("7200") == ("HOURLY", 2)
        # Daily divides evenly.
        assert windows._translate_interval("86400") == ("DAILY", 1)
        # Non-divisible >24h caps at DAILY/1.
        assert windows._translate_interval("90000") == ("DAILY", 1)
        # Empty / garbage falls back to HOURLY rather than emitting bad /SC.
        assert windows._translate_interval("") == ("HOURLY", None)
        assert windows._translate_interval("nonsense") == ("HOURLY", None)
        # Explicit keywords pass through uppercased.
        assert windows._translate_interval("Daily") == ("DAILY", None)
        assert windows._translate_interval("WEEKLY") == ("WEEKLY", None)


# ---------------------------------------------------------------------------
# uninstall()
# ---------------------------------------------------------------------------


class TestWindowsSchedulerUninstall:
    def test_uninstall_calls_delete(self):
        sched = windows.WindowsScheduler()
        captured: dict = {}

        def fake_run(cmd, *args, **kwargs):
            captured["cmd"] = cmd
            return _fake_proc(returncode=0, stdout="SUCCESS: ...")

        with (
            patch(
                "posture_agent.platforms.windows.platform.system",
                return_value="Windows",
            ),
            patch(
                "posture_agent.platforms.windows.subprocess.run",
                side_effect=fake_run,
            ),
        ):
            sched.uninstall()

        cmd = captured["cmd"]
        assert cmd[0] == "schtasks.exe"
        assert "/Delete" in cmd
        assert "/F" in cmd
        tn_idx = cmd.index("/TN")
        assert cmd[tn_idx + 1] == "Intercept Agent"

    def test_uninstall_swallows_missing_task(self):
        """A 'cannot find' error from schtasks means the task is already absent."""
        sched = windows.WindowsScheduler()

        def fake_run(cmd, *args, **kwargs):
            return _fake_proc(
                returncode=1,
                stderr="ERROR: The system cannot find the file specified.",
            )

        with (
            patch(
                "posture_agent.platforms.windows.platform.system",
                return_value="Windows",
            ),
            patch(
                "posture_agent.platforms.windows.subprocess.run",
                side_effect=fake_run,
            ),
        ):
            sched.uninstall()  # must not raise

    def test_uninstall_raises_other_errors(self):
        sched = windows.WindowsScheduler()

        def fake_run(cmd, *args, **kwargs):
            return _fake_proc(returncode=1, stderr="ERROR: Access is denied.")

        with (
            patch(
                "posture_agent.platforms.windows.platform.system",
                return_value="Windows",
            ),
            patch(
                "posture_agent.platforms.windows.subprocess.run",
                side_effect=fake_run,
            ),
            pytest.raises(RuntimeError) as excinfo,
        ):
            sched.uninstall()

        assert "schtasks /Delete failed" in str(excinfo.value)
        assert "Access is denied" in str(excinfo.value)

    def test_uninstall_raises_on_non_windows(self):
        sched = windows.WindowsScheduler()
        with (
            patch(
                "posture_agent.platforms.windows.platform.system",
                return_value="Linux",
            ),
            pytest.raises(UnsupportedPlatformError),
        ):
            sched.uninstall()


# ---------------------------------------------------------------------------
# status()
# ---------------------------------------------------------------------------


# Sample LIST output adapted from a real `schtasks /Query /FO LIST /V` dump.
# Field ordering, blank lines, and trailing whitespace are preserved so the
# parser is exercised against output as close to the real thing as practical.
_LIST_RUNNING = """\

Folder: \\
HostName:                             DEV-PC
TaskName:                             \\Intercept Agent
Next Run Time:                        4/30/2026 4:00:00 PM
Status:                               Running
Logon Mode:                           Interactive only
Last Run Time:                        4/30/2026 3:00:00 PM
Last Result:                          0
Author:                               DEV-PC\\test
Task To Run:                          "C:\\Users\\test\\intercept-agent.exe" collect --report
Start In:                             N/A
Comment:                              N/A
Scheduled Task State:                 Enabled
"""

_LIST_READY = """\

Folder: \\
HostName:                             DEV-PC
TaskName:                             \\Intercept Agent
Next Run Time:                        4/30/2026 4:00:00 PM
Status:                               Ready
Logon Mode:                           Interactive only
Last Run Time:                        4/30/2026 3:00:00 PM
Last Result:                          0
"""


class TestWindowsSchedulerStatus:
    def test_status_when_installed_running(self):
        sched = windows.WindowsScheduler()

        def fake_run(cmd, *args, **kwargs):
            return _fake_proc(returncode=0, stdout=_LIST_RUNNING)

        with (
            patch(
                "posture_agent.platforms.windows.platform.system",
                return_value="Windows",
            ),
            patch(
                "posture_agent.platforms.windows.subprocess.run",
                side_effect=fake_run,
            ),
        ):
            status = sched.status()

        assert isinstance(status, SchedulerStatus)
        assert status.installed is True
        assert status.running is True
        assert status.last_run == "4/30/2026 3:00:00 PM"
        assert status.raw is not None
        # Spot-check that the parser preserved a few well-known fields.
        assert status.raw.get("TaskName") == "\\Intercept Agent"
        assert status.raw.get("Status") == "Running"

    def test_status_when_installed_not_running(self):
        sched = windows.WindowsScheduler()

        def fake_run(cmd, *args, **kwargs):
            return _fake_proc(returncode=0, stdout=_LIST_READY)

        with (
            patch(
                "posture_agent.platforms.windows.platform.system",
                return_value="Windows",
            ),
            patch(
                "posture_agent.platforms.windows.subprocess.run",
                side_effect=fake_run,
            ),
        ):
            status = sched.status()

        assert status.installed is True
        assert status.running is False
        assert status.last_run == "4/30/2026 3:00:00 PM"

    def test_status_when_not_installed(self):
        sched = windows.WindowsScheduler()

        def fake_run(cmd, *args, **kwargs):
            return _fake_proc(
                returncode=1,
                stderr="ERROR: The system cannot find the file specified.",
            )

        with (
            patch(
                "posture_agent.platforms.windows.platform.system",
                return_value="Windows",
            ),
            patch(
                "posture_agent.platforms.windows.subprocess.run",
                side_effect=fake_run,
            ),
        ):
            status = sched.status()

        assert status.installed is False
        assert status.running is None
        assert status.last_run is None

    def test_status_on_non_windows(self):
        sched = windows.WindowsScheduler()
        with patch(
            "posture_agent.platforms.windows.platform.system",
            return_value="Darwin",
        ):
            status = sched.status()

        assert status.installed is False
        assert status.running is None
        assert status.last_run is None

    def test_status_handles_subprocess_oserror(self):
        """If schtasks itself can't be invoked (e.g., PATH stripped), don't crash."""
        sched = windows.WindowsScheduler()

        def fake_run(cmd, *args, **kwargs):
            raise OSError("no such file: schtasks.exe")

        with (
            patch(
                "posture_agent.platforms.windows.platform.system",
                return_value="Windows",
            ),
            patch(
                "posture_agent.platforms.windows.subprocess.run",
                side_effect=fake_run,
            ),
        ):
            status = sched.status()

        assert status.installed is False
        assert status.running is None
        assert status.last_run is None

    def test_status_handles_subprocess_subprocesserror(self):
        sched = windows.WindowsScheduler()

        def fake_run(cmd, *args, **kwargs):
            raise subprocess.SubprocessError("timeout-ish")

        with (
            patch(
                "posture_agent.platforms.windows.platform.system",
                return_value="Windows",
            ),
            patch(
                "posture_agent.platforms.windows.subprocess.run",
                side_effect=fake_run,
            ),
        ):
            status = sched.status()

        assert status.installed is False
