"""Tests for the C9 Windows MCP host paths.

Pure path-construction tests — no filesystem reads. Each test sets a fake
``%APPDATA%`` and ``Path.home()`` and confirms the returned path resolves to
the canonical Windows location.
"""

from __future__ import annotations

from pathlib import Path

from posture_agent.platforms import windows


class TestClaudeDesktopConfig:
    def test_uses_appdata_when_set(self, monkeypatch, tmp_path: Path):
        monkeypatch.setenv("APPDATA", str(tmp_path / "Roaming"))
        monkeypatch.setattr(Path, "home", lambda: tmp_path)

        path = windows.WindowsMCPHostPaths().claude_desktop_config()
        assert path == tmp_path / "Roaming" / "Claude" / "claude_desktop_config.json"

    def test_falls_back_when_appdata_unset(self, monkeypatch, tmp_path: Path):
        monkeypatch.delenv("APPDATA", raising=False)
        monkeypatch.setattr(Path, "home", lambda: tmp_path)

        path = windows.WindowsMCPHostPaths().claude_desktop_config()
        assert path == tmp_path / "AppData" / "Roaming" / "Claude" / "claude_desktop_config.json"


class TestCursorMcpConfig:
    def test_uses_appdata_when_set(self, monkeypatch, tmp_path: Path):
        monkeypatch.setenv("APPDATA", str(tmp_path / "Roaming"))
        monkeypatch.setattr(Path, "home", lambda: tmp_path)

        path = windows.WindowsMCPHostPaths().cursor_mcp_config()
        assert (
            path
            == tmp_path
            / "Roaming"
            / "Cursor"
            / "User"
            / "globalStorage"
            / "cursor.mcp"
            / "mcp.json"
        )

    def test_falls_back_when_appdata_unset(self, monkeypatch, tmp_path: Path):
        monkeypatch.delenv("APPDATA", raising=False)
        monkeypatch.setattr(Path, "home", lambda: tmp_path)

        path = windows.WindowsMCPHostPaths().cursor_mcp_config()
        assert (
            path
            == tmp_path
            / "AppData"
            / "Roaming"
            / "Cursor"
            / "User"
            / "globalStorage"
            / "cursor.mcp"
            / "mcp.json"
        )
