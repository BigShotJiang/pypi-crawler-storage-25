"""Tests for the macOS ``installed_ai_tools`` discovery.

Patches ``Path.exists``, ``shutil.which``, ``run_command``, and
``check_version`` at the import site
(``posture_agent.platforms.macos.*``) so the suite runs on any OS.
"""

from __future__ import annotations

import sys
from unittest.mock import AsyncMock, patch

import pytest
from posture_agent.platforms import macos

pytestmark = pytest.mark.skipif(
    sys.platform != "darwin",
    reason="macOS-specific AI tool detection test",
)


def _make_app_paths(*names: str) -> set[str]:
    """Helper: return a set of canonical /Applications/<Name>.app paths."""
    return {f"/Applications/{n}.app" for n in names}


class TestInstalledAiToolsDesktopApps:
    """Scan of ``/Applications/<App>.app`` AI desktop apps."""

    async def test_no_apps_no_clis_returns_empty(self):
        with (
            patch("posture_agent.platforms.macos.Path.exists", return_value=False),
            patch("posture_agent.platforms.macos.shutil.which", return_value=None),
        ):
            tools, errors = await macos.MacOSIDEDiscovery().installed_ai_tools()

        assert tools == []
        assert errors == []

    async def test_claude_desktop_detected_with_plist_version(self):
        existing = _make_app_paths("Claude")

        def _exists(self):
            # `self` is the Path instance; check whether its full path is in
            # our existing-apps set OR is the Info.plist for one of them.
            s = str(self)
            if s in existing:
                return True
            return any(s == f"{a}/Contents/Info.plist" for a in existing)

        async def _run_command(*args):
            # `defaults read <plist> CFBundleShortVersionString`
            if args[0] == "defaults" and args[1] == "read":
                return "0.7.0\n"
            return None

        with (
            patch("posture_agent.platforms.macos.Path.exists", _exists),
            patch("posture_agent.platforms.macos.shutil.which", return_value=None),
            patch("posture_agent.platforms.macos.run_command", side_effect=_run_command),
        ):
            tools, errors = await macos.MacOSIDEDiscovery().installed_ai_tools()

        claude = next(t for t in tools if t["name"] == "Claude Desktop")
        assert claude["type"] == "desktop"
        assert claude["version"] == "0.7.0"
        assert errors == []

    async def test_chatgpt_desktop_detected_no_plist(self):
        """App bundle exists but Info.plist read fails — still report."""
        existing = _make_app_paths("ChatGPT")

        def _exists(self):
            return str(self) in existing  # Info.plist won't exist

        async def _run_command(*args):
            return None

        with (
            patch("posture_agent.platforms.macos.Path.exists", _exists),
            patch("posture_agent.platforms.macos.shutil.which", return_value=None),
            patch("posture_agent.platforms.macos.run_command", side_effect=_run_command),
        ):
            tools, errors = await macos.MacOSIDEDiscovery().installed_ai_tools()

        chatgpt = next(t for t in tools if t["name"] == "ChatGPT Desktop")
        assert chatgpt["type"] == "desktop"
        assert chatgpt["version"] == ""
        assert errors == []

    async def test_cursor_falls_back_to_cli_version_when_plist_missing(self):
        """No Info.plist, but `cursor --version` succeeds via CLI shim."""
        existing = _make_app_paths("Cursor")  # bundle dir only, no plist

        def _exists(self):
            return str(self) in existing

        async def _run_command(*_args):
            return None

        with (
            patch("posture_agent.platforms.macos.Path.exists", _exists),
            patch(
                "posture_agent.platforms.macos.shutil.which",
                side_effect=lambda b: "/usr/local/bin/cursor" if b == "cursor" else None,
            ),
            patch("posture_agent.platforms.macos.run_command", side_effect=_run_command),
            patch(
                "posture_agent.platforms.macos.check_version",
                new=AsyncMock(return_value="0.42.0"),
            ),
        ):
            tools, errors = await macos.MacOSIDEDiscovery().installed_ai_tools()

        cursor = next(t for t in tools if t["name"] == "Cursor" and t["type"] == "desktop")
        assert cursor["version"] == "0.42.0"
        assert errors == []


class TestInstalledAiToolsCli:
    """Scan of AI CLIs on PATH."""

    async def test_claude_code_cli_detected(self):
        with (
            patch("posture_agent.platforms.macos.Path.exists", return_value=False),
            patch(
                "posture_agent.platforms.macos.shutil.which",
                side_effect=lambda b: "/opt/homebrew/bin/claude" if b == "claude" else None,
            ),
            patch(
                "posture_agent.platforms.macos.check_version",
                new=AsyncMock(return_value="1.0.5"),
            ),
        ):
            tools, errors = await macos.MacOSIDEDiscovery().installed_ai_tools()

        cli = [t for t in tools if t["type"] == "cli"]
        assert len(cli) == 1
        assert cli[0]["name"] == "Claude Code"
        assert cli[0]["version"] == "1.0.5"
        assert errors == []

    async def test_tabnine_no_version_flag(self):
        """Tabnine has version_flag=None — entry reports with empty version."""
        with (
            patch("posture_agent.platforms.macos.Path.exists", return_value=False),
            patch(
                "posture_agent.platforms.macos.shutil.which",
                side_effect=lambda b: "/usr/local/bin/tabnine" if b == "tabnine" else None,
            ),
            patch(
                "posture_agent.platforms.macos.check_version",
                new=AsyncMock(return_value=None),
            ),
        ):
            tools, errors = await macos.MacOSIDEDiscovery().installed_ai_tools()

        tabnine = next(t for t in tools if t["name"] == "Tabnine")
        assert tabnine["type"] == "cli"
        assert tabnine["version"] == ""
        assert errors == []
