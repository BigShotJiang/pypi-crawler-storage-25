# Posture Agent - CLAUDE.md

Developer endpoint agent distributed via PyPI as `intercept-agent`. Runs on developer machines to collect environment metadata (installed tools, security posture, IDE configuration) and reports it to the Intercept API for supply chain security assessment.

**Current version**: Check `VERSION` file (bump before every commit).

## Critical Rules

1. **macOS-only today.** All collectors use macOS-specific commands (`ioreg`, `sysctl`, `fdesetup`, `spctl`, `launchctl`). When adding Linux/Windows support, every collector must be guarded with `platform.system()` checks -- never assume macOS.

2. **Minimal dependencies.** This package installs on user machines. Only four runtime deps: `click`, `pydantic`, `pyyaml`, `httpx`. Do NOT add dependencies without strong justification. Use stdlib whenever possible (e.g., `logging` instead of `loguru`).

3. **Metadata only, never secrets.** Collectors report names, versions, boolean statuses, and file names. NEVER read file contents of SSH private keys, credentials, tokens, or config values. The `security.py` collector reads only the first 64 bytes of SSH key files to detect the key type header.

4. **All collectors must be fault-tolerant.** Every detection call can fail (tool not installed, permission denied, timeout). Always wrap in try/except, append to `errors` list, and continue. A single collector failure must never crash the agent.

5. **Async throughout.** All collectors and shell commands are async. Use `asyncio.gather` for parallel execution. Shell commands go through `utils/shell.py`, never `subprocess` directly.

6. **Version bump required.** CI/CD publishes to PyPI on version change. Bump `VERSION` before committing.

## Project Structure

```
services/posture-agent/
  VERSION                          # Semver, read by hatchling for PyPI version
  pyproject.toml                   # Build config (hatchling), deps, entry point
  resources/
    com.hijacksecurity.intercept-agent.plist   # Template for launchd
  config/
    dev-local.yaml                 # localhost gateway (use --debug for verbose logging)
    dev-docker.yaml                # docker network gateway URL
    test.yaml                      # test cluster gateway URL
    prod.yaml                      # production gateway URL
  posture_agent/
    __init__.py
    main.py                        # Click CLI: collect, install, uninstall, status, update, setup
    core/
      config.py                    # Settings class, YAML + env var loading
      logging.py                   # stdlib logging setup (text or JSON format)
    collectors/
      base.py                      # BaseCollector ABC + CollectorResult model
      machine.py                   # Hostname, OS, CPU, memory, username
      ides.py                      # VS Code, Cursor, JetBrains, Xcode, vim, etc.
      extensions.py                # IDE extensions (VS Code CLI or filesystem fallback)
      ai_tools.py                  # AI coding tools (CLI + IDE extensions)
      dev_tools.py                 # Languages, build tools, cloud CLIs, containers
      security.py                  # Git signing, SSH keys, FileVault, firewall, Gatekeeper
      package_managers.py          # Homebrew, npm, pip, cargo, etc.
      mcp_servers.py               # MCP server configs with risk indicators
    models/
      report.py                    # PostureReportPayload Pydantic model
    services/
      fingerprint.py               # Machine UUID via ioreg (SHA256-hashed)
      reporter.py                  # HTTP POST to API with retry/backoff
    utils/
      shell.py                     # run_command(), check_version(), PATH expansion
  tests/
    test_cli.py                    # Click CLI smoke tests
    test_collectors.py             # Per-collector integration tests
    test_fingerprint.py            # Fingerprint stability tests
```

## Patterns and Conventions

### Adding a New Collector

1. Create `posture_agent/collectors/my_collector.py`:

```python
"""My new collector."""

from posture_agent.collectors.base import BaseCollector, CollectorResult
from posture_agent.utils.shell import check_version, run_command


class MyCollector(BaseCollector):
    name = "my_collector"  # This becomes the key in the report payload

    async def collect(self) -> CollectorResult:
        errors: list[str] = []
        data: list[dict[str, str]] = []

        try:
            which_result = await run_command("which", "mytool")
            if which_result and which_result.strip():
                version = await check_version("mytool", "--version") or ""
                data.append({"name": "MyTool", "version": version})
        except Exception as e:
            errors.append(f"MyTool: {e}")

        return CollectorResult(collector=self.name, data=data, errors=errors)
```

2. Register in `main.py` -- add to imports and to `run_collection()`:

```python
from posture_agent.collectors.my_collector import MyCollector

# Inside run_collection(), after other collector checks:
if settings.collectors.my_collector:
    collectors.append(MyCollector())
```

3. Add toggle to `CollectorsConfig` in `core/config.py`:

```python
class CollectorsConfig(BaseModel):
    # ... existing fields ...
    my_collector: bool = True
```

4. Add field to `PostureReportPayload` in `models/report.py`:

```python
class PostureReportPayload(BaseModel):
    # ... existing fields ...
    my_collector: list[Any] | dict[str, Any] = []
```

5. Add tests in `tests/test_collectors.py`.

### Adding a New Tool Detection

For tools detected by binary name and version flag, add to the appropriate definitions list:

```python
# In dev_tools.py (DEV_TOOL_DEFINITIONS), package_managers.py (PACKAGE_MANAGERS),
# or — for AI tool CLIs — platforms/macos.py (AI_CLI_TOOLS_MACOS) AND
# platforms/windows.py (_AI_CLI_TOOLS_WINDOWS):
("Display Name", "binary_name", "--version"),
```

For AI **desktop apps** (Claude Desktop, ChatGPT Desktop, Cursor, Windsurf,
Codeium, etc.) the install layout is OS-specific — add tuples to:

* `AI_DESKTOP_APP_DEFINITIONS_MACOS` in `platforms/macos.py` for `/Applications/<App>.app` bundles
* `_AI_DESKTOP_APP_DEFINITIONS_WINDOWS` in `platforms/windows.py` for `%LOCALAPPDATA%\<App>\<App>.exe` paths

Windows version extraction reads embedded EXE metadata via `_get_exe_version`
(PowerShell `Get-Item ... .VersionInfo.ProductVersion`); macOS reads
`Contents/Info.plist`'s `CFBundleShortVersionString`. Both layers fall back
to the app's CLI shim `--version` when the metadata read fails.

The `check_version()` helper extracts the first semver-like pattern from the first line of output. If the first line has no version number (e.g., `Application: grype`), it scans subsequent lines for a `Version:` field. Multi-word flags like `"version --client"` are split automatically.

### Adding an IDE

Add a tuple to `IDE_DEFINITIONS` in `ides.py`:

```python
# (display_name, binary_or_None, app_bundle_path_or_None, version_flag_or_None)
("My IDE", "myide", "/Applications/MyIDE.app", "--version"),
```

Detection checks the app bundle first (macOS `/Applications/`), then falls back to `which <binary>`. Version is read from `Info.plist` if the app bundle exists, otherwise from the CLI flag.

### Shell Command Execution

Always use the helpers in `utils/shell.py`:

```python
from posture_agent.utils.shell import run_command, check_version

# run_command: returns stdout as str or None on any failure
result = await run_command("git", "config", "--global", "user.name")
if result:  # Always check for None
    value = result.strip()

# check_version: extracts version pattern from command output
version = await check_version("node", "--version")  # Returns "20.11.0" or None
```

- `run_command` has a 10-second default timeout.
- `_get_expanded_path()` adds common tool locations (`/opt/homebrew/bin`, `~/.cargo/bin`, nvm dirs, etc.) so tools are found even under launchd's minimal PATH.
- Never call `subprocess` directly; always go through these helpers.

## Data Flow

The posture-agent always routes through the **gateway** (nginx), never directly to the API service. The gateway rewrites `/api/v1/core/...` to `/api/v1/...` before forwarding to the API. This ensures the same URL construction works in all environments (dev-local, dev-docker, test, prod).

```
1. CLI invoked:     intercept-agent collect [--report]
2. Fingerprint:     ioreg -> IOPlatformUUID -> SHA256[:32]
3. Collectors:      asyncio.gather(machine, ides, extensions, ai_tools,
                                   dev_tools, security, package_managers, mcp_servers)
4. Payload:         PostureReportPayload(fingerprint, agent_version, collected_at, ...)
5. Dry run:         JSON to stdout
6. Report mode:     POST {GATEWAY_URL}/api/v1/core/posture/reports
                    Gateway rewrites: /api/v1/core/* -> /api/v1/* -> API service
                    Headers: X-API-Key (if hsk_ api_key configured)
                    tenant_id resolved server-side from API key
                    Retry: 3 attempts, exponential backoff (2^attempt seconds)
```

Config `api.url` values per environment:
- `dev-local.yaml`: `http://localhost` (local gateway on port 80)
- `dev-docker.yaml`: `http://gateway` (nginx container)
- `test.yaml`: `https://intercept.test.hijacksecurity.com` (test gateway)
- `prod.yaml`: `https://intercept.hijacksecurity.com` (production gateway)

### Machine Fingerprint

Stable unique ID per machine, generated in `services/fingerprint.py`:
1. Primary: `ioreg` IOPlatformUUID (macOS hardware UUID)
2. Fallback: IOPlatformSerialNumber
3. Last resort: `hostname-architecture`

Result is always a 32-character hex string (SHA256 truncated).

### Report Payload Schema

```json
{
  "fingerprint": "a1b2c3d4e5f6...",
  "agent_version": "0.3.4",
  "collected_at": "2025-01-24T12:00:00Z",
  "enrolled_email": "dev@example.com",
  "machine": {
    "hostname": "dev-laptop",
    "username": "developer",
    "os_name": "macOS",
    "os_version": "15.2",
    "architecture": "arm64",
    "cpu_brand": "Apple M3 Pro",
    "cpu_cores": 12,
    "memory_gb": 36.0
  },
  "ides": [{"name": "VS Code", "version": "1.96.0", "binary": "code"}],
  "extensions": {
    "vscode": [{"id": "ms-python.python", "version": "2024.0.1"}],
    "jetbrains": [{"id": "plugin-name", "ide": "IntelliJIdea2024.3", "version": "1.0"}]
  },
  "ai_tools": [
    {"name": "Claude Code", "type": "cli", "binary": "claude", "version": "1.0.0"},
    {"name": "github.copilot", "type": "extension", "editor": "VS Code", "version": ""}
  ],
  "dev_tools": [{"name": "Git", "binary": "git", "version": "2.43.0", "path": "/usr/bin/git"}],
  "security": {
    "git_signing_enabled": true,
    "git_signing_format": "ssh",
    "git_name": "Dev User",
    "git_email": "dev@example.com",
    "ssh_key_count": 2,
    "ssh_keys": [{"name": "id_ed25519", "algorithm": "ed25519"}],
    "ssh_agent_keys": 1,
    "ssh_agent_type": "1Password",
    "filevault_enabled": true,
    "firewall_enabled": true,
    "gatekeeper_enabled": true,
    "global_hooks_path": "",
    "credential_helper": "osxkeychain",
    "allowed_signers_configured": true,
    "allowed_signers_exists": true
  },
  "package_managers": [{"name": "Homebrew", "binary": "brew", "version": "4.2.0"}],
  "mcp_servers": [
    {
      "name": "github",
      "tool": "claude",
      "config_path": "/Users/dev/.claude/mcp.json",
      "transport": "stdio",
      "command": "npx",
      "args": ["-y", "@modelcontextprotocol/server-github"],
      "url": null,
      "env_keys": ["GITHUB_TOKEN"],
      "risk_indicators": ["credentials"]
    }
  ]
}
```

## Configuration

### Load Priority (first found wins)

1. `~/.config/intercept/agent.yaml` (user config, created by `install` command)
2. `config/{ENVIRONMENT}.yaml` (from package directory)

### Environment Variable Overrides

| Variable | Effect |
|---|---|
| `ENVIRONMENT` | Selects config file: `dev-local`, `dev-docker`, `test`, `prod` (default: `dev-local`) |
| `INTERCEPT_API_URL` | Overrides `api.url` |
| `INTERCEPT_API_KEY` | Sets `api.api_key`. Must be `hsk_` prefixed. Sent as `X-API-Key` header. |
| `INTERCEPT_TENANT_ID` | Sets `api.tenant_id` (included in report body) |

### Disabling Collectors

In `agent.yaml` or environment config:

```yaml
collectors:
  mcp_servers: false    # Skip MCP server discovery
  security: false       # Skip security posture checks
```

### Re-enrolling on an Already-Configured Machine

`setup` refuses to overwrite an existing `hsk_`-keyed config by default
to prevent silent token swaps. Two re-enrollment paths exist:

1. **`setup --token <new_token> --force`** -- preferred. Wipes
   `~/.config/intercept/` (and stops/uninstalls the scheduler if
   present) before continuing with normal enrollment. This is the
   recommended path going forward.
2. **`uninstall --purge` then `setup --token <new_token>`** -- explicit
   two-step path for users who want to manually verify the wipe.

The "Agent is already configured" hint that fires when neither path is
taken **must reference `sys.executable -m posture_agent`** (not the bare
`intercept-agent` console script). The console script is unreliable on
Windows when pip's user Scripts dir isn't on PATH -- which is exactly
the failure mode that drove `python -m posture_agent` to become the
documented universal form. Keep these aligned:

* `main.py::setup` -- the printed hint
* `services/identity/app/schemas/enrollment.py::install_command` -- the
  copy-paste command on the web `/settings/agent` page
* `README.md` -- the "Re-enrolling on an already-configured machine"
  section

If you change one, update the others in the same PR.

## Testing

```bash
# Run all tests
cd services/posture-agent && PYTHONPATH=. ../../.venv/bin/pytest tests/ -v

# Run a specific test class
PYTHONPATH=. ../../.venv/bin/pytest tests/test_collectors.py::TestMCPServersCollector -v

# Dry-run collection (no API call)
PYTHONPATH=. ../../.venv/bin/python -m posture_agent.main collect

# Test with debug logging
PYTHONPATH=. ../../.venv/bin/python -m posture_agent.main --debug collect
```

Tests run the actual collectors against the local machine (integration-style). They verify:
- Each collector returns a `CollectorResult` with the correct `collector` name
- Data types match expectations (list, dict)
- Ubiquitous tools like Git are detected
- Fingerprint is stable across calls (32 hex chars)
- CLI commands exit cleanly and produce expected output

When mocking is needed (e.g., testing error paths), patch `posture_agent.utils.shell.run_command`.

## Common Mistakes

**1. Forgetting None checks on `run_command` return values.**
`run_command` returns `None` on any failure (timeout, command not found, non-zero exit). Always check before calling `.strip()`.
```python
# WRONG:
result = await run_command("which", "node")
path = result.strip()  # AttributeError if tool not installed

# RIGHT:
result = await run_command("which", "node")
if result and result.strip():
    path = result.strip()
```

**2. Hardcoding macOS paths without platform guards.**
When extending for Linux/Windows, never assume `/Applications/`, `~/Library/`, or macOS commands exist.
```python
# WRONG (breaks on Linux):
plist_path = Path.home() / "Library" / "Application Support" / "JetBrains"

# RIGHT:
import platform
if platform.system() == "Darwin":
    config_dir = Path.home() / "Library" / "Application Support" / "JetBrains"
elif platform.system() == "Linux":
    config_dir = Path.home() / ".local" / "share" / "JetBrains"
```

**3. Not adding the new collector to all four locations.**
A new collector requires changes in: (1) the collector module, (2) `CollectorsConfig` in `config.py`, (3) `run_collection()` in `main.py`, (4) `PostureReportPayload` in `report.py`. Missing any of these causes silent data loss or startup errors.

**4. Reading sensitive file contents.**
The agent collects metadata about files (names, types, existence), never their contents. The SSH key detection reads only a 64-byte header to identify the key format. Do not expand this pattern.

**5. Blocking the event loop.**
All I/O must be async. Use `run_command()` (which uses `asyncio.create_subprocess_exec`) instead of `subprocess.run()` in collectors. The only exceptions are the CLI commands (`install`, `uninstall`, `status`) which use `subprocess.run` directly since they are not performance-sensitive.

**6. Adding heavyweight dependencies.**
This runs on user machines installed via `pip`/`pipx`. Every dependency increases install size, potential conflicts, and attack surface. Prefer stdlib solutions.

## Scheduling

The `install` command creates a per-user periodic task that invokes
**`sys.executable -m posture_agent collect --report`** on the configured
interval (default: 3600s). The scheduler is platform-specific:

| Platform | Mechanism | Location |
|---|---|---|
| macOS | launchd plist | `~/Library/LaunchAgents/com.hijacksecurity.intercept-agent.plist` |
| Windows | Task Scheduler | Per-user task `Intercept Agent` (created via `schtasks.exe /Create`) |
| Linux | (planned) systemd user unit | TBD |

**Why `sys.executable -m posture_agent` and not `intercept-agent`?** The
bare `intercept-agent` console script is unreliable on Windows because
`pip install --user` lands it in `%APPDATA%\Python\Python3xx\Scripts`,
which is **not** on the default PATH. Before 0.4.20 the installer tried
to resolve the console script and failed with `intercept-agent not found.
Pass --bin-path or add pip's bin dir to PATH.` -- and that hint contradicted
our public stance that users should never need to munge PATH. Routing through
`sys.executable` (always defined, always points at the interpreter the user
ran `setup` from) makes the scheduled task work everywhere with zero PATH
configuration.

Other behaviors:
- Captures the user's expanded PATH (`EnvironmentVariables.PATH` in the
  plist) so collectors can still find brew / asdf / nvm-managed tools under
  launchd's otherwise-minimal PATH. (Windows: Task Scheduler inherits the
  user's PATH at run time.)
- Logs to `~/.config/intercept/logs/agent.{stdout,stderr}.log` (macOS).
- Runs at load (`RunAtLoad: true`, macOS) and does not stay alive
  (`KeepAlive: false`, macOS).

The CLI prints a platform-aware message during install
(`Installing launchd schedule...` on macOS, `Installing Windows Scheduled
Task...` on Windows, `Installing systemd user unit...` on Linux) so
operators always see the actually-running step.

The `Scheduler` protocol (`platforms/base.py`) accepts the **full argv** as
a `list[str]`, not a single executable path. If you add a Linux/cron
scheduler later, mirror this contract so the CLI can keep building the
argv in exactly one place (`_scheduled_program_args` in `main.py`).

**Interval contract.** The CLI invokes every scheduler with
`interval=str(settings.schedule.interval_seconds)` -- i.e. the **seconds**
form (`"3600"` for the default hourly cadence). macOS consumes this
directly (launchd `StartInterval` is integer-seconds). Windows, however,
requires the schtasks `/SC` keyword set: `MINUTE`, `HOURLY`, `DAILY`,
`WEEKLY`, `MONTHLY`, `ONCE`, `ONSTART`, `ONLOGON`, `ONIDLE`, `ONEVENT`.
Passing the bare seconds value to `/SC` triggers `ERROR: Invalid Schedule
Type specified.` (exit `2147500037`) -- this is what took 0.4.20 down on
Windows.

`WindowsScheduler.install()` translates seconds → `(/SC, /MO)` via
`_translate_interval`: e.g. `"3600"` → `/SC HOURLY /MO 1`, `"1800"` →
`/SC MINUTE /MO 30`, `"86400"` → `/SC DAILY /MO 1`. Bare keyword
intervals (`"hourly"`, `"daily"`) still work and emit no `/MO`. Any new
scheduler MUST translate the seconds form to whatever its OS expects --
never round-trip the raw seconds value into an unrelated OS schedule
field.

## Building and Publishing

```bash
# Build wheel and sdist
cd services/posture-agent && python -m build

# Publishing is handled by CI (ci-posture-agent.yml) on VERSION bump
```

Build system: `hatchling`. Version is read dynamically from the `VERSION` file.

## Install Entry Points (Cross-Platform)

The package ships **two** equivalent invocation paths so users always have
a working command regardless of whether the console script ends up on
PATH:

| Form | Defined by | Notes |
|---|---|---|
| `intercept-agent ...` | `[project.scripts]` in `pyproject.toml` -> `posture_agent.main:cli` | Recommended. Lands on PATH automatically with `pipx` / `uv`; flaky with `pip install --user` on Windows (script dir not on PATH by default). |
| `python -m posture_agent ...` | `posture_agent/__main__.py` -> `from posture_agent.main import cli; cli()` | PATH-independent fallback. Works on every platform whenever the package is importable. Documented in README + web `/settings/agent` page. |

Recommended public install instructions (README + web UI):

1. **`pipx install intercept-agent && intercept-agent setup --token …`** — primary recommendation. `pipx` handles PATH on every OS.
2. **`uvx intercept-agent setup --token …`** — one-shot, no install, for users who already have `uv`.
3. **`pip install intercept-agent && python -m posture_agent setup --token …`** — fallback that works regardless of PATH.

Do NOT recommend "add %APPDATA%\Python\Python3xx\Scripts to your PATH" — that's a workaround, not a fix. The `pipx` / `python -m posture_agent` paths solve it without making the user understand `%APPDATA%`.

If you change the `cli` symbol's import location, update both
`pyproject.toml` `[project.scripts]` AND `posture_agent/__main__.py`.

The install command string produced by identity
(`services/identity/app/schemas/enrollment.py::install_command`) is also
load-bearing — it's the copy-paste command on the web `/settings/agent`
"Generate Install Command" modal. Keep it aligned with the recommended
form above.
