"""IDE collector."""

from posture_agent.collectors.base import BaseCollector, CollectorResult
from posture_agent.platforms import get_bundle


class IDECollector(BaseCollector):
    """Collects installed IDE information."""

    name = "ides"

    async def collect(self) -> CollectorResult:
        bundle = get_bundle()
        ides, errors = await bundle.ides.installed_ides()

        return CollectorResult(
            collector=self.name,
            data=ides,
            errors=errors,
        )
