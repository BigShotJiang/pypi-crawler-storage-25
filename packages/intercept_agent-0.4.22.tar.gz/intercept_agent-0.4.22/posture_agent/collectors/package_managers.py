"""Package manager collector."""

import shutil

from posture_agent.collectors.base import BaseCollector, CollectorResult
from posture_agent.utils.shell import check_version

# Package manager definitions: (name, binary, version_flag)
PACKAGE_MANAGERS = [
    ("Homebrew", "brew", "--version"),
    ("npm", "npm", "--version"),
    ("pnpm", "pnpm", "--version"),
    ("yarn", "yarn", "--version"),
    ("pip", "pip3", "--version"),
    ("uv", "uv", "--version"),
    ("pipx", "pipx", "--version"),
    ("Poetry", "poetry", "--version"),
    ("pdm", "pdm", "--version"),
    ("Cargo", "cargo", "--version"),
    ("Go Modules", "go", "version"),
    ("Composer", "composer", "--version"),
    ("Gem", "gem", "--version"),
    ("CocoaPods", "pod", "--version"),
    ("Swift PM", "swift", "package --version"),
    ("Volta", "volta", "--version"),
    ("asdf", "asdf", "--version"),
    ("mise", "mise", "--version"),
    ("Proto", "proto", "--version"),
    ("Pixi", "pixi", "--version"),
]


class PackageManagerCollector(BaseCollector):
    """Collects installed package managers."""

    name = "package_managers"

    async def collect(self) -> CollectorResult:
        errors: list[str] = []
        managers: list[dict[str, str]] = []

        for name, binary, version_flag in PACKAGE_MANAGERS:
            try:
                resolved = shutil.which(binary)
                if resolved:
                    version = await check_version(binary, version_flag) or ""
                    managers.append(
                        {
                            "name": name,
                            "binary": binary,
                            "version": version,
                        }
                    )
                    # B9 (#623): when the binary is on PATH but no version
                    # came back, leave a breadcrumb so we can debug remotely.
                    # npm on Windows is the canonical case (extensionless
                    # Bash shim defeats CreateProcess).
                    if not version:
                        errors.append(
                            f"{name}: shutil.which returned {resolved} (no version captured)"
                        )
            except Exception as e:
                errors.append(f"{name}: {e}")

        return CollectorResult(
            collector=self.name,
            data=managers,
            errors=errors,
        )
