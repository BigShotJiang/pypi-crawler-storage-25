"""Machine info collector."""

import getpass
import platform

from posture_agent.collectors.base import BaseCollector, CollectorResult
from posture_agent.platforms import get_bundle


class MachineCollector(BaseCollector):
    """Collects machine hardware and OS information."""

    name = "machine"

    async def collect(self) -> CollectorResult:
        errors: list[str] = []
        bundle = get_bundle()
        hw = bundle.hardware

        hostname = platform.node()
        os_name = hw.os_name()
        os_version = hw.os_version()
        architecture = platform.machine()

        # CPU brand
        cpu_brand = ""
        try:
            cpu_brand = await hw.cpu_brand()
        except Exception as e:
            errors.append(f"CPU brand: {e}")

        # CPU cores
        cpu_cores = 0
        try:
            cpu_cores = await hw.cpu_cores()
        except Exception as e:
            errors.append(f"CPU cores: {e}")

        # Memory
        memory_gb = 0
        try:
            mem_bytes = await hw.total_memory_bytes()
            if mem_bytes:
                memory_gb = round(mem_bytes / (1024**3), 1)
        except Exception as e:
            errors.append(f"Memory: {e}")

        # Username (cross-platform via stdlib; falls back through env vars internally)
        try:
            username = getpass.getuser()
        except Exception:
            username = ""

        return CollectorResult(
            collector=self.name,
            data={
                "hostname": hostname,
                "username": username,
                "os_name": os_name,
                "os_version": os_version,
                "architecture": architecture,
                "cpu_brand": cpu_brand,
                "cpu_cores": cpu_cores,
                "memory_gb": memory_gb,
            },
            errors=errors,
        )
