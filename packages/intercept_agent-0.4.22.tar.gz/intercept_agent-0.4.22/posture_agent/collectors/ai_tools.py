"""AI tools collector.

The collector reports three categories of AI tooling, all merged into a
single ``data`` list keyed by ``type``:

* ``"desktop"`` — AI desktop apps (Claude Desktop, ChatGPT Desktop, Cursor,
  Windsurf, Codeium). Sourced from the platform bundle's
  :meth:`~IDEDiscovery.installed_ai_tools` because OS install conventions
  differ wildly between macOS (``/Applications/<App>.app``) and Windows
  (``%LOCALAPPDATA%\\<App>\\<App>.exe`` + EXE metadata read).
* ``"cli"`` — AI CLIs (Claude Code, Aider, GitHub Copilot CLI, Gemini CLI,
  ...). Also sourced from the platform bundle so version extraction reuses
  the bundle's :func:`check_version` helper. Per-platform CLI lists live
  alongside the desktop-app lists in the platform module.
* ``"extension"`` — AI extensions (``github.copilot``, ``cursor.cursor-ai``,
  ...) discovered by invoking each editor shim's ``--list-extensions``
  command. This logic stays in the collector because it's
  platform-agnostic — every supported editor exposes the same shim
  interface on every OS.

Dedupe is by (name, type, editor) tuple so a tool detected via both the
desktop scan and the CLI shim (e.g., Cursor) doesn't show up twice in the
same category.
"""

import shutil

from posture_agent.collectors.base import BaseCollector, CollectorResult
from posture_agent.platforms import get_bundle
from posture_agent.utils.shell import run_command

# Known AI extension IDs across editors
AI_EXTENSIONS = {
    "github.copilot",
    "github.copilot-chat",
    "sourcegraph.cody-ai",
    "continue.continue",
    "amazonwebservices.amazon-q-vscode",
    "saoudrizwan.claude-dev",
    "anthropic.claude-code",
    "cursor.cursor-ai",
    "supermaven.supermaven",
    "codeium.codeium",
    "tabnine.tabnine-vscode",
}

# Editors to scan for AI extensions: (binary, display_name)
_AI_EXTENSION_EDITORS = [
    ("code", "VS Code"),
    ("code-insiders", "VS Code Insiders"),
    ("cursor", "Cursor"),
    ("windsurf", "Windsurf"),
    ("trae", "Trae"),
]


class AIToolsCollector(BaseCollector):
    """Collects AI coding tool information."""

    name = "ai_tools"

    async def collect(self) -> CollectorResult:
        errors: list[str] = []
        ai_tools: list[dict[str, str]] = []
        seen: set[tuple[str, str]] = set()  # (name, type) — extensions keyed (name, editor)

        # 1. Desktop apps + AI CLIs from the platform bundle. The bundle
        # encapsulates the OS-specific install layout — macOS scans
        # /Applications/, Windows scans %LOCALAPPDATA% + the registry-style
        # PATH overlay. Per-tool failures land in `bundle_errors`; the scan
        # itself never raises.
        try:
            bundle_tools, bundle_errors = await get_bundle().ides.installed_ai_tools()
            errors.extend(bundle_errors)
            for entry in bundle_tools:
                key = (entry.get("name", ""), entry.get("type", ""))
                if key in seen:
                    continue
                seen.add(key)
                ai_tools.append(entry)
        except Exception as e:
            errors.append(f"installed_ai_tools: {e}")

        # 2. Editor extensions for AI tools — platform-agnostic, all
        # supported editors expose `--list-extensions --show-versions` on
        # every OS. The `--show-versions` flag emits `id@version` lines so
        # we can populate the AI tool's `version` field from the same
        # extension scan that powers `extensions.vscode` / `extensions.cursor`,
        # keeping the dashboard's AI Tools card and IDE Extensions card
        # consistent.
        for binary, editor_name in _AI_EXTENSION_EDITORS:
            try:
                if not shutil.which(binary):
                    continue

                result = await run_command(binary, "--list-extensions", "--show-versions")
                if not result:
                    continue

                # Parse `id@version` lines (or bare `id` if `--show-versions`
                # is unsupported by an older shim) into a lowercase-id ->
                # version map so AI extension lookup is case-insensitive.
                installed_versions: dict[str, str] = {}
                for line in result.strip().split("\n"):
                    line = line.strip()
                    if not line:
                        continue
                    if "@" in line:
                        ext_id, version = line.rsplit("@", 1)
                        installed_versions[ext_id.strip().lower()] = version.strip()
                    else:
                        installed_versions[line.lower()] = ""

                for ai_ext_id in AI_EXTENSIONS:
                    key = ai_ext_id.lower()
                    if key in installed_versions:
                        ai_tools.append(
                            {
                                "name": ai_ext_id,
                                "type": "extension",
                                "editor": editor_name,
                                "version": installed_versions[key],
                            }
                        )
            except Exception as e:
                errors.append(f"AI extensions ({binary}): {e}")

        return CollectorResult(
            collector=self.name,
            data=ai_tools,
            errors=errors,
        )
