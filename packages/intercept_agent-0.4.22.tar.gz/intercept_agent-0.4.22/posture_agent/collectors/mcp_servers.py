"""MCP servers collector - discovers configured MCP servers for AI tools."""

import json
from pathlib import Path
from typing import Any

from posture_agent.collectors.base import BaseCollector, CollectorResult
from posture_agent.platforms import get_bundle

# Cross-platform MCP config file locations relative to ``Path.home()``.
#
# These paths use the same layout on macOS, Windows, and Linux because the
# tools store user-scoped MCP config under the user's home directory rather
# than under a platform-specific app data root.
#
# - ``.claude.json``: Claude Code CLI per-user config (single FILE — note the
#   leading dot is ``.claude.json``, not the directory ``.claude/``). Same path
#   on every platform.
# - ``.claude/mcp.json``: Defensive fallback for older Claude installs that
#   used the directory layout. Real-world installs are unlikely after the CLI
#   migrated to ``.claude.json``, but cheap to keep.
# - ``.cursor/mcp.json``: Cursor user-scope MCP config.
# - ``.continue/config.json``: Continue extension config (uses the same
#   ``mcpServers`` top-level key).
# - ``mcp.json``: Generic config in the user's home; some tools default here.
#
# VS Code is intentionally NOT in this list — it is platform-specific and is
# resolved through ``bundle.mcp_paths.vscode_mcp_config()`` which returns the
# correct ``%APPDATA%\\Code\\User\\mcp.json`` (Windows) or
# ``~/Library/Application Support/Code/User/mcp.json`` (macOS) plus the
# Insiders variant.
#
# We also intentionally do NOT scan project-scoped ``.mcp.json`` (Claude Code
# reads one from the current working directory). The agent runs as a
# scheduled task with no specific project context, so any "current"
# directory we scan would be arbitrary and misleading.
MCP_CONFIG_PATHS = [
    ("claude", ".claude.json"),
    ("claude", ".claude/mcp.json"),
    ("cursor", ".cursor/mcp.json"),
    ("continue", ".continue/config.json"),
    ("generic", "mcp.json"),
]

# Keywords indicating credential-related environment variables
CREDENTIAL_KEYWORDS = {"key", "token", "secret", "password", "api", "auth", "credential"}

# Keywords indicating shell execution
SHELL_COMMANDS = {"bash", "sh", "zsh", "cmd", "powershell", "pwsh"}

# Keywords indicating filesystem access
FILESYSTEM_KEYWORDS = {"file", "fs", "path", "directory", "folder", "read", "write"}


def detect_risk_indicators(server: dict[str, Any]) -> list[str]:
    """Detect potential risk indicators for an MCP server configuration."""
    risks: list[str] = []

    command = (server.get("command") or "").lower()
    args = server.get("args") or []
    args_str = " ".join(str(a) for a in args).lower()
    env = server.get("env") or {}
    url = (server.get("url") or "").lower()
    transport = (server.get("transport") or "stdio").lower()

    # Check for shell execution
    if any(shell in command for shell in SHELL_COMMANDS):
        risks.append("shell")

    # Check for credential env vars
    env_keys_lower = [k.lower() for k in env.keys()]
    if any(kw in key for key in env_keys_lower for kw in CREDENTIAL_KEYWORDS):
        risks.append("credentials")

    # Check for network access
    if transport in ("sse", "http", "streamable-http"):
        risks.append("network")
    if url and ("http://" in url or "https://" in url):
        risks.append("network")

    # Check for filesystem access indicators
    combined = f"{command} {args_str}"
    if any(kw in combined for kw in FILESYSTEM_KEYWORDS):
        risks.append("filesystem")
    # Also check if any args look like file paths
    if any("/" in str(a) or "\\" in str(a) for a in args):
        risks.append("filesystem")

    return list(set(risks))  # Dedupe


def parse_mcp_config(config_path: Path, tool: str) -> list[dict[str, Any]]:
    """Parse an MCP config file and extract server definitions.

    Raises ``OSError`` (permission denied, I/O error) and
    ``json.JSONDecodeError`` (corrupted JSON) so the caller can record a
    breadcrumb in the report's ``errors`` list. Callers must check
    ``config_path.exists()`` before invoking — a missing file is the
    expected "user does not have this client installed" case and should
    NOT surface as an error.
    """
    servers: list[dict[str, Any]] = []

    content = config_path.read_text()
    data = json.loads(content)

    # Both Claude Desktop, Claude Code (~/.claude.json), Cursor, VS Code,
    # and Continue use the same top-level ``{"mcpServers": {...}}`` shape.
    # Claude Code's ~/.claude.json carries additional sibling keys (project
    # state, telemetry preferences, etc.) but the MCP block, when present,
    # lives at this canonical location, so the parser is uniform across
    # tools.
    servers_data: dict[str, Any] = data.get("mcpServers", {}) if isinstance(data, dict) else {}

    for name, server_config in servers_data.items():
        if not isinstance(server_config, dict):
            continue

        # Determine transport type
        transport = "stdio"  # default
        if "url" in server_config:
            transport = server_config.get("transport", "sse")
        elif "command" in server_config:
            transport = "stdio"

        server_entry = {
            "name": name,
            "tool": tool,
            "config_path": str(config_path),
            "transport": transport,
            "command": server_config.get("command"),
            "args": server_config.get("args"),
            "url": server_config.get("url"),
            "env_keys": list((server_config.get("env") or {}).keys()),
            "risk_indicators": detect_risk_indicators(server_config),
        }
        servers.append(server_entry)

    return servers


class MCPServersCollector(BaseCollector):
    """Collects MCP (Model Context Protocol) server configurations."""

    name = "mcp_servers"

    async def collect(self) -> CollectorResult:
        errors: list[str] = []
        all_servers: list[dict[str, Any]] = []

        home = Path.home()

        # Cross-platform standard paths (Claude Code CLI, Cursor, Continue, generic).
        for tool, relative_path in MCP_CONFIG_PATHS:
            self._scan(home / relative_path, tool, all_servers, errors)

        # Platform-aware host paths. The bundle dispatches to the macOS or
        # Windows implementation; both expose the same ``mcp_paths`` slice
        # so the collector is no longer platform-branched. Linux raises
        # UnsupportedPlatformError at bundle construction, which is fine —
        # the agent itself does not start on unsupported platforms.
        try:
            bundle = get_bundle()
        except Exception as e:
            # Defensive — should never fire in shipping builds because the
            # CLI entry point already gates on platform support, but tests
            # / first-time installs occasionally land here.
            errors.append(f"MCP host paths: {e}")
            return CollectorResult(collector=self.name, data=all_servers, errors=errors)

        mcp_paths = bundle.mcp_paths
        self._scan(mcp_paths.claude_desktop_config(), "claude-desktop", all_servers, errors)
        self._scan(mcp_paths.cursor_mcp_config(), "cursor-desktop", all_servers, errors)
        for vscode_path in mcp_paths.vscode_mcp_config():
            # VS Code Stable and Insiders are reported under the same tool
            # name; the `config_path` field carries the disambiguating
            # location. This matches the existing Cursor / Claude pattern.
            self._scan(vscode_path, "vscode", all_servers, errors)

        return CollectorResult(
            collector=self.name,
            data=all_servers,
            errors=errors,
        )

    @staticmethod
    def _scan(
        config_path: Path,
        tool: str,
        all_servers: list[dict[str, Any]],
        errors: list[str],
    ) -> None:
        """Read one MCP config file and append its servers / any error.

        Missing files are silently skipped — most users do not have every
        client installed, so a missing path is the expected case rather
        than an error. Real failures (permission denied, corrupted JSON,
        unexpected exceptions) are recorded as ``MCP config <path>: <msg>``
        breadcrumbs in the collector's errors list so they show up in the
        report without aborting the collection.
        """
        try:
            if not config_path.exists():
                return
            servers = parse_mcp_config(config_path, tool)
            all_servers.extend(servers)
        except (OSError, json.JSONDecodeError) as e:
            errors.append(f"MCP config {config_path}: {e}")
        except Exception as e:
            errors.append(f"MCP config {config_path}: {e}")
