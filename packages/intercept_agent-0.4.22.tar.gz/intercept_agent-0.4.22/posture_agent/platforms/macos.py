"""macOS implementation of the platform strategies.

This module is a VERBATIM extraction of macOS-specific logic that previously
lived in collectors/services/main. Behavior on macOS is unchanged; the only
new code is the dataclass-shaping at the boundary between collectors and the
strategy classes.
"""

from __future__ import annotations

import os
import platform as _platform
import shutil
import subprocess
from pathlib import Path

from posture_agent.platforms.base import (
    AppSigningStatus,
    DiskEncryptionStatus,
    FirewallStatus,
    PlatformBundle,
    SchedulerStatus,
    SshAgentInfo,
    logical_cpu_count,
)
from posture_agent.utils.shell import check_version, run_command

# AI tool CLIs discoverable on PATH. Same shape as collectors/ai_tools.py
# AI_CLI_TOOLS but lives here so platform bundles can report a unified
# "AI tools installed" list. The collector still scans this list itself for
# legacy reasons (extension scanning happens at the same time), so duplicates
# are deduped at the collector layer.
AI_CLI_TOOLS_MACOS: list[tuple[str, str, str | None]] = [
    ("Claude Code", "claude", "--version"),
    ("GitHub Copilot CLI", "copilot", "--version"),
    ("Aider", "aider", "--version"),
    ("Kiro", "kiro", "--version"),
    ("OpenAI Codex CLI", "codex", "--version"),
    ("Gemini CLI", "gemini", "--version"),
    ("Amazon Q Developer CLI", "q", "--version"),
    ("Open Interpreter", "interpreter", "--version"),
    ("Warp AI", "warp", "--version"),
    ("Tabnine", "tabnine", None),
]

# ---------------------------------------------------------------------------
# Hardware
# ---------------------------------------------------------------------------


class MacOSHardware:
    """Hardware / OS metadata via `sysctl`, `ioreg`, and `platform`."""

    async def machine_uuid(self) -> str | None:
        """Return the raw IOPlatformUUID (or serial fallback) — NOT a hash.

        Verbatim port of the parsing in `services/fingerprint.py`. The caller
        is responsible for hashing the result into a stable fingerprint.
        """
        # Try IOPlatformUUID first (most reliable on macOS)
        result = await run_command("ioreg", "-rd1", "-c", "IOPlatformExpertDevice")
        if result:
            for line in result.split("\n"):
                if "IOPlatformUUID" in line:
                    parts = line.split('"')
                    for i, part in enumerate(parts):
                        if part == "IOPlatformUUID" and i + 2 < len(parts):
                            return parts[i + 2]

        # Fallback: serial number
        serial = await run_command("ioreg", "-l", "-c", "IOPlatformExpertDevice")
        if serial:
            for line in serial.split("\n"):
                if "IOPlatformSerialNumber" in line:
                    parts = line.split('"')
                    for i, part in enumerate(parts):
                        if part == "IOPlatformSerialNumber" and i + 2 < len(parts):
                            return parts[i + 2]

        return None

    async def cpu_brand(self) -> str:
        """Return CPU brand string from `sysctl machdep.cpu.brand_string`."""
        result = await run_command("sysctl", "-n", "machdep.cpu.brand_string")
        return result.strip() if result else ""

    async def cpu_cores(self) -> int:
        """Return logical CPU count.

        Delegates to :func:`logical_cpu_count` so the
        :func:`os.cpu_count`-then-:func:`multiprocessing.cpu_count` fallback
        is shared with the Windows provider. Returns ``0`` only when both
        APIs fail — the schema interprets that as "unknown", not
        "no cores".
        """
        return logical_cpu_count()

    async def total_memory_bytes(self) -> int:
        """Return total memory in bytes from `sysctl hw.memsize`."""
        result = await run_command("sysctl", "-n", "hw.memsize")
        if result:
            return int(result.strip())
        return 0

    def os_name(self) -> str:
        """Return the canonical OS name."""
        return "macOS"

    def os_version(self) -> str:
        """Return the macOS version string."""
        # Verbatim from `main.py:_get_os_version`
        if _platform.system() == "Darwin":
            mac_ver = _platform.mac_ver()[0]
            if mac_ver:
                return mac_ver
        return _platform.release()


# ---------------------------------------------------------------------------
# Security posture
# ---------------------------------------------------------------------------


class MacOSSecurityPosture:
    """FileVault, application firewall, and Gatekeeper probes."""

    async def disk_encryption(self) -> DiskEncryptionStatus:
        """Probe FileVault state via `fdesetup status`."""
        try:
            fv_status = await run_command("fdesetup", "status")
        except Exception as e:
            return DiskEncryptionStatus(
                enabled=None,
                state="unknown",
                product="FileVault",
                reason=f"FileVault: {e}",
            )

        if fv_status is None:
            return DiskEncryptionStatus(
                enabled=False,
                state="unknown",
                product="FileVault",
            )

        if "On" in fv_status:
            return DiskEncryptionStatus(
                enabled=True,
                state="on",
                product="FileVault",
            )
        return DiskEncryptionStatus(
            enabled=False,
            state="off",
            product="FileVault",
        )

    async def firewall(self) -> FirewallStatus:
        """Probe macOS application firewall via `socketfilterfw`."""
        try:
            fw_status = await run_command(
                "/usr/libexec/ApplicationFirewall/socketfilterfw",
                "--getglobalstate",
            )
        except Exception as e:
            return FirewallStatus(
                enabled=None,
                product="ApplicationFirewall",
                reason=f"Firewall: {e}",
            )

        enabled = fw_status is not None and "enabled" in fw_status.lower()
        return FirewallStatus(
            enabled=enabled,
            product="ApplicationFirewall",
        )

    async def app_signing(self) -> AppSigningStatus:
        """Probe Gatekeeper assessment status via `spctl --status`."""
        try:
            gk_status = await run_command("spctl", "--status")
        except Exception as e:
            return AppSigningStatus(
                enforced=None,
                state="unknown",
                product="Gatekeeper",
                reason=f"Gatekeeper: {e}",
            )

        if gk_status is None:
            return AppSigningStatus(
                enforced=False,
                state="unknown",
                product="Gatekeeper",
            )

        enabled = "enabled" in gk_status.lower()
        return AppSigningStatus(
            enforced=enabled,
            state="enforced" if enabled else "disabled",
            product="Gatekeeper",
        )


# ---------------------------------------------------------------------------
# SSH agent
# ---------------------------------------------------------------------------


class MacOSSshAgent:
    """Detect SSH agent type from SSH_AUTH_SOCK.

    Reads the env var directly via `os.environ.get` — no subprocess needed.
    Any unexpected error propagates to the caller (the security collector's
    try/except records it in `errors` and falls back to `"unknown"`).
    """

    async def detect(self) -> SshAgentInfo:
        ssh_auth_sock = os.environ.get("SSH_AUTH_SOCK")
        sock_path = ssh_auth_sock.strip() if ssh_auth_sock else ""
        if "1password" in sock_path.lower() or "1Password" in sock_path:
            agent_type = "1Password"
        elif "secretive" in sock_path.lower():
            agent_type = "Secretive"
        elif "com.apple.launchd" in sock_path:
            agent_type = "Apple Keychain"
        elif sock_path:
            agent_type = "standard"
        else:
            agent_type = "none"

        return SshAgentInfo(
            socket_path=sock_path or None,
            agent_type=agent_type,
            key_count=None,
        )


# ---------------------------------------------------------------------------
# IDE discovery
# ---------------------------------------------------------------------------


# AI desktop apps installed under /Applications. Tuple shape mirrors
# IDE_DEFINITIONS so version extraction reuses the same Info.plist read.
# (name, binary_or_None, app_bundle_path, version_flag_or_None)
#
# Cursor, Windsurf, Trae are also reported as IDEs — listing them here as
# well surfaces them in the "AI Tools" section of the developer detail page,
# which is what users expect when reasoning about *what AI tools are on the
# machine* rather than *what editor is installed*. The dual reporting is by
# design and matches how the user thinks about these apps.
AI_DESKTOP_APP_DEFINITIONS_MACOS: list[tuple[str, str | None, str, str | None]] = [
    ("Claude Desktop", None, "/Applications/Claude.app", None),
    ("ChatGPT Desktop", None, "/Applications/ChatGPT.app", None),
    ("Cursor", "cursor", "/Applications/Cursor.app", "--version"),
    ("Windsurf", "windsurf", "/Applications/Windsurf.app", "--version"),
    ("Trae", "trae", "/Applications/Trae.app", "--version"),
]


# IDE definitions: (name, binary, app_path, version_flag)
# Verbatim from collectors/ides.py
IDE_DEFINITIONS = [
    ("VS Code", "code", "/Applications/Visual Studio Code.app", "--version"),
    (
        "VS Code Insiders",
        "code-insiders",
        "/Applications/Visual Studio Code - Insiders.app",
        "--version",
    ),
    ("Cursor", "cursor", "/Applications/Cursor.app", "--version"),
    ("Windsurf", "windsurf", "/Applications/Windsurf.app", "--version"),
    ("Trae", "trae", "/Applications/Trae.app", "--version"),
    ("IntelliJ IDEA", "idea", "/Applications/IntelliJ IDEA.app", None),
    ("PyCharm", "pycharm", "/Applications/PyCharm.app", None),
    ("WebStorm", "webstorm", "/Applications/WebStorm.app", None),
    ("GoLand", "goland", "/Applications/GoLand.app", None),
    ("JetBrains Fleet", "fleet", "/Applications/Fleet.app", "--version"),
    ("Xcode", None, "/Applications/Xcode.app", None),
    ("Vim", "vim", None, "--version"),
    ("Neovim", "nvim", None, "--version"),
    ("Helix", "hx", None, "--version"),
    ("Emacs", "emacs", None, "--version"),
    ("Sublime Text", "subl", "/Applications/Sublime Text.app", "--version"),
    ("Zed", "zed", "/Applications/Zed.app", "--version"),
    ("Nova", None, "/Applications/Nova.app", None),
    ("Lapce", "lapce", "/Applications/Lapce.app", "--version"),
]


class MacOSIDEDiscovery:
    """Discover installed IDEs via `/Applications` bundles + `which`."""

    async def installed_ides(self) -> tuple[list[dict], list[str]]:
        """Verbatim port of `IDECollector.collect` — returns (ides, errors)."""
        ides: list[dict[str, str]] = []
        errors: list[str] = []
        for name, binary, app_path, version_flag in IDE_DEFINITIONS:
            try:
                installed = False
                version = ""

                # Check app bundle
                if app_path and Path(app_path).exists():
                    installed = True
                    # Try to get version from Info.plist
                    plist_path = Path(app_path) / "Contents" / "Info.plist"
                    if plist_path.exists():
                        result = await run_command(
                            "defaults", "read", str(plist_path), "CFBundleShortVersionString"
                        )
                        if result:
                            version = result.strip()

                # Check binary
                if binary:
                    which_result = await run_command("which", binary)
                    if which_result and which_result.strip():
                        installed = True
                        if version_flag and not version:
                            ver = await check_version(binary, version_flag)
                            if ver:
                                version = ver

                if installed:
                    ides.append(
                        {
                            "name": name,
                            "version": version,
                            "binary": binary or "",
                        }
                    )
            except Exception as e:
                errors.append(f"{name}: {e}")
        return ides, errors

    async def installed_ai_tools(self) -> tuple[list[dict], list[str]]:
        """Discover AI desktop apps + AI-tool CLIs on macOS.

        Two scan paths, mirroring how :meth:`installed_ides` works:

        1. ``/Applications/<App>.app`` bundle scan — detects Claude Desktop,
           ChatGPT Desktop, Cursor, Windsurf, Trae. Version comes from
           ``Contents/Info.plist`` via ``defaults read``; if that fails we
           fall through to ``--version`` on the CLI shim (Cursor/Windsurf/
           Trae expose one). Bundle-only apps (Claude Desktop, ChatGPT)
           still report when no version is available.
        2. ``shutil.which`` scan over :data:`AI_CLI_TOOLS_MACOS` — detects
           CLI tools like ``claude`` (Claude Code), ``aider``, ``copilot``.

        Returns ``(tools, errors)`` with each entry shaped as
        ``{"name", "type": "desktop"|"cli", "binary", "version"}``. Per-tool
        failures are tagged in ``errors`` rather than aborting the scan.
        """
        tools: list[dict[str, str]] = []
        errors: list[str] = []
        seen: set[str] = set()  # dedupe key: tool name

        # 1. Desktop apps under /Applications.
        for name, binary, app_path, version_flag in AI_DESKTOP_APP_DEFINITIONS_MACOS:
            try:
                if not Path(app_path).exists():
                    continue

                version = ""
                plist_path = Path(app_path) / "Contents" / "Info.plist"
                if plist_path.exists():
                    plist_result = await run_command(
                        "defaults", "read", str(plist_path), "CFBundleShortVersionString"
                    )
                    if plist_result:
                        version = plist_result.strip()

                # Fallback: if the app ships a CLI shim and Info.plist didn't
                # give us a version, try `<binary> --version`.
                if not version and binary and version_flag:
                    if shutil.which(binary):
                        ver = await check_version(binary, version_flag)
                        if ver:
                            version = ver

                if name in seen:
                    continue
                seen.add(name)
                tools.append(
                    {
                        "name": name,
                        "type": "desktop",
                        "binary": binary or "",
                        "version": version,
                    }
                )
            except Exception as e:
                errors.append(f"{name}: {e}")

        # 2. AI tool CLIs on PATH.
        for name, binary, version_flag in AI_CLI_TOOLS_MACOS:
            try:
                if not shutil.which(binary):
                    continue
                version = ""
                if version_flag:
                    ver = await check_version(binary, version_flag)
                    if ver:
                        version = ver
                if name in seen:
                    continue
                seen.add(name)
                tools.append(
                    {
                        "name": name,
                        "type": "cli",
                        "binary": binary,
                        "version": version,
                    }
                )
            except Exception as e:
                errors.append(f"{name}: {e}")

        return tools, errors

    def jetbrains_plugin_root(self) -> Path:
        """`~/Library/Application Support/JetBrains` on macOS."""
        return Path.home() / "Library" / "Application Support" / "JetBrains"

    def vscode_extension_root(self) -> Path:
        """`~/.vscode/extensions` (already cross-platform via `Path.home()`)."""
        return Path.home() / ".vscode" / "extensions"


# ---------------------------------------------------------------------------
# MCP host paths
# ---------------------------------------------------------------------------


class MacOSMCPHostPaths:
    """macOS filesystem locations for MCP host configs."""

    def claude_desktop_config(self) -> Path:
        return (
            Path.home()
            / "Library"
            / "Application Support"
            / "Claude"
            / "claude_desktop_config.json"
        )

    def cursor_mcp_config(self) -> Path:
        return (
            Path.home()
            / "Library"
            / "Application Support"
            / "Cursor"
            / "User"
            / "globalStorage"
            / "cursor.mcp"
            / "mcp.json"
        )

    def vscode_mcp_config(self) -> list[Path]:
        """Return VS Code Stable + Insiders MCP config paths on macOS.

        VS Code stores user-level MCP configuration under the per-app User
        directory in ``~/Library/Application Support`` — same convention as
        every other Electron app on macOS. Stable and Insiders are installed
        as separate apps with separate config trees, so we return both.
        """
        base = Path.home() / "Library" / "Application Support"
        return [
            base / "Code" / "User" / "mcp.json",
            base / "Code - Insiders" / "User" / "mcp.json",
        ]


# ---------------------------------------------------------------------------
# Shell PATH expansion
# ---------------------------------------------------------------------------


class MacOSShellPathExpander:
    """Expand PATH for headless schedulers (verbatim from utils/shell.py)."""

    def expanded_path(self) -> str:
        """Return PATH expanded with common tool locations.

        launchd runs with a minimal PATH (/usr/bin:/bin:/usr/sbin:/sbin).
        We add common locations where dev tools are installed.
        """
        current_path = os.environ.get("PATH", "")
        home = str(Path.home())

        extra_paths = [
            "/opt/homebrew/bin",
            "/opt/homebrew/sbin",
            "/usr/local/bin",
            "/usr/local/sbin",
            f"{home}/.local/bin",
            f"{home}/.cargo/bin",
            f"{home}/.go/bin",
            f"{home}/go/bin",
        ]

        # Add nvm node paths
        nvm_dir = Path(home) / ".nvm" / "versions" / "node"
        if nvm_dir.exists():
            for version_dir in sorted(nvm_dir.iterdir(), reverse=True):
                bin_dir = version_dir / "bin"
                if bin_dir.exists():
                    extra_paths.append(str(bin_dir))
                    break  # Only add the latest version

        # Add Python framework paths (macOS)
        python_framework = Path("/Library/Frameworks/Python.framework/Versions")
        if python_framework.exists():
            for version_dir in sorted(python_framework.iterdir(), reverse=True):
                bin_dir = version_dir / "bin"
                if bin_dir.exists() and version_dir.name != "Current":
                    extra_paths.append(str(bin_dir))
                    break

        # Add pip --user paths (macOS)
        lib_python = Path(home) / "Library" / "Python"
        if lib_python.exists():
            for version_dir in sorted(lib_python.iterdir(), reverse=True):
                bin_dir = version_dir / "bin"
                if bin_dir.exists():
                    extra_paths.append(str(bin_dir))
                    break

        # Deduplicate while preserving order
        seen: set[str] = set()
        parts = []
        for p in current_path.split(":") + extra_paths:
            if p and p not in seen:
                seen.add(p)
                parts.append(p)

        return ":".join(parts)

    def pip_user_bin_candidates(self) -> list[Path]:
        """macOS pip --user candidates (verbatim from main._pip_user_bin_candidates)."""
        candidates = []
        home = Path.home()

        # macOS: ~/Library/Python/3.X/bin/
        lib_python = home / "Library" / "Python"
        if lib_python.exists():
            for version_dir in sorted(lib_python.iterdir(), reverse=True):
                candidates.append(version_dir / "bin" / "intercept-agent")
        # Linux/fallback: ~/.local/bin/
        candidates.append(home / ".local" / "bin" / "intercept-agent")
        return candidates


# ---------------------------------------------------------------------------
# Scheduler (launchd)
# ---------------------------------------------------------------------------


PLIST_NAME = "com.hijacksecurity.intercept-agent"
PLIST_PATH = Path.home() / "Library" / "LaunchAgents" / f"{PLIST_NAME}.plist"
CONFIG_DIR = Path.home() / ".config" / "intercept"


class MacOSScheduler:
    """launchd-based scheduler.

    Note: `install` here is a thin reusable helper. The CLI `install` command
    in `main.py` continues to handle config-file creation and bin-path
    discovery; it calls down into this scheduler for the plist write +
    `launchctl load`. `uninstall` and `status` are fully handled here.
    """

    plist_name: str = PLIST_NAME
    plist_path: Path = PLIST_PATH

    def install(self, program_args: list[str], interval: str = "hourly") -> None:
        """Write the launchd plist and load it.

        ``program_args`` is the full argv to schedule -- typically
        ``[sys.executable, "-m", "posture_agent", "collect", "--report"]``.
        Using ``python -m posture_agent`` (instead of the bare
        ``intercept-agent`` console script) means the scheduled task always
        works, even when pip's user Scripts dir isn't on PATH (the failure
        mode on Windows that motivated this design -- we mirror it on macOS
        for consistency and to avoid relying on PATH from a headless agent).

        ``interval`` accepts ``"hourly"`` (treated as 3600s) or a numeric
        string for an explicit ``StartInterval``. The CLI ``install`` command
        resolves the interval from settings before calling here.
        """
        if not program_args:
            raise ValueError("program_args must be a non-empty list")

        try:
            interval_seconds = int(interval)
        except ValueError:
            interval_seconds = 3600  # "hourly" default

        logs_dir = CONFIG_DIR / "logs"
        CONFIG_DIR.mkdir(parents=True, exist_ok=True)
        logs_dir.mkdir(parents=True, exist_ok=True)

        stdout_log = str(logs_dir / "agent.stdout.log")
        stderr_log = str(logs_dir / "agent.stderr.log")

        user_path = MacOSShellPathExpander().expanded_path()

        # Build the <ProgramArguments> array verbatim from program_args so
        # each token lands as its own <string>. XML-escape every entry; a
        # rogue ``&`` or ``<`` in sys.executable would otherwise corrupt the
        # plist.
        from xml.sax.saxutils import escape as _xml_escape

        arg_xml = "\n        ".join(
            f"<string>{_xml_escape(str(a))}</string>" for a in program_args
        )

        plist_content = f"""<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key>
    <string>{self.plist_name}</string>
    <key>ProgramArguments</key>
    <array>
        {arg_xml}
    </array>
    <key>EnvironmentVariables</key>
    <dict>
        <key>PATH</key>
        <string>{user_path}</string>
    </dict>
    <key>StartInterval</key>
    <integer>{interval_seconds}</integer>
    <key>RunAtLoad</key>
    <true/>
    <key>KeepAlive</key>
    <false/>
    <key>StandardOutPath</key>
    <string>{stdout_log}</string>
    <key>StandardErrorPath</key>
    <string>{stderr_log}</string>
</dict>
</plist>
"""

        self.plist_path.parent.mkdir(parents=True, exist_ok=True)
        self.plist_path.write_text(plist_content)

        subprocess.run(["launchctl", "load", str(self.plist_path)], check=True)

    def uninstall(self) -> None:
        """Unload and remove the launchd plist."""
        if self.plist_path.exists():
            subprocess.run(["launchctl", "unload", str(self.plist_path)], check=False)
            self.plist_path.unlink()

    def status(self) -> SchedulerStatus:
        """Return current launchd status."""
        if not self.plist_path.exists():
            return SchedulerStatus(installed=False, running=None, last_run=None)

        result = subprocess.run(
            ["launchctl", "list", self.plist_name],
            capture_output=True,
            text=True,
        )
        if result.returncode == 0:
            return SchedulerStatus(
                installed=True,
                running=True,
                last_run=None,
                raw={"launchctl_list": result.stdout},
            )
        return SchedulerStatus(installed=True, running=False, last_run=None)


# ---------------------------------------------------------------------------
# Bundle factory
# ---------------------------------------------------------------------------


def bundle() -> PlatformBundle:
    """Build the macOS `PlatformBundle`."""
    return PlatformBundle(
        hardware=MacOSHardware(),
        security=MacOSSecurityPosture(),
        ssh_agent=MacOSSshAgent(),
        ides=MacOSIDEDiscovery(),
        mcp_paths=MacOSMCPHostPaths(),
        path_expander=MacOSShellPathExpander(),
        scheduler=MacOSScheduler(),
    )


__all__ = [
    "IDE_DEFINITIONS",
    "MacOSHardware",
    "MacOSIDEDiscovery",
    "MacOSMCPHostPaths",
    "MacOSScheduler",
    "MacOSSecurityPosture",
    "MacOSShellPathExpander",
    "MacOSSshAgent",
    "PLIST_NAME",
    "PLIST_PATH",
    "bundle",
]
