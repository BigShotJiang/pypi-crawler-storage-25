"""Platform strategy protocols and result dataclasses.

Each Protocol describes a slice of platform-specific behavior. The macOS
implementation lives in `macos.py`; future Windows / Linux implementations
will mirror the structure. Collectors / services consume a `PlatformBundle`
that aggregates the concrete strategies for the running platform.
"""

from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Protocol


def logical_cpu_count() -> int:
    """Return the logical CPU count, robust across platforms.

    ``os.cpu_count()`` returns ``None`` when the OS cannot determine the
    count — rare, but observed in containerized / sandboxed environments.
    Falls back to :func:`multiprocessing.cpu_count` (which raises rather
    than returning ``None``) before giving up with ``0``. The wire format
    treats ``0`` as "unknown" rather than "no cores".
    """
    n = os.cpu_count()
    if n:
        return n
    try:
        # multiprocessing.cpu_count raises NotImplementedError when nothing
        # is queryable; both /proc and sysconf can be unavailable.
        import multiprocessing

        m = multiprocessing.cpu_count()
        if m and m > 0:
            return m
    except (NotImplementedError, OSError):
        pass
    return 0


@dataclass(frozen=True)
class DiskEncryptionStatus:
    """Disk encryption posture (FileVault on macOS, BitLocker on Windows, etc.)."""

    enabled: bool | None
    state: str  # "on", "off", "partial", "unknown", "unsupported"
    product: str | None = None
    reason: str | None = None


@dataclass(frozen=True)
class AppSigningStatus:
    """OS-level application signing enforcement (Gatekeeper, SmartScreen, etc.)."""

    enforced: bool | None
    state: str  # "enforced", "permissive", "disabled", "unknown"
    product: str | None = None
    reason: str | None = None


@dataclass(frozen=True)
class FirewallStatus:
    """OS firewall posture."""

    enabled: bool | None
    product: str | None = None
    reason: str | None = None


@dataclass(frozen=True)
class SshAgentInfo:
    """Detected SSH agent context."""

    socket_path: str | None
    agent_type: str | None  # SshAgentType enum value or None
    key_count: int | None


@dataclass(frozen=True)
class SchedulerStatus:
    """Status of the periodic scheduler (launchd / Task Scheduler / cron)."""

    installed: bool
    running: bool | None
    last_run: str | None  # ISO timestamp or None
    raw: dict[str, Any] | None = None  # platform-specific extra info


class HardwareProvider(Protocol):
    """Hardware / OS metadata."""

    def machine_uuid(self) -> str | None: ...  # raw, fingerprint hashes outside

    def cpu_brand(self) -> str: ...

    def cpu_cores(self) -> int: ...

    def total_memory_bytes(self) -> int: ...

    def os_name(self) -> str: ...

    def os_version(self) -> str: ...


class SecurityPostureProvider(Protocol):
    """OS-level security posture probes."""

    async def disk_encryption(self) -> DiskEncryptionStatus: ...

    async def firewall(self) -> FirewallStatus: ...

    async def app_signing(self) -> AppSigningStatus: ...


class SshAgentProvider(Protocol):
    """SSH agent detection."""

    async def detect(self) -> SshAgentInfo: ...


class IDEDiscovery(Protocol):
    """IDE installation discovery."""

    async def installed_ides(
        self,
    ) -> tuple[list[dict], list[str]]: ...  # (ides, per-ide errors); refine in C9

    async def installed_ai_tools(
        self,
    ) -> tuple[list[dict], list[str]]:
        """Return AI desktop apps + AI-tool CLIs detected on disk.

        Returns ``(tools, errors)`` where each entry is a dict shaped like
        ``{"name": ..., "type": "desktop"|"cli", "binary": ..., "version": ...}``.
        Editor extensions (e.g., ``github.copilot``) are scanned separately by
        the AI tools collector and are NOT returned here.

        Implementations on platforms without a meaningful concept of
        "installed AI desktop app" may return ``([], [])`` — callers must
        treat the empty list as "nothing detected" rather than an error.
        """
        ...

    def jetbrains_plugin_root(self) -> Path: ...

    def vscode_extension_root(self) -> Path: ...


class MCPHostPaths(Protocol):
    """Filesystem locations of MCP host config files."""

    def claude_desktop_config(self) -> Path: ...

    def cursor_mcp_config(self) -> Path: ...

    def vscode_mcp_config(self) -> list[Path]:
        """Return all VS Code MCP config locations (Stable + Insiders).

        Returns a list because VS Code Stable and VS Code Insiders use
        separate config directories and a developer can have either or
        both installed. Callers iterate the list and skip non-existent
        paths.
        """
        ...


class ShellPathExpander(Protocol):
    """PATH expansion for subprocess execution under headless schedulers."""

    def expanded_path(self) -> str: ...

    def pip_user_bin_candidates(self) -> list[Path]: ...


class Scheduler(Protocol):
    """Periodic-collection scheduler (launchd / Task Scheduler / cron).

    ``program_args`` is the full argv the scheduled task should invoke — e.g.
    ``[sys.executable, "-m", "posture_agent", "collect", "--report"]``. Passing
    the argv (rather than a single executable path) lets the CLI route
    scheduled runs through ``python -m posture_agent``, which works regardless
    of whether the ``intercept-agent`` console script is on PATH. That matters
    on Windows where ``pip install --user`` lands the script in
    ``%APPDATA%\\Python\\Python3xx\\Scripts`` (not on the default PATH).
    """

    def install(self, program_args: list[str], interval: str = "hourly") -> None: ...

    def uninstall(self) -> None: ...

    def status(self) -> SchedulerStatus: ...


@dataclass(frozen=True)
class PlatformBundle:
    """Aggregate of platform-specific strategies for the current host."""

    hardware: HardwareProvider
    security: SecurityPostureProvider
    ssh_agent: SshAgentProvider
    ides: IDEDiscovery
    mcp_paths: MCPHostPaths
    path_expander: ShellPathExpander
    scheduler: Scheduler


class UnsupportedPlatformError(RuntimeError):
    """Raised when no platform implementation is available for the host."""
