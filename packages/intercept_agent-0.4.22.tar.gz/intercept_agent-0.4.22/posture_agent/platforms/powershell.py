"""Helper for invoking PowerShell 5.1 from the posture agent on Windows.

Uses ``powershell.exe`` (NOT ``pwsh`` — Windows ships 5.1 universally; pwsh 7+
is opt-in and we cannot assume it).

Never raises on cmdlet failure — returns a structured :class:`PSResult` that
callers branch on. This is intentional: Windows collectors must degrade
gracefully when a cmdlet is missing on older Windows builds, requires
elevation, or times out, rather than crashing the entire collection cycle.

Importable on all platforms; on non-Windows, :func:`run_ps` short-circuits
with ``PSResult(error=PSError(kind="unsupported", ...))`` instead of
invoking subprocess. This makes the helper unit-testable on macOS / Linux
CI runners by patching ``platform.system()``.
"""

from __future__ import annotations

import json
import platform
import re
import subprocess
import time
from dataclasses import dataclass
from typing import Any

from posture_agent.utils.win_subprocess import no_window_kwargs

# Stderr signatures emitted by powershell.exe that we want to classify.
CMDLET_NOT_FOUND = re.compile(r"is not recognized as the name of a cmdlet", re.I)
PERMISSION_DENIED = re.compile(
    r"(Access is denied|Requested registry access is not allowed|UnauthorizedAccessException)",
    re.I,
)


@dataclass(frozen=True)
class PSError:
    """Structured error description for a failed PowerShell invocation."""

    kind: str
    """One of: ``cmdlet_not_found``, ``permission_denied``, ``timeout``,
    ``parse_error``, ``exit_nonzero``, ``unsupported``."""

    message: str


@dataclass(frozen=True)
class PSResult:
    """Result of a PowerShell invocation. Always returned — never raised."""

    ok: bool
    data: Any
    error: PSError | None
    stderr: str
    duration_ms: int


def run_ps(
    script: str,
    *,
    timeout: float = 8.0,
    json_output: bool = True,
) -> PSResult:
    """Execute a PowerShell 5.1 snippet via ``powershell.exe``.

    Args:
        script: PowerShell expression to execute. When ``json_output`` is
            true (default), the helper appends ``| ConvertTo-Json -Compress
            -Depth 4`` so callers can rely on parsed objects.
        timeout: Hard wall-clock cap in seconds. PowerShell startup alone
            is ~300 ms on cold boot, so allow generous headroom for the
            cmdlet body.
        json_output: If true, parse stdout as JSON. If false, return raw
            stdout in ``PSResult.data``.

    Returns:
        :class:`PSResult` with ``ok=True`` and a parsed ``data`` payload on
        success, or ``ok=False`` with a populated :class:`PSError` on
        failure. Never raises.
    """

    if platform.system() != "Windows":
        # Short-circuit on non-Windows hosts so callers and unit tests can
        # exercise this helper without a real powershell.exe.
        return PSResult(
            ok=False,
            data=None,
            error=PSError(
                kind="unsupported",
                message=f"powershell unavailable on {platform.system()}",
            ),
            stderr="",
            duration_ms=0,
        )

    wrapped = f"{script} | ConvertTo-Json -Compress -Depth 4" if json_output else script
    args = [
        "powershell.exe",
        "-NoProfile",
        "-NonInteractive",
        "-ExecutionPolicy",
        "Bypass",
        "-Command",
        wrapped,
    ]

    start = time.perf_counter()
    try:
        proc = subprocess.run(
            args,
            capture_output=True,
            text=True,
            timeout=timeout,
            check=False,
            **no_window_kwargs(),
        )
    except subprocess.TimeoutExpired as e:
        return PSResult(
            ok=False,
            data=None,
            error=PSError(kind="timeout", message=str(e)),
            stderr="",
            duration_ms=int((time.perf_counter() - start) * 1000),
        )

    duration_ms = int((time.perf_counter() - start) * 1000)
    stderr = proc.stderr or ""

    # Classify failure modes based on stderr contents and exit code. Order
    # matters: a cmdlet-not-found error frequently coexists with exit != 0,
    # and we want the more specific classification.
    if proc.returncode != 0 or stderr:
        if CMDLET_NOT_FOUND.search(stderr):
            return PSResult(
                ok=False,
                data=None,
                error=PSError(kind="cmdlet_not_found", message=stderr.strip()),
                stderr=stderr,
                duration_ms=duration_ms,
            )
        if PERMISSION_DENIED.search(stderr):
            return PSResult(
                ok=False,
                data=None,
                error=PSError(kind="permission_denied", message=stderr.strip()),
                stderr=stderr,
                duration_ms=duration_ms,
            )
        if proc.returncode != 0:
            return PSResult(
                ok=False,
                data=None,
                error=PSError(
                    kind="exit_nonzero",
                    message=f"exit={proc.returncode}: {stderr.strip()}",
                ),
                stderr=stderr,
                duration_ms=duration_ms,
            )
        # Stderr present but exit code 0 — treat as a warning, not an error.

    if json_output:
        stdout = (proc.stdout or "").strip()
        if not stdout:
            # Empty output is a legitimate success state (e.g., a query
            # returning no rows). Callers branch on `data is None`.
            return PSResult(
                ok=True,
                data=None,
                error=None,
                stderr=stderr,
                duration_ms=duration_ms,
            )
        try:
            return PSResult(
                ok=True,
                data=json.loads(stdout),
                error=None,
                stderr=stderr,
                duration_ms=duration_ms,
            )
        except json.JSONDecodeError as e:
            return PSResult(
                ok=False,
                data=None,
                error=PSError(kind="parse_error", message=str(e)),
                stderr=stderr,
                duration_ms=duration_ms,
            )

    return PSResult(
        ok=True,
        data=proc.stdout or "",
        error=None,
        stderr=stderr,
        duration_ms=duration_ms,
    )


__all__ = ["PSError", "PSResult", "run_ps"]
