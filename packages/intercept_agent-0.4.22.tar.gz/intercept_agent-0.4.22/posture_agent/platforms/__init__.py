"""Platform strategy package.

`detect()` returns the `PlatformBundle` for the running OS. `get_bundle()`
is a lazy singleton that callers (collectors / services / CLI) use to avoid
re-detecting on every invocation.
"""

from __future__ import annotations

import platform

from posture_agent.platforms.base import (
    AppSigningStatus,
    DiskEncryptionStatus,
    FirewallStatus,
    HardwareProvider,
    IDEDiscovery,
    MCPHostPaths,
    PlatformBundle,
    Scheduler,
    SchedulerStatus,
    SecurityPostureProvider,
    ShellPathExpander,
    SshAgentInfo,
    SshAgentProvider,
    UnsupportedPlatformError,
)

_BUNDLE: PlatformBundle | None = None


def detect() -> PlatformBundle:
    """Return a freshly-built `PlatformBundle` for the current OS."""
    system = platform.system()
    if system == "Darwin":
        from posture_agent.platforms import macos

        return macos.bundle()
    if system == "Windows":
        from posture_agent.platforms import windows

        return windows.bundle()
    raise UnsupportedPlatformError(system)


def get_bundle() -> PlatformBundle:
    """Lazily detect and cache the platform bundle."""
    global _BUNDLE
    if _BUNDLE is None:
        _BUNDLE = detect()
    return _BUNDLE


def reset_bundle() -> None:
    """Clear the cached bundle (used by tests)."""
    global _BUNDLE
    _BUNDLE = None


__all__ = [
    "AppSigningStatus",
    "DiskEncryptionStatus",
    "FirewallStatus",
    "HardwareProvider",
    "IDEDiscovery",
    "MCPHostPaths",
    "PlatformBundle",
    "Scheduler",
    "SchedulerStatus",
    "SecurityPostureProvider",
    "ShellPathExpander",
    "SshAgentInfo",
    "SshAgentProvider",
    "UnsupportedPlatformError",
    "detect",
    "get_bundle",
    "reset_bundle",
]
