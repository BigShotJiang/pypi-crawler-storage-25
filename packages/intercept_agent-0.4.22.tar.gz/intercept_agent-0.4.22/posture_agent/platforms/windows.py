"""Windows platform strategies for the posture agent.

All slots are now real implementations: hardware (C6), security posture (C7),
SSH agent (C8), IDE discovery + MCP host paths (C9), shell PATH expansion (C10),
and Task Scheduler scheduler (C12).

Importing this module on Windows pulls in :mod:`winreg` and :mod:`ctypes`
(both stdlib, Windows-only at the API surface). Imports are guarded inside
individual methods rather than at module top so test code can import the
module on macOS / Linux without crashing — every method that needs a
Windows-only stdlib does ``platform.system()`` short-circuiting first.
"""

from __future__ import annotations

import json
import os
import platform
import re
import shutil
import subprocess
from pathlib import Path

from posture_agent.platforms.base import (
    AppSigningStatus,
    DiskEncryptionStatus,
    FirewallStatus,
    PlatformBundle,
    SchedulerStatus,
    SshAgentInfo,
    UnsupportedPlatformError,
    logical_cpu_count,
)
from posture_agent.platforms.powershell import run_ps
from posture_agent.utils.shell import check_version
from posture_agent.utils.win_subprocess import no_window_kwargs

# Canonical task name registered in Windows Task Scheduler. Mirrors the
# ``com.hijacksecurity.intercept-agent`` launchd label on macOS, but uses the
# human-readable form because that is what users see in the Task Scheduler GUI.
_TASK_NAME = "Intercept Agent"

# schtasks.exe operations should never block the agent for long. 10s matches
# the default timeout used elsewhere in this package.
_SCHTASKS_TIMEOUT = 10

# IDE shims discoverable on PATH. Same shape as macOS' IDE_DEFINITIONS but the
# binary is the Windows shim name (no `.exe` — `shutil.which` resolves PATHEXT
# automatically). Version is read by invoking the shim with the given flag.
_PATH_IDE_DEFINITIONS: list[tuple[str, str, str]] = [
    # (display_name, binary, version_flag)
    ("VS Code", "code", "--version"),
    ("VS Code Insiders", "code-insiders", "--version"),
    ("Cursor", "cursor", "--version"),
    ("Windsurf", "windsurf", "--version"),
    ("Trae", "trae", "--version"),
    ("JetBrains Fleet", "fleet", "--version"),
    ("Sublime Text", "subl", "--version"),
    ("Zed", "zed", "--version"),
    ("Lapce", "lapce", "--version"),
    ("Vim", "vim", "--version"),
    ("Neovim", "nvim", "--version"),
    ("Helix", "hx", "--version"),
    ("Emacs", "emacs", "--version"),
]


# AI desktop apps installed under %LOCALAPPDATA%. Tuple shape:
# (display_name, [exe_path_template, ...], cli_binary_or_None, version_flag_or_None)
#
# ``exe_path_templates`` are evaluated against the user's environment (LOCALAPPDATA,
# APPDATA, PROGRAMFILES, PROGRAMFILES(X86)) — the first existing path wins.
# ``cli_binary`` is a fallback ``shutil.which`` lookup for apps that ship a
# CLI shim (Cursor / Windsurf). ``version_flag`` drives the ``--version``
# fallback when the .exe metadata read fails.
#
# Path templates use ``$VAR`` placeholders that ``_expand_template`` resolves
# from ``os.environ`` with sensible fallbacks; trailing components are joined
# with the OS path separator.
_AI_DESKTOP_APP_DEFINITIONS_WINDOWS: list[tuple[str, list[str], str | None, str | None]] = [
    # Anthropic Claude Desktop. Newer installer drops the EXE under
    # %LOCALAPPDATA%\AnthropicClaude; older builds used Programs subdir.
    (
        "Claude Desktop",
        [
            r"$LOCALAPPDATA\AnthropicClaude\Claude.exe",
            r"$LOCALAPPDATA\Programs\AnthropicClaude\Claude.exe",
        ],
        None,
        None,
    ),
    # OpenAI ChatGPT Desktop — Squirrel-style installer puts the EXE under
    # %LOCALAPPDATA%\Programs\openai or %LOCALAPPDATA%\OpenAI.
    (
        "ChatGPT Desktop",
        [
            r"$LOCALAPPDATA\Programs\openai\ChatGPT.exe",
            r"$LOCALAPPDATA\OpenAI\ChatGPT.exe",
        ],
        None,
        None,
    ),
    # Cursor (the AI editor). Newer Squirrel installer uses Programs\cursor;
    # older user installs landed at %LOCALAPPDATA%\cursor.
    (
        "Cursor",
        [
            r"$LOCALAPPDATA\Programs\cursor\Cursor.exe",
            r"$LOCALAPPDATA\cursor\Cursor.exe",
        ],
        "cursor",
        "--version",
    ),
    # Windsurf (Codeium's AI editor).
    (
        "Windsurf",
        [
            r"$LOCALAPPDATA\Programs\Windsurf\Windsurf.exe",
        ],
        "windsurf",
        "--version",
    ),
    # Codeium (legacy desktop app + tray helper).
    (
        "Codeium",
        [
            r"$LOCALAPPDATA\Codeium\Codeium.exe",
            r"$LOCALAPPDATA\Programs\Codeium\Codeium.exe",
        ],
        None,
        None,
    ),
]


# AI tool CLIs discoverable on PATH on Windows. Shape mirrors the macOS list.
_AI_CLI_TOOLS_WINDOWS: list[tuple[str, str, str | None]] = [
    ("Claude Code", "claude", "--version"),
    ("GitHub Copilot CLI", "copilot", "--version"),
    ("Aider", "aider", "--version"),
    ("Kiro", "kiro", "--version"),
    ("OpenAI Codex CLI", "codex", "--version"),
    ("Gemini CLI", "gemini", "--version"),
    ("Amazon Q Developer CLI", "q", "--version"),
    ("Open Interpreter", "interpreter", "--version"),
    ("Warp AI", "warp", "--version"),
    ("Tabnine", "tabnine", None),
]

# JetBrains app directory name → display name. The directory name often
# carries the version suffix (e.g., "IntelliJ IDEA Community Edition 2024.3").
_JETBRAINS_APP_NAMES: dict[str, str] = {
    "IntelliJ IDEA Ultimate": "IntelliJ IDEA",
    "IntelliJ IDEA Community Edition": "IntelliJ IDEA",
    "IntelliJ IDEA": "IntelliJ IDEA",
    "PyCharm Professional": "PyCharm",
    "PyCharm Community Edition": "PyCharm",
    "PyCharm": "PyCharm",
    "WebStorm": "WebStorm",
    "GoLand": "GoLand",
    "RubyMine": "RubyMine",
    "PhpStorm": "PhpStorm",
    "CLion": "CLion",
    "Rider": "Rider",
    "DataGrip": "DataGrip",
    "DataSpell": "DataSpell",
    "RustRover": "RustRover",
    "Android Studio": "Android Studio",
}

# Trailing version segment in a JetBrains install dir name, e.g.
# "IntelliJ IDEA Community Edition 2024.3.1.1" → captures "2024.3.1.1".
_JETBRAINS_VERSION_RE = re.compile(r"\s+(\d{4}(?:\.\d+)+)\s*$")


# ---------------------------------------------------------------------------
# Hardware
# ---------------------------------------------------------------------------


class WindowsHardware:
    """Hardware / OS metadata via the registry, ``ctypes``, and ``platform``.

    Pure stdlib — no ``pywin32`` / ``wmi`` / ``pythonnet``. Every method has a
    graceful-degrade path so a missing registry value, a 32-bit Python on a
    64-bit OS, or an OS that simply isn't Windows never crashes the agent.
    """

    async def machine_uuid(self) -> str | None:
        """Return the machine GUID from the canonical 64-bit registry view.

        Reads ``HKLM\\SOFTWARE\\Microsoft\\Cryptography\\MachineGuid`` with
        ``KEY_WOW64_64KEY`` so a 32-bit Python interpreter still sees the
        64-bit hive on a 64-bit OS. Returns ``None`` on any failure (key
        missing, permission denied, non-Windows host).
        """
        if platform.system() != "Windows":
            return None
        import winreg  # Windows-only stdlib; lazy import

        try:
            with winreg.OpenKey(
                winreg.HKEY_LOCAL_MACHINE,
                r"SOFTWARE\Microsoft\Cryptography",
                0,
                winreg.KEY_READ | winreg.KEY_WOW64_64KEY,
            ) as key:
                value, _ = winreg.QueryValueEx(key, "MachineGuid")
                return str(value) if value else None
        except (OSError, FileNotFoundError):
            return None

    async def cpu_brand(self) -> str:
        """Return the CPU brand string.

        Prefers the friendly brand name from WMI's ``Win32_Processor.Name``
        (e.g., ``"AMD Ryzen 9 5950X 16-Core Processor"`` or
        ``"Intel(R) Core(TM) i9-13900K"``). Falls back to
        :func:`platform.processor` (e.g., ``"AMD64 Family 23 Model 113
        Stepping 0, AuthenticAMD"``) if PowerShell is unavailable or the
        cmdlet fails — at least *something* is reported.

        On virtualized Windows ARM64 hosts (e.g., Windows 11 ARM running in
        Parallels/UTM on Apple Silicon), ``Win32_Processor.Name`` itself can
        return the raw ``platform.processor()``-style string rather than a
        marketing brand. We post-process the PS output through
        :func:`_clean_processor_string` whenever it matches that raw shape,
        producing a friendlier value for the dashboard.
        """
        result = run_ps(
            "Get-CimInstance Win32_Processor | Select-Object -First 1 -ExpandProperty Name",
            json_output=False,
        )
        if result.ok and isinstance(result.data, str) and result.data.strip():
            return _clean_processor_string(result.data.strip())
        return _clean_processor_string(platform.processor())

    async def cpu_cores(self) -> int:
        """Return logical CPU count.

        Delegates to the shared :func:`logical_cpu_count` helper so Windows
        gets the same :func:`os.cpu_count` -> :func:`multiprocessing.cpu_count`
        fallback as macOS. Without this method the collector hits an
        ``AttributeError`` on Windows hosts and silently reports ``cpu_cores=0``,
        which is what the user saw on the test deploy of #623.
        """
        return logical_cpu_count()

    async def total_memory_bytes(self) -> int:
        """Return total physical memory in bytes via ``GlobalMemoryStatusEx``.

        Returns ``0`` on non-Windows hosts or on Win32 API failure.
        """
        return _global_memory_status_ex_total_phys()

    def os_name(self) -> str:
        return "Windows"

    def os_version(self) -> str:
        """Return a user-friendly Windows version string.

        Returns just the marketing release + build, e.g. ``"11 (Build 26200)"``
        — the leading ``"Windows "`` prefix is intentionally omitted so that
        the web UI's ``os_name + " " + os_version`` concatenation does not
        produce ``"Windows Windows 11 (Build 26200)"``. This mirrors the macOS
        strategy which returns bare version strings like ``"14.2.1"``.

        Why we can't trust :func:`platform.win32_ver` slot 0: the kernel
        major version on Windows 11 is still ``10.x``, so :func:`platform.release`
        / ``win32_ver()[0]`` reports ``"10"`` even on Windows 11 hosts. The
        canonical signal is the build number — builds ``>= 22000`` are
        Windows 11; below that is Windows 10.
        """
        release, version, _csd, _ptype = platform.win32_ver()

        # ``version`` is the dotted form like "10.0.26200" — pull out the
        # build number (third component) to drive the marketing-name decision.
        build: int | None = None
        if version:
            parts = version.split(".")
            if len(parts) >= 3 and parts[2].isdigit():
                build = int(parts[2])

        if build is not None:
            if build >= 22000:
                return f"11 (Build {build})"
            return f"10 (Build {build})"

        # No build number available — degrade to whatever ``win32_ver`` did
        # provide so the field is at least non-empty. Strip a leading
        # "Windows " token if win32_ver gave us one in ``release`` so the
        # downstream UI never double-prefixes.
        fallback = release or version or "unknown"
        if fallback.lower().startswith("windows "):
            fallback = fallback[len("windows ") :]
        return fallback


# Matches the raw ``platform.processor()``-style brand string Windows hands
# back when WMI / Win32_Processor has no marketing name to report. Examples:
#
#   "AMD64 Family 25 Model 1 Stepping 1, AuthenticAMD"
#   "Intel64 Family 6 Model 158 Stepping 13, GenuineIntel"
#   "ARMv8 (64-bit) Family 8 Model 0 Revision 0, Apple"
#
# The defining shape is ``Family <n> Model <n> (Stepping|Revision) <n>, <vendor>``.
# Anything that doesn't include both ``Family`` and ``Model`` plus a
# ``Stepping`` or ``Revision`` token is treated as a real brand and passed
# through untouched (so ``"AMD Ryzen 9 5950X 16-Core Processor"`` survives).
_RAW_PROCESSOR_RE = re.compile(
    # Vendor can itself contain commas (e.g., "Qualcomm Technologies, Inc.")
    # so we capture greedily through end-of-string after the first comma
    # following the Stepping/Revision token.
    r"^(?P<arch>.+?)\s+Family\s+\d+\s+Model\s+\d+\s+(?:Stepping|Revision)\s+\d+\s*,\s*(?P<vendor>.+?)\s*$",
    re.IGNORECASE,
)

# Vendor token (right-hand side of the comma) → friendly label. Keys are
# lowercased for case-insensitive lookup.
_VENDOR_FRIENDLY_NAMES: dict[str, str] = {
    "authenticamd": "AMD",
    "genuineintel": "Intel",
    "apple": "Apple",
    "qualcomm": "Qualcomm",
    "qualcomm technologies, inc.": "Qualcomm",
    "microsoft corporation": "Microsoft",
    "arm limited": "ARM",
}


def _clean_processor_string(raw: str | None) -> str:
    """Convert a raw ``platform.processor()``-style string to a friendlier form.

    Handles the unhelpful brand strings that WMI / ``platform.processor()``
    return when no marketing name is available — common on virtualized
    Windows ARM64 (Parallels/UTM on Apple Silicon, where the host reports
    ``"ARMv8 (64-bit) Family 8 Model 0 Revision 0, Apple"``).

    Transformations:

    * ARMv8 + ``Apple`` vendor → ``"Apple Silicon (ARM64)"``
    * ARMv8 + ``Qualcomm`` vendor → ``"Qualcomm Snapdragon (ARM64)"``
    * ARMv8 + any other vendor → ``"<friendly vendor> (ARM64)"``
    * ``AMD64`` arch + ``AuthenticAMD`` → ``"AMD64 (AMD)"``
    * ``Intel64`` arch + ``GenuineIntel`` → ``"Intel64 (Intel)"``
    * Any other ``<arch> Family ... <vendor>`` shape → ``"<arch> (<vendor>)"``

    Strings that don't match the raw shape (real marketing brands like
    ``"AMD Ryzen 9 5950X 16-Core Processor"``) are returned untouched.
    Empty / ``None`` input collapses to ``"unknown"``.
    """
    if not raw:
        return "unknown"
    raw = raw.strip()
    if not raw:
        return "unknown"

    match = _RAW_PROCESSOR_RE.match(raw)
    if not match:
        # Real brand from WMI — don't molest it.
        return raw

    arch = match.group("arch").strip()
    vendor_raw = match.group("vendor").strip()
    vendor_friendly = _VENDOR_FRIENDLY_NAMES.get(vendor_raw.lower(), vendor_raw)

    # ARM64 special-cases — the architecture token is noisy ("ARMv8 (64-bit)")
    # and the vendor carries the real signal.
    if "armv8" in arch.lower() or "arm64" in arch.lower() or "aarch64" in arch.lower():
        if vendor_friendly == "Apple":
            return "Apple Silicon (ARM64)"
        if vendor_friendly == "Qualcomm":
            return "Qualcomm Snapdragon (ARM64)"
        return f"{vendor_friendly} (ARM64)"

    return f"{arch} ({vendor_friendly})"


def _global_memory_status_ex_total_phys() -> int:
    """Call ``kernel32!GlobalMemoryStatusEx`` and return ``ullTotalPhys``.

    Extracted to a module-level helper so unit tests on macOS can patch the
    whole ctypes call site cleanly without the inner ``MEMORYSTATUSEX`` class
    leaking into the public API. Returns ``0`` on any failure.
    """
    if platform.system() != "Windows":
        return 0
    import ctypes
    from ctypes import wintypes

    class MEMORYSTATUSEX(ctypes.Structure):
        _fields_ = [
            ("dwLength", wintypes.DWORD),
            ("dwMemoryLoad", wintypes.DWORD),
            ("ullTotalPhys", ctypes.c_ulonglong),
            ("ullAvailPhys", ctypes.c_ulonglong),
            ("ullTotalPageFile", ctypes.c_ulonglong),
            ("ullAvailPageFile", ctypes.c_ulonglong),
            ("ullTotalVirtual", ctypes.c_ulonglong),
            ("ullAvailVirtual", ctypes.c_ulonglong),
            ("sullAvailExtendedVirtual", ctypes.c_ulonglong),
        ]

    stat = MEMORYSTATUSEX()
    stat.dwLength = ctypes.sizeof(MEMORYSTATUSEX)
    if not ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(stat)):
        return 0
    return int(stat.ullTotalPhys)


# ---------------------------------------------------------------------------
# Security posture
# ---------------------------------------------------------------------------


class WindowsSecurityPosture:
    """BitLocker, Windows Defender Firewall, and SmartScreen probes.

    Each probe degrades gracefully: missing cmdlet, permission denied, empty
    response, or non-Windows host all yield a ``*Status`` with a populated
    ``reason`` rather than raising. Cmdlet output is consumed via the shared
    :func:`run_ps` helper so error classification (``cmdlet_not_found`` vs
    ``permission_denied`` vs generic ``exit_nonzero``) is uniform across
    Windows providers.
    """

    async def disk_encryption(self) -> DiskEncryptionStatus:
        """Probe BitLocker on the system drive.

        ``Get-BitLockerVolume`` is unavailable on Windows Home SKUs and on
        older builds, which we map to ``state="unsupported"``. ``ProtectionStatus``
        is the canonical signal: 0=Off, 1=On, 2=Unknown.
        """
        result = run_ps(
            "Get-BitLockerVolume | "
            "Where-Object MountPoint -eq $env:SystemDrive | "
            "Select-Object MountPoint, ProtectionStatus, VolumeStatus"
        )
        if not result.ok:
            assert result.error is not None  # narrowed by ok=False
            if result.error.kind == "permission_denied":
                return DiskEncryptionStatus(
                    enabled=None,
                    state="unknown",
                    product="BitLocker",
                    reason="insufficient_privilege",
                )
            if result.error.kind == "cmdlet_not_found":
                return DiskEncryptionStatus(
                    enabled=None,
                    state="unsupported",
                    product="BitLocker",
                    reason="bitlocker_unavailable",
                )
            return DiskEncryptionStatus(
                enabled=None,
                state="unknown",
                product="BitLocker",
                reason="query_failed",
            )
        if result.data is None:
            # Empty pipeline — system drive has no BitLocker volume entry.
            return DiskEncryptionStatus(enabled=False, state="off", product="BitLocker")
        protection = result.data.get("ProtectionStatus") if isinstance(result.data, dict) else None
        if protection == 1:
            return DiskEncryptionStatus(enabled=True, state="on", product="BitLocker")
        if protection == 0:
            return DiskEncryptionStatus(enabled=False, state="off", product="BitLocker")
        return DiskEncryptionStatus(enabled=None, state="unknown", product="BitLocker")

    async def firewall(self) -> FirewallStatus:
        """Probe Windows Defender Firewall across all three profiles.

        ``enabled`` is true only when Domain, Private, AND Public profiles
        are all enabled. A single disabled profile is reported as
        ``enabled=False`` because traffic on that network type is unfiltered.
        """
        result = run_ps("Get-NetFirewallProfile | Select-Object Name, Enabled")
        if not result.ok:
            assert result.error is not None
            if result.error.kind == "permission_denied":
                return FirewallStatus(
                    enabled=None,
                    product="Windows Defender Firewall",
                    reason="insufficient_privilege",
                )
            return FirewallStatus(
                enabled=None,
                product="Windows Defender Firewall",
                reason="query_failed",
            )
        if result.data is None:
            return FirewallStatus(
                enabled=None,
                product="Windows Defender Firewall",
                reason="empty_response",
            )
        # Get-NetFirewallProfile returns a list when multiple profiles match,
        # but ConvertTo-Json collapses single objects — normalize to list.
        profiles = result.data if isinstance(result.data, list) else [result.data]
        all_enabled = all(isinstance(p, dict) and p.get("Enabled") in (True, 1) for p in profiles)
        return FirewallStatus(enabled=all_enabled, product="Windows Defender Firewall")

    async def app_signing(self) -> AppSigningStatus:
        """Report SmartScreen state for the OS.

        Reads SmartScreen policy from the Explorer key. SmartScreen is
        enabled by default; an explicit ``"Off"`` value disables it. Policy
        values like ``"Warn"`` or ``"Block"`` both leave it enforced.
        """
        smartscreen_enabled = self._read_smartscreen_state()
        if smartscreen_enabled is None:
            return AppSigningStatus(
                enforced=None,
                state="unknown",
                product="SmartScreen",
                reason="registry_unavailable",
            )
        if smartscreen_enabled:
            return AppSigningStatus(enforced=True, state="enforced", product="SmartScreen")
        return AppSigningStatus(enforced=False, state="disabled", product="SmartScreen")

    def _read_smartscreen_state(self) -> bool | None:
        """Return SmartScreen on/off state, or ``None`` if the registry is unreachable.

        Read order: ``HKLM\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Explorer
        \\SmartScreenEnabled``. Missing value defaults to ``True`` (SmartScreen
        ships enabled out of the box). Any registry failure returns ``None``
        so the caller can surface ``reason="registry_unavailable"``.
        """
        if platform.system() != "Windows":
            return None
        import winreg  # Windows-only stdlib; lazy import

        try:
            with winreg.OpenKey(
                winreg.HKEY_LOCAL_MACHINE,
                r"SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer",
                0,
                winreg.KEY_READ | winreg.KEY_WOW64_64KEY,
            ) as key:
                try:
                    value, _ = winreg.QueryValueEx(key, "SmartScreenEnabled")
                    # "Off" disables; "Warn", "Block", or anything else enables.
                    return str(value).lower() != "off"
                except FileNotFoundError:
                    # Value missing — SmartScreen defaults to enabled.
                    return True
        except OSError:
            return None


# ---------------------------------------------------------------------------
# SSH agent
# ---------------------------------------------------------------------------


class WindowsSshAgent:
    """Detect SSH agent type on Windows.

    Priority order:

    1. **Windows OpenSSH agent** — ``ssh-agent`` service running. Surfaces as
       the named pipe ``\\\\.\\pipe\\openssh-ssh-agent``. We do NOT enumerate
       keys via the pipe (that needs ``pywin32`` for ``CreateFile`` /
       ``WriteFile`` against named pipes — out of scope here).
    2. **PuTTY Pageant** — process ``pageant.exe`` running. Pageant uses a
       Win32 message-passing channel rather than a socket, so ``socket_path``
       is ``None``.
    3. **None** — neither agent detected.

    The ``agent_type`` strings (``"windows_openssh"``, ``"pageant"``) match
    :class:`services.shared.schemas.enums.SshAgentType` values. The posture
    agent ships as a standalone wheel and cannot import ``services.shared``
    at runtime, so the canonical values are duplicated here as string
    literals. Keep in sync with the enum.
    """

    async def detect(self) -> SshAgentInfo:
        # Priority 1: Windows OpenSSH service
        result = run_ps(
            "Get-Service ssh-agent -ErrorAction SilentlyContinue | Select-Object Status",
        )
        if result.ok and result.data:
            status = result.data.get("Status") if isinstance(result.data, dict) else None
            # ServiceControllerStatus enum: 4 = Running. PowerShell sometimes
            # serializes the enum name (`"Running"`) and sometimes the int.
            if status == 4 or (isinstance(status, str) and status.lower() == "running"):
                return SshAgentInfo(
                    socket_path=r"\\.\pipe\openssh-ssh-agent",
                    agent_type="windows_openssh",
                    key_count=None,
                )

        # Priority 2: Pageant
        result = run_ps(
            "Get-Process pageant -ErrorAction SilentlyContinue | Select-Object -First 1 Id",
        )
        if result.ok and result.data:
            return SshAgentInfo(
                socket_path=None,
                agent_type="pageant",
                key_count=None,
            )

        return SshAgentInfo(socket_path=None, agent_type=None, key_count=None)


# ---------------------------------------------------------------------------
# IDE discovery
# ---------------------------------------------------------------------------


class WindowsIDEDiscovery:
    """Discover installed IDEs on Windows.

    Strategy:

    * **Shim-discoverable IDEs** (VS Code, VS Code Insiders, Cursor, Windsurf,
      Trae, JetBrains Fleet, Sublime Text, Zed, Lapce, Vim, Neovim, Emacs,
      Helix) — :func:`shutil.which` resolves the shim under PATHEXT, then
      ``<binary> <flag>`` produces a version string parsed by
      :func:`check_version`.
    * **JetBrains IDEs** — scanned from JetBrains Toolbox app dirs
      (``%LOCALAPPDATA%\\JetBrains\\Toolbox\\apps``) and from the standalone
      installers (``%PROGRAMFILES%\\JetBrains`` and the x86 mirror). Version
      is parsed from the trailing ``YYYY.M[.M]`` segment of the install
      directory name when the dir name follows the canonical
      ``"<App> <version>"`` form.

    Returns ``(ides, errors)`` matching the macOS shape — per-IDE failures are
    tagged in ``errors`` rather than aborting the whole scan.
    """

    async def installed_ides(self) -> tuple[list[dict], list[str]]:
        ides: list[dict[str, str]] = []
        errors: list[str] = []
        seen: set[tuple[str, str]] = set()

        # 1. PATH-resident shims.
        for name, binary, version_flag in _PATH_IDE_DEFINITIONS:
            try:
                resolved = shutil.which(binary)
                if not resolved:
                    continue
                version = ""
                # VS Code-family editors (VS Code, Insiders, Cursor, Windsurf,
                # Trae) ship ``code.cmd``-style shims that invoke an Electron
                # GUI binary. Capturing ``--version`` stdout from a GUI process
                # via ``cmd.exe /c <shim>.cmd`` is unreliable on Windows — the
                # GUI exe can detach before flushing, leaving us with empty
                # output and a blank version field in the dashboard. Read the
                # version directly from the install's bundled
                # ``resources/app/package.json`` first; fall back to the shim
                # invocation only if the filesystem read yields nothing.
                if binary in _VSCODE_FORK_SHIM_BINARIES:
                    pkg_ver = _read_vscode_fork_version_from_shim(resolved)
                    if pkg_ver:
                        version = pkg_ver
                if not version and version_flag:
                    ver = await check_version(binary, version_flag)
                    if ver:
                        version = ver
                key = (name, version)
                if key in seen:
                    continue
                seen.add(key)
                ides.append({"name": name, "version": version, "binary": binary})
            except Exception as e:
                errors.append(f"{name}: {e}")

        # 2. JetBrains IDEs from filesystem scan.
        try:
            jetbrains_ides = self._discover_jetbrains()
        except Exception as e:
            errors.append(f"JetBrains: {e}")
            jetbrains_ides = []
        for entry in jetbrains_ides:
            key = (entry["name"], entry["version"])
            if key in seen:
                continue
            seen.add(key)
            ides.append(entry)

        return ides, errors

    async def installed_ai_tools(self) -> tuple[list[dict], list[str]]:
        """Discover AI desktop apps + AI-tool CLIs on Windows.

        Two scan paths:

        1. Filesystem scan over :data:`_AI_DESKTOP_APP_DEFINITIONS_WINDOWS`
           — checks each candidate ``.exe`` path under ``%LOCALAPPDATA%``
           and ``%APPDATA%``. The first existing path wins. Version comes
           from the EXE's embedded metadata via
           :func:`_get_exe_version` (PowerShell ``Get-Item .VersionInfo``);
           if that fails AND the app ships a CLI shim, fall back to
           ``<binary> --version``. Apps with no version source still report.
        2. ``shutil.which`` scan over :data:`_AI_CLI_TOOLS_WINDOWS` — detects
           CLI tools like ``claude`` (Claude Code), ``aider``, ``copilot``.

        Returns ``(tools, errors)`` with each entry shaped as
        ``{"name", "type": "desktop"|"cli", "binary", "version"}``. Per-tool
        failures land in ``errors``; the scan never raises.
        """
        tools: list[dict[str, str]] = []
        errors: list[str] = []
        seen: set[str] = set()  # dedupe key: tool name

        # 1. Desktop apps.
        for (
            name,
            path_templates,
            cli_binary,
            version_flag,
        ) in _AI_DESKTOP_APP_DEFINITIONS_WINDOWS:
            try:
                exe_path: str | None = None
                for template in path_templates:
                    candidate = _expand_template(template)
                    if candidate.exists():
                        exe_path = str(candidate)
                        break

                # If the EXE wasn't found but a CLI shim is on PATH, treat
                # that as a positive detection too — handy for portable
                # installs where the user dropped the EXE somewhere else.
                cli_resolved: str | None = None
                if cli_binary:
                    cli_resolved = shutil.which(cli_binary)

                if not exe_path and not cli_resolved:
                    continue

                version = ""
                if exe_path:
                    ver = _get_exe_version(exe_path)
                    if ver:
                        version = ver

                # Fallback: try the CLI shim's --version if metadata read
                # didn't yield anything and the app has a CLI.
                if not version and cli_binary and version_flag and cli_resolved:
                    cli_ver = await check_version(cli_binary, version_flag)
                    if cli_ver:
                        version = cli_ver

                if name in seen:
                    continue
                seen.add(name)
                tools.append(
                    {
                        "name": name,
                        "type": "desktop",
                        "binary": cli_binary or "",
                        "version": version,
                    }
                )
            except Exception as e:
                errors.append(f"{name}: {e}")

        # 2. AI tool CLIs on PATH.
        for name, binary, version_flag in _AI_CLI_TOOLS_WINDOWS:
            try:
                if not shutil.which(binary):
                    continue
                version = ""
                if version_flag:
                    ver = await check_version(binary, version_flag)
                    if ver:
                        version = ver
                if name in seen:
                    continue
                seen.add(name)
                tools.append(
                    {
                        "name": name,
                        "type": "cli",
                        "binary": binary,
                        "version": version,
                    }
                )
            except Exception as e:
                errors.append(f"{name}: {e}")

        return tools, errors

    def _discover_jetbrains(self) -> list[dict[str, str]]:
        """Scan known JetBrains install roots and return IDE entries."""
        home = Path.home()
        localappdata = Path(os.environ.get("LOCALAPPDATA", str(home / "AppData" / "Local")))
        programfiles = Path(os.environ.get("PROGRAMFILES", r"C:\Program Files"))
        programfiles_x86 = Path(os.environ.get("PROGRAMFILES(X86)", r"C:\Program Files (x86)"))

        results: list[dict[str, str]] = []

        # Toolbox layout: %LOCALAPPDATA%\JetBrains\Toolbox\apps\<App>\ch-<n>\<version>\bin
        toolbox_root = localappdata / "JetBrains" / "Toolbox" / "apps"
        if toolbox_root.exists():
            for app_dir in _iter_dir(toolbox_root):
                display = _JETBRAINS_APP_NAMES.get(app_dir.name)
                if not display:
                    continue
                version = _toolbox_latest_version(app_dir)
                results.append({"name": display, "version": version, "binary": ""})

        # Standalone installer layout: %PROGRAMFILES%\JetBrains\<App version>\bin
        for root in (programfiles / "JetBrains", programfiles_x86 / "JetBrains"):
            if not root.exists():
                continue
            for entry in _iter_dir(root):
                display, version = _parse_jetbrains_install_dir(entry.name)
                if not display:
                    continue
                results.append({"name": display, "version": version, "binary": ""})

        return results

    def jetbrains_plugin_root(self) -> Path:
        """``%APPDATA%\\JetBrains`` — same logical role as the macOS path."""
        home = Path.home()
        appdata = Path(os.environ.get("APPDATA", str(home / "AppData" / "Roaming")))
        return appdata / "JetBrains"

    def vscode_extension_root(self) -> Path:
        """``%USERPROFILE%\\.vscode\\extensions`` — cross-platform via ``Path.home()``."""
        return Path.home() / ".vscode" / "extensions"


def _iter_dir(path: Path):
    """Iterate child directories of ``path``; tolerate iteration failures."""
    try:
        for entry in path.iterdir():
            if entry.is_dir():
                yield entry
    except (OSError, PermissionError):
        return


# Environment variables we resolve when expanding AI-app path templates.
# Mirrors the fallbacks used elsewhere in this module so stripped/headless
# environments (Task Scheduler with no user profile) still produce sensible
# default paths instead of raising KeyError.
def _expand_template(template: str) -> Path:
    """Resolve ``$VAR``-style placeholders in a Windows path template.

    Recognised tokens: ``$LOCALAPPDATA``, ``$APPDATA``, ``$PROGRAMFILES``,
    ``$PROGRAMFILES(X86)``, ``$USERPROFILE``. Unknown tokens are left
    untouched. Falls back to user-profile-relative defaults for missing env
    vars so the call never raises.

    Backslashes in the template are normalised to forward slashes before
    constructing the :class:`Path`. On Windows ``Path`` accepts both
    separators interchangeably; on POSIX hosts (where the unit test suite
    runs) ``\\`` is a literal character, so without normalisation a template
    like ``r"$LOCALAPPDATA\\Foo\\Bar.exe"`` becomes a single segment with
    embedded backslashes — meaning :meth:`Path.exists` checks against a
    nonsense filename and the AI-tool scan silently reports nothing. This
    bug was caught by the test suite on macOS CI.
    """
    home = Path.home()
    defaults = {
        "LOCALAPPDATA": str(home / "AppData" / "Local"),
        "APPDATA": str(home / "AppData" / "Roaming"),
        "PROGRAMFILES": r"C:\Program Files",
        "PROGRAMFILES(X86)": r"C:\Program Files (x86)",
        "USERPROFILE": str(home),
    }
    expanded = template
    for var, default in defaults.items():
        token = f"${var}"
        if token in expanded:
            expanded = expanded.replace(token, os.environ.get(var, default))
    return Path(expanded.replace("\\", "/"))


# Shim binaries whose install layout follows the VS Code / Electron template
# (``<install>\bin\<shim>.cmd`` + ``<install>\resources\app\package.json``).
# Cursor / Windsurf / Trae are direct VS Code forks and inherit this layout.
# Reading the bundled ``package.json`` is preferred over invoking the shim's
# ``--version`` flag because the shim launches a GUI Electron process that
# can drop stdout when invoked through ``cmd.exe /c``, leaving us with a
# blank version in the dashboard.
_VSCODE_FORK_SHIM_BINARIES: frozenset[str] = frozenset(
    {"code", "code-insiders", "cursor", "windsurf", "trae"}
)


def _read_vscode_fork_version_from_shim(shim_path: str) -> str | None:
    """Read the ``version`` field from a VS Code-family install's ``package.json``.

    The Windows install layout for VS Code (and forks Cursor / Windsurf /
    Trae) is::

        <install>\\bin\\<shim>.cmd          # PATH-discoverable wrapper
        <install>\\resources\\app\\package.json   # canonical version source
        <install>\\Code.exe                  # GUI binary

    Given the resolved shim path (the value :func:`shutil.which` returned),
    we walk two directories up to ``<install>`` and read the bundled
    ``package.json``. Fully sync, no subprocess, deterministic.

    Returns ``None`` on any failure (missing file, JSON parse error,
    permission denied, missing ``version`` field) so the caller falls back
    to the existing shim ``--version`` invocation.
    """
    if not shim_path:
        return None
    try:
        install_root = Path(shim_path).resolve().parent.parent
        pkg_json = install_root / "resources" / "app" / "package.json"
        if not pkg_json.exists():
            return None
        data = json.loads(pkg_json.read_text(encoding="utf-8", errors="replace"))
    except (OSError, ValueError):
        return None
    version = data.get("version") if isinstance(data, dict) else None
    if isinstance(version, str) and version.strip():
        return version.strip()
    return None


def _get_exe_version(path: str) -> str | None:
    """Return the ``ProductVersion`` metadata field for a Windows ``.exe``.

    Reads embedded version metadata via PowerShell:

        (Get-Item -LiteralPath '<path>').VersionInfo.ProductVersion

    Works for any signed Windows binary that ships VersionInfo (most
    Electron-built apps do — Squirrel injects the version into ``app.asar``
    which Electron mirrors into the EXE's resource section).

    Returns ``None`` on:

    * non-Windows hosts (PowerShell helper short-circuits)
    * missing/inaccessible file
    * empty / non-string metadata
    * any PowerShell error

    The single quote in the path is the only character we have to escape —
    PowerShell's ``-LiteralPath`` accepts everything else verbatim. We
    escape ``'`` to ``''`` (PS literal single-quote) before interpolating.
    """
    if not path:
        return None
    escaped = path.replace("'", "''")
    result = run_ps(
        f"(Get-Item -LiteralPath '{escaped}').VersionInfo.ProductVersion",
        json_output=False,
    )
    if not result.ok:
        return None
    if not isinstance(result.data, str):
        return None
    value = result.data.strip()
    return value or None


def _toolbox_latest_version(app_dir: Path) -> str:
    """Return the highest version dir under a Toolbox channel.

    Toolbox layout::

        <app_dir>/ch-<channel>/<version>/bin/...
    """
    candidates: list[str] = []
    for channel in _iter_dir(app_dir):
        for ver_dir in _iter_dir(channel):
            if re.match(r"\d", ver_dir.name):
                candidates.append(ver_dir.name)
    if not candidates:
        return ""
    # Lexicographic sort works for date-based JetBrains versions (YYYY.M.P).
    return sorted(candidates, reverse=True)[0]


def _parse_jetbrains_install_dir(dirname: str) -> tuple[str | None, str]:
    """Extract (display_name, version) from a standalone-installer dir name.

    Examples that match::

        "IntelliJ IDEA Community Edition 2024.3.1" -> ("IntelliJ IDEA", "2024.3.1")
        "PyCharm 2023.2"                            -> ("PyCharm", "2023.2")

    Examples that do NOT match are returned as ``(None, "")`` so the caller
    skips them rather than reporting bogus data.
    """
    match = _JETBRAINS_VERSION_RE.search(dirname)
    if match:
        version = match.group(1)
        prefix = dirname[: match.start()].rstrip()
    else:
        version = ""
        prefix = dirname.rstrip()
    display = _JETBRAINS_APP_NAMES.get(prefix)
    if display is None:
        return None, ""
    return display, version


# ---------------------------------------------------------------------------
# MCP host paths
# ---------------------------------------------------------------------------


class WindowsMCPHostPaths:
    """Windows filesystem locations for MCP host configs.

    Logical paths mirror :class:`MacOSMCPHostPaths` but resolve under Windows
    user-profile conventions (``%APPDATA%`` ↔ ``~/Library/Application Support``).
    Existence is NOT checked here — these methods just compute the canonical
    location; callers handle missing files.
    """

    def claude_desktop_config(self) -> Path:
        """``%APPDATA%\\Claude\\claude_desktop_config.json``.

        Mirrors the macOS path
        ``~/Library/Application Support/Claude/claude_desktop_config.json``.
        """
        home = Path.home()
        appdata = Path(os.environ.get("APPDATA", str(home / "AppData" / "Roaming")))
        return appdata / "Claude" / "claude_desktop_config.json"

    def cursor_mcp_config(self) -> Path:
        """``%APPDATA%\\Cursor\\User\\globalStorage\\cursor.mcp\\mcp.json``.

        Mirrors the macOS path
        ``~/Library/Application Support/Cursor/User/globalStorage/cursor.mcp/mcp.json``.
        """
        home = Path.home()
        appdata = Path(os.environ.get("APPDATA", str(home / "AppData" / "Roaming")))
        return appdata / "Cursor" / "User" / "globalStorage" / "cursor.mcp" / "mcp.json"

    def vscode_mcp_config(self) -> list[Path]:
        """Return VS Code Stable + Insiders MCP config paths on Windows.

        VS Code stores user-level MCP configuration under
        ``%APPDATA%\\Code\\User\\mcp.json`` (Stable) and
        ``%APPDATA%\\Code - Insiders\\User\\mcp.json`` (Insiders). The legacy
        ``~/.vscode/mcp.json`` referenced in earlier collector code is NOT
        where VS Code actually persists MCP configuration on any platform —
        it was an incorrect cross-platform guess.
        """
        home = Path.home()
        appdata = Path(os.environ.get("APPDATA", str(home / "AppData" / "Roaming")))
        return [
            appdata / "Code" / "User" / "mcp.json",
            appdata / "Code - Insiders" / "User" / "mcp.json",
        ]


# ---------------------------------------------------------------------------
# Shell PATH expansion
# ---------------------------------------------------------------------------


class WindowsShellPathExpander:
    """Expand PATH for headless schedulers and locate per-user pip scripts.

    Mirrors :class:`MacOSShellPathExpander` but with Windows-typical install
    locations. Task Scheduler does not inherit the user's interactive PATH —
    we reconstruct a sensible overlay so dev tools (Python, Node, Git, Rust,
    Bun, etc.) are discoverable when the agent runs scheduled.

    Only directories that actually exist are added to PATH; this keeps the
    PATH from ballooning with phantom entries on machines that do not have
    every tool installed.
    """

    def expanded_path(self) -> str:
        base = os.environ.get("PATH", "")
        home = Path.home()
        appdata = Path(os.environ.get("APPDATA", str(home / "AppData" / "Roaming")))
        localappdata = Path(os.environ.get("LOCALAPPDATA", str(home / "AppData" / "Local")))
        programfiles = Path(os.environ.get("PROGRAMFILES", r"C:\Program Files"))
        programfiles_x86 = Path(os.environ.get("PROGRAMFILES(X86)", r"C:\Program Files (x86)"))

        extra = [
            appdata / "npm",  # global npm
            localappdata / "Programs" / "Python",  # python.org installer (per-user)
            home / ".cargo" / "bin",  # rustup
            home / ".bun" / "bin",  # Bun
            localappdata / "nvs",  # Node Version Switcher
            appdata / "Python",  # pip --user scripts
            programfiles / "Git" / "cmd",  # Git for Windows
            programfiles / "nodejs",  # Node.js installer
            localappdata / "Microsoft" / "WindowsApps",  # Microsoft Store apps
            programfiles_x86 / "Git" / "cmd",  # Git for Windows (x86)
        ]

        existing = [str(p) for p in extra if p.exists()]
        if not existing:
            return base
        if not base:
            return os.pathsep.join(existing)
        return os.pathsep.join([base, *existing])

    def pip_user_bin_candidates(self) -> list[Path]:
        """Return potential ``intercept-agent.exe`` install locations.

        Windows ``pip install --user`` drops scripts under
        ``%APPDATA%\\Python\\PythonXY\\Scripts``. Returns one candidate per
        Python version found, plus the legacy bare-Scripts fallback.
        """
        home = Path.home()
        appdata = Path(os.environ.get("APPDATA", str(home / "AppData" / "Roaming")))

        candidates: list[Path] = []
        python_root = appdata / "Python"
        if python_root.exists():
            try:
                for ver_dir in sorted(python_root.iterdir(), reverse=True):
                    if ver_dir.is_dir() and ver_dir.name.startswith("Python"):
                        scripts = ver_dir / "Scripts"
                        if scripts.exists():
                            candidates.append(scripts / "intercept-agent.exe")
            except (OSError, PermissionError):
                pass
        # Legacy / fallback location used by some pip configurations.
        candidates.append(appdata / "Python" / "Scripts" / "intercept-agent.exe")
        return candidates


# ---------------------------------------------------------------------------
# Scheduler (Task Scheduler)
# ---------------------------------------------------------------------------


# ``/SC`` keywords accepted by schtasks.exe. Anything outside this set produces
# ``ERROR: Invalid Schedule Type specified.`` when passed verbatim -- this is
# exactly the failure that took down 0.4.20 on Windows: the CLI was passing
# ``"3600"`` (the seconds form, mirroring the macOS launchd ``StartInterval``
# contract) and we were uppercasing it straight into ``/SC 3600``.
_SCHTASKS_SC_KEYWORDS: frozenset[str] = frozenset(
    {
        "MINUTE",
        "HOURLY",
        "DAILY",
        "WEEKLY",
        "MONTHLY",
        "ONCE",
        "ONSTART",
        "ONLOGON",
        "ONIDLE",
        "ONEVENT",
    }
)


def _translate_interval(interval: str) -> tuple[str, int | None]:
    """Map a caller-supplied interval to a schtasks ``(/SC, /MO)`` pair.

    The CLI computes the schedule once -- in seconds -- and forwards it to
    every platform's scheduler. macOS consumes the seconds value directly
    (``StartInterval`` is integer-seconds), but schtasks requires one of the
    string keywords below plus an optional ``/MO`` modifier. Without a
    translation step here, a numeric value like ``"3600"`` lands in ``/SC``
    and schtasks rejects it with exit 2147500037.

    Accepted inputs:

    * The bare keyword ``"hourly"`` (canonical default) -> ``("HOURLY", None)``.
    * Any of the schtasks ``/SC`` keywords (case-insensitive) -> uppercased
      keyword + ``None`` modifier. Lets callers configure explicit ``daily``,
      ``weekly``, etc. without learning the seconds form.
    * A numeric string (seconds) -> translated to the shortest sensible
      ``(/SC, /MO)`` pair:

      - ``< 60s`` is rounded up to 1 minute (schtasks' floor is MINUTE).
      - ``60s .. 59min`` -> ``("MINUTE", <minutes>)``.
      - ``1h .. 23h`` -> ``("HOURLY", <hours>)`` when the value divides evenly,
        otherwise falls back to ``MINUTE`` so the cadence isn't silently rounded.
      - ``24h .. 31 days`` -> ``("DAILY", <days>)`` when the value divides evenly.
      - Larger / non-divisible values cap at ``("DAILY", 1)`` -- schtasks
        ``MONTHLY`` requires a specific day-of-month modifier that we don't
        ask the user for.

    Returns ``(sc_type, mo_value)``. ``mo_value`` is ``None`` when no ``/MO``
    should be emitted (bare ``HOURLY`` / ``DAILY`` etc. mean "every N").
    """
    raw = (interval or "").strip()
    if not raw:
        return "HOURLY", None

    # Numeric path: seconds. Catches ``"3600"`` (the default from main.py)
    # and any explicit ``schedule.interval_seconds`` the user configured.
    if raw.lstrip("-").isdigit():
        seconds = int(raw)
        if seconds <= 60:
            return "MINUTE", 1
        if seconds < 3600:
            # 60s..3599s -> N minutes (round to nearest, floor at 1).
            minutes = max(1, round(seconds / 60))
            return "MINUTE", minutes
        if seconds < 86400:
            # 1h..23h. Prefer HOURLY when it divides evenly so the Task
            # Scheduler GUI shows "Hourly" rather than a multi-minute drift.
            if seconds % 3600 == 0:
                hours = seconds // 3600
                if 1 <= hours <= 23:
                    return "HOURLY", hours
            minutes = max(1, round(seconds / 60))
            # schtasks MINUTE caps at 1439 (one minute shy of 24h).
            return "MINUTE", min(minutes, 1439)
        # >= 24h. Prefer DAILY for divisible values; otherwise cap at daily.
        if seconds % 86400 == 0:
            days = seconds // 86400
            if 1 <= days <= 31:
                return "DAILY", days
        return "DAILY", 1

    # Keyword path. "hourly" is the historical default token from the
    # platform contract; the rest accept the schtasks keyword set
    # case-insensitively.
    upper = raw.upper()
    if upper in _SCHTASKS_SC_KEYWORDS:
        return upper, None

    # Unknown token -- fall back to HOURLY rather than emitting an invalid
    # ``/SC`` value. A misconfigured caller is preferable to a hard failure
    # at install time on the user's machine.
    return "HOURLY", None


class WindowsScheduler:
    """Task Scheduler-based scheduler.

    Uses ``schtasks.exe`` directly via :mod:`subprocess` rather than PowerShell.
    schtasks is the canonical CLI for Task Scheduler — it is faster, has more
    reliable error reporting for create/delete/query, and avoids the ~500ms
    PowerShell startup cost that ``run_ps`` would impose every install/status
    call. No pywin32 dependency.

    The task runs as a per-user task ("Intercept Agent" in the user's task
    folder), which means no UAC elevation is required and the task appears in
    the user's Task Scheduler GUI under Task Scheduler Library. Idempotent
    install via ``schtasks /Create /F``.
    """

    def install(self, program_args: list[str], interval: str = "hourly") -> None:
        """Register a per-user hourly task in Windows Task Scheduler.

        ``program_args`` is the full argv the task should execute, typically
        ``[sys.executable, "-m", "posture_agent", "collect", "--report"]``.
        Routing scheduled runs through ``python -m posture_agent`` (instead
        of resolving the ``intercept-agent`` console script via PATH) is
        what makes setup reliable on Windows: pip's user Scripts dir is not
        on the default PATH, so the console-script binary often can't be
        found at install time. ``sys.executable`` always exists.

        The first element is treated as the program (quoted in ``/TR`` if it
        contains spaces); remaining elements are appended verbatim. ``/F``
        overwrites any existing task with the same name so the call is
        idempotent -- re-running ``install`` upgrades the task in place
        rather than failing with "task exists".

        Raises :class:`UnsupportedPlatformError` on non-Windows hosts so the
        agent never accidentally calls schtasks.exe on macOS or Linux.
        """
        if platform.system() != "Windows":
            raise UnsupportedPlatformError("schtasks unavailable")

        if not program_args:
            raise ValueError("program_args must be a non-empty list")

        # Build the /TR action string. The first element is the program; we
        # always wrap it in double quotes so paths containing spaces (the
        # common case for sys.executable under "Program Files") survive
        # schtasks' tokenizer. Trailing args are appended space-separated.
        program = str(program_args[0])
        rest = " ".join(str(a) for a in program_args[1:])
        tr_value = f'"{program}" {rest}'.rstrip()

        # Translate the caller's interval to a valid schtasks ``/SC`` (+ ``/MO``)
        # pair. The CLI invokes us with ``interval=str(interval_seconds)`` --
        # i.e. ``"3600"`` for the default hourly cadence -- so we must accept
        # numeric strings here, not just schtasks keywords. Passing the raw
        # seconds value through to ``/SC`` triggers
        # ``ERROR: Invalid Schedule Type specified.`` (exit 2147500037)
        # because schtasks only accepts the keywords listed below.
        sc_type, mo_value = _translate_interval(interval)
        cmd = [
            "schtasks.exe",
            "/Create",
            "/SC",
            sc_type,
            "/TN",
            _TASK_NAME,
            "/TR",
            tr_value,
            "/F",  # overwrite if a task with this name already exists
        ]
        if mo_value is not None:
            # ``/MO`` is the modifier -- e.g. ``/SC MINUTE /MO 30`` for every
            # 30 minutes. Only some ``/SC`` types accept it (MINUTE, HOURLY,
            # DAILY, WEEKLY, MONTHLY); we only emit it when ``_translate_interval``
            # asked for one.
            cmd.extend(["/MO", str(mo_value)])
        proc = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=_SCHTASKS_TIMEOUT,
            check=False,
            **no_window_kwargs(),
        )
        if proc.returncode != 0:
            stderr = (proc.stderr or "").strip()
            raise RuntimeError(f"schtasks /Create failed: exit={proc.returncode}, stderr={stderr}")

    def uninstall(self) -> None:
        """Delete the Intercept Agent task from Task Scheduler.

        Tolerates the "task does not exist" case — schtasks.exe returns a
        nonzero exit code with stderr ``ERROR: The system cannot find the
        file specified.`` when the task is absent. We treat this as a
        successful uninstall (idempotent) rather than raising.
        """
        if platform.system() != "Windows":
            raise UnsupportedPlatformError("schtasks unavailable")

        cmd = ["schtasks.exe", "/Delete", "/TN", _TASK_NAME, "/F"]
        proc = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=_SCHTASKS_TIMEOUT,
            check=False,
            **no_window_kwargs(),
        )
        if proc.returncode != 0:
            stderr = (proc.stderr or "").lower()
            # "cannot find" => task already absent; treat as success.
            if "cannot find" in stderr:
                return
            raise RuntimeError(
                f"schtasks /Delete failed: exit={proc.returncode}, "
                f"stderr={(proc.stderr or '').strip()}"
            )

    def status(self) -> SchedulerStatus:
        """Query Task Scheduler for the Intercept Agent task.

        Parses ``schtasks /Query /FO LIST /V`` output, which prints
        ``"Field Name: Value"`` lines. ``Status`` reports ``Running`` /
        ``Ready`` / ``Disabled`` / ``Could not start`` etc.; ``Last Run
        Time`` carries the most recent execution timestamp in the host's
        locale-formatted form.
        """
        if platform.system() != "Windows":
            return SchedulerStatus(installed=False, running=None, last_run=None)

        cmd = [
            "schtasks.exe",
            "/Query",
            "/TN",
            _TASK_NAME,
            "/FO",
            "LIST",
            "/V",
        ]
        try:
            proc = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=_SCHTASKS_TIMEOUT,
                check=False,
                **no_window_kwargs(),
            )
        except (OSError, subprocess.SubprocessError):
            return SchedulerStatus(installed=False, running=None, last_run=None)

        if proc.returncode != 0:
            return SchedulerStatus(installed=False, running=None, last_run=None)

        # Parse the LIST format: each non-blank line is "FieldName: Value".
        # Field names use a colon as the separator; values may themselves
        # contain colons (e.g., timestamps "3:00:00 PM"), so we use a single
        # ``partition`` split rather than ``split(":")``.
        fields: dict[str, str] = {}
        for line in (proc.stdout or "").splitlines():
            if ":" not in line:
                continue
            key, _, value = line.partition(":")
            fields[key.strip()] = value.strip()

        last_run = fields.get("Last Run Time") or None
        running = fields.get("Status", "").lower() == "running"

        return SchedulerStatus(
            installed=True,
            running=running,
            last_run=last_run,
            raw=dict(fields) if fields else None,
        )


# ---------------------------------------------------------------------------
# Bundle factory
# ---------------------------------------------------------------------------


def bundle() -> PlatformBundle:
    """Build the Windows :class:`PlatformBundle`.

    Every slot is a real implementation as of C12; no remaining stubs.
    """
    return PlatformBundle(
        hardware=WindowsHardware(),
        security=WindowsSecurityPosture(),
        ssh_agent=WindowsSshAgent(),
        ides=WindowsIDEDiscovery(),
        mcp_paths=WindowsMCPHostPaths(),
        path_expander=WindowsShellPathExpander(),
        scheduler=WindowsScheduler(),
    )


__all__ = [
    "WindowsHardware",
    "WindowsIDEDiscovery",
    "WindowsMCPHostPaths",
    "WindowsScheduler",
    "WindowsSecurityPosture",
    "WindowsShellPathExpander",
    "WindowsSshAgent",
    "bundle",
]


# Make the AI-tool helpers re-importable for tests.
__all__ += [
    "_clean_processor_string",
    "_expand_template",
    "_get_exe_version",
    "_read_vscode_fork_version_from_shim",
    "_translate_interval",
]
