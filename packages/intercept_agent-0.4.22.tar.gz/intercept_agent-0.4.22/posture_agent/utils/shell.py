"""Shell utility functions for running subprocesses."""

import asyncio
import os
import re
import shutil
import sys

from posture_agent.utils.win_subprocess import no_window_kwargs

# Windows shim extensions that ``CreateProcess`` cannot execute directly.
# ``npm.cmd``, ``gcloud.cmd``, ``az.cmd``, ``gem.bat`` etc. are scripts that
# the cmd.exe interpreter must run. Calling them via
# ``asyncio.create_subprocess_exec`` raises
# ``OSError: [WinError 193] %1 is not a valid Win32 application``, which is
# the root cause of B5/B6 (npm, pnpm, gem, gcloud, az reporting no version
# on Windows even though they are detected).
_WINDOWS_SHIM_EXTENSIONS = (".cmd", ".bat")

# When ``shutil.which`` resolves to an extensionless file on Windows, that's
# almost always a Bash-style shim that ``CreateProcess`` cannot execute.
# Node's installer ships ``C:\Program Files\nodejs\npm`` (Bash shell script,
# no extension) alongside ``npm.cmd`` (cmd shim). The default Windows PATHEXT
# usually picks up ``npm.cmd`` first, but customised PATHEXT or an explicit
# ``shutil.which("npm")`` call without ``PATHEXT`` set can return the
# extensionless variant — Windows can't run it, even via cmd.exe (B9, #623).
# We probe these sibling extensions when the resolved path has none.
_WINDOWS_PROBE_EXTENSIONS = (".cmd", ".bat", ".exe")

# Windows "App Installer" stub patterns. When the Microsoft Store ships a
# placeholder for an aliased command (``python.exe``, ``python3.exe``,
# ``winget.exe``, etc.) the stub binary prints a redirect prompt to stderr
# and exits non-zero. Our B4 fix added stderr capture to ``check_version``,
# which then dutifully extracts the first ``\d+\.\d+`` token from that
# prompt as the "version" — surfacing in reports as a multi-paragraph
# explanation string instead of a real semver.
#
# A line matching one of these patterns is authoritative evidence that
# the binary is NOT actually installed; ``check_version`` strips matching
# lines before extracting a version, and returns ``None`` if nothing
# remains.
_INSTALL_REDIRECT_PATTERNS: tuple[re.Pattern[str], ...] = (
    # Microsoft Store python stub — exact wording as of Windows 11 25H2.
    re.compile(r"python was not found", re.IGNORECASE),
    # Generic "App execution aliases" prompt — covers any aliased binary
    # whose Store backing app is not installed.
    re.compile(r"app execution aliases", re.IGNORECASE),
    # The Store installer itself sometimes appears in the redirect copy.
    re.compile(r"install (it|from) the microsoft store", re.IGNORECASE),
)


def _strip_install_redirect_lines(text: str) -> str:
    """Remove lines that match a Windows App Installer redirect pattern.

    Preserves all other lines (including their original ordering and
    blank lines) so that a real ``--version`` banner riding alongside a
    stub prompt is still parseable. Returns the joined remaining text;
    callers check :meth:`str.strip` to detect "nothing left".
    """
    keep: list[str] = []
    for line in text.splitlines():
        if any(p.search(line) for p in _INSTALL_REDIRECT_PATTERNS):
            continue
        keep.append(line)
    return "\n".join(keep)


def _looks_like_install_redirect(text: str) -> bool:
    """Return True if any line of ``text`` matches an install-redirect pattern."""
    for line in text.splitlines():
        if any(p.search(line) for p in _INSTALL_REDIRECT_PATTERNS):
            return True
    return False


def _get_expanded_path() -> str:
    """Return PATH expanded with common tool locations.

    Delegates to the platform bundle's `ShellPathExpander`. On macOS this is
    a verbatim port of the prior in-line logic; future platforms (Windows,
    Linux) provide their own implementations.
    """
    # Local import avoids a circular dependency: platforms.macos imports
    # `run_command` from this module.
    from posture_agent.platforms import get_bundle

    return get_bundle().path_expander.expanded_path()


def _get_env() -> dict[str, str]:
    """Return environment with expanded PATH for subprocess execution."""
    env = os.environ.copy()
    env["PATH"] = _get_expanded_path()
    return env


def _upgrade_extensionless_to_shim(resolved: str) -> str:
    """Probe for a runnable Windows sibling when ``resolved`` has no extension.

    Node's installer ships ``C:\\Program Files\\nodejs\\npm`` (Bash script,
    no extension) alongside ``npm.cmd`` (cmd shim). When ``shutil.which``
    returns the extensionless variant — possible when PATHEXT is customised
    or the call bypasses PATHEXT — Windows can't execute it directly and
    cmd.exe can't interpret the Bash syntax either. The agent reports
    "no version" even though npm is installed (B9, #623).

    Returns the first existing sibling with one of
    :data:`_WINDOWS_PROBE_EXTENSIONS`, or the unchanged ``resolved`` path
    when no sibling exists (let the subprocess fail naturally).
    """
    if os.path.splitext(resolved)[1]:
        # Already has an extension — nothing to upgrade.
        return resolved
    for ext in _WINDOWS_PROBE_EXTENSIONS:
        candidate = resolved + ext
        if os.path.isfile(candidate):
            return candidate
    return resolved


def _resolve_for_exec(args: tuple[str, ...]) -> tuple[str, ...]:
    """Rewrite argv so Windows shim scripts (.cmd/.bat) can be executed.

    On Windows, ``asyncio.create_subprocess_exec`` invokes ``CreateProcess``
    directly and cannot run script-style shims (``npm.cmd``, ``gcloud.cmd``,
    ``az.cmd``, ``gem.bat``, ...). The fix is to resolve the binary via
    :func:`shutil.which` and, when the result is a shim, prepend
    ``cmd.exe /c`` so cmd interprets the script.

    Extensionless resolutions (e.g. ``C:\\Program Files\\nodejs\\npm`` —
    Node's Bash-script shim) are upgraded to their ``.cmd``/``.bat``/``.exe``
    sibling when one exists, since ``CreateProcess`` cannot execute the Bash
    variant on Windows. See :func:`_upgrade_extensionless_to_shim` (B9).

    On non-Windows hosts (and for non-shim binaries on Windows) this returns
    the argv unchanged.
    """
    if not args or sys.platform != "win32":
        return args

    binary, *rest = args
    # Already an absolute path? Use it directly. shutil.which respects PATH
    # plus the expanded overlay we set up for the subprocess env.
    expanded_env = _get_env()
    resolved = shutil.which(binary, path=expanded_env.get("PATH"))
    if not resolved:
        # Let the subprocess machinery raise its usual FileNotFoundError so
        # callers see the same error shape as before.
        return args

    # If shutil.which returned an extensionless file (Node's ``npm`` Bash
    # shim, etc.), prefer the runnable sibling so cmd.exe can interpret it.
    resolved = _upgrade_extensionless_to_shim(resolved)

    if resolved.lower().endswith(_WINDOWS_SHIM_EXTENSIONS):
        # cmd.exe /c "path" arg1 arg2 ... — quoting the path defends against
        # spaces in user-profile paths. Trailing args go through verbatim;
        # cmd.exe applies its own quoting rules to those.
        return ("cmd.exe", "/c", resolved, *rest)

    # Real .exe: invoke the resolved absolute path. This avoids relying on
    # PATHEXT lookup happening inside the subprocess.
    return (resolved, *rest)


async def run_command(*args: str, timeout: float = 10.0) -> str | None:
    """Run a command and return stdout, or None on failure.

    Returns the stdout decoded as UTF-8 (errors=replace). ``None`` indicates
    any failure: timeout, missing binary, non-zero exit, or empty output.
    Stderr is intentionally discarded here — callers that need stderr (e.g.
    Python's ``--version`` which prints to stderr on older releases) should
    use :func:`check_version`.
    """
    try:
        proc = await asyncio.create_subprocess_exec(
            *_resolve_for_exec(args),
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            env=_get_env(),
            **no_window_kwargs(),
        )
        stdout, _ = await asyncio.wait_for(proc.communicate(), timeout=timeout)
        if proc.returncode == 0 and stdout:
            return stdout.decode("utf-8", errors="replace")
        return None
    except (TimeoutError, FileNotFoundError, OSError):
        return None


async def _run_capture_both(*args: str, timeout: float = 10.0) -> str | None:
    """Run a command and return ``stdout + stderr`` joined, or ``None`` on failure.

    Some tools — notably older Python and the Microsoft Store ``python3.exe``
    stub on Windows — print their ``--version`` banner to stderr. Discarding
    stderr there caused B4 (Python detected but no version reported). Joining
    both streams lets the version regex find the banner regardless of which
    stream the tool chose.

    A non-zero exit code is still tolerated: the Microsoft Store stub may
    exit with an error after printing its prompt, but the banner is still
    parsable. We require *some* output on either stream.
    """
    try:
        proc = await asyncio.create_subprocess_exec(
            *_resolve_for_exec(args),
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            env=_get_env(),
            **no_window_kwargs(),
        )
        stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=timeout)
    except (TimeoutError, FileNotFoundError, OSError):
        return None

    out = (stdout or b"").decode("utf-8", errors="replace")
    err = (stderr or b"").decode("utf-8", errors="replace")
    combined = out if out else err
    # If both streams emitted content, prefer stdout but append stderr so the
    # regex can fall through. Most tools only use one stream, so this branch
    # is rare.
    if out and err:
        combined = out + "\n" + err
    if not combined.strip():
        return None
    return combined


def _parse_version_output(result: str) -> str | None:
    """Extract a semver-like token from ``result`` or return ``None``.

    Returns ``None`` for install-redirect prompts (Microsoft Store stubs)
    or empty/whitespace-only output. Falls back to the first 50 chars of
    the first line when no semver pattern matches.
    """
    if not result:
        return None

    # If the output is dominated by a Microsoft Store install-redirect
    # prompt, the binary is a stub — no real version exists.
    if _looks_like_install_redirect(result):
        return None

    cleaned = _strip_install_redirect_lines(result).strip()
    if not cleaned:
        return None

    lines = cleaned.split("\n")

    # ``\d+\.\d+(?:\.\d+)*`` matches "10.8.2", "1.0", "2024.3.1.1".
    semver_re = re.compile(r"\d+\.\d+(?:\.\d+)*")

    # First line: "<word> <semver>" (e.g. "git version 2.43.0") or bare
    # semver ("10.8.2" — npm / pnpm on Windows).
    first = lines[0].strip()
    match = semver_re.search(first)
    if match:
        return match.group(0)

    # Multi-line "Version: 0.107.1" blocks (grype, syft, cosign).
    for line in lines[1:]:
        stripped = line.strip()
        if stripped.lower().startswith("version:"):
            ver_match = semver_re.search(stripped)
            if ver_match:
                return ver_match.group(0)

    # Final pass: any line with a semver-like token.
    for line in lines[1:]:
        ver_match = semver_re.search(line)
        if ver_match:
            return ver_match.group(0)

    return first[:50]  # Fallback: first 50 chars of first line


def _is_real_version(parsed: str | None) -> bool:
    """Return True if ``parsed`` looks like a real semver (digits-and-dots).

    The fallback path of :func:`_parse_version_output` returns the first
    50 chars of the first line when no semver matches — that's "we tried
    but found nothing". Callers that want to know whether to retry with a
    different flag use this gate to distinguish.
    """
    if not parsed:
        return False
    return bool(re.fullmatch(r"\d+(\.\d+)+", parsed))


async def check_version(binary: str, version_flag: str, *, timeout: float = 10.0) -> str | None:
    """Get version string from a binary. Handles multi-word flags.

    Reads BOTH stdout and stderr (B4: Python --version writes to stderr in
    older releases and on the Microsoft Store stub). Tolerates non-zero
    exit when usable output is present. Inherits the Windows shim handling
    from :func:`_resolve_for_exec` so ``.cmd``/``.bat`` shims like
    ``npm.cmd``, ``gcloud.cmd`` and ``az.cmd`` are invoked through
    ``cmd.exe /c`` (B5/B6).

    Falls back to ``-v`` when the supplied ``version_flag`` was
    ``--version`` and produced no parseable semver (B9): some shims accept
    only the short flag, and trying both is cheap insurance against
    "detected but no version" reports. The retry is bounded — ``-v`` is
    only attempted once and only when the original flag was the canonical
    long form, so there is no risk of an infinite loop.

    Returns ``None`` when the output looks like a Microsoft Store / App
    Installer redirect prompt (e.g., the ``python3.EXE`` stub printing
    ``"Python was not found; run without arguments to install from the
    Microsoft Store..."``). The redirect copy contains numbers that the
    semver regex would otherwise misinterpret as a version, and its
    presence is authoritative evidence that the binary is not actually
    installed.

    Accepts version strings in two shapes:

    * ``<word> <semver>`` — the common form, e.g. ``"git version 2.43.0"``
      or ``"Python 3.12.5"``.
    * Bare semver on its own line — e.g. ``"10.8.2"``, which is what
      ``npm --version`` and ``pnpm --version`` print on Windows. The
      stricter "needs a leading word" interpretation we used before
      rejected these and produced "no version" in the report (B6 follow-up).
    """
    args = [binary] + version_flag.split()
    result = await _run_capture_both(*args, timeout=timeout)
    parsed = _parse_version_output(result) if result else None

    if _is_real_version(parsed):
        return parsed

    # Defensive fallback: try ``-v`` when the canonical ``--version`` came
    # back empty. Many shims (older npm wrappers, some yarn variants)
    # accept only the short flag. Bounded to a single retry.
    if version_flag.strip() == "--version":
        retry = await _run_capture_both(binary, "-v", timeout=timeout)
        if retry:
            retry_parsed = _parse_version_output(retry)
            if _is_real_version(retry_parsed):
                return retry_parsed
            # ``-v`` may still beat the long flag (non-semver banner) if
            # neither produced a real semver but at least one yielded text.
            parsed = parsed or retry_parsed

    return parsed
