"""Windows console-window suppression for subprocess invocations.

When the posture agent runs under a scheduled task or from a GUI launcher on
Windows (e.g. ``pythonw.exe`` doesn't apply here — Task Scheduler's hidden
window mode does), the *child* processes we spawn (``powershell.exe``,
``schtasks.exe``, ``cmd.exe`` shims for ``npm.cmd``/``gcloud.cmd``, the
``pip``/``uv`` upgrader, etc.) still pop up their own visible console window
unless we tell ``CreateProcess`` to suppress it.

The fix is OS-specific: on Windows we pass
``creationflags=subprocess.CREATE_NO_WINDOW``. On macOS / Linux the flag
doesn't exist on the ``subprocess`` module at all (``CREATE_NO_WINDOW`` is a
Win32-only constant) so this helper must short-circuit before touching the
attribute.

Usage::

    from posture_agent.utils.win_subprocess import no_window_kwargs

    subprocess.run(cmd, **no_window_kwargs(), capture_output=True)

    # Or merge into an existing kwargs dict (helper does not overwrite a
    # caller-supplied ``creationflags`` value):
    kwargs = {"capture_output": True, "text": True}
    kwargs.update(no_window_kwargs())
    subprocess.run(cmd, **kwargs)

The helper returns an empty dict on non-Windows platforms so the same call
sites work everywhere without further branching.
"""

from __future__ import annotations

import subprocess
import sys

# Resolve the flag once at import time. On non-Windows platforms ``subprocess``
# does not expose ``CREATE_NO_WINDOW`` at all, so ``getattr`` with a default of
# ``0`` keeps the kwargs dict safe to splat into ``subprocess.run``/
# ``asyncio.create_subprocess_exec`` on every OS.
_CREATE_NO_WINDOW: int = getattr(subprocess, "CREATE_NO_WINDOW", 0)


def no_window_kwargs() -> dict[str, int]:
    """Return subprocess kwargs that suppress the console window on Windows.

    Returns ``{"creationflags": subprocess.CREATE_NO_WINDOW}`` on Windows,
    and ``{}`` everywhere else. The empty-dict branch is intentional: it
    means call sites can unconditionally splat the result without first
    checking ``sys.platform``.

    The Windows flag has no effect when invoked from an already-windowless
    process (it's idempotent), so passing it from a foreground terminal
    session is safe — the user won't see anything change in that case.
    """
    if sys.platform == "win32":
        return {"creationflags": _CREATE_NO_WINDOW}
    return {}


__all__ = ["no_window_kwargs"]
