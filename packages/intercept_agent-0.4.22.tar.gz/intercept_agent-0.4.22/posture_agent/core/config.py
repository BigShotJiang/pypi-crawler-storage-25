"""Application configuration loaded from YAML files with env overrides."""

import logging
import os
from functools import lru_cache
from importlib.metadata import PackageNotFoundError, version
from importlib.resources import files
from pathlib import Path

import yaml
from pydantic import BaseModel, field_validator

# Distribution names this package may be installed under. The first match
# from `importlib.metadata.version` wins. Test PyPI uses the `-test` suffix
# (rewritten in CI) so the agent must look there too before falling back to
# the bundled VERSION file.
_DIST_CANDIDATES: tuple[str, ...] = (
    "intercept-agent",
    "intercept-agent-test",
)

logger = logging.getLogger(__name__)


class AppConfig(BaseModel):
    """Application configuration."""

    name: str = "Intercept Posture Agent"
    debug: bool = False


class APIConfig(BaseModel):
    """API connection configuration."""

    url: str = "http://localhost:8000"
    timeout: int = 30
    retries: int = 3
    api_key: str = ""
    tenant_id: str = ""
    # Email of the user who created the enrollment token. Captured from the
    # `POST /enroll` response during `intercept-agent setup` and persisted to
    # the user's `agent.yaml`. Sent on every posture report so the API can
    # associate the report with a developer even when `git config user.email`
    # is unset. May be None for older identity service versions or when the
    # creating user's account was deleted.
    enrolled_email: str | None = None


class CollectorsConfig(BaseModel):
    """Collector enable/disable flags."""

    machine: bool = True
    ides: bool = True
    extensions: bool = True
    ai_tools: bool = True
    dev_tools: bool = True
    security: bool = True
    package_managers: bool = True
    mcp_servers: bool = True


class ScheduleConfig(BaseModel):
    """Schedule configuration."""

    interval_seconds: int = 3600

    @field_validator("interval_seconds", mode="before")
    @classmethod
    def _coerce_interval(cls, v: object) -> int:
        """Defensively coerce interval_seconds to int.

        If the YAML file contains a corrupted value (e.g. a serialised
        MagicMock string from a test leak), fall back to the default
        instead of crashing the agent.
        """
        if isinstance(v, int):
            return v
        try:
            return int(v)
        except (TypeError, ValueError):
            logger.warning(
                "Invalid interval_seconds value %r, falling back to 3600",
                v,
            )
            return 3600


class Settings:
    """Combined settings from YAML config and environment."""

    def __init__(self) -> None:
        self._load_config()

    def _load_config(self) -> None:
        """Load configuration from YAML file based on ENVIRONMENT variable."""
        env = os.getenv("ENVIRONMENT", "dev-local")
        user_config = Path.home() / ".config" / "intercept" / "agent.yaml"
        config_paths = [
            user_config,
            Path(f"config/{env}.yaml"),
            Path(f"../config/{env}.yaml"),
            Path(__file__).parent.parent.parent / "config" / f"{env}.yaml",
        ]

        config_data: dict = {}
        for config_path in config_paths:
            if config_path.exists():
                with open(config_path) as f:
                    config_data = yaml.safe_load(f) or {}
                break

        self.app = AppConfig(**config_data.get("app", {}))
        self.api = APIConfig(**config_data.get("api", {}))
        self.collectors = CollectorsConfig(**config_data.get("collectors", {}))
        self.schedule = ScheduleConfig(**config_data.get("schedule", {}))
        self.logging_config = config_data.get("logging", {})

        # Environment variable overrides
        if api_url := os.environ.get("INTERCEPT_API_URL"):
            self.api = self.api.model_copy(update={"url": api_url})
        if api_key := os.environ.get("INTERCEPT_API_KEY"):
            self.api = self.api.model_copy(update={"api_key": api_key})
        if tenant_id := os.environ.get("INTERCEPT_TENANT_ID"):
            self.api = self.api.model_copy(update={"tenant_id": tenant_id})

    @property
    def agent_version(self) -> str:
        """Get agent version, robust to install method and distribution name.

        Resolution order:
        1. Installed package metadata for ``intercept-agent`` (prod PyPI).
        2. Installed package metadata for ``intercept-agent-test`` (Test PyPI).
        3. ``VERSION`` file bundled inside the wheel via
           ``[tool.hatch.build.targets.wheel.force-include]``, read using
           ``importlib.resources``. Works on every OS (no path arithmetic).
        4. Top-level ``VERSION`` file when running from a source checkout.
        5. ``"0.0.0"`` last-resort sentinel.
        """
        for dist in _DIST_CANDIDATES:
            try:
                return version(dist)
            except PackageNotFoundError:
                continue

        # Bundled VERSION inside the wheel (importlib.resources is the only
        # path that works reliably on Windows where `__file__`-relative
        # arithmetic into the source tree does not apply post-install).
        try:
            resource = files("posture_agent").joinpath("VERSION")
            text = resource.read_text(encoding="utf-8").strip()
            if text:
                return text
        except (FileNotFoundError, ModuleNotFoundError, OSError):
            pass

        # Source-checkout fallback: <repo>/services/posture-agent/VERSION.
        version_path = Path(__file__).parent.parent.parent / "VERSION"
        if version_path.exists():
            return version_path.read_text().strip()
        return "0.0.0"

    # Convenience properties
    @property
    def debug(self) -> bool:
        return self.app.debug


@lru_cache
def get_settings() -> Settings:
    """Get cached settings instance."""
    return Settings()
