"""Machine fingerprint generation."""

import hashlib
import platform

from posture_agent.platforms import get_bundle


async def get_machine_fingerprint() -> str:
    """Generate a stable machine fingerprint from the hardware UUID.

    Hashing happens here; the platform bundle returns the raw UUID/serial.
    """
    bundle = get_bundle()

    raw = await bundle.hardware.machine_uuid()
    if raw:
        return hashlib.sha256(raw.encode()).hexdigest()[:32]

    # Last resort: hostname-based
    fallback = f"{platform.node()}-{platform.machine()}"
    return hashlib.sha256(fallback.encode()).hexdigest()[:32]
