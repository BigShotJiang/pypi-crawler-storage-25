"""Module entry point so ``python -m posture_agent`` works.

This is the fallback invocation path that doesn't depend on the
``intercept-agent`` console script being on PATH. It matters most on
Windows, where ``pip install --user`` puts ``intercept-agent.exe``
under ``%APPDATA%\\Python\\Python3xx\\Scripts\\`` and that directory is
not on the default PATH. Users hitting that PATH issue can always fall
back to::

    python -m posture_agent setup --token <hse_...>

The ``intercept-agent`` console script in ``pyproject.toml`` remains the
recommended entry point; this is purely a safety net.
"""

from posture_agent.main import cli

if __name__ == "__main__":
    cli()
