
**X-ray security scanner for AI agent misconfigurations.**

See through your agent configs. Detect dangerous permissions, sandbox misconfigurations,
and attack paths in Claude Code, Codex CLI, OpenClaw, and MCP setups — before they become exploits.

> Under active development. Full release coming soon.

## Links
