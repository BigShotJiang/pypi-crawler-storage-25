"""xrails — X-ray security scanner for AI agent misconfigurations."""

__version__ = "0.1.0"
