from .core import AIBrowser

__all__ = ['AIBrowser']
