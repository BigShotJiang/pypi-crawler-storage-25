from DrissionPage import ChromiumPage, ChromiumOptions
from typing import List, Dict, Any

import time
import os
import urllib.request
import zipfile
import io

def _setup_ublock_origin() -> str:
    """Downloads and extracts the official uBlock Origin MV2 extension perfectly."""
    import time, urllib.request, zipfile, io, shutil
    home = os.path.expanduser("~")
    base_ext_dir = os.path.join(home, ".aura_browser", "ublock_official")
    # CRITICAL: The zip extracts a nested folder! We must point to the nested folder!
    real_ext_dir = os.path.join(base_ext_dir, "uBlock0.chromium")
    
    if os.path.exists(os.path.join(real_ext_dir, "manifest.json")):
        return real_ext_dir
        
    print("[Aura-Browser] Downloading official uBlock Origin (One-time setup)...")
    if os.path.exists(base_ext_dir):
        shutil.rmtree(base_ext_dir)
    os.makedirs(base_ext_dir, exist_ok=True)
    
    try:
        url = "https://github.com/gorhill/uBlock/releases/download/1.57.2/uBlock0_1.57.2.chromium.zip"
        req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
        resp = urllib.request.urlopen(req, timeout=30)
        
        with zipfile.ZipFile(io.BytesIO(resp.read())) as zf:
            zf.extractall(base_ext_dir)
            
        print("[Aura-Browser] uBlock Origin installed successfully!")
        return real_ext_dir
    except Exception as e:
        print(f"[Aura-Browser] Failed to download uBlock Origin: {e}")
        return ""

class AIBrowser:
    def __init__(self, headless: bool = False, mute: bool = True, debug: bool = False):
        import os
        self.debug = debug
        co = ChromiumOptions()
        
        # ⚠️ CRITICAL FIX: Ensure a completely isolated browser instance is launched!
        # If we don't do this, DrissionPage connects to the user's running Chrome,
        # which causes ALL command-line arguments (stealth, extensions) to be IGNORED!
        home = os.path.expanduser("~")
        profile_path = os.path.join(home, ".aura_browser", "isolated_profile")
        co.set_user_data_path(profile_path)
        co.auto_port() # Picks a random free port to guarantee a fresh launch
        
        if headless:
            co.set_argument('--headless=new')
            
        if mute:
            co.mute(True)
            
        # 🛡️ ORIGINAL STEALTH SETTINGS
        co.set_argument('--no-sandbox')
        co.set_argument('--disable-gpu')
        co.set_argument('--disable-blink-features=AutomationControlled')

        # 🚫 Attach OFFICIAL uBlock Origin
        ublock_path = _setup_ublock_origin()
        if ublock_path:
            co.add_extension(ublock_path)

        self.page = ChromiumPage(addr_or_opts=co)
        
        # Close the uBlock welcome tab if it opens on first install
        try:
            import time
            time.sleep(1)
            if len(self.page.tab_ids) > 1:
                self.page.close_other_tabs()
        except:
            pass
        
        # 🗡️ THE ULTIMATE NATIVE DOM ASSASSIN (Triple Protection!)
        # Bypasses all Google restrictions, runs natively via CDP before page loads!
        js_assassin = """
        // Active DOM Scanner to instantly destroy fake captchas and ad overlays
        const observer = new MutationObserver(() => {
            document.querySelectorAll('iframe, [class*="ad"], [id*="ad"], [style*="z-index: 2147483647"]').forEach(e => {
                let html = e.innerHTML || "";
                let src = e.src || "";
                
                // 1. Text/URL Match
                if (html.includes("Show content") || html.includes("I\\'m not a robot") || html.includes("captcha") || src.includes("captcha") || src.includes("pop")) {
                    try { e.remove(); } catch(err) {}
                }
                
                // 2. Kill malicious full-screen or high z-index iframe overlays
                if (e.tagName === 'IFRAME') {
                    let z = parseInt(window.getComputedStyle(e).zIndex);
                    let w = window.getComputedStyle(e).width;
                    let h = window.getComputedStyle(e).height;
                    if (z > 9000 || (w === '100vw' && h === '100vh') || (w === '100%' && h === '100%')) {
                        try { e.remove(); } catch(err) {}
                    }
                }
            });
        });
        observer.observe(document.documentElement, { childList: true, subtree: true });
        """
        self.page.add_init_js(js_assassin)
        
        self.page.set.auto_handle_alert() # Accept any annoying JS alerts
            
        self.interactive_elements = {}
        if self.debug:
            print("[Aura-Browser] Initialized in DEBUG mode.")
        
        # Automatically close any new tabs that open unexpectedly (Pop-ups)
        self.page.set.auto_handle_alert() # Accept any annoying JS alerts
        
    def go_to(self, url: str):
        """Navigate to a URL and wait for it to load completely."""
        if self.debug:
            print(f"[Aura-Browser] Navigating to: {url}")
        self.page.get(url)
        self.page.wait.doc_loaded() # Wait for the document
        time.sleep(3) # Extra wait for dynamic JavaScript frameworks (React/Vue) to render
        if self.debug:
            print(f"[Aura-Browser] Page fully loaded.")
        
    def get_interactive_elements(self) -> List[Dict[str, str]]:
        """
        Scans the page for interactive elements (buttons, links, inputs).
        Returns them as a list of dictionaries with unique IDs for AI to control.
        """
        self.interactive_elements.clear()
        elements_data = []
        
        # Selectors that an AI might want to interact with (DrissionPage syntax requires tag: or css:)
        selectors = ['tag:a', 'tag:button', 'tag:input', 'tag:textarea', 'tag:select', 'css:[role="button"]']
        
        element_counter = 1
        for selector in selectors:
            for ele in self.page.eles(selector):
                try:
                    # Exclude hidden or non-interactive elements
                    if ele.states.is_displayed and not ele.attr('hidden') and ele.states.is_enabled:
                        tag = ele.tag
                        # Filter out inputs that are likely not useful
                        if tag == 'input' and ele.attr('type') in ['hidden', 'checkbox', 'radio']:
                            continue
                            
                        eid = f"ID_{element_counter}"
                        self.interactive_elements[eid] = ele
                        
                        text_val = (ele.text or ele.attr('aria-label') or ele.attr('placeholder') or ele.attr('name') or '').strip()
                        elements_data.append({
                            "id": eid,
                            "tag": tag,
                            "text": text_val,
                            "type": ele.attr('type') if tag == 'input' else None
                        })
                        element_counter += 1
                except Exception:
                    pass
                    
        if self.debug:
            print(f"[Aura-Browser] Extracted {len(elements_data)} visible interactive elements.")
        return elements_data
        
    def _find_element_intelligently(self, identifier: str):
        """Finds an element by AI ID, fuzzy text match, or standard developer CSS/XPath locator."""
        # 1. Direct exact ID match (For AI)
        if identifier in self.interactive_elements:
            return self.interactive_elements[identifier]
            
        # 2. Intelligent fallback match (If AI hallucinates something like 'ID_SEARCH' or 'search')
        # We remove 'id_' just in case the AI made up a fake ID name.
        identifier_clean = identifier.lower().replace("id_", "").strip()
        if identifier_clean:
            for eid, ele in self.interactive_elements.items():
                text = ele.text or ele.attr('aria-label') or ele.attr('placeholder') or ele.attr('name') or ''
                if text and identifier_clean in text.lower():
                    return ele
                    
        # 3. For General Programmers! Treat identifier as a CSS/XPath or DrissionPage locator
        try:
            ele = self.page.ele(identifier, timeout=1)
            if ele:
                return ele
        except Exception:
            pass
            
        return None
        
    def click(self, element_id: str) -> bool:
        """Click an element intelligently."""
        ele = self._find_element_intelligently(element_id)
        if ele:
            try:
                # by_js=True helps bypass some tricky interceptors
                ele.click(by_js=True) 
                self.page.wait.doc_loaded()
                time.sleep(2)
                return True
            except Exception as e:
                print(f"Failed to click {element_id}: {e}")
                return False
        return False
        
    def type_text(self, element_id: str, text: str, press_enter: bool = False) -> bool:
        """Type text into an input intelligently."""
        ele = self._find_element_intelligently(element_id)
        if ele:
            try:
                ele.input(text, clear=True)
                if press_enter:
                    # Press enter key
                    self.page.actions.type('\n')
                self.page.wait.doc_loaded()
                time.sleep(2)
                return True
            except Exception as e:
                print(f"Failed to type in {element_id}: {e}")
                return False
        return False
        
    def take_screenshot(self, save_path: str = "screenshot.jpg"):
        """Take a screenshot of the current page and save it locally."""
        try:
            self.page.get_screenshot(path=save_path)
            return True
        except Exception as e:
            print(f"Failed to take screenshot: {e}")
            return False
        
    def get_page_text(self) -> str:
        """Extract clean, readable text from the current page."""
        return self.page.body.text
        
    def close(self):
        """Quit the browser."""
        self.page.quit()
