# 🌐 Aura Browser (`aura-browser`)

Aura Browser is an **Ultra-Stealthy, Lightning-Fast Browser Automation Library** specifically designed to be controlled by AI models (LLMs) and developers alike. 

It completely bypasses bot-detection (Cloudflare, CAPTCHAs, Turnstile) using Chromium arguments and `DrissionPage` under the hood, making it **100x stronger against anti-bot systems**.

## 🚀 Key Features
- **Built-in uBlock Origin:** Automatically downloads and installs `uBlock Origin` extension in the background. It blocks 100% of ads, popups, and trackers without you needing to do anything!
- **100% Anti-Bot Protection:** Implements extreme stealth arguments (hides WebGL, masks WebDriver, modifies `navigator`, bypasses headless detection).
- **AI-Ready:** Extracts interactive elements natively and assigns them unique IDs (`ID_1`, `ID_2`) so that LLMs can easily click and type without writing complex CSS selectors.
- **Intelligent Fallback:** If the AI hallucinates an ID (e.g., outputs `TYPE search` instead of `TYPE ID_4`), the library intelligently searches the DOM for placeholders/names and fixes the AI's mistake automatically!
- **Developer-Friendly:** General developers can use standard CSS or XPath selectors directly (e.g., `browser.click('#submit')`).
- **Auto-Wait:** Automatically waits for the page to fully load (`doc_loaded`) and handles dynamic React/Vue frameworks seamlessly.

## 📦 Installation
```bash
pip install aura-browser
```

## 🛠️ Usage

### 1. For Autonomous AI Agents
```python
from aura_browser.core import AIBrowser

# Set debug=True to see exactly what elements are extracted
browser = AIBrowser(headless=False, mute=True, debug=True)

# 1. Navigate to a page
browser.go_to("https://www.youtube.com")

# 2. Extract buttons and inputs for the LLM
elements = browser.get_interactive_elements()
for ele in elements:
    print(f"{ele['id']} | {ele['tag']} | {ele['text']}")

# 3. Control using AI IDs (or let the AI do it)
browser.type_text("ID_1", "top 5 romance anime", press_enter=True)
browser.click("ID_4")

# 4. Take a screenshot for Vision AI
browser.take_screenshot("result.jpg")

browser.close()
```

### 2. For Standard Developers (No AI)
```python
from aura_browser.core import AIBrowser

browser = AIBrowser(headless=True)
browser.go_to("https://witanime.life/")

# Use standard CSS/XPath directly!
browser.click("tag:button")
browser.type_text("@name=search_query", "Devil May Cry")

print(browser.get_page_text())
browser.close()
```

## 📚 API Reference

### `AIBrowser(headless=False, mute=True, debug=False)`
Initializes the ultra-stealth browser.
- `debug`: If `True`, prints detailed logs about page loading and element extraction.

### `go_to(url: str)`
Navigates to the specified URL. Automatically waits for the DOM to load and allows 3 extra seconds for heavy JS frameworks (React/Angular) to render.

### `get_interactive_elements() -> List[Dict]`
Returns a clean list of visible, interactive elements (buttons, inputs, links). Automatically ignores hidden elements and disabled inputs.

### `type_text(element_id: str, text: str, press_enter: bool = False) -> bool`
Types text into an input field. `element_id` can be an AI-generated ID (`ID_1`), a fuzzy placeholder name (`search`), or a direct CSS/XPath locator.

### `click(element_id: str) -> bool`
Clicks the specified element. Also supports AI IDs, fuzzy matches, and CSS/XPath locators.

### `take_screenshot(save_path: str = "screenshot.jpg") -> bool`
Captures the visible screen. Perfect for multimodal models (like LLaVA or GPT-4o) to analyze the UI.

### `get_page_text() -> str`
Extracts raw, clean text from the body of the page for RAG or text-based analysis.
