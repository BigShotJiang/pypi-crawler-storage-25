from flakemark.engine import FlakeMark
from flakemark.differ.divergence import DivergenceReport, DivergenceType

__version__ = "1.1.1"
__author__  = "Khushdeep Sharma"
__email__   = "itskhushsharma@gmail.com"
__all__     = ["FlakeMark", "DivergenceReport", "DivergenceType"]
