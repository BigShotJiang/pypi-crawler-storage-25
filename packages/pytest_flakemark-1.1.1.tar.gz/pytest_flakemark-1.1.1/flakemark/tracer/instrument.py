import ast
import sys
import os
import json
import tempfile
import subprocess
import textwrap
import string
from dataclasses import dataclass, field
from typing import Any


@dataclass
class TraceEvent:
    kind:       str
    file:       str
    line:       int
    func:       str
    elapsed_ms: float
    value:      Any = None
    thread_id:  int = 0

    def to_dict(self) -> dict:
        return {
            "kind":       self.kind,
            "file":       self.file,
            "line":       self.line,
            "func":       self.func,
            "elapsed_ms": self.elapsed_ms,
            "value":      str(self.value)[:120] if self.value is not None else None,
            "thread_id":  self.thread_id,
        }

    @classmethod
    def from_dict(cls, d: dict) -> "TraceEvent":
        return cls(**d)

    def __repr__(self) -> str:
        v = f" -> {self.value}" if self.value else ""
        return f"[{self.elapsed_ms:.1f}ms] {self.kind:8s} {self.file}:{self.line}{v}"


@dataclass
class ExecutionTrace:
    run_id:      int
    outcome:     str
    error:       str | None = None
    events:      list[TraceEvent] = field(default_factory=list)
    duration_ms: float = 0.0

    def add(self, event: TraceEvent) -> None:
        self.events.append(event)

    def __len__(self) -> int:
        return len(self.events)

    def to_dict(self) -> dict:
        return {
            "run_id":      self.run_id,
            "outcome":     self.outcome,
            "error":       self.error,
            "duration_ms": self.duration_ms,
            "events":      [e.to_dict() for e in self.events],
        }

    @classmethod
    def from_dict(cls, d: dict) -> "ExecutionTrace":
        t = cls(
            run_id=d["run_id"],
            outcome=d["outcome"],
            error=d.get("error"),
            duration_ms=d.get("duration_ms", 0.0),
        )
        t.events = [TraceEvent.from_dict(e) for e in d.get("events", [])]
        return t

    def __repr__(self) -> str:
        return (
            f"ExecutionTrace(run={self.run_id}, outcome={self.outcome}, "
            f"events={len(self.events)}, duration={self.duration_ms:.1f}ms)"
        )


class TraceInserter(ast.NodeTransformer):

    def __init__(self, filename: str) -> None:
        self._filename = filename
        self._func_stack: list[str] = []
        self.is_async = False

    @property
    def _current_func(self) -> str:
        return self._func_stack[-1] if self._func_stack else ""

    def _make_record(self, kind: str, line: int, func: str = "",
                     value_expr=None) -> ast.Call:
        fn = func or self._current_func
        args = [
            ast.Constant(value=kind),
            ast.Constant(value=self._filename),
            ast.Constant(value=line),
            ast.Constant(value=fn),
        ]
        kw = []
        if value_expr is not None:
            kw.append(ast.keyword(arg="value", value=value_expr))
        return ast.Call(
            func=ast.Name(id="__fm_record__", ctx=ast.Load()),
            args=args,
            keywords=kw,
        )

    def _wrap_stmt(self, kind: str, line: int, func: str = "",
                   value_expr=None) -> ast.Expr:
        node = ast.Expr(value=self._make_record(kind, line, func, value_expr))
        ast.fix_missing_locations(node)
        return node

    def visit_AsyncFunctionDef(self, node: ast.AsyncFunctionDef):
        self.is_async = True
        return self._instrument_funcdef(node)

    def visit_FunctionDef(self, node: ast.FunctionDef):
        return self._instrument_funcdef(node)

    def _instrument_funcdef(self, node):
        self._func_stack.append(node.name)
        self.generic_visit(node)
        self._func_stack.pop()

        entry = self._wrap_stmt("call", node.lineno, node.name)
        node.body.insert(0, entry)
        ast.fix_missing_locations(entry)
        return node

    def visit_Assign(self, node: ast.Assign):
        self.generic_visit(node)
        if len(node.targets) == 1 and isinstance(node.targets[0], ast.Name):
            name = node.targets[0].id
            rec = self._wrap_stmt(
                "assign", node.lineno, "",
                ast.Name(id=name, ctx=ast.Load()),
            )
            return [node, rec]
        return node

    def visit_AugAssign(self, node: ast.AugAssign):
        self.generic_visit(node)
        if isinstance(node.target, ast.Name):
            name = node.target.id
            rec = self._wrap_stmt(
                "assign", node.lineno, "",
                ast.Name(id=name, ctx=ast.Load()),
            )
            return [node, rec]
        return node

    def visit_Return(self, node: ast.Return):
        self.generic_visit(node)
        if node.value is not None:
            tmp = "__fm_ret__"
            store = ast.Assign(
                targets=[ast.Name(id=tmp, ctx=ast.Store())],
                value=node.value,
            )
            rec = self._wrap_stmt(
                "return", node.lineno, "",
                ast.Name(id=tmp, ctx=ast.Load()),
            )
            new_ret = ast.Return(value=ast.Name(id=tmp, ctx=ast.Load()))
            for n in [store, rec, new_ret]:
                ast.copy_location(n, node)
                ast.fix_missing_locations(n)
            return [store, rec, new_ret]
        return node

    def visit_Expr(self, node: ast.Expr):
        self.generic_visit(node)
        if (isinstance(node.value, ast.Call)
                and isinstance(getattr(node.value, 'func', None), ast.Name)
                and getattr(node.value.func, 'id', '') == '__fm_record__'):
            return node
        rec = self._wrap_stmt("expr", getattr(node, 'lineno', 0))
        return [node, rec]

    def visit_Assert(self, node: ast.Assert):
        self.generic_visit(node)
        val_expr = ast.Call(
            func=ast.Name(id="str", ctx=ast.Load()),
            args=[node.test],
            keywords=[],
        )
        rec = self._wrap_stmt("assert", node.lineno, "", val_expr)
        ast.fix_missing_locations(rec)
        return [rec, node]

    def visit_If(self, node: ast.If):
        self.generic_visit(node)
        true_rec = self._wrap_stmt(
            "branch", node.lineno, "",
            ast.Constant(value="true_branch"),
        )
        node.body.insert(0, true_rec)

        if node.orelse:
            else_line = node.orelse[0].lineno if node.orelse else node.lineno
            false_rec = self._wrap_stmt(
                "branch", else_line, "",
                ast.Constant(value="false_branch"),
            )
            node.orelse.insert(0, false_rec)

        ast.fix_missing_locations(node)
        return node

    def visit_Try(self, node: ast.Try):
        self.generic_visit(node)
        try_rec = self._wrap_stmt("expr", node.lineno)
        node.body.insert(0, try_rec)

        for handler in node.handlers:
            if handler.type is None:
                exc_name = "Exception"
            elif isinstance(handler.type, ast.Name):
                exc_name = handler.type.id
            else:
                try:
                    exc_name = ast.unparse(handler.type)
                except (AttributeError, ValueError):
                    exc_name = "Exception"
            h_rec = self._wrap_stmt(
                "exception", handler.lineno, "",
                ast.Constant(value=exc_name),
            )
            handler.body.insert(0, h_rec)

        ast.fix_missing_locations(node)
        return node

    def visit_With(self, node: ast.With):
        self.generic_visit(node)
        rec = self._wrap_stmt("expr", node.lineno)
        node.body.insert(0, rec)
        ast.fix_missing_locations(node)
        return node

    def visit_For(self, node: ast.For):
        self.generic_visit(node)
        rec = self._wrap_stmt("expr", node.lineno)
        node.body.insert(0, rec)
        ast.fix_missing_locations(node)
        return node


_RUNNER_TEMPLATE = string.Template('''\
import sys, json, time, threading, asyncio

_fm_extra_paths = $extra_paths
for _p in reversed(_fm_extra_paths):
    if _p not in sys.path:
        sys.path.insert(0, _p)

$source

_fm_events = []
_fm_start  = time.perf_counter()

def __fm_record__(kind, file, line, func, value=None):
    elapsed = (time.perf_counter() - _fm_start) * 1000.0
    _fm_events.append({
        "kind":       kind,
        "file":       file,
        "line":       line,
        "func":       func,
        "elapsed_ms": round(elapsed, 3),
        "value":      str(value)[:120] if value is not None else None,
        "thread_id":  threading.get_ident(),
    })

_fm_outcome  = "pass"
_fm_error    = None
_fm_t0       = time.perf_counter()

try:
    _fm_fn = $func_name
    if asyncio.iscoroutinefunction(_fm_fn):
        asyncio.run(_fm_fn())
    else:
        _fm_fn()
except AssertionError as _e:
    _fm_outcome = "fail"
    _fm_error   = f"AssertionError: {_e}"
except Exception as _e:
    _fm_outcome = "fail"
    _fm_error   = f"{type(_e).__name__}: {_e}"

_fm_duration = (time.perf_counter() - _fm_t0) * 1000.0

print("__FM_RESULT__:" + json.dumps({
    "run_id":      $run_id,
    "outcome":     _fm_outcome,
    "error":       _fm_error,
    "duration_ms": round(_fm_duration, 3),
    "events":      _fm_events,
}))
''')


def instrument_source(source: str, filename: str) -> tuple[str, bool]:
    tree = ast.parse(textwrap.dedent(source))
    inserter = TraceInserter(filename)
    new_tree = inserter.visit(tree)
    ast.fix_missing_locations(new_tree)
    return ast.unparse(new_tree), inserter.is_async


def run_instrumented(
    source:         str,
    filename:       str,
    test_func_name: str,
    run_id:         int,
    project_root:   str | None = None,
    timeout:        int = 30,
) -> ExecutionTrace:
    try:
        instrumented, _ = instrument_source(source, filename)
    except SyntaxError as e:
        return ExecutionTrace(
            run_id=run_id,
            outcome="fail",
            error=f"SyntaxError during instrumentation: {e}",
        )

    cwd = project_root or os.getcwd()

    extra_paths = list(sys.path)
    if cwd not in extra_paths:
        extra_paths.insert(0, cwd)

    runner_code = _RUNNER_TEMPLATE.substitute(
        source=instrumented,
        func_name=test_func_name,
        run_id=str(run_id),
        extra_paths=repr(extra_paths),
    )

    env = os.environ.copy()
    existing = env.get("PYTHONPATH", "")
    env["PYTHONPATH"] = cwd + (os.pathsep + existing if existing else "")

    tmp_path = None
    try:
        with tempfile.NamedTemporaryFile(
            mode="w", suffix=".py",
            delete=False, encoding="utf-8",
            prefix="flakemark_run_",
        ) as f:
            f.write(runner_code)
            tmp_path = f.name

        proc = subprocess.run(
            [sys.executable, tmp_path],
            capture_output=True,
            text=True,
            timeout=timeout,
            cwd=cwd,
            env=env,
        )

        for line in proc.stdout.splitlines():
            if line.startswith("__FM_RESULT__:"):
                payload = line[len("__FM_RESULT__:"):]
                data = json.loads(payload)
                return ExecutionTrace.from_dict(data)

        stderr_tail = proc.stderr[-500:] if proc.stderr else "(no stderr)"
        return ExecutionTrace(
            run_id=run_id,
            outcome="fail",
            error=(
                f"subprocess exited {proc.returncode} without result. "
                f"stderr: {stderr_tail}"
            ),
        )

    except subprocess.TimeoutExpired:
        return ExecutionTrace(
            run_id=run_id,
            outcome="fail",
            error=f"timed out after {timeout}s",
        )
    except Exception as e:
        return ExecutionTrace(
            run_id=run_id,
            outcome="fail",
            error=f"runner error: {e}",
        )
    finally:
        if tmp_path:
            try:
                os.unlink(tmp_path)
            except OSError:
                pass
