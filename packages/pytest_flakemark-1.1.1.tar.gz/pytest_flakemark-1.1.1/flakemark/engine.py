import os
import ast
import glob
import time
import random
import threading
from pathlib import Path

from flakemark.tracer.instrument import ExecutionTrace, run_instrumented
from flakemark.differ.divergence import DifferentialAnalyser, DivergenceReport


def _find_project_root(start_path: str) -> str:
    markers = {"setup.py", "pyproject.toml", "setup.cfg", ".git", "requirements.txt"}
    current = Path(start_path).resolve()

    if current.is_file():
        current = current.parent

    for _ in range(10):
        if any((current / m).exists() for m in markers):
            return str(current)
        parent = current.parent
        if parent == current:
            break
        current = parent

    return str(Path(start_path).resolve().parent)


class FlakeMark:

    def __init__(
        self,
        runs:         int = 4,
        timeout:      int = 30,
        project_root: str | None = None,
    ) -> None:
        self.runs         = max(runs, 2)
        self.timeout      = timeout
        self.project_root = project_root or os.getcwd()
        self._analyser    = DifferentialAnalyser()

    @classmethod
    def diagnose_source(
        cls,
        source:         str,
        test_func_name: str,
        runs:           int = 4,
        project_root:   str | None = None,
    ) -> DivergenceReport:
        root = project_root or os.getcwd()
        fm = cls(runs=runs, project_root=root)
        return fm._diagnose(source, "<string>", test_func_name)

    @classmethod
    def diagnose_file(
        cls,
        filepath:       str,
        test_func_name: str,
        runs:           int = 4,
        project_root:   str | None = None,
    ) -> DivergenceReport:
        source = Path(filepath).read_text(encoding="utf-8")
        root = project_root or _find_project_root(filepath)
        fm = cls(runs=runs, project_root=root)
        return fm._diagnose(source, filepath, test_func_name)

    @classmethod
    def diagnose_batch(
        cls,
        test_dir: str,
        pattern:  str = "test_*.py",
        runs:     int = 4,
    ) -> dict[str, DivergenceReport]:
        results: dict[str, DivergenceReport] = {}
        project_root = _find_project_root(test_dir)

        files = glob.glob(
            os.path.join(test_dir, "**", pattern),
            recursive=True,
        )

        for fpath in sorted(files):
            source = Path(fpath).read_text(encoding="utf-8")
            try:
                tree = ast.parse(source)
            except SyntaxError:
                continue

            for node in ast.walk(tree):
                if (isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
                        and node.name.startswith("test_")):
                    key = f"{fpath}::{node.name}"
                    try:
                        fm = cls(runs=runs, project_root=project_root)
                        results[key] = fm._diagnose(source, fpath, node.name)
                    except Exception:
                        pass

        return results

    def _diagnose(
        self,
        source:    str,
        filepath:  str,
        func_name: str,
    ) -> DivergenceReport:
        traces = self._collect_traces(source, filepath, func_name)

        passing = [t for t in traces if t.outcome == "pass"]
        failing = [t for t in traces if t.outcome == "fail"]

        if passing and failing:
            trace_a = max(passing, key=lambda t: len(t.events))
            trace_b = max(failing, key=lambda t: len(t.events))
        elif len(traces) >= 2:
            by_dur = sorted(traces, key=lambda t: t.duration_ms)
            trace_a = by_dur[0]
            trace_b = by_dur[-1]
        else:
            empty = ExecutionTrace(run_id=99, outcome="unknown")
            return DivergenceReport(
                trace_a=traces[0] if traces else empty,
                trace_b=empty,
                summary=(
                    "Need at least 2 completed runs. "
                    "Try increasing the timeout."
                ),
            )

        return self._analyser.analyse(trace_a, trace_b)

    def _collect_traces(
        self,
        source:    str,
        filepath:  str,
        func_name: str,
    ) -> list[ExecutionTrace]:
        traces: list[ExecutionTrace | None] = [None] * self.runs
        threads: list[threading.Thread] = []

        def run_one(run_id: int) -> None:
            if run_id > 0:
                time.sleep(random.uniform(0, 0.05))

            traces[run_id] = run_instrumented(
                source=source,
                filename=filepath,
                test_func_name=func_name,
                run_id=run_id,
                project_root=self.project_root,
                timeout=self.timeout,
            )

        for i in range(self.runs):
            t = threading.Thread(target=run_one, args=(i,), daemon=True)
            threads.append(t)

        for t in threads:
            t.start()

        for t in threads:
            t.join(timeout=self.timeout + 5)

        return [t for t in traces if t is not None]
