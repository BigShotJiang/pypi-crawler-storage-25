from dataclasses import dataclass, field
from enum import Enum
from typing import Optional

from flakemark.tracer.instrument import ExecutionTrace, TraceEvent


class DivergenceType(Enum):
    VALUE_MISMATCH    = "value_mismatch"
    TIMING_DELTA      = "timing_delta"
    THREAD_RACE       = "thread_race"
    SEQUENCE_BREAK    = "sequence_break"
    MISSING_EVENT     = "missing_event"
    EARLY_TERMINATION = "early_termination"
    UNKNOWN           = "unknown"


_EXPLANATIONS: dict[DivergenceType, dict[str, str]] = {
    DivergenceType.VALUE_MISMATCH: {
        "cause": "Non-deterministic value — shared mutable state or random source",
        "fix": (
            "Use unittest.mock.patch() to mock the non-deterministic dependency. "
            "Ensure each test run starts with the same state."
        ),
    },
    DivergenceType.TIMING_DELTA: {
        "cause": "Race condition or timing dependency",
        "fix": (
            "Replace time.sleep(N) with threading.Event().wait() "
            "or asyncio.wait_for(). Never hardcode sleep durations in tests."
        ),
    },
    DivergenceType.THREAD_RACE: {
        "cause": "Concurrency race — threads interleaved differently between runs",
        "fix": (
            "Add threading.Lock() around shared resources. "
            "Use thread-safe queues or restructure with async/await."
        ),
    },
    DivergenceType.SEQUENCE_BREAK: {
        "cause": "Test order dependency — dirty state left by another test",
        "fix": (
            "Add pytest fixtures or setUp/tearDown to reset all shared state "
            "before each test run."
        ),
    },
    DivergenceType.MISSING_EVENT: {
        "cause": "Conditional execution — branch depends on non-deterministic external state",
        "fix": (
            "Mock the external dependency that controls the conditional "
            "so it behaves the same on every run."
        ),
    },
    DivergenceType.EARLY_TERMINATION: {
        "cause": "One run terminated early — timeout, crash, or unhandled exception",
        "fix": (
            "Check the error field of the shorter trace. "
            "Add explicit timeouts and handle specific exception types."
        ),
    },
    DivergenceType.UNKNOWN: {
        "cause": "Unknown divergence",
        "fix": "Investigate manually. Add assertions to narrow down the cause.",
    },
}


TIMING_RATIO    = 3.0
TIMING_FLOOR_MS = 50.0
EARLY_TERM_RATIO = 0.5
LOOKAHEAD       = 5
MAX_DIVERGENCES = 8
VALUE_KINDS     = {"assign", "return", "assert"}

_BASE_CONFIDENCE: dict[DivergenceType, float] = {
    DivergenceType.THREAD_RACE:       0.95,
    DivergenceType.TIMING_DELTA:      0.85,
    DivergenceType.VALUE_MISMATCH:    0.80,
    DivergenceType.SEQUENCE_BREAK:    0.70,
    DivergenceType.MISSING_EVENT:     0.60,
    DivergenceType.EARLY_TERMINATION: 0.55,
    DivergenceType.UNKNOWN:           0.20,
}


@dataclass
class DivergencePoint:
    position:        int
    divergence_type: DivergenceType
    event_a:         Optional[TraceEvent]
    event_b:         Optional[TraceEvent]
    detail:          str = ""
    file:            str = ""
    line:            int = 0
    func:            str = ""
    cause:           str = ""
    fix:             str = ""

    def __post_init__(self) -> None:
        ref = self.event_a or self.event_b
        if ref:
            self.file = self.file or ref.file
            self.line = self.line or ref.line
            self.func = self.func or ref.func

        expl = _EXPLANATIONS.get(self.divergence_type, _EXPLANATIONS[DivergenceType.UNKNOWN])
        self.cause = expl["cause"]
        self.fix   = expl["fix"]


@dataclass
class DivergenceReport:
    trace_a:         ExecutionTrace
    trace_b:         ExecutionTrace
    primary:         Optional[DivergencePoint]  = None
    all_divergences: list[DivergencePoint]      = field(default_factory=list)
    summary:         str   = ""
    confidence:      float = 0.0

    def is_found(self) -> bool:
        return self.primary is not None

    def __str__(self) -> str:
        bar = "-" * 56
        if not self.is_found():
            return "\n".join([
                bar,
                "FLAKEMARK - No divergence found",
                bar,
                self.summary or "Both traces are identical.",
                "Test may not be reproducibly flaky with this number of runs.",
                "Try increasing runs= parameter for low-frequency flakes.",
                bar,
            ])

        p = self.primary
        lines = [
            bar,
            "FLAKEMARK - Flaky Test Root Cause Found",
            bar,
            f"File:       {p.file}",
            f"Line:       {p.line}",
            f"Function:   {p.func}",
            f"Type:       {p.divergence_type.value}",
            f"Cause:      {p.cause}",
            "",
            f"Detail:     {p.detail}",
            "",
            f"Fix:        {p.fix}",
            "",
            f"Confidence: {self.confidence:.0%}  |  "
            f"Total divergences: {len(self.all_divergences)}",
            bar,
        ]
        return "\n".join(lines)


class DifferentialAnalyser:

    def analyse(
        self,
        trace_a: ExecutionTrace,
        trace_b: ExecutionTrace,
    ) -> DivergenceReport:
        report = DivergenceReport(trace_a=trace_a, trace_b=trace_b)

        if not trace_a.events and not trace_b.events:
            report.summary = "Both traces empty — instrumentation may have failed."
            return report

        if trace_a.events and trace_b.events:
            len_a, len_b = len(trace_a), len(trace_b)
            smaller, bigger = min(len_a, len_b), max(len_a, len_b)

            if bigger > 0 and (smaller / bigger) < EARLY_TERM_RATIO:
                a_label = f"{trace_a.outcome.capitalize()} run (trace A)"
                b_label = f"{trace_b.outcome.capitalize()} run (trace B)"

                dp = DivergencePoint(
                    position=smaller,
                    divergence_type=DivergenceType.EARLY_TERMINATION,
                    event_a=trace_a.events[-1] if trace_a.events else None,
                    event_b=trace_b.events[-1] if trace_b.events else None,
                    detail=(
                        f"{a_label}: {len_a} events, {trace_a.duration_ms:.0f}ms. "
                        f"{b_label}: {len_b} events, {trace_b.duration_ms:.0f}ms. "
                        f"Error: {trace_b.error or trace_a.error or 'none'}"
                    ),
                )
                report.all_divergences.append(dp)

        tids_a = set(e.thread_id for e in trace_a.events) if trace_a.events else set()
        tids_b = set(e.thread_id for e in trace_b.events) if trace_b.events else set()
        if len(tids_a) <= 1 and len(tids_b) <= 1:
            for trace in (trace_a, trace_b):
                for e in trace.events:
                    e.thread_id = 0

        walk_results = self._walk(trace_a.events, trace_b.events)
        report.all_divergences.extend(walk_results)

        if not report.all_divergences:
            report.summary = (
                "Traces match. Flakiness may come from I/O or external "
                "calls not captured by instrumentation."
            )
            return report

        ranked = sorted(
            report.all_divergences,
            key=lambda d: self._score(d),
            reverse=True,
        )
        report.primary    = ranked[0]
        report.confidence = self._score(ranked[0])
        report.summary = (
            f"{len(ranked)} divergence(s) found. "
            f"Primary: {report.primary.divergence_type.value} "
            f"at {report.primary.file}:{report.primary.line} "
            f"({report.confidence:.0%} confidence)"
        )
        return report

    def _walk(
        self,
        events_a: list[TraceEvent],
        events_b: list[TraceEvent],
    ) -> list[DivergencePoint]:
        divs: list[DivergencePoint] = []
        i = j = pos = 0

        while i < len(events_a) and j < len(events_b):
            a, b = events_a[i], events_b[j]
            key_a = (a.kind, a.file, a.line)
            key_b = (b.kind, b.file, b.line)

            if key_a == key_b:
                dp = self._check_same_op(pos, a, b)
                if dp:
                    divs.append(dp)
                i += 1
                j += 1

            else:
                a_ahead = self._find_ahead(key_a, events_b, j)
                b_ahead = self._find_ahead(key_b, events_a, i)

                if a_ahead:
                    divs.append(DivergencePoint(
                        position=pos,
                        divergence_type=DivergenceType.MISSING_EVENT,
                        event_a=a, event_b=b,
                        detail=(
                            f"Pass run executed {a.kind} at line {a.line}, "
                            f"fail run skipped to {b.kind} at line {b.line}."
                        ),
                    ))
                    j += 1
                elif b_ahead:
                    divs.append(DivergencePoint(
                        position=pos,
                        divergence_type=DivergenceType.MISSING_EVENT,
                        event_a=a, event_b=b,
                        detail=(
                            f"Fail run executed {b.kind} at line {b.line}, "
                            f"pass run skipped to {a.kind} at line {a.line}."
                        ),
                    ))
                    i += 1
                else:
                    divs.append(DivergencePoint(
                        position=pos,
                        divergence_type=DivergenceType.SEQUENCE_BREAK,
                        event_a=a, event_b=b,
                        detail=(
                            f"Pass: {a.kind} at line {a.line}  |  "
                            f"Fail: {b.kind} at line {b.line}. "
                            "Execution paths diverged."
                        ),
                    ))
                    i += 1
                    j += 1

            pos += 1
            if len(divs) >= MAX_DIVERGENCES:
                break

        return divs

    def _check_same_op(
        self, pos: int, a: TraceEvent, b: TraceEvent,
    ) -> Optional[DivergencePoint]:

        if (a.thread_id != 0 and b.thread_id != 0
                and a.thread_id != b.thread_id):
            return DivergencePoint(
                position=pos,
                divergence_type=DivergenceType.THREAD_RACE,
                event_a=a, event_b=b,
                detail=(
                    f"Line {a.line}: thread {a.thread_id} vs "
                    f"thread {b.thread_id}."
                ),
            )

        if a.elapsed_ms > 0 and b.elapsed_ms > 0:
            lo, hi = sorted([a.elapsed_ms, b.elapsed_ms])
            if lo > 0 and hi / lo >= TIMING_RATIO and (hi - lo) >= TIMING_FLOOR_MS:
                return DivergencePoint(
                    position=pos,
                    divergence_type=DivergenceType.TIMING_DELTA,
                    event_a=a, event_b=b,
                    detail=(
                        f"Line {a.line}: {a.elapsed_ms:.1f}ms vs "
                        f"{b.elapsed_ms:.1f}ms — "
                        f"{hi / lo:.0f}x difference."
                    ),
                )

        if (a.kind in VALUE_KINDS
                and a.value is not None and b.value is not None
                and a.value != b.value):
            return DivergencePoint(
                position=pos,
                divergence_type=DivergenceType.VALUE_MISMATCH,
                event_a=a, event_b=b,
                detail=(
                    f"Line {a.line}: got {a.value!r} vs {b.value!r}."
                ),
            )

        return None

    def _find_ahead(
        self, key: tuple, events: list[TraceEvent], start: int,
    ) -> bool:
        end = min(start + LOOKAHEAD, len(events))
        for idx in range(start, end):
            ev = events[idx]
            if (ev.kind, ev.file, ev.line) == key:
                return True
        return False

    def _score(self, dp: DivergencePoint) -> float:
        base = _BASE_CONFIDENCE.get(dp.divergence_type, 0.20)
        penalty = dp.position * 0.02
        boost = 0.03 if (dp.event_a and dp.event_b) else 0.0
        return round(max(0.10, base - penalty + boost), 3)
