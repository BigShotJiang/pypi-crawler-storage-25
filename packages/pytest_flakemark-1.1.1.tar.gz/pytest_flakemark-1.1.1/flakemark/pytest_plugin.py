import inspect
import textwrap
from pathlib import Path

import pytest

from flakemark.engine import FlakeMark


def pytest_addoption(parser) -> None:
    group = parser.getgroup("flakemark", "FLAKEMARK flaky test diagnosis")
    group.addoption(
        "--flakemark-diagnose",
        action="store_true",
        default=False,
        help="Automatically diagnose failing tests for flakiness root cause.",
    )
    group.addoption(
        "--flakemark-runs",
        type=int,
        default=4,
        help="Number of diagnostic runs per test (default: 4).",
    )
    group.addoption(
        "--flakemark-timeout",
        type=int,
        default=30,
        help="Timeout in seconds for each diagnostic run (default: 30).",
    )


@pytest.hookimpl(hookwrapper=True)
def pytest_runtest_makereport(item, call):
    outcome = yield
    rep = outcome.get_result()

    if rep.when != "call" or not rep.failed:
        return

    config = item.config
    if not config.getoption("--flakemark-diagnose", default=False):
        return

    try:
        test_func = item.function
        func_name = test_func.__name__
        filepath  = inspect.getfile(test_func)
        runs      = config.getoption("--flakemark-runs", default=4)
        timeout   = config.getoption("--flakemark-timeout", default=30)

        try:
            source = Path(filepath).read_text(encoding="utf-8")
        except (OSError, UnicodeDecodeError):
            source = textwrap.dedent(inspect.getsource(test_func))

        fm = FlakeMark(runs=runs, timeout=timeout)
        report = fm._diagnose(source, filepath, func_name)

        if report.is_found():
            rep.sections.append(("FLAKEMARK ROOT CAUSE", str(report)))
        else:
            rep.sections.append((
                "FLAKEMARK",
                "No divergence detected. Try --flakemark-runs=10 for low-frequency flakes."
            ))

    except Exception as exc:
        rep.sections.append(("FLAKEMARK ERROR", f"Diagnosis failed: {exc}"))


@pytest.fixture
def flakemark_diagnose(request):
    def _run(source: str, func_name: str, runs: int = 4):
        return FlakeMark.diagnose_source(source, func_name, runs=runs)
    return _run
