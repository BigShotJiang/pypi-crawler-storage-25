use {
    reqwest::Client,
    smbcloud_model::{
        error_codes::ErrorResponse,
        login::{AccountStatus, LoginParams, UserParam},
    },
    smbcloud_network::{environment::Environment, network::request_login},
    smbcloud_networking::{
        constants::{PATH_USERS_SIGN_IN, SMB_USER_AGENT},
        smb_client::SmbClient,
    },
    url_builder::URLBuilder,
};

pub async fn login(
    env: Environment,
    client: (&SmbClient, &str),
    username: String,
    password: String,
) -> Result<AccountStatus, ErrorResponse> {
    let login_params = LoginParams {
        user: UserParam {
            email: username,
            password,
        },
    };
    let builder = Client::new()
        .post(build_smb_login_url(env, client))
        .json(&login_params)
        .header("User-agent", SMB_USER_AGENT);
    request_login(builder).await
}

pub fn build_login_url(env: Environment, client_id: &str, client_secret: &str) -> String {
    let mut url_builder = URLBuilder::new();
    url_builder
        .set_protocol(&env.api_protocol())
        .set_host(&env.api_host())
        .add_param("client_id", client_id)
        .add_param("client_secret", client_secret)
        .add_route(PATH_USERS_SIGN_IN);
    url_builder.build()
}

pub(crate) fn build_smb_login_url(env: Environment, client: (&SmbClient, &str)) -> String {
    build_login_url(env, client.0.id(), client.1)
}
