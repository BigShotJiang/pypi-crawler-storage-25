use {
    crate::{account, mail, project},
    clap::{Parser, Subcommand},
    smbcloud_network::environment::Environment,
    spinners::Spinner,
};

pub struct CommandResult {
    pub spinner: Spinner,
    pub symbol: String,
    pub msg: String,
}

impl CommandResult {
    pub fn stop_and_persist(mut self) {
        self.spinner.stop_and_persist(&self.symbol, self.msg);
    }
}

#[derive(Parser)]
#[clap(author, version, about)]
pub struct Cli {
    /// Environment: dev, production
    #[arg(short, long, env = "ENVIRONMENT", default_value = "production")]
    pub environment: Environment,

    /// Log level: trace, debug, info, warn, error, off
    #[clap(short, long, global = true)]
    pub log_level: Option<String>,

    #[command(subcommand)]
    pub command: Option<Commands>,
}

#[derive(Subcommand)]
pub enum Commands {
    #[clap(about = "Your account info.", display_order = 3)]
    Me {},
    #[clap(
        about = "Deploy project. This is smb main command. Requires an smbCloud account.",
        display_order = 0
    )]
    Deploy {
        /// Name of the sub-project to deploy (for monorepo configs with [[projects]]).
        /// Matches the `name` field in .smb/config.toml. Omit to deploy the root project.
        #[arg(short, long)]
        project: Option<String>,
    },
    #[clap(
        about = "Initialize project. Requires an smbCloud account.",
        display_order = 1
    )]
    Init {},
    #[clap(about = "Login to your account.", display_order = 2)]
    Login {},
    #[clap(about = "Logout from your account.", display_order = 3)]
    Logout {},
    #[clap(about = "Manage your account.")]
    Account {
        #[clap(subcommand)]
        command: account::cli::Commands,
    },
    #[clap(about = "Manage your projects.")]
    Project {
        #[clap(subcommand)]
        command: project::cli::Commands,
    },
    #[clap(about = "Manage smbCloud Mail.")]
    Mail {
        #[clap(subcommand)]
        command: mail::cli::Commands,
    },
}
