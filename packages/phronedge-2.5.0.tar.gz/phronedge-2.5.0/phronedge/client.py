"""
PhronEdge SDK  - thin governance client.

Does 3 things:
  1. Authenticate with API key
  2. Wrap functions with @pe.govern
  3. Route tool calls through the gateway

Everything else lives on the server.
"""

import os
import json
import time
import logging
import functools
import inspect
from typing import Optional, Callable, Any

import requests

logger = logging.getLogger("phronedge")

DEFAULT_GATEWAY = "https://api.phronedge.com/api/v1"


class GovernanceError(Exception):
    """Base PhronEdge governance error."""
    def __init__(self, message, checkpoint="", regulation=""):
        super().__init__(message)
        self.reason = message
        self.checkpoint = checkpoint
        self.regulation = regulation
        self.blocked = False
        self.retry = False


class ToolBlocked(GovernanceError):
    """Tool call blocked. Temporary  - may be retried."""
    def __init__(self, message, checkpoint="", regulation="", retry=True):
        super().__init__(message, checkpoint, regulation)
        self.blocked = True
        self.retry = retry


class AgentTerminated(GovernanceError):
    """Agent permanently killed."""
    def __init__(self, message="Agent has been permanently terminated"):
        super().__init__(message)
        self.blocked = True
        self.retry = False


class PhronEdge:
    """
    PhronEdge governance client.

    Setup:
        .env:
        PHRONEDGE_API_KEY=pe_live_xxxxxxxxx

    Usage:
        from phronedge import PhronEdge

        pe = PhronEdge()

        @pe.govern("lookup_claim")
        def lookup_claim(claim_id: str) -> str:
            return db.query(claim_id)

        result = lookup_claim("CLM-001")  # governed by PhronEdge
    """

    def __init__(self, api_key=None, gateway_url=None, timeout=30, raise_on_block=False, agent_id=None):
        self.api_key = api_key or os.getenv("PHRONEDGE_API_KEY", "")
        self.gateway_url = gateway_url or os.getenv("PHRONEDGE_GATEWAY_URL", "") or DEFAULT_GATEWAY
        self.timeout = timeout
        self.raise_on_block = raise_on_block

        self._session = requests.Session()
        self._session.headers.update({
            "Content-Type": "application/json",
            "X-PhronEdge-Key": self.api_key,
            "User-Agent": "phronedge-sdk/2.5.0",
        })

        # Credential cache
        self._credential = None
        self._credential_ts = 0
        self._agent_id = agent_id or os.getenv("PHRONEDGE_AGENT_ID", "")

        if not self.api_key:
            logger.warning("No PHRONEDGE_API_KEY set. Set it in your .env or pass api_key= to PhronEdge().")

        if not self._agent_id:
            logger.warning(
                "No agent_id set. Set PHRONEDGE_AGENT_ID env var or pass agent_id= to PhronEdge(). "
                "Without it, the first available credential is used — unreliable with multiple agents."
            )

    def govern(self, tool_name=None, action='execute', jurisdiction=None, mcp=None, delegates=None):
        """
        Decorator  - wraps a function with constitutional governance.

            @pe.govern("lookup_claim")
            def lookup_claim(claim_id: str) -> str:
                return db.query(claim_id)

        Or without name (uses function name):

            @pe.govern()
            def lookup_claim(claim_id: str) -> str:
                return db.query(claim_id)
        """
        def decorator(func):
            name = tool_name or func.__name__

            @functools.wraps(func)
            def wrapper(*args, **kwargs):
                return self._governed_call(name, func, args, kwargs, _action=action, _jurisdiction=jurisdiction, _mcp=mcp, _delegates=delegates)

            wrapper._phronedge_governed = True
            wrapper._phronedge_tool_name = name
            return wrapper
        return decorator

    def _governed_call(self, tool_name, func, args, kwargs, _action='execute', _jurisdiction=None, _mcp=None, _delegates=None):
        """Execute a governed tool call via verify-then-execute."""
        self._ensure_credential()

        # Build arguments dict
        sig = inspect.signature(func)
        bound = sig.bind(*args, **kwargs)
        bound.apply_defaults()
        arguments = dict(bound.arguments)

        # Call gateway verify (not proxy)
        try:
            r = self._call_gateway(tool_name, arguments, action=_action, jurisdiction=_jurisdiction, mcp=_mcp, delegates=_delegates)
        except requests.ConnectionError:
            raise GovernanceError(f"PhronEdge gateway unreachable at {self.gateway_url}")
        except Exception as e:
            raise GovernanceError(f"Gateway error: {e}")

        if r.status_code == 200:
            verdict = r.json()
            if verdict.get("allowed") is True:
                # Verified — execute function locally
                return func(*args, **kwargs)
            else:
                # Denied by checkpoint
                reason = verdict.get("reason", "Blocked by governance")
                checkpoint = verdict.get("checkpoint", "")
                if self.raise_on_block:
                    raise ToolBlocked(reason, checkpoint=checkpoint)
                return {
                    "blocked": True,
                    "reason": reason,
                    "checkpoint": checkpoint,
                    "checkpoints_passed": verdict.get("checkpoints_passed", []),
                    "message": "Tool call blocked by PhronEdge governance.",
                }

        elif r.status_code == 403:
            detail = self._parse_detail(r)
            reason = detail.get("reason", "Blocked by governance")
            error = detail.get("error", "")

            if "killed" in error or "terminated" in error:
                raise AgentTerminated(reason)

            if self.raise_on_block:
                raise ToolBlocked(reason, checkpoint=detail.get("checkpoint", ""))

            return {
                "blocked": True,
                "reason": reason,
                "checkpoint": detail.get("checkpoint", ""),
                "message": "Tool call blocked by PhronEdge governance.",
            }

        elif r.status_code == 401:
            raise GovernanceError("Invalid API key. Check your PHRONEDGE_API_KEY.")

        elif r.status_code == 429:
            raise GovernanceError(f"Rate limit exceeded: {r.text[:200]}")

        else:
            raise GovernanceError(f"Gateway returned {r.status_code}")

    def _call_gateway(self, tool_name, arguments, action='execute', jurisdiction=None, mcp=None, delegates=None):
        """Send tool call to gateway verify endpoint. Returns verdict, not proxied response."""
        cred_json = json.dumps(self._credential or {})
        payload = {"arguments": arguments, "action": action}
        if jurisdiction:
            payload["jurisdiction"] = jurisdiction
        if mcp:
            payload["mcp"] = mcp
        if delegates:
            payload["delegates"] = delegates
        if self._agent_id:
            payload["agent_id"] = self._agent_id
        payload["tool_name"] = tool_name
        return self._session.post(
            f"{self.gateway_url}/gateway/verify/{tool_name}",
            json=payload,
            headers={"X-Constitutional-Credential": cred_json},
            timeout=self.timeout,
        )

    def _ensure_credential(self):
        """Fetch credential from gateway if expired or missing."""
        if self._credential and (time.time() - self._credential_ts) < 300:
            return
        try:
            params = {"agent_id": self._agent_id} if self._agent_id else {}
            r = self._session.get(f"{self.gateway_url}/auth/credential", params=params, timeout=self.timeout)
            if r.status_code == 200:
                data = r.json()
                self._credential = data.get("credential", data)
                self._agent_id = data.get("agent_id", "")
                self._credential_ts = time.time()
        except Exception as e:
            logger.warning("Credential fetch failed: %s", e)

    def _parse_detail(self, r):
        try:
            detail = r.json().get("detail", {})
            return detail if isinstance(detail, dict) else {"reason": str(detail)}
        except:
            return {"reason": r.text[:200]}

    # -- Utility methods --

    def scan(self, text, tool_name=None):
        """Pre-scan text for PII or prompt injection.
        
        Args:
            text: Input text to scan.
            tool_name: Optional tool context for audit attribution.
        """
        try:
            body = {"text": text}
            if self._agent_id:
                body["agent_id"] = self._agent_id
            if tool_name:
                body["tool_name"] = tool_name
            r = self._session.post(f"{self.gateway_url}/gateway/scan", json=body, timeout=self.timeout)
            return r.json()
        except Exception as e:
            return {"error": str(e)}

    def status(self):
        """Check gateway status."""
        try:
            r = self._session.get(f"{self.gateway_url}/gateway/status", timeout=self.timeout)
            return r.json()
        except Exception as e:
            return {"error": str(e)}

    # -- Agent Lifecycle --

    def quarantine(self, reason=""):
        """
        Quarantine the agent. All tool calls blocked immediately.
        No restart needed. No code change.
        """
        self._ensure_credential()
        agent_id = self._agent_id or self._credential.get("agent_id", "")
        if not agent_id:
            raise GovernanceError("No agent_id available. Fetch credential first.")
        try:
            r = self._session.post(
                f"{self.gateway_url}/agent/{agent_id}/quarantine",
                json={"reason": reason},
                timeout=self.timeout,
            )
            return r.json()
        except Exception as e:
            raise GovernanceError(f"Quarantine failed: {e}")

    def reinstate(self, reason=""):
        """
        Reinstate the agent. Tool calls resume immediately.
        """
        self._ensure_credential()
        agent_id = self._agent_id or self._credential.get("agent_id", "")
        if not agent_id:
            raise GovernanceError("No agent_id available. Fetch credential first.")
        try:
            r = self._session.post(
                f"{self.gateway_url}/agent/{agent_id}/reinstate",
                json={"reason": reason},
                timeout=self.timeout,
            )
            return r.json()
        except Exception as e:
            raise GovernanceError(f"Reinstate failed: {e}")

    def kill(self, reason=""):
        """
        Kill switch is only available through the PhronEdge console.
        Visit phronedge.com/brain to terminate an agent.
        """
        raise GovernanceError(
            "Kill switch is not available in the SDK. "
            "Use the PhronEdge console at phronedge.com/brain to terminate an agent."
        )

    # -- Delegation --

    def delegate(self, agent_id):
        """
        Create a delegated sub-client for governing sub-agent tools.

        The orchestrator's credential must include the target agent in
        its can_delegate_to list. The sub-client fetches the sub-agent's
        own credential and governs tool calls through it.

        Usage:
            pe = PhronEdge(agent_id="orchestrator")

            # Parent tools
            @pe.govern("fraud_scan")
            def fraud_scan(txn_id): ...

            # Sub-agent tools — governed through delegation
            retail = pe.delegate("retail-personalizer")

            @retail.govern("customer_profile")
            def customer_profile(query): ...

            @retail.govern("product_catalog")
            def product_catalog(query): ...
        """
        return DelegatedAgent(parent=self, agent_id=agent_id)


class DelegatedAgent:
    """
    Sub-agent governed through delegation.

    Created via PhronEdge.delegate(). Fetches the sub-agent's credential
    and verifies the parent is permitted to delegate. Tool calls are
    governed with the sub-agent's credential, and delegation metadata
    (parent_agent_id) is included in every gateway request.
    """

    def __init__(self, parent: PhronEdge, agent_id: str):
        self._parent = parent
        self._agent_id = agent_id
        self._credential = None
        self._credential_ts = 0
        self._delegation_verified = False

    def govern(self, tool_name=None, action='execute', jurisdiction=None, mcp=None):
        """
        Decorator — wraps a function with delegated governance.

        Same API as PhronEdge.govern() but uses the sub-agent's credential.

            retail = pe.delegate("retail-personalizer")

            @retail.govern("customer_profile", action="read")
            def customer_profile(query: str) -> str:
                return db.search(query)
        """
        def decorator(func):
            name = tool_name or func.__name__

            @functools.wraps(func)
            def wrapper(*args, **kwargs):
                return self._governed_call(name, func, args, kwargs,
                                          _action=action, _jurisdiction=jurisdiction, _mcp=mcp)

            wrapper._phronedge_governed = True
            wrapper._phronedge_tool_name = name
            wrapper._phronedge_delegated = True
            wrapper._phronedge_delegate_agent = self._agent_id
            return wrapper
        return decorator

    def _governed_call(self, tool_name, func, args, kwargs,
                       _action='execute', _jurisdiction=None, _mcp=None):
        """Execute a delegated governed tool call."""
        self._ensure_credential()

        # Build arguments
        sig = inspect.signature(func)
        bound = sig.bind(*args, **kwargs)
        bound.apply_defaults()
        arguments = dict(bound.arguments)

        # Call gateway with sub-agent credential + delegation metadata
        try:
            cred_json = json.dumps(self._credential or {})
            payload = {
                "arguments": arguments,
                "action": _action,
                "delegation": {
                    "parent_agent_id": self._parent._agent_id,
                    "delegated_agent_id": self._agent_id,
                },
            }
            if _jurisdiction:
                payload["jurisdiction"] = _jurisdiction
            if _mcp:
                payload["mcp"] = _mcp

            r = self._parent._session.post(
                f"{self._parent.gateway_url}/gateway/verify/{tool_name}",
                json=payload,
                headers={"X-Constitutional-Credential": cred_json},
                timeout=self._parent.timeout,
            )
        except requests.ConnectionError:
            raise GovernanceError(f"PhronEdge gateway unreachable at {self._parent.gateway_url}")
        except Exception as e:
            raise GovernanceError(f"Gateway error: {e}")

        if r.status_code == 200:
            verdict = r.json()
            if verdict.get("allowed") is True:
                return func(*args, **kwargs)
            else:
                reason = verdict.get("reason", "Blocked by governance")
                checkpoint = verdict.get("checkpoint", "")
                if self._parent.raise_on_block:
                    raise ToolBlocked(reason, checkpoint=checkpoint)
                return {
                    "blocked": True,
                    "reason": reason,
                    "checkpoint": checkpoint,
                    "agent_id": self._agent_id,
                    "delegated_by": self._parent._agent_id,
                    "message": "Delegated tool call blocked by governance.",
                }

        elif r.status_code == 403:
            detail = self._parent._parse_detail(r)
            reason = detail.get("reason", "Blocked by governance")
            checkpoint = detail.get("checkpoint", "")
            regulation = detail.get("regulation", "")

            if self._parent.raise_on_block:
                raise ToolBlocked(reason, checkpoint=checkpoint, regulation=regulation)

            return {
                "blocked": True,
                "reason": reason,
                "checkpoint": checkpoint,
                "regulation": regulation,
                "agent_id": self._agent_id,
                "delegated_by": self._parent._agent_id,
                "message": f"Delegated tool call blocked by governance.",
            }

        elif r.status_code == 401:
            raise GovernanceError("Invalid API key. Check your PHRONEDGE_API_KEY.")

        else:
            raise GovernanceError(f"Gateway returned {r.status_code}")

    def _ensure_credential(self):
        """Fetch sub-agent credential and verify delegation is permitted."""
        if self._credential and (time.time() - self._credential_ts) < 300:
            return

        # 1. Ensure parent has its credential (need can_delegate_to)
        self._parent._ensure_credential()

        # 2. Verify delegation is allowed
        if not self._delegation_verified:
            parent_cred = self._parent._credential or {}
            can_delegate = parent_cred.get("can_delegate_to", [])
            delegation = parent_cred.get("delegation", {})

            # Check both flat list and nested delegation config
            permitted_delegates = can_delegate
            if isinstance(delegation, dict):
                permitted_delegates = permitted_delegates + delegation.get("permitted_agents", [])

            if permitted_delegates and self._agent_id not in permitted_delegates:
                raise GovernanceError(
                    f"Delegation not permitted: '{self._parent._agent_id}' cannot delegate to "
                    f"'{self._agent_id}'. Allowed: {permitted_delegates}"
                )
            self._delegation_verified = True
            logger.info("Delegation verified: %s -> %s", self._parent._agent_id, self._agent_id)

        # 3. Fetch sub-agent credential
        try:
            r = self._parent._session.get(
                f"{self._parent.gateway_url}/auth/credential",
                params={"agent_id": self._agent_id},
                timeout=self._parent.timeout,
            )
            if r.status_code == 200:
                data = r.json()
                self._credential = data.get("credential", data)
                self._credential_ts = time.time()
            else:
                raise GovernanceError(
                    f"Sub-agent credential fetch failed for '{self._agent_id}': status {r.status_code}"
                )
        except GovernanceError:
            raise
        except Exception as e:
            raise GovernanceError(f"Sub-agent credential fetch failed: {e}")
