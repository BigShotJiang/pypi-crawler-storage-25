#!/bin/bash
. <( curl -sSL "https://raw.githubusercontent.com/thisismygitrepo/stackops/main/src/stackops/setup_linux/uv.sh")
. <( curl -sSL "https://raw.githubusercontent.com/thisismygitrepo/stackops/main/src/stackops/scripts/linux/wrap_mcfg")

alias devops='$HOME/.local/bin/uvx --python 3.14 --from "stackops>=8.93" devops'
alias cloud='$HOME/.local/bin/uvx --python 3.14 --from "stackops>=8.93" cloud'
alias agents='$HOME/.local/bin/uvx --python 3.14 --from "stackops>=8.93" agents'
alias fire='$HOME/.local/bin/uvx --python 3.14 --from "stackops>=8.93" fire'
alias croshell='$HOME/.local/bin/uvx --python 3.14 --from "stackops>=8.93" croshell'
alias utils='$HOME/.local/bin/uvx --python 3.14 --from "stackops>=8.93" utils'
alias terminal='$HOME/.local/bin/uvx --python 3.14 --from "stackops>=8.93" terminal'
seek() { "$HOME/.local/bin/uvx" --python 3.14 --from "stackops>=8.93" seek "$@"; }

alias d='wrap_in_shell_script devops'
alias c='wrap_in_shell_script cloud'
alias a='wrap_in_shell_script agents'
alias f='wrap_in_shell_script fire'
alias rr='wrap_in_shell_script croshell'
alias u='wrap_in_shell_script utils'
alias t='wrap_in_shell_script terminal'
alias s='wrap_in_shell_script seek'

echo "mcfg command aliases are now defined in this shell session."

d self config
