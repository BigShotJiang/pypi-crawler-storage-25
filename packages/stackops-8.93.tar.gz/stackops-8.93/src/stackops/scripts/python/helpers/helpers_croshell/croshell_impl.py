"""Pure Python implementation for croshell command - no typer dependencies."""

from pathlib import Path
from stackops.scripts.python.enums import BACKENDS


def croshell(
    path: str | None,
    project_path: str | None,
    uv_with: str | None,
    backend: BACKENDS,
    profile: str | None,
    frozen: bool
) -> None:
    """Cross-shell command execution."""
    interactivity = "-i"
    user_uv_with_line = "INIT_VALUE_INVALID"
    if uv_with is not None:
        match backend:
            case "ipython":
                user_uv_with_line = f"--with {uv_with},ipython,rich"
            case _:
                user_uv_with_line = f"--with {uv_with}"
    else:
        match backend:
            case "ipython":
                user_uv_with_line = "--with ipython,rich"
            case _:
                user_uv_with_line = ""
    if frozen:
        user_uv_with_line += " --frozen"

    if project_path is not None:
        uv_project_line = f'--project {project_path}'
        uv_python_line = ""
    else:
        uv_project_line = ""
        uv_python_line = "--python 3.14"

    from stackops.scripts.python.helpers.helpers_croshell.crosh import get_read_python_file_pycode
    from stackops.utils.meta import lambda_to_python_script
    from stackops.utils.accessories import randstr
    from stackops.utils.ve import get_ve_path_and_ipython_profile
    import json
    from rich.console import Console
    from rich.panel import Panel
    console = Console()

    ipython_profile: str | None = profile
    if path is not None:
        from stackops.utils.path_helper import get_choice_file
        choice_file = get_choice_file(path=path, suffixes={".*"}, search_root=None)
        if project_path is None:
            ve_path, _ = get_ve_path_and_ipython_profile(choice_file)
            if ve_path is not None:
                ve_path_obj = Path(ve_path)
                uv_project_line = f'--project {ve_path_obj.parent}'
                uv_python_line = ""
        if choice_file.suffix == ".py":
            program = choice_file.read_text(encoding="utf-8")
            text = f"📄 Selected file: {choice_file.name}"
            console.print(Panel(text, title="[bold blue]Info[/bold blue]"))
        else:
            # from stackops.scripts.python.helpers.helpers_croshell.crosh import get_read_data_pycode
            # program = lambda_to_python_script(
            #     lambda: get_read_data_pycode(path=str(choice_file)),
            #     in_global=True, import_module=False
            # )
            from stackops.utils.files import read as read_module
            suffix = Path(path).suffix[1:]
            if suffix == "":
                program = "print('No file extension found. Cannot determine how to read the file.')"
            else:
                reader = read_module.READERS.get(suffix)
                if reader is None:
                    program = f"print('No reader found for files with the .{suffix} extension.')"
                else:
                    reader_name = getattr(reader, "__name__", type(reader).__name__)
                    program = Path(read_module.__file__).read_text(encoding="utf-8")
                    program += f"""
# p = {reader_name}("{str(choice_file)}")
from rich.panel import Panel
from rich.text import Text
from rich.console import Console
from pathlib import Path
console = Console()
p = Path(rf"{choice_file}").absolute()
try:
    dat = read_file(p)
    panel_title = f"📄 Successfully read the file: {{p.name}}"
    console.print(Panel(Text(str(dat), justify="left"), title=panel_title, expand=False))
except Exception as e:
    error_message = f'''❌ ERROR READING FILE\nFile: {{p.name}}\nError: {{e}}'''
    console.print(Panel(Text(error_message, justify="left"), title="Error", expand=False, border_style="red"))

"""
                    # program = lambda_to_python_script(
                    #     lambda: reader(path=choice_file),
                    #     in_global=True, import_module=False
                    # )
            text = f"📄 Reading data from: {choice_file.name}"
            console.print(Panel(text, title="[bold blue]Info[/bold blue]"))
    else:
        choice_file = Path.cwd()
        program = ""

    if Path.home().joinpath("code/stackops").exists() and uv_project_line == "":
        uv_project_line = f'--project "{str(Path.home().joinpath("code/stackops"))}"'

    preprogram = _build_preprogram()

    pyfile = Path.home().joinpath(f"tmp_results/tmp_scripts/python/croshell/{randstr()}/script.py")
    pyfile.parent.mkdir(parents=True, exist_ok=True)
    title = "Reading Data"
    def_code = lambda_to_python_script(
        lambda: get_read_python_file_pycode(path=str(pyfile), title=title),
        in_global=False, import_module=False
    )
    python_program = preprogram + "\n\n" + def_code + program
    pyfile.write_text(python_program, encoding="utf-8")
    ipython_profile = ipython_profile if ipython_profile is not None else "default"

    nb_target = pyfile.with_suffix(".ipynb")
    if backend == "jupyter":
        try:
            nb_path = pyfile.with_suffix(".ipynb")
            nb_content = {
                "cells": [
                    {
                        "cell_type": "code",
                        "metadata": {"language": "python"},
                        "source": [python_program],
                        "outputs": [],
                        "execution_count": None,
                    }
                ],
                "metadata": {},
                "nbformat": 4,
                "nbformat_minor": 5,
            }
            nb_path.write_text(json.dumps(nb_content), encoding="utf-8")
            nb_target = nb_path
        except Exception:
            pass

    fire_line = _build_fire_line(
        file_obj=choice_file,
        pyfile=pyfile,
        nb_target=nb_target,
        backend=backend,
        interactivity=interactivity,
        ipython_profile=ipython_profile,
        uv_python_line=uv_python_line,
        uv_project_line=uv_project_line,
        user_uv_with_line=user_uv_with_line,
        uv_with=uv_with,
    )

    from stackops.utils.code import exit_then_run_shell_script
    exit_then_run_shell_script(fire_line, strict=False)


def _build_preprogram() -> str:
    """Build the preprogram code for croshell."""
    import inspect
    import textwrap
    from typing import Callable

    def get_body_simple_function_no_args(f: Callable[[], None]) -> str:
        return textwrap.dedent("\n".join(inspect.getsource(f).splitlines()[1:]))

    preprogram = """
#%%
"""

    def preprogram_func() -> None:
        try:
            from stackops.utils.files.headers import print_header, print_logo
            print_header()
            from datetime import date
            todays_date = date.today().strftime("%Y-%m-%d")
            if todays_date == "2026-06-14":
                print_logo("Happy Birthday, Ruby! 🎉")
            else:
                # print(todays_date)
                print_logo("StackOps")
        except ImportError:
            print("Croshell: stackops is not installed in the current environment.")
            print("Skipping logo printing and some utilities. Some features may not work as expected.")
    preprogram += get_body_simple_function_no_args(preprogram_func)
    return preprogram


def _build_fire_line(
    file_obj: Path,
    pyfile: Path,
    nb_target: Path,
    backend: BACKENDS,
    interactivity: str,
    ipython_profile: str,
    uv_python_line: str,
    uv_project_line: str,
    user_uv_with_line: str,
    uv_with: str | None,
) -> str:
    """Build the fire line command for croshell."""
    if backend == "visidata":
        if file_obj.suffix == ".json":
            return f"""uv run {uv_python_line} {user_uv_with_line} {uv_project_line} --with visidata vd "{str(file_obj)}" """
        return f"""uv run {uv_python_line} {user_uv_with_line} {uv_project_line} --with visidata,pyarrow vd "{str(file_obj)}" """

    if backend == "marimo":
        if Path.home().joinpath("code/stackops").exists():
            requirements = f"""{user_uv_with_line} {uv_project_line} --with marimo,sqlglot  """
        else:
            requirements = f"""{uv_python_line} {user_uv_with_line} {uv_project_line} --with "marimo,sqlglot,cowsay,stackops[plot]>=8.93" """
        return f"""
cd "{str(pyfile.parent)}"
uv run {uv_python_line} --with "marimo" marimo convert {pyfile.name} -o marimo_nb.py
uv run {requirements} marimo edit --host 0.0.0.0 marimo_nb.py
"""

    if backend == "jupyter":
        if Path.home().joinpath("code/stackops").exists():
            requirements = f"""{user_uv_with_line}  {uv_project_line} --with jupyterlab """
        else:
            requirements = f"""{user_uv_with_line} {uv_project_line} --with "cowsay,stackops[plot]>=8.93" """
        return f"uv run {requirements} jupyter-lab {str(nb_target)}"

    if backend == "vscode":
        user_uv_add = f"uv add {uv_with}" if uv_with is not None else ""
        return f"""
cd "{str(pyfile.parent)}"
uv init {uv_python_line}
uv venv
uv add "cowsay,stackops[plot]>=8.93"
uv add {user_uv_add}
# code serve-web
code --new-window "{str(pyfile)}"
"""

    if backend == "python":
        interpreter = "python"
        profile = ""
    else:
        interpreter = "python -m IPython"
        profile = f" --profile {ipython_profile} --no-banner"
    if Path.home().joinpath("code/stackops").exists():
        ve_line = f"""{user_uv_with_line}  {uv_project_line} """
    else:
        ve_line = f"""{uv_python_line} {user_uv_with_line} {uv_project_line} --with "cowsay,stackops[plot]>=8.93" """
    return f"uv run {ve_line} {interpreter} {interactivity} {profile} {str(pyfile)}"
