"""AGM-R: theorem-minimum reference implementation of the Sagrada capacity triangle.

Public API:
    from agm_r import KnowledgeGraph, Belief, RelationType
    from agm_r.operations import assert_belief, revise, refine, retract, relate
    from agm_r.queries import DISPATCH, revision_count, provenance_chain, ...
    from agm_r.postulates import verify_all_postulates
    from agm_r import epistemic_vector, EpistemicVector
"""
from .types import Belief, KnowledgeGraph, Relation, RelationType, RetractRecord
from .operations import (
    assert_belief, revise, refine, retract, relate, PostulateViolation,
)
from .queries import DISPATCH
from .vectors import EpistemicVector, epistemic_vector, DEFAULT_FRESHNESS_LAMBDA

__all__ = [
    "Belief", "KnowledgeGraph", "Relation", "RelationType", "RetractRecord",
    "assert_belief", "revise", "refine", "retract", "relate",
    "PostulateViolation", "DISPATCH",
    "EpistemicVector", "epistemic_vector", "DEFAULT_FRESHNESS_LAMBDA",
]
