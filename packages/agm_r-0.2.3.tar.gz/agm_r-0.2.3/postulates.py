"""AGM-R postulate checking — the six classes T-M1 proves jointly minimum sufficient.

Each postulate is a predicate over `KnowledgeGraph` states (and sometimes an
applied operation). These correspond 1-1 with the classes in
`Sagrada/AGM/Minimality.lean`.

T-M1 states: any retrieval system attaining information-lossless behaviour on
the graph-aggregative query class Q* must satisfy all six. Drop any one, and
an adversarial operation sequence collapses the query-output entropy for at
least one query type. `tests/test_postulates.py` constructs those adversarial
sequences explicitly and shows each is caught by its corresponding check.
"""
from __future__ import annotations

from .types import Belief, KnowledgeGraph, Relation, RelationType, RetractRecord


# --------------------------------------------------------------------------
# The six postulate classes (Alchourrón–Gärdenfors–Makinson 1985)
#
# Classical AGM (Hansson 1999, §4; Fermé–Hansson 2011) lists eight postulates
# K*1–K*8. T-M1 bundles into six *classes*:
#   (1) Closure               — belief set closed under derivation
#   (2) Success               — asserted belief is added (or replaced)
#   (3) Inclusion             — revision does not add unrelated beliefs
#   (4) Vacuity               — retracting an absent belief is a no-op
#   (5) Consistency           — if input is consistent, output is consistent
#   (6) Supplementation       — K*7 ∧ K*8 (bundled): revisions compose monotonically
# Extensionality (K*6) reduces to Closure under finite-beliefs (T-M1 footnote).
# --------------------------------------------------------------------------


def closure_check(kg: KnowledgeGraph) -> bool:
    """Closure: every belief's `DerivesFrom` chain lies within `kg.beliefs`.

    In the AGM-R simplification, "closed under derivation" means: if B
    `DerivesFrom` C, then C is a belief in the graph. (Classical AGM reasons
    about logical closure; we reason about reference closure, which is the
    operationalisation for a finite-beliefs representation.)"""
    belief_ids = {b.source_id for b in kg.beliefs}
    for r in kg.relations:
        if r.rel_type == RelationType.DERIVES_FROM:
            if r.src_source_id not in belief_ids:
                return False
            if r.dst_source_id not in belief_ids:
                return False
    return True


def success_check(kg_pre: KnowledgeGraph, kg_post: KnowledgeGraph,
                  asserted: Belief) -> bool:
    """Success: if we assert `asserted`, then after the operation,
    `asserted` is in the graph (modulo any consistency-forced supersession)."""
    # Check if the asserted belief (by source_id) is in kg_post
    return any(b.source_id == asserted.source_id for b in kg_post.beliefs)


def inclusion_check(kg_pre: KnowledgeGraph, kg_post: KnowledgeGraph) -> bool:
    """Inclusion: `kg_post` beliefs ⊆ `kg_pre` beliefs ∪ {newly-asserted}.

    Operations may add, may mark-as-retracted, but may not silently synthesise
    beliefs not derivable from pre-state + the applied op. We check this by
    requiring that every `kg_post` belief was either (a) in `kg_pre`, or (b)
    has a matching op-history entry in `kg_post.ops_history \\ kg_pre.ops_history`."""
    pre_ids = {b.source_id for b in kg_pre.beliefs}
    post_ids = {b.source_id for b in kg_post.beliefs}
    new_ids = post_ids - pre_ids
    new_op_entries = kg_post.ops_history[len(kg_pre.ops_history):]
    # Every new belief must be traceable to an assert in the new ops
    for sid in new_ids:
        if not any(f"assert:{sid}" in op for op in new_op_entries):
            return False
    return True


def vacuity_for_retract_check(kg_pre: KnowledgeGraph, kg_post: KnowledgeGraph,
                              retracted_source_id: str) -> bool:
    """Vacuity (for retract): if `retracted_source_id` was NOT in `kg_pre`,
    then `kg_post ≡ kg_pre` (modulo ops_history). Retracting an absent
    belief is a no-op on the belief set.

    Load-bearing for T-C1: Art. 17 compliance requires that a well-formed
    retraction of a never-asserted claim succeeds silently."""
    was_present = any(b.source_id == retracted_source_id for b in kg_pre.beliefs)
    if was_present:
        return True  # vacuity doesn't apply — retract had work to do
    # Not present → belief set must be identical
    pre_ids = {b.source_id for b in kg_pre.beliefs}
    post_ids = {b.source_id for b in kg_post.beliefs}
    return pre_ids == post_ids


def consistency_check(kg: KnowledgeGraph) -> bool:
    """Consistency: no `Revises` relation points at a belief that is also the
    source of an active (non-retracted) belief for the same term.

    Classical AGM's consistency postulate says: if the input is consistent,
    the output is consistent. The operationalisation for a belief graph: a
    revision supersedes its target; the target cannot simultaneously be the
    active belief. AGM-R enforces this by making queries return only
    beliefs not superseded by any Revises edge."""
    retracted = kg._retracted_closure()
    revises_targets = {r.dst_source_id for r in kg.relations
                       if r.rel_type == RelationType.REVISES}
    # For each term, the set of "active" (non-retracted, non-revised) beliefs
    # must be non-contradictory by construction. We check the structural
    # invariant: no belief is simultaneously asserted and revised-away.
    for b in kg.beliefs:
        if b.source_id in retracted:
            continue
        if b.source_id in revises_targets:
            # This belief has been revised-away — any later belief must
            # actually exist in the graph for revision to be well-formed
            revising_beliefs = [r for r in kg.relations
                                if r.rel_type == RelationType.REVISES
                                and r.dst_source_id == b.source_id]
            # At least one revising belief must exist as a belief itself
            if not any(kg.belief_by_source(r.src_source_id) for r in revising_beliefs):
                return False
    return True


def supplementation_check(kg_pre: KnowledgeGraph, kg_post: KnowledgeGraph) -> bool:
    """Supplementation (K*7 ∧ K*8 bundled): revisions compose monotonically.

    In the finite-belief operational setting: if op1 and op2 are both
    applied in order, the result is the same as op1 then op2 on
    `kg_pre`. AGM-R operations are pure functions, so this is true by
    construction. We verify by checking ops_history is a strict prefix
    extension."""
    pre_history = kg_pre.ops_history
    post_history = kg_post.ops_history
    if len(post_history) < len(pre_history):
        return False
    return post_history[:len(pre_history)] == pre_history


# --------------------------------------------------------------------------
# Aggregate verification
# --------------------------------------------------------------------------


def verify_all_postulates(kg_pre: KnowledgeGraph, kg_post: KnowledgeGraph,
                          operation_kind: str,
                          asserted: Belief | None = None,
                          retracted_source_id: str | None = None) -> dict[str, bool]:
    """Verify all six AGM postulate classes on a (pre, post, op) triple.

    Returns a dict mapping postulate name → True/False.
    AGM-R operations call this as a post-condition; any False is a bug in the
    operation implementation, not in the postulate check. Tests drop specific
    postulates and show the corresponding empirical failure (T-M1 ablation)."""
    results = {
        "closure": closure_check(kg_post),
        "inclusion": inclusion_check(kg_pre, kg_post),
        "consistency": consistency_check(kg_post),
        "supplementation": supplementation_check(kg_pre, kg_post),
    }
    if operation_kind == "assert" and asserted is not None:
        results["success"] = success_check(kg_pre, kg_post, asserted)
    if operation_kind == "retract" and retracted_source_id is not None:
        results["vacuity_for_retract"] = vacuity_for_retract_check(
            kg_pre, kg_post, retracted_source_id)
    return results
