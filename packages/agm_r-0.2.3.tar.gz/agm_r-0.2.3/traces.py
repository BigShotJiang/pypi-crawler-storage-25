"""AGM-R operational-trace emitter.

Every structural-query invocation can emit a typed `QueryTrace`:

    (query_type, input_kg_hash, ops_invoked, kwargs, output_answer, timestamp)

Traces are the operational ground truth Paper 1's §6 cites: every measured
answer has a trace that can be independently verified by re-running the
(deterministic) query against the hashed KG state. The format is JSONL so
the `.crux` verifier in `sagrada_retriever/verify_crux.py` can consume it
unchanged.

Ops_invoked is human-readable (e.g. `filter_beliefs[term]`, `count`,
`sort[timestamp]`); it documents the composition of Σ-primitives + ordinary
list operations the query kernel used. For a formal verification of
composition equivalence, cross-reference the Lean `CompositionWitness`
constructor in `Sagrada/Info/RetrievalAchievability.lean`.
"""
from __future__ import annotations

import hashlib
import json
import pathlib
import time
from dataclasses import dataclass
from typing import Any, Iterable, Mapping

from .types import KnowledgeGraph
from .queries import DISPATCH


# Transparent op-sequence for every query in DISPATCH. Readers can cross-check
# against `queries.py` line-by-line.
QUERY_OPS: dict[str, tuple[str, ...]] = {
    "revision_count":     ("filter_beliefs[term]", "count"),
    "revision_index":     ("filter_beliefs[term]", "sort[timestamp]", "index[k]"),
    "edit_diff":          ("filter_beliefs[term]", "sort[timestamp]",
                           "pairwise_diff[claim_text]", "index[occurrence]"),
    "contradiction":      ("filter_beliefs[term]", "sort[timestamp]",
                           "pairwise_diff[claim_text]"),
    "corroboration":      ("filter_beliefs[term]", "sort[timestamp]",
                           "project[source_id]"),
    "temporal_agg":       ("filter_beliefs[term]", "temporal[window_days]"),
    "negation_existence": ("filter_beliefs[term]", "sort[timestamp]",
                           "any_pairwise_diff[claim_text]"),
    "provenance_chain":   ("filter_beliefs[term]", "sort[timestamp]",
                           "project[source_id,author,timestamp]"),
}


@dataclass(frozen=True)
class QueryTrace:
    """One row of the trace log. Re-runnable against a matching KG hash."""
    query_type: str
    input_kg_hash: str
    ops_invoked: tuple[str, ...]
    kwargs: dict
    output_answer: str
    timestamp: str  # ISO-8601 (UTC) when the query ran

    def to_json(self) -> dict:
        return {
            "query_type": self.query_type,
            "input_kg_hash": self.input_kg_hash,
            "ops_invoked": list(self.ops_invoked),
            "kwargs": self.kwargs,
            "output_answer": self.output_answer,
            "timestamp": self.timestamp,
        }

    @classmethod
    def from_json(cls, d: Mapping[str, Any]) -> "QueryTrace":
        return cls(
            query_type=d["query_type"],
            input_kg_hash=d["input_kg_hash"],
            ops_invoked=tuple(d["ops_invoked"]),
            kwargs=dict(d["kwargs"]),
            output_answer=d["output_answer"],
            timestamp=d["timestamp"],
        )


def kg_hash(kg: KnowledgeGraph) -> str:
    """Deterministic canonical SHA-256 hash of a KG state.

    Two KGs with the same (beliefs, relations, retracts, ops_history) produce
    the same hash; any change produces a different hash. Independent of
    insertion order.
    """
    data = {
        "beliefs": sorted(
            [
                {"term": b.term, "source_id": b.source_id,
                 "claim_text": b.claim_text, "timestamp": b.timestamp,
                 "author": b.author}
                for b in kg.beliefs
            ],
            key=lambda d: d["source_id"],
        ),
        "relations": sorted(
            [
                {"src": r.src_source_id, "dst": r.dst_source_id,
                 "type": r.rel_type.value}
                for r in kg.relations
            ],
            key=lambda d: (d["src"], d["dst"], d["type"]),
        ),
        "retracts": sorted(
            [
                {"source_id": r.source_id,
                 "retraction_time": r.retraction_time}
                for r in kg.retracts
            ],
            key=lambda d: d["source_id"],
        ),
        "ops_history": list(kg.ops_history),
    }
    canonical = json.dumps(data, sort_keys=True, separators=(",", ":"),
                           ensure_ascii=False)
    return hashlib.sha256(canonical.encode("utf-8")).hexdigest()


def traced_query(kg: KnowledgeGraph, query_type: str,
                 **kwargs: Any) -> tuple[str, QueryTrace]:
    """Run a structural query (from DISPATCH) and emit a typed trace.

    Returns `(answer, trace)`. The trace can be written to JSONL via
    `dump_traces` and later verified via `verify_trace`.

    Raises:
        ValueError if `query_type` is not in DISPATCH.
    """
    if query_type not in DISPATCH:
        raise ValueError(f"unknown query_type '{query_type}'; "
                          f"expected one of {sorted(DISPATCH)}")
    fn = DISPATCH[query_type]
    ans = fn(kg, **kwargs)
    trace = QueryTrace(
        query_type=query_type,
        input_kg_hash=kg_hash(kg),
        ops_invoked=QUERY_OPS[query_type],
        kwargs=dict(kwargs),
        output_answer=str(ans),
        timestamp=time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
    )
    return ans, trace


def emit_trace(query_type: str, kg: KnowledgeGraph,
               ops_invoked: tuple[str, ...], kwargs: dict,
               output_answer: str) -> QueryTrace:
    """Build a QueryTrace for a query outside DISPATCH (e.g. `impact_radius`
    from sigma.py). The caller supplies the op-sequence explicitly; everything
    else is derived from the KG and the answer.
    """
    return QueryTrace(
        query_type=query_type,
        input_kg_hash=kg_hash(kg),
        ops_invoked=ops_invoked,
        kwargs=dict(kwargs),
        output_answer=str(output_answer),
        timestamp=time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
    )


def dump_traces(traces: Iterable[QueryTrace], path: str | pathlib.Path) -> None:
    """Write traces to a JSONL file. Creates parent directories as needed."""
    p = pathlib.Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    with p.open("w") as f:
        for t in traces:
            f.write(json.dumps(t.to_json(), ensure_ascii=False) + "\n")


def load_traces(path: str | pathlib.Path) -> list[QueryTrace]:
    """Read traces from a JSONL file."""
    p = pathlib.Path(path)
    out: list[QueryTrace] = []
    with p.open() as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            out.append(QueryTrace.from_json(json.loads(line)))
    return out


def verify_trace(trace: QueryTrace, kg: KnowledgeGraph) -> bool:
    """Verify that `kg` reproduces `trace.output_answer` for DISPATCH queries.

    Returns True iff the KG hash matches AND re-running the query yields an
    identical answer string. For non-DISPATCH queries (emitted via
    `emit_trace`), this function only verifies the KG hash — callers with
    custom query kernels must re-run and compare themselves.
    """
    if kg_hash(kg) != trace.input_kg_hash:
        return False
    if trace.query_type not in DISPATCH:
        return True  # hash match is the only automated check we can do
    fn = DISPATCH[trace.query_type]
    ans = fn(kg, **trace.kwargs)
    return str(ans) == trace.output_answer
