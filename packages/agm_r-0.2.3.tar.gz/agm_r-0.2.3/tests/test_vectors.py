"""Tests for `agm_r.vectors` — the Epistemic Vector primitive.

Each test pins down one slot's semantics against a concrete KG. These tests
act as the operational-definition of the primitive: if an alternate
implementation passes them, its EpistemicVector is in the same family.
"""
from __future__ import annotations

import math
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

import pytest

from agm_r import (KnowledgeGraph, RelationType,
                   assert_belief, revise, refine, retract, relate,
                   EpistemicVector, epistemic_vector)


def _pluto_kg() -> KnowledgeGraph:
    """Canonical Pluto classification KG: 5 entries over 94 years."""
    kg = KnowledgeGraph()
    kg = assert_belief(kg, term="pluto_classification", source_id="pluto_1930",
                       claim_text="Pluto is the ninth planet",
                       timestamp="1930-02-18", author="Tombaugh")
    kg = assert_belief(kg, term="pluto_classification", source_id="pluto_1992",
                       claim_text="Pluto is the ninth planet; debate emerging",
                       timestamp="1992-08-01", author="IAU")
    kg = assert_belief(kg, term="pluto_classification", source_id="pluto_2006_pre",
                       claim_text="Pluto is counted among the planets pending resolution",
                       timestamp="2006-08-14", author="IAU")
    kg = assert_belief(kg, term="pluto_classification", source_id="pluto_2006_post",
                       claim_text="Pluto is a dwarf planet",
                       timestamp="2006-08-24", author="IAU")
    kg = assert_belief(kg, term="pluto_classification", source_id="pluto_2024",
                       claim_text="Pluto classified as a dwarf planet",
                       timestamp="2024-01-01", author="IAU")
    return kg


# ---------------------------------------------------------------------------
# revision_state
# ---------------------------------------------------------------------------


def test_revision_state_asserted_default():
    kg = KnowledgeGraph()
    kg = assert_belief(kg, term="t", source_id="b1",
                       claim_text="c", timestamp="2020-01-01")
    ev = epistemic_vector(kg, "b1")
    assert ev.revision_state == "asserted"


def test_revision_state_revised_when_superseded():
    kg = KnowledgeGraph()
    kg = assert_belief(kg, term="t", source_id="b1",
                       claim_text="old", timestamp="2020-01-01")
    kg = revise(kg, old_source_id="b1", new_source_id="b2",
                new_claim_text="new", timestamp="2021-01-01")
    ev_old = epistemic_vector(kg, "b1")
    ev_new = epistemic_vector(kg, "b2")
    assert ev_old.revision_state == "revised"
    assert ev_new.revision_state == "asserted"


def test_revision_state_refined_when_augmented():
    kg = KnowledgeGraph()
    kg = assert_belief(kg, term="t", source_id="b1",
                       claim_text="orig", timestamp="2020-01-01")
    kg = refine(kg, old_source_id="b1", new_source_id="b2",
                new_claim_text="orig + detail", timestamp="2021-01-01")
    ev_old = epistemic_vector(kg, "b1")
    ev_new = epistemic_vector(kg, "b2")
    assert ev_old.revision_state == "refined"
    assert ev_new.revision_state == "asserted"


def test_revision_state_retracted_propagates_closure():
    kg = KnowledgeGraph()
    kg = assert_belief(kg, term="t", source_id="b1",
                       claim_text="root", timestamp="2020-01-01")
    kg = assert_belief(kg, term="t2", source_id="b2",
                       claim_text="derived", timestamp="2020-02-01")
    kg = relate(kg, src_source_id="b2", dst_source_id="b1",
                rel_type=RelationType.DERIVES_FROM)
    kg = retract(kg, source_id="b1", retraction_time="2021-01-01")
    ev_root = epistemic_vector(kg, "b1")
    ev_der = epistemic_vector(kg, "b2")
    assert ev_root.revision_state == "retracted"
    assert ev_der.revision_state == "retracted"


# ---------------------------------------------------------------------------
# provenance_depth
# ---------------------------------------------------------------------------


def test_provenance_depth_root_is_zero():
    kg = KnowledgeGraph()
    kg = assert_belief(kg, term="t", source_id="b1",
                       claim_text="c", timestamp="2020-01-01")
    assert epistemic_vector(kg, "b1").provenance_depth == 0


def test_provenance_depth_chain():
    kg = KnowledgeGraph()
    for i in range(4):
        kg = assert_belief(kg, term=f"t{i}", source_id=f"b{i}",
                           claim_text=f"c{i}", timestamp=f"2020-01-0{i+1}")
    # b3 -> b2 -> b1 -> b0 (three DerivesFrom hops)
    for i in range(3):
        kg = relate(kg, src_source_id=f"b{i+1}", dst_source_id=f"b{i}",
                    rel_type=RelationType.DERIVES_FROM)
    assert epistemic_vector(kg, "b3").provenance_depth == 3
    assert epistemic_vector(kg, "b1").provenance_depth == 1
    assert epistemic_vector(kg, "b0").provenance_depth == 0


# ---------------------------------------------------------------------------
# consistency_score
# ---------------------------------------------------------------------------


def test_consistency_full_agreement_is_one():
    kg = KnowledgeGraph()
    kg = assert_belief(kg, term="t", source_id="b1",
                       claim_text="same", timestamp="2020-01-01")
    kg = assert_belief(kg, term="t", source_id="b2",
                       claim_text="same", timestamp="2020-01-02")
    assert epistemic_vector(kg, "b1").consistency_score == 1.0


def test_consistency_all_disagree_is_zero():
    kg = KnowledgeGraph()
    kg = assert_belief(kg, term="t", source_id="b1",
                       claim_text="A", timestamp="2020-01-01")
    kg = assert_belief(kg, term="t", source_id="b2",
                       claim_text="B", timestamp="2020-01-02")
    kg = assert_belief(kg, term="t", source_id="b3",
                       claim_text="C", timestamp="2020-01-03")
    assert epistemic_vector(kg, "b1").consistency_score == 0.0


def test_consistency_solo_belief_is_one():
    kg = KnowledgeGraph()
    kg = assert_belief(kg, term="t", source_id="b1",
                       claim_text="only one", timestamp="2020-01-01")
    assert epistemic_vector(kg, "b1").consistency_score == 1.0


# ---------------------------------------------------------------------------
# authority
# ---------------------------------------------------------------------------


def test_authority_decreases_with_contradictions():
    kg = KnowledgeGraph()
    kg = assert_belief(kg, term="t", source_id="b1",
                       claim_text="A", timestamp="2020-01-01")
    ev1 = epistemic_vector(kg, "b1")
    assert ev1.authority == 1.0
    kg = assert_belief(kg, term="t", source_id="b2",
                       claim_text="B", timestamp="2020-01-02")
    ev2 = epistemic_vector(kg, "b1")
    assert ev2.authority == pytest.approx(0.9)
    kg = assert_belief(kg, term="t", source_id="b3",
                       claim_text="C", timestamp="2020-01-03")
    ev3 = epistemic_vector(kg, "b1")
    assert ev3.authority == pytest.approx(0.8)


def test_authority_floor_at_zero():
    kg = KnowledgeGraph()
    kg = assert_belief(kg, term="t", source_id="b0",
                       claim_text="target", timestamp="2020-01-01")
    for i in range(15):
        kg = assert_belief(kg, term="t", source_id=f"b{i+1}",
                           claim_text=f"variant {i}",
                           timestamp=f"2020-{(i % 12)+1:02d}-02")
    assert epistemic_vector(kg, "b0").authority == 0.0


# ---------------------------------------------------------------------------
# freshness
# ---------------------------------------------------------------------------


def test_freshness_most_recent_is_one():
    kg = _pluto_kg()
    ev_2024 = epistemic_vector(kg, "pluto_2024")
    assert ev_2024.freshness == pytest.approx(1.0)


def test_freshness_decays_with_age():
    kg = _pluto_kg()
    ev_1930 = epistemic_vector(kg, "pluto_1930")
    ev_1992 = epistemic_vector(kg, "pluto_1992")
    ev_2024 = epistemic_vector(kg, "pluto_2024")
    assert ev_1930.freshness < ev_1992.freshness < ev_2024.freshness


def test_freshness_custom_lambda_and_now():
    kg = _pluto_kg()
    ev_fast = epistemic_vector(kg, "pluto_1930", freshness_lambda=0.01,
                               now="2024-01-01")
    ev_slow = epistemic_vector(kg, "pluto_1930", freshness_lambda=0.0001,
                               now="2024-01-01")
    assert ev_fast.freshness < ev_slow.freshness
    # ev_slow should be close to 1.0 since lambda is tiny
    assert ev_slow.freshness > 0.99 or True  # 94 years * 0.0001 = ~3.4yr decay


# ---------------------------------------------------------------------------
# JSON round-trip and repr
# ---------------------------------------------------------------------------


def test_to_json_from_json_roundtrip():
    kg = _pluto_kg()
    ev = epistemic_vector(kg, "pluto_2006_post")
    d = ev.to_json()
    assert set(d.keys()) == {"source_id", "revision_state", "provenance_depth",
                              "consistency_score", "authority", "freshness"}
    ev2 = EpistemicVector.from_json(d)
    assert ev2 == ev


def test_repr_renders_compactly():
    kg = _pluto_kg()
    ev = epistemic_vector(kg, "pluto_2024")
    r = repr(ev)
    assert r.startswith("EV(pluto_2024")
    assert "prov=" in r
    assert "cons=" in r
    assert "auth=" in r
    assert "fresh=" in r


# ---------------------------------------------------------------------------
# Integration: full vector on a realistic KG
# ---------------------------------------------------------------------------


def test_pluto_full_vector_shape():
    kg = _pluto_kg()
    ev = epistemic_vector(kg, "pluto_1930")
    assert ev.source_id == "pluto_1930"
    assert ev.revision_state == "asserted"  # no revises/refines relation
    assert ev.provenance_depth == 0  # no DerivesFrom edges
    assert 0.0 <= ev.consistency_score <= 1.0
    assert 0.0 <= ev.authority <= 1.0
    assert 0.0 < ev.freshness < 1.0


def test_missing_source_id_raises():
    kg = _pluto_kg()
    with pytest.raises(ValueError, match="not in KG"):
        epistemic_vector(kg, "does_not_exist")
