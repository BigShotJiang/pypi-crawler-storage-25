"""Tests for `agm_r.traces` — the operational-trace emitter."""
from __future__ import annotations

import json
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

import pytest

from agm_r import (KnowledgeGraph, RelationType,
                   assert_belief, revise, refine, retract, relate)
from agm_r.traces import (
    QueryTrace, traced_query, emit_trace, kg_hash,
    dump_traces, load_traces, verify_trace,
)


def _pluto_kg() -> KnowledgeGraph:
    kg = KnowledgeGraph()
    kg = assert_belief(kg, term="pluto_classification", source_id="pluto_1930",
                       claim_text="Pluto is the ninth planet",
                       timestamp="1930-02-18", author="Tombaugh")
    kg = assert_belief(kg, term="pluto_classification", source_id="pluto_2006",
                       claim_text="Pluto is a dwarf planet",
                       timestamp="2006-08-24", author="IAU")
    return kg


# ---------------------------------------------------------------------------
# kg_hash determinism
# ---------------------------------------------------------------------------


def test_kg_hash_deterministic():
    kg1 = _pluto_kg()
    kg2 = _pluto_kg()
    assert kg_hash(kg1) == kg_hash(kg2)


def test_kg_hash_changes_on_new_belief():
    kg = _pluto_kg()
    h1 = kg_hash(kg)
    kg = assert_belief(kg, term="pluto_classification", source_id="pluto_2024",
                       claim_text="dwarf planet (reaffirmed)",
                       timestamp="2024-01-01")
    h2 = kg_hash(kg)
    assert h1 != h2


def test_kg_hash_changes_on_retract():
    kg = _pluto_kg()
    h1 = kg_hash(kg)
    kg = retract(kg, source_id="pluto_1930", retraction_time="2020-01-01")
    h2 = kg_hash(kg)
    assert h1 != h2


# ---------------------------------------------------------------------------
# traced_query (DISPATCH queries)
# ---------------------------------------------------------------------------


def test_traced_query_revision_count():
    kg = _pluto_kg()
    ans, trace = traced_query(kg, "revision_count", term="pluto_classification")
    assert ans == "2"
    assert trace.query_type == "revision_count"
    assert trace.output_answer == "2"
    assert trace.ops_invoked == ("filter_beliefs[term]", "count")
    assert trace.input_kg_hash == kg_hash(kg)
    assert trace.kwargs == {"term": "pluto_classification"}


def test_traced_query_temporal_agg():
    kg = _pluto_kg()
    ans, trace = traced_query(kg, "temporal_agg",
                              term="pluto_classification", window_days=365)
    assert trace.ops_invoked == ("filter_beliefs[term]", "temporal[window_days]")
    assert trace.kwargs == {"term": "pluto_classification", "window_days": 365}


def test_traced_query_raises_for_unknown():
    kg = _pluto_kg()
    with pytest.raises(ValueError, match="unknown query_type"):
        traced_query(kg, "not_a_real_query", term="x")


# ---------------------------------------------------------------------------
# emit_trace (non-DISPATCH queries)
# ---------------------------------------------------------------------------


def test_emit_trace_custom_query():
    kg = _pluto_kg()
    trace = emit_trace(
        query_type="impact_radius",
        kg=kg,
        ops_invoked=("filter_relations[DERIVES_FROM]", "bfs_reverse"),
        kwargs={"root_source_id": "pluto_1930"},
        output_answer="[]",
    )
    assert trace.query_type == "impact_radius"
    assert trace.input_kg_hash == kg_hash(kg)
    assert trace.output_answer == "[]"


# ---------------------------------------------------------------------------
# JSONL round-trip + verify_trace
# ---------------------------------------------------------------------------


def test_dump_and_load_roundtrip():
    kg = _pluto_kg()
    _, t1 = traced_query(kg, "revision_count", term="pluto_classification")
    _, t2 = traced_query(kg, "corroboration", term="pluto_classification")
    with tempfile.TemporaryDirectory() as td:
        path = Path(td) / "traces.jsonl"
        dump_traces([t1, t2], path)
        loaded = load_traces(path)
    assert len(loaded) == 2
    assert loaded[0] == t1
    assert loaded[1] == t2


def test_verify_trace_passes_on_same_kg():
    kg = _pluto_kg()
    _, trace = traced_query(kg, "revision_count", term="pluto_classification")
    assert verify_trace(trace, kg) is True


def test_verify_trace_fails_on_different_kg():
    kg = _pluto_kg()
    _, trace = traced_query(kg, "revision_count", term="pluto_classification")
    kg2 = assert_belief(kg, term="pluto_classification", source_id="pluto_2024",
                        claim_text="dwarf planet", timestamp="2024-01-01")
    assert verify_trace(trace, kg2) is False


def test_verify_trace_non_dispatch_hash_only():
    """emit_trace'd traces only verify via hash match, not answer replay."""
    kg = _pluto_kg()
    trace = emit_trace(
        query_type="impact_radius",
        kg=kg,
        ops_invoked=("custom_op",),
        kwargs={"x": 1},
        output_answer="anything",
    )
    assert verify_trace(trace, kg) is True
    kg2 = retract(kg, source_id="pluto_1930", retraction_time="2020-01-01")
    assert verify_trace(trace, kg2) is False
