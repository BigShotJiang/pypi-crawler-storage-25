"""End-to-end smoke tests for AGM-R. Each test corresponds to a specific
theorem artifact — pass/fail status is the empirical instantiation of the
theorem on a concrete example."""
from __future__ import annotations

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from agm_r import (KnowledgeGraph, RelationType, assert_belief, revise,
                   refine, retract, relate, PostulateViolation, DISPATCH)
from agm_r.queries import (revision_count, revision_index, edit_diff,
                            contradiction, corroboration, temporal_agg,
                            negation_existence, provenance_chain)
from agm_r.postulates import verify_all_postulates


def _pluto_kg() -> KnowledgeGraph:
    """Construct the canonical Pluto classification KG (5 entries over 94 years)."""
    kg = KnowledgeGraph()
    kg = assert_belief(kg, term="pluto_classification", source_id="pluto_1930",
                       claim_text="Pluto is the ninth planet",
                       timestamp="1930-02-18", author="Tombaugh")
    kg = assert_belief(kg, term="pluto_classification", source_id="pluto_1992",
                       claim_text="Pluto is the ninth planet; debate emerging",
                       timestamp="1992-08-01", author="IAU")
    kg = assert_belief(kg, term="pluto_classification", source_id="pluto_2006_pre",
                       claim_text="Pluto is counted among the planets pending resolution",
                       timestamp="2006-08-14", author="IAU")
    kg = assert_belief(kg, term="pluto_classification", source_id="pluto_2006_post",
                       claim_text="Pluto is a dwarf planet",
                       timestamp="2006-08-24", author="IAU")
    kg = assert_belief(kg, term="pluto_classification", source_id="pluto_2024",
                       claim_text="Pluto classified as a dwarf planet",
                       timestamp="2024-01-01", author="IAU")
    return kg


def test_revision_count():
    kg = _pluto_kg()
    assert revision_count(kg, term="pluto_classification") == "5"


def test_revision_index():
    kg = _pluto_kg()
    out = revision_index(kg, term="pluto_classification", k=2)
    assert "pluto_1992" in out


def test_contradiction_detected():
    kg = _pluto_kg()
    out = contradiction(kg, term="pluto_classification")
    assert "Yes" in out
    assert "pluto_2006_pre" in out or "pluto_2006_post" in out


def test_corroboration():
    kg = _pluto_kg()
    out = corroboration(kg, term="pluto_classification")
    assert "pluto_1930" in out
    assert "pluto_2024" in out


def test_temporal_agg():
    kg = _pluto_kg()
    # 2006_pre and 2006_post are 10 days apart — max window count = 2
    assert temporal_agg(kg, term="pluto_classification", window_days=90) == "2"


def test_negation_existence():
    kg = _pluto_kg()
    assert negation_existence(kg, term="pluto_classification") == "yes"


def test_provenance_chain():
    kg = _pluto_kg()
    out = provenance_chain(kg, term="pluto_classification")
    assert "Tombaugh" in out
    assert "pluto_1930" in out
    assert "pluto_2024" in out


def test_retract_vacuity():
    """T-C1 Vacuity: retracting an absent belief is a no-op on the belief set."""
    kg = _pluto_kg()
    pre_ids = {b.source_id for b in kg.beliefs}
    kg2 = retract(kg, source_id="nonexistent_source", retraction_time="2025-01-01")
    post_ids = {b.source_id for b in kg2.beliefs}
    assert pre_ids == post_ids
    # ops_history should still record the retract op
    assert kg2.ops_history[-1] == "retract:nonexistent_source"


def test_retract_closure_propagation():
    """T-C1 companion: retracting a belief implicitly retracts its DerivesFrom descendants."""
    kg = KnowledgeGraph()
    kg = assert_belief(kg, term="X", source_id="a", claim_text="A",
                       timestamp="2020-01-01")
    kg = assert_belief(kg, term="Y", source_id="b", claim_text="B derived from A",
                       timestamp="2020-02-01")
    kg = relate(kg, src_source_id="b", dst_source_id="a",
                rel_type=RelationType.DERIVES_FROM)
    # Retract 'a' → 'b' is implicitly retracted per T-C1 closure propagation
    kg = retract(kg, source_id="a", retraction_time="2020-03-01")
    assert revision_count(kg, term="X") == "0"
    assert revision_count(kg, term="Y") == "0", "DerivesFrom descendant should be implicitly retracted"


def test_all_postulates_pass_on_clean_ops():
    """Every operation on the Pluto KG should maintain all six postulates."""
    kg = KnowledgeGraph()
    kg1 = assert_belief(kg, term="pluto_classification", source_id="pluto_1930",
                        claim_text="Pluto is the ninth planet",
                        timestamp="1930-02-18")
    results = verify_all_postulates(kg, kg1, operation_kind="assert",
                                    asserted=kg1.beliefs[0])
    # All reported postulates must be True
    assert all(results.values()), f"Postulate violations: {results}"


if __name__ == "__main__":
    for name, fn in list(globals().items()):
        if name.startswith("test_") and callable(fn):
            try:
                fn()
                print(f"✓ {name}")
            except AssertionError as e:
                print(f"✗ {name}: {e}")
            except Exception as e:
                print(f"✗ {name} (error): {e}")
