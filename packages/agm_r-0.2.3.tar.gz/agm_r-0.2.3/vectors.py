"""AGM-R Epistemic Vectors — the typed belief-state vector.

An Epistemic Vector encodes the *epistemic state* of a single belief in a
KnowledgeGraph the way a semantic embedding encodes meaning: five typed slots
that downstream retrieval / re-ranking / audit components can index, filter,
and score against.

The five slots are derived deterministically from the graph (operation history,
relation edges, retract closure, temporal ordering). No LLM call, no free-text
classifier, no extraction heuristic — the vector is a pure function of the
graph and a chosen `source_id`.

This is the retrieval-pipeline primitive referenced in Paper 1. Semantic
embeddings made similarity a first-class metric; Epistemic Vectors do the
same for belief state.
"""
from __future__ import annotations

from dataclasses import dataclass
from math import exp, isnan
from typing import Optional

from .types import Belief, KnowledgeGraph, RelationType
from .sigma import provenance, _parse_timestamp


# Freshness decay constant. exp(-λ · days). At λ = 0.003, half-life ≈ 231 days.
# Override via `epistemic_vector(..., freshness_lambda=...)`.
DEFAULT_FRESHNESS_LAMBDA: float = 0.003


@dataclass(frozen=True)
class EpistemicVector:
    """Typed belief-state vector for a single belief in a KnowledgeGraph.

    Slots:
      - `source_id`: the belief this vector describes.
      - `revision_state`: one of "asserted", "refined", "revised", "retracted".
        Derived from incoming relation edges and the retract closure.
      - `provenance_depth`: length of the DerivesFrom chain from this belief to
        a root (depth 0 = root, depth k = k hops back).
      - `consistency_score`: in [0.0, 1.0]. 1.0 when every co-term belief agrees;
        decreases linearly with the fraction of co-term beliefs whose claim_text
        differs. 1.0 when there is no co-term belief to disagree with.
      - `authority`: in [0.0, 1.0]. First-class slot reserved for an authority
        scorer; the reference implementation uses
        `max(0, 1.0 - 0.1 · num_contradictions_against)` and caps at 1.0.
      - `freshness`: in (0.0, 1.0]. Exponential decay against the most recent
        timestamp in the KG (`exp(-λ · days_since_this_belief)`). Retracted
        beliefs are still dated — retraction affects `revision_state`, not
        `freshness`.

    All slots are derived from graph topology and timestamps only. Paraphrase,
    NLI, or LLM judgement are deliberately out of scope — production engines
    (Sagrada) layer those on top; the primitive ships without them.
    """
    source_id: str
    revision_state: str
    provenance_depth: int
    consistency_score: float
    authority: float
    freshness: float

    def to_json(self) -> dict:
        return {
            "source_id": self.source_id,
            "revision_state": self.revision_state,
            "provenance_depth": self.provenance_depth,
            "consistency_score": self.consistency_score,
            "authority": self.authority,
            "freshness": self.freshness,
        }

    @classmethod
    def from_json(cls, d: dict) -> "EpistemicVector":
        return cls(
            source_id=d["source_id"],
            revision_state=d["revision_state"],
            provenance_depth=int(d["provenance_depth"]),
            consistency_score=float(d["consistency_score"]),
            authority=float(d["authority"]),
            freshness=float(d["freshness"]),
        )

    def __repr__(self) -> str:
        cs = "nan" if isnan(self.consistency_score) else f"{self.consistency_score:.2f}"
        return (f"EV({self.source_id}, {self.revision_state}, "
                f"prov={self.provenance_depth}, cons={cs}, "
                f"auth={self.authority:.2f}, fresh={self.freshness:.2f})")


# ---------------------------------------------------------------------------
# Slot derivations — each a pure function over (kg, source_id).
# ---------------------------------------------------------------------------


def _revision_state(kg: KnowledgeGraph, source_id: str) -> str:
    """Derive revision_state from retract closure and incoming relations.

    Priority: retracted > revised > refined > asserted.
    """
    if source_id in kg._retracted_closure():
        return "retracted"
    for r in kg.relations:
        if r.dst_source_id == source_id and r.rel_type == RelationType.REVISES:
            return "revised"
    for r in kg.relations:
        if r.dst_source_id == source_id and r.rel_type == RelationType.REFINES:
            return "refined"
    return "asserted"


def _provenance_depth(kg: KnowledgeGraph, source_id: str) -> int:
    """Length of the DerivesFrom chain from this belief to its root.

    depth 0 = belief has no DerivesFrom parent.
    depth k = belief has k DerivesFrom hops back to a root.
    """
    chain = provenance(kg, source_id)
    return max(0, len(chain) - 1)


def _same_term_non_retracted(kg: KnowledgeGraph,
                             source_id: str) -> tuple[Belief, list[Belief]]:
    """Return (this_belief, others) where `others` is the list of
    non-retracted beliefs about the same term, excluding `source_id`.

    Raises if source_id not in kg. Retracted status of `source_id` itself is
    OK; we still need to compute its vector.
    """
    belief = kg.belief_by_source(source_id)
    if belief is None:
        raise ValueError(f"source_id '{source_id}' not in KG")
    retracted = kg._retracted_closure()
    others = [b for b in kg.beliefs
              if b.term == belief.term
              and b.source_id != source_id
              and b.source_id not in retracted]
    return belief, others


def _contradiction_count(kg: KnowledgeGraph, source_id: str) -> int:
    """Number of non-retracted beliefs about the same term whose
    claim_text disagrees with this belief's claim_text."""
    belief, others = _same_term_non_retracted(kg, source_id)
    return sum(1 for b in others if b.claim_text != belief.claim_text)


def _consistency_score(kg: KnowledgeGraph, source_id: str) -> float:
    """1.0 minus the fraction of non-retracted co-term beliefs that disagree
    on claim_text. Returns 1.0 when there are no co-term beliefs.
    """
    belief, others = _same_term_non_retracted(kg, source_id)
    if not others:
        return 1.0
    contradictions = sum(1 for b in others if b.claim_text != belief.claim_text)
    return 1.0 - (contradictions / len(others))


def _authority(kg: KnowledgeGraph, source_id: str,
               contradictions_against: Optional[int] = None) -> float:
    """Reference authority scorer: `max(0.0, 1.0 - 0.1 · num_contradictions)`.

    Overridable. Production deployments can replace this with a provenance-
    or domain-aware scorer; the primitive keeps a first-class slot for it.
    """
    if contradictions_against is None:
        contradictions_against = _contradiction_count(kg, source_id)
    return max(0.0, min(1.0, 1.0 - 0.1 * contradictions_against))


def _freshness(kg: KnowledgeGraph, source_id: str, *,
               lam: float = DEFAULT_FRESHNESS_LAMBDA,
               now: Optional[str] = None) -> float:
    """Exponential decay on days since this belief's timestamp, relative to
    `now` (default: max timestamp across all beliefs in kg, for determinism).
    """
    belief = kg.belief_by_source(source_id)
    if belief is None:
        raise ValueError(f"source_id '{source_id}' not in KG")
    if kg.beliefs:
        reference = (_parse_timestamp(now) if now is not None
                     else max(_parse_timestamp(b.timestamp) for b in kg.beliefs))
    else:
        return 1.0
    days = (reference - _parse_timestamp(belief.timestamp)).days
    days = max(0, days)
    return float(exp(-lam * days))


# ---------------------------------------------------------------------------
# The primitive function.
# ---------------------------------------------------------------------------


def epistemic_vector(kg: KnowledgeGraph, source_id: str, *,
                     freshness_lambda: float = DEFAULT_FRESHNESS_LAMBDA,
                     now: Optional[str] = None) -> EpistemicVector:
    """Compute the Epistemic Vector for a belief in `kg`.

    Args:
        kg: the knowledge graph.
        source_id: the belief to describe.
        freshness_lambda: decay constant for the freshness slot (per day).
        now: ISO-8601 timestamp taken as "current time" for freshness. If None,
            the max timestamp in the KG is used, which makes the vector
            deterministic as a pure function of the graph.

    Returns:
        A typed EpistemicVector with five populated slots.

    Raises:
        ValueError if `source_id` is not in `kg`.
    """
    if kg.belief_by_source(source_id) is None:
        raise ValueError(f"source_id '{source_id}' not in KG")
    cc = _contradiction_count(kg, source_id)
    return EpistemicVector(
        source_id=source_id,
        revision_state=_revision_state(kg, source_id),
        provenance_depth=_provenance_depth(kg, source_id),
        consistency_score=_consistency_score(kg, source_id),
        authority=_authority(kg, source_id, contradictions_against=cc),
        freshness=_freshness(kg, source_id, lam=freshness_lambda, now=now),
    )
