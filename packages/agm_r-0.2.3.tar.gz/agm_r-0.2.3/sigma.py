"""AGM-R Σ-signature — the six primitives of T-I2's `StructuredRetriever`.

T-I2 (Retrieval-channel achievability, Sagrada/Info/RetrievalAchievability.lean):
there exists a structured retriever S, realised as a finite composition of
typed graph operations from the signature

    Σ = {aggregate, filter, count, provenance, temporal, compose}

such that end-to-end mutual information with the query saturates H(qDist)
on the graph-aggregative query class Q*.

This module provides Σ as 6 pure functions over (KnowledgeGraph, args). Every
structural query in `queries.py` is a composition of these primitives — that
IS the `CompositionWitness` for the Lean theorem.
"""
from __future__ import annotations

from typing import Callable, Iterable
from datetime import datetime, timedelta

from .types import Belief, KnowledgeGraph, Relation, RelationType


# ---------------------------------------------------------------------------
# Σ primitives
# ---------------------------------------------------------------------------


def filter_beliefs(kg: KnowledgeGraph, predicate: Callable[[Belief], bool]) -> list[Belief]:
    """Σ.filter: return beliefs satisfying `predicate`, excluding retracted."""
    retracted = kg._retracted_closure()
    return [b for b in kg.beliefs if b.source_id not in retracted and predicate(b)]


def count(xs: Iterable) -> int:
    """Σ.count: cardinality of an iterable."""
    return sum(1 for _ in xs)


def aggregate(beliefs: list[Belief],
              key: Callable[[Belief], object],
              reducer: Callable[[list[Belief]], object]) -> dict[object, object]:
    """Σ.aggregate: group beliefs by key, apply reducer to each group."""
    groups: dict[object, list[Belief]] = {}
    for b in beliefs:
        k = key(b)
        groups.setdefault(k, []).append(b)
    return {k: reducer(v) for k, v in groups.items()}


def provenance(kg: KnowledgeGraph, source_id: str) -> list[str]:
    """Σ.provenance: walk DerivesFrom edges to the roots.
    Returns list of source_ids in derivation order (leaf-to-root)."""
    chain = [source_id]
    derives = {(r.src_source_id, r.dst_source_id) for r in kg.relations
               if r.rel_type == RelationType.DERIVES_FROM}
    current = source_id
    while True:
        parent = next((dst for src, dst in derives if src == current), None)
        if parent is None or parent in chain:
            break
        chain.append(parent)
        current = parent
    return chain


def impact_radius(kg: KnowledgeGraph, root_source_id: str) -> list[str]:
    """Σ extension: list all beliefs that DerivesFrom* the root (transitively).

    This is the T-C1 closure computation generalised: given a belief to edit,
    every belief that transitively derives from it is in its 'impact radius'.
    Used for RippleEdits-style cascade detection (§6.3). Implemented as BFS
    over the DerivesFrom edge set (reverse direction: find sources whose dst
    reaches root)."""
    # reverse BFS: start at root, find all srcs whose dst path reaches root
    derives = [(r.src_source_id, r.dst_source_id) for r in kg.relations
               if r.rel_type == RelationType.DERIVES_FROM]
    downstream = set()
    frontier = {root_source_id}
    while frontier:
        next_frontier = set()
        for src, dst in derives:
            if dst in frontier and src not in downstream and src != root_source_id:
                next_frontier.add(src)
                downstream.add(src)
        frontier = next_frontier
    return sorted(downstream)


def _parse_timestamp(ts: str) -> datetime:
    """Robust timestamp parser: tolerates trailing 'T', 'Z', and timezone offsets."""
    if not ts:
        return datetime(1900, 1, 1)
    s = ts.strip().rstrip("T").rstrip("Z")
    if s.endswith("+00:00"):
        s = s[:-6]
    try:
        return datetime.fromisoformat(s)
    except Exception:
        # Try date-only parse
        try:
            return datetime.fromisoformat(s.split("T")[0])
        except Exception:
            return datetime(1900, 1, 1)


def temporal(beliefs: list[Belief], window_days: int) -> int:
    """Σ.temporal: maximum count of beliefs falling inside any rolling
    `window_days`-day window. Used for temporal_agg queries."""
    if not beliefs:
        return 0
    times = sorted(_parse_timestamp(b.timestamp) for b in beliefs)
    max_count = 0
    for i, t in enumerate(times):
        cutoff = t + timedelta(days=window_days)
        c = sum(1 for tt in times if t <= tt <= cutoff)
        if c > max_count:
            max_count = c
    return max_count


def compose(*fns: Callable) -> Callable:
    """Σ.compose: standard function composition, right-to-left.
    `compose(f, g, h)(x) == f(g(h(x)))`.
    Formally, this is what makes Σ a *closed* set of operations — any
    finite composition of Σ primitives is itself expressible as a single
    application (per T-I2's CompositionWitness constructor)."""
    def composed(x):
        for fn in reversed(fns):
            x = fn(x)
        return x
    return composed
