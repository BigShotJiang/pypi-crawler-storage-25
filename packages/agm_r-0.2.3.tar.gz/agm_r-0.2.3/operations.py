"""AGM-R operations — the five `apply` methods the capacity triangle reasons about.

Each operation is a pure function `KnowledgeGraph -> KnowledgeGraph` that
maintains the six AGM postulate invariants. Post-conditions are checked via
`postulates.verify_all_postulates`; any violation is a bug, not a feature.

Correspondence with `engine/core/src/operations.rs`: identical semantics, with
the Rust module additionally maintaining Merkle chain hashes, PROV-O export,
extraction metadata, etc. AGM-R strips those — they are production concerns,
not theorem concerns.
"""
from __future__ import annotations

from .types import Belief, KnowledgeGraph, Relation, RelationType, RetractRecord
from .postulates import verify_all_postulates


class PostulateViolation(Exception):
    """Raised when an operation's post-condition fails a postulate check.
    Only possible if the operation is implemented incorrectly (since by T-M1
    the postulates are necessary for information-lossless retrieval, any valid
    implementation must satisfy all six)."""
    pass


def _check(pre: KnowledgeGraph, post: KnowledgeGraph, kind: str,
           asserted: Belief | None = None,
           retracted_source_id: str | None = None) -> None:
    results = verify_all_postulates(pre, post, kind, asserted, retracted_source_id)
    failed = [name for name, ok in results.items() if not ok]
    if failed:
        raise PostulateViolation(
            f"Operation '{kind}' failed postulate(s): {failed}. "
            f"Pre-state ops: {pre.ops_history[-3:]}. "
            f"Post-state ops: {post.ops_history[-3:]}"
        )


def assert_belief(kg: KnowledgeGraph, *,
                  term: str, source_id: str, claim_text: str,
                  timestamp: str, author: str = "") -> KnowledgeGraph:
    """Assert a new belief.

    Preconditions:
      - `source_id` is not already in `kg`.
    Postconditions (all checked):
      - closure, inclusion, consistency, supplementation: automatic.
      - success: the asserted belief is in `kg_post`.
    """
    if kg.belief_by_source(source_id) is not None:
        raise ValueError(f"source_id '{source_id}' already present in KG")
    b = Belief(term=term, source_id=source_id, claim_text=claim_text,
               timestamp=timestamp, author=author)
    post = kg.with_belief(b)
    _check(kg, post, kind="assert", asserted=b)
    return post


def revise(kg: KnowledgeGraph, *,
           old_source_id: str, new_source_id: str, new_claim_text: str,
           timestamp: str, author: str = "") -> KnowledgeGraph:
    """Revise an existing belief: add a new belief about the same term,
    and add a Revises relation from new → old.

    This is the AGM K*-style revision: the new belief supersedes the old one
    for retrieval purposes, but the old belief is preserved in the graph for
    provenance (the revision chain).

    Preconditions:
      - `old_source_id` is present in `kg`.
      - `new_source_id` is not present in `kg`.
    """
    old = kg.belief_by_source(old_source_id)
    if old is None:
        raise ValueError(f"Cannot revise absent belief '{old_source_id}'")
    if kg.belief_by_source(new_source_id) is not None:
        raise ValueError(f"new source_id '{new_source_id}' already present")
    new = Belief(term=old.term, source_id=new_source_id, claim_text=new_claim_text,
                 timestamp=timestamp, author=author)
    post = (kg.with_belief(new)
              .with_relation(Relation(src_source_id=new_source_id,
                                      dst_source_id=old_source_id,
                                      rel_type=RelationType.REVISES)))
    _check(kg, post, kind="revise", asserted=new)
    return post


def refine(kg: KnowledgeGraph, *,
           old_source_id: str, new_source_id: str, new_claim_text: str,
           timestamp: str, author: str = "") -> KnowledgeGraph:
    """Refine an existing belief: add a new belief that augments (does not
    supersede) the old. Differs from revise in relation type: Refines rather
    than Revises, which means queries treat both as active."""
    old = kg.belief_by_source(old_source_id)
    if old is None:
        raise ValueError(f"Cannot refine absent belief '{old_source_id}'")
    if kg.belief_by_source(new_source_id) is not None:
        raise ValueError(f"new source_id '{new_source_id}' already present")
    new = Belief(term=old.term, source_id=new_source_id, claim_text=new_claim_text,
                 timestamp=timestamp, author=author)
    post = (kg.with_belief(new)
              .with_relation(Relation(src_source_id=new_source_id,
                                      dst_source_id=old_source_id,
                                      rel_type=RelationType.REFINES)))
    _check(kg, post, kind="refine", asserted=new)
    return post


def retract(kg: KnowledgeGraph, *,
            source_id: str, retraction_time: str) -> KnowledgeGraph:
    """Retract a belief.

    Vacuity-for-Retract (T-C1 necessity): if `source_id` is not in `kg`, the
    operation is a no-op on the belief set (ops_history still records it).

    Closure propagation (T-C1 companion): the retract implicitly applies to
    every belief that `DerivesFrom` the retracted one, recursively. This is
    enforced at query time by `KnowledgeGraph._retracted_closure()` rather than
    by adding extra RetractRecords, but the effect is identical.
    """
    present = kg.belief_by_source(source_id) is not None
    post = kg.with_retract(RetractRecord(source_id=source_id,
                                         retraction_time=retraction_time))
    _check(kg, post, kind="retract", retracted_source_id=source_id)
    if not present:
        # Vacuity sanity check
        assert {b.source_id for b in post.beliefs} == {b.source_id for b in kg.beliefs}
    return post


def relate(kg: KnowledgeGraph, *,
           src_source_id: str, dst_source_id: str,
           rel_type: RelationType) -> KnowledgeGraph:
    """Add an explicit typed relation (e.g. DerivesFrom) between two beliefs.
    Required for T-C1 closure propagation: if belief C derives from belief B,
    retracting B implicitly retracts C."""
    if kg.belief_by_source(src_source_id) is None:
        raise ValueError(f"src belief '{src_source_id}' not present")
    if kg.belief_by_source(dst_source_id) is None:
        raise ValueError(f"dst belief '{dst_source_id}' not present")
    post = kg.with_relation(Relation(src_source_id=src_source_id,
                                     dst_source_id=dst_source_id,
                                     rel_type=rel_type))
    _check(kg, post, kind="relate")
    return post
