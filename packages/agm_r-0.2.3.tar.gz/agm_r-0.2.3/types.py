"""AGM-R types — the data objects the theorems reason about.

A `KnowledgeGraph` is a pair (B, R) where B is a list of beliefs and R is a
list of typed relations. Each operation on the graph is a pure function
`KnowledgeGraph -> KnowledgeGraph` that preserves (or can be post-condition
checked against) the six AGM postulate classes.

This module is the theorem-minimum data layer. No serialisation format, no
hash chain, no audit artifacts — those live in production Sagrada.
"""
from __future__ import annotations
from dataclasses import dataclass, field, replace
from enum import Enum
from typing import Iterable


class RelationType(Enum):
    """Typed relations between beliefs. These are exactly the relation classes
    T-M1's minimality proof enumerates (Sagrada/AGM/Minimality.lean)."""
    ASSERTS = "asserts"         # source introduces belief de novo
    REVISES = "revises"         # supersedes an earlier belief for the same term
    REFINES = "refines"         # augments an earlier belief without superseding
    DERIVES_FROM = "derives_from"  # derivative of another belief (load-bearing for T-C1)
    RETRACTS = "retracts"       # marks earlier belief as withdrawn


@dataclass(frozen=True)
class Belief:
    """A single belief in the graph.

    `term`: the symbolic identifier the belief is about (e.g. "pluto_classification").
    `source_id`: a unique identifier for the source record asserting the belief.
    `claim_text`: the verbatim textual claim (only used for §5.4 paraphrase work;
        AGM-R queries ignore this field — that is T-5's graph-topology invariance).
    `timestamp`: ISO-8601 string, used for temporal ordering only.
    `author`: provenance (used by `provenance_chain` query).
    """
    term: str
    source_id: str
    claim_text: str
    timestamp: str
    author: str = ""


@dataclass(frozen=True)
class Relation:
    """A typed edge between two beliefs.

    `src_source_id` is the belief the relation originates from; `dst_source_id`
    is the target. `rel_type` is one of the five `RelationType` values.
    """
    src_source_id: str
    dst_source_id: str
    rel_type: RelationType


@dataclass(frozen=True)
class RetractRecord:
    """A retraction annotation.

    Distinct from RelationType.RETRACTS because T-C1 requires retracts to carry
    a *closure*: the retracted belief's DerivesFrom-reachable descendants are
    also implicitly retracted. `operations.retract` maintains this property.
    """
    source_id: str           # the retracted belief's source_id
    retraction_time: str     # when the retract was applied


@dataclass(frozen=True)
class KnowledgeGraph:
    """The belief graph.

    Invariants (enforced by operations.py, checkable by postulates.py):
      - Every `Relation.src_source_id` and `.dst_source_id` appears in `beliefs`.
      - No two beliefs share the same `source_id`.
      - A belief with a `RetractRecord` is treated as absent by all queries
        (T-C1 Vacuity-for-Retract).
      - If belief B is retracted and C `DerivesFrom` B, then C is *implicitly*
        retracted (T-C1 closure propagation).
    """
    beliefs: tuple[Belief, ...] = field(default_factory=tuple)
    relations: tuple[Relation, ...] = field(default_factory=tuple)
    retracts: tuple[RetractRecord, ...] = field(default_factory=tuple)
    # `ops_history` records the sequence of applied operations; T-M1 proofs
    # reason about trace-level properties (the `ops : List Operation` in Lean).
    ops_history: tuple[str, ...] = field(default_factory=tuple)

    def belief_by_source(self, source_id: str) -> Belief | None:
        for b in self.beliefs:
            if b.source_id == source_id:
                return b
        return None

    def beliefs_for_term(self, term: str, exclude_retracted: bool = True) -> list[Belief]:
        """Return beliefs about `term`, in chronological order, optionally
        filtering out retracted beliefs (+ their DerivesFrom-closure)."""
        retracted_ids = self._retracted_closure() if exclude_retracted else set()
        bs = [b for b in self.beliefs if b.term == term and b.source_id not in retracted_ids]
        return sorted(bs, key=lambda b: b.timestamp)

    def _retracted_closure(self) -> set[str]:
        """Set of source_ids that are retracted OR derive from a retracted belief
        (T-C1 closure propagation)."""
        base = {r.source_id for r in self.retracts}
        if not base:
            return base
        # BFS over DerivesFrom edges
        seen = set(base)
        frontier = set(base)
        derives_edges = [(r.src_source_id, r.dst_source_id) for r in self.relations
                         if r.rel_type == RelationType.DERIVES_FROM]
        while frontier:
            next_frontier = set()
            for src, dst in derives_edges:
                if dst in frontier and src not in seen:
                    next_frontier.add(src)
                    seen.add(src)
            frontier = next_frontier
        return seen

    def with_belief(self, b: Belief) -> "KnowledgeGraph":
        return replace(self, beliefs=self.beliefs + (b,),
                       ops_history=self.ops_history + (f"assert:{b.source_id}",))

    def with_relation(self, r: Relation) -> "KnowledgeGraph":
        return replace(self, relations=self.relations + (r,),
                       ops_history=self.ops_history + (f"relate:{r.src_source_id}->{r.dst_source_id}:{r.rel_type.value}",))

    def with_retract(self, rr: RetractRecord) -> "KnowledgeGraph":
        return replace(self, retracts=self.retracts + (rr,),
                       ops_history=self.ops_history + (f"retract:{rr.source_id}",))
