"""AGM-R structural queries — the 8 question types, each a Σ-composition.

Every query below is written as a composition of the 6 Σ primitives from
`sigma.py`. This is the empirical instantiation of T-I2's CompositionWitness:
each query kernel is `sagradaRetriever` in Lean, realised in Python.

No free text is parsed from queries; the routing is explicit (by
`question_type`). Production Sagrada ships a learned question-type
classifier (§5.5); AGM-R does not — classification is an engineering concern
orthogonal to the theorems.
"""
from __future__ import annotations

from .types import Belief, KnowledgeGraph, RelationType
from .sigma import filter_beliefs, count, aggregate, provenance, temporal


def revision_count(kg: KnowledgeGraph, *, term: str) -> str:
    """How many source entries about `term` are in the graph
    (counting original + all revisions; T-C1-compatible semantics excluding retracted)."""
    beliefs = filter_beliefs(kg, lambda b: b.term == term)
    n = count(beliefs)
    return f"{n}"


def revision_index(kg: KnowledgeGraph, *, term: str, k: int) -> str:
    """Return the k-th (1-indexed) entry about `term` in chronological order."""
    beliefs = sorted(filter_beliefs(kg, lambda b: b.term == term),
                     key=lambda b: b.timestamp)
    if 1 <= k <= len(beliefs):
        b = beliefs[k - 1]
        return f"source_id={b.source_id}; definition: {b.claim_text}"
    return "insufficient information"


def edit_diff(kg: KnowledgeGraph, *, term: str, occurrence: int) -> str:
    """Find the `occurrence`-th pair of consecutive entries whose claim_text differs."""
    beliefs = sorted(filter_beliefs(kg, lambda b: b.term == term),
                     key=lambda b: b.timestamp)
    changes = []
    for i in range(len(beliefs) - 1):
        if beliefs[i].claim_text != beliefs[i + 1].claim_text:
            changes.append((beliefs[i].source_id, beliefs[i + 1].source_id))
    if 1 <= occurrence <= len(changes):
        a, b = changes[occurrence - 1]
        return f"change occurred between source_id {a} and source_id {b}"
    return "insufficient information"


def contradiction(kg: KnowledgeGraph, *, term: str) -> str:
    """Does any pair of consecutive entries about `term` disagree on claim_text?
    Returns "yes" + pairs, or "no"."""
    beliefs = sorted(filter_beliefs(kg, lambda b: b.term == term),
                     key=lambda b: b.timestamp)
    witnesses = []
    for i in range(len(beliefs) - 1):
        if beliefs[i].claim_text != beliefs[i + 1].claim_text:
            witnesses.append((beliefs[i].source_id, beliefs[i + 1].source_id))
    if witnesses:
        pairs = ", ".join(f"({a} vs {b})" for a, b in witnesses)
        return f"Yes — contradicting pairs: {pairs}"
    return f"No contradiction detected for '{term}'."


def corroboration(kg: KnowledgeGraph, *, term: str) -> str:
    """Enumerate the source_ids supporting `term`."""
    beliefs = sorted(filter_beliefs(kg, lambda b: b.term == term),
                     key=lambda b: b.timestamp)
    ids = [b.source_id for b in beliefs]
    if not ids:
        return "insufficient information"
    return "Supporting source_ids: " + ", ".join(ids)


def temporal_agg(kg: KnowledgeGraph, *, term: str, window_days: int = 90) -> str:
    """Max count of entries about `term` in any rolling `window_days`-day window."""
    beliefs = filter_beliefs(kg, lambda b: b.term == term)
    n = temporal(beliefs, window_days)
    return f"{n}"


def negation_existence(kg: KnowledgeGraph, *, term: str) -> str:
    """Is there any pair of entries about `term` that disagree on claim_text?"""
    beliefs = sorted(filter_beliefs(kg, lambda b: b.term == term),
                     key=lambda b: b.timestamp)
    for i in range(len(beliefs) - 1):
        if beliefs[i].claim_text != beliefs[i + 1].claim_text:
            return "yes"
    return "no"


def provenance_chain(kg: KnowledgeGraph, *, term: str) -> str:
    """Describe the chain of entries about `term`: first-introducer + full chain."""
    beliefs = sorted(filter_beliefs(kg, lambda b: b.term == term),
                     key=lambda b: b.timestamp)
    if not beliefs:
        return "insufficient information"
    first = beliefs[0]
    ids = [b.source_id for b in beliefs]
    arrow = " -> ".join(ids)
    return (f"First introduced by {first.author or 'unknown'} in "
            f"source_id {first.source_id} (timestamp {first.timestamp}); chain: {arrow}")


# Dispatch table: the 8 structural query types. Paper §5.3 measures AGM-R's
# accuracy on these 8 across 25 real-world KBs (197 queries total). The claim
# is that this dispatch table saturates the T-I2 achievability ceiling at
# 83.8% — the same ceiling PROV-O+SPARQL hits, and the same ceiling Sagrada
# hits, because all three realise the same Σ-signature.

DISPATCH = {
    "revision_count": revision_count,
    "revision_index": revision_index,
    "edit_diff": edit_diff,
    "contradiction": contradiction,
    "corroboration": corroboration,
    "temporal_agg": temporal_agg,
    "negation_existence": negation_existence,
    "provenance_chain": provenance_chain,
}
