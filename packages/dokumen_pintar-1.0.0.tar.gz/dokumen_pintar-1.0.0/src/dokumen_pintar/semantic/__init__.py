"""Semantic search subsystem (optional)."""
