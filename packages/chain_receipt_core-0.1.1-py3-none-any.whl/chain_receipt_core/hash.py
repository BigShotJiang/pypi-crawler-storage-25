"""SHA-256 hashing utilities for Chain-Receipt v1.0.0."""
from __future__ import annotations

import hashlib
import json
import unicodedata
from typing import Any

from chain_receipt_core.canonical import canonical_json
from chain_receipt_core.schema import Receipt


def sha256_hex(data: bytes) -> str:
    """Lowercase hex SHA-256 of `data`."""
    return hashlib.sha256(data).hexdigest()


def compute_text_hash(text: str) -> str:
    """`sha256:<hex>` of the NFC-normalized UTF-8 of `text`.

    Matches SCHEMA.md §3.2.
    """
    nfc = unicodedata.normalize("NFC", text)
    return "sha256:" + sha256_hex(nfc.encode("utf-8"))


def compute_tool_calls_hash(sequence: list[dict[str, Any]]) -> str:
    """`sha256:<hex>` of the canonical tool-call sequence.

    Reference: scripts/paper4_replay_determinism.py::_seq_full
        for s in sequence:
            args = s.get("args") or {}
            parts.append(s["name"] + ":" + json.dumps(args, sort_keys=True, default=str))
        joined = "||".join(parts)

    NOTE: This intentionally uses Python's `json.dumps(..., sort_keys=True)`
    output as the inner serialization to remain byte-identical to the
    existing replay harness. The outer canonical-JSON algorithm in
    canonical.py is *not* used here because the harness predates it.
    Both the Python and TypeScript reference libraries reproduce the
    Python json.dumps output exactly.
    """
    parts: list[str] = []
    for s in sequence:
        name = s.get("name", "")
        args = s.get("args") or {}
        # default=str matches the harness; UUIDs / datetimes serialize via str()
        parts.append(name + ":" + json.dumps(args, sort_keys=True, default=str))
    joined = "||".join(parts)
    return "sha256:" + sha256_hex(joined.encode("utf-8"))


def receipt_hash(receipt: Receipt | dict[str, Any]) -> str:
    """`sha256:<hex>` of canonical-JSON(receipt with signature := null).

    Matches SCHEMA.md §8.2 exactly. Ed25519 sign/verify uses the **raw
    32 bytes** of the SHA-256 digest, not the hex string.
    """
    body = receipt.model_dump(mode="python") if isinstance(receipt, Receipt) else dict(receipt)
    body["signature"] = None
    canon = canonical_json(body)
    return "sha256:" + sha256_hex(canon)


def receipt_hash_bytes(receipt: Receipt | dict[str, Any]) -> bytes:
    """Raw 32 bytes of the SHA-256 digest used for Ed25519 sign/verify."""
    body = receipt.model_dump(mode="python") if isinstance(receipt, Receipt) else dict(receipt)
    body["signature"] = None
    canon = canonical_json(body)
    return hashlib.sha256(canon).digest()
