"""Tests for suitability scoring — workload-class-aware adjustments."""

from uuid import uuid4

from qlro.schemas import (
    CandidateEnvironment,
    EnvironmentProfile,
    EnvironmentType,
    AccessMode,
    NormalizedComparison,
    Workload,
    WorkloadCategory,
)
from qlro.comparison.suitability import apply_suitability


def _make_workload(**overrides) -> Workload:
    defaults = dict(
        name="test", category=WorkloadCategory.optimization,
        objective="test", priority_cost=0.33, priority_speed=0.33,
        priority_confidence=0.34,
    )
    defaults.update(overrides)
    return Workload(**defaults)


def _make_env(name="Env", profile=None, max_qubits=None, **overrides) -> CandidateEnvironment:
    defaults = dict(
        name=name, vendor="Test", environment_type=EnvironmentType.simulator,
        access_mode=AccessMode.sdk, profile=profile, max_qubits=max_qubits,
    )
    defaults.update(overrides)
    return CandidateEnvironment(**defaults)


def _make_comp(workload_id, env_id, confidence=0.5, overall=0.7, **overrides) -> NormalizedComparison:
    defaults = dict(
        workload_id=workload_id, environment_id=env_id,
        experiment_result_id=uuid4(),
        runtime_score=0.5, cost_score=0.5, confidence_score=confidence,
        feasibility_score=0.5, overall_score=overall, assumptions=[],
    )
    defaults.update(overrides)
    return NormalizedComparison(**defaults)


class TestSuitabilityScoring:
    def test_noisy_env_penalized_for_chemistry(self):
        """Chemistry workload on low-confidence env should get penalized."""
        wl = _make_workload(category=WorkloadCategory.chemistry)
        env = _make_env("Noisy QPU")
        env_map = {env.id: env}

        comp = _make_comp(wl.id, env.id, confidence=0.2, overall=0.7)
        adjusted = apply_suitability(wl, [comp], env_map)

        assert adjusted[0].overall_score < comp.overall_score
        suitability_notes = [a for a in adjusted[0].assumptions if "Suitability:" in a]
        assert len(suitability_notes) > 0

    def test_high_fidelity_env_bonus_for_chemistry(self):
        """Chemistry workload on high-confidence env should get a bonus."""
        wl = _make_workload(category=WorkloadCategory.chemistry)
        env = _make_env("Ideal Sim")
        env_map = {env.id: env}

        comp = _make_comp(wl.id, env.id, confidence=0.9, overall=0.7)
        adjusted = apply_suitability(wl, [comp], env_map)

        assert adjusted[0].overall_score > comp.overall_score

    def test_ml_workload_not_penalized_on_noisy_env(self):
        """ML workload (low noise sensitivity) should not get noise penalty."""
        wl = _make_workload(category=WorkloadCategory.ml)
        env = _make_env("Noisy")
        env_map = {env.id: env}

        comp = _make_comp(wl.id, env.id, confidence=0.2, overall=0.7)
        adjusted = apply_suitability(wl, [comp], env_map)

        # ML has noise_sensitivity=0.3, below the 0.6 threshold for rule 1
        assert adjusted[0].overall_score == comp.overall_score

    def test_qubit_pressure_penalty(self):
        """Workload near environment qubit limit should be penalized."""
        wl = _make_workload(qubit_count_hint=25)  # pressure = 25/30 ≈ 0.83
        env = _make_env("Small QPU", max_qubits=20)
        env_map = {env.id: env}

        comp = _make_comp(wl.id, env.id, overall=0.7)
        adjusted = apply_suitability(wl, [comp], env_map)

        assert adjusted[0].overall_score < comp.overall_score
        assert any("Qubit pressure" in a for a in adjusted[0].assumptions)

    def test_profile_noise_penalty(self):
        """Environment with high gate errors should penalize noise-sensitive workloads."""
        wl = _make_workload(category=WorkloadCategory.simulation)  # noise_sensitivity=0.8
        profile = EnvironmentProfile(
            single_gate_error=0.01,
            two_gate_error=0.05,
            readout_error=0.03,
        )
        env = _make_env("Noisy QPU", profile=profile)
        env_map = {env.id: env}

        comp = _make_comp(wl.id, env.id, confidence=0.5, overall=0.7)
        adjusted = apply_suitability(wl, [comp], env_map)

        assert adjusted[0].overall_score < comp.overall_score
        assert any("noise profile" in a for a in adjusted[0].assumptions)

    def test_ideal_profile_no_penalty(self):
        """Environment with zero errors should get no profile penalty."""
        wl = _make_workload(category=WorkloadCategory.chemistry)
        profile = EnvironmentProfile(
            single_gate_error=0.0,
            two_gate_error=0.0,
            readout_error=0.0,
        )
        env = _make_env("Ideal", profile=profile)
        env_map = {env.id: env}

        comp = _make_comp(wl.id, env.id, confidence=0.9, overall=0.7)
        adjusted = apply_suitability(wl, [comp], env_map)

        # Should only get the fidelity bonus, no noise penalty
        assert adjusted[0].overall_score >= comp.overall_score

    def test_ranking_changes_with_suitability(self):
        """Suitability should be able to change ranking between environments."""
        wl = _make_workload(category=WorkloadCategory.chemistry)

        # Noisy env has slightly higher raw score but low confidence
        env_noisy = _make_env("Noisy")
        env_clean = _make_env("Clean")
        env_map = {env_noisy.id: env_noisy, env_clean.id: env_clean}

        comp_noisy = _make_comp(wl.id, env_noisy.id, confidence=0.15, overall=0.72)
        comp_clean = _make_comp(wl.id, env_clean.id, confidence=0.85, overall=0.70)

        adjusted = apply_suitability(wl, [comp_noisy, comp_clean], env_map)
        adj_noisy = next(c for c in adjusted if c.environment_id == env_noisy.id)
        adj_clean = next(c for c in adjusted if c.environment_id == env_clean.id)

        # Clean should now beat noisy after suitability adjustment
        assert adj_clean.overall_score > adj_noisy.overall_score

    def test_dimension_scores_preserved(self):
        """Suitability should only adjust overall_score, not dimension scores."""
        wl = _make_workload(category=WorkloadCategory.chemistry)
        env = _make_env("Test")
        env_map = {env.id: env}

        comp = _make_comp(wl.id, env.id, confidence=0.2, overall=0.7,
                          runtime_score=0.8, cost_score=0.6, feasibility_score=0.9)
        adjusted = apply_suitability(wl, [comp], env_map)

        assert adjusted[0].runtime_score == 0.8
        assert adjusted[0].cost_score == 0.6
        assert adjusted[0].confidence_score == 0.2
        assert adjusted[0].feasibility_score == 0.9
