"""Tests for workload fingerprinting."""

from qlro.schemas import Workload, WorkloadCategory
from qlro.schemas.fingerprint import compute_fingerprint


def _make_workload(**overrides) -> Workload:
    defaults = dict(
        name="test", category=WorkloadCategory.optimization,
        objective="test", priority_cost=0.33, priority_speed=0.33,
        priority_confidence=0.34,
    )
    defaults.update(overrides)
    return Workload(**defaults)


class TestFingerprint:
    def test_chemistry_high_noise_sensitivity(self):
        """Chemistry workloads should have high noise sensitivity."""
        wl = _make_workload(category=WorkloadCategory.chemistry)
        fp = compute_fingerprint(wl)
        assert fp.noise_sensitivity >= 0.8
        assert fp.fidelity_need >= 0.9

    def test_ml_low_noise_sensitivity(self):
        """ML workloads should have low noise sensitivity."""
        wl = _make_workload(category=WorkloadCategory.ml)
        fp = compute_fingerprint(wl)
        assert fp.noise_sensitivity <= 0.4
        assert fp.depth_sensitivity <= 0.4

    def test_simulation_high_depth_sensitivity(self):
        """Simulation workloads should be depth-sensitive."""
        wl = _make_workload(category=WorkloadCategory.simulation)
        fp = compute_fingerprint(wl)
        assert fp.depth_sensitivity >= 0.7

    def test_deep_circuit_increases_depth_sensitivity(self):
        """High circuit depth hint should increase depth sensitivity."""
        wl_shallow = _make_workload(circuit_depth_hint=2)
        wl_deep = _make_workload(circuit_depth_hint=15)
        fp_shallow = compute_fingerprint(wl_shallow)
        fp_deep = compute_fingerprint(wl_deep)
        assert fp_deep.depth_sensitivity > fp_shallow.depth_sensitivity

    def test_qubit_pressure_scales_with_hint(self):
        """Qubit pressure should scale with qubit count hint."""
        wl_small = _make_workload(qubit_count_hint=4)
        wl_large = _make_workload(qubit_count_hint=25)
        fp_small = compute_fingerprint(wl_small)
        fp_large = compute_fingerprint(wl_large)
        assert fp_large.qubit_pressure > fp_small.qubit_pressure

    def test_priority_passthrough(self):
        """User cost/speed priorities should pass through to fingerprint."""
        wl = _make_workload(priority_cost=0.7, priority_speed=0.2)
        fp = compute_fingerprint(wl)
        assert fp.cost_sensitivity == 0.7
        assert fp.speed_sensitivity == 0.2

    def test_rationale_populated(self):
        """Fingerprint should always have rationale."""
        wl = _make_workload()
        fp = compute_fingerprint(wl)
        assert len(fp.rationale) >= 2

    def test_category_stored(self):
        """Category should be stored on fingerprint."""
        wl = _make_workload(category=WorkloadCategory.chemistry)
        fp = compute_fingerprint(wl)
        assert fp.category == "chemistry"
