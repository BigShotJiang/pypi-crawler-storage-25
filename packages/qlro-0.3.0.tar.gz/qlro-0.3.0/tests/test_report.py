"""Tests for report generation — markdown and JSON."""

import json
from uuid import uuid4

from qlro.schemas import (
    CandidateEnvironment,
    ConfidenceLevel,
    EnvironmentType,
    AccessMode,
    ExplanationSection,
    NormalizedComparison,
    Recommendation,
    Tradeoff,
    Workload,
    WorkloadCategory,
)
from qlro.export.report import generate_report


def _setup():
    """Create a full set of test data for report generation."""
    workload = Workload(
        name="Test Workload",
        category=WorkloadCategory.optimization,
        objective="Test comparison",
        priority_cost=0.3,
        priority_speed=0.3,
        priority_confidence=0.4,
    )

    env_a = CandidateEnvironment(
        name="Env Alpha",
        vendor="Vendor A",
        environment_type=EnvironmentType.simulator,
        access_mode=AccessMode.sdk,
    )
    env_b = CandidateEnvironment(
        name="Env Beta",
        vendor="Vendor B",
        environment_type=EnvironmentType.cloud_hardware,
        access_mode=AccessMode.api,
    )
    env_map = {env_a.id: env_a, env_b.id: env_b}

    comparisons = [
        NormalizedComparison(
            workload_id=workload.id,
            environment_id=env_a.id,
            experiment_result_id=uuid4(),
            runtime_score=0.8,
            cost_score=0.9,
            confidence_score=0.6,
            feasibility_score=0.9,
            overall_score=0.78,
            assumptions=["Queue time unknown; defaulted to 0 (assumed)"],
        ),
        NormalizedComparison(
            workload_id=workload.id,
            environment_id=env_b.id,
            experiment_result_id=uuid4(),
            runtime_score=0.4,
            cost_score=0.3,
            confidence_score=0.95,
            feasibility_score=0.7,
            overall_score=0.55,
            assumptions=["Cost is a user-provided estimate (estimated)"],
        ),
    ]

    recommendation = Recommendation(
        workload_id=workload.id,
        primary_environment_id=env_a.id,
        secondary_environment_id=env_b.id,
        rationale="Env Alpha scored highest overall (0.78). Key strengths: fast runtime, low cost.",
        confidence_level=ConfidenceLevel.medium,
        confidence_reasons=[
            "Moderate score gap (0.23) between top two",
            "1 data points are estimates, not measurements",
        ],
        tradeoffs=[
            Tradeoff(
                dimension="Output confidence",
                favors="Env Beta",
                description="Env Beta scores better on output confidence (0.95 vs 0.60)",
            ),
        ],
        explanation=ExplanationSection(
            observed=[
                "Env Alpha scored highest overall: 0.78",
                "Env Beta scored second: 0.55",
            ],
            estimated=["Cost is a user-provided estimate (estimated)"],
            assumed=["Queue time unknown; defaulted to 0 (assumed)"],
            recommendation_logic=[
                "Scoring weights: speed=30%, cost=30%, confidence=40%, feasibility=10% (fixed)",
                "Overall = speed_weight * runtime_score + cost_weight * cost_score + confidence_weight * confidence_score + 0.1 * feasibility_score",
            ],
            unknowns=["Only 2 environments compared — recommendation is based on a narrow field"],
        ),
        assumptions=[
            "Queue time unknown; defaulted to 0 (assumed)",
            "Cost is a user-provided estimate (estimated)",
        ],
        next_step="Proceed with a small-scale validation run on Env Alpha.",
    )

    return workload, env_map, comparisons, recommendation


class TestMarkdownReport:
    def test_contains_workload_summary(self):
        workload, env_map, comps, rec = _setup()
        report = generate_report(workload, env_map, comps, rec, format="markdown")
        assert "## Workload" in report
        assert "Test Workload" in report
        assert "optimization" in report

    def test_contains_comparison_table(self):
        workload, env_map, comps, rec = _setup()
        report = generate_report(workload, env_map, comps, rec, format="markdown")
        assert "## Comparison Results" in report
        assert "Env Alpha" in report
        assert "Env Beta" in report
        assert "**0.78**" in report

    def test_contains_recommendation(self):
        workload, env_map, comps, rec = _setup()
        report = generate_report(workload, env_map, comps, rec, format="markdown")
        assert "## Recommendation" in report
        assert "**Primary:** Env Alpha" in report
        assert "**Secondary:** Env Beta" in report
        assert "**Confidence:** medium" in report

    def test_contains_tradeoffs(self):
        workload, env_map, comps, rec = _setup()
        report = generate_report(workload, env_map, comps, rec, format="markdown")
        assert "### Tradeoffs" in report
        assert "Output confidence" in report

    def test_contains_explanation_sections(self):
        workload, env_map, comps, rec = _setup()
        report = generate_report(workload, env_map, comps, rec, format="markdown")
        assert "## How This Recommendation Was Made" in report
        assert "### What We Measured" in report
        assert "### What Was Estimated" in report
        assert "### What We Had to Guess" in report
        assert "### How We Ranked the Options" in report

    def test_contains_unknowns(self):
        workload, env_map, comps, rec = _setup()
        report = generate_report(workload, env_map, comps, rec, format="markdown")
        assert "## What We Don't Know" in report

    def test_contains_assumptions(self):
        workload, env_map, comps, rec = _setup()
        report = generate_report(workload, env_map, comps, rec, format="markdown")
        assert "## What Could Change This Recommendation" in report

    def test_contains_trust_checklist(self):
        workload, env_map, comps, rec = _setup()
        report = generate_report(workload, env_map, comps, rec, format="markdown")
        assert "### Trust Checklist" in report
        assert "**Measured:**" in report

    def test_contains_technical_appendix(self):
        workload, env_map, comps, rec = _setup()
        report = generate_report(workload, env_map, comps, rec, format="markdown")
        assert "## Technical Appendix" in report


class TestJsonReport:
    def test_valid_json(self):
        workload, env_map, comps, rec = _setup()
        report = generate_report(workload, env_map, comps, rec, format="json")
        data = json.loads(report)
        assert isinstance(data, dict)

    def test_json_has_all_sections(self):
        workload, env_map, comps, rec = _setup()
        report = generate_report(workload, env_map, comps, rec, format="json")
        data = json.loads(report)

        assert "workload" in data
        assert "comparisons" in data
        assert "recommendation" in data
        assert "explanation" in data
        assert "generated_at" in data

    def test_json_recommendation_fields(self):
        workload, env_map, comps, rec = _setup()
        report = generate_report(workload, env_map, comps, rec, format="json")
        data = json.loads(report)

        r = data["recommendation"]
        assert r["primary_environment"] == "Env Alpha"
        assert r["secondary_environment"] == "Env Beta"
        assert r["confidence"] == "medium"
        assert len(r["confidence_reasons"]) > 0
        assert len(r["tradeoffs"]) > 0
        assert r["rationale"]
        assert r["next_step"]

    def test_json_explanation_structure(self):
        workload, env_map, comps, rec = _setup()
        report = generate_report(workload, env_map, comps, rec, format="json")
        data = json.loads(report)

        expl = data["explanation"]
        assert "observed" in expl
        assert "estimated" in expl
        assert "assumed" in expl
        assert "recommendation_logic" in expl
        assert "unknowns" in expl
