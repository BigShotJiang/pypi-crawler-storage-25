"""End-to-end test: define workload, run experiments, compare, recommend."""

import tempfile
from pathlib import Path

from qlro.schemas import (
    CandidateEnvironment,
    EnvironmentCreate,
    EnvironmentType,
    AccessMode,
    ExperimentRun,
    ExperimentRunCreate,
    RunType,
    Workload,
    WorkloadCategory,
    WorkloadCreate,
)
from qlro.storage import Database
from qlro.runner import QiskitRunner
from qlro.comparison import normalize_results
from qlro.recommendation import recommend
from qlro.export import generate_report


def test_full_pipeline():
    """Run the full Qlro pipeline: workload → experiments → comparison → recommendation → report."""
    with tempfile.TemporaryDirectory() as tmp:
        db = Database(Path(tmp) / "test.db")

        # 1. Create workload
        workload = Workload(
            **WorkloadCreate(
                name="MaxCut 4-qubit",
                category=WorkloadCategory.optimization,
                objective="Solve small MaxCut instance via QAOA",
                qubit_count_hint=4,
                circuit_depth_hint=2,
                priority_cost=0.2,
                priority_speed=0.3,
                priority_confidence=0.5,
            ).model_dump()
        )
        db.save("workloads", workload)

        # 2. Create candidate environments
        env_a = CandidateEnvironment(
            **EnvironmentCreate(
                name="Aer Statevector",
                vendor="IBM/Qiskit",
                environment_type=EnvironmentType.simulator,
                access_mode=AccessMode.sdk,
                max_qubits=30,
                estimated_cost_per_run=0.0,
            ).model_dump()
        )
        env_b = CandidateEnvironment(
            **EnvironmentCreate(
                name="Aer QASM",
                vendor="IBM/Qiskit",
                environment_type=EnvironmentType.simulator,
                access_mode=AccessMode.sdk,
                max_qubits=30,
                estimated_cost_per_run=0.0,
            ).model_dump()
        )
        db.save("environments", env_a)
        db.save("environments", env_b)

        # 3. Run experiments
        runner = QiskitRunner(shots=512)

        exp_a = ExperimentRun(workload_id=workload.id, environment_id=env_a.id)
        run_a, result_a = runner.run(exp_a, workload, env_a)
        db.save("experiment_runs", run_a)
        db.save("experiment_results", result_a)

        exp_b = ExperimentRun(workload_id=workload.id, environment_id=env_b.id)
        run_b, result_b = runner.run(exp_b, workload, env_b)
        db.save("experiment_runs", run_b)
        db.save("experiment_results", result_b)

        assert run_a.status.value == "completed"
        assert run_b.status.value == "completed"
        assert result_a.measured_runtime_sec is not None
        assert result_b.measured_runtime_sec is not None

        # 4. Normalize and compare
        comparisons = normalize_results(
            workload, [(env_a, result_a), (env_b, result_b)]
        )
        assert len(comparisons) == 2
        for comp in comparisons:
            assert 0 <= comp.runtime_score <= 1
            assert 0 <= comp.cost_score <= 1
            assert 0 <= comp.confidence_score <= 1
            db.save("comparisons", comp)

        # 5. Recommend
        env_map = {env_a.id: env_a, env_b.id: env_b}
        rec = recommend(workload, comparisons, env_map)

        assert rec.primary_environment_id in (env_a.id, env_b.id)
        assert rec.rationale
        assert rec.confidence_level
        assert rec.next_step
        db.save("recommendations", rec)

        # 6. Generate report
        md_report = generate_report(workload, env_map, comparisons, rec, format="markdown")
        assert "# Qlro Comparison Report" in md_report
        assert workload.name in md_report
        assert rec.rationale in md_report

        json_report = generate_report(workload, env_map, comparisons, rec, format="json")
        assert '"primary_environment"' in json_report

        db.close()


def test_single_environment():
    """Recommendation should work with a single environment."""
    with tempfile.TemporaryDirectory() as tmp:
        db = Database(Path(tmp) / "test.db")

        workload = Workload(
            **WorkloadCreate(
                name="Bell State Test",
                category=WorkloadCategory.custom,
                objective="Run a simple Bell state circuit",
                qubit_count_hint=2,
            ).model_dump()
        )

        env = CandidateEnvironment(
            **EnvironmentCreate(
                name="Local Simulator",
                vendor="IBM/Qiskit",
                environment_type=EnvironmentType.simulator,
                access_mode=AccessMode.sdk,
            ).model_dump()
        )

        runner = QiskitRunner(shots=256)
        experiment = ExperimentRun(workload_id=workload.id, environment_id=env.id)
        run, result = runner.run(experiment, workload, env)

        comparisons = normalize_results(workload, [(env, result)])
        assert len(comparisons) == 1

        env_map = {env.id: env}
        rec = recommend(workload, comparisons, env_map)
        assert rec.primary_environment_id == env.id
        assert rec.secondary_environment_id is None

        db.close()
