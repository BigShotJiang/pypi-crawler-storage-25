"""Deterministic tests for the normalization pipeline.

No Qiskit execution — uses hand-crafted ExperimentResult objects
so we can verify exact score outputs.
"""

from uuid import uuid4

from qlro.schemas import (
    CandidateEnvironment,
    EnvironmentType,
    AccessMode,
    ExperimentResult,
    Workload,
    WorkloadCategory,
)
from qlro.comparison.normalizer import normalize_results, normalize, discount, DataProvenance


# --- Helpers ---

def _make_workload(**overrides) -> Workload:
    defaults = dict(
        name="test",
        category=WorkloadCategory.optimization,
        objective="test objective",
        priority_cost=0.33,
        priority_speed=0.33,
        priority_confidence=0.34,
    )
    defaults.update(overrides)
    return Workload(**defaults)


def _make_env(name="Env A", cost_per_run=None, queue_time=None, **overrides) -> CandidateEnvironment:
    defaults = dict(
        name=name,
        vendor="Test",
        environment_type=EnvironmentType.simulator,
        access_mode=AccessMode.sdk,
        estimated_cost_per_run=cost_per_run,
        estimated_queue_time_sec=queue_time,
    )
    defaults.update(overrides)
    return CandidateEnvironment(**defaults)


def _make_result(run_id=None, runtime=None, cost=None, fidelity=None, success=None) -> ExperimentResult:
    return ExperimentResult(
        experiment_run_id=run_id or uuid4(),
        measured_runtime_sec=runtime,
        estimated_cost_usd=cost,
        output_fidelity=fidelity,
        success_rate=success,
    )


# --- normalize() function tests ---

class TestNormalize:
    def test_lower_is_better_inversion(self):
        """Lowest value should get score 1.0 when lower_is_better=True."""
        vals = [1.0, 5.0, 10.0]
        assert normalize(1.0, vals, lower_is_better=True) == 1.0   # best
        assert normalize(10.0, vals, lower_is_better=True) == 0.0  # worst
        assert normalize(5.0, vals, lower_is_better=True) == round(1.0 - (4.0 / 9.0), 4)

    def test_higher_is_better(self):
        """Highest value should get score 1.0 when lower_is_better=False."""
        vals = [0.2, 0.5, 0.9]
        assert normalize(0.9, vals, lower_is_better=False) == 1.0   # best
        assert normalize(0.2, vals, lower_is_better=False) == 0.0   # worst

    def test_all_identical(self):
        """All identical values should return 0.5."""
        vals = [3.0, 3.0, 3.0]
        assert normalize(3.0, vals, lower_is_better=True) == 0.5
        assert normalize(3.0, vals, lower_is_better=False) == 0.5

    def test_two_values(self):
        """With two values, one gets 0.0 and the other 1.0."""
        vals = [2.0, 8.0]
        assert normalize(2.0, vals, lower_is_better=True) == 1.0
        assert normalize(8.0, vals, lower_is_better=True) == 0.0


# --- discount() function tests ---

class TestDiscount:
    def test_observed_full_weight(self):
        assert discount(0.8, DataProvenance.observed) == 0.8

    def test_estimated_reduced(self):
        assert discount(1.0, DataProvenance.estimated) == 0.8

    def test_assumed_heavily_reduced(self):
        assert discount(1.0, DataProvenance.assumed) == 0.5

    def test_zero_unaffected(self):
        assert discount(0.0, DataProvenance.assumed) == 0.0


# --- normalize_results pipeline tests ---

class TestNormalizeResults:
    def test_clear_winner(self):
        """Environment with faster runtime, lower cost, higher fidelity should score higher."""
        workload = _make_workload(priority_speed=0.33, priority_cost=0.33, priority_confidence=0.34)
        env_good = _make_env("Fast & Cheap")
        env_bad = _make_env("Slow & Expensive", cost_per_run=5.0, queue_time=120.0)

        result_good = _make_result(runtime=0.01, cost=0.0, fidelity=0.95, success=1.0)
        result_bad = _make_result(runtime=2.0, cost=5.0, fidelity=0.60, success=0.8)

        comps = normalize_results(workload, [(env_good, result_good), (env_bad, result_bad)])
        assert len(comps) == 2

        good_comp = next(c for c in comps if c.environment_id == env_good.id)
        bad_comp = next(c for c in comps if c.environment_id == env_bad.id)

        assert good_comp.overall_score > bad_comp.overall_score

    def test_clear_winner_without_discount(self):
        """Without discounting, raw normalized scores should be exact."""
        workload = _make_workload(priority_speed=0.33, priority_cost=0.33, priority_confidence=0.34)
        env_good = _make_env("Fast & Cheap")
        env_bad = _make_env("Slow & Expensive", cost_per_run=5.0, queue_time=120.0)

        result_good = _make_result(runtime=0.01, cost=0.0, fidelity=0.95, success=1.0)
        result_bad = _make_result(runtime=2.0, cost=5.0, fidelity=0.60, success=0.8)

        comps = normalize_results(
            workload, [(env_good, result_good), (env_bad, result_bad)],
            apply_discount=False,
        )
        good_comp = next(c for c in comps if c.environment_id == env_good.id)
        bad_comp = next(c for c in comps if c.environment_id == env_bad.id)

        assert good_comp.runtime_score == 1.0   # fastest → 1.0
        assert bad_comp.runtime_score == 0.0    # slowest → 0.0
        assert good_comp.cost_score == 1.0      # cheapest → 1.0
        assert good_comp.confidence_score == 1.0  # highest fidelity → 1.0

    def test_missing_data_creates_assumptions(self):
        """Missing data should produce assumptions and default to 0."""
        workload = _make_workload()
        env = _make_env("Sparse Data")
        result = _make_result(runtime=1.0)  # only runtime, everything else None

        comps = normalize_results(workload, [(env, result)])
        comp = comps[0]

        assumed_items = [a for a in comp.assumptions if "(assumed)" in a]
        assert len(assumed_items) >= 2  # at least cost and fidelity

    def test_estimated_cost_tagged(self):
        """Cost from environment estimate should be tagged as estimated."""
        workload = _make_workload()
        env = _make_env("Cloud", cost_per_run=2.50)
        result = _make_result(runtime=0.5, cost=2.50, fidelity=0.8, success=1.0)

        comps = normalize_results(workload, [(env, result)])
        estimated_items = [a for a in comps[0].assumptions if "(estimated)" in a]
        assert any("Cost" in a or "cost" in a.lower() for a in estimated_items)

    def test_priority_weights_matter(self):
        """Changing priority weights should change ranking."""
        env_fast = _make_env("Fast")
        env_accurate = _make_env("Accurate")

        result_fast = _make_result(runtime=0.01, cost=1.0, fidelity=0.5, success=1.0)
        result_accurate = _make_result(runtime=5.0, cost=1.0, fidelity=0.99, success=1.0)

        # Speed-focused workload
        wl_speed = _make_workload(priority_speed=0.8, priority_cost=0.1, priority_confidence=0.1)
        comps_speed = normalize_results(wl_speed, [(env_fast, result_fast), (env_accurate, result_accurate)])
        fast_score = next(c for c in comps_speed if c.environment_id == env_fast.id).overall_score
        acc_score = next(c for c in comps_speed if c.environment_id == env_accurate.id).overall_score
        assert fast_score > acc_score

        # Confidence-focused workload
        wl_conf = _make_workload(priority_speed=0.1, priority_cost=0.1, priority_confidence=0.8)
        comps_conf = normalize_results(wl_conf, [(env_fast, result_fast), (env_accurate, result_accurate)])
        fast_score_2 = next(c for c in comps_conf if c.environment_id == env_fast.id).overall_score
        acc_score_2 = next(c for c in comps_conf if c.environment_id == env_accurate.id).overall_score
        assert acc_score_2 > fast_score_2

    def test_empty_results(self):
        """Empty input should return empty list."""
        workload = _make_workload()
        assert normalize_results(workload, []) == []

    def test_queue_time_affects_feasibility(self):
        """Environment with long queue time should have lower feasibility."""
        workload = _make_workload()
        env_quick = _make_env("Quick Queue", queue_time=0.0)
        env_slow = _make_env("Slow Queue", queue_time=600.0)

        result_a = _make_result(runtime=1.0, cost=0.0, fidelity=0.8, success=1.0)
        result_b = _make_result(runtime=1.0, cost=0.0, fidelity=0.8, success=1.0)

        comps = normalize_results(workload, [(env_quick, result_a), (env_slow, result_b)])
        quick_comp = next(c for c in comps if c.environment_id == env_quick.id)
        slow_comp = next(c for c in comps if c.environment_id == env_slow.id)

        assert quick_comp.feasibility_score > slow_comp.feasibility_score

    def test_provenance_discount_reduces_assumed_scores(self):
        """Assumed data should get discounted, reducing overall score."""
        workload = _make_workload()
        env = _make_env("Missing Data")
        result_sparse = _make_result(runtime=1.0)  # missing cost, fidelity, success
        result_full = _make_result(runtime=1.0, cost=0.0, fidelity=0.8, success=1.0)

        comps_sparse = normalize_results(workload, [(env, result_sparse)])
        comps_full = normalize_results(workload, [(_make_env("Full Data"), result_full)])

        # Full observed data should score higher than assumed defaults
        assert comps_full[0].overall_score >= comps_sparse[0].overall_score
