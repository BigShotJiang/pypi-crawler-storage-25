"""Tests for environment differentiation — proving that different
environment profiles produce measurably different experiment results.

These tests use actual Qiskit Aer execution, so they are slower
than the deterministic tests, but they prove the differentiation is real.
"""

from qlro.schemas import (
    CandidateEnvironment,
    EnvironmentCreate,
    EnvironmentProfile,
    EnvironmentType,
    AccessMode,
    ExperimentRun,
    Workload,
    WorkloadCreate,
    WorkloadCategory,
)
from qlro.runner import QiskitRunner


def _make_workload() -> Workload:
    return Workload(**WorkloadCreate(
        name="Differentiation test",
        category=WorkloadCategory.optimization,
        objective="Test that environments produce different results",
        qubit_count_hint=4,
        circuit_depth_hint=2,
    ).model_dump())


class TestEnvironmentDifferentiation:
    def test_ideal_vs_noisy_fidelity_differs(self):
        """Ideal simulator should produce higher fidelity than noisy one."""
        workload = _make_workload()
        runner = QiskitRunner(shots=2048)

        env_ideal = CandidateEnvironment(**EnvironmentCreate(
            name="Ideal",
            vendor="Test",
            environment_type=EnvironmentType.simulator,
            access_mode=AccessMode.sdk,
            # No profile → ideal simulation
        ).model_dump())

        env_noisy = CandidateEnvironment(**EnvironmentCreate(
            name="Noisy",
            vendor="Test",
            environment_type=EnvironmentType.simulator,
            access_mode=AccessMode.sdk,
            profile=EnvironmentProfile(
                single_gate_error=0.02,
                two_gate_error=0.08,
                readout_error=0.05,
            ),
        ).model_dump())

        _, result_ideal = runner.run(
            ExperimentRun(workload_id=workload.id, environment_id=env_ideal.id),
            workload, env_ideal,
        )
        _, result_noisy = runner.run(
            ExperimentRun(workload_id=workload.id, environment_id=env_noisy.id),
            workload, env_noisy,
        )

        # Ideal should have higher fidelity (more peaked distribution)
        assert result_ideal.output_fidelity > result_noisy.output_fidelity

    def test_noisy_env_has_lower_success_rate(self):
        """Noisy environment should derive a lower success rate."""
        workload = _make_workload()
        runner = QiskitRunner(shots=2048)

        env_ideal = CandidateEnvironment(**EnvironmentCreate(
            name="Ideal",
            vendor="Test",
            environment_type=EnvironmentType.simulator,
            access_mode=AccessMode.sdk,
        ).model_dump())

        env_noisy = CandidateEnvironment(**EnvironmentCreate(
            name="Very Noisy",
            vendor="Test",
            environment_type=EnvironmentType.simulator,
            access_mode=AccessMode.sdk,
            profile=EnvironmentProfile(
                single_gate_error=0.05,
                two_gate_error=0.15,
                readout_error=0.10,
            ),
        ).model_dump())

        _, result_ideal = runner.run(
            ExperimentRun(workload_id=workload.id, environment_id=env_ideal.id),
            workload, env_ideal,
        )
        _, result_noisy = runner.run(
            ExperimentRun(workload_id=workload.id, environment_id=env_noisy.id),
            workload, env_noisy,
        )

        assert result_ideal.success_rate == 1.0  # ideal always succeeds
        assert result_noisy.success_rate < 1.0   # noisy has entropy

    def test_different_noise_levels_produce_different_fidelities(self):
        """Two noisy environments with different error rates should produce different fidelities."""
        workload = _make_workload()
        runner = QiskitRunner(shots=2048)

        env_mild = CandidateEnvironment(**EnvironmentCreate(
            name="Mild Noise",
            vendor="Test",
            environment_type=EnvironmentType.simulator,
            access_mode=AccessMode.sdk,
            profile=EnvironmentProfile(two_gate_error=0.01),
        ).model_dump())

        env_heavy = CandidateEnvironment(**EnvironmentCreate(
            name="Heavy Noise",
            vendor="Test",
            environment_type=EnvironmentType.simulator,
            access_mode=AccessMode.sdk,
            profile=EnvironmentProfile(two_gate_error=0.10),
        ).model_dump())

        _, result_mild = runner.run(
            ExperimentRun(workload_id=workload.id, environment_id=env_mild.id),
            workload, env_mild,
        )
        _, result_heavy = runner.run(
            ExperimentRun(workload_id=workload.id, environment_id=env_heavy.id),
            workload, env_heavy,
        )

        # Mild noise should give better fidelity than heavy noise
        assert result_mild.output_fidelity > result_heavy.output_fidelity

    def test_backend_description_reflects_profile(self):
        """Result notes should describe what backend was actually used."""
        workload = _make_workload()
        runner = QiskitRunner(shots=256)

        env_ideal = CandidateEnvironment(**EnvironmentCreate(
            name="Ideal", vendor="Test",
            environment_type=EnvironmentType.simulator,
            access_mode=AccessMode.sdk,
        ).model_dump())

        env_noisy = CandidateEnvironment(**EnvironmentCreate(
            name="Noisy", vendor="Test",
            environment_type=EnvironmentType.simulator,
            access_mode=AccessMode.sdk,
            profile=EnvironmentProfile(
                two_gate_error=0.05,
                readout_error=0.03,
            ),
        ).model_dump())

        _, result_ideal = runner.run(
            ExperimentRun(workload_id=workload.id, environment_id=env_ideal.id),
            workload, env_ideal,
        )
        _, result_noisy = runner.run(
            ExperimentRun(workload_id=workload.id, environment_id=env_noisy.id),
            workload, env_noisy,
        )

        assert "ideal" in result_ideal.notes.lower()
        assert "depolarizing" in result_noisy.notes.lower()
        assert "readout" in result_noisy.notes.lower()
