"""Tests for the result parser (alpha v2 real-data bridge)."""

import json
import pytest

from qlro.result_parser import (
    detect_format,
    parse_qiskit_result,
    parse_key_value,
    parse_result,
    ParseError,
)


# ── Format detection ──

def test_detect_qiskit_result():
    data = json.dumps({"backend_name": "aer_simulator", "results": [{}]})
    assert detect_format(data) == "qiskit_result"


def test_detect_key_value():
    text = "fidelity: 0.85\ncost: 4.50\nruntime: 12.3"
    assert detect_format(text) == "key_value"


def test_detect_unknown():
    assert detect_format("just some random text") == "unknown"


# ── Qiskit result parsing ──

QISKIT_RESULT = json.dumps({
    "backend_name": "aer_simulator",
    "backend_version": "0.14.1",
    "results": [{
        "shots": 4096,
        "success": True,
        "data": {"counts": {"0x0": 2010, "0x3": 2086}},
        "header": {"name": "circuit-0"},
    }],
    "time_taken": 0.42,
})


def test_parse_qiskit_basic():
    parsed = parse_qiskit_result(QISKIT_RESULT)
    assert parsed.actual_shots == 4096
    assert parsed.actual_runtime_sec == 0.42
    assert parsed.environment_chosen == "aer_simulator"
    assert parsed.actual_result.backend_name == "aer_simulator"
    assert parsed.actual_result.backend_version == "0.14.1"
    assert parsed.actual_result.import_format == "qiskit_result"
    assert parsed.actual_result.counts is not None
    assert sum(parsed.actual_result.counts.values()) == 4096


def test_parse_qiskit_fidelity_derived():
    parsed = parse_qiskit_result(QISKIT_RESULT)
    # Success probability should be the max count / shots
    assert parsed.actual_fidelity == round(2086 / 4096, 4)


def test_parse_qiskit_invalid_json():
    with pytest.raises(ParseError, match="Invalid JSON"):
        parse_qiskit_result("not json at all")


def test_parse_qiskit_missing_results():
    with pytest.raises(ParseError, match="missing 'results'"):
        parse_qiskit_result(json.dumps({"backend_name": "test"}))


# ── Key-value parsing ──

def test_parse_key_value_basic():
    text = "fidelity: 0.87\ncost: 4.50\nruntime: 12.3\nshots: 4096\nbackend: ibm_brisbane"
    parsed = parse_key_value(text)
    assert parsed.actual_fidelity == 0.87
    assert parsed.actual_cost_usd == 4.50
    assert parsed.actual_runtime_sec == 12.3
    assert parsed.actual_shots == 4096
    assert parsed.environment_chosen == "ibm_brisbane"
    assert parsed.actual_result.import_format == "key_value"


def test_parse_key_value_with_dollar_sign():
    text = "cost: $12.50"
    parsed = parse_key_value(text)
    assert parsed.actual_cost_usd == 12.50


def test_parse_key_value_partial():
    text = "fidelity: 0.92"
    parsed = parse_key_value(text)
    assert parsed.actual_fidelity == 0.92
    assert parsed.actual_cost_usd is None
    assert parsed.actual_shots is None


def test_parse_key_value_empty():
    with pytest.raises(ParseError, match="No key: value"):
        parse_key_value("just random text")


# ── Auto-detect parse ──

def test_parse_result_qiskit():
    parsed = parse_result(QISKIT_RESULT)
    assert parsed.actual_result.import_format == "qiskit_result"


def test_parse_result_key_value():
    parsed = parse_result("fidelity: 0.85\nruntime: 3.2")
    assert parsed.actual_result.import_format == "key_value"


def test_parse_result_unknown():
    with pytest.raises(ParseError, match="Could not detect"):
        parse_result("???")
