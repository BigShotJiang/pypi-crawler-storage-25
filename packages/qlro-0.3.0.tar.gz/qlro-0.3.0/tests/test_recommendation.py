"""Deterministic tests for the recommendation engine.

Uses hand-crafted NormalizedComparison objects so we can test
ranking, confidence, tradeoffs, and explanation without Qiskit.
"""

from uuid import uuid4

import pytest

from qlro.schemas import (
    CandidateEnvironment,
    ConfidenceLevel,
    EnvironmentType,
    AccessMode,
    NormalizedComparison,
    Workload,
    WorkloadCategory,
)
from qlro.recommendation.engine import recommend


# --- Helpers ---

def _make_workload(**overrides) -> Workload:
    defaults = dict(
        name="test",
        category=WorkloadCategory.optimization,
        objective="test objective",
        priority_cost=0.33,
        priority_speed=0.33,
        priority_confidence=0.34,
    )
    defaults.update(overrides)
    return Workload(**defaults)


def _make_env(name="Env", **overrides) -> CandidateEnvironment:
    defaults = dict(
        name=name,
        vendor="Test",
        environment_type=EnvironmentType.simulator,
        access_mode=AccessMode.sdk,
    )
    defaults.update(overrides)
    return CandidateEnvironment(**defaults)


def _make_comparison(
    workload_id, env_id,
    runtime=0.5, cost=0.5, confidence=0.5, feasibility=0.5,
    overall=None, assumptions=None,
) -> NormalizedComparison:
    if overall is None:
        overall = (runtime + cost + confidence + 0.1 * feasibility) / 3.1
    return NormalizedComparison(
        workload_id=workload_id,
        environment_id=env_id,
        experiment_result_id=uuid4(),
        runtime_score=runtime,
        cost_score=cost,
        confidence_score=confidence,
        feasibility_score=feasibility,
        overall_score=overall,
        assumptions=assumptions or [],
    )


# --- Ranking tests ---

class TestRecommendationRanking:
    def test_highest_score_wins(self):
        """Primary should be the environment with the highest overall score."""
        workload = _make_workload()
        env_a = _make_env("Env A")
        env_b = _make_env("Env B")
        env_map = {env_a.id: env_a, env_b.id: env_b}

        comps = [
            _make_comparison(workload.id, env_a.id, overall=0.85),
            _make_comparison(workload.id, env_b.id, overall=0.60),
        ]

        rec = recommend(workload, comps, env_map)
        assert rec.primary_environment_id == env_a.id
        assert rec.secondary_environment_id == env_b.id

    def test_ranking_with_three_environments(self):
        """With 3 envs, primary=best, secondary=2nd best."""
        workload = _make_workload()
        envs = [_make_env(f"Env {i}") for i in range(3)]
        env_map = {e.id: e for e in envs}

        comps = [
            _make_comparison(workload.id, envs[0].id, overall=0.50),
            _make_comparison(workload.id, envs[1].id, overall=0.90),
            _make_comparison(workload.id, envs[2].id, overall=0.70),
        ]

        rec = recommend(workload, comps, env_map)
        assert rec.primary_environment_id == envs[1].id
        assert rec.secondary_environment_id == envs[2].id

    def test_single_environment(self):
        """With one environment, primary is set, secondary is None."""
        workload = _make_workload()
        env = _make_env("Solo")
        env_map = {env.id: env}

        comps = [_make_comparison(workload.id, env.id, overall=0.75)]

        rec = recommend(workload, comps, env_map)
        assert rec.primary_environment_id == env.id
        assert rec.secondary_environment_id is None

    def test_empty_comparisons_raises(self):
        """Should raise ValueError with no comparisons."""
        workload = _make_workload()
        with pytest.raises(ValueError, match="no comparison data"):
            recommend(workload, [], {})


# --- Confidence tests ---

class TestConfidenceLabeling:
    def test_high_confidence_clear_winner(self):
        """Large gap + no assumptions → high confidence."""
        workload = _make_workload()
        env_a = _make_env("Winner")
        env_b = _make_env("Loser")
        env_map = {env_a.id: env_a, env_b.id: env_b}

        comps = [
            _make_comparison(workload.id, env_a.id, overall=0.90, assumptions=[]),
            _make_comparison(workload.id, env_b.id, overall=0.50, assumptions=[]),
        ]

        rec = recommend(workload, comps, env_map)
        assert rec.confidence_level == ConfidenceLevel.high

    def test_low_confidence_near_tie(self):
        """Very small gap → low confidence."""
        workload = _make_workload()
        env_a = _make_env("A")
        env_b = _make_env("B")
        env_map = {env_a.id: env_a, env_b.id: env_b}

        comps = [
            _make_comparison(workload.id, env_a.id, overall=0.71, assumptions=[]),
            _make_comparison(workload.id, env_b.id, overall=0.70, assumptions=[]),
        ]

        rec = recommend(workload, comps, env_map)
        assert rec.confidence_level == ConfidenceLevel.low

    def test_low_confidence_many_assumptions(self):
        """Many assumed data points → low confidence even with gap."""
        workload = _make_workload()
        env_a = _make_env("A")
        env_b = _make_env("B")
        env_map = {env_a.id: env_a, env_b.id: env_b}

        comps = [
            _make_comparison(workload.id, env_a.id, overall=0.85, assumptions=[
                "Runtime was not measured; defaulted to 0 (assumed)",
                "Cost was not measured (assumed)",
                "Fidelity was not measured; defaulted to 0 (assumed)",
            ]),
            _make_comparison(workload.id, env_b.id, overall=0.50, assumptions=[
                "Runtime was not measured; defaulted to 0 (assumed)",
                "Cost was not measured (assumed)",
            ]),
        ]

        rec = recommend(workload, comps, env_map)
        assert rec.confidence_level == ConfidenceLevel.low

    def test_medium_confidence_moderate_gap_some_estimates(self):
        """Moderate gap + multiple estimated data points → medium."""
        workload = _make_workload()
        env_a = _make_env("A")
        env_b = _make_env("B")
        env_map = {env_a.id: env_a, env_b.id: env_b}

        comps = [
            _make_comparison(workload.id, env_a.id, overall=0.75, assumptions=[
                "Cost is a user-provided estimate (estimated)",
                "Queue time is a user-provided estimate (estimated)",
            ]),
            _make_comparison(workload.id, env_b.id, overall=0.60, assumptions=[]),
        ]

        rec = recommend(workload, comps, env_map)
        assert rec.confidence_level == ConfidenceLevel.medium

    def test_single_env_with_assumed_data_is_low(self):
        """Single environment with assumed data → low."""
        workload = _make_workload()
        env = _make_env("Solo")
        env_map = {env.id: env}

        comps = [_make_comparison(workload.id, env.id, overall=0.80, assumptions=[
            "Cost was not measured (assumed)",
        ])]

        rec = recommend(workload, comps, env_map)
        assert rec.confidence_level == ConfidenceLevel.low

    def test_confidence_reasons_populated(self):
        """Confidence reasons should always be non-empty."""
        workload = _make_workload()
        env_a = _make_env("A")
        env_b = _make_env("B")
        env_map = {env_a.id: env_a, env_b.id: env_b}

        comps = [
            _make_comparison(workload.id, env_a.id, overall=0.80),
            _make_comparison(workload.id, env_b.id, overall=0.60),
        ]

        rec = recommend(workload, comps, env_map)
        assert len(rec.confidence_reasons) > 0


# --- Tradeoff tests ---

class TestTradeoffs:
    def test_tradeoffs_detected(self):
        """When secondary wins on a dimension, it should appear as a tradeoff."""
        workload = _make_workload()
        env_fast = _make_env("Fast")
        env_accurate = _make_env("Accurate")
        env_map = {env_fast.id: env_fast, env_accurate.id: env_accurate}

        comps = [
            _make_comparison(
                workload.id, env_fast.id,
                runtime=0.95, cost=0.5, confidence=0.3, feasibility=0.8, overall=0.70
            ),
            _make_comparison(
                workload.id, env_accurate.id,
                runtime=0.2, cost=0.5, confidence=0.95, feasibility=0.8, overall=0.65
            ),
        ]

        rec = recommend(workload, comps, env_map)

        # env_fast wins overall, but env_accurate wins on confidence
        confidence_tradeoff = [t for t in rec.tradeoffs if t.dimension == "Output confidence"]
        assert len(confidence_tradeoff) == 1
        assert confidence_tradeoff[0].favors == "Accurate"

        # env_fast should win on runtime
        runtime_tradeoff = [t for t in rec.tradeoffs if t.dimension == "Runtime"]
        assert len(runtime_tradeoff) == 1
        assert runtime_tradeoff[0].favors == "Fast"

    def test_no_tradeoffs_for_single_env(self):
        """Single environment should have no tradeoffs."""
        workload = _make_workload()
        env = _make_env("Solo")
        env_map = {env.id: env}

        comps = [_make_comparison(workload.id, env.id, overall=0.80)]
        rec = recommend(workload, comps, env_map)
        assert rec.tradeoffs == []

    def test_no_tradeoff_for_close_dimensions(self):
        """Dimensions within 0.05 should not generate tradeoffs."""
        workload = _make_workload()
        env_a = _make_env("A")
        env_b = _make_env("B")
        env_map = {env_a.id: env_a, env_b.id: env_b}

        comps = [
            _make_comparison(workload.id, env_a.id, runtime=0.52, cost=0.50, confidence=0.51, feasibility=0.50, overall=0.60),
            _make_comparison(workload.id, env_b.id, runtime=0.50, cost=0.50, confidence=0.50, feasibility=0.50, overall=0.55),
        ]

        rec = recommend(workload, comps, env_map)
        assert rec.tradeoffs == []  # All dimensions within 0.05


# --- Explanation tests ---

class TestExplanation:
    def test_explanation_has_logic(self):
        """Explanation should always contain scoring logic."""
        workload = _make_workload()
        env = _make_env("Solo")
        env_map = {env.id: env}

        comps = [_make_comparison(workload.id, env.id, overall=0.75)]
        rec = recommend(workload, comps, env_map)

        assert len(rec.explanation.recommendation_logic) > 0
        # Should mention the scoring formula
        logic_text = " ".join(rec.explanation.recommendation_logic)
        assert "speed" in logic_text.lower() or "weight" in logic_text.lower()

    def test_explanation_has_observed_scores(self):
        """Explanation observed section should contain the winning score."""
        workload = _make_workload()
        env = _make_env("Winner")
        env_map = {env.id: env}

        comps = [_make_comparison(workload.id, env.id, overall=0.75)]
        rec = recommend(workload, comps, env_map)

        observed_text = " ".join(rec.explanation.observed)
        assert "Winner" in observed_text
        assert "0.75" in observed_text

    def test_explanation_captures_assumed_data(self):
        """Assumed data from comparisons should appear in explanation."""
        workload = _make_workload()
        env = _make_env("Sparse")
        env_map = {env.id: env}

        comps = [_make_comparison(workload.id, env.id, overall=0.5, assumptions=[
            "Cost was not measured; defaulted to 0 (assumed)",
        ])]

        rec = recommend(workload, comps, env_map)
        assert len(rec.explanation.assumed) > 0

    def test_unknowns_when_few_environments(self):
        """Should flag when fewer than 3 environments were compared."""
        workload = _make_workload()
        env_a = _make_env("A")
        env_b = _make_env("B")
        env_map = {env_a.id: env_a, env_b.id: env_b}

        comps = [
            _make_comparison(workload.id, env_a.id, overall=0.80),
            _make_comparison(workload.id, env_b.id, overall=0.60),
        ]

        rec = recommend(workload, comps, env_map)
        unknowns_text = " ".join(rec.explanation.unknowns)
        assert "narrow" in unknowns_text.lower() or "fewer" in unknowns_text.lower()

    def test_next_step_varies_by_confidence(self):
        """Next step should differ for high vs low confidence."""
        workload = _make_workload()
        env_a = _make_env("A")
        env_b = _make_env("B")
        env_map = {env_a.id: env_a, env_b.id: env_b}

        # High confidence
        comps_high = [
            _make_comparison(workload.id, env_a.id, overall=0.95, assumptions=[]),
            _make_comparison(workload.id, env_b.id, overall=0.40, assumptions=[]),
        ]
        rec_high = recommend(workload, comps_high, env_map)

        # Low confidence
        comps_low = [
            _make_comparison(workload.id, env_a.id, overall=0.51, assumptions=[]),
            _make_comparison(workload.id, env_b.id, overall=0.50, assumptions=[]),
        ]
        rec_low = recommend(workload, comps_low, env_map)

        assert rec_high.next_step != rec_low.next_step
        assert "additional" in rec_low.next_step.lower() or "increase confidence" in rec_low.next_step.lower()
