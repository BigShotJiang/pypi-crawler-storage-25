"""Tests for the workload profiler and recommendation engine."""
import math

import pytest

from qlro.scoring.axes import Axis
from qlro.scoring.profiler import WorkloadSpec, profile_weights, explain_weights
from qlro.scoring.recommend import recommend


# ── Weight vector properties ──


class TestProfileWeights:
    """Verify that profile_weights produces physically sensible weight vectors."""

    def test_weights_sum_to_one(self):
        spec = WorkloadSpec(
            qubit_count=12, circuit_depth=200, two_qubit_gates=400,
            connectivity="all-to-all", accuracy="chemical", shots=1024,
        )
        weights = profile_weights(spec)
        assert math.isclose(sum(weights.values()), 1.0, abs_tol=1e-10)

    def test_weights_all_positive(self):
        spec = WorkloadSpec(
            qubit_count=5, circuit_depth=10, two_qubit_gates=5,
            connectivity="linear", accuracy="low", shots=100,
        )
        weights = profile_weights(spec)
        for w in weights.values():
            assert w >= 0

    def test_deep_circuit_increases_phi(self):
        """Deep circuits should push Φ weight higher than shallow ones."""
        shallow = WorkloadSpec(
            qubit_count=10, circuit_depth=10, two_qubit_gates=20,
            connectivity="linear", accuracy="medium", shots=1024,
        )
        deep = WorkloadSpec(
            qubit_count=10, circuit_depth=500, two_qubit_gates=20,
            connectivity="linear", accuracy="medium", shots=1024,
        )
        w_shallow = profile_weights(shallow)
        w_deep = profile_weights(deep)
        assert w_deep[Axis.PHI] > w_shallow[Axis.PHI]

    def test_high_accuracy_increases_f(self):
        """Chemical accuracy should push F weight higher than low accuracy."""
        low = WorkloadSpec(
            qubit_count=10, circuit_depth=50, two_qubit_gates=100,
            connectivity="linear", accuracy="low", shots=1024,
        )
        chem = WorkloadSpec(
            qubit_count=10, circuit_depth=50, two_qubit_gates=100,
            connectivity="linear", accuracy="chemical", shots=1024,
        )
        w_low = profile_weights(low)
        w_chem = profile_weights(chem)
        assert w_chem[Axis.F] > w_low[Axis.F]

    def test_all_to_all_increases_gamma(self):
        """All-to-all connectivity should push Γ weight higher than linear."""
        linear = WorkloadSpec(
            qubit_count=50, circuit_depth=50, two_qubit_gates=100,
            connectivity="linear", accuracy="medium", shots=1024,
        )
        full = WorkloadSpec(
            qubit_count=50, circuit_depth=50, two_qubit_gates=100,
            connectivity="all-to-all", accuracy="medium", shots=1024,
        )
        w_linear = profile_weights(linear)
        w_full = profile_weights(full)
        assert w_full[Axis.GAMMA] > w_linear[Axis.GAMMA]

    def test_high_shots_increases_t(self):
        """High shot count should push T weight higher."""
        low_shots = WorkloadSpec(
            qubit_count=10, circuit_depth=50, two_qubit_gates=100,
            connectivity="linear", accuracy="medium", shots=100,
        )
        high_shots = WorkloadSpec(
            qubit_count=10, circuit_depth=50, two_qubit_gates=100,
            connectivity="linear", accuracy="medium", shots=500000,
        )
        w_low = profile_weights(low_shots)
        w_high = profile_weights(high_shots)
        assert w_high[Axis.T] > w_low[Axis.T]

    def test_many_2q_gates_increases_f(self):
        """Many 2Q gates should increase F weight (error accumulation)."""
        few = WorkloadSpec(
            qubit_count=10, circuit_depth=50, two_qubit_gates=10,
            connectivity="linear", accuracy="medium", shots=1024,
        )
        many = WorkloadSpec(
            qubit_count=10, circuit_depth=50, two_qubit_gates=1000,
            connectivity="linear", accuracy="medium", shots=1024,
        )
        w_few = profile_weights(few)
        w_many = profile_weights(many)
        assert w_many[Axis.F] > w_few[Axis.F]

    def test_unknown_connectivity_uses_default(self):
        """Unknown connectivity pattern should not crash."""
        spec = WorkloadSpec(
            qubit_count=10, circuit_depth=50, two_qubit_gates=100,
            connectivity="custom-topology", accuracy="medium", shots=1024,
        )
        weights = profile_weights(spec)
        assert math.isclose(sum(weights.values()), 1.0, abs_tol=1e-10)


# ── Recommendation engine ──


class TestRecommend:
    """Verify end-to-end recommendation pipeline."""

    def test_recommendation_returns_two_devices(self):
        spec = WorkloadSpec(
            qubit_count=12, circuit_depth=200, two_qubit_gates=400,
            connectivity="all-to-all", accuracy="chemical", shots=1024,
        )
        rec = recommend(spec)
        assert rec.primary.device != ""
        assert rec.alternative.device != ""
        assert rec.primary.device != rec.alternative.device

    def test_primary_scores_higher_than_alternative(self):
        spec = WorkloadSpec(
            qubit_count=12, circuit_depth=200, two_qubit_gates=400,
            connectivity="all-to-all", accuracy="chemical", shots=1024,
        )
        rec = recommend(spec)
        assert rec.primary.value >= rec.alternative.value

    def test_all_scores_sorted_descending(self):
        spec = WorkloadSpec(
            qubit_count=20, circuit_depth=100, two_qubit_gates=200,
            connectivity="ring", accuracy="high", shots=5000,
        )
        rec = recommend(spec)
        for i in range(len(rec.all_scores) - 1):
            assert rec.all_scores[i].value >= rec.all_scores[i + 1].value

    def test_different_specs_can_change_ranking(self):
        """Different workload specs should produce different weight vectors,
        potentially changing the recommendation."""
        spec_chem = WorkloadSpec(
            qubit_count=4, circuit_depth=500, two_qubit_gates=800,
            connectivity="all-to-all", accuracy="chemical", shots=100,
        )
        spec_qaoa = WorkloadSpec(
            qubit_count=100, circuit_depth=5, two_qubit_gates=10,
            connectivity="linear", accuracy="low", shots=500000,
        )
        w_chem = profile_weights(spec_chem)
        w_qaoa = profile_weights(spec_qaoa)
        # The weight vectors should be meaningfully different
        diff = sum(abs(w_chem[a] - w_qaoa[a]) for a in Axis)
        assert diff > 0.3, f"Weight vectors too similar: {w_chem} vs {w_qaoa}"

    def test_confidence_field_valid(self):
        spec = WorkloadSpec(
            qubit_count=12, circuit_depth=200, two_qubit_gates=400,
            connectivity="all-to-all", accuracy="chemical", shots=1024,
        )
        rec = recommend(spec)
        assert rec.confidence in ("high", "medium", "low")

    def test_reason_mentions_device(self):
        spec = WorkloadSpec(
            qubit_count=12, circuit_depth=200, two_qubit_gates=400,
            connectivity="all-to-all", accuracy="chemical", shots=1024,
        )
        rec = recommend(spec)
        assert rec.primary.device in rec.reason

    def test_weight_explanation_not_empty(self):
        spec = WorkloadSpec(
            qubit_count=12, circuit_depth=200, two_qubit_gates=400,
            connectivity="all-to-all", accuracy="chemical", shots=1024,
        )
        rec = recommend(spec)
        assert len(rec.weight_explanation) > 0


# ── Explain weights ──


class TestExplainWeights:
    def test_explanation_contains_axis(self):
        spec = WorkloadSpec(
            qubit_count=12, circuit_depth=200, two_qubit_gates=400,
            connectivity="all-to-all", accuracy="chemical", shots=1024,
        )
        weights = profile_weights(spec)
        explanation = explain_weights(spec, weights)
        assert "Dominant axis" in explanation
        assert "Weight vector" in explanation
