"""Validation pack — automated checks for demo and product readiness.

Checks:
1. Ranking sensitivity: different priorities produce different rankings or scores
2. Category effects: different workload categories produce different fingerprints and scores
3. Confidence changes: data quality affects confidence level
4. Report readability: reports contain required sections and no raw engine internals
"""

from uuid import uuid4

from qlro.schemas import (
    CandidateEnvironment, EnvironmentCreate, EnvironmentProfile,
    EnvironmentType, AccessMode,
    ExperimentRun, Workload, WorkloadCreate, WorkloadCategory,
)
from qlro.runner import QiskitRunner
from qlro.comparison import normalize_results, apply_suitability
from qlro.recommendation import recommend
from qlro.export import generate_report

SEED = 42
SHOTS = 1024


def _make_envs():
    """Standard 3-environment set."""
    env_ideal = CandidateEnvironment(**EnvironmentCreate(
        name="Aer Ideal Simulator",
        vendor="IBM/Qiskit",
        environment_type=EnvironmentType.simulator,
        access_mode=AccessMode.sdk,
        max_qubits=30,
        estimated_cost_per_run=0.0,
        estimated_queue_time_sec=0.0,
    ).model_dump())

    env_noisy = CandidateEnvironment(**EnvironmentCreate(
        name="Aer Noisy Simulator",
        vendor="IBM/Qiskit",
        environment_type=EnvironmentType.simulator,
        access_mode=AccessMode.sdk,
        max_qubits=20,
        estimated_cost_per_run=0.0,
        estimated_queue_time_sec=0.0,
        profile=EnvironmentProfile(
            single_gate_error=0.001,
            two_gate_error=0.02,
            readout_error=0.015,
            connectivity="heavy_hex",
        ),
    ).model_dump())

    env_cloud = CandidateEnvironment(**EnvironmentCreate(
        name="IBM Brisbane (estimated)",
        vendor="IBM",
        environment_type=EnvironmentType.cloud_hardware,
        access_mode=AccessMode.api,
        max_qubits=127,
        estimated_cost_per_run=1.60,
        estimated_queue_time_sec=300.0,
        profile=EnvironmentProfile(
            single_gate_error=0.0003,
            two_gate_error=0.008,
            readout_error=0.012,
            t1_us=300.0,
            t2_us=150.0,
            connectivity="heavy_hex",
        ),
    ).model_dump())

    return [env_ideal, env_noisy, env_cloud]


def _run_pipeline(workload_kwargs, environments):
    """Run full pipeline and return (workload, comparisons, rec, report)."""
    workload = Workload(**WorkloadCreate(**workload_kwargs).model_dump())
    runner = QiskitRunner(shots=SHOTS, seed=SEED)

    results_pairs = []
    for env in environments:
        exp = ExperimentRun(workload_id=workload.id, environment_id=env.id)
        _, result = runner.run(exp, workload, env)
        results_pairs.append((env, result))

    comparisons = normalize_results(workload, results_pairs)
    env_map = {env.id: env for env in environments}
    comparisons = apply_suitability(workload, comparisons, env_map)

    rec = recommend(workload, comparisons, env_map)
    report = generate_report(workload, env_map, comparisons, rec, format="markdown")

    return workload, comparisons, rec, report, env_map


# ── 1. Ranking sensitivity ──

class TestRankingSensitivity:
    """Changing priority weights should change scores, even if primary holds."""

    def test_confidence_vs_cost_priorities_differ(self):
        """Same workload category, different priorities → different overall scores."""
        envs = _make_envs()

        _, comps_conf, rec_conf, _, _ = _run_pipeline(dict(
            name="VQE Confidence",
            category=WorkloadCategory.chemistry,
            objective="test",
            qubit_count_hint=4, circuit_depth_hint=8,
            priority_confidence=0.7, priority_speed=0.15, priority_cost=0.15,
        ), envs)

        _, comps_cost, rec_cost, _, _ = _run_pipeline(dict(
            name="VQE Cost",
            category=WorkloadCategory.chemistry,
            objective="test",
            qubit_count_hint=4, circuit_depth_hint=8,
            priority_cost=0.7, priority_speed=0.15, priority_confidence=0.15,
        ), envs)

        # Overall scores must differ between the two runs
        scores_conf = sorted(c.overall_score for c in comps_conf)
        scores_cost = sorted(c.overall_score for c in comps_cost)
        assert scores_conf != scores_cost, "Priority changes should affect overall scores"

    def test_speed_priority_changes_scores(self):
        """Speed-heavy vs confidence-heavy should produce different score distributions."""
        envs = _make_envs()

        _, comps_speed, _, _, _ = _run_pipeline(dict(
            name="Speed test",
            category=WorkloadCategory.optimization,
            objective="test",
            qubit_count_hint=6, circuit_depth_hint=3,
            priority_speed=0.7, priority_confidence=0.15, priority_cost=0.15,
        ), envs)

        _, comps_conf, _, _, _ = _run_pipeline(dict(
            name="Confidence test",
            category=WorkloadCategory.optimization,
            objective="test",
            qubit_count_hint=6, circuit_depth_hint=3,
            priority_confidence=0.7, priority_speed=0.15, priority_cost=0.15,
        ), envs)

        # At least one environment should get a different score
        scores_speed = sorted(c.overall_score for c in comps_speed)
        scores_conf = sorted(c.overall_score for c in comps_conf)
        diffs = [abs(a - b) for a, b in zip(scores_speed, scores_conf)]
        assert max(diffs) > 0.01, "Different priorities should change at least one score"


# ── 2. Category effects ──

class TestCategoryEffects:
    """Different workload categories should produce different suitability adjustments."""

    def test_chemistry_vs_optimization_differ(self):
        envs = _make_envs()

        _, comps_chem, _, _, _ = _run_pipeline(dict(
            name="Chemistry",
            category=WorkloadCategory.chemistry,
            objective="test",
            qubit_count_hint=4, circuit_depth_hint=8,
            priority_confidence=0.5, priority_speed=0.25, priority_cost=0.25,
        ), envs)

        _, comps_opt, _, _, _ = _run_pipeline(dict(
            name="Optimization",
            category=WorkloadCategory.optimization,
            objective="test",
            qubit_count_hint=4, circuit_depth_hint=8,
            priority_confidence=0.5, priority_speed=0.25, priority_cost=0.25,
        ), envs)

        # At least one environment should have different scores
        scores_chem = {c.environment_id: c.overall_score for c in comps_chem}
        scores_opt = {c.environment_id: c.overall_score for c in comps_opt}

        # Environment IDs differ between runs, so compare by sorted score lists
        sorted_chem = sorted(scores_chem.values())
        sorted_opt = sorted(scores_opt.values())
        assert sorted_chem != sorted_opt, "Category should affect suitability scores"

    def test_ml_category_produces_different_fingerprint(self):
        """ML workloads should have lower noise sensitivity than chemistry."""
        from qlro.schemas import compute_fingerprint

        wl_ml = Workload(**WorkloadCreate(
            name="ML", category=WorkloadCategory.ml,
            objective="test", qubit_count_hint=4,
            priority_confidence=0.4, priority_speed=0.3, priority_cost=0.3,
        ).model_dump())

        wl_chem = Workload(**WorkloadCreate(
            name="Chem", category=WorkloadCategory.chemistry,
            objective="test", qubit_count_hint=4,
            priority_confidence=0.4, priority_speed=0.3, priority_cost=0.3,
        ).model_dump())

        fp_ml = compute_fingerprint(wl_ml)
        fp_chem = compute_fingerprint(wl_chem)

        assert fp_ml.noise_sensitivity < fp_chem.noise_sensitivity
        assert fp_ml.fidelity_need < fp_chem.fidelity_need


# ── 3. Confidence changes ──

class TestConfidenceChanges:
    """Confidence should reflect data quality and score gaps."""

    def test_fewer_environments_lowers_confidence(self):
        """2 environments should not produce high confidence."""
        envs = _make_envs()[:2]  # Only ideal + noisy

        _, _, rec, _, _ = _run_pipeline(dict(
            name="Narrow field",
            category=WorkloadCategory.optimization,
            objective="test",
            qubit_count_hint=6, circuit_depth_hint=3,
            priority_confidence=0.5, priority_speed=0.25, priority_cost=0.25,
        ), envs)

        # With only 2 environments and estimated data, should not be high
        from qlro.schemas import ConfidenceLevel
        assert rec.confidence_level != ConfidenceLevel.high

    def test_confidence_reasons_are_populated(self):
        envs = _make_envs()

        _, _, rec, _, _ = _run_pipeline(dict(
            name="Reasons check",
            category=WorkloadCategory.optimization,
            objective="test",
            qubit_count_hint=6, circuit_depth_hint=3,
            priority_confidence=0.5, priority_speed=0.25, priority_cost=0.25,
        ), envs)

        assert len(rec.confidence_reasons) >= 2, "Should have multiple confidence reasons"
        assert all(isinstance(r, str) and len(r) > 5 for r in rec.confidence_reasons)


# ── 4. Report readability ──

class TestReportReadability:
    """Reports should be buyer-readable with no raw engine internals."""

    def _get_report(self):
        envs = _make_envs()
        _, _, _, report, _ = _run_pipeline(dict(
            name="Report check",
            category=WorkloadCategory.chemistry,
            objective="Find ground state energy",
            qubit_count_hint=4, circuit_depth_hint=8,
            priority_confidence=0.5, priority_speed=0.2, priority_cost=0.3,
        ), envs)
        return report

    def test_has_buyer_sections(self):
        report = self._get_report()
        assert "## Recommendation" in report
        assert "### Tradeoffs" in report
        assert "### Trust Checklist" in report
        assert "## Comparison Results" in report

    def test_has_technical_appendix(self):
        report = self._get_report()
        assert "## Technical Appendix" in report
        assert "## Workload" in report

    def test_no_raw_suitability_strings_in_buyer_section(self):
        """Raw 'Suitability:' strings should not appear before the appendix."""
        report = self._get_report()
        parts = report.split("## Technical Appendix")
        buyer_section = parts[0]
        assert "Suitability:" not in buyer_section, \
            "Raw suitability strings should not appear in buyer section"

    def test_scores_are_clamped(self):
        """No score should display above 1.00 in the comparison table."""
        report = self._get_report()
        import re
        # Find all bold scores in the table (overall scores)
        bold_scores = re.findall(r'\*\*(\d+\.\d+)\*\*', report)
        for score_str in bold_scores:
            assert float(score_str) <= 1.0, f"Score {score_str} exceeds 1.0"

    def test_report_has_fit_labels(self):
        report = self._get_report()
        assert "Best fit" in report
        # With 3 environments, should have "Not recommended" for last
        assert "Not recommended" in report or "Contender" in report

    def test_json_report_is_valid(self):
        """JSON format should produce valid, parseable JSON."""
        import json
        envs = _make_envs()
        workload = Workload(**WorkloadCreate(
            name="JSON check", category=WorkloadCategory.optimization,
            objective="test", qubit_count_hint=6,
            priority_confidence=0.5, priority_speed=0.25, priority_cost=0.25,
        ).model_dump())

        runner = QiskitRunner(shots=SHOTS, seed=SEED)
        results_pairs = []
        for env in envs:
            exp = ExperimentRun(workload_id=workload.id, environment_id=env.id)
            _, result = runner.run(exp, workload, env)
            results_pairs.append((env, result))

        comparisons = normalize_results(workload, results_pairs)
        env_map = {env.id: env for env in envs}
        comparisons = apply_suitability(workload, comparisons, env_map)
        rec = recommend(workload, comparisons, env_map)

        json_report = generate_report(workload, env_map, comparisons, rec, format="json")
        data = json.loads(json_report)
        assert "recommendation" in data
        assert "comparisons" in data
        assert len(data["comparisons"]) == 3
