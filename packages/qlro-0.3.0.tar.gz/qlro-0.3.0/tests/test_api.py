"""API-level tests — exercises endpoints via TestClient.

These tests serve as a regression guard for the SQLite threading bug:
FastAPI's TestClient dispatches requests on a different thread than the
one that imported the module and created the Database connection.
If check_same_thread is not disabled, these tests will raise
sqlite3.ProgrammingError.
"""

import pytest
from fastapi.testclient import TestClient

from qlro.api import app, db
from qlro.environments import seed_environments
from qlro.schemas import (
    EnvironmentType,
    AccessMode,
    WorkloadCategory,
)


@pytest.fixture(autouse=True)
def _clean_tables():
    """Wipe all tables before each test so tests are independent."""
    for table in ["workloads", "environments", "experiment_runs",
                  "experiment_results", "comparisons", "recommendations",
                  "comparison_runs"]:
        db._conn.execute(f"DELETE FROM {table}")
    db._conn.commit()
    # Re-seed default environments after wipe
    seed_environments(db)
    yield


@pytest.fixture
def client():
    return TestClient(app)


class TestAPIThreading:
    """Regression tests for SQLite cross-thread access."""

    def test_list_environments_seeded(self, client):
        resp = client.get("/environments")
        assert resp.status_code == 200
        envs = resp.json()
        assert len(envs) == 7  # seed environments

    def test_list_workloads_empty(self, client):
        resp = client.get("/workloads")
        assert resp.status_code == 200
        assert resp.json() == []

    def test_create_and_list_environment(self, client):
        payload = {
            "name": "Test Simulator",
            "vendor": "Test",
            "environment_type": EnvironmentType.simulator.value,
            "access_mode": AccessMode.sdk.value,
        }
        resp = client.post("/environments", json=payload)
        assert resp.status_code == 200
        env_id = resp.json()["id"]

        resp = client.get("/environments")
        assert resp.status_code == 200
        assert len(resp.json()) == 8  # 7 seeds + 1 new
        ids = [e["id"] for e in resp.json()]
        assert env_id in ids

    def test_create_and_get_workload(self, client):
        payload = {
            "name": "Test QAOA",
            "category": WorkloadCategory.optimization.value,
            "objective": "Test objective",
            "qubit_count_hint": 4,
            "circuit_depth_hint": 2,
        }
        resp = client.post("/workloads", json=payload)
        assert resp.status_code == 200
        wl_id = resp.json()["id"]

        resp = client.get(f"/workloads/{wl_id}")
        assert resp.status_code == 200
        assert resp.json()["name"] == "Test QAOA"

    def test_get_nonexistent_workload(self, client):
        resp = client.get("/workloads/00000000-0000-0000-0000-000000000000")
        assert resp.status_code == 404

    def test_get_nonexistent_environment(self, client):
        resp = client.get("/environments/00000000-0000-0000-0000-000000000000")
        assert resp.status_code == 404

    def test_compare_no_experiments(self, client):
        """Compare endpoint should 400 when no experiments exist."""
        payload = {
            "name": "Test",
            "category": WorkloadCategory.optimization.value,
            "objective": "Test",
        }
        resp = client.post("/workloads", json=payload)
        wl_id = resp.json()["id"]

        resp = client.post(f"/compare/{wl_id}")
        assert resp.status_code == 400


class TestShareableURL:
    """Regression tests for the shareable comparison URL flow.

    The full alpha loop: create comparison → get by ID → fresh fetch by ID.
    All three must return the same result without authentication.
    """

    def _env_ids(self, client):
        resp = client.get("/api/environments")
        envs = resp.json()
        return [envs[0]["id"], envs[1]["id"]]

    def _create_comparison(self, client):
        env_ids = self._env_ids(client)
        resp = client.post("/api/comparisons", json={
            "workload": {
                "name": "Shareable URL Test",
                "category": "optimization",
                "objective": "Verify persistence",
                "qubit_count_hint": 4,
                "circuit_depth_hint": 3,
                "priority_confidence": 0.5,
                "priority_speed": 0.3,
                "priority_cost": 0.2,
            },
            "environment_ids": env_ids,
        })
        assert resp.status_code == 201
        return resp.json()

    def test_create_and_retrieve_by_id(self, client):
        """Created comparison must be retrievable by ID."""
        created = self._create_comparison(client)
        cid = created["id"]

        resp = client.get(f"/api/comparisons/{cid}")
        assert resp.status_code == 200
        fetched = resp.json()
        assert fetched["id"] == cid
        assert fetched["workload_summary"]["name"] == "Shareable URL Test"
        assert fetched["recommendation_summary"]["primary"]

    def test_fresh_fetch_same_result(self, client):
        """Simulate fresh browser: two independent GETs return same data."""
        created = self._create_comparison(client)
        cid = created["id"]

        # First fetch (like the redirect after creation)
        resp1 = client.get(f"/api/comparisons/{cid}")
        assert resp1.status_code == 200

        # Second fetch (like opening shared URL in new browser)
        resp2 = client.get(f"/api/comparisons/{cid}")
        assert resp2.status_code == 200

        assert resp1.json() == resp2.json()

    def test_appears_in_list(self, client):
        """Created comparison must appear in the list endpoint."""
        created = self._create_comparison(client)
        cid = created["id"]

        resp = client.get("/api/comparisons")
        assert resp.status_code == 200
        items = resp.json()
        ids = [item["id"] for item in items]
        assert cid in ids

    def test_nonexistent_id_returns_404(self, client):
        """Unknown comparison ID must return 404, not 500."""
        resp = client.get("/api/comparisons/00000000-0000-0000-0000-000000000000")
        assert resp.status_code == 404

    def test_health_endpoint(self, client):
        """Health endpoint confirms database is functional."""
        resp = client.get("/api/health")
        assert resp.status_code == 200
        data = resp.json()
        assert data["status"] == "ok"
        assert data["database_exists"] is True
