"""Environment library — DB-backed with seed defaults.

On startup, seed environments are written to the DB if they don't exist.
Admin can add/edit/remove environments via the admin API.
The public API reads from DB.
"""

from __future__ import annotations

from uuid import UUID, uuid5, NAMESPACE_DNS
from typing import TYPE_CHECKING

from qlro.schemas import (
    CandidateEnvironment,
    EnvironmentCreate,
    EnvironmentProfile,
    EnvironmentType,
    AccessMode,
)

if TYPE_CHECKING:
    from qlro.storage import Database

# Deterministic namespace so seed IDs are stable across restarts
_NS = NAMESPACE_DNS


def _stable_id(name: str) -> UUID:
    """Generate a deterministic UUID from an environment name."""
    return uuid5(_NS, f"qlro.env.{name}")


SEED_ENVIRONMENTS: list[tuple[UUID, EnvironmentCreate]] = [
    (
        _stable_id("Aer Ideal Simulator"),
        EnvironmentCreate(
            name="Aer Ideal Simulator",
            vendor="IBM/Qiskit",
            environment_type=EnvironmentType.simulator,
            access_mode=AccessMode.sdk,
            max_qubits=30,
            estimated_cost_per_run=0.0,
            estimated_queue_time_sec=0.0,
        ),
    ),
    (
        _stable_id("Aer Noisy Simulator"),
        EnvironmentCreate(
            name="Aer Noisy Simulator",
            vendor="IBM/Qiskit",
            environment_type=EnvironmentType.simulator,
            access_mode=AccessMode.sdk,
            max_qubits=20,
            estimated_cost_per_run=0.0,
            estimated_queue_time_sec=0.0,
            profile=EnvironmentProfile(
                single_gate_error=0.001,
                two_gate_error=0.02,
                readout_error=0.015,
                connectivity="heavy_hex",
            ),
        ),
    ),
    (
        _stable_id("IBM Brisbane (estimated)"),
        EnvironmentCreate(
            name="IBM Brisbane (estimated)",
            vendor="IBM",
            environment_type=EnvironmentType.cloud_hardware,
            access_mode=AccessMode.api,
            max_qubits=127,
            estimated_cost_per_run=1.60,
            estimated_queue_time_sec=300.0,
            profile=EnvironmentProfile(
                single_gate_error=0.0003,
                two_gate_error=0.008,
                readout_error=0.012,
                t1_us=300.0,
                t2_us=150.0,
                connectivity="heavy_hex",
            ),
            notes="Profile based on public IBM Quantum specs",
        ),
    ),
    # ── AWS Braket backends (pricing from public AWS Braket docs) ──
    (
        _stable_id("Rigetti Ankaa-2 (Braket)"),
        EnvironmentCreate(
            name="Rigetti Ankaa-2 (Braket)",
            vendor="AWS / Rigetti",
            environment_type=EnvironmentType.cloud_hardware,
            access_mode=AccessMode.api,
            max_qubits=84,
            cost_per_task=0.30,
            cost_per_shot=0.00090,
            estimated_queue_time_sec=120.0,
            profile=EnvironmentProfile(
                single_gate_error=0.005,
                two_gate_error=0.05,
                readout_error=0.02,
                t1_us=20.0,
                t2_us=25.0,
                connectivity="grid",
            ),
            notes="Superconducting 84Q. Pricing: $0.30/task + $0.00090/shot. Noise profile from public Rigetti specs (estimated ranges).",
        ),
    ),
    (
        _stable_id("IonQ Forte (Braket)"),
        EnvironmentCreate(
            name="IonQ Forte (Braket)",
            vendor="AWS / IonQ",
            environment_type=EnvironmentType.cloud_hardware,
            access_mode=AccessMode.api,
            max_qubits=36,
            cost_per_task=0.30,
            cost_per_shot=0.08,
            estimated_queue_time_sec=600.0,
            profile=EnvironmentProfile(
                single_gate_error=0.0003,
                two_gate_error=0.004,
                readout_error=0.003,
                t1_us=10_000_000.0,  # trapped ion — effectively no T1 limit
                t2_us=1_000_000.0,
                connectivity="all_to_all",
            ),
            notes="Trapped-ion 36Q, all-to-all connectivity. Pricing: $0.30/task + $0.08/shot. Highest fidelity but highest cost on Braket.",
        ),
    ),
    (
        _stable_id("QuEra Aquila (Braket)"),
        EnvironmentCreate(
            name="QuEra Aquila (Braket)",
            vendor="AWS / QuEra",
            environment_type=EnvironmentType.cloud_hardware,
            access_mode=AccessMode.api,
            max_qubits=256,
            cost_per_task=0.30,
            cost_per_shot=0.01,
            estimated_queue_time_sec=180.0,
            profile=EnvironmentProfile(
                single_gate_error=0.005,
                two_gate_error=0.05,
                readout_error=0.02,
                connectivity="grid",
            ),
            notes="Neutral-atom 256Q analog QPU. Pricing: $0.30/task + $0.01/shot. Best suited for optimization / analog simulation workloads.",
        ),
    ),
    (
        _stable_id("IQM Garnet (Braket)"),
        EnvironmentCreate(
            name="IQM Garnet (Braket)",
            vendor="AWS / IQM",
            environment_type=EnvironmentType.cloud_hardware,
            access_mode=AccessMode.api,
            max_qubits=20,
            cost_per_task=0.30,
            cost_per_shot=0.00145,
            estimated_queue_time_sec=60.0,
            profile=EnvironmentProfile(
                single_gate_error=0.003,
                two_gate_error=0.025,
                readout_error=0.02,
                t1_us=30.0,
                t2_us=20.0,
                connectivity="grid",
            ),
            notes="Superconducting 20Q. Pricing: $0.30/task + $0.00145/shot. European provider, lower queue times.",
        ),
    ),
]


def seed_environments(db: Database) -> None:
    """Write seed environments to DB if they don't already exist."""
    for env_id, env_create in SEED_ENVIRONMENTS:
        existing = db.get("environments", env_id)
        if existing is None:
            env = CandidateEnvironment(id=env_id, **env_create.model_dump())
            db.save("environments", env)


def get_environments(db: Database) -> list[CandidateEnvironment]:
    """Return all environments from the DB."""
    return db.list_all("environments")


def get_environment_by_id(db: Database, env_id) -> CandidateEnvironment | None:
    """Look up an environment by UUID."""
    return db.get("environments", env_id)
