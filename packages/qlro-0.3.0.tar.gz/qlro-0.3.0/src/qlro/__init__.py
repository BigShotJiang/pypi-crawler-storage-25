"""Qlro: the evaluation layer for quantum pilot decisions.

Primary use is as an importable library:

    >>> from qiskit import QuantumCircuit
    >>> import qlro
    >>>
    >>> qc = QuantumCircuit(4)
    >>> qc.h(0); qc.cx(0, 1); qc.cx(1, 2); qc.cx(2, 3)
    >>> qc.measure_all()
    >>>
    >>> result = qlro.recommend(qc, category="chemistry")
    >>> result.primary
    'H2-2'
    >>> result  # auto-renders in Jupyter

See WCPP_SPEC.md and ROADMAP.md at the repo root for the full framework
and product context.
"""

from qlro.public_api import (
    CircuitInfo,
    DeviceRanking,
    Recommendation,
    log_outcome,
    recommend,
)
from qlro.scoring.priors import WorkloadCategory

__all__ = [
    "recommend",
    "log_outcome",
    "Recommendation",
    "DeviceRanking",
    "CircuitInfo",
    "WorkloadCategory",
]
