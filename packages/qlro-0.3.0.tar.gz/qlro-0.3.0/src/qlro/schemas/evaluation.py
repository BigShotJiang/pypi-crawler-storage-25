"""Evaluation outcome schema — Layer 2: Evaluation Memory.

An EvaluationOutcome is logged after a user runs their workload on a
real environment. It links back to the original ComparisonRun (the
prediction) and captures what actually happened.

Alpha v2 adds structured result data: measurement counts, success
probability, error rate, and backend metadata — so outcomes contain
real evidence, not just self-reported numbers.
"""

from datetime import datetime, timezone
from enum import Enum
from uuid import UUID, uuid4

from pydantic import BaseModel, Field


class OutcomeStatus(str, Enum):
    """Did the user follow the recommendation?"""

    followed = "followed"        # ran on the recommended environment
    alternative = "alternative"  # ran on a different environment
    abandoned = "abandoned"      # decided not to run at all


class ActualResult(BaseModel):
    """Structured result data from a real quantum run.

    All fields optional — users provide what they have.
    Can be populated manually or extracted from pasted Qiskit/Braket output.
    """

    # Measurement data
    counts: dict[str, int] | None = None       # e.g. {"00": 480, "11": 520}
    success_probability: float | None = None   # derived from counts or user-provided
    error_rate: float | None = None            # 1 - success_probability, or direct

    # Backend metadata
    backend_name: str | None = None            # e.g. "aer_simulator", "ibm_brisbane"
    backend_version: str | None = None         # e.g. "0.14.1"
    execution_date: str | None = None          # ISO date of the actual run

    # Import metadata
    import_format: str | None = None           # "qiskit_result" | "key_value" | "manual"
    raw_input: str | None = None               # original pasted text (for debugging)


class EvaluationOutcomeCreate(BaseModel):
    """Input for logging an actual outcome."""

    comparison_run_id: UUID
    environment_chosen: str                    # name of env actually used
    followed_recommendation: OutcomeStatus

    # Actual metrics (all optional — user may not have all of these)
    actual_fidelity: float | None = None       # 0–1, result quality
    actual_runtime_sec: float | None = None    # wall-clock seconds
    actual_cost_usd: float | None = None       # dollars spent
    actual_queue_time_sec: float | None = None # queue wait
    actual_shots: int | None = None

    # Structured result data (v2)
    actual_result: ActualResult | None = None

    # Free-text
    notes: str | None = None


class EvaluationOutcome(BaseModel):
    """Stored evaluation outcome with predicted-vs-actual deltas."""

    id: UUID = Field(default_factory=uuid4)
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

    comparison_run_id: UUID
    user_email: str | None = None

    # What was predicted
    predicted_environment: str       # Qlro's recommendation
    predicted_score: float | None    # overall score Qlro gave it
    predicted_confidence: str        # high / medium / low

    # What actually happened
    environment_chosen: str
    followed_recommendation: OutcomeStatus

    actual_fidelity: float | None = None
    actual_runtime_sec: float | None = None
    actual_cost_usd: float | None = None
    actual_queue_time_sec: float | None = None
    actual_shots: int | None = None

    # Structured result data (v2)
    actual_result: ActualResult | None = None

    notes: str | None = None

    # Computed deltas (populated at creation time)
    delta_fidelity: float | None = None      # actual - predicted confidence score
    delta_cost: float | None = None          # actual cost - predicted cost score


class EvaluationSummary(BaseModel):
    """Lightweight summary for listing evaluation history."""

    id: UUID
    comparison_run_id: UUID
    workload_name: str
    predicted_environment: str
    environment_chosen: str
    followed_recommendation: OutcomeStatus
    predicted_score: float | None
    actual_fidelity: float | None
    actual_cost_usd: float | None
    has_structured_result: bool = False       # whether actual_result was provided
    created_at: datetime
