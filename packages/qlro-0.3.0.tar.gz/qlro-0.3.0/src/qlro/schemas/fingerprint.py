"""Workload fingerprint — structured traits derived from workload fields.

A fingerprint captures how sensitive a workload is to different environment
characteristics. This drives suitability scoring: a workload with high
noise_sensitivity should be penalized on noisy environments.

All traits are 0-1 floats. Higher = more sensitive/demanding on that axis.

What is real:
- Trait computation from workload category and size hints is rule-based
  and documented. Each rule has a stated rationale.

What is approximate:
- The trait values are heuristic, not derived from circuit analysis.
  Future versions could analyze actual circuit structure (entanglement
  density, critical path depth, etc.).
"""

from pydantic import BaseModel, Field

from qlro.schemas.workload import Workload, WorkloadCategory


class WorkloadFingerprint(BaseModel):
    """Computed traits that describe what a workload demands from an environment."""

    noise_sensitivity: float = Field(
        ge=0, le=1,
        description="How much output quality degrades with gate/readout noise"
    )
    depth_sensitivity: float = Field(
        ge=0, le=1,
        description="How much the workload suffers from decoherence (deep circuits)"
    )
    qubit_pressure: float = Field(
        ge=0, le=1,
        description="How close the workload is to environment qubit limits"
    )
    cost_sensitivity: float = Field(
        ge=0, le=1,
        description="How much the user cares about cost (from priority weights)"
    )
    speed_sensitivity: float = Field(
        ge=0, le=1,
        description="How much the user cares about turnaround time"
    )
    fidelity_need: float = Field(
        ge=0, le=1,
        description="How much the workload requires high-fidelity output"
    )

    category: str = Field(description="Source workload category")
    rationale: list[str] = Field(
        default_factory=list,
        description="Human-readable explanation of how each trait was derived"
    )


def compute_fingerprint(workload: Workload) -> WorkloadFingerprint:
    """Compute a fingerprint from workload fields.

    Rules by category (documented rationale for each):

    - optimization: QAOA-style circuits have moderate depth, moderate
      entanglement. Noise sensitivity is moderate because variational
      algorithms can partially tolerate noise. Fidelity need is moderate.

    - simulation: Trotterized evolution circuits are deep and highly
      entangled. Very sensitive to noise and decoherence. High fidelity need.

    - chemistry: VQE/molecular simulation circuits are deep, require high
      fidelity to get chemically meaningful results. Very high noise and
      depth sensitivity.

    - ml: Quantum ML circuits are typically shallow with moderate
      entanglement. Lower noise sensitivity, but speed matters for
      iterative training.

    - custom: Unknown characteristics — use moderate defaults.
    """
    rationale = []

    # Category-based base traits
    category_traits = _CATEGORY_TRAITS.get(
        workload.category, _CATEGORY_TRAITS[WorkloadCategory.custom]
    )
    noise_sens = category_traits["noise_sensitivity"]
    depth_sens = category_traits["depth_sensitivity"]
    fidelity_need = category_traits["fidelity_need"]
    rationale.append(
        f"Base traits from category '{workload.category.value}': "
        f"noise_sensitivity={noise_sens}, depth_sensitivity={depth_sens}, "
        f"fidelity_need={fidelity_need}"
    )

    # Adjust depth sensitivity by circuit depth hint
    if workload.circuit_depth_hint is not None:
        if workload.circuit_depth_hint > 10:
            depth_sens = min(1.0, depth_sens + 0.2)
            rationale.append(f"Depth hint {workload.circuit_depth_hint} > 10: depth_sensitivity +0.2")
        elif workload.circuit_depth_hint <= 3:
            depth_sens = max(0.0, depth_sens - 0.15)
            rationale.append(f"Depth hint {workload.circuit_depth_hint} <= 3: depth_sensitivity -0.15")

    # Qubit pressure — relative to a reference (30 qubits = most simulators)
    qubit_pressure = 0.3  # default
    if workload.qubit_count_hint is not None:
        qubit_pressure = min(1.0, workload.qubit_count_hint / 30.0)
        rationale.append(
            f"Qubit pressure = {workload.qubit_count_hint}/30 = {qubit_pressure:.2f}"
        )
    else:
        rationale.append("No qubit hint — qubit_pressure defaulted to 0.3")

    # User priority passthrough
    cost_sens = workload.priority_cost
    speed_sens = workload.priority_speed
    rationale.append(
        f"Cost/speed sensitivity from user priorities: "
        f"cost={cost_sens}, speed={speed_sens}"
    )

    return WorkloadFingerprint(
        noise_sensitivity=round(noise_sens, 2),
        depth_sensitivity=round(depth_sens, 2),
        qubit_pressure=round(qubit_pressure, 2),
        cost_sensitivity=round(cost_sens, 2),
        speed_sensitivity=round(speed_sens, 2),
        fidelity_need=round(fidelity_need, 2),
        category=workload.category.value,
        rationale=rationale,
    )


# --- Category trait lookup table ---
# Each value has a documented reason in the compute_fingerprint docstring.

_CATEGORY_TRAITS: dict[WorkloadCategory, dict[str, float]] = {
    WorkloadCategory.optimization: {
        "noise_sensitivity": 0.5,
        "depth_sensitivity": 0.5,
        "fidelity_need": 0.5,
    },
    WorkloadCategory.simulation: {
        "noise_sensitivity": 0.8,
        "depth_sensitivity": 0.8,
        "fidelity_need": 0.8,
    },
    WorkloadCategory.chemistry: {
        "noise_sensitivity": 0.9,
        "depth_sensitivity": 0.85,
        "fidelity_need": 0.95,
    },
    WorkloadCategory.ml: {
        "noise_sensitivity": 0.3,
        "depth_sensitivity": 0.3,
        "fidelity_need": 0.4,
    },
    WorkloadCategory.custom: {
        "noise_sensitivity": 0.5,
        "depth_sensitivity": 0.5,
        "fidelity_need": 0.5,
    },
}
