"""Experiment run and result schemas."""

from datetime import datetime, timezone
from enum import Enum
from typing import Any
from uuid import UUID, uuid4

from pydantic import BaseModel, Field


class RunType(str, Enum):
    simulation = "simulation"
    hardware = "hardware"
    estimated = "estimated"


class RunStatus(str, Enum):
    pending = "pending"
    running = "running"
    completed = "completed"
    failed = "failed"


class ExperimentRunCreate(BaseModel):
    """Input for creating an experiment run."""

    workload_id: UUID
    environment_id: UUID
    run_type: RunType = RunType.simulation


class ExperimentRun(ExperimentRunCreate):
    """Stored experiment run."""

    id: UUID = Field(default_factory=uuid4)
    status: RunStatus = RunStatus.pending
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    completed_at: datetime | None = None


class ExperimentResultCreate(BaseModel):
    """Input for recording experiment results."""

    experiment_run_id: UUID
    measured_runtime_sec: float | None = None
    estimated_cost_usd: float | None = None
    output_fidelity: float | None = Field(default=None, ge=0, le=1)
    success_rate: float | None = Field(default=None, ge=0, le=1)
    raw_counts: dict[str, int] | None = None
    notes: str | None = None


class ExperimentResult(ExperimentResultCreate):
    """Stored experiment result."""

    id: UUID = Field(default_factory=uuid4)
