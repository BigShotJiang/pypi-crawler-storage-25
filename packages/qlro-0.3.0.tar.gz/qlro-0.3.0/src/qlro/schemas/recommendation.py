"""Recommendation schema — the core product output."""

from datetime import datetime, timezone
from enum import Enum
from uuid import UUID, uuid4

from pydantic import BaseModel, Field


class ConfidenceLevel(str, Enum):
    high = "high"
    medium = "medium"
    low = "low"


class Tradeoff(BaseModel):
    """A specific tradeoff the user should be aware of."""
    dimension: str          # e.g. "cost", "runtime", "confidence"
    favors: str             # environment name that wins on this dimension
    description: str        # human-readable explanation


class ExplanationSection(BaseModel):
    """Structured explanation separating observed/estimated/assumed/recommended."""
    observed: list[str] = Field(default_factory=list)
    estimated: list[str] = Field(default_factory=list)
    assumed: list[str] = Field(default_factory=list)
    recommendation_logic: list[str] = Field(default_factory=list)
    unknowns: list[str] = Field(default_factory=list)


class RecommendationCreate(BaseModel):
    """Input for creating a recommendation."""

    workload_id: UUID
    primary_environment_id: UUID
    secondary_environment_id: UUID | None = None
    rationale: str
    confidence_level: ConfidenceLevel
    confidence_reasons: list[str] = Field(default_factory=list)
    tradeoffs: list[Tradeoff] = Field(default_factory=list)
    explanation: ExplanationSection = Field(default_factory=ExplanationSection)
    assumptions: list[str] = Field(default_factory=list)
    next_step: str


class Recommendation(RecommendationCreate):
    """Stored recommendation."""

    id: UUID = Field(default_factory=uuid4)
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
