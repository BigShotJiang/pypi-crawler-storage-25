"""Normalized comparison schema."""

from uuid import UUID, uuid4

from pydantic import BaseModel, Field


class ComparisonCreate(BaseModel):
    """Input for a normalized comparison row."""

    workload_id: UUID
    environment_id: UUID
    experiment_result_id: UUID
    runtime_score: float = Field(ge=0, le=1, description="0=best, 1=worst")
    cost_score: float = Field(ge=0, le=1, description="0=best, 1=worst")
    confidence_score: float = Field(ge=0, le=1, description="1=best, 0=worst")
    feasibility_score: float = Field(ge=0, le=1, description="1=best, 0=worst")
    overall_score: float = Field(description="Weighted composite — higher is better")
    assumptions: list[str] = Field(default_factory=list)


class NormalizedComparison(ComparisonCreate):
    """Stored normalized comparison."""

    id: UUID = Field(default_factory=uuid4)
