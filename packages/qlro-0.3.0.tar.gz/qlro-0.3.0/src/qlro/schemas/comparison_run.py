"""ComparisonRun schema — the saved unit of a full comparison result.

This is what gets a shareable URL. It stores the complete denormalized
result blob so the frontend can render it without re-running anything.
"""

from datetime import datetime, timezone
from uuid import UUID, uuid4

from pydantic import BaseModel, Field

from qlro.schemas.workload import WorkloadCreate


class ComparisonRunCreate(BaseModel):
    """Input for running a new comparison."""

    workload: WorkloadCreate
    environment_ids: list[UUID] = Field(min_length=2)
    user_email: str | None = None


class ComparisonRunSummary(BaseModel):
    """Lightweight summary for listing past comparisons."""

    id: UUID
    workload_name: str
    workload_category: str
    primary: str
    confidence: str
    created_at: datetime


class ComparisonRun(BaseModel):
    """Full saved comparison result."""

    id: UUID = Field(default_factory=uuid4)
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

    user_email: str | None = None

    # Denormalized result — everything the frontend needs
    workload_summary: dict
    recommendation_summary: dict
    comparisons: list[dict]
    trust: dict
    fingerprint: dict
    appendix: dict
