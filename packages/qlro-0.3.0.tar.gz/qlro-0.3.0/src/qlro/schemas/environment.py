"""Candidate environment schema — where a workload could run."""

from enum import Enum
from uuid import UUID, uuid4

from pydantic import BaseModel, Field


class EnvironmentType(str, Enum):
    simulator = "simulator"
    cloud_hardware = "cloud_hardware"
    on_premise = "on_premise"
    hybrid = "hybrid"


class AccessMode(str, Enum):
    api = "api"
    sdk = "sdk"
    manual = "manual"


class EnvironmentProfile(BaseModel):
    """Structured performance/noise characteristics for an environment.

    This is the core data that makes environments meaningfully different
    from each other in comparisons. All fields are optional — missing fields
    are tagged as 'assumed' with documented defaults in the normalization layer.
    """

    # Noise characteristics
    single_gate_error: float | None = Field(
        default=None, ge=0, le=1,
        description="Typical single-qubit gate error rate (0 = ideal)"
    )
    two_gate_error: float | None = Field(
        default=None, ge=0, le=1,
        description="Typical two-qubit gate error rate (0 = ideal)"
    )
    readout_error: float | None = Field(
        default=None, ge=0, le=1,
        description="Typical measurement/readout error rate (0 = ideal)"
    )
    t1_us: float | None = Field(
        default=None, ge=0,
        description="T1 relaxation time in microseconds"
    )
    t2_us: float | None = Field(
        default=None, ge=0,
        description="T2 dephasing time in microseconds"
    )

    # Connectivity
    connectivity: str | None = Field(
        default=None,
        description="Qubit connectivity topology: 'all_to_all', 'linear', 'grid', 'heavy_hex'"
    )

    # Practical characteristics
    typical_queue_minutes: float | None = Field(
        default=None, ge=0,
        description="Typical queue wait time in minutes"
    )
    max_circuits_per_job: int | None = Field(
        default=None, ge=1,
        description="Max circuits allowed per job submission"
    )
    availability_percent: float | None = Field(
        default=None, ge=0, le=100,
        description="Typical system availability percentage"
    )


class EnvironmentCreate(BaseModel):
    """Input schema for creating a candidate environment."""

    name: str
    vendor: str
    environment_type: EnvironmentType
    access_mode: AccessMode = AccessMode.sdk
    max_qubits: int | None = None
    # Cost model: when per-shot pricing is available, cost = cost_per_task + (shots × cost_per_shot)
    # Falls back to estimated_cost_per_run when per-shot fields are absent
    cost_per_task: float | None = Field(
        default=None, ge=0,
        description="Fixed per-task/per-job fee in USD"
    )
    cost_per_shot: float | None = Field(
        default=None, ge=0,
        description="Per-shot fee in USD"
    )
    estimated_cost_per_run: float | None = None
    estimated_queue_time_sec: float | None = None
    noise_model: str | None = None
    profile: EnvironmentProfile | None = None
    notes: str | None = None


class CandidateEnvironment(EnvironmentCreate):
    """Stored candidate environment with ID."""

    id: UUID = Field(default_factory=uuid4)
