"""Workload schema — defines what the user wants to validate."""

from datetime import datetime, timezone
from enum import Enum
from uuid import UUID, uuid4

from pydantic import BaseModel, Field


class WorkloadCategory(str, Enum):
    optimization = "optimization"
    simulation = "simulation"
    chemistry = "chemistry"
    ml = "ml"
    custom = "custom"


class WorkloadCreate(BaseModel):
    """Input schema for creating a workload."""

    name: str
    category: WorkloadCategory
    objective: str = Field(description="What the workload is trying to achieve")
    circuit_depth_hint: int | None = None
    qubit_count_hint: int | None = None
    qasm_circuit: str | None = Field(
        default=None,
        description="OpenQASM 2.0 circuit string. When provided, this is used "
        "instead of the auto-generated reference circuit.",
    )
    shots: int = Field(
        default=1024, ge=1, le=1_000_000,
        description="Number of measurement shots per circuit execution",
    )
    priority_cost: float = Field(default=0.33, ge=0, le=1)
    priority_speed: float = Field(default=0.33, ge=0, le=1)
    priority_confidence: float = Field(default=0.34, ge=0, le=1)
    notes: str | None = None


class Workload(WorkloadCreate):
    """Stored workload with ID and timestamp."""

    id: UUID = Field(default_factory=uuid4)
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
