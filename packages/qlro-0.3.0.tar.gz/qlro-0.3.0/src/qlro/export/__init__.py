"""Report export module."""

from qlro.export.report import generate_report

__all__ = ["generate_report"]
