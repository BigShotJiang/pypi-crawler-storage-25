"""Report generator — produces structured comparison + recommendation reports.

V1: JSON and plain-text markdown reports.
Reports include: workload summary, comparison table, recommendation,
tradeoffs, structured explanation (observed/estimated/assumed/logic),
unknowns, and assumptions.
"""

import json
from datetime import datetime, timezone
from uuid import UUID

from qlro.schemas import (
    CandidateEnvironment,
    NormalizedComparison,
    Recommendation,
    Workload,
)


class _ReportEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, UUID):
            return str(obj)
        if isinstance(obj, datetime):
            return obj.isoformat()
        return super().default(obj)


def generate_report(
    workload: Workload,
    environments: dict,  # UUID -> CandidateEnvironment
    comparisons: list[NormalizedComparison],
    recommendation: Recommendation,
    format: str = "markdown",
) -> str:
    if format == "json":
        return _json_report(workload, environments, comparisons, recommendation)
    return _markdown_report(workload, environments, comparisons, recommendation)


def _markdown_report(
    workload: Workload,
    environments: dict,
    comparisons: list[NormalizedComparison],
    recommendation: Recommendation,
) -> str:
    primary_env = environments[recommendation.primary_environment_id]
    secondary_env = (
        environments[recommendation.secondary_environment_id]
        if recommendation.secondary_environment_id
        else None
    )
    ranked = sorted(comparisons, key=lambda c: c.overall_score, reverse=True)
    primary_comp = ranked[0]
    secondary_comp = ranked[1] if len(ranked) > 1 else None
    expl = recommendation.explanation

    # ══════════════════════════════════════════════
    #  BUYER-FACING SECTION
    # ══════════════════════════════════════════════

    lines = [
        "# Qlro Comparison Report",
        "",
        f"**Generated:** {datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M UTC')}",
        "",
        "## Recommendation",
        "",
        f"**Primary:** {primary_env.name}",
    ]

    if secondary_env:
        lines.append(f"**Secondary:** {secondary_env.name}")

    lines.append(f"**Confidence:** {recommendation.confidence_level.value}")

    # Why the winner won
    lines.extend(["", f"### Why {primary_env.name}"])
    lines.append(recommendation.rationale)

    # Why the runner-up placed second
    if secondary_env and secondary_comp:
        lines.extend(["", f"### Why not {secondary_env.name}"])
        lines.append(
            _why_not_runner_up(primary_comp, primary_env, secondary_comp, secondary_env)
        )

    # One-sentence note for lowest-ranked
    if len(ranked) >= 3:
        last_comp = ranked[-1]
        last_env = environments[last_comp.environment_id]
        lines.extend(["", f"### {last_env.name}"])
        lines.append(_why_last(last_comp, last_env, primary_comp, primary_env))

    # Tradeoffs
    lines.extend(_build_tradeoffs_section(recommendation, secondary_env))

    # What to do next
    lines.extend(["", "### What to Do Next", recommendation.next_step])

    # Trust checklist
    lines.extend(_build_trust_checklist(expl, comparisons))

    # Confidence reasons
    if recommendation.confidence_reasons:
        lines.extend(["", f"**Why {recommendation.confidence_level.value} confidence:**"])
        for r in recommendation.confidence_reasons:
            lines.append(f"- {r}")

    # Comparison table
    lines.extend([
        "",
        "## Comparison Results",
        "",
        "| # | Environment | Runtime | Cost | Confidence | Feasibility | Overall | Fit |",
        "|---|-------------|---------|------|------------|-------------|---------|-----|",
    ])

    fit_labels = _fit_labels(len(ranked))
    for i, comp in enumerate(ranked):
        env = environments[comp.environment_id]
        clamped = min(comp.overall_score, 1.0)
        lines.append(
            f"| {i+1} | {env.name} | {comp.runtime_score:.2f} | {comp.cost_score:.2f} | "
            f"{comp.confidence_score:.2f} | {comp.feasibility_score:.2f} | "
            f"**{clamped:.2f}** | {fit_labels[i]} |"
        )

    lines.extend(["", "*Scores are 0–1. Higher is better.*"])

    # ══════════════════════════════════════════════
    #  TECHNICAL APPENDIX
    # ══════════════════════════════════════════════

    lines.extend(["", "---", "", "## Technical Appendix"])

    # Workload context
    lines.extend([
        "",
        "## Workload",
        f"- **Name:** {workload.name}",
        f"- **Category:** {workload.category.value}",
        f"- **Objective:** {workload.objective}",
        f"- **Priorities:** speed={workload.priority_speed:.0%}, "
        f"cost={workload.priority_cost:.0%}, confidence={workload.priority_confidence:.0%}",
    ])

    # Methodology
    if expl.observed or expl.estimated or expl.assumed or expl.recommendation_logic:
        lines.extend(["", "## How This Recommendation Was Made"])

        if expl.observed:
            lines.extend(["", "### What We Measured"])
            for item in expl.observed:
                lines.append(f"- {item}")

        if expl.estimated:
            lines.extend(["", "### What Was Estimated"])
            for item in expl.estimated:
                lines.append(f"- {item}")

        if expl.assumed:
            lines.extend(["", "### What We Had to Guess"])
            for item in expl.assumed:
                lines.append(f"- {item}")

        if expl.recommendation_logic:
            lines.extend(["", "### How We Ranked the Options"])
            for item in _plain_language_logic(expl.recommendation_logic):
                lines.append(f"- {item}")

    # Unknowns
    if expl.unknowns:
        lines.extend(["", "## What We Don't Know"])
        for item in expl.unknowns:
            lines.append(f"- {item}")

    # What could change — buyer-readable, no raw suitability strings
    if recommendation.assumptions:
        buyer_items = _buyer_assumptions(recommendation.assumptions)
        if buyer_items:
            lines.extend(["", "## What Could Change This Recommendation"])
            for a in buyer_items:
                lines.append(f"- {a}")

    lines.extend(["", "---", "*Report generated by Qlro v0.1.0*"])
    return "\n".join(lines)


# ── Plain-language helpers ──

def _fit_labels(count: int) -> list[str]:
    """Generate fit labels for ranked environments."""
    if count == 1:
        return ["Best fit"]
    labels = ["Best fit", "Contender"]
    labels.extend(["Not recommended"] * max(0, count - 2))
    return labels


def _build_trust_checklist(
    expl,
    comparisons: list[NormalizedComparison],
) -> list[str]:
    """Short trust summary for the buyer, with stability assessment."""
    measured = len(expl.observed)
    estimated = len(expl.estimated)
    guessed = len(expl.assumed)

    # Count profile-derived: suitability notes in any comparison's assumptions
    profile_derived = sum(
        1 for c in comparisons for a in c.assumptions if "Suitability:" in a
    )

    lines = ["", "### Trust Checklist"]
    lines.append(f"- **Measured:** {measured} data points from actual experiments")
    if estimated:
        lines.append(f"- **Estimated:** {estimated} values provided by users, not measured")
    if guessed:
        lines.append(f"- **Guessed:** {guessed} values defaulted due to missing data")
    if profile_derived:
        lines.append(f"- **Profile-derived:** {profile_derived} adjustments inferred from environment specs")

    # Stability assessment — the key buyer question
    risk_factors = []
    if estimated:
        risk_factors.append("real cost or queue time differs from current estimates")
    if guessed:
        risk_factors.append("missing data is filled in with actual measurements")
    if profile_derived:
        risk_factors.append("live calibration data replaces estimated noise profiles")

    if not risk_factors:
        lines.append("- **Stability:** This recommendation is based entirely on measured data and is unlikely to change.")
    elif guessed:
        lines.append(
            f"- **Stability:** Directionally useful, but may change if {risk_factors[0]}."
        )
    else:
        lines.append(
            f"- **Stability:** Likely stable. Could shift if {risk_factors[0]}."
        )

    return lines


def _buyer_assumptions(assumptions: list[str]) -> list[str]:
    """Filter and rewrite assumptions for buyer readability.

    Removes raw suitability strings (those belong in the appendix).
    Rewrites provenance tags into plain language.
    """
    result = []
    seen = set()
    for a in assumptions:
        # Skip raw suitability engine notes
        if a.startswith("Suitability:"):
            continue
        # Deduplicate
        if a in seen:
            continue
        seen.add(a)
        # Rewrite provenance tags
        clean = a.replace(" (estimated)", "").replace(" (assumed)", "").replace(" (observed)", "")
        if "(estimated)" in a:
            result.append(f"{clean} — if actual values differ, the ranking may shift")
        elif "(assumed)" in a:
            result.append(f"{clean} — this was guessed due to missing data and should be verified")
        else:
            result.append(clean)
    return result


def _plain_language_logic(items: list[str]) -> list[str]:
    """Rewrite scoring logic bullets into buyer-friendly language."""
    result = []
    for item in items:
        if item.startswith("Scoring weights:"):
            result.append(item.replace("Scoring weights:", "Your priorities were weighted as:"))
        elif item.startswith("All dimension scores normalized"):
            result.append(
                "Each environment was scored 0–1 on every dimension so they could be compared fairly."
            )
        elif item.startswith("Provenance discounting"):
            result.append(
                "Measured data counted fully. User-provided estimates were discounted 20%. "
                "Guessed values were discounted 50%."
            )
        elif item.startswith("Suitability adjustments"):
            result.append(
                "Scores were adjusted based on how well each environment matches your workload type."
            )
        elif item.startswith("Overall ="):
            result.append(
                "The final score combines all dimensions, weighted by your stated priorities."
            )
        elif item.startswith("Workload fingerprint"):
            # Keep but reword slightly
            result.append(item.replace("Workload fingerprint", "Workload profile"))
        else:
            # Dimension breakdowns, suitability notes — pass through
            result.append(item)
    return result


def _build_tradeoffs_section(
    recommendation: Recommendation,
    secondary_env: CandidateEnvironment | None,
) -> list[str]:
    """Build tradeoffs section. If winner leads everywhere, say so."""
    lines = ["", "### Tradeoffs"]

    if not recommendation.tradeoffs:
        lines.append(
            "No major tradeoffs. The recommended option leads across all "
            "dimensions for this workload."
        )
        return lines

    # Check if the runner-up actually wins on any dimension
    runner_up_wins = [
        t for t in recommendation.tradeoffs
        if secondary_env and t.favors == secondary_env.name
    ]

    if not runner_up_wins:
        lines.append(
            "No major tradeoffs. The recommended option leads across all key "
            "dimensions for this workload."
        )
        return lines

    for t in recommendation.tradeoffs:
        lines.append(f"- **{t.dimension}:** {t.description}")

    return lines


def _why_not_runner_up(
    primary: NormalizedComparison,
    primary_env: CandidateEnvironment,
    secondary: NormalizedComparison,
    secondary_env: CandidateEnvironment,
) -> str:
    """One paragraph explaining why the runner-up didn't win."""
    weaknesses = []
    if secondary.confidence_score < primary.confidence_score - 0.1:
        weaknesses.append("lower result confidence")
    if secondary.cost_score < primary.cost_score - 0.1:
        weaknesses.append("higher cost")
    if secondary.runtime_score < primary.runtime_score - 0.1:
        weaknesses.append("slower runtime")
    if secondary.feasibility_score < primary.feasibility_score - 0.1:
        weaknesses.append("less practical to access")

    # What the runner-up does better
    advantages = []
    if secondary.confidence_score > primary.confidence_score + 0.1:
        advantages.append("result confidence")
    if secondary.cost_score > primary.cost_score + 0.1:
        advantages.append("cost")
    if secondary.runtime_score > primary.runtime_score + 0.1:
        advantages.append("speed")
    if secondary.feasibility_score > primary.feasibility_score + 0.1:
        advantages.append("accessibility")

    parts = []

    if weaknesses:
        parts.append(f"{secondary_env.name} fell behind due to {', '.join(weaknesses)}.")
    else:
        parts.append(f"{secondary_env.name} scored close but didn't lead where it mattered most.")

    if advantages:
        parts.append(
            f"It does score better on {', '.join(advantages)}, "
            f"so it remains a valid alternative if those factors matter more to you."
        )
    else:
        parts.append(
            f"It did not lead on any individual dimension, making {primary_env.name} "
            f"the clear choice."
        )

    return " ".join(parts)


def _why_last(
    last: NormalizedComparison,
    _last_env: CandidateEnvironment,
    primary: NormalizedComparison,
    _primary_env: CandidateEnvironment,
) -> str:
    """One sentence for the lowest-ranked environment."""
    weaknesses = []
    if last.confidence_score < primary.confidence_score - 0.2:
        weaknesses.append("low result confidence")
    if last.cost_score < primary.cost_score - 0.2:
        weaknesses.append("high cost")
    if last.runtime_score < primary.runtime_score - 0.2:
        weaknesses.append("slow runtime")
    if last.feasibility_score < primary.feasibility_score - 0.2:
        weaknesses.append("limited accessibility")

    if weaknesses:
        return f"Ranked last due to {', '.join(weaknesses)}. Not recommended for initial validation."
    return f"Ranked last overall. Not recommended for initial validation."


def _json_report(
    workload: Workload,
    environments: dict,
    comparisons: list[NormalizedComparison],
    recommendation: Recommendation,
) -> str:
    ranked = sorted(comparisons, key=lambda c: c.overall_score, reverse=True)
    report = {
        "workload": workload.model_dump(mode="json"),
        "comparisons": [
            {
                "environment": environments[c.environment_id].model_dump(mode="json"),
                "scores": {
                    "runtime": c.runtime_score,
                    "cost": c.cost_score,
                    "confidence": c.confidence_score,
                    "feasibility": c.feasibility_score,
                    "overall": c.overall_score,
                },
                "assumptions": c.assumptions,
            }
            for c in ranked
        ],
        "recommendation": {
            "primary_environment": environments[
                recommendation.primary_environment_id
            ].name,
            "secondary_environment": (
                environments[recommendation.secondary_environment_id].name
                if recommendation.secondary_environment_id
                else None
            ),
            "confidence": recommendation.confidence_level.value,
            "confidence_reasons": recommendation.confidence_reasons,
            "rationale": recommendation.rationale,
            "tradeoffs": [t.model_dump() for t in recommendation.tradeoffs],
            "next_step": recommendation.next_step,
            "assumptions": recommendation.assumptions,
        },
        "explanation": recommendation.explanation.model_dump(),
        "generated_at": datetime.now(timezone.utc).isoformat(),
    }
    return json.dumps(report, indent=2, cls=_ReportEncoder)
