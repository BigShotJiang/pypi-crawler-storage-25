"""Public Python API — the canonical entry point for Qlro as a library.

This is what `import qlro` exposes. It is deliberately small: `recommend()`
and `log_outcome()`. Everything else (WCPP internals, data loading, axes)
lives under `qlro.scoring.*` for power users who want to go deeper.

The goal is to fit into an existing Jupyter / Python workflow with zero
context switching:

    >>> from qiskit import QuantumCircuit
    >>> import qlro
    >>>
    >>> qc = QuantumCircuit(4)
    >>> qc.h(0); qc.cx(0, 1); qc.cx(1, 2); qc.cx(2, 3)
    >>> qc.measure_all()
    >>>
    >>> result = qlro.recommend(qc, category="chemistry")
    >>> result  # auto-renders as a table in Jupyter
    >>> result.primary
    'H2-2'

See WCPP_SPEC.md for the full framework specification.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from qlro.scoring.composition import FitScore
from qlro.scoring.data_loader import MetriqSnapshot
from qlro.scoring.priors import WorkloadCategory, workload_weights
from qlro.scoring.wcpp import qlro_fit

# Default priority split — confidence-heavy, matching RESEARCH.md's
# "quantum teams running real workloads" persona where result quality
# matters most.
DEFAULT_PRIORITIES = {"confidence": 0.6, "cost": 0.25, "speed": 0.15}


@dataclass
class CircuitInfo:
    """Lightweight circuit metadata extracted from a Qiskit circuit.

    Kept as a separate struct so Qlro does not require the user's
    `QuantumCircuit` object to live on the Recommendation forever.
    """

    num_qubits: int | None = None
    depth: int | None = None
    total_gates: int | None = None
    two_qubit_gates: int | None = None
    op_counts: dict[str, int] = field(default_factory=dict)
    has_measurements: bool = False

    @classmethod
    def from_qiskit(cls, circuit) -> "CircuitInfo":
        """Extract metadata from a Qiskit QuantumCircuit.

        Fails gracefully if the argument isn't a Qiskit circuit.
        """
        try:
            num_qubits = int(circuit.num_qubits)
        except Exception:
            num_qubits = None
        try:
            depth = int(circuit.depth())
        except Exception:
            depth = None
        try:
            op_counts = dict(circuit.count_ops())
        except Exception:
            op_counts = {}
        try:
            total_gates = int(circuit.size())
        except Exception:
            total_gates = None
        try:
            # A heuristic for 2Q count: any op whose name hints at CX / CZ / ECR etc.
            two_qubit_names = {
                "cx", "cz", "ecr", "iswap", "swap", "rzz", "rxx", "ryy", "cp",
                "cry", "crx", "crz", "ccx",
            }
            two_qubit_gates = sum(
                count for name, count in op_counts.items() if name in two_qubit_names
            )
        except Exception:
            two_qubit_gates = None
        try:
            has_measurements = any(
                name == "measure" for name in op_counts
            )
        except Exception:
            has_measurements = False

        return cls(
            num_qubits=num_qubits,
            depth=depth,
            total_gates=total_gates,
            two_qubit_gates=two_qubit_gates,
            op_counts=op_counts,
            has_measurements=has_measurements,
        )


@dataclass
class DeviceRanking:
    """One row in a Recommendation's ranking table."""

    device: str
    provider: str | None
    num_qubits: int | None
    fit: float
    uncertainty: float | None
    any_axis_estimated: bool
    axes: dict[str, float]  # {"Gamma": 0.85, "Phi": 0.7, "F": 0.93, "T": 0.5}
    benchmark_count: int  # how many benchmarks backed this score

    def __repr__(self) -> str:
        unc = f" ± {self.uncertainty:.3f}" if self.uncertainty is not None else ""
        flag = "*" if self.any_axis_estimated else ""
        return f"{self.device}: {self.fit:.4f}{unc}{flag}"


@dataclass
class Recommendation:
    """The public-facing result of `qlro.recommend()`.

    Inspectable as a Python object, auto-renders as an HTML table in Jupyter.
    """

    category: str
    priorities: dict[str, float]
    shots: int
    rankings: list[DeviceRanking]
    circuit_info: CircuitInfo | None
    snapshot_commit: str | None
    snapshot_synced_at: str | None
    note: str | None = None  # warning/caveat about v1 limitations

    @property
    def primary(self) -> str:
        return self.rankings[0].device if self.rankings else ""

    @property
    def primary_fit(self) -> float:
        return self.rankings[0].fit if self.rankings else 0.0

    @property
    def primary_uncertainty(self) -> float | None:
        return self.rankings[0].uncertainty if self.rankings else None

    @property
    def secondary(self) -> str | None:
        return self.rankings[1].device if len(self.rankings) > 1 else None

    def show(self) -> None:
        """Print a terminal-friendly ranking table."""
        print(self._terminal_table())

    def _terminal_table(self) -> str:
        lines = [
            f"Qlro recommendation — category={self.category}, "
            f"shots={self.shots}, priorities={self.priorities}",
            "",
        ]
        if self.note:
            lines.append(f"⚠  {self.note}")
            lines.append("")
        if self.circuit_info:
            ci = self.circuit_info
            lines.append(
                f"Circuit: {ci.num_qubits}Q depth={ci.depth} "
                f"total_ops={ci.total_gates} 2Q_ops={ci.two_qubit_gates}"
            )
            lines.append("")
        lines.append(
            f"{'rank':<5} {'device':<22} {'provider':<12} {'qubits':<7} "
            f"{'fit':<8} {'±σ':<8} {'Γ':<6} {'Φ':<6} {'F':<6} {'T':<6}  notes"
        )
        lines.append("-" * 100)
        for i, r in enumerate(self.rankings, 1):
            flag = " (estimated)" if r.any_axis_estimated else ""
            unc = f"{r.uncertainty:.3f}" if r.uncertainty is not None else "  —  "
            lines.append(
                f"{i:<5} {r.device:<22} {(r.provider or '?'):<12} "
                f"{(r.num_qubits or 0):<7} {r.fit:<8.4f} {unc:<8} "
                f"{r.axes.get('Gamma', 0):<6.3f} {r.axes.get('Phi', 0):<6.3f} "
                f"{r.axes.get('F', 0):<6.3f} {r.axes.get('T', 0):<6.3f}  "
                f"{r.benchmark_count} benchmarks{flag}"
            )
        lines.append("")
        if self.snapshot_commit:
            lines.append(
                f"Data: Metriq @ {self.snapshot_commit[:10]}"
                + (f" (synced {self.snapshot_synced_at})" if self.snapshot_synced_at else "")
            )
        return "\n".join(lines)

    def _repr_html_(self) -> str:
        """Jupyter notebook rendering."""
        rows = []
        for i, r in enumerate(self.rankings, 1):
            highlight = (
                "background: #10DFF614; font-weight: 600;" if i == 1 else ""
            )
            flag = "⚠" if r.any_axis_estimated else ""
            unc = (
                f" <span style='color: #8C94A8; font-size: 11px;'>± {r.uncertainty:.3f}</span>"
                if r.uncertainty is not None
                else ""
            )
            axis_html = " ".join(
                f"<span style='display: inline-block; min-width: 42px; font-family: monospace; "
                f"color: #E2E6ED;'>{axis}={r.axes.get(axis, 0):.2f}</span>"
                for axis in ("Gamma", "Phi", "F", "T")
            )
            rows.append(
                f"<tr style='{highlight}'>"
                f"<td style='padding: 6px 10px;'>{i}</td>"
                f"<td style='padding: 6px 10px;'>{r.device} {flag}</td>"
                f"<td style='padding: 6px 10px; color: #8C94A8;'>{r.provider or '?'}</td>"
                f"<td style='padding: 6px 10px; color: #8C94A8;'>{r.num_qubits or '?'}Q</td>"
                f"<td style='padding: 6px 10px; font-family: monospace;'>"
                f"<b>{r.fit:.4f}</b>{unc}</td>"
                f"<td style='padding: 6px 10px;'>{axis_html}</td>"
                f"<td style='padding: 6px 10px; color: #8C94A8; font-size: 11px;'>"
                f"{r.benchmark_count} benchmarks</td>"
                f"</tr>"
            )
        ci_html = ""
        if self.circuit_info:
            ci = self.circuit_info
            ci_html = (
                f"<div style='color: #8C94A8; font-size: 12px; margin-bottom: 6px;'>"
                f"Circuit: {ci.num_qubits}Q · depth={ci.depth} · "
                f"total_ops={ci.total_gates} · 2Q_ops={ci.two_qubit_gates}"
                f"</div>"
            )
        note_html = ""
        if self.note:
            note_html = (
                f"<div style='color: #D8AC44; font-size: 12px; margin-bottom: 6px;'>"
                f"⚠ {self.note}</div>"
            )
        commit_html = ""
        if self.snapshot_commit:
            commit_html = (
                f"<div style='color: #5C6578; font-size: 11px; "
                f"margin-top: 8px; font-family: monospace;'>"
                f"Data: Metriq @ {self.snapshot_commit[:10]}</div>"
            )
        return f"""
<div style='background: #191E26; border: 1px solid #272E3A; border-radius: 8px;
            padding: 16px; color: #E2E6ED; font-family: -apple-system, sans-serif;'>
  <div style='font-size: 11px; font-weight: 700; text-transform: uppercase;
              letter-spacing: 0.1em; color: #5C6578; margin-bottom: 4px;'>
    Qlro recommendation
  </div>
  <div style='font-size: 13px; color: #8C94A8; margin-bottom: 10px;'>
    category={self.category} · shots={self.shots} ·
    priorities={self.priorities}
  </div>
  {note_html}
  {ci_html}
  <table style='width: 100%; border-collapse: collapse; font-size: 13px;'>
    <thead>
      <tr style='border-bottom: 1px solid #272E3A; color: #5C6578;
                 font-size: 11px; text-transform: uppercase; letter-spacing: 0.08em;'>
        <th style='padding: 6px 10px; text-align: left;'>#</th>
        <th style='padding: 6px 10px; text-align: left;'>Device</th>
        <th style='padding: 6px 10px; text-align: left;'>Provider</th>
        <th style='padding: 6px 10px; text-align: left;'>Qubits</th>
        <th style='padding: 6px 10px; text-align: left;'>Fit</th>
        <th style='padding: 6px 10px; text-align: left;'>Axes (Γ Φ F T)</th>
        <th style='padding: 6px 10px; text-align: left;'>Coverage</th>
      </tr>
    </thead>
    <tbody>
      {"".join(rows)}
    </tbody>
  </table>
  {commit_html}
</div>
""".strip()


def _coerce_circuit_to_info(circuit: Any) -> CircuitInfo | None:
    """Best-effort extraction of circuit metadata from a Qiskit-like object.

    Returns None if the argument is None or doesn't expose Qiskit-style methods.
    """
    if circuit is None:
        return None
    try:
        return CircuitInfo.from_qiskit(circuit)
    except Exception:
        return None


def _normalize_priorities(priorities: dict[str, float] | None) -> dict[str, float]:
    """Ensure priorities sum to 1 and contain the three canonical keys."""
    if not priorities:
        return dict(DEFAULT_PRIORITIES)
    merged = dict(DEFAULT_PRIORITIES)
    for k, v in priorities.items():
        if k in merged:
            merged[k] = float(v)
    total = sum(merged.values()) or 1.0
    return {k: v / total for k, v in merged.items()}


def _ranking_from_fit(
    fit: FitScore,
    provider: str | None,
    num_qubits: int | None,
    benchmark_count: int,
) -> DeviceRanking:
    """Convert a WCPP FitScore into a public-facing DeviceRanking row."""
    axes = fit.axis_values.as_dict()
    return DeviceRanking(
        device=fit.device,
        provider=provider,
        num_qubits=num_qubits,
        fit=fit.value,
        uncertainty=fit.uncertainty,
        any_axis_estimated=fit.any_axis_estimated,
        axes={axis.value: av.value for axis, av in axes.items()},
        benchmark_count=benchmark_count,
    )


def recommend(
    circuit: Any = None,
    category: str = WorkloadCategory.CHEMISTRY,
    priorities: dict[str, float] | None = None,
    shots: int = 1024,
    devices: list[str] | None = None,
    snapshot: MetriqSnapshot | None = None,
) -> Recommendation:
    """Recommend the best quantum device for a workload.

    Parameters
    ----------
    circuit:
        Optional Qiskit `QuantumCircuit`. Used for metadata display.
        In Phase 1M v1, the circuit is NOT used to derive workload weights —
        that comes later. For now, the `category` argument controls scoring.
    category:
        Workload category. One of: "chemistry", "simulation", "optimization", "ml".
    priorities:
        Dict with keys "confidence", "cost", "speed". Sum is normalized to 1.
        In v1, priorities are recorded but only "confidence" actually affects
        the ranking. Cost and runtime wiring lands in a later phase.
    shots:
        Shot count (informational; not used for scoring in v1).
    devices:
        Optional list of device names to restrict the candidate set. If None,
        ranks every device in the Metriq snapshot.
    snapshot:
        Optional pre-loaded MetriqSnapshot. If None, uses the default path.

    Returns
    -------
    Recommendation
        Ranked list of devices with axis breakdown, auditable to a Metriq
        commit hash. Use `result.primary` for the top pick, `result.show()`
        for terminal printing, or just return the object in a Jupyter cell
        for auto-rendering.
    """
    snap = snapshot or MetriqSnapshot()
    candidates = devices if devices is not None else snap.devices()

    rankings: list[DeviceRanking] = []
    for device_name in candidates:
        try:
            device_record = snap.device(device_name)
        except KeyError:
            continue
        try:
            fit = qlro_fit(device_name, category, snapshot=snap)
        except Exception:
            continue
        rankings.append(
            _ranking_from_fit(
                fit=fit,
                provider=device_record.provider,
                num_qubits=device_record.num_qubits,
                benchmark_count=len(device_record.readings),
            )
        )

    # Sort by fit descending. Ties broken by less-estimated-axes first.
    rankings.sort(
        key=lambda r: (-r.fit, r.any_axis_estimated)
    )

    norm_priorities = _normalize_priorities(priorities)
    circuit_info = _coerce_circuit_to_info(circuit)

    note = (
        "v1 limitation: priorities (cost/speed) are not yet wired into scoring. "
        "Ranking currently reflects WCPP fit score only."
    )

    return Recommendation(
        category=category,
        priorities=norm_priorities,
        shots=shots,
        rankings=rankings,
        circuit_info=circuit_info,
        snapshot_commit=snap.source_commit,
        snapshot_synced_at=snap.synced_at,
        note=note,
    )


def log_outcome(
    recommendation: Recommendation,
    actual_result: Any = None,
    actually_ran_on: str | None = None,
    observed_fidelity: float | None = None,
    **_kwargs: Any,
) -> dict[str, Any]:
    """Record that a user ran a workload after getting a recommendation.

    Phase 1M v1 is a stub: it returns a summary dict and does not yet persist
    to the storage layer. Phase 1N will connect this to the existing
    evaluation_outcomes table via the storage module.

    Parameters
    ----------
    recommendation:
        The Recommendation object returned by `recommend()`.
    actual_result:
        A Qiskit `Result` object or None. If provided, we extract counts
        and infer fidelity from the dominant outcome.
    actually_ran_on:
        Device name the user actually used (may differ from the recommendation).
    observed_fidelity:
        Optional explicit fidelity value if the user measured one.
    """
    chosen = actually_ran_on or recommendation.primary
    followed = chosen == recommendation.primary

    fidelity = observed_fidelity
    counts_sum = None
    if fidelity is None and actual_result is not None:
        try:
            counts = actual_result.get_counts()
            counts_sum = sum(counts.values())
            dominant = max(counts.values())
            fidelity = dominant / counts_sum if counts_sum else None
        except Exception:
            pass

    predicted_row = next(
        (r for r in recommendation.rankings if r.device == chosen), None
    )
    delta_fit = None
    if fidelity is not None and predicted_row is not None:
        # Very rough comparison — raw fidelity vs composite fit isn't a clean
        # equivalent, but it gives a first-order delta the user can see.
        delta_fit = fidelity - predicted_row.fit

    return {
        "recommended": recommendation.primary,
        "actually_ran_on": chosen,
        "followed_recommendation": followed,
        "observed_fidelity": fidelity,
        "shots_measured": counts_sum,
        "predicted_fit": predicted_row.fit if predicted_row else None,
        "delta_fit": delta_fit,
        "category": recommendation.category,
        "snapshot_commit": recommendation.snapshot_commit,
        "note": (
            "Phase 1M v1 stub — not yet persisted to storage. "
            "Use this return value directly for now."
        ),
    }
