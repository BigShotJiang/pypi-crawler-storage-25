"""Simple JSON-file-backed storage for V1.

Uses SQLite via a thin wrapper. Keeping it simple — no ORM complexity needed
for V1's data volume. Each entity type gets a table with id + json blob.
"""

import json
import sqlite3
from pathlib import Path
from uuid import UUID

from qlro.schemas import (
    CandidateEnvironment,
    ComparisonRun,
    EvaluationOutcome,
    ExperimentResult,
    ExperimentRun,
    NormalizedComparison,
    Recommendation,
    Workload,
)


class _UUIDEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, UUID):
            return str(obj)
        return super().default(obj)


TABLES = [
    "workloads",
    "environments",
    "experiment_runs",
    "experiment_results",
    "comparisons",
    "recommendations",
    "comparison_runs",
    "evaluation_outcomes",
]

MODEL_MAP = {
    "workloads": Workload,
    "environments": CandidateEnvironment,
    "experiment_runs": ExperimentRun,
    "experiment_results": ExperimentResult,
    "comparisons": NormalizedComparison,
    "recommendations": Recommendation,
    "comparison_runs": ComparisonRun,
    "evaluation_outcomes": EvaluationOutcome,
}


class Database:
    """Minimal SQLite storage. Each table stores id TEXT PK + data JSON."""

    def __init__(self, db_path: str | Path = "qlro.db"):
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._conn = sqlite3.connect(str(self.db_path), check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        self._init_tables()

    def _init_tables(self):
        for table in TABLES:
            self._conn.execute(
                f"CREATE TABLE IF NOT EXISTS {table} "
                "(id TEXT PRIMARY KEY, data TEXT NOT NULL)"
            )
        self._conn.commit()

    def save(self, table: str, obj) -> None:
        """Save a Pydantic model to the given table."""
        data = obj.model_dump_json()
        obj_id = str(obj.id)
        self._conn.execute(
            f"INSERT OR REPLACE INTO {table} (id, data) VALUES (?, ?)",
            (obj_id, data),
        )
        self._conn.commit()

    def get(self, table: str, obj_id: str | UUID):
        """Retrieve a single object by ID."""
        model_cls = MODEL_MAP[table]
        row = self._conn.execute(
            f"SELECT data FROM {table} WHERE id = ?", (str(obj_id),)
        ).fetchone()
        if row is None:
            return None
        return model_cls.model_validate_json(row["data"])

    def list_all(self, table: str) -> list:
        """List all objects in a table."""
        model_cls = MODEL_MAP[table]
        rows = self._conn.execute(f"SELECT data FROM {table}").fetchall()
        return [model_cls.model_validate_json(row["data"]) for row in rows]

    def query(self, table: str, **filters) -> list:
        """List objects matching simple field filters."""
        all_objs = self.list_all(table)
        results = []
        for obj in all_objs:
            match = True
            for key, value in filters.items():
                obj_val = getattr(obj, key, None)
                if isinstance(obj_val, UUID):
                    obj_val = str(obj_val)
                if str(obj_val) != str(value):
                    match = False
                    break
            if match:
                results.append(obj)
        return results

    def delete(self, table: str, obj_id: str | UUID) -> bool:
        """Delete an object by ID. Returns True if a row was deleted."""
        cursor = self._conn.execute(
            f"DELETE FROM {table} WHERE id = ?", (str(obj_id),)
        )
        self._conn.commit()
        return cursor.rowcount > 0

    def count(self, table: str) -> int:
        """Return the number of rows in a table."""
        row = self._conn.execute(f"SELECT COUNT(*) as cnt FROM {table}").fetchone()
        return row["cnt"]

    def close(self):
        self._conn.close()
