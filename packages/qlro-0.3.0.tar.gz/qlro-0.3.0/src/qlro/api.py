"""FastAPI application — Qlro API (alpha).

Alpha product endpoints:
- POST /api/comparisons — run full pipeline from user input
- GET  /api/comparisons/{id} — fetch saved result
- GET  /api/comparisons — list past comparisons
- DELETE /api/comparisons/{id} — delete a comparison
- GET  /api/environments — environment library

Evaluation endpoints (Layer 2):
- POST /api/evaluations — log actual outcome for a comparison
- GET  /api/evaluations — list all evaluation outcomes
- GET  /api/evaluations/{id} — fetch single evaluation
- GET  /api/evaluations/metrics — proof metrics (follow rate, accuracy, calibration)
- GET  /api/comparisons/{id}/evaluations — evaluations for a comparison

Admin endpoints (require QLRO_ADMIN_TOKEN):
- GET  /api/admin/stats — dashboard stats
- GET  /api/admin/environments — list all environments
- POST /api/admin/environments — create environment
- PUT  /api/admin/environments/{id} — update environment
- DELETE /api/admin/environments/{id} — delete environment
- GET  /api/admin/comparisons — list comparisons with pagination
- DELETE /api/admin/comparisons/{id} — delete comparison
"""

import os
from pathlib import Path
from uuid import UUID

from fastapi import FastAPI, HTTPException, Header, Depends
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel as PydanticBaseModel

from qlro.schemas import (
    CandidateEnvironment,
    ComparisonRun,
    ComparisonRunCreate,
    EnvironmentCreate,
    EvaluationOutcome,
    EvaluationOutcomeCreate,
    ExperimentResult,
    ExperimentRun,
    ExperimentRunCreate,
    Workload,
    WorkloadCreate,
)
from qlro.storage import Database
from qlro.runner import QiskitRunner
from qlro.runner.circuits import CircuitParseError
from qlro.result_parser import parse_result, ParseError
from qlro.comparison import normalize_results, apply_suitability, serialize_result
from qlro.recommendation import recommend
from qlro.export import generate_report
from qlro.environments import seed_environments, get_environments, get_environment_by_id

app = FastAPI(
    title="Qlro",
    description="Quantum environment comparison and recommendation API",
    version="0.1.0",
)

# CORS — allow the Vercel frontend
allowed_origins = os.environ.get(
    "ALLOWED_ORIGINS", "http://localhost:3000"
).split(",")

app.add_middleware(
    CORSMiddleware,
    allow_origins=allowed_origins,
    allow_methods=["*"],
    allow_headers=["*"],
)

db_path = Path(os.environ.get("DATABASE_PATH", "qlro.db"))
db = Database(db_path)
runner = QiskitRunner(shots=2048, seed=42)

# Seed default environments on startup
seed_environments(db)

ADMIN_TOKEN = os.environ.get("QLRO_ADMIN_TOKEN", "qlro-admin-dev")


# ═══════════════════════════════════════════
#  AUTH
# ═══════════════════════════════════════════


def require_admin(authorization: str = Header(None)):
    """Dependency: verify admin token from Authorization header."""
    if not authorization:
        raise HTTPException(401, "Missing Authorization header")
    # Accept "Bearer <token>" or raw token
    token = authorization.removeprefix("Bearer ").strip()
    if token != ADMIN_TOKEN:
        raise HTTPException(403, "Invalid admin token")


@app.get("/api/health")
def health():
    """Alpha diagnostic endpoint: confirm DB path, persistence, and state."""
    comparisons = db.list_all("comparison_runs")
    return {
        "status": "ok",
        "database_path": str(db_path),
        "database_exists": db_path.exists(),
        "database_size_bytes": db_path.stat().st_size if db_path.exists() else 0,
        "comparison_count": len(comparisons),
        "volume_test": "persistent" if db_path.parent.is_mount() else "ephemeral_or_unknown",
    }


@app.get("/api/pulse")
def alpha_pulse():
    """Lightweight alpha behavior signal — just counts, no PII.

    Check this periodically to see if the product is being used
    and whether the proof loop is activating.
    """
    runs = db.list_all("comparison_runs")
    outcomes = db.list_all("evaluation_outcomes")

    # Rerun detection: comparisons with same workload name as a prior one
    workload_names = [r.workload_summary.get("name", "") for r in runs]
    rerun_count = len(workload_names) - len(set(workload_names))

    # Revisit signal: comparisons with multiple outcomes
    outcome_by_run: dict[str, int] = {}
    for o in outcomes:
        key = str(o.comparison_run_id)
        outcome_by_run[key] = outcome_by_run.get(key, 0) + 1
    multi_outcome_runs = sum(1 for c in outcome_by_run.values() if c > 1)

    return {
        "comparisons_created": len(runs),
        "outcomes_logged": len(outcomes),
        "comparisons_with_outcomes": len(outcome_by_run),
        "comparisons_without_outcomes": len(runs) - len(outcome_by_run),
        "reruns_detected": rerun_count,
        "multi_outcome_comparisons": multi_outcome_runs,
        "proof_loop_active": len(outcomes) > 0,
    }


# ═══════════════════════════════════════════
#  ALPHA PRODUCT ENDPOINTS
# ═══════════════════════════════════════════


@app.get("/api/environments")
def list_public_environments():
    """Return all environments from the library."""
    envs = get_environments(db)
    return [
        {
            "id": str(env.id),
            "name": env.name,
            "vendor": env.vendor,
            "environment_type": env.environment_type.value,
            "max_qubits": env.max_qubits,
            "cost_per_task": env.cost_per_task,
            "cost_per_shot": env.cost_per_shot,
            "cost_per_run": env.estimated_cost_per_run or 0.0,
            "queue_time_sec": env.estimated_queue_time_sec or 0.0,
            "has_noise_profile": env.profile is not None,
            "notes": env.notes,
        }
        for env in envs
    ]


@app.post("/api/comparisons", status_code=201)
def create_comparison(data: ComparisonRunCreate):
    """Run a full comparison pipeline and save the result."""
    # Validate environments
    envs = []
    for env_id in data.environment_ids:
        env = get_environment_by_id(db, env_id)
        if env is None:
            raise HTTPException(404, f"Environment {env_id} not found")
        envs.append(env)

    if len(envs) < 2:
        raise HTTPException(400, "At least 2 environments required")

    # Create workload
    workload = Workload(**data.workload.model_dump())

    # Run experiments
    results_pairs = []
    for env in envs:
        exp = ExperimentRun(workload_id=workload.id, environment_id=env.id)
        try:
            _, result = runner.run(exp, workload, env)
        except CircuitParseError as e:
            raise HTTPException(422, str(e))
        results_pairs.append((env, result))

    # Normalize → suitability → recommend
    comparisons = normalize_results(workload, results_pairs)
    env_map = {env.id: env for env in envs}
    comparisons = apply_suitability(workload, comparisons, env_map)
    rec = recommend(workload, comparisons, env_map)

    # Serialize
    result_map = {env.id: result for env, result in results_pairs}
    result_data = serialize_result(workload, env_map, comparisons, rec, result_map)

    # Save
    comparison_run = ComparisonRun(
        user_email=data.user_email,
        workload_summary=result_data["workload_summary"],
        recommendation_summary=result_data["recommendation_summary"],
        comparisons=result_data["comparisons"],
        trust=result_data["trust"],
        fingerprint=result_data["fingerprint"],
        appendix=result_data["appendix"],
    )
    db.save("comparison_runs", comparison_run)

    return {
        "id": str(comparison_run.id),
        "created_at": comparison_run.created_at.isoformat(),
        **result_data,
    }


@app.get("/api/comparisons/{comparison_id}")
def get_comparison(comparison_id: UUID):
    """Fetch a saved comparison result by ID."""
    run = db.get("comparison_runs", comparison_id)
    if not run:
        raise HTTPException(404, "Comparison not found")

    return {
        "id": str(run.id),
        "created_at": run.created_at.isoformat(),
        "workload_summary": run.workload_summary,
        "recommendation_summary": run.recommendation_summary,
        "comparisons": run.comparisons,
        "trust": run.trust,
        "fingerprint": run.fingerprint,
        "appendix": run.appendix,
    }


@app.get("/api/comparisons")
def list_comparisons():
    """List all saved comparisons with summary info."""
    runs = db.list_all("comparison_runs")
    # Pre-compute outcome counts per comparison
    all_outcomes = db.list_all("evaluation_outcomes")
    outcome_counts: dict[str, int] = {}
    for o in all_outcomes:
        key = str(o.comparison_run_id)
        outcome_counts[key] = outcome_counts.get(key, 0) + 1

    summaries = []
    for run in runs:
        rec = run.recommendation_summary
        trust = run.trust or {}
        # Get top score from comparisons
        top_score = None
        if run.comparisons:
            scores = [c.get("overall", 0) for c in run.comparisons]
            top_score = max(scores) if scores else None
        summaries.append({
            "id": str(run.id),
            "workload_name": run.workload_summary.get("name", "Unknown"),
            "workload_category": run.workload_summary.get("category", "custom"),
            "primary": rec.get("primary", "Unknown"),
            "secondary": rec.get("secondary"),
            "confidence": rec.get("confidence", "low"),
            "rationale": rec.get("rationale", ""),
            "top_score": top_score,
            "environments_compared": len(run.comparisons) if run.comparisons else 0,
            "trust_measured": trust.get("measured", 0),
            "trust_estimated": trust.get("estimated", 0),
            "outcome_count": outcome_counts.get(str(run.id), 0),
            "created_at": run.created_at.isoformat(),
        })
    # Most recent first
    summaries.sort(key=lambda s: s["created_at"], reverse=True)
    return summaries


@app.delete("/api/comparisons/{comparison_id}")
def delete_comparison(comparison_id: UUID):
    """Delete a comparison by ID."""
    deleted = db.delete("comparison_runs", comparison_id)
    if not deleted:
        raise HTTPException(404, "Comparison not found")
    return {"deleted": True}


# ═══════════════════════════════════════════
#  EVALUATION OUTCOMES (Layer 2)
# ═══════════════════════════════════════════


@app.post("/api/evaluations", status_code=201)
def log_evaluation(data: EvaluationOutcomeCreate):
    """Log an actual outcome for a comparison run (predicted vs actual)."""
    # Look up the original comparison to get prediction data
    run = db.get("comparison_runs", data.comparison_run_id)
    if not run:
        raise HTTPException(404, "Comparison run not found")

    rec = run.recommendation_summary
    # Find the predicted score for the recommended environment
    predicted_score = None
    for comp in run.comparisons:
        if comp.get("name") == rec.get("primary"):
            predicted_score = comp.get("overall")
            break

    # Compute deltas where possible
    delta_fidelity = None
    if data.actual_fidelity is not None and predicted_score is not None:
        delta_fidelity = round(data.actual_fidelity - predicted_score, 4)

    delta_cost = None
    if data.actual_cost_usd is not None:
        # Find predicted cost score for chosen environment
        for comp in run.comparisons:
            if comp.get("name") == data.environment_chosen:
                delta_cost = round(data.actual_cost_usd - comp.get("cost", 0), 4)
                break

    outcome = EvaluationOutcome(
        comparison_run_id=data.comparison_run_id,
        user_email=run.user_email,
        predicted_environment=rec.get("primary", "Unknown"),
        predicted_score=predicted_score,
        predicted_confidence=rec.get("confidence", "low"),
        environment_chosen=data.environment_chosen,
        followed_recommendation=data.followed_recommendation,
        actual_fidelity=data.actual_fidelity,
        actual_runtime_sec=data.actual_runtime_sec,
        actual_cost_usd=data.actual_cost_usd,
        actual_queue_time_sec=data.actual_queue_time_sec,
        actual_shots=data.actual_shots,
        actual_result=data.actual_result,
        notes=data.notes,
        delta_fidelity=delta_fidelity,
        delta_cost=delta_cost,
    )
    db.save("evaluation_outcomes", outcome)

    return {
        "id": str(outcome.id),
        "created_at": outcome.created_at.isoformat(),
        "predicted_environment": outcome.predicted_environment,
        "predicted_score": outcome.predicted_score,
        "predicted_confidence": outcome.predicted_confidence,
        "environment_chosen": outcome.environment_chosen,
        "followed_recommendation": outcome.followed_recommendation.value,
        "actual_result": outcome.actual_result.model_dump() if outcome.actual_result else None,
        "delta_fidelity": outcome.delta_fidelity,
        "delta_cost": outcome.delta_cost,
    }


class ParseRequest(PydanticBaseModel):
    text: str


@app.post("/api/parse-result")
def parse_result_endpoint(req: ParseRequest):
    """Parse pasted quantum result text into structured fields.

    Accepts Qiskit Result JSON or key:value plaintext.
    Returns extracted fields for preview before logging.
    """
    try:
        parsed = parse_result(req.text)
    except ParseError as e:
        raise HTTPException(422, str(e))

    return {
        "format": parsed.actual_result.import_format,
        "environment_chosen": parsed.environment_chosen,
        "actual_fidelity": parsed.actual_fidelity,
        "actual_runtime_sec": parsed.actual_runtime_sec,
        "actual_cost_usd": parsed.actual_cost_usd,
        "actual_shots": parsed.actual_shots,
        "actual_result": parsed.actual_result.model_dump(exclude={"raw_input"}),
    }


@app.get("/api/evaluations")
def list_evaluations():
    """List all evaluation outcomes with summary info."""
    outcomes = db.list_all("evaluation_outcomes")
    summaries = []
    for o in outcomes:
        # Look up workload name from the comparison run
        run = db.get("comparison_runs", o.comparison_run_id)
        workload_name = run.workload_summary.get("name", "Unknown") if run else "Unknown"

        summaries.append({
            "id": str(o.id),
            "comparison_run_id": str(o.comparison_run_id),
            "workload_name": workload_name,
            "predicted_environment": o.predicted_environment,
            "environment_chosen": o.environment_chosen,
            "followed_recommendation": o.followed_recommendation.value,
            "predicted_score": o.predicted_score,
            "actual_fidelity": o.actual_fidelity,
            "actual_cost_usd": o.actual_cost_usd,
            "delta_fidelity": o.delta_fidelity,
            "created_at": o.created_at.isoformat(),
        })
    summaries.sort(key=lambda s: s["created_at"], reverse=True)
    return summaries


@app.get("/api/evaluations/metrics")
def evaluation_metrics():
    """Proof metrics: how accurate are Qlro's recommendations?

    Returns follow rate, top-1 accuracy, confidence calibration,
    and alternative regret — the core metrics that prove the
    suitability model is useful.
    """
    outcomes = db.list_all("evaluation_outcomes")
    total = len(outcomes)

    if total == 0:
        return {
            "total_outcomes": 0,
            "follow_rate": None,
            "top1_accuracy": None,
            "confidence_calibration": None,
            "alternative_regret": None,
            "sufficient_data": False,
        }

    # Follow rate: % who ran on the recommended environment
    followed = [o for o in outcomes if o.followed_recommendation.value == "followed"]
    alternatives = [o for o in outcomes if o.followed_recommendation.value == "alternative"]
    follow_rate = len(followed) / total if total > 0 else 0

    # Top-1 accuracy: of those who followed, how many had actual fidelity
    # within threshold of predicted score?
    # NOTE: 0.15 is an initial operational heuristic, not a scientific claim.
    # Should be revisited after 50+ outcomes and eventually replaced with
    # workload-category-specific thresholds.
    ACCURACY_THRESHOLD = 0.15  # initial heuristic — see research.md threshold policy
    followed_with_fidelity = [o for o in followed if o.actual_fidelity is not None and o.predicted_score is not None]
    top1_accurate = 0
    for o in followed_with_fidelity:
        if abs(o.actual_fidelity - o.predicted_score) <= ACCURACY_THRESHOLD:
            top1_accurate += 1
    top1_accuracy = (top1_accurate / len(followed_with_fidelity)) if followed_with_fidelity else None

    # Confidence calibration: average absolute delta by confidence level
    calibration = {}
    for level in ["high", "medium", "low"]:
        level_outcomes = [
            o for o in outcomes
            if o.predicted_confidence == level
            and o.delta_fidelity is not None
        ]
        if level_outcomes:
            avg_abs_delta = sum(abs(o.delta_fidelity) for o in level_outcomes) / len(level_outcomes)
            calibration[level] = {
                "count": len(level_outcomes),
                "avg_absolute_delta": round(avg_abs_delta, 4),
            }

    # Alternative regret: when users chose differently, was their actual
    # fidelity better or worse than predicted score for the recommended env?
    alt_with_fidelity = [
        o for o in alternatives
        if o.actual_fidelity is not None and o.predicted_score is not None
    ]
    regret_count = 0  # how many did worse than Qlro's pick would have predicted
    for o in alt_with_fidelity:
        if o.actual_fidelity < o.predicted_score:
            regret_count += 1
    alternative_regret = (regret_count / len(alt_with_fidelity)) if alt_with_fidelity else None

    return {
        "total_outcomes": total,
        "follow_rate": round(follow_rate, 4),
        "top1_accuracy": round(top1_accuracy, 4) if top1_accuracy is not None else None,
        "confidence_calibration": calibration if calibration else None,
        "alternative_regret": round(alternative_regret, 4) if alternative_regret is not None else None,
        "sufficient_data": total >= 10,
        "breakdown": {
            "followed": len(followed),
            "alternative": len(alternatives),
            "abandoned": total - len(followed) - len(alternatives),
            "with_fidelity_data": len(followed_with_fidelity) + len(alt_with_fidelity),
        },
    }


@app.get("/api/evaluations/{evaluation_id}")
def get_evaluation(evaluation_id: UUID):
    """Fetch a single evaluation outcome with full details."""
    outcome = db.get("evaluation_outcomes", evaluation_id)
    if not outcome:
        raise HTTPException(404, "Evaluation not found")

    run = db.get("comparison_runs", outcome.comparison_run_id)
    workload_name = run.workload_summary.get("name", "Unknown") if run else "Unknown"

    return {
        "id": str(outcome.id),
        "created_at": outcome.created_at.isoformat(),
        "comparison_run_id": str(outcome.comparison_run_id),
        "workload_name": workload_name,
        "user_email": outcome.user_email,
        "predicted_environment": outcome.predicted_environment,
        "predicted_score": outcome.predicted_score,
        "predicted_confidence": outcome.predicted_confidence,
        "environment_chosen": outcome.environment_chosen,
        "followed_recommendation": outcome.followed_recommendation.value,
        "actual_fidelity": outcome.actual_fidelity,
        "actual_runtime_sec": outcome.actual_runtime_sec,
        "actual_cost_usd": outcome.actual_cost_usd,
        "actual_queue_time_sec": outcome.actual_queue_time_sec,
        "actual_shots": outcome.actual_shots,
        "actual_result": outcome.actual_result.model_dump(exclude={"raw_input"}) if outcome.actual_result else None,
        "notes": outcome.notes,
        "delta_fidelity": outcome.delta_fidelity,
        "delta_cost": outcome.delta_cost,
    }


@app.get("/api/comparisons/{comparison_id}/evaluations")
def list_comparison_evaluations(comparison_id: UUID):
    """List all evaluation outcomes for a specific comparison run."""
    run = db.get("comparison_runs", comparison_id)
    if not run:
        raise HTTPException(404, "Comparison not found")

    outcomes = db.list_all("evaluation_outcomes")
    matched = [o for o in outcomes if o.comparison_run_id == comparison_id]
    matched.sort(key=lambda o: o.created_at.isoformat(), reverse=True)

    return [
        {
            "id": str(o.id),
            "predicted_environment": o.predicted_environment,
            "predicted_score": o.predicted_score,
            "predicted_confidence": o.predicted_confidence,
            "environment_chosen": o.environment_chosen,
            "followed_recommendation": o.followed_recommendation.value,
            "actual_fidelity": o.actual_fidelity,
            "actual_cost_usd": o.actual_cost_usd,
            "actual_runtime_sec": o.actual_runtime_sec,
            "actual_shots": o.actual_shots,
            "actual_result": o.actual_result.model_dump(exclude={"raw_input"}) if o.actual_result else None,
            "delta_fidelity": o.delta_fidelity,
            "delta_cost": o.delta_cost,
            "notes": o.notes,
            "created_at": o.created_at.isoformat(),
        }
        for o in matched
    ]




# ═══════════════════════════════════════════
#  ADMIN ENDPOINTS
# ═══════════════════════════════════════════


@app.get("/api/admin/stats", dependencies=[Depends(require_admin)])
def admin_stats():
    """Rich analytics for admin dashboard."""
    from collections import defaultdict
    from datetime import datetime, timedelta, timezone

    envs = get_environments(db)
    runs = db.list_all("comparison_runs")

    now = datetime.now(timezone.utc)
    today = now.date()

    # ── Counters ──
    categories: dict[str, int] = defaultdict(int)
    confidence_counts: dict[str, int] = defaultdict(int)
    recommended_counts: dict[str, int] = defaultdict(int)
    selected_counts: dict[str, int] = defaultdict(int)
    daily_counts: dict[str, int] = defaultdict(int)  # "YYYY-MM-DD" -> count
    priority_sums = {"confidence": 0.0, "speed": 0.0, "cost": 0.0}
    qubit_values: list[int] = []
    depth_values: list[int] = []
    comparisons_today = 0
    comparisons_7d = 0

    # ── Activity feed (last 20) ──
    sorted_runs = sorted(runs, key=lambda r: r.created_at.isoformat(), reverse=True)
    activity_feed = []

    for run in sorted_runs:
        ws = run.workload_summary
        rs = run.recommendation_summary
        cat = ws.get("category", "custom")
        conf = rs.get("confidence", "low")
        primary = rs.get("primary", "Unknown")

        categories[cat] += 1
        confidence_counts[conf] += 1
        recommended_counts[primary] += 1

        # Environment selection frequency
        for comp in run.comparisons:
            env_name = comp.get("name", "Unknown")
            selected_counts[env_name] += 1

        # Daily counts
        run_date = run.created_at.date()
        daily_counts[run_date.isoformat()] += 1

        days_ago = (today - run_date).days
        if days_ago == 0:
            comparisons_today += 1
        if days_ago < 7:
            comparisons_7d += 1

        # Priority distribution
        priorities = ws.get("priorities", {})
        priority_sums["confidence"] += priorities.get("confidence", 0.34)
        priority_sums["speed"] += priorities.get("speed", 0.33)
        priority_sums["cost"] += priorities.get("cost", 0.33)

        # Qubit/depth patterns
        qh = ws.get("qubit_count_hint")
        dh = ws.get("circuit_depth_hint")
        if qh:
            qubit_values.append(qh)
        if dh:
            depth_values.append(dh)

        # Activity feed
        if len(activity_feed) < 20:
            activity_feed.append({
                "id": str(run.id),
                "workload_name": ws.get("name", "Unknown"),
                "category": cat,
                "primary": primary,
                "confidence": conf,
                "environments_compared": len(run.comparisons),
                "created_at": run.created_at.isoformat(),
            })

    n = len(runs) or 1  # avoid division by zero

    # ── Daily time series (last 30 days) ──
    daily_series = []
    for i in range(29, -1, -1):
        d = (today - timedelta(days=i)).isoformat()
        daily_series.append({"date": d, "count": daily_counts.get(d, 0)})

    # ── Recommendation vs selection gap ──
    env_analytics = []
    all_env_names = set(list(recommended_counts.keys()) + list(selected_counts.keys()))
    for name in sorted(all_env_names):
        env_analytics.append({
            "name": name,
            "times_selected": selected_counts.get(name, 0),
            "times_recommended": recommended_counts.get(name, 0),
        })

    return {
        "total_environments": len(envs),
        "total_comparisons": len(runs),
        "comparisons_today": comparisons_today,
        "comparisons_7d": comparisons_7d,

        "categories": dict(categories),
        "confidence_breakdown": dict(confidence_counts),
        "daily_series": daily_series,

        "priority_avg": {
            "confidence": round(priority_sums["confidence"] / n, 2),
            "speed": round(priority_sums["speed"] / n, 2),
            "cost": round(priority_sums["cost"] / n, 2),
        },

        "qubit_stats": {
            "min": min(qubit_values) if qubit_values else None,
            "max": max(qubit_values) if qubit_values else None,
            "avg": round(sum(qubit_values) / len(qubit_values), 1) if qubit_values else None,
            "count": len(qubit_values),
        },
        "depth_stats": {
            "min": min(depth_values) if depth_values else None,
            "max": max(depth_values) if depth_values else None,
            "avg": round(sum(depth_values) / len(depth_values), 1) if depth_values else None,
            "count": len(depth_values),
        },

        "environment_analytics": env_analytics,
        "activity_feed": activity_feed,
    }


@app.get("/api/admin/environments", dependencies=[Depends(require_admin)])
def admin_list_environments():
    """List all environments with full details."""
    envs = get_environments(db)
    return [env.model_dump(mode="json") for env in envs]


@app.post("/api/admin/environments", status_code=201, dependencies=[Depends(require_admin)])
def admin_create_environment(data: EnvironmentCreate):
    """Create a new environment."""
    env = CandidateEnvironment(**data.model_dump())
    db.save("environments", env)
    return env.model_dump(mode="json")


@app.put("/api/admin/environments/{env_id}", dependencies=[Depends(require_admin)])
def admin_update_environment(env_id: UUID, data: EnvironmentCreate):
    """Update an existing environment."""
    existing = db.get("environments", env_id)
    if not existing:
        raise HTTPException(404, "Environment not found")
    updated = CandidateEnvironment(id=env_id, **data.model_dump())
    db.save("environments", updated)
    return updated.model_dump(mode="json")


@app.delete("/api/admin/environments/{env_id}", dependencies=[Depends(require_admin)])
def admin_delete_environment(env_id: UUID):
    """Delete an environment."""
    deleted = db.delete("environments", env_id)
    if not deleted:
        raise HTTPException(404, "Environment not found")
    return {"deleted": True}


@app.get("/api/admin/comparisons", dependencies=[Depends(require_admin)])
def admin_list_comparisons(limit: int = 50, offset: int = 0):
    """List comparisons with pagination."""
    runs = db.list_all("comparison_runs")
    # Sort most recent first
    runs.sort(key=lambda r: r.created_at.isoformat(), reverse=True)
    total = len(runs)
    page = runs[offset : offset + limit]
    return {
        "total": total,
        "limit": limit,
        "offset": offset,
        "items": [
            {
                "id": str(run.id),
                "workload_name": run.workload_summary.get("name", "Unknown"),
                "workload_category": run.workload_summary.get("category", "custom"),
                "primary": run.recommendation_summary.get("primary", "Unknown"),
                "confidence": run.recommendation_summary.get("confidence", "low"),
                "environments_compared": len(run.comparisons),
                "created_at": run.created_at.isoformat(),
            }
            for run in page
        ],
    }


@app.delete("/api/admin/comparisons/{comparison_id}", dependencies=[Depends(require_admin)])
def admin_delete_comparison(comparison_id: UUID):
    """Delete a comparison."""
    deleted = db.delete("comparison_runs", comparison_id)
    if not deleted:
        raise HTTPException(404, "Comparison not found")
    return {"deleted": True}


@app.get("/api/admin/system", dependencies=[Depends(require_admin)])
def admin_system_info():
    """System info for admin settings page."""
    return {
        "database_path": str(db_path),
        "database_exists": db_path.exists(),
        "database_size_bytes": db_path.stat().st_size if db_path.exists() else 0,
        "table_counts": {table: db.count(table) for table in [
            "environments", "comparison_runs", "workloads",
            "experiment_runs", "experiment_results", "comparisons", "recommendations",
        ]},
        "allowed_origins": allowed_origins,
    }


# ═══════════════════════════════════════════
#  LEGACY ENDPOINTS (kept for internal use)
# ═══════════════════════════════════════════


@app.post("/workloads", response_model=Workload)
def create_workload(data: WorkloadCreate):
    workload = Workload(**data.model_dump())
    db.save("workloads", workload)
    return workload


@app.get("/workloads", response_model=list[Workload])
def list_workloads():
    return db.list_all("workloads")


@app.get("/workloads/{workload_id}", response_model=Workload)
def get_workload(workload_id: UUID):
    w = db.get("workloads", workload_id)
    if not w:
        raise HTTPException(404, "Workload not found")
    return w


@app.post("/environments", response_model=CandidateEnvironment)
def create_environment(data: EnvironmentCreate):
    env = CandidateEnvironment(**data.model_dump())
    db.save("environments", env)
    return env


@app.get("/environments", response_model=list[CandidateEnvironment])
def list_legacy_environments():
    return db.list_all("environments")


@app.get("/environments/{env_id}", response_model=CandidateEnvironment)
def get_environment(env_id: UUID):
    env = db.get("environments", env_id)
    if not env:
        raise HTTPException(404, "Environment not found")
    return env


@app.post("/experiments/run")
def run_experiment(data: ExperimentRunCreate):
    workload = db.get("workloads", data.workload_id)
    if not workload:
        raise HTTPException(404, "Workload not found")
    environment = db.get("environments", data.environment_id)
    if not environment:
        raise HTTPException(404, "Environment not found")
    experiment = ExperimentRun(**data.model_dump())
    updated_run, result = runner.run(experiment, workload, environment)
    db.save("experiment_runs", updated_run)
    db.save("experiment_results", result)
    return {
        "experiment_run": updated_run.model_dump(mode="json"),
        "result": result.model_dump(mode="json"),
    }


@app.get("/experiments", response_model=list[ExperimentRun])
def list_experiments():
    return db.list_all("experiment_runs")


# ═══════════════════════════════════════════
#  WCPP RECOMMENDATION (product endpoint)
# ═══════════════════════════════════════════


class RecommendRequest(PydanticBaseModel):
    """User workload spec for personalized recommendation."""

    qubit_count: int
    circuit_depth: int
    two_qubit_gates: int
    connectivity: str = "linear"
    accuracy: str = "medium"
    shots: int = 1024


@app.post("/api/recommend")
def wcpp_recommend(req: RecommendRequest):
    """Personalized device recommendation based on workload spec.

    Converts user spec → custom WCPP weight vector → scores all devices
    → returns top recommendation with explanation.
    """
    from qlro.scoring.profiler import WorkloadSpec
    from qlro.scoring.recommend import recommend as wcpp_recommend_fn

    spec = WorkloadSpec(
        qubit_count=req.qubit_count,
        circuit_depth=req.circuit_depth,
        two_qubit_gates=req.two_qubit_gates,
        connectivity=req.connectivity,
        accuracy=req.accuracy,
        shots=req.shots,
    )

    rec = wcpp_recommend_fn(spec)

    return {
        "primary": {
            "device": rec.primary.device,
            "fit": round(rec.primary.value, 4),
            "uncertainty": round(rec.primary.uncertainty, 4) if rec.primary.uncertainty else None,
            "any_estimated": rec.primary.any_axis_estimated,
        },
        "alternative": {
            "device": rec.alternative.device,
            "fit": round(rec.alternative.value, 4),
            "uncertainty": round(rec.alternative.uncertainty, 4) if rec.alternative.uncertainty else None,
            "any_estimated": rec.alternative.any_axis_estimated,
        },
        "reason": rec.reason,
        "tradeoffs": rec.tradeoffs,
        "confidence": rec.confidence,
        "warnings": rec.warnings,
        "weights": {a.value: round(w, 4) for a, w in rec.weights.items()},
        "weight_explanation": rec.weight_explanation,
        "all_scores": [
            {
                "device": s.device,
                "fit": round(s.value, 4),
                "uncertainty": round(s.uncertainty, 4) if s.uncertainty else None,
                "any_estimated": s.any_axis_estimated,
            }
            for s in rec.all_scores
        ],
    }


@app.post("/compare/{workload_id}")
def compare_and_recommend(workload_id: UUID, format: str = "markdown"):
    workload = db.get("workloads", workload_id)
    if not workload:
        raise HTTPException(404, "Workload not found")
    runs = db.query("experiment_runs", workload_id=workload_id)
    if not runs:
        raise HTTPException(400, "No experiment runs found for this workload")
    env_results: list[tuple[CandidateEnvironment, ExperimentResult]] = []
    for run in runs:
        if run.status.value != "completed":
            continue
        results = db.query("experiment_results", experiment_run_id=run.id)
        if not results:
            continue
        env = db.get("environments", run.environment_id)
        if env:
            env_results.append((env, results[0]))
    if not env_results:
        raise HTTPException(400, "No completed experiment results to compare")
    comparisons = normalize_results(workload, env_results)
    env_map = {env.id: env for env, _ in env_results}
    comparisons = apply_suitability(workload, comparisons, env_map)
    for comp in comparisons:
        db.save("comparisons", comp)
    rec = recommend(workload, comparisons, env_map)
    db.save("recommendations", rec)
    report = generate_report(workload, env_map, comparisons, rec, format=format)
    return {
        "comparisons": [c.model_dump(mode="json") for c in comparisons],
        "recommendation": rec.model_dump(mode="json"),
        "report": report,
    }
