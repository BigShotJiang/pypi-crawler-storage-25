"""Workload-conditioned composition (Stage 3 of WCPP).

Combines the four capability axes via weighted geometric mean:
    fit(d, w) = Π_α X_α(d)^w_α

See WCPP_SPEC.md §5 for motivation (Leontief-style complementary inputs).
"""

from __future__ import annotations

import math
from dataclasses import dataclass

from qlro.scoring.axes import Axis, CapabilityValues
from qlro.scoring.priors import WorkloadCategory, workload_weights


@dataclass
class FitScore:
    """Final WCPP output for one device under one workload."""

    device: str
    workload: str
    value: float
    uncertainty: float | None
    axis_values: CapabilityValues
    weights: dict[Axis, float]
    any_axis_estimated: bool

    def __repr__(self) -> str:
        u = f" ± {self.uncertainty:.3g}" if self.uncertainty is not None else ""
        flag = " [partially estimated]" if self.any_axis_estimated else ""
        return (
            f"qlro_fit({self.device}, {self.workload}) = "
            f"{self.value:.4f}{u}{flag}"
        )

    def breakdown(self) -> str:
        """Human-readable breakdown of the computation."""
        lines = [repr(self)]
        for axis in (Axis.GAMMA, Axis.PHI, Axis.F, Axis.T):
            av = self.axis_values.as_dict()[axis]
            w = self.weights[axis]
            lines.append(f"  {axis.value:<6} (w={w:.2f})  {av}")
            for c in av.contributions:
                lines.append(f"      ← {c}")
        return "\n".join(lines)


def compose(
    axis_values: CapabilityValues,
    workload: str,
    custom_weights: dict[Axis, float] | None = None,
) -> FitScore:
    """Combine capability axes via workload-weighted geometric mean.

    fit = Π_α X_α^w_α
    σ(fit) = fit × √( Σ_α (w_α × σ(X_α) / X_α)² )

    Parameters
    ----------
    custom_weights:
        Optional per-axis weight dict (must sum to 1). When provided,
        overrides the default category-based lookup from priors.py.
    """
    weights = custom_weights if custom_weights is not None else workload_weights(workload)

    # Guard: any axis value == 0 means fit is exactly 0 (and uncertainty is
    # meaningless in that case).
    axis_dict = axis_values.as_dict()
    for axis, av in axis_dict.items():
        if weights[axis] > 0 and av.value == 0.0:
            return FitScore(
                device=axis_values.device,
                workload=workload,
                value=0.0,
                uncertainty=None,
                axis_values=axis_values,
                weights=weights,
                any_axis_estimated=axis_values.any_estimated(),
            )

    log_fit = 0.0
    for axis, av in axis_dict.items():
        w = weights[axis]
        if w == 0.0:
            continue  # skip axes the workload doesn't care about
        log_fit += w * math.log(av.value)

    value = math.exp(log_fit)

    # Uncertainty via error propagation:
    #   σ(fit) = fit × √( Σ (w_α × σ_α / X_α)² )
    rel_var = 0.0
    any_uncertainty = False
    for axis, av in axis_dict.items():
        w = weights[axis]
        if w == 0.0 or av.uncertainty is None:
            continue
        rel_var += (w * av.uncertainty / av.value) ** 2
        any_uncertainty = True

    uncertainty = value * math.sqrt(rel_var) if any_uncertainty else None

    return FitScore(
        device=axis_values.device,
        workload=workload,
        value=value,
        uncertainty=uncertainty,
        axis_values=axis_values,
        weights=weights,
        any_axis_estimated=axis_values.any_estimated(),
    )
