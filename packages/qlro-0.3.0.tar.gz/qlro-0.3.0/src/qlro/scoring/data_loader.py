"""Load the Metriq snapshot and extract raw benchmark values per device.

The snapshot shape is heterogeneous: some benchmarks have a single scalar value,
some have nested {value, uncertainty} objects, and some have lists (like EPLG
chain_eplgs). This module's job is to give the physics transforms a clean,
uniform view of "the value and uncertainty for benchmark X on device D."
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any

REPO_ROOT = Path(__file__).resolve().parents[3]
# Look for the snapshot in two places:
# 1. Package-embedded: src/qlro/data/metriq_snapshot.json (for pip install)
# 2. Repo-level: data/metriq_snapshot.json (for development)
_PACKAGE_DATA = Path(__file__).resolve().parents[1] / "data" / "metriq_snapshot.json"
_REPO_DATA = REPO_ROOT / "data" / "metriq_snapshot.json"
DEFAULT_SNAPSHOT_PATH = _PACKAGE_DATA if _PACKAGE_DATA.exists() else _REPO_DATA


@dataclass
class BenchmarkReading:
    """A single raw benchmark measurement, normalized into a uniform shape."""

    benchmark_name: str
    metric_name: str  # e.g. "largest_connected_size", "eplg_100", "accuracy_score"
    value: float
    uncertainty: float | None
    width: int | None = None  # num_qubits for width-dependent benchmarks
    timestamp: str | None = None
    metriq_version: str | None = None
    source_params: dict[str, Any] = field(default_factory=dict)

    def __repr__(self) -> str:
        w = f"@{self.width}Q" if self.width is not None else ""
        u = f" ± {self.uncertainty:.4g}" if self.uncertainty is not None else ""
        return f"{self.benchmark_name}{w}[{self.metric_name}] = {self.value:.4g}{u}"


@dataclass
class DeviceRecord:
    """All normalized benchmark readings for a single device."""

    device: str
    provider: str | None
    num_qubits: int | None
    readings: list[BenchmarkReading] = field(default_factory=list)

    def filter(
        self,
        benchmark_name: str | None = None,
        width: int | None = None,
        max_date: str | None = None,
        min_date: str | None = None,
    ) -> list[BenchmarkReading]:
        """Return readings matching the given filters."""
        out = []
        for r in self.readings:
            if benchmark_name is not None and r.benchmark_name != benchmark_name:
                continue
            if width is not None and r.width != width:
                continue
            if max_date is not None and r.timestamp and r.timestamp[:10] > max_date:
                continue
            if min_date is not None and r.timestamp and r.timestamp[:10] < min_date:
                continue
            out.append(r)
        return out


class MetriqSnapshot:
    """Loaded view of data/metriq_snapshot.json with normalization."""

    def __init__(self, path: Path | None = None) -> None:
        self.path = path or DEFAULT_SNAPSHOT_PATH
        with self.path.open() as f:
            self._raw = json.load(f)
        self.source_commit = self._raw.get("source_commit")
        self.synced_at = self._raw.get("synced_at")
        self._devices: dict[str, DeviceRecord] = {}
        self._parse()

    def _parse(self) -> None:
        for name, data in self._raw["devices"].items():
            record = DeviceRecord(
                device=name,
                provider=data.get("provider"),
                num_qubits=data.get("num_qubits"),
            )
            for entry in data.get("benchmarks", []):
                readings = self._extract_readings(entry)
                record.readings.extend(readings)
            self._devices[name] = record

    def _extract_readings(self, entry: dict) -> list[BenchmarkReading]:
        """Convert one entry into one or more BenchmarkReading objects."""
        bench = entry.get("benchmark_name")
        if not bench:
            return []
        params = entry.get("params") or {}
        width = params.get("num_qubits") or params.get("width")
        timestamp = entry.get("timestamp")
        version = entry.get("metriq_version")
        values = entry.get("values") or {}
        uncertainties = entry.get("uncertainties") or {}
        out: list[BenchmarkReading] = []

        for metric, v in values.items():
            # Skip helper fields that aren't scores
            if metric in {"chain_lengths", "directions", "confidence_pass"}:
                continue

            # Unwrap nested {value, uncertainty} format used in v0.5/v0.6
            if isinstance(v, dict) and "value" in v:
                scalar = v.get("value")
                unc = v.get("uncertainty")
            elif isinstance(v, list):
                # Take the first element for list-valued metrics like approx_ratio
                # (LR-QAOA reports it as a single-element list)
                if not v:
                    continue
                first = v[0]
                if isinstance(first, dict) and "value" in first:
                    scalar = first.get("value")
                    unc = first.get("uncertainty")
                elif isinstance(first, (int, float)):
                    scalar = first
                    unc = uncertainties.get(metric)
                else:
                    continue
            elif isinstance(v, (int, float, bool)):
                scalar = float(v) if not isinstance(v, bool) else None
                unc = uncertainties.get(metric)
                if isinstance(unc, dict):
                    unc = unc.get("uncertainty")
            else:
                continue

            if scalar is None or not isinstance(scalar, (int, float)):
                continue
            if isinstance(unc, str):
                try:
                    unc = float(unc)
                except ValueError:
                    unc = None
            if unc is not None and not isinstance(unc, (int, float)):
                unc = None

            out.append(
                BenchmarkReading(
                    benchmark_name=bench,
                    metric_name=metric,
                    value=float(scalar),
                    uncertainty=float(unc) if unc is not None else None,
                    width=width,
                    timestamp=timestamp,
                    metriq_version=version,
                    source_params=params,
                )
            )

        return out

    def device(self, name: str) -> DeviceRecord:
        if name not in self._devices:
            raise KeyError(f"Device {name!r} not in snapshot")
        return self._devices[name]

    def devices(self) -> list[str]:
        return sorted(self._devices.keys())

    def summary(self) -> dict:
        return self._raw.get("summary", {})
