"""Top-level WCPP entry point: qlro_fit(device, workload).

Orchestrates the full three-stage pipeline:
    raw benchmarks → physical values → axis aggregation → workload composition

See WCPP_SPEC.md for the full framework specification.
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Callable

from qlro.scoring.axes import (
    Axis,
    AxisContribution,
    CapabilityValues,
    apply_prior,
    axis_for_benchmark,
    geometric_mean_aggregate,
)
from qlro.scoring.composition import FitScore, compose  # noqa: F401 — Axis re-export for callers
from qlro.scoring.data_loader import (
    BenchmarkReading,
    DeviceRecord,
    MetriqSnapshot,
)
from qlro.scoring.physics import (
    tau_bseq,
    tau_clops,
    tau_eplg,
    tau_lr_qaoa,
    tau_mirror_circuits,
    tau_qft,
    tau_qml_kernel,
    tau_wit,
)
from qlro.scoring.priors import axis_prior


# A filter is a predicate on BenchmarkReading used to select a subset
# (e.g. only readings from a specific date range).
Filter = Callable[[BenchmarkReading], bool]


def _select_latest(readings: list[BenchmarkReading]) -> list[BenchmarkReading]:
    """When there are multiple readings with the same (benchmark, metric, width),
    keep only the most recent one."""
    keyed: dict[tuple[str, str, int | None], BenchmarkReading] = {}
    for r in readings:
        key = (r.benchmark_name, r.metric_name, r.width)
        if key not in keyed or (r.timestamp or "") > (keyed[key].timestamp or ""):
            keyed[key] = r
    return list(keyed.values())


def _mean_contribution(
    axis: Axis,
    label: str,
    per_width: list[tuple[int | None, float, float | None]],
) -> AxisContribution:
    """Aggregate per-width transformed values for one benchmark into a single
    AxisContribution via arithmetic mean over the signal-bearing widths.

    Width information is preserved in the `source` description so the breakdown
    reported to the user always shows which widths contributed.

    Uncertainty is propagated as the standard error of the mean:
        σ(mean) = √(Σσᵢ²) / N
    ignoring terms where σᵢ is None.
    """
    n = len(per_width)
    mean_value = sum(v for _, v, _ in per_width) / n

    uncertainties = [u for _, _, u in per_width if u is not None]
    if uncertainties:
        sigma = math.sqrt(sum(u * u for u in uncertainties)) / n
    else:
        sigma = None

    widths = sorted([w for w, _, _ in per_width if w is not None])
    if widths:
        width_range = (
            f"{widths[0]}Q" if len(widths) == 1 else f"{widths[0]}Q–{widths[-1]}Q"
        )
        source = f"{label} mean over {n} widths ({width_range})"
    else:
        source = f"{label} mean over {n} readings"

    return AxisContribution(
        axis=axis,
        value=mean_value,
        uncertainty=sigma,
        source=source,
    )


def _bseq_contributions(
    device: DeviceRecord, readings: list[BenchmarkReading]
) -> list[AxisContribution]:
    """Convert BSEQ readings into AxisContributions for Γ."""
    contribs = []
    n = device.num_qubits
    for r in readings:
        if r.benchmark_name != "BSEQ":
            continue
        if r.metric_name != "largest_connected_size":
            continue
        if n is None:
            continue
        pv = tau_bseq(r.value, n, r.uncertainty)
        contribs.append(
            AxisContribution(
                axis=Axis.GAMMA,
                value=pv.value,
                uncertainty=pv.uncertainty,
                source=pv.description,
            )
        )
    return contribs


def _eplg_contributions(
    readings: list[BenchmarkReading], length: int = 100
) -> list[AxisContribution]:
    """Convert EPLG readings into AxisContributions for F.

    Uses only the `eplg_<length>` anchor point (default 100). The full
    chain_eplgs curve is recorded but only the canonical anchor is used.
    """
    target_metric = f"eplg_{length}"
    contribs = []
    for r in readings:
        if r.benchmark_name != "EPLG":
            continue
        if r.metric_name != target_metric:
            continue
        pv = tau_eplg(r.value, r.uncertainty)
        contribs.append(
            AxisContribution(
                axis=Axis.F,
                value=pv.value,
                uncertainty=pv.uncertainty,
                source=pv.description,
            )
        )
    return contribs


def _wit_contributions(
    readings: list[BenchmarkReading],
) -> list[AxisContribution]:
    """Convert WIT readings into AxisContributions for F."""
    contribs = []
    for r in readings:
        if r.benchmark_name != "WIT":
            continue
        if r.metric_name != "expectation_value":
            continue
        pv = tau_wit(r.value, raw_uncertainty=r.uncertainty)
        contribs.append(
            AxisContribution(
                axis=Axis.F,
                value=pv.value,
                uncertainty=pv.uncertainty,
                source=pv.description,
            )
        )
    return contribs


def _qml_contributions(
    readings: list[BenchmarkReading],
) -> list[AxisContribution]:
    """Convert QML Kernel readings into one AxisContribution for F.

    Aggregation rule (WCPP_SPEC.md §4.3, revised): arithmetic mean of
    τ_QML across ALL measured widths where the device has signal above
    random. This represents "average classification skill across the
    measured range." Widths where the device fails (accuracy ≤ random)
    are excluded rather than allowed to drag the average to zero.

    Rationale: the previous rule ("use the largest signal-bearing width")
    punished devices that had more comprehensive benchmark coverage,
    because the measurement set extended into failure widths where the
    physical value is essentially zero. Averaging across signal-bearing
    widths is honest about what was measured without rewarding sparse
    coverage.
    """
    qml = [r for r in readings if r.benchmark_name == "QML Kernel"]
    qml = [r for r in qml if r.metric_name == "accuracy_score"]
    if not qml:
        return []

    # Transform each reading individually, then keep only the ones with signal.
    transformed: list[tuple[int | None, float, float | None]] = []
    for r in qml:
        pv = tau_qml_kernel(r.value, r.uncertainty)
        if pv.value > 0.0:
            transformed.append((r.width, pv.value, pv.uncertainty))
    if not transformed:
        return []

    return [_mean_contribution(Axis.F, "QML", transformed)]


def _clops_contributions(
    readings: list[BenchmarkReading],
) -> list[AxisContribution]:
    """Convert CLOPS readings into AxisContributions for T."""
    contribs = []
    for r in readings:
        if r.benchmark_name != "CLOPS":
            continue
        if r.metric_name != "clops_score":
            continue
        pv = tau_clops(r.value, raw_uncertainty=r.uncertainty)
        contribs.append(
            AxisContribution(
                axis=Axis.T,
                value=pv.value,
                uncertainty=pv.uncertainty,
                source=pv.description,
            )
        )
    return contribs


def _qft_contributions(
    readings: list[BenchmarkReading],
) -> list[AxisContribution]:
    """Convert QFT / Quantum Fourier Transform readings into AxisContributions for Φ."""
    contribs = []
    for r in readings:
        if r.benchmark_name not in ("QFT", "Quantum Fourier Transform"):
            continue
        # QFT publishes a fidelity-like scalar; different field names across versions
        if r.metric_name not in ("fidelity", "qft_score", "fidelity_score", "score"):
            continue
        pv = tau_qft(r.value, r.uncertainty)
        contribs.append(
            AxisContribution(
                axis=Axis.PHI,
                value=pv.value,
                uncertainty=pv.uncertainty,
                source=f"QFT@{r.width}Q {pv.description}" if r.width else pv.description,
            )
        )
    return contribs


def _mirror_contributions(
    readings: list[BenchmarkReading],
) -> list[AxisContribution]:
    """Convert Mirror Circuits readings into one AxisContribution for Φ.

    Aggregation rule (WCPP_SPEC.md §4.3, revised): arithmetic mean of
    τ_MC across all measured widths where success_probability > 0.
    """
    mirror = [r for r in readings if r.benchmark_name == "Mirror Circuits"]
    mirror = [r for r in mirror if r.metric_name == "success_probability"]
    transformed: list[tuple[int | None, float, float | None]] = []
    for r in mirror:
        if r.value <= 0.0:
            continue
        pv = tau_mirror_circuits(r.value, r.uncertainty)
        if pv.value > 0.0:
            transformed.append((r.width, pv.value, pv.uncertainty))
    if not transformed:
        return []
    return [_mean_contribution(Axis.PHI, "Mirror Circuits", transformed)]


def _lr_qaoa_contributions(
    readings: list[BenchmarkReading],
) -> list[AxisContribution]:
    """Convert LR-QAOA readings into one AxisContribution for Γ.

    Aggregation rule (WCPP_SPEC.md §4.3, revised): arithmetic mean of
    τ_QAOA across all measured widths where effective_approx_ratio > 0.
    """
    lr = [r for r in readings if r.benchmark_name == "Linear Ramp QAOA"]
    lr = [r for r in lr if r.metric_name == "effective_approx_ratio"]
    transformed: list[tuple[int | None, float, float | None]] = []
    for r in lr:
        if r.value <= 0.0:
            continue
        pv = tau_lr_qaoa(r.value, r.uncertainty)
        if pv.value > 0.0:
            transformed.append((r.width, pv.value, pv.uncertainty))
    if not transformed:
        return []
    return [_mean_contribution(Axis.GAMMA, "LR-QAOA", transformed)]


def compute_capability(
    device: DeviceRecord,
    readings: list[BenchmarkReading] | None = None,
) -> CapabilityValues:
    """Compute the four capability axis values for a device from its readings.

    Parameters
    ----------
    device:
        The DeviceRecord from the snapshot (provides num_qubits for BSEQ).
    readings:
        Optional filtered subset of readings. If None, uses device.readings.
        Either way, within-axis deduplication via (benchmark, metric, width)
        keeps only the most recent reading per slot.
    """
    if readings is None:
        readings = device.readings
    readings = _select_latest(readings)

    gamma_contribs: list[AxisContribution] = []
    gamma_contribs.extend(_bseq_contributions(device, readings))
    gamma_contribs.extend(_lr_qaoa_contributions(readings))

    phi_contribs: list[AxisContribution] = []
    phi_contribs.extend(_qft_contributions(readings))
    phi_contribs.extend(_mirror_contributions(readings))

    f_contribs: list[AxisContribution] = []
    f_contribs.extend(_eplg_contributions(readings))
    f_contribs.extend(_wit_contributions(readings))
    f_contribs.extend(_qml_contributions(readings))

    t_contribs: list[AxisContribution] = []
    t_contribs.extend(_clops_contributions(readings))

    def _resolve(axis: Axis, contribs: list[AxisContribution]):
        if contribs:
            return geometric_mean_aggregate(contribs, axis)
        prior_v, prior_s = axis_prior(axis)
        return apply_prior(axis, prior_v, prior_s)

    return CapabilityValues(
        device=device.device,
        gamma=_resolve(Axis.GAMMA, gamma_contribs),
        phi=_resolve(Axis.PHI, phi_contribs),
        f=_resolve(Axis.F, f_contribs),
        t=_resolve(Axis.T, t_contribs),
    )


def qlro_fit(
    device_name: str,
    workload: str,
    snapshot: MetriqSnapshot | None = None,
    reading_filter: Filter | None = None,
    custom_weights: dict[Axis, float] | None = None,
) -> FitScore:
    """Compute the WCPP fit score for a device under a workload.

    Parameters
    ----------
    device_name:
        Metriq device identifier (e.g. "ibm_torino", "ibm_fez").
    workload:
        Workload category string. See qlro.scoring.priors.WorkloadCategory.
        When custom_weights is provided, this is used only as a label.
    snapshot:
        Optional MetriqSnapshot. If None, loads the default snapshot path.
    reading_filter:
        Optional predicate to restrict which readings are used. Useful for
        reproducing historical calculations (e.g. "only 2025-10-20 data").
    custom_weights:
        Optional per-axis weight dict. Overrides default category weights.
    """
    snap = snapshot or MetriqSnapshot()
    device = snap.device(device_name)
    readings = device.readings
    if reading_filter is not None:
        readings = [r for r in readings if reading_filter(r)]

    cap = compute_capability(device, readings)
    return compose(cap, workload, custom_weights=custom_weights)
