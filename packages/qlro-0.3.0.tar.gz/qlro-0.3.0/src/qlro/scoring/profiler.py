"""Workload Profiler — converts user workload specs into custom weight vectors.

This is the key product layer that transforms Qlro from a static leaderboard
into a personalized recommendation engine. Given a user's circuit parameters,
it produces a physically-grounded weight vector for the WCPP scoring pipeline.

Physics rationale for each mapping:

- Γ (Connectivity): Qubit count and connectivity pattern determine how much
  routing overhead the device must absorb. All-to-all connectivity on a
  sparse-topology device requires many SWAP gates, making Γ critical.

- Φ (Coherence): Circuit depth determines how long qubits must stay coherent.
  Deep circuits (depth > 100) are coherence-limited; shallow ones are not.

- F (Fidelity): Accuracy requirements and 2Q gate count determine how much
  per-gate error is tolerable. Chemical accuracy on a 400-CNOT circuit
  requires extremely high fidelity.

- T (Throughput): Shot count determines total execution time. At 100K+ shots,
  throughput becomes the dominant practical concern.
"""
from __future__ import annotations

import math
from dataclasses import dataclass

from qlro.scoring.axes import Axis


@dataclass
class WorkloadSpec:
    """User-provided workload specification."""

    qubit_count: int
    circuit_depth: int
    two_qubit_gates: int
    connectivity: str  # "linear" | "ring" | "star" | "all-to-all" | "heavy-hex"
    accuracy: str  # "low" | "medium" | "high" | "chemical"
    shots: int = 1024
    category_hint: str | None = None


# ── Connectivity pressure ─────────────────────────────────────────────

# Maps connectivity pattern to a base pressure score [0, 1].
# Higher = more demanding on device native connectivity.
_CONNECTIVITY_PRESSURE: dict[str, float] = {
    "linear": 0.2,
    "ring": 0.3,
    "star": 0.5,
    "heavy-hex": 0.6,
    "all-to-all": 1.0,
}

# ── Accuracy demand ───────────────────────────────────────────────────

_ACCURACY_DEMAND: dict[str, float] = {
    "low": 0.2,
    "medium": 0.5,
    "high": 0.8,
    "chemical": 1.0,
}


def _sigmoid(x: float, midpoint: float, steepness: float = 0.05) -> float:
    """Smooth sigmoid mapping [0, ∞) → [0, 1], centered at midpoint."""
    return 1.0 / (1.0 + math.exp(-steepness * (x - midpoint)))


def profile_weights(spec: WorkloadSpec) -> dict[Axis, float]:
    """Convert a WorkloadSpec into a normalized WCPP weight vector.

    Each axis gets a raw "pressure" score based on the spec, then all
    four are normalized to sum to 1.

    Returns
    -------
    dict mapping each Axis to its weight (summing to 1.0).
    """
    # ── Γ pressure: connectivity pattern + qubit scaling ──
    conn_base = _CONNECTIVITY_PRESSURE.get(spec.connectivity, 0.5)
    qubit_scale = _sigmoid(spec.qubit_count, midpoint=50, steepness=0.04)
    gamma_raw = 0.4 * conn_base + 0.6 * conn_base * qubit_scale

    # ── Φ pressure: circuit depth ──
    # Shallow circuits (depth < 20) barely need coherence.
    # Deep circuits (depth > 200) are coherence-limited.
    phi_raw = _sigmoid(spec.circuit_depth, midpoint=100, steepness=0.03)

    # ── F pressure: accuracy + gate error accumulation ──
    acc_base = _ACCURACY_DEMAND.get(spec.accuracy, 0.5)
    # More 2Q gates → more accumulated error → higher fidelity need
    gate_pressure = _sigmoid(spec.two_qubit_gates, midpoint=200, steepness=0.01)
    f_raw = 0.5 * acc_base + 0.5 * gate_pressure

    # ── T pressure: shot count ──
    # Below 1K shots, throughput is irrelevant.
    # Above 100K shots, throughput dominates wall-clock time.
    t_raw = _sigmoid(spec.shots, midpoint=10000, steepness=0.0005)

    # ── Normalize to sum = 1 ──
    total = gamma_raw + phi_raw + f_raw + t_raw
    if total == 0:
        # Fallback: equal weights
        return {Axis.GAMMA: 0.25, Axis.PHI: 0.25, Axis.F: 0.25, Axis.T: 0.25}

    return {
        Axis.GAMMA: gamma_raw / total,
        Axis.PHI: phi_raw / total,
        Axis.F: f_raw / total,
        Axis.T: t_raw / total,
    }


def explain_weights(spec: WorkloadSpec, weights: dict[Axis, float]) -> str:
    """Generate a human-readable explanation of why the weights are set this way."""
    parts = []

    # Find the dominant axis
    dominant = max(weights, key=lambda a: weights[a])
    dominant_pct = weights[dominant] * 100

    axis_reasons = {
        Axis.GAMMA: f"connectivity={spec.connectivity} with {spec.qubit_count} qubits "
                     f"creates routing pressure",
        Axis.PHI: f"circuit depth={spec.circuit_depth} requires sustained coherence",
        Axis.F: f"accuracy={spec.accuracy} with {spec.two_qubit_gates} 2Q gates "
                 f"demands high per-gate fidelity",
        Axis.T: f"shots={spec.shots:,} makes throughput the execution bottleneck",
    }

    parts.append(
        f"Dominant axis: {dominant.value} ({dominant_pct:.0f}%) — "
        f"{axis_reasons[dominant]}"
    )

    # Weight vector summary
    wstr = ", ".join(
        f"{a.value}={weights[a]:.2f}" for a in [Axis.GAMMA, Axis.PHI, Axis.F, Axis.T]
    )
    parts.append(f"Weight vector: [{wstr}]")

    return ". ".join(parts)
