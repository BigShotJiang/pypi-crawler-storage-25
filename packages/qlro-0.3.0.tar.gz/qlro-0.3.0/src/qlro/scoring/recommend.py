"""Recommendation engine — scores all devices with custom weights and
produces a structured recommendation with explanation.
"""
from __future__ import annotations

from dataclasses import dataclass, field

from qlro.scoring.axes import Axis
from qlro.scoring.composition import FitScore
from qlro.scoring.data_loader import MetriqSnapshot
from qlro.scoring.profiler import WorkloadSpec, explain_weights, profile_weights
from qlro.scoring.wcpp import compute_capability, compose


@dataclass
class Recommendation:
    """Structured recommendation output."""

    primary: FitScore
    alternative: FitScore
    all_scores: list[FitScore]
    reason: str
    tradeoffs: str
    confidence: str  # "high" | "medium" | "low"
    warnings: list[str]
    weights: dict[Axis, float]
    weight_explanation: str
    spec: WorkloadSpec


def _confidence_level(primary: FitScore, alternative: FitScore) -> str:
    """Assess confidence based on score gap and estimation flags."""
    gap = primary.value - alternative.value
    gap_pct = gap / primary.value if primary.value > 0 else 0

    if primary.any_axis_estimated:
        return "low"
    if gap_pct < 0.05:
        return "low"
    if gap_pct < 0.15:
        return "medium"
    return "high"


def _generate_reason(primary: FitScore, spec: WorkloadSpec) -> str:
    """Explain why the primary device was recommended."""
    axes = primary.axis_values.as_dict()

    # Find the device's strongest axis relative to the workload weights
    weighted_contributions = {
        a: axes[a].value * primary.weights[a]
        for a in [Axis.GAMMA, Axis.PHI, Axis.F, Axis.T]
    }
    strongest = max(weighted_contributions, key=lambda a: weighted_contributions[a])

    axis_names = {
        Axis.GAMMA: "connectivity",
        Axis.PHI: "coherence",
        Axis.F: "fidelity",
        Axis.T: "throughput",
    }

    return (
        f"{primary.device} scores highest (fit={primary.value:.4f}) for your "
        f"{spec.qubit_count}-qubit, depth-{spec.circuit_depth} workload. "
        f"Its {axis_names[strongest]} ({axes[strongest].value:.3f}) is the "
        f"strongest weighted contributor under your spec's requirements."
    )


def _generate_tradeoffs(
    primary: FitScore, alternative: FitScore, spec: WorkloadSpec
) -> str:
    """Explain tradeoffs between primary and alternative."""
    p_axes = primary.axis_values.as_dict()
    a_axes = alternative.axis_values.as_dict()

    advantages = []
    for axis in [Axis.GAMMA, Axis.PHI, Axis.F, Axis.T]:
        if a_axes[axis].value > p_axes[axis].value + 0.05:
            axis_name = axis.value
            advantages.append(
                f"{axis_name} ({a_axes[axis].value:.3f} vs {p_axes[axis].value:.3f})"
            )

    if advantages:
        return (
            f"{alternative.device} (fit={alternative.value:.4f}) has stronger "
            + ", ".join(advantages)
            + f", but scores lower overall due to weaker performance on "
            f"the axes your workload weights most."
        )
    return (
        f"{alternative.device} (fit={alternative.value:.4f}) is close "
        f"but does not exceed {primary.device} on any heavily-weighted axis."
    )


def _generate_warnings(scores: list[FitScore]) -> list[str]:
    """Generate warnings about estimation and uncertainty."""
    warnings = []
    top = scores[0]

    if top.any_axis_estimated:
        # Find which axes are estimated
        axes = top.axis_values.as_dict()
        estimated = [a.value for a in [Axis.GAMMA, Axis.PHI, Axis.F, Axis.T]
                     if axes[a].is_estimated]
        warnings.append(
            f"{top.device}'s {', '.join(estimated)} axis(es) rely on "
            f"population priors — actual performance may differ."
        )

    if top.uncertainty is not None:
        ratio = top.uncertainty / top.value if top.value > 0 else 0
        if ratio > 0.10:
            warnings.append(
                f"Uncertainty is {ratio:.0%} of fit score — "
                f"recommendation should be validated empirically."
            )

    # Check if top two are very close
    if len(scores) >= 2:
        gap = scores[0].value - scores[1].value
        if scores[0].value > 0 and gap / scores[0].value < 0.03:
            warnings.append(
                f"{scores[0].device} and {scores[1].device} are within 3% — "
                f"practical factors (cost, availability) may matter more."
            )

    return warnings


def recommend(
    spec: WorkloadSpec,
    snapshot: MetriqSnapshot | None = None,
) -> Recommendation:
    """Run the full recommendation pipeline.

    1. Convert spec → custom weight vector via WorkloadProfiler
    2. Score all devices with custom weights
    3. Rank, select top 2, generate explanation
    """
    snap = snapshot or MetriqSnapshot()
    weights = profile_weights(spec)
    weight_explanation = explain_weights(spec, weights)

    # Score all devices
    workload_label = spec.category_hint or "custom"
    scores: list[FitScore] = []
    for device_name in snap.devices():
        cap = compute_capability(snap.device(device_name))
        fit = compose(cap, workload_label, custom_weights=weights)
        scores.append(fit)

    # Sort by fit score descending
    scores.sort(key=lambda s: -s.value)

    primary = scores[0]
    alternative = scores[1] if len(scores) > 1 else scores[0]

    return Recommendation(
        primary=primary,
        alternative=alternative,
        all_scores=scores,
        reason=_generate_reason(primary, spec),
        tradeoffs=_generate_tradeoffs(primary, alternative, spec),
        confidence=_confidence_level(primary, alternative),
        warnings=_generate_warnings(scores),
        weights=weights,
        weight_explanation=weight_explanation,
        spec=spec,
    )
