"""Physical translation transforms (Stage 1 of WCPP).

Each function τ_b: ℝ → [0,1] converts a raw benchmark value into a dimensionless
physical quantity bounded by a *theoretical* maximum — not by any observed
device's value. This is what enforces Axiom 1 (Locality) and is the root of
Theorem 1 (Baseline Invariance).

See WCPP_SPEC.md §8 for the full transform catalog and physics justifications.
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Callable

# -- Calibration constants (see WCPP_SPEC.md §10) --

# CLOPS horizon: C_0 where τ_CLOPS reaches 1 - 1/e ≈ 0.632.
# 500,000 is the operational default anchored at the wall-clock boundary
# of typical interactive experiments.
CLOPS_HORIZON = 500_000.0

# WIT v0.4 circuit uses 24 two-qubit gates. This is version-dependent and
# should be read from benchmark metadata in a future revision.
WIT_GATE_COUNT_V04 = 24


@dataclass
class PhysicalValue:
    """Result of a physical transform: dimensionless value in [0,1] with uncertainty."""

    value: float
    uncertainty: float | None
    description: str = ""

    def __repr__(self) -> str:
        u = f" ± {self.uncertainty:.4g}" if self.uncertainty is not None else ""
        return f"{self.value:.4g}{u}"


def _propagate(
    value: float, dtau_dv: float, raw_uncertainty: float | None
) -> float | None:
    """First-order error propagation for a single-variable transform."""
    if raw_uncertainty is None:
        return None
    return abs(dtau_dv) * raw_uncertainty


def _clip(x: float) -> float:
    """Clip to [0, 1] to enforce the physical bound."""
    if x < 0.0:
        return 0.0
    if x > 1.0:
        return 1.0
    return x


# -- Transform catalog --


def tau_bseq(
    largest_connected_size: float, num_qubits: int, raw_uncertainty: float | None = None
) -> PhysicalValue:
    """BSEQ → Γ (Connectivity).

    Fraction of the chip with functional Bell-verified entanglement.
    τ_BSEQ(v) = v / N where N is the chip qubit count.
    """
    if num_qubits <= 0:
        raise ValueError(f"num_qubits must be positive, got {num_qubits}")
    value = _clip(largest_connected_size / num_qubits)
    # ∂τ/∂v = 1/N (the N denominator is a fixed physical constant per device,
    # so propagation treats it as exact)
    uncertainty = _propagate(value, 1.0 / num_qubits, raw_uncertainty)
    return PhysicalValue(value, uncertainty, f"BSEQ {largest_connected_size}/{num_qubits}")


def tau_eplg(
    eplg: float, raw_uncertainty: float | None = None
) -> PhysicalValue:
    """EPLG → F (Fidelity).

    Survival probability per layer. τ_EPLG(v) = 1 - v.
    Typical raw range: [0.001, 0.15].
    """
    value = _clip(1.0 - eplg)
    # ∂τ/∂v = -1
    uncertainty = _propagate(value, -1.0, raw_uncertainty)
    return PhysicalValue(value, uncertainty, f"EPLG 1 − {eplg:.4g}")


def tau_wit(
    expectation: float,
    gate_count: int = WIT_GATE_COUNT_V04,
    raw_uncertainty: float | None = None,
) -> PhysicalValue:
    """WIT → F (Fidelity).

    Per-2Q-gate effective fidelity via multiplicative error model.
    τ_WIT(v) = v^(1/k) where k is the number of 2Q gates in the circuit.
    """
    if expectation <= 0:
        return PhysicalValue(0.0, None, f"WIT {expectation:.4g} non-positive → 0")
    value = _clip(expectation ** (1.0 / gate_count))
    # ∂τ/∂v = (1/k) * v^((1/k) - 1)
    derivative = (1.0 / gate_count) * expectation ** ((1.0 / gate_count) - 1.0)
    uncertainty = _propagate(value, derivative, raw_uncertainty)
    return PhysicalValue(value, uncertainty, f"WIT {expectation:.4g}^(1/{gate_count})")


def tau_qml_kernel(
    accuracy: float, raw_uncertainty: float | None = None
) -> PhysicalValue:
    """QML Kernel → F (Fidelity).

    Skill above random for binary classification.
    τ_QML(v) = max(0, 2v - 1).
    """
    value = _clip(2.0 * accuracy - 1.0)
    # ∂τ/∂v = 2 (when above random), 0 (when clamped)
    if 2.0 * accuracy - 1.0 > 0:
        uncertainty = _propagate(value, 2.0, raw_uncertainty)
    else:
        uncertainty = None
    return PhysicalValue(value, uncertainty, f"QML 2×{accuracy:.4g} − 1")


def tau_clops(
    clops_score: float,
    horizon: float = CLOPS_HORIZON,
    raw_uncertainty: float | None = None,
) -> PhysicalValue:
    """CLOPS → T (Throughput).

    Saturating exponential toward 1 with physical horizon constant.
    τ_CLOPS(v) = 1 - exp(-v / C_0).
    """
    value = _clip(1.0 - math.exp(-clops_score / horizon))
    # ∂τ/∂v = (1/C_0) * exp(-v/C_0) = (1 - value) / C_0
    derivative = (1.0 - value) / horizon
    uncertainty = _propagate(value, derivative, raw_uncertainty)
    return PhysicalValue(
        value, uncertainty, f"CLOPS 1 − exp(−{clops_score:.0f}/{horizon:.0f})"
    )


def tau_qft(
    fidelity: float, raw_uncertainty: float | None = None
) -> PhysicalValue:
    """QFT → Φ (Coherence).

    Already dimensionless; identity transform.
    τ_QFT(v) = v.
    """
    value = _clip(fidelity)
    uncertainty = raw_uncertainty
    return PhysicalValue(value, uncertainty, f"QFT {fidelity:.4g}")


def tau_mirror_circuits(
    success_probability: float, raw_uncertainty: float | None = None
) -> PhysicalValue:
    """Mirror Circuits → Φ (Coherence).

    Already dimensionless; identity transform.
    τ_MC(v) = v.
    """
    value = _clip(success_probability)
    uncertainty = raw_uncertainty
    return PhysicalValue(value, uncertainty, f"MC {success_probability:.4g}")


def tau_lr_qaoa(
    effective_approx_ratio: float, raw_uncertainty: float | None = None
) -> PhysicalValue:
    """LR-QAOA → Γ (Connectivity).

    The Metriq dataset publishes `effective_approx_ratio` which is already
    (approx_ratio − random_baseline) / (1 − random_baseline), in [0, 1].
    We use it directly.
    """
    value = _clip(effective_approx_ratio)
    uncertainty = raw_uncertainty
    return PhysicalValue(
        value, uncertainty, f"LR-QAOA eff {effective_approx_ratio:.4g}"
    )
