"""Workload capability requirement vectors and missing-axis priors.

These are the default values from WCPP_SPEC.md §5.4.1 and §10.5. All of them
can be overridden per-call, and they are expected to be replaced by outcome-
calibrated posteriors once the product accumulates user feedback data
(the Layer 3 adaptive system in the strategic plan).
"""

from __future__ import annotations

from qlro.scoring.axes import Axis


class WorkloadCategory:
    """Canonical workload categories. Free-form string for now; a class-based
    enum would lock this too early since users will want custom categories.
    """

    CHEMISTRY = "chemistry"
    SIMULATION = "simulation"
    OPTIMIZATION = "optimization"
    ML = "ml"


# Capability requirement vectors w_α, per WCPP_SPEC.md §5.4.1.
# Each vector must sum to 1.
DEFAULT_WORKLOAD_WEIGHTS: dict[str, dict[Axis, float]] = {
    WorkloadCategory.CHEMISTRY: {
        Axis.GAMMA: 0.15,
        Axis.PHI: 0.30,
        Axis.F: 0.45,
        Axis.T: 0.10,
    },
    WorkloadCategory.SIMULATION: {
        Axis.GAMMA: 0.20,
        Axis.PHI: 0.40,
        Axis.F: 0.30,
        Axis.T: 0.10,
    },
    WorkloadCategory.OPTIMIZATION: {
        Axis.GAMMA: 0.40,
        Axis.PHI: 0.15,
        Axis.F: 0.30,
        Axis.T: 0.15,
    },
    WorkloadCategory.ML: {
        Axis.GAMMA: 0.20,
        Axis.PHI: 0.10,
        Axis.F: 0.30,
        Axis.T: 0.40,
    },
}


# Population-wide prior values for each axis (WCPP_SPEC.md §10.5).
# Used when no benchmark data is available for a given axis.
#
# As of paper v0.6, these are the empirical median and standard deviation of
# the *measured* (non-prior) axis values across the 13 devices in the
# reference snapshot (metriq-data commit 89cd842f23). T sigma is floored at
# 0.10 because T is derived from a single benchmark (CLOPS) on a narrow
# device subset, and the observed stdev of 0.008 would understate the true
# epistemic uncertainty for devices without CLOPS measurements.
#
# Replacing these priors with snapshot-derived medians was motivated by an
# external review in v0.6 flagging that the prior Φ value (0.80) was 3x
# higher than observed Φ values (median 0.26), artificially inflating the
# scores of devices lacking Φ measurements (notably ibm_brisbane on the
# Φ-heavy simulation workload). See paper §8.7 and §9.1 for discussion.
DEFAULT_AXIS_PRIORS: dict[Axis, tuple[float, float]] = {
    # (empirical_median, empirical_sigma)
    Axis.GAMMA: (0.69, 0.31),
    Axis.PHI: (0.26, 0.23),
    Axis.F: (0.80, 0.18),
    Axis.T: (0.51, 0.10),
}


def workload_weights(category: str) -> dict[Axis, float]:
    """Return the capability requirement vector for a workload category."""
    if category not in DEFAULT_WORKLOAD_WEIGHTS:
        raise ValueError(
            f"Unknown workload category {category!r}. "
            f"Known categories: {sorted(DEFAULT_WORKLOAD_WEIGHTS.keys())}"
        )
    return dict(DEFAULT_WORKLOAD_WEIGHTS[category])


def axis_prior(axis: Axis) -> tuple[float, float]:
    """Return (median, sigma) for a missing-data fallback."""
    return DEFAULT_AXIS_PRIORS[axis]
