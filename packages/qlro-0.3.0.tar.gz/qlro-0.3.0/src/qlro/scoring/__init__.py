"""WCPP scoring module — reference implementation of Workload-Conditioned
Physical Projection, as specified in WCPP_SPEC.md at the repo root.

Public entry points are re-exported here as modules are added.
"""
