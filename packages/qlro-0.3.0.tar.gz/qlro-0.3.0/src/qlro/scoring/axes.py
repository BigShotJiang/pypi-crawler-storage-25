"""Axis projection (Stage 2 of WCPP).

Maps each benchmark to its primary capability axis, then aggregates within-axis
contributions via geometric mean. Also handles missing-axis fallback with
population-prior inflation.

See WCPP_SPEC.md §4-5.
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from enum import Enum
from typing import Iterable


class Axis(str, Enum):
    """The four capability axes."""

    GAMMA = "Gamma"  # Connectivity
    PHI = "Phi"  # Coherence
    F = "F"  # Fidelity
    T = "T"  # Throughput


# Fixed benchmark-to-axis mapping (WCPP_SPEC.md §4 Table)
BENCHMARK_AXIS: dict[str, Axis] = {
    "BSEQ": Axis.GAMMA,
    "Linear Ramp QAOA": Axis.GAMMA,
    "QFT": Axis.PHI,
    "Quantum Fourier Transform": Axis.PHI,  # Metriq's canonical name
    "Mirror Circuits": Axis.PHI,
    "EPLG": Axis.F,
    "WIT": Axis.F,
    "QML Kernel": Axis.F,
    "CLOPS": Axis.T,
}


@dataclass
class AxisContribution:
    """A single transformed-physical-value contribution to an axis."""

    axis: Axis
    value: float
    uncertainty: float | None
    source: str  # human-readable label like "BSEQ 113/133"

    def __repr__(self) -> str:
        u = f" ± {self.uncertainty:.4g}" if self.uncertainty is not None else ""
        return f"{self.axis.value}[{self.source}] = {self.value:.4g}{u}"


@dataclass
class AxisValue:
    """Aggregated value for a single axis on a single device."""

    axis: Axis
    value: float
    uncertainty: float | None
    contributions: list[AxisContribution]
    is_estimated: bool = False  # True if fell back to prior

    def __repr__(self) -> str:
        u = f" ± {self.uncertainty:.4g}" if self.uncertainty is not None else ""
        flag = " (estimated)" if self.is_estimated else ""
        return f"{self.axis.value} = {self.value:.4g}{u}{flag}"


@dataclass
class CapabilityValues:
    """All four capability axes for a single device."""

    device: str
    gamma: AxisValue
    phi: AxisValue
    f: AxisValue
    t: AxisValue

    def as_dict(self) -> dict[Axis, AxisValue]:
        return {
            Axis.GAMMA: self.gamma,
            Axis.PHI: self.phi,
            Axis.F: self.f,
            Axis.T: self.t,
        }

    def any_estimated(self) -> bool:
        return any(av.is_estimated for av in self.as_dict().values())


def geometric_mean_aggregate(
    contributions: list[AxisContribution], axis: Axis
) -> AxisValue:
    """Combine multiple benchmark contributions to one axis via geometric mean.

    σ(log X) is computed via standard error propagation for log transforms:
        σ(log X)² = (1/k²) Σ (σ_i / x_i)²
    """
    if not contributions:
        raise ValueError(f"No contributions to aggregate for axis {axis}")

    k = len(contributions)
    log_values = []
    rel_var = 0.0
    any_uncertainty = False

    for c in contributions:
        # Guard against zero values — geometric mean of anything with a 0 is 0.
        # Propagate that explicitly rather than blowing up.
        if c.value == 0.0:
            return AxisValue(
                axis=axis,
                value=0.0,
                uncertainty=None,
                contributions=contributions,
                is_estimated=False,
            )
        log_values.append(math.log(c.value))
        if c.uncertainty is not None:
            rel_var += (c.uncertainty / c.value) ** 2
            any_uncertainty = True

    log_mean = sum(log_values) / k
    value = math.exp(log_mean)

    if any_uncertainty:
        sigma_log = math.sqrt(rel_var) / k
        sigma = value * sigma_log
    else:
        sigma = None

    return AxisValue(
        axis=axis,
        value=value,
        uncertainty=sigma,
        contributions=contributions,
        is_estimated=False,
    )


def apply_prior(axis: Axis, prior_value: float, prior_sigma: float) -> AxisValue:
    """Fall back to a population prior when no benchmark data is available.

    See WCPP_SPEC.md §4 (missing-data rule) and §10.4 (inflation factor).
    """
    return AxisValue(
        axis=axis,
        value=prior_value,
        uncertainty=prior_sigma * 2.0,  # 2× inflation factor per spec §10.4
        contributions=[],
        is_estimated=True,
    )


def axis_for_benchmark(benchmark_name: str) -> Axis | None:
    """Return the capability axis for a benchmark, or None if unmapped."""
    return BENCHMARK_AXIS.get(benchmark_name)
