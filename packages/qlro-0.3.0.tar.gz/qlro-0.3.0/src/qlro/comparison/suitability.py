"""Suitability scoring — adjusts normalized scores based on workload fingerprint.

The core idea: a normalized comparison tells you how environments rank on
raw dimensions. Suitability scoring tells you how much each dimension
*matters* for this specific workload.

A chemistry workload with high noise_sensitivity should be penalized more
on an environment with a low confidence_score. A shallow ML workload
shouldn't care much about depth-related noise.

This is a rule-based scoring layer, not a model. All rules are in a
lookup table and documented.

What is real:
- The penalty/bonus calculations are deterministic and testable
- The fingerprint-to-adjustment mapping is explicit

What is approximate:
- The penalty magnitudes are heuristic (not empirically calibrated)
- The interaction between dimensions is simplified (no cross-terms)
"""

from qlro.schemas import (
    CandidateEnvironment,
    EnvironmentProfile,
    NormalizedComparison,
    Workload,
)
from qlro.schemas.fingerprint import WorkloadFingerprint, compute_fingerprint


def apply_suitability(
    workload: Workload,
    comparisons: list[NormalizedComparison],
    environments: dict,  # UUID -> CandidateEnvironment
) -> list[NormalizedComparison]:
    """Adjust overall scores using workload-environment suitability rules.

    Does NOT replace the normalized scores — adjusts overall_score only.
    Original dimension scores are preserved for transparency.

    Returns new NormalizedComparison objects with adjusted overall_score
    and suitability-related assumptions appended.
    """
    fingerprint = compute_fingerprint(workload)
    adjusted = []

    for comp in comparisons:
        env = environments[comp.environment_id]
        adjustment, reasons = _compute_adjustment(fingerprint, comp, env)

        new_overall = round(comp.overall_score + adjustment, 4)
        # Clamp to [0, max reasonable] — don't let adjustments go negative
        new_overall = max(0.0, new_overall)

        new_assumptions = list(comp.assumptions)
        for reason in reasons:
            new_assumptions.append(f"Suitability: {reason}")

        adjusted.append(NormalizedComparison(
            id=comp.id,
            workload_id=comp.workload_id,
            environment_id=comp.environment_id,
            experiment_result_id=comp.experiment_result_id,
            runtime_score=comp.runtime_score,
            cost_score=comp.cost_score,
            confidence_score=comp.confidence_score,
            feasibility_score=comp.feasibility_score,
            overall_score=new_overall,
            assumptions=new_assumptions,
        ))

    return adjusted


def _compute_adjustment(
    fp: WorkloadFingerprint,
    comp: NormalizedComparison,
    env: CandidateEnvironment,
) -> tuple[float, list[str]]:
    """Compute suitability adjustment for one environment.

    Rules:
    1. If workload has high noise_sensitivity and environment confidence is low → penalty
    2. If workload has high fidelity_need and environment confidence is high → bonus
    3. If workload has high qubit_pressure and environment max_qubits is tight → penalty
    4. If environment has a profile with high error rates and workload is noise-sensitive → penalty

    Returns (adjustment_float, list_of_reason_strings).
    """
    adjustment = 0.0
    reasons = []

    # Rule 1: Noise sensitivity vs confidence score
    if fp.noise_sensitivity > 0.6 and comp.confidence_score < 0.4:
        penalty = -0.1 * fp.noise_sensitivity
        adjustment += penalty
        reasons.append(
            f"Noise-sensitive workload ({fp.noise_sensitivity:.1f}) on low-confidence "
            f"environment ({comp.confidence_score:.2f}): {penalty:+.3f}"
        )

    # Rule 2: Fidelity need vs confidence score
    if fp.fidelity_need > 0.7 and comp.confidence_score > 0.7:
        bonus = 0.05 * fp.fidelity_need
        adjustment += bonus
        reasons.append(
            f"High-fidelity workload ({fp.fidelity_need:.1f}) on high-confidence "
            f"environment ({comp.confidence_score:.2f}): {bonus:+.3f}"
        )

    # Rule 3: Qubit pressure vs environment capacity
    if fp.qubit_pressure > 0.7 and env.max_qubits is not None:
        needed = int(fp.qubit_pressure * 30)  # reference scale
        if needed > env.max_qubits * 0.8:  # within 80% of capacity
            penalty = -0.15
            adjustment += penalty
            reasons.append(
                f"Qubit pressure ({needed} qubits) near environment limit "
                f"({env.max_qubits} qubits): {penalty:+.3f}"
            )

    # Rule 4: Profile-based noise penalty
    if env.profile is not None and fp.noise_sensitivity > 0.5:
        profile_penalty = _profile_noise_penalty(env.profile, fp)
        if abs(profile_penalty) > 0.001:
            adjustment += profile_penalty
            reasons.append(
                f"Environment noise profile penalty for noise-sensitive workload: "
                f"{profile_penalty:+.3f}"
            )

    return round(adjustment, 4), reasons


def _profile_noise_penalty(profile: EnvironmentProfile, fp: WorkloadFingerprint) -> float:
    """Calculate penalty from structured noise characteristics.

    Higher error rates × higher workload sensitivity = bigger penalty.
    """
    penalty = 0.0

    if profile.two_gate_error is not None:
        # Two-qubit gate error matters most for entangled circuits
        if profile.two_gate_error > 0.01:
            penalty -= profile.two_gate_error * fp.noise_sensitivity * 0.5

    if profile.readout_error is not None:
        if profile.readout_error > 0.01:
            penalty -= profile.readout_error * fp.noise_sensitivity * 0.3

    if profile.single_gate_error is not None:
        if profile.single_gate_error > 0.005:
            penalty -= profile.single_gate_error * fp.noise_sensitivity * 0.2

    return round(penalty, 4)
