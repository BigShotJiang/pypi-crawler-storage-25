"""Normalization and comparison module."""

from qlro.comparison.normalizer import (
    normalize_results,
    extract,
    normalize,
    discount,
    compute_feasibility,
    DataProvenance,
    PROVENANCE_DISCOUNT,
)
from qlro.comparison.suitability import apply_suitability
from qlro.comparison.serialize import serialize_result

__all__ = [
    "normalize_results",
    "extract",
    "normalize",
    "discount",
    "compute_feasibility",
    "DataProvenance",
    "PROVENANCE_DISCOUNT",
    "apply_suitability",
    "serialize_result",
]
