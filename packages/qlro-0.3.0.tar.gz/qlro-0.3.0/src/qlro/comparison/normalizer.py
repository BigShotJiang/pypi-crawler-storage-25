"""Normalization pipeline — converts raw experiment results into comparable scores.

Pipeline stages:
1. EXTRACT   — pull raw values from results + environments, tag provenance
2. NORMALIZE — min-max scale each dimension within the comparison set
3. DISCOUNT  — reduce weight of estimated/assumed values
4. SCORE     — apply workload-aware suitability weights → overall score

Each stage is a pure function, independently testable.
All provenance is tracked and surfaced in the output.

What is real:
- Provenance tagging: observed/estimated/assumed is correctly identified
- Min-max normalization math
- Provenance discount factors (0.8 for estimated, 0.5 for assumed)
- Pipeline stage separation

What is approximate:
- The discount factors (0.8, 0.5) are heuristic, not empirically calibrated
- Feasibility composite weights (0.7 success + 0.3 queue) are heuristic
"""

from enum import Enum

from qlro.schemas import (
    CandidateEnvironment,
    ExperimentResult,
    NormalizedComparison,
    Workload,
)


class DataProvenance(str, Enum):
    """How a data point was obtained."""
    observed = "observed"      # Measured from an actual experiment run
    estimated = "estimated"    # User-provided estimate, not measured
    assumed = "assumed"        # Defaulted by the system due to missing data


# Discount factors: how much to trust each provenance level.
# 1.0 = full trust, 0.0 = ignore completely.
PROVENANCE_DISCOUNT = {
    DataProvenance.observed: 1.0,
    DataProvenance.estimated: 0.8,
    DataProvenance.assumed: 0.5,
}


class DimensionValue:
    """A single extracted value with its provenance."""
    __slots__ = ("value", "provenance", "label")

    def __init__(self, value: float, provenance: DataProvenance, label: str):
        self.value = value
        self.provenance = provenance
        self.label = label


class ExtractedRow:
    """All extracted dimensions for one environment."""
    __slots__ = ("env", "result", "runtime", "cost", "fidelity", "success", "queue_time")

    def __init__(self, env, result, runtime, cost, fidelity, success, queue_time):
        self.env = env
        self.result = result
        self.runtime = runtime
        self.cost = cost
        self.fidelity = fidelity
        self.success = success
        self.queue_time = queue_time


# ---- STAGE 1: EXTRACT ----

def extract(
    results: list[tuple[CandidateEnvironment, ExperimentResult]],
) -> list[ExtractedRow]:
    """Extract raw values with provenance tags from results + environments."""
    rows = []
    for env, result in results:
        rows.append(ExtractedRow(
            env=env,
            result=result,
            runtime=_extract_runtime(result),
            cost=_extract_cost(env, result),
            fidelity=_extract_fidelity(result),
            success=_extract_success(result),
            queue_time=_extract_queue_time(env),
        ))
    return rows


def _extract_runtime(result: ExperimentResult) -> DimensionValue:
    if result.measured_runtime_sec is not None:
        return DimensionValue(result.measured_runtime_sec, DataProvenance.observed, "Runtime")
    return DimensionValue(0.0, DataProvenance.assumed, "Runtime")


def _extract_cost(env: CandidateEnvironment, result: ExperimentResult) -> DimensionValue:
    if result.estimated_cost_usd is not None:
        # Per-shot pricing is computed from real formulas — mark as observed
        prov = DataProvenance.observed if env.cost_per_shot is not None else DataProvenance.estimated
        return DimensionValue(result.estimated_cost_usd, prov, "Cost")
    if env.estimated_cost_per_run is not None:
        return DimensionValue(env.estimated_cost_per_run, DataProvenance.estimated, "Cost")
    return DimensionValue(0.0, DataProvenance.assumed, "Cost")


def _extract_fidelity(result: ExperimentResult) -> DimensionValue:
    if result.output_fidelity is not None:
        return DimensionValue(result.output_fidelity, DataProvenance.observed, "Fidelity")
    return DimensionValue(0.0, DataProvenance.assumed, "Fidelity")


def _extract_success(result: ExperimentResult) -> DimensionValue:
    if result.success_rate is not None:
        return DimensionValue(result.success_rate, DataProvenance.observed, "Success rate")
    return DimensionValue(0.0, DataProvenance.assumed, "Success rate")


def _extract_queue_time(env: CandidateEnvironment) -> DimensionValue:
    if env.estimated_queue_time_sec is not None:
        return DimensionValue(env.estimated_queue_time_sec, DataProvenance.estimated, "Queue time")
    return DimensionValue(0.0, DataProvenance.assumed, "Queue time")


# ---- STAGE 2: NORMALIZE ----

def normalize(value: float, all_values: list[float], lower_is_better: bool) -> float:
    """Min-max normalize. Always returns higher = better."""
    min_val = min(all_values)
    max_val = max(all_values)
    if max_val == min_val:
        return 0.5
    normed = (value - min_val) / (max_val - min_val)
    if lower_is_better:
        return round(1.0 - normed, 4)
    return round(normed, 4)


# ---- STAGE 3: DISCOUNT ----

def discount(score: float, provenance: DataProvenance) -> float:
    """Apply provenance discount — estimated/assumed data gets reduced weight."""
    return round(score * PROVENANCE_DISCOUNT[provenance], 4)


# ---- STAGE 4: SCORE ----

def compute_feasibility(success_rate: float, queue_score: float) -> float:
    """Composite feasibility: 70% success rate + 30% queue accessibility."""
    return round(0.7 * success_rate + 0.3 * queue_score, 4)


# ---- FULL PIPELINE ----

def normalize_results(
    workload: Workload,
    results: list[tuple[CandidateEnvironment, ExperimentResult]],
    apply_discount: bool = True,
) -> list[NormalizedComparison]:
    """Run the full normalization pipeline.

    Args:
        workload: The workload being compared.
        results: List of (environment, result) pairs.
        apply_discount: Whether to apply provenance discounting. Default True.
            Set False for tests that need raw normalized scores.
    """
    if not results:
        return []

    # Stage 1: Extract
    rows = extract(results)

    # Collect value arrays for stage 2
    runtimes = [r.runtime.value for r in rows]
    costs = [r.cost.value for r in rows]
    fidelities = [r.fidelity.value for r in rows]
    queue_times = [r.queue_time.value for r in rows]

    comparisons = []
    for row in rows:
        assumptions = []

        # Stage 2: Normalize each dimension
        runtime_score = normalize(row.runtime.value, runtimes, lower_is_better=True)
        cost_score = normalize(row.cost.value, costs, lower_is_better=True)
        confidence_score = normalize(row.fidelity.value, fidelities, lower_is_better=False)
        queue_score = normalize(row.queue_time.value, queue_times, lower_is_better=True)
        feasibility_score = compute_feasibility(row.success.value, queue_score)

        # Stage 3: Discount by provenance
        if apply_discount:
            runtime_score = discount(runtime_score, row.runtime.provenance)
            cost_score = discount(cost_score, row.cost.provenance)
            confidence_score = discount(confidence_score, row.fidelity.provenance)
            # feasibility gets the worse of its two provenances
            worse_prov = _worse_provenance(row.success.provenance, row.queue_time.provenance)
            feasibility_score = discount(feasibility_score, worse_prov)

        # Track assumptions
        _track_assumptions(row, assumptions)

        # Stage 4: Weighted overall score
        overall_score = (
            workload.priority_speed * runtime_score
            + workload.priority_cost * cost_score
            + workload.priority_confidence * confidence_score
            + 0.1 * feasibility_score
        )

        comparisons.append(NormalizedComparison(
            workload_id=workload.id,
            environment_id=row.env.id,
            experiment_result_id=row.result.id,
            runtime_score=runtime_score,
            cost_score=cost_score,
            confidence_score=confidence_score,
            feasibility_score=feasibility_score,
            overall_score=round(overall_score, 4),
            assumptions=assumptions,
        ))

    return comparisons


def _worse_provenance(a: DataProvenance, b: DataProvenance) -> DataProvenance:
    """Return the less trustworthy of two provenances."""
    order = {DataProvenance.observed: 0, DataProvenance.estimated: 1, DataProvenance.assumed: 2}
    return a if order[a] >= order[b] else b


def _track_assumptions(row: ExtractedRow, assumptions: list[str]) -> None:
    """Build assumption strings from provenance tags."""
    for dim in [row.runtime, row.cost, row.fidelity, row.success, row.queue_time]:
        if dim.provenance == DataProvenance.assumed:
            assumptions.append(f"{dim.label} was not measured; defaulted to {dim.value} (assumed)")
        elif dim.provenance == DataProvenance.estimated:
            assumptions.append(f"{dim.label} is a user-provided estimate, not a measurement (estimated)")
