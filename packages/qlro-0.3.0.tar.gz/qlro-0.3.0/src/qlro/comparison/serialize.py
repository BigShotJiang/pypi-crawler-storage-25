"""Serialize pipeline output into the flat dict the frontend consumes.

One function, one output shape. Used by both the API response and
the ComparisonRun storage blob.
"""

from qlro.schemas import (
    CandidateEnvironment,
    ExperimentResult,
    NormalizedComparison,
    Recommendation,
    Workload,
    compute_fingerprint,
)


def serialize_result(
    workload: Workload,
    env_map: dict,  # UUID -> CandidateEnvironment
    comparisons: list[NormalizedComparison],
    recommendation: Recommendation,
    result_map: dict | None = None,  # UUID -> ExperimentResult
) -> dict:
    """Serialize a full pipeline result into the frontend-ready dict."""
    ranked = sorted(comparisons, key=lambda c: c.overall_score, reverse=True)
    rec = recommendation
    expl = rec.explanation
    fp = compute_fingerprint(workload)

    primary_env = env_map[rec.primary_environment_id]
    secondary_env = env_map[rec.secondary_environment_id] if rec.secondary_environment_id else None

    # Comparison table
    fit_labels = _fit_labels(len(ranked))
    comp_rows = []
    for i, comp in enumerate(ranked):
        env = env_map[comp.environment_id]
        row: dict = {
            "rank": i + 1,
            "name": env.name,
            "runtime": round(comp.runtime_score, 2),
            "cost": round(comp.cost_score, 2),
            "confidence": round(comp.confidence_score, 2),
            "feasibility": round(comp.feasibility_score, 2),
            "overall": round(min(comp.overall_score, 1.0), 2),
            "fit": fit_labels[i],
        }
        # Attach raw values when available
        if result_map and comp.environment_id in result_map:
            res = result_map[comp.environment_id]
            row["raw_runtime_sec"] = res.measured_runtime_sec
            row["raw_cost_usd"] = res.estimated_cost_usd
            row["raw_fidelity"] = res.output_fidelity
            row["raw_shots"] = sum(res.raw_counts.values()) if res.raw_counts else None
        comp_rows.append(row)

    # Why not runner-up
    primary_comp = ranked[0]
    secondary_comp = ranked[1] if len(ranked) > 1 else None
    why_not = _why_not_runner_up(primary_comp, primary_env, secondary_comp, secondary_env)

    # Trust
    measured = len(expl.observed)
    estimated = len(expl.estimated)
    guessed = len(expl.assumed)
    profile_derived = sum(
        1 for c in comparisons for a in c.assumptions if "Suitability:" in a
    )

    # Plain-language logic
    logic = _plain_language_logic(expl.recommendation_logic)

    return {
        "workload_summary": {
            "name": workload.name,
            "category": workload.category.value,
            "objective": workload.objective,
            "qubit_count_hint": workload.qubit_count_hint,
            "circuit_depth_hint": workload.circuit_depth_hint,
            "shots": workload.shots,
            "priorities": {
                "confidence": workload.priority_confidence,
                "speed": workload.priority_speed,
                "cost": workload.priority_cost,
            },
        },
        "recommendation_summary": {
            "primary": primary_env.name,
            "secondary": secondary_env.name if secondary_env else None,
            "confidence": rec.confidence_level.value,
            "rationale": rec.rationale,
            "why_not_runner_up": why_not,
            "next_step": rec.next_step,
            "confidence_reasons": rec.confidence_reasons,
        },
        "comparisons": comp_rows,
        "trust": {
            "measured": measured,
            "estimated": estimated,
            "guessed": guessed,
            "profile_derived": profile_derived,
            "could_change": [
                a.replace(" (estimated)", "").replace(" (assumed)", "")
                for a in rec.assumptions
                if not a.startswith("Suitability:")
            ],
        },
        "fingerprint": {
            "category": fp.category,
            "noise_sensitivity": fp.noise_sensitivity,
            "depth_sensitivity": fp.depth_sensitivity,
            "fidelity_need": fp.fidelity_need,
            "qubit_pressure": fp.qubit_pressure,
        },
        "appendix": {
            "observed": expl.observed,
            "estimated": expl.estimated,
            "assumed": expl.assumed,
            "logic": logic,
            "unknowns": expl.unknowns,
        },
    }


def _fit_labels(count: int) -> list[str]:
    if count == 1:
        return ["Best fit"]
    labels = ["Best fit", "Contender"]
    labels.extend(["Not recommended"] * max(0, count - 2))
    return labels


def _why_not_runner_up(
    primary_comp: NormalizedComparison,
    primary_env: CandidateEnvironment,
    secondary_comp: NormalizedComparison | None,
    secondary_env: CandidateEnvironment | None,
) -> str:
    if not secondary_comp or not secondary_env:
        return ""
    weaknesses = []
    if secondary_comp.confidence_score < primary_comp.confidence_score - 0.1:
        weaknesses.append("lower result confidence")
    if secondary_comp.cost_score < primary_comp.cost_score - 0.1:
        weaknesses.append("higher cost")
    if secondary_comp.runtime_score < primary_comp.runtime_score - 0.1:
        weaknesses.append("slower runtime")
    if secondary_comp.feasibility_score < primary_comp.feasibility_score - 0.1:
        weaknesses.append("less practical to access")
    if weaknesses:
        return f"{secondary_env.name} fell behind due to {', '.join(weaknesses)}."
    return f"{secondary_env.name} scored close but didn't lead where it mattered most."


def _plain_language_logic(items: list[str]) -> list[str]:
    result = []
    for item in items:
        if item.startswith("Scoring weights:"):
            result.append(item.replace("Scoring weights:", "Your priorities were weighted as:"))
        elif item.startswith("All dimension scores normalized"):
            result.append("Each environment was scored 0\u20131 on every dimension so they could be compared fairly.")
        elif item.startswith("Provenance discounting"):
            result.append(
                "Measured data counted fully. User-provided estimates were discounted 20%. "
                "Guessed values were discounted 50%."
            )
        elif item.startswith("Suitability adjustments"):
            result.append("Scores were adjusted based on how well each environment matches your workload type.")
        elif item.startswith("Overall ="):
            result.append("The final score combines all dimensions, weighted by your stated priorities.")
        elif item.startswith("Workload fingerprint"):
            result.append(item.replace("Workload fingerprint", "Workload profile"))
        else:
            result.append(item)
    return result
