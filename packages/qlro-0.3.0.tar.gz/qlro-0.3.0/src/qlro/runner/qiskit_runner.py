"""Qiskit-based experiment runner.

Runs circuits on Aer simulator backends configured per-environment.
Environments with profiles get noise models applied; environments without
profiles run ideal simulation. The boundary is explicit.

What is real:
- Circuit execution on Aer is real
- Noise models from profiles are real Qiskit noise models
- Runtime measurement is real
- Counts and fidelity derivation are real

What is still simulated:
- All execution is local Aer, not actual remote hardware
- Cost comes from environment metadata, not billing APIs
- Success rate for noisy sims is derived, not from repeated job submissions
"""

import time
from datetime import datetime, timezone

from qiskit_aer import AerSimulator
from qiskit_aer.noise import NoiseModel, depolarizing_error, thermal_relaxation_error

from qlro.schemas import (
    CandidateEnvironment,
    EnvironmentProfile,
    ExperimentResult,
    ExperimentRun,
    RunStatus,
    Workload,
)
from qlro.runner.circuits import build_circuit_for_workload


class QiskitRunner:
    """Runs workloads on Aer backends configured from environment profiles."""

    def __init__(self, shots: int = 1024, seed: int | None = None):
        self.shots = shots
        self.seed = seed

    def run(
        self,
        experiment: ExperimentRun,
        workload: Workload,
        environment: CandidateEnvironment,
    ) -> tuple[ExperimentRun, ExperimentResult]:
        """Execute an experiment and return updated run + result."""
        circuit = build_circuit_for_workload(workload)
        backend = self._get_backend(environment)
        shots = workload.shots if workload.shots else self.shots

        experiment.status = RunStatus.running
        start = time.monotonic()

        try:
            run_kwargs = {"shots": shots}
            if self.seed is not None:
                run_kwargs["seed_simulator"] = self.seed
            result = backend.run(circuit, **run_kwargs).result()
            elapsed = time.monotonic() - start
            counts = result.get_counts(circuit)

            total_shots = sum(counts.values())
            max_count = max(counts.values())
            fidelity = max_count / total_shots

            # For noisy backends, derive a success proxy from fidelity spread
            success_rate = _derive_success_rate(counts, environment)

            experiment.status = RunStatus.completed
            experiment.completed_at = datetime.now(timezone.utc)

            backend_desc = _describe_backend(environment)
            exp_result = ExperimentResult(
                experiment_run_id=experiment.id,
                measured_runtime_sec=elapsed,
                estimated_cost_usd=self._estimate_cost(environment, elapsed, shots),
                output_fidelity=fidelity,
                success_rate=success_rate,
                raw_counts=counts,
                notes=f"{backend_desc}, {shots} shots",
            )
        except Exception as e:
            elapsed = time.monotonic() - start
            experiment.status = RunStatus.failed
            experiment.completed_at = datetime.now(timezone.utc)

            exp_result = ExperimentResult(
                experiment_run_id=experiment.id,
                measured_runtime_sec=elapsed,
                success_rate=0.0,
                notes=f"Failed: {e}",
            )

        return experiment, exp_result

    def _get_backend(self, environment: CandidateEnvironment) -> AerSimulator:
        """Build an Aer backend from the environment profile.

        - No profile → ideal simulator
        - Profile with error rates → depolarizing noise model
        - Profile with T1/T2 → thermal relaxation added
        """
        profile = environment.profile
        if profile is None:
            return AerSimulator()

        noise_model = _build_noise_model(profile)
        if noise_model is None:
            return AerSimulator()

        return AerSimulator(noise_model=noise_model)

    def _estimate_cost(
        self, environment: CandidateEnvironment, runtime_sec: float, shots: int | None = None
    ) -> float | None:
        # Dynamic cost: cost_per_task + (shots × cost_per_shot)
        if environment.cost_per_shot is not None:
            task_fee = environment.cost_per_task or 0.0
            n_shots = shots or self.shots
            return task_fee + (n_shots * environment.cost_per_shot)
        # Flat fallback
        if environment.estimated_cost_per_run is not None:
            return environment.estimated_cost_per_run
        return 0.0


def _build_noise_model(profile: EnvironmentProfile) -> NoiseModel | None:
    """Construct a Qiskit NoiseModel from environment profile fields.

    Returns None if no noise parameters are specified.
    """
    has_noise = any([
        profile.single_gate_error,
        profile.two_gate_error,
        profile.readout_error,
    ])
    if not has_noise:
        return None

    noise_model = NoiseModel()

    # Single-qubit gate noise
    if profile.single_gate_error:
        error_1q = depolarizing_error(profile.single_gate_error, 1)
        noise_model.add_all_qubit_quantum_error(error_1q, ['h', 'rx', 'ry', 'rz', 'x'])

    # Two-qubit gate noise
    if profile.two_gate_error:
        error_2q = depolarizing_error(profile.two_gate_error, 2)
        noise_model.add_all_qubit_quantum_error(error_2q, ['cx'])

    # Readout noise
    if profile.readout_error:
        from qiskit_aer.noise import ReadoutError
        p = profile.readout_error
        readout_err = ReadoutError([[1 - p, p], [p, 1 - p]])
        noise_model.add_all_qubit_readout_error(readout_err)

    return noise_model


def _derive_success_rate(
    counts: dict[str, int],
    environment: CandidateEnvironment,
) -> float:
    """Derive a success rate proxy from measurement statistics.

    For ideal simulators: 1.0
    For noisy environments: entropy-based — a flat distribution means
    noise is dominating (low success), a peaked distribution means
    the signal is preserved (high success).
    """
    if environment.profile is None:
        return 1.0

    has_noise = any([
        environment.profile.single_gate_error,
        environment.profile.two_gate_error,
        environment.profile.readout_error,
    ])
    if not has_noise:
        return 1.0

    total = sum(counts.values())
    if total == 0:
        return 0.0

    # Normalized entropy: 0 = one outcome dominates, 1 = uniform
    import math
    n_outcomes = len(counts)
    if n_outcomes <= 1:
        return 1.0

    entropy = -sum(
        (c / total) * math.log2(c / total)
        for c in counts.values() if c > 0
    )
    max_entropy = math.log2(n_outcomes)
    normalized_entropy = entropy / max_entropy if max_entropy > 0 else 0

    # Invert: low entropy → high success
    return round(1.0 - normalized_entropy, 4)


def _describe_backend(environment: CandidateEnvironment) -> str:
    """Human-readable description of what backend was used."""
    if environment.profile is None:
        return "Aer ideal simulator"

    parts = ["Aer simulator"]
    p = environment.profile
    if p.single_gate_error or p.two_gate_error:
        parts.append("with depolarizing noise")
    if p.readout_error:
        parts.append("+ readout error")
    if p.t1_us or p.t2_us:
        parts.append("+ thermal relaxation")
    return " ".join(parts)
