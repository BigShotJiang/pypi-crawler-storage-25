"""Circuit builders for standard workload types.

When a user provides an OpenQASM circuit string, that circuit is used
directly. Otherwise, a reference circuit is generated from workload
category and hints — these are small, repeatable circuits for validating
the comparison framework, NOT production quantum algorithms.
"""

from qiskit import QuantumCircuit
from qiskit.qasm2 import loads as qasm2_loads

from qlro.schemas import Workload, WorkloadCategory


class CircuitParseError(Exception):
    """Raised when a user-provided QASM string cannot be parsed."""


def build_circuit_for_workload(workload: Workload) -> QuantumCircuit:
    """Build a circuit from user QASM or generate a reference circuit."""
    if workload.qasm_circuit:
        return _parse_user_qasm(workload.qasm_circuit)

    n_qubits = workload.qubit_count_hint or 4

    match workload.category:
        case WorkloadCategory.optimization:
            return _qaoa_like_circuit(n_qubits, workload.circuit_depth_hint or 2)
        case WorkloadCategory.simulation:
            return _trotter_like_circuit(n_qubits, workload.circuit_depth_hint or 3)
        case WorkloadCategory.chemistry:
            return _vqe_like_circuit(n_qubits, workload.circuit_depth_hint or 2)
        case _:
            return _generic_circuit(n_qubits, workload.circuit_depth_hint or 2)


def _qaoa_like_circuit(n_qubits: int, depth: int) -> QuantumCircuit:
    """QAOA-style circuit: alternating problem/mixer layers."""
    qc = QuantumCircuit(n_qubits)
    # Initial superposition
    for i in range(n_qubits):
        qc.h(i)
    # QAOA layers
    for _ in range(depth):
        # Problem layer: ZZ interactions on adjacent qubits
        for i in range(n_qubits - 1):
            qc.cx(i, i + 1)
            qc.rz(0.5, i + 1)
            qc.cx(i, i + 1)
        # Mixer layer: X rotations
        for i in range(n_qubits):
            qc.rx(0.7, i)
    qc.measure_all()
    return qc


def _trotter_like_circuit(n_qubits: int, depth: int) -> QuantumCircuit:
    """Trotterized evolution-style circuit."""
    qc = QuantumCircuit(n_qubits)
    # Initial state
    qc.x(0)
    for _ in range(depth):
        for i in range(n_qubits - 1):
            qc.cx(i, i + 1)
            qc.rz(0.3, i + 1)
            qc.cx(i, i + 1)
        for i in range(n_qubits):
            qc.rx(0.2, i)
    qc.measure_all()
    return qc


def _vqe_like_circuit(n_qubits: int, depth: int) -> QuantumCircuit:
    """VQE-style ansatz circuit."""
    qc = QuantumCircuit(n_qubits)
    for _ in range(depth):
        for i in range(n_qubits):
            qc.ry(0.5, i)
        for i in range(n_qubits - 1):
            qc.cx(i, i + 1)
    qc.measure_all()
    return qc


def _generic_circuit(n_qubits: int, depth: int) -> QuantumCircuit:
    """Generic reference circuit."""
    qc = QuantumCircuit(n_qubits)
    for i in range(n_qubits):
        qc.h(i)
    for _ in range(depth):
        for i in range(0, n_qubits - 1, 2):
            qc.cx(i, i + 1)
        for i in range(n_qubits):
            qc.rz(0.4, i)
    qc.measure_all()
    return qc


def _parse_user_qasm(qasm_str: str) -> QuantumCircuit:
    """Parse a user-provided OpenQASM 2.0 string into a QuantumCircuit.

    Adds measurement gates if the circuit has none.
    """
    try:
        qc = qasm2_loads(qasm_str)
    except Exception as e:
        raise CircuitParseError(f"Could not parse QASM: {e}") from e

    # Ensure the circuit has measurements
    if qc.num_clbits == 0:
        qc.measure_all()

    return qc
