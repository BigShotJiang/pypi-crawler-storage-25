"""Recommendation engine module."""

from qlro.recommendation.engine import recommend

__all__ = ["recommend"]
