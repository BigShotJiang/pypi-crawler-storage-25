"""Recommendation engine — transparent, rule-based.

Takes normalized comparison results and produces a recommendation with:
- primary and secondary environment picks
- tradeoff analysis between top candidates
- provenance-aware confidence assessment
- structured explanation (observed / estimated / assumed / logic)
- suggested next step

All logic is explicit and auditable. No hidden LLM prompts.
"""

from qlro.schemas import (
    CandidateEnvironment,
    ConfidenceLevel,
    ExplanationSection,
    NormalizedComparison,
    Recommendation,
    Tradeoff,
    Workload,
    compute_fingerprint,
)


DIMENSION_LABELS = {
    "runtime_score": "Runtime",
    "cost_score": "Cost",
    "confidence_score": "Output confidence",
    "feasibility_score": "Feasibility",
}


def recommend(
    workload: Workload,
    comparisons: list[NormalizedComparison],
    environments: dict,  # UUID -> CandidateEnvironment
) -> Recommendation:
    """Generate a recommendation from normalized comparison results.

    Rules:
    1. Rank by overall_score (higher is better).
    2. Primary = highest score. Secondary = second highest.
    3. Identify per-dimension tradeoffs between top 2.
    4. Confidence is based on score gap, data completeness, and provenance.
    5. Explanation separates observed/estimated/assumed/logic.
    """
    if not comparisons:
        raise ValueError("Cannot recommend with no comparison data")

    ranked = sorted(comparisons, key=lambda c: c.overall_score, reverse=True)

    primary = ranked[0]
    secondary = ranked[1] if len(ranked) > 1 else None

    primary_env = environments[primary.environment_id]
    secondary_env = environments[secondary.environment_id] if secondary else None

    # Analyze tradeoffs
    tradeoffs = _analyze_tradeoffs(primary, primary_env, secondary, secondary_env)

    # Assess confidence with reasons
    confidence, confidence_reasons = _assess_confidence(primary, secondary, ranked)

    # Build structured explanation
    explanation = _build_explanation(
        workload, primary, primary_env, secondary, secondary_env, ranked
    )

    # Build rationale (human-readable summary)
    rationale = _build_rationale(
        workload, primary, primary_env, secondary_env, tradeoffs
    )

    # Collect all assumptions
    all_assumptions = list(primary.assumptions)
    if secondary:
        for a in secondary.assumptions:
            if a not in all_assumptions:
                all_assumptions.append(a)

    next_step = _suggest_next_step(
        primary_env, secondary_env, confidence, confidence_reasons, all_assumptions,
    )

    return Recommendation(
        workload_id=workload.id,
        primary_environment_id=primary.environment_id,
        secondary_environment_id=secondary.environment_id if secondary else None,
        rationale=rationale,
        confidence_level=confidence,
        confidence_reasons=confidence_reasons,
        tradeoffs=tradeoffs,
        explanation=explanation,
        assumptions=all_assumptions,
        next_step=next_step,
    )


# --- Tradeoff analysis ---

def _analyze_tradeoffs(
    primary: NormalizedComparison,
    primary_env: CandidateEnvironment,
    secondary: NormalizedComparison | None,
    secondary_env: CandidateEnvironment | None,
) -> list[Tradeoff]:
    """Compare primary vs secondary on each dimension."""
    if secondary is None or secondary_env is None:
        return []

    tradeoffs = []
    dimensions = [
        ("runtime_score", "Runtime"),
        ("cost_score", "Cost"),
        ("confidence_score", "Output confidence"),
        ("feasibility_score", "Feasibility"),
    ]

    for attr, label in dimensions:
        p_val = getattr(primary, attr)
        s_val = getattr(secondary, attr)
        gap = p_val - s_val

        if abs(gap) < 0.05:
            continue  # Too close to call — not a meaningful tradeoff

        if gap > 0:
            favors = primary_env.name
        else:
            favors = secondary_env.name

        tradeoffs.append(Tradeoff(
            dimension=label,
            favors=favors,
            description=(
                f"{favors} scores better on {label.lower()} "
                f"({max(p_val, s_val):.2f} vs {min(p_val, s_val):.2f})"
            ),
        ))

    return tradeoffs


# --- Confidence assessment ---

def _assess_confidence(
    primary: NormalizedComparison,
    secondary: NormalizedComparison | None,
    ranked: list[NormalizedComparison],
) -> tuple[ConfidenceLevel, list[str]]:
    """Assess recommendation confidence with explicit reasons.

    Factors:
    - Score gap between primary and secondary
    - Number of assumptions (missing/estimated data)
    - Number of environments compared
    - Whether assumptions involve the primary's strengths
    """
    reasons = []

    # Count provenance quality
    estimated_count = sum(
        1 for a in primary.assumptions if "(estimated)" in a
    )
    assumed_count = sum(
        1 for a in primary.assumptions if "(assumed)" in a
    )

    if secondary is None:
        reasons.append("Only one environment was compared")
        if assumed_count > 0:
            reasons.append(f"Primary has {assumed_count} assumed data points")
            return ConfidenceLevel.low, reasons
        if estimated_count > 0:
            reasons.append(f"Primary has {estimated_count} estimated data points")
            return ConfidenceLevel.medium, reasons
        reasons.append("All data for the primary was observed")
        return ConfidenceLevel.medium, reasons  # Single option = medium at best

    score_gap = primary.overall_score - secondary.overall_score
    total_assumptions = len(primary.assumptions) + len(secondary.assumptions)
    total_assumed = assumed_count + sum(
        1 for a in secondary.assumptions if "(assumed)" in a
    )
    total_estimated = estimated_count + sum(
        1 for a in secondary.assumptions if "(estimated)" in a
    )

    # Score gap assessment
    if score_gap > 0.15:
        reasons.append(f"Clear score gap ({score_gap:.2f}) between top two")
    elif score_gap > 0.05:
        reasons.append(f"Moderate score gap ({score_gap:.2f}) between top two")
    else:
        reasons.append(f"Very small score gap ({score_gap:.2f}) — near tie")

    # Data quality assessment
    if total_assumed > 0:
        reasons.append(f"{total_assumed} data points were system-assumed (missing data)")
    if total_estimated > 0:
        reasons.append(f"{total_estimated} data points are estimates, not measurements")
    if total_assumptions == 0:
        reasons.append("All data was directly observed")

    # Environment count
    if len(ranked) >= 3:
        reasons.append(f"{len(ranked)} environments compared")
    elif len(ranked) == 2:
        reasons.append("Only 2 environments compared")

    # Determine level
    if score_gap > 0.15 and total_assumed == 0 and total_estimated <= 1:
        return ConfidenceLevel.high, reasons
    elif score_gap > 0.05 and total_assumed <= 1 and total_assumptions <= 4:
        return ConfidenceLevel.medium, reasons
    else:
        return ConfidenceLevel.low, reasons


# --- Explanation layer ---

def _build_explanation(
    workload: Workload,
    primary: NormalizedComparison,
    primary_env: CandidateEnvironment,
    secondary: NormalizedComparison | None,
    secondary_env: CandidateEnvironment | None,
    ranked: list[NormalizedComparison],
) -> ExplanationSection:
    """Build structured explanation separating data types."""
    observed = []
    estimated = []
    assumed = []
    logic = []
    unknowns = []

    # Categorize assumptions from comparisons (deduplicated)
    seen = set()
    for comp in ranked:
        for a in comp.assumptions:
            if a in seen:
                continue
            seen.add(a)
            if "(observed)" in a:
                observed.append(a)
            elif "(estimated)" in a:
                estimated.append(a)
            elif "(assumed)" in a:
                assumed.append(a)

    # Add observed facts
    observed.append(
        f"{primary_env.name} scored highest overall: {min(primary.overall_score, 1.0):.2f}"
    )
    if secondary and secondary_env:
        observed.append(
            f"{secondary_env.name} scored second: {min(secondary.overall_score, 1.0):.2f}"
        )

    # Workload fingerprint context
    fp = compute_fingerprint(workload)
    logic.append(
        f"Workload fingerprint ({fp.category}): "
        f"noise_sensitivity={fp.noise_sensitivity}, "
        f"depth_sensitivity={fp.depth_sensitivity}, "
        f"fidelity_need={fp.fidelity_need}, "
        f"qubit_pressure={fp.qubit_pressure}"
    )

    # Explain scoring logic
    logic.append(
        f"Scoring weights: speed={workload.priority_speed:.0%}, "
        f"cost={workload.priority_cost:.0%}, "
        f"confidence={workload.priority_confidence:.0%}, "
        f"feasibility=10% (fixed)"
    )
    logic.append("All dimension scores normalized 0-1 (higher = better) via min-max within this comparison set")
    logic.append("Provenance discounting applied: observed=1.0x, estimated=0.8x, assumed=0.5x")
    logic.append("Suitability adjustments applied based on workload fingerprint × environment characteristics")
    logic.append("Overall = speed_weight * runtime_score + cost_weight * cost_score + confidence_weight * confidence_score + 0.1 * feasibility_score + suitability_adjustment")

    # Per-dimension breakdown for primary
    logic.append(
        f"{primary_env.name} dimension scores: "
        f"runtime={primary.runtime_score:.2f}, "
        f"cost={primary.cost_score:.2f}, "
        f"confidence={primary.confidence_score:.2f}, "
        f"feasibility={primary.feasibility_score:.2f}"
    )

    # Surface suitability adjustments
    suitability_notes = [a for a in primary.assumptions if a.startswith("Suitability:")]
    for note in suitability_notes:
        logic.append(note)

    # Identify unknowns
    if any("(assumed)" in a for a in primary.assumptions):
        unknowns.append(
            f"Some data for {primary_env.name} was missing and defaulted — "
            f"recommendation may change with real measurements"
        )
    if secondary and any("(assumed)" in a for a in secondary.assumptions):
        unknowns.append(
            f"Some data for {secondary_env.name} was missing and defaulted"
        )

    # Structural unknowns
    if len(ranked) < 3:
        unknowns.append("Fewer than 3 environments compared — recommendation is based on a narrow field")

    return ExplanationSection(
        observed=observed,
        estimated=estimated,
        assumed=assumed,
        recommendation_logic=logic,
        unknowns=unknowns,
    )


# --- Rationale ---

def _build_rationale(
    workload: Workload,
    primary: NormalizedComparison,
    primary_env: CandidateEnvironment,
    secondary_env: CandidateEnvironment | None,
    tradeoffs: list[Tradeoff],
) -> str:
    """Build a buyer-readable rationale. Used directly as the 'Why X' paragraph."""
    # What the winner does well
    strengths = []
    if primary.confidence_score >= 0.7:
        strengths.append("produced the most reliable results")
    if primary.cost_score >= 0.7:
        strengths.append("costs less to run")
    if primary.runtime_score >= 0.7:
        strengths.append("runs faster")
    if primary.feasibility_score >= 0.7:
        strengths.append("is the most practical to access")

    if not strengths:
        strengths.append("scored well across multiple dimensions without a major weakness")

    # What the user cares about most
    top_priority = max(
        [("speed", workload.priority_speed),
         ("cost", workload.priority_cost),
         ("result confidence", workload.priority_confidence)],
        key=lambda x: x[1],
    )

    parts = [
        f"{primary_env.name} {', '.join(strengths)}.",
        f"Given that your top priority is {top_priority[0]}"
        f" ({top_priority[1]:.0%} weight), this environment is the strongest fit"
        f" for validating this workload first.",
    ]

    # Note what the runner-up does better, if anything
    secondary_wins = [t for t in tradeoffs if secondary_env and t.favors == secondary_env.name]
    if secondary_wins:
        dims = ", ".join(t.dimension.lower() for t in secondary_wins)
        parts.append(f"Tradeoff: {secondary_env.name} is better on {dims}.")

    return " ".join(parts)


# --- Next step ---

def _suggest_next_step(
    primary_env: CandidateEnvironment,
    secondary_env: CandidateEnvironment | None,
    confidence: ConfidenceLevel,
    confidence_reasons: list[str],
    assumptions: list[str],
) -> str:
    # Identify what's limiting confidence
    has_assumed = any("assumed" in a.lower() for a in assumptions)
    has_estimated = any("estimated" in a.lower() for a in assumptions)
    few_envs = any("only" in r.lower() and "compared" in r.lower() for r in confidence_reasons)
    near_tie = any("small" in r.lower() or "tie" in r.lower() for r in confidence_reasons)

    if confidence == ConfidenceLevel.low:
        blockers = []
        if near_tie and secondary_env:
            blockers.append(
                f"the gap between {primary_env.name} and {secondary_env.name} is too small to call"
            )
        if has_assumed:
            blockers.append("some data was missing and had to be defaulted")
        if few_envs:
            blockers.append("fewer than 3 environments were compared")
        reason = "; ".join(blockers) if blockers else "data quality is limited"
        return (
            f"Confidence is low because {reason}. "
            f"Run additional experiments on {primary_env.name}"
            + (f" and {secondary_env.name}" if secondary_env else "")
            + " to increase confidence before committing."
        )
    elif confidence == ConfidenceLevel.medium:
        gaps = []
        if has_estimated:
            gaps.append("some cost or queue data is estimated rather than measured")
        if few_envs:
            gaps.append("only a narrow set of environments was compared")
        if gaps:
            qualifier = f" The main gap: {gaps[0]}."
        else:
            qualifier = ""
        return (
            f"Proceed with a small-scale validation run on {primary_env.name}."
            + qualifier
            + (f" Consider a parallel test on {secondary_env.name} to confirm the ranking."
               if secondary_env else "")
        )
    else:
        return (
            f"Proceed with validation on {primary_env.name}. "
            f"The recommendation has high confidence based on observed data across "
            f"{len(confidence_reasons)} quality checks."
        )
