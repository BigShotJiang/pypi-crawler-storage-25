"""IPython / Jupyter extension for Qlro.

Load with:

    %load_ext qlro.jupyter

Then use either of these:

    # Line magic — name a circuit variable, get a recommendation:
    %qlro my_circuit chemistry

    # With priorities:
    %qlro my_circuit optimization --priorities confidence:0.7,cost:0.2,speed:0.1

    # With device filter:
    %qlro my_circuit chemistry --devices ibm_boston,ibm_torino,H2-2

For power use, just call `qlro.recommend(circuit, category)` directly — it
auto-renders as HTML in Jupyter via the Recommendation._repr_html_ method.
This magic is a shortcut for quick interactive exploration.
"""

from __future__ import annotations

import shlex
from typing import TYPE_CHECKING

from qlro.public_api import Recommendation, recommend

if TYPE_CHECKING:
    from IPython.core.interactiveshell import InteractiveShell


def _parse_priorities(spec: str) -> dict[str, float]:
    """Parse a 'confidence:0.6,cost:0.25,speed:0.15' string."""
    out: dict[str, float] = {}
    for pair in spec.split(","):
        if ":" not in pair:
            continue
        key, value = pair.split(":", 1)
        try:
            out[key.strip()] = float(value.strip())
        except ValueError:
            continue
    return out


def _parse_devices(spec: str) -> list[str]:
    return [d.strip() for d in spec.split(",") if d.strip()]


def _qlro_line_magic(line: str) -> Recommendation | None:
    """The %qlro line magic.

    Usage: %qlro <circuit_var> <category> [--priorities k:v,k:v] [--devices a,b,c]
    """
    from IPython import get_ipython

    ipython = get_ipython()
    if ipython is None:
        print("%qlro can only be used inside an IPython kernel.")
        return None

    tokens = shlex.split(line)
    if len(tokens) < 2:
        print(
            "usage: %qlro <circuit_var> <category> "
            "[--priorities k:v,k:v] [--devices a,b,c] [--shots N]"
        )
        return None

    circuit_var = tokens[0]
    category = tokens[1]

    # Parse optional flags
    priorities: dict[str, float] | None = None
    devices: list[str] | None = None
    shots: int = 1024

    i = 2
    while i < len(tokens):
        tok = tokens[i]
        if tok == "--priorities" and i + 1 < len(tokens):
            priorities = _parse_priorities(tokens[i + 1])
            i += 2
        elif tok == "--devices" and i + 1 < len(tokens):
            devices = _parse_devices(tokens[i + 1])
            i += 2
        elif tok == "--shots" and i + 1 < len(tokens):
            try:
                shots = int(tokens[i + 1])
            except ValueError:
                pass
            i += 2
        else:
            i += 1

    ns = ipython.user_ns
    if circuit_var not in ns:
        print(f"variable {circuit_var!r} not found in notebook namespace")
        return None

    circuit = ns[circuit_var]
    result = recommend(
        circuit=circuit,
        category=category,
        priorities=priorities,
        shots=shots,
        devices=devices,
    )
    return result  # IPython auto-displays the return value via _repr_html_


def load_ipython_extension(ipython: "InteractiveShell") -> None:
    """Register the %qlro line magic. Called by `%load_ext qlro.jupyter`."""
    ipython.register_magic_function(_qlro_line_magic, magic_kind="line", magic_name="qlro")
    print("qlro: loaded. Usage: %qlro <circuit_var> <category>")


def unload_ipython_extension(ipython: "InteractiveShell") -> None:
    """Unregister the magic when `%unload_ext qlro.jupyter` is called."""
    # IPython handles this via its internal magics_manager; nothing to do.
    pass
