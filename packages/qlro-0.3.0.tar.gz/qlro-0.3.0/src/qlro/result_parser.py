"""Result parsers for semi-structured import (alpha v2).

Accepts pasted text from quantum job outputs and extracts structured
fields. Two formats supported:

1. Qiskit Result JSON — the standard output of job.result().to_dict()
2. Key-value plaintext — simple "field: value" lines as a fallback

The parser auto-detects the format and returns an ActualResult with
extracted fields, plus any top-level metrics (fidelity, cost, runtime,
shots) that can be inferred.
"""

import json
import re
from dataclasses import dataclass

from qlro.schemas.evaluation import ActualResult


@dataclass
class ParsedOutcome:
    """Extracted fields from pasted result text."""

    actual_result: ActualResult
    actual_fidelity: float | None = None
    actual_runtime_sec: float | None = None
    actual_cost_usd: float | None = None
    actual_shots: int | None = None
    environment_chosen: str | None = None  # if we can infer it from backend name


class ParseError(Exception):
    """Raised when the input cannot be parsed in any supported format."""
    pass


def detect_format(text: str) -> str:
    """Auto-detect the format of pasted text.

    Returns: "qiskit_result" | "key_value" | "unknown"
    """
    stripped = text.strip()

    # Try JSON first
    if stripped.startswith("{"):
        try:
            data = json.loads(stripped)
            # Qiskit result has "results" key with list of experiment results
            if isinstance(data, dict) and "results" in data:
                return "qiskit_result"
            # Could be a generic JSON — treat as key-value extraction
            return "key_value"
        except json.JSONDecodeError:
            pass

    # Check for key: value lines
    kv_pattern = re.compile(r"^\s*\w[\w\s]*:\s*.+", re.MULTILINE)
    if kv_pattern.search(stripped):
        return "key_value"

    return "unknown"


def parse_qiskit_result(text: str) -> ParsedOutcome:
    """Parse a Qiskit Result JSON blob.

    Expected structure (from job.result().to_dict()):
    {
        "backend_name": "aer_simulator",
        "backend_version": "0.14.1",
        "results": [{
            "shots": 4096,
            "success": true,
            "data": {"counts": {"0x0": 2010, "0x3": 2086}},
            "header": {"name": "circuit-0"}
        }],
        "time_taken": 0.42
    }
    """
    try:
        data = json.loads(text.strip())
    except json.JSONDecodeError as e:
        raise ParseError(f"Invalid JSON: {e}")

    if not isinstance(data, dict) or "results" not in data:
        raise ParseError("Not a Qiskit result — missing 'results' key")

    results = data["results"]
    if not results or not isinstance(results, list):
        raise ParseError("No experiment results found")

    # Use the first result (most common case: single circuit)
    first = results[0]

    # Extract counts — Qiskit uses hex keys like "0x0", "0x3"
    counts = None
    raw_counts = first.get("data", {}).get("counts", {})
    if raw_counts:
        # Convert hex keys to binary strings for readability
        counts = {}
        for key, val in raw_counts.items():
            if key.startswith("0x"):
                # Convert hex to binary, strip "0b" prefix
                n_bits = max(len(bin(int(k, 16))[2:]) for k in raw_counts if k.startswith("0x"))
                bin_key = bin(int(key, 16))[2:].zfill(n_bits)
                counts[bin_key] = val
            else:
                counts[key] = val

    # Extract shots
    shots = first.get("shots")

    # Extract success probability from counts
    success_probability = None
    if counts and shots:
        # Heuristic: the most frequent outcome is "success"
        max_count = max(counts.values())
        success_probability = round(max_count / shots, 4)

    # Extract timing
    runtime = data.get("time_taken")
    if runtime is not None:
        runtime = round(float(runtime), 4)

    # Backend info
    backend_name = data.get("backend_name")
    backend_version = data.get("backend_version")

    # Success flag
    success = first.get("success", True)
    error_rate = None
    if not success:
        error_rate = 1.0
    elif success_probability is not None:
        error_rate = round(1.0 - success_probability, 4)

    actual_result = ActualResult(
        counts=counts,
        success_probability=success_probability,
        error_rate=error_rate,
        backend_name=backend_name,
        backend_version=backend_version,
        import_format="qiskit_result",
        raw_input=text.strip()[:2000],  # cap stored raw input
    )

    return ParsedOutcome(
        actual_result=actual_result,
        actual_fidelity=success_probability,
        actual_runtime_sec=runtime,
        actual_shots=shots,
        environment_chosen=backend_name,
    )


def parse_key_value(text: str) -> ParsedOutcome:
    """Parse key: value lines.

    Supported keys (case-insensitive):
        fidelity, cost, runtime, shots, backend, error_rate,
        success_probability, counts
    """
    lines = text.strip().splitlines()
    fields: dict[str, str] = {}

    for line in lines:
        match = re.match(r"^\s*([\w_\s]+?)\s*:\s*(.+?)\s*$", line)
        if match:
            key = match.group(1).strip().lower().replace(" ", "_")
            fields[key] = match.group(2)

    if not fields:
        raise ParseError("No key: value pairs found")

    def to_float(key: str) -> float | None:
        v = fields.get(key)
        if v is None:
            return None
        try:
            return float(v.replace("$", "").replace(",", ""))
        except ValueError:
            return None

    def to_int(key: str) -> int | None:
        v = fields.get(key)
        if v is None:
            return None
        try:
            return int(v.replace(",", ""))
        except ValueError:
            return None

    fidelity = to_float("fidelity")
    cost = to_float("cost")
    runtime = to_float("runtime")
    shots = to_int("shots")
    backend = fields.get("backend")
    success_prob = to_float("success_probability")
    error_rate = to_float("error_rate")

    # Parse counts if provided as JSON-like string
    counts = None
    counts_str = fields.get("counts")
    if counts_str:
        try:
            counts = json.loads(counts_str)
        except json.JSONDecodeError:
            pass

    actual_result = ActualResult(
        counts=counts,
        success_probability=success_prob or fidelity,
        error_rate=error_rate,
        backend_name=backend,
        import_format="key_value",
        raw_input=text.strip()[:2000],
    )

    return ParsedOutcome(
        actual_result=actual_result,
        actual_fidelity=fidelity,
        actual_runtime_sec=runtime,
        actual_cost_usd=cost,
        actual_shots=shots,
        environment_chosen=backend,
    )


def parse_result(text: str) -> ParsedOutcome:
    """Auto-detect format and parse pasted result text.

    Raises ParseError if the text cannot be parsed.
    """
    fmt = detect_format(text)

    if fmt == "qiskit_result":
        return parse_qiskit_result(text)
    elif fmt == "key_value":
        return parse_key_value(text)
    else:
        raise ParseError(
            "Could not detect format. Paste a Qiskit result JSON "
            "or use key: value lines (e.g. 'fidelity: 0.85')"
        )
