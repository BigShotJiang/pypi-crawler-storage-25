use floe_core::{validate, ValidateOptions};

use super::super::common::write_temp_config;

#[test]
fn gcs_definition_requires_bucket() {
    let yaml = r#"
version: "0.1"
storages:
  default: gcs_raw
  definitions:
    - name: gcs_raw
      type: gcs
entities:
  - name: "customer"
    source:
      format: "csv"
      path: "in/customers.csv"
    sink:
      accepted:
        format: "parquet"
        path: "out/customers"
    policy:
      severity: "warn"
    schema:
      columns:
        - name: "id"
          type: "string"
          nullable: false
"#;
    let path = write_temp_config(yaml);
    let err = validate(&path, ValidateOptions::default()).expect_err("should fail");
    let message = err.to_string();
    assert!(message.contains("requires bucket for type gcs"));
}

#[test]
fn gcs_storage_reference_is_supported() {
    let yaml = r#"
version: "0.1"
storages:
  default: gcs_raw
  definitions:
    - name: gcs_raw
      type: gcs
      bucket: my-bucket
entities:
  - name: "customer"
    source:
      format: "csv"
      path: "in/customers.csv"
      storage: gcs_raw
    sink:
      accepted:
        format: "parquet"
        path: "out/customers"
    policy:
      severity: "warn"
    schema:
      columns:
        - name: "id"
          type: "string"
          nullable: false
"#;
    let path = write_temp_config(yaml);
    validate(&path, ValidateOptions::default()).expect("should validate");
}
