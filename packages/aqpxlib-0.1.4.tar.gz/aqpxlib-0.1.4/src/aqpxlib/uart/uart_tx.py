# Copyright 2025 Acute Technology Inc. All rights reserved.
# SPDX-License-Identifier: BSD-3-Clause
"""UART TX Target Class."""

from typing import TYPE_CHECKING, ClassVar

import aqpxlib.message as pxmsg
from aqpxlib.abstract import PxAbstractController

if TYPE_CHECKING:
    from aqpxlib.toplevel import AqProtocolExerciser

from ._uart_message import PxUartConfig, PxUartParityMode


class PxUartTx(PxAbstractController):
    """Uart Tx Class."""

    # Used to identify the class
    identifier: str = "uart_tx"
    protobuf_key: str = "uart_tx"
    valid_buses: ClassVar[list[str]] = ["uart"]

    def __init__(
        self,
        exerciser: "AqProtocolExerciser",
        baud_rate: int = 9600,
        stop_bits: int = 1,
        data_bits: int = 8,
        parity: PxUartParityMode = PxUartParityMode.PARITY_MODE_NONE,
        config: PxUartConfig | None = None,
        *args,
        **kwargs,
    ) -> None:
        """Initialize UART Tx."""
        if config is None:
            config = PxUartConfig(
                baud_rate=baud_rate,
                stop_bits=stop_bits,
                data_bits=data_bits,
                parity=parity,
                enabled=1,
            )

        super().__init__(exerciser, config=config, *args, **kwargs)

    def write_data(self, data: list[int], parity_error: bool = False) -> list[int]:
        """Write a list of data to the bus."""
        return self.perform_operation(
            pxmsg.PxDeviceOperation(uart_tx_write_data=pxmsg.UartWriteData(data=data, with_parity_error=parity_error)),
        )

    def write_bytes(self, data: bytes, parity_error: bool = False) -> list[int]:
        """Write a list of data in bytes to the bus."""
        return self.write_data([int(x) for x in data], parity_error=parity_error)


__all__ = [
    "PxUartTx",
]
