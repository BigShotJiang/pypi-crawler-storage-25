# Copyright 2025 Acute Technology Inc. All rights reserved.
# SPDX-License-Identifier: BSD-3-Clause
"""Definition of exceptions for aqpxlib."""


class PxError(Exception):
    """Base exception for aqpxlib."""


class PxAPIError(PxError):
    """Exception for API errors."""

    def __init__(self, error_code: int) -> None:
        """Exception with error code from Exerciser."""
        super().__init__(error_code)
        self.error_code = error_code

    def __str__(self) -> str:
        """Return string representation of a PxAPI error."""
        return f"PxAPI error: {self.error_code}"


class BackendError(PxError):
    """Generic error from ZeroMQ backend."""
