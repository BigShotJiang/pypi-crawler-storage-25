# Copyright 2025 Acute Technology Inc. All rights reserved.
# SPDX-License-Identifier: BSD-3-Clause
"""Acute Protocol Exerciser I2C Module."""

from aqpxlib.i2c.i2c_32bit_register_target import (
    PxI2C32BitRegisterTarget,
    PxI2C32BitRegisterTargetConfig,
    PxI2C32BitRegisterTargetState,
)
from aqpxlib.i2c.i2c_base_controller import (
    PxI2CController,
    PxI2CControllerConfig,
    PxI2CControllerState,
)
from aqpxlib.i2c.i2c_bus import PxI2CBus

__all__ = [
    "PxI2C32BitRegisterTarget",
    "PxI2C32BitRegisterTargetConfig",
    "PxI2C32BitRegisterTargetState",
    "PxI2CBus",
    "PxI2CController",
    "PxI2CControllerConfig",
    "PxI2CControllerState",
]
