# Copyright 2025 Acute Technology Inc. All rights reserved.
# SPDX-License-Identifier: BSD-3-Clause
"""SPI 32-bit Register Target Class."""

from typing import TYPE_CHECKING, ClassVar

from aqpxlib.abstract import PxAbstractTarget
from aqpxlib.message import Spi32BitRegisterTargetConfig as PxSPI32BitRegisterTargetConfig
from aqpxlib.message import Spi32BitRegisterTargetState as PxSPI32BitRegisterTargetState

if TYPE_CHECKING:
    from aqpxlib.toplevel import AqProtocolExerciser


class PxSPI32BitRegisterTarget(PxAbstractTarget):
    """SPI Base Target Class."""

    # Used to identify the class
    identifier: str = "spi_32bit_register_target"
    protobuf_key: str = "spi_32_bit_reg_target"
    valid_buses: ClassVar[list[str]] = ["spi"]

    def __init__(
        self,
        exerciser: "AqProtocolExerciser",
        config: PxSPI32BitRegisterTargetConfig | None = None,
        *args,
        **kwargs,
    ) -> None:
        """Initialize an SPI 32-bit regiseter target."""
        if config is None:
            config = PxSPI32BitRegisterTargetConfig(
                # may append in the future
            )

        super().__init__(exerciser, config=config, *args, **kwargs)


__all__ = [
    "PxSPI32BitRegisterTarget",
    "PxSPI32BitRegisterTargetConfig",
    "PxSPI32BitRegisterTargetState",
]
