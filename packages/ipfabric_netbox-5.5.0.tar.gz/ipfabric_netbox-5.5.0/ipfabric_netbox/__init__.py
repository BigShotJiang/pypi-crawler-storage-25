from django.db.models.signals import post_delete
from netbox.plugins import PluginConfig


class NetboxIPFabricConfig(PluginConfig):
    name = "ipfabric_netbox"
    verbose_name = "NetBox IP Fabric SoT Plugin"
    description = "Sync IP Fabric into NetBox"
    version = "5.5.0"
    base_url = "ipfabric"
    min_version = "4.5.0"
    default_settings = {
        # Maps IPFabricSync PK (int) to {"secret": "<hmac-secret>", "username": "<netbox-username>"}
        # Example:
        #   "webhook_secrets": {
        #       7:  {"secret": "change-me", "username": "ipfabric-bot"},
        #       12: {"secret": "other-secret", "username": "ipfabric-bot"},
        #   }
        "webhook_secrets": {},
    }

    def ready(self):
        super().ready()

        from ipfabric_netbox.signals import remove_group_from_syncs

        post_delete.connect(
            remove_group_from_syncs,
            sender="ipfabric_netbox.IPFabricTransformMapGroup",
            dispatch_uid="remove_group_from_syncs",
        )


config = NetboxIPFabricConfig
