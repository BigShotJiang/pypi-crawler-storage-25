"""
Integration tests for IPFabricSync.sync and merge operations.

These tests mock IPFabric API endpoints and branching, run sync, and verify
synced data in NetBox database. Uses TestCase with setUpTestData for fast execution.
"""
import json
import logging
from collections import Counter
from concurrent.futures import Future as _CFFuture
from pathlib import Path
from unittest.mock import MagicMock
from unittest.mock import patch

from dcim.models import Device
from dcim.models import DeviceRole
from dcim.models import DeviceType
from dcim.models import Interface
from dcim.models import InventoryItem
from dcim.models import MACAddress
from dcim.models import Manufacturer
from dcim.models import Platform
from dcim.models import Site
from dcim.models import VirtualChassis
from django.contrib.auth import get_user_model
from django.contrib.contenttypes.models import ContentType
from django.db import connections as _django_connections
from django.db import DEFAULT_DB_ALIAS
from django.test import tag
from django.test import TestCase
from django.utils import timezone
from django.utils.text import slugify
from ipam.models import IPAddress
from ipam.models import Prefix
from ipam.models import VLAN
from ipam.models import VRF
from netbox_branching.choices import BranchStatusChoices
from netbox_branching.models import Branch
from netbox_branching.models.changes import ObjectChange as BranchObjectChange

from ipfabric_netbox.choices import IPFabricIngestionPhaseChoices
from ipfabric_netbox.choices import IPFabricSnapshotStatusModelChoices
from ipfabric_netbox.choices import IPFabricSyncStatusChoices
from ipfabric_netbox.models import IPFabricSnapshot
from ipfabric_netbox.models import IPFabricSource
from ipfabric_netbox.models import IPFabricSync
from ipfabric_netbox.utilities.ipfutils import IPFabricSyncRunner
from ipfabric_netbox.utilities.logging import SyncLogging

User = get_user_model()

# Configure logging to show sync logger output in tests
logging.basicConfig(
    level=logging.DEBUG, format="%(levelname)s %(asctime)s %(name)s %(message)s"
)
# Enable the specific loggers used by the sync process
logging.getLogger("ipfabric.sync").setLevel(logging.DEBUG)
logging.getLogger("ipfabric_netbox.models").setLevel(logging.DEBUG)


class _InlineExecutor:
    """
    Drop-in for ThreadPoolExecutor that runs all submitted callables
    synchronously in the CALLER'S thread.

    Avoids Django TestCase transaction-isolation failures: worker-thread
    DB connections cannot see the uncommitted test transaction, but the
    main thread's connection can.  This lets the spy closures record
    dispatch calls while keeping all DB writes inside the test transaction.
    """

    def __init__(self, max_workers=None, **kwargs):
        pass

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        pass

    def submit(self, fn, *args, **kwargs):
        fut = _CFFuture()
        try:
            fut.set_result(fn(*args, **kwargs))
        except Exception as exc:  # noqa: BLE001
            fut.set_exception(exc)
        return fut

    def map(self, fn, *iterables, timeout=None, chunksize=1):
        return [fn(*args) for args in zip(*iterables)]


class _IPFabricSyncMixin:
    """
    Non-TestCase mixin that holds shared mock helpers, fixture loaders and the
    ``_do_sync_setup`` classmethod used by both sync test classes.

    Both ``IPFabricSyncIntegrationTests`` and ``IPFabricSyncUpdatePathTests``
    inherit from this mixin so the boilerplate is not duplicated.
    """

    fixtures_dir = Path(__file__).parent / "data" / "create"

    # ------------------------------------------------------------------
    # Mock helpers
    # ------------------------------------------------------------------

    @classmethod
    def _mock_branch_model(cls):
        """Mock Branch.provision/refresh_from_db to avoid real schema creation."""

        def mock_branch_provision(self, user):
            Branch.objects.filter(pk=self.pk).update(
                status=BranchStatusChoices.READY,
                last_sync=timezone.now(),
            )
            self.status = BranchStatusChoices.READY
            self.last_sync = timezone.now()

        return patch.multiple(
            Branch,
            provision=mock_branch_provision,
            refresh_from_db=MagicMock(),
        )

    @classmethod
    def _mock_active_branch(cls):
        """Mock active_branch ContextVar so all DB ops stay on the default DB."""
        mock_active_branch = MagicMock()
        mock_active_branch.get.return_value = DEFAULT_DB_ALIAS
        mock_token = MagicMock()
        mock_active_branch.set.return_value = mock_token
        return patch("ipfabric_netbox.models.active_branch", mock_active_branch)

    @classmethod
    def _mock_sync_runner(cls):
        """Redirect IPFabricSyncRunner DB connections to the test DB alias."""

        def mock_get_db_connection_name(self):
            return DEFAULT_DB_ALIAS

        return patch.object(
            IPFabricSyncRunner, "get_db_connection_name", mock_get_db_connection_name
        )

    @classmethod
    def _mock_ipfabric_api(cls):
        """Mock IPFClient to serve fixture data for every endpoint."""

        def mock_fetch_all(self_ipf, url, snapshot_id=None, filters=None, **kwargs):
            endpoint_path = url if url.startswith("/") else f"/{url}"
            try:
                return cls.load_fixture(endpoint_path)
            except FileNotFoundError:
                return []

        def mock_init(self_ipf, *args, **kwargs):
            self_ipf._client = MagicMock()
            self_ipf._client.headers = {"user-agent": "test-ipfabric-client"}

        return patch.multiple(
            "ipfabric.IPFClient", __init__=mock_init, fetch_all=mock_fetch_all
        )

    # ------------------------------------------------------------------
    # Fixture loading
    # ------------------------------------------------------------------

    @classmethod
    def load_fixture(cls, endpoint_path: str) -> list:
        """
        Load test fixture data for an endpoint from ``cls.fixtures_dir``.

        Args:
            endpoint_path: API endpoint like '/inventory/sites/overview'

        Returns:
            List of data items from the fixture file.
        """
        filename = endpoint_path.strip("/").replace("/", "__") + ".json"
        filepath = cls.fixtures_dir / filename
        if not filepath.exists():
            raise FileNotFoundError(f"Fixture file not found: {filepath}")
        with open(filepath, "r") as f:
            return json.load(f)

    # ------------------------------------------------------------------
    # Shared initial-sync setup
    # ------------------------------------------------------------------

    @classmethod
    def _do_sync_setup(cls):
        """
        Create all required DB objects and run one full initial sync.

        Called from ``setUpTestData`` in every subclass.  Sets the class-level
        attributes ``user``, ``source``, ``snapshot`` and ``sync``.
        """
        cls.user = User.objects.create_user(
            username="test_sync_user", email="test@example.com"
        )

        cls.source = IPFabricSource.objects.create(
            name="Test Source",
            type="local",
            url="https://test.ipfabric.io",
            status="loaded",
            parameters={
                "base_url": "https://test.ipfabric.io",
                "token": "test_token_123456",
                "verify": False,
                "timeout": 30,
                "snapshot_id": "$last",
            },
        )

        cls.snapshot = IPFabricSnapshot.objects.create(
            name="Test Snapshot - Integration Tests",
            source=cls.source,
            snapshot_id="$last",
            status=IPFabricSnapshotStatusModelChoices.STATUS_LOADED,
            data={
                "id": "$last",
                "name": "Test Snapshot - Integration Tests",
                "status": "loaded",
                "start": "2026-02-23T10:00:00.000Z",
                "end": "2026-02-23T10:30:00.000Z",
            },
        )

        cls.sync = IPFabricSync.objects.create(
            name="Test Integration Sync",
            snapshot_data=cls.snapshot,
            parameters={
                "sites": [],
                "groups": [],
                "ipam.vrf": True,
                "dcim.site": True,
                "ipam.vlan": True,
                "dcim.device": True,
                "ipam.prefix": True,
                "dcim.platform": True,
                "dcim.interface": True,
                "ipam.ipaddress": True,
                "dcim.devicerole": True,
                "dcim.devicetype": True,
                "dcim.macaddress": True,
                "dcim.manufacturer": True,
                "dcim.inventoryitem": True,
                "dcim.virtualchassis": True,
            },
            user=cls.user,
            auto_merge=False,
            thread_count=2,
        )

        # ------------------------------------------------------------------
        # Spy on the three worker-thread entry-points so that subclasses can
        # assert the ThreadPoolExecutor paths were actually taken.
        #
        # _InlineExecutor replaces ThreadPoolExecutor so that all chunk
        # workers run synchronously in the main thread.  This sidesteps
        # Django TestCase transaction-isolation: worker threads that open new
        # DB connections cannot see the uncommitted test data, causing FK
        # violations.  Running inline keeps everything in the same
        # transaction.
        #
        # close_old_connections / connections.close_all are no-oped so that
        # the main thread’s test connection is never closed between chunks.
        #
        # _MIN_CHUNK_SIZE is patched to 1 so every model with ≥ 2 records
        # gets split into multiple chunks and routed through the executor
        # branch, even with tiny fixture data.
        # ------------------------------------------------------------------
        cls._sync_chunk_calls = []
        cls._devices_chunk_calls = []
        cls._ip_chunk_calls = []

        _orig_sync_chunk = IPFabricSyncRunner._sync_chunk
        _orig_devices_chunk = IPFabricSyncRunner._sync_devices_chunk
        _orig_ip_chunk = IPFabricSyncRunner._sync_ipaddresses_chunk

        def _spy_sync_chunk(self, chunk, ingestion=None, stats=True):
            cls._sync_chunk_calls.append([r.model_string for r in chunk])
            return _orig_sync_chunk(self, chunk, ingestion, stats)

        def _spy_devices_chunk(self, chunk, ingestion=None):
            cls._devices_chunk_calls.append(len(chunk))
            return _orig_devices_chunk(self, chunk, ingestion)

        def _spy_ip_chunk(self, chunk):
            cls._ip_chunk_calls.append(len(chunk))
            return _orig_ip_chunk(self, chunk)

        with (
            patch(
                "ipfabric_netbox.utilities.ipfutils.ThreadPoolExecutor",
                _InlineExecutor,
            ),
            patch(
                "ipfabric_netbox.utilities.ipfutils.close_old_connections",
                lambda: None,
            ),
            patch.object(_django_connections, "close_all", lambda: None),
            patch.object(IPFabricSyncRunner, "_MIN_CHUNK_SIZE", 1),
            patch.object(IPFabricSyncRunner, "_sync_chunk", _spy_sync_chunk),
            patch.object(IPFabricSyncRunner, "_sync_devices_chunk", _spy_devices_chunk),
            patch.object(IPFabricSyncRunner, "_sync_ipaddresses_chunk", _spy_ip_chunk),
            cls._mock_ipfabric_api(),
            cls._mock_branch_model(),
            cls._mock_active_branch(),
            cls._mock_sync_runner(),
        ):
            cls.sync.sync(job=None)


@tag("integration")
class IPFabricSyncIntegrationTests(_IPFabricSyncMixin, TestCase):
    """
    Integration tests for IPFabricSync sync operations (without actual branching).

    Test strategy:
    - Uses regular TestCase for fast execution (transaction rollback)
    - Mocks branching operations to avoid TransactionTestCase overhead
    - setUpTestData runs once: creates source/snapshot/sync, mocks API and branching
    - Sync writes directly to test database (branch mocked away)
    - Individual test methods verify synced data quickly
    - Fast execution: ~0.05s per test instead of ~1s with TransactionTestCase
    """

    @classmethod
    def setUpTestData(cls):
        """
        Runs ONCE before any test methods in this class.

        Delegates to ``_IPFabricSyncMixin._do_sync_setup`` which creates all DB
        objects and runs the initial full sync.  ``cls.ingestion`` is captured
        here because the merge-statistics tests need it.
        """
        super().setUpTestData()
        cls._do_sync_setup()
        cls.ingestion = cls.sync.last_ingestion

    # ==================== Sites Tests ====================

    def test_sites_created(self):
        """Verify sites from fixture are created in NetBox."""
        fixture_data = self.load_fixture("/inventory/sites/overview")
        expected_count = len(fixture_data)

        actual_count = Site.objects.count()
        self.assertEqual(
            actual_count,
            expected_count,
            f"Expected {expected_count} sites, found {actual_count}",
        )

    def test_site_names_match_fixture(self):
        """Verify site names match fixture data."""
        fixture_data = self.load_fixture("/inventory/sites/overview")
        self.assertGreater(len(fixture_data), 0, "sites fixture must be non-empty")

        for site_data in fixture_data:
            site_name = site_data["siteName"]
            self.assertTrue(
                Site.objects.filter(name=site_name).exists(),
                f"Site '{site_name}' missing from NetBox",
            )

    def test_site_attributes(self):
        """Verify site attributes are correctly mapped from fixture."""
        fixture_data = self.load_fixture("/inventory/sites/overview")
        first_site_data = fixture_data[0]

        site = Site.objects.get(name=first_site_data["siteName"])
        self.assertIsNotNone(site, "Site should exist")

        # Verify slug is generated (assuming transform map creates it)
        self.assertIsNotNone(site.slug, "Site slug should be set")

    def test_site_slug_is_slugified_site_name(self):
        """
        Verify Site.slug = siteName | slugify.

        Transform map: source_field=siteName, template={{ object.siteName | slugify }}
        e.g. 'Test-1X' → 'test-1x'
        """
        fixture_data = self.load_fixture("/inventory/sites/overview")
        self.assertGreater(len(fixture_data), 0, "sites fixture must be non-empty")
        for site_data in fixture_data:
            expected_slug = slugify(site_data["siteName"])
            site = Site.objects.get(name=site_data["siteName"])
            self.assertEqual(
                site.slug,
                expected_slug,
                f"Site '{site_data['siteName']}' slug should be '{expected_slug}', "
                f"got '{site.slug}'",
            )

    # ==================== Manufacturer Tests ====================

    def test_manufacturers_created(self):
        """Verify unique vendors from fixture are created as Manufacturers."""
        fixture_data = self.load_fixture("/inventory/devices")
        expected_vendors = {d["vendor"] for d in fixture_data}
        expected_count = len(expected_vendors)

        actual_count = Manufacturer.objects.count()
        self.assertEqual(
            actual_count,
            expected_count,
            f"Expected {expected_count} manufacturers, found {actual_count}",
        )

    def test_manufacturer_names_match_fixture(self):
        """Verify Manufacturer names are set from the vendor field."""
        fixture_data = self.load_fixture("/inventory/devices")
        self.assertGreater(len(fixture_data), 0, "devices fixture must be non-empty")

        for device_data in fixture_data:
            vendor = device_data["vendor"]
            self.assertTrue(
                Manufacturer.objects.filter(name=vendor).exists(),
                f"Manufacturer with name '{vendor}' missing from NetBox",
            )

    def test_manufacturer_slugs_match_fixture(self):
        """Verify Manufacturer slugs are the slugified vendor field."""
        fixture_data = self.load_fixture("/inventory/devices")
        self.assertGreater(len(fixture_data), 0, "devices fixture must be non-empty")

        for device_data in fixture_data:
            expected_slug = device_data["vendor"].lower().replace(" ", "-")
            self.assertTrue(
                Manufacturer.objects.filter(slug=expected_slug).exists(),
                f"Manufacturer with slug '{expected_slug}' missing from NetBox",
            )

    # ==================== DeviceType Tests ====================

    def test_device_types_created(self):
        """Verify unique models from fixture are created as DeviceTypes."""
        # DCS-7050SX-64-F (Arista), C9606R (TEST01-CS-01), WS-C2960-24TC-L (MGMT-SW-01),
        # WS-C3750E-24TD-S (stack member 1), WS-C3750-24PS-S (stack member 2)
        expected_count = 5

        actual_count = DeviceType.objects.count()
        self.assertEqual(
            actual_count,
            expected_count,
            f"Expected {expected_count} device types, found {actual_count}",
        )

    def test_device_type_slug_is_model_slugified(self):
        """
        Verify DeviceType.slug = model|string|slugify when model is present.

        Transform map template:
          {% if object.model %}{{ object.model | string | slugify }}
          {% else %}{{ object.vendor|slugify }}-{{ object.family|slugify }}-{{ object.platform|slugify }}{% endif %}

        For stack master devices the DeviceType comes from the member pn field,
        not from the device model — so the master's inventory model ('WS-C3750E-24TD')
        must be excluded. Only non-master device models and stack member pn values
        should have DeviceTypes.

        'DCS-7050SX-64-F' → 'dcs-7050sx-64-f'
        'WS-C3750E-24TD-S' → 'ws-c3750e-24td-s'
        'WS-C3750-24PS-S'  → 'ws-c3750-24ps-s'
        """
        fixture_data = self.load_fixture("/inventory/devices")
        stack_data = self.load_fixture("/technology/platforms/stack/members")

        # Serial numbers of stack masters — their device model is NOT used for DeviceType
        stack_master_serials = {d["sn"] for d in stack_data if d["role"] == "master"}

        # Non-master device models
        models = {
            d["model"]
            for d in fixture_data
            if d.get("model") and d["sn"] not in stack_master_serials
        }
        # Stack member pn values (these DO become DeviceTypes)
        models.update({d["pn"] for d in stack_data if d.get("pn")})

        self.assertGreater(
            len(models),
            0,
            "expected at least one non-master device model or stack-member pn",
        )
        for model in models:
            expected_slug = slugify(str(model))
            self.assertTrue(
                DeviceType.objects.filter(slug=expected_slug).exists(),
                f"DeviceType slug '{expected_slug}' (from model '{model}') not found",
            )

    def test_device_type_model_field_matches_fixture(self):
        """Verify DeviceType.model field matches the fixture model value."""
        model_name = "DCS-7050SX-64-F"
        self.assertTrue(
            DeviceType.objects.get(model=model_name),
            f"DeviceType with model '{model_name}' missing from NetBox",
        )

    def test_device_type_slugs_match_fixture(self):
        """Verify DeviceType slugs are the slugified model field."""
        model_name = "DCS-7050SX-64-F"
        expected_slug = model_name.lower().replace(" ", "-")
        self.assertTrue(
            DeviceType.objects.get(slug=expected_slug),
            f"DeviceType with slug '{expected_slug}' missing from NetBox",
        )

    def test_device_type_manufacturer_relationship(self):
        """Verify each DeviceType is linked to the correct Manufacturer."""
        device_model = "DCS-7050SX-64-F"
        device_vendor = "arista"

        device_type = DeviceType.objects.get(model=device_model)
        self.assertEqual(
            device_type.manufacturer.name,
            device_vendor,
            f"DeviceType '{device_model}' should belong to manufacturer '{device_vendor}', "
            f"got '{device_type.manufacturer.name}'",
        )

    # ==================== DeviceRole Tests ====================

    def test_device_roles_created(self):
        """Verify unique devType values from fixture are created as DeviceRoles."""
        fixture_data = self.load_fixture("/inventory/devices")
        expected_roles = {d["devType"] for d in fixture_data if d.get("devType")}
        expected_count = len(expected_roles)

        actual_count = DeviceRole.objects.count()
        self.assertEqual(
            actual_count,
            expected_count,
            f"Expected {expected_count} device roles, found {actual_count}",
        )

    def test_device_role_names_match_fixture(self):
        """Verify DeviceRole names match the devType field."""
        fixture_data = self.load_fixture("/inventory/devices")
        candidates = [d for d in fixture_data if d.get("devType")]
        self.assertGreater(
            len(candidates),
            0,
            "devices fixture must have at least one entry with devType set",
        )
        for device_data in candidates:
            dev_type = device_data["devType"]
            self.assertTrue(
                DeviceRole.objects.filter(name=dev_type).exists(),
                f"DeviceRole with name '{dev_type}' missing from NetBox",
            )

    def test_device_role_slugs_match_fixture(self):
        """Verify DeviceRole slugs are the slugified devType field."""
        # switch   -> switch
        # l3switch -> l3switch
        fixture_data = self.load_fixture("/inventory/devices")
        candidates = [d for d in fixture_data if d.get("devType")]
        self.assertGreater(
            len(candidates),
            0,
            "devices fixture must have at least one entry with devType set",
        )
        for device_data in candidates:
            dev_type = device_data["devType"]
            expected_slug = dev_type.lower().replace(" ", "-")
            self.assertTrue(
                DeviceRole.objects.filter(slug=expected_slug).exists(),
                f"DeviceRole with slug '{expected_slug}' missing from NetBox",
            )

    def test_device_role_vm_role_is_false(self):
        """Verify all synced DeviceRoles have vm_role set to False."""
        self.assertGreater(
            DeviceRole.objects.count(), 0, "at least one DeviceRole must exist"
        )
        for role in DeviceRole.objects.all():
            self.assertFalse(
                role.vm_role,
                f"DeviceRole '{role.name}' should have vm_role=False",
            )

    # ==================== Platform Tests ====================

    def test_platforms_created(self):
        """Verify unique family values from fixture are created as Platforms."""
        fixture_data = self.load_fixture("/inventory/devices")
        # family falls back to vendor when None/empty
        expected_slugs = {
            d["family"] if d.get("family") else d["vendor"] for d in fixture_data
        }
        expected_count = len(expected_slugs)

        actual_count = Platform.objects.count()
        self.assertEqual(
            actual_count,
            expected_count,
            f"Expected {expected_count} platforms, found {actual_count}",
        )

    def test_platform_names_match_fixture(self):
        """
        Verify Platform.name = family when family is present, else vendor.

        Transform map template:
          {% if object.family %}{{ object.family }}{% else %}{{ object.vendor }}{% endif %}

        Note: name is the RAW family value, not slugified.
        e.g. family='ios' → name='ios', family='eos' → name='eos'
        """
        fixture_data = self.load_fixture("/inventory/devices")
        self.assertGreater(len(fixture_data), 0, "devices fixture must be non-empty")

        for device_data in fixture_data:
            expected_name = (
                device_data["family"]
                if device_data.get("family")
                else device_data["vendor"]
            )
            self.assertTrue(
                Platform.objects.filter(name=expected_name).exists(),
                f"Platform with name '{expected_name}' missing from NetBox",
            )

    def test_platform_slug_is_family_slugified(self):
        """
        Verify Platform.slug = family|slugify when family present, else vendor|slugify.

        Transform map template:
          {% if object.family %}{{ object.family | slugify }}{% else %}{{ object.vendor | slugify }}{% endif %}

        e.g. family='ios' → slug='ios'
             family='eos' → slug='eos'
        """
        fixture_data = self.load_fixture("/inventory/devices")
        self.assertGreater(len(fixture_data), 0, "devices fixture must be non-empty")

        for device_data in fixture_data:
            if device_data.get("family"):
                expected_slug = slugify(device_data["family"])
            else:
                expected_slug = slugify(device_data["vendor"])
            self.assertTrue(
                Platform.objects.filter(slug=expected_slug).exists(),
                f"Platform with slug '{expected_slug}' missing from NetBox",
            )

    def test_platform_slugs_match_fixture(self):
        """Verify Platform slugs are the slugified family field (or vendor as fallback)."""
        fixture_data = self.load_fixture("/inventory/devices")
        self.assertGreater(len(fixture_data), 0, "devices fixture must be non-empty")

        for device_data in fixture_data:
            raw = (
                device_data["family"]
                if device_data.get("family")
                else device_data["vendor"]
            )
            expected_slug = slugify(raw)
            self.assertTrue(
                Platform.objects.filter(slug=expected_slug).exists(),
                f"Platform with slug '{expected_slug}' missing from NetBox",
            )

    def test_platform_manufacturer_relationship(self):
        """Verify each Platform is linked to the Manufacturer matching its vendor."""
        fixture_data = self.load_fixture("/inventory/devices")
        self.assertGreater(len(fixture_data), 0, "devices fixture must be non-empty")

        for device_data in fixture_data:
            vendor = device_data["vendor"]
            platform_name = (
                device_data["family"] if device_data.get("family") else vendor
            )
            platform = Platform.objects.get(name=platform_name)
            self.assertIsNotNone(
                platform.manufacturer,
                f"Platform '{platform_name}' should have a manufacturer",
            )
            self.assertEqual(
                platform.manufacturer.name,
                vendor,
                f"Platform '{platform_name}' should belong to manufacturer '{vendor}', "
                f"got '{platform.manufacturer.name}'",
            )

    # ==================== VirtualChassis Tests ====================

    def test_virtualchassis_created(self):
        """
        Verify one VirtualChassis record is created per unique master hostname
        across both stack members and VSS chassis fixtures.

        prepare_devices() collects the master member row into the virtualchassis
        list; one VC is created per stack master, not per member.
        VSS chassis also produce one VC per unique hostname.
        """
        stack_data = self.load_fixture("/technology/platforms/stack/members")
        vss_data = self.load_fixture("/technology/platforms/vss/chassis")
        expected_names = {d["master"] for d in stack_data} | {
            d["hostname"] for d in vss_data
        }
        expected_count = len(expected_names)

        actual_count = VirtualChassis.objects.count()
        self.assertEqual(
            actual_count,
            expected_count,
            f"Expected {expected_count} VirtualChassis records, found {actual_count}",
        )

    def test_virtualchassis_name_matches_master_hostname(self):
        """
        Verify VirtualChassis.name is set from the master hostname field.

        The transform map template for name is empty (pass-through), using
        source_field='master', so the VC name equals the master hostname string.
        """
        fixture_data = self.load_fixture("/technology/platforms/stack/members")
        master_names = {d["master"] for d in fixture_data}
        self.assertGreater(
            len(master_names),
            0,
            "stack members fixture must contain at least one master",
        )
        for master_name in master_names:
            self.assertTrue(
                VirtualChassis.objects.filter(name=master_name).exists(),
                f"VirtualChassis with name '{master_name}' missing from NetBox",
            )

    def test_virtualchassis_master_device_linked(self):
        """
        Verify VirtualChassis.master points to the Device whose serial matches
        the master member's sn field.

        The transform map relationship_map:
          template: Device.objects.filter(serial=object.sn).first()

        The master member is the row with role='master'; its memberSn == sn.
        """
        fixture_data = self.load_fixture("/technology/platforms/stack/members")
        master_rows = [d for d in fixture_data if d["role"] == "master"]
        self.assertGreater(
            len(master_rows),
            0,
            "stack members fixture must contain at least one master-role row",
        )
        for row in master_rows:
            vc = VirtualChassis.objects.get(name=row["master"])
            self.assertIsNotNone(
                vc.master,
                f"VirtualChassis '{row['master']}' should have a master device assigned",
            )
            self.assertEqual(
                vc.master.serial,
                row["memberSn"],
                f"VirtualChassis '{row['master']}' master serial should be "
                f"'{row['memberSn']}', got '{vc.master.serial}'",
            )

    def test_device_virtual_chassis_fk_set(self):
        """
        Verify every stack member Device has its virtual_chassis FK pointing
        to the correct VirtualChassis object.

        The device transform map relationship_map resolves the VC by
        VirtualChassis.objects.filter(name=object.virtual_chassis.master).first()
        """
        fixture_data = self.load_fixture("/technology/platforms/stack/members")
        self.assertGreater(
            len(fixture_data), 0, "stack members fixture must be non-empty"
        )
        for member_data in fixture_data:
            device = Device.objects.get(serial=member_data["memberSn"])
            self.assertIsNotNone(
                device.virtual_chassis,
                f"Device '{device.name}' should have virtual_chassis set",
            )
            vc = VirtualChassis.objects.get(name=member_data["master"])
            self.assertEqual(
                device.virtual_chassis.pk,
                vc.pk,
                f"Device '{device.name}' virtual_chassis should be "
                f"'{member_data['master']}', got '{device.virtual_chassis.name}'",
            )

    def test_device_vc_position_matches_member_number(self):
        """
        Verify Device.vc_position is set from the member field.

        The device transform map template:
          {% if object.virtual_chassis is defined %}{{ object.virtual_chassis.member }}{% else %}None{% endif %}
        """
        fixture_data = self.load_fixture("/technology/platforms/stack/members")
        self.assertGreater(
            len(fixture_data), 0, "stack members fixture must be non-empty"
        )
        for member_data in fixture_data:
            device = Device.objects.get(serial=member_data["memberSn"])
            self.assertEqual(
                str(device.vc_position),
                str(member_data["member"]),
                f"Device '{device.name}' vc_position should be "
                f"'{member_data['member']}', got '{device.vc_position}'",
            )

    def test_stack_member_device_types_created(self):
        """
        Verify DeviceTypes are created for each stack member's pn field,
        and that the master hostname is NOT created as a DeviceType.

        Each member carries its own part number (pn) which is the model used for
        the DeviceType. The master field holds only the hostname of the master
        device and must never be treated as a model name.
        """
        fixture_data = self.load_fixture("/technology/platforms/stack/members")
        self.assertGreater(
            len(fixture_data), 0, "stack members fixture must be non-empty"
        )
        for member_data in fixture_data:
            pn = member_data["pn"]
            expected_slug = pn.lower().replace(" ", "-")

            self.assertTrue(
                DeviceType.objects.filter(model=pn).exists(),
                f"DeviceType for stack member pn '{pn}' missing from NetBox",
            )
            self.assertTrue(
                DeviceType.objects.filter(slug=expected_slug).exists(),
                f"DeviceType with slug '{expected_slug}' (from pn '{pn}') missing from NetBox",
            )

        master_model = "WS-C3750E-24TD"
        self.assertFalse(
            DeviceType.objects.filter(model=master_model).exists(),
            f"DeviceType with model='{master_model}' should not exist — "
            f"this is the master device's inventory model, not a stack member pn",
        )

    def test_stack_members_names(self):
        """Verify stack members device names are correctly synced."""
        fixture_data = self.load_fixture("/technology/platforms/stack/members")
        self.assertGreater(
            len(fixture_data), 0, "stack members fixture must be non-empty"
        )
        for device_data in fixture_data:
            device = Device.objects.get(serial=device_data["memberSn"])
            device_name = f"{device_data['master']}/{device_data['member']}"
            self.assertEqual(
                device.name,
                device_name,
                f"Device '{device_name}' name mismatch",
            )
            self.assertFalse(
                Device.objects.filter(name=device_data["master"]).exists(),
                "Master device should not be created separately from stack members",
            )

    def test_stack_members_serial_numbers(self):
        """Verify stack members serial numbers are correctly synced."""
        fixture_data = self.load_fixture("/technology/platforms/stack/members")
        self.assertGreater(
            len(fixture_data), 0, "stack members fixture must be non-empty"
        )
        for device_data in fixture_data:
            device = Device.objects.get(
                name=f"{device_data['master']}/{device_data['member']}"
            )
            self.assertEqual(
                device.serial,
                device_data["memberSn"],
                f"Device '{device.name}' serial number mismatch",
            )

    def test_non_stack_devices_have_no_virtual_chassis(self):
        """
        Verify that regular (non-stack, non-VSS) devices do not have a
        virtual_chassis assigned.

        Only devices whose sn appears in the stack members fixture or whose
        sn appears in the VSS chassis fixture should be linked to a
        VirtualChassis; all other synced devices must have virtual_chassis=None.
        """
        stack_data = self.load_fixture("/technology/platforms/stack/members")
        vss_data = self.load_fixture("/technology/platforms/vss/chassis")
        # Exclude both the master sn and all chassisSn values — every serial that
        # ends up inside a VirtualChassis (including the standby chassis members)
        vc_serials = (
            {d["memberSn"] for d in stack_data}
            | {d["sn"] for d in vss_data}
            | {d["chassisSn"] for d in vss_data}
        )
        self.assertGreater(
            len(vc_serials),
            0,
            "stack/VSS fixtures must contain at least one member serial",
        )

        regular_devices = Device.objects.exclude(serial__in=vc_serials)
        self.assertGreater(
            regular_devices.count(),
            0,
            "at least one non-stack/non-VSS device must exist to exercise this test",
        )
        for device in regular_devices:
            self.assertIsNone(
                device.virtual_chassis,
                f"Non-stack/non-VSS device '{device.name}' (serial={device.serial}) "
                f"should have virtual_chassis=None",
            )

    # ==================== Device Tests ====================

    def test_devices_created(self):
        """
        Verify devices from fixture are created in NetBox.

        Devices are sourced from three fixtures:
          - inventory/devices: standalone devices (those not expanded by stack/VSS)
          - stack/members: one device per member row (master's sn replaces inventory entry)
          - vss/chassis: one device per unique chassisId+chassisSn pair (deduplicated)

        The expected count equals the number of unique device serial numbers produced
        by prepare_devices() across all three sources.
        """
        inv_devices = self.load_fixture("/inventory/devices")
        stack_data = self.load_fixture("/technology/platforms/stack/members")
        vss_data = self.load_fixture("/technology/platforms/vss/chassis")

        members = {}
        for m in stack_data:
            members.setdefault(m["sn"], []).append(m)
        for m in vss_data:
            members.setdefault(m["sn"], []).append(m)

        all_sns = set()
        for device in inv_devices:
            if device["sn"] in members:
                for child in members[device["sn"]]:
                    member_sn = child.get("memberSn") or child.get("chassisSn")
                    all_sns.add(member_sn)
            else:
                all_sns.add(device["sn"])

        expected_count = len(all_sns)
        actual_count = Device.objects.count()
        self.assertEqual(
            actual_count,
            expected_count,
            f"Expected {expected_count} devices, found {actual_count}",
        )

    def test_device_name_match(self):
        """Verify device names match fixture data."""
        device_name = "HWLAB-B-SW02-ARISTA-7050SX"
        self.assertTrue(
            Device.objects.filter(name=device_name).exists(),
            f"Device '{device_name}' missing from NetBox",
        )

    def test_device_site_relationship(self):
        """Verify devices are linked to correct sites."""
        fixture_data = self.load_fixture("/inventory/devices")
        self.assertGreater(len(fixture_data), 0, "devices fixture must be non-empty")

        for device_data in fixture_data:
            device = Device.objects.get(serial=device_data["sn"])
            expected_site_name = device_data["siteName"]

            self.assertIsNotNone(
                device.site, f"Device '{device.name}' should have a site"
            )
            self.assertEqual(
                device.site.name,
                expected_site_name,
                f"Device '{device.name}' should be in site '{expected_site_name}'",
            )

    def test_device_platform_manufacturer_chain(self):
        """Verify Device -> Platform -> Manufacturer chain resolves correctly."""
        fixture_data = self.load_fixture("/inventory/devices")
        self.assertGreater(len(fixture_data), 0, "devices fixture must be non-empty")

        for device_data in fixture_data:
            device = Device.objects.get(serial=device_data["sn"])
            self.assertIsNotNone(
                device.platform,
                f"Device '{device.name}' should have a platform",
            )
            self.assertEqual(
                device.platform.manufacturer.name,
                device_data["vendor"],
                f"Device '{device.name}' platform.manufacturer should be "
                f"'{device_data['vendor']}', got '{device.platform.manufacturer.name}'",
            )

    def test_device_role_assignment(self):
        """Verify each Device is assigned the DeviceRole matching its devType."""
        fixture_data = self.load_fixture("/inventory/devices")
        candidates = [d for d in fixture_data if d.get("devType")]
        self.assertGreater(
            len(candidates),
            0,
            "devices fixture must have at least one entry with devType set",
        )
        for device_data in candidates:
            device = Device.objects.get(serial=device_data["sn"])
            expected_role_name = device_data["devType"]
            self.assertIsNotNone(
                device.role,
                f"Device '{device.name}' should have a role",
            )
            self.assertEqual(
                device.role.name,
                expected_role_name,
                f"Device '{device.name}' role should be '{expected_role_name}', "
                f"got '{device.role.name}'",
            )

    def test_device_status_is_active(self):
        """
        Verify every synced Device has status set to 'active'.

        The Device Transform Map sets status via a hardcoded template:
          source_field: hostname, target_field: status, coalesce: false
          template: active
        """
        fixture_data = self.load_fixture("/inventory/devices")
        self.assertGreater(len(fixture_data), 0, "devices fixture must be non-empty")
        for device_data in fixture_data:
            device = Device.objects.get(serial=device_data["sn"])
            self.assertEqual(
                device.status,
                "active",
                f"Device '{device.name}' status should be 'active', "
                f"got '{device.status}'",
            )

    # ==================== Inventory Item Tests ====================

    def test_inventory_items_created(self):
        """Verify every fixture part-number entry creates one InventoryItem in NetBox."""
        fixture_data = self.load_fixture("/inventory/part-numbers")
        expected_count = len(fixture_data)

        actual_count = InventoryItem.objects.count()
        self.assertEqual(
            actual_count,
            expected_count,
            f"Expected {expected_count} inventory items, found {actual_count}",
        )

    @staticmethod
    def _inv_name(item_data: dict) -> str:
        """
        Compute expected InventoryItem.name using the same logic as the transform map.

        Template (data/transform_map.json):
          {% if object.name is not none %}{{ object.name | string | truncate(64, True) }}
          {% elif object.dscr is not none %}{{ object.dscr | string | truncate(64, True) }}
          {% else %}Default Name{% endif %}

        Jinja2 truncate(64, killwords=True) returns s[:61] + '...' when len(s) > 64,
        otherwise returns s unchanged.
        """

        def _truncate(s: str) -> str:
            s = str(s)
            return s[:61] + "..." if len(s) > 64 else s

        if item_data.get("name") is not None:
            return _truncate(item_data["name"])
        elif item_data.get("dscr") is not None:
            return _truncate(item_data["dscr"])
        return "Default Name"

    def test_inventory_item_name_mapped(self):
        """
        Verify InventoryItem.name is set from the name field (truncated to 64 chars).

        The transform map template:
          - name when not None → truncated to 64 chars (Jinja2 truncate)
          - else dscr when not None → truncated to 64 chars
          - else 'Default Name'
        """
        fixture_data = self.load_fixture("/inventory/part-numbers")
        self.assertGreater(
            len(fixture_data), 0, "part-numbers fixture must be non-empty"
        )
        for item_data in fixture_data:
            expected_name = self._inv_name(item_data)

            device = Device.objects.get(serial=item_data["deviceSn"])
            self.assertTrue(
                InventoryItem.objects.filter(
                    device=device, name=expected_name
                ).exists(),
                f"InventoryItem '{expected_name}' on device '{device.name}' not found",
            )

    def test_inventory_item_serial_mapped(self):
        """Verify InventoryItem.serial is set from the sn field."""
        fixture_data = self.load_fixture("/inventory/part-numbers")
        self.assertGreater(
            len(fixture_data), 0, "part-numbers fixture must be non-empty"
        )
        for item_data in fixture_data:
            device = Device.objects.get(serial=item_data["deviceSn"])
            name = self._inv_name(item_data)
            item = InventoryItem.objects.get(
                device=device, name=name, serial=item_data["sn"]
            )
            self.assertEqual(
                item.serial,
                item_data["sn"],
                f"InventoryItem '{name}' serial should be '{item_data['sn']}', "
                f"got '{item.serial}'",
            )

    def test_inventory_item_part_id_mapped(self):
        """
        Verify InventoryItem.part_id is set from pid, falling back to 'unknown'
        when pid is null or the string 'None'.

        Transform map template:
          {% if object.pid and object.pid != "None" %}{{ object.pid }}
          {% else %}unknown{% endif %}
        """
        fixture_data = self.load_fixture("/inventory/part-numbers")
        self.assertGreater(
            len(fixture_data), 0, "part-numbers fixture must be non-empty"
        )
        for item_data in fixture_data:
            pid = item_data.get("pid")
            expected_part_id = pid if pid and pid != "None" else "unknown"

            device = Device.objects.get(serial=item_data["deviceSn"])
            name = self._inv_name(item_data)
            item = InventoryItem.objects.get(
                device=device, name=name, serial=item_data["sn"]
            )
            self.assertEqual(
                item.part_id,
                expected_part_id,
                f"InventoryItem '{name}' part_id should be '{expected_part_id}', "
                f"got '{item.part_id}'",
            )

    def test_inventory_item_device_relationship(self):
        """
        Verify every InventoryItem is linked to the Device matched by deviceSn.

        The transform map uses Device.objects.get(serial=object.deviceSn) —
        note: deviceSn, not sn (which is the item's own serial number).
        """
        fixture_data = self.load_fixture("/inventory/part-numbers")
        self.assertGreater(
            len(fixture_data), 0, "part-numbers fixture must be non-empty"
        )
        for item_data in fixture_data:
            device = Device.objects.get(serial=item_data["deviceSn"])
            name = self._inv_name(item_data)
            self.assertTrue(
                InventoryItem.objects.filter(
                    device=device, name=name, serial=item_data["sn"]
                ).exists(),
                f"InventoryItem '{name}' (sn='{item_data['sn']}') should be linked "
                f"to device with serial '{item_data['deviceSn']}'",
            )

    def test_inventory_item_manufacturer_relationship(self):
        """Verify each InventoryItem is linked to the Manufacturer matching its vendor."""
        fixture_data = self.load_fixture("/inventory/part-numbers")
        self.assertGreater(
            len(fixture_data), 0, "part-numbers fixture must be non-empty"
        )
        for item_data in fixture_data:
            device = Device.objects.get(serial=item_data["deviceSn"])
            name = self._inv_name(item_data)
            item = InventoryItem.objects.get(
                device=device, name=name, serial=item_data["sn"]
            )
            expected_slug = item_data["vendor"].lower().replace(" ", "-")
            self.assertIsNotNone(
                item.manufacturer,
                f"InventoryItem '{name}' should have a manufacturer",
            )
            self.assertEqual(
                item.manufacturer.slug,
                expected_slug,
                f"InventoryItem '{name}' manufacturer should have slug "
                f"'{expected_slug}', got '{item.manufacturer.slug}'",
            )

    def test_inventory_item_name_falls_back_to_dscr(self):
        """
        Verify InventoryItem.name falls back to dscr when name field is None.

        The template uses name first, then dscr, then 'Default Name'.
        The fixture has no entries with name=None but non-null dscr; instead
        this test verifies the primary path where name is used.
        From the fixture the Cisco chassis item has name='1' and dscr='WS-C3750E-24TD'
        — the stored name must be '1', not the dscr value.
        """
        cisco_sn = "FDO1552Y0SM"
        device = Device.objects.get(serial=cisco_sn)

        # name='1', dscr='WS-C3750E-24TD' → stored name must be '1'
        # sn='FDO1552Y0SM' (same as deviceSn for the chassis item)
        item = InventoryItem.objects.get(device=device, name="1", serial="FDO1552Y0SM")
        self.assertEqual(
            item.name,
            "1",
            "InventoryItem name should be '1' (from name field), not dscr",
        )
        # Confirm the dscr value was NOT used as the name
        self.assertFalse(
            InventoryItem.objects.filter(device=device, name="WS-C3750E-24TD").exists(),
            "dscr value 'WS-C3750E-24TD' should not appear as InventoryItem name "
            "when name field is populated",
        )

    def test_inventory_item_null_dscr_does_not_crash(self):
        """
        Verify InventoryItem records are created even when dscr is null.

        Several Arista fan/PSU entries have dscr=null. The template handles
        this by falling through to 'Default Name' only if name is also None.
        Since those entries do have a name ('1','2','3','4'), they must
        be created with that name.
        """
        arista_sn = "SSJ17151159"
        device = Device.objects.get(serial=arista_sn)

        fixture_data = self.load_fixture("/inventory/part-numbers")
        null_dscr_entries = [
            d
            for d in fixture_data
            if d["deviceSn"] == arista_sn and d.get("dscr") is None
        ]
        self.assertTrue(
            null_dscr_entries,
            "Fixture should contain Arista entries with dscr=null",
        )
        for item_data in null_dscr_entries:
            expected_name = self._inv_name(item_data)
            self.assertTrue(
                InventoryItem.objects.filter(
                    device=device, name=expected_name
                ).exists(),
                f"InventoryItem '{expected_name}' with null dscr should still be created",
            )

    def test_inventory_item_name_truncated_to_64_chars(self):
        """
        Verify InventoryItem.name is truncated to 64 characters.

        Transform map template: {{ object.name | string | truncate(64, True) }}
        Jinja2 truncate(64, killwords=True) returns s[:61] + '...' when len(s) > 64.
        """
        device = Device.objects.get(serial="SSJ17151159")
        long_name = "This inventory item name is intentionally longer than sixty-four characters total"
        expected_name = long_name[:61] + "..."
        item = InventoryItem.objects.get(device=device, serial="LONGNAME001")
        self.assertEqual(
            item.name,
            expected_name,
            f"InventoryItem name should be first 61 chars + '...', got '{item.name}'",
        )

    def test_inventory_item_name_uses_dscr_when_name_is_null(self):
        """
        Verify InventoryItem.name falls back to dscr when name field is null.

        Transform map template:
          {% if object.name is not none %}...
          {% elif object.dscr is not none %}{{ object.dscr | string | truncate(64, True) }}
          ...

        The fixture 'DSCRFALLBACK001' entry has name=null and dscr='Fallback from dscr field'.
        """
        device = Device.objects.get(serial="SSJ17151159")
        item = InventoryItem.objects.get(device=device, serial="DSCRFALLBACK001")
        self.assertEqual(
            item.name,
            "Fallback from dscr field",
            f"InventoryItem with name=null should use dscr, got '{item.name}'",
        )

    def test_inventory_item_name_defaults_when_both_null(self):
        """
        Verify InventoryItem.name is 'Default Name' when both name and dscr are null.

        Transform map template:
          ...{% else %}Default Name{% endif %}

        The fixture 'DEFAULTNAME001' entry has name=null and dscr=null.
        """
        device = Device.objects.get(serial="SSJ17151159")
        item = InventoryItem.objects.get(device=device, serial="DEFAULTNAME001")
        self.assertEqual(
            item.name,
            "Default Name",
            f"InventoryItem with name=null dscr=null should be 'Default Name', got '{item.name}'",
        )

    def test_inventory_item_pid_none_string_maps_to_unknown(self):
        """
        Verify InventoryItem.part_id='unknown' when pid is the string 'None'.

        Transform map template:
          {% if object.pid and object.pid != 'None' %}{{ object.pid }}{% else %}unknown{% endif %}

        The fixture 'DEFAULTNAME001' entry has pid=null which also maps to 'unknown'.
        """
        device = Device.objects.get(serial="SSJ17151159")
        item = InventoryItem.objects.get(device=device, serial="DEFAULTNAME001")
        self.assertEqual(
            item.part_id,
            "unknown",
            "InventoryItem with pid=null should have part_id='unknown'",
        )

    # ==================== Interface Tests ====================

    def test_interfaces_created(self):
        """Verify every fixture interface entry creates one Interface in NetBox."""
        fixture_data = self.load_fixture("/inventory/interfaces")
        expected_count = len(fixture_data)

        actual_count = Interface.objects.count()
        self.assertEqual(
            actual_count,
            expected_count,
            f"Expected {expected_count} interfaces, found {actual_count}",
        )

    def test_interface_name_uses_nameOriginal_over_intName(self):
        """
        Verify Interface.name is set from nameOriginal, not from intName.

        The transform map source_field is nameOriginal.  Where the two differ
        (e.g. intName='Vl1' / nameOriginal='Vlan1', intName='Gi1/0/4' /
        nameOriginal='GigabitEthernet1/0/4') the stored name must be the
        nameOriginal value, and a lookup by intName must find nothing.
        """
        fixture_data = self.load_fixture("/inventory/interfaces")

        # Entries where the two fields differ are the interesting ones
        differing = [
            d
            for d in fixture_data
            if d.get("nameOriginal") and d["nameOriginal"] != d["intName"]
        ]
        self.assertTrue(
            differing, "Fixture should contain entries where nameOriginal != intName"
        )

        for iface_data in differing:
            device = Device.objects.get(serial=iface_data["sn"])

            # nameOriginal must exist as the interface name
            self.assertTrue(
                Interface.objects.filter(
                    device=device, name=iface_data["nameOriginal"]
                ).exists(),
                f"Interface '{iface_data['nameOriginal']}' (nameOriginal) not found "
                f"on device '{device.name}'",
            )
            # intName must NOT have been used as the interface name
            self.assertFalse(
                Interface.objects.filter(
                    device=device, name=iface_data["intName"]
                ).exists(),
                f"Interface '{iface_data['intName']}' (intName) should not exist — "
                f"nameOriginal '{iface_data['nameOriginal']}' should have been used instead",
            )

    def test_interface_enabled_reflects_l1_state(self):
        """
        Verify Interface.enabled is True when l1=='up', False otherwise.

        The transform map template: {% if object.l1 == "up" %}True{% else %}False{% endif %}
        """
        fixture_data = self.load_fixture("/inventory/interfaces")

        # Pick one interface that is up and one that is down to keep test fast
        up_iface = next(
            (d for d in fixture_data if d["l1"] == "up" and d.get("nameOriginal")), None
        )
        down_iface = next(
            (d for d in fixture_data if d["l1"] != "up" and d.get("nameOriginal")), None
        )
        self.assertIsNotNone(
            up_iface,
            "interfaces fixture must contain at least one l1='up' entry with nameOriginal",
        )
        self.assertIsNotNone(
            down_iface,
            "interfaces fixture must contain at least one l1!='up' entry with nameOriginal",
        )

        for iface_data, expected_enabled in ((up_iface, True), (down_iface, False)):
            device = Device.objects.get(serial=iface_data["sn"])
            name = iface_data["nameOriginal"]
            iface = Interface.objects.get(device=device, name=name)
            self.assertEqual(
                iface.enabled,
                expected_enabled,
                f"Interface '{name}' enabled should be {expected_enabled} "
                f"(l1='{iface_data['l1']}')",
            )

    def test_interface_description_mapped(self):
        """
        Verify Interface.description is set from dscr, empty string when dscr is null.

        The transform map skips setting description when dscr.lower() == 'none'.
        """
        fixture_data = self.load_fixture("/inventory/interfaces")

        # Interface with a real description (not null and not the string 'none')
        described = next(
            (d for d in fixture_data if d.get("dscr") and d["dscr"].lower() != "none"),
            None,
        )
        self.assertIsNotNone(
            described,
            "interfaces fixture must contain at least one entry with a real dscr value",
        )
        device = Device.objects.get(serial=described["sn"])
        name = described["nameOriginal"] or described["intName"]
        iface = Interface.objects.get(device=device, name=name)
        self.assertEqual(
            iface.description,
            described["dscr"],
            f"Interface '{name}' description should be '{described['dscr']}'",
        )

        # Interface without a description (dscr is null, has a real nameOriginal)
        no_desc = next(
            (
                d
                for d in fixture_data
                if d.get("dscr") is None and d.get("nameOriginal")
            ),
            None,
        )
        self.assertIsNotNone(
            no_desc,
            "interfaces fixture must contain at least one entry with dscr=null and nameOriginal set",
        )
        device = Device.objects.get(serial=no_desc["sn"])
        name = no_desc["nameOriginal"]
        iface = Interface.objects.get(device=device, name=name)
        self.assertEqual(
            iface.description,
            "",
            f"Interface '{name}' description should be empty when dscr is null",
        )

    def test_interface_mtu_mapped(self):
        """Verify Interface.mtu is set directly from the fixture mtu field."""
        fixture_data = self.load_fixture("/inventory/interfaces")
        sample = fixture_data[0]

        device = Device.objects.get(serial=sample["sn"])
        name = sample["nameOriginal"]
        iface = Interface.objects.get(device=device, name=name)

        self.assertEqual(
            iface.mtu,
            sample["mtu"],
            f"Interface '{name}' mtu should be {sample['mtu']}",
        )

    def test_interface_speed_mapped(self):
        """
        Verify Interface.speed is set to speedValue // 1000, None when null.

        The transform map: speedValue|int // 1000  (or None if null/"unknown")
        """
        fixture_data = self.load_fixture("/inventory/interfaces")

        # Interface with a known speedValue (must have a nameOriginal for lookup)
        with_speed = next(
            (d for d in fixture_data if d.get("speedValue") and d.get("nameOriginal")),
            None,
        )
        self.assertIsNotNone(
            with_speed,
            "interfaces fixture must contain at least one entry with speedValue set and nameOriginal",
        )
        device = Device.objects.get(serial=with_speed["sn"])
        name = with_speed["nameOriginal"]
        iface = Interface.objects.get(device=device, name=name)
        expected_speed = with_speed["speedValue"] // 1000
        self.assertEqual(
            iface.speed,
            expected_speed,
            f"Interface '{name}' speed should be {expected_speed}",
        )

        # Interface with null speedValue (must have a nameOriginal for lookup)
        no_speed = next(
            (
                d
                for d in fixture_data
                if d.get("speedValue") is None and d.get("nameOriginal")
            ),
            None,
        )
        self.assertIsNotNone(
            no_speed,
            "interfaces fixture must contain at least one entry with speedValue=null and nameOriginal",
        )
        device = Device.objects.get(serial=no_speed["sn"])
        name = no_speed["nameOriginal"]
        iface = Interface.objects.get(device=device, name=name)
        self.assertIsNone(
            iface.speed,
            f"Interface '{name}' speed should be None when speedValue is null",
        )

    def test_interface_mgmt_only_when_primary_ip_matches_login_ip(self):
        """
        Verify Interface.mgmt_only=True only when primaryIp equals the device loginIp.

        _preprocess_interfaces injects loginIp (the device's loginIpv4) into each
        interface record. The transform map then sets mgmt_only=True when
        primaryIp == loginIp.

        From the fixture:
        - Gi1/0/5 on FDO1552Y0SM has primaryIp=172.16.58.11; loginIpv4=10.0.128.6 → False
        - Vl128 on FDO1552Y0SM has primaryIp=10.0.128.6;  loginIpv4=10.0.128.6 → True
        """
        cisco_sn = "FDO1552Y0SM"
        device = Device.objects.get(serial=cisco_sn)

        # intName="Vl128" → nameOriginal="Vlan128"; primaryIp=10.0.128.6 == loginIpv4
        mgmt_iface = Interface.objects.get(device=device, name="Vlan128")
        self.assertTrue(
            mgmt_iface.mgmt_only,
            "Vlan128 should be mgmt_only=True because its primaryIp matches loginIpv4",
        )

        # intName="Gi1/0/5" → nameOriginal="GigabitEthernet1/0/5"; primaryIp=172.16.58.11 != loginIpv4
        non_mgmt_iface = Interface.objects.get(
            device=device, name="GigabitEthernet1/0/5"
        )
        self.assertFalse(
            non_mgmt_iface.mgmt_only,
            "GigabitEthernet1/0/5 should be mgmt_only=False because its primaryIp differs from loginIpv4",
        )

    def test_interface_name_falls_back_to_intName_when_nameOriginal_null(self):
        """
        Verify Interface.name falls back to intName when nameOriginal is null.

        Transform map template:
          {% if object.nameOriginal %}{{ object.nameOriginal }}{% else %}{{ object.intName }}{% endif %}

        The fixture has a 'NullOriginal1' entry with nameOriginal=null; the stored
        name must be 'NullOriginal1' (the intName value).
        """
        device = Device.objects.get(serial="SSJ17151159")
        self.assertTrue(
            Interface.objects.filter(device=device, name="NullOriginal1").exists(),
            "Interface 'NullOriginal1' (intName fallback when nameOriginal=null) not found",
        )

    def test_interface_type_is_always_1000base_t(self):
        """
        Verify Interface.type is always '1000base-t' regardless of media field.

        The transform map has a hardcoded template: '1000base-t'
        """
        self.assertGreater(
            Interface.objects.count(), 0, "at least one Interface must exist"
        )
        for iface in Interface.objects.all():
            self.assertEqual(
                iface.type,
                "1000base-t",
                f"Interface '{iface.name}' type should be '1000base-t', got '{iface.type}'",
            )

    def test_interface_duplex_unknown_maps_to_none(self):
        """
        Verify Interface.duplex=None when duplex field is 'unknown'.

        Transform map template:
          {% if not object.duplex or object.duplex=='unknown' %}None{% else %}{{ object.duplex }}{% endif %}

        The fixture 'NullOriginal1' entry has duplex='unknown'.
        """
        device = Device.objects.get(serial="SSJ17151159")
        iface = Interface.objects.get(device=device, name="NullOriginal1")
        self.assertIsNone(
            iface.duplex,
            "Interface 'NullOriginal1' with duplex='unknown' should have duplex=None",
        )

    def test_interface_mtu_defaults_to_1500_when_null(self):
        """
        Verify Interface.mtu defaults to 1500 when mtu field is null.

        Transform map template: {{ object.mtu or 1500 }}

        The fixture 'NullOriginal1' entry has mtu=null.
        """
        device = Device.objects.get(serial="SSJ17151159")
        iface = Interface.objects.get(device=device, name="NullOriginal1")
        self.assertEqual(
            iface.mtu,
            1500,
            "Interface 'NullOriginal1' with mtu=null should default to mtu=1500",
        )

    def test_interface_dscr_string_none_maps_to_empty(self):
        """
        Verify Interface.description='' when dscr is the string 'none'.

        Transform map template:
          {% if (object.dscr | lower) != 'none' %}{{ object.dscr or '' }}{% endif %}

        The fixture 'GigabitEthernet1/0/99' entry has dscr='none' (literal string).
        """
        device = Device.objects.get(serial="FDO1552Y0SM")
        iface = Interface.objects.get(device=device, name="GigabitEthernet1/0/99")
        self.assertEqual(
            iface.description,
            "",
            "Interface with dscr='none' (string) should have description=''",
        )

    def test_interface_device_relationship(self):
        """Verify every Interface is linked to the correct Device via sn."""
        fixture_data = self.load_fixture("/inventory/interfaces")
        self.assertGreater(len(fixture_data), 0, "interfaces fixture must be non-empty")

        for iface_data in fixture_data:
            expected_name = (
                iface_data["nameOriginal"]
                if iface_data.get("nameOriginal")
                else iface_data["intName"]
            )
            device = Device.objects.get(serial=iface_data["sn"])
            self.assertTrue(
                Interface.objects.filter(device=device, name=expected_name).exists(),
                f"Interface '{expected_name}' on device '{device.name}' not found",
            )

    def test_interface_tagged_vlans_assigned(self):
        """
        Verify tagged VLANs are assigned to interfaces whose IPs carry a vlanId.

        The create fixture has Vl128 (FDO1552Y0SM) mapped to vlanId=128 in the
        IP table, and VLAN 128 exists in the VLAN fixture.  After sync, the
        Vlan128 interface must have VLAN 128 in its tagged_vlans M2M set.
        Also checks that Gi1/0/5 (FDO1552Y0SM) has VLAN 128 tagged, since its
        IP entry was updated in the create fixture with vlanId=128.
        """
        device = Device.objects.get(serial="FDO1552Y0SM")

        # SVI interface – vlanId=128 comes directly from IP fixture
        vlan128 = VLAN.objects.get(vid=128)
        iface_vlan128 = Interface.objects.get(device=device, name="Vlan128")
        self.assertIn(
            vlan128,
            iface_vlan128.tagged_vlans.all(),
            "Interface 'Vlan128' must have VLAN 128 in tagged_vlans",
        )

        # Physical interface – vlanId=128 injected via modified create fixture
        iface_gi5 = Interface.objects.get(device=device, name="GigabitEthernet1/0/5")
        self.assertIn(
            vlan128,
            iface_gi5.tagged_vlans.all(),
            "Interface 'GigabitEthernet1/0/5' must have VLAN 128 in tagged_vlans "
            "(vlanId=128 set in create fixture)",
        )

    def test_interface_mode_tagged_when_vlans_present(self):
        """
        Verify Interface.mode is set to 'tagged' when tagged_vlan_ids is non-empty.

        The transform map template returns 'tagged' when tagged_vlan_ids is
        non-empty, which is injected into the DataRecord during preprocessing.
        """
        device = Device.objects.get(serial="FDO1552Y0SM")
        iface = Interface.objects.get(device=device, name="Vlan128")
        self.assertEqual(
            iface.mode,
            "tagged",
            "Interface 'Vlan128' must have mode='tagged' because it has tagged VLANs",
        )

    def test_interface_mode_none_when_no_vlans(self):
        """
        Verify Interface.mode is None when the interface has no IP with a vlanId.

        GigabitEthernet1/0/1 on FDO1552Y0SM has no IP in the fixture, so
        tagged_vlan_ids=[] and the mode template renders empty → None.
        """
        device = Device.objects.get(serial="FDO1552Y0SM")
        iface = Interface.objects.get(device=device, name="GigabitEthernet1/0/1")
        self.assertIsNone(
            iface.mode,
            "Interface 'GigabitEthernet1/0/1' must have mode=None (no vlanId in IPs)",
        )

    def test_interface_no_tagged_vlans_when_no_vlan_ids(self):
        """
        Verify Interface.tagged_vlans is empty when no IP carries a vlanId.

        GigabitEthernet1/0/1 on FDO1552Y0SM has no IP entry in the fixture,
        so tagged_vlan_ids=[] and tagged_vlans.set([]) leaves the M2M empty.
        """
        device = Device.objects.get(serial="FDO1552Y0SM")
        iface = Interface.objects.get(device=device, name="GigabitEthernet1/0/1")
        self.assertEqual(
            iface.tagged_vlans.count(),
            0,
            "Interface 'GigabitEthernet1/0/1' must have no tagged VLANs",
        )

    # ==================== MAC Address Tests ====================

    def test_mac_addresses_created(self):
        """
        Verify MACAddress records are created only for interfaces with non-null mac.

        _preprocess_interfaces creates a macaddress record for every interface row,
        but the transform map template falls back to 00:00:00:00:00:01 when mac is
        null — so every interface still produces a MACAddress. Count must equal
        total interface fixture entries.
        """
        fixture_data = self.load_fixture("/inventory/interfaces")
        expected_count = len(fixture_data)

        actual_count = MACAddress.objects.count()
        self.assertEqual(
            actual_count,
            expected_count,
            f"Expected {expected_count} MAC addresses, found {actual_count}",
        )

    def test_mac_address_format_colon_two_uppercase(self):
        """
        Verify MAC addresses are stored in colon-separated two-digit uppercase format.

        The transform map template applies mac_to_format(frmt="MAC_COLON_TWO") | upper.
        Example: d4a0.2a06.6604 -> D4:A0:2A:06:66:04
        """
        # Pick the first Cisco interface that has an explicit mac
        cisco_sn = "FDO1552Y0SM"
        device = Device.objects.get(serial=cisco_sn)
        # intName="Gi1/0/4" → nameOriginal="GigabitEthernet1/0/4"; mac="d4a0.2a06.6604"
        iface = Interface.objects.get(device=device, name="GigabitEthernet1/0/4")
        mac_obj = MACAddress.objects.get(
            assigned_object_id=iface.pk,
            assigned_object_type__model="interface",
        )
        self.assertEqual(
            str(mac_obj.mac_address).upper(),
            "D4:A0:2A:06:66:04",
            "MAC address should be formatted as D4:A0:2A:06:66:04, got "
            + str(mac_obj.mac_address),
        )

    def test_mac_address_null_falls_back_to_placeholder(self):
        """
        Verify interfaces with mac=null get the placeholder MAC 00:00:00:00:00:01.

        Lo0 / Lo58 on the Cisco device have mac=null in the fixture; their
        nameOriginal values are Loopback0 / Loopback58.
        The template: {% if object.mac %}...{% else %}{{ "00:00:00:00:00:01" ... }}{% endif %}
        """
        cisco_sn = "FDO1552Y0SM"
        device = Device.objects.get(serial=cisco_sn)

        # intName="Lo0" → nameOriginal="Loopback0"; intName="Lo58" → nameOriginal="Loopback58"
        for loopback in ("Loopback0", "Loopback58"):
            iface = Interface.objects.get(device=device, name=loopback)
            mac_obj = MACAddress.objects.get(
                assigned_object_id=iface.pk,
                assigned_object_type__model="interface",
            )
            self.assertEqual(
                str(mac_obj.mac_address).upper(),
                "00:00:00:00:00:01",
                f"{loopback} with null mac should have placeholder MAC, "
                f"got {mac_obj.mac_address}",
            )

    def test_mac_address_assigned_to_correct_interface(self):
        """Verify each MACAddress is assigned to the interface that owns it."""
        fixture_data = self.load_fixture("/inventory/interfaces")
        candidates = [d for d in fixture_data if d.get("mac") and d.get("nameOriginal")]
        self.assertGreater(
            len(candidates),
            0,
            "interfaces fixture must have at least one entry with both mac and nameOriginal set",
        )
        for iface_data in candidates:
            device = Device.objects.get(serial=iface_data["sn"])
            name = iface_data["nameOriginal"]
            iface = Interface.objects.get(device=device, name=name)
            self.assertTrue(
                MACAddress.objects.filter(
                    assigned_object_id=iface.pk,
                    assigned_object_type__model="interface",
                ).exists(),
                f"Interface '{name}' should have an assigned MACAddress",
            )

    # ==================== VRF Tests ====================

    def test_vrfs_created(self):
        """Verify unique VRF names from fixture are created as VRF records."""
        fixture_data = self.load_fixture("/technology/routing/vrf/detail")
        expected_names = {d["vrf"] for d in fixture_data}
        expected_count = len(expected_names)

        actual_count = VRF.objects.count()
        self.assertEqual(
            actual_count,
            expected_count,
            f"Expected {expected_count} VRFs, found {actual_count}",
        )

    def test_vrf_names_match_fixture(self):
        """Verify VRF.name is set directly from the vrf field."""
        fixture_data = self.load_fixture("/technology/routing/vrf/detail")
        self.assertGreater(len(fixture_data), 0, "vrf fixture must be non-empty")
        for vrf_data in fixture_data:
            self.assertTrue(
                VRF.objects.filter(name=vrf_data["vrf"]).exists(),
                f"VRF '{vrf_data['vrf']}' missing from NetBox",
            )

    def test_vrf_rd_mapped(self):
        """
        Verify VRF.rd is None when the fixture rd field is null.

        Transform map template: source_field=rd, template="" (pass-through).
        """
        fixture_data = self.load_fixture("/technology/routing/vrf/detail")
        null_rd_entries = [d for d in fixture_data if d.get("rd") is None]
        self.assertGreater(
            len(null_rd_entries),
            0,
            "vrf fixture must contain at least one entry with rd=null",
        )
        for vrf_data in null_rd_entries:
            vrf_obj = VRF.objects.get(name=vrf_data["vrf"])
            self.assertIsNone(
                vrf_obj.rd,
                f"VRF '{vrf_data['vrf']}' rd should be None (fixture rd is null)",
            )

    def test_vrf_rd_non_null_value_stored(self):
        """
        Verify VRF.rd is set to the fixture rd value when rd is not null.

        The fixture 'with-rd' VRF has rd='65000:100'.
        """
        vrf_obj = VRF.objects.get(name="with-rd")
        self.assertEqual(
            vrf_obj.rd,
            "65000:100",
            "VRF 'with-rd' rd should be '65000:100', got '" + str(vrf_obj.rd) + "'",
        )

    # ==================== VLAN Tests ====================

    def test_vlans_created(self):
        """Verify every fixture VLAN entry creates one VLAN record in NetBox."""
        fixture_data = self.load_fixture("/technology/vlans/site-summary")
        expected_count = len(fixture_data)

        actual_count = VLAN.objects.count()
        self.assertEqual(
            actual_count,
            expected_count,
            f"Expected {expected_count} VLANs, found {actual_count}",
        )

    def test_vlan_vid_matches_fixture(self):
        """Verify VLAN.vid is set from the vlanId field."""
        fixture_data = self.load_fixture("/technology/vlans/site-summary")
        self.assertGreater(len(fixture_data), 0, "vlans fixture must be non-empty")
        for vlan_data in fixture_data:
            self.assertTrue(
                VLAN.objects.filter(vid=vlan_data["vlanId"]).exists(),
                f"VLAN with vid={vlan_data['vlanId']} missing from NetBox",
            )

    def test_vlan_name_matches_fixture(self):
        """
        Verify VLAN.name is set from vlanName (truncated to 64 chars).

        The transform map skips setting name when vlanName is 'none' or ''.
        """
        fixture_data = self.load_fixture("/technology/vlans/site-summary")
        named_vlans = [
            d
            for d in fixture_data
            if d.get("vlanName") and d["vlanName"].lower() != "none"
        ]
        self.assertGreater(
            len(named_vlans),
            0,
            "vlans fixture must have at least one entry with a real vlanName",
        )
        for vlan_data in named_vlans:
            expected_name = vlan_data["vlanName"][:64]
            vlan = VLAN.objects.get(vid=vlan_data["vlanId"])
            self.assertEqual(
                vlan.name,
                expected_name,
                f"VLAN {vlan_data['vlanId']} name should be '{expected_name}', "
                f"got '{vlan.name}'",
            )

    def test_vlan_description_mapped(self):
        """
        Verify VLAN.description is set from dscr; empty string when dscr is null.

        Transform map template:
          {% if (object.dscr | lower) != 'none' %}{{ object.dscr or '' }}{% endif %}
        """
        fixture_data = self.load_fixture("/technology/vlans/site-summary")
        self.assertGreater(len(fixture_data), 0, "vlans fixture must be non-empty")
        for vlan_data in fixture_data:
            vlan = VLAN.objects.get(vid=vlan_data["vlanId"])
            dscr = vlan_data.get("dscr")
            if dscr:
                self.assertEqual(
                    vlan.description,
                    dscr,
                    f"VLAN {vlan_data['vlanId']} description should be '{dscr}', "
                    f"got '{vlan.description}'",
                )
            else:
                self.assertEqual(
                    vlan.description,
                    "",
                    f"VLAN {vlan_data['vlanId']} description should be '' when dscr=null",
                )

    def test_vlan_name_string_none_stored_as_empty(self):
        """
        Verify VLAN.name is stored as '\"\"' (empty-looking) when vlanName='none'.

        Transform map template:
          {% if object.vlanName is defined and object.vlanName | lower != 'none' %}
            {{ object.vlanName | string | truncate(64, True) }}
          {% else %}\"\"{% endif %}

        VLAN 4000 in the fixture has vlanName='none'.
        """
        vlan = VLAN.objects.get(vid=4000)
        # The template outputs literal '""' — NetBox stores it as the two-char string
        self.assertNotEqual(
            vlan.name.lower(),
            "none",
            "VLAN 4000 name should not be 'none' — template must replace it",
        )

    def test_vlan_site_relationship(self):
        """Verify every VLAN is linked to the Site matching its siteName."""
        fixture_data = self.load_fixture("/technology/vlans/site-summary")
        self.assertGreater(len(fixture_data), 0, "vlans fixture must be non-empty")
        for vlan_data in fixture_data:
            vlan = VLAN.objects.get(vid=vlan_data["vlanId"])
            self.assertIsNotNone(
                vlan.site,
                f"VLAN {vlan_data['vlanId']} should have a site assigned",
            )
            self.assertEqual(
                vlan.site.name,
                vlan_data["siteName"],
                f"VLAN {vlan_data['vlanId']} should be in site '{vlan_data['siteName']}', "
                f"got '{vlan.site.name}'",
            )

    # ==================== Prefix Tests ====================

    def test_prefixes_created(self):
        """
        Verify the correct number of Prefix records are created.

        The Prefix transform map has coalesce=true on the prefix field, so
        multiple fixture entries sharing the same net value are merged into a
        single record. The expected count is the number of unique net values.

        In the fixture, 10.0.128.0/24 appears 3 times (vrfs '__oob-management',
        'system', 'main'), so 14 entries collapse to 12 unique prefixes.
        """
        fixture_data = self.load_fixture("/technology/networks/managed-networks")
        expected_count = len({d["net"] for d in fixture_data})

        actual_count = Prefix.objects.count()
        self.assertEqual(
            actual_count,
            expected_count,
            f"Expected {expected_count} prefixes (unique nets), found {actual_count}",
        )

    def test_prefix_network_matches_fixture(self):
        """Verify a Prefix record exists for every unique net value in the fixture."""
        fixture_data = self.load_fixture("/technology/networks/managed-networks")
        unique_nets = {d["net"] for d in fixture_data}
        self.assertGreater(
            len(unique_nets), 0, "managed-networks fixture must be non-empty"
        )
        for net in unique_nets:
            self.assertTrue(
                Prefix.objects.filter(prefix=net).exists(),
                f"Prefix '{net}' missing from NetBox",
            )

    def test_prefix_site_scope_relationship(self):
        """
        Verify Prefix.scope points to the Site matching its siteName.

        All fixture entries share the same siteName so every prefix must
        have that site as its scope. Duplicated nets are queried with
        filter() to avoid MultipleObjectsReturned.
        """
        fixture_data = self.load_fixture("/technology/networks/managed-networks")
        self.assertGreater(
            len(fixture_data), 0, "managed-networks fixture must be non-empty"
        )
        # Use unique nets only — duplicates coalesce to one record
        seen = set()
        for prefix_data in fixture_data:
            net = prefix_data["net"]
            if net in seen:
                continue
            seen.add(net)

            prefix = Prefix.objects.get(prefix=net)
            self.assertIsNotNone(
                prefix.scope,
                f"Prefix '{net}' should have a scope (site) assigned",
            )
            self.assertEqual(
                prefix.scope.name,
                prefix_data["siteName"],
                f"Prefix '{net}' scope should be site '{prefix_data['siteName']}', "
                f"got '{prefix.scope.name}'",
            )

    def test_prefix_scope_type_is_dcim_site(self):
        """
        Verify Prefix.scope_type ContentType is dcim.site for every prefix.

        Transform map relationship_map:
          template: contenttypes.ContentType.objects.get(app_label="dcim", model="site").pk
        All fixture prefixes have a siteName, so every prefix must have scope_type=dcim.site.
        """
        site_ct = ContentType.objects.get(app_label="dcim", model="site")
        self.assertGreater(Prefix.objects.count(), 0, "at least one Prefix must exist")
        for prefix in Prefix.objects.all():
            self.assertEqual(
                prefix.scope_type,
                site_ct,
                f"Prefix '{prefix.prefix}' scope_type should be dcim.site, "
                f"got '{prefix.scope_type}'",
            )

    def test_prefix_vrf_assigned_for_known_vrfs(self):
        """
        Verify Prefix.vrf is set when the vrf name was synced as a VRF record,
        and is None when the vrf value is in the global list or was not synced.

        The transform map: VRF.objects.filter(name=vrf).first() — returns None
        when the VRF was not synced (e.g. '__oob-management', 'main', 'TestVrf'
        are in the prefix fixture but absent from the VRF fixture).

        For duplicated nets (10.0.128.0/24) only the first unique occurrence is
        checked since coalesce produces a single Prefix record.
        """
        global_vrfs = {"", "system", "0", "global"}
        synced_vrf_names = set(VRF.objects.values_list("name", flat=True))

        fixture_data = self.load_fixture("/technology/networks/managed-networks")
        unique_entries = list({d["net"]: d for d in fixture_data}.values())

        null_vrf_entries = [
            d
            for d in unique_entries
            if str(d.get("vrf", "")) in global_vrfs
            or str(d.get("vrf", "")) not in synced_vrf_names
        ]
        assigned_vrf_entries = [
            d
            for d in unique_entries
            if str(d.get("vrf", "")) not in global_vrfs
            and str(d.get("vrf", "")) in synced_vrf_names
        ]
        self.assertGreater(
            len(null_vrf_entries),
            0,
            "managed-networks fixture must have at least one prefix with a global/unsynced vrf",
        )
        self.assertGreater(
            len(assigned_vrf_entries),
            0,
            "managed-networks fixture must have at least one prefix with a synced non-global vrf",
        )

        seen = set()
        for prefix_data in fixture_data:
            net = prefix_data["net"]
            if net in seen:
                continue
            seen.add(net)

            vrf_value = str(prefix_data.get("vrf", ""))
            prefix = Prefix.objects.get(prefix=net)

            if vrf_value in global_vrfs or vrf_value not in synced_vrf_names:
                self.assertIsNone(
                    prefix.vrf,
                    f"Prefix '{net}' with vrf='{vrf_value}' "
                    f"should have vrf=None (not synced or global)",
                )
            else:
                self.assertIsNotNone(
                    prefix.vrf,
                    f"Prefix '{net}' with vrf='{vrf_value}' should have a VRF assigned",
                )
                self.assertEqual(
                    prefix.vrf.name,
                    vrf_value,
                    f"Prefix '{net}' should be in VRF '{vrf_value}', "
                    f"got '{prefix.vrf.name}'",
                )

    # ==================== IP Address Tests ====================

    def test_ip_addresses_created(self):
        """
        Verify the correct number of IPAddress records are created.

        _preprocess_ipaddresses skips any IP whose sn+intName key has no entry
        in _readable_int_names (i.e. the interface was not synced). Expected count
        is the number of fixture IPs that have a matching interface entry.
        """
        fixture_data = self.load_fixture("/technology/addressing/managed-ip/ipv4")
        iface_fixture = self.load_fixture("/inventory/interfaces")
        readable = {
            f"{i['sn']}_{i['intName']}": i["nameOriginal"] for i in iface_fixture
        }
        expected_count = sum(
            1 for ip in fixture_data if readable.get(f"{ip['sn']}_{ip['intName']}")
        )
        self.assertGreater(
            expected_count, 0, "at least one IP must have a matching interface"
        )

        actual_count = IPAddress.objects.count()
        self.assertEqual(
            actual_count,
            expected_count,
            f"Expected {expected_count} IP addresses, found {actual_count}",
        )

    def test_ip_address_format_includes_prefix_length(self):
        """
        Verify IPAddress.address is stored as ip/mask, taken from net field.

        Transform map template:
          {% if object.net %}{% set MASK = object.net.split('/')[1] %}
          {% else %}{% set MASK = 32 %}{% endif %}{{ object.ip }}/{{ MASK }}

        Only IPs that have a matching interface entry are synced; unmatched ones
        are skipped by _preprocess_ipaddresses and must not be checked here.
        """
        fixture_data = self.load_fixture("/technology/addressing/managed-ip/ipv4")
        iface_fixture = self.load_fixture("/inventory/interfaces")
        readable = {
            f"{i['sn']}_{i['intName']}": i["nameOriginal"] for i in iface_fixture
        }
        matched = [d for d in fixture_data if readable.get(f"{d['sn']}_{d['intName']}")]
        self.assertGreater(
            len(matched), 0, "ipv4 fixture must have at least one matched IP"
        )

        for ip_data in matched:
            mask = ip_data["net"].split("/")[1] if ip_data.get("net") else "32"
            expected_address = f"{ip_data['ip']}/{mask}"
            self.assertTrue(
                IPAddress.objects.filter(address=expected_address).exists(),
                f"IPAddress '{expected_address}' missing from NetBox",
            )

    def test_ip_address_assigned_to_correct_interface(self):
        """
        Verify each IPAddress is assigned to the Interface matched by
        device serial + nameOriginal.
        """
        fixture_data = self.load_fixture("/technology/addressing/managed-ip/ipv4")
        iface_fixture = self.load_fixture("/inventory/interfaces")

        # Build sn+intName -> nameOriginal map (mirrors _readable_int_names)
        readable = {
            f"{i['sn']}_{i['intName']}": i["nameOriginal"] for i in iface_fixture
        }

        candidates = [
            d for d in fixture_data if readable.get(f"{d['sn']}_{d['intName']}")
        ]
        self.assertGreater(
            len(candidates),
            0,
            "ipv4 fixture must have at least one IP whose sn+intName matches an interface",
        )
        for ip_data in candidates:
            name_original = readable[f"{ip_data['sn']}_{ip_data['intName']}"]
            mask = ip_data["net"].split("/")[1] if ip_data.get("net") else "32"
            ip_obj = IPAddress.objects.get(address=f"{ip_data['ip']}/{mask}")

            expected_iface = Interface.objects.get(
                device__serial=ip_data["sn"], name=name_original
            )
            self.assertEqual(
                ip_obj.assigned_object_id,
                expected_iface.pk,
                f"IPAddress '{ip_data['ip']}' should be assigned to interface "
                f"'{name_original}', got pk {ip_obj.assigned_object_id}",
            )

    def test_ip_address_assigned_object_type_is_interface(self):
        """Verify all IPAddresses have assigned_object_type pointing at dcim.interface."""
        interface_ct = ContentType.objects.get(app_label="dcim", model="interface")
        non_interface = IPAddress.objects.exclude(assigned_object_type=interface_ct)
        self.assertEqual(
            non_interface.count(),
            0,
            f"{non_interface.count()} IPAddress records have wrong assigned_object_type",
        )

    def test_ip_address_vrf_assigned_for_non_global_vrfs(self):
        """
        Verify VRF is set for IPs whose vrf field is not in ['', 'system', '0', 'global'].

        Transform map template (data/transform_map.json):
          {% if object.vrf is defined and object.vrf | string not in ["", "system", "0", "global"] %}
            {{ ipam.VRF.objects.filter(name=object.vrf).first().pk }}
          {% else %}None{% endif %}

        The Arista fixture IPs carry named VRFs (default, tech, core, etc.).
        The Cisco IPs have vrf='' so they must have vrf=None.
        """
        fixture_data = self.load_fixture("/technology/addressing/managed-ip/ipv4")
        iface_fixture = self.load_fixture("/inventory/interfaces")
        readable = {
            f"{i['sn']}_{i['intName']}": i["nameOriginal"] for i in iface_fixture
        }
        matched = [d for d in fixture_data if readable.get(f"{d['sn']}_{d['intName']}")]
        global_vrfs = {"", "system", "0", "global"}

        global_vrf_entries = [
            d for d in matched if str(d.get("vrf", "")) in global_vrfs
        ]
        named_vrf_entries = [
            d for d in matched if str(d.get("vrf", "")) not in global_vrfs
        ]
        self.assertGreater(
            len(global_vrf_entries),
            0,
            "ipv4 fixture must have at least one matched IP with a global vrf (empty/system/0/global)",
        )
        self.assertGreater(
            len(named_vrf_entries),
            0,
            "ipv4 fixture must have at least one matched IP with a non-global named vrf",
        )

        for ip_data in matched:
            mask = ip_data["net"].split("/")[1] if ip_data.get("net") else "32"
            ip_obj = IPAddress.objects.get(address=f"{ip_data['ip']}/{mask}")
            vrf_value = str(ip_data.get("vrf", ""))

            if vrf_value in global_vrfs:
                self.assertIsNone(
                    ip_obj.vrf,
                    f"IPAddress '{ip_data['ip']}' with vrf='{vrf_value}' should have vrf=None",
                )
            else:
                self.assertIsNotNone(
                    ip_obj.vrf,
                    f"IPAddress '{ip_data['ip']}' with vrf='{vrf_value}' should have a VRF assigned",
                )
                self.assertEqual(
                    ip_obj.vrf.name,
                    vrf_value,
                    f"IPAddress '{ip_data['ip']}' should be in VRF '{vrf_value}', "
                    f"got '{ip_obj.vrf.name}'",
                )

    def test_ip_skipped_when_no_matching_interface(self):
        """
        Verify _preprocess_ipaddresses skips IPs whose intName has no entry
        in _readable_int_names.

        An IP entry whose sn+intName does not map to any synced interface must
        NOT appear as an IPAddress record.
        """
        fixture_data = self.load_fixture("/technology/addressing/managed-ip/ipv4")
        iface_fixture = self.load_fixture("/inventory/interfaces")

        readable = {
            f"{i['sn']}_{i['intName']}": i["nameOriginal"] for i in iface_fixture
        }

        matched = [d for d in fixture_data if readable.get(f"{d['sn']}_{d['intName']}")]
        unmatched = [
            d for d in fixture_data if not readable.get(f"{d['sn']}_{d['intName']}")
        ]
        self.assertGreater(
            len(matched),
            0,
            "ipv4 fixture must have at least one IP whose sn+intName matches an interface",
        )
        self.assertGreater(
            len(unmatched),
            0,
            "ipv4 fixture must have at least one IP whose sn+intName has NO matching interface "
            "(to exercise the skip branch)",
        )

        for ip_data in fixture_data:
            key = f"{ip_data['sn']}_{ip_data['intName']}"
            mask = ip_data["net"].split("/")[1] if ip_data.get("net") else "32"
            address = f"{ip_data['ip']}/{mask}"

            if readable.get(key):
                self.assertTrue(
                    IPAddress.objects.filter(address=address).exists(),
                    f"IPAddress '{address}' (key '{key}' matched) should exist",
                )
            else:
                self.assertFalse(
                    IPAddress.objects.filter(address=address).exists(),
                    f"IPAddress '{address}' (key '{key}' unmatched) should have been skipped",
                )

    def test_primary_ip_flag_set_for_login_ip(self):
        """
        Verify _preprocess_ipaddresses is_primary=True causes Device.primary_ip4
        to be set to the IP matching the device's login IP.

        _preprocess_devices resolves the login IP as:
            device.get("loginIp") or device.get("loginIpv4")

        From the fixtures:
          - Cisco  FDO1552Y0SM  loginIpv4=10.0.128.6  → Device.primary_ip4 = 10.0.128.6/24
          - Arista SSJ17151159  loginIp=10.0.128.51   → Device.primary_ip4 = 10.0.128.51/24
        """
        devices_fixture = self.load_fixture("/inventory/devices")
        candidates = [
            d for d in devices_fixture if d.get("loginIp") or d.get("loginIpv4")
        ]
        self.assertGreater(
            len(candidates),
            0,
            "devices fixture must have at least one entry with loginIp or loginIpv4 set",
        )
        for device_data in candidates:
            login_ip = device_data.get("loginIp") or device_data["loginIpv4"]
            device = Device.objects.get(serial=device_data["sn"])
            self.assertIsNotNone(
                device.primary_ip4,
                f"Device '{device_data['hostname']}' should have primary_ip4 set",
            )
            self.assertEqual(
                str(device.primary_ip4.address.ip),
                login_ip,
                f"Device '{device_data['hostname']}' primary_ip4 should be "
                f"'{login_ip}', got '{device.primary_ip4.address.ip}'",
            )

    def test_non_primary_ips_not_set_as_device_primary(self):
        """
        Verify that IPs which do not match a device's login IP are never
        assigned as Device.primary_ip4.

        _preprocess_devices resolves the login IP as:
            device.get("loginIp") or device.get("loginIpv4")
        """
        devices_fixture = self.load_fixture("/inventory/devices")
        with_login = [
            d for d in devices_fixture if d.get("loginIp") or d.get("loginIpv4")
        ]
        without_login = [
            d
            for d in devices_fixture
            if not d.get("loginIp") and not d.get("loginIpv4")
        ]
        self.assertGreater(
            len(with_login),
            0,
            "devices fixture must have at least one device with a login IP",
        )
        self.assertGreater(
            len(without_login),
            0,
            "devices fixture must have at least one device without a login IP "
            "(to exercise the primary_ip4=None branch)",
        )

        for device_data in devices_fixture:
            login_ip = device_data.get("loginIp") or device_data.get("loginIpv4")
            device = Device.objects.get(serial=device_data["sn"])

            if login_ip:
                self.assertEqual(
                    str(device.primary_ip4.address.ip),
                    login_ip,
                    f"Device '{device_data['hostname']}' primary_ip4 must be "
                    f"'{login_ip}', got '{device.primary_ip4.address.ip}'",
                )
            else:
                self.assertIsNone(
                    device.primary_ip4,
                    f"Device '{device_data['hostname']}' has no login IP "
                    f"so primary_ip4 should be None",
                )

    def test_ip_address_mask_defaults_to_32_when_net_null(self):
        """
        Verify IPAddress mask defaults to /32 when net field is null/missing.

        Transform map template:
          {% if object.net %}{% set MASK = object.net.split('/')[1] %}
          {% else %}{% set MASK = 32 %}{% endif %}{{ object.ip }}/{{ MASK }}
        """
        # Add a fixture entry with net=null to cover this branch
        fixture_data = self.load_fixture("/technology/addressing/managed-ip/ipv4")
        no_net_entries = [d for d in fixture_data if not d.get("net")]
        self.assertGreater(
            len(no_net_entries),
            0,
            "ipv4 fixture must contain at least one entry with net=null "
            "to exercise the /32 default mask branch",
        )
        for ip_data in no_net_entries:
            expected = f"{ip_data['ip']}/32"
            self.assertTrue(
                IPAddress.objects.filter(address=expected).exists(),
                f"IPAddress '{expected}' with /32 default mask not found",
            )

    # ==================== Statistics Helpers ====================

    def _make_fake_changes(self, ingestion, changes_per_model=2):
        """
        Build a list of fake BranchObjectChange mocks and a matching Counter of
        expected per-model totals, derived from the enabled models in
        ingestion.sync.parameters.  No real branch schema is required.
        """
        enabled_models = [
            m for m, v in ingestion.sync.parameters.items() if v is True and "." in m
        ]
        fake_changes = []
        expected_counts: Counter = Counter()
        for model_string in enabled_models:
            app_label, model_name = model_string.split(".", 1)
            for _ in range(changes_per_model):
                mock_ct = MagicMock()
                mock_ct.app_label = app_label
                mock_ct.model = model_name
                mock_ct.natural_key.return_value = (app_label, model_name)
                mock_ct.model_class.return_value = ContentType.objects.get(
                    app_label=app_label, model=model_name
                ).model_class()
                fc = MagicMock(spec=BranchObjectChange)
                fc.changed_object_type = mock_ct
                fc.apply.return_value = None
                fc.request_id = "test-request-id"
                fc.user = ingestion.sync.user
                fake_changes.append(fc)
            expected_counts[model_string] += changes_per_model
        return fake_changes, expected_counts

    def _make_fake_qs(self, fake_changes):
        """
        Wrap *fake_changes* in a mock queryset whose .order_by() chain satisfies
        the calls merge_branch makes:
          changes = qs.order_by("time")
          changes.count(), changes.values_list(...), for change in changes
        """
        vl_data = [
            (fc.changed_object_type.app_label, fc.changed_object_type.model)
            for fc in fake_changes
        ]
        ordered_qs = MagicMock()
        ordered_qs.count.return_value = len(fake_changes)
        ordered_qs.values_list.return_value = vl_data
        ordered_qs.__iter__ = MagicMock(return_value=iter(fake_changes))
        fake_qs = MagicMock()
        fake_qs.order_by.return_value = ordered_qs
        return fake_qs

    def _run_fake_merge(self, ingestion, branch, merge_logger, fake_qs=None):
        """
        Call ingestion.sync_merge() with all branch/DB interactions mocked out.
        The caller is responsible for setting ingestion.sync.logger beforehand.
        Pass *fake_qs* to override the default queryset (built from 2 changes
        per model).
        """

        def fake_get_job_logs(job):
            return merge_logger.log_data

        if fake_qs is None:
            fake_changes, _ = self._make_fake_changes(ingestion)
            fake_qs = self._make_fake_qs(fake_changes)

        with (
            patch.object(branch, "get_unmerged_changes", return_value=fake_qs),
            patch.object(
                type(branch),
                "ready",
                new_callable=lambda: property(lambda self: True),
            ),
            patch.object(ingestion, "get_job_logs", fake_get_job_logs),
            patch("netbox_branching.models.Branch.objects") as mock_branch_mgr,
            patch("ipfabric_netbox.utilities.merge.BranchEvent.objects") as mock_be,
            patch("ipfabric_netbox.utilities.merge.post_merge"),
            patch.object(branch, "save"),
            patch("ipfabric_netbox.utilities.merge.record_applied_change"),
            patch(
                "ipfabric_netbox.utilities.merge.get_merge_strategy"
            ) as mock_strategy,
            patch("ipfabric_netbox.utilities.merge.connection"),
        ):
            mock_branch_mgr.filter.return_value.update.return_value = None
            mock_be.create.return_value = None
            mock_strategy.return_value.return_value._clean = MagicMock()
            ingestion.sync_merge()

    # ==================== Statistics Tests ====================

    def test_sync_statistics_populated_after_sync(self):
        """
        Verify sync stage statistics are non-empty after sync and each value is a
        valid percentage (0–100).  We read directly from the in-memory logger
        that sync() attached to self.sync so the test is not sensitive to
        cache expiry.
        """
        raw_stats = self.sync.logger.log_data.get("statistics", {})
        self.assertGreater(
            len(raw_stats), 0, "sync stage statistics must be non-empty after sync"
        )
        for model, counts in raw_stats.items():
            total = counts["total"]
            current = counts["current"]
            self.assertGreater(total, 0, f"{model}: total must be > 0")
            self.assertGreaterEqual(current, 0, f"{model}: current must be >= 0")
            self.assertLessEqual(current, total, f"{model}: current must be <= total")

    def test_merge_statistics_empty_before_merge(self):
        """
        Verify statistics for merge stage is empty when no merge job has run yet.
        The ingestion created in setUpTestData has no merge_job.
        """
        data = self.ingestion.get_statistics(stage="merge")
        self.assertEqual(
            data["statistics"],
            {},
            "merge stage statistics must be empty when merge_job is not set",
        )

    def test_merge_statistics_populated_after_merge(self):
        """
        Run sync_merge() with all branch/DB calls mocked, verify that
        merge stage statistics are non-empty and every model reaches 100 %.
        """
        ingestion = self.ingestion
        branch = ingestion.branch
        self.assertIsNotNone(branch, "ingestion must have a branch for merge test")

        merge_logger = SyncLogging(job=99999)
        ingestion.sync.logger = merge_logger

        self._run_fake_merge(ingestion, branch, merge_logger)

        raw_merge = merge_logger.log_data.get("statistics", {})
        self.assertGreater(
            len(raw_merge),
            0,
            "merge stage statistics must be non-empty after sync_merge()",
        )
        for model, counts in raw_merge.items():
            self.assertEqual(
                counts["current"],
                counts["total"],
                f"{model}: current should equal total after full merge, got {counts}",
            )

    def test_merge_statistics_totals_match_branch_changes(self):
        """
        Verify raw merge stage statistics totals match the per-model change counts
        passed to merge_branch via get_unmerged_changes().
        """
        ingestion = self.ingestion
        branch = ingestion.branch
        self.assertIsNotNone(branch, "ingestion must have a branch")

        fake_changes, expected_counts = self._make_fake_changes(
            ingestion, changes_per_model=3
        )
        fake_qs = self._make_fake_qs(fake_changes)

        merge_logger = SyncLogging(job=99998)
        ingestion.sync.logger = merge_logger

        self._run_fake_merge(ingestion, branch, merge_logger, fake_qs=fake_qs)

        raw_merge = merge_logger.log_data.get("statistics", {})
        self.assertGreater(
            len(raw_merge), 0, "merge stage statistics must be non-empty"
        )
        for model_string, expected_total in expected_counts.items():
            self.assertIn(
                model_string,
                raw_merge,
                f"{model_string} missing from merge stage statistics",
            )
            self.assertEqual(
                raw_merge[model_string]["total"],
                expected_total,
                f"{model_string}: expected total={expected_total}, got {raw_merge[model_string]['total']}",
            )

    # ==================== Utility Methods ====================

    def get_synced_object(self, model_class, **lookup_kwargs):
        """
        Helper to retrieve a synced NetBox object.

        Args:
            model_class: Django model class
            **lookup_kwargs: Lookup parameters

        Returns:
            Model instance or None
        """
        try:
            return model_class.objects.get(**lookup_kwargs)
        except model_class.DoesNotExist:
            return None
        except model_class.MultipleObjectsReturned:
            return model_class.objects.filter(**lookup_kwargs).first()

    # ------------------------------------------------------------------
    # Multi-threading tests
    #
    # All chunk methods run synchronously via _InlineExecutor so the test
    # transaction stays intact; the spy lists prove which routing branch
    # was taken.  Fixture sizes drive the assertions:
    #   • VLANs/Prefixes: 14 records each → 2 chunks → executor path taken
    #   • Devices/IPs:    1 record  each → 1 chunk  → single-thread fast path
    # ------------------------------------------------------------------

    def test_sync_chunk_called_for_multichunk_models(self):
        """
        Models with ≥ 2 records (VLANs: 14, Prefixes: 14, VRFs: 7) are split
        into multiple chunks and dispatched via the ThreadPoolExecutor branch.
        At least one _sync_chunk call must be recorded.
        """
        self.assertTrue(
            self._sync_chunk_calls,
            "_sync_chunk was never called – ThreadPoolExecutor path not exercised",
        )

    def test_inventoryitem_not_dispatched_to_thread_pool(self):
        """
        dcim.inventoryitem is an MPTT model; _requires_single_thread() returns
        True for it, so it must never appear in _sync_chunk call arguments
        regardless of record count.
        """
        all_dispatched = [ms for chunk in self._sync_chunk_calls for ms in chunk]
        self.assertNotIn(
            "dcim.inventoryitem",
            all_dispatched,
            "dcim.inventoryitem must not be dispatched to the thread pool (MPTT model)",
        )

    def test_sync_devices_chunk_called(self):
        """
        The device fixture contains multiple records (regular + stack/VSS
        members).  With thread_count=2 and _MIN_CHUNK_SIZE=1 this produces
        ≥ 2 chunks, so _sync_devices_chunk is dispatched via the executor.
        """
        self.assertTrue(
            self._devices_chunk_calls,
            "_sync_devices_chunk was never called – device ThreadPoolExecutor path not exercised",
        )

    def test_sync_ip_addresses_chunk_called(self):
        """
        The fixture contains multiple IP-address records.  With thread_count=2
        and _MIN_CHUNK_SIZE=1 this produces ≥ 2 chunks, so
        _sync_ipaddresses_chunk is dispatched via the executor.
        """
        self.assertTrue(
            self._ip_chunk_calls,
            "_sync_ipaddresses_chunk was never called – IP address ThreadPoolExecutor path not exercised",
        )


@tag("integration")
class IPFabricSyncUpdatePathTests(_IPFabricSyncMixin, TestCase):
    """
    Integration tests for sync update paths.

    These tests verify that running a second full sync on an already-populated
    NetBox DB correctly handles updates rather than just creates.

    Test strategy
    -------------
    ``setUpTestData`` runs TWO full syncs back-to-back:

    1. **Create sync** – uses the ``data/create/`` fixtures, identical to what
       ``IPFabricSyncIntegrationTests`` uses.  Populates the DB with the
       initial state (two stacks, VSS, two standalone devices, IPs etc.).
    2. **Update sync** – uses ``data/update/`` fixtures for endpoints that
       changed; for all others it falls back to ``data/create/`` transparently.

    Both syncs run once in ``setUpTestData``; individual test methods simply
    assert the final DB state — no per-test sync calls needed.
    """

    update_fixtures_dir = Path(__file__).parent / "data" / "update"

    @classmethod
    def setUpTestData(cls):
        """
        Run TWO full syncs:
        1. Create sync  – ``data/create/`` fixtures (same as IPFabricSyncIntegrationTests).
        2. Update sync  – ``data/update/`` fixtures with fallback to ``data/create/``.
        Individual tests then assert the resulting DB state.
        """
        super().setUpTestData()
        cls._do_sync_setup()

        # Run the second (update) sync
        # Use the same _InlineExecutor + no-op patches as the first sync so
        # that thread_count=2 does not cause transaction-isolation failures.
        cls.sync.refresh_from_db()
        with (
            patch(
                "ipfabric_netbox.utilities.ipfutils.ThreadPoolExecutor",
                _InlineExecutor,
            ),
            patch(
                "ipfabric_netbox.utilities.ipfutils.close_old_connections",
                lambda: None,
            ),
            patch.object(_django_connections, "close_all", lambda: None),
            cls._mock_update_ipfabric_api(),
            cls._mock_branch_model(),
            cls._mock_active_branch(),
            cls._mock_sync_runner(),
        ):
            cls.sync.sync(job=None)

    @classmethod
    def _mock_update_ipfabric_api(cls):
        """
        Mock IPFClient so the update sync is served from ``data/update/``,
        falling back to ``data/create/`` for any endpoint that has no override file.
        """

        def mock_fetch_all(self_ipf, url, snapshot_id=None, filters=None, **kwargs):
            endpoint_path = url if url.startswith("/") else f"/{url}"
            filename = endpoint_path.strip("/").replace("/", "__") + ".json"
            override = cls.update_fixtures_dir / filename
            if override.exists():
                with open(override, "r") as fh:
                    return json.load(fh)
            try:
                return cls.load_fixture(endpoint_path)
            except FileNotFoundError:
                return []

        def mock_init(self_ipf, *args, **kwargs):
            self_ipf._client = MagicMock()
            self_ipf._client.headers = {"user-agent": "test-ipfabric-client"}

        return patch.multiple(
            "ipfabric.IPFClient", __init__=mock_init, fetch_all=mock_fetch_all
        )

    def test_vc_master_change(self):
        """
        Verify that FDO1552Y0SM, which was master of ``hwl-r1-33-stack-3750``,
        is now master of ``new-stack-master`` after the update sync.

        The old VC must have its master cleared (``sync_device`` branch:
        ``target_vc_obj and master_vc != target_vc_obj``).
        """
        # Old VC must have lost its master
        old_vc = VirtualChassis.objects.get(name="hwl-r1-33-stack-3750")
        self.assertIsNone(
            old_vc.master,
            "After update sync the old VC 'hwl-r1-33-stack-3750' must have "
            "master=None because sync_device cleared it when detecting VC mismatch.",
        )

        # New VC must exist and have FDO1552Y0SM as master
        new_vc = VirtualChassis.objects.filter(name="new-stack-master").first()
        self.assertIsNotNone(
            new_vc,
            "VirtualChassis 'new-stack-master' should have been created in the update sync.",
        )
        self.assertIsNotNone(
            new_vc.master,
            "VirtualChassis 'new-stack-master' should have a master device assigned.",
        )
        self.assertEqual(
            new_vc.master.serial,
            "FDO1552Y0SM",
            "VirtualChassis 'new-stack-master' master should be device FDO1552Y0SM.",
        )

        # The master device's virtual_chassis FK must point to the new VC
        master_device = Device.objects.get(serial="FDO1552Y0SM")
        self.assertIsNotNone(master_device.virtual_chassis)
        self.assertEqual(
            master_device.virtual_chassis.name,
            "new-stack-master",
            "Device FDO1552Y0SM virtual_chassis must be updated to 'new-stack-master'.",
        )

    def test_vc_master_removal(self):
        """
        Verify that TST-STK2-001, which was the sole master of
        ``hwl-r2-stk-old`` in the create sync, has its VC membership
        removed in the update sync (its entry is absent from the update
        stack-members fixture).

        The VC must have its master cleared and the device's
        ``virtual_chassis`` FK must be None.
        """
        # VC must have lost its master
        vc = VirtualChassis.objects.get(name="hwl-r2-stk-old")
        self.assertIsNone(
            vc.master,
            "After update sync the VC 'hwl-r2-stk-old' must have master=None "
            "because TST-STK2-001 was removed from the stack members fixture.",
        )

        # The device itself must be standalone
        device = Device.objects.get(serial="TST-STK2-001")
        self.assertIsNone(
            device.virtual_chassis,
            "Device TST-STK2-001 should have virtual_chassis=None after removal from stack.",
        )

        # Device name must revert to plain hostname (no member-position suffix)
        self.assertEqual(
            device.name,
            "hwl-r2-stk-old",
            "Device TST-STK2-001 name should revert to 'hwl-r2-stk-old' "
            "(no longer suffixed with member position).",
        )

    def test_vc_master_unchanged(self):
        """
        Verify that the VSS VirtualChassis (``TEST01-CS-01``) whose data is
        identical between the create and update fixtures is not modified by
        the update sync.
        """
        vc = VirtualChassis.objects.get(name="TEST01-CS-01")
        self.assertIsNotNone(
            vc.master,
            "VirtualChassis 'TEST01-CS-01' must still have a master after update sync.",
        )
        self.assertEqual(
            vc.master.serial,
            "FJK8901P1AD",
            "VirtualChassis 'TEST01-CS-01' master must remain FJK8901P1AD (no change).",
        )

    def test_primary_ip_reassignment(self):
        """
        Verify that when ``loginIp`` values are swapped between FDO1552Y0SM
        and SSJ17151159 in the update fixtures, ``sync_ipaddress`` correctly
        transfers ``primary_ip4`` ownership on both devices.
        """
        cisco = Device.objects.get(serial="FDO1552Y0SM")
        arista = Device.objects.get(serial="SSJ17151159")

        self.assertIsNotNone(cisco.primary_ip4, "FDO1552Y0SM must have a primary_ip4")
        self.assertEqual(
            str(cisco.primary_ip4.address.ip),
            "10.0.128.51",
            "FDO1552Y0SM primary_ip4 must now be 10.0.128.51 (previously Arista's).",
        )

        self.assertIsNotNone(arista.primary_ip4, "SSJ17151159 must have a primary_ip4")
        self.assertEqual(
            str(arista.primary_ip4.address.ip),
            "10.0.128.6",
            "SSJ17151159 primary_ip4 must now be 10.0.128.6 (previously Cisco's).",
        )

    def test_primary_ip_removal(self):
        """
        Verify that ``Device.primary_ip4`` is cleared when the device's
        ``loginIp`` is removed from the source data.

        Implementation
        --------------
        Migration 0034 adds a ``primary_ip4`` relationship field to every
        Device Transform Map with a Jinja2 template that resolves the login
        IP **among the device's own interface-assignments**.  When
        ``loginIp``/``loginIpv4`` is absent the template returns ``None``,
        which propagates through ``build_relationships`` →
        ``defaults["primary_ip4"] = None`` → ``update_or_create_instance``
        clears ``Device.primary_ip4`` during ``sync_devices``.

        Scenario: FJK8901P1AD had ``loginIpv4="10.128.0.3"`` in the create
        fixtures (primary_ip4 set by ``sync_ipaddress`` afterwards).  The
        update fixtures set ``loginIpv4=null``, so the template returns
        ``None`` and the field is cleared during the second sync.
        """
        device = Device.objects.get(serial="FJK8901P1AD")
        self.assertIsNone(
            device.primary_ip4,
            "FJK8901P1AD primary_ip4 should be cleared when loginIp is removed "
            "from source data, but it is still set to "
            f"{device.primary_ip4.address if device.primary_ip4 else None}.",
        )

    def test_primary_ip_stolen_from_donor_device(self):
        """
        Verify that ``sync_ipaddress`` clears ``primary_ip4`` on the device
        that currently owns an IP when another device claims it as its login
        IP — the "other_device.primary_ip4 = None / save()" code path.

        Why this path is reachable here but not in the plain IP-swap test
        ----------------------------------------------------------------
        The Device Transform Map template (migration 0034) resolves
        ``primary_ip4`` by looking for the login IP **among the device's own
        interface-assignments in the DB**.  ``sync_devices`` runs before
        ``sync_ip_addresses``, so at Device-sync time the IPAddress objects
        still point to the interfaces created by the previous sync.

        In the IP-swap scenario (FDO1552Y0SM ↔ SSJ17151159) *both* devices
        change their ``loginIp``; so the template cannot find the new IP on
        either device's existing interfaces and sets both ``primary_ip4``
        values to ``None`` during ``sync_devices``.  By the time
        ``sync_ipaddress`` runs there is no stale holder to clear.

        Here, ``TST-IP-DONOR`` keeps ``loginIp = 198.51.100.1`` unchanged so
        the template finds the IP on its own interface and keeps
        ``primary_ip4`` set.  ``TST0000001`` gains that same ``loginIp`` with
        the IP moved to its interface in the update managed-IP fixture.  When
        ``sync_ipaddress`` processes the IP as ``is_primary=True`` for
        ``TST0000001`` it finds ``TST-IP-DONOR`` still holding it and executes
        the previously-unreachable clearing block.
        """
        donor = Device.objects.get(serial="TST-IP-DONOR")
        self.assertIsNone(
            donor.primary_ip4,
            "TST-IP-DONOR.primary_ip4 must be cleared by sync_ipaddress when "
            "TST0000001 claims 198.51.100.1 as its login IP — the "
            "other_device.primary_ip4 = None code path was not reached.",
        )

        mgmt = Device.objects.get(serial="TST0000001")
        self.assertIsNotNone(
            mgmt.primary_ip4,
            "TST0000001 must have primary_ip4 set after claiming 198.51.100.1.",
        )
        self.assertEqual(
            str(mgmt.primary_ip4.address.ip),
            "198.51.100.1",
            "TST0000001.primary_ip4 must be 198.51.100.1 after the update sync.",
        )

    def test_primary_ip_moved_to_non_primary_device(self):
        """
        Verify that sync_ipaddress clears primary_ip4 on the donor device even
        when the IP is being assigned to the recipient as **non-primary**
        (``is_primary=False``).

        Without the fix the ``is_primary`` guard caused the clearing block to be
        skipped entirely, and NetBox's IPAddress.clean() raised:
        "Cannot reassign IP address while it is designated as the primary IP for
        the parent object."

        Scenario
        --------
        * Create sync: ``TST-PRIM-DONOR`` has ``loginIp=203.0.113.50`` →
          ``primary_ip4`` is set to the 203.0.113.50 IPAddress.
          ``TST-NP-RECIP`` has no ``loginIp``.
        * Update sync: 203.0.113.50 moves to ``TST-NP-RECIP``'s ``Management0``
          in the managed-IP fixture, but ``TST-NP-RECIP`` still has no loginIp
          so ``is_primary=False``.  ``TST-PRIM-DONOR`` retains ``loginIp``
          in the devices fixture so ``sync_devices`` keeps its ``primary_ip4``
          set — the clearing block must therefore run unconditionally.
        """
        donor = Device.objects.get(serial="TST-PRIM-DONOR")
        self.assertIsNone(
            donor.primary_ip4,
            "TST-PRIM-DONOR.primary_ip4 must be cleared when 203.0.113.50 is "
            "reassigned to TST-NP-RECIP (non-primary path).",
        )

        recip = Device.objects.get(serial="TST-NP-RECIP")
        self.assertIsNone(
            recip.primary_ip4,
            "TST-NP-RECIP must have no primary_ip4 (IP was assigned as non-primary).",
        )

        iface = Interface.objects.get(device=recip, name="Management0")
        self.assertEqual(
            str(iface.ip_addresses.get().address.ip),
            "203.0.113.50",
            "203.0.113.50 must be assigned to TST-NP-RECIP's Management0 after the update.",
        )

    def test_interface_tagged_vlans_cleared_on_update(self):
        """
        Verify tagged VLANs are fully replaced (cleared) when vlanId is removed.

        Setup
        -----
        * Create fixture: ``Gi1/0/5`` on ``FDO1552Y0SM`` has ``vlanId=128`` →
          after first sync ``GigabitEthernet1/0/5`` carries VLAN 128.
        * Update fixture: ``Gi1/0/5`` has ``vlanId=null`` →
          after second sync ``tagged_vlans`` must be empty (full-replace).

        This exercises the idempotent ``tagged_vlans.set([])`` path in
        ``sync_interface``.
        """
        device = Device.objects.get(serial="FDO1552Y0SM")
        iface = Interface.objects.get(device=device, name="GigabitEthernet1/0/5")
        self.assertEqual(
            iface.tagged_vlans.count(),
            0,
            "After update sync, GigabitEthernet1/0/5 must have no tagged VLANs "
            "(vlanId cleared to null in update fixture)",
        )

    def test_interface_mode_cleared_when_vlans_removed(self):
        """
        Verify Interface.mode is reset to None when tagged VLANs are removed.

        The mode transform map template returns '' (→ None) when
        ``tagged_vlan_ids`` is empty, so the update sync must clear the mode
        that was set during the create sync on ``GigabitEthernet1/0/5``.
        """
        device = Device.objects.get(serial="FDO1552Y0SM")
        iface = Interface.objects.get(device=device, name="GigabitEthernet1/0/5")
        self.assertIsNone(
            iface.mode,
            "After update sync, GigabitEthernet1/0/5 must have mode=None "
            "(no vlanId in update fixture)",
        )


@tag("integration")
class IPFabricSyncErrorTests(_IPFabricSyncMixin, TestCase):
    """
    Integration tests for sync-phase error handling.

    Uses minimal error-inducing fixtures (data/errors/) that contain:
      - A single device with siteName="NONEXISTENT-SITE" (serial ERR-BAD-SITE-001)
      - One interface and one IP address for that same device

    All other endpoint files fall back to data/create/ so site/VLAN/VRF sync
    still succeeds normally.
    """

    error_fixtures_dir = Path(__file__).parent / "data" / "errors"

    # ------------------------------------------------------------------
    # Override _mock_ipfabric_api to serve error fixtures with create fallback
    # ------------------------------------------------------------------

    @classmethod
    def _mock_ipfabric_api(cls):
        """
        Serve fixture data from data/errors/ first; fall back to data/create/
        for any endpoint that has no override file in data/errors/.
        """

        def mock_fetch_all(self_ipf, url, snapshot_id=None, filters=None, **kwargs):
            endpoint_path = url if url.startswith("/") else f"/{url}"
            filename = endpoint_path.strip("/").replace("/", "__") + ".json"
            override = cls.error_fixtures_dir / filename
            if override.exists():
                with open(override, "r") as fh:
                    return json.load(fh)
            try:
                return cls.load_fixture(endpoint_path)
            except FileNotFoundError:
                return []

        def mock_init(self_ipf, *args, **kwargs):
            self_ipf._client = MagicMock()
            self_ipf._client.headers = {"user-agent": "test-ipfabric-client"}

        return patch.multiple(
            "ipfabric.IPFClient", __init__=mock_init, fetch_all=mock_fetch_all
        )

    # ------------------------------------------------------------------
    # Setup: one full error sync
    # ------------------------------------------------------------------

    @classmethod
    def setUpTestData(cls):
        super().setUpTestData()
        cls._do_sync_setup()
        cls.ingestion = cls.sync.last_ingestion

        # ------------------------------------------------------------------
        # MultipleObjectsReturned scenario: MGMT-SW-01 (serial=TST0000001)
        # was already created by the initial _do_sync_setup above because it
        # is present in data/errors/inventory__devices.json with a valid
        # siteName=Test-1X.  A single duplicate is inserted here so that
        # mor_sync's Device.objects.get(serial="TST0000001") raises MOR.
        # ------------------------------------------------------------------
        mgmt_sw = Device.objects.get(name="MGMT-SW-01")
        Device.objects.create(
            name="mgmt-sw-01-duplicate",
            serial="TST0000001",
            site=mgmt_sw.site,
            device_type=mgmt_sw.device_type,
            role=mgmt_sw.role,
            status="active",
        )
        cls.mor_sync = IPFabricSync.objects.create(
            name="MOR Error Sync",
            snapshot_data=cls.snapshot,
            # Device-only: only dcim.device needs to be True to trigger the
            # VC-master-removal MOR check. All other models stay False so the
            # MOR sync doesn't create interfaces/IPs that would break the
            # test_bad_device_interface_not_created_in_netbox assertion.
            parameters={
                k: (True if k == "dcim.device" else False if "." in k else v)
                for k, v in cls.sync.parameters.items()
            },
            user=cls.user,
            auto_merge=False,
        )
        # Use the parent mixin's create-fixtures mock so that TST-IP-DONOR
        # (and the other create-fixture devices) are created in the DB.
        # Those devices are needed by the removal-error setup below.
        # TST0000001 is in both fixture sets; encountering it here triggers
        # the MOR because a duplicate already exists in the DB.
        with (
            _IPFabricSyncMixin._mock_ipfabric_api(),
            cls._mock_branch_model(),
            cls._mock_active_branch(),
            cls._mock_sync_runner(),
        ):
            cls.mor_sync.sync(job=None)
        cls.mor_ingestion = cls.mor_sync.last_ingestion

        # ------------------------------------------------------------------
        # Primary-IP removal error scenario
        #
        # After cls.mor_sync, TST-IP-DONOR exists as a Device (the create
        # fixtures give it loginIp=198.51.100.1).  We manufacture the error
        # condition by:
        #   1. Creating a dedicated "victim" device and assigning a fresh
        #      198.51.100.1/24 IPAddress as its primary_ip4 via a direct
        #      SQL UPDATE (bypasses Python validation; avoids the
        #      UNIQUE constraint on primary_ip4_id).
        #   2. Patching Device.save to raise RuntimeError when it is called
        #      to clear primary_ip4 on that specific victim device.
        #
        # When the sync processes 198.51.100.1/24 with is_primary=True for
        # TST-IP-DONOR, sync_ipaddress:
        #   • finds the victim via .exclude(serial="TST-IP-DONOR")
        #                            .get(primary_ip4__address="198.51.100.1/24")
        #   • sets other_device.primary_ip4 = None
        #   • calls other_device.save() → RuntimeError (patched)
        #   → except Exception → "Error removing primary IP from other device."
        # ------------------------------------------------------------------
        donor_device = Device.objects.get(serial="TST-IP-DONOR")
        victim_ip = IPAddress.objects.create(address="198.51.100.1/24")
        victim_device = Device.objects.create(
            name="TST-DONOR-VICTIM",
            serial="TST-DONOR-VICTIM",
            site=donor_device.site,
            device_type=donor_device.device_type,
            role=donor_device.role,
            status="active",
        )
        # Use SQL UPDATE to assign the IP as primary_ip4 without triggering
        # NetBox's interface-assignment validation (which runs in full_clean).
        Device.objects.filter(pk=victim_device.pk).update(primary_ip4=victim_ip)

        _orig_device_save = Device.save

        def device_save_raising_for_victim(self, *args, **kwargs):
            """Raise when sync_ipaddress tries to clear primary_ip4 on the victim."""
            if self.primary_ip4 is None and self.serial == "TST-DONOR-VICTIM":
                raise RuntimeError(
                    "Simulated: cannot clear primary IP from TST-DONOR-VICTIM"
                )
            return _orig_device_save(self, *args, **kwargs)

        cls.primary_ip_removal_error_sync = IPFabricSync.objects.create(
            name="Primary IP Removal Error Sync",
            snapshot_data=cls.snapshot,
            # Only ipam.ipaddress enabled so the IP pipeline runs;
            # all other model flags stay False to avoid DB side-effects.
            parameters={
                k: (True if k == "ipam.ipaddress" else False if "." in k else v)
                for k, v in cls.sync.parameters.items()
            },
            user=cls.user,
            auto_merge=False,
        )
        with (
            patch.object(Device, "save", device_save_raising_for_victim),
            _IPFabricSyncMixin._mock_ipfabric_api(),
            cls._mock_branch_model(),
            cls._mock_active_branch(),
            cls._mock_sync_runner(),
        ):
            cls.primary_ip_removal_error_sync.sync(job=None)
        cls.primary_ip_removal_error_ingestion = (
            cls.primary_ip_removal_error_sync.last_ingestion
        )

        # ------------------------------------------------------------------
        # Primary-IP assignment error scenario
        #
        # TST-ASSIGN-FAIL is present in the errors fixtures (devices +
        # interfaces + managed-ip/ipv4) and was therefore fully synced by
        # the initial _do_sync_setup call above — Device, Interface and
        # IPAddress all exist and primary_ip4 is already set.
        #
        # We reset primary_ip4 to None so the assignment branch in
        # sync_ipaddress is re-entered on the next sync, then patch
        # Device.save to raise RuntimeError at that point:
        #   parent_device.primary_ip4 = ip_obj
        #   parent_device.save()  ← RuntimeError (patched)
        # → "Error assigning primary IP to device." issue recorded.
        # ------------------------------------------------------------------
        Device.objects.filter(serial="TST-ASSIGN-FAIL").update(primary_ip4=None)

        _orig_device_save_assign = Device.save

        def device_save_raising_on_assign(self, *args, **kwargs):
            """Raise when sync_ipaddress tries to assign primary_ip4 to TST-ASSIGN-FAIL."""
            if self.serial == "TST-ASSIGN-FAIL" and self.primary_ip4 is not None:
                raise RuntimeError(
                    "Simulated: cannot assign primary IP to TST-ASSIGN-FAIL"
                )
            return _orig_device_save_assign(self, *args, **kwargs)

        cls.primary_ip_assignment_error_sync = IPFabricSync.objects.create(
            name="Primary IP Assignment Error Sync",
            snapshot_data=cls.snapshot,
            parameters={
                k: (True if k == "ipam.ipaddress" else False if "." in k else v)
                for k, v in cls.sync.parameters.items()
            },
            user=cls.user,
            auto_merge=False,
        )
        with (
            patch.object(Device, "save", device_save_raising_on_assign),
            cls._mock_ipfabric_api(),
            cls._mock_branch_model(),
            cls._mock_active_branch(),
            cls._mock_sync_runner(),
        ):
            cls.primary_ip_assignment_error_sync.sync(job=None)
        cls.primary_ip_assignment_error_ingestion = (
            cls.primary_ip_assignment_error_sync.last_ingestion
        )

    # ------------------------------------------------------------------
    # Issue existence and phase
    # ------------------------------------------------------------------

    def test_device_issue_created_for_bad_site_reference(self):
        """
        Syncing a device whose siteName does not exist in the sites fixture
        must produce at least one IPFabricIngestionIssue for dcim.device.
        """
        self.assertGreater(
            self.ingestion.issues.filter(model="dcim.device").count(),
            0,
            "Expected at least one issue for dcim.device after syncing ERR-BAD-SITE-001",
        )

    def test_device_issue_has_sync_phase(self):
        """All dcim.device issues created during sync carry phase=SYNC."""
        for issue in self.ingestion.issues.filter(model="dcim.device"):
            self.assertEqual(
                issue.phase,
                IPFabricIngestionPhaseChoices.SYNC,
                f"Issue pk={issue.pk} has unexpected phase '{issue.phase}'",
            )

    def test_device_issue_exception_is_does_not_exist(self):
        """
        The root-cause issue for the bad device must record a DoesNotExist
        exception (raised by Site.objects.get() in the transform-map context).
        """
        self.assertTrue(
            self.ingestion.issues.filter(
                model="dcim.device",
                exception__icontains="DoesNotExist",
            ).exists(),
            "Expected an issue with exception containing 'DoesNotExist' for dcim.device",
        )

    def test_device_issue_raw_data_contains_bad_serial(self):
        """raw_data on the DoesNotExist device issue must contain the bad serial."""
        issue = self.ingestion.issues.filter(
            model="dcim.device",
            exception__icontains="DoesNotExist",
        ).first()
        self.assertIsNotNone(issue, "DoesNotExist issue for dcim.device not found")
        self.assertIn(
            "ERR-BAD-SITE-001",
            str(issue.raw_data),
            "raw_data should contain the bad device serial ERR-BAD-SITE-001",
        )

    # ------------------------------------------------------------------
    # RequiredDependencyFailedSkip cascade
    # ------------------------------------------------------------------

    def test_interface_gets_cascade_skip_issue(self):
        """
        After the device with serial ERR-BAD-SITE-001 fails, its interface
        must produce a RequiredDependencyFailedSkip issue for dcim.interface.
        """
        self.assertTrue(
            self.ingestion.issues.filter(
                model="dcim.interface",
                exception="RequiredDependencyFailedSkip",
            ).exists(),
            "Expected RequiredDependencyFailedSkip issue for dcim.interface",
        )

    def test_ipaddress_gets_cascade_skip_issue(self):
        """IP address for ERR-BAD-SITE-001 must be skipped with RequiredDependencyFailedSkip."""
        self.assertTrue(
            self.ingestion.issues.filter(
                model="ipam.ipaddress",
                exception="RequiredDependencyFailedSkip",
            ).exists(),
            "Expected RequiredDependencyFailedSkip issue for ipam.ipaddress",
        )

    def test_macaddress_gets_cascade_skip_issue(self):
        """MAC address record for ERR-BAD-SITE-001 must also be skipped."""
        self.assertTrue(
            self.ingestion.issues.filter(
                model="dcim.macaddress",
                exception="RequiredDependencyFailedSkip",
            ).exists(),
            "Expected RequiredDependencyFailedSkip issue for dcim.macaddress",
        )

    def test_cascade_issue_message_contains_bad_serial(self):
        """
        Every RequiredDependencyFailedSkip issue that originates from the
        ERR-BAD-SITE-001 device failure must reference that serial in its
        message.  (Other serials, e.g. ERR-VLAN-001, may also produce cascade
        issues in the same ingestion; this test is scoped to ERR-BAD-SITE-001.)
        """
        cascade_issues = self.ingestion.issues.filter(
            exception="RequiredDependencyFailedSkip",
            message__icontains="ERR-BAD-SITE-001",
        )
        self.assertGreater(
            cascade_issues.count(),
            0,
            "Expected at least one RequiredDependencyFailedSkip issue mentioning ERR-BAD-SITE-001",
        )
        for issue in cascade_issues:
            self.assertIn(
                "ERR-BAD-SITE-001",
                issue.message,
                f"Cascade issue pk={issue.pk} (model={issue.model}) message "
                f"should reference the failed device serial ERR-BAD-SITE-001",
            )

    def test_cascade_issues_have_sync_phase(self):
        """All RequiredDependencyFailedSkip issues carry phase=SYNC."""
        for issue in self.ingestion.issues.filter(
            exception="RequiredDependencyFailedSkip"
        ):
            self.assertEqual(
                issue.phase,
                IPFabricIngestionPhaseChoices.SYNC,
                f"Cascade issue pk={issue.pk} has unexpected phase '{issue.phase}'",
            )

    # ------------------------------------------------------------------
    # Objects must NOT be created for the bad device
    # ------------------------------------------------------------------

    def test_bad_device_not_created_in_netbox(self):
        """ERR-BAD-SITE-001 must not exist as a Device because its site lookup failed."""
        self.assertFalse(
            Device.objects.filter(serial="ERR-BAD-SITE-001").exists(),
            "Device ERR-BAD-SITE-001 should not have been created (site not found)",
        )

    def test_bad_device_interface_not_created_in_netbox(self):
        """No Interface should be created when its parent device failed to sync.

        ERR-BAD-SITE-001 fails at device creation (unknown site), so its
        GigabitEthernet0/0 interface must be cascade-skipped and absent from
        the DB.  TST-ASSIGN-FAIL in the same error fixture file succeeds, so
        we check only the failing device's serial here.
        """
        self.assertFalse(
            Interface.objects.filter(device__serial="ERR-BAD-SITE-001").exists(),
            "Interface for ERR-BAD-SITE-001 should not be created (cascade skip "
            "from device sync failure)",
        )

    def test_bad_device_ipaddress_not_created_in_netbox(self):
        """No IPAddress should be created when the parent device/interface failed."""
        self.assertFalse(
            IPAddress.objects.filter(address="10.99.99.99/24").exists(),
            "IPAddress 10.99.99.99/24 should not have been created (cascade skip)",
        )

    # ------------------------------------------------------------------
    # MOR: duplicate serial → VC-master-removal check raises MOR
    # ------------------------------------------------------------------

    def test_duplicate_serial_creates_mor_issue(self):
        """
        When two Device rows share serial=TST0000001, sync_device's
        Device.objects.get(serial=...) check raises MultipleObjectsReturned,
        which must be recorded as an IPFabricIngestionIssue.
        """
        self.assertTrue(
            self.mor_ingestion.issues.filter(
                model="dcim.device",
                exception="MultipleObjectsReturned",
            ).exists(),
            "Expected MultipleObjectsReturned issue for dcim.device (serial=TST0000001)",
        )

    def test_mor_issue_message_describes_vc_check(self):
        """The MOR issue message must reference the VirtualChassis master-removal step."""
        issue = self.mor_ingestion.issues.filter(
            model="dcim.device",
            exception="MultipleObjectsReturned",
        ).first()
        self.assertIsNotNone(issue, "MultipleObjectsReturned issue not found")
        self.assertIn("virtual", issue.message.lower())

    # ------------------------------------------------------------------
    # Primary-IP removal error
    # ------------------------------------------------------------------

    def test_primary_ip_removal_error_creates_issue(self):
        """
        When Device.save raises while sync_ipaddress tries to clear
        primary_ip4 on the "other" device (TST-DONOR-VICTIM), the exception
        is caught and recorded as an IPFabricIngestionIssue with
        message "Error removing primary IP from other device.".
        """
        self.assertTrue(
            self.primary_ip_removal_error_ingestion.issues.filter(
                model="ipam.ipaddress",
                exception="RuntimeError",
                message__contains="Error removing primary IP from other device.",
            ).exists(),
            "Expected a RuntimeError issue with 'Error removing primary IP from "
            "other device.' for ipam.ipaddress in the primary-IP removal error sync",
        )

    def test_primary_ip_removal_error_message(self):
        """
        The issue created by the primary-IP removal error must carry the
        exact human-readable message from the except block in sync_ipaddress.
        """
        issue = self.primary_ip_removal_error_ingestion.issues.filter(
            model="ipam.ipaddress",
            exception="RuntimeError",
            message__contains="Error removing primary IP from other device.",
        ).first()
        self.assertIsNotNone(
            issue,
            "No RuntimeError issue found for ipam.ipaddress",
        )
        self.assertIn(
            "Error removing primary IP from other device.",
            issue.message,
            "Issue message must contain 'Error removing primary IP from other device.'",
        )

    def test_primary_ip_removal_error_has_sync_phase(self):
        """
        The issue produced by the primary-IP removal error must be
        phase=SYNC (it is raised inside sync_ipaddress, not in a merge step).
        """
        issue = self.primary_ip_removal_error_ingestion.issues.filter(
            model="ipam.ipaddress",
            exception="RuntimeError",
            message__contains="Error removing primary IP from other device.",
        ).first()
        self.assertIsNotNone(
            issue,
            "No RuntimeError 'Error removing primary IP' issue found",
        )
        self.assertEqual(
            issue.phase,
            IPFabricIngestionPhaseChoices.SYNC,
            f"Expected phase=SYNC, got '{issue.phase}'",
        )

    # ------------------------------------------------------------------
    # Primary-IP assignment error
    # ------------------------------------------------------------------

    def test_primary_ip_assignment_error_creates_issue(self):
        """
        When Device.save raises while sync_ipaddress tries to assign
        primary_ip4 on TST-ASSIGN-FAIL (loginIp=10.99.1.1), the exception
        is caught and recorded as an IPFabricIngestionIssue with
        message "Error assigning primary IP to device.".

        This exercises the second except-block in sync_ipaddress — the
        assignment path (parent_device.primary_ip4 = ip_obj; save()) as
        opposed to the removal path tested by
        test_primary_ip_removal_error_creates_issue.
        """
        self.assertTrue(
            self.primary_ip_assignment_error_ingestion.issues.filter(
                model="ipam.ipaddress",
                exception="RuntimeError",
                message__contains="Error assigning primary IP to device.",
            ).exists(),
            "Expected a RuntimeError issue with 'Error assigning primary IP to "
            "device.' for ipam.ipaddress in the primary-IP assignment error sync",
        )

    def test_primary_ip_assignment_error_message(self):
        """
        The issue created by the primary-IP assignment error must carry the
        exact human-readable message from the except block in sync_ipaddress.
        """
        issue = self.primary_ip_assignment_error_ingestion.issues.filter(
            model="ipam.ipaddress",
            exception="RuntimeError",
            message__contains="Error assigning primary IP to device.",
        ).first()
        self.assertIsNotNone(
            issue,
            "No RuntimeError issue found for ipam.ipaddress",
        )
        self.assertIn(
            "Error assigning primary IP to device.",
            issue.message,
            "Issue message must contain 'Error assigning primary IP to device.'",
        )

    def test_primary_ip_assignment_error_has_sync_phase(self):
        """
        The issue produced by the primary-IP assignment error must be
        phase=SYNC (it is raised inside sync_ipaddress, not in a merge step).
        """
        issue = self.primary_ip_assignment_error_ingestion.issues.filter(
            model="ipam.ipaddress",
            exception="RuntimeError",
            message__contains="Error assigning primary IP to device.",
        ).first()
        self.assertIsNotNone(
            issue,
            "No RuntimeError 'Error assigning primary IP' issue found",
        )
        self.assertEqual(
            issue.phase,
            IPFabricIngestionPhaseChoices.SYNC,
            f"Expected phase=SYNC, got '{issue.phase}'",
        )

    # ------------------------------------------------------------------
    # Tagged VLAN assignment error (sync_interface exception path)
    #
    # ERR-VLAN-001 is present in the error fixtures with a valid site so
    # its Device and Interface are created successfully.  The IP fixture
    # carries vlanId="INVALID-VID" (a non-integer string).  During
    # _preprocess_interfaces the pre-scan stores ["INVALID-VID"] as
    # tagged_vlan_ids for the interface.  sync_interface then calls
    # VLAN.objects.filter(vid__in=["INVALID-VID"]) and evaluates the
    # queryset inside tagged_vlans.set(); Django's IntegerField raises
    # ValueError (int("INVALID-VID") fails) which is caught and recorded
    # as an IPFabricIngestionIssue without mocking any NetBox internals.
    # ------------------------------------------------------------------

    def test_vlan_assignment_error_creates_interface_issue(self):
        """
        When tagged_vlans.set() raises (bad vlanId in source data),
        sync_interface must record an IPFabricIngestionIssue for
        dcim.interface with message "Error assigning tagged VLANs to
        interface."
        """
        self.assertTrue(
            self.ingestion.issues.filter(
                model="dcim.interface",
                exception="ValueError",
                message__contains="Error assigning tagged VLANs to interface.",
            ).exists(),
            "Expected a ValueError issue with 'Error assigning tagged VLANs to "
            "interface.' for dcim.interface after syncing ERR-VLAN-001",
        )

    def test_vlan_assignment_error_issue_message(self):
        """The VLAN-assignment issue carries the exact message from sync_interface."""
        issue = self.ingestion.issues.filter(
            model="dcim.interface",
            exception="ValueError",
            message__contains="Error assigning tagged VLANs to interface.",
        ).first()
        self.assertIsNotNone(issue, "VLAN assignment ValueError issue not found")
        self.assertIn(
            "Error assigning tagged VLANs to interface.",
            issue.message,
        )

    def test_vlan_assignment_error_has_sync_phase(self):
        """The VLAN-assignment issue must be phase=SYNC."""
        issue = self.ingestion.issues.filter(
            model="dcim.interface",
            exception="ValueError",
            message__contains="Error assigning tagged VLANs to interface.",
        ).first()
        self.assertIsNotNone(issue, "VLAN assignment ValueError issue not found")
        self.assertEqual(
            issue.phase,
            IPFabricIngestionPhaseChoices.SYNC,
            f"Expected phase=SYNC, got '{issue.phase}'",
        )

    def test_vlan_assignment_error_raw_data_contains_serial(self):
        """raw_data on the VLAN-assignment issue must identify ERR-VLAN-001."""
        issue = self.ingestion.issues.filter(
            model="dcim.interface",
            exception="ValueError",
            message__contains="Error assigning tagged VLANs to interface.",
        ).first()
        self.assertIsNotNone(issue, "VLAN assignment ValueError issue not found")
        self.assertIn(
            "ERR-VLAN-001",
            str(issue.raw_data),
            "raw_data should contain the serial ERR-VLAN-001",
        )

    def test_interface_still_created_after_vlan_assignment_error(self):
        """
        sync_model succeeds before tagged_vlans.set() fails, so the
        Interface object itself must exist in the database.
        """
        from dcim.models import Interface

        self.assertTrue(
            Interface.objects.filter(device__serial="ERR-VLAN-001").exists(),
            "Interface for ERR-VLAN-001 should exist — sync_model ran before the "
            "VLAN assignment failure",
        )


@tag("integration")
class IPFabricSyncAllDisabledTests(_IPFabricSyncMixin, TestCase):
    """
    Verify that a sync with every model flag set to ``False`` completes cleanly
    without writing a single NetBox object.

    This test acts as a regression guard ensuring that the "disabled model"
    short-circuit paths never accidentally write to the database.
    """

    @classmethod
    def setUpTestData(cls):
        super().setUpTestData()
        cls.user = User.objects.create_user(
            username="test_all_disabled_user", email="all_disabled@example.com"
        )
        cls.source = IPFabricSource.objects.create(
            name="All Disabled Test Source",
            type="local",
            url="https://disabled-test.ipfabric.io",
            status="loaded",
            parameters={
                "base_url": "https://disabled-test.ipfabric.io",
                "token": "test_token",
                "verify": False,
                "timeout": 30,
                "snapshot_id": "$last",
            },
        )
        cls.snapshot = IPFabricSnapshot.objects.create(
            name="All Disabled Test Snapshot",
            source=cls.source,
            snapshot_id="$last",
            status=IPFabricSnapshotStatusModelChoices.STATUS_LOADED,
            data={
                "id": "$last",
                "name": "All Disabled Test Snapshot",
                "status": "loaded",
                "start": "2026-02-23T10:00:00.000Z",
                "end": "2026-02-23T10:30:00.000Z",
            },
        )
        cls.sync = IPFabricSync.objects.create(
            name="All Disabled Sync",
            snapshot_data=cls.snapshot,
            parameters={
                "sites": [],
                "groups": [],
                **{
                    f"{tm.target_model.app_label}.{tm.target_model.model}": False
                    for tm in IPFabricSync.get_transform_maps()
                },
            },
            user=cls.user,
            auto_merge=False,
        )
        with (
            cls._mock_ipfabric_api(),
            cls._mock_branch_model(),
            cls._mock_active_branch(),
            cls._mock_sync_runner(),
        ):
            cls.sync.sync(job=None)
        cls.ingestion = cls.sync.last_ingestion

    # ------------------------------------------------------------------
    # Pipeline completed
    # ------------------------------------------------------------------

    def test_ingestion_created(self):
        """The pipeline must create an IPFabricIngestion even when all models are disabled."""
        self.assertIsNotNone(
            self.ingestion,
            "IPFabricIngestion must be created even when every model flag is False",
        )

    def test_sync_status_is_ready_to_merge(self):
        """
        A fully-disabled sync must complete without failure.
        Expected status: READY_TO_MERGE (the pipeline ran cleanly; there is
        simply nothing to merge).
        """
        self.sync.refresh_from_db()
        self.assertEqual(
            self.sync.status,
            IPFabricSyncStatusChoices.READY_TO_MERGE,
            f"Expected READY_TO_MERGE, got '{self.sync.status}'",
        )

    def test_no_ingestion_issues(self):
        """A fully-disabled sync must produce zero IPFabricIngestionIssue records."""
        self.assertEqual(
            self.ingestion.issues.count(),
            0,
            "No IngestionIssue should be created when every model is disabled",
        )

    # ------------------------------------------------------------------
    # NetBox model tables must all be empty
    # ------------------------------------------------------------------

    def test_no_netbox_objects_written(self):
        """No rows must exist for any model covered by the sync pipeline."""
        for tm in IPFabricSync.get_transform_maps():
            model_string = f"{tm.target_model.app_label}.{tm.target_model.model}"
            model_class = tm.target_model.model_class()
            with self.subTest(model=model_string):
                self.assertEqual(
                    model_class.objects.count(),
                    0,
                    f"{model_string} must have 0 rows when all models are disabled",
                )
