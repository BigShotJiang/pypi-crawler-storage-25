"""
Unit tests for IPFabricSyncRunner.create_or_get_sync_issue and the
handle_errors decorator.

These tests exercise the error-recording contract in isolation, using real DB
objects for IPFabricIngestionIssue (which must be persisted) but mocking out
everything else (branching, transform maps, etc.) to keep the tests fast.
"""
import threading
from unittest.mock import MagicMock
from unittest.mock import patch

from django.contrib.auth import get_user_model
from django.test import TestCase
from rq.timeouts import JobTimeoutException

from ipfabric_netbox.choices import IPFabricSyncStatusChoices
from ipfabric_netbox.exceptions import IPAddressDuplicateError
from ipfabric_netbox.exceptions import RequiredDependencyFailedSkip
from ipfabric_netbox.exceptions import SearchError
from ipfabric_netbox.models import IPFabricIngestion
from ipfabric_netbox.models import IPFabricIngestionIssue
from ipfabric_netbox.models import IPFabricSnapshot
from ipfabric_netbox.models import IPFabricSource
from ipfabric_netbox.models import IPFabricSync
from ipfabric_netbox.utilities.ipfutils import IPFabricSyncRunner
from ipfabric_netbox.utilities.logging import SyncLogging

User = get_user_model()

BAD_SERIAL = "ERR-UNIT-001"


def _make_runner(ingestion: IPFabricIngestion) -> IPFabricSyncRunner:
    """
    Construct a minimal IPFabricSyncRunner by bypassing __init__.

    Only the attributes touched by create_or_get_sync_issue / handle_errors
    are set; everything else (client, transform_maps, …) remains absent so
    the runner cannot accidentally call real IPFabric or NetBox logic.

    get_db_connection_name is replaced with a plain lambda returning None so
    that any code path reaching it uses the default test DB instead of trying
    to resolve an ingestion branch (which does not exist in unit tests).
    """
    runner = object.__new__(IPFabricSyncRunner)
    runner.error_serials = set()
    runner._lock = threading.Lock()
    runner.ingestion = ingestion
    runner.sync = MagicMock()
    runner.sync.status = "syncing"  # plain string – overwritten on failure
    runner.logger = MagicMock()
    runner.settings = {}
    runner.events_clearer = MagicMock()
    # Override the @cache-decorated method so no branch DB lookup is attempted.
    runner.get_db_connection_name = lambda: None
    return runner


class _IssueTestBase(TestCase):
    """Shared DB setup used by both test suites below."""

    @classmethod
    def setUpTestData(cls):
        cls.user = User.objects.create_user(
            username="test_issue_errors_user", email="issue_errors@example.com"
        )
        source = IPFabricSource.objects.create(
            name="Issue Error Test Source",
            url="https://issue-error.test.local",
            parameters={"auth": "token", "verify": True},
        )
        snapshot = IPFabricSnapshot.objects.create(
            name="Issue Error Test Snapshot",
            source=source,
            snapshot_id="issue-err-snap-1",
            status="loaded",
            data={},
        )
        sync = IPFabricSync.objects.create(
            name="Issue Error Test Sync",
            snapshot_data=snapshot,
            parameters={},
            user=cls.user,
        )
        sync.logger = SyncLogging(job=sync.pk)
        cls.ingestion = IPFabricIngestion.objects.create(sync=sync)


# ---------------------------------------------------------------------------
# create_or_get_sync_issue
# ---------------------------------------------------------------------------


class CreateOrGetSyncIssueTests(_IssueTestBase):
    """Unit tests for IPFabricSyncRunner.create_or_get_sync_issue."""

    def test_creates_new_issue_returns_true_and_issue(self):
        """When exception has no issue_id a new issue is created and (True, issue) returned."""
        runner = _make_runner(self.ingestion)
        exc = ValueError("something went wrong")

        created, issue = runner.create_or_get_sync_issue(
            exception=exc,
            ingestion=self.ingestion,
            message="Test error",
            model_string="dcim.device",
            context={"name": "test-device"},
            data={"sn": BAD_SERIAL, "hostname": "test-device"},
        )

        self.assertTrue(created)
        self.assertIsInstance(issue, IPFabricIngestionIssue)
        self.assertEqual(issue.exception, "ValueError")
        self.assertEqual(issue.message, "Test error")
        self.assertEqual(issue.model, "dcim.device")
        self.assertEqual(issue.ingestion_id, self.ingestion.pk)

    def test_returns_existing_issue_when_issue_id_already_set(self):
        """When exception.issue_id is set, returns (False, existing) without creating a new row."""
        runner = _make_runner(self.ingestion)

        existing = IPFabricIngestionIssue.objects.create(
            ingestion=self.ingestion,
            exception="ValueError",
            message="Pre-existing issue",
            model="dcim.device",
        )

        exc = SearchError(
            message="test", model_string="dcim.device", data={"sn": BAD_SERIAL}
        )
        exc.issue_id = existing.pk

        count_before = IPFabricIngestionIssue.objects.count()

        created, issue = runner.create_or_get_sync_issue(
            exception=exc,
            ingestion=self.ingestion,
            model_string="dcim.device",
            data={"sn": BAD_SERIAL},
        )

        self.assertFalse(created)
        self.assertEqual(issue.pk, existing.pk)
        # No extra row written
        self.assertEqual(IPFabricIngestionIssue.objects.count(), count_before)

    def test_issue_id_set_on_exception_after_creation(self):
        """After creation, exception.issue_id is populated with the new issue pk."""
        runner = _make_runner(self.ingestion)
        exc = SearchError(
            message="test", model_string="dcim.device", data={"sn": BAD_SERIAL}
        )
        self.assertIsNone(exc.issue_id)

        _, issue = runner.create_or_get_sync_issue(
            exception=exc,
            ingestion=self.ingestion,
            model_string="dcim.device",
            data={"sn": BAD_SERIAL},
        )

        self.assertEqual(exc.issue_id, issue.pk)

    def test_adds_serial_to_error_serials_for_standard_model(self):
        """Serial number from data is added to error_serials for standard models."""
        runner = _make_runner(self.ingestion)

        runner.create_or_get_sync_issue(
            exception=ValueError("err"),
            ingestion=self.ingestion,
            model_string="dcim.device",
            context={},
            data={"sn": BAD_SERIAL, "hostname": "device1"},
        )

        self.assertIn(BAD_SERIAL, runner.error_serials)

    def test_does_not_add_serial_for_ipam_ipaddress(self):
        """Serial is NOT added to error_serials when model_string is 'ipam.ipaddress'."""
        runner = _make_runner(self.ingestion)

        runner.create_or_get_sync_issue(
            exception=ValueError("err"),
            ingestion=self.ingestion,
            model_string="ipam.ipaddress",
            context={},
            data={"sn": BAD_SERIAL, "ip": "10.0.0.1"},
        )

        self.assertNotIn(BAD_SERIAL, runner.error_serials)

    def test_does_not_add_serial_for_dcim_macaddress(self):
        """Serial is NOT added to error_serials when model_string is 'dcim.macaddress'."""
        runner = _make_runner(self.ingestion)

        runner.create_or_get_sync_issue(
            exception=ValueError("err"),
            ingestion=self.ingestion,
            model_string="dcim.macaddress",
            context={},
            data={"sn": BAD_SERIAL, "mac": "aa:bb:cc:dd:ee:ff"},
        )

        self.assertNotIn(BAD_SERIAL, runner.error_serials)

    def test_serial_from_context_takes_precedence_over_data(self):
        """When context contains 'serial', it is used over serial(data)."""
        runner = _make_runner(self.ingestion)
        ctx_serial = "CTX-SERIAL-001"

        runner.create_or_get_sync_issue(
            exception=ValueError("err"),
            ingestion=self.ingestion,
            model_string="dcim.device",
            context={"serial": ctx_serial},
            data={"sn": "DATA-SERIAL"},
        )

        self.assertIn(ctx_serial, runner.error_serials)
        self.assertNotIn("DATA-SERIAL", runner.error_serials)

    def test_coalesce_fields_excludes_defaults_key(self):
        """The 'defaults' key is stripped from context before storing in coalesce_fields."""
        runner = _make_runner(self.ingestion)
        context = {
            "name": "test",
            "serial": BAD_SERIAL,
            "defaults": {"status": "active"},
        }

        _, issue = runner.create_or_get_sync_issue(
            exception=ValueError("err"),
            ingestion=self.ingestion,
            model_string="dcim.device",
            context=context,
            data={"sn": BAD_SERIAL},
        )

        stored = str(issue.coalesce_fields)
        self.assertNotIn("defaults", stored)
        self.assertIn("name", stored)

    def test_raw_data_contains_source_data(self):
        """raw_data on the created issue preserves the original source dict."""
        runner = _make_runner(self.ingestion)
        data = {"sn": BAD_SERIAL, "hostname": "bad-device", "siteName": "MISSING"}

        _, issue = runner.create_or_get_sync_issue(
            exception=ValueError("err"),
            ingestion=self.ingestion,
            model_string="dcim.device",
            data=data,
        )

        self.assertIn(BAD_SERIAL, str(issue.raw_data))
        self.assertIn("MISSING", str(issue.raw_data))

    def test_job_timeout_reraises_without_creating_issue(self):
        """JobTimeoutException must be re-raised immediately; no issue row is written."""
        runner = _make_runner(self.ingestion)
        count_before = IPFabricIngestionIssue.objects.count()

        try:
            raise JobTimeoutException()
        except JobTimeoutException as exc:
            with self.assertRaises(JobTimeoutException):
                runner.create_or_get_sync_issue(
                    exception=exc,
                    ingestion=self.ingestion,
                    model_string="dcim.device",
                    data={"sn": BAD_SERIAL},
                )

        self.assertEqual(IPFabricIngestionIssue.objects.count(), count_before)


# ---------------------------------------------------------------------------
# handle_errors decorator
# ---------------------------------------------------------------------------


class HandleErrorsTests(_IssueTestBase):
    """Unit tests for the handle_errors static decorator on IPFabricSyncRunner."""

    def setUp(self):
        # handle_errors calls logger.error(err, exc_info=True) on every exception
        # before inspecting issue_id.  Patch the module logger so intentionally
        # raised test exceptions do not litter the test output with tracebacks.
        patcher = patch("ipfabric_netbox.utilities.ipfutils.logger")
        self.mock_ipf_logger = patcher.start()
        self.addCleanup(patcher.stop)

    def test_exception_with_issue_id_returns_none_immediately(self):
        """Exception that already has issue_id is silently suppressed; status unchanged."""
        runner = _make_runner(self.ingestion)
        exc = SearchError(
            message="already tracked",
            model_string="dcim.device",
            data={"sn": BAD_SERIAL},
        )
        exc.issue_id = 999  # pre-set – issue was created upstream

        initial_status = runner.sync.status

        with patch.object(runner, "get_model_or_update", side_effect=exc):
            result = runner.sync_model(record=MagicMock(data={"sn": BAD_SERIAL}))

        self.assertIsNone(result)
        # status must NOT have been changed
        self.assertEqual(runner.sync.status, initial_status)
        # log_failure must NOT have been called (issue already logged upstream)
        runner.logger.log_failure.assert_not_called()

    def test_search_error_without_issue_id_sets_sync_failed(self):
        """Untracked SearchError (no issue_id) logs a failure and sets sync.status=FAILED."""
        runner = _make_runner(self.ingestion)
        runner.settings = {"dcim.device": True}
        exc = SearchError(
            message="site not found",
            model_string="dcim.device",
            data={"sn": BAD_SERIAL},
        )
        # issue_id is None (the default class attribute)

        with patch.object(runner, "get_model_or_update", side_effect=exc):
            result = runner.sync_model(record=MagicMock(data={"sn": BAD_SERIAL}))

        self.assertIsNone(result)
        self.assertEqual(runner.sync.status, IPFabricSyncStatusChoices.FAILED)
        runner.logger.log_failure.assert_called()

    def test_search_error_disabled_model_logs_different_failure_message(self):
        """SearchError on a disabled model produces a distinct 'disabled' log message."""
        runner = _make_runner(self.ingestion)
        runner.settings = {"dcim.device": False}  # model disabled
        exc = SearchError(
            message="not found", model_string="dcim.device", data={"sn": BAD_SERIAL}
        )

        with patch.object(runner, "get_model_or_update", side_effect=exc):
            runner.sync_model(record=MagicMock(data={"sn": BAD_SERIAL}))

        # Any log_failure call should mention the model is disabled
        failure_messages = [
            str(call) for call in runner.logger.log_failure.call_args_list
        ]
        self.assertTrue(
            any("disabled" in msg for msg in failure_messages),
            f"Expected a 'disabled' failure message, got: {failure_messages}",
        )

    def test_ip_duplicate_error_logs_warning_and_sets_failed(self):
        """IPAddressDuplicateError triggers log_warning (not log_failure) and sets FAILED."""
        runner = _make_runner(self.ingestion)
        exc = IPAddressDuplicateError(
            model_string="ipam.ipaddress",
            data={"address": "10.0.0.1", "sn": BAD_SERIAL},
        )

        with patch.object(runner, "get_model_or_update", side_effect=exc):
            result = runner.sync_model(record=MagicMock(data={"address": "10.0.0.1"}))

        self.assertIsNone(result)
        self.assertEqual(runner.sync.status, IPFabricSyncStatusChoices.FAILED)
        runner.logger.log_warning.assert_called_once()

    def test_required_dependency_failed_skip_returns_none(self):
        """RequiredDependencyFailedSkip with issue_id set is silently suppressed."""
        runner = _make_runner(self.ingestion)

        # issue_id is set as though create_or_get_sync_issue already ran
        exc = RequiredDependencyFailedSkip(
            message="skip due to prior error",
            model_string="dcim.interface",
            data={"sn": BAD_SERIAL},
        )
        exc.issue_id = 42

        with patch.object(runner, "get_model_or_update", side_effect=exc):
            result = runner.sync_model(record=MagicMock(data={"sn": BAD_SERIAL}))

        self.assertIsNone(result)
        runner.logger.log_failure.assert_not_called()

    def test_job_timeout_creates_issue_and_reraises(self):
        """JobTimeoutException creates one IPFabricIngestionIssue and then propagates."""
        runner = _make_runner(self.ingestion)

        with patch("ipfabric_netbox.utilities.ipfutils.connections") as mock_conns:
            mock_conns.all.return_value = []  # don't close test DB connections
            exc = JobTimeoutException()

            with patch.object(runner, "get_model_or_update", side_effect=exc):
                with self.assertRaises(JobTimeoutException):
                    runner.sync_model(record=MagicMock(data={"sn": BAD_SERIAL}))

        self.assertEqual(
            IPFabricIngestionIssue.objects.filter(
                ingestion=self.ingestion,
                exception="JobTimeoutException",
            ).count(),
            1,
        )

    def test_job_timeout_deduplicates_issue_on_nested_calls(self):
        """A second JobTimeoutException does not create a duplicate issue row."""
        runner = _make_runner(self.ingestion)

        # Simulate an issue already written by a previous (nested) handle_errors call
        IPFabricIngestionIssue.objects.create(
            ingestion=self.ingestion,
            exception="JobTimeoutException",
            message="timed out",
        )

        with patch("ipfabric_netbox.utilities.ipfutils.connections") as mock_conns:
            mock_conns.all.return_value = []
            exc = JobTimeoutException()

            with patch.object(runner, "get_model_or_update", side_effect=exc):
                with self.assertRaises(JobTimeoutException):
                    runner.sync_model(record=MagicMock(data={"sn": BAD_SERIAL}))

        # Must still be exactly 1
        self.assertEqual(
            IPFabricIngestionIssue.objects.filter(
                ingestion=self.ingestion,
                exception="JobTimeoutException",
            ).count(),
            1,
        )
