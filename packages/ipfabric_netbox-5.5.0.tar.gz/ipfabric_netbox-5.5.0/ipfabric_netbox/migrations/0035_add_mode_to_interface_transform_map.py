"""
Merged migration: tagged-VLAN mode field + all Transform Map parent corrections
(previously split across 0035, 0036, 0037).

Changes applied in a single ``do_change`` call:

Interface Transform Map
  • field: add ``tagged_vlan_ids → mode`` (Jinja2 template sets mode=tagged or
    clears it to None; see sync_interface / _preprocess_interfaces).
  • parents: dcim.device → [dcim.device, ipam.vlan]
    (ipam.vlan must exist before tagged_vlans.set() is called)

Virtual Chassis Transform Map
  • parents: dcim.manufacturer → [dcim.devicetype, dcim.platform, dcim.devicerole]
    (VC has no FK to Manufacturer; correct ordering puts it before Device but
    after all Device prerequisites)

Device Transform Map
  • parents: dcim.devicetype → [dcim.site, dcim.virtualchassis, dcim.platform,
                                dcim.devicetype, dcim.devicerole]
    (all relationship_maps reference these models directly)

Inventory Item Transform Map
  • parents: dcim.device → [dcim.device, dcim.manufacturer]
    (manufacturer relationship_map does a live Manufacturer.objects.get())

VRF Transform Map
  • parents: ipam.vlan → dcim.site
    (VRF has no FK to VLAN; site is the correct ordering anchor because VRF
    source data carries siteName and the sync order places VRFs after sites)
"""
from typing import TYPE_CHECKING

from django.db import migrations

from ipfabric_netbox.utilities.transform_map import do_change
from ipfabric_netbox.utilities.transform_map import FieldRecord
from ipfabric_netbox.utilities.transform_map import ParentRecord
from ipfabric_netbox.utilities.transform_map import TransformMapRecord

if TYPE_CHECKING:
    from django.apps import apps as apps_type
    from django.db.backends.base.schema import BaseDatabaseSchemaEditor

_MODE_TEMPLATE = "{% if object.tagged_vlan_ids %}tagged{% else %}None{% endif %}"

TRANSFORM_MAP_ADDITIONS = (
    # ── Interface: new mode field + parent ipam.vlan ──────────────────────────
    TransformMapRecord(
        source_endpoint="/inventory/interfaces",
        target_model="dcim.interface",
        fields=(
            FieldRecord(
                source_field="tagged_vlan_ids",
                target_field="mode",
                old_template=None,  # ADD operation
                new_template=_MODE_TEMPLATE,
                coalesce=False,
            ),
        ),
        parents=ParentRecord(
            old_parents=["dcim.device"],
            new_parents=["dcim.device", "ipam.vlan"],
        ),
    ),
    # ── Virtual Chassis: replace single ordering parent ───────────────────────
    TransformMapRecord(
        source_endpoint="/technology/platforms/stack/members",
        target_model="dcim.virtualchassis",
        parents=ParentRecord(
            old_parents=["dcim.manufacturer"],
            new_parents=["dcim.devicetype", "dcim.platform", "dcim.devicerole"],
        ),
    ),
    # ── Device: all direct FK / operational dependencies ─────────────────────
    TransformMapRecord(
        source_endpoint="/inventory/devices",
        target_model="dcim.device",
        parents=ParentRecord(
            old_parents=["dcim.devicetype"],
            new_parents=[
                "dcim.site",
                "dcim.virtualchassis",
                "dcim.platform",
                "dcim.devicetype",
                "dcim.devicerole",
            ],
        ),
    ),
    # ── Inventory Item: add manufacturer dependency ───────────────────────────
    TransformMapRecord(
        source_endpoint="/inventory/part-numbers",
        target_model="dcim.inventoryitem",
        parents=ParentRecord(
            old_parents=["dcim.device"],
            new_parents=["dcim.device", "dcim.manufacturer"],
        ),
    ),
    # ── VRF: site is the correct anchor (no FK to VLAN) ──────────────────────
    TransformMapRecord(
        source_endpoint="/technology/routing/vrf/detail",
        target_model="ipam.vrf",
        parents=ParentRecord(
            old_parents=["ipam.vlan"],
            new_parents=["dcim.site"],
        ),
    ),
)


def forward(apps: "apps_type", schema_editor: "BaseDatabaseSchemaEditor") -> None:
    do_change(apps, schema_editor, TRANSFORM_MAP_ADDITIONS, forward=True)


def backward(apps: "apps_type", schema_editor: "BaseDatabaseSchemaEditor") -> None:
    do_change(apps, schema_editor, TRANSFORM_MAP_ADDITIONS, forward=False)


class Migration(migrations.Migration):
    dependencies = [
        ("ipfabric_netbox", "0034_add_primary_ip4_to_device_transform_map"),
    ]

    operations = [
        migrations.RunPython(forward, backward),
    ]
