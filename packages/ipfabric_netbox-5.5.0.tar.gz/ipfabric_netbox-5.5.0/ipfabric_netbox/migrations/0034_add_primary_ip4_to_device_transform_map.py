"""
Add a ``primary_ip4`` IPFabricRelationshipField to every Device Transform Map
(default ungrouped map and all group clones).

When the template resolves a login IP it looks up the matching IPAddress
via the device's interfaces, so the FK is always scoped to the correct device.
When ``loginIp``/``loginIpv4`` is absent from the source data the template
returns ``None``, which propagates through ``build_relationships`` →
``defaults["primary_ip4"] = None`` → ``update_or_create_instance`` clears
``Device.primary_ip4``.  This fills the gap where the sync previously left
``primary_ip4`` set even after the login IP was removed in IP Fabric.

On first-create runs the IPAddress rows do not yet exist when Device sync
runs, so the template returns ``None`` and ``sync_ipaddress`` assigns the
correct IP afterwards (existing behavior, unchanged).
"""
from typing import TYPE_CHECKING

from django.db import migrations

from ipfabric_netbox.utilities.transform_map import do_change
from ipfabric_netbox.utilities.transform_map import RelationshipRecord
from ipfabric_netbox.utilities.transform_map import TransformMapRecord

if TYPE_CHECKING:
    from django.apps import apps as apps_type
    from django.db.backends.base.schema import BaseDatabaseSchemaEditor

# Keep the template in a named constant so forward and reverse migrations
# reference exactly the same string (avoids accidental divergence).
_TEMPLATE = (
    "{% set LOGIN_IP = object.loginIp or object.loginIpv4 %}"
    "{% if LOGIN_IP %}"
    "{% set IFACE_PKS = dcim.Interface.objects.filter(device__serial=object.sn).values_list('pk', flat=True) %}"
    "{% set IP = ipam.IPAddress.objects.filter("
    "assigned_object_type__model='interface',"
    "assigned_object_id__in=IFACE_PKS,"
    "address__net_host=LOGIN_IP"
    ").first() %}"
    "{% if IP %}{{ IP.pk }}{% else %}None{% endif %}"
    "{% else %}None{% endif %}"
)

TRANSFORM_MAP_ADDITIONS = (
    TransformMapRecord(
        source_endpoint="/inventory/devices",
        target_model="dcim.device",
        relationships=(
            RelationshipRecord(
                source_model="ipam.ipaddress",
                target_field="primary_ip4",
                # old_template=None signals an ADD operation (not an update of an
                # existing record).  do_change will get_or_create on forward and
                # delete on reverse.
                old_template=None,
                new_template=_TEMPLATE,
                coalesce=False,
            ),
        ),
    ),
)


def add_primary_ip4_field(
    apps: "apps_type", schema_editor: "BaseDatabaseSchemaEditor"
) -> None:
    """Add primary_ip4 relationship field to every Device Transform Map."""
    do_change(apps, schema_editor, TRANSFORM_MAP_ADDITIONS, forward=True)


def remove_primary_ip4_field(
    apps: "apps_type", schema_editor: "BaseDatabaseSchemaEditor"
) -> None:
    """Remove primary_ip4 relationship field from every Device Transform Map."""
    do_change(apps, schema_editor, TRANSFORM_MAP_ADDITIONS, forward=False)


class Migration(migrations.Migration):
    dependencies = [
        ("ipfabric_netbox", "0033_add_status_to_device_transform_maps"),
    ]

    operations = [
        migrations.RunPython(add_primary_ip4_field, remove_primary_ip4_field),
    ]
