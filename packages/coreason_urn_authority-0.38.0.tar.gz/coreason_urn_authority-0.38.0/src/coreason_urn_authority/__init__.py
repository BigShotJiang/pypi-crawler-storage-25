# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-urn-authority>
"""
coreason-urn-authority: The Cryptographic Trust Anchor & OCI Artifact Ledger.

This package acts as the decentralized cryptographic authority for all
URN-addressable capabilities within the CoReason ecosystem.  It maintains
a declarative YAML ledger mapping URNs to external OCI artifact URIs
and verifies supply-chain signatures using the industry-standard
Sigstore Cosign binary.

Part of the CoReason Tripartite Cybernetic Manifold.
"""

import importlib.metadata

try:
    __version__ = importlib.metadata.version("coreason_urn_authority")
except importlib.metadata.PackageNotFoundError:
    __version__ = "0.38.0"

__author__ = "Gowtham A Rao"
__email__ = "gowtham.rao@coreason.ai"
