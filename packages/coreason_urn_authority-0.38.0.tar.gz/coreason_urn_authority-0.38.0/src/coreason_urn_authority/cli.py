# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-urn-authority>

"""CoReason URN Authority CLI.

Commands:
    resolve <urn>   Resolve a URN to its cryptographically verified OCI artifact URI.
    list            List all URNs registered in the OCI Artifact Ledger.
"""

import argparse
import sys
from pathlib import Path

from coreason_urn_authority.crypto.cosign_verifier import (
    SubprocessRunner,
    TopologicalSeveranceEvent,
    verify_code_attestation,
)
from coreason_urn_authority.epistemic import EpistemicFilter, EpistemicValidationError
from coreason_urn_authority.ledger.loader import _DEFAULT_LEDGER_PATH, load_ledger
from coreason_urn_authority.ledger.promoter import append_to_ledger
from coreason_urn_authority.routing.semantic_router import resolve_capability


def main(
    args_list: list[str] | None = None,
    *,
    runner: SubprocessRunner | None = None,
) -> None:
    parser = argparse.ArgumentParser(description="CoReason URN Authority — OCI Trust Anchor CLI")
    subparsers = parser.add_subparsers(dest="command", required=True)

    # ── resolve ────────────────────────────────────────────────────
    resolve_parser = subparsers.add_parser(
        "resolve",
        help="Resolve a URN to its verified OCI artifact URI",
    )
    resolve_parser.add_argument("urn", type=str, help="The URN to resolve")
    resolve_parser.add_argument(
        "--ledger-path",
        type=str,
        default=None,
        help="Path to a custom ledger index.yaml",
    )

    # ── list ───────────────────────────────────────────────────────
    list_parser = subparsers.add_parser(
        "list",
        help="List all URNs in the OCI Artifact Ledger",
    )
    list_parser.add_argument(
        "--ledger-path",
        type=str,
        default=None,
        help="Path to a custom ledger index.yaml",
    )

    # ── promote ────────────────────────────────────────────────────
    promote_parser = subparsers.add_parser(
        "promote",
        help="Promote a URN from a testing network to the global ledger",
    )
    promote_parser.add_argument("--urn", type=str, required=True, help="The URN to promote")
    promote_parser.add_argument("--oci-uri", type=str, required=True, help="The OCI artifact URI")
    promote_parser.add_argument("--did", type=str, required=True, help="The authorized signer DID")
    promote_parser.add_argument(
        "--tenant-cid",
        type=str,
        default="urn:tenant:coreason:global:authority",
        help="Tenant CID (default: global authority)",
    )
    promote_parser.add_argument(
        "--mcp-namespace",
        type=str,
        default=None,
        help="Optional MCP Registry reverse-DNS namespace",
    )
    promote_parser.add_argument(
        "--dependency",
        type=str,
        action="append",
        default=None,
        help="Dependency URN for this capability (can be specified multiple times)",
    )
    promote_parser.add_argument(
        "--royalty-share",
        type=str,
        action="append",
        default=None,
        help="Royalty share split in format 'did:key:xyz=percentage' (can be specified multiple times)",
    )
    promote_parser.add_argument(
        "--payment-splitter-address",
        type=str,
        default=None,
        help="On-chain EVM address of the deployed PaymentSplitter contract",
    )
    promote_parser.add_argument(
        "--ledger-path",
        type=str,
        default=None,
        help="Path to a custom ledger index.yaml",
    )
    promote_parser.add_argument(
        "--skip-git",
        action="store_true",
        help="Skip local subprocess git operations (checkout, add, commit)",
    )

    # ── verify-attestation ─────────────────────────────────────────
    verify_attestation_parser = subparsers.add_parser(
        "verify-attestation",
        help="Verify zero-trust code attestation against sidecar hash",
    )
    verify_attestation_parser.add_argument("code_file", type=str, help="Path to the code file to attest")
    verify_attestation_parser.add_argument(
        "--expected-hash",
        type=str,
        default=None,
        help="Optional expected SHA-256 hash or path to hash file to verify against",
    )

    # ── filter-payload ─────────────────────────────────────────────
    filter_payload_parser = subparsers.add_parser(
        "filter-payload",
        help="Run epistemic filtering on high-entropy payload",
    )
    filter_payload_parser.add_argument(
        "schema_file", type=str, help="Path to the Python file containing Pydantic models"
    )
    filter_payload_parser.add_argument("model_name", type=str, help="Name of the Pydantic model to validate against")
    filter_payload_parser.add_argument("payload_file", type=str, help="Path to the raw JSON payload file")
    filter_payload_parser.add_argument(
        "--trigger-self-healing",
        action="store_true",
        help="Trigger the self-healing compilation loop on validation failure",
    )

    args = parser.parse_args(args_list)
    ledger_path = Path(args.ledger_path) if getattr(args, "ledger_path", None) else _DEFAULT_LEDGER_PATH

    if args.command == "resolve":
        try:
            receipt = resolve_capability(args.urn, ledger_path=ledger_path, runner=runner)
        except TopologicalSeveranceEvent as e:
            print(f"Error: {e}")
            sys.exit(1)

        print("--- Verified Capability Receipt ---")
        print(f"URN:    {receipt.urn}")
        print(f"OCI:    {receipt.oci_uri}")
        print(f"Signer: {receipt.authorized_signer_did}")

    elif args.command == "list":
        try:
            entries = load_ledger(ledger_path)
        except TopologicalSeveranceEvent as e:
            print(f"Error: {e}")
            sys.exit(1)

        if not entries:
            print("No capabilities registered in the ledger.")
            return

        print(f"--- OCI Artifact Ledger ({len(entries)} capabilities) ---")
        for entry in entries:
            print(f"  {entry.urn}")
            print(f"    OCI:    {entry.oci_uri}")
            print(f"    Signer: {entry.authorized_signer_did}")
            print()

    elif args.command == "promote":
        # Validate inputs
        if not args.urn.startswith("urn:coreason:"):
            print("Error: URN must follow the 'urn:coreason:' schema.")
            sys.exit(1)
        if not args.did.startswith("did:key:"):
            print("Error: Signer DID must follow the 'did:key:' format.")
            sys.exit(1)

        # Parse and validate royalty shares
        royalty_shares = {}
        if args.royalty_share:
            for share_str in args.royalty_share:
                if "=" not in share_str:
                    print("Error: Royalty share must be in format 'did:key:xyz=percentage'")
                    sys.exit(1)
                signer_did, pct_str = share_str.split("=", 1)
                if not signer_did.startswith("did:key:"):
                    print("Error: Royalty share DID must follow the 'did:key:' format.")
                    sys.exit(1)
                try:
                    pct = int(pct_str)
                except ValueError:
                    print(f"Error: Royalty share percentage must be an integer: {pct_str}")
                    sys.exit(1)
                royalty_shares[signer_did] = pct

            if royalty_shares and sum(royalty_shares.values()) != 100:
                print(f"Error: Royalty shares must sum to 100. Current sum: {sum(royalty_shares.values())}")
                sys.exit(1)

        # Sanitize branch name
        safe_urn = args.urn.replace(":", "-")
        branch_name = f"promote/{safe_urn}"

        print(f"Promoting {args.urn} to ledger at {ledger_path}")

        import os

        skip_git = args.skip_git or os.environ.get("COREASON_SKIP_GIT") in ("true", "1")

        # Checkout new branch
        import subprocess

        if not skip_git:
            try:
                subprocess.run(["git", "checkout", "-b", branch_name], check=True, cwd=ledger_path.parent)
            except subprocess.CalledProcessError as e:  # pragma: no cover
                print(f"Error creating git branch: {e}")
                sys.exit(1)

        # Append to ledger
        append_to_ledger(
            ledger_path=ledger_path,
            urn=args.urn,
            oci_uri=args.oci_uri,
            did=args.did,
            tenant_cid=args.tenant_cid,
            mcp_namespace=args.mcp_namespace,
            dependencies=args.dependency,
            royalty_shares=royalty_shares,
            payment_splitter_address=args.payment_splitter_address,
        )

        # Commit changes
        if not skip_git:
            try:
                subprocess.run(["git", "add", ledger_path.name], check=True, cwd=ledger_path.parent)
                subprocess.run(["git", "commit", "-m", f"feat: promote {args.urn}"], check=True, cwd=ledger_path.parent)
            except subprocess.CalledProcessError as e:  # pragma: no cover
                print(f"Error committing to git: {e}")
                sys.exit(1)

        if skip_git:
            print("\n--- Promotion Completed Successfully ---")
            print("Locally updated ledger file. Subprocess git operations skipped.")
        else:
            print("\n--- Promotion Staged Successfully ---")
            print(f"Locally committed to branch: {branch_name}")
        print("To complete the GitOps Release Protocol, run:")
        print(f"  git push origin {branch_name}")
        print('  gh pr create --title "feat: promote capability" --body "Human Oracle Review Requested."')
        print("Once approved and merged, the URN will be available on the global network.")

    elif args.command == "verify-attestation":
        try:
            expected_hash = args.expected_hash
            # If expected_hash is a path that exists, convert it to Path object
            if expected_hash and Path(expected_hash).exists():
                expected_hash = Path(expected_hash)
            verify_code_attestation(Path(args.code_file), expected_hash)
            print("Attestation succeeded: Code fingerprint matches signature.")
        except TopologicalSeveranceEvent as e:
            print(f"Error: {e}")
            sys.exit(1)

    elif args.command == "filter-payload":
        import json

        try:
            payload_content = Path(args.payload_file).read_text(encoding="utf-8")
        except Exception as e:
            print(f"Error reading payload file: {e}")
            sys.exit(1)

        filt = EpistemicFilter()
        try:
            res = filt.filter_payload(payload_content, Path(args.schema_file), args.model_name)
            print("Payload validation succeeded:")
            print(json.dumps(res, indent=2))
        except EpistemicValidationError as e:
            print(f"Validation Error: {e}")
            if args.trigger_self_healing:
                print("Triggering self-healing compilation loop...")
                try:
                    patched_code = filt.trigger_self_healing(Path(args.schema_file), args.model_name, e.failed_payload)
                    print("Self-healing successfully completed. Patched schema generated:")
                    print(patched_code[:200] + "\n...")
                except Exception as she:
                    print(f"Self-healing failed: {she}")
                    sys.exit(1)
            sys.exit(1)


if __name__ == "__main__":  # pragma: no cover
    main()
