# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

"""OCI Artifact Ledger Loader.

Loads and queries the declarative YAML index that maps CoReason URNs
to external OCI artifact URIs and their authorized signer DIDs.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any, Literal

import yaml
from coreason_manifest.spec.ontology import CoreasonBaseState
from pydantic import Field

from coreason_urn_authority.crypto.cosign_verifier import TopologicalSeveranceEvent

# ────────────────────────────────────────────────────────────────────
# Data Structures
# ────────────────────────────────────────────────────────────────────


class MCPRegistryRef(CoreasonBaseState):
    """AGENT INSTRUCTION: An optional reference mapping this URN to its equivalent
    public MCP Registry listing.

    CAUSAL AFFORDANCE: Enables the semantic router to link OCI artifacts to their
    HTTP-discoverable MCP counterparts for dual-publishing architectures.

    EPISTEMIC BOUNDS: Namespace must follow reverse-DNS format.

    MCP ROUTING TRIGGERS: MCP Registry, Cross-Reference, Dual-Publish
    """

    namespace: str = Field(
        description="The reverse-DNS namespace (e.g. io.github.username/server).",
        max_length=256,
    )
    registry_url: str = Field(
        description="The URL of the MCP Registry.",
        default="https://registry.modelcontextprotocol.io",
        max_length=512,
    )
    verified: bool = Field(
        description="Whether this capability has been Cosign verified against the registry.",
        default=True,
    )


class LedgerEntry(CoreasonBaseState):
    """AGENT INSTRUCTION: An immutable, cryptographically canonicalizable record in the
    OCI Artifact Ledger mapping a CoReason URN to its external OCI artifact URI and
    the DID of the authorized signer.

    CAUSAL AFFORDANCE: Enables the semantic router to resolve URNs to verified OCI
    artifact locations and extract the signer's public key for Cosign verification.

    EPISTEMIC BOUNDS: Frozen via CoreasonBaseState. URN pattern follows the CoReason
    namespace convention. OCI URI bounded to 512 characters. DID bounded to
    the did:key: format.

    MCP ROUTING TRIGGERS: OCI Artifact Ledger, URN Resolution, DID Key Mapping,
    Supply Chain Trust, Capability Registry
    """

    urn: str = Field(
        description="The CoReason Uniform Resource Name for this capability.",
        max_length=256,
    )
    oci_uri: str = Field(
        description="The OCI artifact URI (e.g. ghcr.io/coreason-ai/solver:v1).",
        max_length=512,
    )
    authorized_signer_did: str = Field(
        description="The W3C DID of the authorized signer (e.g. did:key:z6Mk...).",
        max_length=256,
    )
    tenant_cid: str = Field(
        description="The tenant capability identifier for zero-trust multi-tenancy isolation.",
        default="urn:tenant:coreason:global:authority",
        max_length=256,
    )
    mcp_registry: MCPRegistryRef | None = Field(
        description="Optional cross-reference to the public MCP Registry.",
        default=None,
    )
    license_tier: Literal["prosperity-3.0", "commercial"] = Field(
        description="The licensing class under which this capability was registered. "
        "'prosperity-3.0' = forged under the Prosperity Public License (copyright assigned to CoReason, Inc. via CLA). "
        "'commercial' = forged under a commercial license agreement (tenant retains IP sovereignty).",
        default="prosperity-3.0",
    )
    dependencies: list[str] = Field(
        description="The list of capability dependency URNs that this tool relies on.",
        default_factory=list,
    )
    royalty_shares: dict[str, int] = Field(
        description="The mapping of authorized did:key signers to their percentage of execution royalties (must sum to 100).",
        default_factory=dict,
    )
    payment_splitter_address: str | None = Field(
        description="The deployed Hyperledger Besu EVM contract address of the OpenZeppelin PaymentSplitter.",
        default=None,
        max_length=256,
    )


# ────────────────────────────────────────────────────────────────────
# Default Ledger Path
# ────────────────────────────────────────────────────────────────────

_DEFAULT_LEDGER_PATH = Path(__file__).parent / "index.yaml"


# ────────────────────────────────────────────────────────────────────
# Public API
# ────────────────────────────────────────────────────────────────────


def load_ledger(ledger_path: Path | None = None) -> list[LedgerEntry]:
    """Load the OCI artifact ledger from a YAML file.

    Args:
        ledger_path: Path to the ledger YAML file. Defaults to the
            package-bundled ``index.yaml``.

    Returns:
        A list of ``LedgerEntry`` objects.

    Raises:
        TopologicalSeveranceEvent: If the ledger file is missing or malformed.
    """
    path = ledger_path or _DEFAULT_LEDGER_PATH

    if not path.exists():
        raise TopologicalSeveranceEvent(f"OCI Ledger not found at {path}")

    # Impose a 10MB safety ceiling on local ledger index sizes
    max_bytes = 10 * 1024 * 1024
    file_size = path.stat().st_size
    if file_size > max_bytes:
        raise TopologicalSeveranceEvent(
            f"Epistemic Boundary Violation: Ledger size ({file_size} bytes) exceeds maximum security budget of {max_bytes} bytes."
        )

    raw: dict[str, Any] = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
    capabilities: list[dict[str, Any]] = raw.get("capabilities", [])

    entries: list[LedgerEntry] = []
    for cap in capabilities:
        try:
            entries.append(LedgerEntry.model_validate(cap))
        except Exception as e:
            raise TopologicalSeveranceEvent(f"Malformed ledger entry: missing required fields in {cap}: {e}") from e

    return entries


def resolve_urn(urn: str, ledger: list[LedgerEntry]) -> LedgerEntry:
    """Look up a URN in the ledger.

    Args:
        urn: The URN to resolve.
        ledger: The loaded ledger entries.

    Returns:
        The matching ``LedgerEntry``.

    Raises:
        TopologicalSeveranceEvent: If the URN is not found.
    """
    for entry in ledger:
        if entry.urn == urn:
            return entry

    available = [e.urn for e in ledger]
    raise TopologicalSeveranceEvent(f"URN '{urn}' not found in OCI Ledger. Available URNs: {available}")


# ────────────────────────────────────────────────────────────────────
# File-Mtime Ledger Cache (Sprint D: D1)
# ────────────────────────────────────────────────────────────────────


class _LedgerCache:
    """In-process cache for ledger entries, keyed on file path.

    Avoids re-parsing YAML and re-validating Pydantic models on every
    ``resolve_capability()`` call when the ledger file has not changed.
    Uses ``os.path.getmtime()`` to detect file modifications.
    """

    def __init__(self) -> None:
        self._entries: dict[str, list[LedgerEntry]] = {}
        self._mtimes: dict[str, float] = {}

    def get(self, path: Path | None = None) -> list[LedgerEntry]:
        """Return cached ledger entries, reloading only if the file changed."""
        resolved = str((path or _DEFAULT_LEDGER_PATH).resolve())

        try:
            current_mtime = (path or _DEFAULT_LEDGER_PATH).stat().st_mtime
        except OSError:
            # File doesn't exist or can't stat — fall through to load_ledger
            return load_ledger(path)

        cached_mtime = self._mtimes.get(resolved)
        if cached_mtime is not None and cached_mtime == current_mtime:
            return self._entries[resolved]

        # Cache miss or file changed — reload
        entries = load_ledger(path)
        self._entries[resolved] = entries
        self._mtimes[resolved] = current_mtime
        return entries

    def invalidate(self, path: Path | None = None) -> None:
        """Remove a specific path from the cache, or clear all if None."""
        if path is None:
            self._entries.clear()
            self._mtimes.clear()
        else:
            resolved = str(path.resolve())
            self._entries.pop(resolved, None)
            self._mtimes.pop(resolved, None)


# Module-level singleton
_ledger_cache = _LedgerCache()


def cached_load_ledger(ledger_path: Path | None = None) -> list[LedgerEntry]:
    """Load ledger entries with file-mtime caching.

    Returns the same list object on repeated calls as long as the
    underlying YAML file has not been modified on disk.

    Args:
        ledger_path: Path to the ledger YAML file. Defaults to the
            package-bundled ``index.yaml``.

    Returns:
        A list of ``LedgerEntry`` objects.

    Raises:
        TopologicalSeveranceEvent: If the ledger file is missing or malformed.
    """
    return _ledger_cache.get(ledger_path)
