# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-urn-authority>

"""Tests for the URN Authority CLI.

Uses real YAML ledger files and dependency inversion for cosign.
"""

from __future__ import annotations

import json
import subprocess
from pathlib import Path

import pytest
import yaml

from coreason_urn_authority.cli import main


def _write_test_ledger(tmp_path: Path) -> Path:
    """Write a test ledger with a valid Ed25519 DID."""
    raw_pubkey = bytes(32)
    multicodec_bytes = b"\xed\x01" + raw_pubkey
    n = int.from_bytes(multicodec_bytes, "big")
    alphabet = b"123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz"
    chars: list[int] = []
    while n > 0:
        n, remainder = divmod(n, 58)
        chars.append(alphabet[remainder])
    for byte in multicodec_bytes:
        if byte == 0:
            chars.append(alphabet[0])
        else:
            break
    encoded = bytes(reversed(chars)).decode("ascii")
    did_key = f"did:key:z{encoded}"

    ledger_path = tmp_path / "index.yaml"
    ledger_path.write_text(
        yaml.dump(
            {
                "capabilities": [
                    {
                        "urn": "urn:coreason:solver:test_v1",
                        "oci_uri": "ghcr.io/coreason-ai/test-solver:v1.0.0",
                        "authorized_signer_did": did_key,
                    },
                    {
                        "urn": "urn:coreason:oracle:extractor_v1",
                        "oci_uri": "ghcr.io/coreason-ai/extractor:v2.0.0",
                        "authorized_signer_did": did_key,
                    },
                ]
            },
            default_flow_style=False,
        ),
        encoding="utf-8",
    )
    return ledger_path


def _success_runner(*args: object, **kwargs: object) -> subprocess.CompletedProcess[str]:
    return subprocess.CompletedProcess(
        args=["cosign", "verify"],
        returncode=0,
        stdout=json.dumps([{"critical": {}}]),
        stderr="",
    )


class TestCLIList:
    """Tests for the 'list' command."""

    def test_list_success(self, tmp_path: Path, capsys: pytest.CaptureFixture[str]) -> None:
        ledger_path = _write_test_ledger(tmp_path)
        main(["list", "--ledger-path", str(ledger_path)])
        captured = capsys.readouterr()
        assert "2 capabilities" in captured.out
        assert "urn:coreason:solver:test_v1" in captured.out
        assert "urn:coreason:oracle:extractor_v1" in captured.out

    def test_list_empty(self, tmp_path: Path, capsys: pytest.CaptureFixture[str]) -> None:
        ledger_path = tmp_path / "index.yaml"
        ledger_path.write_text(yaml.dump({"capabilities": []}), encoding="utf-8")
        main(["list", "--ledger-path", str(ledger_path)])
        captured = capsys.readouterr()
        assert "No capabilities" in captured.out

    def test_list_missing_ledger(self, tmp_path: Path, capsys: pytest.CaptureFixture[str]) -> None:
        with pytest.raises(SystemExit) as excinfo:
            main(["list", "--ledger-path", str(tmp_path / "missing.yaml")])
        assert excinfo.value.code == 1
        captured = capsys.readouterr()
        assert "Error:" in captured.out


class TestCLIResolve:
    """Tests for the 'resolve' command."""

    def test_resolve_success(self, tmp_path: Path, capsys: pytest.CaptureFixture[str]) -> None:
        ledger_path = _write_test_ledger(tmp_path)
        # Inject the success runner directly via dependency injection (NO MOCKS!)
        main(
            ["resolve", "urn:coreason:solver:test_v1", "--ledger-path", str(ledger_path)],
            runner=_success_runner,
        )
        captured = capsys.readouterr()
        assert "Verified Capability Receipt" in captured.out
        assert "urn:coreason:solver:test_v1" in captured.out
        assert "ghcr.io/coreason-ai/test-solver:v1.0.0" in captured.out

    def test_resolve_unknown_urn(self, tmp_path: Path, capsys: pytest.CaptureFixture[str]) -> None:
        ledger_path = _write_test_ledger(tmp_path)
        with pytest.raises(SystemExit) as excinfo:
            main(["resolve", "urn:coreason:solver:nonexistent_v1", "--ledger-path", str(ledger_path)])
        assert excinfo.value.code == 1
        captured = capsys.readouterr()
        assert "Error:" in captured.out


class TestCLIPromote:
    """Tests for the 'promote' command."""

    def test_promote_invalid_urn(self, tmp_path: Path) -> None:
        ledger_path = _write_test_ledger(tmp_path)
        with pytest.raises(SystemExit) as excinfo:
            main(
                [
                    "promote",
                    "--urn",
                    "invalid:urn",
                    "--oci-uri",
                    "ghcr.io/test:v1",
                    "--did",
                    "did:key:z123",
                    "--ledger-path",
                    str(ledger_path),
                ]
            )
        assert excinfo.value.code == 1

    def test_promote_invalid_did(self, tmp_path: Path) -> None:
        ledger_path = _write_test_ledger(tmp_path)
        with pytest.raises(SystemExit) as excinfo:
            main(
                [
                    "promote",
                    "--urn",
                    "urn:coreason:solver:test_v2",
                    "--oci-uri",
                    "ghcr.io/test:v1",
                    "--did",
                    "did:web:example.com",
                    "--ledger-path",
                    str(ledger_path),
                ]
            )
        assert excinfo.value.code == 1

    def test_promote_success(self, tmp_path: Path, capsys: pytest.CaptureFixture[str]) -> None:
        # Initialize a real git repository in tmp_path to support real git operations
        import subprocess

        subprocess.run(["git", "init"], check=True, cwd=tmp_path)
        subprocess.run(["git", "config", "user.name", "Test User"], check=True, cwd=tmp_path)
        subprocess.run(["git", "config", "user.email", "test@example.com"], check=True, cwd=tmp_path)

        # Write initial ledger and commit it
        ledger_path = _write_test_ledger(tmp_path)
        subprocess.run(["git", "add", ledger_path.name], check=True, cwd=tmp_path)
        subprocess.run(["git", "commit", "-m", "initial commit"], check=True, cwd=tmp_path)

        # Run promote command
        main(
            [
                "promote",
                "--urn",
                "urn:coreason:solver:promoted_v1",
                "--oci-uri",
                "ghcr.io/coreason-ai/promoted-solver:v1.0.0",
                "--did",
                "did:key:z6MkhaXgBZDvotDkL5257faiztiuC2ZXsdY4SSgMnh3YEFWbYB",
                "--ledger-path",
                str(ledger_path),
                "--mcp-namespace",
                "com.coreason.solver",
            ]
        )

        captured = capsys.readouterr()
        assert "Promotion Staged Successfully" in captured.out

        # Verify the ledger indeed was appended
        content = ledger_path.read_text(encoding="utf-8")
        assert "urn:coreason:solver:promoted_v1" in content
        assert "ghcr.io/coreason-ai/promoted-solver:v1.0.0" in content
        assert "did:key:z6MkhaXgBZDvotDkL5257faiztiuC2ZXsdY4SSgMnh3YEFWbYB" in content
        assert "com.coreason.solver" in content

        # Check git branch was created and file was committed
        res = subprocess.run(["git", "branch", "--show-current"], capture_output=True, text=True, cwd=tmp_path)
        assert res.stdout.strip() == "promote/urn-coreason-solver-promoted_v1"

    def test_promote_skip_git_flag(self, tmp_path: Path, capsys: pytest.CaptureFixture[str]) -> None:
        ledger_path = _write_test_ledger(tmp_path)

        # Run promote command with --skip-git
        main(
            [
                "promote",
                "--urn",
                "urn:coreason:solver:promoted_v2",
                "--oci-uri",
                "ghcr.io/coreason-ai/promoted-solver:v2.0.0",
                "--did",
                "did:key:z6MkhaXgBZDvotDkL5257faiztiuC2ZXsdY4SSgMnh3YEFWbYB",
                "--ledger-path",
                str(ledger_path),
                "--skip-git",
            ]
        )

        captured = capsys.readouterr()
        assert "Promotion Completed Successfully" in captured.out
        assert "Subprocess git operations skipped." in captured.out

        # Verify the ledger indeed was appended
        content = ledger_path.read_text(encoding="utf-8")
        assert "urn:coreason:solver:promoted_v2" in content

    def test_promote_skip_git_env(self, tmp_path: Path, capsys: pytest.CaptureFixture[str]) -> None:
        ledger_path = _write_test_ledger(tmp_path)

        import os

        old_val = os.environ.get("COREASON_SKIP_GIT")
        try:
            os.environ["COREASON_SKIP_GIT"] = "true"
            main(
                [
                    "promote",
                    "--urn",
                    "urn:coreason:solver:promoted_v3",
                    "--oci-uri",
                    "ghcr.io/coreason-ai/promoted-solver:v3.0.0",
                    "--did",
                    "did:key:z6MkhaXgBZDvotDkL5257faiztiuC2ZXsdY4SSgMnh3YEFWbYB",
                    "--ledger-path",
                    str(ledger_path),
                ]
            )
        finally:
            if old_val is not None:
                os.environ["COREASON_SKIP_GIT"] = old_val
            else:
                del os.environ["COREASON_SKIP_GIT"]

        captured = capsys.readouterr()
        assert "Promotion Completed Successfully" in captured.out

    def test_promote_with_tokenized_mesh_options(self, tmp_path: Path, capsys: pytest.CaptureFixture[str]) -> None:
        ledger_path = _write_test_ledger(tmp_path)

        main(
            [
                "promote",
                "--urn",
                "urn:coreason:solver:promoted_mesh_v1",
                "--oci-uri",
                "ghcr.io/coreason-ai/promoted-mesh:v1.0.0",
                "--did",
                "did:key:z6MkhaXgBZDvotDkL5257faiztiuC2ZXsdY4SSgMnh3YEFWbYB",
                "--ledger-path",
                str(ledger_path),
                "--skip-git",
                "--dependency",
                "urn:coreason:solver:test_v1",
                "--dependency",
                "urn:coreason:oracle:extractor_v1",
                "--royalty-share",
                "did:key:z6MkhaXgBZDvotDkL5257faiztiuC2ZXsdY4SSgMnh3YEFWbYB=60",
                "--royalty-share",
                "did:key:z6MkqRYqQiSgvZQdnBytw86Qbs2ZWUkGv22od935YF4s8M7V=40",
                "--payment-splitter-address",
                "0x70997970C51812dc3A010C7d01b50e0d17dc79C8",
            ]
        )

        captured = capsys.readouterr()
        assert "Promotion Completed Successfully" in captured.out

        # Load back ledger and verify fields
        from coreason_urn_authority.ledger.loader import load_ledger
        entries = load_ledger(ledger_path)
        matching = [e for e in entries if e.urn == "urn:coreason:solver:promoted_mesh_v1"]
        assert len(matching) == 1
        entry = matching[0]
        assert entry.dependencies == ["urn:coreason:solver:test_v1", "urn:coreason:oracle:extractor_v1"]
        assert entry.royalty_shares == {
            "did:key:z6MkhaXgBZDvotDkL5257faiztiuC2ZXsdY4SSgMnh3YEFWbYB": 60,
            "did:key:z6MkqRYqQiSgvZQdnBytw86Qbs2ZWUkGv22od935YF4s8M7V": 40,
        }
        assert entry.payment_splitter_address == "0x70997970C51812dc3A010C7d01b50e0d17dc79C8"

    def test_promote_royalty_shares_not_sum_to_100(self, tmp_path: Path) -> None:
        ledger_path = _write_test_ledger(tmp_path)
        with pytest.raises(SystemExit) as excinfo:
            main(
                [
                    "promote",
                    "--urn",
                    "urn:coreason:solver:promoted_mesh_v2",
                    "--oci-uri",
                    "ghcr.io/coreason-ai/promoted-mesh:v1.0.0",
                    "--did",
                    "did:key:z6MkhaXgBZDvotDkL5257faiztiuC2ZXsdY4SSgMnh3YEFWbYB",
                    "--ledger-path",
                    str(ledger_path),
                    "--skip-git",
                    "--royalty-share",
                    "did:key:z6MkhaXgBZDvotDkL5257faiztiuC2ZXsdY4SSgMnh3YEFWbYB=60",
                    "--royalty-share",
                    "did:key:z6MkqRYqQiSgvZQdnBytw86Qbs2ZWUkGv22od935YF4s8M7V=30",
                ]
            )
        assert excinfo.value.code == 1
