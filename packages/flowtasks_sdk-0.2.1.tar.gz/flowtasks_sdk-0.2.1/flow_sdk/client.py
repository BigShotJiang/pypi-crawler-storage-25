"""Flow Python SDK client.

Wraps the Flow API with typed methods for document management,
chat/RAG queries, knowledge graph operations, agent triggers,
ontology management, legal analysis, workflows, and compliance.

Usage::

    from flow_sdk import FlowClient

    client = FlowClient(base_url="https://api.flowtasks.io", api_key="your-key")

    # Upload a document
    doc = client.upload_document("contract.pdf", open("contract.pdf", "rb"))

    # Ask a question
    answer = client.chat("What are the key terms?", organization_id="org-123")

    # Legal analysis
    clauses = client.legal_query("termination clauses", mode="deterministic")
"""

from __future__ import annotations

from typing import Any, BinaryIO, Dict, List, Optional

import httpx


class FlowAPIError(Exception):
    def __init__(self, status_code: int, detail: str):
        self.status_code = status_code
        self.detail = detail
        super().__init__(f"HTTP {status_code}: {detail}")


class FlowClient:
    """Synchronous Python client for the Flow API."""

    def __init__(
        self,
        base_url: str = "http://localhost:8000",
        api_key: str = "",
        organization_id: Optional[str] = None,
        timeout: float = 60.0,
    ):
        self._base = base_url.rstrip("/")
        self._api_key = api_key
        self._org_id = organization_id
        headers: Dict[str, str] = {
            "X-API-Key": api_key,
            "Content-Type": "application/json",
        }
        if organization_id:
            headers["X-Organization-ID"] = organization_id
        self._client = httpx.Client(
            base_url=f"{self._base}/api/v1",
            headers=headers,
            timeout=timeout,
        )

    def close(self) -> None:
        self._client.close()

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()

    def _request(self, method: str, path: str, **kwargs) -> Any:
        resp = self._client.request(method, path, **kwargs)
        if resp.status_code >= 400:
            try:
                detail = resp.json().get("detail", resp.text)
            except Exception:
                detail = resp.text
            raise FlowAPIError(resp.status_code, detail)
        if resp.status_code == 204:
            return None
        return resp.json()

    # ── Health ────────────────────────────────────────────────────────

    def health(self) -> Dict[str, Any]:
        return self._request("GET", "/health")

    # ── Documents ─────────────────────────────────────────────────────

    def upload_document(
        self,
        filename: str,
        file: BinaryIO,
        organization_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        files = {"file": (filename, file)}
        data: Dict[str, str] = {}
        if organization_id:
            data["organization_id"] = organization_id
        return self._client.post(
            "/documents/upload",
            files=files,
            data=data,
            headers={"X-API-Key": self._api_key},
        ).json()

    def list_documents(
        self, organization_id: Optional[str] = None, skip: int = 0, limit: int = 50
    ) -> Dict[str, Any]:
        params: Dict[str, Any] = {"skip": skip, "limit": limit}
        if organization_id:
            params["organization_id"] = organization_id
        return self._request("GET", "/documents", params=params)

    def get_document(self, document_id: str) -> Dict[str, Any]:
        return self._request("GET", f"/documents/{document_id}")

    def delete_document(self, document_id: str) -> None:
        self._request("DELETE", f"/documents/{document_id}")

    # ── Chat / RAG ────────────────────────────────────────────────────

    def chat(
        self,
        message: str,
        session_id: Optional[str] = None,
        organization_id: Optional[str] = None,
        use_multi_agent: bool = False,
    ) -> Dict[str, Any]:
        body: Dict[str, Any] = {"message": message}
        if session_id:
            body["session_id"] = session_id
        if organization_id:
            body["organization_id"] = organization_id
        if use_multi_agent:
            body["use_multi_agent"] = True
        return self._request("POST", "/chat", json=body)

    # ── Knowledge Graph ───────────────────────────────────────────────

    def search_graph(
        self, query: str, organization_id: Optional[str] = None
    ) -> Dict[str, Any]:
        params: Dict[str, Any] = {"q": query}
        if organization_id:
            params["organization_id"] = organization_id
        return self._request("GET", "/knowledge-graph/search", params=params)

    def get_graph_stats(self, organization_id: Optional[str] = None) -> Dict[str, Any]:
        params: Dict[str, Any] = {}
        if organization_id:
            params["organization_id"] = organization_id
        return self._request("GET", "/knowledge-graph/stats", params=params)

    def ask_graph(self, question: str) -> Dict[str, Any]:
        return self._request("POST", "/knowledge-graph/ask", json={"question": question})

    def reason_graph(
        self, question: str, category: Optional[str] = None
    ) -> Dict[str, Any]:
        body: Dict[str, Any] = {"question": question}
        if category:
            body["category"] = category
        return self._request("POST", "/knowledge-graph/reason", json=body)

    def get_graph_visualization(self, limit: int = 500) -> Dict[str, Any]:
        return self._request("GET", "/knowledge-graph/visualization", params={"limit": limit})

    def get_entity_neighbors(self, entity_name: str, depth: int = 1) -> Dict[str, Any]:
        return self._request(
            "GET", f"/knowledge-graph/neighbors/{entity_name}", params={"depth": depth}
        )

    # ── Agent ─────────────────────────────────────────────────────────

    def agent_run(
        self,
        query: Optional[str] = None,
        trigger_type: str = "manual",
        context: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        body: Dict[str, Any] = {"trigger_type": trigger_type}
        if query:
            body["query"] = query
        if context:
            body["context"] = context
        return self._request("POST", "/agent/run", json=body)

    def list_agent_runs(self, skip: int = 0, limit: int = 50) -> Dict[str, Any]:
        return self._request("GET", "/agent/runs", params={"skip": skip, "limit": limit})

    def list_risk_signals(self, skip: int = 0, limit: int = 50) -> Dict[str, Any]:
        return self._request("GET", "/agent/risk-signals", params={"skip": skip, "limit": limit})

    # ── Ontology ──────────────────────────────────────────────────────

    def list_domains(self) -> Dict[str, Any]:
        return self._request("GET", "/ontology/domains")

    def get_domain(self, domain: str) -> Dict[str, Any]:
        return self._request("GET", f"/ontology/domains/{domain}")

    def create_ontology(
        self,
        name: str,
        entity_types: Optional[List[str]] = None,
        relationship_types: Optional[List[str]] = None,
        relation_rules: Optional[List[Dict[str, Any]]] = None,
        description: str = "",
    ) -> Dict[str, Any]:
        body: Dict[str, Any] = {"name": name, "description": description}
        if entity_types:
            body["entity_types"] = [{"name": et} for et in entity_types]
        if relationship_types:
            body["relationship_types"] = relationship_types
        if relation_rules:
            body["relation_rules"] = relation_rules
        return self._request("POST", "/ontology/custom", json=body)

    def list_custom_ontologies(self) -> Dict[str, Any]:
        return self._request("GET", "/ontology/custom")

    def get_custom_ontology(self, ontology_id: str) -> Dict[str, Any]:
        return self._request("GET", f"/ontology/custom/{ontology_id}")

    def update_ontology(self, ontology_id: str, **fields) -> Dict[str, Any]:
        return self._request("PUT", f"/ontology/custom/{ontology_id}", json=fields)

    def delete_ontology(self, ontology_id: str) -> None:
        self._request("DELETE", f"/ontology/custom/{ontology_id}")

    def get_resolved_ontology(self, domain: str) -> Dict[str, Any]:
        return self._request("GET", f"/ontology/resolved/{domain}")

    # ── Legal Analysis ────────────────────────────────────────────────

    def legal_clause_types(self) -> Dict[str, Any]:
        return self._request("GET", "/legal/clause-types")

    def legal_clauses(self, document_id: str) -> Dict[str, Any]:
        return self._request("GET", f"/legal/clauses/{document_id}")

    def legal_diff(self, doc_a: str, doc_b: str) -> Dict[str, Any]:
        return self._request("GET", "/legal/diff", params={"doc_a": doc_a, "doc_b": doc_b})

    def legal_query(
        self,
        query: str,
        mode: str = "auto",
        clause_types: Optional[List[str]] = None,
        condition_filters: Optional[Dict[str, str]] = None,
        has_obligations: Optional[bool] = None,
    ) -> Dict[str, Any]:
        body: Dict[str, Any] = {"query": query, "mode": mode}
        if clause_types:
            body["clause_types"] = clause_types
        if condition_filters:
            body["condition_filters"] = condition_filters
        if has_obligations is not None:
            body["has_obligations"] = has_obligations
        return self._request("POST", "/legal/query", json=body)

    # ── Workflows ─────────────────────────────────────────────────────

    def list_workflows(self) -> Dict[str, Any]:
        return self._request("GET", "/workflows")

    def create_workflow(
        self,
        name: str,
        steps: List[Dict[str, Any]],
        description: str = "",
        is_active: bool = True,
    ) -> Dict[str, Any]:
        return self._request("POST", "/workflows", json={
            "name": name,
            "description": description,
            "steps_json": steps,
            "is_active": is_active,
        })

    def run_workflow(self, workflow_id: str, input_data: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        body: Dict[str, Any] = {}
        if input_data:
            body["input_data"] = input_data
        return self._request("POST", f"/workflows/{workflow_id}/run", json=body)

    # ── Compliance ────────────────────────────────────────────────────

    def list_compliance_checks(self) -> Dict[str, Any]:
        return self._request("GET", "/compliance/checks")

    def run_compliance_scan(
        self,
        document_id: Optional[str] = None,
        framework: str = "general",
    ) -> Dict[str, Any]:
        body: Dict[str, Any] = {"framework": framework}
        if document_id:
            body["document_id"] = document_id
        return self._request("POST", "/compliance/scan", json=body)

    # ── Webhooks ──────────────────────────────────────────────────────

    def list_webhooks(self) -> Dict[str, Any]:
        return self._request("GET", "/webhooks")

    def create_webhook(
        self,
        url: str,
        events: List[str],
        name: str = "",
    ) -> Dict[str, Any]:
        return self._request("POST", "/webhooks", json={
            "url": url,
            "events": events,
            "name": name,
        })

    # ── Usage ─────────────────────────────────────────────────────────

    def get_usage(self, organization_id: Optional[str] = None) -> Dict[str, Any]:
        params: Dict[str, Any] = {}
        if organization_id:
            params["organization_id"] = organization_id
        return self._request("GET", "/usage", params=params)


class AsyncFlowClient:
    """Async Python client for the Flow API."""

    def __init__(
        self,
        base_url: str = "http://localhost:8000",
        api_key: str = "",
        organization_id: Optional[str] = None,
        timeout: float = 60.0,
    ):
        self._base = base_url.rstrip("/")
        self._api_key = api_key
        headers: Dict[str, str] = {
            "X-API-Key": api_key,
            "Content-Type": "application/json",
        }
        if organization_id:
            headers["X-Organization-ID"] = organization_id
        self._client = httpx.AsyncClient(
            base_url=f"{self._base}/api/v1",
            headers=headers,
            timeout=timeout,
        )

    async def close(self) -> None:
        await self._client.aclose()

    async def __aenter__(self):
        return self

    async def __aexit__(self, *args):
        await self.close()

    async def _request(self, method: str, path: str, **kwargs) -> Any:
        resp = await self._client.request(method, path, **kwargs)
        if resp.status_code >= 400:
            try:
                detail = resp.json().get("detail", resp.text)
            except Exception:
                detail = resp.text
            raise FlowAPIError(resp.status_code, detail)
        if resp.status_code == 204:
            return None
        return resp.json()

    async def health(self) -> Dict[str, Any]:
        return await self._request("GET", "/health")

    async def chat(self, message: str, **kwargs) -> Dict[str, Any]:
        body: Dict[str, Any] = {"message": message, **kwargs}
        return await self._request("POST", "/chat", json=body)

    async def upload_document(self, filename: str, file: BinaryIO, **kwargs) -> Dict[str, Any]:
        files = {"file": (filename, file)}
        resp = await self._client.post("/documents/upload", files=files, data=kwargs, headers={"X-API-Key": self._api_key})
        if resp.status_code >= 400:
            raise FlowAPIError(resp.status_code, resp.text)
        return resp.json()

    async def list_documents(self, **kwargs) -> Dict[str, Any]:
        return await self._request("GET", "/documents", params=kwargs)

    async def search_graph(self, query: str, **kwargs) -> Dict[str, Any]:
        return await self._request("GET", "/knowledge-graph/search", params={"q": query, **kwargs})

    async def ask_graph(self, question: str) -> Dict[str, Any]:
        return await self._request("POST", "/knowledge-graph/ask", json={"question": question})

    async def reason_graph(self, question: str, **kwargs) -> Dict[str, Any]:
        body: Dict[str, Any] = {"question": question, **kwargs}
        return await self._request("POST", "/knowledge-graph/reason", json=body)

    async def agent_run(self, query: Optional[str] = None, **kwargs) -> Dict[str, Any]:
        body: Dict[str, Any] = {"trigger_type": "manual", **kwargs}
        if query:
            body["query"] = query
        return await self._request("POST", "/agent/run", json=body)

    async def list_domains(self) -> Dict[str, Any]:
        return await self._request("GET", "/ontology/domains")

    async def create_ontology(self, name: str, **kwargs) -> Dict[str, Any]:
        body: Dict[str, Any] = {"name": name, **kwargs}
        return await self._request("POST", "/ontology/custom", json=body)

    async def legal_query(self, query: str, **kwargs) -> Dict[str, Any]:
        body: Dict[str, Any] = {"query": query, **kwargs}
        return await self._request("POST", "/legal/query", json=body)

    async def legal_clauses(self, document_id: str) -> Dict[str, Any]:
        return await self._request("GET", f"/legal/clauses/{document_id}")

    async def legal_diff(self, doc_a: str, doc_b: str) -> Dict[str, Any]:
        return await self._request("GET", "/legal/diff", params={"doc_a": doc_a, "doc_b": doc_b})

    async def list_workflows(self) -> Dict[str, Any]:
        return await self._request("GET", "/workflows")

    async def run_workflow(self, workflow_id: str, **kwargs) -> Dict[str, Any]:
        return await self._request("POST", f"/workflows/{workflow_id}/run", json=kwargs)

    async def get_usage(self, **kwargs) -> Dict[str, Any]:
        return await self._request("GET", "/usage", params=kwargs)
