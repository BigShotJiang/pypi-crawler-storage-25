from setuptools import setup, find_packages

setup(
    name="flow-sdk",
    version="0.2.0",
    description="Python SDK for the Flowtasks Intelligence Engine API",
    author="Flow Tasks",
    author_email="dev@flowtasks.io",
    url="https://github.com/flowtasks/flow-sdk-python",
    packages=find_packages(),
    python_requires=">=3.9",
    install_requires=[
        "httpx>=0.25.0",
    ],
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
    ],
)
