from dataclasses import dataclass
from typing import List, Dict, Any, Callable
from .helpers import parseUserUploadFiles, split_images_from_md, is_base64_image


class LLMTools:
    def __init__(self, gen_stream: Callable, gen: Callable):
        self.gen_stream = gen_stream
        self.gen = gen


class FSTools:
    def __init__(self, upload_file: Callable):
        self.upload_file = upload_file


class Helpers:
    def __init__(self):
        self.parseUserUploadFiles = parseUserUploadFiles
        self.split_images_from_md = split_images_from_md
        self.is_base64_image = is_base64_image


@dataclass
class Context:
    messages: List[Dict[str, Any]]
    extra_params: Dict[str, Any]
    llm: LLMTools
    fs: FSTools
    mcp: Any
    helpers: Helpers
