from urllib.parse import urlparse
import os
import re
import requests

docling_service = "https://oac500-docling.oasishpc.hk/v1/convert/source"

IMAGE_PATTERN = r"(!\[.*?\]\(data:image\/.*?;base64,.*?\))"
SEPARATORS = [r"\n## ", r"\n\n", r"\n", r" ", r""]

need_parse_types = [".pdf", ".docx", ".xlsx", ".pptx", ".csv", ".md", ".html"]
plaintext_types = [".txt", ".py", ".js", ".json", ".yaml", ".yml", ".c", ".cpp", ".sh"]


def extract_file_extension(url):
    parsed_url = urlparse(url)
    path = parsed_url.path
    filename = os.path.basename(path)
    file_root, extension = os.path.splitext(filename)

    return extension


def docling_parse(url):
    payload = {"sources": [{"kind": "http", "url": url}], "to_formats": ["md"]}
    headers = {"Content-Type": "application/json"}
    response = requests.post(
        docling_service, json=payload, headers=headers, timeout=300
    )

    if response.status_code == 200:
        data = response.json()
        file_name = data["document"]["filename"]
        markdown_content = data["document"]["md_content"]
        return file_name, markdown_content
    else:
        print(f"Error: Received status {response.status_code}. Body: {response.text}")
        return "Fail", "Fail to parse document"


def parseUserUploadFiles(messages):
    last_message = messages[-1]
    for i, content in enumerate(last_message["content"]):
        if content["type"] == "file_url":
            file_url = content["file_url"]["url"]
            file_type = extract_file_extension(file_url)

            combined_text = None

            if file_type in need_parse_types:
                # file_url = "https://pdfobject.com/pdf/sample.pdf"
                # file_url = "https://arxiv.org/pdf/2408.09869.pdf"
                file_name, md = docling_parse(file_url)
                combined_text = f"Uploaded file ({file_name}):\n{md}"
            elif file_type in plaintext_types:
                try:
                    # file_url = "https://raw.githubusercontent.com/python/cpython/main/Lib/antigravity.py"
                    resp = requests.get(file_url, timeout=10)
                    resp.raise_for_status()
                    file_name = os.path.basename(urlparse(file_url).path)
                    combined_text = f"Uploaded text file ({file_name}):\n{resp.text}"
                except Exception as e:
                    combined_text = f"Error reading text file: {str(e)}"
            else:
                continue
            last_message["content"][i]["file_url"]["url"] = combined_text


def approx_token_count(text):
    char_count = len(text)
    tokens_by_char = char_count // 4
    # word_count = len(text.split())
    # tokens_by_word = int(word_count / 0.75)
    # return max(tokens_by_char, tokens_by_word)
    return tokens_by_char


def split_images_from_md(md):
    parts = re.split(IMAGE_PATTERN, md, flags=re.DOTALL)
    return parts


def is_base64_image(text):
    return bool(re.fullmatch(IMAGE_PATTERN, text, flags=re.DOTALL))
