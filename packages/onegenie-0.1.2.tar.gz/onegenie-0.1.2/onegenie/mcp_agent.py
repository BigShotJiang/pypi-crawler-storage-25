from json_repair import repair_json

from contextlib import AsyncExitStack
from typing import Optional

from mcp import ClientSession
from mcp.client.sse import sse_client


class MCPAgent:
    def __init__(self, dgg_url: str, api_token: str, default_gen_stream=None):
        self.dgg_url = dgg_url
        self.api_token = api_token
        self.exit_stack = AsyncExitStack()
        self.dgg: Optional[ClientSession] = None
        self.messages = []
        self.default_gen_stream = default_gen_stream

    async def __aenter__(self):
        """進入 async with 區塊時自動觸發"""
        await self.start()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """離開 async with 區塊時自動觸發（即使發生 Exception 也會執行）"""
        # exc_type, exc_val, exc_tb 是用來捕捉區塊內發生錯誤時的資訊
        # 在這裡我們只需要確保資源被正確關閉即可
        await self.stop()

    async def start(self):
        """建立與 DGG 的連線，並傳入 User Context Headers"""
        print("Connecting to DGG...")

        # [關鍵] 我們把 User Context 放在 Header 傳給 DGG
        # DGG 的 handle_sse 需要修改以讀取這些 Headers 來做 OPA Filtering
        headers = {"X-JWT-TOKEN": self.api_token}

        # 使用 AsyncExitStack 管理 Context Manager
        sse_transport = await self.exit_stack.enter_async_context(
            sse_client(self.dgg_url, headers=headers)
        )
        self.dgg = await self.exit_stack.enter_async_context(
            ClientSession(sse_transport[0], sse_transport[1])
        )

        await self.dgg.initialize()
        print("✅ Connected & Initialized!")

    def _convert_mcp_to_openai_tools(self, mcp_tools):
        """[關鍵] 將 MCP 工具格式轉換為 OpenAI/vLLM 格式"""
        openai_tools = []
        for tool in mcp_tools.tools:
            openai_tools.append(
                {
                    "type": "function",
                    "function": {
                        "name": tool.name,
                        "description": tool.description,
                        "parameters": tool.inputSchema,  # MCP Schema 相容 JSON Schema
                    },
                }
            )
        return openai_tools

    def _robust_parse_arguments(self, args_str: str) -> dict:
        if not args_str:
            return {}

        args_str = args_str.strip()

        # --- 第一道防線：手動補全結構 ---
        # 如果不像是一個物件的開頭，我們強制幫它補上 '{'
        if not args_str.startswith("{"):
            # 你的案例會在這裡被修復
            args_str = "{" + args_str

        # 同理，如果沒結尾，補上 '}'
        if not args_str.endswith("}"):
            args_str = args_str + "}"

        # --- 第二道防線：json_repair 修復語法 ---
        # 這裡會處理單引號、trailing comma、未轉義字符等細節
        try:
            decoded = repair_json(args_str, return_objects=True)

            # [重要] 確保回傳的一定是 dict
            # 有時候 json_repair 修復失敗會回傳原始字串，這會導致後續報錯
            if isinstance(decoded, dict):
                return decoded
            elif isinstance(decoded, list):
                # 極少見情況，但以防萬一
                return {"items": decoded}
            else:
                # 如果回傳的是字串，代表修復失敗或內容根本不是 JSON
                print(f"⚠️ json_repair returned non-dict: {type(decoded)}")
                # 嘗試最後一次暴力解析 (針對 key: value 這種格式)
                return self._fallback_parse(args_str)

        except Exception as e:
            print(f"❌ JSON Parsing Failed: {e}")
            return {}

    async def chat(self, history: list):
        if not self.dgg:
            raise RuntimeError("Agent not started")

        self.messages = history

        # 1. 向 DGG 拿工具 (DGG 會根據 Header 過濾工具)
        mcp_tools = await self.dgg.list_tools()
        openai_tools = self._convert_mcp_to_openai_tools(mcp_tools)

        # --- ReAct Loop ---
        while True:
            current_tool_calls = {}  # 用來暫存工具呼叫的片段
            is_collecting_tool = False
            full_response_content = ""

            # A. 呼叫 LLM
            async for delta in self.default_gen_stream(
                messages=self.messages,
                model="llm",
                tools=openai_tools if openai_tools else None,
            ):
                # delta.reasoning_content
                # print(delta)
                # --- 情況 A: LLM 決定呼叫工具 (攔截模式) ---
                if delta.tool_calls:
                    is_collecting_tool = True
                    for tc in delta.tool_calls:
                        idx = tc.index
                        if idx not in current_tool_calls:
                            current_tool_calls[idx] = {
                                "id": tc.id,
                                "name": tc.function.name,
                                "arguments": "",
                            }
                        # 拼湊 JSON 片段
                        if tc.function.arguments:
                            current_tool_calls[idx]["arguments"] += (
                                tc.function.arguments
                            )

                    # 選用：你可以 yield 一個 "正在分析工具..." 的狀態給 UI
                    # yield "[STATUS: Analyzing...]"

                # --- 情況 B: LLM 正在說話 (直通模式) ---
                elif delta.content:
                    # 如果我們確認不是在組裝工具，就直接串流給用戶
                    if not is_collecting_tool:
                        full_response_content += delta.content
                        yield delta.content

            if is_collecting_tool:
                # 這裡不需要 yield content，因為上面攔截了

                # 建構完整的 Assistant Message (為了塞回歷史紀錄)
                tool_calls_data = []
                for idx, tc in current_tool_calls.items():
                    tool_calls_data.append(
                        {
                            "id": tc["id"],
                            "type": "function",
                            "function": {
                                "name": tc["name"],
                                "arguments": tc["arguments"],
                            },
                        }
                    )

                # 把「意圖」存入歷史 (即使沒顯示給用戶，LLM 需要知道它呼叫了工具)
                self.messages.append(
                    {
                        "role": "assistant",
                        "content": None,
                        "tool_calls": tool_calls_data,
                    }
                )

                # 通知 UI 我們正在執行 (UX 優化)
                for tc in tool_calls_data:
                    func_name = tc["function"]["name"]
                    # yield f"\n\n> ⚙️ *Calling {func_name}...*\n\n"

                    # ... (執行 Tool 的邏輯與之前相同) ...
                    # result = await self.dgg.call_tool(...)
                    # self.messages.append(tool_result_message)
                    func_args_str = tc["function"]["arguments"]
                    call_id = tc["id"]
                    failed_reason = None

                    print(f"⚡ Executing: {func_name} with {func_args_str}")

                    try:
                        # 解析參數 JSON
                        func_args = self._robust_parse_arguments(func_args_str)

                        # 呼叫 DGG (MCP Protocol)
                        result = await self.dgg.call_tool(func_name, func_args)

                        # 提取文字結果
                        tool_output = ""
                        for content in result.content:
                            if content.type == "text":
                                tool_output += content.text

                        if len(tool_output) > 50:
                            print(f"   -> Result: {tool_output[:50]}...")
                        else:
                            print(f"   -> Result: {tool_output}")

                    except Exception as e:
                        failed_reason = str(e)
                        print(f"   -> Error: {failed_reason}...")

                    # E. 將工具執行結果回傳給 LLM (Role: tool)
                    # OpenAI 格式要求必須帶上 tool_call_id
                    self.messages.append(
                        {
                            "role": "tool",
                            "tool_call_id": call_id,
                            "name": func_name,
                            "content": tool_output,
                            "failed_reasoning": failed_reason,
                        }
                    )

                # [關鍵] 執行完工具後，continue 回到 while 開頭
                # 下一輪 LLM 會看到 Tool Result，然後開始解釋 (這時就會進入情況 B 串流文字)
                continue

            # 2. 如果沒有工具呼叫 -> 結束對話
            else:
                # 把完整的文字回應存入歷史
                self.messages.append(
                    {"role": "assistant", "content": full_response_content}
                )
                return  # 結束 Loop

    async def stop(self):
        await self.exit_stack.aclose()
