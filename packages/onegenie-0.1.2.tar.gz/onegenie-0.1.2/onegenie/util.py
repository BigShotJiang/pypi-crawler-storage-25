import re
import os
import json
from types import SimpleNamespace
import orjson
from openai import AsyncOpenAI, APIError

base_url = os.environ["ASKGENIE_ENDPOINT"].replace("/api/v1", "/mpg/v1")

chunksize = 30000


def dumps(obj) -> str:
    return orjson.dumps(obj).decode("utf-8")


def loads(json_str: str | bytes):
    return orjson.loads(json_str)


def read_file(path, default=None):
    print(f"Reading File content from {path}...")
    if os.path.exists(path):
        with open(path, "r") as file:
            return file.read()
    else:
        if default is None:
            raise Exception(f"File do not exists: {path}")
        else:
            return default


async def gen(messages, model, api_token, tools=None):
    client = AsyncOpenAI(base_url=base_url, api_key=api_token, default_headers={"User-Agent": "curl/7.81.0", "Accept": "*/*"})

    params = {
        "model": model,
        "messages": messages,
    }

    if tools:
        params["tools"] = tools
        params["tool_choice"] = "auto"

    try:
        response = await client.chat.completions.create(**params)
        return response.choices[0].message
    except Exception as e:
        print(f"LLM Error: {e}")
        raise e


# def genWithlogprobs(prompt, top_logprobs=10):
#     response = llm.chat.completions.create(
#         model=model_id,
#         messages=[{"role": "user", "content": prompt}],
#         logprobs=True,
#         top_logprobs=top_logprobs,
#     )
#     return response
#
#
# async def agen(prompt):
#     response = await llm_stream.chat.completions.create(
#         model=model_id, messages=[{"role": "user", "content": prompt}]
#     )
#     return response.choices[0].message.content


# history = [
#     {"role": "system", "content": "You are a helpful assistant."},
#     {"role": "user", "content": "What's the capital of France?"},
#     {"role": "assistant", "content": "Paris."},
# ]
async def gen_stream(messages, model, api_token, tools=None):
    # messages = history + [{"role": "user", "content": prompt}]
    mpg = AsyncOpenAI(base_url=base_url, api_key=api_token, default_headers={"User-Agent": "curl/7.81.0", "Accept": "*/*"})

    params = {
        "model": model,
        "messages": messages,
        "stream": True,
    }

    if tools:
        params["tools"] = tools
        params["tool_choice"] = "auto"

    try:
        stream = await mpg.chat.completions.create(**params)
        async for chunk in stream:
            # Extract the content delta
            if chunk.choices:
                delta = chunk.choices[0].delta
                if delta:
                    yield delta

            elif hasattr(chunk, "usage") and chunk.usage:
                continue

    except APIError as e:
        # yield f"Failed: {e.message}"
        yield SimpleNamespace(content=f"Failed: {e.message}", tool_calls=[])

    except Exception as e:
        # yield f"Failed: {str(e)}"
        yield SimpleNamespace(content=f"Failed: {str(e)}", tool_calls=[])


def trim_and_load_json(input):
    start = input.find("{")
    end = input.rfind("}") + 1
    if end == 0 and start != -1:
        input = input + "}"
        end = len(input)
    jsonStr = input[start:end] if start != -1 and end != 0 else ""
    jsonStr = re.sub(r",\s*([\]}])", r"\1", jsonStr)
    try:
        return json.loads(jsonStr)
    except json.JSONDecodeError:
        return []
    except Exception:
        return []
