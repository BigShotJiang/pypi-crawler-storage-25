import os
import uuid
import asyncio
import requests
import redis.asyncio as redis
import redis as sync_redis

from .util import dumps, loads, gen, gen_stream
from .mcp_agent import MCPAgent
from .context import Context, LLMTools, FSTools, Helpers


def register_agent(card):
    ASKGENIE_ENDPOINT = os.getenv("ASKGENIE_ENDPOINT")
    if ASKGENIE_ENDPOINT is None:
        raise Exception("Expected ASKGENIE_ENDPOINT but missing")

    ASKGENIE_DEVELOPER_KEY = os.getenv("ASKGENIE_DEVELOPER_KEY")
    if ASKGENIE_DEVELOPER_KEY is None:
        raise Exception("Expected ASKGENIE_DEVELOPER_KEY but missing")

    REGISTER_URL = f"{ASKGENIE_ENDPOINT}/agent/register"

    print("Register agent to system...")
    resp = requests.post(
        REGISTER_URL,
        json={"agent": card},
        headers={"X-API-KEY": ASKGENIE_DEVELOPER_KEY},
        timeout=10,
    )

    if resp.status_code != 200:
        print(resp.text)
    resp.raise_for_status()
    return resp.json()


# Configuration
GROUP_NAME = "default"
CONSUMER_NAME = "consumer-1"
DGG_SSE_URL = "http://localhost:8081/sse"


class TaskSession:
    """管理單一任務生命週期與平台 API 工具的會話物件"""

    def __init__(self, r, job_id, api_token, s3_ticket, response_channel):
        self.r = r
        self.job_id = job_id
        self.api_token = api_token
        self.s3_ticket = s3_ticket
        self.response_channel = response_channel

    # upload a file
    async def upload_file(self, *, filename, srcpath=None, content=None, type="file"):
        if type not in ("file", "streamlit_app"):
            raise ValueError(
                f"Upload Error: unsupported type '{type}'. Allowed types are 'file' and 'streamlit_app'."
            )

        if (srcpath is None and content is None) or (
            srcpath is not None and content is not None
        ):
            raise ValueError(
                "Upload Error: Must provide exactly one of 'srcpath' or 'content'"
            )

        _, file_ext = os.path.splitext(filename)
        file_ext = file_ext.lower()

        if not file_ext:
            raise ValueError(
                "Upload Error: extension is expected but missing in filename"
            )

        # filename security check
        unsafe_chars = ["/", "\\", "..", "\0"]
        if any(char in filename for char in unsafe_chars) or filename.strip() == "":
            raise ValueError(f"Upload Error: illegal filename ('{filename}')")

        # generate uuid for storage
        uuid_filename = f"{uuid.uuid4()}{file_ext}"
        url = self.s3_ticket["url"]
        fields = self.s3_ticket["fields"].copy()
        fields["key"] = fields["key"].replace("${filename}", uuid_filename)
        s3_filepath = fields["key"]
        print(f"Ready to upload: File [{filename}] -> S3 path [{s3_filepath}]")

        # stream to s3
        def _perform_upload():
            if srcpath is not None:
                with open(srcpath, "rb") as f:
                    return requests.post(
                        url, data=fields, files={"file": f}, allow_redirects=False
                    )
            else:
                # Handle in-memory content (convert str to bytes if necessary)
                file_data = (
                    content.encode("utf-8") if isinstance(content, str) else content
                )
                # requests allows a tuple for files: (filename, data)
                return requests.post(
                    url,
                    data=fields,
                    files={"file": (uuid_filename, file_data)},
                    allow_redirects=False,
                )

        response = await asyncio.to_thread(_perform_upload)
        print(f"Upload {uuid_filename} Status code: {response.status_code}")

        if response.status_code == 204:
            payload = {
                "jobId": self.job_id,
                "status": "processing",
                "filename": filename,  # for display and download
                "s3_filepath": s3_filepath,  # for storage
                "type": type,
            }
            msg = dumps(payload)

            print(f"job_id: {self.job_id} | Ready to Publish: {payload}")
            await self.r.publish(self.response_channel, msg)
        else:
            print(f"Upload Failed: {response.text}")

    # streaming output
    async def gen_stream(self, *, messages=[], model, tools=[]):
        async for chunk in gen_stream(
            messages=messages, model=model, api_token=self.api_token, tools=tools
        ):
            yield chunk

    # blocking one time generation
    async def gen(self, *, messages=[], model, tools=[]):
        return await gen(
            messages=messages, model=model, api_token=self.api_token, tools=tools
        )


async def process_task(r, task_data, handler_func, response_channel):
    job_id = task_data.get("id")
    agent = task_data.get("agent")
    messages = task_data.get("messages")
    api_token = task_data.get("token")
    extra_params = task_data.get("extra_params")
    s3_ticket = task_data.get("s3_ticket")

    print(f"Processing job agent[{agent}] job_id[{job_id}]...")

    session = TaskSession(r, job_id, api_token, s3_ticket, response_channel)
    mcp_agent = MCPAgent(DGG_SSE_URL, api_token, session.gen_stream)

    ctx = Context(
        messages=messages,
        extra_params=extra_params,
        llm=LLMTools(gen_stream=session.gen_stream, gen=session.gen),
        fs=FSTools(upload_file=session.upload_file),
        mcp=mcp_agent,
        helpers=Helpers(),
    )

    try:
        output = ""
        async for chunk in handler_func(ctx):
            msg = dumps({"jobId": job_id, "status": "processing", "chunk": chunk})
            if isinstance(chunk, str):
                output += chunk
            await r.publish(response_channel, msg)

        await r.publish(
            response_channel,
            dumps({"jobId": job_id, "status": "done", "output": output}),
        )

    except Exception as e:
        print(f"Error processing {job_id}: {e}")
        err_msg = dumps({"status": "error", "error": str(e)})
        await r.publish(response_channel, err_msg)


async def start_heartbeat(r, hb_key):
    while True:
        try:
            await r.set(hb_key, "alive", ex=45)
            await asyncio.sleep(30)
        except Exception as e:
            print(f"Heartbeat failed: {e}")
            await asyncio.sleep(30)


async def main(agent_card, handler_func, ctx):
    info = register_agent(agent_card)
    print("Registration completed.", info)

    ctx["redis_url"] = info["redisUrl"]
    r = redis.from_url(info["redisUrl"], decode_responses=True)
    print(f"Python Agent Daemon connected to {info['redisUrl']}")

    worker_id = uuid.uuid4().hex
    ctx["hb_key"] = info["heartbeatPattern"].replace(":*", f":{worker_id}")
    print(f"heartbeat_key: {ctx['hb_key']}")

    MAX_CONCURRENCY = 10
    sem = asyncio.Semaphore(MAX_CONCURRENCY)

    # We need to keep track of running tasks to cancel them on shutdown if needed
    background_tasks = set()

    heartbeat_task = asyncio.create_task(start_heartbeat(r, ctx["hb_key"]))

    async def task_wrapper(mid, task_data):
        try:
            await process_task(r, task_data, handler_func, info["outputChannel"])
            await r.xack(info["streamKey"], GROUP_NAME, mid)
        except Exception as e:
            print(f"Task processing error: {e}")
        finally:
            sem.release()

    while True:
        try:
            await sem.acquire()

            response = await r.xreadgroup(
                GROUP_NAME,
                CONSUMER_NAME,
                streams={info["streamKey"]: ">"},
                count=1,
                block=0,
            )
            if response:
                stream_name, messages = response[0]
                message_id, data = messages[0]

                task_payload = loads(data.get("payload"))

                # Create background task and add to set
                t = asyncio.create_task(task_wrapper(message_id, task_payload))
                background_tasks.add(t)

                # Remove task from set when done
                t.add_done_callback(background_tasks.discard)
            else:
                # If no message, release the semaphore immediately so we can loop again
                sem.release()

        except Exception as e:
            print(f"Critical error in loop: {e}")
            heartbeat_task.cancel()
            await heartbeat_task
            if background_tasks:
                await asyncio.wait(background_tasks)
            await asyncio.sleep(1)  # Prevent tight loop on Redis connection fail


def start_daemon(agent_card, handler_func):
    ctx = {}
    try:
        asyncio.run(main(agent_card, handler_func, ctx))
    except KeyboardInterrupt:
        print("Daemon stopped.")
    finally:
        if "hb_key" in ctx:
            print(f"Cleaning up heartbeat: {ctx['hb_key']}...")
            try:
                # Use standard 'redis' (not asyncio) to guarantee execution
                r = sync_redis.from_url(ctx["redis_url"])
                r.delete(ctx["hb_key"])
                print("Cleanup successful.")
            except Exception as e:
                print(f"Cleanup failed: {e}")
