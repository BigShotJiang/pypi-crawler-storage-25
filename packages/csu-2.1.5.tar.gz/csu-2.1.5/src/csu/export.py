from datetime import date
from datetime import datetime

from django.core.exceptions import BadRequest
from django.core.exceptions import ValidationError
from django.db import models
from django.db.models import Choices
from django.db.models import Lookup
from django.db.models import Model
from django.db.models.expressions import Col
from django.db.models.lookups import Exact
from django.db.models.sql import AND
from django.http import HttpResponse
from django.utils.encoding import force_str
from django.utils.tree import Node
from import_export.fields import Field
from import_export.formats.base_formats import CSV
from import_export.formats.base_formats import XLS
from import_export.formats.base_formats import XLSX
from import_export.instance_loaders import ModelInstanceLoader
from import_export.resources import Diff
from import_export.resources import ModelResource
from import_export.results import RowResult
from import_export.signals import post_export
from import_export.widgets import Widget
from rest_framework import serializers
from tablib import InvalidDimensions

from csu.gettext import _
from csu.timezones import adjust_dt
from csu.timezones import now

from .timezones import today

EXPORT_FORMATS = {
    "XLSX": XLSX,
    "XLS": XLS,
    "CSV": CSV,
}


class RenderExportViewMixin:
    export_resource_class: type[ModelResource]
    export_formats = ("XLSX", "XLS", "CSV")
    export_filename_prefix = "export"
    export_filename_time = "%Y-%m-%d_%H%M"

    def get_export_filename_prefix(self):
        return self.export_filename_prefix

    def render_to_response(self, context, **response_kwargs):
        params = self.request.GET
        if params.get("action") == "export":
            file_format: str = params["format"]
            if file_format not in self.export_formats:
                raise BadRequest
            file_format_instance = EXPORT_FORMATS[file_format]()
            filters_repr = "".join(
                f"-{key}={value.replace(':', '')}"
                for key, raw_value in params.items()
                if key
                not in (
                    "action",
                    "format",
                )
                for value in (raw_value.strip(),)
                if value
            )
            object_list = context["object_list"]
            data = self.export_resource_class().export(object_list)
            file_dt = adjust_dt(now()).strftime(self.export_filename_time)
            file_prefix = self.get_export_filename_prefix()
            file_content = file_format_instance.export_data(data)
            file_ext = file_format_instance.get_extension()
            if not file_format_instance.is_binary():
                file_content = file_content.encode()
            content_type = file_format_instance.get_content_type()
            response = HttpResponse(file_content, content_type=content_type)
            response["Content-Disposition"] = f'attachment; filename="{file_prefix}-{file_dt}{filters_repr}.{file_ext}"'
            post_export.send(sender=None, model=self.export_resource_class._meta.model)
            return response
        else:
            return super().render_to_response(context, **response_kwargs)


class RowDumpOnImportErrorMixin:
    def add_data_read_fail_error_to_form(self, form, e):
        if isinstance(e, InvalidDimensions):
            row = ""
            tb = e.__traceback__
            while tb.tb_next:
                tb = tb.tb_next
            frame = tb.tb_frame
            while frame:
                if "row" in frame.f_locals:
                    row = frame.f_locals["row"]
                    break
                frame = frame.f_back

            form.add_error("import_file", _("Row {row!r} doesn't match the headers!").format(row=row))
        else:
            super().add_data_read_fail_error_to_form(form, e)


def repr_expr(obj):
    if isinstance(obj, Exact):
        return f"{repr_expr(obj.lhs)}={repr_expr(obj.rhs)}"
    elif isinstance(obj, Lookup):
        return f"{repr_expr(obj.lhs)}__{obj.lookup_name}={repr_expr(obj.rhs)}"
    elif isinstance(obj, Col):
        return obj.target.column
    elif isinstance(obj, Node):
        if obj.connector == AND:
            return "-".join(map(repr_expr, obj.children))
        else:
            return "-OR-".join(map(repr_expr, obj.children))
    elif isinstance(obj, datetime | date):
        return obj.isoformat()
    else:
        return str(obj)


class FullFilenameExportAdminMixin:
    model: models.Model

    def get_export_filename(self, request, queryset: models.QuerySet, file_format):
        filters = repr_expr(queryset.query.where)
        filename = "{}-{}-{}-{}.{}".format(
            self.model._meta.app_label,
            self.model._meta.verbose_name_plural.replace(" ", "-").replace("/", "-"),
            today().isoformat(),
            filters or "all",
            file_format.get_extension(),
        )
        return filename


class ChoiceWidget(Widget):
    def __init__(self, choice_class: type[Choices], **kwargs):
        super().__init__(**kwargs)
        self.choice_class = choice_class

    def render(self, value, obj=None, **kwargs):
        if value in self.choice_class:
            return self.choice_class(value).name
        else:
            return value

    def clean(self, value, row=None, **kwargs):
        if value in self.choice_class:
            return self.choice_class[value]


class SmartField(Field):
    def clean(self, data, **kwargs):
        """
        Perform exception wrapping early here (instead of letting import_obj do it).
        Apparently that behavior is completely missing from (for import_id_fields).
        """
        try:
            return super().clean(data, **kwargs)
        except ValueError as e:
            raise ValidationError({self.attribute: force_str(e)}, code="invalid") from e


def widget_passthrough(widget_instance):
    def widget_trampoline(key_is_id=None, **kwargs):
        assert not kwargs, f"no widget kwargs are allowed but we got: {kwargs!r}"
        return widget_instance

    return widget_trampoline


def widget_for_drf_field(drf_field: serializers.Field):
    class WidgetWrapper(Widget):
        def clean(self, value, row=None, **kwargs):
            try:
                return drf_field.run_validation(value)
            except serializers.ValidationError as exc:
                raise ValueError(*map(str, exc.detail)) from None

    return WidgetWrapper()


class SkipInstance(tuple):
    pass


class SkipDiff(Diff):
    def compare_with(self, resource, instance, **_):
        if isinstance(instance, SkipInstance):
            self.right = []
        else:
            super().compare_with(resource, instance)


class UniqueModelInstanceLoader(ModelInstanceLoader):
    def __init__(self, resource, dataset=None):
        super().__init__(resource, dataset)
        self.seen_keys = set()

    def get_instance(self, row):
        try:
            params = {}
            values = []
            for key in self.resource.get_import_id_fields():
                field = self.resource.fields[key]
                params[field.attribute] = value = field.clean(row)
                values.append(value)
            seen_key = SkipInstance(values)
            if seen_key in self.seen_keys:
                return seen_key
            else:
                self.seen_keys.add(seen_key)
            if params:
                return self.get_queryset().get(**params)
            else:
                return None
        except self.resource._meta.model.DoesNotExist:
            return None


class SmartModelResource(ModelResource):
    class Meta:
        instance_loader_class = UniqueModelInstanceLoader

    DEFAULT_RESOURCE_FIELD = SmartField

    seen_pks: set

    def get_diff_class(self):
        return SkipDiff

    def before_import(self, *args, **kwargs):
        self.seen_pks = set()

    def after_import_row(self, row, row_result: RowResult, row_number=None, **kwargs):
        if row_result.object_id:
            self.seen_pks.add(row_result.object_id)

    def skip_row(self, instance: Model | SkipInstance, original, *args, **kwargs):
        if isinstance(instance, SkipInstance):
            return True
        if instance.pk in self.seen_pks:
            return True

    @classmethod
    def widget_kwargs_for_field(cls, *args):
        return {}

    @classmethod
    def widget_from_django_field(cls, f: models.Field, *args, **kwargs):
        name = f.name
        widgets = cls._meta.widgets or ()
        if name in widgets:
            return widget_passthrough(widgets[name])
        else:
            return widget_passthrough(super().widget_from_django_field(f, *args, **kwargs)())
