import signal
import sys

from process_tests import TestProcess
from process_tests import dump_on_error
from process_tests import wait_for_strings


def test_noskip():
    with TestProcess(sys.executable, "-mexampleworker", "3", "0", "1000", "4") as target, dump_on_error(target.read):
        wait_for_strings(
            target.read,
            5,
            "PRODUCER fetch_task @ 1 RETURN",
            "INFO:worker:ExampleEngine(4w/0q).push(ExampleJob(done=<Future pending>, started=<Future pending>, id=1))",
            "INFO:worker:ExampleProducer().run() awaiting ExampleJob(done=<Future pending>, started=<Future pending>, id=1).done of NoOpTask(id=1).",
            "working on: ExampleJob(done=<Future pending>, started=<Future finished result=True>, id=1)",
            "- performing...",
            "CONSUMER 0 perform_work JOB 1 START",
            "CONSUMER 0 perform_work JOB 1 DONE",
            "CONSUMER 0 save_result JOB 1",
            "PRODUCER fetch_task @ 2 RETURN",
            "INFO:worker:ExampleEngine(4w/0q).push(ExampleJob(done=<Future pending>, started=<Future pending>, id=2))",
            "INFO:worker:ExampleProducer().run() awaiting ExampleJob(done=<Future pending>, started=<Future pending>, id=2).done of NoOpTask(id=2).",
            ").run() working on: ExampleJob(done=<Future pending>, started=<Future finished result=True>, id=2)",
            ").run() - performing...",
            "CONSUMER 1 perform_work JOB 2 START",
            "CONSUMER 1 perform_work JOB 2 DONE",
            "CONSUMER 1 save_result JOB 2",
            "PRODUCER fetch_task @ 3 RETURN",
            "INFO:worker:ExampleEngine(4w/0q).push(ExampleJob(done=<Future pending>, started=<Future pending>, id=3))",
            "INFO:worker:ExampleProducer().run() awaiting ExampleJob(done=<Future pending>, started=<Future pending>, id=3).done of NoOpTask(id=3).",
            ").run() working on: ExampleJob(done=<Future pending>, started=<Future finished result=True>, id=3)",
            ").run() - performing...",
            "CONSUMER 2 perform_work JOB 3 START",
            "CONSUMER 2 perform_work JOB 3 DONE",
            "CONSUMER 2 save_result JOB 3",
            "PRODUCER fetch_task @ 4 RETURN",
            "INFO:worker:ExampleEngine(4w/0q).push(ExampleJob(done=<Future pending>, started=<Future pending>, id=4))",
            "INFO:worker:ExampleProducer().run() awaiting ExampleJob(done=<Future pending>, started=<Future pending>, id=4).done of NoOpTask(id=4).",
            ").run() working on: ExampleJob(done=<Future pending>, started=<Future finished result=True>, id=4)",
            ").run() - performing...",
            "CONSUMER 0 perform_work JOB 4 START",
            "CONSUMER 0 perform_work JOB 4 DONE",
            "CONSUMER 0 save_result JOB 4",
            "EXHAUSTED",
        )


def test_skip():
    with TestProcess(sys.executable, "-mexampleworker", "3", "2", "100", "4") as target, dump_on_error(target.read):
        wait_for_strings(
            target.read,
            5,
            "INFO:worker:ExampleProducer() started.",
            "INFO:worker:ExampleProducer().run() started.",
            "PRODUCER fetch_task @ 1 RETURN",
            "INFO:worker:ExampleEngine(4w/0q).push(ExampleJob(done=<Future pending>, started=<Future pending>, id=1))",
            "INFO:worker:ExampleProducer().run() awaiting ExampleJob(done=<Future pending>, started=<Future pending>, id=1).done of NoOpTask(id=1).",
            ").run() working on: ExampleJob(done=<Future pending>, started=<Future finished result=True>, id=1)",
            ").run() - performing...",
            "CONSUMER 0 perform_work JOB 1 START",
            "CONSUMER 0 perform_work JOB 1 DONE",
            "CONSUMER 0 save_result JOB 1",
            "PRODUCER fetch_task @ 2 SKIP",
            "PRODUCER fetch_task @ 3 RETURN",
            "INFO:worker:ExampleEngine(4w/0q).push(ExampleJob(done=<Future pending>, started=<Future pending>, id=3))",
            "INFO:worker:ExampleProducer().run() awaiting ExampleJob(done=<Future pending>, started=<Future pending>, id=3).done of NoOpTask(id=3).",
            ").run() working on: ExampleJob(done=<Future pending>, started=<Future finished result=True>, id=3)",
            ").run() - performing...",
            "CONSUMER 1 perform_work JOB 3 START",
            "CONSUMER 1 perform_work JOB 3 DONE",
            "CONSUMER 1 save_result JOB 3",
            "PRODUCER fetch_task @ 4 SKIP",
            "PRODUCER fetch_task @ 5 EXHAUSTED",
        )


def test_sigterm():
    with TestProcess(sys.executable, "-mexampleworker", "3", "0", "1000", "100") as target, dump_on_error(target.read):
        wait_for_strings(
            target.read,
            15,
            "PRODUCER fetch_task @ 1 RETURN",
            "INFO:worker:ExampleEngine(4w/0q).push(ExampleJob(done=<Future pending>, started=<Future pending>, id=1))",
            "INFO:worker:ExampleProducer().run() awaiting ExampleJob(done=<Future pending>, started=<Future pending>, id=1).done of NoOpTask(id=1).",
            "working on: ExampleJob(done=<Future pending>, started=<Future finished result=True>, id=1)",
            "- performing...",
            "CONSUMER 0 perform_work JOB 1 START",
        )
        target.proc.send_signal(signal.SIGINT)
        wait_for_strings(
            target.read,
            15,
            "INFO:worker:ExampleEngine(4w/0q).stop(graceful=True)",
            "CONSUMER 0 perform_work JOB 1 DONE",
            "CONSUMER 0 save_result JOB 1",
            "INFO:worker:ExampleEngine(4w/0q) requesting all workers to shutdown...",
            "INFO:worker:ExampleEngine(4w/0q).push(None)",
            "INFO:worker:ExampleEngine(4w/1q).push(None)",
            "INFO:worker:ExampleEngine(4w/2q).push(None)",
            "INFO:worker:ExampleEngine(0w/0q) shutdown complete.",
            "DONE: {'ExampleEngine': {'JOBS': 4, 'QSIZE': 0}}",
        )
