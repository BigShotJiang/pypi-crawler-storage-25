import asyncio
import logging
import sys
from dataclasses import asdict
from dataclasses import dataclass
from enum import StrEnum
from logging import getLogger

from csu.worker.engine import AbstractConsumer
from csu.worker.engine import AbstractEngine
from csu.worker.engine import AbstractProducer
from csu.worker.engine import SleepingCooldown
from csu.worker.engine import SleepingCooldownMixin
from csu.worker.engine import TaskProtocol
from csu.worker.job import Job

logger = getLogger(__name__)


@dataclass
class NoOpTask:
    """
    Simple task model that doesn't store anything.
    """

    id: int

    @property
    def job_kwargs(self):
        return asdict(self)

    async def done_watchdog(self, job: Job):
        """
        Nothing done as there's no storage for this job.
        """


@dataclass
class ExampleJob[RequestStruct](Job):
    id: int


class ExampleResultType(StrEnum):
    PENDING = "PENDING"
    SUCCESS = "SUCCESS"
    ERROR = "ERROR"
    ABSENT = "ABSENT"


class ExampleProducer(
    SleepingCooldownMixin,
    AbstractProducer,
):
    engine: ExampleEngine
    job_class = ExampleJob
    counter = 0
    cooldown_min_seconds = cooldown_max_seconds = 1
    cooldown_on = SleepingCooldown.IDLE

    async def fetch_task(self) -> TaskProtocol | None:
        self.counter += 1
        if self.counter > self.engine.max_jobs:
            print(f"PRODUCER fetch_task @ {self.counter} EXHAUSTED")
            return
        if not self.engine.producer_skip or self.counter % self.engine.producer_skip:
            print(f"PRODUCER fetch_task @ {self.counter} RETURN")
            return NoOpTask(self.counter)
        else:
            print(f"PRODUCER fetch_task @ {self.counter} SKIP")


class ExampleConsumer(AbstractConsumer):
    result_type_enum = ExampleResultType
    engine: ExampleEngine

    def __init__(self, engine: ExampleEngine, name):
        super().__init__(engine)
        self.name = name

    async def perform_work(self, job: ExampleJob):
        print(f"CONSUMER {self.name} perform_work JOB {job.id} START")
        try:
            await asyncio.sleep(self.engine.consumer_sleep)
            return {"foo": "bar"}
        finally:
            print(f"CONSUMER {self.name} perform_work JOB {job.id} DONE")

    async def save_result(self, job: ExampleJob, /, **kwargs):
        print(f"CONSUMER {self.name} save_result JOB {job.id}")


class ExampleEngine(AbstractEngine):
    def __init__(self, consumers, producer_skip, consumer_sleep, max_jobs):
        super().__init__()
        self.consumers = int(consumers)
        self.producer_skip = int(producer_skip)
        self.consumer_sleep = int(consumer_sleep) / 1000
        self.max_jobs = int(max_jobs)
        self.job_counter = 0

    async def start(self):
        for i in range(self.consumers):
            self.add_worker(ExampleConsumer(engine=self, name=i))

        self.add_worker(ExampleProducer(engine=self))

        await super().start()

        while self.is_work_pending():
            await asyncio.sleep(1)
            print(self.inspect())
        print(f"DONE: {self.inspect()}")

    async def push(self, job: Job | None) -> None:
        self.job_counter += 1
        await super().push(job)

    def report(self, inspect):
        super().report(inspect)
        inspect["JOBS"] = self.job_counter


if __name__ == "__main__":
    print("+", " ".join(sys.argv))
    logging.basicConfig(level=logging.DEBUG)
    engine = ExampleEngine(*sys.argv[1:])
    asyncio.run(engine.start())
