# Design-partner feedback

Thanks for trying `promptify-cmax` early. We're sending it to ~5 people before any public launch; you're one of them. Honest answers — including "this didn't help me" — are the most valuable thing you can give us.

The bar for v0.1 is one binary question, asked at the end of two weeks of casual use:

> **After two weeks, would you install promptify-cmax on every new repo by default?**

That's the wedge-survives-or-doesn't question. Everything below helps us understand *why* your answer is yes or no.

## How to send feedback

Reply by email to **c@promptify.com** with the questionnaire below filled in. No call required. If you'd rather hop on a 30-minute Zoom to walk through it, mention that and we'll book one. Either path is fine; we want the answers either way.

## When to send

End of week 2 of trying it (or sooner if you bounce off it earlier — we want the bounce-off data too). Don't worry about polish; bullet points beat prose.

---

## Questionnaire (8 questions, 10–15 minutes)

### 1. Setup friction

How long did install + first successful query take? What broke, what was confusing, what did you have to look up that the QUICKSTART didn't cover?

### 2. The binary question

After ~two weeks of using it casually, would you install promptify-cmax on every new repo by default?

- [ ] Yes — explain in one sentence what won you over
- [ ] No — explain in one sentence what's missing or wrong
- [ ] Maybe — explain in one sentence what would make it a clear yes

### 3. Wins (concrete)

Describe one specific case where the structural-context tool found the right file(s) and saved your AI agent a long detour. Include the task you asked, the files it returned, what you would have gotten with `grep` instead. Anything resembling a token count, latency feel, or "the agent got it on the first try" is gold.

### 4. Losses (concrete)

Describe one specific case where the tool failed — wrong files, missed the obvious file, was slow, hallucinated, didn't get installed in the agent at all. Same format: what you asked, what you got, what should have happened.

### 5. The agent's behavior change

Did your AI agent (Claude Code / Cursor / Continue) actually *use* the `structural_context` tool when it had access? How did you tell? If it didn't use it, why do you think — was the tool description wrong, did the agent prefer grep, were the result counts overwhelming?

### 6. What would make this Pro-tier worth $X to you

If this were a paid product with a hosted-indexing tier (no laptop indexing of monorepos, multi-repo BFS, editor extensions, analytics), what would the trigger be for you to upgrade? Team size? Repo size? A specific feature? A specific price point?

### 7. Vs. other tools

If you've used [`zilliztech/claude-context`](https://github.com/zilliztech/claude-context) (semantic retrieval), [`ast-grep` MCP](https://mcpservers.org/servers/ast-grep/ast-grep-mcp), or another code-context MCP server: where did this one win, where did it lose? Would you actually run multiple side-by-side, or is one enough?

If you haven't tried any of the alternatives, just say "haven't compared" — we'll know.

### 8. Anything else

Bugs, surprises, "I wish it did Y," people you think we should also send it to, vibes — whatever didn't fit above.

---

## What we won't do with your feedback

- Quote you publicly without explicit permission
- Add you to a marketing list
- Auto-charge you when we eventually launch (this trial is free; no payment method required)

## What we will do

- Read every word
- Reply within 48 hours with what we're going to fix and what we're not
- Tell you which of your asks made it into v0.2 and which didn't
- Send you a free Pro tier when we launch, as thanks
