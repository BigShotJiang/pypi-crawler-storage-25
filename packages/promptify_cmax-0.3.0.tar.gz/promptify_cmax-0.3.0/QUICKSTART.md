# Quickstart — promptify-cmax

Five-minute install. The goal: in your next Claude Code / Cursor session, watch your AI agent stop wasting tokens on irrelevant files.

## Prerequisites

- Python 3.12 or newer (`python3 --version` to check)
- An MCP-aware AI coding tool: [Claude Code](https://claude.com/claude-code), [Cursor](https://cursor.com), or [Continue](https://continue.dev)

## 1. Install

```bash
pip install promptify-cmax
```

If you don't have `pip` for Python 3.12 specifically:

```bash
python3.12 -m pip install --user promptify-cmax
```

Verify:

```bash
promptify-cmax --help
```

You should see three subcommands: `index`, `query`, `serve`.

## 2. Build the index for your project

```bash
cd /path/to/your/project
promptify-cmax index --project-root .
```

Expected: a few seconds for a small project, ~10s per 1k files for larger ones. Index lands at `.promptify/code-index.db` (add to `.gitignore` — it's a build artefact).

Try a query to confirm it works:

```bash
promptify-cmax query --project-root . "fix the <some_function_name> function" --top-k 5 --json-only
```

You should see five files ranked by call-graph distance, not by surface keyword match.

## 3. Wire it into your AI tool

### Claude Code

Add to `.mcp.json` at the root of your project:

```json
{
  "mcpServers": {
    "promptify-cmax": {
      "command": "promptify-cmax",
      "args": ["serve", "--project-root", "."]
    }
  }
}
```

Restart Claude Code (or run `/mcp` and reconnect). The agent now has access to two tools:
- `structural_context(task, top_k)` — rank files by call-graph distance
- `reindex()` — rebuild after large code changes

### Cursor

Cursor's MCP support is in beta. Add to `~/.cursor/mcp.json`:

```json
{
  "mcpServers": {
    "promptify-cmax": {
      "command": "promptify-cmax",
      "args": ["serve", "--project-root", "/absolute/path/to/your/project"]
    }
  }
}
```

Cursor needs an absolute path — `.` won't work the way it does in Claude Code.

### Continue

Add to `~/.continue/config.json` under `experimental.modelContextProtocolServers`:

```json
{
  "experimental": {
    "modelContextProtocolServers": [
      {
        "transport": {
          "type": "stdio",
          "command": "promptify-cmax",
          "args": ["serve", "--project-root", "."]
        }
      }
    ]
  }
}
```

## 4. Watch it work

Open a coding session and ask the agent something like:

> "Fix the `<some_function_name>` function — it's returning the wrong result on edge cases."

Watch the agent's tool calls. With `promptify-cmax` available, it should call `structural_context` instead of (or before) `Grep`. The result is a short list of files the agent actually needs to read, instead of every file that mentions the symbol.

## Re-indexing

The MCP server includes a `reindex` tool the agent can call when it suspects the index is stale. You can also run it manually:

```bash
promptify-cmax index --project-root .
```

The index is incremental — files whose hash hasn't changed are skipped, so re-running is cheap.

## Troubleshooting

**"command not found: promptify-cmax"** — your `pip install` location isn't on `$PATH`. Try `python3.12 -m promptify_cmax.cli` directly, or check `pip show promptify-cmax` to see where the script went.

**MCP server starts but tool calls return errors** — the index probably hasn't been built. Run `promptify-cmax index --project-root .` from the same directory the MCP server was started in.

**Indexing takes too long** — the indexer skips `.venv/`, `node_modules/`, dotfile dirs, and `__pycache__/`. If you have a build directory or generated code dir we don't recognize, add it to a `.promptify-ignore` (planned for v0.2; in the meantime, run from a smaller project root).

**Wrong files in results** — file an issue with: (1) the task you asked, (2) the result you got, (3) the result you expected. We tune the ranker on real cases, not synthetic ones.

## What to expect

This is v0.1 — Beta. Python and TypeScript are well-supported; Go / Rust / Java / C# are on the roadmap. Bugs will exist. We're treating early users as design partners, not customers; see [FEEDBACK.md](https://github.com/promptify-com/promptify-cmax/blob/main/FEEDBACK.md) if you'd like to share what you find.

**You may also want to look at:** [`zilliztech/claude-context`](https://github.com/zilliztech/claude-context) for *semantic* code retrieval (embeddings + BM25; good for "how does X work?" questions), and [`ast-grep` MCP](https://mcpservers.org/servers/ast-grep/ast-grep-mcp) for AST-pattern search. They solve different problems and can run alongside `promptify-cmax`. See the [README](https://github.com/promptify-com/promptify-cmax/blob/main/README.md#when-to-use-this-vs-semantic-retrieval) for when each wins.

If you hit a wall, open a GitHub issue or email c@promptify.com.
