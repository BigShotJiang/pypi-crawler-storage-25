"""Tests for Python extraction via tree-sitter."""
import pytest
from promptify_cmax.extractor import extract_file


def test_extract_python_functions(sample_python_file):
    """Verify that all top-level and class method names are extracted."""
    result = extract_file(sample_python_file)
    names = {f.name for f in result.functions}
    assert "fetch_data" in names
    assert "parse_response" in names
    assert "__init__" in names
    assert "process" in names
    assert "transform" in names


def test_extract_python_function_signatures(sample_python_file):
    """Verify signatures and line numbers for extracted functions."""
    result = extract_file(sample_python_file)
    by_name = {f.name: f for f in result.functions}

    fetch = by_name["fetch_data"]
    assert "url" in fetch.signature
    assert "timeout" in fetch.signature
    assert fetch.start_line >= 1

    parse = by_name["parse_response"]
    assert "response" in parse.signature
    assert parse.start_line > fetch.start_line

    # Line numbers must be positive and end >= start
    for fn in result.functions:
        assert fn.start_line >= 1
        assert fn.end_line >= fn.start_line


def test_extract_python_calls(sample_python_file):
    """Verify (caller, callee) pairs are extracted from function bodies."""
    result = extract_file(sample_python_file)
    pairs = {(c.caller, c.callee) for c in result.calls}

    # fetch_data calls helper and parse_response
    assert ("fetch_data", "helper") in pairs
    assert ("fetch_data", "parse_response") in pairs

    # DataProcessor.process calls fetch_data
    assert ("process", "fetch_data") in pairs


def test_extract_python_imports(sample_python_file):
    """Verify imported names are extracted with correct module."""
    result = extract_file(sample_python_file)
    imported_names = {i.name for i in result.imports}
    modules = {i.module for i in result.imports}

    assert "join" in imported_names
    assert "helper" in imported_names
    # module for join
    join_imp = next(i for i in result.imports if i.name == "join")
    assert join_imp.module == "os.path"


def test_extract_python_classes(sample_python_file):
    """Verify class methods are grouped under class_name."""
    result = extract_file(sample_python_file)
    class_methods = [f for f in result.functions if f.class_name == "DataProcessor"]
    method_names = {f.name for f in class_methods}

    assert "__init__" in method_names
    assert "process" in method_names
    assert "transform" in method_names

    # Top-level functions must not have a class_name
    top_level = [f for f in result.functions if f.class_name is None]
    top_names = {f.name for f in top_level}
    assert "fetch_data" in top_names
    assert "parse_response" in top_names


def test_extract_python_docstrings(sample_python_file):
    """Verify docstrings are captured for functions that have them."""
    result = extract_file(sample_python_file)
    by_name = {f.name: f for f in result.functions}

    assert by_name["fetch_data"].docstring is not None
    assert "Fetch data" in by_name["fetch_data"].docstring
    assert by_name["parse_response"].docstring is not None
    assert "Parse" in by_name["parse_response"].docstring


def test_extract_typescript_functions(sample_ts_file):
    result = extract_file(sample_ts_file, language="typescript")
    names = {f.name for f in result.functions}
    assert "fetchData" in names
    assert "parseResponse" in names
    assert "process" in names
    assert "transform" in names


def test_extract_typescript_calls(sample_ts_file):
    result = extract_file(sample_ts_file, language="typescript")
    call_pairs = {(c.caller, c.callee) for c in result.calls}
    assert ("fetchData", "helper") in call_pairs
    assert ("fetchData", "parseResponse") in call_pairs
    assert ("process", "fetchData") in call_pairs


def test_extract_typescript_imports(sample_ts_file):
    result = extract_file(sample_ts_file, language="typescript")
    imported_names = {i.name for i in result.imports}
    assert "helper" in imported_names
