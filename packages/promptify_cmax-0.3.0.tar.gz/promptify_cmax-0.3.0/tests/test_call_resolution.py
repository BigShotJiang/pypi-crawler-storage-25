"""Regression test for FQN-aware call resolution.

The call graph must NOT pull in files that merely define a function
with the same bare name as a node on the BFS frontier. Reachability
must be determined by actual call edges, resolved through imports
and same-file scope.

Real-world failure case (2026-05-08): a structural_context query for
`threshold_for_complexity` returned
`dca/experiments/.../g6_phase5_falsification.py` because that file
defines its own local `encode_query` — same name as the legitimate
distance-2 callee `dca.pillar_v.embedding_reranker.encode_query`,
but no actual call edge connects them.
"""
from __future__ import annotations

from pathlib import Path

import pytest

from promptify_cmax.cli import _build_index
from promptify_cmax.graph import find_affected_files


@pytest.fixture
def collision_project(tmp_path: Path) -> Path:
    """Three-file project with a deliberate bare-name collision.

    Call graph (real edges only):
        entry.py:entry  -> real_target.py:helper
        unrelated.py:main -> unrelated.py:helper  (island, never reached)

    Both `real_target.py` and `unrelated.py` define `helper`.
    Only `real_target.py:helper` is reachable from `entry`.
    """
    (tmp_path / "entry.py").write_text(
        "from real_target import helper\n"
        "\n"
        "def entry():\n"
        "    return helper()\n"
    )
    (tmp_path / "real_target.py").write_text(
        "def helper():\n"
        "    return 'real'\n"
    )
    (tmp_path / "unrelated.py").write_text(
        "def helper():\n"
        "    return 'collision'\n"
        "\n"
        "def main():\n"
        "    return helper()\n"
    )
    return tmp_path


def test_bare_name_collision_excluded(collision_project: Path) -> None:
    db_path = collision_project / ".promptify" / "code-index.db"
    db_path.parent.mkdir(parents=True, exist_ok=True)
    idx, _, _ = _build_index(collision_project, db_path)

    results = find_affected_files(idx, ["entry"], max_depth=2, top_k=10)
    paths = {r.path for r in results}
    idx.close()

    assert "entry.py" in paths, "entry.py is the entry-point file"
    assert "real_target.py" in paths, "real_target.py is the legit callee"
    assert "unrelated.py" not in paths, (
        "unrelated.py defines its own helper() and main() but is not "
        "imported by entry.py; FQN-aware resolution must exclude it"
    )
