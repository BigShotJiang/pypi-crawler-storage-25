"""Tests for promptify_cmax.query.extract_identifiers."""

from promptify_cmax.query import extract_identifiers


def test_backtick_identifiers():
    ids = extract_identifiers("Fix the bug in `login_session` and `UserAuth`")
    assert "login_session" in ids
    assert "UserAuth" in ids


def test_camel_case():
    ids = extract_identifiers("The DataProcessor class has a bug")
    assert "DataProcessor" in ids


def test_snake_case():
    ids = extract_identifiers("The fetch_data function times out")
    assert "fetch_data" in ids


def test_dotted_path():
    ids = extract_identifiers("Error in auth.session.validate")
    assert "validate" in ids


def test_filters_common_words():
    ids = extract_identifiers("Fix the bug in the code")
    assert "the" not in ids
    assert "bug" not in ids
    assert "code" not in ids


def test_edit_hint_passthrough():
    ids = extract_identifiers("anything", edit_hint="auth/session.py:login")
    assert "login" in ids


def test_filters_against_index():
    known = {"login", "fetch_data", "DataProcessor"}
    ids = extract_identifiers(
        "The DataProcessor calls fetch_data and some_unknown_thing",
        known_symbols=known,
    )
    assert "DataProcessor" in ids
    assert "fetch_data" in ids
