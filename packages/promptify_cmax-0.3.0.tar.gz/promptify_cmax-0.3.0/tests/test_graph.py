"""Tests for graph.py BFS call graph traversal and file ranking."""
from __future__ import annotations

import pytest

from promptify_cmax.extractor import FunctionInfo
from promptify_cmax.graph import RankedFile, find_affected_files
from promptify_cmax.index import CodeIndex


# ---------------------------------------------------------------------------
# Helper to build a test index
# ---------------------------------------------------------------------------

def _build_test_index(tmp_path) -> CodeIndex:
    """Build a CodeIndex with the following call graph:
        login (auth.py) -> get_user (db.py) -> cached (cache.py)
        handle_login (api.py) -> login (auth.py)
        unrelated (other.py) -- no connections
    """
    db_path = tmp_path / "test.db"
    index = CodeIndex(db_path)

    # Register functions
    for name, file in [
        ("login", "auth.py"),
        ("get_user", "db.py"),
        ("cached", "cache.py"),
        ("handle_login", "api.py"),
        ("unrelated", "other.py"),
    ]:
        index.upsert_function(FunctionInfo(
            name=name,
            file=file,
            start_line=1,
            end_line=5,
            signature="()",
        ))

    # Register calls (caller_file is required for FQN-aware resolution;
    # all bare names here are globally unique so single-definition
    # resolution applies regardless of caller file).
    index.upsert_call("auth.py", "login", "get_user")
    index.upsert_call("db.py", "get_user", "cached")
    index.upsert_call("api.py", "handle_login", "login")

    return index


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

def test_depth_0_returns_entry_file(tmp_path):
    """Entry 'login' at depth 0 should include auth.py; other.py must not appear."""
    index = _build_test_index(tmp_path)
    results = find_affected_files(index, ["login"], max_depth=0, top_k=10)
    paths = {r.path for r in results}
    assert "auth.py" in paths
    assert "other.py" not in paths


def test_depth_1_returns_callers_and_callees(tmp_path):
    """Entry 'login' at depth 1 should include auth.py (d=0), db.py (callee, d=1),
    and api.py (caller, d=1)."""
    index = _build_test_index(tmp_path)
    results = find_affected_files(index, ["login"], max_depth=1, top_k=10)
    paths = {r.path for r in results}
    assert "auth.py" in paths
    assert "db.py" in paths
    assert "api.py" in paths


def test_depth_2_reaches_transitive(tmp_path):
    """Entry 'login' at depth 2 should reach cache.py transitively
    (login -> get_user -> cached)."""
    index = _build_test_index(tmp_path)
    results = find_affected_files(index, ["login"], max_depth=2, top_k=10)
    paths = {r.path for r in results}
    assert "cache.py" in paths


def test_unrelated_files_excluded(tmp_path):
    """other.py (with 'unrelated' function, no connections) must never appear
    regardless of depth when starting from 'login'."""
    index = _build_test_index(tmp_path)
    for depth in (0, 1, 2):
        results = find_affected_files(index, ["login"], max_depth=depth, top_k=10)
        paths = {r.path for r in results}
        assert "other.py" not in paths, f"other.py appeared at depth={depth}"


def test_ranking_by_distance(tmp_path):
    """The first result when starting from 'login' must be auth.py at distance 0."""
    index = _build_test_index(tmp_path)
    results = find_affected_files(index, ["login"], max_depth=2, top_k=10)
    assert results, "Expected at least one result"
    assert results[0].path == "auth.py"
    assert results[0].distance == 0


def test_top_k_limits_results(tmp_path):
    """top_k=2 must return at most 2 files."""
    index = _build_test_index(tmp_path)
    results = find_affected_files(index, ["login"], max_depth=2, top_k=2)
    assert len(results) <= 2
