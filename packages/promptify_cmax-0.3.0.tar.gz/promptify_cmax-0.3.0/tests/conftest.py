import textwrap
import pytest


@pytest.fixture
def sample_python_file(tmp_path):
    content = textwrap.dedent("""\
        from os.path import join
        from .utils import helper

        def fetch_data(url: str, timeout: int = 30) -> dict:
            \"\"\"Fetch data from URL.\"\"\"
            response = helper(url)
            return parse_response(response)

        def parse_response(response) -> dict:
            \"\"\"Parse HTTP response.\"\"\"
            return {"data": response.text}

        class DataProcessor:
            def __init__(self, config):
                self.config = config

            def process(self, raw):
                data = fetch_data(raw["url"])
                return self.transform(data)

            def transform(self, data):
                return {k: v.strip() for k, v in data.items()}
    """)
    p = tmp_path / "sample.py"
    p.write_text(content)
    return p


@pytest.fixture
def sample_ts_file(tmp_path):
    content = textwrap.dedent("""\
        import { helper } from './utils';
        import type { Config } from './types';

        export function fetchData(url: string, timeout: number = 30): Promise<object> {
            const response = helper(url);
            return parseResponse(response);
        }

        function parseResponse(response: Response): object {
            return { data: response.text };
        }

        export class DataProcessor {
            constructor(private config: Config) {}

            process(raw: { url: string }): object {
                const data = fetchData(raw.url);
                return this.transform(data);
            }

            private transform(data: object): object {
                return data;
            }
        }
    """)
    p = tmp_path / "sample.ts"
    p.write_text(content)
    return p


@pytest.fixture
def sample_repo(tmp_path):
    """Minimal Python repo with cross-file calls: auth.py -> db.py -> cache.py, api.py -> auth.py."""
    cache_py = textwrap.dedent("""\
        class Cache:
            def get(self, key: str):
                return None

            def set(self, key: str, value):
                pass
    """)

    db_py = textwrap.dedent("""\
        from .cache import Cache

        def get_user(user_id: int):
            cache = Cache()
            cached = cache.get(str(user_id))
            if cached:
                return cached
            return query_db(user_id)

        def query_db(user_id: int):
            return {"id": user_id}
    """)

    auth_py = textwrap.dedent("""\
        from .db import get_user

        def authenticate(token: str) -> bool:
            user = get_user(int(token))
            return user is not None

        def get_current_user(token: str):
            return get_user(int(token))
    """)

    api_py = textwrap.dedent("""\
        from .auth import authenticate, get_current_user

        def handle_request(token: str, payload: dict):
            if not authenticate(token):
                return {"error": "unauthorized"}
            user = get_current_user(token)
            return {"user": user, "payload": payload}
    """)

    repo_dir = tmp_path / "myrepo"
    repo_dir.mkdir()
    (repo_dir / "cache.py").write_text(cache_py)
    (repo_dir / "db.py").write_text(db_py)
    (repo_dir / "auth.py").write_text(auth_py)
    (repo_dir / "api.py").write_text(api_py)
    return repo_dir
