"""End-to-end integration tests: index a sample repo and verify query results."""
from __future__ import annotations

import hashlib
from pathlib import Path

import pytest

from promptify_cmax.extractor import extract_file, FunctionInfo
from promptify_cmax.graph import find_affected_files
from promptify_cmax.index import CodeIndex
from promptify_cmax.query import extract_identifiers


# ---------------------------------------------------------------------------
# Helper: walk and index a directory of .py files
# ---------------------------------------------------------------------------

def _index_repo(repo_dir: Path, db_path: Path) -> CodeIndex:
    """Walk all .py files in repo_dir, extract and upsert into a CodeIndex.

    Skips __init__.py.  Stores relative paths (relative to repo_dir) so that
    assertions can use bare filenames like "auth.py".
    """
    idx = CodeIndex(db_path)

    for py_file in sorted(repo_dir.rglob("*.py")):
        if py_file.name.startswith("__"):
            continue

        rel = str(py_file.relative_to(repo_dir))
        file_hash = hashlib.sha256(py_file.read_bytes()).hexdigest()

        if not idx.needs_update(rel, file_hash):
            continue

        extraction = extract_file(py_file)

        for func in extraction.functions:
            # Re-create FunctionInfo with the relative path so queries match
            idx.upsert_function(FunctionInfo(
                name=func.name,
                file=rel,
                start_line=func.start_line,
                end_line=func.end_line,
                signature=func.signature,
                class_name=func.class_name,
                docstring=func.docstring,
            ))

        for call in extraction.calls:
            idx.upsert_call(rel, call.caller, call.callee)
        for imp in extraction.imports:
            idx.upsert_import(rel, imp.module, imp.name)

        idx.set_file_hash(rel, file_hash)

    return idx


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

def test_end_to_end_authenticate_bug(sample_repo, tmp_path):
    """`authenticate` bug -> auth.py + db.py.

    authenticate() lives in auth.py and calls get_user() which lives in db.py.
    At max_depth=2, both files must surface.
    """
    idx = _index_repo(sample_repo, tmp_path / "index.db")
    task = "fix the `authenticate` bug"
    identifiers = extract_identifiers(task, known_symbols=idx.all_function_names())
    assert "authenticate" in identifiers
    files = find_affected_files(idx, identifiers, max_depth=2, top_k=5)
    paths = [f.path for f in files]
    assert "auth.py" in paths
    assert "db.py" in paths  # authenticate calls get_user


def test_end_to_end_get_user_task(sample_repo, tmp_path):
    """fix the get_user function -> db.py + auth.py (callers at depth 1)."""
    idx = _index_repo(sample_repo, tmp_path / "index.db")
    task = "fix the `get_user` function in the database module"
    identifiers = extract_identifiers(task, known_symbols=idx.all_function_names())
    assert "get_user" in identifiers
    files = find_affected_files(idx, identifiers, max_depth=1, top_k=5)
    paths = [f.path for f in files]
    assert "db.py" in paths
    assert "auth.py" in paths  # authenticate and get_current_user call get_user


def test_end_to_end_excludes_unrelated(sample_repo, tmp_path):
    """get_user task at depth=1 must not surface handle_request.

    handle_request (api.py) is 2 hops from get_user (via authenticate),
    so it must not appear at max_depth=1.
    """
    idx = _index_repo(sample_repo, tmp_path / "index.db")
    task = "fix the `get_user` function"
    identifiers = extract_identifiers(task, known_symbols=idx.all_function_names())
    files = find_affected_files(idx, identifiers, max_depth=1, top_k=5)
    func_names: set[str] = set()
    for f in files:
        func_names.update(f.affected_functions)
    assert "handle_request" not in func_names


def test_incremental_reindex(sample_repo, tmp_path):
    """Second index run skips unchanged files (needs_update returns False)."""
    idx = _index_repo(sample_repo, tmp_path / "index.db")

    for py_file in sample_repo.rglob("*.py"):
        if py_file.name.startswith("__"):
            continue
        rel = str(py_file.relative_to(sample_repo))
        file_hash = hashlib.sha256(py_file.read_bytes()).hexdigest()
        assert idx.needs_update(rel, file_hash) is False
