"""Tests for the SQLite-backed CodeIndex."""
import pytest

from promptify_cmax.extractor import FunctionInfo
from promptify_cmax.index import CodeIndex


def test_create_index(tmp_path):
    idx = CodeIndex(tmp_path / "test.db")
    assert (tmp_path / "test.db").exists()


def test_insert_and_query_functions(tmp_path):
    idx = CodeIndex(tmp_path / "test.db")
    func = FunctionInfo(name="login", file="auth.py", start_line=5, end_line=10,
                        signature="(username, password)", class_name=None)
    idx.upsert_function(func)
    results = idx.find_functions("login")
    assert len(results) == 1
    assert results[0].name == "login"
    assert results[0].file == "auth.py"


def test_insert_and_query_calls(tmp_path):
    idx = CodeIndex(tmp_path / "test.db")
    f1 = FunctionInfo(name="login", file="auth.py", start_line=1, end_line=5, signature="()")
    f2 = FunctionInfo(name="get_user", file="db.py", start_line=1, end_line=5, signature="()")
    idx.upsert_function(f1)
    idx.upsert_function(f2)
    idx.upsert_call("auth.py", "login", "get_user")
    assert "get_user" in idx.get_callees_from("auth.py", "login")
    assert ("auth.py", "login") in idx.get_callers_of("get_user")


def test_file_hash_tracking(tmp_path):
    idx = CodeIndex(tmp_path / "test.db")
    idx.set_file_hash("auth.py", "abc123")
    assert idx.get_file_hash("auth.py") == "abc123"
    assert idx.get_file_hash("missing.py") is None


def test_incremental_update_skips_unchanged(tmp_path):
    idx = CodeIndex(tmp_path / "test.db")
    idx.set_file_hash("auth.py", "abc123")
    assert idx.needs_update("auth.py", "abc123") is False
    assert idx.needs_update("auth.py", "def456") is True
    assert idx.needs_update("new.py", "xyz") is True


def test_delete_file_entries(tmp_path):
    idx = CodeIndex(tmp_path / "test.db")
    func = FunctionInfo(name="login", file="auth.py", start_line=1, end_line=5, signature="()")
    idx.upsert_function(func)
    idx.delete_file("auth.py")
    assert idx.find_functions("login") == []
