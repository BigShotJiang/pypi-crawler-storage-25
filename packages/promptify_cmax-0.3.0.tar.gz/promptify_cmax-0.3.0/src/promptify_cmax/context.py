# SPDX-FileCopyrightText: 2026 Promptify LLC
# SPDX-License-Identifier: Apache-2.0
"""Function-level context extraction — read only the affected code.

Instead of returning entire files (~3K tokens each), extracts just the
affected function bodies (~50-200 tokens each) plus a compact file
header showing the imports and structure.
"""
from __future__ import annotations

from pathlib import Path

from promptify_cmax.graph import RankedFile
from promptify_cmax.index import CodeIndex, FunctionInfo


def extract_function_context(
    ranked_files: list[RankedFile],
    index: CodeIndex,
    project_root: Path,
    context_lines: int = 2,
) -> list[dict]:
    """Extract function-level context for each ranked file.

    Returns a list of dicts, each with:
      path, distance, functions: [{name, signature, lines, code}]
    """
    results = []
    for rf in ranked_files:
        abs_path = project_root / rf.path
        if not abs_path.exists():
            continue

        source_lines = abs_path.read_text().splitlines()
        funcs = index.functions_in_file(rf.path, rf.affected_functions)
        if not funcs:
            funcs = index.functions_in_file(rf.path)

        seen_ranges: list[tuple[int, int]] = []
        func_snippets = []

        for fi in _sort_by_line(funcs):
            start = max(0, fi.start_line - 1 - context_lines)
            end = min(len(source_lines), fi.end_line + context_lines)

            if _overlaps(start, end, seen_ranges):
                continue
            seen_ranges.append((start, end))

            snippet = "\n".join(source_lines[start:end])
            label = f"{fi.class_name}.{fi.name}" if fi.class_name else fi.name

            func_snippets.append({
                "name": label,
                "signature": fi.signature or "",
                "lines": f"L{fi.start_line}-{fi.end_line}",
                "code": snippet,
            })

        results.append({
            "path": rf.path,
            "distance": rf.distance,
            "reason": rf.reason,
            "functions": func_snippets,
        })

    return results


def format_function_context(extracted: list[dict]) -> str:
    """Format extracted function context as a compact text block."""
    parts = []
    for entry in extracted:
        header = f"── {entry['path']} (distance {entry['distance']}) ──"
        parts.append(header)
        for fn in entry["functions"]:
            parts.append(f"# {fn['name']}{fn['signature']} {fn['lines']}")
            parts.append(fn["code"])
            parts.append("")
    return "\n".join(parts)


def _sort_by_line(funcs: list[FunctionInfo]) -> list[FunctionInfo]:
    return sorted(funcs, key=lambda f: f.start_line)


def _overlaps(start: int, end: int, ranges: list[tuple[int, int]]) -> bool:
    for rs, re in ranges:
        if start < re and end > rs:
            return True
    return False
