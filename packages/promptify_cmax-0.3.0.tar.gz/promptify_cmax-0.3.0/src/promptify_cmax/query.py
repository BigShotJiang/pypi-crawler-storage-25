# SPDX-FileCopyrightText: 2026 Promptify LLC
# SPDX-License-Identifier: Apache-2.0
"""Identifier extraction from natural-language task descriptions."""

from __future__ import annotations

import re

_STOP_WORDS: frozenset[str] = frozenset(
    {
        "the",
        "a",
        "an",
        "bug",
        "fix",
        "error",
        "issue",
        "code",
        "file",
        "function",
        "class",
        "method",
        "test",
        "add",
        "remove",
        "update",
        "change",
    }
)

_RE_BACKTICK = re.compile(r"`(\w[\w.]*)`")
_RE_CAMEL = re.compile(r"\b([A-Z][a-z]+(?:[A-Z][a-z]*)+)\b")
_RE_SNAKE = re.compile(r"\b([a-z]\w*_\w+)\b")
_RE_DOTTED = re.compile(r"\b(\w+(?:\.\w+){2,})\b")
_RE_HINT_SPLIT = re.compile(r"[/:]")
_RE_IDENT = re.compile(r"(\w[\w.]*)")


def _is_valid(token: str) -> bool:
    """Return True if token passes length and stop-word filters."""
    return len(token) > 2 and token.lower() not in _STOP_WORDS


def extract_identifiers(
    task: str,
    *,
    edit_hint: str | None = None,
    known_symbols: set[str] | None = None,
) -> list[str]:
    """Extract code identifiers from a natural-language task description.

    Strategies applied in priority order:
    1. Backtick-quoted tokens  — highest confidence
    2. CamelCase tokens
    3. snake_case tokens
    4. Dotted paths            — last segment extracted

    Parameters
    ----------
    task:
        Natural-language task description.
    edit_hint:
        Optional file-path hint (e.g. ``"auth/session.py:login"``).
        Split on ``/`` and ``:``; identifiers from each segment are
        appended at lower priority.
    known_symbols:
        If provided, the result is filtered to only tokens present in
        this set.

    Returns
    -------
    list[str]
        Deduplicated identifiers, capped at 15.
    """
    seen: dict[str, None] = {}  # insertion-ordered dedup

    def _add(token: str) -> None:
        if _is_valid(token) and token not in seen:
            seen[token] = None

    # Strategy 1 — backtick-quoted
    for m in _RE_BACKTICK.finditer(task):
        _add(m.group(1))

    # Strategy 2 — CamelCase
    for m in _RE_CAMEL.finditer(task):
        _add(m.group(1))

    # Strategy 3 — snake_case
    for m in _RE_SNAKE.finditer(task):
        _add(m.group(1))

    # Strategy 4 — dotted paths → last segment
    for m in _RE_DOTTED.finditer(task):
        last = m.group(1).rsplit(".", 1)[-1]
        if _is_valid(last):
            seen[last] = None

    # edit_hint — split on / and :, extract identifiers from each part
    if edit_hint is not None:
        for part in _RE_HINT_SPLIT.split(edit_hint):
            for m in _RE_IDENT.finditer(part):
                _add(m.group(1))

    # Strategy 5 — plain words matched against known symbols (fallback).
    # Handles queries like "fix the HNSW search in embedding reranker"
    # where no backtick/CamelCase/snake_case patterns exist.
    # Only matches non-test symbols; requires word to be a substring of
    # the symbol name (not vice versa) to avoid over-matching.
    if known_symbols is not None and not seen:
        words = set(re.findall(r"\b(\w{4,})\b", task.lower())) - _STOP_WORDS
        for sym in known_symbols:
            if sym.startswith("test_") or sym.startswith("_test"):
                continue
            sym_lower = sym.lower()
            for word in words:
                if word in sym_lower:
                    _add(sym)
                    break

    results = list(seen.keys())

    if known_symbols is not None:
        results = [r for r in results if r in known_symbols]

    return results[:15]
