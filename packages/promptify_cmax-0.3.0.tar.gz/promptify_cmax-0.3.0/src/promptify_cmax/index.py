# SPDX-FileCopyrightText: 2026 Promptify LLC
# SPDX-License-Identifier: Apache-2.0
"""SQLite-backed code index for functions, calls, imports, and file hashes."""
from __future__ import annotations

import sqlite3
from pathlib import Path

from promptify_cmax.extractor import FunctionInfo


class CodeIndex:
    """Persistent SQLite index for extracted code structure."""

    def __init__(self, db_path: Path) -> None:
        self._db_path = db_path
        self._conn = sqlite3.connect(str(db_path))
        self._conn.row_factory = sqlite3.Row
        self._create_tables()

    # ------------------------------------------------------------------
    # Schema
    # ------------------------------------------------------------------

    def _create_tables(self) -> None:
        with self._conn:
            self._conn.executescript("""
                CREATE TABLE IF NOT EXISTS functions (
                    id          INTEGER PRIMARY KEY AUTOINCREMENT,
                    name        TEXT NOT NULL,
                    file        TEXT NOT NULL,
                    start_line  INTEGER NOT NULL,
                    end_line    INTEGER NOT NULL,
                    signature   TEXT NOT NULL,
                    class_name  TEXT,
                    docstring   TEXT
                );

                CREATE TABLE IF NOT EXISTS calls (
                    caller_file TEXT NOT NULL,
                    caller_name TEXT NOT NULL,
                    callee_name TEXT NOT NULL,
                    PRIMARY KEY (caller_file, caller_name, callee_name)
                );

                CREATE TABLE IF NOT EXISTS imports (
                    file    TEXT NOT NULL,
                    module  TEXT NOT NULL,
                    name    TEXT NOT NULL
                );

                CREATE INDEX IF NOT EXISTS idx_calls_callee
                    ON calls (callee_name);
                CREATE INDEX IF NOT EXISTS idx_imports_file_name
                    ON imports (file, name);

                CREATE TABLE IF NOT EXISTS file_hashes (
                    file    TEXT PRIMARY KEY,
                    hash    TEXT NOT NULL
                );
            """)

    # ------------------------------------------------------------------
    # Functions
    # ------------------------------------------------------------------

    def upsert_function(self, func: FunctionInfo) -> None:
        with self._conn:
            self._conn.execute(
                """
                INSERT INTO functions (name, file, start_line, end_line, signature, class_name, docstring)
                VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                (func.name, func.file, func.start_line, func.end_line,
                 func.signature, func.class_name, func.docstring),
            )

    def find_functions(self, name: str) -> list[FunctionInfo]:
        rows = self._conn.execute(
            "SELECT name, file, start_line, end_line, signature, class_name, docstring "
            "FROM functions WHERE name = ?",
            (name,),
        ).fetchall()
        return [
            FunctionInfo(
                name=row["name"],
                file=row["file"],
                start_line=row["start_line"],
                end_line=row["end_line"],
                signature=row["signature"],
                class_name=row["class_name"],
                docstring=row["docstring"],
            )
            for row in rows
        ]

    def functions_in_file(self, file: str, names: list[str] | None = None) -> list[FunctionInfo]:
        """Return functions in a file, optionally filtered to specific names."""
        if names:
            placeholders = ",".join("?" for _ in names)
            rows = self._conn.execute(
                f"SELECT name, file, start_line, end_line, signature, class_name, docstring "
                f"FROM functions WHERE file = ? AND (name IN ({placeholders}) OR class_name IN ({placeholders}))",
                (file, *names, *names),
            ).fetchall()
        else:
            rows = self._conn.execute(
                "SELECT name, file, start_line, end_line, signature, class_name, docstring "
                "FROM functions WHERE file = ?",
                (file,),
            ).fetchall()
        return [
            FunctionInfo(
                name=row["name"], file=row["file"],
                start_line=row["start_line"], end_line=row["end_line"],
                signature=row["signature"], class_name=row["class_name"],
                docstring=row["docstring"],
            )
            for row in rows
        ]

    def all_function_names(self) -> set[str]:
        rows = self._conn.execute(
            "SELECT DISTINCT name FROM functions "
            "UNION SELECT DISTINCT class_name FROM functions WHERE class_name IS NOT NULL"
        ).fetchall()
        return {row[0] for row in rows}

    def get_files_for_function(self, func_name: str) -> list[str]:
        rows = self._conn.execute(
            "SELECT DISTINCT file FROM functions WHERE name = ? OR class_name = ?",
            (func_name, func_name),
        ).fetchall()
        return [row["file"] for row in rows]

    # ------------------------------------------------------------------
    # Calls
    # ------------------------------------------------------------------

    def upsert_call(self, caller_file: str, caller: str, callee: str) -> None:
        with self._conn:
            self._conn.execute(
                "INSERT OR IGNORE INTO calls (caller_file, caller_name, callee_name) "
                "VALUES (?, ?, ?)",
                (caller_file, caller, callee),
            )

    def get_callees_from(self, caller_file: str, caller_name: str) -> list[str]:
        rows = self._conn.execute(
            "SELECT callee_name FROM calls "
            "WHERE caller_file = ? AND caller_name = ?",
            (caller_file, caller_name),
        ).fetchall()
        return [row["callee_name"] for row in rows]

    def get_callers_of(self, callee_name: str) -> list[tuple[str, str]]:
        """Return (caller_file, caller_name) for every recorded call to callee_name."""
        rows = self._conn.execute(
            "SELECT caller_file, caller_name FROM calls WHERE callee_name = ?",
            (callee_name,),
        ).fetchall()
        return [(row["caller_file"], row["caller_name"]) for row in rows]

    # ------------------------------------------------------------------
    # Imports
    # ------------------------------------------------------------------

    def upsert_import(self, file: str, module: str, name: str) -> None:
        with self._conn:
            self._conn.execute(
                "INSERT INTO imports (file, module, name) VALUES (?, ?, ?)",
                (file, module, name),
            )

    def get_import_module(self, file: str, name: str) -> str | None:
        """Return the module that `name` was imported from in `file`, or None."""
        row = self._conn.execute(
            "SELECT module FROM imports WHERE file = ? AND name = ? LIMIT 1",
            (file, name),
        ).fetchone()
        return row["module"] if row else None

    # ------------------------------------------------------------------
    # File hashes
    # ------------------------------------------------------------------

    def set_file_hash(self, file: str, hash_val: str) -> None:
        with self._conn:
            self._conn.execute(
                "INSERT OR REPLACE INTO file_hashes (file, hash) VALUES (?, ?)",
                (file, hash_val),
            )

    def get_file_hash(self, file: str) -> str | None:
        row = self._conn.execute(
            "SELECT hash FROM file_hashes WHERE file = ?", (file,)
        ).fetchone()
        return row["hash"] if row else None

    def needs_update(self, file: str, current_hash: str) -> bool:
        stored = self.get_file_hash(file)
        return stored != current_hash

    # ------------------------------------------------------------------
    # Deletion
    # ------------------------------------------------------------------

    def delete_file(self, file: str) -> None:
        with self._conn:
            self._conn.execute("DELETE FROM functions WHERE file = ?", (file,))
            self._conn.execute("DELETE FROM imports WHERE file = ?", (file,))
            self._conn.execute("DELETE FROM calls WHERE caller_file = ?", (file,))
            self._conn.execute("DELETE FROM file_hashes WHERE file = ?", (file,))

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def close(self) -> None:
        self._conn.close()
