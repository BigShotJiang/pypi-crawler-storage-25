# SPDX-FileCopyrightText: 2026 Promptify LLC
# SPDX-License-Identifier: Apache-2.0
"""MCP server exposing structural_context and reindex tools."""
from __future__ import annotations

import json
from pathlib import Path

from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import TextContent, Tool

server = Server("promptify-cmax")

# Project root is set at startup via run_server(); shared across handlers.
_project_root: Path = Path(".")


@server.list_tools()
async def list_tools() -> list[Tool]:
    return [
        Tool(
            name="structural_context",
            description=(
                "Return files most relevant to a coding task, ranked by "
                "call-graph distance from the task's entry points."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "task": {
                        "type": "string",
                        "description": "Natural-language description of the task or bug.",
                    },
                    "edit_hint": {
                        "type": "string",
                        "description": (
                            "Optional file-path hint such as 'auth.py' or "
                            "'auth/session.py:login' to seed identifier extraction."
                        ),
                    },
                    "top_k": {
                        "type": "integer",
                        "description": "Maximum number of files to return (default 5).",
                        "default": 5,
                    },
                },
                "required": ["task"],
            },
        ),
        Tool(
            name="reindex",
            description="Rebuild the structural index for the project root.",
            inputSchema={
                "type": "object",
                "properties": {},
                "required": [],
            },
        ),
    ]


@server.call_tool()
async def call_tool(name: str, arguments: dict) -> list[TextContent]:
    if name == "structural_context":
        return await _handle_structural_context(arguments)
    if name == "reindex":
        return await _handle_reindex(arguments)
    raise ValueError(f"Unknown tool: {name}")


async def _handle_structural_context(arguments: dict) -> list[TextContent]:
    from promptify_cmax.cli import _build_index
    from promptify_cmax.graph import find_affected_files
    from promptify_cmax.index import CodeIndex
    from promptify_cmax.query import extract_identifiers

    task = arguments["task"]
    edit_hint = arguments.get("edit_hint")
    top_k = int(arguments.get("top_k", 5))

    db_path = _project_root / ".promptify" / "code-index.db"

    if not db_path.exists():
        result = {"error": f"Index not found at {db_path}. Call reindex first."}
        return [TextContent(type="text", text=json.dumps(result))]

    idx = CodeIndex(db_path)
    known = idx.all_function_names()
    identifiers = extract_identifiers(task, edit_hint=edit_hint, known_symbols=known)
    ranked = find_affected_files(idx, identifiers, max_depth=2, top_k=top_k)

    from promptify_cmax.context import extract_function_context, format_function_context
    extracted = extract_function_context(ranked, idx, _project_root)
    idx.close()

    context_text = format_function_context(extracted)

    result = {
        "entry_points": identifiers,
        "files_returned": len(ranked),
        "relevant_files": [
            {
                "path": e["path"],
                "distance": e["distance"],
                "functions": [f["name"] for f in e["functions"]],
                "reason": e["reason"],
            }
            for e in extracted
        ],
        "context": context_text,
    }
    return [TextContent(type="text", text=json.dumps(result, indent=2))]


async def _handle_reindex(_arguments: dict) -> list[TextContent]:
    from promptify_cmax.cli import _build_index

    db_dir = _project_root / ".promptify"
    db_dir.mkdir(parents=True, exist_ok=True)
    db_path = db_dir / "code-index.db"

    idx, indexed, skipped = _build_index(_project_root, db_path)
    func_count = len(idx.all_function_names())
    idx.close()

    result = {
        "status": "ok",
        "files_indexed": indexed,
        "files_skipped": skipped,
        "function_count": func_count,
    }
    return [TextContent(type="text", text=json.dumps(result))]


async def run_server(project_root: Path) -> None:
    global _project_root
    _project_root = project_root

    async with stdio_server() as (read_stream, write_stream):
        await server.run(
            read_stream,
            write_stream,
            server.create_initialization_options(),
        )
