# SPDX-FileCopyrightText: 2026 Promptify LLC
# SPDX-License-Identifier: Apache-2.0
"""Tree-sitter based code extractor for Python and TypeScript."""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Iterator


@dataclass(frozen=True)
class FunctionInfo:
    name: str
    file: str
    start_line: int
    end_line: int
    signature: str
    class_name: str | None = None
    docstring: str | None = None


@dataclass(frozen=True)
class CallInfo:
    caller: str
    callee: str
    line: int


@dataclass(frozen=True)
class ImportInfo:
    module: str
    name: str
    file: str


@dataclass
class FileExtraction:
    file: str
    language: str
    functions: list[FunctionInfo]
    calls: list[CallInfo]
    imports: list[ImportInfo]


# ---------------------------------------------------------------------------
# Language detection
# ---------------------------------------------------------------------------

_EXT_TO_LANG: dict[str, str] = {
    ".py": "python",
    ".ts": "typescript",
    ".tsx": "tsx",
    ".js": "javascript",
    ".jsx": "javascript",
}


def _detect_language(path: Path) -> str:
    lang = _EXT_TO_LANG.get(path.suffix.lower())
    if lang is None:
        raise ValueError(f"Cannot detect language for {path}")
    return lang


# ---------------------------------------------------------------------------
# Parser factory
# ---------------------------------------------------------------------------

def _make_parser(language: str):
    from tree_sitter import Language, Parser

    if language == "python":
        import tree_sitter_python as tslang
        lang_obj = Language(tslang.language())
    elif language in ("typescript", "tsx"):
        import tree_sitter_typescript as tslang  # type: ignore[no-redef]
        if language == "tsx":
            lang_obj = Language(tslang.language_tsx())
        else:
            lang_obj = Language(tslang.language_typescript())
    else:
        raise ValueError(f"Unsupported language: {language}")

    parser = Parser()
    parser.language = lang_obj
    return parser


# ---------------------------------------------------------------------------
# Generic AST traversal helpers
# ---------------------------------------------------------------------------

def _walk(node) -> Iterator:
    """Yield every node in the subtree (depth-first, pre-order)."""
    yield node
    for child in node.children:
        yield from _walk(child)


def _node_text(node, source: bytes) -> str:
    return source[node.start_byte:node.end_byte].decode("utf-8", errors="replace")


def _node_lines(node) -> tuple[int, int]:
    """Return 1-based (start_line, end_line)."""
    return node.start_point[0] + 1, node.end_point[0] + 1


# ---------------------------------------------------------------------------
# Python extraction
# ---------------------------------------------------------------------------

def _extract_python_docstring(func_node, source: bytes) -> str | None:
    """Extract docstring from the body of a function_definition node."""
    body = func_node.child_by_field_name("body")
    if body is None:
        return None
    # The body is a block; find its first expression_statement child
    for child in body.children:
        if child.type == "expression_statement":
            for sub in child.children:
                if sub.type == "string":
                    raw = _node_text(sub, source)
                    # Strip surrounding quotes (""" ... """ or ' ... ')
                    stripped = raw.strip("'\"").strip()
                    # Handle triple-quote content
                    stripped = re.sub(r'^["\']+(.*?)["\']+ *$', r'\1', raw, flags=re.DOTALL).strip()
                    return stripped if stripped else None
            break
    return None


def _extract_python_signature(func_node, source: bytes) -> str:
    """Extract the parameters portion of a function definition."""
    params_node = func_node.child_by_field_name("parameters")
    if params_node is None:
        return "()"
    return _node_text(params_node, source)


def _extract_python_calls_from_body(func_node, source: bytes) -> list[tuple[str, int]]:
    """Return (callee_name, 1-based line) for all calls inside a function body."""
    calls: list[tuple[str, int]] = []
    for node in _walk(func_node):
        if node.type == "call":
            func_part = node.child_by_field_name("function")
            if func_part is None:
                continue
            line = node.start_point[0] + 1
            if func_part.type == "identifier":
                calls.append((_node_text(func_part, source), line))
            elif func_part.type == "attribute":
                # e.g. self.transform(data) -> callee = "transform"
                attr = func_part.child_by_field_name("attribute")
                if attr is not None:
                    calls.append((_node_text(attr, source), line))
    return calls


def _extract_python(path: Path, source: bytes, parser) -> FileExtraction:
    tree = parser.parse(source)
    root = tree.root_node

    functions: list[FunctionInfo] = []
    calls: list[CallInfo] = []
    imports: list[ImportInfo] = []
    file_str = str(path)

    def _process_class(class_node):
        class_name_node = class_node.child_by_field_name("name")
        class_name = _node_text(class_name_node, source) if class_name_node else None
        body = class_node.child_by_field_name("body")
        if body is None:
            return
        for child in body.children:
            if child.type == "function_definition":
                _process_function(child, class_name)
            elif child.type == "decorated_definition":
                # Find the function inside decorated_definition
                for sub in child.children:
                    if sub.type == "function_definition":
                        _process_function(sub, class_name)

    def _process_function(func_node, class_name: str | None):
        name_node = func_node.child_by_field_name("name")
        if name_node is None:
            return
        name = _node_text(name_node, source)
        start_line, end_line = _node_lines(func_node)
        signature = _extract_python_signature(func_node, source)
        docstring = _extract_python_docstring(func_node, source)

        functions.append(FunctionInfo(
            name=name,
            file=file_str,
            start_line=start_line,
            end_line=end_line,
            signature=signature,
            class_name=class_name,
            docstring=docstring,
        ))

        # Extract calls from this function
        caller = name
        for callee, line in _extract_python_calls_from_body(func_node, source):
            calls.append(CallInfo(caller=caller, callee=callee, line=line))

    # Walk top-level statements
    for node in root.children:
        if node.type == "function_definition":
            _process_function(node, None)
        elif node.type == "decorated_definition":
            for sub in node.children:
                if sub.type == "function_definition":
                    _process_function(sub, None)
                elif sub.type == "class_definition":
                    _process_class(sub)
        elif node.type == "class_definition":
            _process_class(node)
        elif node.type == "import_from_statement":
            _process_import_from(node, source, file_str, imports)
        elif node.type == "import_statement":
            _process_import(node, source, file_str, imports)

    return FileExtraction(
        file=file_str,
        language="python",
        functions=functions,
        calls=calls,
        imports=imports,
    )


def _process_import_from(node, source: bytes, file_str: str, imports: list[ImportInfo]):
    """Handle `from X import Y, Z` statements."""
    module_node = node.child_by_field_name("module_name")
    if module_node is None:
        return
    module = _node_text(module_node, source)
    # Remove leading dot(s) from relative imports
    module = module.lstrip(".")

    for child in node.children:
        if child.type == "dotted_name" and child != module_node:
            imports.append(ImportInfo(module=module, name=_node_text(child, source), file=file_str))
        elif child.type == "aliased_import":
            name_node = child.child_by_field_name("name")
            if name_node:
                imports.append(ImportInfo(module=module, name=_node_text(name_node, source), file=file_str))
        elif child.type == "identifier" and _node_text(child, source) not in ("from", "import"):
            # Fallback: plain identifier that is neither keyword
            pass

    # Fallback: collect all identifiers that follow "import" keyword
    saw_import = False
    for child in node.children:
        text = _node_text(child, source)
        if text == "import":
            saw_import = True
            continue
        if saw_import and child.type in ("dotted_name", "identifier"):
            imports.append(ImportInfo(module=module, name=text, file=file_str))
        elif saw_import and child.type == "aliased_import":
            name_node = child.child_by_field_name("name")
            if name_node:
                imports.append(ImportInfo(module=module, name=_node_text(name_node, source), file=file_str))


def _process_import(node, source: bytes, file_str: str, imports: list[ImportInfo]):
    """Handle plain `import X` statements."""
    for child in node.children:
        if child.type == "dotted_name":
            name = _node_text(child, source)
            imports.append(ImportInfo(module=name, name=name, file=file_str))
        elif child.type == "aliased_import":
            name_node = child.child_by_field_name("name")
            if name_node:
                n = _node_text(name_node, source)
                imports.append(ImportInfo(module=n, name=n, file=file_str))


# ---------------------------------------------------------------------------
# TypeScript extraction
# ---------------------------------------------------------------------------

def _extract_typescript(path: Path, source: bytes, parser) -> FileExtraction:
    tree = parser.parse(source)
    root = tree.root_node

    functions: list[FunctionInfo] = []
    calls: list[CallInfo] = []
    imports: list[ImportInfo] = []
    file_str = str(path)

    def _add_function(node, name: str, class_name: str | None):
        start_line, end_line = _node_lines(node)
        # Build a simple signature from parameter node if available
        params = node.child_by_field_name("parameters") or node.child_by_field_name("formal_parameters")
        signature = _node_text(params, source) if params else "()"
        functions.append(FunctionInfo(
            name=name,
            file=file_str,
            start_line=start_line,
            end_line=end_line,
            signature=signature,
            class_name=class_name,
        ))
        # Calls
        for sub in _walk(node):
            if sub.type == "call_expression":
                func_part = sub.child_by_field_name("function")
                if func_part is None:
                    continue
                line = sub.start_point[0] + 1
                if func_part.type == "identifier":
                    calls.append(CallInfo(caller=name, callee=_node_text(func_part, source), line=line))
                elif func_part.type == "member_expression":
                    prop = func_part.child_by_field_name("property")
                    if prop:
                        calls.append(CallInfo(caller=name, callee=_node_text(prop, source), line=line))

    def _process_ts_class(class_node, class_name: str):
        body = class_node.child_by_field_name("body")
        if body is None:
            return
        for child in body.children:
            if child.type == "method_definition":
                name_node = child.child_by_field_name("name")
                if name_node:
                    _add_function(child, _node_text(name_node, source), class_name)

    for node in _walk(root):
        if node.type == "function_declaration":
            name_node = node.child_by_field_name("name")
            if name_node:
                _add_function(node, _node_text(name_node, source), None)
        elif node.type == "lexical_declaration":
            # const foo = (...) => { ... }  or  const foo = function(...) { ... }
            for decl in node.children:
                if decl.type == "variable_declarator":
                    name_node = decl.child_by_field_name("name")
                    value_node = decl.child_by_field_name("value")
                    if name_node and value_node and value_node.type in ("arrow_function", "function"):
                        _add_function(value_node, _node_text(name_node, source), None)
        elif node.type == "class_declaration":
            name_node = node.child_by_field_name("name")
            if name_node:
                _process_ts_class(node, _node_text(name_node, source))
        elif node.type == "import_statement":
            _extract_ts_imports(node, source, file_str, imports)

    return FileExtraction(
        file=file_str,
        language="typescript",
        functions=functions,
        calls=calls,
        imports=imports,
    )


def _extract_ts_imports(node, source: bytes, file_str: str, imports: list[ImportInfo]):
    """Handle TS `import { X, Y } from 'mod'` and `import type { X } from 'mod'`."""
    # Find source string (the module path)
    module = ""
    for child in node.children:
        if child.type == "string":
            raw = _node_text(child, source).strip("'\"")
            module = raw
            break

    for child in _walk(node):
        if child.type == "import_specifier":
            name_node = child.child_by_field_name("name")
            if name_node:
                imports.append(ImportInfo(module=module, name=_node_text(name_node, source), file=file_str))


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def extract_file(path: str | Path, language: str | None = None) -> FileExtraction:
    """Parse a source file and return its structural extraction.

    Args:
        path: Path to the source file.
        language: Language override. If None, detected from file extension.

    Returns:
        FileExtraction with functions, calls, and imports.
    """
    path = Path(path)
    if language is None:
        language = _detect_language(path)

    source = path.read_bytes()
    parser = _make_parser(language)

    if language == "python":
        return _extract_python(path, source, parser)
    elif language in ("typescript", "tsx"):
        return _extract_typescript(path, source, parser)
    else:
        raise ValueError(f"Extraction not implemented for language: {language}")
