# SPDX-FileCopyrightText: 2026 Promptify LLC
# SPDX-License-Identifier: Apache-2.0
"""BFS-based call graph traversal with FQN-aware resolution.

Nodes are `(file, function_name)` tuples, not bare names. Call edges
are resolved through the caller's import bindings and same-file scope,
so two functions named `helper` in different files do not collapse
into a single graph node.

When a callee_name has only one definition in the index, we accept
the edge unambiguously. With ≥2 candidates we require either a
matching `from M import name` in the caller's file or a same-file
definition; otherwise the edge is dropped.
"""
from __future__ import annotations

from collections import deque
from dataclasses import dataclass

from promptify_cmax.index import CodeIndex


@dataclass(frozen=True)
class RankedFile:
    path: str
    distance: int
    affected_functions: list[str]
    reason: str


def _module_matches_path(module: str, file_path: str) -> bool:
    """Check whether `file_path` is the on-disk location of Python module `module`.

    Handles both submodule files (`a.b.c` -> `.../a/b/c.py`) and packages
    (`a.b` -> `.../a/b/__init__.py`). Matches anywhere along the path so
    `dca.pillar_v.embedding_reranker` resolves under
    `dca/src/dca/pillar_v/embedding_reranker.py`.
    """
    if not module:
        return False
    parts = module.split(".")
    base = "/".join(parts)
    candidates = (base + ".py", base + "/__init__.py")
    norm = file_path.replace("\\", "/")
    return any(norm == c or norm.endswith("/" + c) for c in candidates)


def _resolve_callee_file(
    caller_file: str,
    callee_name: str,
    index: CodeIndex,
) -> str | None:
    """Resolve `caller_file`'s reference to `callee_name` to a single file.

    Returns the file path of the resolved callee, or None when the call
    is ambiguous and cannot be attributed to a specific definition.
    """
    candidates = index.get_files_for_function(callee_name)
    if not candidates:
        return None

    # Single global definition is unambiguous regardless of import context.
    if len(candidates) == 1:
        return candidates[0]

    # Same-file scope wins over imports (Python's lexical resolution).
    if caller_file in candidates:
        return caller_file

    module = index.get_import_module(caller_file, callee_name)
    if module is None:
        return None
    for cand in candidates:
        if _module_matches_path(module, cand):
            return cand
    return None


def _expand_callees(
    file: str, name: str, index: CodeIndex
) -> list[tuple[str, str]]:
    edges: list[tuple[str, str]] = []
    for callee_name in index.get_callees_from(file, name):
        normalized = callee_name.split(".")[-1]
        resolved = _resolve_callee_file(file, normalized, index)
        if resolved is not None:
            edges.append((resolved, normalized))
    return edges


def _expand_callers(
    file: str, name: str, index: CodeIndex
) -> list[tuple[str, str]]:
    """Return (caller_file, caller_name) pairs whose call edge resolves to (file, name)."""
    edges: list[tuple[str, str]] = []
    for caller_file, caller_name in index.get_callers_of(name):
        if _resolve_callee_file(caller_file, name, index) == file:
            edges.append((caller_file, caller_name))
    return edges


def find_affected_files(
    index: CodeIndex,
    entry_points: list[str],
    max_depth: int = 2,
    top_k: int = 10,
) -> list[RankedFile]:
    """BFS from entry_points through the call graph, returning ranked files.

    Entry points are bare names; each name expands to every file that
    defines it (legitimate when the user supplies an unqualified
    identifier from a task description). Subsequent hops are
    FQN-resolved per `_resolve_callee_file`.
    """
    visited: dict[tuple[str, str], int] = {}
    queue: deque[tuple[str, str, int]] = deque()

    for ep_name in entry_points:
        for ep_file in index.get_files_for_function(ep_name):
            node = (ep_file, ep_name)
            if node not in visited:
                visited[node] = 0
                queue.append((ep_file, ep_name, 0))

    while queue:
        file, name, depth = queue.popleft()
        if depth >= max_depth:
            continue

        for nf, nn in _expand_callees(file, name, index):
            node = (nf, nn)
            if node not in visited:
                visited[node] = depth + 1
                queue.append((nf, nn, depth + 1))

        for nf, nn in _expand_callers(file, name, index):
            node = (nf, nn)
            if node not in visited:
                visited[node] = depth + 1
                queue.append((nf, nn, depth + 1))

    file_data: dict[str, tuple[int, list[str]]] = {}
    for (file, name), dist in visited.items():
        if file not in file_data:
            file_data[file] = (dist, [name])
            continue
        cur_dist, names = file_data[file]
        names.append(name)
        file_data[file] = (min(cur_dist, dist), names)

    _test_markers = ("/test_", "/tests/", "test_", "/conftest.")

    ranked = [
        RankedFile(
            path=path,
            distance=dist,
            affected_functions=names,
            reason=f"BFS distance {dist}, {len(names)} affected function(s)",
        )
        for path, (dist, names) in file_data.items()
        if not any(m in path for m in _test_markers)
    ]
    ranked.sort(key=lambda r: (r.distance, -len(r.affected_functions)))
    return ranked[:top_k]
