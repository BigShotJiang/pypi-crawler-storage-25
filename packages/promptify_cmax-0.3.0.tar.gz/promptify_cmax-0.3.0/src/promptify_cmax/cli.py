# SPDX-FileCopyrightText: 2026 Promptify LLC
# SPDX-License-Identifier: Apache-2.0
"""CLI entry point for promptify-cmax."""
from __future__ import annotations

import argparse
import asyncio
import hashlib
import json
import time
from pathlib import Path

from promptify_cmax.extractor import FunctionInfo, extract_file
from promptify_cmax.graph import find_affected_files
from promptify_cmax.index import CodeIndex
from promptify_cmax.query import extract_identifiers

SUPPORTED_EXTENSIONS = {".py", ".ts", ".tsx", ".js", ".jsx"}


def _build_index(project_root: Path, db_path: Path) -> tuple[CodeIndex, int, int]:
    """Walk project_root, extract all supported source files, upsert into index.

    Returns (index, indexed_count, skipped_count).
    """
    idx = CodeIndex(db_path)
    indexed = skipped = 0

    for src_file in sorted(project_root.rglob("*")):
        if not src_file.is_file() or src_file.suffix not in SUPPORTED_EXTENSIONS:
            continue
        if any(
            p.startswith(".") or p in ("node_modules", "__pycache__")
            for p in src_file.relative_to(project_root).parts
        ):
            continue

        rel = str(src_file.relative_to(project_root))
        file_hash = hashlib.sha256(src_file.read_bytes()).hexdigest()

        if not idx.needs_update(rel, file_hash):
            skipped += 1
            continue

        try:
            extraction = extract_file(src_file)
        except Exception:
            continue

        idx.delete_file(rel)
        for func in extraction.functions:
            idx.upsert_function(
                FunctionInfo(
                    name=func.name,
                    file=rel,
                    start_line=func.start_line,
                    end_line=func.end_line,
                    signature=func.signature,
                    class_name=func.class_name,
                    docstring=func.docstring,
                )
            )
        for call in extraction.calls:
            idx.upsert_call(rel, call.caller, call.callee)
        for imp in extraction.imports:
            idx.upsert_import(rel, imp.module, imp.name)

        idx.set_file_hash(rel, file_hash)
        indexed += 1

    return idx, indexed, skipped


def _cmd_index(args: argparse.Namespace) -> None:
    project_root = Path(args.project_root).resolve()
    db_dir = project_root / ".promptify"
    db_dir.mkdir(parents=True, exist_ok=True)
    db_path = db_dir / "code-index.db"

    t0 = time.monotonic()
    idx, indexed, skipped = _build_index(project_root, db_path)
    elapsed = time.monotonic() - t0

    func_count = len(idx.all_function_names())
    idx.close()

    print(f"Index: {db_path}")
    print(f"Files indexed : {indexed}")
    print(f"Files skipped : {skipped}")
    print(f"Functions     : {func_count}")
    print(f"Time          : {elapsed:.2f}s")


def _cmd_query(args: argparse.Namespace) -> None:
    project_root = Path(args.project_root).resolve()
    db_path = project_root / ".promptify" / "code-index.db"

    if not db_path.exists():
        print(json.dumps({"error": f"Index not found: {db_path}. Run `promptify-cmax index` first."}))
        return

    idx = CodeIndex(db_path)
    known = idx.all_function_names()

    identifiers = extract_identifiers(
        args.task,
        edit_hint=args.edit_hint,
        known_symbols=known,
    )

    top_k = args.top_k
    ranked = find_affected_files(idx, identifiers, max_depth=2, top_k=top_k)

    from promptify_cmax.context import extract_function_context, format_function_context
    extracted = extract_function_context(ranked, idx, Path(args.project_root))
    idx.close()

    context_text = format_function_context(extracted)

    result = {
        "entry_points": identifiers,
        "files_returned": len(ranked),
        "relevant_files": [
            {
                "path": e["path"],
                "distance": e["distance"],
                "functions": [f["name"] for f in e["functions"]],
                "reason": e["reason"],
            }
            for e in extracted
        ],
    }
    print(json.dumps(result, indent=2))
    if not args.json_only:
        print("\n" + context_text)


def _cmd_serve(args: argparse.Namespace) -> None:
    from promptify_cmax.server import run_server

    project_root = Path(args.project_root).resolve()
    asyncio.run(run_server(project_root))


def main() -> None:
    parser = argparse.ArgumentParser(
        prog="promptify-cmax",
        description="Call-graph-aware code context retrieval",
    )
    subparsers = parser.add_subparsers(dest="command", required=True)

    # --- index ---
    p_index = subparsers.add_parser("index", help="Build or update the structural index")
    p_index.add_argument(
        "--project-root",
        default=".",
        help="Root directory to index (default: current directory)",
    )
    p_index.set_defaults(func=_cmd_index)

    # --- query ---
    p_query = subparsers.add_parser("query", help="Query for files relevant to a task")
    p_query.add_argument("task", help="Natural-language task description")
    p_query.add_argument(
        "--project-root",
        default=".",
        help="Root directory containing the index (default: current directory)",
    )
    p_query.add_argument(
        "--edit-hint",
        default=None,
        help="Optional file:function hint to guide identifier extraction",
    )
    p_query.add_argument(
        "--top-k",
        type=int,
        default=5,
        help="Maximum number of files to return (default: 5)",
    )
    p_query.add_argument(
        "--json-only",
        action="store_true",
        help="Output JSON metadata only, no code context",
    )
    p_query.set_defaults(func=_cmd_query)

    # --- serve ---
    p_serve = subparsers.add_parser("serve", help="Start the MCP server")
    p_serve.add_argument(
        "--project-root",
        default=".",
        help="Root directory to use for the index (default: current directory)",
    )
    p_serve.set_defaults(func=_cmd_serve)

    args = parser.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
