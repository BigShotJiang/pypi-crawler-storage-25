# Contributing to promptify-cmax

Thanks for your interest. This project is Apache-2.0 licensed and developed by [Promptify LLC](https://promptify.com).

## Quick start

```bash
git clone https://github.com/promptify-com/promptify-cmax
cd promptify-cmax
uv sync
uv run pytest
```

All 33 tests should pass.

## Development workflow

- **Tests-first.** Every behavior change ships with a failing test that turns green. Bug fixes ship with a regression test that captures the bug.
- **Small PRs.** One concern per PR; rebase rather than merge-commit.
- **Style.** No formatter is enforced yet; match what's already there. Type hints on public functions.
- **Conventional Commits** for the subject line: `feat:`, `fix:`, `refactor:`, `test:`, `docs:`, `chore:`.

## DCO sign-off (after the first external PR)

Once external contributions start landing, every commit will need a `Signed-off-by:` line per the [Developer Certificate of Origin](https://developercertificate.org/). Add it with:

```bash
git commit -s -m "your message"
```

Until then, this isn't required — sign-off enforcement will go on with the first external PR, not before.

## Reporting issues

Please include:
- The query or task that produced the unexpected result
- The relevant slice of `promptify-cmax query --top-k 10` output
- Python version and OS
- Project size (rough function count from `promptify-cmax index`)

## What's in scope

- Bug fixes in the call-graph builder, FQN resolution, query identifier extraction
- New language support (Go, Rust, Java, C# are open ground; mention before starting)
- Performance work on large repos (>10k files)
- MCP protocol compliance fixes

## What's not in scope (yet)

- Hosted-tier features (multi-repo index, analytics, editor extensions) — those live in the Promptify SaaS layer, not this package
- Vendoring tree-sitter grammars (we depend on the official PyPI bindings)
- Telemetry of any kind

## License

By contributing, you agree your contributions are licensed under Apache-2.0, the same license as the project.
