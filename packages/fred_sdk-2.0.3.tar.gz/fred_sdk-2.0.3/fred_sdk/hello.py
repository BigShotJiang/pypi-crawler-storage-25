# Copyright Thales 2026
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Hello-world API surface for the starter SDK."""

from __future__ import annotations


def hello_message(name: str | None = None) -> str:
    """Return a friendly greeting for a hello-world SDK call.

    Why: Provide a tiny, stable API entry point that proves the SDK is importable.
    How: Pass an optional display name to customize the greeting.
    Example:
        >>> from fred_sdk import hello_message
        >>> hello_message("Ada")
        'Hello, Ada!'
    """

    cleaned_name = (name or "").strip() or "world"
    return f"Hello, {cleaned_name}!"
