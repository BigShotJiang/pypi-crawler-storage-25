#exonware/xwsyntax/tests/1.unit/conftest.py
"""
Unit test fixtures for xwsyntax.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
@pytest.fixture

def sample_json_ast():
    """Sample JSON AST for testing."""
    from exonware.xwsyntax import BidirectionalGrammar
    grammar = BidirectionalGrammar.load('json')
    return grammar.parse('{"test": "data", "number": 42}')
@pytest.fixture

def sample_sql_text():
    """Sample SQL query text."""
    return "SELECT name, age FROM users WHERE age > 30"
@pytest.fixture

def large_json_text():
    """Large JSON for optimization testing."""
    items = ','.join([f'{{"id": {i}, "value": "item_{i}"}}' for i in range(150)])
    return f'{{"items": [{items}]}}'
