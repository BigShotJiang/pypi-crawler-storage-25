// mongodb.monarch.ts
// Auto-generated Monaco language definition
export const mongodbLanguage = {
  "defaultToken": "",
  "tokenPostfix": ".mongodb",
  "keywords": [
    "Date",
    "ISODate",
    "ObjectId",
    "aggregate",
    "countDocuments",
    "db",
    "deleteMany",
    "deleteOne",
    "false",
    "find",
    "insertMany",
    "insertOne",
    "new",
    "null",
    "project",
    "replaceOne",
    "true",
    "updateMany",
    "updateOne"
  ],
  "operators": [
    "$addFields",
    "$addToSet",
    "$all",
    "$and",
    "$bucket",
    "$count",
    "$elemMatch",
    "$eq",
    "$exists",
    "$facet",
    "$graphLookup",
    "$group",
    "$gt",
    "$gte",
    "$in",
    "$inc",
    "$limit",
    "$lookup",
    "$lt",
    "$lte",
    "$match",
    "$mul",
    "$ne",
    "$nin",
    "$nor",
    "$not",
    "$or",
    "$pop",
    "$project",
    "$pull",
    "$push",
    "$regex",
    "$rename",
    "$replaceRoot",
    "$set",
    "$size",
    "$skip",
    "$sort",
    "$text",
    "$type",
    "$unset",
    "$unwind",
    "$where",
    "(",
    ")",
    ",",
    ".",
    "/ | /",
    "0",
    "1",
    ":",
    "[",
    "[^",
    "]",
    "]*",
    "{",
    "}"
  ],
  "symbols": "\\$all|0|\\$or|:|\\$gt|\\.|,|\\$where|\\$nor|\\$sort|\\$unset|\\$pop|\\$mul|\\$set|\\}|\\]|\\{|\\$skip|\\$unwind|\\$in|\\$and|\\$push|1|\\$facet|\\$ne|\\$addFields|\\$count|\\(|\\$lookup|\\$text|\\$inc|\\$exists|\\$replaceRoot|\\$match|\\)|\\$elemMatch|\\$project|\\]\\*|\\$nin|\\$lt|\\$addToSet|\\$regex|\\$limit|\\$graphLookup|\\[\\^|\\$lte|\\$bucket|\\$type|\\$eq|\\$gte|\\$rename|\\$not|/\\ \\|\\ /|\\$pull|\\[|\\$group|\\$size",
  "brackets": [
    {
      "open": "(",
      "close": ")",
      "token": "delimiter.parenthesis"
    },
    {
      "open": "[",
      "close": "]",
      "token": "delimiter.square"
    },
    {
      "open": "{",
      "close": "}",
      "token": "delimiter.curly"
    }
  ],
  "tokenizer": {
    "root": [
      {
        "include": "@whitespace"
      },
      [
        "/\\d+(\\.\\d+)?([eE][+-]?\\d+)?/",
        "number"
      ],
      [
        "/\"([^\"\\\\]|\\\\.)*\"/",
        "string"
      ],
      [
        "/'([^'\\\\]|\\\\.)*'/",
        "string"
      ],
      [
        "/[a-zA-Z_][\\w]*/",
        {
          "cases": {
            "@keywords": "keyword",
            "@default": "identifier"
          }
        }
      ],
      [
        "/\\$replaceRoot/",
        "operator"
      ],
      [
        "/\\$graphLookup/",
        "operator"
      ],
      [
        "/\\$addFields/",
        "operator"
      ],
      [
        "/\\$elemMatch/",
        "operator"
      ],
      [
        "/\\$addToSet/",
        "operator"
      ],
      [
        "/\\$project/",
        "operator"
      ],
      [
        "/\\$unwind/",
        "operator"
      ],
      [
        "/\\$lookup/",
        "operator"
      ],
      [
        "/\\$exists/",
        "operator"
      ],
      [
        "/\\$bucket/",
        "operator"
      ],
      [
        "/\\$rename/",
        "operator"
      ],
      [
        "/\\$where/",
        "operator"
      ],
      [
        "/\\$unset/",
        "operator"
      ],
      [
        "/\\$facet/",
        "operator"
      ],
      [
        "/\\$count/",
        "operator"
      ],
      [
        "/\\$match/",
        "operator"
      ],
      [
        "/\\$regex/",
        "operator"
      ],
      [
        "/\\$limit/",
        "operator"
      ],
      [
        "/\\$group/",
        "operator"
      ],
      [
        "/\\$sort/",
        "operator"
      ],
      [
        "/\\$skip/",
        "operator"
      ],
      [
        "/\\$push/",
        "operator"
      ],
      [
        "/\\$text/",
        "operator"
      ],
      [
        "/\\$type/",
        "operator"
      ],
      [
        "//\\ \\|\\ //",
        "operator"
      ],
      [
        "/\\$pull/",
        "operator"
      ],
      [
        "/\\$size/",
        "operator"
      ],
      [
        "/\\$all/",
        "operator"
      ],
      [
        "/\\$nor/",
        "operator"
      ],
      [
        "/\\$pop/",
        "operator"
      ],
      [
        "/\\$mul/",
        "operator"
      ],
      [
        "/\\$set/",
        "operator"
      ],
      [
        "/\\$and/",
        "operator"
      ],
      [
        "/\\$inc/",
        "operator"
      ],
      [
        "/\\$nin/",
        "operator"
      ],
      [
        "/\\$lte/",
        "operator"
      ],
      [
        "/\\$gte/",
        "operator"
      ],
      [
        "/\\$not/",
        "operator"
      ],
      [
        "/\\$or/",
        "operator"
      ],
      [
        "/\\$gt/",
        "operator"
      ],
      [
        "/\\$in/",
        "operator"
      ],
      [
        "/\\$ne/",
        "operator"
      ],
      [
        "/\\$lt/",
        "operator"
      ],
      [
        "/\\$eq/",
        "operator"
      ],
      [
        "/\\]\\*/",
        "operator"
      ],
      [
        "/\\[\\^/",
        "operator"
      ],
      [
        "/0/",
        "operator"
      ],
      [
        "/:/",
        "operator"
      ],
      [
        "/\\./",
        "operator"
      ],
      [
        "/,/",
        "operator"
      ],
      [
        "/\\}/",
        "operator"
      ],
      [
        "/\\]/",
        "operator"
      ],
      [
        "/\\{/",
        "operator"
      ],
      [
        "/1/",
        "operator"
      ],
      [
        "/\\(/",
        "operator"
      ],
      [
        "/\\)/",
        "operator"
      ],
      [
        "/\\[/",
        "operator"
      ],
      [
        "/[()[\\]{}]/",
        "@brackets"
      ],
      [
        "/[;,.]/",
        "delimiter"
      ]
    ],
    "whitespace": [
      [
        "/[ \\t\\r\\n]+/",
        ""
      ],
      [
        "/--.*$/",
        "comment"
      ],
      [
        "/\\/\\/.*$/",
        "comment"
      ],
      [
        "/\\/\\*/",
        "comment",
        "@comment"
      ]
    ],
    "comment": [
      [
        "/[^/*]+/",
        "comment"
      ],
      [
        "/\\*\\//",
        "comment",
        "@pop"
      ],
      [
        "/[/*]/",
        "comment"
      ]
    ]
  }
};
export const mongodbLanguageConfig = {
  "brackets": [
    [
      "(",
      ")"
    ],
    [
      "[",
      "]"
    ],
    [
      "{",
      "}"
    ]
  ],
  "autoClosingPairs": [
    {
      "open": "(",
      "close": ")"
    },
    {
      "open": "[",
      "close": "]"
    },
    {
      "open": "{",
      "close": "}"
    },
    {
      "open": "'",
      "close": "'"
    }
  ],
  "surroundingPairs": [
    {
      "open": "(",
      "close": ")"
    },
    {
      "open": "[",
      "close": "]"
    },
    {
      "open": "{",
      "close": "}"
    },
    {
      "open": "'",
      "close": "'"
    }
  ]
};
// Register with Monaco Editor
export function registerMongodbLanguage(monaco: any) {
  monaco.languages.register({ id: 'mongodb' });
  monaco.languages.setMonarchTokensProvider('mongodb', mongodbLanguage);
  monaco.languages.setLanguageConfiguration('mongodb', mongodbLanguageConfig);
}
