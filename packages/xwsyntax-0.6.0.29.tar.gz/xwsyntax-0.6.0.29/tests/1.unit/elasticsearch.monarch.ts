// elasticsearch.monarch.ts
// Auto-generated Monaco language definition
export const elasticsearchLanguage = {
  "defaultToken": "",
  "tokenPostfix": ".elasticsearch",
  "operators": [
    "\n\n// Aggregation\naggregation_query: ",
    "\n\n// Bool query\nbool_query: ",
    "\n\n// Exists query\nexists_query: ",
    "\n\n// Nested query\nnested_query: ",
    "\n\n// Range query\nrange_query: ",
    "\n\n// Terminals\nIDENTIFIER: /[a-zA-Z_][a-zA-Z0-9_]*/\nSTRING: /",
    "\n\n// Wildcard query\nwildcard_query: ",
    "\n\nNULL: ",
    "\n\nagg_definition: STRING ",
    "\n\nagg_param: STRING ",
    "\n\nagg_params: ",
    "\n\nagg_type: ",
    "\n\nbool_clauses: bool_clause (",
    "\n\nfield_match: STRING ",
    "\n\nfield_value: STRING ",
    "\n\nfuzzy_options: fuzzy_option (",
    "\n\nmatch_options: match_option (",
    "\n\nmatch_query: ",
    "\n\nmulti_match_params: ",
    "\n\nquery_string_options: query_string_option (",
    "\n\nrange_condition: range_op ",
    "\n           | query\n\n// Multi-match query\nmulti_match_query: ",
    "\n        | ",
    " (",
    " (STRING | NUMBER)\n            | ",
    " (STRING | match_params)\n\nmatch_params: ",
    " NUMBER\n\n// Prefix query\nprefix_query: ",
    " NUMBER\n\nquery_array: ",
    " NUMBER\n            | ",
    " STRING\n\n// Fuzzy query\nfuzzy_query: ",
    " STRING\n\n// Term queries\nterm_query: ",
    " STRING\n                   | ",
    " STRING ",
    " STRING (",
    " STRING [",
    " STRING)* ",
    " [",
    " agg_definition (",
    " agg_definition)* ",
    " agg_param (",
    " agg_param)* ",
    " agg_params ",
    " agg_type ",
    " bool_clause)*\n\nbool_clause: ",
    " bool_clauses ",
    " field_match ",
    " field_value ",
    " fuzzy_option)*\n\nfuzzy_option: ",
    " fuzzy_options] ",
    " match_option)*\n\nmatch_option: ",
    " match_options]\n\n// Query string\nquery_string_query: ",
    " match_options] ",
    " multi_match_params ",
    " query ",
    " query (",
    " query)* ",
    " query_array\n           | ",
    " query_string_option)*\n\nquery_string_option: ",
    " query_string_options] ",
    " range_condition (",
    " range_condition)* ",
    " value\n\n// Values\nvalue: STRING | NUMBER | BOOLEAN_LITERAL | NULL\n\nBOOLEAN_LITERAL: ",
    " value\n\nrange_op: ",
    " value\n\nterms_query: ",
    " value (",
    " value)* ",
    " | ",
    ")\n                   | ",
    ")\n            | ",
    "AND\\",
    "OR\\",
    "\\",
    "]*",
    "aggs\\",
    "analyzer\\",
    "and\\",
    "avg\\",
    "bool\\",
    "cardinality\\",
    "date_histogram\\",
    "default_field\\",
    "default_operator\\",
    "exists\\",
    "field\\",
    "fields\\",
    "filter\\",
    "fuzziness\\",
    "fuzzy\\",
    "gt\\",
    "gte\\",
    "histogram\\",
    "lt\\",
    "lte\\",
    "match\\",
    "max\\",
    "min\\",
    "minimum_should_match\\",
    "multi_match\\",
    "must\\",
    "must_not\\",
    "nested\\",
    "operator\\",
    "or\\",
    "path\\",
    "prefix\\",
    "prefix_length\\",
    "query\\",
    "query_string\\",
    "range\\",
    "should\\",
    "stats\\",
    "sum\\",
    "term\\",
    "terms\\",
    "value\\",
    "wildcard\\",
    "{"
  ],
  "symbols": "\\\n\\\nmatch_query:\\ |\\ \\(STRING\\ \\|\\ NUMBER\\)\\\n\\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\|\\ |\\\n\\\n//\\ Aggregation\\\naggregation_query:\\ |\\ \\(STRING\\ \\|\\ match_params\\)\\\n\\\nmatch_params:\\ |\\\n\\\nbool_clauses:\\ bool_clause\\ \\(|\\\n\\\nfuzzy_options:\\ fuzzy_option\\ \\(|prefix\\\\|\\ match_options\\]\\ |\\ query\\ \\(|stats\\\\|\\\n\\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\|\\ query\\\n\\\n//\\ Multi\\-match\\ query\\\nmulti_match_query:\\ |prefix_length\\\\|filter\\\\|\\ field_match\\ |minimum_should_match\\\\|fields\\\\|sum\\\\|\\ \\|\\ |should\\\\|and\\\\|\\ \\(|\\ agg_type\\ |\\\n\\\nagg_type:\\ |terms\\\\|OR\\\\|aggs\\\\|\\\n\\\n//\\ Bool\\ query\\\nbool_query:\\ |\\\n\\\n//\\ Terminals\\\nIDENTIFIER:\\ /\\[a\\-zA\\-Z_\\]\\[a\\-zA\\-Z0\\-9_\\]\\*/\\\nSTRING:\\ /|\\ \\[|nested\\\\|\\ STRING\\ \\[|lt\\\\|or\\\\|\\\n\\\n//\\ Nested\\ query\\\nnested_query:\\ |\\\n\\\nmatch_options:\\ match_option\\ \\(|\\ fuzzy_option\\)\\*\\\n\\\nfuzzy_option:\\ |\\ agg_param\\)\\*\\ |\\ STRING\\ \\(|\\ value\\\n\\\n//\\ Values\\\nvalue:\\ STRING\\ \\|\\ NUMBER\\ \\|\\ BOOLEAN_LITERAL\\ \\|\\ NULL\\\n\\\nBOOLEAN_LITERAL:\\ |\\ agg_definition\\ \\(|must_not\\\\|multi_match\\\\|\\ field_value\\ |\\\n\\\nmulti_match_params:\\ |histogram\\\\|\\{|fuzzy\\\\|\\ value\\\n\\\nrange_op:\\ |\\ NUMBER\\\n\\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\|\\ |\\ value\\ \\(|\\ bool_clauses\\ |\\ query_array\\\n\\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\|\\ |\\ STRING\\\n\\\n//\\ Fuzzy\\ query\\\nfuzzy_query:\\ |cardinality\\\\|\\ STRING\\\n\\\n//\\ Term\\ queries\\\nterm_query:\\ |default_field\\\\|\\)\\\n\\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\|\\ |field\\\\|avg\\\\|\\\n\\\n//\\ Exists\\ query\\\nexists_query:\\ |\\\n\\ \\ \\ \\ \\ \\ \\ \\ \\|\\ |query_string\\\\|wildcard\\\\|\\ query_string_option\\)\\*\\\n\\\nquery_string_option:\\ |fuzziness\\\\|bool\\\\|analyzer\\\\|\\ STRING\\\n\\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\|\\ |\\\n\\\nNULL:\\ |must\\\\|\\ NUMBER\\\n\\\n//\\ Prefix\\ query\\\nprefix_query:\\ |\\\n\\\nagg_definition:\\ STRING\\ |\\)\\\n\\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\|\\ |gte\\\\|\\\n\\\nfield_match:\\ STRING\\ |\\\n\\\n//\\ Range\\ query\\\nrange_query:\\ |operator\\\\|\\ agg_param\\ \\(|\\\n\\\nrange_condition:\\ range_op\\ |lte\\\\|\\]\\*|term\\\\|\\ query_string_options\\]\\ |\\ range_condition\\ \\(|min\\\\|\\ query\\)\\*\\ |match\\\\|\\ range_condition\\)\\*\\ |\\ STRING\\ |\\ NUMBER\\\n\\\nquery_array:\\ |\\\n\\\nagg_param:\\ STRING\\ |exists\\\\|range\\\\|query\\\\|\\\n\\\nagg_params:\\ |\\ multi_match_params\\ |\\ value\\)\\*\\ |default_operator\\\\|\\ match_options\\]\\\n\\\n//\\ Query\\ string\\\nquery_string_query:\\ |\\ bool_clause\\)\\*\\\n\\\nbool_clause:\\ |\\\n\\\nquery_string_options:\\ query_string_option\\ \\(|path\\\\|\\ STRING\\)\\*\\ |\\ match_option\\)\\*\\\n\\\nmatch_option:\\ |\\\n\\\n//\\ Wildcard\\ query\\\nwildcard_query:\\ |\\ agg_definition\\)\\*\\ |gt\\\\|\\ query\\ |\\ agg_params\\ |\\\\|max\\\\|AND\\\\|\\ fuzzy_options\\]\\ |date_histogram\\\\|\\ value\\\n\\\nterms_query:\\ |value\\\\|\\\n\\\nfield_value:\\ STRING\\ ",
  "brackets": [
    {
      "open": "{",
      "close": "}",
      "token": "delimiter.curly"
    }
  ],
  "tokenizer": {
    "root": [
      {
        "include": "@whitespace"
      },
      [
        "/\\d+(\\.\\d+)?([eE][+-]?\\d+)?/",
        "number"
      ],
      [
        "/\"([^\"\\\\]|\\\\.)*\"/",
        "string"
      ],
      [
        "/'([^'\\\\]|\\\\.)*'/",
        "string"
      ],
      [
        "/[a-zA-Z_][\\w]*/",
        {
          "cases": {
            "@keywords": "keyword",
            "@default": "identifier"
          }
        }
      ],
      [
        "/\\ value\\\n\\\n//\\ Values\\\nvalue:\\ STRING\\ \\|\\ NUMBER\\ \\|\\ BOOLEAN_LITERAL\\ \\|\\ NULL\\\n\\\nBOOLEAN_LITERAL:\\ /",
        "operator"
      ],
      [
        "/\\\n\\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\|\\ query\\\n\\\n//\\ Multi\\-match\\ query\\\nmulti_match_query:\\ /",
        "operator"
      ],
      [
        "/\\\n\\\n//\\ Terminals\\\nIDENTIFIER:\\ /\\[a\\-zA\\-Z_\\]\\[a\\-zA\\-Z0\\-9_\\]\\*/\\\nSTRING:\\ //",
        "operator"
      ],
      [
        "/\\ match_options\\]\\\n\\\n//\\ Query\\ string\\\nquery_string_query:\\ /",
        "operator"
      ],
      [
        "/\\ query_string_option\\)\\*\\\n\\\nquery_string_option:\\ /",
        "operator"
      ],
      [
        "/\\\n\\\nquery_string_options:\\ query_string_option\\ \\(/",
        "operator"
      ],
      [
        "/\\ \\(STRING\\ \\|\\ match_params\\)\\\n\\\nmatch_params:\\ /",
        "operator"
      ],
      [
        "/\\ NUMBER\\\n\\\n//\\ Prefix\\ query\\\nprefix_query:\\ /",
        "operator"
      ],
      [
        "/\\ STRING\\\n\\\n//\\ Fuzzy\\ query\\\nfuzzy_query:\\ /",
        "operator"
      ],
      [
        "/\\ STRING\\\n\\\n//\\ Term\\ queries\\\nterm_query:\\ /",
        "operator"
      ],
      [
        "/\\\n\\\n//\\ Aggregation\\\naggregation_query:\\ /",
        "operator"
      ],
      [
        "/\\\n\\\n//\\ Wildcard\\ query\\\nwildcard_query:\\ /",
        "operator"
      ],
      [
        "/\\ \\(STRING\\ \\|\\ NUMBER\\)\\\n\\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\|\\ /",
        "operator"
      ],
      [
        "/\\\n\\\n//\\ Nested\\ query\\\nnested_query:\\ /",
        "operator"
      ],
      [
        "/\\\n\\\n//\\ Exists\\ query\\\nexists_query:\\ /",
        "operator"
      ],
      [
        "/\\\n\\\nfuzzy_options:\\ fuzzy_option\\ \\(/",
        "operator"
      ],
      [
        "/\\\n\\\nmatch_options:\\ match_option\\ \\(/",
        "operator"
      ],
      [
        "/\\ fuzzy_option\\)\\*\\\n\\\nfuzzy_option:\\ /",
        "operator"
      ],
      [
        "/\\ match_option\\)\\*\\\n\\\nmatch_option:\\ /",
        "operator"
      ],
      [
        "/\\\n\\\n//\\ Range\\ query\\\nrange_query:\\ /",
        "operator"
      ],
      [
        "/\\\n\\\nbool_clauses:\\ bool_clause\\ \\(/",
        "operator"
      ],
      [
        "/\\ STRING\\\n\\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\|\\ /",
        "operator"
      ],
      [
        "/\\ bool_clause\\)\\*\\\n\\\nbool_clause:\\ /",
        "operator"
      ],
      [
        "/\\\n\\\n//\\ Bool\\ query\\\nbool_query:\\ /",
        "operator"
      ],
      [
        "/\\\n\\\nrange_condition:\\ range_op\\ /",
        "operator"
      ],
      [
        "/\\ query_array\\\n\\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\|\\ /",
        "operator"
      ],
      [
        "/\\\n\\\nagg_definition:\\ STRING\\ /",
        "operator"
      ],
      [
        "/\\)\\\n\\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\|\\ /",
        "operator"
      ],
      [
        "/\\ query_string_options\\]\\ /",
        "operator"
      ],
      [
        "/\\\n\\\nmulti_match_params:\\ /",
        "operator"
      ],
      [
        "/\\ NUMBER\\\n\\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\|\\ /",
        "operator"
      ],
      [
        "/\\\n\\\nfield_match:\\ STRING\\ /",
        "operator"
      ],
      [
        "/\\ NUMBER\\\n\\\nquery_array:\\ /",
        "operator"
      ],
      [
        "/\\\n\\\nfield_value:\\ STRING\\ /",
        "operator"
      ],
      [
        "/minimum_should_match\\\\/",
        "operator"
      ],
      [
        "/\\ value\\\n\\\nterms_query:\\ /",
        "operator"
      ],
      [
        "/\\\n\\\nagg_param:\\ STRING\\ /",
        "operator"
      ],
      [
        "/\\ multi_match_params\\ /",
        "operator"
      ],
      [
        "/\\ range_condition\\)\\*\\ /",
        "operator"
      ],
      [
        "/\\ value\\\n\\\nrange_op:\\ /",
        "operator"
      ],
      [
        "/\\ range_condition\\ \\(/",
        "operator"
      ],
      [
        "/\\ agg_definition\\)\\*\\ /",
        "operator"
      ],
      [
        "/\\ agg_definition\\ \\(/",
        "operator"
      ],
      [
        "/default_operator\\\\/",
        "operator"
      ],
      [
        "/\\ match_options\\]\\ /",
        "operator"
      ],
      [
        "/\\)\\\n\\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\|\\ /",
        "operator"
      ],
      [
        "/\\ fuzzy_options\\]\\ /",
        "operator"
      ],
      [
        "/\\\n\\\nmatch_query:\\ /",
        "operator"
      ],
      [
        "/date_histogram\\\\/",
        "operator"
      ],
      [
        "/prefix_length\\\\/",
        "operator"
      ],
      [
        "/\\ bool_clauses\\ /",
        "operator"
      ],
      [
        "/default_field\\\\/",
        "operator"
      ],
      [
        "/\\\n\\\nagg_params:\\ /",
        "operator"
      ],
      [
        "/\\ field_match\\ /",
        "operator"
      ],
      [
        "/\\ agg_param\\)\\*\\ /",
        "operator"
      ],
      [
        "/\\ field_value\\ /",
        "operator"
      ],
      [
        "/query_string\\\\/",
        "operator"
      ],
      [
        "/\\\n\\\nagg_type:\\ /",
        "operator"
      ],
      [
        "/multi_match\\\\/",
        "operator"
      ],
      [
        "/cardinality\\\\/",
        "operator"
      ],
      [
        "/\\ agg_param\\ \\(/",
        "operator"
      ],
      [
        "/\\ agg_params\\ /",
        "operator"
      ],
      [
        "/\\\n\\ \\ \\ \\ \\ \\ \\ \\ \\|\\ /",
        "operator"
      ],
      [
        "/\\ agg_type\\ /",
        "operator"
      ],
      [
        "/histogram\\\\/",
        "operator"
      ],
      [
        "/fuzziness\\\\/",
        "operator"
      ],
      [
        "/\\ STRING\\)\\*\\ /",
        "operator"
      ],
      [
        "/\\ STRING\\ \\[/",
        "operator"
      ],
      [
        "/\\ STRING\\ \\(/",
        "operator"
      ],
      [
        "/must_not\\\\/",
        "operator"
      ],
      [
        "/wildcard\\\\/",
        "operator"
      ],
      [
        "/analyzer\\\\/",
        "operator"
      ],
      [
        "/operator\\\\/",
        "operator"
      ],
      [
        "/\\ query\\)\\*\\ /",
        "operator"
      ],
      [
        "/\\ value\\)\\*\\ /",
        "operator"
      ],
      [
        "/\\ query\\ \\(/",
        "operator"
      ],
      [
        "/\\ value\\ \\(/",
        "operator"
      ],
      [
        "/\\\n\\\nNULL:\\ /",
        "operator"
      ],
      [
        "/\\ STRING\\ /",
        "operator"
      ],
      [
        "/prefix\\\\/",
        "operator"
      ],
      [
        "/filter\\\\/",
        "operator"
      ],
      [
        "/fields\\\\/",
        "operator"
      ],
      [
        "/should\\\\/",
        "operator"
      ],
      [
        "/nested\\\\/",
        "operator"
      ],
      [
        "/exists\\\\/",
        "operator"
      ],
      [
        "/\\ query\\ /",
        "operator"
      ],
      [
        "/stats\\\\/",
        "operator"
      ],
      [
        "/terms\\\\/",
        "operator"
      ],
      [
        "/fuzzy\\\\/",
        "operator"
      ],
      [
        "/field\\\\/",
        "operator"
      ],
      [
        "/match\\\\/",
        "operator"
      ],
      [
        "/range\\\\/",
        "operator"
      ],
      [
        "/query\\\\/",
        "operator"
      ],
      [
        "/value\\\\/",
        "operator"
      ],
      [
        "/aggs\\\\/",
        "operator"
      ],
      [
        "/bool\\\\/",
        "operator"
      ],
      [
        "/must\\\\/",
        "operator"
      ],
      [
        "/term\\\\/",
        "operator"
      ],
      [
        "/path\\\\/",
        "operator"
      ],
      [
        "/sum\\\\/",
        "operator"
      ],
      [
        "/and\\\\/",
        "operator"
      ],
      [
        "/avg\\\\/",
        "operator"
      ],
      [
        "/gte\\\\/",
        "operator"
      ],
      [
        "/lte\\\\/",
        "operator"
      ],
      [
        "/min\\\\/",
        "operator"
      ],
      [
        "/max\\\\/",
        "operator"
      ],
      [
        "/AND\\\\/",
        "operator"
      ],
      [
        "/\\ \\|\\ /",
        "operator"
      ],
      [
        "/OR\\\\/",
        "operator"
      ],
      [
        "/lt\\\\/",
        "operator"
      ],
      [
        "/or\\\\/",
        "operator"
      ],
      [
        "/gt\\\\/",
        "operator"
      ],
      [
        "/\\ \\(/",
        "operator"
      ],
      [
        "/\\ \\[/",
        "operator"
      ],
      [
        "/\\]\\*/",
        "operator"
      ],
      [
        "/\\{/",
        "operator"
      ],
      [
        "/\\\\/",
        "operator"
      ],
      [
        "/[()[\\]{}]/",
        "@brackets"
      ],
      [
        "/[;,.]/",
        "delimiter"
      ]
    ],
    "whitespace": [
      [
        "/[ \\t\\r\\n]+/",
        ""
      ],
      [
        "/--.*$/",
        "comment"
      ],
      [
        "/\\/\\/.*$/",
        "comment"
      ],
      [
        "/\\/\\*/",
        "comment",
        "@comment"
      ]
    ],
    "comment": [
      [
        "/[^/*]+/",
        "comment"
      ],
      [
        "/\\*\\//",
        "comment",
        "@pop"
      ],
      [
        "/[/*]/",
        "comment"
      ]
    ]
  }
};
export const elasticsearchLanguageConfig = {
  "brackets": [
    [
      "{",
      "}"
    ]
  ],
  "autoClosingPairs": [
    {
      "open": "{",
      "close": "}"
    }
  ],
  "surroundingPairs": [
    {
      "open": "{",
      "close": "}"
    }
  ]
};
// Register with Monaco Editor
export function registerElasticsearchLanguage(monaco: any) {
  monaco.languages.register({ id: 'elasticsearch' });
  monaco.languages.setMonarchTokensProvider('elasticsearch', elasticsearchLanguage);
  monaco.languages.setLanguageConfiguration('elasticsearch', elasticsearchLanguageConfig);
}
