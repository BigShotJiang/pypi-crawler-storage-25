#exonware/xwsyntax/tests/1.unit/optimizations_tests/conftest.py
"""
Optimization test fixtures.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
@pytest.fixture

def small_ast():
    """Create small AST for testing."""
    from exonware.xwsyntax import BidirectionalGrammar
    grammar = BidirectionalGrammar.load('json')
    return grammar.parse('{"small": "ast"}')
@pytest.fixture

def medium_ast():
    """Create medium AST (100-1000 nodes)."""
    from exonware.xwsyntax import BidirectionalGrammar
    grammar = BidirectionalGrammar.load('json')
    items = ','.join([f'{{"id": {i}}}' for i in range(120)])
    return grammar.parse(f'{{"items": [{items}]}}')
@pytest.fixture

def large_ast():
    """Create large AST (>1000 nodes)."""
    from exonware.xwsyntax import BidirectionalGrammar
    grammar = BidirectionalGrammar.load('json')
    items = ','.join([f'{{"id": {i}, "data": "value_{i}"}}' for i in range(600)])
    return grammar.parse(f'{{"items": [{items}]}}')
