// sql.monarch.ts
// Auto-generated Monaco language definition
export const sqlLanguage = {
  "defaultToken": "",
  "tokenPostfix": ".sql",
  "ignoreCase": true,
  "keywords": [
    "ALL",
    "BLOB",
    "BOOL",
    "BOOLEAN",
    "CHAR",
    "CROSS",
    "DATE",
    "DATETIME",
    "DECIMAL",
    "DISTINCT",
    "DOUBLE",
    "FLOAT",
    "FULL",
    "INNER",
    "INT",
    "INTEGER",
    "LEFT",
    "NUMERIC",
    "RIGHT",
    "TEXT",
    "TIME",
    "TIMESTAMP",
    "TOP",
    "VARCHAR"
  ],
  "operators": [
    "!=",
    "%",
    "(",
    ")",
    "*",
    "+",
    ",",
    "-",
    ".",
    "/",
    "/\n\n// Keywords (case-insensitive)\nSELECT: ",
    "<",
    "<=",
    "<>",
    "=",
    ">",
    ">=",
    "[^",
    "]+",
    "i\n\n// Terminals\nQUOTED_IDENTIFIER: /`[^`]+`/ | /\\[[^\\]]+\\]/ | /",
    "i\nADD: ",
    "i\nALTER: ",
    "i\nAND: ",
    "i\nAS: ",
    "i\nASC: ",
    "i\nBETWEEN: ",
    "i\nBOOLEAN: ",
    "i\nBY: ",
    "i\nCHECK: ",
    "i\nCOLUMN: ",
    "i\nCREATE: ",
    "i\nDATABASE: ",
    "i\nDELETE: ",
    "i\nDESC: ",
    "i\nDROP: ",
    "i\nFOREIGN_KEY: ",
    "i\nFROM: ",
    "i\nGROUP: ",
    "i\nHAVING: ",
    "i\nIN: ",
    "i\nINDEX: ",
    "i\nINSERT: ",
    "i\nINTO: ",
    "i\nIS: ",
    "i\nJOIN: ",
    "i\nLIKE: ",
    "i\nLIMIT: ",
    "i\nMODIFY: ",
    "i\nNOT: ",
    "i\nNOT_NULL: ",
    "i\nNULL: ",
    "i\nOFFSET: ",
    "i\nON: ",
    "i\nOR: ",
    "i\nORDER: ",
    "i\nPRIMARY_KEY: ",
    "i\nSET: ",
    "i\nTABLE: ",
    "i\nUNIQUE: ",
    "i\nUPDATE: ",
    "i\nVALUES: ",
    "i\nVIEW: ",
    "i\nWHERE: ",
    "i ",
    "i | "
  ],
  "symbols": "<=|i\\\nVALUES:\\ |/\\\n\\\n//\\ Keywords\\ \\(case\\-insensitive\\)\\\nSELECT:\\ |i\\\nON:\\ |i\\\nUPDATE:\\ |i\\\nINTO:\\ |<|i\\\nDROP:\\ |i\\\nWHERE:\\ |\\.|,|i\\\nCHECK:\\ |i\\\nORDER:\\ |i\\\nNOT_NULL:\\ |i\\\nPRIMARY_KEY:\\ |<>|i\\ |!=|\\*|\\-|i\\ \\|\\ |i\\\nDATABASE:\\ |i\\\nCOLUMN:\\ |i\\\nAS:\\ |>|i\\\nLIMIT:\\ |i\\\nLIKE:\\ |i\\\nCREATE:\\ |i\\\nJOIN:\\ |i\\\nFOREIGN_KEY:\\ |/|i\\\nFROM:\\ |\\+|i\\\nTABLE:\\ |\\(|=|i\\\nINDEX:\\ |i\\\nDESC:\\ |i\\\nBETWEEN:\\ |\\)|i\\\nVIEW:\\ |i\\\nBY:\\ |i\\\nINSERT:\\ |i\\\nUNIQUE:\\ |i\\\n\\\n//\\ Terminals\\\nQUOTED_IDENTIFIER:\\ /`\\[\\^`\\]\\+`/\\ \\|\\ /\\\\\\[\\[\\^\\\\\\]\\]\\+\\\\\\]/\\ \\|\\ /|i\\\nMODIFY:\\ |i\\\nBOOLEAN:\\ |>=|\\[\\^|i\\\nOFFSET:\\ |i\\\nADD:\\ |\\]\\+|i\\\nIS:\\ |%|i\\\nAND:\\ |i\\\nGROUP:\\ |i\\\nIN:\\ |i\\\nHAVING:\\ |i\\\nNULL:\\ |i\\\nASC:\\ |i\\\nDELETE:\\ |i\\\nNOT:\\ |i\\\nALTER:\\ |i\\\nOR:\\ |i\\\nSET:\\ ",
  "brackets": [
    {
      "open": "(",
      "close": ")",
      "token": "delimiter.parenthesis"
    }
  ],
  "tokenizer": {
    "root": [
      {
        "include": "@whitespace"
      },
      [
        "/\\d+(\\.\\d+)?([eE][+-]?\\d+)?/",
        "number"
      ],
      [
        "/\"([^\"\\\\]|\\\\.)*\"/",
        "string"
      ],
      [
        "/'([^'\\\\]|\\\\.)*'/",
        "string"
      ],
      [
        "/[a-zA-Z_][\\w]*/",
        {
          "cases": {
            "@keywords": "keyword",
            "@default": "identifier"
          }
        }
      ],
      [
        "/i\\\n\\\n//\\ Terminals\\\nQUOTED_IDENTIFIER:\\ /`\\[\\^`\\]\\+`/\\ \\|\\ /\\\\\\[\\[\\^\\\\\\]\\]\\+\\\\\\]/\\ \\|\\ //",
        "operator"
      ],
      [
        "//\\\n\\\n//\\ Keywords\\ \\(case\\-insensitive\\)\\\nSELECT:\\ /",
        "operator"
      ],
      [
        "/i\\\nPRIMARY_KEY:\\ /",
        "operator"
      ],
      [
        "/i\\\nFOREIGN_KEY:\\ /",
        "operator"
      ],
      [
        "/i\\\nNOT_NULL:\\ /",
        "operator"
      ],
      [
        "/i\\\nDATABASE:\\ /",
        "operator"
      ],
      [
        "/i\\\nBETWEEN:\\ /",
        "operator"
      ],
      [
        "/i\\\nBOOLEAN:\\ /",
        "operator"
      ],
      [
        "/i\\\nVALUES:\\ /",
        "operator"
      ],
      [
        "/i\\\nUPDATE:\\ /",
        "operator"
      ],
      [
        "/i\\\nCOLUMN:\\ /",
        "operator"
      ],
      [
        "/i\\\nCREATE:\\ /",
        "operator"
      ],
      [
        "/i\\\nINSERT:\\ /",
        "operator"
      ],
      [
        "/i\\\nUNIQUE:\\ /",
        "operator"
      ],
      [
        "/i\\\nMODIFY:\\ /",
        "operator"
      ],
      [
        "/i\\\nOFFSET:\\ /",
        "operator"
      ],
      [
        "/i\\\nHAVING:\\ /",
        "operator"
      ],
      [
        "/i\\\nDELETE:\\ /",
        "operator"
      ],
      [
        "/i\\\nWHERE:\\ /",
        "operator"
      ],
      [
        "/i\\\nCHECK:\\ /",
        "operator"
      ],
      [
        "/i\\\nORDER:\\ /",
        "operator"
      ],
      [
        "/i\\\nLIMIT:\\ /",
        "operator"
      ],
      [
        "/i\\\nTABLE:\\ /",
        "operator"
      ],
      [
        "/i\\\nINDEX:\\ /",
        "operator"
      ],
      [
        "/i\\\nGROUP:\\ /",
        "operator"
      ],
      [
        "/i\\\nALTER:\\ /",
        "operator"
      ],
      [
        "/i\\\nINTO:\\ /",
        "operator"
      ],
      [
        "/i\\\nDROP:\\ /",
        "operator"
      ],
      [
        "/i\\\nLIKE:\\ /",
        "operator"
      ],
      [
        "/i\\\nJOIN:\\ /",
        "operator"
      ],
      [
        "/i\\\nFROM:\\ /",
        "operator"
      ],
      [
        "/i\\\nDESC:\\ /",
        "operator"
      ],
      [
        "/i\\\nVIEW:\\ /",
        "operator"
      ],
      [
        "/i\\\nNULL:\\ /",
        "operator"
      ],
      [
        "/i\\\nADD:\\ /",
        "operator"
      ],
      [
        "/i\\\nAND:\\ /",
        "operator"
      ],
      [
        "/i\\\nASC:\\ /",
        "operator"
      ],
      [
        "/i\\\nNOT:\\ /",
        "operator"
      ],
      [
        "/i\\\nSET:\\ /",
        "operator"
      ],
      [
        "/i\\\nON:\\ /",
        "operator"
      ],
      [
        "/i\\\nAS:\\ /",
        "operator"
      ],
      [
        "/i\\\nBY:\\ /",
        "operator"
      ],
      [
        "/i\\\nIS:\\ /",
        "operator"
      ],
      [
        "/i\\\nIN:\\ /",
        "operator"
      ],
      [
        "/i\\\nOR:\\ /",
        "operator"
      ],
      [
        "/i\\ \\|\\ /",
        "operator"
      ],
      [
        "/<=/",
        "operator"
      ],
      [
        "/<>/",
        "operator"
      ],
      [
        "/i\\ /",
        "operator"
      ],
      [
        "/!=/",
        "operator"
      ],
      [
        "/>=/",
        "operator"
      ],
      [
        "/\\[\\^/",
        "operator"
      ],
      [
        "/\\]\\+/",
        "operator"
      ],
      [
        "/</",
        "operator"
      ],
      [
        "/\\./",
        "operator"
      ],
      [
        "/,/",
        "operator"
      ],
      [
        "/\\*/",
        "operator"
      ],
      [
        "/\\-/",
        "operator"
      ],
      [
        "/>/",
        "operator"
      ],
      [
        "///",
        "operator"
      ],
      [
        "/\\+/",
        "operator"
      ],
      [
        "/\\(/",
        "operator"
      ],
      [
        "/=/",
        "operator"
      ],
      [
        "/\\)/",
        "operator"
      ],
      [
        "/%/",
        "operator"
      ],
      [
        "/[()[\\]{}]/",
        "@brackets"
      ],
      [
        "/[;,.]/",
        "delimiter"
      ]
    ],
    "whitespace": [
      [
        "/[ \\t\\r\\n]+/",
        ""
      ],
      [
        "/--.*$/",
        "comment"
      ],
      [
        "/\\/\\/.*$/",
        "comment"
      ],
      [
        "/\\/\\*/",
        "comment",
        "@comment"
      ]
    ],
    "comment": [
      [
        "/[^/*]+/",
        "comment"
      ],
      [
        "/\\*\\//",
        "comment",
        "@pop"
      ],
      [
        "/[/*]/",
        "comment"
      ]
    ]
  }
};
export const sqlLanguageConfig = {
  "brackets": [
    [
      "(",
      ")"
    ]
  ],
  "autoClosingPairs": [
    {
      "open": "(",
      "close": ")"
    },
    {
      "open": "'",
      "close": "'"
    }
  ],
  "surroundingPairs": [
    {
      "open": "(",
      "close": ")"
    },
    {
      "open": "'",
      "close": "'"
    }
  ]
};
// Register with Monaco Editor
export function registerSqlLanguage(monaco: any) {
  monaco.languages.register({ id: 'sql' });
  monaco.languages.setMonarchTokensProvider('sql', sqlLanguage);
  monaco.languages.setLanguageConfiguration('sql', sqlLanguageConfig);
}
