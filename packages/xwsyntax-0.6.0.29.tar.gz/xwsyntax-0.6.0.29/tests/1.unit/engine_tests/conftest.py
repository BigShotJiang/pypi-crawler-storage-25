#exonware/xwsyntax/tests/1.unit/engine_tests/conftest.py
"""
Engine test fixtures.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
@pytest.fixture

def syntax_engine():
    """Create XWSyntax instance."""
    from exonware.xwsyntax import XWSyntax
    return XWSyntax()
