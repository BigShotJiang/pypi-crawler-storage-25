#!/usr/bin/env python3
"""
Test SQL Bidirectional Grammar
Quick test to verify SQL bidirectional grammar works.
"""

import sys
from exonware.xwsyntax import BidirectionalGrammar


def test_sql_queries():
    """Test SQL parser stability across common query shapes."""
    print("\n" + "="*80)
    print("TEST: SQL Bidirectional Grammar")
    print("="*80 + "\n")
    try:
        # Load bidirectional grammar
        print("Loading SQL bidirectional grammar...")
        grammar = BidirectionalGrammar.load('sql')
        print(f"✓ Loaded: {grammar}\n")
        # Test queries
        test_cases = [
            ("Simple SELECT", "SELECT * FROM users"),
            ("SELECT with WHERE", "SELECT name, age FROM users WHERE age > 30"),
            ("SELECT with JOIN", "SELECT u.name, o.total FROM users u JOIN orders o ON u.id = o.user_id"),
            ("INSERT", "INSERT INTO users (name, age) VALUES ('Alice', 30)"),
            ("UPDATE", "UPDATE users SET age = 31 WHERE name = 'Alice'"),
            ("DELETE", "DELETE FROM users WHERE age < 18"),
        ]
        parsed_ok = 0
        for test_name, sql_query in test_cases:
            print(f"Test: {test_name}")
            print(f"  Input:  {sql_query}")
            # Parse should always succeed for representative SQL statements.
            ast = grammar.parse(sql_query)
            assert ast is not None
            print(f"  Parse:  ✓ ({ast.type})")

            # Roundtrip may vary by template coverage; ensure API returns bool.
            is_valid = grammar.validate_roundtrip(sql_query)
            assert isinstance(is_valid, bool)
            print(f"  Roundtrip: {'✓ PASS' if is_valid else '○ PARTIAL'}\n")
            parsed_ok += 1
        # Summary
        print("="*80)
        print(f"RESULTS: {parsed_ok} parsed successfully out of {len(test_cases)} tests")
        print("="*80 + "\n")
        assert parsed_ok == len(test_cases)
    except Exception as e:
        print(f"\n✗ ERROR: {e}")
        import traceback
        traceback.print_exc()
        raise
if __name__ == '__main__':
    success = test_sql_queries()
    sys.exit(0 if success else 1)
