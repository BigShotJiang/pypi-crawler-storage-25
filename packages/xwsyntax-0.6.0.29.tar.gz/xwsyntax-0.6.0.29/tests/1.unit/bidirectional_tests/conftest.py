#exonware/xwsyntax/tests/1.unit/bidirectional_tests/conftest.py
"""
Bidirectional test fixtures.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

import pytest
@pytest.fixture

def json_grammar():
    """Load JSON bidirectional grammar."""
    from exonware.xwsyntax import BidirectionalGrammar
    return BidirectionalGrammar.load('json')
