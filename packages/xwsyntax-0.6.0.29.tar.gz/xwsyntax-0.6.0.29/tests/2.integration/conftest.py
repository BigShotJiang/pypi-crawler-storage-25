#exonware/xwsyntax/tests/2.integration/conftest.py
"""
Integration test fixtures.
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
"""

