# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from gmt import Gmt, AsyncGmt
from gmt.types import (
    TelegramGetStarsPriceResponse,
    TelegramGetPremiumPriceResponse,
)
from tests.utils import assert_matches_type

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestTelegram:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_get_premium_price(self, client: Gmt) -> None:
        telegram = client.telegram.get_premium_price(
            mounts="mounts",
        )
        assert_matches_type(TelegramGetPremiumPriceResponse, telegram, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_get_premium_price(self, client: Gmt) -> None:
        response = client.telegram.with_raw_response.get_premium_price(
            mounts="mounts",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        telegram = response.parse()
        assert_matches_type(TelegramGetPremiumPriceResponse, telegram, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_get_premium_price(self, client: Gmt) -> None:
        with client.telegram.with_streaming_response.get_premium_price(
            mounts="mounts",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            telegram = response.parse()
            assert_matches_type(TelegramGetPremiumPriceResponse, telegram, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_get_stars_price(self, client: Gmt) -> None:
        telegram = client.telegram.get_stars_price(
            amount="amount",
        )
        assert_matches_type(TelegramGetStarsPriceResponse, telegram, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_get_stars_price(self, client: Gmt) -> None:
        response = client.telegram.with_raw_response.get_stars_price(
            amount="amount",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        telegram = response.parse()
        assert_matches_type(TelegramGetStarsPriceResponse, telegram, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_get_stars_price(self, client: Gmt) -> None:
        with client.telegram.with_streaming_response.get_stars_price(
            amount="amount",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            telegram = response.parse()
            assert_matches_type(TelegramGetStarsPriceResponse, telegram, path=["response"])

        assert cast(Any, response.is_closed) is True


class TestAsyncTelegram:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_get_premium_price(self, async_client: AsyncGmt) -> None:
        telegram = await async_client.telegram.get_premium_price(
            mounts="mounts",
        )
        assert_matches_type(TelegramGetPremiumPriceResponse, telegram, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_get_premium_price(self, async_client: AsyncGmt) -> None:
        response = await async_client.telegram.with_raw_response.get_premium_price(
            mounts="mounts",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        telegram = await response.parse()
        assert_matches_type(TelegramGetPremiumPriceResponse, telegram, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_get_premium_price(self, async_client: AsyncGmt) -> None:
        async with async_client.telegram.with_streaming_response.get_premium_price(
            mounts="mounts",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            telegram = await response.parse()
            assert_matches_type(TelegramGetPremiumPriceResponse, telegram, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_get_stars_price(self, async_client: AsyncGmt) -> None:
        telegram = await async_client.telegram.get_stars_price(
            amount="amount",
        )
        assert_matches_type(TelegramGetStarsPriceResponse, telegram, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_get_stars_price(self, async_client: AsyncGmt) -> None:
        response = await async_client.telegram.with_raw_response.get_stars_price(
            amount="amount",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        telegram = await response.parse()
        assert_matches_type(TelegramGetStarsPriceResponse, telegram, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_get_stars_price(self, async_client: AsyncGmt) -> None:
        async with async_client.telegram.with_streaming_response.get_stars_price(
            amount="amount",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            telegram = await response.parse()
            assert_matches_type(TelegramGetStarsPriceResponse, telegram, path=["response"])

        assert cast(Any, response.is_closed) is True
