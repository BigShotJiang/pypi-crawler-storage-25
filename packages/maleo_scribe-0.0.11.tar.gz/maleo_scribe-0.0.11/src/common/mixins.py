from pydantic import BaseModel, Field
from typing import Annotated, Generic
from nexo.types.float import OptFloat
from nexo.types.integer import OptInt
from nexo.types.string import OptStr, OptStrT


class Notes(BaseModel, Generic[OptStrT]):
    notes: Annotated[OptStrT, Field(..., description="Notes")]


# ----- SOAP ----- #
class Overall(BaseModel, Generic[OptStrT]):
    overall: Annotated[OptStrT, Field(..., description="Overall")]


class OptOtherInformation(BaseModel):
    other_information: Annotated[
        OptStr, Field(None, description="Other information")
    ] = None


# ----- Subjective ----- #
class ChiefComplaint(BaseModel, Generic[OptStrT]):
    chief_complaint: Annotated[
        OptStrT, Field(..., description="Patient's chief complaint")
    ]


class OptAdditionalComplaint(BaseModel):
    additional_complaint: Annotated[
        OptStr, Field(None, description="Patient's additional complaint")
    ] = None


class CombinedComplaint(BaseModel, Generic[OptStrT]):
    combined_complaint: Annotated[
        OptStrT, Field(..., description="Patient's combined complaint")
    ]


class OptPainScale(BaseModel):
    pain_scale: Annotated[
        OptInt, Field(None, description="Patient's pain scale", ge=1, le=10)
    ] = None


class OptOnset(BaseModel):
    onset: Annotated[OptStr, Field(None, description="Patient's onset")] = None


class OptChronology(BaseModel):
    chronology: Annotated[OptStr, Field(None, description="Patient's chronology")] = (
        None
    )


class OptLocation(BaseModel):
    location: Annotated[OptStr, Field(None, description="Patient's location")] = None


class OptFactors(BaseModel):
    factors: Annotated[OptStr, Field(None, description="Patient's factors")] = None


class OptAggravatingFactor(BaseModel):
    aggravating_factor: Annotated[
        OptStr, Field(None, description="Patient's aggravating factor")
    ] = None


class OptAggravatingFactors(BaseModel):
    aggravating_factors: Annotated[
        OptStr, Field(None, description="Patient's aggravating factors")
    ] = None


class OptRelievingFactor(BaseModel):
    relieving_factor: Annotated[
        OptStr, Field(None, description="Patient's relieving factor")
    ] = None


class OptRelievingFactors(BaseModel):
    relieving_factors: Annotated[
        OptStr, Field(None, description="Patient's relieving factors")
    ] = None


class OptPersonalMedicalHistory(BaseModel):
    personal_medical_history: Annotated[
        OptStr, Field(None, description="Patient's personal medical history")
    ] = None


class OptFamilyMedicalHistory(BaseModel):
    family_medical_history: Annotated[
        OptStr, Field(None, description="Patient's family medical history")
    ] = None


class OptPastIllnessHistory(BaseModel):
    past_illness_history: Annotated[
        OptStr, Field(None, description="Patient's past illness history")
    ] = None


class OptFamilyIllnessHistory(BaseModel):
    family_illness_history: Annotated[
        OptStr, Field(None, description="Patient's family illness history")
    ] = None


class OptHabitActivityOccupation(BaseModel):
    habit_activity_occupation: Annotated[
        OptStr, Field(None, description="Patient's habit activity occupation")
    ] = None


class OptConsumedMedication(BaseModel):
    consumed_medication: Annotated[
        OptStr, Field(None, description="Patient's consumed medication")
    ] = None


# ----- Vital Sign ----- #
class OptSystole(BaseModel):
    systole: Annotated[OptInt, Field(None, description="Patient's systole", ge=1)] = (
        None
    )


class OptSystolicBloodPressure(BaseModel):
    systolic_blood_pressure: Annotated[
        OptInt, Field(None, description="Patient's systolic blood pressure", ge=1)
    ] = None


class OptDiastole(BaseModel):
    diastole: Annotated[OptInt, Field(None, description="Patient's diastole", ge=1)] = (
        None
    )


class OptDiastolicBloodPressure(BaseModel):
    diastolic_blood_pressure: Annotated[
        OptInt, Field(None, description="Patient's diastolic blood pressure", ge=1)
    ] = None


class OptTemperature(BaseModel):
    temperature: Annotated[
        OptFloat, Field(None, description="Patient's temperature", ge=1)
    ] = None


class OptRespirationRate(BaseModel):
    respiration_rate: Annotated[
        OptInt, Field(None, description="Patient's respiration rate", ge=1)
    ] = None


class OptHeartRate(BaseModel):
    heart_rate: Annotated[
        OptInt, Field(None, description="Patient's heart rate", ge=1)
    ] = None


class OptOxygenSaturation(BaseModel):
    oxygen_saturation: Annotated[
        OptInt, Field(None, description="Patient's oxygen saturation", le=100)
    ] = None


class OptAbdominalCircumference(BaseModel):
    abdominal_circumference: Annotated[
        OptFloat, Field(None, description="Patient's abdominal circumference")
    ] = None


class OptWaistCircumference(BaseModel):
    waist_circumference: Annotated[
        OptFloat, Field(None, description="Patient's waist circumference")
    ] = None


class OptWeight(BaseModel):
    weight: Annotated[OptFloat, Field(None, description="Patient's weight", ge=0.0)] = (
        None
    )


class OptHeight(BaseModel):
    height: Annotated[OptFloat, Field(None, description="Patient's height", ge=0.0)] = (
        None
    )


class OptBodyMassIndex(BaseModel):
    body_mass_index: Annotated[
        OptFloat, Field(None, description="Patient's body mass index", ge=0.0)
    ] = None


class OptOrganExaminationDetail(BaseModel):
    organ_examination_detail: Annotated[
        OptStr, Field(None, description="Patient's organ examination details")
    ] = None
