from pydantic import BaseModel, Field
from typing import Annotated
from uuid import UUID


class TranscribeParameter(BaseModel):
    id: Annotated[int, Field(..., description="ID", ge=1)]
    uuid: Annotated[UUID, Field(..., description="UUID")]
    audio: Annotated[bytes, Field(..., description="Audio")]
    filename: Annotated[str, Field(..., description="File name")]
