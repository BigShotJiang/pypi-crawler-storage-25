from pydantic import BaseModel, Field
from typing import Annotated, Generic, TypeVar
from nexo.types.string import OptStr, OptStrT
from ...common.mixins import (
    Overall,
    OptOtherInformation,
    ChiefComplaint,
    OptAdditionalComplaint,
    OptPainScale,
    OptOnset,
    OptChronology,
    OptLocation,
    OptAggravatingFactor,
    OptRelievingFactor,
    OptPersonalMedicalHistory,
    OptFamilyMedicalHistory,
    OptHabitActivityOccupation,
    OptConsumedMedication,
    OptSystolicBloodPressure,
    OptDiastolicBloodPressure,
    OptTemperature,
    OptRespirationRate,
    OptHeartRate,
    OptOxygenSaturation,
    OptAbdominalCircumference,
    OptWaistCircumference,
    OptWeight,
    OptHeight,
    OptBodyMassIndex,
    OptOrganExaminationDetail,
)


# ----- Subjective ----- #
class SubjectiveDTO(
    OptOtherInformation,
    OptConsumedMedication,
    OptHabitActivityOccupation,
    OptFamilyMedicalHistory,
    OptPersonalMedicalHistory,
    OptRelievingFactor,
    OptAggravatingFactor,
    OptLocation,
    OptChronology,
    OptOnset,
    OptPainScale,
    OptAdditionalComplaint,
    ChiefComplaint[OptStrT],
    Generic[OptStrT],
):
    pass


class FlexibleSubjectiveDTO(SubjectiveDTO[OptStr]):
    chief_complaint: Annotated[
        OptStr, Field(None, description="Patient's chief complaint")
    ] = None


class StrictSubjectiveDTO(SubjectiveDTO[str]):
    pass


OptSubjectiveDTO = SubjectiveDTO | None
OptSubjectiveDTOT = TypeVar("OptSubjectiveDTOT", bound=OptSubjectiveDTO)


class SubjectiveDTOMixin(BaseModel, Generic[OptSubjectiveDTOT]):
    subjective: Annotated[OptSubjectiveDTOT, Field(..., description="Subjective")]


# ----- Vital Sign ----- #
class VitalSignDTO(
    OptOrganExaminationDetail,
    OptBodyMassIndex,
    OptWeight,
    OptHeight,
    OptWaistCircumference,
    OptAbdominalCircumference,
    OptOxygenSaturation,
    OptHeartRate,
    OptRespirationRate,
    OptTemperature,
    OptDiastolicBloodPressure,
    OptSystolicBloodPressure,
):
    pass


OptVitalSignDTO = VitalSignDTO | None
OptVitalSignDTOT = TypeVar("OptVitalSignDTOT", bound=OptVitalSignDTO)


class VitalSignDTOMixin(BaseModel, Generic[OptVitalSignDTOT]):
    vital_sign: Annotated[OptVitalSignDTOT, Field(..., description="Vital Sign")]


# ----- Objective ----- #
ObjectiveOverallT = TypeVar("ObjectiveOverallT", bound=OptStr)


class ObjectiveDTO(
    OptOtherInformation,
    VitalSignDTOMixin[OptVitalSignDTOT],
    Overall[ObjectiveOverallT],
    Generic[
        ObjectiveOverallT,
        OptVitalSignDTOT,
    ],
):
    pass


class FlexibleObjectiveDTO(ObjectiveDTO[OptStr, VitalSignDTO]):
    overall: Annotated[OptStr, Field(None, description="Overall")] = None


class StrictObjectiveDTO(ObjectiveDTO[str, VitalSignDTO]):
    pass


OptObjectiveDTO = ObjectiveDTO | None
OptObjectiveDTOT = TypeVar("OptObjectiveDTOT", bound=OptObjectiveDTO)


class ObjectiveDTOMixin(BaseModel, Generic[OptObjectiveDTOT]):
    objective: Annotated[OptObjectiveDTOT, Field(..., description="Objective")]


# ----- Assessment ----- #
AssessmentOverallT = TypeVar("AssessmentOverallT", bound=OptStr)


class AssessmentDTO(Overall[AssessmentOverallT], Generic[AssessmentOverallT]):
    pass


class FlexibleAssessmentDTO(AssessmentDTO[OptStr]):
    overall: Annotated[OptStr, Field(None, description="Overall")] = None


class StrictAssessmentDTO(AssessmentDTO[str]):
    pass


OptAssessmentDTO = AssessmentDTO | None
OptAssessmentDTOT = TypeVar("OptAssessmentDTOT", bound=OptAssessmentDTO)


class AssessmentDTOMixin(BaseModel, Generic[OptAssessmentDTOT]):
    assessment: Annotated[OptAssessmentDTOT, Field(..., description="Assessment")]


# ----- Plan ----- #
PlanOverallT = TypeVar("PlanOverallT", bound=OptStr)


class PlanDTO(Overall[PlanOverallT], Generic[PlanOverallT]):
    pass


class FlexiblePlanDTO(PlanDTO[OptStr]):
    overall: Annotated[OptStr, Field(None, description="Overall")] = None


class StrictPlanDTO(PlanDTO[str]):
    pass


OptPlanDTO = PlanDTO | None
OptPlanDTOT = TypeVar("OptPlanDTOT", bound=OptPlanDTO)


class PlanDTOMixin(BaseModel, Generic[OptPlanDTOT]):
    plan: Annotated[OptPlanDTOT, Field(..., description="Plan")]


# ----- SOAP ----- #
class SOAPDTO(
    PlanDTOMixin[OptPlanDTOT],
    AssessmentDTOMixin[OptAssessmentDTOT],
    ObjectiveDTOMixin[OptObjectiveDTOT],
    SubjectiveDTOMixin[OptSubjectiveDTOT],
    Generic[
        OptSubjectiveDTOT,
        OptObjectiveDTOT,
        OptAssessmentDTOT,
        OptPlanDTOT,
    ],
):
    pass


OptSOAPDTO = SOAPDTO | None
OptSOAPDTOT = TypeVar("OptSOAPDTOT", bound=OptSOAPDTO)


class FlexibleSOAPDTO(
    SOAPDTO[
        FlexibleSubjectiveDTO | None,
        FlexibleObjectiveDTO | None,
        FlexibleAssessmentDTO | None,
        FlexiblePlanDTO | None,
    ]
):
    subjective: Annotated[
        FlexibleSubjectiveDTO | None, Field(None, description="Subjective")
    ] = None
    objective: Annotated[
        FlexibleObjectiveDTO | None, Field(None, description="Objective")
    ] = None
    assessment: Annotated[
        FlexibleAssessmentDTO | None, Field(None, description="Assessment")
    ] = None
    plan: Annotated[FlexiblePlanDTO | None, Field(None, description="Plan")] = None


class StrictSOAPDTO(
    SOAPDTO[
        StrictSubjectiveDTO,
        StrictObjectiveDTO,
        StrictAssessmentDTO,
        StrictPlanDTO,
    ]
):
    pass


class SOAPDTOMixin(BaseModel, Generic[OptSOAPDTOT]):
    soap: Annotated[OptSOAPDTOT, Field(..., description="SOAP")]
