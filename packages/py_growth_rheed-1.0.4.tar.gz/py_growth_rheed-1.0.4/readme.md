# PY_GROWTH Simulation Package

<div align="center">
  <img src="https://img.shields.io/badge/Python-3.10+-blue.svg" alt="Python Version"/>
  <img src="https://img.shields.io/badge/JAX-Accelerated-orange.svg" alt="JAX Accelerated"/>
  <img src="https://img.shields.io/badge/Numba-JIT-green.svg" alt="Numba JIT"/>
  <img src="https://img.shields.io/badge/License-BSD_3--Clause-green.svg" alt="BSD-3-Clause"/>
  <img src="https://img.shields.io/pypi/v/py-growth-RHEED.svg" alt="PyPI Version"/>
</div>

**PY_GROWTH** is a modern, high-performance Python package for simulating layer coverages during the growth of thin epitaxial films and the corresponding **RHEED (Reflection High-Energy Electron Diffraction)** intensities within the kinematical approximation. 

This package translates, refactors, and massively accelerates legacy C++ simulation algorithms using state-of-the-art numerical engines (`NumPy`, `Numba LLVM`, and `JAX/XLA`), enabling rapid programmatic experimentation and data plotting.

---

## 1. Quick Start & Tutorial

### Installation

Install directly from PyPI:
```bash
pip install py-growth-RHEED
```
This automatically resolves all dependencies (`numpy`, `numba`, `jax`, `plotly`).

Alternatively, clone this repository and install in editable mode:
```bash
git clone https://github.com/BartekDaniluk/C---code-for-simulations-of-RHEED-intensity-oscillations-within-the-kinematical-approximation..git
cd C---code-for-simulations-of-RHEED-intensity-oscillations-within-the-kinematical-approximation.
pip install -e .
```

### Usage

Pass raw data arrays directly to the simulation engine:

```python
import numpy as np
import plotly.graph_objects as go
from PY_GROWTH.numpy import run_simulation

# Define simulation parameters
num_layers = 15
an_kn = np.full(num_layers, 100.0)
growth_rates = np.full(num_layers, 1.0)

# Execute the Adaptive Cash-Karp Runge-Kutta solver
results = run_simulation(
    model_type=0,        # 0=Diffusive, 1=Dist_1, 2=Dist_2
    num_layers=num_layers,
    t_max=12.0,          # Max growth time (s)
    num_intervals=1000,  # Data points sampled
    an_kn=an_kn,
    growth_rates=growth_rates
)

# Plot RHEED Intensity Oscillations
fig = go.Figure()
fig.add_trace(go.Scatter(x=results['time'], y=results['intensity'], mode='lines', name='Intensity'))
fig.update_layout(title="RHEED Intensity Oscillations", xaxis_title="Time (s)", yaxis_title="RHEED Intensity")
fig.show()
```

### Loading from Input Files

If you cloned the repository, example data files are provided in `exampleData/`:

```python
from PY_GROWTH.numpy import run_simulation, load_input_data

model_type, num_layers, t_max, num_intervals, _, _, an_kn, growth_rates = load_input_data("exampleData/inputData.dat")
results = run_simulation(model_type, num_layers, t_max, num_intervals, an_kn, growth_rates)
```

See `examples/` for complete scripts using all three backends.

### Switching Backends

All three engines expose an identical `run_simulation` API:

```python
from PY_GROWTH.numpy import run_simulation   # Pure NumPy (default)
from PY_GROWTH.numba import run_simulation   # Numba LLVM JIT-compiled
from PY_GROWTH.jax import run_simulation     # JAX/XLA hardware-accelerated
```

---

## 2. Theory & Background

PY_GROWTH provides a deterministic, rigorous numerical solution for initial value problems analyzing nonlinear differential equations. The user provides constraints dictating how growth parameters ($A_n$ or $k_n$) act relative to linear intervals.

The software computes three primary physical models:
* **Model 0 (Diffusive Growth):** Simulates standard continuous step-flow and localized layer progression.
* **Model 1 (Distributed Growth Type 1):** Introduces probabilistic dispersion mechanics across surface coverages.
* **Model 2 (Distributed Growth Type 2):** Alters distribution bounds to simulate chaotic island generation.

### The Input Data Schema

The `inputData.dat` file adheres to a strict C++-legacy schema. It expects floating-point matrices defining the system exactly in this sequence:
1. `modelType`: 0, 1, or 2.
2. `numLayers`: The number of discrete vertical atom sequences evaluated simultaneously.
3. `tMax`: Upper limit of the growth time interval.
4. `num_intervals`: Granularity of output data.
5. Boolean flags dictating continuous versus fixed constraints.
6. The $A_n$ (or $k_n$) arrays mapped individually to each layer boundary.
7. Growth rates representing $1/\tau_n \text{ MLs}^{-1}$.

--- 

## 3. Academic Citations

If incorporating **PY_GROWTH** into research publications, please consider citing:

* **The ODE Solver (Cash-Karp Runge-Kutta 5th-Order):** 
  Cash, J. R., & Karp, A. H. (1990). *A variable order Runge-Kutta method for initial value problems with rapidly varying right-hand sides.* ACM Transactions on Mathematical Software (TOMS), 16(3), 201-222.
* **The Numba LLVM Architecture:** 
  Lam, S. K., Pitrou, A., & Seibert, S. (2015). *Numba: A LLVM-based Python JIT compiler.* In Proceedings of the Second Workshop on the LLVM Compiler Infrastructure in HPC (pp. 1-6).
* **The Google JAX/XLA Accelerator:** 
  Bradbury, J., Frostig, R., Hawkins, P., Johnson, M. J., Leary, C., Maclaurin, D., Necula, G., Paszke, A., VanderPlas, J., Wanderman-Milne, S., & Zhang, Q. (2018). *JAX: composable transformations of Python+NumPy programs.* http://github.com/google/jax

---

## 4. Publishing Updates to PyPI

To publish a new version to the global Python Package Index:
```bash
pip install build twine
python -m build
twine upload dist/*
```

---

## License

This project is licensed under the **BSD 3-Clause License** — see the [LICENSE](LICENSE) file for details.  
Free for academic, research, and commercial use.
