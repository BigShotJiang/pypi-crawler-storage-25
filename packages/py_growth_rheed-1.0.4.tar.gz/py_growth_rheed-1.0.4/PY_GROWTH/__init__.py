"""
PY_GROWTH - RHEED Intensity Oscillation Simulator.
"""
