import numpy as np
from numba import njit
import math

@njit(cache=True)
def rkck(y, dydx, x, h, derivs, args):
    b21 = 0.2; b31 = 3.0/40.0; b32 = 9.0/40.0; b41 = 0.3; b42 = -0.9; b43 = 1.2
    b51 = -11.0/54.0; b52 = 2.5; b53 = -70.0/27.0; b54 = 35.0/27.0
    b61 = 1631.0/55296.0; b62 = 175.0/512.0; b63 = 575.0/13824.0
    b64 = 44275.0/110592.0; b65 = 253.0/4096.0
    c1 = 37.0/378.0; c3 = 250.0/621.0; c4 = 125.0/594.0; c6 = 512.0/1771.0
    dc5 = -277.00/14336.0
    dc1 = c1 - 2825.0/27648.0; dc3 = c3 - 18575.0/48384.0
    dc4 = c4 - 13525.0/55296.0; dc6 = c6 - 0.25

    ak2 = derivs(x + b21*h, y + b21*h*dydx, *args)
    ak3 = derivs(x + (b31+b32)*h, y + h*(b31*dydx + b32*ak2), *args)
    ak4 = derivs(x + (b41+b42+b43)*h, y + h*(b41*dydx + b42*ak2 + b43*ak3), *args)
    ak5 = derivs(x + (b51+b52+b53+b54)*h, y + h*(b51*dydx + b52*ak2 + b53*ak3 + b54*ak4), *args)
    ak6 = derivs(x + (b61+b62+b63+b64+b65)*h, y + h*(b61*dydx + b62*ak2 + b63*ak3 + b64*ak4 + b65*ak5), *args)

    yout = y + h*(c1*dydx + c3*ak3 + c4*ak4 + c6*ak6)
    yerr = h*(dc1*dydx + dc3*ak3 + dc4*ak4 + dc5*ak5 + dc6*ak6)
    
    return yout, yerr

@njit(cache=True)
def rkqs(y, dydx, x, htry, eps, yscal, derivs, args):
    SAFETY = 0.9; PGROW = -0.2; PSHRNK = -0.25; ERRCON = 1.89e-4
    h = htry
    
    while True:
        ytemp, yerr = rkck(y, dydx, x, h, derivs, args)
        
        errmax = 0.0
        for i in range(len(yerr)):
            err = abs(yerr[i] / yscal[i])
            if err > errmax:
                errmax = err
        errmax /= eps
        
        if errmax <= 1.0:
            break
            
        htemp = SAFETY * h * (errmax ** PSHRNK)
        h = max(htemp, 0.1 * h) if h >= 0.0 else min(htemp, 0.1 * h)
        
    if errmax > ERRCON:
        hnext = SAFETY * h * (errmax ** PGROW)
    else:
        hnext = 5.0 * h
        
    x_new = x + h
    return ytemp, x_new, hnext

@njit(cache=True)
def solve_ode_adaptive(derivs, y0, t_span, args, num_intervals, eps=1.0e-7, h1=1.0e-3):
    t0, t_max = t_span
    TINY = 1.0e-30
    
    y = np.copy(y0)
    x = t0
    h = h1
    
    d_x_sav = t_max / num_intervals
    x_sav = x - d_x_sav * 2.0
    
    hist_t = np.zeros(num_intervals + 5, dtype=np.float64)
    hist_y = np.zeros((num_intervals + 5, len(y0)), dtype=np.float64)
    out_idx = 0
    
    MAXSTP = 300000
    for _ in range(MAXSTP):
        dydx = derivs(x, y, *args)
        
        yscal = np.zeros(len(y), dtype=np.float64)
        for i in range(len(y)):
            yscal[i] = abs(y[i]) + abs(dydx[i] * h) + TINY
        
        if abs(x - x_sav) > abs(d_x_sav) and out_idx < num_intervals:
            hist_t[out_idx] = x
            hist_y[out_idx, :] = y
            out_idx += 1
            x_sav = x
            
        if (x + h - t_max) * (x + h - t0) > 0.0:
            h = t_max - x
            
        y, x, hnext = rkqs(y, dydx, x, h, eps, yscal, derivs, args)
        
        if (x - t_max) * (t_max - t0) >= 0.0:
            if out_idx < len(hist_t):
                hist_t[out_idx] = x
                hist_y[out_idx, :] = y
                out_idx += 1
            break
            
        h = hnext
        
    return hist_t[:out_idx], hist_y[:out_idx, :]
