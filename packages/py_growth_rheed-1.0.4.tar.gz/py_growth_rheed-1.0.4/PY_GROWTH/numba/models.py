import numpy as np
from numba import njit
import math

@njit(cache=True)
def th(n: int, theta: np.ndarray) -> float:
    """
    Retrieves the coverage value simulating generalized padding.
    Upper boundary condition (n<=0) treats coverage as 1.0 (fully covered substrate).
    Lower boundary condition (n>nMax) treats coverage as 0.0 (no coverage yet).
    """
    nMax = len(theta) - 1
    if n < 0:
        return 1.0
    elif n > nMax:
        return 0.0
    else:
        return theta[n]

@njit(cache=True)
def dn1(n: int, theta: np.ndarray) -> float:
    """Distribution function 1 for Distributed model 1."""
    tt = th(n, theta)
    if tt < 0.0: tt = 0.0
    if tt > 1.0: tt = 1.0
    return tt * math.sqrt(1.0 - tt)

@njit(cache=True)
def dn2(n: int, theta: np.ndarray) -> float:
    """Distribution function 2 for Distributed model 2."""
    tt = th(n, theta)
    if tt < 0.0: tt = 0.0
    if tt > 1.0: tt = 1.0
    if tt < 0.5:
        return math.sqrt(tt)
    else:
        return math.sqrt(1.0 - tt)

@njit(cache=True)
def derivs0(t: float, theta: np.ndarray, C: np.ndarray, gR: np.ndarray) -> np.ndarray:
    """ Diffusive growth: Model 0 """
    nMax = len(theta)
    dThetaDt = np.zeros(nMax)
    for n in range(nMax):
        dTheta = th(n-1, theta) - th(n, theta)
        dThetaDt[n] = (dTheta * gR[n] + 
                       C[n] * (th(n+1, theta) - th(n+2, theta)) * dTheta - 
                       C[n] * (th(n, theta) - th(n+1, theta)) * (th(n-2, theta) - th(n-1, theta)))
    return dThetaDt

@njit(cache=True)
def derivs1(t: float, theta: np.ndarray, C: np.ndarray, gR: np.ndarray) -> np.ndarray:
    """ Distributed growth model 1: Model 1 """
    nMax = len(theta)
    dThetaDt = np.zeros(nMax)
    for n in range(nMax):
        dTheta = th(n-1, theta) - th(n, theta)
        
        dn1_n_m1 = dn1(n-1, theta)
        dn1_n = dn1(n, theta)
        dn1_n_p1 = dn1(n+1, theta)
        
        C_prev = 0.0 if n == 0 else C[n-1]
        
        if dn1_n_m1 != 0.0:
            dTheta -= C_prev * dTheta * dn1_n_m1 / (dn1_n_m1 + dn1_n)
            
        if dn1_n > 0.0:
            dTheta += C[n] * (th(n, theta) - th(n+1, theta)) * dn1_n / (dn1_n + dn1_n_p1)
            
        dThetaDt[n] = dTheta * gR[n]
    return dThetaDt

@njit(cache=True)
def derivs2(t: float, theta: np.ndarray, C: np.ndarray, gR: np.ndarray) -> np.ndarray:
    """ Distributed growth model 2: Model 2 """
    nMax = len(theta)
    dThetaDt = np.zeros(nMax)
    for n in range(nMax):
        dTheta = th(n-1, theta) - th(n, theta)
        
        dn2_n_m1 = dn2(n-1, theta)
        dn2_n = dn2(n, theta)
        dn2_n_p1 = dn2(n+1, theta)
        
        C_prev = 0.0 if n == 0 else C[n-1]
        
        if dn2_n_m1 != 0.0:
            dTheta -= C_prev * dTheta * dn2_n_m1 / (dn2_n_m1 + dn2_n)
            
        if dn2_n > 0.0:
            dTheta += C[n] * (th(n, theta) - th(n+1, theta)) * dn2_n / (dn2_n + dn2_n_p1)
            
        dThetaDt[n] = dTheta * gR[n]
    return dThetaDt

@njit(cache=True)
def compute_intensity(coverage_history: np.ndarray) -> np.ndarray:
    """
    Computes Kinematical Diffracted Intensity.
    
    Args:
        coverage_history (np.ndarray): History matrix of shape (num_time_steps, numLayers).
        
    Returns:
        np.ndarray: Evaluated sequence of intensity values.
    """
    num_t = coverage_history.shape[0]
    num_layers = coverage_history.shape[1]
    intensity = np.zeros(num_t)
    
    PI = math.pi
    for t in range(num_t):
        cDI = 1.0 - coverage_history[t, 0]
        for n in range(1, num_layers):
            cDI += (coverage_history[t, n-1] - coverage_history[t, n]) * math.cos(n * PI)
        intensity[t] = cDI * cDI
    return intensity

@njit(cache=True)
def compute_rms_roughness(growthTime: np.ndarray, coverage_history: np.ndarray, gR: np.ndarray) -> np.ndarray:
    """
    Computes the RMS Roughness over time.
    
    Args:
        growthTime (np.ndarray): Vector of time steps elapsed.
        coverage_history (np.ndarray): Shape (num_time_steps, numLayers).
        gR (np.ndarray): Growth rates of the layers.
        
    Returns:
        np.ndarray: Vector of evaluated RMS roughness configurations.
    """
    num_t = coverage_history.shape[0]
    num_layers = coverage_history.shape[1]
    rms = np.zeros(num_t)
    
    for t in range(num_t):
        sD = (growthTime[t] * gR[0])**2 * (1.0 - coverage_history[t, 0])
        for n in range(1, num_layers):
            sD += (n - growthTime[t] * gR[n-1])**2 * (coverage_history[t, n-1] - coverage_history[t, n])
        rms[t] = math.sqrt(sD)
    return rms
