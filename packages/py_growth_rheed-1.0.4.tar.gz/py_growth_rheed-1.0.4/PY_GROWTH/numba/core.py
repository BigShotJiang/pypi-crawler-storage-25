import time
import numpy as np
from numba import njit
from .ode_solver import solve_ode_adaptive
from .models import derivs0, derivs1, derivs2, compute_intensity, compute_rms_roughness

@njit(cache=True)
def _jitted_pipeline(model_type, num_layers, t_max, num_intervals, an_kn, growth_rates):
    """
    Executes the entire RKCK execution block alongside physical geometry extraction mathematically isolated inside LLVM.
    Resolves Numba limitations regarding Generic Callable python function arguments.
    """
    y0 = np.zeros(num_layers, dtype=np.float64)
    
    if model_type == 0:
        hist_t, hist_y = solve_ode_adaptive(derivs0, y0, (0.0, t_max), (an_kn, growth_rates), num_intervals)
    elif model_type == 1:
        hist_t, hist_y = solve_ode_adaptive(derivs1, y0, (0.0, t_max), (an_kn, growth_rates), num_intervals)
    else:
        hist_t, hist_y = solve_ode_adaptive(derivs2, y0, (0.0, t_max), (an_kn, growth_rates), num_intervals)
        
    intensity = compute_intensity(hist_y)
    rms = compute_rms_roughness(hist_t, hist_y, growth_rates)
    
    return hist_t, hist_y, intensity, rms

def run_simulation(model_type: int, num_layers: int, t_max: float, num_intervals: int,
                   an_kn: np.ndarray, growth_rates: np.ndarray) -> dict:
    """
    Executes the RHEED ODE simulations explicitly optimized under Numba caching mechanics.
    """
    if model_type not in (0, 1, 2):
        raise ValueError(f"Unknown model_type integer: {model_type}")

    start_time = time.perf_counter()
    
    t, y, intensity, rms = _jitted_pipeline(model_type, num_layers, t_max, num_intervals, an_kn, growth_rates)
    
    end_time = time.perf_counter()
    calc_time = end_time - start_time
    
    return {
        "time": t,
        "coverage": y,
        "intensity": intensity,
        "rms_roughness": rms,
        "model_type": model_type,
        "execution_time_seconds": calc_time
    }
