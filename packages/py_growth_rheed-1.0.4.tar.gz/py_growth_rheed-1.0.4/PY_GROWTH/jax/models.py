"""
models.py

Vectorized mathematical models translating C++ loop calculations representing 
diffusive and distributed RHEED epitaxial growth dynamics.
Accelerated using JAX.
"""

import jax
import jax.numpy as jnp
from functools import partial

@jax.jit
def _th_padded(theta: jnp.ndarray) -> jnp.ndarray:
    """
    Pads the coverage array for generic layer interaction without out-of-bounds errors.
    Upper boundary condition (n<=0) treats coverage as 1.0 (fully covered substrate).
    Lower boundary condition (n>nMax) treats coverage as 0.0 (no coverage yet).
    """
    return jnp.concatenate((jnp.array([1.0, 1.0]), theta, jnp.array([0.0, 0.0])))

@jax.jit
def _dn1(theta_array: jnp.ndarray) -> jnp.ndarray:
    """Distribution function 1 for Distributed model 1."""
    th_c = jnp.clip(theta_array, 0.0, 1.0)
    return th_c * jnp.sqrt(1.0 - th_c)

@jax.jit
def _dn2(theta_array: jnp.ndarray) -> jnp.ndarray:
    """Distribution function 2 for Distributed model 2."""
    th_c = jnp.clip(theta_array, 0.0, 1.0)
    return jnp.where(th_c < 0.5, jnp.sqrt(th_c), jnp.sqrt(1.0 - th_c))

@jax.jit
def derivs0(t: float, theta: jnp.ndarray, C: jnp.ndarray, gR: jnp.ndarray) -> jnp.ndarray:
    """ Diffusive growth: Model 0 """
    th = _th_padded(theta)
    
    th_n = th[2:-2]
    th_n_minus_1 = th[1:-3]
    th_n_minus_2 = th[:-4]
    th_n_plus_1 = th[3:-1]
    th_n_plus_2 = th[4:]
    
    dTheta = th_n_minus_1 - th_n
    
    dThetaDt = (dTheta * gR + 
                C * (th_n_plus_1 - th_n_plus_2) * dTheta - 
                C * (th_n - th_n_plus_1) * (th_n_minus_2 - th_n_minus_1))
    
    return dThetaDt

@jax.jit
def derivs1(t: float, theta: jnp.ndarray, C: jnp.ndarray, gR: jnp.ndarray) -> jnp.ndarray:
    """ Distributed growth model 1: Model 1 """
    th = _th_padded(theta)
    
    th_n = th[2:-2]
    th_n_minus_1 = th[1:-3]
    th_n_plus_1 = th[3:-1]
    
    dn1_n = _dn1(th_n)
    dn1_n_minus_1 = _dn1(th_n_minus_1)
    dn1_n_plus_1 = _dn1(th_n_plus_1)
    
    C_n = C
    C_n_minus_1 = jnp.pad(C, (1, 0), constant_values=0.0)[:-1]
    
    dTheta = th_n_minus_1 - th_n
    
    den_m1 = dn1_n_minus_1 + dn1_n
    term_m1 = jnp.where(dn1_n_minus_1 != 0.0, 
                       (C_n_minus_1 * dTheta * dn1_n_minus_1) / den_m1, 
                       0.0)
    
    den_p1 = dn1_n + dn1_n_plus_1
    term_p1 = jnp.where(dn1_n > 0.0, 
                       (C_n * (th_n - th_n_plus_1) * dn1_n) / den_p1, 
                       0.0)
    
    return (dTheta - term_m1 + term_p1) * gR

@jax.jit
def derivs2(t: float, theta: jnp.ndarray, C: jnp.ndarray, gR: jnp.ndarray) -> jnp.ndarray:
    """ Distributed growth model 2: Model 2 """
    th = _th_padded(theta)
    
    th_n = th[2:-2]
    th_n_minus_1 = th[1:-3]
    th_n_plus_1 = th[3:-1]
    
    dn2_n = _dn2(th_n)
    dn2_n_minus_1 = _dn2(th_n_minus_1)
    dn2_n_plus_1 = _dn2(th_n_plus_1)
    
    C_n = C
    C_n_minus_1 = jnp.pad(C, (1, 0), constant_values=0.0)[:-1]
    
    dTheta = th_n_minus_1 - th_n
    
    den_m1 = dn2_n_minus_1 + dn2_n
    term_m1 = jnp.where(dn2_n_minus_1 != 0.0, 
                       (C_n_minus_1 * dTheta * dn2_n_minus_1) / den_m1, 
                       0.0)
    
    den_p1 = dn2_n + dn2_n_plus_1
    term_p1 = jnp.where(dn2_n > 0.0, 
                       (C_n * (th_n - th_n_plus_1) * dn2_n) / den_p1, 
                       0.0)
    
    return (dTheta - term_m1 + term_p1) * gR

@jax.jit
def compute_intensity(coverage_history: jnp.ndarray) -> jnp.ndarray:
    """
    Computes Kinematical Diffracted Intensity.
    
    Args:
        coverage_history (jnp.ndarray): History matrix of shape (num_time_steps, numLayers).
        
    Returns:
        jnp.ndarray: Evaluated sequence of intensity values.
    """
    num_layers = coverage_history.shape[1]
    cDI = 1.0 - coverage_history[:, 0]
    
    n_indices = jnp.arange(1, num_layers)
    cos_n_pi = jnp.cos(n_indices * jnp.pi)
    
    cov_n = coverage_history[:, :-1]
    cov_n_plus_1 = coverage_history[:, 1:]
    
    sum_term = jnp.sum((cov_n - cov_n_plus_1) * cos_n_pi, axis=1)
    # Using python if is evaluated at trace time, which works if num_layers is static.
    # In JAX, shapes (and thus num_layers) are always statically traced.
    if num_layers > 1:
        cDI += sum_term
        
    return cDI ** 2

@jax.jit
def compute_rms_roughness(growth_time: jnp.ndarray, coverage_history: jnp.ndarray, gR: jnp.ndarray) -> jnp.ndarray:
    """
    Computes the RMS Roughness over time.
    
    Args:
        growth_time (jnp.ndarray): Vector of time steps elapsed.
        coverage_history (jnp.ndarray): Shape (num_time_steps, numLayers).
        gR (jnp.ndarray): Growth rates of the layers.
        
    Returns:
        jnp.ndarray: Vector of evaluated RMS roughness configurations.
    """
    num_layers = coverage_history.shape[1]
    
    sD = (growth_time * gR[0])**2 * (1.0 - coverage_history[:, 0])
    
    if num_layers > 1:
        t = growth_time[:, jnp.newaxis]
        n_indices = jnp.arange(1, num_layers)
        cov_n = coverage_history[:, :-1]
        cov_n_plus_1 = coverage_history[:, 1:]
        
        gR_inner = gR[:num_layers-1]
        
        sum_term = jnp.sum((n_indices - t * gR_inner)**2 * (cov_n - cov_n_plus_1), axis=1)
        sD += sum_term
        
    return jnp.sqrt(sD)
