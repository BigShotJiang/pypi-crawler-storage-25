"""
core.py

Defines the centralized pipeline that binds the physics models with the ODE 
solver to produce and return calculation history dictionaries.
Accelerated end-to-end using JAX.
"""

from typing import Dict, Any, Literal
import time
import jax
import jax.numpy as jnp

# Enable 64-bit precision to match NumPy/C++ for identical math tracing
jax.config.update("jax_enable_x64", True)

from functools import partial

from .ode_solver import solve_ode_adaptive
from .models import derivs0, derivs1, derivs2, compute_intensity, compute_rms_roughness

@partial(jax.jit, static_argnames=['model_type', 'num_layers', 'num_intervals'])
def _run_sim_jitted(
    model_type: int,
    num_layers: int,
    t_max: float,
    num_intervals: int,
    an_kn: jnp.ndarray,
    growth_rates: jnp.ndarray
):
    """
    Core JIT-compiled simulation trace.
    """
    if model_type == 0:
        derivs_closure = lambda x, y: derivs0(x, y, an_kn, growth_rates)
    elif model_type == 1:
        derivs_closure = lambda x, y: derivs1(x, y, an_kn, growth_rates)
    elif model_type == 2:
        derivs_closure = lambda x, y: derivs2(x, y, an_kn, growth_rates)
    else:
        # Fallback to 0 if traced incorrectly, but static_argnames prevents this
        derivs_closure = lambda x, y: derivs0(x, y, an_kn, growth_rates)

    y0 = jnp.zeros(num_layers, dtype=jnp.float64)
    
    results = solve_ode_adaptive(
        derivs=derivs_closure, 
        y0=y0, 
        t_span=(0.0, t_max), 
        num_intervals=num_intervals
    )
    
    t_history = results["t"]
    y_history = results["y"]
    valid_count = results["valid_count"]
    
    intensity = compute_intensity(y_history)
    roughness = compute_rms_roughness(t_history, y_history, growth_rates)
    
    return t_history, y_history, intensity, roughness, valid_count

def run_simulation(
    model_type: Literal[0, 1, 2],
    num_layers: int,
    t_max: float,
    num_intervals: int,
    an_kn: jnp.ndarray,
    growth_rates: jnp.ndarray
) -> Dict[str, Any]:
    """
    Orchestrates the chosen ODE implementation on a zero-based coverage system.
    Returns standard python dictionary slicing dynamic lengths appropriately.
    """
    import numpy as np # For output conversion
    
    start_time = time.perf_counter()
    
    an_kn_jnp = jnp.array(an_kn, dtype=jnp.float64)
    gR_jnp = jnp.array(growth_rates, dtype=jnp.float64)
    
    t_hist_jnp, y_hist_jnp, int_jnp, rough_jnp, valid_count = _run_sim_jitted(
        model_type=int(model_type),
        num_layers=int(num_layers),
        t_max=float(t_max),
        num_intervals=int(num_intervals),
        an_kn=an_kn_jnp,
        growth_rates=gR_jnp
    )
    
    # Block until ready to measure true execution time including GPU execution
    t_hist_jnp.block_until_ready()
    
    end_time = time.perf_counter()
    calc_time = end_time - start_time
    
    v = int(valid_count)
    
    return {
        "time": np.array(t_hist_jnp[:v]),
        "coverage": np.array(y_hist_jnp[:v, :]),
        "intensity": np.array(int_jnp[:v]),
        "rms_roughness": np.array(rough_jnp[:v]),
        "model_type": model_type,
        "execution_time_seconds": calc_time
    }
