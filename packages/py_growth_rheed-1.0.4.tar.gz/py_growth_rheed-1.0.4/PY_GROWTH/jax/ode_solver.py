"""
ode_solver.py

Provides a generalized, pure JAX implementation of the Cash-Karp 
fifth-order Runge-Kutta adaptive ODE solver. Designed using 
jax.lax.while_loop to allow end-to-end JIT compilation.
"""

import jax
import jax.numpy as jnp
from typing import Callable, Tuple, Dict

def rkck(y: jnp.ndarray, dydx: jnp.ndarray, x: float, h: float, 
         derivs: Callable[[float, jnp.ndarray], jnp.ndarray]) -> Tuple[jnp.ndarray, jnp.ndarray]:
    """Cash-Karp fifth-order Runge-Kutta step."""
    b21 = 0.2; b31 = 3.0/40.0; b32 = 9.0/40.0; b41 = 0.3; b42 = -0.9; b43 = 1.2
    b51 = -11.0/54.0; b52 = 2.5; b53 = -70.0/27.0; b54 = 35.0/27.0
    b61 = 1631.0/55296.0; b62 = 175.0/512.0; b63 = 575.0/13824.0
    b64 = 44275.0/110592.0; b65 = 253.0/4096.0
    
    c1 = 37.0/378.0; c3 = 250.0/621.0; c4 = 125.0/594.0; c6 = 512.0/1771.0
    dc5 = -277.00/14336.0
    
    dc1 = c1 - 2825.0/27648.0; dc3 = c3 - 18575.0/48384.0
    dc4 = c4 - 13525.0/55296.0; dc6 = c6 - 0.25

    ak2 = derivs(x + b21*h, y + b21*h*dydx)
    ak3 = derivs(x + (b31+b32)*h, y + h*(b31*dydx + b32*ak2))
    ak4 = derivs(x + (b41+b42+b43)*h, y + h*(b41*dydx + b42*ak2 + b43*ak3))
    ak5 = derivs(x + (b51+b52+b53+b54)*h, y + h*(b51*dydx + b52*ak2 + b53*ak3 + b54*ak4))
    ak6 = derivs(x + (b61+b62+b63+b64+b65)*h, y + h*(b61*dydx + b62*ak2 + b63*ak3 + b64*ak4 + b65*ak5))

    yout = y + h*(c1*dydx + c3*ak3 + c4*ak4 + c6*ak6)
    yerr = h*(dc1*dydx + dc3*ak3 + dc4*ak4 + dc5*ak5 + dc6*ak6)
    
    return yout, yerr

def rkqs(y: jnp.ndarray, dydx: jnp.ndarray, x: float, htry: float, eps: float, 
         yscal: jnp.ndarray, derivs: Callable[[float, jnp.ndarray], jnp.ndarray]):
    """Fifth-order Runge Kutta step with monitoring of local truncation error."""
    SAFETY = 0.9; PGROW = -0.2; PSHRNK = -0.25; ERRCON = 1.89e-4
    
    def cond_fun(state):
        h, ytemp, yerr, errmax = state
        return errmax > 1.0
        
    def body_fun(state):
        h, _, _, _ = state
        ytemp, yerr = rkck(y, dydx, x, h, derivs)
        errmax = jnp.max(jnp.abs(yerr / yscal)) / eps
        
        htemp = SAFETY * h * (errmax ** PSHRNK)
        h_new = jnp.where(h >= 0.0, jnp.maximum(htemp, 0.1 * h), jnp.minimum(htemp, 0.1 * h))
        
        h_next_iter = jnp.where(errmax > 1.0, h_new, h)
        return (h_next_iter, ytemp, yerr, errmax)
        
    init_errmax = jnp.array(2.0, dtype=y.dtype)
    init_state = (htry, y, jnp.zeros_like(y), init_errmax)
    
    final_state = jax.lax.while_loop(cond_fun, body_fun, init_state)
    h_used, ytemp, yerr, errmax = final_state
    
    hnext = jnp.where(errmax > ERRCON, 
                      SAFETY * h_used * (errmax ** PGROW), 
                      5.0 * h_used)
                      
    x_new = x + h_used
    return ytemp, x_new, hnext, h_used

def solve_ode_adaptive(derivs: Callable, y0: jnp.ndarray, t_span: Tuple[float, float], 
                       num_intervals: int, eps: float = 1.0e-7, h1: float = 1.0e-3) -> Dict[str, jnp.ndarray]:
    """Main driver using jax.lax.while_loop."""
    t0, t_max = t_span
    TINY = 1.0e-30
    
    d_x_sav = t_max / num_intervals
    
    history_t = jnp.zeros(num_intervals + 5, dtype=jnp.float64)
    history_y = jnp.zeros((num_intervals + 5, len(y0)), dtype=jnp.float64)
    
    def cond_fun(state):
        # State: y, x, h, x_sav, history_t, history_y, out_idx, done, steps
        return jnp.logical_not(state[7])

    def body_fun(state):
        y, x, h, x_sav, history_t, history_y, out_idx, done, steps = state
        
        dydx = derivs(x, y)
        yscal = jnp.abs(y) + jnp.abs(dydx * h) + TINY
        
        save_cond = jnp.logical_and(jnp.abs(x - x_sav) > jnp.abs(d_x_sav), out_idx < num_intervals)
        
        idx_to_update = jnp.where(save_cond, out_idx, 0)
        
        new_hist_t = jnp.where(save_cond, history_t.at[idx_to_update].set(x), history_t)
        new_hist_y = jnp.where(save_cond, history_y.at[idx_to_update].set(y), history_y)
        
        new_x_sav = jnp.where(save_cond, x, x_sav)
        new_out_idx = out_idx + jnp.where(save_cond, 1, 0)
        
        overshoot = (x + h - t_max) * (x + h - t0) > 0.0
        h_adjusted = jnp.where(overshoot, t_max - x, h)
        
        y_next, x_next, hnext, h_used = rkqs(y, dydx, x, h_adjusted, eps, yscal, derivs)
        
        finished = jnp.logical_or((x_next - t_max) * (t_max - t0) >= 0.0, steps >= 300000)
        
        save_end_cond = jnp.logical_and(finished, new_out_idx < len(new_hist_t))
        
        final_idx = jnp.where(save_end_cond, new_out_idx, 0)
        new_hist_t_final = jnp.where(save_end_cond, new_hist_t.at[final_idx].set(x_next), new_hist_t)
        new_hist_y_final = jnp.where(save_end_cond, new_hist_y.at[final_idx].set(y_next), new_hist_y)
        
        final_out_idx = new_out_idx + jnp.where(save_end_cond, 1, 0)
        
        return (y_next, x_next, hnext, new_x_sav, new_hist_t_final, new_hist_y_final, final_out_idx, finished, steps + 1)

    init_state = (
        y0,          
        jnp.array(t0, dtype=jnp.float64),          
        jnp.array(h1, dtype=jnp.float64),          
        jnp.array(t0 - d_x_sav * 2.0, dtype=jnp.float64), 
        history_t,   
        history_y,   
        jnp.array(0, dtype=jnp.int32),           
        jnp.array(False),
        jnp.array(0, dtype=jnp.int32)
    )
    
    final_state = jax.lax.while_loop(cond_fun, body_fun, init_state)
    
    _, _, _, _, final_history_t, final_history_y, final_out_idx, _, _ = final_state
    
    return {
        "t": final_history_t,
        "y": final_history_y,
        "valid_count": final_out_idx
    }
