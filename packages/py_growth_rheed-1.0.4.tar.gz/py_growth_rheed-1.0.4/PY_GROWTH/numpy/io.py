"""
io.py

Contains utilities for saving, serializing, and exporting functional calculation 
histories to disk formats.
"""

import json
import numpy as np
from typing import Dict, Any

def save_history_to_json(history_dict: Dict[str, Any], filepath: str) -> None:
    """
    Serializes mathematical history outputs (capable of containing NumPy structures)
    into a universally readable `.json` file format.
    
    Args:
        history_dict (Dict[str, Any]): The returned dictionary from `run_simulation()`.
        filepath (str): Valid string path mapping to a localized JSON file target.
    """
    def _numpy_encoder(obj: Any) -> Any:
        # Handles any stray nested NumPy structures effortlessly
        if isinstance(obj, np.ndarray):
            return obj.tolist()
        if isinstance(obj, (np.int_, np.intc, np.intp, np.int8,
                            np.int16, np.int32, np.int64, np.uint8,
                            np.uint16, np.uint32, np.uint64)):
            return int(obj)
        elif isinstance(obj, (np.float16, np.float32, np.float64)):
            return float(obj)
        elif isinstance(obj, (np.bool_)):
            return bool(obj)
        raise TypeError(f"Object of type {type(obj)} is not JSON serializable")

    # Rebuilding safely through custom types or built in conversions prevents json errs
    serialize_safe = {k: (v.tolist() if isinstance(v, np.ndarray) else v) 
                      for k, v in history_dict.items()}

    with open(filepath, 'w', encoding='utf-8') as file_out:
        json.dump(serialize_safe, file_out, indent=4, default=_numpy_encoder)

def load_input_data(filepath: str) -> dict:
    """
    Parses the legacy C++ inputData.dat configuration file.
    """
    with open(filepath, 'r') as f:
        lines = [line.strip() for line in f if line.strip()]
        
    model = int(lines[0])
    num_layers = int(lines[2])
    t_max = float(lines[3])
    linear_an_kn = lines[4].lower() == 'true'
    linear_grn = lines[5].lower() == 'true'
    
    an_kn = np.zeros(num_layers)
    growth_rates = np.zeros(num_layers)
    
    data_start = 7
    for i in range(num_layers):
        if data_start + i < len(lines):
            parts = lines[data_start + i].split()
            c_val = float(parts[0])
            gr_val = float(parts[1])
        else:
            c_val = 0.0
            gr_val = 1.0
            
        c_val = max(c_val, 0.0)
        gr_val = max(gr_val, 1e-10)
        if model != 0 and c_val >= 1.0:
            c_val = 0.9999
            
        an_kn[i] = c_val
        growth_rates[i] = gr_val
        
    if linear_an_kn and num_layers > 1:
        c1 = an_kn[0]
        c_last = an_kn[-1]
        for i in range(1, num_layers):
            an_kn[i] = c1 - (c1 - c_last) * i / (num_layers - 1)
            
    if linear_grn and num_layers > 1:
        gr1 = growth_rates[0]
        gr_last = growth_rates[-1]
        for i in range(1, num_layers):
            growth_rates[i] = gr1 - (gr1 - gr_last) * i / (num_layers - 1)
            
    return {
        "model_type": model,
        "num_layers": num_layers,
        "t_max": t_max,
        "an_kn": an_kn,
        "growth_rates": growth_rates,
        "num_intervals": 1000
    }
