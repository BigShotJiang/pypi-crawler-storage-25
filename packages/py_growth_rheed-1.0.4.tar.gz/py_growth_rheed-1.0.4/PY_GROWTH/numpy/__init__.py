"""
PY_GROWTH.numpy

Pure NumPy vectorized implementation of the RHEED ODE solvers.
"""

from .core import run_simulation
from .io import save_history_to_json, load_input_data
from .models import compute_intensity, compute_rms_roughness
from .ode_solver import solve_ode_adaptive
__all__ = [
    "run_simulation",
    "save_history_to_json",
    "load_input_data",
    "compute_intensity",
    "compute_rms_roughness",
    "solve_ode_adaptive"
]
