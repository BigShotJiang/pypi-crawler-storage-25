"""
ode_solver.py

Provides a generalized, pure NumPy implementation of the Cash-Karp 
fifth-order Runge-Kutta adaptive ODE solver. This module is designed 
to be standalone and applicable to any ODE system (e.g., Hodgkin-Huxley), 
operating completely independent of the RHEED physics wrapper.
"""

import numpy as np
from typing import Callable, Tuple, Dict, Any

def rkck(y: np.ndarray, dydx: np.ndarray, x: float, h: float, 
         derivs: Callable[[float, np.ndarray], np.ndarray]) -> Tuple[np.ndarray, np.ndarray]:
    """
    Cash-Karp fifth-order Runge-Kutta step.
    
    Args:
        y (np.ndarray): Current state vector.
        dydx (np.ndarray): Derivative at current state.
        x (float): Current independent variable (e.g., time).
        h (float): Step size.
        derivs (Callable): Function that computes the derivative dy/dx.
            Signature must be `derivs(x, y)`.
            
    Returns:
        Tuple[np.ndarray, np.ndarray]: (yout, yerr) 
            yout: New state vector after step h.
            yerr: Estimated error vector.
    """
    # RKCK constants
    b21 = 0.2; b31 = 3.0/40.0; b32 = 9.0/40.0; b41 = 0.3; b42 = -0.9; b43 = 1.2
    b51 = -11.0/54.0; b52 = 2.5; b53 = -70.0/27.0; b54 = 35.0/27.0
    b61 = 1631.0/55296.0; b62 = 175.0/512.0; b63 = 575.0/13824.0
    b64 = 44275.0/110592.0; b65 = 253.0/4096.0
    
    c1 = 37.0/378.0; c3 = 250.0/621.0; c4 = 125.0/594.0; c6 = 512.0/1771.0
    dc5 = -277.00/14336.0
    
    dc1 = c1 - 2825.0/27648.0; dc3 = c3 - 18575.0/48384.0
    dc4 = c4 - 13525.0/55296.0; dc6 = c6 - 0.25

    ak2 = derivs(x + b21*h, y + b21*h*dydx)
    ak3 = derivs(x + (b31+b32)*h, y + h*(b31*dydx + b32*ak2))
    ak4 = derivs(x + (b41+b42+b43)*h, y + h*(b41*dydx + b42*ak2 + b43*ak3))
    ak5 = derivs(x + (b51+b52+b53+b54)*h, y + h*(b51*dydx + b52*ak2 + b53*ak3 + b54*ak4))
    ak6 = derivs(x + (b61+b62+b63+b64+b65)*h, y + h*(b61*dydx + b62*ak2 + b63*ak3 + b64*ak4 + b65*ak5))

    yout = y + h*(c1*dydx + c3*ak3 + c4*ak4 + c6*ak6)
    yerr = h*(dc1*dydx + dc3*ak3 + dc4*ak4 + dc5*ak5 + dc6*ak6)
    
    return yout, yerr

def rkqs(y: np.ndarray, dydx: np.ndarray, x: float, htry: float, eps: float, 
         yscal: np.ndarray, derivs: Callable[[float, np.ndarray], np.ndarray]) -> Tuple[np.ndarray, float, float]:
    """
    Fifth-order Runge Kutta step with monitoring of local truncation error 
    to ensure accuracy and adjust stepsize.
    
    Args:
        y (np.ndarray): Current state vector.
        dydx (np.ndarray): Derivative at current state.
        x (float): Current independent variable.
        htry (float): Attempted step size.
        eps (float): Desired accuracy/error tolerance.
        yscal (np.ndarray): Vector used to scale the error evaluation.
        derivs (Callable): Derivative function `derivs(x, y)`.
        
    Returns:
        Tuple[np.ndarray, float, float]: (ytemp, x_new, hnext)
            ytemp: Updated state vector.
            x_new: Updated independent variable (x + actual step).
            hnext: Recommended step size for the next step.
    """
    SAFETY = 0.9; PGROW = -0.2; PSHRNK = -0.25; ERRCON = 1.89e-4
    h = htry
    
    while True:
        ytemp, yerr = rkck(y, dydx, x, h, derivs)
        errmax = np.max(np.abs(yerr / yscal)) / eps
        
        if errmax <= 1.0:
            break
            
        htemp = SAFETY * h * (errmax ** PSHRNK)
        h = max(htemp, 0.1 * h) if h >= 0.0 else min(htemp, 0.1 * h)
        
    if errmax > ERRCON:
        hnext = SAFETY * h * (errmax ** PGROW)
    else:
        hnext = 5.0 * h
        
    x_new = x + h
    return ytemp, x_new, hnext

def solve_ode_adaptive(derivs: Callable[[float, np.ndarray], np.ndarray], 
                       y0: np.ndarray, t_span: Tuple[float, float], 
                       num_intervals: int, eps: float = 1.0e-7, h1: float = 1.0e-3) -> Dict[str, np.ndarray]:
    """
    Main driver to solve an ODE system adaptively over a timespan, 
    saving intermediate points for history.
    
    Args:
        derivs (Callable): Function predicting y' given (x, y).
        y0 (np.ndarray): Array of initial conditions.
        t_span (Tuple[float, float]): (t0, t_final).
        num_intervals (int): Expected bounds of saved points over the timespan.
        eps (float): Error tolerance.
        h1 (float): Guessed initial step size.
        
    Returns:
        Dict[str, np.ndarray]: dictionary containing `t` and `y` histories.
    """
    t0, t_max = t_span
    TINY = 1.0e-30
    
    y = np.array(y0, dtype=float)
    x = t0
    h = h1
    
    d_x_sav = t_max / num_intervals
    x_sav = x - d_x_sav * 2.0
    
    history_t = []
    history_y = []
    
    MAXSTP = 300000
    for _ in range(MAXSTP):
        dydx = derivs(x, y)
        yscal = np.abs(y) + np.abs(dydx * h) + TINY
        
        # Save sample intermediate states spaced by an amount roughly d_x_sav
        if abs(x - x_sav) > abs(d_x_sav) and len(history_t) < num_intervals:
            history_t.append(x)
            history_y.append(y.copy())
            x_sav = x
            
        # Do not overshoot the end
        if (x + h - t_max) * (x + h - t0) > 0.0:
            h = t_max - x
            
        y, x, hnext = rkqs(y, dydx, x, h, eps, yscal, derivs)
        
        # Finished exactly at the edge
        if (x - t_max) * (t_max - t0) >= 0.0:
            history_t.append(x)
            history_y.append(y.copy())
            break
            
        h = hnext
        
    return {
        "t": np.array(history_t),
        "y": np.array(history_y)
    }
