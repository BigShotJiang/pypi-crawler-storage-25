"""
models.py

Vectorized mathematical models translating C++ loop calculations representing 
diffusive and distributed RHEED epitaxial growth dynamics.
"""

import numpy as np
from typing import Callable

def _th_padded(theta: np.ndarray) -> np.ndarray:
    """
    Pads the coverage array for generic layer interaction without out-of-bounds errors.
    Upper boundary condition (n<=0) treats coverage as 1.0 (fully covered substrate).
    Lower boundary condition (n>nMax) treats coverage as 0.0 (no coverage yet).
    """
    return np.concatenate(([1.0, 1.0], theta, [0.0, 0.0]))

def _dn1(theta_array: np.ndarray) -> np.ndarray:
    """Distribution function 1 for Distributed model 1."""
    th_c = np.clip(theta_array, 0.0, 1.0)
    return th_c * np.sqrt(1.0 - th_c)

def _dn2(theta_array: np.ndarray) -> np.ndarray:
    """Distribution function 2 for Distributed model 2."""
    th_c = np.clip(theta_array, 0.0, 1.0)
    return np.where(th_c < 0.5, np.sqrt(th_c), np.sqrt(1.0 - th_c))

def derivs0(t: float, theta: np.ndarray, C: np.ndarray, gR: np.ndarray) -> np.ndarray:
    """ Diffusive growth: Model 0 """
    th = _th_padded(theta)
    
    th_n = th[2:-2]
    th_n_minus_1 = th[1:-3]
    th_n_minus_2 = th[:-4]
    th_n_plus_1 = th[3:-1]
    th_n_plus_2 = th[4:]
    
    dTheta = th_n_minus_1 - th_n
    
    dThetaDt = (dTheta * gR + 
                C * (th_n_plus_1 - th_n_plus_2) * dTheta - 
                C * (th_n - th_n_plus_1) * (th_n_minus_2 - th_n_minus_1))
    
    return dThetaDt

def derivs1(t: float, theta: np.ndarray, C: np.ndarray, gR: np.ndarray) -> np.ndarray:
    """ Distributed growth model 1: Model 1 """
    th = _th_padded(theta)
    
    th_n = th[2:-2]
    th_n_minus_1 = th[1:-3]
    th_n_plus_1 = th[3:-1]
    
    dn1_n = _dn1(th_n)
    dn1_n_minus_1 = _dn1(th_n_minus_1)
    dn1_n_plus_1 = _dn1(th_n_plus_1)
    
    C_n = C
    C_n_minus_1 = np.pad(C, (1, 0), constant_values=0.0)[:-1]
    
    dTheta = th_n_minus_1 - th_n
    
    den_m1 = dn1_n_minus_1 + dn1_n
    term_m1 = np.zeros_like(dTheta)
    safe_den_m1 = np.where(den_m1 == 0.0, 1.0, den_m1)
    np.divide(C_n_minus_1 * dTheta * dn1_n_minus_1, safe_den_m1, out=term_m1, where=(dn1_n_minus_1 != 0.0))
    
    den_p1 = dn1_n + dn1_n_plus_1
    term_p1 = np.zeros_like(dTheta)
    safe_den_p1 = np.where(den_p1 == 0.0, 1.0, den_p1)
    np.divide(C_n * (th_n - th_n_plus_1) * dn1_n, safe_den_p1, out=term_p1, where=(dn1_n > 0.0))
    
    return (dTheta - term_m1 + term_p1) * gR

def derivs2(t: float, theta: np.ndarray, C: np.ndarray, gR: np.ndarray) -> np.ndarray:
    """ Distributed growth model 2: Model 2 """
    th = _th_padded(theta)
    
    th_n = th[2:-2]
    th_n_minus_1 = th[1:-3]
    th_n_plus_1 = th[3:-1]
    
    dn2_n = _dn2(th_n)
    dn2_n_minus_1 = _dn2(th_n_minus_1)
    dn2_n_plus_1 = _dn2(th_n_plus_1)
    
    C_n = C
    C_n_minus_1 = np.pad(C, (1, 0), constant_values=0.0)[:-1]
    
    dTheta = th_n_minus_1 - th_n
    
    den_m1 = dn2_n_minus_1 + dn2_n
    term_m1 = np.zeros_like(dTheta)
    safe_den_m1 = np.where(den_m1 == 0.0, 1.0, den_m1)
    np.divide(C_n_minus_1 * dTheta * dn2_n_minus_1, safe_den_m1, out=term_m1, where=(dn2_n_minus_1 != 0.0))
    
    den_p1 = dn2_n + dn2_n_plus_1
    term_p1 = np.zeros_like(dTheta)
    safe_den_p1 = np.where(den_p1 == 0.0, 1.0, den_p1)
    np.divide(C_n * (th_n - th_n_plus_1) * dn2_n, safe_den_p1, out=term_p1, where=(dn2_n > 0.0))
    
    return (dTheta - term_m1 + term_p1) * gR

def compute_intensity(coverage_history: np.ndarray) -> np.ndarray:
    """
    Computes Kinematical Diffracted Intensity.
    
    Args:
        coverage_history (np.ndarray): History matrix of shape (num_time_steps, numLayers).
        
    Returns:
        np.ndarray: Evaluated sequence of intensity values.
    """
    num_layers = coverage_history.shape[1]
    cDI = 1.0 - coverage_history[:, 0]
    
    if num_layers > 1:
        n_indices = np.arange(1, num_layers)
        cos_n_pi = np.cos(n_indices * np.pi)
        
        cov_n = coverage_history[:, :-1]
        cov_n_plus_1 = coverage_history[:, 1:]
        
        sum_term = np.sum((cov_n - cov_n_plus_1) * cos_n_pi, axis=1)
        cDI += sum_term
        
    return cDI ** 2

def compute_rms_roughness(growth_time: np.ndarray, coverage_history: np.ndarray, gR: np.ndarray) -> np.ndarray:
    """
    Computes the RMS Roughness over time.
    
    Args:
        growth_time (np.ndarray): Vector of time steps elapsed.
        coverage_history (np.ndarray): Shape (num_time_steps, numLayers).
        gR (np.ndarray): Growth rates of the layers.
        
    Returns:
        np.ndarray: Vector of evaluated RMS roughness configurations.
    """
    num_layers = coverage_history.shape[1]
    
    # Use pure 1D time array for initial calculation to avoid (T, T) broadcasting bugs
    sD = (growth_time * gR[0])**2 * (1.0 - coverage_history[:, 0])
    
    if num_layers > 1:
        t = growth_time[:, np.newaxis] # Expand to (T, 1) safely for inner broadcast
        n_indices = np.arange(1, num_layers)
        cov_n = coverage_history[:, :-1]
        cov_n_plus_1 = coverage_history[:, 1:]
        
        # In physical formula, `n` maps naturally to 1..num_layers-1.
        gR_inner = gR[:num_layers-1]
        sD += np.sum((n_indices - t * gR_inner)**2 * (cov_n - cov_n_plus_1), axis=1)
        
    return np.sqrt(sD)
