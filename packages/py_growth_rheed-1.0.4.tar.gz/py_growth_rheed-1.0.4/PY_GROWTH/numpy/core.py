"""
core.py

Defines the centralized pipeline that binds the physics models with the ODE 
solver to produce and return calculation history dictionaries.
"""

from typing import Dict, Any, Literal
import numpy as np

from .ode_solver import solve_ode_adaptive
from .models import derivs0, derivs1, derivs2, compute_intensity, compute_rms_roughness

def run_simulation(
    model_type: Literal[0, 1, 2],
    num_layers: int,
    t_max: float,
    num_intervals: int,
    an_kn: np.ndarray,
    growth_rates: np.ndarray
) -> Dict[str, Any]:
    """
    Orchestrates the chosen ODE implementation on a zero-based coverage system.
    
    Args:
        model_type (int): 0 for Diffusive, 1 for Distributed 1, 2 for Distributed 2.
        num_layers (int): Number of simulated layers.
        t_max (float): End time value for the ODE limits.
        num_intervals (int): Expected bounds of output steps to save.
        an_kn (np.ndarray): Configuration values (A_n or k_n) for each layer.
        growth_rates (np.ndarray): Growth speeds parameterized for each layer.
        
    Returns:
        Dict[str, Any]: Consolidated dictionary of the simulation results.
    """
    if model_type == 0:
        derivs = lambda t, y: derivs0(t, y, an_kn, growth_rates)
    elif model_type == 1:
        derivs = lambda t, y: derivs1(t, y, an_kn, growth_rates)
    elif model_type == 2:
        derivs = lambda t, y: derivs2(t, y, an_kn, growth_rates)
    else:
        raise ValueError(f"Unknown model_type code integer: {model_type}. Must be 0, 1, or 2.")

    # Base state dictates no coverage across all required physical layers at time T=0
    import time
    start_time = time.perf_counter()

    # Base state dictates no coverage across all required physical layers at time T=0
    y0 = np.zeros(num_layers, dtype=float)
    
    results = solve_ode_adaptive(
        derivs=derivs, 
        y0=y0, 
        t_span=(0.0, t_max), 
        num_intervals=num_intervals
    )
    
    t_history = results["t"]
    y_history = results["y"]
    
    intensity = compute_intensity(y_history)
    roughness = compute_rms_roughness(t_history, y_history, growth_rates)
    
    end_time = time.perf_counter()
    calc_time = end_time - start_time
    
    return {
        "time": t_history,
        "coverage": y_history,
        "intensity": intensity,
        "rms_roughness": roughness,
        "model_type": model_type,
        "execution_time_seconds": calc_time
    }
