from setuptools import setup, find_packages
import os

def parse_requirements(filename):
    if not os.path.exists(filename):
        return []
    lineiter = (line.strip() for line in open(filename))
    return [line for line in lineiter if line and not line.startswith("#")]

try:
    with open('readme.md', 'r', encoding='utf-8') as f:
        long_desc = f.read()
except FileNotFoundError:
    long_desc = 'A Python package for simulations of RHEED intensity oscillations within the kinematical approximation'

setup(
    name='py-growth-RHEED',
    version='1.0.4',
    description='A Python package for simulations of RHEED intensity oscillations within the kinematical approximation',
    long_description=long_desc,
    long_description_content_type='text/markdown',
    author='Bartek Daniluk',
    packages=find_packages(),
    install_requires=parse_requirements('requirements.txt'),
    python_requires='>=3.10',
    license='BSD 3-Clause',
    classifiers=[
        'License :: OSI Approved :: BSD License',
        'Programming Language :: Python :: 3',
        'Topic :: Scientific/Engineering :: Physics',
        'Intended Audience :: Science/Research',
    ],
)
