"""
Event - The fundamental unit of observability.

Events are immutable records of things that happened in the system.
Unlike v1's rigid TraceType enum, event types are simple strings
that support pattern matching (e.g., "agent.*", "*.error").

Example:
    ```python
    from cogent.observability import Event, create_event

    # Create event with factory
    event = create_event(
        "agent.thinking",
        agent_name="Researcher",
        iteration=1,
    )

    # Access properties
    print(event.type)       # "agent.thinking"
    print(event.category)   # "agent"
    print(event.data)       # {"agent_name": "Researcher", "iteration": 1}
    ```
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any

from cogent.core.utils import generate_id, now_utc


@dataclass(frozen=True, slots=True)
class Event:
    """
    Immutable event record.

    Attributes:
        type: Event type string (e.g., "agent.thinking", "tool.called")
        data: Event payload - arbitrary key-value data
        timestamp: When the event occurred (UTC)
        source: Origin of the event (agent name, "system", etc.)
        correlation_id: ID for correlating related events
        event_id: Unique identifier for this event
    """

    type: str
    data: dict[str, Any] = field(default_factory=dict)
    timestamp: datetime = field(default_factory=now_utc)
    source: str = "system"
    correlation_id: str | None = None
    event_id: str = field(default_factory=lambda: generate_id(8))

    @property
    def category(self) -> str:
        """
        Extract category from type.

        Examples:
            "agent.thinking" → "agent"
            "tool.called" → "tool"
            "my_app.order.placed" → "my_app"
            "custom" → "custom"
        """
        return self.type.split(".")[0] if "." in self.type else self.type

    @property
    def action(self) -> str:
        """
        Extract action from type (everything after the first dot).

        Examples:
            "agent.thinking" → "thinking"
            "tool.called" → "called"
            "my_app.order.placed" → "order.placed"
            "custom" → "custom"
        """
        parts = self.type.split(".", 1)
        return parts[1] if len(parts) > 1 else self.type

    def get(self, key: str, default: Any = None) -> Any:
        """Get a value from event data with default."""
        return self.data.get(key, default)

    def __getitem__(self, key: str) -> Any:
        """Allow dict-like access to data."""
        return self.data[key]

    def matches(self, pattern: str) -> bool:
        """
        Check if event type matches a glob pattern.

        Patterns:
            "agent.*" - matches agent.thinking, agent.responded, etc.
            "*.error" - matches agent.error, tool.error, etc.
            "*" - matches everything
            "agent.thinking" - exact match

        Args:
            pattern: Glob pattern to match against

        Returns:
            True if event type matches pattern
        """
        import fnmatch

        return fnmatch.fnmatch(self.type, pattern)


@dataclass(frozen=True, slots=True)
class EventSchema:
    """Documents the stable payload contract for a built-in event type."""

    required_fields: frozenset[str]
    optional_fields: frozenset[str] = field(default_factory=frozenset)


def create_event(
    event_type: str,
    *,
    source: str = "system",
    correlation_id: str | None = None,
    timestamp: datetime | None = None,
    **data: Any,
) -> Event:
    """
    Create an event with the given type and data.

    Factory function that provides a cleaner API than the dataclass constructor.

    Args:
        event_type: Event type string (e.g., "agent.thinking")
        source: Origin of the event
        correlation_id: ID for correlating related events
        timestamp: Event timestamp (defaults to now)
        **data: Event payload as keyword arguments

    Returns:
        New Event instance

    Example:
        ```python
        event = create_event(
            "tool.called",
            source="Researcher",
            tool_name="web_search",
            args={"query": "python tutorials"},
        )
        ```
    """
    return Event(
        type=event_type,
        data=data,
        timestamp=timestamp or now_utc(),
        source=source,
        correlation_id=correlation_id,
    )


# Common event type constants (for convenience, not required)
class EventTypes:
    """
    Common built-in event type strings.

    These constants document the event names emitted by Cogent's built-in
    runtime components today. They are provided for convenience and IDE
    autocomplete, but event types remain open strings so applications can
    define their own namespaced custom events.
    """

    # Agent events
    AGENT_INVOKED = "agent.invoked"
    AGENT_THINKING = "agent.thinking"
    AGENT_REASONING = "agent.reasoning"
    AGENT_ACTING = "agent.acting"
    AGENT_RESPONDED = "agent.responded"
    AGENT_ERROR = "agent.error"
    AGENT_STATUS_CHANGED = "agent.status_changed"

    # Tool events
    TOOL_CALLED = "tool.called"
    TOOL_RESULT = "tool.result"
    TOOL_ERROR = "tool.error"
    TOOL_WAITING = "tool.waiting"
    TOOL_SUSPENDED = "tool.suspended"

    # Subagent events
    SUBAGENT_CALLED = "subagent.called"
    SUBAGENT_RESULT = "subagent.result"
    SUBAGENT_ERROR = "subagent.error"

    # Task events
    TASK_STARTED = "task.started"
    TASK_COMPLETED = "task.completed"
    TASK_FAILED = "task.failed"

    # Output events
    OUTPUT_GENERATED = "output.generated"

    # Stream events
    STREAM_START = "stream.start"
    STREAM_TOKEN = "stream.token"
    STREAM_END = "stream.end"
    STREAM_ERROR = "stream.error"
    STREAM_TOOL_CALL = "stream.tool_call"

    # LLM events
    LLM_REQUEST = "llm.request"
    LLM_RESPONSE = "llm.response"
    LLM_THINKING = "llm.thinking"
    LLM_TOOL_DECISION = "llm.tool_decision"

    # Memory events
    MEMORY_READ = "memory.read"
    MEMORY_WRITE = "memory.write"
    MEMORY_SEARCH = "memory.search"
    MEMORY_DELETE = "memory.delete"
    MEMORY_CLEAR = "memory.clear"
    MEMORY_CONVERSATION_LOADED = "memory.conversation.loaded"
    MEMORY_CONVERSATION_SAVED = "memory.conversation.saved"
    MEMORY_ACC_CONTEXT_FORMATTED = "memory.acc.context_formatted"
    MEMORY_ACC_UPDATED = "memory.acc.updated"
    MEMORY_CACHE_HIT = "memory.cache.hit"
    MEMORY_CACHE_MISS = "memory.cache.miss"
    MEMORY_CACHE_WRITE = "memory.cache.write"

    # Retrieval events
    RETRIEVAL_START = "retrieval.start"
    RETRIEVAL_COMPLETE = "retrieval.complete"
    RETRIEVAL_ERROR = "retrieval.error"
    RETRIEVAL_SUMMARY_INDEX_START = "retrieval.summary_index.start"
    RETRIEVAL_SUMMARY_INDEX_DOCUMENT_SUMMARIZED = (
        "retrieval.summary_index.document_summarized"
    )
    RETRIEVAL_SUMMARY_INDEX_COMPLETE = "retrieval.summary_index.complete"
    RETRIEVAL_SUMMARY_INDEX_ERROR = "retrieval.summary_index.error"

    # MCP events
    MCP_SERVER_CONNECTING = "mcp.server.connecting"
    MCP_SERVER_CONNECTED = "mcp.server.connected"
    MCP_SERVER_DISCONNECTED = "mcp.server.disconnected"
    MCP_SERVER_ERROR = "mcp.server.error"
    MCP_TOOLS_DISCOVERED = "mcp.tools.discovered"
    MCP_TOOL_CALLED = "mcp.tool.called"
    MCP_TOOL_RESULT = "mcp.tool.result"
    MCP_TOOL_ERROR = "mcp.tool.error"


BUILT_IN_EVENT_SCHEMAS: dict[str, EventSchema] = {
    EventTypes.AGENT_INVOKED: EventSchema(
        required_fields=frozenset({"agent", "agent_name", "task", "run_id", "step_id"}),
        optional_fields=frozenset({"parent_run_id"}),
    ),
    EventTypes.AGENT_THINKING: EventSchema(
        required_fields=frozenset(
            {"agent", "agent_name", "iteration", "run_id", "step_id"}
        ),
        optional_fields=frozenset({"message", "parent_run_id"}),
    ),
    EventTypes.LLM_REQUEST: EventSchema(
        required_fields=frozenset(
            {
                "agent_name",
                "model",
                "messages",
                "message_count",
                "tools_available",
                "prompt",
                "iteration",
                "run_id",
                "step_id",
            }
        ),
        optional_fields=frozenset({"system_prompt", "parent_run_id"}),
    ),
    EventTypes.LLM_RESPONSE: EventSchema(
        required_fields=frozenset(
            {
                "agent_name",
                "iteration",
                "content",
                "content_length",
                "tool_calls",
                "has_tool_calls",
                "finish_reason",
                "duration_ms",
                "tokens",
                "run_id",
                "step_id",
            }
        ),
        optional_fields=frozenset(
            {"thinking_preview", "thinking_length", "parent_run_id"}
        ),
    ),
    EventTypes.LLM_TOOL_DECISION: EventSchema(
        required_fields=frozenset(
            {
                "agent_name",
                "iteration",
                "tools_selected",
                "subagents_selected",
                "regular_tools_selected",
                "reasoning",
                "run_id",
                "step_id",
            }
        ),
        optional_fields=frozenset({"parent_run_id"}),
    ),
    EventTypes.TOOL_CALLED: EventSchema(
        required_fields=frozenset(
            {
                "agent",
                "agent_name",
                "tool",
                "tool_name",
                "call_id",
                "tool_call_id",
                "args",
                "is_subagent",
                "run_id",
                "step_id",
            }
        ),
        optional_fields=frozenset({"parent_run_id"}),
    ),
    EventTypes.TOOL_RESULT: EventSchema(
        required_fields=frozenset(
            {
                "agent",
                "agent_name",
                "tool",
                "tool_name",
                "call_id",
                "tool_call_id",
                "result",
                "is_subagent",
                "run_id",
                "step_id",
            }
        ),
        optional_fields=frozenset({"parent_run_id"}),
    ),
    EventTypes.TOOL_SUSPENDED: EventSchema(
        required_fields=frozenset(
            {
                "agent",
                "agent_name",
                "tool",
                "tool_name",
                "call_id",
                "callback_id",
                "message",
                "run_id",
                "step_id",
            }
        ),
        optional_fields=frozenset({"duration_ms", "parent_run_id"}),
    ),
    EventTypes.TOOL_WAITING: EventSchema(
        required_fields=frozenset(
            {
                "agent",
                "agent_name",
                "tool",
                "tool_name",
                "call_id",
                "callback_id",
                "message",
                "run_id",
                "step_id",
            }
        ),
        optional_fields=frozenset({"timeout", "interval", "parent_run_id"}),
    ),
    EventTypes.SUBAGENT_CALLED: EventSchema(
        required_fields=frozenset(
            {
                "agent",
                "agent_name",
                "subagent",
                "subagent_name",
                "call_id",
                "tool_call_id",
                "args",
                "run_id",
                "step_id",
            }
        ),
        optional_fields=frozenset({"task", "parent_run_id"}),
    ),
    EventTypes.SUBAGENT_RESULT: EventSchema(
        required_fields=frozenset(
            {
                "agent",
                "agent_name",
                "subagent",
                "subagent_name",
                "call_id",
                "tool_call_id",
                "result",
                "run_id",
                "step_id",
            }
        ),
        optional_fields=frozenset({"subagent_run_id", "parent_run_id"}),
    ),
    EventTypes.SUBAGENT_ERROR: EventSchema(
        required_fields=frozenset(
            {
                "agent",
                "agent_name",
                "subagent",
                "subagent_name",
                "call_id",
                "tool_call_id",
                "error",
                "run_id",
                "step_id",
            }
        ),
        optional_fields=frozenset({"subagent_run_id", "parent_run_id"}),
    ),
    EventTypes.OUTPUT_GENERATED: EventSchema(
        required_fields=frozenset(
            {
                "agent",
                "agent_name",
                "output",
                "content",
                "duration_ms",
                "run_id",
                "step_id",
            }
        ),
        optional_fields=frozenset({"limited", "parent_run_id"}),
    ),
    EventTypes.AGENT_RESPONDED: EventSchema(
        required_fields=frozenset(
            {"agent_id", "agent_name", "response", "duration_ms", "run_id", "step_id"}
        ),
        optional_fields=frozenset(
            {
                "response_preview",
                "tokens",
                "tool_calls_count",
                "tool_calls",
                "success",
                "correlation_id",
                "parent_run_id",
            }
        ),
    ),
    EventTypes.MEMORY_CONVERSATION_LOADED: EventSchema(
        required_fields=frozenset(
            {
                "agent_id",
                "agent_name",
                "thread_id",
                "mode",
                "message_count",
                "run_id",
                "step_id",
            }
        ),
        optional_fields=frozenset({"parent_run_id"}),
    ),
    EventTypes.MEMORY_CONVERSATION_SAVED: EventSchema(
        required_fields=frozenset(
            {
                "agent_id",
                "agent_name",
                "thread_id",
                "mode",
                "run_id",
                "step_id",
            }
        ),
        optional_fields=frozenset({"tool_calls_count", "parent_run_id"}),
    ),
    EventTypes.MEMORY_ACC_CONTEXT_FORMATTED: EventSchema(
        required_fields=frozenset(
            {
                "agent_id",
                "agent_name",
                "thread_id",
                "has_context",
                "context_chars",
                "run_id",
                "step_id",
            }
        ),
        optional_fields=frozenset({"acc_stats", "parent_run_id"}),
    ),
    EventTypes.MEMORY_ACC_UPDATED: EventSchema(
        required_fields=frozenset(
            {
                "agent_id",
                "agent_name",
                "thread_id",
                "tool_calls_count",
                "run_id",
                "step_id",
            }
        ),
        optional_fields=frozenset({"acc_stats", "parent_run_id"}),
    ),
    EventTypes.MEMORY_CACHE_HIT: EventSchema(
        required_fields=frozenset(
            {
                "agent_id",
                "agent_name",
                "tool_name",
                "cache_key_hash",
                "run_id",
                "step_id",
            }
        ),
        optional_fields=frozenset({"parent_run_id"}),
    ),
    EventTypes.MEMORY_CACHE_MISS: EventSchema(
        required_fields=frozenset(
            {
                "agent_id",
                "agent_name",
                "tool_name",
                "cache_key_hash",
                "run_id",
                "step_id",
            }
        ),
        optional_fields=frozenset({"parent_run_id"}),
    ),
    EventTypes.MEMORY_CACHE_WRITE: EventSchema(
        required_fields=frozenset(
            {
                "agent_id",
                "agent_name",
                "tool_name",
                "cache_key_hash",
                "artifact_type",
                "run_id",
                "step_id",
            }
        ),
        optional_fields=frozenset({"parent_run_id"}),
    ),
}
