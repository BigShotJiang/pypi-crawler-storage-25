"""Episodic memory backed by a knowledge graph.

Gives agents structured memory across turns and sessions.  An *episode*
captures a sequence of observations (user messages, tool results,
reflections) as graph entities linked by temporal edges.  Semantic
entities (facts, preferences) extracted along the way form a persistent
semantic layer that is shared across episodes.

Inspired by AriGraph (arXiv:2407.04363).

Typical usage::

    from cogent.graph import Graph
    from cogent.memory.episodic import EpisodicMemory

    graph = Graph()
    episodic = EpisodicMemory(graph)

    ep = await episodic.start_episode(agent="assistant", thread_id="t-1")
    await episodic.add_observation(ep.id, "User asked about Python async.")
    await episodic.add_observation(ep.id, "Explained asyncio event loop.")
    await episodic.close_episode(ep.id, outcome="success")

    # Later — recall relevant episodes
    results = await episodic.recall("async programming", top_k=3)
"""

from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from cogent.graph.graph import Graph


# ---------------------------------------------------------------------------
# Data models
# ---------------------------------------------------------------------------


@dataclass(slots=True)
class Episode:
    """A bounded sequence of observations forming one coherent interaction.

    Attributes:
        id: Unique episode identifier.
        agent: Name of the agent that owns this episode.
        thread_id: Conversation thread this episode belongs to.
        user_id: Identifier for the user this episode belongs to. When set,
            recall and list operations can filter by user to enforce privacy
            boundaries in multi-user deployments.
        started_at: When the episode began.
        closed_at: When the episode ended (``None`` while open).
        outcome: Free-text result label set on close (e.g. "success", "error").
        metadata: Arbitrary key-value data.
    """

    id: str
    agent: str
    thread_id: str | None = None
    user_id: str | None = None
    started_at: datetime = field(default_factory=lambda: datetime.now(UTC))
    closed_at: datetime | None = None
    outcome: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)

    @property
    def is_open(self) -> bool:
        return self.closed_at is None


@dataclass(slots=True)
class Observation:
    """A single event recorded inside an episode.

    Attributes:
        id: Unique observation identifier.
        episode_id: Parent episode.
        content: Free-text content (user message, tool output, reflection …).
        kind: Category tag — ``"user"``, ``"assistant"``, ``"tool"``, ``"reflection"``.
        timestamp: When the observation was recorded.
        metadata: Arbitrary key-value data.
    """

    id: str
    episode_id: str
    content: str
    kind: str = "observation"
    timestamp: datetime = field(default_factory=lambda: datetime.now(UTC))
    metadata: dict[str, Any] = field(default_factory=dict)


# ---------------------------------------------------------------------------
# Constants — entity types and relation labels used inside the graph
# ---------------------------------------------------------------------------

_EPISODE_TYPE = "Episode"
_OBSERVATION_TYPE = "Observation"

_NEXT_OBS = "NEXT"  # Temporal link between successive observations
_OBSERVED_IN = "OBSERVED_IN"  # Observation → Episode
_MENTIONS = "MENTIONS"  # Observation → semantic entity
_FOLLOWED_BY = "FOLLOWED_BY"  # Episode → Episode (within a thread)


# ---------------------------------------------------------------------------
# EpisodicMemory
# ---------------------------------------------------------------------------


class EpisodicMemory:
    """Graph-backed episodic memory for agents.

    Maintains two interleaved layers inside a single :class:`Graph`:

    * **Episodic layer** — episodes and temporally ordered observations.
    * **Semantic layer** — long-lived entities (facts, concepts, people …)
      extracted from observations and linked via ``MENTIONS`` edges.

    The semantic layer is whatever the caller (or an LLM extraction step)
    adds with :meth:`link_entity`.  EpisodicMemory does **not** call an
    LLM itself — it provides the structural scaffolding that an agent or
    pipeline can drive.

    Args:
        graph: Optional knowledge graph. Defaults to ``Graph()`` (NetworkX
            engine, in-memory storage). Pass a custom graph for persistent
            storage or a shared graph with other components.
    """

    def __init__(self, graph: Graph | None = None) -> None:
        if graph is None:
            from cogent.graph.graph import Graph as _Graph

            graph = _Graph()
        self._graph = graph
        self._open_episodes: dict[str, Episode] = {}
        # Track last observation per episode for temporal chaining
        self._last_obs: dict[str, str] = {}
        # Track last episode per thread for FOLLOWED_BY chaining
        self._last_episode: dict[str, str] = {}

    @property
    def graph(self) -> Graph:
        return self._graph

    # ----- episode lifecycle ------------------------------------------------

    async def start_episode(
        self,
        agent: str,
        thread_id: str | None = None,
        *,
        user_id: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> Episode:
        """Begin a new episode.

        Args:
            agent: Owning agent name.
            thread_id: Optional thread / conversation ID.
            user_id: Optional user identifier for privacy isolation.
            metadata: Extra data stored on the episode entity.

        Returns:
            The newly created :class:`Episode`.
        """
        ep = Episode(
            id=f"ep_{uuid.uuid4().hex[:12]}",
            agent=agent,
            thread_id=thread_id,
            user_id=user_id,
            metadata=metadata or {},
        )

        await self._graph.add_entity(
            ep.id,
            _EPISODE_TYPE,
            agent=ep.agent,
            thread_id=ep.thread_id or "",
            user_id=ep.user_id or "",
            started_at=ep.started_at.isoformat(),
            outcome="",
            **ep.metadata,
        )

        # Chain to previous episode in the same thread
        if thread_id and thread_id in self._last_episode:
            prev_id = self._last_episode[thread_id]
            await self._graph.add_relationship(prev_id, _FOLLOWED_BY, ep.id)

        if thread_id:
            self._last_episode[thread_id] = ep.id

        self._open_episodes[ep.id] = ep
        return ep

    async def close_episode(
        self,
        episode_id: str,
        *,
        outcome: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> Episode:
        """Close an open episode.

        Args:
            episode_id: ID of the episode to close.
            outcome: Free-text description of the episode result.
            metadata: Extra metadata to merge.

        Returns:
            The closed :class:`Episode`.

        Raises:
            KeyError: If the episode is not open.
        """
        ep = self._open_episodes.pop(episode_id, None)
        if ep is None:
            raise KeyError(f"No open episode with id {episode_id!r}")

        ep.closed_at = datetime.now(UTC)
        ep.outcome = outcome

        if metadata:
            ep.metadata.update(metadata)

        # Update graph entity attributes
        entity = await self._graph.get_entity(episode_id)
        if entity:
            entity.update_attributes(
                closed_at=ep.closed_at.isoformat(),
                outcome=outcome or "",
                **ep.metadata,
            )

        # Clean up temporal tracking
        self._last_obs.pop(episode_id, None)
        return ep

    # ----- observations -----------------------------------------------------

    async def add_observation(
        self,
        episode_id: str,
        content: str,
        *,
        kind: str = "observation",
        metadata: dict[str, Any] | None = None,
    ) -> Observation:
        """Record an observation inside an open episode.

        Observations are chained with temporal ``NEXT`` edges and linked to
        their parent episode via ``OBSERVED_IN``.

        Args:
            episode_id: Parent episode (must be open).
            content: Free-text event content.
            kind: Category — ``"user"``, ``"assistant"``, ``"tool"``, ``"reflection"``.
            metadata: Extra data.

        Returns:
            The created :class:`Observation`.

        Raises:
            KeyError: If the episode is not open.
        """
        if episode_id not in self._open_episodes:
            raise KeyError(f"No open episode with id {episode_id!r}")

        obs = Observation(
            id=f"obs_{uuid.uuid4().hex[:12]}",
            episode_id=episode_id,
            content=content,
            kind=kind,
            metadata=metadata or {},
        )

        await self._graph.add_entity(
            obs.id,
            _OBSERVATION_TYPE,
            episode_id=episode_id,
            content=content,
            kind=kind,
            timestamp=obs.timestamp.isoformat(),
            **(metadata or {}),
        )

        # Link observation → episode
        await self._graph.add_relationship(obs.id, _OBSERVED_IN, episode_id)

        # Chain to previous observation (temporal ordering)
        prev_obs_id = self._last_obs.get(episode_id)
        if prev_obs_id is not None:
            await self._graph.add_relationship(prev_obs_id, _NEXT_OBS, obs.id)

        self._last_obs[episode_id] = obs.id
        return obs

    # ----- semantic linking -------------------------------------------------

    async def link_entity(
        self,
        observation_id: str,
        entity_id: str,
    ) -> None:
        """Link an observation to a semantic entity already in the graph.

        Creates a ``MENTIONS`` edge from the observation to the entity.
        The entity must already exist (add it via ``graph.add_entity``).

        Args:
            observation_id: The observation doing the mentioning.
            entity_id: The semantic entity being referenced.

        Raises:
            ValueError: If either node does not exist in the graph.
        """
        obs = await self._graph.get_entity(observation_id)
        target = await self._graph.get_entity(entity_id)
        if obs is None:
            raise ValueError(f"Observation {observation_id!r} not found in graph")
        if target is None:
            raise ValueError(f"Entity {entity_id!r} not found in graph")

        await self._graph.add_relationship(observation_id, _MENTIONS, entity_id)

    # ----- convenience: record a full turn -----------------------------------

    async def record_turn(
        self,
        episode_id: str,
        user_message: str,
        assistant_message: str,
        *,
        tool_calls: list[dict[str, Any]] | list[Any] | None = None,
    ) -> list[Observation]:
        """Record a complete user→assistant turn (with optional tool calls).

        Convenience wrapper over :meth:`add_observation` that creates one
        observation per logical event in the turn.

        Args:
            episode_id: Parent episode (must be open).
            user_message: The user's input.
            assistant_message: The assistant's response.
            tool_calls: Optional tool call data.  Accepts plain
                ``{"name": ..., "args": ...}`` dicts **or**
                :class:`~cogent.core.response.ToolCall` objects.  When
                ``ToolCall`` objects are provided, outcome metadata
                (result preview, duration, success, error) is included
                in the observation.

        Returns:
            The observations created (in temporal order).
        """
        observations: list[Observation] = []
        observations.append(
            await self.add_observation(episode_id, user_message, kind="user")
        )
        if tool_calls:
            for tc in tool_calls:
                summary, meta = self._format_tool_observation(tc)
                observations.append(
                    await self.add_observation(
                        episode_id, summary, kind="tool", metadata=meta
                    )
                )
        observations.append(
            await self.add_observation(episode_id, assistant_message, kind="assistant")
        )
        return observations

    @staticmethod
    def _format_tool_observation(tc: Any) -> tuple[str, dict[str, Any]]:
        """Build observation content and metadata from a tool call.

        Handles both plain dicts and :class:`~cogent.core.response.ToolCall`
        dataclass instances.
        """
        # --- Rich ToolCall object (has .tool_name, .success, etc.) ---
        if hasattr(tc, "tool_name") and hasattr(tc, "success"):
            name = tc.tool_name
            args = getattr(tc, "arguments", {})
            duration_ms = round(getattr(tc, "duration", 0) * 1000)

            if tc.success:
                result_str = str(getattr(tc, "result", ""))
                preview = result_str[:120] + ("…" if len(result_str) > 120 else "")
                summary = f"tool:{name}({args}) → OK {duration_ms}ms {preview}"
            else:
                error = getattr(tc, "error", None) or "unknown error"
                summary = f"tool:{name}({args}) → FAILED {duration_ms}ms {error}"

            meta: dict[str, Any] = {
                "name": name,
                "args": args,
                "success": tc.success,
                "duration_ms": duration_ms,
            }
            if tc.success:
                result_str = str(getattr(tc, "result", ""))
                meta["result_preview"] = result_str[:500]
            else:
                meta["error"] = getattr(tc, "error", None)
            return summary, meta

        # --- Plain dict (legacy / manual calls) ---
        name = tc.get("name", "?")
        args = tc.get("args", {})
        summary = f"tool:{name}({args})"
        return summary, dict(tc)

    # ----- recall -----------------------------------------------------------

    async def get_episode(self, episode_id: str) -> Episode | None:
        """Retrieve an episode by ID (from graph, not just open cache)."""
        entity = await self._graph.get_entity(episode_id)
        if entity is None or entity.entity_type != _EPISODE_TYPE:
            return None
        return _entity_to_episode(entity)

    async def get_observations(self, episode_id: str) -> list[Observation]:
        """Get all observations for an episode in temporal order.

        Args:
            episode_id: The episode to query.

        Returns:
            Observations sorted by timestamp.
        """
        rels = await self._graph.get_relationships(
            target_id=episode_id, relation=_OBSERVED_IN
        )
        observations: list[Observation] = []
        for rel in rels:
            entity = await self._graph.get_entity(rel.source_id)
            if entity and entity.entity_type == _OBSERVATION_TYPE:
                observations.append(_entity_to_observation(entity))

        observations.sort(key=lambda o: o.timestamp)
        return observations

    async def list_episodes(
        self,
        agent: str | None = None,
        thread_id: str | None = None,
        *,
        user_id: str | None = None,
        limit: int | None = None,
    ) -> list[Episode]:
        """List episodes, optionally filtered by agent, thread, or user.

        Args:
            agent: Filter by agent name.
            thread_id: Filter by thread ID.
            user_id: Filter by user ID.
            limit: Maximum episodes to return (most recent first).

        Returns:
            Episodes sorted most-recent-first.
        """
        entities = await self._graph.get_all_entities()
        episodes: list[Episode] = []
        for e in entities:
            if e.entity_type != _EPISODE_TYPE:
                continue
            if agent and e.attributes.get("agent") != agent:
                continue
            if thread_id and e.attributes.get("thread_id") != thread_id:
                continue
            if user_id and e.attributes.get("user_id") != user_id:
                continue
            episodes.append(_entity_to_episode(e))

        episodes.sort(key=lambda ep: ep.started_at, reverse=True)
        if limit:
            episodes = episodes[:limit]
        return episodes

    async def recall(
        self,
        query: str,
        *,
        top_k: int = 5,
        agent: str | None = None,
        thread_id: str | None = None,
        user_id: str | None = None,
    ) -> list[Observation]:
        """Recall observations relevant to a query using PPR when available.

        Strategy:

        1. Find observation entities whose ``content`` attribute contains
           any of the query terms (simple keyword overlap).
        2. If the graph engine supports PPR, run :meth:`Graph.personalized_pagerank`
           seeded from those observations and collect the highest-scoring
           observation nodes.
        3. Fall back to keyword matches sorted by recency when PPR is
           unavailable or no seeds are found.

        Results are optionally filtered by *agent* / *thread_id* / *user_id*
        (via the parent episode).

        Args:
            query: Free-text recall query.
            top_k: Maximum observations to return.
            agent: Only return observations from episodes by this agent.
            thread_id: Only return observations from this thread.
            user_id: Only return observations from episodes owned by this user.

        Returns:
            Relevant observations sorted by score (descending) then recency.
        """
        # Step 1 — keyword seed discovery
        query_terms = {t.lower() for t in query.split() if len(t) >= 3}
        all_entities = await self._graph.get_all_entities()

        seeds: list[str] = []
        obs_entities: dict[str, Any] = {}
        for e in all_entities:
            if e.entity_type != _OBSERVATION_TYPE:
                continue
            obs_entities[e.id] = e
            content = str(e.attributes.get("content", "")).lower()
            if any(term in content for term in query_terms):
                seeds.append(e.id)

        if not obs_entities:
            return []

        # Step 2 — PPR expansion (if supported and we have seeds)
        ranked_ids: list[str]
        if seeds and hasattr(self._graph.engine, "personalized_pagerank"):
            scores = self._graph.personalized_pagerank(seeds, top_k=None)
            # Keep only observation nodes
            scored_obs = {
                nid: score for nid, score in scores.items() if nid in obs_entities
            }
            ranked_ids = sorted(scored_obs, key=scored_obs.get, reverse=True)  # type: ignore[arg-type]
        else:
            # Fallback: keyword matches sorted by timestamp descending
            ranked_ids = sorted(
                seeds or list(obs_entities.keys()),
                key=lambda nid: str(obs_entities[nid].attributes.get("timestamp", "")),
                reverse=True,
            )

        # Step 3 — optional agent / thread / user filtering
        if agent or thread_id or user_id:
            # Build episode lookup for filtering
            ep_lookup: dict[str, Any] = {}
            for e in all_entities:
                if e.entity_type == _EPISODE_TYPE:
                    ep_lookup[e.id] = e

            filtered: list[str] = []
            for nid in ranked_ids:
                ep_id = obs_entities[nid].attributes.get("episode_id")
                if ep_id and ep_id in ep_lookup:
                    ep_ent = ep_lookup[ep_id]
                    if agent and ep_ent.attributes.get("agent") != agent:
                        continue
                    if thread_id and ep_ent.attributes.get("thread_id") != thread_id:
                        continue
                    if user_id and ep_ent.attributes.get("user_id") != user_id:
                        continue
                filtered.append(nid)
            ranked_ids = filtered

        results = [
            _entity_to_observation(obs_entities[nid]) for nid in ranked_ids[:top_k]
        ]
        return results

    # ----- reflection -------------------------------------------------------

    async def reflect(
        self,
        model: Any,
        *,
        episode_id: str | None = None,
        agent: str | None = None,
        thread_id: str | None = None,
        max_observations: int = 20,
    ) -> list[Observation]:
        """Synthesize recent observations into higher-level lessons.

        Reads observations from a specific episode or across recent episodes,
        asks an LLM to identify patterns and lessons, and stores each lesson
        as an :class:`Observation` with ``kind="reflection"`` in the episodic
        graph.

        Inspired by the *reflection* step in Generative Agents (Park et al.,
        2023) and the *learning actions* concept from CoALA (Sumers et al.,
        2024).

        Args:
            model: A ``BaseChatModel`` instance (with ``with_structured_output``
                and ``ainvoke`` support).  Typically the agent's own model.
            episode_id: Reflect on observations from this specific episode.
                When omitted, gathers observations across recent episodes
                filtered by *agent* and/or *thread_id*.
            agent: Filter observations by agent name (used when *episode_id*
                is not provided).
            thread_id: Filter observations by thread (used when *episode_id*
                is not provided).
            max_observations: Maximum observations to feed the LLM.

        Returns:
            Reflection observations created (one per lesson), stored in the
            episodic graph under the given *episode_id* (or the most recent
            matching episode).

        Raises:
            ValueError: If no observations are found to reflect on.
        """
        # --- gather observations ---
        if episode_id:
            observations = await self.get_observations(episode_id)
        else:
            observations = await self._gather_recent_observations(
                agent=agent, thread_id=thread_id, limit=max_observations
            )

        if not observations:
            raise ValueError("No observations found to reflect on.")

        observations = observations[-max_observations:]

        # Determine target episode for storing reflections
        target_episode_id = episode_id or observations[-1].episode_id

        # --- format for LLM ---
        obs_lines = []
        for obs in observations:
            prefix = obs.kind.upper()
            obs_lines.append(f"[{prefix}] {obs.content}")
        observations_text = "\n".join(obs_lines)

        prompt = _REFLECTION_PROMPT.format(
            observations=observations_text,
            count=len(observations),
        )

        # --- LLM call ---
        from pydantic import BaseModel, Field

        class ReflectionOutput(BaseModel):
            """Lessons distilled from recent agent observations."""

            lessons: list[str] = Field(
                description=(
                    "Concise, actionable lessons or patterns observed. "
                    "Each lesson should be a single statement."
                ),
                min_length=1,
            )

        try:
            result = await model.with_structured_output(ReflectionOutput).ainvoke(
                prompt
            )
            lessons = result.lessons
        except Exception:
            # Fallback: plain text response, split by newlines
            response = await model.ainvoke(prompt)
            content = (
                response.content if hasattr(response, "content") else str(response)
            )
            lessons = [
                line.lstrip("0123456789.-) ").strip()
                for line in content.strip().splitlines()
                if line.strip() and not line.strip().startswith("#")
            ]

        if not lessons:
            return []

        # --- store as reflection observations ---
        reflections: list[Observation] = []
        for lesson in lessons:
            obs = await self.add_observation(
                target_episode_id,
                lesson,
                kind="reflection",
                metadata={"source_observations": len(observations)},
            )
            reflections.append(obs)

        return reflections

    async def _gather_recent_observations(
        self,
        *,
        agent: str | None = None,
        thread_id: str | None = None,
        limit: int = 20,
    ) -> list[Observation]:
        """Collect observations across recent episodes."""
        episodes = await self.list_episodes(agent=agent, thread_id=thread_id, limit=5)
        observations: list[Observation] = []
        for ep in reversed(episodes):  # oldest first
            obs_list = await self.get_observations(ep.id)
            observations.extend(obs_list)
            if len(observations) >= limit:
                break
        return observations[:limit]


_REFLECTION_PROMPT = """You are analyzing {count} observations from an AI agent's recent interactions.

{observations}

Based on these observations, identify the most important patterns, lessons, and insights. Focus on:

1. Recurring patterns or user preferences
2. What approaches worked well or failed
3. Tool effectiveness — which tools succeeded and which struggled
4. Knowledge the agent should carry forward to future interactions

Provide concise, actionable lessons. Each lesson should be a single clear statement that would help the agent perform better in future interactions. Aim for 3-5 lessons."""


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _entity_to_episode(entity: Any) -> Episode:
    attrs = entity.attributes
    closed_str = attrs.get("closed_at", "")
    closed_at = datetime.fromisoformat(closed_str) if closed_str else None
    started_str = attrs.get("started_at", "")
    started_at = (
        datetime.fromisoformat(started_str) if started_str else entity.created_at
    )
    extra_keys = {
        "agent",
        "thread_id",
        "user_id",
        "started_at",
        "closed_at",
        "outcome",
    }
    metadata = {k: v for k, v in attrs.items() if k not in extra_keys}
    return Episode(
        id=entity.id,
        agent=attrs.get("agent", ""),
        thread_id=attrs.get("thread_id") or None,
        user_id=attrs.get("user_id") or None,
        started_at=started_at,
        closed_at=closed_at,
        outcome=attrs.get("outcome") or None,
        metadata=metadata,
    )


def _entity_to_observation(entity: Any) -> Observation:
    attrs = entity.attributes
    ts_str = attrs.get("timestamp", "")
    timestamp = datetime.fromisoformat(ts_str) if ts_str else entity.created_at
    extra_keys = {"episode_id", "content", "kind", "timestamp"}
    metadata = {k: v for k, v in attrs.items() if k not in extra_keys}
    return Observation(
        id=entity.id,
        episode_id=attrs.get("episode_id", ""),
        content=attrs.get("content", ""),
        kind=attrs.get("kind", "observation"),
        timestamp=timestamp,
        metadata=metadata,
    )
