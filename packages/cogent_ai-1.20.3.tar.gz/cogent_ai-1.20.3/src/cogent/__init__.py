# Suppress Pydantic V1 compatibility warning on Python 3.13+
import warnings

warnings.filterwarnings(
    "ignore",
    message="Core Pydantic V1 functionality",
    category=UserWarning,
)

"""
Cogent - Production Agent Framework
=========================================

A lightweight, single-agent-first framework with:
- Tool-augmented agent execution (research shows tools > multi-agent)
- Intelligent resilience (retry, circuit breakers, fallbacks)
- Native model support for OpenAI, Azure, Anthropic, Groq, Gemini, Ollama
- Full observability (tracing, metrics, progress tracking)
- Native multi-agent coordination via subagents= for delegation

Quick Start:
    ```python
    from cogent import Agent, tool

    @tool
    def search(query: str) -> str:
        '''Search the web.'''
        return f"Results for {query}"

    agent = Agent(
        name="Assistant",
        model="gpt-4o-mini",
        tools=[search],
    )

    result = await agent.run("Search for Python tutorials")
    ```

Native Models:
    ```python
    from cogent.models.openai import OpenAIChat
    from cogent.models.azure import AzureOpenAIChat
    from cogent.models.anthropic import AnthropicChat
    from cogent.models import create_chat, create_embedding

    # Direct usage
    llm = OpenAIChat(model="gpt-5.4")
    response = await llm.ainvoke([{"role": "user", "content": "Hello!"}])

    # Factory function
    llm = create_chat("anthropic", model="claude-sonnet-4-20250514")

    # Azure with Managed Identity (Entra ID)
    from cogent.models.azure import AzureEntraAuth
    llm = AzureOpenAIChat(
        deployment="gpt-4o",
        azure_endpoint="https://my-resource.openai.azure.com",
        entra=AzureEntraAuth(method="managed_identity"),
    )
    ```

Multi-Agent Coordination:
    ```python
    # Native subagents= for delegation (preserves full metadata)
    researcher = Agent(name="Researcher", model="gpt-5.4")
    writer = Agent(
        name="Writer",
        model="gpt-5.4",
        subagents=[researcher],
    )

    # Writer can delegate to researcher as needed
    result = await writer.run("Research and write article on AI")
    ```
"""

from importlib.metadata import PackageNotFoundError
from importlib.metadata import version as _pkg_version

try:
    __version__ = _pkg_version("cogent-ai")
except PackageNotFoundError:  # running from source without install
    __version__ = "unknown"

# Core enums and utilities
# Graph API (unified visualization)
# Temporarily commented out while rebuilding graph/kg modules
# from cogent import graph

# Agents (THIS IS WHERE WE ADD VALUE)
# Backwards-compatible aliases for visualization module (commented out temporarily)
# MermaidConfig = GraphConfig
# MermaidTheme = GraphTheme
# MermaidDirection = GraphDirection
# MermaidRenderer = GraphView  # Closest equivalent
# AgentDiagram = GraphView  # Use GraphView.from_agent() instead
# TopologyDiagram = GraphView  # Use GraphView.from_topology() instead
# Capabilities (composable tools for agents)
# Document processing module
from cogent import documents
from cogent.agent.a2a import A2AAgent
from cogent.agent.a2a_server import A2AServer, serve_agent
from cogent.agent.base import Agent
from cogent.agent.config import AgentConfig
from cogent.agent.hitl import (
    AbortedException,
    DecisionRequiredException,
    DecisionType,
    GuidanceResult,
    HumanDecision,
    HumanResponse,
    InterruptedException,
    InterruptedState,
    InterruptReason,
    PendingAction,
    should_interrupt,
)
from cogent.agent.output import (
    OutputMethod,
    ResponseSchema,
    StructuredResult,
)
from cogent.agent.resilience import (
    ResilienceConfig,
    RetryPolicy,
    RetryStrategy,
    ToolResilience,
)
from cogent.agent.state import AgentState
from cogent.agent.streaming import (
    CollectorStreamCallback,
    PrintStreamCallback,
    StreamCallback,
    StreamChunk,
    StreamConfig,
    StreamEvent,
    StreamMode,
    StreamTraceType,
    ToolCallChunk,
    chunk_from_message,
    collect_stream,
    extract_tool_calls,
    print_stream,
)
from cogent.capabilities import (
    BaseCapability,
    KnowledgeGraph,
)
from cogent.core import Document, DocumentMetadata

# Context - invocation-scoped data
from cogent.core.context import EMPTY_CONTEXT, RunContext
from cogent.core.enums import (
    AgentRole,
    AgentStatus,
    Priority,
    TaskStatus,
    get_role_capabilities,
)

# Native message types (from core.messages)
from cogent.core.messages import (
    AIMessage,
    BaseMessage,
    HumanMessage,
    SystemMessage,
    ToolMessage,
)
from cogent.core.utils import generate_id, now_utc

# Execution strategies
from cogent.executors import (
    ExecutionStrategy,
    NativeExecutor,
    SequentialExecutor,
    create_executor,
    run,
)

# Temporarily commented out while rebuilding graph/kg modules
# from cogent.graph import (
#     GraphConfig,
#     GraphDirection,
#     GraphTheme,
#     GraphView,
# )
# Interceptors (execution flow control)
from cogent.interceptors import (
    AuditEvent,
    Auditor,
    AuditTraceType,
    BudgetGuard,
    ContentFilter,
    ContextCompressor,
    ContextPrompt,
    ConversationGate,
    ConversationPrompt,
    Failover,
    InterceptContext,
    Interceptor,
    InterceptResult,
    LambdaPrompt,
    PermissionGate,
    Phase,
    PIIAction,
    PIIShield,
    PromptAdapter,
    RateLimiter,
    StopExecution,
    ThrottleInterceptor,
    TokenLimiter,
    # Context Layer
    ToolGate,
    ToolGuard,
    run_interceptors,
)

# Memory components moved to cogent.memory
from cogent.memory import (
    InMemorySaver,
    MemorySnapshot,
    ThreadConfig,
)

# LLM & Embedding Models (native)
from cogent.models import (
    ChatModel,
    EmbeddingModel,
    create_chat,
    create_embedding,
)

# Provider-specific model imports for convenience
from cogent.models.azure import AzureOpenAIChat, AzureOpenAIEmbedding

# Observability (THIS IS WHERE WE ADD VALUE)
from cogent.observability import (
    AgentInspector,
    Channel,
    Colors,
    Counter,
    Dashboard,
    DashboardConfig,
    EventInspector,
    Gauge,
    Histogram,
    LogEntry,
    LogLevel,
    MetricsCollector,
    ObservabilityLevel,
    ObservabilityLogger,
    # Observer (unified observability for agents, flows, teams)
    Observer,
    # Progress & Output system
    OutputConfig,
    OutputFormat,
    ProgressEvent,
    ProgressStyle,
    ProgressTracker,
    Span,
    SpanContext,
    SpanKind,
    Styler,
    Symbols,
    SystemInspector,
    TaskInspector,
    Timer,
    Tracer,
    Verbosity,
    configure_output,
    create_executor_callback,
    create_on_step_callback,
    render_dag_ascii,
)

# Tools
from cogent.tools.base import BaseTool, tool
from cogent.tools.registry import ToolRegistry, create_tool_from_function
from cogent.tools.suspend import Suspend

# All public exports
__all__ = [
    # Version
    "__version__",
    # Core enums
    "AgentStatus",
    "TaskStatus",
    "Priority",
    "AgentRole",
    "get_role_capabilities",
    # Core utilities
    "generate_id",
    "now_utc",
    # Agents
    "Agent",
    "A2AAgent",
    "A2AServer",
    "serve_agent",
    "AgentConfig",
    "AgentState",
    # Memory (checkpointing - from cogent.memory)
    "MemorySnapshot",
    "ThreadConfig",
    "InMemorySaver",
    # Execution strategies
    "ExecutionStrategy",
    "NativeExecutor",
    "SequentialExecutor",
    "run",
    "create_executor",
    # Resilience
    "ResilienceConfig",
    "RetryPolicy",
    "RetryStrategy",
    "ToolResilience",
    # Human-in-the-Loop
    "InterruptReason",
    "DecisionType",
    "PendingAction",
    "HumanDecision",
    "InterruptedState",
    "InterruptedException",
    "DecisionRequiredException",
    "AbortedException",
    "GuidanceResult",
    "HumanResponse",
    "should_interrupt",
    # Streaming
    "StreamChunk",
    "StreamEvent",
    "StreamMode",
    "StreamTraceType",
    "StreamConfig",
    "StreamCallback",
    "PrintStreamCallback",
    "CollectorStreamCallback",
    "ToolCallChunk",
    "chunk_from_message",
    "extract_tool_calls",
    "collect_stream",
    "print_stream",
    # Structured Output
    "ResponseSchema",
    "OutputMethod",
    "StructuredResult",
    # Interceptors
    "Interceptor",
    "Phase",
    "InterceptContext",
    "InterceptResult",
    "BudgetGuard",
    "StopExecution",
    "run_interceptors",
    "ContextCompressor",
    "TokenLimiter",
    "PIIAction",
    "PIIShield",
    "ContentFilter",
    "RateLimiter",
    "ThrottleInterceptor",
    "Auditor",
    "AuditEvent",
    "AuditTraceType",
    # Context Layer
    "ToolGate",
    "PermissionGate",
    "ConversationGate",
    "Failover",
    "ToolGuard",
    "PromptAdapter",
    "ContextPrompt",
    "ConversationPrompt",
    "LambdaPrompt",
    # Context
    "RunContext",
    "EMPTY_CONTEXT",
    # Tools
    "ToolRegistry",
    "create_tool_from_function",
    "BaseTool",
    "tool",
    "Suspend",
    # Observability
    "Tracer",
    "Span",
    "SpanContext",
    "SpanKind",
    "MetricsCollector",
    "Counter",
    "Gauge",
    "Histogram",
    "Timer",
    "ObservabilityLogger",
    "LogLevel",
    "LogEntry",
    "Dashboard",
    "DashboardConfig",
    "SystemInspector",
    "AgentInspector",
    "EventInspector",
    "TaskInspector",
    # Observer (integrated observability)
    "Observer",
    "ObservabilityLevel",
    "Channel",
    # Progress & Output
    "OutputConfig",
    "Verbosity",
    "OutputFormat",
    "ProgressStyle",
    "ProgressTracker",
    "ProgressEvent",
    "Styler",
    "Colors",
    "Symbols",
    "create_on_step_callback",
    "create_executor_callback",
    "configure_output",
    "render_dag_ascii",
    # Graph API (visualization) - temporarily commented out
    # "graph",
    # "GraphView",
    # "GraphConfig",
    # "GraphTheme",
    # "GraphDirection",
    # Backwards-compatible visualization aliases
    # "MermaidConfig",
    # "MermaidRenderer",
    # "MermaidTheme",
    # "MermaidDirection",
    # "AgentDiagram",
    # "TopologyDiagram",
    # Capabilities
    "BaseCapability",
    "KnowledgeGraph",
    # LLM & Embedding Models (native)
    "ChatModel",
    "EmbeddingModel",
    "AzureOpenAIChat",
    "AzureOpenAIEmbedding",
    "create_chat",
    "create_embedding",
    # Native message types
    "BaseMessage",
    "HumanMessage",
    "AIMessage",
    "SystemMessage",
    "ToolMessage",
    # Document types (core)
    "Document",
    "DocumentMetadata",
    # Document processing module
    "documents",
]
