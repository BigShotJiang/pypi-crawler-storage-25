# Cogent Examples

Learn Cogent through hands-on examples organized by category.

---

## 🚀 Quick Start

### 1. Set Up API Keys

Cogent auto-discovers API keys from multiple sources. Choose one:

**Option A: `.env` file (recommended for development)**

```bash
# Create .env in project root
touch .env

# Add your API key(s)
echo "OPENAI_API_KEY=sk-..." >> .env
echo "ANTHROPIC_API_KEY=sk-ant-..." >> .env
echo "GEMINI_API_KEY=AIza..." >> .env
```

**Option B: Environment variables**

```bash
export OPENAI_API_KEY=sk-...
```

**Option C: Config file** (see [docs/models.md](../docs/models.md) for details)

```toml
# cogent.toml or ~/.cogent/config.toml
[models.openai]
api_key = "sk-..."
```

### 2. Run Your First Example

```bash
uv run python examples/basics/hello_world.py
```

That's it! No imports, no config files needed.

---

## 🔑 How API Key Auto-Discovery Works

Cogent automatically finds your API keys in this priority order:

| Priority | Source | Example |
|----------|--------|---------|
| 1 (highest) | Explicit parameter | `Agent(model="gpt4", api_key="sk-...")` |
| 2 | Environment variable | `OPENAI_API_KEY=sk-...` |
| 3 | `.env` file | Auto-loaded from project root |
| 4 | Project config | `cogent.toml` or `cogent.yaml` |
| 5 (lowest) | User config | `~/.cogent/config.toml` |

**Supported environment variables:**

| Provider | Variable |
|----------|----------|
| OpenAI | `OPENAI_API_KEY` |
| Anthropic | `ANTHROPIC_API_KEY` |
| Google Gemini | `GEMINI_API_KEY` or `GOOGLE_API_KEY` |
| Groq | `GROQ_API_KEY` |
| Mistral | `MISTRAL_API_KEY` |
| Cohere | `COHERE_API_KEY` |
| Azure OpenAI | `AZURE_OPENAI_API_KEY` + `AZURE_OPENAI_ENDPOINT` |
| Cloudflare | `CLOUDFLARE_API_TOKEN` + `CLOUDFLARE_ACCOUNT_ID` |
| Ollama | No key needed (local) |

📖 **Full documentation:** [docs/models.md](../docs/models.md)

---

## 🎯 Using Models in Examples

All examples use simple string-based models:

```python
from cogent import Agent

# Just use model names - keys are auto-discovered!
agent = Agent(name="Helper", model="gpt-4o-mini")
agent = Agent(name="Helper", model="claude-sonnet-4")
agent = Agent(name="Helper", model="gemini-2.5-flash")

# Or use aliases for convenience
agent = Agent(name="Helper", model="gpt4")      # → gpt-4o
agent = Agent(name="Helper", model="claude")    # → claude-sonnet-4
agent = Agent(name="Helper", model="gemini")    # → gemini-2.5-flash

# Provider prefix for explicit control
agent = Agent(name="Helper", model="groq:llama-3.1-70b")
agent = Agent(name="Helper", model="ollama:qwen2.5")
```

---

## 📁 Example Categories

### [basics/](basics/) — Start Here

Core concepts every user should know.

| Example | Description |
|---------|-------------|
| [hello_world.py](basics/hello_world.py) | Your first agent |
| [all_providers.py](basics/all_providers.py) | Test all model providers |
| [response.py](basics/response.py) | Response protocol with metadata |
| [memory.py](basics/memory.py) | Conversation memory |
| [streaming.py](basics/streaming.py) | Token-by-token streaming |
| [structured_output.py](basics/structured_output.py) | Bare types, Pydantic, TypedDict |
| [roles.py](basics/roles.py) | Agent roles (worker, supervisor) |

---

### [capabilities/](capabilities/) — Agent Tools

Pre-built tools that give agents superpowers.

| Example | Description |
|---------|-------------|
| [filesystem.py](capabilities/filesystem.py) | Read/write files safely |
| [web_search.py](capabilities/web_search.py) | Search the web |
| [code_sandbox.py](capabilities/code_sandbox.py) | Execute code safely |
| [browser.py](capabilities/browser.py) | Web browsing (Playwright) |
| [shell.py](capabilities/shell.py) | Shell command execution |
| [knowledge_graph.py](capabilities/knowledge_graph.py) | Graph-based knowledge |
| [kg_agent_viz.py](capabilities/kg_agent_viz.py) | KG extraction + visualization |

---

### [mcp/](mcp/) — Model Context Protocol

Connect agents to local and remote MCP tool servers.

| Example | Description |
|---------|-------------|
| [mcp_example.py](mcp/mcp_example.py) | stdio, HTTP/SSE, and WebSocket transports |

Support files in `mcp/_servers/`: MCP server implementations used by the examples.

---

### [subagent/](subagent/) — Local Agent Delegation

Coordinate multiple local agents and delegate tasks between them.

| Example | Description |
|---------|-------------|
| [simple_delegation.py](subagent/simple_delegation.py) | Basic coordinator with local specialists |

---

### [a2a/](a2a/) — Agent-to-Agent Protocol

Expose agents as remote HTTP endpoints and delegate to them over the A2A protocol.

| Example | Description |
|---------|-------------|
| [delegation.py](a2a/delegation.py) | Local agent + remote A2A agent + MCP server together |

---

### [retrieval/](retrieval/) — RAG & Retrieval

Advanced retrieval patterns for RAG systems.

| Example | Description |
|---------|-------------|
| [basic_retrievers.py](retrieval/basic_retrievers.py) | Dense, BM25, Hybrid, Ensemble, ParentDocument |
| [advanced_retrievers.py](retrieval/advanced_retrievers.py) | HyDE, SelfQuery, SentenceWindow, TimeBasedRetriever |
| [llm_retrievers.py](retrieval/llm_retrievers.py) | Summary, Tree, KeywordTable, KG, MultiRepresentation |
| [reranking.py](retrieval/reranking.py) | CrossEncoder, Cohere, LLM rerankers |
| [hyde.py](retrieval/hyde.py) | Hypothetical Document Embeddings (detailed) |

---

### [observability/](observability/) — Monitoring

See what your agents are doing.

| Example | Description |
|---------|-------------|
| [basic.py](observability/basic.py) | Attach an observer and watch live output |
| [capture.py](observability/capture.py) | Capture events by pattern, inspect history and summary |
| [memory.py](observability/memory.py) | Observe an agent calling `remember`/`recall` with captured `memory.*` + `tool.*` events |
| [custom_formatter.py](observability/custom_formatter.py) | Domain-specific console formatter |
| [reasoning.py](observability/reasoning.py) | Surface `llm.thinking` events from reasoning models |

---

### [resilience/](resilience/) — Fault Tolerance

Production-grade retry, circuit breaking, fallback chains, and failure learning.  All examples run without an API key.

| Example | Description |
|---------|-------------|
| [retry_backoff.py](resilience/retry_backoff.py) | Fixed, exponential, and jitter retry strategies |
| [circuit_breaker.py](resilience/circuit_breaker.py) | CLOSED → OPEN → HALF_OPEN state machine |
| [fallback_chain.py](resilience/fallback_chain.py) | Cascade through backup tools automatically |
| [failure_learning.py](resilience/failure_learning.py) | Learn from failure patterns and avoid known-bad calls |

---

### [advanced/](advanced/) — Production Patterns

Power-user features for production systems.

| Example | Description |
|---------|-------------|
| [reasoning.py](advanced/reasoning.py) | Extended thinking |
| [interceptors.py](advanced/interceptors.py) | Budget guards, PII masking |
| [human_in_the_loop.py](advanced/human_in_the_loop.py) | Tool approval workflows |
| [context_layer.py](advanced/context_layer.py) | Runtime configuration |
| [semantic_cache.py](advanced/semantic_cache.py) | Semantic caching |
| [acc.py](advanced/acc.py) | Context compression |

---

### [memory/](memory/) — 5-Layer Memory Architecture

One example per memory layer, each with a real agent proving its value.

| Example | Layer | Description |
|---------|-------|-------------|
| [conversation.py](memory/conversation.py) | 1 | Thread-based message history, thread isolation |
| [acc.py](memory/acc.py) | 2 | Bounded compression vs unbounded transcript growth |
| [long_term.py](memory/long_term.py) | 3 | Persistent key-value facts across threads, multi-agent sharing |
| [retrieval.py](memory/retrieval.py) | 3 | Non-agentic auto-retrieval from a knowledge base |
| [hybrid.py](memory/hybrid.py) | 3 | Auto-retrieval + agentic tools on a single Memory |
| [episodic.py](memory/episodic.py) | 4 | Graph-backed cross-session experience recall |
| [cache.py](memory/cache.py) | 5 | Semantic tool output cache with timing proof |

---

## 🛣️ Learning Path

### Beginner (30 min)

1. **[hello_world.py](basics/hello_world.py)** — Create your first agent
2. **[conversation.py](memory/conversation.py)** — Add conversation memory
3. **[structured_output.py](basics/structured_output.py)** — Get typed responses
4. **[capture.py](observability/capture.py)** — See what’s happening

### Intermediate (1 hour)

5. **[content_review.py](advanced/content_review.py)** — Multi-agent with subagents
6. **[single_vs_multi_agent.py](advanced/single_vs_multi_agent.py)** — Compare single vs multi-agent efficiency
7. **[filesystem.py](capabilities/filesystem.py)** — Give agents file access
8. **[retrievers.py](retrieval/retrievers.py)** — Add knowledge with RAG
9. **[streaming.py](basics/streaming.py)** — Real-time responses

### Advanced (2+ hours)

10. **[interceptors.py](advanced/interceptors.py)** — Production safeguards
11. **[reasoning.py](advanced/reasoning.py)** — Extended thinking
12. **[context_layer.py](advanced/context_layer.py)** — Runtime configuration

---

## 📂 Data Files

Sample files for examples are in `data/`:

| File | Used By |
|------|---------|
| `the_secret_garden.txt` | RAG examples |
| `company_knowledge.txt` | Knowledge base demos |
| `financial_report.pdf` | PDF processing |
| `mcp_server/` | MCP integration |

---

## 🔧 Troubleshooting

### "API key not found"

1. Check your `.env` file exists in project root
2. Verify the variable name matches (e.g., `OPENAI_API_KEY` not `OPENAI_KEY`)
3. Try setting it explicitly: `export OPENAI_API_KEY=sk-...`

### "Model not found"

1. Check the model name spelling
2. Use provider prefix for clarity: `openai:gpt-4o`
3. See [docs/models.md](../docs/models.md) for supported models

### Running examples

```bash
# Always run from project root
cd /path/to/cogent
uv run python examples/basics/hello_world.py
```

---

## 📚 More Resources

- **[docs/models.md](../docs/models.md)** — Complete model configuration guide
- **[docs/observability.md](../docs/observability.md)** — Event-based observability guide
- **[docs/tools.md](../docs/tools.md)** — Creating custom tools
- **[docs/memory.md](../docs/memory.md)** — Memory systems
