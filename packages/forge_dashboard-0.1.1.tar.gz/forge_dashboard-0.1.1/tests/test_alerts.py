"""Tests for alert rule evaluation logic."""

from __future__ import annotations

import os
import tempfile

os.environ["SQLITE_PATH"] = os.path.join(tempfile.gettempdir(), "forge_test.db")

import pytest

from backend.alerts import (
    create_alert_rule,
    evaluate_alerts,
    evaluate_rule,
)
from backend.auth import create_project, create_user
from backend.db import get_connection, init_db
from backend.ingest import store_metrics


@pytest.fixture(autouse=True)
def fresh_db():
    db_path = os.environ["SQLITE_PATH"]
    if os.path.exists(db_path):
        os.remove(db_path)
    init_db()
    yield
    if os.path.exists(db_path):
        os.remove(db_path)


def _make_project() -> int:
    user = create_user("alert-test@example.com")
    project = create_project("alert-project", user["id"])
    return project["id"]


def test_evaluate_rule_gt():
    rule = {"condition": "gt", "threshold": 10.0}
    assert evaluate_rule(rule, 11.0) is True
    assert evaluate_rule(rule, 10.0) is False
    assert evaluate_rule(rule, 9.0) is False


def test_evaluate_rule_lt():
    rule = {"condition": "lt", "threshold": 10.0}
    assert evaluate_rule(rule, 9.0) is True
    assert evaluate_rule(rule, 10.0) is False


def test_evaluate_rule_gte():
    rule = {"condition": "gte", "threshold": 10.0}
    assert evaluate_rule(rule, 10.0) is True
    assert evaluate_rule(rule, 9.0) is False


def test_evaluate_rule_lte():
    rule = {"condition": "lte", "threshold": 10.0}
    assert evaluate_rule(rule, 10.0) is True
    assert evaluate_rule(rule, 11.0) is False


def test_evaluate_rule_eq():
    rule = {"condition": "eq", "threshold": 10.0}
    assert evaluate_rule(rule, 10.0) is True
    assert evaluate_rule(rule, 10.1) is False


def test_evaluate_alerts_fires_when_threshold_exceeded():
    pid = _make_project()
    create_alert_rule(
        project_id=pid,
        name="High tokens",
        metric_name="forge.thinking_tokens",
        condition="gt",
        threshold=50.0,
    )
    store_metrics(pid, [
        {"name": "forge.thinking_tokens", "value": 100.0, "unit": "", "attributes": {}},
    ])
    triggered = evaluate_alerts(pid)
    assert len(triggered) == 1
    assert triggered[0]["rule_name"] == "High tokens"
    assert triggered[0]["current_value"] == 100.0


def test_evaluate_alerts_does_not_fire_below_threshold():
    pid = _make_project()
    create_alert_rule(
        project_id=pid,
        name="High tokens",
        metric_name="forge.thinking_tokens",
        condition="gt",
        threshold=200.0,
    )
    store_metrics(pid, [
        {"name": "forge.thinking_tokens", "value": 100.0, "unit": "", "attributes": {}},
    ])
    triggered = evaluate_alerts(pid)
    assert len(triggered) == 0


def test_evaluate_alerts_records_firing_in_db():
    pid = _make_project()
    create_alert_rule(
        project_id=pid,
        name="Budget low",
        metric_name="forge.budget",
        condition="lt",
        threshold=500.0,
    )
    store_metrics(pid, [
        {"name": "forge.budget", "value": 100.0, "unit": "", "attributes": {}},
    ])
    evaluate_alerts(pid)
    with get_connection() as conn:
        rows = conn.execute("SELECT * FROM alert_notifications").fetchall()
        assert len(rows) == 1
        assert rows[0]["triggered_value"] == 100.0


def test_evaluate_alerts_skips_missing_metric():
    pid = _make_project()
    create_alert_rule(
        project_id=pid,
        name="No data",
        metric_name="forge.nonexistent",
        condition="gt",
        threshold=0.0,
    )
    triggered = evaluate_alerts(pid)
    assert len(triggered) == 0


def test_create_alert_rule_invalid_condition():
    pid = _make_project()
    with pytest.raises(ValueError, match="Invalid condition"):
        create_alert_rule(
            project_id=pid,
            name="Bad",
            metric_name="x",
            condition="invalid",
            threshold=1.0,
        )


def test_create_alert_rule_invalid_channel():
    pid = _make_project()
    with pytest.raises(ValueError, match="Invalid channel"):
        create_alert_rule(
            project_id=pid,
            name="Bad",
            metric_name="x",
            condition="gt",
            threshold=1.0,
            channel="sms",
        )
