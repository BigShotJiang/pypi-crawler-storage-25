"""Integration tests for API endpoints via TestClient."""

from __future__ import annotations

import os
import tempfile

os.environ["SQLITE_PATH"] = os.path.join(tempfile.gettempdir(), "forge_test.db")
os.environ["FORGE_SETUP_SECRET"] = "test-setup-secret"

import pytest
from fastapi.testclient import TestClient

from backend.auth import create_project, create_user
from backend.db import init_db
from backend.main import app

client = TestClient(app, raise_server_exceptions=False)

SETUP_HEADERS = {"Authorization": "Bearer test-setup-secret"}


@pytest.fixture(autouse=True)
def fresh_db():
    db_path = os.environ["SQLITE_PATH"]
    if os.path.exists(db_path):
        os.remove(db_path)
    init_db()
    yield
    if os.path.exists(db_path):
        os.remove(db_path)


def _make_project() -> tuple[int, str]:
    user = create_user("api-test@example.com")
    project = create_project("api-project", user["id"])
    return project["id"], project["api_key"]


TRACE_PAYLOAD = {
    "resourceSpans": [
        {
            "resource": {"attributes": []},
            "scopeSpans": [
                {
                    "spans": [
                        {
                            "traceId": "t1",
                            "spanId": "s1",
                            "name": "forge.session.request",
                            "startTimeUnixNano": "1700000000000000000",
                            "endTimeUnixNano": "1700000001000000000",
                            "attributes": [
                                {"key": "forge.model", "value": {"stringValue": "Qwen3.6-27B"}},
                                {"key": "forge.thinking_tokens", "value": {"intValue": 100}},
                            ],
                            "status": {"code": "OK"},
                        }
                    ]
                }
            ],
        }
    ]
}


def test_health():
    resp = client.get("/health")
    assert resp.status_code == 200
    assert resp.json()["status"] == "ok"


def test_ingest_traces_requires_api_key():
    resp = client.post("/v1/traces", json=TRACE_PAYLOAD)
    assert resp.status_code == 422


def test_ingest_traces_bad_key():
    resp = client.post(
        "/v1/traces",
        json=TRACE_PAYLOAD,
        headers={"X-API-Key": "fd_bogus"},
    )
    assert resp.status_code == 401


def test_ingest_traces_success():
    _, key = _make_project()
    resp = client.post(
        "/v1/traces",
        json=TRACE_PAYLOAD,
        headers={"X-API-Key": key},
    )
    assert resp.status_code == 200
    assert resp.json()["spans_stored"] == 1


def test_list_sessions_empty():
    _, key = _make_project()
    resp = client.get("/v1/sessions", headers={"X-API-Key": key})
    assert resp.status_code == 200
    assert resp.json() == []


def test_list_sessions_after_ingest():
    _, key = _make_project()
    client.post("/v1/traces", json=TRACE_PAYLOAD, headers={"X-API-Key": key})
    resp = client.get("/v1/sessions", headers={"X-API-Key": key})
    assert resp.status_code == 200
    sessions = resp.json()
    assert len(sessions) == 1
    assert sessions[0]["trace_id"] == "t1"


def test_token_split_empty():
    _, key = _make_project()
    resp = client.get("/v1/token-split", headers={"X-API-Key": key})
    assert resp.status_code == 200
    data = resp.json()
    assert data["total"] == 0


def test_alerts_crud():
    _, key = _make_project()
    headers = {"X-API-Key": key}

    resp = client.post(
        "/v1/alerts",
        json={
            "name": "Budget low",
            "metric_name": "forge.thinking_budget.remaining",
            "condition": "lt",
            "threshold": 1000,
        },
        headers=headers,
    )
    assert resp.status_code == 200
    rule_id = resp.json()["id"]

    resp = client.get("/v1/alerts", headers=headers)
    assert resp.status_code == 200
    assert len(resp.json()) == 1

    resp = client.delete(f"/v1/alerts/{rule_id}", headers=headers)
    assert resp.status_code == 200

    resp = client.get("/v1/alerts", headers=headers)
    assert resp.json() == []


def test_alert_invalid_condition_returns_422():
    _, key = _make_project()
    resp = client.post(
        "/v1/alerts",
        json={
            "name": "Bad",
            "metric_name": "x",
            "condition": "invalid",
            "threshold": 1,
        },
        headers={"X-API-Key": key},
    )
    assert resp.status_code == 422


def test_billing_status():
    _, key = _make_project()
    resp = client.get("/v1/billing/status", headers={"X-API-Key": key})
    assert resp.status_code == 200
    data = resp.json()
    assert data["plan"] == "free"
    assert data["status"] == "stub"


def test_create_user_requires_setup_secret():
    resp = client.post("/v1/users", json={"email": "new@example.com"})
    assert resp.status_code == 422


def test_create_user_wrong_secret():
    resp = client.post(
        "/v1/users",
        json={"email": "new@example.com"},
        headers={"Authorization": "Bearer wrong"},
    )
    assert resp.status_code == 401


def test_create_user():
    resp = client.post(
        "/v1/users",
        json={"email": "new@example.com"},
        headers=SETUP_HEADERS,
    )
    assert resp.status_code == 200
    assert resp.json()["email"] == "new@example.com"


def test_create_project_endpoint():
    user_resp = client.post(
        "/v1/users",
        json={"email": "proj@example.com"},
        headers=SETUP_HEADERS,
    )
    user_id = user_resp.json()["id"]
    resp = client.post(
        "/v1/projects",
        json={"name": "new-proj", "owner_id": user_id},
        headers=SETUP_HEADERS,
    )
    assert resp.status_code == 200
    assert resp.json()["name"] == "new-proj"
    assert "api_key" in resp.json()
