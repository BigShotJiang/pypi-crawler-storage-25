"""Tests for OTLP data parsing and storage."""

from __future__ import annotations

import os
import tempfile

import pytest

os.environ["SQLITE_PATH"] = os.path.join(
    tempfile.gettempdir(), "forge_test.db"
)

from backend.auth import create_project, create_user
from backend.db import get_connection, init_db
from backend.ingest import (
    parse_otlp_metrics,
    parse_otlp_spans,
    store_metrics,
    store_spans,
)


@pytest.fixture(autouse=True)
def fresh_db():
    """Reset the database before each test."""
    db_path = os.environ["SQLITE_PATH"]
    if os.path.exists(db_path):
        os.remove(db_path)
    init_db()
    yield
    if os.path.exists(db_path):
        os.remove(db_path)


def _make_project() -> tuple[int, str]:
    user = create_user("test@example.com")
    project = create_project("test-project", user["id"])
    return project["id"], project["api_key"]


SAMPLE_TRACE_PAYLOAD = {
    "resourceSpans": [
        {
            "resource": {
                "attributes": [
                    {"key": "service.name", "value": {"stringValue": "myapp"}}
                ]
            },
            "scopeSpans": [
                {
                    "spans": [
                        {
                            "traceId": "abc123",
                            "spanId": "span001",
                            "parentSpanId": None,
                            "name": "forge.thinking_turn",
                            "kind": "SPAN_KIND_INTERNAL",
                            "startTimeUnixNano": "1700000000000000000",
                            "endTimeUnixNano": "1700000001000000000",
                            "attributes": [
                                {
                                    "key": "forge.budget_remaining",
                                    "value": {"intValue": 500},
                                }
                            ],
                            "status": {"code": "OK", "message": ""},
                        },
                        {
                            "traceId": "abc123",
                            "spanId": "span002",
                            "parentSpanId": "span001",
                            "name": "forge.mode_switch",
                            "kind": "SPAN_KIND_INTERNAL",
                            "startTimeUnixNano": "1700000001000000000",
                            "endTimeUnixNano": "1700000001100000000",
                            "attributes": [
                                {
                                    "key": "forge.from_mode",
                                    "value": {"stringValue": "think"},
                                },
                                {
                                    "key": "forge.to_mode",
                                    "value": {"stringValue": "instruct"},
                                },
                            ],
                            "status": {"code": "OK"},
                        },
                    ]
                }
            ],
        }
    ]
}

SAMPLE_METRICS_PAYLOAD = {
    "resourceMetrics": [
        {
            "resource": {
                "attributes": [
                    {"key": "service.name", "value": {"stringValue": "myapp"}}
                ]
            },
            "scopeMetrics": [
                {
                    "metrics": [
                        {
                            "name": "forge.thinking_tokens",
                            "unit": "tokens",
                            "gauge": {
                                "dataPoints": [
                                    {
                                        "asInt": 150,
                                        "timeUnixNano": "1700000000000000000",
                                        "attributes": [
                                            {
                                                "key": "trace_id",
                                                "value": {
                                                    "stringValue": "abc123"
                                                },
                                            }
                                        ],
                                    }
                                ]
                            },
                        },
                        {
                            "name": "forge.response_tokens",
                            "unit": "tokens",
                            "sum": {
                                "dataPoints": [
                                    {
                                        "asDouble": 350.0,
                                        "timeUnixNano": "1700000001000000000",
                                        "attributes": [],
                                    }
                                ]
                            },
                        },
                    ]
                }
            ],
        }
    ]
}


def test_parse_otlp_spans_extracts_two_spans():
    spans = parse_otlp_spans(SAMPLE_TRACE_PAYLOAD)
    assert len(spans) == 2


def test_parse_otlp_spans_first_span_fields():
    spans = parse_otlp_spans(SAMPLE_TRACE_PAYLOAD)
    first = spans[0]
    assert first["trace_id"] == "abc123"
    assert first["span_id"] == "span001"
    assert first["name"] == "forge.thinking_turn"
    assert first["attributes"]["service.name"] == "myapp"
    assert first["attributes"]["forge.budget_remaining"] == 500


def test_parse_otlp_spans_second_span_has_parent():
    spans = parse_otlp_spans(SAMPLE_TRACE_PAYLOAD)
    second = spans[1]
    assert second["parent_span_id"] == "span001"
    assert second["name"] == "forge.mode_switch"
    assert second["attributes"]["forge.from_mode"] == "think"
    assert second["attributes"]["forge.to_mode"] == "instruct"


def test_parse_otlp_metrics_extracts_two_metrics():
    metrics = parse_otlp_metrics(SAMPLE_METRICS_PAYLOAD)
    assert len(metrics) == 2


def test_parse_otlp_metrics_values():
    metrics = parse_otlp_metrics(SAMPLE_METRICS_PAYLOAD)
    thinking = [m for m in metrics if m["name"] == "forge.thinking_tokens"][0]
    response = [m for m in metrics if m["name"] == "forge.response_tokens"][0]
    assert thinking["value"] == 150.0
    assert thinking["unit"] == "tokens"
    assert response["value"] == 350.0


def test_store_spans_returns_count():
    project_id, _ = _make_project()
    spans = parse_otlp_spans(SAMPLE_TRACE_PAYLOAD)
    count = store_spans(project_id, spans)
    assert count == 2


def test_store_spans_persists_to_db():
    project_id, _ = _make_project()
    spans = parse_otlp_spans(SAMPLE_TRACE_PAYLOAD)
    store_spans(project_id, spans)
    with get_connection() as conn:
        rows = conn.execute(
            "SELECT * FROM spans WHERE project_id = ?", (project_id,)
        ).fetchall()
        assert len(rows) == 2
        names = {r["name"] for r in rows}
        assert "forge.thinking_turn" in names
        assert "forge.mode_switch" in names


def test_store_metrics_returns_count():
    project_id, _ = _make_project()
    metrics = parse_otlp_metrics(SAMPLE_METRICS_PAYLOAD)
    count = store_metrics(project_id, metrics)
    assert count == 2


def test_store_metrics_persists_to_db():
    project_id, _ = _make_project()
    metrics = parse_otlp_metrics(SAMPLE_METRICS_PAYLOAD)
    store_metrics(project_id, metrics)
    with get_connection() as conn:
        rows = conn.execute(
            "SELECT * FROM metrics WHERE project_id = ?", (project_id,)
        ).fetchall()
        assert len(rows) == 2
        names = {r["name"] for r in rows}
        assert "forge.thinking_tokens" in names
        assert "forge.response_tokens" in names


def test_store_empty_spans_returns_zero():
    project_id, _ = _make_project()
    assert store_spans(project_id, []) == 0


def test_store_empty_metrics_returns_zero():
    project_id, _ = _make_project()
    assert store_metrics(project_id, []) == 0


def test_parse_empty_payload_returns_empty():
    assert parse_otlp_spans({}) == []
    assert parse_otlp_metrics({}) == []
