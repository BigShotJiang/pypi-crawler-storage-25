"""Tests for dashboard query correctness."""

from __future__ import annotations

import os
import tempfile

import pytest

os.environ["SQLITE_PATH"] = os.path.join(
    tempfile.gettempdir(), "forge_test.db"
)

from backend.auth import create_project, create_user
from backend.db import init_db
from backend.ingest import store_metrics, store_spans
from backend.query import (
    get_budget_over_time,
    get_mode_switches,
    get_preserve_thinking_stats,
    get_session_spans,
    get_sessions,
    get_token_split,
)


@pytest.fixture(autouse=True)
def fresh_db():
    db_path = os.environ["SQLITE_PATH"]
    if os.path.exists(db_path):
        os.remove(db_path)
    init_db()
    yield
    if os.path.exists(db_path):
        os.remove(db_path)


def _make_project() -> int:
    user = create_user("query-test@example.com")
    project = create_project("query-project", user["id"])
    return project["id"]


def _seed_spans(project_id: int) -> None:
    spans = [
        {
            "trace_id": "trace-aaa",
            "span_id": "s1",
            "name": "forge.thinking_turn",
            "kind": "INTERNAL",
            "start_time": "1700000000",
            "end_time": "1700000010",
            "attributes": {"session": "first"},
            "status_code": "OK",
            "status_message": "",
        },
        {
            "trace_id": "trace-aaa",
            "span_id": "s2",
            "parent_span_id": "s1",
            "name": "forge.mode_switch",
            "kind": "INTERNAL",
            "start_time": "1700000005",
            "end_time": "1700000006",
            "attributes": {
                "forge.from_mode": "think",
                "forge.to_mode": "instruct",
            },
            "status_code": "OK",
            "status_message": "",
        },
        {
            "trace_id": "trace-bbb",
            "span_id": "s3",
            "name": "forge.thinking_turn",
            "kind": "INTERNAL",
            "start_time": "1700000020",
            "end_time": "1700000030",
            "attributes": {"session": "second"},
            "status_code": "OK",
            "status_message": "",
        },
    ]
    store_spans(project_id, spans)


def _seed_metrics(project_id: int) -> None:
    metrics = [
        {
            "name": "forge.thinking_budget.remaining",
            "value": 1000.0,
            "unit": "tokens",
            "attributes": {"trace_id": "trace-aaa"},
            "timestamp": "1700000000",
        },
        {
            "name": "forge.thinking_budget.remaining",
            "value": 800.0,
            "unit": "tokens",
            "attributes": {"trace_id": "trace-aaa"},
            "timestamp": "1700000005",
        },
        {
            "name": "forge.thinking_tokens",
            "value": 200.0,
            "unit": "tokens",
            "attributes": {"trace_id": "trace-aaa"},
            "timestamp": "1700000010",
        },
        {
            "name": "forge.response_tokens",
            "value": 300.0,
            "unit": "tokens",
            "attributes": {"trace_id": "trace-aaa"},
            "timestamp": "1700000010",
        },
        {
            "name": "forge.preserve_thinking_reuse",
            "value": 8.0,
            "unit": "",
            "attributes": {},
            "timestamp": "1700000010",
        },
        {
            "name": "forge.preserve_thinking_regen",
            "value": 2.0,
            "unit": "",
            "attributes": {},
            "timestamp": "1700000010",
        },
    ]
    store_metrics(project_id, metrics)


def test_get_sessions_returns_distinct_traces():
    pid = _make_project()
    _seed_spans(pid)
    sessions = get_sessions(pid)
    assert len(sessions) == 2
    trace_ids = {s["trace_id"] for s in sessions}
    assert trace_ids == {"trace-aaa", "trace-bbb"}


def test_get_sessions_most_recent_first():
    pid = _make_project()
    _seed_spans(pid)
    sessions = get_sessions(pid)
    assert sessions[0]["trace_id"] == "trace-bbb"
    assert sessions[1]["trace_id"] == "trace-aaa"


def test_get_sessions_span_count():
    pid = _make_project()
    _seed_spans(pid)
    sessions = get_sessions(pid)
    aaa = [s for s in sessions if s["trace_id"] == "trace-aaa"][0]
    bbb = [s for s in sessions if s["trace_id"] == "trace-bbb"][0]
    assert aaa["span_count"] == 2
    assert bbb["span_count"] == 1


def test_get_session_spans_returns_all():
    pid = _make_project()
    _seed_spans(pid)
    spans = get_session_spans(pid, "trace-aaa")
    assert len(spans) == 2
    names = [s["name"] for s in spans]
    assert "forge.thinking_turn" in names
    assert "forge.mode_switch" in names


def test_get_session_spans_ordered_by_start_time():
    pid = _make_project()
    _seed_spans(pid)
    spans = get_session_spans(pid, "trace-aaa")
    assert spans[0]["start_time"] <= spans[1]["start_time"]


def test_get_budget_over_time_returns_data():
    pid = _make_project()
    _seed_metrics(pid)
    budget = get_budget_over_time(pid)
    assert len(budget) == 2
    assert budget[0]["value"] == 1000.0
    assert budget[1]["value"] == 800.0


def test_get_budget_over_time_filter_by_trace():
    pid = _make_project()
    _seed_metrics(pid)
    budget = get_budget_over_time(pid, trace_id="trace-aaa")
    assert len(budget) == 2
    budget_none = get_budget_over_time(pid, trace_id="nonexistent")
    assert len(budget_none) == 0


def test_get_token_split_totals():
    pid = _make_project()
    _seed_metrics(pid)
    split = get_token_split(pid)
    assert split["thinking_tokens"] == 200.0
    assert split["response_tokens"] == 300.0
    assert split["total"] == 500.0


def test_get_mode_switches():
    pid = _make_project()
    _seed_spans(pid)
    switches = get_mode_switches(pid)
    assert len(switches) == 1
    assert switches[0]["attributes"]["forge.from_mode"] == "think"
    assert switches[0]["attributes"]["forge.to_mode"] == "instruct"


def test_get_mode_switches_filter_by_trace():
    pid = _make_project()
    _seed_spans(pid)
    switches = get_mode_switches(pid, trace_id="trace-aaa")
    assert len(switches) == 1
    switches_empty = get_mode_switches(pid, trace_id="trace-bbb")
    assert len(switches_empty) == 0


def test_preserve_thinking_stats():
    pid = _make_project()
    _seed_metrics(pid)
    stats = get_preserve_thinking_stats(pid)
    assert stats["reuse_count"] == 8.0
    assert stats["regen_count"] == 2.0
    assert stats["total"] == 10.0
    assert stats["reuse_rate"] == 0.8


def test_preserve_thinking_stats_no_data():
    pid = _make_project()
    stats = get_preserve_thinking_stats(pid)
    assert stats["reuse_count"] == 0.0
    assert stats["regen_count"] == 0.0
    assert stats["total"] == 0.0
    assert stats["reuse_rate"] == 0.0


def test_get_sessions_respects_limit():
    pid = _make_project()
    _seed_spans(pid)
    sessions = get_sessions(pid, limit=1)
    assert len(sessions) == 1


def test_get_session_spans_wrong_project_returns_empty():
    pid = _make_project()
    _seed_spans(pid)
    spans = get_session_spans(999, "trace-aaa")
    assert len(spans) == 0
