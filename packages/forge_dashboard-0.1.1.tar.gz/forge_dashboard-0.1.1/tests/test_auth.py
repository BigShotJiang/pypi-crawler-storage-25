"""Tests for authentication and authorization flows."""

from __future__ import annotations

import os
import tempfile

import pytest

os.environ["SQLITE_PATH"] = os.path.join(
    tempfile.gettempdir(), "forge_test.db"
)

from backend.auth import (
    create_project,
    create_user,
    validate_api_key,
)
from backend.db import init_db


@pytest.fixture(autouse=True)
def fresh_db():
    db_path = os.environ["SQLITE_PATH"]
    if os.path.exists(db_path):
        os.remove(db_path)
    init_db()
    yield
    if os.path.exists(db_path):
        os.remove(db_path)


def test_create_user_returns_id_and_email():
    user = create_user("alice@example.com")
    assert user["email"] == "alice@example.com"
    assert isinstance(user["id"], int)
    assert user["id"] >= 1


def test_create_project_returns_api_key():
    user = create_user("owner@example.com")
    project = create_project("my-project", user["id"])
    assert project["name"] == "my-project"
    assert project["owner_id"] == user["id"]
    assert project["api_key"].startswith("fd_")
    assert len(project["api_key"]) == 51  # "fd_" + 48 hex chars


def test_validate_api_key_valid():
    user = create_user("val@example.com")
    project = create_project("val-project", user["id"])
    pid = validate_api_key(project["api_key"])
    assert pid == project["id"]


def test_validate_api_key_invalid():
    pid = validate_api_key("fd_boguskey1234567890")
    assert pid is None


def test_duplicate_user_raises():
    create_user("dup@example.com")
    with pytest.raises(Exception):
        create_user("dup@example.com")
