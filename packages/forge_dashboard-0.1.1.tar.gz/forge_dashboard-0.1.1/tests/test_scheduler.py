"""Tests for the background scheduler (alert eval + retention)."""

from __future__ import annotations

import os
import tempfile

os.environ["SQLITE_PATH"] = os.path.join(tempfile.gettempdir(), "forge_test.db")
os.environ["FORGE_RETENTION_DAYS"] = "0"

import pytest

from backend.auth import create_project, create_user
from backend.db import get_connection, init_db
from backend.ingest import store_spans
from backend.scheduler import _get_all_project_ids, _run_retention_cleanup


@pytest.fixture(autouse=True)
def fresh_db():
    db_path = os.environ["SQLITE_PATH"]
    if os.path.exists(db_path):
        os.remove(db_path)
    init_db()
    yield
    if os.path.exists(db_path):
        os.remove(db_path)


def _make_project() -> tuple[int, str]:
    user = create_user("sched@example.com")
    project = create_project("sched-project", user["id"])
    return project["id"], project["api_key"]


def test_get_all_project_ids():
    pid, _ = _make_project()
    ids = _get_all_project_ids()
    assert pid in ids


def test_retention_cleanup_removes_old_data():
    pid, _ = _make_project()
    old_spans = [
        {
            "trace_id": "old",
            "span_id": "s1",
            "name": "test",
            "kind": "",
            "start_time": "1000000000",
            "end_time": "1000000001",
            "attributes": {},
            "status_code": "OK",
            "status_message": "",
        }
    ]
    store_spans(pid, old_spans)
    with get_connection() as conn:
        count = conn.execute("SELECT COUNT(*) FROM spans").fetchone()[0]
        assert count == 1

    deleted = _run_retention_cleanup()
    assert deleted >= 1

    with get_connection() as conn:
        count = conn.execute("SELECT COUNT(*) FROM spans").fetchone()[0]
        assert count == 0


def test_retention_cleanup_keeps_recent_data():
    os.environ["FORGE_RETENTION_DAYS"] = "365"
    pid, _ = _make_project()
    from datetime import datetime, timezone

    now_ns = str(int(datetime.now(timezone.utc).timestamp() * 1e9))
    recent_spans = [
        {
            "trace_id": "recent",
            "span_id": "s1",
            "name": "test",
            "kind": "",
            "start_time": now_ns,
            "end_time": now_ns,
            "attributes": {},
            "status_code": "OK",
            "status_message": "",
        }
    ]
    store_spans(pid, recent_spans)
    deleted = _run_retention_cleanup()
    assert deleted == 0
    with get_connection() as conn:
        count = conn.execute("SELECT COUNT(*) FROM spans").fetchone()[0]
        assert count == 1
    os.environ["FORGE_RETENTION_DAYS"] = "0"
