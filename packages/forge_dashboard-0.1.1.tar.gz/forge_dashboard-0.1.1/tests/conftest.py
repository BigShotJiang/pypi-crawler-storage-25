"""Shared test fixtures."""

from __future__ import annotations

import os
import tempfile

import pytest

os.environ["SQLITE_PATH"] = os.path.join(tempfile.gettempdir(), "forge_test.db")

from backend.auth import create_project, create_user
from backend.db import init_db


@pytest.fixture()
def fresh_db():
    db_path = os.environ["SQLITE_PATH"]
    if os.path.exists(db_path):
        os.remove(db_path)
    init_db()
    yield
    if os.path.exists(db_path):
        os.remove(db_path)


@pytest.fixture()
def project_with_key(fresh_db):
    """Create a user + project and return (project_id, api_key)."""
    user = create_user("test@example.com")
    project = create_project("test-project", user["id"])
    return project["id"], project["api_key"]
