-- Time-series tables for spans and metrics.

CREATE TABLE IF NOT EXISTS spans (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    project_id INTEGER NOT NULL REFERENCES projects(id),
    trace_id TEXT NOT NULL,
    span_id TEXT NOT NULL,
    parent_span_id TEXT,
    name TEXT NOT NULL,
    kind TEXT NOT NULL DEFAULT '',
    start_time TEXT NOT NULL,
    end_time TEXT NOT NULL,
    attributes TEXT NOT NULL DEFAULT '{}',
    status_code TEXT NOT NULL DEFAULT 'OK',
    status_message TEXT NOT NULL DEFAULT '',
    ingested_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_spans_project_trace
    ON spans(project_id, trace_id);

CREATE INDEX IF NOT EXISTS idx_spans_project_name
    ON spans(project_id, name);

CREATE INDEX IF NOT EXISTS idx_spans_start_time
    ON spans(start_time);

CREATE TABLE IF NOT EXISTS metrics (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    project_id INTEGER NOT NULL REFERENCES projects(id),
    name TEXT NOT NULL,
    value REAL NOT NULL,
    unit TEXT NOT NULL DEFAULT '',
    attributes TEXT NOT NULL DEFAULT '{}',
    timestamp TEXT NOT NULL,
    ingested_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_metrics_project_name
    ON metrics(project_id, name);

CREATE INDEX IF NOT EXISTS idx_metrics_timestamp
    ON metrics(timestamp);
