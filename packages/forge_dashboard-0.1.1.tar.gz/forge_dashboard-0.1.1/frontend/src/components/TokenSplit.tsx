import { useEffect, useState } from "react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  Cell,
} from "recharts";
import { getTokenSplit, TokenSplit as TokenSplitData } from "../api";

interface Props {
  traceId?: string;
}

const COLORS = ["#2563eb", "#f59e0b"];

export default function TokenSplit({ traceId }: Props) {
  const [data, setData] = useState<TokenSplitData | null>(null);
  const [error, setError] = useState("");

  useEffect(() => {
    getTokenSplit(traceId)
      .then(setData)
      .catch((e) => setError(e.message));
  }, [traceId]);

  if (error) {
    return <p className="text-red-600 text-sm">{error}</p>;
  }

  if (!data || data.total === 0) {
    return (
      <p className="text-gray-500 text-sm">No token split data available.</p>
    );
  }

  const chartData = [
    { name: "Thinking", tokens: data.thinking_tokens },
    { name: "Response", tokens: data.response_tokens },
  ];

  const thinkPct =
    data.total > 0 ? ((data.thinking_tokens / data.total) * 100).toFixed(1) : "0";

  return (
    <div className="bg-white rounded-lg border border-gray-200 p-4">
      <h3 className="text-sm font-medium text-gray-700 mb-1">
        Think vs Response Tokens
      </h3>
      <p className="text-xs text-gray-500 mb-3">
        {thinkPct}% thinking, {data.total.toLocaleString()} total tokens
      </p>
      <ResponsiveContainer width="100%" height={200}>
        <BarChart data={chartData}>
          <XAxis dataKey="name" tick={{ fontSize: 12 }} />
          <YAxis tick={{ fontSize: 11 }} />
          <Tooltip />
          <Bar dataKey="tokens" radius={[4, 4, 0, 0]}>
            {chartData.map((_entry, idx) => (
              <Cell key={idx} fill={COLORS[idx % COLORS.length]} />
            ))}
          </Bar>
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}
