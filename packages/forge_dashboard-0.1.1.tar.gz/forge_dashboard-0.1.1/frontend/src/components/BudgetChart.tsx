import { useEffect, useState } from "react";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts";
import { getBudget, BudgetPoint } from "../api";

interface Props {
  traceId?: string;
}

export default function BudgetChart({ traceId }: Props) {
  const [data, setData] = useState<BudgetPoint[]>([]);
  const [error, setError] = useState("");

  useEffect(() => {
    getBudget(traceId)
      .then(setData)
      .catch((e) => setError(e.message));
  }, [traceId]);

  if (error) {
    return <p className="text-red-600 text-sm">{error}</p>;
  }

  if (data.length === 0) {
    return <p className="text-gray-500 text-sm">No budget data available.</p>;
  }

  return (
    <div className="bg-white rounded-lg border border-gray-200 p-4">
      <h3 className="text-sm font-medium text-gray-700 mb-3">
        Thinking Budget Over Time
      </h3>
      <ResponsiveContainer width="100%" height={250}>
        <LineChart data={data}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis
            dataKey="timestamp"
            tick={{ fontSize: 11 }}
            tickFormatter={(v: string) => {
              if (!v || v.length < 10) return v;
              return v.slice(0, 10);
            }}
          />
          <YAxis tick={{ fontSize: 11 }} />
          <Tooltip />
          <Line
            type="monotone"
            dataKey="value"
            stroke="#2563eb"
            strokeWidth={2}
            dot={false}
            name="Budget Remaining"
          />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}
