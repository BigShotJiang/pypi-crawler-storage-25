import { useEffect, useState } from "react";
import { getModeSwitches, ModeSwitch } from "../api";

interface Props {
  traceId?: string;
}

export default function ModeTimeline({ traceId }: Props) {
  const [switches, setSwitches] = useState<ModeSwitch[]>([]);
  const [error, setError] = useState("");

  useEffect(() => {
    getModeSwitches(traceId)
      .then(setSwitches)
      .catch((e) => setError(e.message));
  }, [traceId]);

  if (error) {
    return <p className="text-red-600 text-sm">{error}</p>;
  }

  if (switches.length === 0) {
    return (
      <p className="text-gray-500 text-sm">No mode switch events recorded.</p>
    );
  }

  return (
    <div className="bg-white rounded-lg border border-gray-200 p-4">
      <h3 className="text-sm font-medium text-gray-700 mb-3">
        Mode Switch Events
      </h3>
      <div className="space-y-2 max-h-64 overflow-y-auto">
        {switches.map((sw) => {
          const from = (sw.attributes["forge.from_mode"] as string) || "?";
          const to = (sw.attributes["forge.to_mode"] as string) || "?";
          return (
            <div
              key={sw.span_id}
              className="flex items-center gap-3 text-sm border-l-2 border-blue-400 pl-3 py-1"
            >
              <span className="text-gray-400 text-xs font-mono">
                {sw.start_time}
              </span>
              <span>
                <span className="font-medium">{from}</span>
                {" -> "}
                <span className="font-medium">{to}</span>
              </span>
              <span className="text-xs text-gray-400">{sw.trace_id}</span>
            </div>
          );
        })}
      </div>
    </div>
  );
}
