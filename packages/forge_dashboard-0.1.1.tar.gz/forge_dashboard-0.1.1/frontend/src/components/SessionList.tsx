import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { getSessions, Session } from "../api";

export default function SessionList() {
  const [sessions, setSessions] = useState<Session[]>([]);
  const [error, setError] = useState("");

  useEffect(() => {
    getSessions()
      .then(setSessions)
      .catch((e) => setError(e.message));
  }, []);

  if (error) {
    return <p className="text-red-600 text-sm">{error}</p>;
  }

  if (sessions.length === 0) {
    return <p className="text-gray-500 text-sm">No sessions recorded yet.</p>;
  }

  return (
    <div className="bg-white rounded-lg border border-gray-200 p-4">
      <h3 className="text-sm font-medium text-gray-700 mb-3">
        Recent Sessions
      </h3>
      <table className="w-full text-sm">
        <thead>
          <tr className="text-left text-gray-500 border-b">
            <th className="pb-2 font-medium">Trace ID</th>
            <th className="pb-2 font-medium">Started</th>
            <th className="pb-2 font-medium">Spans</th>
          </tr>
        </thead>
        <tbody>
          {sessions.map((s) => (
            <tr key={s.trace_id} className="border-b last:border-0">
              <td className="py-2">
                <Link
                  to={`/session/${s.trace_id}`}
                  className="text-blue-600 hover:underline font-mono text-xs"
                >
                  {s.trace_id}
                </Link>
              </td>
              <td className="py-2 text-gray-600 text-xs">{s.first_span}</td>
              <td className="py-2 text-gray-600">{s.span_count}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
