import { Link, Route, Routes } from "react-router-dom";
import Dashboard from "./pages/Dashboard";
import Session from "./pages/Session";
import Alerts from "./pages/Alerts";
import Settings from "./pages/Settings";

function Nav() {
  return (
    <nav className="bg-white border-b border-gray-200 px-6 py-3 flex items-center gap-6">
      <span className="font-bold text-lg">Forge Dashboard</span>
      <Link to="/" className="text-gray-600 hover:text-gray-900">
        Dashboard
      </Link>
      <Link to="/alerts" className="text-gray-600 hover:text-gray-900">
        Alerts
      </Link>
      <Link to="/settings" className="text-gray-600 hover:text-gray-900">
        Settings
      </Link>
    </nav>
  );
}

export default function App() {
  return (
    <div className="min-h-screen bg-gray-50">
      <Nav />
      <main className="max-w-7xl mx-auto px-4 py-6">
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/session/:traceId" element={<Session />} />
          <Route path="/alerts" element={<Alerts />} />
          <Route path="/settings" element={<Settings />} />
        </Routes>
      </main>
    </div>
  );
}
