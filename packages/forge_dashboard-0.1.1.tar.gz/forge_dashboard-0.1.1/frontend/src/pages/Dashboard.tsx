import BudgetChart from "../components/BudgetChart";
import TokenSplit from "../components/TokenSplit";
import ModeTimeline from "../components/ModeTimeline";
import SessionList from "../components/SessionList";

export default function Dashboard() {
  return (
    <div className="space-y-6">
      <h1 className="text-xl font-semibold">Overview</h1>
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <BudgetChart />
        <TokenSplit />
      </div>
      <ModeTimeline />
      <SessionList />
    </div>
  );
}
