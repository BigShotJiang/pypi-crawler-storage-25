import { useEffect, useState } from "react";
import { getAlerts, createAlert, deleteAlert, AlertRule } from "../api";

export default function Alerts() {
  const [rules, setRules] = useState<AlertRule[]>([]);
  const [error, setError] = useState("");

  // Form state
  const [name, setName] = useState("");
  const [metricName, setMetricName] = useState("forge.thinking_budget.remaining");
  const [condition, setCondition] = useState("lt");
  const [threshold, setThreshold] = useState("");
  const [channel, setChannel] = useState("email");

  function loadAlerts() {
    getAlerts()
      .then(setRules)
      .catch((e) => setError(e.message));
  }

  useEffect(() => {
    loadAlerts();
  }, []);

  async function handleCreate(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    try {
      await createAlert({
        name,
        metric_name: metricName,
        condition,
        threshold: parseFloat(threshold),
        channel,
      });
      setName("");
      setThreshold("");
      loadAlerts();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to create alert");
    }
  }

  async function handleDelete(ruleId: number) {
    try {
      await deleteAlert(ruleId);
      loadAlerts();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to delete alert");
    }
  }

  return (
    <div className="space-y-6">
      <h1 className="text-xl font-semibold">Alert Rules</h1>

      {error && <p className="text-red-600 text-sm">{error}</p>}

      <form
        onSubmit={handleCreate}
        className="bg-white rounded-lg border border-gray-200 p-4 space-y-3"
      >
        <h3 className="text-sm font-medium text-gray-700">New Alert Rule</h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          <input
            type="text"
            placeholder="Rule name"
            value={name}
            onChange={(e) => setName(e.target.value)}
            className="border rounded px-3 py-2 text-sm"
            required
          />
          <select
            value={metricName}
            onChange={(e) => setMetricName(e.target.value)}
            className="border rounded px-3 py-2 text-sm"
          >
            <option value="forge.thinking_budget.remaining">
              Budget Remaining
            </option>
            <option value="forge.thinking_tokens">Thinking Tokens</option>
            <option value="forge.response_tokens">Response Tokens</option>
            <option value="forge.preserve_thinking_reuse">
              Preserve Thinking Reuse
            </option>
          </select>
          <select
            value={condition}
            onChange={(e) => setCondition(e.target.value)}
            className="border rounded px-3 py-2 text-sm"
          >
            <option value="gt">Greater than</option>
            <option value="lt">Less than</option>
            <option value="gte">Greater or equal</option>
            <option value="lte">Less or equal</option>
            <option value="eq">Equal to</option>
          </select>
          <input
            type="number"
            placeholder="Threshold"
            value={threshold}
            onChange={(e) => setThreshold(e.target.value)}
            className="border rounded px-3 py-2 text-sm"
            required
          />
          <select
            value={channel}
            onChange={(e) => setChannel(e.target.value)}
            className="border rounded px-3 py-2 text-sm"
          >
            <option value="email">Email</option>
            <option value="slack">Slack</option>
            <option value="pagerduty">PagerDuty</option>
          </select>
          <button
            type="submit"
            className="bg-blue-600 text-white rounded px-4 py-2 text-sm hover:bg-blue-700"
          >
            Create
          </button>
        </div>
      </form>

      <div className="bg-white rounded-lg border border-gray-200 p-4">
        <h3 className="text-sm font-medium text-gray-700 mb-3">
          Active Rules
        </h3>
        {rules.length === 0 ? (
          <p className="text-gray-500 text-sm">No alert rules configured.</p>
        ) : (
          <table className="w-full text-sm">
            <thead>
              <tr className="text-left text-gray-500 border-b">
                <th className="pb-2 font-medium">Name</th>
                <th className="pb-2 font-medium">Metric</th>
                <th className="pb-2 font-medium">Condition</th>
                <th className="pb-2 font-medium">Channel</th>
                <th className="pb-2 font-medium"></th>
              </tr>
            </thead>
            <tbody>
              {rules.map((r) => (
                <tr key={r.id} className="border-b last:border-0">
                  <td className="py-2">{r.name}</td>
                  <td className="py-2 font-mono text-xs">{r.metric_name}</td>
                  <td className="py-2">
                    {r.condition} {r.threshold}
                  </td>
                  <td className="py-2">{r.channel}</td>
                  <td className="py-2">
                    <button
                      onClick={() => handleDelete(r.id)}
                      className="text-red-600 hover:underline text-xs"
                    >
                      Delete
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
