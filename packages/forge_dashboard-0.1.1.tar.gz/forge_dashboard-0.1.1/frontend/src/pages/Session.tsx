import { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import { getSessionSpans, Span } from "../api";
import BudgetChart from "../components/BudgetChart";
import TokenSplit from "../components/TokenSplit";
import ModeTimeline from "../components/ModeTimeline";

export default function Session() {
  const { traceId } = useParams<{ traceId: string }>();
  const [spans, setSpans] = useState<Span[]>([]);
  const [error, setError] = useState("");

  useEffect(() => {
    if (!traceId) return;
    getSessionSpans(traceId)
      .then(setSpans)
      .catch((e) => setError(e.message));
  }, [traceId]);

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3">
        <Link to="/" className="text-blue-600 hover:underline text-sm">
          Back
        </Link>
        <h1 className="text-xl font-semibold">
          Session{" "}
          <span className="font-mono text-base text-gray-500">{traceId}</span>
        </h1>
      </div>

      {error && <p className="text-red-600 text-sm">{error}</p>}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <BudgetChart traceId={traceId} />
        <TokenSplit traceId={traceId} />
      </div>

      <ModeTimeline traceId={traceId} />

      <div className="bg-white rounded-lg border border-gray-200 p-4">
        <h3 className="text-sm font-medium text-gray-700 mb-3">
          Spans ({spans.length})
        </h3>
        {spans.length === 0 ? (
          <p className="text-gray-500 text-sm">No spans found.</p>
        ) : (
          <div className="space-y-2">
            {spans.map((s) => (
              <div
                key={s.span_id}
                className="border rounded p-3 text-sm space-y-1"
              >
                <div className="flex justify-between">
                  <span className="font-medium">{s.name}</span>
                  <span className="text-xs text-gray-400 font-mono">
                    {s.span_id}
                  </span>
                </div>
                <div className="text-xs text-gray-500">
                  {s.start_time} - {s.end_time} | Status: {s.status_code}
                </div>
                {Object.keys(s.attributes).length > 0 && (
                  <pre className="text-xs bg-gray-50 rounded p-2 overflow-x-auto">
                    {JSON.stringify(s.attributes, null, 2)}
                  </pre>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
