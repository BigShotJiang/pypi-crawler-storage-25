import { useEffect, useState } from "react";
import { getBillingStatus } from "../api";

export default function Settings() {
  const [apiKey, setApiKey] = useState(
    () => localStorage.getItem("forge_api_key") || "",
  );
  const [billing, setBilling] = useState<Record<string, unknown> | null>(null);
  const [saved, setSaved] = useState(false);

  function handleSaveKey(e: React.FormEvent) {
    e.preventDefault();
    localStorage.setItem("forge_api_key", apiKey);
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  }

  useEffect(() => {
    if (apiKey) {
      getBillingStatus()
        .then(setBilling)
        .catch(() => setBilling(null));
    }
  }, [apiKey]);

  return (
    <div className="space-y-6">
      <h1 className="text-xl font-semibold">Settings</h1>

      <div className="bg-white rounded-lg border border-gray-200 p-4 space-y-3">
        <h3 className="text-sm font-medium text-gray-700">API Key</h3>
        <form onSubmit={handleSaveKey} className="flex gap-3">
          <input
            type="text"
            value={apiKey}
            onChange={(e) => setApiKey(e.target.value)}
            placeholder="fd_..."
            className="border rounded px-3 py-2 text-sm flex-1 font-mono"
          />
          <button
            type="submit"
            className="bg-blue-600 text-white rounded px-4 py-2 text-sm hover:bg-blue-700"
          >
            Save
          </button>
        </form>
        {saved && (
          <p className="text-green-600 text-sm">API key saved to browser.</p>
        )}
        <p className="text-xs text-gray-500">
          Your API key is stored in localStorage and sent with every request.
        </p>
      </div>

      <div className="bg-white rounded-lg border border-gray-200 p-4 space-y-3">
        <h3 className="text-sm font-medium text-gray-700">Billing</h3>
        {billing ? (
          <div className="text-sm space-y-1">
            <p>
              Plan:{" "}
              <span className="font-medium">
                {String(billing.plan || "free")}
              </span>
            </p>
            <p>
              Status:{" "}
              <span className="font-medium">
                {String(billing.status || "unknown")}
              </span>
            </p>
            <p>
              Data retention:{" "}
              <span className="font-medium">
                {String(billing.data_retention_days || "?")} days
              </span>
            </p>
          </div>
        ) : (
          <p className="text-gray-500 text-sm">
            Enter an API key above to see billing info.
          </p>
        )}
      </div>

      <div className="bg-white rounded-lg border border-gray-200 p-4 space-y-3">
        <h3 className="text-sm font-medium text-gray-700">
          Project Setup
        </h3>
        <p className="text-gray-500 text-sm">
          Create users and projects via the API with the setup secret.
          See the README for details.
        </p>
      </div>
    </div>
  );
}
