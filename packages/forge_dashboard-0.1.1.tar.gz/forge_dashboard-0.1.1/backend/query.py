"""Query engine for dashboard views.

Provides functions to query spans and metrics for visualization.
"""

from __future__ import annotations

import json
from typing import Any

from backend.db import get_connection


def get_sessions(
    project_id: int, limit: int = 50, offset: int = 0
) -> list[dict[str, Any]]:
    """List sessions (distinct trace_ids) for a project, most recent first."""
    with get_connection() as conn:
        rows = conn.execute(
            "SELECT trace_id, "
            "  MIN(start_time) AS first_span, "
            "  MAX(end_time) AS last_span, "
            "  COUNT(*) AS span_count "
            "FROM spans "
            "WHERE project_id = ? "
            "GROUP BY trace_id "
            "ORDER BY first_span DESC "
            "LIMIT ? OFFSET ?",
            (project_id, limit, offset),
        ).fetchall()
        return [dict(r) for r in rows]


def get_session_spans(
    project_id: int, trace_id: str
) -> list[dict[str, Any]]:
    """Get all spans for a single session/trace."""
    with get_connection() as conn:
        rows = conn.execute(
            "SELECT span_id, parent_span_id, name, kind, "
            "  start_time, end_time, attributes, "
            "  status_code, status_message "
            "FROM spans "
            "WHERE project_id = ? AND trace_id = ? "
            "ORDER BY start_time ASC",
            (project_id, trace_id),
        ).fetchall()
        results = []
        for r in rows:
            d = dict(r)
            d["attributes"] = json.loads(d["attributes"])
            results.append(d)
        return results


def get_budget_over_time(
    project_id: int, trace_id: str | None = None
) -> list[dict[str, Any]]:
    """Get thinking budget burn rate data points.

    Looks for metrics named 'forge.thinking_budget.*' or span attributes
    with budget info.
    """
    with get_connection() as conn:
        params: list[Any] = [project_id]
        query = (
            "SELECT name, value, timestamp, attributes "
            "FROM metrics "
            "WHERE project_id = ? "
            "  AND name LIKE 'forge.thinking_budget%' "
        )
        if trace_id:
            query += "  AND json_extract(attributes, '$.trace_id') = ? "
            params.append(trace_id)
        query += "ORDER BY timestamp ASC"
        rows = conn.execute(query, params).fetchall()
        results = []
        for r in rows:
            d = dict(r)
            d["attributes"] = json.loads(d["attributes"])
            results.append(d)
        return results


def get_token_split(
    project_id: int, trace_id: str | None = None
) -> dict[str, float]:
    """Get thinking vs response token totals.

    Returns {"thinking_tokens": N, "response_tokens": N, "total": N}.
    """
    with get_connection() as conn:
        params: list[Any] = [project_id]
        query = (
            "SELECT name, SUM(value) AS total "
            "FROM metrics "
            "WHERE project_id = ? "
            "  AND name IN ("
            "    'forge.thinking_tokens', 'forge.response_tokens'"
            "  ) "
        )
        if trace_id:
            query += "  AND json_extract(attributes, '$.trace_id') = ? "
            params.append(trace_id)
        query += "GROUP BY name"
        rows = conn.execute(query, params).fetchall()
        result = {"thinking_tokens": 0.0, "response_tokens": 0.0, "total": 0.0}
        for r in rows:
            if r["name"] == "forge.thinking_tokens":
                result["thinking_tokens"] = r["total"]
            elif r["name"] == "forge.response_tokens":
                result["response_tokens"] = r["total"]
        result["total"] = result["thinking_tokens"] + result["response_tokens"]
        return result


def get_mode_switches(
    project_id: int, trace_id: str | None = None, limit: int = 100
) -> list[dict[str, Any]]:
    """Get mode switch events (think <-> instruct transitions).

    These are stored as spans with name 'forge.mode_switch'.
    """
    with get_connection() as conn:
        params: list[Any] = [project_id]
        query = (
            "SELECT span_id, trace_id, start_time, attributes "
            "FROM spans "
            "WHERE project_id = ? AND name = 'forge.mode_switch' "
        )
        if trace_id:
            query += "AND trace_id = ? "
            params.append(trace_id)
        query += "ORDER BY start_time DESC LIMIT ?"
        params.append(limit)
        rows = conn.execute(query, params).fetchall()
        results = []
        for r in rows:
            d = dict(r)
            d["attributes"] = json.loads(d["attributes"])
            results.append(d)
        return results


def get_preserve_thinking_stats(
    project_id: int,
) -> dict[str, Any]:
    """Get preserve_thinking utilization stats.

    Returns reuse rate and counts.
    """
    with get_connection() as conn:
        rows = conn.execute(
            "SELECT name, SUM(value) AS total "
            "FROM metrics "
            "WHERE project_id = ? "
            "  AND name IN ("
            "    'forge.preserve_thinking_reuse', "
            "    'forge.preserve_thinking_regen'"
            "  ) "
            "GROUP BY name",
            (project_id,),
        ).fetchall()
        reuse = 0.0
        regen = 0.0
        for r in rows:
            if r["name"] == "forge.preserve_thinking_reuse":
                reuse = r["total"]
            elif r["name"] == "forge.preserve_thinking_regen":
                regen = r["total"]
        total = reuse + regen
        rate = (reuse / total) if total > 0 else 0.0
        return {
            "reuse_count": reuse,
            "regen_count": regen,
            "total": total,
            "reuse_rate": rate,
        }
