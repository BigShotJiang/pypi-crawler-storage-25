"""Alert rule evaluation.

Threshold-based alerts evaluated on a background schedule.
When a rule fires, the event is recorded in the alert_notifications table.
Notification delivery (email, Slack, etc.) is not yet implemented.
"""

from __future__ import annotations

import json
from typing import Any

from backend.db import get_connection


def create_alert_rule(
    project_id: int,
    name: str,
    metric_name: str,
    condition: str,
    threshold: float,
    channel: str = "email",
    channel_config: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Create an alert rule.

    condition: one of 'gt', 'lt', 'gte', 'lte', 'eq'
    channel: 'email', 'slack', 'pagerduty'
    """
    valid_conditions = ("gt", "lt", "gte", "lte", "eq")
    if condition not in valid_conditions:
        raise ValueError(
            f"Invalid condition: {condition}. Must be one of {valid_conditions}"
        )
    valid_channels = ("email", "slack", "pagerduty")
    if channel not in valid_channels:
        raise ValueError(
            f"Invalid channel: {channel}. Must be one of {valid_channels}"
        )
    config_json = json.dumps(channel_config or {})
    with get_connection() as conn:
        cursor = conn.execute(
            "INSERT INTO alert_rules "
            "(project_id, name, metric_name, condition, threshold, "
            " channel, channel_config) "
            "VALUES (?, ?, ?, ?, ?, ?, ?)",
            (
                project_id,
                name,
                metric_name,
                condition,
                threshold,
                channel,
                config_json,
            ),
        )
        conn.commit()
        rule_id = cursor.lastrowid
        return {
            "id": rule_id,
            "project_id": project_id,
            "name": name,
            "metric_name": metric_name,
            "condition": condition,
            "threshold": threshold,
            "channel": channel,
        }


def list_alert_rules(project_id: int) -> list[dict[str, Any]]:
    with get_connection() as conn:
        rows = conn.execute(
            "SELECT id, name, metric_name, condition, threshold, "
            "  channel, enabled, created_at "
            "FROM alert_rules "
            "WHERE project_id = ? "
            "ORDER BY created_at DESC",
            (project_id,),
        ).fetchall()
        return [dict(r) for r in rows]


def delete_alert_rule(rule_id: int, project_id: int) -> bool:
    with get_connection() as conn:
        cursor = conn.execute(
            "DELETE FROM alert_rules WHERE id = ? AND project_id = ?",
            (rule_id, project_id),
        )
        conn.commit()
        return cursor.rowcount > 0


def evaluate_rule(rule: dict[str, Any], current_value: float) -> bool:
    """Check if a rule's condition is met against the current value."""
    threshold = rule["threshold"]
    condition = rule["condition"]
    if condition == "gt":
        return current_value > threshold
    if condition == "lt":
        return current_value < threshold
    if condition == "gte":
        return current_value >= threshold
    if condition == "lte":
        return current_value <= threshold
    if condition == "eq":
        return current_value == threshold
    return False


def _get_current_metric_value(
    project_id: int, metric_name: str
) -> float | None:
    """Get the most recent value for a metric."""
    with get_connection() as conn:
        row = conn.execute(
            "SELECT value FROM metrics "
            "WHERE project_id = ? AND name = ? "
            "ORDER BY timestamp DESC LIMIT 1",
            (project_id, metric_name),
        ).fetchone()
        return row["value"] if row else None


def record_firing(
    rule_id: int, triggered_value: float, message: str
) -> None:
    """Write an alert firing to the DB. Does not send any notification."""
    with get_connection() as conn:
        conn.execute(
            "INSERT INTO alert_notifications "
            "(rule_id, triggered_value, message) "
            "VALUES (?, ?, ?)",
            (rule_id, triggered_value, message),
        )
        conn.commit()


def evaluate_alerts(project_id: int) -> list[dict[str, Any]]:
    """Evaluate all enabled alert rules for a project.

    Returns list of triggered alerts with details.
    """
    rules = list_alert_rules(project_id)
    triggered = []
    for rule in rules:
        if not rule.get("enabled", True):
            continue
        current = _get_current_metric_value(project_id, rule["metric_name"])
        if current is None:
            continue
        if evaluate_rule(rule, current):
            msg = (
                f"Alert '{rule['name']}': "
                f"{rule['metric_name']} is {current} "
                f"({rule['condition']} {rule['threshold']})"
            )
            record_firing(rule["id"], current, msg)
            triggered.append(
                {
                    "rule_id": rule["id"],
                    "rule_name": rule["name"],
                    "metric_name": rule["metric_name"],
                    "current_value": current,
                    "threshold": rule["threshold"],
                    "message": msg,
                }
            )
    return triggered
