"""FastAPI application entry point for forge-dashboard."""

from __future__ import annotations

import asyncio
import hmac
import os
from contextlib import asynccontextmanager
from typing import Any

from fastapi import Depends, FastAPI, Header, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

from backend import alerts, auth, ingest, query
from backend.db import init_db
from backend.scheduler import alert_loop, retention_loop


class CreateAlertRequest(BaseModel):
    name: str
    metric_name: str
    condition: str
    threshold: float
    channel: str = "email"
    channel_config: dict[str, Any] | None = None


class CreateUserRequest(BaseModel):
    email: str


class CreateProjectRequest(BaseModel):
    name: str
    owner_id: int


@asynccontextmanager
async def lifespan(app: FastAPI):
    init_db()
    alert_task = asyncio.create_task(alert_loop())
    retention_task = asyncio.create_task(retention_loop())
    yield
    alert_task.cancel()
    retention_task.cancel()
    for task in (alert_task, retention_task):
        try:
            await task
        except asyncio.CancelledError:
            pass


app = FastAPI(title="forge-dashboard", version="0.1.0", lifespan=lifespan)

_cors_origins = os.getenv("FORGE_CORS_ORIGINS", "http://localhost:5173").split(",")
app.add_middleware(
    CORSMiddleware,
    allow_origins=_cors_origins,
    allow_credentials=True,
    allow_methods=["GET", "POST", "DELETE", "OPTIONS"],
    allow_headers=["Authorization", "Content-Type", "X-API-Key"],
)


def require_project(
    x_api_key: str = Header(..., alias="X-API-Key"),
) -> int:
    project_id = auth.validate_api_key(x_api_key)
    if project_id is None:
        raise HTTPException(status_code=401, detail="Invalid API key")
    return project_id


def _check_setup_secret(
    authorization: str = Header(..., alias="Authorization"),
) -> None:
    secret = os.getenv("FORGE_SETUP_SECRET")
    if secret is None:
        raise HTTPException(
            status_code=403,
            detail="Setup endpoints disabled. Set FORGE_SETUP_SECRET to enable.",
        )
    expected = f"Bearer {secret}"
    if not hmac.compare_digest(authorization, expected):
        raise HTTPException(status_code=401, detail="Invalid setup secret")


@app.post("/v1/traces")
async def ingest_traces(
    body: dict[str, Any],
    project_id: int = Depends(require_project),
) -> dict[str, Any]:
    spans = ingest.parse_otlp_spans(body)
    count = await asyncio.to_thread(ingest.store_spans, project_id, spans)
    return {"status": "ok", "spans_stored": count}


@app.post("/v1/metrics")
async def ingest_metrics(
    body: dict[str, Any],
    project_id: int = Depends(require_project),
) -> dict[str, Any]:
    metrics = ingest.parse_otlp_metrics(body)
    count = await asyncio.to_thread(ingest.store_metrics, project_id, metrics)
    return {"status": "ok", "metrics_stored": count}


@app.get("/v1/sessions")
def list_sessions(
    limit: int = 50,
    offset: int = 0,
    project_id: int = Depends(require_project),
) -> list[dict[str, Any]]:
    return query.get_sessions(project_id, limit=limit, offset=offset)


@app.get("/v1/sessions/{trace_id}")
def get_session(
    trace_id: str,
    project_id: int = Depends(require_project),
) -> list[dict[str, Any]]:
    return query.get_session_spans(project_id, trace_id)


@app.get("/v1/budget")
def budget_over_time(
    trace_id: str | None = None,
    project_id: int = Depends(require_project),
) -> list[dict[str, Any]]:
    return query.get_budget_over_time(project_id, trace_id=trace_id)


@app.get("/v1/token-split")
def token_split(
    trace_id: str | None = None,
    project_id: int = Depends(require_project),
) -> dict[str, float]:
    return query.get_token_split(project_id, trace_id=trace_id)


@app.get("/v1/mode-switches")
def mode_switches(
    trace_id: str | None = None,
    limit: int = 100,
    project_id: int = Depends(require_project),
) -> list[dict[str, Any]]:
    return query.get_mode_switches(project_id, trace_id=trace_id, limit=limit)


@app.get("/v1/preserve-thinking")
def preserve_thinking_stats(
    project_id: int = Depends(require_project),
) -> dict[str, Any]:
    return query.get_preserve_thinking_stats(project_id)


@app.post("/v1/alerts")
def create_alert(
    body: CreateAlertRequest,
    project_id: int = Depends(require_project),
) -> dict[str, Any]:
    try:
        return alerts.create_alert_rule(
            project_id=project_id,
            name=body.name,
            metric_name=body.metric_name,
            condition=body.condition,
            threshold=body.threshold,
            channel=body.channel,
            channel_config=body.channel_config,
        )
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc


@app.get("/v1/alerts")
def list_alerts(
    project_id: int = Depends(require_project),
) -> list[dict[str, Any]]:
    return alerts.list_alert_rules(project_id)


@app.delete("/v1/alerts/{rule_id}")
def delete_alert(
    rule_id: int,
    project_id: int = Depends(require_project),
) -> dict[str, Any]:
    deleted = alerts.delete_alert_rule(rule_id, project_id)
    if not deleted:
        raise HTTPException(status_code=404, detail="Alert rule not found")
    return {"status": "deleted"}


@app.post("/v1/alerts/evaluate")
def evaluate_project_alerts(
    project_id: int = Depends(require_project),
) -> list[dict[str, Any]]:
    return alerts.evaluate_alerts(project_id)


@app.post("/v1/users")
def create_user(
    body: CreateUserRequest,
    _: None = Depends(_check_setup_secret),
) -> dict[str, Any]:
    return auth.create_user(body.email)


@app.post("/v1/projects")
def create_project(
    body: CreateProjectRequest,
    _: None = Depends(_check_setup_secret),
) -> dict[str, Any]:
    return auth.create_project(body.name, body.owner_id)


@app.get("/v1/billing/status")
def billing_status(
    project_id: int = Depends(require_project),
) -> dict[str, Any]:
    retention_days = int(os.getenv("FORGE_RETENTION_DAYS", "7"))
    return {
        "project_id": project_id,
        "plan": "free",
        "status": "stub",
        "data_retention_days": retention_days,
        "max_projects": 1,
    }


@app.get("/health")
def health() -> dict[str, str]:
    return {"status": "ok"}


def main():
    import uvicorn

    uvicorn.run("backend.main:app", host="127.0.0.1", port=8000, reload=True)


if __name__ == "__main__":
    main()
