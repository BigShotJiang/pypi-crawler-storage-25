"""Authentication and authorization.

Manages users, projects, API keys, and team membership.
"""

from __future__ import annotations

import hashlib
import secrets
from typing import Any

from backend.db import get_connection


def _hash_key(raw_key: str) -> str:
    return hashlib.sha256(raw_key.encode()).hexdigest()


def create_user(email: str) -> dict[str, Any]:
    """Create a new user. Returns the user row as a dict."""
    with get_connection() as conn:
        conn.execute(
            "INSERT INTO users (email) VALUES (?)", (email,)
        )
        conn.commit()
        row = conn.execute(
            "SELECT id, email, created_at FROM users WHERE email = ?",
            (email,),
        ).fetchone()
        return dict(row)


def create_project(name: str, owner_id: int) -> dict[str, Any]:
    """Create a project and generate an API key for it."""
    raw_key = "fd_" + secrets.token_hex(24)
    key_hash = _hash_key(raw_key)
    with get_connection() as conn:
        cursor = conn.execute(
            "INSERT INTO projects (name, owner_id) VALUES (?, ?)",
            (name, owner_id),
        )
        project_id = cursor.lastrowid
        conn.execute(
            "INSERT INTO api_keys (project_id, key_hash, key_prefix) "
            "VALUES (?, ?, ?)",
            (project_id, key_hash, raw_key[:10]),
        )
        conn.commit()
        row = conn.execute(
            "SELECT id, name, owner_id, created_at FROM projects WHERE id = ?",
            (project_id,),
        ).fetchone()
        result = dict(row)
        result["api_key"] = raw_key
        return result


def validate_api_key(raw_key: str) -> int | None:
    """Validate an API key. Returns the project_id if valid, else None."""
    key_hash = _hash_key(raw_key)
    with get_connection() as conn:
        row = conn.execute(
            "SELECT project_id FROM api_keys "
            "WHERE key_hash = ? AND revoked = 0",
            (key_hash,),
        ).fetchone()
        return row["project_id"] if row else None


