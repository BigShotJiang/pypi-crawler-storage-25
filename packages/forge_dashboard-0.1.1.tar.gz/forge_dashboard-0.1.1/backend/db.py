"""Database connection and schema management. SQLite only."""

from __future__ import annotations

import os
import sqlite3
from contextlib import contextmanager
from pathlib import Path
from typing import Generator

MIGRATIONS_DIR = Path(__file__).resolve().parent.parent / "migrations"


def _get_sqlite_path() -> str:
    return os.getenv("SQLITE_PATH", "forge_dashboard.db")


def _get_sqlite_connection() -> sqlite3.Connection:
    conn = sqlite3.connect(_get_sqlite_path())
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")
    return conn


@contextmanager
def get_connection() -> Generator[sqlite3.Connection, None, None]:
    """Yield a database connection. SQLite only for now."""
    conn = _get_sqlite_connection()
    try:
        yield conn
    finally:
        conn.close()


def run_migrations() -> None:
    """Run all SQL migration files in order."""
    if not MIGRATIONS_DIR.exists():
        return
    migration_files = sorted(MIGRATIONS_DIR.glob("*.sql"))
    with get_connection() as conn:
        conn.execute(
            "CREATE TABLE IF NOT EXISTS _migrations ("
            "  filename TEXT PRIMARY KEY,"
            "  applied_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP"
            ")"
        )
        for mf in migration_files:
            row = conn.execute(
                "SELECT 1 FROM _migrations WHERE filename = ?", (mf.name,)
            ).fetchone()
            if row:
                continue
            sql = mf.read_text(encoding="utf-8")
            conn.executescript(sql)
            conn.execute(
                "INSERT INTO _migrations (filename) VALUES (?)", (mf.name,)
            )
            conn.commit()


def init_db() -> None:
    """Initialize database and run pending migrations."""
    run_migrations()
