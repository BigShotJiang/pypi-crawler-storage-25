"""OTLP data ingestion.

Receives spans and metrics from forge-observe (via OTLP/HTTP)
and writes them to the database.
"""

from __future__ import annotations

import json
from datetime import datetime, timezone
from typing import Any

from backend.db import get_connection


def store_spans(project_id: int, spans: list[dict[str, Any]]) -> int:
    """Store a batch of spans. Returns number of rows inserted."""
    if not spans:
        return 0
    with get_connection() as conn:
        count = 0
        for span in spans:
            conn.execute(
                "INSERT INTO spans "
                "(project_id, trace_id, span_id, parent_span_id, "
                " name, kind, start_time, end_time, attributes, "
                " status_code, status_message) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                (
                    project_id,
                    span.get("trace_id", ""),
                    span.get("span_id", ""),
                    span.get("parent_span_id"),
                    span.get("name", ""),
                    span.get("kind", ""),
                    span.get("start_time", ""),
                    span.get("end_time", ""),
                    json.dumps(span.get("attributes", {})),
                    span.get("status_code", "OK"),
                    span.get("status_message", ""),
                ),
            )
            count += 1
        conn.commit()
        return count


def store_metrics(project_id: int, metrics: list[dict[str, Any]]) -> int:
    """Store a batch of metric data points. Returns rows inserted."""
    if not metrics:
        return 0
    with get_connection() as conn:
        count = 0
        for m in metrics:
            conn.execute(
                "INSERT INTO metrics "
                "(project_id, name, value, unit, attributes, timestamp) "
                "VALUES (?, ?, ?, ?, ?, ?)",
                (
                    project_id,
                    m.get("name", ""),
                    m.get("value", 0.0),
                    m.get("unit", ""),
                    json.dumps(m.get("attributes", {})),
                    m.get("timestamp", datetime.now(timezone.utc).isoformat()),
                ),
            )
            count += 1
        conn.commit()
        return count


def parse_otlp_spans(payload: dict[str, Any]) -> list[dict[str, Any]]:
    """Parse an OTLP ExportTraceServiceRequest JSON payload into flat spans."""
    spans: list[dict[str, Any]] = []
    for resource_spans in payload.get("resourceSpans", []):
        resource_attrs = {}
        resource = resource_spans.get("resource", {})
        for attr in resource.get("attributes", []):
            resource_attrs[attr["key"]] = _extract_value(attr.get("value", {}))

        for scope_spans in resource_spans.get("scopeSpans", []):
            for span in scope_spans.get("spans", []):
                attrs = dict(resource_attrs)
                for attr in span.get("attributes", []):
                    attrs[attr["key"]] = _extract_value(
                        attr.get("value", {})
                    )
                spans.append(
                    {
                        "trace_id": span.get("traceId", ""),
                        "span_id": span.get("spanId", ""),
                        "parent_span_id": span.get("parentSpanId"),
                        "name": span.get("name", ""),
                        "kind": str(span.get("kind", "")),
                        "start_time": span.get("startTimeUnixNano", ""),
                        "end_time": span.get("endTimeUnixNano", ""),
                        "attributes": attrs,
                        "status_code": span.get("status", {}).get(
                            "code", "OK"
                        ),
                        "status_message": span.get("status", {}).get(
                            "message", ""
                        ),
                    }
                )
    return spans


def parse_otlp_metrics(payload: dict[str, Any]) -> list[dict[str, Any]]:
    """Parse an OTLP ExportMetricsServiceRequest JSON payload."""
    results: list[dict[str, Any]] = []
    for resource_metrics in payload.get("resourceMetrics", []):
        resource_attrs = {}
        resource = resource_metrics.get("resource", {})
        for attr in resource.get("attributes", []):
            resource_attrs[attr["key"]] = _extract_value(attr.get("value", {}))

        for scope_metrics in resource_metrics.get("scopeMetrics", []):
            for metric in scope_metrics.get("metrics", []):
                name = metric.get("name", "")
                unit = metric.get("unit", "")
                # Handle gauge and sum data points
                for key in ("gauge", "sum"):
                    data = metric.get(key, {})
                    for dp in data.get("dataPoints", []):
                        attrs = dict(resource_attrs)
                        for attr in dp.get("attributes", []):
                            attrs[attr["key"]] = _extract_value(
                                attr.get("value", {})
                            )
                        value = dp.get(
                            "asDouble", dp.get("asInt", 0)
                        )
                        results.append(
                            {
                                "name": name,
                                "value": float(value),
                                "unit": unit,
                                "attributes": attrs,
                                "timestamp": dp.get(
                                    "timeUnixNano", ""
                                ),
                            }
                        )
    return results


def _extract_value(value_obj: dict[str, Any]) -> Any:
    """Extract a scalar from an OTLP AnyValue."""
    for key in ("stringValue", "intValue", "doubleValue", "boolValue"):
        if key in value_obj:
            return value_obj[key]
    return str(value_obj)
