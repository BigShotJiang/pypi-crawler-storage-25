# 🛠️ runfix

A lightweight, smart CLI tool that executes commands, intercepts errors, and provides instant solutions.

[TR: Türkçe döküman için buraya tıklayın.](README.TR.MD)

---

## 🚀 Overview

`runfix` is designed for developers who want to stay in the flow. Instead of manually copying error logs to search for solutions, `runfix` analyzes the `stderr` output and offers a one-click fix.

## ✨ Key Features

- **Runtime Analysis:** Uses regex-based parsing to identify core error types (e.g., `ModuleNotFoundError`, `SyntaxError`).
- **One-Click Fix:** Automatically suggests and executes recovery commands like `pip install`.
- **Localization:** Supports multiple languages for error explanations.
- **Minimalist:** No heavy dependencies. Pure Python power.

## 📦 Installation

You can install **runfix** directly from PyPI:

```bash
pip install runfix
```
## ⚙️ Configuration

Change the output language:
```bash
runfix config --lang tr  # For Turkish
runfix config --lang en  # For English
```
## 💡 Quick Start
Simply wrap your usual command with `runfix` run:
```bash
runfix run "python your_script.py"
```
## 📜 License
MIT

