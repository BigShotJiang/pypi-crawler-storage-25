import re

TRANSLATIONS = {
    "tr": {
        "missing_pkg": "Eksik paket bulundu: {pkg}. Yüklemek ister misin?",
        "syntax_err": "Sözdizimi (Syntax) hatası tespit edildi. Kodu kontrol et.",
        "unknown": "Bu hata için henüz bir çözüm kuralım yok."
    },
    "en": {
        "missing_pkg": "Missing package: {pkg}. Would you like to install it?",
        "syntax_err": "Syntax error detected. Please check your code.",
        "unknown": "I don't have a solution rule for this error yet."
    }
}

def resolve(err_type, msg, lang="en"):
    t = TRANSLATIONS.get(lang, TRANSLATIONS["en"])

    if err_type == "ModuleNotFoundError":
        pkg_match = re.search(r"named '(.+)'", msg)
        pkg = pkg_match.group(1) if pkg_match else "unknown"
        return f"pip install {pkg}", t["missing_pkg"].format(pkg=pkg)

    if err_type == "SyntaxError":
        return None, t["syntax_err"]

    return None, t["unknown"]