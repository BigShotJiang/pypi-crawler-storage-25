import json
import os

SETTINGS_FILE = os.path.expanduser("~/.runfix_settings.json")

def get_lang():
    if os.path.exists(SETTINGS_FILE):
        try:
            with open(SETTINGS_FILE, "r") as f:
                return json.load(f).get("lang", "en")
        except: pass
    return "en"

def set_lang(lang):
    with open(SETTINGS_FILE, "w") as f:
        json.dump({"lang": lang}, f)
    print(f"[*] Dil ayarı kaydedildi: {lang}")