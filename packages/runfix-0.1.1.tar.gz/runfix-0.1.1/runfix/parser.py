import re

def get_error_details(stderr):
    if not stderr:
        return {"type": "Unknown", "msg": "No error output"}

    match = re.search(r"(\w+Error): (.+)", stderr)

    if match:
        return {
            "type": match.group(1),
            "msg": match.group(2).strip()
        }

    lines = [l for l in stderr.strip().split('\n') if l.strip()]
    return {
        "type": "RuntimeError",
        "msg": lines[-1] if lines else "Bilinmeyen hata"
    }