import subprocess

def apply(cmd):
    ans = input(f"\n? Çözüm komutu uygulansın mı: '{cmd}'? [y/N] ").lower()
    if ans == 'y':
        print(f"-> Uygulanıyor: {cmd}")
        try:
            subprocess.run(cmd, shell=True, check=True)
            print("OK: Çözüm başarıyla uygulandı.")
        except:
            print("HATA: Komut çalışırken bir sorun oluştu.")