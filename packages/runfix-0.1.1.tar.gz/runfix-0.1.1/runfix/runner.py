import subprocess

def exec_cmd(cmd):
    try:
        proc = subprocess.run(
            cmd,
            shell=True,
            capture_output=True,
            text=True
        )
        return {
            "out": proc.stdout,
            "err": proc.stderr,
            "code": proc.returncode
        }
    except Exception as e:
        return {"out": "", "err": str(e), "code": 1}