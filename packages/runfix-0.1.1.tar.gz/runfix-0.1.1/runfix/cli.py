import argparse
import sys
from . import runner, parser, rules, fixer, utils


def main():
    p = argparse.ArgumentParser(
        prog="runfix",
        description="runfix: Komut hatalarını analiz eder ve çözüm sunar."
    )
    p.add_argument('-v', '--version', action='version', version='runfix 0.1.1')

    sub = p.add_subparsers(dest="cmd")

    run_p = sub.add_parser("run", help="Bir komutu çalıştırır (Örn: runfix run python app.py)")
    run_p.add_argument("target", nargs='+', help="Çalıştırılacak komut ve argümanları")

    cfg_p = sub.add_parser("config", help="Ayarları yapılandırır")
    cfg_p.add_argument("--lang", choices=["tr", "en"], help="Dili değiştir (tr/en)")

    args = p.parse_args()

    if not args.cmd:
        p.print_help()
        return

    lang = utils.get_lang()

    if args.cmd == "config":
        if args.lang:
            utils.set_lang(args.lang)
        else:
            print(f"[*] Mevcut dil: {lang}")
        return

    if args.cmd == "run":
        full_command = " ".join(args.target)
        res = runner.exec_cmd(full_command)

        if res["code"] == 0:
            if res["out"]: print(res["out"])
            sys.exit(0)

        info = parser.get_error_details(res["err"])
        fix_cmd, note = rules.resolve(info["type"], info["msg"], lang)

        print(f"\n[!] Hata Tipi: {info['type']}")
        print(f"[*] Mesaj: {info['msg']}")
        print(f"[*] Öneri: {note}")

        if fix_cmd:
            fixer.apply(fix_cmd)


if __name__ == "__main__":
    main()