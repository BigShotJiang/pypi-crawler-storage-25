"""Tests for VRIN MCP authentication (v2 key format)."""

import pytest

from vrin_mcp.auth.api_key import (
    AuthError,
    validate_key_format,
)


# V2 fixtures — 32-char base62 suffix
_SUFFIX_32 = "A" * 32
_SUFFIX_32_MIXED = "dxLk2nT8qJFY9sPmW3vHxR7cB4eGaZ6y"


class TestKeyFormatValidation:
    """Tests for v2 API key format validation."""

    def test_valid_standard_live_key(self):
        assert validate_key_format(f"vrin_live_{_SUFFIX_32}") is True
        assert validate_key_format(f"vrin_live_{_SUFFIX_32_MIXED}") is True

    def test_valid_standard_dev_key(self):
        assert validate_key_format(f"vrin_dev_{_SUFFIX_32}") is True
        assert validate_key_format(f"vrin_dev_{_SUFFIX_32_MIXED}") is True

    def test_valid_enterprise_live_keys(self):
        # All 3 deployment modes with live env
        assert validate_key_format(f"vrin_ent_la_{_SUFFIX_32}") is True  # live + airgap
        assert validate_key_format(f"vrin_ent_lv_{_SUFFIX_32}") is True  # live + vpc
        assert validate_key_format(f"vrin_ent_lh_{_SUFFIX_32}") is True  # live + hybrid

    def test_valid_enterprise_dev_keys(self):
        # All 3 deployment modes with dev env
        assert validate_key_format(f"vrin_ent_da_{_SUFFIX_32}") is True
        assert validate_key_format(f"vrin_ent_dv_{_SUFFIX_32}") is True
        assert validate_key_format(f"vrin_ent_dh_{_SUFFIX_32}") is True

    def test_invalid_key_no_prefix(self):
        assert validate_key_format("1234567890abcdef") is False
        assert validate_key_format("api_1234567890abcdef") is False

    def test_invalid_key_wrong_prefix(self):
        assert validate_key_format("openai_1234567890abcdef") is False
        assert validate_key_format(f"sk_live_{_SUFFIX_32}") is False

    def test_invalid_v1_format_rejected(self):
        """Old v1 format (vrin_<16hex>) must not be accepted under v2."""
        assert validate_key_format("vrin_4926d56cff3a2adc") is False
        assert validate_key_format("vrin_ff2160037c6a1afb") is False
        assert validate_key_format("vrin_cdbff10916448fe4") is False

    def test_invalid_old_enterprise_format_rejected(self):
        """Old vrin_ent_<20hex> format must not be accepted under v2."""
        assert validate_key_format(f"vrin_ent_{_SUFFIX_32}") is False  # no discrim
        assert validate_key_format(f"vrin_ent_airgap_{_SUFFIX_32}") is False  # old word
        assert validate_key_format(f"vrin_ent_vpc_{_SUFFIX_32}") is False
        assert validate_key_format(f"vrin_ent_hybrid_{_SUFFIX_32}") is False

    def test_invalid_env_words(self):
        """'prod', 'test', 'sandbox' are not valid env discriminators."""
        assert validate_key_format(f"vrin_prod_{_SUFFIX_32}") is False
        assert validate_key_format(f"vrin_test_{_SUFFIX_32}") is False
        assert validate_key_format(f"vrin_sandbox_{_SUFFIX_32}") is False

    def test_invalid_enterprise_discriminators(self):
        """Env must be [ld], deploy must be [avh]."""
        assert validate_key_format(f"vrin_ent_xa_{_SUFFIX_32}") is False  # bad env
        assert validate_key_format(f"vrin_ent_lz_{_SUFFIX_32}") is False  # bad deploy
        assert validate_key_format(f"vrin_ent_AA_{_SUFFIX_32}") is False  # uppercase

    def test_invalid_key_too_short(self):
        assert validate_key_format("vrin_live_abc") is False
        assert validate_key_format(f"vrin_live_{'A' * 31}") is False  # 31, not 32
        assert validate_key_format(f"vrin_ent_la_{'A' * 16}") is False

    def test_invalid_key_too_long(self):
        assert validate_key_format(f"vrin_live_{'A' * 33}") is False

    def test_invalid_key_non_base62(self):
        """Base62 alphabet is [0-9A-Za-z] only — no '-', '_', '+', '/'."""
        assert validate_key_format(f"vrin_live_{'A' * 30}-A") is False
        assert validate_key_format(f"vrin_live_{'A' * 30}_A") is False
        assert validate_key_format(f"vrin_live_{'A' * 30}+A") is False
        assert validate_key_format(f"vrin_ent_la_{'A' * 30}/A") is False

    def test_invalid_key_empty(self):
        assert validate_key_format("") is False
        assert validate_key_format(None) is False


class TestAuthError:
    """Tests for AuthError exception."""

    def test_auth_error_message(self):
        error = AuthError("Test error message")
        assert str(error) == "Test error message"

    def test_auth_error_is_exception(self):
        assert issubclass(AuthError, Exception)

    def test_auth_error_can_be_raised(self):
        with pytest.raises(AuthError) as exc_info:
            raise AuthError("Missing API key")
        assert "Missing API key" in str(exc_info.value)
