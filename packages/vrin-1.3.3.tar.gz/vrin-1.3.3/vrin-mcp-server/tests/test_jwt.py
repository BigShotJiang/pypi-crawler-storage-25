"""Tests for JWT validation and dual auth context."""

import pytest

from vrin_mcp.auth.context import (
    extract_bearer_token,
    is_jwt,
    set_auth_info,
    get_auth_info,
    clear_auth_info,
)
from vrin_mcp.auth.jwt_validator import JWTValidationError, StytchJWTValidator


class TestIsJWT:
    """Tests for JWT detection heuristic."""

    def test_valid_jwt_format(self):
        """Test valid JWT format detection."""
        # JWTs always start with eyJ (base64 of {"...)
        assert is_jwt("eyJhbGciOiJSUzI1NiJ9.eyJzdWIiOiJ0ZXN0In0.signature") is True

    def test_api_key_not_jwt(self):
        """Test VRiN API key is not detected as JWT."""
        assert is_jwt("vrin_1234567890abcdef") is False
        assert is_jwt("vrin_ent_1234567890abcdef") is False

    def test_random_string_not_jwt(self):
        """Test random strings are not detected as JWT."""
        assert is_jwt("not-a-jwt") is False
        assert is_jwt("abc.def.ghi") is False  # doesn't start with ey

    def test_incomplete_jwt_not_detected(self):
        """Test incomplete JWT format."""
        assert is_jwt("eyJhbGciOiJSUzI1NiJ9.payload") is False  # only 1 dot
        assert is_jwt("eyJhbGciOiJSUzI1NiJ9") is False  # no dots


class TestExtractBearerToken:
    """Tests for bearer token extraction."""

    def test_bearer_with_api_key(self):
        """Test extracting VRiN API key from Bearer header."""
        assert extract_bearer_token("Bearer vrin_test123") == "vrin_test123"

    def test_bearer_with_jwt(self):
        """Test extracting JWT from Bearer header."""
        jwt_token = "eyJhbGciOiJSUzI1NiJ9.eyJzdWIiOiJ0ZXN0In0.sig"
        assert extract_bearer_token(f"Bearer {jwt_token}") == jwt_token

    def test_direct_api_key(self):
        """Test extracting API key without Bearer prefix."""
        assert extract_bearer_token("vrin_test123") == "vrin_test123"

    def test_none_header(self):
        """Test None authorization header."""
        assert extract_bearer_token(None) is None

    def test_empty_header(self):
        """Test empty authorization header."""
        assert extract_bearer_token("") is None

    def test_invalid_scheme(self):
        """Test non-Bearer scheme."""
        assert extract_bearer_token("Basic dXNlcjpwYXNz") is None


class TestAuthInfo:
    """Tests for auth metadata context variable."""

    def test_set_and_get_auth_info(self):
        """Test setting and getting auth info."""
        info = {"method": "api_key", "key_type": "standard"}
        set_auth_info(info)
        assert get_auth_info() == info
        clear_auth_info()

    def test_auth_info_default_none(self):
        """Test auth info defaults to None."""
        clear_auth_info()
        assert get_auth_info() is None

    def test_clear_auth_info(self):
        """Test clearing auth info."""
        set_auth_info({"method": "jwt"})
        clear_auth_info()
        assert get_auth_info() is None


class TestJWTValidator:
    """Tests for StytchJWTValidator."""

    def test_not_configured_without_env(self):
        """Test validator reports not configured without env vars."""
        validator = StytchJWTValidator(project_id="", jwks_url="")
        assert validator.is_configured is False

    def test_configured_with_project_id(self):
        """Test validator is configured with project ID."""
        validator = StytchJWTValidator(project_id="project-test-123")
        assert validator.is_configured is True

    def test_configured_with_jwks_url(self):
        """Test validator is configured with explicit JWKS URL."""
        validator = StytchJWTValidator(
            jwks_url="https://test.stytch.com/v1/sessions/jwks/test"
        )
        assert validator.is_configured is True

    @pytest.mark.asyncio
    async def test_validate_rejects_garbage(self):
        """Test validation rejects non-JWT input."""
        validator = StytchJWTValidator(project_id="test")
        with pytest.raises(JWTValidationError):
            await validator.validate("not-a-jwt")

    @pytest.mark.asyncio
    async def test_validate_rejects_expired(self):
        """Test validation rejects malformed JWT."""
        # This is a syntactically valid but expired/unsigned JWT
        validator = StytchJWTValidator(project_id="test")
        with pytest.raises(JWTValidationError):
            await validator.validate(
                "eyJhbGciOiJSUzI1NiJ9.eyJzdWIiOiJ0ZXN0IiwiZXhwIjoxfQ.invalid"
            )
