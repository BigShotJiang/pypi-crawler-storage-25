"""VRIN Backend API Client.

This module provides an async HTTP client for communicating with VRIN's
backend APIs. It handles authentication, request formatting, and response
parsing for all VRIN operations.

The client proxies to VRIN's existing Lambda functions rather than
connecting directly to Neptune/OpenSearch, ensuring:
- Proper authentication and authorization
- Enterprise data sovereignty (vrin_ent_ keys route to customer infra)
- Consistent behavior with the VRIN SDK
"""

import logging
import os
from typing import Any, Callable, Optional

import httpx
from pydantic import BaseModel

logger = logging.getLogger(__name__)


class QueryResponse(BaseModel):
    """Response from VRIN query endpoint."""

    success: bool = True
    summary: Optional[str] = None
    answer: Optional[str] = None
    sources: list[dict[str, Any]] = []
    facts_used: int = 0
    reasoning_steps: list[str] = []
    search_time: Optional[str] = None
    error: Optional[str] = None


class EntitySearchResult(BaseModel):
    """Single entity search result."""

    name: str
    type: str = "unknown"
    fact_count: int = 0
    relevance_score: float = 0.0


class SearchResponse(BaseModel):
    """Response from VRIN entity search."""

    success: bool = True
    entities: list[EntitySearchResult] = []
    total: int = 0
    error: Optional[str] = None


class Fact(BaseModel):
    """Single fact from knowledge graph."""

    subject: str
    predicate: str
    object: str
    confidence: float = 1.0
    source_document: Optional[str] = None
    temporal_info: Optional[dict[str, Any]] = None


class FactsResponse(BaseModel):
    """Response from VRIN get facts endpoint."""

    success: bool = True
    entity: str
    facts: list[Fact] = []
    total: int = 0
    error: Optional[str] = None


class StatsResponse(BaseModel):
    """Response from VRIN stats endpoint."""

    success: bool = True
    total_entities: int = 0
    total_facts: int = 0
    total_documents: int = 0
    graph_statistics: dict[str, Any] = {}
    error: Optional[str] = None


class ContextResponse(BaseModel):
    """Response from VRIN context-only retrieval (no LLM generation).

    Returns structured retrieval context and generation guidance for
    host LLMs (ChatGPT, Claude) to generate a single high-quality response.
    """

    success: bool = True
    structured_context: str = ""
    reasoning_insights: str = ""
    sources: list[dict[str, Any]] = []
    entities: list[str] = []
    facts_count: int = 0
    chunks_count: int = 0
    generation_guidance: str = ""
    query_depth: str = "basic"
    session_id: Optional[str] = None
    error: Optional[str] = None


class VRINClient:
    """Async client for VRIN backend APIs.

    This client communicates with VRIN's Lambda functions to perform
    knowledge graph operations. It uses the same endpoints as the VRIN SDK.

    Attributes:
        api_key: VRIN API key (vrin_ or vrin_ent_ prefix)
        streaming_url: URL for streaming Lambda
        auth_url: URL for auth API

    Example:
        async with VRINClient("vrin_xxx") as client:
            response = await client.query("What is ACME Corporation?")
            print(response.summary)

        # Or with config:
        from vrin_mcp.config import get_global_config
        config = get_global_config()
        async with VRINClient("vrin_xxx", config=config) as client:
            ...
    """

    def __init__(
        self,
        api_key: str,
        streaming_url: Optional[str] = None,
        auth_url: Optional[str] = None,
        timeout: Optional[float] = None,
        config: Optional[Any] = None,
    ):
        """Initialize VRIN client.

        Args:
            api_key: VRIN API key
            streaming_url: Streaming Lambda URL (overrides config)
            auth_url: Auth API URL (overrides config)
            timeout: Request timeout in seconds (overrides config)
            config: Optional VRINConfig instance for defaults
        """
        self.api_key = api_key

        # Resolve URLs: explicit param > config > hardcoded default
        default_streaming = (
            "https://43tybsfy52ehi3fctubc7jwlpi0fgkcz.lambda-url.us-east-1.on.aws"
        )
        default_auth = "https://gp7g651udc.execute-api.us-east-1.amazonaws.com/Prod"
        default_timeout = float(os.environ.get("VRIN_QUERY_TIMEOUT", "300"))

        if config is not None:
            default_streaming = config.streaming_url
            default_auth = config.auth_url
            default_timeout = config.query_timeout

        self.streaming_url = streaming_url or default_streaming
        self.auth_url = auth_url or default_auth
        self.timeout = timeout or default_timeout
        self._client: Optional[httpx.AsyncClient] = None

    async def __aenter__(self) -> "VRINClient":
        """Enter async context."""
        self._client = httpx.AsyncClient(timeout=self.timeout)
        return self

    async def __aexit__(self, *args) -> None:
        """Exit async context."""
        if self._client:
            await self._client.aclose()
            self._client = None

    @property
    def client(self) -> httpx.AsyncClient:
        """Get HTTP client, creating if needed."""
        if self._client is None:
            self._client = httpx.AsyncClient(timeout=self.timeout)
        return self._client

    def _headers(self) -> dict[str, str]:
        """Get request headers with authentication."""
        return {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
            "User-Agent": "vrin-mcp-server/1.0.0",
        }

    @staticmethod
    def _parse_streaming_response(response: httpx.Response) -> dict[str, Any]:
        """Parse SSE streaming response from Lambda into a single result dict.

        The Lambda returns Server-Sent Events with types: metadata, content, done.
        We collect content deltas and merge with metadata.
        """
        import json as _json

        metadata: dict[str, Any] = {}
        content_parts: list[str] = []

        for line in response.text.splitlines():
            if not line.startswith("data: "):
                continue
            try:
                event = _json.loads(line[6:])
            except _json.JSONDecodeError:
                continue

            event_type = event.get("type", "")
            data = event.get("data", {})

            if event_type == "metadata":
                metadata = data
            elif event_type == "content":
                delta = data.get("delta", "")
                if delta:
                    content_parts.append(delta)
            elif event_type == "done":
                # Final event may contain summary info
                if isinstance(data, dict):
                    metadata.update(data)

        answer = "".join(content_parts)
        sources = metadata.get("sources", [])
        facts_used = metadata.get("total_facts", 0)

        return {
            "success": True,
            "summary": answer,
            "answer": answer,
            "sources": sources,
            "facts_used": facts_used,
            "reasoning_steps": [
                s.get("description", "") for s in metadata.get("thinking_steps", [])
            ],
            "search_time": metadata.get("search_time"),
        }

    async def validate_key(self) -> bool:
        """Validate API key is active and authorized.

        Returns:
            True if key is valid, False otherwise
        """
        try:
            response = await self.client.get(
                f"{self.auth_url}/user/profile",
                headers=self._headers(),
                timeout=10.0,
            )
            return response.status_code == 200
        except httpx.HTTPError as e:
            logger.warning(f"API key validation failed: {e}")
            return False

    async def query(
        self,
        query: str,
        mode: str = "chat",
        include_sources: bool = True,
    ) -> QueryResponse:
        """Query the VRIN knowledge base.

        Args:
            query: Natural language question
            mode: Response mode - 'chat', 'expert', 'raw_facts', 'brainstorm'
            include_sources: Whether to include source documents

        Returns:
            QueryResponse with answer and metadata

        Raises:
            httpx.HTTPError: If request fails
        """
        logger.info(f"Querying VRIN: {query[:100]}...")

        payload = {
            "query": query,
            "response_mode": mode,
            "include_sources": include_sources,
            "stream": False,
        }

        try:
            url = f"{self.streaming_url.rstrip('/')}/query"
            response = await self.client.post(
                url,
                headers=self._headers(),
                json=payload,
            )
            response.raise_for_status()

            # Lambda streams SSE — collect full response
            data = self._parse_streaming_response(response)

            return QueryResponse(
                success=data.get("success", True),
                summary=data.get("summary") or data.get("answer"),
                answer=data.get("answer") or data.get("summary"),
                sources=data.get("sources", []),
                facts_used=data.get("facts_used", 0),
                reasoning_steps=data.get("reasoning_steps", []),
                search_time=data.get("search_time"),
            )
        except httpx.HTTPStatusError as e:
            logger.error(f"Query failed with status {e.response.status_code}")
            return QueryResponse(
                success=False,
                error=f"Query failed: HTTP {e.response.status_code}",
            )
        except Exception as e:
            logger.error(f"Query failed: {type(e).__name__}: {e}")
            return QueryResponse(success=False, error=f"{type(e).__name__}: {e}")

    async def retrieve_context(
        self,
        query: str,
        depth: str = "basic",
        include_sources: bool = True,
    ) -> ContextResponse:
        """Retrieve structured context without LLM generation.

        Returns VRIN's full retrieval pipeline output (graph facts, vector
        chunks, reasoning insights) as structured context for the host LLM
        to generate a single high-quality response.

        Args:
            query: Natural language question
            depth: Query depth — 'basic' (fast), 'thinking' (cross-doc),
                   'research' (exhaustive deep analysis)
            include_sources: Whether to include source documents

        Returns:
            ContextResponse with structured context and generation guidance
        """
        logger.info(f"Retrieving context: {query[:100]}... depth={depth}")

        payload = {
            "query": query,
            "response_mode": "context",
            "query_depth": depth,
            "include_sources": include_sources,
            "stream": True,
        }

        try:
            url = f"{self.streaming_url.rstrip('/')}/query"
            response = await self.client.post(
                url,
                headers=self._headers(),
                json=payload,
            )
            response.raise_for_status()

            # Context mode returns either:
            # - JSON directly (Lambda handler path)
            # - SSE with a 'context' event (FastAPI streaming path)
            content_type = response.headers.get("content-type", "")
            if "application/json" in content_type:
                data = response.json()
            else:
                # Parse SSE: look for the 'context' event type
                data = {}
                import json as _json

                for line in response.text.splitlines():
                    if not line.startswith("data: "):
                        continue
                    try:
                        event = _json.loads(line[6:])
                    except _json.JSONDecodeError:
                        continue
                    if event.get("type") == "context":
                        data = event.get("data", {})
                        break

            return ContextResponse(
                success=data.get("success", True),
                structured_context=data.get("structured_context", ""),
                reasoning_insights=data.get("reasoning_insights", ""),
                sources=data.get("sources", []),
                entities=data.get("entities", []),
                facts_count=data.get("facts_count", 0),
                chunks_count=data.get("chunks_count", 0),
                generation_guidance=data.get("generation_guidance", ""),
                query_depth=data.get("query_depth", depth),
                session_id=data.get("session_id"),
            )
        except httpx.HTTPStatusError as e:
            logger.error(f"Context retrieval failed with status {e.response.status_code}")
            return ContextResponse(
                success=False,
                error=f"Context retrieval failed: HTTP {e.response.status_code}",
            )
        except Exception as e:
            logger.error(f"Context retrieval failed: {type(e).__name__}: {e}")
            return ContextResponse(success=False, error=f"{type(e).__name__}: {e}")

    async def retrieve_context_with_progress(
        self,
        query: str,
        depth: str = "basic",
        include_sources: bool = True,
        on_progress: Optional[Callable] = None,
    ) -> ContextResponse:
        """Retrieve context with progress event callbacks.

        Like retrieve_context() but uses httpx streaming to capture
        progress events and forward them via on_progress callback.
        Falls back to non-streaming if streaming fails.
        """
        logger.info(f"Retrieving context with progress: {query[:100]}... depth={depth}")

        payload = {
            "query": query,
            "response_mode": "context",
            "query_depth": depth,
            "include_sources": include_sources,
            "stream": True,
        }

        try:
            url = f"{self.streaming_url.rstrip('/')}/query"

            # Use httpx streaming to parse SSE events in real-time
            async with self.client.stream(
                "POST",
                url,
                headers=self._headers(),
                json=payload,
            ) as response:
                response.raise_for_status()

                data = {}
                async for line in response.aiter_lines():
                    if not line.startswith("data: "):
                        continue
                    try:
                        import json as _json

                        event = _json.loads(line[6:])
                    except (ValueError, _json.JSONDecodeError):
                        continue

                    event_type = event.get("type")

                    if event_type == "progress" and on_progress:
                        await on_progress(event.get("data", {}))
                    elif event_type == "context":
                        data = event.get("data", {})
                    elif event_type == "metadata":
                        # Store metadata but keep looking for context event
                        if not data:
                            data = event.get("data", {})

            return ContextResponse(
                success=data.get("success", True),
                structured_context=data.get("structured_context", ""),
                reasoning_insights=data.get("reasoning_insights", ""),
                sources=data.get("sources", []),
                entities=data.get("entities", []),
                facts_count=data.get("facts_count", 0),
                chunks_count=data.get("chunks_count", 0),
                generation_guidance=data.get("generation_guidance", ""),
                query_depth=data.get("query_depth", depth),
                session_id=data.get("session_id"),
            )
        except Exception as e:
            logger.warning(f"Streaming context retrieval failed, falling back: {e}")
            # Fall back to non-streaming
            return await self.retrieve_context(query, depth, include_sources)

    async def search_entities(
        self,
        entity_name: str,
        limit: int = 10,
    ) -> SearchResponse:
        """Search for entities in the knowledge graph.

        Args:
            entity_name: Name or partial name to search
            limit: Maximum results to return

        Returns:
            SearchResponse with matching entities
        """
        logger.info(f"Searching entities: {entity_name}")

        payload = {
            "query": f"Find entities matching: {entity_name}",
            "response_mode": "raw_facts",
            "include_sources": False,
            "stream": False,
            "search_params": {
                "entity_search": entity_name,
                "limit": limit,
            },
        }

        try:
            url = f"{self.streaming_url.rstrip('/')}/query"
            response = await self.client.post(
                url,
                headers=self._headers(),
                json=payload,
            )
            response.raise_for_status()
            data = self._parse_streaming_response(response)

            entities = []
            raw_entities = data.get("entities", [])
            for ent in raw_entities[:limit]:
                if isinstance(ent, dict):
                    entities.append(
                        EntitySearchResult(
                            name=ent.get("name", ent.get("entity", "Unknown")),
                            type=ent.get("type", "unknown"),
                            fact_count=ent.get("fact_count", 0),
                            relevance_score=ent.get("relevance", 0.0),
                        )
                    )
                elif isinstance(ent, str):
                    entities.append(EntitySearchResult(name=ent))

            return SearchResponse(
                success=True,
                entities=entities,
                total=len(entities),
            )
        except httpx.HTTPStatusError as e:
            logger.error(f"Search failed with status {e.response.status_code}")
            return SearchResponse(
                success=False,
                error=f"Search failed: HTTP {e.response.status_code}",
            )
        except Exception as e:
            logger.error(f"Search failed: {type(e).__name__}: {e}")
            return SearchResponse(success=False, error=f"{type(e).__name__}: {e}")

    async def get_facts(
        self,
        entity: str,
        temporal_filter: Optional[str] = None,
    ) -> FactsResponse:
        """Get all facts about a specific entity.

        Args:
            entity: Entity name to get facts for
            temporal_filter: Optional date filter (e.g., "2023", "2023-Q1")

        Returns:
            FactsResponse with facts for the entity
        """
        logger.info(f"Getting facts for entity: {entity}")

        query = f"Get all facts about {entity}"
        if temporal_filter:
            query += f" from {temporal_filter}"

        payload = {
            "query": query,
            "response_mode": "raw_facts",
            "include_sources": True,
            "stream": False,
            "target_entity": entity,
        }

        if temporal_filter:
            payload["temporal_filter"] = temporal_filter

        try:
            url = f"{self.streaming_url.rstrip('/')}/query"
            response = await self.client.post(
                url,
                headers=self._headers(),
                json=payload,
            )
            response.raise_for_status()
            data = self._parse_streaming_response(response)

            facts = []
            raw_facts = data.get("facts", data.get("raw_facts", []))
            for fact in raw_facts:
                if isinstance(fact, dict):
                    facts.append(
                        Fact(
                            subject=fact.get("subject", entity),
                            predicate=fact.get("predicate", fact.get("relationship", "")),
                            object=fact.get("object", fact.get("value", "")),
                            confidence=fact.get("confidence", 1.0),
                            source_document=fact.get("source_document"),
                            temporal_info=fact.get("temporal_info"),
                        )
                    )

            return FactsResponse(
                success=True,
                entity=entity,
                facts=facts,
                total=len(facts),
            )
        except httpx.HTTPStatusError as e:
            logger.error(f"Get facts failed with status {e.response.status_code}")
            return FactsResponse(
                success=False,
                entity=entity,
                error=f"Get facts failed: HTTP {e.response.status_code}",
            )
        except Exception as e:
            logger.error(f"Get facts failed: {type(e).__name__}: {e}")
            return FactsResponse(success=False, entity=entity, error=f"{type(e).__name__}: {e}")

    async def get_stats(self) -> StatsResponse:
        """Get knowledge graph statistics.

        Returns:
            StatsResponse with graph statistics
        """
        logger.info("Getting graph statistics")

        try:
            url = f"{self.streaming_url.rstrip('/')}/query"
            response = await self.client.post(
                url,
                headers=self._headers(),
                json={
                    "query": "Get graph statistics",
                    "response_mode": "stats",
                    "stream": False,
                },
                timeout=30.0,
            )
            response.raise_for_status()
            data = self._parse_streaming_response(response)

            return StatsResponse(
                success=True,
                total_entities=data.get("total_entities", 0),
                total_facts=data.get("total_facts", 0),
                total_documents=data.get("total_documents", 0),
                graph_statistics=data.get("statistics", {}),
            )
        except httpx.HTTPStatusError as e:
            logger.error(f"Get stats failed with status {e.response.status_code}")
            return StatsResponse(
                success=False,
                error=f"Get stats failed: HTTP {e.response.status_code}",
            )
        except Exception as e:
            logger.error(f"Get stats failed: {e}")
            return StatsResponse(success=False, error=str(e))
