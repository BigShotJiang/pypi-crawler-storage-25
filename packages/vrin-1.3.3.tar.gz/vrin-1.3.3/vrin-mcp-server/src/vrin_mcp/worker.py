"""MCP Job Worker — runs VRIN queries in background.

Deployed as a separate Lambda function (`vrin-mcp-job-worker`).
Invoked asynchronously by `vrin_query_async` in server.py.

Flow:
  1. Receives {job_id, api_key, query, params} from async Lambda invoke
  2. Calls VRIN streaming backend via VRINClient
  3. Writes result to DynamoDB via job_store
"""

import asyncio
import json
import logging
import os

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)


def _run_async(coro):
    """Run an async coroutine from sync Lambda handler."""
    loop = asyncio.new_event_loop()
    try:
        return loop.run_until_complete(coro)
    finally:
        loop.close()


async def _execute_job(
    job_id: str,
    api_key: str,
    query: str,
    params: dict,
) -> None:
    """Execute the VRIN query and store result in DynamoDB."""
    from vrin_mcp.client.vrin_api import VRINClient
    from vrin_mcp.job_store import update_job, update_job_progress

    mode = params.get("mode", "context")
    depth = params.get("depth", "basic")
    include_sources = params.get("include_sources", True)

    # Throttle progress updates to DynamoDB (max 1 per 3 seconds)
    last_progress_time = 0

    async def _on_progress(event: dict) -> None:
        nonlocal last_progress_time
        import time

        now = time.time()
        if now - last_progress_time < 3.0:
            return
        last_progress_time = now
        try:
            update_job_progress(
                job_id,
                api_key,
                progress_stage=event.get("stage", ""),
                progress_label=event.get("label", ""),
                progress_step=event.get("step", 0),
                progress_total=event.get("total_steps", 7),
            )
        except Exception as e:
            logger.warning(f"Progress update failed for job {job_id}: {e}")

    try:
        async with VRINClient(api_key) as client:
            if mode == "context":
                response = await client.retrieve_context_with_progress(
                    query=query,
                    depth=depth,
                    include_sources=include_sources,
                    on_progress=_on_progress,
                )

                context_parts = []
                if response.generation_guidance:
                    context_parts.append(response.generation_guidance)
                if response.structured_context:
                    context_parts.append("---\n\n" + response.structured_context)
                if response.reasoning_insights:
                    context_parts.append(
                        "---\n\n## Multi-Hop Reasoning Insights\n"
                        + response.reasoning_insights
                    )
                combined_context = "\n\n".join(context_parts)

                result = {
                    "success": response.success,
                    "context": combined_context,
                    "facts_count": response.facts_count,
                    "chunks_count": response.chunks_count,
                    "query_depth": response.query_depth,
                    "error": response.error,
                }
                if include_sources and response.sources:
                    result["sources"] = response.sources
            else:
                response = await client.query(
                    query=query,
                    mode=mode,
                    include_sources=include_sources,
                )
                result = {
                    "success": response.success,
                    "summary": response.summary or response.answer,
                    "answer": response.answer or response.summary,
                    "sources": response.sources,
                    "facts_used": response.facts_used,
                    "reasoning_steps": response.reasoning_steps,
                    "search_time": response.search_time,
                    "error": response.error,
                }

        if result.get("error"):
            update_job(job_id, api_key, "failed", error=result["error"])
        else:
            update_job(job_id, api_key, "completed", result=result)

    except Exception as e:
        logger.error(f"Job {job_id} failed: {type(e).__name__}: {e}")
        update_job(job_id, api_key, "failed", error=f"{type(e).__name__}: {e}")


def lambda_handler(event: dict, context) -> dict:
    """Lambda handler for async job execution.

    Expected event payload:
        {
            "job_id": "uuid",
            "api_key": "vrin_xxx",
            "query": "...",
            "params": {"mode": "context", "depth": "basic", ...}
        }
    """
    job_id = event.get("job_id", "")
    api_key = event.get("api_key", "")
    query = event.get("query", "")
    params = event.get("params", {})

    if not all([job_id, api_key, query]):
        logger.error(f"Invalid event: missing required fields")
        return {"statusCode": 400, "body": "Missing required fields"}

    logger.info(f"Worker starting job {job_id}: {query[:80]}...")

    _run_async(_execute_job(job_id, api_key, query, params))

    logger.info(f"Worker completed job {job_id}")
    return {"statusCode": 200, "body": json.dumps({"job_id": job_id})}
