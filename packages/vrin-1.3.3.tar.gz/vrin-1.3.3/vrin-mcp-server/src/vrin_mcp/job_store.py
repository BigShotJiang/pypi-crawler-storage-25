"""DynamoDB Job Store for async MCP operations.

Stores job status and results for the async query pattern:
  vrin_query_async → creates job → worker runs → vrin_check_job reads result.

Uses the existing vrin-graph-metadata table with tenant isolation via
API key hash. Jobs auto-expire after 1 hour via DynamoDB TTL.
"""

import hashlib
import json
import logging
import os
import time
from datetime import datetime, timezone
from typing import Any, Optional

import boto3
from botocore.exceptions import ClientError

logger = logging.getLogger(__name__)

_JOB_TTL_SECONDS = 3600  # 1 hour


def _get_table_name() -> str:
    return os.environ.get("VRIN_JOB_TABLE", "vrin-graph-metadata")


def _get_table():
    region = os.environ.get("AWS_REGION", "us-east-1")
    dynamodb = boto3.resource("dynamodb", region_name=region)
    return dynamodb.Table(_get_table_name())


def hash_api_key(api_key: str) -> str:
    """Hash API key for tenant isolation. Never store raw keys."""
    return hashlib.sha256(api_key.encode()).hexdigest()[:16]


def create_job(
    job_id: str,
    api_key: str,
    query: str,
    params: dict[str, Any],
) -> dict[str, Any]:
    """Create a new job record in DynamoDB.

    Returns the job record dict on success.
    """
    table = _get_table()
    now = datetime.now(timezone.utc).isoformat()
    item = {
        "user_id": hash_api_key(api_key),
        "metadata_key": f"mcp_job#{job_id}",
        "job_id": job_id,
        "status": "working",
        "query": query,
        "params": params,
        "created_at": now,
        "updated_at": now,
        "ttl": int(time.time()) + _JOB_TTL_SECONDS,
    }

    try:
        table.put_item(Item=item)
        logger.info(f"Created job {job_id}")
        return item
    except ClientError as e:
        logger.error(f"Failed to create job {job_id}: {e}")
        raise


def get_job(job_id: str, api_key: str) -> Optional[dict[str, Any]]:
    """Get a job record by ID. Returns None if not found.

    Enforces tenant isolation via API key hash.
    """
    table = _get_table()

    try:
        response = table.get_item(
            Key={
                "user_id": hash_api_key(api_key),
                "metadata_key": f"mcp_job#{job_id}",
            }
        )
        return response.get("Item")
    except ClientError as e:
        logger.error(f"Failed to get job {job_id}: {e}")
        return None


def update_job(
    job_id: str,
    api_key: str,
    status: str,
    result: Optional[dict[str, Any]] = None,
    error: Optional[str] = None,
) -> None:
    """Update job status and optionally set result or error."""
    table = _get_table()
    now = datetime.now(timezone.utc).isoformat()

    update_expr = "SET #s = :status, updated_at = :now"
    expr_names = {"#s": "status"}
    expr_values: dict[str, Any] = {":status": status, ":now": now}

    if result is not None:
        # Store result as JSON string to avoid DynamoDB type issues
        update_expr += ", result_json = :result"
        expr_values[":result"] = json.dumps(result, default=str)

    if error is not None:
        update_expr += ", error_message = :error"
        expr_values[":error"] = error

    try:
        table.update_item(
            Key={
                "user_id": hash_api_key(api_key),
                "metadata_key": f"mcp_job#{job_id}",
            },
            UpdateExpression=update_expr,
            ExpressionAttributeNames=expr_names,
            ExpressionAttributeValues=expr_values,
        )
        logger.info(f"Updated job {job_id} → {status}")
    except ClientError as e:
        logger.error(f"Failed to update job {job_id}: {e}")
        raise


def update_job_progress(
    job_id: str,
    api_key: str,
    progress_stage: str,
    progress_label: str,
    progress_step: int,
    progress_total: int,
) -> None:
    """Update job with progress information (throttle at caller)."""
    table = _get_table()
    now = datetime.now(timezone.utc).isoformat()

    try:
        table.update_item(
            Key={
                "user_id": hash_api_key(api_key),
                "metadata_key": f"mcp_job#{job_id}",
            },
            UpdateExpression=(
                "SET updated_at = :now, "
                "progress_stage = :stage, "
                "progress_label = :label, "
                "progress_step = :step, "
                "progress_total = :total"
            ),
            ExpressionAttributeValues={
                ":now": now,
                ":stage": progress_stage,
                ":label": progress_label,
                ":step": progress_step,
                ":total": progress_total,
            },
        )
    except ClientError as e:
        logger.warning(f"Failed to update progress for job {job_id}: {e}")
