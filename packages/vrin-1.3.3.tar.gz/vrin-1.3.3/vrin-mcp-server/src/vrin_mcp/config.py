"""VRIN MCP Server Configuration.

Configuration is loaded from environment variables with sensible defaults.
Used by VRINClient and server_http.py for consistent URL/timeout management.
"""

import os
from dataclasses import dataclass
from typing import Optional

from dotenv import load_dotenv

# Load .env file if present
load_dotenv()


@dataclass
class VRINConfig:
    """VRIN MCP Server configuration.

    All fields have environment-variable-driven defaults so that
    constructing VRINConfig() with no args works out of the box.
    """

    # VRIN Backend URLs
    streaming_url: str = (
        "https://43tybsfy52ehi3fctubc7jwlpi0fgkcz.lambda-url.us-east-1.on.aws"
    )
    auth_url: str = "https://gp7g651udc.execute-api.us-east-1.amazonaws.com/Prod"

    # Timeouts (in seconds)
    query_timeout: float = 120.0
    search_timeout: float = 30.0
    auth_timeout: float = 10.0

    # Server settings
    server_name: str = "vrin-knowledge"
    server_version: str = "1.0.0"

    # HTTP transport settings (for remote deployment)
    http_host: str = "0.0.0.0"
    http_port: int = 8000

    # OAuth / Stytch
    stytch_project_id: str = ""
    stytch_jwks_url: str = ""
    mcp_resource_url: str = ""

    # Async job pattern
    job_table_name: str = "vrin-graph-metadata"
    worker_lambda_name: str = "vrin-mcp-job-worker"


def get_config() -> VRINConfig:
    """Load configuration from environment variables.

    Environment Variables:
        VRIN_STREAMING_URL: Override streaming Lambda URL
        VRIN_AUTH_URL: Override auth API URL
        VRIN_QUERY_TIMEOUT: Query timeout in seconds (default: 120)
        VRIN_HTTP_HOST: HTTP server host (default: 0.0.0.0)
        VRIN_HTTP_PORT: HTTP server port (default: 8000)
        STYTCH_PROJECT_ID: Stytch project for OAuth JWT validation
        STYTCH_JWKS_URL: Override JWKS endpoint
        VRIN_MCP_RESOURCE_URL: Public URL of this MCP server's /mcp endpoint

    Returns:
        VRINConfig instance
    """
    return VRINConfig(
        streaming_url=os.environ.get(
            "VRIN_STREAMING_URL",
            "https://43tybsfy52ehi3fctubc7jwlpi0fgkcz.lambda-url.us-east-1.on.aws",
        ),
        auth_url=os.environ.get(
            "VRIN_AUTH_URL",
            "https://gp7g651udc.execute-api.us-east-1.amazonaws.com/Prod",
        ),
        query_timeout=float(os.environ.get("VRIN_QUERY_TIMEOUT", "120")),
        http_host=os.environ.get("VRIN_HTTP_HOST", "0.0.0.0"),
        http_port=int(os.environ.get("VRIN_HTTP_PORT", "8000")),
        stytch_project_id=os.environ.get("STYTCH_PROJECT_ID", ""),
        stytch_jwks_url=os.environ.get("STYTCH_JWKS_URL", ""),
        mcp_resource_url=os.environ.get("VRIN_MCP_RESOURCE_URL", ""),
    )


# Global config instance (lazy loaded)
_config: Optional[VRINConfig] = None


def get_global_config() -> VRINConfig:
    """Get or create global config instance."""
    global _config
    if _config is None:
        _config = get_config()
    return _config
