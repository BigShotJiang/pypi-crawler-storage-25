"""AWS Lambda Handler for VRIN MCP Server.

This module provides the Lambda entry point using Mangum to adapt the
Starlette ASGI application to AWS Lambda's event format.

The handler supports:
- Lambda Function URLs (recommended)
- API Gateway HTTP API
- API Gateway REST API
- Application Load Balancer

Usage:
    Deploy as a Docker-based Lambda function with this handler as the entry point.
    The handler is automatically configured in the Lambda Dockerfile.
"""

import logging
import os
import sys

# Configure logging for Lambda
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    stream=sys.stdout,  # Lambda captures stdout
)
logger = logging.getLogger(__name__)

# Import Mangum adapter
try:
    from mangum import Mangum
except ImportError:
    logger.error("Mangum not installed. Install with: pip install mangum")
    raise

# Import the Starlette app
from vrin_mcp.server_http import app

# Create the Lambda handler
# lifespan="auto" — Mangum fires startup/shutdown per invocation,
# which creates a fresh StreamableHTTPSessionManager each time via _lambda_lifespan.
handler = Mangum(
    app,
    lifespan="auto",
    api_gateway_base_path=None,  # No base path stripping
)


def lambda_handler(event: dict, context) -> dict:
    """AWS Lambda entry point.

    This function is called by AWS Lambda for each invocation.
    It delegates to Mangum which handles the ASGI protocol translation.

    Args:
        event: Lambda event (from Function URL, API Gateway, or ALB)
        context: Lambda context object

    Returns:
        HTTP response in Lambda format
    """
    # Log request info for debugging (without sensitive data)
    request_context = event.get("requestContext", {})
    http_info = request_context.get("http", {})

    logger.info(
        f"MCP Request: {http_info.get('method', 'UNKNOWN')} "
        f"{http_info.get('path', '/')} "
        f"from {http_info.get('sourceIp', 'unknown')}"
    )

    # Delegate to Mangum
    response = handler(event, context)

    # Log response status
    logger.info(f"MCP Response: {response.get('statusCode', 'unknown')}")

    return response
