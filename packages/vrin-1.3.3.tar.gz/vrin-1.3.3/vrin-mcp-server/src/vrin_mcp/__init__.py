"""VRIN MCP Server - Enterprise Hybrid RAG for AI Agents.

This package provides an MCP (Model Context Protocol) server that exposes
VRIN's Hybrid RAG capabilities to any MCP-compatible AI agent including
Claude Desktop, ChatGPT, OpenClaw, and custom agents.

Example:
    # Claude Desktop configuration
    {
        "mcpServers": {
            "vrin-knowledge": {
                "command": "python",
                "args": ["-m", "vrin_mcp.server"],
                "env": {"VRIN_API_KEY": "vrin_your_api_key"}
            }
        }
    }
"""

__version__ = "1.0.0"
__author__ = "VRIN Team"


def get_server():
    """Get the MCP server instance (lazy import to avoid startup errors)."""
    from vrin_mcp.server import mcp
    return mcp


def main():
    """Run the MCP server."""
    from vrin_mcp.server import main as server_main
    server_main()


__all__ = ["get_server", "main", "__version__"]
