"""Stytch JWT Validation for MCP OAuth 2.1.

This module validates JWTs issued by Stytch's Connected Apps (OAuth 2.1).
It acts as a Resource Server: validates tokens but never issues them.

Configuration:
    STYTCH_PROJECT_ID: Stytch project identifier
    STYTCH_JWKS_URL: JWKS endpoint (auto-derived from project ID if not set)
"""

import logging
import os
import time
from dataclasses import dataclass, field
from typing import Any, Optional

import httpx
import jwt
from jwt import PyJWKClient, PyJWKClientError

logger = logging.getLogger(__name__)

# JWKS cache TTL in seconds (1 hour)
_JWKS_CACHE_TTL = 3600


@dataclass
class JWTClaims:
    """Validated claims extracted from a Stytch JWT."""

    sub: str  # Stytch member_id
    email: Optional[str] = None
    organization_id: Optional[str] = None
    issuer: Optional[str] = None
    audience: Optional[str] = None
    expires_at: Optional[float] = None
    raw_claims: dict[str, Any] = field(default_factory=dict)


class JWTValidationError(Exception):
    """Raised when JWT validation fails."""

    pass


class StytchJWTValidator:
    """Validates JWTs issued by Stytch for MCP OAuth 2.1.

    Fetches JWKS from Stytch's well-known endpoint and validates:
    - Signature (RS256)
    - Expiration
    - Issuer
    - Required claims (sub)

    Example:
        validator = StytchJWTValidator()
        claims = await validator.validate("eyJ...")
        print(claims.email)
    """

    def __init__(
        self,
        project_id: Optional[str] = None,
        jwks_url: Optional[str] = None,
        domain: Optional[str] = None,
    ) -> None:
        self._project_id = project_id or os.environ.get("STYTCH_PROJECT_ID", "")
        self._jwks_url = jwks_url or os.environ.get("STYTCH_JWKS_URL", "")
        self._domain = domain or os.environ.get("STYTCH_DOMAIN", "")

        # Derive JWKS URL if not explicitly set
        # Prefer domain-based URL (Connected Apps standard)
        if not self._jwks_url and self._domain:
            self._jwks_url = f"{self._domain.rstrip('/')}/.well-known/jwks.json"
        elif not self._jwks_url and self._project_id:
            # Fallback: legacy sessions JWKS path (same keys)
            self._jwks_url = (
                f"https://test.stytch.com/v1/sessions/jwks/{self._project_id}"
            )

        self._jwk_client: Optional[PyJWKClient] = None
        self._jwk_client_created_at: float = 0

    def _get_jwk_client(self) -> PyJWKClient:
        """Get or create the JWKS client with TTL-based refresh."""
        now = time.time()
        if (
            self._jwk_client is None
            or (now - self._jwk_client_created_at) > _JWKS_CACHE_TTL
        ):
            if not self._jwks_url:
                raise JWTValidationError(
                    "JWKS URL not configured. Set STYTCH_PROJECT_ID or STYTCH_JWKS_URL."
                )
            self._jwk_client = PyJWKClient(self._jwks_url, cache_keys=True)
            self._jwk_client_created_at = now
            logger.info(f"JWKS client initialized from {self._jwks_url}")
        return self._jwk_client

    async def validate(self, token: str) -> JWTClaims:
        """Validate a Stytch JWT and extract claims.

        Args:
            token: Raw JWT string (without "Bearer " prefix)

        Returns:
            JWTClaims with validated claims

        Raises:
            JWTValidationError: If token is invalid, expired, or malformed
        """
        try:
            jwk_client = self._get_jwk_client()
            signing_key = jwk_client.get_signing_key_from_jwt(token)

            decoded = jwt.decode(
                token,
                signing_key.key,
                algorithms=["RS256"],
                options={
                    "require": ["sub", "exp", "iss"],
                    "verify_exp": True,
                    "verify_iss": True,
                    # Disable audience verification — Stytch Connected Apps
                    # JWTs contain a dynamically-registered client_id as the
                    # audience. We can't predict this value. Signature
                    # verification against Stytch's JWKS is sufficient.
                    "verify_aud": False,
                },
                # Accept any issuer from Stytch — we validate the signature
                # which is sufficient since we fetch keys from a trusted JWKS URL
                issuer=None,
            )

            # Issuer check: must be from Stytch (.stytch.com for prod, .stytch.dev for test)
            iss = decoded.get("iss", "")
            if "stytch.com" not in iss and "stytch.dev" not in iss:
                raise JWTValidationError(
                    f"Invalid issuer: {iss}. Expected Stytch issuer."
                )

            # Log claim keys for debugging (no values — they may be sensitive)
            logger.info(f"JWT claim keys: {list(decoded.keys())}")

            # Extract email — Stytch JWTs put it in various locations
            # depending on token type (session, Connected Apps, etc.)
            email = (
                decoded.get("email")
                or decoded.get("https://stytch.com/member", {}).get("email")
                or decoded.get("https://stytch.com/member", {}).get(
                    "email_address"
                )
                or decoded.get("https://stytch.com/session", {}).get("email")
            )

            # Extract organization_id from multiple possible locations
            org_id = (
                decoded.get("https://stytch.com/organization", {}).get(
                    "organization_id"
                )
                or decoded.get("org_id")
            )

            claims = JWTClaims(
                sub=decoded["sub"],
                email=email,
                organization_id=org_id,
                issuer=iss,
                audience=decoded.get("aud"),
                expires_at=decoded.get("exp"),
                raw_claims=decoded,
            )

            logger.info(
                f"JWT validated: sub={claims.sub}, "
                f"email={'yes' if claims.email else 'NO'}, "
                f"org={claims.organization_id or 'none'}"
            )
            return claims

        except jwt.ExpiredSignatureError:
            raise JWTValidationError("JWT has expired")
        except jwt.InvalidIssuerError:
            raise JWTValidationError("JWT has invalid issuer")
        except jwt.DecodeError as e:
            raise JWTValidationError(f"JWT decode failed: {e}")
        except PyJWKClientError as e:
            raise JWTValidationError(f"JWKS key fetch failed: {e}")
        except jwt.PyJWTError as e:
            raise JWTValidationError(f"JWT validation failed: {e}")
        except JWTValidationError:
            raise
        except Exception as e:
            logger.error(f"Unexpected JWT validation error: {e}")
            raise JWTValidationError(f"JWT validation failed: {e}")

    @property
    def is_configured(self) -> bool:
        """Check if JWT validation is configured (JWKS URL available)."""
        return bool(self._jwks_url)
