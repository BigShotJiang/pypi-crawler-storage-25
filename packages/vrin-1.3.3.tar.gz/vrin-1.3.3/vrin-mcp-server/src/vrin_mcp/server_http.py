"""VRIN MCP HTTP Server - Remote deployment with Streamable HTTP.

This module provides an HTTP server for remote MCP deployment using
Streamable HTTP transport. This enables VRIN to be accessed by remote
AI agents without requiring local installation.

Authentication (dual auth):
    1. VRiN API key: Authorization: Bearer vrin_xxx
    2. Stytch OAuth JWT: Authorization: Bearer eyJ... (validated, resolved to API key)
    3. No auth: Returns 401 with WWW-Authenticate pointing to OAuth discovery

OAuth 2.1 (MCP spec, June 2025 revision):
    GET /.well-known/oauth-protected-resource → RFC 9728 discovery
    401 responses include WWW-Authenticate header for auto-discovery

Example:
    # Run HTTP server (remote mode - clients pass their own API keys)
    $ python -m vrin_mcp.server_http

    # Or with uvicorn directly
    $ uvicorn vrin_mcp.server_http:app --host 0.0.0.0 --port 8000

    # Or use the entry point
    $ vrin-mcp-http
"""

import logging
import os
import sys

try:
    from starlette.applications import Starlette
    from starlette.middleware import Middleware
    from starlette.middleware.base import BaseHTTPMiddleware
    from starlette.requests import Request
    from starlette.responses import JSONResponse, PlainTextResponse, Response
    from starlette.routing import Mount, Route
    import uvicorn
except ImportError:
    print(
        "HTTP server dependencies not installed. "
        "Install with: pip install vrin-mcp-server[remote]",
        file=sys.stderr,
    )
    sys.exit(1)

from vrin_mcp.server import mcp
from vrin_mcp.auth.context import (
    clear_auth_info,
    clear_request_api_key,
    extract_bearer_token,
    is_jwt,
    set_auth_info,
    set_request_api_key,
)

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
)
logger = logging.getLogger(__name__)


# =============================================================================
# OAuth 2.1 Configuration
# =============================================================================

def _get_resource_url() -> str:
    """Get the MCP resource URL for OAuth discovery."""
    return os.environ.get(
        "VRIN_MCP_RESOURCE_URL",
        "https://mcp.vrin.cloud/mcp",
    )


def _get_authorization_server() -> str:
    """Get the Stytch authorization server URL (issuer).

    Uses STYTCH_DOMAIN if set (e.g. https://word-word-1234.customers.stytch.dev),
    otherwise falls back to test.stytch.com/v1/public/{project_id}.
    """
    domain = os.environ.get("STYTCH_DOMAIN", "")
    if domain:
        return domain.rstrip("/")
    project_id = os.environ.get("STYTCH_PROJECT_ID", "")
    if project_id:
        return f"https://test.stytch.com/v1/public/{project_id}"
    return "https://test.stytch.com/v1/public/oauth2"


def _get_protected_resource_metadata() -> dict:
    """Build RFC 9728 Protected Resource Metadata."""
    return {
        "resource": _get_resource_url(),
        "authorization_servers": [_get_authorization_server()],
        "bearer_methods_supported": ["header"],
        "scopes_supported": ["openid", "email", "profile"],
    }


# Lazy-initialized singletons for JWT validation
_jwt_validator = None
_user_resolver = None


def _get_jwt_validator():
    """Get or create the JWT validator singleton."""
    global _jwt_validator
    if _jwt_validator is None:
        from vrin_mcp.auth.jwt_validator import StytchJWTValidator
        _jwt_validator = StytchJWTValidator()
    return _jwt_validator


def _get_user_resolver():
    """Get or create the user resolver singleton."""
    global _user_resolver
    if _user_resolver is None:
        from vrin_mcp.auth.user_resolver import UserResolver
        _user_resolver = UserResolver()
    return _user_resolver


# =============================================================================
# Authentication Middleware
# =============================================================================


# Paths that never require authentication
_PUBLIC_PATHS = frozenset({
    "/",
    "/health",
    "/.well-known/oauth-protected-resource",
    "/.well-known/oauth-protected-resource/mcp",
    "/.well-known/oauth-authorization-server",
})


class APIKeyMiddleware(BaseHTTPMiddleware):
    """Middleware to handle triple authentication: URL path, API key header, Stytch JWT.

    Supported auth methods (checked in order):
    1. URL path: /mcp/vrin_xxx — API key embedded in URL (simplest)
    2. Bearer vrin_xxx — VRiN API key in Authorization header
    3. Bearer eyJ... — Stytch OAuth JWT (validated, resolved to API key)

    Unauthenticated requests to protected paths get 401 with
    WWW-Authenticate pointing to OAuth discovery.
    """

    async def dispatch(self, request: Request, call_next) -> Response:
        path = request.url.path
        auth_header = request.headers.get("authorization")
        token = extract_bearer_token(auth_header)

        try:
            # Path C: URL-path API key — /mcp/vrin_xxx
            # Extract key from URL, rewrite path to /mcp for the MCP handler.
            # This is the simplest auth method — no headers needed.
            if path.startswith("/mcp/vrin_"):
                api_key = path[5:]  # Strip "/mcp/" prefix
                set_request_api_key(api_key)
                key_type = "enterprise" if api_key.startswith("vrin_ent_") else "standard"
                set_auth_info({"method": "url_path", "key_type": key_type})
                logger.info(f"URL-path auth: {key_type} API key")
                # Rewrite path so the /mcp route handler matches
                request.scope["path"] = "/mcp"
                response = await call_next(request)
                return response

            # Public paths never require authentication
            if path in _PUBLIC_PATHS:
                set_request_api_key(None)
                set_auth_info(None)
                response = await call_next(request)
                return response

            if token and token.startswith("vrin_"):
                # Path A: VRiN API key (existing behavior)
                set_request_api_key(token)
                key_type = "enterprise" if token.startswith("vrin_ent_") else "standard"
                set_auth_info({"method": "api_key", "key_type": key_type})
                logger.debug(f"Request authenticated with {key_type} API key")

            elif token and is_jwt(token):
                # Path B: Stytch JWT → validate → resolve to VRiN API key
                validator = _get_jwt_validator()
                if not validator.is_configured:
                    logger.warning("JWT received but Stytch not configured")
                    set_request_api_key(None)
                    set_auth_info(None)
                else:
                    try:
                        from vrin_mcp.auth.jwt_validator import JWTValidationError
                        from vrin_mcp.auth.user_resolver import UserResolveError

                        claims = await validator.validate(token)
                        resolver = _get_user_resolver()
                        api_key = await resolver.resolve(claims)
                        set_request_api_key(api_key)
                        set_auth_info({
                            "method": "jwt",
                            "email": claims.email,
                            "member_id": claims.sub,
                            "organization_id": claims.organization_id,
                        })
                        logger.info(f"JWT authenticated: {claims.sub}")
                    except (JWTValidationError, UserResolveError) as e:
                        logger.warning(f"JWT auth failed: {e}")
                        set_request_api_key(None)
                        set_auth_info(None)
                        # Return 401 immediately for invalid JWTs
                        return _build_401_response(str(e))
            else:
                # No valid auth token on a protected path.
                # In local mode (VRIN_API_KEY env var set), allow through
                # so get_api_key() can fall back to the env var.
                # In remote mode (no env var), return 401 per MCP spec
                # to trigger OAuth discovery in Claude/ChatGPT.
                if not os.environ.get("VRIN_API_KEY"):
                    logger.info(f"Unauthenticated request to {path}, returning 401")
                    return _build_401_response("Authentication required")
                set_request_api_key(None)
                set_auth_info(None)
                if token:
                    logger.warning("Invalid token format in Authorization header")

            response = await call_next(request)
            return response

        finally:
            clear_request_api_key()
            clear_auth_info()


# Keep alias for backward compatibility
AuthMiddleware = APIKeyMiddleware


def _build_401_response(detail: str = "Authentication required") -> Response:
    """Build a 401 response with WWW-Authenticate header per MCP OAuth 2.1 spec."""
    resource_metadata_url = _get_resource_url().rsplit("/mcp", 1)[0]
    resource_metadata_url += "/.well-known/oauth-protected-resource"

    return JSONResponse(
        {"error": "unauthorized", "detail": detail},
        status_code=401,
        headers={
            "WWW-Authenticate": (
                f'Bearer resource_metadata="{resource_metadata_url}"'
            ),
        },
    )


# =============================================================================
# OAuth Discovery Endpoint
# =============================================================================


async def oauth_protected_resource(request: Request) -> Response:
    """RFC 9728 Protected Resource Metadata endpoint.

    Returns metadata telling OAuth clients where to authenticate.
    This is the entry point for Claude Web, ChatGPT, and other
    MCP clients that support OAuth 2.1 auto-discovery.
    """
    return JSONResponse(
        _get_protected_resource_metadata(),
        headers={"Cache-Control": "public, max-age=3600"},
    )


async def oauth_authorization_server(request: Request) -> Response:
    """RFC 8414 OAuth Authorization Server Metadata (proxy to Stytch).

    ChatGPT and other MCP clients fetch this to discover the OAuth endpoints
    (authorize, token, registration). We proxy Stytch's metadata so that
    clients only need our MCP server URL.
    """
    import httpx as _httpx

    auth_server = _get_authorization_server()
    metadata_url = f"{auth_server}/.well-known/oauth-authorization-server"

    try:
        async with _httpx.AsyncClient(timeout=10.0) as client:
            resp = await client.get(metadata_url)
            resp.raise_for_status()
            metadata = resp.json()
            # Remove Stytch-specific fields that aren't part of RFC 8414
            metadata.pop("status_code", None)
            metadata.pop("request_id", None)
            return JSONResponse(
                metadata,
                headers={"Cache-Control": "public, max-age=3600"},
            )
    except Exception as e:
        logger.error(f"Failed to fetch OAuth AS metadata from {metadata_url}: {e}")
        return JSONResponse(
            {"error": "Failed to fetch authorization server metadata"},
            status_code=502,
        )


# =============================================================================
# Health Check Endpoints
# =============================================================================


async def health_check(request: Request) -> Response:
    """Health check endpoint for load balancers and monitoring."""
    return JSONResponse(
        {
            "status": "healthy",
            "service": "vrin-mcp-server",
            "version": "1.0.0",
        }
    )


async def readiness_check(request: Request) -> Response:
    """Readiness check - verifies API key is available.

    Checks for API key in:
    1. Authorization header (for remote MCP)
    2. VRIN_API_KEY environment variable (for local MCP)
    """
    from vrin_mcp.auth.context import get_api_key

    api_key = get_api_key()

    if api_key:
        is_enterprise = api_key.startswith("vrin_ent_")
        auth_header = request.headers.get("authorization")
        source = "header" if auth_header else "environment"
        return JSONResponse(
            {
                "status": "ready",
                "api_key_configured": True,
                "api_key_source": source,
                "is_enterprise": is_enterprise,
            }
        )
    else:
        return JSONResponse(
            {
                "status": "not_ready",
                "api_key_configured": False,
                "error": (
                    "API key required. Pass 'Authorization: Bearer vrin_xxx' header, "
                    "use Stytch OAuth JWT, or set VRIN_API_KEY environment variable."
                ),
            },
            status_code=503,
        )


async def root(request: Request) -> Response:
    """Root endpoint with server information."""
    return PlainTextResponse(
        "VRIN MCP Server v1.0.0\n"
        "=======================\n\n"
        "Endpoints:\n"
        "  /mcp                                       - MCP protocol endpoint\n"
        "  /mcp/YOUR_API_KEY                          - MCP endpoint (API key in URL)\n"
        "  /health                                     - Health check (no auth)\n"
        "  /ready                                      - Readiness check\n"
        "  /.well-known/oauth-protected-resource       - OAuth 2.1 discovery\n\n"
        "Authentication (any of these methods):\n"
        "  1. URL path:  /mcp/vrin_your_api_key         (simplest — no headers needed)\n"
        "  2. Header:    Authorization: Bearer vrin_xxx  (VRiN API key)\n"
        "  3. Header:    Authorization: Bearer eyJ...    (Stytch OAuth JWT)\n\n"
        "Get your API key at: https://vrin.cloud\n"
        "Documentation: https://docs.vrin.cloud/mcp\n"
    )


# =============================================================================
# Starlette Application
# =============================================================================


# Detect Lambda environment (Mangum can't run lifespan per-request)
_is_lambda = bool(os.environ.get("AWS_LAMBDA_FUNCTION_NAME"))

if _is_lambda:
    # Lambda: create a fresh session manager per invocation via lifespan.
    # StreamableHTTPSessionManager.run() can only be called once per instance,
    # and Mangum fires lifespan startup/shutdown per Lambda invocation,
    # so we create a new instance each time.
    from contextlib import asynccontextmanager

    from mcp.server.streamable_http_manager import StreamableHTTPSessionManager

    _lambda_session_mgr: dict[str, StreamableHTTPSessionManager | None] = {"current": None}

    class _MCPAsgiApp:
        """ASGI wrapper that delegates to the current session manager."""

        async def __call__(self, scope, receive, send):
            mgr = _lambda_session_mgr["current"]
            if mgr is None:
                raise RuntimeError("No active MCP session manager")
            await mgr.handle_request(scope, receive, send)

    @asynccontextmanager
    async def _lambda_lifespan(app):
        mgr = StreamableHTTPSessionManager(
            app=mcp._mcp_server,
            event_store=mcp._event_store,
            stateless=True,
            json_response=True,
        )
        async with mgr.run():
            _lambda_session_mgr["current"] = mgr
            yield
            _lambda_session_mgr["current"] = None

    app = Starlette(
        debug=os.environ.get("DEBUG", "false").lower() == "true",
        routes=[
            Route("/", endpoint=root),
            Route("/health", endpoint=health_check),
            Route("/ready", endpoint=readiness_check),
            Route(
                "/.well-known/oauth-protected-resource",
                endpoint=oauth_protected_resource,
            ),
            Route(
                "/.well-known/oauth-protected-resource/mcp",
                endpoint=oauth_protected_resource,
            ),
            Route(
                "/.well-known/oauth-authorization-server",
                endpoint=oauth_authorization_server,
            ),
            Route("/mcp", endpoint=_MCPAsgiApp()),
        ],
        middleware=[
            Middleware(APIKeyMiddleware),
        ],
        lifespan=_lambda_lifespan,
    )
else:
    # Non-Lambda: use full MCP Starlette app with lifespan
    from contextlib import asynccontextmanager

    _mcp_app = mcp.streamable_http_app()

    @asynccontextmanager
    async def _lifespan(app):
        """Run FastMCP's session manager lifespan alongside our app."""
        async with _mcp_app.router.lifespan_context(app):
            yield

    app = Starlette(
        debug=os.environ.get("DEBUG", "false").lower() == "true",
        routes=[
            Route("/", endpoint=root),
            Route("/health", endpoint=health_check),
            Route("/ready", endpoint=readiness_check),
            Route(
                "/.well-known/oauth-protected-resource",
                endpoint=oauth_protected_resource,
            ),
            Route(
                "/.well-known/oauth-protected-resource/mcp",
                endpoint=oauth_protected_resource,
            ),
            Route(
                "/.well-known/oauth-authorization-server",
                endpoint=oauth_authorization_server,
            ),
            # Mount MCP's Starlette app at root — it exposes /mcp internally
            Mount("/", app=_mcp_app),
        ],
        middleware=[
            Middleware(APIKeyMiddleware),
        ],
        lifespan=_lifespan,
    )


# =============================================================================
# Entry Point
# =============================================================================


def main() -> None:
    """Run the VRIN MCP HTTP Server.

    This is the main entry point for remote deployment.

    Authentication modes:
    1. Per-request auth (recommended for shared servers):
       Clients pass API key or OAuth JWT via Authorization header.

    2. Server-wide auth (for single-user deployments):
       Set VRIN_API_KEY env var on server.
       All requests use that key.
    """
    # Check if server-wide API key is configured
    env_api_key = os.environ.get("VRIN_API_KEY")
    if env_api_key:
        is_enterprise = env_api_key.startswith("vrin_ent_")
        logger.info(
            f"Starting VRIN MCP HTTP Server v1.0.0 "
            f"(server-wide API key, enterprise={is_enterprise})"
        )
    else:
        logger.info(
            "Starting VRIN MCP HTTP Server v1.0.0 "
            "(per-request authentication mode)"
        )

    # Log OAuth config
    stytch_project = os.environ.get("STYTCH_PROJECT_ID")
    if stytch_project:
        logger.info(f"Stytch OAuth enabled (project: {stytch_project})")
    else:
        logger.info("Stytch OAuth not configured (API key auth only)")

    # Get host/port from environment
    host = os.environ.get("VRIN_HTTP_HOST", "0.0.0.0")
    port = int(os.environ.get("VRIN_HTTP_PORT", "8000"))

    logger.info(f"HTTP server listening on {host}:{port}")
    logger.info("Auth: 'Bearer vrin_xxx' (API key) or 'Bearer eyJ...' (OAuth JWT)")

    # Run with uvicorn
    uvicorn.run(
        app,
        host=host,
        port=port,
        log_level="info",
    )


if __name__ == "__main__":
    main()
