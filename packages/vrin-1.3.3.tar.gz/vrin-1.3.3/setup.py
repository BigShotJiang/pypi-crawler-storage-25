"""
Setup script for VRIN SDK
"""

from setuptools import setup, find_packages
import os


def read_readme():
    readme_path = os.path.join(os.path.dirname(__file__), "README.md")
    if os.path.exists(readme_path):
        with open(readme_path, "r", encoding="utf-8") as f:
            return f.read()
    return "VRIN Hybrid RAG SDK"


setup(
    name="vrin",
    version="1.2.0",
    author="VRIN Team",
    author_email="support@vrin.cloud",
    description="Knowledge reasoning infrastructure for AI — structure documents into a temporal knowledge graph, reason across them, and trace every answer to specific facts",
    long_description=read_readme(),
    long_description_content_type="text/markdown",
    url="https://vrin.cloud",
    project_urls={
        "Bug Tracker": "https://github.com/Vrin-cloud/vrin-sdk/issues",
        "Documentation": "https://docs.vrin.cloud",
        "Source Code": "https://github.com/Vrin-cloud/vrin-sdk",
    },
    packages=find_packages(exclude=["tests", "tests.*"]),
    classifiers=[
        "Development Status :: 5 - Production/Stable",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
    ],
    python_requires=">=3.9",
    install_requires=[
        "requests>=2.28.0",
        "typer>=0.9.0",
    ],
    entry_points={
        "console_scripts": [
            "vrin=vrin.cli:app",
        ],
    },
    extras_require={
        "dev": [
            "pytest>=7.0.0",
            "pytest-cov>=4.0.0",
            "black>=22.0.0",
            "mypy>=1.0.0",
        ],
    },
    keywords="ai, knowledge-graph, reasoning, knowledge-reasoning, temporal-graph, traceable-ai, mcp, enterprise-ai",
    license="MIT",
    zip_safe=False,
    include_package_data=True,
)
