# VRIN — Knowledge Reasoning Infrastructure for AI

The reasoning engine for AI that needs to be right.

VRIN structures your documents into a temporal knowledge graph and reasons across them — giving AI answers you can trace to specific facts.

| Benchmark | VRIN | Best Baseline | Gap |
|-----------|:----:|:-------------:|:---:|
| **MultiHop-RAG** | **95.1%** | 78.9% (GPT 5.2 w/ same docs) | +16.2pp |
| **MuSiQue** | **28% more accurate** | HippoRAG 2 (academic SOTA) | +10.6 EM |
| **FinQA** | **71.4%** | 11.1% (vector-only retrieval) | +640% |

## Installation

```bash
pip install vrin
```

## Quick Start

```python
from vrin import VRINClient

client = VRINClient(api_key="vrin_your_api_key")

# Insert knowledge
client.insert("ACME Corp reported $50M revenue in Q4 2025.", title="ACME Financials")

# Query — answers traced to specific facts
result = client.query("What is ACME's revenue?")
print(result["summary"])
```

## Bulk Ingestion with Adaptive Concurrency

Ingest hundreds of documents with automatic concurrency control. The SDK uses Netflix's Gradient2 algorithm to monitor backend latency and adjust parallelism in real time — ramping up when healthy, backing off when congested, retrying failures with exponential backoff, and running a sequential recovery pass for any remaining items. Zero information loss guaranteed.

```python
items = [
    {"content": "Apple reported $416B revenue in FY2025.", "title": "AAPL 10-K"},
    {"content": "Microsoft Cloud surpassed $50B quarterly.", "title": "MSFT Earnings"},
    # ... hundreds more
]

result = client.bulk_insert(items)
print(f"Ingested {result['completed']}/{result['total']} — "
      f"{result['facts_stored']} facts stored")
```

## Streaming

```python
for token in client.query("Summarize Q4 results", stream=True):
    print(token, end="", flush=True)
```

## Query Modes

```python
result = client.query(
    "Compare ACME and Widget Corp revenues",
    response_mode="research",     # "chat" | "thinking" | "research"
    query_depth="research",       # "basic" | "thinking" | "research"
)
```

## File Upload

```python
client.upload_file("report.pdf", save_to_memory=True)
```

## Conversations

```python
client.start_conversation()
r1 = client.continue_conversation("What was ACME's Q4 revenue?")
r2 = client.continue_conversation("How does that compare to Q3?")  # has context
client.end_conversation()
```

## MCP Integration

VRIN exposes an MCP (Model Context Protocol) server so any compatible AI assistant can query your knowledge base — Claude Code, Claude Desktop, Cursor, Windsurf, or custom agents.

Tools exposed: `vrin_query_async`, `vrin_check_job`, `vrin_search_entities`, `vrin_get_facts`

## Enterprise — Your Data Stays in Your Cloud

Enterprise API keys (`vrin_ent_*`) route all data through your own AWS/Azure account. Your knowledge graph, your vector store, your encryption keys. Data never touches our infrastructure.

```python
from vrin import VRINEnterpriseClient

client = VRINEnterpriseClient(api_key="vrin_ent_your_key")
result = client.query("What is our Q4 revenue?")
```

Three deployment modes: VRIN Cloud, Hybrid Cloud (your data, our compute), Private VPC (everything in your account).

## What Makes VRIN Different

| | Vector-Only Retrieval | VRIN |
|---|---|---|
| **Answers** | Similar-looking text chunks | Specific facts, traced to sources |
| **Temporal** | None — returns latest by similarity | Bi-temporal versioning: "What was true in Q3?" |
| **Cross-document** | Concatenates chunks | Traverses entity relationships across documents |
| **Numbers** | LLM interprets from raw text | Constraint extraction + validated numerical fields |
| **Aggregation** | LLM must infer | Explicit sum/count with calculation steps |
| **Audit trail** | Chunk-level at best | Fact-level with document, confidence, and provenance |

## License

MIT License — see LICENSE file for details.

---

**Built by the VRIN Team** | [vrin.cloud](https://vrin.cloud) | support@vrin.cloud
