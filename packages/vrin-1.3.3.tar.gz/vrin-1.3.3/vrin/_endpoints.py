"""
VRIN API endpoint constants — single source of truth.

All backend service URLs are defined here. No URL string literal
should appear in client code outside this module.
"""

# ---------------------------------------------------------------------------
# Base URLs
# ---------------------------------------------------------------------------

STREAMING_QUERY_URL = (
    "https://43tybsfy52ehi3fctubc7jwlpi0fgkcz.lambda-url.us-east-1.on.aws"
)
AUTH_API_URL = "https://gp7g651udc.execute-api.us-east-1.amazonaws.com/Prod"
MAIN_API_URL = "https://thuiu23t0c.execute-api.us-east-1.amazonaws.com/dev"
CHAT_API_URL = "https://cg7yind3j5.execute-api.us-east-1.amazonaws.com/dev"
CONVERSATIONS_API_URL = (
    "https://rthl3rcg2b.execute-api.us-east-1.amazonaws.com/Stage"
)
ENTERPRISE_PORTAL_URL = (
    "https://6xjf0e7djg.execute-api.us-east-1.amazonaws.com/dev"
)
ENTERPRISE_TEAMS_URL = (
    "https://tug6uyfdb4.execute-api.us-east-1.amazonaws.com/dev"
)
ENTERPRISE_PERMS_URL = (
    "https://e4oqdoz0j4.execute-api.us-east-1.amazonaws.com/dev"
)


# ---------------------------------------------------------------------------
# Streaming / Query endpoints
# ---------------------------------------------------------------------------

def query_url() -> str:
    return f"{STREAMING_QUERY_URL}/query"


def health_url() -> str:
    return f"{MAIN_API_URL}/health"


# ---------------------------------------------------------------------------
# Knowledge management (MAIN_API_URL)
# ---------------------------------------------------------------------------

def insert_url() -> str:
    return f"{MAIN_API_URL}/insert"


def job_status_url(job_id: str) -> str:
    return f"{MAIN_API_URL}/job-status/{job_id}"


def specialize_url() -> str:
    return f"{MAIN_API_URL}/specialize"


def graph_url() -> str:
    return f"{MAIN_API_URL}/graph"


# ---------------------------------------------------------------------------
# Auth endpoints (AUTH_API_URL)
# ---------------------------------------------------------------------------

def signup_url() -> str:
    return f"{AUTH_API_URL}/api/auth/signup"


def login_url() -> str:
    return f"{AUTH_API_URL}/api/auth/login"


def api_keys_url() -> str:
    return f"{AUTH_API_URL}/api/auth/api-keys"


def create_api_key_url() -> str:
    return f"{AUTH_API_URL}/api/auth/create-api-key"


def delete_api_key_url() -> str:
    return f"{AUTH_API_URL}/api/auth/delete-api-key"


def user_limits_url() -> str:
    return f"{AUTH_API_URL}/api/user/limits"


# Device auth (CLI login) — RFC 8628
def device_code_init_url() -> str:
    return f"{AUTH_API_URL}/auth/device/code"


def device_code_poll_url() -> str:
    return f"{AUTH_API_URL}/auth/device/token"


# ---------------------------------------------------------------------------
# File upload (CHAT_API_URL)
# ---------------------------------------------------------------------------

def upload_url() -> str:
    return f"{CHAT_API_URL}/upload"


def upload_status_url(upload_id: str) -> str:
    return f"{CHAT_API_URL}/upload/{upload_id}/status"


# ---------------------------------------------------------------------------
# Conversations (CONVERSATIONS_API_URL)
# ---------------------------------------------------------------------------

def conversations_url() -> str:
    return f"{CONVERSATIONS_API_URL}/conversations"


def conversation_url(conversation_id: str) -> str:
    return f"{CONVERSATIONS_API_URL}/conversations/{conversation_id}"


def conversation_title_url(conversation_id: str) -> str:
    return f"{CONVERSATIONS_API_URL}/conversations/{conversation_id}/title"


def conversation_resume_url(conversation_id: str) -> str:
    return f"{CONVERSATIONS_API_URL}/conversations/{conversation_id}/resume"


# ---------------------------------------------------------------------------
# Enterprise portal (ENTERPRISE_PORTAL_URL)
# ---------------------------------------------------------------------------

def enterprise_organization_url() -> str:
    return f"{ENTERPRISE_PORTAL_URL}/enterprise/organization"


def enterprise_users_url() -> str:
    return f"{ENTERPRISE_PORTAL_URL}/enterprise/users"


def enterprise_api_keys_url() -> str:
    return f"{ENTERPRISE_PORTAL_URL}/enterprise/api-keys"


def enterprise_configuration_url() -> str:
    return f"{ENTERPRISE_PORTAL_URL}/enterprise/configuration"


def enterprise_validate_connectivity_url() -> str:
    return f"{ENTERPRISE_PORTAL_URL}/enterprise/validate-connectivity"
