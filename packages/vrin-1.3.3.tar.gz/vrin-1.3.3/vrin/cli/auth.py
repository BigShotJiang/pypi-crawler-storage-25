"""Auth commands: vrin auth login|register|keys|create-key|delete-key."""

from typing import Optional

import typer

from ._client import get_client
from ._output import is_json_mode, output_error, output_success
from .query import _handle_error

auth_app = typer.Typer(name="auth", help="Authentication and API key management.")


@auth_app.command("login")
def login_command(
    email: str = typer.Argument(..., help="Account email"),
    json_output: bool = typer.Option(False, "--json", help="Force JSON output"),
) -> None:
    """Log in to VRIN (prompts for password)."""
    from ..client import VRINClient

    json_mode = is_json_mode(force_json=json_output)
    password = typer.prompt("Password", hide_input=True)

    try:
        result = VRINClient.login(email, password)
        output_success(result, json_mode=json_mode)
    except Exception as e:
        _handle_error(e)


@auth_app.command("register")
def register_command(
    email: str = typer.Argument(..., help="Account email"),
    name: Optional[str] = typer.Option(None, "--name", help="Display name"),
    json_output: bool = typer.Option(False, "--json", help="Force JSON output"),
) -> None:
    """Register a new VRIN account (prompts for password)."""
    from ..client import VRINClient

    json_mode = is_json_mode(force_json=json_output)
    password = typer.prompt("Password", hide_input=True)
    confirm = typer.prompt("Confirm password", hide_input=True)

    if password != confirm:
        output_error("Passwords do not match", code="validation_error")
        raise SystemExit(4)

    try:
        result = VRINClient.register(email, password, name=name)
        output_success(result, json_mode=json_mode)
    except Exception as e:
        _handle_error(e)


@auth_app.command("keys")
def keys_command(
    json_output: bool = typer.Option(False, "--json", help="Force JSON output"),
) -> None:
    """List your API keys."""
    client = get_client()
    json_mode = is_json_mode(force_json=json_output)
    try:
        result = client.list_api_keys()
        output_success(result, json_mode=json_mode)
    except Exception as e:
        _handle_error(e)


@auth_app.command("create-key")
def create_key_command(
    name: Optional[str] = typer.Option(None, "--name", help="Key name/label"),
    json_output: bool = typer.Option(False, "--json", help="Force JSON output"),
) -> None:
    """Create a new API key."""
    client = get_client()
    json_mode = is_json_mode(force_json=json_output)
    try:
        result = client.create_api_key(name=name)
        output_success(result, json_mode=json_mode)
    except Exception as e:
        _handle_error(e)


@auth_app.command("delete-key")
def delete_key_command(
    key_id: str = typer.Argument(..., help="API key ID to delete"),
    json_output: bool = typer.Option(False, "--json", help="Force JSON output"),
) -> None:
    """Delete an API key."""
    client = get_client()
    json_mode = is_json_mode(force_json=json_output)
    try:
        result = client.delete_api_key(key_id)
        output_success(result, json_mode=json_mode)
    except Exception as e:
        _handle_error(e)
