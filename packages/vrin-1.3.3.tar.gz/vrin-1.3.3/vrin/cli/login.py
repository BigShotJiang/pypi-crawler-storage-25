"""Commands: ``vrin login``, ``vrin logout``, ``vrin whoami``.

Implements the CLI half of the RFC 8628 device authorization flow. The
user runs ``vrin login``, the CLI fetches a ``user_code``, opens the
browser to ``/activate``, the user approves in their logged-in VRIN
session, and the CLI finishes with a ``vrin_live_…`` API key persisted
to the local credentials file.
"""

from __future__ import annotations

import sys
import time
import webbrowser
from typing import Any, Dict

import typer

from ..client import VRINClient
from . import _credentials as creds
from ._output import is_json_mode, output_error, output_success


_DEFAULT_TIMEOUT_SECONDS = 600  # matches backend expires_in
_MIN_POLL_INTERVAL = 2


def login_command(
    no_browser: bool = typer.Option(
        False, "--no-browser", help="Don't attempt to open the browser; just print the URL"
    ),
    json_output: bool = typer.Option(
        False, "--json", help="Force JSON output (no prompts, no color)"
    ),
) -> None:
    """Log in to VRIN (opens browser, no key-copying required)."""
    json_mode = is_json_mode(force_json=json_output)

    # Resume path: a prior `vrin login` may have crashed or been killed after
    # the user actually approved in the browser. The approval committed to the
    # backend but the dead CLI never claimed the key. Try that first — if the
    # device_code is still valid and approved, we're done in one request.
    resumed = _try_resume_pending(json_mode=json_mode)
    if resumed:
        return

    try:
        init = VRINClient.device_code_init()
    except Exception as e:
        output_error(f"Could not start login: {e}", code="device_init_failed")
        raise SystemExit(2)

    device_code = init.get("device_code", "")
    user_code = init.get("user_code", "")
    verification_uri = init.get("verification_uri", "")
    verification_uri_complete = init.get("verification_uri_complete") or verification_uri
    expires_in = int(init.get("expires_in") or _DEFAULT_TIMEOUT_SECONDS)
    interval = max(int(init.get("interval") or _MIN_POLL_INTERVAL), _MIN_POLL_INTERVAL)

    if not (device_code and user_code and verification_uri):
        output_error("Invalid response from auth server", code="device_init_failed")
        raise SystemExit(2)

    # Persist the in-flight flow so a Ctrl+C / kill / crash can recover.
    creds.save_pending_login(
        device_code=device_code,
        user_code=user_code,
        expires_at=int(time.time()) + expires_in,
    )

    if json_mode:
        # Non-interactive / agent path: print the metadata, then quietly poll
        # until we either succeed or hit a terminal error.
        print_json({
            "action": "verify",
            "user_code": user_code,
            "verification_uri": verification_uri,
            "verification_uri_complete": verification_uri_complete,
            "expires_in": expires_in,
        })
    else:
        typer.echo()
        typer.echo(f"! First copy your one-time code: {typer.style(user_code, bold=True)}")
        typer.echo(f"  Press Enter to open {verification_uri} in your browser...")
        try:
            input()  # noqa: S322 — deliberate blocking prompt
        except (KeyboardInterrupt, EOFError):
            typer.echo("")
            raise SystemExit(130)
        if not no_browser:
            try:
                webbrowser.open(verification_uri_complete)
            except Exception:
                pass  # browser open is best-effort; user has the URL already
        typer.echo("")
        typer.echo("Waiting for approval...", nl=False)

    try:
        result = _poll(device_code, interval=interval, timeout=expires_in, json_mode=json_mode)
    except (KeyboardInterrupt, SystemExit):
        # Leave the pending-login file in place so a re-run of `vrin login`
        # can claim the key if the user approved while we were dying.
        raise

    if "api_key" not in result:
        err = result.get("error", "unknown_error")
        # Denied / expired are terminal — drop the pending record so the next
        # `vrin login` starts fresh instead of resuming a dead flow.
        if err in ("access_denied", "expired_token", "timeout"):
            creds.clear_pending_login()
        output_error(_friendly_error(err), code=err)
        raise SystemExit(2)

    credentials = {
        "api_key": result["api_key"],
        "user_id": result.get("user_id", ""),
        "email": result.get("email", ""),
        "name": result.get("name", ""),
        "created_at": int(time.time()),
    }
    path = creds.save(credentials)
    creds.clear_pending_login()

    if json_mode:
        output_success(
            {
                "success": True,
                "email": credentials["email"],
                "name": credentials["name"],
                "credentials_path": str(path),
            },
            json_mode=True,
        )
        return

    typer.echo("")
    display_name = credentials["name"] or credentials["email"] or "your account"
    typer.echo(typer.style(f"✓ Signed in as {display_name}", fg=typer.colors.GREEN))
    if credentials["email"] and credentials["name"]:
        typer.echo(f"  ({credentials['email']})")
    typer.echo(f"  credentials stored at {path}")


def logout_command(
    json_output: bool = typer.Option(False, "--json", help="Force JSON output"),
) -> None:
    """Sign out and remove local credentials."""
    json_mode = is_json_mode(force_json=json_output)
    removed = creds.clear()
    # Belt-and-suspenders: drop any half-finished login state too so
    # `vrin login` after `vrin logout` starts from a clean slate.
    creds.clear_pending_login()
    if json_mode:
        output_success({"success": True, "removed": removed}, json_mode=True)
        return
    if removed:
        typer.echo(typer.style("Signed out.", fg=typer.colors.GREEN))
    else:
        typer.echo("No local credentials found. Nothing to do.")


def whoami_command(
    json_output: bool = typer.Option(False, "--json", help="Force JSON output"),
) -> None:
    """Show who is currently signed in."""
    json_mode = is_json_mode(force_json=json_output)
    creds_data = creds.load()
    import os as _os
    env_key = _os.environ.get("VRIN_API_KEY", "").strip()

    if env_key:
        if json_mode:
            output_success(
                {"source": "env", "api_key_prefix": env_key[:12] + "…"},
                json_mode=True,
            )
            return
        typer.echo("Signed in via VRIN_API_KEY env var")
        typer.echo(f"  key prefix: {env_key[:12]}…")
        return

    if not creds_data:
        output_error(
            "Not signed in. Run 'vrin login' to sign in.",
            code="not_signed_in",
        )
        raise SystemExit(2)

    if json_mode:
        output_success(
            {
                "source": "credentials_file",
                "email": creds_data.get("email", ""),
                "name": creds_data.get("name", ""),
            },
            json_mode=True,
        )
        return
    typer.echo(f"Signed in as {creds_data.get('name') or creds_data.get('email') or '(unknown)'}")
    if creds_data.get("email"):
        typer.echo(f"  email: {creds_data['email']}")


# ---------------------------------------------------------------------------
# Internals
# ---------------------------------------------------------------------------


def _try_resume_pending(*, json_mode: bool) -> bool:
    """If a prior login crashed after the user approved, claim the key now.

    Returns True if we successfully recovered credentials (caller should
    return). Returns False if there's nothing to resume or the pending
    state is unusable — caller should proceed with a new flow.
    """
    pending = creds.load_pending_login()
    if not pending:
        return False

    device_code = pending.get("device_code", "")
    if not device_code or int(time.time()) > int(pending.get("expires_at", 0)):
        creds.clear_pending_login()
        return False

    try:
        resp = VRINClient.device_code_poll(device_code)
    except Exception:
        # Network hiccup — don't burn the pending state; let the caller
        # start a fresh flow so the user isn't blocked on a transient.
        return False

    if "api_key" in resp:
        credentials = {
            "api_key": resp["api_key"],
            "user_id": resp.get("user_id", ""),
            "email": resp.get("email", ""),
            "name": resp.get("name", ""),
            "created_at": int(time.time()),
        }
        path = creds.save(credentials)
        creds.clear_pending_login()
        if json_mode:
            output_success(
                {
                    "success": True,
                    "resumed": True,
                    "email": credentials["email"],
                    "name": credentials["name"],
                    "credentials_path": str(path),
                },
                json_mode=True,
            )
        else:
            display = credentials["name"] or credentials["email"] or "your account"
            typer.echo(typer.style(
                f"✓ Resumed previous login — signed in as {display}",
                fg=typer.colors.GREEN,
            ))
            if credentials["email"] and credentials["name"]:
                typer.echo(f"  ({credentials['email']})")
            typer.echo(f"  credentials stored at {path}")
        return True

    # Any non-approval response (authorization_pending, access_denied,
    # expired_token, slow_down, server_error, …) means the old flow is
    # unusable. Clear the pending record so the caller starts a brand-new
    # device-code flow without a stale user_code hanging around.
    creds.clear_pending_login()
    return False


def _poll(device_code: str, *, interval: int, timeout: int, json_mode: bool) -> Dict[str, Any]:
    """Poll until approval, denial, or timeout. RFC 8628 error handling."""
    deadline = time.time() + timeout
    current_interval = interval
    while time.time() < deadline:
        try:
            resp = VRINClient.device_code_poll(device_code)
        except Exception as e:
            return {"error": f"server_error: {e}"}

        if "api_key" in resp:
            if not json_mode:
                typer.echo("")  # newline after the dots
            return resp

        err = resp.get("error", "")
        if err == "authorization_pending":
            if not json_mode:
                typer.echo(".", nl=False)
            time.sleep(current_interval)
            continue
        if err == "slow_down":
            current_interval += 5
            time.sleep(current_interval)
            continue
        if err in ("access_denied", "expired_token"):
            if not json_mode:
                typer.echo("")
            return resp
        # Unknown error — surface it and bail.
        if not json_mode:
            typer.echo("")
        return resp
    return {"error": "timeout"}


def _friendly_error(code: str) -> str:
    return {
        "authorization_pending": "Still waiting for approval — try again.",
        "access_denied": "Access was denied in the browser.",
        "expired_token": "The login request expired. Run 'vrin login' again.",
        "timeout": "Timed out waiting for approval. Run 'vrin login' again.",
        "invalid_request": "Invalid request to auth server.",
        "server_error": "The auth server had a problem. Try again in a minute.",
    }.get(code, f"Login failed: {code}")


def print_json(data: Dict[str, Any]) -> None:
    import json as _json
    sys.stdout.write(_json.dumps(data) + "\n")
    sys.stdout.flush()
