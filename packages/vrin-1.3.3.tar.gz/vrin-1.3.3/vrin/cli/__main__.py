"""Allow ``python -m vrin.cli`` invocation."""

from . import app

app()
