"""Admin commands: vrin health, vrin limits, vrin specialize, vrin graph."""

from typing import Optional

import typer

from ._client import get_client
from ._output import is_json_mode, output_success
from .query import _handle_error

admin_app = typer.Typer(name="admin-commands", hidden=True)


def health_command(
    json_output: bool = typer.Option(False, "--json", help="Force JSON output"),
) -> None:
    """Check VRIN service health."""
    client = get_client()
    json_mode = is_json_mode(force_json=json_output)
    try:
        result = client.health_check()
        output_success(result, json_mode=json_mode)
    except Exception as e:
        _handle_error(e)


def limits_command(
    json_output: bool = typer.Option(False, "--json", help="Force JSON output"),
) -> None:
    """Show current plan and usage limits."""
    client = get_client()
    json_mode = is_json_mode(force_json=json_output)
    try:
        result = client.get_limits()
        output_success(result, json_mode=json_mode)
    except Exception as e:
        _handle_error(e)


def specialize_command(
    prompt: Optional[str] = typer.Argument(None, help="Custom system prompt for AI"),
    get: bool = typer.Option(False, "--get", help="Get current specialization instead of setting"),
    json_output: bool = typer.Option(False, "--json", help="Force JSON output"),
) -> None:
    """Set or get AI specialization/persona."""
    client = get_client()
    json_mode = is_json_mode(force_json=json_output)
    try:
        if get or prompt is None:
            result = client.get_specialization()
        else:
            result = client.specialize(prompt)
        output_success(result, json_mode=json_mode)
    except Exception as e:
        _handle_error(e)


def graph_command(
    limit: int = typer.Option(100, "--limit", "-n", help="Max nodes to return"),
    json_output: bool = typer.Option(False, "--json", help="Force JSON output"),
) -> None:
    """Get knowledge graph visualization data."""
    client = get_client()
    json_mode = is_json_mode(force_json=json_output)
    try:
        result = client.get_knowledge_graph(limit=limit)
        output_success(result, json_mode=json_mode)
    except Exception as e:
        _handle_error(e)
