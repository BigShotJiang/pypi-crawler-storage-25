"""VRIN CLI — query and manage your knowledge base from the terminal.

Entry point: ``vrin`` command (registered via pyproject.toml console_scripts).
"""

import json
import sys
from typing import Optional

import typer

from .. import __version__

from .admin import graph_command, health_command, limits_command, specialize_command
from .auth import auth_app
from .conversations import conversation_app
from .knowledge import bulk_insert_command, insert_command, job_command, upload_command
from .login import login_command, logout_command, whoami_command
from .query import facts_command, query_command

# ---------------------------------------------------------------------------
# Main app
# ---------------------------------------------------------------------------

app = typer.Typer(
    name="vrin",
    help="VRIN — query and manage your knowledge base.",
    no_args_is_help=True,
    add_completion=False,
)

# Top-level commands
app.command("login", help="Sign in to VRIN via browser")(login_command)
app.command("logout", help="Sign out and remove local credentials")(logout_command)
app.command("whoami", help="Show who is currently signed in")(whoami_command)
app.command("query", help="Query the knowledge base")(query_command)
app.command("facts", help="Fast fact retrieval (no AI summary)")(facts_command)
app.command("health", help="Check service health")(health_command)
app.command("limits", help="Show plan and usage limits")(limits_command)
app.command("specialize", help="Set or get AI specialization")(specialize_command)
app.command("graph", help="Get knowledge graph data")(graph_command)

# Knowledge management commands
app.command("insert", help="Insert text into the knowledge base")(insert_command)
app.command("upload", help="Upload a file to the knowledge base")(upload_command)
app.command("bulk-insert", help="Bulk insert from a JSON file")(bulk_insert_command)
app.command("job", help="Check async job status")(job_command)

# Subcommand groups
app.add_typer(conversation_app, name="conversation")
app.add_typer(auth_app, name="auth")


# ---------------------------------------------------------------------------
# Top-level flags handled via callback
# ---------------------------------------------------------------------------


def _version_callback(value: bool) -> None:
    if value:
        print(f"vrin {__version__}")
        raise typer.Exit()


def _describe_callback(value: bool) -> None:
    """Output machine-readable JSON schema of all commands."""
    if value:
        schema = _build_describe_schema()
        print(json.dumps(schema, indent=2))
        raise typer.Exit()


@app.callback()
def main(
    version: Optional[bool] = typer.Option(
        None, "--version", "-V", callback=_version_callback, is_eager=True,
        help="Show version and exit",
    ),
    describe: Optional[bool] = typer.Option(
        None, "--describe", callback=_describe_callback, is_eager=True,
        help="Output machine-readable command schema (JSON)",
    ),
) -> None:
    """VRIN CLI — knowledge reasoning infrastructure for AI."""


# ---------------------------------------------------------------------------
# --describe schema builder
# ---------------------------------------------------------------------------


def _build_describe_schema() -> dict:
    return {
        "name": "vrin",
        "version": __version__,
        "auth": "Run 'vrin login' to sign in (opens browser). For headless/CI, set VRIN_API_KEY env var.",
        "output": "JSON by default when stdout is not a TTY; human-readable at TTY. Use --json to force JSON.",
        "commands": {
            "login": {
                "description": "Sign in via browser (RFC 8628 device flow)",
                "flags": {
                    "--no-browser": "Skip opening the browser; just print the URL",
                    "--json": "Force JSON output (no prompts)",
                },
            },
            "logout": {
                "description": "Sign out and remove local credentials",
                "flags": {"--json": "Force JSON output"},
            },
            "whoami": {
                "description": "Show who is currently signed in",
                "flags": {"--json": "Force JSON output"},
            },
            "query": {
                "description": "Retrieve context (facts + chunks + sources) from the knowledge base. Always context-only — no LLM summary.",
                "args": {"question": {"type": "str", "required": True}},
                "flags": {
                    "--json": "Force JSON output",
                },
            },
            "facts": {
                "description": "Fast fact retrieval without AI summary",
                "args": {"question": {"type": "str", "required": True}},
                "flags": {"--json": "Force JSON output"},
            },
            "insert": {
                "description": "Insert text into the knowledge base",
                "args": {"content": {"type": "str", "required": True}},
                "flags": {
                    "--title": "Document title (default: Untitled)",
                    "--tag": "Tag to attach (repeatable)",
                    "--wait/--no-wait": "Wait for processing (default: wait)",
                    "--dry-run": "Show payload without sending",
                    "--json": "Force JSON output",
                },
            },
            "upload": {
                "description": "Upload a file to the knowledge base",
                "args": {"file": {"type": "path", "required": True}},
                "flags": {
                    "--save-to-memory/--no-save-to-memory": "Persist extracted knowledge (default: save)",
                    "--wait/--no-wait": "Wait for processing (default: wait)",
                    "--json": "Force JSON output",
                },
            },
            "bulk-insert": {
                "description": "Bulk insert from a JSON file",
                "args": {"file": {"type": "path", "required": True}},
                "flags": {
                    "--concurrency": "Initial concurrent workers (default: 8)",
                    "--max-concurrency": "Max concurrent workers (default: 25)",
                    "--json": "Force JSON output",
                },
            },
            "job": {
                "description": "Check async job status",
                "args": {"job_id": {"type": "str", "required": True}},
                "flags": {
                    "--wait": "Poll until completion",
                    "--json": "Force JSON output",
                },
            },
            "conversation": {
                "description": "Manage conversations",
                "subcommands": {
                    "list": "List conversations",
                    "get <id>": "Get full conversation history",
                    "delete <id>": "Delete a conversation",
                    "rename <id> <title>": "Rename a conversation",
                },
            },
            "auth": {
                "description": "Authentication and API key management",
                "subcommands": {
                    "login <email>": "Log in (prompts for password)",
                    "register <email>": "Register new account",
                    "keys": "List API keys",
                    "create-key": "Create a new API key",
                    "delete-key <id>": "Delete an API key",
                },
            },
            "health": {
                "description": "Check service health",
                "flags": {"--json": "Force JSON output"},
            },
            "limits": {
                "description": "Show plan and usage limits",
                "flags": {"--json": "Force JSON output"},
            },
            "specialize": {
                "description": "Set or get AI specialization",
                "args": {"prompt": {"type": "str", "required": False}},
                "flags": {
                    "--get": "Get current specialization",
                    "--json": "Force JSON output",
                },
            },
            "graph": {
                "description": "Get knowledge graph data",
                "flags": {
                    "--limit": "Max nodes to return (default: 100)",
                    "--json": "Force JSON output",
                },
            },
        },
    }


# ---------------------------------------------------------------------------
# Allow `python -m vrin.cli`
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    app()
