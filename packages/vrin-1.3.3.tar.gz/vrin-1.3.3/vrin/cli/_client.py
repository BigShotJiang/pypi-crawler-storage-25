"""Shared client factory for CLI commands."""

import os
import sys

from .. import get_enterprise_client
from ..client import VRINClient
from . import _credentials


def get_client() -> VRINClient:
    """Create a VRINClient from whichever credential source is available.

    Precedence (highest first):
      1. ``VRIN_API_KEY`` env var — agent/CI path. Unchanged behavior for
         headless environments and automation.
      2. ``~/.config/vrin/credentials.json`` — populated by ``vrin login``.
      3. Error with hint to run ``vrin login`` or set the env var.

    Automatically routes ``vrin_ent_*`` keys to VRINEnterpriseClient.
    """
    api_key = os.environ.get("VRIN_API_KEY", "").strip()
    if not api_key:
        stored = _credentials.load()
        if stored:
            api_key = (stored.get("api_key") or "").strip()

    if not api_key:
        from ._output import output_error

        output_error(
            "Not signed in. Run 'vrin login' to sign in, "
            "or set VRIN_API_KEY for headless use.",
            code="auth_missing",
        )
        sys.exit(2)

    return get_enterprise_client(api_key)
