"""Output formatting for CLI — JSON (machine) and human-readable modes."""

import json
import os
import sys
from typing import Any, Dict, Optional


def is_json_mode(*, force_json: bool = False) -> bool:
    """Return True when output should be JSON.

    JSON is used when:
    - ``--json`` flag was passed (force_json=True)
    - ``VRIN_OUTPUT=json`` env var is set
    - stdout is not a TTY (piped / called by an agent)
    """
    if force_json:
        return True
    if os.environ.get("VRIN_OUTPUT", "").lower() == "json":
        return True
    return not sys.stdout.isatty()


def output_success(data: Any, *, json_mode: bool = False) -> None:
    """Print a success response to stdout."""
    if is_json_mode(force_json=json_mode):
        print(json.dumps({"ok": True, "data": data}, default=str))
    else:
        _print_human(data)


def output_error(
    message: str,
    *,
    code: str = "error",
    hint: str = "",
    json_mode: bool = False,
) -> None:
    """Print an error to stderr (always JSON-formatted for parseability)."""
    err: Dict[str, Any] = {"ok": False, "error": {"code": code, "message": message}}
    if hint:
        err["error"]["hint"] = hint
    sys.stderr.write(json.dumps(err, default=str) + "\n")


def output_stream_token(token: str) -> None:
    """Write a single streaming token to stdout without a newline."""
    sys.stdout.write(token)
    sys.stdout.flush()


def output_stream_meta(info: str) -> None:
    """Write stream metadata to stderr after streaming completes."""
    sys.stderr.write(info + "\n")


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _print_human(data: Any, indent: int = 0) -> None:
    """Pretty-print data for human consumption."""
    prefix = "  " * indent
    if isinstance(data, dict):
        for key, value in data.items():
            if isinstance(value, (dict, list)):
                print(f"{prefix}{key}:")
                _print_human(value, indent + 1)
            else:
                print(f"{prefix}{key}: {value}")
    elif isinstance(data, list):
        for i, item in enumerate(data):
            if isinstance(item, dict):
                if i > 0:
                    print(f"{prefix}---")
                _print_human(item, indent)
            else:
                print(f"{prefix}- {item}")
    else:
        print(f"{prefix}{data}")
