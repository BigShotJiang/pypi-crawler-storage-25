"""Conversation commands: vrin conversation list|get|delete|rename."""

import typer

from ._client import get_client
from ._output import is_json_mode, output_error, output_success
from .query import _handle_error

conversation_app = typer.Typer(name="conversation", help="Manage conversations.")


@conversation_app.command("list")
def list_command(
    limit: int = typer.Option(50, "--limit", "-n", help="Max conversations to return"),
    json_output: bool = typer.Option(False, "--json", help="Force JSON output"),
) -> None:
    """List conversations."""
    client = get_client()
    json_mode = is_json_mode(force_json=json_output)
    try:
        result = client.list_conversations(limit=limit)
        output_success(result, json_mode=json_mode)
    except Exception as e:
        _handle_error(e)


@conversation_app.command("get")
def get_command(
    conversation_id: str = typer.Argument(..., help="Conversation ID"),
    json_output: bool = typer.Option(False, "--json", help="Force JSON output"),
) -> None:
    """Get full conversation history."""
    client = get_client()
    json_mode = is_json_mode(force_json=json_output)
    try:
        result = client.get_conversation(conversation_id)
        output_success(result, json_mode=json_mode)
    except Exception as e:
        _handle_error(e)


@conversation_app.command("delete")
def delete_command(
    conversation_id: str = typer.Argument(..., help="Conversation ID"),
    force: bool = typer.Option(False, "--force", "-f", help="Skip confirmation"),
    json_output: bool = typer.Option(False, "--json", help="Force JSON output"),
) -> None:
    """Delete a conversation."""
    json_mode = is_json_mode(force_json=json_output)

    if not force and not json_mode:
        confirm = typer.confirm(f"Delete conversation {conversation_id}?")
        if not confirm:
            raise typer.Abort()

    client = get_client()
    try:
        success = client.delete_conversation(conversation_id)
        output_success({"deleted": success, "conversation_id": conversation_id}, json_mode=json_mode)
    except Exception as e:
        _handle_error(e)


@conversation_app.command("rename")
def rename_command(
    conversation_id: str = typer.Argument(..., help="Conversation ID"),
    title: str = typer.Argument(..., help="New title"),
    json_output: bool = typer.Option(False, "--json", help="Force JSON output"),
) -> None:
    """Rename a conversation."""
    client = get_client()
    json_mode = is_json_mode(force_json=json_output)
    try:
        success = client.rename_conversation(conversation_id, title)
        output_success({"renamed": success, "conversation_id": conversation_id, "title": title}, json_mode=json_mode)
    except Exception as e:
        _handle_error(e)
