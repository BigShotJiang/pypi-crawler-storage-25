"""Knowledge management commands: vrin insert, vrin upload, vrin bulk-insert, vrin job."""

import json
import sys
from pathlib import Path
from typing import List, Optional

import typer

from ._client import get_client
from ._output import is_json_mode, output_error, output_stream_meta, output_success
from .query import _handle_error


def insert_command(
    content: str = typer.Argument(..., help="Text content to insert"),
    title: str = typer.Option("Untitled", "--title", "-t", help="Document title"),
    tags: Optional[List[str]] = typer.Option(None, "--tag", help="Tags (repeatable)"),
    metadata_json: Optional[str] = typer.Option(None, "--metadata", help="Metadata as JSON string"),
    wait: bool = typer.Option(True, "--wait/--no-wait", help="Wait for processing to complete"),
    dry_run: bool = typer.Option(False, "--dry-run", help="Show payload without sending"),
    json_output: bool = typer.Option(False, "--json", help="Force JSON output"),
) -> None:
    """Insert text content into the knowledge base."""
    json_mode = is_json_mode(force_json=json_output)

    metadata = {}
    if metadata_json:
        try:
            metadata = json.loads(metadata_json)
        except json.JSONDecodeError:
            output_error("Invalid JSON in --metadata", code="validation_error")
            raise SystemExit(4)

    payload = {
        "content": content,
        "title": title,
        "tags": tags or [],
        "metadata": metadata,
    }

    if dry_run:
        output_success({"dry_run": True, "payload": payload}, json_mode=json_mode)
        return

    client = get_client()
    try:
        result = client.insert(
            content,
            title=title,
            tags=tags or [],
            metadata=metadata,
            wait=wait,
        )
        if isinstance(result, str):
            # wait=False returns job_id string
            output_success({"job_id": result}, json_mode=json_mode)
        else:
            output_success(result, json_mode=json_mode)
    except Exception as e:
        _handle_error(e)


def upload_command(
    file_path: Path = typer.Argument(..., help="Path to file to upload", exists=True, readable=True),
    save_to_memory: bool = typer.Option(True, "--save-to-memory/--no-save-to-memory", help="Persist extracted knowledge"),
    wait: bool = typer.Option(True, "--wait/--no-wait", help="Wait for processing to complete"),
    json_output: bool = typer.Option(False, "--json", help="Force JSON output"),
) -> None:
    """Upload a file to the knowledge base."""
    client = get_client()
    json_mode = is_json_mode(force_json=json_output)
    try:
        result = client.upload_file(
            str(file_path),
            save_to_memory=save_to_memory,
            wait=wait,
        )
        output_success(result, json_mode=json_mode)
    except FileNotFoundError as e:
        output_error(str(e), code="file_not_found")
        raise SystemExit(4)
    except Exception as e:
        _handle_error(e)


def bulk_insert_command(
    file_path: Path = typer.Argument(..., help="JSON file with items to insert", exists=True, readable=True),
    concurrency: int = typer.Option(8, "--concurrency", help="Initial concurrent workers"),
    max_concurrency: int = typer.Option(25, "--max-concurrency", help="Max concurrent workers"),
    tags: Optional[List[str]] = typer.Option(None, "--tag", help="Default tags for all items"),
    json_output: bool = typer.Option(False, "--json", help="Force JSON output"),
) -> None:
    """Bulk insert items from a JSON file.

    File format: JSON array of objects with "content" (required), "title", "tags", "metadata".
    """
    json_mode = is_json_mode(force_json=json_output)

    try:
        items = json.loads(file_path.read_text())
    except json.JSONDecodeError:
        output_error(f"Invalid JSON in {file_path}", code="validation_error")
        raise SystemExit(4)

    if not isinstance(items, list):
        output_error("JSON file must contain an array of objects", code="validation_error")
        raise SystemExit(4)

    client = get_client()

    def _on_progress(done: int, total: int, result: dict) -> None:
        if not json_mode:
            status = result.get("status", "?")
            title = result.get("title", "")[:40]
            output_stream_meta(f"[{done}/{total}] {status}: {title}")

    try:
        result = client.bulk_insert(
            items,
            initial_concurrency=concurrency,
            max_concurrency=max_concurrency,
            tags=tags or [],
            on_progress=_on_progress,
        )
        output_success(result, json_mode=json_mode)
    except Exception as e:
        _handle_error(e)


def job_command(
    job_id: str = typer.Argument(..., help="Job ID to check"),
    wait: bool = typer.Option(False, "--wait", help="Poll until completion"),
    json_output: bool = typer.Option(False, "--json", help="Force JSON output"),
) -> None:
    """Check the status of an async job."""
    client = get_client()
    json_mode = is_json_mode(force_json=json_output)
    try:
        if wait:
            result = client.wait_for_job(job_id)
        else:
            result = client.get_job_status(job_id)
        output_success(result, json_mode=json_mode)
    except Exception as e:
        _handle_error(e)
