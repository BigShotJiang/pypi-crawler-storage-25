"""Local credential store for the VRIN CLI.

Stores the user's api_key and profile at ``$XDG_CONFIG_HOME/vrin/credentials.json``
(falls back to ``~/.config/vrin/credentials.json``) with 0600 permissions.

This is the MVP store. Phase 2 moves to OS keychain (macOS Security / libsecret /
Windows Credential Manager) via the ``keyring`` package — the surface here is
compatible, only the backing storage swaps.
"""

from __future__ import annotations

import json
import os
import stat
from pathlib import Path
from typing import Any, Dict, Optional


def _config_dir() -> Path:
    """Resolve the VRIN config directory, honoring XDG_CONFIG_HOME."""
    xdg = os.environ.get("XDG_CONFIG_HOME", "").strip()
    base = Path(xdg) if xdg else Path.home() / ".config"
    return base / "vrin"


def credentials_path() -> Path:
    return _config_dir() / "credentials.json"


def save(credentials: Dict[str, Any]) -> Path:
    """Write credentials atomically with 0600 perms. Returns the file path."""
    path = credentials_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(".json.tmp")
    tmp.write_text(json.dumps(credentials, indent=2))
    # Tighten perms before the atomic rename so a brief window doesn't expose
    # the api_key via world-readable modes on systems where umask is loose.
    os.chmod(tmp, stat.S_IRUSR | stat.S_IWUSR)
    os.replace(tmp, path)
    os.chmod(path, stat.S_IRUSR | stat.S_IWUSR)
    return path


def load() -> Optional[Dict[str, Any]]:
    """Read credentials if present and well-formed, else None."""
    path = credentials_path()
    if not path.exists():
        return None
    try:
        return json.loads(path.read_text())
    except Exception:
        return None


def clear() -> bool:
    """Remove the credentials file. Returns True if a file was deleted."""
    path = credentials_path()
    if path.exists():
        path.unlink()
        return True
    return False


# ---------------------------------------------------------------------------
# Pending login state — lets a killed/crashed ``vrin login`` resume and
# claim its already-approved device_code on the next invocation.
# ---------------------------------------------------------------------------


def pending_login_path() -> Path:
    return _config_dir() / "pending-login.json"


def save_pending_login(device_code: str, user_code: str, expires_at: int) -> None:
    """Record an in-flight device-code flow so we can resume after a crash."""
    path = pending_login_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(".json.tmp")
    tmp.write_text(json.dumps({
        "device_code": device_code,
        "user_code": user_code,
        "expires_at": expires_at,
    }))
    os.chmod(tmp, stat.S_IRUSR | stat.S_IWUSR)
    os.replace(tmp, path)
    os.chmod(path, stat.S_IRUSR | stat.S_IWUSR)


def load_pending_login() -> Optional[Dict[str, Any]]:
    path = pending_login_path()
    if not path.exists():
        return None
    try:
        return json.loads(path.read_text())
    except Exception:
        return None


def clear_pending_login() -> None:
    path = pending_login_path()
    if path.exists():
        path.unlink()
