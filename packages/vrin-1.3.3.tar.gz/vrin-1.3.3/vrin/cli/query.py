"""Query commands: vrin query, vrin facts."""

from typing import Optional

import typer

from ._client import get_client
from ._output import is_json_mode, output_error, output_success


def query_command(
    question: str = typer.Argument(..., help="Question to retrieve context for"),
    json_output: bool = typer.Option(False, "--json", help="Force JSON output"),
) -> None:
    """Retrieve context from the VRIN knowledge base.

    Always returns structured context (facts + chunks + sources + entities)
    for a calling AI agent to synthesize from. Vrin does not generate a
    prose summary here — that's the agent's job.
    """
    client = get_client()
    json_mode = is_json_mode(force_json=json_output)

    try:
        result = client.get_context(question)
        output_success(result, json_mode=json_mode)
    except Exception as e:
        _handle_error(e)


def facts_command(
    question: str = typer.Argument(..., help="Topic or question for fact lookup"),
    json_output: bool = typer.Option(False, "--json", help="Force JSON output"),
) -> None:
    """Fast fact retrieval without AI summary generation."""
    client = get_client()
    json_mode = is_json_mode(force_json=json_output)

    try:
        result = client.get_raw_facts_only(question)
        output_success(result, json_mode=json_mode)
    except Exception as e:
        _handle_error(e)


def _handle_error(exc: Exception) -> None:
    """Map SDK exceptions to exit codes."""
    from ..exceptions import (
        AuthenticationError,
        JobFailedError,
        RateLimitError,
        ServiceUnavailableError,
        TimeoutError,
        ValidationError,
        VRINError,
    )

    if isinstance(exc, AuthenticationError):
        output_error(str(exc), code="auth_failed")
        raise SystemExit(2)
    elif isinstance(exc, RateLimitError):
        output_error(str(exc), code="rate_limited")
        raise SystemExit(3)
    elif isinstance(exc, ValidationError):
        output_error(str(exc), code="validation_error")
        raise SystemExit(4)
    elif isinstance(exc, JobFailedError):
        output_error(str(exc), code="job_failed")
        raise SystemExit(5)
    elif isinstance(exc, TimeoutError):
        output_error(str(exc), code="timeout")
        raise SystemExit(6)
    elif isinstance(exc, ServiceUnavailableError):
        output_error(str(exc), code="service_unavailable")
        raise SystemExit(7)
    elif isinstance(exc, VRINError):
        output_error(str(exc), code="vrin_error")
        raise SystemExit(1)
    else:
        output_error(str(exc), code="unexpected_error")
        raise SystemExit(1)
