"""
VRIN SDK Legacy Archive

These modules are from v0.8.x and earlier. They are kept here for reference
but are no longer imported by the SDK. Use ``vrin.VRINClient`` and
``vrin.VRINEnterpriseClient`` instead.

Archived files:
  - client_v2.py         — v2 client (replaced by unified client.py)
  - client_v3.py         — v3 client (never shipped)
  - enterprise_client.py — old enterprise client (replaced by enterprise.py)
  - conversation.py      — conversation mixin (folded into client.py)
  - config.py            — config manager (removed; enterprise routing is server-side)
  - network.py           — network utilities (removed)
  - validation.py        — config validation (removed)
  - deployment.py        — deployment scripts (removed)
  - agents.py            — agent abstractions (removed)
  - cli.py               — CLI tool (removed)
  - providers/           — provider abstractions (removed)
"""
