"""Legacy provider abstractions — archived from v0.8.x."""
