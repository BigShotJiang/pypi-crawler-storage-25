"""
VRIN Hybrid RAG Client — the single unified client for all VRIN operations.

Consolidates query, insert, file upload, conversations, auth,
specialization, and health into one class.
"""

import json
import logging
import mimetypes
import time
from pathlib import Path
from typing import Any, Dict, List, Optional, Union

import requests

from . import _endpoints as ep
from ._streaming import StreamingResponse, parse_complete_sse
from .exceptions import (
    AuthenticationError,
    InsufficientCoverageError,
    JobFailedError,
    RateLimitError,
    ServiceUnavailableError,
    TimeoutError,
    ValidationError,
    VRINError,
)

logger = logging.getLogger(__name__)


class VRINClient:
    """VRIN Hybrid RAG client.

    Handles queries, knowledge management, file uploads, conversations,
    auth, specialization, and health checks against the VRIN backend.

    Example::

        client = VRINClient(api_key="vrin_abc123")

        # Non-streaming query
        result = client.query("What is ACME's revenue?")
        print(result["summary"])

        # Streaming query
        for token in client.query("Summarize Q4 results", stream=True):
            print(token, end="", flush=True)
    """

    def __init__(
        self,
        api_key: str,
        *,
        timeout: float = 120.0,
        max_retries: int = 2,
    ) -> None:
        if not api_key:
            raise ValueError("api_key is required")
        self.api_key = api_key
        self.timeout = timeout
        self.max_retries = max_retries

        self._session = requests.Session()
        self._session.headers.update(
            {
                "Content-Type": "application/json",
                "Authorization": f"Bearer {api_key}",
            }
        )

        # Conversation state
        self._current_session_id: Optional[str] = None
        self._conversation_history: List[str] = []

    # -----------------------------------------------------------------------
    # Internal request helper
    # -----------------------------------------------------------------------

    def _request(
        self,
        method: str,
        url: str,
        *,
        json_body: Optional[Dict[str, Any]] = None,
        params: Optional[Dict[str, Any]] = None,
        timeout: Optional[float] = None,
        stream: bool = False,
        **kwargs: Any,
    ) -> requests.Response:
        """Central request method with retry and error mapping."""
        effective_timeout = timeout or self.timeout
        last_exc: Optional[Exception] = None

        for attempt in range(1 + self.max_retries):
            try:
                resp = self._session.request(
                    method,
                    url,
                    json=json_body,
                    params=params,
                    timeout=effective_timeout,
                    stream=stream,
                    **kwargs,
                )
                if resp.status_code == 401:
                    raise AuthenticationError(
                        f"Authentication failed (HTTP 401): {resp.text[:200]}"
                    )
                if resp.status_code == 429:
                    raise RateLimitError("Rate limit exceeded (HTTP 429)")
                if resp.status_code >= 500:
                    raise ServiceUnavailableError(
                        f"Server error (HTTP {resp.status_code}): {resp.text[:200]}"
                    )
                resp.raise_for_status()
                return resp
            except (AuthenticationError, RateLimitError, ValidationError):
                raise  # Don't retry client errors
            except (ServiceUnavailableError, requests.exceptions.ConnectionError, requests.exceptions.Timeout) as exc:
                last_exc = exc
                if attempt < self.max_retries:
                    wait = 2 ** attempt
                    logger.warning(
                        f"Request to {url} failed (attempt {attempt + 1}), "
                        f"retrying in {wait}s: {exc}"
                    )
                    time.sleep(wait)
                    continue
                raise

        # Should not reach here, but just in case
        raise last_exc or VRINError("Request failed after retries")

    # =====================================================================
    # Query
    # =====================================================================

    def query(
        self,
        query: str,
        *,
        stream: bool = False,
        response_mode: str = "chat",
        query_depth: Optional[str] = None,
        model: Optional[str] = None,
        session_id: Optional[str] = None,
        maintain_context: bool = False,
        include_summary: bool = True,
        web_search_enabled: bool = False,
        conversation_upload_ids: Optional[List[str]] = None,
    ) -> Union[Dict[str, Any], StreamingResponse]:
        """Query the knowledge base.

        Args:
            query: Natural-language question.
            stream: If ``True``, return a ``StreamingResponse`` that yields
                tokens as they arrive.
            response_mode: ``"chat"`` | ``"thinking"`` | ``"research"``.
            query_depth: ``"basic"`` | ``"thinking"`` | ``"research"`` (override).
            model: LLM model name override (e.g. ``"gpt-4o"``).
            session_id: Explicit conversation session to continue.
            maintain_context: If ``True``, maintain conversation state.
            include_summary: If ``True``, include AI-generated summary.
            web_search_enabled: Enable web search augmentation.
            conversation_upload_ids: List of upload IDs to include as context.

        Returns:
            ``dict`` for non-streaming, ``StreamingResponse`` for streaming.
        """
        payload: Dict[str, Any] = {
            "query": query,
            "stream": stream,
            "response_mode": response_mode,
            "include_summary": include_summary,
            "maintain_context": maintain_context,
        }
        if query_depth is not None:
            payload["query_depth"] = query_depth
        if model is not None:
            payload["model"] = model
        if web_search_enabled:
            payload["web_search_enabled"] = True
        if conversation_upload_ids:
            payload["conversation_upload_ids"] = conversation_upload_ids

        # Session resolution
        effective_session = session_id or (
            self._current_session_id if maintain_context else None
        )
        if effective_session:
            payload["session_id"] = effective_session

        if stream:
            resp = self._request(
                "POST", ep.query_url(), json_body=payload, stream=True
            )
            sr = StreamingResponse(resp)
            # If we get a session_id later we'll capture it in to_dict()
            return sr

        resp = self._request("POST", ep.query_url(), json_body=payload)

        content_type = resp.headers.get("Content-Type", "")
        if "text/event-stream" in content_type:
            result = parse_complete_sse(resp.text)
        else:
            result = resp.json()

        # Track session
        if maintain_context and result.get("session_id"):
            self._current_session_id = result["session_id"]

        return result

    def query_facts(
        self, query: str, *, max_results: int = 10
    ) -> Dict[str, Any]:
        """Fast fact retrieval without AI summary generation."""
        return self.query(
            query, include_summary=False, response_mode="chat"
        )

    # =====================================================================
    # Knowledge Management
    # =====================================================================

    def insert(
        self,
        content: str,
        *,
        title: str = "Untitled",
        tags: Optional[List[str]] = None,
        metadata: Optional[Dict[str, Any]] = None,
        wait: bool = True,
        poll_interval: float = 2.0,
        max_wait: float = 300.0,
    ) -> Union[Dict[str, Any], str]:
        """Insert content into the knowledge base.

        Args:
            content: Text content to insert.
            title: Document title.
            tags: Optional list of tags.
            metadata: Optional metadata dict.
            wait: If ``True`` (default), poll until processing completes
                and return the result dict. If ``False``, return the
                ``job_id`` string immediately.
            poll_interval: Seconds between status polls (when ``wait=True``).
            max_wait: Maximum seconds to wait (when ``wait=True``).

        Returns:
            Result dict (wait=True) or job_id string (wait=False).
        """
        payload: Dict[str, Any] = {
            "content": content,
            "title": title,
            "tags": tags or [],
            "metadata": metadata or {},
        }

        resp = self._request(
            "POST", ep.insert_url(), json_body=payload, timeout=30.0
        )
        result = resp.json()

        job_id = result.get("job_id")
        if not job_id:
            # Synchronous response from older backend
            return result

        if not wait:
            return job_id

        return self.wait_for_job(job_id, poll_interval=poll_interval, max_wait=max_wait)

    def get_job_status(self, job_id: str) -> Dict[str, Any]:
        """Check the status of an async insertion job."""
        resp = self._request("GET", ep.job_status_url(job_id), timeout=10.0)
        return resp.json()

    def wait_for_job(
        self,
        job_id: str,
        poll_interval: float = 2.0,
        max_wait: float = 300.0,
    ) -> Dict[str, Any]:
        """Poll job status until completion or timeout."""
        start = time.time()
        last_status = None

        while (time.time() - start) < max_wait:
            status = self.get_job_status(job_id)
            current = status.get("status")

            if current != last_status:
                progress = status.get("progress", 0)
                if isinstance(progress, (int, float)):
                    progress = progress * 100 if progress <= 1 else progress
                logger.info(
                    f"Job {job_id}: {current} ({progress:.0f}%) — "
                    f"{status.get('message', '')}"
                )
                last_status = current

            if current == "completed":
                return status.get("data", status)

            if current == "failed":
                raise JobFailedError(
                    f"Job {job_id} failed: {status.get('error_details', 'Unknown error')}"
                )

            time.sleep(poll_interval)

        raise TimeoutError(
            f"Job {job_id} did not complete within {max_wait}s "
            f"(last status: {last_status}). "
            f"Use get_job_status() to check current state."
        )

    def get_knowledge_graph(self, *, limit: int = 100) -> Dict[str, Any]:
        """Get knowledge graph visualization data."""
        resp = self._request(
            "GET", ep.graph_url(), params={"limit": limit}, timeout=30.0
        )
        return resp.json()

    # =====================================================================
    # File Upload
    # =====================================================================

    def upload_file(
        self,
        file_path: Union[str, Path],
        *,
        save_to_memory: bool = True,
        wait: bool = True,
        poll_interval: float = 3.0,
        max_wait: float = 120.0,
    ) -> Dict[str, Any]:
        """Upload a file to the knowledge base.

        Args:
            file_path: Path to the file to upload.
            save_to_memory: If ``True``, persist extracted knowledge.
            wait: If ``True``, poll until processing completes.
            poll_interval: Seconds between status polls.
            max_wait: Maximum seconds to wait.

        Returns:
            Upload result dict.
        """
        path = Path(file_path)
        if not path.exists():
            raise FileNotFoundError(f"File not found: {path}")

        content_type = mimetypes.guess_type(str(path))[0] or "application/octet-stream"

        with open(path, "rb") as f:
            return self.upload_bytes(
                f.read(),
                filename=path.name,
                content_type=content_type,
                save_to_memory=save_to_memory,
                wait=wait,
                poll_interval=poll_interval,
                max_wait=max_wait,
            )

    def upload_bytes(
        self,
        file_bytes: bytes,
        filename: str,
        *,
        content_type: Optional[str] = None,
        save_to_memory: bool = True,
        wait: bool = True,
        poll_interval: float = 3.0,
        max_wait: float = 120.0,
    ) -> Dict[str, Any]:
        """Upload raw bytes to the knowledge base.

        Args:
            file_bytes: File content as bytes.
            filename: Name of the file.
            content_type: MIME type (auto-detected if not provided).
            save_to_memory: If ``True``, persist extracted knowledge.
            wait: If ``True``, poll until processing completes.
            poll_interval: Seconds between status polls.
            max_wait: Maximum seconds to wait.

        Returns:
            Upload result dict.
        """
        if content_type is None:
            content_type = mimetypes.guess_type(filename)[0] or "application/octet-stream"

        # Multipart upload — requests will auto-set the
        # `multipart/form-data; boundary=…` header when ``files=`` is used,
        # but ONLY if there's no Content-Type already in the merged request
        # headers. The session defaults to ``application/json`` for every
        # other endpoint, and passing ``headers=...`` merges on top of
        # session headers rather than replacing them, so the JSON default
        # silently bleeds through and the backend rejects the body as
        # ``not multipart/form-data``. Passing the header as ``None`` is
        # the requests-lib idiom for "strip this header from this request".
        files = {"file": (filename, file_bytes, content_type)}
        data = {"save_to_memory": str(save_to_memory).lower()}

        resp = self._session.post(
            ep.upload_url(),
            files=files,
            data=data,
            headers={"Content-Type": None},
            timeout=self.timeout,
        )

        if resp.status_code == 401:
            raise AuthenticationError("Authentication failed during upload")
        resp.raise_for_status()

        result = resp.json()
        upload_id = result.get("upload_id", result.get("id"))

        if not wait or not upload_id:
            return result

        # Poll for completion
        start = time.time()
        while (time.time() - start) < max_wait:
            status = self.get_upload_status(upload_id)
            if status.get("status") in ("completed", "done"):
                return status
            if status.get("status") == "failed":
                return status
            time.sleep(poll_interval)

        result["warning"] = f"Upload {upload_id} still processing after {max_wait}s"
        return result

    def get_upload_status(self, upload_id: str) -> Dict[str, Any]:
        """Check the processing status of an upload."""
        resp = self._request(
            "GET", ep.upload_status_url(upload_id), timeout=10.0
        )
        return resp.json()

    # =====================================================================
    # Conversations
    # =====================================================================

    def start_conversation(self) -> "VRINClient":
        """Start a new conversation session. Returns ``self`` for chaining."""
        self._current_session_id = None
        return self

    def end_conversation(self) -> "VRINClient":
        """End the current conversation. Returns ``self`` for chaining."""
        if self._current_session_id:
            self._conversation_history.append(self._current_session_id)
            self._current_session_id = None
        return self

    def continue_conversation(
        self, query: str, **kwargs: Any
    ) -> Dict[str, Any]:
        """Query with automatic conversation context (sugar for ``query()``
        with ``maintain_context=True``)."""
        kwargs["maintain_context"] = True
        if self._current_session_id:
            kwargs["session_id"] = self._current_session_id
        result = self.query(query, **kwargs)
        return result

    def resume_conversation(self, conversation_id: str) -> "VRINClient":
        """Resume a previous conversation. Returns ``self`` for chaining."""
        self._current_session_id = conversation_id
        return self

    def list_conversations(self, *, limit: int = 50) -> List[Dict[str, Any]]:
        """List the user's conversations."""
        resp = self._request(
            "GET",
            ep.conversations_url(),
            params={"limit": limit},
            timeout=10.0,
        )
        result = resp.json()
        return result.get("conversations", result) if isinstance(result, dict) else result

    def get_conversation(self, conversation_id: str) -> Dict[str, Any]:
        """Get full history for a conversation."""
        resp = self._request(
            "GET", ep.conversation_url(conversation_id), timeout=10.0
        )
        return resp.json()

    def delete_conversation(self, conversation_id: str) -> bool:
        """Soft-delete a conversation. Returns ``True`` on success."""
        try:
            self._request(
                "DELETE", ep.conversation_url(conversation_id), timeout=10.0
            )
            if self._current_session_id == conversation_id:
                self._current_session_id = None
            return True
        except VRINError:
            return False

    def rename_conversation(self, conversation_id: str, title: str) -> bool:
        """Rename a conversation. Returns ``True`` on success."""
        try:
            self._request(
                "PUT",
                ep.conversation_title_url(conversation_id),
                json_body={"title": title},
                timeout=10.0,
            )
            return True
        except VRINError:
            return False

    # =====================================================================
    # Specialization
    # =====================================================================

    def specialize(self, custom_prompt: str, **kwargs: Any) -> Dict[str, Any]:
        """Set AI specialization/persona for queries."""
        payload: Dict[str, Any] = {"custom_prompt": custom_prompt}
        payload.update(kwargs)
        resp = self._request(
            "POST", ep.specialize_url(), json_body=payload, timeout=30.0
        )
        return resp.json()

    def get_specialization(self) -> Dict[str, Any]:
        """Get current specialization settings."""
        resp = self._request("GET", ep.specialize_url(), timeout=10.0)
        return resp.json()

    # =====================================================================
    # Auth (static helpers + instance methods for API keys)
    # =====================================================================

    @staticmethod
    def login(email: str, password: str) -> Dict[str, Any]:
        """Authenticate and receive API key."""
        resp = requests.post(
            ep.login_url(),
            json={"email": email, "password": password},
            headers={"Content-Type": "application/json"},
            timeout=15.0,
        )
        resp.raise_for_status()
        return resp.json()

    @staticmethod
    def register(email: str, password: str, name: Optional[str] = None) -> Dict[str, Any]:
        """Register a new account."""
        payload: Dict[str, Any] = {"email": email, "password": password}
        if name:
            payload["name"] = name
        resp = requests.post(
            ep.signup_url(),
            json=payload,
            headers={"Content-Type": "application/json"},
            timeout=15.0,
        )
        resp.raise_for_status()
        return resp.json()

    @staticmethod
    def device_code_init() -> Dict[str, Any]:
        """Start a device auth flow. Returns device_code + user_code + verification_uri."""
        resp = requests.post(
            ep.device_code_init_url(),
            json={},
            headers={"Content-Type": "application/json"},
            timeout=15.0,
        )
        resp.raise_for_status()
        return resp.json()

    @staticmethod
    def device_code_poll(device_code: str) -> Dict[str, Any]:
        """Poll for device code completion. Returns {api_key,...} on approval
        or {error: 'authorization_pending'|'slow_down'|'access_denied'|'expired_token'}.
        """
        resp = requests.post(
            ep.device_code_poll_url(),
            json={"device_code": device_code},
            headers={"Content-Type": "application/json"},
            timeout=15.0,
        )
        # Don't raise_for_status — 400 with {error: "authorization_pending"}
        # is the expected response while waiting.
        try:
            return resp.json()
        except Exception:
            return {"error": "server_error", "status_code": resp.status_code}

    def list_api_keys(self) -> Dict[str, Any]:
        """List API keys for the current user."""
        resp = self._request("GET", ep.api_keys_url(), timeout=10.0)
        return resp.json()

    def create_api_key(self, *, name: Optional[str] = None) -> Dict[str, Any]:
        """Create a new API key."""
        payload: Dict[str, Any] = {}
        if name:
            payload["name"] = name
        resp = self._request(
            "POST", ep.create_api_key_url(), json_body=payload, timeout=10.0
        )
        return resp.json()

    def delete_api_key(self, key_id: str) -> Dict[str, Any]:
        """Delete an API key."""
        resp = self._request(
            "POST",
            ep.delete_api_key_url(),
            json_body={"key_id": key_id},
            timeout=10.0,
        )
        return resp.json()

    def get_limits(self) -> Dict[str, Any]:
        """Get current user's plan and usage limits."""
        resp = self._request("GET", ep.user_limits_url(), timeout=10.0)
        return resp.json()

    # =====================================================================
    # Health
    # =====================================================================

    def health_check(self) -> Dict[str, Any]:
        """Check VRIN service health."""
        resp = self._request("GET", ep.health_url(), timeout=10.0)
        return resp.json()

    # =====================================================================
    # Properties
    # =====================================================================

    @property
    def current_session_id(self) -> Optional[str]:
        """Current active conversation session ID, or ``None``."""
        return self._current_session_id

    @property
    def conversation_history_ids(self) -> List[str]:
        """List of ended conversation session IDs."""
        return self._conversation_history.copy()

    # =====================================================================
    # Bulk ingestion with adaptive concurrency
    # =====================================================================

    def bulk_insert(
        self,
        items: List[Dict[str, Any]],
        *,
        initial_concurrency: int = 8,
        min_concurrency: int = 1,
        max_concurrency: int = 25,
        smoothing: float = 0.2,
        tolerance: float = 2.0,
        tags: Optional[List[str]] = None,
        on_progress: Optional[Any] = None,
        max_wait_per_item: float = 180.0,
    ) -> Dict[str, Any]:
        """Bulk-insert multiple items with Netflix Gradient2 adaptive concurrency.

        The limiter monitors per-item RTT and adjusts concurrency proactively —
        reducing workers when backend latency rises (congestion forming) and
        increasing when latency is stable. This prevents 429 errors and
        Neptune write contention without manual tuning.

        Args:
            items: List of dicts, each with ``"content"`` (required) and
                optionally ``"title"``, ``"tags"``, ``"metadata"``, ``"id"``.
            initial_concurrency: Starting number of concurrent workers.
            min_concurrency: Floor for adaptive limiter.
            max_concurrency: Ceiling for adaptive limiter.
            smoothing: Gradient2 limit update smoothing (0-1). Higher = more
                responsive to latency changes.
            tolerance: RTT tolerance before reducing concurrency. Higher = more
                lenient before throttling.
            tags: Default tags applied to all items (item-level tags override).
            on_progress: Optional callback ``fn(completed, total, result_dict)``
                called after each item completes.
            max_wait_per_item: Max seconds to wait for each item's job.

        Returns:
            Summary dict with ``completed``, ``failed``, ``total``,
            ``facts_extracted``, ``facts_stored``, ``results`` (list),
            and ``limiter_stats``.

        Example::

            results = client.bulk_insert([
                {"content": "Apple reported $416B revenue.", "title": "AAPL 10-K"},
                {"content": "Microsoft Cloud grew 26%.", "title": "MSFT Earnings"},
            ], initial_concurrency=8, max_concurrency=25)
            print(f"Stored {results['facts_stored']} facts")
        """
        from concurrent.futures import ThreadPoolExecutor, as_completed

        from ._adaptive_concurrency import Gradient2Limiter

        if not items:
            return {
                "completed": 0, "failed": 0, "total": 0,
                "facts_extracted": 0, "facts_stored": 0,
                "results": [], "limiter_stats": {},
            }

        limiter = Gradient2Limiter(
            initial_limit=min(initial_concurrency, len(items)),
            min_limit=min_concurrency,
            max_limit=min(max_concurrency, max(len(items), initial_concurrency)),
            smoothing=smoothing,
            tolerance=tolerance,
        )

        default_tags = tags or []

        logger.info(
            f"bulk_insert: {len(items)} items, Gradient2 limiter "
            f"(initial={initial_concurrency}, min={min_concurrency}, "
            f"max={max_concurrency}, smoothing={smoothing}, tolerance={tolerance})"
        )

        max_retries = 3

        def _insert_one_adaptive(item: Dict[str, Any]) -> Dict[str, Any]:
            item_id = item.get("id", "")
            item_title = item.get("title", "Untitled")
            item_tags = item.get("tags", default_tags)
            item_metadata = item.get("metadata", {})

            last_error = ""
            for attempt in range(1, max_retries + 1):
                with limiter.acquire(timeout=300) as token:
                    start = time.monotonic()
                    try:
                        result = self.insert(
                            item["content"],
                            title=item_title,
                            tags=item_tags,
                            metadata=item_metadata,
                            wait=True,
                            max_wait=max_wait_per_item,
                        )
                        elapsed = time.monotonic() - start
                        is_dict = isinstance(result, dict)
                        token.report(rtt=elapsed, dropped=False)

                        return {
                            "id": item_id,
                            "title": item_title,
                            "status": "completed",
                            "facts_extracted": result.get("facts_extracted", 0) if is_dict else 0,
                            "facts_stored": result.get("facts_stored", 0) if is_dict else 0,
                            "job_id": result.get("job_id", "") if is_dict else "",
                            "elapsed_s": round(elapsed, 1),
                            "attempts": attempt,
                        }
                    except Exception as e:
                        elapsed = time.monotonic() - start
                        is_429 = "429" in str(e) or "Too Many" in str(e)
                        token.report(rtt=elapsed, dropped=True)
                        last_error = str(e)[:200]

                        if attempt < max_retries:
                            backoff = 2 ** attempt
                            logger.warning(
                                f"bulk_insert: item '{item_title[:40]}' failed "
                                f"(attempt {attempt}/{max_retries}, "
                                f"{'429' if is_429 else 'error'}): {str(e)[:80]} "
                                f"— retrying in {backoff}s"
                            )
                            time.sleep(backoff)
                        else:
                            logger.error(
                                f"bulk_insert: item '{item_title[:40]}' failed "
                                f"after {max_retries} attempts: {str(e)[:100]}"
                            )

            return {
                "id": item_id,
                "title": item_title,
                "status": "failed",
                "error": last_error,
                "elapsed_s": 0,
                "attempts": max_retries,
            }

        results_list: List[Dict[str, Any]] = []
        completed_count = 0
        failed_count = 0

        with ThreadPoolExecutor(max_workers=max_concurrency) as pool:
            futures = {
                pool.submit(_insert_one_adaptive, item): idx
                for idx, item in enumerate(items)
            }

            for future in as_completed(futures):
                result = future.result()
                results_list.append(result)

                if result["status"] == "completed":
                    completed_count += 1
                else:
                    failed_count += 1

                if on_progress:
                    try:
                        on_progress(completed_count + failed_count, len(items), result)
                    except Exception:
                        pass

                # Log periodic stats
                total_done = completed_count + failed_count
                if total_done % 10 == 0 or total_done == len(items):
                    stats = limiter.stats
                    logger.info(
                        f"bulk_insert: {total_done}/{len(items)} "
                        f"(ok={completed_count}, fail={failed_count}) | "
                        f"Gradient2: limit={stats['current_limit']}, "
                        f"rtt={stats['long_rtt']:.1f}s, "
                        f"drops={stats['drops_total']}"
                    )

        # ---------------------------------------------------------------
        # Recovery pass: retry all failed items sequentially (concurrency=1)
        # to guarantee zero information loss. The main batch is done so the
        # backend is no longer under pressure.
        # ---------------------------------------------------------------
        failed_items = [
            (r, item) for r, item in zip(results_list, items)
            if r["status"] == "failed"
        ]

        if failed_items:
            logger.info(
                f"bulk_insert: {len(failed_items)} items failed during main batch. "
                f"Starting recovery pass (sequential, unlimited retries)..."
            )
            recovery_count = 0
            for failed_result, item in failed_items:
                item_title = item.get("title", "Untitled")
                for recovery_attempt in range(1, 6):  # up to 5 more attempts
                    backoff = min(2 ** recovery_attempt, 30)
                    time.sleep(backoff)
                    try:
                        result = self.insert(
                            item["content"],
                            title=item_title,
                            tags=item.get("tags", default_tags),
                            metadata=item.get("metadata", {}),
                            wait=True,
                            max_wait=max_wait_per_item,
                        )
                        is_dict = isinstance(result, dict)
                        # Update the failed result in-place
                        failed_result["status"] = "completed"
                        failed_result["facts_extracted"] = result.get("facts_extracted", 0) if is_dict else 0
                        failed_result["facts_stored"] = result.get("facts_stored", 0) if is_dict else 0
                        failed_result["job_id"] = result.get("job_id", "") if is_dict else ""
                        failed_result["recovered"] = True
                        failed_result["recovery_attempts"] = recovery_attempt
                        completed_count += 1
                        failed_count -= 1
                        recovery_count += 1
                        logger.info(
                            f"bulk_insert recovery: '{item_title[:40]}' succeeded "
                            f"on attempt {recovery_attempt}"
                        )
                        break
                    except Exception as e:
                        logger.warning(
                            f"bulk_insert recovery: '{item_title[:40]}' failed "
                            f"(attempt {recovery_attempt}/5): {str(e)[:80]}"
                        )
                        if recovery_attempt == 5:
                            logger.error(
                                f"bulk_insert: PERMANENT FAILURE for '{item_title[:40]}' "
                                f"after {max_retries + 5} total attempts"
                            )

            logger.info(
                f"bulk_insert recovery complete: {recovery_count}/{len(failed_items)} recovered"
            )

        final_stats = limiter.stats
        total_extracted = sum(r.get("facts_extracted", 0) for r in results_list)
        total_stored = sum(r.get("facts_stored", 0) for r in results_list)

        logger.info(
            f"bulk_insert complete: {completed_count} ok, {failed_count} failed, "
            f"{total_extracted} facts extracted, {total_stored} stored | "
            f"Gradient2 final: limit={final_stats['current_limit']}, "
            f"rtt={final_stats['long_rtt']:.1f}s, "
            f"samples={final_stats['sample_count']}, drops={final_stats['drops_total']}"
        )

        return {
            "completed": completed_count,
            "failed": failed_count,
            "total": len(items),
            "facts_extracted": total_extracted,
            "facts_stored": total_stored,
            "results": results_list,
            "limiter_stats": final_stats,
        }

    # =====================================================================
    # Backward compatibility aliases
    # =====================================================================

    def insert_text(self, text: str, title: Optional[str] = None, tags: Optional[List[str]] = None) -> Dict[str, Any]:
        """Alias for ``insert()``."""
        return self.insert(text, title=title or "Untitled", tags=tags)

    def insert_and_wait(self, content: str, title: str = "Untitled", tags: Optional[List[str]] = None, timeout: int = 300) -> Dict[str, Any]:
        """Alias for ``insert(wait=True)``."""
        return self.insert(content, title=title, tags=tags, max_wait=timeout)

    def query_text(self, query: str) -> Dict[str, Any]:
        """Alias for ``query()``."""
        return self.query(query)

    def get_context(self, query: str) -> Dict[str, Any]:
        """Return the raw retrieved context (facts + chunks) without any LLM-generated summary.

        Non-streaming on purpose: the streaming response only emits counts
        (``total_facts`` / ``total_chunks``), not the accumulated arrays —
        passing ``stream=True`` here used to silently produce empty results.
        """
        result = self.query(query, include_summary=False, stream=False)
        return {
            "success": True,
            "facts": result.get("graph_facts", result.get("facts", [])),
            "chunks": result.get("vector_results", result.get("chunks", [])),
            "total_facts": result.get("total_facts", 0),
            "total_chunks": result.get("total_chunks", 0),
            "metadata": result.get("metadata", {}),
        }

    def get_facts(self, query: str, *, max_results: int = 10) -> Dict[str, Any]:
        """Return only the retrieved facts for a query, no chunks or summary."""
        ctx = self.get_context(query)
        facts = ctx.get("facts", [])[:max_results]
        return {
            "success": True,
            "facts": facts,
            "total_facts": ctx.get("total_facts", 0),
        }

    # Deprecated aliases — kept for backward compatibility
    def get_raw_results(self, query: str) -> Dict[str, Any]:
        """Deprecated. Use ``get_context()``."""
        return self.get_context(query)

    def get_raw_facts_only(self, query: str) -> Dict[str, Any]:
        """Deprecated. Use ``get_facts()``."""
        return self.get_facts(query)

    def get_current_session_id(self) -> Optional[str]:
        """Deprecated — use the ``current_session_id`` property."""
        return self._current_session_id

    def get_conversation_history_ids(self) -> List[str]:
        """Deprecated — use the ``conversation_history_ids`` property."""
        return self._conversation_history.copy()

    # =====================================================================
    # Context manager
    # =====================================================================

    def __enter__(self) -> "VRINClient":
        return self

    def __exit__(self, *exc: Any) -> None:
        self._session.close()

    def __repr__(self) -> str:
        key_preview = self.api_key[:12] + "..." if len(self.api_key) > 12 else self.api_key
        return f"VRINClient(api_key='{key_preview}')"
