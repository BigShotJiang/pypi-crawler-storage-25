"""
VRIN Hybrid RAG SDK v1.0.0

Enterprise-grade Hybrid RAG with graph + vector search, streaming,
file upload, conversations, and enterprise data sovereignty.

Quick start::

    from vrin import VRINClient

    client = VRINClient(api_key="vrin_abc123")
    result = client.query("What is ACME's revenue?")
    print(result["summary"])
"""

__version__ = "1.3.3"
__author__ = "VRIN Team"
__email__ = "support@vrin.cloud"

# Core client
from .client import VRINClient

# Enterprise client
from .enterprise import VRINEnterpriseClient

# Streaming
from ._streaming import StreamingResponse

# Models
from .models import (
    Conversation,
    Document,
    InsertResult,
    JobStatus,
    QueryResult,
    UploadResult,
    UserLimits,
)

# Exceptions
from .exceptions import (
    AuthenticationError,
    InsufficientCoverageError,
    JobFailedError,
    RateLimitError,
    ServiceUnavailableError,
    StreamingError,
    TimeoutError,
    ValidationError,
    VRINError,
)


# ---------------------------------------------------------------------------
# Factory helpers & backward-compat aliases
# ---------------------------------------------------------------------------


def get_enterprise_client(api_key: str, **kwargs) -> "VRINClient":
    """Return ``VRINEnterpriseClient`` for ``vrin_ent_*`` keys, else ``VRINClient``."""
    if api_key.startswith("vrin_ent_"):
        return VRINEnterpriseClient(api_key, **kwargs)
    return VRINClient(api_key, **kwargs)


def create_enterprise_client(api_key: str, **kwargs) -> VRINEnterpriseClient:
    """Create an enterprise client (alias)."""
    return VRINEnterpriseClient(api_key, **kwargs)


def create_centralized_client(api_key: str, **kwargs) -> VRINClient:
    """Create a standard client (alias)."""
    return VRINClient(api_key, **kwargs)


__all__ = [
    # Core
    "VRINClient",
    "VRINEnterpriseClient",
    "StreamingResponse",
    # Factories
    "get_enterprise_client",
    "create_enterprise_client",
    "create_centralized_client",
    # Models
    "Document",
    "QueryResult",
    "JobStatus",
    "InsertResult",
    "UploadResult",
    "UserLimits",
    "Conversation",
    # Exceptions
    "VRINError",
    "AuthenticationError",
    "RateLimitError",
    "ValidationError",
    "ServiceUnavailableError",
    "JobFailedError",
    "TimeoutError",
    "InsufficientCoverageError",
    "StreamingError",
]
