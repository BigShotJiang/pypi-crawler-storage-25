"""
Data models for the VRIN SDK.

All models are plain dataclasses with ``from_dict()`` classmethods for
optional typed usage. None of them are required — the client methods
return regular dicts by default.
"""

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Dict, List, Optional


# ---------------------------------------------------------------------------
# Existing models (backward-compatible)
# ---------------------------------------------------------------------------


@dataclass
class Document:
    """Represents a document to be processed and indexed."""

    content: str
    title: Optional[str] = None
    tags: Optional[List[str]] = None
    source: Optional[str] = None
    user_id: Optional[str] = None
    document_type: str = "text"

    def __post_init__(self) -> None:
        if self.tags is None:
            self.tags = []
        if self.title is None:
            self.title = "Untitled Document"
        if self.source is None:
            self.source = "vrin-sdk"
        if self.user_id is None:
            self.user_id = "default"


@dataclass
class QueryResult:
    """Represents a search result from the knowledge base."""

    content: str
    score: float
    search_type: str
    metadata: Dict[str, Any]
    chunk_id: str
    graph_context: Optional[Dict[str, Any]] = None

    def __post_init__(self) -> None:
        if self.graph_context is None:
            self.graph_context = {"related_chunks": [], "graph_score": 0.0}

    @property
    def title(self) -> Optional[str]:
        return self.metadata.get("title")

    @property
    def tags(self) -> List[str]:
        return self.metadata.get("tags", [])

    @property
    def source(self) -> Optional[str]:
        return self.metadata.get("source")

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "QueryResult":
        return cls(
            content=d.get("content", ""),
            score=d.get("score", 0.0),
            search_type=d.get("search_type", ""),
            metadata=d.get("metadata", {}),
            chunk_id=d.get("chunk_id", ""),
            graph_context=d.get("graph_context"),
        )


@dataclass
class JobStatus:
    """Represents the status of a processing job."""

    job_id: str
    status: str  # pending / chunking / extracting / storing / completed / failed
    message: str
    timestamp: Optional[int] = None
    data: Optional[Dict[str, Any]] = None
    progress: int = 0
    completed_at: Optional[int] = None
    error_details: Optional[str] = None
    estimated_completion: Optional[str] = None

    @property
    def is_completed(self) -> bool:
        return self.status == "completed"

    @property
    def is_failed(self) -> bool:
        return self.status == "failed"

    @property
    def is_processing(self) -> bool:
        return self.status in ("queued", "pending", "chunking", "extracting", "storing", "processing")

    @property
    def completion_time(self) -> Optional[datetime]:
        if self.completed_at:
            return datetime.fromtimestamp(self.completed_at)
        return None

    @property
    def creation_time(self) -> Optional[datetime]:
        if self.timestamp:
            return datetime.fromtimestamp(self.timestamp)
        return None

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "JobStatus":
        return cls(
            job_id=d.get("job_id", ""),
            status=d.get("status", "unknown"),
            message=d.get("message", ""),
            timestamp=d.get("timestamp"),
            data=d.get("data"),
            progress=d.get("progress", 0),
            completed_at=d.get("completed_at"),
            error_details=d.get("error_details"),
            estimated_completion=d.get("estimated_completion"),
        )


# ---------------------------------------------------------------------------
# New models (v1.0.0)
# ---------------------------------------------------------------------------


@dataclass
class InsertResult:
    """Structured response from an insert operation."""

    success: bool
    job_id: Optional[str] = None
    facts_extracted: int = 0
    message: str = ""
    chunk_id: Optional[str] = None

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "InsertResult":
        return cls(
            success=d.get("success", False),
            job_id=d.get("job_id"),
            facts_extracted=d.get("facts_extracted", d.get("facts_count", 0)),
            message=d.get("message", ""),
            chunk_id=d.get("chunk_id"),
        )


@dataclass
class UploadResult:
    """Structured response from a file upload."""

    success: bool
    upload_id: Optional[str] = None
    filename: Optional[str] = None
    status: str = ""
    message: str = ""

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "UploadResult":
        return cls(
            success=d.get("success", False),
            upload_id=d.get("upload_id", d.get("id")),
            filename=d.get("filename"),
            status=d.get("status", ""),
            message=d.get("message", ""),
        )


@dataclass
class UserLimits:
    """User plan information and usage limits."""

    plan: str = "free"
    queries_remaining: int = 0
    inserts_remaining: int = 0
    allowed_models: List[str] = field(default_factory=list)
    max_file_size_mb: int = 10

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "UserLimits":
        return cls(
            plan=d.get("plan", "free"),
            queries_remaining=d.get("queries_remaining", 0),
            inserts_remaining=d.get("inserts_remaining", 0),
            allowed_models=d.get("allowed_models", []),
            max_file_size_mb=d.get("max_file_size_mb", 10),
        )


@dataclass
class Conversation:
    """Summary of a conversation session."""

    session_id: str
    title: str = ""
    created_at: Optional[str] = None
    last_updated: Optional[str] = None
    turn_count: int = 0
    preview: str = ""

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "Conversation":
        return cls(
            session_id=d.get("session_id", d.get("id", "")),
            title=d.get("title", ""),
            created_at=d.get("created_at"),
            last_updated=d.get("last_updated"),
            turn_count=d.get("turn_count", 0),
            preview=d.get("preview", ""),
        )
