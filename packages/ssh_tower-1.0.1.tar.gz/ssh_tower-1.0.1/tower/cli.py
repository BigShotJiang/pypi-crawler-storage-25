import sys
import getpass

from tower.security import SecurityManager
from tower.scanner import NetworkScanner
from tower.ssh_manager import SSHSession
from tower.pairing import PairingSystem

# ANSI Colors
CYAN = '\033[96m'
MAGENTA = '\033[95m'
YELLOW = '\033[93m'
GREEN = '\033[92m'
RED = '\033[91m'
BLUE = '\033[94m'
BOLD = '\033[1m'
RESET = '\033[0m'

sec_mgr = SecurityManager()
session = SSHSession(sec_mgr)
pairing = PairingSystem(sec_mgr)

def print_banner():
    print(f"\n{CYAN}{'='*50}{RESET}")
    print(f"{BOLD}{CYAN}   SSH tower{RESET} - Advanced Remote Management Tool")
    print(f"{CYAN}{'='*50}{RESET}\n")

def scan_network_menu():
    print(f"{YELLOW}Initiating high-speed network sweep (Port 22)...{RESET}")
    hosts = NetworkScanner.scan_network()
    
    if not hosts:
        print(f"{RED}No SSH devices found on the local network.{RESET}\n")
        return

    print(f"\n{BOLD}{CYAN}{'IP Address'.ljust(18)} {MAGENTA}Hostname{RESET}")
    print("-" * 50)
    for h in hosts:
        print(f"{CYAN}{h['ip'].ljust(18)}{RESET} {MAGENTA}{h['hostname']}{RESET}")
    print()

def connect_ssh_menu():
    profiles = list(sec_mgr.db["profiles"].keys())
    if not profiles:
        print(f"{RED}No profiles found. Add one first.{RESET}\n")
        return
    
    for idx, p in enumerate(profiles):
        print(f"[{idx}] {p} ({sec_mgr.db['profiles'][p]['ip']})")
    
    try:
        choice = int(input(f"\nSelect profile index: "))
        if 0 <= choice < len(profiles):
            name = profiles[choice]
            prof = sec_mgr.db["profiles"][name]
            print(f"{YELLOW}Connecting to {name}...{RESET}")
            success, msg = session.connect(name, prof)
            
            if success:
                print(f"{BOLD}{GREEN}Connection Established!{RESET}\n")
                session_menu()
            else:
                print(f"{BOLD}{RED}Failed: {msg}{RESET}\n")
        else:
            print(f"{RED}Invalid index.{RESET}\n")
    except ValueError:
        print(f"{RED}Please enter a valid number.{RESET}\n")

def session_menu():
    while session.connected:
        print(f"\n{BOLD}{BLUE}--- Active Session Menu ---{RESET}")
        print("1. Execute Command")
        print("2. Freeze Device (Simulate)")
        print("3. Disconnect")
        
        choice = input(f"\nSelect action (1/2/3): ").strip()
        
        if choice == "1":
            cmd = input("Enter command: ")
            out = session.execute(cmd)
            print(f"\n{GREEN}--- Output ---{RESET}\n{out}\n{GREEN}--------------{RESET}")
        elif choice == "2":
            session.freeze_device()
            print(f"{BOLD}{RED}Device Frozen (CPU spiked via dummy process).{RESET}")
        elif choice == "3":
            session.disconnect()
            print(f"{YELLOW}Disconnected.{RESET}\n")

def add_profile_menu():
    print(f"{BOLD}--- Add New SSH Profile ---{RESET}")
    name = input("Profile Name: ")
    ip = input("IP Address: ")
    user = input("Username: ")
    
    auth_type = ""
    while auth_type not in ["1", "2"]:
        auth_type = input("Auth Type [1=Password, 2=Key]: ").strip()
    
    if auth_type == "1":
        pwd = getpass.getpass("Password (hidden): ")
        sec_mgr.add_profile(name, ip, 22, user, password=pwd)
    else:
        k_path = input("Private Key Path: ")
        sec_mgr.add_profile(name, ip, 22, user, key_path=k_path)
    
    print(f"{BOLD}{GREEN}Profile Saved!{RESET}\n")

def pairing_menu():
    print(f"\n{BOLD}--- AirDrop Pairing System ---{RESET}")
    print("1. Host a Pairing Session (Broadcast presence)")
    print("2. Scan & Connect to a Host")
    choice = input("\nSelect (1/2): ").strip()
    
    if choice == "1":
        pairing.start_host()
        input(f"\n{MAGENTA}Press Enter at any time to stop hosting...{RESET}\n")
        pairing.stop_host()
        print(f"{YELLOW}Hosting stopped.{RESET}\n")
        
    elif choice == "2":
        print(f"{YELLOW}Scanning airwaves for tower Hosts (3 seconds)...{RESET}")
        discovered = pairing.discover_hosts()
        
        if not discovered:
            print(f"{RED}No broadcasting hosts found on the network.{RESET}\n")
            return
            
        print(f"\n{BOLD}{GREEN}Discovered Hosts:{RESET}")
        host_list = list(discovered.items())
        for idx, (ip, name) in enumerate(host_list):
            print(f"[{idx}] {name} ({ip})")
            
        try:
            h_choice = int(input("\nSelect host index to pair with: "))
            if 0 <= h_choice < len(host_list):
                target_ip = host_list[h_choice][0]
                pin = input(f"Enter the 6-digit PIN shown on {host_list[h_choice][1]}: ")
                
                print(f"{YELLOW}Verifying PIN and establishing secure link...{RESET}")
                success, data = pairing.connect_to_host(target_ip, pin)
                
                if success:
                    print(f"{BOLD}{GREEN}Paired Successfully! Received Credentials.{RESET}")
                    sec_mgr.add_profile(f"Auto_{target_ip}", target_ip, 22, data["user"], password=data["password"])
                else:
                    print(f"{BOLD}{RED}Pairing Failed: {data}{RESET}\n")
            else:
                print(f"{RED}Invalid selection.{RESET}\n")
        except ValueError:
            print(f"{RED}Please enter a valid number.{RESET}\n")

def main():
    while True:
        print_banner()
        print("1. Connect to Profile")
        print("2. Add Profile")
        print(f"3. Scan Network {GREEN}(High-Speed){RESET}")
        print(f"4. AirDrop Pairing {MAGENTA}(Auto-Discovery){RESET}")
        print("5. Recent Connections History")
        print("6. Exit")
        
        choice = input(f"\n{BOLD}Choose an option:{RESET} ").strip()
        print()
        
        if choice == "1": connect_ssh_menu()
        elif choice == "2": add_profile_menu()
        elif choice == "3": scan_network_menu()
        elif choice == "4": pairing_menu()
        elif choice == "5":
            print(f"{BOLD}--- Recent Connections ---{RESET}")
            print(f"{CYAN}{'Name'.ljust(15)} {MAGENTA}{'IP'.ljust(15)} {GREEN}Duration{RESET}")
            print("-" * 45)
            for h in sec_mgr.db["history"]:
                print(f"{CYAN}{h['name'].ljust(15)}{RESET} {MAGENTA}{h['ip'].ljust(15)}{RESET} {GREEN}{h['duration']}{RESET}")
            print()
        elif choice == "6":
            print(f"{YELLOW}Exiting SSH tower...{RESET}")
            sys.exit(0)
        else:
            print(f"{RED}Invalid option. Try again.{RESET}")

if __name__ == "__main__":
    main()
