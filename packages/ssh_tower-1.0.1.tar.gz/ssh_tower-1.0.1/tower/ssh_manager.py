import time
import paramiko
import logging
from datetime import datetime

class SSHSession:
    def __init__(self, sec_mgr):
        self.client = paramiko.SSHClient()
        self.client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        self.sec_mgr = sec_mgr
        self.connected = False
        self.start_time = None
        self.current_ip = None
        self.current_name = None

    def connect(self, name, profile):
        try:
            password = self.sec_mgr.decrypt(profile["password"]) if "password" in profile else None
            key_path = profile.get("key_path")

            if key_path:
                self.client.connect(profile["ip"], port=profile["port"], username=profile["user"], key_filename=key_path)
            else:
                self.client.connect(profile["ip"], port=profile["port"], username=profile["user"], password=password)

            self.connected = True
            self.start_time = time.time()
            self.current_ip = profile["ip"]
            self.current_name = name
            logging.info(f"Connected to {name} ({self.current_ip})")
            return True, "Connected successfully"
        except Exception as e:
            logging.error(f"Failed to connect to {name}: {e}")
            return False, str(e)

    def execute(self, command):
        if not self.connected: return "Not connected."
        stdin, stdout, stderr = self.client.exec_command(command)
        return stdout.read().decode().strip() + stderr.read().decode().strip()

    def freeze_device(self):
        # Simulates freeze by running a dummy CPU max process in background
        return self.execute('nohup python3 -c "while True: pass" > /dev/null 2>&1 & echo $!')

    def shutdown_device(self):
        return self.execute("sudo shutdown -h now")

    def disconnect(self):
        if self.connected:
            duration = round(time.time() - self.start_time, 2)
            self.client.close()
            self.connected = False
            self.sec_mgr.log_connection(self.current_name, self.current_ip, f"{duration}s")
