import socket
import subprocess
import platform
from concurrent.futures import ThreadPoolExecutor

class NetworkScanner:
    @staticmethod
    def get_local_ip():
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            ip = s.getsockname()[0]
            s.close()
            return ip
        except Exception:
            return "127.0.0.1"

    @staticmethod
    def get_arp_ips():
        """Reads the ARP table for instant local device discovery (Fastest)."""
        ips = set()
        try:
            if platform.system() == "Linux" or "termux" in platform.release().lower():
                with open('/proc/net/arp') as f:
                    next(f) # Skip header
                    for line in f:
                        parts = line.split()
                        if len(parts) >= 4 and parts[3] != "00:00:00:00:00:00":
                            ips.add(parts[0])
        except Exception:
            pass
        return ips

    @staticmethod
    def scan_port(ip, port=22, timeout=0.2):
        """Checks if port 22 is open on a given IP."""
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.settimeout(timeout)
            result = s.connect_ex((ip, port))
            s.close()
            if result == 0:
                try:
                    hostname = socket.gethostbyaddr(ip)[0]
                except socket.herror:
                    hostname = "Unknown Device"
                return {"ip": ip, "hostname": hostname}
        except Exception:
            pass
        return None

    @staticmethod
    def scan_network():
        """Combines ARP checking with a threaded subnet sweep."""
        local_ip = NetworkScanner.get_local_ip()
        base_ip = ".".join(local_ip.split(".")[:-1]) + "."
        
        # Build list of IPs to scan: 1-255 + any known ARP IPs
        target_ips = set([f"{base_ip}{i}" for i in range(1, 255)])
        target_ips.update(NetworkScanner.get_arp_ips())
        
        active_hosts = []
        
        # Aggressive 100-thread sweep for blazing fast discovery
        with ThreadPoolExecutor(max_workers=100) as executor:
            futures = [executor.submit(NetworkScanner.scan_port, ip) for ip in target_ips]
            for future in futures:
                result = future.result()
                if result:
                    active_hosts.append(result)
                    
        return sorted(active_hosts, key=lambda x: x['ip'])
