import socket
import random
import json
import threading
import time

CYAN = '\033[96m'
YELLOW = '\033[93m'
GREEN = '\033[92m'
RED = '\033[91m'
BOLD = '\033[1m'
RESET = '\033[0m'

class PairingSystem:
    def __init__(self, sec_mgr):
        self.sec_mgr = sec_mgr
        self.tcp_port = 55555
        self.udp_port = 55556
        self.active_pin = None
        self.hosting = False

    def start_host(self):
        self.active_pin = str(random.randint(100000, 999999))
        local_ip = socket.gethostbyname(socket.gethostname())
        self.hosting = True
        
        print(f"\n{BOLD}{CYAN}AirDrop Hosting Active!{RESET}")
        print(f"Tell the other device to scan, then enter PIN: {BOLD}{YELLOW}{self.active_pin}{RESET}")

        # Start TCP Listener for the actual PIN exchange
        threading.Thread(target=self._listen_for_pairing, args=(local_ip,), daemon=True).start()
        # Start UDP Broadcaster so clients can auto-discover this device
        threading.Thread(target=self._broadcast_presence, args=(local_ip,), daemon=True).start()

    def _broadcast_presence(self, local_ip):
        """Invisibly broadcasts presence to the local network."""
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
        hostname = socket.gethostname()
        
        while self.hosting:
            msg = f"NEXUS:{hostname}:{local_ip}"
            try:
                s.sendto(msg.encode(), ('<broadcast>', self.udp_port))
            except Exception:
                pass
            time.sleep(1.5)
        s.close()

    def stop_host(self):
        self.hosting = False
        self.active_pin = None

    def _listen_for_pairing(self, ip):
        server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        server.bind(("0.0.0.0", self.tcp_port))
        server.listen(1)
        server.settimeout(1) # Allows us to check if hosting was stopped
        
        while self.hosting:
            try:
                client, addr = server.accept()
                data = client.recv(1024).decode()
                if data == self.active_pin:
                    print(f"\n{BOLD}{GREEN}[!] Device at {addr[0]} entered correct PIN!{RESET}")
                    print(f"{YELLOW}Securely transmitting SSH credentials...{RESET}\n")
                    # In a real app, prompt the host to ACCEPT/REJECT here.
                    creds = json.dumps({"user": "admin", "password": "dummy_password"})
                    client.send(self.sec_mgr.encrypt(creds).encode())
                    self.stop_host() # Stop hosting after success
                else:
                    client.send(b"DENIED")
                client.close()
            except socket.timeout:
                continue
            except Exception:
                break
        server.close()

    def discover_hosts(self):
        """Scans the network for active AirDrop hosts broadcasting UDP."""
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        s.bind(('', self.udp_port))
        s.settimeout(3.0) # Listen for 3 seconds
        
        hosts = {}
        try:
            while True:
                data, addr = s.recvfrom(1024)
                if data.startswith(b"NEXUS:"):
                    _, name, ip = data.decode().split(":")
                    if ip not in hosts:
                        hosts[ip] = name
        except socket.timeout:
            pass
        finally:
            s.close()
            
        return hosts

    def connect_to_host(self, ip, pin):
        try:
            client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            client.settimeout(5)
            client.connect((ip, self.tcp_port))
            client.send(pin.encode())
            response = client.recv(2048).decode()
            client.close()
            
            if response == "DENIED":
                return False, "Pairing rejected or invalid PIN."
                
            creds = json.loads(self.sec_mgr.decrypt(response))
            return True, creds
        except Exception as e:
            return False, f"Connection error: {str(e)}"
