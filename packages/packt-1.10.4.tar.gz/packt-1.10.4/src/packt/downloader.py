import logging
import os
import re
import shutil
import tempfile
import time

import requests
from slugify import slugify
from tqdm import tqdm

from .api import (
    PACKT_API_PRODUCT_FILE_DOWNLOAD_URL,
    PACKT_API_PRODUCT_FILE_TYPES_URL,
)

logger = logging.getLogger("packt")


class PacktConnectionError(requests.ConnectionError):
    """Error raised whenever fetching data from Packt API fails."""


def slugify_product_name(title):
    """Return book title with spaces replaced by underscore and unicodes replaced by characters valid in filenames."""
    return slugify(
        title,
        separator="_",
        lowercase=False,
        regex_pattern=re.compile(r"[^-a-zA-Z0-9\+\#\.\-\–]+"),  # noqa: RUF001
        replacements=[["–", "-"]],  # noqa: RUF001
    )


def wait_for_computation(predicate, timeout, retry_after):
    """Return wrapped function retrying computation until result satisfies given predicate or timeout is reached."""

    def wrapper(func):
        def compute(*args, time_left=timeout, **kwargs):
            if time_left <= 0:
                raise TimeoutError("Timeout reached!")

            try:
                result = func(*args, **kwargs)
                if predicate(result):
                    return result

                time.sleep(retry_after)
                return compute(*args, time_left=time_left - retry_after, **kwargs)
            except Exception:  # noqa: BLE001
                time.sleep(retry_after)
                return compute(*args, time_left=time_left - retry_after, **kwargs)

        return compute

    return wrapper


def get_product_download_url(product_id, file_type):
    file_format_mapping = {"code": "code_bundle", "epub": "epub", "mobi": "mobi", "pdf": "ebook", "video": "video_zip"}

    return PACKT_API_PRODUCT_FILE_DOWNLOAD_URL.format(product_id=product_id, file_type=file_format_mapping[file_type])


@wait_for_computation(lambda _: all(_.values()), 15.0, 0.75)
def get_product_download_urls(api_client, product_id, formats):
    error_message = f"Couldn't fetch download URLs for product {product_id}."
    try:
        response = api_client.get(PACKT_API_PRODUCT_FILE_TYPES_URL.format(product_id=product_id))
        if response.status_code == 200:  # noqa: PLR2004
            return {
                file_format: get_product_download_url(product_id, file_format)
                for file_format in response.json().get("data")[0].get("fileTypes")
                if file_format in formats
            }

        logger.info(error_message)
        return {}
    except Exception:  # noqa: BLE001
        raise PacktConnectionError(error_message)  # noqa: B904


def download_file(api_client, url, file_name, chunk_size=1024):
    r = api_client.get(url, timeout=100, stream=True)
    if r.status_code == 200:  # noqa: PLR2004
        content_length = int(r.headers.get("Content-Length", 0))
        with (
            tempfile.NamedTemporaryFile() as fp,
            tqdm(total=content_length, unit="iB", unit_scale=True, unit_divisor=chunk_size) as progress_bar,
        ):
            for chunk in r.iter_content(chunk_size):
                if chunk:
                    size = fp.write(chunk)
                    progress_bar.update(size)
                    fp.flush()
            shutil.move(fp.name, file_name)


def download_products(api_client, download_directory, formats, product_list, into_folder=False):  # noqa: FBT002
    """Download selected products."""
    nr_of_books_downloaded = 0
    for book in product_list:
        download_urls = get_product_download_urls(api_client, book["id"], formats)
        for file_format, download_url in download_urls.items():
            file_extension = "zip" if file_format in ("video", "code") else file_format
            file_name = slugify_product_name(book["title"])
            logger.info('Title: "{}"'.format(book["title"]))
            if into_folder:
                target_download_path = os.path.join(download_directory, file_name)
                if not os.path.isdir(target_download_path):
                    os.mkdir(target_download_path)
            else:
                target_download_path = os.path.join(download_directory)
            full_file_path = os.path.join(target_download_path, f"{file_name}.{file_extension}")
            if os.path.isfile(full_file_path):
                logger.info('"{}.{}" already exists under the given path.'.format(file_name, file_extension))
            else:
                if file_format == "code":
                    logger.info('Downloading code for ebook: "{}"...'.format(book["title"]))
                elif file_format == "video":
                    logger.info('Downloading "{}" video...'.format(book["title"]))
                else:
                    logger.info('Downloading ebook: "{}" in {} format...'.format(book["title"], file_format))
                try:
                    download_file(api_client, download_url, full_file_path)
                    logger.info(
                        f'Code for ebook "{book["title"]}" downloaded successfully!'
                        if file_format == "code"
                        else f'Ebook "{book["title"]}" in {file_format} format downloaded successfully!'
                    )
                    nr_of_books_downloaded += 1
                except Exception as e:  # noqa: BLE001
                    message = 'Couldn\'t download "{}" ebook in {} format.'.format(book["title"], file_format)
                    logger.error(message)
                    logger.error(e)
    logger.info("{} ebooks have been downloaded!".format(str(nr_of_books_downloaded)))
