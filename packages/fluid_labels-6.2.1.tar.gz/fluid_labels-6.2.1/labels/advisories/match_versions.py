import logging
from functools import lru_cache

from fluidattacks_core.rustport import (
    PyFixMetadata,
    PyFixMetadataNew,
    PyResidualCves,
    PySeverityCves,
)
from fluidattacks_core.rustport import compute_fix_metadata as _rust_compute_fix_metadata
from fluidattacks_core.rustport import match_version_ranges as _rust_match_version_ranges
from fluidattacks_core.rustport import match_vulnerable_versions as _rust_match_vulnerable_versions

from labels.model.advisories import (
    Advisory,
    AdvisoryFixMetadataNew,
    FixMetadata,
    ResidualCVES,
    SeverityCVES,
    UpgradeType,
)

LOGGER = logging.getLogger(__name__)


def _to_severity(s: PySeverityCves | None) -> SeverityCVES | None:
    if s is None:
        return None
    return SeverityCVES(
        critical=s.critical,
        high=s.high,
        medium=s.medium,
        low=s.low,
        total=s.total,
    )


def _to_residual(r: PyResidualCves | None) -> ResidualCVES | None:
    if r is None:
        return None
    return ResidualCVES(
        remedied=_to_severity(r.remedied),
        maintained=_to_severity(r.maintained),
        introduced=_to_severity(r.introduced),
    )


def _to_fix_metadata(f: PyFixMetadata) -> FixMetadata:
    return FixMetadata(
        fix_version=f.fix_version,
        upgrade_type=UpgradeType(f.upgrade_type),
        breaking_change=f.breaking_change,
        residual_cves=_to_residual(f.residual_cves),
    )


def _to_fix_metadata_new(obj: PyFixMetadataNew) -> AdvisoryFixMetadataNew:
    return AdvisoryFixMetadataNew(
        closest_min_fix=_to_fix_metadata(obj.closest_min_fix),
        closest_safe_fix=_to_fix_metadata(obj.closest_safe_fix) if obj.closest_safe_fix else None,
        closest_complete_fix=_to_fix_metadata(obj.closest_complete_fix)
        if obj.closest_complete_fix
        else None,
    )


@lru_cache(maxsize=10000)  # type: ignore[misc]
def match_version_ranges(dep_version: str, vulnerable_version: str) -> bool:
    return _rust_match_version_ranges(dep_version, vulnerable_version)


@lru_cache(maxsize=10000)  # type: ignore[misc]
def match_vulnerable_versions(dep_version: str, advisory_range: str | None) -> bool:
    return _rust_match_vulnerable_versions(dep_version, advisory_range)


def match_fixed_versions(
    dep_version: str,
    advisory: Advisory,
    complete_fix_versions: list[str] | None,
    all_package_versions: list[str],
    advisories: list[Advisory],
) -> Advisory:
    try:
        all_adv_tuples = [(a.id, a.vulnerable_version, a.severity_level) for a in advisories]
        result = _rust_compute_fix_metadata(
            dep_version,
            advisory.fixed_versions or [],
            advisory.vulnerable_version,
            complete_fix_versions,
            all_package_versions,
            all_adv_tuples,
            advisory.ecosystem,
        )
        if not result:
            return advisory
        advisory.fix_metadata_new = _to_fix_metadata_new(result)
    except Exception:
        LOGGER.exception(
            "Unexpected error calculating fix metadata. Reporting advisories without it"
        )

    return advisory
