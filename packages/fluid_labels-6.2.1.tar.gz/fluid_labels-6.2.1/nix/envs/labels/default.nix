{
  inputs,
  pkgs,
  projectPath,
}:
let
  envars = import ./envars.nix { inherit pkgs projectPath; };
  venv = import ./venv.nix { inherit inputs pkgs projectPath; };

  dependencies =
    let
      osDependencies = [
        pkgs.git
        pkgs.uv
        pkgs.syft
      ];
    in
    {
      default = pkgs.lib.flatten [
        venv.default
        osDependencies
      ];
      editable = pkgs.lib.flatten [
        venv.editable
        osDependencies
      ];
    };
in
{
  inherit dependencies envars venv;
}
