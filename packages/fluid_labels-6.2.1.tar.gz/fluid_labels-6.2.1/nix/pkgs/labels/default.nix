{ lib', pkgs }:
pkgs.writeShellApplication {
  name = "labels";
  runtimeInputs = pkgs.lib.flatten [
    lib'.envs.labels.dependencies.default
    lib'.envs.labels.envars
  ];
  extraShellCheckFlags = [ "-x" ];
  text = ''
    # shellcheck source=${lib'.envs.labels.envars}/bin/labels-envars
    source labels-envars

    fluid-labels "$@"
  '';
}
