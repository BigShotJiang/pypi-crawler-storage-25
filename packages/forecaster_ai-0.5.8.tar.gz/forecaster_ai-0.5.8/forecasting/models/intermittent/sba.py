"""
SBA (Syntetos-Boylan Approximation) method for intermittent demand forecasting.

Reference:
    Syntetos, A. A., & Boylan, J. E. (2005).
    The accuracy of intermittent demand estimates.
    International Journal of Forecasting, 21(2), 303-314.
"""

from typing import Optional
import numpy as np

from forecasting.core.base import BaseForecaster
from forecasting.core.config import ForecastConfig
from forecasting.core.exceptions import ModelNotFittedError, ValidationError


class SBAForecaster(BaseForecaster):
    """
    SBA (Syntetos-Boylan Approximation) method for intermittent demand forecasting.
    
    An improved version of Croston's method that corrects for the positive bias
    in Croston's forecasts. SBA applies a bias correction factor:
    
    SBA forecast = Croston forecast * (1 - alpha / 2)
    
    where alpha is the smoothing parameter.
    
    Best suited for:
    - Intermittent demand (ADI between 1.32 and 1.6)
    - Items with moderate variability
    - More accurate than Croston for most intermittent patterns
    
    Parameters
    ----------
    alpha : float, default=0.1
        Smoothing parameter for both demand size and inter-arrival time (0 < alpha <= 1)
    min_demand_threshold : float, default=0.01
        Minimum value to consider as non-zero demand
    
    Attributes
    ----------
    demand_size_ : float
        Smoothed demand size estimate
    inter_arrival_ : float
        Smoothed inter-arrival time estimate
    is_fitted : bool
        Whether the model has been fitted
    
    Examples
    --------
    >>> import numpy as np
    >>> from forecasting.models.intermittent import SBAForecaster
    >>> 
    >>> # Intermittent demand data
    >>> y = np.array([0, 0, 5, 0, 0, 0, 8, 0, 0, 0, 0, 3, 0, 0, 0, 0, 0, 6])
    >>> 
    >>> # Fit SBA model
    >>> model = SBAForecaster(alpha=0.1)
    >>> model.fit(y)
    >>> 
    >>> # Forecast next 10 periods
    >>> forecast = model.predict(steps=10)
    >>> print(forecast)
    """
    
    def __init__(
        self,
        config: Optional[ForecastConfig] = None,
        alpha: float = 0.1,
        min_demand_threshold: float = 0.01
    ):
        """Initialize SBA forecaster."""
        super().__init__(config or ForecastConfig())
        
        if not 0 < alpha <= 1:
            raise ValidationError("alpha must be between 0 and 1")
        
        self.alpha = alpha
        self.min_demand_threshold = min_demand_threshold
        
        # Model parameters (fitted)
        self.demand_size_: Optional[float] = None
        self.inter_arrival_: Optional[float] = None
        self.bias_correction_factor_: Optional[float] = None
        
    def fit(
        self,
        y: np.ndarray,
        dates: Optional[np.ndarray] = None,
        exog: Optional[np.ndarray] = None
    ) -> 'SBAForecaster':
        """
        Fit SBA model to intermittent demand data.
        
        Parameters
        ----------
        y : np.ndarray
            Time series data with intermittent demand
        dates : np.ndarray, optional
            Not used, kept for API consistency
        exog : np.ndarray, optional
            Not used, SBA doesn't use exogenous variables
            
        Returns
        -------
        self : SBAForecaster
            Fitted model
        """
        # Validate input
        y = self._validate_input(y)
        
        # Identify non-zero demand periods
        non_zero_mask = y > self.min_demand_threshold
        non_zero_indices = np.where(non_zero_mask)[0]
        
        if len(non_zero_indices) < 2:
            raise ValidationError("Need at least 2 non-zero demand observations")
        
        # Initialize demand size with first non-zero demand
        self.demand_size_ = float(y[non_zero_indices[0]])
        
        # Initialize inter-arrival time with first interval
        self.inter_arrival_ = float(non_zero_indices[1] - non_zero_indices[0])
        
        # Track time since last demand
        time_since_last_demand = 0
        
        # Update estimates using exponential smoothing (Croston's method)
        for t in range(1, len(y)):
            time_since_last_demand += 1
            
            if y[t] > self.min_demand_threshold:
                # Update demand size
                self.demand_size_ = (
                    self.alpha * y[t] +
                    (1 - self.alpha) * self.demand_size_
                )
                
                # Update inter-arrival time
                self.inter_arrival_ = (
                    self.alpha * time_since_last_demand +
                    (1 - self.alpha) * self.inter_arrival_
                )
                
                # Reset counter
                time_since_last_demand = 0
        
        # Calculate SBA bias correction factor
        self.bias_correction_factor_ = 1 - (self.alpha / 2)
        
        self.is_fitted = True
        self.logger.info(
            f"SBA model fitted: demand_size={self.demand_size_:.2f}, "
            f"inter_arrival={self.inter_arrival_:.2f}, "
            f"bias_correction={self.bias_correction_factor_:.4f}"
        )
        
        return self
    
    def predict(
        self,
        steps: int = 1,
        exog: Optional[np.ndarray] = None,
        return_conf_int: bool = False,
        alpha: float = 0.05
    ) -> np.ndarray:
        """
        Generate forecasts using SBA method.
        
        Parameters
        ----------
        steps : int, default=1
            Number of periods to forecast
        exog : np.ndarray, optional
            Not used, kept for API consistency
        return_conf_int : bool, default=False
            Not supported for SBA method
        alpha : float, default=0.05
            Not used, kept for API consistency
            
        Returns
        -------
        forecast : np.ndarray
            Point forecasts for the next 'steps' periods
        """
        if not self.is_fitted:
            raise ModelNotFittedError("Model must be fitted before prediction")
        
        if return_conf_int:
            self.logger.warning(
                "Confidence intervals not supported for SBA method"
            )
        
        # Croston's forecast
        croston_forecast = self.demand_size_ / self.inter_arrival_
        
        # Apply SBA bias correction
        sba_forecast = croston_forecast * self.bias_correction_factor_
        
        # Return constant forecast for all steps
        forecast = np.full(steps, sba_forecast)
        
        return forecast
    
    def get_params(self) -> dict:
        """Get model parameters."""
        params = {
            'alpha': self.alpha,
            'min_demand_threshold': self.min_demand_threshold
        }
        
        if self.is_fitted:
            croston_forecast = self.demand_size_ / self.inter_arrival_
            sba_forecast = croston_forecast * self.bias_correction_factor_
            
            params.update({
                'demand_size': self.demand_size_,
                'inter_arrival': self.inter_arrival_,
                'bias_correction_factor': self.bias_correction_factor_,
                'croston_forecast': croston_forecast,
                'sba_forecast': sba_forecast,
                'bias_reduction': croston_forecast - sba_forecast
            })
        
        return params
    
    def _validate_input(self, y: np.ndarray) -> np.ndarray:
        """Validate input data."""
        if not isinstance(y, np.ndarray):
            y = np.array(y)
        
        if y.ndim != 1:
            raise ValidationError("Input must be 1-dimensional")
        
        if len(y) < 2:
            raise ValidationError("Input must have at least 2 observations")
        
        if np.any(y < 0):
            raise ValidationError("Demand cannot be negative")
        
        return y
    
    def compare_with_croston(self, y: np.ndarray) -> dict:
        """
        Compare SBA forecast with Croston's method.
        
        Parameters
        ----------
        y : np.ndarray
            Time series data
            
        Returns
        -------
        comparison : dict
            Dictionary containing forecasts from both methods and bias reduction
        """
        from forecasting.models.intermittent.croston import CrostonForecaster
        
        # Fit both models
        croston = CrostonForecaster(alpha=self.alpha)
        croston.fit(y)
        
        # Get forecasts
        sba_forecast = self.predict(steps=1)[0]
        croston_forecast = croston.predict(steps=1)[0]
        
        return {
            'sba_forecast': sba_forecast,
            'croston_forecast': croston_forecast,
            'bias_reduction': croston_forecast - sba_forecast,
            'bias_reduction_pct': ((croston_forecast - sba_forecast) / croston_forecast * 100) if croston_forecast > 0 else 0,
            'bias_correction_factor': self.bias_correction_factor_,
            'demand_size': self.demand_size_,
            'inter_arrival': self.inter_arrival_
        }


# Made with Bob