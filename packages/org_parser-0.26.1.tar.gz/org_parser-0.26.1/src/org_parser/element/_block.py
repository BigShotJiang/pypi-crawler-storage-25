"""Semantic element classes for Org block nodes."""

from __future__ import annotations

from typing import TYPE_CHECKING

from org_parser._node import is_error_node, node_source
from org_parser._nodes import INDENT, SPECIAL_KEYWORD
from org_parser.element._dirty_list import DirtyList
from org_parser.element._dispatch import body_element_factories
from org_parser.element._element import (
    Element,
    build_semantic_repr,
    coerce_element_body,
    element_from_error_or_unknown,
    ensure_trailing_newline,
)
from org_parser.element._structure import Indent

if TYPE_CHECKING:
    from collections.abc import Callable, Iterator, Sequence

    import tree_sitter

    from org_parser.document._document import Document
    from org_parser.document._heading import Heading

__all__ = [
    "CenterBlock",
    "CommentBlock",
    "DynamicBlock",
    "ExampleBlock",
    "ExportBlock",
    "FixedWidthBlock",
    "QuoteBlock",
    "SourceBlock",
    "SpecialBlock",
    "VerseBlock",
]

_TRUNCATED_BLOCK_MESSAGE = "Unterminated block (missing end marker)"


class _ContainerBlock(Element):
    """Base class for blocks whose contents are nested elements."""

    def __init__(
        self,
        *,
        begin_line: str,
        end_line: str,
        body: Sequence[Element] = (),
        parent: Document | Heading | Element | None = None,
    ) -> None:
        super().__init__(parent=parent)
        self._begin_line = begin_line
        self._end_line = end_line
        self._body = list(body)
        self._adopt_body(self._body)

    @property
    def body(self) -> list[Element]:
        """Mutable block contents as semantic elements."""

        def on_body_mutation(wrapped: DirtyList[Element]) -> None:
            self._body = list(wrapped)
            self._adopt_body(self._body)
            self.mark_dirty()

        return DirtyList(self._body, on_mutation=on_body_mutation)

    @body.setter
    def body(self, value: Sequence[Element] | Element | str) -> None:
        """Set block contents."""
        self._body = list(coerce_element_body(value))
        self._adopt_body(self._body)
        self.mark_dirty()

    @property
    def body_text(self) -> str:
        """Stringified text of all nested block body elements."""
        return "".join(str(element) for element in self._body)

    def reformat(self) -> None:
        """Mark contents and this block dirty for scratch-built rendering."""
        for element in self._body:
            element.reformat()
        self.mark_dirty()

    def _adopt_body(self, body: Sequence[Element]) -> None:
        """Assign this block as parent for each nested element."""
        for element in body:
            element.parent = self

    def _render_body(self) -> str:
        """Render nested contents ensuring one trailing newline per child."""
        return "".join(ensure_trailing_newline(str(element)) for element in self._body)

    def __str__(self) -> str:
        """Render block text preserving source while parse-backed and clean."""
        if not self.dirty and self._node is not None and self._document is not None:
            return node_source(self._node, self._document)
        return f"{self._begin_line}\n{self._render_body()}{self._end_line}\n"

    def __repr__(self) -> str:
        """Return a tree-oriented representation for debugging."""
        return build_semantic_repr(
            self.__class__.__name__,
            begin_line=self._begin_line,
            body=self._body,
        )

    def __iter__(self) -> Iterator[Element]:
        """Iterate over body elements."""
        return iter(self._body)

    def __len__(self) -> int:
        """Return number of body elements."""
        return len(self._body)

    def __getitem__(self, index: int | slice) -> Element | list[Element]:
        """Return one body element (or body slice)."""
        return self._body[index]


class _TextBlock(Element):
    """Base class for blocks whose contents are plain mutable text."""

    def __init__(
        self,
        *,
        begin_line: str,
        end_line: str,
        body: str,
        parent: Document | Heading | Element | None = None,
    ) -> None:
        super().__init__(parent=parent)
        self._begin_line = begin_line
        self._end_line = end_line
        self._body = body

    @property
    def body(self) -> str:
        """Mutable block contents text without delimiters."""
        return self._body

    @body.setter
    def body(self, value: str) -> None:
        """Set block contents text."""
        self._body = value
        self.mark_dirty()

    def __str__(self) -> str:
        """Render block text preserving source while parse-backed and clean."""
        if not self.dirty and self._node is not None and self._document is not None:
            return node_source(self._node, self._document)
        content = _ensure_single_trailing_newline(self._body)
        return f"{self._begin_line}\n{content}{self._end_line}\n"

    def __repr__(self) -> str:
        """Return a tree-oriented representation for debugging."""
        return build_semantic_repr(
            self.__class__.__name__,
            begin_line=self._begin_line,
            body=self._body,
        )


class CenterBlock(_ContainerBlock):
    r"""``#+begin_center`` block with mutable nested element contents.

    Example:
    ```python
    >>> from org_parser.element import CenterBlock
    >>> b = CenterBlock.from_source('''\
    ... #+begin_center :width 60
    ... content
    ... #+end_center
    ... ''')
    >>> b.parameters
    ':width 60'
    >>> b.body_text
    'content\n'
    ```
    """

    def __init__(
        self,
        *,
        parameters: str | None = None,
        body: Sequence[Element] = (),
        parent: Document | Heading | Element | None = None,
    ) -> None:
        self._parameters = _normalize_optional_text(parameters)
        super().__init__(
            begin_line=_render_begin_line("center", self._parameters),
            end_line="#+end_center",
            body=body,
            parent=parent,
        )

    @classmethod
    def from_node(
        cls,
        node: tree_sitter.Node,
        document: Document,
        *,
        parent: Document | Heading | Element | None = None,
    ) -> CenterBlock:
        """Create a [org_parser.element.CenterBlock][] from a ``center_block`` node."""
        source_text = node_source(node, document)
        block = cls(
            parameters=_extract_optional_field_text(node, document, "parameters")
            or _extract_begin_parameters(source_text, "#+begin_center"),
            body=_extract_container_contents(node, document),
            parent=parent,
        )
        block._node = node
        block._document = document
        _report_direct_block_parse_errors(node, document)
        return block

    @property
    def parameters(self) -> str | None:
        """Optional trailing parameters from the begin line."""
        return self._parameters

    @parameters.setter
    def parameters(self, value: str | None) -> None:
        """Set begin-line parameters."""
        self._parameters = _normalize_optional_text(value)
        self._begin_line = _render_begin_line("center", self._parameters)
        self.mark_dirty()

    def __repr__(self) -> str:
        """Return a semantic representation for debugging."""
        return build_semantic_repr(
            self.__class__.__name__,
            parameters=self._parameters,
            body=self._body,
        )


class QuoteBlock(_ContainerBlock):
    r"""``#+begin_quote`` block with mutable nested element contents.

    Example:
    ```python
    >>> from org_parser.element import QuoteBlock
    >>> b = QuoteBlock.from_source('''\
    ... #+begin_quote :left
    ... content
    ... #+end_quote
    ... ''')
    >>> b.parameters
    ':left'
    >>> b.body_text
    'content\n'
    ```
    """

    def __init__(
        self,
        *,
        parameters: str | None = None,
        body: Sequence[Element] = (),
        parent: Document | Heading | Element | None = None,
    ) -> None:
        self._parameters = _normalize_optional_text(parameters)
        super().__init__(
            begin_line=_render_begin_line("quote", self._parameters),
            end_line="#+end_quote",
            body=body,
            parent=parent,
        )

    @classmethod
    def from_node(
        cls,
        node: tree_sitter.Node,
        document: Document,
        *,
        parent: Document | Heading | Element | None = None,
    ) -> QuoteBlock:
        """Create a [org_parser.element.QuoteBlock][] from a ``quote_block`` node."""
        source_text = node_source(node, document)
        block = cls(
            parameters=_extract_optional_field_text(node, document, "parameters")
            or _extract_begin_parameters(source_text, "#+begin_quote"),
            body=_extract_container_contents(node, document),
            parent=parent,
        )
        block._node = node
        block._document = document
        _report_direct_block_parse_errors(node, document)
        return block

    @property
    def parameters(self) -> str | None:
        """Optional trailing parameters from the begin line."""
        return self._parameters

    @parameters.setter
    def parameters(self, value: str | None) -> None:
        """Set begin-line parameters."""
        self._parameters = _normalize_optional_text(value)
        self._begin_line = _render_begin_line("quote", self._parameters)
        self.mark_dirty()

    def __repr__(self) -> str:
        """Return a semantic representation for debugging."""
        return build_semantic_repr(
            self.__class__.__name__,
            parameters=self._parameters,
            body=self._body,
        )


class SpecialBlock(_ContainerBlock):
    r"""``#+begin_<name>`` block with mutable nested element contents.

    Example:
    ```python
    >>> from org_parser.element import SpecialBlock
    >>> b = SpecialBlock.from_source('''\
    ... #+begin_NOTE :notes
    ... content
    ... #+end_NOTE
    ... ''')
    >>> b.name
    'NOTE'
    >>> b.parameters
    ':notes'
    >>> b.body_text
    'content\n'
    ```
    """

    def __init__(
        self,
        *,
        name: str,
        parameters: str | None = None,
        body: Sequence[Element] = (),
        parent: Document | Heading | Element | None = None,
    ) -> None:
        self._name = name
        self._parameters = _normalize_optional_text(parameters)
        super().__init__(
            begin_line=_render_begin_line(name, self._parameters),
            end_line=f"#+end_{name}",
            body=body,
            parent=parent,
        )

    @classmethod
    def from_node(
        cls,
        node: tree_sitter.Node,
        document: Document,
        *,
        parent: Document | Heading | Element | None = None,
    ) -> SpecialBlock:
        """Create a [org_parser.element.SpecialBlock][] from a ``special_block`` node."""
        source_text = node_source(node, document)
        name = _extract_optional_field_text(node, document, "name")
        parsed_name, parsed_parameters = _extract_special_begin_data(source_text)
        block = cls(
            name=parsed_name if name is None else name,
            parameters=_extract_optional_field_text(node, document, "parameters")
            or parsed_parameters,
            body=_extract_container_contents(node, document),
            parent=parent,
        )
        block._node = node
        block._document = document
        _report_direct_block_parse_errors(node, document)
        return block

    @property
    def name(self) -> str:
        """Special block name (the ``<name>`` in ``#+begin_<name>``)."""
        return self._name

    @name.setter
    def name(self, value: str) -> None:
        """Set block name."""
        self._name = value
        self._begin_line = _render_begin_line(self._name, self._parameters)
        self._end_line = f"#+end_{self._name}"
        self.mark_dirty()

    @property
    def parameters(self) -> str | None:
        """Optional trailing parameters from the begin line."""
        return self._parameters

    @parameters.setter
    def parameters(self, value: str | None) -> None:
        """Set begin-line parameters."""
        self._parameters = _normalize_optional_text(value)
        self._begin_line = _render_begin_line(self._name, self._parameters)
        self.mark_dirty()

    def __repr__(self) -> str:
        """Return a semantic representation for debugging."""
        return build_semantic_repr(
            self.__class__.__name__,
            name=self._name,
            parameters=self._parameters,
            body=self._body,
        )


class DynamicBlock(_ContainerBlock):
    r"""``#+begin:`` dynamic block with mutable nested element contents.

    Example:
    ```python
    >>> from org_parser.element import DynamicBlock
    >>> b = DynamicBlock.from_source('''\
    ... #+begin: notes :value
    ... content
    ... #+end:
    ... ''')
    >>> b.name
    'notes'
    >>> b.parameters
    ':value'
    >>> b.body_text
    'content\n'
    ```
    """

    def __init__(
        self,
        *,
        name: str,
        parameters: str | None = None,
        body: Sequence[Element] = (),
        parent: Document | Heading | Element | None = None,
    ) -> None:
        self._name = name
        self._parameters = _normalize_optional_text(parameters)
        super().__init__(
            begin_line=_render_dynamic_begin_line(name, self._parameters),
            end_line="#+end:",
            body=body,
            parent=parent,
        )

    @classmethod
    def from_node(
        cls,
        node: tree_sitter.Node,
        document: Document,
        *,
        parent: Document | Heading | Element | None = None,
    ) -> DynamicBlock:
        """Create a [org_parser.element.DynamicBlock][] from a ``dynamic_block`` node."""
        source_text = node_source(node, document)
        name = _extract_optional_field_text(node, document, "name")
        parsed_name, parsed_parameters = _extract_dynamic_begin_data(source_text)
        block = cls(
            name=parsed_name if name is None else name,
            parameters=_extract_optional_field_text(node, document, "parameters")
            or parsed_parameters,
            body=_extract_container_contents(node, document),
            parent=parent,
        )
        block._node = node
        block._document = document
        _report_direct_block_parse_errors(node, document)
        return block

    @property
    def name(self) -> str:
        """Dynamic block name from the begin line."""
        return self._name

    @name.setter
    def name(self, value: str) -> None:
        """Set dynamic block name."""
        self._name = value
        self._begin_line = _render_dynamic_begin_line(self._name, self._parameters)
        self.mark_dirty()

    @property
    def parameters(self) -> str | None:
        """Optional trailing parameters from the begin line."""
        return self._parameters

    @parameters.setter
    def parameters(self, value: str | None) -> None:
        """Set begin-line parameters."""
        self._parameters = _normalize_optional_text(value)
        self._begin_line = _render_dynamic_begin_line(self._name, self._parameters)
        self.mark_dirty()

    def __repr__(self) -> str:
        """Return a semantic representation for debugging."""
        return build_semantic_repr(
            self.__class__.__name__,
            name=self._name,
            parameters=self._parameters,
            body=self._body,
        )


class VerseBlock(_ContainerBlock):
    r"""``#+begin_verse`` block with mutable nested element contents.

    Example:
    ```python
    >>> from org_parser.element import VerseBlock
    >>> b = VerseBlock.from_source('''\
    ... #+begin_verse
    ... content
    ... #+end_verse
    ... ''')
    >>> b.body_text
    'content\n'
    ```
    """

    def __init__(
        self,
        *,
        body: Sequence[Element] = (),
        parent: Document | Heading | Element | None = None,
    ) -> None:
        super().__init__(
            begin_line="#+begin_verse",
            end_line="#+end_verse",
            body=body,
            parent=parent,
        )

    @classmethod
    def from_node(
        cls,
        node: tree_sitter.Node,
        document: Document,
        *,
        parent: Document | Heading | Element | None = None,
    ) -> VerseBlock:
        """Create a [org_parser.element.VerseBlock][] from a ``verse_block`` node."""
        block = cls(
            body=_extract_container_contents(node, document),
            parent=parent,
        )
        block._node = node
        block._document = document
        _report_direct_block_parse_errors(node, document)
        return block

    def __repr__(self) -> str:
        """Return a semantic representation for debugging."""
        return build_semantic_repr(self.__class__.__name__, body=self._body)


class CommentBlock(_TextBlock):
    r"""``#+begin_comment`` block with mutable raw text contents.

    Example:
    ```python
    >>> from org_parser.element import CommentBlock
    >>> b = CommentBlock.from_source('''\
    ... #+begin_comment
    ... content
    ... #+end_comment
    ... ''')
    >>> b.body
    'content\n'
    ```
    """

    def __init__(
        self,
        *,
        body: str,
        parent: Document | Heading | Element | None = None,
    ) -> None:
        super().__init__(
            begin_line="#+begin_comment",
            end_line="#+end_comment",
            body=body,
            parent=parent,
        )

    @classmethod
    def from_node(
        cls,
        node: tree_sitter.Node,
        document: Document,
        *,
        parent: Document | Heading | Element | None = None,
    ) -> CommentBlock:
        """Create a [org_parser.element.CommentBlock][] from a ``comment_block`` node."""
        block = cls(
            body=_extract_optional_field_text(node, document, "body") or "",
            parent=parent,
        )
        block._node = node
        block._document = document
        _report_direct_block_parse_errors(node, document)
        return block

    def __repr__(self) -> str:
        """Return a semantic representation for debugging."""
        return build_semantic_repr(self.__class__.__name__, body=self._body)


class ExampleBlock(_TextBlock):
    r"""``#+begin_example`` block with mutable raw text contents.

    Example:
    ```python
    >>> from org_parser.element import ExampleBlock
    >>> b = ExampleBlock.from_source('''\
    ... #+begin_example :param
    ... content
    ... #+end_example
    ... ''')
    >>> b.body
    'content\n'
    >>> b.parameters
    ':param'
    ```
    """

    def __init__(
        self,
        *,
        parameters: str | None = None,
        body: str,
        parent: Document | Heading | Element | None = None,
    ) -> None:
        self._parameters = _normalize_optional_text(parameters)
        super().__init__(
            begin_line=_render_begin_line("example", self._parameters),
            end_line="#+end_example",
            body=body,
            parent=parent,
        )

    @classmethod
    def from_node(
        cls,
        node: tree_sitter.Node,
        document: Document,
        *,
        parent: Document | Heading | Element | None = None,
    ) -> ExampleBlock:
        """Create a [org_parser.element.ExampleBlock][] from an ``example_block`` node."""
        source_text = node_source(node, document)
        block = cls(
            parameters=_extract_optional_field_text(node, document, "parameters")
            or _extract_begin_parameters(source_text, "#+begin_example"),
            body=_extract_optional_field_text(node, document, "body")
            or _extract_block_body_text(source_text),
            parent=parent,
        )
        block._node = node
        block._document = document
        _report_direct_block_parse_errors(node, document)
        return block

    @property
    def parameters(self) -> str | None:
        """Optional trailing parameters from the begin line."""
        return self._parameters

    @parameters.setter
    def parameters(self, value: str | None) -> None:
        """Set begin-line parameters."""
        self._parameters = _normalize_optional_text(value)
        self._begin_line = _render_begin_line("example", self._parameters)
        self.mark_dirty()

    def __repr__(self) -> str:
        """Return a semantic representation for debugging."""
        return build_semantic_repr(
            self.__class__.__name__,
            parameters=self._parameters,
            body=self._body,
        )


class ExportBlock(_TextBlock):
    r"""``#+begin_export`` block with mutable raw text contents.

    Example:
    ```python
    >>> from org_parser.element import ExportBlock
    >>> b = ExportBlock.from_source('''\
    ... #+begin_export  markdown:gfm
    ... # content
    ... #+end_export
    ... ''')
    >>> b.body
    '# content\n'
    >>> b.parameters
    ':gfm'
    >>> b.backend
    'markdown'
    ```
    """

    def __init__(
        self,
        *,
        backend: str,
        parameters: str | None = None,
        body: str,
        parent: Document | Heading | Element | None = None,
    ) -> None:
        self._backend = backend
        self._parameters = _normalize_optional_text(parameters)
        super().__init__(
            begin_line=_render_export_begin_line(self._backend, self._parameters),
            end_line="#+end_export",
            body=body,
            parent=parent,
        )

    @classmethod
    def from_node(
        cls,
        node: tree_sitter.Node,
        document: Document,
        *,
        parent: Document | Heading | Element | None = None,
    ) -> ExportBlock:
        """Create a [org_parser.element.ExportBlock][] from an ``export_block`` node."""
        source_text = node_source(node, document)
        backend = _extract_optional_field_text(node, document, "backend")
        parsed_backend, parsed_parameters = _extract_export_begin_data(source_text)
        block = cls(
            backend=parsed_backend if backend is None else backend,
            parameters=_extract_optional_field_text(node, document, "parameters")
            or parsed_parameters,
            body=_extract_optional_field_text(node, document, "body") or "",
            parent=parent,
        )
        block._node = node
        block._document = document
        _report_direct_block_parse_errors(node, document)
        return block

    @property
    def backend(self) -> str:
        """Export backend identifier from begin line."""
        return self._backend

    @backend.setter
    def backend(self, value: str) -> None:
        """Set export backend."""
        self._backend = value
        self._begin_line = _render_export_begin_line(self._backend, self._parameters)
        self.mark_dirty()

    @property
    def parameters(self) -> str | None:
        """Optional trailing parameters from the begin line."""
        return self._parameters

    @parameters.setter
    def parameters(self, value: str | None) -> None:
        """Set begin-line parameters."""
        self._parameters = _normalize_optional_text(value)
        self._begin_line = _render_export_begin_line(self._backend, self._parameters)
        self.mark_dirty()

    def __repr__(self) -> str:
        """Return a semantic representation for debugging."""
        return build_semantic_repr(
            self.__class__.__name__,
            backend=self._backend,
            parameters=self._parameters,
            body=self._body,
        )


class SourceBlock(_TextBlock):
    r"""``#+begin_src`` block with mutable source text contents.

    Example:
    ```python
    >>> from org_parser.element import SourceBlock
    >>> b = SourceBlock.from_source('''\
    ... #+begin_src  python :export stdout
    ... print("Hello world!")
    ... #+end_src
    ... ''')
    >>> b.body
    '# print("Hello world!")\n'
    >>> b.switches
    ':export stdout'
    >>> b.language
    'python'
    ```
    """

    def __init__(
        self,
        *,
        language: str | None = None,
        switches: str | None = None,
        body: str,
        parent: Document | Heading | Element | None = None,
    ) -> None:
        self._language = _normalize_optional_text(language)
        self._switches = _normalize_optional_text(switches)
        super().__init__(
            begin_line=_render_source_begin_line(self._language, self._switches),
            end_line="#+end_src",
            body=body,
            parent=parent,
        )

    @classmethod
    def from_node(
        cls,
        node: tree_sitter.Node,
        document: Document,
        *,
        parent: Document | Heading | Element | None = None,
    ) -> SourceBlock:
        """Create a [org_parser.element.SourceBlock][] from a ``src_block`` node."""
        source_text = node_source(node, document)
        parsed_language, parsed_switches = _extract_source_begin_data(source_text)
        block = cls(
            language=_extract_optional_field_text(node, document, "language") or parsed_language,
            switches=_extract_optional_field_text(node, document, "switches") or parsed_switches,
            body=_extract_optional_field_text(node, document, "body")
            or _extract_block_body_text(source_text),
            parent=parent,
        )
        block._node = node
        block._document = document
        _report_direct_block_parse_errors(node, document)
        return block

    @property
    def language(self) -> str | None:
        """Optional source language from begin line."""
        return self._language

    @language.setter
    def language(self, value: str | None) -> None:
        """Set source language."""
        self._language = _normalize_optional_text(value)
        self._begin_line = _render_source_begin_line(self._language, self._switches)
        self.mark_dirty()

    @property
    def switches(self) -> str | None:
        """Optional source block switches from begin line."""
        return self._switches

    @switches.setter
    def switches(self, value: str | None) -> None:
        """Set source switches."""
        self._switches = _normalize_optional_text(value)
        self._begin_line = _render_source_begin_line(self._language, self._switches)
        self.mark_dirty()

    def __repr__(self) -> str:
        """Return a semantic representation for debugging."""
        return build_semantic_repr(
            self.__class__.__name__,
            language=self._language,
            switches=self._switches,
            body=self._body,
        )


class FixedWidthBlock(Element):
    r"""Fixed-width area line with mutable content text.

    Example:
    ```python
    >>> from org_parser.element import FixedWidthBlock
    >>> b = FixedWidthBlock.from_source(": content\n")
    >>> b.body
    'content\n'
    ```
    """

    def __init__(
        self,
        *,
        body: str,
        parent: Document | Heading | Element | None = None,
    ) -> None:
        super().__init__(parent=parent)
        self._body = body

    @classmethod
    def from_node(
        cls,
        node: tree_sitter.Node,
        document: Document,
        *,
        parent: Document | Heading | Element | None = None,
    ) -> FixedWidthBlock:
        """Create a [org_parser.element.FixedWidthBlock][] from a ``fixed_width`` node."""
        block = cls(body=_extract_fixed_width_values(node, document), parent=parent)
        block._node = node
        block._document = document
        _report_direct_block_parse_errors(node, document)
        return block

    @property
    def body(self) -> str:
        """Mutable fixed-width content text without ``:`` prefixes."""
        return self._body

    @body.setter
    def body(self, value: str) -> None:
        """Set fixed-width content text."""
        self._body = value
        self.mark_dirty()

    def __str__(self) -> str:
        """Render fixed-width line preserving source while parse-backed and clean."""
        if not self.dirty and self._node is not None and self._document is not None:
            return node_source(self._node, self._document)

        lines = self._body.splitlines()
        if not lines:
            return ":\n"
        rendered = [":\n" if line == "" else f": {line}\n" for line in lines]
        return "".join(rendered)

    def __repr__(self) -> str:
        """Return a tree-oriented representation for debugging."""
        return build_semantic_repr("FixedWidthBlock", body=self._body)


def _report_direct_block_parse_errors(node: tree_sitter.Node, document: Document) -> None:
    """Report direct parse-error children on one block node.

    Truncated blocks often surface as one direct ``ERROR`` child anchored at
    the point where the end marker should appear.
    """
    for child in node.named_children:
        if is_error_node(child):
            document.report_error(child, _TRUNCATED_BLOCK_MESSAGE)


def _extract_container_contents(
    node: tree_sitter.Node,
    document: Document,
) -> list[Element]:
    """Extract nested body elements for container-style blocks.

    Elements are constructed with ``parent=None``; the containing
    [org_parser.element._block._ContainerBlock][] assigns the correct parent via
    [org_parser.element._block._ContainerBlock._adopt_body][] after construction.
    """
    elements = [
        _extract_nested_element(child, document, parent=None)
        for child in node.children_by_field_name("body")
        if child.is_named
    ]
    from org_parser.element._structure_recovery import attach_affiliated_keywords

    attach_affiliated_keywords(elements)
    return elements


def _extract_nested_element(
    node: tree_sitter.Node,
    document: Document,
    *,
    parent: Document | Heading | Element | None = None,
) -> Element:
    """Build one semantic element for nested block contents."""
    if node.type == INDENT:
        return _extract_indent(node, document, parent=parent)

    from org_parser.element._keyword import Keyword

    dispatch: dict[str, Callable[..., Element]] = {
        **body_element_factories(),
        SPECIAL_KEYWORD: Keyword.from_node,
    }
    factory = dispatch.get(node.type)
    if factory is None:
        return element_from_error_or_unknown(node, document, parent=parent)
    return factory(node, document, parent=parent)


def _extract_indent(
    node: tree_sitter.Node,
    document: Document,
    *,
    parent: Document | Heading | Element | None = None,
) -> Indent:
    """Build one nested [org_parser.element.Indent][] from an ``indent`` node."""
    return Indent.from_node(node, document, parent=parent, child_factory=_extract_nested_element)


def _extract_optional_field_text(
    node: tree_sitter.Node,
    document: Document,
    field_name: str,
) -> str | None:
    """Return text for one optional field node, if present."""
    field_node = node.child_by_field_name(field_name)
    if field_node is None:
        return None
    value = document.source_for(field_node).decode()
    return value if value != "" else None


def _extract_fixed_width_values(node: tree_sitter.Node, document: Document) -> str:
    """Return fixed-width body text extracted from ``value`` field nodes."""
    value_nodes = node.children_by_field_name("value")
    if not value_nodes:
        return ""

    lines: list[str] = []
    previous_row = node.start_point.row - 1
    for value_node in value_nodes:
        gap = value_node.start_point.row - previous_row - 1
        if gap > 0:
            lines.extend([""] * gap)
        lines.append(document.source_for(value_node).decode())
        previous_row = value_node.end_point.row

    trailing_gap = node.end_point.row - 1 - previous_row
    if trailing_gap > 0:
        lines.extend([""] * trailing_gap)

    return "\n".join(lines)


def _extract_block_body_text(source_text: str) -> str:
    """Return block body text between opening and closing delimiter lines."""
    lines = source_text.splitlines(keepends=True)
    if len(lines) <= 2:
        return ""
    return "".join(lines[1:-1])


def _extract_begin_parameters(source_text: str, prefix: str) -> str | None:
    """Return trailing begin-line parameters after one exact prefix."""
    line = _first_line(source_text)
    if not line.lower().startswith(prefix.lower()):
        return None
    tail = line[len(prefix) :].strip()
    return tail if tail != "" else None


def _extract_special_begin_data(source_text: str) -> tuple[str, str | None]:
    """Return ``(name, parameters)`` for one ``#+begin_<name>`` line."""
    line = _first_line(source_text).strip()
    lowered = line.lower()
    marker = "#+begin_"
    if not lowered.startswith(marker):
        return "", None
    tail = line[len(marker) :].strip()
    if tail == "":
        return "", None
    name, _, params = tail.partition(" ")
    normalized = params.strip()
    return name, (normalized if normalized != "" else None)


def _extract_dynamic_begin_data(source_text: str) -> tuple[str, str | None]:
    """Return ``(name, parameters)`` for one ``#+begin:`` dynamic line."""
    line = _first_line(source_text).strip()
    marker = "#+begin:"
    if not line.lower().startswith(marker):
        return "", None
    tail = line[len(marker) :].strip()
    if tail == "":
        return "", None
    name, _, params = tail.partition(" ")
    normalized = params.strip()
    return name, (normalized if normalized != "" else None)


def _extract_export_begin_data(source_text: str) -> tuple[str, str | None]:
    """Return ``(backend, parameters)`` for one export block begin line."""
    line = _first_line(source_text).strip()
    marker = "#+begin_export"
    if not line.lower().startswith(marker):
        return "", None
    tail = line[len(marker) :].strip()
    if tail == "":
        return "", None
    backend, _, params = tail.partition(" ")
    normalized = params.strip()
    return backend, (normalized if normalized != "" else None)


def _extract_source_begin_data(source_text: str) -> tuple[str | None, str | None]:
    """Return ``(language, switches)`` for one source block begin line."""
    line = _first_line(source_text).strip()
    marker = "#+begin_src"
    if not line.lower().startswith(marker):
        return None, None
    tail = line[len(marker) :].strip()
    if tail == "":
        return None, None
    language, _, switches = tail.partition(" ")
    normalized_switches = switches.strip()
    return language, (normalized_switches if normalized_switches != "" else None)


def _first_line(value: str) -> str:
    """Return the first line (without newline terminator) from text."""
    first, _, _ = value.partition("\n")
    return first


def _render_begin_line(name: str, parameters: str | None) -> str:
    """Return a canonical ``#+begin_<name>`` line."""
    if parameters is None:
        return f"#+begin_{name}"
    return f"#+begin_{name} {parameters}"


def _render_dynamic_begin_line(name: str, parameters: str | None) -> str:
    """Return a canonical ``#+begin:`` line for dynamic blocks."""
    base = f"#+begin: {name}" if name != "" else "#+begin:"
    if parameters is None:
        return base
    return f"{base} {parameters}".rstrip()


def _render_export_begin_line(backend: str, parameters: str | None) -> str:
    """Return a canonical ``#+begin_export`` line."""
    base = f"#+begin_export {backend}" if backend != "" else "#+begin_export"
    if parameters is None:
        return base
    return f"{base} {parameters}".rstrip()


def _render_source_begin_line(language: str | None, switches: str | None) -> str:
    """Return a canonical ``#+begin_src`` line."""
    if language is None:
        return "#+begin_src"
    if switches is None:
        return f"#+begin_src {language}"
    return f"#+begin_src {language} {switches}"


def _normalize_optional_text(value: str | None) -> str | None:
    """Return stripped text or ``None`` when empty."""
    if value is None:
        return None
    normalized = value.strip()
    if normalized == "":
        return None
    return normalized


def _ensure_single_trailing_newline(value: str) -> str:
    """Return text with exactly one trailing newline when non-empty."""
    if value == "":
        return ""
    return f"{value.rstrip(chr(10))}\n"
