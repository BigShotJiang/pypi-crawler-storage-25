

class RetreiveSequenceError(Exception):
	pass