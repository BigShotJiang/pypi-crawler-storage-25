"""
General-purpose static checks for supero-ui.js and supero-mobile.jsx.

This is the place to land "things we have learned the hard way" —
patterns that, if they regress, break apps in subtle ways.

Adding a new check: write a short method in either TestSuperoUiJs or
TestSuperoMobileJsx. Keep each check focused; if it gets large, factor
it out into a module-level function (see test_services_ui.py for the
pattern).
"""
from __future__ import annotations
import re
import unittest

# After flattening: this file lives in test/, helpers/fixtures live in test/ui/.
import os as _os
import sys as _sys
_sys.path.insert(0, _os.path.join(_os.path.dirname(_os.path.abspath(__file__)), 'ui'))

import _helpers as H


def _load_or_skip(testcls, kind):
    """kind = 'web' | 'mobile'. Loads source, raises SkipTest if missing."""
    web, mobile = H.resolve_ui_sources()
    path = web if kind == "web" else mobile
    if path is None:
        raise unittest.SkipTest(
            f"{kind} source file not found "
            f"(set SUPERO_UI_JS / SUPERO_MOBILE_JSX env vars)"
        )
    src = H.read_or_none(path)
    if src is None:
        raise unittest.SkipTest(f"{kind} source could not be read")
    return src, path


# ──────────────────────────────────────────────────────────────
# supero-ui.js (web)
# ──────────────────────────────────────────────────────────────

class TestSuperoUiJs(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        cls.src, cls.path = _load_or_skip(cls, "web")

    # ── load guards ──

    def test_react_load_guard_present(self):
        """File header guard prevents loading without React."""
        self.assertRegex(
            self.src,
            r"typeof\s+React\s*===\s*['\"]undefined['\"]",
            "Web UI must guard against missing React global",
        )

    # ── version metadata ──

    def test_version_global_is_set(self):
        """window.SUPERO_UI_VERSION is set to a semver-ish string."""
        m = re.search(
            r'window\.SUPERO_UI_VERSION\s*=\s*[\'"]([^\'"]+)[\'"]',
            self.src,
        )
        self.assertIsNotNone(
            m, "window.SUPERO_UI_VERSION assignment not found")
        self.assertRegex(
            m.group(1), r'^\d+\.\d+\.\d+',
            "SUPERO_UI_VERSION should look like a semver",
        )

    # ── config plumbing ──

    def test_supero_config_pulled_from_window(self):
        """SUPERO_CONFIG reads from window.__SUPERO_CONFIG (the run.sh contract)."""
        self.assertIn("window.__SUPERO_CONFIG", self.src)

    # ── forbidden patterns ──

    def test_no_eval_calls(self):
        """eval() is forbidden — encourages XSS sinks."""
        # Use strip_code_only so console.warn("avoid eval()") doesn't fire.
        code = H.strip_code_only(self.src)
        # Permit `evaluate(`, `evaluator`, etc. — only flag bare eval(.
        self.assertNotRegex(
            code, r'(^|[^A-Za-z_$])eval\s*\(',
            "eval() call found in supero-ui.js",
        )

    def test_no_document_write(self):
        """document.write breaks SPAs and is never the right tool."""
        self.assertNotIn(
            "document.write", H.strip_code_only(self.src),
            "document.write found in supero-ui.js",
        )


# ──────────────────────────────────────────────────────────────
# supero-mobile.jsx (React Native / Expo)
# ──────────────────────────────────────────────────────────────

class TestSuperoMobileJsx(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        cls.src, cls.path = _load_or_skip(cls, "mobile")

    # ── version metadata ──

    def test_mobile_version_constant_set(self):
        """SUPERO_MOBILE_VERSION constant is set to a semver-ish string."""
        m = re.search(
            r"SUPERO_MOBILE_VERSION\s*=\s*['\"]([^'\"]+)['\"]",
            self.src,
        )
        self.assertIsNotNone(
            m, "SUPERO_MOBILE_VERSION assignment not found")
        self.assertRegex(m.group(1), r'^\d+\.\d+\.\d+')

    # ── forbidden imports / APIs (lessons learned) ──
    #
    # These come from the file's own header comments — they are
    # explicitly NOT-DOs that have caused production crashes.

    def test_no_expo_secure_store(self):
        """expo-secure-store triggers a TurboModule crash on the new
        architecture. Header comment in the file warns about this."""
        # strip_code_only so the header warning comment doesn't fire.
        code = H.strip_code_only(self.src)
        self.assertNotIn(
            "expo-secure-store", code,
            "expo-secure-store import found — will crash on new architecture",
        )

    def test_no_react_native_picker(self):
        """@react-native-picker/picker is not in Expo SDK 54."""
        code = H.strip_code_only(self.src)
        self.assertNotIn(
            "@react-native-picker/picker", code,
            "@react-native-picker/picker import found — not in Expo SDK 54",
        )

    def test_no_streaming_fetch(self):
        """RN fetch can't stream — header comment forbids stream:true."""
        # Use strip_code_only so the header comment warning doesn't fire,
        # and a string mentioning stream:true wouldn't either.
        code = H.strip_code_only(self.src)
        self.assertNotRegex(
            code,
            r"stream\s*:\s*true",
            "stream:true found in mobile fetch — RN fetch can't stream",
        )

    def test_no_localstorage(self):
        """localStorage doesn't exist in React Native."""
        code = H.strip_code_only(self.src)
        self.assertNotIn(
            "localStorage", code,
            "localStorage reference found — doesn't exist in RN",
        )

    # ── crash reporter sanity ──

    def test_crash_reporter_installed_before_imports(self):
        """The self-installing crash reporter must run at top level."""
        self.assertIn(
            "_installSuperoCrashReporter",
            self.src,
            "crash reporter IIFE not found",
        )

    def test_crash_reporter_kill_switch_documented(self):
        """The disabled env var exists and is honored."""
        self.assertIn(
            "EXPO_PUBLIC_SUPERO_CRASH_DISABLED",
            self.src,
            "crash reporter kill switch not found",
        )


# ──────────────────────────────────────────────────────────────
# Cross-file consistency
# ──────────────────────────────────────────────────────────────

class TestUiCrossFileConsistency(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        web, mobile = H.resolve_ui_sources()
        if web is None or mobile is None:
            raise unittest.SkipTest(
                "one or both UI source files not found")
        cls.web = H.read_or_none(web)
        cls.mobile = H.read_or_none(mobile)

    def test_both_files_export_setconfig_or_have_config_global(self):
        """Both platforms must expose a way to set domain/project/api_url."""
        web_has = (
            "window.__SUPERO_CONFIG" in self.web
            or re.search(r"function\s+setConfig\s*\(", self.web)
        )
        mobile_has = bool(
            re.search(r"export\s+(const|function)\s+setConfig", self.mobile)
            or re.search(r"function\s+setConfig\s*\(", self.mobile)
        )
        self.assertTrue(web_has, "web UI has no config injection point")
        self.assertTrue(mobile_has, "mobile UI has no setConfig export")


if __name__ == "__main__":
    unittest.main()
