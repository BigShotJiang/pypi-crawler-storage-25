"""
test_cli_run_app_meta.py — tests for _read_app_meta.

_read_app_meta orchestrates:
  1. Branding extraction from config.py (name/emoji/description)
  2. PUBLIC_SCHEMAS extraction from schemas.py via _extract_public_schemas_ast
  3. Sanity check: warn if app.js has stale publicSchemas array

Returns dict: {"name": str, "emoji": str, "description": str,
               "public_schemas": list[str]}

These tests use real filesystem fixtures (tmpdir + tearDown) instead
of mocks because the function reads multiple files and the interactions
between them are part of the contract.
"""

import io
import os
import importlib
import tempfile
import unittest
from contextlib import redirect_stdout


def _get_run_module():
    """Return the supero.cli.run MODULE (avoids package attribute shadowing)."""
    return importlib.import_module('supero.cli.run')


def _write(path, content):
    """Write content to a file, creating parent dirs as needed."""
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        f.write(content)


class TestReadAppMetaBranding(unittest.TestCase):
    """Branding extraction from config.py."""

    def setUp(self):
        self.run_module = _get_run_module()
        self.tmpdir = tempfile.mkdtemp(prefix="supero-meta-branding-")

    def tearDown(self):
        import shutil
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_extracts_app_name(self):
        """app_name = 'Family Hub' is extracted into result['name']."""
        _write(
            os.path.join(self.tmpdir, "config.py"),
            'app_name = "Family Hub"\n'
        )
        with redirect_stdout(io.StringIO()):
            meta = self.run_module._read_app_meta(self.tmpdir)
        self.assertEqual(meta["name"], "Family Hub")

    def test_extracts_display_name_as_name(self):
        """display_name also populates result['name'] (synonym)."""
        _write(
            os.path.join(self.tmpdir, "config.py"),
            'display_name = "Family Hub"\n'
        )
        with redirect_stdout(io.StringIO()):
            meta = self.run_module._read_app_meta(self.tmpdir)
        self.assertEqual(meta["name"], "Family Hub")

    def test_extracts_emoji(self):
        """app_emoji = '🏠' is extracted into result['emoji']."""
        _write(
            os.path.join(self.tmpdir, "config.py"),
            'app_emoji = "\U0001F3E0"\n'
        )
        with redirect_stdout(io.StringIO()):
            meta = self.run_module._read_app_meta(self.tmpdir)
        self.assertEqual(meta["emoji"], "\U0001F3E0")

    def test_extracts_description(self):
        """app_description is extracted into result['description']."""
        _write(
            os.path.join(self.tmpdir, "config.py"),
            'app_description = "Manage your family"\n'
        )
        with redirect_stdout(io.StringIO()):
            meta = self.run_module._read_app_meta(self.tmpdir)
        self.assertEqual(meta["description"], "Manage your family")

    def test_missing_config_returns_empty_branding(self):
        """No config.py → empty branding fields, no exception."""
        with redirect_stdout(io.StringIO()):
            meta = self.run_module._read_app_meta(self.tmpdir)
        self.assertEqual(meta["name"], "")
        self.assertEqual(meta["emoji"], "")
        self.assertEqual(meta["description"], "")
        self.assertEqual(meta["public_schemas"], [])

    def test_first_match_wins_for_name(self):
        """If both app_name and display_name exist, the first set wins."""
        _write(
            os.path.join(self.tmpdir, "config.py"),
            'app_name = "First Name"\n'
            'display_name = "Second Name"\n'
        )
        with redirect_stdout(io.StringIO()):
            meta = self.run_module._read_app_meta(self.tmpdir)
        # The implementation uses "if not result[key]" so first wins
        self.assertEqual(meta["name"], "First Name")

    def test_comments_ignored(self):
        """Lines starting with # are ignored."""
        _write(
            os.path.join(self.tmpdir, "config.py"),
            '# app_name = "Wrong"\n'
            'app_name = "Right"\n'
        )
        with redirect_stdout(io.StringIO()):
            meta = self.run_module._read_app_meta(self.tmpdir)
        self.assertEqual(meta["name"], "Right")


class TestReadAppMetaPublicSchemas(unittest.TestCase):
    """PUBLIC_SCHEMAS extraction via _extract_public_schemas_ast."""

    def setUp(self):
        self.run_module = _get_run_module()
        self.tmpdir = tempfile.mkdtemp(prefix="supero-meta-public-")

    def tearDown(self):
        import shutil
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_extracts_public_schemas_when_defined(self):
        """schemas.py with PUBLIC_SCHEMAS list → result['public_schemas']."""
        _write(
            os.path.join(self.tmpdir, "schemas.py"),
            'PUBLIC_SCHEMAS = ["event", "news_post"]\n'
        )
        with redirect_stdout(io.StringIO()):
            meta = self.run_module._read_app_meta(self.tmpdir)
        self.assertEqual(meta["public_schemas"], ["event", "news_post"])

    def test_empty_public_schemas_list_is_respected(self):
        """schemas.py with PUBLIC_SCHEMAS = [] → empty list, not default."""
        _write(
            os.path.join(self.tmpdir, "schemas.py"),
            'PUBLIC_SCHEMAS = []\n'
        )
        with redirect_stdout(io.StringIO()):
            meta = self.run_module._read_app_meta(self.tmpdir)
        self.assertEqual(meta["public_schemas"], [])

    def test_missing_schemas_py_returns_empty(self):
        """No schemas.py → empty public_schemas, no crash."""
        with redirect_stdout(io.StringIO()):
            meta = self.run_module._read_app_meta(self.tmpdir)
        self.assertEqual(meta["public_schemas"], [])

    def test_not_defined_warning_is_printed(self):
        """schemas.py without PUBLIC_SCHEMAS → warning printed to stdout."""
        _write(
            os.path.join(self.tmpdir, "schemas.py"),
            'ALL_SCHEMAS = []\n'
        )
        buf = io.StringIO()
        with redirect_stdout(buf):
            meta = self.run_module._read_app_meta(self.tmpdir)
        output = buf.getvalue()
        self.assertEqual(meta["public_schemas"], [])
        self.assertIn("PUBLIC_SCHEMAS", output)
        self.assertIn("not defined", output)

    def test_parse_error_warning_is_printed(self):
        """schemas.py with syntax error → warning, not exception."""
        _write(
            os.path.join(self.tmpdir, "schemas.py"),
            'PUBLIC_SCHEMAS = ["event"\n'  # missing closing bracket
        )
        buf = io.StringIO()
        with redirect_stdout(buf):
            meta = self.run_module._read_app_meta(self.tmpdir)
        output = buf.getvalue()
        self.assertEqual(meta["public_schemas"], [])
        self.assertIn("syntax error", output)

    def test_non_literal_warning_is_printed(self):
        """schemas.py with non-literal PUBLIC_SCHEMAS → warning."""
        _write(
            os.path.join(self.tmpdir, "schemas.py"),
            'PUBLIC_SCHEMAS = some_function()\n'
        )
        buf = io.StringIO()
        with redirect_stdout(buf):
            meta = self.run_module._read_app_meta(self.tmpdir)
        output = buf.getvalue()
        self.assertEqual(meta["public_schemas"], [])
        self.assertIn("Cannot statically extract", output)


class TestReadAppMetaAppJsWarning(unittest.TestCase):
    """Sanity check: warn when app.js has a stale publicSchemas array."""

    def setUp(self):
        self.run_module = _get_run_module()
        self.tmpdir = tempfile.mkdtemp(prefix="supero-meta-appjs-")

    def tearDown(self):
        import shutil
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_no_warning_when_app_js_missing(self):
        """If app.js doesn't exist, no warning is emitted."""
        _write(
            os.path.join(self.tmpdir, "schemas.py"),
            'PUBLIC_SCHEMAS = ["event"]\n'
        )
        buf = io.StringIO()
        with redirect_stdout(buf):
            self.run_module._read_app_meta(self.tmpdir)
        self.assertNotIn("stale publicSchemas", buf.getvalue())

    def test_no_warning_when_app_js_agrees(self):
        """If app.js publicSchemas matches schemas.py, no warning."""
        _write(
            os.path.join(self.tmpdir, "schemas.py"),
            'PUBLIC_SCHEMAS = ["event", "news_post"]\n'
        )
        _write(
            os.path.join(self.tmpdir, "ui", "app.js"),
            'const cfg = {publicSchemas: ["event", "news_post"]};\n'
        )
        buf = io.StringIO()
        with redirect_stdout(buf):
            self.run_module._read_app_meta(self.tmpdir)
        self.assertNotIn("stale publicSchemas", buf.getvalue())

    def test_warning_when_app_js_disagrees(self):
        """If app.js has DIFFERENT publicSchemas, warning is printed."""
        _write(
            os.path.join(self.tmpdir, "schemas.py"),
            'PUBLIC_SCHEMAS = ["event"]\n'
        )
        _write(
            os.path.join(self.tmpdir, "ui", "app.js"),
            'const cfg = {publicSchemas: ["old_schema"]};\n'
        )
        buf = io.StringIO()
        with redirect_stdout(buf):
            meta = self.run_module._read_app_meta(self.tmpdir)
        output = buf.getvalue()
        self.assertIn("stale publicSchemas", output)
        # schemas.py value still wins
        self.assertEqual(meta["public_schemas"], ["event"])

    def test_app_js_at_root_also_checked(self):
        """app.js at root (not just ui/app.js) is also checked."""
        _write(
            os.path.join(self.tmpdir, "schemas.py"),
            'PUBLIC_SCHEMAS = ["new_schema"]\n'
        )
        _write(
            os.path.join(self.tmpdir, "app.js"),
            'const cfg = {publicSchemas: ["old_schema"]};\n'
        )
        buf = io.StringIO()
        with redirect_stdout(buf):
            self.run_module._read_app_meta(self.tmpdir)
        self.assertIn("stale publicSchemas", buf.getvalue())


class TestReadAppMetaReturnShape(unittest.TestCase):
    """Verify the return value always has the expected shape."""

    def setUp(self):
        self.run_module = _get_run_module()
        self.tmpdir = tempfile.mkdtemp(prefix="supero-meta-shape-")

    def tearDown(self):
        import shutil
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_always_returns_dict_with_four_keys(self):
        """Result always has name, emoji, description, public_schemas."""
        with redirect_stdout(io.StringIO()):
            meta = self.run_module._read_app_meta(self.tmpdir)
        self.assertIsInstance(meta, dict)
        self.assertIn("name", meta)
        self.assertIn("emoji", meta)
        self.assertIn("description", meta)
        self.assertIn("public_schemas", meta)

    def test_public_schemas_is_always_a_list(self):
        """result['public_schemas'] is always a list, never None."""
        with redirect_stdout(io.StringIO()):
            meta = self.run_module._read_app_meta(self.tmpdir)
        self.assertIsInstance(meta["public_schemas"], list)


if __name__ == "__main__":
    unittest.main()
