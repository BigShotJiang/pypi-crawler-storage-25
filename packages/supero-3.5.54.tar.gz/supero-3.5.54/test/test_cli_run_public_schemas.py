"""
test_cli_run_public_schemas.py — tests for _extract_public_schemas_ast.

Tests the AST-based static extractor that reads PUBLIC_SCHEMAS from a
schemas.py file without executing it. The function returns a 3-tuple:

    (status, value, error)

Status codes:
    'defined'      — PUBLIC_SCHEMAS = [...] or (...) found, value populated
    'not_defined'  — PUBLIC_SCHEMAS not in file at all
    'non_literal'  — PUBLIC_SCHEMAS = some_function() — can't extract
    'parse_error'  — schemas.py has a syntax error
    'io_error'     — couldn't read the file

This function is the integration point for the snake_case seed fix:
the values it returns become the publicSchemas array in config.js,
which the frontend uses to determine which schemas have public
landing pages. Wrong output → broken landing pages or platform 404s.
"""

import os
import importlib
import tempfile
import unittest


def _get_run_module():
    """Return the supero.cli.run MODULE (avoids package attribute shadowing)."""
    return importlib.import_module('supero.cli.run')


def _write_schemas_py(tmpdir, content):
    """Write a schemas.py file in tmpdir and return its path."""
    path = os.path.join(tmpdir, "schemas.py")
    with open(path, "w", encoding="utf-8") as f:
        f.write(content)
    return path


# ═══════════════════════════════════════════════════════════════
# Status code: 'defined' — PUBLIC_SCHEMAS is a literal list/tuple
# ═══════════════════════════════════════════════════════════════

class TestExtractDefined(unittest.TestCase):
    """Status='defined' — valid literal list/tuple of strings."""

    def setUp(self):
        self.run_module = _get_run_module()
        self.tmpdir = tempfile.mkdtemp(prefix="supero-public-schemas-")

    def tearDown(self):
        import shutil
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_simple_list_of_strings(self):
        """PUBLIC_SCHEMAS = ['event', 'news_post'] is extracted."""
        path = _write_schemas_py(
            self.tmpdir,
            'PUBLIC_SCHEMAS = ["event", "news_post"]\n'
        )
        status, value, error = self.run_module._extract_public_schemas_ast(path)
        self.assertEqual(status, 'defined')
        self.assertEqual(value, ['event', 'news_post'])
        self.assertIsNone(error)

    def test_tuple_also_accepted(self):
        """PUBLIC_SCHEMAS = ('event', 'news_post') works (tuple, not list)."""
        path = _write_schemas_py(
            self.tmpdir,
            'PUBLIC_SCHEMAS = ("event", "news_post")\n'
        )
        status, value, error = self.run_module._extract_public_schemas_ast(path)
        self.assertEqual(status, 'defined')
        self.assertEqual(value, ['event', 'news_post'])

    def test_empty_list_is_defined(self):
        """PUBLIC_SCHEMAS = [] is a valid explicit private declaration."""
        path = _write_schemas_py(self.tmpdir, 'PUBLIC_SCHEMAS = []\n')
        status, value, error = self.run_module._extract_public_schemas_ast(path)
        self.assertEqual(status, 'defined')
        self.assertEqual(value, [])
        self.assertIsNone(error)

    def test_single_element(self):
        """PUBLIC_SCHEMAS = ['event'] returns ['event']."""
        path = _write_schemas_py(self.tmpdir, 'PUBLIC_SCHEMAS = ["event"]\n')
        status, value, error = self.run_module._extract_public_schemas_ast(path)
        self.assertEqual(status, 'defined')
        self.assertEqual(value, ['event'])

    def test_snake_case_names_preserved(self):
        """Snake_case names are returned unchanged (the canonical form)."""
        path = _write_schemas_py(
            self.tmpdir,
            'PUBLIC_SCHEMAS = ["family_member", "menu_item", "news_post"]\n'
        )
        status, value, _ = self.run_module._extract_public_schemas_ast(path)
        self.assertEqual(status, 'defined')
        self.assertEqual(value, ['family_member', 'menu_item', 'news_post'])

    def test_extracted_only_from_top_level(self):
        """A PUBLIC_SCHEMAS inside a function is ignored; top-level wins."""
        path = _write_schemas_py(self.tmpdir, """
def helper():
    PUBLIC_SCHEMAS = ["wrong"]  # local — should be ignored
    return PUBLIC_SCHEMAS

PUBLIC_SCHEMAS = ["correct"]
""".lstrip())
        status, value, _ = self.run_module._extract_public_schemas_ast(path)
        self.assertEqual(status, 'defined')
        self.assertEqual(value, ['correct'])

    def test_other_code_in_file_does_not_interfere(self):
        """File with imports, ALL_SCHEMAS, etc. still parses correctly."""
        path = _write_schemas_py(self.tmpdir, """
import json
from typing import List

ALL_SCHEMAS = [
    {"name": "Event", "schema_type": "object"},
    {"name": "NewsPost", "schema_type": "object"},
]

PUBLIC_SCHEMAS = ["event", "news_post"]

def get_schemas():
    return ALL_SCHEMAS
""".lstrip())
        status, value, _ = self.run_module._extract_public_schemas_ast(path)
        self.assertEqual(status, 'defined')
        self.assertEqual(value, ['event', 'news_post'])

    def test_does_not_execute_module(self):
        """File with import-time side effects must NOT be executed."""
        marker = os.path.join(self.tmpdir, "executed.marker")
        path = _write_schemas_py(self.tmpdir, f"""
# If this file is executed, the marker file is created.
# The AST walker must NOT execute it.
import os
with open({marker!r}, "w") as f:
    f.write("EXECUTED")

PUBLIC_SCHEMAS = ["event"]
""".lstrip())
        status, value, _ = self.run_module._extract_public_schemas_ast(path)
        self.assertEqual(status, 'defined')
        self.assertEqual(value, ['event'])
        self.assertFalse(
            os.path.exists(marker),
            "schemas.py was executed — AST walker should NOT exec it"
        )


# ═══════════════════════════════════════════════════════════════
# Status code: 'not_defined' — no PUBLIC_SCHEMAS variable
# ═══════════════════════════════════════════════════════════════

class TestExtractNotDefined(unittest.TestCase):
    """Status='not_defined' — file is valid but has no PUBLIC_SCHEMAS."""

    def setUp(self):
        self.run_module = _get_run_module()
        self.tmpdir = tempfile.mkdtemp(prefix="supero-not-defined-")

    def tearDown(self):
        import shutil
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_empty_file(self):
        """Empty schemas.py → not_defined."""
        path = _write_schemas_py(self.tmpdir, "")
        status, value, error = self.run_module._extract_public_schemas_ast(path)
        self.assertEqual(status, 'not_defined')
        self.assertEqual(value, [])
        self.assertIsNone(error)

    def test_file_with_only_imports(self):
        """schemas.py with imports but no PUBLIC_SCHEMAS → not_defined."""
        path = _write_schemas_py(
            self.tmpdir,
            "import json\nfrom typing import List\n"
        )
        status, value, _ = self.run_module._extract_public_schemas_ast(path)
        self.assertEqual(status, 'not_defined')

    def test_file_with_other_variables(self):
        """schemas.py with ALL_SCHEMAS but no PUBLIC_SCHEMAS → not_defined."""
        path = _write_schemas_py(
            self.tmpdir,
            'ALL_SCHEMAS = [{"name": "Event"}]\n'
        )
        status, value, _ = self.run_module._extract_public_schemas_ast(path)
        self.assertEqual(status, 'not_defined')


# ═══════════════════════════════════════════════════════════════
# Status code: 'non_literal' — can't extract statically
# ═══════════════════════════════════════════════════════════════

class TestExtractNonLiteral(unittest.TestCase):
    """Status='non_literal' — PUBLIC_SCHEMAS exists but isn't a literal."""

    def setUp(self):
        self.run_module = _get_run_module()
        self.tmpdir = tempfile.mkdtemp(prefix="supero-non-literal-")

    def tearDown(self):
        import shutil
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_function_call_value(self):
        """PUBLIC_SCHEMAS = get_schemas() → non_literal."""
        path = _write_schemas_py(
            self.tmpdir,
            "def get_schemas():\n    return ['event']\n\n"
            "PUBLIC_SCHEMAS = get_schemas()\n"
        )
        status, value, error = self.run_module._extract_public_schemas_ast(path)
        self.assertEqual(status, 'non_literal')
        self.assertEqual(value, [])
        self.assertIsNotNone(error)

    def test_variable_reference_value(self):
        """PUBLIC_SCHEMAS = some_other_var → non_literal."""
        path = _write_schemas_py(
            self.tmpdir,
            'OTHER = ["event"]\nPUBLIC_SCHEMAS = OTHER\n'
        )
        status, _, _ = self.run_module._extract_public_schemas_ast(path)
        self.assertEqual(status, 'non_literal')

    def test_list_with_function_call_element(self):
        """PUBLIC_SCHEMAS = [to_url_name('Event')] → defined, value=['event'].

        The AST walker now handles to_url_name() calls by computing
        snake_case statically — no import needed.
        """
        path = _write_schemas_py(
            self.tmpdir,
            'PUBLIC_SCHEMAS = [to_url_name("Event")]\n'
        )
        status, value, err = self.run_module._extract_public_schemas_ast(path)
        self.assertEqual(status, 'defined')
        self.assertEqual(value, ['event'])

    def test_list_with_none_element(self):
        """PUBLIC_SCHEMAS = ['event', None] → non_literal."""
        path = _write_schemas_py(
            self.tmpdir, 'PUBLIC_SCHEMAS = ["event", None]\n'
        )
        status, _, _ = self.run_module._extract_public_schemas_ast(path)
        self.assertEqual(status, 'non_literal')

    def test_dict_value(self):
        """PUBLIC_SCHEMAS = {'a': 1} → non_literal (not list/tuple)."""
        path = _write_schemas_py(
            self.tmpdir, 'PUBLIC_SCHEMAS = {"a": 1}\n'
        )
        status, _, error = self.run_module._extract_public_schemas_ast(path)
        self.assertEqual(status, 'non_literal')
        self.assertIn("not a literal list/tuple", error or "")

    def test_string_value(self):
        """PUBLIC_SCHEMAS = 'event' → non_literal (string is not a list)."""
        path = _write_schemas_py(
            self.tmpdir, 'PUBLIC_SCHEMAS = "event"\n'
        )
        status, _, _ = self.run_module._extract_public_schemas_ast(path)
        self.assertEqual(status, 'non_literal')

    def test_list_comprehension_value(self):
        """PUBLIC_SCHEMAS = [s for s in NAMES] → non_literal."""
        path = _write_schemas_py(
            self.tmpdir,
            'NAMES = ["event"]\nPUBLIC_SCHEMAS = [s for s in NAMES]\n'
        )
        status, _, _ = self.run_module._extract_public_schemas_ast(path)
        self.assertEqual(status, 'non_literal')


# ═══════════════════════════════════════════════════════════════
# Status code: 'parse_error' — schemas.py has invalid Python
# ═══════════════════════════════════════════════════════════════

class TestExtractParseError(unittest.TestCase):
    """Status='parse_error' — schemas.py has a syntax error."""

    def setUp(self):
        self.run_module = _get_run_module()
        self.tmpdir = tempfile.mkdtemp(prefix="supero-parse-error-")

    def tearDown(self):
        import shutil
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_unclosed_bracket(self):
        """PUBLIC_SCHEMAS = ["event" (no closing bracket) → parse_error."""
        path = _write_schemas_py(
            self.tmpdir, 'PUBLIC_SCHEMAS = ["event"\n'
        )
        status, value, error = self.run_module._extract_public_schemas_ast(path)
        self.assertEqual(status, 'parse_error')
        self.assertEqual(value, [])
        self.assertIsNotNone(error)
        self.assertIn("line", error)

    def test_invalid_indent(self):
        """File with invalid indentation → parse_error."""
        path = _write_schemas_py(
            self.tmpdir,
            'def foo():\nreturn 1\n'
        )
        status, _, error = self.run_module._extract_public_schemas_ast(path)
        self.assertEqual(status, 'parse_error')
        self.assertIn("line", error)


# ═══════════════════════════════════════════════════════════════
# Status code: 'io_error' — file unreadable
# ═══════════════════════════════════════════════════════════════

class TestExtractIoError(unittest.TestCase):
    """Status='io_error' — file can't be read."""

    def setUp(self):
        self.run_module = _get_run_module()

    def test_nonexistent_file(self):
        """schemas.py at a path that doesn't exist → io_error."""
        status, value, error = self.run_module._extract_public_schemas_ast(
            "/nonexistent/path/schemas.py"
        )
        self.assertEqual(status, 'io_error')
        self.assertEqual(value, [])
        self.assertIsNotNone(error)

    def test_directory_instead_of_file(self):
        """Path is a directory, not a file → io_error."""
        tmpdir = tempfile.mkdtemp(prefix="supero-io-error-")
        try:
            status, _, error = self.run_module._extract_public_schemas_ast(tmpdir)
            self.assertEqual(status, 'io_error')
            self.assertIsNotNone(error)
        finally:
            import shutil
            shutil.rmtree(tmpdir, ignore_errors=True)


# ═══════════════════════════════════════════════════════════════
# Return value contract — always (status, value, error)
# ═══════════════════════════════════════════════════════════════

class TestExtractReturnContract(unittest.TestCase):
    """Verify the function ALWAYS returns a 3-tuple with the right shapes."""

    def setUp(self):
        self.run_module = _get_run_module()
        self.tmpdir = tempfile.mkdtemp(prefix="supero-contract-")

    def tearDown(self):
        import shutil
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_always_returns_three_tuple(self):
        """Every status returns exactly (status, list, str-or-None)."""
        cases = [
            'PUBLIC_SCHEMAS = ["event"]\n',
            "",
            "PUBLIC_SCHEMAS = get_it()\n",
            'PUBLIC_SCHEMAS = ["event"\n',
        ]
        for src in cases:
            path = _write_schemas_py(self.tmpdir, src)
            result = self.run_module._extract_public_schemas_ast(path)
            self.assertEqual(len(result), 3, f"Wrong tuple shape for: {src!r}")
            status, value, error = result
            self.assertIn(status, ('defined', 'not_defined', 'non_literal',
                                    'parse_error', 'io_error'))
            self.assertIsInstance(value, list)
            self.assertTrue(error is None or isinstance(error, str))

    def test_value_is_empty_list_when_not_defined(self):
        """Status 'not_defined' returns [] not None."""
        path = _write_schemas_py(self.tmpdir, "")
        _, value, _ = self.run_module._extract_public_schemas_ast(path)
        self.assertEqual(value, [])
        self.assertIsInstance(value, list)


if __name__ == "__main__":
    unittest.main()
