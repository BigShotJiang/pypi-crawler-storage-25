# Add this to the very top of your test_client_ut.py file, before any other imports

import sys
import os
import unittest
import json
from pathlib import Path
from unittest.mock import patch, call, MagicMock, Mock

# Setup paths
test_dir = Path(__file__).parent
project_root = test_dir.parent
src_dir = project_root / "src"
utils_dir = project_root / ".." / ".." / ".." / "utils"

for path in [str(src_dir), str(project_root), str(utils_dir)]:
    if path not in sys.path:
        sys.path.insert(0, path)

# Set test environment
os.environ["TESTING"] = "true"

def setup_test_mocks():
    """Setup mocks for missing dependencies."""
    try:
        import pymodel
        import pymodel.objects
        import pymodel.serialization_errors
    except ImportError:
        pymodel_mock = MagicMock()
        pymodel_objects_mock = MagicMock()
        pymodel_serialization_mock = MagicMock()

        # Mock functions
        pymodel_serialization_mock.safe_serialize_to_dict = lambda obj, obj_type=None: {}
        pymodel_serialization_mock.safe_serialize_to_json = lambda obj, obj_type=None: '{}'
        pymodel_serialization_mock.safe_deserialize_from_dict = lambda data, cls, obj_type=None: MagicMock()

        # Create custom exception classes (not base Exception!)
        class SerializationError(Exception):
            pass
        class ObjectSerializationError(SerializationError):
            pass
        class ObjectDeserializationError(SerializationError):
            pass
        class JSONSerializationError(SerializationError):
            pass
        class JSONDeserializationError(SerializationError):
            pass

        pymodel_serialization_mock.SerializationError = SerializationError
        pymodel_serialization_mock.ObjectSerializationError = ObjectSerializationError
        pymodel_serialization_mock.ObjectDeserializationError = ObjectDeserializationError
        pymodel_serialization_mock.JSONSerializationError = JSONSerializationError
        pymodel_serialization_mock.JSONDeserializationError = JSONDeserializationError

        pymodel_mock.objects = pymodel_objects_mock
        pymodel_mock.serialization_errors = pymodel_serialization_mock

        sys.modules['pymodel'] = pymodel_mock
        sys.modules['pymodel.objects'] = pymodel_objects_mock
        sys.modules['pymodel.serialization_errors'] = pymodel_serialization_mock

    # Mock api_logger if not available
    try:
        from py_api_lib import api_logger
        api_logger.initialize_logger("test-py-api-lib")
    except ImportError:
        api_logger_mock = MagicMock()
        sys.modules['py_api_lib.api_logger'] = api_logger_mock

# Apply mocks
setup_test_mocks()

# Now import py_api_lib with correct paths
from py_api_lib.api_lib import ApiLib
from py_api_lib.api_client import ApiClient
from py_api_lib import api_lib
from py_api_lib import api_client


class TestApiLibBasic(unittest.TestCase):
    """Basic tests for ApiLib functionality."""
    
    def setUp(self):
        """Set up test fixtures."""
        with patch('py_api_lib.api_lib.ApiClient') as mock_client_class:
            self.mock_api_client = Mock()
            mock_client_class.return_value = self.mock_api_client
            self.api_lib = ApiLib(api_server_host='localhost', api_server_port='8082')
    
    def test_api_lib_creation(self):
        """Test that ApiLib can be created."""
        self.assertIsNotNone(self.api_lib)
        self.assertEqual(self.api_lib.api_client, self.mock_api_client)
    
    def test_api_client_import(self):
        """Test that ApiClient can be imported."""
        self.assertTrue(hasattr(ApiClient, '__init__'))


class TestApiClientInit(unittest.TestCase):
    """Test ApiClient initialization and basic functionality."""
    
    def setUp(self):
        """Set up test fixtures."""
        self.mock_session = Mock()
        
    @patch('py_api_lib.api_client.requests.Session')
    def test_api_client_creation(self, mock_session_class):
        """Test ApiClient can be created with basic parameters."""
        mock_session_class.return_value = self.mock_session
        
        # Use correct constructor parameters from actual ApiClient implementation
        client = ApiClient(server_ip='localhost', port=8082)
        
        self.assertIsNotNone(client)
        self.assertTrue(client.base_url.endswith('localhost:8082'))
        self.assertEqual(client.timeout, 30)  # default timeout


class TestApiClientHTTPOperations(unittest.TestCase):
    """Test ApiClient HTTP operation methods."""
    
    def setUp(self):
        """Set up test fixtures."""
        with patch('py_api_lib.api_client.requests.Session'):
            self.client = ApiClient(server_ip='localhost', port=8082)
            self.client.session = Mock()

    def test_http_query_success(self):
        """Test successful HTTP query operation."""
        # Mock response
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "results": [
                {"id": "sub-class-1", "name": "Restaurant", "count": 25},
                {"id": "sub-class-2", "name": "Retail", "count": 18}
            ],
            "total_count": 43
        }
        
        # Mock the _make_request method
        self.client._make_request = Mock(return_value=mock_response)
        
        # Test query payload
        json_data = '{"op": "find-sub-classes", "lon": -122.4194, "lat": 37.7749}'
        
        # Call query
        result = self.client._http_query(json_data)
        
        # Verify result
        expected_result = {
            "results": [
                {"id": "sub-class-1", "name": "Restaurant", "count": 25},
                {"id": "sub-class-2", "name": "Retail", "count": 18}
            ],
            "total_count": 43
        }
        self.assertEqual(result, expected_result)
        
        # ✅ FIX: Updated to expect domain in URL path AND api_key parameter
        self.client._make_request.assert_called_once_with(
            'POST', 
            f"{self.client.base_url}/default-domain/query",
            api_key=None,  # ✅ FIXED: Added api_key parameter
            json={"op": "find-sub-classes", "lon": -122.4194, "lat": 37.7749}
        )

    def test_http_query_invalid_json(self):
        """Test HTTP query with invalid JSON data."""
        # Invalid JSON string
        invalid_json = '{"op": "find-sub-classes", "lon": -122.4194, "lat":'  # Missing closing
        
        # Should raise ValueError for invalid JSON
        with self.assertRaises(ValueError) as context:
            self.client._http_query(invalid_json)
        
        self.assertIn("Invalid JSON data", str(context.exception))

    def test_http_query_server_error(self):
        """Test HTTP query with server error response."""
        # Mock error response
        mock_response = Mock()
        mock_response.status_code = 500
        mock_response.text = "Internal Server Error"
        
        self.client._make_request = Mock(return_value=mock_response)
        
        # Test query
        json_data = '{"op": "find-sub-classes", "lon": -122.4194, "lat": 37.7749}'
        result = self.client._http_query(json_data)
        
        # Should return None for server errors
        self.assertIsNone(result)

    def test_http_query_invalid_response_json(self):
        """Test HTTP query with invalid JSON response from server."""
        # Mock response with invalid JSON
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.json.side_effect = json.JSONDecodeError("Invalid JSON", "", 0)
        
        self.client._make_request = Mock(return_value=mock_response)
        
        json_data = '{"op": "find-sub-classes"}'
        
        # Should raise JSONDeserializationError
        with self.assertRaises(Exception):  # Will be JSONDeserializationError in real implementation
            self.client._http_query(json_data)

    def test_http_query_connection_failure(self):
        """Test HTTP query with connection failure."""
        # Mock connection failure
        self.client._make_request = Mock(return_value=None)
        
        json_data = '{"op": "find-sub-classes", "lon": -122.4194, "lat": 37.7749}'
        result = self.client._http_query(json_data)
        
        # Should return None for connection failures
        self.assertIsNone(result)

    def test_query_high_level_interface(self):
        """Test high-level query interface delegates to _http_query."""
        # Mock _http_query method
        expected_result = {"results": [], "count": 0}
        self.client._http_query = Mock(return_value=expected_result)
        
        json_data = '{"op": "find-sub-classes", "lon": -122.4194, "lat": 37.7749}'
        result = self.client.query(json_data)
        
        # ✅ FIX: Updated to expect domain_name AND api_key parameters
        self.client._http_query.assert_called_once_with(
            json_data, 
            domain_name=None, 
            api_key=None  # ✅ FIXED: Added api_key parameter
        )
        self.assertEqual(result, expected_result)


class TestApiClientCRUDOperations(unittest.TestCase):
    """Test ApiClient CRUD operation methods."""
    
    def setUp(self):
        """Set up test fixtures."""
        with patch('py_api_lib.api_client.requests.Session'):
            self.client = ApiClient(server_ip='localhost', port=8082)
            self.client.session = Mock()
    
    def test_http_create_basic(self):
        """Test basic HTTP create operation."""
        # Mock response - need to mock _make_request since that's what _http_create calls
        mock_response = Mock()
        mock_response.status_code = 201  # Correct status code for create
        mock_response.json.return_value = {"domain": {"uuid": "test-uuid"}}
        
        # Mock the _make_request method that _http_create actually calls
        self.client._make_request = Mock(return_value=mock_response)
        
        # Test payload
        payload = {"name": "test-domain", "fq_name": ["test-domain"]}
        
        # Call create (use the actual method name from your implementation)
        result = self.client._http_create("domain", payload)
        
        # Verify result
        self.assertEqual(result, {"domain": {"uuid": "test-uuid"}})
        
        # ✅ FIX: Updated to expect domain in URL path AND api_key parameter
        self.client._make_request.assert_called_once_with(
            'POST', 
            f"{self.client.base_url}/default-domain/domain",
            api_key=None,  # ✅ FIXED: Added api_key parameter
            json=payload
        )


class TestApiClientHighLevelOperations(unittest.TestCase):
    """Test ApiClient high-level operations."""
    
    def setUp(self):
        """Set up test fixtures."""
        with patch('py_api_lib.api_client.requests.Session'):
            self.client = ApiClient(server_ip='localhost', port=8082)
            self.client.session = Mock()


class TestApiClientReferenceOperations(unittest.TestCase):
    """Test ApiClient reference operations."""
    
    def setUp(self):
        """Set up test fixtures."""
        with patch('py_api_lib.api_client.requests.Session'):
            self.client = ApiClient(server_ip='localhost', port=8082)
            self.client.session = Mock()


class TestApiClientUtilityFunctions(unittest.TestCase):
    """Test ApiClient utility functions."""
    
    def setUp(self):
        """Set up test fixtures."""
        with patch('py_api_lib.api_client.requests.Session'):
            self.client = ApiClient(server_ip='localhost', port=8082)
            self.client.session = Mock()

    def test_query_with_different_operations(self):
        """Test query method with different operation types."""
        operation_tests = [
            {
                "op": "find-sub-classes",
                "params": {"lon": -122.4194, "lat": 37.7749},
                "expected_endpoint": "/default-domain/query"
            },
            {
                "op": "find-resource-class-count", 
                "params": {"lon": -122.4194, "lat": 37.7749, "kws": ["food"]},
                "expected_endpoint": "/default-domain/query"
            },
            {
                "op": "find-exclusive-match-deal-count",
                "params": {"lon": -122.4194, "lat": 37.7749, "city": "SF"},
                "expected_endpoint": "/default-domain/query"
            }
        ]

        for test_case in operation_tests:
            with self.subTest(operation=test_case["op"]):
                # Reset mock
                mock_response = Mock()
                mock_response.status_code = 200
                mock_response.json.return_value = {"results": []}
                self.client._make_request = Mock(return_value=mock_response)

                # Build query
                query_data = {"op": test_case["op"]}
                query_data.update(test_case["params"])
                json_data = json.dumps(query_data)

                # Execute query
                result = self.client.query(json_data)

                # Verify endpoint was called correctly
                self.client._make_request.assert_called_once()
                call_args = self.client._make_request.call_args
                self.assertEqual(call_args[0][0], 'POST')  # Method
                self.assertTrue(call_args[0][1].endswith(test_case["expected_endpoint"]))  # URL

    def test_query_parameter_validation(self):
        """Test that query properly validates different parameter combinations."""
        # Test with minimal parameters
        minimal_query = '{"op": "find-sub-classes"}'
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"results": []}
        self.client._make_request = Mock(return_value=mock_response)

        result = self.client.query(minimal_query)
        self.assertEqual(result, {"results": []})

        # Test with all parameters
        full_query = '''{
            "op": "find-resource-sub-class-count",
            "lon": -122.4194,
            "lat": 37.7749,
            "kws": ["restaurant", "food"],
            "city": "San Francisco", 
            "area": "SOMA",
            "include_default_deals": true,
            "include_online": false,
            "online_only": false,
            "include_deals": true,
            "project_name": "test-project"
        }'''

        # Reset mock
        self.client._make_request.reset_mock()
        result = self.client.query(full_query)
        self.assertEqual(result, {"results": []})

        # Verify complex payload was sent correctly
        call_args = self.client._make_request.call_args
        sent_payload = call_args[1]['json']
        self.assertEqual(sent_payload["op"], "find-resource-sub-class-count")
        self.assertEqual(sent_payload["lon"], -122.4194)
        self.assertEqual(sent_payload["lat"], 37.7749)
        self.assertEqual(sent_payload["city"], "San Francisco")
        self.assertTrue(sent_payload["include_default_deals"])
        self.assertFalse(sent_payload["include_online"])


class TestApiClientUtilityHelpers(unittest.TestCase):
    """Test ApiClient utility helper methods."""
    
    def setUp(self):
        """Set up test fixtures."""
        with patch('py_api_lib.api_client.requests.Session'):
            self.client = ApiClient(server_ip='localhost', port=8082)
            self.client.session = Mock()


class TestApiClientErrorHandling(unittest.TestCase):
    """Test ApiClient error handling."""
    
    def setUp(self):
        """Set up test fixtures."""
        with patch('py_api_lib.api_client.requests.Session'):
            self.client = ApiClient(server_ip='localhost', port=8082)
            self.client.session = Mock()


class TestApiClientContextManager(unittest.TestCase):
    """Test ApiClient context manager functionality."""
    
    def setUp(self):
        """Set up test fixtures."""
        with patch('py_api_lib.api_client.requests.Session'):
            self.client = ApiClient(server_ip='localhost', port=8082)
            self.client.session = Mock()


class TestApiLibCRUDOperations(unittest.TestCase):
    """Test the refactored ApiLib CRUD operations that call HTTP methods directly."""

    def setUp(self):
        """Set up test fixtures for ApiLib testing."""
        # Mock the ApiClient creation in ApiLib
        with patch('py_api_lib.api_lib.ApiClient') as mock_client_class:
            self.mock_api_client = Mock()
            mock_client_class.return_value = self.mock_api_client

            # Create ApiLib instance with correct parameters
            self.api_lib = ApiLib(api_server_host='localhost', api_server_port='8082')

            # Mock object types discovery
            self.api_lib.object_types = ['domain', 'project', 'virtual-network']

            # Sample test object with to_dict method - make Mock behave like real object
            self.sample_obj = Mock()
            self.sample_obj.name = "test-domain"
            self.sample_obj.uuid = "domain-123"
            self.sample_obj.fq_name = ["test-domain"]  # Make this a real list
            self.sample_obj.obj_type = "domain"
            self.sample_obj.parent_obj = None  # No parent for this test
            
            # Mock to_dict to return a real dict
            self.sample_obj.to_dict.return_value = {
                "uuid": "domain-123",
                "name": "test-domain",
                "fq_name": ["test-domain"],
                "display_name": "Test Domain"
            }

            # Mock methods for legacy compatibility
            self.sample_obj.set_server_conn = Mock()
            self.sample_obj.clear_pending_updates = Mock()

    def test_object_create_calls_http_create_directly(self):
        """Test that _object_create calls _http_create directly with obj.to_dict()."""
        # Mock the HTTP create response
        self.mock_api_client._http_create.return_value = {
            "domain": {"uuid": "domain-456", "name": "test-domain"}
        }

        # Call create
        result = self.api_lib._object_create("domain", self.sample_obj)

        # Verify _http_create was called with correct payload
        self.mock_api_client._http_create.assert_called_once()
        call_args = self.mock_api_client._http_create.call_args

        self.assertEqual(call_args[0][0], "domain")  # obj_type
        # Verify payload came from to_dict()
        expected_payload = self.sample_obj.to_dict.return_value
        # ✅ FIX: Check that _encrypted was added
        expected_payload['_encrypted'] = False
        self.assertEqual(call_args[0][1], expected_payload)
        
        # ✅ FIX: Verify domain_name AND api_key parameters were passed
        self.assertEqual(call_args[1]['domain_name'], 'default-domain')
        self.assertEqual(call_args[1]['api_key'], None)  # ✅ FIXED: Added api_key check

        # Verify obj.to_dict() was called
        self.sample_obj.to_dict.assert_called_once()

        # Verify return value
        self.assertEqual(result, "domain-456")

    def test_object_create_sets_parent_relationships(self):
        """Test that object creation properly sets up parent relationships."""
        # Create mock parent with proper list-like fq_name
        mock_parent = Mock()
        mock_parent.obj_type = "domain"
        mock_parent.uuid = "parent-uuid"
        mock_parent.fq_name = ["parent-domain"]  # Real list, not Mock

        # Create child object
        child_obj = Mock()
        child_obj.name = "test-project"
        child_obj.parent_type = mock_parent.obj_type
        child_obj.parent_uuid = mock_parent.uuid
        child_obj.fq_name = mock_parent.fq_name + [child_obj.name]
        child_obj.to_dict.return_value = {
            "uuid": "project-123",
            "name": "test-project",
            "fq_name": ["parent-domain", "test-project"],
            "parent_uuid": "parent-uuid"
        }
        child_obj.set_server_conn = Mock()
        child_obj.clear_pending_updates = Mock()

        # Mock HTTP response
        self.mock_api_client._http_create.return_value = {
            "project": {"uuid": "project-456"}
        }

        # Call create
        result = self.api_lib._object_create("project", child_obj)

        # Verify parent attributes were set
        self.assertEqual(child_obj.parent_type, "domain")
        self.assertEqual(child_obj.parent_uuid, "parent-uuid")
        self.assertEqual(child_obj.fq_name, ["parent-domain", "test-project"])

        # Verify to_dict was called after parent setup
        child_obj.to_dict.assert_called_once()

    def test_object_read_calls_http_read_directly(self):
        """Test that _object_read calls _http_read directly and hydrates object."""
        # Mock HTTP read response
        self.mock_api_client._http_read.return_value = {
            "domain": {
                "uuid": "domain-123",
                "name": "test-domain",
                "fq_name": ["test-domain"]
            }
        }

        # Mock object hydration
        hydrated_obj = Mock()
        hydrated_obj.set_server_conn = Mock()
        hydrated_obj.clear_pending_updates = Mock()

        with patch.object(self.api_lib, '_hydrate_object', return_value=hydrated_obj):
            result = self.api_lib._object_read("domain", id="domain-123")

        # ✅ FIX: Verify _http_read was called with domain_name AND api_key parameters
        self.mock_api_client._http_read.assert_called_once_with(
            "domain", "domain-123", 
            domain_name='default-domain',
            api_key=None  # ✅ FIXED: Added api_key parameter
        )

        # Verify legacy compatibility methods were called
        hydrated_obj.clear_pending_updates.assert_called_once()
        hydrated_obj.set_server_conn.assert_called_once_with(self.api_lib)

        self.assertEqual(result, hydrated_obj)

    def test_object_read_with_fq_name_conversion(self):
        """Test that _object_read converts fq_name to UUID before HTTP call."""
        # Mock fq_name to UUID conversion
        self.api_lib.fq_name_to_uuid = Mock(return_value="domain-123")

        # Mock HTTP read response
        self.mock_api_client._http_read.return_value = {
            "domain": {"uuid": "domain-123", "name": "test"}
        }

        # Mock hydration
        with patch.object(self.api_lib, '_hydrate_object', return_value=Mock()):
            result = self.api_lib._object_read("domain", fq_name=["test-domain"])

        # ✅ FIX: Verify fq_name conversion was called with domain_name AND api_key parameters
        self.api_lib.fq_name_to_uuid.assert_called_once_with(
            "domain", ["test-domain"], 
            domain_name='default-domain',
            api_key=None  # ✅ FIXED: Added api_key parameter
        )

        # ✅ FIX: Verify HTTP read was called with domain_name AND api_key parameters
        self.mock_api_client._http_read.assert_called_once_with(
            "domain", "domain-123", 
            domain_name='default-domain',
            api_key=None  # ✅ FIXED: Added api_key parameter
        )

    def test_object_update_calls_http_update_directly(self):
        """Test that _object_update calls _http_update directly with obj.to_dict()."""
        # Mock HTTP update response
        self.mock_api_client._http_update.return_value = {
            "domain": {"uuid": "domain-123", "name": "updated-domain"}
        }

        # Call update
        result = self.api_lib._object_update("domain", self.sample_obj)

        # Verify _http_update was called with correct parameters
        self.mock_api_client._http_update.assert_called_once()
        call_args = self.mock_api_client._http_update.call_args

        self.assertEqual(call_args[0][0], "domain")  # obj_type
        self.assertEqual(call_args[0][1], "domain-123")  # obj_uuid

        # Verify payload came from to_dict() and UUID was removed
        expected_payload = self.sample_obj.to_dict.return_value.copy()
        expected_payload.pop('uuid', None)  # UUID should be removed
        expected_payload['_encrypted'] = False  # ✅ Added by implementation
        self.assertEqual(call_args[0][2], expected_payload)
        
        # ✅ FIX: Verify domain_name AND api_key parameters were passed
        self.assertEqual(call_args[1]['domain_name'], 'default-domain')
        self.assertEqual(call_args[1]['api_key'], None)  # ✅ FIXED: Added api_key check

        # Verify obj.to_dict() was called
        self.sample_obj.to_dict.assert_called_once()

        # Verify clear_pending_updates was called
        self.sample_obj.clear_pending_updates.assert_called_once()

        # Verify return value
        self.assertEqual(result, "Updated successfully")

    def test_object_update_uuid_from_fq_name(self):
        """Test that update gets UUID from fq_name if not present on object."""
        # Create object without UUID
        obj_without_uuid = Mock()
        obj_without_uuid.uuid = None
        obj_without_uuid.fq_name = ["test-domain"]  # Real list
        obj_without_uuid.get_fq_name.return_value = ["test-domain"]
        obj_without_uuid.to_dict.return_value = {"name": "updated-domain"}
        obj_without_uuid.clear_pending_updates = Mock()

        # Mock UUID lookup
        self.api_lib.fq_name_to_uuid = Mock(return_value="domain-123")

        # Mock HTTP update
        self.mock_api_client._http_update.return_value = {"domain": {"uuid": "domain-123"}}

        # Call update
        result = self.api_lib._object_update("domain", obj_without_uuid)

        # ✅ FIX: Verify UUID was looked up with domain_name AND api_key parameters
        self.api_lib.fq_name_to_uuid.assert_called_once_with(
            "domain", ["test-domain"], 
            domain_name='default-domain',
            api_key=None  # ✅ FIXED: Added api_key parameter
        )
        self.assertEqual(obj_without_uuid.uuid, "domain-123")

        # Verify HTTP update was called with found UUID
        self.mock_api_client._http_update.assert_called_once()
        call_args = self.mock_api_client._http_update.call_args
        self.assertEqual(call_args[0][1], "domain-123")

    def test_object_delete_calls_http_delete_directly(self):
        """Test that _object_delete calls _http_delete directly."""
        # Mock HTTP delete response
        self.mock_api_client._http_delete.return_value = True

        # Call delete
        self.api_lib._object_delete("domain", id="domain-123")

        # ✅ FIX: Verify _http_delete was called with domain_name AND api_key parameters
        self.mock_api_client._http_delete.assert_called_once_with(
            "domain", "domain-123", 
            domain_name='default-domain',
            api_key=None  # ✅ FIXED: Added api_key parameter
        )

    def test_objects_list_calls_http_list_directly(self):
        """Test that _objects_list calls _http_list and always returns hydrated objects."""
        # Mock HTTP list response (raw dicts from API)
        raw_objects = [
            {"uuid": "domain-1", "name": "domain1", "fq_name": ["domain1"], "obj_type": "domain"},
            {"uuid": "domain-2", "name": "domain2", "fq_name": ["domain2"], "obj_type": "domain"}
        ]
        self.mock_api_client._http_list.return_value = raw_objects
        
        # Call _objects_list (now ALWAYS returns objects, regardless of detail parameter)
        result = self.api_lib._objects_list("domain", detail=False)
        
        # ✅ FIX: Verify _http_list was called with domain_name AND api_key parameters
        self.mock_api_client._http_list.assert_called_once_with(
            "domain", None, 
            domain_name='default-domain',
            api_key=None  # ✅ FIXED: Added api_key parameter
        )
        
        # NEW: Verify we got objects, not dicts
        self.assertEqual(len(result), 2)
        
        # Verify first object
        self.assertIsInstance(result[0], object)
        self.assertNotIsInstance(result[0], dict)
        self.assertEqual(result[0].uuid, "domain-1")
        self.assertEqual(result[0].name, "domain1")
        self.assertEqual(result[0].fq_name, ["domain1"])
        
        # Verify second object
        self.assertIsInstance(result[1], object)
        self.assertNotIsInstance(result[1], dict)
        self.assertEqual(result[1].uuid, "domain-2")
        self.assertEqual(result[1].name, "domain2")
        self.assertEqual(result[1].fq_name, ["domain2"])

    def test_objects_list_detail_true_hydrates_objects(self):
        """Test that _objects_list with detail=True hydrates objects."""
        # Mock HTTP list response
        raw_objects = [
            {"uuid": "domain-1", "name": "domain1", "obj_type": "domain"},
            {"uuid": "domain-2", "name": "domain2", "obj_type": "domain"}
        ]
        self.mock_api_client._http_list.return_value = raw_objects

        # Mock hydrated objects
        hydrated_obj1 = Mock()
        hydrated_obj1.clear_pending_updates = Mock()
        hydrated_obj1.set_server_conn = Mock()

        hydrated_obj2 = Mock()
        hydrated_obj2.clear_pending_updates = Mock()
        hydrated_obj2.set_server_conn = Mock()

        with patch.object(self.api_lib, '_hydrate_object', side_effect=[hydrated_obj1, hydrated_obj2]):
            result = self.api_lib._objects_list("domain", detail=True)

        # Verify objects were hydrated
        self.assertEqual(len(result), 2)
        self.assertEqual(result[0], hydrated_obj1)
        self.assertEqual(result[1], hydrated_obj2)

        # Verify legacy compatibility methods called
        hydrated_obj1.clear_pending_updates.assert_called_once()
        hydrated_obj1.set_server_conn.assert_called_once_with(self.api_lib)
        hydrated_obj2.clear_pending_updates.assert_called_once()
        hydrated_obj2.set_server_conn.assert_called_once_with(self.api_lib)

    def test_objects_list_filtering(self):
        """Test that _objects_list applies filtering and returns hydrated objects."""
        # Mock HTTP list response (raw dicts from API)
        raw_objects = [
                {"uuid": "domain-1", "name": "domain-1", "parent_uuid": "parent-1", "fq_name": ["parent", "domain-1"], "obj_type": "domain"},
                {"uuid": "domain-2", "name": "domain-2", "parent_uuid": "parent-2", "fq_name": ["parent", "domain-2"], "obj_type": "domain"},
                {"uuid": "domain-3", "name": "domain-3", "parent_uuid": "parent-1", "fq_name": ["other", "domain-3"], "obj_type": "domain"}
        ]
        self.mock_api_client._http_list.return_value = raw_objects

        # Test parent_id filtering
        result = self.api_lib._objects_list("domain", parent_id="parent-1", detail=False)

        # Should return 2 hydrated objects with matching parent_uuid
        self.assertEqual(len(result), 2)

        # Verify they are objects, not dicts
        self.assertIsInstance(result[0], object)
        self.assertNotIsInstance(result[0], dict)
        self.assertIsInstance(result[1], object)
        self.assertNotIsInstance(result[1], dict)

        # Verify filtering worked correctly
        self.assertEqual(result[0].uuid, "domain-1")
        self.assertEqual(result[0].parent_uuid, "parent-1")
        self.assertEqual(result[1].uuid, "domain-3")
        self.assertEqual(result[1].parent_uuid, "parent-1")

        # Test parent_fq_name filtering
        result = self.api_lib._objects_list("domain", parent_fq_name=["parent"], detail=False)

        # Should return 2 hydrated objects with matching parent fq_name prefix
        self.assertEqual(len(result), 2)

        # Verify they are objects
        self.assertIsInstance(result[0], object)
        self.assertIsInstance(result[1], object)

        # Verify filtering worked correctly
        self.assertEqual(result[0].uuid, "domain-1")
        self.assertEqual(result[0].fq_name, ["parent", "domain-1"])
        self.assertEqual(result[1].uuid, "domain-2")
        self.assertEqual(result[1].fq_name, ["parent", "domain-2"])

        # Verify domain-3 was filtered out (different parent prefix)
        uuids = [obj.uuid for obj in result]
        self.assertNotIn("domain-3", uuids)


class TestApiLibListBulkOperations(unittest.TestCase):
    """Test the new list_bulk API in both ApiClient and ApiLib."""

    def setUp(self):
        """Set up test fixtures for list_bulk testing."""
        # Mock the ApiClient creation in ApiLib
        with patch('py_api_lib.api_lib.ApiClient') as mock_client_class:
            self.mock_api_client = Mock()
            mock_client_class.return_value = self.mock_api_client

            # Create ApiLib instance
            self.api_lib = ApiLib(api_server_host='localhost', api_server_port='8082')

            # Mock object types discovery
            self.api_lib.object_types = ['business', 'customer', 'provider', 'deal']

    def test_list_bulk_legacy_compatibility(self):
        """Test that list_bulk maintains legacy interface compatibility."""
        # Mock the underlying _http_list_bulk
        raw_data = [
            {"uuid": "biz-1", "name": "business1", "status": "active"},
            {"uuid": "biz-2", "name": "business2", "status": "active"}
        ]
        self.mock_api_client._http_list_bulk.return_value = raw_data

        # Mock hydrated objects
        hydrated_obj1 = Mock()
        hydrated_obj1.clear_pending_updates = Mock()
        hydrated_obj1.set_server_conn = Mock()

        hydrated_obj2 = Mock()
        hydrated_obj2.clear_pending_updates = Mock()
        hydrated_obj2.set_server_conn = Mock()

        with patch.object(self.api_lib, '_hydrate_object', side_effect=[hydrated_obj1, hydrated_obj2]):
            # Test legacy call format: list_bulk('business')
            result = self.api_lib.list_bulk('business')

        # ✅ FIX: Verify _http_list_bulk was called with domain_name AND api_key parameters
        self.mock_api_client._http_list_bulk.assert_called_once_with(
            'business', [], 
            domain_name='default-domain', 
            api_key=None,  # ✅ FIXED: Added api_key parameter
            detail=True
        )

        # Verify objects were hydrated and legacy methods called
        self.assertEqual(len(result), 2)
        self.assertEqual(result[0], hydrated_obj1)
        self.assertEqual(result[1], hydrated_obj2)

        # Verify legacy compatibility methods
        hydrated_obj1.clear_pending_updates.assert_called_once()
        hydrated_obj1.set_server_conn.assert_called_once_with(self.api_lib)
        hydrated_obj2.clear_pending_updates.assert_called_once()
        hydrated_obj2.set_server_conn.assert_called_once_with(self.api_lib)


class TestApiLibQueryOperations(unittest.TestCase):
    """Test ApiLib query operations for backward compatibility."""

    def setUp(self):
        """Set up test fixtures for ApiLib query testing."""
        # Mock the ApiClient creation in ApiLib
        self.patcher = patch('py_api_lib.api_lib.ApiClient')
        mock_client_class = self.patcher.start()
        self.mock_api_client = Mock()
        mock_client_class.return_value = self.mock_api_client

        # Create ApiLib instance
        self.api_lib = ApiLib(api_server_host='localhost', api_server_port='8082')

    def tearDown(self):
        """Clean up patches."""
        self.patcher.stop()

    def test_query_backward_compatibility(self):
        """Test that ApiLib.query maintains backward compatibility."""
        # Mock successful query response
        expected_result = {
            "sub_classes": [
                {"id": "restaurant", "name": "Restaurant", "count": 25},
                {"id": "retail", "name": "Retail", "count": 18}
            ]
        }
        self.mock_api_client.query.return_value = expected_result

        # Test legacy query usage
        json_data = '{"op": "find-sub-classes", "lon": -122.4194, "lat": 37.7749, "city": "San Francisco"}'
        result = self.api_lib.query(json_data)

        # ✅ FIX: Verify delegation to ApiClient with domain_name AND api_key parameters
        self.mock_api_client.query.assert_called_once_with(
            json_data, 
            domain_name='default-domain',
            api_key=None  # ✅ FIXED: Added api_key parameter
        )
        self.assertEqual(result, expected_result)

    def test_query_with_complex_payload(self):
        """Test query with complex JSON payload typical of real usage."""
        # Mock response for resource class count query
        expected_result = {
            "resource_classes": {
                "business": 45,
                "customer": 23,
                "provider": 12
            },
            "total_count": 80
        }
        self.mock_api_client.query.return_value = expected_result

        # Complex query payload
        json_data = '''{
            "op": "find-resource-class-count",
            "lon": -122.4194,
            "lat": 37.7749,
            "kws": ["restaurant", "food"],
            "city": "San Francisco",
            "area": "SOMA",
            "include_default_deals": true,
            "include_online": false,
            "online_only": false,
            "project_name": "test-project"
        }'''

        result = self.api_lib.query(json_data)

        # ✅ FIX: Verify correct delegation with domain_name AND api_key parameters
        self.mock_api_client.query.assert_called_once_with(
            json_data, 
            domain_name='default-domain',
            api_key=None  # ✅ FIXED: Added api_key parameter
        )
        self.assertEqual(result, expected_result)

    def test_query_handles_api_client_errors(self):
        """Test that ApiLib.query handles ApiClient errors gracefully."""
        # Verify what happens when _http_query is called directly
        self.api_lib.api_client.query = Mock(side_effect=ValueError("Invalid JSON data"))

        # Test calling through api_lib.query()
        with self.assertRaises(ValueError):
            self.api_lib.query('{"test": "data"}')

    def test_query_handles_serialization_errors(self):
        """Test that ApiLib.query handles various error conditions correctly."""
        json_data = '{"op": "find-sub-classes"}'

        # Test 1: ValueError should be propagated
        with patch.object(self.api_lib.api_client, 'query',
                     side_effect=ValueError("Invalid JSON data")):
            with self.assertRaises(ValueError):
                self.api_lib.query(json_data)

        # Test 2: TypeError should be propagated
        with patch.object(self.api_lib.api_client, 'query',
                     side_effect=TypeError("Invalid parameter type")):
            with self.assertRaises(TypeError):
                self.api_lib.query(json_data)

        # Test 3: Other exceptions return None (backward compatibility)
        with patch.object(self.api_lib.api_client, 'query',
                     side_effect=ConnectionError("Connection failed")):
            with self.assertRaises(ConnectionError) as ctx:
                self.api_lib.query('{"type": "order"}')
            self.assertEqual(str(ctx.exception), "Connection failed")

    def test_query_returns_none_on_failure(self):
        """Test that ApiLib.query returns None for general failures (backward compatibility)."""
        # Mock general exception from ApiClient
        self.mock_api_client.query.side_effect = RuntimeError("Connection failed")

        json_data = '{"op": "find-sub-classes", "lon": -122.4194, "lat": 37.7749}'
        with self.assertRaises(RuntimeError) as ctx:
            self.api_lib.query('{"type": "order"}')
        self.assertEqual(str(ctx.exception), "Connection failed")

    def test_query_with_location_based_operations(self):
        """Test query with typical location-based operations."""
        test_cases = [
            {
                "name": "find_sub_classes",
                "query": '{"op": "find-sub-classes", "lon": -122.4194, "lat": 37.7749}',
                "response": {"sub_classes": ["restaurant", "retail"]}
            },
            {
                "name": "find_resource_class_count", 
                "query": '{"op": "find-resource-class-count", "lon": -122.4194, "lat": 37.7749}',
                "response": {"business": 10, "customer": 5}
            },
            {
                "name": "find_exclusive_match_deal_count",
                "query": '{"op": "find-exclusive-match-deal-count", "lon": -122.4194, "lat": 37.7749}',
                "response": {"count": 3}
            }
        ]

        for case in test_cases:
            with self.subTest(operation=case["name"]):
                # Reset mock
                self.mock_api_client.query.reset_mock()
                self.mock_api_client.query.return_value = case["response"]

                # Execute query
                result = self.api_lib.query(case["query"])

                # ✅ FIX: Verify with domain_name AND api_key parameters
                self.mock_api_client.query.assert_called_once_with(
                    case["query"], 
                    domain_name='default-domain',
                    api_key=None  # ✅ FIXED: Added api_key parameter
                )
                self.assertEqual(result, case["response"])

    def test_query_empty_response(self):
        """Test query with empty response from server."""
        # Mock empty response
        self.mock_api_client.query.return_value = {}

        json_data = '{"op": "find-sub-classes", "lon": -122.4194, "lat": 37.7749}'
        result = self.api_lib.query(json_data)

        # Should return empty dict
        self.assertEqual(result, {})

    def test_query_null_response(self):
        """Test query with null response from ApiClient."""
        # Mock null response
        self.mock_api_client.query.return_value = None

        json_data = '{"op": "find-sub-classes", "lon": -122.4194, "lat": 37.7749}'
        result = self.api_lib.query(json_data) or None

        # Should return None
        self.assertIsNone(result)


class TestApiLibObjectHydration(unittest.TestCase):
    """Test the moved _hydrate_object method in ApiLib."""

    def setUp(self):
        """Set up test fixtures."""
        with patch('py_api_lib.api_lib.ApiClient'):
            self.api_lib = ApiLib()
            self.api_lib._module_cache = {}

    @patch('py_api_lib.api_lib.importlib.import_module')
    def test_hydrate_object_success(self, mock_import):
        """Test successful object hydration from data dict."""
        # Mock module and class
        mock_module = Mock()
        mock_class = Mock()
        mock_instance = Mock()
        mock_class.from_dict.return_value = mock_instance
        mock_module.Domain = mock_class
        mock_import.return_value = mock_module

        # Test data - make it non-empty to avoid deserialization errors
        obj_data = {
            "uuid": "domain-123",
            "name": "test-domain",
            "fq_name": ["test-domain"]
        }

        # Call hydration
        result = self.api_lib._hydrate_object("domain", obj_data)

        # Verify correct module was imported
        mock_import.assert_called_once_with("pymodel_system.objects.domain")

        # Verify from_dict was called with correct data
        mock_class.from_dict.assert_called_once_with(obj_data)

        # Verify result
        self.assertEqual(result, mock_instance)

        # Verify module was cached
        self.assertIn("pymodel_system.objects.domain", self.api_lib._module_cache)

    @patch('py_api_lib.api_lib.importlib.import_module')
    def test_hydrate_object_uses_module_cache(self, mock_import):
        """Test that hydration uses cached modules."""
        # Pre-populate cache
        mock_module = Mock()
        mock_class = Mock()
        mock_instance = Mock()
        mock_class.from_dict.return_value = mock_instance
        mock_module.VirtualNetwork = mock_class
        self.api_lib._module_cache["pymodel_system.objects.virtual_network"] = mock_module

        # Test data
        obj_data = {"uuid": "vn-123", "name": "test-vn"}

        # Call hydration
        result = self.api_lib._hydrate_object("virtual-network", obj_data)

        # Verify import was NOT called (used cache)
        mock_import.assert_not_called()

        # Verify from_dict was called
        mock_class.from_dict.assert_called_once_with(obj_data)

        self.assertEqual(result, mock_instance)

    @patch('py_api_lib.api_lib.importlib.import_module')
    def test_hydrate_object_handles_errors(self, mock_import):
        """Test that hydration handles import/attribute errors gracefully."""
        # Mock import failure
        mock_import.side_effect = ImportError("Module not found")

        # Test data
        obj_data = {"uuid": "test-123", "name": "test"}

        # The actual implementation raises an exception, so we expect that
        with self.assertRaises(Exception):
            self.api_lib._hydrate_object("invalid-type", obj_data)

    def test_hydrate_object_normalizes_type_names(self):
        """Test that hydration correctly normalizes object type names."""
        with patch('py_api_lib.api_lib.importlib.import_module') as mock_import:
            mock_module = Mock()
            mock_class = Mock()
            mock_instance = Mock()
            mock_class.from_dict.return_value = mock_instance
            mock_module.SampleObject1 = mock_class
            mock_import.return_value = mock_module

            # Test with hyphenated type and non-empty data
            obj_data = {"uuid": "test-123", "name": "test-sample"}
            result = self.api_lib._hydrate_object("sample-object1", obj_data)

            # Verify correct module path and class name
            mock_import.assert_called_with("pymodel_system.objects.sample_object1")
            mock_class.from_dict.assert_called_once_with(obj_data)
            self.assertEqual(result, mock_instance)


class TestApiLibSchemaDiscovery(unittest.TestCase):
    """Test that ApiLib discovers and loads schemas from both pymodel and pymodel_system."""

    def setUp(self):
        """Set up test fixtures."""
        # Mock the API client
        with patch('py_api_lib.api_lib.ApiClient') as mock_client_class:
            self.mock_api_client = Mock()
            mock_client_class.return_value = self.mock_api_client
            self.api_lib = ApiLib(api_server_host='localhost', api_server_port='8082')

    def test_pymodel_import_available(self):
        """Test that pymodel can be imported."""
        try:
            import pymodel
            import pymodel.objects
            self.assertTrue(True, "pymodel imported successfully")
        except ImportError as e:
            self.skipTest(f"pymodel not available: {e}")

    def test_pymodel_system_import_available(self):
        """Test that pymodel_system can be imported."""
        try:
            import pymodel_system
            import pymodel_system.objects
            self.assertTrue(True, "pymodel_system imported successfully")
        except ImportError as e:
            self.skipTest(f"pymodel_system not available: {e}")

    def test_tenant_schema_classes_available(self):
        """Test that tenant schema classes are available in pymodel.objects."""
        try:
            import pymodel.objects

            # Test common tenant schema classes
            expected_classes = ['Domain', 'Project', 'Business', 'Customer', 'Provider']
            available_classes = []

            for class_name in expected_classes:
                if hasattr(pymodel.objects, class_name):
                    available_classes.append(class_name)

            self.assertGreater(len(available_classes), 0,
                             f"At least some tenant schema classes should be available. Found: {available_classes}")

        except ImportError as e:
            self.skipTest(f"pymodel.objects not available: {e}")

    def test_system_schema_classes_available(self):
        """Test that system schema classes are available in pymodel_system.objects."""
        try:
            import pymodel_system.objects

            # Test system schema classes
            expected_classes = ['GlobalSystemConfig']
            available_classes = []

            for class_name in expected_classes:
                if hasattr(pymodel_system.objects, class_name):
                    available_classes.append(class_name)

            self.assertGreater(len(available_classes), 0,
                             f"Private schema classes should be available. Found: {available_classes}")

        except ImportError as e:
            self.skipTest(f"pymodel_system.objects not available: {e}")

    def test_api_lib_discovers_tenant_object_types(self):
        """Test that ApiLib discovers object types from tenant schemas."""
        try:
            # Check if ApiLib has object_types attribute populated
            if hasattr(self.api_lib, 'object_types'):
                object_types = self.api_lib.object_types

                # Should have discovered some tenant object types
                tenant_types = ['domain', 'project', 'business', 'customer']
                found_types = [t for t in tenant_types if t in object_types]

                self.assertGreater(len(found_types), 0,
                                 f"ApiLib should discover tenant object types. Found: {found_types}")
        except Exception as e:
            self.skipTest(f"Could not test object type discovery: {e}")

    def test_api_lib_discovers_system_object_types(self):
        """Test that ApiLib discovers object types from system schemas."""
        try:
            # Check if ApiLib has object_types attribute populated
            if hasattr(self.api_lib, 'object_types'):
                object_types = self.api_lib.object_types

                # Should have discovered private object types
                private_types = ['global-system-config']
                found_types = [t for t in private_types if t in object_types]

                self.assertGreater(len(found_types), 0,
                                 f"ApiLib should discover private object types. Found: {found_types}")
        except Exception as e:
            self.skipTest(f"Could not test private object type discovery: {e}")

    def test_api_lib_has_global_system_config_methods(self):
        """Test that ApiLib has methods for global_system_config from system schemas."""
        # Check for the methods that should be generated for GlobalSystemConfig
        expected_methods = [
            'global_system_config_create',
            'global_system_config_read',
            'global_system_config_update',
            'global_system_config_delete'
        ]

        available_methods = []
        for method in expected_methods:
            if hasattr(self.api_lib, method):
                available_methods.append(method)

        # If pymodel_system is installed, all methods should be available
        try:
            import pymodel_system.objects
            self.assertEqual(len(available_methods), len(expected_methods),
                           f"All GlobalSystemConfig methods should be available. Found: {available_methods}")
        except ImportError:
            self.skipTest("pymodel_system not available, skipping method availability test")

    def test_both_namespaces_coexist(self):
        """Test that both pymodel and pymodel_system can be imported simultaneously."""
        try:
            import pymodel
            import pymodel_system

            # Both should be importable
            self.assertIsNotNone(pymodel)
            self.assertIsNotNone(pymodel_system)

            # They should be different modules
            self.assertNotEqual(pymodel, pymodel_system)

            # Both should have objects submodules
            import pymodel.objects
            import pymodel_system.objects

            self.assertIsNotNone(pymodel.objects)
            self.assertIsNotNone(pymodel_system.objects)

        except ImportError as e:
            self.skipTest(f"Both schemas not available: {e}")


class TestApiLibPrivateSchemaIntegration(unittest.TestCase):
    """Integration tests for ApiLib working with system schemas."""

    def setUp(self):
        """Set up test fixtures with mocked API client."""
        with patch('py_api_lib.api_lib.ApiClient') as mock_client_class:
            self.mock_api_client = Mock()
            mock_client_class.return_value = self.mock_api_client
            self.api_lib = ApiLib(api_server_host='localhost', api_server_port='8082')

    @patch('py_api_lib.api_lib.importlib.import_module')
    def test_api_lib_attempts_system_import(self, mock_import):
        """Test that ApiLib initialization attempts to import pymodel_system."""
        # This test verifies the code path exists
        # The actual import happens during __init__, so we test the logic exists

        try:
            # Re-initialize to trigger import attempt
            with patch('py_api_lib.api_lib.ApiClient'):
                api_lib = ApiLib(api_server_host='localhost', api_server_port='8082')

            # If we get here, initialization succeeded
            self.assertTrue(True)
        except Exception as e:
            # Even if import fails, initialization should handle it gracefully
            self.assertNotIn('pymodel_system', str(e),
                           "Should handle missing pymodel_system gracefully")

    def test_global_system_config_create_method_signature(self):
        """Test that global_system_config_create method exists with correct signature."""
        try:
            import pymodel_system.objects

            # Method should exist
            self.assertTrue(hasattr(self.api_lib, 'global_system_config_create'))

            # Should be callable
            method = getattr(self.api_lib, 'global_system_config_create')
            self.assertTrue(callable(method))

        except ImportError:
            self.skipTest("pymodel_system not available")


class TestApiLibDirectHTTPIntegration(unittest.TestCase):
    """Test integration between ApiLib and direct HTTP method calls."""

    def setUp(self):
        """Set up test fixtures for integration testing."""
        with patch('py_api_lib.api_lib.ApiClient') as mock_client_class:
            self.mock_api_client = Mock()
            mock_client_class.return_value = self.mock_api_client
            self.api_lib = ApiLib()

    def test_create_read_cycle_data_flow(self):
        """Test complete create-read cycle with correct data flow."""
        # Mock object with to_dict
        test_obj = Mock()
        test_obj.name = "test-domain"
        test_obj.uuid = None
        test_obj.fq_name = ["test-domain"]  # Real list
        test_obj.parent_obj = None
        test_obj.set_server_conn = Mock()
        test_obj.clear_pending_updates = Mock()

        obj_dict = {
            "name": "test-domain",
            "fq_name": ["test-domain"],
            "display_name": "Test Domain",
            "uuid": "generated-uuid"
        }
        test_obj.to_dict.return_value = obj_dict

        # Mock create response
        self.mock_api_client._http_create.return_value = {
            "domain": {"uuid": "server-uuid", "name": "test-domain"}
        }

        # Mock read response for verification
        self.mock_api_client._http_read.return_value = {
            "domain": {"uuid": "server-uuid", "name": "test-domain", "fq_name": ["test-domain"]}
        }

        # Mock hydration
        read_obj = Mock()
        read_obj.set_server_conn = Mock()
        read_obj.clear_pending_updates = Mock()

        with patch.object(self.api_lib, '_hydrate_object', return_value=read_obj):
            # Test create
            create_result = self.api_lib._object_create("domain", test_obj)

            # Test read back
            read_result = self.api_lib._object_read("domain", id="server-uuid")

        # ✅ FIX: Verify create data flow with domain_name AND api_key parameters
        self.mock_api_client._http_create.assert_called_once()
        call_args = self.mock_api_client._http_create.call_args
        self.assertEqual(call_args[0][0], "domain")
        # Verify payload has _encrypted field added
        expected_payload = obj_dict.copy()
        expected_payload['_encrypted'] = False
        self.assertEqual(call_args[0][1], expected_payload)
        self.assertEqual(call_args[1]['domain_name'], 'default-domain')
        self.assertEqual(call_args[1]['api_key'], None)  # ✅ FIXED: Added api_key check
        
        self.assertEqual(create_result, "server-uuid")
        self.assertEqual(test_obj.uuid, "server-uuid")  # Should be updated

        # ✅ FIX: Verify read data flow with domain_name AND api_key parameters
        self.mock_api_client._http_read.assert_called_once_with(
            "domain", "server-uuid", 
            domain_name='default-domain',
            api_key=None  # ✅ FIXED: Added api_key parameter
        )
        self.assertEqual(read_result, read_obj)

class TestApiClientNameNormalization(unittest.TestCase):
    """Test that ApiClient properly handles name normalization."""

    def setUp(self):
        """Set up test fixtures."""
        with patch('py_api_lib.api_client.requests.Session'):
            self.client = ApiClient(server_ip='localhost', port=8082)
            self.client.session = Mock()

    def test_email_name_preserved_in_create(self):
        """Test that email addresses in 'name' field are preserved during create."""
        # Mock response
        mock_response = Mock()
        mock_response.status_code = 201
        mock_response.json.return_value = {
            "user_account": {
                "uuid": "user-123",
                "name": "admin@test.com",
                "fq_name": ["test-domain", "default-project", "admin@test.com"]
            }
        }
        self.client._make_request = Mock(return_value=mock_response)

        # Payload with email as name
        payload = {
            "name": "admin@test.com",
            "fq_name": ["test-domain", "default-project", "admin@test.com"],
            "email": "admin@test.com"
        }

        result = self.client._http_create("user_account", payload, domain_name='test-domain')

        # Verify the payload sent to server has email preserved
        self.assertEqual(result["user_account"]["name"], "admin@test.com")
        self.assertEqual(result["user_account"]["fq_name"][-1], "admin@test.com")

    def test_regular_name_normalized_in_create(self):
        """Test that regular names (non-email) are normalized during create."""
        mock_response = Mock()
        mock_response.status_code = 201
        mock_response.json.return_value = {
            "domain": {
                "uuid": "domain-123",
                "name": "test-domain",
                "fq_name": ["test-domain"]
            }
        }
        self.client._make_request = Mock(return_value=mock_response)

        # Payload with regular name (should be normalized)
        payload = {
            "name": "Test Domain",
            "fq_name": ["Test Domain"]
        }

        result = self.client._http_create("domain", payload, domain_name='default-domain')

        # Verify normalized name
        self.assertEqual(result["domain"]["name"], "test-domain")
        self.assertEqual(result["domain"]["fq_name"][-1], "test-domain")

    def test_name_fqname_consistency_validation(self):
        """Test that name and fq_name last element must match after normalization."""
        mock_response = Mock()
        mock_response.status_code = 422
        mock_response.text = "Name doesn't match fq_name last element"
        mock_response.json.return_value = {
            "error": "ValidationException",
            "message": "Name 'admin_test.com' doesn't match fq_name last element 'admin@test.com'"
        }
        self.client._make_request = Mock(return_value=mock_response)
        
        # Payload with mismatched name and fq_name
        payload = {
            "name": "admin_test.com",  # Incorrectly normalized
            "fq_name": ["test-domain", "default-project", "admin@test.com"]  # Email preserved
        }
        
        with self.assertRaises(ValueError) as context:
            self.client._http_create("user_account", payload, domain_name='test-domain')
        
        error_message = str(context.exception)
        self.assertIn("Validation failed for user_account", error_message)
        self.assertIn("admin_test.com", error_message)
        self.assertIn("admin@test.com", error_message)


class TestApiLibNameNormalization(unittest.TestCase):
    """Test that ApiLib properly handles name normalization in objects."""

    def setUp(self):
        """Set up test fixtures."""
        with patch('py_api_lib.api_lib.ApiClient') as mock_client_class:
            self.mock_api_client = Mock()
            mock_client_class.return_value = self.mock_api_client
            self.api_lib = ApiLib(api_server_host='localhost', api_server_port='8082')

    def test_object_with_email_name_preserves_email(self):
        """Test that objects with email names preserve the email in both name and fq_name."""
        # Create object with email as name
        user_obj = Mock()
        user_obj.name = "admin@test.com"
        user_obj.email = "admin@test.com"
        user_obj.uuid = None
        user_obj.fq_name = ["test-domain", "default-project", "admin@test.com"]
        user_obj.parent_uuid = "project-123"
        user_obj.obj_type = "user_account"
        user_obj.set_server_conn = Mock()
        user_obj.clear_pending_updates = Mock()

        # Mock to_dict to return email-preserved data
        user_obj.to_dict.return_value = {
            "name": "admin@test.com",
            "fq_name": ["test-domain", "default-project", "admin@test.com"],
            "email": "admin@test.com",
            "parent_uuid": "project-123"
        }

        # Mock HTTP response
        self.mock_api_client._http_create.return_value = {
            "user_account": {"uuid": "user-456"}
        }

        # Call create
        result = self.api_lib._object_create("user_account", user_obj)

        # Verify payload sent to API client
        call_args = self.mock_api_client._http_create.call_args
        payload = call_args[0][1]

        # CRITICAL: name and fq_name[-1] must match
        self.assertEqual(payload["name"], "admin@test.com")
        self.assertEqual(payload["fq_name"][-1], "admin@test.com")
        self.assertEqual(payload["name"], payload["fq_name"][-1])

    def test_object_with_regular_name_normalizes_consistently(self):
        """Test that objects with regular names normalize consistently in name and fq_name."""
        # Create object with regular name (should be normalized)
        domain_obj = Mock()
        domain_obj.name = "My Test Domain"
        domain_obj.uuid = None
        domain_obj.fq_name = ["My Test Domain"]
        domain_obj.parent_obj = None
        domain_obj.obj_type = "domain"
        domain_obj.set_server_conn = Mock()
        domain_obj.clear_pending_updates = Mock()

        # Mock to_dict - assumes object internally normalizes
        domain_obj.to_dict.return_value = {
            "name": "my-test-domain",
            "fq_name": ["my-test-domain"],
            "display_name": "My Test Domain"
        }

        # Mock HTTP response
        self.mock_api_client._http_create.return_value = {
            "domain": {"uuid": "domain-789"}
        }

        # Call create
        result = self.api_lib._object_create("domain", domain_obj)

        # Verify payload
        call_args = self.mock_api_client._http_create.call_args
        payload = call_args[0][1]

        # CRITICAL: name and fq_name[-1] must match after normalization
        self.assertEqual(payload["name"], "my-test-domain")
        self.assertEqual(payload["fq_name"][-1], "my-test-domain")
        self.assertEqual(payload["name"], payload["fq_name"][-1])

    def test_object_name_fqname_mismatch_detected(self):
        """Test that mismatched name and fq_name are detected."""
        # Create object with mismatched name/fq_name
        user_obj = Mock()
        user_obj.name = "admin-test-com"  # Incorrectly normalized
        user_obj.email = "admin@test.com"
        user_obj.uuid = None
        user_obj.fq_name = ["test-domain", "default-project", "admin@test.com"]  # Correct
        user_obj.set_server_conn = Mock()
        user_obj.clear_pending_updates = Mock()

        # Mock to_dict returns mismatched data
        user_obj.to_dict.return_value = {
            "name": "admin-test-com",
            "fq_name": ["test-domain", "default-project", "admin@test.com"],
            "email": "admin@test.com"
        }

        # Mock HTTP error response
        self.mock_api_client._http_create.side_effect = Exception(
            "ValidationException: Name 'admin-test-com' doesn't match fq_name last element 'admin@test.com'"
        )

        # Call should raise exception
        with self.assertRaises(Exception) as context:
            self.api_lib._object_create("user_account", user_obj)

        self.assertIn("doesn't match", str(context.exception))

    def test_phone_number_name_preserved(self):
        """Test that phone numbers in name field are preserved."""
        obj = Mock()
        obj.name = "+1-555-1234"
        obj.uuid = None
        obj.fq_name = ["test-domain", "default-project", "+1-555-1234"]
        obj.set_server_conn = Mock()
        obj.clear_pending_updates = Mock()

        obj.to_dict.return_value = {
            "name": "+1-555-1234",
            "fq_name": ["test-domain", "default-project", "+1-555-1234"]
        }

        self.mock_api_client._http_create.return_value = {
            "test_object": {"uuid": "obj-123"}
        }

        result = self.api_lib._object_create("test_object", obj)

        call_args = self.mock_api_client._http_create.call_args
        payload = call_args[0][1]

        # Phone number preserved in both places
        self.assertEqual(payload["name"], "+1-555-1234")
        self.assertEqual(payload["fq_name"][-1], "+1-555-1234")
        self.assertEqual(payload["name"], payload["fq_name"][-1])

    def test_dots_and_underscores_preserved_in_name(self):
        """Test that dots and underscores are preserved in regular names."""
        obj = Mock()
        obj.name = "my_project.backup"
        obj.uuid = None
        obj.fq_name = ["test-domain", "my_project.backup"]
        obj.set_server_conn = Mock()
        obj.clear_pending_updates = Mock()

        obj.to_dict.return_value = {
            "name": "my_project.backup",
            "fq_name": ["test-domain", "my_project.backup"]
        }

        self.mock_api_client._http_create.return_value = {
            "project": {"uuid": "proj-123"}
        }

        result = self.api_lib._object_create("project", obj)

        call_args = self.mock_api_client._http_create.call_args
        payload = call_args[0][1]

        # Dots and underscores preserved
        self.assertEqual(payload["name"], "my_project.backup")
        self.assertEqual(payload["fq_name"][-1], "my_project.backup")

    def test_special_chars_normalized_in_name(self):
        """Test that special characters are normalized to hyphens."""
        obj = Mock()
        obj.name = "Test Project!"
        obj.uuid = None
        obj.fq_name = ["test-domain", "test-project"]
        obj.set_server_conn = Mock()
        obj.clear_pending_updates = Mock()

        obj.to_dict.return_value = {
            "name": "test-project",
            "fq_name": ["test-domain", "test-project"],
            "display_name": "Test Project!"
        }

        self.mock_api_client._http_create.return_value = {
            "project": {"uuid": "proj-456"}
        }

        result = self.api_lib._object_create("project", obj)

        call_args = self.mock_api_client._http_create.call_args
        payload = call_args[0][1]

        # Special chars normalized
        self.assertEqual(payload["name"], "test-project")
        self.assertEqual(payload["fq_name"][-1], "test-project")
        self.assertIn("display_name", payload)
        self.assertEqual(payload["display_name"], "Test Project!")


class TestApiLibNameNormalizationEdgeCases(unittest.TestCase):
    """Test edge cases in name normalization."""

    def setUp(self):
        """Set up test fixtures."""
        with patch('py_api_lib.api_lib.ApiClient') as mock_client_class:
            self.mock_api_client = Mock()
            mock_client_class.return_value = self.mock_api_client
            self.api_lib = ApiLib(api_server_host='localhost', api_server_port='8082')

    def test_email_with_plus_addressing(self):
        """Test that email with plus addressing is preserved."""
        obj = Mock()
        obj.name = "user+tag@example.com"
        obj.uuid = None
        obj.fq_name = ["domain", "project", "user+tag@example.com"]
        obj.set_server_conn = Mock()
        obj.clear_pending_updates = Mock()

        obj.to_dict.return_value = {
            "name": "user+tag@example.com",
            "fq_name": ["domain", "project", "user+tag@example.com"]
        }

        self.mock_api_client._http_create.return_value = {
            "user_account": {"uuid": "user-123"}
        }

        result = self.api_lib._object_create("user_account", obj)

        call_args = self.mock_api_client._http_create.call_args
        payload = call_args[0][1]

        # Email with + preserved
        self.assertEqual(payload["name"], "user+tag@example.com")
        self.assertEqual(payload["fq_name"][-1], "user+tag@example.com")

    def test_email_case_insensitive(self):
        """Test that email addresses are lowercased."""
        obj = Mock()
        obj.name = "Admin@Test.COM"
        obj.uuid = None
        obj.fq_name = ["domain", "project", "admin@test.com"]
        obj.set_server_conn = Mock()
        obj.clear_pending_updates = Mock()

        obj.to_dict.return_value = {
            "name": "admin@test.com",  # Lowercased
            "fq_name": ["domain", "project", "admin@test.com"]
        }

        self.mock_api_client._http_create.return_value = {
            "user_account": {"uuid": "user-456"}
        }

        result = self.api_lib._object_create("user_account", obj)

        call_args = self.mock_api_client._http_create.call_args
        payload = call_args[0][1]

        # Email lowercased consistently
        self.assertEqual(payload["name"], "admin@test.com")
        self.assertEqual(payload["fq_name"][-1], "admin@test.com")

    def test_multiple_consecutive_hyphens_collapsed(self):
        """Test that multiple hyphens are collapsed to single hyphen."""
        obj = Mock()
        obj.name = "test---project"
        obj.uuid = None
        obj.fq_name = ["domain", "test-project"]
        obj.set_server_conn = Mock()
        obj.clear_pending_updates = Mock()

        obj.to_dict.return_value = {
            "name": "test-project",
            "fq_name": ["domain", "test-project"]
        }

        self.mock_api_client._http_create.return_value = {
            "project": {"uuid": "proj-789"}
        }

        result = self.api_lib._object_create("project", obj)

        call_args = self.mock_api_client._http_create.call_args
        payload = call_args[0][1]

        # Multiple hyphens collapsed
        self.assertEqual(payload["name"], "test-project")
        self.assertEqual(payload["fq_name"][-1], "test-project")

    def test_leading_trailing_separators_stripped(self):
        """Test that leading/trailing separators are stripped."""
        obj = Mock()
        obj.name = "-test-project-"
        obj.uuid = None
        obj.fq_name = ["domain", "test-project"]
        obj.set_server_conn = Mock()
        obj.clear_pending_updates = Mock()

        obj.to_dict.return_value = {
            "name": "test-project",
            "fq_name": ["domain", "test-project"]
        }

        self.mock_api_client._http_create.return_value = {
            "project": {"uuid": "proj-111"}
        }

        result = self.api_lib._object_create("project", obj)

        call_args = self.mock_api_client._http_create.call_args
        payload = call_args[0][1]

        # Leading/trailing separators stripped
        self.assertEqual(payload["name"], "test-project")
        self.assertEqual(payload["fq_name"][-1], "test-project")

    def test_unicode_email_preserved(self):
        """Test that unicode characters in email are preserved (lowercased)."""
        obj = Mock()
        obj.name = "Café@example.com"
        obj.uuid = None
        obj.fq_name = ["domain", "project", "café@example.com"]
        obj.set_server_conn = Mock()
        obj.clear_pending_updates = Mock()

        obj.to_dict.return_value = {
            "name": "café@example.com",
            "fq_name": ["domain", "project", "café@example.com"]
        }

        self.mock_api_client._http_create.return_value = {
            "user_account": {"uuid": "user-222"}
        }

        result = self.api_lib._object_create("user_account", obj)

        call_args = self.mock_api_client._http_create.call_args
        payload = call_args[0][1]

        # Unicode email preserved
        self.assertEqual(payload["name"], "café@example.com")
        self.assertEqual(payload["fq_name"][-1], "café@example.com")
        self.assertIn("@", payload["name"])


class TestApiLibFQNameConsistency(unittest.TestCase):
    """Test that fq_name components are consistently normalized."""

    def setUp(self):
        """Set up test fixtures."""
        with patch('py_api_lib.api_lib.ApiClient') as mock_client_class:
            self.mock_api_client = Mock()
            mock_client_class.return_value = self.mock_api_client
            self.api_lib = ApiLib(api_server_host='localhost', api_server_port='8082')

    def test_fqname_all_components_normalized(self):
        """Test that all fq_name components follow normalization rules."""
        obj = Mock()
        obj.name = "Test Project"
        obj.uuid = None
        obj.fq_name = ["Test Domain", "Default Project", "test-project"]
        obj.set_server_conn = Mock()
        obj.clear_pending_updates = Mock()

        obj.to_dict.return_value = {
            "name": "test-project",
            "fq_name": ["test-domain", "default-project", "test-project"]
        }

        self.mock_api_client._http_create.return_value = {
            "project": {"uuid": "proj-333"}
        }

        result = self.api_lib._object_create("project", obj)

        call_args = self.mock_api_client._http_create.call_args
        payload = call_args[0][1]

        # All fq_name components normalized
        self.assertEqual(payload["fq_name"][0], "test-domain")
        self.assertEqual(payload["fq_name"][1], "default-project")
        self.assertEqual(payload["fq_name"][2], "test-project")

        # Last component matches name
        self.assertEqual(payload["name"], payload["fq_name"][-1])

    def test_fqname_with_mixed_types(self):
        """Test fq_name with domain (regular) and user (email)."""
        obj = Mock()
        obj.name = "admin@test.com"
        obj.uuid = None
        obj.fq_name = ["Test Domain", "default-project", "admin@test.com"]
        obj.set_server_conn = Mock()
        obj.clear_pending_updates = Mock()

        obj.to_dict.return_value = {
            "name": "admin@test.com",
            "fq_name": ["test-domain", "default-project", "admin@test.com"]
        }

        self.mock_api_client._http_create.return_value = {
            "user_account": {"uuid": "user-444"}
        }

        result = self.api_lib._object_create("user_account", obj)

        call_args = self.mock_api_client._http_create.call_args
        payload = call_args[0][1]

        # Domain normalized, project normalized, email preserved
        self.assertEqual(payload["fq_name"][0], "test-domain")
        self.assertEqual(payload["fq_name"][1], "default-project")
        self.assertEqual(payload["fq_name"][2], "admin@test.com")

        # Name matches last fq_name element
        self.assertEqual(payload["name"], payload["fq_name"][-1])


# Update the create_test_suite function to include all test classes
def create_test_suite():
    """Create comprehensive test suite for API client."""
    suite = unittest.TestSuite()

    # Add all test classes (existing + new)
    test_classes = [
        TestApiLibBasic,
        TestApiClientInit,
        TestApiClientHTTPOperations,
        TestApiClientCRUDOperations,
        TestApiClientHighLevelOperations,
        TestApiClientReferenceOperations,
        TestApiClientUtilityFunctions,
        TestApiClientUtilityHelpers,
        TestApiClientErrorHandling,
        TestApiClientContextManager,
        # New test classes for refactored ApiLib
        TestApiLibCRUDOperations,
        TestApiLibListBulkOperations,
        TestApiLibObjectHydration,
        TestApiLibDirectHTTPIntegration,
        # New test class for query functionality
        TestApiLibQueryOperations,
        # Name match
        TestApiClientNameNormalization,
        TestApiLibNameNormalization,
        TestApiLibNameNormalizationEdgeCases,
        TestApiLibFQNameConsistency,
    ]

    for test_class in test_classes:
        suite.addTest(unittest.TestLoader().loadTestsFromTestCase(test_class))

    return suite


if __name__ == '__main__':
    unittest.main()
