"""
Static contract tests for the services-ui layer of supero-ui.js and
supero-mobile.jsx. Each check encodes one finding from the services-ui
pre-integration review. Failure means the bug has regressed.

Each check is a module-level function returning (ok, message) so the
meta-test can call them against fixture files. The unittest TestCase
binds them to the live UI source files.
"""
from __future__ import annotations
import re
import unittest

# After flattening: this file lives in test/, helpers/fixtures live in test/ui/.
import os as _os
import sys as _sys
_sys.path.insert(0, _os.path.join(_os.path.dirname(_os.path.abspath(__file__)), 'ui'))

import _helpers as H


# ──────────────────────────────────────────────────────────────
# Reusable check functions
# ──────────────────────────────────────────────────────────────

def check_b1_drive_vs_gdrive(web_src, mobile_src):
    """Both platforms register the same Google Drive manifest key."""
    web_obj = H.balanced_object_after(web_src, r'var\s+SERVICE_MANIFESTS\s*=')
    mobile_obj = H.balanced_object_after(
        mobile_src, r'export\s+const\s+SERVICE_MANIFESTS\s*=')
    if not web_obj or not mobile_obj:
        return None, "could not locate SERVICE_MANIFESTS in one or both files"
    web = H.top_level_keys(web_obj)
    mobile = H.top_level_keys(mobile_obj)
    drive_match = ('drive' in web) == ('drive' in mobile)
    gdrive_match = ('gdrive' in web) == ('gdrive' in mobile)
    return (drive_match and gdrive_match), (
        f"web_drive={'drive' in web}, web_gdrive={'gdrive' in web}, "
        f"mobile_drive={'drive' in mobile}, mobile_gdrive={'gdrive' in mobile}"
    )


# Service names referenced from the LLM generator prompt. Must resolve
# to a manifest key on each platform or the generated app emits
# unknown-service errors at runtime.
PROMPT_SERVICES = [
    "ai", "amazon_s3", "auth_otp", "billing", "billing_paypal",
    "billing_razorpay", "bitbucket", "email", "email_smtp", "github",
    "google_ads", "google_calendar", "google_drive", "google_oauth",
    "google_reviews", "google_search", "instagram", "linkedin",
    "mcp_client", "mcp_server", "plaid", "push_notification",
    "quickbooks", "salesforce", "servicenow", "slack", "sms", "stripe",
    "whatsapp", "workflows", "x_social", "youtube",
]


def check_b2_prompt_services(web_src, mobile_src):
    web_obj = H.balanced_object_after(web_src, r'var\s+SERVICE_MANIFESTS\s*=')
    mobile_obj = H.balanced_object_after(
        mobile_src, r'export\s+const\s+SERVICE_MANIFESTS\s*=')
    if not web_obj or not mobile_obj:
        return None, "could not locate SERVICE_MANIFESTS"
    web = set(H.top_level_keys(web_obj))
    mobile = set(H.top_level_keys(mobile_obj))
    web_missing = [s for s in PROMPT_SERVICES if s not in web]
    mobile_missing = [s for s in PROMPT_SERVICES if s not in mobile]
    return (not web_missing and not mobile_missing), (
        f"web_missing={web_missing}, mobile_missing={mobile_missing}"
    )


def check_s1_url_protocol_whitelist(web_src):
    func = H.extract_block(
        web_src, r'function\s+_suiRenderOutputField\s*\(', r'\n\}\s*\n')
    if not func:
        return None, "could not locate _suiRenderOutputField"
    has_inline = bool(
        re.search(r'_?isSafeUrl\s*\(', func)
        # Match a JS regex literal of the form /^https?:\/\/  — note the
        # \? to match a literal ? in source (regex metachar otherwise).
        or re.search(r'/\^https\?:\\/\\/', func)
        or re.search(r'startsWith\s*\(\s*[\'"]https?', func)
    )
    has_helper = bool(
        re.search(r'function\s+_?isSafeUrl\s*\(', web_src)
        or re.search(r'(var|const|let)\s+_?isSafeUrl\s*=', web_src)
    )
    return (has_inline or has_helper), (
        f"inline_check={has_inline}, helper_declared={has_helper}"
    )


def check_s2_output_secret_masking(web_src, mobile_src):
    candidates = [
        r'OUTPUT_SECRET_FIELDS', r'OUTPUT_SENSITIVE_FIELDS',
        r'SECRET_OUTPUT_FIELDS', r'SENSITIVE_OUTPUT_FIELDS',
    ]
    web_has = any(re.search(p, web_src) for p in candidates)
    mobile_has = any(re.search(p, mobile_src) for p in candidates)
    near_masking = False
    combined = web_src + mobile_src
    for token in ('"auth"', "'auth'", '"link_token"', '"plaid_access_token"'):
        for m in re.finditer(re.escape(token), combined):
            window = combined[max(0, m.start() - 200): m.end() + 200]
            if re.search(r'mask|redact|•••|reveal|type\s*:\s*[\'"]password',
                         window, re.I):
                near_masking = True
                break
        if near_masking:
            break
    return (web_has or mobile_has or near_masking), (
        f"web_const={web_has}, mobile_const={mobile_has}, near={near_masking}"
    )


def check_s3_project_uuid_preflight(web_src, mobile_src):
    if "project_uuid not in mobile config" not in mobile_src:
        return None, "mobile guard fingerprint not found — message changed?"
    # We try several end-anchors in decreasing order of specificity. If
    # none match, fall back to scanning the whole file. Don't tie the
    # check to a single Unicode comment divider — that broke historically
    # whenever someone reformatted the file.
    web_block = (
        H.extract_block(web_src,
                        r'function\s+_ServiceActionForm\s*\(',
                        r'\n\}\s*\n\s*//\s*─── Register')
        or H.extract_block(web_src,
                           r'function\s+_ServiceActionForm\s*\(',
                           r'\n\}\s*\n\s*(//|/\*|function\s)')
        or web_src
    )
    has_guard = bool(
        re.search(r'project_uuid', web_block)
        and re.search(
            r'(if\s*\(\s*!\s*projectUuid)|'
            r'(project_uuid.{0,80}not\s+set)|'
            r'(project_uuid.{0,80}not\s+in\s+config)|'
            r'(setError\s*\([^)]*project_uuid)',
            web_block, re.I,
        )
    )
    return has_guard, f"web_has_preflight_guard={has_guard}"


def check_m5_dead_keymap_entries(web_src):
    web_obj = H.balanced_object_after(web_src, r'var\s+SERVICE_MANIFESTS\s*=')
    if not web_obj:
        return None, "could not extract SERVICE_MANIFESTS"
    web_keys = set(H.top_level_keys(web_obj))
    # Window of 2000 chars accommodates JSDoc + function signature +
    # whatever leading code the function has before declaring KEY_MAP.
    # If KEY_MAP is moved further away or renamed, we report inconclusive
    # rather than false-passing.
    key_map = H.balanced_object_after(
        web_src,
        r'function\s+_superoBackendIdForKey[\s\S]{0,2000}var\s+KEY_MAP\s*='
    )
    if not key_map:
        return None, "could not find KEY_MAP within 2000 chars of function"
    orphans = sorted(k for k in H.top_level_keys(key_map) if k not in web_keys)
    return (not orphans), f"orphan_keymap_entries={orphans}"


def check_m11_console_log_version(web_src):
    m_ver = re.search(
        r'window\.SUPERO_UI_VERSION\s*=\s*[\'"]([^\'"]+)[\'"]', web_src)
    m_log = re.search(
        r'\[supero-services-ui\]\s+v([\d.]+)\s+loaded', web_src)
    if not m_ver or not m_log:
        return None, (
            f"file_ver={m_ver and m_ver.group(1)}, "
            f"log_ver={m_log and m_log.group(1)}"
        )
    return (m_ver.group(1) == m_log.group(1)), (
        f"file={m_ver.group(1)}, log={m_log.group(1)}"
    )


def check_m18_flip_respects_intent(web_src):
    flip = H.extract_block(
        web_src,
        r'_flipModeAvailability\s*\(\)',
        r'\}\s*\)\s*\(\s*\)\s*;',
    )
    if not flip:
        return None, "could not locate _flipModeAvailability"
    has_arch = bool(re.search(r'archetypes', flip))
    has_pending = bool(
        re.search(r"modes\.action\s*===\s*['\"]pending['\"]", flip)
        and not re.search(r"!\s*entry\.modes\.action", flip)
    )
    return (has_arch or has_pending), (
        f"archetypes_check={has_arch}, pending_only={has_pending}"
    )


# ──────────────────────────────────────────────────────────────
# unittest binding — runs against the live UI source files
# ──────────────────────────────────────────────────────────────

class TestServicesUI(unittest.TestCase):
    """
    Note: setUpClass loads whichever sources exist. Tests that need only
    one platform will run even if the other is missing — only tests that
    require BOTH (B1, B2, S2, S3) will skip. This means a branch that
    only touches web still gets full web-side coverage.
    """

    @classmethod
    def setUpClass(cls):
        web_path, mobile_path = H.resolve_ui_sources()
        if web_path is None and mobile_path is None:
            raise unittest.SkipTest(
                "neither supero-ui.js nor supero-mobile.jsx found "
                "(set SUPERO_UI_JS / SUPERO_MOBILE_JSX or place them at "
                "infra/libs/py/src/supero/ui/)"
            )
        cls.web_src = H.read_or_none(web_path) if web_path else None
        cls.mobile_src = H.read_or_none(mobile_path) if mobile_path else None

    def _check(self, ok, msg, fid):
        if ok is None:
            self.skipTest(f"[{fid}] inconclusive: {msg}")
        self.assertTrue(ok, f"[{fid}] {msg}")

    def _need_web(self, fid):
        if self.web_src is None:
            self.skipTest(f"[{fid}] web source missing")

    def _need_mobile(self, fid):
        if self.mobile_src is None:
            self.skipTest(f"[{fid}] mobile source missing")

    def test_b1_drive_vs_gdrive(self):
        self._need_web("B1"); self._need_mobile("B1")
        self._check(*check_b1_drive_vs_gdrive(
            self.web_src, self.mobile_src), "B1")

    def test_b2_prompt_services_resolve(self):
        self._need_web("B2"); self._need_mobile("B2")
        self._check(*check_b2_prompt_services(
            self.web_src, self.mobile_src), "B2")

    def test_s1_url_protocol_whitelist(self):
        self._need_web("S1")
        self._check(*check_s1_url_protocol_whitelist(self.web_src), "S1")

    def test_s2_output_secret_masking(self):
        self._need_web("S2"); self._need_mobile("S2")
        self._check(*check_s2_output_secret_masking(
            self.web_src, self.mobile_src), "S2")

    def test_s3_project_uuid_preflight(self):
        self._need_web("S3"); self._need_mobile("S3")
        self._check(*check_s3_project_uuid_preflight(
            self.web_src, self.mobile_src), "S3")

    def test_m5_dead_keymap_entries(self):
        self._need_web("M5")
        self._check(*check_m5_dead_keymap_entries(self.web_src), "M5")

    #def test_m11_console_log_version(self):
        #self._need_web("M11")
        #self._check(*check_m11_console_log_version(self.web_src), "M11")

    def test_m18_flip_respects_intent(self):
        self._need_web("M18")
        self._check(*check_m18_flip_respects_intent(self.web_src), "M18")


if __name__ == "__main__":
    unittest.main()
