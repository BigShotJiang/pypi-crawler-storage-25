"""
Edge Cases and Error Scenario Tests for Supero API
Tests unusual inputs, boundary conditions, and error handling.
"""

import unittest
from unittest.mock import Mock, MagicMock, patch
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '../src'))

from mock_server import mock_server
from supero import Supero, quickstart


class TestEdgeCases(unittest.TestCase):
    """Test edge cases and boundary conditions."""
    
    def setUp(self):
        """Setup test fixtures."""
        mock_server.reset()
    
    def test_empty_object_creation(self):
        """Test creating object with minimal data."""
        response = mock_server.mock_create_response('project', {})
        
        self.assertIn('project', response)
        self.assertIsNotNone(response['project']['uuid'])
    
    def test_object_with_none_values(self):
        """Test handling None values."""
        data = {
            'name': 'Test',
            'status': None,
            'priority': None,
            'description': None
        }
        
        response = mock_server.mock_create_response('project', data)
        self.assertIsNotNone(response)
    
    def test_object_with_empty_strings(self):
        """Test handling empty strings."""
        data = {
            'name': '',
            'status': '',
            'description': ''
        }
        
        response = mock_server.mock_create_response('project', data)
        self.assertEqual(response['project']['name'], '')
    
    def test_very_long_strings(self):
        """Test handling very long string values."""
        long_string = 'x' * 10000
        data = {
            'name': 'Test',
            'description': long_string
        }
        
        response = mock_server.mock_create_response('project', data)
        uuid = response['project']['uuid']
        
        # Check the stored object (create response only returns uuid+name)
        stored_obj = mock_server.objects_store['project'][uuid]
        self.assertEqual(len(stored_obj['description']), 10000)
    
    def test_special_characters_in_name(self):
        """Test special characters in object names."""
        special_names = [
            'Project@#$%',
            'Project™®©',
            'Проект',  # Cyrillic
            '项目',     # Chinese
            'プロジェクト',  # Japanese
            'Test\nNew\nLine',
            'Test\tTab'
        ]
        
        for name in special_names:
            response = mock_server.mock_create_response('project', {'name': name})
            self.assertEqual(response['project']['name'], name)
    
    def test_numeric_edge_values(self):
        """Test numeric edge values."""
        test_cases = [
            {'priority': 0},
            {'priority': -1},
            {'priority': 999999},
            {'budget': 0.01},
            {'budget': -100.50},
            {'budget': 1e10}
        ]
        
        for data in test_cases:
            data['name'] = 'Test'
            response = mock_server.mock_create_response('project', data)
            self.assertIsNotNone(response)
    
    def test_deeply_nested_data(self):
        """Test handling deeply nested data structures."""
        nested_data = {
            'name': 'Test',
            'metadata': {
                'level1': {
                    'level2': {
                        'level3': {
                            'level4': {
                                'value': 'deep'
                            }
                        }
                    }
                }
            }
        }
        
        response = mock_server.mock_create_response('project', nested_data)
        uuid = response['project']['uuid']
        
        # Check the stored object (create response only returns uuid+name)
        stored_obj = mock_server.objects_store['project'][uuid]
        self.assertEqual(
            stored_obj['metadata']['level1']['level2']['level3']['level4']['value'],
            'deep'
        )
    
    def test_large_list_attributes(self):
        """Test handling large list attributes."""
        data = {
            'name': 'Test',
            'tags': [f'tag-{i}' for i in range(1000)],
            'assignees': [f'user-{i}' for i in range(500)]
        }
        
        response = mock_server.mock_create_response('project', data)
        uuid = response['project']['uuid']
        
        # Check the stored object (create response only returns uuid+name)
        stored_obj = mock_server.objects_store['project'][uuid]
        self.assertEqual(len(stored_obj['tags']), 1000)
        self.assertEqual(len(stored_obj['assignees']), 500)
    
    def test_boolean_variations(self):
        """Test various boolean representations."""
        test_cases = [
            {'active': True},
            {'active': False},
            {'active': 1},
            {'active': 0},
            {'active': 'true'},
            {'active': 'false'}
        ]
        
        for data in test_cases:
            data['name'] = 'Test'
            response = mock_server.mock_create_response('project', data)
            self.assertIsNotNone(response)
    
    def test_duplicate_uuid_handling(self):
        """Test handling duplicate UUIDs."""
        uuid1 = mock_server.add_object('project', {'name': 'First'})
        
        # Try to add another object with same UUID
        data = {'name': 'Second', 'uuid': uuid1}
        uuid2 = mock_server.add_object('project', data)
        
        # Should overwrite or handle appropriately
        self.assertEqual(uuid1, uuid2)


class TestErrorConditions(unittest.TestCase):
    """Test error conditions and failure scenarios."""
    
    def setUp(self):
        """Setup test fixtures."""
        mock_server.reset()
    
    def test_read_missing_object(self):
        """Test reading non-existent object."""
        result = mock_server.mock_read_response('project', 'missing-uuid-12345')
        self.assertIsNone(result)
    
    def test_update_missing_object(self):
        """Test updating non-existent object."""
        response = mock_server.mock_update_response(
            'project',
            'missing-uuid',
            {'status': 'active'}
        )
        
        # Should return response but object won't exist in store
        self.assertIsNotNone(response)
    
    def test_delete_missing_object(self):
        """Test deleting non-existent object."""
        result = mock_server.mock_delete_response('project', 'missing-uuid')
        self.assertFalse(result)
    
    def test_delete_already_deleted(self):
        """Test deleting already deleted object."""
        uuid = mock_server.add_object('project', {'name': 'Test'})
        
        # First delete
        result1 = mock_server.mock_delete_response('project', uuid)
        self.assertTrue(result1)
        
        # Second delete
        result2 = mock_server.mock_delete_response('project', uuid)
        self.assertFalse(result2)
    
    def test_list_nonexistent_type(self):
        """Test listing non-existent object type."""
        result = mock_server.mock_list_response('nonexistent-type')
        result = result.get("objects") or []
        self.assertEqual(result, [])
    
    def test_bulk_list_empty_uuids(self):
        """Test bulk list with empty UUID list."""
        mock_server.add_object('project', {'name': 'Test1'})
        mock_server.add_object('project', {'name': 'Test2'})
        
        response = mock_server.mock_list_bulk_response('project', [])
        response = response.get("objects") or []
        
        # Should return all objects when no UUIDs specified
        self.assertGreater(len(response), 0)
    
    def test_bulk_list_nonexistent_uuids(self):
        """Test bulk list with non-existent UUIDs."""
        mock_server.add_object('project', {'name': 'Test1'})
        
        response = mock_server.mock_list_bulk_response('project', ['fake-1', 'fake-2'])

        response = response.get("objects") or []
        
        # Should return empty list
        self.assertEqual(len(response), 0)
    
    def test_bulk_list_mixed_valid_invalid(self):
        """Test bulk list with mix of valid and invalid UUIDs."""
        valid_uuid = mock_server.add_object('project', {'name': 'Valid'})
        
        response = mock_server.mock_list_bulk_response(
            'project',
            [valid_uuid, 'invalid-1', 'invalid-2']
        )

        response = response.get("objects") or []
        
        # Should return only valid object
        self.assertEqual(len(response), 1)
        self.assertEqual(response[0]['uuid'], valid_uuid)


class TestConcurrency(unittest.TestCase):
    """Test concurrent operation scenarios."""
    
    def setUp(self):
        """Setup test fixtures."""
        mock_server.reset()
    
    def test_simultaneous_creates(self):
        """Test multiple simultaneous create operations."""
        # Simulate concurrent creates
        responses = []
        for i in range(10):
            response = mock_server.mock_create_response('project', {
                'name': f'Concurrent-{i}'
            })
            responses.append(response)
        
        # All should succeed with unique UUIDs
        uuids = [r['project']['uuid'] for r in responses]
        self.assertEqual(len(uuids), len(set(uuids)))  # All unique
    
    def test_concurrent_updates(self):
        """Test concurrent updates to same object."""
        uuid = mock_server.add_object('project', {
            'name': 'Test',
            'status': 'planning'
        })
        
        # Simulate concurrent updates
        mock_server.mock_update_response('project', uuid, {'status': 'active'})
        mock_server.mock_update_response('project', uuid, {'priority': 10})
        mock_server.mock_update_response('project', uuid, {'status': 'completed'})
        
        # Last update should win
        obj = mock_server.objects_store['project'][uuid]
        self.assertEqual(obj['status'], 'completed')
        self.assertEqual(obj['priority'], 10)
    
    def test_read_during_update(self):
        """Test reading object while it's being updated."""
        uuid = mock_server.add_object('project', {'name': 'Test', 'status': 'planning'})
        
        # Read initial state
        read1 = mock_server.mock_read_response('project', uuid)
        initial_status = read1['project'].get('status')
        
        # Update
        mock_server.mock_update_response('project', uuid, {'status': 'active'})
        
        # Read again
        read2 = mock_server.mock_read_response('project', uuid)
        updated_status = read2['project'].get('status')
        
        # Should see the update
        self.assertEqual(initial_status, 'planning')
        self.assertEqual(updated_status, 'active')
        self.assertNotEqual(initial_status, updated_status)


class TestDataIntegrity(unittest.TestCase):
    """Test data integrity and consistency."""
    
    def setUp(self):
        """Setup test fixtures."""
        mock_server.reset()
    
    def test_update_preserves_other_fields(self):
        """Test that update preserves unchanged fields."""
        uuid = mock_server.add_object('project', {
            'name': 'Test',
            'status': 'active',
            'priority': 10,
            'budget': 100000
        })
        
        # Update only status
        mock_server.mock_update_response('project', uuid, {'status': 'completed'})
        
        # Verify other fields preserved
        obj = mock_server.objects_store['project'][uuid]
        self.assertEqual(obj['name'], 'Test')
        self.assertEqual(obj['priority'], 10)
        self.assertEqual(obj['budget'], 100000)
        self.assertEqual(obj['status'], 'completed')
    
    def test_create_generates_unique_uuids(self):
        """Test that creates always generate unique UUIDs."""
        uuids = set()
        
        for i in range(100):
            response = mock_server.mock_create_response('project', {
                'name': f'Project-{i}'
            })
            uuid = response['project']['uuid']
            self.assertNotIn(uuid, uuids)
            uuids.add(uuid)
        
        self.assertEqual(len(uuids), 100)
    
    def test_delete_cascades_properly(self):
        """Test that delete removes object completely."""
        # Create object with nested data
        uuid = mock_server.add_object('project', {
            'name': 'Test',
            'team': [{'user_id': 'u1'}, {'user_id': 'u2'}],
            'metadata': {'key': 'value'}
        })
        
        # Delete
        result = mock_server.mock_delete_response('project', uuid)
        self.assertTrue(result)
        
        # Verify completely removed
        self.assertNotIn(uuid, mock_server.objects_store.get('project', {}))
        
        # Subsequent operations should fail
        read_result = mock_server.mock_read_response('project', uuid)
        self.assertIsNone(read_result)
    
    def test_object_type_consistency(self):
        """Test object type consistency across operations."""
        # Create as project
        response = mock_server.mock_create_response('project', {'name': 'Test'})
        uuid = response['project']['uuid']
        
        # Read should maintain type
        read_response = mock_server.mock_read_response('project', uuid)
        self.assertIn('project', read_response)
        
        # Update should maintain type
        update_response = mock_server.mock_update_response('project', uuid, {})
        self.assertIn('project', update_response)


class TestReferenceIntegrity(unittest.TestCase):
    """Test reference and relationship integrity."""
    
    def setUp(self):
        """Setup test fixtures."""
        mock_server.reset()
    
    def test_dangling_reference_after_delete(self):
        """Test handling dangling references after deletion."""
        # Create objects
        project_uuid = mock_server.add_object('project', {'name': 'Project'})
        user_uuid = mock_server.add_object('user', {'name': 'User'})
        
        # Add reference
        project = mock_server.objects_store['project'][project_uuid]
        project['team'] = [{'user_uuid': user_uuid}]
        
        # Delete user
        mock_server.mock_delete_response('user', user_uuid)
        
        # Project still has reference (dangling)
        # Application should handle this
        self.assertEqual(len(project['team']), 1)
        self.assertEqual(project['team'][0]['user_uuid'], user_uuid)
    
    def test_circular_reference_handling(self):
        """Test handling circular references."""
        uuid1 = mock_server.add_object('project', {'name': 'Project1'})
        uuid2 = mock_server.add_object('project', {'name': 'Project2'})
        
        # Create circular references
        obj1 = mock_server.objects_store['project'][uuid1]
        obj2 = mock_server.objects_store['project'][uuid2]
        
        obj1['related_project'] = uuid2
        obj2['related_project'] = uuid1
        
        # Should not cause infinite loops
        read1 = mock_server.mock_read_response('project', uuid1)
        read2 = mock_server.mock_read_response('project', uuid2)
        
        self.assertIsNotNone(read1)
        self.assertIsNotNone(read2)
    
    def test_reference_count_tracking(self):
        """Test tracking reference counts."""
        # Create user
        user_uuid = mock_server.add_object('user', {'name': 'Alice'})
        
        # Create projects referencing user
        project_uuids = []
        for i in range(5):
            uuid = mock_server.add_object('project', {
                'name': f'Project-{i}',
                'owner': user_uuid
            })
            project_uuids.append(uuid)
        
        # Count references
        response = mock_server.mock_list_response('project')
        all_projects = response.get('objects', [])
        ref_count = sum(
            1 for p in all_projects
            if p.get('owner') == user_uuid
        )
        
        self.assertEqual(ref_count, 5)


class TestStateTransitions(unittest.TestCase):
    """Test state transitions and lifecycle."""
    
    def setUp(self):
        """Setup test fixtures."""
        mock_server.reset()
    
    def test_project_lifecycle_states(self):
        """Test project progressing through lifecycle states."""
        states = ['planning', 'active', 'on-hold', 'active', 'completed', 'archived']
        
        # Create project
        response = mock_server.mock_create_response('project', {
            'name': 'Test',
            'status': states[0]
        })
        uuid = response['project']['uuid']
        
        # Transition through states
        for state in states[1:]:
            mock_server.mock_update_response('project', uuid, {'status': state})
            
            obj = mock_server.objects_store['project'][uuid]
            self.assertEqual(obj['status'], state)
    
    def test_invalid_state_transition(self):
        """Test handling invalid state transitions."""
        # Create project in completed state
        uuid = mock_server.add_object('project', {
            'name': 'Test',
            'status': 'completed'
        })
        
        # Try to transition back to planning (might be invalid)
        # Mock server doesn't enforce this, but application should
        mock_server.mock_update_response('project', uuid, {'status': 'planning'})
        
        # Update succeeds (validation is application responsibility)
        obj = mock_server.objects_store['project'][uuid]
        self.assertEqual(obj['status'], 'planning')
    
    def test_multiple_field_transitions(self):
        """Test transitioning multiple fields simultaneously."""
        uuid = mock_server.add_object('project', {
            'name': 'Test',
            'status': 'planning',
            'progress': 0
        })
        
        # Update multiple fields
        updates = [
            {'status': 'active', 'progress': 25},
            {'progress': 50},
            {'progress': 75},
            {'status': 'completed', 'progress': 100}
        ]
        
        for update in updates:
            mock_server.mock_update_response('project', uuid, update)
        
        # Verify final state
        obj = mock_server.objects_store['project'][uuid]
        self.assertEqual(obj['status'], 'completed')
        self.assertEqual(obj['progress'], 100)


if __name__ == '__main__':
    unittest.main(verbosity=2)
