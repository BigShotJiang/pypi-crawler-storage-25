"""
Tests for the tenantNoun extraction regex used in Phase 2 of app generation.

The regex lives in app_generation_service.py and pulls LLM-emitted
tenantNoun values out of ui/app.js so they can override the Phase 1
heuristic written into .env.

These tests pin:
  - Single and double quote handling
  - Whitespace / newline tolerance
  - Empty-value rejection (prevents accidentally writing empty labels)
  - Key-order requirement (singular before plural — must match prompt rule 22)
"""

import re
import unittest

# Keep in sync with the regex in app_generation_service.py. If you change
# one, change the other — and update these tests to match.
TENANT_NOUN_REGEX = (
    r"""tenantNoun\s*:\s*\{\s*"""
    r"""singular\s*:\s*["']([^"']+)["']\s*,\s*"""
    r"""plural\s*:\s*["']([^"']+)["']"""
)


class TestTenantNounExtraction(unittest.TestCase):

    def test_extract_single_quotes(self):
        appjs = "AppShell.render({ tenantNoun: { singular: 'Salon', plural: 'Salons' } });"
        m = re.search(TENANT_NOUN_REGEX, appjs)
        self.assertIsNotNone(m)
        self.assertEqual(m.group(1), 'Salon')
        self.assertEqual(m.group(2), 'Salons')

    def test_extract_double_quotes(self):
        appjs = 'AppShell.render({ tenantNoun: { singular: "Firm", plural: "Firms" } });'
        m = re.search(TENANT_NOUN_REGEX, appjs)
        self.assertIsNotNone(m)
        self.assertEqual(m.group(1), 'Firm')
        self.assertEqual(m.group(2), 'Firms')

    def test_extract_with_newlines_and_spaces(self):
        appjs = """
        AppShell.render({
            tenantNoun: {
                singular: 'Studio',
                plural: 'Studios',
            }
        });
        """
        m = re.search(TENANT_NOUN_REGEX, appjs)
        self.assertIsNotNone(m)
        self.assertEqual(m.group(1), 'Studio')
        self.assertEqual(m.group(2), 'Studios')

    def test_absent_returns_none(self):
        appjs = "AppShell.render({ signupMode: 'open' });"
        self.assertIsNone(re.search(TENANT_NOUN_REGEX, appjs))

    def test_empty_string_values_do_not_match(self):
        # Guard: [^"']+ requires >= 1 char. Empty labels must not reach .env.
        appjs = "tenantNoun: { singular: '', plural: '' }"
        self.assertIsNone(re.search(TENANT_NOUN_REGEX, appjs))

    def test_reversed_order_does_not_match(self):
        # Pins current behavior: plural-before-singular is not supported.
        # Prompt rule 22 prescribes singular-first. If the LLM violates that,
        # we fall back to the Phase 1 heuristic (which is safer than guessing).
        appjs = "tenantNoun: { plural: 'Salons', singular: 'Salon' }"
        self.assertIsNone(re.search(TENANT_NOUN_REGEX, appjs))

    def test_extract_picks_first_match_when_multiple(self):
        # If the LLM somehow emits multiple tenantNoun blocks, we take the first.
        appjs = (
            "tenantNoun: { singular: 'Salon', plural: 'Salons' } "
            "tenantNoun: { singular: 'Firm', plural: 'Firms' }"
        )
        m = re.search(TENANT_NOUN_REGEX, appjs)
        self.assertIsNotNone(m)
        self.assertEqual(m.group(1), 'Salon')

    def test_mixed_quotes_across_keys(self):
        # LLM might emit single quotes for one key and double for the other.
        appjs = """tenantNoun: { singular: "Clinic", plural: 'Clinics' }"""
        m = re.search(TENANT_NOUN_REGEX, appjs)
        self.assertIsNotNone(m)
        self.assertEqual(m.group(1), 'Clinic')
        self.assertEqual(m.group(2), 'Clinics')


if __name__ == "__main__":
    unittest.main()
