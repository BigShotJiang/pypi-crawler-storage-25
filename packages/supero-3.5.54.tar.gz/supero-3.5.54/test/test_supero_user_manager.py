"""
Unit Tests for UserManager v2.0 - Context-Aware Architecture

CHANGES in v2.0:
- NO domain_name parameter in __init__
- NO domain_uuid parameter in methods
- Domain extracted from platform_client automatically
- All methods support api_key parameter for RBAC
"""
import unittest
from unittest.mock import Mock, MagicMock, patch
import sys
import os

# Add src to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '../src'))

from supero.user_manager import UserManager
from supero.platform_client import (
    PlatformClient,
    AuthenticationError,
    AuthorizationError
)

# ============================================================================
# Mock Platform Client
# ============================================================================

class MockPlatformClient:
    """Mock PlatformClient for testing"""
    
    def __init__(self, domain_name="test-domain", domain_uuid="uuid-123"):
        self.domain_name = domain_name
        self.domain_uuid = domain_uuid
        self.base_url = "http://localhost:8083/api/v1"
        self._responses = {}
        self.project_name = "test-project"
        self.project_uuid = "project-uuid-456"
        self.tenant_name = "test-tenant"
        self.tenant_uuid = "tenant-uuid-789"
        self.user_uuid = "user-uuid-abc"
        self.user_email = "test@example.com"
        self.username = "testuser"
        self.role = "admin"
    
    def set_response(self, endpoint, response):
        """Set mock response for endpoint"""
        self._responses[endpoint] = response
    
    def post(self, endpoint, json=None, **kwargs):
        """Mock POST request"""
        if endpoint in self._responses:
            return self._responses[endpoint]
        return {"success": True}
    
    def get(self, endpoint, params=None, **kwargs):
        """Mock GET request"""
        if endpoint in self._responses:
            return self._responses[endpoint]
        return {"results": []}
    
    def put(self, endpoint, json=None, **kwargs):
        """Mock PUT request"""
        if endpoint in self._responses:
            return self._responses[endpoint]
        return {"updated": True}
    
    def delete(self, endpoint, **kwargs):
        """Mock DELETE request"""
        if endpoint in self._responses:
            return self._responses[endpoint]
        return {"deleted": True}


# ============================================================================
# Initialization Tests (v2.0)
# ============================================================================

class TestUserManagerInit(unittest.TestCase):
    """Test UserManager initialization"""
    
    def test_init_extracts_domain_from_client(self):
        """Test initialization extracts domain from platform_client"""
        mock_client = MockPlatformClient(
            domain_name="acme-corp",
            domain_uuid="acme-uuid-123"
        )
        
        # NEW in v2.0: NO domain_name parameter!
        user_mgr = UserManager(platform_client=mock_client)
        
        # Domain extracted from client
        self.assertEqual(user_mgr.domain_name, "acme-corp")
        self.assertEqual(user_mgr.domain_uuid, "acme-uuid-123")
    
    def test_init_with_different_domains(self):
        """Test initialization works with any domain"""
        mock_client = MockPlatformClient(
            domain_name="different-org",
            domain_uuid="different-uuid"
        )
        
        user_mgr = UserManager(platform_client=mock_client)
        
        self.assertEqual(user_mgr.domain_name, "different-org")
        self.assertEqual(user_mgr.domain_uuid, "different-uuid")
    
    def test_init_stores_client_reference(self):
        """Test initialization stores client reference"""
        mock_client = MockPlatformClient()
        
        user_mgr = UserManager(platform_client=mock_client)
        
        self.assertIs(user_mgr.client, mock_client)


# ============================================================================
# Add User Tests (v2.0)
# ============================================================================

class TestUserManagerAddUser(unittest.TestCase):
    """Test add_user functionality"""
    
    def setUp(self):
        self.mock_client = MockPlatformClient(
            domain_name="test-domain",
            domain_uuid="domain-uuid-123"
        )
        self.user_mgr = UserManager(platform_client=self.mock_client)
    
    def test_add_user_no_domain_uuid_parameter(self):
        """Test add_user NO LONGER requires domain_uuid parameter"""
        # Setup mock response
        self.mock_client.set_response(
            "/users/register",
            {
                "user": {
                    "user_uuid": "new-user-uuid",
                    "email": "dev@test.com",
                    "role": "tenant_user"
                }
            }
        )
        
        # NEW in v2.0: NO domain_uuid parameter!
        result = self.user_mgr.add_user(
            email="dev@test.com",
            password="Pass123!",
            first_name="John",
            last_name="Developer"
        )
        
        self.assertEqual(result["user"]["email"], "dev@test.com")
        self.assertEqual(result["user"]["role"], "tenant_user")
    
    def test_add_user_uses_domain_from_client(self):
        """Test add_user uses domain from platform_client"""
        # Create spy to track POST calls
        original_post = self.mock_client.post
        post_calls = []
        
        def spy_post(endpoint, json=None, **kwargs):
            post_calls.append({"endpoint": endpoint, "json": json})
            return original_post(endpoint, json, **kwargs)
        
        self.mock_client.post = spy_post
        
        # Add user
        self.user_mgr.add_user(
            email="test@example.com",
            password="Pass123!"
        )
        
        # Verify domain_uuid was included in request
        self.assertEqual(len(post_calls), 1)
        self.assertEqual(post_calls[0]["json"]["domain_uuid"], "domain-uuid-123")
    
    def test_add_user_with_api_key_rbac(self):
        """Test add_user with api_key parameter for RBAC"""
        post_calls = []
        
        def spy_post(endpoint, json=None, **kwargs):
            post_calls.append({"endpoint": endpoint, "json": json, "kwargs": kwargs})
            return {"user": {"user_uuid": "new-uuid"}}
        
        self.mock_client.post = spy_post
        
        # NEW in v2.0: api_key parameter for RBAC
        self.user_mgr.add_user(
            email="admin@test.com",
            password="AdminPass!",
            role="tenant_admin",
            api_key="ak_admin_key_123"
        )
        
        # Verify api_key was passed
        self.assertEqual(post_calls[0]["kwargs"]["api_key"], "ak_admin_key_123")
    
    def test_add_user_validates_email(self):
        """Test add_user validates email"""
        with self.assertRaises(ValueError) as ctx:
            self.user_mgr.add_user(
                email="",  # Empty email
                password="Pass123!"
            )
        
        self.assertIn("email", str(ctx.exception).lower())
    
    def test_add_user_validates_password(self):
        """Test add_user validates password"""
        with self.assertRaises(ValueError) as ctx:
            self.user_mgr.add_user(
                email="test@example.com",
                password=""  # Empty password
            )
        
        self.assertIn("password", str(ctx.exception).lower())
    
    def test_add_user_with_permissions(self):
        """Test add_user with custom permissions"""
        post_calls = []
        
        def spy_post(endpoint, json=None, **kwargs):
            post_calls.append(json)
            return {"user": {"user_uuid": "uuid"}}
        
        self.mock_client.post = spy_post
        
        self.user_mgr.add_user(
            email="dev@test.com",
            password="Pass123!",
            permissions=["project:read", "project:write", "task:read"]
        )
        
        # Verify permissions were passed
        self.assertEqual(
            post_calls[0]["permissions"],
            ["project:read", "project:write", "task:read"]
        )


# ============================================================================
# List Users Tests (v2.0)
# ============================================================================

class TestUserManagerListUsers(unittest.TestCase):
    """Test list_users functionality"""
    
    def setUp(self):
        self.mock_client = MockPlatformClient(
            domain_name="test-domain",
            domain_uuid="domain-uuid-123"
        )
        self.user_mgr = UserManager(platform_client=self.mock_client)
    
    def test_list_users_no_domain_uuid_parameter(self):
        """Test list_users NO LONGER requires domain_uuid parameter"""
        # Setup mock response
        self.mock_client.set_response(
            "/domains/domain-uuid-123/users",
            {
                "users": [
                    {"user_uuid": "uuid-1", "email": "user1@test.com"},
                    {"user_uuid": "uuid-2", "email": "user2@test.com"}
                ]
            }
        )
        
        # NEW in v2.0: NO domain_uuid parameter!
        result = self.user_mgr.list_users(domain_uuid="domain-uuid-123")
        
        self.assertEqual(len(result["users"]), 2)
    
    def test_list_users_with_role_filter(self):
        """Test list_users with role filter"""
        get_calls = []
        
        def spy_get(endpoint, params=None, **kwargs):
            get_calls.append({"endpoint": endpoint, "params": params})
            return {"users": []}
        
        self.mock_client.get = spy_get
        
        self.user_mgr.list_users(role="tenant_admin")
        
        # Verify role filter was passed
        self.assertEqual(get_calls[0]["params"]["role"], "tenant_admin")
    
    def test_list_users_with_api_key(self):
        """Test list_users with api_key for RBAC"""
        get_calls = []
        
        def spy_get(endpoint, params=None, **kwargs):
            get_calls.append({"endpoint": endpoint, "kwargs": kwargs})
            return {"users": []}
        
        self.mock_client.get = spy_get
        
        # NEW in v2.0: api_key parameter
        self.user_mgr.list_users(api_key="ak_user_key_123")
        
        # Verify api_key was passed
        self.assertEqual(get_calls[0]["kwargs"]["api_key"], "ak_user_key_123")


# ============================================================================
# Get User Tests (v2.0)
# ============================================================================

class TestUserManagerGetUser(unittest.TestCase):
    """Test get_user functionality"""
    
    def setUp(self):
        self.mock_client = MockPlatformClient()
        self.user_mgr = UserManager(platform_client=self.mock_client)
    
    def test_get_user_by_uuid(self):
        """Test getting user by UUID"""
        self.mock_client.set_response(
            "/users/user-uuid-123",
            {
                "user": {
                    "user_uuid": "user-uuid-123",
                    "email": "test@example.com",
                    "role": "tenant_user"
                }
            }
        )
        
        result = self.user_mgr.get_user("user-uuid-123")
        
        self.assertEqual(result["user"]["user_uuid"], "user-uuid-123")
    
    def test_get_user_with_api_key(self):
        """Test get_user with api_key"""
        get_calls = []
        
        def spy_get(endpoint, **kwargs):
            get_calls.append(kwargs)
            return {"user": {}}
        
        self.mock_client.get = spy_get
        
        self.user_mgr.get_user("user-uuid-123", api_key="ak_key")
        
        self.assertEqual(get_calls[0]["api_key"], "ak_key")


# ============================================================================
# Update User Tests (v2.0)
# ============================================================================

class TestUserManagerUpdateUser(unittest.TestCase):
    """Test update_user functionality"""
    
    def setUp(self):
        self.mock_client = MockPlatformClient()
        self.user_mgr = UserManager(platform_client=self.mock_client)
    
    def test_update_user_role(self):
        """Test updating user role"""
        put_calls = []
        
        def spy_put(endpoint, json=None, **kwargs):
            put_calls.append({"endpoint": endpoint, "json": json})
            return {"updated": True}
        
        self.mock_client.put = spy_put
        
        self.user_mgr.update_user("user-uuid-123", role="tenant_admin")
        
        # Verify role update
        self.assertIn("/users/user-uuid-123", put_calls[0]["endpoint"])
        self.assertEqual(put_calls[0]["json"]["role"], "tenant_admin")
    
    def test_update_user_with_api_key(self):
        """Test update_user with api_key"""
        put_calls = []
        
        def spy_put(endpoint, json=None, **kwargs):
            put_calls.append(kwargs)
            return {"updated": True}
        
        self.mock_client.put = spy_put
        
        self.user_mgr.update_user(
            "user-uuid-123",
            role="tenant_admin",
            api_key="ak_admin_key"
        )
        
        self.assertEqual(put_calls[0]["api_key"], "ak_admin_key")


# ============================================================================
# Enable/Disable User Tests (v2.0)
# ============================================================================

class TestUserManagerEnableDisable(unittest.TestCase):
    """Test enable_user and disable_user functionality"""
    
    def setUp(self):
        self.mock_client = MockPlatformClient()
        self.user_mgr = UserManager(platform_client=self.mock_client)
    
    def test_enable_user(self):
        """Test enabling user"""
        put_calls = []
        
        def spy_put(endpoint, **kwargs):
            put_calls.append(endpoint)
            return {"enabled": True}
        
        self.mock_client.put = spy_put
        
        self.user_mgr.enable_user("user-uuid-123")
        
        self.assertIn("/users/user-uuid-123/enable", put_calls[0])
    
    def test_disable_user(self):
        """Test disabling user"""
        put_calls = []
        
        def spy_put(endpoint, **kwargs):
            put_calls.append(endpoint)
            return {"disabled": True}
        
        self.mock_client.put = spy_put
        
        self.user_mgr.disable_user("user-uuid-123")
        
        self.assertIn("/users/user-uuid-123/disable", put_calls[0])
    
    def test_enable_user_with_api_key(self):
        """Test enable_user with api_key"""
        put_calls = []
        
        def spy_put(endpoint, **kwargs):
            put_calls.append(kwargs)
            return {"enabled": True}
        
        self.mock_client.put = spy_put
        
        self.user_mgr.enable_user("user-uuid-123", api_key="ak_admin")
        
        self.assertEqual(put_calls[0]["api_key"], "ak_admin")


# ============================================================================
# Whoami Tests (v2.0)
# ============================================================================

class TestUserManagerWhoami(unittest.TestCase):
    """Test whoami functionality"""
    
    def setUp(self):
        self.mock_client = MockPlatformClient()
        self.user_mgr = UserManager(platform_client=self.mock_client)
    
    def test_whoami(self):
        """Test getting current user info"""
        self.mock_client.set_response(
            "/auth/me",
            {
                "user": {
                    "user_uuid": "current-user",
                    "email": "current@example.com"
                }
            }
        )
        
        result = self.user_mgr.whoami()
        
        self.assertEqual(result["user"]["email"], "current@example.com")
    
    def test_whoami_with_api_key(self):
        """Test whoami with api_key"""
        get_calls = []
        
        def spy_get(endpoint, **kwargs):
            get_calls.append(kwargs)
            return {"user": {}}
        
        self.mock_client.get = spy_get
        
        self.user_mgr.whoami(api_key="ak_user_key")
        
        self.assertEqual(get_calls[0]["api_key"], "ak_user_key")


# ============================================================================
# Error Handling Tests
# ============================================================================

class TestUserManagerErrors(unittest.TestCase):
    """Test error handling"""
    
    def setUp(self):
        self.mock_client = MockPlatformClient()
        self.user_mgr = UserManager(platform_client=self.mock_client)
    
    def test_add_user_authentication_error(self):
        """Test add_user with authentication error"""
        def raise_auth_error(*args, **kwargs):
            raise AuthenticationError("Invalid token")
        
        self.mock_client.post = raise_auth_error
        
        with self.assertRaises(AuthenticationError):
            self.user_mgr.add_user(
                email="test@example.com",
                password="Pass123!"
            )
    
    def test_list_users_authorization_error(self):
        """Test list_users with authorization error"""
        def raise_authz_error(*args, **kwargs):
            raise AuthorizationError("Permission denied")
        
        self.mock_client.get = raise_authz_error
        
        with self.assertRaises(AuthorizationError):
            self.user_mgr.list_users()


# ============================================================================
# Integration Tests (v2.0)
# ============================================================================

class TestUserManagerIntegration(unittest.TestCase):
    """Integration tests for UserManager"""
    
    def setUp(self):
        self.mock_client = MockPlatformClient(
            domain_name="acme-corp",
            domain_uuid="acme-uuid"
        )
        self.user_mgr = UserManager(platform_client=self.mock_client)
    
    def test_complete_user_lifecycle(self):
        """Test complete user lifecycle"""
        # Add user
        self.mock_client.set_response(
            "/users/register",
            {"user": {"user_uuid": "new-uuid", "email": "dev@acme.com"}}
        )
        
        user = self.user_mgr.add_user(
            email="dev@acme.com",
            password="Pass123!",
            first_name="John"
        )
        
        self.assertEqual(user["user"]["email"], "dev@acme.com")
        
        # Update user
        self.mock_client.set_response(
            "/users/new-uuid/role",
            {"updated": True, "role": "tenant_admin"}
        )
        
        updated = self.user_mgr.update_user("new-uuid", role="tenant_admin")
        
        self.assertTrue(updated["updated"])
        
        # Disable user
        self.mock_client.set_response(
            "/users/new-uuid/disable",
            {"success": True, "disabled": True}
        )
        
        result = self.user_mgr.disable_user("new-uuid")
        
        self.assertTrue(result)


if __name__ == '__main__':
    unittest.main(verbosity=2)
