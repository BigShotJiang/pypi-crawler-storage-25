"""
test_bootstrap.py — Unit tests for supero.bootstrap module

Location: ~/supero/platform/infra/libs/py/test/test_bootstrap.py

Run:
    python -m pytest test_bootstrap.py -v
    python -m unittest test_bootstrap -v

Coverage:
    - Happy path: new domain, existing domain, schemas, tenants, users, custom project
    - Result fields: org, api_key, counts, success property
    - Edge cases: login failure, partial schema failure, fail_fast, empty inputs
    - Idempotency: all-skipped run succeeds cleanly
    - Interface: module-level import, print_summary()
"""

import io
import os
import sys
import unittest
from unittest.mock import MagicMock, patch, call


# ---------------------------------------------------------------------------
# Test helpers
# ---------------------------------------------------------------------------

def _make_org_mock(domain_name="test-domain"):
    """
    Create a minimal Supero instance mock.

    Mirrors create_mock_platform_client() style from test_supero_core.py.
    """
    org = MagicMock()
    org.domain_name  = domain_name
    org._domain_uuid = "domain-uuid-123"
    org.project_uuid = "project-uuid-456"
    org.tenant_uuid  = "tenant-uuid-789"
    org.tenant_name  = "default-tenant"
    org.jwt_token    = "eyJ.jwt.token"
    return org


def _make_reg_response(status: int, api_key: str = "ak_domain_test_...",
                        domain_uuid: str = "domain-uuid-123",
                        project_uuid: str = "project-uuid-456",
                        tenant_uuid: str  = "tenant-uuid-789") -> dict:
    """Build a fake /api/v1/auth/register response dict."""
    return {
        "_status_code": status,
        "auth": {
            "access_token": "eyJ.access.token",
            "api_key": api_key,
        },
        "context": {
            "domain_uuid":  domain_uuid,
            "project_uuid": project_uuid,
            "tenant_uuid":  tenant_uuid,
            "tenant":       "default-tenant",
        },
        "idempotent": (status == 200),
    }


def _make_login_response(api_key: str = "ak_domain_login_...") -> dict:
    """Build a fake /api/v1/auth/login response dict (for api_key fetch)."""
    return {
        "_status_code": 200,
        "auth": {
            "access_token": "eyJ.access.token",
            "api_key": api_key,
        },
        "context": {
            "domain_uuid":  "domain-uuid-123",
            "project_uuid": "project-uuid-456",
            "tenant_uuid":  "tenant-uuid-789",
            "tenant":       "default-tenant",
        },
    }


def _make_project_response(name: str = "my-app", uuid: str = "proj-uuid-abc",
                            api_key: str = "ak_proj_...") -> dict:
    """Build a fake create_project() response dict (from crud_routes.py)."""
    return {
        "success": True,
        "uuid":    uuid,
        "name":    name,
        "fq_name": ["test-domain", name],
        "default_tenant_uuid": "tenant-uuid-789",
        "default_tenant_name": "default-tenant",
        "api_key": {"key": api_key, "uuid": "key-uuid-xyz"},
    }


def _make_schema_upload_response(uploaded: int = 3, skipped: int = 0,
                                  updated: int = 0, failed: int = 0) -> dict:
    """Build a fake schema upload response dict (from schema_routes.py)."""
    return {
        "success": True,
        "schemas": [],
        "failed":  [],
        "skipped": [],
        "summary": {
            "total":    uploaded + skipped + updated + failed,
            "uploaded": uploaded,
            "updated":  updated,
            "skipped":  skipped,
            "failed":   failed,
        },
    }


def _make_crud_success(uuid: str = "obj-uuid-001") -> dict:
    """Build a generic create_object() success response (from crud_routes.py)."""
    return {
        "success": True,
        "data":    {"uuid": uuid, "name": "test-object"},
    }


def _make_crud_exists_error() -> dict:
    """Build a create_object() 'already exists' error (idempotent case)."""
    return {
        "success": False,
        "error":   "Create Failed: Object already exists",
    }

def _make_user_reg_success() -> dict:
    """Build a /users/register success response.
    Route returns {'message': 'User registered successfully', ...}
    NOT the old CRUD shape {'success': True, 'uuid': ...}.
    """
    return {
        "message": "User registered successfully",
        "email":   "user@example.com",
        "role":    "tenant_user",
    }


def _make_user_reg_exists() -> dict:
    """Build a /users/register already-exists error response.
    Our already_exists check: 'exist'|'duplicate'|'already' in error_msg.lower()
    """
    return {
        "error":   "User already exists",
        "message": "User already exists",
    }


def _make_fqn_response(uuid: str = "proj-uuid-abc") -> dict:
    """Build a fq-name-to-uuid response."""
    return {"success": True, "uuid": uuid}


# Shared schema list used across tests
SAMPLE_SCHEMAS = [
    {
        "name": "Customer",
        "namespace": "test-domain",
        "schema_type": "object",
        "parent_type": "tenant",
        "attributes": [{"name": "company_name", "type": "string"}],
    },
    {
        "name": "Order",
        "namespace": "test-domain",
        "schema_type": "object",
        "parent_type": "tenant",
        "attributes": [{"name": "total", "type": "float"}],
    },
]

SAMPLE_TENANTS = [
    {"name": "team-alpha", "display_name": "Team Alpha"},
    {"name": "team-beta",  "display_name": "Team Beta"},
]

SAMPLE_USERS = [
    {
        "email":     "alice@test.com",
        "password":  "Password123!",
        "role":      "tenant_admin",
        "full_name": "Alice Smith",
        "tenant":    "team-alpha",
    },
    {
        "email":    "bob@test.com",
        "password": "Password123!",
        "role":     "tenant_user",
        "tenant":   "team-alpha",
    },
]


# ---------------------------------------------------------------------------
# Helper: standard patch stack that all bootstrap tests need
#
# PATCHING STRATEGY — two gotchas to avoid:
#
# Gotcha 1 — "supero.bootstrap" resolves to the function, not the module.
#   supero/__init__.py does `from .bootstrap import bootstrap, BootstrapResult`,
#   setting the bootstrap FUNCTION as the `bootstrap` attribute on the supero
#   package object. Any string-based patch or import that resolves via package
#   attribute lookup (e.g. patch("supero.bootstrap._http_post"), or
#   `import supero.bootstrap as X`) finds the function, not the submodule.
#
# Gotcha 2 — module-level sys.modules capture is unreliable in test suites.
#   Depending on test runner import order, sys.modules['supero.bootstrap'] may
#   or may not be populated when this file's module-level code runs.
#
# SOLUTION: use importlib.import_module('supero.bootstrap') INSIDE each helper
#   at call time. importlib always returns the MODULE (it uses sys.modules
#   internally but bypasses package attribute shadowing), and it is safe to
#   call repeatedly — it returns the cached module on subsequent calls.
#
# For Supero.login: patch on 'supero.core.Supero.login' — the class's home.
#   bootstrap.py imports Supero lazily inside _bootstrap(), so Supero is never
#   a module-level attribute of bootstrap.py. Patching on core reaches it
#   regardless of where Supero is imported inside the function at runtime.
# ---------------------------------------------------------------------------

def _get_bootstrap_module():
    """Return the supero.bootstrap MODULE (never the shadowed function)."""
    import importlib
    return importlib.import_module('supero.bootstrap')


def _patch_supero_login(org_mock):
    """Patch Supero.login where it lives (supero.core), not via bootstrap."""
    return patch("supero.core.Supero.login", return_value=org_mock)


def _patch_http_post(responses: list):
    """
    Patch _http_post on the bootstrap MODULE using importlib at call time.
    Avoids the package-attribute shadowing that makes string-based patch fail.
    """
    return patch.object(
        _get_bootstrap_module(),
        "_http_post",
        side_effect=responses,
    )


# ---------------------------------------------------------------------------
# Happy-path tests
# ---------------------------------------------------------------------------



# ─────────────────────────────────────────────────────────────────
# Test isolation: clear shell SUPERO_* env vars so tests don't pick up
# the developer's real api-key / domain / project from their shell.
# Without this, pre_api_key = os.getenv("SUPERO_API_KEY") reads the
# real shell value instead of empty, which flips bootstrap into the
# "skip register+login" fast-path and breaks new-domain tests.
# ─────────────────────────────────────────────────────────────────
_SUPERO_TEST_ISOLATION = {}

def _isolate_supero_env():
    """Pop all SUPERO_* env vars and return them for later restoration."""
    saved = {}
    for k in list(os.environ):
        if k.startswith("SUPERO_"):
            saved[k] = os.environ.pop(k)
    return saved

def _restore_supero_env(saved):
    """Restore previously popped SUPERO_* env vars."""
    for k, v in saved.items():
        os.environ[k] = v

class _BootstrapTestBase(unittest.TestCase):
    """Base class that isolates SUPERO_* env vars for the duration of each test."""
    def setUp(self):
        self._saved_supero_env = _isolate_supero_env()
        super().setUp()
    def tearDown(self):
        _restore_supero_env(self._saved_supero_env)
        super().tearDown()

class TestBootstrapNewDomain(_BootstrapTestBase):
    """Tests for bootstrapping a brand-new domain (registration returns 201)."""

    def _run_bootstrap(self, **kwargs):
        """Run bootstrap with sensible defaults, returning (result, org_mock)."""
        from supero.bootstrap import bootstrap
        kwargs.setdefault("project_name", "test-project")

        org_mock = _make_org_mock()
        # Step 3 of bootstrap creates the project via org.post(). Use the
        # SAME uuid and api_key as the registration response so assertions
        # about result.project_uuid and result.api_key remain consistent
        # whether they read from registration or from project creation.
        org_mock.post.return_value = _make_project_response(
            uuid="project-uuid-456",
            api_key="ak_domain_test_...",
        )
        http_responses = [
            _make_reg_response(201),      # Step 1: register → success
            _make_login_response(),        # Step 2: api_key fetch
        ]

        with _patch_http_post(http_responses):
            with _patch_supero_login(org_mock):
                result = bootstrap(
                    domain_name    = "test-domain",
                    admin_email    = "admin@test.com",
                    admin_password = "Admin123!",
                    **kwargs,
                )
        return result, org_mock

    def test_new_domain_returns_bootstrap_result(self):
        """bootstrap() returns a BootstrapResult."""
        from supero.bootstrap import BootstrapResult
        result, _ = self._run_bootstrap()
        self.assertIsInstance(result, BootstrapResult)

    def test_new_domain_success(self):
        """result.success is True when no errors."""
        result, _ = self._run_bootstrap()
        self.assertTrue(result.success)

    def test_new_domain_result_has_org(self):
        """result.org is the Supero instance from login."""
        result, org_mock = self._run_bootstrap()
        self.assertIs(result.org, org_mock)

    def test_new_domain_api_key_from_registration(self):
        """result.api_key comes from auth.api_key in registration response, not jwt."""
        result, org_mock = self._run_bootstrap()
        # Should be the value from reg response, not org_mock.jwt_token
        self.assertEqual(result.api_key, "ak_domain_test_...")
        self.assertNotEqual(result.api_key, org_mock.jwt_token)

    def test_new_domain_captures_domain_uuid(self):
        """result.domain_uuid is set from registration context."""
        result, _ = self._run_bootstrap()
        self.assertEqual(result.domain_uuid, "domain-uuid-123")

    def test_new_domain_captures_project_uuid(self):
        """result.project_uuid is set from registration context."""
        result, _ = self._run_bootstrap()
        self.assertEqual(result.project_uuid, "project-uuid-456")

    def test_new_domain_captures_tenant_uuid(self):
        """result.tenant_uuid is set from registration context."""
        result, _ = self._run_bootstrap()
        self.assertEqual(result.tenant_uuid, "tenant-uuid-789")

    def test_new_domain_no_errors(self):
        """result.errors is empty on clean run."""
        result, _ = self._run_bootstrap()
        self.assertEqual(result.errors, [])

    def test_new_domain_login_scoped_to_project_name(self):
        """Supero.login() is always called with project='default-project'."""
        from supero.bootstrap import bootstrap

        org_mock = _make_org_mock()
        http_responses = [_make_reg_response(201), _make_login_response()]

        with _patch_http_post(http_responses):
            with patch("supero.core.Supero.login", return_value=org_mock) as mock_login:
                bootstrap(
                    domain_name    = "test-domain",
                    admin_email    = "admin@test.com",
                    admin_password = "Admin123!",
                    project_name   = "my-app",   # custom — but login must use default
                )

        mock_login.assert_called_once()
        _, kwargs = mock_login.call_args
        # Updated v1.5.48: login scoped to project_name for project-scoped api_key
        self.assertEqual(kwargs.get("project", mock_login.call_args[0][3] if len(mock_login.call_args[0]) > 3 else None),
                         "my-app")


class TestBootstrapExistingDomain(_BootstrapTestBase):
    """Tests for bootstrapping a domain that already exists (409 → login)."""

    def _run_bootstrap(self, **kwargs):
        from supero.bootstrap import bootstrap
        kwargs.setdefault("project_name", "test-project")
        org_mock = _make_org_mock()
        # Step 3 of bootstrap creates the project via org.post(). Use the
        # SAME api_key as the login response so assertions about
        # result.api_key remain consistent.
        org_mock.post.return_value = _make_project_response(
            uuid="project-uuid-456",
            api_key="ak_existing_domain_...",
        )
        # Step 1: 409 (domain exists)
        # Step 2: raw login call to fetch api_key
        http_responses = [
            _make_reg_response(409),
            _make_login_response(api_key="ak_existing_domain_..."),
        ]
        with _patch_http_post(http_responses):
            with _patch_supero_login(org_mock):
                result = bootstrap(
                    domain_name    = "test-domain",
                    admin_email    = "admin@test.com",
                    admin_password = "Admin123!",
                    **kwargs,
                )
        return result, org_mock

    def test_existing_domain_succeeds(self):
        """Bootstrap of existing domain succeeds (idempotent)."""
        result, _ = self._run_bootstrap()
        self.assertTrue(result.success)

    def test_existing_domain_api_key_from_login(self):
        """result.api_key comes from login response auth.api_key for existing domains."""
        result, org_mock = self._run_bootstrap()
        self.assertEqual(result.api_key, "ak_existing_domain_...")
        self.assertNotEqual(result.api_key, org_mock.jwt_token)

    def test_existing_domain_no_errors(self):
        """No errors on idempotent re-registration."""
        result, _ = self._run_bootstrap()
        self.assertEqual(result.errors, [])


class TestBootstrapWithSchemas(_BootstrapTestBase):
    """Tests for schema upload during bootstrap."""

    def _run_with_schema_response(self, upload_resp: dict):
        from supero.bootstrap import bootstrap
        org_mock = _make_org_mock()
        org_mock.post.return_value = upload_resp

        http_responses = [_make_reg_response(201), _make_login_response()]
        with _patch_http_post(http_responses):
            with _patch_supero_login(org_mock):
                result = bootstrap(
                    domain_name    = "test-domain",
                    admin_email    = "admin@test.com",
                    admin_password = "Admin123!",
                    project_name  = "test-project",
                    schemas        = SAMPLE_SCHEMAS,
                )
        return result, org_mock

    def test_schemas_uploaded(self):
        """result.schemas_uploaded reflects summary.uploaded from upload response."""
        result, _ = self._run_with_schema_response(
            _make_schema_upload_response(uploaded=2)
        )
        self.assertEqual(result.schemas_uploaded, 2)

    def test_schemas_skipped(self):
        """result.schemas_skipped reflects summary.skipped."""
        result, _ = self._run_with_schema_response(
            _make_schema_upload_response(uploaded=0, skipped=2)
        )
        self.assertEqual(result.schemas_skipped, 2)

    def test_schemas_updated(self):
        """result.schemas_updated reflects summary.updated."""
        result, _ = self._run_with_schema_response(
            _make_schema_upload_response(uploaded=0, updated=2)
        )
        self.assertEqual(result.schemas_updated, 2)

    def test_schema_upload_sends_correct_payload(self):
        """Schema upload POST includes domain_name, schemas, skip_existing."""
        from supero.bootstrap import bootstrap
        org_mock = _make_org_mock()
        org_mock.post.return_value = _make_schema_upload_response(uploaded=2)

        http_responses = [_make_reg_response(201), _make_login_response()]
        with _patch_http_post(http_responses):
            with _patch_supero_login(org_mock):
                bootstrap(
                    domain_name    = "test-domain",
                    admin_email    = "admin@test.com",
                    admin_password = "Admin123!",
                    project_name  = "test-project",
                    schemas        = SAMPLE_SCHEMAS,
                )

        # Find the schema upload call
        schema_call = None
        for c in org_mock.post.call_args_list:
            if "/schemas/upload" in str(c):
                schema_call = c
                break
        self.assertIsNotNone(schema_call, "Expected a /schemas/upload POST call")
        _, call_kwargs = schema_call
        payload = call_kwargs.get("json", {})
        self.assertEqual(payload.get("domain_name"), "test-domain")
        self.assertEqual(payload.get("schemas"), SAMPLE_SCHEMAS)
        self.assertTrue(payload.get("skip_existing"))

    def test_no_schemas_skips_upload(self):
        """When schemas=None, no POST to /schemas/upload is made."""
        from supero.bootstrap import bootstrap
        org_mock = _make_org_mock()

        http_responses = [_make_reg_response(201), _make_login_response()]
        with _patch_http_post(http_responses):
            with _patch_supero_login(org_mock):
                bootstrap(
                    domain_name    = "test-domain",
                    admin_email    = "admin@test.com",
                    admin_password = "Admin123!",
                    project_name  = "test-project",
                    schemas        = None,
                )

        calls = [str(c) for c in org_mock.post.call_args_list]
        self.assertFalse(
            any("/schemas/upload" in c for c in calls),
            "No schema upload call expected when schemas=None"
        )

    def test_partial_schema_failure_adds_error(self):
        """Partial schema failure (some failed) adds to result.errors."""
        result, _ = self._run_with_schema_response(
            _make_schema_upload_response(uploaded=1, failed=1)
        )
        self.assertEqual(result.schemas_failed, 1)
        self.assertTrue(len(result.errors) > 0)
        self.assertFalse(result.success)


class TestBootstrapWithTenants(_BootstrapTestBase):
    """Tests for tenant creation during bootstrap."""

    def _run_with_tenant_responses(self, tenant_responses: list):
        from supero.bootstrap import bootstrap
        org_mock = _make_org_mock()

        call_count = [0]
        def _post_side_effect(path, json=None):
            if "tenant" in path:
                resp = tenant_responses[min(call_count[0], len(tenant_responses)-1)]
                call_count[0] += 1
                return resp
            return _make_crud_success()

        org_mock.post.side_effect = _post_side_effect

        http_responses = [_make_reg_response(201), _make_login_response()]
        with _patch_http_post(http_responses):
            with _patch_supero_login(org_mock):
                result = bootstrap(
                    domain_name    = "test-domain",
                    admin_email    = "admin@test.com",
                    admin_password = "Admin123!",
                    project_name  = "test-project",
                    tenants        = SAMPLE_TENANTS,
                )
        return result

    def test_tenants_created(self):
        """result.tenants_created counts successful tenant creations."""
        result = self._run_with_tenant_responses([
            _make_crud_success("tenant-1"),
            _make_crud_success("tenant-2"),
        ])
        self.assertEqual(result.tenants_created, 2)
        self.assertEqual(result.tenants_skipped, 0)

    def test_tenants_skipped_when_exists(self):
        """Already-existing tenants are counted as skipped (idempotent)."""
        result = self._run_with_tenant_responses([
            _make_crud_exists_error(),
            _make_crud_exists_error(),
        ])
        self.assertEqual(result.tenants_skipped, 2)
        self.assertEqual(result.tenants_created, 0)
        self.assertTrue(result.success)

    def test_no_tenants_skips_step(self):
        """When tenants=None, no tenant POST calls are made."""
        from supero.bootstrap import bootstrap
        org_mock = _make_org_mock()

        http_responses = [_make_reg_response(201), _make_login_response()]
        with _patch_http_post(http_responses):
            with _patch_supero_login(org_mock):
                bootstrap(
                    domain_name    = "test-domain",
                    admin_email    = "admin@test.com",
                    admin_password = "Admin123!",
                    project_name  = "test-project",
                    tenants        = None,
                )

        calls = [str(c) for c in org_mock.post.call_args_list]
        self.assertFalse(
            any("/tenant" in c for c in calls),
            "No tenant creation call expected when tenants=None"
        )


class TestBootstrapWithUsers(_BootstrapTestBase):
    """Tests for user creation during bootstrap."""

    def _run_with_user_responses(self, user_responses: list):
        from supero.bootstrap import bootstrap
        org_mock = _make_org_mock()

        call_count = [0]
        def _post_side_effect(path, json=None):
            if "users/register" in path:
                resp = user_responses[min(call_count[0], len(user_responses)-1)]
                call_count[0] += 1
                return resp
            return _make_crud_success()

        org_mock.post.side_effect = _post_side_effect

        http_responses = [_make_reg_response(201), _make_login_response()]
        with _patch_http_post(http_responses):
            with _patch_supero_login(org_mock):
                result = bootstrap(
                    domain_name    = "test-domain",
                    admin_email    = "admin@test.com",
                    admin_password = "Admin123!",
                    project_name  = "test-project",
                    users          = SAMPLE_USERS,
                )
        return result

    def test_users_created(self):
        """result.users_created counts successful user creations."""
        result = self._run_with_user_responses([
            _make_user_reg_success(),
            _make_user_reg_success(),
        ])
        self.assertEqual(result.users_created, 2)
        self.assertEqual(result.users_skipped, 0)

    def test_users_skipped_when_exists(self):
        """Already-existing users are counted as skipped."""
        result = self._run_with_user_responses([
            _make_user_reg_exists(),
            _make_user_reg_exists(),
        ])
        self.assertEqual(result.users_skipped, 2)
        self.assertEqual(result.users_created, 0)
        self.assertTrue(result.success)

    def test_user_payload_has_plaintext_password(self):
        """User creation payload sends 'password' not 'password_hash'."""
        from supero.bootstrap import bootstrap
        org_mock = _make_org_mock()
        org_mock.post.return_value = _make_user_reg_success()

        http_responses = [_make_reg_response(201), _make_login_response()]
        with _patch_http_post(http_responses):
            with _patch_supero_login(org_mock):
                bootstrap(
                    domain_name    = "test-domain",
                    admin_email    = "admin@test.com",
                    admin_password = "Admin123!",
                    project_name  = "test-project",
                    users          = [SAMPLE_USERS[0]],
                )

        user_call = None
        for c in org_mock.post.call_args_list:
            if "users/register" in str(c):
                user_call = c
                break
        self.assertIsNotNone(user_call)
        _, call_kwargs = user_call
        payload = call_kwargs.get("json", {})
        self.assertIn("password", payload)
        self.assertNotIn("password_hash", payload)
        self.assertEqual(payload["password"], SAMPLE_USERS[0]["password"])

    def test_user_payload_has_explicit_tenant_uuid(self):
        """User creation payload sends explicit tenant_uuid + tenant_name (not parent_context)."""
        from supero.bootstrap import bootstrap
        org_mock = _make_org_mock()
        org_mock.post.return_value = _make_user_reg_success()

        http_responses = [_make_reg_response(201), _make_login_response()]
        with _patch_http_post(http_responses):
            with _patch_supero_login(org_mock):
                bootstrap(
                    domain_name    = "test-domain",
                    admin_email    = "admin@test.com",
                    admin_password = "Admin123!",
                    project_name  = "test-project",
                    users          = [SAMPLE_USERS[0]],
                )

        user_call = None
        for c in org_mock.post.call_args_list:
            if "users/register" in str(c):
                user_call = c
                break
        _, call_kwargs = user_call
        payload = call_kwargs.get("json", {})
        # New payload uses explicit UUIDs, not parent_context hint
        self.assertIn("tenant_name", payload)
        self.assertIn("tenant_uuid", payload)
        self.assertIn("project_uuid", payload)
        self.assertIn("domain_name", payload)
        self.assertNotIn("parent_context", payload)

    def test_user_missing_email_skipped_with_error(self):
        """User dict without email is skipped and added to result.errors."""
        from supero.bootstrap import bootstrap
        org_mock = _make_org_mock()

        http_responses = [_make_reg_response(201), _make_login_response()]
        with _patch_http_post(http_responses):
            with _patch_supero_login(org_mock):
                result = bootstrap(
                    domain_name    = "test-domain",
                    admin_email    = "admin@test.com",
                    admin_password = "Admin123!",
                    project_name  = "test-project",
                    users          = [{"role": "admin"}],   # no email, no password
                )

        self.assertEqual(result.users_created, 0)
        self.assertTrue(len(result.errors) > 0)

    def test_no_users_skips_step(self):
        """When users=None, no user-account POST calls are made."""
        from supero.bootstrap import bootstrap
        org_mock = _make_org_mock()

        http_responses = [_make_reg_response(201), _make_login_response()]
        with _patch_http_post(http_responses):
            with _patch_supero_login(org_mock):
                bootstrap(
                    domain_name    = "test-domain",
                    admin_email    = "admin@test.com",
                    admin_password = "Admin123!",
                    project_name  = "test-project",
                    users          = None,
                )

        calls = [str(c) for c in org_mock.post.call_args_list]
        self.assertFalse(any("user-account" in c for c in calls))


class TestBootstrapCustomProject(_BootstrapTestBase):
    """Tests for custom project_name (not default-project)."""

    def _run(self, project_resp=None, **kwargs):
        from supero.bootstrap import bootstrap
        org_mock = _make_org_mock()

        def _post_side_effect(path, json=None):
            if path == f"/crud/test-domain/project":
                return project_resp or _make_project_response()
            if "fq-name-to-uuid" in path:
                return _make_fqn_response()
            return _make_crud_success()

        org_mock.post.side_effect = _post_side_effect
        org_mock.switch_project = MagicMock()

        http_responses = [_make_reg_response(201), _make_login_response()]
        with _patch_http_post(http_responses):
            with _patch_supero_login(org_mock):
                result = bootstrap(
                    domain_name    = "test-domain",
                    admin_email    = "admin@test.com",
                    admin_password = "Admin123!",
                    project_name   = "my-app",
                    **kwargs,
                )
        return result, org_mock

    def test_custom_project_created(self):
        """Custom project is created when project_name != default-project."""
        result, org_mock = self._run()
        # Verify project creation POST was made
        project_calls = [
            c for c in org_mock.post.call_args_list
            if "/crud/test-domain/project" in str(c)
        ]
        self.assertEqual(len(project_calls), 1)

    def test_custom_project_api_key_captured(self):
        """api_key from project creation is captured if no registration key."""
        from supero.bootstrap import bootstrap
        org_mock = _make_org_mock()
        org_mock.switch_project = MagicMock()

        def _post_side_effect(path, json=None):
            if "/project" in path:
                return _make_project_response(api_key="ak_proj_from_create_...")
            if "fq-name-to-uuid" in path:
                return _make_fqn_response()
            return _make_crud_success()
        org_mock.post.side_effect = _post_side_effect

        # Existing domain — no api_key from registration
        http_responses = [
            _make_reg_response(409),
            {"_status_code": 200, "auth": {"api_key": ""}},  # login returns empty key
        ]
        with _patch_http_post(http_responses):
            with _patch_supero_login(org_mock):
                result = bootstrap(
                    domain_name    = "test-domain",
                    admin_email    = "admin@test.com",
                    admin_password = "Admin123!",
                    project_name   = "my-app",
                )

        # Should have captured api_key from project creation
        self.assertEqual(result.api_key, "ak_proj_from_create_...")

    def test_switch_project_called_after_creation(self):
        """switch_project() is called after the project is created."""
        result, org_mock = self._run()
        org_mock.switch_project.assert_called_once_with(project_name="my-app")

    def test_login_scoped_to_project_name(self):
        """Supero.login() is called with project='default-project', not 'my-app'."""
        from supero.bootstrap import bootstrap
        org_mock = _make_org_mock()
        org_mock.switch_project = MagicMock()
        org_mock.post.return_value = _make_project_response()

        http_responses = [_make_reg_response(201), _make_login_response()]
        with _patch_http_post(http_responses):
            with patch("supero.core.Supero.login", return_value=org_mock) as mock_login:
                bootstrap(
                    domain_name    = "test-domain",
                    admin_email    = "admin@test.com",
                    admin_password = "Admin123!",
                    project_name   = "my-app",
                )

        args, kwargs = mock_login.call_args
        project_arg = kwargs.get("project") or (args[3] if len(args) > 3 else None)
        # Updated v1.5.48: login is scoped to the actual project_name so the
        # returned api_key is project-scoped (not domain-admin default-project).
        self.assertEqual(project_arg, "my-app")

    def test_default_project_skips_creation(self):
        """project_name='default-project' skips Step 3 (no project POST)."""
        from supero.bootstrap import bootstrap
        org_mock = _make_org_mock()

        http_responses = [_make_reg_response(201), _make_login_response()]
        with _patch_http_post(http_responses):
            with _patch_supero_login(org_mock):
                bootstrap(
                    domain_name    = "test-domain",
                    admin_email    = "admin@test.com",
                    admin_password = "Admin123!",
                    project_name   = "default-project",
                )

        calls = [str(c) for c in org_mock.post.call_args_list]
        self.assertFalse(any("/project" in c and "fq-name" not in c for c in calls))


    def test_schema_upload_includes_project_uuid(self):
        """Schema upload must include project_uuid so schemas link to the correct project."""
        test_schemas = [{"name": "test_item", "schema_type": "object", "namespace": "test", "attributes": [{"name": "title", "type": "string"}]}]
        result, org_mock = self._run(schemas=test_schemas)
        # Find the schema upload POST call - search all post calls
        all_calls = org_mock.post.call_args_list
        upload_calls = []
        for call in all_calls:
            call_str = str(call)
            if "schemas/upload" in call_str or "schemas" in str(call.kwargs.get("json", {}).keys()):
                upload_calls.append(call)
        self.assertTrue(len(upload_calls) > 0,
            f"No schema upload call found. All POST calls: {[str(c.args[0]) if c.args else str(c) for c in all_calls]}")
        # Get the json payload
        upload_json = upload_calls[0].kwargs.get("json", {})
        if not upload_json and len(upload_calls[0].args) > 1:
            upload_json = upload_calls[0].args[1] if isinstance(upload_calls[0].args[1], dict) else {}
        # project_uuid must be present and non-empty
        self.assertIn("project_uuid", upload_json,
            f"Schema upload missing project_uuid. Payload keys: {list(upload_json.keys())}")
        self.assertTrue(len(str(upload_json.get("project_uuid", ""))) > 0,
            "project_uuid is empty in schema upload")


class TestBootstrapIdempotent(_BootstrapTestBase):
    """Tests for fully idempotent re-run (all resources already exist)."""

    def test_all_skipped_is_success(self):
        """All-skipped run (everything exists) is still a success."""
        from supero.bootstrap import bootstrap
        org_mock = _make_org_mock()

        # Project already exists (409-style), tenants/users already exist too.
        # Use a URL router so the project gets an "already exists" error
        # while still allowing the response to satisfy bootstrap's idempotent
        # check. fq-name-to-uuid resolves the existing project UUID.
        def _post_side_effect(path, json=None):
            if "/project" in path and "fq-name" not in path:
                return {"success": False, "error": "Create Failed: Project already exists"}
            if "fq-name-to-uuid" in path:
                return _make_fqn_response()
            return _make_crud_exists_error()
        org_mock.post.side_effect = _post_side_effect

        http_responses = [
            _make_reg_response(409),                          # domain exists
            _make_login_response(api_key="ak_existing_..."),  # fetch api_key
        ]
        with _patch_http_post(http_responses):
            with _patch_supero_login(org_mock):
                result = bootstrap(
                    domain_name    = "test-domain",
                    admin_email    = "admin@test.com",
                    admin_password = "Admin123!",
                    project_name  = "test-project",
                    tenants        = [{"name": "default-tenant"}],
                    users          = [SAMPLE_USERS[0]],
                )

        self.assertTrue(result.success)
        self.assertEqual(result.errors, [])
        self.assertEqual(result.tenants_created, 0)
        self.assertEqual(result.tenants_skipped, 1)
        self.assertEqual(result.users_created, 0)
        self.assertEqual(result.users_skipped, 1)


# ---------------------------------------------------------------------------
# Error handling tests
# ---------------------------------------------------------------------------

class TestBootstrapErrorHandling(_BootstrapTestBase):
    """Tests for error handling, fail_fast, and edge cases."""


    def test_login_failure_falls_back_to_http_session(self):
        """If Supero.login() raises, bootstrap falls back to HTTP-only session."""
        from supero.bootstrap import bootstrap

        # When Supero.login() fails, bootstrap builds an HTTP-only session
        # which makes real requests. We can't intercept those at this layer,
        # so the test asserts the fallback path completes successfully even
        # though downstream operations like project creation may produce
        # errors. The result.success may legitimately be False; what matters
        # is that result.org is populated and the fallback path executed.
        http_responses = [_make_reg_response(201), _make_login_response()]
        with _patch_http_post(http_responses):
            with patch("supero.core.Supero.login",
                       side_effect=Exception("Connection refused")):
                result = bootstrap(
                    domain_name    = "test-domain",
                    admin_email    = "admin@test.com",
                    admin_password = "Admin123!",
                    project_name  = "test-project",
                )

        # HTTP login succeeds — bootstrap continues with HTTP-only session.
        # We do NOT assert result.success because the HTTP fallback session
        # makes real downstream calls (project create, etc.) which we cannot
        # intercept here. What we can assert: org is populated and domain
        # context was captured.
        self.assertIsNotNone(result.org)
        self.assertTrue(result.domain_uuid)

    def test_fail_fast_stops_on_schema_error(self):
        """fail_fast=True stops after first schema failure, skips tenants/users."""
        from supero.bootstrap import bootstrap
        org_mock = _make_org_mock()
        org_mock.post.return_value = _make_schema_upload_response(failed=2)

        http_responses = [_make_reg_response(201), _make_login_response()]
        with _patch_http_post(http_responses):
            with _patch_supero_login(org_mock):
                result = bootstrap(
                    domain_name    = "test-domain",
                    admin_email    = "admin@test.com",
                    admin_password = "Admin123!",
                    project_name  = "test-project",
                    schemas        = SAMPLE_SCHEMAS,
                    tenants        = SAMPLE_TENANTS,
                    fail_fast      = True,
                )

        # Should have stopped — tenants not created
        self.assertEqual(result.tenants_created, 0)
        self.assertEqual(result.tenants_skipped, 0)
        self.assertFalse(result.success)

    def test_non_fail_fast_continues_after_tenant_error(self):
        """fail_fast=False continues after tenant error, attempts all tenants."""
        from supero.bootstrap import bootstrap
        org_mock = _make_org_mock()

        responses = [
            {"success": False, "error": "Create Failed: Some error"},  # tenant 1 fails
            _make_crud_success("tenant-2"),                              # tenant 2 succeeds
        ]
        call_idx = [0]
        def _side_effect(path, json=None):
            if "/tenant" in path:
                r = responses[call_idx[0] % len(responses)]
                call_idx[0] += 1
                return r
            return _make_crud_success()
        org_mock.post.side_effect = _side_effect

        http_responses = [_make_reg_response(201), _make_login_response()]
        with _patch_http_post(http_responses):
            with _patch_supero_login(org_mock):
                result = bootstrap(
                    domain_name    = "test-domain",
                    admin_email    = "admin@test.com",
                    admin_password = "Admin123!",
                    project_name  = "test-project",
                    tenants        = SAMPLE_TENANTS,
                    fail_fast      = False,
                )

        self.assertEqual(result.tenants_created, 1)
        self.assertEqual(result.tenants_failed, 1)

    def test_schema_partial_failure_does_not_stop_tenants(self):
        """Partial schema failure (fail_fast=False) still creates tenants."""
        from supero.bootstrap import bootstrap
        org_mock = _make_org_mock()

        def _side_effect(path, json=None):
            if "/schemas/upload" in path:
                return _make_schema_upload_response(uploaded=1, failed=1)
            if "/tenant" in path:
                return _make_crud_success("tenant-1")
            return _make_crud_success()
        org_mock.post.side_effect = _side_effect

        http_responses = [_make_reg_response(201), _make_login_response()]
        with _patch_http_post(http_responses):
            with _patch_supero_login(org_mock):
                result = bootstrap(
                    domain_name    = "test-domain",
                    admin_email    = "admin@test.com",
                    admin_password = "Admin123!",
                    project_name  = "test-project",
                    schemas        = SAMPLE_SCHEMAS,
                    tenants        = [{"name": "team-alpha"}],
                    fail_fast      = False,
                )

        # Schema partial failure recorded
        self.assertEqual(result.schemas_failed, 1)
        # But tenant creation still ran
        self.assertEqual(result.tenants_created, 1)


# ---------------------------------------------------------------------------
# Result object tests
# ---------------------------------------------------------------------------

class TestBootstrapResult(_BootstrapTestBase):
    """Tests for BootstrapResult dataclass behaviour."""

    def _get_clean_result(self):
        from supero.bootstrap import bootstrap
        org_mock = _make_org_mock()
        org_mock.post.return_value = _make_schema_upload_response(uploaded=3, skipped=1)

        http_responses = [_make_reg_response(201), _make_login_response()]
        with _patch_http_post(http_responses):
            with _patch_supero_login(org_mock):
                result = bootstrap(
                    domain_name    = "test-domain",
                    admin_email    = "admin@test.com",
                    admin_password = "Admin123!",
                    project_name  = "test-project",
                    schemas        = SAMPLE_SCHEMAS,
                )
        return result

    def test_result_success_true_when_no_errors(self):
        """success property is True when errors is empty."""
        from supero.bootstrap import BootstrapResult
        r = BootstrapResult(domain_name="test")
        self.assertTrue(r.success)

    def test_result_success_false_when_errors(self):
        """success property is False when errors list is non-empty."""
        from supero.bootstrap import BootstrapResult
        r = BootstrapResult(domain_name="test", errors=["something went wrong"])
        self.assertFalse(r.success)

    def test_result_domain_name_set(self):
        """result.domain_name matches requested domain."""
        result = self._get_clean_result()
        self.assertEqual(result.domain_name, "test-domain")

    def test_result_has_all_count_fields(self):
        """BootstrapResult has all expected count fields."""
        from supero.bootstrap import BootstrapResult
        r = BootstrapResult()
        for field in [
            "schemas_uploaded", "schemas_updated", "schemas_skipped", "schemas_failed",
            "tenants_created", "tenants_skipped", "tenants_failed",
            "users_created",   "users_skipped",   "users_failed",
        ]:
            self.assertTrue(hasattr(r, field), f"Missing field: {field}")
            self.assertIsInstance(getattr(r, field), int)

    def test_print_summary_runs_without_error(self):
        """print_summary() produces output and does not raise."""
        result = self._get_clean_result()
        buf = io.StringIO()
        old_stdout = sys.stdout
        sys.stdout = buf
        try:
            result.print_summary()
        finally:
            sys.stdout = old_stdout

        output = buf.getvalue()
        self.assertIn("test-domain", output)
        self.assertIn("Schemas", output)

    def test_print_summary_shows_api_key(self):
        """print_summary() includes api_key when present."""
        result = self._get_clean_result()
        buf = io.StringIO()
        old_stdout = sys.stdout
        sys.stdout = buf
        try:
            result.print_summary()
        finally:
            sys.stdout = old_stdout

        output = buf.getvalue()
        self.assertIn("API Key", output)

    def test_print_summary_shows_errors(self):
        """print_summary() lists errors when present."""
        from supero.bootstrap import BootstrapResult
        r = BootstrapResult(
            domain_name="test",
            errors=["Schema upload failed: ['Bad']"],
        )
        buf = io.StringIO()
        old_stdout = sys.stdout
        sys.stdout = buf
        try:
            r.print_summary()
        finally:
            sys.stdout = old_stdout

        output = buf.getvalue()
        self.assertIn("Errors", output)
        self.assertIn("Schema upload failed", output)


# ---------------------------------------------------------------------------
# Interface / import tests
# ---------------------------------------------------------------------------

class TestBootstrapInterface(_BootstrapTestBase):
    """Tests for public interface: imports, signatures, module-level access."""

    def test_bootstrap_importable_from_supero(self):
        """from supero import bootstrap works."""
        from supero import bootstrap
        self.assertTrue(callable(bootstrap))

    def test_bootstrap_result_importable_from_supero(self):
        """from supero import BootstrapResult works."""
        from supero import BootstrapResult
        self.assertTrue(callable(BootstrapResult))

    def test_bootstrap_importable_from_module(self):
        """from supero.bootstrap import bootstrap works."""
        from supero.bootstrap import bootstrap
        self.assertTrue(callable(bootstrap))

    def test_bootstrap_in_supero_all(self):
        """bootstrap and BootstrapResult are in supero.__all__."""
        import supero
        self.assertIn("bootstrap",       supero.__all__)
        self.assertIn("BootstrapResult", supero.__all__)

    def test_bootstrap_required_params(self):
        """bootstrap() raises TypeError without required params."""
        from supero.bootstrap import bootstrap
        with self.assertRaises(TypeError):
            bootstrap()                  # no domain_name
        with self.assertRaises(TypeError):
            bootstrap("test-domain")     # no admin_email
        with self.assertRaises(TypeError):
            bootstrap("test-domain", "admin@test.com")  # no admin_password

    def test_bootstrap_idempotent_default_true(self):
        """idempotent defaults to True — already-exists errors are silent."""
        from supero.bootstrap import bootstrap
        org_mock = _make_org_mock()
        org_mock.post.return_value = _make_crud_exists_error()

        http_responses = [_make_reg_response(409), _make_login_response()]
        with _patch_http_post(http_responses):
            with _patch_supero_login(org_mock):
                # Should not raise, should not add errors for 'already exists'
                result = bootstrap(
                    domain_name    = "test-domain",
                    admin_email    = "admin@test.com",
                    admin_password = "Admin123!",
                    project_name  = "test-project",
                    tenants        = [{"name": "default-tenant"}],
                )

        self.assertTrue(result.success)
        self.assertEqual(result.errors, [])

    def test_bootstrap_result_org_is_supero_instance(self):
        """result.org is set to the Supero instance returned by login."""
        from supero.bootstrap import bootstrap
        from unittest.mock import MagicMock
        org_mock = _make_org_mock()

        http_responses = [_make_reg_response(201), _make_login_response()]
        with _patch_http_post(http_responses):
            with _patch_supero_login(org_mock):
                result = bootstrap(
                    domain_name    = "test-domain",
                    admin_email    = "admin@test.com",
                    admin_password = "Admin123!",
                    project_name  = "test-project",
                )

        self.assertIs(result.org, org_mock)


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    unittest.main(verbosity=2)
