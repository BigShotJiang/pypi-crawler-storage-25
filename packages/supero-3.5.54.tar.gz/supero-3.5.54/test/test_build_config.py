"""
Test suite for py_api_lib build configuration and schema discovery.
Validates that imports work correctly for both platform and tenant builds.
"""
import unittest
import sys
import os
from unittest.mock import MagicMock, patch


class TestBuildConfiguration(unittest.TestCase):
    """Test build configuration is correctly embedded."""
    
    def test_build_config_exists(self):
        """Test that _build_config module exists and is importable."""
        try:
            from py_api_lib import _build_config
            self.assertIsNotNone(_build_config)
        except ImportError:
            self.fail("_build_config module not found - was build.sh run?")
    
    def test_build_config_has_required_attributes(self):
        """Test that build config has all required attributes."""
        from py_api_lib import _build_config
        
        required_attrs = [
            'BUILD_MODE',
            'PRIMARY_SCHEMA_NAMESPACE',
            'SCHEMA_NAMESPACES',
            'BUILD_TENANT',
            'BUILD_TIMESTAMP',
            'BUILD_VERSION',
            'get_build_info'
        ]
        
        for attr in required_attrs:
            self.assertTrue(
                hasattr(_build_config, attr),
                f"Build config missing required attribute: {attr}"
            )
    
    def test_build_mode_is_valid(self):
        """Test that BUILD_MODE is either 'platform' or 'tenant'."""
        from py_api_lib._build_config import BUILD_MODE
        
        self.assertIn(
            BUILD_MODE,
            ['platform', 'tenant'],
            f"Invalid BUILD_MODE: {BUILD_MODE}"
        )
    
    def test_schema_namespaces_is_list(self):
        """Test that SCHEMA_NAMESPACES is a list."""
        from py_api_lib._build_config import SCHEMA_NAMESPACES
        
        self.assertIsInstance(SCHEMA_NAMESPACES, list)
        self.assertGreater(len(SCHEMA_NAMESPACES), 0, "SCHEMA_NAMESPACES is empty")
    
    def test_platform_build_has_correct_namespace(self):
        """Test that platform build uses pymodel_system only."""
        from py_api_lib._build_config import BUILD_MODE, SCHEMA_NAMESPACES, PRIMARY_SCHEMA_NAMESPACE
        
        if BUILD_MODE == 'platform':
            self.assertEqual(
                PRIMARY_SCHEMA_NAMESPACE,
                'pymodel_system',
                "Platform build should use pymodel_system as primary namespace"
            )
            self.assertEqual(
                SCHEMA_NAMESPACES,
                ['pymodel_system'],
                "Platform build should only have pymodel_system in SCHEMA_NAMESPACES"
            )
    
    def test_tenant_build_has_correct_namespaces(self):
        """Test that tenant build includes both pymodel and pymodel_system."""
        from py_api_lib._build_config import BUILD_MODE, SCHEMA_NAMESPACES, PRIMARY_SCHEMA_NAMESPACE
        
        if BUILD_MODE == 'tenant':
            self.assertEqual(
                PRIMARY_SCHEMA_NAMESPACE,
                'pymodel',
                "Tenant build should use pymodel as primary namespace"
            )
            self.assertIn(
                'pymodel',
                SCHEMA_NAMESPACES,
                "Tenant build should have pymodel in SCHEMA_NAMESPACES"
            )
            self.assertIn(
                'pymodel_system',
                SCHEMA_NAMESPACES,
                "Tenant build should have pymodel_system in SCHEMA_NAMESPACES"
            )


class TestPackageImports(unittest.TestCase):
    """Test that all package imports work correctly."""
    
    def test_py_api_lib_imports(self):
        """Test that py_api_lib package imports successfully."""
        try:
            import py_api_lib
            self.assertIsNotNone(py_api_lib)
        except ImportError as e:
            self.fail(f"Failed to import py_api_lib: {e}")
    
    def test_build_config_accessible_from_package(self):
        """Test that build config is accessible from main package."""
        import py_api_lib
        
        self.assertTrue(hasattr(py_api_lib, 'BUILD_MODE'))
        self.assertTrue(hasattr(py_api_lib, 'PRIMARY_SCHEMA_NAMESPACE'))
        self.assertTrue(hasattr(py_api_lib, 'SCHEMA_NAMESPACES'))
        self.assertTrue(hasattr(py_api_lib, 'get_build_info'))
    
    def test_get_info_function(self):
        """Test that get_info() returns complete information."""
        import py_api_lib
        
        info = py_api_lib.get_info()
        
        required_keys = [
            'version',
            'build_mode',
            'primary_namespace',
            'expected_namespaces',
            'schemas_available',
            'schemas_missing',
            'api_client_available',
            'api_lib_available',
            'build_info'
        ]
        
        for key in required_keys:
            self.assertIn(key, info, f"get_info() missing key: {key}")
    
    def test_exceptions_import(self):
        """Test that exception classes import correctly."""
        from py_api_lib import (
            ApiException,
            AuthenticationError,
            ValidationError,
            NotFoundError,
            ConflictError,
            ServerError
        )
        
        # Verify they're actual classes
        self.assertTrue(callable(ApiException))
        self.assertTrue(callable(AuthenticationError))
    
    def test_api_client_imports(self):
        """Test that ApiClient imports correctly."""
        try:
            from py_api_lib import ApiClient
            self.assertIsNotNone(ApiClient)
            self.assertTrue(callable(ApiClient))
        except ImportError as e:
            self.fail(f"Failed to import ApiClient: {e}")
    
    def test_api_lib_imports(self):
        """Test that ApiLib imports correctly."""
        try:
            from py_api_lib import ApiLib
            self.assertIsNotNone(ApiLib)
            self.assertTrue(callable(ApiLib))
        except ImportError as e:
            self.fail(f"Failed to import ApiLib: {e}")


class TestApiClientBuildAwareness(unittest.TestCase):
    """Test that ApiClient is build-aware."""
    
    def test_api_client_has_build_config(self):
        """Test that ApiClient instance has build configuration."""
        from py_api_lib import ApiClient
        
        client = ApiClient(server_ip='localhost', port=8080)
        
        self.assertTrue(hasattr(client, 'build_mode'))
        self.assertTrue(hasattr(client, 'primary_namespace'))
        self.assertTrue(hasattr(client, 'expected_namespaces'))
    
    def test_api_client_build_mode_matches_package(self):
        """Test that ApiClient build mode matches package build mode."""
        from py_api_lib import ApiClient, BUILD_MODE
        
        client = ApiClient(server_ip='localhost', port=8080)
        
        self.assertEqual(
            client.build_mode,
            BUILD_MODE,
            "ApiClient build_mode doesn't match package BUILD_MODE"
        )
    
    def test_api_client_can_get_serialization_helpers(self):
        """Test that ApiClient can load serialization helpers."""
        from py_api_lib import ApiClient
        
        client = ApiClient(server_ip='localhost', port=8080)
        
        # This should not raise an exception
        helpers = client._get_serialization_helpers()
        
        self.assertIsNotNone(helpers)
        self.assertIsInstance(helpers, dict)
        
        # Check for expected helper functions
        expected_helpers = [
            'safe_serialize_to_dict',
            'safe_serialize_to_json',
            'safe_deserialize_from_dict',
            'safe_deserialize_from_json'
        ]
        
        for helper in expected_helpers:
            self.assertIn(helper, helpers, f"Missing helper: {helper}")


class TestApiLibBuildAwareness(unittest.TestCase):
    """Test that ApiLib is build-aware."""
    
    def test_api_lib_has_build_config(self):
        """Test that ApiLib instance has build configuration."""
        from py_api_lib import ApiLib
        
        api_lib = ApiLib(api_server_host='localhost', api_server_port=8080)
        
        self.assertTrue(hasattr(api_lib, 'build_mode'))
        self.assertTrue(hasattr(api_lib, 'primary_namespace'))
        self.assertTrue(hasattr(api_lib, 'expected_namespaces'))
    
    def test_api_lib_build_mode_matches_package(self):
        """Test that ApiLib build mode matches package build mode."""
        from py_api_lib import ApiLib, BUILD_MODE
        
        api_lib = ApiLib(api_server_host='localhost', api_server_port=8080)
        
        self.assertEqual(
            api_lib.build_mode,
            BUILD_MODE,
            "ApiLib build_mode doesn't match package BUILD_MODE"
        )
    
    def test_api_lib_can_discover_schemas(self):
        """Test that ApiLib can discover available schemas."""
        from py_api_lib import ApiLib
        
        api_lib = ApiLib(api_server_host='localhost', api_server_port=8080)
        
        # This should not raise an exception
        namespaces = api_lib._discover_schema_namespaces()
        
        self.assertIsNotNone(namespaces)
        self.assertIsInstance(namespaces, list)
    
    def test_api_lib_respects_expected_namespaces(self):
        """Test that ApiLib only tries to import expected namespaces."""
        from py_api_lib import ApiLib
        from py_api_lib._build_config import BUILD_MODE, SCHEMA_NAMESPACES
        
        api_lib = ApiLib(api_server_host='localhost', api_server_port=8080)
        
        # Discover namespaces
        discovered = api_lib._discover_schema_namespaces()
        discovered_names = [name for name, _ in discovered]
        
        # All discovered namespaces should be in expected list
        for name in discovered_names:
            self.assertIn(
                name,
                SCHEMA_NAMESPACES,
                f"Discovered unexpected namespace: {name}"
            )
        
        # For platform build, should NOT have pymodel
        if BUILD_MODE == 'platform':
            self.assertNotIn(
                'pymodel',
                discovered_names,
                "Platform build should not discover pymodel namespace"
            )


class TestSchemaAvailability(unittest.TestCase):
    """Test schema package availability."""
    
    def test_expected_schemas_are_available(self):
        """Test that expected schema packages are actually installed."""
        from py_api_lib._build_config import SCHEMA_NAMESPACES
        
        for namespace in SCHEMA_NAMESPACES:
            if namespace == 'pymodel_system':
                try:
                    import pymodel_system
                    import pymodel_system.objects
                    self.assertIsNotNone(pymodel_system)
                except ImportError as e:
                    self.fail(f"Expected schema {namespace} not available: {e}")
            
            elif namespace == 'pymodel':
                try:
                    import pymodel
                    import pymodel.objects
                    self.assertIsNotNone(pymodel)
                except ImportError as e:
                    self.fail(f"Expected schema {namespace} not available: {e}")
    
    def test_serialization_utilities_available(self):
        """Test that serialization utilities are available in schema packages."""
        from py_api_lib._build_config import PRIMARY_SCHEMA_NAMESPACE
        
        if PRIMARY_SCHEMA_NAMESPACE == 'pymodel_system':
            try:
                from pymodel_system.serialization_errors import (
                    safe_serialize_to_dict,
                    safe_serialize_to_json,
                    safe_deserialize_from_dict,
                    safe_deserialize_from_json
                )
                self.assertIsNotNone(safe_serialize_to_dict)
            except ImportError as e:
                self.fail(f"Serialization utilities not available in pymodel_system: {e}")
        
        elif PRIMARY_SCHEMA_NAMESPACE == 'pymodel':
            try:
                from pymodel.serialization_errors import (
                    safe_serialize_to_dict,
                    safe_serialize_to_json,
                    safe_deserialize_from_dict,
                    safe_deserialize_from_json
                )
                self.assertIsNotNone(safe_serialize_to_dict)
            except ImportError as e:
                self.fail(f"Serialization utilities not available in pymodel: {e}")


class TestObjectTypeDiscovery(unittest.TestCase):
    """Test that object types are discovered correctly."""
    
    def test_api_lib_can_load_object_types(self):
        """Test that ApiLib can load object types from schemas."""
        from py_api_lib import ApiLib
        
        api_lib = ApiLib(api_server_host='localhost', api_server_port=8080)
        
        # Load object types
        object_types = api_lib._load_object_types()
        
        self.assertIsNotNone(object_types)
        self.assertIsInstance(object_types, dict)
        
        # Should have at least some object types
        self.assertGreater(
            len(object_types),
            0,
            "No object types discovered - check schema packages"
        )
    
    def test_object_types_are_callable(self):
        """Test that discovered object types are actually classes."""
        from py_api_lib import ApiLib
        
        api_lib = ApiLib(api_server_host='localhost', api_server_port=8080)
        object_types = api_lib._load_object_types()
        
        # Check first 5 object types
        for name, obj_class in list(object_types.items())[:5]:
            self.assertTrue(
                callable(obj_class),
                f"Object type {name} is not callable"
            )
    
    def test_get_build_info_method(self):
        """Test that get_build_info() works on ApiLib."""
        from py_api_lib import ApiLib
        
        api_lib = ApiLib(api_server_host='localhost', api_server_port=8080)
        
        build_info = api_lib.get_build_info()
        
        self.assertIsNotNone(build_info)
        self.assertIsInstance(build_info, dict)
        self.assertIn('build_mode', build_info)
        self.assertIn('primary_namespace', build_info)


class TestNoHardcodedImports(unittest.TestCase):
    """Test that there are no hardcoded schema imports."""
    
    def test_api_client_no_module_level_imports(self):
        """Test that api_client.py has no module-level schema imports."""
        import py_api_lib.api_client as api_client_module
        
        # Get the source file
        source_file = api_client_module.__file__
        
        with open(source_file, 'r') as f:
            content = f.read()
            lines = content.split('\n')
        
        # Check for problematic imports at module level
        # (imports before class definitions)
        in_class = False
        line_num = 0
        
        for line in lines:
            line_num += 1
            stripped = line.strip()
            
            # Track if we're inside a class
            if stripped.startswith('class '):
                in_class = True
            
            # Before any class definitions, check for bad imports
            if not in_class:
                if 'import pymodel.objects' in stripped and not stripped.startswith('#'):
                    self.fail(
                        f"Found hardcoded 'import pymodel.objects' at line {line_num} "
                        f"in api_client.py (module level)"
                    )
                if 'import pymodel_system.objects' in stripped and not stripped.startswith('#'):
                    self.fail(
                        f"Found hardcoded 'import pymodel_system.objects' at line {line_num} "
                        f"in api_client.py (module level)"
                    )
    
    def test_api_lib_no_module_level_imports(self):
        """Test that api_lib.py has no module-level schema imports."""
        import py_api_lib.api_lib as api_lib_module
        
        # Get the source file
        source_file = api_lib_module.__file__
        
        with open(source_file, 'r') as f:
            content = f.read()
            lines = content.split('\n')
        
        # Check for problematic imports at module level
        in_class = False
        line_num = 0
        
        for line in lines:
            line_num += 1
            stripped = line.strip()
            
            # Track if we're inside a class
            if stripped.startswith('class '):
                in_class = True
            
            # Before any class definitions, check for bad imports
            if not in_class:
                if 'import pymodel.objects' in stripped and not stripped.startswith('#'):
                    self.fail(
                        f"Found hardcoded 'import pymodel.objects' at line {line_num} "
                        f"in api_lib.py (module level)"
                    )
                if 'import pymodel_system.objects' in stripped and not stripped.startswith('#'):
                    self.fail(
                        f"Found hardcoded 'import pymodel_system.objects' at line {line_num} "
                        f"in api_lib.py (module level)"
                    )


if __name__ == '__main__':
    # Run tests with verbose output
    unittest.main(verbosity=2)
