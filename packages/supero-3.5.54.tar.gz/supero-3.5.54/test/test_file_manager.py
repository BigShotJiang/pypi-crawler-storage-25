"""
Unit tests for FileManager - File & image upload/download operations.

Tests cover:
- Helpers: _resolve_file, FileReference, BatchUploadResult
- Upload: upload single, upload_batch, size validation, MIME detection
- Download: download, download_to
- Replace: replace binary (same file_id)
- Delete: delete binary
- URLs: url, thumbnail_url, signed_url
- Attach: upload + CRUD save (single, batch), rollback on CRUD failure
- Detach: delete binary + remove reference (Appendix F.4 ordering)
- Replace attached: replace binary + update entity reference
- Internal CRUD: _save_ref_to_entity (single vs list, is_list hint),
                 _remove_ref_from_entity, _update_ref_in_entity
- Object-level injection: inject_file_methods, .attach(), .detach(),
                          .replace_file(), .attach_batch(), .list_files()
- RBAC: api_key passthrough on all methods
- Edge cases: bytes input, file-like input, missing files, oversized files
"""

import io
import os
import tempfile
import unittest
from pathlib import Path
from typing import Any, Dict, List, Optional
from unittest.mock import MagicMock

from supero.file_manager import (
    FileManager,
    FileReference,
    BatchUploadResult,
    _resolve_file,
    inject_file_methods,
    _make_attach_method,
    _make_detach_method,
    _make_replace_file_method,
    _make_attach_batch_method,
    _make_list_files_method,
)


# ============================================
# Mock Classes (extends CrudManager test pattern)
# ============================================

class MockPlatformClient:
    """Mock PlatformClient with multipart and binary download support."""

    def __init__(self, domain_name: str = "test-domain"):
        self.domain_name = domain_name
        self._responses: Dict[str, Any] = {}
        self._calls: List[Dict] = []
        self._error_endpoints: Dict[str, Exception] = {}

    def set_response(self, endpoint: str, response: Any):
        self._responses[endpoint] = response

    def set_error(self, endpoint: str, error: Exception):
        self._error_endpoints[endpoint] = error

    def get_calls(self, endpoint: str = None) -> List[Dict]:
        if endpoint:
            return [c for c in self._calls if c["endpoint"] == endpoint]
        return self._calls

    def last_call(self) -> Optional[Dict]:
        return self._calls[-1] if self._calls else None

    def calls_by_method(self, method: str) -> List[Dict]:
        return [c for c in self._calls if c["method"] == method]

    def _handle_request(self, method: str, endpoint: str, **kwargs) -> Any:
        self._calls.append({"method": method, "endpoint": endpoint, **kwargs})
        if endpoint in self._error_endpoints:
            raise self._error_endpoints[endpoint]
        if endpoint in self._responses:
            return self._responses[endpoint]
        # Defaults
        if method == "GET":
            return {}
        elif method in ("POST", "POST_MULTIPART"):
            return {"file_id": "img_default12ch", "filename": "upload.jpg",
                    "url": "/api/v1/files/test-domain/img_default12ch"}
        elif method in ("PUT", "PUT_MULTIPART"):
            return {"updated": True}
        elif method == "DELETE":
            return {"deleted": True}
        return {}

    # Standard HTTP methods
    def get(self, endpoint, params=None, **kwargs):
        return self._handle_request("GET", endpoint, params=params, **kwargs)

    def post(self, endpoint, json=None, **kwargs):
        return self._handle_request("POST", endpoint, json=json, **kwargs)

    def put(self, endpoint, json=None, **kwargs):
        return self._handle_request("PUT", endpoint, json=json, **kwargs)

    def delete(self, endpoint, **kwargs):
        return self._handle_request("DELETE", endpoint, **kwargs)

    # Multipart methods (used by FileManager)
    def post_multipart(self, endpoint, file_field, file_name, file_obj,
                       file_mime=None, extra_headers=None):
        return self._handle_request(
            "POST_MULTIPART", endpoint,
            file_field=file_field, file_name=file_name,
            file_mime=file_mime, extra_headers=extra_headers,
        )

    def post_multipart_batch(self, endpoint, file_field, files,
                             extra_headers=None):
        return self._handle_request(
            "POST_MULTIPART_BATCH", endpoint,
            file_field=file_field, files=files,
            extra_headers=extra_headers,
        )

    def put_multipart(self, endpoint, file_field, file_name, file_obj,
                      file_mime=None, extra_headers=None):
        return self._handle_request(
            "PUT_MULTIPART", endpoint,
            file_field=file_field, file_name=file_name,
            file_mime=file_mime, extra_headers=extra_headers,
        )

    def get_binary(self, endpoint, extra_headers=None):
        return self._handle_request(
            "GET_BINARY", endpoint,
            extra_headers=extra_headers,
        )


class MockSupero:
    """Mock Supero instance for FileManager tests."""

    def __init__(self, domain_name: str = "test-domain",
                 jwt_token: str = "test-jwt-token"):
        self.domain_name = domain_name
        self._jwt_token = jwt_token
        self.logger = MagicMock()
        self._platform_client = MockPlatformClient(domain_name=domain_name)

    @property
    def jwt_token(self):
        return self._jwt_token

    @property
    def mock_client(self) -> MockPlatformClient:
        return self._platform_client

    def set_response(self, endpoint: str, response: Any):
        self._platform_client.set_response(endpoint, response)

    def set_error(self, endpoint: str, error: Exception):
        self._platform_client.set_error(endpoint, error)

    def get_calls(self, endpoint: str = None) -> List[Dict]:
        return self._platform_client.get_calls(endpoint)

    def last_call(self) -> Optional[Dict]:
        return self._platform_client.last_call()


# ============================================
# Sample data factories
# ============================================

def make_image_ref(**overrides) -> dict:
    """Create a sample Image FileReference dict."""
    ref = {
        "file_id": "img_a7bX9kLmNp3q",
        "filename": "front-view.jpg",
        "mime_type": "image/jpeg",
        "size_bytes": 245000,
        "url": "/api/v1/files/test-domain/img_a7bX9kLmNp3q",
        "thumbnail_url": "/api/v1/files/test-domain/img_a7bX9kLmNp3q/thumb",
        "width": 1920,
        "height": 1080,
        "uploaded_at": "2026-01-15T10:30:00Z",
    }
    ref.update(overrides)
    return ref


def make_file_ref(**overrides) -> dict:
    """Create a sample File FileReference dict."""
    ref = {
        "file_id": "file_xYz123456Ab",
        "filename": "brochure.pdf",
        "mime_type": "application/pdf",
        "size_bytes": 1500000,
        "url": "/api/v1/files/test-domain/file_xYz123456Ab",
        "thumbnail_url": None,
        "uploaded_at": "2026-01-15T11:00:00Z",
    }
    ref.update(overrides)
    return ref


def make_temp_file(content: bytes = b"fake image data", suffix: str = ".jpg") -> str:
    """Create a temporary file and return its path."""
    fd, path = tempfile.mkstemp(suffix=suffix)
    os.write(fd, content)
    os.close(fd)
    return path


# ============================================
# FileReference Tests
# ============================================

class TestFileReference(unittest.TestCase):
    """Test FileReference dict wrapper."""

    def test_image_properties(self):
        """Test all properties on an image FileReference"""
        ref = FileReference(make_image_ref())
        self.assertEqual(ref.file_id, "img_a7bX9kLmNp3q")
        self.assertEqual(ref.filename, "front-view.jpg")
        self.assertEqual(ref.mime_type, "image/jpeg")
        self.assertEqual(ref.size_bytes, 245000)
        self.assertEqual(ref.url, "/api/v1/files/test-domain/img_a7bX9kLmNp3q")
        self.assertEqual(ref.thumbnail_url, "/api/v1/files/test-domain/img_a7bX9kLmNp3q/thumb")
        self.assertEqual(ref.width, 1920)
        self.assertEqual(ref.height, 1080)
        self.assertEqual(ref.uploaded_at, "2026-01-15T10:30:00Z")
        self.assertTrue(ref.is_image)

    def test_file_properties(self):
        """Test properties on a non-image FileReference"""
        ref = FileReference(make_file_ref())
        self.assertEqual(ref.file_id, "file_xYz123456Ab")
        self.assertEqual(ref.filename, "brochure.pdf")
        self.assertIsNone(ref.thumbnail_url)
        self.assertIsNone(ref.width)
        self.assertIsNone(ref.height)
        self.assertFalse(ref.is_image)

    def test_size_display_bytes(self):
        ref = FileReference({"file_id": "f", "size_bytes": 512})
        self.assertEqual(ref.size_display, "512 B")

    def test_size_display_kb(self):
        ref = FileReference({"file_id": "f", "size_bytes": 245000})
        self.assertIn("KB", ref.size_display)

    def test_size_display_mb(self):
        ref = FileReference({"file_id": "f", "size_bytes": 5 * 1024 * 1024})
        self.assertIn("MB", ref.size_display)

    def test_behaves_as_dict(self):
        """FileReference is a dict — can be passed directly to CRUD payloads"""
        ref = FileReference(make_image_ref())
        self.assertEqual(ref["file_id"], "img_a7bX9kLmNp3q")
        self.assertIn("url", ref)
        self.assertEqual(dict(ref)["filename"], "front-view.jpg")

    def test_repr(self):
        ref = FileReference(make_image_ref())
        r = repr(ref)
        self.assertIn("img_a7bX9kLmNp3q", r)
        self.assertIn("front-view.jpg", r)

    def test_empty_defaults(self):
        """Missing keys return safe defaults"""
        ref = FileReference({})
        self.assertEqual(ref.file_id, "")
        self.assertEqual(ref.filename, "")
        self.assertEqual(ref.size_bytes, 0)
        self.assertIsNone(ref.width)


# ============================================
# BatchUploadResult Tests
# ============================================

class TestBatchUploadResult(unittest.TestCase):
    """Test BatchUploadResult wrapper."""

    def test_all_succeeded(self):
        data = {
            "files": [make_image_ref(), make_image_ref(file_id="img_second12345")],
            "failed": [],
        }
        result = BatchUploadResult(data)
        self.assertEqual(result.succeeded, 2)
        self.assertEqual(result.failed_count, 0)
        self.assertTrue(result.all_succeeded)
        self.assertIsInstance(result.files[0], FileReference)

    def test_partial_failure(self):
        data = {
            "files": [make_image_ref()],
            "failed": [{"filename": "bad.xyz", "error": "Unsupported type"}],
        }
        result = BatchUploadResult(data)
        self.assertEqual(result.succeeded, 1)
        self.assertEqual(result.failed_count, 1)
        self.assertFalse(result.all_succeeded)

    def test_empty(self):
        result = BatchUploadResult({})
        self.assertEqual(result.succeeded, 0)
        self.assertEqual(result.failed_count, 0)

    def test_repr(self):
        data = {"files": [make_image_ref()], "failed": []}
        result = BatchUploadResult(data)
        r = repr(result)
        self.assertIn("succeeded=1", r)
        self.assertIn("failed=0", r)


# ============================================
# _resolve_file Tests
# ============================================

class TestResolveFile(unittest.TestCase):
    """Test the _resolve_file helper."""

    def test_resolve_path_string(self):
        path = make_temp_file(b"hello", ".png")
        try:
            name, fobj, mime = _resolve_file(path)
            self.assertEqual(name, os.path.basename(path))
            self.assertEqual(mime, "image/png")
            self.assertEqual(fobj.read(), b"hello")
            fobj.close()
        finally:
            os.unlink(path)

    def test_resolve_path_object(self):
        path = make_temp_file(b"data", ".pdf")
        try:
            name, fobj, mime = _resolve_file(Path(path))
            self.assertTrue(name.endswith(".pdf"))
            self.assertEqual(mime, "application/pdf")
            fobj.close()
        finally:
            os.unlink(path)

    def test_resolve_bytes(self):
        name, fobj, mime = _resolve_file(b"raw bytes")
        self.assertEqual(name, "upload")
        self.assertIsNone(mime)
        self.assertEqual(fobj.read(), b"raw bytes")

    def test_resolve_file_like(self):
        buf = io.BytesIO(b"content")
        buf.name = "/some/path/report.csv"
        name, fobj, mime = _resolve_file(buf)
        self.assertEqual(name, "report.csv")
        self.assertEqual(mime, "text/csv")

    def test_resolve_file_like_no_name(self):
        """File-like without .name attribute uses 'upload' default"""
        buf = io.BytesIO(b"content")
        name, fobj, mime = _resolve_file(buf)
        self.assertEqual(name, "upload")

    def test_resolve_missing_file_raises(self):
        with self.assertRaises(FileNotFoundError):
            _resolve_file("/nonexistent/photo.jpg")

    def test_resolve_unsupported_type_raises(self):
        with self.assertRaises(TypeError):
            _resolve_file(12345)


# ============================================
# FileManager — Upload Tests
# ============================================

class TestFileManagerUpload(unittest.TestCase):
    """Test upload functionality."""

    def setUp(self):
        self.mock_org = MockSupero()
        self.fm = FileManager(self.mock_org)

    def test_upload_from_path(self):
        """Test uploading a file from disk path"""
        ref_data = make_image_ref()
        self.mock_org.set_response("/api/v1/files/test-domain/upload", ref_data)

        path = make_temp_file(b"jpeg data", ".jpg")
        try:
            ref = self.fm.upload(path)
            self.assertIsInstance(ref, FileReference)
            self.assertEqual(ref.file_id, "img_a7bX9kLmNp3q")

            call = self.mock_org.last_call()
            self.assertEqual(call["method"], "POST_MULTIPART")
            self.assertEqual(call["endpoint"], "/api/v1/files/test-domain/upload")
            self.assertEqual(call["file_field"], "file")
            self.assertTrue(call["file_name"].endswith(".jpg"))
        finally:
            os.unlink(path)

    def test_upload_from_bytes(self):
        """Test uploading raw bytes"""
        ref_data = make_file_ref()
        self.mock_org.set_response("/api/v1/files/test-domain/upload", ref_data)

        ref = self.fm.upload(b"pdf content", filename="doc.pdf")
        self.assertEqual(ref.file_id, "file_xYz123456Ab")

        call = self.mock_org.last_call()
        self.assertEqual(call["file_name"], "doc.pdf")

    def test_upload_from_file_object(self):
        """Test uploading an open file object"""
        ref_data = make_image_ref()
        self.mock_org.set_response("/api/v1/files/test-domain/upload", ref_data)

        buf = io.BytesIO(b"png data")
        buf.name = "logo.png"
        self.fm.upload(buf)

        call = self.mock_org.last_call()
        self.assertEqual(call["file_name"], "logo.png")

    def test_upload_with_filename_override(self):
        """Test filename parameter overrides detected name"""
        ref_data = make_image_ref()
        self.mock_org.set_response("/api/v1/files/test-domain/upload", ref_data)

        path = make_temp_file(b"data", ".jpg")
        try:
            self.fm.upload(path, filename="custom-name.jpg")
            call = self.mock_org.last_call()
            self.assertEqual(call["file_name"], "custom-name.jpg")
        finally:
            os.unlink(path)

    def test_upload_with_api_key(self):
        """Test upload passes RBAC API key in headers"""
        ref_data = make_image_ref()
        self.mock_org.set_response("/api/v1/files/test-domain/upload", ref_data)

        buf = io.BytesIO(b"data")
        buf.name = "photo.jpg"
        self.fm.upload(buf, api_key="secret-key-123")

        call = self.mock_org.last_call()
        self.assertEqual(call["extra_headers"]["X-API-Key"], "secret-key-123")

    def test_upload_auth_header_from_jwt(self):
        """Test upload uses JWT Bearer token when no api_key"""
        ref_data = make_image_ref()
        self.mock_org.set_response("/api/v1/files/test-domain/upload", ref_data)

        buf = io.BytesIO(b"data")
        buf.name = "photo.jpg"
        self.fm.upload(buf)

        call = self.mock_org.last_call()
        self.assertEqual(
            call["extra_headers"]["Authorization"], "Bearer test-jwt-token"
        )

    def test_upload_image_exceeds_10mb(self):
        """Test image files are validated against 10 MB limit"""
        big_data = b"x" * (11 * 1024 * 1024)
        path = make_temp_file(big_data, ".jpg")
        try:
            with self.assertRaises(ValueError) as ctx:
                self.fm.upload(path)
            self.assertIn("10 MB", str(ctx.exception))
        finally:
            os.unlink(path)

    def test_upload_file_exceeds_25mb(self):
        """Test non-image files are validated against 25 MB limit"""
        big_data = b"x" * (26 * 1024 * 1024)
        path = make_temp_file(big_data, ".pdf")
        try:
            with self.assertRaises(ValueError) as ctx:
                self.fm.upload(path)
            self.assertIn("25 MB", str(ctx.exception))
        finally:
            os.unlink(path)

    def test_upload_20mb_pdf_passes(self):
        """Test non-image file under 25 MB passes validation"""
        data = b"x" * (20 * 1024 * 1024)
        ref_data = make_file_ref()
        self.mock_org.set_response("/api/v1/files/test-domain/upload", ref_data)

        path = make_temp_file(data, ".pdf")
        try:
            ref = self.fm.upload(path)
            self.assertEqual(ref.file_id, "file_xYz123456Ab")
        finally:
            os.unlink(path)

    def test_upload_9mb_image_passes(self):
        """Test image file under 10 MB passes validation"""
        data = b"x" * (9 * 1024 * 1024)
        ref_data = make_image_ref()
        self.mock_org.set_response("/api/v1/files/test-domain/upload", ref_data)

        path = make_temp_file(data, ".png")
        try:
            ref = self.fm.upload(path)
            self.assertEqual(ref.file_id, "img_a7bX9kLmNp3q")
        finally:
            os.unlink(path)


# ============================================
# FileManager — Upload Batch Tests
# ============================================

class TestFileManagerUploadBatch(unittest.TestCase):
    """Test batch upload functionality."""

    def setUp(self):
        self.mock_org = MockSupero()
        self.fm = FileManager(self.mock_org)

    def test_upload_batch(self):
        """Test batch upload returns BatchUploadResult"""
        batch_data = {
            "files": [make_image_ref(), make_image_ref(file_id="img_second12345")],
            "failed": [],
        }
        self.mock_org.set_response(
            "/api/v1/files/test-domain/upload/batch", batch_data
        )

        p1 = make_temp_file(b"img1", ".jpg")
        p2 = make_temp_file(b"img2", ".jpg")
        try:
            result = self.fm.upload_batch([p1, p2])
            self.assertIsInstance(result, BatchUploadResult)
            self.assertEqual(result.succeeded, 2)
            self.assertTrue(result.all_succeeded)

            call = self.mock_org.last_call()
            self.assertEqual(call["method"], "POST_MULTIPART_BATCH")
            self.assertEqual(call["file_field"], "files[]")
        finally:
            os.unlink(p1)
            os.unlink(p2)

    def test_upload_batch_max_10(self):
        """Test batch upload rejects more than 10 files"""
        files = []
        for i in range(11):
            f = io.BytesIO(b"x")
            f.name = f"file_{i}.jpg"
            files.append(f)

        with self.assertRaises(ValueError) as ctx:
            self.fm.upload_batch(files)
        self.assertIn("10", str(ctx.exception))

    def test_upload_batch_with_api_key(self):
        """Test batch upload passes API key"""
        batch_data = {"files": [make_image_ref()], "failed": []}
        self.mock_org.set_response(
            "/api/v1/files/test-domain/upload/batch", batch_data
        )

        buf = io.BytesIO(b"data")
        buf.name = "photo.jpg"
        self.fm.upload_batch([buf], api_key="batch-key")

        call = self.mock_org.last_call()
        self.assertEqual(call["extra_headers"]["X-API-Key"], "batch-key")


# ============================================
# FileManager — Download Tests
# ============================================

class TestFileManagerDownload(unittest.TestCase):
    """Test download functionality."""

    def setUp(self):
        self.mock_org = MockSupero()
        self.fm = FileManager(self.mock_org)

    def test_download(self):
        """Test download returns (content, filename, mime_type)"""
        self.mock_org.set_response(
            "/api/v1/files/test-domain/img_abc",
            {"content": b"jpeg bytes", "filename": "front-view.jpg",
             "mime_type": "image/jpeg"},
        )

        content, filename, mime = self.fm.download("img_abc")
        self.assertEqual(content, b"jpeg bytes")
        self.assertEqual(filename, "front-view.jpg")
        self.assertEqual(mime, "image/jpeg")

        call = self.mock_org.last_call()
        self.assertEqual(call["method"], "GET_BINARY")

    def test_download_with_api_key(self):
        self.mock_org.set_response(
            "/api/v1/files/test-domain/file_abc",
            {"content": b"data", "filename": "f.pdf",
             "mime_type": "application/pdf"},
        )
        self.fm.download("file_abc", api_key="dl-key")

        call = self.mock_org.last_call()
        self.assertEqual(call["extra_headers"]["X-API-Key"], "dl-key")

    def test_download_to_directory(self):
        """Test download_to saves to directory using original filename"""
        self.mock_org.set_response(
            "/api/v1/files/test-domain/img_abc",
            {"content": b"image data", "filename": "photo.jpg",
             "mime_type": "image/jpeg"},
        )

        with tempfile.TemporaryDirectory() as tmpdir:
            result_path = self.fm.download_to("img_abc", tmpdir)
            self.assertTrue(os.path.exists(result_path))
            self.assertTrue(result_path.endswith("photo.jpg"))
            with open(result_path, "rb") as f:
                self.assertEqual(f.read(), b"image data")

    def test_download_to_explicit_path(self):
        """Test download_to with explicit file path"""
        self.mock_org.set_response(
            "/api/v1/files/test-domain/img_abc",
            {"content": b"data", "filename": "photo.jpg",
             "mime_type": "image/jpeg"},
        )

        with tempfile.TemporaryDirectory() as tmpdir:
            out = os.path.join(tmpdir, "custom-name.jpg")
            result_path = self.fm.download_to("img_abc", out)
            self.assertEqual(result_path, out)
            self.assertTrue(os.path.exists(out))


# ============================================
# FileManager — Replace Tests
# ============================================

class TestFileManagerReplace(unittest.TestCase):
    """Test replace functionality."""

    def setUp(self):
        self.mock_org = MockSupero()
        self.fm = FileManager(self.mock_org)

    def test_replace(self):
        """Test replace sends PUT multipart to /files/{domain}/{file_id}"""
        updated = make_image_ref(size_bytes=500000, filename="new-render.jpg")
        self.mock_org.set_response(
            "/api/v1/files/test-domain/img_a7bX9kLmNp3q", updated
        )

        buf = io.BytesIO(b"new image")
        buf.name = "new-render.jpg"
        ref = self.fm.replace("img_a7bX9kLmNp3q", buf)

        self.assertIsInstance(ref, FileReference)
        self.assertEqual(ref.size_bytes, 500000)

        call = self.mock_org.last_call()
        self.assertEqual(call["method"], "PUT_MULTIPART")
        self.assertEqual(
            call["endpoint"], "/api/v1/files/test-domain/img_a7bX9kLmNp3q"
        )

    def test_replace_with_api_key(self):
        updated = make_image_ref()
        self.mock_org.set_response(
            "/api/v1/files/test-domain/img_abc", updated
        )

        buf = io.BytesIO(b"new")
        buf.name = "new.jpg"
        self.fm.replace("img_abc", buf, api_key="replace-key")

        call = self.mock_org.last_call()
        self.assertEqual(call["extra_headers"]["X-API-Key"], "replace-key")


# ============================================
# FileManager — Delete Tests
# ============================================

class TestFileManagerDelete(unittest.TestCase):
    """Test delete functionality."""

    def setUp(self):
        self.mock_org = MockSupero()
        self.fm = FileManager(self.mock_org)

    def test_delete(self):
        """Test delete sends DELETE to /files/{domain}/{file_id}"""
        self.mock_org.set_response(
            "/api/v1/files/test-domain/img_abc", {"deleted": True}
        )
        result = self.fm.delete("img_abc")
        self.assertTrue(result)

        call = self.mock_org.last_call()
        self.assertEqual(call["method"], "DELETE")
        self.assertEqual(
            call["endpoint"], "/api/v1/files/test-domain/img_abc"
        )

    def test_delete_with_api_key(self):
        self.mock_org.set_response(
            "/api/v1/files/test-domain/img_abc", {"deleted": True}
        )
        self.fm.delete("img_abc", api_key="del-key")

        call = self.mock_org.last_call()
        self.assertEqual(call["extra_headers"]["X-API-Key"], "del-key")


# ============================================
# FileManager — URL Tests
# ============================================

class TestFileManagerURLs(unittest.TestCase):
    """Test URL helper methods."""

    def setUp(self):
        self.mock_org = MockSupero()
        self.fm = FileManager(self.mock_org)

    def test_url(self):
        self.assertEqual(
            self.fm.url("img_abc"),
            "/api/v1/files/test-domain/img_abc",
        )

    def test_thumbnail_url(self):
        self.assertEqual(
            self.fm.thumbnail_url("img_abc"),
            "/api/v1/files/test-domain/img_abc/thumb",
        )

    def test_signed_url(self):
        self.mock_org.set_response(
            "/api/v1/files/test-domain/img_abc",
            {"signed_url": "https://s3.amazonaws.com/bucket/img_abc?sig=xxx"},
        )
        url = self.fm.signed_url("img_abc")
        self.assertIn("s3.amazonaws.com", url)

        call = self.mock_org.last_call()
        self.assertEqual(call["params"], {"signed": "true"})

    def test_signed_url_with_api_key(self):
        self.mock_org.set_response(
            "/api/v1/files/test-domain/img_abc",
            {"signed_url": "https://s3.example.com/img_abc"},
        )
        self.fm.signed_url("img_abc", api_key="sign-key")

        call = self.mock_org.last_call()
        self.assertEqual(call["extra_headers"]["X-API-Key"], "sign-key")

    def test_signed_url_fallback_to_url_key(self):
        """Test signed_url falls back to 'url' key if 'signed_url' missing"""
        self.mock_org.set_response(
            "/api/v1/files/test-domain/img_abc",
            {"url": "https://cdn.example.com/img_abc"},
        )
        url = self.fm.signed_url("img_abc")
        self.assertEqual(url, "https://cdn.example.com/img_abc")


# ============================================
# FileManager — Attach Tests (upload + CRUD)
# ============================================

class TestFileManagerAttach(unittest.TestCase):
    """Test attach (combined upload + CRUD save)."""

    def setUp(self):
        self.mock_org = MockSupero()
        self.fm = FileManager(self.mock_org)
        self._setup_upload_response()

    def _setup_upload_response(self, ref_data=None):
        if ref_data is None:
            ref_data = make_image_ref()
        self.mock_org.set_response("/api/v1/files/test-domain/upload", ref_data)

    def _setup_entity(self, obj_type, uuid, data):
        self.mock_org.set_response(
            f"/crud/test-domain/{obj_type}/{uuid}", data
        )

    def test_attach_single_attribute(self):
        """Test attaching to a single (non-list) attribute"""
        self._setup_entity("channel_partner", "cp-uuid", {"logo": None})

        buf = io.BytesIO(b"logo png")
        buf.name = "logo.png"
        ref = self.fm.attach("cp-uuid", "channel_partner", "logo", buf)

        self.assertEqual(ref.file_id, "img_a7bX9kLmNp3q")

        # Verify CRUD PUT was called
        put_calls = self.mock_org.mock_client.calls_by_method("PUT")
        self.assertTrue(len(put_calls) >= 1)
        last_put = put_calls[-1]
        self.assertEqual(
            last_put["endpoint"], "/crud/test-domain/channel_partner/cp-uuid"
        )
        saved_logo = last_put["json"]["logo"]
        self.assertEqual(saved_logo["file_id"], "img_a7bX9kLmNp3q")

    def test_attach_list_attribute_append(self):
        """Test attaching to a list attribute appends"""
        existing_photo = make_image_ref(file_id="img_existing1234")
        self._setup_entity("project", "proj-uuid", {
            "project_photos": [existing_photo],
        })

        buf = io.BytesIO(b"new photo")
        buf.name = "render.jpg"
        self.fm.attach("proj-uuid", "project", "project_photos", buf)

        put_calls = self.mock_org.mock_client.calls_by_method("PUT")
        last_put = put_calls[-1]
        saved = last_put["json"]["project_photos"]
        self.assertEqual(len(saved), 2)
        self.assertEqual(saved[0]["file_id"], "img_existing1234")
        self.assertEqual(saved[1]["file_id"], "img_a7bX9kLmNp3q")

    def test_attach_list_attribute_replace(self):
        """Test attach with append=False replaces entire list"""
        existing = make_image_ref(file_id="img_old")
        self._setup_entity("project", "proj-uuid", {"photos": [existing]})

        buf = io.BytesIO(b"new")
        buf.name = "new.jpg"
        self.fm.attach("proj-uuid", "project", "photos", buf, append=False)

        put_calls = self.mock_org.mock_client.calls_by_method("PUT")
        last_put = put_calls[-1]
        saved = last_put["json"]["photos"]
        self.assertEqual(len(saved), 1)
        self.assertEqual(saved[0]["file_id"], "img_a7bX9kLmNp3q")

    def test_attach_is_list_hint_on_empty(self):
        """Test is_list=True creates [ref] instead of ref when current is None"""
        self._setup_entity("project", "proj-uuid", {"photos": None})

        buf = io.BytesIO(b"first")
        buf.name = "first.jpg"
        self.fm.attach(
            "proj-uuid", "project", "photos", buf, is_list=True
        )

        put_calls = self.mock_org.mock_client.calls_by_method("PUT")
        last_put = put_calls[-1]
        saved = last_put["json"]["photos"]
        self.assertIsInstance(saved, list)
        self.assertEqual(len(saved), 1)

    def test_attach_without_is_list_on_none_saves_as_single(self):
        """Test without is_list hint, None attribute saves as single dict"""
        self._setup_entity("partner", "p-uuid", {"logo": None})

        buf = io.BytesIO(b"logo")
        buf.name = "logo.png"
        self.fm.attach("p-uuid", "partner", "logo", buf)

        put_calls = self.mock_org.mock_client.calls_by_method("PUT")
        last_put = put_calls[-1]
        saved = last_put["json"]["logo"]
        # Should be a dict, not a list
        self.assertIsInstance(saved, dict)

    def test_attach_rollback_on_crud_failure(self):
        """Test if CRUD update fails, uploaded file is cleaned up"""
        self._setup_upload_response(make_image_ref())
        # Entity GET will work but we need PUT to fail
        # Set the GET response
        self.mock_org.set_response(
            "/crud/test-domain/project/proj-uuid", {"logo": None}
        )
        # Make PUT fail — use a different approach: override after GET
        # We need GET to succeed but PUT to fail on the same endpoint.
        # Since mock uses exact match, the GET and PUT share the same endpoint.
        # We'll verify the rollback via DELETE being called.

        # Actually, _get_entity uses GET and _update_entity uses PUT on same path.
        # Our mock handles both from same response. For the PUT to fail, set error:
        original_put = self.mock_org._platform_client.put

        call_count = {"n": 0}

        def failing_put(endpoint, json=None, **kwargs):
            call_count["n"] += 1
            self.mock_org._platform_client._calls.append({
                "method": "PUT", "endpoint": endpoint, "json": json, **kwargs
            })
            raise Exception("CRUD update failed")

        self.mock_org._platform_client.put = failing_put

        buf = io.BytesIO(b"data")
        buf.name = "logo.png"

        with self.assertRaises(Exception) as ctx:
            self.fm.attach("proj-uuid", "project", "logo", buf)
        self.assertIn("CRUD", str(ctx.exception))

        # Verify cleanup DELETE was called for the uploaded file
        delete_calls = self.mock_org.mock_client.calls_by_method("DELETE")
        self.assertTrue(any(
            c["endpoint"] == "/api/v1/files/test-domain/img_a7bX9kLmNp3q"
            for c in delete_calls
        ))

        # Restore
        self.mock_org._platform_client.put = original_put

    def test_attach_with_api_key(self):
        """Test attach passes api_key to upload"""
        self._setup_entity("project", "proj-uuid", {"logo": None})

        buf = io.BytesIO(b"data")
        buf.name = "logo.png"
        self.fm.attach("proj-uuid", "project", "logo", buf, api_key="att-key")

        upload_call = self.mock_org.mock_client.calls_by_method("POST_MULTIPART")[0]
        self.assertEqual(upload_call["extra_headers"]["X-API-Key"], "att-key")


class TestFileManagerAttachBatch(unittest.TestCase):
    """Test batch attach (upload batch + CRUD save)."""

    def setUp(self):
        self.mock_org = MockSupero()
        self.fm = FileManager(self.mock_org)

    def test_attach_batch(self):
        """Test batch attach uploads and saves all refs"""
        batch_data = {
            "files": [
                make_image_ref(file_id="img_batch1"),
                make_image_ref(file_id="img_batch2"),
            ],
            "failed": [],
        }
        self.mock_org.set_response(
            "/api/v1/files/test-domain/upload/batch", batch_data
        )
        self.mock_org.set_response(
            "/crud/test-domain/project/proj-uuid", {"photos": []}
        )

        f1 = io.BytesIO(b"img1")
        f1.name = "a.jpg"
        f2 = io.BytesIO(b"img2")
        f2.name = "b.jpg"

        result = self.fm.attach_batch(
            "proj-uuid", "project", "photos", [f1, f2]
        )
        self.assertEqual(result.succeeded, 2)

        put_calls = self.mock_org.mock_client.calls_by_method("PUT")
        self.assertTrue(len(put_calls) >= 1)
        saved = put_calls[-1]["json"]["photos"]
        self.assertEqual(len(saved), 2)

    def test_attach_batch_empty_result_skips_crud(self):
        """Test batch attach with all failures skips CRUD update"""
        batch_data = {"files": [], "failed": [{"filename": "bad.xyz"}]}
        self.mock_org.set_response(
            "/api/v1/files/test-domain/upload/batch", batch_data
        )

        f1 = io.BytesIO(b"data")
        f1.name = "bad.xyz"
        result = self.fm.attach_batch(
            "proj-uuid", "project", "photos", [f1]
        )
        self.assertEqual(result.succeeded, 0)

        # No PUT calls should have been made
        put_calls = self.mock_org.mock_client.calls_by_method("PUT")
        self.assertEqual(len(put_calls), 0)

    def test_attach_batch_appends_to_existing(self):
        """Test batch attach appends to existing list"""
        existing = [make_image_ref(file_id="img_old")]
        batch_data = {
            "files": [make_image_ref(file_id="img_new1")],
            "failed": [],
        }
        self.mock_org.set_response(
            "/api/v1/files/test-domain/upload/batch", batch_data
        )
        self.mock_org.set_response(
            "/crud/test-domain/project/proj-uuid", {"photos": existing}
        )

        f1 = io.BytesIO(b"data")
        f1.name = "new.jpg"
        self.fm.attach_batch("proj-uuid", "project", "photos", [f1])

        put_calls = self.mock_org.mock_client.calls_by_method("PUT")
        saved = put_calls[-1]["json"]["photos"]
        self.assertEqual(len(saved), 2)
        self.assertEqual(saved[0]["file_id"], "img_old")
        self.assertEqual(saved[1]["file_id"], "img_new1")


# ============================================
# FileManager — Detach Tests
# ============================================

class TestFileManagerDetach(unittest.TestCase):
    """Test detach (delete binary + remove reference)."""

    def setUp(self):
        self.mock_org = MockSupero()
        self.fm = FileManager(self.mock_org)

    def test_detach_ordering(self):
        """Test Appendix F.4: delete binary FIRST, then remove reference"""
        photos = [
            make_image_ref(file_id="img_keep"),
            make_image_ref(file_id="img_remove"),
        ]
        self.mock_org.set_response(
            "/crud/test-domain/project/proj-uuid", {"photos": photos}
        )
        self.mock_org.set_response(
            "/api/v1/files/test-domain/img_remove", {"deleted": True}
        )

        result = self.fm.detach(
            "proj-uuid", "project", "photos", "img_remove"
        )
        self.assertTrue(result)

        calls = self.mock_org.get_calls()
        methods = [c["method"] for c in calls]
        # DELETE (binary) should come before GET (CRUD fetch)
        delete_idx = methods.index("DELETE")
        get_idx = methods.index("GET")
        self.assertLess(delete_idx, get_idx)

    def test_detach_removes_from_list(self):
        """Test detach removes correct file_id from list"""
        photos = [
            make_image_ref(file_id="img_keep"),
            make_image_ref(file_id="img_remove"),
        ]
        self.mock_org.set_response(
            "/crud/test-domain/project/proj-uuid", {"photos": photos}
        )
        self.mock_org.set_response(
            "/api/v1/files/test-domain/img_remove", {"deleted": True}
        )

        self.fm.detach("proj-uuid", "project", "photos", "img_remove")

        put_calls = self.mock_org.mock_client.calls_by_method("PUT")
        saved = put_calls[-1]["json"]["photos"]
        self.assertEqual(len(saved), 1)
        self.assertEqual(saved[0]["file_id"], "img_keep")

    def test_detach_single_attribute_sets_none(self):
        """Test detach on single attribute sets to None"""
        logo = make_image_ref(file_id="img_logo")
        self.mock_org.set_response(
            "/crud/test-domain/partner/p-uuid", {"logo": logo}
        )
        self.mock_org.set_response(
            "/api/v1/files/test-domain/img_logo", {"deleted": True}
        )

        self.fm.detach("p-uuid", "partner", "logo", "img_logo")

        put_calls = self.mock_org.mock_client.calls_by_method("PUT")
        self.assertIsNone(put_calls[-1]["json"]["logo"])

    def test_detach_without_binary_delete(self):
        """Test delete_binary=False only removes reference"""
        photos = [make_image_ref(file_id="img_unlink")]
        self.mock_org.set_response(
            "/crud/test-domain/project/proj-uuid", {"photos": photos}
        )

        self.fm.detach(
            "proj-uuid", "project", "photos", "img_unlink",
            delete_binary=False,
        )

        delete_calls = self.mock_org.mock_client.calls_by_method("DELETE")
        self.assertEqual(len(delete_calls), 0)

    def test_detach_binary_failure_still_removes_reference(self):
        """Test if binary delete fails, reference is still removed"""
        photos = [make_image_ref(file_id="img_stubborn")]
        self.mock_org.set_response(
            "/crud/test-domain/project/proj-uuid", {"photos": photos}
        )
        self.mock_org.set_error(
            "/api/v1/files/test-domain/img_stubborn",
            Exception("Storage error"),
        )

        result = self.fm.detach(
            "proj-uuid", "project", "photos", "img_stubborn"
        )
        self.assertTrue(result)

        put_calls = self.mock_org.mock_client.calls_by_method("PUT")
        saved = put_calls[-1]["json"]["photos"]
        self.assertEqual(len(saved), 0)

    def test_detach_file_id_not_found_in_list(self):
        """Test detach when file_id not in list — list stays unchanged"""
        photos = [make_image_ref(file_id="img_other")]
        self.mock_org.set_response(
            "/crud/test-domain/project/proj-uuid", {"photos": photos}
        )
        self.mock_org.set_response(
            "/api/v1/files/test-domain/img_nonexistent", {"deleted": True}
        )

        result = self.fm.detach(
            "proj-uuid", "project", "photos", "img_nonexistent"
        )
        self.assertTrue(result)

        # List should be unchanged — img_other still present
        put_calls = self.mock_org.mock_client.calls_by_method("PUT")
        saved = put_calls[-1]["json"]["photos"]
        self.assertEqual(len(saved), 1)
        self.assertEqual(saved[0]["file_id"], "img_other")

    def test_detach_file_id_not_found_non_list(self):
        """Test detach when attribute is not a list and file_id doesn't match — logs warning"""
        other_logo = make_image_ref(file_id="img_different")
        self.mock_org.set_response(
            "/crud/test-domain/partner/p-uuid", {"logo": other_logo}
        )
        self.mock_org.set_response(
            "/api/v1/files/test-domain/img_nonexistent", {"deleted": True}
        )

        self.fm.detach(
            "p-uuid", "partner", "logo", "img_nonexistent"
        )

        # Should log warning because it's a dict with a different file_id
        self.mock_org.logger.warning.assert_called()
        # No PUT should have been made (early return)
        put_calls = self.mock_org.mock_client.calls_by_method("PUT")
        self.assertEqual(len(put_calls), 0)


# ============================================
# FileManager — Replace Attached Tests
# ============================================

class TestFileManagerReplaceAttached(unittest.TestCase):
    """Test replace_attached (replace binary + update entity ref)."""

    def setUp(self):
        self.mock_org = MockSupero()
        self.fm = FileManager(self.mock_org)

    def test_replace_attached_updates_entity(self):
        """Test replace_attached updates both binary and entity reference"""
        updated_ref = make_image_ref(
            size_bytes=500000, filename="better.jpg"
        )
        self.mock_org.set_response(
            "/api/v1/files/test-domain/img_a7bX9kLmNp3q", updated_ref
        )

        photos = [
            make_image_ref(file_id="img_a7bX9kLmNp3q", filename="old.jpg"),
            make_image_ref(file_id="img_other"),
        ]
        self.mock_org.set_response(
            "/crud/test-domain/project/proj-uuid", {"photos": photos}
        )

        buf = io.BytesIO(b"better image")
        buf.name = "better.jpg"
        ref = self.fm.replace_attached(
            "proj-uuid", "project", "photos",
            "img_a7bX9kLmNp3q", buf,
        )

        self.assertEqual(ref.size_bytes, 500000)

        # Find the CRUD PUT
        crud_puts = self.mock_org.mock_client.calls_by_method("PUT")
        saved = crud_puts[-1]["json"]["photos"]
        self.assertEqual(len(saved), 2)
        # First entry should be the updated one
        self.assertEqual(saved[0]["filename"], "better.jpg")
        self.assertEqual(saved[0]["size_bytes"], 500000)
        # Second entry unchanged
        self.assertEqual(saved[1]["file_id"], "img_other")

    def test_replace_attached_single_attribute(self):
        """Test replace_attached on a single (non-list) attribute"""
        updated_ref = make_image_ref(filename="new-logo.png")
        self.mock_org.set_response(
            "/api/v1/files/test-domain/img_logo", updated_ref
        )
        self.mock_org.set_response(
            "/crud/test-domain/partner/p-uuid",
            {"logo": make_image_ref(file_id="img_logo", filename="old.png")},
        )

        buf = io.BytesIO(b"new logo")
        buf.name = "new-logo.png"
        self.fm.replace_attached(
            "p-uuid", "partner", "logo", "img_logo", buf,
        )

        crud_puts = self.mock_org.mock_client.calls_by_method("PUT")
        saved = crud_puts[-1]["json"]["logo"]
        self.assertIsInstance(saved, dict)
        self.assertEqual(saved["filename"], "new-logo.png")


# ============================================
# FileManager — MIME / Size Constants Tests
# ============================================

class TestFileManagerConstants(unittest.TestCase):
    """Test class constants match schema definitions."""

    def test_image_mimes_match_schema(self):
        """IMAGE_MIMES must match Image.json ui_hints.accept"""
        expected = {
            "image/jpeg", "image/png", "image/webp",
            "image/gif", "image/svg+xml", "image/bmp", "image/tiff",
        }
        self.assertEqual(FileManager.IMAGE_MIMES, expected)

    def test_thumbnail_mimes_excludes_svg(self):
        """THUMBNAIL_MIMES = IMAGE_MIMES minus SVG"""
        self.assertNotIn("image/svg+xml", FileManager.THUMBNAIL_MIMES)
        self.assertIn("image/jpeg", FileManager.THUMBNAIL_MIMES)
        self.assertIn("image/gif", FileManager.THUMBNAIL_MIMES)

    def test_max_image_size_10mb(self):
        self.assertEqual(FileManager.MAX_IMAGE_SIZE, 10 * 1024 * 1024)

    def test_max_file_size_25mb(self):
        self.assertEqual(FileManager.MAX_FILE_SIZE, 25 * 1024 * 1024)

    def test_max_batch_size_10(self):
        self.assertEqual(FileManager.MAX_BATCH_SIZE, 10)


# ============================================
# FileManager — Endpoint Building Tests
# ============================================

class TestFileManagerEndpoints(unittest.TestCase):
    """Test endpoint URL building."""

    def setUp(self):
        self.mock_org = MockSupero(domain_name="acme-corp")
        self.fm = FileManager(self.mock_org)

    def test_file_endpoint(self):
        self.assertEqual(
            self.fm._file_endpoint("upload"),
            "/api/v1/files/acme-corp/upload",
        )

    def test_file_endpoint_with_file_id(self):
        self.assertEqual(
            self.fm._file_endpoint("img_abc"),
            "/api/v1/files/acme-corp/img_abc",
        )

    def test_file_endpoint_with_parts(self):
        self.assertEqual(
            self.fm._file_endpoint("img_abc", "thumb"),
            "/api/v1/files/acme-corp/img_abc/thumb",
        )

    def test_crud_endpoint(self):
        self.assertEqual(
            self.fm._crud_endpoint("project", "uuid-123"),
            "/crud/acme-corp/project/uuid-123",
        )

    def test_auth_headers_jwt(self):
        """JWT auth when no api_key"""
        headers = self.fm._auth_headers()
        self.assertEqual(headers["Authorization"], "Bearer test-jwt-token")

    def test_auth_headers_api_key(self):
        """API key overrides JWT"""
        headers = self.fm._auth_headers(api_key="my-key")
        self.assertEqual(headers["X-API-Key"], "my-key")
        self.assertNotIn("Authorization", headers)


# ============================================
# Object-Level Method Injection Tests
# ============================================

class TestInjectFileMethods(unittest.TestCase):
    """Test inject_file_methods and object-level convenience."""

    def setUp(self):
        self.mock_org = MockSupero()
        self.fm = FileManager(self.mock_org)
        # Wire up org.files so injected methods can call it
        self.mock_org.files = self.fm

    def _make_instance(self, uuid="obj-uuid", obj_type="project"):
        """Create a plain object to inject methods onto."""

        class Obj:
            pass

        inst = Obj()
        inst.uuid = uuid
        inst.obj_type = obj_type
        return inst

    def test_inject_adds_all_methods(self):
        """Test inject_file_methods adds 5 methods"""
        inst = self._make_instance()
        inject_file_methods(self.mock_org, inst)

        self.assertTrue(callable(getattr(inst, "attach", None)))
        self.assertTrue(callable(getattr(inst, "detach", None)))
        self.assertTrue(callable(getattr(inst, "replace_file", None)))
        self.assertTrue(callable(getattr(inst, "attach_batch", None)))
        self.assertTrue(callable(getattr(inst, "list_files", None)))

    def test_inject_skips_without_uuid(self):
        """Test inject_file_methods skips objects without UUID"""
        inst = self._make_instance()
        inst.uuid = None
        inject_file_methods(self.mock_org, inst)

        self.assertFalse(hasattr(inst, "attach"))

    def test_inject_idempotent(self):
        """Test calling inject_file_methods twice doesn't overwrite"""
        inst = self._make_instance()
        inject_file_methods(self.mock_org, inst)
        first_attach = inst.attach
        inject_file_methods(self.mock_org, inst)
        self.assertIs(inst.attach, first_attach)

    def test_object_attach_calls_manager(self):
        """Test inst.attach() delegates to org.files.attach()"""
        inst = self._make_instance(uuid="proj-uuid", obj_type="project")
        inject_file_methods(self.mock_org, inst)

        # Setup mocks
        ref_data = make_image_ref()
        self.mock_org.set_response(
            "/api/v1/files/test-domain/upload", ref_data
        )
        self.mock_org.set_response(
            "/crud/test-domain/project/proj-uuid", {"logo": None}
        )

        buf = io.BytesIO(b"data")
        buf.name = "logo.png"
        ref = inst.attach("logo", buf)

        self.assertEqual(ref.file_id, "img_a7bX9kLmNp3q")

    def test_object_detach_calls_manager(self):
        """Test inst.detach() delegates to org.files.detach()"""
        inst = self._make_instance(uuid="proj-uuid", obj_type="project")
        inject_file_methods(self.mock_org, inst)

        photos = [make_image_ref(file_id="img_del")]
        self.mock_org.set_response(
            "/crud/test-domain/project/proj-uuid", {"photos": photos}
        )
        self.mock_org.set_response(
            "/api/v1/files/test-domain/img_del", {"deleted": True}
        )

        result = inst.detach("photos", "img_del")
        self.assertTrue(result)

    def test_object_attach_without_uuid_raises(self):
        """Test .attach() raises if object has no uuid"""
        inst = self._make_instance()
        inst.uuid = "obj-uuid"
        inject_file_methods(self.mock_org, inst)
        # Now remove uuid to simulate stale reference
        inst.uuid = None

        buf = io.BytesIO(b"data")
        buf.name = "f.jpg"
        with self.assertRaises(ValueError) as ctx:
            inst.attach("logo", buf)
        self.assertIn("uuid", str(ctx.exception).lower())

    def test_list_files_empty(self):
        """Test list_files returns [] for None attribute"""
        inst = self._make_instance()
        inst.photos = None
        inject_file_methods(self.mock_org, inst)

        result = inst.list_files("photos")
        self.assertEqual(result, [])

    def test_list_files_list_attribute(self):
        """Test list_files wraps dicts in FileReference"""
        inst = self._make_instance()
        inst.photos = [make_image_ref(), make_image_ref(file_id="img_2")]
        inject_file_methods(self.mock_org, inst)

        result = inst.list_files("photos")
        self.assertEqual(len(result), 2)
        self.assertIsInstance(result[0], FileReference)

    def test_list_files_single_attribute(self):
        """Test list_files wraps single dict in a list"""
        inst = self._make_instance()
        inst.logo = make_image_ref()
        inject_file_methods(self.mock_org, inst)

        result = inst.list_files("logo")
        self.assertEqual(len(result), 1)
        self.assertIsInstance(result[0], FileReference)


# ============================================
# Integration-style Tests
# ============================================

class TestFileManagerIntegration(unittest.TestCase):
    """Integration-style tests for common workflows."""

    def setUp(self):
        self.mock_org = MockSupero()
        self.fm = FileManager(self.mock_org)

    def test_upload_attach_detach_workflow(self):
        """Test complete file lifecycle: upload → attach → detach"""
        ref_data = make_image_ref()

        # 1. Upload
        self.mock_org.set_response(
            "/api/v1/files/test-domain/upload", ref_data
        )
        ref = self.fm.upload(io.BytesIO(b"img"))

        self.assertEqual(ref.file_id, "img_a7bX9kLmNp3q")

        # 2. Attach to entity
        self.mock_org.set_response(
            "/crud/test-domain/project/proj-uuid",
            {"project_photos": []},
        )
        self.fm.attach(
            "proj-uuid", "project", "project_photos",
            io.BytesIO(b"img"),
        )

        put_calls = self.mock_org.mock_client.calls_by_method("PUT")
        self.assertTrue(len(put_calls) >= 1)

        # 3. Detach
        self.mock_org._platform_client._calls.clear()  # reset
        self.mock_org.set_response(
            "/crud/test-domain/project/proj-uuid",
            {"project_photos": [ref_data]},
        )
        self.mock_org.set_response(
            "/api/v1/files/test-domain/img_a7bX9kLmNp3q",
            {"deleted": True},
        )
        self.fm.detach(
            "proj-uuid", "project", "project_photos", "img_a7bX9kLmNp3q"
        )

        put_calls = self.mock_org.mock_client.calls_by_method("PUT")
        saved = put_calls[-1]["json"]["project_photos"]
        self.assertEqual(len(saved), 0)

    def test_gallery_build_workflow(self):
        """Test building a gallery with batch upload then individual additions"""
        # Batch upload 2 photos
        batch_data = {
            "files": [
                make_image_ref(file_id="img_b1"),
                make_image_ref(file_id="img_b2"),
            ],
            "failed": [],
        }
        self.mock_org.set_response(
            "/api/v1/files/test-domain/upload/batch", batch_data
        )
        self.mock_org.set_response(
            "/crud/test-domain/project/proj-uuid", {"photos": []}
        )

        f1 = io.BytesIO(b"1")
        f1.name = "a.jpg"
        f2 = io.BytesIO(b"2")
        f2.name = "b.jpg"
        self.fm.attach_batch("proj-uuid", "project", "photos", [f1, f2])

        put_calls = self.mock_org.mock_client.calls_by_method("PUT")
        self.assertEqual(len(put_calls[-1]["json"]["photos"]), 2)

        # Add one more
        self.mock_org._platform_client._calls.clear()
        self.mock_org.set_response(
            "/api/v1/files/test-domain/upload",
            make_image_ref(file_id="img_b3"),
        )
        self.mock_org.set_response(
            "/crud/test-domain/project/proj-uuid",
            {"photos": [
                make_image_ref(file_id="img_b1"),
                make_image_ref(file_id="img_b2"),
            ]},
        )

        f3 = io.BytesIO(b"3")
        f3.name = "c.jpg"
        self.fm.attach("proj-uuid", "project", "photos", f3)

        put_calls = self.mock_org.mock_client.calls_by_method("PUT")
        self.assertEqual(len(put_calls[-1]["json"]["photos"]), 3)

    def test_replace_in_gallery_workflow(self):
        """Test replacing one image in a gallery"""
        old_photos = [
            make_image_ref(file_id="img_1", filename="old-1.jpg"),
            make_image_ref(file_id="img_2", filename="keep.jpg"),
        ]
        updated_ref = make_image_ref(
            file_id="img_1", filename="new-1.jpg", size_bytes=999
        )

        self.mock_org.set_response(
            "/api/v1/files/test-domain/img_1", updated_ref
        )
        self.mock_org.set_response(
            "/crud/test-domain/project/proj-uuid", {"photos": old_photos}
        )

        buf = io.BytesIO(b"new")
        buf.name = "new-1.jpg"
        self.fm.replace_attached(
            "proj-uuid", "project", "photos", "img_1", buf
        )

        put_calls = self.mock_org.mock_client.calls_by_method("PUT")
        saved = put_calls[-1]["json"]["photos"]
        self.assertEqual(saved[0]["filename"], "new-1.jpg")
        self.assertEqual(saved[0]["size_bytes"], 999)
        self.assertEqual(saved[1]["filename"], "keep.jpg")


# ============================================
# Run Tests
# ============================================

if __name__ == "__main__":
    unittest.main(verbosity=2)
