"""
Unit tests for CrudManager - REST-based CRUD operations.

Tests cover:
- Basic CRUD: create, get, list, update, delete
- Query: query builder, filter, order_by, limit, offset, paginate
- Aggregations: count, sum, avg, min, max, distinct, count_by, stats
- References: set_ref, get_ref, update_ref, remove_ref
- Bulk operations: bulk_get, bulk_create, bulk_update, bulk_delete
- Convenience: exists, get_by_name, get_or_create, update_or_create
- Parent-child relationships
- RBAC with api_key
"""

import unittest
import copy
from unittest.mock import MagicMock, patch
from typing import Any, Dict, List, Optional


# ============================================
# Mock Classes
# ============================================

class MockPlatformClient:
    """Mock PlatformClient for testing CrudManager"""
    
    def __init__(self, domain_name: str = "test-domain", domain_uuid: str = "domain-uuid-123"):
        self.domain_name = domain_name
        self.domain_uuid = domain_uuid
        self._responses: Dict[str, Any] = {}
        self._calls: List[Dict] = []
        self._error_endpoints: Dict[str, Exception] = {}
    
    def set_response(self, endpoint: str, response: Any):
        """Set mock response for an endpoint"""
        self._responses[endpoint] = response
    
    def set_error(self, endpoint: str, error: Exception):
        """Set an error to raise for an endpoint"""
        self._error_endpoints[endpoint] = error
    
    def get_calls(self, endpoint: str = None) -> List[Dict]:
        """Get recorded calls, optionally filtered by endpoint"""
        if endpoint:
            return [c for c in self._calls if c["endpoint"] == endpoint]
        return self._calls
    
    def last_call(self) -> Optional[Dict]:
        """Get the last call made"""
        return self._calls[-1] if self._calls else None
    
    def _handle_request(self, method: str, endpoint: str, **kwargs) -> Any:
        """Handle a mock request"""
        self._calls.append({
            "method": method,
            "endpoint": endpoint,
            **kwargs
        })
        
        if endpoint in self._error_endpoints:
            raise self._error_endpoints[endpoint]
        
        # Try exact match first
        if endpoint in self._responses:
            return self._responses[endpoint]
        
        # Try pattern matching (for endpoints with UUIDs)
        for pattern, response in self._responses.items():
            if self._matches_pattern(pattern, endpoint):
                return response
        
        # Default responses based on method
        if method == "GET":
            return {}
        elif method == "POST":
            return {"uuid": "new-uuid-123", "name": "created"}
        elif method == "PUT":
            return {"uuid": "updated-uuid", "updated": True}
        elif method == "DELETE":
            return {"deleted": True}
        return {}
    
    def _matches_pattern(self, pattern: str, endpoint: str) -> bool:
        """Simple pattern matching for endpoints"""
        pattern_parts = pattern.split("/")
        endpoint_parts = endpoint.split("/")
        if len(pattern_parts) != len(endpoint_parts):
            return False
        for p, e in zip(pattern_parts, endpoint_parts):
            if p.startswith("{") and p.endswith("}"):
                continue  # Wildcard match
            if p != e:
                return False
        return True
    
    def get(self, endpoint: str, params: Dict = None, **kwargs) -> Any:
        return self._handle_request("GET", endpoint, params=params, **kwargs)
    
    def post(self, endpoint: str, json: Dict = None, **kwargs) -> Any:
        return self._handle_request("POST", endpoint, json=json, **kwargs)
    
    def put(self, endpoint: str, json: Dict = None, **kwargs) -> Any:
        return self._handle_request("PUT", endpoint, json=json, **kwargs)
    
    def delete(self, endpoint: str, **kwargs) -> Any:
        return self._handle_request("DELETE", endpoint, **kwargs)


class MockSupero:
    """Mock Supero instance that wraps MockPlatformClient"""
    
    def __init__(self, domain_name: str = "test-domain"):
        self.domain_name = domain_name
        self._client = MockPlatformClient(domain_name=domain_name)
    
    @property
    def mock_client(self) -> MockPlatformClient:
        return self._client
    
    def set_response(self, endpoint: str, response: Any):
        self._client.set_response(endpoint, response)
    
    def set_error(self, endpoint: str, error: Exception):
        self._client.set_error(endpoint, error)
    
    def get_calls(self, endpoint: str = None) -> List[Dict]:
        return self._client.get_calls(endpoint)
    
    def last_call(self) -> Optional[Dict]:
        return self._client.last_call()
    
    def get(self, endpoint: str, params: Dict = None, **kwargs) -> Any:
        return self._client.get(endpoint, params=params, **kwargs)
    
    def post(self, endpoint: str, json: Dict = None, **kwargs) -> Any:
        return self._client.post(endpoint, json=json, **kwargs)
    
    def put(self, endpoint: str, json: Dict = None, **kwargs) -> Any:
        return self._client.put(endpoint, json=json, **kwargs)
    
    def delete(self, endpoint: str, **kwargs) -> Any:
        return self._client.delete(endpoint, **kwargs)


# Import CrudManager (adjust path as needed)
# from supero.crud_manager import CrudManager, CrudQueryBuilder

# For testing, we'll include a minimal version here
# In real tests, import from the actual module
import sys
import os

# Add the path to crud_manager if needed
# sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from supero.crud_manager import CrudManager, CrudQueryBuilder


# ============================================
# Basic CRUD Tests
# ============================================

class TestCrudManagerCreate(unittest.TestCase):
    """Test create functionality"""
    
    def setUp(self):
        self.mock_org = MockSupero(domain_name="test-domain")
        self.crud = CrudManager(self.mock_org)
    
    def test_create_basic(self):
        """Test basic object creation"""
        self.mock_org.set_response(
            "/crud/test-domain/task",
            {"uuid": "task-uuid-123", "name": "task-1", "title": "Test Task"}
        )
        
        result = self.crud.create("task", name="task-1", title="Test Task")
        
        self.assertEqual(result["uuid"], "task-uuid-123")
        self.assertEqual(result["name"], "task-1")
        
        # Verify request
        call = self.mock_org.last_call()
        self.assertEqual(call["method"], "POST")
        self.assertEqual(call["endpoint"], "/crud/test-domain/task")
        self.assertEqual(call["json"]["name"], "task-1")
        self.assertEqual(call["json"]["parent_type"], "domain")
        self.assertEqual(call["json"]["fq_name"], ["test-domain", "task-1"])
    
    def test_create_requires_name(self):
        """Test that create requires name field"""
        with self.assertRaises(ValueError) as ctx:
            self.crud.create("task", title="No Name Task")
        
        self.assertIn("'name' field is required", str(ctx.exception))
    
    def test_create_with_parent_object(self):
        """Test creating child object with parent"""
        self.mock_org.set_response(
            "/crud/test-domain/order",
            {"uuid": "order-uuid-123", "name": "order-1", "total": 99.99}
        )
        
        parent = {
            "uuid": "customer-uuid-456",
            "name": "customer-1",
            "object_type": "customer"
        }
        
        result = self.crud.create("order", parent=parent, name="order-1", total=99.99)
        
        call = self.mock_org.last_call()
        self.assertEqual(call["json"]["parent_type"], "customer")
        self.assertEqual(call["json"]["parent_uuid"], "customer-uuid-456")
        self.assertEqual(call["json"]["fq_name"], ["test-domain", "customer-1", "order-1"])
    
    def test_create_parent_requires_uuid_and_type(self):
        """Test that parent must have uuid and object_type"""
        parent = {"name": "customer-1"}  # Missing uuid and object_type
        
        with self.assertRaises(ValueError) as ctx:
            self.crud.create("order", parent=parent, name="order-1")
        
        self.assertIn("uuid", str(ctx.exception).lower())
    
    def test_create_with_api_key(self):
        """Test create with RBAC API key"""
        self.mock_org.set_response(
            "/crud/test-domain/task",
            {"uuid": "task-uuid-123", "name": "task-1"}
        )
        
        self.crud.create("task", name="task-1", api_key="secret-key-123")
        
        call = self.mock_org.last_call()
        self.assertEqual(call["headers"]["X-API-Key"], "secret-key-123")


class TestCrudManagerGet(unittest.TestCase):
    """Test get functionality"""
    
    def setUp(self):
        self.mock_org = MockSupero(domain_name="test-domain")
        self.crud = CrudManager(self.mock_org)
    
    def test_get_by_uuid(self):
        """Test getting object by UUID"""
        self.mock_org.set_response(
            "/crud/test-domain/task/task-uuid-123",
            {"uuid": "task-uuid-123", "name": "task-1", "title": "Test Task"}
        )
        
        result = self.crud.get("task", "task-uuid-123")
        
        self.assertEqual(result["uuid"], "task-uuid-123")
        self.assertEqual(result["name"], "task-1")
    
    def test_get_not_found_returns_none(self):
        """Test get returns None when object not found"""
        self.mock_org.set_error(
            "/crud/test-domain/task/nonexistent-uuid",
            Exception("Not found")
        )
        
        result = self.crud.get("task", "nonexistent-uuid")
        
        self.assertIsNone(result)
    
    def test_get_with_api_key(self):
        """Test get with RBAC API key"""
        self.mock_org.set_response(
            "/crud/test-domain/task/task-uuid-123",
            {"uuid": "task-uuid-123"}
        )
        
        self.crud.get("task", "task-uuid-123", api_key="secret-key")
        
        call = self.mock_org.last_call()
        self.assertEqual(call["headers"]["X-API-Key"], "secret-key")


class TestCrudManagerGetByFqName(unittest.TestCase):
    """Test get_by_fq_name functionality"""
    
    def setUp(self):
        self.mock_org = MockSupero(domain_name="test-domain")
        self.crud = CrudManager(self.mock_org)
    
    def test_get_by_fq_name(self):
        """Test getting object by fully qualified name"""
        self.mock_org.set_response(
            "/crud/test-domain/task/by-fq-name",
            {"uuid": "task-uuid-123", "name": "task-1", "fq_name": ["test-domain", "task-1"]}
        )
        
        result = self.crud.get_by_fq_name("task", ["test-domain", "task-1"])
        
        self.assertEqual(result["uuid"], "task-uuid-123")
        
        call = self.mock_org.last_call()
        self.assertEqual(call["json"]["fq_name"], ["test-domain", "task-1"])
    
    def test_get_by_fq_name_not_found(self):
        """Test get_by_fq_name returns None when not found"""
        self.mock_org.set_error(
            "/crud/test-domain/task/by-fq-name",
            Exception("Not found")
        )
        
        result = self.crud.get_by_fq_name("task", ["test-domain", "nonexistent"])
        
        self.assertIsNone(result)


class TestCrudManagerList(unittest.TestCase):
    """Test list functionality"""
    
    def setUp(self):
        self.mock_org = MockSupero(domain_name="test-domain")
        self.crud = CrudManager(self.mock_org)
    
    def test_list_returns_array(self):
        """Test list when response is array"""
        self.mock_org.set_response(
            "/crud/test-domain/task",
            [
                {"uuid": "uuid-1", "name": "task-1"},
                {"uuid": "uuid-2", "name": "task-2"}
            ]
        )
        
        result = self.crud.list("task")
        
        self.assertEqual(len(result), 2)
        self.assertEqual(result[0]["name"], "task-1")
    
    def test_list_returns_paginated_results(self):
        """Test list when response is paginated object with 'results'"""
        self.mock_org.set_response(
            "/crud/test-domain/task",
            {
                "results": [
                    {"uuid": "uuid-1", "name": "task-1"},
                    {"uuid": "uuid-2", "name": "task-2"}
                ],
                "total": 2,
                "page": 1
            }
        )
        
        result = self.crud.list("task")
        
        self.assertEqual(len(result), 2)
    
    def test_list_returns_paginated_items(self):
        """Test list when response is paginated object with 'items'"""
        self.mock_org.set_response(
            "/crud/test-domain/task",
            {
                "items": [
                    {"uuid": "uuid-1", "name": "task-1"}
                ]
            }
        )
        
        result = self.crud.list("task")
        
        self.assertEqual(len(result), 1)
    
    def test_list_with_limit_offset(self):
        """Test list with limit and offset parameters"""
        self.mock_org.set_response("/crud/test-domain/task", [])
        
        self.crud.list("task", limit=50, offset=10)
        
        call = self.mock_org.last_call()
        self.assertEqual(call["params"]["limit"], 50)
        self.assertEqual(call["params"]["offset"], 10)


class TestCrudManagerUpdate(unittest.TestCase):
    """Test update functionality"""
    
    def setUp(self):
        self.mock_org = MockSupero(domain_name="test-domain")
        self.crud = CrudManager(self.mock_org)
    
    def test_update_basic(self):
        """Test basic object update"""
        self.mock_org.set_response(
            "/crud/test-domain/task/task-uuid-123",
            {"uuid": "task-uuid-123", "done": True, "priority": "high"}
        )
        
        result = self.crud.update("task", "task-uuid-123", done=True, priority="high")
        
        self.assertEqual(result["done"], True)
        
        call = self.mock_org.last_call()
        self.assertEqual(call["method"], "PUT")
        self.assertEqual(call["json"]["done"], True)
        self.assertEqual(call["json"]["priority"], "high")


class TestCrudManagerDelete(unittest.TestCase):
    """Test delete functionality"""
    
    def setUp(self):
        self.mock_org = MockSupero(domain_name="test-domain")
        self.crud = CrudManager(self.mock_org)
    
    def test_delete_success(self):
        """Test successful deletion"""
        self.mock_org.set_response(
            "/crud/test-domain/task/task-uuid-123",
            {"deleted": True}
        )
        
        result = self.crud.delete("task", "task-uuid-123")
        
        self.assertTrue(result)
        
        call = self.mock_org.last_call()
        self.assertEqual(call["method"], "DELETE")
    
    def test_delete_failure_returns_false(self):
        """Test delete returns False on failure"""
        self.mock_org.set_error(
            "/crud/test-domain/task/nonexistent",
            Exception("Not found")
        )
        
        result = self.crud.delete("task", "nonexistent")
        
        self.assertFalse(result)


# ============================================
# Query Tests
# ============================================

class TestCrudQueryBuilder(unittest.TestCase):
    """Test CrudQueryBuilder functionality"""
    
    def setUp(self):
        self.mock_org = MockSupero(domain_name="test-domain")
        self.crud = CrudManager(self.mock_org)
    
    def test_query_returns_builder(self):
        """Test query() returns CrudQueryBuilder"""
        builder = self.crud.query("task")
        
        self.assertIsInstance(builder, CrudQueryBuilder)
    
    def test_filter_chaining(self):
        """Test filter chaining"""
        self.mock_org.set_response("/crud/test-domain/task/query", [])
        
        self.crud.query("task").filter(done=False).filter(priority="high").all()
        
        call = self.mock_org.last_call()
        self.assertEqual(call["json"]["filters"]["done"], False)
        self.assertEqual(call["json"]["filters"]["priority"], "high")
    
    def test_order_by(self):
        """Test order_by"""
        self.mock_org.set_response("/crud/test-domain/task/query", [])
        
        self.crud.query("task").order_by("-created_at", "name").all()
        
        call = self.mock_org.last_call()
        self.assertEqual(call["json"]["order_by"], ["-created_at", "name"])
    
    def test_limit_and_offset(self):
        """Test limit and offset"""
        self.mock_org.set_response("/crud/test-domain/task/query", [])
        
        self.crud.query("task").limit(10).offset(20).all()
        
        call = self.mock_org.last_call()
        self.assertEqual(call["json"]["limit"], 10)
        self.assertEqual(call["json"]["offset"], 20)
    
    def test_paginate(self):
        """Test paginate helper"""
        self.mock_org.set_response("/crud/test-domain/task/query", [])
        
        # Page 3 with 25 per page = offset 50, limit 25
        self.crud.query("task").paginate(page=3, per_page=25).all()
        
        call = self.mock_org.last_call()
        self.assertEqual(call["json"]["limit"], 25)
        self.assertEqual(call["json"]["offset"], 50)
    
    def test_first_limits_to_one(self):
        """Test first() sets limit to 1"""
        self.mock_org.set_response(
            "/crud/test-domain/task/query",
            [{"uuid": "uuid-1", "name": "task-1"}]
        )
        
        result = self.crud.query("task").filter(done=False).first()
        
        self.assertEqual(result["uuid"], "uuid-1")
        
        call = self.mock_org.last_call()
        self.assertEqual(call["json"]["limit"], 1)
    
    def test_first_returns_none_for_empty(self):
        """Test first() returns None for empty results"""
        self.mock_org.set_response("/crud/test-domain/task/query", [])
        
        result = self.crud.query("task").first()
        
        self.assertIsNone(result)
    
    def test_count(self):
        """Test count() on query builder"""
        self.mock_org.set_response(
            "/crud/test-domain/task/aggregate",
            {"count": 42}
        )
        
        result = self.crud.query("task").filter(done=False).count()
        
        self.assertEqual(result, 42)
    
    def test_exists_true(self):
        """Test exists() returns True when count > 0"""
        self.mock_org.set_response(
            "/crud/test-domain/task/aggregate",
            {"count": 5}
        )
        
        result = self.crud.query("task").filter(done=False).exists()
        
        self.assertTrue(result)
    
    def test_exists_false(self):
        """Test exists() returns False when count = 0"""
        self.mock_org.set_response(
            "/crud/test-domain/task/aggregate",
            {"count": 0}
        )
        
        result = self.crud.query("task").filter(name="nonexistent").exists()
        
        self.assertFalse(result)
    
    def test_with_api_key(self):
        """Test with_api_key() on query builder"""
        self.mock_org.set_response("/crud/test-domain/task/query", [])
        
        self.crud.query("task").with_api_key("secret-key").filter(done=False).all()
        
        call = self.mock_org.last_call()
        self.assertEqual(call["headers"]["X-API-Key"], "secret-key")
    
    def test_delete_all(self):
        """Test delete_all() on query builder"""
        self.mock_org.set_response(
            "/crud/test-domain/task/delete-all",
            {"deleted": 15}
        )
        
        result = self.crud.query("task").filter(done=True).delete_all()
        
        self.assertEqual(result, 15)
        
        call = self.mock_org.last_call()
        self.assertEqual(call["json"]["filters"]["done"], True)


class TestCrudManagerFind(unittest.TestCase):
    """Test find functionality"""
    
    def setUp(self):
        self.mock_org = MockSupero(domain_name="test-domain")
        self.crud = CrudManager(self.mock_org)
    
    def test_find_with_filters(self):
        """Test find() is shortcut for query().filter().all()"""
        self.mock_org.set_response(
            "/crud/test-domain/task/query",
            [{"uuid": "uuid-1", "done": False, "priority": "high"}]
        )
        
        result = self.crud.find("task", done=False, priority="high")
        
        self.assertEqual(len(result), 1)
        
        call = self.mock_org.last_call()
        self.assertEqual(call["json"]["filters"]["done"], False)
        self.assertEqual(call["json"]["filters"]["priority"], "high")


# ============================================
# Aggregation Tests
# ============================================

class TestCrudManagerAggregations(unittest.TestCase):
    """Test aggregation functionality"""
    
    def setUp(self):
        self.mock_org = MockSupero(domain_name="test-domain")
        self.crud = CrudManager(self.mock_org)
    
    def test_count_all(self):
        """Test count all objects"""
        self.mock_org.set_response(
            "/crud/test-domain/task/aggregate",
            {"count": 100}
        )
        
        result = self.crud.count("task")
        
        self.assertEqual(result, 100)
        
        call = self.mock_org.last_call()
        self.assertEqual(call["json"]["op"], "count")
    
    def test_count_with_filters(self):
        """Test count with filters"""
        self.mock_org.set_response(
            "/crud/test-domain/task/aggregate",
            {"count": 25}
        )
        
        result = self.crud.count("task", done=False)
        
        self.assertEqual(result, 25)
        
        call = self.mock_org.last_call()
        self.assertEqual(call["json"]["filters"]["done"], False)
    
    def test_sum(self):
        """Test sum aggregation"""
        self.mock_org.set_response(
            "/crud/test-domain/order/aggregate",
            {"sum": 9999.99}
        )
        
        result = self.crud.sum("order", "amount")
        
        self.assertEqual(result, 9999.99)
        
        call = self.mock_org.last_call()
        self.assertEqual(call["json"]["op"], "sum")
        self.assertEqual(call["json"]["field"], "amount")
    
    def test_sum_with_filters(self):
        """Test sum with filters"""
        self.mock_org.set_response(
            "/crud/test-domain/order/aggregate",
            {"sum": 5000.00}
        )
        
        result = self.crud.sum("order", "amount", status="completed")
        
        call = self.mock_org.last_call()
        self.assertEqual(call["json"]["filters"]["status"], "completed")
    
    def test_avg(self):
        """Test average aggregation"""
        self.mock_org.set_response(
            "/crud/test-domain/product/aggregate",
            {"avg": 49.99}
        )
        
        result = self.crud.avg("product", "price")
        
        self.assertEqual(result, 49.99)
        
        call = self.mock_org.last_call()
        self.assertEqual(call["json"]["op"], "avg")
    
    def test_min(self):
        """Test min aggregation"""
        self.mock_org.set_response(
            "/crud/test-domain/product/aggregate",
            {"min": 9.99}
        )
        
        result = self.crud.min("product", "price")
        
        self.assertEqual(result, 9.99)
        
        call = self.mock_org.last_call()
        self.assertEqual(call["json"]["op"], "min")
    
    def test_max(self):
        """Test max aggregation"""
        self.mock_org.set_response(
            "/crud/test-domain/product/aggregate",
            {"max": 999.99}
        )
        
        result = self.crud.max("product", "price")
        
        self.assertEqual(result, 999.99)
        
        call = self.mock_org.last_call()
        self.assertEqual(call["json"]["op"], "max")
    
    def test_distinct(self):
        """Test distinct aggregation"""
        self.mock_org.set_response(
            "/crud/test-domain/task/aggregate",
            {"distinct": ["pending", "active", "done"]}
        )
        
        result = self.crud.distinct("task", "status")
        
        self.assertEqual(result, ["pending", "active", "done"])
        
        call = self.mock_org.last_call()
        self.assertEqual(call["json"]["op"], "distinct")
    
    def test_distinct_with_values_key(self):
        """Test distinct with 'values' response key"""
        self.mock_org.set_response(
            "/crud/test-domain/task/aggregate",
            {"values": ["low", "medium", "high"]}
        )
        
        result = self.crud.distinct("task", "priority")
        
        self.assertEqual(result, ["low", "medium", "high"])
    
    def test_count_by(self):
        """Test count_by aggregation"""
        self.mock_org.set_response(
            "/crud/test-domain/task/aggregate",
            {"count_by": {"pending": 5, "active": 10, "done": 25}}
        )
        
        result = self.crud.count_by("task", "status")
        
        self.assertEqual(result["pending"], 5)
        self.assertEqual(result["active"], 10)
        self.assertEqual(result["done"], 25)
        
        call = self.mock_org.last_call()
        self.assertEqual(call["json"]["op"], "count_by")
    
    def test_stats(self):
        """Test stats aggregation"""
        self.mock_org.set_response(
            "/crud/test-domain/order/aggregate",
            {"stats": {"count": 100, "sum": 5000, "avg": 50.0, "min": 10, "max": 200}}
        )
        
        result = self.crud.stats("order", "amount")
        
        self.assertEqual(result["count"], 100)
        self.assertEqual(result["sum"], 5000)
        self.assertEqual(result["avg"], 50.0)
        
        call = self.mock_org.last_call()
        self.assertEqual(call["json"]["op"], "stats")
    
    def test_generic_aggregate(self):
        """Test generic aggregate method"""
        self.mock_org.set_response(
            "/crud/test-domain/order/aggregate",
            {"sum": 12345.67}
        )
        
        result = self.crud.aggregate("order", "sum", "amount", status="completed")
        
        self.assertEqual(result, 12345.67)
        
        call = self.mock_org.last_call()
        self.assertEqual(call["json"]["op"], "sum")
        self.assertEqual(call["json"]["field"], "amount")
        self.assertEqual(call["json"]["filters"]["status"], "completed")


# ============================================
# Reference Tests
# ============================================

class TestCrudManagerReferences(unittest.TestCase):
    """Test reference functionality"""
    
    def setUp(self):
        self.mock_org = MockSupero(domain_name="test-domain")
        self.crud = CrudManager(self.mock_org)
    
    def test_set_ref(self):
        """Test setting a reference"""
        self.mock_org.set_response(
            "/crud/test-domain/order/order-uuid/ref",
            {"uuid": "order-uuid", "customer_refs": ["customer-uuid"]}
        )
        
        result = self.crud.set_ref("order", "order-uuid", "customer", "customer-uuid")
        
        call = self.mock_org.last_call()
        self.assertEqual(call["method"], "POST")
        self.assertEqual(call["json"]["ref_field"], "customer")
        self.assertEqual(call["json"]["ref_uuid"], "customer-uuid")
    
    def test_set_ref_with_link_data(self):
        """Test setting a reference with link data"""
        self.mock_org.set_response(
            "/crud/test-domain/order/order-uuid/ref",
            {"uuid": "order-uuid"}
        )
        
        self.crud.set_ref("order", "order-uuid", "customer", "customer-uuid", 
                         role="primary", notes="VIP")
        
        call = self.mock_org.last_call()
        self.assertEqual(call["json"]["link_data"]["role"], "primary")
        self.assertEqual(call["json"]["link_data"]["notes"], "VIP")
    
    def test_get_ref(self):
        """Test getting a reference"""
        self.mock_org.set_response(
            "/crud/test-domain/order/order-uuid/ref/customer",
            {"target": {"uuid": "customer-uuid", "name": "cust-1"}, "link_data": {"role": "primary"}}
        )
        
        result = self.crud.get_ref("order", "order-uuid", "customer")
        
        self.assertEqual(result["target"]["uuid"], "customer-uuid")
        self.assertEqual(result["link_data"]["role"], "primary")
    
    def test_get_ref_not_found(self):
        """Test get_ref returns None when not found"""
        self.mock_org.set_error(
            "/crud/test-domain/order/order-uuid/ref/nonexistent",
            Exception("Not found")
        )
        
        result = self.crud.get_ref("order", "order-uuid", "nonexistent")
        
        self.assertIsNone(result)
    
    def test_update_ref(self):
        """Test updating reference link data"""
        self.mock_org.set_response(
            "/crud/test-domain/order/order-uuid/ref",
            {"uuid": "order-uuid"}
        )
        
        self.crud.update_ref("order", "order-uuid", "customer", role="secondary", notes="Updated")
        
        call = self.mock_org.last_call()
        self.assertEqual(call["method"], "PUT")
        self.assertEqual(call["json"]["ref_field"], "customer")
        self.assertEqual(call["json"]["link_data"]["role"], "secondary")
    
    def test_remove_ref_success(self):
        """Test removing a reference"""
        self.mock_org.set_response(
            "/crud/test-domain/order/order-uuid/ref/customer",
            {"deleted": True}
        )
        
        result = self.crud.remove_ref("order", "order-uuid", "customer")
        
        self.assertTrue(result)
        
        call = self.mock_org.last_call()
        self.assertEqual(call["method"], "DELETE")
    
    def test_remove_ref_failure(self):
        """Test remove_ref returns False on failure"""
        self.mock_org.set_error(
            "/crud/test-domain/order/order-uuid/ref/customer",
            Exception("Not found")
        )
        
        result = self.crud.remove_ref("order", "order-uuid", "customer")
        
        self.assertFalse(result)


# ============================================
# Bulk Operation Tests
# ============================================

class TestCrudManagerBulkOperations(unittest.TestCase):
    """Test bulk operation functionality"""
    
    def setUp(self):
        self.mock_org = MockSupero(domain_name="test-domain")
        self.crud = CrudManager(self.mock_org)
    
    def test_bulk_get(self):
        """Test bulk get by UUIDs"""
        self.mock_org.set_response(
            "/crud/test-domain/task/bulk-get",
            [
                {"uuid": "uuid-1", "name": "task-1"},
                {"uuid": "uuid-2", "name": "task-2"}
            ]
        )
        
        result = self.crud.bulk_get("task", ["uuid-1", "uuid-2"])
        
        self.assertEqual(len(result), 2)
        
        call = self.mock_org.last_call()
        self.assertEqual(call["json"]["uuids"], ["uuid-1", "uuid-2"])
    
    def test_bulk_create(self):
        """Test bulk create"""
        self.mock_org.set_response(
            "/crud/test-domain/task/bulk-create",
            {
                "created": [
                    {"uuid": "uuid-1", "name": "task-1"},
                    {"uuid": "uuid-2", "name": "task-2"}
                ]
            }
        )
        
        items = [
            {"name": "task-1", "title": "Task 1"},
            {"name": "task-2", "title": "Task 2"}
        ]
        
        result = self.crud.bulk_create("task", items)
        
        self.assertEqual(len(result), 2)
        
        call = self.mock_org.last_call()
        self.assertEqual(call["json"]["items"][0]["parent_type"], "domain")
        self.assertEqual(call["json"]["items"][0]["fq_name"], ["test-domain", "task-1"])
    
    def test_bulk_create_does_not_mutate_input(self):
        """Test bulk_create does not mutate input list"""
        items = [
            {"name": "task-1", "title": "Task 1"},
            {"name": "task-2", "title": "Task 2"}
        ]
        original_items = copy.deepcopy(items)
        
        self.mock_org.set_response("/crud/test-domain/task/bulk-create", {"created": []})
        
        self.crud.bulk_create("task", items)
        
        # Original items should be unchanged
        self.assertEqual(items, original_items)
        self.assertNotIn("fq_name", items[0])
        self.assertNotIn("parent_type", items[0])
    
    def test_bulk_create_requires_name(self):
        """Test bulk_create requires name in each item"""
        items = [
            {"title": "Task 1"},  # Missing name
        ]
        
        with self.assertRaises(ValueError) as ctx:
            self.crud.bulk_create("task", items)
        
        self.assertIn("name", str(ctx.exception).lower())
    
    def test_bulk_update(self):
        """Test bulk update"""
        self.mock_org.set_response(
            "/crud/test-domain/task/bulk-update",
            {
                "updated": [
                    {"uuid": "uuid-1", "done": True},
                    {"uuid": "uuid-2", "done": True}
                ]
            }
        )
        
        updates = [
            {"uuid": "uuid-1", "done": True},
            {"uuid": "uuid-2", "done": True}
        ]
        
        result = self.crud.bulk_update("task", updates)
        
        self.assertEqual(len(result), 2)
        
        call = self.mock_org.last_call()
        self.assertEqual(call["json"]["updates"], updates)
    
    def test_bulk_update_requires_uuid(self):
        """Test bulk_update requires uuid in each update"""
        updates = [
            {"done": True},  # Missing uuid
        ]
        
        with self.assertRaises(ValueError) as ctx:
            self.crud.bulk_update("task", updates)
        
        self.assertIn("uuid", str(ctx.exception).lower())
    
    def test_bulk_delete(self):
        """Test bulk delete"""
        self.mock_org.set_response(
            "/crud/test-domain/task/bulk-delete",
            {"deleted": 3}
        )
        
        result = self.crud.bulk_delete("task", ["uuid-1", "uuid-2", "uuid-3"])
        
        self.assertEqual(result, 3)
        
        call = self.mock_org.last_call()
        self.assertEqual(call["json"]["uuids"], ["uuid-1", "uuid-2", "uuid-3"])


# ============================================
# Convenience Method Tests
# ============================================

class TestCrudManagerConvenienceMethods(unittest.TestCase):
    """Test convenience methods"""
    
    def setUp(self):
        self.mock_org = MockSupero(domain_name="test-domain")
        self.crud = CrudManager(self.mock_org)
    
    def test_exists_true(self):
        """Test exists returns True when objects match"""
        self.mock_org.set_response(
            "/crud/test-domain/user/aggregate",
            {"count": 1}
        )
        
        result = self.crud.exists("user", email="test@example.com")
        
        self.assertTrue(result)
    
    def test_exists_false(self):
        """Test exists returns False when no objects match"""
        self.mock_org.set_response(
            "/crud/test-domain/user/aggregate",
            {"count": 0}
        )
        
        result = self.crud.exists("user", email="nonexistent@example.com")
        
        self.assertFalse(result)
    
    def test_get_by_name(self):
        """Test get_by_name"""
        self.mock_org.set_response(
            "/crud/test-domain/task/query",
            [{"uuid": "uuid-1", "name": "task-001", "title": "Test Task"}]
        )
        
        result = self.crud.get_by_name("task", "task-001")
        
        self.assertEqual(result["uuid"], "uuid-1")
        
        call = self.mock_org.last_call()
        self.assertEqual(call["json"]["filters"]["name"], "task-001")
    
    def test_get_by_name_not_found(self):
        """Test get_by_name returns None when not found"""
        self.mock_org.set_response("/crud/test-domain/task/query", [])
        
        result = self.crud.get_by_name("task", "nonexistent")
        
        self.assertIsNone(result)
    
    def test_get_or_create_existing(self):
        """Test get_or_create returns existing object"""
        self.mock_org.set_response(
            "/crud/test-domain/task/query",
            [{"uuid": "existing-uuid", "name": "task-001", "title": "Existing"}]
        )
        
        result, created = self.crud.get_or_create("task", "task-001", title="Default Title")
        
        self.assertEqual(result["uuid"], "existing-uuid")
        self.assertFalse(created)
    
    def test_get_or_create_new(self):
        """Test get_or_create creates new object"""
        # First call: query returns empty
        self.mock_org.set_response("/crud/test-domain/task/query", [])
        # Second call: create returns new object
        self.mock_org.set_response(
            "/crud/test-domain/task",
            {"uuid": "new-uuid", "name": "task-001", "title": "Default Title"}
        )
        
        result, created = self.crud.get_or_create("task", "task-001", title="Default Title")
        
        self.assertEqual(result["uuid"], "new-uuid")
        self.assertTrue(created)
    
    def test_update_or_create_existing(self):
        """Test update_or_create updates existing object"""
        # First call: query returns existing
        self.mock_org.set_response(
            "/crud/test-domain/task/query",
            [{"uuid": "existing-uuid", "name": "task-001"}]
        )
        # Second call: update
        self.mock_org.set_response(
            "/crud/test-domain/task/existing-uuid",
            {"uuid": "existing-uuid", "name": "task-001", "done": True}
        )
        
        result, created = self.crud.update_or_create("task", "task-001", done=True)
        
        self.assertFalse(created)
        
        # Verify update was called
        calls = self.mock_org.get_calls()
        update_call = [c for c in calls if c["method"] == "PUT"][0]
        self.assertEqual(update_call["json"]["done"], True)
    
    def test_update_or_create_new(self):
        """Test update_or_create creates new object"""
        # First call: query returns empty
        self.mock_org.set_response("/crud/test-domain/task/query", [])
        # Second call: create
        self.mock_org.set_response(
            "/crud/test-domain/task",
            {"uuid": "new-uuid", "name": "task-001", "done": True}
        )
        
        result, created = self.crud.update_or_create("task", "task-001", done=True)
        
        self.assertTrue(created)


# ============================================
# Edge Cases and Error Handling Tests
# ============================================

class TestCrudManagerEdgeCases(unittest.TestCase):
    """Test edge cases and error handling"""
    
    def setUp(self):
        self.mock_org = MockSupero(domain_name="test-domain")
        self.crud = CrudManager(self.mock_org)
    
    def test_endpoint_building(self):
        """Test endpoint URL building"""
        # Basic endpoint
        endpoint = self.crud._endpoint("task")
        self.assertEqual(endpoint, "/crud/test-domain/task")
        
        # With UUID
        endpoint = self.crud._endpoint("task", "uuid-123")
        self.assertEqual(endpoint, "/crud/test-domain/task/uuid-123")
        
        # With multiple parts
        endpoint = self.crud._endpoint("task", "uuid-123", "ref", "customer")
        self.assertEqual(endpoint, "/crud/test-domain/task/uuid-123/ref/customer")
    
    def test_request_kwargs_without_api_key(self):
        """Test _request_kwargs returns empty dict without api_key"""
        kwargs = self.crud._request_kwargs()
        self.assertEqual(kwargs, {})
    
    def test_request_kwargs_with_api_key(self):
        """Test _request_kwargs includes headers with api_key"""
        kwargs = self.crud._request_kwargs(api_key="secret-key")
        self.assertEqual(kwargs["headers"]["X-API-Key"], "secret-key")
    
    def test_aggregate_result_fallback(self):
        """Test aggregations fallback to 'result' key"""
        self.mock_org.set_response(
            "/crud/test-domain/task/aggregate",
            {"result": 42}  # Using 'result' instead of 'count'
        )
        
        result = self.crud.count("task")
        
        self.assertEqual(result, 42)
    
    def test_list_empty_response(self):
        """Test list handles empty response"""
        self.mock_org.set_response("/crud/test-domain/task", {})
        
        result = self.crud.list("task")
        
        self.assertEqual(result, [])
    
    def test_query_builder_repr(self):
        """Test CrudQueryBuilder string representation"""
        builder = self.crud.query("task").filter(done=False, priority="high")
        
        repr_str = repr(builder)
        
        self.assertIn("task", repr_str)
        self.assertIn("done", repr_str)


# ============================================
# Integration-style Tests
# ============================================

class TestCrudManagerIntegration(unittest.TestCase):
    """Integration-style tests for common workflows"""
    
    def setUp(self):
        self.mock_org = MockSupero(domain_name="test-domain")
        self.crud = CrudManager(self.mock_org)
    
    def test_crud_workflow(self):
        """Test complete CRUD workflow"""
        # Create
        self.mock_org.set_response(
            "/crud/test-domain/task",
            {"uuid": "task-uuid", "name": "task-1", "title": "Test", "done": False}
        )
        task = self.crud.create("task", name="task-1", title="Test")
        self.assertEqual(task["uuid"], "task-uuid")
        
        # Read
        self.mock_org.set_response(
            "/crud/test-domain/task/task-uuid",
            {"uuid": "task-uuid", "name": "task-1", "title": "Test", "done": False}
        )
        task = self.crud.get("task", "task-uuid")
        self.assertFalse(task["done"])
        
        # Update
        self.mock_org.set_response(
            "/crud/test-domain/task/task-uuid",
            {"uuid": "task-uuid", "name": "task-1", "title": "Test", "done": True}
        )
        task = self.crud.update("task", "task-uuid", done=True)
        self.assertTrue(task["done"])
        
        # Delete
        self.mock_org.set_response(
            "/crud/test-domain/task/task-uuid",
            {"deleted": True}
        )
        result = self.crud.delete("task", "task-uuid")
        self.assertTrue(result)
    
    def test_parent_child_workflow(self):
        """Test parent-child object creation"""
        # Create parent
        self.mock_org.set_response(
            "/crud/test-domain/customer",
            {"uuid": "customer-uuid", "name": "cust-1", "object_type": "customer"}
        )
        customer = self.crud.create("customer", name="cust-1", email="test@example.com")
        
        # Create child with parent
        self.mock_org.set_response(
            "/crud/test-domain/order",
            {"uuid": "order-uuid", "name": "order-1", "parent_type": "customer"}
        )
        order = self.crud.create("order", parent=customer, name="order-1", total=99.99)
        
        # Verify parent was set correctly
        call = self.mock_org.last_call()
        self.assertEqual(call["json"]["parent_type"], "customer")
        self.assertEqual(call["json"]["parent_uuid"], "customer-uuid")
    
    def test_query_and_aggregate_workflow(self):
        """Test querying and aggregating data"""
        # Query
        self.mock_org.set_response(
            "/crud/test-domain/order/query",
            [
                {"uuid": "uuid-1", "amount": 100},
                {"uuid": "uuid-2", "amount": 200}
            ]
        )
        orders = self.crud.query("order").filter(status="completed").order_by("-amount").limit(10).all()
        self.assertEqual(len(orders), 2)
        
        # Aggregate
        self.mock_org.set_response(
            "/crud/test-domain/order/aggregate",
            {"sum": 300}
        )
        total = self.crud.sum("order", "amount", status="completed")
        self.assertEqual(total, 300)


# ============================================
# SchemaProxy / NamespaceProxy Tests
# ============================================

class TestSchemaProxy(unittest.TestCase):
    """Test SchemaProxy routes all CRUD calls through the correct namespace."""

    def setUp(self):
        from supero.crud_manager import SchemaProxyNS, NamespaceProxy, CrudManager
        self.mock_org = MockSupero()
        self.mock_org.set_response("/crud/test-domain/billing:customer", {"uuid": "c1", "name": "c1"})
        self.mock_org.set_response("/crud/test-domain/billing:customer/c1", {"uuid": "c1", "name": "c1"})
        self.mock_org.set_response("/crud/test-domain/billing:customer/query", [])
        self.crud = CrudManager(self.mock_org)
        self.proxy = SchemaProxyNS(self.crud, "customer", namespace="billing")

    def test_proxy_create_uses_namespace(self):
        self.proxy.create(name="c1")
        self.assertIn("billing:customer", self.mock_org.last_call()["endpoint"])

    def test_proxy_get_uses_namespace(self):
        self.proxy.get("c1")
        self.assertIn("billing:customer", self.mock_org.last_call()["endpoint"])

    def test_proxy_list_uses_namespace(self):
        self.mock_org.set_response("/crud/test-domain/billing:customer", [])
        self.proxy.list()
        self.assertIn("billing:customer", self.mock_org.last_call()["endpoint"])

    def test_proxy_update_uses_namespace(self):
        self.proxy.update("c1", email="new@example.com")
        self.assertIn("billing:customer", self.mock_org.last_call()["endpoint"])

    def test_proxy_delete_uses_namespace(self):
        self.proxy.delete("c1")
        self.assertIn("billing:customer", self.mock_org.last_call()["endpoint"])

    def test_proxy_query_uses_namespace(self):
        self.mock_org.set_response("/crud/test-domain/billing:customer/query", [{"uuid": "c1"}])
        self.proxy.query().all()
        self.assertIn("billing:customer", self.mock_org.last_call()["endpoint"])

    def test_proxy_repr(self):
        self.assertIn("billing", repr(self.proxy))
        self.assertIn("customer", repr(self.proxy))


class TestNamespaceProxy(unittest.TestCase):
    """Test NamespaceProxy attribute access returns correctly configured SchemaProxies."""

    def setUp(self):
        from supero.crud_manager import NamespaceProxy, CrudManager
        self.mock_org = MockSupero()
        self.crud = CrudManager(self.mock_org)
        self.billing = NamespaceProxy(self.crud, "billing")

    def test_attribute_access_returns_schema_proxy(self):
        from supero.crud_manager import SchemaProxyNS
        proxy = self.billing.customer
        self.assertIsInstance(proxy, SchemaProxyNS)

    def test_proxy_namespace_is_set_correctly(self):
        proxy = self.billing.customer
        self.assertEqual(proxy._ns, "billing")
        self.assertEqual(proxy._type, "customer")

    def test_two_types_in_same_namespace(self):
        from supero.crud_manager import SchemaProxyNS
        self.assertIsInstance(self.billing.customer, SchemaProxyNS)
        self.assertIsInstance(self.billing.invoice, SchemaProxyNS)
        self.assertEqual(self.billing.invoice._type, "invoice")

    def test_crud_manager_ns_method_returns_namespace_proxy(self):
        from supero.crud_manager import NamespaceProxy
        ns = self.crud.ns("crm")
        self.assertIsInstance(ns, NamespaceProxy)
        self.assertEqual(ns._ns, "crm")

    def test_ns_method_customer_routes_correctly(self):
        self.mock_org.set_response("/crud/test-domain/crm:contact", {"uuid": "c1", "name": "c1"})
        self.crud.ns("crm").contact.create(name="c1")
        self.assertIn("crm:contact", self.mock_org.last_call()["endpoint"])

    def test_default_namespace_proxy_no_colon(self):
        """Proxy for default namespace must NOT add colon prefix to endpoint."""
        self.mock_org.set_response("/crud/test-domain/task", {"uuid": "t1", "name": "t1"})
        self.crud.ns("default").task.create(name="t1")
        endpoint = self.mock_org.last_call()["endpoint"]
        # default namespace should not appear as "default:task"
        self.assertNotIn("default:task", endpoint)


# ============================================
# Namespace Tests
# ============================================

class TestCrudManagerNamespace(unittest.TestCase):
    """Test namespace-qualified URL routing in CrudManager."""

    def setUp(self):
        self.mock_org = MockSupero()
        self.mock_org.set_response("/crud/test-domain/billing:customer", {"uuid": "cust-1", "name": "c1"})
        self.mock_org.set_response("/crud/test-domain/billing:customer/cust-1", {"uuid": "cust-1", "name": "c1"})
        self.mock_org.set_response("/crud/test-domain/billing:customer/query", [])
        from supero.crud_manager import CrudManager
        self.crud = CrudManager(self.mock_org)

    def test_create_with_namespace_uses_qualified_endpoint(self):
        """create() with namespace= sends request to billing:customer endpoint."""
        self.crud.create("customer", namespace="billing", name="c1")
        call = self.mock_org.last_call()
        self.assertIn("billing:customer", call["endpoint"])

    def test_get_with_namespace_uses_qualified_endpoint(self):
        """get() with namespace= sends request to billing:customer/{uuid} endpoint."""
        self.crud.get("customer", "cust-1", namespace="billing")
        call = self.mock_org.last_call()
        self.assertIn("billing:customer", call["endpoint"])

    def test_list_with_namespace_uses_qualified_endpoint(self):
        """list() with namespace= sends request to billing:customer endpoint."""
        self.mock_org.set_response(
            "/crud/test-domain/billing:customer",
            [{"uuid": "cust-1", "name": "c1"}]
        )
        self.crud.list("customer", namespace="billing")
        call = self.mock_org.last_call()
        self.assertIn("billing:customer", call["endpoint"])

    def test_update_with_namespace_uses_qualified_endpoint(self):
        """update() with namespace= sends PUT to billing:customer/{uuid} endpoint."""
        self.crud.update("customer", "cust-1", namespace="billing", email="new@example.com")
        call = self.mock_org.last_call()
        self.assertIn("billing:customer", call["endpoint"])
        self.assertIn("cust-1", call["endpoint"])

    def test_delete_with_namespace_uses_qualified_endpoint(self):
        """delete() with namespace= sends DELETE to billing:customer/{uuid} endpoint."""
        self.mock_org.set_response("/crud/test-domain/billing:customer/cust-1", True)
        self.crud.delete("customer", "cust-1", namespace="billing")
        call = self.mock_org.last_call()
        self.assertIn("billing:customer", call["endpoint"])
        self.assertIn("cust-1", call["endpoint"])

    def test_query_with_namespace_uses_qualified_endpoint(self):
        """query() with namespace= builds query against billing:customer."""
        self.mock_org.set_response(
            "/crud/test-domain/billing:customer/query",
            [{"uuid": "cust-1"}]
        )
        self.crud.query("customer", namespace="billing").filter(status="active").all()
        call = self.mock_org.last_call()
        self.assertIn("billing:customer", call["endpoint"])

    def test_no_namespace_uses_plain_endpoint(self):
        """Without namespace=, endpoint is unqualified (backward compat)."""
        self.mock_org.set_response("/crud/test-domain/customer", {"uuid": "c1", "name": "c1"})
        self.crud.create("customer", name="c1")
        call = self.mock_org.last_call()
        self.assertNotIn(":", call["endpoint"].split("/crud/test-domain/")[-1])

    def test_namespace_not_doubled_when_already_qualified(self):
        """Endpoint should not double-qualify if type already contains ':'."""
        # _qualified_type skips qualification if namespace is empty
        self.mock_org.set_response("/crud/test-domain/customer", {"uuid": "c1", "name": "c1"})
        self.crud.create("customer", name="c1")
        call = self.mock_org.last_call()
        self.assertEqual(call["endpoint"].count("billing"), 0)


# ============================================
# Run Tests
# ============================================

if __name__ == "__main__":
    unittest.main(verbosity=2)
