"""
test_cli_recent_additions.py — Unit tests for recently added CLI functions.

Covers:
  - _ensure_e2e_tests: generation, version stamp, stale detection, skip conditions
  - _ensure_docs_files: CUSTOMIZATION.md generation (new addition)
  - _ensure_crud_tests: version stamp, stale file regeneration
  - _to_snake: PascalCase to snake_case conversion
  - make_payload: test payload generation with parent_context, enums, list types
  - E2E_TESTS_VERSION / CRUD_TESTS_VERSION constants

Run:
    python -m pytest test_cli_recent_additions.py -v
    python -m pytest test_cli_recent_additions.py -v -k "e2e"
    python -m pytest test_cli_recent_additions.py -v -k "customization"
"""

import os
import sys
import shutil
import tempfile
import textwrap
import time
import ast
import unittest

# ── Setup import path ──
_HERE = os.path.dirname(os.path.abspath(__file__))
_SRC = os.path.join(_HERE, "..", "src")
sys.path.insert(0, _SRC)

from supero.cli.run import (
    _ensure_crud_tests,
    CRUD_TESTS_VERSION,
)

# _to_snake lives inside the crud_tests template string (not a real function).
# Define it locally for testing — same regex as in the template.
import re as _re
def _to_snake(name):
    return _re.sub(r'(?<!^)(?=[A-Z])', '_', name).lower()

# Conditionally import new additions (may not exist in older branches)
try:
    from supero.cli.run import _ensure_e2e_tests, E2E_TESTS_VERSION
    HAS_E2E = True
except ImportError:
    HAS_E2E = False

try:
    from supero.cli.run import _ensure_docs_files
    HAS_DOCS = True
except ImportError:
    HAS_DOCS = False

try:
    from supero.cli._customization_template import CUSTOMIZATION_TEMPLATE
    HAS_CUSTOMIZATION = True
except ImportError:
    HAS_CUSTOMIZATION = False


class _TempAppDir:
    """Context manager that creates a temp dir with schemas.py + config.py."""

    def __init__(self, with_schemas=True, with_config=True):
        self._with_schemas = with_schemas
        self._with_config = with_config
        self.path = None

    def __enter__(self):
        self.path = tempfile.mkdtemp(prefix="supero_test_")
        if self._with_schemas:
            with open(os.path.join(self.path, "schemas.py"), "w") as f:
                f.write(textwrap.dedent('''\
                    SUPERO_APP_NAMESPACE = "testapp"
                    ALL_SCHEMAS = [
                        {"name": "Product", "namespace": "testapp", "schema_type": "object",
                         "parent_type": "tenant", "display_name": "Product",
                         "attributes": [
                             {"name": "product_name", "type": "string", "mandatory": True},
                             {"name": "price", "type": "float", "mandatory": True},
                             {"name": "status", "type": "ProductStatus"},
                             {"name": "featured_image", "type": "Image"},
                             {"name": "tags", "type": "string", "list": True},
                         ],
                         "references": [{"name": "Category", "cardinality": "one"}]},
                        {"name": "Category", "namespace": "testapp", "schema_type": "object",
                         "parent_type": "tenant", "display_name": "Category",
                         "attributes": [
                             {"name": "category_name", "type": "string", "mandatory": True},
                         ]},
                        {"name": "ProductStatus", "namespace": "testapp", "schema_type": "enum",
                         "type": "string", "values": ["draft", "active", "discontinued"]},
                    ]
                '''))
        if self._with_config:
            with open(os.path.join(self.path, "config.py"), "w") as f:
                f.write(textwrap.dedent('''\
                    from dataclasses import dataclass, field
                    @dataclass
                    class AppConfig:
                        app_name: str = "Test App"
                        app_emoji: str = "🧪"
                        tenants: list = field(default_factory=lambda: [
                            {"name": "default-tenant", "display_name": "Default"},
                        ])
                        users: list = field(default_factory=list)
                        services: list = field(default_factory=list)
                '''))
        return self

    def __exit__(self, *args):
        shutil.rmtree(self.path, ignore_errors=True)


# ===============================================================
# _to_snake tests
# ===============================================================

class TestToSnake(unittest.TestCase):
    """Test PascalCase -> snake_case conversion."""

    def test_simple_pascal(self):
        self.assertEqual(_to_snake("ProductVariant"), "product_variant")

    def test_single_word(self):
        self.assertEqual(_to_snake("Product"), "product")

    def test_already_snake(self):
        self.assertEqual(_to_snake("product_variant"), "product_variant")

    def test_all_caps(self):
        self.assertEqual(_to_snake("API"), "a_p_i")

    def test_mixed_acronym(self):
        self.assertEqual(_to_snake("APIKey"), "a_p_i_key")

    def test_empty_string(self):
        self.assertEqual(_to_snake(""), "")

    def test_lower_case(self):
        self.assertEqual(_to_snake("product"), "product")

    def test_three_words(self):
        self.assertEqual(_to_snake("OrderLineItem"), "order_line_item")

    def test_with_numbers(self):
        self.assertEqual(_to_snake("Phase2Result"), "phase2_result")

    def test_consecutive_caps(self):
        # Documents actual behavior: consecutive caps each get underscore
        result = _to_snake("HTMLParser")
        self.assertEqual(result, result.lower(), "Result should be lowercase")
        self.assertIn("parser", result)


# ===============================================================
# _ensure_crud_tests tests
# ===============================================================

class TestEnsureCrudTests(unittest.TestCase):
    """Test crud_tests.py generation and version stamping."""

    def test_generates_crud_tests(self):
        with _TempAppDir() as d:
            _ensure_crud_tests(d.path)
            dest = os.path.join(d.path, "tests", "crud_tests.py")  # TEST_CRUD_PATH_V1
            self.assertTrue(os.path.exists(dest))

    def test_has_version_stamp(self):
        with _TempAppDir() as d:
            _ensure_crud_tests(d.path)
            dest = os.path.join(d.path, "tests", "crud_tests.py")  # TEST_CRUD_PATH_V1
            with open(dest) as f:
                first_line = f.readline().strip()
            self.assertIn("CRUD_TESTS_TEMPLATE_VERSION:", first_line)
            self.assertIn(CRUD_TESTS_VERSION, first_line)

    def test_skip_if_current_version(self):
        with _TempAppDir() as d:
            _ensure_crud_tests(d.path)
            dest = os.path.join(d.path, "tests", "crud_tests.py")  # TEST_CRUD_PATH_V1
            with open(dest) as f:
                content1 = f.read()
            # Append a marker — if regenerated, marker would be gone
            with open(dest, "a") as f:
                f.write("\n# MARKER_SHOULD_SURVIVE\n")
            _ensure_crud_tests(d.path)  # should skip (version matches)
            with open(dest) as f:
                content2 = f.read()
            self.assertIn("MARKER_SHOULD_SURVIVE", content2,
                          "File should not be rewritten when version matches")

    def test_regenerates_stale_version(self):
        with _TempAppDir() as d:
            _ensure_crud_tests(d.path)
            dest = os.path.join(d.path, "tests", "crud_tests.py")  # TEST_CRUD_PATH_V1
            # Write a fake old version stamp
            with open(dest, "w") as f:
                f.write("# CRUD_TESTS_TEMPLATE_VERSION: 0\nold content\n")
            _ensure_crud_tests(d.path)
            with open(dest) as f:
                content = f.read()
            self.assertIn(CRUD_TESTS_VERSION, content.split("\n")[0])
            self.assertNotIn("old content", content)

    def test_skip_without_schemas(self):
        with _TempAppDir(with_schemas=False) as d:
            _ensure_crud_tests(d.path)
            dest = os.path.join(d.path, "tests", "crud_tests.py")  # TEST_CRUD_PATH_V1
            self.assertFalse(os.path.exists(dest))

    def test_skip_without_config(self):
        with _TempAppDir(with_config=False) as d:
            _ensure_crud_tests(d.path)
            dest = os.path.join(d.path, "tests", "crud_tests.py")  # TEST_CRUD_PATH_V1
            self.assertFalse(os.path.exists(dest))

    def test_content_has_namespace_qualification(self):
        with _TempAppDir() as d:
            _ensure_crud_tests(d.path)
            dest = os.path.join(d.path, "tests", "crud_tests.py")  # TEST_CRUD_PATH_V1
            with open(dest) as f:
                content = f.read()
            # Should contain namespace-aware CRUD URL pattern
            self.assertIn("namespace", content.lower())

    def test_content_is_valid_python(self):
        with _TempAppDir() as d:
            _ensure_crud_tests(d.path)
            dest = os.path.join(d.path, "tests", "crud_tests.py")  # TEST_CRUD_PATH_V1
            with open(dest) as f:
                content = f.read()
            try:
                ast.parse(content)
            except SyntaxError as e:
                self.fail(f"Generated crud_tests.py has syntax error: {e}")


# ===============================================================
# _ensure_e2e_tests tests
# ===============================================================



# ===============================================================
# _ensure_docs_files — CUSTOMIZATION.md tests
# ===============================================================

@unittest.skipUnless(HAS_DOCS and HAS_CUSTOMIZATION, "_ensure_docs_files or CUSTOMIZATION_TEMPLATE not available")
class TestEnsureDocsCustomization(unittest.TestCase):
    """Test that _ensure_docs_files generates CUSTOMIZATION.md."""

    def _make_env(self, app_dir):
        """Create a minimal EnvManager-like object."""
        class FakeEnv:
            def get(self, key, default=""):
                return {
                    "SUPERO_DOMAIN": "testdomain",
                    "SUPERO_PROJECT": "test-project-abc",
                    "SUPERO_DEFAULT_TENANT": "default-tenant",
                    "SUPERO_ADMIN_EMAIL": "admin@test.com",
                    "PORT": "5648",
                    "UI_PORT": "5648",
                }.get(key, default)
        return FakeEnv()

    def test_generates_customization_md(self):
        with _TempAppDir() as d:
            old_cwd = os.getcwd()
            os.chdir(d.path)
            try:
                env = self._make_env(d.path)
                _ensure_docs_files(d.path, env, app_name="Test App")
                cust = os.path.join(d.path, "CUSTOMIZATION.md")
                self.assertTrue(os.path.exists(cust), "CUSTOMIZATION.md should be generated")
            finally:
                os.chdir(old_cwd)

    def test_customization_md_not_empty(self):
        with _TempAppDir() as d:
            old_cwd = os.getcwd()
            os.chdir(d.path)
            try:
                env = self._make_env(d.path)
                _ensure_docs_files(d.path, env, app_name="Test App")
                cust = os.path.join(d.path, "CUSTOMIZATION.md")
                self.assertTrue(os.path.exists(cust), "CUSTOMIZATION.md should exist")
                size = os.path.getsize(cust)
                self.assertGreater(size, 100, "CUSTOMIZATION.md should not be empty")
            finally:
                os.chdir(old_cwd)




    def test_all_five_doc_files_generated(self):
        with _TempAppDir() as d:
            old_cwd = os.getcwd()
            os.chdir(d.path)
            try:
                env = self._make_env(d.path)
                _ensure_docs_files(d.path, env, app_name="Test App")
                for fname in ["README.md", "CLAUDE.md", ".cursorrules",
                               ".windsurfrules", "CUSTOMIZATION.md"]:
                    path = os.path.join(d.path, fname)
                    self.assertTrue(os.path.exists(path), f"{fname} should be generated")
            finally:
                os.chdir(old_cwd)

    def test_readme_has_app_name_and_domain(self):
        with _TempAppDir() as d:
            old_cwd = os.getcwd()
            os.chdir(d.path)
            try:
                env = self._make_env(d.path)
                _ensure_docs_files(d.path, env, app_name="My Cool App")
                readme = os.path.join(d.path, "README.md")
                self.assertTrue(os.path.exists(readme))
                with open(readme) as f:
                    content = f.read()
                self.assertIn("My Cool App", content,
                              "README should contain the app name")
                self.assertIn("testdomain", content,
                              "README should contain the domain")
            finally:
                os.chdir(old_cwd)


# ===============================================================
# make_payload tests (from run.py crud_tests template)
# ===============================================================

class TestMakePayload(unittest.TestCase):
    """Test payload generation by importing from generated crud_tests.py."""

    @classmethod
    def setUpClass(cls):
        """Generate crud_tests.py in a temp dir and import make_payload from it."""
        cls._tmpdir = tempfile.mkdtemp(prefix="supero_payload_test_")
        # Write schemas.py
        with open(os.path.join(cls._tmpdir, "schemas.py"), "w") as f:
            f.write(textwrap.dedent('''\
                SUPERO_APP_NAMESPACE = "testapp"
                ALL_SCHEMAS = [
                    {"name": "Product", "namespace": "testapp", "schema_type": "object",
                     "parent_type": "tenant", "display_name": "Product",
                     "attributes": [
                         {"name": "product_name", "type": "string", "mandatory": True},
                         {"name": "price", "type": "float", "mandatory": True},
                         {"name": "status", "type": "ProductStatus"},
                         {"name": "featured_image", "type": "Image"},
                         {"name": "tags", "type": "string", "list": True},
                         {"name": "is_active", "type": "bool", "default": True},
                         {"name": "stock_count", "type": "integer", "default": 0},
                     ]},
                    {"name": "ProductStatus", "namespace": "testapp", "schema_type": "enum",
                     "type": "string", "values": ["draft", "active", "discontinued"]},
                ]
            '''))
        with open(os.path.join(cls._tmpdir, "config.py"), "w") as f:
            f.write("from dataclasses import dataclass\n@dataclass\nclass AppConfig:\n    app_name: str = 'Test'\n")
        # Generate crud_tests.py
        _ensure_crud_tests(cls._tmpdir)
        crud_path = os.path.join(cls._tmpdir, "tests", "crud_tests.py")  # TEST_CRUD_PATH_V1
        if not os.path.exists(crud_path):
            cls._mod = None
            return
        # Import from generated file
        import importlib.util
        spec = importlib.util.spec_from_file_location("_crud_tests", crud_path)
        cls._mod = importlib.util.module_from_spec(spec)
        try:
            spec.loader.exec_module(cls._mod)
        except Exception:
            cls._mod = None

    @classmethod
    def tearDownClass(cls):
        shutil.rmtree(cls._tmpdir, ignore_errors=True)

    def setUp(self):
        if self._mod is None:
            self.skipTest("Could not import generated crud_tests.py")
        self.make_payload = self._mod.make_payload
        self.build_enum_map = self._mod.build_enum_map
        self.schemas = [
            {"name": "Product", "namespace": "testapp", "schema_type": "object",
             "attributes": [
                 {"name": "product_name", "type": "string", "mandatory": True},
                 {"name": "price", "type": "float", "mandatory": True},
                 {"name": "status", "type": "ProductStatus"},
                 {"name": "featured_image", "type": "Image"},
                 {"name": "is_active", "type": "bool"},
                 {"name": "stock_count", "type": "integer"},
             ]},
            {"name": "ProductStatus", "namespace": "testapp", "schema_type": "enum",
             "type": "string", "values": ["draft", "active", "discontinued"]},
        ]
        self.enum_map = self.build_enum_map(self.schemas)

    def test_has_name_field(self):
        payload = self.make_payload(self.schemas[0], "abc123", "tenant-uuid", self.enum_map)
        self.assertIn("name", payload)
        self.assertIn("abc123", payload["name"])

    def test_has_parent_context(self):
        """Tenant-parented schemas should have parent_type + parent_uuid."""
        payload = self.make_payload(self.schemas[0], "abc123", "tenant-uuid", self.enum_map)
        # make_payload uses parent_type + parent_uuid, not parent_context dict
        self.assertTrue(
            "parent_uuid" in payload or "parent_context" in payload,
            "Tenant-parented schema should have parent reference"
        )

    def test_string_field(self):
        payload = self.make_payload(self.schemas[0], "abc", "t-uuid", self.enum_map)
        self.assertIn("product_name", payload)
        self.assertIsInstance(payload["product_name"], str)

    def test_float_field(self):
        payload = self.make_payload(self.schemas[0], "abc", "t-uuid", self.enum_map)
        self.assertIn("price", payload)
        self.assertIsInstance(payload["price"], (int, float))

    def test_enum_field_uses_valid_value(self):
        payload = self.make_payload(self.schemas[0], "abc", "t-uuid", self.enum_map)
        if "status" in payload:
            self.assertIn(payload["status"], ["draft", "active", "discontinued"])

    def test_image_field(self):
        payload = self.make_payload(self.schemas[0], "abc", "t-uuid", self.enum_map)
        if "featured_image" in payload:
            self.assertIn("http", payload["featured_image"])

    def test_unique_names_per_suffix(self):
        p1 = self.make_payload(self.schemas[0], "aaa", "t-uuid", self.enum_map)
        p2 = self.make_payload(self.schemas[0], "bbb", "t-uuid", self.enum_map)
        self.assertNotEqual(p1["name"], p2["name"])


# ===============================================================
# Version constants
# ===============================================================

class TestVersionConstants(unittest.TestCase):
    """Verify version constants are properly defined."""

    def test_crud_version_is_string(self):
        self.assertIsInstance(CRUD_TESTS_VERSION, str)
        self.assertTrue(len(CRUD_TESTS_VERSION) > 0)

    @unittest.skipUnless(HAS_E2E, "E2E_TESTS_VERSION not available")
    def test_e2e_version_is_string(self):
        self.assertIsInstance(E2E_TESTS_VERSION, str)
        self.assertTrue(len(E2E_TESTS_VERSION) > 0)

    def test_crud_version_is_numeric(self):
        self.assertTrue(CRUD_TESTS_VERSION.isdigit(),
                        "CRUD_TESTS_VERSION should be a numeric string")

    @unittest.skipUnless(HAS_E2E, "E2E_TESTS_VERSION not available")
    def test_e2e_version_is_numeric(self):
        self.assertTrue(E2E_TESTS_VERSION.isdigit(),
                        "E2E_TESTS_VERSION should be a numeric string")


if __name__ == "__main__":
    unittest.main(verbosity=2)
