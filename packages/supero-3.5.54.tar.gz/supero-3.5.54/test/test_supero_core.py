"""
Unit Tests for Supero Core v2.0 - Context-Aware Architecture

CHANGES in v2.0:
- Managers initialized with platform_client (no domain_name parameter)
- Domain context extracted from JWT automatically
- New AggregateManager
- Supero.login() creates PlatformClient with JWT
- All managers support api_key parameter for RBAC
"""

import unittest
import requests
from unittest.mock import Mock, MagicMock, patch
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '../src'))

from supero import Supero, quickstart, connect, SchemaProxy



def create_mock_load_lib_return():
    """Create proper return value for _load_py_api_lib_for_domain mock"""
    from unittest.mock import MagicMock
    return (
        MagicMock,  # ApiLib class
        ['pymodel_system'],  # SCHEMA_NAMESPACES
        'pymodel_system',  # PRIMARY_SCHEMA_NAMESPACE
        None,  # TENANT_NAMESPACE
        'py_api_lib'  # package name
    )


# ============================================================================
# Test Helpers
# ============================================================================

def create_mock_jwt(domain_name="test-domain", domain_uuid="uuid-123"):
    """Create a mock JWT token with domain context"""
    import jwt
    
    payload = {
        "domain_name": domain_name,
        "domain_uuid": domain_uuid,
        "project_uuid": "xxx",
        "project_name": "default-project",
        "tenant_name": "default-tenant",
        "user_uuid": "user-456",
        "email": "test@example.com",
        "exp": 9999999999
    }
    
    return jwt.encode(payload, "secret", algorithm="HS256")


def create_mock_platform_client(domain_name="test-domain", domain_uuid="uuid-123"):
    """Create mock PlatformClient with domain context"""
    mock_client = MagicMock()
    mock_client.domain_name = domain_name
    mock_client.domain_uuid = domain_uuid
    mock_client.base_url = "http://localhost:8083/api/v1"
    return mock_client

def set_project_name(org, value):
    """Set project name on org (via private attribute since property is read-only)"""
    org._project_name = value


def set_tenant_name(org, value):
    """Set tenant name on org (via private attribute since property is read-only)"""
    org._tenant_name = value


# ============================================================================
# Initialization Tests (v2.0)
# ============================================================================

class TestSuperoInit(unittest.TestCase):
    """Test Supero initialization"""
    
    def setUp(self):
        """Setup mocks for domain loading"""
        def mock_load_existing(inst):
            inst._domain_obj = MagicMock()
            inst._domain_obj.uuid = "test-uuid"
            inst._domain_uuid = "test-uuid"
        
        self.mock_load_patcher = patch.object(Supero, "_load_existing_domain", mock_load_existing)
        self.mock_load_patcher.start()
        
        self.mock_ensure_patcher = patch.object(Supero, "_ensure_domain", lambda self: None)
        self.mock_ensure_patcher.start()
    
    def tearDown(self):
        """Stop mocks"""
        self.mock_load_patcher.stop()
        self.mock_ensure_patcher.stop()
    
    """Test Supero initialization"""
    
    @patch('supero.core.PlatformClient')
    def test_init_creates_platform_client(self, mock_client_class):
        """Test initialization creates PlatformClient"""
        mock_client = create_mock_platform_client()
        mock_client_class.return_value = mock_client
        
        with patch('supero.core._load_py_api_lib_for_domain') as mock_load:

        
            mock_load.return_value = create_mock_load_lib_return()
            with patch.object(Supero, '_ensure_domain', lambda self: None):
                def _mock_load(self):
                    self._domain_obj = MagicMock()
                    self._domain_obj.uuid = 'test-uuid'
                    self._domain_uuid = 'test-uuid'
                with patch.object(Supero, '_load_existing_domain', _mock_load):
                    org = Supero(
                        domain_name="test-domain",
                        jwt_token="test-jwt-token"
                    )
                    
                    # Trigger lazy load by accessing a manager
                    _ = org.users
                    
                    # Should create PlatformClient
                    mock_client_class.assert_called()
    
    @patch('supero.core.PlatformClient')
    def test_init_initializes_managers_with_platform_client(self, mock_client_class):
        """Test initialization passes platform_client to managers (v2.0)"""
        mock_client = create_mock_platform_client()
        mock_client_class.return_value = mock_client
        
        with patch('supero.core._load_py_api_lib_for_domain') as mock_load:

        
            mock_load.return_value = create_mock_load_lib_return()
            with patch.object(Supero, '_ensure_domain', lambda self: None):
                def _mock_load(self):
                    self._domain_obj = MagicMock()
                    self._domain_obj.uuid = 'test-uuid'
                    self._domain_uuid = 'test-uuid'
                with patch.object(Supero, '_load_existing_domain', _mock_load):
                    with patch('supero.core.UserManager') as mock_user_mgr:
                        with patch('supero.core.SchemaManager') as mock_schema_mgr:
                            with patch('supero.core.SDKManager') as mock_sdk_mgr:
                                with patch('supero.core.AggregateManager') as mock_agg_mgr:
                                    org = Supero(
                                        domain_name="test-domain",
                                        jwt_token="test-jwt"
                                    )
                                    
                                    # Trigger lazy loads by accessing managers
                                    _ = org.users
                                    _ = org.schemas_manager
                                    _ = org.sdks
                                    _ = org.aggregate
                                    
                                    # NEW in v2.0: NO domain_name parameter!
                                    # Managers should be called with platform_client only
                                    mock_user_mgr.assert_called_with(
                                        platform_client=mock_client,
                                        logger=org.logger
                                    )
                                    
                                    mock_schema_mgr.assert_called_with(
                                        platform_client=mock_client,
                                        logger=org.logger
                                    )
                                    
                                    mock_sdk_mgr.assert_called_with(
                                        platform_client=mock_client,
                                        logger=org.logger
                                    )
                                    
                                    # NEW in v2.0: AggregateManager
                                    mock_agg_mgr.assert_called_with(
                                        platform_client=mock_client,
                                        logger=org.logger
                                    )
    
    @patch('supero.core.PlatformClient')
    def test_init_with_jwt_token(self, mock_client_class):
        """Test initialization with JWT token"""
        jwt_token = create_mock_jwt(domain_name="acme-corp")
        mock_client = create_mock_platform_client(domain_name="acme-corp")
        mock_client_class.return_value = mock_client
        
        with patch('supero.core._load_py_api_lib_for_domain') as mock_load:

        
            mock_load.return_value = create_mock_load_lib_return()
            with patch.object(Supero, '_ensure_domain', lambda self: None):
                def _mock_load(self):
                    self._domain_obj = MagicMock()
                    self._domain_obj.uuid = 'test-uuid'
                    self._domain_uuid = 'test-uuid'
                with patch.object(Supero, '_load_existing_domain', _mock_load):
                    org = Supero(
                        domain_name="acme-corp",
                        jwt_token=jwt_token
                    )
                    
                    # Verify Supero instance has JWT token stored
                    self.assertEqual(org._jwt_token, jwt_token)
                    
                    # Trigger lazy load to ensure PlatformClient is created
                    _ = org.users
                    
                    # Verify PlatformClient was called
                    self.assertTrue(mock_client_class.called)
    
    @patch('supero.core.PlatformClient')
    def test_init_with_api_key(self, mock_client_class):
        """Test initialization with API key (admin mode)"""
        mock_client = create_mock_platform_client()
        mock_client_class.return_value = mock_client
        
        with patch('supero.core._load_py_api_lib_for_domain') as mock_load:

        
            mock_load.return_value = create_mock_load_lib_return()
            with patch.object(Supero, '_ensure_domain', lambda self: None):
                def _mock_load(self):
                    self._domain_obj = MagicMock()
                    self._domain_obj.uuid = 'test-uuid'
                    self._domain_uuid = 'test-uuid'
                with patch.object(Supero, '_load_existing_domain', _mock_load):
                    org = Supero(
                        domain_name="test-domain",
                        api_key="ak_admin_key"
                    )
                    
                    # PlatformClient should be called with api_key
                    # (api_key might be passed differently, adjust as needed)
                    self.assertIsInstance(org, Supero)


# ============================================================================
# Login Tests (v2.0)
# ============================================================================

class TestSuperoLogin(unittest.TestCase):
    """Test Supero.login() class method"""
    
    @patch('supero.core.PlatformClient')
    @patch('requests.post')
    def test_login_creates_platform_client_and_authenticates(self, mock_post, mock_client_class):
        """Test login() creates PlatformClient and authenticates"""
        jwt_token = create_mock_jwt(domain_name="acme-corp")
        mock_client = create_mock_platform_client(domain_name="acme-corp")
        mock_client_class.return_value = mock_client
        
        # Mock HTTP response
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "token": jwt_token
        }
        mock_post.return_value = mock_response
        
        with patch('supero.core._load_py_api_lib_for_domain') as mock_load:

        
            mock_load.return_value = create_mock_load_lib_return()
            with patch.object(Supero, '_ensure_domain', lambda self: None):
                def _mock_load(self):
                    self._domain_obj = MagicMock()
                    self._domain_obj.uuid = 'test-uuid'
                    self._domain_uuid = 'test-uuid'
                with patch.object(Supero, '_load_existing_domain', _mock_load):
                    org = Supero.login(
                        domain_name="acme-corp",
                        email="user@acme.com",
                        password="password123"
                    )
                    
                    # Should return Supero instance
                    self.assertIsInstance(org, Supero)
                    self.assertEqual(org.domain_name, "acme-corp")
                    
                    # Should have called HTTP login endpoint
                    self.assertTrue(mock_post.called)
    
    @patch('supero.core.PlatformClient')
    @patch('requests.post')
    def test_login_with_jwt_sets_token(self, mock_post, mock_client_class):
        """Test login() sets JWT token correctly"""
        jwt_token = create_mock_jwt(domain_name="acme-corp")
        mock_client = create_mock_platform_client(domain_name="acme-corp")
        mock_client_class.return_value = mock_client
        
        # Mock HTTP response
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "token": jwt_token
        }
        mock_post.return_value = mock_response
        
        with patch('supero.core._load_py_api_lib_for_domain') as mock_load:

        
            mock_load.return_value = create_mock_load_lib_return()
            with patch.object(Supero, '_ensure_domain', lambda self: None):
                def _mock_load(self):
                    self._domain_obj = MagicMock()
                    self._domain_obj.uuid = 'test-uuid'
                    self._domain_uuid = 'test-uuid'
                with patch.object(Supero, '_load_existing_domain', _mock_load):
                    org = Supero.login(
                        domain_name="acme-corp",
                        email="user@acme.com",
                        password="password123"
                    )
                    
                    # Should have stored JWT token
                    self.assertEqual(org._jwt_token, jwt_token)


# ============================================================================
# Manager Access Tests (v2.0)
# ============================================================================

class TestSuperoManagerAccess(unittest.TestCase):
    """Test accessing managers from Supero instance"""
    
    @patch('supero.core.PlatformClient')
    def test_has_users_manager(self, mock_client_class):
        """Test Supero has users manager"""
        mock_client = create_mock_platform_client()
        mock_client_class.return_value = mock_client
        
        with patch('supero.core._load_py_api_lib_for_domain') as mock_load:

        
            mock_load.return_value = create_mock_load_lib_return()
            with patch.object(Supero, '_ensure_domain', lambda self: None):
                def _mock_load(self):
                    self._domain_obj = MagicMock()
                    self._domain_obj.uuid = 'test-uuid'
                    self._domain_uuid = 'test-uuid'
                with patch.object(Supero, '_load_existing_domain', _mock_load):
                    org = Supero(domain_name="test-domain")
                    
                    self.assertTrue(hasattr(org, 'users'))
                    self.assertIsNotNone(org.users)
    
    @patch('supero.core.PlatformClient')
    def test_has_schemas_manager(self, mock_client_class):
        """Test Supero has schemas_manager"""
        mock_client = create_mock_platform_client()
        mock_client_class.return_value = mock_client
        
        with patch('supero.core._load_py_api_lib_for_domain') as mock_load:

        
            mock_load.return_value = create_mock_load_lib_return()
            with patch.object(Supero, '_ensure_domain', lambda self: None):
                def _mock_load(self):
                    self._domain_obj = MagicMock()
                    self._domain_obj.uuid = 'test-uuid'
                    self._domain_uuid = 'test-uuid'
                with patch.object(Supero, '_load_existing_domain', _mock_load):
                    org = Supero(domain_name="test-domain")
                    
                    self.assertTrue(hasattr(org, 'schemas_manager'))
                    self.assertIsNotNone(org.schemas_manager)
    
    @patch('supero.core.PlatformClient')
    def test_has_sdks_manager(self, mock_client_class):
        """Test Supero has sdks manager"""
        mock_client = create_mock_platform_client()
        mock_client_class.return_value = mock_client
        
        with patch('supero.core._load_py_api_lib_for_domain') as mock_load:

        
            mock_load.return_value = create_mock_load_lib_return()
            with patch.object(Supero, '_ensure_domain', lambda self: None):
                def _mock_load(self):
                    self._domain_obj = MagicMock()
                    self._domain_obj.uuid = 'test-uuid'
                    self._domain_uuid = 'test-uuid'
                with patch.object(Supero, '_load_existing_domain', _mock_load):
                    org = Supero(domain_name="test-domain")
                    
                    self.assertTrue(hasattr(org, 'sdks'))
                    self.assertIsNotNone(org.sdks)
    
    @patch('supero.core.PlatformClient')
    def test_has_aggregate_manager(self, mock_client_class):
        """Test Supero has aggregate manager (NEW in v2.0)"""
        mock_client = create_mock_platform_client()
        mock_client_class.return_value = mock_client
        
        with patch('supero.core._load_py_api_lib_for_domain') as mock_load:

        
            mock_load.return_value = create_mock_load_lib_return()
            with patch.object(Supero, '_ensure_domain', lambda self: None):
                def _mock_load(self):
                    self._domain_obj = MagicMock()
                    self._domain_obj.uuid = 'test-uuid'
                    self._domain_uuid = 'test-uuid'
                with patch.object(Supero, '_load_existing_domain', _mock_load):
                    org = Supero(domain_name="test-domain")
                    
                    # NEW in v2.0: AggregateManager
                    self.assertTrue(hasattr(org, 'aggregate'))
                    self.assertIsNotNone(org.aggregate)


# ============================================================================
# Schema Access Tests
# ============================================================================

class TestSuperoSchemaAccess(unittest.TestCase):
    """Test schema access patterns"""
    
    @patch('supero.core.PlatformClient')
    def test_direct_schema_access(self, mock_client_class):
        """Test direct schema access via org.SchemaName"""
        mock_client = create_mock_platform_client()
        mock_client_class.return_value = mock_client
        
        with patch('supero.core._load_py_api_lib_for_domain') as mock_load:

        
            mock_load.return_value = create_mock_load_lib_return()
            with patch.object(Supero, '_ensure_domain', lambda self: None):
                def _mock_load(self):
                    self._domain_obj = MagicMock()
                    self._domain_obj.uuid = 'test-uuid'
                    self._domain_uuid = 'test-uuid'
                with patch.object(Supero, '_load_existing_domain', _mock_load):
                    with patch.object(Supero, '_list_schemas', return_value=['Project', 'User']):
                        org = Supero(domain_name="test-domain")
                        
                        # Direct access should work
                        project_proxy = org.Project
                        
                        self.assertIsNotNone(project_proxy)
    
    @patch('supero.core.PlatformClient')
    def test_schema_registry_access(self, mock_client_class):
        """Test schema access via org.schemas.SchemaName"""
        mock_client = create_mock_platform_client()
        mock_client_class.return_value = mock_client
        
        with patch('supero.core._load_py_api_lib_for_domain') as mock_load:

        
            mock_load.return_value = create_mock_load_lib_return()
            with patch.object(Supero, '_ensure_domain', lambda self: None):
                def _mock_load(self):
                    self._domain_obj = MagicMock()
                    self._domain_obj.uuid = 'test-uuid'
                    self._domain_uuid = 'test-uuid'
                with patch.object(Supero, '_load_existing_domain', _mock_load):
                    with patch.object(Supero, '_list_schemas', return_value=['Project', 'User']):
                        org = Supero(domain_name="test-domain")
                        
                        # Registry access should work
                        project_proxy = org.schemas.Project
                        
                        self.assertIsNotNone(project_proxy)
    
    @patch('supero.core.PlatformClient')
    def test_get_schema_method(self, mock_client_class):
        """Test get_schema() method"""
        mock_client = create_mock_platform_client()
        mock_client_class.return_value = mock_client
        
        with patch('supero.core._load_py_api_lib_for_domain') as mock_load:

        
            mock_load.return_value = create_mock_load_lib_return()
            with patch.object(Supero, '_ensure_domain', lambda self: None):
                def _mock_load(self):
                    self._domain_obj = MagicMock()
                    self._domain_obj.uuid = 'test-uuid'
                    self._domain_uuid = 'test-uuid'
                with patch.object(Supero, '_load_existing_domain', _mock_load):
                    org = Supero(domain_name="test-domain")
                    
                    # get_schema should work
                    try:
                        schema_class = org.get_schema("Project")
                        self.assertIsNotNone(schema_class)
                    except:
                        # May fail if schema doesn't exist, acceptable
                        pass


# ============================================================================
# Quickstart Tests (v2.0)
# ============================================================================

class TestQuickstart(unittest.TestCase):
    """Test quickstart() convenience function"""
    
    @patch('supero.core.PlatformClient')
    def test_quickstart_returns_supero(self, mock_client_class):
        """Test quickstart returns Supero instance"""
        mock_client = create_mock_platform_client()
        mock_client_class.return_value = mock_client
        
        with patch('supero.core._load_py_api_lib_for_domain') as mock_load:

        
            mock_load.return_value = create_mock_load_lib_return()
            with patch.object(Supero, '_ensure_domain', lambda self: None):
                def _mock_load(self):
                    self._domain_obj = MagicMock()
                    self._domain_obj.uuid = 'test-uuid'
                    self._domain_uuid = 'test-uuid'
                with patch.object(Supero, '_load_existing_domain', _mock_load):
                    org = quickstart("test-domain")
                    
                    self.assertIsInstance(org, Supero)
                    self.assertEqual(org.domain_name, "test-domain")
    
    @patch('supero.core.PlatformClient')
    def test_quickstart_with_jwt_token(self, mock_client_class):
        """Test quickstart with JWT token"""
        jwt_token = create_mock_jwt()
        mock_client = create_mock_platform_client()
        mock_client_class.return_value = mock_client
        
        with patch('supero.core._load_py_api_lib_for_domain') as mock_load:

        
            mock_load.return_value = create_mock_load_lib_return()
            with patch.object(Supero, '_ensure_domain', lambda self: None):
                def _mock_load(self):
                    self._domain_obj = MagicMock()
                    self._domain_obj.uuid = 'test-uuid'
                    self._domain_uuid = 'test-uuid'
                with patch.object(Supero, '_load_existing_domain', _mock_load):
                    org = quickstart("test-domain", jwt_token=jwt_token)
                    
                    self.assertIsInstance(org, Supero)
    
    @patch('supero.core.PlatformClient')
    def test_quickstart_with_api_key(self, mock_client_class):
        """Test quickstart with API key"""
        mock_client = create_mock_platform_client()
        mock_client_class.return_value = mock_client
        
        with patch('supero.core._load_py_api_lib_for_domain') as mock_load:

        
            mock_load.return_value = create_mock_load_lib_return()
            with patch.object(Supero, '_ensure_domain', lambda self: None):
                def _mock_load(self):
                    self._domain_obj = MagicMock()
                    self._domain_obj.uuid = 'test-uuid'
                    self._domain_uuid = 'test-uuid'
                with patch.object(Supero, '_load_existing_domain', _mock_load):
                    org = quickstart("test-domain", api_key="ak_admin")
                    
                    self.assertIsInstance(org, Supero)


# ============================================================================
# Connect Tests (v2.0)
# ============================================================================

class TestConnect(unittest.TestCase):
    """Test connect() convenience function"""
    
    @patch('supero.core.PlatformClient')
    def test_connect_returns_supero(self, mock_client_class):
        """Test connect returns Supero instance"""
        mock_client = create_mock_platform_client()
        mock_client_class.return_value = mock_client
        
        with patch('supero.core._load_py_api_lib_for_domain') as mock_load:

        
            mock_load.return_value = create_mock_load_lib_return()
            with patch.object(Supero, '_ensure_domain', lambda self: None):
                def _mock_load(self):
                    self._domain_obj = MagicMock()
                    self._domain_obj.uuid = 'test-uuid'
                    self._domain_uuid = 'test-uuid'
                with patch.object(Supero, '_load_existing_domain', _mock_load):
                    org = connect("test-domain")
                    
                    self.assertIsInstance(org, Supero)
    
    @patch('supero.core.PlatformClient')
    def test_connect_with_api_key(self, mock_client_class):
        """Test connect with API key"""
        mock_client = create_mock_platform_client()
        mock_client_class.return_value = mock_client
        
        with patch('supero.core._load_py_api_lib_for_domain') as mock_load:

        
            mock_load.return_value = create_mock_load_lib_return()
            with patch.object(Supero, '_ensure_domain', lambda self: None):
                def _mock_load(self):
                    self._domain_obj = MagicMock()
                    self._domain_obj.uuid = 'test-uuid'
                    self._domain_uuid = 'test-uuid'
                with patch.object(Supero, '_load_existing_domain', _mock_load):
                    org = connect("test-domain", api_key="ak_test")
                    
                    self.assertIsInstance(org, Supero)


# ============================================================================
# Namespace Detection Tests
# ============================================================================

class TestNamespaceDetection(unittest.TestCase):
    """Test namespace auto-detection"""
    
    def test_namespace_for_system_domains(self):
        """Test that all system domains get pymodel_system"""
        system_domains = ['default-domain', 'platform', 'system', 'admin']
        
        for domain in system_domains:
            namespace = Supero._auto_detect_namespace(domain)
            self.assertEqual(
                namespace,
                'pymodel_system',
                f"Failed for system domain: {domain}"
            )
    
    def test_namespace_for_tenant_domains(self):
        """Test that tenant domains get appropriate namespace"""
        tenant_domains = ['acme-corp', 'my-company', 'test-tenant']
        
        for domain in tenant_domains:
            namespace = Supero._auto_detect_namespace(domain)
            # Should return pymodel_system in platform mode
            self.assertEqual(
                namespace,
                'pymodel_system',
                f"Failed for tenant domain: {domain}"
            )


# ============================================================================
# Integration Tests (v2.0)
# ============================================================================

class TestSuperoIntegration(unittest.TestCase):
    """Integration tests for Supero"""
    
    @patch('supero.core.PlatformClient')
    @patch('requests.post')
    def test_complete_workflow(self, mock_post, mock_client_class):
        """Test complete Supero workflow"""
        jwt_token = create_mock_jwt(domain_name="acme-corp")
        mock_client = create_mock_platform_client(domain_name="acme-corp")
        mock_client_class.return_value = mock_client
        
        # Mock HTTP response
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "token": jwt_token
        }
        mock_post.return_value = mock_response
        
        with patch('supero.core._load_py_api_lib_for_domain') as mock_load:

        
            mock_load.return_value = create_mock_load_lib_return()
            with patch.object(Supero, '_ensure_domain', lambda self: None):
                def _mock_load(self):
                    self._domain_obj = MagicMock()
                    self._domain_obj.uuid = 'test-uuid'
                    self._domain_uuid = 'test-uuid'
                with patch.object(Supero, '_load_existing_domain', _mock_load):
                    # Login
                    org = Supero.login(
                        domain_name="acme-corp",
                        email="user@acme.com",
                        password="password"
                    )
                    
                    # Should have all managers
                    self.assertIsNotNone(org.users)
                    self.assertIsNotNone(org.schemas_manager)
                    self.assertIsNotNone(org.sdks)
                    self.assertIsNotNone(org.aggregate)  # NEW!
                    
                    # Should have schema access
                    self.assertIsNotNone(org.schemas)

# ============================================================================
# Login with Project/Tenant Tests (v2.1)
# ============================================================================

class TestSuperoLoginWithProjectTenant(unittest.TestCase):
    """Test Supero.login() with project and tenant parameters"""

    def setUp(self):
        """Setup common mocks"""
        from supero import Supero
        self.Supero = Supero

    @patch('supero.core.PlatformClient')
    @patch('requests.post')
    def test_login_with_default_project_tenant(self, mock_post, mock_client_class):
        """Test login() uses default-project and default-tenant when not specified"""
        jwt_token = create_mock_jwt(domain_name="acme-corp")
        mock_client = create_mock_platform_client(domain_name="acme-corp")
        mock_client_class.return_value = mock_client

        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"token": jwt_token}
        mock_post.return_value = mock_response

        with patch('supero.core._load_py_api_lib_for_domain') as mock_load:
            mock_load.return_value = create_mock_load_lib_return()
            with patch.object(self.Supero, '_ensure_domain', lambda self: None):
                def _mock_load(self):
                    self._domain_obj = MagicMock()
                    self._domain_obj.uuid = 'test-uuid'
                    self._domain_uuid = 'test-uuid'
                with patch.object(self.Supero, '_load_existing_domain', _mock_load):
                    org = self.Supero.login(
                        domain_name="acme-corp",
                        email="user@acme.com",
                        password="password123"
                    )

                    # Verify defaults are used
                    self.assertEqual(org.project_name, "default-project")
                    self.assertEqual(org.tenant_name, "default-tenant")

    @patch('supero.core.PlatformClient')
    @patch('requests.post')
    def test_login_with_custom_project(self, mock_post, mock_client_class):
        """Test login() with custom project (single-tenant)"""
        jwt_token = create_mock_jwt(domain_name="acme-corp")
        mock_client = create_mock_platform_client(domain_name="acme-corp")
        mock_client_class.return_value = mock_client

        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"token": jwt_token}
        mock_post.return_value = mock_response

        with patch('supero.core._load_py_api_lib_for_domain') as mock_load:
            mock_load.return_value = create_mock_load_lib_return()
            with patch.object(self.Supero, '_ensure_domain', lambda self: None):
                def _mock_load(self):
                    self._domain_obj = MagicMock()
                    self._domain_obj.uuid = 'test-uuid'
                    self._domain_uuid = 'test-uuid'
                with patch.object(self.Supero, '_load_existing_domain', _mock_load):
                    org = self.Supero.login(
                        domain_name="acme-corp",
                        email="user@acme.com",
                        password="password123",
                        project="ecommerce"
                    )

                    # Verify custom project is used
                    self.assertEqual(org.project_name, "ecommerce")
                    # Tenant should still be default
                    self.assertEqual(org.tenant_name, "default-tenant")

    @patch('supero.core.PlatformClient')
    @patch('requests.post')
    def test_login_with_custom_project_and_tenant(self, mock_post, mock_client_class):
        """Test login() with custom project and tenant (multi-tenant)"""
        jwt_token = create_mock_jwt(domain_name="acme-corp")
        mock_client = create_mock_platform_client(domain_name="acme-corp")
        mock_client_class.return_value = mock_client

        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"token": jwt_token}
        mock_post.return_value = mock_response

        with patch('supero.core._load_py_api_lib_for_domain') as mock_load:
            mock_load.return_value = create_mock_load_lib_return()
            with patch.object(self.Supero, '_ensure_domain', lambda self: None):
                def _mock_load(self):
                    self._domain_obj = MagicMock()
                    self._domain_obj.uuid = 'test-uuid'
                    self._domain_uuid = 'test-uuid'
                with patch.object(self.Supero, '_load_existing_domain', _mock_load):
                    org = self.Supero.login(
                        domain_name="acme-corp",
                        email="user@acme.com",
                        password="password123",
                        project="hr-system",
                        tenant="sales"
                    )

                    # Verify both are set
                    self.assertEqual(org.project_name, "hr-system")
                    self.assertEqual(org.tenant_name, "sales")

    @patch('supero.core.PlatformClient')
    @patch('requests.post')
    def test_login_sends_project_tenant_in_request(self, mock_post, mock_client_class):
        """Test login() sends project and tenant in HTTP request body"""
        jwt_token = create_mock_jwt(domain_name="acme-corp")
        mock_client = create_mock_platform_client(domain_name="acme-corp")
        mock_client_class.return_value = mock_client

        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"token": jwt_token}
        mock_post.return_value = mock_response

        with patch('supero.core._load_py_api_lib_for_domain') as mock_load:
            mock_load.return_value = create_mock_load_lib_return()
            with patch.object(self.Supero, '_ensure_domain', lambda self: None):
                def _mock_load(self):
                    self._domain_obj = MagicMock()
                    self._domain_obj.uuid = 'test-uuid'
                    self._domain_uuid = 'test-uuid'
                with patch.object(self.Supero, '_load_existing_domain', _mock_load):
                    self.Supero.login(
                        domain_name="acme-corp",
                        email="user@acme.com",
                        password="password123",
                        project="hr-system",
                        tenant="sales"
                    )

                    # Verify HTTP request was made with project/tenant
                    self.assertTrue(mock_post.called)
                    call_args = mock_post.call_args

                    # Check request body contains project and tenant
                    # Handle both positional and keyword json argument
                    request_body = call_args.kwargs.get('json')
                    if request_body is None and len(call_args.args) > 1:
                        request_body = call_args.args[1]

                    self.assertIsNotNone(request_body, "Expected JSON body in request")
                    self.assertEqual(request_body.get('project'), 'hr-system')
                    self.assertEqual(request_body.get('tenant'), 'sales')

# ============================================================================
# Login with Project/Tenant Tests (v2.1)
# ============================================================================

class TestSuperoLoginWithProjectTenant(unittest.TestCase):
    """Test Supero.login() with project and tenant parameters"""

    def setUp(self):
        """Setup common mocks"""
        from supero import Supero
        self.Supero = Supero

    @patch('supero.core.PlatformClient')
    @patch('requests.post')
    def test_login_with_default_project_tenant(self, mock_post, mock_client_class):
        """Test login() uses default-project and default-tenant when not specified"""
        jwt_token = create_mock_jwt(domain_name="acme-corp")
        mock_client = create_mock_platform_client(domain_name="acme-corp")
        mock_client_class.return_value = mock_client

        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"token": jwt_token}
        mock_post.return_value = mock_response

        with patch('supero.core._load_py_api_lib_for_domain') as mock_load:
            mock_load.return_value = create_mock_load_lib_return()
            with patch.object(self.Supero, '_ensure_domain', lambda self: None):
                def _mock_load(self):
                    self._domain_obj = MagicMock()
                    self._domain_obj.uuid = 'test-uuid'
                    self._domain_uuid = 'test-uuid'
                with patch.object(self.Supero, '_load_existing_domain', _mock_load):
                    org = self.Supero.login(
                        domain_name="acme-corp",
                        email="user@acme.com",
                        password="password123"
                    )

                    # Verify defaults are used
                    self.assertEqual(org.project_name, "default-project")
                    self.assertEqual(org.tenant_name, "default-tenant")

    @patch('supero.core.PlatformClient')
    @patch('requests.post')
    def test_login_with_custom_project(self, mock_post, mock_client_class):
        """Test login() with custom project (single-tenant)"""
        jwt_token = create_mock_jwt(domain_name="acme-corp")
        mock_client = create_mock_platform_client(domain_name="acme-corp")
        mock_client_class.return_value = mock_client

        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"token": jwt_token}
        mock_post.return_value = mock_response

        with patch('supero.core._load_py_api_lib_for_domain') as mock_load:
            mock_load.return_value = create_mock_load_lib_return()
            with patch.object(self.Supero, '_ensure_domain', lambda self: None):
                def _mock_load(self):
                    self._domain_obj = MagicMock()
                    self._domain_obj.uuid = 'test-uuid'
                    self._domain_uuid = 'test-uuid'
                with patch.object(self.Supero, '_load_existing_domain', _mock_load):
                    org = self.Supero.login(
                        domain_name="acme-corp",
                        email="user@acme.com",
                        password="password123",
                        project="ecommerce"
                    )

                    # Verify custom project is used
                    self.assertEqual(org.project_name, "ecommerce")
                    # Tenant should still be default
                    self.assertEqual(org.tenant_name, "default-tenant")

    @patch('supero.core.PlatformClient')
    @patch('requests.post')
    def test_login_with_custom_project_and_tenant(self, mock_post, mock_client_class):
        """Test login() with custom project and tenant (multi-tenant)"""
        jwt_token = create_mock_jwt(domain_name="acme-corp")
        mock_client = create_mock_platform_client(domain_name="acme-corp")
        mock_client_class.return_value = mock_client

        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"token": jwt_token}
        mock_post.return_value = mock_response

        with patch('supero.core._load_py_api_lib_for_domain') as mock_load:
            mock_load.return_value = create_mock_load_lib_return()
            with patch.object(self.Supero, '_ensure_domain', lambda self: None):
                def _mock_load(self):
                    self._domain_obj = MagicMock()
                    self._domain_obj.uuid = 'test-uuid'
                    self._domain_uuid = 'test-uuid'
                with patch.object(self.Supero, '_load_existing_domain', _mock_load):
                    org = self.Supero.login(
                        domain_name="acme-corp",
                        email="user@acme.com",
                        password="password123",
                        project="hr-system",
                        tenant="sales"
                    )

                    # Verify both are set
                    self.assertEqual(org.project_name, "hr-system")
                    self.assertEqual(org.tenant_name, "sales")

    @patch('supero.core.PlatformClient')
    @patch('requests.post')
    def test_login_sends_project_tenant_in_request(self, mock_post, mock_client_class):
        """Test login() sends project and tenant in HTTP request body"""
        jwt_token = create_mock_jwt(domain_name="acme-corp")
        mock_client = create_mock_platform_client(domain_name="acme-corp")
        mock_client_class.return_value = mock_client

        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"token": jwt_token}
        mock_post.return_value = mock_response

        with patch('supero.core._load_py_api_lib_for_domain') as mock_load:
            mock_load.return_value = create_mock_load_lib_return()
            with patch.object(self.Supero, '_ensure_domain', lambda self: None):
                def _mock_load(self):
                    self._domain_obj = MagicMock()
                    self._domain_obj.uuid = 'test-uuid'
                    self._domain_uuid = 'test-uuid'
                with patch.object(self.Supero, '_load_existing_domain', _mock_load):
                    self.Supero.login(
                        domain_name="acme-corp",
                        email="user@acme.com",
                        password="password123",
                        project="hr-system",
                        tenant="sales"
                    )

                    # Verify HTTP request was made with project/tenant
                    self.assertTrue(mock_post.called)
                    call_args = mock_post.call_args

                    # Check request body contains project and tenant
                    # Handle both positional and keyword json argument
                    request_body = call_args.kwargs.get('json')
                    if request_body is None and len(call_args.args) > 1:
                        request_body = call_args.args[1]

                    self.assertIsNotNone(request_body, "Expected JSON body in request")
                    self.assertEqual(request_body.get('project'), 'hr-system')
                    self.assertEqual(request_body.get('tenant'), 'sales')


# ============================================================================
# Switch Project Tests (v2.1)
# ============================================================================

class TestSwitchProject(unittest.TestCase):
    """Test Supero.switch_project() and use_project() methods"""

    def setUp(self):
        """Setup common mocks"""
        from supero import Supero
        self.Supero = Supero

        self.mock_client_patcher = patch('supero.core.PlatformClient')
        self.mock_client_class = self.mock_client_patcher.start()
        self.mock_client = create_mock_platform_client()
        self.mock_client_class.return_value = self.mock_client

        self.mock_load_patcher = patch('supero.core._load_py_api_lib_for_domain')
        self.mock_load = self.mock_load_patcher.start()
        self.mock_load.return_value = create_mock_load_lib_return()

        self.mock_ensure_patcher = patch.object(self.Supero, '_ensure_domain', lambda self: None)
        self.mock_ensure_patcher.start()

        def _mock_load_domain(self):
            self._domain_obj = MagicMock()
            self._domain_obj.uuid = 'test-uuid'
            self._domain_uuid = 'test-uuid'

        self.mock_load_domain_patcher = patch.object(self.Supero, '_load_existing_domain', _mock_load_domain)
        self.mock_load_domain_patcher.start()

    def tearDown(self):
        """Stop mocks"""
        self.mock_client_patcher.stop()
        self.mock_load_patcher.stop()
        self.mock_ensure_patcher.stop()
        self.mock_load_domain_patcher.stop()

    def _create_switch_response(self, project="ecommerce", tenant="default-tenant"):
        """Create mock switch_project API response"""
        return {
            "success": True,
            "auth": {
                "access_token": "new-access-token-xyz",
                "refresh_token": "new-refresh-token-xyz",
                "expires_in": 28800
            },
            "context": {
                "domain": "acme-corp",
                "domain_uuid": "domain-uuid-123",
                "project": project,
                "project_uuid": f"{project}-uuid-456",
                "tenant": tenant,
                "tenant_uuid": f"{tenant}-uuid-789"
            }
        }

    def test_switch_project_with_project_name_positional(self):
        """Test switch_project() with project_name as positional arg"""
        org = self.Supero(domain_name="acme-corp", jwt_token="initial-token")

        # Use _platform_client (not _api_client)
        org._platform_client = self.mock_client

        # PlatformClient.post() returns dict directly
        self.mock_client.post.return_value = self._create_switch_response(project="ecommerce")

        # Switch project
        result = org.switch_project("ecommerce")

        # Verify returns self
        self.assertIs(result, org)

        # Verify API was called correctly
        self.mock_client.post.assert_called_once()
        call_args = self.mock_client.post.call_args
        self.assertIn("/auth/switch-project", call_args.args[0])

        # Verify request body
        request_body = call_args.kwargs.get('json')
        self.assertEqual(request_body.get('project_name'), 'ecommerce')

    def test_switch_project_with_project_name_keyword(self):
        """Test switch_project() with project_name as keyword argument"""
        org = self.Supero(domain_name="acme-corp", jwt_token="initial-token")
        org._platform_client = self.mock_client

        self.mock_client.post.return_value = self._create_switch_response(project="hr-system")

        result = org.switch_project(project_name="hr-system")

        self.assertIs(result, org)
        call_args = self.mock_client.post.call_args
        request_body = call_args.kwargs.get('json')
        self.assertEqual(request_body.get('project_name'), 'hr-system')

    def test_switch_project_with_project_uuid(self):
        """Test switch_project() with project_uuid"""
        org = self.Supero(domain_name="acme-corp", jwt_token="initial-token")
        org._platform_client = self.mock_client

        self.mock_client.post.return_value = self._create_switch_response()

        org.switch_project(project_uuid="proj-uuid-123")

        call_args = self.mock_client.post.call_args
        request_body = call_args.kwargs.get('json')
        self.assertEqual(request_body.get('project_uuid'), 'proj-uuid-123')

    def test_switch_project_with_tenant_name(self):
        """Test switch_project() with project and tenant_name"""
        org = self.Supero(domain_name="acme-corp", jwt_token="initial-token")
        org._platform_client = self.mock_client

        self.mock_client.post.return_value = self._create_switch_response(
            project="hr-system",
            tenant="sales"
        )

        org.switch_project("hr-system", tenant_name="sales")

        call_args = self.mock_client.post.call_args
        request_body = call_args.kwargs.get('json')
        self.assertEqual(request_body.get('project_name'), 'hr-system')
        self.assertEqual(request_body.get('tenant_name'), 'sales')

    def test_switch_project_with_tenant_uuid(self):
        """Test switch_project() with tenant_uuid"""
        org = self.Supero(domain_name="acme-corp", jwt_token="initial-token")
        org._platform_client = self.mock_client

        self.mock_client.post.return_value = self._create_switch_response()

        org.switch_project(project_uuid="proj-123", tenant_uuid="tenant-456")

        call_args = self.mock_client.post.call_args
        request_body = call_args.kwargs.get('json')
        self.assertEqual(request_body.get('project_uuid'), 'proj-123')
        self.assertEqual(request_body.get('tenant_uuid'), 'tenant-456')

    def test_switch_project_updates_access_token(self):
        """Test switch_project() updates access token from response"""
        org = self.Supero(domain_name="acme-corp", jwt_token="old-token")
        org._platform_client = self.mock_client

        self.mock_client.post.return_value = self._create_switch_response()

        org.switch_project("ecommerce")

        # Verify token was updated
        self.assertEqual(org._jwt_token, "new-access-token-xyz")

    def test_switch_project_updates_refresh_token(self):
        """Test switch_project() updates refresh token from response"""
        org = self.Supero(domain_name="acme-corp", jwt_token="old-token")
        org._platform_client = self.mock_client
        org._refresh_token = "old-refresh-token"

        self.mock_client.post.return_value = self._create_switch_response()

        org.switch_project("ecommerce")

        self.assertEqual(org._refresh_token, "new-refresh-token-xyz")

    def test_switch_project_updates_expires_in(self):
        """Test switch_project() updates token expiry from response"""
        org = self.Supero(domain_name="acme-corp", jwt_token="token")
        org._platform_client = self.mock_client

        self.mock_client.post.return_value = self._create_switch_response()

        org.switch_project("ecommerce")

        self.assertEqual(org._token_expires_in, 28800)

    def test_switch_project_updates_project_context(self):
        """Test switch_project() updates project context from response"""
        org = self.Supero(domain_name="acme-corp", jwt_token="token")
        org._platform_client = self.mock_client
        org._project_name = "old-project"
        org._project_uuid = "old-uuid"

        self.mock_client.post.return_value = self._create_switch_response(project="new-project")

        org.switch_project("new-project")

        self.assertEqual(org.project_name, "new-project")
        self.assertEqual(org.project_uuid, "new-project-uuid-456")

    def test_switch_project_updates_tenant_context(self):
        """Test switch_project() updates tenant context from response"""
        org = self.Supero(domain_name="acme-corp", jwt_token="token")
        org._platform_client = self.mock_client
        org._tenant_name = "old-tenant"
        org._tenant_uuid = "old-uuid"

        self.mock_client.post.return_value = self._create_switch_response(
            project="proj",
            tenant="new-tenant"
        )

        org.switch_project("proj", tenant_name="new-tenant")

        self.assertEqual(org.tenant_name, "new-tenant")
        self.assertEqual(org.tenant_uuid, "new-tenant-uuid-789")

    def test_switch_project_updates_domain_context(self):
        """Test switch_project() updates domain context from response"""
        org = self.Supero(domain_name="acme-corp", jwt_token="token")
        org._platform_client = self.mock_client

        self.mock_client.post.return_value = self._create_switch_response()

        org.switch_project("ecommerce")

        # domain_name is a public property on Supero
        self.assertEqual(org.domain_name, "acme-corp")
        self.assertEqual(org.domain_uuid, "domain-uuid-123")

    def test_switch_project_raises_on_missing_args(self):
        """Test switch_project() raises ValueError when no project specified"""
        org = self.Supero(domain_name="acme-corp", jwt_token="token")

        with self.assertRaises(ValueError) as context:
            org.switch_project()

        self.assertIn("project", str(context.exception).lower())

    def test_switch_project_raises_on_http_error(self):
        """Test switch_project() raises on HTTP error"""
        org = self.Supero(domain_name="acme-corp", jwt_token="token")
        org._platform_client = self.mock_client

        # PlatformClient raises exception on HTTP errors
        self.mock_client.post.side_effect = Exception("HTTP 404: Project not found")

        with self.assertRaises(Exception) as context:
            org.switch_project("nonexistent-project")

        self.assertIn("failed", str(context.exception).lower())

    def test_switch_project_raises_on_success_false(self):
        """Test switch_project() raises when response success=false"""
        org = self.Supero(domain_name="acme-corp", jwt_token="token")
        org._platform_client = self.mock_client

        self.mock_client.post.return_value = {"success": False}

        with self.assertRaises(Exception) as context:
            org.switch_project("some-project")

        self.assertIn("failed", str(context.exception).lower())

    def test_switch_project_calls_set_jwt_token_on_client(self):
        """Test switch_project() calls set_jwt_token on platform_client"""
        org = self.Supero(domain_name="acme-corp", jwt_token="initial-token")
        org._platform_client = self.mock_client

        self.mock_client.post.return_value = self._create_switch_response()

        org.switch_project("ecommerce")

        # Verify set_jwt_token was called with new token
        self.mock_client.set_jwt_token.assert_called_with("new-access-token-xyz")

    def test_use_project_is_alias_for_switch_project(self):
        """Test use_project() is an alias for switch_project()"""
        org = self.Supero(domain_name="acme-corp", jwt_token="token")

        # Verify use_project exists and points to switch_project
        self.assertTrue(hasattr(org, 'use_project'))
        self.assertEqual(org.use_project, org.switch_project)

    def test_use_project_works_same_as_switch_project(self):
        """Test use_project() works identically to switch_project()"""
        org = self.Supero(domain_name="acme-corp", jwt_token="initial-token")
        org._platform_client = self.mock_client

        self.mock_client.post.return_value = self._create_switch_response(project="myapp")

        # Use the alias
        result = org.use_project("myapp")

        self.assertIs(result, org)
        self.assertEqual(org.project_name, "myapp")

    def test_switch_project_default_tenant_when_not_specified(self):
        """Test switch_project() uses default-tenant from response when not specified"""
        org = self.Supero(domain_name="acme-corp", jwt_token="token")
        org._platform_client = self.mock_client

        self.mock_client.post.return_value = self._create_switch_response(
            project="ecommerce",
            tenant="default-tenant"  # Backend returns default
        )

        org.switch_project("ecommerce")  # No tenant specified

        self.assertEqual(org.tenant_name, "default-tenant")

    def test_switch_project_with_both_name_and_uuid(self):
        """Test switch_project() with both project_name and project_uuid sends both"""
        org = self.Supero(domain_name="acme-corp", jwt_token="token")
        org._platform_client = self.mock_client

        self.mock_client.post.return_value = self._create_switch_response()

        # Pass both name and uuid
        org.switch_project("ecommerce", project_uuid="proj-uuid-123")

        call_args = self.mock_client.post.call_args
        request_body = call_args.kwargs.get('json')
        # Both should be in body
        self.assertEqual(request_body.get('project_name'), 'ecommerce')
        self.assertEqual(request_body.get('project_uuid'), 'proj-uuid-123')

    def test_switch_project_handles_partial_response(self):
        """Test switch_project() gracefully handles response with missing optional fields"""
        org = self.Supero(domain_name="acme-corp", jwt_token="old-token")
        org._platform_client = self.mock_client
        org._refresh_token = "old-refresh"

        # Response with minimal fields (no refresh_token, no expires_in)
        self.mock_client.post.return_value = {
            "success": True,
            "auth": {
                "access_token": "new-token"
                # No refresh_token, no expires_in
            },
            "context": {
                "project": "ecommerce",
                "project_uuid": "proj-123"
                # No tenant info
            }
        }

        # Should not raise
        result = org.switch_project("ecommerce")

        self.assertIs(result, org)
        self.assertEqual(org._jwt_token, "new-token")
        self.assertEqual(org.project_name, "ecommerce")


# ============================================================================
# Quickstart with Project/Tenant Tests (v2.1)
# ============================================================================
class TestQuickstartWithProjectTenant(unittest.TestCase):
    """Test quickstart() with project and tenant parameters"""

    def setUp(self):
        """Setup common mocks"""
        from supero import Supero
        self.Supero = Supero

    @patch('supero.core.PlatformClient')
    def test_quickstart_with_default_project(self, mock_client_class):
        """Test quickstart() uses default-project when not specified"""
        mock_client = create_mock_platform_client()
        mock_client_class.return_value = mock_client

        with patch('supero.core._load_py_api_lib_for_domain') as mock_load:
            mock_load.return_value = create_mock_load_lib_return()
            with patch.object(self.Supero, '_ensure_domain', lambda self: None):
                def _mock_load(self):
                    self._domain_obj = MagicMock()
                    self._domain_obj.uuid = 'test-uuid'
                    self._domain_uuid = 'test-uuid'
                with patch.object(self.Supero, '_load_existing_domain', _mock_load):
                    org = self.Supero.quickstart("acme-corp", jwt_token="token")

                    self.assertEqual(org.project_name, "default-project")

    @patch('supero.core.PlatformClient')
    def test_quickstart_with_custom_project_positional(self, mock_client_class):
        """Test quickstart() with custom project as positional arg"""
        mock_client = create_mock_platform_client()
        mock_client_class.return_value = mock_client

        with patch('supero.core._load_py_api_lib_for_domain') as mock_load:
            mock_load.return_value = create_mock_load_lib_return()
            with patch.object(self.Supero, '_ensure_domain', lambda self: None):
                def _mock_load(self):
                    self._domain_obj = MagicMock()
                    self._domain_obj.uuid = 'test-uuid'
                    self._domain_uuid = 'test-uuid'
                with patch.object(self.Supero, '_load_existing_domain', _mock_load):
                    org = self.Supero.quickstart("acme-corp", project="ecommerce", jwt_token="token")

                    self.assertEqual(org.project_name, "ecommerce")

    @patch('supero.core.PlatformClient')
    def test_quickstart_with_project_and_tenant(self, mock_client_class):
        """Test quickstart() with project and tenant"""
        mock_client = create_mock_platform_client()
        mock_client_class.return_value = mock_client

        with patch('supero.core._load_py_api_lib_for_domain') as mock_load:
            mock_load.return_value = create_mock_load_lib_return()
            with patch.object(self.Supero, '_ensure_domain', lambda self: None):
                def _mock_load(self):
                    self._domain_obj = MagicMock()
                    self._domain_obj.uuid = 'test-uuid'
                    self._domain_uuid = 'test-uuid'
                with patch.object(self.Supero, '_load_existing_domain', _mock_load):
                    org = self.Supero.quickstart(
                        "acme-corp",
                        project="hr-system",
                        jwt_token="token",
                        tenant="sales"
                    )

                    self.assertEqual(org.project_name, "hr-system")
                    self.assertEqual(org.tenant_name, "sales")

    @patch('supero.core.PlatformClient')
    def test_quickstart_with_default_tenant(self, mock_client_class):
        """Test quickstart() uses default-tenant when only project specified"""
        mock_client = create_mock_platform_client()
        mock_client_class.return_value = mock_client

        with patch('supero.core._load_py_api_lib_for_domain') as mock_load:
            mock_load.return_value = create_mock_load_lib_return()
            with patch.object(self.Supero, '_ensure_domain', lambda self: None):
                def _mock_load(self):
                    self._domain_obj = MagicMock()
                    self._domain_obj.uuid = 'test-uuid'
                    self._domain_uuid = 'test-uuid'
                with patch.object(self.Supero, '_load_existing_domain', _mock_load):
                    org = self.Supero.quickstart("acme-corp", project="ecommerce", jwt_token="token")

                    self.assertEqual(org.project_name, "ecommerce")
                    self.assertEqual(org.tenant_name, "default-tenant")


class TestConnectWithProjectTenant(unittest.TestCase):
    """Test connect() with project and tenant parameters"""

    def setUp(self):
        """Setup common mocks"""
        from supero import Supero
        self.Supero = Supero

    @patch('supero.core.PlatformClient')
    def test_connect_with_default_project(self, mock_client_class):
        """Test connect() uses default-project when not specified"""
        mock_client = create_mock_platform_client()
        mock_client_class.return_value = mock_client

        with patch('supero.core._load_py_api_lib_for_domain') as mock_load:
            mock_load.return_value = create_mock_load_lib_return()
            with patch.object(self.Supero, '_ensure_domain', lambda self: None):
                def _mock_load(self):
                    self._domain_obj = MagicMock()
                    self._domain_obj.uuid = 'test-uuid'
                    self._domain_uuid = 'test-uuid'
                with patch.object(self.Supero, '_load_existing_domain', _mock_load):
                    org = self.Supero.connect("acme-corp")

                    self.assertEqual(org.project_name, "default-project")

    @patch('supero.core.PlatformClient')
    def test_connect_with_custom_project(self, mock_client_class):
        """Test connect() with custom project"""
        mock_client = create_mock_platform_client()
        mock_client_class.return_value = mock_client

        with patch('supero.core._load_py_api_lib_for_domain') as mock_load:
            mock_load.return_value = create_mock_load_lib_return()
            with patch.object(self.Supero, '_ensure_domain', lambda self: None):
                def _mock_load(self):
                    self._domain_obj = MagicMock()
                    self._domain_obj.uuid = 'test-uuid'
                    self._domain_uuid = 'test-uuid'
                with patch.object(self.Supero, '_load_existing_domain', _mock_load):
                    org = self.Supero.connect("acme-corp", project="ecommerce")

                    self.assertEqual(org.project_name, "ecommerce")



if __name__ == '__main__':
    unittest.main(verbosity=2)

