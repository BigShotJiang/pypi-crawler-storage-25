"""test_service_ui_manifest_sync.py

CI test: verifies SDK-bundled service UI manifests in
src/supero/ui/schemas/services/ match the tenant-services source.

If this fails, run ./build.sh to re-trigger the SERVICE_UI_MANIFESTS_V1
sync block.
"""
import filecmp
import json
import os
import unittest
from pathlib import Path


def _find_platform_root():
    here = Path(__file__).resolve().parent
    for candidate in [here, *here.parents]:
        if (candidate / "tenant-services" / "public-services").is_dir():
            return candidate
    raise RuntimeError(
        f"Could not locate tenant-services/ from {here}. "
        f"Set SUPERO_PLATFORM_ROOT env var to override."
    )


PLATFORM_ROOT = Path(
    os.environ.get("SUPERO_PLATFORM_ROOT") or _find_platform_root()
)
SOURCE_DIR = PLATFORM_ROOT / "tenant-services" / "public-services"
BUNDLED_DIR = (
    PLATFORM_ROOT / "infra" / "libs" / "py" / "src" / "supero"
    / "ui" / "schemas" / "services"
)


def _find_source_manifests():
    result = {}
    if not SOURCE_DIR.is_dir():
        return result
    for svc_dir in sorted(SOURCE_DIR.iterdir()):
        if not svc_dir.is_dir():
            continue
        manifest = svc_dir / "manifest.ui.json"
        if manifest.is_file():
            result[svc_dir.name] = manifest
    return result


def _find_bundled_manifests():
    result = {}
    if not BUNDLED_DIR.is_dir():
        return result
    for f in sorted(BUNDLED_DIR.iterdir()):
        if f.name.endswith(".ui.json"):
            svc_id = f.name[:-len(".ui.json")]
            result[svc_id] = f
    return result


class ServiceUIManifestSyncTest(unittest.TestCase):
    def test_source_dir_exists(self):
        self.assertTrue(SOURCE_DIR.is_dir(),
            f"tenant-services source not found: {SOURCE_DIR}")

    def test_every_source_has_bundled(self):
        sources = _find_source_manifests()
        bundled = _find_bundled_manifests()
        if not sources:
            self.skipTest("No source manifests yet")
        missing = set(sources.keys()) - set(bundled.keys())
        self.assertFalse(missing,
            f"Source manifests missing from SDK bundle: {sorted(missing)}. "
            f"Run ./build.sh to trigger sync.")

    def test_no_stale_bundled(self):
        sources = _find_source_manifests()
        bundled = _find_bundled_manifests()
        if not bundled:
            self.skipTest("No bundled manifests yet")
        stale = set(bundled.keys()) - set(sources.keys())
        self.assertFalse(stale,
            f"Stale bundled manifests with no source: {sorted(stale)}. "
            f"Remove them from {BUNDLED_DIR}/")

    def test_byte_identical(self):
        sources = _find_source_manifests()
        bundled = _find_bundled_manifests()
        common = set(sources.keys()) & set(bundled.keys())
        if not common:
            self.skipTest("No services in both source and bundle yet")
        drift = []
        for svc in sorted(common):
            if not filecmp.cmp(str(sources[svc]), str(bundled[svc]),
                               shallow=False):
                drift.append(svc)
        self.assertFalse(drift,
            f"Drift detected in: {drift}. Re-run ./build.sh to re-sync.")

    def test_all_bundled_valid_json(self):
        bundled = _find_bundled_manifests()
        if not bundled:
            self.skipTest("No bundled manifests yet")
        for svc, path in bundled.items():
            with self.subTest(service=svc):
                with open(path, "r", encoding="utf-8") as f:
                    data = json.load(f)
                self.assertIsInstance(data, dict, f"{svc}: top-level not object")
                self.assertIn("service_id", data, f"{svc}: no service_id")
                self.assertIn("ui_schemas", data, f"{svc}: no ui_schemas")
                self.assertIsInstance(data["ui_schemas"], list,
                    f"{svc}: ui_schemas not list")


if __name__ == "__main__":
    unittest.main(verbosity=2)

