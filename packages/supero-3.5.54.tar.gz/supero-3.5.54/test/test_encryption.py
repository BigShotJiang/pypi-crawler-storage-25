"""
Unit tests for ApiLib encryption integration.

Tests ApiLib-specific encryption functionality including:
- CRUD operations with encryption enabled/disabled
- Error handling for encryption mismatches
- Integration with EncryptionManager

Location: ~/ai_infra/infra/libs/py/test/test_encryption.py
"""

import unittest
from unittest.mock import Mock, MagicMock, patch
import sys
import os

# Add source to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

# Add utils for EncryptionManager
utils_path = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', '..', '..', 'utils'))
sys.path.insert(0, utils_path)

from py_api_lib.api_lib import ApiLib, EncryptionRequiredError
from crypto_utils import EncryptionManager

class TestApiLibEncryption(unittest.TestCase):
    """Test ApiLib integration with encryption."""
    
    def setUp(self):
        """Set up test ApiLib instances."""
        self.key = EncryptionManager._generate_key()
        
        # Mock the ApiClient
        with patch('py_api_lib.api_lib.ApiClient'):
            # ApiLib WITHOUT encryption (default)
            self.api_no_encrypt = ApiLib(
                api_server_host='localhost',
                api_server_port='8082',
                enable_encryption=False
            )
            
            # ApiLib WITH encryption
            self.api_with_encrypt = ApiLib(
                api_server_host='localhost',
                api_server_port='8082',
                enable_encryption=True,
                encryption_key=self.key,
                domain_name='test-domain'
            )
        
        # Mock api_client for both instances
        self.api_no_encrypt.api_client = Mock()
        self.api_with_encrypt.api_client = Mock()
    
    def test_initialization_without_encryption(self):
        """Test ApiLib initializes without encryption by default."""
        self.assertFalse(self.api_no_encrypt.enable_encryption)
        self.assertIsNone(self.api_no_encrypt.encryption_manager)
    
    def test_initialization_with_encryption(self):
        """Test ApiLib initializes with encryption when enabled."""
        self.assertTrue(self.api_with_encrypt.enable_encryption)
        self.assertIsNotNone(self.api_with_encrypt.encryption_manager)
        self.assertEqual(self.api_with_encrypt.domain_name, 'test-domain')
    
    def test_initialization_encryption_requires_key(self):
        """Test that enabling encryption without key raises error."""
        with patch('py_api_lib.api_lib.ApiClient'):
            with self.assertRaises(ValueError):
                ApiLib(
                    api_server_host='localhost',
                    enable_encryption=True,
                    encryption_key=None  # Missing key
                )
    
    def test_contains_encrypted_values(self):
        """Test detection of encrypted values in objects."""
        # Object with encrypted values
        obj_with_encrypted = {
            'uuid': 'test-123',
            'name': 'test',
            'secret_field': 'ENC:v1:dGVzdA==',
        }
        
        self.assertTrue(
            self.api_with_encrypt._contains_encrypted_values(obj_with_encrypted)
        )
        
        # Object without encrypted values
        obj_without_encrypted = {
            'uuid': 'test-123',
            'name': 'test',
            'public_field': 'plaintext',
        }
        
        self.assertFalse(
            self.api_with_encrypt._contains_encrypted_values(obj_without_encrypted)
        )
    
    def test_list_encrypted_fields(self):
        """Test listing encrypted fields in an object."""
        obj_data = {
            'uuid': 'test-123',
            'name': 'test',
            'field1': 'ENC:v1:abc',
            'field2': 'plaintext',
            'field3': 'ENC:v1:def',
        }
        
        encrypted_fields = self.api_with_encrypt._list_encrypted_fields(obj_data)
        
        self.assertEqual(set(encrypted_fields), {'field1', 'field3'})
    
    def test_contains_encrypted_in_nested_dict(self):
        """Test detection of encrypted values in nested structures."""
        obj_data = {
            'uuid': 'test-123',
            'config': {
                'password': 'ENC:v1:secret'
            }
        }
        
        self.assertTrue(self.api_with_encrypt._contains_encrypted_values(obj_data))
    
    def test_contains_encrypted_in_list(self):
        """Test detection of encrypted values in lists."""
        obj_data = {
            'uuid': 'test-123',
            'tokens': ['plain', 'ENC:v1:secret', 'plain2']
        }
        
        self.assertTrue(self.api_with_encrypt._contains_encrypted_values(obj_data))
    
    def test_create_without_encryption(self):
        """Test creating object without encryption."""
        # Mock object
        mock_obj = Mock()
        mock_obj.name = 'test-obj'
        mock_obj.uuid = 'test-uuid'
        mock_obj.fq_name = ['domain', 'proj', 'test-obj']
        mock_obj.parent_type = 'project'
        
        # Mock to_dict
        with patch('py_api_lib.api_lib.safe_serialize_to_dict') as mock_serialize:
            mock_serialize.return_value = {
                'uuid': 'test-uuid',
                'name': 'test-obj',
                'fq_name': ['domain', 'proj', 'test-obj'],
                'api_key': 'secret-key',
            }
            
            # Mock create response
            self.api_no_encrypt.api_client._http_create.return_value = {
                'test_type': {'uuid': 'test-uuid'}
            }
            
            # Create object
            result = self.api_no_encrypt._object_create('test-type', mock_obj)
            
            # Verify call
            call_args = self.api_no_encrypt.api_client._http_create.call_args[0]
            payload = call_args[1]
            
            # Verify NOT encrypted
            self.assertEqual(payload['api_key'], 'secret-key')
            self.assertFalse(payload['api_key'].startswith('ENC:'))
            self.assertEqual(payload['_encrypted'], False)
    
    def test_create_with_encryption(self):
        """Test creating object with encryption enabled."""
        # Mock object
        mock_obj = Mock()
        mock_obj.name = 'test-obj'
        mock_obj.uuid = 'test-uuid'
        mock_obj.fq_name = ['domain', 'proj', 'test-obj']
        mock_obj.parent_type = 'project'
        
        # Mock to_dict
        with patch('py_api_lib.api_lib.safe_serialize_to_dict') as mock_serialize:
            mock_serialize.return_value = {
                'uuid': 'test-uuid',
                'name': 'test-obj',
                'fq_name': ['domain', 'proj', 'test-obj'],
                'api_key': 'secret-key',
            }
            
            # Mock create response
            self.api_with_encrypt.api_client._http_create.return_value = {
                'test_type': {'uuid': 'test-uuid'}
            }
            
            # Create object
            result = self.api_with_encrypt._object_create('test-type', mock_obj)
            
            # Verify call
            call_args = self.api_with_encrypt.api_client._http_create.call_args[0]
            payload = call_args[1]
            
            # Verify encrypted
            self.assertTrue(payload['api_key'].startswith('ENC:'))
            self.assertEqual(payload['_encrypted'], True)
            
            # Verify metadata NOT encrypted
            self.assertEqual(payload['uuid'], 'test-uuid')
            self.assertEqual(payload['name'], 'test-obj')
    
    def test_read_encrypted_without_encryption_enabled(self):
        """Test reading encrypted object without encryption enabled raises error."""
        # Mock read response with encrypted data
        self.api_no_encrypt.api_client._http_read.return_value = {
            'test_type': {
                'uuid': 'test-uuid',
                'name': 'test-obj',
                'api_key': 'ENC:v1:dGVzdA==',
                '_encrypted': True,
            }
        }
        
        # Should raise EncryptionRequiredError
        with self.assertRaises(EncryptionRequiredError) as context:
            self.api_no_encrypt._object_read('test-type', id='test-uuid')
        
        # Check that error message mentions encrypted data
        self.assertIn('encrypted data', str(context.exception))  # ✅ CORRECT
        self.assertIn("['api_key']", str(context.exception))  # Verify field list
    
    def test_read_encrypted_with_encryption_enabled(self):
        """Test reading encrypted object with encryption enabled."""
        # Create encrypted data
        encrypted_api_key = self.api_with_encrypt.encryption_manager._encrypt_value('secret-key')
        
        # Mock read response
        self.api_with_encrypt.api_client._http_read.return_value = {
            'test_type': {
                'uuid': 'test-uuid',
                'name': 'test-obj',
                'fq_name': ['domain', 'proj', 'test-obj'],
                'parent_uuid': 'parent-uuid',
                'obj_type': 'test_type',
                'parent_type': 'project',
                'api_key': encrypted_api_key,
                '_encrypted': True,
            }
        }
        
        # Mock hydrate
        with patch.object(self.api_with_encrypt, '_hydrate_object') as mock_hydrate:
            mock_obj = Mock()
            mock_obj.api_key = 'secret-key'  # Decrypted value
            mock_hydrate.return_value = mock_obj
            
            # Read object
            result = self.api_with_encrypt._object_read('test-type', id='test-uuid')
            
            # Verify hydrate was called with decrypted data
            call_args = mock_hydrate.call_args[0]
            decrypted_data = call_args[1]
            
            # Verify decryption happened
            self.assertEqual(decrypted_data['api_key'], 'secret-key')
            self.assertFalse(decrypted_data['api_key'].startswith('ENC:'))
    
    def test_read_plaintext_without_encryption(self):
        """Test reading plaintext object without encryption works normally."""
        # Mock read response (no encryption)
        self.api_no_encrypt.api_client._http_read.return_value = {
            'test_type': {
                'uuid': 'test-uuid',
                'name': 'test-obj',
                'fq_name': ['domain', 'proj', 'test-obj'],
                'parent_uuid': 'parent-uuid',
                'obj_type': 'test_type',
                'parent_type': 'project',
                'api_key': 'secret-key',
                '_encrypted': False,
            }
        }
        
        # Mock hydrate
        with patch.object(self.api_no_encrypt, '_hydrate_object') as mock_hydrate:
            mock_obj = Mock()
            mock_hydrate.return_value = mock_obj
            
            # Read object - should work
            result = self.api_no_encrypt._object_read('test-type', id='test-uuid')
            
            self.assertIsNotNone(result)
    
    def test_update_with_encryption(self):
        """Test updating object with encryption enabled."""
        # Mock object
        mock_obj = Mock()
        mock_obj.uuid = 'test-uuid'
        
        # Mock to_dict
        with patch('py_api_lib.api_lib.safe_serialize_to_dict') as mock_serialize:
            mock_serialize.return_value = {
                'uuid': 'test-uuid',
                'name': 'updated-obj',
                'api_key': 'new-secret',
            }
            
            # Mock update response
            self.api_with_encrypt.api_client._http_update.return_value = {
                'test_type': {'uuid': 'test-uuid'}
            }
            
            # Update object
            result = self.api_with_encrypt._object_update('test-type', mock_obj)
            
            # Verify call
            call_args = self.api_with_encrypt.api_client._http_update.call_args[0]
            payload = call_args[2]
            
            # Verify encrypted
            self.assertTrue(payload['api_key'].startswith('ENC:'))
            self.assertEqual(payload['_encrypted'], True)
    
    def test_update_without_encryption(self):
        """Test updating object without encryption."""
        # Mock object
        mock_obj = Mock()
        mock_obj.uuid = 'test-uuid'
        
        # Mock to_dict
        with patch('py_api_lib.api_lib.safe_serialize_to_dict') as mock_serialize:
            mock_serialize.return_value = {
                'uuid': 'test-uuid',
                'name': 'updated-obj',
                'api_key': 'new-secret',
            }
            
            # Mock update response
            self.api_no_encrypt.api_client._http_update.return_value = {
                'test_type': {'uuid': 'test-uuid'}
            }
            
            # Update object
            result = self.api_no_encrypt._object_update('test-type', mock_obj)
            
            # Verify call
            call_args = self.api_no_encrypt.api_client._http_update.call_args[0]
            payload = call_args[2]
            
            # Verify NOT encrypted
            self.assertEqual(payload['api_key'], 'new-secret')
            self.assertEqual(payload['_encrypted'], False)
    
    def test_list_skips_encrypted_when_encryption_disabled(self):
        """Test list operation skips encrypted objects when encryption disabled."""
        # Mock list response with mixed objects
        self.api_no_encrypt.api_client._http_list.return_value = [
            {
                'uuid': 'obj-1',
                'name': 'plaintext-obj',
                'obj_type': 'test_type',
                'api_key': 'key1',
                '_encrypted': False,
            },
            {
                'uuid': 'obj-2',
                'name': 'encrypted-obj',
                'obj_type': 'test_type',
                'api_key': 'ENC:v1:dGVzdA==',
                '_encrypted': True,
            }
        ]
        
        # Mock hydrate
        with patch.object(self.api_no_encrypt, '_hydrate_object') as mock_hydrate:
            mock_hydrate.return_value = Mock()
            
            # List objects
            result = self.api_no_encrypt._objects_list('test-type', detail=True)
            
            # Should only return 1 object (skipped encrypted one)
            self.assertEqual(len(result), 1)
    
    def test_list_decrypts_when_encryption_enabled(self):
        """Test list operation decrypts objects when encryption enabled."""
        # Create encrypted data
        encrypted_key = self.api_with_encrypt.encryption_manager._encrypt_value('secret')
        
        # Mock list response
        self.api_with_encrypt.api_client._http_list.return_value = [
              {
                'uuid': 'obj-1',
                'name': 'encrypted-obj',
                'fq_name': ['domain', 'proj', 'obj-1'],
                'parent_uuid': 'parent-uuid',
                'obj_type': 'test_type',
                'parent_type': 'project',
                'api_key': encrypted_key,
                '_encrypted': True,
             }
        ] 
       
        # Mock hydrate
        with patch.object(self.api_with_encrypt, '_hydrate_object') as mock_hydrate:
            mock_hydrate.return_value = Mock()
            
            # List objects
            result = self.api_with_encrypt._objects_list('test-type', detail=True)
            
            # Verify hydrate was called with decrypted data
            call_args = mock_hydrate.call_args[0]
            decrypted_data = call_args[1]
            
            self.assertEqual(decrypted_data['api_key'], 'secret')
    
    def test_list_bulk_with_encryption(self):
        """Test list_bulk handles encryption correctly."""
        # Create encrypted data
        encrypted_key = self.api_with_encrypt.encryption_manager._encrypt_value('secret')
        
        # Mock list_bulk response
        self.api_with_encrypt.api_client._http_list_bulk.return_value = [
            {
                'uuid': 'obj-1',
                'name': 'encrypted-obj',
                'fq_name': ['domain', 'proj', 'obj-1'],
                'parent_uuid': 'parent-uuid',
                'obj_type': 'test_type',
                'parent_type': 'project',
                'api_key': encrypted_key,
                '_encrypted': True,
            },
        ]
        
        # Mock hydrate
        with patch.object(self.api_with_encrypt, '_hydrate_object') as mock_hydrate:
            mock_hydrate.return_value = Mock()
            
            # List bulk
            result = self.api_with_encrypt.list_bulk('test-type', ['obj-1'])
            
            # Verify decryption
            self.assertEqual(len(result), 1)
    
    def test_list_bulk_skips_encrypted_when_disabled(self):
        """Test list_bulk skips encrypted objects when encryption disabled."""
        # Mock list_bulk response
        self.api_no_encrypt.api_client._http_list_bulk.return_value = [
            {
                'uuid': 'obj-1',
                'name': 'plaintext-obj',
                'api_key': 'key1',
                '_encrypted': False,
            },
            {
                'uuid': 'obj-2',
                'name': 'encrypted-obj',
                'api_key': 'ENC:v1:secret',
                '_encrypted': True,
            },
        ]
        
        # Mock hydrate
        with patch.object(self.api_no_encrypt, '_hydrate_object') as mock_hydrate:
            mock_hydrate.return_value = Mock()
            
            # List bulk
            result = self.api_no_encrypt.list_bulk('test-type', ['obj-1', 'obj-2'])
            
            # Should only return 1 (plaintext)
            self.assertEqual(len(result), 1)
    
    def test_encryption_metadata_in_response(self):
        """Test that _encrypted metadata is handled correctly."""
        mock_obj = Mock()
        mock_obj.name = 'test'
        mock_obj.uuid = 'test-uuid'
        mock_obj.fq_name = ['domain', 'test']
        mock_obj.parent_type = 'domain'
        
        with patch('py_api_lib.api_lib.safe_serialize_to_dict') as mock_serialize:
            mock_serialize.return_value = {
                'uuid': 'test-uuid',
                'name': 'test',
                'data': 'value'
            }
            
            self.api_with_encrypt.api_client._http_create.return_value = {
                'test_type': {'uuid': 'test-uuid', '_encrypted': True}
            }
            
            result = self.api_with_encrypt._object_create('test-type', mock_obj)
            
            # Result should include uuid
            self.assertEqual(result, 'test-uuid')


def run_tests():
    """Run all ApiLib encryption tests."""
    loader = unittest.TestLoader()
    suite = loader.loadTestsFromTestCase(TestApiLibEncryption)
    
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)
    
    return 0 if result.wasSuccessful() else 1


if __name__ == '__main__':
    sys.exit(run_tests())
