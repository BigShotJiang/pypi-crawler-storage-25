"""
test_cli_ensure_files.py — Unit tests for the file-generation helpers in supero.cli.run

Location: ~/supero/platform/infra/libs/py/test/test_cli_ensure_files.py

Run:
    python -m pytest test_cli_ensure_files.py -v
    python -m unittest test_cli_ensure_files -v

Coverage:
    - _ensure_docs_files: generates all 4 docs files on a clean directory
    - _ensure_docs_files: preserves existing files (idempotent)
    - _ensure_docs_files: CLAUDE.md == .cursorrules == .windsurfrules (byte-identical)
    - _ensure_docs_files: placeholder substitution from EnvManager values
    - _ensure_docs_files: fallback values when env is empty
    - _ensure_docker_files: generates Dockerfile + docker-compose.yml
    - _ensure_docker_files: preserves existing files
    - _ensure_docker_files: uses _make_slug for container naming
    - Error resilience: continues on _safe_write failure without crashing
    - Unicode app names: produces ASCII slugs in Docker files
"""

import hashlib
import io
import os
import re
import sys
import tempfile
import unittest
from unittest.mock import MagicMock, patch


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _get_run_module():
    """Return the supero.cli.run MODULE (avoids package attribute shadowing)."""
    import importlib
    return importlib.import_module('supero.cli.run')


class _FakeEnv:
    """
    Minimal EnvManager stand-in for testing.

    Real EnvManager is tested separately in test_cli_env_manager.py.
    Here we just need something with a .get(key, default) method.
    """

    def __init__(self, values=None):
        self.values = values or {}

    def get(self, key, default=""):
        """Mirror EnvManager.get(): return value or default."""
        v = self.values.get(key)
        if v:
            return v
        return default


def _hash(path):
    """Return the first 16 hex chars of SHA256 for a file."""
    with open(path, 'rb') as f:
        return hashlib.sha256(f.read()).hexdigest()[:16]


def _run_under_cwd(tmpdir):
    """
    Context manager replacement: cd into tmpdir for the duration of a test.

    The ensure_* functions use os.getcwd() internally, so we change into the
    tmp directory before calling them and restore on exit.
    """
    class _Ctx:
        def __init__(self, target):
            self.target = target
            self.original = None

        def __enter__(self):
            self.original = os.getcwd()
            os.chdir(self.target)
            return self.target

        def __exit__(self, *args):
            os.chdir(self.original)

    return _Ctx(tmpdir)


# Standard env values used by most tests
STANDARD_ENV_VALUES = {
    "SUPERO_DOMAIN":         "foodtruck",
    "SUPERO_PROJECT":        "default-project",
    "SUPERO_DEFAULT_TENANT": "default-tenant",
    "SUPERO_ADMIN_EMAIL":    "admin@foodtruck.com",
    "PORT":                  "5648",
}


# ---------------------------------------------------------------------------
# _ensure_docs_files — happy path
# ---------------------------------------------------------------------------

class TestEnsureDocsFilesFresh(unittest.TestCase):
    """Tests for _ensure_docs_files() on a fresh directory."""

    def setUp(self):
        self.run_module = _get_run_module()
        self.tmpdir = tempfile.mkdtemp(prefix="supero-docs-test-")
        self.env = _FakeEnv(STANDARD_ENV_VALUES)

    def tearDown(self):
        import shutil
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_generates_readme(self):
        """README.md is created on a fresh directory."""
        with _run_under_cwd(self.tmpdir):
            self.run_module._ensure_docs_files(
                self.tmpdir, self.env, app_name="Food Truck App"
            )
        self.assertTrue(os.path.exists(os.path.join(self.tmpdir, "README.md")))

    def test_generates_claude_md(self):
        """CLAUDE.md is created on a fresh directory."""
        with _run_under_cwd(self.tmpdir):
            self.run_module._ensure_docs_files(
                self.tmpdir, self.env, app_name="Food Truck App"
            )
        self.assertTrue(os.path.exists(os.path.join(self.tmpdir, "CLAUDE.md")))

    def test_generates_cursorrules(self):
        """.cursorrules is created on a fresh directory."""
        with _run_under_cwd(self.tmpdir):
            self.run_module._ensure_docs_files(
                self.tmpdir, self.env, app_name="Food Truck App"
            )
        self.assertTrue(os.path.exists(os.path.join(self.tmpdir, ".cursorrules")))

    def test_generates_windsurfrules(self):
        """.windsurfrules is created on a fresh directory."""
        with _run_under_cwd(self.tmpdir):
            self.run_module._ensure_docs_files(
                self.tmpdir, self.env, app_name="Food Truck App"
            )
        self.assertTrue(os.path.exists(os.path.join(self.tmpdir, ".windsurfrules")))

    def test_generates_all_four_files(self):
        """All 4 docs files are created in a single call."""
        with _run_under_cwd(self.tmpdir):
            self.run_module._ensure_docs_files(
                self.tmpdir, self.env, app_name="Food Truck App"
            )
        expected = {"README.md", "CLAUDE.md", ".cursorrules", ".windsurfrules"}
        actual = set(os.listdir(self.tmpdir))
        self.assertEqual(expected - actual, set(),
                         f"Missing files: {expected - actual}")

    def test_all_files_non_empty(self):
        """Every generated file has non-zero content."""
        with _run_under_cwd(self.tmpdir):
            self.run_module._ensure_docs_files(
                self.tmpdir, self.env, app_name="Food Truck App"
            )
        for name in ["README.md", "CLAUDE.md", ".cursorrules", ".windsurfrules"]:
            path = os.path.join(self.tmpdir, name)
            self.assertGreater(os.path.getsize(path), 100,
                               f"{name} is suspiciously small")


class TestEnsureDocsFilesContent(unittest.TestCase):
    """Tests for the content of files produced by _ensure_docs_files()."""

    def setUp(self):
        self.run_module = _get_run_module()
        self.tmpdir = tempfile.mkdtemp(prefix="supero-content-test-")
        self.env = _FakeEnv(STANDARD_ENV_VALUES)

    def tearDown(self):
        import shutil
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def _generate(self, app_name="Food Truck App", env=None):
        """Helper: run _ensure_docs_files and return the generated files."""
        env = env or self.env
        with _run_under_cwd(self.tmpdir):
            self.run_module._ensure_docs_files(
                self.tmpdir, env, app_name=app_name
            )

    def _read(self, name):
        """Helper: read a generated file."""
        with open(os.path.join(self.tmpdir, name), encoding='utf-8') as f:
            return f.read()

    def test_readme_contains_app_name(self):
        """README.md includes the provided app_name."""
        self._generate(app_name="Food Truck Management Platform")
        content = self._read("README.md")
        self.assertIn("Food Truck Management Platform", content)

    def test_readme_contains_domain(self):
        """README.md includes the SUPERO_DOMAIN value."""
        self._generate()
        content = self._read("README.md")
        self.assertIn("foodtruck", content)

    def test_readme_contains_port(self):
        """README.md references the configured PORT."""
        self._generate()
        content = self._read("README.md")
        self.assertIn("5648", content)

    def test_readme_contains_admin_email(self):
        """README.md shows the admin email for login."""
        self._generate()
        content = self._read("README.md")
        self.assertIn("admin@foodtruck.com", content)

    def test_readme_no_stray_placeholders(self):
        """README.md has no unsubstituted {PLACEHOLDER} tokens."""
        self._generate()
        content = self._read("README.md")
        stray = re.findall(r'\{[A-Z_]{3,}\}', content)
        self.assertEqual(stray, [], f"Stray placeholders: {stray}")

    def test_readme_contains_sdk_version(self):
        """README.md footer contains the CLI SDK version."""
        self._generate()
        content = self._read("README.md")
        self.assertIn(self.run_module.__version__, content)

    def test_claude_md_is_generic(self):
        """CLAUDE.md has zero placeholders (100% generic content)."""
        self._generate()
        content = self._read("CLAUDE.md")
        stray = re.findall(r'\{[A-Z_]{3,}\}', content)
        self.assertEqual(stray, [], f"CLAUDE.md should be placeholder-free: {stray}")

    def test_claude_md_references_schemas_py(self):
        """CLAUDE.md points the AI at schemas.py."""
        self._generate()
        content = self._read("CLAUDE.md")
        self.assertIn("schemas.py", content)

    def test_claude_md_warns_about_supero_ui_js(self):
        """CLAUDE.md warns AI not to modify supero-ui.js."""
        self._generate()
        content = self._read("CLAUDE.md")
        self.assertIn("supero-ui.js", content)
        self.assertIn("DO NOT", content)


class TestEnsureDocsFilesIdentical(unittest.TestCase):
    """Tests verifying CLAUDE.md == .cursorrules == .windsurfrules."""

    def setUp(self):
        self.run_module = _get_run_module()
        self.tmpdir = tempfile.mkdtemp(prefix="supero-identical-test-")
        self.env = _FakeEnv(STANDARD_ENV_VALUES)

    def tearDown(self):
        import shutil
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_claude_and_cursor_identical(self):
        """.cursorrules is byte-identical to CLAUDE.md."""
        with _run_under_cwd(self.tmpdir):
            self.run_module._ensure_docs_files(
                self.tmpdir, self.env, app_name="Test"
            )
        self.assertEqual(
            _hash(os.path.join(self.tmpdir, "CLAUDE.md")),
            _hash(os.path.join(self.tmpdir, ".cursorrules")),
        )

    def test_claude_and_windsurf_identical(self):
        """.windsurfrules is byte-identical to CLAUDE.md."""
        with _run_under_cwd(self.tmpdir):
            self.run_module._ensure_docs_files(
                self.tmpdir, self.env, app_name="Test"
            )
        self.assertEqual(
            _hash(os.path.join(self.tmpdir, "CLAUDE.md")),
            _hash(os.path.join(self.tmpdir, ".windsurfrules")),
        )

    def test_all_three_rule_files_identical(self):
        """All three AI rule files have the same content hash."""
        with _run_under_cwd(self.tmpdir):
            self.run_module._ensure_docs_files(
                self.tmpdir, self.env, app_name="Test"
            )
        hashes = {
            _hash(os.path.join(self.tmpdir, "CLAUDE.md")),
            _hash(os.path.join(self.tmpdir, ".cursorrules")),
            _hash(os.path.join(self.tmpdir, ".windsurfrules")),
        }
        self.assertEqual(len(hashes), 1, f"Rule files differ: {hashes}")


# ---------------------------------------------------------------------------
# _ensure_docs_files — idempotency
# ---------------------------------------------------------------------------

class TestEnsureDocsFilesIdempotent(unittest.TestCase):
    """Tests that _ensure_docs_files() preserves existing files on re-run."""

    def setUp(self):
        self.run_module = _get_run_module()
        self.tmpdir = tempfile.mkdtemp(prefix="supero-idempotent-test-")
        self.env = _FakeEnv(STANDARD_ENV_VALUES)

    def tearDown(self):
        import shutil
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_existing_readme_preserved(self):
        """User-customized README.md is not overwritten."""
        readme_path = os.path.join(self.tmpdir, "README.md")
        custom_content = "# My Custom README\n\nI edited this myself.\n"
        with open(readme_path, 'w') as f:
            f.write(custom_content)

        with _run_under_cwd(self.tmpdir):
            self.run_module._ensure_docs_files(
                self.tmpdir, self.env, app_name="Test"
            )

        with open(readme_path) as f:
            self.assertEqual(f.read(), custom_content)

    def test_existing_claude_md_preserved(self):
        """User-customized CLAUDE.md is not overwritten."""
        claude_path = os.path.join(self.tmpdir, "CLAUDE.md")
        custom_content = "# My custom AI instructions"
        with open(claude_path, 'w') as f:
            f.write(custom_content)

        with _run_under_cwd(self.tmpdir):
            self.run_module._ensure_docs_files(
                self.tmpdir, self.env, app_name="Test"
            )

        with open(claude_path) as f:
            self.assertEqual(f.read(), custom_content)



    def test_partial_preservation_fills_missing(self):
        """If README exists but CLAUDE.md doesn't, only CLAUDE.md is generated."""
        readme_path = os.path.join(self.tmpdir, "README.md")
        with open(readme_path, 'w') as f:
            f.write("custom readme")

        with _run_under_cwd(self.tmpdir):
            self.run_module._ensure_docs_files(
                self.tmpdir, self.env, app_name="Test"
            )

        # README preserved
        with open(readme_path) as f:
            self.assertEqual(f.read(), "custom readme")
        # CLAUDE.md generated fresh
        self.assertTrue(os.path.exists(os.path.join(self.tmpdir, "CLAUDE.md")))

    def test_double_invocation_idempotent(self):
        """Calling _ensure_docs_files twice leaves files unchanged."""
        with _run_under_cwd(self.tmpdir):
            self.run_module._ensure_docs_files(
                self.tmpdir, self.env, app_name="Test"
            )
        first_hashes = {
            name: _hash(os.path.join(self.tmpdir, name))
            for name in ["README.md", "CLAUDE.md", ".cursorrules", ".windsurfrules"]
        }

        with _run_under_cwd(self.tmpdir):
            self.run_module._ensure_docs_files(
                self.tmpdir, self.env, app_name="Test"
            )
        second_hashes = {
            name: _hash(os.path.join(self.tmpdir, name))
            for name in ["README.md", "CLAUDE.md", ".cursorrules", ".windsurfrules"]
        }

        self.assertEqual(first_hashes, second_hashes)


# ---------------------------------------------------------------------------
# _ensure_docs_files — env value handling
# ---------------------------------------------------------------------------

class TestEnsureDocsFilesEnvValues(unittest.TestCase):
    """Tests that env values are correctly read and defaulted."""

    def setUp(self):
        self.run_module = _get_run_module()
        self.tmpdir = tempfile.mkdtemp(prefix="supero-env-test-")

    def tearDown(self):
        import shutil
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def _generate_and_read_readme(self, env_values, app_name="Test App"):
        env = _FakeEnv(env_values)
        with _run_under_cwd(self.tmpdir):
            self.run_module._ensure_docs_files(
                self.tmpdir, env, app_name=app_name
            )
        with open(os.path.join(self.tmpdir, "README.md"), encoding='utf-8') as f:
            return f.read()

    def test_empty_env_uses_defaults(self):
        """When env is empty, sensible defaults appear in README."""
        content = self._generate_and_read_readme({})
        # Defaults from _ensure_docs_files:
        #   domain="your-domain", project="default-project",
        #   tenant="default-tenant", admin_email=f"admin@{domain}.com",
        #   port="5648"
        self.assertIn("your-domain", content)
        self.assertIn("default-project", content)
        self.assertIn("default-tenant", content)
        self.assertIn("5648", content)

    def test_custom_port_propagates(self):
        """Non-default PORT appears throughout README."""
        content = self._generate_and_read_readme({"PORT": "8080"})
        self.assertIn("8080", content)

    def test_ui_port_fallback(self):
        """UI_PORT is used if PORT is not set."""
        content = self._generate_and_read_readme({"UI_PORT": "9090"})
        self.assertIn("9090", content)

    def test_admin_email_fallback(self):
        """When SUPERO_ADMIN_EMAIL is unset, derived from domain."""
        content = self._generate_and_read_readme({"SUPERO_DOMAIN": "mycompany"})
        # Default: admin@{domain}.com
        self.assertIn("admin@mycompany.com", content)

    def test_explicit_admin_email_takes_precedence(self):
        """Explicit SUPERO_ADMIN_EMAIL wins over derived value."""
        content = self._generate_and_read_readme({
            "SUPERO_DOMAIN": "mycompany",
            "SUPERO_ADMIN_EMAIL": "real-admin@elsewhere.io",
        })
        self.assertIn("real-admin@elsewhere.io", content)


# ---------------------------------------------------------------------------
# _ensure_docs_files — unicode app names
# ---------------------------------------------------------------------------

class TestEnsureDocsFilesUnicode(unittest.TestCase):
    """Tests that unicode app names produce correct files."""

    def setUp(self):
        self.run_module = _get_run_module()
        self.tmpdir = tempfile.mkdtemp(prefix="supero-unicode-test-")
        self.env = _FakeEnv(STANDARD_ENV_VALUES)

    def tearDown(self):
        import shutil
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_unicode_app_name_preserved_in_readme(self):
        """Unicode app_name appears verbatim in the README title."""
        with _run_under_cwd(self.tmpdir):
            self.run_module._ensure_docs_files(
                self.tmpdir, self.env, app_name="Über Café Management"
            )
        with open(os.path.join(self.tmpdir, "README.md"), encoding='utf-8') as f:
            content = f.read()
        self.assertIn("Über Café Management", content)

    def test_unicode_app_name_produces_ascii_slug_in_readme(self):
        """Docker commands in README use ASCII slug, not unicode."""
        with _run_under_cwd(self.tmpdir):
            self.run_module._ensure_docs_files(
                self.tmpdir, self.env, app_name="Über Café Management"
            )
        with open(os.path.join(self.tmpdir, "README.md"), encoding='utf-8') as f:
            content = f.read()
        # ASCII slug should appear in docker commands
        self.assertIn("uber-cafe-management", content)


# ---------------------------------------------------------------------------
# _ensure_docker_files — happy path
# ---------------------------------------------------------------------------

class TestEnsureDockerFilesFresh(unittest.TestCase):
    """Tests for _ensure_docker_files() on a fresh directory."""

    def setUp(self):
        self.run_module = _get_run_module()
        self.tmpdir = tempfile.mkdtemp(prefix="supero-docker-test-")
        self.env = _FakeEnv(STANDARD_ENV_VALUES)

    def tearDown(self):
        import shutil
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_generates_dockerfile(self):
        """Dockerfile is created on a fresh directory."""
        with _run_under_cwd(self.tmpdir):
            self.run_module._ensure_docker_files(
                self.tmpdir, self.env, app_name="Food Truck"
            )
        self.assertTrue(os.path.exists(os.path.join(self.tmpdir, "Dockerfile")))

    def test_generates_docker_compose(self):
        """docker-compose.yml is created on a fresh directory."""
        with _run_under_cwd(self.tmpdir):
            self.run_module._ensure_docker_files(
                self.tmpdir, self.env, app_name="Food Truck"
            )
        self.assertTrue(os.path.exists(os.path.join(self.tmpdir, "docker-compose.yml")))

    def test_dockerfile_contains_non_root_user(self):
        """Generated Dockerfile runs as non-root for security."""
        with _run_under_cwd(self.tmpdir):
            self.run_module._ensure_docker_files(
                self.tmpdir, self.env, app_name="Test"
            )
        with open(os.path.join(self.tmpdir, "Dockerfile")) as f:
            content = f.read()
        self.assertIn("USER supero", content)

    def test_dockerfile_contains_healthcheck(self):
        """Generated Dockerfile has a HEALTHCHECK directive."""
        with _run_under_cwd(self.tmpdir):
            self.run_module._ensure_docker_files(
                self.tmpdir, self.env, app_name="Test"
            )
        with open(os.path.join(self.tmpdir, "Dockerfile")) as f:
            content = f.read()
        self.assertIn("HEALTHCHECK", content)

    def test_dockerfile_pins_sdk_version(self):
        """Generated Dockerfile pins supero>={current version}."""
        with _run_under_cwd(self.tmpdir):
            self.run_module._ensure_docker_files(
                self.tmpdir, self.env, app_name="Test"
            )
        with open(os.path.join(self.tmpdir, "Dockerfile")) as f:
            content = f.read()
        self.assertIn(f"supero>={self.run_module.__version__}", content)

    def test_dockerfile_runs_run_sh(self):
        """Generated Dockerfile CMD is ./run.sh, not --server-only."""
        with _run_under_cwd(self.tmpdir):
            self.run_module._ensure_docker_files(
                self.tmpdir, self.env, app_name="Test"
            )
        with open(os.path.join(self.tmpdir, "Dockerfile")) as f:
            content = f.read()
        self.assertIn("./run.sh", content)
        # Must NOT contain the old bad pattern
        self.assertNotIn('"-m", "supero.cli", "--server-only"', content)

    def test_compose_has_healthcheck(self):
        """Generated docker-compose.yml defines a healthcheck block."""
        with _run_under_cwd(self.tmpdir):
            self.run_module._ensure_docker_files(
                self.tmpdir, self.env, app_name="Test"
            )
        with open(os.path.join(self.tmpdir, "docker-compose.yml")) as f:
            content = f.read()
        self.assertIn("healthcheck:", content)

    def test_compose_has_volume_mounts(self):
        """Generated docker-compose.yml mounts source files for dev hot-reload."""
        with _run_under_cwd(self.tmpdir):
            self.run_module._ensure_docker_files(
                self.tmpdir, self.env, app_name="Test"
            )
        with open(os.path.join(self.tmpdir, "docker-compose.yml")) as f:
            content = f.read()
        self.assertIn("./schemas.py:/app/schemas.py", content)
        self.assertIn("./setup.py:/app/setup.py", content)
        self.assertNotIn("./ui:/app/ui", content)  # ui/ intentionally not bind-mounted (PermissionError fix)

    def test_compose_uses_slug_as_container_name(self):
        """Container name uses the computed slug, not raw app_name."""
        with _run_under_cwd(self.tmpdir):
            self.run_module._ensure_docker_files(
                self.tmpdir, self.env, app_name="Food Truck App"
            )
        with open(os.path.join(self.tmpdir, "docker-compose.yml")) as f:
            content = f.read()
        self.assertIn("container_name: food-truck-app", content)


class TestEnsureDockerFilesUnicode(unittest.TestCase):
    """Tests for _ensure_docker_files() with unicode app names."""

    def setUp(self):
        self.run_module = _get_run_module()
        self.tmpdir = tempfile.mkdtemp(prefix="supero-docker-unicode-")
        self.env = _FakeEnv(STANDARD_ENV_VALUES)

    def tearDown(self):
        import shutil
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_unicode_app_name_produces_ascii_container_name(self):
        """Über Café → container_name: uber-cafe (valid for Docker)."""
        with _run_under_cwd(self.tmpdir):
            self.run_module._ensure_docker_files(
                self.tmpdir, self.env, app_name="Über Café"
            )
        with open(os.path.join(self.tmpdir, "docker-compose.yml")) as f:
            content = f.read()
        self.assertIn("container_name: uber-cafe", content)
        # Must not contain unicode in container name
        self.assertNotIn("Über", content)
        self.assertNotIn("Café", content)

    def test_long_app_name_capped_slug(self):
        """Very long app names produce slugs ≤ 40 chars in Docker files."""
        long_name = "The Best Food Truck Management and Ordering Platform Ever"
        with _run_under_cwd(self.tmpdir):
            self.run_module._ensure_docker_files(
                self.tmpdir, self.env, app_name=long_name
            )
        with open(os.path.join(self.tmpdir, "docker-compose.yml")) as f:
            content = f.read()
        # Find the container_name line
        for line in content.split('\n'):
            if 'container_name:' in line:
                slug = line.split(':', 1)[1].strip()
                self.assertLessEqual(len(slug), 40)
                self.assertFalse(slug.endswith('-'))
                return
        self.fail("No container_name found in docker-compose.yml")


# ---------------------------------------------------------------------------
# _ensure_docker_files — idempotency
# ---------------------------------------------------------------------------

class TestEnsureDockerFilesIdempotent(unittest.TestCase):
    """Tests that _ensure_docker_files() preserves existing files."""

    def setUp(self):
        self.run_module = _get_run_module()
        self.tmpdir = tempfile.mkdtemp(prefix="supero-docker-idem-")
        self.env = _FakeEnv(STANDARD_ENV_VALUES)

    def tearDown(self):
        import shutil
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_existing_dockerfile_preserved(self):
        """User-customized Dockerfile is not overwritten."""
        path = os.path.join(self.tmpdir, "Dockerfile")
        custom = "FROM python:3.12-slim\nRUN echo 'custom'\n"
        with open(path, 'w') as f:
            f.write(custom)

        with _run_under_cwd(self.tmpdir):
            self.run_module._ensure_docker_files(
                self.tmpdir, self.env, app_name="Test"
            )

        with open(path) as f:
            self.assertEqual(f.read(), custom)

    def test_existing_compose_preserved(self):
        """User-customized docker-compose.yml is not overwritten."""
        path = os.path.join(self.tmpdir, "docker-compose.yml")
        custom = "services:\n  custom:\n    image: nginx\n"
        with open(path, 'w') as f:
            f.write(custom)

        with _run_under_cwd(self.tmpdir):
            self.run_module._ensure_docker_files(
                self.tmpdir, self.env, app_name="Test"
            )

        with open(path) as f:
            self.assertEqual(f.read(), custom)

    def test_partial_preservation(self):
        """If Dockerfile exists but compose doesn't, only compose is generated."""
        dockerfile_path = os.path.join(self.tmpdir, "Dockerfile")
        with open(dockerfile_path, 'w') as f:
            f.write("FROM python:3.12-slim\n")

        with _run_under_cwd(self.tmpdir):
            self.run_module._ensure_docker_files(
                self.tmpdir, self.env, app_name="Test"
            )

        # Dockerfile preserved
        with open(dockerfile_path) as f:
            self.assertEqual(f.read(), "FROM python:3.12-slim\n")
        # compose.yml generated
        self.assertTrue(os.path.exists(os.path.join(self.tmpdir, "docker-compose.yml")))

    def test_double_invocation_idempotent(self):
        """Calling _ensure_docker_files twice produces identical files."""
        with _run_under_cwd(self.tmpdir):
            self.run_module._ensure_docker_files(
                self.tmpdir, self.env, app_name="Test"
            )
        h1 = {
            name: _hash(os.path.join(self.tmpdir, name))
            for name in ["Dockerfile", "docker-compose.yml"]
        }

        with _run_under_cwd(self.tmpdir):
            self.run_module._ensure_docker_files(
                self.tmpdir, self.env, app_name="Test"
            )
        h2 = {
            name: _hash(os.path.join(self.tmpdir, name))
            for name in ["Dockerfile", "docker-compose.yml"]
        }

        self.assertEqual(h1, h2)


# ---------------------------------------------------------------------------
# Error resilience — _safe_write failures
# ---------------------------------------------------------------------------

class TestEnsureFilesErrorResilience(unittest.TestCase):
    """Tests that ensure functions degrade gracefully on write errors."""

    def setUp(self):
        self.run_module = _get_run_module()
        self.tmpdir = tempfile.mkdtemp(prefix="supero-error-test-")
        self.env = _FakeEnv(STANDARD_ENV_VALUES)

    def tearDown(self):
        import shutil
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_docs_files_continue_on_permission_error(self):
        """If one docs file extract fails, the others still attempt.

        3.5.0: each item goes through extract_to_project in its own
        try/except. Patching extract_to_project lets us inject failure
        for a specific item and verify others were still attempted.

        The .cursorrules and .windsurfrules aliases are post-extract
        copies inside extract_to_project, not separate items, so they
        are NOT in call_log. We assert their presence on disk instead.
        """
        from supero.install import PROJECT_MANIFEST
        original_extract = self.run_module.extract_to_project
        call_log = []

        def mock_extract(project_dir, items=None, render_values=None):
            item = items[0]  # 3.5.0 layer always passes a single-item list
            dest = PROJECT_MANIFEST.get(item, item)
            label = os.path.basename(dest)
            call_log.append(label)
            if label == "README.md":
                raise PermissionError("simulated permission denial")
            return original_extract(project_dir, items=items,
                                    render_values=render_values)

        with patch.object(self.run_module, 'extract_to_project',
                          side_effect=mock_extract):
            with _run_under_cwd(self.tmpdir):
                # Should not raise even if README.md fails
                self.run_module._ensure_docs_files(
                    self.tmpdir, self.env, app_name="Test"
                )

        # Each docs item the function planned to extract was attempted,
        # despite README.md failing partway through.
        self.assertIn("README.md", call_log)
        self.assertIn("CLAUDE.md", call_log)
        self.assertIn("CUSTOMIZATION.md", call_log)

    def test_docker_files_continue_on_error(self):
        """If Dockerfile extract fails, docker-compose.yml still attempts.

        3.5.0: per-item extract_to_project loop with try/except.
        """
        from supero.install import PROJECT_MANIFEST
        original_extract = self.run_module.extract_to_project
        call_log = []

        def mock_extract(project_dir, items=None, render_values=None):
            item = items[0]
            dest = PROJECT_MANIFEST.get(item, item)
            label = os.path.basename(dest)
            call_log.append(label)
            if label == "Dockerfile":
                raise PermissionError("simulated permission denial")
            return original_extract(project_dir, items=items,
                                    render_values=render_values)

        with patch.object(self.run_module, 'extract_to_project',
                          side_effect=mock_extract):
            with _run_under_cwd(self.tmpdir):
                self.run_module._ensure_docker_files(
                    self.tmpdir, self.env, app_name="Test"
                )

        # Both labels attempted despite Dockerfile failure.
        self.assertIn("Dockerfile", call_log)
        self.assertIn("docker-compose.yml", call_log)


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    unittest.main(verbosity=2)
