"""
Unit Tests for PlatformClient v2.0 - Context-Aware Architecture

NEW in v2.0:
- Domain extraction from JWT token
- domain_name and domain_uuid properties
- Context-aware architecture support
"""
import unittest
from unittest.mock import Mock, MagicMock, patch, PropertyMock
import sys
import os
import json
import base64

# Add src to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '../src'))

from supero.platform_client import (
    PlatformClient,
    AuthenticationError,
    AuthorizationError,
    RateLimitError
)


# ============================================================================
# Helper Functions
# ============================================================================

def create_mock_jwt(domain_name="test-domain", domain_uuid="uuid-123", user_uuid="user-456"):
    """Create a mock JWT token with domain context"""
    import jwt
    
    payload = {
        "domain_name": domain_name,
        "domain_uuid": domain_uuid,
        "user_uuid": user_uuid,
        "email": "test@example.com",
        "exp": 9999999999  # Far future
    }
    
    # Create JWT (no signature needed for tests)
    token = jwt.encode(payload, "secret", algorithm="HS256")
    return token


# ============================================================================
# Domain Extraction Tests (NEW in v2.0)
# ============================================================================

class TestPlatformClientDomainExtraction(unittest.TestCase):
    """Test domain context extraction from JWT token"""
    
    def test_init_extracts_domain_from_jwt(self):
        """Test initialization extracts domain from JWT"""
        jwt_token = create_mock_jwt(
            domain_name="acme-corp",
            domain_uuid="domain-uuid-123"
        )
        
        client = PlatformClient(jwt_token=jwt_token)
        
        self.assertEqual(client.domain_name, "acme-corp")
        self.assertEqual(client.domain_uuid, "domain-uuid-123")
    
    def test_init_without_jwt_has_no_domain(self):
        """Test initialization without JWT has no domain context"""
        client = PlatformClient()
        
        self.assertIsNone(client.domain_name)
        self.assertIsNone(client.domain_uuid)
    
    def test_set_jwt_token_extracts_domain(self):
        """Test set_jwt_token extracts domain context"""
        client = PlatformClient()
        
        # Initially no domain
        self.assertIsNone(client.domain_name)
        
        # Set JWT token
        jwt_token = create_mock_jwt(
            domain_name="new-domain",
            domain_uuid="new-uuid"
        )
        client.update_token(jwt_token)
        
        # Now has domain context
        self.assertEqual(client.domain_name, "new-domain")
        self.assertEqual(client.domain_uuid, "new-uuid")
    
    def test_clear_jwt_token_clears_domain(self):
        """Test clearing JWT token clears domain context"""
        jwt_token = create_mock_jwt(domain_name="test-domain")
        client = PlatformClient(jwt_token=jwt_token)
        
        # Initially has domain
        self.assertEqual(client.domain_name, "test-domain")
        
        # Clear token
        client.clear_context()
        client.jwt_token = None
        
        # Domain context cleared
        self.assertIsNone(client.domain_name)
        self.assertIsNone(client.domain_uuid)
    
    def test_domain_extraction_with_invalid_jwt(self):
        """Test domain extraction with invalid JWT doesn't crash"""
        client = PlatformClient(jwt_token="invalid-token")
        
        # Should gracefully handle invalid token
        self.assertIsNone(client.domain_name)
        self.assertIsNone(client.domain_uuid)
    
    def test_domain_extraction_with_missing_claims(self):
        """Test domain extraction with JWT missing domain claims"""
        import jwt
        
        payload = {
            "email": "test@example.com",
            "exp": 9999999999
            # No domain_name or domain_uuid
        }
        
        token = jwt.encode(payload, "secret", algorithm="HS256")
        client = PlatformClient(jwt_token=token)
        
        # Should handle missing claims gracefully
        self.assertIsNone(client.domain_name)
        self.assertIsNone(client.domain_uuid)
    
    def test_domain_properties_are_readonly(self):
        """Test domain properties cannot be set directly"""
        jwt_token = create_mock_jwt(domain_name="original-domain")
        client = PlatformClient(jwt_token=jwt_token)
        
        # Properties should be read-only (attempting to set raises AttributeError)
        with self.assertRaises(AttributeError):
            client.domain_name = "hacked-domain"
        
        # Original value unchanged
        self.assertEqual(client.domain_name, "original-domain")


# ============================================================================
# Initialization Tests (Updated for v2.0)
# ============================================================================

class TestPlatformClientInit(unittest.TestCase):
    """Test PlatformClient initialization"""
    
    def test_init_default_values(self):
        """Test initialization with default values"""
        client = PlatformClient()
        
        self.assertEqual(client.base_url, "https://api.supero.dev:443")
        self.assertIsNone(client.jwt_token)
        self.assertIsNone(client.domain_name)  # NEW in v2.0
        self.assertIsNone(client.domain_uuid)  # NEW in v2.0
        self.assertEqual(client.timeout, 30)    
    def test_init_custom_values(self):
        """Test initialization with custom values"""
        jwt_token = create_mock_jwt(domain_name="test-domain")
        
        client = PlatformClient(
            base_url="http://api.example.com:8080/api/v1",
            jwt_token=jwt_token,
            timeout=60
        )
        
        self.assertEqual(client.base_url, "http://api.example.com:8080")
        self.assertEqual(client.domain_name, "test-domain")  # Extracted from JWT
        self.assertEqual(client.timeout, 60)    
    def test_init_https_port_443(self):
        """Test HTTPS is used for port 443"""
        client = PlatformClient(base_url="https://api.example.com:443/api/v1")
        
        self.assertTrue(client.base_url.startswith("https://"))
    
    def test_init_http_other_ports(self):
        """Test HTTP is used for non-443 ports"""
        client = PlatformClient(base_url="http://api.example.com:8080/api/v1")
        
        self.assertTrue(client.base_url.startswith("http://"))
    
    def test_init_with_jwt_sets_header_and_extracts_domain(self):
        """Test JWT token sets header and extracts domain context"""
        jwt_token = create_mock_jwt(domain_name="acme-corp", domain_uuid="uuid-123")
        client = PlatformClient(jwt_token=jwt_token)
        
        # Header set        
        # Domain extracted (NEW in v2.0)
        self.assertEqual(client.domain_name, "acme-corp")
        self.assertEqual(client.domain_uuid, "uuid-123")
    


class TestPlatformClientJWT(unittest.TestCase):
    """Test JWT token management"""
    
    def setUp(self):
        self.client = PlatformClient()
    
    def test_set_jwt_token_updates_domain_context(self):
        """Test setting JWT token updates domain context"""
        jwt_token = create_mock_jwt(domain_name="new-domain", domain_uuid="new-uuid")
        
        self.client.update_token(jwt_token)
        
        # Token set
        self.assertEqual(self.client.jwt_token, jwt_token)        
        # Domain context updated (NEW in v2.0)
        self.assertEqual(self.client.domain_name, "new-domain")
        self.assertEqual(self.client.domain_uuid, "new-uuid")
    
    def test_clear_jwt_token_clears_domain_context(self):
        """Test clearing JWT token clears domain context"""
        jwt_token = create_mock_jwt(domain_name="temp-domain")
        self.client.update_token(jwt_token)
        
        # Clear token
        self.client.clear_context()
        self.client.jwt_token = None        # Token cleared
        self.assertIsNone(self.client.jwt_token)
        
        # Domain context cleared (NEW in v2.0)
        self.assertIsNone(self.client.domain_name)
        self.assertIsNone(self.client.domain_uuid)
    
    def test_clear_jwt_token_when_not_set(self):
        """Test clearing JWT token when not set doesn't raise"""
        # Should not raise
        self.client.clear_context()
        self.client.jwt_token = None
        
        self.assertIsNone(self.client.jwt_token)
        self.assertIsNone(self.client.domain_name)
        self.assertIsNone(self.client.domain_uuid)


# ============================================================================
# HTTP Methods Tests (Unchanged from v1.0 - all still work)
# ============================================================================

class MockResponse:
    """Mock HTTP response for testing"""
    
    def __init__(
        self,
        status_code: int = 200,
        json_data: dict = None,
        text: str = None,
        content: bytes = None,
        headers: dict = None
    ):
        self.status_code = status_code
        self._json_data = json_data
        self.text = text or (json.dumps(json_data) if json_data else "")
        self.content = content or self.text.encode('utf-8')
        self.headers = headers or {}
    
    def json(self):
        if self._json_data is not None:
            return self._json_data
        if self.text:
            return json.loads(self.text)
        raise ValueError("No JSON data")
    
    def iter_lines(self):
        """Simulate streaming response lines"""
        if hasattr(self, '_lines'):
            for line in self._lines:
                yield line.encode('utf-8') if isinstance(line, str) else line
    
    def raise_for_status(self):
        if self.status_code >= 400:
            raise Exception(f"HTTP {self.status_code}")
    
    def __enter__(self):
        return self
    
    def __exit__(self, *args):
        pass


class TestPlatformClientGet(unittest.TestCase):
    """Test GET request functionality"""
    
    def setUp(self):
        self.client = PlatformClient(base_url="http://localhost:8080/api/v1")
    
    @patch('requests.Session.request')
    def test_get_basic(self, mock_request):
        """Test basic GET request"""
        mock_request.return_value = MockResponse(
            status_code=200,
            json_data={"data": "value"}
        )
        
        result = self.client.get("/test/endpoint")
        
        self.assertEqual(result, {"data": "value"})
        mock_request.assert_called_once()
        call_args = mock_request.call_args
    
    @patch('requests.Session.request')
    def test_get_with_params(self, mock_request):
        """Test GET request with query parameters"""
        mock_request.return_value = MockResponse(
            status_code=200,
            json_data={"results": []}
        )
        
        self.client.get("/search", params={"q": "test", "limit": 10})
        
        call_args = mock_request.call_args
        self.assertEqual(call_args[1]["params"], {"q": "test", "limit": 10})


class TestPlatformClientPost(unittest.TestCase):
    """Test POST request functionality"""
    
    def setUp(self):
        self.client = PlatformClient(base_url="http://localhost:8080/api/v1")
    
    @patch('requests.Session.request')
    def test_post_with_json(self, mock_request):
        """Test POST request with JSON body"""
        mock_request.return_value = MockResponse(
            status_code=201,
            json_data={"id": "new-123"}
        )
        
        result = self.client.post("/create", json={"name": "test"})
        
        self.assertEqual(result, {"id": "new-123"})
        call_args = mock_request.call_args
        self.assertEqual(call_args[1]["json"], {"name": "test"})


# ============================================================================
# Error Handling Tests (Unchanged)
# ============================================================================

class TestPlatformClientErrors(unittest.TestCase):
    """Test error handling"""
    
    def setUp(self):
        self.client = PlatformClient(base_url="http://localhost:8080/api/v1")
    
    @patch('requests.Session.request')
    def test_401_raises_authentication_error(self, mock_request):
        """Test 401 raises AuthenticationError"""
        mock_request.return_value = MockResponse(status_code=401)
        
        with self.assertRaises(AuthenticationError) as ctx:
            self.client.get("/protected")
        
        self.assertIn("Authentication failed", str(ctx.exception))
    
    @patch('requests.Session.request')
    def test_403_raises_authorization_error(self, mock_request):
        """Test 403 raises AuthorizationError"""
        mock_request.return_value = MockResponse(status_code=403)
        
        with self.assertRaises(AuthorizationError) as ctx:
            self.client.get("/forbidden")
        
        self.assertIn("Permission denied", str(ctx.exception))
    
    @patch('requests.Session.request')
    def test_429_raises_rate_limit_error(self, mock_request):
        """Test 429 raises RateLimitError"""
        mock_request.return_value = MockResponse(status_code=429)
        
        with self.assertRaises(RateLimitError) as ctx:
            self.client.get("/rate-limited")
        
        self.assertIn("Rate limit", str(ctx.exception))


# ============================================================================
# Integration Tests (Updated for v2.0)
# ============================================================================

class TestPlatformClientIntegration(unittest.TestCase):
    """Integration-like tests for common workflows"""
    
    def setUp(self):
        jwt_token = create_mock_jwt(domain_name="test-org")
        self.client = PlatformClient(
            base_url="http://localhost:8080/api/v1",
            jwt_token=jwt_token
        
        )
    
    @patch('requests.Session.request')
    def test_login_workflow_updates_domain_context(self, mock_request):
        """Test login workflow updates domain context"""
        # Create new JWT with different domain
        new_jwt = create_mock_jwt(domain_name="acme-corp", domain_uuid="acme-uuid")
        
        # Login response
        mock_request.return_value = MockResponse(
            status_code=200,
            json_data={
                "auth": {"access_token": new_jwt},
                "user": {"email": "user@acme.com"}
            }
        )
        
        result = self.client.post("/auth/login", json={
            "email": "user@acme.com",
            "password": "password"
        })
        
        # Update client with new token
        self.client.update_token(result["auth"]["access_token"])
        
        # Domain context updated
        self.assertEqual(self.client.domain_name, "acme-corp")
        self.assertEqual(self.client.domain_uuid, "acme-uuid")


if __name__ == '__main__':
    unittest.main(verbosity=2)
