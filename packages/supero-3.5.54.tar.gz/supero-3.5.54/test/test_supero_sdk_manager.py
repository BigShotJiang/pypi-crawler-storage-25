"""
Unit Tests for SDKManager v2.0 - Context-Aware Architecture

CHANGES in v2.0:
- NO domain_name parameter in __init__
- Domain extracted from platform_client automatically
- All methods support api_key parameter for RBAC (already had this)
"""
import unittest
from unittest.mock import Mock, MagicMock, patch
import sys
import os
import tempfile
import shutil

# Add src to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '../src'))

from supero.sdk_manager import SDKManager
from supero.platform_client import AuthenticationError, AuthorizationError


# ============================================================================
# Mock Platform Client
# ============================================================================

class MockPlatformClient:
    """Mock PlatformClient for testing"""
    
    def __init__(self, domain_name="test-domain", domain_uuid="uuid-123"):
        self.domain_name = domain_name
        self.domain_uuid = domain_uuid
        self.base_url = "http://localhost:8083/api/v1"
        self.call_history = []
        self.responses = {}
        self.file_responses = {}
        self.project_name = "test-project"
        self.project_uuid = "project-uuid-456"
        self.tenant_name = "test-tenant"
        self.tenant_uuid = "tenant-uuid-789"
        self.user_uuid = "user-uuid-abc"
        self.user_email = "test@example.com"
        self.username = "testuser"
        self.role = "admin"
    
    def set_response(self, method: str, endpoint: str, response: dict):
        """Set mock response for endpoint"""
        key = f"{method}:{endpoint}"
        self.responses[key] = response
    
    def set_file_response(self, endpoint: str, content: bytes):
        """Set mock file download response"""
        self.file_responses[endpoint] = content
    
    def get(self, endpoint: str, params: dict = None, **kwargs):
        """Mock GET request"""
        self.call_history.append({
            "method": "GET",
            "endpoint": endpoint,
            "params": params,
            "kwargs": kwargs
        })
        key = f"GET:{endpoint}"
        if key in self.responses:
            return self.responses[key]
        return {}
    
    def post(self, endpoint: str, json: dict = None, data: dict = None,
             files: dict = None, **kwargs):
        """Mock POST request"""
        self.call_history.append({
            "method": "POST",
            "endpoint": endpoint,
            "json": json,
            "data": data,
            "files": files,
            "kwargs": kwargs
        })
        key = f"POST:{endpoint}"
        if key in self.responses:
            return self.responses[key]
        return {}
    
    def delete(self, endpoint: str, params: dict = None, **kwargs):
        """Mock DELETE request"""
        self.call_history.append({
            "method": "DELETE",
            "endpoint": endpoint,
            "params": params,
            "kwargs": kwargs
        })
        key = f"DELETE:{endpoint}"
        if key in self.responses:
            return self.responses[key]
        return {"success": True}
    
    def get_file(self, endpoint: str, **kwargs):
        """Mock file download"""
        self.call_history.append({
            "method": "GET_FILE",
            "endpoint": endpoint,
            "kwargs": kwargs
        })
        
        mock_response = Mock()
        if endpoint in self.file_responses:
            mock_response.content = self.file_responses[endpoint]
        else:
            mock_response.content = b"mock file content"
        mock_response.headers = {'Content-Disposition': 'attachment; filename="sdk.whl"'}
        return mock_response


# ============================================================================
# Initialization Tests (v2.0)
# ============================================================================

class TestSDKManagerInit(unittest.TestCase):
    """Test SDKManager initialization"""
    
    def test_init_extracts_domain_from_client(self):
        """Test initialization extracts domain from platform_client"""
        mock_client = MockPlatformClient(
            domain_name="acme-corp",
            domain_uuid="acme-uuid-123"
        )
        
        # NEW in v2.0: NO domain_name parameter!
        sdk_mgr = SDKManager(platform_client=mock_client)
        
        # Domain extracted from client
        self.assertEqual(sdk_mgr.domain_name, "acme-corp")
        self.assertEqual(sdk_mgr.domain_uuid, "acme-uuid-123")
    
    def test_init_with_different_domains(self):
        """Test initialization works with any domain"""
        mock_client = MockPlatformClient(
            domain_name="different-org",
            domain_uuid="different-uuid"
        )
        
        sdk_mgr = SDKManager(platform_client=mock_client)
        
        self.assertEqual(sdk_mgr.domain_name, "different-org")
        self.assertEqual(sdk_mgr.domain_uuid, "different-uuid")
    
    def test_init_stores_client_reference(self):
        """Test initialization stores client reference"""
        mock_client = MockPlatformClient()
        
        sdk_mgr = SDKManager(platform_client=mock_client)
        
        self.assertIs(sdk_mgr.client, mock_client)


# ============================================================================
# Generate SDK Tests (v2.0)
# ============================================================================

class TestSDKManagerGenerate(unittest.TestCase):
    """Test SDK generation functionality"""
    
    def setUp(self):
        self.mock_client = MockPlatformClient(
            domain_name="test-domain",
            domain_uuid="domain-uuid-123"
        )
        self.sdk_mgr = SDKManager(platform_client=self.mock_client)
    
    def test_generate_sdk_uses_domain_from_client(self):
        """Test generate_sdk uses domain from platform_client"""
        self.mock_client.set_response(
            "POST", "/sdks/generate",
            {
                "sdk_uuid": "sdk-123",
                "domain_name": "test-domain",
                "language": "python",
                "status": "pending"
            }
        )
        
        result = self.sdk_mgr.generate_sdk(language="python")
        
        # Verify domain was used from client
        call = self.mock_client.call_history[0]
        self.assertEqual(call['json']['domain_name'], "test-domain")
    
    def test_generate_sdk_with_api_key(self):
        """Test generating SDK with per-call API key override"""
        self.mock_client.set_response(
            "POST", "/sdks/generate",
            {"sdk_uuid": "sdk-123", "language": "python"}
        )
        
        result = self.sdk_mgr.generate_sdk(
            language="python",
            api_key="user-api-key"
        )
        
        # Verify API key was passed
        call = self.mock_client.call_history[0]
        self.assertEqual(call['kwargs']['api_key'], "user-api-key")
    
    def test_generate_sdk_with_version(self):
        """Test generating SDK with specific version"""
        self.mock_client.set_response(
            "POST", "/sdks/generate",
            {"sdk_uuid": "sdk-456", "version": "2.0.0"}
        )
        
        result = self.sdk_mgr.generate_sdk(
            language="python",
            version="2.0.0"
        )
        
        call = self.mock_client.call_history[0]
        self.assertEqual(call['json']['version'], "2.0.0")
    
    def test_generate_sdk_with_options(self):
        """Test generating SDK with custom options"""
        self.mock_client.set_response(
            "POST", "/sdks/generate",
            {"sdk_uuid": "sdk-789"}
        )
        
        result = self.sdk_mgr.generate_sdk(
            language="python",
            version="1.0.0",
            include_examples=True,
            include_tests=True
        )
        
        call = self.mock_client.call_history[0]
        self.assertTrue(call['json']['include_examples'])
        self.assertTrue(call['json']['include_tests'])
    
    def test_generate_multi_language(self):
        """Test generating SDKs for multiple languages"""
        self.mock_client.set_response(
            "POST", "/sdks/generate",
            {"sdk_uuid": "sdk-multi", "language": "python"}
        )
        
        result = self.sdk_mgr.generate_multi_language(
            languages=['python', 'typescript']
        )
        
        self.assertIn('python', result)
        self.assertIn('typescript', result)
    
    def test_generate_multi_language_with_api_key(self):
        """Test generating multi-language SDKs with API key"""
        self.mock_client.set_response(
            "POST", "/sdks/generate",
            {"sdk_uuid": "sdk-multi", "language": "python"}
        )
        
        result = self.sdk_mgr.generate_multi_language(
            languages=['python', 'typescript'],
            api_key="admin-api-key"
        )
        
        # Verify API key was passed to all calls
        for call in self.mock_client.call_history:
            if call['method'] == 'POST':
                self.assertEqual(call['kwargs']['api_key'], "admin-api-key")


# ============================================================================
# List SDKs Tests (v2.0)
# ============================================================================

class TestSDKManagerList(unittest.TestCase):
    """Test SDK listing functionality"""
    
    def setUp(self):
        self.mock_client = MockPlatformClient(
            domain_name="test-domain",
            domain_uuid="domain-uuid-123"
        )
        self.sdk_mgr = SDKManager(platform_client=self.mock_client)
    
    def test_list_sdks_uses_domain_from_client(self):
        """Test list_sdks uses domain from platform_client"""
        self.mock_client.set_response(
            "GET", "/domains/test-domain/sdks",
            [
                {"sdk_uuid": "sdk-1", "language": "python", "status": "completed"}
            ]
        )
        
        sdks = self.sdk_mgr.list_sdks()
        
        # Verify correct domain was used
        call = self.mock_client.call_history[0]
        self.assertIn("test-domain", call['endpoint'])
    
    def test_list_sdks_with_api_key(self):
        """Test listing SDKs with API key"""
        self.mock_client.set_response(
            "GET", "/domains/test-domain/sdks",
            [{"sdk_uuid": "sdk-1", "language": "python"}]
        )
        
        sdks = self.sdk_mgr.list_sdks(api_key="user-api-key")
        
        call = self.mock_client.call_history[0]
        self.assertEqual(call['kwargs']['api_key'], "user-api-key")
    
    def test_list_sdks_filtered_by_language(self):
        """Test listing SDKs filtered by language"""
        self.mock_client.set_response(
            "GET", "/domains/test-domain/sdks",
            [{"sdk_uuid": "sdk-1", "language": "python"}]
        )
        
        sdks = self.sdk_mgr.list_sdks(language="python")
        
        call = self.mock_client.call_history[0]
        self.assertEqual(call['params']['language'], "python")
    
    def test_list_sdks_filtered_by_version(self):
        """Test listing SDKs filtered by version"""
        self.mock_client.set_response(
            "GET", "/domains/test-domain/sdks",
            [{"sdk_uuid": "sdk-1", "version": "2.0.0"}]
        )
        
        sdks = self.sdk_mgr.list_sdks(version="2.0.0")
        
        self.assertEqual(len(sdks), 1)
        self.assertEqual(sdks[0]['version'], "2.0.0")
    
    def test_list_sdks_filtered_by_status(self):
        """Test listing SDKs filtered by status"""
        self.mock_client.set_response(
            "GET", "/domains/test-domain/sdks",
            [{"sdk_uuid": "sdk-1", "status": "completed"}]
        )
        
        sdks = self.sdk_mgr.list_sdks(status="completed")
        
        call = self.mock_client.call_history[0]
        self.assertEqual(call['params']['status'], "completed")


# ============================================================================
# Get SDK Tests (v2.0)
# ============================================================================

class TestSDKManagerGet(unittest.TestCase):
    """Test getting SDK details"""
    
    def setUp(self):
        self.mock_client = MockPlatformClient()
        self.sdk_mgr = SDKManager(platform_client=self.mock_client)
    
    def test_get_sdk(self):
        """Test getting a single SDK"""
        self.mock_client.set_response(
            "GET", "/sdks/sdk-123",
            {
                "sdk_uuid": "sdk-123",
                "language": "python",
                "version": "1.0.0",
                "status": "completed"
            }
        )
        
        sdk = self.sdk_mgr.get_sdk("sdk-123")
        
        self.assertEqual(sdk['sdk_uuid'], "sdk-123")
        self.assertEqual(sdk['language'], "python")
    
    def test_get_sdk_with_api_key(self):
        """Test getting a single SDK with API key"""
        self.mock_client.set_response(
            "GET", "/sdks/sdk-123",
            {"sdk_uuid": "sdk-123", "language": "python"}
        )
        
        sdk = self.sdk_mgr.get_sdk("sdk-123", api_key="user-api-key")
        
        call = self.mock_client.call_history[0]
        self.assertEqual(call['kwargs']['api_key'], "user-api-key")
    
    def test_get_latest_sdk(self):
        """Test getting latest SDK for language"""
        self.mock_client.set_response(
            "GET", "/domains/test-domain/sdks",
            [
                {"sdk_uuid": "sdk-1", "version": "1.0.0", "created_at": "2025-01-01"},
                {"sdk_uuid": "sdk-2", "version": "2.0.0", "created_at": "2025-01-02"}
            ]
        )
        
        sdk = self.sdk_mgr.get_latest_sdk(language="python")
        
        self.assertEqual(sdk['sdk_uuid'], "sdk-2")


# ============================================================================
# Check Status Tests (v2.0)
# ============================================================================

class TestSDKManagerStatus(unittest.TestCase):
    """Test SDK status checking"""
    
    def setUp(self):
        self.mock_client = MockPlatformClient()
        self.sdk_mgr = SDKManager(platform_client=self.mock_client)
    
    def test_check_status_pending(self):
        """Test checking status of pending SDK"""
        self.mock_client.set_response(
            "GET", "/sdks/sdk-123",
            {
                "sdk_uuid": "sdk-123",
                "status": "pending",
                "progress": 30
            }
        )
        
        status = self.sdk_mgr.check_status("sdk-123")
        
        self.assertEqual(status['status'], "pending")
        self.assertEqual(status['progress'], 30)
    
    def test_check_status_completed(self):
        """Test checking status of completed SDK"""
        self.mock_client.set_response(
            "GET", "/sdks/sdk-123",
            {
                "sdk_uuid": "sdk-123",
                "status": "completed",
                "download_url": "/sdks/sdk-123/download"
            }
        )
        
        status = self.sdk_mgr.check_status("sdk-123")
        
        self.assertEqual(status['status'], "completed")
        self.assertIn('download_url', status)
    
    def test_check_status_failed(self):
        """Test checking status of failed SDK"""
        self.mock_client.set_response(
            "GET", "/sdks/sdk-123",
            {
                "sdk_uuid": "sdk-123",
                "status": "failed",
                "error": "Generation failed"
            }
        )
        
        status = self.sdk_mgr.check_status("sdk-123")
        
        self.assertEqual(status['status'], "failed")
        self.assertIn('error', status)
    
    def test_check_status_with_api_key(self):
        """Test checking status with API key"""
        self.mock_client.set_response(
            "GET", "/sdks/sdk-123",
            {"sdk_uuid": "sdk-123", "status": "completed"}
        )
        
        status = self.sdk_mgr.check_status("sdk-123", api_key="user-api-key")
        
        call = self.mock_client.call_history[0]
        self.assertEqual(call['kwargs']['api_key'], "user-api-key")
    
    def test_wait_for_completion_success(self):
        """Test waiting for SDK completion (success)"""
        call_count = [0]
        
        def mock_get(endpoint, params=None, **kwargs):
            call_count[0] += 1
            if call_count[0] < 3:
                return {"status": "pending", "progress": call_count[0] * 30}
            else:
                return {"status": "completed", "download_url": "/download"}
        
        self.mock_client.get = mock_get
        
        result = self.sdk_mgr.wait_for_completion(
            "sdk-123",
            timeout=5,
            poll_interval=0.1
        )
        
        self.assertEqual(result['status'], "completed")
    
    def test_wait_for_completion_timeout(self):
        """Test waiting for SDK completion (timeout)"""
        self.mock_client.set_response(
            "GET", "/sdks/sdk-123",
            {"status": "pending", "progress": 50}
        )
        
        with self.assertRaises(TimeoutError):
            self.sdk_mgr.wait_for_completion(
                "sdk-123",
                timeout=1,
                poll_interval=0.5
            )


# ============================================================================
# Download SDK Tests (v2.0)
# ============================================================================

class TestSDKManagerDownload(unittest.TestCase):
    """Test SDK download functionality"""
    
    def setUp(self):
        self.mock_client = MockPlatformClient()
        self.sdk_mgr = SDKManager(platform_client=self.mock_client)
        self.download_dir = tempfile.mkdtemp()
    
    def tearDown(self):
        if os.path.exists(self.download_dir):
            shutil.rmtree(self.download_dir)
    
    def test_download_sdk_basic(self):
        """Test downloading SDK"""
        mock_content = b"mock file content"
        self.mock_client.set_file_response(
            "/sdks/sdk-123/download?artifact=wheel",
            mock_content
        )
        
        filepath = self.sdk_mgr.download_sdk(
            sdk_uuid="sdk-123",
            output_path=self.download_dir
        )
        
        self.assertTrue(os.path.exists(filepath))
        
        with open(filepath, 'rb') as f:
            content = f.read()
        self.assertEqual(content, mock_content)
    
    def test_download_sdk_with_artifact_type(self):
        """Test downloading specific artifact type"""
        mock_content = b"mock source tarball"
        self.mock_client.set_file_response(
            "/sdks/sdk-123/download?artifact=source",
            mock_content
        )
        
        filepath = self.sdk_mgr.download_sdk(
            sdk_uuid="sdk-123",
            output_path=self.download_dir,
            artifact="source"
        )
        
        self.assertTrue(os.path.exists(filepath))
    
    def test_download_sdk_with_api_key(self):
        """Test downloading SDK with API key"""
        mock_content = b"mock file content"
        self.mock_client.set_file_response(
            "/sdks/sdk-123/download?artifact=wheel",
            mock_content
        )
        
        filepath = self.sdk_mgr.download_sdk(
            sdk_uuid="sdk-123",
            output_path=self.download_dir,
            api_key="user-api-key"
        )
        
        call = self.mock_client.call_history[0]
        self.assertEqual(call['kwargs']['api_key'], "user-api-key")


# ============================================================================
# Delete SDK Tests (v2.0)
# ============================================================================

class TestSDKManagerDelete(unittest.TestCase):
    """Test SDK deletion functionality"""
    
    def setUp(self):
        self.mock_client = MockPlatformClient()
        self.sdk_mgr = SDKManager(platform_client=self.mock_client)
    
    def test_delete_sdk(self):
        """Test deleting a single SDK"""
        self.mock_client.set_response(
            "DELETE", "/sdks/sdk-123",
            {"success": True, "message": "SDK deleted"}
        )
        
        result = self.sdk_mgr.delete_sdk("sdk-123")
        
        self.assertTrue(result)
        
        call = self.mock_client.call_history[0]
        self.assertEqual(call['method'], "DELETE")
        self.assertEqual(call['endpoint'], "/sdks/sdk-123")
    
    def test_delete_sdk_with_api_key(self):
        """Test deleting SDK with API key"""
        self.mock_client.set_response(
            "DELETE", "/sdks/sdk-123",
            {"success": True}
        )
        
        result = self.sdk_mgr.delete_sdk("sdk-123", api_key="admin-api-key")
        
        call = self.mock_client.call_history[0]
        self.assertEqual(call['kwargs']['api_key'], "admin-api-key")
    
    def test_delete_version(self):
        """Test deleting all SDKs of a version"""
        self.mock_client.set_response(
            "GET", "/domains/test-domain/sdks",
            [
                {"sdk_uuid": "sdk-1", "version": "1.0.0"},
                {"sdk_uuid": "sdk-2", "version": "1.0.0"}
            ]
        )
        
        self.mock_client.set_response(
            "DELETE", "/sdks/sdk-1",
            {"success": True}
        )
        self.mock_client.set_response(
            "DELETE", "/sdks/sdk-2",
            {"success": True}
        )
        
        result = self.sdk_mgr.delete_version(version="1.0.0")
        
        self.assertEqual(len(result['deleted']), 2)
        self.assertEqual(len(result['failed']), 0)


# ============================================================================
# Error Handling Tests
# ============================================================================

class TestSDKManagerErrors(unittest.TestCase):
    """Test error handling"""
    
    def setUp(self):
        self.mock_client = MockPlatformClient()
        self.sdk_mgr = SDKManager(platform_client=self.mock_client)
    
    def test_generate_sdk_authentication_error(self):
        """Test generate_sdk with authentication error"""
        def raise_auth_error(*args, **kwargs):
            raise AuthenticationError("Invalid token")
        
        self.mock_client.post = raise_auth_error
        
        with self.assertRaises(AuthenticationError):
            self.sdk_mgr.generate_sdk(language="python")
    
    def test_list_sdks_authorization_error(self):
        """Test list_sdks with authorization error"""
        def raise_authz_error(*args, **kwargs):
            raise AuthorizationError("Permission denied")
        
        self.mock_client.get = raise_authz_error
        
        with self.assertRaises(AuthorizationError):
            self.sdk_mgr.list_sdks()
    
    def test_generate_sdk_invalid_language(self):
        """Test generating SDK with invalid language"""
        with self.assertRaises(ValueError) as ctx:
            self.sdk_mgr.generate_sdk(language="invalid-language")
        
        self.assertIn("Unsupported language", str(ctx.exception))


# ============================================================================
# Integration Tests (v2.0)
# ============================================================================

class TestSDKManagerIntegration(unittest.TestCase):
    """Integration tests for SDKManager"""
    
    def setUp(self):
        self.mock_client = MockPlatformClient(
            domain_name="acme-corp",
            domain_uuid="acme-uuid"
        )
        self.sdk_mgr = SDKManager(platform_client=self.mock_client)
    
    def test_complete_sdk_lifecycle(self):
        """Test complete SDK lifecycle"""
        # Generate
        self.mock_client.set_response(
            "POST", "/sdks/generate",
            {
                "sdk_uuid": "new-sdk",
                "language": "python",
                "status": "pending"
            }
        )
        
        result = self.sdk_mgr.generate_sdk(language="python")
        
        self.assertEqual(result['sdk_uuid'], "new-sdk")
        
        # Check status
        self.mock_client.set_response(
            "GET", "/sdks/new-sdk",
            {
                "sdk_uuid": "new-sdk",
                "status": "completed"
            }
        )
        
        status = self.sdk_mgr.check_status("new-sdk")
        
        self.assertEqual(status['status'], "completed")
        
        # Delete
        self.mock_client.set_response(
            "DELETE", "/sdks/new-sdk",
            {"success": True}
        )
        
        deleted = self.sdk_mgr.delete_sdk("new-sdk")
        
        self.assertTrue(deleted)


# ============================================================================
# RBAC Integration Tests
# ============================================================================

class TestSDKManagerRBAC(unittest.TestCase):
    """Test RBAC integration scenarios"""
    
    def setUp(self):
        self.mock_client = MockPlatformClient()
    
    def test_multi_user_server_scenario(self):
        """Test multi-user server scenario with per-call API keys"""
        # Create single SDKManager instance (like in a server)
        sdk_mgr = SDKManager(platform_client=self.mock_client)
        
        self.mock_client.set_response(
            "GET", "/domains/test-domain/sdks",
            [{"sdk_uuid": "sdk-1", "language": "python"}]
        )
        
        # User A's request
        user_a_key = "user-a-api-key"
        sdk_mgr.list_sdks(api_key=user_a_key)
        
        # User B's request
        user_b_key = "user-b-api-key"
        sdk_mgr.list_sdks(api_key=user_b_key)
        
        # Verify each request used correct API key
        self.assertEqual(
            self.mock_client.call_history[0]['kwargs']['api_key'],
            user_a_key
        )
        self.assertEqual(
            self.mock_client.call_history[1]['kwargs']['api_key'],
            user_b_key
        )


# ============================================================================
# Namespace Isolation Tests
# ============================================================================

class TestSDKManagerNamespaceIsolation(unittest.TestCase):
    """
    Verify SDK manager endpoints are NOT namespace-qualified.

    Namespace isolation applies to data-plane CRUD operations (billing:customer,
    finance:invoice, etc.).  SDK management (generate, list, download) operates
    at the domain/platform level and must never embed namespace qualifiers in
    its URLs.
    """

    def setUp(self):
        self.mock_client = MockPlatformClient(
            domain_name="test-domain",
            domain_uuid="domain-uuid-123",
        )
        self.sdk_mgr = SDKManager(platform_client=self.mock_client)

    def _has_namespace_qualifier(self, endpoint: str) -> bool:
        """Return True if endpoint contains a colon-qualified segment like 'billing:customer'."""
        import re
        return bool(re.search(r'/[^/]+:[^/]+', endpoint))

    def test_generate_sdk_endpoint_has_no_namespace(self):
        """generate_sdk() URL must not contain a namespace qualifier."""
        self.mock_client.set_response(
            "POST", "/sdks/generate",
            {"sdk_uuid": "sdk-1", "language": "python"},
        )
        self.sdk_mgr.generate_sdk(language="python")
        for call in self.mock_client.call_history:
            self.assertFalse(
                self._has_namespace_qualifier(call["endpoint"]),
                f"generate_sdk endpoint should not contain namespace qualifier: {call['endpoint']}",
            )

    def test_list_sdks_endpoint_has_no_namespace(self):
        """list_sdks() URL must not contain a namespace qualifier."""
        self.mock_client.set_response(
            "GET", f"/domains/test-domain/sdks",
            [{"sdk_uuid": "sdk-1", "language": "python"}],
        )
        self.sdk_mgr.list_sdks()
        for call in self.mock_client.call_history:
            self.assertFalse(
                self._has_namespace_qualifier(call["endpoint"]),
                f"list_sdks endpoint should not contain namespace qualifier: {call['endpoint']}",
            )

    def test_sdk_manager_domain_is_plain_name(self):
        """SDKManager domain_name must be a plain name without namespace colons."""
        self.assertNotIn(":", self.sdk_mgr.domain_name)


if __name__ == '__main__':
    unittest.main(verbosity=2)
