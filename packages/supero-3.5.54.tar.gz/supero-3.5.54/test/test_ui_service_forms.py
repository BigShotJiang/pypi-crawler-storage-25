"""
Batch 3 (v3.1): Service form pipeline (mobile-side primarily).

v3.1 changes:
  - Uses self.mobile_code (comment-stripped) for greps.
  - Signature checks via H.has_function_signature (allows extra params).
  - Acronym/secret list checks tolerate quote style (single OR double).
"""
from __future__ import annotations
import re
import unittest

import os as _os
import sys as _sys
_sys.path.insert(0, _os.path.join(_os.path.dirname(_os.path.abspath(__file__)), 'ui'))
import _helpers as H


class TestSuiHelpers(unittest.TestCase):
    """The _sui* family of internal helpers used by ServiceWidget forms."""

    @classmethod
    def setUpClass(cls):
        H.load_ui_sources_or_skip(cls, mobile=True)

    def test_field_render_type_helper(self):
        self.assertTrue(
            H.has_function_signature(self.mobile_code,
                                     '_suiFieldRenderType',
                                     'fieldName', 'fieldSpec'),
            "_suiFieldRenderType missing or signature changed",
        )

    def test_interpolate_helper(self):
        self.assertTrue(
            H.has_function_signature(self.mobile_code,
                                     '_suiInterpolate',
                                     'template', 'context'),
            "_suiInterpolate missing or signature changed",
        )

    def test_initial_form_data_helper(self):
        self.assertTrue(
            H.has_function_signature(self.mobile_code,
                                     '_suiInitialFormData',
                                     'opDef', 'defaultsFromProps', 'context'),
            "_suiInitialFormData missing or signature changed",
        )

    def test_validate_required_helper(self):
        self.assertTrue(
            H.has_function_signature(self.mobile_code,
                                     '_suiValidateRequired',
                                     'opDef', 'formData'),
            "_suiValidateRequired missing or signature changed",
        )

    def test_validate_json_fields_helper(self):
        self.assertTrue(
            H.has_function_signature(self.mobile_code,
                                     '_suiValidateJsonFields'),
            "_suiValidateJsonFields missing",
        )

    def test_coerce_for_submit_helper(self):
        self.assertTrue(
            H.has_function_signature(self.mobile_code,
                                     '_suiCoerceForSubmit',
                                     'opDef', 'formData'),
            "_suiCoerceForSubmit missing or signature changed",
        )

    def test_field_label_helper(self):
        self.assertRegex(
            self.mobile_code,
            r'(?:const|var|let|function)\s+_suiFieldLabel\b',
            "_suiFieldLabel missing",
        )


class TestSuiAcronymsAndOutputFields(unittest.TestCase):
    """Hard-coded lists used by form rendering and result masking.

    These tests inspect string contents of arrays — must use _text
    (string literals preserved), not _code.
    """

    @classmethod
    def setUpClass(cls):
        H.load_ui_sources_or_skip(cls, mobile=True)

    def test_acronyms_list_exists(self):
        m = re.search(
            r"_SUI_ACRONYMS_MOBILE\s*=\s*\[([^\]]+)\]", self.mobile_text)
        self.assertIsNotNone(m, "_SUI_ACRONYMS_MOBILE array not found")

    def test_acronyms_includes_required_terms(self):
        """Sanity: domain-critical terms must be in the acronym list.

        v3.1: tolerates either single OR double quotes around terms.
        """
        m = re.search(
            r"_SUI_ACRONYMS_MOBILE\s*=\s*\[([^\]]+)\]", self.mobile_text)
        if not m:
            self.skipTest("_SUI_ACRONYMS_MOBILE not found")
        content = m.group(1)
        for required in ('UUID', 'URL', 'API', 'JWT', 'OAUTH'):
            self.assertRegex(
                content, rf"['\"]{required}['\"]",
                f"_SUI_ACRONYMS_MOBILE missing required term: {required}",
            )

    def test_output_secret_fields_list(self):
        """_OUTPUT_SECRET_FIELDS drives result masking — must exist."""
        m = re.search(
            r"_OUTPUT_SECRET_FIELDS\s*=\s*\[([^\]]+)\]",
            self.mobile_text, flags=re.DOTALL,
        )
        self.assertIsNotNone(m, "_OUTPUT_SECRET_FIELDS list missing")

    def test_output_secret_fields_includes_known_secrets(self):
        """Critical: known secret field names must be in the masking list."""
        m = re.search(
            r"_OUTPUT_SECRET_FIELDS\s*=\s*\[([^\]]+)\]",
            self.mobile_text, flags=re.DOTALL,
        )
        if not m:
            self.skipTest("_OUTPUT_SECRET_FIELDS not found")
        content = m.group(1)
        for secret in ('auth', 'link_token', 'plaid_access_token'):
            self.assertRegex(
                content, rf"['\"]{re.escape(secret)}['\"]",
                f"_OUTPUT_SECRET_FIELDS missing: {secret} — would render unmasked",
            )

    def test_url_output_fields_list_exists(self):
        self.assertRegex(
            self.mobile_code, r"URL_OUTPUT_FIELDS\s*=\s*\[",
            "URL_OUTPUT_FIELDS list missing",
        )

    def test_is_safe_url_function_present(self):
        """_isSafeUrl gates URL rendering — protocol whitelist."""
        self.assertTrue(
            H.has_function_signature(self.mobile_code, '_isSafeUrl'),
            "_isSafeUrl protocol-whitelist function missing",
        )


class TestServiceFormComponents(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        H.load_ui_sources_or_skip(cls, mobile=True)

    def test_service_action_form_signature(self):
        """_ServiceActionForm({ service, manifest, operation, ... })"""
        # Destructured props — keep regex but operate on stripped code.
        self.assertRegex(
            self.mobile_code,
            r'function\s+_ServiceActionForm\s*\(\s*\{[^}]*service[^}]*manifest[^}]*operation',
            "_ServiceActionForm signature changed — missing service/manifest/operation",
        )

    def test_service_action_result_component(self):
        self.assertRegex(
            self.mobile_code,
            r'function\s+_ServiceActionResult\s*\(\s*\{[^}]*success[^}]*output[^}]*error',
            "_ServiceActionResult signature changed",
        )

    def test_service_status_badge_component(self):
        self.assertRegex(
            self.mobile_code,
            r'function\s+_ServiceStatusBadge\s*\(',
            "_ServiceStatusBadge component missing",
        )

    def test_service_widget_default_mode(self):
        """ServiceWidget mode defaults to 'status'.

        Uses _text — needs to see the literal 'status' string.
        """
        self.assertRegex(
            self.mobile_text,
            r"ServiceWidget\s*\(\s*\{[^}]*mode\s*=\s*['\"]status['\"]",
            "ServiceWidget default mode is not 'status'",
        )


class TestServicesStatusCache(unittest.TestCase):
    """The /v1/services/status fetch + cache layer."""

    @classmethod
    def setUpClass(cls):
        H.load_ui_sources_or_skip(cls, mobile=True)

    def test_status_cache_variables_present(self):
        self.assertRegex(
            self.mobile_code, r'_SERVICES_STATUS_CACHE\b',
            "_SERVICES_STATUS_CACHE missing — status fetches won't cache",
        )
        self.assertRegex(
            self.mobile_code, r'_SERVICES_STATUS_PROMISE\b',
            "_SERVICES_STATUS_PROMISE missing — concurrent fetches won't dedupe",
        )

    def test_fetch_services_status_function(self):
        self.assertTrue(
            H.has_function_signature(self.mobile_code,
                                     '_fetchServicesStatus'),
            "_fetchServicesStatus missing",
        )

    def test_status_reset_hook_exported(self):
        """__superoStatusReset is for tests — must be exported."""
        self.assertRegex(
            self.mobile_code,
            r'export\s+const\s+__superoStatusReset\s*=',
            "__superoStatusReset reset hook not exported (test infrastructure)",
        )


class TestArchetypesAndAliases(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        H.load_ui_sources_or_skip(cls, mobile=True)

    def test_archetypes_object_present(self):
        self.assertRegex(
            self.mobile_code,
            r'(?:const|var|let)\s+_archetypes\s*=\s*\{',
            "_archetypes registry missing",
        )

    def test_backend_id_alias_object_present(self):
        self.assertRegex(
            self.mobile_code,
            r'(?:const|var|let)\s+_BACKEND_ID_ALIAS\s*=\s*\{',
            "_BACKEND_ID_ALIAS missing — backend-id resolution broken",
        )


if __name__ == '__main__':
    unittest.main()
