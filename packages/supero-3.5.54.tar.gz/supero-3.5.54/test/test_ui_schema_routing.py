"""
Batch 2 (v3.1): SuperoSchemaRegistry + routing + scope helpers.

v3.1 changes:
  - Uses self.web_code (comment-stripped) for greps.
  - IIFE arrow-function fallback: detects `(() => {...})()` form too.
    Crucially: if neither IIFE form is found in a present source file,
    setUpClass FAILS HARD instead of silently skipping (would otherwise
    hide zero-coverage on refactor).
"""
from __future__ import annotations
import re
import unittest

import os as _os
import sys as _sys
_sys.path.insert(0, _os.path.join(_os.path.dirname(_os.path.abspath(__file__)), 'ui'))
import _helpers as H


def _registry_iife(src):
    """Body of `var SuperoSchemaRegistry = (function() {...})();` OR
    `var SuperoSchemaRegistry = (() => {...})();`. v3.1 (F3): tries both."""
    body = H.extract_block(
        src,
        r'var\s+SuperoSchemaRegistry\s*=\s*\(function\s*\(\s*\)\s*\{',
        r'\}\s*\)\s*\(\s*\)\s*;',
    )
    if body:
        return body
    # Try arrow IIFE: `var X = (() => {...})();`
    return H.extract_block(
        src,
        r'var\s+SuperoSchemaRegistry\s*=\s*\(\(\s*\)\s*=>\s*\{',
        r'\}\s*\)\s*\(\s*\)\s*;',
    )


def _router_iife(src):
    """Body of `var _router = (function|() =>) (...) {...})();`."""
    body = H.extract_block(
        src,
        r'var\s+_router\s*=\s*\(function\s*\(\s*\)\s*\{',
        r'\}\s*\)\s*\(\s*\)\s*;',
    )
    if body:
        return body
    return H.extract_block(
        src,
        r'var\s+_router\s*=\s*\(\(\s*\)\s*=>\s*\{',
        r'\}\s*\)\s*\(\s*\)\s*;',
    )


# ─────────────────────────────────────────────────────────────────

class TestSchemaRegistry(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        H.load_ui_sources_or_skip(cls, web=True)
        # IIFE detection runs against _text — we need the original string
        # quotes etc. preserved (the IIFE body itself contains string
        # literals like '/api/schemas/describe' that downstream tests check).
        cls.iife = _registry_iife(cls.web_text)
        if not cls.iife:
            raise AssertionError(
                "SuperoSchemaRegistry IIFE not found in source. Either:\n"
                "  (a) the file was refactored to a form we don't recognize\n"
                "      — add a new fallback to _registry_iife()\n"
                "  (b) the registry was renamed or removed — update tests."
            )

    # ── Public surface (per v3.4.0 contract in header comment) ──

    def test_load_function_defined(self):
        self.assertRegex(
            self.iife, r'function\s+load\s*\(\s*\)',
            "SuperoSchemaRegistry.load function missing",
        )

    def test_ready_function_defined(self):
        self.assertRegex(
            self.iife, r'function\s+ready\s*\(\s*\)',
            "SuperoSchemaRegistry.ready function missing",
        )

    def test_get_function_defined(self):
        # F2: allow extra params. Was: function\s+get\s*\(\s*name\s*\)
        self.assertTrue(
            H.has_function_signature(self.iife, 'get', 'name'),
            "SuperoSchemaRegistry.get(name) missing",
        )

    def test_references_function_defined(self):
        self.assertRegex(
            self.iife, r'function\s+references\s*\(',
            "SuperoSchemaRegistry.references function missing",
        )

    # ── Idempotency: load() is safe to call multiple times ──

    def test_load_idempotency_guard_present(self):
        """load() short-circuits via _loadStarted flag.

        Tolerates several forms:
          if (_loadStarted) return ...
          if (_loadStarted === true) return ...
          if (_loadStarted == true) return ...
        """
        self.assertIn(
            "_loadStarted", self.iife,
            "_loadStarted idempotency flag missing in registry",
        )
        # Look for `_loadStarted` followed within ~30 chars by `return`.
        # This tolerates both bare and comparison forms.
        self.assertRegex(
            self.iife,
            r'_loadStarted[^;{}]{0,40}\)\s*return',
            "load() doesn't appear to short-circuit when already loading",
        )

    # ── Empty fallback shape on fetch failure ──

    def test_empty_fallback_has_correct_shape(self):
        """When fetch fails, _cache must have schemas/enums/parent_hierarchy.

        Tolerates several modern JS forms:
          _cache.schemas = {}
          _cache.schemas ||= {}
          _cache.schemas ??= {}
          if (!_cache.schemas) _cache.schemas = {}
        """
        for key in ('schemas', 'enums', 'parent_hierarchy'):
            pat = rf'_cache\.{key}\s*(\?\?=|\|\|=|=)\s*\{{\s*\}}'
            self.assertRegex(
                self.iife, pat,
                f"empty fallback for _cache.{key} missing — fetch-failure "
                f"path could leave cache.{key} undefined",
            )

    def test_fetch_calls_describe_endpoint(self):
        # Need _text — the URL is a string literal that _code would empty out.
        self.assertIn(
            "/api/schemas/describe", self.iife,
            "registry doesn't fetch /api/schemas/describe",
        )

    def test_never_throws_on_fetch_failure(self):
        """Per header comment: fetch failure → resolved with empty payload."""
        self.assertRegex(
            self.iife, r'\.catch\s*\(',
            "registry has no .catch handler — could throw on fetch failure",
        )

    # ── Name normalization ──

    def test_snake_case_helper_exists(self):
        self.assertRegex(
            self.iife, r'function\s+_snake\s*\(',
            "_snake helper missing",
        )

    def test_normalize_handles_fqsn(self):
        """_normalizeName accepts 'ns:name' → strips namespace.

        Uses iife (which is from _text) to preserve the ':' string literal.
        """
        self.assertRegex(
            self.iife,
            r"indexOf\s*\(\s*['\"]:['\"]?\s*\)",
            "FQSN namespace stripping missing in _normalizeName",
        )


class TestRouter(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        H.load_ui_sources_or_skip(cls, web=True)
        cls.iife = _router_iife(cls.web_text)
        if not cls.iife:
            raise AssertionError(
                "_router IIFE not found in source. Either it was refactored "
                "(add fallback to _router_iife()) or removed entirely."
            )

    # ── v3.4.1 scope helpers ──

    def test_router_has_setScope(self):
        # FIX: scope helpers are patched onto _router AFTER the IIFE
        # returns (lines ~408 of supero-ui.js: _router.setScope = ...).
        # The IIFE-only extractor misses them. Check web_code instead.
        self.assertRegex(
            self.web_code, r'_router\.setScope\s*=\s*function',
            "_router.setScope helper missing (v3.4.1 contract)",
        )

    def test_router_has_getScope(self):
        # FIX: see test_router_has_setScope.
        self.assertRegex(
            self.web_code, r'_router\.getScope\s*=\s*function',
            "_router.getScope helper missing (v3.4.1 contract)",
        )

    def test_scope_url_format_supported(self):
        """URL hash query supports `scope=<schema>:<uuid>` format."""
        # FIX: scope handling lives in parseScopeParam/setScope/getScope
        # which are patched onto _router OUTSIDE the IIFE. Check web_code.
        self.assertIn(
            "scope", self.web_code,
            "_router has no 'scope' handling — v3.4.1 URL format broken",
        )

    def test_post_auth_redirect_function(self):
        # F1: search code-stripped src, not raw (avoids comment false-positives).
        self.assertRegex(
            self.web_code, r'function\s+_routerPostAuthRedirect\s*\(',
            "_routerPostAuthRedirect missing",
        )


class TestSchemaQualification(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        H.load_ui_sources_or_skip(cls, web=True)

    def test_qualifySchema_function_exists(self):
        # F2: allow extra params.
        self.assertTrue(
            H.has_function_signature(self.web_code, '_qualifySchema',
                                     'schema'),
            "_qualifySchema missing",
        )

    def test_system_types_object_present(self):
        self.assertRegex(
            self.web_code, r'(?:var|let|const)\s+_SYSTEM_TYPES\s*=\s*\{',
            "_SYSTEM_TYPES object missing",
        )

    def test_app_namespace_normalization(self):
        """_APP_NAMESPACE = ... .toLowerCase().replace(/-/g, '_')

        Uses _text — needs to see the '_' replacement string literal.
        """
        self.assertRegex(
            self.web_text,
            r"_APP_NAMESPACE\s*=.*toLowerCase.*replace.*['\"]_['\"]",
            "_APP_NAMESPACE doesn't normalize hyphens to underscores",
        )


if __name__ == '__main__':
    unittest.main()

# SUPERO_V341_CONTRACT_FIXES_APPLIED
