"""
Unit Tests for SchemaManager v2.0 - Context-Aware Architecture

CHANGES in v2.0:
- NO domain_name parameter in __init__
- NO domain_uuid parameter in methods
- Domain extracted from platform_client automatically
- All methods support api_key parameter for RBAC
"""
import unittest
from unittest.mock import Mock, MagicMock, patch
import sys
import os
import json
import tempfile
import shutil

# Add src to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '../src'))

from supero.schema_manager import SchemaManager
from supero.platform_client import AuthenticationError, AuthorizationError


# ============================================================================
# Mock Platform Client
# ============================================================================

class MockPlatformClient:
    """Mock PlatformClient for testing"""
    
    def __init__(self, domain_name="test-domain", domain_uuid="uuid-123"):
        self.domain_name = domain_name
        self.domain_uuid = domain_uuid
        self.base_url = "http://localhost:8083/api/v1"
        self.call_history = []
        self.responses = {}
        self.project_name = "test-project"
        self.project_uuid = "project-uuid-456"
        self.tenant_name = "test-tenant"
        self.tenant_uuid = "tenant-uuid-789"
        self.user_uuid = "user-uuid-abc"
        self.user_email = "test@example.com"
        self.username = "testuser"
        self.role = "admin"
    
    def set_response(self, method: str, endpoint: str, response: dict):
        """Set mock response for endpoint"""
        key = f"{method}:{endpoint}"
        self.responses[key] = response
    
    def get(self, endpoint: str, params: dict = None, **kwargs):
        """Mock GET request"""
        self.call_history.append({
            "method": "GET",
            "endpoint": endpoint,
            "params": params,
            "kwargs": kwargs
        })
        key = f"GET:{endpoint}"
        if key in self.responses:
            return self.responses[key]
        return {}
    
    def post(self, endpoint: str, json: dict = None, files: dict = None, 
             data: dict = None, **kwargs):
        """Mock POST request"""
        self.call_history.append({
            "method": "POST",
            "endpoint": endpoint,
            "json": json,
            "files": files,
            "data": data,
            "kwargs": kwargs
        })
        key = f"POST:{endpoint}"
        if key in self.responses:
            return self.responses[key]
        return {}
    
    def delete(self, endpoint: str, params: dict = None, **kwargs):
        """Mock DELETE request"""
        self.call_history.append({
            "method": "DELETE",
            "endpoint": endpoint,
            "params": params,
            "kwargs": kwargs
        })
        key = f"DELETE:{endpoint}"
        if key in self.responses:
            return self.responses[key]
        return {"success": True}


# ============================================================================
# Initialization Tests (v2.0)
# ============================================================================

class TestSchemaManagerInit(unittest.TestCase):
    """Test SchemaManager initialization"""
    
    def test_init_extracts_domain_from_client(self):
        """Test initialization extracts domain from platform_client"""
        mock_client = MockPlatformClient(
            domain_name="acme-corp",
            domain_uuid="acme-uuid-123"
        )
        
        # NEW in v2.0: NO domain_name or domain_uuid parameters!
        schema_mgr = SchemaManager(platform_client=mock_client)
        
        # Domain extracted from client
        self.assertEqual(schema_mgr.domain_name, "acme-corp")
        self.assertEqual(schema_mgr.domain_uuid, "acme-uuid-123")
    
    def test_init_with_different_domains(self):
        """Test initialization works with any domain"""
        mock_client = MockPlatformClient(
            domain_name="different-org",
            domain_uuid="different-uuid"
        )
        
        schema_mgr = SchemaManager(platform_client=mock_client)
        
        self.assertEqual(schema_mgr.domain_name, "different-org")
        self.assertEqual(schema_mgr.domain_uuid, "different-uuid")
    
    def test_init_stores_client_reference(self):
        """Test initialization stores client reference"""
        mock_client = MockPlatformClient()
        
        schema_mgr = SchemaManager(platform_client=mock_client)
        
        self.assertIs(schema_mgr.client, mock_client)


# ============================================================================
# Schema Type Detection Tests
# ============================================================================

class TestSchemaManagerDetection(unittest.TestCase):
    """Test schema type detection"""
    
    def setUp(self):
        self.mock_client = MockPlatformClient()
        self.schema_mgr = SchemaManager(platform_client=self.mock_client)
    
    def test_detect_schema_type_objects(self):
        """Test schema type detection for objects"""
        schema_type = self.schema_mgr._detect_schema_type("schemas/objects/project.json")
        self.assertEqual(schema_type, "object")
    
    def test_detect_schema_type_types(self):
        """Test schema type detection for types"""
        schema_type = self.schema_mgr._detect_schema_type("schemas/types/address.json")
        self.assertEqual(schema_type, "type")
    
    def test_detect_schema_type_enums(self):
        """Test schema type detection for enums"""
        schema_type = self.schema_mgr._detect_schema_type("schemas/enums/status.json")
        self.assertEqual(schema_type, "enum")
    
    def test_detect_schema_type_operational(self):
        """Test schema type detection for operational"""
        schema_type = self.schema_mgr._detect_schema_type("schemas/operational/workflow.json")
        self.assertEqual(schema_type, "operational")
    
    def test_detect_schema_type_default(self):
        """Test schema type detection defaults to objects"""
        schema_type = self.schema_mgr._detect_schema_type("some/random/path.json")
        self.assertEqual(schema_type, "object")


# ============================================================================
# Upload Schema Tests (v2.0)
# ============================================================================

class TestSchemaManagerUpload(unittest.TestCase):
    """Test schema upload functionality"""
    
    def setUp(self):
        self.mock_client = MockPlatformClient(
            domain_name="test-domain",
            domain_uuid="domain-uuid-123"
        )
        self.schema_mgr = SchemaManager(platform_client=self.mock_client)
        self.test_dir = tempfile.mkdtemp()
    
    def tearDown(self):
        if os.path.exists(self.test_dir):
            shutil.rmtree(self.test_dir)
    
    def test_upload_schema_no_domain_uuid_parameter(self):
        """Test upload_schema NO LONGER requires domain_uuid parameter"""
        # Create test schema
        schema_data = {
            "name": "Project",
            "parent_type": "domain",
            "attributes": {
                "project_name": {"type": "string", "mandatory": True}
            }
        }
        
        schema_file = os.path.join(self.test_dir, "objects", "project.json")
        os.makedirs(os.path.dirname(schema_file), exist_ok=True)
        with open(schema_file, 'w') as f:
            json.dump(schema_data, f)
        
        # Setup mock response
        self.mock_client.set_response(
            "POST", "/schemas/upload",
            {
                "schemas": [{
                    "schema_uuid": "schema-123",
                    "name": "Project",
                    "schema_type": "objects"
                }],
                "failed": []
            }
        )
        
        # NEW in v2.0: NO domain_uuid parameter!
        result = self.schema_mgr.upload_schema(
            schema_file=schema_file,
            schema_type="objects"
        )
        
        self.assertIn('schema', result)
        self.assertEqual(result['schema']['name'], "Project")
    
    def test_upload_schema_uses_domain_from_client(self):
        """Test upload_schema uses domain from platform_client"""
        schema_data = {
            "name": "Task",
            "parent_type": "project",
            "attributes": {"task_name": {"type": "string"}}
        }
        
        schema_file = os.path.join(self.test_dir, "task.json")
        with open(schema_file, 'w') as f:
            json.dump(schema_data, f)
        
        self.mock_client.set_response(
            "POST", "/schemas/upload",
            {
                "schemas": [{
                    "schema_uuid": "schema-456",
                    "name": "Task"
                }],
                "failed": []
            }
        )
        
        self.schema_mgr.upload_schema(schema_file=schema_file)
        
        # Verify domain_uuid was included in request
        call = self.mock_client.call_history[0]
        self.assertEqual(call['json']['domain_uuid'], "domain-uuid-123")
    
    def test_upload_schema_with_api_key(self):
        """Test upload_schema with api_key parameter for RBAC"""
        schema_data = {
            "name": "User",
            "parent_type": "domain",
            "attributes": {}
        }
        
        schema_file = os.path.join(self.test_dir, "user.json")
        with open(schema_file, 'w') as f:
            json.dump(schema_data, f)
        
        self.mock_client.set_response(
            "POST", "/schemas/upload",
            {"schemas": [{"schema_uuid": "schema-789"}], "failed": []}
        )
        
        # NEW in v2.0: api_key parameter for RBAC
        self.schema_mgr.upload_schema(
            schema_file=schema_file,
            api_key="ak_admin_key_123"
        )
        
        # Verify api_key was passed
        call = self.mock_client.call_history[0]
        self.assertEqual(call['kwargs']['api_key'], "ak_admin_key_123")
    
    def test_upload_schema_auto_detect_type(self):
        """Test schema upload with auto-detected type"""
        schema_data = {
            "name": "Task",
            "parent_type": "project",
            "attributes": {"task_name": {"type": "string"}}
        }
        
        schema_file = os.path.join(self.test_dir, "objects", "task.json")
        os.makedirs(os.path.dirname(schema_file), exist_ok=True)
        with open(schema_file, 'w') as f:
            json.dump(schema_data, f)
        
        self.mock_client.set_response(
            "POST", "/schemas/upload",
            {"schemas": [{"schema_uuid": "schema-456", "name": "Task"}], "failed": []}
        )
        
        # Upload without specifying schema_type
        result = self.schema_mgr.upload_schema(schema_file=schema_file)
        
        self.assertIn('schema', result)
        
        # Should auto-detect as 'object'
        call = self.mock_client.call_history[0]
        self.assertEqual(call['json']['schemas'][0]['schema_type'], "object")
    
    def test_upload_schema_invalid_file(self):
        """Test uploading non-existent file"""
        with self.assertRaises(FileNotFoundError):
            self.schema_mgr.upload_schema(schema_file="nonexistent.json")
    
    def test_upload_schema_non_json_file(self):
        """Test uploading non-JSON file"""
        txt_file = os.path.join(self.test_dir, "schema.txt")
        with open(txt_file, 'w') as f:
            f.write("not json")
        
        with self.assertRaises(ValueError) as ctx:
            self.schema_mgr.upload_schema(schema_file=txt_file)
        
        self.assertIn("JSON format", str(ctx.exception))


# ============================================================================
# Upload Schemas (Directory) Tests (v2.0)
# ============================================================================

class TestSchemaManagerUploadDirectory(unittest.TestCase):
    """Test uploading multiple schemas from directory"""
    
    def setUp(self):
        self.mock_client = MockPlatformClient()
        self.schema_mgr = SchemaManager(platform_client=self.mock_client)
        self.test_dir = tempfile.mkdtemp()
    
    def tearDown(self):
        if os.path.exists(self.test_dir):
            shutil.rmtree(self.test_dir)
    
    def test_upload_schemas_no_domain_uuid_parameter(self):
        """Test upload_schemas NO LONGER requires domain_uuid parameter"""
        # Create test schemas
        schemas_to_create = [
            ("objects/project.json", {
                "name": "Project",
                "parent_type": "domain",
                "attributes": {"project_name": {"type": "string"}}
            }),
            ("objects/task.json", {
                "name": "Task",
                "parent_type": "project",
                "attributes": {"status": {"type": "string"}}
            })
        ]
        
        for path, data in schemas_to_create:
            full_path = os.path.join(self.test_dir, path)
            os.makedirs(os.path.dirname(full_path), exist_ok=True)
            with open(full_path, 'w') as f:
                json.dump(data, f)
        
        self.mock_client.set_response(
            "POST", "/schemas/upload",
            {
                "schemas": [
                    {"schema_uuid": "schema-1", "name": "Project", "schema_type": "objects"},
                    {"schema_uuid": "schema-2", "name": "Task", "schema_type": "objects"}
                ],
                "failed": []
            }
        )
        
        # NEW in v2.0: NO domain_uuid parameter!
        result = self.schema_mgr.upload_schemas(directory=self.test_dir)
        
        total_uploaded = (len(result.get('objects', [])) +
                         len(result.get('types', [])) +
                         len(result.get('enums', [])) +
                         len(result.get('operational', [])))
        
        self.assertEqual(total_uploaded, 2)
    
    def test_upload_schemas_with_api_key(self):
        """Test upload_schemas with api_key"""
        schema_data = {
            "name": "Test",
            "parent_type": "domain",
            "attributes": {}
        }
        
        schema_file = os.path.join(self.test_dir, "objects", "test.json")
        os.makedirs(os.path.dirname(schema_file), exist_ok=True)
        with open(schema_file, 'w') as f:
            json.dump(schema_data, f)
        
        self.mock_client.set_response(
            "POST", "/schemas/upload",
            {"schemas": [{"schema_uuid": "schema-1"}], "failed": []}
        )
        
        # NEW in v2.0: api_key parameter
        self.schema_mgr.upload_schemas(
            directory=self.test_dir,
            api_key="ak_admin_key"
        )
        
        call = self.mock_client.call_history[0]
        self.assertEqual(call['kwargs']['api_key'], "ak_admin_key")


# ============================================================================
# List Schemas Tests (v2.0)
# ============================================================================

class TestSchemaManagerList(unittest.TestCase):
    """Test list_schemas functionality"""
    
    def setUp(self):
        self.mock_client = MockPlatformClient(
            domain_name="test-domain",
            domain_uuid="domain-uuid-123"
        )
        self.schema_mgr = SchemaManager(platform_client=self.mock_client)
    
    def test_list_schemas_no_domain_uuid_parameter(self):
        """Test list_schemas NO LONGER requires domain_uuid parameter"""
        self.mock_client.set_response(
            "GET", "/domains/test-domain/schemas",
            {
                "schemas": [
                    {"uuid": "schema-1", "name": "Project", "schema_type": "objects"},
                    {"uuid": "schema-2", "name": "Task", "schema_type": "objects"}
                ]
            }
        )
        
        # NEW in v2.0: NO domain_uuid parameter!
        schemas = self.schema_mgr.list_schemas()
        
        self.assertEqual(len(schemas), 2)
        self.assertEqual(schemas[0]['name'], "Project")
    
    def test_list_schemas_uses_domain_from_client(self):
        """Test list_schemas uses domain from platform_client"""
        self.mock_client.set_response(
            "GET", "/domains/test-domain/schemas",
            {"schemas": []}
        )
        
        self.schema_mgr.list_schemas()
        
        # Verify correct domain was used
        call = self.mock_client.call_history[0]
        self.assertIn("test-domain", call['endpoint'])
    
    def test_list_schemas_with_api_key(self):
        """Test list_schemas with api_key"""
        self.mock_client.set_response(
            "GET", "/domains/test-domain/schemas",
            {"schemas": []}
        )
        
        # NEW in v2.0: api_key parameter
        self.schema_mgr.list_schemas(api_key="ak_user_key")
        
        call = self.mock_client.call_history[0]
        self.assertEqual(call['kwargs']['api_key'], "ak_user_key")
    
    def test_list_schemas_filtered(self):
        """Test listing schemas with filter"""
        self.mock_client.set_response(
            "GET", "/domains/test-domain/schemas",
            {"schemas": [{"uuid": "schema-1", "name": "Project"}]}
        )
        
        schemas = self.schema_mgr.list_schemas(schema_type="objects")
        
        call = self.mock_client.call_history[0]
        self.assertEqual(call['params']['schema_type'], "object")


# ============================================================================
# Get Schema Tests (v2.0)
# ============================================================================

class TestSchemaManagerGet(unittest.TestCase):
    """Test get_schema functionality"""
    
    def setUp(self):
        self.mock_client = MockPlatformClient()
        self.schema_mgr = SchemaManager(platform_client=self.mock_client)
    
    def test_get_schema(self):
        """Test getting a single schema"""
        self.mock_client.set_response(
            "GET", "/schemas/schema-123",
            {
                "schema_uuid": "schema-123",
                "name": "Project",
                "schema_type": "objects",
                "schema_content": {"name": "Project", "parent_type": "domain"}
            }
        )
        
        schema = self.schema_mgr.get_schema("schema-123")
        
        self.assertEqual(schema['name'], "Project")
        self.assertIn('schema_content', schema)
    
    def test_get_schema_with_api_key(self):
        """Test get_schema with api_key"""
        self.mock_client.set_response(
            "GET", "/schemas/schema-123",
            {"schema_uuid": "schema-123", "name": "Project"}
        )
        
        schema = self.schema_mgr.get_schema("schema-123", api_key="ak_user_key")
        
        call = self.mock_client.call_history[0]
        self.assertEqual(call['kwargs']['api_key'], "ak_user_key")


# ============================================================================
# Delete Schema Tests (v2.0)
# ============================================================================

class TestSchemaManagerDelete(unittest.TestCase):
    """Test delete_schema functionality"""
    
    def setUp(self):
        self.mock_client = MockPlatformClient()
        self.schema_mgr = SchemaManager(platform_client=self.mock_client)
    
    def test_delete_schema(self):
        """Test deleting a schema"""
        self.mock_client.set_response(
            "DELETE", "/schemas/schema-123",
            {"success": True, "message": "Schema deleted"}
        )
        
        result = self.schema_mgr.delete_schema("schema-123")
        
        self.assertTrue(result)
    
    def test_delete_schema_with_api_key(self):
        """Test delete_schema with api_key"""
        self.mock_client.set_response(
            "DELETE", "/schemas/schema-123",
            {"success": True}
        )
        
        self.schema_mgr.delete_schema("schema-123", api_key="ak_admin_key")
        
        call = self.mock_client.call_history[0]
        self.assertEqual(call['kwargs']['api_key'], "ak_admin_key")
    
    def test_delete_schema_with_options(self):
        """Test deleting schema with force and delete_objects options"""
        self.mock_client.set_response(
            "DELETE", "/schemas/schema-123",
            {"success": True}
        )
        
        result = self.schema_mgr.delete_schema(
            "schema-123",
            force_delete=True,
            delete_objects=True
        )
        
        call = self.mock_client.call_history[0]
        self.assertEqual(call['params']['force_delete'], 'true')
        self.assertEqual(call['params']['delete_objects'], 'true')


# ============================================================================
# Export Schemas Tests (v2.0)
# ============================================================================

class TestSchemaManagerExport(unittest.TestCase):
    """Test schema export functionality"""
    
    def setUp(self):
        self.mock_client = MockPlatformClient(
            domain_name="test-domain",
            domain_uuid="domain-uuid-123"
        )
        self.schema_mgr = SchemaManager(platform_client=self.mock_client)
        self.export_dir = tempfile.mkdtemp()
    
    def tearDown(self):
        if os.path.exists(self.export_dir):
            shutil.rmtree(self.export_dir)
    
    def test_export_schemas_no_domain_uuid_parameter(self):
        """Test export_schemas NO LONGER requires domain_uuid parameter"""
        # Mock list_schemas response
        self.mock_client.set_response(
            "GET", "/domains/test-domain/schemas",
            {
                "schemas": [
                    {"uuid": "schema-1", "name": "Project", "schema_type": "objects"}
                ]
            }
        )
        
        # Mock get_schema response
        self.mock_client.set_response(
            "GET", "/schemas/schema-1",
            {
                "schema_uuid": "schema-1",
                "name": "Project",
                "schema_type": "objects",
                "schema_content": {"name": "Project", "parent_type": "domain"}
            }
        )
        
        # NEW in v2.0: NO domain_uuid parameter!
        result = self.schema_mgr.export_schemas(output_directory=self.export_dir)
        
        self.assertEqual(len(result['exported']), 1)
        self.assertEqual(len(result['failed']), 0)
    
    def test_export_schemas_with_api_key(self):
        """Test export_schemas with api_key"""
        self.mock_client.set_response(
            "GET", "/domains/test-domain/schemas",
            {"schemas": [{"uuid": "schema-1", "name": "Project", "schema_type": "objects"}]}
        )
        
        self.mock_client.set_response(
            "GET", "/schemas/schema-1",
            {
                "schema_uuid": "schema-1",
                "name": "Project",
                "schema_content": {"name": "Project"}
            }
        )
        
        result = self.schema_mgr.export_schemas(
            output_directory=self.export_dir,
            api_key="ak_admin_key"
        )
        
        # Verify api_key was used
        for call in self.mock_client.call_history:
            self.assertEqual(call['kwargs']['api_key'], "ak_admin_key")


# ============================================================================
# Validation Tests
# ============================================================================

class TestSchemaManagerValidation(unittest.TestCase):
    """Test schema validation functionality"""
    
    def setUp(self):
        self.mock_client = MockPlatformClient()
        self.schema_mgr = SchemaManager(platform_client=self.mock_client)
    
    def test_basic_validation_valid_object_schema(self):
        """Test basic validation of valid object schema"""
        schema_data = {
            "name": "Project",
            "parent_type": "domain",
            "attributes": {"name": {"type": "string"}}
        }
        
        validation = self.schema_mgr._validate_schema_basic(schema_data, "objects")
        
        self.assertTrue(validation['valid'])
        self.assertEqual(len(validation['errors']), 0)
    
    def test_basic_validation_missing_name(self):
        """Test validation catches missing name"""
        schema_data = {
            "parent_type": "domain",
            "attributes": {}
        }
        
        validation = self.schema_mgr._validate_schema_basic(schema_data, "objects")
        
        self.assertFalse(validation['valid'])
        self.assertIn("'name'", validation['errors'][0])
    
    def test_basic_validation_missing_parent_type(self):
        """Test validation catches missing parent_type for objects"""
        schema_data = {
            "name": "Project",
            "attributes": {}
        }
        
        validation = self.schema_mgr._validate_schema_basic(schema_data, "objects")
        
        self.assertFalse(validation['valid'])
        self.assertIn("parent_type", validation['errors'][0])


# ============================================================================
# Error Handling Tests
# ============================================================================

class TestSchemaManagerErrors(unittest.TestCase):
    """Test error handling"""
    
    def setUp(self):
        self.mock_client = MockPlatformClient()
        self.schema_mgr = SchemaManager(platform_client=self.mock_client)
    
    @patch("os.path.exists", return_value=True)
    def test_upload_schema_authentication_error(self, mock_exists):
        """Test upload_schema with authentication error"""
        # Create temp schema file
        import tempfile
        import os
        with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
            f.write('{"name": "test_schema", "parent_type": "system", "type": "object", "attributes": {}}')
            temp_file = f.name
        
        try:
            def raise_auth_error(*args, **kwargs):
                raise AuthenticationError("Invalid token")
            
            self.mock_client.post = raise_auth_error
            
            with self.assertRaises(AuthenticationError):
                self.schema_mgr.upload_schema(schema_file=temp_file)
        finally:
            os.unlink(temp_file)
    
    def test_list_schemas_authorization_error(self):
        """Test list_schemas with authorization error"""
        def raise_authz_error(*args, **kwargs):
            raise AuthorizationError("Permission denied")
        
        self.mock_client.get = raise_authz_error
        
        with self.assertRaises(AuthorizationError):
            self.schema_mgr.list_schemas()


# ============================================================================
# Integration Tests (v2.0)
# ============================================================================

class TestSchemaManagerIntegration(unittest.TestCase):
    """Integration tests for SchemaManager"""
    
    def setUp(self):
        self.mock_client = MockPlatformClient(
            domain_name="acme-corp",
            domain_uuid="acme-uuid"
        )
        self.schema_mgr = SchemaManager(platform_client=self.mock_client)
        self.test_dir = tempfile.mkdtemp()
    
    def tearDown(self):
        if os.path.exists(self.test_dir):
            shutil.rmtree(self.test_dir)
    
    def test_complete_schema_lifecycle(self):
        """Test complete schema lifecycle"""
        # Create schema file
        schema_data = {
            "name": "Project",
            "parent_type": "domain",
            "attributes": {"project_name": {"type": "string"}}
        }
        
        schema_file = os.path.join(self.test_dir, "project.json")
        with open(schema_file, 'w') as f:
            json.dump(schema_data, f)
        
        # Upload
        self.mock_client.set_response(
            "POST", "/schemas/upload",
            {"schemas": [{"schema_uuid": "new-uuid", "name": "Project"}], "failed": []}
        )
        
        result = self.schema_mgr.upload_schema(schema_file=schema_file)
        
        self.assertEqual(result['schema']['name'], "Project")
        
        # List
        self.mock_client.set_response(
            "GET", "/domains/acme-corp/schemas",
            {"schemas": [{"uuid": "new-uuid", "name": "Project"}]}
        )
        
        schemas = self.schema_mgr.list_schemas()
        
        self.assertEqual(len(schemas), 1)
        
        # Delete
        self.mock_client.set_response(
            "DELETE", "/schemas/new-uuid",
            {"success": True}
        )
        
        deleted = self.schema_mgr.delete_schema("new-uuid")
        
        self.assertTrue(deleted)


if __name__ == '__main__':
    unittest.main(verbosity=2)
