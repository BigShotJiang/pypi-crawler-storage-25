"""Unit tests for AppSetup._persist_env_var.

The method writes KEY="VALUE" to .env in the current working directory,
idempotently (no-op if already correct, update if different, append if
missing). Also sets os.environ so the current process picks up the
value without restart.

These tests focus on the file-writing behavior — they construct a
minimal AppSetup-like object with just the attributes the helper
uses (none — it only touches filesystem + os.environ).
"""
import os
import sys
import tempfile
import unittest


def _get_persist_method():
    """Import AppSetup and return its _persist_env_var method unbound."""
    import importlib
    mod = importlib.import_module("supero.app_setup")
    return mod.AppSetup._persist_env_var


class _EnvIsolation:
    """Snapshot + restore os.environ around a test (same pattern as
    test_cli_env_manager.py)."""

    def __init__(self, keys_to_clear=None):
        self.snapshot = {}
        self.keys_to_clear = keys_to_clear or []

    def __enter__(self):
        self.snapshot = os.environ.copy()
        for k in self.keys_to_clear:
            os.environ.pop(k, None)
        return self

    def __exit__(self, *args):
        current_keys = set(os.environ.keys())
        original_keys = set(self.snapshot.keys())
        for k in current_keys - original_keys:
            os.environ.pop(k, None)
        for k, v in self.snapshot.items():
            os.environ[k] = v


class _FakeAppSetup:
    """Minimal stand-in — _persist_env_var only uses self (for method
    binding) and doesn't touch any instance attributes."""


class PersistEnvVarTests(unittest.TestCase):
    """Tests for AppSetup._persist_env_var."""

    def setUp(self):
        self.persist = _get_persist_method()
        self.tmpdir = tempfile.mkdtemp(prefix="persist-env-")
        self.env_path = os.path.join(self.tmpdir, ".env")
        self.original_cwd = os.getcwd()
        os.chdir(self.tmpdir)
        self.isolation = _EnvIsolation([
            "SUPERO_PROJECT_UUID", "TEST_KEY", "NEW_KEY",
        ])
        self.isolation.__enter__()

    def tearDown(self):
        os.chdir(self.original_cwd)
        self.isolation.__exit__()
        import shutil
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def _invoke(self, key, value):
        """Call the unbound method with a fake instance."""
        self.persist(_FakeAppSetup(), key, value)

    def _read_env(self):
        if not os.path.exists(self.env_path):
            return None
        with open(self.env_path) as f:
            return f.read()

    # ── Empty / edge cases ─────────────────────────────────────

    def test_no_op_when_value_empty(self):
        """Empty value does NOT write anything."""
        with open(self.env_path, "w") as f:
            f.write('EXISTING="x"\n')
        self._invoke("TEST_KEY", "")
        self.assertEqual(self._read_env(), 'EXISTING="x"\n')
        self.assertNotIn("TEST_KEY", os.environ)

    def test_no_op_when_value_none(self):
        """None value does NOT write anything."""
        with open(self.env_path, "w") as f:
            f.write('EXISTING="x"\n')
        self._invoke("TEST_KEY", None)
        self.assertEqual(self._read_env(), 'EXISTING="x"\n')

    def test_no_op_when_env_file_missing(self):
        """Missing .env file means nothing to persist into; don't create."""
        self.assertFalse(os.path.exists(self.env_path))
        self._invoke("TEST_KEY", "some-value")
        # Helper should NOT create a new .env (it only edits existing ones)
        self.assertFalse(os.path.exists(self.env_path))

    # ── Append cases ───────────────────────────────────────────

    def test_appends_when_key_missing(self):
        """Key not in .env is appended at end."""
        with open(self.env_path, "w") as f:
            f.write('SUPERO_DOMAIN="test"\n')
        self._invoke("SUPERO_PROJECT_UUID", "abc-123")
        content = self._read_env()
        self.assertIn('SUPERO_DOMAIN="test"', content)
        self.assertIn('SUPERO_PROJECT_UUID="abc-123"', content)
        # Original line is untouched
        self.assertTrue(content.startswith('SUPERO_DOMAIN="test"'))

    def test_sets_os_environ_when_writing(self):
        """After write, os.environ[key] is also set."""
        with open(self.env_path, "w") as f:
            f.write('SUPERO_DOMAIN="test"\n')
        self._invoke("SUPERO_PROJECT_UUID", "abc-123")
        self.assertEqual(os.environ.get("SUPERO_PROJECT_UUID"), "abc-123")

    def test_appends_adds_trailing_newline_if_missing(self):
        """If .env lacks a trailing newline, one is added before append."""
        with open(self.env_path, "w") as f:
            f.write('SUPERO_DOMAIN="test"')  # no trailing \n
        self._invoke("NEW_KEY", "value")
        content = self._read_env()
        # Should have both entries on separate lines
        self.assertIn('SUPERO_DOMAIN="test"\n', content)
        self.assertIn('NEW_KEY="value"', content)

    # ── Update cases ───────────────────────────────────────────

    def test_updates_existing_key_with_different_value(self):
        """Existing key gets replaced in-place when value differs."""
        with open(self.env_path, "w") as f:
            f.write('SUPERO_PROJECT_UUID="old-uuid"\nOTHER="x"\n')
        self._invoke("SUPERO_PROJECT_UUID", "new-uuid")
        content = self._read_env()
        self.assertIn('SUPERO_PROJECT_UUID="new-uuid"', content)
        self.assertNotIn("old-uuid", content)
        self.assertIn('OTHER="x"', content)  # other lines preserved

    def test_update_preserves_line_order(self):
        """Replacing an existing key doesn't move it to end of file."""
        with open(self.env_path, "w") as f:
            f.write('FIRST="a"\nSUPERO_PROJECT_UUID="old"\nLAST="z"\n')
        self._invoke("SUPERO_PROJECT_UUID", "new")
        content = self._read_env()
        first_pos = content.find('FIRST="a"')
        uuid_pos = content.find('SUPERO_PROJECT_UUID="new"')
        last_pos = content.find('LAST="z"')
        self.assertTrue(0 <= first_pos < uuid_pos < last_pos)

    # ── Idempotence ────────────────────────────────────────────

    def test_idempotent_when_already_quoted(self):
        """Calling twice with same value doesn't duplicate the line."""
        with open(self.env_path, "w") as f:
            f.write('SUPERO_DOMAIN="test"\n')
        self._invoke("SUPERO_PROJECT_UUID", "abc-123")
        content_after_first = self._read_env()
        self._invoke("SUPERO_PROJECT_UUID", "abc-123")
        content_after_second = self._read_env()
        self.assertEqual(content_after_first, content_after_second)
        # Verify only one occurrence
        self.assertEqual(content_after_second.count("SUPERO_PROJECT_UUID"), 1)

    def test_idempotent_with_unquoted_existing_value(self):
        """No-op if value present in UNQUOTED form (KEY=value without quotes)."""
        with open(self.env_path, "w") as f:
            # Some legacy .env files have no quotes
            f.write('SUPERO_PROJECT_UUID=abc-123\n')
        self._invoke("SUPERO_PROJECT_UUID", "abc-123")
        content = self._read_env()
        # Should leave the unquoted form alone (no change)
        self.assertEqual(content, 'SUPERO_PROJECT_UUID=abc-123\n')
        # But still sets os.environ
        self.assertEqual(os.environ.get("SUPERO_PROJECT_UUID"), "abc-123")

    def test_second_call_updates_not_appends(self):
        """If value changes, replace — don't append a second line."""
        with open(self.env_path, "w") as f:
            f.write('SUPERO_DOMAIN="test"\n')
        self._invoke("SUPERO_PROJECT_UUID", "first-uuid")
        self._invoke("SUPERO_PROJECT_UUID", "second-uuid")
        content = self._read_env()
        # Only one SUPERO_PROJECT_UUID line, with the new value
        self.assertEqual(content.count("SUPERO_PROJECT_UUID"), 1)
        self.assertIn("second-uuid", content)
        self.assertNotIn("first-uuid", content)

    # ── Special characters ────────────────────────────────────

    def test_value_with_special_chars(self):
        """Values with hyphens, dots, etc. are written correctly."""
        with open(self.env_path, "w") as f:
            f.write('DOMAIN="x"\n')
        uuid_val = "b9ca02cd-e564-42df-b428-22b2d991f93e"
        self._invoke("SUPERO_PROJECT_UUID", uuid_val)
        content = self._read_env()
        self.assertIn(f'SUPERO_PROJECT_UUID="{uuid_val}"', content)
        self.assertEqual(os.environ.get("SUPERO_PROJECT_UUID"), uuid_val)


if __name__ == "__main__":
    unittest.main()
