"""
Tests for Supero Direct Schema Access v2.0 (__getattr__ and __dir__)
Tests the clean API: org.Project instead of org.schemas.Project

UPDATED for v2.0:
- Compatible with context-aware architecture
- No changes needed (tests Supero core API, not managers)
- All tests validate direct schema access patterns

Coverage:
- Direct schema access (org.Schema)
- __dir__ for autocomplete
- SchemaProxy functionality
- Error handling and edge cases
- Backward compatibility
"""

import unittest
from unittest.mock import Mock, MagicMock, patch
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '../src'))

from supero import Supero, quickstart, SchemaProxy


# ============================================================================
# Helper Functions
# ============================================================================

def create_mock_load_lib_return(mock_api=None):
    """Helper to create standard mock return value for _load_py_api_lib_for_domain."""
    if mock_api is None:
        mock_api = MagicMock()
    return (
        MagicMock(return_value=mock_api),  # ApiLib class
        ['pymodel_system'],  # SCHEMA_NAMESPACES
        'pymodel_system',    # PRIMARY_SCHEMA_NAMESPACE
        None,                # TENANT_NAMESPACE
        'py_api_lib'         # package name
    )


def create_supero_with_mocks(domain_name="test-corp", mock_api=None):
    """
    Helper to create Supero instance with all required mocks.
    Returns (org, mock_api) tuple.
    
    CRITICAL: The mock for _load_existing_domain must SET _domain_obj,
    otherwise the check `if not self._domain_obj` will raise ValueError.
    """
    if mock_api is None:
        mock_api = MagicMock()
    
    def mock_load_existing_domain(self):
        """Mock that sets _domain_obj to avoid ValueError."""
        self._domain_obj = MagicMock()
        self._domain_uuid = f'{domain_name}-uuid-123'
    
    with patch('supero.core._load_py_api_lib_for_domain') as mock_load_lib:
        mock_load_lib.return_value = create_mock_load_lib_return(mock_api)
        
        with patch.object(Supero, '_ensure_domain'):
            with patch.object(Supero, '_load_existing_domain', mock_load_existing_domain):
                org = Supero(domain_name=domain_name)
                return org, mock_api


class SuperoTestCase(unittest.TestCase):
    """Base test class with mocked _ensure_domain and _load_existing_domain."""

    def setUp(self):
        """Setup test fixtures."""
        self.org, self.mock_api = create_supero_with_mocks("test-corp")


# ============================================================================
# Direct Schema Access Tests
# ============================================================================

class TestDirectSchemaAccess(SuperoTestCase):
    """Test direct schema access via __getattr__."""
    
    def test_direct_schema_access_returns_proxy(self):
        """Test that org.SchemaName returns a SchemaProxy."""
        with patch.object(self.org, '_list_schemas', return_value=['Project', 'User']):
            result = self.org.Project
            
            self.assertIsNotNone(result)
            self.assertEqual(result._display_name, 'Project')
            self.assertEqual(result._schema_name, 'project')
    
    def test_direct_schema_access_case_sensitive(self):
        """Test exact case match for schema names."""
        with patch.object(self.org, '_list_schemas', return_value=['Project', 'User']):
            result = self.org.Project
            self.assertIsNotNone(result)
            self.assertEqual(result._schema_name, 'project')
            self.assertEqual(result._display_name, 'Project')
            self.assertIsInstance(result, SchemaProxy)
    
    def test_direct_schema_access_case_insensitive(self):
        """Test that snake_case is rejected with helpful error."""
        with patch.object(self.org, '_list_schemas', return_value=['Project']):
            with self.assertRaises(AttributeError) as ctx:
                _ = self.org.project

            error_msg = str(ctx.exception)
            self.assertIn('CamelCase', error_msg)
            self.assertIn('Project', error_msg)
    
    def test_direct_schema_access_nonexistent_schema(self):
        """Test accessing non-existent schema gives helpful error."""
        with patch.object(self.org, '_list_schemas', return_value=['Project', 'User']):
            with self.assertRaises(AttributeError) as ctx:
                _ = self.org.NonExistentSchema
            
            error_msg = str(ctx.exception)
            self.assertIn('not found', error_msg)
            self.assertIn('Available schemas', error_msg)
    
    def test_direct_schema_access_private_attribute(self):
        """Test that private attributes raise proper error."""
        with self.assertRaises(AttributeError) as cm:
            _ = self.org._some_private_attr
        
        error_msg = str(cm.exception)
        self.assertIn('_some_private_attr', error_msg)
    
    def test_direct_schema_access_known_attributes(self):
        """Test that known Supero attributes don't get intercepted."""
        self.assertIsNotNone(self.org.domain_name)
        self.assertIsNotNone(self.org.logger)
        self.assertIsNotNone(self.org.schemas)
    
    def test_direct_schema_access_error_message_suggestions(self):
        """Test that error messages provide helpful suggestions."""
        schemas = ['Project', 'User', 'Task', 'Team', 'Domain']
        with patch.object(self.org, '_list_schemas', return_value=schemas):
            with self.assertRaises(AttributeError) as ctx:
                _ = self.org.InvalidSchema
            
            error_msg = str(ctx.exception)
            self.assertIn('not found', error_msg)
            self.assertIn('Available schemas', error_msg)

    def test_direct_schema_access_multiple_schemas(self):
        """Test accessing multiple schemas."""
        schemas = ['Project', 'User', 'Task', 'Team', 'Domain']
        with patch.object(self.org, '_list_schemas', return_value=schemas):
            project_proxy = self.org.Project
            user_proxy = self.org.User
            
            # Check normalized internal name
            self.assertEqual(project_proxy._schema_name, 'project')
            self.assertEqual(user_proxy._schema_name, 'user')
            
            # Display name should be CamelCase
            self.assertEqual(project_proxy._display_name, 'Project')
            self.assertEqual(user_proxy._display_name, 'User')

    def test_direct_schema_access_schema_discovery_fails(self):
        """Test behavior when schema discovery fails."""
        with patch.object(self.org, '_list_schemas', side_effect=Exception("Discovery failed")):
            with self.assertRaises(AttributeError):
                _ = self.org.Project


# ============================================================================
# Direct Access Method Tests
# ============================================================================

class TestDirectSchemaAccessMethods(SuperoTestCase):
    """Test that schema methods work through direct access."""
    
    def test_direct_access_count_method(self):
        """Test org.Schema.count() works."""
        with patch.object(self.org, '_list_schemas', return_value=['Project']):
            proxy = self.org.Project
            
            self.assertTrue(hasattr(proxy, 'count'))
            
            result = proxy.count()
            self.assertEqual(result, 0)
    
    def test_direct_access_find_method(self):
        """Test org.Schema.find() works."""
        with patch.object(self.org, '_list_schemas', return_value=['Project']):
            proxy = self.org.Project
            
            self.assertTrue(hasattr(proxy, 'find'))
            
            result = proxy.find(status="active")
            self.assertEqual(result, [])
    
    def test_direct_access_all_method(self):
        """Test org.Schema.all() works."""
        with patch.object(self.org, '_list_schemas', return_value=['Project']):
            proxy = self.org.Project
            
            self.assertTrue(hasattr(proxy, 'all'))
            
            result = proxy.all()
            self.assertEqual(result, [])
    
    def test_direct_access_get_method(self):
        """Test org.Schema.get() works."""
        with patch.object(self.org, '_list_schemas', return_value=['Project']):
            proxy = self.org.Project
            
            self.assertTrue(hasattr(proxy, 'get'))
            
            result = proxy.get('some-uuid')
            self.assertIsNone(result)


# ============================================================================
# Method Chaining Tests
# ============================================================================

class TestDirectSchemaAccessChaining(SuperoTestCase):
    """Test method chaining with direct schema access."""
    
    def test_chained_method_calls(self):
        """Test chaining: org.Project.find().count()"""
        with patch.object(self.org, '_list_schemas', return_value=['Project']):
            proxy = self.org.Project
            
            result = proxy.find(status="active")
            
            count = len(result)
            self.assertEqual(count, 0)
    
    def test_multiple_sequential_accesses(self):
        """Test multiple separate accesses."""
        schemas = ['Project', 'User', 'Task']

        with patch.object(self.org, '_list_schemas', return_value=schemas):
            project_proxy = self.org.Project
            user_proxy = self.org.User
            task_proxy = self.org.Task

            # Mock the count() method
            project_proxy.count = MagicMock(return_value=0)
            user_proxy.count = MagicMock(return_value=0)
            task_proxy.count = MagicMock(return_value=0)

            # Test
            project_count = project_proxy.count()
            user_count = user_proxy.count()
            task_count = task_proxy.count()

            self.assertEqual(project_count, 0)
            self.assertEqual(user_count, 0)
            self.assertEqual(task_count, 0)


# ============================================================================
# __dir__ Autocomplete Tests
# ============================================================================

class TestDirAutocompletion(SuperoTestCase):
    """Test __dir__ for IDE autocomplete support."""
    
    def test_dir_includes_schemas(self):
        """Test that dir() includes schema names."""
        schemas = ['Project', 'User', 'Task']
        with patch.object(self.org, '_list_schemas', return_value=schemas):
            result = dir(self.org)
            
            self.assertIn('Project', result)
            self.assertIn('User', result)
            self.assertIn('Task', result)
    
    def test_dir_includes_supero_attributes(self):
        """Test that dir() includes Supero attributes."""
        schemas = ['Project']
        with patch.object(self.org, '_list_schemas', return_value=schemas):
            result = dir(self.org)
            
            self.assertIn('domain_name', result)
            self.assertIn('schemas', result)
            self.assertIn('save', result)
            self.assertIn('delete', result)
    
    def test_dir_returns_sorted_list(self):
        """Test that dir() returns sorted list."""
        schemas = ['Project', 'User', 'Task']
        with patch.object(self.org, '_list_schemas', return_value=schemas):
            result = dir(self.org)
            
            self.assertEqual(result, sorted(result))
    
    def test_dir_deduplicates(self):
        """Test that dir() doesn't have duplicates."""
        schemas = ['Project', 'User']
        with patch.object(self.org, '_list_schemas', return_value=schemas):
            result = dir(self.org)
            
            self.assertEqual(len(result), len(set(result)))
    
    def test_dir_when_schema_discovery_fails(self):
        """Test dir() when schema discovery fails."""
        with patch.object(self.org, '_list_schemas', side_effect=Exception("Failed")):
            result = dir(self.org)
            
            self.assertIsInstance(result, list)
            self.assertGreater(len(result), 0)
    
    def test_dir_with_many_schemas(self):
        """Test dir() with many schemas."""
        schemas = [f'Schema{i}' for i in range(100)]
        with patch.object(self.org, '_list_schemas', return_value=schemas):
            result = dir(self.org)
            
            for schema in schemas:
                self.assertIn(schema, result)


# ============================================================================
# Real-World Use Case Tests
# ============================================================================

class TestDirectAccessUseCases(unittest.TestCase):
    """Test real-world use cases with direct schema access."""
    
    def setUp(self):
        """Setup with different domain name."""
        self.org, self.mock_api = create_supero_with_mocks("acme-corp")

    def test_status_report_use_case(self):
        """Test status report pattern from documentation."""
        schemas = ['Project', 'Task']
        with patch.object(self.org, '_list_schemas', return_value=schemas):
            proxy = self.org.Project

            proxy.count = MagicMock(return_value=0)

            active = proxy.count(status="active")
            completed = proxy.count(status="completed")

            self.assertEqual(active, 0)
            self.assertEqual(completed, 0)
    
    def test_multiple_schema_access(self):
        """Test accessing multiple different schemas in one flow."""
        schemas = ['Project', 'User', 'Task']
        
        with patch.object(self.org, '_list_schemas', return_value=schemas):
            with patch.object(self.org, 'get_schema') as mock_get_schema:
                mock_project = MagicMock()
                mock_user = MagicMock()
                mock_task = MagicMock()
                
                def get_schema_side_effect(name):
                    schema_map = {
                        'project': mock_project,
                        'user': mock_user,
                        'task': mock_task
                    }
                    return schema_map.get(name, MagicMock())
                
                mock_get_schema.side_effect = get_schema_side_effect
                
                project_proxy = self.org.Project
                user_proxy = self.org.User
                task_proxy = self.org.Task
                
                self.assertEqual(project_proxy._schema_name, 'project')
                self.assertEqual(user_proxy._schema_name, 'user')
                self.assertEqual(task_proxy._schema_name, 'task')
                
                self.assertEqual(project_proxy._display_name, 'Project')
                self.assertEqual(user_proxy._display_name, 'User')
                self.assertEqual(task_proxy._display_name, 'Task')
    
    def test_old_vs_new_api_equivalence(self):
        """Test that org.Schema and org.schemas.Schema are equivalent."""
        schemas = ['Project']
        with patch.object(self.org, '_list_schemas', return_value=schemas):
            old_proxy = self.org.schemas.Project
            new_proxy = self.org.Project
            
            self.assertEqual(old_proxy._schema_name, new_proxy._schema_name)


# ============================================================================
# Edge Case Tests
# ============================================================================

class TestDirectAccessEdgeCases(SuperoTestCase):
    """Test edge cases for direct schema access."""
    
    def test_schema_name_conflicts_with_method(self):
        """Test that known methods take precedence over schemas."""
        schemas = ['Project', 'save']
        with patch.object(self.org, '_list_schemas', return_value=schemas):
            self.assertTrue(callable(self.org.save))
    
    def test_schema_with_special_characters(self):
        """Test schema names with special characters."""
        schemas = ['Project-API', 'User_Account']
        with patch.object(self.org, '_list_schemas', return_value=schemas):
            result = dir(self.org)
            self.assertIn('Project-API', result)
            self.assertIn('User_Account', result)
    
    def test_very_long_schema_name(self):
        """Test very long schema name."""
        long_name = 'A' * 1000
        schemas = ['Project', long_name]
        with patch.object(self.org, '_list_schemas', return_value=schemas):
            result = dir(self.org)
            self.assertIn(long_name, result)


# ============================================================================
# Quickstart Integration Tests
# ============================================================================

class TestDirectAccessWithQuickstart(unittest.TestCase):
    """Test direct access with quickstart() function."""
    
    def test_quickstart_direct_access(self):
        """Test direct access works with quickstart."""
        def mock_load(self):
            self._domain_obj = MagicMock()
            self._domain_uuid = 'test-uuid-123'
        
        with patch('supero.core._load_py_api_lib_for_domain') as mock_load_lib:
            mock_load_lib.return_value = create_mock_load_lib_return()

            with patch.object(Supero, '_ensure_domain'):
                with patch.object(Supero, '_load_existing_domain', mock_load):
                    org = quickstart("test-corp")

                    with patch.object(org, '_list_schemas', return_value=['Project']):
                        proxy = org.Project
                        self.assertIsNotNone(proxy)

    def test_quickstart_dir_autocomplete(self):
        """Test dir() works with quickstart."""
        def mock_load(self):
            self._domain_obj = MagicMock()
            self._domain_uuid = 'test-uuid-123'
        
        with patch('supero.core._load_py_api_lib_for_domain') as mock_load_lib:
            mock_load_lib.return_value = create_mock_load_lib_return()

            with patch.object(Supero, '_ensure_domain'):
                with patch.object(Supero, '_load_existing_domain', mock_load):
                    org = quickstart("test-corp")

                    with patch.object(org, '_list_schemas', return_value=['Project', 'User']):
                        result = dir(org)

                        self.assertIn('Project', result)
                        self.assertIn('User', result)


# ============================================================================
# Backward Compatibility Tests
# ============================================================================

class TestDirectAccessBackwardCompatibility(SuperoTestCase):
    """Test backward compatibility with org.schemas.Project syntax."""

    def test_old_api_still_works(self):
        """Test that org.schemas.Project still works for backward compatibility."""
        with patch.object(self.org, '_list_schemas', return_value=['Project']):
            proxy = self.org.schemas.Project

            self.assertEqual(proxy._schema_name, 'project')
            self.assertEqual(proxy._display_name, 'Project')
            self.assertIsInstance(proxy, SchemaProxy)

    def test_both_apis_work_together(self):
        """Test that both old and new APIs can be used in same code."""
        with patch.object(self.org, '_list_schemas', return_value=['Project', 'User']):
            new_proxy = self.org.Project
            old_proxy = self.org.schemas.Project

            self.assertEqual(new_proxy._schema_name, 'project')
            self.assertEqual(old_proxy._schema_name, 'project')

            self.assertEqual(new_proxy._display_name, 'Project')
            self.assertEqual(old_proxy._display_name, 'Project')

            with patch.object(self.org, 'get_schema') as mock_get_schema:
                mock_schema = MagicMock()
                mock_get_schema.return_value = mock_schema

                user_proxy_new = self.org.User
                user_proxy_old = self.org.schemas.User

                self.assertEqual(user_proxy_new._schema_name, 'user')
                self.assertEqual(user_proxy_old._schema_name, 'user')


if __name__ == '__main__':
    unittest.main(verbosity=2)
