"""
Batch 1 (v3.1): Public API surface tests for supero-ui.js and supero-mobile.jsx.

v3.1 changes:
  - Uses self.web_code / self.mobile_code (comment-stripped) for greps,
    so a TODO comment mentioning a method doesn't false-positive.
  - Signature checks allow extra trailing params (no false alarms when
    optional params are added).
  - Class regex tolerates `extends X`.
  - Singleton check accepts var/let/const.
  - Formatter regex accepts var/const + function/arrow.
  - export default <kind> handled via H.has_named_export.
"""
from __future__ import annotations
import re
import unittest

import os as _os
import sys as _sys
_sys.path.insert(0, _os.path.join(_os.path.dirname(_os.path.abspath(__file__)), 'ui'))
import _helpers as H


# ─────────────────────────────────────────────────────────────────
# Web public surface
# ─────────────────────────────────────────────────────────────────

class TestWebPublicSurface(unittest.TestCase):
    """supero-ui.js public API contract."""

    @classmethod
    def setUpClass(cls):
        H.load_ui_sources_or_skip(cls, web=True)

    # ── SuperoClient class surface ──

    def test_supero_client_class_exists(self):
        body = H.class_body(self.web_code, 'SuperoClient')
        self.assertIsNotNone(body, "SuperoClient class declaration not found")

    def test_supero_client_has_init(self):
        body = H.class_body(self.web_code, 'SuperoClient')
        self.assertTrue(H.has_method(body, 'init'),
                        "SuperoClient.init missing")

    def test_supero_client_has_crud_methods(self):
        body = H.class_body(self.web_code, 'SuperoClient')
        for method in ('get', 'list', 'create', 'update', 'delete'):
            self.assertTrue(H.has_method(body, method),
                            f"SuperoClient.{method} missing")

    def test_supero_client_has_auth_methods(self):
        body = H.class_body(self.web_code, 'SuperoClient')
        for method in ('login', 'logout', 'signup'):
            self.assertTrue(H.has_method(body, method),
                            f"SuperoClient.{method} missing")

    def test_supero_client_has_getScopedList_v110(self):
        """v1.1.0 added getScopedList(parent_schema, parent_uuid, record_schema)."""
        body = H.class_body(self.web_code, 'SuperoClient')
        self.assertTrue(
            H.has_method(body, 'getScopedList',
                         'parent_schema', 'parent_uuid', 'record_schema'),
            "SuperoClient.getScopedList missing or signature changed",
        )

    def test_supero_client_has_linkReference_v110(self):
        """v1.1.0 added linkReference(source_type, source_uuid, ref_name, ref_uuid, operation)."""
        body = H.class_body(self.web_code, 'SuperoClient')
        self.assertTrue(
            H.has_method(body, 'linkReference',
                         'source_type', 'source_uuid', 'ref_name',
                         'ref_uuid', 'operation'),
            "SuperoClient.linkReference missing or signature changed",
        )

    def test_supero_client_singleton_instantiated(self):
        """Module-level `client = new SuperoClient()` (var/let/const)."""
        self.assertRegex(
            self.web_code,
            r'(?:var|let|const)\s+client\s*=\s*new\s+SuperoClient\s*\(\s*\)',
            "client singleton not instantiated",
        )

    # ── Window globals (header "do NOT redeclare" contract) ──

    def test_window_supero_schema_registry_exposed(self):
        self.assertRegex(
            self.web_code, r'window\.SuperoSchemaRegistry\s*=',
            "window.SuperoSchemaRegistry not exposed",
        )

    def test_window_reference_dropdowns_exposed(self):
        self.assertRegex(
            self.web_code, r'window\.ReferenceDropdowns\s*=',
            "window.ReferenceDropdowns not exposed",
        )

    def test_window_slide_over_form_exposed(self):
        self.assertRegex(
            self.web_code, r'window\.SlideOverForm\s*=',
            "window.SlideOverForm not exposed",
        )

    def test_window_invoice_pay_panel_exposed(self):
        self.assertRegex(
            self.web_code, r'window\.InvoicePayPanel\s*=',
            "window.InvoicePayPanel not exposed",
        )

    # ── Formatter exports ──

    def test_formatters_all_defined(self):
        """Formatters from header 'do NOT redeclare' must exist.

        Accepts both `var X = function` and `const X = (...) =>`.
        """
        formatters = [
            'formatCurrency', 'formatNumber', 'formatDate',
            'formatDateTime', 'formatRelativeTime', 'formatFieldValue',
        ]
        missing = []
        for name in formatters:
            # Accept: (var|let|const) X = (function|arrow)
            pat = (rf'(?:var|let|const)\s+{re.escape(name)}\s*=\s*'
                   r'(?:function|\([^)]*\)\s*=>|[A-Za-z_]\w*\s*=>)')
            if not re.search(pat, self.web_code):
                missing.append(name)
        self.assertFalse(
            missing,
            f"formatters missing or definition style unrecognized: {missing}",
        )

    def test_resolveImageUrl_defined(self):
        self.assertTrue(
            H.has_function_signature(self.web_code, 'resolveImageUrl'),
            "resolveImageUrl not defined",
        )

    # ── fileService singleton ──

    def test_file_service_object_exists(self):
        self.assertRegex(
            self.web_code,
            r'(?:var|let|const)\s+fileService\s*=\s*\{',
            "fileService object not declared",
        )

    # ── App config defaults ──

    def test_supero_config_defaults(self):
        """SUPERO_CONFIG has documented defaults for missing keys.

        Uses web_text (string contents preserved) because we need to
        verify the literal default values 'app' and 'app-project'.
        """
        self.assertRegex(
            self.web_text,
            r"SUPERO_CONFIG\.domain\s*\|\|\s*['\"]app['\"]",
            "domain default 'app' missing",
        )
        self.assertRegex(
            self.web_text,
            r"SUPERO_CONFIG\.project\s*\|\|\s*['\"]app-project['\"]",
            "project default 'app-project' missing",
        )


# ─────────────────────────────────────────────────────────────────
# Mobile public surface
# ─────────────────────────────────────────────────────────────────

class TestMobilePublicSurface(unittest.TestCase):
    """supero-mobile.jsx named exports contract."""

    @classmethod
    def setUpClass(cls):
        H.load_ui_sources_or_skip(cls, mobile=True)

    # ── Named exports listed in the header "Provides:" line ──
    # All checks use H.has_named_export which handles `export default` too.

    def test_export_supero_client_class(self):
        self.assertTrue(
            H.has_named_export(self.mobile_code, 'class', 'SuperoClient'),
            "export class SuperoClient missing",
        )

    def test_export_client_singleton(self):
        self.assertRegex(
            self.mobile_code,
            r'export\s+const\s+client\s*=\s*new\s+SuperoClient',
            "export const client singleton missing",
        )

    def test_export_supero_error_boundary(self):
        self.assertTrue(
            H.has_named_export(self.mobile_code, 'class',
                               'SuperoErrorBoundary'),
            "export class SuperoErrorBoundary missing",
        )

    def test_export_use_auth(self):
        self.assertRegex(
            self.mobile_code, r'export\s+const\s+useAuth\s*=',
            "export const useAuth missing",
        )

    def test_export_auth_provider(self):
        self.assertTrue(
            H.has_named_export(self.mobile_code, 'function', 'AuthProvider'),
            "export function AuthProvider missing",
        )

    def test_export_setConfig_and_getConfig(self):
        self.assertTrue(
            H.has_named_export(self.mobile_code, 'function', 'setConfig'),
            "export function setConfig missing",
        )
        self.assertTrue(
            H.has_named_export(self.mobile_code, 'function', 'getConfig'),
            "export function getConfig missing",
        )

    def test_export_services(self):
        self.assertRegex(
            self.mobile_code, r'export\s+const\s+services\s*=\s*\{',
            "export const services missing",
        )

    def test_export_build_field_defs(self):
        self.assertTrue(
            H.has_named_export(self.mobile_code, 'function', 'buildFieldDefs'),
            "export function buildFieldDefs missing",
        )

    def test_export_parse_422_error(self):
        self.assertTrue(
            H.has_named_export(self.mobile_code, 'function', 'parse422Error'),
            "export function parse422Error missing",
        )

    def test_export_mobile_shell(self):
        self.assertTrue(
            H.has_named_export(self.mobile_code, 'function', 'MobileShell'),
            "export function MobileShell missing",
        )

    def test_export_service_widget(self):
        self.assertTrue(
            H.has_named_export(self.mobile_code, 'function', 'ServiceWidget'),
            "export function ServiceWidget missing",
        )

    def test_export_supero_service_registry(self):
        self.assertRegex(
            self.mobile_code,
            r'export\s+const\s+SuperoServiceRegistry\s*=',
            "export const SuperoServiceRegistry missing",
        )

    def test_export_ai_chat_async(self):
        self.assertRegex(
            self.mobile_code,
            r'export\s+async\s+function\s+aiChat\s*\(',
            "export async function aiChat missing",
        )

    def test_export_trigger_workflow_async(self):
        self.assertRegex(
            self.mobile_code,
            r'export\s+async\s+function\s+triggerWorkflow\s*\(',
            "export async function triggerWorkflow missing",
        )

    def test_export_inline_select(self):
        self.assertTrue(
            H.has_named_export(self.mobile_code, 'function', 'InlineSelect'),
            "export function InlineSelect missing",
        )

    def test_export_action_ops(self):
        self.assertRegex(
            self.mobile_code, r'export\s+const\s+ACTION_OPS\s*=',
            "export const ACTION_OPS missing",
        )

    # ── DEFAULT_CONFIG ──

    def test_default_config_exported(self):
        self.assertRegex(
            self.mobile_code,
            r'export\s+const\s+DEFAULT_CONFIG\s*=\s*\{',
            "export const DEFAULT_CONFIG missing",
        )

    def test_config_starts_as_copy_not_reference(self):
        """`let CONFIG = { ...DEFAULT_CONFIG }` — must spread, not assign."""
        self.assertRegex(
            self.mobile_code,
            r'let\s+CONFIG\s*=\s*\{\s*\.\.\.DEFAULT_CONFIG\s*\}',
            "CONFIG must be spread copy of DEFAULT_CONFIG, "
            "not direct assignment",
        )


if __name__ == '__main__':
    unittest.main()
