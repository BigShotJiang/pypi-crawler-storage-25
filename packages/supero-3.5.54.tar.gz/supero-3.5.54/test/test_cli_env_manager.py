"""
test_cli_env_manager.py — Unit tests for supero.cli.env_manager.EnvManager

Location: ~/supero/platform/infra/libs/py/test/test_cli_env_manager.py

Run:
    python -m pytest test_cli_env_manager.py -v
    python -m unittest test_cli_env_manager -v

Coverage:
    - Constructor + _load: empty file, existing file, missing file, comments, blanks
    - get/set: basic access, default values, os.environ fallback
    - save: written keys, ordered keys, quoted values
    - reload: picks up external changes
    - clear: removes file + env vars
    - is_configured: API key mode, password mode, partial configs
    - derive_sdk_vars: HTTPS, HTTP, custom port, bare host
    - generate_config_js: required keys, optional keys, defaults
"""

import io
import os
import re
import sys
import tempfile
import unittest
from unittest.mock import patch


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _get_env_manager_class():
    """Return the EnvManager class."""
    import importlib
    mod = importlib.import_module('supero.cli.env_manager')
    return mod.EnvManager


# Snapshot/restore os.environ to keep tests isolated
class _EnvIsolation:
    """
    Context manager that snapshots os.environ on enter and restores on exit.

    Tests that call env.set() or env.clear() mutate os.environ as a side
    effect. This wrapper ensures tests don't leak into each other.
    """
    def __init__(self, keys_to_clear=None):
        self.snapshot = {}
        self.keys_to_clear = keys_to_clear or []

    def __enter__(self):
        self.snapshot = os.environ.copy()
        # Clear any SUPERO_* env vars so shell pollution doesn't leak into
        # tests. This is defense-in-depth: individual tests can still pass
        # keys_to_clear for non-SUPERO vars (e.g. TEST_KEY, NEW_KEY), but
        # no test should ever see a SUPERO_* var from the developer's shell.
        for k in list(os.environ):
            if k.startswith("SUPERO_"):
                os.environ.pop(k, None)
        for k in self.keys_to_clear:
            os.environ.pop(k, None)
        return self

    def __exit__(self, *args):
        # Restore by removing keys that were added and resetting originals
        current_keys = set(os.environ.keys())
        original_keys = set(self.snapshot.keys())
        for k in current_keys - original_keys:
            os.environ.pop(k, None)
        for k, v in self.snapshot.items():
            os.environ[k] = v


# ---------------------------------------------------------------------------
# Constructor + _load tests
# ---------------------------------------------------------------------------

class TestEnvManagerLoad(unittest.TestCase):
    """Tests for EnvManager initialization and .env file loading."""

    def setUp(self):
        self.EnvManager = _get_env_manager_class()
        self.tmpdir = tempfile.mkdtemp(prefix="env-manager-load-")
        self.env_path = os.path.join(self.tmpdir, ".env")
        self.isolation = _EnvIsolation([
            "SUPERO_URL", "SUPERO_DOMAIN", "SUPERO_PROJECT", "SUPERO_API_KEY",
            "SUPERO_ADMIN_EMAIL", "SUPERO_PASSWORD", "PORT", "UI_PORT",
        ])
        self.isolation.__enter__()

    def tearDown(self):
        self.isolation.__exit__()
        import shutil
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_missing_env_file_starts_empty(self):
        """Missing .env file produces an empty EnvManager."""
        env = self.EnvManager(env_path=self.env_path)
        self.assertEqual(env.values, {})

    def test_existing_env_file_loaded(self):
        """Existing .env file values are loaded into EnvManager.values."""
        with open(self.env_path, "w") as f:
            f.write("SUPERO_DOMAIN=test-domain\nSUPERO_PROJECT=my-project\n")
        env = self.EnvManager(env_path=self.env_path)
        self.assertEqual(env.get("SUPERO_DOMAIN"), "test-domain")
        self.assertEqual(env.get("SUPERO_PROJECT"), "my-project")

    def test_comments_ignored(self):
        """Lines starting with # are ignored."""
        with open(self.env_path, "w") as f:
            f.write("# This is a comment\nSUPERO_DOMAIN=test\n# Another comment\n")
        env = self.EnvManager(env_path=self.env_path)
        self.assertEqual(env.get("SUPERO_DOMAIN"), "test")
        self.assertEqual(len([k for k in env.values if k]), 1)

    def test_blank_lines_ignored(self):
        """Blank lines don't create empty keys."""
        with open(self.env_path, "w") as f:
            f.write("\n\nSUPERO_DOMAIN=test\n\n\n")
        env = self.EnvManager(env_path=self.env_path)
        self.assertEqual(env.get("SUPERO_DOMAIN"), "test")

    def test_lines_without_equals_ignored(self):
        """Malformed lines (no =) are silently skipped."""
        with open(self.env_path, "w") as f:
            f.write("SUPERO_DOMAIN=test\nmalformed line\nSUPERO_PROJECT=proj\n")
        env = self.EnvManager(env_path=self.env_path)
        self.assertEqual(env.get("SUPERO_DOMAIN"), "test")
        self.assertEqual(env.get("SUPERO_PROJECT"), "proj")

    def test_quoted_values_unquoted(self):
        """Values wrapped in quotes have quotes stripped."""
        with open(self.env_path, "w") as f:
            f.write("SUPERO_DOMAIN=\"quoted-value\"\nSUPERO_PROJECT='single-quoted'\n")
        env = self.EnvManager(env_path=self.env_path)
        self.assertEqual(env.get("SUPERO_DOMAIN"), "quoted-value")
        self.assertEqual(env.get("SUPERO_PROJECT"), "single-quoted")

    def test_values_with_equals_preserved(self):
        """Values containing = are parsed correctly (split only on first =)."""
        with open(self.env_path, "w") as f:
            f.write("SUPERO_API_KEY=ak_abc=def=ghi\n")
        env = self.EnvManager(env_path=self.env_path)
        self.assertEqual(env.get("SUPERO_API_KEY"), "ak_abc=def=ghi")

    def test_whitespace_around_keys_stripped(self):
        """Leading/trailing whitespace around keys is stripped."""
        with open(self.env_path, "w") as f:
            f.write("  SUPERO_DOMAIN  =test\n")
        env = self.EnvManager(env_path=self.env_path)
        self.assertEqual(env.get("SUPERO_DOMAIN"), "test")

    def test_os_environ_override(self):
        """os.environ values override .env file values for the same key."""
        with open(self.env_path, "w") as f:
            f.write("SUPERO_DOMAIN=from-file\n")
        os.environ["SUPERO_DOMAIN"] = "from-env"
        env = self.EnvManager(env_path=self.env_path)
        self.assertEqual(env.get("SUPERO_DOMAIN"), "from-env")


# ---------------------------------------------------------------------------
# get/set tests
# ---------------------------------------------------------------------------

class TestEnvManagerGetSet(unittest.TestCase):
    """Tests for get() and set() methods."""

    def setUp(self):
        self.EnvManager = _get_env_manager_class()
        self.tmpdir = tempfile.mkdtemp(prefix="env-manager-getset-")
        self.env_path = os.path.join(self.tmpdir, ".env")
        self.isolation = _EnvIsolation([
            "SUPERO_DOMAIN", "TEST_KEY", "MISSING_KEY",
        ])
        self.isolation.__enter__()

    def tearDown(self):
        self.isolation.__exit__()
        import shutil
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_get_missing_key_returns_empty_string(self):
        """get() on a missing key returns empty string by default."""
        env = self.EnvManager(env_path=self.env_path)
        self.assertEqual(env.get("MISSING_KEY"), "")

    def test_get_missing_key_returns_default(self):
        """get() with a default returns the default when key is missing."""
        env = self.EnvManager(env_path=self.env_path)
        self.assertEqual(env.get("MISSING_KEY", "fallback"), "fallback")

    def test_get_existing_key(self):
        """get() returns the stored value for existing keys."""
        env = self.EnvManager(env_path=self.env_path)
        env.values["TEST_KEY"] = "test-value"
        self.assertEqual(env.get("TEST_KEY"), "test-value")

    def test_set_stores_in_values_and_environ(self):
        """set() writes to both EnvManager.values and os.environ."""
        env = self.EnvManager(env_path=self.env_path)
        env.set("TEST_KEY", "new-value")
        self.assertEqual(env.values["TEST_KEY"], "new-value")
        self.assertEqual(os.environ.get("TEST_KEY"), "new-value")

    def test_set_overwrites_existing(self):
        """set() overwrites existing values."""
        env = self.EnvManager(env_path=self.env_path)
        env.set("TEST_KEY", "first")
        env.set("TEST_KEY", "second")
        self.assertEqual(env.get("TEST_KEY"), "second")

    def test_get_empty_value_returns_default(self):
        """Empty string values fall through to the default (falsy check)."""
        env = self.EnvManager(env_path=self.env_path)
        env.values["TEST_KEY"] = ""
        self.assertEqual(env.get("TEST_KEY", "fallback"), "fallback")


# ---------------------------------------------------------------------------
# save tests
# ---------------------------------------------------------------------------

class TestEnvManagerSave(unittest.TestCase):
    """Tests for save() to .env file."""

    def setUp(self):
        self.EnvManager = _get_env_manager_class()
        self.tmpdir = tempfile.mkdtemp(prefix="env-manager-save-")
        self.env_path = os.path.join(self.tmpdir, ".env")
        self.isolation = _EnvIsolation([
            "SUPERO_DOMAIN", "SUPERO_API_KEY", "SUPERO_ADMIN_EMAIL",
            "SUPERO_PASSWORD", "PORT",
        ])
        self.isolation.__enter__()

    def tearDown(self):
        self.isolation.__exit__()
        import shutil
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def _read_env(self):
        with open(self.env_path) as f:
            return f.read()

    def test_save_creates_file(self):
        """save() creates the .env file when it doesn't exist."""
        env = self.EnvManager(env_path=self.env_path)
        env.values["SUPERO_DOMAIN"] = "test"
        env.values["SUPERO_PROJECT"] = "test-project"
        env.save(allow_partial=True)
        self.assertTrue(os.path.exists(self.env_path))

    def test_save_writes_keys(self):
        """save() writes all values as KEY=value lines."""
        env = self.EnvManager(env_path=self.env_path)
        env.values["SUPERO_DOMAIN"] = "test-domain"
        env.values["SUPERO_PROJECT"] = "test-project"
        env.values["SUPERO_API_KEY"] = "ak_123"
        env.save(allow_partial=True)
        content = self._read_env()
        self.assertIn('SUPERO_DOMAIN="test-domain"', content)
        self.assertIn('SUPERO_API_KEY="ak_123"', content)

    def test_save_preserves_values_on_reload(self):
        """Values saved by save() can be read back with a new EnvManager."""
        env1 = self.EnvManager(env_path=self.env_path)
        env1.values["SUPERO_DOMAIN"] = "saved"
        env1.values["PORT"] = "9090"
        env1.save(allow_partial=True)
        env2 = self.EnvManager(env_path=self.env_path)
        self.assertEqual(env2.get("SUPERO_DOMAIN"), "saved")
        self.assertEqual(env2.get("PORT"), "9090")

    def test_save_ordered_keys_first(self):
        """Well-known keys appear in a predictable order before others."""
        env = self.EnvManager(env_path=self.env_path)
        env.values["CUSTOM_KEY"] = "custom"
        env.values["SUPERO_DOMAIN"] = "test"
        env.values["SUPERO_PROJECT"] = "test-project"
        env.values["SUPERO_URL"] = "https://api.supero.dev"
        # This test exercises key ordering, not the completeness contract.
        # Pass allow_partial=True to skip required-key validation.
        env.save(allow_partial=True)
        content = self._read_env()
        url_pos = content.find("SUPERO_URL=")
        domain_pos = content.find("SUPERO_DOMAIN=")
        custom_pos = content.find("CUSTOM_KEY=")
        # SUPERO_URL should come before SUPERO_DOMAIN (matches ordered_keys list)
        self.assertLess(url_pos, domain_pos)
        # Custom keys come after the ordered ones
        self.assertLess(domain_pos, custom_pos)

    def test_save_merges_with_existing_file(self):
        """
        save() merges new values with values loaded from the existing file.

        Note: EnvManager.__init__ calls _load() which reads existing keys into
        self.values. A subsequent save() writes both old + new keys. To fully
        replace the file, use clear() first.
        """
        with open(self.env_path, "w") as f:
            f.write("OLD_KEY=old_value\n")
        env = self.EnvManager(env_path=self.env_path)
        # OLD_KEY is loaded into values automatically
        self.assertEqual(env.values.get("OLD_KEY"), "old_value")

        env.values["SUPERO_DOMAIN"] = "new"

        env.values["SUPERO_PROJECT"] = "test-project"
        env.save(allow_partial=True)
        content = self._read_env()
        # Both keys present — OLD_KEY preserved, new key added
        self.assertIn('OLD_KEY="old_value"', content)
        self.assertIn('SUPERO_DOMAIN="new"', content)

    def test_save_after_clear_fully_replaces(self):
        """To fully replace file contents, call clear() before save()."""
        with open(self.env_path, "w") as f:
            f.write("OLD_KEY=old_value\n")
        env = self.EnvManager(env_path=self.env_path)
        env.clear()
        env.values["SUPERO_DOMAIN"] = "new"
        env.values["SUPERO_PROJECT"] = "test-project"
        env.save(allow_partial=True)
        content = self._read_env()
        self.assertNotIn("OLD_KEY", content)
        self.assertIn('SUPERO_DOMAIN="new"', content)

    def test_save_includes_header_comment(self):
        """Saved .env file has a helpful header comment."""
        env = self.EnvManager(env_path=self.env_path)
        env.values["SUPERO_DOMAIN"] = "test"
        env.values["SUPERO_PROJECT"] = "test-project"
        env.save(allow_partial=True)
        content = self._read_env()
        self.assertTrue(content.startswith("#"))


# ---------------------------------------------------------------------------
# reload tests
# ---------------------------------------------------------------------------

class TestEnvManagerReload(unittest.TestCase):
    """Tests for reload() picking up external file changes."""

    def setUp(self):
        self.EnvManager = _get_env_manager_class()
        self.tmpdir = tempfile.mkdtemp(prefix="env-manager-reload-")
        self.env_path = os.path.join(self.tmpdir, ".env")
        self.isolation = _EnvIsolation(["SUPERO_DOMAIN", "NEW_KEY"])
        self.isolation.__enter__()

    def tearDown(self):
        self.isolation.__exit__()
        import shutil
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_reload_picks_up_external_changes(self):
        """reload() re-reads the .env file after external edits."""
        with open(self.env_path, "w") as f:
            f.write("SUPERO_DOMAIN=original\n")
        env = self.EnvManager(env_path=self.env_path)
        self.assertEqual(env.get("SUPERO_DOMAIN"), "original")

        # External process modifies the file
        with open(self.env_path, "w") as f:
            f.write("SUPERO_DOMAIN=modified\n")

        env.reload()
        self.assertEqual(env.get("SUPERO_DOMAIN"), "modified")

    def test_reload_picks_up_new_keys(self):
        """reload() picks up keys added externally."""
        with open(self.env_path, "w") as f:
            f.write("SUPERO_DOMAIN=test\n")
        env = self.EnvManager(env_path=self.env_path)

        with open(self.env_path, "w") as f:
            f.write("SUPERO_DOMAIN=test\nNEW_KEY=added\n")

        env.reload()
        self.assertEqual(env.get("NEW_KEY"), "added")

    def test_reload_clears_old_values(self):
        """reload() removes keys that no longer exist in the file."""
        with open(self.env_path, "w") as f:
            f.write("SUPERO_DOMAIN=test\nOLD_KEY=remove_me\n")
        env = self.EnvManager(env_path=self.env_path)
        self.assertEqual(env.values.get("OLD_KEY"), "remove_me")

        with open(self.env_path, "w") as f:
            f.write("SUPERO_DOMAIN=test\n")

        env.reload()
        self.assertNotIn("OLD_KEY", env.values)


# ---------------------------------------------------------------------------
# clear tests
# ---------------------------------------------------------------------------

class TestEnvManagerClear(unittest.TestCase):
    """Tests for clear() removing file and env vars."""

    def setUp(self):
        self.EnvManager = _get_env_manager_class()
        self.tmpdir = tempfile.mkdtemp(prefix="env-manager-clear-")
        self.env_path = os.path.join(self.tmpdir, ".env")
        self.isolation = _EnvIsolation([
            "SUPERO_DOMAIN", "SUPERO_API_KEY", "SUPERO_ADMIN_EMAIL", "PORT",
        ])
        self.isolation.__enter__()

    def tearDown(self):
        self.isolation.__exit__()
        import shutil
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_clear_empties_values(self):
        """clear() empties EnvManager.values dict."""
        env = self.EnvManager(env_path=self.env_path)
        env.values["SUPERO_DOMAIN"] = "test"
        env.values["SUPERO_PROJECT"] = "test-project"
        env.clear()
        self.assertEqual(env.values, {})

    def test_clear_removes_env_file(self):
        """clear() deletes the .env file on disk."""
        env = self.EnvManager(env_path=self.env_path)
        env.values["SUPERO_DOMAIN"] = "test"
        env.values["SUPERO_PROJECT"] = "test-project"
        env.save(allow_partial=True)
        self.assertTrue(os.path.exists(self.env_path))
        env.clear()
        self.assertFalse(os.path.exists(self.env_path))

    def test_clear_removes_os_environ_vars(self):
        """clear() unsets known SUPERO_* variables from os.environ."""
        env = self.EnvManager(env_path=self.env_path)
        env.set("SUPERO_DOMAIN", "test")
        env.set("SUPERO_API_KEY", "ak_test")
        self.assertEqual(os.environ.get("SUPERO_DOMAIN"), "test")
        env.clear()
        self.assertIsNone(os.environ.get("SUPERO_DOMAIN"))
        self.assertIsNone(os.environ.get("SUPERO_API_KEY"))

    def test_clear_when_file_missing_no_error(self):
        """clear() on a missing .env file does not raise."""
        env = self.EnvManager(env_path=self.env_path)
        # File doesn't exist yet
        try:
            env.clear()
        except Exception as e:
            self.fail(f"clear() raised unexpectedly: {e}")


# ---------------------------------------------------------------------------
# is_configured tests
# ---------------------------------------------------------------------------

class TestEnvManagerIsConfigured(unittest.TestCase):
    """Tests for is_configured() — API key mode + password mode."""

    def setUp(self):
        self.EnvManager = _get_env_manager_class()
        self.tmpdir = tempfile.mkdtemp(prefix="env-manager-config-")
        self.env_path = os.path.join(self.tmpdir, ".env")
        self.isolation = _EnvIsolation([
            "SUPERO_DOMAIN", "SUPERO_API_KEY",
            "SUPERO_ADMIN_EMAIL", "SUPERO_PASSWORD",
        ])
        self.isolation.__enter__()

    def tearDown(self):
        self.isolation.__exit__()
        import shutil
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_empty_is_not_configured(self):
        """Empty EnvManager is not configured."""
        env = self.EnvManager(env_path=self.env_path)
        self.assertFalse(env.is_configured())

    def test_api_key_mode_configured(self):
        """Domain + valid API key (ak_ prefix) is configured."""
        env = self.EnvManager(env_path=self.env_path)
        env.values["SUPERO_DOMAIN"] = "test"
        env.values["SUPERO_PROJECT"] = "test-project"
        env.values["SUPERO_API_KEY"] = "ak_valid_key"
        self.assertTrue(env.is_configured())

    def test_api_key_without_ak_prefix_not_configured(self):
        """Domain + API key missing 'ak_' prefix is not configured."""
        env = self.EnvManager(env_path=self.env_path)
        env.values["SUPERO_DOMAIN"] = "test"
        env.values["SUPERO_PROJECT"] = "test-project"
        env.values["SUPERO_API_KEY"] = "invalid_key_no_prefix"
        self.assertFalse(env.is_configured())

    def test_api_key_without_domain_not_configured(self):
        """API key alone (no domain) is not configured."""
        env = self.EnvManager(env_path=self.env_path)
        env.values["SUPERO_API_KEY"] = "ak_valid"
        self.assertFalse(env.is_configured())

    def test_password_mode_configured(self):
        """Domain + email + password is configured."""
        env = self.EnvManager(env_path=self.env_path)
        env.values["SUPERO_DOMAIN"] = "test"
        env.values["SUPERO_PROJECT"] = "test-project"
        env.values["SUPERO_ADMIN_EMAIL"] = "admin@test.com"
        env.values["SUPERO_PASSWORD"] = "pass123"
        self.assertTrue(env.is_configured())

    def test_password_mode_missing_email_not_configured(self):
        """Password without email is not configured."""
        env = self.EnvManager(env_path=self.env_path)
        env.values["SUPERO_DOMAIN"] = "test"
        env.values["SUPERO_PROJECT"] = "test-project"
        env.values["SUPERO_PASSWORD"] = "pass123"
        self.assertFalse(env.is_configured())

    def test_password_mode_missing_password_not_configured(self):
        """Email without password is not configured."""
        env = self.EnvManager(env_path=self.env_path)
        env.values["SUPERO_DOMAIN"] = "test"
        env.values["SUPERO_PROJECT"] = "test-project"
        env.values["SUPERO_ADMIN_EMAIL"] = "admin@test.com"
        self.assertFalse(env.is_configured())

    def test_both_modes_configured(self):
        """Both API key and password mode set → still configured."""
        env = self.EnvManager(env_path=self.env_path)
        env.values["SUPERO_DOMAIN"] = "test"
        env.values["SUPERO_PROJECT"] = "test-project"
        env.values["SUPERO_API_KEY"] = "ak_valid"
        env.values["SUPERO_ADMIN_EMAIL"] = "admin@test.com"
        env.values["SUPERO_PASSWORD"] = "pass"
        self.assertTrue(env.is_configured())


# ---------------------------------------------------------------------------
# derive_sdk_vars tests
# ---------------------------------------------------------------------------

class TestEnvManagerDeriveSdkVars(unittest.TestCase):
    """Tests for derive_sdk_vars() parsing SUPERO_URL into HOST + PORT."""

    def setUp(self):
        self.EnvManager = _get_env_manager_class()
        self.tmpdir = tempfile.mkdtemp(prefix="env-manager-derive-")
        self.env_path = os.path.join(self.tmpdir, ".env")
        self.isolation = _EnvIsolation([
            "SUPERO_URL", "PLATFORM_CORE_HOST", "PLATFORM_CORE_PORT",
        ])
        self.isolation.__enter__()

    def tearDown(self):
        self.isolation.__exit__()
        import shutil
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_https_url_default_port_443(self):
        """https:// URL without port derives port 443."""
        env = self.EnvManager(env_path=self.env_path)
        env.values["SUPERO_URL"] = "https://api.supero.dev"
        env.derive_sdk_vars()
        self.assertEqual(env.get("PLATFORM_CORE_HOST"), "api.supero.dev")
        self.assertEqual(env.get("PLATFORM_CORE_PORT"), "443")

    def test_http_url_default_port_8083(self):
        """http:// URL without port derives port 8083 (Supero default)."""
        env = self.EnvManager(env_path=self.env_path)
        env.values["SUPERO_URL"] = "http://localhost"
        env.derive_sdk_vars()
        self.assertEqual(env.get("PLATFORM_CORE_HOST"), "localhost")
        self.assertEqual(env.get("PLATFORM_CORE_PORT"), "8083")

    def test_explicit_port_in_url(self):
        """URL with explicit :port extracts that port."""
        env = self.EnvManager(env_path=self.env_path)
        env.values["SUPERO_URL"] = "http://localhost:9999"
        env.derive_sdk_vars()
        self.assertEqual(env.get("PLATFORM_CORE_HOST"), "localhost")
        self.assertEqual(env.get("PLATFORM_CORE_PORT"), "9999")

    def test_https_with_explicit_port(self):
        """HTTPS URL with port uses that port, not 443."""
        env = self.EnvManager(env_path=self.env_path)
        env.values["SUPERO_URL"] = "https://staging.supero.dev:8443"
        env.derive_sdk_vars()
        self.assertEqual(env.get("PLATFORM_CORE_HOST"), "staging.supero.dev")
        self.assertEqual(env.get("PLATFORM_CORE_PORT"), "8443")

    def test_url_with_path_strips_path(self):
        """URL with path keeps only host in PLATFORM_CORE_HOST."""
        env = self.EnvManager(env_path=self.env_path)
        env.values["SUPERO_URL"] = "https://api.supero.dev/v1/something"
        env.derive_sdk_vars()
        self.assertEqual(env.get("PLATFORM_CORE_HOST"), "api.supero.dev")
        # Port follows the HTTPS default
        self.assertEqual(env.get("PLATFORM_CORE_PORT"), "443")

    def test_empty_url_uses_default(self):
        """Missing SUPERO_URL falls back to default https://api.supero.dev."""
        env = self.EnvManager(env_path=self.env_path)
        env.derive_sdk_vars()
        self.assertEqual(env.get("PLATFORM_CORE_HOST"), "api.supero.dev")
        self.assertEqual(env.get("PLATFORM_CORE_PORT"), "443")


# ---------------------------------------------------------------------------
# generate_config_js tests
# ---------------------------------------------------------------------------

class TestEnvManagerGenerateConfigJs(unittest.TestCase):
    """Tests for generate_config_js() producing ui/config.js."""

    def setUp(self):
        self.EnvManager = _get_env_manager_class()
        self.tmpdir = tempfile.mkdtemp(prefix="env-manager-configjs-")
        self.env_path = os.path.join(self.tmpdir, ".env")
        self.ui_dir = os.path.join(self.tmpdir, "ui")
        self.config_js_path = os.path.join(self.ui_dir, "config.js")
        self.isolation = _EnvIsolation([
            "SUPERO_DOMAIN", "SUPERO_PROJECT", "SUPERO_DEFAULT_TENANT",
            "SUPERO_URL", "APP_NAME", "APP_EMOJI", "APP_DESCRIPTION",
        ])
        self.isolation.__enter__()

    def _make_env(self, project="test-project"):
        """
        Build an EnvManager pre-populated with the SUPERO_PROJECT that
        generate_config_js() now requires. Tests that want to exercise
        the missing-project code path should pass project=None.
        """
        env = self.EnvManager(env_path=self.env_path)
        if project is not None:
            env.values["SUPERO_PROJECT"] = project
        # SUPERO_TEST_UPDATES_V1: also seed SUPERO_APP_NAMESPACE so the
        # new generate_config_js fail-loud contract (introduced by
        # patch_namespace_required_python_v1) does not break unrelated
        # tests. Tests that specifically exercise the missing-namespace
        # path should env.values.pop("SUPERO_APP_NAMESPACE", None).
        env.values["SUPERO_APP_NAMESPACE"] = "test_namespace"
        return env

    def tearDown(self):
        self.isolation.__exit__()
        import shutil
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def _read_config_js(self):
        with open(self.config_js_path) as f:
            return f.read()

    def test_creates_config_js(self):
        """generate_config_js() creates ui/config.js."""
        env = self.EnvManager(env_path=self.env_path)
        env.values["SUPERO_DOMAIN"] = "test"
        env.values["SUPERO_PROJECT"] = "test-project"
        env.values["SUPERO_APP_NAMESPACE"] = "test_namespace"  # SUPERO_TEST_UPDATES_V1
        env.generate_config_js(self.ui_dir)
        self.assertTrue(os.path.exists(self.config_js_path))

    def test_creates_ui_dir_if_missing(self):
        """generate_config_js() creates the ui/ directory if it doesn't exist."""
        env = self.EnvManager(env_path=self.env_path)
        env.values["SUPERO_DOMAIN"] = "test"
        env.values["SUPERO_PROJECT"] = "test-project"
        self.assertFalse(os.path.isdir(self.ui_dir))
        env.values["SUPERO_APP_NAMESPACE"] = "test_namespace"  # SUPERO_TEST_UPDATES_V1
        env.generate_config_js(self.ui_dir)
        self.assertTrue(os.path.isdir(self.ui_dir))

    def test_config_js_has_domain(self):
        """Generated config.js sets window.__SUPERO_CONFIG.domain."""
        env = self.EnvManager(env_path=self.env_path)
        env.values["SUPERO_DOMAIN"] = "foodtruck"
        env.values["SUPERO_PROJECT"] = "test-project"
        env.values["SUPERO_APP_NAMESPACE"] = "test_namespace"  # SUPERO_TEST_UPDATES_V1
        env.generate_config_js(self.ui_dir)
        content = self._read_config_js()
        self.assertIn("window.__SUPERO_CONFIG", content)
        self.assertIn('domain: "foodtruck"', content)

    def test_config_js_has_project(self):
        """Generated config.js sets project."""
        env = self.EnvManager(env_path=self.env_path)
        env.values["SUPERO_DOMAIN"] = "test"
        env.values["SUPERO_PROJECT"] = "my-project"
        env.values["SUPERO_APP_NAMESPACE"] = "test_namespace"  # SUPERO_TEST_UPDATES_V1
        env.generate_config_js(self.ui_dir)
        content = self._read_config_js()
        self.assertIn('project: "my-project"', content)

    def test_config_js_has_tenant(self):
        """Generated config.js sets tenant."""
        env = self.EnvManager(env_path=self.env_path)
        env.values["SUPERO_DOMAIN"] = "test"
        env.values["SUPERO_PROJECT"] = "test-project"
        env.values["SUPERO_DEFAULT_TENANT"] = "branch-nyc"
        env.values["SUPERO_APP_NAMESPACE"] = "test_namespace"  # SUPERO_TEST_UPDATES_V1
        env.generate_config_js(self.ui_dir)
        content = self._read_config_js()
        self.assertIn('tenant: "branch-nyc"', content)

    def test_config_js_has_api_url(self):
        """Generated config.js sets apiUrl."""
        env = self.EnvManager(env_path=self.env_path)
        env.values["SUPERO_DOMAIN"] = "test"
        env.values["SUPERO_PROJECT"] = "test-project"
        env.values["SUPERO_URL"] = "https://api.supero.dev"
        env.values["SUPERO_APP_NAMESPACE"] = "test_namespace"  # SUPERO_TEST_UPDATES_V1
        env.generate_config_js(self.ui_dir)
        content = self._read_config_js()
        self.assertIn('apiUrl: "https://api.supero.dev"', content)

    def test_config_js_app_branding_from_env(self):
        """Explicit APP_NAME/APP_EMOJI in env takes precedence."""
        env = self.EnvManager(env_path=self.env_path)
        env.values["SUPERO_DOMAIN"] = "test"
        env.values["SUPERO_PROJECT"] = "test-project"
        env.values["APP_NAME"] = "My Custom App"
        env.values["APP_EMOJI"] = "🚀"
        env.values["SUPERO_APP_NAMESPACE"] = "test_namespace"  # SUPERO_TEST_UPDATES_V1
        env.generate_config_js(self.ui_dir)
        content = self._read_config_js()
        self.assertIn('appName: "My Custom App"', content)
        self.assertIn('appEmoji: "🚀"', content)

    def test_config_js_app_branding_from_args(self):
        """app_name/app_emoji arguments override env defaults."""
        env = self.EnvManager(env_path=self.env_path)
        env.values["SUPERO_DOMAIN"] = "test"
        env.values["SUPERO_PROJECT"] = "test-project"
        env.values["SUPERO_APP_NAMESPACE"] = "test_namespace"  # SUPERO_TEST_UPDATES_V1
        env.generate_config_js(
            self.ui_dir,
            app_name="Via Arg",
            app_emoji="🎯",
            app_description="A test",
        )
        content = self._read_config_js()
        self.assertIn('appName: "Via Arg"', content)
        self.assertIn('appEmoji: "🎯"', content)
        self.assertIn('appDescription: "A test"', content)

    def test_config_js_fallback_name_from_domain(self):
        """When no APP_NAME, the name is derived from the domain."""
        env = self.EnvManager(env_path=self.env_path)
        env.values["SUPERO_DOMAIN"] = "my-cool-app"
        env.values["SUPERO_PROJECT"] = "test-project"
        env.values["SUPERO_APP_NAMESPACE"] = "test_namespace"  # SUPERO_TEST_UPDATES_V1
        env.generate_config_js(self.ui_dir)
        content = self._read_config_js()
        # domain "my-cool-app" → "My Cool App"
        self.assertIn('"My Cool App"', content)

    def test_config_js_default_emoji(self):
        """Default emoji is 🚀 when nothing is provided."""
        env = self.EnvManager(env_path=self.env_path)
        env.values["SUPERO_DOMAIN"] = "test"
        env.values["SUPERO_PROJECT"] = "test-project"
        env.values["SUPERO_APP_NAMESPACE"] = "test_namespace"  # SUPERO_TEST_UPDATES_V1
        env.generate_config_js(self.ui_dir)
        content = self._read_config_js()
        self.assertIn('🚀', content)

    def test_config_js_no_project_raises(self):
        """generate_config_js must raise ValueError if SUPERO_PROJECT is unset.

        The old behavior silently defaulted to 'default-project', which
        caused generated apps to route schemas into the admin placeholder
        project. The new contract requires an explicit project — no
        silent fallback.
        """
        env = self._make_env(project=None)
        env.values["SUPERO_DOMAIN"] = "test"
        # Defensively ensure SUPERO_PROJECT is absent from env.values
        env.values.pop("SUPERO_PROJECT", None)
        with self.assertRaises(ValueError) as ctx:
            env.generate_config_js(self.ui_dir)
        self.assertIn("SUPERO_PROJECT", str(ctx.exception))

    def test_config_js_no_namespace_raises(self):
        """generate_config_js must raise ValueError if SUPERO_APP_NAMESPACE is unset.

        SUPERO_TEST_UPDATES_V1 — Asserts the new fail-loud contract
        introduced by patch_namespace_required_python_v1. Previously
        the SDK silently fell back to using SUPERO_DOMAIN as namespace,
        causing CRUD URLs to route to the wrong namespace and return
        empty results. The new contract requires explicit namespace.
        """
        env = self.EnvManager(env_path=self.env_path)
        env.values["SUPERO_DOMAIN"] = "test"
        env.values["SUPERO_PROJECT"] = "test-project"
        # Deliberately do NOT set SUPERO_APP_NAMESPACE
        env.values.pop("SUPERO_APP_NAMESPACE", None)
        with self.assertRaises(ValueError) as ctx:
            env.generate_config_js(self.ui_dir)
        self.assertIn("SUPERO_APP_NAMESPACE", str(ctx.exception))
    def test_config_js_default_tenant(self):
        """Default tenant is 'default-tenant' when unset."""
        env = self.EnvManager(env_path=self.env_path)
        env.values["SUPERO_DOMAIN"] = "test"
        env.values["SUPERO_PROJECT"] = "test-project"
        env.values["SUPERO_APP_NAMESPACE"] = "test_namespace"  # SUPERO_TEST_UPDATES_V1
        env.generate_config_js(self.ui_dir)
        content = self._read_config_js()
        self.assertIn('tenant: "default-tenant"', content)

    def test_config_js_default_api_url(self):
        """Default apiUrl is https://api.supero.dev when unset."""
        env = self.EnvManager(env_path=self.env_path)
        env.values["SUPERO_DOMAIN"] = "test"
        env.values["SUPERO_PROJECT"] = "test-project"
        env.values["SUPERO_APP_NAMESPACE"] = "test_namespace"  # SUPERO_TEST_UPDATES_V1
        env.generate_config_js(self.ui_dir)
        content = self._read_config_js()
        self.assertIn("https://api.supero.dev", content)

    def test_tenant_noun_emitted_with_defaults(self):
        """Generated config.js emits tenantNoun with Workspace defaults when noun args are not passed."""
        env = self._make_env()
        env.values["SUPERO_DOMAIN"] = "test"
        env.generate_config_js(self.ui_dir)
        content = self._read_config_js()
        self.assertIn(
            'tenantNoun: { singular: "Workspace", plural: "Workspaces" }',
            content,
        )

    def test_tenant_noun_emitted_with_custom(self):
        """Generated config.js emits custom tenantNoun when passed explicitly."""
        env = self._make_env()
        env.values["SUPERO_DOMAIN"] = "test"
        env.generate_config_js(
            self.ui_dir,
            tenant_noun_singular="Salon",
            tenant_noun_plural="Salons",
        )
        content = self._read_config_js()
        self.assertIn(
            'tenantNoun: { singular: "Salon", plural: "Salons" }',
            content,
        )

    def test_tenant_noun_js_escaped(self):
        """Regression guard: quotes in tenant noun must be escaped, not break out of the JS string literal."""
        env = self._make_env()
        env.values["SUPERO_DOMAIN"] = "test"
        env.generate_config_js(
            self.ui_dir,
            tenant_noun_singular='Sal"on',
        )
        content = self._read_config_js()
        # Escaped form must be present
        self.assertIn('Sal\\"on', content)
        # Raw quote must NOT break out of the string literal
        self.assertNotIn('singular: "Sal"on"', content)


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    unittest.main(verbosity=2)
