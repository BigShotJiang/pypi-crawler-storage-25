"""
Unit tests for proxy mode functionality in ApiClient and ApiLib.
Tests authentication validation, mode detection, and proxy routing.
"""

import unittest
import sys
import os
from unittest.mock import patch, Mock, MagicMock, call
from pathlib import Path

# Setup paths
test_dir = Path(__file__).parent
project_root = test_dir.parent
src_dir = project_root / "src"

for path in [str(src_dir), str(project_root)]:
    if path not in sys.path:
        sys.path.insert(0, path)

# Set test environment
os.environ["TESTING"] = "true"

# Mock dependencies if needed
def setup_test_mocks():
    """Setup mocks for missing dependencies."""
    try:
        import pymodel_system
    except ImportError:
        pymodel_system_mock = MagicMock()
        sys.modules['pymodel_system'] = pymodel_system_mock
        sys.modules['pymodel_system.objects'] = MagicMock()
        sys.modules['pymodel_system.serialization_errors'] = MagicMock()

setup_test_mocks()

from py_api_lib.api_client import ApiClient
from py_api_lib.api_lib import ApiLib


# ============================================================================
# Helper Functions
# ============================================================================

def create_mock_session():
    """
    Create properly configured mock session for ApiClient tests.
    Returns a mock session with real dict headers and working methods.
    """
    mock_session = Mock()
    mock_session.headers = {}  # IMPORTANT: Real dict, not Mock!
    
    # Mock successful connection test response
    mock_response = Mock()
    mock_response.status_code = 200
    mock_response.text = "OK"
    mock_session.options.return_value = mock_response
    mock_session.request.return_value = mock_response
    
    return mock_session


# ============================================================================
# ApiClient Proxy Mode Tests
# ============================================================================

class TestApiClientProxyModeInitialization(unittest.TestCase):
    """Test ApiClient initialization in proxy mode."""
    
    @patch('py_api_lib.api_client.requests.Session')
    def test_direct_mode_initialization(self, mock_session_class):
        """Test ApiClient initializes correctly in direct mode."""
        mock_session_instance = create_mock_session()
        mock_session_class.return_value = mock_session_instance
        
        client = ApiClient(
            server_ip='api-server',
            port=8082,
            api_key='ak_test_prod_123'
        )
        
        # Verify mode
        self.assertFalse(client.use_proxy)
        
        # Verify base URL (no prefix)
        self.assertEqual(client.base_url, 'http://api-server:8082')
        
        # Verify API key set
        self.assertEqual(client._api_key, 'ak_test_prod_123')
        self.assertIsNone(client._jwt_token)
        
        # Verify API key header set
        self.assertIn('Authorization', client.session.headers)
        self.assertNotIn('X-API-Key', client.session.headers)
        #self.assertEqual(client.session.headers['X-API-Key'], 'ak_test_prod_123')
        #self.assertNotIn('Authorization', client.session.headers)
    
    @patch('py_api_lib.api_client.requests.Session')
    def test_proxy_mode_initialization(self, mock_session_class):
        """Test ApiClient initializes correctly in proxy mode."""
        mock_session_instance = create_mock_session()
        mock_session_class.return_value = mock_session_instance
        
        client = ApiClient(
            server_ip='platform-core',
            port=8083,
            use_proxy=True,
            jwt_token='eyJhbGciOiJIUzI1NiIs...'
        )
        
        # Verify mode
        self.assertTrue(client.use_proxy)
        
        # Verify base URL (with prefix)
        self.assertEqual(client.base_url, 'http://platform-core:8083/api/v1/crud')
        
        # Verify JWT token set
        self.assertEqual(client._jwt_token, 'eyJhbGciOiJIUzI1NiIs...')
        self.assertIsNone(client._api_key)
        
        # Verify JWT header set
        self.assertIn('Authorization', client.session.headers)
        self.assertEqual(
            client.session.headers['Authorization'], 
            'Bearer eyJhbGciOiJIUzI1NiIs...'
        )
        #self.assertNotIn('X-API-Key', client.session.headers)
    
    @patch('py_api_lib.api_client.requests.Session')
    def test_proxy_mode_with_custom_prefix(self, mock_session_class):
        """Test proxy mode with custom endpoint prefix."""
        mock_session_instance = create_mock_session()
        mock_session_class.return_value = mock_session_instance
        
        client = ApiClient(
            server_ip='platform-core',
            port=8083,
            use_proxy=True,
            proxy_prefix='/custom/api/prefix',
            jwt_token='test_jwt'
        )
        
        self.assertEqual(client.base_url, 'http://platform-core:8083/custom/api/prefix')
        self.assertEqual(client.proxy_prefix, '/custom/api/prefix')
    
    @patch('py_api_lib.api_client.requests.Session')
    def test_proxy_prefix_trailing_slash_removed(self, mock_session_class):
        """Test that trailing slash is removed from proxy prefix."""
        mock_session_instance = create_mock_session()
        mock_session_class.return_value = mock_session_instance
        
        client = ApiClient(
            server_ip='platform-core',
            port=8083,
            use_proxy=True,
            proxy_prefix='/api/v1/crud/',  # With trailing slash
            jwt_token='test_jwt'
        )
        
        # Trailing slash should be removed
        self.assertEqual(client.proxy_prefix, '/api/v1/crud')
        self.assertEqual(client.base_url, 'http://platform-core:8083/api/v1/crud')
    
    @patch('py_api_lib.api_client.requests.Session')
    def test_no_authentication_direct_mode(self, mock_session_class):
        """Test ApiClient with no authentication in direct mode."""
        mock_session_instance = create_mock_session()
        mock_session_class.return_value = mock_session_instance
        
        client = ApiClient(
            server_ip='localhost',
            port=8082
        )
        
        self.assertFalse(client.use_proxy)
        self.assertIsNone(client._api_key)
        self.assertIsNone(client._jwt_token)
        
        # No auth headers should be set
        self.assertNotIn('X-API-Key', client.session.headers)
        self.assertNotIn('Authorization', client.session.headers)


class TestApiClientAuthValidation(unittest.TestCase):
    """Test authentication configuration validation."""
    
    @patch('py_api_lib.api_client.requests.Session')
    def test_validation_both_tokens_raises_error(self, mock_session_class):
        """Test that providing both api_key and jwt_token raises ValueError."""
        with self.assertRaises(ValueError) as context:
            ApiClient(
                api_key='ak_test_123',
                jwt_token='eyJhbGc...'
            )
        
        self.assertIn('Cannot provide both api_key and jwt_token', str(context.exception))
    
    @patch('py_api_lib.api_client.requests.Session')
    def test_proxy_mode_with_api_key_works(self, mock_session_class):
        """Fix U: proxy mode + api_key is a valid configuration.

        Platform-core's /api/v1/crud/* endpoints accept api_key auth via
        the Authorization: Bearer header. Rejecting this combination
        (the old behavior) broke every SDK caller that had an api_key —
        the standard server-to-server auth form.

        After Fix U: client should be created successfully, api_key
        stored, and Authorization header set on the session.
        """
        mock_session_instance = create_mock_session()
        mock_session_class.return_value = mock_session_instance

        # Must not raise
        client = ApiClient(
            use_proxy=True,
            api_key='ak_test_123'
        )

        self.assertEqual(client._api_key, 'ak_test_123')
        self.assertTrue(client.use_proxy)
        # Authorization: Bearer header should be set on the session
        self.assertIn('Authorization', mock_session_instance.headers)
        self.assertEqual(
            mock_session_instance.headers['Authorization'],
            'Bearer ak_test_123'
        )
    
    @patch('py_api_lib.api_client.requests.Session')
    def test_direct_mode_with_jwt_token_works(self, mock_session_class):
        """Fix U: direct mode + jwt_token is a valid configuration.

        Api-server validates Authorization: Bearer tokens on direct
        endpoints. The old rejection was incorrect.
        """
        mock_session_instance = create_mock_session()
        mock_session_class.return_value = mock_session_instance

        # Must not raise
        client = ApiClient(
            use_proxy=False,
            jwt_token='eyJhbGc...'
        )

        self.assertEqual(client._jwt_token, 'eyJhbGc...')
        self.assertFalse(client.use_proxy)
        # Authorization: Bearer header should be set on the session
        self.assertIn('Authorization', mock_session_instance.headers)
        self.assertEqual(
            mock_session_instance.headers['Authorization'],
            'Bearer eyJhbGc...'
        )
    
    @patch('py_api_lib.api_client.requests.Session')
    def test_validation_proxy_mode_without_auth_warns(self, mock_session_class):
        """Test that proxy mode without authentication logs warning."""
        mock_session_instance = create_mock_session()
        mock_session_class.return_value = mock_session_instance
        
        with patch('py_api_lib.api_client.get_logger') as mock_logger_func:
            mock_logger = Mock()
            mock_logger_func.return_value = mock_logger
            
            client = ApiClient(
                use_proxy=True
                # No jwt_token or api_key
            )
            
            # Verify warning was logged (may be called multiple times)
            self.assertTrue(mock_logger.warning.called)
            
            # Check that at least one warning is about authentication
            warning_calls = [str(call) for call in mock_logger.warning.call_args_list]
            auth_warning_found = any('without authentication' in str(call) for call in warning_calls)
            self.assertTrue(auth_warning_found, "Expected authentication warning not found")


class TestApiClientAuthHeaderMethods(unittest.TestCase):
    """Test authentication header manipulation methods."""
    
    @patch('py_api_lib.api_client.requests.Session')
    def test_set_api_key_header(self, mock_session_class):
        """Test _set_api_key_header sets correct header."""
        mock_session_instance = create_mock_session()
        mock_session_class.return_value = mock_session_instance
        
        client = ApiClient(api_key='ak_test_123')
        
        self.assertIn('Authorization', client.session.headers)
        self.assertEqual(client.session.headers['Authorization'], 'Bearer ak_test_123')
    
    @patch('py_api_lib.api_client.requests.Session')
    def test_set_jwt_header(self, mock_session_class):
        """Test _set_jwt_header sets correct header."""
        mock_session_instance = create_mock_session()
        mock_session_class.return_value = mock_session_instance
        
        client = ApiClient(use_proxy=True, jwt_token='test_jwt')
        
        self.assertIn('Authorization', client.session.headers)
        self.assertEqual(client.session.headers['Authorization'], 'Bearer test_jwt')
    
    @patch('py_api_lib.api_client.requests.Session')
    def test_clear_auth_headers(self, mock_session_class):
        """Test _clear_auth_headers removes both auth headers."""
        mock_session_instance = create_mock_session()
        # Add auth headers
        #mock_session_instance.headers['X-API-Key'] = 'test_key'
        mock_session_instance.headers['Authorization'] = 'Bearer test_jwt'
        mock_session_instance.headers['Content-Type'] = 'application/json'
        mock_session_class.return_value = mock_session_instance
        
        client = ApiClient()
        client._clear_auth_headers()
        
        #self.assertNotIn('X-API-Key', client.session.headers)
        self.assertNotIn('Authorization', client.session.headers)
        # Other headers should remain
        self.assertIn('Content-Type', client.session.headers)


class TestApiClientSetApiKeyMethod(unittest.TestCase):
    """Test set_api_key method with mode checks."""
    
    @patch('py_api_lib.api_client.requests.Session')
    def test_set_api_key_in_direct_mode(self, mock_session_class):
        """Test set_api_key works in direct mode."""
        mock_session_instance = create_mock_session()
        mock_session_class.return_value = mock_session_instance
        
        client = ApiClient(server_ip='localhost', port=8082)
        
        client.set_api_key('ak_new_key_123')
        
        self.assertEqual(client._api_key, 'ak_new_key_123')
        #self.assertIn('X-API-Key', client.session.headers)
        self.assertEqual(client.session.headers['Authorization'], 'Bearer ak_new_key_123')
    
    @patch('py_api_lib.api_client.requests.Session')
    def test_set_api_key_in_proxy_mode_warns(self, mock_session_class):
        """Test set_api_key warns and doesn't change in proxy mode."""
        mock_session_instance = create_mock_session()
        mock_session_class.return_value = mock_session_instance
        
        with patch('py_api_lib.api_client.get_logger') as mock_logger_func:
            mock_logger = Mock()
            mock_logger_func.return_value = mock_logger
            
            client = ApiClient(use_proxy=True, jwt_token='test_jwt')
            original_api_key = client._api_key
            
            # Clear previous warnings
            mock_logger.warning.reset_mock()
            
            client.set_api_key('ak_new_key')
            
            # Should not change
            self.assertEqual(client._api_key, original_api_key)
            
            # Should warn
            mock_logger.warning.assert_called_once()
            warning_msg = mock_logger.warning.call_args[0][0]
            self.assertIn('Cannot set API key in proxy mode', warning_msg)
    
    @patch('py_api_lib.api_client.requests.Session')
    def test_set_api_key_to_none_clears_headers(self, mock_session_class):
        """Test set_api_key(None) clears auth headers."""
        mock_session_instance = create_mock_session()
        mock_session_class.return_value = mock_session_instance
        
        client = ApiClient(api_key='ak_test_123')
        
        # Verify key is set
        self.assertIn('Authorization', client.session.headers)
        
        # Clear it
        client.set_api_key(None)
        
        self.assertIsNone(client._api_key)
        self.assertNotIn('Authorization', client.session.headers)


class TestApiClientSetJwtTokenMethod(unittest.TestCase):
    """Test set_jwt_token method with mode checks."""
    
    @patch('py_api_lib.api_client.requests.Session')
    def test_set_jwt_token_in_proxy_mode(self, mock_session_class):
        """Test set_jwt_token works in proxy mode."""
        mock_session_instance = create_mock_session()
        mock_session_class.return_value = mock_session_instance
        
        client = ApiClient(use_proxy=True, jwt_token='old_jwt')
        
        client.set_jwt_token('new_jwt_token')
        
        self.assertEqual(client._jwt_token, 'new_jwt_token')
        self.assertIn('Authorization', client.session.headers)
        self.assertEqual(client.session.headers['Authorization'], 'Bearer new_jwt_token')
    
    @patch('py_api_lib.api_client.requests.Session')
    def test_set_jwt_token_in_direct_mode_warns(self, mock_session_class):
        """Test set_jwt_token warns and doesn't change in direct mode."""
        mock_session_instance = create_mock_session()
        mock_session_class.return_value = mock_session_instance
        
        with patch('py_api_lib.api_client.get_logger') as mock_logger_func:
            mock_logger = Mock()
            mock_logger_func.return_value = mock_logger
            
            client = ApiClient(api_key='ak_test_123')
            original_jwt = client._jwt_token
            
            # Clear previous warnings
            mock_logger.warning.reset_mock()
            
            client.set_jwt_token('new_jwt')
            
            # Should not change
            self.assertEqual(client._jwt_token, original_jwt)
            
            # Should warn
            mock_logger.warning.assert_called_once()
            warning_msg = mock_logger.warning.call_args[0][0]
            self.assertIn('Cannot set JWT token in direct mode', warning_msg)
    
    @patch('py_api_lib.api_client.requests.Session')
    def test_set_jwt_token_to_none_clears_headers(self, mock_session_class):
        """Test set_jwt_token(None) clears auth headers."""
        mock_session_instance = create_mock_session()
        mock_session_class.return_value = mock_session_instance
        
        client = ApiClient(use_proxy=True, jwt_token='test_jwt')
        
        # Verify token is set
        self.assertIn('Authorization', client.session.headers)
        
        # Clear it
        client.set_jwt_token(None)
        
        self.assertIsNone(client._jwt_token)
        self.assertNotIn('Authorization', client.session.headers)


# ============================================================================
# ApiLib Proxy Mode Tests
# ============================================================================

class TestApiLibProxyModeInitialization(unittest.TestCase):
    """Test ApiLib initialization in proxy mode."""
    
    @patch('py_api_lib.api_lib.ApiClient')
    def test_direct_mode_initialization(self, mock_client_class):
        """Test ApiLib initializes correctly in direct mode."""
        mock_client = Mock()
        mock_client_class.return_value = mock_client
        
        api_lib = ApiLib(
            api_server_host='api-server',
            api_server_port='8082',
            api_key='ak_test_123'
        )
        
        # Verify ApiClient was called with correct parameters
        mock_client_class.assert_called_once()
        call_kwargs = mock_client_class.call_args[1]
        
        self.assertEqual(call_kwargs['server_ip'], 'api-server')
        self.assertEqual(call_kwargs['port'], 8082)
        self.assertEqual(call_kwargs['api_key'], 'ak_test_123')
        self.assertFalse(call_kwargs['use_proxy'])
        self.assertIsNone(call_kwargs['jwt_token'])
    
    @patch('py_api_lib.api_lib.ApiClient')
    def test_proxy_mode_initialization(self, mock_client_class):
        """Test ApiLib initializes correctly in proxy mode."""
        mock_client = Mock()
        mock_client_class.return_value = mock_client
        
        api_lib = ApiLib(
            api_server_host='platform-core',
            api_server_port='8083',
            use_proxy=True,
            jwt_token='eyJhbGc...'
        )
        
        # Verify ApiClient was called with correct parameters
        mock_client_class.assert_called_once()
        call_kwargs = mock_client_class.call_args[1]
        
        self.assertEqual(call_kwargs['server_ip'], 'platform-core')
        self.assertEqual(call_kwargs['port'], 8083)
        self.assertTrue(call_kwargs['use_proxy'])
        self.assertEqual(call_kwargs['jwt_token'], 'eyJhbGc...')
        self.assertIsNone(call_kwargs['api_key'])
    
    @patch('py_api_lib.api_lib.ApiClient')
    def test_proxy_mode_with_custom_prefix(self, mock_client_class):
        """Test proxy mode with custom prefix."""
        mock_client = Mock()
        mock_client_class.return_value = mock_client
        
        api_lib = ApiLib(
            api_server_host='platform-core',
            api_server_port='8083',
            use_proxy=True,
            proxy_prefix='/custom/prefix',
            jwt_token='test_jwt'
        )
        
        call_kwargs = mock_client_class.call_args[1]
        self.assertEqual(call_kwargs['proxy_prefix'], '/custom/prefix')


class TestApiLibAuthValidation(unittest.TestCase):
    """Test ApiLib authentication validation."""
    
    @patch('py_api_lib.api_lib.ApiClient')
    def test_validation_both_tokens_raises_error(self, mock_client_class):
        """Test that providing both tokens raises ValueError."""
        with self.assertRaises(ValueError) as context:
            ApiLib(
                api_key='ak_test_123',
                jwt_token='eyJhbGc...'
            )
        
        self.assertIn('Cannot provide both api_key and jwt_token', str(context.exception))
    
    @patch('py_api_lib.api_lib.ApiClient')
    def test_proxy_with_api_key_works(self, mock_client_class):
        """Fix U: ApiLib-level mirror of test_proxy_mode_with_api_key_works."""
        # Must not raise
        api_lib = ApiLib(
            use_proxy=True,
            api_key='ak_test_123'
        )
        # Verify ApiClient was instantiated with the expected auth config
        self.assertTrue(mock_client_class.called)
        call_kwargs = mock_client_class.call_args.kwargs if hasattr(mock_client_class.call_args, 'kwargs') else mock_client_class.call_args[1]
        self.assertTrue(call_kwargs.get('use_proxy'))
        self.assertEqual(call_kwargs.get('api_key'), 'ak_test_123')
    
    @patch('py_api_lib.api_lib.ApiClient')
    def test_direct_with_jwt_works(self, mock_client_class):
        """Fix U: ApiLib-level mirror of test_direct_mode_with_jwt_token_works."""
        # Must not raise
        api_lib = ApiLib(
            use_proxy=False,
            jwt_token='eyJhbGc...'
        )
        # Verify ApiClient was instantiated with the expected auth config
        self.assertTrue(mock_client_class.called)
        call_kwargs = mock_client_class.call_args.kwargs if hasattr(mock_client_class.call_args, 'kwargs') else mock_client_class.call_args[1]
        self.assertFalse(call_kwargs.get('use_proxy'))
        self.assertEqual(call_kwargs.get('jwt_token'), 'eyJhbGc...')


class TestApiLibFromConfigProxyMode(unittest.TestCase):
    """Test ApiLib.from_config with proxy mode configuration."""
    
    @patch('py_api_lib.api_lib.ApiClient')
    def test_from_config_with_proxy_yaml(self, mock_client_class):
        """Test loading proxy config from YAML file."""
        try:
            import yaml
        except ImportError:
            self.skipTest("PyYAML not installed")
        
        import tempfile
        
        mock_client = Mock()
        mock_client_class.return_value = mock_client
        
        # Create temp config file
        config = {
            'api_lib': {
                'api_server_host': 'platform-core',
                'api_server_port': '8083'
            },
            'proxy': {
                'enabled': True,
                'prefix': '/api/v1/crud'
            }
        }
        
        with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
            yaml.dump(config, f)
            config_file = f.name
        
        try:
            # Load from config (provide jwt_token as kwarg)
            api_lib = ApiLib.from_config(config_file, jwt_token='test_jwt')
            
            # Verify proxy config was loaded
            call_kwargs = mock_client_class.call_args[1]
            self.assertTrue(call_kwargs['use_proxy'])
            self.assertEqual(call_kwargs['proxy_prefix'], '/api/v1/crud')
            self.assertEqual(call_kwargs['jwt_token'], 'test_jwt')
        finally:
            os.unlink(config_file)
    
    @patch('py_api_lib.api_lib.ApiClient')
    def test_from_config_with_env_vars(self, mock_client_class):
        """Test loading proxy config from environment variables."""
        mock_client = Mock()
        mock_client_class.return_value = mock_client
        
        # Save original env vars
        env_keys = ['USE_PROXY', 'PROXY_PREFIX', 'JWT_TOKEN', 'API_SERVER_HOST', 'API_SERVER_PORT']
        original_env = {k: os.environ.get(k) for k in env_keys}
        
        try:
            # Set environment variables
            os.environ['USE_PROXY'] = 'true'
            os.environ['PROXY_PREFIX'] = '/custom/api'
            os.environ['JWT_TOKEN'] = 'env_jwt_token'
            os.environ['API_SERVER_HOST'] = 'platform-core-env'
            os.environ['API_SERVER_PORT'] = '9000'
            
            api_lib = ApiLib.from_config()
            
            # Verify env vars were loaded
            call_kwargs = mock_client_class.call_args[1]
            self.assertEqual(call_kwargs['server_ip'], 'platform-core-env')
            self.assertEqual(call_kwargs['port'], 9000)
            self.assertTrue(call_kwargs['use_proxy'])
            self.assertEqual(call_kwargs['proxy_prefix'], '/custom/api')
            self.assertEqual(call_kwargs['jwt_token'], 'env_jwt_token')
        finally:
            # Restore original env vars
            for key, value in original_env.items():
                if value is None:
                    os.environ.pop(key, None)
                else:
                    os.environ[key] = value

class TestApiLibProxyModeOperations(unittest.TestCase):
    """Test that ApiLib operations work correctly in proxy mode."""

    @patch('py_api_lib.api_lib.ApiClient')
    def test_crud_operations_use_correct_client(self, mock_client_class):
        """Test that CRUD operations delegate to correct ApiClient."""
        mock_client = Mock()
        mock_client._http_read.return_value = {
            'domain': {'uuid': 'test-123', 'name': 'test'}
        }
        mock_client_class.return_value = mock_client

        # Create in proxy mode
        api_lib = ApiLib(
            use_proxy=True,
            jwt_token='test_jwt'
        )

        # Mock hydration
        with patch.object(api_lib, '_hydrate_object') as mock_hydrate:
            mock_obj = Mock()
            mock_obj.clear_pending_updates = Mock()
            mock_obj.set_server_conn = Mock()
            mock_hydrate.return_value = mock_obj
            # Perform read operation
            result = api_lib._object_read('domain', id='test-123')

        # ✅ FIXED: Added api_key=None parameter
        mock_client._http_read.assert_called_once_with(
            'domain', 'test-123',
            domain_name='default-domain',
            api_key=None  # ✅ Added this
        )
        # Verify result
        self.assertEqual(result, mock_obj)

# ============================================================================
# Integration Tests
# ============================================================================

class TestProxyModeEndToEndFlow(unittest.TestCase):
    """End-to-end integration tests for proxy mode."""
    
    @patch('py_api_lib.api_client.requests.Session')
    def test_complete_proxy_flow(self, mock_session_class):
        """Test complete flow: init → make request → verify headers."""
        mock_session_instance = create_mock_session()
        mock_session_class.return_value = mock_session_instance
        
        # Create client in proxy mode
        client = ApiClient(
            server_ip='platform-core',
            port=8083,
            use_proxy=True,
            jwt_token='test_jwt_token_123'
        )
        
        # Verify configuration
        self.assertTrue(client.use_proxy)
        self.assertEqual(client.base_url, 'http://platform-core:8083/api/v1/crud')
        self.assertEqual(client._jwt_token, 'test_jwt_token_123')
        
        # Verify JWT header is set
        self.assertIn('Authorization', client.session.headers)
        self.assertEqual(
            client.session.headers['Authorization'],
            'Bearer test_jwt_token_123'
        )
        
        # Verify no API key header
        # self.assertNotIn('X-API-Key', client.session.headers)
    
    @patch('py_api_lib.api_lib.ApiClient')
    def test_apilib_proxy_flow(self, mock_client_class):
        """Test ApiLib proxy flow with client delegation."""
        mock_client = Mock()
        mock_client.use_proxy = True
        mock_client.base_url = 'http://platform-core:8083/api/v1/crud'
        mock_client_class.return_value = mock_client
        
        # Create ApiLib in proxy mode
        api_lib = ApiLib(
            api_server_host='platform-core',
            api_server_port='8083',
            use_proxy=True,
            jwt_token='test_jwt'
        )
        
        # Verify ApiClient was created with correct config
        call_kwargs = mock_client_class.call_args[1]
        self.assertTrue(call_kwargs['use_proxy'])
        self.assertEqual(call_kwargs['jwt_token'], 'test_jwt')
        
        # Verify stored configuration
        self.assertTrue(api_lib._use_proxy)
        self.assertEqual(api_lib._jwt_token, 'test_jwt')


# ============================================================================
# Test Suite
# ============================================================================

def create_proxy_mode_test_suite():
    """Create test suite for proxy mode functionality."""
    suite = unittest.TestSuite()
    
    test_classes = [
        # ApiClient tests
        TestApiClientProxyModeInitialization,
        TestApiClientAuthValidation,
        TestApiClientAuthHeaderMethods,
        TestApiClientSetApiKeyMethod,
        TestApiClientSetJwtTokenMethod,
        
        # ApiLib tests
        TestApiLibProxyModeInitialization,
        TestApiLibAuthValidation,
        TestApiLibFromConfigProxyMode,
        TestApiLibProxyModeOperations,
        
        # Integration tests
        TestProxyModeEndToEndFlow
    ]
    
    for test_class in test_classes:
        suite.addTest(unittest.TestLoader().loadTestsFromTestCase(test_class))
    
    return suite


if __name__ == '__main__':
    # Run tests with verbose output
    runner = unittest.TextTestRunner(verbosity=2)
    suite = create_proxy_mode_test_suite()
    result = runner.run(suite)
    
    # Exit with error code if tests failed
    sys.exit(0 if result.wasSuccessful() else 1)
