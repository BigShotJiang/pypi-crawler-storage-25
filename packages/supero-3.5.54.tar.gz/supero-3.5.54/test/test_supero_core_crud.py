"""
Unit tests for Supero core.py additions:
- HTTP methods: get, post, put, delete
- crud property (CrudManager access)

These tests verify the new REST API layer added to the Supero class.
"""

import unittest
from typing import Any, Dict, List, Optional


# ============================================
# Mock Classes
# ============================================

class MockPlatformClient:
    """Mock PlatformClient for testing HTTP method delegation."""
    
    def __init__(self, domain_name: str = "test-domain", domain_uuid: str = "domain-uuid-123"):
        self.domain_name = domain_name
        self.domain_uuid = domain_uuid
        self._responses: Dict[str, Any] = {}
        self._errors: Dict[str, Exception] = {}
        self._calls: List[Dict] = []
    
    def set_response(self, endpoint: str, response: Any):
        """Set mock response for an endpoint."""
        self._responses[endpoint] = response
    
    def set_error(self, endpoint: str, error: Exception):
        """Set an error to raise for an endpoint."""
        self._errors[endpoint] = error
    
    def get_calls(self) -> List[Dict]:
        """Get all recorded calls."""
        return self._calls
    
    def last_call(self) -> Optional[Dict]:
        """Get the last call made."""
        return self._calls[-1] if self._calls else None
    
    def clear_calls(self):
        """Clear recorded calls."""
        self._calls = []
    
    def _handle_call(self, method: str, endpoint: str, **kwargs) -> Any:
        """Handle a mock call - check for errors, then return response."""
        self._calls.append({
            "method": method,
            "endpoint": endpoint,
            **kwargs
        })
        
        # Check if error is set for this endpoint
        if endpoint in self._errors:
            raise self._errors[endpoint]
        
        return self._responses.get(endpoint, {"default": f"{method.lower()}_response"})
    
    def get(self, endpoint: str, params: Dict = None, **kwargs) -> Any:
        return self._handle_call("GET", endpoint, params=params, **kwargs)
    
    def post(self, endpoint: str, json: Dict = None, **kwargs) -> Any:
        return self._handle_call("POST", endpoint, json=json, **kwargs)
    
    def put(self, endpoint: str, json: Dict = None, **kwargs) -> Any:
        return self._handle_call("PUT", endpoint, json=json, **kwargs)
    
    def delete(self, endpoint: str, **kwargs) -> Any:
        return self._handle_call("DELETE", endpoint, **kwargs)


class MockCrudManager:
    """Mock CrudManager for testing crud property."""
    
    def __init__(self, supero):
        self._org = supero
        self.initialized = True
    
    def create(self, type_name: str, **data):
        return {"mock": "create", "type": type_name, **data}
    
    def list(self, type_name: str):
        return [{"mock": "list", "type": type_name}]


# Minimal Supero class with the additions we're testing
class SuperoWithAdditions:
    """
    Minimal Supero class containing just the additions we're testing.
    In real tests, this would be the actual Supero class.
    """
    
    def __init__(self, platform_client, domain_name: str = "test-domain"):
        self._platform_client = platform_client
        self.domain_name = domain_name
    
    # =========================================
    # HTTP Methods (delegate to PlatformClient)
    # =========================================
    
    def get(self, endpoint: str, params: Dict = None, **kwargs) -> Any:
        """HTTP GET request."""
        return self._platform_client.get(endpoint, params=params, **kwargs)
    
    def post(self, endpoint: str, json: Dict = None, **kwargs) -> Any:
        """HTTP POST request."""
        return self._platform_client.post(endpoint, json=json, **kwargs)
    
    def put(self, endpoint: str, json: Dict = None, **kwargs) -> Any:
        """HTTP PUT request."""
        return self._platform_client.put(endpoint, json=json, **kwargs)
    
    def delete(self, endpoint: str, **kwargs) -> Any:
        """HTTP DELETE request."""
        return self._platform_client.delete(endpoint, **kwargs)
    
    # =========================================
    # CRUD Manager (no-SDK path)
    # =========================================
    
    @property
    def crud(self):
        """CRUD operations without SDK download."""
        if not hasattr(self, '_crud_manager'):
            # In real code: from .crud_manager import CrudManager
            # self._crud_manager = CrudManager(self)
            self._crud_manager = MockCrudManager(self)
        return self._crud_manager


# ============================================
# Test Base Class
# ============================================

class SuperoTestCase(unittest.TestCase):
    """Base test case for Supero tests."""
    
    def setUp(self):
        """Set up test fixtures."""
        self.mock_client = MockPlatformClient(domain_name="test-domain")
        self.org = SuperoWithAdditions(
            platform_client=self.mock_client,
            domain_name="test-domain"
        )


# ============================================
# HTTP GET Method Tests
# ============================================

class TestSuperoHttpGet(SuperoTestCase):
    """Test Supero.get() HTTP method."""
    
    def test_get_delegates_to_platform_client(self):
        """Test that get() delegates to PlatformClient.get()."""
        self.mock_client.set_response("/test/endpoint", {"data": "test"})
        
        result = self.org.get("/test/endpoint")
        
        self.assertEqual(result, {"data": "test"})
        
        call = self.mock_client.last_call()
        self.assertEqual(call["method"], "GET")
        self.assertEqual(call["endpoint"], "/test/endpoint")
    
    def test_get_with_params(self):
        """Test get() passes query parameters."""
        self.mock_client.set_response("/crud/test-domain/task", [])
        
        self.org.get("/crud/test-domain/task", params={"limit": 10, "offset": 0})
        
        call = self.mock_client.last_call()
        self.assertEqual(call["params"]["limit"], 10)
        self.assertEqual(call["params"]["offset"], 0)
    
    def test_get_with_kwargs(self):
        """Test get() passes additional kwargs."""
        self.mock_client.set_response("/test", {})
        
        self.org.get("/test", headers={"X-Custom": "value"})
        
        call = self.mock_client.last_call()
        self.assertEqual(call["headers"]["X-Custom"], "value")
    
    def test_get_crud_endpoint(self):
        """Test get() with CRUD endpoint pattern."""
        self.mock_client.set_response(
            "/crud/test-domain/task/uuid-123",
            {"uuid": "uuid-123", "name": "task-1", "title": "Test Task"}
        )
        
        result = self.org.get("/crud/test-domain/task/uuid-123")
        
        self.assertEqual(result["uuid"], "uuid-123")
        self.assertEqual(result["name"], "task-1")
    
    def test_get_returns_list(self):
        """Test get() can return list response."""
        self.mock_client.set_response(
            "/crud/test-domain/task",
            [{"uuid": "1"}, {"uuid": "2"}]
        )
        
        result = self.org.get("/crud/test-domain/task")
        
        self.assertIsInstance(result, list)
        self.assertEqual(len(result), 2)


# ============================================
# HTTP POST Method Tests
# ============================================

class TestSuperoHttpPost(SuperoTestCase):
    """Test Supero.post() HTTP method."""
    
    def test_post_delegates_to_platform_client(self):
        """Test that post() delegates to PlatformClient.post()."""
        self.mock_client.set_response("/test/endpoint", {"created": True})
        
        result = self.org.post("/test/endpoint", json={"data": "test"})
        
        self.assertEqual(result, {"created": True})
        
        call = self.mock_client.last_call()
        self.assertEqual(call["method"], "POST")
        self.assertEqual(call["endpoint"], "/test/endpoint")
    
    def test_post_with_json_body(self):
        """Test post() passes JSON body."""
        self.mock_client.set_response("/crud/test-domain/task", {"uuid": "new-uuid"})
        
        self.org.post("/crud/test-domain/task", json={
            "name": "task-1",
            "title": "Test Task",
            "priority": "high"
        })
        
        call = self.mock_client.last_call()
        self.assertEqual(call["json"]["name"], "task-1")
        self.assertEqual(call["json"]["title"], "Test Task")
        self.assertEqual(call["json"]["priority"], "high")
    
    def test_post_with_kwargs(self):
        """Test post() passes additional kwargs."""
        self.mock_client.set_response("/test", {})
        
        self.org.post("/test", json={}, headers={"Authorization": "Bearer token"})
        
        call = self.mock_client.last_call()
        self.assertEqual(call["headers"]["Authorization"], "Bearer token")
    
    def test_post_without_json(self):
        """Test post() works without JSON body."""
        self.mock_client.set_response("/test/action", {"success": True})
        
        result = self.org.post("/test/action")
        
        call = self.mock_client.last_call()
        self.assertIsNone(call["json"])
    
    def test_post_create_object(self):
        """Test post() for creating objects."""
        self.mock_client.set_response(
            "/crud/test-domain/task",
            {"uuid": "task-uuid-123", "name": "task-1", "title": "Created Task"}
        )
        
        result = self.org.post("/crud/test-domain/task", json={
            "name": "task-1",
            "title": "Created Task",
            "fq_name": ["test-domain", "task-1"],
            "parent_type": "domain"
        })
        
        self.assertEqual(result["uuid"], "task-uuid-123")


# ============================================
# HTTP PUT Method Tests
# ============================================

class TestSuperoHttpPut(SuperoTestCase):
    """Test Supero.put() HTTP method."""
    
    def test_put_delegates_to_platform_client(self):
        """Test that put() delegates to PlatformClient.put()."""
        self.mock_client.set_response("/test/endpoint", {"updated": True})
        
        result = self.org.put("/test/endpoint", json={"data": "test"})
        
        self.assertEqual(result, {"updated": True})
        
        call = self.mock_client.last_call()
        self.assertEqual(call["method"], "PUT")
        self.assertEqual(call["endpoint"], "/test/endpoint")
    
    def test_put_with_json_body(self):
        """Test put() passes JSON body."""
        self.mock_client.set_response("/crud/test-domain/task/uuid-123", {"uuid": "uuid-123", "done": True})
        
        self.org.put("/crud/test-domain/task/uuid-123", json={"done": True, "priority": "low"})
        
        call = self.mock_client.last_call()
        self.assertEqual(call["json"]["done"], True)
        self.assertEqual(call["json"]["priority"], "low")
    
    def test_put_with_kwargs(self):
        """Test put() passes additional kwargs."""
        self.mock_client.set_response("/test", {})
        
        self.org.put("/test", json={}, timeout=30)
        
        call = self.mock_client.last_call()
        self.assertEqual(call["timeout"], 30)
    
    def test_put_update_object(self):
        """Test put() for updating objects."""
        self.mock_client.set_response(
            "/crud/test-domain/task/task-uuid",
            {"uuid": "task-uuid", "done": True, "title": "Updated"}
        )
        
        result = self.org.put("/crud/test-domain/task/task-uuid", json={
            "done": True,
            "title": "Updated"
        })
        
        self.assertEqual(result["done"], True)
        self.assertEqual(result["title"], "Updated")


# ============================================
# HTTP DELETE Method Tests
# ============================================

class TestSuperoHttpDelete(SuperoTestCase):
    """Test Supero.delete() HTTP method."""
    
    def test_delete_delegates_to_platform_client(self):
        """Test that delete() delegates to PlatformClient.delete()."""
        self.mock_client.set_response("/test/endpoint", {"deleted": True})
        
        result = self.org.delete("/test/endpoint")
        
        self.assertEqual(result, {"deleted": True})
        
        call = self.mock_client.last_call()
        self.assertEqual(call["method"], "DELETE")
        self.assertEqual(call["endpoint"], "/test/endpoint")
    
    def test_delete_with_kwargs(self):
        """Test delete() passes additional kwargs."""
        self.mock_client.set_response("/test", {})
        
        self.org.delete("/test", headers={"X-Confirm": "true"})
        
        call = self.mock_client.last_call()
        self.assertEqual(call["headers"]["X-Confirm"], "true")
    
    def test_delete_object(self):
        """Test delete() for deleting objects."""
        self.mock_client.set_response(
            "/crud/test-domain/task/task-uuid",
            {"deleted": True, "uuid": "task-uuid"}
        )
        
        result = self.org.delete("/crud/test-domain/task/task-uuid")
        
        self.assertTrue(result["deleted"])
    
    def test_delete_no_body(self):
        """Test delete() sends no body by default."""
        self.mock_client.set_response("/test", {})
        
        self.org.delete("/test")
        
        call = self.mock_client.last_call()
        self.assertNotIn("json", call)


# ============================================
# CRUD Property Tests
# ============================================

class TestSuperoCrudProperty(SuperoTestCase):
    """Test Supero.crud property."""
    
    def test_crud_returns_crud_manager(self):
        """Test that crud property returns CrudManager instance."""
        crud = self.org.crud
        
        # In real tests, would check: self.assertIsInstance(crud, CrudManager)
        self.assertIsNotNone(crud)
        self.assertTrue(hasattr(crud, 'initialized'))
    
    def test_crud_lazy_initialization(self):
        """Test that CrudManager is lazily initialized."""
        # Before accessing crud, _crud_manager should not exist
        self.assertFalse(hasattr(self.org, '_crud_manager'))
        
        # Access crud property
        crud = self.org.crud
        
        # Now _crud_manager should exist
        self.assertTrue(hasattr(self.org, '_crud_manager'))
        self.assertIsNotNone(self.org._crud_manager)
    
    def test_crud_same_instance(self):
        """Test that crud property returns same instance on multiple accesses."""
        crud1 = self.org.crud
        crud2 = self.org.crud
        
        self.assertIs(crud1, crud2)
    
    def test_crud_receives_supero_instance(self):
        """Test that CrudManager receives Supero instance."""
        crud = self.org.crud
        
        self.assertIs(crud._org, self.org)
    
    def test_crud_can_call_methods(self):
        """Test that crud manager methods are callable."""
        crud = self.org.crud
        
        # Test create (mocked)
        result = crud.create("task", name="t1", title="Test")
        self.assertEqual(result["mock"], "create")
        self.assertEqual(result["type"], "task")
        
        # Test list (mocked)
        result = crud.list("task")
        self.assertIsInstance(result, list)


# ============================================
# HTTP Methods with CRUD Patterns Tests
# ============================================

class TestSuperoHttpMethodsCrudPatterns(SuperoTestCase):
    """Test HTTP methods with common CRUD endpoint patterns."""
    
    def test_crud_list_pattern(self):
        """Test GET /crud/{domain}/{type} pattern."""
        self.mock_client.set_response(
            "/crud/test-domain/task",
            [{"uuid": "1", "name": "task-1"}, {"uuid": "2", "name": "task-2"}]
        )
        
        result = self.org.get("/crud/test-domain/task", params={"limit": 100})
        
        self.assertEqual(len(result), 2)
    
    def test_crud_get_pattern(self):
        """Test GET /crud/{domain}/{type}/{uuid} pattern."""
        self.mock_client.set_response(
            "/crud/test-domain/task/uuid-123",
            {"uuid": "uuid-123", "name": "task-1"}
        )
        
        result = self.org.get("/crud/test-domain/task/uuid-123")
        
        self.assertEqual(result["uuid"], "uuid-123")
    
    def test_crud_create_pattern(self):
        """Test POST /crud/{domain}/{type} pattern."""
        self.mock_client.set_response(
            "/crud/test-domain/task",
            {"uuid": "new-uuid", "name": "task-1"}
        )
        
        result = self.org.post("/crud/test-domain/task", json={
            "name": "task-1",
            "title": "New Task"
        })
        
        self.assertEqual(result["uuid"], "new-uuid")
    
    def test_crud_update_pattern(self):
        """Test PUT /crud/{domain}/{type}/{uuid} pattern."""
        self.mock_client.set_response(
            "/crud/test-domain/task/uuid-123",
            {"uuid": "uuid-123", "done": True}
        )
        
        result = self.org.put("/crud/test-domain/task/uuid-123", json={"done": True})
        
        self.assertTrue(result["done"])
    
    def test_crud_delete_pattern(self):
        """Test DELETE /crud/{domain}/{type}/{uuid} pattern."""
        self.mock_client.set_response(
            "/crud/test-domain/task/uuid-123",
            {"deleted": True}
        )
        
        result = self.org.delete("/crud/test-domain/task/uuid-123")
        
        self.assertTrue(result["deleted"])
    
    def test_crud_query_pattern(self):
        """Test POST /crud/{domain}/{type}/query pattern."""
        self.mock_client.set_response(
            "/crud/test-domain/task/query",
            [{"uuid": "1", "done": False}]
        )
        
        result = self.org.post("/crud/test-domain/task/query", json={
            "filters": {"done": False},
            "order_by": ["-created_at"],
            "limit": 10
        })
        
        self.assertEqual(len(result), 1)
        
        call = self.mock_client.last_call()
        self.assertEqual(call["json"]["filters"]["done"], False)
    
    def test_crud_aggregate_pattern(self):
        """Test POST /crud/{domain}/{type}/aggregate pattern."""
        self.mock_client.set_response(
            "/crud/test-domain/order/aggregate",
            {"sum": 9999.99}
        )
        
        result = self.org.post("/crud/test-domain/order/aggregate", json={
            "op": "sum",
            "field": "amount"
        })
        
        self.assertEqual(result["sum"], 9999.99)
    
    def test_crud_ref_pattern(self):
        """Test POST /crud/{domain}/{type}/{uuid}/ref pattern."""
        self.mock_client.set_response(
            "/crud/test-domain/order/order-uuid/ref",
            {"uuid": "order-uuid", "customer_refs": ["customer-uuid"]}
        )
        
        result = self.org.post("/crud/test-domain/order/order-uuid/ref", json={
            "ref_field": "customer",
            "ref_uuid": "customer-uuid"
        })
        
        self.assertIn("customer-uuid", result["customer_refs"])
    
    def test_crud_bulk_create_pattern(self):
        """Test POST /crud/{domain}/{type}/bulk-create pattern."""
        self.mock_client.set_response(
            "/crud/test-domain/task/bulk-create",
            {"created": [{"uuid": "1"}, {"uuid": "2"}]}
        )
        
        result = self.org.post("/crud/test-domain/task/bulk-create", json={
            "items": [
                {"name": "t1", "title": "Task 1"},
                {"name": "t2", "title": "Task 2"}
            ]
        })
        
        self.assertEqual(len(result["created"]), 2)


# ============================================
# Edge Cases and Error Handling Tests
# ============================================

class TestSuperoHttpMethodsEdgeCases(SuperoTestCase):
    """Test edge cases for HTTP methods."""
    
    def test_get_empty_params(self):
        """Test get() with empty params dict."""
        self.mock_client.set_response("/test", {})
        
        self.org.get("/test", params={})
        
        call = self.mock_client.last_call()
        self.assertEqual(call["params"], {})
    
    def test_post_empty_json(self):
        """Test post() with empty JSON body."""
        self.mock_client.set_response("/test", {})
        
        self.org.post("/test", json={})
        
        call = self.mock_client.last_call()
        self.assertEqual(call["json"], {})
    
    def test_put_empty_json(self):
        """Test put() with empty JSON body."""
        self.mock_client.set_response("/test", {})
        
        self.org.put("/test", json={})
        
        call = self.mock_client.last_call()
        self.assertEqual(call["json"], {})
    
    def test_multiple_http_calls(self):
        """Test multiple HTTP calls are tracked."""
        self.mock_client.set_response("/a", {"a": 1})
        self.mock_client.set_response("/b", {"b": 2})
        self.mock_client.set_response("/c", {"c": 3})
        
        self.org.get("/a")
        self.org.post("/b", json={})
        self.org.delete("/c")
        
        calls = self.mock_client.get_calls()
        self.assertEqual(len(calls), 3)
        self.assertEqual(calls[0]["method"], "GET")
        self.assertEqual(calls[1]["method"], "POST")
        self.assertEqual(calls[2]["method"], "DELETE")
    
    def test_special_characters_in_endpoint(self):
        """Test endpoints with special characters."""
        self.mock_client.set_response("/crud/my-domain/task", {})
        
        self.org.get("/crud/my-domain/task")
        
        call = self.mock_client.last_call()
        self.assertEqual(call["endpoint"], "/crud/my-domain/task")
    
    def test_get_none_params(self):
        """Test get() with None params (default)."""
        self.mock_client.set_response("/test", {})
        
        self.org.get("/test")
        
        call = self.mock_client.last_call()
        self.assertIsNone(call["params"])
    
    def test_post_none_json(self):
        """Test post() with None json (default)."""
        self.mock_client.set_response("/test", {})
        
        self.org.post("/test")
        
        call = self.mock_client.last_call()
        self.assertIsNone(call["json"])


# ============================================
# Integration Tests
# ============================================

class TestSuperoHttpCrudIntegration(SuperoTestCase):
    """Integration tests for HTTP methods with crud property."""
    
    def test_crud_uses_http_methods(self):
        """Test that crud manager would use Supero's HTTP methods."""
        # The crud manager receives self.org which has get/post/put/delete
        crud = self.org.crud
        
        # Verify crud._org is the Supero instance with HTTP methods
        self.assertTrue(hasattr(crud._org, 'get'))
        self.assertTrue(hasattr(crud._org, 'post'))
        self.assertTrue(hasattr(crud._org, 'put'))
        self.assertTrue(hasattr(crud._org, 'delete'))
    
    def test_workflow_create_then_get(self):
        """Test create then get workflow."""
        # Create
        self.mock_client.set_response(
            "/crud/test-domain/task",
            {"uuid": "task-uuid", "name": "task-1"}
        )
        create_result = self.org.post("/crud/test-domain/task", json={
            "name": "task-1",
            "title": "Test"
        })
        
        # Get
        self.mock_client.set_response(
            "/crud/test-domain/task/task-uuid",
            {"uuid": "task-uuid", "name": "task-1", "title": "Test"}
        )
        get_result = self.org.get(f"/crud/test-domain/task/{create_result['uuid']}")
        
        self.assertEqual(get_result["uuid"], create_result["uuid"])
    
    def test_workflow_update_then_delete(self):
        """Test update then delete workflow."""
        # Update
        self.mock_client.set_response(
            "/crud/test-domain/task/uuid-123",
            {"uuid": "uuid-123", "done": True}
        )
        self.org.put("/crud/test-domain/task/uuid-123", json={"done": True})
        
        # Delete
        self.mock_client.set_response(
            "/crud/test-domain/task/uuid-123",
            {"deleted": True}
        )
        result = self.org.delete("/crud/test-domain/task/uuid-123")
        
        self.assertTrue(result["deleted"])


# ============================================
# Error Handling Tests
# ============================================

class TestSuperoHttpMethodsErrors(SuperoTestCase):
    """Test error handling for HTTP methods."""
    
    def test_get_raises_on_error(self):
        """Test that get() propagates exceptions."""
        self.mock_client.set_error("/test/error", ValueError("Not found"))
        
        with self.assertRaises(ValueError) as ctx:
            self.org.get("/test/error")
        
        self.assertIn("Not found", str(ctx.exception))
    
    def test_post_raises_on_error(self):
        """Test that post() propagates exceptions."""
        self.mock_client.set_error("/test/error", ConnectionError("Server unavailable"))
        
        with self.assertRaises(ConnectionError) as ctx:
            self.org.post("/test/error", json={"data": "test"})
        
        self.assertIn("Server unavailable", str(ctx.exception))
    
    def test_put_raises_on_error(self):
        """Test that put() propagates exceptions."""
        self.mock_client.set_error("/test/error", PermissionError("Access denied"))
        
        with self.assertRaises(PermissionError) as ctx:
            self.org.put("/test/error", json={"data": "test"})
        
        self.assertIn("Access denied", str(ctx.exception))
    
    def test_delete_raises_on_error(self):
        """Test that delete() propagates exceptions."""
        self.mock_client.set_error("/test/error", RuntimeError("Delete failed"))
        
        with self.assertRaises(RuntimeError) as ctx:
            self.org.delete("/test/error")
        
        self.assertIn("Delete failed", str(ctx.exception))
    
    def test_http_404_simulation(self):
        """Test handling of 404-like errors."""
        class HttpError(Exception):
            def __init__(self, status_code, message):
                self.status_code = status_code
                super().__init__(message)
        
        self.mock_client.set_error(
            "/crud/test-domain/task/nonexistent",
            HttpError(404, "Object not found")
        )
        
        with self.assertRaises(HttpError) as ctx:
            self.org.get("/crud/test-domain/task/nonexistent")
        
        self.assertEqual(ctx.exception.status_code, 404)
    
    def test_http_500_simulation(self):
        """Test handling of 500-like errors."""
        class HttpError(Exception):
            def __init__(self, status_code, message):
                self.status_code = status_code
                super().__init__(message)
        
        self.mock_client.set_error(
            "/crud/test-domain/task",
            HttpError(500, "Internal server error")
        )
        
        with self.assertRaises(HttpError) as ctx:
            self.org.post("/crud/test-domain/task", json={"name": "test"})
        
        self.assertEqual(ctx.exception.status_code, 500)


# ============================================
# Additional CRUD Endpoint Pattern Tests
# ============================================

class TestSuperoHttpMethodsAdditionalPatterns(SuperoTestCase):
    """Test additional CRUD endpoint patterns."""
    
    def test_crud_bulk_get_pattern(self):
        """Test POST /crud/{domain}/{type}/bulk-get pattern."""
        self.mock_client.set_response(
            "/crud/test-domain/task/bulk-get",
            [{"uuid": "1"}, {"uuid": "2"}, {"uuid": "3"}]
        )
        
        result = self.org.post("/crud/test-domain/task/bulk-get", json={
            "uuids": ["1", "2", "3"]
        })
        
        self.assertEqual(len(result), 3)
        
        call = self.mock_client.last_call()
        self.assertEqual(call["json"]["uuids"], ["1", "2", "3"])
    
    def test_crud_bulk_update_pattern(self):
        """Test POST /crud/{domain}/{type}/bulk-update pattern."""
        self.mock_client.set_response(
            "/crud/test-domain/task/bulk-update",
            {"updated": [{"uuid": "1", "done": True}, {"uuid": "2", "done": True}]}
        )
        
        result = self.org.post("/crud/test-domain/task/bulk-update", json={
            "updates": [
                {"uuid": "1", "done": True},
                {"uuid": "2", "done": True}
            ]
        })
        
        self.assertEqual(len(result["updated"]), 2)
    
    def test_crud_bulk_delete_pattern(self):
        """Test POST /crud/{domain}/{type}/bulk-delete pattern."""
        self.mock_client.set_response(
            "/crud/test-domain/task/bulk-delete",
            {"deleted": 3}
        )
        
        result = self.org.post("/crud/test-domain/task/bulk-delete", json={
            "uuids": ["1", "2", "3"]
        })
        
        self.assertEqual(result["deleted"], 3)
    
    def test_crud_ref_get_pattern(self):
        """Test GET /crud/{domain}/{type}/{uuid}/ref/{field} pattern."""
        self.mock_client.set_response(
            "/crud/test-domain/order/order-uuid/ref/customer",
            {"target": {"uuid": "cust-uuid"}, "link_data": {"role": "primary"}}
        )
        
        result = self.org.get("/crud/test-domain/order/order-uuid/ref/customer")
        
        self.assertEqual(result["target"]["uuid"], "cust-uuid")
        self.assertEqual(result["link_data"]["role"], "primary")
    
    def test_crud_ref_update_pattern(self):
        """Test PUT /crud/{domain}/{type}/{uuid}/ref pattern."""
        self.mock_client.set_response(
            "/crud/test-domain/order/order-uuid/ref",
            {"uuid": "order-uuid", "updated": True}
        )
        
        result = self.org.put("/crud/test-domain/order/order-uuid/ref", json={
            "ref_field": "customer",
            "link_data": {"role": "secondary"}
        })
        
        self.assertTrue(result["updated"])
    
    def test_crud_ref_delete_pattern(self):
        """Test DELETE /crud/{domain}/{type}/{uuid}/ref/{field} pattern."""
        self.mock_client.set_response(
            "/crud/test-domain/order/order-uuid/ref/customer",
            {"deleted": True}
        )
        
        result = self.org.delete("/crud/test-domain/order/order-uuid/ref/customer")
        
        self.assertTrue(result["deleted"])
    
    def test_crud_by_fq_name_pattern(self):
        """Test POST /crud/{domain}/{type}/by-fq-name pattern."""
        self.mock_client.set_response(
            "/crud/test-domain/task/by-fq-name",
            {"uuid": "task-uuid", "fq_name": ["test-domain", "task-1"]}
        )
        
        result = self.org.post("/crud/test-domain/task/by-fq-name", json={
            "fq_name": ["test-domain", "task-1"]
        })
        
        self.assertEqual(result["uuid"], "task-uuid")
    
    def test_crud_delete_all_pattern(self):
        """Test POST /crud/{domain}/{type}/delete-all pattern."""
        self.mock_client.set_response(
            "/crud/test-domain/task/delete-all",
            {"deleted": 15}
        )
        
        result = self.org.post("/crud/test-domain/task/delete-all", json={
            "filters": {"done": True}
        })
        
        self.assertEqual(result["deleted"], 15)


# ============================================
# Additional Edge Case Tests
# ============================================

class TestSuperoHttpPutAdditional(SuperoTestCase):
    """Additional tests for PUT method."""
    
    def test_put_without_json(self):
        """Test put() works without JSON body."""
        self.mock_client.set_response("/test/action", {"success": True})
        
        result = self.org.put("/test/action")
        
        call = self.mock_client.last_call()
        self.assertIsNone(call["json"])


# ============================================
# Run Tests
# ============================================

if __name__ == "__main__":
    unittest.main(verbosity=2)
