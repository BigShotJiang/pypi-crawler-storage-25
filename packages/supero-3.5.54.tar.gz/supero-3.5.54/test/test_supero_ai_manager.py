"""
Unit Tests for AIManager - AI Service Integration

Tests:
- AIManager initialization and configuration
- Chat functionality (sync and streaming)
- Session management
- Tool management
- Vector search (RAG)
- Convenience methods (ask, query, summarize, explain)
- Error handling
"""
import unittest
from unittest.mock import Mock, MagicMock, patch
import sys
import os
import json
from datetime import datetime

# Add src to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '../src'))

from supero.ai_manager import (
    AIManager,
    SessionManager,
    ToolManager,
    VectorManager,
    ChatResponse,
    Session,
    Tool,
    ToolResult,
    VectorSearchResult,
    Message,
    MessageRole,
    create_ai_manager
)

class MockPlatformClient:
    """Mock Platform Client for testing AI Manager"""

    def __init__(self, domain_name="test-domain", domain_uuid="test-uuid-123"):
        """Initialize mock client with domain context (v2.0 pattern)"""
        self.domain_name = domain_name
        self.domain_uuid = domain_uuid
        self.project_name = "test-project"
        self.project_uuid = "project-uuid-456"
        self.tenant_name = "test-tenant"
        self.tenant_uuid = "tenant-uuid-789"
        self.user_uuid = "user-uuid-abc"
        self.user_email = "test@example.com"
        self.username = "testuser"
        self.call_history = []
        self.responses = {}
        self.stream_responses = {}

    def set_response(self, method: str, endpoint: str, response: dict):
        """Set mock response for endpoint"""
        key = f"{method}:{endpoint}"
        self.responses[key] = response

    def set_stream_response(self, method: str, endpoint: str, chunks: list):
        """Set mock streaming response for endpoint"""
        key = f"{method}:{endpoint}"
        self.stream_responses[key] = chunks

    def get(self, endpoint: str, params: dict = None):
        """Mock GET request"""
        self.call_history.append({
            "method": "GET",
            "endpoint": endpoint,
            "params": params
        })
        key = f"GET:{endpoint}"
        if key in self.responses:
            return self.responses[key]
        return {}

    def post(self, endpoint: str, json: dict = None, data: dict = None, files: dict = None):
        """Mock POST request"""
        self.call_history.append({
            "method": "POST",
            "endpoint": endpoint,
            "json": json,
            "data": data,
            "files": files
        })
        key = f"POST:{endpoint}"
        if key in self.responses:
            return self.responses[key]
        return {}

    def put(self, endpoint: str, json: dict = None):
        """Mock PUT request"""
        self.call_history.append({
            "method": "PUT",
            "endpoint": endpoint,
            "json": json
        })
        key = f"PUT:{endpoint}"
        if key in self.responses:
            return self.responses[key]
        return {}

    def delete(self, endpoint: str, params: dict = None):
        """Mock DELETE request"""
        self.call_history.append({
            "method": "DELETE",
            "endpoint": endpoint,
            "params": params
        })
        key = f"DELETE:{endpoint}"
        if key in self.responses:
            return self.responses[key]
        return {"success": True}

    def stream_request(self, method: str, endpoint: str, json_data: dict = None, **kwargs):
        """Mock streaming request - yields chunks"""
        self.call_history.append({
            "method": f"STREAM_{method}",
            "endpoint": endpoint,
            "json_data": json_data
        })
        key = f"{method}:{endpoint}"
        if key in self.stream_responses:
            for chunk in self.stream_responses[key]:
                yield chunk
        else:
            yield "Mock streaming response"

# ============================================================================
# Data Model Tests
# ============================================================================

class TestDataModels(unittest.TestCase):
    """Test AI Manager data models"""

    def test_message_role_enum(self):
        """Test MessageRole enum values"""
        self.assertEqual(MessageRole.USER.value, "user")
        self.assertEqual(MessageRole.ASSISTANT.value, "assistant")
        self.assertEqual(MessageRole.SYSTEM.value, "system")
        self.assertEqual(MessageRole.TOOL.value, "tool")

    def test_message_to_dict(self):
        """Test Message serialization"""
        msg = Message(
            role=MessageRole.USER,
            content="Hello, AI!",
            tool_calls=[{"name": "test"}],
            tool_call_id="call-123",
            name="user_message"
        )
        
        data = msg.to_dict()
        
        self.assertEqual(data["role"], "user")
        self.assertEqual(data["content"], "Hello, AI!")
        self.assertEqual(data["tool_calls"], [{"name": "test"}])
        self.assertEqual(data["tool_call_id"], "call-123")
        self.assertEqual(data["name"], "user_message")

    def test_message_from_dict(self):
        """Test Message deserialization"""
        data = {
            "role": "assistant",
            "content": "Hello! How can I help?",
            "tool_calls": None,
            "timestamp": "2024-01-15T10:30:00"
        }
        
        msg = Message.from_dict(data)
        
        self.assertEqual(msg.role, MessageRole.ASSISTANT)
        self.assertEqual(msg.content, "Hello! How can I help?")
        self.assertIsNone(msg.tool_calls)
        self.assertIsNotNone(msg.timestamp)

    def test_chat_response_from_dict(self):
        """Test ChatResponse deserialization"""
        data = {
            "content": "Here are your projects...",
            "role": "assistant",
            "tool_calls": [{"name": "list_projects", "arguments": {}}],
            "tool_results": [{"projects": []}],
            "session_id": "session-123",
            "usage": {"input_tokens": 100, "output_tokens": 50},
            "model": "claude-sonnet-4-20250514"
        }
        
        response = ChatResponse.from_dict(data)
        
        self.assertEqual(response.content, "Here are your projects...")
        self.assertEqual(response.role, MessageRole.ASSISTANT)
        self.assertIsNotNone(response.tool_calls)
        self.assertEqual(response.session_id, "session-123")
        self.assertEqual(response.model, "claude-sonnet-4-20250514")

    def test_session_from_dict(self):
        """Test Session deserialization"""
        data = {
            "session_id": "sess-456",
            "domain_name": "acme-corp",
            "created_at": "2024-01-15T10:00:00",
            "updated_at": "2024-01-15T11:00:00",
            "message_count": 5,
            "metadata": {"purpose": "testing"}
        }
        
        session = Session.from_dict(data)
        
        self.assertEqual(session.id, "sess-456")
        self.assertEqual(session.domain_name, "acme-corp")
        self.assertEqual(session.message_count, 5)
        self.assertEqual(session.metadata["purpose"], "testing")

    def test_tool_from_dict(self):
        """Test Tool deserialization"""
        data = {
            "name": "list_projects",
            "description": "List all projects with optional filters",
            "parameters": {
                "type": "object",
                "properties": {
                    "status": {"type": "string"}
                }
            },
            "schema_name": "Project",
            "operation": "list"
        }
        
        tool = Tool.from_dict(data)
        
        self.assertEqual(tool.name, "list_projects")
        self.assertEqual(tool.description, "List all projects with optional filters")
        self.assertEqual(tool.schema_name, "Project")
        self.assertEqual(tool.operation, "list")

    def test_tool_result_from_dict(self):
        """Test ToolResult deserialization"""
        data = {
            "tool_name": "list_projects",
            "success": True,
            "result": [{"name": "Project A"}, {"name": "Project B"}],
            "error": None,
            "execution_time_ms": 150.5
        }
        
        result = ToolResult.from_dict(data)
        
        self.assertEqual(result.tool_name, "list_projects")
        self.assertTrue(result.success)
        self.assertEqual(len(result.result), 2)
        self.assertIsNone(result.error)
        self.assertEqual(result.execution_time_ms, 150.5)

    def test_tool_result_error(self):
        """Test ToolResult with error"""
        data = {
            "tool_name": "create_project",
            "success": False,
            "result": None,
            "error": "Validation failed: name is required"
        }
        
        result = ToolResult.from_dict(data)
        
        self.assertFalse(result.success)
        self.assertIsNone(result.result)
        self.assertIn("Validation failed", result.error)

    def test_vector_search_result_from_dict(self):
        """Test VectorSearchResult deserialization"""
        data = {
            "id": "doc-789",
            "content": "Project Alpha is our main backend...",
            "score": 0.95,
            "metadata": {"type": "project_doc", "project_id": "uuid-123"}
        }
        
        result = VectorSearchResult.from_dict(data)
        
        self.assertEqual(result.id, "doc-789")
        self.assertIn("Project Alpha", result.content)
        self.assertEqual(result.score, 0.95)
        self.assertEqual(result.metadata["type"], "project_doc")


# ============================================================================
# AIManager Basic Tests
# ============================================================================

class TestAIManagerBasic(unittest.TestCase):
    """Test basic AIManager functionality"""

    def setUp(self):
        """Setup test fixtures"""
        self.mock_client = MockPlatformClient()
        self.domain_name = "test-domain"
        self.ai_manager = AIManager(
            platform_client=self.mock_client
        )

    def test_initialization(self):
        """Test AIManager initializes correctly"""
        self.assertEqual(self.ai_manager._domain_name, "test-domain")
        self.assertIsNotNone(self.ai_manager._platform_client)
        self.assertIsNotNone(self.ai_manager._logger)
        
        # Default settings
        self.assertIsNone(self.ai_manager._default_model)
        self.assertEqual(self.ai_manager._default_max_tokens, 4000)
        self.assertEqual(self.ai_manager._default_temperature, 0.7)

    def test_configure(self):
        """Test AIManager configuration"""
        result = self.ai_manager.configure(
            model="claude-sonnet-4-20250514",
            max_tokens=8000,
            temperature=0.5
        )
        
        self.assertEqual(self.ai_manager._default_model, "claude-sonnet-4-20250514")
        self.assertEqual(self.ai_manager._default_max_tokens, 8000)
        self.assertEqual(self.ai_manager._default_temperature, 0.5)
        
        # Should return self for chaining
        self.assertEqual(result, self.ai_manager)

    def test_configure_partial(self):
        """Test AIManager partial configuration"""
        self.ai_manager.configure(model="gpt-4-turbo")
        
        self.assertEqual(self.ai_manager._default_model, "gpt-4-turbo")
        # Other settings unchanged
        self.assertEqual(self.ai_manager._default_max_tokens, 4000)
        self.assertEqual(self.ai_manager._default_temperature, 0.7)

    def test_lazy_loaded_sessions(self):
        """Test sessions property is lazy-loaded"""
        self.assertIsNone(self.ai_manager._sessions)
        
        sessions = self.ai_manager.sessions
        
        self.assertIsNotNone(self.ai_manager._sessions)
        self.assertIsInstance(sessions, SessionManager)
        
        # Second access should return same instance
        self.assertIs(self.ai_manager.sessions, sessions)

    def test_lazy_loaded_tools(self):
        """Test tools property is lazy-loaded"""
        self.assertIsNone(self.ai_manager._tools)
        
        tools = self.ai_manager.tools
        
        self.assertIsNotNone(self.ai_manager._tools)
        self.assertIsInstance(tools, ToolManager)

    def test_lazy_loaded_vectors(self):
        """Test vectors property is lazy-loaded"""
        self.assertIsNone(self.ai_manager._vectors)
        
        vectors = self.ai_manager.vectors
        
        self.assertIsNotNone(self.ai_manager._vectors)
        self.assertIsInstance(vectors, VectorManager)


# ============================================================================
# Chat Tests
# ============================================================================

class TestAIManagerChat(unittest.TestCase):
    """Test AIManager chat functionality"""

    def setUp(self):
        """Setup test fixtures"""
        self.mock_client = MockPlatformClient()
        self.domain_name = "test-domain"
        self.ai_manager = AIManager(
            platform_client=self.mock_client
        )

    def test_chat_basic(self):
        """Test basic chat"""
        self.mock_client.set_response(
            "POST", "/ai/v1/chat",
            {
                "content": "You have 5 active projects.",
                "role": "assistant",
                "model": "claude-sonnet-4-20250514"
            }
        )
        
        response = self.ai_manager.chat("How many active projects do I have?")
        
        self.assertEqual(response.content, "You have 5 active projects.")
        self.assertEqual(response.role, MessageRole.ASSISTANT)
        
        # Verify API call
        call = self.mock_client.call_history[0]
        self.assertEqual(call["method"], "POST")
        self.assertEqual(call["endpoint"], "/ai/v1/chat")
        self.assertEqual(call["json"]["message"], "How many active projects do I have?")
        self.assertEqual(call["json"]["domain_name"], "test-domain")
        self.assertTrue(call["json"]["tools_enabled"])

    def test_chat_with_session(self):
        """Test chat with session ID"""
        self.mock_client.set_response(
            "POST", "/ai/v1/chat",
            {
                "content": "Creating task for Project Alpha...",
                "role": "assistant",
                "session_id": "session-123"
            }
        )
        
        response = self.ai_manager.chat(
            "Create a task for the first project",
            session_id="session-123"
        )
        
        self.assertEqual(response.session_id, "session-123")
        
        call = self.mock_client.call_history[0]
        self.assertEqual(call["json"]["session_id"], "session-123")

    def test_chat_with_context(self):
        """Test chat with additional context"""
        self.mock_client.set_response(
            "POST", "/ai/v1/chat",
            {"content": "Based on budget constraints...", "role": "assistant"}
        )
        
        self.ai_manager.chat(
            "Summarize this project",
            context="Focus on timeline and budget"
        )
        
        call = self.mock_client.call_history[0]
        self.assertEqual(call["json"]["context"], "Focus on timeline and budget")

    def test_chat_tools_disabled(self):
        """Test chat with tools disabled"""
        self.mock_client.set_response(
            "POST", "/ai/v1/chat",
            {"content": "Here's a general explanation...", "role": "assistant"}
        )
        
        self.ai_manager.chat("What is machine learning?", tools_enabled=False)
        
        call = self.mock_client.call_history[0]
        self.assertFalse(call["json"]["tools_enabled"])

    def test_chat_with_model_override(self):
        """Test chat with model override"""
        self.mock_client.set_response(
            "POST", "/ai/v1/chat",
            {"content": "Complex analysis...", "role": "assistant"}
        )
        
        self.ai_manager.chat(
            "Perform complex analysis",
            model="claude-opus-4-20250514",
            max_tokens=16000,
            temperature=0.3
        )
        
        call = self.mock_client.call_history[0]
        self.assertEqual(call["json"]["model"], "claude-opus-4-20250514")
        self.assertEqual(call["json"]["max_tokens"], 16000)
        self.assertEqual(call["json"]["temperature"], 0.3)

    def test_chat_with_tool_calls(self):
        """Test chat response with tool calls"""
        self.mock_client.set_response(
            "POST", "/ai/v1/chat",
            {
                "content": "I found 3 active projects.",
                "role": "assistant",
                "tool_calls": [
                    {"name": "list_projects", "arguments": {"status": "active"}}
                ],
                "tool_results": [
                    {"projects": [{"name": "Alpha"}, {"name": "Beta"}, {"name": "Gamma"}]}
                ]
            }
        )
        
        response = self.ai_manager.chat("Show me active projects")
        
        self.assertIsNotNone(response.tool_calls)
        self.assertEqual(len(response.tool_calls), 1)
        self.assertEqual(response.tool_calls[0]["name"], "list_projects")
        self.assertIsNotNone(response.tool_results)

    def test_chat_stream(self):
        """Test streaming chat"""
        self.mock_client.set_stream_response(
            "POST", "/ai/v1/chat",
            ["Here ", "are ", "your ", "projects..."]
        )
        
        chunks = list(self.ai_manager.chat_stream("List my projects"))
        
        self.assertEqual(chunks, ["Here ", "are ", "your ", "projects..."])
        
        # Verify streaming flag was set
        call = self.mock_client.call_history[0]
        self.assertEqual(call["method"], "STREAM_POST")
        self.assertTrue(call["json_data"]["stream"])

    def test_chat_stream_with_session(self):
        """Test streaming chat with session"""
        self.mock_client.set_stream_response(
            "POST", "/ai/v1/chat",
            ["Creating ", "task..."]
        )
        
        chunks = list(self.ai_manager.chat_stream(
            "Create a task",
            session_id="session-456"
        ))
        
        call = self.mock_client.call_history[0]
        self.assertEqual(call["json_data"]["session_id"], "session-456")


# ============================================================================
# Convenience Method Tests
# ============================================================================

class TestAIManagerConvenienceMethods(unittest.TestCase):
    """Test AIManager convenience methods"""

    def setUp(self):
        """Setup test fixtures"""
        self.mock_client = MockPlatformClient()
        self.ai_manager = AIManager(
            platform_client=self.mock_client
        )

    def test_ask(self):
        """Test ask convenience method"""
        self.mock_client.set_response(
            "POST", "/ai/v1/chat",
            {"content": "You have 42 users.", "role": "assistant"}
        )
        
        answer = self.ai_manager.ask("How many users do we have?")
        
        self.assertEqual(answer, "You have 42 users.")
        self.assertIsInstance(answer, str)

    def test_query_with_tool_results(self):
        """Test query convenience method with tool results"""
        self.mock_client.set_response(
            "POST", "/ai/v1/chat",
            {
                "content": "",
                "role": "assistant",
                "tool_results": [
                    {"name": "Alpha", "status": "active"},
                    {"name": "Beta", "status": "active"}
                ]
            }
        )
        
        results = self.ai_manager.query("active projects with high priority")
        
        self.assertEqual(len(results), 2)
        self.assertEqual(results[0]["name"], "Alpha")

    def test_query_with_json_response(self):
        """Test query with JSON in content"""
        self.mock_client.set_response(
            "POST", "/ai/v1/chat",
            {
                "content": '[{"name": "Project X"}]',
                "role": "assistant",
                "tool_results": None
            }
        )
        
        results = self.ai_manager.query("projects named X")
        
        self.assertEqual(len(results), 1)
        self.assertEqual(results[0]["name"], "Project X")

    def test_query_with_schema_focus(self):
        """Test query with specific schema"""
        self.mock_client.set_response(
            "POST", "/ai/v1/chat",
            {"content": "[]", "role": "assistant"}
        )
        
        self.ai_manager.query("recent entries", schema="User")
        
        call = self.mock_client.call_history[0]
        self.assertIn("User", call["json"]["context"])

    def test_summarize_brief(self):
        """Test summarize with brief format"""
        self.mock_client.set_response(
            "POST", "/ai/v1/chat",
            {"content": "5 projects, 3 active.", "role": "assistant"}
        )
        
        summary = self.ai_manager.summarize(
            [{"name": "A"}, {"name": "B"}],
            format="brief"
        )
        
        self.assertEqual(summary, "5 projects, 3 active.")
        
        call = self.mock_client.call_history[0]
        self.assertIn("brief", call["json"]["message"].lower())
        self.assertFalse(call["json"]["tools_enabled"])

    def test_summarize_bullet_points(self):
        """Test summarize with bullet points"""
        self.mock_client.set_response(
            "POST", "/ai/v1/chat",
            {"content": "• Point 1\n• Point 2", "role": "assistant"}
        )
        
        summary = self.ai_manager.summarize({"key": "value"}, format="bullet_points")
        
        call = self.mock_client.call_history[0]
        self.assertIn("bullet", call["json"]["message"].lower())

    def test_summarize_string_input(self):
        """Test summarize with string input"""
        self.mock_client.set_response(
            "POST", "/ai/v1/chat",
            {"content": "Summary of text...", "role": "assistant"}
        )
        
        summary = self.ai_manager.summarize("Long text content here...")
        
        self.assertIsInstance(summary, str)

    def test_explain_technical(self):
        """Test explain for technical audience"""
        self.mock_client.set_response(
            "POST", "/ai/v1/chat",
            {"content": "Technical explanation...", "role": "assistant"}
        )
        
        explanation = self.ai_manager.explain(
            {"name": "Project", "type": "backend"},
            audience="technical"
        )
        
        call = self.mock_client.call_history[0]
        self.assertIn("technical", call["json"]["message"].lower())

    def test_explain_business(self):
        """Test explain for business audience"""
        self.mock_client.set_response(
            "POST", "/ai/v1/chat",
            {"content": "Business explanation...", "role": "assistant"}
        )
        
        self.ai_manager.explain({"data": "value"}, audience="business")
        
        call = self.mock_client.call_history[0]
        self.assertIn("business", call["json"]["message"].lower())

    def test_explain_object_with_to_dict(self):
        """Test explain with object that has to_dict method"""
        mock_obj = Mock()
        mock_obj.to_dict.return_value = {"name": "MockObject"}
        
        self.mock_client.set_response(
            "POST", "/ai/v1/chat",
            {"content": "Explanation...", "role": "assistant"}
        )
        
        self.ai_manager.explain(mock_obj)
        
        mock_obj.to_dict.assert_called_once()


# ============================================================================
# Session Manager Tests
# ============================================================================

class TestSessionManager(unittest.TestCase):
    """Test SessionManager functionality"""

    def setUp(self):
        """Setup test fixtures"""
        self.mock_client = MockPlatformClient()
        self.ai_manager = AIManager(
            platform_client=self.mock_client
        )
        self.session_mgr = self.ai_manager.sessions

    def test_create_session(self):
        """Test creating a new session"""
        self.mock_client.set_response(
            "POST", "/ai/v1/sessions",
            {
                "session_id": "new-session-123",
                "domain_name": "test-domain",
                "created_at": "2024-01-15T10:00:00",
                "updated_at": "2024-01-15T10:00:00",
                "message_count": 0,
                "metadata": {}
            }
        )
        
        session = self.session_mgr.create()
        
        self.assertEqual(session.id, "new-session-123")
        self.assertEqual(session.message_count, 0)
        
        call = self.mock_client.call_history[0]
        self.assertEqual(call["endpoint"], "/ai/v1/sessions")

    def test_create_session_with_metadata(self):
        """Test creating session with metadata"""
        self.mock_client.set_response(
            "POST", "/ai/v1/sessions",
            {
                "session_id": "meta-session",
                "domain_name": "test-domain",
                "created_at": "2024-01-15T10:00:00",
                "updated_at": "2024-01-15T10:00:00",
                "metadata": {"purpose": "testing", "user_id": "user-123"}
            }
        )
        
        session = self.session_mgr.create(
            metadata={"purpose": "testing", "user_id": "user-123"}
        )
        
        call = self.mock_client.call_history[0]
        self.assertEqual(call["json"]["metadata"]["purpose"], "testing")

    def test_list_sessions(self):
        """Test listing sessions"""
        self.mock_client.set_response(
            "GET", "/ai/v1/sessions",
            {
                "sessions": [
                    {
                        "session_id": "sess-1",
                        "domain_name": "test-domain",
                        "created_at": "2024-01-15T10:00:00",
                        "updated_at": "2024-01-15T11:00:00",
                        "message_count": 5
                    },
                    {
                        "session_id": "sess-2",
                        "domain_name": "test-domain",
                        "created_at": "2024-01-14T10:00:00",
                        "updated_at": "2024-01-14T12:00:00",
                        "message_count": 10
                    }
                ]
            }
        )
        
        sessions = self.session_mgr.list()
        
        self.assertEqual(len(sessions), 2)
        self.assertEqual(sessions[0].id, "sess-1")
        self.assertEqual(sessions[1].message_count, 10)

    def test_list_sessions_with_pagination(self):
        """Test listing sessions with pagination"""
        self.mock_client.set_response(
            "GET", "/ai/v1/sessions",
            {"sessions": []}
        )
        
        self.session_mgr.list(limit=10, offset=20)
        
        call = self.mock_client.call_history[0]
        self.assertEqual(call["params"]["limit"], 10)
        self.assertEqual(call["params"]["offset"], 20)

    def test_get_session(self):
        """Test getting session details"""
        self.mock_client.set_response(
            "GET", "/ai/v1/sessions/sess-123",
            {
                "session_id": "sess-123",
                "domain_name": "test-domain",
                "created_at": "2024-01-15T10:00:00",
                "updated_at": "2024-01-15T11:00:00",
                "message_count": 8,
                "metadata": {"purpose": "support"}
            }
        )
        
        session = self.session_mgr.get("sess-123")
        
        self.assertEqual(session.id, "sess-123")
        self.assertEqual(session.message_count, 8)

    def test_get_history(self):
        """Test getting session history"""
        self.mock_client.set_response(
            "GET", "/ai/v1/sessions/sess-123",
            {
                "session_id": "sess-123",
                "domain_name": "test-domain",
                "created_at": "2024-01-15T10:00:00",
                "updated_at": "2024-01-15T11:00:00",
                "messages": [
                    {"role": "user", "content": "Hello"},
                    {"role": "assistant", "content": "Hi! How can I help?"},
                    {"role": "user", "content": "List projects"},
                    {"role": "assistant", "content": "Here are your projects..."}
                ]
            }
        )
        
        history = self.session_mgr.get_history("sess-123")
        
        self.assertEqual(len(history), 4)
        self.assertEqual(history[0].role, MessageRole.USER)
        self.assertEqual(history[1].role, MessageRole.ASSISTANT)

    def test_delete_session(self):
        """Test deleting a session"""
        self.mock_client.set_response(
            "DELETE", "/ai/v1/sessions/sess-123",
            {"success": True}
        )
        
        result = self.session_mgr.delete("sess-123")
        
        self.assertTrue(result)
        
        call = self.mock_client.call_history[0]
        self.assertEqual(call["endpoint"], "/ai/v1/sessions/sess-123")

    def test_clear_history(self):
        """Test clearing session history"""
        self.mock_client.set_response(
            "POST", "/ai/v1/sessions/sess-123/clear",
            {"success": True}
        )
        
        result = self.session_mgr.clear_history("sess-123")
        
        self.assertTrue(result)
        
        call = self.mock_client.call_history[0]
        self.assertEqual(call["endpoint"], "/ai/v1/sessions/sess-123/clear")


# ============================================================================
# Tool Manager Tests
# ============================================================================

class TestToolManager(unittest.TestCase):
    """Test ToolManager functionality"""

    def setUp(self):
        """Setup test fixtures"""
        self.mock_client = MockPlatformClient()
        self.ai_manager = AIManager(
            platform_client=self.mock_client
        )
        self.tool_mgr = self.ai_manager.tools

    def test_list_tools(self):
        """Test listing available tools"""
        self.mock_client.set_response(
            "GET", "/ai/v1/tools",
            {
                "tools": [
                    {
                        "name": "create_project",
                        "description": "Create a new project",
                        "parameters": {"type": "object"},
                        "schema_name": "Project",
                        "operation": "create"
                    },
                    {
                        "name": "list_projects",
                        "description": "List projects",
                        "parameters": {"type": "object"},
                        "schema_name": "Project",
                        "operation": "list"
                    },
                    {
                        "name": "create_user",
                        "description": "Create a new user",
                        "parameters": {"type": "object"},
                        "schema_name": "User",
                        "operation": "create"
                    }
                ]
            }
        )
        
        tools = self.tool_mgr.list()
        
        self.assertEqual(len(tools), 3)
        self.assertEqual(tools[0].name, "create_project")
        self.assertEqual(tools[0].schema_name, "Project")

    def test_list_tools_cached(self):
        """Test tools list is cached"""
        self.mock_client.set_response(
            "GET", "/ai/v1/tools",
            {"tools": [{"name": "test_tool", "description": "", "parameters": {}}]}
        )
        
        # First call
        tools1 = self.tool_mgr.list()
        # Second call (should use cache)
        tools2 = self.tool_mgr.list()
        
        # Should only have one API call
        self.assertEqual(len(self.mock_client.call_history), 1)
        self.assertIs(tools1, tools2)

    def test_list_tools_refresh(self):
        """Test tools list refresh"""
        self.mock_client.set_response(
            "GET", "/ai/v1/tools",
            {"tools": [{"name": "tool_v1", "description": "", "parameters": {}}]}
        )
        
        # First call
        self.tool_mgr.list()
        
        # Change response
        self.mock_client.set_response(
            "GET", "/ai/v1/tools",
            {"tools": [{"name": "tool_v2", "description": "", "parameters": {}}]}
        )
        
        # Force refresh
        tools = self.tool_mgr.list(refresh=True)
        
        self.assertEqual(len(self.mock_client.call_history), 2)
        self.assertEqual(tools[0].name, "tool_v2")

    def test_get_tool(self):
        """Test getting tool by name"""
        self.mock_client.set_response(
            "GET", "/ai/v1/tools",
            {
                "tools": [
                    {"name": "create_project", "description": "Create", "parameters": {}},
                    {"name": "list_projects", "description": "List", "parameters": {}}
                ]
            }
        )
        
        tool = self.tool_mgr.get("list_projects")
        
        self.assertIsNotNone(tool)
        self.assertEqual(tool.name, "list_projects")

    def test_get_tool_not_found(self):
        """Test getting non-existent tool"""
        self.mock_client.set_response(
            "GET", "/ai/v1/tools",
            {"tools": [{"name": "some_tool", "description": "", "parameters": {}}]}
        )
        
        tool = self.tool_mgr.get("nonexistent_tool")
        
        self.assertIsNone(tool)

    def test_invoke_tool(self):
        """Test invoking a tool directly"""
        self.mock_client.set_response(
            "POST", "/ai/v1/tools/list_projects/invoke",
            {
                "tool_name": "list_projects",
                "success": True,
                "result": [{"name": "Alpha"}, {"name": "Beta"}],
                "execution_time_ms": 125.5
            }
        )
        
        result = self.tool_mgr.invoke("list_projects", status="active", limit=10)
        
        self.assertTrue(result.success)
        self.assertEqual(len(result.result), 2)
        self.assertEqual(result.execution_time_ms, 125.5)
        
        call = self.mock_client.call_history[0]
        self.assertEqual(call["json"]["parameters"]["status"], "active")
        self.assertEqual(call["json"]["parameters"]["limit"], 10)

    def test_invoke_tool_error(self):
        """Test tool invocation error"""
        self.mock_client.set_response(
            "POST", "/ai/v1/tools/create_project/invoke",
            {
                "tool_name": "create_project",
                "success": False,
                "result": None,
                "error": "Validation error: name is required"
            }
        )
        
        result = self.tool_mgr.invoke("create_project", status="active")
        
        self.assertFalse(result.success)
        self.assertIn("Validation error", result.error)

    def test_refresh_tools(self):
        """Test refreshing tools cache"""
        self.mock_client.set_response(
            "POST", "/ai/v1/tools/refresh",
            {"success": True}
        )
        self.mock_client.set_response(
            "GET", "/ai/v1/tools",
            {"tools": [{"name": "refreshed_tool", "description": "", "parameters": {}}]}
        )
        
        tools = self.tool_mgr.refresh()
        
        # Should have called refresh endpoint
        self.assertEqual(self.mock_client.call_history[0]["endpoint"], "/ai/v1/tools/refresh")
        self.assertEqual(tools[0].name, "refreshed_tool")

    def test_for_schema(self):
        """Test getting tools for specific schema"""
        self.mock_client.set_response(
            "GET", "/ai/v1/tools",
            {
                "tools": [
                    {"name": "create_project", "description": "", "parameters": {}, "schema_name": "Project"},
                    {"name": "list_projects", "description": "", "parameters": {}, "schema_name": "Project"},
                    {"name": "create_user", "description": "", "parameters": {}, "schema_name": "User"},
                    {"name": "list_users", "description": "", "parameters": {}, "schema_name": "User"}
                ]
            }
        )
        
        project_tools = self.tool_mgr.for_schema("Project")
        
        self.assertEqual(len(project_tools), 2)
        for tool in project_tools:
            self.assertEqual(tool.schema_name, "Project")

    def test_for_schema_case_insensitive(self):
        """Test for_schema is case insensitive"""
        self.mock_client.set_response(
            "GET", "/ai/v1/tools",
            {
                "tools": [
                    {"name": "create_project", "description": "", "parameters": {}, "schema_name": "Project"}
                ]
            }
        )
        
        tools = self.tool_mgr.for_schema("project")  # lowercase
        
        self.assertEqual(len(tools), 1)


# ============================================================================
# Vector Manager Tests
# ============================================================================

class TestVectorManager(unittest.TestCase):
    """Test VectorManager functionality"""

    def setUp(self):
        """Setup test fixtures"""
        self.mock_client = MockPlatformClient()
        self.ai_manager = AIManager(
            platform_client=self.mock_client
        )
        self.vector_mgr = self.ai_manager.vectors

    def test_index_document(self):
        """Test indexing a document"""
        self.mock_client.set_response(
            "POST", "/ai/v1/vectors/index",
            {"document_id": "doc-new-123"}
        )
        
        doc_id = self.vector_mgr.index(
            content="Project Alpha is our main backend initiative...",
            metadata={"type": "project_doc", "project_id": "uuid-123"}
        )
        
        self.assertEqual(doc_id, "doc-new-123")
        
        call = self.mock_client.call_history[0]
        self.assertIn("Project Alpha", call["json"]["content"])
        self.assertEqual(call["json"]["metadata"]["type"], "project_doc")

    def test_index_document_with_id(self):
        """Test indexing with custom document ID"""
        self.mock_client.set_response(
            "POST", "/ai/v1/vectors/index",
            {"document_id": "custom-id-456"}
        )
        
        doc_id = self.vector_mgr.index(
            content="Some content",
            document_id="custom-id-456"
        )
        
        call = self.mock_client.call_history[0]
        self.assertEqual(call["json"]["document_id"], "custom-id-456")

    def test_search(self):
        """Test vector search"""
        self.mock_client.set_response(
            "POST", "/ai/v1/vectors/search",
            {
                "results": [
                    {
                        "id": "doc-1",
                        "content": "Backend architecture uses microservices...",
                        "score": 0.95,
                        "metadata": {"type": "tech_doc"}
                    },
                    {
                        "id": "doc-2",
                        "content": "Our backend team is responsible...",
                        "score": 0.82,
                        "metadata": {"type": "team_doc"}
                    }
                ]
            }
        )
        
        results = self.vector_mgr.search("backend architecture")
        
        self.assertEqual(len(results), 2)
        self.assertEqual(results[0].id, "doc-1")
        self.assertEqual(results[0].score, 0.95)
        self.assertIn("microservices", results[0].content)

    def test_search_with_options(self):
        """Test search with limit and min_score"""
        self.mock_client.set_response(
            "POST", "/ai/v1/vectors/search",
            {"results": []}
        )
        
        self.vector_mgr.search(
            query="test query",
            limit=5,
            min_score=0.8,
            filters={"type": "project_doc"}
        )
        
        call = self.mock_client.call_history[0]
        self.assertEqual(call["json"]["query"], "test query")
        self.assertEqual(call["json"]["limit"], 5)
        self.assertEqual(call["json"]["min_score"], 0.8)
        self.assertEqual(call["json"]["filters"]["type"], "project_doc")

    def test_delete_document(self):
        """Test deleting a document"""
        self.mock_client.set_response(
            "DELETE", "/ai/v1/vectors/doc-123",
            {"success": True}
        )
        
        result = self.vector_mgr.delete("doc-123")
        
        self.assertTrue(result)
        
        call = self.mock_client.call_history[0]
        self.assertEqual(call["endpoint"], "/ai/v1/vectors/doc-123")

    def test_bulk_index(self):
        """Test bulk indexing documents"""
        self.mock_client.set_response(
            "POST", "/ai/v1/vectors/bulk-index",
            {
                "indexed_count": 3,
                "failed_count": 0,
                "document_ids": ["doc-1", "doc-2", "doc-3"]
            }
        )
        
        documents = [
            {"content": "Doc 1 content", "metadata": {"type": "a"}},
            {"content": "Doc 2 content", "metadata": {"type": "b"}},
            {"content": "Doc 3 content", "metadata": {"type": "c"}, "document_id": "custom-3"}
        ]
        
        result = self.vector_mgr.bulk_index(documents)
        
        self.assertEqual(result["indexed_count"], 3)
        
        call = self.mock_client.call_history[0]
        self.assertEqual(len(call["json"]["documents"]), 3)


# ============================================================================
# Health Check Tests
# ============================================================================

class TestAIManagerHealth(unittest.TestCase):
    """Test AIManager health check functionality"""

    def setUp(self):
        """Setup test fixtures"""
        self.mock_client = MockPlatformClient()
        self.ai_manager = AIManager(
            platform_client=self.mock_client
        )

    def test_health_healthy(self):
        """Test health check when service is healthy"""
        self.mock_client.set_response(
            "GET", "/health",
            {
                "status": "healthy",
                "service": "ai-service",
                "llm": {"status": "healthy", "providers": ["anthropic"]}
            }
        )
        
        health = self.ai_manager.health()
        
        self.assertEqual(health["status"], "healthy")
        self.assertEqual(health["service"], "ai-service")

    def test_health_degraded(self):
        """Test health check when service is degraded"""
        self.mock_client.set_response(
            "GET", "/health",
            {
                "status": "degraded",
                "service": "ai-service",
                "llm": {"status": "degraded", "providers": []}
            }
        )
        
        health = self.ai_manager.health()
        
        self.assertEqual(health["status"], "degraded")

    def test_is_available_healthy(self):
        """Test is_available when service is healthy"""
        self.mock_client.set_response(
            "GET", "/health",
            {"status": "healthy"}
        )
        
        available = self.ai_manager.is_available()
        
        self.assertTrue(available)

    def test_is_available_degraded(self):
        """Test is_available when service is degraded (still available)"""
        self.mock_client.set_response(
            "GET", "/health",
            {"status": "degraded"}
        )
        
        available = self.ai_manager.is_available()
        
        self.assertTrue(available)

    def test_is_available_unhealthy(self):
        """Test is_available when service is unhealthy"""
        self.mock_client.set_response(
            "GET", "/health",
            {"status": "unhealthy"}
        )
        
        available = self.ai_manager.is_available()
        
        self.assertFalse(available)

    def test_is_available_connection_error(self):
        """Test is_available when connection fails"""
        # Don't set any response - will return empty dict
        # The is_available method should handle this gracefully
        
        available = self.ai_manager.is_available()
        
        self.assertFalse(available)


# ============================================================================
# Factory Function Tests
# ============================================================================

class TestCreateAIManager(unittest.TestCase):
    """Test create_ai_manager factory function"""

    def test_create_ai_manager(self):
        """Test creating standalone AI manager"""
        # PlatformClient is imported from .platform_client inside create_ai_manager
        # So we patch it at the source module
        with patch('supero.platform_client.PlatformClient') as mock_client_class:
            mock_client = Mock()
            mock_client_class.return_value = mock_client
            mock_client.domain_name = 'test-domain'
            
            ai_manager = create_ai_manager(
                domain_name="test-domain",
                jwt_token="test-jwt-token",
                platform_core_host="api.example.com",
                platform_core_port=8080
            )
            
            # Verify PlatformClient was created with correct params
            mock_client_class.assert_called_once_with(
                host="api.example.com",
                port=8080,
                jwt_token="test-jwt-token"
            )
            
            # Verify AIManager was created
            self.assertIsInstance(ai_manager, AIManager)
            self.assertEqual(ai_manager._domain_name, "test-domain")

    def test_create_ai_manager_default_values(self):
        """Test create_ai_manager with default host/port"""
        with patch('supero.platform_client.PlatformClient') as mock_client_class:
            mock_client = Mock()
            mock_client_class.return_value = mock_client
            mock_client.domain_name = 'test-domain'
            
            ai_manager = create_ai_manager(
                domain_name="test-domain",
                jwt_token="test-jwt-token"
                # Use default host/port
            )
            
            # Verify defaults were used
            mock_client_class.assert_called_once_with(
                host="localhost",
                port=8083,
                jwt_token="test-jwt-token"
            )
            
            self.assertIsInstance(ai_manager, AIManager)


# ============================================================================
# Edge Cases and Error Handling Tests
# ============================================================================

class TestAIManagerEdgeCases(unittest.TestCase):
    """Test edge cases and error handling"""

    def setUp(self):
        """Setup test fixtures"""
        self.mock_client = MockPlatformClient()
        self.ai_manager = AIManager(
            platform_client=self.mock_client
        )

    def test_chat_empty_message(self):
        """Test chat with empty message"""
        self.mock_client.set_response(
            "POST", "/ai/v1/chat",
            {"content": "I didn't receive a message.", "role": "assistant"}
        )
        
        response = self.ai_manager.chat("")
        
        # Should still work (server handles validation)
        self.assertIsNotNone(response)

    def test_query_fallback_to_response(self):
        """Test query fallback when no tool results or JSON"""
        self.mock_client.set_response(
            "POST", "/ai/v1/chat",
            {
                "content": "I found some projects but can't list them.",
                "role": "assistant",
                "tool_results": None
            }
        )
        
        results = self.ai_manager.query("test query")
        
        # Should return wrapped response
        self.assertEqual(len(results), 1)
        self.assertIn("response", results[0])

    def test_summarize_with_datetime_objects(self):
        """Test summarize handles datetime objects"""
        self.mock_client.set_response(
            "POST", "/ai/v1/chat",
            {"content": "Summary...", "role": "assistant"}
        )
        
        data = {
            "name": "Project",
            "created_at": datetime(2024, 1, 15, 10, 30, 0)
        }
        
        # Should not raise - datetime should be serialized
        summary = self.ai_manager.summarize(data)
        
        self.assertIsNotNone(summary)

    def test_explain_object_with_dict_attribute(self):
        """Test explain with object that has __dict__"""
        class SimpleObject:
            def __init__(self):
                self.name = "Test"
                self.value = 42
        
        obj = SimpleObject()
        
        self.mock_client.set_response(
            "POST", "/ai/v1/chat",
            {"content": "Explanation...", "role": "assistant"}
        )
        
        explanation = self.ai_manager.explain(obj)
        
        self.assertIsNotNone(explanation)

    def test_session_from_dict_missing_fields(self):
        """Test Session.from_dict handles missing optional fields"""
        data = {
            "session_id": "sess-123",
            # Missing domain_name, created_at, updated_at, message_count, metadata
        }
        
        session = Session.from_dict(data)
        
        self.assertEqual(session.id, "sess-123")
        self.assertEqual(session.domain_name, "")
        self.assertEqual(session.message_count, 0)
        self.assertEqual(session.metadata, {})

    def test_vector_search_result_missing_metadata(self):
        """Test VectorSearchResult handles missing metadata"""
        data = {
            "id": "doc-123",
            "content": "Some content",
            "score": 0.9
            # Missing metadata
        }
        
        result = VectorSearchResult.from_dict(data)
        
        self.assertEqual(result.metadata, {})

    def test_tool_for_schema_no_schema_name(self):
        """Test for_schema handles tools without schema_name"""
        self.mock_client.set_response(
            "GET", "/ai/v1/tools",
            {
                "tools": [
                    {"name": "system_tool", "description": "", "parameters": {}, "schema_name": None},
                    {"name": "project_tool", "description": "", "parameters": {}, "schema_name": "Project"}
                ]
            }
        )
        
        tools = self.ai_manager.tools.for_schema("Project")
        
        self.assertEqual(len(tools), 1)
        self.assertEqual(tools[0].name, "project_tool")


if __name__ == '__main__':
    unittest.main(verbosity=2)
