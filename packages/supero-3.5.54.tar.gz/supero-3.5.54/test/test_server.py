#!/usr/bin/env python3
"""
test_server.py — Tests for server.py hooks installed by install-service-lib.py.

Self-contained: the minimal server.py fixture is written out at test start,
patched by running the installer, then imported to test the injected helpers.
No separate fixture file needed.

Tests cover:
  - _sl_parse_crud_url        (URL parsing)
  - _sl_extract_user_from_jwt (JWT claim extraction without verification)
  - _sl_fire_crud_event_safe  (skip list, payload building, fail-safe)
  - _sl_fire_event_safe       (async dispatch, exception isolation)
"""
import base64
import json
import os
import shutil
import subprocess
import sys
import tempfile
import time
import unittest
from unittest.mock import MagicMock, patch


# ═══════════════════════════════════════════════════════════════════
# Minimal server.py fixture — written to tempdir at test start.
# Mirrors the production server.py structure enough that the installer
# anchors find their targets. Kept compact to minimize maintenance.
# ═══════════════════════════════════════════════════════════════════

_SERVER_FIXTURE = r'''#!/usr/bin/env python3
"""Minimal server.py fixture — mimics real server.py structure."""
import os
import sys
import json
import time
import http.server
import socketserver
import urllib.request
import urllib.error
import ssl

__version__ = '1.0.0'

API_URL = os.getenv('SUPERO_URL', 'https://api.supero.dev').rstrip('/')
BROWSER_UA = 'Mozilla/5.0'

_SERVICE_API_KEY = ''
_PUBLIC_SCHEMAS = []


def init_service_account():
    return True


def _fetch_policy(token, domain=None, tenant=None):
    return None


_PROJECT_UUID_CACHE = {}
_RATE_LIMIT_BUCKET = {}


def _strip_env(name, default=''):
    v = os.getenv(name, default) or default
    return v.strip().strip('"').strip("'")


def _check_rate_limit(client_ip, max_per_minute=3):
    return True


class SuperoRequestHandler(http.server.SimpleHTTPRequestHandler):

    def end_headers(self):
        self.send_header('Access-Control-Allow-Origin', '*')
        super().end_headers()

    def do_OPTIONS(self):
        self.send_response(200)
        self.end_headers()

    def do_GET(self):
        if self.path.startswith('/api/'):
            self._proxy_request('GET')
        else:
            super().do_GET()

    def do_POST(self):
        if self.path == '/api/signup':
            self._handle_signup()
        elif self.path == '/api/signup-tenant':
            self._handle_tenant_signup()
        elif self.path == '/api/v1/auth/login':
            self._handle_login()
        elif self.path.startswith('/api/'):
            self._proxy_request('POST')
        else:
            self._send_json(404, {'error': 'Not found'})

    def do_PUT(self):
        if self.path.startswith('/api/'):
            self._proxy_request('PUT')

    def do_DELETE(self):
        if self.path.startswith('/api/'):
            self._proxy_request('DELETE')

    def _proxy_request(self, method):
        url = f'{API_URL}{self.path}'
        cl = int(self.headers.get('Content-Length', 0))
        body = self.rfile.read(cl) if cl > 0 else None

        req = urllib.request.Request(url, data=body, method=method)
        for h in ['Authorization', 'Content-Type']:
            val = self.headers.get(h)
            if val:
                req.add_header(h, val)

        try:
            with urllib.request.urlopen(req, timeout=120) as resp:
                content_type = resp.headers.get('Content-Type', 'application/json')
                if 'text/event-stream' in content_type:
                    return

                data = resp.read()
                self.send_response(resp.status)
                self.send_header('Content-Type', content_type)
                self.end_headers()
                self.wfile.write(data)
        except urllib.error.HTTPError as e:
            data = e.read()
            self.send_response(e.code)
            self.send_header('Content-Type', 'application/json')
            self.end_headers()
            self.wfile.write(data)
        except Exception as e:
            self._send_json(502, {'error': f'Proxy error: {str(e)}'})

    def _handle_tenant_signup(self):
        client_ip = self.client_address[0] if self.client_address else 'unknown'
        if not _check_rate_limit(client_ip, max_per_minute=3):
            return self._send_json(429, {'error': 'Too many signup attempts. Try again in a minute.'})

        cl = int(self.headers.get('Content-Length', 0))
        try:
            body = json.loads(self.rfile.read(cl)) if cl > 0 else {}
        except (json.JSONDecodeError, ValueError):
            return self._send_json(400, {'error': 'Invalid JSON body'})

        display_name = body.get('display_name', '').strip()
        admin_email = body.get('admin_email', '').strip().lower()
        admin_password = body.get('admin_password', '')
        admin_full_name = body.get('admin_full_name', admin_email.split('@')[0] if admin_email else '')

        if not display_name or len(display_name) < 2:
            return self._send_json(400, {'error': 'Display name required'})

        slug = display_name.lower().replace(' ', '-')
        domain = _strip_env('SUPERO_DOMAIN')
        tenant_result = {'uuid': 'fake-uuid'}

        tenant_result['success'] = True
        tenant_result['redirect_url'] = f'/?tenant={slug}'
        return self._send_json(200, tenant_result)

    def _handle_login(self):
        cl = int(self.headers.get('Content-Length', 0))
        body_bytes = self.rfile.read(cl)

        try:
            req = urllib.request.Request(f'{API_URL}/api/v1/auth/login',
                data=body_bytes, method='POST')
            with urllib.request.urlopen(req, timeout=30) as resp:
                login_result = json.loads(resp.read().decode())
        except Exception:
            return self._send_json(502, {'error': 'Login proxy failed'})

        token = login_result.get('auth', {}).get('access_token')
        domain = login_result.get('context', {}).get('domain') or os.getenv('SUPERO_DOMAIN', '')
        tenant = login_result.get('context', {}).get('tenant', 'default-tenant')

        policy = _fetch_policy(token, domain, tenant) if token else None
        login_result['policy'] = policy

        self._send_json(200, login_result)

    def _handle_signup(self):
        cl = int(self.headers.get('Content-Length', 0))
        try:
            body = json.loads(self.rfile.read(cl)) if cl > 0 else {}
        except (json.JSONDecodeError, ValueError):
            return self._send_json(400, {'error': 'Invalid JSON body'})

        email = body.get('email', '').strip().lower()
        password = body.get('password', '')
        full_name = body.get('full_name', email.split('@')[0])

        if not email or '@' not in email:
            return self._send_json(400, {'error': 'Valid email required'})

        domain = _strip_env('SUPERO_DOMAIN')
        project = _strip_env('SUPERO_PROJECT', 'default-project')
        tenant = body.get('tenant') or os.getenv('SUPERO_DEFAULT_TENANT', 'default-tenant')

        try:
            req = urllib.request.Request(f'{API_URL}/api/v1/auth/login',
                data=b'{}', method='POST')
            with urllib.request.urlopen(req, timeout=30) as resp:
                result = json.loads(resp.read().decode())
                token = result['auth']['access_token']
                policy = _fetch_policy(token, domain, tenant)

                return self._send_json(200, {
                    'auth': {'access_token': token},
                    'user': {'email': email, 'full_name': full_name, 'role': 'tenant_user'},
                    'context': {'domain': domain, 'project': project, 'tenant': tenant},
                    'policy': policy,
                })
        except Exception as e:
            return self._send_json(500, {'error': f'Login after signup failed: {e}'})

    def _send_json(self, status, data):
        body = json.dumps(data).encode()
        self.send_response(status)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Content-Length', str(len(body)))
        self.end_headers()
        self.wfile.write(body)


if __name__ == '__main__':
    pass
'''


# ═══════════════════════════════════════════════════════════════════
# Test setup — write fixture, run installer, import the result
# ═══════════════════════════════════════════════════════════════════

class _TestContext:
    tempdir = None
    module = None


def _make_jwt(claims):
    """Build an unsigned JWT-shaped token from a claims dict."""
    header = base64.urlsafe_b64encode(b'{"alg":"none"}').decode().rstrip("=")
    body = base64.urlsafe_b64encode(
        json.dumps(claims).encode()).decode().rstrip("=")
    return f"{header}.{body}.signature"


def _find_installer_and_service_lib():
    """Locate install-service-lib.py and service_lib.py relative to this test.

    Looks in: same dir, parent dir, ../src/supero/ (common layouts).
    Returns (installer_path, service_lib_path) or raises FileNotFoundError.
    """
    here = os.path.dirname(os.path.abspath(__file__))
    candidates = [
        here,
        os.path.dirname(here),
        os.path.join(os.path.dirname(here), "src", "supero"),
        os.path.join(os.path.dirname(here), "scripts"),
    ]

    installer = None
    service_lib = None
    for d in candidates:
        if not os.path.isdir(d):
            continue
        if installer is None:
            cand = os.path.join(d, "install-service-lib.py")
            if os.path.isfile(cand):
                installer = cand
        if service_lib is None:
            cand = os.path.join(d, "service_lib.py")
            if os.path.isfile(cand):
                service_lib = cand

    if not installer:
        raise FileNotFoundError(
            "install-service-lib.py not found near this test file. "
            f"Searched: {candidates}")
    if not service_lib:
        raise FileNotFoundError(
            "service_lib.py not found near this test file. "
            f"Searched: {candidates}")
    return installer, service_lib


def setUpModule():
    """Apply installer to an inline fixture, make 'patched_server' importable.

    If the installer file isn't found anywhere, skip all tests in this
    module rather than hard-failing — the library tests in test_service_lib.py
    cover the core functionality, and this file only adds installer-level checks.
    """
    tempdir = tempfile.mkdtemp(prefix="test_server_")
    _TestContext.tempdir = tempdir

    try:
        installer, service_lib = _find_installer_and_service_lib()
    except FileNotFoundError as e:
        # Skip the whole module cleanly (not a crash)
        raise unittest.SkipTest(
            f"install-service-lib.py not found — skipping server-patch tests. "
            f"test_service_lib.py still runs and covers the library itself. "
            f"({e})"
        )

    # Write the fixture
    target_server = os.path.join(tempdir, "patched_server.py")
    with open(target_server, "w") as f:
        f.write(_SERVER_FIXTURE)

    # Run the installer
    result = subprocess.run(
        [sys.executable, installer,
         "--server", target_server,
         "--service-lib", service_lib],
        capture_output=True, text=True, timeout=30,
    )
    if result.returncode != 0:
        raise RuntimeError(
            f"Installer failed:\nstdout={result.stdout}\nstderr={result.stderr}")

    sys.path.insert(0, tempdir)
    import patched_server  # noqa: E402
    _TestContext.module = patched_server


def tearDownModule():
    if _TestContext.tempdir and _TestContext.tempdir in sys.path:
        sys.path.remove(_TestContext.tempdir)
    if _TestContext.tempdir and os.path.isdir(_TestContext.tempdir):
        shutil.rmtree(_TestContext.tempdir, ignore_errors=True)
    sys.modules.pop("patched_server", None)


# ═══════════════════════════════════════════════════════════════════
# 1. _sl_parse_crud_url
# ═══════════════════════════════════════════════════════════════════

class TestParseCrudUrl(unittest.TestCase):
    def setUp(self):
        self.parse = _TestContext.module._sl_parse_crud_url

    def test_list_create_url(self):
        self.assertEqual(self.parse("/api/v1/crud/mydomain/order"), {
            "domain": "mydomain", "type": "order",
            "bare_type": "order", "uuid": None,
        })

    def test_with_uuid(self):
        self.assertEqual(self.parse("/api/v1/crud/mydomain/order/abc-123"), {
            "domain": "mydomain", "type": "order",
            "bare_type": "order", "uuid": "abc-123",
        })

    def test_qualified_type(self):
        result = self.parse("/api/v1/crud/mydomain/ma559:order")
        self.assertEqual(result["type"], "ma559:order")
        self.assertEqual(result["bare_type"], "order")

    def test_qualified_with_uuid(self):
        result = self.parse("/api/v1/crud/mydomain/ma559:order/uuid-x")
        self.assertEqual(result["type"], "ma559:order")
        self.assertEqual(result["bare_type"], "order")
        self.assertEqual(result["uuid"], "uuid-x")

    def test_query_string_ignored(self):
        result = self.parse("/api/v1/crud/mydomain/order?limit=10")
        self.assertEqual(result["type"], "order")
        self.assertIsNone(result["uuid"])

    def test_non_crud_url_returns_none(self):
        self.assertIsNone(self.parse("/api/v1/services/execute"))
        self.assertIsNone(self.parse("/api/signup"))
        self.assertIsNone(self.parse("/health"))

    def test_empty_path(self):
        self.assertIsNone(self.parse(""))
        self.assertIsNone(self.parse(None))


# ═══════════════════════════════════════════════════════════════════
# 2. _sl_extract_user_from_jwt
# ═══════════════════════════════════════════════════════════════════

class TestExtractUserFromJwt(unittest.TestCase):
    def setUp(self):
        self.extract = _TestContext.module._sl_extract_user_from_jwt

    def test_returns_empty_for_no_header(self):
        self.assertEqual(self.extract(""), {})
        self.assertEqual(self.extract(None), {})

    def test_returns_empty_for_non_bearer(self):
        self.assertEqual(self.extract("Basic xyz"), {})

    def test_extracts_standard_claims(self):
        token = _make_jwt({
            "email": "user@example.com",
            "user_uuid": "user-123",
            "tenant_name": "acme",
            "role": "admin",
        })
        result = self.extract(f"Bearer {token}")
        self.assertEqual(result, {
            "email": "user@example.com",
            "uuid": "user-123",
            "tenant": "acme",
            "role": "admin",
        })

    def test_fallback_to_sub(self):
        """If user_uuid missing, falls back to sub claim."""
        token = _make_jwt({
            "email": "u@x.com", "sub": "sub-uuid",
            "tenant": "acme",
        })
        result = self.extract(f"Bearer {token}")
        self.assertEqual(result["uuid"], "sub-uuid")
        self.assertEqual(result["tenant"], "acme")

    def test_malformed_jwt_returns_empty(self):
        self.assertEqual(self.extract("Bearer not-a-jwt"), {})

    def test_missing_segments(self):
        self.assertEqual(self.extract("Bearer header.body"), {})

    def test_unparseable_payload(self):
        token = ("header."
                 + base64.urlsafe_b64encode(b"not json").decode().rstrip("=")
                 + ".sig")
        self.assertEqual(self.extract(f"Bearer {token}"), {})

    def test_missing_claims(self):
        """JWT with empty payload → all fields None."""
        token = _make_jwt({})
        result = self.extract(f"Bearer {token}")
        self.assertEqual(result, {
            "email": None, "uuid": None, "tenant": None, "role": None,
        })


# ═══════════════════════════════════════════════════════════════════
# 3. _sl_fire_crud_event_safe — skip list + payload building
# ═══════════════════════════════════════════════════════════════════

class TestFireCrudEventSafe(unittest.TestCase):
    def setUp(self):
        self.mod = _TestContext.module
        self.fire = self.mod._sl_fire_crud_event_safe

    def _make_handler(self, path, auth=""):
        h = MagicMock()
        h.path = path
        h.headers = MagicMock()
        h.headers.get = MagicMock(return_value=auth)
        return h

    @patch("patched_server._sl_fire_event_safe")
    def test_fires_for_crud_post(self, mock_fire):
        """POST to /crud/{dom}/{type} fires @create:{type}."""
        h = self._make_handler("/api/v1/crud/mydomain/order")
        response_body = json.dumps({"uuid": "abc-123", "status": "new"}).encode()
        self.fire(h, "POST", response_body, None)

        mock_fire.assert_called_once()
        event, payload = mock_fire.call_args[0]
        self.assertEqual(event, "@create:order")
        self.assertEqual(payload["operation"], "create")
        self.assertEqual(payload["type"], "order")
        self.assertEqual(payload["uuid"], "abc-123")
        self.assertEqual(payload["record"], {"uuid": "abc-123", "status": "new"})

    @patch("patched_server._sl_fire_event_safe")
    def test_fires_for_put(self, mock_fire):
        h = self._make_handler("/api/v1/crud/d/order/uuid-x")
        request_body = json.dumps({"status": "paid"}).encode()
        self.fire(h, "PUT", None, request_body)

        event, payload = mock_fire.call_args[0]
        self.assertEqual(event, "@update:order")
        self.assertEqual(payload["uuid"], "uuid-x")
        self.assertEqual(payload["record"], {"status": "paid"})

    @patch("patched_server._sl_fire_event_safe")
    def test_fires_for_delete(self, mock_fire):
        h = self._make_handler("/api/v1/crud/d/order/uuid-y")
        self.fire(h, "DELETE", None, None)

        event, payload = mock_fire.call_args[0]
        self.assertEqual(event, "@delete:order")
        self.assertEqual(payload["uuid"], "uuid-y")
        self.assertNotIn("record", payload)

    @patch("patched_server._sl_fire_event_safe")
    def test_skips_system_types(self, mock_fire):
        """System types never fire CRUD events."""
        for sys_type in [
            "user_account", "tenant", "project", "api_key", "domain",
            "access_policy", "schema", "workflow_instance",
            "workflow_definition", "plugin_registry",
        ]:
            mock_fire.reset_mock()
            h = self._make_handler(f"/api/v1/crud/d/{sys_type}")
            self.fire(h, "POST", b'{"uuid":"x"}', None)
            mock_fire.assert_not_called()

    @patch("patched_server._sl_fire_event_safe")
    def test_skips_non_crud_urls(self, mock_fire):
        h = self._make_handler("/api/v1/services/execute")
        self.fire(h, "POST", b"{}", None)
        mock_fire.assert_not_called()

    @patch("patched_server._sl_fire_event_safe")
    def test_skips_unknown_methods(self, mock_fire):
        h = self._make_handler("/api/v1/crud/d/order")
        self.fire(h, "GET", None, None)
        mock_fire.assert_not_called()
        self.fire(h, "PATCH", None, None)
        mock_fire.assert_not_called()

    @patch("patched_server._sl_fire_event_safe")
    def test_qualified_type_uses_bare_name(self, mock_fire):
        """ma559:order in URL → @create:order event name."""
        h = self._make_handler("/api/v1/crud/d/ma559:order")
        self.fire(h, "POST", b'{"uuid":"x"}', None)

        event, payload = mock_fire.call_args[0]
        self.assertEqual(event, "@create:order")
        self.assertEqual(payload["type"], "order")
        self.assertEqual(payload["qualified_type"], "ma559:order")

    @patch("patched_server._sl_fire_event_safe")
    def test_includes_user_from_jwt(self, mock_fire):
        jwt = _make_jwt({
            "email": "u@x.com", "user_uuid": "uu-1", "role": "admin",
        })
        h = self._make_handler("/api/v1/crud/d/order", auth=f"Bearer {jwt}")
        self.fire(h, "POST", b'{"uuid":"x"}', None)

        _, payload = mock_fire.call_args[0]
        self.assertEqual(payload["user"]["email"], "u@x.com")
        self.assertEqual(payload["user"]["uuid"], "uu-1")
        self.assertEqual(payload["user"]["role"], "admin")

    @patch("patched_server._sl_fire_event_safe")
    def test_malformed_response_body_survives(self, mock_fire):
        """Non-JSON response body → payload still fires, without 'record'."""
        h = self._make_handler("/api/v1/crud/d/order")
        self.fire(h, "POST", b"not-json-but-something", None)

        mock_fire.assert_called_once()
        _, payload = mock_fire.call_args[0]
        self.assertEqual(payload["event"], "@create:order")
        self.assertNotIn("record", payload)

    @patch("patched_server._sl_fire_event_safe")
    def test_create_backfills_uuid_from_response(self, mock_fire):
        """POST may not have uuid in URL; we grab it from response body."""
        h = self._make_handler("/api/v1/crud/d/order")
        self.fire(h, "POST", b'{"uuid":"from-response","name":"X"}', None)

        _, payload = mock_fire.call_args[0]
        self.assertEqual(payload["uuid"], "from-response")

    def test_never_raises(self):
        """Bad input should never propagate."""
        self.fire(None, "POST", None, None)
        h = self._make_handler("/api/v1/crud/d/order")
        self.fire(h, None, None, None)


# ═══════════════════════════════════════════════════════════════════
# 4. _sl_fire_event_safe — thread-dispatch safety
# ═══════════════════════════════════════════════════════════════════

class TestFireEventSafe(unittest.TestCase):
    def test_runs_in_thread(self):
        """fire_event_safe spawns a daemon thread."""
        mod = _TestContext.module

        calls = []

        def fake_trigger(event, payload):
            calls.append((event, payload))

        fake_sl = MagicMock()
        fake_sl.trigger = fake_trigger
        mod._sl_default = lambda: fake_sl

        mod._sl_fire_event_safe("@test", {"key": "val"})

        for _ in range(20):
            if calls:
                break
            time.sleep(0.05)
        self.assertEqual(calls, [("@test", {"key": "val"})])

    def test_missing_default_noop(self):
        """When _sl_default is None, fire is a silent no-op."""
        mod = _TestContext.module
        original = mod._sl_default
        try:
            mod._sl_default = None
            mod._sl_fire_event_safe("@test", {})
        finally:
            mod._sl_default = original

    def test_trigger_exception_swallowed(self):
        """If trigger() raises inside the thread, it never propagates."""
        mod = _TestContext.module

        fake_sl = MagicMock()
        fake_sl.trigger = MagicMock(side_effect=Exception("boom"))
        mod._sl_default = lambda: fake_sl

        mod._sl_fire_event_safe("@test", {})
        time.sleep(0.1)


if __name__ == "__main__":
    unittest.main(verbosity=2)
