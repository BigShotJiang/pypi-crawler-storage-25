#!/usr/bin/env python3
"""
test_service_lib.py — Unit tests for supero.service_lib (v1.5.71 simplified).
"""
import json
import os
import time
import unittest
from unittest.mock import MagicMock, patch
from urllib.error import HTTPError
import io
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
# Also look in src/supero (sibling of test/ in the SDK layout)
sys.path.insert(0, os.path.join(
    os.path.dirname(os.path.abspath(__file__)), "..", "src", "supero"))
import service_lib as sl_mod




# V4_TEST_PATCH_APPLIED_AST_V2

# ═══════════════════════════════════════════════════════════════════
# 1. Dotted-path resolver
# ═══════════════════════════════════════════════════════════════════

class TestResolveDottedPath(unittest.TestCase):
    def test_top_level(self):
        self.assertEqual(sl_mod._resolve_dotted_path({"a": 1}, "a"), 1)

    def test_nested(self):
        self.assertEqual(
            sl_mod._resolve_dotted_path({"user": {"email": "x@y.com"}}, "user.email"),
            "x@y.com")

    def test_three_levels(self):
        self.assertEqual(
            sl_mod._resolve_dotted_path({"a": {"b": {"c": 42}}}, "a.b.c"), 42)

    def test_missing_returns_none(self):
        self.assertIsNone(sl_mod._resolve_dotted_path({"a": 1}, "b"))

    def test_partial_missing_returns_none(self):
        self.assertIsNone(sl_mod._resolve_dotted_path({"a": {"b": 1}}, "a.c"))

    def test_empty_path_returns_none(self):
        self.assertIsNone(sl_mod._resolve_dotted_path({"a": 1}, ""))

    def test_non_dict_intermediate(self):
        self.assertIsNone(sl_mod._resolve_dotted_path({"a": "str"}, "a.b"))

    def test_zero_value_is_returned(self):
        self.assertEqual(sl_mod._resolve_dotted_path({"a": 0}, "a"), 0)

    def test_false_value_is_returned(self):
        self.assertEqual(sl_mod._resolve_dotted_path({"a": False}, "a"), False)


# ═══════════════════════════════════════════════════════════════════
# 2. Input-map resolver
# ═══════════════════════════════════════════════════════════════════

class TestResolveInputMap(unittest.TestCase):
    def test_empty_map_returns_empty(self):
        self.assertEqual(sl_mod._resolve_input_map({}, {"a": 1}), {})

    def test_non_dict_map_returns_empty(self):
        self.assertEqual(sl_mod._resolve_input_map(None, {}), {})

    def test_simple_mapping(self):
        result = sl_mod._resolve_input_map(
            {"email": "user.email"},
            {"user": {"email": "x@y.com"}})
        self.assertEqual(result, {"email": "x@y.com"})

    def test_missing_path_omitted(self):
        result = sl_mod._resolve_input_map(
            {"email": "user.email", "name": "user.name"},
            {"user": {"email": "x@y.com"}})
        self.assertEqual(result, {"email": "x@y.com"})
        self.assertNotIn("name", result)

    def test_literal_passes_through(self):
        result = sl_mod._resolve_input_map(
            {"count": 5, "active": True}, {})
        self.assertEqual(result, {"count": 5, "active": True})

    def test_multiple_paths(self):
        payload = {
            "user": {"email": "x@y.com", "name": "Alice"},
            "record": {"uuid": "abc", "total": 99.50},
        }
        result = sl_mod._resolve_input_map({
            "customer_email": "user.email",
            "order_uuid": "record.uuid",
            "amount": "record.total",
        }, payload)
        self.assertEqual(result, {
            "customer_email": "x@y.com",
            "order_uuid": "abc",
            "amount": 99.50,
        })


# ═══════════════════════════════════════════════════════════════════
# 3. ServiceLib instantiation
# ═══════════════════════════════════════════════════════════════════

class TestServiceLibInit(unittest.TestCase):
    def setUp(self):
        sl_mod.reset_default()

    def test_defaults(self):
        sl = sl_mod.ServiceLib()
        self.assertEqual(sl.api_url, "https://api.supero.dev")
        self.assertEqual(sl.api_key, "")
        self.assertEqual(sl.domain, "")

    def test_strips_trailing_slash(self):
        self.assertEqual(
            sl_mod.ServiceLib(api_url="https://x.com/").api_url, "https://x.com")

    def test_strips_quotes(self):
        sl = sl_mod.ServiceLib(api_key='"k"', domain="'d'")
        self.assertEqual(sl.api_key, "k")
        self.assertEqual(sl.domain, "d")

    def test_from_env(self):
        env = {
            "SUPERO_URL": "https://x.com",
            "SUPERO_API_KEY": "test-key",
            "SUPERO_DOMAIN": "test-dom",
            "SUPERO_PROJECT_UUID": "uuid-x",
        }
        sl = sl_mod.ServiceLib.from_env(env)
        self.assertEqual(sl.api_url, "https://x.com")
        self.assertEqual(sl.api_key, "test-key")
        self.assertEqual(sl.domain, "test-dom")
        self.assertEqual(sl.project_uuid, "uuid-x")


# ═══════════════════════════════════════════════════════════════════
# 4. Typed accessors
# ═══════════════════════════════════════════════════════════════════

class TestTypedAccessors(unittest.TestCase):
    def setUp(self):
        self.sl = sl_mod.ServiceLib(api_key="k", domain="d")

    def test_all_accessors_wired(self):
        expected = {
            "email": "email", "email_smtp": "email_smtp",
            "sms": "sms", "whatsapp": "whatsapp",
            "push": "push_notification", "slack": "slack",
            "stripe": "stripe_checkout", "ai": "ai",
            "workflow": "workflows", "otp": "auth_otp",
        }
        for attr, sid in expected.items():
            svc = getattr(self.sl, attr)
            self.assertEqual(svc._service_id, sid)

    def test_accessor_cached(self):
        self.assertIs(self.sl.email, self.sl.email)

    def test_email_payload(self):
        self.sl.exec = MagicMock(return_value={})
        self.sl.email.send(
            to="u@x.com", subject="Hi",
            body_html="<p>Hello</p>", from_name="Acme")
        self.sl.exec.assert_called_with("email", "send_email", {
            "to_email": "u@x.com", "subject": "Hi",
            "body_html": "<p>Hello</p>", "from_name": "Acme",
        })

    def test_email_omits_empty_body(self):
        self.sl.exec = MagicMock(return_value={})
        self.sl.email.send(to="u@x.com", subject="Hi")
        call_args = self.sl.exec.call_args[0][2]
        self.assertNotIn("body_html", call_args)
        self.assertNotIn("body_text", call_args)

    def test_slack_message(self):
        self.sl.exec = MagicMock(return_value={})
        self.sl.slack.message("#ops", "alert")
        self.sl.exec.assert_called_with("slack", "send_message",
                                         {"channel": "#ops", "text": "alert"})

    def test_workflow_run(self):
        self.sl.exec = MagicMock(return_value={})
        self.sl.workflow.run("wf", arg1=1, arg2="two")
        self.sl.exec.assert_called_with("workflows", "run_workflow", {
            "workflow_id": "wf", "input": {"arg1": 1, "arg2": "two"},
        })


# ═══════════════════════════════════════════════════════════════════
# 5. exec() safety
# ═══════════════════════════════════════════════════════════════════

class TestExecSafety(unittest.TestCase):
    def setUp(self):
        self.logger = MagicMock()

    def test_missing_api_key(self):
        sl = sl_mod.ServiceLib(api_key="", domain="d", logger=self.logger)
        self.assertIsNone(sl.exec("email", "op", {}))
        self.logger.assert_called()

    def test_missing_domain(self):
        sl = sl_mod.ServiceLib(api_key="k", domain="", logger=self.logger)
        self.assertIsNone(sl.exec("email", "op", {}))

    @patch("service_lib.PlatformClient")
    def test_success(self, mock_pc_class):
        """v4: exec() routes through PlatformClient.post()."""
        mock_http = mock_pc_class.return_value
        mock_http.post.return_value = {"success": True}
        sl = sl_mod.ServiceLib(api_key="k", domain="d")
        self.assertEqual(sl.exec("email", "op", {}), {"success": True})
        mock_pc_class.assert_called_once()
        self.assertEqual(mock_pc_class.call_args.kwargs.get("api_key"), "k")
        mock_http.post.assert_called_once()
        self.assertEqual(
            mock_http.post.call_args.args[0], "/api/v1/services/execute"
        )

    @patch("service_lib.PlatformClient")
    def test_http_error_none(self, mock_pc_class):
        """v4: any exception from http.post() → exec() returns None."""
        mock_http = mock_pc_class.return_value
        mock_http.post.side_effect = RuntimeError("HTTP 500")
        sl = sl_mod.ServiceLib(api_key="k", domain="d")
        self.assertIsNone(sl.exec("email", "op", {}))

    @patch("service_lib.PlatformClient")
    def test_network_error_none(self, mock_pc_class):
        """v4: connection errors surface as exceptions; exec() returns None."""
        mock_http = mock_pc_class.return_value
        mock_http.post.side_effect = Exception("conn refused")
        sl = sl_mod.ServiceLib(api_key="k", domain="d")
        self.assertIsNone(sl.exec("email", "op", {}))

    @patch("service_lib.PlatformClient")
    def test_payload_uses_operation(self, mock_pc_class):
        """v4: payload sent via http.post has service_id/operation/input."""
        mock_http = mock_pc_class.return_value
        mock_http.post.return_value = {}
        sl = sl_mod.ServiceLib(api_key="k", domain="d")
        sl.exec("email", "send_email", {})
        body = mock_http.post.call_args.kwargs["json"]
        self.assertEqual(body["operation"], "send_email")
        self.assertEqual(body["service_id"], "email")
        self.assertNotIn("operation_id", body)  # old buggy field name regression check

    @patch("service_lib.PlatformClient")
    def test_project_uuid_included_when_set(self, mock_pc_class):
        """v4: project_uuid present in payload when set."""
        mock_http = mock_pc_class.return_value
        mock_http.post.return_value = {}
        sl = sl_mod.ServiceLib(api_key="k", domain="d", project_uuid="uuid")
        sl.exec("email", "op", {})
        body = mock_http.post.call_args.kwargs["json"]
        self.assertEqual(body["project_uuid"], "uuid")

    @patch("service_lib.PlatformClient")
    def test_project_uuid_omitted_when_empty(self, mock_pc_class):
        """v4: project_uuid absent from payload when empty."""
        mock_http = mock_pc_class.return_value
        mock_http.post.return_value = {}
        sl = sl_mod.ServiceLib(api_key="k", domain="d")
        sl.exec("email", "op", {})
        body = mock_http.post.call_args.kwargs["json"]
        self.assertNotIn("project_uuid", body)

    @patch("service_lib.PlatformClient")
    def test_x_api_key_header(self, mock_pc_class):
        """v4: API key is passed to PlatformClient on construction
        (not per-request header — PlatformClient owns it).
        """
        mock_http = mock_pc_class.return_value
        mock_http.post.return_value = {}
        sl = sl_mod.ServiceLib(api_key="secret", domain="d")
        sl.exec("email", "op", {})
        self.assertEqual(
            mock_pc_class.call_args.kwargs.get("api_key"), "secret"
        )


# ═══════════════════════════════════════════════════════════════════
# 6. trigger()
# ═══════════════════════════════════════════════════════════════════

class TestTrigger(unittest.TestCase):
    def setUp(self):
        self.logger = MagicMock()
        self.sl = sl_mod.ServiceLib(api_key="k", domain="d", logger=self.logger)

    def test_empty_event_none(self):
        self.assertIsNone(self.sl.trigger(""))
        self.assertIsNone(self.sl.trigger(None))

    def test_no_binding_none(self):
        self.sl._fetch_config = MagicMock(return_value={"event_bindings": []})
        self.assertIsNone(self.sl.trigger("@signup", {"user": {"email": "x"}}))

    def test_config_empty_none(self):
        self.sl._fetch_config = MagicMock(return_value={})
        self.assertIsNone(self.sl.trigger("@signup", {}))

    def test_matched_binding_calls_exec(self):
        self.sl._fetch_config = MagicMock(return_value={
            "event_bindings": [{
                "event": "@signup",
                "workflow_id": "welcome",
                "input_map": {"email": "user.email"},
            }],
        })
        self.sl.exec = MagicMock(return_value={"success": True})

        result = self.sl.trigger("@signup", {"user": {"email": "x@y.com"}})

        self.sl.exec.assert_called_once()
        args = self.sl.exec.call_args[0]
        self.assertEqual(args[0], "workflows")
        self.assertEqual(args[1], "run_workflow")
        self.assertEqual(args[2]["workflow_id"], "welcome")
        self.assertEqual(args[2]["input"], {"email": "x@y.com"})
        self.assertEqual(args[2]["trigger_source"], "event:@signup")

    def test_missing_workflow_id(self):
        self.sl._fetch_config = MagicMock(return_value={
            "event_bindings": [{"event": "@signup", "input_map": {}}],
        })
        self.sl.exec = MagicMock(return_value={})
        self.assertIsNone(self.sl.trigger("@signup", {}))
        self.sl.exec.assert_not_called()

    def test_first_match_wins(self):
        self.sl._fetch_config = MagicMock(return_value={
            "event_bindings": [
                {"event": "@signup", "workflow_id": "first", "input_map": {}},
                {"event": "@signup", "workflow_id": "second", "input_map": {}},
            ],
        })
        self.sl.exec = MagicMock(return_value={})
        self.sl.trigger("@signup", {})
        self.assertEqual(
            self.sl.exec.call_args[0][2]["workflow_id"], "first")

    def test_trigger_source_format(self):
        self.sl._fetch_config = MagicMock(return_value={
            "event_bindings": [{
                "event": "@create:order",
                "workflow_id": "order_wf",
                "input_map": {},
            }],
        })
        captured = {}
        self.sl.exec = MagicMock(
            side_effect=lambda *a, **kw: captured.update({"a": a}))
        self.sl.trigger("@create:order", {})
        self.assertEqual(
            captured["a"][2]["trigger_source"], "event:@create:order")

    def test_trigger_never_raises_on_fetch_exception(self):
        """If _fetch_config raises, trigger() must return None, not propagate.

        server.py hooks depend on this — a failing trigger can never
        crash a user's request.
        """
        self.sl._fetch_config = MagicMock(
            side_effect=Exception("config fetch boom"))
        result = self.sl.trigger("@signup", {"user": {"email": "x"}})
        self.assertIsNone(result)

    def test_trigger_never_raises_on_exec_exception(self):
        """If exec itself raises (shouldn't, but defense in depth)."""
        self.sl._fetch_config = MagicMock(return_value={
            "event_bindings": [{"event": "@x", "workflow_id": "w", "input_map": {}}],
        })
        self.sl.exec = MagicMock(side_effect=Exception("exec boom"))
        result = self.sl.trigger("@x", {})
        self.assertIsNone(result)


# ═══════════════════════════════════════════════════════════════════
# 7. Config cache
# ═══════════════════════════════════════════════════════════════════

class TestConfigCache(unittest.TestCase):
    def setUp(self):
        self.sl = sl_mod.ServiceLib(
            api_key="k", domain="d", config_ttl_seconds=60)

    def test_cache_miss_fetches(self):
        self.sl._fetch_config = MagicMock(return_value={})
        self.sl._get_cached_config()
        self.sl._fetch_config.assert_called_once()

    def test_cache_hit_no_refetch(self):
        self.sl._fetch_config = MagicMock(return_value={})
        for _ in range(3):
            self.sl._get_cached_config()
        self.sl._fetch_config.assert_called_once()

    def test_expired_refetches(self):
        self.sl._fetch_config = MagicMock(return_value={})
        self.sl._get_cached_config()
        self.sl._config_cache_expires = 0
        self.sl._get_cached_config()
        self.assertEqual(self.sl._fetch_config.call_count, 2)

    def test_refresh_forces_refetch(self):
        self.sl._fetch_config = MagicMock(return_value={})
        self.sl._get_cached_config()
        self.sl.refresh_config()
        self.sl._get_cached_config()
        self.assertEqual(self.sl._fetch_config.call_count, 2)


# ═══════════════════════════════════════════════════════════════════
# 8. Singleton
# ═══════════════════════════════════════════════════════════════════

class TestSingleton(unittest.TestCase):
    def setUp(self):
        sl_mod.reset_default()
        os.environ["SUPERO_API_KEY"] = "t"
        os.environ["SUPERO_DOMAIN"] = "td"

    def tearDown(self):
        sl_mod.reset_default()

    def test_same_instance(self):
        self.assertIs(sl_mod.default(), sl_mod.default())

    def test_reset_creates_new(self):
        a = sl_mod.default()
        sl_mod.reset_default()
        self.assertIsNot(a, sl_mod.default())

    def test_reads_env(self):
        a = sl_mod.default()
        self.assertEqual(a.api_key, "t")
        self.assertEqual(a.domain, "td")


# ═══════════════════════════════════════════════════════════════════
# 9. Services backward-compat shim
# ═══════════════════════════════════════════════════════════════════

class TestServicesShim(unittest.TestCase):
    def setUp(self):
        os.environ["SUPERO_API_KEY"] = "shim-k"
        os.environ.pop("SUPERO_PROJECT_UUID", None)

    def test_legacy_signature(self):
        svc = sl_mod.Services(None, "https://x.com", "d")
        self.assertEqual(svc.api_url, "https://x.com")
        self.assertEqual(svc.api_key, "shim-k")
        self.assertEqual(svc.domain, "d")

    def test_accessors_available(self):
        svc = sl_mod.Services(None, "http://x", "d")
        for a in ["email", "slack", "workflow", "stripe", "ai", "sms"]:
            self.assertTrue(hasattr(svc, a))

    def test_trigger_available(self):
        svc = sl_mod.Services(None, "http://x", "d")
        self.assertTrue(callable(svc.trigger))


# ═══════════════════════════════════════════════════════════════════
# 10. _fetch_config
# ═══════════════════════════════════════════════════════════════════

class TestFetchConfig(unittest.TestCase):
    def test_missing_creds_returns_empty(self):
        sl = sl_mod.ServiceLib(api_key="", domain="")
        self.assertEqual(sl._fetch_config(), {})

    @patch("service_lib.PlatformClient")
    def test_success(self, mock_pc_class):
        """v4: _fetch_config via http.get() returns config_data dict."""
        mock_http = mock_pc_class.return_value
        mock_http.get.return_value = {
            "config_data": {"event_bindings": [{"event": "@x"}]}
        }
        sl = sl_mod.ServiceLib(api_key="k", domain="d")
        self.assertEqual(
            sl._fetch_config(), {"event_bindings": [{"event": "@x"}]}
        )
        mock_http.get.assert_called_once_with(
            "/api/v1/services/workflows/config"
        )

    @patch("service_lib.PlatformClient")
    def test_http_error_empty(self, mock_pc_class):
        """v4: http.get() error → _fetch_config returns {}."""
        mock_http = mock_pc_class.return_value
        mock_http.get.side_effect = RuntimeError("HTTP 404")
        sl = sl_mod.ServiceLib(api_key="k", domain="d")
        self.assertEqual(sl._fetch_config(), {})

    @patch("service_lib.PlatformClient")
    def test_malformed_empty(self, mock_pc_class):
        """v4: non-dict response from http.get() → _fetch_config returns {}."""
        mock_http = mock_pc_class.return_value
        mock_http.get.return_value = "not a dict"  # PlatformClient might return anything
        sl = sl_mod.ServiceLib(api_key="k", domain="d")
        self.assertEqual(sl._fetch_config(), {})

    @patch("service_lib.urllib.request.urlopen")
    def test_missing_config_data_empty(self, mock_open):
        resp = MagicMock()
        resp.__enter__.return_value = resp
        resp.read.return_value = b'{"other": "field"}'
        mock_open.return_value = resp
        sl = sl_mod.ServiceLib(api_key="k", domain="d")
        self.assertEqual(sl._fetch_config(), {})


if __name__ == "__main__":
    unittest.main(verbosity=2)
