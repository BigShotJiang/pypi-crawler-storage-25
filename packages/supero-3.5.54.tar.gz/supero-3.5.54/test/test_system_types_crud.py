"""
Unit Tests for System Types in Supero CRUD Operations

Tests that entities with rich system type attributes (Image, File, Currency,
PhoneNumber, Email, Address, Signature, GeoLocation, DateRange, URL) can be
created, read, updated, and listed correctly through the Supero library.

These tests use mock platform client — no live server required.
"""

import unittest
import json
from typing import Any, Dict, List, Optional


# ============================================================================
# Mock Platform Client (same pattern as test_supero_core_crud.py)
# ============================================================================

class MockPlatformClient:
    """Mock PlatformClient for testing system types in CRUD operations."""

    def __init__(self, domain_name="test-domain", domain_uuid="domain-uuid-123"):
        self.domain_name = domain_name
        self.domain_uuid = domain_uuid
        self.base_url = "http://localhost:8083/api/v1"
        self.project_name = "car-rental"
        self.project_uuid = "project-uuid-456"
        self.tenant_name = "test-tenant"
        self.tenant_uuid = "tenant-uuid-789"
        self._responses: Dict[str, Any] = {}
        self._errors: Dict[str, Exception] = {}
        self._calls: List[Dict] = []

    def set_response(self, endpoint: str, response: Any):
        self._responses[endpoint] = response

    def set_error(self, endpoint: str, error: Exception):
        self._errors[endpoint] = error

    def get_calls(self) -> List[Dict]:
        return self._calls

    def last_call(self) -> Optional[Dict]:
        return self._calls[-1] if self._calls else None

    def clear_calls(self):
        self._calls = []

    def _handle_call(self, method: str, endpoint: str, **kwargs) -> Any:
        self._calls.append({"method": method, "endpoint": endpoint, **kwargs})
        if endpoint in self._errors:
            raise self._errors[endpoint]
        return self._responses.get(endpoint, {"default": f"{method.lower()}_response"})

    def get(self, endpoint: str, params: Dict = None, **kwargs) -> Any:
        return self._handle_call("GET", endpoint, params=params, **kwargs)

    def post(self, endpoint: str, json: Dict = None, **kwargs) -> Any:
        return self._handle_call("POST", endpoint, json=json, **kwargs)

    def put(self, endpoint: str, json: Dict = None, **kwargs) -> Any:
        return self._handle_call("PUT", endpoint, json=json, **kwargs)

    def delete(self, endpoint: str, **kwargs) -> Any:
        return self._handle_call("DELETE", endpoint, **kwargs)


# ============================================================================
# Minimal Supero wrapper (delegates to platform client)
# ============================================================================

class SuperoTestClient:
    """Minimal Supero-like client for testing CRUD with system types."""

    def __init__(self, platform_client):
        self._client = platform_client
        self.domain = platform_client.domain_name

    def create(self, entity_type: str, data: Dict) -> Dict:
        endpoint = f"/api/v1/crud/{self.domain}/{entity_type}"
        return self._client.post(endpoint, json={entity_type: data})

    def get(self, entity_type: str, uuid: str) -> Dict:
        endpoint = f"/api/v1/crud/{self.domain}/{entity_type}/{uuid}"
        return self._client.get(endpoint)

    def update(self, entity_type: str, uuid: str, data: Dict) -> Dict:
        endpoint = f"/api/v1/crud/{self.domain}/{entity_type}/{uuid}"
        return self._client.put(endpoint, json={entity_type: data})

    def delete(self, entity_type: str, uuid: str) -> Dict:
        endpoint = f"/api/v1/crud/{self.domain}/{entity_type}/{uuid}"
        return self._client.delete(endpoint)

    def list(self, entity_type: str, params: Dict = None) -> Dict:
        endpoint = f"/api/v1/crud/{self.domain}/{entity_type}"
        return self._client.get(endpoint, params=params)


# ============================================================================
# Sample Data Fixtures — realistic system type values
# ============================================================================

SAMPLE_IMAGE = {
    "file_id": "img_abc123",
    "filename": "front-view.jpg",
    "mime_type": "image/jpeg",
    "size_bytes": 245000,
    "url": "/api/v1/files/test-domain/img_abc123",
    "thumbnail_url": "/api/v1/files/test-domain/img_abc123/thumb",
    "width": 1920,
    "height": 1080,
    "uploaded_at": "2026-01-15T10:30:00Z"
}

SAMPLE_IMAGE_2 = {
    "file_id": "img_def456",
    "filename": "rear-view.jpg",
    "mime_type": "image/jpeg",
    "size_bytes": 312000,
    "url": "/api/v1/files/test-domain/img_def456",
    "thumbnail_url": "/api/v1/files/test-domain/img_def456/thumb",
    "width": 1920,
    "height": 1080,
    "uploaded_at": "2026-01-15T10:31:00Z"
}

SAMPLE_FILE = {
    "file_id": "file_reg001",
    "filename": "registration.pdf",
    "mime_type": "application/pdf",
    "size_bytes": 1500000,
    "url": "/api/v1/files/test-domain/file_reg001",
    "thumbnail_url": None,
    "uploaded_at": "2026-01-10T08:00:00Z"
}

SAMPLE_CURRENCY = {
    "amount": 350.00,
    "currency_code": "USD"
}

SAMPLE_CURRENCY_INR = {
    "amount": 25000.00,
    "currency_code": "INR"
}

SAMPLE_PHONE = {
    "number": "+15551234567",
    "country_code": "US",
    "label": "mobile"
}

SAMPLE_EMAIL = {
    "address": "john.doe@example.com",
    "verified": True,
    "label": "personal"
}

SAMPLE_ADDRESS = {
    "line1": "123 Main Street",
    "line2": "Apt 4B",
    "city": "San Francisco",
    "state": "CA",
    "postal_code": "94102",
    "country": "US",
    "lat": 37.7749,
    "lng": -122.4194
}

SAMPLE_GEOLOCATION = {
    "lat": 37.7749,
    "lng": -122.4194,
    "accuracy_m": 10.0,
    "label": "Office Parking Lot",
    "recorded_at": "2026-01-15T10:30:00Z"
}

SAMPLE_SIGNATURE = {
    "image_data": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJ...",
    "signed_at": "2026-01-15T10:45:00Z",
    "signed_by": "John Doe",
    "ip_address": "192.168.1.100"
}

SAMPLE_DATE_RANGE = {
    "start_date": "2026-01-15T00:00:00Z",
    "end_date": "2026-02-15T00:00:00Z",
    "timezone": "America/Los_Angeles"
}

SAMPLE_URL = {
    "url": "https://www.example.com",
    "label": "Company Website"
}


# ============================================================================
# Test: Create entities with system type fields
# ============================================================================

class TestCreateWithSystemTypes(unittest.TestCase):
    """Test creating entities that use system type attributes."""

    def setUp(self):
        self.mock_client = MockPlatformClient()
        self.supero = SuperoTestClient(self.mock_client)

    def test_create_vehicle_with_image_and_currency(self):
        """Create a vehicle with Image (list) and Currency fields."""
        endpoint = "/api/v1/crud/test-domain/vehicle"
        self.mock_client.set_response(endpoint, {
            "vehicle": {
                "uuid": "vehicle-uuid-001",
                "make": "Toyota",
                "model": "Camry",
                "weekly_rate": SAMPLE_CURRENCY,
                "vehicle_photos": [SAMPLE_IMAGE, SAMPLE_IMAGE_2],
                "registration_doc": SAMPLE_FILE,
            }
        })

        result = self.supero.create("vehicle", {
            "make": "Toyota",
            "model": "Camry",
            "year": 2024,
            "weekly_rate": SAMPLE_CURRENCY,
            "vehicle_photos": [SAMPLE_IMAGE, SAMPLE_IMAGE_2],
            "registration_doc": SAMPLE_FILE,
        })

        # Verify call was made
        call = self.mock_client.last_call()
        self.assertEqual(call["method"], "POST")
        self.assertIn("/vehicle", call["endpoint"])

        # Verify payload includes system type data
        payload = call["json"]["vehicle"]
        self.assertEqual(payload["weekly_rate"]["amount"], 350.00)
        self.assertEqual(payload["weekly_rate"]["currency_code"], "USD")
        self.assertEqual(len(payload["vehicle_photos"]), 2)
        self.assertEqual(payload["vehicle_photos"][0]["file_id"], "img_abc123")
        self.assertEqual(payload["registration_doc"]["mime_type"], "application/pdf")

    def test_create_customer_with_email_phone_address(self):
        """Create a customer with Email, PhoneNumber, and Address fields."""
        endpoint = "/api/v1/crud/test-domain/customer"
        self.mock_client.set_response(endpoint, {
            "customer": {
                "uuid": "customer-uuid-001",
                "full_name": "John Doe",
                "email": SAMPLE_EMAIL,
                "mobile": SAMPLE_PHONE,
                "home_address": SAMPLE_ADDRESS,
            }
        })

        result = self.supero.create("customer", {
            "full_name": "John Doe",
            "email": SAMPLE_EMAIL,
            "mobile": SAMPLE_PHONE,
            "home_address": SAMPLE_ADDRESS,
            "driver_license": [SAMPLE_IMAGE],
        })

        call = self.mock_client.last_call()
        payload = call["json"]["customer"]
        self.assertEqual(payload["email"]["address"], "john.doe@example.com")
        self.assertTrue(payload["email"]["verified"])
        self.assertEqual(payload["mobile"]["number"], "+15551234567")
        self.assertEqual(payload["mobile"]["country_code"], "US")
        self.assertEqual(payload["home_address"]["city"], "San Francisco")
        self.assertEqual(payload["home_address"]["postal_code"], "94102")
        self.assertIsInstance(payload["driver_license"], list)

    def test_create_rental_with_signature_daterange_currency(self):
        """Create a rental with Signature, DateRange, Currency, and File fields."""
        endpoint = "/api/v1/crud/test-domain/rental"
        self.mock_client.set_response(endpoint, {
            "rental": {"uuid": "rental-uuid-001", "status": "agreement_pending"}
        })

        result = self.supero.create("rental", {
            "status": "agreement_pending",
            "rental_period": SAMPLE_DATE_RANGE,
            "weekly_rate": SAMPLE_CURRENCY,
            "deposit_amount": {"amount": 500.00, "currency_code": "USD"},
            "agreement_pdf": SAMPLE_FILE,
            "customer_signature": SAMPLE_SIGNATURE,
        })

        call = self.mock_client.last_call()
        payload = call["json"]["rental"]
        self.assertEqual(payload["rental_period"]["start_date"], "2026-01-15T00:00:00Z")
        self.assertEqual(payload["rental_period"]["end_date"], "2026-02-15T00:00:00Z")
        self.assertEqual(payload["weekly_rate"]["amount"], 350.00)
        self.assertEqual(payload["deposit_amount"]["amount"], 500.00)
        self.assertEqual(payload["customer_signature"]["signed_by"], "John Doe")
        self.assertIn("image_data", payload["customer_signature"])

    def test_create_inspection_with_geolocation_and_images(self):
        """Create an inspection with GeoLocation, multiple Image lists, and Signature."""
        endpoint = "/api/v1/crud/test-domain/inspection"
        self.mock_client.set_response(endpoint, {
            "inspection": {"uuid": "inspection-uuid-001"}
        })

        result = self.supero.create("inspection", {
            "odometer_reading": 45230,
            "fuel_level": "three_quarter",
            "exterior_photos": [SAMPLE_IMAGE, SAMPLE_IMAGE_2],
            "interior_photos": [SAMPLE_IMAGE],
            "damage_photos": [],
            "inspector_signature": SAMPLE_SIGNATURE,
            "inspection_location": SAMPLE_GEOLOCATION,
        })

        call = self.mock_client.last_call()
        payload = call["json"]["inspection"]
        self.assertEqual(len(payload["exterior_photos"]), 2)
        self.assertEqual(len(payload["interior_photos"]), 1)
        self.assertEqual(len(payload["damage_photos"]), 0)
        self.assertEqual(payload["inspection_location"]["lat"], 37.7749)
        self.assertEqual(payload["inspection_location"]["lng"], -122.4194)
        self.assertEqual(payload["inspection_location"]["label"], "Office Parking Lot")

    def test_create_payment_with_currency_and_file(self):
        """Create a payment with Currency and File (receipt) fields."""
        endpoint = "/api/v1/crud/test-domain/payment"
        self.mock_client.set_response(endpoint, {
            "payment": {"uuid": "payment-uuid-001", "status": "paid"}
        })

        result = self.supero.create("payment", {
            "amount": SAMPLE_CURRENCY,
            "status": "paid",
            "payment_method": "card",
            "receipt": SAMPLE_FILE,
            "transaction_ref": "TXN-20260115-001",
        })

        call = self.mock_client.last_call()
        payload = call["json"]["payment"]
        self.assertEqual(payload["amount"]["amount"], 350.00)
        self.assertEqual(payload["receipt"]["file_id"], "file_reg001")


# ============================================================================
# Test: Read/Get entities with system type fields
# ============================================================================

class TestGetWithSystemTypes(unittest.TestCase):
    """Test reading entities that have system type attribute values."""

    def setUp(self):
        self.mock_client = MockPlatformClient()
        self.supero = SuperoTestClient(self.mock_client)

    def test_get_vehicle_returns_image_list(self):
        """GET vehicle returns Image list with file_id, url, thumbnail_url."""
        endpoint = "/api/v1/crud/test-domain/vehicle/vehicle-uuid-001"
        self.mock_client.set_response(endpoint, {
            "vehicle": {
                "uuid": "vehicle-uuid-001",
                "make": "Toyota",
                "model": "Camry",
                "weekly_rate": SAMPLE_CURRENCY,
                "vehicle_photos": [SAMPLE_IMAGE, SAMPLE_IMAGE_2],
                "registration_doc": SAMPLE_FILE,
                "current_location": SAMPLE_GEOLOCATION,
            }
        })

        result = self.supero.get("vehicle", "vehicle-uuid-001")
        vehicle = result["vehicle"]

        # Currency sub-fields accessible
        self.assertEqual(vehicle["weekly_rate"]["amount"], 350.00)
        self.assertEqual(vehicle["weekly_rate"]["currency_code"], "USD")

        # Image list sub-fields accessible
        self.assertEqual(len(vehicle["vehicle_photos"]), 2)
        self.assertEqual(vehicle["vehicle_photos"][0]["filename"], "front-view.jpg")
        self.assertEqual(vehicle["vehicle_photos"][0]["thumbnail_url"],
                         "/api/v1/files/test-domain/img_abc123/thumb")
        self.assertEqual(vehicle["vehicle_photos"][1]["filename"], "rear-view.jpg")

        # File sub-fields accessible
        self.assertEqual(vehicle["registration_doc"]["mime_type"], "application/pdf")

        # GeoLocation sub-fields accessible
        self.assertEqual(vehicle["current_location"]["lat"], 37.7749)
        self.assertIn("accuracy_m", vehicle["current_location"])

    def test_get_customer_returns_contact_types(self):
        """GET customer returns Email, PhoneNumber, Address structured data."""
        endpoint = "/api/v1/crud/test-domain/customer/customer-uuid-001"
        self.mock_client.set_response(endpoint, {
            "customer": {
                "uuid": "customer-uuid-001",
                "full_name": "John Doe",
                "email": SAMPLE_EMAIL,
                "mobile": SAMPLE_PHONE,
                "home_address": SAMPLE_ADDRESS,
                "website": SAMPLE_URL,
            }
        })

        result = self.supero.get("customer", "customer-uuid-001")
        customer = result["customer"]

        # Email sub-fields
        self.assertEqual(customer["email"]["address"], "john.doe@example.com")
        self.assertTrue(customer["email"]["verified"])

        # PhoneNumber sub-fields
        self.assertEqual(customer["mobile"]["number"], "+15551234567")

        # Address sub-fields
        self.assertEqual(customer["home_address"]["city"], "San Francisco")
        self.assertEqual(customer["home_address"]["state"], "CA")
        self.assertEqual(customer["home_address"]["lat"], 37.7749)

        # URL sub-fields
        self.assertEqual(customer["website"]["url"], "https://www.example.com")

    def test_get_rental_returns_signature_and_daterange(self):
        """GET rental returns Signature and DateRange structured data."""
        endpoint = "/api/v1/crud/test-domain/rental/rental-uuid-001"
        self.mock_client.set_response(endpoint, {
            "rental": {
                "uuid": "rental-uuid-001",
                "status": "active",
                "rental_period": SAMPLE_DATE_RANGE,
                "customer_signature": SAMPLE_SIGNATURE,
                "agreement_pdf": SAMPLE_FILE,
            }
        })

        result = self.supero.get("rental", "rental-uuid-001")
        rental = result["rental"]

        # DateRange sub-fields
        self.assertEqual(rental["rental_period"]["start_date"], "2026-01-15T00:00:00Z")
        self.assertEqual(rental["rental_period"]["end_date"], "2026-02-15T00:00:00Z")
        self.assertEqual(rental["rental_period"]["timezone"], "America/Los_Angeles")

        # Signature sub-fields
        self.assertIn("image_data", rental["customer_signature"])
        self.assertEqual(rental["customer_signature"]["signed_by"], "John Doe")
        self.assertEqual(rental["customer_signature"]["signed_at"], "2026-01-15T10:45:00Z")


# ============================================================================
# Test: Update entities with system type fields
# ============================================================================

class TestUpdateWithSystemTypes(unittest.TestCase):
    """Test updating specific system type fields."""

    def setUp(self):
        self.mock_client = MockPlatformClient()
        self.supero = SuperoTestClient(self.mock_client)

    def test_update_vehicle_add_photo(self):
        """Update vehicle to add a new photo to the Image list."""
        endpoint = "/api/v1/crud/test-domain/vehicle/vehicle-uuid-001"
        new_photo = {
            "file_id": "img_new789",
            "filename": "side-view.jpg",
            "mime_type": "image/jpeg",
            "size_bytes": 280000,
            "url": "/api/v1/files/test-domain/img_new789",
            "thumbnail_url": "/api/v1/files/test-domain/img_new789/thumb",
        }
        self.mock_client.set_response(endpoint, {
            "vehicle": {
                "uuid": "vehicle-uuid-001",
                "vehicle_photos": [SAMPLE_IMAGE, SAMPLE_IMAGE_2, new_photo],
            }
        })

        result = self.supero.update("vehicle", "vehicle-uuid-001", {
            "vehicle_photos": [SAMPLE_IMAGE, SAMPLE_IMAGE_2, new_photo],
        })

        call = self.mock_client.last_call()
        self.assertEqual(call["method"], "PUT")
        payload = call["json"]["vehicle"]
        self.assertEqual(len(payload["vehicle_photos"]), 3)
        self.assertEqual(payload["vehicle_photos"][2]["file_id"], "img_new789")

    def test_update_vehicle_change_rate(self):
        """Update vehicle weekly rate (Currency field)."""
        endpoint = "/api/v1/crud/test-domain/vehicle/vehicle-uuid-001"
        self.mock_client.set_response(endpoint, {
            "vehicle": {"uuid": "vehicle-uuid-001", "weekly_rate": {"amount": 400.00, "currency_code": "USD"}}
        })

        result = self.supero.update("vehicle", "vehicle-uuid-001", {
            "weekly_rate": {"amount": 400.00, "currency_code": "USD"},
        })

        call = self.mock_client.last_call()
        payload = call["json"]["vehicle"]
        self.assertEqual(payload["weekly_rate"]["amount"], 400.00)

    def test_update_customer_phone(self):
        """Update customer phone number (PhoneNumber field)."""
        endpoint = "/api/v1/crud/test-domain/customer/customer-uuid-001"
        new_phone = {"number": "+14155559999", "country_code": "US", "label": "mobile"}
        self.mock_client.set_response(endpoint, {
            "customer": {"uuid": "customer-uuid-001", "mobile": new_phone}
        })

        result = self.supero.update("customer", "customer-uuid-001", {
            "mobile": new_phone,
        })

        call = self.mock_client.last_call()
        payload = call["json"]["customer"]
        self.assertEqual(payload["mobile"]["number"], "+14155559999")

    def test_update_customer_address(self):
        """Update customer address (Address field) with new geocoded location."""
        endpoint = "/api/v1/crud/test-domain/customer/customer-uuid-001"
        new_address = {
            "line1": "456 Oak Avenue",
            "city": "Oakland",
            "state": "CA",
            "postal_code": "94612",
            "country": "US",
            "lat": 37.8044,
            "lng": -122.2712,
        }
        self.mock_client.set_response(endpoint, {
            "customer": {"uuid": "customer-uuid-001", "home_address": new_address}
        })

        result = self.supero.update("customer", "customer-uuid-001", {
            "home_address": new_address,
        })

        call = self.mock_client.last_call()
        payload = call["json"]["customer"]
        self.assertEqual(payload["home_address"]["city"], "Oakland")
        self.assertEqual(payload["home_address"]["lat"], 37.8044)

    def test_update_rental_add_signature(self):
        """Update rental to add customer signature (Signature field)."""
        endpoint = "/api/v1/crud/test-domain/rental/rental-uuid-001"
        self.mock_client.set_response(endpoint, {
            "rental": {"uuid": "rental-uuid-001", "customer_signature": SAMPLE_SIGNATURE}
        })

        result = self.supero.update("rental", "rental-uuid-001", {
            "customer_signature": SAMPLE_SIGNATURE,
            "status": "inspection_pending",
        })

        call = self.mock_client.last_call()
        payload = call["json"]["rental"]
        self.assertIn("image_data", payload["customer_signature"])
        self.assertEqual(payload["status"], "inspection_pending")

    def test_partial_update_preserves_system_type_structure(self):
        """Partial update with only status should not affect Currency/Image fields."""
        endpoint = "/api/v1/crud/test-domain/vehicle/vehicle-uuid-001"
        self.mock_client.set_response(endpoint, {
            "vehicle": {"uuid": "vehicle-uuid-001", "status": "maintenance"}
        })

        result = self.supero.update("vehicle", "vehicle-uuid-001", {
            "status": "maintenance",
        })

        call = self.mock_client.last_call()
        payload = call["json"]["vehicle"]
        # Only status field in update payload — no system type fields
        self.assertEqual(payload["status"], "maintenance")
        self.assertNotIn("weekly_rate", payload)
        self.assertNotIn("vehicle_photos", payload)


# ============================================================================
# Test: List entities with system type fields
# ============================================================================

class TestListWithSystemTypes(unittest.TestCase):
    """Test listing entities that contain system type fields."""

    def setUp(self):
        self.mock_client = MockPlatformClient()
        self.supero = SuperoTestClient(self.mock_client)

    def test_list_vehicles_returns_system_type_data(self):
        """List vehicles returns Currency and Image data in each item."""
        endpoint = "/api/v1/crud/test-domain/vehicle"
        self.mock_client.set_response(endpoint, {
            "vehicles": [
                {
                    "uuid": "v1",
                    "make": "Toyota",
                    "weekly_rate": {"amount": 350.00, "currency_code": "USD"},
                    "vehicle_photos": [SAMPLE_IMAGE],
                },
                {
                    "uuid": "v2",
                    "make": "Honda",
                    "weekly_rate": {"amount": 300.00, "currency_code": "USD"},
                    "vehicle_photos": [],
                },
            ]
        })

        result = self.supero.list("vehicle")
        vehicles = result["vehicles"]

        self.assertEqual(len(vehicles), 2)
        self.assertEqual(vehicles[0]["weekly_rate"]["amount"], 350.00)
        self.assertEqual(len(vehicles[0]["vehicle_photos"]), 1)
        self.assertEqual(vehicles[1]["weekly_rate"]["amount"], 300.00)
        self.assertEqual(len(vehicles[1]["vehicle_photos"]), 0)

    def test_list_customers_returns_contact_types(self):
        """List customers returns Email and PhoneNumber in each item."""
        endpoint = "/api/v1/crud/test-domain/customer"
        self.mock_client.set_response(endpoint, {
            "customers": [
                {
                    "uuid": "c1",
                    "full_name": "Alice",
                    "email": {"address": "alice@example.com", "verified": True},
                    "mobile": {"number": "+15551111111", "country_code": "US"},
                },
                {
                    "uuid": "c2",
                    "full_name": "Bob",
                    "email": {"address": "bob@example.com", "verified": False},
                    "mobile": {"number": "+919876543210", "country_code": "IN"},
                },
            ]
        })

        result = self.supero.list("customer")
        customers = result["customers"]

        self.assertEqual(customers[0]["email"]["address"], "alice@example.com")
        self.assertEqual(customers[1]["mobile"]["country_code"], "IN")

    def test_list_payments_with_currency_aggregate_ready(self):
        """List payments returns Currency data that can be summed client-side."""
        endpoint = "/api/v1/crud/test-domain/payment"
        self.mock_client.set_response(endpoint, {
            "payments": [
                {"uuid": "p1", "amount": {"amount": 350.00, "currency_code": "USD"}, "status": "paid"},
                {"uuid": "p2", "amount": {"amount": 350.00, "currency_code": "USD"}, "status": "paid"},
                {"uuid": "p3", "amount": {"amount": 350.00, "currency_code": "USD"}, "status": "pending"},
            ]
        })

        result = self.supero.list("payment")
        payments = result["payments"]

        # Verify Currency fields can be aggregated
        total = sum(p["amount"]["amount"] for p in payments)
        self.assertEqual(total, 1050.00)

        paid_total = sum(
            p["amount"]["amount"] for p in payments if p["status"] == "paid"
        )
        self.assertEqual(paid_total, 700.00)


# ============================================================================
# Test: Delete entities with system type fields
# ============================================================================

class TestDeleteWithSystemTypes(unittest.TestCase):
    """Test deleting entities that have system type data (files should be cleaned up)."""

    def setUp(self):
        self.mock_client = MockPlatformClient()
        self.supero = SuperoTestClient(self.mock_client)

    def test_delete_vehicle_with_images(self):
        """Delete a vehicle that has Image and File attachments."""
        endpoint = "/api/v1/crud/test-domain/vehicle/vehicle-uuid-001"
        self.mock_client.set_response(endpoint, {"deleted": True})

        result = self.supero.delete("vehicle", "vehicle-uuid-001")

        call = self.mock_client.last_call()
        self.assertEqual(call["method"], "DELETE")
        self.assertIn("vehicle-uuid-001", call["endpoint"])

    def test_delete_rental_with_signature_and_file(self):
        """Delete a rental that has Signature and File data."""
        endpoint = "/api/v1/crud/test-domain/rental/rental-uuid-001"
        self.mock_client.set_response(endpoint, {"deleted": True})

        result = self.supero.delete("rental", "rental-uuid-001")

        call = self.mock_client.last_call()
        self.assertEqual(call["method"], "DELETE")
        self.assertIn("rental-uuid-001", call["endpoint"])


# ============================================================================
# Test: Edge cases with system type data
# ============================================================================

class TestSystemTypeEdgeCases(unittest.TestCase):
    """Edge cases for system type attribute handling."""

    def setUp(self):
        self.mock_client = MockPlatformClient()
        self.supero = SuperoTestClient(self.mock_client)

    def test_null_system_type_fields(self):
        """System type fields can be null (not yet filled)."""
        endpoint = "/api/v1/crud/test-domain/vehicle/v1"
        self.mock_client.set_response(endpoint, {
            "vehicle": {
                "uuid": "v1",
                "make": "Toyota",
                "weekly_rate": None,
                "vehicle_photos": None,
                "registration_doc": None,
                "current_location": None,
            }
        })

        result = self.supero.get("vehicle", "v1")
        vehicle = result["vehicle"]

        self.assertIsNone(vehicle["weekly_rate"])
        self.assertIsNone(vehicle["vehicle_photos"])
        self.assertIsNone(vehicle["registration_doc"])
        self.assertIsNone(vehicle["current_location"])

    def test_empty_image_list(self):
        """Image list field can be empty array."""
        endpoint = "/api/v1/crud/test-domain/vehicle/v1"
        self.mock_client.set_response(endpoint, {
            "vehicle": {
                "uuid": "v1",
                "vehicle_photos": [],
            }
        })

        result = self.supero.get("vehicle", "v1")
        self.assertEqual(result["vehicle"]["vehicle_photos"], [])

    def test_currency_zero_amount(self):
        """Currency field with zero amount is valid (e.g., waived fee)."""
        endpoint = "/api/v1/crud/test-domain/payment"
        self.mock_client.set_response(endpoint, {
            "payment": {"uuid": "p1", "amount": {"amount": 0.00, "currency_code": "USD"}}
        })

        result = self.supero.create("payment", {
            "amount": {"amount": 0.00, "currency_code": "USD"},
            "status": "waived",
        })

        call = self.mock_client.last_call()
        payload = call["json"]["payment"]
        self.assertEqual(payload["amount"]["amount"], 0.00)

    def test_currency_different_codes(self):
        """Currency fields in different currencies within same entity."""
        endpoint = "/api/v1/crud/test-domain/rental"
        self.mock_client.set_response(endpoint, {
            "rental": {"uuid": "r1"}
        })

        result = self.supero.create("rental", {
            "weekly_rate": {"amount": 350.00, "currency_code": "USD"},
            "deposit_amount": {"amount": 25000.00, "currency_code": "INR"},
        })

        call = self.mock_client.last_call()
        payload = call["json"]["rental"]
        self.assertEqual(payload["weekly_rate"]["currency_code"], "USD")
        self.assertEqual(payload["deposit_amount"]["currency_code"], "INR")

    def test_address_minimal_fields(self):
        """Address with only mandatory fields (line1, city, country)."""
        endpoint = "/api/v1/crud/test-domain/customer"
        minimal_address = {"line1": "123 Main St", "city": "Mumbai", "country": "IN"}
        self.mock_client.set_response(endpoint, {
            "customer": {"uuid": "c1", "home_address": minimal_address}
        })

        result = self.supero.create("customer", {
            "full_name": "Test User",
            "home_address": minimal_address,
        })

        call = self.mock_client.last_call()
        payload = call["json"]["customer"]
        self.assertEqual(payload["home_address"]["city"], "Mumbai")
        self.assertEqual(payload["home_address"]["country"], "IN")
        self.assertNotIn("lat", payload["home_address"])

    def test_signature_without_optional_fields(self):
        """Signature with only mandatory fields (image_data, signed_at)."""
        endpoint = "/api/v1/crud/test-domain/rental"
        minimal_sig = {
            "image_data": "data:image/png;base64,abc123",
            "signed_at": "2026-01-15T10:00:00Z",
        }
        self.mock_client.set_response(endpoint, {
            "rental": {"uuid": "r1", "customer_signature": minimal_sig}
        })

        result = self.supero.create("rental", {
            "customer_signature": minimal_sig,
        })

        call = self.mock_client.last_call()
        payload = call["json"]["rental"]
        self.assertIn("image_data", payload["customer_signature"])
        self.assertNotIn("signed_by", payload["customer_signature"])
        self.assertNotIn("ip_address", payload["customer_signature"])

    def test_geolocation_boundary_values(self):
        """GeoLocation with extreme but valid coordinates."""
        endpoint = "/api/v1/crud/test-domain/vehicle"
        self.mock_client.set_response(endpoint, {
            "vehicle": {"uuid": "v1"}
        })

        # North Pole
        result = self.supero.create("vehicle", {
            "current_location": {"lat": 90.0, "lng": 0.0},
        })
        payload = self.mock_client.last_call()["json"]["vehicle"]
        self.assertEqual(payload["current_location"]["lat"], 90.0)

        self.mock_client.clear_calls()

        # International Date Line
        result = self.supero.create("vehicle", {
            "current_location": {"lat": 0.0, "lng": -180.0},
        })
        payload = self.mock_client.last_call()["json"]["vehicle"]
        self.assertEqual(payload["current_location"]["lng"], -180.0)

    def test_date_range_open_ended(self):
        """DateRange with null end_date (open-ended rental)."""
        endpoint = "/api/v1/crud/test-domain/rental"
        open_range = {
            "start_date": "2026-01-15T00:00:00Z",
            "end_date": None,
            "timezone": "UTC",
        }
        self.mock_client.set_response(endpoint, {
            "rental": {"uuid": "r1", "rental_period": open_range}
        })

        result = self.supero.create("rental", {
            "rental_period": open_range,
        })

        call = self.mock_client.last_call()
        payload = call["json"]["rental"]
        self.assertIsNone(payload["rental_period"]["end_date"])
        self.assertEqual(payload["rental_period"]["start_date"], "2026-01-15T00:00:00Z")


if __name__ == '__main__':
    unittest.main(verbosity=2)
