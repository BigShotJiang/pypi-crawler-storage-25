"""
Unit Tests for Platform Operations - Module-level Functions

Tests critical platform operations including:
- register_domain() - Tenant/organization creation
- register_user() - User registration with multi-tenant hierarchy
- login() - Authentication with project/tenant context (v3.0)
- signup() - Self-service user registration

v3.0 Multi-Tenant Hierarchy:
- domain → project → tenant → user
- login() supports project and tenant parameters
- register_user() supports project_uuid and tenant_uuid
- Context extraction and attachment to Supero instances

These are the main entry points for the Supero SDK and require thorough testing.
"""

import unittest
from unittest.mock import Mock, MagicMock, patch, call
import sys
import os

# Add src to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '../src'))

from supero.platform_operations import (
    register_domain,
    register_user,
    login,
    signup
)

from supero.platform_client import (
    AuthenticationError,
    AuthorizationError,
    RateLimitError
)


# ============================================================================
# Mock Helpers
# ============================================================================

def create_mock_jwt(domain_name="test-domain", domain_uuid="uuid-123", 
                   project_uuid="proj-456", tenant_uuid="tenant-789",
                   user_uuid="user-abc", email="test@example.com"):
    """Create a mock JWT token (just a string for testing)"""
    import jwt
    
    payload = {
        "domain_name": domain_name,
        "domain_uuid": domain_uuid,
        "project_uuid": project_uuid,
        "tenant_uuid": tenant_uuid,
        "user_uuid": user_uuid,
        "email": email,
        "exp": 9999999999  # Far future
    }
    
    return jwt.encode(payload, "secret", algorithm="HS256")


def create_mock_platform_client():
    """Create a mock PlatformClient"""
    mock_client = Mock()
    mock_client.post = Mock()
    mock_client.get = Mock()
    return mock_client


def create_mock_supero_instance():
    """Create a mock Supero instance"""
    mock_supero = Mock()
    mock_supero._attach_login_context = Mock()
    return mock_supero


# ============================================================================
# register_domain() Tests
# ============================================================================

class TestRegisterTenant(unittest.TestCase):
    """Test register_domain() function"""
    
    @patch('supero.platform_operations.PlatformClient')
    @patch('supero.platform_operations.Supero')
    def test_register_domain_self_registration(self, mock_supero_class, mock_client_class):
        """Test self-registration flow (user creating their own tenant)"""
        # Setup mocks
        mock_client = create_mock_platform_client()
        mock_client_class.return_value = mock_client
        
        mock_supero = create_mock_supero_instance()
        mock_supero_class.quickstart.return_value = mock_supero
        
        # Mock API response for self-registration
        jwt_token = create_mock_jwt(domain_name="my-company")
        mock_client.post.return_value = {
            'session_updated': True,
            'tokens': {
                'access_token': jwt_token,
                'refresh_token': 'refresh-token-123'
            },
            'domain': {
                'domain_uuid': 'domain-new-123',
                'domain_name': 'my-company'
            }
        }
        
        # Call function
        result = register_domain(
            domain_name='my-company',
            admin_email='me@my-company.com',
            admin_password='SecurePass123!',
            domain_display_name='My Company',
            self_registration=True,
            platform_core_host='localhost',
            platform_core_port=8083
        )
        
        # Verify PlatformClient created with correct params
        mock_client_class.assert_called_once_with(
            base_url='http://localhost:8083/api/v1'
        )
        
        # Verify API called correctly
        mock_client.post.assert_called_once_with(
            '/domains/register',
            json={
                'domain_name': 'my-company',
                'domain_display_name': 'My Company',
                'admin_email': 'me@my-company.com',
                'admin_password': 'SecurePass123!',
                'description': 'Tenant for my-company'
            }
        )
        
        # Verify Supero.quickstart called with JWT
        mock_supero_class.quickstart.assert_called_once_with(
            name='my-company',
            jwt_token=jwt_token,
            platform_core_host='localhost',
            platform_core_port=8083
        )
        
        # Verify result is Supero instance
        self.assertEqual(result, mock_supero)
    
    @patch('supero.platform_operations.PlatformClient')
    @patch("supero.platform_operations.login")
    def test_register_domain_admin_registration(self, mock_login, mock_client_class):
        """Test admin registration flow (admin creating tenant for someone else)"""
        # Setup mocks
        mock_client = create_mock_platform_client()
        mock_client_class.return_value = mock_client
        
        mock_supero = create_mock_supero_instance()
        mock_login.return_value = mock_supero
        
        # Mock API response for admin registration (no session update)
        mock_client.post.return_value = {
            'session_updated': False,
            'domain': {
                'domain_uuid': 'domain-new-456',
                'domain_name': 'acme-corp'
            }
        }
        
        # Call function
        result = register_domain(
            domain_name='acme-corp',
            admin_email='admin@acme.com',
            admin_password='AdminPass123!',
            self_registration=False,
            platform_core_host='api.example.com',
            platform_core_port=443
        )
        
        # Verify registration API called
        mock_client.post.assert_called_once()
        
        # Verify login called with correct params
        mock_login.assert_called_once_with(
            domain_name='acme-corp',
            email='admin@acme.com',
            password='AdminPass123!',
            platform_core_host='api.example.com',
            platform_core_port=443
        )
        
        # Verify result is from login
        self.assertEqual(result, mock_supero)
    
    @patch('supero.platform_operations.PlatformClient')
    @patch('supero.platform_operations.Supero')
    def test_register_domain_with_metadata(self, mock_supero_class, mock_client_class):
        """Test register_domain with additional metadata"""
        mock_client = create_mock_platform_client()
        mock_client_class.return_value = mock_client
        
        # Setup Supero mock
        mock_supero = create_mock_supero_instance()
        mock_supero_class.quickstart.return_value = mock_supero
        
        jwt_token = create_mock_jwt()
        mock_client.post.return_value = {
            'session_updated': True,
            'tokens': {'access_token': jwt_token}
        }
        
        register_domain(
            domain_name='test-domain',
            admin_email='admin@test.com',
            admin_password='password',
            description='Custom description',
            industry='Technology',
            size='50-100'
        )
        
        # Verify payload includes domain info
        call_args = mock_client.post.call_args
        payload = call_args[1]['json']
        
        self.assertEqual(payload['domain_name'], 'test-domain')
        self.assertEqual(payload['description'], 'Custom description')
    
    @patch('supero.platform_operations.PlatformClient')
    def test_register_domain_connection_error(self, mock_client_class):
        """Test register_domain handles connection errors"""
        mock_client = create_mock_platform_client()
        mock_client_class.return_value = mock_client
        
        # Mock connection error
        mock_client.post.side_effect = ConnectionError("Connection refused")
        
        # Should raise ConnectionError with helpful message
        with self.assertRaises(ConnectionError) as ctx:
            register_domain(
                domain_name='test-domain',
                admin_email='admin@test.com',
                admin_password='password',
                platform_core_host='unreachable.example.com',
                platform_core_port=9999
            )
        
        self.assertIn("Could not connect to Platform Core", str(ctx.exception))
        self.assertIn("unreachable.example.com:9999", str(ctx.exception))
    
    @patch('supero.platform_operations.PlatformClient')
    def test_register_domain_authentication_error(self, mock_client_class):
        """Test register_domain handles authentication errors"""
        mock_client = create_mock_platform_client()
        mock_client_class.return_value = mock_client
        
        # Mock authentication error
        mock_client.post.side_effect = AuthenticationError("Invalid credentials")
        
        with self.assertRaises(AuthenticationError) as ctx:
            register_domain(
                domain_name='test-domain',
                admin_email='admin@test.com',
                admin_password='wrong-password'
            )
        
        self.assertIn("Tenant registration failed", str(ctx.exception))
    
    @patch('supero.platform_operations.PlatformClient')
    @patch('supero.platform_operations.Supero')
    def test_register_domain_missing_jwt_in_response(self, mock_supero_class, mock_client_class):
        """Test register_domain handles missing JWT in self-registration response"""
        mock_client = create_mock_platform_client()
        mock_client_class.return_value = mock_client
        
        # Mock response without JWT token
        mock_client.post.return_value = {
            'session_updated': True,
            'tokens': {}  # No access_token!
        }
        
        with self.assertRaises(AuthenticationError) as ctx:
            register_domain(
                domain_name='test-domain',
                admin_email='admin@test.com',
                admin_password='password',
                self_registration=True
            )
        
        self.assertIn("no JWT token returned", str(ctx.exception))
    
    @patch('supero.platform_operations.PlatformClient')
    @patch('supero.platform_operations.Supero')  # ✅
    def test_register_domain_login_fails_after_admin_registration(self, mock_supero_class, mock_client_class):
        """Test register_domain handles login failure in admin registration"""
        mock_client = create_mock_platform_client()
        mock_client_class.return_value = mock_client
        
        mock_client.post.return_value = {
            'session_updated': False,
            'domain': {'domain_uuid': 'uuid-123'}
        }
        
        # Login fails
        mock_supero_class.quickstart.side_effect = AuthenticationError("Login failed")
        
        with self.assertRaises(AuthenticationError) as ctx:
            register_domain(
                domain_name='test-domain',
                admin_email='admin@test.com',
                admin_password='password',
                self_registration=False
            )
        
        self.assertIn("Tenant registered successfully but login failed", str(ctx.exception))
    
    @patch('supero.platform_operations.PlatformClient')
    @patch('supero.platform_operations.Supero')
    def test_register_domain_uses_default_host(self, mock_supero_class, mock_client_class):
        """Test register_domain uses default host when not specified"""
        mock_client = create_mock_platform_client()
        mock_client_class.return_value = mock_client
        
        jwt_token = create_mock_jwt()
        mock_client.post.return_value = {
            'session_updated': True,
            'tokens': {'access_token': jwt_token}
        }
        
        mock_supero_class.quickstart.return_value = Mock()
        
        register_domain(
            domain_name='test-domain',
            admin_email='admin@test.com',
            admin_password='password'
            # No platform_core_host specified
        )
        
        # Verify default host used (from environment or 'localhost')
        # The function should use default_platform_core_host
        mock_client_class.assert_called_once()


# ============================================================================
# register_user() Tests - v3.0 with Multi-Tenant Hierarchy
# ============================================================================

class TestRegisterUser(unittest.TestCase):
    """Test register_user() function with v3.0 multi-tenant hierarchy"""
    
    @patch('supero.platform_operations.PlatformClient')
    def test_register_user_with_project_tenant(self, mock_client_class):
        """Test register_user with specific project and tenant (v3.0)"""
        mock_client = create_mock_platform_client()
        mock_client_class.return_value = mock_client
        
        mock_client.post.return_value = {
            'user_uuid': 'user-new-123',
            'email': 'developer@acme.com',
            'role': 'developer'
        }
        
        result = register_user(
            domain_uuid='domain-123',
            project_uuid='project-456',  # ✅ v3.0 feature
            tenant_uuid='tenant-789',    # ✅ v3.0 feature
            email='developer@acme.com',
            password='DevPass123!',
            first_name='John',
            last_name='Developer',
            role='developer',
            permissions=['project:read', 'project:write'],
            admin_token='admin-token-xyz',
            platform_core_host='localhost',
            platform_core_port=8083
        )
        
        # Verify PlatformClient created with admin token
        mock_client_class.assert_called_once_with(
            base_url='http://localhost:8083/api/v1',
            jwt_token='admin-token-xyz'
        )
        
        # Verify API called with project/tenant context
        mock_client.post.assert_called_once_with(
            '/users/register',
            json={
                'domain_uuid': 'domain-123',
                'project_uuid': 'project-456',  # ✅ Included
                'tenant_uuid': 'tenant-789',    # ✅ Included
                'email': 'developer@acme.com',
                'password': 'DevPass123!',
                'first_name': 'John',
                'last_name': 'Developer',
                'role': 'developer',
                'permissions': ['project:read', 'project:write']
            }
        )
        
        self.assertEqual(result['user_uuid'], 'user-new-123')
    
    @patch('supero.platform_operations.PlatformClient')
    def test_register_user_default_context(self, mock_client_class):
        """Test register_user uses defaults when project/tenant not specified"""
        mock_client = create_mock_platform_client()
        mock_client_class.return_value = mock_client
        
        mock_client.post.return_value = {'user_uuid': 'user-456'}
        
        register_user(
            domain_uuid='domain-123',
            email='viewer@acme.com',
            password='ViewPass123!',
            admin_token='admin-token-xyz'
            # No project_uuid or tenant_uuid
        )
        
        # Verify payload does NOT include project/tenant
        call_args = mock_client.post.call_args
        payload = call_args[1]['json']
        
        self.assertNotIn('project_uuid', payload)
        self.assertNotIn('tenant_uuid', payload)
        # Server will use defaults (default-project/default-tenant)
    
    @patch('supero.platform_operations.PlatformClient')
    def test_register_user_project_only(self, mock_client_class):
        """Test register_user with project but no tenant"""
        mock_client = create_mock_platform_client()
        mock_client_class.return_value = mock_client
        
        mock_client.post.return_value = {'user_uuid': 'user-789'}
        
        register_user(
            domain_uuid='domain-123',
            project_uuid='project-456',
            email='user@acme.com',
            password='Pass123!',
            admin_token='admin-token-xyz'
            # No tenant_uuid - will use project's default tenant
        )
        
        call_args = mock_client.post.call_args
        payload = call_args[1]['json']
        
        self.assertIn('project_uuid', payload)
        self.assertNotIn('tenant_uuid', payload)
    
    def test_register_user_requires_admin_token(self):
        """Test register_user raises error without admin_token"""
        with self.assertRaises(ValueError) as ctx:
            register_user(
                domain_uuid='domain-123',
                email='user@acme.com',
                password='password'
                # No admin_token!
            )
        
        self.assertIn("admin_token is required", str(ctx.exception))
    
    def test_register_user_requires_domain_uuid(self):
        """Test register_user raises error without domain_uuid"""
        with self.assertRaises(ValueError) as ctx:
            register_user(
                domain_uuid=None,
                email='user@acme.com',
                password='password',
                admin_token='token'
            )
        
        self.assertIn("domain_uuid is required", str(ctx.exception))
    
    @patch('supero.platform_operations.PlatformClient')
    def test_register_user_connection_error(self, mock_client_class):
        """Test register_user handles connection errors"""
        mock_client = create_mock_platform_client()
        mock_client_class.return_value = mock_client
        
        mock_client.post.side_effect = ConnectionError("Connection refused")
        
        with self.assertRaises(ConnectionError) as ctx:
            register_user(
                domain_uuid='domain-123',
                email='user@acme.com',
                password='password',
                admin_token='token',
                platform_core_host='unreachable.com',
                platform_core_port=9999
            )
        
        self.assertIn("Could not connect to Platform Core", str(ctx.exception))
        self.assertIn("unreachable.com:9999", str(ctx.exception))
    
    @patch('supero.platform_operations.PlatformClient')
    def test_register_user_authentication_error(self, mock_client_class):
        """Test register_user handles authentication errors"""
        mock_client = create_mock_platform_client()
        mock_client_class.return_value = mock_client
        
        mock_client.post.side_effect = AuthenticationError("Invalid token")
        
        with self.assertRaises(AuthenticationError) as ctx:
            register_user(
                domain_uuid='domain-123',
                email='user@acme.com',
                password='password',
                admin_token='invalid-token'
            )
        
        self.assertIn("authentication error", str(ctx.exception))
        self.assertIn("Check admin_token", str(ctx.exception))
    
    @patch('supero.platform_operations.PlatformClient')
    def test_register_user_authorization_error(self, mock_client_class):
        """Test register_user handles authorization errors"""
        mock_client = create_mock_platform_client()
        mock_client_class.return_value = mock_client
        
        mock_client.post.side_effect = AuthorizationError("Permission denied")
        
        with self.assertRaises(AuthorizationError) as ctx:
            register_user(
                domain_uuid='domain-123',
                email='user@acme.com',
                password='password',
                admin_token='viewer-token'
            )
        
        self.assertIn("permission denied", str(ctx.exception))
        self.assertIn("user:create permission", str(ctx.exception))
    
    @patch('supero.platform_operations.PlatformClient')
    def test_register_user_with_full_details(self, mock_client_class):
        """Test register_user with all parameters"""
        mock_client = create_mock_platform_client()
        mock_client_class.return_value = mock_client
        
        mock_client.post.return_value = {'user_uuid': 'user-complete'}
        
        result = register_user(
            domain_uuid='domain-123',
            project_uuid='project-456',
            tenant_uuid='tenant-789',
            email='complete@acme.com',
            password='CompletePass123!',
            first_name='Complete',
            last_name='User',
            role='admin',
            permissions=['*:*'],
            admin_token='admin-token',
            platform_core_host='api.acme.com',
            platform_core_port=443
        )
        
        # Verify complete payload
        call_args = mock_client.post.call_args
        payload = call_args[1]['json']
        
        self.assertEqual(payload['domain_uuid'], 'domain-123')
        self.assertEqual(payload['project_uuid'], 'project-456')
        self.assertEqual(payload['tenant_uuid'], 'tenant-789')
        self.assertEqual(payload['email'], 'complete@acme.com')
        self.assertEqual(payload['first_name'], 'Complete')
        self.assertEqual(payload['last_name'], 'User')
        self.assertEqual(payload['role'], 'admin')
        self.assertEqual(payload['permissions'], ['*:*'])


# ============================================================================
# login() Tests - v3.0 with Multi-Tenant Hierarchy
# ============================================================================

class TestLogin(unittest.TestCase):
    """Test login() function with v3.0 multi-tenant hierarchy"""
    
    @patch('supero.platform_operations.PlatformClient')
    @patch('supero.platform_operations.Supero')
    def test_login_with_specific_tenant(self, mock_supero_class, mock_client_class):
        """Test login to specific project and tenant (v3.0)"""
        mock_client = create_mock_platform_client()
        mock_client_class.return_value = mock_client
        
        mock_supero = create_mock_supero_instance()
        mock_supero_class.quickstart.return_value = mock_supero
        
        jwt_token = create_mock_jwt(
            domain_name='acme-corp',
            project_uuid='proj-backend',
            tenant_uuid='tenant-prod'
        )
        
        # Mock login response with v3.0 structure
        mock_client.post.return_value = {
            'auth': {
                'access_token': jwt_token,
                'refresh_token': 'refresh-token-xyz'
            },
            'user': {
                'user_uuid': 'user-123',
                'email': 'developer@acme.com',
                'username': 'developer',
                'role': 'developer'
            },
            'context': {
                'domain_name': 'acme-corp',
                'domain_uuid': 'domain-123',
                'project_name': 'backend-project',
                'project_uuid': 'proj-backend',
                'tenant_name': 'production',
                'tenant_uuid': 'tenant-prod'
            }
        }
        
        result = login(
            domain_name='acme-corp',
            email='developer@acme.com',
            password='DevPass123!',
            project='backend-project',  # ✅ v3.0 feature
            tenant='production',        # ✅ v3.0 feature
            platform_core_host='localhost',
            platform_core_port=8083
        )
        
        # Verify PlatformClient created
        mock_client_class.assert_called_once_with(
            base_url='http://localhost:8083/api/v1'
        )
        
        # Verify login API called with project/tenant
        mock_client.post.assert_called_once_with(
            '/auth/login',
            json={
                'email': 'developer@acme.com',
                'password': 'DevPass123!',
                'domain': 'acme-corp',
                'project': 'backend-project',  # ✅ Included
                'tenant': 'production'         # ✅ Included
            }
        )
        
        # Verify Supero.quickstart called with JWT
        mock_supero_class.quickstart.assert_called_once_with(
            name='acme-corp',
            jwt_token=jwt_token,
            platform_core_host='localhost',
            platform_core_port=8083,
            login_context={'user_uuid': 'user-123', 'user_email': 'developer@acme.com', 'username': 'developer', 'role': 'developer', 'domain_name': 'acme-corp', 'domain_uuid': 'domain-123', 'project_name': 'backend-project', 'project_uuid': 'proj-backend', 'tenant_name': 'production', 'tenant_uuid': 'tenant-prod'}
        )
        
        # Verify context attached
        #mock_supero._attach_login_context.assert_called_once()
        #context = mock_supero._attach_login_context.call_args[0][0]
        
        #self.assertEqual(context['user_uuid'], 'user-123')
        #self.assertEqual(context['user_email'], 'developer@acme.com')
        #self.assertEqual(context['project_name'], 'backend-project')
        #self.assertEqual(context['tenant_name'], 'production')
        
        self.assertEqual(result, mock_supero)
    
    @patch('supero.platform_operations.PlatformClient')
    @patch('supero.platform_operations.Supero')
    def test_login_default_project_tenant(self, mock_supero_class, mock_client_class):
        """Test login uses default project and tenant"""
        mock_client = create_mock_platform_client()
        mock_client_class.return_value = mock_client
        
        mock_supero = create_mock_supero_instance()
        mock_supero_class.quickstart.return_value = mock_supero
        
        jwt_token = create_mock_jwt()
        
        mock_client.post.return_value = {
            'auth': {'access_token': jwt_token},
            'user': {'user_uuid': 'user-456', 'email': 'user@acme.com'},
            'context': {
                'domain_name': 'acme-corp',
                'project_name': 'default-project',
                'tenant_name': 'default-tenant'
            }
        }
        
        login(
            domain_name='acme-corp',
            email='user@acme.com',
            password='password'
            # No project or tenant specified
        )
        
        # Verify defaults used
        call_args = mock_client.post.call_args
        payload = call_args[1]['json']
        
        self.assertEqual(payload['project'], 'default-project')
        self.assertEqual(payload['tenant'], 'default-tenant')
    
    @patch('supero.platform_operations.PlatformClient')
    @patch('supero.platform_operations.Supero')
    def test_login_project_only(self, mock_supero_class, mock_client_class):
        """Test login with project but default tenant"""
        mock_client = create_mock_platform_client()
        mock_client_class.return_value = mock_client
        
        mock_supero = create_mock_supero_instance()
        mock_supero_class.quickstart.return_value = mock_supero
        
        jwt_token = create_mock_jwt()
        mock_client.post.return_value = {
            'auth': {'access_token': jwt_token},
            'user': {'user_uuid': 'user-789', 'email': 'user@acme.com'},
            'context': {}
        }
        
        login(
            domain_name='acme-corp',
            email='user@acme.com',
            password='password',
            project='my-project'
            # tenant defaults to 'default-tenant'
        )
        
        call_args = mock_client.post.call_args
        payload = call_args[1]['json']
        
        self.assertEqual(payload['project'], 'my-project')
        self.assertEqual(payload['tenant'], 'default-tenant')
    
    @patch('supero.platform_operations.PlatformClient')
    def test_login_connection_error(self, mock_client_class):
        """Test login handles connection errors"""
        mock_client = create_mock_platform_client()
        mock_client_class.return_value = mock_client
        
        mock_client.post.side_effect = ConnectionError("Connection refused")
        
        with self.assertRaises(ConnectionError) as ctx:
            login(
                domain_name='acme-corp',
                email='user@acme.com',
                password='password',
                platform_core_host='unreachable.com',
                platform_core_port=9999
            )
        
        self.assertIn("Could not connect to Platform Core", str(ctx.exception))
        self.assertIn("unreachable.com:9999", str(ctx.exception))
    
    @patch('supero.platform_operations.PlatformClient')
    def test_login_authentication_error(self, mock_client_class):
        """Test login handles authentication errors with context"""
        mock_client = create_mock_platform_client()
        mock_client_class.return_value = mock_client
        
        mock_client.post.side_effect = AuthenticationError("Invalid credentials")
        
        with self.assertRaises(AuthenticationError) as ctx:
            login(
                domain_name='acme-corp',
                email='wrong@acme.com',
                password='wrong-password',
                project='backend-project',
                tenant='production'
            )
        
        # Error message includes full context
        error_msg = str(ctx.exception)
        self.assertIn("wrong@acme.com@acme-corp", error_msg)
        self.assertIn("backend-project", error_msg)
        self.assertIn("production", error_msg)
    
    @patch('supero.platform_operations.PlatformClient')
    def test_login_authorization_error(self, mock_client_class):
        """Test login handles authorization errors"""
        mock_client = create_mock_platform_client()
        mock_client_class.return_value = mock_client
        
        mock_client.post.side_effect = AuthorizationError("User disabled")
        
        with self.assertRaises(AuthorizationError) as ctx:
            login(
                domain_name='acme-corp',
                email='disabled@acme.com',
                password='password'
            )
        
        self.assertIn("permission denied", str(ctx.exception))
        self.assertIn("disabled@acme.com@acme-corp", str(ctx.exception))
    
    @patch('supero.platform_operations.PlatformClient')
    @patch('supero.platform_operations.Supero')
    def test_login_missing_jwt_in_response(self, mock_supero_class, mock_client_class):
        """Test login handles missing JWT in response"""
        mock_client = create_mock_platform_client()
        mock_client_class.return_value = mock_client
        
        # Response without JWT
        mock_client.post.return_value = {
            'auth': {},  # No access_token!
            'user': {'user_uuid': 'user-123'}
        }
        
        with self.assertRaises(AuthenticationError) as ctx:
            login(
                domain_name='acme-corp',
                email='user@acme.com',
                password='password'
            )
        
        self.assertIn("no JWT token returned", str(ctx.exception))
    
    @patch('supero.platform_operations.PlatformClient')
    @patch('supero.platform_operations.Supero')
    def test_login_fallback_token_format(self, mock_supero_class, mock_client_class):
        """Test login handles old response format (fallback)"""
        mock_client = create_mock_platform_client()
        mock_client_class.return_value = mock_client
        
        mock_supero = create_mock_supero_instance()
        mock_supero_class.quickstart.return_value = mock_supero
        
        jwt_token = create_mock_jwt()
        
        # Old format (for backward compatibility)
        mock_client.post.return_value = {
            'token': jwt_token,  # Old field name
            'user': {'user_uuid': 'user-123', 'email': 'user@acme.com'}
        }
        
        result = login(
            domain_name='acme-corp',
            email='user@acme.com',
            password='password'
        )
        
        # Should still work
        mock_supero_class.quickstart.assert_called_once()
        self.assertEqual(result, mock_supero)
    
    @patch('supero.platform_operations.PlatformClient')
    @patch('supero.platform_operations.Supero')
    def test_login_context_attachment_optional(self, mock_supero_class, mock_client_class):
        """Test login works when Supero doesn't have _attach_login_context"""
        mock_client = create_mock_platform_client()
        mock_client_class.return_value = mock_client
        
        # Mock Supero without _attach_login_context method
        mock_supero = Mock(spec=[])  # No _attach_login_context
        mock_supero_class.quickstart.return_value = mock_supero
        
        jwt_token = create_mock_jwt()
        mock_client.post.return_value = {
            'auth': {'access_token': jwt_token},
            'user': {'user_uuid': 'user-123', 'email': 'user@acme.com'},
            'context': {'project_name': 'test-project'}
        }
        
        # Should not raise even without _attach_login_context
        result = login(
            domain_name='acme-corp',
            email='user@acme.com',
            password='password'
        )
        
        self.assertEqual(result, mock_supero)
    
    @patch('supero.platform_operations.PlatformClient')
    def test_login_unexpected_error(self, mock_client_class):
        """Test login handles unexpected errors"""
        mock_client = create_mock_platform_client()
        mock_client_class.return_value = mock_client
        
        mock_client.post.side_effect = ValueError("Unexpected error")
        
        with self.assertRaises(ValueError) as ctx:
            login(
                domain_name='acme-corp',
                email='user@acme.com',
                password='password'
            )
        
        self.assertIn("Unexpected error during login", str(ctx.exception))


# ============================================================================
# signup() Tests
# ============================================================================

class TestSignup(unittest.TestCase):
    """Test signup() function"""
    
    @patch('supero.platform_operations.PlatformClient')
    def test_signup_success(self, mock_client_class):
        """Test successful user signup"""
        mock_client = create_mock_platform_client()
        mock_client_class.return_value = mock_client
        
        mock_client.post.return_value = {
            'user_uuid': 'user-new-viewer',
            'email': 'newuser@example.com',
            'role': 'viewer',
            'domain': 'default-domain',
            'project': 'default-project',
            'tenant': 'default-tenant'
        }
        
        result = signup(
            email='newuser@example.com',
            password='NewUserPass123!',
            full_name='New User',
            platform_core_host='localhost',
            platform_core_port=8083
        )
        
        # Verify PlatformClient created
        mock_client_class.assert_called_once_with(
            base_url='http://localhost:8083/api/v1'
        )
        
        # Verify signup API called
        mock_client.post.assert_called_once_with(
            '/auth/register',
            json={
                'email': 'newuser@example.com',
                'password': 'NewUserPass123!',
                'full_name': 'New User'
            }
        )
        
        self.assertEqual(result['user_uuid'], 'user-new-viewer')
        self.assertEqual(result['role'], 'viewer')
    
    @patch('supero.platform_operations.PlatformClient')
    def test_signup_connection_error(self, mock_client_class):
        """Test signup handles connection errors"""
        mock_client = create_mock_platform_client()
        mock_client_class.return_value = mock_client
        
        mock_client.post.side_effect = ConnectionError("Connection refused")
        
        with self.assertRaises(ConnectionError) as ctx:
            signup(
                email='user@example.com',
                password='password',
                full_name='User',
                platform_core_host='unreachable.com',
                platform_core_port=9999
            )
        
        self.assertIn("Could not connect to Platform Core", str(ctx.exception))
        self.assertIn("unreachable.com:9999", str(ctx.exception))
    
    @patch('supero.platform_operations.PlatformClient')
    def test_signup_duplicate_email(self, mock_client_class):
        """Test signup handles duplicate email errors"""
        mock_client = create_mock_platform_client()
        mock_client_class.return_value = mock_client
        
        mock_client.post.side_effect = AuthenticationError("Email already registered")
        
        with self.assertRaises(AuthenticationError) as ctx:
            signup(
                email='existing@example.com',
                password='password',
                full_name='Duplicate User'
            )
        
        self.assertIn("Signup failed", str(ctx.exception))
        self.assertIn("existing@example.com", str(ctx.exception))
        self.assertIn("Email may already be registered", str(ctx.exception))
    
    @patch('supero.platform_operations.PlatformClient')
    def test_signup_uses_default_host(self, mock_client_class):
        """Test signup uses default host when not specified"""
        mock_client = create_mock_platform_client()
        mock_client_class.return_value = mock_client
        
        mock_client.post.return_value = {'user_uuid': 'user-123'}
        
        signup(
            email='user@example.com',
            password='password',
            full_name='User'
            # No platform_core_host specified
        )
        
        # Should use default_platform_core_host
        mock_client_class.assert_called_once()


# ============================================================================
# Integration/Workflow Tests
# ============================================================================

class TestPlatformOperationsWorkflows(unittest.TestCase):
    """Test common platform operation workflows"""
    
    @patch('supero.platform_operations.PlatformClient')
    @patch('supero.platform_operations.Supero')
    def test_complete_signup_and_tenant_creation_workflow(self, mock_supero_class, mock_client_class):
        """Test complete workflow: signup → login → create tenant"""
        mock_client = create_mock_platform_client()
        mock_client_class.return_value = mock_client
        
        mock_supero = create_mock_supero_instance()
        mock_supero_class.quickstart.return_value = mock_supero
        
        # Step 1: Signup
        mock_client.post.return_value = {
            'user_uuid': 'user-new',
            'email': 'newuser@example.com',
            'role': 'viewer'
        }
        
        user_info = signup(
            email='newuser@example.com',
            password='password',
            full_name='New User'
        )
        
        self.assertEqual(user_info['role'], 'viewer')
        
        # Step 2: User creates their own tenant (self-registration)
        jwt_token = create_mock_jwt(domain_name='my-company')
        mock_client.post.return_value = {
            'session_updated': True,
            'tokens': {'access_token': jwt_token},
            'domain': {'domain_uuid': 'domain-new'}
        }
        
        org = register_domain(
            domain_name='my-company',
            admin_email='newuser@example.com',
            admin_password='password',
            self_registration=True
        )
        
        # Verify Supero instance created with new JWT
        self.assertEqual(org, mock_supero)
    
    @patch('supero.platform_operations.PlatformClient')
    @patch('supero.platform_operations.Supero')  # ✅ Only patch Supero
    def test_admin_creates_tenant_and_users(self, mock_supero_class, mock_client_class):
        """Test admin workflow: create tenant → create users"""
        mock_client = create_mock_platform_client()
        mock_client_class.return_value = mock_client
        
        mock_supero = create_mock_supero_instance()
        mock_supero.platform_client = Mock()
        mock_supero.platform_client.domain_uuid = 'domain-123'
        mock_supero_class.quickstart.return_value = mock_supero
        
        # Step 1: Admin creates tenant
        mock_client.post.return_value = {
            'session_updated': False,
            'jwt_token': 'fake-jwt-for-workflow',
            'domain': {
                'domain_uuid': 'domain-123',
                'domain_name': 'new-company'
            }
        }
        
        jwt_token = create_mock_jwt()
        mock_supero_class.quickstart.return_value.platform_client.jwt_token = jwt_token
        
        org = register_domain(
            domain_name='new-company',
            admin_email='admin@new-company.com',
            admin_password='password',
            self_registration=False
        )
        
        # Step 2: Admin creates users in the tenant
        mock_client.post.return_value = {'user_uuid': 'user-dev-1'}
        
        user = register_user(
            domain_uuid='domain-123',
            project_uuid='project-main',
            tenant_uuid='tenant-prod',
            email='developer@new-company.com',
            password='password',
            role='developer',
            admin_token=jwt_token
        )
        
        self.assertEqual(user['user_uuid'], 'user-dev-1')


if __name__ == '__main__':
    unittest.main(verbosity=2)
