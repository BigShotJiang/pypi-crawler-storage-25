# test_app_setup.py (new file)
import os
import tempfile
import unittest
from unittest.mock import MagicMock


class TestPersistEnvVar(unittest.TestCase):
    """Tests for AppSetup._persist_env_var helper."""

    def setUp(self):
        self.tmpdir = tempfile.mkdtemp()
        self.old_cwd = os.getcwd()
        os.chdir(self.tmpdir)
        # Create a minimal .env
        with open(".env", "w") as f:
            f.write('SUPERO_DOMAIN="test"\n')
        # Create a minimal AppSetup instance
        from supero.app_setup import AppSetup
        self.setup = AppSetup.__new__(AppSetup)  # bypass __init__

    def tearDown(self):
        os.chdir(self.old_cwd)
        os.environ.pop("FOOBAR", None)

    def test_appends_new_key(self):
        self.setup._persist_env_var("FOOBAR", "hello")
        content = open(".env").read()
        self.assertIn('FOOBAR="hello"', content)
        self.assertEqual(os.environ["FOOBAR"], "hello")

    def test_idempotent_when_already_present(self):
        self.setup._persist_env_var("FOOBAR", "hello")
        self.setup._persist_env_var("FOOBAR", "hello")
        content = open(".env").read()
        self.assertEqual(content.count("FOOBAR="), 1)

    def test_updates_when_value_different(self):
        self.setup._persist_env_var("FOOBAR", "first")
        self.setup._persist_env_var("FOOBAR", "second")
        content = open(".env").read()
        self.assertIn('FOOBAR="second"', content)
        self.assertNotIn('"first"', content)

    def test_noop_on_missing_env_file(self):
        os.remove(".env")
        # Should not raise
        self.setup._persist_env_var("FOOBAR", "hello")

    def test_noop_on_empty_value(self):
        self.setup._persist_env_var("FOOBAR", "")
        content = open(".env").read()
        self.assertNotIn("FOOBAR", content)


if __name__ == "__main__":
    unittest.main()
