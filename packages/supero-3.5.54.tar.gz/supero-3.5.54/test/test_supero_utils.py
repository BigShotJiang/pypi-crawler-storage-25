"""
Comprehensive Tests for Supero Utils
Tests all utility functions with extensive coverage.
"""

import unittest
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '../src'))

from supero.utils import (
    singularize,
    snake_case,
    camel_case,
    extract_uuid,
    batch,
    deduplicate_by_uuid,
    merge_link_data
)


class TestStringUtilities(unittest.TestCase):
    """Test string manipulation utilities."""
    
    def test_singularize_regular(self):
        """Test singularize with regular nouns."""
        self.assertEqual(singularize('projects'), 'project')
        self.assertEqual(singularize('users'), 'user')
        self.assertEqual(singularize('tasks'), 'task')
        self.assertEqual(singularize('domains'), 'domain')
    
    def test_singularize_special_cases(self):
        """Test singularize with special cases."""
        self.assertEqual(singularize('companies'), 'company')
        self.assertEqual(singularize('categories'), 'category')
        self.assertEqual(singularize('businesses'), 'business')
        self.assertEqual(singularize('children'), 'child')
        self.assertEqual(singularize('people'), 'person')
    
    def test_singularize_already_singular(self):
        """Test singularize with already singular words."""
        result = singularize('project')
        self.assertIsInstance(result, str)
    
    def test_snake_case_from_camel(self):
        """Test snake_case conversion from CamelCase."""
        self.assertEqual(snake_case('ProjectName'), 'project_name')
        self.assertEqual(snake_case('UserAccount'), 'user_account')
        self.assertEqual(snake_case('APIKey'), 'api_key')
        self.assertEqual(snake_case('HTTPRequest'), 'http_request')
    
    def test_snake_case_from_spaces(self):
        """Test snake_case conversion from spaces."""
        # inflection.underscore is designed for CamelCase, not spaces
        # It may return the string as-is or lowercase it
        result = snake_case('Project Name')
        # Just verify it's a string
        self.assertIsInstance(result, str)
        # Should at least have 'project' in it (case-insensitive)
        self.assertIn('project', result.lower())
    
    def test_snake_case_already_snake(self):
        """Test snake_case with already snake_case."""
        self.assertEqual(snake_case('project_name'), 'project_name')
        self.assertEqual(snake_case('user_account'), 'user_account')
    
    def test_snake_case_single_word(self):
        """Test snake_case with single word."""
        self.assertEqual(snake_case('project'), 'project')
        self.assertEqual(snake_case('Project'), 'project')
    
    def test_camel_case_from_snake(self):
        """Test camel_case conversion from snake_case."""
        self.assertEqual(camel_case('project_name'), 'ProjectName')
        self.assertEqual(camel_case('user_account'), 'UserAccount')
        self.assertEqual(camel_case('api_key'), 'ApiKey')
    
    def test_camel_case_from_spaces(self):
        """Test camel_case conversion from spaces."""
        result = camel_case('project name')
        self.assertTrue(result[0].isupper())
    
    def test_camel_case_already_camel(self):
        """Test camel_case with already CamelCase."""
        self.assertEqual(camel_case('ProjectName'), 'ProjectName')
    
    def test_camel_case_single_word(self):
        """Test camel_case with single word."""
        self.assertEqual(camel_case('project'), 'Project')
    
    def test_camel_case_empty_string(self):
        """Test camel_case with empty string."""
        result = camel_case('')
        self.assertEqual(result, '')


class TestUUIDUtilities(unittest.TestCase):
    """Test UUID extraction utilities."""
    
    def test_extract_uuid_from_string(self):
        """Test extracting UUID from string."""
        uuid_str = 'abc-123-def-456'
        self.assertEqual(extract_uuid(uuid_str), uuid_str)
    
    def test_extract_uuid_from_object(self):
        """Test extracting UUID from object."""
        class MockObject:
            def __init__(self):
                self.uuid = 'obj-uuid-789'
        
        obj = MockObject()
        self.assertEqual(extract_uuid(obj), 'obj-uuid-789')
    
    def test_extract_uuid_from_object_no_uuid(self):
        """Test extracting UUID from object without uuid attribute."""
        class MockObject:
            pass
        
        obj = MockObject()
        self.assertIsNone(extract_uuid(obj))
    
    def test_extract_uuid_with_none(self):
        """Test extracting UUID with None."""
        # Should return None (no uuid attribute on None)
        result = extract_uuid(None)
        self.assertIsNone(result)


class TestBatchUtilities(unittest.TestCase):
    """Test batch processing utilities."""
    
    def test_batch_exact_size(self):
        """Test batching with exact batch size."""
        items = list(range(100))
        batches = batch(items, batch_size=10)
        
        self.assertEqual(len(batches), 10)
        for b in batches:
            self.assertEqual(len(b), 10)
    
    def test_batch_with_remainder(self):
        """Test batching with remainder."""
        items = list(range(105))
        batches = batch(items, batch_size=10)
        
        self.assertEqual(len(batches), 11)
        # First 10 batches should have 10 items
        for i in range(10):
            self.assertEqual(len(batches[i]), 10)
        # Last batch should have 5 items
        self.assertEqual(len(batches[10]), 5)
    
    def test_batch_smaller_than_size(self):
        """Test batching with items less than batch size."""
        items = list(range(5))
        batches = batch(items, batch_size=10)
        
        self.assertEqual(len(batches), 1)
        self.assertEqual(len(batches[0]), 5)
    
    def test_batch_empty_list(self):
        """Test batching empty list."""
        items = []
        batches = batch(items, batch_size=10)
        
        self.assertEqual(len(batches), 0)
    
    def test_batch_single_item(self):
        """Test batching single item."""
        items = [1]
        batches = batch(items, batch_size=10)
        
        self.assertEqual(len(batches), 1)
        self.assertEqual(batches[0], [1])
    
    def test_batch_size_one(self):
        """Test batching with size of 1."""
        items = list(range(5))
        batches = batch(items, batch_size=1)
        
        self.assertEqual(len(batches), 5)
        for b in batches:
            self.assertEqual(len(b), 1)
    
    def test_batch_large_dataset(self):
        """Test batching large dataset."""
        items = list(range(1000))
        batches = batch(items, batch_size=100)
        
        self.assertEqual(len(batches), 10)
        total_items = sum(len(b) for b in batches)
        self.assertEqual(total_items, 1000)
    
    def test_batch_preserves_order(self):
        """Test that batching preserves item order."""
        items = list(range(25))
        batches = batch(items, batch_size=10)
        
        # Reconstruct and verify order
        reconstructed = []
        for b in batches:
            reconstructed.extend(b)
        
        self.assertEqual(reconstructed, items)


class TestDeduplicationUtilities(unittest.TestCase):
    """Test deduplication utilities."""
    
    def test_deduplicate_by_uuid_basic(self):
        """Test basic UUID deduplication."""
        class MockObject:
            def __init__(self, uuid):
                self.uuid = uuid
        
        obj1 = MockObject('uuid-1')
        obj2 = MockObject('uuid-2')
        obj3 = MockObject('uuid-1')  # Duplicate
        
        objects = [obj1, obj2, obj3]
        unique = deduplicate_by_uuid(objects)
        
        self.assertEqual(len(unique), 2)
        self.assertEqual(unique[0].uuid, 'uuid-1')
        self.assertEqual(unique[1].uuid, 'uuid-2')
    
    def test_deduplicate_preserves_first_occurrence(self):
        """Test that deduplication preserves first occurrence."""
        class MockObject:
            def __init__(self, uuid, name):
                self.uuid = uuid
                self.name = name
        
        obj1 = MockObject('uuid-1', 'First')
        obj2 = MockObject('uuid-1', 'Second')  # Duplicate
        
        objects = [obj1, obj2]
        unique = deduplicate_by_uuid(objects)
        
        self.assertEqual(len(unique), 1)
        self.assertEqual(unique[0].name, 'First')
    
    def test_deduplicate_no_duplicates(self):
        """Test deduplication with no duplicates."""
        class MockObject:
            def __init__(self, uuid):
                self.uuid = uuid
        
        objects = [MockObject(f'uuid-{i}') for i in range(5)]
        unique = deduplicate_by_uuid(objects)
        
        self.assertEqual(len(unique), 5)
    
    def test_deduplicate_all_duplicates(self):
        """Test deduplication with all duplicates."""
        class MockObject:
            def __init__(self, uuid):
                self.uuid = uuid
        
        objects = [MockObject('uuid-1') for _ in range(10)]
        unique = deduplicate_by_uuid(objects)
        
        self.assertEqual(len(unique), 1)
    
    def test_deduplicate_empty_list(self):
        """Test deduplication with empty list."""
        unique = deduplicate_by_uuid([])
        self.assertEqual(len(unique), 0)
    
    def test_deduplicate_no_uuid_attribute(self):
        """Test deduplication with objects without uuid."""
        class MockObject:
            def __init__(self, name):
                self.name = name
        
        objects = [MockObject(f'name-{i}') for i in range(5)]
        unique = deduplicate_by_uuid(objects)
        
        # Should keep all objects since they have no UUID
        self.assertEqual(len(unique), 5)
    
    def test_deduplicate_mixed_uuid_and_no_uuid(self):
        """Test deduplication with mixed objects."""
        class MockObjectWithUUID:
            def __init__(self, uuid):
                self.uuid = uuid
        
        class MockObjectNoUUID:
            def __init__(self, name):
                self.name = name
        
        objects = [
            MockObjectWithUUID('uuid-1'),
            MockObjectNoUUID('no-uuid-1'),
            MockObjectWithUUID('uuid-1'),  # Duplicate
            MockObjectNoUUID('no-uuid-2'),
        ]
        
        unique = deduplicate_by_uuid(objects)
        
        # Should have: 1 uuid-1, 2 no-uuid objects
        self.assertEqual(len(unique), 3)


class TestLinkDataUtilities(unittest.TestCase):
    """Test link data manipulation utilities."""
    
    def test_merge_link_data_basic(self):
        """Test basic link data merge."""
        existing = {'role': 'member', 'allocation': 0.5}
        updates = {'role': 'lead'}
        
        merged = merge_link_data(existing, updates)
        
        self.assertEqual(merged['role'], 'lead')
        self.assertEqual(merged['allocation'], 0.5)
    
    def test_merge_link_data_add_new_fields(self):
        """Test merging with new fields."""
        existing = {'role': 'member'}
        updates = {'allocation': 1.0, 'status': 'active'}
        
        merged = merge_link_data(existing, updates)
        
        self.assertEqual(merged['role'], 'member')
        self.assertEqual(merged['allocation'], 1.0)
        self.assertEqual(merged['status'], 'active')
    
    def test_merge_link_data_empty_updates(self):
        """Test merging with empty updates."""
        existing = {'role': 'member', 'allocation': 0.5}
        updates = {}
        
        merged = merge_link_data(existing, updates)
        
        self.assertEqual(merged, existing)
    
    def test_merge_link_data_empty_existing(self):
        """Test merging with empty existing."""
        existing = {}
        updates = {'role': 'lead', 'allocation': 1.0}
        
        merged = merge_link_data(existing, updates)
        
        self.assertEqual(merged, updates)
    
    def test_merge_link_data_does_not_mutate_original(self):
        """Test that merge doesn't mutate original."""
        existing = {'role': 'member', 'allocation': 0.5}
        updates = {'role': 'lead'}
        
        merged = merge_link_data(existing, updates)
        
        # Original should be unchanged
        self.assertEqual(existing['role'], 'member')
        self.assertEqual(merged['role'], 'lead')
    
    def test_merge_link_data_with_none_values(self):
        """Test merging with None values."""
        existing = {'role': 'member', 'allocation': 0.5}
        updates = {'role': None}
        
        merged = merge_link_data(existing, updates)
        
        self.assertIsNone(merged['role'])
        self.assertEqual(merged['allocation'], 0.5)
    
    def test_merge_link_data_complex_values(self):
        """Test merging with complex values."""
        existing = {
            'role': 'member',
            'metadata': {'level': 1}
        }
        updates = {
            'metadata': {'level': 2, 'status': 'active'}
        }
        
        merged = merge_link_data(existing, updates)
        
        # Should replace entire metadata dict
        self.assertEqual(merged['metadata']['level'], 2)
        self.assertEqual(merged['metadata']['status'], 'active')


class TestUtilsEdgeCases(unittest.TestCase):
    """Test edge cases for utilities."""
    
    def test_batch_with_custom_objects(self):
        """Test batching with custom objects."""
        class CustomObject:
            def __init__(self, value):
                self.value = value
        
        items = [CustomObject(i) for i in range(25)]
        batches = batch(items, batch_size=10)
        
        self.assertEqual(len(batches), 3)
        self.assertEqual(batches[0][0].value, 0)
        self.assertEqual(batches[2][4].value, 24)
    
    def test_extract_uuid_with_numeric_uuid(self):
        """Test extracting numeric UUID."""
        class MockObject:
            def __init__(self):
                self.uuid = 123456
        
        obj = MockObject()
        self.assertEqual(extract_uuid(obj), 123456)
    
    def test_singularize_empty_string(self):
        """Test singularize with empty string."""
        result = singularize('')
        self.assertIsInstance(result, str)
    
    def test_snake_case_with_numbers(self):
        """Test snake_case with numbers."""
        result = snake_case('Project2024Name')
        self.assertIsInstance(result, str)
        self.assertIn('2024', result.lower())
    
    def test_camel_case_with_numbers(self):
        """Test camel_case with numbers."""
        result = camel_case('project_2024_name')
        self.assertIsInstance(result, str)
        self.assertTrue(result[0].isupper())


if __name__ == '__main__':
    unittest.main(verbosity=2)
