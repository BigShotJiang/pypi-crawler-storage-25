"""
Comprehensive Tests for Supero Reference
Tests all Reference class functionality - FIXED VERSION
Only tests methods that actually exist in the implementation.
"""

import unittest
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '../src'))

from supero.reference import Reference, create_ref


class MockTarget:
    """Mock object to use as reference target."""
    def __init__(self, uuid, name, obj_type='user'):
        self.uuid = uuid
        self.name = name
        self.obj_type = obj_type


class TestReferenceCreation(unittest.TestCase):
    """Test Reference creation and initialization."""
    
    def test_create_basic_reference(self):
        """Test creating basic reference."""
        target = MockTarget('user-123', 'Alice')
        ref = Reference(target)
        
        self.assertEqual(ref._target, target)
        self.assertEqual(ref._link_data, {})
        self.assertFalse(ref._modified)
    
    def test_create_reference_with_link_data(self):
        """Test creating reference with link data."""
        target = MockTarget('user-123', 'Alice')
        ref = Reference(target, role='lead', allocation=1.0)
        
        self.assertEqual(ref._target, target)
        self.assertEqual(ref._link_data, {'role': 'lead', 'allocation': 1.0})
        self.assertFalse(ref._modified)  # Not modified on creation
    
    def test_create_reference_with_complex_link_data(self):
        """Test creating reference with complex link data."""
        target = MockTarget('user-123', 'Alice')
        ref = Reference(
            target,
            role='lead',
            allocation=1.0,
            permissions=['read', 'write', 'admin'],
            metadata={'level': 5, 'certified': True}
        )
        
        self.assertEqual(ref.role, 'lead')
        self.assertEqual(ref.allocation, 1.0)
        self.assertEqual(ref.permissions, ['read', 'write', 'admin'])
        self.assertEqual(ref.metadata, {'level': 5, 'certified': True})
    
    def test_create_ref_convenience_function(self):
        """Test create_ref convenience function."""
        target = MockTarget('user-123', 'Alice')
        ref = create_ref(target, role='member', allocation=0.5)
        
        self.assertIsInstance(ref, Reference)
        self.assertEqual(ref.role, 'member')
        self.assertEqual(ref.allocation, 0.5)


class TestReferenceAttributes(unittest.TestCase):
    """Test Reference attribute access."""
    
    def test_get_link_data_attribute(self):
        """Test getting link data as attribute."""
        target = MockTarget('user-123', 'Alice')
        ref = Reference(target, role='lead', allocation=1.0)
        
        self.assertEqual(ref.role, 'lead')
        self.assertEqual(ref.allocation, 1.0)
    
    def test_set_link_data_attribute(self):
        """Test setting link data as attribute."""
        target = MockTarget('user-123', 'Alice')
        ref = Reference(target, role='member')
        
        ref.role = 'lead'
        ref.allocation = 1.0
        
        self.assertEqual(ref.role, 'lead')
        self.assertEqual(ref.allocation, 1.0)
        self.assertTrue(ref.is_modified())
    
    def test_get_nonexistent_attribute(self):
        """Test getting non-existent attribute."""
        target = MockTarget('user-123', 'Alice')
        ref = Reference(target, role='lead')
        
        with self.assertRaises(AttributeError) as cm:
            _ = ref.nonexistent
        
        self.assertIn('nonexistent', str(cm.exception))
    
    def test_set_multiple_attributes(self):
        """Test setting multiple attributes."""
        target = MockTarget('user-123', 'Alice')
        ref = Reference(target)
        
        ref.role = 'lead'
        ref.allocation = 1.0
        ref.status = 'active'
        ref.permissions = ['read', 'write']
        
        self.assertEqual(ref.role, 'lead')
        self.assertEqual(ref.allocation, 1.0)
        self.assertEqual(ref.status, 'active')
        self.assertEqual(ref.permissions, ['read', 'write'])


class TestReferenceTargetAccess(unittest.TestCase):
    """Test accessing reference target."""
    
    def test_target_property(self):
        """Test accessing target via property."""
        target = MockTarget('user-123', 'Alice', 'user')
        ref = Reference(target, role='lead')
        
        self.assertEqual(ref.target, target)
        self.assertEqual(ref.target.uuid, 'user-123')
        self.assertEqual(ref.target.name, 'Alice')
    
    def test_target_attributes_via_target_property(self):
        """Test accessing target attributes."""
        target = MockTarget('user-123', 'Alice')
        ref = Reference(target)
        
        # Access via .target property (the correct way)
        self.assertEqual(ref.target.uuid, 'user-123')
        self.assertEqual(ref.target.name, 'Alice')


class TestReferenceLinkDataMethods(unittest.TestCase):
    """Test Reference link data methods."""
    
    def test_get_method(self):
        """Test get method for link data."""
        target = MockTarget('user-123', 'Alice')
        ref = Reference(target, role='lead', allocation=1.0)
        
        self.assertEqual(ref.get('role'), 'lead')
        self.assertEqual(ref.get('allocation'), 1.0)
        self.assertIsNone(ref.get('nonexistent'))
        self.assertEqual(ref.get('nonexistent', 'default'), 'default')
    
    def test_set_method(self):
        """Test set method for link data."""
        target = MockTarget('user-123', 'Alice')
        ref = Reference(target, role='member')
        
        ref.set('role', 'lead')
        ref.set('allocation', 1.0)
        
        self.assertEqual(ref.role, 'lead')
        self.assertEqual(ref.allocation, 1.0)
        self.assertTrue(ref.is_modified())
    
    def test_update_method(self):
        """Test update method for link data."""
        target = MockTarget('user-123', 'Alice')
        ref = Reference(target, role='member', allocation=0.5)
        
        ref.update(role='lead', allocation=1.0, status='active')
        
        self.assertEqual(ref.role, 'lead')
        self.assertEqual(ref.allocation, 1.0)
        self.assertEqual(ref.status, 'active')
        self.assertTrue(ref.is_modified())
    
    def test_has_method(self):
        """Test has method for checking link data."""
        target = MockTarget('user-123', 'Alice')
        ref = Reference(target, role='lead', allocation=1.0)
        
        self.assertTrue(ref.has('role'))
        self.assertTrue(ref.has('allocation'))
        self.assertFalse(ref.has('nonexistent'))
    
    def test_link_data_property(self):
        """Test link_data property returns all data."""
        target = MockTarget('user-123', 'Alice')
        ref = Reference(target, role='lead', allocation=1.0, status='active')
        
        link_data = ref.link_data
        
        self.assertIn('role', link_data)
        self.assertIn('allocation', link_data)
        self.assertIn('status', link_data)
        self.assertEqual(len(link_data), 3)
    
    def test_link_data_returns_copy(self):
        """Test link_data returns a copy, not original."""
        target = MockTarget('user-123', 'Alice')
        ref = Reference(target, role='lead', allocation=1.0)
        
        link_data = ref.link_data
        link_data['role'] = 'modified'
        
        # Original should be unchanged
        self.assertEqual(ref.get('role'), 'lead')
    
    def test_iterating_link_data(self):
        """Test iterating over link data."""
        target = MockTarget('user-123', 'Alice')
        ref = Reference(target, role='lead', allocation=1.0)
        
        # Can iterate over the dict returned by link_data property
        link_data = ref.link_data
        
        self.assertIn('role', link_data.keys())
        self.assertIn('lead', link_data.values())
        self.assertIn(('allocation', 1.0), link_data.items())


class TestReferenceModificationTracking(unittest.TestCase):
    """Test Reference modification tracking."""
    
    def test_is_modified_initial(self):
        """Test is_modified is False initially."""
        target = MockTarget('user-123', 'Alice')
        ref = Reference(target, role='lead')
        
        self.assertFalse(ref.is_modified())
    
    def test_is_modified_after_attribute_set(self):
        """Test is_modified after setting attribute."""
        target = MockTarget('user-123', 'Alice')
        ref = Reference(target, role='member')
        
        ref.role = 'lead'
        
        self.assertTrue(ref.is_modified())
    
    def test_is_modified_after_set_method(self):
        """Test is_modified after set method."""
        target = MockTarget('user-123', 'Alice')
        ref = Reference(target, role='member')
        
        ref.set('allocation', 1.0)
        
        self.assertTrue(ref.is_modified())
    
    def test_is_modified_after_update_method(self):
        """Test is_modified after update method."""
        target = MockTarget('user-123', 'Alice')
        ref = Reference(target, role='member')
        
        ref.update(role='lead')
        
        self.assertTrue(ref.is_modified())
    
    def test_save_method(self):
        """Test save method (placeholder implementation)."""
        target = MockTarget('user-123', 'Alice')
        ref = Reference(target, role='member')
        
        ref.role = 'lead'
        
        # save() is a placeholder, should not raise error
        ref.save()


class TestReferenceConversions(unittest.TestCase):
    """Test Reference conversion methods."""
    
    def test_to_dict_basic(self):
        """Test to_dict with basic reference."""
        target = MockTarget('user-123', 'Alice', 'user')
        ref = Reference(target, role='lead', allocation=1.0)
        
        result = ref.to_dict()
        
        self.assertEqual(result['target']['uuid'], 'user-123')
        self.assertEqual(result['target']['name'], 'Alice')
        self.assertEqual(result['target']['obj_type'], 'user')
        self.assertEqual(result['link_data'], {'role': 'lead', 'allocation': 1.0})
    
    def test_to_dict_no_link_data(self):
        """Test to_dict with no link data."""
        target = MockTarget('user-123', 'Alice')
        ref = Reference(target)
        
        result = ref.to_dict()
        
        self.assertEqual(result['link_data'], {})
    
    def test_to_dict_target_no_attributes(self):
        """Test to_dict when target lacks attributes."""
        class MinimalTarget:
            pass
        
        target = MinimalTarget()
        ref = Reference(target, role='lead')
        
        result = ref.to_dict()
        
        self.assertIsNone(result['target']['uuid'])
        self.assertIsNone(result['target']['name'])
        self.assertIsNone(result['target']['obj_type'])
        self.assertEqual(result['link_data'], {'role': 'lead'})
    
    def test_repr_basic(self):
        """Test __repr__ with basic reference."""
        target = MockTarget('user-123', 'Alice')
        ref = Reference(target, role='lead', allocation=1.0)
        
        repr_str = repr(ref)
        
        self.assertIn('Reference', repr_str)
        self.assertIn('Alice', repr_str)
    
    def test_repr_no_link_data(self):
        """Test __repr__ with no link data."""
        target = MockTarget('user-123', 'Alice')
        ref = Reference(target)
        
        repr_str = repr(ref)
        
        self.assertIn('Reference', repr_str)
        self.assertIn('Alice', repr_str)


class TestReferenceComparison(unittest.TestCase):
    """Test Reference comparison methods."""
    
    def test_equality_same_target(self):
        """Test equality with same target UUID."""
        target1 = MockTarget('user-123', 'Alice')
        target2 = MockTarget('user-123', 'Alice')
        
        ref1 = Reference(target1, role='lead')
        ref2 = Reference(target2, role='member')
        
        self.assertEqual(ref1, ref2)
    
    def test_equality_different_target(self):
        """Test equality with different target UUID."""
        target1 = MockTarget('user-123', 'Alice')
        target2 = MockTarget('user-456', 'Bob')
        
        ref1 = Reference(target1, role='lead')
        ref2 = Reference(target2, role='lead')
        
        self.assertNotEqual(ref1, ref2)
    
    def test_equality_non_reference(self):
        """Test equality with non-Reference object."""
        target = MockTarget('user-123', 'Alice')
        ref = Reference(target)
        
        self.assertNotEqual(ref, "not a reference")
        self.assertNotEqual(ref, 123)
        self.assertNotEqual(ref, None)
    
    def test_hash_basic(self):
        """Test hash for use in sets/dicts."""
        target = MockTarget('user-123', 'Alice')
        ref1 = Reference(target, role='lead')
        ref2 = Reference(target, role='member')
        
        # Same target UUID should have same hash
        self.assertEqual(hash(ref1), hash(ref2))
    
    def test_hash_different_targets(self):
        """Test hash with different targets."""
        target1 = MockTarget('user-123', 'Alice')
        target2 = MockTarget('user-456', 'Bob')
        
        ref1 = Reference(target1)
        ref2 = Reference(target2)
        
        # Different UUIDs should (likely) have different hashes
        self.assertNotEqual(hash(ref1), hash(ref2))
    
    def test_hash_in_set(self):
        """Test using references in a set."""
        target1 = MockTarget('user-123', 'Alice')
        target2 = MockTarget('user-456', 'Bob')
        
        ref1a = Reference(target1, role='lead')
        ref1b = Reference(target1, role='member')
        ref2 = Reference(target2, role='lead')
        
        ref_set = {ref1a, ref1b, ref2}
        
        # Should have 2 items (ref1a and ref1b are considered equal)
        self.assertEqual(len(ref_set), 2)
    
    def test_hash_in_dict(self):
        """Test using references as dict keys."""
        target1 = MockTarget('user-123', 'Alice')
        target2 = MockTarget('user-456', 'Bob')
        
        ref1 = Reference(target1)
        ref2 = Reference(target2)
        
        ref_dict = {ref1: 'first', ref2: 'second'}
        
        self.assertEqual(ref_dict[ref1], 'first')
        self.assertEqual(ref_dict[ref2], 'second')


class TestReferenceEdgeCases(unittest.TestCase):
    """Test Reference edge cases."""
    
    def test_empty_link_data(self):
        """Test reference with empty link data."""
        target = MockTarget('user-123', 'Alice')
        ref = Reference(target)
        
        link_data = ref.link_data
        self.assertEqual(len(link_data), 0)
    
    def test_none_values_in_link_data(self):
        """Test reference with None values."""
        target = MockTarget('user-123', 'Alice')
        ref = Reference(target, role=None, allocation=None)
        
        self.assertIsNone(ref.role)
        self.assertIsNone(ref.allocation)
    
    def test_complex_nested_link_data(self):
        """Test reference with complex nested data."""
        target = MockTarget('user-123', 'Alice')
        ref = Reference(
            target,
            metadata={
                'permissions': {
                    'read': True,
                    'write': True,
                    'admin': False
                },
                'history': ['action1', 'action2']
            }
        )
        
        self.assertIsInstance(ref.metadata, dict)
        self.assertTrue(ref.metadata['permissions']['read'])
        self.assertEqual(len(ref.metadata['history']), 2)
    
    def test_modify_after_creation(self):
        """Test modifying reference after creation."""
        target = MockTarget('user-123', 'Alice')
        ref = Reference(target, role='member', allocation=0.5)
        
        # Multiple modifications
        ref.role = 'lead'
        ref.allocation = 1.0
        ref.status = 'active'
        ref.priority = 10
        
        self.assertEqual(ref.role, 'lead')
        self.assertEqual(ref.allocation, 1.0)
        self.assertEqual(ref.status, 'active')
        self.assertEqual(ref.priority, 10)
        self.assertTrue(ref.is_modified())
    
    def test_get_with_various_defaults(self):
        """Test get method with various default values."""
        target = MockTarget('user-123', 'Alice')
        ref = Reference(target, role='lead')
        
        self.assertIsNone(ref.get('nonexistent'))
        self.assertEqual(ref.get('nonexistent', 'default'), 'default')
        self.assertEqual(ref.get('nonexistent', 0), 0)
        self.assertEqual(ref.get('nonexistent', []), [])
        self.assertEqual(ref.get('nonexistent', {}), {})


if __name__ == '__main__':
    unittest.main(verbosity=2)
