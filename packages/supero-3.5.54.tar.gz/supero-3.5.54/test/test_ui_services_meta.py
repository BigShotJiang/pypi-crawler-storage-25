"""
Meta-test for the services-ui static checks.

Runs each check function from test_services_ui against:
  - fixtures/mock_*_fixed.{js,jsx}      → all checks must PASS
  - fixtures/mock_*_postpatch.{js,jsx}  → specific checks must FAIL
                                          (the bug they were written for)

Why this exists: it's the watchdog for the watchdogs. If someone "fixes"
a flaky check by relaxing it, the postpatch fixture starts passing it —
and this meta-test fires.
"""
from __future__ import annotations
import unittest
from pathlib import Path

# After flattening: import the renamed sibling test module.
import os as _os
import sys as _sys
_sys.path.insert(0, _os.path.dirname(_os.path.abspath(__file__)))

import test_ui_services as suite

_FIX = Path(__file__).resolve().parent / "ui" / "fixtures"

# Names of fixtures the meta-test relies on. If any are removed without
# updating this list, TestFixturesPresent will fail — the watchdog has
# its own watchdog.
_REQUIRED_FIXTURES = [
    "mock_supero_ui_fixed.js",
    "mock_supero_ui_postpatch.js",
    "mock_supero_mobile_fixed.jsx",
    "mock_supero_mobile_postpatch.jsx",
]


def _read(name):
    p = _FIX / name
    if not p.exists():
        return None
    return p.read_text(encoding="utf-8", errors="replace")


# Fixtures are deliberately minimal — they carry only the structural
# patterns each check needs to inspect. So we only validate the checks
# whose patterns are present in the fixtures.
#
# B1, B2, M5: pattern present in fixtures → exercised here.
# S1, S2, S3, M11, M18: need richer source surface → live-file only.


class TestFixturesPresent(unittest.TestCase):
    """The watchdog's watchdog.

    Without this check, an attacker (or careless cleanup) could disable
    the meta-test suite by deleting the postpatch fixtures: setUpClass
    in the other meta classes would just SkipTest silently. This test
    has no setUpClass guard — it always runs and always fails when a
    fixture is missing.
    """

    def test_all_meta_fixtures_present(self):
        missing = [n for n in _REQUIRED_FIXTURES if not (_FIX / n).exists()]
        self.assertFalse(
            missing,
            f"Meta-test fixtures missing from {_FIX}: {missing}. "
            "If you intentionally removed a fixture, also remove its name "
            "from _REQUIRED_FIXTURES in this file.",
        )


class TestSuiteAgainstFixedFixtures(unittest.TestCase):
    """All structural checks pass against the fixed fixtures."""

    @classmethod
    def setUpClass(cls):
        cls.web = _read("mock_supero_ui_fixed.js")
        cls.mobile = _read("mock_supero_mobile_fixed.jsx")
        if cls.web is None or cls.mobile is None:
            raise unittest.SkipTest(
                "fixed fixtures missing from ui/fixtures/")

    def _ok(self, ok, msg, fid):
        if ok is None:
            self.skipTest(f"[{fid}] inconclusive: {msg}")
        self.assertTrue(ok, f"[{fid}] FIXED fixture should pass: {msg}")

    def test_b1_passes_on_fixed(self):
        self._ok(*suite.check_b1_drive_vs_gdrive(self.web, self.mobile), "B1")

    def test_b2_passes_on_fixed(self):
        self._ok(*suite.check_b2_prompt_services(self.web, self.mobile), "B2")

    def test_m5_passes_on_fixed(self):
        self._ok(*suite.check_m5_dead_keymap_entries(self.web), "M5")


class TestSuiteAgainstPostpatchFixtures(unittest.TestCase):
    """Each check fires on the postpatch fixture — proves it can detect."""

    @classmethod
    def setUpClass(cls):
        cls.web = _read("mock_supero_ui_postpatch.js")
        cls.mobile = _read("mock_supero_mobile_postpatch.jsx")
        if cls.web is None or cls.mobile is None:
            raise unittest.SkipTest(
                "postpatch fixtures missing from ui/fixtures/")

    def _must_fail(self, ok, msg, fid):
        if ok is None:
            self.skipTest(f"[{fid}] inconclusive: {msg}")
        self.assertFalse(ok, (
            f"[{fid}] check no longer detects its bug ({msg}). "
            "Either the postpatch fixture was inadvertently 'fixed' "
            "(update it) or the check itself was relaxed (revert it)."
        ))

    def test_b1_detects_drive_gdrive_mismatch(self):
        self._must_fail(*suite.check_b1_drive_vs_gdrive(
            self.web, self.mobile), "B1")

    def test_b2_detects_unresolved_prompt_names(self):
        self._must_fail(*suite.check_b2_prompt_services(
            self.web, self.mobile), "B2")

    def test_m5_detects_orphan_keymap_entries(self):
        self._must_fail(*suite.check_m5_dead_keymap_entries(self.web), "M5")


if __name__ == "__main__":
    unittest.main()
