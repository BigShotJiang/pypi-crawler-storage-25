# File: test_extensions.py
"""
Unit tests for the ApiLib extension system.

This test suite covers:
- ApiLibExtension base class functionality
- ExtensionRegistry management
- ExtensionManager integration
- ApiLib extension integration
- Error handling and edge cases
"""

import sys
import os
import unittest
import json
from pathlib import Path
from unittest.mock import Mock, patch, MagicMock

# Setup paths for testing
test_dir = Path(__file__).parent
project_root = test_dir.parent
src_dir = project_root / "src"

for path in [str(src_dir), str(project_root)]:
    if path not in sys.path:
        sys.path.insert(0, path)

# Set test environment
os.environ["TESTING"] = "true"

# Mock dependencies before importing
def setup_test_mocks():
    """Setup mocks for dependencies."""
    
    # Mock api_logger
    api_logger_mock = MagicMock()
    api_logger_mock.get_logger.return_value = MagicMock()
    sys.modules['py_api_lib.api_logger'] = api_logger_mock
    
    # Mock pymodel
    pymodel_mock = MagicMock()
    pymodel_serialization_mock = MagicMock()
    
    # Mock serialization functions
    pymodel_serialization_mock.safe_serialize_to_dict = lambda obj, obj_type=None: {'mocked': True}
    pymodel_serialization_mock.safe_serialize_to_json = lambda obj, obj_type=None: '{"mocked": true}'
    pymodel_serialization_mock.safe_deserialize_from_dict = lambda data, cls, obj_type=None: MagicMock()
    pymodel_serialization_mock.SerializationError = Exception
    pymodel_serialization_mock.ObjectSerializationError = Exception
    pymodel_serialization_mock.ObjectDeserializationError = Exception
    pymodel_serialization_mock.JSONSerializationError = Exception
    pymodel_serialization_mock.JSONDeserializationError = Exception
    
    # Create pymodel.objects mock with __path__ attribute
    pymodel_objects_mock = MagicMock()
    pymodel_objects_mock.__path__ = ['/fake/path']
    pymodel_objects_mock.__name__ = 'pymodel.objects'
    
    pymodel_mock.objects = pymodel_objects_mock
    pymodel_mock.serialization_errors = pymodel_serialization_mock
    
    sys.modules['pymodel'] = pymodel_mock
    sys.modules['pymodel.objects'] = pymodel_objects_mock
    sys.modules['pymodel.serialization_errors'] = pymodel_serialization_mock

# Apply mocks
setup_test_mocks()

# Import the extension system
from py_api_lib.extensions import (
    ApiLibExtension, ExtensionRegistry, ExtensionManager,
    QueryBuilderMixin, ResponseParserMixin,
    global_extension_registry, clear_global_extensions,
    list_global_extensions, register_global_extension_class,
    register_global_extension_package
)


class TestApiLibExtension(unittest.TestCase):
    """Test the base ApiLibExtension class."""
    
    def setUp(self):
        """Set up test fixtures."""
        self.mock_api_lib = Mock()
        self.extension = TestExtensionImpl()
    
    def test_extension_name_default(self):
        """Test default extension name generation."""
        self.assertEqual(self.extension.get_extension_name(), 'testimpl')
    
    def test_extension_name_custom(self):
        """Test custom extension name."""
        class CustomExtension(ApiLibExtension):
            def get_extension_name(self):
                return 'custom_name'
        
        ext = CustomExtension()
        self.assertEqual(ext.get_extension_name(), 'custom_name')
    
    def test_get_methods_default(self):
        """Test default get_methods returns empty dict."""
        class EmptyExtension(ApiLibExtension):
            pass
        
        ext = EmptyExtension()
        self.assertEqual(ext.get_methods(), {})
    
    def test_register_with_api_lib(self):
        """Test registering extension with ApiLib."""
        self.extension.register_with_api_lib(self.mock_api_lib)
        
        # Verify api_lib is set
        self.assertEqual(self.extension.api_lib, self.mock_api_lib)
        
        # Verify methods are added to api_lib
        methods = self.extension.get_methods()
        for method_name in methods.keys():
            self.assertTrue(hasattr(self.mock_api_lib, method_name))
    
    def test_unregister_from_api_lib(self):
        """Test unregistering extension from ApiLib."""
        # First register
        self.extension.register_with_api_lib(self.mock_api_lib)
        
        # Verify methods were added
        methods = self.extension.get_methods()
        for method_name in methods.keys():
            self.assertTrue(hasattr(self.mock_api_lib, method_name))
        
        # Mock the delattr calls we expect
        with patch('builtins.delattr') as mock_delattr:
            # Then unregister
            self.extension.unregister_from_api_lib(self.mock_api_lib)
            
            # Verify api_lib is cleared
            self.assertIsNone(self.extension.api_lib)
            
            # Verify delattr was called for each method
            expected_calls = len(methods)
            self.assertEqual(mock_delattr.call_count, expected_calls)
    
    def test_extension_method_override_warning(self):
        """Test warning when extension overrides existing method."""
        # Setup api_lib with existing method
        self.mock_api_lib.test_method = Mock()
        
        with patch.object(self.extension, 'logger') as mock_logger:
            self.extension.register_with_api_lib(self.mock_api_lib)
            
            # Should log warning about overriding existing method
            mock_logger.warning.assert_called()


class TestExtensionImpl(ApiLibExtension):
    """Test implementation of ApiLibExtension for testing."""
    
    def get_extension_name(self):
        return 'testimpl'
    
    def get_methods(self):
        return {
            'test_method': self.test_method,
            'another_method': self.another_method
        }
    
    def test_method(self):
        return 'test_result'
    
    def another_method(self, arg):
        return f'another_{arg}'


class TestExtensionRegistry(unittest.TestCase):
    """Test the ExtensionRegistry class."""
    
    def setUp(self):
        """Set up test fixtures."""
        self.registry = ExtensionRegistry()
    
    def tearDown(self):
        """Clean up after tests."""
        self.registry.clear()
    
    def test_register_extension_class(self):
        """Test registering an extension class."""
        self.registry.register_extension_class(TestExtensionImpl)
        
        # Verify extension is registered
        available = self.registry.list_available_extensions()
        self.assertIn('testimpl', available)
        
        # Verify we can get the class back
        ext_class = self.registry.get_extension_class('testimpl')
        self.assertEqual(ext_class, TestExtensionImpl)
    
    def test_register_invalid_extension_class(self):
        """Test registering invalid extension class raises error."""
        class NotAnExtension:
            pass
        
        with self.assertRaises(ValueError):
            self.registry.register_extension_class(NotAnExtension)
    
    def test_create_extension_instance(self):
        """Test creating extension instance from registry."""
        self.registry.register_extension_class(TestExtensionImpl)
        
        instance = self.registry.create_extension_instance('testimpl')
        
        self.assertIsInstance(instance, TestExtensionImpl)
        self.assertEqual(instance.get_extension_name(), 'testimpl')
    
    def test_create_nonexistent_extension(self):
        """Test creating instance of nonexistent extension returns None."""
        instance = self.registry.create_extension_instance('nonexistent')
        self.assertIsNone(instance)
    
    def test_register_extension_by_path(self):
        """Test registering extension by module path."""
        # Mock module with extension class
        mock_module = Mock()
        mock_module.TestExt = TestExtensionImpl
        
        # Mock the dir() function for this module
        def mock_dir(obj):
            if obj is mock_module:
                return ['TestExt']
            return []
        
        with patch('importlib.import_module', return_value=mock_module):
            with patch('builtins.dir', side_effect=mock_dir):
                self.registry.register_extension_by_path('test.module', 'TestExt')
        
        # Verify extension is registered
        self.assertIn('testimpl', self.registry.list_available_extensions())
    
    @unittest.skip("Skipped in CI - RecursionError with mock")
    def test_register_extension_by_path_auto_discover(self):
        """Test auto-discovering extensions in module."""
        # Mock module with multiple extension classes
        class AnotherTestExt(ApiLibExtension):
            def get_extension_name(self):
                return 'another'
        
        mock_module = Mock()
        mock_module.TestExt = TestExtensionImpl
        mock_module.AnotherTestExt = AnotherTestExt
        mock_module.NotAnExtension = str  # Should be ignored
        
        # Mock the dir() function for this module
        def mock_dir(obj):
            if obj is mock_module:
                return ['TestExt', 'AnotherTestExt', 'NotAnExtension']
            return []
        
        def mock_getattr(obj, name):
            if obj is mock_module:
                return getattr(mock_module, name)
            return getattr(obj, name)
        
        with patch('importlib.import_module', return_value=mock_module):
            with patch('builtins.dir', side_effect=mock_dir):
                with patch('builtins.getattr', side_effect=mock_getattr):
                    self.registry.register_extension_by_path('test.module')
        
        # Should register both extension classes but not the other class
        available = self.registry.list_available_extensions()
        self.assertIn('testimpl', available)
        self.assertIn('another', available)
    
    def test_register_extension_package(self):
        """Test registering extensions from package."""
        # Mock package with register_extensions function
        def mock_register_extensions():
            return [TestExtensionImpl]
        
        mock_package = Mock()
        mock_package.register_extensions = mock_register_extensions
        
        with patch('importlib.import_module', return_value=mock_package):
            self.registry.register_extension_package('test.package')
        
        # Verify extension is registered
        self.assertIn('testimpl', self.registry.list_available_extensions())
    
    def test_register_extension_package_invalid_return(self):
        """Test error when register_extensions returns invalid type."""
        def mock_register_extensions():
            return "not a list"
        
        mock_package = Mock()
        mock_package.register_extensions = mock_register_extensions
        
        with patch('importlib.import_module', return_value=mock_package):
            with self.assertRaises(ValueError):
                self.registry.register_extension_package('test.package')
    
    def test_clear_registry(self):
        """Test clearing the registry."""
        self.registry.register_extension_class(TestExtensionImpl)
        self.assertNotEqual(len(self.registry.list_available_extensions()), 0)
        
        self.registry.clear()
        self.assertEqual(len(self.registry.list_available_extensions()), 0)


class TestExtensionManager(unittest.TestCase):
    """Test the ExtensionManager class."""
    
    def setUp(self):
        """Set up test fixtures."""
        self.mock_api_lib = Mock()
        self.manager = ExtensionManager(self.mock_api_lib)
        
        # Clear global registry for clean tests
        clear_global_extensions()
        
        # Register test extension in global registry
        self.manager.register_extension_class(TestExtensionImpl)
    
    def tearDown(self):
        """Clean up after tests."""
        clear_global_extensions()
    
    def test_load_extension_by_name(self):
        """Test loading extension by name."""
        self.manager.load_extension('testimpl')
        
        # Verify extension is loaded
        loaded = self.manager.get_loaded_extensions()
        self.assertIn('testimpl', loaded)
        
        # Verify extension is registered with api_lib
        self.assertTrue(hasattr(self.mock_api_lib, 'test_method'))
    
    def test_load_extension_by_class(self):
        """Test loading extension by class."""
        self.manager.load_extension(TestExtensionImpl)
        
        # Verify extension is loaded
        loaded = self.manager.get_loaded_extensions()
        self.assertIn('testimpl', loaded)
    
    def test_load_extension_by_instance(self):
        """Test loading extension by instance."""
        ext_instance = TestExtensionImpl()
        self.manager.load_extension(ext_instance)
        
        # Verify extension is loaded
        loaded = self.manager.get_loaded_extensions()
        self.assertIn('testimpl', loaded)
    
    def test_load_invalid_extension(self):
        """Test loading invalid extension raises error."""
        with self.assertRaises(ValueError):
            self.manager.load_extension('nonexistent')
        
        with self.assertRaises(ValueError):
            self.manager.load_extension(123)  # Invalid type
    
    def test_unload_extension(self):
        """Test unloading extension."""
        # First load extension
        self.manager.load_extension('testimpl')
        self.assertIn('testimpl', self.manager.get_loaded_extensions())
        
        # Then unload it
        self.manager.unload_extension('testimpl')
        self.assertNotIn('testimpl', self.manager.get_loaded_extensions())
    
    def test_unload_nonexistent_extension(self):
        """Test unloading nonexistent extension logs warning."""
        with patch.object(self.manager, 'logger') as mock_logger:
            self.manager.unload_extension('nonexistent')
            
            # Should log warning
            mock_logger.warning.assert_called()
    
    def test_reload_extension(self):
        """Test reloading extension."""
        # Load extension
        self.manager.load_extension('testimpl')
        
        # Mock the unload and load methods to verify they're called
        with patch.object(self.manager, 'unload_extension') as mock_unload:
            with patch.object(self.manager, 'load_extension') as mock_load:
                self.manager.reload_extension('testimpl')
                
                mock_unload.assert_called_once_with('testimpl')
                mock_load.assert_called_once_with('testimpl')
    
    def test_has_extension(self):
        """Test checking if extension is loaded."""
        self.assertFalse(self.manager.has_extension('testimpl'))
        
        self.manager.load_extension('testimpl')
        self.assertTrue(self.manager.has_extension('testimpl'))
    
    def test_get_extension_methods(self):
        """Test getting mapping of methods to extensions."""
        self.manager.load_extension('testimpl')
        
        method_mapping = self.manager.get_extension_methods()
        
        self.assertEqual(method_mapping['test_method'], 'testimpl')
        self.assertEqual(method_mapping['another_method'], 'testimpl')
    
    def test_load_extensions_from_config_dict(self):
        """Test loading extensions from config dictionary."""
        config = {
            'extensions': ['testimpl']
        }
        
        self.manager.load_extensions_from_config(config)
        
        # Verify extension is loaded
        self.assertIn('testimpl', self.manager.get_loaded_extensions())
    
    def test_load_extensions_from_config_file(self):
        """Test loading extensions from config file."""
        # Mock file operations
        config_data = {
            'extension_packages': ['test.package'],
            'extensions': ['testimpl']
        }
        
        with patch('pathlib.Path.exists', return_value=True):
            with patch('builtins.open', mock_open_json(config_data)):
                with patch.object(self.manager, 'register_extension_package') as mock_register:
                    self.manager.load_extensions_from_config('config.json')
                    
                    # Verify package registration was attempted
                    mock_register.assert_called_with('test.package')


def mock_open_json(data):
    """Helper to mock open() for JSON files."""
    import json
    from unittest.mock import mock_open
    return mock_open(read_data=json.dumps(data))


class TestUtilityMixins(unittest.TestCase):
    """Test utility mixin classes."""
    
    def test_query_builder_mixin(self):
        """Test QueryBuilderMixin functionality."""
        
        class TestExtension(ApiLibExtension, QueryBuilderMixin):
            def test_geo_query(self, lon, lat):
                return self._build_geo_query(lon, lat)
            
            def test_filters(self, **kwargs):
                return self._build_filters(**kwargs)
        
        ext = TestExtension()
        
        # Test geo query building
        geo_query = ext.test_geo_query(-122.4, 37.7)
        expected = {
            "geo_point": {
                "coordinates": [-122.4, 37.7]
            }
        }
        self.assertEqual(geo_query, expected)
        
        # Test with None values
        geo_query_none = ext.test_geo_query(None, None)
        self.assertEqual(geo_query_none, {})
        
        # Test filter building
        filters = ext.test_filters(kws=['test'], city='SF', max_limit=10, custom_param='value')
        self.assertEqual(filters['keywords'], ['test'])
        self.assertEqual(filters['city'], 'SF')
        self.assertEqual(filters['max_limit'], 10)
        self.assertEqual(filters['custom_param'], 'value')
    
    def test_response_parser_mixin(self):
        """Test ResponseParserMixin functionality."""
        
        class TestExtension(ApiLibExtension, ResponseParserMixin):
            def test_parse_json(self, data):
                return self._parse_json_response(data)
            
            def test_extract_objects(self, data, key):
                return self._extract_objects(data, key)
            
            def test_hydrate_objects(self, data, cls):
                return self._hydrate_objects(data, cls)
        
        ext = TestExtension()
        
        # Test JSON parsing
        json_str = '{"test": "value"}'
        parsed = ext.test_parse_json(json_str)
        self.assertEqual(parsed, {"test": "value"})
        
        # Test with dict input
        dict_input = {"test": "value"}
        parsed_dict = ext.test_parse_json(dict_input)
        self.assertEqual(parsed_dict, {"test": "value"})
        
        # Test with invalid JSON
        invalid_json = '{"invalid": json'
        parsed_invalid = ext.test_parse_json(invalid_json)
        self.assertEqual(parsed_invalid, {})
        
        # Test object extraction
        response_data = {"objects": [{"id": 1}, {"id": 2}]}
        objects = ext.test_extract_objects(response_data, "objects")
        self.assertEqual(objects, [{"id": 1}, {"id": 2}])
        
        # Test with missing key
        missing_objects = ext.test_extract_objects(response_data, "missing")
        self.assertEqual(missing_objects, [])
        
        # Test object hydration
        class MockClass:
            def __init__(self, **kwargs):
                self.data = kwargs
            
            @classmethod
            def from_dict(cls, **kwargs):
                return cls(**kwargs)
        
        object_data = [{"id": 1, "name": "test1"}, {"id": 2, "name": "test2"}]
        hydrated = ext.test_hydrate_objects(object_data, MockClass)
        
        self.assertEqual(len(hydrated), 2)
        self.assertEqual(hydrated[0].data['id'], 1)
        self.assertEqual(hydrated[1].data['name'], 'test2')


class TestApiLibIntegration(unittest.TestCase):
    """Test ApiLib integration with extensions."""
    
    def setUp(self):
        """Set up test fixtures."""
        # Clear global registry
        clear_global_extensions()
        
        # Mock ApiClient to avoid real API calls
        self.mock_api_client = Mock()
        
        # Patch ApiClient creation in ApiLib
        self.api_client_patcher = patch('py_api_lib.api_lib.ApiClient')
        self.mock_api_client_class = self.api_client_patcher.start()
        self.mock_api_client_class.return_value = self.mock_api_client
        
        # Import ApiLib class here to get the actual class for patching
        from py_api_lib.api_lib import ApiLib
        self.ApiLib = ApiLib
        
        # Mock other dependencies using the actual class
        self.mock_load_object_types = patch.object(
            self.ApiLib, '_load_object_types', return_value=[]
        )
        self.mock_create_dynamic_methods = patch.object(
            self.ApiLib, '_create_dynamic_methods'
        )
        
        self.mock_load_object_types.start()
        self.mock_create_dynamic_methods.start()
    
    def tearDown(self):
        """Clean up after tests."""
        self.api_client_patcher.stop()
        self.mock_load_object_types.stop()
        self.mock_create_dynamic_methods.stop()
        clear_global_extensions()
    
    def test_api_lib_without_extensions(self):
        """Test ApiLib works normally without extensions."""
        api_lib = self.ApiLib()
        
        # Should have extension manager but no extensions loaded
        self.assertEqual(len(api_lib.get_loaded_extensions()), 0)
    
    def test_api_lib_with_extensions_parameter(self):
        """Test ApiLib with extensions parameter."""
        # Register extension globally first
        global_extension_registry.register_extension_class(TestExtensionImpl)
        
        api_lib = self.ApiLib(extensions=['testimpl'])
        
        # Should have extension loaded
        self.assertIn('testimpl', api_lib.get_loaded_extensions())
        
        # Should have extension methods available
        self.assertTrue(hasattr(api_lib, 'test_method'))
    
    def test_api_lib_extension_methods(self):
        """Test that ApiLib extension methods work correctly."""
        api_lib = self.ApiLib()
        
        # Load extension
        api_lib.register_extension_class(TestExtensionImpl)
        api_lib.load_extension('testimpl')
        
        # Test extension methods
        self.assertEqual(len(api_lib.get_loaded_extensions()), 1)
        self.assertTrue(api_lib.has_extension('testimpl'))
        
        # Test method mapping
        method_mapping = api_lib.get_extension_methods()
        self.assertEqual(method_mapping['test_method'], 'testimpl')
        
        # Test unloading
        api_lib.unload_extension('testimpl')
        self.assertEqual(len(api_lib.get_loaded_extensions()), 0)
    
    def test_api_lib_extension_error_handling(self):
        """Test ApiLib handles extension errors gracefully."""
        api_lib = self.ApiLib()
        
        # Try to load nonexistent extension - should not crash ApiLib
        with patch.object(api_lib._extension_manager, 'logger'):
            try:
                api_lib.load_extension('nonexistent')  # Should log error but not crash
            except ValueError:
                pass  # Expected for nonexistent extension
        
        # ApiLib should still be functional
        self.assertEqual(len(api_lib.get_loaded_extensions()), 0)


class TestGlobalExtensionFunctions(unittest.TestCase):
    """Test global extension management functions."""
    
    def setUp(self):
        """Set up test fixtures."""
        clear_global_extensions()
    
    def tearDown(self):
        """Clean up after tests."""
        clear_global_extensions()
    
    def test_register_global_extension_class(self):
        """Test registering extension class globally."""
        from py_api_lib.extensions import register_global_extension_class, list_global_extensions
        
        register_global_extension_class(TestExtensionImpl)
        
        available = list_global_extensions()
        self.assertIn('testimpl', available)
    
    def test_register_global_extension_package(self):
        """Test registering extension package globally."""
        from py_api_lib.extensions import register_global_extension_package
        
        # Mock package
        mock_package = Mock()
        mock_package.register_extensions = lambda: [TestExtensionImpl]
        
        with patch('importlib.import_module', return_value=mock_package):
            register_global_extension_package('test.package')
        
        available = list_global_extensions()
        self.assertIn('testimpl', available)
    
    def test_clear_global_extensions(self):
        """Test clearing global extensions."""
        from py_api_lib.extensions import register_global_extension_class, list_global_extensions
        
        register_global_extension_class(TestExtensionImpl)
        self.assertNotEqual(len(list_global_extensions()), 0)
        
        clear_global_extensions()
        self.assertEqual(len(list_global_extensions()), 0)


def create_test_suite():
    """Create comprehensive test suite for extensions."""
    suite = unittest.TestSuite()
    
    test_classes = [
        TestApiLibExtension,
        TestExtensionRegistry,
        TestExtensionManager,
        TestUtilityMixins,
        TestApiLibIntegration,
        TestGlobalExtensionFunctions
    ]
    
    for test_class in test_classes:
        suite.addTest(unittest.TestLoader().loadTestsFromTestCase(test_class))
    
    return suite


if __name__ == '__main__':
    # Run the tests
    suite = create_test_suite()
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)
    
    # Print summary
    print(f"\nTest Summary:")
    print(f"Tests run: {result.testsRun}")
    print(f"Failures: {len(result.failures)}")
    print(f"Errors: {len(result.errors)}")
    print(f"Success rate: {((result.testsRun - len(result.failures) - len(result.errors)) / result.testsRun * 100):.1f}%")
    
    if result.failures:
        print(f"\nFailures:")
        for test, traceback in result.failures:
            print(f"- {test}: {traceback}")
    
    if result.errors:
        print(f"\nErrors:")
        for test, traceback in result.errors:
            print(f"- {test}: {traceback}")
