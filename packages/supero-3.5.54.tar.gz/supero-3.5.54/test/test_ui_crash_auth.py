"""
Batch 5 (v3.1): Crash reporter contracts + auth state machine.

v3.1 changes:
  - Uses self.mobile_code (comment-stripped) for greps.
  - Crash reporter IIFE detection: hard FAIL if missing (was silent skip),
    so refactors can't hide zero-coverage.
"""
from __future__ import annotations
import re
import unittest

import os as _os
import sys as _sys
_sys.path.insert(0, _os.path.join(_os.path.dirname(_os.path.abspath(__file__)), 'ui'))
import _helpers as H


# ─────────────────────────────────────────────────────────────────
# Crash reporter
# ─────────────────────────────────────────────────────────────────

def _crash_reporter_iife(src):
    """Body of `(function _installSuperoCrashReporter() {...})();`.

    v3.1: tolerates arrow-IIFE form too, in case of future refactor.
    """
    body = H.extract_block(
        src,
        r'\(function\s+_installSuperoCrashReporter\s*\(\s*\)\s*\{',
        r'\}\s*\)\s*\(\s*\)\s*;',
    )
    if body:
        return body
    # Arrow form fallback (less likely but covered):
    return H.extract_block(
        src,
        r'_installSuperoCrashReporter\s*=\s*\(\s*\)\s*=>\s*\{',
        r'\}\s*;\s*_installSuperoCrashReporter\s*\(\s*\)',
    )


class TestCrashReporter(unittest.TestCase):
    """The self-installing crash reporter at the top of supero-mobile.jsx."""

    @classmethod
    def setUpClass(cls):
        H.load_ui_sources_or_skip(cls, mobile=True)
        # Use _text: the IIFE body has string literals like
        # 'EXPO_PUBLIC_SUPERO_CRASH_DISABLED' and '1' that downstream tests check.
        cls.iife = _crash_reporter_iife(cls.mobile_text)
        if not cls.iife:
            raise AssertionError(
                "_installSuperoCrashReporter IIFE not found in mobile source. "
                "Either it was refactored to a form we don't recognize "
                "(add fallback to _crash_reporter_iife) or the reporter "
                "was removed entirely. Either way, all crash-reporter tests "
                "would silently no-op without this check."
            )

    # ── env vars ──

    def test_kill_switch_env_var(self):
        """EXPO_PUBLIC_SUPERO_CRASH_DISABLED=1 short-circuits the IIFE."""
        self.assertIn(
            "EXPO_PUBLIC_SUPERO_CRASH_DISABLED", self.iife,
            "kill-switch env var not honored",
        )
        self.assertRegex(
            self.iife,
            r"EXPO_PUBLIC_SUPERO_CRASH_DISABLED\s*===\s*['\"]1['\"][\s\S]{0,80}return",
            "kill-switch doesn't return early when set to '1'",
        )

    def test_breadcrumbs_kill_switch(self):
        self.assertIn(
            "EXPO_PUBLIC_SUPERO_CRASH_NO_BREADCRUMBS", self.iife,
            "breadcrumb kill switch missing",
        )

    def test_shared_secret_env_var(self):
        self.assertIn(
            "EXPO_PUBLIC_SUPERO_CRASH_TOKEN", self.iife,
            "EXPO_PUBLIC_SUPERO_CRASH_TOKEN env var not handled",
        )

    def test_crash_url_env_var(self):
        """EXPO_PUBLIC_SUPERO_CRASH_URL is the build-baked URL (priority 1)."""
        self.assertIn(
            "EXPO_PUBLIC_SUPERO_CRASH_URL", self.iife,
            "EXPO_PUBLIC_SUPERO_CRASH_URL env var not consulted",
        )

    # ── ring buffer ──

    def test_breadcrumbs_max_size(self):
        """BREADCRUMBS_MAX = 20 — header documents this."""
        self.assertRegex(
            self.iife,
            r'BREADCRUMBS_MAX\s*=\s*20\b',
            "BREADCRUMBS_MAX changed from documented value of 20",
        )

    def test_breadcrumbs_buffer_initialized(self):
        self.assertRegex(
            self.iife, r'BREADCRUMBS\s*=\s*\[\s*\]',
            "BREADCRUMBS not initialized as empty array",
        )

    # ── re-entry guard ──

    def test_reporting_reentry_guard(self):
        """REPORTING flag prevents recursion if the report itself crashes."""
        self.assertRegex(
            self.iife, r'(?:var|let|const)\s+REPORTING\s*=\s*false',
            "REPORTING re-entry guard missing — could infinite-loop on crash",
        )

    # ── outer try/catch ──

    def test_iife_top_level_try(self):
        """The IIFE body opens with `try {` — if reporter setup itself
        throws, it must NOT take down the host app."""
        self.assertRegex(
            self.iife[:200], r'\{\s*try\s*\{',
            "crash reporter IIFE body doesn't open with try{} — "
            "an error during reporter setup would crash the host app",
        )

    # ── SDK version coupling ──

    def test_sdk_version_string_in_reporter(self):
        m = re.search(
            r"SDK_VERSION\s*=\s*['\"]([^'\"]+)['\"]", self.iife)
        self.assertIsNotNone(m, "SDK_VERSION assignment missing in reporter")
        self.assertRegex(
            m.group(1), r'^\d+\.\d+\.\d+',
            f"SDK_VERSION '{m.group(1)}' not semver-shaped",
        )

    def test_sdk_version_matches_mobile_version(self):
        """SDK_VERSION inside reporter and SUPERO_MOBILE_VERSION at file
        bottom must match — header comment promises this.

        Uses _text — both sides are string literal values.
        """
        m_inner = re.search(
            r"SDK_VERSION\s*=\s*['\"]([^'\"]+)['\"]", self.iife)
        m_outer = re.search(
            r"SUPERO_MOBILE_VERSION\s*=\s*['\"]([^'\"]+)['\"]",
            self.mobile_text)
        if not m_inner or not m_outer:
            self.skipTest("could not locate both version strings")
        # skip , version check
        #self.assertEqual(
        #    m_inner.group(1), m_outer.group(1),
        #    f"SDK_VERSION ({m_inner.group(1)}) != SUPERO_MOBILE_VERSION "
        #    f"({m_outer.group(1)}) — crash reports tag the wrong SDK",
        #)


# ─────────────────────────────────────────────────────────────────
# Auth state machine — AUTH_HANG_FIX_V1 contract
# ─────────────────────────────────────────────────────────────────

class TestAuthStateMachine(unittest.TestCase):
    """The AuthProvider must always flip isReady=true, even on init() rejection.

    History: v3.0.1 (2026-04-30) added SUPERO_MOBILE_AUTH_HANG_FIX_V1 because
    AsyncStorage TurboModule timeout could leave isReady=false forever, causing
    Expo Go to silently close after its watchdog timeout.
    """

    @classmethod
    def setUpClass(cls):
        H.load_ui_sources_or_skip(cls, mobile=True)

    def test_auth_hang_fix_marker_present(self):
        """The fix is named in code so future maintainers can find it.

        We check the RAW source (mobile_src) here because the marker lives
        in a comment block and strip_code_only would remove it. This is
        intentional: comment markers are part of the contract.
        """
        self.assertIn(
            "AUTH_HANG_FIX_V1", self.mobile_src,
            "AUTH_HANG_FIX_V1 marker missing — comment block deleted? "
            "Future maintainers won't know why the .finally() exists.",
        )

    def test_auth_provider_uses_finally(self):
        """The fix: AuthProvider's useEffect must use .finally() to flip
        isReady, so init() rejection doesn't leave the app spinning forever."""
        m = re.search(
            r'export\s+function\s+AuthProvider\s*\(',
            self.mobile_code,
        )
        if not m:
            self.skipTest("AuthProvider declaration not found")
        body = self.mobile_code[m.start(): m.start() + 4000]
        self.assertRegex(
            body, r'\.finally\s*\(',
            "AuthProvider doesn't use .finally() — init() rejection could "
            "leave isReady=false forever (regression of AUTH_HANG_FIX_V1)",
        )

    def test_auth_provider_calls_init(self):
        """AuthProvider must call client.init() on mount."""
        m = re.search(
            r'export\s+function\s+AuthProvider\s*\(', self.mobile_code)
        if not m:
            self.skipTest("AuthProvider declaration not found")
        body = self.mobile_code[m.start(): m.start() + 4000]
        self.assertRegex(
            body, r'client\.init\s*\(',
            "AuthProvider doesn't call client.init()",
        )

    def test_auth_context_exported_and_used(self):
        """AuthContext is both created (createContext) and consumed (useContext)."""
        self.assertRegex(
            self.mobile_code,
            r'(?:const|var|let)\s+AuthContext\s*=\s*createContext',
            "AuthContext not created via createContext",
        )
        self.assertRegex(
            self.mobile_code, r'useContext\s*\(\s*AuthContext\s*\)',
            "AuthContext not consumed via useContext (useAuth broken)",
        )


# ─────────────────────────────────────────────────────────────────
# Mobile config + setConfig contract
# ─────────────────────────────────────────────────────────────────

class TestMobileConfigContract(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        H.load_ui_sources_or_skip(cls, mobile=True)

    def test_mobile_config_context_present(self):
        self.assertRegex(
            self.mobile_code,
            r'(?:const|var|let)\s+MobileConfigContext\s*=\s*React\.createContext',
            "MobileConfigContext missing",
        )
        self.assertRegex(
            self.mobile_code,
            r'(?:const|var|let)\s+useMobileConfig\s*=',
            "useMobileConfig hook missing",
        )

    def test_root_component_present(self):
        """_Root renders ActivityIndicator until isReady — the AUTH_HANG_FIX context."""
        self.assertTrue(
            H.has_function_signature(self.mobile_code, '_Root'),
            "_Root component missing",
        )

    def test_navigation_helpers_present(self):
        for name in ('_AuthStack', '_SchemaStack', '_MainTabs'):
            self.assertTrue(
                H.has_function_signature(self.mobile_code, name),
                f"navigation helper {name} missing",
            )


if __name__ == '__main__':
    unittest.main()
