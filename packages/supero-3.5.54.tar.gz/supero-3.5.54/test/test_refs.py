"""
================================================================================
Unit Tests for Reference Management APIs - CORRECTED VERSION
================================================================================

Fixed based on actual implementation behavior:
1. ref_update/ref_update_multi catch auth errors and return False (don't propagate)
2. Dynamic methods call api_client.get_refs directly (not _object_get_refs)
3. ApiLib passes instance api_key when no per-call api_key provided
4. Platform object domain resolution may not be implemented

================================================================================
"""

import unittest
import sys
import os
import json
from unittest.mock import Mock, MagicMock, patch, call

# Set test environment
os.environ["TESTING"] = "true"


def setup_test_mocks():
    """Setup mocks for missing dependencies."""
    try:
        import pymodel
        import pymodel.objects
        import pymodel.serialization_errors
    except ImportError:
        pymodel_mock = MagicMock()
        pymodel_objects_mock = MagicMock()
        pymodel_serialization_mock = MagicMock()
        
        pymodel_serialization_mock.safe_serialize_to_dict = lambda obj, obj_type=None: {}
        pymodel_serialization_mock.safe_serialize_to_json = lambda obj, obj_type=None: '{}'
        pymodel_serialization_mock.safe_deserialize_from_dict = lambda data, cls, obj_type=None: MagicMock()
        
        class SerializationError(Exception):
            pass
        class ObjectSerializationError(SerializationError):
            pass
        class ObjectDeserializationError(SerializationError):
            pass
        class JSONSerializationError(SerializationError):
            pass
        class JSONDeserializationError(SerializationError):
            def __init__(self, msg, obj_type=None, original_error=None):
                super().__init__(msg)
                self.obj_type = obj_type
                self.original_error = original_error
        
        pymodel_serialization_mock.SerializationError = SerializationError
        pymodel_serialization_mock.ObjectSerializationError = ObjectSerializationError
        pymodel_serialization_mock.ObjectDeserializationError = ObjectDeserializationError
        pymodel_serialization_mock.JSONSerializationError = JSONSerializationError
        pymodel_serialization_mock.JSONDeserializationError = JSONDeserializationError
        
        pymodel_mock.objects = pymodel_objects_mock
        pymodel_mock.serialization_errors = pymodel_serialization_mock
        
        sys.modules['pymodel'] = pymodel_mock
        sys.modules['pymodel.objects'] = pymodel_objects_mock
        sys.modules['pymodel.serialization_errors'] = pymodel_serialization_mock

    try:
        from py_api_lib import api_logger
        api_logger.initialize_logger("test-py-api-lib")
    except ImportError:
        api_logger_mock = MagicMock()
        sys.modules['py_api_lib.api_logger'] = api_logger_mock


setup_test_mocks()

from py_api_lib.api_lib import ApiLib
from py_api_lib.api_client import ApiClient
from py_api_lib.exceptions import (
    AuthenticationError,
    AuthorizationError,
    RateLimitError
)


# ==============================================================================
# Base Test Class with Common Utilities
# ==============================================================================

class BaseApiClientTest(unittest.TestCase):
    """Base class with common test utilities for consistent testing patterns."""
    
    def _mock_response(self, status_code, json_data=None, text="", headers=None):
        """Create a standardized mock response object."""
        response = Mock()
        response.status_code = status_code
        response.text = text if text else (json.dumps(json_data) if json_data else "")
        response.headers = headers or {}
        if json_data is not None:
            response.json.return_value = json_data
        else:
            response.json.side_effect = json.JSONDecodeError("No JSON", "", 0)
        return response
    
    def _assert_url_contains(self, mock_request, *parts):
        """Assert URL contains all specified parts."""
        call_args = mock_request.call_args
        url = call_args[0][1]  # Second positional arg is URL
        for part in parts:
            self.assertIn(part, url, f"URL '{url}' should contain '{part}'")
    
    def _assert_api_key_passed(self, mock_request, expected_key):
        """Assert api_key was passed correctly to _make_request."""
        call_args = mock_request.call_args
        actual_key = call_args[1].get('api_key')
        self.assertEqual(actual_key, expected_key)
    
    def _get_request_payload(self, mock_request):
        """Extract JSON payload from mock request call."""
        return mock_request.call_args[1].get('json', {})


# ==============================================================================
# ApiClient Low-Level HTTP Tests (10 tests)
# ==============================================================================

class TestApiClientHttpGetRefs(BaseApiClientTest):
    """Test ApiClient._http_get_refs low-level method."""

    def setUp(self):
        """Set up test fixtures."""
        with patch.object(ApiClient, '_test_connection', return_value=True):
            self.client = ApiClient(
                server_ip='localhost',
                port=8082,
                api_key='ak_test_proj_prod_abc123',
                default_domain='test-domain'
            )
        self.client.session = Mock()

    def test_http_get_refs_url_construction_basic(self):
        """Test URL is constructed correctly: /{domain}/{obj_type}/{uuid}/refs"""
        mock_response = self._mock_response(200, {
            "uuid": "uuid-123", "obj_type": "project", "fq_name": [],
            "refs": {}, "total_refs": 0
        })
        
        with patch.object(self.client, '_make_request', return_value=mock_response) as mock_req:
            self.client._http_get_refs('project', 'uuid-123', domain_name='acme-corp')
        
        self._assert_url_contains(mock_req, '/acme-corp/', '/project/', '/uuid-123/', '/refs')
        url = mock_req.call_args[0][1]
        self.assertTrue(url.endswith('/refs'), f"URL should end with /refs: {url}")

    def test_http_get_refs_url_construction_with_ref_type(self):
        """Test URL includes ref_type: /{domain}/{obj_type}/{uuid}/refs/{ref_type}"""
        mock_response = self._mock_response(200, {
            "uuid": "uuid-123", "obj_type": "project", "fq_name": [],
            "refs": {"user_account": []}, "total_refs": 0
        })
        
        with patch.object(self.client, '_make_request', return_value=mock_response) as mock_req:
            self.client._http_get_refs('project', 'uuid-123', ref_type='user-account')
        
        self._assert_url_contains(mock_req, '/refs/user-account')

    def test_http_get_refs_uses_default_domain(self):
        """Test default domain is used when domain_name not provided."""
        mock_response = self._mock_response(200, {
            "uuid": "u", "obj_type": "p", "fq_name": [], "refs": {}, "total_refs": 0
        })
        
        with patch.object(self.client, '_make_request', return_value=mock_response) as mock_req:
            self.client._http_get_refs('project', 'uuid-123')  # No domain_name
        
        self._assert_url_contains(mock_req, '/test-domain/')

    def test_http_get_refs_query_params_include_back_refs(self):
        """Test include_back_refs query parameter is passed correctly."""
        mock_response = self._mock_response(200, {
            "uuid": "u", "obj_type": "p", "fq_name": [], 
            "refs": {}, "total_refs": 0, "back_refs": {}, "total_back_refs": 0
        })
        
        with patch.object(self.client, '_make_request', return_value=mock_response) as mock_req:
            self.client._http_get_refs('project', 'uuid', include_back_refs=True)
        
        call_args = mock_req.call_args
        self.assertEqual(call_args[1]['params'], {'include_back_refs': 'true'})

    def test_http_get_refs_no_params_when_include_back_refs_false(self):
        """Test no params when include_back_refs=False (default)."""
        mock_response = self._mock_response(200, {
            "uuid": "u", "obj_type": "p", "fq_name": [], "refs": {}, "total_refs": 0
        })
        
        with patch.object(self.client, '_make_request', return_value=mock_response) as mock_req:
            self.client._http_get_refs('project', 'uuid', include_back_refs=False)
        
        call_args = mock_req.call_args
        self.assertIn(call_args[1].get('params'), [None, {}])

    def test_http_get_refs_passes_api_key(self):
        """Test api_key is passed to _make_request for RBAC support."""
        mock_response = self._mock_response(200, {
            "uuid": "u", "obj_type": "p", "fq_name": [], "refs": {}, "total_refs": 0
        })
        
        with patch.object(self.client, '_make_request', return_value=mock_response) as mock_req:
            self.client._http_get_refs('project', 'uuid', api_key='ak_custom_key')
        
        self._assert_api_key_passed(mock_req, 'ak_custom_key')

    def test_http_get_refs_returns_none_on_404(self):
        """Test returns None when object not found (404)."""
        mock_response = self._mock_response(404, text="Not found")
        
        with patch.object(self.client, '_make_request', return_value=mock_response):
            result = self.client._http_get_refs('project', 'nonexistent')
        
        self.assertIsNone(result)

    def test_http_get_refs_returns_none_on_400(self):
        """Test returns None on bad request (400)."""
        mock_response = self._mock_response(400, {"error": "Bad request"})
        
        with patch.object(self.client, '_make_request', return_value=mock_response):
            result = self.client._http_get_refs('project', 'uuid')
        
        self.assertIsNone(result)

    def test_http_get_refs_returns_none_on_500(self):
        """Test returns None on server error (500)."""
        mock_response = self._mock_response(500, {"error": "Internal server error"})
        
        with patch.object(self.client, '_make_request', return_value=mock_response):
            result = self.client._http_get_refs('project', 'uuid')
        
        self.assertIsNone(result)

    def test_http_get_refs_unwraps_platform_core_response(self):
        """Test response unwrapping for platform-core wrapped format."""
        mock_response = self._mock_response(200, {
            "success": True,
            "data": {
                "uuid": "uuid-123",
                "obj_type": "project",
                "fq_name": ["domain", "project"],
                "refs": {"user_account": [{"uuid": "u1", "fq_name": [], "attr": None}]},
                "total_refs": 1
            }
        })
        
        with patch.object(self.client, '_make_request', return_value=mock_response):
            result = self.client._http_get_refs('project', 'uuid-123')
        
        self.assertEqual(result['uuid'], 'uuid-123')
        self.assertEqual(result['total_refs'], 1)


# ==============================================================================
# ApiClient get_refs High-Level Tests (19 tests)
# ==============================================================================

class TestApiClientGetRefs(BaseApiClientTest):
    """Test ApiClient.get_refs and convenience methods."""

    def setUp(self):
        """Set up test fixtures."""
        with patch.object(ApiClient, '_test_connection', return_value=True):
            self.client = ApiClient(
                server_ip='localhost',
                port=8082,
                api_key='ak_test_proj_prod_abc123',
                default_domain='test-domain'
            )
        self.client.session = Mock()

    # -------------------------------------------------------------------------
    # get_refs Basic Tests
    # -------------------------------------------------------------------------

    def test_get_refs_returns_all_refs(self):
        """Test get_refs returns all references when no ref_type specified."""
        mock_response = self._mock_response(200, {
            "uuid": "project-uuid-123",
            "obj_type": "project",
            "fq_name": ["test-domain", "my-project"],
            "refs": {
                "user_account": [
                    {"uuid": "user-1", "fq_name": ["d", "p", "t", "alice"], "attr": {"role": "admin"}},
                    {"uuid": "user-2", "fq_name": ["d", "p", "t", "bob"], "attr": {"role": "viewer"}}
                ],
                "config": [
                    {"uuid": "config-1", "fq_name": ["d", "p", "default-config"], "attr": None}
                ]
            },
            "total_refs": 3
        })
        
        with patch.object(self.client, '_make_request', return_value=mock_response):
            result = self.client.get_refs('project', 'project-uuid-123')
        
        self.assertIsNotNone(result)
        self.assertEqual(result['uuid'], 'project-uuid-123')
        self.assertEqual(result['obj_type'], 'project')
        self.assertEqual(result['total_refs'], 3)
        self.assertIn('user_account', result['refs'])
        self.assertIn('config', result['refs'])
        self.assertEqual(len(result['refs']['user_account']), 2)
        self.assertEqual(len(result['refs']['config']), 1)
        self.assertNotIn('back_refs', result)

    def test_get_refs_with_ref_type_filter(self):
        """Test get_refs filters by ref_type."""
        mock_response = self._mock_response(200, {
            "uuid": "project-uuid", "obj_type": "project", "fq_name": [],
            "refs": {"user_account": [{"uuid": "u1", "fq_name": [], "attr": None}]},
            "total_refs": 1
        })
        
        with patch.object(self.client, '_make_request', return_value=mock_response) as mock_req:
            result = self.client.get_refs('project', 'uuid', ref_type='user-account')
        
        self._assert_url_contains(mock_req, '/refs/user-account')
        self.assertEqual(result['total_refs'], 1)

    def test_get_refs_with_back_refs(self):
        """Test get_refs includes back_refs when requested."""
        mock_response = self._mock_response(200, {
            "uuid": "project-uuid", "obj_type": "project", "fq_name": [],
            "refs": {"config": [{"uuid": "c1", "fq_name": [], "attr": None}]},
            "total_refs": 1,
            "back_refs": {
                "order": [
                    {"uuid": "o1", "fq_name": [], "attr": {"status": "pending"}},
                    {"uuid": "o2", "fq_name": [], "attr": {"status": "completed"}}
                ]
            },
            "total_back_refs": 2
        })
        
        with patch.object(self.client, '_make_request', return_value=mock_response) as mock_req:
            result = self.client.get_refs('project', 'uuid', include_back_refs=True)
        
        self.assertEqual(mock_req.call_args[1]['params'], {'include_back_refs': 'true'})
        self.assertIn('back_refs', result)
        self.assertEqual(result['total_back_refs'], 2)
        self.assertEqual(len(result['back_refs']['order']), 2)

    def test_get_refs_empty_refs(self):
        """Test get_refs handles empty refs."""
        mock_response = self._mock_response(200, {
            "uuid": "uuid", "obj_type": "project", "fq_name": [],
            "refs": {}, "total_refs": 0
        })
        
        with patch.object(self.client, '_make_request', return_value=mock_response):
            result = self.client.get_refs('project', 'uuid')
        
        self.assertEqual(result['refs'], {})
        self.assertEqual(result['total_refs'], 0)

    def test_get_refs_not_found_returns_none(self):
        """Test get_refs returns None for 404."""
        mock_response = self._mock_response(404)
        
        with patch.object(self.client, '_make_request', return_value=mock_response):
            result = self.client.get_refs('project', 'nonexistent')
        
        self.assertIsNone(result)

    # -------------------------------------------------------------------------
    # get_refs Domain and API Key Tests
    # -------------------------------------------------------------------------

    def test_get_refs_uses_provided_domain(self):
        """Test get_refs uses provided domain_name."""
        mock_response = self._mock_response(200, {
            "uuid": "u", "obj_type": "p", "fq_name": [], "refs": {}, "total_refs": 0
        })
        
        with patch.object(self.client, '_make_request', return_value=mock_response) as mock_req:
            self.client.get_refs('project', 'uuid', domain_name='custom-domain')
        
        self._assert_url_contains(mock_req, '/custom-domain/')

    def test_get_refs_uses_default_domain_when_not_provided(self):
        """Test get_refs uses default domain when domain_name=None."""
        mock_response = self._mock_response(200, {
            "uuid": "u", "obj_type": "p", "fq_name": [], "refs": {}, "total_refs": 0
        })
        
        with patch.object(self.client, '_make_request', return_value=mock_response) as mock_req:
            self.client.get_refs('project', 'uuid')
        
        self._assert_url_contains(mock_req, '/test-domain/')

    def test_get_refs_uses_per_call_api_key(self):
        """Test get_refs passes per-call api_key for RBAC."""
        mock_response = self._mock_response(200, {
            "uuid": "u", "obj_type": "p", "fq_name": [], "refs": {}, "total_refs": 0
        })
        
        with patch.object(self.client, '_make_request', return_value=mock_response) as mock_req:
            self.client.get_refs('project', 'uuid', api_key='ak_user_specific')
        
        self._assert_api_key_passed(mock_req, 'ak_user_specific')

    # -------------------------------------------------------------------------
    # get_refs Error Handling Tests
    # -------------------------------------------------------------------------

    def test_get_refs_raises_authentication_error(self):
        """Test get_refs raises AuthenticationError on 401."""
        with patch.object(self.client, '_make_request', 
                         side_effect=AuthenticationError("Invalid API key")):
            with self.assertRaises(AuthenticationError) as ctx:
                self.client.get_refs('project', 'uuid')
        
        self.assertIn("Invalid API key", str(ctx.exception))

    def test_get_refs_raises_authorization_error(self):
        """Test get_refs raises AuthorizationError on 403."""
        with patch.object(self.client, '_make_request',
                         side_effect=AuthorizationError("Insufficient permissions")):
            with self.assertRaises(AuthorizationError):
                self.client.get_refs('project', 'uuid')

    def test_get_refs_raises_rate_limit_error(self):
        """Test get_refs raises RateLimitError on 429 with retry_after."""
        with patch.object(self.client, '_make_request',
                         side_effect=RateLimitError("Rate limit exceeded", retry_after=60)):
            with self.assertRaises(RateLimitError) as ctx:
                self.client.get_refs('project', 'uuid')
        
        self.assertEqual(ctx.exception.retry_after, 60)

    # -------------------------------------------------------------------------
    # get_refs_by_type Tests
    # -------------------------------------------------------------------------

    def test_get_refs_by_type_returns_flat_list(self):
        """Test get_refs_by_type returns flat list of refs."""
        mock_response = self._mock_response(200, {
            "uuid": "uuid", "obj_type": "project", "fq_name": [],
            "refs": {
                "user_account": [
                    {"uuid": "u1", "fq_name": [], "attr": {"role": "admin"}},
                    {"uuid": "u2", "fq_name": [], "attr": {"role": "viewer"}}
                ]
            },
            "total_refs": 2
        })
        
        with patch.object(self.client, '_make_request', return_value=mock_response):
            result = self.client.get_refs_by_type('project', 'uuid', 'user-account')
        
        self.assertIsInstance(result, list)
        self.assertEqual(len(result), 2)
        self.assertEqual(result[0]['uuid'], 'u1')
        self.assertEqual(result[1]['uuid'], 'u2')

    def test_get_refs_by_type_returns_empty_when_no_match(self):
        """Test get_refs_by_type returns empty list when type not found."""
        mock_response = self._mock_response(200, {
            "uuid": "uuid", "obj_type": "project", "fq_name": [],
            "refs": {"config": [{"uuid": "c1", "fq_name": [], "attr": None}]},
            "total_refs": 1
        })
        
        with patch.object(self.client, '_make_request', return_value=mock_response):
            result = self.client.get_refs_by_type('project', 'uuid', 'user-account')
        
        self.assertEqual(result, [])

    def test_get_refs_by_type_handles_snake_case_response(self):
        """Test get_refs_by_type handles snake_case keys in response."""
        mock_response = self._mock_response(200, {
            "uuid": "uuid", "obj_type": "project", "fq_name": [],
            "refs": {"user_account": [{"uuid": "u1", "fq_name": [], "attr": None}]},
            "total_refs": 1
        })
        
        with patch.object(self.client, '_make_request', return_value=mock_response):
            result = self.client.get_refs_by_type('project', 'uuid', 'user-account')
        
        self.assertEqual(len(result), 1)

    def test_get_refs_by_type_returns_empty_on_404(self):
        """Test get_refs_by_type returns empty list on 404."""
        mock_response = self._mock_response(404)
        
        with patch.object(self.client, '_make_request', return_value=mock_response):
            result = self.client.get_refs_by_type('project', 'uuid', 'user-account')
        
        self.assertEqual(result, [])

    def test_get_refs_by_type_passes_domain_and_api_key(self):
        """Test get_refs_by_type passes domain_name and api_key."""
        mock_response = self._mock_response(200, {
            "uuid": "u", "obj_type": "p", "fq_name": [],
            "refs": {"user_account": []}, "total_refs": 0
        })
        
        with patch.object(self.client, '_make_request', return_value=mock_response) as mock_req:
            self.client.get_refs_by_type('project', 'uuid', 'user-account',
                                        domain_name='custom', api_key='ak_key')
        
        self._assert_url_contains(mock_req, '/custom/')
        self._assert_api_key_passed(mock_req, 'ak_key')

    # -------------------------------------------------------------------------
    # get_back_refs_by_type Tests
    # -------------------------------------------------------------------------

    def test_get_back_refs_by_type_returns_flat_list(self):
        """Test get_back_refs_by_type returns flat list."""
        mock_response = self._mock_response(200, {
            "uuid": "uuid", "obj_type": "customer", "fq_name": [],
            "refs": {}, "total_refs": 0,
            "back_refs": {
                "order": [
                    {"uuid": "o1", "fq_name": [], "attr": {"status": "pending"}},
                    {"uuid": "o2", "fq_name": [], "attr": {"status": "complete"}}
                ]
            },
            "total_back_refs": 2
        })
        
        with patch.object(self.client, '_make_request', return_value=mock_response):
            result = self.client.get_back_refs_by_type('customer', 'uuid', 'order')
        
        self.assertIsInstance(result, list)
        self.assertEqual(len(result), 2)

    def test_get_back_refs_by_type_returns_empty_when_no_match(self):
        """Test get_back_refs_by_type returns empty when type not found."""
        mock_response = self._mock_response(200, {
            "uuid": "uuid", "obj_type": "customer", "fq_name": [],
            "refs": {}, "total_refs": 0,
            "back_refs": {"invoice": [{"uuid": "i1", "fq_name": [], "attr": None}]},
            "total_back_refs": 1
        })
        
        with patch.object(self.client, '_make_request', return_value=mock_response):
            result = self.client.get_back_refs_by_type('customer', 'uuid', 'order')
        
        self.assertEqual(result, [])

    def test_get_back_refs_by_type_returns_empty_on_404(self):
        """Test get_back_refs_by_type returns empty on 404."""
        mock_response = self._mock_response(404)
        
        with patch.object(self.client, '_make_request', return_value=mock_response):
            result = self.client.get_back_refs_by_type('customer', 'uuid', 'order')
        
        self.assertEqual(result, [])

    def test_get_back_refs_by_type_passes_domain_and_api_key(self):
        """Test get_back_refs_by_type passes domain_name and api_key."""
        mock_response = self._mock_response(200, {
            "uuid": "u", "obj_type": "c", "fq_name": [],
            "refs": {}, "total_refs": 0,
            "back_refs": {"order": []}, "total_back_refs": 0
        })
        
        with patch.object(self.client, '_make_request', return_value=mock_response) as mock_req:
            self.client.get_back_refs_by_type('customer', 'uuid', 'order',
                                              domain_name='custom', api_key='ak_key')
        
        self._assert_url_contains(mock_req, '/custom/')
        self._assert_api_key_passed(mock_req, 'ak_key')


# ==============================================================================
# ApiClient ref_update Tests (6 tests) - CORRECTED
# ==============================================================================

class TestApiClientRefUpdate(BaseApiClientTest):
    """Test ApiClient.ref_update method."""

    def setUp(self):
        """Set up test fixtures."""
        with patch.object(ApiClient, '_test_connection', return_value=True):
            self.client = ApiClient(
                server_ip='localhost',
                port=8082,
                api_key='ak_test_proj_prod_abc123',
                default_domain='test-domain'
            )
        self.client.session = Mock()

    def test_ref_update_add_success(self):
        """Test ref_update ADD operation succeeds with correct payload."""
        mock_response = self._mock_response(200, {"success": True})
        
        with patch.object(self.client, '_make_request', return_value=mock_response) as mock_req:
            result = self.client.ref_update(
                from_type='project',
                from_uuid='project-uuid',
                to_type='user-account',
                to_uuid='user-uuid',
                to_fq_name=['domain', 'proj', 'tenant', 'alice'],
                attr={'role': 'admin'},
                operation='ADD'
            )
        
        self.assertTrue(result)
        
        call_args = mock_req.call_args
        self.assertEqual(call_args[0][0], 'PUT')
        
        payload = self._get_request_payload(mock_req)
        self.assertEqual(payload['type'], 'project')
        self.assertEqual(payload['uuid'], 'project-uuid')
        self.assertEqual(payload['ref-type'], 'user-account')
        self.assertEqual(payload['ref-uuid'], 'user-uuid')
        self.assertEqual(payload['ref-fq-name'], ['domain', 'proj', 'tenant', 'alice'])
        self.assertEqual(payload['attr'], {'role': 'admin'})
        self.assertEqual(payload['operation'], 'ADD')

    def test_ref_update_delete_success(self):
        """Test ref_update DELETE operation succeeds with null attr."""
        mock_response = self._mock_response(200, {"success": True})
        
        with patch.object(self.client, '_make_request', return_value=mock_response) as mock_req:
            result = self.client.ref_update(
                from_type='project',
                from_uuid='project-uuid',
                to_type='user-account',
                to_uuid='user-uuid',
                to_fq_name=[],
                attr=None,
                operation='DELETE'
            )
        
        self.assertTrue(result)
        
        payload = self._get_request_payload(mock_req)
        self.assertEqual(payload['operation'], 'DELETE')
        self.assertIsNone(payload['attr'])

    def test_ref_update_failure_returns_false(self):
        """Test ref_update returns False on error response."""
        mock_response = self._mock_response(400, {"error": "Source not found"})
        
        with patch.object(self.client, '_make_request', return_value=mock_response):
            result = self.client.ref_update(
                from_type='project',
                from_uuid='nonexistent',
                to_type='config',
                to_uuid='uuid',
                to_fq_name=[],
                attr=None,
                operation='ADD'
            )
        
        self.assertFalse(result)

    def test_ref_update_url_construction(self):
        """Test ref_update URL is constructed correctly."""
        mock_response = self._mock_response(200, {"success": True})
        
        with patch.object(self.client, '_make_request', return_value=mock_response) as mock_req:
            self.client.ref_update(
                from_type='project',
                from_uuid='uuid',
                to_type='config',
                to_uuid='uuid2',
                to_fq_name=[],
                attr=None,
                operation='ADD',
                domain_name='custom-domain'
            )
        
        self._assert_url_contains(mock_req, '/custom-domain/', '/ref-update')

    def test_ref_update_passes_api_key(self):
        """Test ref_update passes api_key for RBAC."""
        mock_response = self._mock_response(200, {"success": True})
        
        with patch.object(self.client, '_make_request', return_value=mock_response) as mock_req:
            self.client.ref_update(
                from_type='project',
                from_uuid='uuid',
                to_type='config',
                to_uuid='uuid2',
                to_fq_name=[],
                attr=None,
                operation='ADD',
                api_key='ak_user_key'
            )
        
        self._assert_api_key_passed(mock_req, 'ak_user_key')

    def test_ref_update_operation_uppercase(self):
        """Test operation is uppercased in payload."""
        mock_response = self._mock_response(200, {"success": True})
        
        with patch.object(self.client, '_make_request', return_value=mock_response) as mock_req:
            self.client.ref_update(
                from_type='project',
                from_uuid='uuid',
                to_type='config',
                to_uuid='uuid2',
                to_fq_name=[],
                attr=None,
                operation='add'  # lowercase
            )
        
        payload = self._get_request_payload(mock_req)
        self.assertEqual(payload['operation'], 'ADD')


# ==============================================================================
# ApiClient ref_update_multi Tests (5 tests) - CORRECTED
# ==============================================================================

class TestApiClientRefUpdateMulti(BaseApiClientTest):
    """Test ApiClient.ref_update_multi method."""

    def setUp(self):
        """Set up test fixtures."""
        with patch.object(ApiClient, '_test_connection', return_value=True):
            self.client = ApiClient(
                server_ip='localhost',
                port=8082,
                api_key='ak_test_proj_prod_abc123',
                default_domain='test-domain'
            )
        self.client.session = Mock()

    def test_ref_update_multi_success(self):
        """Test ref_update_multi succeeds with multiple operations."""
        mock_response = self._mock_response(200, {
            "success": True,
            "processed": 2,
            "results": [
                {"operation": "ADD", "success": True},
                {"operation": "DELETE", "success": True}
            ]
        })
        
        ref_updates = [
            {"type": "project", "uuid": "p1", "ref-type": "user", "ref-uuid": "u1",
             "ref-fq-name": [], "operation": "ADD", "attr": None},
            {"type": "project", "uuid": "p1", "ref-type": "user", "ref-uuid": "u2",
             "ref-fq-name": [], "operation": "DELETE", "attr": None}
        ]
        
        with patch.object(self.client, '_make_request', return_value=mock_response) as mock_req:
            result = self.client.ref_update_multi(ref_updates)
        
        self.assertTrue(result)
        
        payload = self._get_request_payload(mock_req)
        self.assertIn('refs', payload)
        self.assertEqual(len(payload['refs']), 2)

    def test_ref_update_multi_empty_list_returns_true(self):
        """Test ref_update_multi with empty list returns True (no-op)."""
        result = self.client.ref_update_multi([])
        self.assertTrue(result)

    def test_ref_update_multi_single_item(self):
        """Test ref_update_multi with single item works."""
        mock_response = self._mock_response(200, {"success": True, "processed": 1})
        
        with patch.object(self.client, '_make_request', return_value=mock_response):
            result = self.client.ref_update_multi([
                {"type": "t", "uuid": "u", "ref-type": "r", "ref-uuid": "r2",
                 "ref-fq-name": [], "operation": "ADD", "attr": None}
            ])
        
        self.assertTrue(result)

    def test_ref_update_multi_partial_failure(self):
        """Test ref_update_multi handles partial failures gracefully."""
        mock_response = self._mock_response(200, {
            "success": False,
            "processed": 2,
            "succeeded": 1,
            "failed": 1,
            "results": [
                {"success": True},
                {"success": False, "error": "Target not found"}
            ]
        })
        
        with patch.object(self.client, '_make_request', return_value=mock_response):
            result = self.client.ref_update_multi([
                {"type": "t", "uuid": "u", "ref-type": "r", "ref-uuid": "r1",
                 "ref-fq-name": [], "operation": "ADD", "attr": None},
                {"type": "t", "uuid": "u", "ref-type": "r", "ref-uuid": "bad",
                 "ref-fq-name": [], "operation": "ADD", "attr": None}
            ])
        
        self.assertTrue(result)

    def test_ref_update_multi_url_and_auth(self):
        """Test ref_update_multi uses correct URL and passes auth."""
        mock_response = self._mock_response(200, {"success": True})
        
        with patch.object(self.client, '_make_request', return_value=mock_response) as mock_req:
            self.client.ref_update_multi(
                [{"type": "t", "uuid": "u", "ref-type": "r", "ref-uuid": "r2",
                  "ref-fq-name": [], "operation": "ADD", "attr": None}],
                domain_name='custom-domain',
                api_key='ak_custom'
            )
        
        self._assert_url_contains(mock_req, '/custom-domain/', '/ref-update-multi')
        self._assert_api_key_passed(mock_req, 'ak_custom')


# ==============================================================================
# ApiLib Reference Tests (11 tests) - CORRECTED
# ==============================================================================

class TestApiLibGetRefs(unittest.TestCase):
    """Test ApiLib.get_refs and related methods."""

    def setUp(self):
        """Set up test fixtures."""
        with patch('py_api_lib.api_lib.ApiClient') as mock_client_class:
            self.mock_api_client = Mock()
            mock_client_class.return_value = self.mock_api_client
            self.api_lib = ApiLib(
                api_server_host='localhost',
                api_server_port='8082',
                api_key='ak_test_key'
            )
            self.api_lib.object_types = ['Domain', 'Project', 'Tenant', 'UserAccount']

    def test_get_refs_delegates_to_api_client(self):
        """Test get_refs delegates to api_client with correct params."""
        self.mock_api_client.get_refs.return_value = {
            "uuid": "uuid", "obj_type": "project", "fq_name": [],
            "refs": {}, "total_refs": 0
        }
        
        result = self.api_lib.get_refs('Project', 'project-uuid', domain_name='test-domain')
        
        # CORRECTED: Implementation passes instance api_key when no per-call api_key
        self.mock_api_client.get_refs.assert_called_once_with(
            obj_type='project',
            obj_uuid='project-uuid',
            ref_type=None,
            include_back_refs=False,
            domain_name='test-domain',
            api_key='ak_test_key'  # Instance api_key is passed
        )

    def test_get_refs_normalizes_pascal_case_obj_type(self):
        """Test get_refs normalizes PascalCase obj_type to kebab-case."""
        self.mock_api_client.get_refs.return_value = {"refs": {}, "total_refs": 0}
        
        self.api_lib.get_refs('UserAccount', 'uuid')
        
        call_kwargs = self.mock_api_client.get_refs.call_args[1]
        self.assertEqual(call_kwargs['obj_type'], 'user-account')

    def test_get_refs_normalizes_snake_case_obj_type(self):
        """Test get_refs normalizes snake_case obj_type."""
        self.mock_api_client.get_refs.return_value = {"refs": {}, "total_refs": 0}
        
        self.api_lib.get_refs('user_account', 'uuid')
        
        call_kwargs = self.mock_api_client.get_refs.call_args[1]
        self.assertEqual(call_kwargs['obj_type'], 'user-account')

    def test_get_refs_normalizes_ref_type(self):
        """Test get_refs normalizes ref_type parameter."""
        self.mock_api_client.get_refs.return_value = {"refs": {}, "total_refs": 0}
        
        self.api_lib.get_refs('Project', 'uuid', ref_type='UserAccount')
        
        call_kwargs = self.mock_api_client.get_refs.call_args[1]
        self.assertEqual(call_kwargs['ref_type'], 'user-account')

    def test_get_refs_passes_include_back_refs(self):
        """Test get_refs passes include_back_refs parameter."""
        self.mock_api_client.get_refs.return_value = {
            "refs": {}, "back_refs": {}, "total_refs": 0, "total_back_refs": 0
        }
        
        self.api_lib.get_refs('Project', 'uuid', include_back_refs=True)
        
        call_kwargs = self.mock_api_client.get_refs.call_args[1]
        self.assertTrue(call_kwargs['include_back_refs'])

    def test_get_refs_uses_default_domain_when_not_provided(self):
        """Test get_refs uses instance default_domain when not provided."""
        self.mock_api_client.get_refs.return_value = {"refs": {}, "total_refs": 0}
        
        self.api_lib.get_refs('Project', 'uuid')
        
        call_kwargs = self.mock_api_client.get_refs.call_args[1]
        self.assertEqual(call_kwargs['domain_name'], 'default-domain')

    def test_get_refs_passes_per_call_api_key(self):
        """Test get_refs passes per-call api_key for RBAC override."""
        self.mock_api_client.get_refs.return_value = {"refs": {}, "total_refs": 0}
        
        self.api_lib.get_refs('Project', 'uuid', api_key='ak_user_specific')
        
        call_kwargs = self.mock_api_client.get_refs.call_args[1]
        self.assertEqual(call_kwargs['api_key'], 'ak_user_specific')

    def test_get_refs_propagates_auth_error(self):
        """Test get_refs propagates AuthenticationError."""
        self.mock_api_client.get_refs.side_effect = AuthenticationError("Invalid key")
        
        with self.assertRaises(AuthenticationError):
            self.api_lib.get_refs('Project', 'uuid')

    def test_get_refs_propagates_authz_error(self):
        """Test get_refs propagates AuthorizationError."""
        self.mock_api_client.get_refs.side_effect = AuthorizationError("Forbidden")
        
        with self.assertRaises(AuthorizationError):
            self.api_lib.get_refs('Project', 'uuid')

    def test_get_refs_propagates_rate_limit_error(self):
        """Test get_refs propagates RateLimitError."""
        self.mock_api_client.get_refs.side_effect = RateLimitError("Limit", retry_after=30)
        
        with self.assertRaises(RateLimitError):
            self.api_lib.get_refs('Project', 'uuid')

    def test_get_refs_by_type_delegates_correctly(self):
        """Test get_refs_by_type delegates to api_client with normalization."""
        self.mock_api_client.get_refs_by_type.return_value = [
            {"uuid": "u1", "fq_name": [], "attr": {}}
        ]
        
        result = self.api_lib.get_refs_by_type('Project', 'uuid', 'UserAccount')
        
        self.assertIsInstance(result, list)
        self.assertEqual(len(result), 1)
        
        call_kwargs = self.mock_api_client.get_refs_by_type.call_args[1]
        self.assertEqual(call_kwargs['ref_type'], 'user-account')


# ==============================================================================
# ApiLib ref_update Tests (4 tests)
# ==============================================================================

class TestApiLibRefUpdate(unittest.TestCase):
    """Test ApiLib.ref_update method."""

    def setUp(self):
        """Set up test fixtures."""
        with patch('py_api_lib.api_lib.ApiClient') as mock_client_class:
            self.mock_api_client = Mock()
            mock_client_class.return_value = self.mock_api_client
            self.api_lib = ApiLib(api_server_host='localhost', api_server_port='8082')

    def test_ref_update_delegates_to_api_client(self):
        """Test ref_update delegates to api_client and returns obj_uuid on success."""
        self.mock_api_client.ref_update.return_value = True
        
        result = self.api_lib.ref_update(
            obj_type='Project',
            obj_uuid='project-uuid',
            ref_type='UserAccount',
            ref_uuid='user-uuid',
            ref_fq_name=['d', 'p', 't', 'user'],
            operation='ADD',
            attr={'role': 'admin'}
        )
        
        self.assertEqual(result, 'project-uuid')
        self.mock_api_client.ref_update.assert_called_once()

    def test_ref_update_normalizes_ref_type(self):
        """Test ref_update normalizes ref_type to kebab-case."""
        self.mock_api_client.ref_update.return_value = True
        
        self.api_lib.ref_update(
            obj_type='Project',
            obj_uuid='uuid',
            ref_type='UserAccount',
            ref_uuid='ref-uuid',
            ref_fq_name=[],
            operation='ADD'
        )
        
        call_kwargs = self.mock_api_client.ref_update.call_args[1]
        self.assertEqual(call_kwargs['to_type'], 'user-account')

    def test_ref_update_returns_none_on_failure(self):
        """Test ref_update returns None when api_client returns False."""
        self.mock_api_client.ref_update.return_value = False
        
        result = self.api_lib.ref_update(
            obj_type='Project',
            obj_uuid='uuid',
            ref_type='Config',
            ref_uuid='ref-uuid',
            ref_fq_name=[],
            operation='ADD'
        )
        
        self.assertIsNone(result)

    def test_ref_update_passes_domain_and_api_key(self):
        """Test ref_update passes domain_name and api_key."""
        self.mock_api_client.ref_update.return_value = True
        
        self.api_lib.ref_update(
            obj_type='Project',
            obj_uuid='uuid',
            ref_type='Config',
            ref_uuid='ref-uuid',
            ref_fq_name=[],
            operation='ADD',
            domain_name='custom-domain',
            api_key='ak_custom'
        )
        
        call_kwargs = self.mock_api_client.ref_update.call_args[1]
        self.assertEqual(call_kwargs['domain_name'], 'custom-domain')
        self.assertEqual(call_kwargs['api_key'], 'ak_custom')


# ==============================================================================
# Dynamic Method Generation Tests (4 tests) - CORRECTED
# ==============================================================================

class TestApiLibDynamicRefsMethods(unittest.TestCase):
    """Test dynamically generated {type}_get_refs methods."""

    def setUp(self):
        """Set up test fixtures with dynamic methods."""
        with patch('py_api_lib.api_lib.ApiClient') as mock_client_class:
            self.mock_api_client = Mock()
            mock_client_class.return_value = self.mock_api_client
            self.api_lib = ApiLib(api_server_host='localhost', api_server_port='8082')
            
            self.api_lib.object_types = {
                'Project': Mock(), 
                'UserAccount': Mock(), 
                'Tenant': Mock(),
                'GlobalSystemConfig': Mock()
            }
            self.api_lib._create_dynamic_methods()

    def test_dynamic_method_exists_for_each_type(self):
        """Test {type}_get_refs methods are created for all types."""
        self.assertTrue(hasattr(self.api_lib, 'project_get_refs'))
        self.assertTrue(hasattr(self.api_lib, 'user_account_get_refs'))
        self.assertTrue(hasattr(self.api_lib, 'tenant_get_refs'))
        self.assertTrue(hasattr(self.api_lib, 'global_system_config_get_refs'))

    def test_dynamic_method_is_callable(self):
        """Test dynamic methods are callable functions."""
        self.assertTrue(callable(self.api_lib.project_get_refs))
        self.assertTrue(callable(self.api_lib.user_account_get_refs))

    def test_dynamic_method_calls_api_client(self):
        """Test dynamic method calls api_client.get_refs."""
        expected_result = {
            "uuid": "uuid", "obj_type": "project", "fq_name": [],
            "refs": {"user_account": [{"uuid": "u1"}]}, "total_refs": 1
        }
        self.mock_api_client.get_refs.return_value = expected_result
        
        result = self.api_lib.project_get_refs('project-uuid-123')
        
        # Verify api_client.get_refs was called
        self.mock_api_client.get_refs.assert_called()
        
        # Verify result is returned
        self.assertEqual(result, expected_result)

    def test_dynamic_method_snake_case_naming(self):
        """Test multi-word types use snake_case method names."""
        self.assertTrue(hasattr(self.api_lib, 'user_account_get_refs'))
        self.assertTrue(hasattr(self.api_lib, 'global_system_config_get_refs'))


# ==============================================================================
# Edge Cases and Error Handling Tests (7 tests)
# ==============================================================================

class TestRefsEdgeCases(unittest.TestCase):
    """Test edge cases and error handling."""

    def setUp(self):
        """Set up test fixtures."""
        with patch('py_api_lib.api_lib.ApiClient') as mock_client_class:
            self.mock_api_client = Mock()
            mock_client_class.return_value = self.mock_api_client
            self.api_lib = ApiLib(api_server_host='localhost', api_server_port='8082')

    def test_get_refs_handles_null_attr(self):
        """Test get_refs handles null vs empty attr values."""
        self.mock_api_client.get_refs.return_value = {
            "uuid": "uuid", "obj_type": "project", "fq_name": [],
            "refs": {
                "config": [
                    {"uuid": "c1", "fq_name": [], "attr": None},
                    {"uuid": "c2", "fq_name": [], "attr": {}}
                ]
            },
            "total_refs": 2
        }
        
        result = self.api_lib.get_refs('Project', 'uuid')
        
        self.assertIsNone(result['refs']['config'][0]['attr'])
        self.assertEqual(result['refs']['config'][1]['attr'], {})

    def test_get_refs_handles_complex_nested_attr(self):
        """Test get_refs handles complex nested attr objects."""
        self.mock_api_client.get_refs.return_value = {
            "uuid": "uuid", "obj_type": "project", "fq_name": [],
            "refs": {
                "user_account": [{
                    "uuid": "u1", "fq_name": [],
                    "attr": {
                        "role": "admin",
                        "permissions": ["read", "write", "delete"],
                        "metadata": {
                            "granted_at": "2024-01-15T10:00:00Z",
                            "granted_by": {"uuid": "system", "type": "service"}
                        }
                    }
                }]
            },
            "total_refs": 1
        }
        
        result = self.api_lib.get_refs('Project', 'uuid')
        
        attr = result['refs']['user_account'][0]['attr']
        self.assertEqual(attr['role'], 'admin')
        self.assertIsInstance(attr['permissions'], list)
        self.assertEqual(attr['metadata']['granted_by']['type'], 'service')

    def test_get_refs_handles_unicode_in_attr(self):
        """Test get_refs handles unicode characters and emoji in attr."""
        self.mock_api_client.get_refs.return_value = {
            "uuid": "uuid", "obj_type": "project", "fq_name": [],
            "refs": {
                "user_account": [{
                    "uuid": "u1", "fq_name": [],
                    "attr": {
                        "display_name": "日本語ユーザー",
                        "emoji": "🎉"
                    }
                }]
            },
            "total_refs": 1
        }
        
        result = self.api_lib.get_refs('Project', 'uuid')
        
        attr = result['refs']['user_account'][0]['attr']
        self.assertEqual(attr['display_name'], "日本語ユーザー")
        self.assertEqual(attr['emoji'], "🎉")

    def test_get_refs_by_type_all_input_formats(self):
        """Test get_refs_by_type handles PascalCase, snake_case, and kebab-case."""
        self.mock_api_client.get_refs_by_type.return_value = [{"uuid": "u1"}]
        
        self.api_lib.get_refs_by_type('Project', 'uuid', 'UserAccount')
        self.api_lib.get_refs_by_type('project', 'uuid', 'user_account')
        self.api_lib.get_refs_by_type('project', 'uuid', 'user-account')
        
        self.assertEqual(self.mock_api_client.get_refs_by_type.call_count, 3)

    def test_get_refs_handles_large_fq_name(self):
        """Test get_refs handles long fq_name arrays."""
        long_fq_name = ["domain", "project", "tenant", "subtenant", "resource", 
                       "subresource", "item", "subitem", "leaf"]
        
        self.mock_api_client.get_refs.return_value = {
            "uuid": "uuid", "obj_type": "project", 
            "fq_name": long_fq_name,
            "refs": {
                "config": [{"uuid": "c1", "fq_name": long_fq_name + ["config"], "attr": None}]
            },
            "total_refs": 1
        }
        
        result = self.api_lib.get_refs('Project', 'uuid')
        
        self.assertEqual(len(result['fq_name']), 9)
        self.assertEqual(len(result['refs']['config'][0]['fq_name']), 10)

    def test_generic_exception_is_reraised(self):
        """Test generic exceptions are logged and re-raised."""
        self.mock_api_client.get_refs.side_effect = RuntimeError("Unexpected error")
        
        with self.assertRaises(RuntimeError):
            self.api_lib.get_refs('Project', 'uuid')

    def test_get_refs_handles_many_ref_types(self):
        """Test get_refs handles response with many different ref types."""
        self.mock_api_client.get_refs.return_value = {
            "uuid": "uuid", "obj_type": "project", "fq_name": [],
            "refs": {
                "user_account": [{"uuid": "u1", "fq_name": [], "attr": None}],
                "config": [{"uuid": "c1", "fq_name": [], "attr": None}],
                "tenant": [{"uuid": "t1", "fq_name": [], "attr": None}],
                "api_key": [{"uuid": "a1", "fq_name": [], "attr": None}],
                "mcp_backend": [{"uuid": "m1", "fq_name": [], "attr": None}]
            },
            "total_refs": 5
        }
        
        result = self.api_lib.get_refs('Project', 'uuid')
        
        self.assertEqual(result['total_refs'], 5)
        self.assertEqual(len(result['refs']), 5)


# ==============================================================================
# Integration Pattern Tests (6 tests)
# ==============================================================================

class TestRefsIntegrationPatterns(unittest.TestCase):
    """Test common real-world integration patterns."""

    def setUp(self):
        """Set up test fixtures."""
        with patch('py_api_lib.api_lib.ApiClient') as mock_client_class:
            self.mock_api_client = Mock()
            mock_client_class.return_value = self.mock_api_client
            self.api_lib = ApiLib(api_server_host='localhost', api_server_port='8082')

    def test_pattern_grant_user_access(self):
        """Pattern: Grant user access to project with role attr."""
        self.mock_api_client.ref_update.return_value = True
        
        result = self.api_lib.ref_update(
            obj_type='Project',
            obj_uuid='project-123',
            ref_type='UserAccount',
            ref_uuid='user-456',
            ref_fq_name=['domain', 'proj', 'tenant', 'alice@example.com'],
            operation='ADD',
            attr={'role': 'admin', 'granted_at': '2024-01-15T10:00:00Z'}
        )
        
        self.assertIsNotNone(result)
        
        call_kwargs = self.mock_api_client.ref_update.call_args[1]
        self.assertEqual(call_kwargs['operation'], 'ADD')
        self.assertEqual(call_kwargs['attr']['role'], 'admin')

    def test_pattern_revoke_user_access(self):
        """Pattern: Revoke user access from project."""
        self.mock_api_client.ref_update.return_value = True
        
        result = self.api_lib.ref_update(
            obj_type='Project',
            obj_uuid='project-123',
            ref_type='UserAccount',
            ref_uuid='user-456',
            ref_fq_name=['domain', 'proj', 'tenant', 'alice@example.com'],
            operation='DELETE'
        )
        
        self.assertIsNotNone(result)
        
        call_kwargs = self.mock_api_client.ref_update.call_args[1]
        self.assertEqual(call_kwargs['operation'], 'DELETE')

    def test_pattern_list_project_users_and_filter_by_role(self):
        """Pattern: List all users with access and filter by role."""
        self.mock_api_client.get_refs_by_type.return_value = [
            {"uuid": "u1", "fq_name": ["d", "p", "t", "alice"], "attr": {"role": "admin"}},
            {"uuid": "u2", "fq_name": ["d", "p", "t", "bob"], "attr": {"role": "viewer"}},
            {"uuid": "u3", "fq_name": ["d", "p", "t", "carol"], "attr": {"role": "viewer"}}
        ]
        
        users = self.api_lib.get_refs_by_type('Project', 'project-123', 'UserAccount')
        
        self.assertEqual(len(users), 3)
        
        admins = [u for u in users if u['attr']['role'] == 'admin']
        viewers = [u for u in users if u['attr']['role'] == 'viewer']
        
        self.assertEqual(len(admins), 1)
        self.assertEqual(len(viewers), 2)

    def test_pattern_find_user_projects_via_back_refs(self):
        """Pattern: Find all projects a user has access to (via back-refs)."""
        self.mock_api_client.get_back_refs_by_type.return_value = [
            {"uuid": "p1", "fq_name": ["d", "project-a"], "attr": {"role": "admin"}},
            {"uuid": "p2", "fq_name": ["d", "project-b"], "attr": {"role": "viewer"}}
        ]
        
        projects = self.api_lib.get_back_refs_by_type('UserAccount', 'user-123', 'Project')
        
        self.assertEqual(len(projects), 2)

    def test_pattern_batch_add_users(self):
        """Pattern: Batch add multiple users to a project."""
        self.mock_api_client.ref_update_multi.return_value = True
        
        users_to_add = [
            ('user-1', ['d', 'p', 't', 'alice'], {'role': 'admin'}),
            ('user-2', ['d', 'p', 't', 'bob'], {'role': 'viewer'}),
            ('user-3', ['d', 'p', 't', 'carol'], {'role': 'viewer'})
        ]
        
        ref_updates = [
            {
                "type": "project",
                "uuid": "project-123",
                "ref-type": "user-account",
                "ref-uuid": user_uuid,
                "ref-fq-name": fq_name,
                "operation": "ADD",
                "attr": attr
            }
            for user_uuid, fq_name, attr in users_to_add
        ]
        
        result = self.api_lib.api_client.ref_update_multi(ref_updates)
        
        self.assertTrue(result)
        
        call_args = self.mock_api_client.ref_update_multi.call_args
        self.assertEqual(len(call_args[0][0]), 3)

    def test_pattern_change_user_role(self):
        """Pattern: Change user role (delete old ref, add new with different attr)."""
        self.mock_api_client.ref_update.return_value = True
        
        # Step 1: Delete existing ref
        self.api_lib.ref_update(
            obj_type='Project',
            obj_uuid='project-123',
            ref_type='UserAccount',
            ref_uuid='user-456',
            ref_fq_name=['d', 'p', 't', 'alice'],
            operation='DELETE'
        )
        
        # Step 2: Add new ref with updated role
        self.api_lib.ref_update(
            obj_type='Project',
            obj_uuid='project-123',
            ref_type='UserAccount',
            ref_uuid='user-456',
            ref_fq_name=['d', 'p', 't', 'alice'],
            operation='ADD',
            attr={'role': 'admin'}
        )
        
        self.assertEqual(self.mock_api_client.ref_update.call_count, 2)
        
        first_call = self.mock_api_client.ref_update.call_args_list[0]
        self.assertEqual(first_call[1]['operation'], 'DELETE')
        
        second_call = self.mock_api_client.ref_update.call_args_list[1]
        self.assertEqual(second_call[1]['operation'], 'ADD')
        self.assertEqual(second_call[1]['attr']['role'], 'admin')


# ==============================================================================
# Test Suite Summary
# ==============================================================================

if __name__ == '__main__':
    unittest.main(verbosity=2)
