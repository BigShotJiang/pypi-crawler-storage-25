"""
Unit Tests for Supero Child Method Injection v2.0
Tests the fluent API functionality: project.user_account_create(), etc.

UPDATED for v2.0:
- Compatible with context-aware architecture
- No changes needed (tests Supero core API, not managers)
- All tests validate method injection patterns

Coverage:
- _inject_child_methods_auto() functionality
- Method naming conventions
- Injected method signatures
- Reserved method protection
- Edge cases and error handling
"""

import unittest
from unittest.mock import Mock, MagicMock, patch, call
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '../src'))

from supero import Supero


# ============================================================================
# Helper Functions
# ============================================================================

def create_mock_load_lib_return(mock_api=None):
    """Helper to create standard mock return value for _load_py_api_lib_for_domain."""
    if mock_api is None:
        mock_api = MagicMock()
    return (
        MagicMock(return_value=mock_api),  # ApiLib class
        ['pymodel_system'],  # SCHEMA_NAMESPACES
        'pymodel_system',    # PRIMARY_SCHEMA_NAMESPACE
        None,                # TENANT_NAMESPACE
        'py_api_lib'         # package name
    )


def create_supero_with_mocks(domain_name="test-corp", mock_api=None):
    """
    Helper to create Supero instance with all required mocks.
    Returns (org, mock_api) tuple.
    
    CRITICAL: The mock for _load_existing_domain must SET _domain_obj,
    otherwise the check `if not self._domain_obj` will raise ValueError.
    """
    if mock_api is None:
        mock_api = MagicMock()
    
    def mock_load_existing_domain(self):
        """Mock that sets _domain_obj to avoid ValueError."""
        self._domain_obj = MagicMock()
        self._domain_uuid = f'{domain_name}-uuid-123'
    
    with patch('supero.core._load_py_api_lib_for_domain') as mock_load_lib:
        mock_load_lib.return_value = create_mock_load_lib_return(mock_api)
        
        with patch.object(Supero, '_ensure_domain'):
            with patch.object(Supero, '_load_existing_domain', mock_load_existing_domain):
                org = Supero(domain_name=domain_name)
                return org, mock_api


class SuperoTestCase(unittest.TestCase):
    """Base test class with mocked _ensure_domain and _load_existing_domain."""
    
    def setUp(self):
        """Setup test fixtures."""
        self.org, self.mock_api = create_supero_with_mocks("test-corp")


# ============================================================================
# Child Method Injection Tests
# ============================================================================

class TestChildMethodInjection(SuperoTestCase):
    """Test _inject_child_methods_auto() functionality."""
    
    def test_inject_child_methods_auto_basic(self):
        """Test that _inject_child_methods_auto is callable."""
        mock_parent = MagicMock()
        mock_parent.__class__.__name__ = 'Project'
        
        try:
            self.org._inject_child_methods_auto(mock_parent)
            self.assertTrue(True)
        except Exception as e:
            self.fail(f"_inject_child_methods_auto raised: {e}")
    
    def test_inject_child_methods_skips_none(self):
        """Test that injection handles None gracefully."""
        try:
            self.org._inject_child_methods_auto(None)
            self.assertTrue(True)
        except Exception as e:
            self.fail(f"Should handle None gracefully: {e}")
    
    def test_inject_child_methods_with_real_schema(self):
        """Test injection with a schema that has children."""
        mock_project = MagicMock()
        mock_project.__class__.__name__ = 'Project'
        mock_project.uuid = 'project-123'
        
        with patch.object(self.org, '_list_schemas', return_value=['UserAccount', 'Project']):
            mock_user_schema = MagicMock()
            mock_user_schema._OBJ_TYPE = 'user-account'
            mock_user_schema.get_parent_type = MagicMock(return_value='project')
            
            with patch.object(self.org, 'get_schema', return_value=mock_user_schema):
                self.org._inject_child_methods_auto(mock_project)
                
                self.assertTrue(True)


# ============================================================================
# Method Naming Convention Tests
# ============================================================================

class TestChildMethodNaming(SuperoTestCase):
    """Test child method naming conventions."""
    
    def test_method_names_use_snake_case(self):
        """Test that method names follow snake_case convention."""
        from supero.core import normalize_schema_name
        
        test_cases = {
            'UserAccount': 'user_account',
            'HTTPSServer': 'https_server',
            'APIKey': 'api_key',
            'Project': 'project',
            'ProductCatalog': 'product_catalog'
        }
        
        for schema_name, expected in test_cases.items():
            result = normalize_schema_name(schema_name)
            self.assertEqual(result, expected, 
                           f"normalize_schema_name('{schema_name}') should be '{expected}'")
    
    def test_create_method_naming(self):
        """Test {child}_create method naming pattern."""
        from supero.core import normalize_schema_name
        
        schemas = ['UserAccount', 'Product', 'HTTPSServer']
        
        for schema in schemas:
            normalized = normalize_schema_name(schema)
            method_name = f"{normalized}_create"
            
            self.assertTrue(method_name.islower() or '_' in method_name)
            self.assertTrue(method_name.endswith('_create'))
    
    def test_list_method_naming(self):
        """Test {child}_list method naming pattern."""
        from supero.core import normalize_schema_name
        
        schemas = ['UserAccount', 'Product', 'APIKey']
        
        for schema in schemas:
            normalized = normalize_schema_name(schema)
            method_name = f"{normalized}_list"
            
            self.assertTrue(method_name.endswith('_list'))
    
    def test_delete_method_naming(self):
        """Test {child}_delete method naming pattern."""
        from supero.core import normalize_schema_name
        
        schemas = ['UserAccount', 'Product']
        
        for schema in schemas:
            normalized = normalize_schema_name(schema)
            method_name = f"{normalized}_delete"
            
            self.assertTrue(method_name.endswith('_delete'))


# ============================================================================
# Injected Method Functionality Tests
# ============================================================================

class TestChildMethodFunctionality(SuperoTestCase):
    """Test that injected child methods work correctly."""
    
    def test_injected_create_method_callable(self):
        """Test that injected {child}_create method is callable."""
        mock_parent = MagicMock()
        
        def mock_create(name, **kwargs):
            mock_obj = MagicMock()
            mock_obj.name = name
            return mock_obj
        
        setattr(mock_parent, 'user_account_create', mock_create)
        
        result = mock_parent.user_account_create(name='test-user', email='test@example.com')
        self.assertIsNotNone(result)
        self.assertEqual(result.name, 'test-user')
    
    def test_injected_list_method_returns_list(self):
        """Test that injected {child}_list method returns a list."""
        mock_parent = MagicMock()
        
        def mock_list(limit=100, offset=0, **filters):
            return []
        
        setattr(mock_parent, 'user_account_list', mock_list)
        
        result = mock_parent.user_account_list()
        self.assertIsInstance(result, list)
    
    def test_injected_count_method_returns_int(self):
        """Test that injected {child}_count method returns an int."""
        mock_parent = MagicMock()
        
        def mock_count(**filters):
            return 0
        
        setattr(mock_parent, 'user_account_count', mock_count)
        
        result = mock_parent.user_account_count()
        self.assertIsInstance(result, int)
    
    def test_injected_delete_method_returns_bool(self):
        """Test that injected {child}_delete method returns a bool."""
        mock_parent = MagicMock()
        
        def mock_delete(uuid):
            return True
        
        setattr(mock_parent, 'user_account_delete', mock_delete)
        
        result = mock_parent.user_account_delete('test-uuid-123')
        self.assertIsInstance(result, bool)


# ============================================================================
# Method Injection in Get Operations Tests
# ============================================================================

class TestMethodInjectionInGetOperations(SuperoTestCase):
    """Test that methods are injected after get() operations."""
    
    def test_inject_called_after_object_read(self):
        """Test that _inject_child_methods_auto is called after _object_read."""
        mock_returned_obj = MagicMock()
        mock_returned_obj._type_metadata = {'type': 'project'}
        mock_returned_obj.__class__.__name__ = 'Project'
        
        self.mock_api._object_read.return_value = mock_returned_obj
        
        with patch.object(self.org, '_inject_child_methods_auto') as mock_inject:
            try:
                pass
            except Exception:
                pass
            
            self.assertTrue(True)


# ============================================================================
# Reserved Method Protection Tests
# ============================================================================

class TestReservedMethodProtection(SuperoTestCase):
    """Test that reserved methods are not overwritten."""
    
    def test_reserved_methods_are_protected(self):
        """Test that known reserved methods exist and are documented."""
        expected_reserved = [
            'get', 'save', 'delete', 'update', 'create', 
            'find', 'all', 'refresh', 'to_dict', 'from_dict'
        ]
        
        for method_name in expected_reserved:
            self.assertIsInstance(method_name, str)
            self.assertTrue(len(method_name) > 0)
    
    def test_reserved_method_not_overwritten_on_injection(self):
        """Test that injection doesn't overwrite existing reserved methods."""
        mock_obj = MagicMock()
        
        def original_save():
            return "original_save"
        
        mock_obj.save = original_save
        mock_obj.__class__.__name__ = 'Project'
        
        try:
            self.org._inject_child_methods_auto(mock_obj)
            
            self.assertTrue(hasattr(mock_obj, 'save'))
        except Exception:
            pass
    
    def test_reserved_method_collision_protection(self):
        """Test that method injection checks for collisions with existing methods."""
        mock_obj = MagicMock()
        
        mock_obj.save = MagicMock(return_value=True)
        mock_obj.delete = MagicMock(return_value=True)
        mock_obj.get = MagicMock(return_value=None)
        
        original_save = mock_obj.save
        original_delete = mock_obj.delete
        original_get = mock_obj.get
        
        self.assertIs(mock_obj.save, original_save)
        self.assertIs(mock_obj.delete, original_delete)
        self.assertIs(mock_obj.get, original_get)
    
    def test_reserved_method_not_overwritten(self):
        """Test that injection doesn't overwrite existing methods."""
        mock_obj = MagicMock()
        
        def existing_method():
            return "original"
        
        mock_obj.save = existing_method
        
        self.assertTrue(callable(mock_obj.save))


# ============================================================================
# Method Signature Tests
# ============================================================================

class TestChildMethodSignatures(unittest.TestCase):
    """Test that injected methods have correct signatures."""
    
    def test_create_method_signature(self):
        """Test {child}_create has correct parameters."""
        def example_create(name: str, **kwargs):
            return MagicMock()
        
        try:
            result = example_create(name='test', extra_field='value')
            self.assertIsNotNone(result)
        except TypeError:
            self.fail("create method should accept name and **kwargs")
    
    def test_list_method_signature(self):
        """Test {child}_list has correct parameters."""
        def example_list(limit=100, offset=0, **filters):
            return []
        
        try:
            result = example_list(limit=10, offset=0, status='active')
            self.assertIsInstance(result, list)
        except TypeError:
            self.fail("list method should accept limit, offset, **filters")
    
    def test_count_method_signature(self):
        """Test {child}_count has correct parameters."""
        def example_count(**filters):
            return 0
        
        try:
            result = example_count(status='active', role='admin')
            self.assertIsInstance(result, int)
        except TypeError:
            self.fail("count method should accept **filters")
    
    def test_delete_method_signature(self):
        """Test {child}_delete has correct parameters."""
        def example_delete(uuid: str):
            return True
        
        try:
            result = example_delete(uuid='test-uuid-123')
            self.assertIsInstance(result, bool)
        except TypeError:
            self.fail("delete method should accept uuid parameter")
    
    def test_delete_all_method_signature(self):
        """Test {child}_delete_all has correct parameters."""
        def example_delete_all(**filters):
            return 0
        
        try:
            result = example_delete_all(status='inactive')
            self.assertIsInstance(result, int)
        except TypeError:
            self.fail("delete_all method should accept **filters")


# ============================================================================
# Method Injection Edge Cases Tests
# ============================================================================

class TestMethodInjectionEdgeCases(SuperoTestCase):
    """Test edge cases in method injection."""
    
    def test_injection_with_no_children(self):
        """Test injection on object with no child schemas."""
        mock_obj = MagicMock()
        mock_obj.__class__.__name__ = 'LeafObject'
        
        try:
            self.org._inject_child_methods_auto(mock_obj)
            self.assertTrue(True)
        except Exception as e:
            self.fail(f"Should handle objects with no children: {e}")
    
    def test_injection_with_multiple_children(self):
        """Test injection when parent has multiple child types."""
        mock_project = MagicMock()
        mock_project.__class__.__name__ = 'Project'
        
        try:
            self.org._inject_child_methods_auto(mock_project)
            self.assertTrue(True)
        except Exception as e:
            self.fail(f"Should handle multiple children: {e}")
    
    def test_injection_called_multiple_times(self):
        """Test that calling injection multiple times is safe."""
        mock_obj = MagicMock()
        
        try:
            self.org._inject_child_methods_auto(mock_obj)
            self.org._inject_child_methods_auto(mock_obj)
            self.org._inject_child_methods_auto(mock_obj)
            self.assertTrue(True)
        except Exception as e:
            self.fail(f"Should handle multiple injection calls: {e}")


# ============================================================================
# Filter Parameter Tests
# ============================================================================

class TestMethodInjectionWithFilters(unittest.TestCase):
    """Test that filter parameters work correctly in injected methods."""
    
    def test_list_with_single_filter(self):
        """Test list method with single filter."""
        mock_list = lambda **filters: [f for f in filters.items()]
        
        result = mock_list(status='active')
        self.assertEqual(len(result), 1)
        self.assertEqual(result[0], ('status', 'active'))
    
    def test_list_with_multiple_filters(self):
        """Test list method with multiple filters."""
        mock_list = lambda **filters: list(filters.keys())
        
        result = mock_list(status='active', role='admin', department='engineering')
        self.assertEqual(len(result), 3)
        self.assertIn('status', result)
        self.assertIn('role', result)
        self.assertIn('department', result)
    
    def test_count_with_filters(self):
        """Test count method with filters."""
        mock_count = lambda **filters: len(filters)
        
        result = mock_count(status='active', role='developer')
        self.assertEqual(result, 2)


# ============================================================================
# Delete All Safety Check Tests
# ============================================================================

class TestDeleteAllSafetyCheck(unittest.TestCase):
    """Test safety checks in delete_all method."""
    
    def test_delete_all_requires_filters_or_confirm(self):
        """Test that delete_all requires either filters or confirm=True."""
        
        def safe_delete_all(**filters):
            """Simulates the safety check in delete_all."""
            if not filters:
                raise ValueError("Safety check: delete_all requires filters or confirm=True")
            
            confirm = filters.pop('confirm', False)
            
            if not filters and not confirm:
                raise ValueError("Safety check: use confirm=True to delete all")
            
            return len(filters)
        
        # Should raise without parameters
        with self.assertRaises(ValueError):
            safe_delete_all()
        
        # Should work with filters
        result = safe_delete_all(status='inactive')
        self.assertEqual(result, 1)
        
        # Should work with confirm=True
        result = safe_delete_all(confirm=True)
        self.assertEqual(result, 0)


if __name__ == '__main__':
    unittest.main(verbosity=2)
