"""
test_cli_helpers.py — Unit tests for supero.cli helper functions

Location: ~/supero/platform/infra/libs/py/test/test_cli_helpers.py

Run:
    python -m pytest test_cli_helpers.py -v
    python -m unittest test_cli_helpers -v

Coverage:
    - _make_slug: unicode normalization, length capping, empty input, edge cases
    - _safe_write: success path, PermissionError, OSError, disk full simulation
    - Template rendering: README, Dockerfile, compose all .format() cleanly
    - CLAUDE.md: no placeholders, byte-stable content
    - Placeholder consistency: all 4 templates accept expected kwargs
"""

import io
import os
import stat
import sys
import tempfile
import unittest
from unittest.mock import patch, MagicMock


# ---------------------------------------------------------------------------
# Import the functions under test.
#
# _make_slug and _safe_write live in supero.cli.run — we import them directly.
# The template constants come from dedicated modules.
# ---------------------------------------------------------------------------

def _get_run_module():
    """Return the supero.cli.run MODULE (avoids package attribute shadowing)."""
    import importlib
    return importlib.import_module('supero.cli.run')


# ---------------------------------------------------------------------------
# _make_slug tests
# ---------------------------------------------------------------------------

class TestMakeSlugBasic(unittest.TestCase):
    """Tests for basic _make_slug() behavior on common inputs."""

    def setUp(self):
        self._make_slug = _get_run_module()._make_slug

    def test_simple_name(self):
        """A simple name becomes lowercase-with-dashes."""
        self.assertEqual(self._make_slug("Food Truck"), "food-truck")

    def test_single_word(self):
        """A single word is just lowercased."""
        self.assertEqual(self._make_slug("Platform"), "platform")

    def test_already_slug(self):
        """An already-valid slug passes through unchanged."""
        self.assertEqual(self._make_slug("food-truck-platform"), "food-truck-platform")

    def test_mixed_case(self):
        """Mixed-case input is normalized to lowercase."""
        self.assertEqual(self._make_slug("FoodTruck"), "foodtruck")

    def test_spaces_become_dashes(self):
        """Multiple spaces collapse to single dashes."""
        self.assertEqual(self._make_slug("A   B   C"), "a-b-c")

    def test_underscores_become_dashes(self):
        """Underscores convert to dashes (Docker doesn't allow _ in image names)."""
        self.assertEqual(self._make_slug("food_truck_app"), "food-truck-app")


class TestMakeSlugUnicode(unittest.TestCase):
    """Tests for NFKD unicode normalization (Fix A from the 5-pass review)."""

    def setUp(self):
        self._make_slug = _get_run_module()._make_slug

    def test_german_umlaut(self):
        """Über becomes 'uber' after NFKD decomposition."""
        self.assertEqual(self._make_slug("Über"), "uber")

    def test_french_accent(self):
        """Café becomes 'cafe'."""
        self.assertEqual(self._make_slug("Café"), "cafe")

    def test_combined_unicode_phrase(self):
        """Über Café Management → uber-cafe-management."""
        self.assertEqual(self._make_slug("Über Café Management"), "uber-cafe-management")

    def test_spanish_accent(self):
        """Déjà Vu → deja-vu."""
        self.assertEqual(self._make_slug("Déjà Vu"), "deja-vu")

    def test_naive_resume(self):
        """Naïve Résumé Builder → naive-resume-builder."""
        self.assertEqual(self._make_slug("Naïve Résumé Builder"), "naive-resume-builder")

    def test_multiple_diacritics(self):
        """München Store → munchen-store."""
        self.assertEqual(self._make_slug("München Store"), "munchen-store")

    def test_cjk_characters_stripped(self):
        """CJK characters have no ASCII equivalent; surviving parts remain."""
        # "北京 App" — CJK chars get stripped, "App" survives
        self.assertEqual(self._make_slug("北京 App"), "app")

    def test_emoji_stripped(self):
        """Emoji are removed entirely, leaving only the ASCII text."""
        self.assertEqual(self._make_slug("🚀 Rocket App"), "rocket-app")


class TestMakeSlugEdgeCases(unittest.TestCase):
    """Tests for edge cases: empty strings, whitespace, special characters."""

    def setUp(self):
        self._make_slug = _get_run_module()._make_slug

    def test_empty_string(self):
        """Empty string falls back to 'supero-app'."""
        self.assertEqual(self._make_slug(""), "supero-app")

    def test_none_input(self):
        """None input falls back to 'supero-app'."""
        self.assertEqual(self._make_slug(None), "supero-app")

    def test_whitespace_only(self):
        """Whitespace-only input falls back to 'supero-app'."""
        self.assertEqual(self._make_slug("   "), "supero-app")

    def test_punctuation_only(self):
        """Punctuation-only input (no alphanumerics) falls back."""
        self.assertEqual(self._make_slug("---"), "supero-app")
        self.assertEqual(self._make_slug("!!!"), "supero-app")
        self.assertEqual(self._make_slug("___"), "supero-app")

    def test_single_character(self):
        """Single character is preserved."""
        self.assertEqual(self._make_slug("a"), "a")

    def test_currency_symbols_stripped(self):
        """Currency symbols are stripped (no ASCII equivalent)."""
        self.assertEqual(self._make_slug("The £100 Store"), "the-100-store")

    def test_apostrophe_becomes_dash(self):
        """Apostrophes are treated as separators (become dashes), preserving info."""
        # Note: the regex [^a-z0-9]+ converts any non-alphanumeric run to a
        # single dash, so "Amazon's Store" becomes "amazon-s-store" (not
        # "amazons-store"). This preserves the fact that 's' was originally
        # attached to "Amazon", which is the conservative choice.
        self.assertEqual(self._make_slug("Amazon's Store"), "amazon-s-store")

    def test_plus_sign_stripped(self):
        """C++ becomes 'c' (+ stripped, only letter remains)."""
        self.assertEqual(self._make_slug("C++"), "c")

    def test_percent_sign_stripped(self):
        """50% Off → 50-off."""
        self.assertEqual(self._make_slug("50% Off Deals"), "50-off-deals")

    def test_leading_trailing_spaces(self):
        """Leading/trailing whitespace is stripped."""
        self.assertEqual(self._make_slug("  Hello World  "), "hello-world")

    def test_leading_trailing_dashes(self):
        """Leading/trailing dashes are stripped from result."""
        self.assertEqual(self._make_slug("-hello-"), "hello")
        self.assertEqual(self._make_slug("!!!Hello!!!"), "hello")


class TestMakeSlugLengthCap(unittest.TestCase):
    """Tests for the 40-char length cap (Fix B from the 5-pass review)."""

    def setUp(self):
        self._make_slug = _get_run_module()._make_slug

    def test_cap_at_default_40(self):
        """Default cap is 40 characters."""
        result = self._make_slug("A" * 100)
        self.assertEqual(len(result), 40)
        self.assertEqual(result, "a" * 40)

    def test_cap_custom_length(self):
        """Custom max_length parameter is respected."""
        result = self._make_slug("A" * 100, max_length=20)
        self.assertEqual(len(result), 20)

    def test_cap_strips_trailing_dash(self):
        """When cap lands on a dash, trailing dash is stripped."""
        # Craft input so that char 40 is a dash
        name = "a" * 39 + "-" + "b" * 20  # length 60, char 40 is '-'
        result = self._make_slug(name)
        # Result should be 39 chars (not 40 with trailing dash)
        self.assertFalse(result.endswith('-'), f"Got: {result!r}")
        self.assertLessEqual(len(result), 40)

    def test_long_realistic_name(self):
        """Realistic long name is capped and still readable."""
        name = "The Best Food Truck Management and Ordering Platform for Modern Businesses"
        result = self._make_slug(name)
        self.assertLessEqual(len(result), 40)
        self.assertTrue(result.startswith("the-best-food-truck"))
        self.assertFalse(result.endswith('-'))

    def test_short_name_not_capped(self):
        """Short names are returned unchanged by length logic."""
        result = self._make_slug("short-name")
        self.assertEqual(result, "short-name")

    def test_dash_heavy_name_cap(self):
        """A dash-heavy name is capped without trailing dash."""
        result = self._make_slug("a-b-c-d-e-f-g-h-i-j-k-l-m-n-o-p-q-r-s-t-u-v-w-x-y-z")
        self.assertLessEqual(len(result), 40)
        self.assertFalse(result.endswith('-'))


class TestMakeSlugDockerCompatibility(unittest.TestCase):
    """Tests that verify output is valid as a Docker image/container name.

    Docker naming rules:
      - Lowercase only
      - Alphanumeric + dashes
      - Must start with alphanumeric
      - Must end with alphanumeric
      - Max 255 chars (our 40 cap is well within)
    """

    def setUp(self):
        self._make_slug = _get_run_module()._make_slug

    def _is_valid_docker_name(self, name: str) -> bool:
        """Check Docker naming rules."""
        if not name:
            return False
        if not name[0].isalnum():
            return False
        if not name[-1].isalnum():
            return False
        for c in name:
            if not (c.isalnum() or c == '-') or c.isupper():
                return False
        return True

    def test_output_always_valid_docker_name(self):
        """Every test input produces a valid Docker name."""
        test_cases = [
            "Food Truck Management Platform",
            "Über Café",
            "50% Off Deals",
            "Amazon's Store",
            "",
            "   ",
            "---",
            "C++",
            "🚀 Rocket",
            "a" * 100,
            "The £100 Store",
            "北京 App",
        ]
        for name in test_cases:
            with self.subTest(name=name):
                slug = self._make_slug(name)
                self.assertTrue(
                    self._is_valid_docker_name(slug),
                    f"Slug {slug!r} from {name!r} is not a valid Docker name"
                )


# ---------------------------------------------------------------------------
# _safe_write tests
# ---------------------------------------------------------------------------

class TestSafeWriteSuccess(unittest.TestCase):
    """Tests for _safe_write() happy path."""

    def setUp(self):
        self._safe_write = _get_run_module()._safe_write
        self.tmpdir = tempfile.mkdtemp(prefix="supero-safe-write-test-")

    def tearDown(self):
        import shutil
        # Make sure we can remove the temp dir even if test changed permissions
        try:
            os.chmod(self.tmpdir, stat.S_IRWXU)
        except Exception:
            pass
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_writes_content_to_new_file(self):
        """Writing to a new file succeeds and content matches."""
        path = os.path.join(self.tmpdir, "new.txt")
        result = self._safe_write(path, "hello world", "test.txt")
        self.assertTrue(result)
        with open(path) as f:
            self.assertEqual(f.read(), "hello world")

    def test_overwrites_existing_file(self):
        """Writing to an existing file replaces its content."""
        path = os.path.join(self.tmpdir, "existing.txt")
        with open(path, "w") as f:
            f.write("old content")
        result = self._safe_write(path, "new content", "existing.txt")
        self.assertTrue(result)
        with open(path) as f:
            self.assertEqual(f.read(), "new content")

    def test_returns_true_on_success(self):
        """Successful write returns True."""
        path = os.path.join(self.tmpdir, "return.txt")
        self.assertTrue(self._safe_write(path, "data", "return.txt"))

    def test_unicode_content_written_correctly(self):
        """Unicode content is preserved in the file."""
        path = os.path.join(self.tmpdir, "unicode.txt")
        content = "Über Café 北京 🚀"
        result = self._safe_write(path, content, "unicode.txt")
        self.assertTrue(result)
        with open(path, encoding="utf-8") as f:
            self.assertEqual(f.read(), content)


class TestSafeWriteErrors(unittest.TestCase):
    """Tests for _safe_write() error paths (Fix D from the 5-pass review)."""

    def setUp(self):
        self._safe_write = _get_run_module()._safe_write

    def test_permission_error_returns_false(self):
        """PermissionError returns False, does not raise."""
        with patch("builtins.open", side_effect=PermissionError("denied")):
            result = self._safe_write("/fake/path.txt", "data", "test.txt")
            self.assertFalse(result)

    def test_permission_error_prints_warning(self):
        """PermissionError prints a warning message to stdout."""
        buf = io.StringIO()
        old_stdout = sys.stdout
        sys.stdout = buf
        try:
            with patch("builtins.open", side_effect=PermissionError("denied")):
                self._safe_write("/fake/path.txt", "data", "test.txt")
        finally:
            sys.stdout = old_stdout
        output = buf.getvalue()
        self.assertIn("test.txt", output)
        self.assertTrue(
            "permission" in output.lower() or "denied" in output.lower(),
            f"Expected permission warning, got: {output!r}"
        )

    def test_os_error_returns_false(self):
        """OSError (disk full, etc.) returns False."""
        with patch("builtins.open", side_effect=OSError("disk full")):
            result = self._safe_write("/fake/path.txt", "data", "test.txt")
            self.assertFalse(result)

    def test_os_error_prints_warning(self):
        """OSError prints a warning with the error message."""
        buf = io.StringIO()
        old_stdout = sys.stdout
        sys.stdout = buf
        try:
            with patch("builtins.open", side_effect=OSError("disk full")):
                self._safe_write("/fake/path.txt", "data", "test.txt")
        finally:
            sys.stdout = old_stdout
        output = buf.getvalue()
        self.assertIn("disk full", output)

    def test_does_not_raise_on_any_error(self):
        """_safe_write never raises — always returns True/False."""
        errors = [
            PermissionError("denied"),
            OSError("disk full"),
            FileNotFoundError("no dir"),   # subclass of OSError
            IsADirectoryError("is dir"),    # subclass of OSError
        ]
        for err in errors:
            with self.subTest(error=type(err).__name__):
                with patch("builtins.open", side_effect=err):
                    try:
                        result = self._safe_write("/fake.txt", "data", "test.txt")
                        self.assertFalse(result)
                    except Exception as e:
                        self.fail(f"_safe_write raised {type(e).__name__}: {e}")


# ---------------------------------------------------------------------------
# Template rendering tests
# ---------------------------------------------------------------------------

# Standard values used to render each template
STANDARD_SAMPLE = {
    'APP_NAME':       'Food Truck Management Platform',
    'APP_SLUG':       'food-truck-management-platform',
    'DOMAIN':         's1_corp',
    'PROJECT':        'default-project',
    'TENANT':         'default-tenant',
    'ADMIN_EMAIL':    'admin@s1-corp.com',
    'PORT':           '5648',
    'SDK_VERSION':    '1.5.16',
    'GENERATED_DATE': '2026-04-05',
}












# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    unittest.main(verbosity=2)
