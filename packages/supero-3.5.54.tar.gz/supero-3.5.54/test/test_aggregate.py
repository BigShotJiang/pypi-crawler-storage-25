# test_aggregate.py
"""
Unit tests for aggregate operations in py_api_lib.
Tests get_stats, aggregate, get_distinct, and get_count_by methods.

COMPREHENSIVE COVERAGE:
- Basic operations (success paths)
- Error handling (specific exceptions)
- Edge cases (field types, limits, filters)
- Boundary conditions (min/max values)
- Parameter validation
- Integration workflows
"""

import sys
import os
import unittest
import json
from pathlib import Path
from unittest.mock import patch, call, MagicMock, Mock

# Setup paths
test_dir = Path(__file__).parent
project_root = test_dir.parent
src_dir = project_root / "src"
utils_dir = project_root / ".." / ".." / ".." / "utils"

for path in [str(src_dir), str(project_root), str(utils_dir)]:
    if path not in sys.path:
        sys.path.insert(0, path)

# Set test environment
os.environ["TESTING"] = "true"

def setup_test_mocks():
    """Setup mocks for missing dependencies."""
    try:
        import pymodel
        import pymodel.objects
        import pymodel.serialization_errors
    except ImportError:
        pymodel_mock = MagicMock()
        pymodel_objects_mock = MagicMock()
        pymodel_serialization_mock = MagicMock()

        # Mock functions
        pymodel_serialization_mock.safe_serialize_to_dict = lambda obj, obj_type=None: {}
        pymodel_serialization_mock.safe_serialize_to_json = lambda obj, obj_type=None: '{}'
        pymodel_serialization_mock.safe_deserialize_from_dict = lambda data, cls, obj_type=None: MagicMock()

        # Create custom exception classes
        class SerializationError(Exception):
            pass
        class ObjectSerializationError(SerializationError):
            pass
        class ObjectDeserializationError(SerializationError):
            pass
        class JSONSerializationError(SerializationError):
            pass
        class JSONDeserializationError(SerializationError):
            pass

        pymodel_serialization_mock.SerializationError = SerializationError
        pymodel_serialization_mock.ObjectSerializationError = ObjectSerializationError
        pymodel_serialization_mock.ObjectDeserializationError = ObjectDeserializationError
        pymodel_serialization_mock.JSONSerializationError = JSONSerializationError
        pymodel_serialization_mock.JSONDeserializationError = JSONDeserializationError

        pymodel_mock.objects = pymodel_objects_mock
        pymodel_mock.serialization_errors = pymodel_serialization_mock

        sys.modules['pymodel'] = pymodel_mock
        sys.modules['pymodel.objects'] = pymodel_objects_mock
        sys.modules['pymodel.serialization_errors'] = pymodel_serialization_mock

    # Mock api_logger if not available
    try:
        from py_api_lib import api_logger
        api_logger.initialize_logger("test-py-api-lib")
    except ImportError:
        api_logger_mock = MagicMock()
        sys.modules['py_api_lib.api_logger'] = api_logger_mock

# Apply mocks
setup_test_mocks()

# Import after mocking
from py_api_lib.api_lib import ApiLib
from py_api_lib.api_client import ApiClient
from pymodel.serialization_errors import JSONDeserializationError, SerializationError


class TestApiClientGetStats(unittest.TestCase):
    """Test ApiClient get_stats methods."""
    
    def setUp(self):
        """Set up test fixtures."""
        with patch('py_api_lib.api_client.requests.Session'):
            self.client = ApiClient(server_ip='localhost', port=8082)
            self.client.session = Mock()
            # Ensure _default_domain is set
            self.client._default_domain = 'default-domain'

    def test_http_get_stats_success(self):
        """Test successful HTTP get stats operation."""
        # Mock response
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "stats": {
                "amount": {"count": 100, "sum": 50000, "avg": 500, "min": 10, "max": 2000},
                "quantity": {"count": 100, "sum": 1500, "avg": 15, "min": 1, "max": 50}
            }
        }
        
        self.client._make_request = Mock(return_value=mock_response)
        
        # Call get_stats
        result = self.client._http_get_stats(
            'order',
            fields=['amount', 'quantity'],
            match={'status': 'completed'}
        )
        
        # Verify result structure
        self.assertIsNotNone(result, "Result should not be None")
        self.assertIn('stats', result, "Result should contain 'stats' key")
        self.assertEqual(result['stats']['amount']['count'], 100, 
                        "Amount count should be 100")
        self.assertEqual(result['stats']['amount']['avg'], 500,
                        "Amount average should be 500")
        
        # Verify request was made correctly
        self.client._make_request.assert_called_once()
        call_args = self.client._make_request.call_args
        
        # Verify HTTP method
        self.assertEqual(call_args[0][0], 'GET', "Should use GET method")
        
        # Verify endpoint
        expected_endpoint = f"{self.client.base_url}/default-domain/order/stats"
        self.assertEqual(call_args[0][1], expected_endpoint,
                        f"Endpoint should be {expected_endpoint}")
        
        # Verify API key
        self.assertEqual(call_args[1]['api_key'], None, "API key should be None by default")
        
        # Verify query params
        params = call_args[1]['params']
        self.assertIsNotNone(params, "Params should not be None")
        self.assertEqual(params['fields'], 'amount,quantity',
                        "Fields should be comma-separated")
        self.assertIn('match', params, "Match filter should be in params")

    def test_http_get_stats_fields_as_string(self):
        """Test get stats with fields as string (not list)."""
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"stats": {"amount": {"count": 50}}}
        
        self.client._make_request = Mock(return_value=mock_response)
        
        # Pass fields as string
        result = self.client._http_get_stats('order', fields='amount,quantity')
        
        # Verify fields param
        call_args = self.client._make_request.call_args
        params = call_args[1]['params']
        self.assertEqual(params['fields'], 'amount,quantity',
                        "String fields should be passed through as-is")

    def test_http_get_stats_no_fields(self):
        """Test get stats without specific fields (all numeric fields)."""
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "stats": {
                "amount": {"count": 50, "sum": 25000, "avg": 500, "min": 100, "max": 1000}
            }
        }
        
        self.client._make_request = Mock(return_value=mock_response)
        
        # Call without fields
        result = self.client._http_get_stats('order')
        
        # Verify no params (or None)
        call_args = self.client._make_request.call_args
        params = call_args[1]['params']
        # When no fields/match, params should be None
        self.assertIsNone(params, "Params should be None when no fields or match provided")

    def test_http_get_stats_with_match_filter(self):
        """Test get stats with match filter."""
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"stats": {}}
        
        self.client._make_request = Mock(return_value=mock_response)
        
        # Call with match filter
        match_filter = {'status': 'completed', 'amount': {'$gt': 100}}
        result = self.client._http_get_stats('order', match=match_filter)
        
        # Verify match serialized to JSON
        call_args = self.client._make_request.call_args
        params = call_args[1]['params']
        self.assertIn('match', params, "Match should be in params")
        
        # Parse back the match param
        match_parsed = json.loads(params['match'])
        self.assertEqual(match_parsed['status'], 'completed',
                        "Status filter should be preserved")
        self.assertEqual(match_parsed['amount']['$gt'], 100,
                        "MongoDB operators should be preserved")

    def test_http_get_stats_complex_match_filter(self):
        """Test get stats with complex nested match filter."""
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"stats": {}}
        
        self.client._make_request = Mock(return_value=mock_response)
        
        # Complex nested filter
        match_filter = {
            'status': {'$in': ['active', 'pending']},
            'metadata': {
                'tags': {'$all': ['python', 'testing']},
                'priority': {'$gte': 5}
            },
            'created_at': {'$gte': '2024-01-01'}
        }
        
        result = self.client._http_get_stats('order', match=match_filter)
        
        # Verify complex structure preserved
        call_args = self.client._make_request.call_args
        params = call_args[1]['params']
        match_parsed = json.loads(params['match'])
        
        self.assertEqual(match_parsed['status']['$in'], ['active', 'pending'],
                        "Array operators should be preserved")
        self.assertEqual(match_parsed['metadata']['tags']['$all'], ['python', 'testing'],
                        "Nested array operators should be preserved")
        self.assertEqual(match_parsed['metadata']['priority']['$gte'], 5,
                        "Nested comparison operators should be preserved")

    def test_http_get_stats_match_with_special_characters(self):
        """Test match filter with special characters requiring JSON escaping."""
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"stats": {}}
        
        self.client._make_request = Mock(return_value=mock_response)
        
        # Special characters
        match_filter = {
            'name': "O'Reilly",
            'description': 'Test "quoted" value',
            'path': 'C:\\Users\\Test'
        }
        
        result = self.client._http_get_stats('order', match=match_filter)
        
        # Verify JSON encoding handles special chars
        call_args = self.client._make_request.call_args
        params = call_args[1]['params']
        match_parsed = json.loads(params['match'])
        
        self.assertEqual(match_parsed['name'], "O'Reilly",
                        "Single quotes should be preserved")
        self.assertEqual(match_parsed['description'], 'Test "quoted" value',
                        "Double quotes should be escaped and preserved")
        self.assertEqual(match_parsed['path'], 'C:\\Users\\Test',
                        "Backslashes should be escaped")

    def test_http_get_stats_with_domain_name(self):
        """Test get stats with custom domain name."""
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"stats": {}}
        
        self.client._make_request = Mock(return_value=mock_response)
        
        # Call with custom domain
        result = self.client._http_get_stats('order', domain_name='acme-corp')
        
        # Verify domain in URL
        call_args = self.client._make_request.call_args
        expected_endpoint = f"{self.client.base_url}/acme-corp/order/stats"
        self.assertEqual(call_args[0][1], expected_endpoint,
                        "Custom domain should be in URL path")

    def test_http_get_stats_with_api_key(self):
        """Test get stats with API key."""
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"stats": {}}
        
        self.client._make_request = Mock(return_value=mock_response)
        
        # Call with API key
        result = self.client._http_get_stats('order', api_key='test-key-123')
        
        # Verify API key passed
        call_args = self.client._make_request.call_args
        self.assertEqual(call_args[1]['api_key'], 'test-key-123',
                        "API key should be passed to _make_request")

    def test_http_get_stats_server_error(self):
        """Test get stats with server error."""
        mock_response = Mock()
        mock_response.status_code = 500
        mock_response.text = "Internal Server Error"
        
        self.client._make_request = Mock(return_value=mock_response)
        
        # Should return None
        result = self.client._http_get_stats('order')
        self.assertIsNone(result, "Server errors should return None")

    def test_http_get_stats_not_found_error(self):
        """Test get stats with 404 error."""
        mock_response = Mock()
        mock_response.status_code = 404
        mock_response.text = "Object type not found"
        
        self.client._make_request = Mock(return_value=mock_response)
        
        result = self.client._http_get_stats('invalid_type')
        self.assertIsNone(result, "404 errors should return None")

    


    def test_http_get_stats_connection_failure(self):
        """Test get stats with connection failure (None response)."""
        self.client._make_request = Mock(return_value=None)
        
        result = self.client._http_get_stats('order')
        self.assertIsNone(result, "Connection failures should return None")

    def test_http_get_stats_empty_response(self):
        """Test get stats with empty stats response."""
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"stats": {}}
        
        self.client._make_request = Mock(return_value=mock_response)
        
        result = self.client._http_get_stats('order')
        
        self.assertIsNotNone(result, "Empty stats should still return a dict")
        self.assertEqual(result['stats'], {}, "Stats should be empty dict")

    def test_get_stats_delegates_to_http_method(self):
        """Test high-level get_stats delegates to _http_get_stats."""
        self.client._http_get_stats = Mock(return_value={"stats": {}})
        
        result = self.client.get_stats('order', fields=['amount'], domain_name='test-domain')
        
        self.client._http_get_stats.assert_called_once_with(
            'order', fields=['amount'], match=None, domain_name='test-domain', api_key=None
        )
        self.assertEqual(result, {"stats": {}}, "Should return _http_get_stats result")


class TestApiClientAggregate(unittest.TestCase):
    """Test ApiClient aggregate methods."""
    
    def setUp(self):
        """Set up test fixtures."""
        with patch('py_api_lib.api_client.requests.Session'):
            self.client = ApiClient(server_ip='localhost', port=8082)
            self.client.session = Mock()
            self.client._default_domain = 'default-domain'

    def test_http_aggregate_with_pipeline(self):
        """Test aggregate with raw MongoDB pipeline."""
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "results": [
                {"_id": "customer-1", "total": 5000, "count": 10},
                {"_id": "customer-2", "total": 3000, "count": 6}
            ]
        }
        
        self.client._make_request = Mock(return_value=mock_response)
        
        # Pipeline mode
        pipeline = [
            {"$match": {"status": "completed"}},
            {"$group": {"_id": "$customer_id", "total": {"$sum": "$amount"}, "count": {"$sum": 1}}}
        ]
        
        result = self.client._http_aggregate('order', pipeline=pipeline)
        
        # Verify result
        self.assertIsNotNone(result, "Result should not be None")
        self.assertEqual(len(result['results']), 2, "Should have 2 aggregated results")
        self.assertEqual(result['results'][0]['total'], 5000,
                        "First result total should be 5000")
        
        # Verify request
        call_args = self.client._make_request.call_args
        self.assertEqual(call_args[0][0], 'POST', "Should use POST method")
        
        expected_endpoint = f"{self.client.base_url}/default-domain/order/aggregate"
        self.assertEqual(call_args[0][1], expected_endpoint,
                        f"Endpoint should be {expected_endpoint}")
        
        # Verify body has pipeline
        body = call_args[1]['json']
        self.assertIn('pipeline', body, "Body should contain pipeline")
        self.assertEqual(len(body['pipeline']), 2, "Pipeline should have 2 stages")
        self.assertEqual(body['pipeline'][0]['$match']['status'], 'completed',
                        "Match stage should be preserved")

    def test_http_aggregate_with_builder_syntax(self):
        """Test aggregate with builder syntax."""
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"results": []}
        
        self.client._make_request = Mock(return_value=mock_response)
        
        # Builder mode
        result = self.client._http_aggregate(
            'order',
            match={'status': 'completed'},
            group_by='customer_id',
            metrics={'total': {'$sum': 'amount'}, 'count': True}
        )
        
        # Verify request body
        call_args = self.client._make_request.call_args
        body = call_args[1]['json']
        
        # Should NOT have pipeline
        self.assertNotIn('pipeline', body,
                        "Builder mode should not include pipeline key")
        
        # Should have builder fields
        self.assertEqual(body['match'], {'status': 'completed'},
                        "Match filter should be in body")
        self.assertEqual(body['group_by'], 'customer_id',
                        "Group by field should be in body")
        self.assertIn('total', body['metrics'],
                     "Metrics should include 'total'")
        self.assertTrue(body['metrics']['count'],
                       "Count metric should be True")

    def test_http_aggregate_pipeline_takes_precedence(self):
        """Test that pipeline mode ignores builder parameters."""
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"results": []}
        
        self.client._make_request = Mock(return_value=mock_response)
        
        pipeline = [{"$match": {"status": "active"}}]
        
        # Call with BOTH pipeline and builder params
        result = self.client._http_aggregate(
            'order',
            pipeline=pipeline,
            match={'status': 'completed'},  # Should be ignored
            group_by='customer_id',  # Should be ignored
            metrics={'count': True}  # Should be ignored
        )
        
        # Verify only pipeline is in body
        call_args = self.client._make_request.call_args
        body = call_args[1]['json']
        
        self.assertIn('pipeline', body, "Pipeline should be in body")
        self.assertNotIn('match', body, "Match should be ignored when pipeline provided")
        self.assertNotIn('group_by', body, "Group by should be ignored when pipeline provided")
        self.assertNotIn('metrics', body, "Metrics should be ignored when pipeline provided")

    def test_http_aggregate_with_sort_and_limit(self):
        """Test aggregate with sort and limit."""
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"results": []}
        
        self.client._make_request = Mock(return_value=mock_response)
        
        result = self.client._http_aggregate(
            'order',
            group_by='category',
            metrics={'count': True},
            sort={'count': -1},
            limit=10
        )
        
        # Verify sort and limit in body
        call_args = self.client._make_request.call_args
        body = call_args[1]['json']
        self.assertEqual(body['sort'], {'count': -1},
                        "Sort should be descending by count")
        self.assertEqual(body['limit'], 10,
                        "Limit should be 10")

    def test_http_aggregate_with_domain_and_api_key(self):
        """Test aggregate with domain name and API key."""
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"results": []}
        
        self.client._make_request = Mock(return_value=mock_response)
        
        result = self.client._http_aggregate(
            'order',
            pipeline=[{"$match": {}}],
            domain_name='acme-corp',
            api_key='key-123'
        )
        
        # Verify domain and key
        call_args = self.client._make_request.call_args
        expected_endpoint = f"{self.client.base_url}/acme-corp/order/aggregate"
        self.assertEqual(call_args[0][1], expected_endpoint,
                        "Domain should be in URL")
        self.assertEqual(call_args[1]['api_key'], 'key-123',
                        "API key should be passed")

    def test_http_aggregate_error_handling(self):
        """Test aggregate error handling."""
        mock_response = Mock()
        mock_response.status_code = 400
        mock_response.text = "Invalid pipeline"
        
        self.client._make_request = Mock(return_value=mock_response)
        self.client._extract_error_message = Mock(return_value="Invalid pipeline")
        
        result = self.client._http_aggregate('order', pipeline=[])
        
        # Should return None on error
        self.assertIsNone(result, "Errors should return None")
        
        # Verify error was logged
        self.client._extract_error_message.assert_called_once()

    def test_http_get_stats_invalid_json_response(self):
        """Test get stats with invalid JSON response."""
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.json.side_effect = json.JSONDecodeError("Invalid JSON", "", 0)
        
        self.client._make_request = Mock(return_value=mock_response)
        
        # Should raise some exception for invalid JSON
        with self.assertRaises(Exception) as context:
            self.client._http_get_stats('order')
        
        # Verify it's a deserialization error
        self.assertIn("Deserialization", type(context.exception).__name__)
        self.assertIn("Invalid JSON", str(context.exception))

    def test_http_aggregate_invalid_json_response(self):
        """Test aggregate with invalid JSON response."""
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.json.side_effect = json.JSONDecodeError("Invalid", "", 0)
        
        self.client._make_request = Mock(return_value=mock_response)
        
        # Should raise some exception for invalid JSON
        with self.assertRaises(Exception) as context:
            self.client._http_aggregate('order', pipeline=[{"$match": {}}])
        
        # Verify it's a deserialization error
        self.assertIn("Deserialization", type(context.exception).__name__)
        self.assertIn("Invalid", str(context.exception))
    

    def test_http_aggregate_empty_pipeline(self):
        """Test aggregate with empty pipeline - empty list is falsy."""
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"results": []}

        self.client._make_request = Mock(return_value=mock_response)

        # Empty list is falsy in Python: if []: is False
        result = self.client._http_aggregate('order', pipeline=[])

        call_args = self.client._make_request.call_args
        body = call_args[1]['json']

        # Empty list is falsy, so 'if pipeline:' is False
        # Implementation: if pipeline: body['pipeline'] = pipeline
        # Since [] is falsy, pipeline won't be added to body
        self.assertEqual(body, {},
                        "Empty pipeline (falsy) results in empty body")
        

    def test_aggregate_delegates_to_http_method(self):
        """Test high-level aggregate delegates to _http_aggregate."""
        self.client._http_aggregate = Mock(return_value={"results": []})
        
        result = self.client.aggregate(
            'order',
            match={'status': 'active'},
            group_by='category',
            domain_name='test-domain'
        )
        
        self.client._http_aggregate.assert_called_once()
        self.assertEqual(result, {"results": []},
                        "Should return _http_aggregate result")


class TestApiClientGetDistinct(unittest.TestCase):
    """Test ApiClient get_distinct methods."""
    
    def setUp(self):
        """Set up test fixtures."""
        with patch('py_api_lib.api_client.requests.Session'):
            self.client = ApiClient(server_ip='localhost', port=8082)
            self.client.session = Mock()
            self.client._default_domain = 'default-domain'

    def test_http_get_distinct_success(self):
        """Test successful get distinct values."""
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "values": ["active", "pending", "completed"],
            "count": 3
        }
        
        self.client._make_request = Mock(return_value=mock_response)
        
        result = self.client._http_get_distinct('project', field='status')
        
        # Verify result
        self.assertIsNotNone(result, "Result should not be None")
        self.assertEqual(len(result['values']), 3,
                        "Should have 3 distinct values")
        self.assertEqual(result['count'], 3,
                        "Count should match number of values")
        self.assertIn('active', result['values'],
                     "Should include 'active' status")
        
        # Verify request
        call_args = self.client._make_request.call_args
        self.assertEqual(call_args[0][0], 'GET', "Should use GET method")
        
        expected_endpoint = f"{self.client.base_url}/default-domain/project/distinct/status"
        self.assertEqual(call_args[0][1], expected_endpoint,
                        f"Endpoint should be {expected_endpoint}")

    def test_http_get_distinct_with_match(self):
        """Test get distinct with match filter."""
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"values": ["admin"], "count": 1}
        
        self.client._make_request = Mock(return_value=mock_response)
        
        result = self.client._http_get_distinct(
            'user_account',
            field='role',
            match={'enabled': True}
        )
        
        # Verify match param
        call_args = self.client._make_request.call_args
        params = call_args[1]['params']
        self.assertIn('match', params, "Match should be in params")
        
        match_parsed = json.loads(params['match'])
        self.assertEqual(match_parsed['enabled'], True,
                        "Enabled filter should be preserved")

    def test_http_get_distinct_with_limit(self):
        """Test get distinct with custom limit."""
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"values": [], "count": 0}
        
        self.client._make_request = Mock(return_value=mock_response)
        
        result = self.client._http_get_distinct('project', field='category', limit=50)
        
        # Verify limit param
        call_args = self.client._make_request.call_args
        params = call_args[1]['params']
        self.assertEqual(params['limit'], 50,
                        "Limit should be 50")

    def test_http_get_distinct_limit_boundaries(self):
        """Test get distinct at limit boundaries."""
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"values": [], "count": 0}
        
        self.client._make_request = Mock(return_value=mock_response)
        
        # Test minimum limit
        result = self.client._http_get_distinct('project', field='status', limit=1)
        call_args = self.client._make_request.call_args
        self.assertEqual(call_args[1]['params']['limit'], 1,
                        "Minimum limit should be 1")
        
        # Test maximum limit
        self.client._make_request.reset_mock()
        result = self.client._http_get_distinct('project', field='status', limit=10000)
        call_args = self.client._make_request.call_args
        self.assertEqual(call_args[1]['params']['limit'], 10000,
                        "Maximum limit should be 10000")

    def test_http_get_distinct_with_domain_and_key(self):
        """Test get distinct with domain and API key."""
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"values": [], "count": 0}
        
        self.client._make_request = Mock(return_value=mock_response)
        
        result = self.client._http_get_distinct(
            'order',
            field='status',
            domain_name='acme-corp',
            api_key='key-789'
        )
        
        # Verify domain and key
        call_args = self.client._make_request.call_args
        expected_endpoint = f"{self.client.base_url}/acme-corp/order/distinct/status"
        self.assertEqual(call_args[0][1], expected_endpoint,
                        "Domain should be in URL")
        self.assertEqual(call_args[1]['api_key'], 'key-789',
                        "API key should be passed")

    def test_http_get_distinct_empty_results(self):
        """Test get distinct with no matching values."""
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"values": [], "count": 0}
        
        self.client._make_request = Mock(return_value=mock_response)
        
        result = self.client._http_get_distinct('project', field='nonexistent_field')
        
        self.assertEqual(result['values'], [],
                        "Empty results should return empty list")
        self.assertEqual(result['count'], 0,
                        "Count should be 0 for empty results")

    def test_http_get_distinct_server_error(self):
        """Test get distinct with server error."""
        mock_response = Mock()
        mock_response.status_code = 500
        mock_response.text = "Internal error"
        
        self.client._make_request = Mock(return_value=mock_response)
        
        result = self.client._http_get_distinct('project', field='status')
        self.assertIsNone(result, "Server errors should return None")

    def test_get_distinct_delegates_to_http_method(self):
        """Test high-level get_distinct delegates."""
        self.client._http_get_distinct = Mock(return_value={"values": [], "count": 0})
        
        result = self.client.get_distinct('project', 'status', limit=100)
        
        self.client._http_get_distinct.assert_called_once_with(
            'project', field='status', match=None, limit=100, domain_name=None, api_key=None
        )


class TestApiClientGetCountBy(unittest.TestCase):
    """Test ApiClient get_count_by methods."""
    
    def setUp(self):
        """Set up test fixtures."""
        with patch('py_api_lib.api_client.requests.Session'):
            self.client = ApiClient(server_ip='localhost', port=8082)
            self.client.session = Mock()
            self.client._default_domain = 'default-domain'

    def test_http_get_count_by_success(self):
        """Test successful count-by operation."""
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "groups": [
                {"value": "developer", "count": 45},
                {"value": "admin", "count": 12},
                {"value": "viewer", "count": 8}
            ],
            "total_count": 65
        }
        
        self.client._make_request = Mock(return_value=mock_response)
        
        result = self.client._http_get_count_by('user_account', field='role')
        
        # Verify result
        self.assertIsNotNone(result, "Result should not be None")
        self.assertEqual(len(result['groups']), 3,
                        "Should have 3 groups")
        self.assertEqual(result['groups'][0]['count'], 45,
                        "Developer count should be 45")
        self.assertEqual(result['total_count'], 65,
                        "Total count should be 65")
        
        # Verify request
        call_args = self.client._make_request.call_args
        self.assertEqual(call_args[0][0], 'GET', "Should use GET method")
        
        expected_endpoint = f"{self.client.base_url}/default-domain/user_account/count-by/role"
        self.assertEqual(call_args[0][1], expected_endpoint,
                        f"Endpoint should be {expected_endpoint}")

    def test_http_get_count_by_with_sort(self):
        """Test count-by with different sort orders."""
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"groups": [], "total_count": 0}
        
        self.client._make_request = Mock(return_value=mock_response)
        
        # Test different sort orders
        test_cases = [
            ('-count', "Descending by count"),
            ('count', "Ascending by count"),
            ('value', "Ascending by value"),
            ('-value', "Descending by value")
        ]
        
        for sort_order, description in test_cases:
            with self.subTest(sort=sort_order):
                self.client._make_request.reset_mock()
                
                result = self.client._http_get_count_by(
                    'project',
                    field='status',
                    sort=sort_order
                )
                
                # Verify sort param
                call_args = self.client._make_request.call_args
                params = call_args[1]['params']
                self.assertEqual(params['sort'], sort_order,
                                f"{description} should be in params")

    def test_http_get_count_by_with_match_and_limit(self):
        """Test count-by with match filter and limit."""
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"groups": [], "total_count": 0}
        
        self.client._make_request = Mock(return_value=mock_response)
        
        result = self.client._http_get_count_by(
            'order',
            field='category',
            match={'status': 'completed'},
            limit=20
        )
        
        # Verify params
        call_args = self.client._make_request.call_args
        params = call_args[1]['params']
        self.assertEqual(params['limit'], 20,
                        "Limit should be 20")
        self.assertIn('match', params,
                     "Match should be in params")

    def test_http_get_count_by_limit_boundaries(self):
        """Test count-by at limit boundaries."""
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"groups": [], "total_count": 0}
        
        self.client._make_request = Mock(return_value=mock_response)
        
        # Test minimum
        result = self.client._http_get_count_by('project', field='status', limit=1)
        call_args = self.client._make_request.call_args
        self.assertEqual(call_args[1]['params']['limit'], 1,
                        "Minimum limit should be 1")
        
        # Test maximum
        self.client._make_request.reset_mock()
        result = self.client._http_get_count_by('project', field='status', limit=1000)
        call_args = self.client._make_request.call_args
        self.assertEqual(call_args[1]['params']['limit'], 1000,
                        "Maximum limit should be 1000")

    def test_http_get_count_by_with_domain_and_key(self):
        """Test count-by with domain and API key."""
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"groups": [], "total_count": 0}
        
        self.client._make_request = Mock(return_value=mock_response)
        
        result = self.client._http_get_count_by(
            'business',
            field='industry',
            domain_name='acme-corp',
            api_key='key-abc'
        )
        
        # Verify domain and key
        call_args = self.client._make_request.call_args
        expected_endpoint = f"{self.client.base_url}/acme-corp/business/count-by/industry"
        self.assertEqual(call_args[0][1], expected_endpoint,
                        "Domain should be in URL")
        self.assertEqual(call_args[1]['api_key'], 'key-abc',
                        "API key should be passed")

    def test_http_get_count_by_empty_results(self):
        """Test count-by with no matching documents."""
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"groups": [], "total_count": 0}
        
        self.client._make_request = Mock(return_value=mock_response)
        
        result = self.client._http_get_count_by('project', field='nonexistent')
        
        self.assertEqual(result['groups'], [],
                        "Empty results should return empty list")
        self.assertEqual(result['total_count'], 0,
                        "Total count should be 0")

    def test_get_count_by_delegates_to_http_method(self):
        """Test high-level get_count_by delegates."""
        self.client._http_get_count_by = Mock(return_value={"groups": [], "total_count": 0})
        
        result = self.client.get_count_by('user_account', 'role', sort='-count', limit=50)
        
        self.client._http_get_count_by.assert_called_once_with(
            'user_account', field='role', match=None, limit=50, sort='-count',
            domain_name=None, api_key=None
        )


class TestApiLibGetStats(unittest.TestCase):
    """Test ApiLib get_stats methods."""
    
    def setUp(self):
        """Set up test fixtures."""
        with patch('py_api_lib.api_lib.ApiClient') as mock_client_class:
            self.mock_api_client = Mock()
            mock_client_class.return_value = self.mock_api_client
            self.api_lib = ApiLib(api_server_host='localhost', api_server_port='8082')
            self.api_lib.object_types = ['order', 'project', 'user_account']
            # Mock domain resolution
            self.api_lib._resolve_domain_name = Mock(return_value='default-domain')
            self.api_lib._resolve_api_key = Mock(return_value=None)

    def test_get_stats_delegates_to_api_client(self):
        """Test that get_stats delegates to ApiClient."""
        self.mock_api_client.get_stats.return_value = {"stats": {}}
        
        result = self.api_lib.get_stats(
            'order',
            fields=['amount', 'quantity'],
            match={'status': 'completed'}
        )
        
        # Verify delegation
        self.mock_api_client.get_stats.assert_called_once_with(
            obj_type='order',
            fields=['amount', 'quantity'],
            match={'status': 'completed'},
            domain_name='default-domain',
            api_key=None
        )
        self.assertEqual(result, {"stats": {}},
                        "Should return ApiClient result")

    def test_get_stats_with_domain_resolution(self):
        """Test that get_stats resolves domain name."""
        self.mock_api_client.get_stats.return_value = {"stats": {}}
        self.api_lib._resolve_domain_name.return_value = 'acme-corp'
        
        result = self.api_lib.get_stats('order', domain_name='acme-corp')
        
        # Verify domain resolution called
        self.api_lib._resolve_domain_name.assert_called_once_with('order', 'acme-corp')
        
        # Should use resolved domain
        call_args = self.mock_api_client.get_stats.call_args
        self.assertEqual(call_args[1]['domain_name'], 'acme-corp',
                        "Should use resolved domain")

    def test_get_stats_with_api_key_resolution(self):
        """Test that get_stats resolves API key."""
        self.mock_api_client.get_stats.return_value = {"stats": {}}
        self.api_lib._resolve_api_key.return_value = 'resolved-key-456'
        
        result = self.api_lib.get_stats('order', api_key='test-key-456')
        
        # Verify key resolution called
        self.api_lib._resolve_api_key.assert_called_once_with('test-key-456')
        
        # Should use resolved key
        call_args = self.mock_api_client.get_stats.call_args
        self.assertEqual(call_args[1]['api_key'], 'resolved-key-456',
                        "Should use resolved API key")

    def test_get_stats_error_handling(self):
        """Test that get_stats handles errors gracefully."""
        self.mock_api_client.get_stats.side_effect = Exception("Connection failed")
        
        with self.assertRaises(Exception) as ctx:
            self.api_lib.get_stats('order', fields=['amount'])
        self.assertIn("Connection failed", str(ctx.exception))

    def test_get_stats_with_specific_exceptions(self):
        """Test get_stats with specific exception types."""
        # Test with different exceptions - all should propagate
        exceptions = [
            (ConnectionError, "Network error"),
            (TimeoutError, "Request timeout"),
            (ValueError, "Invalid parameter"),
        ]
        
        for exc_class, message in exceptions:
            with self.subTest(exception=exc_class.__name__):
                self.mock_api_client.get_stats.reset_mock()
                self.mock_api_client.get_stats.side_effect = exc_class(message)
                
                # ✅ FIXED: Expect exception to be raised, not None
                with self.assertRaises(exc_class) as ctx:
                    self.api_lib.get_stats('order')
                
                self.assertEqual(str(ctx.exception), message,
                                f"{exc_class.__name__} should propagate with correct message")


class TestApiLibAggregate(unittest.TestCase):
    """Test ApiLib aggregate methods."""
    
    def setUp(self):
        """Set up test fixtures."""
        with patch('py_api_lib.api_lib.ApiClient') as mock_client_class:
            self.mock_api_client = Mock()
            mock_client_class.return_value = self.mock_api_client
            self.api_lib = ApiLib(api_server_host='localhost', api_server_port='8082')
            self.api_lib._resolve_domain_name = Mock(return_value='default-domain')
            self.api_lib._resolve_api_key = Mock(return_value=None)

    def test_aggregate_with_pipeline(self):
        """Test aggregate with raw pipeline."""
        self.mock_api_client.aggregate.return_value = {"results": []}
        
        pipeline = [{"$match": {"status": "active"}}]
        result = self.api_lib.aggregate('order', pipeline=pipeline)
        
        # Verify delegation
        self.mock_api_client.aggregate.assert_called_once()
        call_args = self.mock_api_client.aggregate.call_args
        self.assertEqual(call_args[1]['pipeline'], pipeline,
                        "Pipeline should be passed")

    def test_aggregate_with_builder_syntax(self):
        """Test aggregate with builder syntax."""
        self.mock_api_client.aggregate.return_value = {"results": []}
        
        result = self.api_lib.aggregate(
            'order',
            match={'status': 'completed'},
            group_by='customer_id',
            metrics={'total': {'$sum': 'amount'}}
        )
        
        # Verify builder params passed
        call_args = self.mock_api_client.aggregate.call_args
        self.assertEqual(call_args[1]['match'], {'status': 'completed'},
                        "Match should be passed")
        self.assertEqual(call_args[1]['group_by'], 'customer_id',
                        "Group by should be passed")
        self.assertIn('metrics', call_args[1],
                     "Metrics should be in kwargs")

    def test_aggregate_with_all_parameters(self):
        """Test aggregate with all available parameters."""
        self.mock_api_client.aggregate.return_value = {"results": []}
        
        result = self.api_lib.aggregate(
            'order',
            match={'status': 'active'},
            group_by='category',
            metrics={'total': {'$sum': 'amount'}},
            sort={'total': -1},
            limit=20,
            domain_name='acme-corp',
            api_key='test-key'
        )
        
        # Verify all params
        call_args = self.mock_api_client.aggregate.call_args
        self.assertEqual(call_args[1]['match'], {'status': 'active'})
        self.assertEqual(call_args[1]['group_by'], 'category')
        self.assertEqual(call_args[1]['sort'], {'total': -1})
        self.assertEqual(call_args[1]['limit'], 20)

    def test_aggregate_with_domain_and_key(self):
        """Test aggregate with domain and API key."""
        self.mock_api_client.aggregate.return_value = {"results": []}
        self.api_lib._resolve_domain_name.return_value = 'acme-corp'
        self.api_lib._resolve_api_key.return_value = 'key-xyz'
        
        result = self.api_lib.aggregate(
            'order',
            match={},
            domain_name='acme-corp',
            api_key='key-xyz'
        )
        
        # Verify resolution
        call_args = self.mock_api_client.aggregate.call_args
        self.assertEqual(call_args[1]['domain_name'], 'acme-corp')
        self.assertEqual(call_args[1]['api_key'], 'key-xyz')

    def test_aggregate_error_handling(self):
        """Test aggregate error handling."""
        self.mock_api_client.aggregate.side_effect = Exception("Pipeline error")
        
        with self.assertRaises(Exception) as ctx:
            self.api_lib.aggregate('order', pipeline=[...])
        self.assertIn("Pipeline error", str(ctx.exception))


class TestApiLibGetDistinct(unittest.TestCase):
    """Test ApiLib get_distinct methods."""
    
    def setUp(self):
        """Set up test fixtures."""
        with patch('py_api_lib.api_lib.ApiClient') as mock_client_class:
            self.mock_api_client = Mock()
            mock_client_class.return_value = self.mock_api_client
            self.api_lib = ApiLib(api_server_host='localhost', api_server_port='8082')
            self.api_lib._resolve_domain_name = Mock(return_value='default-domain')
            self.api_lib._resolve_api_key = Mock(return_value=None)

    def test_get_distinct_delegates_to_api_client(self):
        """Test that get_distinct delegates properly."""
        self.mock_api_client.get_distinct.return_value = {"values": [], "count": 0}
        
        result = self.api_lib.get_distinct('project', field='status', limit=100)
        
        # Verify delegation
        self.mock_api_client.get_distinct.assert_called_once_with(
            obj_type='project',
            field='status',
            match=None,
            limit=100,
            domain_name='default-domain',
            api_key=None
        )

    def test_get_distinct_with_all_parameters(self):
        """Test get_distinct with all parameters."""
        self.mock_api_client.get_distinct.return_value = {"values": ["active"], "count": 1}
        self.api_lib._resolve_domain_name.return_value = 'test-domain'
        self.api_lib._resolve_api_key.return_value = 'test-key'
        
        result = self.api_lib.get_distinct(
            'user_account',
            field='role',
            match={'enabled': True},
            limit=50,
            domain_name='test-domain',
            api_key='test-key'
        )
        
        # Verify all params passed
        call_args = self.mock_api_client.get_distinct.call_args
        self.assertEqual(call_args[1]['field'], 'role')
        self.assertEqual(call_args[1]['match'], {'enabled': True})
        self.assertEqual(call_args[1]['limit'], 50)
        self.assertEqual(call_args[1]['domain_name'], 'test-domain')
        self.assertEqual(call_args[1]['api_key'], 'test-key')

    def test_get_distinct_error_handling(self):
        """Test get_distinct error handling."""
        self.mock_api_client.get_distinct.side_effect = Exception("Field not found")
        
        with self.assertRaises(Exception) as ctx:
            self.api_lib.get_distinct('order', 'status')
        self.assertIn("Field not found", str(ctx.exception))


class TestApiLibGetCountBy(unittest.TestCase):
    """Test ApiLib get_count_by methods."""
    
    def setUp(self):
        """Set up test fixtures."""
        with patch('py_api_lib.api_lib.ApiClient') as mock_client_class:
            self.mock_api_client = Mock()
            mock_client_class.return_value = self.mock_api_client
            self.api_lib = ApiLib(api_server_host='localhost', api_server_port='8082')
            self.api_lib._resolve_domain_name = Mock(return_value='default-domain')
            self.api_lib._resolve_api_key = Mock(return_value=None)

    def test_get_count_by_delegates_to_api_client(self):
        """Test that get_count_by delegates properly."""
        self.mock_api_client.get_count_by.return_value = {"groups": [], "total_count": 0}
        
        result = self.api_lib.get_count_by('user_account', field='role')
        
        # Verify delegation
        self.mock_api_client.get_count_by.assert_called_once_with(
            obj_type='user_account',
            field='role',
            match=None,
            limit=100,
            sort='-count',
            domain_name='default-domain',
            api_key=None
        )

    def test_get_count_by_with_custom_sort_and_limit(self):
        """Test get_count_by with custom parameters."""
        self.mock_api_client.get_count_by.return_value = {"groups": [], "total_count": 0}
        
        result = self.api_lib.get_count_by(
            'order',
            field='category',
            sort='value',
            limit=20
        )
        
        # Verify params
        call_args = self.mock_api_client.get_count_by.call_args
        self.assertEqual(call_args[1]['sort'], 'value',
                        "Custom sort should be passed")
        self.assertEqual(call_args[1]['limit'], 20,
                        "Custom limit should be passed")

    def test_get_count_by_with_match_filter(self):
        """Test get_count_by with match filter."""
        self.mock_api_client.get_count_by.return_value = {"groups": [], "total_count": 0}
        
        result = self.api_lib.get_count_by(
            'business',
            field='industry',
            match={'active': True}
        )
        
        # Verify match passed
        call_args = self.mock_api_client.get_count_by.call_args
        self.assertEqual(call_args[1]['match'], {'active': True},
                        "Match filter should be passed")

    def test_get_count_by_error_handling(self):
        """Test get_count_by error handling."""
        self.mock_api_client.get_count_by.side_effect = Exception("Aggregation failed")
        
        with self.assertRaises(Exception) as ctx:
            self.api_lib.get_count_by('order', 'status')
        self.assertIn("Aggregation failed", str(ctx.exception))


class TestAggregateIntegration(unittest.TestCase):
    """Integration tests for aggregate operations."""
    
    def setUp(self):
        """Set up test fixtures."""
        with patch('py_api_lib.api_lib.ApiClient') as mock_client_class:
            self.mock_api_client = Mock()
            mock_client_class.return_value = self.mock_api_client
            self.api_lib = ApiLib(api_server_host='localhost', api_server_port='8082')
            self.api_lib._resolve_domain_name = Mock(return_value='default-domain')
            self.api_lib._resolve_api_key = Mock(return_value=None)

    def test_complete_stats_workflow(self):
        """Test complete get_stats workflow from ApiLib to ApiClient."""
        # Mock ApiClient response
        self.mock_api_client.get_stats.return_value = {
            "stats": {
                "amount": {"count": 100, "sum": 50000, "avg": 500, "min": 10, "max": 2000}
            }
        }
        
        # Call through ApiLib
        result = self.api_lib.get_stats(
            'order',
            fields=['amount'],
            match={'status': 'completed'},
            domain_name='acme-corp',
            api_key='test-key'
        )
        
        # Verify end-to-end
        self.assertIsNotNone(result, "Result should not be None")
        self.assertIn('stats', result, "Result should have stats key")
        self.assertEqual(result['stats']['amount']['count'], 100,
                        "Count should be 100")
        
        # Verify call chain
        self.mock_api_client.get_stats.assert_called_once()

    def test_complete_aggregate_workflow(self):
        """Test complete aggregate workflow."""
        # Mock response
        self.mock_api_client.aggregate.return_value = {
            "results": [
                {"_id": "category-1", "count": 50, "total": 25000}
            ]
        }
        
        # Call through ApiLib
        result = self.api_lib.aggregate(
            'order',
            match={'status': 'active'},
            group_by='category',
            metrics={'count': True, 'total': {'$sum': 'amount'}}
        )
        
        # Verify
        self.assertIsNotNone(result, "Result should not be None")
        self.assertEqual(len(result['results']), 1,
                        "Should have 1 result")
        self.assertEqual(result['results'][0]['count'], 50,
                        "Count should be 50")

    def test_complete_distinct_workflow(self):
        """Test complete get_distinct workflow."""
        # Mock response
        self.mock_api_client.get_distinct.return_value = {
            "values": ["active", "pending", "completed"],
            "count": 3
        }
        
        # Call through ApiLib
        result = self.api_lib.get_distinct('project', field='status', limit=100)
        
        # Verify
        self.assertIsNotNone(result, "Result should not be None")
        self.assertEqual(result['count'], 3,
                        "Count should be 3")
        self.assertEqual(len(result['values']), 3,
                        "Should have 3 distinct values")

    def test_complete_count_by_workflow(self):
        """Test complete get_count_by workflow."""
        # Mock response
        self.mock_api_client.get_count_by.return_value = {
            "groups": [
                {"value": "developer", "count": 45},
                {"value": "admin", "count": 12}
            ],
            "total_count": 57
        }
        
        # Call through ApiLib
        result = self.api_lib.get_count_by('user_account', field='role', sort='-count')
        
        # Verify
        self.assertIsNotNone(result, "Result should not be None")
        self.assertEqual(result['total_count'], 57,
                        "Total count should be 57")
        self.assertEqual(len(result['groups']), 2,
                        "Should have 2 groups")

    def test_error_propagation_through_layers(self):
        """Test that errors propagate correctly through ApiLib to ApiClient."""
        # Mock error in ApiClient
        self.mock_api_client.aggregate.side_effect = Exception("Network error")
        
        # ✅ ADD THIS BLOCK - wrap the call in assertRaises:
        with self.assertRaises(Exception) as ctx:
            # Call through ApiLib - exception should propagate
            result = self.api_lib.aggregate('order', pipeline=[{"$count": "total"}])
        
        # Verify the exception message
        self.assertIn("Network error", str(ctx.exception),
                     "Exception should propagate through layers")

    def test_parameter_passthrough_integrity(self):
        """Test that all parameters pass through correctly."""
        self.mock_api_client.aggregate.return_value = {"results": []}
        self.api_lib._resolve_domain_name = Mock(side_effect=lambda obj_type, domain: domain or 'default-domain')
        self.api_lib._resolve_api_key = Mock(side_effect=lambda key: key)
        
        # Call with many parameters
        self.api_lib.aggregate(
            'order',
            pipeline=[{"$match": {}}],
            match={'status': 'active'},  # Should be ignored
            group_by='category',  # Should be ignored
            metrics={'count': True},  # Should be ignored
            sort={'count': -1},
            limit=50,
            domain_name='test-domain',
            api_key='test-key'
        )
        
        # Verify ApiClient received correct params
        call_args = self.mock_api_client.aggregate.call_args
        
        # Pipeline should be present
        self.assertIn('pipeline', call_args[1])
        
        # Domain and key should be passed
        self.assertEqual(call_args[1]['domain_name'], 'test-domain')
        self.assertEqual(call_args[1]['api_key'], 'test-key')


def create_test_suite():
    """Create test suite for aggregate operations."""
    suite = unittest.TestSuite()
    
    test_classes = [
        TestApiClientGetStats,
        TestApiClientAggregate,
        TestApiClientGetDistinct,
        TestApiClientGetCountBy,
        TestApiLibGetStats,
        TestApiLibAggregate,
        TestApiLibGetDistinct,
        TestApiLibGetCountBy,
        TestAggregateIntegration,
    ]
    
    for test_class in test_classes:
        suite.addTest(unittest.TestLoader().loadTestsFromTestCase(test_class))
    
    return suite


if __name__ == '__main__':
    # Run tests
    runner = unittest.TextTestRunner(verbosity=2)
    suite = create_test_suite()
    result = runner.run(suite)
    
    # Print summary
    print("\n" + "="*70)
    print(f"Tests run: {result.testsRun}")
    print(f"Failures: {len(result.failures)}")
    print(f"Errors: {len(result.errors)}")
    print(f"Skipped: {len(result.skipped)}")
    print(f"Success rate: {((result.testsRun - len(result.failures) - len(result.errors)) / result.testsRun * 100):.1f}%")
    print("="*70)
    
    # Exit with appropriate code
    sys.exit(0 if result.wasSuccessful() else 1)
