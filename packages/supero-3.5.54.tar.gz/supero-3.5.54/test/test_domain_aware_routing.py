"""
Domain-Aware Routing Tests

Tests the new domain-aware architecture in ApiClient, ApiLib, and Supero.
Focuses on:
- Domain name parameter passing through call chains
- Default domain usage
- Platform registry object detection
- Domain name resolution logic

FIXED: Mock _load_existing_domain must set _domain_obj to avoid ValueError.
"""

import unittest
from unittest.mock import Mock, patch, MagicMock
import sys
from pathlib import Path

# Setup paths
test_dir = Path(__file__).parent
project_root = test_dir.parent
src_dir = project_root / "src"

for path in [str(src_dir), str(project_root)]:
    if path not in sys.path:
        sys.path.insert(0, path)

from py_api_lib.api_client import ApiClient
from py_api_lib.api_lib import ApiLib


class TestApiClientDomainAwareRouting(unittest.TestCase):
    """Test ApiClient domain-aware URL routing."""
    
    def setUp(self):
        """Set up test fixtures."""
        with patch('py_api_lib.api_client.requests.Session'):
            self.client = ApiClient(
                server_ip='localhost',
                port=8082,
                default_domain='test-domain'
            )
            self.client.session = Mock()
    
    def test_default_domain_initialization(self):
        """Test that default_domain is set correctly during initialization."""
        self.assertEqual(self.client.get_default_domain(), 'test-domain')
    
    def test_set_default_domain(self):
        """Test setting default domain after initialization."""
        self.client.set_default_domain('new-domain')
        self.assertEqual(self.client.get_default_domain(), 'new-domain')
    
    def test_http_create_uses_default_domain(self):
        """Test that _http_create uses default_domain when domain_name not provided."""
        mock_response = Mock()
        mock_response.status_code = 201
        mock_response.json.return_value = {"project": {"uuid": "proj-123"}}
        self.client._make_request = Mock(return_value=mock_response)
        
        payload = {"name": "test-project"}
        result = self.client._http_create("project", payload)
        
        # Verify URL includes default domain
        call_args = self.client._make_request.call_args
        self.assertIn('test-domain/project', call_args[0][1])
    
    def test_http_create_uses_explicit_domain(self):
        """Test that _http_create uses explicit domain_name when provided."""
        mock_response = Mock()
        mock_response.status_code = 201
        mock_response.json.return_value = {"project": {"uuid": "proj-123"}}
        self.client._make_request = Mock(return_value=mock_response)
        
        payload = {"name": "test-project"}
        result = self.client._http_create("project", payload, domain_name='acme-corp')
        
        # Verify URL includes explicit domain
        call_args = self.client._make_request.call_args
        self.assertIn('acme-corp/project', call_args[0][1])
    
    def test_http_read_domain_routing(self):
        """Test that _http_read routes to correct domain."""
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"project": {"uuid": "proj-123"}}
        self.client._make_request = Mock(return_value=mock_response)
        
        # Test with default domain
        result = self.client._http_read("project", "proj-123")
        call_args = self.client._make_request.call_args
        self.assertIn('test-domain/project/proj-123', call_args[0][1])
        
        # Test with explicit domain
        result = self.client._http_read("project", "proj-123", domain_name='acme-corp')
        call_args = self.client._make_request.call_args
        self.assertIn('acme-corp/project/proj-123', call_args[0][1])
    
    def test_http_update_domain_routing(self):
        """Test that _http_update routes to correct domain."""
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"project": {"uuid": "proj-123"}}
        self.client._make_request = Mock(return_value=mock_response)
        
        payload = {"name": "updated-project"}
        result = self.client._http_update("project", "proj-123", payload, domain_name='acme-corp')
        
        call_args = self.client._make_request.call_args
        self.assertIn('acme-corp/project/proj-123', call_args[0][1])
    
    def test_http_delete_domain_routing(self):
        """Test that _http_delete routes to correct domain."""
        mock_response = Mock()
        mock_response.status_code = 200
        self.client._make_request = Mock(return_value=mock_response)
        
        result = self.client._http_delete("project", "proj-123", domain_name='acme-corp')
        
        call_args = self.client._make_request.call_args
        self.assertIn('acme-corp/project/proj-123', call_args[0][1])
    
    def test_http_list_uses_no_plural_form_with_domain(self):
        """Test that _http_list uses no plural form and correct domain."""
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"objects": []}
        self.client._make_request = Mock(return_value=mock_response)
        
        result = self.client._http_list("project", domain_name='acme-corp')
        
        # Verify URL uses plural form with domain
        call_args = self.client._make_request.call_args
        self.assertIn('acme-corp/project', call_args[0][1])
    
    def test_http_query_domain_routing(self):
        """Test that _http_query routes to correct domain."""
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"results": []}
        self.client._make_request = Mock(return_value=mock_response)
        
        json_data = '{"op": "find-sub-classes"}'
        result = self.client._http_query(json_data, domain_name='acme-corp')
        
        call_args = self.client._make_request.call_args
        self.assertIn('acme-corp/query', call_args[0][1])
    
    def test_http_list_bulk_domain_routing(self):
        """Test that _http_list_bulk routes to correct domain."""
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"projects": []}
        self.client._make_request = Mock(return_value=mock_response)
        
        result = self.client._http_list_bulk("project", [], domain_name='acme-corp')
        
        call_args = self.client._make_request.call_args
        self.assertIn('acme-corp/list-bulk', call_args[0][1])
    
    def test_fq_name_to_uuid_domain_routing(self):
        """Test that fq_name_to_uuid routes to correct domain."""
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"uuid": "proj-123"}
        self.client._make_request = Mock(return_value=mock_response)
        
        result = self.client.fq_name_to_uuid("project", "test:project", domain_name='acme-corp')
        
        call_args = self.client._make_request.call_args
        self.assertIn('acme-corp/fq-name-to-uuid', call_args[0][1])
    
    def test_uuid_to_fq_name_domain_routing(self):
        """Test that uuid_to_fq_name routes to correct domain."""
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"fq_name": ["test", "project"]}
        self.client._make_request = Mock(return_value=mock_response)
        
        result = self.client.uuid_to_fq_name("project", "proj-123", domain_name='acme-corp')
        
        call_args = self.client._make_request.call_args
        self.assertIn('acme-corp/uuid-to-fq-name', call_args[0][1])


class TestApiLibDomainResolution(unittest.TestCase):
    """Test ApiLib domain name resolution logic."""
    
    def setUp(self):
        """Set up test fixtures."""
        self.patcher = patch('py_api_lib.api_lib.ApiClient')
        mock_client_class = self.patcher.start()
        
        self.mock_api_client = Mock()
        mock_client_class.return_value = self.mock_api_client
        
        self.api_lib = ApiLib(
            api_server_host='localhost',
            api_server_port='8082',
            default_domain='tenant-domain'
        )
    
    def tearDown(self):
        """Clean up patches."""
        self.patcher.stop()
    
    def test_default_domain_initialization(self):
        """Test that default_domain is set correctly."""
        self.assertEqual(self.api_lib.get_default_domain(), 'tenant-domain')
    
    def test_set_default_domain(self):
        """Test setting default domain."""
        self.api_lib.set_default_domain('new-domain')
        self.assertEqual(self.api_lib.get_default_domain(), 'new-domain')
    
    def test_resolve_domain_for_platform_objects(self):
        """Test that platform registry objects always use 'default-domain'."""
        # Platform objects should always resolve to 'default-domain'
        platform_objects = ['audit_log', 'global_system_config', 'global-system-config']
        
        for obj_type in platform_objects:
            # Even if we explicitly pass a different domain, it should use 'default-domain'
            resolved = self.api_lib._resolve_domain_name(obj_type, 'acme-corp')
            self.assertEqual(resolved, 'default-domain', 
                           f"{obj_type} should always use its default-domain")
    
    def test_resolve_domain_for_tenant_objects(self):
        """Test that tenant objects use provided or default domain."""
        tenant_objects = ['domain', 'project', 'business', 'customer', 'provider']
        
        for obj_type in tenant_objects:
            # With explicit domain
            resolved = self.api_lib._resolve_domain_name(obj_type, 'acme-corp')
            self.assertEqual(resolved, 'acme-corp')
            
            # Without explicit domain (should use default)
            resolved = self.api_lib._resolve_domain_name(obj_type, None)
            self.assertEqual(resolved, 'tenant-domain')
    
    def test_resolve_domain_normalizes_type_names(self):
        """Test that domain resolution works with various type name formats."""
        # Hyphenated
        resolved = self.api_lib._resolve_domain_name('virtual-network', 'acme-corp')
        self.assertEqual(resolved, 'acme-corp')
        
        # Underscore
        resolved = self.api_lib._resolve_domain_name('virtual_network', 'acme-corp')
        self.assertEqual(resolved, 'acme-corp')
        
        # CamelCase
        resolved = self.api_lib._resolve_domain_name('VirtualNetwork', 'acme-corp')
        self.assertEqual(resolved, 'acme-corp')
    
    def test_object_create_passes_domain_name(self):
        """Test that _object_create passes domain_name to ApiClient."""
        mock_obj = Mock()
        mock_obj.name = "test-project"
        mock_obj.fq_name = ["test-project"]
        mock_obj.parent_obj = None
        mock_obj.to_dict.return_value = {"name": "test-project", "_encrypted": False}
        
        self.mock_api_client._http_create.return_value = {"project": {"uuid": "proj-123"}}
        
        # Call with explicit domain
        result = self.api_lib._object_create("project", mock_obj, domain_name='acme-corp')
        
        # Verify domain_name was passed
        call_args = self.mock_api_client._http_create.call_args
        self.assertEqual(call_args[1]['domain_name'], 'acme-corp')
    
    def test_object_read_passes_domain_name(self):
        """Test that _object_read passes domain_name to ApiClient."""
        self.mock_api_client._http_read.return_value = {
            "project": {"uuid": "proj-123", "name": "test"}
        }
        
        with patch.object(self.api_lib, '_hydrate_object') as mock_hydrate:
            mock_obj = Mock()
            mock_obj.clear_pending_updates = Mock()
            mock_obj.set_server_conn = Mock()
            mock_hydrate.return_value = mock_obj
            
            result = self.api_lib._object_read("project", id="proj-123", domain_name='acme-corp')
        
        # Verify domain_name was passed
        call_args = self.mock_api_client._http_read.call_args
        self.assertEqual(call_args[1]['domain_name'], 'acme-corp')
    
    def test_object_update_passes_domain_name(self):
        """Test that _object_update passes domain_name to ApiClient."""
        mock_obj = Mock()
        mock_obj.uuid = "proj-123"
        mock_obj.to_dict.return_value = {"uuid": "proj-123", "name": "updated", "_encrypted": False}
        mock_obj.clear_pending_updates = Mock()
        
        self.mock_api_client._http_update.return_value = {"project": {"uuid": "proj-123"}}
        
        result = self.api_lib._object_update("project", mock_obj, domain_name='acme-corp')
        
        # Verify domain_name was passed
        call_args = self.mock_api_client._http_update.call_args
        self.assertEqual(call_args[1]['domain_name'], 'acme-corp')
    
    def test_object_delete_passes_domain_name(self):
        """Test that _object_delete passes domain_name to ApiClient."""
        self.mock_api_client._http_delete.return_value = True
        
        self.api_lib._object_delete("project", id="proj-123", domain_name='acme-corp')
        
        # Verify domain_name was passed
        call_args = self.mock_api_client._http_delete.call_args
        self.assertEqual(call_args[1]['domain_name'], 'acme-corp')
    
    def test_objects_list_passes_domain_name(self):
        """Test that _objects_list passes domain_name to ApiClient."""
        self.mock_api_client._http_list.return_value = []
        
        result = self.api_lib._objects_list("project", domain_name='acme-corp')
        
        # Verify domain_name was passed
        call_args = self.mock_api_client._http_list.call_args
        self.assertEqual(call_args[1]['domain_name'], 'acme-corp')
    
    def test_list_bulk_passes_domain_name(self):
        """Test that list_bulk passes domain_name to ApiClient."""
        self.mock_api_client._http_list_bulk.return_value = []
        
        result = self.api_lib.list_bulk("project", [], domain_name='acme-corp')
        
        # Verify domain_name was passed
        call_args = self.mock_api_client._http_list_bulk.call_args
        self.assertEqual(call_args[1]['domain_name'], 'acme-corp')
    
    def test_query_passes_domain_name(self):
        """Test that query passes domain_name to ApiClient."""
        self.mock_api_client.query.return_value = {"results": []}
        
        result = self.api_lib.query('{"op": "test"}', domain_name='acme-corp')
        
        # Verify domain_name was passed
        call_args = self.mock_api_client.query.call_args
        self.assertEqual(call_args[1]['domain_name'], 'acme-corp')
    
    def test_fq_name_to_uuid_passes_domain_name(self):
        """Test that fq_name_to_uuid passes domain_name to ApiClient."""
        self.mock_api_client.fq_name_to_uuid.return_value = "proj-123"
        
        result = self.api_lib.fq_name_to_uuid("project", ["test", "project"], domain_name='acme-corp')
        
        # Verify domain_name was passed
        call_args = self.mock_api_client.fq_name_to_uuid.call_args
        self.assertEqual(call_args[1]['domain_name'], 'acme-corp')
    
    def test_uuid_to_fq_name_passes_domain_name(self):
        """Test that uuid_to_fq_name passes domain_name to ApiClient."""
        self.mock_api_client.uuid_to_fq_name.return_value = ["test", "project"]
        
        result = self.api_lib.uuid_to_fq_name("project", "proj-123", domain_name='acme-corp')
        
        # Verify domain_name was passed
        call_args = self.mock_api_client.uuid_to_fq_name.call_args
        self.assertEqual(call_args[1]['domain_name'], 'acme-corp')


def create_mock_load_lib_return(mock_api=None):
    """Helper to create standard mock return value for _load_py_api_lib_for_domain."""
    if mock_api is None:
        mock_api = MagicMock()
    return (
        MagicMock(return_value=mock_api),  # ApiLib class
        ['pymodel_system'],  # SCHEMA_NAMESPACES
        'pymodel_system',    # PRIMARY_SCHEMA_NAMESPACE
        None,                # TENANT_NAMESPACE
        'py_api_lib'         # package name
    )


class TestSuperoDomainPropagation(unittest.TestCase):
    """Test that Supero propagates domain_name to ApiLib operations."""
    
    def setUp(self):
        """Set up test fixtures."""
        # Skip this test group if Supero imports fail
        try:
            from supero import Supero
            self.Supero = Supero
        except ImportError:
            self.skipTest("Supero not available")

    def test_supero_passes_domain_to_operations(self):
        """Test that Supero passes domain_name to all API operations."""
        mock_api_lib = MagicMock()
        mock_api_lib.object_types = {}
        mock_api_lib.get_default_domain.return_value = 'acme-corp'
        
        mock_domain = MagicMock()
        mock_domain.uuid = 'domain-123'
        mock_domain.name = 'acme-corp'
        mock_api_lib._object_read.return_value = mock_domain
        
        def mock_load_existing_domain(self):
            """Mock that sets _domain_obj to avoid ValueError."""
            self._domain_obj = mock_domain
            self._domain_uuid = 'domain-123'
        
        with patch('supero.core._load_py_api_lib_for_domain') as mock_load_lib:
            mock_load_lib.return_value = create_mock_load_lib_return(mock_api_lib)
            
            with patch.object(self.Supero, '_ensure_domain'):
                with patch.object(self.Supero, '_load_existing_domain', mock_load_existing_domain):
                    org = self.Supero(domain_name='acme-corp')
                    
                    # Verify domain_name was stored
                    self.assertEqual(org.domain_name, 'acme-corp')
                    self.assertEqual(org._domain_uuid, 'domain-123')
                    self.assertIsNotNone(org._domain_obj)


def create_test_suite():
    """Create test suite for domain-aware routing."""
    suite = unittest.TestSuite()
    
    test_classes = [
        TestApiClientDomainAwareRouting,
        TestApiLibDomainResolution,
        TestSuperoDomainPropagation,
    ]
    
    for test_class in test_classes:
        suite.addTest(unittest.TestLoader().loadTestsFromTestCase(test_class))
    
    return suite


if __name__ == '__main__':
    # Run tests with verbose output
    runner = unittest.TextTestRunner(verbosity=2)
    runner.run(create_test_suite())
