"""
Unit Tests for Service Account Fallback Feature

Tests the new service_api_key and service_account parameters
that enable anonymous/no-login operations via a service account.

Covers:
- __init__ with service_api_key
- __init__ with service_account (credentials)
- _get_effective_api_key() priority resolution
- _login_service_account() lazy login
- save() using effective API key
- delete() using effective API key
- quickstart() / connect() / login() parameter passthrough
"""

import unittest
import json
from unittest.mock import Mock, MagicMock, patch, PropertyMock
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '../src'))

from supero import Supero, quickstart, connect, SchemaProxy


# ============================================================================
# Test Helpers (matching existing test_supero_core.py patterns)
# ============================================================================

def create_mock_load_lib_return():
    """Create proper return value for _load_py_api_lib_for_domain mock"""
    return (
        MagicMock,          # ApiLib class
        ['pymodel_system'], # SCHEMA_NAMESPACES
        'pymodel_system',   # PRIMARY_SCHEMA_NAMESPACE
        None,               # TENANT_NAMESPACE
        'py_api_lib'        # package name
    )


def create_mock_platform_client(domain_name="test-domain", domain_uuid="uuid-123"):
    """Create mock PlatformClient with domain context"""
    mock_client = MagicMock()
    mock_client.domain_name = domain_name
    mock_client.domain_uuid = domain_uuid
    mock_client.base_url = "http://localhost:8083/api/v1"
    return mock_client


def create_supero_instance(**kwargs):
    """
    Helper to create a Supero instance with all mocks in place.

    Accepts any kwargs to pass to Supero.__init__().
    Returns the Supero instance.
    """
    defaults = {
        'domain_name': 'test-domain',
    }
    defaults.update(kwargs)

    with patch('supero.core._load_py_api_lib_for_domain') as mock_load:
        mock_load.return_value = create_mock_load_lib_return()
        with patch('supero.core.PlatformClient') as mock_client_class:
            mock_client_class.return_value = create_mock_platform_client()
            with patch.object(Supero, '_ensure_domain', lambda self: None):
                def _mock_load_domain(self, api_key=None):
                    self._domain_obj = MagicMock()
                    self._domain_obj.uuid = 'test-uuid'
                    self._Supero__domain_uuid = 'test-uuid'
                with patch.object(Supero, '_load_existing_domain', _mock_load_domain):
                    org = Supero(**defaults)
    return org


# ============================================================================
# Test: __init__ with service account parameters
# ============================================================================

class TestServiceAccountInit(unittest.TestCase):
    """Test that __init__ accepts and stores service account params."""

    def test_init_with_service_api_key(self):
        """service_api_key should be stored on the instance."""
        org = create_supero_instance(service_api_key="ak_service_test_123")

        self.assertEqual(org._service_api_key, "ak_service_test_123")
        self.assertIsNone(org._service_account)
        self.assertIsNone(org._service_session_token)

    def test_init_with_service_account_credentials(self):
        """service_account dict should be stored on the instance."""
        creds = {"email": "svc@test.com", "password": "Secret123"}
        org = create_supero_instance(service_account=creds)

        self.assertEqual(org._service_account, creds)
        self.assertIsNone(org._service_api_key)

    def test_init_service_api_key_becomes_default_when_no_other_auth(self):
        """When no jwt_token and no api_key, service_api_key should be used as default."""
        org = create_supero_instance(service_api_key="ak_service_fallback")

        # The service_api_key should have been promoted to api_key on ApiLib
        # since no jwt_token or api_key was provided
        self.assertEqual(org._service_api_key, "ak_service_fallback")

    def test_init_jwt_takes_priority_over_service_key(self):
        """jwt_token should take priority - service_api_key is NOT promoted."""
        org = create_supero_instance(
            jwt_token="jwt-token-123",
            service_api_key="ak_service_fallback"
        )

        # JWT is primary auth, service key is stored but not promoted
        self.assertEqual(org._jwt_token, "jwt-token-123")
        self.assertEqual(org._service_api_key, "ak_service_fallback")

    def test_init_api_key_takes_priority_over_service_key(self):
        """Explicit api_key should take priority over service_api_key."""
        org = create_supero_instance(
            api_key="ak_user_primary",
            service_api_key="ak_service_fallback"
        )

        self.assertEqual(org._service_api_key, "ak_service_fallback")

    def test_init_without_service_account_defaults_to_none(self):
        """Without service params, fields should be None."""
        org = create_supero_instance()

        self.assertIsNone(org._service_api_key)
        self.assertIsNone(org._service_account)
        self.assertIsNone(org._service_session_token)


# ============================================================================
# Test: _get_effective_api_key() priority resolution
# ============================================================================

class TestGetEffectiveApiKey(unittest.TestCase):
    """Test the API key resolution priority chain."""

    def test_explicit_key_wins_over_everything(self):
        """Per-call api_key should always take highest priority."""
        org = create_supero_instance(
            jwt_token="jwt-123",
            service_api_key="ak_service"
        )

        result = org._get_effective_api_key("ak_explicit_user")
        self.assertEqual(result, "ak_explicit_user")

    def test_jwt_returns_none(self):
        """When JWT is set, return None (JWT auth handled by ApiLib)."""
        org = create_supero_instance(jwt_token="jwt-123")

        result = org._get_effective_api_key(None)
        self.assertIsNone(result)

    def test_service_api_key_used_when_no_jwt_no_apikey(self):
        """Service API key should be returned when no user auth exists."""
        org = create_supero_instance(service_api_key="ak_service_123")
        # Clear any JWT that might have been set
        org._jwt_token = None
        # Ensure ApiLib doesn't have api_key set
        org._api_lib._api_key = None

        result = org._get_effective_api_key(None)
        self.assertEqual(result, "ak_service_123")

    def test_service_account_triggers_lazy_login(self):
        """service_account credentials should trigger _login_service_account()."""
        creds = {"email": "svc@test.com", "password": "Secret123"}
        org = create_supero_instance(service_account=creds)
        org._jwt_token = None
        org._api_lib._api_key = None

        with patch.object(org, '_login_service_account') as mock_login:
            # After login, service_api_key gets set
            def set_key():
                org._service_api_key = "ak_from_login"
            mock_login.side_effect = set_key

            result = org._get_effective_api_key(None)

            mock_login.assert_called_once()
            self.assertEqual(result, "ak_from_login")

    def test_returns_none_when_no_auth_at_all(self):
        """When nothing is configured, return None."""
        org = create_supero_instance()
        org._jwt_token = None
        org._api_lib._api_key = None

        result = org._get_effective_api_key(None)
        self.assertIsNone(result)

    def test_explicit_key_overrides_service_key(self):
        """Per-call key should override even when service key exists."""
        org = create_supero_instance(service_api_key="ak_service")
        org._jwt_token = None
        org._api_lib._api_key = None

        result = org._get_effective_api_key("ak_user_override")
        self.assertEqual(result, "ak_user_override")


# ============================================================================
# Test: _login_service_account()
# ============================================================================

class TestLoginServiceAccount(unittest.TestCase):
    """Test the lazy service account login mechanism."""

    def test_login_with_jwt_response(self):
        """Should store JWT when login returns token."""
        creds = {"email": "svc@test.com", "password": "Secret123"}
        org = create_supero_instance(service_account=creds)

        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"token": "jwt-service-token-xyz"}

        # FIX: patch 'requests.post' not 'supero.core.requests.post'
        # because _login_service_account does `import requests as _requests`
        with patch('requests.post', return_value=mock_response) as mock_post:
            org._login_service_account()

        self.assertEqual(org._service_session_token, "jwt-service-token-xyz")
        # Verify login was called with correct params
        call_kwargs = mock_post.call_args
        body = call_kwargs[1].get('json') or call_kwargs[0][1] if len(call_kwargs[0]) > 1 else call_kwargs[1].get('json')
        self.assertEqual(body['email'], "svc@test.com")
        self.assertEqual(body['domain'], "test-domain")

    def test_login_with_api_key_response(self):
        """Should store API key when login returns api_key."""
        creds = {"email": "svc@test.com", "password": "Secret123"}
        org = create_supero_instance(service_account=creds)

        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"api_key": "ak_from_service_login"}

        with patch('requests.post', return_value=mock_response) as mock_post:
            org._login_service_account()

        self.assertEqual(org._service_api_key, "ak_from_service_login")

    def test_login_failure_raises_error(self):
        """Should raise AuthenticationError on login failure."""
        creds = {"email": "svc@test.com", "password": "wrong"}
        org = create_supero_instance(service_account=creds)

        mock_response = MagicMock()
        mock_response.status_code = 401
        mock_response.json.return_value = {"error": "Invalid credentials"}
        mock_response.text = "Invalid credentials"

        with patch('requests.post', return_value=mock_response):
            with self.assertRaises(Exception) as ctx:
                org._login_service_account()

            self.assertIn("login failed", str(ctx.exception).lower())

    def test_login_missing_email_raises_valueerror(self):
        """Should raise ValueError if email is missing."""
        creds = {"password": "Secret123"}  # No email
        org = create_supero_instance(service_account=creds)

        with self.assertRaises(ValueError) as ctx:
            org._login_service_account()

        self.assertIn("email", str(ctx.exception).lower())

    def test_login_missing_password_raises_valueerror(self):
        """Should raise ValueError if password is missing."""
        creds = {"email": "svc@test.com"}  # No password
        org = create_supero_instance(service_account=creds)

        with self.assertRaises(ValueError) as ctx:
            org._login_service_account()

        self.assertIn("password", str(ctx.exception).lower())

    def test_login_noop_when_no_service_account(self):
        """Should do nothing if no service_account configured."""
        org = create_supero_instance()

        # Should not raise or do anything
        org._login_service_account()
        self.assertIsNone(org._service_api_key)
        self.assertIsNone(org._service_session_token)

    def test_login_uses_project_tenant_from_context(self):
        """Should use project/tenant from login context if not in service_account."""
        creds = {"email": "svc@test.com", "password": "Secret123"}
        org = create_supero_instance(
            service_account=creds,
            project="dental-clinic",
            tenant="bright-smile"
        )

        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"token": "jwt-xyz"}

        with patch('requests.post', return_value=mock_response) as mock_post:
            org._login_service_account()

        call_kwargs = mock_post.call_args
        body = call_kwargs[1].get('json') or call_kwargs[0][1]
        self.assertEqual(body['project'], "dental-clinic")
        self.assertEqual(body['tenant'], "bright-smile")

    def test_login_uses_project_tenant_from_service_account_override(self):
        """service_account can override project/tenant."""
        creds = {
            "email": "svc@test.com",
            "password": "Secret123",
            "project": "custom-project",
            "tenant": "custom-tenant",
        }
        org = create_supero_instance(
            service_account=creds,
            project="dental-clinic",
            tenant="default-tenant"
        )

        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"token": "jwt-xyz"}

        with patch('requests.post', return_value=mock_response) as mock_post:
            org._login_service_account()

        call_kwargs = mock_post.call_args
        body = call_kwargs[1].get('json') or call_kwargs[0][1]
        self.assertEqual(body['project'], "custom-project")
        self.assertEqual(body['tenant'], "custom-tenant")

    def test_login_connection_error(self):
        """Should raise ConnectionError when platform-core is unreachable."""
        creds = {"email": "svc@test.com", "password": "Secret123"}
        org = create_supero_instance(service_account=creds)

        import requests as _requests
        # FIX: patch 'requests.post' not 'supero.core.requests.post'
        with patch('requests.post', side_effect=_requests.exceptions.ConnectionError("refused")):
            with self.assertRaises(ConnectionError):
                org._login_service_account()


# ============================================================================
# Test: save() with service account fallback
# ============================================================================

class TestSaveWithServiceAccount(unittest.TestCase):
    """Test that save() uses _get_effective_api_key for auth resolution."""

    def _make_mock_obj(self, has_uuid=False):
        """Create a mock schema object for save()."""
        obj = MagicMock()
        obj.obj_type = "appointment"
        if has_uuid:
            obj.uuid = "existing-uuid-123"
        else:
            obj.uuid = None
        obj.validate_mandatory_fields = MagicMock(return_value={'valid': True})
        return obj

    def test_save_create_uses_service_key_when_no_user_auth(self):
        """CREATE should use service API key when no user is logged in."""
        org = create_supero_instance(service_api_key="ak_service_key")
        org._jwt_token = None
        org._api_lib._api_key = None
        org._api_lib._object_create = MagicMock(return_value="new-uuid")
        org._api_lib._object_read = MagicMock(return_value=MagicMock())

        obj = self._make_mock_obj(has_uuid=False)
        org.save(obj)

        # Verify _object_create was called with the service key
        create_call = org._api_lib._object_create.call_args
        self.assertEqual(create_call[1].get('api_key'), "ak_service_key")

    def test_save_create_uses_explicit_key_over_service(self):
        """Explicit per-call api_key should override service key."""
        org = create_supero_instance(service_api_key="ak_service_key")
        org._jwt_token = None
        org._api_lib._api_key = None
        org._api_lib._object_create = MagicMock(return_value="new-uuid")
        org._api_lib._object_read = MagicMock(return_value=MagicMock())

        obj = self._make_mock_obj(has_uuid=False)
        org.save(obj, api_key="ak_user_specific")

        create_call = org._api_lib._object_create.call_args
        self.assertEqual(create_call[1].get('api_key'), "ak_user_specific")

    def test_save_update_uses_service_key(self):
        """UPDATE should also use service API key fallback."""
        org = create_supero_instance(service_api_key="ak_service_key")
        org._jwt_token = None
        org._api_lib._api_key = None
        org._api_lib._object_update = MagicMock()
        org._api_lib._object_read = MagicMock(return_value=MagicMock())

        obj = self._make_mock_obj(has_uuid=True)
        org.save(obj)

        update_call = org._api_lib._object_update.call_args
        self.assertEqual(update_call[1].get('api_key'), "ak_service_key")

    def test_save_with_jwt_does_not_use_service_key(self):
        """When JWT is active, service key should NOT be used."""
        org = create_supero_instance(
            jwt_token="jwt-user-token",
            service_api_key="ak_service_key"
        )
        org._api_lib._object_create = MagicMock(return_value="new-uuid")
        org._api_lib._object_read = MagicMock(return_value=MagicMock())

        obj = self._make_mock_obj(has_uuid=False)
        org.save(obj)

        create_call = org._api_lib._object_create.call_args
        # Should be None (JWT handles auth)
        self.assertIsNone(create_call[1].get('api_key'))


# ============================================================================
# Test: delete() with service account fallback
# ============================================================================

class TestDeleteWithServiceAccount(unittest.TestCase):
    """Test that delete() uses _get_effective_api_key."""

    def test_delete_uses_service_key(self):
        """delete() should use service API key when no user auth."""
        org = create_supero_instance(service_api_key="ak_service_key")
        org._jwt_token = None
        org._api_lib._api_key = None
        org._api_lib._object_delete = MagicMock()

        obj = MagicMock()
        obj.obj_type = "appointment"
        obj.uuid = "delete-me-uuid"

        org.delete(obj)

        delete_call = org._api_lib._object_delete.call_args
        self.assertEqual(delete_call[1].get('api_key'), "ak_service_key")

    def test_delete_explicit_key_overrides_service(self):
        """Per-call api_key should override service key in delete()."""
        org = create_supero_instance(service_api_key="ak_service_key")
        org._jwt_token = None
        org._api_lib._api_key = None
        org._api_lib._object_delete = MagicMock()

        obj = MagicMock()
        obj.obj_type = "appointment"
        obj.uuid = "delete-me-uuid"

        org.delete(obj, api_key="ak_admin_override")

        delete_call = org._api_lib._object_delete.call_args
        self.assertEqual(delete_call[1].get('api_key'), "ak_admin_override")


# ============================================================================
# Test: quickstart() / connect() / login() parameter passthrough
# ============================================================================

class TestFactoryMethodPassthrough(unittest.TestCase):
    """Test that factory methods pass service account params to __init__."""

    @patch('supero.core._load_py_api_lib_for_domain')
    @patch('supero.core.PlatformClient')
    def test_quickstart_passes_service_api_key(self, mock_client, mock_load_lib):
        """quickstart() should pass service_api_key to __init__."""
        mock_load_lib.return_value = create_mock_load_lib_return()
        mock_client.return_value = create_mock_platform_client()

        def _mock_load_domain(self_inst, api_key=None):
            self_inst._domain_obj = MagicMock()
            self_inst._domain_obj.uuid = 'test-uuid'
            self_inst._Supero__domain_uuid = 'test-uuid'

        with patch.object(Supero, '_ensure_domain', lambda self: None):
            with patch.object(Supero, '_load_existing_domain', _mock_load_domain):
                with patch('supero.init', return_value=None):
                    org = Supero.quickstart(
                        "test-domain",
                        service_api_key="ak_svc_via_quickstart"
                    )

        self.assertEqual(org._service_api_key, "ak_svc_via_quickstart")

    @patch('supero.core._load_py_api_lib_for_domain')
    @patch('supero.core.PlatformClient')
    def test_quickstart_passes_service_account(self, mock_client, mock_load_lib):
        """quickstart() should pass service_account to __init__."""
        mock_load_lib.return_value = create_mock_load_lib_return()
        mock_client.return_value = create_mock_platform_client()

        def _mock_load_domain(self_inst, api_key=None):
            self_inst._domain_obj = MagicMock()
            self_inst._domain_obj.uuid = 'test-uuid'
            self_inst._Supero__domain_uuid = 'test-uuid'

        creds = {"email": "svc@test.com", "password": "pass"}
        with patch.object(Supero, '_ensure_domain', lambda self: None):
            with patch.object(Supero, '_load_existing_domain', _mock_load_domain):
                with patch('supero.init', return_value=None):
                    org = Supero.quickstart(
                        "test-domain",
                        service_account=creds
                    )

        self.assertEqual(org._service_account, creds)

    @patch('supero.core._load_py_api_lib_for_domain')
    @patch('supero.core.PlatformClient')
    def test_connect_passes_service_params(self, mock_client, mock_load_lib):
        """connect() should pass service account params to __init__."""
        mock_load_lib.return_value = create_mock_load_lib_return()
        mock_client.return_value = create_mock_platform_client()

        def _mock_load_domain(self_inst, api_key=None):
            self_inst._domain_obj = MagicMock()
            self_inst._domain_obj.uuid = 'test-uuid'
            self_inst._Supero__domain_uuid = 'test-uuid'

        with patch.object(Supero, '_ensure_domain', lambda self: None):
            with patch.object(Supero, '_load_existing_domain', _mock_load_domain):
                org = Supero.connect(
                    "test-domain",
                    service_api_key="ak_svc_via_connect",
                    service_account={"email": "svc@test.com", "password": "pass"}
                )

        self.assertEqual(org._service_api_key, "ak_svc_via_connect")
        self.assertEqual(org._service_account["email"], "svc@test.com")


# ============================================================================
# Test: Integration scenario - anonymous dental appointment
# ============================================================================

class TestAnonymousOperationScenario(unittest.TestCase):
    """
    Integration-style test: anonymous patient creates appointment
    via service account fallback.
    """

    def test_anonymous_create_appointment_with_service_key(self):
        """
        Scenario: Patient walks in, no login.
        SDK manager uses service_api_key to create appointment.
        """
        org = create_supero_instance(service_api_key="ak_dental_service")
        org._jwt_token = None
        org._api_lib._api_key = None

        # Mock the create flow
        org._api_lib._object_create = MagicMock(return_value="apt-uuid-001")
        mock_saved = MagicMock()
        mock_saved.uuid = "apt-uuid-001"
        mock_saved.name = "apt-walkin-001"
        org._api_lib._object_read = MagicMock(return_value=mock_saved)

        # Create appointment object
        apt = MagicMock()
        apt.obj_type = "appointment"
        apt.uuid = None
        apt.validate_mandatory_fields = MagicMock(return_value={'valid': True})

        # Save it - should use service key
        result = org.save(apt)

        # Verify service key was used
        create_call = org._api_lib._object_create.call_args
        self.assertEqual(create_call[1]['api_key'], "ak_dental_service")
        self.assertIsNotNone(result)

    def test_anonymous_then_authenticated_operations(self):
        """
        Scenario: First anonymous, then user-specific operations.
        Service key for anonymous, explicit key for authenticated.
        """
        org = create_supero_instance(service_api_key="ak_dental_service")
        org._jwt_token = None
        org._api_lib._api_key = None
        org._api_lib._object_create = MagicMock(return_value="uuid-1")
        org._api_lib._object_read = MagicMock(return_value=MagicMock())

        # Anonymous create
        anon_apt = MagicMock()
        anon_apt.obj_type = "appointment"
        anon_apt.uuid = None
        anon_apt.validate_mandatory_fields = MagicMock(return_value={'valid': True})
        org.save(anon_apt)

        anon_call = org._api_lib._object_create.call_args
        self.assertEqual(anon_call[1]['api_key'], "ak_dental_service")

        # Authenticated create (user logged in, passes their key)
        org._api_lib._object_create.reset_mock()
        org._api_lib._object_create.return_value = "uuid-2"

        user_apt = MagicMock()
        user_apt.obj_type = "appointment"
        user_apt.uuid = None
        user_apt.validate_mandatory_fields = MagicMock(return_value={'valid': True})
        org.save(user_apt, api_key="ak_patient_john")

        user_call = org._api_lib._object_create.call_args
        self.assertEqual(user_call[1]['api_key'], "ak_patient_john")

    def test_service_account_lazy_login_then_create(self):
        """
        Scenario: service_account with email/password, lazy login on first create.
        """
        creds = {"email": "admin@dental.com", "password": "Admin123"}
        org = create_supero_instance(service_account=creds)
        org._jwt_token = None
        org._api_lib._api_key = None

        mock_login_response = MagicMock()
        mock_login_response.status_code = 200
        mock_login_response.json.return_value = {"token": "jwt-service-abc"}

        org._api_lib._object_create = MagicMock(return_value="uuid-new")
        org._api_lib._object_read = MagicMock(return_value=MagicMock())

        apt = MagicMock()
        apt.obj_type = "health_plan"
        apt.uuid = None
        apt.validate_mandatory_fields = MagicMock(return_value={'valid': True})

        # FIX: patch 'requests.post' not 'supero.core.requests.post'
        with patch('requests.post', return_value=mock_login_response):
            org.save(apt)

        # Verify lazy login happened - JWT should be set on ApiLib
        self.assertEqual(org._service_session_token, "jwt-service-abc")


# ============================================================================
# Run
# ============================================================================

if __name__ == '__main__':
    unittest.main(verbosity=2)
