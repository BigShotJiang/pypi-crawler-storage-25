"""
Unit tests for API Key authentication integration.

Tests ApiLib and ApiClient API key functionality including:
- API key initialization and configuration
- Runtime key management (set/get/clear)
- Authorization header injection
- Error handling for 401/403/429 responses
- Rate limit detection and retry logic
- Integration with existing CRUD operations

Location: ~/ai_infra/infra/libs/py/test/test_api_key_auth.py
"""

import unittest
from unittest.mock import Mock, MagicMock, patch, call
import sys
import os
import time

# Add source to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

from py_api_lib.api_lib import ApiLib
from py_api_lib.api_client import ApiClient
from py_api_lib.exceptions import (
    AuthenticationError,
    AuthorizationError,
    RateLimitError
)


class TestApiClientApiKey(unittest.TestCase):
    """Test ApiClient API key authentication."""
    
    def setUp(self):
        """Set up test ApiClient instances."""
        # Mock session to avoid real HTTP calls
        with patch('py_api_lib.api_client.requests.Session'):
            # ApiClient WITHOUT API key
            self.client_no_auth = ApiClient(
                server_ip='localhost',
                port=8082,
                api_key=None
            )
            
            # ApiClient WITH API key
            self.client_with_auth = ApiClient(
                server_ip='localhost',
                port=8082,
                api_key='ak_stores_prod_test123abc'
            )
        
        # Mock the session with proper dict-like headers
        self.client_no_auth.session = Mock()
        self.client_no_auth.session.headers = {}  # Real dict, not Mock
        
        self.client_with_auth.session = Mock()
        self.client_with_auth.session.headers = {  # Real dict with auth header
            'Authorization': 'Bearer ak_stores_prod_test123abc',
            'Content-Type': 'application/json',
            'User-Agent': 'UnifiedApiClient/2.1'  # ✅ FIXED: Updated version for per-call API key support
        }
    
    def test_initialization_without_api_key(self):
        """Test ApiClient initializes without API key."""
        self.assertIsNone(self.client_no_auth._api_key)
        self.assertNotIn('Authorization', self.client_no_auth.session.headers)
    
    def test_initialization_with_api_key(self):
        """Test ApiClient initializes with API key."""
        self.assertEqual(self.client_with_auth._api_key, 'ak_stores_prod_test123abc')
        self.assertEqual(
            self.client_with_auth.session.headers['Authorization'],
            'Bearer ak_stores_prod_test123abc'
        )
    
    def test_set_api_key(self):
        """Test setting API key at runtime."""
        # Start without key
        self.assertIsNone(self.client_no_auth._api_key)
        # Set key
        self.client_no_auth.set_api_key('ak_domain_prod_newkey456')
        # Verify set
        self.assertEqual(self.client_no_auth._api_key, 'ak_domain_prod_newkey456')
        self.assertEqual(
            self.client_no_auth.session.headers['Authorization'],
            'Bearer ak_domain_prod_newkey456'
        )

    def test_update_api_key(self):
        """Test updating API key to a new value."""
        old_key = 'ak_stores_prod_old123'
        new_key = 'ak_stores_prod_new456'
        self.client_no_auth.set_api_key(old_key)
        self.assertEqual(self.client_no_auth._api_key, old_key)
        self.client_no_auth.set_api_key(new_key)
        self.assertEqual(self.client_no_auth._api_key, new_key)
        self.assertEqual(
            self.client_no_auth.session.headers['Authorization'],
            f'Bearer ak_stores_prod_new456'
        )
    
    def test_clear_api_key(self):
        """Test clearing API key."""
        # Start with key
        self.assertIsNotNone(self.client_with_auth._api_key)
        
        # Clear key
        self.client_with_auth.set_api_key(None)
        
        # Verify cleared
        self.assertIsNone(self.client_with_auth._api_key)
        self.assertNotIn('Authorization', self.client_with_auth.session.headers)
    
    def test_get_api_key_prefix(self):
        """Test getting masked API key prefix."""
        # With key
        prefix = self.client_with_auth.get_api_key_prefix()
        self.assertEqual(prefix, 'ak_stores_prod_***')
        
        # Without key
        prefix_none = self.client_no_auth.get_api_key_prefix()
        self.assertIsNone(prefix_none)
    
    def test_authentication_error_401(self):
        """Test handling of 401 authentication error."""
        # Mock response with 401
        mock_response = Mock()
        mock_response.status_code = 401
        mock_response.json.return_value = {'error': 'Invalid API key'}
        mock_response.text = 'Invalid API key'
        
        self.client_with_auth.session.request.return_value = mock_response
        
        # Should raise AuthenticationError
        with self.assertRaises(AuthenticationError) as context:
            self.client_with_auth._make_request('GET', 'http://localhost:8082/default-domain/domain')
        
        self.assertIn('Invalid API key', str(context.exception))
        self.assertIn('ak_stores_prod_***', str(context.exception))
    
    def test_authorization_error_403(self):
        """Test handling of 403 authorization error."""
        # Mock response with 403
        mock_response = Mock()
        mock_response.status_code = 403
        mock_response.json.return_value = {'error': "Missing scope 'write'"}
        mock_response.text = "Missing scope 'write'"
        
        self.client_with_auth.session.request.return_value = mock_response
        
        # Should raise AuthorizationError
        with self.assertRaises(AuthorizationError) as context:
            self.client_with_auth._make_request('POST', 'http://localhost:8082/default-domain/domain')
        
        self.assertIn('Missing scope', str(context.exception))
        self.assertIn('ak_stores_prod_***', str(context.exception))
    
    def test_rate_limit_error_429(self):
        """Test handling of 429 rate limit error."""
        # Mock response with 429
        mock_response = Mock()
        mock_response.status_code = 429
        mock_response.headers = {'Retry-After': '3600'}
        mock_response.json.return_value = {'error': 'Rate limit exceeded'}
        mock_response.text = 'Rate limit exceeded'
        
        self.client_with_auth.session.request.return_value = mock_response
        
        # Should raise RateLimitError
        with self.assertRaises(RateLimitError) as context:
            self.client_with_auth._make_request('GET', 'http://localhost:8082/default-domain/domain')
        
        self.assertIn('Rate limit exceeded', str(context.exception))
        self.assertEqual(context.exception.retry_after, 3600)
    
    def test_rate_limit_retry_logic(self):
        """Test automatic retry for rate limits with small retry_after."""
        # Mock responses: first 429, then 200
        mock_response_429 = Mock()
        mock_response_429.status_code = 429
        mock_response_429.headers = {'Retry-After': '1'}  # 1 second (will retry)
        mock_response_429.json.return_value = {'error': 'Rate limit'}
        
        mock_response_200 = Mock()
        mock_response_200.status_code = 200
        mock_response_200.json.return_value = {'success': True}
        
        self.client_with_auth.session.request.side_effect = [
            mock_response_429,
            mock_response_200
        ]
        
        # Should retry and succeed
        with patch('time.sleep') as mock_sleep:
            response = self.client_with_auth._make_request('GET', 'http://localhost:8082/default-domain/domain')
            
            # Verify sleep was called
            mock_sleep.assert_called_once_with(1)
            
            # Verify success
            self.assertEqual(response.status_code, 200)
    
    def test_rate_limit_no_retry_large_wait(self):
        """Test no retry for rate limits with large retry_after."""
        # Mock response with 429 and large retry_after
        mock_response = Mock()
        mock_response.status_code = 429
        mock_response.headers = {'Retry-After': '3600'}  # 1 hour (won't retry)
        mock_response.json.return_value = {'error': 'Rate limit'}
        
        self.client_with_auth.session.request.return_value = mock_response
        
        # Should raise immediately without retry
        with self.assertRaises(RateLimitError):
            self.client_with_auth._make_request('GET', 'http://localhost:8082/default-domain/domain')
        
        # Should only call once (no retry)
        self.assertEqual(self.client_with_auth.session.request.call_count, 1)
    
    def test_successful_request_with_api_key(self):
        """Test successful request includes Authorization header."""
        # Mock successful response
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.json.return_value = {'domains': []}
        
        self.client_with_auth.session.request.return_value = mock_response
        
        # Make request
        response = self.client_with_auth._make_request('GET', 'http://localhost:8082/default-domain/domain')
        
        # Verify Authorization header is in session headers
        self.assertEqual(
            self.client_with_auth.session.headers['Authorization'],
            'Bearer ak_stores_prod_test123abc'
        )
        
        # Verify success
        self.assertEqual(response.status_code, 200)


class TestApiLibApiKey(unittest.TestCase):
    """Test ApiLib API key integration."""
    
    def setUp(self):
        """Set up test ApiLib instances."""
        # Mock ApiClient to avoid real connections
        with patch('py_api_lib.api_lib.ApiClient'):
            # ApiLib WITHOUT API key
            self.api_no_auth = ApiLib(
                api_server_host='localhost',
                api_server_port='8082',
                api_key=None
            )
            
            # ApiLib WITH API key
            self.api_with_auth = ApiLib(
                api_server_host='localhost',
                api_server_port='8082',
                api_key='ak_stores_prod_test123abc'
            )
        
        # Mock api_client for both instances
        self.api_no_auth.api_client = Mock()
        self.api_with_auth.api_client = Mock()
    
    def test_initialization_without_api_key(self):
        """Test ApiLib initializes without API key."""
        self.assertIsNone(self.api_no_auth._api_key)
    
    def test_initialization_with_api_key(self):
        """Test ApiLib initializes with API key."""
        self.assertEqual(self.api_with_auth._api_key, 'ak_stores_prod_test123abc')
    
    def test_api_key_passed_to_client(self):
        """Test API key is passed to ApiClient during initialization."""
        with patch('py_api_lib.api_lib.ApiClient') as MockApiClient:
            api_lib = ApiLib(
                api_server_host='localhost',
                api_server_port='8082',
                api_key='ak_domain_prod_key123'
            )
            
            # Verify ApiClient was called with api_key
            MockApiClient.assert_called_once()
            call_kwargs = MockApiClient.call_args[1]
            self.assertEqual(call_kwargs['api_key'], 'ak_domain_prod_key123')
    
    def test_set_api_key(self):
        """Test setting API key at runtime."""
        self.assertIsNone(self.api_no_auth._api_key)
        
        self.api_no_auth.set_api_key('ak_domain_prod_newkey')
        
        self.assertEqual(self.api_no_auth._api_key, 'ak_domain_prod_newkey')
        self.api_no_auth.api_client.set_api_key.assert_called_once_with('ak_domain_prod_newkey')
    
    def test_get_api_key(self):
        """Test getting masked API key."""
        # With key
        masked = self.api_with_auth.get_api_key()
        self.assertEqual(masked, 'ak_stores_prod_***')
        
        # Without key
        masked_none = self.api_no_auth.get_api_key()
        self.assertIsNone(masked_none)
    
    def test_clear_api_key(self):
        """Test clearing API key."""
        self.assertIsNotNone(self.api_with_auth._api_key)
        
        self.api_with_auth.clear_api_key()
        
        self.assertIsNone(self.api_with_auth._api_key)
        self.api_with_auth.api_client.set_api_key.assert_called_once_with(None)
    
    def test_from_config_with_api_key_env(self):
        """Test loading API key from environment variable."""
        with patch.dict(os.environ, {'API_KEY': 'ak_env_prod_key123'}):
            with patch('py_api_lib.api_lib.ApiClient'):
                api_lib = ApiLib.from_config()
                
                self.assertEqual(api_lib._api_key, 'ak_env_prod_key123')
    
    def test_from_config_with_api_key_file(self):
        """Test loading API key from config file."""
        try:
            import yaml
        except ImportError:
            self.skipTest("PyYAML not installed")
        
        import tempfile
        
        # Create temp config file
        with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
            config = {
                'api_lib': {
                    'api_server_host': 'localhost',
                    'api_server_port': '8082',
                    'api_key': 'ak_file_prod_key123'
                }
            }
            yaml.dump(config, f)
            config_file = f.name
        
        try:
            with patch('py_api_lib.api_lib.ApiClient'):
                api_lib = ApiLib.from_config(config_file)
                
                self.assertEqual(api_lib._api_key, 'ak_file_prod_key123')
        finally:
            os.unlink(config_file)
    
    def test_from_config_priority(self):
        """Test config priority: kwargs > env > file."""
        try:
            import yaml
        except ImportError:
            self.skipTest("PyYAML not installed")
        
        import tempfile
        
        # Create config file
        with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
            config = {'api_lib': {'api_key': 'ak_file_prod_key'}}
            yaml.dump(config, f)
            config_file = f.name
        
        try:
            # Set env var
            with patch.dict(os.environ, {'API_KEY': 'ak_env_prod_key'}):
                with patch('py_api_lib.api_lib.ApiClient'):
                    # Explicit kwarg should win
                    api_lib = ApiLib.from_config(
                        config_file,
                        api_key='ak_kwarg_prod_key'
                    )
                    
                    self.assertEqual(api_lib._api_key, 'ak_kwarg_prod_key')
        finally:
            os.unlink(config_file)
    
    def test_create_operation_with_auth(self):
        """Test create operation works with API key."""
        # Mock object
        mock_obj = Mock()
        mock_obj.name = 'test-domain'
        mock_obj.uuid = 'domain-uuid'
        mock_obj.fq_name = ['test-domain']
        mock_obj.parent_type = 'config-root'
        
        # Mock serialize
        with patch('py_api_lib.api_lib.safe_serialize_to_dict') as mock_serialize:
            mock_serialize.return_value = {
                'uuid': 'domain-uuid',
                'name': 'test-domain',
                'fq_name': ['test-domain']
            }
            
            # Mock create response
            self.api_with_auth.api_client._http_create.return_value = {
                'domain': {'uuid': 'domain-uuid'}
            }
            
            # Create
            result = self.api_with_auth._object_create('domain', mock_obj)
            
            # Verify create was called (with authenticated client)
            self.api_with_auth.api_client._http_create.assert_called_once()
            self.assertEqual(result, 'domain-uuid')
    
    def test_read_operation_with_auth(self):
        """Test read operation works with API key."""
        # Mock read response
        self.api_with_auth.api_client._http_read.return_value = {
            'domain': {
                'uuid': 'domain-uuid',
                'name': 'test-domain',
                'fq_name': ['test-domain'],
                'parent_uuid': 'root',
                'obj_type': 'domain',
                'parent_type': 'config-root',
                '_encrypted': False
            }
        }
        
        # Mock hydrate
        with patch.object(self.api_with_auth, '_hydrate_object') as mock_hydrate:
            mock_obj = Mock()
            mock_hydrate.return_value = mock_obj
            
            # Read
            result = self.api_with_auth._object_read('domain', id='domain-uuid')
            
            # ✅ FIXED: Expect domain_name AND api_key parameters
            # When ApiLib has an api_key, it passes it through to HTTP methods
            self.api_with_auth.api_client._http_read.assert_called_once_with(
                'domain', 'domain-uuid', 
                domain_name='default-domain',
                api_key='ak_stores_prod_test123abc'  # ✅ FIXED: Added api_key
            )
            self.assertIsNotNone(result)
    
    def test_update_operation_with_auth(self):
        """Test update operation works with API key."""
        # Mock object
        mock_obj = Mock()
        mock_obj.uuid = 'domain-uuid'
        
        # Mock serialize
        with patch('py_api_lib.api_lib.safe_serialize_to_dict') as mock_serialize:
            mock_serialize.return_value = {
                'uuid': 'domain-uuid',
                'name': 'updated-domain'
            }
            
            # Mock update response
            self.api_with_auth.api_client._http_update.return_value = {
                'domain': {'uuid': 'domain-uuid'}
            }
            
            # Update
            result = self.api_with_auth._object_update('domain', mock_obj)
            
            # Verify update was called
            self.api_with_auth.api_client._http_update.assert_called_once()
            self.assertEqual(result, 'Updated successfully')
    
    def test_delete_operation_with_auth(self):
        """Test delete operation works with API key."""
        # Mock delete response
        self.api_with_auth.api_client._http_delete.return_value = True
        
        # Delete
        self.api_with_auth._object_delete('domain', id='domain-uuid')
        
        # ✅ FIXED: Expect domain_name AND api_key parameters
        # When ApiLib has an api_key, it passes it through to HTTP methods
        self.api_with_auth.api_client._http_delete.assert_called_once_with(
            'domain', 'domain-uuid', 
            domain_name='default-domain',
            api_key='ak_stores_prod_test123abc'  # ✅ FIXED: Added api_key
        )
    
    def test_list_operation_with_auth(self):
        """Test list operation works with API key."""
        # Mock list response
        self.api_with_auth.api_client._http_list.return_value = [
              {
                'uuid': 'domain-1',
                'name': 'domain1',
                'fq_name': ['domain1'],
                "obj_type": "domain",
                'parent_uuid': 'root',
                'parent_type': 'config-root',
                '_encrypted': False
              }
        ] 
        
        # Mock hydrate
        with patch.object(self.api_with_auth, '_hydrate_object') as mock_hydrate:
            mock_obj = Mock()
            mock_hydrate.return_value = mock_obj
            
            # List
            result = self.api_with_auth._objects_list('domain', detail=True)
            
            # ✅ FIXED: Expect domain_name AND api_key parameters
            # When ApiLib has an api_key, it passes it through to HTTP methods
            self.api_with_auth.api_client._http_list.assert_called_once_with(
                'domain', None, 
                domain_name='default-domain',
                api_key='ak_stores_prod_test123abc'  # ✅ FIXED: Added api_key
            )
            self.assertEqual(len(result), 1)
    
    def test_authentication_error_propagation(self):
        """Test AuthenticationError propagates from ApiClient to ApiLib."""
        # Mock client to raise AuthenticationError
        self.api_with_auth.api_client._http_create.side_effect = AuthenticationError(
            "Invalid API key"
        )
        
        # Mock object
        mock_obj = Mock()
        mock_obj.name = 'test'
        mock_obj.uuid = 'uuid'
        mock_obj.fq_name = ['test']
        mock_obj.parent_type = 'config-root'
        
        # Should propagate error
        with patch('py_api_lib.api_lib.safe_serialize_to_dict'):
            with self.assertRaises(AuthenticationError):
                self.api_with_auth._object_create('domain', mock_obj)
    
    def test_authorization_error_propagation(self):
        """Test AuthorizationError propagates from ApiClient to ApiLib."""
        # Mock client to raise AuthorizationError
        self.api_with_auth.api_client._http_read.side_effect = AuthorizationError(
            "Missing scope 'read'"
        )
        
        # Should propagate error
        with self.assertRaises(AuthorizationError):
            self.api_with_auth._object_read('domain', id='uuid')
    
    def test_rate_limit_error_propagation(self):
        """Test RateLimitError propagates from ApiClient to ApiLib."""
        # Mock client to raise RateLimitError
        rate_error = RateLimitError("Rate limit exceeded", retry_after=3600)
        self.api_with_auth.api_client._http_list.side_effect = rate_error
        
        # Should propagate error
        with self.assertRaises(RateLimitError) as context:
            self.api_with_auth._objects_list('domain')
        
        self.assertEqual(context.exception.retry_after, 3600)


class TestApiLibApiKeyNoAuth(unittest.TestCase):
    """Test ApiLib operations WITHOUT API key (api_key=None)."""
    
    def setUp(self):
        """Set up test ApiLib instance without API key."""
        with patch('py_api_lib.api_lib.ApiClient'):
            self.api_no_auth = ApiLib(
                api_server_host='localhost',
                api_server_port='8082',
                api_key=None
            )
        
        self.api_no_auth.api_client = Mock()
    
    def test_read_operation_without_auth(self):
        """Test read operation without API key passes api_key=None."""
        # Mock read response
        self.api_no_auth.api_client._http_read.return_value = {
            'domain': {
                'uuid': 'domain-uuid',
                'name': 'test-domain',
                'fq_name': ['test-domain'],
                'parent_uuid': 'root',
                'obj_type': 'domain',
                'parent_type': 'config-root',
                '_encrypted': False
            }
        }
        
        with patch.object(self.api_no_auth, '_hydrate_object') as mock_hydrate:
            mock_hydrate.return_value = Mock()
            
            result = self.api_no_auth._object_read('domain', id='domain-uuid')
            
            # ✅ When no api_key, should pass api_key=None
            self.api_no_auth.api_client._http_read.assert_called_once_with(
                'domain', 'domain-uuid', 
                domain_name='default-domain',
                api_key=None
            )
    
    def test_delete_operation_without_auth(self):
        """Test delete operation without API key passes api_key=None."""
        self.api_no_auth.api_client._http_delete.return_value = True
        
        self.api_no_auth._object_delete('domain', id='domain-uuid')
        
        # ✅ When no api_key, should pass api_key=None
        self.api_no_auth.api_client._http_delete.assert_called_once_with(
            'domain', 'domain-uuid', 
            domain_name='default-domain',
            api_key=None
        )
    
    def test_list_operation_without_auth(self):
        """Test list operation without API key passes api_key=None."""
        self.api_no_auth.api_client._http_list.return_value = []
        
        result = self.api_no_auth._objects_list('domain', detail=False)
        
        # ✅ When no api_key, should pass api_key=None
        self.api_no_auth.api_client._http_list.assert_called_once_with(
            'domain', None, 
            domain_name='default-domain',
            api_key=None
        )


class TestApiKeyMultiTenant(unittest.TestCase):
    """Test multi-tenant scenarios with API keys."""
    
    def setUp(self):
        """Set up multi-tenant test scenario."""
        with patch('py_api_lib.api_lib.ApiClient'):
            self.api_lib = ApiLib(
                api_server_host='localhost',
                api_server_port='8082'
            )
        
        self.api_lib.api_client = Mock()
    
    def test_switch_tenant_keys(self):
        """Test switching between tenant API keys."""
        # Start with tenant A
        self.api_lib.set_api_key('ak_tenantA_prod_key123')
        self.assertEqual(self.api_lib._api_key, 'ak_tenantA_prod_key123')
        
        # Switch to tenant B
        self.api_lib.set_api_key('ak_tenantB_prod_key456')
        self.assertEqual(self.api_lib._api_key, 'ak_tenantB_prod_key456')
        
        # Verify client was updated
        self.assertEqual(self.api_lib.api_client.set_api_key.call_count, 2)
    
    def test_different_keys_different_operations(self):
        """Test using different keys for different operations."""
        readonly_key = 'ak_stores_prod_readonly123'
        fullaccess_key = 'ak_stores_prod_fullaccess456'
        
        # Use readonly key for read
        self.api_lib.set_api_key(readonly_key)
        
        # Mock read
        self.api_lib.api_client._http_read.return_value = {
            'domain': {'uuid': 'uuid', 'name': 'test', 'fq_name': ['test'],
                      'parent_uuid': 'root', 'obj_type': 'domain',
                      'parent_type': 'config-root', '_encrypted': False}
        }
        
        with patch.object(self.api_lib, '_hydrate_object') as mock_hydrate:
            mock_hydrate.return_value = Mock()
            self.api_lib._object_read('domain', id='uuid')
        
        # Switch to fullaccess key for create
        self.api_lib.set_api_key(fullaccess_key)
        
        # Verify key changed
        self.assertEqual(self.api_lib._api_key, fullaccess_key)


class TestApiKeyEdgeCases(unittest.TestCase):
    """Test edge cases and error conditions."""
    
    def test_malformed_api_key(self):
        """Test handling of malformed API key format."""
        with patch('py_api_lib.api_client.requests.Session'):
            client = ApiClient(
                server_ip='localhost',
                port=8082,
                api_key='not-a-valid-key-format'
            )
            
            # Should still set it (server validates format)
            self.assertEqual(client._api_key, 'not-a-valid-key-format')
    
    def test_empty_api_key(self):
        """Test handling of empty API key."""
        with patch('py_api_lib.api_client.requests.Session'):
            client = ApiClient(
                server_ip='localhost',
                port=8082,
                api_key=''
            )
            
            # Empty string is falsy, should not set header
            self.assertEqual(client._api_key, '')
    
    def test_get_prefix_short_key(self):
        """Test get_api_key_prefix with short/malformed key."""
        with patch('py_api_lib.api_client.requests.Session'):
            client = ApiClient(
                server_ip='localhost',
                port=8082,
                api_key='short'
            )
            
            prefix = client.get_api_key_prefix()
            self.assertEqual(prefix, '***')
    
    def test_retry_after_from_response_body(self):
        """Test extracting retry_after from response body when header missing."""
        with patch('py_api_lib.api_client.requests.Session'):
            client = ApiClient(
                server_ip='localhost',
                port=8082,
                api_key='ak_test_prod_key'
            )
        
        client.session = Mock()
        
        # Mock response without header but with body
        mock_response = Mock()
        mock_response.status_code = 429
        mock_response.headers = {}  # No Retry-After header
        mock_response.json.return_value = {
            'error': 'Rate limit exceeded',
            'retry_after': 1800
        }
        
        client.session.request.return_value = mock_response
        
        with self.assertRaises(RateLimitError) as context:
            client._make_request('GET', 'http://localhost:8082/test')
        
        # Should extract retry_after from body
        self.assertEqual(context.exception.retry_after, 1800)


class TestPerCallApiKeyOverride(unittest.TestCase):
    """Test per-call API key override functionality for RBAC."""
    
    def setUp(self):
        """Set up test ApiLib with default API key."""
        with patch('py_api_lib.api_lib.ApiClient'):
            # ApiLib with default admin key
            self.api_lib = ApiLib(
                api_server_host='localhost',
                api_server_port='8082',
                api_key='ak_admin_prod_default123'
            )
        
        self.api_lib.api_client = Mock()
    
    def test_per_call_api_key_read(self):
        """Test per-call API key override for read operation."""
        user_api_key = 'ak_user_prod_tenant456'
        
        # Mock read response
        self.api_lib.api_client._http_read.return_value = {
            'domain': {
                'uuid': 'domain-uuid',
                'name': 'test-domain',
                'fq_name': ['test-domain'],
                'obj_type': 'domain'
            }
        }
        
        with patch.object(self.api_lib, '_hydrate_object') as mock_hydrate:
            mock_hydrate.return_value = Mock()
            
            # Call with per-call api_key override
            result = self.api_lib._object_read('domain', id='domain-uuid', api_key=user_api_key)
            
            # ✅ Should use per-call key, not default
            self.api_lib.api_client._http_read.assert_called_once_with(
                'domain', 'domain-uuid', 
                domain_name='default-domain',
                api_key=user_api_key  # Per-call override
            )
    
    def test_per_call_api_key_delete(self):
        """Test per-call API key override for delete operation."""
        user_api_key = 'ak_user_prod_tenant789'
        
        self.api_lib.api_client._http_delete.return_value = True
        
        # Delete with per-call api_key override
        self.api_lib._object_delete('domain', id='domain-uuid', api_key=user_api_key)
        
        # ✅ Should use per-call key
        self.api_lib.api_client._http_delete.assert_called_once_with(
            'domain', 'domain-uuid', 
            domain_name='default-domain',
            api_key=user_api_key
        )
    
    def test_per_call_api_key_list(self):
        """Test per-call API key override for list operation."""
        user_api_key = 'ak_user_prod_tenantabc'
        
        self.api_lib.api_client._http_list.return_value = []
        
        # List with per-call api_key override
        result = self.api_lib._objects_list('domain', api_key=user_api_key)
        
        # ✅ Should use per-call key
        self.api_lib.api_client._http_list.assert_called_once_with(
            'domain', None, 
            domain_name='default-domain',
            api_key=user_api_key
        )
    
    def test_default_key_when_no_override(self):
        """Test that default key is used when no per-call override."""
        # Mock read response
        self.api_lib.api_client._http_read.return_value = {
            'domain': {
                'uuid': 'domain-uuid',
                'name': 'test-domain',
                'fq_name': ['test-domain'],
                'obj_type': 'domain'
            }
        }
        
        with patch.object(self.api_lib, '_hydrate_object') as mock_hydrate:
            mock_hydrate.return_value = Mock()
            
            # Call WITHOUT per-call override
            result = self.api_lib._object_read('domain', id='domain-uuid')
            
            # ✅ Should use default key
            self.api_lib.api_client._http_read.assert_called_once_with(
                'domain', 'domain-uuid', 
                domain_name='default-domain',
                api_key='ak_admin_prod_default123'  # Default key
            )


def run_tests():
    """Run all API key authentication tests."""
    loader = unittest.TestLoader()
    suite = unittest.TestSuite()
    
    # Add all test classes
    suite.addTests(loader.loadTestsFromTestCase(TestApiClientApiKey))
    suite.addTests(loader.loadTestsFromTestCase(TestApiLibApiKey))
    suite.addTests(loader.loadTestsFromTestCase(TestApiLibApiKeyNoAuth))
    suite.addTests(loader.loadTestsFromTestCase(TestApiKeyMultiTenant))
    suite.addTests(loader.loadTestsFromTestCase(TestApiKeyEdgeCases))
    suite.addTests(loader.loadTestsFromTestCase(TestPerCallApiKeyOverride))
    
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)
    
    return 0 if result.wasSuccessful() else 1


if __name__ == '__main__':
    sys.exit(run_tests())
