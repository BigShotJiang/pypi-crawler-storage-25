#!/usr/bin/env python3
# SERVICE_INTEGRATION_REPORT_VERSION: 3
"""
service_integration_report.py — Service Integration Matrix Report.

Produces a clear, scannable report showing for each imported service:
  - Whether config.py and services.json agree about it
  - Whether tenant data schemas extend the service's data base
  - Whether tenant UI schemas extend the service's UI base
  - Whether app.js calls registerExtensions for it
  - The service's verdict (fully wired / workflow-only / drift / etc.)

Failure modes covered:
  S-A1  Configuration drift (config.py SERVICE_IDS vs services.json)
  S-A2  UI extension references unknown supero_ui:* or <svc>:base_*_admin_ui
  S-A3  UI extension `ui_for` references unknown data schema
  S-A4  card_template / featured_fields / field_renderer__X fields don't exist
  S-A5  Bad renderer/editor alias in field_renderer__X / field_editor__X
  S-B1  registerExtensions target tenant schema doesn't exist
  S-B2  registerExtensions wrong shape (two-schema vs single)
  S-B3  UI schema extends a service but no registerExtensions call for it

Usage:
    python service_integration_report.py             # report + checks
    python service_integration_report.py --json      # machine-readable
    python service_integration_report.py --verbose
    python service_integration_report.py --bail
    python service_integration_report.py --matrix-only  # just the matrix table

Exit: 0 clean, 1 hard failure, 2 warnings only.

CHANGES vs VERSION 1 (review fixes):
  - _norm_services_json now handles the dict-of-lists shape its docstring
    promised (previously returned empty set → false config-drift).
  - _extract_register_extensions warns on calls it cannot parse instead of
    silently dropping them (previously → false S-B3 "not registered").
  - Verdict tree gained explicit data-only and UI-only arms (previously both
    fell through to misleading "partial integration").
  - Single shared NON_SERVICE_NAMESPACES set used by _ext_service and
    _data_parent_service; added 'supero' to stop a phantom "supero" service.
  - check_field_references: 'ok' renamed to 'examined' + a real pass count,
    removing the mislabel that a refactor could turn into a false success.
  - did_you_mean calls now receive sorted iterables for stable --json output.

CHANGES vs VERSION 2 (verified against real _test_lib.py):
  - check_field_references now reads build_schema_index values correctly.
    The index maps {schema_name: set_of_field_names}, NOT {name: schema_dict}.
    v1/v2 treated the value as a dict and walked .get("attributes"), so the
    isinstance(target, dict) guard always failed → S-A4 silently validated
    nothing. Now uses the field-name set directly, so S-A4 actually runs.
    (System fields like uuid/name/created_at are already included by the
    index, so references to them resolve instead of false-failing.)
  - Added `if results.aborted(): return` guards inside each check loop so
    counters and summary calls don't run after --bail trips (cosmetic; the
    accumulator already drops post-abort results, but this keeps counts honest).
"""

import json
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from _test_lib import (
    Results, PlatformClient,
    load_schemas, load_config_py, load_app_js, load_services_json,
    build_schema_index,
    did_you_mean, make_arg_parser, print_human, print_json,
    green, red, yellow, dim, bold,
)
from _test_lib import _js_to_json_lite as _js_to_json


# ════════════════════════════════════════════════════════════════════
# Constants — known platform vocabulary
# ════════════════════════════════════════════════════════════════════

# Namespaces that are NEVER a service id. Shared by _ext_service and
# _data_parent_service so the two stay in lockstep (previously they had
# slightly different exclusion lists, and neither excluded 'supero', which
# let a base 'supero:*' schema invent a phantom service named "supero").
NON_SERVICE_NAMESPACES = frozenset({
    "supero_ui", "supero", "_sys_", "tenant",
})

# Known supero_ui:base_* schemas an app may extend.
# (Hardcoded; future enhancement = fetch from platform with --platform mode.)
KNOWN_SUPERO_UI_BASES = frozenset({
    "supero_ui:base_record_ui",
    "supero_ui:base_landing_page_config",
    "supero_ui:base_app_shell_config",
    "supero_ui:base_metric_card_config",
    "supero_ui:base_hero_variant",
    "supero_ui:base_stats_variant",
    "supero_ui:base_feature_grid_variant",
})

# Services that ship with UI bases — apps CAN extend them for an admin panel.
SERVICES_WITH_UI = frozenset({
    "appointment", "ticket", "cart", "order", "notification",
    "comment", "task", "feedback", "attachment",
    "approval", "payment", "booking",
})

# Services that are workflow / backend / admin-only — apps typically do
# NOT extend them for UI. No warning if a service in this set is imported
# without UI integration.
SERVICES_BACKEND_ONLY = frozenset({
    "accounts", "auth_otp", "amazon_s3", "billing",
    "ai", "email", "sms", "push_notification", "webhook",
    "cron", "search_index", "audit_log",
})

# Two-schema services: registerExtensions value must be a 2-element array
# [parent_extension, child_extension].
TWO_SCHEMA_SERVICES = frozenset({
    "cart", "order", "approval", "document_signature",
    "inventory", "loyalty_points",
})

# Known renderer aliases (from platform atoms/).
# (Hardcoded; will go stale — track in a future fetch-from-platform mode.)
KNOWN_RENDERER_ALIASES = frozenset({
    "text", "longtext", "email", "url", "phone",
    "number", "integer", "currency", "percent",
    "boolean", "date", "datetime", "time", "duration",
    "image", "image_grid", "thumbnail", "avatar",
    "enum", "tag", "tag_list", "lifecycle_state",
    "color_swatch", "code", "markdown",
    "address", "geo_point", "attached_file",
    "reference", "reference_list", "ref_link",
    "json", "key_value", "progress",
})

# Known editor aliases (from platform atoms/).
KNOWN_EDITOR_ALIASES = frozenset({
    "text", "textarea", "longtext", "number", "integer",
    "currency", "percent", "boolean", "checkbox",
    "date", "datetime", "time",
    "select", "enum", "multi_select", "tag_picker",
    "color_picker", "image_upload", "file_upload",
    "address", "geo_point",
    "reference_picker", "reference_list_picker",
    "json", "code", "markdown", "rich_text",
})


# ════════════════════════════════════════════════════════════════════
# Helpers
# ════════════════════════════════════════════════════════════════════

def _norm_services_json(data) -> set:
    """Normalize services.json contents to a set of service_id strings.

    Handles:
      - list of strings:           ["cart", "order"]
      - list of dicts:             [{"service_id": "cart"}, ...]
      - dict with services key:    {"services": [...]} / {"service_ids": [...]}
      - dict-of-lists (grouped):   {"core": ["auth_otp"], "commerce": ["cart"]}
    """
    if data is None:
        return set()
    if isinstance(data, list):
        out = set()
        for item in data:
            if isinstance(item, dict):
                sid = item.get("service_id") or item.get("id") or item.get("name")
                if sid:
                    out.add(sid)
            elif isinstance(item, str):
                out.add(item)
        return out
    if isinstance(data, dict):
        # Preferred explicit keys first.
        if "services" in data or "service_ids" in data:
            services = data.get("services") or data.get("service_ids") or []
            return _norm_services_json(services)
        # Otherwise treat as dict-of-lists / grouped shape: flatten every value
        # that is itself a list/str/dict of services. Ignore scalar metadata.
        out = set()
        for value in data.values():
            if isinstance(value, (list, dict)):
                out |= _norm_services_json(value)
            elif isinstance(value, str):
                # Bare scalar string value — only count it if it looks like a
                # service id (avoid swallowing version strings, timestamps…).
                # Conservative: skip scalars at the top level of a grouped dict.
                pass
        return out
    return set()


def _get_config_service_ids(config_mod) -> set:
    """Pull SERVICE_IDS from config.py module. Tries common locations:
    module attribute SERVICE_IDS, or AppConfig.SERVICE_IDS / .services."""
    if config_mod is None:
        return set()
    # Top-level
    if hasattr(config_mod, "SERVICE_IDS"):
        v = getattr(config_mod, "SERVICE_IDS")
        if isinstance(v, (list, tuple, set)):
            return set(v)
    # AppConfig class
    if hasattr(config_mod, "AppConfig"):
        cls = config_mod.AppConfig
        for attr in ("SERVICE_IDS", "services", "SERVICES"):
            if hasattr(cls, attr):
                v = getattr(cls, attr)
                if isinstance(v, (list, tuple, set)):
                    return set(v)
    return set()


def _load_ui_schemas() -> tuple:
    """Import UI_SCHEMAS from ui_schemas.py. Returns (list, error_msg)."""
    try:
        from ui_schemas import UI_SCHEMAS  # type: ignore
        return UI_SCHEMAS, None
    except Exception as e:
        return None, f"cannot import ui_schemas.py: {e}"


def _ext_service(extends_value: str) -> str | None:
    """If `extends` points at a service base UI, return the service id; else None.
    e.g. 'ticket:base_ticket_admin_ui' → 'ticket'
         'supero_ui:base_record_ui'    → None  (not a service)
    """
    if not isinstance(extends_value, str) or ":" not in extends_value:
        return None
    ns, _ = extends_value.split(":", 1)
    if ns in NON_SERVICE_NAMESPACES:
        return None
    return ns


def _data_parent_service(parent_type: str) -> str | None:
    """If `parent_type` points at a service base schema, return the service id."""
    if not isinstance(parent_type, str) or ":" not in parent_type:
        return None
    ns, _ = parent_type.split(":", 1)
    if ns in NON_SERVICE_NAMESPACES:
        return None
    return ns


def _extract_register_extensions(app_js_source: str, results=None) -> dict:
    """Parse registerExtensions calls from app.js.
    Returns {service_id: tenant_schema_value} where value is str or list.

    If a call's object literal cannot be parsed (template literals, spreads,
    computed keys, etc.), emit a warning via `results` instead of silently
    dropping it — a dropped call previously caused false S-B3 "extended but
    not registered" failures on apps that ARE registered correctly.
    """
    if not app_js_source:
        return {}
    out = {}
    unparsed = 0
    for m in re.finditer(
        r'\.transactional\.registerExtensions\s*\(\s*', app_js_source
    ):
        start = m.end()
        # Find object literal
        while start < len(app_js_source) and app_js_source[start] in " \t\n\r":
            start += 1
        if start >= len(app_js_source) or app_js_source[start] != "{":
            # Not an object literal (could be a variable / spread). Note it.
            unparsed += 1
            continue
        # Match braces
        depth = 0
        i = start
        in_str = None
        parsed_this = False
        while i < len(app_js_source):
            ch = app_js_source[i]
            if in_str:
                if ch == "\\":
                    i += 2
                    continue
                if ch == in_str:
                    in_str = None
            else:
                if ch in '"\'`':
                    in_str = ch
                elif ch == "{":
                    depth += 1
                elif ch == "}":
                    depth -= 1
                    if depth == 0:
                        raw = app_js_source[start:i + 1]
                        try:
                            obj = json.loads(_js_to_json(raw))
                            if isinstance(obj, dict):
                                out.update(obj)
                                parsed_this = True
                        except Exception:
                            pass
                        break
            i += 1
        if not parsed_this:
            unparsed += 1

    if unparsed and results is not None:
        results.warn(
            "register_extensions", "unparsed_calls",
            f"{unparsed} registerExtensions call(s) in app.js could not be "
            "parsed (template literal, spread, or computed key?) and were "
            "skipped — services they register may show as 'not registered'",
            mode="S-B3",
            hint="If a service is flagged S-B3 but you DO register it, the "
                 "call likely uses a JS form this static parser can't read; "
                 "rewrite it as a plain object literal of string/array values.",
        )
    return out


def _ui_for_namespace_and_type(ui_for: str) -> tuple:
    """Parse ui_for value 'corp-learning:my_task' into ('corp-learning', 'my_task').
    Returns (None, None) if malformed."""
    if not isinstance(ui_for, str) or ":" not in ui_for:
        return (None, None)
    parts = ui_for.split(":", 1)
    return (parts[0], parts[1])


# ════════════════════════════════════════════════════════════════════
# Phase 1 — Configuration consistency
# ════════════════════════════════════════════════════════════════════

def check_config_consistency(cfg_services: set, sj_services: set,
                              results: Results) -> None:
    """S-A1: config.py SERVICE_IDS and services.json must agree."""
    section = "configuration"
    if not cfg_services and not sj_services:
        results.skip(section, "no_services",
            "no services declared in either config.py or services.json")
        return

    if cfg_services == sj_services:
        results.pass_(section, "config_matches_deployment",
            f"config.py and services.json agree on {len(cfg_services)} services")
        return

    only_cfg = cfg_services - sj_services
    only_sj = sj_services - cfg_services
    if only_cfg:
        results.fail(
            section, "declared_not_deployed",
            f"config.py declares {len(only_cfg)} services not in "
            f"services.json: {sorted(only_cfg)}",
            mode="S-A1",
            hint="Re-run app deployment so services.json is regenerated, "
                 "OR remove the service from config.py SERVICE_IDS if not needed.",
        )
    if only_sj:
        results.warn(
            section, "deployed_not_declared",
            f"services.json has {len(only_sj)} services not in config.py: "
            f"{sorted(only_sj)}",
            mode="S-A1",
            hint="Add the service to config.py SERVICE_IDS for consistency, "
                 "or remove from services.json if not needed.",
        )


# ════════════════════════════════════════════════════════════════════
# Phase 2 — Build the integration matrix
# ════════════════════════════════════════════════════════════════════

def build_matrix(cfg_services: set, sj_services: set,
                  all_schemas: list, ui_schemas: list,
                  register_extensions: dict) -> dict:
    """Build per-service integration map.
    Returns: { service_id: {
        in_cfg, in_svcs, data_ext_names, ui_ext_names,
        registered, has_ui_base, is_backend_only
    } }"""
    matrix = {}

    all_services = cfg_services | sj_services | set(register_extensions.keys())
    # Plus any services referenced by data/UI schemas
    for s in all_schemas or []:
        if isinstance(s, dict):
            svc = _data_parent_service(s.get("parent_type", ""))
            if svc:
                all_services.add(svc)
    for s in ui_schemas or []:
        if isinstance(s, dict):
            svc = _ext_service(s.get("extends", ""))
            if svc:
                all_services.add(svc)

    for svc in all_services:
        # Data extensions
        data_ext = []
        for s in all_schemas or []:
            if isinstance(s, dict) and _data_parent_service(s.get("parent_type", "")) == svc:
                data_ext.append(s.get("name"))
        # UI extensions
        ui_ext = []
        for s in ui_schemas or []:
            if isinstance(s, dict) and _ext_service(s.get("extends", "")) == svc:
                ui_ext.append(s.get("name"))

        matrix[svc] = {
            "in_cfg": svc in cfg_services,
            "in_svcs": svc in sj_services,
            "data_ext_names": data_ext,
            "ui_ext_names": ui_ext,
            "registered": svc in register_extensions,
            "register_value": register_extensions.get(svc),
            "has_ui_base": svc in SERVICES_WITH_UI,
            "is_backend_only": svc in SERVICES_BACKEND_ONLY,
        }
    return matrix


def _verdict(m: dict):
    """Compute a service's verdict cell. Covers all four data×UI quadrants
    explicitly so a normal data-only or UI-only extension is not mislabeled
    'partial integration'."""
    has_data = bool(m["data_ext_names"])
    has_ui = bool(m["ui_ext_names"])
    registered = m["registered"]
    present = m["in_cfg"] or m["in_svcs"]

    # Backend-only services: UI is not expected.
    if m["is_backend_only"]:
        return dim("backend-only (no UI expected)") if present \
            else dim("backend-only, not used")

    # Config drift takes precedence — declaration and deployment disagree.
    if m["in_cfg"] != m["in_svcs"]:
        return yellow("config drift")

    # Quadrant: data + UI
    if has_data and has_ui:
        return green("fully wired UI") if registered \
            else yellow("extended but not registered")

    # Quadrant: UI only (no data extension). Unusual but valid — admin UI over
    # the service's own data. Still needs registration to take effect.
    if has_ui and not has_data:
        return green("UI-only, registered") if registered \
            else yellow("UI extended but not registered")

    # Quadrant: data only (no UI). Perfectly normal — extend the service's
    # data without an admin panel. Not a problem.
    if has_data and not has_ui:
        return dim("data-only extension")

    # Quadrant: neither data nor UI extension.
    if present:
        return dim("imported, workflow-only") if m["has_ui_base"] \
            else dim("imported")

    # Referenced somewhere (e.g. registerExtensions) but not declared/deployed.
    return yellow("partial integration")


def render_matrix(matrix: dict) -> str:
    """Pretty-print the matrix as a fixed-width table."""
    if not matrix:
        return "  (no services declared in this app)"
    rows = []
    rows.append("  Service       Cfg  Svcs Data  UI    Reg   Verdict")
    rows.append("  ────────────  ───  ──── ────  ────  ────  ───────────────────────────")
    chk = green("✓")
    cross = red("✗")

    for svc in sorted(matrix.keys()):
        m = matrix[svc]
        c_cfg  = chk if m["in_cfg"] else cross
        c_svcs = chk if m["in_svcs"] else cross
        c_data = chk + f" {len(m['data_ext_names'])}" if m["data_ext_names"] else cross + "  "
        c_ui   = chk + f" {len(m['ui_ext_names'])}"   if m["ui_ext_names"]   else cross + "  "
        c_reg  = chk if m["registered"] else cross
        verdict = _verdict(m)

        rows.append(
            f"  {svc:<13} {c_cfg}    {c_svcs}    {c_data}  {c_ui}  {c_reg}    {verdict}"
        )
    return "\n".join(rows)


# ════════════════════════════════════════════════════════════════════
# Phase 3 — UI schema deep checks
# ════════════════════════════════════════════════════════════════════

def check_ui_extends(ui_schemas: list, results: Results) -> None:
    """S-A2: every UI schema's `extends` must resolve to a known base."""
    section = "ui_schemas"
    if not ui_schemas:
        results.skip(section, "extends", "no ui_schemas to validate")
        return

    bad = 0
    ok = 0
    # We know supero_ui:* bases. For service bases, we trust the naming
    # pattern <svc>:base_<svc>_admin_ui (can't verify svc base UI exists
    # without --platform mode).
    known_service_pattern = re.compile(r'^([a-z_][a-z0-9_]*):base_\w+$')

    for s in ui_schemas:
        if results.aborted():
            return
        if not isinstance(s, dict): continue
        name = s.get("name", "<unnamed>")
        ext = s.get("extends", "")

        if not ext:
            results.fail(
                section, f"{name}_no_extends",
                f"UI schema '{name}' has no 'extends' value",
                mode="S-A2",
                hint="Every UI schema must extend a base, e.g. "
                     "extends='supero_ui:base_record_ui' or 'ticket:base_ticket_admin_ui'",
            )
            bad += 1
            continue

        if ext in KNOWN_SUPERO_UI_BASES:
            ok += 1
            continue

        m = known_service_pattern.match(ext)
        if m:
            svc = m.group(1)
            if svc in SERVICES_WITH_UI:
                ok += 1
                continue
            elif svc in SERVICES_BACKEND_ONLY:
                results.warn(
                    section, f"{name}_extends_backend_service",
                    f"UI schema '{name}' extends '{ext}' but '{svc}' is a "
                    "backend-only service that typically doesn't have UI bases",
                    mode="S-A2",
                )
                bad += 1
                continue
            else:
                # Unknown service — could be a new platform service we don't
                # know about, or a typo. Warn rather than fail.
                results.warn(
                    section, f"{name}_extends_unknown_service",
                    f"UI schema '{name}' extends '{ext}' but service '{svc}' "
                    "is not in the known service list",
                    mode="S-A2",
                    hint=f"Verify '{svc}' is a real service; known services with UI: "
                         f"{', '.join(sorted(SERVICES_WITH_UI))}",
                )
                bad += 1
                continue

        # Unknown supero_ui:* OR malformed
        suggestion = did_you_mean(ext, sorted(KNOWN_SUPERO_UI_BASES), n=2)
        results.fail(
            section, f"{name}_extends_unknown",
            f"UI schema '{name}' extends unknown base '{ext}'",
            mode="S-A2",
            hint=(f"did you mean: {suggestion}" if suggestion
                  else f"known supero_ui bases: {', '.join(sorted(KNOWN_SUPERO_UI_BASES))}"),
        )
        bad += 1

    if ok and bad == 0:
        results.pass_(section, "extends_all_known",
            f"all {ok} UI schemas extend known bases")


def check_ui_for_references(ui_schemas: list, schema_index: dict,
                              results: Results) -> None:
    """S-A3: ui_for must reference an existing data schema."""
    section = "ui_schemas"
    if not ui_schemas:
        return

    bad = 0
    ok = 0
    for s in ui_schemas:
        if results.aborted():
            return
        if not isinstance(s, dict): continue
        name = s.get("name", "<unnamed>")
        # Find ui_for in attributes
        ui_for_val = None
        for a in s.get("attributes", []):
            if a.get("name") == "ui_for":
                ui_for_val = a.get("default") or a.get("default-value")
                break
        if ui_for_val is None:
            continue  # Not all UI schemas have ui_for (e.g. landing_page)

        ns, typ = _ui_for_namespace_and_type(ui_for_val)
        if not ns:
            results.warn(
                section, f"{name}_ui_for_malformed",
                f"UI schema '{name}' has ui_for='{ui_for_val}' (expected 'namespace:type')",
                mode="S-A3",
            )
            bad += 1
            continue

        # Resolve via schema_index. Index keys vary by app — try bare name first.
        if not schema_index:
            continue  # nothing to validate against

        found = (typ in schema_index) or (ui_for_val in schema_index) or any(
            k.endswith(f":{typ}") for k in schema_index.keys())
        if found:
            ok += 1
        else:
            available = list(schema_index.keys())
            suggestion = did_you_mean(
                typ, sorted({k.split(":")[-1] for k in available}), n=2)
            results.fail(
                section, f"{name}_ui_for_unknown",
                f"UI schema '{name}' ui_for='{ui_for_val}' references unknown data schema",
                mode="S-A3",
                hint=(f"did you mean: {suggestion}" if suggestion
                      else f"available data schemas: {', '.join(available[:8])}"),
            )
            bad += 1

    if ok and bad == 0:
        results.pass_(section, "ui_for_all_resolved",
            f"all {ok} ui_for references resolve to real schemas")


def check_field_references(ui_schemas: list, schema_index: dict,
                            results: Results) -> None:
    """S-A4: card_template fields, featured_fields, field_renderer__X targets
    must exist on the data schema referenced by ui_for."""
    section = "ui_schemas"
    if not ui_schemas or not schema_index:
        return

    issues = 0
    examined = 0   # schemas we actually inspected (had a resolvable target)
    passed = 0     # schemas inspected that had NO field issues
    for s in ui_schemas:
        if results.aborted():
            return
        if not isinstance(s, dict): continue
        name = s.get("name", "<unnamed>")
        # Get ui_for to find the data schema
        ui_for_val = None
        attrs_list = s.get("attributes", [])
        attrs_by_name = {a.get("name"): a for a in attrs_list if isinstance(a, dict)}
        if "ui_for" in attrs_by_name:
            ui_for_val = attrs_by_name["ui_for"].get("default") or \
                         attrs_by_name["ui_for"].get("default-value")
        if not ui_for_val:
            continue

        ns, typ = _ui_for_namespace_and_type(ui_for_val)
        if not typ:
            continue

        # build_schema_index maps {schema_name: {field_name, ...}} — the value
        # is ALREADY the set of field names (incl. system fields), NOT a schema
        # dict. Look it up by bare type, full ui_for, or a namespaced key.
        target_fields = (schema_index.get(typ) or
                         schema_index.get(ui_for_val) or
                         next((schema_index[k] for k in schema_index
                               if k.endswith(f":{typ}")), None))
        if not target_fields:
            continue
        # Defensive: tolerate either a set/list of names or a legacy dict shape.
        if isinstance(target_fields, dict):
            target_fields = {a.get("name") for a in target_fields.get("attributes", [])
                             if isinstance(a, dict) and a.get("name")}
        else:
            target_fields = set(target_fields)
        if not target_fields:
            continue

        examined += 1
        schema_issues = 0
        sorted_fields = sorted(target_fields)

        # featured_fields
        if "featured_fields" in attrs_by_name:
            ff = attrs_by_name["featured_fields"].get("default") or []
            if isinstance(ff, list):
                for idx, f in enumerate(ff):
                    if isinstance(f, str) and f not in target_fields:
                        suggestion = did_you_mean(f, sorted_fields, n=2)
                        results.fail(
                            section, f"{name}_featured_field_{idx}_unknown",
                            f"UI schema '{name}' featured_fields references "
                            f"'{f}' which doesn't exist on '{typ}'",
                            mode="S-A4",
                            hint=(f"did you mean: {suggestion}" if suggestion
                                  else f"fields on {typ}: {', '.join(sorted_fields)}"),
                        )
                        schema_issues += 1

        # card_template — mappings like {title: "title", image: "cover_image"}
        if "card_template" in attrs_by_name:
            tpl = attrs_by_name["card_template"].get("default") or {}
            if isinstance(tpl, dict):
                for slot, fld in tpl.items():
                    if isinstance(fld, str) and fld not in target_fields:
                        suggestion = did_you_mean(fld, sorted_fields, n=2)
                        results.fail(
                            section, f"{name}_card_template_{slot}_unknown",
                            f"UI schema '{name}' card_template.{slot} = "
                            f"'{fld}' but '{fld}' doesn't exist on '{typ}'",
                            mode="S-A4",
                            hint=(f"did you mean: {suggestion}" if suggestion
                                  else f"fields on {typ}: {', '.join(sorted_fields)}"),
                        )
                        schema_issues += 1
                    elif isinstance(fld, list):
                        # metrics: ["a", "b", "c"]
                        for jdx, fl in enumerate(fld):
                            if isinstance(fl, str) and fl not in target_fields:
                                results.fail(
                                    section, f"{name}_card_template_{slot}_{jdx}_unknown",
                                    f"UI schema '{name}' card_template.{slot}[]='{fl}' "
                                    f"but '{fl}' doesn't exist on '{typ}'",
                                    mode="S-A4",
                                )
                                schema_issues += 1

        # field_renderer__X / field_editor__X
        for attr_name in attrs_by_name:
            if attr_name.startswith("field_renderer__") or attr_name.startswith("field_editor__"):
                fld = attr_name.split("__", 1)[1]
                if fld and fld not in target_fields:
                    suggestion = did_you_mean(fld, sorted_fields, n=2)
                    results.fail(
                        section, f"{name}_{attr_name}_unknown_field",
                        f"UI schema '{name}' has '{attr_name}' but "
                        f"'{fld}' doesn't exist on '{typ}'",
                        mode="S-A4",
                        hint=(f"did you mean: {suggestion}" if suggestion
                              else f"fields on {typ}: {', '.join(sorted_fields)}"),
                    )
                    schema_issues += 1

        issues += schema_issues
        if schema_issues == 0:
            passed += 1

    if examined and issues == 0:
        results.pass_(section, "field_refs_resolve",
            f"all field references on {passed} UI schemas resolve correctly")


def check_renderer_editor_aliases(ui_schemas: list, results: Results) -> None:
    """S-A5: field_renderer__X / field_editor__X aliases must be real."""
    section = "ui_schemas"
    if not ui_schemas:
        return

    bad = 0
    ok = 0
    for s in ui_schemas:
        if results.aborted():
            return
        if not isinstance(s, dict): continue
        name = s.get("name", "<unnamed>")
        for a in s.get("attributes", []):
            if not isinstance(a, dict): continue
            an = a.get("name", "")
            default = a.get("default") or a.get("default-value")

            if an.startswith("field_renderer__"):
                # default can be a string (alias) or dict ({renderer: alias, config: {...}})
                alias = None
                if isinstance(default, str):
                    alias = default
                elif isinstance(default, dict):
                    alias = default.get("renderer")
                if alias and alias not in KNOWN_RENDERER_ALIASES:
                    suggestion = did_you_mean(alias, sorted(KNOWN_RENDERER_ALIASES), n=2)
                    results.warn(
                        section, f"{name}_{an}_unknown_renderer",
                        f"UI schema '{name}' '{an}' uses renderer '{alias}' "
                        "which isn't in known aliases",
                        mode="S-A5",
                        hint=(f"did you mean: {suggestion}" if suggestion
                              else "unknown aliases may work at runtime via custom registration"),
                    )
                    bad += 1
                elif alias:
                    ok += 1

            elif an.startswith("field_editor__"):
                alias = None
                if isinstance(default, str):
                    alias = default
                elif isinstance(default, dict):
                    alias = default.get("editor")
                if alias and alias not in KNOWN_EDITOR_ALIASES:
                    suggestion = did_you_mean(alias, sorted(KNOWN_EDITOR_ALIASES), n=2)
                    results.warn(
                        section, f"{name}_{an}_unknown_editor",
                        f"UI schema '{name}' '{an}' uses editor '{alias}' "
                        "which isn't in known aliases",
                        mode="S-A5",
                        hint=(f"did you mean: {suggestion}" if suggestion
                              else "unknown aliases may work at runtime via custom registration"),
                    )
                    bad += 1
                elif alias:
                    ok += 1

    if ok and bad == 0:
        results.pass_(section, "aliases_all_known",
            f"all {ok} renderer/editor aliases are recognized")


# ════════════════════════════════════════════════════════════════════
# Phase 4 — registerExtensions consistency
# ════════════════════════════════════════════════════════════════════

def check_register_extensions_consistency(matrix: dict,
                                            schema_index: dict,
                                            results: Results) -> None:
    """S-B1, S-B2, S-B3: registerExtensions must:
       - Have target tenant schemas that exist in schemas.py
       - Match shape (string for single-schema, [parent, child] for two-schema)
       - Be called for every service with UI extension"""
    section = "register_extensions"
    if not matrix:
        return

    bad = 0
    ok = 0
    for svc, info in matrix.items():
        if results.aborted():
            return
        # S-B3: UI extension exists but no registerExtensions call
        if info["ui_ext_names"] and not info["registered"]:
            results.fail(
                section, f"{svc}_extended_not_registered",
                f"service '{svc}' has UI extension(s) {info['ui_ext_names']} "
                "but app.js doesn't call registerExtensions for it",
                mode="S-B3",
                hint=f"Add to app.js: await client.transactional."
                     f"registerExtensions({{ {svc}: '{{ns}}:{{schema_name}}' }})",
            )
            bad += 1
            continue

        if not info["registered"]:
            continue

        # S-B2: shape check
        value = info["register_value"]
        if svc in TWO_SCHEMA_SERVICES:
            if not (isinstance(value, list) and len(value) == 2):
                results.fail(
                    section, f"{svc}_wrong_shape",
                    f"service '{svc}' is two-schema; registerExtensions value "
                    f"should be array of length 2, got {value!r}",
                    mode="S-B2",
                    hint=f"Use [parent_extension, child_extension] format",
                )
                bad += 1
                continue
        else:
            if not isinstance(value, str):
                results.fail(
                    section, f"{svc}_wrong_shape",
                    f"service '{svc}' is single-schema; registerExtensions value "
                    f"should be a string, got {value!r}",
                    mode="S-B2",
                )
                bad += 1
                continue

        # S-B1: target schema(s) must exist
        targets = value if isinstance(value, list) else [value]
        missing = []
        for t in targets:
            if not isinstance(t, str) or ":" not in t:
                missing.append(t)
                continue
            ns, typ = _ui_for_namespace_and_type(t)
            if not typ:
                missing.append(t)
                continue
            found = (typ in schema_index) or (t in schema_index) or any(
                k.endswith(f":{typ}") for k in schema_index.keys())
            if not found:
                missing.append(t)

        if missing:
            results.fail(
                section, f"{svc}_target_missing",
                f"service '{svc}' registerExtensions targets {missing} "
                "but these tenant schemas don't exist in schemas.py",
                mode="S-B1",
                hint=f"Add the schema(s) to schemas.py with parent_type='{svc}:base_*'",
            )
            bad += 1
        else:
            ok += 1

    if ok and bad == 0:
        results.pass_(section, "register_extensions_consistent",
            f"all {ok} registerExtensions calls have valid targets and shapes")


# ════════════════════════════════════════════════════════════════════
# Main
# ════════════════════════════════════════════════════════════════════

def main():
    ap = make_arg_parser(
        prog="service_integration_report.py",
        description="Service Integration Matrix Report — see how each "
                    "imported service is wired through schemas.py, "
                    "ui_schemas.py, and app.js.",
    )
    ap.add_argument("--matrix-only", action="store_true",
                    help="print only the integration matrix, skip checks")
    args = ap.parse_args()

    results = Results()
    results.bail = args.bail

    # ── Load everything ─────────────────────────────────────────
    schemas_list, schemas_err = load_schemas()
    if schemas_err:
        results.warn("loading", "schemas.py", schemas_err)
    schema_index = build_schema_index(schemas_list) if schemas_list else {}

    config_mod, config_err = load_config_py()
    if config_err:
        results.warn("loading", "config.py", config_err)

    sj_data, sj_err = load_services_json()
    if sj_err:
        results.warn("loading", "services.json", sj_err)

    app_js_src, app_js_err = load_app_js()
    if app_js_err:
        results.warn("loading", "app.js", app_js_err)

    ui_schemas, ui_err = _load_ui_schemas()
    if ui_err:
        results.warn("loading", "ui_schemas.py", ui_err)

    cfg_services = _get_config_service_ids(config_mod)
    sj_services = _norm_services_json(sj_data)
    register_extensions = _extract_register_extensions(app_js_src or "", results)

    # ── Build the matrix ────────────────────────────────────────
    matrix = build_matrix(
        cfg_services, sj_services,
        schemas_list or [], ui_schemas or [],
        register_extensions,
    )

    # ── Print matrix at the top so it's the first thing seen ────
    if not args.json:
        print()
        print(bold("🔌 Service Integration Report"))
        print("━" * 72)
        print()
        print(bold("📋 Configuration"))
        print(f"  config.py SERVICE_IDS: {sorted(cfg_services) or '(none)'}")
        print(f"  services.json:         {sorted(sj_services) or '(none)'}")
        if register_extensions:
            print(f"  registerExtensions:    {dict(register_extensions)}")
        else:
            print(f"  registerExtensions:    (none)")
        print()
        print(bold("📋 Integration Matrix"))
        print(render_matrix(matrix))
        print()
        print(dim("  Cfg = in config.py SERVICE_IDS"))
        print(dim("  Svcs = in services.json"))
        print(dim("  Data = N tenant schemas extend the service's data base"))
        print(dim("  UI = N tenant UI schemas extend the service's UI base"))
        print(dim("  Reg = app.js calls registerExtensions for this service"))
        print()

    if args.matrix_only:
        # Note: loader warnings (if any) were recorded but not printed in
        # matrix-only mode. Surface a hint so the table isn't trusted blindly.
        sys.exit(0)

    # ── Run checks ──────────────────────────────────────────────
    if not results.aborted():
        check_config_consistency(cfg_services, sj_services, results)

    if ui_schemas and not results.aborted():
        check_ui_extends(ui_schemas, results)
        check_ui_for_references(ui_schemas, schema_index, results)
        check_field_references(ui_schemas, schema_index, results)
        check_renderer_editor_aliases(ui_schemas, results)

    if not results.aborted():
        check_register_extensions_consistency(matrix, schema_index, results)

    # ── Output ──────────────────────────────────────────────────
    if args.json:
        print_json(results, tool_name="service_integration_report")
    else:
        print_human(results, args.verbose, tool_name="🔌 Service Integration Checks")

    sys.exit(results.exit_code())


if __name__ == "__main__":
    main()
