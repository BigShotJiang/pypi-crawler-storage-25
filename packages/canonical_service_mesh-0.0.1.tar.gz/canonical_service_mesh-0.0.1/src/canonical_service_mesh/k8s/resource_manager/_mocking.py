# Copyright 2025 Canonical Ltd.
# See LICENSE file for licensing details.

# pyright: reportArgumentType=false
# _FakeResponse is a duck-type stand-in for httpx.Response.

"""Tools for mocking with Lightkube."""

from lightkube.core.exceptions import ApiError


class _FakeResponse:
    """Used to fake an httpx response during testing only."""

    def __init__(self, code):
        self.code = code
        self.name = ""

    def json(self):
        reason = ""
        if self.code == 409:
            reason = "AlreadyExists"
        return {
            "apiVersion": 1,
            "code": self.code,
            "message": "broken",
            "reason": reason,
        }


class FakeApiError(ApiError):
    """Used to simulate an ApiError during testing."""

    def __init__(self, code=400):
        super().__init__(response=_FakeResponse(code))
