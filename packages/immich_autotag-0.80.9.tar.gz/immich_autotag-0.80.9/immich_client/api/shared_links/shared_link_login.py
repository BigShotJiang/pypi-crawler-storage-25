from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.shared_link_login_dto import SharedLinkLoginDto
from ...models.shared_link_response_dto import SharedLinkResponseDto
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    body: SharedLinkLoginDto,
    key: str | Unset = UNSET,
    slug: str | Unset = UNSET,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    params: dict[str, Any] = {}

    params["key"] = key

    params["slug"] = slug

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/shared-links/login",
        "params": params,
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> SharedLinkResponseDto | None:
    if response.status_code == 201:
        response_201 = SharedLinkResponseDto.from_dict(response.json())

        return response_201

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[SharedLinkResponseDto]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    body: SharedLinkLoginDto,
    key: str | Unset = UNSET,
    slug: str | Unset = UNSET,
) -> Response[SharedLinkResponseDto]:
    """Shared link login

     Login to a password protected shared link

    Args:
        key (str | Unset):
        slug (str | Unset):
        body (SharedLinkLoginDto):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[SharedLinkResponseDto]
    """

    kwargs = _get_kwargs(
        body=body,
        key=key,
        slug=slug,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    body: SharedLinkLoginDto,
    key: str | Unset = UNSET,
    slug: str | Unset = UNSET,
) -> SharedLinkResponseDto | None:
    """Shared link login

     Login to a password protected shared link

    Args:
        key (str | Unset):
        slug (str | Unset):
        body (SharedLinkLoginDto):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        SharedLinkResponseDto
    """

    return sync_detailed(
        client=client,
        body=body,
        key=key,
        slug=slug,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    body: SharedLinkLoginDto,
    key: str | Unset = UNSET,
    slug: str | Unset = UNSET,
) -> Response[SharedLinkResponseDto]:
    """Shared link login

     Login to a password protected shared link

    Args:
        key (str | Unset):
        slug (str | Unset):
        body (SharedLinkLoginDto):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[SharedLinkResponseDto]
    """

    kwargs = _get_kwargs(
        body=body,
        key=key,
        slug=slug,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    body: SharedLinkLoginDto,
    key: str | Unset = UNSET,
    slug: str | Unset = UNSET,
) -> SharedLinkResponseDto | None:
    """Shared link login

     Login to a password protected shared link

    Args:
        key (str | Unset):
        slug (str | Unset):
        body (SharedLinkLoginDto):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        SharedLinkResponseDto
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
            key=key,
            slug=slug,
        )
    ).parsed
