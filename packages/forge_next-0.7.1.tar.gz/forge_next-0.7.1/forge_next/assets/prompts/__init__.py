"""Bundled prompt templates."""

