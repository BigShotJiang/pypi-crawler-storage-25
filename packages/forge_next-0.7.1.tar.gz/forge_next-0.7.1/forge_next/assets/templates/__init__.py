"""Bundled non-prompt templates."""

