# standard
import io
import os
import base64
import mimetypes
from enum import Enum
from dataclasses import dataclass, field
from typing import Any, Callable

# third party
# custom

_ZIP_MAGIC = b"PK\x03\x04"

_EXT_OVERRIDES: dict[str, str] = {
    ".docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    ".xlsx": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    ".pptx": "application/vnd.openxmlformats-officedocument.presentationml.presentation",
    ".json": "application/json",
    ".pdf": "application/pdf",
}

_SUPPORTED_IMAGE_TYPES: frozenset[str] = frozenset(
    {
        "image/jpeg",
        "image/png",
        "image/gif",
        "image/webp",
    }
)

_SUPPORTED_DOCUMENT_TYPES: frozenset[str] = frozenset(
    {
        "application/json",
        "application/pdf",
        "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        "application/vnd.openxmlformats-officedocument.presentationml.presentation",
    }
)

_MAX_IMAGE_BYTES: int = 10 * 1024 * 1024  # 10MB
_MAX_DOCUMENT_BYTES: int = 20 * 1024 * 1024  # 20MB


@dataclass
class FileAttachment:
    data: bytes
    filename: str
    media_type: str = field(default="")

    def __post_init__(self) -> None:
        # media type
        if not self.media_type:
            ext = os.path.splitext(self.filename)[1].lower()
            if ext in _EXT_OVERRIDES:
                self.media_type = _EXT_OVERRIDES[ext]
            else:
                detected, _ = mimetypes.guess_type(self.filename)
                self.media_type = detected or "application/octet-stream"

        # NOTE: raise if unsupported format
        if not (self.media_type.startswith("text/") or self.media_type in _SUPPORTED_IMAGE_TYPES or self.media_type in _SUPPORTED_DOCUMENT_TYPES):
            raise ValueError(f"unsupported media type: {self.media_type!r}")

        # NOTE: reject ZIP-disguised-as-text files
        if self.media_type.startswith("text/") and len(self.data) >= 4 and self.data[:4] == _ZIP_MAGIC:
            raise ValueError("file content has ZIP magic bytes but media type is text/*")

        # enforce hard byte cap
        cap = _MAX_IMAGE_BYTES if self.is_image else _MAX_DOCUMENT_BYTES
        if len(self.data) > cap:
            limit_mb = cap // (1024 * 1024)
            raise ValueError(f"file {self.filename!r} exceeds {limit_mb} MB limit for {self.media_type!r}")

    @property
    def is_text(self) -> bool:
        return self.media_type.startswith("text/") or self.media_type in _SUPPORTED_DOCUMENT_TYPES

    @property
    def is_image(self) -> bool:
        return self.media_type in _SUPPORTED_IMAGE_TYPES

    def as_text(self) -> str:
        if self.media_type.startswith("text/") or self.media_type == "application/json":
            return self.data.decode("utf-8", errors="replace")
        if self.media_type == "application/pdf":
            return self._extract_pdf()
        if self.media_type == "application/vnd.openxmlformats-officedocument.wordprocessingml.document":
            return self._extract_docx()
        if self.media_type == "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet":
            return self._extract_xlsx()
        if self.media_type == "application/vnd.openxmlformats-officedocument.presentationml.presentation":
            return self._extract_pptx()
        return self.data.decode("utf-8", errors="replace")  # pragma: no cover

    def _extract_pdf(self) -> str:
        from pypdf import PdfReader

        reader = PdfReader(io.BytesIO(self.data))
        pages = []
        for page in reader.pages:
            text = page.extract_text() or ""
            if text.strip():
                pages.append(text)

        return "\n\n".join(pages)

    def _extract_docx(self) -> str:
        from docx import Document

        doc = Document(io.BytesIO(self.data))

        return "\n".join(p.text for p in doc.paragraphs if p.text.strip())

    def _extract_xlsx(self) -> str:
        from openpyxl import load_workbook

        wb = load_workbook(io.BytesIO(self.data), read_only=True, data_only=True)
        sections = []
        for name in wb.sheetnames:
            ws = wb[name]
            rows = []
            for row in ws.iter_rows(values_only=True):
                cells = [str(c) if c is not None else "" for c in row]
                rows.append("\t".join(cells))
            sections.append(f"[Sheet: {name}]\n" + "\n".join(rows))
        wb.close()

        return "\n\n".join(sections)

    def _extract_pptx(self) -> str:
        from pptx import Presentation

        prs = Presentation(io.BytesIO(self.data))
        sections = []
        for i, slide in enumerate(prs.slides, 1):
            texts = []
            for shape in slide.shapes:
                if shape.has_text_frame:
                    for para in shape.text_frame.paragraphs:
                        text = para.text.strip()
                        if text:
                            texts.append(text)
            if texts:
                sections.append(f"[Slide {i}]\n" + "\n".join(texts))

        return "\n\n".join(sections)

    def as_base64(self) -> str:
        return base64.b64encode(self.data).decode()


class StopReason(Enum):
    END_TURN = "end_turn"
    TOOL_USE = "tool_use"
    MAX_TOKENS = "max_tokens"


class Role(Enum):
    SYSTEM = "system"
    USER = "user"
    ASSISTANT = "assistant"
    TOOL = "tool"
    CONTEXT = "context"


@dataclass
class ToolCall:
    id: str
    name: str
    arguments: dict[str, Any]
    error: str | None = field(default=None)
    duration: float = field(default=0.0)
    results: list[dict] = field(default_factory=list)

    thought_signature: str | None = field(default=None)  # NOTE: google thoughtSignature required


@dataclass
class Message:
    role: Role
    content: str | None = None
    reasoning_content: str | None = None
    reasoning_signature: str | None = None  # NOTE: for anthropic signature and google thoughtSignature
    tool_call_id: str | None = None
    tool_calls: list[ToolCall] | None = None

    attachments: list[FileAttachment] | None = None  # NOTE: ignored on roles other than USER


@dataclass
class Tool:
    name: str
    description: str
    parameters: dict[str, Any]
    fn: Callable[..., Any] | None = field(default=None, repr=False)


def resolve_tokens(input_tokens: int, output_tokens: int, total_tokens: int) -> tuple[int, int, int]:
    """Normalize token counts across providers.

    Some providers (xAI, Google with thinking) exclude reasoning tokens from
    output_tokens but include them in total_tokens. When total is provided and
    doesn't match input+output we trust total and back-compute output_tokens.

    output_tokens is clamped to >= 0 to guard against providers that report
    total_tokens < input_tokens in edge cases.
    """

    if total_tokens == 0:
        total_tokens = input_tokens + output_tokens
    elif input_tokens + output_tokens != total_tokens:
        output_tokens = max(0, total_tokens - input_tokens)

    return input_tokens, output_tokens, total_tokens


@dataclass
class Error:
    message: str = ""
    status_code: int = 0


@dataclass
class Performance:
    latency: float = 0.0
    reasoning_duration: float = 0.0
    content_duration: float = 0.0
    total_duration: float = 0.0
    throughput: int = 0


@dataclass
class Cost:
    input: float = 0.0
    output: float = 0.0
    cache_read: float = 0.0
    cache_write: float = 0.0
    total: float = 0.0


@dataclass
class Usage:
    input_tokens: int = 0
    output_tokens: int = 0
    total_tokens: int = 0
    cache_read_tokens: int = 0
    cache_write_tokens: int = 0


def make_non_stream_performance(response: Response, total_duration: float) -> Performance:
    """Estimate reasoning/content split from character counts (non-streaming only)."""

    r_len = len(response.reasoning_content or "")
    c_len = len(response.content or "")
    total_chars = r_len + c_len

    reasoning_duration = 0.0
    content_duration = 0.0

    if total_chars > 0:
        reasoning_duration = r_len / total_chars * total_duration
        content_duration = c_len / total_chars * total_duration

    out_tok = response.usage.output_tokens if response.usage else 0
    throughput = max(1, int(out_tok / total_duration)) if out_tok > 0 and total_duration > 0 else 0

    return Performance(
        latency=round(total_duration, 2),
        reasoning_duration=round(reasoning_duration, 2),
        content_duration=round(content_duration, 2),
        total_duration=round(total_duration, 2),
        throughput=throughput,
    )


@dataclass
class Response:
    provider: str = ""
    model: str = ""
    streaming: bool = False
    synthetic: bool = False
    content: str | None = None
    reasoning_content: str | None = None
    reasoning_signature: str | None = None
    tool_calls: list[ToolCall] | None = None
    stop_reason: StopReason | None = None
    error: Error | None = None
    cost: Cost | None = None
    performance: Performance | None = None
    usage: Usage | None = None
