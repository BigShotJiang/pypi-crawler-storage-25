class EngineError(RuntimeError):
    """Base exception for all provider engine errors.

    Subclasses ``RuntimeError`` so existing ``except RuntimeError`` callers
    continue to work without changes.
    """

    def __init__(self, message: str, status_code: int = 0) -> None:
        super().__init__(message)
        self.status_code = status_code


class RateLimitError(EngineError):
    """HTTP 429 — provider rate limit exceeded."""


class AuthError(EngineError):
    """HTTP 401 / 403 — invalid or expired API key."""


class TransientError(EngineError):
    """HTTP 5xx — server-side failure that may succeed on retry."""


def raise_api_error(provider: str, status_code: int, body: str) -> None:
    """Raise the correct ``EngineError`` subclass for an HTTP error response.

    The body is truncated to 500 characters to prevent sensitive upstream data
    from being embedded verbatim in exception messages.
    """
    snippet = body[:500]
    msg = f"{provider} API error {status_code}: {snippet}"
    if status_code == 429:
        raise RateLimitError(msg, status_code=status_code)
    if status_code in (401, 403):
        raise AuthError(msg, status_code=status_code)
    if status_code >= 500:
        raise TransientError(msg, status_code=status_code)
    raise EngineError(msg, status_code=status_code)
