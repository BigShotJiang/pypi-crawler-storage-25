# standard
# third party
# custom
from ..model import Model, compute_cost
from . import anthropic, deepseek, google, moonshot, openai, xai

_ALL: list[Model] = sorted(
    anthropic.MODELS + deepseek.MODELS + google.MODELS + moonshot.MODELS + openai.MODELS + xai.MODELS,
    key=lambda m: (
        m.provider,
        -(int(m.release_date.replace("-", "")) if m.release_date else 0),
    ),
)

_INDEX: dict[str, Model] = {m.name: m for m in _ALL}


def get_model(name: str) -> Model | None:
    """Return the Model for the given name, or None if unknown."""

    return _INDEX.get(name)


def list_models() -> list[Model]:
    """Return all known models."""

    return _ALL


__all__ = ["Model", "compute_cost", "get_model", "list_models"]
