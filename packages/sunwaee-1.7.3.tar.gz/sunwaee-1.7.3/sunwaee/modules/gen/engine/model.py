# standard
from dataclasses import dataclass

# third party
# custom
from .types import Cost, Usage


@dataclass
class Model:
    name: str
    provider: str
    display_name: str
    description: str | None = None

    # basic specs
    context_window: int = 0
    max_output_tokens: int | None = None

    # features
    supports_vision: bool = False
    supports_tools: bool = False
    supports_reasoning: bool = False

    reasoning_mode: str | None = None  # None, dynamic, always
    reasoning_efforts: list[str] | None = None  # effort levels
    reasoning_uses_budget: bool = False  # True = effort strings map to integer token budgets
    reasoning_tokens_type: str | None = None  # raw, summary, None
    reasoning_disabled_payload: dict | None = None  # merge when disabling reasoning explicitly

    # NOTE: for models having 2 different variants for reasoning
    reasoning_id: str | None = None
    non_reasoning_id: str | None = None

    api_type: list[str] | None = None  # ["responses"], ["completions"], or both

    cache_min_tokens: int | None = None  # min tokens required for caching

    # pricing
    input_price_per_mtok: float | None = None
    output_price_per_mtok: float | None = None
    cache_read_price_per_mtok: float | None = None
    cache_write_price_per_mtok: float | None = None
    input_price_per_mtok_128k: float | None = None  # xai only
    output_price_per_mtok_128k: float | None = None  # xai only
    input_price_per_mtok_200k: float | None = None
    output_price_per_mtok_200k: float | None = None
    cache_read_price_per_mtok_200k: float | None = None
    cache_write_price_per_mtok_200k: float | None = None
    input_price_per_mtok_272k: float | None = None  # openai only
    output_price_per_mtok_272k: float | None = None  # openai only
    cache_read_price_per_mtok_272k: float | None = None  # openai only

    # dates
    release_date: str | None = None
    deprecated_at: str | None = None
    sunset_at: str | None = None


def _price_tier(usage: Usage, model: Model) -> tuple[float, float, float, float]:
    tok = usage.input_tokens

    if tok > 272_000 and model.input_price_per_mtok_272k is not None:
        return (
            model.input_price_per_mtok_272k,
            model.output_price_per_mtok_272k or model.output_price_per_mtok or 0,
            model.cache_read_price_per_mtok_272k or model.cache_read_price_per_mtok or 0,
            model.cache_write_price_per_mtok or 0,
        )
    if tok > 200_000 and model.input_price_per_mtok_200k is not None:
        return (
            model.input_price_per_mtok_200k,
            model.output_price_per_mtok_200k or model.output_price_per_mtok or 0,
            model.cache_read_price_per_mtok_200k or model.cache_read_price_per_mtok or 0,
            model.cache_write_price_per_mtok_200k or model.cache_write_price_per_mtok or 0,
        )
    if tok > 128_000 and model.input_price_per_mtok_128k is not None:
        return (
            model.input_price_per_mtok_128k,
            model.output_price_per_mtok_128k or model.output_price_per_mtok or 0,
            model.cache_read_price_per_mtok or 0,
            model.cache_write_price_per_mtok or 0,
        )
    return (
        model.input_price_per_mtok or 0,
        model.output_price_per_mtok or 0,
        model.cache_read_price_per_mtok or 0,
        model.cache_write_price_per_mtok or 0,
    )


def compute_cost(usage: Usage, model: Model) -> Cost:
    mtok = 1_000_000

    p_in, p_out, p_cr, p_cw = _price_tier(usage, model)

    regular_input = max(0, usage.input_tokens - usage.cache_read_tokens - usage.cache_write_tokens)
    input_cost = (regular_input / mtok) * p_in
    output_cost = (usage.output_tokens / mtok) * p_out
    cache_read_cost = (usage.cache_read_tokens / mtok) * p_cr
    cache_write_cost = (usage.cache_write_tokens / mtok) * p_cw

    return Cost(
        input=input_cost,
        output=output_cost,
        cache_read=cache_read_cost,
        cache_write=cache_write_cost,
        total=input_cost + output_cost + cache_read_cost + cache_write_cost,
    )
