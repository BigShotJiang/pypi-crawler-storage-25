# standard
import asyncio
import os
import weakref

# third party
import httpx

# custom
from sunwaee.utils.logger import get_logger
from .base import BaseEngine
from .models import get_model
from .providers.anthropic import AnthropicEngine
from .providers.completions import CompletionsEngine
from .providers.google import GoogleEngine
from .providers.responses import ResponsesEngine

_log = get_logger("engine.factory")

_OPENAI_COMPATIBLE: dict[str, str] = {
    "openai": "https://api.openai.com/v1",
    "deepseek": "https://api.deepseek.com/v1",
    "moonshot": "https://api.moonshot.ai/v1",
    "xai": "https://api.x.ai/v1",
}

# NOTE: effort -> thinking_budget token mapping for providers whose API uses integer budget
_ANTHROPIC_BUDGET: dict[str, int] = {"low": 2048, "medium": 8192, "high": 24_576}
_GOOGLE_BUDGET: dict[str, int] = {"low": 1024, "medium": 8192, "high": 24_576}

# NOTE: shared timeout and connection-pool settings for all provider clients.
_TIMEOUT = httpx.Timeout(connect=5.0, read=300.0, write=30.0, pool=5.0)
_LIMITS = httpx.Limits(max_connections=50, max_keepalive_connections=20)

# NOTE: one persistent AsyncClient per (event loop, base_url)
_HTTP_CLIENTS: weakref.WeakKeyDictionary[asyncio.AbstractEventLoop, dict[str, httpx.AsyncClient]] = weakref.WeakKeyDictionary()
_SYNC_HTTP_CLIENTS: dict[str, httpx.AsyncClient] = {}


def _get_client(base_url: str) -> httpx.AsyncClient:
    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        bucket = _SYNC_HTTP_CLIENTS
    else:
        bucket = _HTTP_CLIENTS.setdefault(loop, {})

    if base_url not in bucket:
        bucket[base_url] = httpx.AsyncClient(timeout=_TIMEOUT, limits=_LIMITS)

    return bucket[base_url]


async def close_all_clients() -> None:
    """Close and drain all pooled HTTP clients.

    Call this once during graceful shutdown (e.g. in a FastAPI ``lifespan``
    shutdown handler) to release all open TCP connections cleanly.
    """

    clients: list[httpx.AsyncClient] = []
    for bucket in list(_HTTP_CLIENTS.values()):
        clients.extend(bucket.values())
    clients.extend(_SYNC_HTTP_CLIENTS.values())

    await asyncio.gather(*(c.aclose() for c in clients), return_exceptions=True)

    _HTTP_CLIENTS.clear()
    _SYNC_HTTP_CLIENTS.clear()


def get_engine(
    provider: str,
    model: str,
    api_key: str | None = None,
    max_tokens: int = 8192,
    reasoning_effort: str | None = None,
) -> BaseEngine:
    p = provider.lower()

    resolved_key = api_key or os.environ.get(f"{p.upper()}_API_KEY")
    if not resolved_key:
        raise ValueError(f"No API key for provider '{provider}'. " f"Pass api_key= or set the {p.upper()}_API_KEY environment variable.")

    model_info = get_model(model)

    # NOTE: raise when passing reasoning_effort to a non-reasoning model
    if reasoning_effort and model_info is not None and not model_info.supports_reasoning:
        raise ValueError(f"reasoning_effort {reasoning_effort!r} cannot be applied to non-reasoning model {model_info.name}")

    # NOTE: pass "off" to dynamic models that support it when no reasoning_effort is passed
    if reasoning_effort is None and model_info is not None and model_info.reasoning_efforts and "off" in model_info.reasoning_efforts:
        reasoning_effort = "off"
        _log.debug("get_engine: coerced reasoning_effort to 'off' for dynamic model %r", model)

    # effort validation
    if reasoning_effort is not None and model_info is not None and model_info.reasoning_efforts:
        if reasoning_effort not in model_info.reasoning_efforts:
            raise ValueError(f"reasoning_effort {reasoning_effort!r} not in model.reasoning_efforts={model_info.reasoning_efforts}")

    # max_tokens resolution
    if model_info is not None and model_info.max_output_tokens:
        max_tokens = model_info.max_output_tokens

    # wire-id resolution for dynamic parents
    # reasoning_id / non_reasoning_id are raw wire-name strings sent in the
    # payload. They are NOT separate registry entries — model_info stays as
    # the user-facing parent throughout (pricing, vision, reasoning_tokens_type).
    wire_model = model
    if model_info is not None and model_info.reasoning_mode == "dynamic":
        if reasoning_effort in (None, "off") and model_info.non_reasoning_id:
            wire_model = model_info.non_reasoning_id
            _log.debug("get_engine: swapped %r -> non_reasoning wire_model %r", model, wire_model)
        elif reasoning_effort not in (None, "off") and model_info.reasoning_id:
            wire_model = model_info.reasoning_id
            _log.debug("get_engine: swapped %r -> reasoning wire_model %r", model, wire_model)

    _log.debug("get_engine: provider=%r model=%r wire=%r effort=%r max_tokens=%d", p, model, wire_model, reasoning_effort, max_tokens)

    # provider routing
    if p in _OPENAI_COMPATIBLE:
        base_url = _OPENAI_COMPATIBLE[p]
        api_types = model_info.api_type if model_info and model_info.api_type else ["completions"]
        if "responses" in api_types:
            return ResponsesEngine(
                provider=p,
                model=wire_model,
                api_key=resolved_key,
                base_url=base_url,
                max_tokens=max_tokens,
                reasoning_effort=reasoning_effort,
                model_info=model_info,
                client=_get_client(base_url),
            )
        return CompletionsEngine(
            provider=p,
            model=wire_model,
            api_key=resolved_key,
            base_url=base_url,
            max_tokens=max_tokens,
            reasoning_effort=reasoning_effort,
            model_info=model_info,
            client=_get_client(base_url),
        )

    if p == "anthropic":
        effort: str | None = None
        thinking_budget: int | None = None

        if model_info is not None and model_info.reasoning_efforts and not model_info.reasoning_uses_budget:
            # New effort-based models (Opus 4.7/4.6, Sonnet 4.6): pass effort through directly.
            effort = reasoning_effort
        elif reasoning_effort is not None and reasoning_effort != "off":
            # Budget models (Opus 4.5, Haiku 4.5, Sonnet 4.5): translate effort ->
            # thinking_budget token count. Clamp to max_tokens - 1024 (Anthropic
            # requires budget < max_tokens; need headroom for the final answer).
            if reasoning_effort not in _ANTHROPIC_BUDGET:
                raise ValueError(f"reasoning_effort {reasoning_effort!r} is not valid for this model; use one of {sorted(_ANTHROPIC_BUDGET)}")
            cap = max(1024, max_tokens - 1024)
            thinking_budget = min(_ANTHROPIC_BUDGET[reasoning_effort], cap)

        return AnthropicEngine(
            model=wire_model,
            api_key=resolved_key,
            max_tokens=max_tokens,
            thinking_budget=thinking_budget,
            effort=effort,
            model_info=model_info,
            client=_get_client(AnthropicEngine.BASE_URL),
        )

    if p == "google":
        thinking_budget_g: int | None = None
        thinking_level: str | None = None

        if model_info is not None:
            if reasoning_effort == "off":
                # Google rejects "off" as a thinkingLevel — use thinkingBudget=0 instead.
                thinking_budget_g = 0
            elif model_info.reasoning_uses_budget:
                # Gemini 2.5 budget models: translate effort -> integer thinkingBudget.
                if reasoning_effort is None:
                    thinking_budget_g = 0
                else:
                    if reasoning_effort not in _GOOGLE_BUDGET:
                        raise ValueError(f"reasoning_effort {reasoning_effort!r} is not valid for this model; use one of {sorted(_GOOGLE_BUDGET)}")
                    thinking_budget_g = _GOOGLE_BUDGET[reasoning_effort]
            elif model_info.reasoning_efforts and reasoning_effort not in (None, "auto"):
                # Gemini 3 series and always-reasoning level-controlled models: set thinkingLevel.
                thinking_level = reasoning_effort
            elif model_info.reasoning_efforts and reasoning_effort is None and model_info.reasoning_mode == "dynamic":
                # Dynamic Gemini 3 with no effort specified: default to first level.
                thinking_level = model_info.reasoning_efforts[0]
            # else: always-reasoning with auto/None (gemini-2.5-pro) -> let API decide.

        return GoogleEngine(
            model=wire_model,
            api_key=resolved_key,
            max_tokens=max_tokens,
            thinking_budget=thinking_budget_g,
            thinking_level=thinking_level,
            model_info=model_info,
            client=_get_client(GoogleEngine.BASE_URL),
        )

    raise ValueError(f"Unknown provider '{provider}'. " f"Supported: {', '.join(sorted({*_OPENAI_COMPATIBLE, 'anthropic', 'google'}))}")
