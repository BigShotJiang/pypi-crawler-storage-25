# standard
import asyncio

# third party
import pytest

# custom
from sunwaee.modules.gen.engine.factory import _HTTP_CLIENTS, _SYNC_HTTP_CLIENTS, _get_client, close_all_clients, get_engine
from sunwaee.modules.gen.engine.providers.anthropic import AnthropicEngine
from sunwaee.modules.gen.engine.providers.completions import CompletionsEngine
from sunwaee.modules.gen.engine.providers.google import GoogleEngine
from sunwaee.modules.gen.engine.providers.responses import ResponsesEngine

### HELPERS


def _monkeypatch_env(monkeypatch, provider: str, key: str = "env-key"):
    monkeypatch.setenv(f"{provider.upper()}_API_KEY", key)


### PROVIDER ROUTING


def test_get_engine_anthropic():
    engine = get_engine("anthropic", "claude-haiku-4-5", "key")

    assert isinstance(engine, AnthropicEngine)
    assert engine.model == "claude-haiku-4-5"


def test_get_engine_google():
    engine = get_engine("google", "gemini-2.5-flash", "key")

    assert isinstance(engine, GoogleEngine)
    assert engine.model == "gemini-2.5-flash"


def test_get_engine_openai_responses_model_routes_to_responses_engine():
    engine = get_engine("openai", "gpt-5.4-mini", "key")

    assert isinstance(engine, ResponsesEngine)
    assert engine.base_url == "https://api.openai.com/v1"


def test_get_engine_deepseek_routes_to_completions():
    engine = get_engine("deepseek", "deepseek-v3.2", "key")

    assert isinstance(engine, CompletionsEngine)
    assert "deepseek" in engine.base_url


def test_get_engine_moonshot_routes_to_completions():
    engine = get_engine("moonshot", "kimi-k2.5", "key")

    assert isinstance(engine, CompletionsEngine)
    assert "moonshot" in engine.base_url


def test_get_engine_xai_responses_model_routes_to_responses():
    engine = get_engine("xai", "grok-4-1-fast", "key")

    assert isinstance(engine, ResponsesEngine)
    assert "x.ai" in engine.base_url


def test_get_engine_unknown_openai_model_defaults_to_completions():
    engine = get_engine("openai", "totally-unknown-model", "key")

    assert isinstance(engine, CompletionsEngine)


def test_get_engine_unknown_provider():
    with pytest.raises(ValueError, match="Unknown provider"):
        get_engine("banana", "some-model", "key")


### API KEY RESOLUTION


def test_get_engine_api_key_from_env(monkeypatch):
    _monkeypatch_env(monkeypatch, "anthropic")
    engine = get_engine("anthropic", "claude-haiku-4-5")

    assert engine.api_key == "env-key"


def test_get_engine_explicit_key_takes_precedence(monkeypatch):
    _monkeypatch_env(monkeypatch, "anthropic", key="env-key")
    engine = get_engine("anthropic", "claude-haiku-4-5", api_key="explicit-key")

    assert engine.api_key == "explicit-key"


def test_get_engine_no_key_raises(monkeypatch):
    monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)
    with pytest.raises(ValueError, match="ANTHROPIC_API_KEY"):
        get_engine("anthropic", "claude-haiku-4-5")


### REASONING_EFFORT — wire-id resolution for dynamic parents


def test_dynamic_parent_effort_none_wires_to_non_reasoning_id():
    engine = get_engine("xai", "grok-4-1-fast", "key", reasoning_effort=None)

    assert engine.model == "grok-4-1-fast-non-reasoning"


def test_dynamic_parent_effort_off_wires_to_non_reasoning_id():
    engine = get_engine("xai", "grok-4-1-fast", "key", reasoning_effort="off")

    assert engine.model == "grok-4-1-fast-non-reasoning"


def test_dynamic_parent_effort_auto_wires_to_reasoning_id():
    engine = get_engine("xai", "grok-4-1-fast", "key", reasoning_effort="auto")

    assert engine.model == "grok-4-1-fast-reasoning"


def test_deepseek_parent_effort_auto_wires_to_reasoner():
    engine = get_engine("deepseek", "deepseek-v3.2", "key", reasoning_effort="auto")

    assert engine.model == "deepseek-reasoner"


def test_deepseek_parent_effort_none_wires_to_chat():
    engine = get_engine("deepseek", "deepseek-v3.2", "key", reasoning_effort=None)

    assert engine.model == "deepseek-chat"


def test_deepseek_parent_effort_off_wires_to_chat():
    engine = get_engine("deepseek", "deepseek-v3.2", "key", reasoning_effort="off")

    assert engine.model == "deepseek-chat"


def test_always_parent_without_pair_does_not_swap():
    engine = get_engine("xai", "grok-4", "key", reasoning_effort=None)

    assert engine.model == "grok-4"


### REASONING_EFFORT - validation


def test_reasoning_effort_invalid_raises():
    with pytest.raises(ValueError, match="reasoning_effort"):
        get_engine("openai", "gpt-5.4-mini", "key", reasoning_effort="not-a-level")


def test_reasoning_effort_on_non_reasoning_model_raises():
    with pytest.raises(ValueError, match="non-reasoning"):
        get_engine("openai", "gpt-4.1-nano", "key", reasoning_effort="high")


### REASONING_EFFORT — anthropic


def test_reasoning_effort_anthropic_effort_model_passes_through():
    engine = get_engine("anthropic", "claude-opus-4-7", "key", reasoning_effort="high")

    assert isinstance(engine, AnthropicEngine)
    assert engine.effort == "high"
    assert engine.thinking_budget is None


def test_reasoning_effort_none_anthropic_effort_model_coerces_to_off():
    engine = get_engine("anthropic", "claude-opus-4-7", "key", reasoning_effort=None)

    assert engine.effort == "off"
    assert engine.thinking_budget is None


def test_reasoning_effort_anthropic_budget_model_unmapped_effort_raises():
    with pytest.raises(ValueError, match="reasoning_effort"):
        get_engine("anthropic", "claude-haiku-4-5", "key", reasoning_effort="xhigh")


def test_reasoning_effort_anthropic_unknown_model_unmapped_budget_effort_raises():
    # model_info=None -> validation skipped -> budget path validates separately.
    with pytest.raises(ValueError, match="reasoning_effort"):
        get_engine("anthropic", "unknown-anthropic-model", "key", reasoning_effort="xhigh")


def test_reasoning_effort_anthropic_budget_model_valid_effort_maps_to_budget():
    engine = get_engine("anthropic", "claude-haiku-4-5", "key", reasoning_effort="medium")

    assert engine.thinking_budget == min(8192, max(1024, 64_000 - 1024))
    assert engine.effort is None


def test_reasoning_effort_none_anthropic_budget_model_no_thinking():
    engine = get_engine("anthropic", "claude-haiku-4-5", "key", reasoning_effort=None)

    assert engine.thinking_budget is None
    assert engine.effort is None


### REASONING_EFFORT — google


def test_reasoning_effort_gemini3_uses_thinking_level():
    engine = get_engine("google", "gemini-3-flash-preview", "key", reasoning_effort="high")

    assert engine.thinking_level == "high"
    assert engine.thinking_budget is None


def test_reasoning_effort_none_gemini3_disables_via_budget_zero():
    engine = get_engine("google", "gemini-3-flash-preview", "key", reasoning_effort=None)

    assert engine.thinking_budget == 0
    assert engine.thinking_level is None


def test_reasoning_effort_gemini25_low_maps_to_budget():
    engine = get_engine("google", "gemini-2.5-flash", "key", reasoning_effort="low")

    assert engine.thinking_budget == 1024


def test_reasoning_effort_gemini25_medium_maps_to_budget():
    engine = get_engine("google", "gemini-2.5-flash", "key", reasoning_effort="medium")

    assert engine.thinking_budget == 8192


def test_reasoning_effort_gemini25_high_maps_to_budget():
    engine = get_engine("google", "gemini-2.5-flash", "key", reasoning_effort="high")

    assert engine.thinking_budget == 24_576


def test_reasoning_effort_gemini25_unmapped_effort_raises():
    with pytest.raises(ValueError, match="reasoning_effort"):
        get_engine("google", "gemini-2.5-flash", "key", reasoning_effort="xhigh")


def test_reasoning_effort_none_gemini25_budget_zero():
    engine = get_engine("google", "gemini-2.5-flash", "key", reasoning_effort=None)

    assert engine.thinking_budget == 0
    assert engine.thinking_level is None


def test_reasoning_effort_gemini25_pro_always_no_swap():
    engine = get_engine("google", "gemini-2.5-pro", "key", reasoning_effort=None)

    assert engine.model == "gemini-2.5-pro"
    assert engine.thinking_budget is None
    assert engine.thinking_level is None


def test_reasoning_effort_gemini25_pro_auto_no_thinking_params():
    # "auto" on always-reasoning gemini-2.5-pro -> let API decide; no thinking params sent.
    engine = get_engine("google", "gemini-2.5-pro", "key", reasoning_effort="auto")

    assert engine.thinking_budget is None
    assert engine.thinking_level is None


def test_reasoning_effort_google_budget_without_off_none_defaults_to_budget_zero(monkeypatch):
    # Safety net: budget model without "off" in efforts + effort=None -> budget=0.
    from sunwaee.modules.gen.engine.model import Model

    fake = Model(
        name="fake-google-budget",
        display_name="Fake Google Budget",
        provider="google",
        supports_reasoning=True,
        reasoning_mode="dynamic",
        reasoning_efforts=["low", "medium", "high"],
        reasoning_uses_budget=True,
    )
    monkeypatch.setattr("sunwaee.modules.gen.engine.factory.get_model", lambda _: fake)

    engine = get_engine("google", "fake-google-budget", "key", reasoning_effort=None)

    assert engine.thinking_budget == 0
    assert engine.thinking_level is None


def test_reasoning_effort_google_budget_effort_not_in_budget_table_raises(monkeypatch):
    # Safety net: effort passes model.reasoning_efforts validation but isn't in _GOOGLE_BUDGET.
    from sunwaee.modules.gen.engine.model import Model

    fake = Model(
        name="fake-google-budget",
        display_name="Fake Google Budget",
        provider="google",
        supports_reasoning=True,
        reasoning_mode="dynamic",
        reasoning_efforts=["off", "low", "medium", "high", "xhigh"],
        reasoning_uses_budget=True,
    )
    monkeypatch.setattr("sunwaee.modules.gen.engine.factory.get_model", lambda _: fake)

    with pytest.raises(ValueError, match="reasoning_effort"):
        get_engine("google", "fake-google-budget", "key", reasoning_effort="xhigh")


def test_reasoning_effort_gemini31_pro_always_sets_thinking_level():
    # always-reasoning gemini-3.1-pro-preview: explicit effort sets thinkingLevel.
    engine = get_engine("google", "gemini-3.1-pro-preview", "key", reasoning_effort="medium")

    assert engine.thinking_level == "medium"
    assert engine.thinking_budget is None


def test_reasoning_effort_none_google_dynamic_without_off_defaults_to_first_effort(monkeypatch):
    from sunwaee.modules.gen.engine.model import Model

    fake = Model(
        name="fake-google-dynamic",
        display_name="Fake Google Dynamic",
        provider="google",
        supports_reasoning=True,
        reasoning_mode="dynamic",
        reasoning_efforts=["minimal", "low", "medium"],
    )
    monkeypatch.setattr("sunwaee.modules.gen.engine.factory.get_model", lambda _: fake)

    engine = get_engine("google", "fake-google-dynamic", "key", reasoning_effort=None)

    assert engine.thinking_level == "minimal"
    assert engine.thinking_budget is None


### REASONING_EFFORT - openai-compat


def test_reasoning_effort_openai_responses_engine_pass_through():
    engine = get_engine("openai", "gpt-5.4-mini", "key", reasoning_effort="high")

    assert isinstance(engine, ResponsesEngine)
    assert engine.reasoning_effort == "high"


def test_reasoning_effort_none_openai_responses_engine_coerces_to_off():
    # gpt-5.4-mini has "off" in efforts; effort=None coerces to "off".
    engine = get_engine("openai", "gpt-5.4-mini", "key", reasoning_effort=None)

    assert isinstance(engine, ResponsesEngine)
    assert engine.reasoning_effort == "off"


def test_reasoning_effort_xai_auto_on_always_model_routes_to_responses():
    engine = get_engine("xai", "grok-4-1-fast", "key", reasoning_effort="auto")

    assert isinstance(engine, ResponsesEngine)
    assert engine.reasoning_effort == "auto"


def test_reasoning_effort_moonshot_off_merges_disabled_payload():
    engine = get_engine("moonshot", "kimi-k2.5", "key", reasoning_effort="off")

    assert isinstance(engine, CompletionsEngine)
    assert engine._reasoning_disabled_payload == {"thinking": {"type": "disabled"}}


def test_reasoning_effort_moonshot_auto_no_disabled_payload():
    engine = get_engine("moonshot", "kimi-k2.5", "key", reasoning_effort="auto")

    assert engine._reasoning_disabled_payload is None


def test_reasoning_effort_moonshot_none_coerced_to_off_merges_payload():
    engine = get_engine("moonshot", "kimi-k2.5", "key", reasoning_effort=None)

    assert engine._reasoning_disabled_payload == {"thinking": {"type": "disabled"}}


### HTTP CLIENT POOL


@pytest.mark.asyncio
async def test_close_all_clients_clears_pool():
    get_engine("anthropic", "claude-haiku-4-5", "key")
    assert len(_HTTP_CLIENTS) > 0

    await close_all_clients()
    assert len(_HTTP_CLIENTS) == 0


@pytest.mark.asyncio
async def test_close_all_clients_is_idempotent():
    await close_all_clients()
    await close_all_clients()


@pytest.mark.asyncio
async def test_client_pool_keyed_by_loop_identity(monkeypatch):
    await close_all_clients()
    loop = asyncio.get_running_loop()
    c1 = _get_client("https://example.test")
    assert _HTTP_CLIENTS[loop]["https://example.test"] is c1
    assert _get_client("https://example.test") is c1
    await close_all_clients()


def test_sync_context_uses_fallback_bucket():
    asyncio.run(close_all_clients())
    c = _get_client("https://sync.test")
    assert _SYNC_HTTP_CLIENTS["https://sync.test"] is c
    asyncio.run(close_all_clients())
    assert "https://sync.test" not in _SYNC_HTTP_CLIENTS
