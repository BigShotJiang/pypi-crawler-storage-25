# custom
from sunwaee.modules.gen.engine.model import Model, compute_cost
from sunwaee.modules.gen.engine.models import get_model, list_models
from sunwaee.modules.gen.engine.types import Cost, Usage


def _model(
    input_price: float = 1.0,
    output_price: float = 2.0,
    cache_read: float = 0.1,
    cache_write: float = 0.2,
    input_128k: float | None = None,
    output_128k: float | None = None,
    input_200k: float | None = None,
    output_200k: float | None = None,
    cache_read_200k: float | None = None,
    cache_write_200k: float | None = None,
) -> Model:
    return Model(
        name="test-model",
        provider="test",
        display_name="Test Model",
        context_window=200_000,
        input_price_per_mtok=input_price,
        output_price_per_mtok=output_price,
        cache_read_price_per_mtok=cache_read,
        cache_write_price_per_mtok=cache_write,
        input_price_per_mtok_128k=input_128k,
        output_price_per_mtok_128k=output_128k,
        input_price_per_mtok_200k=input_200k,
        output_price_per_mtok_200k=output_200k,
        cache_read_price_per_mtok_200k=cache_read_200k,
        cache_write_price_per_mtok_200k=cache_write_200k,
    )


# base tier, no cache
def test_compute_cost_base_tier_no_cache():
    model = _model(input_price=1.0, output_price=2.0, cache_read=0.0, cache_write=0.0)
    usage = Usage(input_tokens=1_000_000, output_tokens=500_000)
    cost = compute_cost(usage, model)

    assert isinstance(cost, Cost)
    assert cost.input == 1
    assert cost.output == 1
    assert cost.cache_read == 0
    assert cost.cache_write == 0
    assert cost.total == 2


# base tier, with cache
def test_compute_cost_base_tier_with_cache():
    model = _model(input_price=3.0, output_price=15.0, cache_read=0.3, cache_write=3.75)
    usage = Usage(input_tokens=100_000, output_tokens=50_000, cache_read_tokens=20_000, cache_write_tokens=10_000)
    cost = compute_cost(usage, model)

    expected_input = (70_000 / 1_000_000) * 3.0
    expected_output = (50_000 / 1_000_000) * 15.0
    expected_cr = (20_000 / 1_000_000) * 0.3
    expected_cw = (10_000 / 1_000_000) * 3.75

    assert cost.input == expected_input
    assert cost.output == expected_output
    assert cost.cache_read == expected_cr
    assert cost.cache_write == expected_cw
    assert cost.total == expected_input + expected_output + expected_cr + expected_cw


# 128k tier
def test_compute_cost_128k_tier():
    model = _model(input_price=1.0, output_price=2.0, input_128k=5.0, output_128k=10.0)
    usage = Usage(input_tokens=150_000, output_tokens=10_000)
    cost = compute_cost(usage, model)

    expected_input = (150_000 / 1_000_000) * 5.0
    expected_output = (10_000 / 1_000_000) * 10.0

    assert cost.input == expected_input
    assert cost.output == expected_output


# 200k tier
def test_compute_cost_200k_tier():
    model = _model(
        input_price=1.0,
        output_price=2.0,
        cache_read=0.1,
        cache_write=0.2,
        input_200k=6.0,
        output_200k=22.5,
        cache_read_200k=0.6,
        cache_write_200k=7.5,
    )
    usage = Usage(input_tokens=250_000, output_tokens=5_000, cache_read_tokens=10_000, cache_write_tokens=0)
    cost = compute_cost(usage, model)
    regular = 250_000 - 10_000

    expected_input = (regular / 1_000_000) * 6.0
    expected_output = (5_000 / 1_000_000) * 22.5
    expected_cr = (10_000 / 1_000_000) * 0.6
    expected_cw = (0 / 1_000_000) * 7.5

    assert cost.input == expected_input
    assert cost.output == expected_output
    assert cost.cache_read == expected_cr
    assert cost.cache_write == expected_cw


# 272k tier
def test_compute_cost_272k_tier():
    model = Model(
        name="test-model",
        provider="test",
        display_name="Test Model",
        input_price_per_mtok=1.0,
        output_price_per_mtok=2.0,
        cache_read_price_per_mtok=0.1,
        cache_write_price_per_mtok=0.2,
        input_price_per_mtok_272k=8.0,
        output_price_per_mtok_272k=24.0,
        cache_read_price_per_mtok_272k=0.8,
    )
    usage = Usage(input_tokens=300_000, output_tokens=5_000, cache_read_tokens=10_000, cache_write_tokens=0)
    cost = compute_cost(usage, model)
    regular = 300_000 - 10_000

    expected_input = (regular / 1_000_000) * 8.0
    expected_output = (5_000 / 1_000_000) * 24.0
    expected_cr = (10_000 / 1_000_000) * 0.8

    assert cost.input == expected_input
    assert cost.output == expected_output
    assert cost.cache_read == expected_cr


def test_list_models_returns_nonempty():
    models = list_models()
    assert len(models) > 0
    assert all(isinstance(m, Model) for m in models)


def test_list_models_sorted_by_provider_then_date():
    models = list_models()
    providers = [m.provider for m in models]
    assert providers == sorted(providers)


def test_get_model_known():
    models = list_models()
    first = models[0]
    result = get_model(first.name)
    assert result is not None
    assert result.name == first.name


def test_get_model_unknown_returns_none():
    result = get_model("this-model-does-not-exist")
    assert result is None
