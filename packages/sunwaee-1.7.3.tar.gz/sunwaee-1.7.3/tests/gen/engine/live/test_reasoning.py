# standard
import os

# third party
import pytest

# custom
from sunwaee.modules.gen.engine.factory import get_engine
from sunwaee.modules.gen.engine.models import get_model
from sunwaee.modules.gen.engine.types import Message, Role, StopReason

from ._shared import (
    _assert_base_fields,
    _assert_usage_cost_perf,
    _key_for,
    _save,
    _to_dict,
)

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

# (provider, model, on_effort)
# on_effort is the effort that ENABLES reasoning:
#   "high" — adaptive effort models (anthropic, google, openai); budget models
#            (claude-haiku-4-5, gemini-2.5-flash) translate this to a token budget
#   "auto" — models where "auto" wires to a dedicated reasoner (deepseek-v3.2 ->
#            deepseek-reasoner, grok-4-1-fast -> reasoning variant) or signals
#            always-on thinking (kimi-k2.5, grok-code-fast-1, grok-4)
#   "low"  — always-reasoning models that expose a multi-level effort list
REASONING_ENGINES: list[tuple[str, str, str]] = [
    # --- dynamic · reasoning_tokens_type="raw" ---
    ("anthropic", "claude-haiku-4-5", "high"),  # budget (reasoning_uses_budget -> thinkingBudget)
    ("anthropic", "claude-sonnet-4-6", "high"),  # adaptive effort
    ("deepseek", "deepseek-v3.2", "auto"),  # "auto" wires to deepseek-reasoner
    ("moonshot", "kimi-k2.5", "auto"),  # "auto" enables extended thinking
    # --- dynamic · reasoning_tokens_type="summary" ---
    ("google", "gemini-3-flash-preview", "high"),  # adaptive effort
    ("google", "gemini-2.5-flash", "high"),  # budget (no reasoning_efforts)
    ("openai", "gpt-5.4-nano", "high"),  # adaptive effort
    # --- dynamic · reasoning_tokens_type=None (silent — tokens inaccessible) ---
    ("xai", "grok-4-1-fast", "auto"),  # "auto" wires to reasoning variant
    # --- always-reasoning · reasoning_tokens_type="raw" ---
    ("xai", "grok-code-fast-1", "auto"),  # single effort, always reasons
    # --- always-reasoning · reasoning_tokens_type="summary" ---
    ("google", "gemini-3.1-pro-preview", "low"),  # multi-effort, always reasons
    # --- always-reasoning · reasoning_tokens_type=None (silent) ---
    ("xai", "grok-4", "auto"),  # single effort, always reasons silently
]

_PROMPT = [Message(role=Role.USER, content="Respond with the single word 'ok'.")]

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _assert_valid_response(response, *, provider: str, model: str) -> None:
    _assert_base_fields(response, streaming=False)
    _assert_usage_cost_perf(response)
    assert response.stop_reason == StopReason.END_TURN, f"{provider}/{model}: unexpected stop_reason {response.stop_reason}"
    assert response.content, f"{provider}/{model}: content must be non-empty"


def _should_assert_reasoning(model_info, on_effort: str) -> bool:
    """Return True when the model reliably exposes reasoning_content for on_effort.

    False when reasoning_tokens_type is None (silent — tokens inaccessible via
    the API) or when the model uses adaptive effort (may skip thinking on trivial
    prompts, so asserting would make the test flaky).
    """
    if model_info.reasoning_tokens_type is None:
        return False
    if model_info.reasoning_mode == "always":
        return True
    if not model_info.reasoning_efforts:
        return True  # budget model — always reasons when effort is given
    if on_effort == "auto":
        return True  # "auto" wires to a dedicated reasoner; always produces thinking
    return False  # adaptive effort — may skip on trivial prompt


# ---------------------------------------------------------------------------
# Tests — reasoning ON
# ---------------------------------------------------------------------------


@pytest.mark.live
@pytest.mark.parametrize("provider,model,on_effort", REASONING_ENGINES)
async def test_reasoning_on(provider: str, model: str, on_effort: str) -> None:
    """reasoning_effort=<on_effort>: response valid; reliable models expose reasoning_content."""
    if not os.environ.get(_key_for(provider)):
        pytest.skip(f"{_key_for(provider)} not set")

    engine = get_engine(provider, model, reasoning_effort=on_effort)
    response = await engine.chat(_PROMPT)

    _save(_to_dict(response), f"reasoning_on_{provider}_{model}")
    _assert_valid_response(response, provider=provider, model=model)

    model_info = get_model(model)
    if model_info and _should_assert_reasoning(model_info, on_effort):
        assert response.reasoning_content, (
            f"{provider}/{model}: expected reasoning_content with effort={on_effort!r} "
            f"(tokens_type={model_info.reasoning_tokens_type!r}, "
            f"mode={model_info.reasoning_mode!r})"
        )


# ---------------------------------------------------------------------------
# Tests — reasoning OFF
# ---------------------------------------------------------------------------


@pytest.mark.live
@pytest.mark.parametrize("provider,model,on_effort", REASONING_ENGINES)
async def test_reasoning_off(provider: str, model: str, on_effort: str) -> None:
    """reasoning_effort=None: response valid; dynamic models don't reason; always models still reason."""
    del on_effort  # unused in OFF
    if not os.environ.get(_key_for(provider)):
        pytest.skip(f"{_key_for(provider)} not set")

    engine = get_engine(provider, model, reasoning_effort=None)
    response = await engine.chat(_PROMPT)

    _save(_to_dict(response), f"reasoning_off_{provider}_{model}")
    _assert_valid_response(response, provider=provider, model=model)

    model_info = get_model(model)
    if model_info is None:
        return

    if model_info.non_reasoning_id:
        # dynamic model with a paired non-reasoning variant — factory must have swapped
        assert response.model == model_info.non_reasoning_id, (
            f"{provider}/{model}: expected model swap to {model_info.non_reasoning_id!r}, " f"got {response.model!r}"
        )
        assert not response.reasoning_content, f"non-reasoning variant {model_info.non_reasoning_id!r} must not produce reasoning_content"
    elif model_info.reasoning_mode == "dynamic":
        # reasoning disabled via "off" effort or disabled payload — no tokens expected
        assert not response.reasoning_content, f"{provider}/{model}: dynamic model must not produce reasoning_content when disabled"
    # always-reasoning models (reasoning_mode="always") cannot be disabled at the
    # effort level — they continue to reason regardless of reasoning_effort=None.
    # No assertion; their output is verified by _assert_valid_response above.
