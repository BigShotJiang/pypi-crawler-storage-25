# standard
import os

# third party
import pytest

# custom
from sunwaee.modules.gen.engine.factory import get_engine
from sunwaee.modules.gen.engine.types import Response

from ._shared import (
    ENGINES,
    SCENARIO_NAMES,
    SCENARIOS,
    TOOLS,
    _TOOL_SCENARIOS,
    _assert_content_chunk,
    _assert_final_response,
    _collect_stream,
    _key_for,
    _save,
    _to_dict,
)


@pytest.mark.live
@pytest.mark.parametrize("scenario_name", SCENARIO_NAMES)
@pytest.mark.parametrize("provider,model", ENGINES)
async def test_chat_scenario(provider: str, model: str, scenario_name: str) -> None:
    """chat() must return a correctly populated Response for every scenario."""
    if not os.environ.get(_key_for(provider)):
        pytest.skip(f"{_key_for(provider)} not set")

    messages = SCENARIOS[scenario_name]
    tools = TOOLS if scenario_name in _TOOL_SCENARIOS else None

    engine = get_engine(provider, model)
    response = await engine.chat(messages, tools=tools)

    _save(_to_dict(response), f"{provider}_{model}_{scenario_name}_chat")
    _assert_final_response(response, streaming=False, scenario_name=scenario_name)

    if scenario_name == "SYSTEM_AND_USER":
        assert "<START>" in (response.content or "").upper(), f"system prompt not respected — content: {response.content!r}"


@pytest.mark.live
@pytest.mark.parametrize("scenario_name", SCENARIO_NAMES)
@pytest.mark.parametrize("provider,model", ENGINES)
async def test_stream_scenario(provider: str, model: str, scenario_name: str) -> None:
    """stream() must yield intermediate chunks followed by a terminal chunk
    that carries stop_reason, usage, performance, and cost.
    """
    if not os.environ.get(_key_for(provider)):
        pytest.skip(f"{_key_for(provider)} not set")

    messages = SCENARIOS[scenario_name]
    tools = TOOLS if scenario_name in _TOOL_SCENARIOS else None

    engine = get_engine(provider, model)
    chunks: list[Response] = [c async for c in engine.stream(messages, tools=tools)]

    _save({"chunks": [_to_dict(c) for c in chunks]}, f"{provider}_{model}_{scenario_name}_stream")

    assert chunks, "stream must yield at least one chunk"

    for i, chunk in enumerate(chunks):
        assert chunk.provider == provider, f"chunk[{i}].provider mismatch"
        assert chunk.model == model, f"chunk[{i}].model mismatch"
        assert chunk.streaming is True, f"chunk[{i}].streaming must be True"

    final = chunks[-1]

    if scenario_name == "ONLY_SYSTEM":
        assert final.provider
        assert final.model
        return

    intermediate = [c for c in chunks if c.stop_reason is None and not c.synthetic]
    for chunk in intermediate:
        _assert_content_chunk(chunk)

    _assert_final_response(final, streaming=True, scenario_name=scenario_name)

    accumulated_content, _, all_tool_calls = _collect_stream(chunks)

    if scenario_name in ("ONLY_USER", "SYSTEM_AND_USER"):
        assert accumulated_content, "accumulated content must be non-empty"

    if scenario_name == "SYSTEM_AND_USER":
        assert "<START>" in accumulated_content.upper(), f"system prompt not respected — accumulated: {accumulated_content!r}"

    if scenario_name == "TOOL_CALL":
        assert all_tool_calls, "no tool calls found across stream chunks"
        call = all_tool_calls[0]
        assert call.name == "update_chat", f"unexpected tool name: {call.name!r}"
        assert call.arguments.get("title") == "Test Chat", f"unexpected title argument: {call.arguments!r}"
