# standard
import os

# third party
import pytest

# custom
from sunwaee.modules.gen.engine.factory import get_engine
from sunwaee.modules.gen.engine.types import Message, Response, Role, StopReason

from ._shared import (
    ENGINES,
    SCENARIOS,
    TOOLS,
    _assert_content_chunk,
    _assert_final_response,
    _collect_stream,
    _execute_tool,
    _key_for,
    _save,
    _to_dict,
)


@pytest.mark.live
@pytest.mark.parametrize("provider,model", ENGINES)
async def test_chat_tool_call_result(provider: str, model: str) -> None:
    """Full tool-use loop via chat(): TOOL_CALL -> execute -> text reply."""
    if not os.environ.get(_key_for(provider)):
        pytest.skip(f"{_key_for(provider)} not set")

    engine = get_engine(provider, model)
    user_messages: list[Message] = list(SCENARIOS["TOOL_CALL"])

    tc_response = await engine.chat(user_messages, tools=TOOLS)
    assert tc_response.stop_reason == StopReason.TOOL_USE, f"expected TOOL_USE from step 1, got {tc_response.stop_reason}"
    assert tc_response.tool_calls, "expected tool_calls in step 1 response"

    assistant_msg = Message(
        role=Role.ASSISTANT,
        content=tc_response.content,
        reasoning_content=tc_response.reasoning_content,
        reasoning_signature=tc_response.reasoning_signature,
        tool_calls=tc_response.tool_calls,
    )
    tool_msgs = [
        Message(
            role=Role.TOOL,
            content=_execute_tool(tc.name, tc.arguments),
            tool_call_id=tc.id,
        )
        for tc in tc_response.tool_calls
    ]

    final_messages = user_messages + [assistant_msg] + tool_msgs
    final_response = await engine.chat(final_messages, tools=TOOLS)

    _save(
        {"tool_call_response": _to_dict(tc_response), "final_response": _to_dict(final_response)},
        f"{provider}_{model}_TOOL_CALL_RESULT_chat",
    )

    _assert_final_response(final_response, streaming=False, scenario_name="TOOL_CALL_RESULT")


@pytest.mark.live
@pytest.mark.parametrize("provider,model", ENGINES)
async def test_stream_tool_call_result(provider: str, model: str) -> None:
    """Full tool-use loop via stream(): TOOL_CALL -> execute -> text reply."""
    if not os.environ.get(_key_for(provider)):
        pytest.skip(f"{_key_for(provider)} not set")

    engine = get_engine(provider, model)
    user_messages: list[Message] = list(SCENARIOS["TOOL_CALL"])

    tc_chunks: list[Response] = [c async for c in engine.stream(user_messages, tools=TOOLS)]
    tc_final = tc_chunks[-1]
    assert tc_final.stop_reason == StopReason.TOOL_USE, f"expected TOOL_USE from step 1 stream, got {tc_final.stop_reason}"

    tc_content, tc_reasoning, all_tool_calls = _collect_stream(tc_chunks)
    tc_reasoning_sig = next((c.reasoning_signature for c in tc_chunks if c.reasoning_signature), None)
    assert all_tool_calls, "no tool calls found across step 1 stream chunks"

    assistant_msg = Message(
        role=Role.ASSISTANT,
        content=tc_content or None,
        reasoning_content=tc_reasoning or None,
        reasoning_signature=tc_reasoning_sig,
        tool_calls=all_tool_calls,
    )
    tool_msgs = [
        Message(
            role=Role.TOOL,
            content=_execute_tool(tc.name, tc.arguments),
            tool_call_id=tc.id,
        )
        for tc in all_tool_calls
    ]

    final_messages = user_messages + [assistant_msg] + tool_msgs
    final_chunks: list[Response] = [c async for c in engine.stream(final_messages, tools=TOOLS)]
    final = final_chunks[-1]

    _save(
        {"step1_chunks": [_to_dict(c) for c in tc_chunks], "step2_chunks": [_to_dict(c) for c in final_chunks]},
        f"{provider}_{model}_TOOL_CALL_RESULT_stream",
    )

    assert final_chunks, "step 2 stream must yield at least one chunk"

    for i, chunk in enumerate(final_chunks):
        assert chunk.provider == provider, f"step2 chunk[{i}].provider mismatch"
        assert chunk.model == model, f"step2 chunk[{i}].model mismatch"
        assert chunk.streaming is True

    intermediate = [c for c in final_chunks if c.stop_reason is None and not c.synthetic]
    for chunk in intermediate:
        _assert_content_chunk(chunk)

    _assert_final_response(final, streaming=True, scenario_name="TOOL_CALL_RESULT")

    accumulated_content, _, _ = _collect_stream(final_chunks)
    assert accumulated_content, "accumulated content must be non-empty after tool result"
