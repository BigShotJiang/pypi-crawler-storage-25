# standard
import os

# third party
import pytest

# custom
from sunwaee.modules.gen.engine.factory import get_engine
from sunwaee.modules.gen.engine.types import Message, Role

from ._shared import (
    CACHE_ENGINES,
    STRICT_CACHE_PROVIDERS,
    _STATIC_SYSTEM,
    _key_for,
    _save,
    _to_dict,
)


@pytest.mark.live
@pytest.mark.parametrize("provider,model", CACHE_ENGINES)
async def test_cache_two_turns(provider: str, model: str) -> None:
    """Static system + CONTEXT role: turn 2 must show cache_read_tokens >= 0 (> 0 for strict providers)."""
    if not os.environ.get(_key_for(provider)):
        pytest.skip(f"{_key_for(provider)} not set")

    engine = get_engine(provider, model)

    # Turn 1 — establish the cache
    t1_messages: list[Message] = [
        Message(role=Role.SYSTEM, content=_STATIC_SYSTEM),
        Message(role=Role.CONTEXT, content="date: 2026-01-01\nengine: test-model\nturn: 1"),
        Message(role=Role.USER, content="Reply with the single word 'ok'."),
    ]
    r1 = await engine.chat(t1_messages)
    assert r1.usage is not None, "turn 1: usage must be set"
    assert r1.content, "turn 1: content must be non-empty"

    # Turn 2 — same static system; history from turn 1; new context + user message
    t2_messages: list[Message] = [
        Message(role=Role.SYSTEM, content=_STATIC_SYSTEM),
        Message(role=Role.CONTEXT, content="date: 2026-01-01\nengine: test-model\nturn: 1"),
        Message(role=Role.USER, content="Reply with the single word 'ok'."),
        Message(role=Role.ASSISTANT, content=r1.content),
        Message(role=Role.CONTEXT, content="date: 2026-01-01\nengine: test-model\nturn: 2"),
        Message(role=Role.USER, content="Reply with the single word 'done'."),
    ]
    r2 = await engine.chat(t2_messages)
    assert r2.usage is not None, "turn 2: usage must be set"

    _save({"turn1": _to_dict(r1), "turn2": _to_dict(r2)}, f"{provider}_{model}_CACHE_two_turns")

    assert r2.usage.cache_read_tokens >= 0, "cache_read_tokens must be a non-negative integer"
    if provider in STRICT_CACHE_PROVIDERS:
        assert r2.usage.cache_read_tokens > 0, (
            f"turn 2: expected cache_read_tokens > 0 for {provider}/{model}; "
            f"got {r2.usage.cache_read_tokens} (turn 1 cache_write={r1.usage.cache_write_tokens})"
        )
