# standard
import os

# third party
import pytest

# custom
from sunwaee.modules.gen.engine.factory import get_engine
from sunwaee.modules.gen.engine.types import FileAttachment, Message, Response, Role, StopReason

from ._shared import (
    VISION_ENGINES,
    _PNG,
    _assert_base_fields,
    _assert_content_chunk,
    _assert_usage_cost_perf,
    _collect_stream,
    _key_for,
    _save,
    _to_dict,
)


@pytest.mark.live
@pytest.mark.parametrize("provider,model", VISION_ENGINES)
async def test_chat_image_attachment(provider: str, model: str) -> None:
    """chat() must accept a PNG image attachment and return a non-empty text reply."""
    if not os.environ.get(_key_for(provider)):
        pytest.skip(f"{_key_for(provider)} not set")

    engine = get_engine(provider, model)
    messages = [
        Message(
            role=Role.USER,
            content="Describe this image in one sentence.",
            attachments=[FileAttachment(data=_PNG, filename="pixel.png")],
        )
    ]
    response = await engine.chat(messages)

    _save(_to_dict(response), f"{provider}_{model}_IMAGE_ATTACHMENT_chat")

    _assert_base_fields(response, streaming=False)
    _assert_usage_cost_perf(response)
    assert response.stop_reason == StopReason.END_TURN
    assert response.content, "content must be non-empty after image attachment"
    assert response.tool_calls is None


@pytest.mark.live
@pytest.mark.parametrize("provider,model", VISION_ENGINES)
async def test_stream_image_attachment(provider: str, model: str) -> None:
    """stream() must accept a PNG image attachment and yield a non-empty text reply."""
    if not os.environ.get(_key_for(provider)):
        pytest.skip(f"{_key_for(provider)} not set")

    engine = get_engine(provider, model)
    messages = [
        Message(
            role=Role.USER,
            content="Describe this image in one sentence.",
            attachments=[FileAttachment(data=_PNG, filename="pixel.png")],
        )
    ]
    chunks: list[Response] = [c async for c in engine.stream(messages)]

    _save({"chunks": [_to_dict(c) for c in chunks]}, f"{provider}_{model}_IMAGE_ATTACHMENT_stream")

    assert chunks
    final = chunks[-1]

    for i, chunk in enumerate(chunks):
        assert chunk.provider == provider, f"chunk[{i}].provider mismatch"
        assert chunk.model == model, f"chunk[{i}].model mismatch"
        assert chunk.streaming is True

    intermediate = [c for c in chunks if c.stop_reason is None and not c.synthetic]
    for chunk in intermediate:
        _assert_content_chunk(chunk)

    _assert_base_fields(final, streaming=True)
    _assert_usage_cost_perf(final)
    assert final.stop_reason == StopReason.END_TURN

    accumulated_content, _, _ = _collect_stream(chunks)
    assert accumulated_content, "accumulated content must be non-empty after image attachment"
