# standard
import base64
from unittest.mock import AsyncMock, MagicMock, patch

# third party
import pytest

# custom
from sunwaee.modules.gen.engine.providers.anthropic import AnthropicEngine
from sunwaee.modules.gen.engine.types import (
    FileAttachment,
    Message,
    Role,
    StopReason,
    Tool,
    ToolCall,
)

_PNG = base64.b64decode("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg==")

ENGINE = AnthropicEngine(model="claude-3-5-haiku", api_key="test-key")

DUMMY_TOOL = Tool(
    name="tasks",
    description="Manage tasks.",
    parameters={"type": "object", "properties": {}, "required": []},
)


### MESSAGES


def test_build_messages_user():
    msgs = [Message(role=Role.USER, content="Hello")]
    result = ENGINE._build_messages(msgs)
    assert result == [{"role": "user", "content": "Hello"}]


def test_build_messages_context_role():
    """CONTEXT emits a standalone XML-wrapped user message."""
    msgs = [Message(role=Role.CONTEXT, content="dynamic header info")]
    result = ENGINE._build_messages(msgs)
    assert result == [{"role": "user", "content": "<context>\ndynamic header info\n</context>"}]


def test_build_messages_context_followed_by_user():
    """CONTEXT and USER produce two separate user messages (Anthropic accepts consecutive)."""
    msgs = [
        Message(role=Role.CONTEXT, content="date: 2026-01-01\nengine: test"),
        Message(role=Role.USER, content="Reply with ok."),
    ]
    result = ENGINE._build_messages(msgs)
    assert len(result) == 2
    assert result[0] == {
        "role": "user",
        "content": "<context>\ndate: 2026-01-01\nengine: test\n</context>",
    }
    assert result[1] == {"role": "user", "content": "Reply with ok."}


def test_build_messages_context_multiturn():
    """CONTEXT messages in a multi-turn history each become their own user message."""
    msgs = [
        Message(role=Role.CONTEXT, content="turn: 1"),
        Message(role=Role.USER, content="q1"),
        Message(role=Role.ASSISTANT, content="a1"),
        Message(role=Role.CONTEXT, content="turn: 2"),
        Message(role=Role.USER, content="q2"),
    ]
    result = ENGINE._build_messages(msgs)
    roles = [m["role"] for m in result]
    assert roles == ["user", "user", "assistant", "user", "user"]
    assert result[0]["content"] == "<context>\nturn: 1\n</context>"
    assert result[1]["content"] == "q1"
    assert result[3]["content"] == "<context>\nturn: 2\n</context>"
    assert result[4]["content"] == "q2"


def test_build_messages_assistant_text():
    msgs = [Message(role=Role.ASSISTANT, content="Hi there")]
    result = ENGINE._build_messages(msgs)
    assert result == [{"role": "assistant", "content": [{"type": "text", "text": "Hi there"}]}]


def test_build_messages_assistant_with_reasoning():
    msgs = [
        Message(
            role=Role.ASSISTANT,
            content="Answer",
            reasoning_content="I think...",
            reasoning_signature="sig-123",
        )
    ]
    result = ENGINE._build_messages(msgs)
    assert len(result) == 1
    parts = result[0]["content"]
    assert parts[0] == {
        "type": "thinking",
        "thinking": "I think...",
        "signature": "sig-123",
    }
    assert parts[1] == {"type": "text", "text": "Answer"}


def test_build_messages_drops_foreign_reasoning_signature():
    """Cross-provider replay: an OpenAI Responses reasoning_signature (JSON list) must not
    be sent as an Anthropic thinking block signature — Anthropic rejects it."""
    foreign_sig = '[{"id": "rs_abc", "type": "reasoning", "encrypted_content": "gAAAAA..."}]'
    msgs = [
        Message(
            role=Role.ASSISTANT,
            content="Answer",
            reasoning_content="I think...",
            reasoning_signature=foreign_sig,
        )
    ]
    result = ENGINE._build_messages(msgs)
    parts = result[0]["content"]
    assert all(p["type"] != "thinking" for p in parts)
    assert parts[0] == {"type": "text", "text": "Answer"}


def test_build_messages_assistant_reasoning_no_content():
    msgs = [
        Message(
            role=Role.ASSISTANT,
            reasoning_content="thinking only",
            reasoning_signature="s",
        )
    ]
    result = ENGINE._build_messages(msgs)
    parts = result[0]["content"]
    assert parts[0]["type"] == "thinking"
    assert len(parts) == 1  # no text block added when content is None


def test_build_messages_assistant_with_tool_calls():
    tc = ToolCall(id="call-1", name="tasks", arguments={"action": "list"})
    msgs = [Message(role=Role.ASSISTANT, content="Using tool", tool_calls=[tc])]
    result = ENGINE._build_messages(msgs)
    parts = result[0]["content"]
    assert parts[0] == {"type": "text", "text": "Using tool"}
    assert parts[1] == {
        "type": "tool_use",
        "id": "call-1",
        "name": "tasks",
        "input": {"action": "list"},
    }


def test_build_messages_tool_result():
    msgs = [Message(role=Role.TOOL, content='{"ok": true}', tool_call_id="call-1")]
    result = ENGINE._build_messages(msgs)
    assert result == [
        {
            "role": "user",
            "content": [
                {
                    "type": "tool_result",
                    "tool_use_id": "call-1",
                    "content": '{"ok": true}',
                }
            ],
        }
    ]


def test_build_messages_system_excluded():
    """System messages are stripped by _split_system before _build_messages is called."""
    msgs = [Message(role=Role.USER, content="Hi")]
    system, rest = ENGINE._split_system([Message(role=Role.SYSTEM, content="You are Sun.")] + msgs)
    assert system == "You are Sun."
    built = ENGINE._build_messages(rest)
    assert all(m["role"] != "system" for m in built)


def test_split_system_only_promotes_to_user():
    """System-only input: no top-level system field, content becomes a user message."""
    system, rest = ENGINE._split_system([Message(role=Role.SYSTEM, content="Respond with ok.")])
    assert system is None
    assert len(rest) == 1
    assert rest[0].role == Role.USER
    assert rest[0].content == "Respond with ok."


def test_build_payload_with_system():
    msgs = [
        Message(role=Role.SYSTEM, content="You are Sun."),
        Message(role=Role.USER, content="Hi"),
    ]
    payload = ENGINE._build_payload(msgs, tools=None)
    assert payload["system"] == [{"type": "text", "text": "You are Sun.", "cache_control": {"type": "ephemeral"}}]


def test_build_payload_with_tools():
    msgs = [Message(role=Role.USER, content="Hi")]
    payload = ENGINE._build_payload(msgs, tools=[DUMMY_TOOL])
    assert "tools" in payload
    assert payload["tools"][0]["name"] == "tasks"


def test_build_payload_no_thinking_by_default():
    """Engine emits no thinking block when neither thinking_budget nor effort is passed."""
    msgs = [Message(role=Role.USER, content="Hi")]
    payload = ENGINE._build_payload(msgs, tools=None)
    assert "thinking" not in payload
    assert "output_config" not in payload


def test_build_payload_thinking_budget_custom():
    engine = AnthropicEngine(model="claude-3-5-haiku", api_key="k", max_tokens=4096, thinking_budget=2000)
    payload = engine._build_payload([Message(role=Role.USER, content="Hi")], tools=None)
    assert payload["thinking"]["budget_tokens"] == 2000


def test_build_payload_thinking_budget_none_by_default():
    """thinking_budget is None when not provided — the factory is responsible for computing it."""
    engine = AnthropicEngine(model="m", api_key="k", max_tokens=2048)
    assert engine.thinking_budget is None


def test_build_payload_thinking_disabled_when_budget_zero():
    """thinking_budget=0 omits the thinking key entirely — enables prompt caching."""
    engine = AnthropicEngine(model="claude-haiku-4-5", api_key="k", thinking_budget=0)
    payload = engine._build_payload([Message(role=Role.USER, content="Hi")], tools=None)
    assert "thinking" not in payload


def test_build_payload_effort_sends_adaptive_and_output_config():
    engine = AnthropicEngine(model="claude-opus-4-7", api_key="k", effort="high")
    payload = engine._build_payload([Message(role=Role.USER, content="Hi")], tools=None)
    assert payload["thinking"] == {"type": "adaptive"}
    assert payload["output_config"] == {"effort": "high"}


def test_build_payload_effort_takes_precedence_over_budget():
    engine = AnthropicEngine(model="claude-opus-4-7", api_key="k", effort="low", thinking_budget=2000)
    payload = engine._build_payload([Message(role=Role.USER, content="Hi")], tools=None)
    assert payload["thinking"] == {"type": "adaptive"}
    assert payload["output_config"] == {"effort": "low"}
    assert payload["thinking"].get("budget_tokens") is None


def test_build_messages_reasoning_only_on_last_turn():
    """Reasoning block only on the last assistant turn (safe for cross-engine history)."""
    msgs = [
        Message(role=Role.USER, content="First question"),
        Message(
            role=Role.ASSISTANT,
            content="First answer",
            reasoning_content="thinking1",
            reasoning_signature="sig1",
        ),
        Message(role=Role.USER, content="Second question"),
        Message(
            role=Role.ASSISTANT,
            content="Second answer",
            reasoning_content="thinking2",
            reasoning_signature="sig2",
        ),
    ]
    result = ENGINE._build_messages(msgs)
    assistant_msgs = [m for m in result if m["role"] == "assistant"]
    assert len(assistant_msgs) == 2
    # First turn: no thinking block
    assert assistant_msgs[0]["content"][0]["type"] == "text"
    # Last turn: thinking block present
    assert assistant_msgs[1]["content"][0]["type"] == "thinking"
    assert assistant_msgs[1]["content"][0]["thinking"] == "thinking2"


### ATTACHMENTS


def test_build_messages_user_text_attachment():
    att = FileAttachment(data=b"file contents", filename="notes.txt")
    msgs = [Message(role=Role.USER, content="Here is a file", attachments=[att])]
    result = ENGINE._build_messages(msgs)
    assert len(result) == 1
    content = result[0]["content"]
    assert isinstance(content, list)
    file_part = content[0]
    assert file_part["type"] == "text"
    assert '<file name="notes.txt">' in file_part["text"]
    assert "file contents" in file_part["text"]
    text_part = content[1]
    assert text_part == {"type": "text", "text": "Here is a file"}


def test_build_messages_user_image_attachment():
    att = FileAttachment(data=_PNG, filename="photo.png")
    msgs = [Message(role=Role.USER, content="Look at this", attachments=[att])]
    result = ENGINE._build_messages(msgs)
    content = result[0]["content"]
    assert isinstance(content, list)
    img_part = content[0]
    assert img_part["type"] == "image"
    assert img_part["source"]["type"] == "base64"
    assert img_part["source"]["media_type"] == "image/png"
    assert img_part["source"]["data"] == base64.b64encode(_PNG).decode()
    assert content[1] == {"type": "text", "text": "Look at this"}


def test_build_messages_image_on_non_vision_model_raises():
    from sunwaee.modules.gen.engine.model import Model

    engine = AnthropicEngine(
        model="fake-text-only",
        api_key="k",
        model_info=Model(name="fake-text-only", display_name="Fake Text Only", provider="anthropic", supports_vision=False),
    )
    att = FileAttachment(data=_PNG, filename="photo.png")
    msgs = [Message(role=Role.USER, content="Hi", attachments=[att])]
    with pytest.raises(ValueError, match="does not support vision"):
        engine._build_messages(msgs)


def test_build_messages_multiple_attachments_ordered_before_text():
    att1 = FileAttachment(data=b"first", filename="a.txt")
    att2 = FileAttachment(data=b"second", filename="b.txt")
    msgs = [Message(role=Role.USER, content="see both", attachments=[att1, att2])]
    result = ENGINE._build_messages(msgs)
    content = result[0]["content"]
    assert len(content) == 3
    assert "a.txt" in content[0]["text"]
    assert "b.txt" in content[1]["text"]
    assert content[2] == {"type": "text", "text": "see both"}


def test_build_messages_attachment_in_history_replayed():
    att = FileAttachment(data=_PNG, filename="img.png")
    msgs = [
        Message(role=Role.USER, content="first turn", attachments=[att]),
        Message(role=Role.ASSISTANT, content="got it"),
        Message(role=Role.USER, content="second turn"),
    ]
    result = ENGINE._build_messages(msgs)
    # First user message still has the attachment encoded
    first_content = result[0]["content"]
    assert isinstance(first_content, list)
    assert first_content[0]["type"] == "image"
    assert first_content[0]["source"]["data"] == base64.b64encode(_PNG).decode()
    # Third message (second user turn) has no attachments
    assert result[2]["content"] == "second turn"


def test_build_messages_attachment_no_text_content():
    att = FileAttachment(data=b"data", filename="file.txt")
    msgs = [Message(role=Role.USER, content=None, attachments=[att])]
    result = ENGINE._build_messages(msgs)
    content = result[0]["content"]
    assert len(content) == 1
    assert content[0]["type"] == "text"


### TOOLS


def test_build_tools():
    tools = ENGINE._build_tools([DUMMY_TOOL])
    assert tools == [
        {
            "name": "tasks",
            "description": "Manage tasks.",
            "input_schema": {"type": "object", "properties": {}, "required": []},
        }
    ]


### RESPONSE PARSING


def _raw(content_blocks, stop_reason="end_turn", input_tokens=10, output_tokens=20):
    return {
        "content": content_blocks,
        "stop_reason": stop_reason,
        "usage": {"input_tokens": input_tokens, "output_tokens": output_tokens},
    }


def test_parse_response_text():
    r = ENGINE._parse_response(_raw([{"type": "text", "text": "Hello!"}]))
    assert r.content == "Hello!"
    assert r.tool_calls is None
    assert r.stop_reason == StopReason.END_TURN
    assert r.usage
    assert r.usage.input_tokens == 10
    assert r.usage.output_tokens == 20
    assert r.reasoning_content is None
    assert r.provider == "anthropic"
    assert r.model == ENGINE.model


def test_parse_response_thinking():
    r = ENGINE._parse_response(
        _raw(
            [
                {"type": "thinking", "thinking": "I think...", "signature": "sig-abc"},
                {"type": "text", "text": "Answer"},
            ]
        )
    )
    assert r.content == "Answer"
    assert r.reasoning_content == "I think..."
    assert r.reasoning_signature == "sig-abc"


def test_parse_response_tool_use():
    r = ENGINE._parse_response(
        _raw(
            [
                {
                    "type": "tool_use",
                    "id": "call-1",
                    "name": "tasks",
                    "input": {"action": "list"},
                },
            ],
            stop_reason="tool_use",
        )
    )
    assert r.content is None
    assert r.stop_reason == StopReason.TOOL_USE
    assert r.tool_calls
    assert len(r.tool_calls) == 1
    assert r.tool_calls[0].id == "call-1"
    assert r.tool_calls[0].name == "tasks"
    assert r.tool_calls[0].arguments == {"action": "list"}


def test_parse_response_thinking_and_tool_use():
    r = ENGINE._parse_response(
        _raw(
            [
                {
                    "type": "thinking",
                    "thinking": "Should I use a tool?",
                    "signature": "s",
                },
                {
                    "type": "tool_use",
                    "id": "c1",
                    "name": "notes",
                    "input": {"action": "list"},
                },
            ],
            stop_reason="tool_use",
        )
    )
    assert r.reasoning_content == "Should I use a tool?"
    assert r.tool_calls
    assert r.tool_calls[0].name == "notes"


def test_parse_response_multiple_tool_calls():
    r = ENGINE._parse_response(
        _raw(
            [
                {
                    "type": "tool_use",
                    "id": "c1",
                    "name": "tasks",
                    "input": {"action": "list"},
                },
                {
                    "type": "tool_use",
                    "id": "c2",
                    "name": "notes",
                    "input": {"action": "list"},
                },
            ],
            stop_reason="tool_use",
        )
    )
    assert r.tool_calls
    assert len(r.tool_calls) == 2


def test_parse_response_stop_reason_mapping():
    assert ENGINE._parse_response(_raw([], stop_reason="end_turn")).stop_reason == StopReason.END_TURN
    assert ENGINE._parse_response(_raw([], stop_reason="tool_use")).stop_reason == StopReason.TOOL_USE
    assert ENGINE._parse_response(_raw([], stop_reason="max_tokens")).stop_reason == StopReason.MAX_TOKENS


def test_parse_response_missing_stop_reason_defaults_to_end_turn():
    # Anthropic may omit stop_reason on some payloads — we must default cleanly.
    raw = {"content": [{"type": "text", "text": "Hi"}], "usage": {"input_tokens": 1, "output_tokens": 1}}
    assert ENGINE._parse_response(raw).stop_reason == StopReason.END_TURN


def test_parse_response_unknown_stop_reason_defaults_to_end_turn():
    assert ENGINE._parse_response(_raw([], stop_reason="something_new")).stop_reason == StopReason.END_TURN


def test_parse_response_block_without_type_is_ignored():
    # A malformed block missing 'type' must not raise — it's silently skipped.
    raw = _raw([{"text": "stray"}, {"type": "text", "text": "real"}])
    r = ENGINE._parse_response(raw)
    assert r.content == "real"


def test_parse_response_unknown_block_type_is_ignored():
    raw = _raw([{"type": "mystery", "data": "???"}, {"type": "text", "text": "ok"}])
    r = ENGINE._parse_response(raw)
    assert r.content == "ok"


### CHAT - chat()


@pytest.mark.asyncio
async def test_chat_returns_response():
    raw = _raw([{"type": "text", "text": "Hi from Anthropic"}])
    mock_resp = MagicMock()
    mock_resp.is_success = True
    mock_resp.json.return_value = raw

    with patch("httpx.AsyncClient.post", new_callable=AsyncMock, return_value=mock_resp):
        response = await ENGINE.chat([Message(role=Role.USER, content="Hello")])

    assert response.content == "Hi from Anthropic"


@pytest.mark.asyncio
async def test_chat_raises_on_error():
    mock_resp = MagicMock()
    mock_resp.is_success = False
    mock_resp.status_code = 401
    mock_resp.text = "Unauthorized"

    with patch("httpx.AsyncClient.post", new_callable=AsyncMock, return_value=mock_resp):
        with pytest.raises(RuntimeError, match="401"):
            await ENGINE.chat([Message(role=Role.USER, content="Hello")])


@pytest.mark.asyncio
async def test_chat_computes_cost_for_known_model():
    engine = AnthropicEngine(model="claude-haiku-4-5", api_key="test-key")
    raw = _raw([{"type": "text", "text": "Hi"}])
    mock_resp = MagicMock()
    mock_resp.is_success = True
    mock_resp.json.return_value = raw

    with patch("httpx.AsyncClient.post", new_callable=AsyncMock, return_value=mock_resp):
        response = await engine.chat([Message(role=Role.USER, content="Hello")])

    assert response.cost is not None
    assert response.cost.total > 0


@pytest.mark.asyncio
async def test_chat_with_text_attachment():
    raw = _raw([{"type": "text", "text": "Got your file"}])
    mock_resp = MagicMock()
    mock_resp.is_success = True
    mock_resp.json.return_value = raw

    att = FileAttachment(data=b"Hello from file", filename="notes.txt")
    msg = Message(role=Role.USER, content="Here is a file", attachments=[att])

    with patch("httpx.AsyncClient.post", new_callable=AsyncMock, return_value=mock_resp) as mock_post:
        await ENGINE.chat([msg])

    payload = mock_post.call_args.kwargs["json"]
    content = payload["messages"][0]["content"]
    assert isinstance(content, list)
    assert content[0]["type"] == "text"
    assert '<file name="notes.txt">' in content[0]["text"]
    assert "Hello from file" in content[0]["text"]
    assert content[-1] == {"type": "text", "text": "Here is a file"}


@pytest.mark.asyncio
async def test_chat_with_image_attachment():
    raw = _raw([{"type": "text", "text": "Got your image"}])
    mock_resp = MagicMock()
    mock_resp.is_success = True
    mock_resp.json.return_value = raw

    att = FileAttachment(data=_PNG, filename="photo.png")
    msg = Message(role=Role.USER, content="Look at this", attachments=[att])

    with patch("httpx.AsyncClient.post", new_callable=AsyncMock, return_value=mock_resp) as mock_post:
        await ENGINE.chat([msg])

    payload = mock_post.call_args.kwargs["json"]
    content = payload["messages"][0]["content"]
    assert isinstance(content, list)
    img = content[0]
    assert img["type"] == "image"
    assert img["source"]["type"] == "base64"
    assert img["source"]["media_type"] == "image/png"
    assert img["source"]["data"] == base64.b64encode(_PNG).decode()
    assert content[-1] == {"type": "text", "text": "Look at this"}


### STREAM - stream()


@pytest.mark.asyncio
async def test_stream_yields_reasoning_content_and_text():
    lines = [
        'data: {"type": "message_start", "message": {"usage": {"input_tokens": 5}}}',
        'data: {"type": "content_block_start", "index": 0, "content_block": {"type": "thinking", "thinking": ""}}',
        'data: {"type": "content_block_delta", "index": 0, "delta": {"type": "thinking_delta", "thinking": "I think"}}',
        'data: {"type": "content_block_delta", "index": 0, "delta": {"type": "signature_delta", "signature": "sig-abc"}}',
        'data: {"type": "content_block_start", "index": 1, "content_block": {"type": "text", "text": ""}}',
        'data: {"type": "content_block_delta", "index": 1, "delta": {"type": "text_delta", "text": "Hello"}}',
        'data: {"type": "content_block_delta", "index": 1, "delta": {"type": "text_delta", "text": " world"}}',
        'data: {"type": "message_delta", "delta": {"stop_reason": "end_turn"}, "usage": {"output_tokens": 2}}',
        'data: {"type": "message_stop"}',
    ]

    mock_resp = AsyncMock()
    mock_resp.__aenter__ = AsyncMock(return_value=mock_resp)
    mock_resp.__aexit__ = AsyncMock(return_value=False)
    mock_resp.is_success = True
    mock_resp.aiter_lines = MagicMock(return_value=aiter(lines))

    mock_client = AsyncMock()
    mock_client.__aenter__ = AsyncMock(return_value=mock_client)
    mock_client.__aexit__ = AsyncMock(return_value=False)
    mock_client.stream = MagicMock(return_value=mock_resp)

    ENGINE._client = mock_client
    chunks = [c async for c in ENGINE.stream([Message(role=Role.USER, content="Hi")])]

    # reasoning chunk, signature chunk, 2 text chunks, summary
    assert chunks[0].reasoning_content == "I think"
    assert chunks[0].stop_reason is None
    assert chunks[1].reasoning_signature == "sig-abc"
    assert chunks[1].stop_reason is None
    assert chunks[2].content == "Hello"
    assert chunks[2].stop_reason is None
    assert chunks[3].content == " world"
    assert chunks[3].stop_reason is None
    summary = chunks[-1]
    assert summary.content is None
    assert summary.usage
    assert summary.usage.input_tokens == 5
    assert summary.usage.output_tokens == 2
    assert summary.stop_reason == StopReason.END_TURN


@pytest.mark.asyncio
async def test_stream_yields_tool_call():
    lines = [
        'data: {"type": "message_start", "message": {"usage": {"input_tokens": 10}}}',
        'data: {"type": "content_block_start", "index": 0, "content_block": {"type": "tool_use", "id": "tc_1", "name": "update_chat", "input": {}}}',
        'data: {"type": "content_block_delta", "index": 0, "delta": {"type": "input_json_delta", "partial_json": "{\\"title\\":"}}',
        'data: {"type": "content_block_delta", "index": 0, "delta": {"type": "input_json_delta", "partial_json": " \\"Test\\"}"}}',
        'data: {"type": "content_block_stop", "index": 0}',
        'data: {"type": "message_delta", "delta": {"stop_reason": "tool_use"}, "usage": {"output_tokens": 20}}',
        'data: {"type": "message_stop"}',
    ]

    mock_resp = AsyncMock()
    mock_resp.__aenter__ = AsyncMock(return_value=mock_resp)
    mock_resp.__aexit__ = AsyncMock(return_value=False)
    mock_resp.is_success = True
    mock_resp.aiter_lines = MagicMock(return_value=aiter(lines))

    mock_client = AsyncMock()
    mock_client.__aenter__ = AsyncMock(return_value=mock_client)
    mock_client.__aexit__ = AsyncMock(return_value=False)
    mock_client.stream = MagicMock(return_value=mock_resp)

    ENGINE._client = mock_client
    chunks = [c async for c in ENGINE.stream([Message(role=Role.USER, content="Hi")])]

    # tool call chunk + summary
    tc_chunk = next(c for c in chunks if c.tool_calls)
    assert tc_chunk.tool_calls
    assert tc_chunk.tool_calls[0].id == "tc_1"
    assert tc_chunk.tool_calls[0].name == "update_chat"
    assert tc_chunk.tool_calls[0].arguments == {"title": "Test"}
    assert tc_chunk.stop_reason is None
    summary = chunks[-1]
    assert summary.stop_reason == StopReason.TOOL_USE
    assert summary.usage
    assert summary.usage.output_tokens == 20


@pytest.mark.asyncio
async def test_stream_reads_body_before_raising_on_error():
    """H5: streaming 4xx must read the body before raising, not call raise_for_status."""
    mock_resp = AsyncMock()
    mock_resp.__aenter__ = AsyncMock(return_value=mock_resp)
    mock_resp.__aexit__ = AsyncMock(return_value=False)
    mock_resp.is_success = False
    mock_resp.status_code = 401
    mock_resp.aread = AsyncMock(return_value=b"Unauthorized: bad key")

    mock_client = AsyncMock()
    mock_client.__aenter__ = AsyncMock(return_value=mock_client)
    mock_client.__aexit__ = AsyncMock(return_value=False)
    mock_client.stream = MagicMock(return_value=mock_resp)

    ENGINE._client = mock_client
    with pytest.raises(RuntimeError, match="401"):
        async for _ in ENGINE.stream([Message(role=Role.USER, content="Hi")]):
            pass


@pytest.mark.asyncio
async def test_chat_raises_auth_error_for_401():
    from sunwaee.modules.gen.engine.errors import AuthError

    mock_resp = MagicMock()
    mock_resp.is_success = False
    mock_resp.status_code = 401
    mock_resp.text = "Unauthorized"

    engine = AnthropicEngine(model="claude-3-5-haiku", api_key="test-key")
    engine._client = AsyncMock()
    engine._client.post = AsyncMock(return_value=mock_resp)

    with pytest.raises(AuthError):
        await engine.chat([Message(role=Role.USER, content="Hello")])


@pytest.mark.asyncio
async def test_chat_raises_rate_limit_error_for_429():
    from sunwaee.modules.gen.engine.errors import RateLimitError

    mock_resp = MagicMock()
    mock_resp.is_success = False
    mock_resp.status_code = 429
    mock_resp.text = "Too Many Requests"

    engine = AnthropicEngine(model="claude-3-5-haiku", api_key="test-key")
    engine._client = AsyncMock()
    engine._client.post = AsyncMock(return_value=mock_resp)

    with pytest.raises(RateLimitError):
        await engine.chat([Message(role=Role.USER, content="Hello")])


### HELPERS


async def aiter(items):
    for item in items:
        yield item
