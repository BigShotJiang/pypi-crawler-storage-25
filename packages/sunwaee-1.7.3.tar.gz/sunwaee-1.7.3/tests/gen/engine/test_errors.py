# standard
# third party
import pytest

# custom
from sunwaee.modules.gen.engine.errors import (
    AuthError,
    EngineError,
    RateLimitError,
    TransientError,
    raise_api_error,
)

### HIERARCHY


def test_engine_error_is_runtime_error():
    err = EngineError("boom", status_code=400)
    assert isinstance(err, RuntimeError)
    assert err.status_code == 400
    assert str(err) == "boom"


def test_rate_limit_error_is_engine_error():
    err = RateLimitError("slow down", status_code=429)
    assert isinstance(err, EngineError)
    assert isinstance(err, RuntimeError)
    assert err.status_code == 429


def test_auth_error_is_engine_error():
    err = AuthError("bad key", status_code=401)
    assert isinstance(err, EngineError)
    assert err.status_code == 401


def test_transient_error_is_engine_error():
    err = TransientError("server down", status_code=503)
    assert isinstance(err, EngineError)
    assert err.status_code == 503


### raise_api_error DISPATCH


def test_raise_api_error_429_raises_rate_limit():
    with pytest.raises(RateLimitError) as exc_info:
        raise_api_error("openai", 429, "Too Many Requests")
    assert exc_info.value.status_code == 429
    assert "429" in str(exc_info.value)


def test_raise_api_error_401_raises_auth():
    with pytest.raises(AuthError) as exc_info:
        raise_api_error("anthropic", 401, "Unauthorized")
    assert exc_info.value.status_code == 401


def test_raise_api_error_403_raises_auth():
    with pytest.raises(AuthError) as exc_info:
        raise_api_error("google", 403, "Forbidden")
    assert exc_info.value.status_code == 403


def test_raise_api_error_500_raises_transient():
    with pytest.raises(TransientError) as exc_info:
        raise_api_error("xai", 500, "Internal Server Error")
    assert exc_info.value.status_code == 500


def test_raise_api_error_503_raises_transient():
    with pytest.raises(TransientError) as exc_info:
        raise_api_error("deepseek", 503, "Service Unavailable")
    assert exc_info.value.status_code == 503


def test_raise_api_error_400_raises_engine_error():
    with pytest.raises(EngineError) as exc_info:
        raise_api_error("anthropic", 400, "Bad Request: invalid model")
    assert exc_info.value.status_code == 400
    assert not isinstance(exc_info.value, RateLimitError)
    assert not isinstance(exc_info.value, AuthError)
    assert not isinstance(exc_info.value, TransientError)


def test_raise_api_error_body_truncated_at_500_chars():
    long_body = "x" * 1000
    with pytest.raises(EngineError) as exc_info:
        raise_api_error("openai", 400, long_body)
    # message should not contain more than 500 chars of the body
    msg = str(exc_info.value)
    assert "x" * 501 not in msg
    assert "x" * 500 in msg


def test_raise_api_error_provider_in_message():
    with pytest.raises(EngineError) as exc_info:
        raise_api_error("myprovider", 400, "oops")
    assert "myprovider" in str(exc_info.value)


def test_engine_error_caught_as_runtime_error():
    """Existing callers catching RuntimeError must still work."""
    with pytest.raises(RuntimeError):
        raise_api_error("anthropic", 401, "bad key")
