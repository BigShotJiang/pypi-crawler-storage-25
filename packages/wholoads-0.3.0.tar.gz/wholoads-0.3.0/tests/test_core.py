"""Unit tests for wholoads core logic."""

from __future__ import annotations

from wholoads.core.plugin import AnalysisResult, Finding, Severity, SystemInfo
from wholoads.output import render_result


def _make_result(findings: list[Finding] | None = None) -> AnalysisResult:
    info = SystemInfo(name="test", host="localhost", version="PG 15", uptime="1d")
    return AnalysisResult(system_info=info, findings=findings or [])


def test_severity_ordering() -> None:
    result = _make_result([
        Finding(Severity.INFO, "cpu", "info finding", "detail", "rec"),
        Finding(Severity.RED, "cpu", "red finding", "detail", "rec"),
        Finding(Severity.YELLOW, "cpu", "yellow finding", "detail", "rec"),
    ])
    severity_order = {Severity.RED: 0, Severity.YELLOW: 1, Severity.INFO: 2}
    result.findings.sort(key=lambda f: severity_order[f.severity])
    assert result.findings[0].severity == Severity.RED
    assert result.findings[1].severity == Severity.YELLOW
    assert result.findings[2].severity == Severity.INFO


def test_result_counts() -> None:
    result = _make_result([
        Finding(Severity.RED, "cpu", "t", "d", "r"),
        Finding(Severity.RED, "cpu", "t", "d", "r"),
        Finding(Severity.YELLOW, "cpu", "t", "d", "r"),
    ])
    assert result.red_count == 2
    assert result.yellow_count == 1


def test_result_by_category() -> None:
    result = _make_result([
        Finding(Severity.RED, "cpu", "t", "d", "r"),
        Finding(Severity.YELLOW, "locks", "t", "d", "r"),
    ])
    assert len(result.by_category("cpu")) == 1
    assert len(result.by_category("locks")) == 1
    assert len(result.by_category("disk_io")) == 0


def test_render_json() -> None:
    result = _make_result([Finding(Severity.RED, "cpu", "title", "detail", "rec", query="SELECT 1")])
    output = render_result(result, fmt="json")
    assert output is not None
    assert '"critical": 1' in output
    assert "SELECT 1" in output


def test_render_csv() -> None:
    result = _make_result([Finding(Severity.YELLOW, "locks", "title", "detail", "rec")])
    output = render_result(result, fmt="csv")
    assert output is not None
    assert "yellow" in output
    assert "locks" in output


def test_render_markdown() -> None:
    result = _make_result([Finding(Severity.INFO, "cpu", "my title", "detail", "rec")])
    output = render_result(result, fmt="markdown")
    assert output is not None
    assert "my title" in output


def test_render_rich_no_crash() -> None:
    from rich.console import Console

    console = Console(width=80)
    result = _make_result()
    render_result(result, fmt="rich", console=console)


def test_config_load_missing(tmp_path: "pytest.TempPathFactory") -> None:  # type: ignore[name-defined]
    from pathlib import Path

    from wholoads.config import load_config

    missing = Path(tmp_path) / "nonexistent.yaml"  # type: ignore[arg-type]
    assert load_config(missing) == {}


def test_config_generate_default() -> None:
    from wholoads.config import generate_default_config

    cfg = generate_default_config()
    assert "postgresql" in cfg
    assert "clickhouse" in cfg
    assert "kubernetes" in cfg


def test_postgresql_parse_psql_output() -> None:
    from wholoads.plugins.postgresql import PostgreSQLPlugin

    plugin = PostgreSQLPlugin({}, {})
    sql = "SELECT count(*) AS total, max(age) AS max_age FROM foo;"
    raw = "42|100\n"
    rows = plugin._parse_psql_output(raw, sql)
    assert rows == [{"total": 42, "max_age": 100}]


def test_postgresql_coerce_values() -> None:
    from wholoads.plugins.postgresql import PostgreSQLPlugin

    plugin = PostgreSQLPlugin({}, {})
    assert plugin._coerce_value("42") == 42
    assert plugin._coerce_value("3.14") == 3.14
    assert plugin._coerce_value("hello") == "hello"
    assert plugin._coerce_value("") is None
    assert plugin._coerce_value("null") is None
