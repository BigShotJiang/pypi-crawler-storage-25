wholoads/
├── README.md
├── LICENSE                          # MIT
├── pyproject.toml                   # packaging, deps, entry points
├── CONTRIBUTING.md
├── CHANGELOG.md
│
├── src/
│   └── wholoads/
│       ├── __init__.py              # version
│       ├── __main__.py              # python -m wholoads
│       ├── cli.py                   # click/typer CLI entry point
│       ├── config.py                # YAML config loader + validation (pydantic)
│       ├── output.py                # formatters: rich, json, csv, markdown
│       │
│       ├── core/
│       │   ├── __init__.py
│       │   ├── plugin.py            # BasePlugin ABC, Finding, Severity
│       │   ├── connection.py        # SSH, Direct, Kubeconfig connectors
│       │   └── discovery.py         # plugin auto-discovery
│       │
│       ├── plugins/
│       │   ├── __init__.py
│       │   ├── postgresql.py        # pg_stat_statements + EXPLAIN
│       │   ├── clickhouse.py        # system.query_log + system.merges
│       │   └── kubernetes.py        # kubectl top + resource analysis
│       │
│       └── templates/
│           └── config.yaml          # default config template for `wholoads init`
│
├── tests/
│   ├── conftest.py
│   ├── test_config.py
│   ├── test_output.py
│   ├── test_plugins/
│   │   ├── test_postgresql.py
│   │   ├── test_clickhouse.py
│   │   └── test_kubernetes.py
│   └── fixtures/                    # sample outputs for testing
│       ├── pg_stat_statements.json
│       ├── explain_plan.json
│       ├── ch_query_log.json
│       └── kubectl_top.json
│
├── docs/
│   ├── plugins.md                   # how to write plugins
│   ├── config.md                    # config reference
│   └── examples.md                  # real-world usage examples
│
└── .github/
    ├── workflows/
    │   ├── ci.yml                   # pytest + linting
    │   └── release.yml              # publish to PyPI on tag
    ├── FUNDING.yml                  # GitHub Sponsors + Ko-fi
    └── ISSUE_TEMPLATE/
        ├── bug_report.md
        └── plugin_request.md
