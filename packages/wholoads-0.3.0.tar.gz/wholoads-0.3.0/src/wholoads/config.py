"""Configuration loading and validation."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import yaml

DEFAULT_CONFIG_PATH = Path.home() / ".config" / "wholoads" / "config.yaml"


def load_config(path: Path | None = None) -> dict[str, Any]:
    """Load config from YAML file."""
    config_path = path or DEFAULT_CONFIG_PATH

    if not config_path.exists():
        return {}

    with open(config_path) as f:
        config = yaml.safe_load(f)

    return config or {}


def generate_default_config() -> str:
    """Return default config YAML as string."""
    return """\
# wholoads configuration
# Docs: https://github.com/USERNAME/wholoads

# ─── PostgreSQL ───────────────────────────────────────────
postgresql:
  targets:
    - name: my-postgres
      # Connection method: direct | ssh
      method: direct
      host: localhost
      port: 5432
      user: monitoring
      password_env: WHOLOADS_PG_PASSWORD   # reads from environment variable
      dbname: myapp

    # SSH example (for servers where pg_hba blocks remote access):
    # - name: db-prod-via-ssh
    #   method: ssh
    #   ssh_host: db-prod.internal
    #   ssh_user: admin
    #   ssh_key: ~/.ssh/id_ed25519
    #   pg_user: postgres               # su - <pg_user> on remote host
    #   dbname: myapp

  settings:
    top_n: 10                            # top queries per category
    min_calls: 100                       # ignore low-frequency queries
    cache_hit_threshold: 95.0            # flag below this %
    # explain: true                      # auto-run EXPLAIN (future)
    # explain_format: json               # text | json

# ─── ClickHouse ───────────────────────────────────────────
clickhouse:
  targets:
    - name: my-clickhouse
      method: direct
      host: localhost
      port: 8123                         # HTTP interface
      user: default
      password_env: WHOLOADS_CH_PASSWORD

    # SSH example:
    # - name: ch-via-ssh
    #   method: ssh
    #   ssh_host: ch-node.internal
    #   ssh_user: admin
    #   ch_user: default

  settings:
    top_n: 10
    min_query_duration_ms: 1000
    include_system_queries: false
    hours_back: 24                       # look at last N hours

# ─── Kubernetes ───────────────────────────────────────────
kubernetes:
  targets:
    - name: my-cluster
      method: kubeconfig
      context: default                   # kubectl context name
      # kubeconfig: ~/.kube/config       # optional, uses default

  settings:
    namespaces: []                       # empty = all namespaces
    exclude_namespaces:
      - kube-system
    sort_by: cpu                         # cpu | memory | restarts
    top_n: 20

# ─── Output ──────────────────────────────────────────────
output:
  format: rich                           # rich | json | csv | markdown
  color: true
  truncate_query: 80                     # max query display length

# ─── SSH defaults ────────────────────────────────────────
ssh:
  timeout: 10
  # known_hosts: ~/.ssh/known_hosts
"""
