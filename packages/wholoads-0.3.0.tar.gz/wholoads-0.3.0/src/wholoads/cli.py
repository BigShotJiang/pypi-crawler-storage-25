"""CLI entry point for wholoads."""

from __future__ import annotations

import importlib
import sys
from pathlib import Path
from typing import Any

import typer
from rich.console import Console

from wholoads.config import generate_default_config, load_config
from wholoads.output import render_result

app = typer.Typer(
    name="wholoads",
    help="Find who's overloading your infrastructure.",
    no_args_is_help=True,
    add_completion=False,
)
console = Console()


def _get_plugin(plugin_name: str) -> Any:
    """Import and return the appropriate plugin class."""
    plugins = {
        "pg": "wholoads.plugins.postgresql:PostgreSQLPlugin",
        "ch": "wholoads.plugins.clickhouse:ClickHousePlugin",
        "k8s": "wholoads.plugins.kubernetes:KubernetesPlugin",
    }

    if plugin_name not in plugins:
        console.print(f"[red]Unknown plugin: {plugin_name}[/red]")
        console.print(f"Available: {', '.join(plugins.keys())}")
        raise typer.Exit(1)

    module_path, class_name = plugins[plugin_name].rsplit(":", 1)

    try:
        module = importlib.import_module(module_path)
        return getattr(module, class_name)
    except ImportError as e:
        console.print(f"[red]Failed to load plugin '{plugin_name}': {e}[/red]")
        console.print("Check that required dependencies are installed.")
        raise typer.Exit(1) from e


@app.command()
def init(
    path: Path | None = typer.Option(
        None,
        help="Config file path (default: ~/.config/wholoads/config.yaml)",
    ),
) -> None:
    """Generate a default config file."""
    config_path = path or Path.home() / ".config" / "wholoads" / "config.yaml"

    if config_path.exists():
        overwrite = typer.confirm(f"{config_path} already exists. Overwrite?")
        if not overwrite:
            raise typer.Exit(0)

    config_path.parent.mkdir(parents=True, exist_ok=True)
    config_path.write_text(generate_default_config())
    console.print(f"[green]Config created: {config_path}[/green]")
    console.print("Edit it with your connection details, then run: wholoads pg")


@app.command()
def pg(
    target: str | None = typer.Option(None, "--target", "-t", help="Target name from config"),
    all_targets: bool = typer.Option(False, "--all", help="Run on all configured targets"),
    fmt: str = typer.Option("rich", "--format", "-f", help="Output format: rich|json|csv|markdown"),
    top_n: int | None = typer.Option(
        None, "--top", "-n", help="Number of top queries per category"
    ),
    truncate: int | None = typer.Option(
        None, "--truncate", "-q", help="Query display length (0=full)"
    ),
    config_path: Path | None = typer.Option(None, "--config", "-c", help="Config file path"),
) -> None:
    """Analyze PostgreSQL — find who's consuming CPU, disk, cache."""
    _run_plugin("pg", "postgresql", target, all_targets, fmt, top_n, truncate, config_path)


@app.command()
def ch(
    target: str | None = typer.Option(None, "--target", "-t", help="Target name from config"),
    all_targets: bool = typer.Option(False, "--all", help="Run on all configured targets"),
    fmt: str = typer.Option("rich", "--format", "-f", help="Output format: rich|json|csv|markdown"),
    top_n: int | None = typer.Option(None, "--top", "-n", help="Number of top queries"),
    truncate: int | None = typer.Option(
        None, "--truncate", "-q", help="Query display length (0=full)"
    ),
    config_path: Path | None = typer.Option(None, "--config", "-c", help="Config file path"),
) -> None:
    """Analyze ClickHouse — find who's reading, writing, merging."""
    _run_plugin("ch", "clickhouse", target, all_targets, fmt, top_n, truncate, config_path)


@app.command()
def k8s(
    target: str | None = typer.Option(None, "--target", "-t", help="Target name from config"),
    all_targets: bool = typer.Option(False, "--all", help="Run on all configured targets"),
    fmt: str = typer.Option("rich", "--format", "-f", help="Output format: rich|json|csv|markdown"),
    namespace: str | None = typer.Option(None, "--namespace", "-ns", help="Kubernetes namespace"),
    truncate: int | None = typer.Option(
        None, "--truncate", "-q", help="Query display length (0=full)"
    ),
    config_path: Path | None = typer.Option(None, "--config", "-c", help="Config file path"),
) -> None:
    """Analyze Kubernetes — find who's eating CPU, memory, restarting."""
    _run_plugin("k8s", "kubernetes", target, all_targets, fmt, None, truncate, config_path)


def _run_plugin(
    plugin_name: str,
    config_section: str,
    target: str | None,
    all_targets: bool,
    fmt: str,
    top_n: int | None,
    truncate: int | None,
    config_path: Path | None,
) -> None:
    """Generic plugin runner."""
    config = load_config(config_path)
    section = config.get(config_section, {})
    targets = section.get("targets", [])
    settings = section.get("settings", {})

    if top_n is not None:
        settings["top_n"] = top_n

    truncate_query: int = (
        truncate if truncate is not None
        else config.get("output", {}).get("truncate_query", 80)
    )

    if not targets:
        console.print(f"[yellow]No {config_section} targets configured.[/yellow]")
        console.print("Run 'wholoads init' to create a config, then add your targets.")
        raise typer.Exit(1)

    # Select targets to run
    if all_targets:
        selected = targets
    elif target:
        selected = [t for t in targets if t.get("name") == target]
        if not selected:
            available = [t.get("name", "unnamed") for t in targets]
            console.print(f"[red]Target '{target}' not found.[/red]")
            console.print(f"Available: {', '.join(available)}")
            raise typer.Exit(1)
    else:
        selected = [targets[0]]

    # Run analysis
    plugin_class = _get_plugin(plugin_name)

    for target_config in selected:
        with console.status(
            f"[bold blue]Analyzing {target_config.get('name', 'target')}...[/bold blue]"
        ):
            try:
                plugin = plugin_class(target_config, settings)
                result = plugin.analyze()
                render_result(result, fmt=fmt, console=console, truncate_query=truncate_query)
            except Exception as e:
                console.print(f"[red]Error analyzing {target_config.get('name')}: {e}[/red]")
                if "--verbose" in sys.argv:
                    console.print_exception()


@app.command()
def version() -> None:
    """Show version."""
    from wholoads import __version__

    console.print(f"wholoads {__version__}")


if __name__ == "__main__":
    app()
