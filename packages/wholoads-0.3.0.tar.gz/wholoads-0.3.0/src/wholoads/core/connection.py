"""Connection helpers: SSH, direct DB, kubeconfig."""

from __future__ import annotations

import os
import subprocess
from dataclasses import dataclass
from typing import Any

import paramiko


@dataclass
class SSHConnection:
    """SSH connection wrapper using paramiko."""

    host: str
    user: str
    port: int = 22
    key_path: str | None = None
    timeout: int = 10

    _client: paramiko.SSHClient | None = None

    def connect(self) -> None:
        self._client = paramiko.SSHClient()
        self._client.set_missing_host_key_policy(paramiko.AutoAddPolicy())

        connect_kwargs: dict[str, Any] = {
            "hostname": self.host,
            "username": self.user,
            "port": self.port,
            "timeout": self.timeout,
        }

        if self.key_path:
            connect_kwargs["key_filename"] = os.path.expanduser(self.key_path)

        self._client.connect(**connect_kwargs)

    def execute(self, command: str) -> str:
        """Execute a command over SSH and return stdout."""
        if self._client is None:
            self.connect()

        if self._client is None:
            raise RuntimeError("SSH connection failed to establish")
        _, stdout, stderr = self._client.exec_command(command, timeout=30)

        exit_code = stdout.channel.recv_exit_status()
        output = stdout.read().decode("utf-8", errors="replace")
        errors = stderr.read().decode("utf-8", errors="replace")

        if exit_code != 0:
            raise RuntimeError(
                f"SSH command failed (exit {exit_code}): {errors.strip()}"
            )

        return output

    def execute_psql(
        self,
        sql: str,
        dbname: str = "postgres",
        pg_user: str = "postgres",
    ) -> str:
        """Execute psql command via su - postgres on remote host."""
        # Escape single quotes in SQL for shell
        escaped_sql = sql.replace("'", "'\\''")
        cmd = f"sudo su - {pg_user} -c \"psql -d {dbname} -t -A -F '|' -c '{escaped_sql}'\""
        return self.execute(cmd)

    def execute_clickhouse(
        self,
        sql: str,
        ch_user: str = "default",
        fmt: str = "JSONEachRow",
    ) -> str:
        """Execute clickhouse-client on remote host."""
        escaped_sql = sql.replace("'", "'\\''")
        cmd = (
            f"clickhouse-client -u {ch_user} "
            f"--format {fmt} "
            f"-q '{escaped_sql}'"
        )
        return self.execute(cmd)

    def close(self) -> None:
        if self._client:
            self._client.close()
            self._client = None

    def __enter__(self) -> SSHConnection:
        self.connect()
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()


@dataclass
class DirectPGConnection:
    """Direct PostgreSQL connection via psycopg."""

    host: str
    port: int
    user: str
    password: str
    dbname: str

    _conn: Any = None

    def connect(self) -> None:
        import psycopg

        self._conn = psycopg.connect(
            host=self.host,
            port=self.port,
            user=self.user,
            password=self.password,
            dbname=self.dbname,
            connect_timeout=10,
        )
        self._conn.autocommit = True

    def execute(self, sql: str) -> list[dict[str, Any]]:
        """Execute SQL and return list of dicts."""
        if self._conn is None:
            self.connect()

        with self._conn.cursor() as cur:
            cur.execute(sql)
            columns = [desc[0] for desc in cur.description or []]
            return [dict(zip(columns, row, strict=False)) for row in cur.fetchall()]

    def close(self) -> None:
        if self._conn:
            self._conn.close()
            self._conn = None


@dataclass
class DirectCHConnection:
    """Direct ClickHouse connection via HTTP (httpx)."""

    host: str
    port: int = 8123
    user: str = "default"
    password: str = ""

    def execute(self, sql: str, fmt: str = "JSONEachRow") -> str:
        """Execute query via ClickHouse HTTP interface."""
        import httpx

        url = f"http://{self.host}:{self.port}/"
        params = {
            "query": sql,
            "default_format": fmt,
        }

        response = httpx.post(
            url,
            params=params,
            auth=(self.user, self.password) if self.password else None,
            timeout=30.0,
        )
        response.raise_for_status()
        return response.text

    def close(self) -> None:
        pass


@dataclass
class KubeConnection:
    """Kubernetes connection via official client."""

    context: str | None = None
    kubeconfig: str | None = None

    _api: Any = None
    _custom_api: Any = None

    def connect(self) -> None:
        from kubernetes import client, config

        if self.kubeconfig:
            config.load_kube_config(
                config_file=self.kubeconfig,
                context=self.context,
            )
        else:
            config.load_kube_config(context=self.context)

        self._api = client.CoreV1Api()
        self._custom_api = client.CustomObjectsApi()

    @property
    def api(self) -> Any:
        if self._api is None:
            self.connect()
        return self._api

    def get_top_pods(self, namespace: str | None = None) -> str:
        """Run kubectl top pods and return output."""
        cmd = ["kubectl", "top", "pods", "--no-headers"]
        if self.context:
            cmd.extend(["--context", self.context])
        if namespace:
            cmd.extend(["-n", namespace])
        else:
            cmd.append("-A")

        result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
        if result.returncode != 0:
            raise RuntimeError(f"kubectl top failed: {result.stderr}")
        return result.stdout

    def close(self) -> None:
        pass
