"""Base plugin system for wholoads."""

from __future__ import annotations

import abc
from dataclasses import dataclass, field
from enum import Enum
from typing import Any


class Severity(str, Enum):
    """Finding severity level."""
    RED = "red"        # critical — immediate action needed
    YELLOW = "yellow"  # warning — should investigate
    INFO = "info"      # informational — good to know


@dataclass
class Finding:
    """A single diagnostic finding from a plugin."""
    severity: Severity
    category: str          # e.g. "cpu", "disk_io", "cache", "connections", "locks"
    title: str             # short summary, e.g. "Seq Scan on orders (2.1M rows)"
    detail: str            # longer explanation
    recommendation: str    # what to do about it
    query: str | None = None          # the offending SQL/command if applicable
    metrics: dict[str, Any] = field(default_factory=dict)  # raw numbers for JSON output


@dataclass
class SystemInfo:
    """High-level system information shown in the header."""
    name: str              # target name from config
    host: str
    version: str = ""
    uptime: str = ""
    extra: dict[str, str] = field(default_factory=dict)  # e.g. connections, db_size


@dataclass
class AnalysisResult:
    """Complete result from a plugin analysis run."""
    system_info: SystemInfo
    findings: list[Finding]
    raw_data: dict[str, Any] = field(default_factory=dict)  # full data for JSON output

    @property
    def red_count(self) -> int:
        return sum(1 for f in self.findings if f.severity == Severity.RED)

    @property
    def yellow_count(self) -> int:
        return sum(1 for f in self.findings if f.severity == Severity.YELLOW)

    def by_category(self, category: str) -> list[Finding]:
        return [f for f in self.findings if f.category == category]


class BasePlugin(abc.ABC):
    """Abstract base for all wholoads plugins.

    To create a new plugin:
    1. Subclass BasePlugin
    2. Set `name` and `description` class attributes
    3. Implement `analyze()` method
    4. Drop file in plugins/ or ~/.config/wholoads/plugins/
    """

    name: str = ""
    description: str = ""

    def __init__(self, target_config: dict[str, Any], settings: dict[str, Any]) -> None:
        self.target = target_config
        self.settings = settings
        self._connection: Any = None

    @abc.abstractmethod
    def analyze(self) -> AnalysisResult:
        """Run the full analysis and return results.

        This is the main entry point. Typical implementation:
        1. Connect to the target system
        2. Collect raw data (queries, metrics, etc.)
        3. Analyze and produce findings
        4. Return AnalysisResult with SystemInfo + list[Finding]
        """
        ...

    def connect(self) -> None:  # noqa: B027
        """Establish connection to the target system.

        Override this for custom connection logic.
        Called automatically before analyze() if needed.
        """

    def close(self) -> None:
        """Clean up connections."""
        if self._connection is not None:
            try:
                self._connection.close()
            except Exception:
                pass

    def __enter__(self) -> BasePlugin:
        self.connect()
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()
