"""PostgreSQL plugin — find who's overloading your database."""

from __future__ import annotations

import os
from typing import Any

from wholoads.core.connection import DirectPGConnection, SSHConnection
from wholoads.core.plugin import (
    AnalysisResult,
    BasePlugin,
    Finding,
    Severity,
    SystemInfo,
)

# ---------------------------------------------------------------------------
# SQL templates
# ---------------------------------------------------------------------------

SQL_VERSION = "SELECT version();"
SQL_PG_STAT_STATEMENTS_AVAILABLE = """
SELECT count(*) AS cnt
FROM pg_extension
WHERE extname = 'pg_stat_statements';
"""
SQL_UPTIME = "SELECT now() - pg_postmaster_start_time() AS uptime;"
SQL_DB_SIZE = "SELECT pg_size_pretty(pg_database_size(current_database())) AS size;"
SQL_CONNECTIONS = """
SELECT
    count(*) AS total,
    (SELECT setting::int FROM pg_settings WHERE name = 'max_connections') AS max_conn,
    count(*) FILTER (WHERE state = 'active') AS active,
    count(*) FILTER (WHERE state = 'idle') AS idle,
    count(*) FILTER (WHERE state = 'idle in transaction') AS idle_in_tx
FROM pg_stat_activity
WHERE backend_type = 'client backend';
"""

SQL_TOP_CPU = """
SELECT
    queryid,
    calls,
    round(total_exec_time::numeric, 2) AS total_time_ms,
    round(mean_exec_time::numeric, 2) AS mean_time_ms,
    round((100.0 * total_exec_time /
        nullif(sum(total_exec_time) OVER (), 0))::numeric, 2) AS pct_total,
    rows,
    query
FROM pg_stat_statements
WHERE dbid = (SELECT oid FROM pg_database WHERE datname = current_database())
ORDER BY total_exec_time DESC
LIMIT {top_n};
"""

SQL_TOP_DISK_READ = """
SELECT
    queryid,
    calls,
    shared_blks_read,
    shared_blks_hit,
    round(100.0 * shared_blks_hit /
        nullif(shared_blks_hit + shared_blks_read, 0), 2) AS cache_hit_pct,
    round(total_exec_time::numeric, 2) AS total_time_ms,
    rows,
    query
FROM pg_stat_statements
WHERE dbid = (SELECT oid FROM pg_database WHERE datname = current_database())
ORDER BY shared_blks_read DESC
LIMIT {top_n};
"""

SQL_WORST_CACHE = """
SELECT
    queryid,
    calls,
    shared_blks_read,
    shared_blks_hit,
    round(100.0 * shared_blks_hit /
        nullif(shared_blks_hit + shared_blks_read, 0), 2) AS cache_hit_pct,
    round(mean_exec_time::numeric, 2) AS mean_time_ms,
    rows,
    query
FROM pg_stat_statements
WHERE dbid = (SELECT oid FROM pg_database WHERE datname = current_database())
  AND (shared_blks_hit + shared_blks_read) > {min_blocks}
ORDER BY (shared_blks_hit::float /
    nullif(shared_blks_hit + shared_blks_read, 0)) ASC
LIMIT {top_n};
"""

SQL_TOP_ROWS = """
SELECT
    queryid,
    calls,
    rows,
    round(rows::numeric / nullif(calls, 0), 0) AS rows_per_call,
    round(mean_exec_time::numeric, 2) AS mean_time_ms,
    query
FROM pg_stat_statements
WHERE dbid = (SELECT oid FROM pg_database WHERE datname = current_database())
  AND calls > {min_calls}
ORDER BY rows::numeric / nullif(calls, 0) DESC
LIMIT {top_n};
"""

SQL_CONNECTIONS_BY_USER = """
SELECT
    usename,
    application_name,
    state,
    count(*) AS cnt
FROM pg_stat_activity
WHERE backend_type = 'client backend'
GROUP BY usename, application_name, state
ORDER BY cnt DESC
LIMIT 20;
"""

SQL_LONG_RUNNING = """
SELECT
    pid,
    now() - xact_start AS duration,
    usename,
    application_name,
    state,
    left(query, 200) AS query
FROM pg_stat_activity
WHERE state != 'idle'
  AND xact_start < now() - interval '5 minutes'
  AND backend_type = 'client backend'
ORDER BY xact_start ASC;
"""

SQL_LOCK_WAITS = """
SELECT
    blocked.pid AS blocked_pid,
    blocked.usename AS blocked_user,
    left(blocked.query, 100) AS blocked_query,
    blocking.pid AS blocking_pid,
    blocking.usename AS blocking_user,
    left(blocking.query, 100) AS blocking_query,
    now() - blocked.xact_start AS wait_duration
FROM pg_stat_activity blocked
JOIN pg_locks bl ON bl.pid = blocked.pid AND NOT bl.granted
JOIN pg_locks gl ON gl.pid != blocked.pid
    AND gl.transactionid = bl.transactionid AND gl.granted
JOIN pg_stat_activity blocking ON blocking.pid = gl.pid
ORDER BY wait_duration DESC;
"""


class PostgreSQLPlugin(BasePlugin):
    """PostgreSQL performance analyzer."""

    name = "pg"
    description = "Find who's overloading PostgreSQL"

    def _get_connection(self) -> DirectPGConnection | SSHConnection:
        method = self.target.get("method", "direct")

        if method == "ssh":
            return SSHConnection(
                host=self.target["ssh_host"],
                user=self.target.get("ssh_user", "root"),
                port=self.target.get("ssh_port", 22),
                key_path=self.target.get("ssh_key"),
            )
        else:
            password = ""
            pw_env = self.target.get("password_env")
            if pw_env:
                password = os.environ.get(pw_env, "")
            else:
                password = self.target.get("password", "")

            return DirectPGConnection(
                host=self.target.get("host", "localhost"),
                port=self.target.get("port", 5432),
                user=self.target.get("user", "postgres"),
                password=password,
                dbname=self.target.get("dbname", "postgres"),
            )

    def _query(self, conn: Any, sql: str) -> list[dict[str, Any]]:
        """Execute SQL through either direct or SSH connection."""
        if isinstance(conn, SSHConnection):
            raw = conn.execute_psql(
                sql,
                dbname=self.target.get("dbname", "postgres"),
                pg_user=self.target.get("pg_user", "postgres"),
            )
            return self._parse_psql_output(raw, sql)
        rows: list[dict[str, Any]] = conn.execute(sql)
        return rows

    def _parse_psql_output(self, raw: str, sql: str) -> list[dict[str, Any]]:
        """Parse psql -t -A -F '|' output into list of dicts.

        Since we use -t (tuples only), we don't get headers.
        We infer column names from the SQL SELECT clause.
        """
        lines = [line.strip() for line in raw.strip().split("\n") if line.strip()]
        if not lines:
            return []

        # Extract column aliases from SQL
        columns = self._extract_columns(sql)

        results = []
        for line in lines:
            values = line.split("|")
            if len(values) == len(columns):
                row = {}
                for col, val in zip(columns, values, strict=False):
                    row[col] = self._coerce_value(val.strip())
                results.append(row)

        return results

    def _extract_columns(self, sql: str) -> list[str]:
        """Extract column names/aliases from a SELECT statement."""
        import re

        # Find the SELECT ... FROM part
        match = re.search(r"SELECT\s+(.*?)\s+FROM", sql, re.DOTALL | re.IGNORECASE)
        if not match:
            return []

        select_part = match.group(1)
        columns = []

        # Split by comma, respecting parentheses
        depth = 0
        current: list[str] = []
        for char in select_part:
            if char == "(":
                depth += 1
            elif char == ")":
                depth -= 1
            elif char == "," and depth == 0:
                columns.append("".join(current).strip())
                current = []
                continue
            current.append(char)
        columns.append("".join(current).strip())

        # Extract alias (AS name) or last identifier
        result = []
        for col in columns:
            # Check for AS alias
            as_match = re.search(r"\bAS\s+(\w+)\s*$", col, re.IGNORECASE)
            if as_match:
                result.append(as_match.group(1))
            else:
                # Use last word
                words = re.findall(r"\w+", col)
                result.append(words[-1] if words else "col")

        return result

    def _coerce_value(self, val: str) -> Any:
        """Try to convert string values to appropriate Python types."""
        if val == "" or val.lower() == "null":
            return None
        try:
            return int(val)
        except ValueError:
            pass
        try:
            return float(val)
        except ValueError:
            pass
        return val

    def analyze(self) -> AnalysisResult:
        """Run full PostgreSQL analysis."""
        conn = self._get_connection()
        findings: list[Finding] = []
        raw_data: dict[str, Any] = {}

        top_n = self.settings.get("top_n", 10)
        min_calls = self.settings.get("min_calls", 100)
        cache_threshold = self.settings.get("cache_hit_threshold", 95.0)

        try:
            if isinstance(conn, SSHConnection):
                conn.connect()

            # --- System info ---
            version_rows = self._query(conn, SQL_VERSION)
            uptime_rows = self._query(conn, SQL_UPTIME)
            size_rows = self._query(conn, SQL_DB_SIZE)
            conn_rows = self._query(conn, SQL_CONNECTIONS)

            sys_info = SystemInfo(
                name=self.target.get("name", "unknown"),
                host=self.target.get("host", self.target.get("ssh_host", "")),
                version=str(version_rows[0].get("version", "")) if version_rows else "",
                uptime=str(uptime_rows[0].get("uptime", "")) if uptime_rows else "",
                extra={},
            )

            if conn_rows:
                c = conn_rows[0]
                sys_info.extra["connections"] = f"{c.get('total', '?')}/{c.get('max_conn', '?')}"
                sys_info.extra["active"] = str(c.get("active", "?"))
                sys_info.extra["idle_in_tx"] = str(c.get("idle_in_tx", "?"))

            if size_rows:
                sys_info.extra["db_size"] = str(size_rows[0].get("size", "?"))

            # --- Check pg_stat_statements availability ---
            pss_rows = self._query(conn, SQL_PG_STAT_STATEMENTS_AVAILABLE)
            has_pss = bool(pss_rows and pss_rows[0].get("cnt", 0))
            if not has_pss:
                findings.append(Finding(
                    severity=Severity.YELLOW,
                    category="config",
                    title="pg_stat_statements is not installed",
                    detail="CPU, disk I/O, cache, and row analyses are unavailable",
                    recommendation=(
                        "Run: CREATE EXTENSION pg_stat_statements; "
                        "and add shared_preload_libraries = 'pg_stat_statements' to postgresql.conf"
                    ),
                ))

            if has_pss:
                # --- Top CPU ---
                cpu_rows = self._query(conn, SQL_TOP_CPU.format(top_n=top_n))
                raw_data["top_cpu"] = cpu_rows
            else:
                cpu_rows = []
            for i, row in enumerate(cpu_rows[:5]):
                pct = row.get("pct_total", 0)
                if pct > 20:
                    severity = Severity.RED
                elif pct > 5:
                    severity = Severity.YELLOW
                else:
                    severity = Severity.INFO
                findings.append(Finding(
                    severity=severity,
                    category="cpu",
                    title=f"#{i+1} CPU: {pct}% of total exec time ({row.get('calls', 0):,} calls)",
                    detail=(
                        f"total={row.get('total_time_ms', 0)}ms, "
                        f"mean={row.get('mean_time_ms', 0)}ms, "
                        f"rows={row.get('rows', 0):,}"
                    ),
                    recommendation="Run EXPLAIN ANALYZE to check for Seq Scans or missing indexes",
                    query=str(row.get("query", ""))[:500],
                    metrics=row,
                ))

            if has_pss:
                # --- Top disk read ---
                disk_rows = self._query(conn, SQL_TOP_DISK_READ.format(top_n=top_n))
                raw_data["top_disk_read"] = disk_rows
                for row in disk_rows[:5]:
                    cache_pct = row.get("cache_hit_pct", 100)
                    if cache_pct is not None and cache_pct < cache_threshold:
                        blks = row.get("shared_blks_read", 0)
                        findings.append(Finding(
                            severity=Severity.RED if cache_pct < 80 else Severity.YELLOW,
                            category="disk_io",
                            title=f"Cache hit {cache_pct}% — reads {blks:,} blocks from disk",
                            detail=(
                                f"calls={row.get('calls', 0):,}, "
                                f"total_time={row.get('total_time_ms', 0)}ms"
                            ),
                            recommendation=(
                                "Check shared_buffers sizing, consider partitioning large tables"
                            ),
                            query=str(row.get("query", ""))[:500],
                            metrics=row,
                        ))

                # --- Worst cache ---
                cache_rows = self._query(
                    conn, SQL_WORST_CACHE.format(top_n=top_n, min_blocks=100)
                )
                raw_data["worst_cache"] = cache_rows
                for row in cache_rows[:5]:
                    cache_pct = row.get("cache_hit_pct", 100)
                    if cache_pct is not None and cache_pct < cache_threshold:
                        findings.append(Finding(
                            severity=Severity.RED if cache_pct < 80 else Severity.YELLOW,
                            category="cache",
                            title=f"Poor cache hit {cache_pct}% on frequent query",
                            detail=(
                                f"calls={row.get('calls', 0):,}, "
                                f"blks_read={row.get('shared_blks_read', 0):,}, "
                                f"mean={row.get('mean_time_ms', 0)}ms"
                            ),
                            recommendation=(
                                "Increase shared_buffers, check for large sequential scans"
                            ),
                            query=str(row.get("query", ""))[:500],
                            metrics=row,
                        ))

                # --- Top rows per call ---
                rows_rows = self._query(
                    conn, SQL_TOP_ROWS.format(top_n=top_n, min_calls=min_calls)
                )
                raw_data["top_rows_per_call"] = rows_rows
                for row in rows_rows[:5]:
                    rpc = row.get("rows_per_call", 0)
                    if rpc and rpc > 1000:
                        findings.append(Finding(
                            severity=Severity.YELLOW if rpc < 10000 else Severity.RED,
                            category="rows",
                            title=(
                                f"Returns {int(rpc):,} rows/call"
                                " — possible missing LIMIT or full scan"
                            ),
                            detail=(
                                f"calls={row.get('calls', 0):,}, "
                                f"mean_time={row.get('mean_time_ms', 0)}ms"
                            ),
                            recommendation=(
                                "Add LIMIT, check if application needs all rows,"
                                " consider pagination"
                            ),
                            query=str(row.get("query", ""))[:500],
                            metrics=row,
                        ))

            # --- Connections by user ---
            conn_by_user = self._query(conn, SQL_CONNECTIONS_BY_USER)
            raw_data["connections_by_user"] = conn_by_user
            for row in conn_by_user[:10]:
                cnt = row.get("cnt", 0)
                state = row.get("state", "")
                user = row.get("usename", "?")
                app = row.get("application_name", "")
                severity = Severity.INFO
                if state == "idle in transaction" and cnt > 5:
                    severity = Severity.RED
                elif cnt > 20:
                    severity = Severity.YELLOW
                findings.append(Finding(
                    severity=severity,
                    category="connections",
                    title=f"{cnt} connections — {user} / {app} [{state}]",
                    detail=f"user={user}, app={app}, state={state}, count={cnt}",
                    recommendation=(
                        "Use a connection pooler (PgBouncer) if counts are high"
                        if cnt > 20
                        else "Monitor for idle-in-transaction connections — they hold locks"
                        if state == "idle in transaction"
                        else ""
                    ),
                    metrics=row,
                ))

            # --- Long-running queries ---
            long_running = self._query(conn, SQL_LONG_RUNNING)
            raw_data["long_running"] = long_running
            for row in long_running:
                findings.append(Finding(
                    severity=Severity.RED,
                    category="long_running",
                    title=(
                        f"Long-running query: pid={row.get('pid')}"
                        f" for {row.get('duration')}"
                    ),
                    detail=(
                        f"user={row.get('usename')}, "
                        f"app={row.get('application_name')}, "
                        f"state={row.get('state')}"
                    ),
                    recommendation=(
                        "Check if this is expected; consider pg_terminate_backend() if stuck"
                    ),
                    query=str(row.get("query", ""))[:500],
                    metrics=row,
                ))

            # --- Lock waits ---
            lock_waits = self._query(conn, SQL_LOCK_WAITS)
            raw_data["lock_waits"] = lock_waits
            for row in lock_waits:
                findings.append(Finding(
                    severity=Severity.RED,
                    category="locks",
                    title=(
                        f"Lock wait: pid {row.get('blocked_pid')}"
                        f" blocked by {row.get('blocking_pid')}"
                        f" for {row.get('wait_duration')}"
                    ),
                    detail=(
                        f"blocked={row.get('blocked_user')}: "
                        f"{str(row.get('blocked_query', ''))[:120]}\n"
                        f"        blocking={row.get('blocking_user')}: "
                        f"{str(row.get('blocking_query', ''))[:120]}"
                    ),
                    recommendation="Investigate blocking query; consider lock_timeout setting",
                    query=str(row.get("blocked_query", ""))[:500],
                    metrics=row,
                ))

            # Sort findings: RED first, then YELLOW, then INFO
            severity_order = {Severity.RED: 0, Severity.YELLOW: 1, Severity.INFO: 2}
            findings.sort(key=lambda f: severity_order[f.severity])

            return AnalysisResult(
                system_info=sys_info,
                findings=findings,
                raw_data=raw_data,
            )

        finally:
            if isinstance(conn, SSHConnection):
                conn.close()
            elif hasattr(conn, "close"):
                conn.close()
