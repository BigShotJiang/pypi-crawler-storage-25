"""Allow running as python -m wholoads."""
from wholoads.cli import app

app()
