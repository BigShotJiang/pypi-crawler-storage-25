"""wholoads — find who's overloading your infrastructure."""

from importlib.metadata import version

__version__ = version("wholoads")
