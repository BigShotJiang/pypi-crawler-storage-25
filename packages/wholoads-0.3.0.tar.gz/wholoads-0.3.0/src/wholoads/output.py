"""Output formatters: rich, json, csv, markdown."""

from __future__ import annotations

import csv
import io
import json

from rich.console import Console
from rich.panel import Panel

from wholoads.core.plugin import AnalysisResult, Finding, Severity

SEVERITY_ICONS = {
    Severity.RED: "🔴",
    Severity.YELLOW: "🟡",
    Severity.INFO: "⚪",
}

SEVERITY_COLORS = {
    Severity.RED: "red",
    Severity.YELLOW: "yellow",
    Severity.INFO: "dim",
}


def render_result(
    result: AnalysisResult,
    fmt: str = "rich",
    console: Console | None = None,
    truncate_query: int = 80,
) -> str | None:
    """Render analysis result in the specified format.

    Args:
        truncate_query: max query chars to display (0 = no truncation).
    """
    if fmt == "rich":
        _render_rich(result, console or Console(), truncate_query=truncate_query)
        return None
    elif fmt == "json":
        output = _render_json(result)
        if console:
            console.print(output)
        return output
    elif fmt == "csv":
        output = _render_csv(result)
        if console:
            console.print(output)
        return output
    elif fmt == "markdown":
        output = _render_markdown(result)
        if console:
            console.print(output)
        return output
    else:
        raise ValueError(f"Unknown format: {fmt}")


def _render_rich(result: AnalysisResult, console: Console, truncate_query: int = 80) -> None:
    """Render with rich tables and panels."""
    info = result.system_info

    # Header panel
    header_parts = [f"[bold]{info.name}[/bold] ({info.host})"]
    if info.version:
        # Extract short version
        ver_short = info.version.split(",")[0] if "," in info.version else info.version
        header_parts.append(f"Version: {ver_short}")
    if info.uptime:
        header_parts.append(f"Uptime: {info.uptime}")

    extras = []
    for k, v in info.extra.items():
        extras.append(f"{k}: {v}")
    if extras:
        header_parts.append(" │ ".join(extras))

    console.print(Panel(
        "\n".join(header_parts),
        title="[bold blue]wholoads[/bold blue]",
        border_style="blue",
    ))

    if not result.findings:
        console.print("[green]No issues found! Everything looks healthy.[/green]")
        return

    # Summary
    console.print(
        f"\nFound: "
        f"[red]{result.red_count} critical[/red], "
        f"[yellow]{result.yellow_count} warning[/yellow], "
        f"[dim]{len(result.findings) - result.red_count - result.yellow_count} info[/dim]\n"
    )

    # Group findings by category
    categories: dict[str, list[Finding]] = {}
    for f in result.findings:
        categories.setdefault(f.category, []).append(f)

    category_titles = {
        "cpu": "TOP CPU CONSUMERS",
        "disk_io": "DISK I/O (CACHE MISSES)",
        "rows": "EXCESSIVE ROWS RETURNED",
        "long_running": "LONG-RUNNING QUERIES",
        "locks": "LOCK WAITS",
        "connections": "CONNECTIONS",
        "memory": "MEMORY USAGE",
        "merges": "MERGES & MUTATIONS",
    }

    for cat, findings in categories.items():
        title = category_titles.get(cat, cat.upper())
        icon = SEVERITY_ICONS[findings[0].severity]

        console.print(f"\n{icon} [bold]{title}[/bold]")
        console.print("─" * 60)

        for f in findings:
            color = SEVERITY_COLORS[f.severity]
            console.print(f"  [{color}]{SEVERITY_ICONS[f.severity]} {f.title}[/{color}]")
            console.print(f"    {f.detail}")
            if f.query:
                if truncate_query and len(f.query) > truncate_query:
                    q = f.query[:truncate_query] + "..."
                else:
                    q = f.query
                console.print(f"    [dim]Query: {q}[/dim]")
            console.print(f"    [green]→ {f.recommendation}[/green]")
            console.print()


def _render_json(result: AnalysisResult) -> str:
    """Render as JSON."""
    data = {
        "system": {
            "name": result.system_info.name,
            "host": result.system_info.host,
            "version": result.system_info.version,
            "uptime": result.system_info.uptime,
            **result.system_info.extra,
        },
        "summary": {
            "total_findings": len(result.findings),
            "critical": result.red_count,
            "warning": result.yellow_count,
        },
        "findings": [
            {
                "severity": f.severity.value,
                "category": f.category,
                "title": f.title,
                "detail": f.detail,
                "recommendation": f.recommendation,
                "query": f.query,
                "metrics": f.metrics,
            }
            for f in result.findings
        ],
        "raw_data": result.raw_data,
    }
    return json.dumps(data, indent=2, default=str)


def _render_csv(result: AnalysisResult) -> str:
    """Render findings as CSV."""
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(["severity", "category", "title", "detail", "recommendation", "query"])

    for f in result.findings:
        writer.writerow([
            f.severity.value,
            f.category,
            f.title,
            f.detail,
            f.recommendation,
            f.query or "",
        ])

    return output.getvalue()


def _render_markdown(result: AnalysisResult) -> str:
    """Render as Markdown."""
    lines = []
    info = result.system_info

    lines.append(f"# wholoads: {info.name}")
    lines.append("")
    lines.append(f"**Host:** {info.host}")
    if info.uptime:
        lines.append(f"**Uptime:** {info.uptime}")
    for k, v in info.extra.items():
        lines.append(f"**{k}:** {v}")
    lines.append("")

    lines.append(
        f"**Summary:** {result.red_count} critical, "
        f"{result.yellow_count} warning, "
        f"{len(result.findings) - result.red_count - result.yellow_count} info"
    )
    lines.append("")
    lines.append("---")
    lines.append("")

    for f in result.findings:
        icon = SEVERITY_ICONS[f.severity]
        lines.append(f"### {icon} {f.title}")
        lines.append("")
        lines.append(f"**Category:** {f.category} | **Severity:** {f.severity.value}")
        lines.append("")
        lines.append(f.detail)
        if f.query:
            lines.append("")
            lines.append(f"```sql\n{f.query}\n```")
        lines.append("")
        lines.append(f"**Recommendation:** {f.recommendation}")
        lines.append("")
        lines.append("---")
        lines.append("")

    return "\n".join(lines)
