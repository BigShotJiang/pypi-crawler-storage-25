import sys

import click

from plain.cli import register_cli
from plain.runtime import settings
from plain.utils.module_loading import import_string

from .openapi.generator import OpenAPISchemaGenerator
from .openapi.validation import OpenAPIValidationError, validate_openapi_schema


@register_cli("api")
@click.group()
def cli() -> None:
    """API commands"""


@cli.command()
@click.option(
    "--validate",
    is_flag=True,
    help="Validate the OpenAPI schema (requires openapi-spec-validator).",
)
@click.option("--indent", default=2, help="Indentation level for JSON and YAML output.")
@click.option(
    "--format",
    default="json",
    help="Output format (json or yaml).",
    type=click.Choice(["json", "yaml"]),
)
def generate_openapi(validate: bool, indent: int, format: str) -> None:
    if not settings.API_OPENAPI_ROUTER:
        click.secho("No OpenAPI URL router configured.", fg="red", err=True)
        sys.exit(1)

    url_router_class = import_string(settings.API_OPENAPI_ROUTER)

    schema = OpenAPISchemaGenerator(url_router_class)

    if format == "json":
        print(schema.as_json(indent=indent))
    elif format == "yaml":
        print(schema.as_yaml(indent=indent))

    if validate:
        click.secho("\nOpenAPI schema validation: ", err=True, nl=False)
        try:
            validate_openapi_schema(schema.schema)
        except OpenAPIValidationError as exc:
            click.secho("Failed", fg="red", err=True)
            click.secho(str(exc), fg="yellow", err=True)
            sys.exit(1)
        click.secho("Success", fg="green", err=True)
