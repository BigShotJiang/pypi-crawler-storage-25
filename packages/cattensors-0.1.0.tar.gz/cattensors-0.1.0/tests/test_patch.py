import os
import sys
from unittest import mock

import pytest
import safetensors
import safetensors.torch

# cattensors.__init__ shadows the submodule with `from cattensors.patch import patch`,
# so we must grab the actual module from sys.modules.
import cattensors.patch  # noqa: F401

patch_mod = sys.modules["cattensors.patch"]

from cattensors.patch import (  # noqa: E402
    WarmingSafeOpen,
    _detect_sibling_shards,
    _warm_with_flock,
    patch,
    unpatch,
    warming_load_file,
)


@pytest.fixture(autouse=True)
def _ensure_unpatched():
    """Unpatch after every test to avoid leaking state."""
    yield
    unpatch()
    patch_mod._warmed_shards.clear()


class TestPatchUnpatch:
    def test_patch_replaces_safetensors(self):
        # Ensure clean state — startup.py may have auto-patched
        unpatch()
        original_safe_open = safetensors.safe_open
        original_load_file = safetensors.torch.load_file

        patch()
        assert safetensors.safe_open is WarmingSafeOpen
        assert safetensors.torch.safe_open is WarmingSafeOpen
        assert safetensors.torch.load_file is warming_load_file

        unpatch()
        assert safetensors.safe_open is original_safe_open
        assert safetensors.torch.load_file is original_load_file

    def test_patch_is_idempotent(self):
        patch()
        first_safe_open = safetensors.safe_open
        patch()  # second call should be no-op
        assert safetensors.safe_open is first_safe_open

    def test_unpatch_is_idempotent(self):
        unpatch()  # should be no-op when not patched
        unpatch()

    def test_unpatch_clears_warmed_shards(self):
        patch()
        patch_mod._warmed_shards.add("dummy")
        unpatch()
        assert len(patch_mod._warmed_shards) == 0

    def test_patched_flag(self):
        assert patch_mod._patched is False
        patch()
        assert patch_mod._patched is True
        unpatch()
        assert patch_mod._patched is False


class TestDetectSiblingShards:
    def test_returns_shard_paths(self, tmp_sharded_model):
        tmp_path, info = tmp_sharded_model
        result = _detect_sibling_shards(info["shard1"])
        assert result is not None
        assert len(result) == 2
        assert info["shard1"] in result
        assert info["shard2"] in result

    def test_returns_none_for_non_sharded(self, tmp_safetensors):
        path, _ = tmp_safetensors
        result = _detect_sibling_shards(path)
        assert result is None

    def test_sorted_and_deduped(self, tmp_sharded_model):
        tmp_path, info = tmp_sharded_model
        result = _detect_sibling_shards(info["shard1"])
        assert result
        assert result == sorted(result)


class TestWarmingLoadFile:
    def test_default_loader(self, tmp_safetensors):
        """Without special flags, warming_load_file delegates to original load_file."""
        path, expected = tmp_safetensors
        patch()
        result = warming_load_file(path, device="cpu")
        assert set(result.keys()) == set(expected.keys())

    def test_warmed_shards_tracked(self, tmp_safetensors):
        path, _ = tmp_safetensors
        patch()
        patch_mod._warmed_shards.clear()
        warming_load_file(path, device="cpu")
        assert path in patch_mod._warmed_shards

    def test_parallel_shard_warming(self, tmp_sharded_model, monkeypatch):
        """When parallel shards enabled, all sibling shards are warmed."""
        monkeypatch.setenv("CATTENSORS_PARALLEL_SHARDS", "1")
        monkeypatch.setenv("HF_ENABLE_PARALLEL_LOADING", "0")
        _, info = tmp_sharded_model
        patch()
        patch_mod._warmed_shards.clear()
        warming_load_file(info["shard1"], device="cpu")
        assert info["shard1"] in patch_mod._warmed_shards
        assert info["shard2"] in patch_mod._warmed_shards

    def test_skips_parallel_when_hf_parallel(self, tmp_sharded_model, monkeypatch):
        """When HF parallel loading is enabled, skip parallel shard warming."""
        monkeypatch.setenv("CATTENSORS_PARALLEL_SHARDS", "1")
        monkeypatch.setenv("HF_ENABLE_PARALLEL_LOADING", "1")
        _, info = tmp_sharded_model
        patch()
        patch_mod._warmed_shards.clear()
        warming_load_file(info["shard1"], device="cpu")
        # Only the single file should be warmed, not both shards
        assert info["shard1"] in patch_mod._warmed_shards

    def test_no_duplicate_warming(self, tmp_safetensors):
        """Same file loaded twice should only be warmed once."""
        path, _ = tmp_safetensors
        patch()
        patch_mod._warmed_shards.clear()

        with mock.patch("cattensors.patch._warm_with_flock") as mock_warm:
            warming_load_file(path, device="cpu")
            warming_load_file(path, device="cpu")
            # Only called once since second call finds path in _warmed_shards
            assert mock_warm.call_count == 1


class TestWarmWithFlock:
    def test_single_file(self, large_tmp_file):
        path, _ = large_tmp_file
        _warm_with_flock(path)

    def test_multiple_files(self, tmp_path):
        for i in range(3):
            p = str(tmp_path / f"f{i}.bin")
            with open(p, "wb") as f:
                f.write(os.urandom(1024))
            _warm_with_flock(p)

    def test_lock_file_created(self, large_tmp_file, tmp_path):
        import glob
        import tempfile

        path, _ = large_tmp_file
        _warm_with_flock(path)
        lock_files = glob.glob(
            os.path.join(tempfile.gettempdir(), "cattensors_warm_*.lock")
        )
        assert len(lock_files) > 0


class TestWarmingSafeOpen:
    def test_requires_patch(self):
        """WarmingSafeOpen asserts patch has been applied."""
        with pytest.raises(AssertionError, match="has not been patched"):
            WarmingSafeOpen("dummy.safetensors")
