import importlib
import sys
from unittest import mock

import pytest

import cattensors.patch  # noqa: F401

patch_mod = sys.modules["cattensors.patch"]


@pytest.fixture(autouse=True)
def _ensure_unpatched():
    yield
    patch_mod.unpatch()


class TestStartup:
    def test_auto_patch_when_enabled(self, monkeypatch):
        monkeypatch.setenv("CATTENSORS_AUTO_PATCH", "1")
        import cattensors.startup

        importlib.reload(cattensors.startup)
        assert patch_mod._patched is True

    def test_no_auto_patch_when_disabled(self, monkeypatch):
        monkeypatch.setenv("CATTENSORS_AUTO_PATCH", "0")
        patch_mod.unpatch()
        import cattensors.startup

        importlib.reload(cattensors.startup)
        assert patch_mod._patched is False

    def test_startup_swallows_exceptions(self, monkeypatch):
        """startup must not raise even if patch() fails."""
        monkeypatch.setenv("CATTENSORS_AUTO_PATCH", "1")

        with mock.patch(
            "cattensors.patch.patch", side_effect=RuntimeError("broken env")
        ):
            import cattensors.startup

            importlib.reload(cattensors.startup)
