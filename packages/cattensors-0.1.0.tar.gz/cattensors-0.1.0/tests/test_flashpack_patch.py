import sys
from unittest import mock

import pytest

flashpack = pytest.importorskip("flashpack")
flashpack_deser = pytest.importorskip("flashpack.deserialization")

import cattensors.flashpack_patch  # noqa: E402, F401
import cattensors.patch  # noqa: E402, F401

fp_patch_mod = sys.modules["cattensors.flashpack_patch"]
patch_mod = sys.modules["cattensors.patch"]

from cattensors.flashpack_patch import (  # noqa: E402
    _detect_pipeline_siblings,
    patch,
    unpatch,
    warming_read_flashpack_file,
)


@pytest.fixture(autouse=True)
def _ensure_unpatched():
    """Unpatch and clear shared state after every test."""
    yield
    unpatch()
    patch_mod._warmed_shards.clear()


class TestPatchUnpatch:
    def test_patch_replaces_read_flashpack_file(self):
        unpatch()
        original = flashpack_deser.read_flashpack_file

        patch()
        assert flashpack_deser.read_flashpack_file is warming_read_flashpack_file

        unpatch()
        assert flashpack_deser.read_flashpack_file is original

    def test_patch_is_idempotent(self):
        patch()
        first = flashpack_deser.read_flashpack_file
        patch()
        assert flashpack_deser.read_flashpack_file is first

    def test_unpatch_is_idempotent(self):
        unpatch()
        unpatch()

    def test_patched_flag(self):
        assert fp_patch_mod._patched is False
        patch()
        assert fp_patch_mod._patched is True
        unpatch()
        assert fp_patch_mod._patched is False


class TestDetectPipelineSiblings:
    def test_returns_peer_subfolders(self, tmp_flashpack_pipeline):
        _, paths = tmp_flashpack_pipeline
        result = _detect_pipeline_siblings(paths["unet"])
        assert result is not None
        assert set(result) == set(paths.values())

    def test_returns_none_for_non_pipeline(self, tmp_path):
        # Build an isolated layout: <root>/<sub>/model.flashpack with no peers.
        root = tmp_path / "isolated_root"
        sub = root / "only_sub"
        sub.mkdir(parents=True)
        path = sub / "model.flashpack"
        path.write_bytes(b"x")
        result = _detect_pipeline_siblings(str(path))
        assert result is None

    def test_returns_none_for_non_model_flashpack(self, tmp_path):
        p = tmp_path / "weights.flashpack"
        p.write_bytes(b"x")
        assert _detect_pipeline_siblings(str(p)) is None

    def test_sorted(self, tmp_flashpack_pipeline):
        _, paths = tmp_flashpack_pipeline
        result = _detect_pipeline_siblings(paths["unet"])
        assert result == sorted(result)  # ty: ignore[invalid-argument-type]


class TestWarmingReadFlashpackFile:
    def test_default_loader(self, tmp_flashpack):
        """Without special flags, warming_read_flashpack_file delegates and returns real data."""
        path, expected = tmp_flashpack
        patch()
        storage, meta = warming_read_flashpack_file(path, device="cpu")
        names = {rec["name"] for rec in meta["index"]}
        assert names == set(expected.keys())

    def test_warmed_paths_tracked(self, tmp_flashpack):
        path, _ = tmp_flashpack
        patch()
        patch_mod._warmed_shards.clear()
        warming_read_flashpack_file(path, device="cpu")
        assert path in patch_mod._warmed_shards

    def test_pipeline_sibling_warming(self, tmp_flashpack_pipeline, monkeypatch):
        """When parallel shards enabled, all peer subfolders are eagerly marked."""
        monkeypatch.setenv("CATTENSORS_PARALLEL_SHARDS", "1")
        monkeypatch.setenv("HF_ENABLE_PARALLEL_LOADING", "0")
        _, paths = tmp_flashpack_pipeline
        patch()
        patch_mod._warmed_shards.clear()
        warming_read_flashpack_file(paths["unet"], device="cpu")
        for p in paths.values():
            assert p in patch_mod._warmed_shards

    def test_skips_pipeline_warming_when_hf_parallel(
        self, tmp_flashpack_pipeline, monkeypatch
    ):
        monkeypatch.setenv("CATTENSORS_PARALLEL_SHARDS", "1")
        monkeypatch.setenv("HF_ENABLE_PARALLEL_LOADING", "1")
        _, paths = tmp_flashpack_pipeline
        patch()
        patch_mod._warmed_shards.clear()
        warming_read_flashpack_file(paths["unet"], device="cpu")
        assert paths["unet"] in patch_mod._warmed_shards
        # Peers should NOT be eagerly marked when HF parallel is on
        assert paths["vae"] not in patch_mod._warmed_shards

    def test_no_duplicate_warming(self, tmp_flashpack):
        path, _ = tmp_flashpack
        patch()
        patch_mod._warmed_shards.clear()

        with mock.patch("cattensors.flashpack_patch._warm_with_flock") as mock_warm:
            warming_read_flashpack_file(path, device="cpu")
            warming_read_flashpack_file(path, device="cpu")
            assert mock_warm.call_count == 1


class TestPatchAbsentFlashpack:
    def test_patch_no_op_when_flashpack_missing(self, monkeypatch):
        """patch() must soft-fail when flashpack is not installed."""
        # Force ImportError inside patch() by hiding flashpack.deserialization
        unpatch()

        real_import = (
            __builtins__["__import__"]
            if isinstance(__builtins__, dict)
            else __builtins__.__import__
        )

        def fake_import(name, *args, **kwargs):
            if name == "flashpack.deserialization" or name.startswith(
                "flashpack.deserialization"
            ):
                raise ImportError("hidden")
            return real_import(name, *args, **kwargs)

        with mock.patch("builtins.__import__", side_effect=fake_import):
            patch()
        assert fp_patch_mod._patched is False
