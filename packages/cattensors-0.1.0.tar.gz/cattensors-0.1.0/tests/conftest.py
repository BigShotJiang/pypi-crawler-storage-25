"""Shared fixtures for cattensors tests."""

import json
import os
import struct

import pytest
import torch


def _make_safetensors_file(path: str, tensors: dict[str, torch.Tensor]) -> None:
    """Write tensors to a safetensors file at path."""
    DTYPE_STR = {
        torch.float64: "F64",
        torch.float32: "F32",
        torch.float16: "F16",
        torch.bfloat16: "BF16",
        torch.int64: "I64",
        torch.int32: "I32",
        torch.int16: "I16",
        torch.int8: "I8",
        torch.uint8: "U8",
        torch.bool: "BOOL",
    }
    header = {}
    data_parts = []
    offset = 0
    for name, tensor in tensors.items():
        flat = (
            tensor.contiguous().view(torch.uint8)
            if tensor.dtype == torch.bool
            else tensor.contiguous().view(-1)
        )
        raw = flat.numpy().tobytes()
        nbytes = len(raw)
        header[name] = {
            "dtype": DTYPE_STR[tensor.dtype],
            "shape": list(tensor.shape),
            "data_offsets": [offset, offset + nbytes],
        }
        data_parts.append(raw)
        offset += nbytes

    header_bytes = json.dumps(header).encode("utf-8")
    header_size = len(header_bytes)

    with open(path, "wb") as f:
        f.write(struct.pack("<Q", header_size))
        f.write(header_bytes)
        for part in data_parts:
            f.write(part)


@pytest.fixture
def tmp_safetensors(tmp_path):
    """Create a temporary safetensors file with known tensors."""
    tensors = {
        "weight": torch.randn(4, 3, dtype=torch.float32),
        "bias": torch.randn(4, dtype=torch.float32),
    }
    path = str(tmp_path / "model.safetensors")
    _make_safetensors_file(path, tensors)
    return path, tensors


@pytest.fixture
def tmp_safetensors_multi_dtype(tmp_path):
    """Create a safetensors file with multiple dtypes."""
    tensors = {
        "f32": torch.randn(2, 3, dtype=torch.float32),
        "f16": torch.randn(2, 3, dtype=torch.float32).half(),
        "i32": torch.randint(-100, 100, (5,), dtype=torch.int32),
        "u8": torch.randint(0, 255, (3, 3), dtype=torch.uint8),
    }
    path = str(tmp_path / "multi_dtype.safetensors")
    _make_safetensors_file(path, tensors)
    return path, tensors


@pytest.fixture
def tmp_empty_safetensors(tmp_path):
    """Create a safetensors file with no tensors."""
    path = str(tmp_path / "empty.safetensors")
    header = {"__metadata__": {"format": "pt"}}
    header_bytes = json.dumps(header).encode("utf-8")
    with open(path, "wb") as f:
        f.write(struct.pack("<Q", len(header_bytes)))
        f.write(header_bytes)
    return path


@pytest.fixture
def tmp_sharded_model(tmp_path):
    """Create a sharded safetensors model with index file."""
    tensors_1 = {"layer1.weight": torch.randn(4, 3, dtype=torch.float32)}
    tensors_2 = {"layer2.weight": torch.randn(4, 3, dtype=torch.float32)}

    shard1 = str(tmp_path / "model-00001-of-00002.safetensors")
    shard2 = str(tmp_path / "model-00002-of-00002.safetensors")
    _make_safetensors_file(shard1, tensors_1)
    _make_safetensors_file(shard2, tensors_2)

    index = {
        "weight_map": {
            "layer1.weight": "model-00001-of-00002.safetensors",
            "layer2.weight": "model-00002-of-00002.safetensors",
        }
    }
    index_path = str(tmp_path / "model.safetensors.index.json")
    with open(index_path, "w") as f:
        json.dump(index, f)

    return tmp_path, {
        "shard1": shard1,
        "shard2": shard2,
        "index": index_path,
        "tensors_1": tensors_1,
        "tensors_2": tensors_2,
    }


@pytest.fixture
def large_tmp_file(tmp_path):
    """Create a ~1MB temp file for warming tests."""
    path = str(tmp_path / "large.bin")
    data = os.urandom(1024 * 1024)
    with open(path, "wb") as f:
        f.write(data)
    return path, len(data)


def _make_flashpack_file(path: str, tensors: dict[str, torch.Tensor]) -> None:
    """Write a minimal flashpack v4 file with a single fp32 macroblock.

    Layout: payload bytes, then UTF-8 JSON metadata, then 8-byte LE u64
    json_len, then 8-byte magic "FLASHPK\\0".
    """
    MAGIC = b"FLASHPK\0"
    payload_parts: list[bytes] = []
    index: list[dict] = []
    offset = 0
    for name, t in tensors.items():
        flat = t.contiguous().view(-1).to(torch.float32)
        raw = flat.numpy().tobytes()
        index.append(
            {
                "name": name,
                "shape": list(t.shape),
                "offset": offset,
                "length": flat.numel(),
                "macroblock": 0,
            }
        )
        offset += flat.numel()
        payload_parts.append(raw)

    payload = b"".join(payload_parts)
    meta = {
        "format": "flashpack_v4",
        "macroblocks": [
            {
                "dtype": "float32",
                "offset_bytes": 0,
                "length_bytes": len(payload),
                "length_elems": offset,
            }
        ],
        "index": index,
        "align_bytes": 0,
    }
    meta_bytes = json.dumps(meta).encode("utf-8")
    with open(path, "wb") as f:
        f.write(payload)
        f.write(meta_bytes)
        f.write(struct.pack("<Q", len(meta_bytes)))
        f.write(MAGIC)


@pytest.fixture
def tmp_flashpack(tmp_path):
    """Create a temporary flashpack file with known tensors."""
    tensors = {
        "weight": torch.randn(4, 3, dtype=torch.float32),
        "bias": torch.randn(4, dtype=torch.float32),
    }
    path = str(tmp_path / "model.flashpack")
    _make_flashpack_file(path, tensors)
    return path, tensors


@pytest.fixture
def tmp_flashpack_pipeline(tmp_path):
    """Create a diffusers-style pipeline layout with multiple model.flashpack files."""
    subfolders = ["unet", "vae", "text_encoder"]
    paths: dict[str, str] = {}
    for sub in subfolders:
        sub_dir = tmp_path / sub
        sub_dir.mkdir()
        p = str(sub_dir / "model.flashpack")
        _make_flashpack_file(p, {"w": torch.randn(2, 2, dtype=torch.float32)})
        paths[sub] = p
    return tmp_path, paths
