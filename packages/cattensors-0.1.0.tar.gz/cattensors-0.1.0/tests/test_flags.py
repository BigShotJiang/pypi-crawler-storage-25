import importlib
import os

import pytest


@pytest.fixture(autouse=True)
def _clean_env(monkeypatch):
    """Remove all CATTENSORS_ and HF_ env vars before each test."""
    for key in list(os.environ):
        if key.startswith("CATTENSORS_") or key == "HF_ENABLE_PARALLEL_LOADING":
            monkeypatch.delenv(key, raising=False)


def _reload_flags():
    import cattensors.flags as flags

    importlib.reload(flags)
    return flags


class TestParseBool:
    def test_empty_returns_default(self):
        from cattensors.flags import _parse_bool

        assert _parse_bool("", True) is True
        assert _parse_bool("", False) is False

    @pytest.mark.parametrize("val", ["1", "true", "yes", "True", "YES", "TRUE"])
    def test_truthy_values(self, val):
        from cattensors.flags import _parse_bool

        assert _parse_bool(val, False) is True

    @pytest.mark.parametrize("val", ["0", "false", "no", "anything", "2"])
    def test_falsy_values(self, val):
        from cattensors.flags import _parse_bool

        assert _parse_bool(val, True) is False


class TestBoolFlags:
    def test_debug_default_false(self):
        flags = _reload_flags()
        assert flags.CATTENSORS_DEBUG is False

    def test_debug_enabled(self, monkeypatch):
        monkeypatch.setenv("CATTENSORS_DEBUG", "1")
        flags = _reload_flags()
        assert flags.CATTENSORS_DEBUG is True

    def test_parallel_shards_default_false(self):
        flags = _reload_flags()
        assert flags.CATTENSORS_PARALLEL_SHARDS is False

    def test_parallel_shards_disabled(self, monkeypatch):
        monkeypatch.setenv("CATTENSORS_PARALLEL_SHARDS", "0")
        flags = _reload_flags()
        assert flags.CATTENSORS_PARALLEL_SHARDS is False

    def test_auto_patch_default_true(self):
        flags = _reload_flags()
        assert flags.CATTENSORS_AUTO_PATCH is True

    def test_hf_parallel_loading_default_false(self):
        flags = _reload_flags()
        assert flags.HF_ENABLE_PARALLEL_LOADING is False


class TestIntFlags:
    def test_warm_threads_default(self):
        flags = _reload_flags()
        assert flags.CATTENSORS_WARM_THREADS == 8

    def test_warm_threads_custom(self, monkeypatch):
        monkeypatch.setenv("CATTENSORS_WARM_THREADS", "4")
        flags = _reload_flags()
        assert flags.CATTENSORS_WARM_THREADS == 4


class TestUnknownFlag:
    def test_raises_attribute_error(self):
        flags = _reload_flags()
        with pytest.raises(AttributeError, match="has no attribute"):
            _ = flags.NONEXISTENT_FLAG


class TestLazyEvaluation:
    def test_flags_reflect_env_changes(self, monkeypatch):
        """Flags are read from env on every access, not cached."""
        flags = _reload_flags()
        assert flags.CATTENSORS_DEBUG is False
        monkeypatch.setenv("CATTENSORS_DEBUG", "1")
        assert flags.CATTENSORS_DEBUG is True
