import os

import pytest

from cattensors.reader import warm_multiple, warm_parallel_chunked


class TestWarmParallelChunked:
    def test_warms_file(self, large_tmp_file):
        path, size = large_tmp_file
        # Should complete without error
        warm_parallel_chunked(path, n_threads=4)

    def test_empty_file(self, tmp_path):
        path = str(tmp_path / "empty.bin")
        with open(path, "wb"):
            pass
        # Should return immediately for empty files
        warm_parallel_chunked(path, n_threads=2)

    def test_small_file(self, tmp_path):
        path = str(tmp_path / "small.bin")
        with open(path, "wb") as f:
            f.write(b"hello")
        warm_parallel_chunked(path, n_threads=4)

    def test_single_thread(self, large_tmp_file):
        path, _ = large_tmp_file
        warm_parallel_chunked(path, n_threads=1)

    def test_custom_chunk_size(self, large_tmp_file):
        path, _ = large_tmp_file
        warm_parallel_chunked(path, n_threads=2, chunk_size=1024)

    def test_file_not_found(self):
        with pytest.raises(FileNotFoundError):
            warm_parallel_chunked("/nonexistent/path.bin")


class TestWarmMultiple:
    def test_warms_multiple_files(self, tmp_path):
        paths = []
        for i in range(3):
            path = str(tmp_path / f"file_{i}.bin")
            with open(path, "wb") as f:
                f.write(os.urandom(4096))
            paths.append(path)
        warm_multiple(paths, n_threads_per_file=2)

    def test_empty_list(self):
        warm_multiple([])

    def test_single_file(self, large_tmp_file):
        path, _ = large_tmp_file
        warm_multiple([path], n_threads_per_file=2)
