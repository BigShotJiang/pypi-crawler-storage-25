import logging
import sys

from cattensors import flags


class _LazyDebugHandler(logging.Handler):
    """Emits only when CATTENSORS_DEBUG is enabled — checked at call time."""

    def __init__(self):
        super().__init__()
        self.setFormatter(
            logging.Formatter("%(asctime)s %(message)s", datefmt="%H:%M:%S")
        )

    def emit(self, record):
        if flags.CATTENSORS_DEBUG:
            sys.stderr.write(self.format(record) + "\n")


log = logging.getLogger("cattensors")
log.addHandler(_LazyDebugHandler())
log.setLevel(logging.DEBUG)
log.propagate = False
