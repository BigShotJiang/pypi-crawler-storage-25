try:
    from cattensors._version import __version__
except ModuleNotFoundError:
    __version__ = "0.0.0"
from cattensors.patch import patch, unpatch

__all__ = [
    "__version__",
    "patch",
    "unpatch",
]
