"""Auto-patch entrypoint for .pth file usage.

When cattensors.pth is in site-packages, Python runs `import cattensors.startup`
at interpreter startup, before any user code.
"""

try:
    import cattensors.logger  # noqa: F401 — attach lazy debug handler
    from cattensors import flags
    from cattensors.patch import patch

    if flags.CATTENSORS_AUTO_PATCH:
        patch()
except Exception as exc:
    # startup hook must not break interpreter initialization
    import sys

    print(f"[cattensors] startup failed: {exc}", file=sys.stderr)

try:
    from cattensors import flags as _fp_flags
    from cattensors.flashpack_patch import patch as _fp_patch

    if _fp_flags.CATTENSORS_AUTO_PATCH:
        _fp_patch()
except Exception as exc:
    import sys

    print(f"[cattensors] flashpack startup failed: {exc}", file=sys.stderr)
