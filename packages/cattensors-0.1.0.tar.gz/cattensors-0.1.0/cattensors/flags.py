import os

_BOOL_FLAGS = {
    # Enable verbose debug logging (timestamps, warming steps)
    "CATTENSORS_DEBUG": False,
    # Warm sibling shards in parallel when HF loads them sequentially
    "CATTENSORS_PARALLEL_SHARDS": False,
    # HF's own parallel shard loading, skip our parallel warming if enabled
    # unlike the other flags, this is not a flag we own. But rather a check
    # in our library to avoid overlapping I/O
    # TODO: we should change our logic to warm only the next shard unlike HF
    # where they warm everything at the same time. We are already attempting to
    # get maximum throughput per-shard using parallel threads, if we do parallel
    # shards we might end up slowing down the file system reads.
    "HF_ENABLE_PARALLEL_LOADING": False,
    # Whether to auto patch safetensors and flashpack at interpreter startup.
    # Flashpack patching soft-fails if flashpack is not installed.
    "CATTENSORS_AUTO_PATCH": True,
}

_INT_FLAGS = {
    # Number of threads for parallel warming
    "CATTENSORS_WARM_THREADS": 8,
}

_ALL_FLAGS = {**_BOOL_FLAGS, **_INT_FLAGS}


def _parse_bool(val: str, default: bool) -> bool:
    if not val:
        return default
    return val.lower() in ("1", "true", "yes")


def __getattr__(name: str) -> int | bool:
    if name not in _ALL_FLAGS:
        raise AttributeError(f"module {__name__!r} has no attribute {name!r}")

    val = os.environ.get(name, "")

    if name in _BOOL_FLAGS:
        return _parse_bool(val, _BOOL_FLAGS[name])
    return int(val) if val else _INT_FLAGS[name]
