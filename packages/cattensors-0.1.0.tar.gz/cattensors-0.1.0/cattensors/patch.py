import logging
import os
import threading
from collections.abc import Callable

from cattensors import flags
from cattensors.reader import warm_parallel_chunked

logger = logging.getLogger(__name__)

_original_safe_open: Callable | None = None
_original_load_file: Callable | None = None
_patched: bool = False
_warmed_shards: set[str] = set()  # track which shard groups we have already warmed
_warmed_shards_lock = threading.Lock()  # protect against concurrent load_file calls
_bg_warm_thread: threading.Thread | None = None


def _start_background_warm(paths: list[str]):
    """Warm sibling shards in a background thread so they're in the local cache
    when diffusers gets to them sequentially."""
    global _bg_warm_thread
    from cattensors.reader import warm_multiple

    if _bg_warm_thread is not None and _bg_warm_thread.is_alive():
        return  # already warming

    def _bg():
        logger.debug("[pid=%d] background warm: %d files", os.getpid(), len(paths))
        warm_multiple(paths)

    _bg_warm_thread = threading.Thread(target=_bg, daemon=True)
    _bg_warm_thread.start()


class WarmingSafeOpen:
    """Wraps the original safe_open with a pre-warm step."""

    def __init__(self, filename, framework="pt", device="cpu"):
        assert _original_safe_open is not None, "safe_open has not been patched"

        filename = str(filename)
        logger.debug(
            "[pid=%d] patch: warming safe_open(%s, device=%s)",
            os.getpid(),
            filename,
            device,
        )
        warm_parallel_chunked(filename)
        self._inner = _original_safe_open(filename, framework=framework, device=device)

    def __enter__(self):
        return self._inner.__enter__()

    def __exit__(self, *args):
        return self._inner.__exit__(*args)

    def keys(self):
        # safetensors returns keys in alphabetical order which causes
        # random I/O on distributed filesystems. We return offset-ordered
        # keys instead so reads are sequential.
        logger.debug(
            "[pid=%d] patch: keys() called, returning offset_keys()", os.getpid()
        )
        return self._inner.offset_keys()

    def __getattr__(self, name):
        return getattr(self._inner, name)


def warming_load_file(filename, device="cpu"):
    assert _original_load_file is not None, "load_file has not been patched"

    filename = str(filename)

    logger.debug(
        "[pid=%d] patch: warming load_file(%s, device=%s)",
        os.getpid(),
        filename,
        device,
    )

    # Decide what to warm under the lock, then do I/O outside.
    # We mark files in _warmed_shards eagerly (before the actual read)
    # so concurrent threads don't duplicate work. Warming is idempotent
    # (just cache-populating reads), so early marking is safe.
    parallel_shards = flags.CATTENSORS_PARALLEL_SHARDS

    warm_target = None
    bg_warm_targets = None
    with _warmed_shards_lock:
        if filename not in _warmed_shards:
            if parallel_shards:
                hf_parallel = flags.HF_ENABLE_PARALLEL_LOADING
                sibling_shards = _detect_sibling_shards(filename)

                if sibling_shards and not hf_parallel:
                    _warmed_shards.update(sibling_shards)
                    bg_warm_targets = [s for s in sibling_shards if s != filename]
                    warm_target = filename

            if warm_target is None:
                warm_target = filename
                _warmed_shards.add(filename)

    # Kick off background warming for a few sibling shards so they're in the
    # local cache by the time diffusers gets to them.  Limit to 3 shards to
    # avoid saturating the FUSE mount and starving the current shard's read.
    if bg_warm_targets:
        _start_background_warm(bg_warm_targets[:3])

    # Warm current file into page cache
    if warm_target is not None:
        _warm_with_flock(warm_target)

    return _original_load_file(filename, device=device)


def patch():
    """Wrap safetensors.safe_open and load_file with pre-warming.

    Call this before importing diffusers/transformers, or use the .pth file
    for automatic patching at interpreter startup.
    """
    global _original_safe_open, _original_load_file, _patched

    if _patched:
        return

    import safetensors
    import safetensors.torch

    # save originals
    _original_safe_open = safetensors.safe_open
    _original_load_file = safetensors.torch.load_file

    # patch at all levels
    safetensors.safe_open = WarmingSafeOpen  # ty: ignore[invalid-assignment]
    safetensors.torch.safe_open = WarmingSafeOpen  # ty: ignore[invalid-assignment]
    safetensors.torch.load_file = warming_load_file  # ty: ignore[invalid-assignment]

    try:
        import safetensors._safetensors_rust as _rust  # ty: ignore[unresolved-import]

        _rust.safe_open = WarmingSafeOpen
    except (ImportError, AttributeError):
        pass

    _patched = True
    logger.debug("[pid=%d] patch: safetensors patched", os.getpid())


def _detect_sibling_shards(filename: str) -> list[str] | None:
    """If filename is part of a sharded safetensors model, return all shard paths."""
    import json
    import re

    basename = os.path.basename(filename)
    # Sharded files follow the pattern: <prefix>-NNNNN-of-NNNNN.safetensors
    # Derive the index name: <prefix>.safetensors.index.json
    m = re.match(r"^(.+)-\d{5}-of-\d{5}\.safetensors$", basename)
    if not m:
        return None

    directory = os.path.dirname(filename)
    index_path = os.path.join(directory, f"{m.group(1)}.safetensors.index.json")
    try:
        with open(index_path) as f:
            index = json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        return None

    shard_names = sorted(set(index["weight_map"].values()))
    return [os.path.join(directory, name) for name in shard_names]


def _warm_with_flock(path: str):
    """Warm a single file with cross-process coordination via file lock.

    Uses fcntl.flock on a node-local lock file so only one process per node
    does the slow network read. Other processes wait on the lock, then their
    warming hits the hot local cache (fast).
    """
    import fcntl
    import hashlib
    import tempfile

    lock_key = os.path.abspath(path)
    path_hash = hashlib.md5(lock_key.encode()).hexdigest()[:12]
    lock_path = os.path.join(tempfile.gettempdir(), f"cattensors_warm_{path_hash}.lock")

    fd = os.open(lock_path, os.O_WRONLY | os.O_CREAT, 0o644)
    try:
        logger.debug("[pid=%d] patch: acquiring flock %s", os.getpid(), lock_path)
        fcntl.flock(fd, fcntl.LOCK_EX)
        logger.debug("[pid=%d] patch: acquired flock, warming %s", os.getpid(), path)
        warm_parallel_chunked(path)
    finally:
        fcntl.flock(fd, fcntl.LOCK_UN)
        logger.debug("[pid=%d] patch: released flock", os.getpid())
        os.close(fd)


def unpatch():
    """Restore original safetensors functions."""
    global _original_safe_open, _original_load_file, _patched

    if not _patched:
        return

    import safetensors
    import safetensors.torch

    safetensors.safe_open = _original_safe_open  # ty: ignore[invalid-assignment]
    safetensors.torch.safe_open = _original_safe_open  # ty: ignore[invalid-assignment]
    safetensors.torch.load_file = _original_load_file  # ty: ignore[invalid-assignment]

    try:
        import safetensors._safetensors_rust as _rust  # ty: ignore[unresolved-import]

        _rust.safe_open = _original_safe_open
    except (ImportError, AttributeError):
        pass

    _original_safe_open = None
    _original_load_file = None
    _patched = False
    _warmed_shards.clear()
    logger.debug("[pid=%d] unpatch: safetensors restored", os.getpid())
