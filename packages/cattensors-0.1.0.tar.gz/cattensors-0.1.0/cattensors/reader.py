import logging
import os
import threading
import time

from cattensors import flags

logger = logging.getLogger(__name__)


def _pid():
    return os.getpid()


def warm_parallel_chunked(
    path: str,
    n_threads: int | None = None,
    chunk_size: int = 4 * 1024 * 1024,
):
    """Read a file into the OS page cache so subsequent mmap/open access is fast.

    Splits the file into n_threads contiguous ranges, each read sequentially in its
    own thread with its own file descriptor. chunk_size controls the read buffer size.
    """
    if n_threads is None:
        n_threads = flags.CATTENSORS_WARM_THREADS

    logger.debug(
        "[pid=%d] warm_parallel_chunked: %s (%d threads)", _pid(), path, n_threads
    )
    t0 = time.perf_counter()

    size = os.path.getsize(path)
    if size == 0:
        return

    bytes_per_thread = size // n_threads

    def _read_range(start: int, end: int):
        fd = os.open(path, os.O_RDONLY)
        try:
            os.lseek(fd, start, os.SEEK_SET)
            remaining = end - start
            while remaining > 0:
                to_read = min(chunk_size, remaining)
                data = os.read(fd, to_read)
                if not data:
                    break
                remaining -= len(data)
        finally:
            os.close(fd)

    threads = []
    for i in range(n_threads):
        start = i * bytes_per_thread
        end = size if i == n_threads - 1 else (i + 1) * bytes_per_thread
        t = threading.Thread(target=_read_range, args=(start, end))
        threads.append(t)
        t.start()

    for t in threads:
        t.join()

    logger.debug(
        "[pid=%d] warm_parallel_chunked: done in %.3fs",
        _pid(),
        time.perf_counter() - t0,
    )


def warm_multiple(paths: list[str], n_threads_per_file: int | None = None):
    """Read multiple files into the OS page cache concurrently.

    Each file is warmed in its own thread via warm_parallel_chunked, so total open
    file descriptors can reach len(paths) * n_threads_per_file.
    """
    if n_threads_per_file is None:
        n_threads_per_file = flags.CATTENSORS_WARM_THREADS

    logger.debug("[pid=%d] warm_multiple: %d files", _pid(), len(paths))
    t0 = time.perf_counter()
    threads = []
    for path in paths:
        t = threading.Thread(
            target=warm_parallel_chunked, args=(path, n_threads_per_file)
        )
        threads.append(t)
        t.start()
    for t in threads:
        t.join()
    logger.debug(
        "[pid=%d] warm_multiple: done in %.3fs", _pid(), time.perf_counter() - t0
    )
