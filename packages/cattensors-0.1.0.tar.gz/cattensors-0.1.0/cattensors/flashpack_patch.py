"""Patch flashpack to pre-warm files into the OS page cache.

flashpack opens its payload via np.memmap with madvise(WILLNEED|SEQUENTIAL),
which is weakly honored on FUSE / network filesystems. We wrap the single
read entry point (read_flashpack_file) with the same parallel-chunked warm
and per-node flock coordination that we use for safetensors.
"""

import logging
import os
from collections.abc import Callable

from cattensors import flags
from cattensors.patch import (
    _start_background_warm,
    _warm_with_flock,
    _warmed_shards,
    _warmed_shards_lock,
)

logger = logging.getLogger(__name__)

_original_read_flashpack_file: Callable | None = None
_patched: bool = False


def warming_read_flashpack_file(path, *args, **kwargs):
    assert _original_read_flashpack_file is not None, (
        "read_flashpack_file has not been patched"
    )

    path = str(path)
    logger.debug(
        "[pid=%d] flashpack patch: warming read_flashpack_file(%s)",
        os.getpid(),
        path,
    )

    parallel_shards = flags.CATTENSORS_PARALLEL_SHARDS

    warm_target = None
    bg_warm_targets = None
    with _warmed_shards_lock:
        if path not in _warmed_shards:
            if parallel_shards:
                hf_parallel = flags.HF_ENABLE_PARALLEL_LOADING
                siblings = _detect_pipeline_siblings(path)

                if siblings and not hf_parallel:
                    _warmed_shards.update(siblings)
                    bg_warm_targets = [s for s in siblings if s != path]
                    warm_target = path

            if warm_target is None:
                warm_target = path
                _warmed_shards.add(path)

    if bg_warm_targets:
        _start_background_warm(bg_warm_targets[:3])

    if warm_target is not None:
        _warm_with_flock(warm_target)

    return _original_read_flashpack_file(path, *args, **kwargs)


def patch():
    """Wrap flashpack.deserialization.read_flashpack_file with pre-warming.

    No-op if flashpack is not installed.
    """
    global _original_read_flashpack_file, _patched

    if _patched:
        return

    try:
        import flashpack.deserialization as deserialization
    except ImportError:
        logger.debug(
            "[pid=%d] flashpack patch: flashpack not installed, skipping",
            os.getpid(),
        )
        return

    _original_read_flashpack_file = deserialization.read_flashpack_file
    deserialization.read_flashpack_file = warming_read_flashpack_file  # ty: ignore[invalid-assignment]

    _patched = True
    logger.debug("[pid=%d] flashpack patch: patched", os.getpid())


def unpatch():
    """Restore flashpack.deserialization.read_flashpack_file."""
    global _original_read_flashpack_file, _patched

    if not _patched:
        return

    import flashpack.deserialization as deserialization

    deserialization.read_flashpack_file = _original_read_flashpack_file  # ty: ignore[invalid-assignment]

    _original_read_flashpack_file = None
    _patched = False
    logger.debug("[pid=%d] flashpack unpatch: restored", os.getpid())


def _detect_pipeline_siblings(path: str) -> list[str] | None:
    """If path is <root>/<sub>/model.flashpack inside a diffusers pipeline,
    return all peer subfolders' model.flashpack paths.

    Diffusers pipelines have multiple subfolders (unet, vae, text_encoder, ...)
    each with its own model.flashpack. When the pipeline iterates them
    sequentially, warming peers in the background hides their network read.
    """
    basename = os.path.basename(path)
    if basename != "model.flashpack":
        return None

    subfolder_dir = os.path.dirname(path)
    pipeline_root = os.path.dirname(subfolder_dir)
    if not pipeline_root or not os.path.isdir(pipeline_root):
        return None

    siblings: list[str] = []
    try:
        for entry in os.listdir(pipeline_root):
            candidate = os.path.join(pipeline_root, entry, "model.flashpack")
            if os.path.isfile(candidate):
                siblings.append(candidate)
    except OSError:
        return None

    if len(siblings) <= 1:
        return None
    return sorted(siblings)
