"""
Telegram bot handlers for music search and download.
"""

import asyncio
import contextlib
import logging
import os
import re
from dataclasses import dataclass, field

from telegram import Message, Update
from telegram.constants import ParseMode
from telegram.error import BadRequest, NetworkError, TimedOut
from telegram.ext import (
    Application,
    CallbackQueryHandler,
    CommandHandler,
    ContextTypes,
    MessageHandler,
    filters,
)

from music_downloader.bot.keyboards import (
    build_approve_keyboard,
    build_auto_mode_keyboard,
    build_direct_search_keyboard,
    build_duplicate_keyboard,
    build_import_confirm_keyboard,
    build_import_skip_keyboard,
    build_import_track_keyboard,
    build_results_keyboard,
    build_retry_keyboard,
    build_retry_next_keyboard,
    build_spotify_keyboard,
)
from music_downloader.config import Config
from music_downloader.metadata.playlist import PlaylistResolver
from music_downloader.metadata.spotify import SpotifyResolver, TrackInfo
from music_downloader.persistence.database import Database
from music_downloader.persistence.history_repo import HistoryRepository
from music_downloader.persistence.import_repo import (
    ImportRepository,
    JobStatus,
    TrackStatus,
)
from music_downloader.processor.file_handler import FileProcessor
from music_downloader.processor.flac_analyzer import (
    FlacVerdict,
    analyze_flac,
    convert_to_ogg,
    create_preview_clip,
)
from music_downloader.search.scorer import ResultScorer
from music_downloader.search.slskd_client import SearchResult, SlskdClient
from music_downloader.tools.embed_artwork import embed_artwork_into_file, fetch_spotify_artwork

logger = logging.getLogger(__name__)

# Telegram bot API file size limit: 50 MB
TELEGRAM_FILE_LIMIT = 50 * 1024 * 1024


def _escape_md(text: str) -> str:
    """Escape Markdown V1 special characters for safe display."""
    for ch in r"\_*[]()~`>#+-=|{}.!":
        text = text.replace(ch, f"\\{ch}")
    return text


async def _safe_edit(msg: Message, text: str, **kwargs) -> bool:
    """Edit a Telegram message, swallowing common failures.

    Returns True on success, False if the edit failed (logged as warning).
    """
    try:
        await msg.edit_text(text, **kwargs)
        return True
    except BadRequest as exc:
        logger.warning(f"Telegram edit failed (BadRequest): {exc}")
        return False
    except TimedOut:
        logger.warning("Telegram edit timed out")
        return False
    except NetworkError as exc:
        logger.warning(f"Telegram edit network error: {exc}")
        return False


async def _safe_query_edit(query, text: str, **kwargs) -> bool:
    """Edit a callback query message, swallowing transient Telegram errors."""
    try:
        await query.edit_message_text(text, **kwargs)
        return True
    except BadRequest as exc:
        logger.warning(f"Telegram query edit failed (BadRequest): {exc}")
        return False
    except TimedOut:
        logger.warning("Telegram query edit timed out")
        return False
    except NetworkError as exc:
        logger.warning(f"Telegram query edit network error: {exc}")
        return False


# Noise keywords that Spotify appends to track titles but Soulseek users never use.
# Named remixes (e.g. "Butch Vig Remix") are intentionally excluded — they
# represent distinct versions the user specifically selected.
_NOISE_PATTERN = (
    r"Mono|Stereo|Remaster(?:ed)?(?:\s+\d{4})?"
    r"|Deluxe(?:\s+Edition)?"
    r"|Ultimate\s+Mix|Single\s+Version|Album\s+Version"
    r"|Radio\s+Edit|Bonus\s+Track|Anniversary(?:\s+Edition)?"
    r"|Super\s+Deluxe|Special\s+Edition"
    r"|\d{4}\s+(?:Mix|Remix|Remaster(?:ed)?|Version)"
    r"|(?:German|French|Spanish|Italian|Japanese|Portuguese|English)\s+Version"
    r"|Remix"
)

# Matches trailing " - Remastered 2009", " - German Version 1989 Remix; ...", etc.
# Once a noise keyword is detected after a dash, everything to EOL is stripped.
_VERSION_SUFFIX_RE = re.compile(
    r"\s*[-–]\s*(?:" + _NOISE_PATTERN + r").*$",
    re.IGNORECASE,
)

# Same patterns inside parentheses: "(Remastered 2009)", "(German Version)", etc.
_VERSION_PAREN_RE = re.compile(
    r"\s*\((?:" + _NOISE_PATTERN + r")[^)]*\)",
    re.IGNORECASE,
)


_QUOTE_CHARS = "'\"‘’“”"


def _clean_search_title(title: str) -> str:
    """Strip Spotify version suffixes that add noise to Soulseek keyword search."""
    title = _VERSION_SUFFIX_RE.sub("", title)
    title = _VERSION_PAREN_RE.sub("", title)
    title = title.strip()
    if len(title) >= 2 and title[0] in _QUOTE_CHARS and title[-1] in _QUOTE_CHARS:
        title = title[1:-1].strip()
    return title


def _build_reduced_queries(title: str, year: str) -> list[str]:
    """Build fallback search queries by dropping one word at a time and appending the year.

    Soulseek users sometimes block entire phrases (e.g. "Purple Rain").
    Removing one keyword at a time while adding the album year often
    bypasses server-side filters while still narrowing results enough
    to find the right track.

    Args:
        title: The (cleaned) song title, e.g. "Purple Rain".
        year: Album release year, e.g. "1984".

    Returns:
        List of fallback query strings.  Empty if the title has fewer
        than 2 words or no year is available.
    """
    if not year:
        return []
    words = title.split()
    if len(words) < 2:
        return []
    queries: list[str] = []
    for i in range(len(words)):
        reduced = " ".join(words[:i] + words[i + 1 :])
        queries.append(f"{reduced} {year}")
    return queries


def _has_non_latin_script(text: str) -> bool:
    """True when *text* contains characters from non-Latin scripts (CJK, Cyrillic, etc.)."""
    return any(c.isalpha() and ord(c) > 0x024F for c in text)


_NOISE_WORDS = frozenset(
    {
        "single",
        "version",
        "long",
        "short",
        "full",
        "edit",
        "mix",
        "remastered",
        "remaster",
        "deluxe",
        "edition",
        "bonus",
        "track",
        "album",
        "mono",
        "stereo",
        "original",
        "extended",
        "feat",
        "featuring",
        "ft",
        "the",
        "an",
        "and",
        "or",
        "of",
        "in",
        "on",
        "at",
        "to",
        "for",
        "with",
        "from",
        "by",
    }
)


def _extract_latin_keywords(title: str) -> list[str]:
    """Extract meaningful Latin keywords from a potentially mixed-script title.

    Strips common noise words so only distinctive keywords remain,
    e.g. ``["KURENAI"]`` from ``"紅 - KURENAI - シングル… - Single Long Version"``.
    """
    words = re.findall(r"[a-zA-Z]{2,}", title)
    return [w for w in words if w.lower() not in _NOISE_WORDS]


@dataclass
class PendingSearch:
    """Holds state for an active search session."""

    query: str
    track: TrackInfo | None = None
    results: list[SearchResult] = field(default_factory=list)
    message_id: int | None = None
    is_fallback: bool = False
    page: int = 0


@dataclass
class PendingDownload:
    """Tracks a single file download waiting for approval."""

    track: TrackInfo
    result: SearchResult
    chat_id: int
    source_path: str | None = None  # Path in /downloads
    status_message_id: int | None = None
    approval_message_id: int | None = None  # Message with approve/reject buttons
    result_index: int = 0  # Position in ranked results list


class MusicBot:
    """Telegram bot for music discovery and download."""

    def __init__(self, config: Config):
        self.config = config
        self.spotify = SpotifyResolver(config.spotify_client_id, config.spotify_client_secret)
        self.slskd = SlskdClient(config.slskd_host, config.slskd_api_key)
        self.scorer = ResultScorer(
            duration_tolerance_secs=config.duration_tolerance_secs,
            exclude_keywords=config.exclude_keywords,
        )
        self.processor = FileProcessor(
            download_dir=config.download_dir,
            output_dir=config.output_dir,
            filename_template=config.filename_template,
        )
        self.auto_mode = config.auto_mode

        # Per-user pending searches (chat_id -> PendingSearch)
        self.pending: dict[int, PendingSearch] = {}

        # Active downloads keyed by short numeric ID
        # download_id -> PendingDownload
        self.downloads: dict[str, PendingDownload] = {}
        self._dl_counter = 0

        # Per-chat Spotify candidates when multiple tracks match (chat_id -> list[TrackInfo])
        self._spotify_candidates: dict[int, list[TrackInfo]] = {}
        # Current page for Spotify browsing (chat_id -> page)
        self._spotify_page: dict[int, int] = {}

        # Awaiting direct search metadata: chat_id -> original query
        self._awaiting_direct_metadata: dict[int, str] = {}

        # Per-chat cancellation: generation counter bumped on each new text message.
        # Running search/download flows check their generation against the current
        # value and abort silently when superseded by a newer request.
        self._chat_generation: dict[int, int] = {}
        # Background tasks (downloads) tracked per chat for cancellation.
        self._active_tasks: dict[int, set[asyncio.Task]] = {}

        # Persistence
        self.db = Database(f"{config.data_dir}/importer.db")
        self.history_repo = HistoryRepository(self.db)
        self.import_repo = ImportRepository(self.db)

        # Playlist resolver
        self.playlist_resolver = PlaylistResolver(self.spotify)

        # Active import tracking (chat_id -> job_id)
        self._active_import: dict[int, int] = {}
        # Separate pending search state for import flows (avoids clobbering self.pending)
        self._import_pending: dict[int, PendingSearch] = {}

    def _is_authorized(self, user_id: int) -> bool:
        """Check if a user is authorized to use the bot (fail-closed)."""
        if not self.config.telegram_allowed_users:
            return False
        return user_id in self.config.telegram_allowed_users

    async def _check_auth(self, update: Update) -> bool:
        """Check authorization and send a message if denied."""
        if not self._is_authorized(update.effective_user.id):
            await update.message.reply_text("You are not authorized to use this bot.")
            return False
        return True

    # =========================================================================
    # CANCELLATION
    # =========================================================================

    def _cancel_chat_operations(self, chat_id: int) -> bool:
        """Cancel all active operations for a chat.

        Bumps the generation counter (signals running search flows to abort)
        and cancels tracked background tasks (downloads).

        Returns True if something was actually cancelled.
        """
        had_work = bool(
            self.pending.get(chat_id) or self._spotify_candidates.get(chat_id) or self._active_tasks.get(chat_id)
        )

        self._chat_generation[chat_id] = self._chat_generation.get(chat_id, 0) + 1

        for task in self._active_tasks.pop(chat_id, set()):
            task.cancel()

        self.pending.pop(chat_id, None)
        self._import_pending.pop(chat_id, None)
        self._spotify_candidates.pop(chat_id, None)
        self._spotify_page.pop(chat_id, None)
        self._awaiting_direct_metadata.pop(chat_id, None)

        stale_ids = [k for k, v in self.downloads.items() if v.chat_id == chat_id]
        for dl_id in stale_ids:
            del self.downloads[dl_id]

        return had_work

    def _is_stale(self, chat_id: int, generation: int) -> bool:
        """True when *generation* has been superseded by a newer request."""
        return self._chat_generation.get(chat_id, 0) != generation

    def _track_task(self, chat_id: int, task: asyncio.Task):
        """Register a background task for cancellation tracking."""
        self._active_tasks.setdefault(chat_id, set()).add(task)

        def _on_done(t: asyncio.Task) -> None:
            tasks = self._active_tasks.get(chat_id)
            if tasks is not None:
                tasks.discard(t)
                if not tasks:
                    del self._active_tasks[chat_id]

        task.add_done_callback(_on_done)

    # =========================================================================
    # COMMAND HANDLERS
    # =========================================================================

    async def cmd_start(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /start command."""
        if not await self._check_auth(update):
            return

        await update.message.reply_text(
            "Send me a song name (e.g., `Nancy Sinatra Bang Bang`) "
            "and I'll find and download it in FLAC.\n\n"
            "Commands:\n"
            "/auto — Toggle auto-download mode\n"
            "/status — Show active downloads\n"
            "/history — Recent downloads\n"
            "/help — Show this message",
            parse_mode=ParseMode.MARKDOWN,
        )

    async def cmd_help(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /help command."""
        if not await self._check_auth(update):
            return
        await self.cmd_start(update, context)

    async def cmd_auto(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /auto command — toggle auto-download mode."""
        if not await self._check_auth(update):
            return

        mode_str = "ON" if self.auto_mode else "OFF"
        await update.message.reply_text(
            f"Auto-download mode is currently: *{mode_str}*\n\n"
            "When ON, the best FLAC match is downloaded automatically without asking you to pick.",
            parse_mode=ParseMode.MARKDOWN,
            reply_markup=build_auto_mode_keyboard(self.auto_mode),
        )

    async def cmd_status(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /status command — show active searches and downloads."""
        if not await self._check_auth(update):
            return

        lines = []

        if self.pending:
            lines.append("*Active searches:*\n")
            for _chat_id, pending in self.pending.items():
                lines.append(f"• {pending.track.artist} - {pending.track.title}")

        if self.downloads:
            lines.append("\n*Active downloads:*\n")
            for _dl_id, dl in self.downloads.items():
                lines.append(f"• {dl.track.artist} - {dl.track.title} ({dl.result.basename})")

        if not lines:
            await update.message.reply_text("No active searches or downloads.")
            return

        await update.message.reply_text("\n".join(lines), parse_mode=ParseMode.MARKDOWN)

    async def cmd_history(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /history command — show recent downloads."""
        if not await self._check_auth(update):
            return

        records = await asyncio.to_thread(self.history_repo.get_recent, 10)

        if not records:
            await update.message.reply_text("No downloads yet.")
            return

        lines = ["*Recent downloads:*\n"]
        for entry in records:
            icon = {"success": "✅", "rejected": "🚫"}.get(entry.status, "❌")
            lines.append(f"{icon} `{entry.filename}`")

        await update.message.reply_text("\n".join(lines), parse_mode=ParseMode.MARKDOWN)

    # =========================================================================
    # TEXT MESSAGE HANDLER (song search)
    # =========================================================================

    async def handle_text(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle free-text messages — treat as song search queries."""
        if not await self._check_auth(update):
            return

        query = update.message.text.strip()
        if not query:
            return

        chat_id = update.effective_chat.id

        # Check if we're awaiting "Artist - Title" for a direct Soulseek search
        if chat_id in self._awaiting_direct_metadata:
            search_query = self._awaiting_direct_metadata.pop(chat_id)
            generation = self._chat_generation.get(chat_id, 0)

            if " - " in query:
                artist, title = query.split(" - ", 1)
            else:
                artist, title = query, search_query

            synthetic_track = TrackInfo(
                artist=artist.strip(),
                title=title.strip(),
                album="",
                duration_ms=0,
                spotify_url="",
                year="",
            )

            searching_msg = await context.bot.send_message(
                chat_id=chat_id,
                text=f"\U0001f50d Searching slskd for: `{search_query}`\n"
                f"Saving as: *{synthetic_track.artist} - {synthetic_track.title}*",
                parse_mode=ParseMode.MARKDOWN,
            )

            await self._do_direct_slskd_search(
                context, chat_id, search_query, searching_msg, generation, display_track=synthetic_track
            )
            return

        # Cancel any in-flight search / download for this chat immediately.
        self._cancel_chat_operations(chat_id)
        generation = self._chat_generation[chat_id]

        # Step 0: Check for similar files already in the library
        similar = self.processor.find_similar(query)
        if similar:
            existing_list = "\n".join(f"• `{f}`" for f in similar[:5])
            await update.message.reply_text(
                f"⚠️ *Similar files already in library:*\n\n{existing_list}\n\nContinue searching anyway?",
                parse_mode=ParseMode.MARKDOWN,
                reply_markup=build_duplicate_keyboard(),
            )
            self.pending[chat_id] = PendingSearch(query=query, track=None)
            return

        await self._do_search(update, context, query, generation)

    async def _do_search(self, update: Update, context: ContextTypes.DEFAULT_TYPE, query: str, generation: int):
        """Resolve metadata via Spotify, then proceed to slskd search."""
        chat_id = update.effective_chat.id

        searching_msg = await context.bot.send_message(
            chat_id=chat_id,
            text=f"🔍 Looking up: `{query}`",
            parse_mode=ParseMode.MARKDOWN,
        )

        try:
            tracks = self.spotify.search_multiple(query, limit=50)
            if self._is_stale(chat_id, generation):
                return

            if not tracks:
                await _safe_edit(
                    searching_msg,
                    f"Could not find `{query}` on Spotify.\nYou can search Soulseek directly instead.",
                    parse_mode=ParseMode.MARKDOWN,
                    reply_markup=build_direct_search_keyboard(),
                )
                # Store query for direct search callback
                self.pending[chat_id] = PendingSearch(query=query, track=None)
                return

            query_lower = query.lower()
            query_words = set(query_lower.split())
            query_artist = ""
            if " - " in query:
                query_artist = query.split(" - ", 1)[0].strip().lower()

            seen = set()
            unique_tracks = []
            artist_match_tracks = []
            other_tracks = []
            for t in tracks:
                key = (t.artist.lower(), t.title.lower(), t.album.lower())
                if key in seen:
                    continue
                seen.add(key)
                artist_lower = t.artist.lower()
                if query_artist and query_artist not in artist_lower:
                    continue
                artist_words = set(artist_lower.split())
                if len(artist_words) >= 2 and artist_lower in query_lower:
                    artist_match_tracks.append(t)
                elif artist_words.issubset(query_words):
                    artist_match_tracks.append(t)
                else:
                    other_tracks.append(t)

            artist_match_tracks.sort(key=lambda t: len(t.artist), reverse=True)
            unique_tracks = artist_match_tracks + other_tracks

            if not unique_tracks:
                seen = set()
                for t in tracks:
                    key = (t.artist.lower(), t.title.lower(), t.album.lower())
                    if key not in seen:
                        seen.add(key)
                        unique_tracks.append(t)

            if len(unique_tracks) == 1:
                await self._do_slskd_search(context, chat_id, unique_tracks[0], searching_msg, generation)
                return

            self._spotify_candidates[chat_id] = unique_tracks
            self._spotify_page[chat_id] = 0
            self.pending[chat_id] = PendingSearch(query=query, track=None)
            await _safe_edit(
                searching_msg,
                self._format_spotify_results(unique_tracks, page=0),
                parse_mode=ParseMode.MARKDOWN,
                disable_web_page_preview=True,
                reply_markup=build_spotify_keyboard(unique_tracks, page=0),
            )

        except Exception:
            logger.exception(f"Unexpected error in _do_search for: {query}")
            self._spotify_candidates.pop(chat_id, None)
            self._spotify_page.pop(chat_id, None)
            await _safe_edit(searching_msg, "Something went wrong. Please try again.")

    async def _do_slskd_search(self, context, chat_id: int, track: TrackInfo, searching_msg, generation: int):
        """Search slskd for a resolved Spotify track."""
        try:
            await _safe_edit(
                searching_msg,
                f"🎵 *{track.artist} - {track.title}*\n"
                f"Album: {track.album} ({track.year})\n"
                f"Duration: {track.duration_display}\n\n"
                f"Searching slskd...",
                parse_mode=ParseMode.MARKDOWN,
            )

            clean_title = _clean_search_title(track.title)
            search_query = f"{track.artist} {clean_title}"
            raw_responses = await self.slskd.search(search_query, timeout_secs=self.config.search_timeout_secs)
            if self._is_stale(chat_id, generation):
                return

            ranked, is_fallback = self._rank_responses(raw_responses, track)

            # Fallback 2: title-only search
            if not ranked:
                if self._is_stale(chat_id, generation):
                    return
                logger.info(
                    "No results for '%s', retrying with title-only: '%s'",
                    search_query,
                    clean_title,
                )
                await _safe_edit(
                    searching_msg,
                    f"🎵 *{track.artist} - {track.title}*\n\n"
                    f"No results with full query — retrying with song title only…",
                    parse_mode=ParseMode.MARKDOWN,
                )
                raw_responses = await self.slskd.search(clean_title, timeout_secs=self.config.search_timeout_secs)
                if self._is_stale(chat_id, generation):
                    return

                ranked, is_fallback = self._rank_responses(raw_responses, track)

            # Fallback 3: keyword reduction + album year
            if not ranked and not _has_non_latin_script(clean_title):
                reduced_queries = _build_reduced_queries(clean_title, track.year)
                if reduced_queries:
                    if self._is_stale(chat_id, generation):
                        return
                    logger.info(
                        "No results for title-only '%s', trying keyword reduction + year",
                        clean_title,
                    )
                    await _safe_edit(
                        searching_msg,
                        f"🎵 *{track.artist} - {track.title}*\n\n"
                        f"Still no results — trying keyword variations with year…",
                        parse_mode=ParseMode.MARKDOWN,
                    )
                    for fallback_query in reduced_queries:
                        if self._is_stale(chat_id, generation):
                            return
                        raw_responses = await self.slskd.search(
                            fallback_query, timeout_secs=self.config.search_timeout_secs
                        )
                        ranked, is_fallback = self._rank_responses(raw_responses, track)
                        if ranked:
                            logger.info("Keyword-reduction fallback hit: '%s'", fallback_query)
                            break

            # Fallback 4: artist + Latin keywords
            if not ranked:
                if self._is_stale(chat_id, generation):
                    return
                latin_kw = _extract_latin_keywords(clean_title)
                if latin_kw:
                    fb4_query = f"{track.artist} {' '.join(latin_kw)}"
                else:
                    fb4_query = track.artist
                logger.info(
                    "Trying artist + Latin keywords fallback: '%s'",
                    fb4_query,
                )
                await _safe_edit(
                    searching_msg,
                    f"🎵 *{track.artist} - {track.title}*\n\nStill no results — trying artist + keyword search…",
                    parse_mode=ParseMode.MARKDOWN,
                )
                raw_responses = await self.slskd.search(
                    fb4_query,
                    timeout_secs=self.config.search_timeout_secs,
                    response_limit=150,
                )
                if self._is_stale(chat_id, generation):
                    return

                ranked, is_fallback = self._rank_responses(raw_responses, track, max_duration_diff=120)
                if ranked:
                    logger.info("Artist-keyword fallback hit: '%s'", fb4_query)

            if self._is_stale(chat_id, generation):
                return

            if not ranked:
                await _safe_edit(
                    searching_msg,
                    f"🎵 *{track.artist} - {track.title}* ({track.duration_display})\n\n"
                    f"No results found on Soulseek matching this track.\n"
                    f"Try a different search query.",
                    parse_mode=ParseMode.MARKDOWN,
                )
                return

            self.pending[chat_id] = PendingSearch(
                query=f"{track.artist} {track.title}",
                track=track,
                results=ranked,
                message_id=searching_msg.message_id,
                is_fallback=is_fallback,
            )

            results_text = self._format_results(track, ranked, is_fallback, page=0, page_size=self.config.max_results)
            await _safe_edit(
                searching_msg,
                results_text,
                parse_mode=ParseMode.MARKDOWN,
                reply_markup=build_results_keyboard(ranked, page=0, page_size=self.config.max_results),
            )

        except Exception:
            logger.exception(f"Unexpected error in _do_slskd_search for: {track.artist} - {track.title}")
            self.pending.pop(chat_id, None)
            await _safe_edit(
                searching_msg,
                "Something went wrong during the search. Please try again.",
            )

    # =========================================================================
    # CALLBACK QUERY HANDLER (button presses)
    # =========================================================================

    async def handle_callback(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle inline keyboard button presses."""
        query = update.callback_query
        with contextlib.suppress(BadRequest):
            await query.answer()

        if not self._is_authorized(query.from_user.id):
            return

        chat_id = update.effective_chat.id
        data = query.data

        # Dispatch callbacks by prefix
        prefix = data.split(":", 1)[0]
        handler = {
            "direct": self._handle_direct_search,
            "ic": self._handle_import_callback,
            "ix": self._handle_import_callback,
            "ia": self._handle_import_callback,
            "ir": self._handle_import_callback,
            "is": self._handle_import_callback,
            "retry": self._handle_retry,
            "next": self._handle_next_result,
            "dup": self._handle_duplicate_response,
            "sp_page": self._handle_spotify_page,
            "sp": self._handle_spotify_selection,
            "dl_page": self._handle_results_page,
            "dl": self._handle_download_selection,
            "approve": self._handle_approval,
            "reject": self._handle_approval,
        }.get(prefix)

        if handler:
            await handler(update, context, chat_id, data)
            return

        # Auto-mode toggle (inline, no separate handler needed)
        if data.startswith("auto:"):
            self.auto_mode = data == "auto:on"
            mode_str = "ON" if self.auto_mode else "OFF"
            await query.edit_message_text(
                f"Auto-download mode: *{mode_str}*",
                parse_mode=ParseMode.MARKDOWN,
            )
            return

    async def _handle_duplicate_response(self, update, context, chat_id: int, data: str):
        """Handle Continue/Cancel response to duplicate detection."""
        query = update.callback_query
        action = data.split(":", 1)[1]

        pending = self.pending.pop(chat_id, None)

        if action == "cancel" or not pending:
            await query.edit_message_text("Cancelled.")
            return

        await query.edit_message_text(
            f"Continuing with search: `{pending.query}`",
            parse_mode=ParseMode.MARKDOWN,
        )
        generation = self._chat_generation.get(chat_id, 0)
        await self._do_search(update, context, pending.query, generation)

    async def _handle_spotify_page(self, update, context, chat_id: int, data: str):
        """Handle Spotify page navigation (◀️ / ▶️)."""
        query = update.callback_query
        candidates = self._spotify_candidates.get(chat_id)
        if not candidates:
            await query.edit_message_text("Search expired. Send a new query.")
            return

        try:
            page = int(data.split(":", 1)[1])
        except ValueError:
            return

        self._spotify_page[chat_id] = page
        await query.edit_message_text(
            self._format_spotify_results(candidates, page=page),
            parse_mode=ParseMode.MARKDOWN,
            disable_web_page_preview=True,
            reply_markup=build_spotify_keyboard(candidates, page=page),
        )

    async def _handle_spotify_selection(self, update, context, chat_id: int, data: str):
        """Handle Spotify track selection from multiple results."""
        query = update.callback_query
        action = data.split(":", 1)[1]

        candidates = self._spotify_candidates.pop(chat_id, None)
        self._spotify_page.pop(chat_id, None)

        if action == "cancel" or not candidates:
            await query.edit_message_text("Cancelled.")
            return

        try:
            index = int(action)
        except ValueError:
            return

        if index >= len(candidates):
            return

        track = candidates[index]
        await query.edit_message_text(
            f"Selected: *{track.artist} - {track.title}* ({track.duration_display})",
            parse_mode=ParseMode.MARKDOWN,
        )

        searching_msg = await context.bot.send_message(
            chat_id=chat_id,
            text="🔍 Searching slskd for FLAC...",
            parse_mode=ParseMode.MARKDOWN,
        )
        generation = self._chat_generation.get(chat_id, 0)
        await self._do_slskd_search(context, chat_id, track, searching_msg, generation)

    async def _handle_results_page(self, update, context, chat_id: int, data: str):
        """Handle slskd results page navigation (◀️ / ▶️)."""
        query = update.callback_query
        pending = self.pending.get(chat_id)
        if not pending or not pending.track:
            await query.edit_message_text("Search expired. Send a new query.")
            return

        try:
            page = int(data.split(":", 1)[1])
        except ValueError:
            return

        pending.page = page
        results_text = self._format_results(
            pending.track,
            pending.results,
            pending.is_fallback,
            page=page,
            page_size=self.config.max_results,
        )
        await query.edit_message_text(
            results_text,
            parse_mode=ParseMode.MARKDOWN,
            reply_markup=build_results_keyboard(pending.results, page=page, page_size=self.config.max_results),
        )

    async def _handle_download_selection(self, update, context, chat_id: int, data: str):
        """Handle when user picks a file to download from results."""
        query = update.callback_query
        pending = self.pending.get(chat_id)
        if not pending:
            await query.edit_message_text("Search expired. Send a new query.")
            return

        action = data.split(":", 1)[1]

        if action == "cancel":
            del self.pending[chat_id]
            await query.edit_message_text("Cancelled.")
            return

        if action == "auto":
            index = 0
        else:
            try:
                index = int(action)
            except ValueError:
                return

        if index >= len(pending.results):
            return

        result = pending.results[index]
        track = pending.track

        status_msg = await context.bot.send_message(
            chat_id=chat_id,
            text=(
                f"⬇️ *Downloading #{index + 1}...*\n"
                f"{track.artist} - {track.title}\n"
                f"From: `{result.username}`\n"
                f"File: `{result.basename}`"
            ),
            parse_mode=ParseMode.MARKDOWN,
        )

        task = context.application.create_task(
            self._do_download(context, chat_id, track, result, status_msg, index),
            update=update,
        )
        self._track_task(chat_id, task)

    def _rank_responses(
        self, raw_responses, track: TrackInfo, max_duration_diff: int | None = None
    ) -> tuple[list[SearchResult], bool]:
        """Parse raw slskd responses and rank: try FLAC first, fall back to all audio."""
        score_kwargs = {"max_duration_diff": max_duration_diff} if max_duration_diff else {}
        flac_results = self.slskd.parse_results(raw_responses, flac_only=True)
        ranked = self.scorer.score_results(flac_results, track, **score_kwargs)
        if ranked:
            return ranked, False
        all_audio = self.slskd.parse_results(raw_responses, flac_only=False)
        ranked = self.scorer.score_results(all_audio, track, **score_kwargs)
        return ranked, bool(ranked)

    # =========================================================================
    # DOWNLOAD + PREVIEW + APPROVAL
    # =========================================================================

    def _next_dl_id(self) -> str:
        """Generate a short unique download ID."""
        self._dl_counter += 1
        return str(self._dl_counter)

    def _has_next_result(self, chat_id: int, current_index: int) -> bool:
        pending = self.pending.get(chat_id)
        return pending is not None and current_index + 1 < len(pending.results)

    async def _do_download(
        self, context, chat_id: int, track: TrackInfo, result: SearchResult, status_msg, result_index: int = 0
    ):
        """Download a file, send it to Telegram for preview, and ask for approval."""
        dl_id = self._next_dl_id()
        label = f"#{result_index + 1}"

        try:
            success = self.slskd.enqueue_download(result)
            if not success:
                pending_dl = PendingDownload(
                    track=track,
                    result=result,
                    chat_id=chat_id,
                    status_message_id=status_msg.message_id,
                    result_index=result_index,
                )
                self.downloads[dl_id] = pending_dl
                has_next = self._has_next_result(chat_id, result_index)
                await status_msg.edit_text(
                    f"❌ Failed to enqueue download from `{result.username}`.\nThe user might be offline.",
                    parse_mode=ParseMode.MARKDOWN,
                    reply_markup=build_retry_next_keyboard(dl_id) if has_next else build_retry_keyboard(dl_id),
                )
                return

            status = await self.slskd.wait_for_download(
                username=result.username,
                filename=result.filename,
                timeout_secs=self.config.download_timeout_secs,
            )

            if status is None or status.is_failed:
                state = status.state if status else "Timeout"
                pending_dl = PendingDownload(
                    track=track,
                    result=result,
                    chat_id=chat_id,
                    status_message_id=status_msg.message_id,
                    result_index=result_index,
                )
                self.downloads[dl_id] = pending_dl
                has_next = self._has_next_result(chat_id, result_index)
                await status_msg.edit_text(
                    f"❌ Download failed: {state}\nFile: `{result.basename}`",
                    parse_mode=ParseMode.MARKDOWN,
                    reply_markup=build_retry_next_keyboard(dl_id) if has_next else build_retry_keyboard(dl_id),
                )
                await self._add_history(track, result, "failed")
                return

            source_path = self.processor.find_downloaded_file(result.username, result.filename)
            if not source_path:
                await status_msg.edit_text(
                    "❌ Downloaded file not found on disk.\nCheck DOWNLOAD_DIR configuration.",
                )
                await self._add_history(track, result, "file_not_found")
                return

            flac_verdict = await self._analyze_flac(source_path) if result.extension == "flac" else None

            pending_dl = PendingDownload(
                track=track,
                result=result,
                chat_id=chat_id,
                source_path=source_path,
                status_message_id=status_msg.message_id,
                result_index=result_index,
            )
            self.downloads[dl_id] = pending_dl

            quality_line = f"Quality: {result.quality_display} | {result.duration_display}"
            if flac_verdict:
                quality_line += f"\n{flac_verdict.display}"

            await status_msg.edit_text(
                f"✅ *{label} Downloaded!* Sending preview...\n`{result.basename}`\n{quality_line}",
                parse_mode=ParseMode.MARKDOWN,
            )

            file_size = os.path.getsize(source_path) if os.path.isfile(source_path) else 0
            caption = f"{label} {quality_line}\nSave to library?"

            if file_size > TELEGRAM_FILE_LIMIT:
                await self._send_large_file(
                    context,
                    chat_id,
                    track,
                    result,
                    source_path,
                    file_size,
                    quality_line,
                    label,
                    dl_id,
                )
            else:
                target_name = self.processor.build_filename(track.artist, track.title, result.extension)
                try:
                    with open(source_path, "rb") as f:
                        sent = await context.bot.send_audio(
                            chat_id=chat_id,
                            audio=f,
                            filename=target_name,
                            title=track.title,
                            performer=track.artist,
                            duration=track.duration_secs,
                            caption=caption,
                            reply_markup=build_approve_keyboard(dl_id),
                        )
                except BadRequest:
                    logger.info("send_audio failed, falling back to send_document for %s", result.basename)
                    with open(source_path, "rb") as f:
                        sent = await context.bot.send_document(
                            chat_id=chat_id,
                            document=f,
                            filename=target_name,
                            caption=caption,
                            reply_markup=build_approve_keyboard(dl_id),
                        )
                if dl_id in self.downloads:
                    self.downloads[dl_id].approval_message_id = sent.message_id

        except asyncio.CancelledError:
            logger.info("Download cancelled for %s", result.basename)
            self.downloads.pop(dl_id, None)
            raise
        except Exception:
            logger.exception(f"Download failed for {result.basename}")
            await status_msg.edit_text(
                f"❌ Error downloading `{result.basename}`. Check logs.",
                parse_mode=ParseMode.MARKDOWN,
            )

    async def _send_large_file(
        self,
        context,
        chat_id: int,
        track: TrackInfo,
        result: SearchResult,
        source_path: str,
        file_size: int,
        quality_line: str,
        label: str,
        dl_id: str,
    ):
        """Convert a >50 MB file to OGG and send.  Trim only as last resort.

        Strategy:
        1. Convert full song to OGG Opus (~128 kbps).
        2. If OGG ≤ 50 MB → send the full song.
        3. If OGG > 50 MB → trim to ~1 min and send that.
        """
        # Step 1: full OGG conversion
        ogg_path = await self._convert_to_ogg(source_path)

        if ogg_path:
            ogg_size = os.path.getsize(ogg_path)
            if ogg_size <= TELEGRAM_FILE_LIMIT:
                try:
                    target_name = self.processor.build_filename(track.artist, track.title, "ogg")
                    caption = (
                        f"🎧 {label} Converted to OGG "
                        f"(original: {file_size / (1024 * 1024):.0f}MB {result.extension.upper()})\n"
                        f"{quality_line}\nSave to library?"
                    )
                    with open(ogg_path, "rb") as f:
                        sent = await context.bot.send_audio(
                            chat_id=chat_id,
                            audio=f,
                            filename=target_name,
                            title=track.title,
                            performer=track.artist,
                            duration=track.duration_secs,
                            caption=caption,
                            reply_markup=build_approve_keyboard(dl_id),
                        )
                    if dl_id in self.downloads:
                        self.downloads[dl_id].approval_message_id = sent.message_id
                    return
                finally:
                    with contextlib.suppress(OSError):
                        os.unlink(ogg_path)
            else:
                # Full OGG still too large — clean up, will trim below.
                with contextlib.suppress(OSError):
                    os.unlink(ogg_path)

        # Step 2: trim to ~1 min
        preview_path = await self._create_preview(source_path, duration_secs=60.0)
        if not preview_path:
            logger.error("Preview creation failed for %s, cannot send to Telegram", source_path)
            sent = await context.bot.send_message(
                chat_id=chat_id,
                text=(
                    f"❌ {label} Could not create preview for "
                    f"{file_size / (1024 * 1024):.0f}MB file.\n"
                    f"{quality_line}\n\nSave to library anyway?"
                ),
                reply_markup=build_approve_keyboard(dl_id),
            )
            if dl_id in self.downloads:
                self.downloads[dl_id].approval_message_id = sent.message_id
            return

        try:
            preview_ext = os.path.splitext(preview_path)[1].lstrip(".")
            target_name = self.processor.build_filename(track.artist, f"{track.title} (1min preview)", preview_ext)
            preview_caption = (
                f"🎧 {label} ~1 min preview "
                f"(full file: {file_size / (1024 * 1024):.0f}MB)\n"
                f"{quality_line}\n"
                f"Save to library?"
            )
            with open(preview_path, "rb") as f:
                sent = await context.bot.send_audio(
                    chat_id=chat_id,
                    audio=f,
                    filename=target_name,
                    title=f"{track.title} (1min preview)",
                    performer=track.artist,
                    duration=60,
                    caption=preview_caption,
                    reply_markup=build_approve_keyboard(dl_id),
                )
            if dl_id in self.downloads:
                self.downloads[dl_id].approval_message_id = sent.message_id
        finally:
            with contextlib.suppress(OSError):
                os.unlink(preview_path)

    async def _handle_approval(self, update, context, chat_id: int, data: str):
        """Handle approve/reject of a downloaded file."""
        query = update.callback_query
        action, dl_id = data.split(":", 1)

        pending_dl = self.downloads.pop(dl_id, None)
        if not pending_dl:
            await self._edit_approval_message(query, "⏹ Cancelled")
            return

        if pending_dl.chat_id != chat_id:
            self.downloads[dl_id] = pending_dl
            return

        track = pending_dl.track
        result = pending_dl.result

        if action == "approve":
            if pending_dl.source_path:
                target_path = self.processor.process_file(pending_dl.source_path, track.artist, track.title)
                if target_path:
                    self.processor.cleanup_download(pending_dl.source_path)
                    await self._embed_spotify_artwork(target_path, track)
                    target_name = os.path.basename(target_path)
                    await self._edit_approval_message(query, f"✅ Saved: `{target_name}`")
                    await self._add_history(track, result, "success")
                    logger.info(f"Approved and saved: {target_name}")

                    # Dismiss every other pending download for this chat.
                    await self._dismiss_other_downloads(context, chat_id)
                else:
                    await self._edit_approval_message(query, "❌ Failed to save file. Check logs.")
                    await self._add_history(track, result, "process_failed")
            else:
                await self._edit_approval_message(query, "❌ Source file not found.")
                await self._add_history(track, result, "file_not_found")

        elif action == "reject":
            if pending_dl.source_path and os.path.isfile(pending_dl.source_path):
                os.remove(pending_dl.source_path)
                logger.info(f"Deleted rejected file: {pending_dl.source_path}")
            await self._edit_approval_message(query, f"🚫 Rejected: {track.artist} - {track.title}")
            await self._add_history(track, result, "rejected")
            logger.info(f"Rejected: {track.artist} - {track.title} ({result.basename})")

    async def _dismiss_other_downloads(self, context, chat_id: int):
        """Cancel all remaining pending downloads for a chat after one is approved."""
        # Remove the results keyboard so no more downloads can be started.
        pending = self.pending.pop(chat_id, None)
        if pending and pending.message_id:
            with contextlib.suppress(Exception):
                await context.bot.edit_message_reply_markup(
                    chat_id=chat_id,
                    message_id=pending.message_id,
                )

        # Dismiss other pending download approval messages and clean up files.
        stale = [(k, v) for k, v in self.downloads.items() if v.chat_id == chat_id]
        for dl_id, dl in stale:
            del self.downloads[dl_id]
            if dl.source_path and os.path.isfile(dl.source_path):
                os.remove(dl.source_path)
            if dl.approval_message_id:
                try:
                    await context.bot.edit_message_caption(
                        chat_id=chat_id,
                        message_id=dl.approval_message_id,
                        caption="⏹ Cancelled",
                    )
                except Exception:
                    with contextlib.suppress(Exception):
                        await context.bot.edit_message_text(
                            chat_id=chat_id,
                            message_id=dl.approval_message_id,
                            text="⏹ Cancelled",
                        )

        for task in self._active_tasks.pop(chat_id, set()):
            task.cancel()

    @staticmethod
    async def _edit_approval_message(query, text: str):
        """Edit the approval message — works for both audio captions and text messages."""
        try:
            await query.edit_message_caption(caption=text, parse_mode=ParseMode.MARKDOWN)
        except Exception:
            with contextlib.suppress(Exception):
                await query.edit_message_text(text=text, parse_mode=ParseMode.MARKDOWN)

    # =========================================================================
    # DIRECT SEARCH (skip Spotify)
    # =========================================================================

    async def _handle_direct_search(self, update: Update, context: ContextTypes.DEFAULT_TYPE, chat_id: int, data: str):
        """Handle 'Search Soulseek directly' button — asks for Artist - Title, then searches slskd."""
        query = update.callback_query

        pending = self.pending.get(chat_id)
        if not pending:
            await query.edit_message_text("Search expired. Send a new query.")
            return

        search_query = pending.query
        self._awaiting_direct_metadata[chat_id] = search_query

        await query.edit_message_text(
            f"\U0001f3b5 How should this track be saved?\n\n"
            f"Send the name as: `Artist - Title`\n"
            f"(This will be used for the filename and tags)",
            parse_mode=ParseMode.MARKDOWN,
        )

    async def _do_direct_slskd_search(
        self, context, chat_id: int, query: str, searching_msg, generation: int, display_track: TrackInfo | None = None
    ):
        """Search slskd without Spotify metadata. Duration scoring gives flat 15 points."""
        try:
            raw_responses = await self.slskd.search(query, timeout_secs=self.config.search_timeout_secs)
            if self._is_stale(chat_id, generation):
                return

            # Use display_track from Spotify candidates if available, otherwise parse query
            if display_track:
                synthetic_track = TrackInfo(
                    artist=display_track.artist,
                    title=display_track.title,
                    album=display_track.album,
                    duration_ms=0,
                    spotify_url="",
                    year=display_track.year,
                )
            else:
                artist, title = self._parse_query_artist_title(query)
                synthetic_track = TrackInfo(
                    artist=artist,
                    title=title,
                    album="",
                    duration_ms=0,
                    spotify_url="",
                    year="",
                )

            ranked, is_fallback = self._rank_responses(raw_responses, synthetic_track)

            if self._is_stale(chat_id, generation):
                return

            if not ranked:
                await _safe_edit(
                    searching_msg,
                    f"\U0001f50e Direct search: `{query}`\n\nNo results found on Soulseek.",
                    parse_mode=ParseMode.MARKDOWN,
                )
                return

            self.pending[chat_id] = PendingSearch(
                query=query,
                track=synthetic_track,
                results=ranked,
                message_id=searching_msg.message_id,
                is_fallback=is_fallback,
            )

            results_text = self._format_results(
                synthetic_track, ranked, is_fallback, page=0, page_size=self.config.max_results
            )
            await _safe_edit(
                searching_msg,
                results_text,
                parse_mode=ParseMode.MARKDOWN,
                reply_markup=build_results_keyboard(ranked, page=0, page_size=self.config.max_results),
            )

        except Exception:
            logger.exception(f"Direct search failed for: {query}")
            await _safe_edit(searching_msg, "Something went wrong. Please try again.")

    # =========================================================================
    # IMPORT COMMANDS
    # =========================================================================

    async def cmd_import(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /import <spotify_url> — import playlist or album."""
        if not await self._check_auth(update):
            return

        chat_id = update.effective_chat.id
        args = update.message.text.split(maxsplit=1)

        if len(args) < 2:
            await update.message.reply_text(
                "Usage: `/import <spotify_playlist_or_album_url>`",
                parse_mode=ParseMode.MARKDOWN,
            )
            return

        url = args[1].strip()

        if not PlaylistResolver.is_spotify_url(url):
            await update.message.reply_text(
                "Please provide a valid Spotify playlist or album URL.",
            )
            return

        # Check for existing active import
        active = await asyncio.to_thread(self.import_repo.get_active_job, chat_id)
        if active:
            await update.message.reply_text(
                f"You already have an active import: *{_escape_md(active.name)}* ({active.completed_tracks}/{active.total_tracks})\n"
                f"Use /cancel to stop it first.",
                parse_mode=ParseMode.MARKDOWN,
            )
            return

        status_msg = await update.message.reply_text("\U0001f50d Resolving playlist...")

        playlist_info = await asyncio.to_thread(self.playlist_resolver.resolve, url)
        if not playlist_info:
            await _safe_edit(status_msg, "Failed to resolve playlist. Check the URL and try again.")
            return

        # Create job in DB
        job_id = await asyncio.to_thread(
            self.import_repo.create_job,
            chat_id=chat_id,
            spotify_url=url,
            name=playlist_info.name,
            total_tracks=playlist_info.total_tracks,
        )

        # Add tracks to DB
        track_dicts = [
            {
                "position": i + 1,
                "artist": t.artist,
                "title": t.title,
                "album": t.album,
                "duration_ms": t.duration_ms,
                "spotify_url": t.spotify_url,
                "year": t.year,
            }
            for i, t in enumerate(playlist_info.tracks)
        ]
        await asyncio.to_thread(self.import_repo.add_tracks, job_id, track_dicts)

        # Show summary
        type_label = "album" if playlist_info.is_album else "playlist"
        await _safe_edit(
            status_msg,
            f"\U0001f4cb Found {type_label}: *{_escape_md(playlist_info.name)}*\n"
            f"By: {_escape_md(playlist_info.owner)}\n"
            f"Tracks: {playlist_info.total_tracks}\n\n"
            f"Import all tracks one by one?",
            parse_mode=ParseMode.MARKDOWN,
            reply_markup=build_import_confirm_keyboard(job_id),
        )

    async def cmd_cancel(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /cancel — cancel active import or search."""
        if not await self._check_auth(update):
            return

        chat_id = update.effective_chat.id

        # Cancel import if active
        job_id = self._active_import.pop(chat_id, None)
        if job_id:
            await asyncio.to_thread(self.import_repo.update_job_status, job_id, JobStatus.cancelled)
            self._cancel_chat_operations(chat_id)
            await update.message.reply_text("❌ Import cancelled.")
            return

        # Otherwise cancel regular operations
        had_work = self._cancel_chat_operations(chat_id)
        if had_work:
            await update.message.reply_text("❌ Cancelled.")
        else:
            await update.message.reply_text("Nothing to cancel.")

    async def _handle_import_callback(
        self, update: Update, context: ContextTypes.DEFAULT_TYPE, chat_id: int, data: str
    ):
        """Route import-related callbacks (ic/ix/ia/ir/is prefixes)."""
        query = update.callback_query
        prefix, _, payload = data.partition(":")
        parts = payload.split(":")

        try:
            job_id = int(parts[0])
        except (IndexError, ValueError):
            return

        # IDOR: verify job belongs to this chat
        job = await asyncio.to_thread(self.import_repo.get_job_for_chat, job_id, chat_id)
        if not job:
            await _safe_query_edit(query, "⏹ Import not found.")
            return

        if prefix == "ic":
            await _safe_query_edit(query, "✅ Import started! Processing tracks one by one...")
            await asyncio.to_thread(self.import_repo.update_job_status, job_id, JobStatus.active)
            self._active_import[chat_id] = job_id
            generation = self._chat_generation.get(chat_id, 0)
            task = context.application.create_task(
                self._process_next_import_track(context, chat_id, job_id, generation),
                update=update,
            )
            self._track_task(chat_id, task)

        elif prefix == "ix":
            await asyncio.to_thread(self.import_repo.update_job_status, job_id, JobStatus.cancelled)
            self._active_import.pop(chat_id, None)
            await _safe_query_edit(query, "❌ Import cancelled.")

        elif prefix == "ia":
            track_id = int(parts[1])
            dl_id = parts[2]
            await self._handle_import_approve(update, context, chat_id, job_id, track_id, dl_id)

        elif prefix == "ir":
            track_id = int(parts[1])
            await asyncio.to_thread(
                self.import_repo.complete_track, job_id, track_id, TrackStatus.failed, "Rejected by user"
            )
            await _safe_query_edit(query, "\U0001f6ab Track rejected.")
            generation = self._chat_generation.get(chat_id, 0)
            await self._process_next_import_track(context, chat_id, job_id, generation)

        elif prefix == "is":
            track_id = int(parts[1])
            await asyncio.to_thread(self.import_repo.complete_track, job_id, track_id, TrackStatus.skipped)
            await _safe_query_edit(query, "⏭ Track skipped.")
            generation = self._chat_generation.get(chat_id, 0)
            await self._process_next_import_track(context, chat_id, job_id, generation)

    async def _handle_import_approve(self, update, context, chat_id: int, job_id: int, track_id: int, dl_id: str):
        """Approve a download within an import flow."""
        query = update.callback_query
        pending_dl = self.downloads.pop(dl_id, None)

        if not pending_dl:
            await self._edit_approval_message(query, "⏹ Download expired")
            return

        if not pending_dl.source_path:
            await self._edit_approval_message(query, "❌ Source file not ready. Download may still be in progress.")
            self.downloads[dl_id] = pending_dl
            return

        track = pending_dl.track
        result = pending_dl.result

        target_path = self.processor.process_file(pending_dl.source_path, track.artist, track.title)
        if target_path:
            self.processor.cleanup_download(pending_dl.source_path)
            await self._embed_spotify_artwork(target_path, track)
            target_name = os.path.basename(target_path)
            await self._edit_approval_message(query, f"✅ Saved: `{target_name}`")
            await self._add_history(track, result, "success")
            await asyncio.to_thread(self.import_repo.complete_track, job_id, track_id, TrackStatus.completed)
        else:
            await self._edit_approval_message(query, "❌ Failed to save file.")
            await asyncio.to_thread(
                self.import_repo.complete_track, job_id, track_id, TrackStatus.failed, "File processing failed"
            )

        # Continue to next track
        generation = self._chat_generation.get(chat_id, 0)
        await self._process_next_import_track(context, chat_id, job_id, generation)

    async def _process_next_import_track(self, context, chat_id: int, job_id: int, generation: int):
        """Process the next pending track in an import job."""
        if self._is_stale(chat_id, generation):
            return

        next_track = await asyncio.to_thread(self.import_repo.get_next_pending_track, job_id)

        if not next_track:
            # All tracks processed
            progress = await asyncio.to_thread(self.import_repo.get_job_progress, job_id)
            completed, failed, skipped, total = progress
            await asyncio.to_thread(self.import_repo.update_job_status, job_id, JobStatus.completed)
            self._active_import.pop(chat_id, None)
            await context.bot.send_message(
                chat_id=chat_id,
                text=f"\U0001f3c1 *Import complete!*\n\n"
                f"✅ Saved: {completed}\n"
                f"❌ Failed: {failed}\n"
                f"⏭ Skipped: {skipped}\n"
                f"\U0001f4ca Total: {total}",
                parse_mode=ParseMode.MARKDOWN,
            )
            return

        # Build TrackInfo from import track
        track_info = TrackInfo(
            artist=next_track.artist,
            title=next_track.title,
            album=next_track.album,
            duration_ms=next_track.duration_ms,
            spotify_url=next_track.spotify_url,
            year=next_track.year,
        )

        progress = await asyncio.to_thread(self.import_repo.get_job_progress, job_id)
        completed, failed, skipped, total = progress
        position = completed + failed + skipped + 1

        await asyncio.to_thread(self.import_repo.update_track_status, next_track.id, TrackStatus.searching)

        searching_msg = await context.bot.send_message(
            chat_id=chat_id,
            text=f"\U0001f4cb *Import [{position}/{total}]*\n"
            f"\U0001f50d Searching: *{track_info.artist} - {track_info.title}*\n"
            f"Album: {track_info.album} ({track_info.year})",
            parse_mode=ParseMode.MARKDOWN,
        )

        # Use the existing search logic but with import-aware download handling
        await self._do_import_slskd_search(
            context, chat_id, track_info, searching_msg, generation, job_id, next_track.id
        )

    async def _do_import_slskd_search(
        self, context, chat_id: int, track: TrackInfo, searching_msg, generation: int, job_id: int, track_id: int
    ):
        """Search slskd for an import track. Similar to _do_slskd_search but with import keyboards."""
        try:
            clean_title = _clean_search_title(track.title)
            search_query = f"{track.artist} {clean_title}"
            raw_responses = await self.slskd.search(search_query, timeout_secs=self.config.search_timeout_secs)
            if self._is_stale(chat_id, generation):
                return

            ranked, is_fallback = self._rank_responses(raw_responses, track)

            # Title-only fallback
            if not ranked:
                if self._is_stale(chat_id, generation):
                    return
                raw_responses = await self.slskd.search(clean_title, timeout_secs=self.config.search_timeout_secs)
                if self._is_stale(chat_id, generation):
                    return
                ranked, is_fallback = self._rank_responses(raw_responses, track)

            if self._is_stale(chat_id, generation):
                return

            if not ranked:
                await _safe_edit(
                    searching_msg,
                    f"\U0001f4cb *Import track:* {track.artist} - {track.title}\n\nNo results found on Soulseek.",
                    parse_mode=ParseMode.MARKDOWN,
                    reply_markup=build_import_skip_keyboard(job_id, track_id),
                )
                await asyncio.to_thread(self.import_repo.update_track_status, track_id, TrackStatus.awaiting_approval)
                return

            # Auto-pick best result and start download
            best = ranked[0]

            # Store results for potential "next result" retry (separate from regular search)
            self._import_pending[chat_id] = PendingSearch(
                query=search_query,
                track=track,
                results=ranked,
                message_id=searching_msg.message_id,
                is_fallback=is_fallback,
            )

            dl_id = self._next_dl_id()
            pending_dl = PendingDownload(
                track=track,
                result=best,
                chat_id=chat_id,
                source_path=None,
                status_message_id=searching_msg.message_id,
            )
            self.downloads[dl_id] = pending_dl

            await _safe_edit(
                searching_msg,
                f"\U0001f4cb *Import track:* {track.artist} - {track.title}\n"
                f"⬇️ Downloading: `{best.basename}`\n"
                f"From: `{best.username}` | {best.quality_display}",
                parse_mode=ParseMode.MARKDOWN,
            )

            # Start download
            task = context.application.create_task(
                self._do_import_download(
                    context, chat_id, track, best, searching_msg, generation, job_id, track_id, dl_id
                ),
                update=None,
            )
            self._track_task(chat_id, task)

        except Exception:
            logger.exception(f"Import search failed for: {track.artist} - {track.title}")
            await _safe_edit(searching_msg, f"❌ Search failed for {track.artist} - {track.title}")
            await asyncio.to_thread(
                self.import_repo.complete_track, job_id, track_id, TrackStatus.failed, "Search error"
            )
            await self._process_next_import_track(context, chat_id, job_id, generation)

    async def _do_import_download(
        self,
        context,
        chat_id: int,
        track: TrackInfo,
        result: SearchResult,
        status_msg,
        generation: int,
        job_id: int,
        track_id: int,
        dl_id: str,
    ):
        """Download a file within an import flow."""
        try:
            success = self.slskd.enqueue_download(result)
            if not success:
                await _safe_edit(
                    status_msg,
                    f"❌ Failed to enqueue from `{result.username}`",
                    parse_mode=ParseMode.MARKDOWN,
                    reply_markup=build_import_track_keyboard(job_id, track_id, dl_id),
                )
                await asyncio.to_thread(self.import_repo.update_track_status, track_id, TrackStatus.awaiting_approval)
                return

            status = await self.slskd.wait_for_download(
                username=result.username,
                filename=result.filename,
                timeout_secs=self.config.download_timeout_secs,
            )

            if status is None or status.is_failed:
                state = status.state if status else "Timeout"
                await _safe_edit(
                    status_msg,
                    f"❌ Download failed: {state}\n`{result.basename}`",
                    parse_mode=ParseMode.MARKDOWN,
                    reply_markup=build_retry_keyboard(dl_id),
                )
                await asyncio.to_thread(self.import_repo.update_track_status, track_id, TrackStatus.awaiting_approval)
                return

            source_path = self.processor.find_downloaded_file(result.username, result.filename)
            if not source_path:
                await _safe_edit(
                    status_msg,
                    "❌ Downloaded file not found on disk.",
                    reply_markup=build_import_track_keyboard(job_id, track_id, dl_id),
                )
                await asyncio.to_thread(self.import_repo.update_track_status, track_id, TrackStatus.awaiting_approval)
                return

            # Update PendingDownload with source path
            if dl_id in self.downloads:
                self.downloads[dl_id].source_path = source_path

            # Send file for approval
            await asyncio.to_thread(self.import_repo.update_track_status, track_id, TrackStatus.awaiting_approval)

            file_size = os.path.getsize(source_path) if os.path.isfile(source_path) else 0
            quality_line = f"{result.quality_display} | {result.duration_display}"
            caption = f"\U0001f4cb Import: {track.artist} - {track.title}\n{quality_line}"

            if file_size > TELEGRAM_FILE_LIMIT:
                # For large files, just show approve button without sending file
                await _safe_edit(
                    status_msg,
                    f"✅ Downloaded: `{result.basename}` ({file_size / (1024 * 1024):.0f}MB)\n"
                    f"{quality_line}\n\nFile too large to preview. Save to library?",
                    parse_mode=ParseMode.MARKDOWN,
                    reply_markup=build_import_track_keyboard(job_id, track_id, dl_id),
                )
            else:
                target_name = self.processor.build_filename(track.artist, track.title, result.extension)
                try:
                    with open(source_path, "rb") as f:
                        await context.bot.send_audio(
                            chat_id=chat_id,
                            audio=f,
                            filename=target_name,
                            title=track.title,
                            performer=track.artist,
                            duration=track.duration_secs,
                            caption=caption,
                            reply_markup=build_import_track_keyboard(job_id, track_id, dl_id),
                        )
                except BadRequest:
                    with open(source_path, "rb") as f:
                        await context.bot.send_document(
                            chat_id=chat_id,
                            document=f,
                            filename=target_name,
                            caption=caption,
                            reply_markup=build_import_track_keyboard(job_id, track_id, dl_id),
                        )

        except asyncio.CancelledError:
            self.downloads.pop(dl_id, None)
            raise
        except Exception:
            logger.exception(f"Import download failed for {result.basename}")
            await _safe_edit(status_msg, f"❌ Error downloading `{result.basename}`", parse_mode=ParseMode.MARKDOWN)
            await asyncio.to_thread(
                self.import_repo.complete_track, job_id, track_id, TrackStatus.failed, "Download error"
            )
            await self._process_next_import_track(context, chat_id, job_id, generation)

    # =========================================================================
    # RETRY HANDLERS
    # =========================================================================

    async def _handle_retry(self, update: Update, context: ContextTypes.DEFAULT_TYPE, chat_id: int, data: str):
        """Retry a failed download."""
        query = update.callback_query
        dl_id = data.split(":", 1)[1]

        pending_dl = self.downloads.pop(dl_id, None)
        if not pending_dl:
            await _safe_query_edit(query, "⏹ Download expired. Send a new search.")
            return

        if pending_dl.chat_id != chat_id:
            self.downloads[dl_id] = pending_dl
            return

        result = pending_dl.result
        track = pending_dl.track
        result_index = pending_dl.result_index

        await _safe_query_edit(
            query,
            f"\U0001f504 Retrying: `{result.basename}`...",
            parse_mode=ParseMode.MARKDOWN,
        )

        status_msg = await context.bot.send_message(
            chat_id=chat_id,
            text=f"⬇️ Re-downloading from `{result.username}`...",
            parse_mode=ParseMode.MARKDOWN,
        )

        task = context.application.create_task(
            self._do_download(context, chat_id, track, result, status_msg, result_index),
            update=update,
        )
        self._track_task(chat_id, task)

    async def _handle_next_result(self, update: Update, context: ContextTypes.DEFAULT_TYPE, chat_id: int, data: str):
        """Try the next-best search result after a failed download."""
        query = update.callback_query
        dl_id = data.split(":", 1)[1]

        pending = self.pending.get(chat_id) or self._import_pending.get(chat_id)
        pending_dl = self.downloads.pop(dl_id, None)

        if not pending or not pending.results or not pending_dl:
            await _safe_query_edit(query, "⏹ No more results available. Try a new search.")
            return

        if pending_dl.chat_id != chat_id:
            self.downloads[dl_id] = pending_dl
            return

        next_idx = pending_dl.result_index + 1
        if next_idx >= len(pending.results):
            await _safe_query_edit(query, "⏹ No more results to try.")
            return

        next_result = pending.results[next_idx]
        track = pending_dl.track

        await _safe_query_edit(
            query,
            f"⏭ Trying next result: `{next_result.basename}`",
            parse_mode=ParseMode.MARKDOWN,
        )

        status_msg = await context.bot.send_message(
            chat_id=chat_id,
            text=f"⬇️ Downloading from `{next_result.username}`...",
            parse_mode=ParseMode.MARKDOWN,
        )

        task = context.application.create_task(
            self._do_download(context, chat_id, track, next_result, status_msg, next_idx),
            update=update,
        )
        self._track_task(chat_id, task)

    # =========================================================================
    # FLAC ANALYSIS
    # =========================================================================

    @staticmethod
    async def _analyze_flac(filepath: str) -> FlacVerdict | None:
        """Run spectral analysis on a FLAC file in a thread to avoid blocking."""
        try:
            verdict = await asyncio.to_thread(analyze_flac, filepath)
            if verdict:
                logger.info("FLAC analysis for %s: %s (cutoff=%.1fkHz)", filepath, verdict.verdict, verdict.cutoff_khz)
            return verdict
        except Exception:
            logger.exception("FLAC analysis failed for %s", filepath)
            return None

    @staticmethod
    async def _convert_to_ogg(filepath: str) -> str | None:
        """Convert a full audio file to OGG Opus in a thread."""
        try:
            return await asyncio.to_thread(convert_to_ogg, filepath)
        except Exception:
            logger.exception("OGG conversion failed for %s", filepath)
            return None

    @staticmethod
    async def _create_preview(filepath: str, duration_secs: float = 60.0) -> str | None:
        """Create a trimmed audio preview clip in a thread to avoid blocking."""
        try:
            return await asyncio.to_thread(create_preview_clip, filepath, duration_secs)
        except Exception:
            logger.exception("Preview clip creation failed for %s", filepath)
            return None

    async def _embed_spotify_artwork(self, filepath: str, track: TrackInfo) -> None:
        """Fetch album artwork from Spotify and embed into the saved file."""
        try:
            art = await asyncio.to_thread(fetch_spotify_artwork, self.spotify.sp, track.artist, track.title)
            if art:
                ok = await asyncio.to_thread(embed_artwork_into_file, filepath, art)
                if ok:
                    logger.info("Embedded Spotify artwork into %s (%d KB)", filepath, len(art) // 1024)
        except Exception:
            logger.debug("Artwork embedding failed for %s", filepath, exc_info=True)

    # =========================================================================
    # HELPERS
    # =========================================================================

    @staticmethod
    def _format_spotify_results(tracks: list[TrackInfo], page: int = 0, page_size: int = 5) -> str:
        """Format Spotify track candidates for selection (one page)."""
        total = len(tracks)
        start = page * page_size
        end = min(start + page_size, total)
        total_pages = (total + page_size - 1) // page_size

        header = "🔍 *Multiple matches found on Spotify:*"
        if total_pages > 1:
            header += f" (page {page + 1}/{total_pages})"
        lines = [header + "\n"]

        for i in range(start, end):
            t = tracks[i]
            lines.append(
                f"*#{i + 1} {t.artist} - {t.title}*\n"
                f"    Album: {t.album} ({t.year}) | {t.duration_display}\n"
                f"    [Listen on Spotify]({t.spotify_url})"
            )
        lines.append("\nPick the correct version:")
        return "\n".join(lines)

    def _format_results(
        self,
        track: TrackInfo,
        results: list[SearchResult],
        is_fallback: bool = False,
        page: int = 0,
        page_size: int = 10,
    ) -> str:
        """Format search results for display in Telegram (one page)."""
        total = len(results)
        start = page * page_size
        end = min(start + page_size, total)
        total_pages = (total + page_size - 1) // page_size

        is_direct = track.duration_ms == 0
        if is_direct:
            if track.artist:
                header = [
                    f"🎵 *{track.artist} - {track.title}*\n",
                    f"Found {total} FLAC matches:\n",
                ]
            else:
                header = [
                    f"\U0001f50e *Direct search:* `{track.title}`\n",
                    f"Found {total} FLAC matches:\n",
                ]
        elif is_fallback:
            header = [
                f"🎵 *{track.artist} - {track.title}*",
                f"Duration: {track.duration_display} | Album: {track.album}\n",
                f"⚠️ No FLAC found — showing all formats ({total} matches):\n",
            ]
        else:
            header = [
                f"🎵 *{track.artist} - {track.title}*",
                f"Duration: {track.duration_display} | Album: {track.album}\n",
                f"Found {total} FLAC matches:\n",
            ]

        if total_pages > 1:
            header.append(f"📄 Page {page + 1}/{total_pages}\n")

        lines = header
        for i in range(start, end):
            r = results[i]
            slot_icon = "🟢" if r.has_free_slot else "🔴"
            fmt = r.extension.upper()
            format_tag = f" [{fmt}]" if is_fallback else ""
            lines.append(
                f"*#{i + 1}* {slot_icon} `{r.duration_display}` | "
                f"{r.quality_display}{format_tag} | {r.size_mb:.0f}MB\n"
                f"    `{r.basename}`"
            )

        return "\n".join(lines)

    @staticmethod
    def _parse_query_artist_title(query: str) -> tuple[str, str]:
        """Parse a free-text query into (artist, title) with title-casing.

        Tries " - " separator first. Otherwise assumes last word is title,
        rest is artist (e.g. "david bowie helden" → "David Bowie", "Helden").
        """
        if " - " in query:
            parts = query.split(" - ", 1)
            return parts[0].strip().title(), parts[1].strip().title()
        words = query.strip().split()
        if len(words) >= 3:
            return " ".join(words[:-1]).title(), words[-1].title()
        if len(words) == 2:
            return words[0].title(), words[1].title()
        return "", query.title()

    async def _add_history(self, track: TrackInfo, result: SearchResult, status: str):
        """Add an entry to download history (persisted in SQLite)."""
        await asyncio.to_thread(
            self.history_repo.add,
            artist=track.artist,
            title=track.title,
            album=track.album,
            filename=f"{track.artist} - {track.title}.{result.extension}",
            source_user=result.username,
            remote_path=result.filename,
            status=status,
            duration_secs=track.duration_secs,
            file_size=result.size,
        )


def create_bot(config: Config) -> Application:
    """
    Create and configure the Telegram bot application.

    Args:
        config: Application configuration.

    Returns:
        Configured telegram Application ready to run.
    """
    bot = MusicBot(config)

    app = Application.builder().token(config.telegram_bot_token).build()

    # Command handlers
    app.add_handler(CommandHandler("start", bot.cmd_start))
    app.add_handler(CommandHandler("help", bot.cmd_help))
    app.add_handler(CommandHandler("auto", bot.cmd_auto))
    app.add_handler(CommandHandler("status", bot.cmd_status))
    app.add_handler(CommandHandler("history", bot.cmd_history))
    app.add_handler(CommandHandler("import", bot.cmd_import))
    app.add_handler(CommandHandler("cancel", bot.cmd_cancel))

    # Callback query handler (inline keyboard buttons)
    app.add_handler(CallbackQueryHandler(bot.handle_callback))

    # Text message handler (song search) — must be last
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, bot.handle_text))

    logger.info("Telegram bot configured")
    return app
