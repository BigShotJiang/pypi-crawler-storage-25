"""
File processor for renaming and placing downloaded files.
Handles the final step: rename to 'Artist - Title.flac' and move to output directory.
"""

import contextlib
import logging
import os
import re
import shutil
from difflib import SequenceMatcher

import mutagen.flac

logger = logging.getLogger(__name__)

# Audio extensions to check for duplicates
_AUDIO_EXTENSIONS = {".flac", ".alac", ".wav", ".aiff", ".mp3", ".aac", ".m4a", ".ogg", ".opus", ".wma"}


class FileProcessor:
    """Handles file renaming, moving, and cleanup."""

    def __init__(self, download_dir: str, output_dir: str, filename_template: str = "{artist} - {title}"):
        self.download_dir = download_dir
        self.output_dir = output_dir
        self.filename_template = filename_template

        # Ensure output directory exists
        os.makedirs(self.output_dir, exist_ok=True)
        logger.info(f"File processor initialized: downloads={download_dir}, output={output_dir}")

    def find_similar(self, query: str, threshold: float = 0.6) -> list[str]:
        """
        Find files in the output directory with names similar to the query.
        Uses fuzzy matching on the filename stem (without extension).

        Args:
            query: The search query or "Artist - Title" string to match against.
            threshold: Minimum similarity ratio (0.0 to 1.0). Default 0.6.

        Returns:
            List of matching filenames sorted by similarity (best first).
        """
        if not os.path.isdir(self.output_dir):
            return []

        query_lower = query.lower()
        # Extract individual words for word-level matching
        query_words = set(re.findall(r"\w+", query_lower))

        matches = []
        for filename in os.listdir(self.output_dir):
            _, ext = os.path.splitext(filename)
            if ext.lower() not in _AUDIO_EXTENSIONS:
                continue

            stem = os.path.splitext(filename)[0].lower()
            stem_words = set(re.findall(r"\w+", stem))

            # Word overlap ratio
            if query_words and stem_words:
                common = query_words & stem_words
                word_ratio = len(common) / min(len(query_words), len(stem_words))
            else:
                word_ratio = 0.0

            # Sequence similarity
            seq_ratio = SequenceMatcher(None, query_lower, stem).ratio()

            # Use the best of both approaches
            best_ratio = max(word_ratio, seq_ratio)

            if best_ratio >= threshold:
                matches.append((filename, best_ratio))

        # Sort by similarity descending
        matches.sort(key=lambda x: x[1], reverse=True)
        return [m[0] for m in matches]

    def build_filename(self, artist: str, title: str, extension: str = "flac") -> str:
        """
        Build the target filename from artist and title.

        Args:
            artist: Artist/group name.
            title: Song title.
            extension: File extension (default: flac).

        Returns:
            Sanitized filename like 'Artist - Title.flac'.
        """
        name = self.filename_template.format(artist=artist, title=title)
        name = self._sanitize_filename(name)
        return f"{name}.{extension}"

    def find_downloaded_file(self, username: str, remote_filename: str) -> str | None:
        """
        Find a downloaded file on disk based on the slskd download structure.
        slskd stores downloads as: <download_dir>/<username>/<directory>/<filename>

        Args:
            username: The Soulseek username of the source.
            remote_filename: The remote path (with backslashes).

        Returns:
            Absolute path to the file on disk, or None if not found.
        """
        # The basename of the remote file
        basename = remote_filename.rsplit("\\", 1)[-1] if "\\" in remote_filename else remote_filename

        # Walk the download directory looking for the file
        user_dir = os.path.join(self.download_dir, username)

        # PATH TRAVERSAL GUARD
        real_user_dir = os.path.realpath(user_dir)
        real_download_dir = os.path.realpath(self.download_dir)
        if not real_user_dir.startswith(real_download_dir + os.sep) and real_user_dir != real_download_dir:
            logger.warning("Path traversal blocked for username: %s", username)
            return None

        if os.path.isdir(user_dir):
            for root, _, files in os.walk(user_dir):
                if basename in files:
                    path = os.path.join(root, basename)
                    logger.info(f"Found downloaded file: {path}")
                    return path

        # Fallback: search entire download directory
        for root, _, files in os.walk(self.download_dir):
            if basename in files:
                path = os.path.join(root, basename)
                logger.info(f"Found downloaded file (fallback): {path}")
                return path

        logger.warning(f"Downloaded file not found: {basename} (user={username})")
        return None

    def process_file(self, source_path: str, artist: str, title: str) -> str | None:
        """
        Rename and move a downloaded file to the output directory.

        Args:
            source_path: Path to the downloaded file.
            artist: Artist name for the filename.
            title: Song title for the filename.

        Returns:
            Path to the final file in the output directory, or None on failure.
        """
        try:
            if not os.path.isfile(source_path):
                logger.error(f"Source file does not exist: {source_path}")
                return None

            # Determine extension from source
            _, ext = os.path.splitext(source_path)
            extension = ext.lstrip(".").lower() or "flac"

            # Build target filename
            target_name = self.build_filename(artist, title, extension)
            target_path = os.path.join(self.output_dir, target_name)

            # Avoid overwriting existing files
            if os.path.exists(target_path):
                logger.warning(f"File already exists: {target_path}")
                # Add a numeric suffix
                base, ext_with_dot = os.path.splitext(target_path)
                counter = 1
                while os.path.exists(target_path):
                    target_path = f"{base} ({counter}){ext_with_dot}"
                    counter += 1

            # Copy to a temp file with a non-audio extension so downstream
            # watchers (audio-transcoder, Navidrome) ignore it entirely.
            # Clean tags on the temp file, then atomically rename into place.
            tmp_path = target_path + ".importing"
            try:
                shutil.copy2(source_path, tmp_path)
                self._dedup_flac_tags(tmp_path)
                os.replace(tmp_path, target_path)
            except BaseException:
                with contextlib.suppress(OSError):
                    os.remove(tmp_path)
                raise
            logger.info(f"File placed: {target_path}")

            return target_path

        except Exception:
            logger.exception(f"Failed to process file: {source_path}")
            return None

    def cleanup_download(self, source_path: str) -> bool:
        """
        Remove the original downloaded file after successful processing.

        Args:
            source_path: Path to the downloaded file to remove.

        Returns:
            True if cleanup succeeded.
        """
        try:
            if os.path.isfile(source_path):
                os.remove(source_path)
                logger.info(f"Cleaned up: {source_path}")

                # Also remove the parent directory if empty
                parent = os.path.dirname(source_path)
                if os.path.isdir(parent) and not os.listdir(parent):
                    os.rmdir(parent)
                    logger.debug(f"Removed empty directory: {parent}")

                return True
            return False

        except Exception:
            logger.exception(f"Failed to cleanup: {source_path}")
            return False

    @staticmethod
    def _dedup_flac_tags(filepath: str) -> None:
        """Remove exact duplicate Vorbis comment values in a FLAC file.

        Many Soulseek sources have identical ARTIST/TITLE/ALBUM entries
        repeated.  This removes only exact repeated values while preserving
        legitimate multi-value tags (e.g. multiple artists or genres).

        Accepts any path; non-FLAC files are silently skipped via the
        try/except (mutagen reads file headers, not extensions).
        """
        try:
            audio = mutagen.flac.FLAC(filepath)
            changed = False
            for key in list(audio.keys()):
                values = audio.get(key, [])
                if len(values) <= 1:
                    continue
                seen: list[str] = []
                for v in values:
                    if v not in seen:
                        seen.append(v)
                if len(seen) < len(values):
                    audio[key] = seen
                    changed = True
            if changed:
                audio.save()
                logger.info("Deduplicated FLAC tags: %s", os.path.basename(filepath))
        except Exception:
            logger.debug("Tag dedup failed for %s", filepath, exc_info=True)

    @staticmethod
    def _sanitize_filename(name: str) -> str:
        """
        Remove or replace characters that are invalid in filenames.

        Args:
            name: Raw filename string.

        Returns:
            Sanitized filename safe for all major filesystems.
        """
        # Replace characters invalid on Windows/Linux/macOS
        name = re.sub(r'[<>:"/\\|?*]', "", name)
        # Replace multiple spaces with single space
        name = re.sub(r"\s+", " ", name)
        # Strip leading/trailing whitespace and dots
        name = name.strip(" .")
        return name
