"""
Token counter for LocalFirst.

Tracks what was handled locally vs what went to the cloud.
Persists to .localfirst/stats.json for weekly summaries.
"""

from __future__ import annotations

import json
import logging
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)

STATS_FILE = ".localfirst/stats.json"

# Cloud model pricing (USD per 1M input tokens)
MODEL_COSTS: dict[str, float] = {
    "claude-haiku-4-5":  0.25,
    "claude-sonnet-4-6": 3.00,
    "claude-opus-4-6":  15.00,
    "gpt-4o-mini":       0.15,
    "gpt-4o":            2.50,
}


@dataclass
class RunStats:
    run_id: str
    task: str
    timestamp: str
    routing_layer: str          # "local", "worker", "planner", "coder"
    model: str
    tokens_local: int = 0       # tokens handled locally (0 cost)
    tokens_cloud: int = 0       # tokens sent to cloud
    tokens_repo_total: int = 0  # total tokens in repo
    cost_usd: float = 0.0
    cost_saved_usd: float = 0.0  # vs sending full repo to sonnet
    duration_ms: float = 0.0


@dataclass
class WeeklyStats:
    runs: int = 0
    tokens_local: int = 0
    tokens_cloud: int = 0
    tokens_saved: int = 0
    cost_usd: float = 0.0
    cost_saved_usd: float = 0.0
    local_pct: float = 0.0

    @property
    def summary_line(self) -> str:
        return (
            f"{self.runs} tasks · "
            f"{self.local_pct:.0f}% local · "
            f"saved ${self.cost_saved_usd:.2f}"
        )


class TokenCounter:
    """
    Tracks and persists token usage statistics.
    """

    def __init__(self, repo_root: Path):
        self.repo_root = repo_root
        self.stats_path = repo_root / STATS_FILE
        self.stats_path.parent.mkdir(parents=True, exist_ok=True)
        self._runs: list[RunStats] = self._load()

    def record(self, run: RunStats) -> None:
        """Record a run's stats."""
        self._runs.append(run)
        self._save()

    def weekly_summary(self, days: int = 7) -> WeeklyStats:
        """Compute summary for the last N days."""
        from datetime import timedelta
        cutoff = datetime.now(timezone.utc) - timedelta(days=days)

        recent = [
            r for r in self._runs
            if datetime.fromisoformat(r.timestamp) > cutoff
        ]

        if not recent:
            return WeeklyStats()

        total_tokens = sum(r.tokens_local + r.tokens_cloud for r in recent)
        local_tokens = sum(r.tokens_local for r in recent)
        cloud_tokens = sum(r.tokens_cloud for r in recent)
        saved = sum(r.tokens_saved for r in recent) if hasattr(recent[0], 'tokens_saved') else 0

        return WeeklyStats(
            runs=len(recent),
            tokens_local=local_tokens,
            tokens_cloud=cloud_tokens,
            tokens_saved=sum(r.tokens_repo_total - r.tokens_cloud for r in recent if r.tokens_repo_total > 0),
            cost_usd=sum(r.cost_usd for r in recent),
            cost_saved_usd=sum(r.cost_saved_usd for r in recent),
            local_pct=(local_tokens / total_tokens * 100) if total_tokens > 0 else 0,
        )

    def _load(self) -> list[RunStats]:
        try:
            if self.stats_path.exists():
                data = json.loads(self.stats_path.read_text())
                return [RunStats(**r) for r in data.get("runs", [])]
        except Exception:
            pass
        return []

    def _save(self) -> None:
        try:
            # Keep last 1000 runs
            runs = self._runs[-1000:]
            self.stats_path.write_text(
                json.dumps({"runs": [asdict(r) for r in runs]}, indent=2)
            )
        except Exception as e:
            logger.debug(f"Could not save stats: {e}")


def calculate_savings(
    tokens_sent: int,
    tokens_repo_total: int,
    model: str = "claude-sonnet-4-6",
) -> float:
    """Calculate USD saved by filtering context."""
    cost_per_1m = MODEL_COSTS.get(model, 3.0)
    cost_full = (tokens_repo_total / 1_000_000) * cost_per_1m
    cost_filtered = (tokens_sent / 1_000_000) * cost_per_1m
    return max(0.0, round(cost_full - cost_filtered, 4))
