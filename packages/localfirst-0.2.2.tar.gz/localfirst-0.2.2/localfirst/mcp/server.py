"""LocalFirst MCP Server."""
from __future__ import annotations
import logging
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)


def create_mcp_server():
    try:
        from fastmcp import FastMCP
    except ImportError:
        raise ImportError("fastmcp required. Install with: pip install fastmcp")

    mcp = FastMCP("localfirst")

    @mcp.tool()
    def localfirst_prep(
        task: str,
        repo_path: Optional[str] = None,
        extra_context: Optional[str] = None,
        output_format: str = "compact",
    ) -> str:
        """Prepare context + routing decision for a coding task."""
        try:
            from lao.core.runner import run_prep
            from lao.models import TaskInput
            from lao.config import load_config
            from lao.output.compact import render_compact
            from localfirst.config import load_config as lf_config
            from localfirst.router import Router

            repo = Path(repo_path or ".").resolve()
            config = load_config(repo)
            task_input = TaskInput(task=task, repo_path=repo)
            if extra_context:
                task_input.extra_context = extra_context

            pack, report, _, _ = run_prep(task_input, config, silent=True)

            # Get routing decision
            lf_conf = lf_config(repo_root=repo)
            router = Router(lf_conf)
            decision = router.route(task, context_tokens=pack.optimized_token_estimate)

            output = render_compact(pack, report)
            route_line = f"\nROUTE:{decision.layer.value.upper()} MODEL:{decision.model} COST:${decision.estimated_cost_usd:.4f}"
            return output + route_line

        except Exception as e:
            return f"Error: {e}"

    @mcp.tool()
    def localfirst_route(task: str, repo_path: Optional[str] = None) -> str:
        """Show routing decision for a task."""
        try:
            from localfirst.config import load_config
            from localfirst.router import Router
            repo = Path(repo_path or ".").resolve()
            config = load_config(repo_root=repo)
            router = Router(config)
            d = router.route(task)
            return f"Layer: {d.layer.value}\nModel: {d.model}\nReason: {d.reason}\nCost: ${d.estimated_cost_usd:.4f}"
        except Exception as e:
            return f"Error: {e}"

    @mcp.tool()
    def localfirst_status(repo_path: Optional[str] = None) -> str:
        """Show LocalFirst status."""
        try:
            import shutil
            ollama = "✓" if shutil.which("ollama") else "✗"
            rg = "✓" if shutil.which("rg") else "✗"
            return f"ripgrep: {rg}\nOllama: {ollama}\nLocalFirst: ready"
        except Exception as e:
            return f"Error: {e}"

    return mcp


def run_stdio() -> None:
    mcp = create_mcp_server()
    mcp.run(transport="stdio")


def run_http(port: int = 8765) -> None:
    mcp = create_mcp_server()
    mcp.run(transport="sse", port=port)
