"""
Hardware detection for LocalFirst.

Detects RAM, CPU, GPU to recommend the right local model.
Used during `localfirst init` to suggest Qwen size.
"""

from __future__ import annotations

import platform
import subprocess
from dataclasses import dataclass
from typing import Optional


@dataclass
class HardwareProfile:
    ram_gb: float
    cpu_cores: int
    cpu_name: str
    gpu_name: Optional[str]
    gpu_vram_gb: Optional[float]
    platform: str  # "macos", "linux", "windows"
    is_apple_silicon: bool

    @property
    def recommended_model(self) -> str:
        """Recommend Qwen model based on hardware."""
        if self.is_apple_silicon and self.ram_gb >= 16:
            return "qwen2.5-coder:7b"
        if self.gpu_vram_gb and self.gpu_vram_gb >= 8:
            return "qwen2.5-coder:7b"
        if self.ram_gb >= 8:
            return "qwen2.5-coder:1.5b"
        return "qwen2.5-coder:0.5b"

    @property
    def recommended_model_size(self) -> str:
        m = self.recommended_model
        if "7b" in m:
            return "~5GB"
        if "1.5b" in m:
            return "~1GB"
        return "~400MB"

    @property
    def can_run_local_model(self) -> bool:
        return self.ram_gb >= 4


def detect_hardware() -> HardwareProfile:
    """Detect hardware profile. Never raises."""
    import psutil

    ram_gb = psutil.virtual_memory().total / (1024 ** 3)
    cpu_cores = psutil.cpu_count(logical=False) or 1
    cpu_name = _get_cpu_name()
    gpu_name, gpu_vram = _get_gpu_info()
    os_platform = platform.system().lower()
    platform_name = {"darwin": "macos", "linux": "linux", "windows": "windows"}.get(
        os_platform, "unknown"
    )
    is_apple_silicon = platform_name == "macos" and platform.machine() == "arm64"

    return HardwareProfile(
        ram_gb=round(ram_gb, 1),
        cpu_cores=cpu_cores,
        cpu_name=cpu_name,
        gpu_name=gpu_name,
        gpu_vram_gb=gpu_vram,
        platform=platform_name,
        is_apple_silicon=is_apple_silicon,
    )


def _get_cpu_name() -> str:
    try:
        if platform.system() == "Darwin":
            result = subprocess.run(
                ["sysctl", "-n", "machdep.cpu.brand_string"],
                capture_output=True, text=True, timeout=3
            )
            return result.stdout.strip() or platform.processor()
        if platform.system() == "Linux":
            with open("/proc/cpuinfo") as f:
                for line in f:
                    if line.startswith("model name"):
                        return line.split(":")[1].strip()
    except Exception:
        pass
    return platform.processor() or "Unknown CPU"


def _get_gpu_info() -> tuple[Optional[str], Optional[float]]:
    """Try to detect GPU and VRAM. Returns (name, vram_gb) or (None, None)."""
    # Try nvidia-smi
    try:
        result = subprocess.run(
            ["nvidia-smi", "--query-gpu=name,memory.total", "--format=csv,noheader"],
            capture_output=True, text=True, timeout=5
        )
        if result.returncode == 0:
            parts = result.stdout.strip().split(",")
            if len(parts) >= 2:
                name = parts[0].strip()
                vram_str = parts[1].strip()
                vram_mb = float(vram_str.replace("MiB", "").strip())
                return name, round(vram_mb / 1024, 1)
    except Exception:
        pass

    # macOS Metal (Apple Silicon — uses unified memory)
    if platform.system() == "Darwin" and platform.machine() == "arm64":
        try:
            import psutil
            ram = psutil.virtual_memory().total / (1024 ** 3)
            return "Apple Silicon (unified memory)", round(ram, 1)
        except Exception:
            pass

    return None, None
