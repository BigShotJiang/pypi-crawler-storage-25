"""
Ollama integration for LocalFirst.

Handles:
- Checking if Ollama is installed and running
- Pulling models
- Running inference (chat completion)
- Streaming responses
"""

from __future__ import annotations

import json
import logging
from typing import AsyncIterator, Optional

logger = logging.getLogger(__name__)

OLLAMA_BASE_URL = "http://localhost:11434"

RECOMMENDED_MODELS = [
    {
        "id": "qwen2.5-coder:0.5b",
        "name": "Qwen 2.5 Coder 0.5B",
        "size": "400MB",
        "description": "Fast, minimal hardware",
        "min_ram_gb": 4,
    },
    {
        "id": "qwen2.5-coder:1.5b",
        "name": "Qwen 2.5 Coder 1.5B",
        "size": "1GB",
        "description": "Recommended for most machines",
        "min_ram_gb": 8,
    },
    {
        "id": "qwen2.5-coder:7b",
        "name": "Qwen 2.5 Coder 7B",
        "size": "5GB",
        "description": "Best quality, needs 8GB+ RAM or GPU",
        "min_ram_gb": 16,
    },
    {
        "id": "qwen2.5-coder:32b",
        "name": "Qwen 2.5 Coder 32B",
        "size": "20GB",
        "description": "Near-Sonnet quality, high-end only",
        "min_ram_gb": 32,
    },
]


class OllamaClient:
    """Simple async Ollama client using httpx."""

    def __init__(self, base_url: str = OLLAMA_BASE_URL):
        self.base_url = base_url.rstrip("/")

    async def is_running(self) -> bool:
        """Check if Ollama server is running."""
        try:
            import httpx
            async with httpx.AsyncClient(timeout=3) as client:
                r = await client.get(f"{self.base_url}/api/tags")
                return r.status_code == 200
        except Exception:
            return False

    async def list_models(self) -> list[str]:
        """List installed models."""
        try:
            import httpx
            async with httpx.AsyncClient(timeout=5) as client:
                r = await client.get(f"{self.base_url}/api/tags")
                data = r.json()
                return [m["name"] for m in data.get("models", [])]
        except Exception:
            return []

    async def has_model(self, model: str) -> bool:
        """Check if a specific model is installed."""
        models = await self.list_models()
        # Normalize: "qwen2.5-coder:1.5b" matches "qwen2.5-coder:1.5b"
        model_base = model.split(":")[0].lower()
        for m in models:
            if m.lower().startswith(model_base):
                return True
        return False

    async def pull_model(self, model: str) -> bool:
        """Pull a model. Returns True on success."""
        try:
            import httpx
            async with httpx.AsyncClient(timeout=300) as client:
                async with client.stream(
                    "POST",
                    f"{self.base_url}/api/pull",
                    json={"name": model},
                ) as r:
                    async for line in r.aiter_lines():
                        if line:
                            data = json.loads(line)
                            if data.get("status") == "success":
                                return True
            return True
        except Exception as e:
            logger.error(f"Failed to pull model {model}: {e}")
            return False

    async def chat(
        self,
        model: str,
        messages: list[dict],
        system: str = "",
        temperature: float = 0.1,
        max_tokens: int = 2000,
    ) -> str:
        """Run a chat completion. Returns response text."""
        try:
            import httpx

            payload = {
                "model": model,
                "messages": messages,
                "stream": False,
                "options": {
                    "temperature": temperature,
                    "num_predict": max_tokens,
                },
            }
            if system:
                payload["system"] = system

            async with httpx.AsyncClient(timeout=120) as client:
                r = await client.post(
                    f"{self.base_url}/api/chat",
                    json=payload,
                )
                data = r.json()
                return data.get("message", {}).get("content", "")
        except Exception as e:
            logger.error(f"Ollama chat failed: {e}")
            return ""

    async def chat_stream(
        self,
        model: str,
        messages: list[dict],
        system: str = "",
    ) -> AsyncIterator[str]:
        """Stream a chat completion."""
        try:
            import httpx

            payload = {
                "model": model,
                "messages": messages,
                "stream": True,
            }
            if system:
                payload["system"] = system

            async with httpx.AsyncClient(timeout=120) as client:
                async with client.stream(
                    "POST",
                    f"{self.base_url}/api/chat",
                    json=payload,
                ) as r:
                    async for line in r.aiter_lines():
                        if line:
                            data = json.loads(line)
                            token = data.get("message", {}).get("content", "")
                            if token:
                                yield token
                            if data.get("done"):
                                break
        except Exception as e:
            logger.error(f"Ollama stream failed: {e}")
            return


def get_install_instructions(platform: str) -> str:
    """Get Ollama install instructions for platform."""
    if platform == "macos":
        return "brew install ollama"
    if platform == "linux":
        return "curl -fsSL https://ollama.ai/install.sh | sh"
    if platform == "windows":
        return "Download from https://ollama.ai/download"
    return "Visit https://ollama.ai/download"
