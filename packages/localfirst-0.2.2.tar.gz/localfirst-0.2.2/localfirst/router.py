"""
LocalFirst 3-layer router.

Routes tasks to the cheapest capable resource:

  Layer 0 — Local tools (ripgrep, file ops)     → 0 tokens
  Layer 1 — Worker (Qwen via Ollama)             → 0 cloud tokens
  Layer 2 — Planner (claude-haiku / gpt-4o-mini) → cheap
  Layer 3 — Coder (claude-sonnet / gpt-4o)       → full power

Decision is based on task classification:
  - file_ops / search → Layer 0
  - simple_question / explain_snippet → Layer 1
  - code_review / architecture → Layer 2
  - bug_fix / implement / refactor → Layer 3
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from enum import Enum
from typing import Optional

logger = logging.getLogger(__name__)


class RoutingLayer(str, Enum):
    LOCAL = "local"       # 0 tokens — ripgrep, file ops
    WORKER = "worker"     # 0 cloud tokens — Qwen/Ollama
    PLANNER = "planner"   # cheap cloud — haiku, gpt-4o-mini
    CODER = "coder"       # full power — sonnet, gpt-4o


class TaskComplexity(str, Enum):
    LOCAL = "local"
    SIMPLE = "simple"
    MEDIUM = "medium"
    HARD = "hard"


@dataclass
class RoutingDecision:
    layer: RoutingLayer
    model: str
    reason: str
    estimated_tokens: int
    estimated_cost_usd: float

    @property
    def is_local(self) -> bool:
        return self.layer in (RoutingLayer.LOCAL, RoutingLayer.WORKER)

    @property
    def display(self) -> str:
        if self.layer == RoutingLayer.LOCAL:
            return "⚡ Local (0 tokens)"
        if self.layer == RoutingLayer.WORKER:
            return f"🖥  Worker ({self.model})"
        if self.layer == RoutingLayer.PLANNER:
            return f"☁  Planner ({self.model})"
        return f"☁  Coder ({self.model})"


# Token cost per 1M input tokens (USD)
MODEL_COSTS: dict[str, float] = {
    "claude-haiku-4-5":   0.25,
    "claude-sonnet-4-6":  3.00,
    "claude-opus-4-6":   15.00,
    "gpt-4o-mini":        0.15,
    "gpt-4o":             2.50,
    "gemini-1.5-flash":   0.075,
    "gemini-1.5-pro":     1.25,
}

# Keywords that suggest each complexity level
LOCAL_KEYWORDS = {
    "find", "search", "grep", "list", "show", "where", "which",
    "ls", "tree", "count", "how many", "what files",
}

SIMPLE_KEYWORDS = {
    "explain", "what is", "what does", "describe", "summarize",
    "how does", "what are", "overview", "document",
}

MEDIUM_KEYWORDS = {
    "review", "analyze", "plan", "architecture", "design",
    "compare", "suggest", "improve", "optimize", "refactor",
}

HARD_KEYWORDS = {
    "fix", "bug", "implement", "build", "create", "write",
    "add", "change", "update", "migrate", "test", "debug",
    "failing", "error", "broken", "crash",
}


class Router:
    """
    Routes tasks to appropriate execution layer.
    
    Config determines which models to use at each layer
    and whether Ollama is available.
    """

    def __init__(self, config: dict):
        self.config = config
        self.worker_model = config.get("worker", {}).get("model", "qwen2.5-coder:1.5b")
        self.planner_model = config.get("planner", {}).get("model", "claude-haiku-4-5")
        self.coder_model = config.get("coder", {}).get("model", "claude-sonnet-4-6")
        self.ollama_available = config.get("worker", {}).get("enabled", False)

    def route(self, task: str, context_tokens: int = 0) -> RoutingDecision:
        """
        Decide which layer should handle this task.
        
        Args:
            task: The task description
            context_tokens: Number of tokens in the context pack
        """
        complexity = self._classify_complexity(task)

        if complexity == TaskComplexity.LOCAL:
            return RoutingDecision(
                layer=RoutingLayer.LOCAL,
                model="local",
                reason="Task can be handled with local file operations",
                estimated_tokens=0,
                estimated_cost_usd=0.0,
            )

        if complexity == TaskComplexity.SIMPLE and self.ollama_available:
            return RoutingDecision(
                layer=RoutingLayer.WORKER,
                model=self.worker_model,
                reason="Simple task routed to local Ollama model",
                estimated_tokens=0,
                estimated_cost_usd=0.0,
            )

        if complexity == TaskComplexity.MEDIUM:
            cost = (context_tokens / 1_000_000) * MODEL_COSTS.get(self.planner_model, 0.25)
            return RoutingDecision(
                layer=RoutingLayer.PLANNER,
                model=self.planner_model,
                reason="Medium complexity — using planner model",
                estimated_tokens=context_tokens,
                estimated_cost_usd=round(cost, 4),
            )

        # Hard or simple without Ollama → coder
        cost = (context_tokens / 1_000_000) * MODEL_COSTS.get(self.coder_model, 3.0)
        return RoutingDecision(
            layer=RoutingLayer.CODER,
            model=self.coder_model,
            reason="Complex task — using coder model",
            estimated_tokens=context_tokens,
            estimated_cost_usd=round(cost, 4),
        )

    def _classify_complexity(self, task: str) -> TaskComplexity:
        """Classify task complexity based on keywords."""
        task_lower = task.lower()
        words = set(task_lower.split())

        # Count keyword matches per level
        hard_hits = sum(1 for kw in HARD_KEYWORDS if kw in task_lower)
        medium_hits = sum(1 for kw in MEDIUM_KEYWORDS if kw in task_lower)
        simple_hits = sum(1 for kw in SIMPLE_KEYWORDS if kw in task_lower)
        local_hits = sum(1 for kw in LOCAL_KEYWORDS if kw in task_lower)

        # Local ops: pure search/list tasks
        if local_hits > 0 and hard_hits == 0 and medium_hits == 0:
            return TaskComplexity.LOCAL

        # Hard: explicit action keywords
        if hard_hits >= 1:
            return TaskComplexity.HARD

        # Medium: analysis/review
        if medium_hits >= 1:
            return TaskComplexity.MEDIUM

        # Simple: explanation/overview
        if simple_hits >= 1:
            return TaskComplexity.SIMPLE

        # Default: medium (safe choice)
        return TaskComplexity.MEDIUM


def create_router_from_config(config_path: Optional[str] = None) -> Router:
    """Load config and create router."""
    from localfirst.config import load_config
    config = load_config(config_path)
    return Router(config)
