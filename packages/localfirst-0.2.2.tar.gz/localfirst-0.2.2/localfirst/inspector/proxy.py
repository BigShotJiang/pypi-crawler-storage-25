"""LocalFirst Inspector — zeigt was Claude Code wirklich macht."""
from __future__ import annotations
import json
import time
from datetime import datetime
from pathlib import Path
import httpx
from rich.console import Console
from rich.panel import Panel

console = Console()

ANTHROPIC_REAL = "https://api.anthropic.com"

SECRET_PATTERNS = [".env", "api_key", "secret", "password", "token", "private_key"]


def scan_secrets(text: str) -> list[str]:
    found = []
    lower = text.lower()
    for p in SECRET_PATTERNS:
        if p in lower:
            found.append(p)
    return found


def run_inspector(port: int = 8081, mode: str = "log", log_file: str | None = None):
    try:
        from fastapi import FastAPI, Request
        from fastapi.responses import StreamingResponse
        import uvicorn
    except ImportError:
        console.print("[red]Missing deps: pip install fastapi uvicorn[/red]")
        return

    app = FastAPI()
    log_path = Path(log_file) if log_file else None
    request_count = 0

    console.print()
    console.print(Panel(
        f"[bold green]LocalFirst Inspector[/bold green]\n\n"
        f"  Proxy läuft auf: [cyan]http://localhost:{port}[/cyan]\n\n"
        f"  Starte Claude Code so:\n"
        f"  [bold]$env:ANTHROPIC_BASE_URL=\"http://localhost:{port}\"[/bold]\n"
        f"  [bold]claude \"deine frage\"[/bold]\n\n"
        f"  [dim]Ctrl+C zum Beenden[/dim]",
        title="Inspector",
        border_style="green"
    ))

    @app.api_route("/{path:path}", methods=["GET", "POST", "PUT", "DELETE", "OPTIONS"])
    async def proxy(request: Request, path: str):
        nonlocal request_count
        request_count += 1

        body = await request.body()
        headers = dict(request.headers)
        headers.pop("host", None)

        # Parse und anzeigen
        timestamp = datetime.now().strftime("%H:%M:%S")
        tokens_estimate = 0
        secrets_found = []
        files_detected = []

        if body:
            try:
                data = json.loads(body)
                messages = data.get("messages", [])
                full_text = json.dumps(data)

                # Token estimate (rough: 4 chars = 1 token)
                tokens_estimate = len(full_text) // 4

                # Secret scan
                secrets_found = scan_secrets(full_text)

                # File detection
                for msg in messages:
                    content = msg.get("content", "")
                    if isinstance(content, str):
                        for line in content.split("\n"):
                            if line.startswith("---") and ("." in line):
                                files_detected.append(line.strip("- ").strip())

            except Exception:
                pass

        # Output
        color = "red" if secrets_found else "cyan"
        console.print(f"\n[dim]{timestamp}[/dim] [bold {color}]📤 Request #{request_count}[/bold {color}]")
        console.print(f"  Endpoint: [dim]/{path}[/dim]")
        console.print(f"  Tokens:   ~[yellow]{tokens_estimate:,}[/yellow]")

        if files_detected:
            console.print(f"  Dateien erkannt:")
            for f in files_detected[:10]:
                console.print(f"    [dim]{f}[/dim]")

        if secrets_found:
            console.print(f"  [bold red]⚠️  SECRETS GEFUNDEN: {', '.join(secrets_found)}[/bold red]")

        # Log to file
        if log_path:
            with open(log_path, "a") as f:
                f.write(json.dumps({
                    "ts": timestamp,
                    "path": path,
                    "tokens": tokens_estimate,
                    "secrets": secrets_found,
                    "files": files_detected,
                }) + "\n")

        # Block secrets in block mode
        if mode == "block_secrets" and secrets_found:
            console.print(f"  [bold red]BLOCKED — Secret würde Maschine verlassen![/bold red]")
            return {"error": "blocked by LocalFirst Inspector", "reason": "secrets detected"}

        # Forward to Anthropic
        url = f"{ANTHROPIC_REAL}/{path}"
        async with httpx.AsyncClient(timeout=120) as client:
            resp = await client.request(
                method=request.method,
                url=url,
                headers=headers,
                content=body,
                params=dict(request.query_params),
            )

        console.print(f"  Status:   [{('green' if resp.status_code == 200 else 'red')}]{resp.status_code}[/]")

        return StreamingResponse(
            content=iter([resp.content]),
            status_code=resp.status_code,
            headers=dict(resp.headers),
        )

    uvicorn.run(app, host="0.0.0.0", port=port, log_level="error")
