"""LocalFirst CLI."""
from __future__ import annotations
import asyncio
import logging
import time
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Annotated, Optional

import typer
from rich.console import Console

app = typer.Typer(
    name="localfirst",
    help="Your hardware runs first. Cloud is the exception, not the rule.",
    add_completion=False,
    no_args_is_help=True,
)
console = Console()
VERSION = "0.2.2"


def _setup_logging(verbose: bool) -> None:
    logging.basicConfig(level=logging.DEBUG if verbose else logging.WARNING)


@app.command()
def init(
    repo: Annotated[Optional[Path], typer.Argument()] = None,
    yes: Annotated[bool, typer.Option("--yes", "-y")] = False,
    verbose: Annotated[bool, typer.Option("--verbose", "-v")] = False,
) -> None:
    """Initialize LocalFirst: detect hardware, setup Ollama, create config."""
    _setup_logging(verbose)
    from localfirst.hardware import detect_hardware
    from localfirst.ollama import OllamaClient, get_install_instructions
    from localfirst.config import init_config

    repo_path = (repo or Path.cwd()).resolve()
    console.print()
    console.print("[bold]LocalFirst Setup[/bold]")
    console.print("[dim]Your hardware runs first. Cloud is the exception.[/dim]")
    console.print()

    console.print("🔍 Detecting hardware...")
    hw = detect_hardware()
    console.print(f"   CPU:  [cyan]{hw.cpu_name[:50]}[/cyan]")
    console.print(f"   RAM:  [cyan]{hw.ram_gb:.0f}GB[/cyan]")
    if hw.gpu_name:
        console.print(f"   GPU:  [cyan]{hw.gpu_name}[/cyan]")
    console.print()

    client = OllamaClient()
    ollama_running = asyncio.run(client.is_running())
    worker_model = None

    if ollama_running:
        console.print("✓ [green]Ollama is running[/green]")
        installed = asyncio.run(client.list_models())
        recommended = hw.recommended_model
        already = any(recommended.split(":")[0] in m for m in installed)

        if already:
            console.print(f"✓ [green]Model ready:[/green] {recommended}")
            worker_model = recommended
        else:
            console.print(f"   Recommended: [cyan]{recommended}[/cyan] ({hw.recommended_model_size})")
            pull = yes or typer.confirm(f"   Pull {recommended} now?", default=True)
            if pull:
                console.print(f"   Pulling {recommended}...")
                if asyncio.run(client.pull_model(recommended)):
                    console.print(f"   ✓ [green]{recommended} ready[/green]")
                    worker_model = recommended
    else:
        console.print("✗ [yellow]Ollama not running[/yellow]")
        console.print(f"   Install: [dim]{get_install_instructions(hw.platform)}[/dim]")

    console.print()
    config_path = init_config(repo_path, worker_model=worker_model)
    console.print(f"✓ Config: [dim]{config_path}[/dim]")
    console.print()

    if worker_model:
        console.print("[bold green]Ready![/bold green] Local model active.")
        console.print(f"   Worker:  [cyan]{worker_model}[/cyan] (free, local)")
    else:
        console.print("[bold]Ready![/bold] Cloud routing active.")

    console.print()
    console.print('Run [bold cyan]localfirst prep "your task"[/bold cyan] to get started.')


@app.command()
def prep(
    task: Annotated[str, typer.Argument()],
    repo: Annotated[Optional[Path], typer.Option("--repo", "-r")] = None,
    context: Annotated[Optional[str], typer.Option("--context", "-c")] = None,
    output: Annotated[str, typer.Option("--output", "-o")] = "compact",
    verbose: Annotated[bool, typer.Option("--verbose", "-v")] = False,
) -> None:
    """Prepare context for a task and route to the right model."""
    _setup_logging(verbose)
    repo_path = (repo or Path.cwd()).resolve()

    from localfirst.config import load_config
    from localfirst.router import Router
    from localfirst.token_counter import TokenCounter, RunStats, calculate_savings

    config = load_config(repo_root=repo_path)
    router = Router(config)
    start = time.monotonic()

    try:
        from lao.core.runner import run_prep
        from lao.models import TaskInput
        task_input = TaskInput(task=task, repo_path=repo_path)
        if context:
            task_input.extra_context = context
        pack, report, _, _ = run_prep(task_input, silent=True)
        context_tokens = pack.optimized_token_estimate
        repo_total = getattr(report, 'repo_total_tokens', 0)
    except Exception as e:
        import subprocess
        args = ["lao", "prep", task, "--repo", str(repo_path), "--output", output]
        subprocess.run(args)
        return

    duration_ms = (time.monotonic() - start) * 1000
    decision = router.route(task, context_tokens=context_tokens)

    from lao.output.compact import render_compact
    console.print()
    console.print(render_compact(pack, report))
    console.print()
    console.print(f"  → [bold]{decision.display}[/bold]")
    if decision.is_local:
        console.print(f"  → [bold green]Cost: $0.00 (local)[/bold green]")
    console.print()

    if decision.layer.value == "worker" and config.get("worker", {}).get("enabled"):
        _run_worker(task, pack, config)

    savings = calculate_savings(context_tokens, repo_total, decision.model)
    counter = TokenCounter(repo_path)
    counter.record(RunStats(
        run_id=str(uuid.uuid4())[:8],
        task=task[:200],
        timestamp=datetime.now(timezone.utc).isoformat(),
        routing_layer=decision.layer.value,
        model=decision.model,
        tokens_local=context_tokens if decision.is_local else 0,
        tokens_cloud=0 if decision.is_local else context_tokens,
        tokens_repo_total=repo_total,
        cost_usd=decision.estimated_cost_usd,
        cost_saved_usd=savings,
        duration_ms=duration_ms,
    ))


def _run_worker(task: str, pack, config: dict) -> None:
    """Run task via local Ollama model."""
    import httpx
    model = config["worker"]["model"]
    ollama_url = config["worker"].get("ollama_url", "http://localhost:11434")

    context_text = ""
    for sf in pack.selected_files[:5]:
        try:
            text = sf.file.path.read_text(encoding="utf-8", errors="ignore")[:2000]
            context_text += f"\n--- {sf.file.relative_path} ---\n{text}\n"
        except Exception:
            pass

    messages = [{"role": "user", "content": f"{task}\n\nContext:\n{context_text}"}]
    console.print(f"[dim]Running on {model} locally...[/dim]")

    try:
        with httpx.Client(timeout=120) as client:
            r = client.post(
                f"{ollama_url}/api/chat",
                json={"model": model, "messages": messages, "stream": False,
                      "options": {"temperature": 0.1, "num_predict": 2000}},
            )
            response = r.json().get("message", {}).get("content", "")
    except Exception as e:
        console.print(f"[yellow]Worker error: {e}[/yellow]")
        return

    if response:
        console.print()
        console.rule(f"[bold green]Worker Response ({model})[/bold green]")
        console.print(response)
        console.print()


@app.command()
def route(
    task: Annotated[str, typer.Argument()],
    repo: Annotated[Optional[Path], typer.Option("--repo", "-r")] = None,
    verbose: Annotated[bool, typer.Option("--verbose", "-v")] = False,
) -> None:
    """Show routing decision for a task."""
    _setup_logging(verbose)
    from localfirst.config import load_config
    from localfirst.router import Router

    config = load_config(repo_root=(repo or Path.cwd()).resolve())
    router = Router(config)
    decision = router.route(task)

    console.print()
    console.rule("[bold]Routing Decision[/bold]")
    console.print(f"  Task:   [dim]{task}[/dim]")
    console.print(f"  Layer:  [bold]{decision.layer.value}[/bold]")
    console.print(f"  Model:  [cyan]{decision.model}[/cyan]")
    console.print(f"  Reason: [dim]{decision.reason}[/dim]")
    if decision.is_local:
        console.print(f"  Cost:   [bold green]$0.00 (local)[/bold green]")
    else:
        console.print(f"  Cost:   ~${decision.estimated_cost_usd:.4f} per task")
    console.print()


@app.command()
def stats(
    repo: Annotated[Optional[Path], typer.Option("--repo", "-r")] = None,
    days: Annotated[int, typer.Option("--days", "-d")] = 7,
) -> None:
    """Show token usage and cost savings."""
    from localfirst.token_counter import TokenCounter
    counter = TokenCounter((repo or Path.cwd()).resolve())
    s = counter.weekly_summary(days=days)
    if s.runs == 0:
        console.print("[dim]No runs yet. Run 'localfirst prep' first.[/dim]")
        return
    console.print()
    console.rule(f"[bold]Last {days} Days[/bold]")
    console.print(f"  Tasks:        [cyan]{s.runs}[/cyan]")
    console.print(f"  Local:        [bold green]{s.local_pct:.0f}%[/bold green]")
    console.print(f"  Cost saved:   [bold green]${s.cost_saved_usd:.2f}[/bold green]")
    console.print()


@app.command()
def check(verbose: Annotated[bool, typer.Option("--verbose", "-v")] = False) -> None:
    """Check tool availability."""
    from localfirst.hardware import detect_hardware
    from localfirst.ollama import OllamaClient
    import shutil

    hw = detect_hardware()
    console.print(f"\n[bold]LocalFirst[/bold] v{VERSION}\n")
    console.print(f"  RAM: [cyan]{hw.ram_gb:.0f}GB[/cyan]  CPU: [dim]{hw.cpu_name[:50]}[/dim]")
    console.print()
    for binary, name in [("rg", "ripgrep"), ("gitleaks", "gitleaks"), ("ollama", "Ollama")]:
        icon = "✓" if shutil.which(binary) else "✗"
        color = "green" if shutil.which(binary) else "yellow"
        console.print(f"  {icon} [{color}]{name}[/{color}]")

    client = OllamaClient()
    if asyncio.run(client.is_running()):
        models = asyncio.run(client.list_models())
        console.print()
        for m in models:
            console.print(f"  ✓ [green]{m}[/green]")
    console.print()



@app.command()
def inspect(
    port: Annotated[int, typer.Option("--port", "-p")] = 8081,
    mode: Annotated[str, typer.Option("--mode", "-m", help="log|block_secrets")] = "log",
    log: Annotated[Optional[str], typer.Option("--log", "-l")] = None,
) -> None:
    """Start LocalFirst Inspector — zeigt was Claude Code mit deinem Code macht."""
    from localfirst.inspector.proxy import run_inspector
    run_inspector(port=port, mode=mode, log_file=log)

@app.command()
def version() -> None:
    """Show version."""
    console.print(f"localfirst v{VERSION}")


# MCP subcommands
mcp_app = typer.Typer(help="MCP server commands.")
app.add_typer(mcp_app, name="mcp")


@mcp_app.command("start")
def mcp_start(
    http: Annotated[bool, typer.Option("--http")] = False,
    port: Annotated[int, typer.Option("--port")] = 8765,
) -> None:
    """Start MCP server."""
    from localfirst.mcp.server import run_stdio, run_http
    if http:
        run_http(port)
    else:
        run_stdio()


@mcp_app.command("config")
def mcp_config() -> None:
    """Show MCP configuration snippet for Claude Code / Cursor."""
    import json, sys, shutil
    from pathlib import Path

    exe_dir = Path(sys.executable).parent
    candidates = [exe_dir / "localfirst.exe", exe_dir / "localfirst"]
    exe = next((str(p) for p in candidates if p.exists()), shutil.which("localfirst") or "localfirst")

    config = {"mcpServers": {"localfirst": {"command": exe, "args": ["mcp", "start"]}}}

    console.print()
    console.print("[bold]Claude Code (.claude/settings.json):[/bold]")
    console.print(json.dumps(config, indent=2))
    console.print()
    console.print("[bold]Claude Code CLI:[/bold]")
    console.print(f'  [cyan]claude mcp add localfirst "{exe}" mcp start --scope user[/cyan]')
    console.print()
    console.print("[bold]Cursor (.cursor/mcp.json):[/bold]")
    console.print(json.dumps(config, indent=2))
    console.print()
    console.print(f"[dim]stdio: {exe} mcp start[/dim]")


if __name__ == "__main__":
    app()
