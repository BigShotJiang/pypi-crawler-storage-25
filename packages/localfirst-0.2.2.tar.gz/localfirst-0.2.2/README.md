# LocalFirst

> **Your hardware runs first. Cloud is the exception, not the rule.**

Built on [LAO](https://github.com/SynthexCapital/lao).

## Quick Start

```bash
pip install localfirst
localfirst init
localfirst prep "fix failing auth test"
```

## License
MIT
