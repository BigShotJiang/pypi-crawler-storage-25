"""Knowledge graph — SPO triples + wiki-link extraction from vault files.

Two separate graphs:
1. Wiki-link graph (undirected): [[entities]] parsed from markdown files.
   Captures co-occurrence — "these things are mentioned together."
2. SPO graph (directed): structured subject-predicate-object facts with
   authority, epistemic status, decay. Captures meaning — "this relates to that how."

Both use the unified EntityRegistry as the canonical entity source.
Triples are validated against the Ontology schema at insertion time.
Contradiction detection prevents conflicting single-cardinality facts.
"""

from __future__ import annotations

import json
import logging
import re
from datetime import UTC, datetime, timedelta
from typing import TYPE_CHECKING, Any

import networkx as nx

from agntspace.memory.entity_registry import EntityRegistry
from agntspace.memory.ontology import (
    AUTHORITY_WEIGHTS,
    EntityType,
    EpistemicStatus,
    build_extraction_prompt,
    get_inferences,
    get_knowledge_type,
    is_single_cardinality,
    load_ontology,
    resolve_entity_type,
    validate_triple,
)

if TYPE_CHECKING:
    from agntspace.llm.base import LLMProvider
    from agntspace.vault.reader import VaultReader
    from agntspace.vault.writer import VaultWriter

log = logging.getLogger(__name__)

WIKI_LINK_PATTERN = re.compile(r"\[\[([^\]|]+)(?:\|[^\]]+)?\]\]")

# Artifact wikilinks that aren't real entities — filtered from graph
_LINK_BLOCKLIST = frozenset({
    "sources", "links", "backlinks", "link", "source", "references",
    "todo", "note", "see also", "index", "catalog", "contents",
    "open questions", "counter-arguments", "data gaps",
})

# AUTHORITY_WEIGHTS is imported from ontology (backwards compat)

_TRIPLES_PATH = "agnt-memory/graph/triples.json"

# Knowledge-type-aware half-lives for temporal decay (in days).
# Episodic facts (events) fade fast; normative (preferences) persist.
_KNOWLEDGE_TYPE_HALF_LIVES: dict[str, int] = {
    "episodic": 30,       # Events fade quickly
    "declarative": 90,    # Facts persist moderately
    "procedural": 180,    # Skills and how-to knowledge persist
    "normative": 365,     # Preferences and rules persist long
    "intentional": 120,   # Goals and plans have medium life
}


def _build_triple_extract_prompt() -> str:
    """Build the triple extraction prompt dynamically from the loaded ontology."""
    vocab = build_extraction_prompt()
    return f"""You are a knowledge graph extraction engine. Extract structured facts as subject-predicate-object triples from the text below.

Return a JSON array of triples. Each triple:
```json
[
  {{
    "subject": "entity name (person, company, project, concept)",
    "subject_type": "person|organization|project|concept|place|event|task|goal|decision|document",
    "predicate": "relationship verb",
    "object": "entity name or literal value",
    "object_type": "person|organization|project|concept|place|event|task|goal|decision|document|literal",
    "confidence": 0.9,
    "knowledge_type": "declarative|episodic|procedural|normative|intentional"
  }}
]
```

{vocab}

Knowledge types:
- declarative: facts ("Sarah works at Acme")
- episodic: events ("Met Sarah on April 5")
- procedural: how-to ("To deploy, run make deploy")
- normative: preferences/rules ("We prefer PostgreSQL")
- intentional: goals/plans ("Launch by Q3")

Confidence scale:
- 1.0 = explicitly stated fact
- 0.7-0.9 = strongly implied
- 0.5-0.7 = inferred from context

Rules:
- Extract ONLY facts present in the text. Never invent.
- Prefer specific predicates over generic "related_to".
- Use full entity names ("Sarah Chen" not "Sarah").
- For literal values (dates, statuses), set object_type to "literal".
- Maximum 30 triples per extraction.
- Return ONLY the JSON array, no other text."""


def _now_iso() -> str:
    return datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%SZ")


def _today_iso() -> str:
    return datetime.now(UTC).strftime("%Y-%m-%d")


class KnowledgeGraph:
    """Builds and queries a knowledge graph from wiki-links and SPO triples.

    Uses:
    - EntityRegistry for all entity operations (single source of truth)
    - Ontology for predicate validation and schema enforcement
    - Two separate NetworkX graphs: wiki-links (undirected) and SPO (directed)
    """

    def __init__(
        self,
        vault: VaultReader,
        writer: VaultWriter | None = None,
        llm: LLMProvider | None = None,
        entity_registry: EntityRegistry | None = None,
    ) -> None:
        self._vault = vault
        self._writer = writer
        self._llm = llm
        self._agent: object | None = None  # injected post-hoc from main.py

        # Entity registry (shared, canonical)
        if entity_registry:
            self._registry = entity_registry
        else:
            self._registry = EntityRegistry(vault=vault, writer=writer)

        # Wiki-link graph: undirected, co-occurrence
        self._wikilink_graph = nx.Graph()
        # SPO graph: directed, semantic relationships
        self._spo_graph = nx.DiGraph()
        # Combined view for backwards-compat queries
        self._graph = nx.Graph()

        self._node_sources: dict[str, set[str]] = {}

        # Cross-reference indexes (built during build())
        self._article_triples: dict[str, list[int]] = {}  # article path -> triple IDs
        self._article_entities: dict[str, set[str]] = {}  # article path -> entity slugs

        # SPO triples (loaded from JSON, kept in memory)
        self._triples: list[dict] = []
        self._next_triple_id: int = 1
        self._triples_dirty = False

        # Dedup index: (subject_slug, predicate, object_slug_or_literal) -> triple index
        # Turns O(n) dedup scan into O(1) lookup.
        self._dedup_index: dict[tuple, int] = {}

        # Fix #7: Extraction quality metrics — tracks LLM extraction health
        self._extraction_metrics: dict[str, Any] = {
            "total_extractions": 0,
            "total_triples_extracted": 0,
            "failed_extractions": 0,   # LLM returned invalid JSON or empty
            "empty_extractions": 0,    # LLM returned 0 triples from non-empty text
            "hallucinated_entities": 0, # Entities not found in source text
            "predicate_distribution": {},  # predicate -> count
            "knowledge_type_distribution": {},  # kt -> count
        }

    @property
    def registry(self) -> EntityRegistry:
        """Access the entity registry."""
        return self._registry

    # ── Backwards-compat properties ──

    @property
    def _entities(self) -> dict[str, dict]:
        """Backwards compat: delegate to registry."""
        return self._registry.entities

    @property
    def _dirty(self) -> bool:
        """Dirty if either triples or entities have unsaved changes."""
        return self._triples_dirty or self._registry.dirty

    @_dirty.setter
    def _dirty(self, value: bool) -> None:
        self._triples_dirty = value
        if not value:
            self._registry.dirty = False

    # ── File persistence ──

    def _load_graph_data(self) -> None:
        """Load entities, triples, and ontology from vault files."""
        # Load ontology from skills config (or fallback to defaults)
        skills_dir = self._vault.vault_dir / "agnt-system" / "skills"
        load_ontology(str(skills_dir) if skills_dir.exists() else None)

        self._registry.load()

        # Load triples
        if self._vault.exists(_TRIPLES_PATH):
            try:
                path = self._vault.vault_dir / _TRIPLES_PATH
                raw = path.read_text(encoding="utf-8")
                self._triples = json.loads(raw)
                if self._triples:
                    self._next_triple_id = max(t.get("id", 0) for t in self._triples) + 1
                # Migrate: add fields if missing from older data
                for t in self._triples:
                    if "epistemic_status" not in t:
                        t["epistemic_status"] = EpistemicStatus.BELIEVED.value
                    if "knowledge_type" not in t:
                        t["knowledge_type"] = get_knowledge_type(t.get("predicate", "")).value
                    # Epistemic fix: last_verified tracks when fact was confirmed true
                    # (distinct from last_accessed which tracks when it was read)
                    if "last_verified" not in t:
                        if t.get("epistemic_status") == "verified" or t.get("authority") == "explicit":
                            t["last_verified"] = t.get("source_date") or t.get("first_seen")
                            if not t["last_verified"]:
                                log.warning("Triple #%d marked verified but has no provenance date", t.get("id", "?"))
                        else:
                            t["last_verified"] = None
                    # Invariant: verified facts must have last_verified set
                    if t.get("epistemic_status") == "verified" and not t.get("last_verified"):
                        t["last_verified"] = t.get("source_date") or t.get("first_seen") or _now_iso()
                        log.warning("Triple #%d: verified but last_verified was None, auto-set", t.get("id", "?"))
                    # Epistemic fix: justified_by tracks inference dependencies
                    if "justified_by" not in t:
                        t["justified_by"] = []
                # Build dedup index from loaded triples
                self._dedup_index.clear()
                for idx, t in enumerate(self._triples):
                    if t["status"] == "active":
                        key = (t["subject"], t["predicate"], t.get("object") or t.get("object_literal"))
                        self._dedup_index[key] = idx

                log.debug("Loaded %d triples from graph", len(self._triples))
            except Exception as e:
                log.warning("Failed to load triples.json: %s", e)
                self._triples = []

    def save(self) -> None:
        """Persist current graph state to vault JSON files."""
        if not self._writer:
            return

        # Save entities via registry
        self._registry.save()

        # Save triples
        if self._triples_dirty:
            triples_json = json.dumps(self._triples, separators=(",", ":"), ensure_ascii=False)
            self._writer.write(_TRIPLES_PATH, triples_json)
            self._triples_dirty = False
            log.info("Graph saved: %d entities, %d triples",
                     len(self._registry.entities), len(self._triples))

    # ── Entity management (delegated to registry) ──

    def add_entity(
        self,
        name: str,
        entity_type: str = "concept",
        authority: str = "inferred",
        aliases: list[str] | None = None,
        decay_condition: str = "when:unaccessed:90d",
    ) -> str:
        """Add or update an entity via the registry. Returns slug."""
        return self._registry.add(
            name=name,
            entity_type=entity_type,
            authority=authority,
            aliases=aliases,
            decay_condition=decay_condition,
        )

    def _resolve_entity(self, name: str) -> str | None:
        """Resolve entity name to slug via registry."""
        return self._registry.resolve(name)

    def _entity_name(self, slug: str | None) -> str:
        """Get display name for a slug."""
        return self._registry.get_name(slug)

    # ── Triple management ──

    def add_triple(
        self,
        subject: str,
        predicate: str,
        obj: str,
        authority: str = "inferred",
        source_file: str = "",
        source_date: str = "",
        confidence: float = 0.8,
        decay_condition: str = "when:superseded",
        subject_type: str = "concept",
        object_type: str = "concept",
        epistemic_status: str = "believed",
        knowledge_type: str | None = None,
        valid_from: str | None = None,
        valid_until: str | None = None,
    ) -> int:
        """Add a triple with ontology validation and contradiction detection.

        Returns the triple ID. Logs warnings for schema violations but still
        stores the triple (permissive — we don't want to lose data).
        """
        now = _now_iso()
        is_literal = object_type == "literal"

        # Resolve types via ontology
        subj_etype = resolve_entity_type(subject_type)
        obj_etype = resolve_entity_type(object_type) if not is_literal else None

        # Validate against ontology
        validation = validate_triple(predicate, subj_etype, obj_etype, is_literal)
        if validation.warnings:
            for w in validation.warnings:
                log.debug("Ontology warning: %s", w)
        # Use normalized predicate (maps unknown predicates to related_to)
        effective_predicate = validation.normalized_predicate or predicate

        # Determine knowledge type
        if knowledge_type:
            kt = knowledge_type
        else:
            kt = get_knowledge_type(effective_predicate).value

        # Resolve or create entities via registry
        subj_slug = self._registry.add(
            subject, entity_type=subj_etype, authority=authority,
        )

        obj_slug = None
        if not is_literal:
            obj_slug = self._registry.add(
                obj, entity_type=obj_etype or EntityType.THING, authority=authority,
            )

        # Dedup: same subject + predicate + object -> update (O(1) via index)
        dedup_key = (subj_slug, effective_predicate, obj_slug if obj_slug else obj)
        dedup_idx = self._dedup_index.get(dedup_key)
        triple = self._triples[dedup_idx] if dedup_idx is not None and dedup_idx < len(self._triples) else None
        if triple and triple["status"] == "active":
            if True:  # preserves original indentation block
                # Update existing — re-encountering a fact is a verification event
                auth_rank = {"inferred": 0, "system": 1, "explicit": 2}
                authority_upgraded = auth_rank.get(authority, 0) > auth_rank.get(triple.get("authority", "inferred"), 0)
                if authority_upgraded:
                    triple["authority"] = authority
                if confidence > triple.get("confidence", 0):
                    triple["confidence"] = confidence
                # Track re-encounters separately from query access.
                # Dedup should NOT bump last_accessed — that defeats unaccessed decay.
                # A fact re-mentioned in passing is not the same as a fact actively queried.
                # last_accessed is only set by query_entity() and similar read paths.
                triple["last_encountered"] = now
                triple["encounter_count"] = triple.get("encounter_count", 0) + 1
                if source_file and source_file not in triple.get("source_files", []):
                    triple.setdefault("source_files", []).append(source_file)
                # Re-encountering a fact from an independent source is evidence:
                # mark as re-verified (authority upgrade or new source = corroboration)
                if authority_upgraded or authority == "explicit" or epistemic_status == "verified":
                    triple["last_verified"] = now
                # Upgrade epistemic status
                self._upgrade_epistemic(triple, epistemic_status)
                self._dirty = True
                return triple["id"]

        # Contradiction detection for single-cardinality predicates
        contradiction = self._detect_contradiction(
            subj_slug, effective_predicate, obj_slug, obj if is_literal else None,
            authority, confidence,
        )

        # Cascade: if a triple was superseded, propagate to related triples
        if contradiction:
            cascade_result = self.propagate_change(contradiction["id"])
            if cascade_result.get("cascaded", 0):
                log.info(
                    "Contradiction cascade: %d triples affected by supersession of #%d",
                    cascade_result["cascaded"], contradiction["id"],
                )

        # New triple
        triple_id = self._next_triple_id
        self._next_triple_id += 1

        triple: dict[str, Any] = {
            "id": triple_id,
            "subject": subj_slug,
            "predicate": effective_predicate,
            "authority": authority,
            "confidence": confidence,
            "epistemic_status": epistemic_status,
            "knowledge_type": kt,
            "source_files": [source_file] if source_file else [],
            "source_date": source_date or _today_iso(),
            "decay_condition": decay_condition,
            "last_accessed": now,
            "last_verified": now if epistemic_status == "verified" or authority == "explicit" else None,
            "justified_by": [],
            "access_count": 0,
            "status": "active",
            "valid_from": valid_from or source_date or _today_iso(),
            "valid_until": valid_until,
        }
        if is_literal:
            triple["object_literal"] = obj
            triple["object"] = None
        else:
            triple["object"] = obj_slug
            triple["object_literal"] = None

        if contradiction:
            triple["supersedes"] = contradiction["id"]

        self._triples.append(triple)
        self._dedup_index[dedup_key] = len(self._triples) - 1
        self._dirty = True

        # Add edge to SPO graph
        if obj_slug:
            subj_name = self._registry.get_name(subj_slug)
            obj_name = self._registry.get_name(obj_slug)
            weight = AUTHORITY_WEIGHTS.get(authority, 1.0) * confidence
            if self._spo_graph.has_edge(subj_name, obj_name):
                existing = self._spo_graph[subj_name][obj_name]
                existing["weight"] = existing.get("weight", 1.0) + weight
                relations = existing.get("relations", [])
                if effective_predicate not in relations:
                    relations.append(effective_predicate)
                    existing["relations"] = relations
            else:
                self._spo_graph.add_edge(
                    subj_name, obj_name,
                    relation=effective_predicate, relations=[effective_predicate],
                    weight=weight, source="spo",
                )
            # Also add to combined graph for backwards compat
            if not self._graph.has_edge(subj_name, obj_name):
                self._graph.add_edge(
                    subj_name, obj_name,
                    relation=effective_predicate, relations=[effective_predicate],
                    weight=weight, source="spo",
                )
            else:
                existing = self._graph[subj_name][obj_name]
                existing["weight"] = existing.get("weight", 1.0) + weight
                relations = existing.get("relations", [])
                if effective_predicate not in relations:
                    relations.append(effective_predicate)
                    existing["relations"] = relations

        # Run inference rules (e.g., collaborates_with → knows)
        if not is_literal and obj_slug:
            self._run_inference(
                subject=subject, predicate=effective_predicate, obj=obj,
                subj_slug=subj_slug, obj_slug=obj_slug,
                subject_type=subject_type, object_type=object_type,
                source_file=source_file, source_date=source_date,
            )

        return triple_id

    def _run_inference(
        self,
        subject: str,
        predicate: str,
        obj: str,
        subj_slug: str,
        obj_slug: str,
        subject_type: str,
        object_type: str,
        source_file: str,
        source_date: str,
    ) -> None:
        """Execute inference rules for a newly added triple.

        Inferred triples get authority=inferred, epistemic_status=believed,
        and justified_by pointing to the source triple that triggered the inference.
        This creates a proper justification chain for epistemic cascading.
        """
        # Find the source triple ID (the one we just added that triggered inference)
        source_triple_id = None
        for t in reversed(self._triples):
            if (t["subject"] == subj_slug and t["predicate"] == predicate
                    and t["status"] == "active"):
                source_triple_id = t["id"]
                break

        rules = get_inferences(predicate)
        for rule in rules:
            if rule.swap:
                inf_subject, inf_obj = obj, subject
                inf_subj_type, inf_obj_type = object_type, subject_type
            else:
                inf_subject, inf_obj = subject, obj
                inf_subj_type, inf_obj_type = subject_type, object_type

            # add_triple handles dedup — if this inference already exists, it's a no-op
            inferred_id = self.add_triple(
                subject=inf_subject,
                predicate=rule.then_predicate,
                obj=inf_obj,
                authority="inferred",
                source_file=source_file,
                source_date=source_date,
                confidence=0.9,
                subject_type=inf_subj_type,
                object_type=inf_obj_type,
                epistemic_status="believed",
            )

            # Record justification dependency: inferred triple depends on source triple
            if source_triple_id:
                for t in self._triples:
                    if t["id"] == inferred_id:
                        justified_by = t.get("justified_by", [])
                        if source_triple_id not in justified_by:
                            justified_by.append(source_triple_id)
                            t["justified_by"] = justified_by
                        break

    def _detect_contradiction(
        self,
        subj_slug: str,
        predicate: str,
        obj_slug: str | None,
        obj_literal: str | None,
        new_authority: str,
        new_confidence: float,
    ) -> dict | None:
        """Detect if a new triple contradicts an existing single-cardinality fact.

        For single-cardinality predicates (e.g., works_at), if a different object
        exists for the same subject, the old triple is superseded.

        Returns the superseded triple dict, or None.
        """
        if not is_single_cardinality(predicate):
            return None

        for t in self._triples:
            if t["status"] != "active":
                continue
            if t["subject"] != subj_slug or t["predicate"] != predicate:
                continue

            # Same subject + predicate, check if different object
            existing_obj = t.get("object") or t.get("object_literal")
            new_obj = obj_slug or obj_literal

            if existing_obj == new_obj:
                continue  # same fact, not a contradiction

            # Contradiction found
            subj_name = self._registry.get_name(subj_slug)
            existing_obj_name = self._registry.get_name(t.get("object")) if t.get("object") else t.get("object_literal", "?")
            new_obj_name = self._registry.get_name(obj_slug) if obj_slug else (obj_literal or "?")

            log.info(
                "Contradiction detected: %s %s %s (existing) vs %s (new). "
                "Superseding old triple #%d.",
                subj_name, predicate, existing_obj_name, new_obj_name, t["id"],
            )

            # Supersede the old triple
            t["status"] = "superseded"
            t["superseded_by"] = self._next_triple_id
            t["valid_until"] = _now_iso()
            t["epistemic_status"] = EpistemicStatus.SUPERSEDED.value
            t["superseded_at"] = _now_iso()

            return t

        return None

    @staticmethod
    def _upgrade_epistemic(triple: dict, new_status: str) -> None:
        """Upgrade epistemic status if the new one is stronger."""
        rank = {
            "retracted": 0, "superseded": 1, "contested": 2,
            "uncertain": 3, "believed": 4, "verified": 5,
        }
        current = triple.get("epistemic_status", "believed")
        if rank.get(new_status, 0) > rank.get(current, 0):
            triple["epistemic_status"] = new_status

    # ── Querying ──

    # Minimum effective_weight for a triple to appear in query results.
    # Facts below this threshold have decayed too far to be useful context.
    _MIN_QUERY_WEIGHT = 0.05

    def query_entity(self, entity: str, depth: int = 2) -> dict | None:
        """Query everything known about an entity.

        Returns structured result with entity data, triples grouped by predicate,
        connected entities, and epistemic metadata.

        Fix #4: Results are filtered by effective_weight (excludes near-zero facts)
        and sorted by weight within each predicate group so the agent sees the
        most reliable facts first.
        """
        slug = self._registry.resolve(entity)
        if not slug:
            return None

        ent = self._registry.entities[slug]
        self._registry.bump_access(slug)

        # Collect triples where this entity is subject or object
        triples_as_subject: dict[str, list[dict]] = {}
        triples_as_object: dict[str, list[dict]] = {}

        for t in self._triples:
            if t["status"] not in ("active", "contested"):
                continue
            # Filter out triples with negligible effective weight
            ew = t.get("effective_weight")
            if ew is not None and ew < self._MIN_QUERY_WEIGHT:
                continue
            if t["subject"] == slug:
                pred = t["predicate"]
                obj_display = self._registry.get_name(t["object"]) if t["object"] else t.get("object_literal", "?")
                triples_as_subject.setdefault(pred, []).append({
                    "value": obj_display,
                    "confidence": t["confidence"],
                    "authority": t["authority"],
                    "epistemic_status": t.get("epistemic_status", "believed"),
                    "knowledge_type": t.get("knowledge_type", "declarative"),
                    "source_date": t.get("source_date", ""),
                    "effective_weight": ew,
                })
                t["last_accessed"] = _now_iso()
                t["access_count"] = t.get("access_count", 0) + 1
            elif t.get("object") == slug:
                pred = t["predicate"]
                subj_display = self._registry.get_name(t["subject"])
                triples_as_object.setdefault(pred, []).append({
                    "value": subj_display,
                    "confidence": t["confidence"],
                    "authority": t["authority"],
                    "epistemic_status": t.get("epistemic_status", "believed"),
                    "knowledge_type": t.get("knowledge_type", "declarative"),
                    "source_date": t.get("source_date", ""),
                    "effective_weight": ew,
                })
                t["last_accessed"] = _now_iso()
                t["access_count"] = t.get("access_count", 0) + 1

        # Sort each predicate group by effective_weight descending
        for pred_triples in triples_as_subject.values():
            pred_triples.sort(key=lambda x: x.get("effective_weight") or 0, reverse=True)
        for pred_triples in triples_as_object.values():
            pred_triples.sort(key=lambda x: x.get("effective_weight") or 0, reverse=True)

        # Get graph connections (combined graph for broader reach)
        connected = self.get_connected(ent["canonical_name"], depth=depth)

        return {
            "entity": {
                "slug": slug,
                "name": ent["canonical_name"],
                "type": ent.get("entity_type", "thing"),
                "authority": ent.get("authority", "inferred"),
                "first_seen": ent.get("first_seen", ""),
                "access_count": ent.get("access_count", 0),
            },
            "facts": triples_as_subject,
            "referenced_by": triples_as_object,
            "connected": connected,
        }

    def query_path(self, entity_a: str, entity_b: str) -> list[dict] | None:
        """Find shortest path between two entities using SPO graph only.

        Unlike the old implementation, this uses the directed SPO graph,
        so paths are semantically meaningful (not just co-mentions).
        Falls back to combined graph if no SPO path exists.
        """
        slug_a = self._registry.resolve(entity_a)
        slug_b = self._registry.resolve(entity_b)
        if not slug_a or not slug_b:
            return None

        name_a = self._registry.get_name(slug_a)
        name_b = self._registry.get_name(slug_b)

        # Try SPO graph first (semantically meaningful paths)
        path = None
        try:
            # Treat as undirected for path finding (relationships work both ways)
            path = nx.shortest_path(self._spo_graph.to_undirected(), name_a, name_b)
        except (nx.NetworkXError, nx.NodeNotFound):
            pass

        # Fallback to combined graph
        if not path:
            try:
                path = nx.shortest_path(self._graph, name_a, name_b)
            except (nx.NetworkXError, nx.NodeNotFound):
                return None

        # Build path with supporting triples
        result = []
        for i in range(len(path) - 1):
            from_node = path[i]
            to_node = path[i + 1]

            from_slug = self._registry.resolve(from_node)
            to_slug = self._registry.resolve(to_node)
            supporting = []
            if from_slug and to_slug:
                for t in self._triples:
                    if t["status"] != "active":
                        continue
                    if ((t["subject"] == from_slug and t.get("object") == to_slug)
                            or (t["subject"] == to_slug and t.get("object") == from_slug)):
                        supporting.append({
                            "predicate": t["predicate"],
                            "confidence": t["confidence"],
                            "authority": t["authority"],
                            "epistemic_status": t.get("epistemic_status", "believed"),
                        })

            # Determine edge type
            edge_data = {}
            if self._spo_graph.has_edge(from_node, to_node):
                edge_data = dict(self._spo_graph[from_node][to_node])
            elif self._spo_graph.has_edge(to_node, from_node):
                edge_data = dict(self._spo_graph[to_node][from_node])
            elif self._graph.has_edge(from_node, to_node):
                edge_data = dict(self._graph[from_node][to_node])

            relations = edge_data.get("relations", [edge_data.get("relation", "connected")])

            result.append({
                "from": from_node,
                "to": to_node,
                "relations": relations,
                "triples": supporting,
                "semantic": bool(supporting),  # True if backed by SPO triples
            })

        return result

    def get_contradictions(self) -> list[dict]:
        """Find all contradictions in the graph.

        Returns pairs of triples that conflict (same subject + single-cardinality
        predicate, different objects, both active/contested).
        """
        contradictions = []
        seen = set()

        for t in self._triples:
            if t["status"] not in ("active", "contested"):
                continue
            if not is_single_cardinality(t["predicate"]):
                continue

            key = (t["subject"], t["predicate"])
            if key in seen:
                continue

            # Find all active triples with same subject+predicate
            matching = [
                other for other in self._triples
                if other["status"] in ("active", "contested")
                and other["subject"] == t["subject"]
                and other["predicate"] == t["predicate"]
                and other["id"] != t["id"]
            ]

            if matching:
                seen.add(key)
                subj_name = self._registry.get_name(t["subject"])
                for other in matching:
                    contradictions.append({
                        "subject": subj_name,
                        "predicate": t["predicate"],
                        "triple_a": {
                            "id": t["id"],
                            "object": self._registry.get_name(t.get("object")) or t.get("object_literal"),
                            "authority": t["authority"],
                            "confidence": t["confidence"],
                            "source_date": t.get("source_date"),
                        },
                        "triple_b": {
                            "id": other["id"],
                            "object": self._registry.get_name(other.get("object")) or other.get("object_literal"),
                            "authority": other["authority"],
                            "confidence": other["confidence"],
                            "source_date": other.get("source_date"),
                        },
                    })

        return contradictions

    # ── LLM triple extraction ──

    async def extract_triples_llm(
        self,
        text: str,
        source_file: str = "",
        source_date: str = "",
        authority: str = "system",
    ) -> list[dict]:
        """Extract structured triples from text via the main agent."""
        if not self._agent and not self._llm:
            return []

        vocab = build_extraction_prompt()
        task_instruction = (
            "Extract structured knowledge triples from the text below as a JSON array.\n"
            "Each triple: {subject, subject_type, predicate, object, object_type, confidence, knowledge_type}.\n"
            f"{vocab}\n"
            "Rules: only facts present in text, prefer specific predicates, full entity names, max 30 triples.\n"
            "Return ONLY the JSON array, no other text."
        )

        try:
            if self._agent:
                raw_response = await self._agent.process_task(task=task_instruction, context=text)
            else:
                from agntspace.llm.base import Message
                response = await self._llm.complete(
                    messages=[Message(role="user", content=text)],
                    system=_build_triple_extract_prompt(),
                    max_tokens=2048,
                    temperature=0.2,
                )
                raw_response = response.content
        except Exception as e:
            log.warning("Triple extraction failed: %s", e)
            return []

        self._extraction_metrics["total_extractions"] += 1

        raw = raw_response.strip()
        if raw.startswith("```"):
            lines = raw.split("\n")
            raw = "\n".join(lines[1:])
            if raw.endswith("```"):
                raw = raw[:-3]
            raw = raw.strip()

        try:
            triples_data = json.loads(raw)
        except json.JSONDecodeError:
            log.warning("Failed to parse triple extraction JSON")
            self._extraction_metrics["failed_extractions"] += 1
            return []

        if not isinstance(triples_data, list):
            self._extraction_metrics["failed_extractions"] += 1
            return []

        if not triples_data and len(text) > 100:
            self._extraction_metrics["empty_extractions"] += 1

        # Fix #7: Validate extracted entities actually appear in source text
        text_lower = text.lower()

        created = []
        for t in triples_data[:30]:
            try:
                subj = t["subject"]
                obj = t["object"]

                # Check if entities are hallucinated (not present in source)
                subj_in_text = subj.lower() in text_lower
                obj_in_text = obj.lower() in text_lower
                if not subj_in_text and not obj_in_text:
                    self._extraction_metrics["hallucinated_entities"] += 1
                    log.debug(
                        "Skipping likely hallucinated triple: '%s' and '%s' not in source text",
                        subj, obj,
                    )
                    continue  # Skip triples where BOTH entities are missing

                triple_id = self.add_triple(
                    subject=subj,
                    predicate=t["predicate"],
                    obj=obj,
                    authority=authority,
                    source_file=source_file,
                    source_date=source_date or _today_iso(),
                    confidence=float(t.get("confidence", 0.8)),
                    subject_type=t.get("subject_type", "concept"),
                    object_type=t.get("object_type", "concept"),
                    knowledge_type=t.get("knowledge_type"),
                )
                created.append({"id": triple_id, **t})

                # Track predicate and knowledge type distribution
                pred = t["predicate"]
                self._extraction_metrics["predicate_distribution"][pred] = \
                    self._extraction_metrics["predicate_distribution"].get(pred, 0) + 1
                kt = t.get("knowledge_type", "declarative")
                self._extraction_metrics["knowledge_type_distribution"][kt] = \
                    self._extraction_metrics["knowledge_type_distribution"].get(kt, 0) + 1

            except (KeyError, TypeError) as e:
                log.debug("Skipping malformed triple: %s", e)
                continue

        self._extraction_metrics["total_triples_extracted"] += len(created)

        if created:
            self.save()
            log.info("Extracted %d triples from %s", len(created), source_file or "text")

        return created

    def get_extraction_metrics(self) -> dict[str, Any]:
        """Return LLM extraction quality metrics (Fix #7).

        Useful for detecting systematic extraction failures:
        - High failed_extractions: LLM returning bad JSON
        - High empty_extractions: LLM missing facts
        - High hallucinated_entities: LLM inventing entities
        - Skewed predicate_distribution: missing relationship types
        """
        m = dict(self._extraction_metrics)
        total = m["total_extractions"]
        if total > 0:
            m["failure_rate"] = m["failed_extractions"] / total
            m["empty_rate"] = m["empty_extractions"] / total
            m["avg_triples_per_extraction"] = m["total_triples_extracted"] / total
        return m

    # ── Authority + Decay ──

    def upgrade_authority(self, source_file: str, new_authority: str) -> int:
        """Upgrade authority on all triples from a given source.

        Called when user approves pending memory — triples become explicit.
        """
        count = 0
        auth_rank = {"inferred": 0, "system": 1, "explicit": 2}
        new_rank = auth_rank.get(new_authority, 0)

        for t in self._triples:
            if source_file in t.get("source_files", []):
                if auth_rank.get(t.get("authority", "inferred"), 0) < new_rank:
                    t["authority"] = new_authority
                    # User approval = verification event (strongest epistemic act)
                    if new_authority == "explicit":
                        t["epistemic_status"] = EpistemicStatus.VERIFIED.value
                        t["last_verified"] = _now_iso()
                    count += 1

        # Upgrade entities too
        for t in self._triples:
            if source_file in t.get("source_files", []):
                for slug in [t["subject"], t.get("object")]:
                    if slug:
                        self._registry.upgrade_authority(slug, new_authority)
                        if new_authority == "explicit":
                            self._registry.mark_verified(slug)

        if count:
            self._dirty = True
            self.save()
            log.info("Upgraded %d triples to authority=%s from %s", count, new_authority, source_file)

        return count

    def merge_entities(self, slug_keep: str, slug_remove: str) -> dict:
        """Merge two entities AND repoint all triple references (Fix #8).

        Previously entity_registry.merge() deleted the old slug but left triples
        still pointing at it, creating orphaned references that returned '?' on query.
        """
        if not self._registry.merge(slug_keep, slug_remove):
            return {"merged": False, "reason": "entities not found"}

        # Repoint all triples that reference the removed slug
        repointed = 0
        for t in self._triples:
            if t["subject"] == slug_remove:
                t["subject"] = slug_keep
                repointed += 1
            if t.get("object") == slug_remove:
                t["object"] = slug_keep
                repointed += 1

        if repointed:
            self._triples_dirty = True
            self.save()

        log.info(
            "Entity merge: '%s' into '%s', %d triple references repointed",
            slug_remove, slug_keep, repointed,
        )
        return {"merged": True, "slug_keep": slug_keep, "slug_remove": slug_remove, "triples_repointed": repointed}

    def evaluate_decay(self) -> dict:
        """Evaluate decay conditions on all entities and triples."""
        now = datetime.now(UTC)
        entities_decayed = 0
        triples_decayed = 0

        for t in self._triples:
            if t["status"] != "active":
                continue
            condition = t.get("decay_condition", "never")
            if self._should_decay(condition, t, now):
                t["status"] = "decayed"
                t["decayed_at"] = _now_iso()
                triples_decayed += 1

        # Decay entities based on their own decay condition.
        # The entity decays if its condition is met — the cascade code below
        # handles individual triples selectively (verified/recent triples survive).
        # Previously required ALL triples to be decayed first, which prevented
        # entity decay when triples had "when:superseded" (never met) conditions.
        newly_decayed_entities: list[str] = []
        for slug, ent in self._registry.entities.items():
            if ent.get("status") == "decayed":
                continue
            condition = ent.get("decay_condition", "never")
            if condition == "never":
                continue
            if self._should_decay(condition, ent, now):
                self._registry.mark_decayed(slug)
                entities_decayed += 1
                newly_decayed_entities.append(slug)

        # Cascade: when an entity decays, decay its triples — BUT skip triples
        # that are individually verified or recently accessed (Fix #5).
        # Previously this was all-or-nothing: if "Project X" entity decayed,
        # even "Project X deadline is June 2026" (actively queried yesterday) died.
        # Build entity→triple index to avoid O(entities × triples) scan.
        if newly_decayed_entities:
            entity_triples: dict[str, list[dict]] = {}
            for t in self._triples:
                if t["status"] != "active":
                    continue
                for slug_key in (t["subject"], t.get("object")):
                    if slug_key:
                        entity_triples.setdefault(slug_key, []).append(t)

        for slug in newly_decayed_entities:
            for t in entity_triples.get(slug, []):
                if t["status"] != "active":
                    continue  # may have been decayed by a previous slug in this loop
                # Skip verified triples — they have independent epistemic ground
                if t.get("epistemic_status") == "verified":
                    continue
                # Skip triples accessed in the last 14 days — still actively relevant
                last_acc = t.get("last_accessed", "")
                if last_acc:
                    try:
                        acc_dt = datetime.fromisoformat(last_acc.replace("Z", "+00:00"))
                        if (now - acc_dt) < timedelta(days=14):
                            continue
                    except ValueError:
                        pass
                t["status"] = "decayed"
                t["decayed_at"] = _now_iso()
                triples_decayed += 1

        if entities_decayed or triples_decayed:
            self._dirty = True
            self.save()
            log.info("Decay: %d entities, %d triples decayed", entities_decayed, triples_decayed)

        return {"entities_decayed": entities_decayed, "triples_decayed": triples_decayed}

    @staticmethod
    def _should_decay(condition: str, item: dict, now: datetime) -> bool:
        """Check if a decay condition is met."""
        if not condition or condition == "never":
            return False

        parts = condition.split(":")

        if parts[0] == "after" and len(parts) >= 2:
            days = int(parts[1].rstrip("d"))
            created = item.get("first_seen") or item.get("source_date", "")
            if created:
                try:
                    created_dt = datetime.fromisoformat(created.replace("Z", "+00:00"))
                    return (now - created_dt) > timedelta(days=days)
                except ValueError:
                    pass

        elif parts[0] == "when" and len(parts) >= 2:
            if parts[1] == "superseded":
                return bool(item.get("superseded_by"))
            if parts[1] == "unaccessed" and len(parts) >= 3:
                days = int(parts[2].rstrip("d"))
                last = item.get("last_accessed", "")
                if last:
                    try:
                        last_dt = datetime.fromisoformat(last.replace("Z", "+00:00"))
                        return (now - last_dt) > timedelta(days=days)
                    except ValueError:
                        pass

        return False

    def reweight(self) -> None:
        """Recalculate effective weights for all active triples.

        Epistemically sound formula:
          effective_weight = authority × confidence × epistemic × temporal × justification

        where justification = (1 + source_boost) × inference_factor

        Key design principles:
        1. Temporal factor uses last_verified (not last_accessed). Reading a fact
           doesn't make it more true — only verification events reset the clock.
        2. Independent sources (horizontal) boost weight: +0.1 per source, capped +0.5.
           Inference chains (vertical) penalize: 0.95^depth — long chains are fragile.
        3. Epistemic factors treat verified (1.0) as the baseline, not believed.
           Unverified beliefs are penalized because they lack justification.
        4. Verified facts that decay below temporal=0.15 get downgraded to believed
           (reconciles the verified+decayed contradiction).
        """
        now = datetime.now(UTC)

        for t in self._triples:
            if t["status"] != "active":
                continue

            auth_w = AUTHORITY_WEIGHTS.get(t.get("authority", "inferred"), 1.0)
            confidence = t.get("confidence", 0.8)

            # Fix 6: Verified is the epistemic baseline (1.0), not a bonus.
            # Unverified beliefs are penalized because they lack full justification.
            epistemic_factors = {
                "verified": 1.0, "believed": 0.7, "uncertain": 0.5,
                "contested": 0.3, "superseded": 0.1, "retracted": 0.0,
            }
            epistemic = epistemic_factors.get(t.get("epistemic_status", "believed"), 0.7)

            # Fix 1 + 4: Temporal factor uses last_verified, not last_accessed.
            # Justification comes from evidence, not retrieval frequency.
            # Half-life of 90 days (verified facts stay strong longer).
            # Falls back to source_date for never-verified facts (shorter 45-day half-life).
            # Temporal factor: knowledge-type-aware half-lives.
            # Episodic facts (events) fade fast; normative (preferences) persist.
            # Verified facts get the full half-life; unverified get 50% of it.
            kt = t.get("knowledge_type", "declarative")
            half_life = _KNOWLEDGE_TYPE_HALF_LIVES.get(kt, 90)

            temporal = 1.0
            verified_at = t.get("last_verified")
            if verified_at:
                try:
                    verified_dt = datetime.fromisoformat(verified_at.replace("Z", "+00:00"))
                    if verified_dt.tzinfo is None:
                        verified_dt = verified_dt.replace(tzinfo=UTC)
                    days_since = max(0, (now - verified_dt).days)
                    temporal = 0.5 ** (days_since / half_life)
                except ValueError:
                    pass
            else:
                # Unverified: 50% of the knowledge-type half-life
                unverified_half_life = max(14, half_life // 2)
                source = t.get("source_date") or t.get("first_seen", "")
                if source:
                    try:
                        source_dt = datetime.fromisoformat(source.replace("Z", "+00:00"))
                        if source_dt.tzinfo is None:
                            source_dt = source_dt.replace(tzinfo=UTC)
                        days_since = max(0, (now - source_dt).days)
                        temporal = 0.5 ** (days_since / unverified_half_life)
                    except ValueError:
                        pass

            # Fix #6: Separate independent sources (horizontal credibility) from
            # inference chains (vertical reasoning). Multiple independent sources
            # confirming a fact is genuinely robust. Long inference chains are fragile
            # — break one hop and everything downstream collapses.
            #
            # Sources boost: each independent source adds +0.1 (capped at +0.5)
            # Inference penalty: each hop in the chain REDUCES confidence slightly
            # because inferred facts are only as strong as their weakest premise.
            source_count = len(t.get("source_files", []))
            source_boost = min(0.5, source_count * 0.1)

            justified_by = t.get("justified_by", [])
            inference_depth = len(justified_by)
            # Inferred facts (depth > 0) get penalized: 0.95^depth
            # 1 hop = 0.95, 2 hops = 0.90, 5 hops = 0.77, 10 hops = 0.60
            inference_factor = 0.95 ** inference_depth if inference_depth > 0 else 1.0

            justification = (1.0 + source_boost) * inference_factor

            t["effective_weight"] = auth_w * confidence * epistemic * temporal * justification

            # Fix #3: Reconcile verified status with severe temporal decay.
            # A fact can't be both "verified" and temporally irrelevant — if temporal
            # factor drops below 0.15 (roughly 2.5+ half-lives without re-verification),
            # downgrade to "believed" so queries know it needs re-confirmation.
            if t.get("epistemic_status") == "verified" and temporal < 0.15:
                t["epistemic_status"] = "believed"
                log.debug(
                    "Triple #%d downgraded verified->believed (temporal=%.3f, "
                    "last_verified=%s -- needs re-confirmation)",
                    t.get("id", 0), temporal, t.get("last_verified", "?"),
                )

            # Fix C: Recover uncertain triples that have been re-encountered.
            # When a triple is marked uncertain by cascade, it stays uncertain forever
            # even if the fact is re-mentioned later. If the triple has been
            # re-encountered since becoming uncertain (encounter_count > 0 and
            # multiple sources corroborate it), upgrade back to believed.
            if t.get("epistemic_status") == "uncertain":
                sources = len(t.get("source_files", []))
                encounters = t.get("encounter_count", 0)
                # Recovery: 2+ independent sources, or 3+ re-encounters
                if sources >= 2 or encounters >= 3:
                    t["epistemic_status"] = "believed"
                    log.debug(
                        "Triple #%d recovered uncertain->believed "
                        "(sources=%d, encounters=%d)",
                        t.get("id", 0), sources, encounters,
                    )

        self._dirty = True

    # ── Wiki-link graph building ──

    def build(self) -> int:
        """Scan all vault files, build graphs from [[links]] + SPO overlay + cross-refs."""
        self._wikilink_graph.clear()
        self._spo_graph.clear()
        self._graph.clear()
        self._node_sources.clear()
        self._article_triples.clear()
        self._article_entities.clear()

        # Load persisted data
        self._load_graph_data()

        files = self._vault.list_files(pattern="**/*.md")
        edges_created = 0

        # Only scan knowledge files, not raw user files or library copies
        _SCAN_PREFIXES = ("agnt-kb/", "agnt-memory/", "agnt-system/identity/", "journal/", "agnt-system/agents/")
        _SKIP_PATTERNS = ("/library/", "/inbox/", "/.archives/", "/.history/")

        for file_path in files:
            relative = str(file_path.relative_to(self._vault.vault_dir)).replace("\\", "/")

            # Only scan wiki articles, memory, identity — not library copies of user files
            if not any(relative.startswith(p) for p in _SCAN_PREFIXES):
                continue
            if any(s in relative for s in _SKIP_PATTERNS) or relative.endswith(".index.md"):
                continue
            # Skip memory summary archives (summaries/{layer}/{date}.md) — only scan current summaries
            if "agnt-memory/summaries/" in relative and relative.count("/") > 2:
                continue

            try:
                doc = self._vault.read(relative)
            except Exception:
                continue

            links = WIKI_LINK_PATTERN.findall(doc.content)
            if not links:
                continue

            file_node = relative
            file_etype = doc.metadata.get("entity_type", "")
            # Add to wiki-link graph
            self._wikilink_graph.add_node(file_node, type="file", label=file_path.stem, entity_type=file_etype)
            # Add to combined graph
            self._graph.add_node(file_node, type="file", label=file_path.stem, entity_type=file_etype)

            # If this file IS an entity page (person, concept, org), register its display name
            if file_etype and file_etype not in ("source_summary", "synthesis", "decision_record"):
                display_name = doc.metadata.get("title", file_path.stem)
                if not self._graph.has_node(display_name):
                    self._graph.add_node(display_name, type="entity", label=display_name, entity_type=file_etype)
                elif not self._graph.nodes[display_name].get("entity_type"):
                    self._graph.nodes[display_name]["entity_type"] = file_etype

            # Collect entity slugs for this article (for cross-referencing)
            article_slugs: set[str] = set()

            for link in links:
                link = link.strip()
                if not link or link.lower() in _LINK_BLOCKLIST:
                    continue

                if not self._wikilink_graph.has_node(link):
                    self._wikilink_graph.add_node(link, type="entity", label=link)
                if not self._graph.has_node(link):
                    self._graph.add_node(link, type="entity", label=link)

                if link not in self._node_sources:
                    self._node_sources[link] = set()
                self._node_sources[link].add(file_node)

                # Resolve link to entity slug for cross-referencing
                slug = self._registry.resolve(link)
                if slug:
                    article_slugs.add(slug)

                if not self._wikilink_graph.has_edge(file_node, link):
                    self._wikilink_graph.add_edge(file_node, link, relation="mentions")
                    self._graph.add_edge(file_node, link, relation="mentions")
                    edges_created += 1

            # Co-mention edges (wiki-link graph only, NOT in SPO)
            basename = file_path.name.lower()
            is_index = basename in (".index.md", ".concepts.md", "_catalog.md") or "/.archives/" in relative
            if not is_index and len(links) <= 50:
                for i, link_a in enumerate(links):
                    for link_b in links[i + 1:]:
                        a, b = link_a.strip(), link_b.strip()
                        if a and b and a != b and a.lower() not in _LINK_BLOCKLIST and b.lower() not in _LINK_BLOCKLIST:
                            if not self._wikilink_graph.has_edge(a, b):
                                self._wikilink_graph.add_edge(a, b, relation="co-mentioned")
                                edges_created += 1
                            if not self._graph.has_edge(a, b):
                                self._graph.add_edge(a, b, relation="co-mentioned")

            # Store entity slugs for this article
            if article_slugs and "/wiki/" in relative:
                self._article_entities[relative] = article_slugs

        # Overlay SPO edges onto both SPO graph and combined graph
        edges_created += self._overlay_spo_edges()

        # Cross-reference: match triples to wiki articles
        xref_count = self._cross_reference_triples()

        log.debug(
            "Knowledge graph built: %d wikilink nodes, %d spo nodes, %d combined edges, "
            "%d entities, %d triples, %d cross-refs",
            self._wikilink_graph.number_of_nodes(), self._spo_graph.number_of_nodes(),
            self._graph.number_of_edges(),
            len(self._registry.entities), len(self._triples), xref_count,
        )
        return edges_created

    def _overlay_spo_edges(self) -> int:
        """Add edges from SPO triples onto both SPO graph and combined graph."""
        edges_created = 0
        for t in self._triples:
            if t["status"] != "active" or not t.get("object"):
                continue

            subj_name = self._registry.get_name(t["subject"])
            obj_name = self._registry.get_name(t.get("object"))
            if not subj_name or subj_name == "?" or not obj_name or obj_name == "?":
                continue

            weight = AUTHORITY_WEIGHTS.get(t.get("authority", "inferred"), 1.0) * t.get("confidence", 0.8)

            # SPO graph (directed)
            if not self._spo_graph.has_node(subj_name):
                self._spo_graph.add_node(subj_name, type="entity", label=subj_name)
            if not self._spo_graph.has_node(obj_name):
                self._spo_graph.add_node(obj_name, type="entity", label=obj_name)

            if self._spo_graph.has_edge(subj_name, obj_name):
                existing = self._spo_graph[subj_name][obj_name]
                existing["weight"] = existing.get("weight", 1.0) + weight
                relations = existing.get("relations", [])
                if t["predicate"] not in relations:
                    relations.append(t["predicate"])
                    existing["relations"] = relations
            else:
                self._spo_graph.add_edge(
                    subj_name, obj_name,
                    relation=t["predicate"], relations=[t["predicate"]],
                    weight=weight, source="spo",
                )
                edges_created += 1

            # Combined graph (undirected, for backwards compat)
            if not self._graph.has_node(subj_name):
                self._graph.add_node(subj_name, type="entity", label=subj_name)
            if not self._graph.has_node(obj_name):
                self._graph.add_node(obj_name, type="entity", label=obj_name)

            if self._graph.has_edge(subj_name, obj_name):
                existing = self._graph[subj_name][obj_name]
                existing["weight"] = existing.get("weight", 1.0) + weight
                relations = existing.get("relations", [])
                if t["predicate"] not in relations:
                    relations.append(t["predicate"])
                    existing["relations"] = relations
            else:
                self._graph.add_edge(
                    subj_name, obj_name,
                    relation=t["predicate"], relations=[t["predicate"]],
                    weight=weight, source="spo",
                )

        return edges_created

    def _cross_reference_triples(self) -> int:
        """Match triples to wiki articles that mention the same entities.

        For each active triple, if both subject and object entities appear
        in a wiki article's [[wikilinks]], that article "expresses" the triple.

        Builds bidirectional index:
        - triple gets wiki_refs (article paths)
        - _article_triples maps article path -> triple IDs
        """
        xref_count = 0

        # Clear existing wiki_refs on triples
        for t in self._triples:
            t.pop("wiki_refs", None)

        for t in self._triples:
            # Cross-reference active AND superseded/contested triples
            # (superseded triples indicate stale article content)
            if t["status"] not in ("active", "superseded", "contested"):
                continue

            subj_slug = t["subject"]
            obj_slug = t.get("object")  # None for literals

            refs = []
            for article_path, article_slugs in self._article_entities.items():
                if subj_slug in article_slugs:
                    # Subject is mentioned in this article
                    if obj_slug is None or obj_slug in article_slugs:
                        # Both subject and object (or literal triple's subject) present
                        refs.append(article_path)
                        self._article_triples.setdefault(article_path, [])
                        if t["id"] not in self._article_triples[article_path]:
                            self._article_triples[article_path].append(t["id"])

            if refs:
                t["wiki_refs"] = refs
                xref_count += 1

        return xref_count

    def get_article_triples(self, article_path: str) -> list[dict]:
        """Get all triples that are expressed in a wiki article."""
        triple_ids = self._article_triples.get(article_path, [])
        results = []
        for t in self._triples:
            if t["id"] in triple_ids and t["status"] == "active":
                results.append({
                    "id": t["id"],
                    "subject": self._registry.get_name(t["subject"]),
                    "predicate": t["predicate"],
                    "object": self._registry.get_name(t.get("object")) or t.get("object_literal"),
                    "confidence": t["confidence"],
                    "authority": t["authority"],
                    "epistemic_status": t.get("epistemic_status", "believed"),
                })
        return results

    def get_triple_articles(self, triple_id: int) -> list[str]:
        """Get all wiki articles that express a given triple."""
        for t in self._triples:
            if t["id"] == triple_id:
                return t.get("wiki_refs", [])
        return []

    # ── Temporal queries ──

    def query_entity_at(self, entity: str, date: str) -> dict | None:
        """Query what was known about an entity at a specific point in time.

        Returns only triples that were valid at the given date:
        - valid_from <= date
        - valid_until is None OR valid_until > date
        """
        slug = self._registry.resolve(entity)
        if not slug:
            return None

        ent = self._registry.entities[slug]
        facts: dict[str, list[dict]] = {}

        for t in self._triples:
            if t["subject"] != slug and t.get("object") != slug:
                continue

            # Check temporal validity
            valid_from = t.get("valid_from", t.get("source_date", ""))
            valid_until = t.get("valid_until")

            if valid_from and valid_from > date:
                continue  # not yet valid at this date
            if valid_until and valid_until <= date:
                continue  # already expired at this date

            pred = t["predicate"]
            if t["subject"] == slug:
                obj_display = self._registry.get_name(t.get("object")) or t.get("object_literal", "?")
                facts.setdefault(pred, []).append({
                    "value": obj_display,
                    "confidence": t["confidence"],
                    "authority": t["authority"],
                    "epistemic_status": t.get("epistemic_status", "believed"),
                    "valid_from": valid_from,
                    "valid_until": valid_until,
                })

        if not facts:
            return None

        return {
            "entity": {
                "name": ent["canonical_name"],
                "type": ent.get("entity_type", "thing"),
            },
            "as_of": date,
            "facts": facts,
        }

    # ── Confidence propagation ──

    def propagate_change(self, triple_id: int) -> dict:
        """When a triple changes status, cascade along justification chains.

        Epistemic cascade follows two paths (in order of priority):
        1. Justification dependencies: triples whose justified_by includes the
           changed triple are directly invalidated (their premise is gone).
        2. Source-file heuristic (secondary): triples from the same source get
           downgraded to "uncertain" as a weaker guilt-by-association signal.
           This is a fallback for triples without explicit justification links.

        Verified facts are immune to cascade — they have independent justification
        from user confirmation.
        """
        triple = None
        for t in self._triples:
            if t["id"] == triple_id:
                triple = t
                break
        if not triple:
            return {"affected_articles": [], "affected_triples": [], "triple_id": triple_id}

        changed_status = triple.get("epistemic_status", "believed")
        is_negative = changed_status in ("superseded", "contested", "retracted")

        affected_triples = []
        cascade_truncated = False
        _MAX_CASCADE_DEPTH = 20  # Prevent runaway cascades from cyclic/deep chains

        if is_negative:
            visited = {triple_id}

            # Phase 1: Follow justification chains (proper belief revision).
            # If triple A justified triple B, and A is retracted, B loses its ground.
            # Depth-limited BFS prevents cycles and unbounded cascades.
            # Fix #9: Don't break on depth limit — skip the deep node but continue
            # processing other nodes in the queue. Also mark triples beyond the
            # limit so they can be identified as having incomplete justification.
            queue: list[tuple[int, int]] = [(triple_id, 0)]  # (id, depth)
            while queue:
                current_id, depth = queue.pop(0)
                if depth >= _MAX_CASCADE_DEPTH:
                    # Don't break — other items in queue at shallower depth may still need processing.
                    # Mark this as truncated so the caller knows the cascade was incomplete.
                    cascade_truncated = True
                    log.warning(
                        "Cascade depth limit (%d) reached at triple #%d — "
                        "marking as cascade_truncated",
                        _MAX_CASCADE_DEPTH, current_id,
                    )
                    continue  # skip this node but keep processing the queue
                for t in self._triples:
                    if t["id"] in visited or t["status"] != "active":
                        continue
                    if t.get("epistemic_status") in ("verified", "superseded", "retracted"):
                        continue  # Verified facts have independent justification
                    if current_id in t.get("justified_by", []):
                        # This triple's justification is invalidated
                        new_status = "uncertain"
                        # If we're AT the depth limit, mark as cascade_incomplete
                        # so health checks can detect triples with unresolved dependencies
                        if depth + 1 >= _MAX_CASCADE_DEPTH:
                            t["cascade_incomplete"] = True
                        t["epistemic_status"] = new_status
                        visited.add(t["id"])
                        queue.append((t["id"], depth + 1))
                        affected_triples.append({
                            "id": t["id"],
                            "subject": self._registry.get_name(t["subject"]),
                            "predicate": t["predicate"],
                            "object": self._registry.get_name(t.get("object")) or t.get("object_literal"),
                            "new_status": new_status,
                            "reason": f"justified by invalidated triple #{current_id}",
                        })

            # Phase 2: Source-file heuristic (weaker signal, secondary).
            # Only affects triples NOT already caught by justification chains
            # and NOT already verified.
            # Tightened: must share BOTH source file AND subject entity.
            # A job change for Wolf shouldn't make "Alice knows Bob" uncertain
            # just because both facts came from the same meeting notes.
            if triple.get("source_files"):
                invalidated_subject = triple["subject"]
                for t in self._triples:
                    if t["id"] in visited or t["status"] != "active":
                        continue
                    if t.get("epistemic_status") in ("verified", "superseded", "retracted"):
                        continue
                    # Must share the same subject entity (not just source file)
                    if t["subject"] != invalidated_subject:
                        continue
                    shared_sources = set(t.get("source_files", [])) & set(triple.get("source_files", []))
                    if shared_sources:
                        t["epistemic_status"] = "uncertain"
                        visited.add(t["id"])
                        affected_triples.append({
                            "id": t["id"],
                            "subject": self._registry.get_name(t["subject"]),
                            "predicate": t["predicate"],
                            "object": self._registry.get_name(t.get("object")) or t.get("object_literal"),
                            "new_status": "uncertain",
                            "reason": f"shares source with invalidated triple #{triple_id}",
                        })

        if affected_triples:
            self._triples_dirty = True

        # Find affected wiki articles
        affected_articles = list(triple.get("wiki_refs", []))
        subj_slug = triple["subject"]
        for article_path, article_slugs in self._article_entities.items():
            if subj_slug in article_slugs and article_path not in affected_articles:
                affected_articles.append(article_path)

        return {
            "triple_id": triple_id,
            "status": triple.get("status"),
            "epistemic_status": changed_status,
            "subject": self._registry.get_name(triple["subject"]),
            "predicate": triple["predicate"],
            "affected_articles": affected_articles,
            "affected_triples": affected_triples,
            "cascaded": len(affected_triples),
            "cascade_truncated": cascade_truncated,  # Fix #9: True if depth limit was hit
        }

    def get_stale_articles(self) -> list[dict]:
        """Find wiki articles that may contain outdated information.

        An article is potentially stale if any of its backing triples have been
        superseded, contested, or retracted.
        """
        stale = []
        seen = set()

        for article_path, triple_ids in self._article_triples.items():
            if article_path in seen:
                continue

            stale_triples = []
            for t in self._triples:
                if t["id"] not in triple_ids:
                    continue
                es = t.get("epistemic_status", "believed")
                status = t.get("status", "active")
                if es in ("superseded", "contested", "retracted") or status in ("superseded", "decayed"):
                    stale_triples.append({
                        "id": t["id"],
                        "subject": self._registry.get_name(t["subject"]),
                        "predicate": t["predicate"],
                        "object": self._registry.get_name(t.get("object")) or t.get("object_literal"),
                        "status": t.get("epistemic_status"),
                    })

            if stale_triples:
                seen.add(article_path)
                stale.append({
                    "article": article_path,
                    "stale_triples": stale_triples,
                    "total_triples": len(triple_ids),
                })

        stale.sort(key=lambda x: len(x["stale_triples"]), reverse=True)
        return stale

    # ── Query methods (backwards compat) ──

    def get_connected(self, entity: str, depth: int = 2) -> list[dict]:
        """Get all entities connected within N hops (combined graph)."""
        if entity not in self._graph:
            for node in self._graph.nodes:
                if node.lower() == entity.lower():
                    entity = node
                    break
            else:
                return []

        connected = []
        visited = {entity}
        queue = [(entity, 0)]

        while queue:
            current, d = queue.pop(0)
            if d > 0:
                node_data = self._graph.nodes[current]
                edge_data = self._graph.edges.get((entity, current), {})
                connected.append({
                    "entity": current,
                    "type": node_data.get("type", "unknown"),
                    "label": node_data.get("label", current),
                    "distance": d,
                    "sources": sorted(self._node_sources.get(current, set())),
                    "relations": edge_data.get("relations", [edge_data.get("relation", "connected")]),
                    "weight": edge_data.get("weight", 1.0),
                })

            if d < depth:
                for neighbor in self._graph.neighbors(current):
                    if neighbor not in visited:
                        visited.add(neighbor)
                        queue.append((neighbor, d + 1))

        connected.sort(key=lambda x: (-x.get("weight", 1.0), x["distance"]))
        return connected

    def search_entities(self, query: str) -> list[dict]:
        """Search for entities by name. Combines registry search with graph data."""
        query_lower = query.lower()
        results = []
        seen = set()

        # Search NetworkX nodes
        for node in self._graph.nodes:
            node_data = self._graph.nodes[node]
            if node_data.get("type") == "entity" and query_lower in node.lower():
                results.append({
                    "entity": node,
                    "connections": self._graph.degree(node),
                    "sources": sorted(self._node_sources.get(node, set())),
                })
                seen.add(node.lower())

        # Search registry entities
        for slug, ent in self._registry.entities.items():
            name = ent["canonical_name"]
            if name.lower() in seen:
                continue
            match = query_lower in name.lower()
            if not match:
                match = any(query_lower in a.lower() for a in ent.get("aliases", []))
            if match:
                triple_count = sum(
                    1 for t in self._triples
                    if t["status"] == "active" and (t["subject"] == slug or t.get("object") == slug)
                )
                results.append({
                    "entity": name,
                    "entity_type": ent.get("entity_type", "thing"),
                    "authority": ent.get("authority", "inferred"),
                    "connections": self._graph.degree(name) if name in self._graph else 0,
                    "triples": triple_count,
                    "sources": sorted(self._node_sources.get(name, set())),
                })

        results.sort(key=lambda x: x.get("connections", 0) + x.get("triples", 0), reverse=True)
        return results

    def get_graph_data(self) -> dict:
        """Get full graph as nodes + edges for UI visualization."""
        # Build entity_type lookup from registry — index by name, slug, and lowercase
        etype_map: dict[str, str] = {}
        if self._registry:
            for ent in self._registry.list_all():
                name = ent.get("name", "")
                slug = ent.get("slug", "")
                etype = ent.get("entity_type", "thing")
                if etype and etype != "thing":
                    if name:
                        etype_map[name] = etype
                        etype_map[name.lower()] = etype
                    if slug:
                        etype_map[slug] = etype

        # Also index entity_type from wiki article frontmatter (node attributes)
        for node in self._graph.nodes:
            data = self._graph.nodes[node]
            node_etype = data.get("entity_type", "")
            if node_etype and node_etype not in ("", "source_summary", "synthesis", "decision_record"):
                etype_map[node] = node_etype
                etype_map[data.get("label", node)] = node_etype

        nodes = []
        for node in self._graph.nodes:
            data = self._graph.nodes[node]
            label = data.get("label", node)
            # Try: exact label, exact node id, lowercase label, hyphenated label
            entity_type = (
                etype_map.get(label) or etype_map.get(node)
                or etype_map.get(label.lower())
                or etype_map.get(label.lower().replace(" ", "-"))
                or ""
            )
            nd: dict = {
                "id": node,
                "label": label,
                "type": data.get("type", "unknown"),
                "connections": self._graph.degree(node),
            }
            if entity_type:
                nd["entity_type"] = entity_type
            nodes.append(nd)

        edges = []
        for u, v in self._graph.edges:
            edge_data = self._graph.edges[u, v]
            edges.append({
                "source": u,
                "target": v,
                "relation": edge_data.get("relation", "related"),
                "relations": edge_data.get("relations", []),
                "weight": edge_data.get("weight", 1.0),
                "semantic": edge_data.get("source") == "spo",
            })

        return {
            "nodes": nodes,
            "edges": edges,
            "node_count": len(nodes),
            "edge_count": len(edges),
        }

    def get_stats(self) -> dict:
        """Graph statistics including SPO triple data."""
        entities = [n for n, d in self._graph.nodes(data=True) if d.get("type") == "entity"]
        files = [n for n, d in self._graph.nodes(data=True) if d.get("type") == "file"]

        most_connected = sorted(
            [(n, self._graph.degree(n)) for n in entities],
            key=lambda x: x[1], reverse=True,
        )[:10]

        active_triples = [t for t in self._triples if t["status"] == "active"]
        decayed_triples = [t for t in self._triples if t.get("status") == "decayed"]
        superseded_triples = [t for t in self._triples if t.get("status") == "superseded"]

        authority_counts: dict[str, int] = {}
        for t in active_triples:
            auth = t.get("authority", "inferred")
            authority_counts[auth] = authority_counts.get(auth, 0) + 1

        epistemic_counts: dict[str, int] = {}
        for t in active_triples:
            es = t.get("epistemic_status", "believed")
            epistemic_counts[es] = epistemic_counts.get(es, 0) + 1

        knowledge_type_counts: dict[str, int] = {}
        for t in active_triples:
            kt = t.get("knowledge_type", "declarative")
            knowledge_type_counts[kt] = knowledge_type_counts.get(kt, 0) + 1

        registry_stats = self._registry.stats()

        return {
            "total_nodes": self._graph.number_of_nodes(),
            "total_edges": self._graph.number_of_edges(),
            "wiki_entities": len(entities),
            "files": len(files),
            "wikilink_edges": self._wikilink_graph.number_of_edges(),
            "spo_edges": self._spo_graph.number_of_edges(),
            "most_connected": [{"entity": n, "connections": c} for n, c in most_connected],
            "spo": {
                "entities": registry_stats["total"],
                "entity_types": registry_stats["by_type"],
                "active_triples": len(active_triples),
                "decayed_triples": len(decayed_triples),
                "superseded_triples": len(superseded_triples),
                "authority_breakdown": authority_counts,
                "epistemic_breakdown": epistemic_counts,
                "knowledge_types": knowledge_type_counts,
            },
            "extraction_quality": self.get_extraction_metrics(),
        }
