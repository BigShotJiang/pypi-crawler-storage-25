"""Unified Entity Registry — single source of truth for all entities.

Every subsystem (memory graph, KB wiki, agent tools, vault search) references
entities through this registry. One slug, one canonical name, one set of aliases.

Storage: agnt-memory/graph/entities.json (vault-centric, same as before but now
the registry owns it exclusively).
"""

from __future__ import annotations

import json
import logging
import re
from datetime import UTC, datetime
from difflib import SequenceMatcher
from typing import TYPE_CHECKING, Any

from agntspace.memory.ontology import EntityType, resolve_entity_type

if TYPE_CHECKING:
    from agntspace.vault.reader import VaultReader
    from agntspace.vault.writer import VaultWriter

log = logging.getLogger(__name__)

_ENTITIES_PATH = "agnt-memory/graph/entities.json"


def _slugify(name: str) -> str:
    """Convert entity name to a stable slug ID."""
    return re.sub(r"[^a-z0-9]+", "-", name.lower()).strip("-")


def _now_iso() -> str:
    return datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%SZ")


class EntityRegistry:
    """Canonical registry for all entities in the system.

    Every entity has:
    - slug: stable ID derived from name
    - canonical_name: display name
    - entity_type: from ontology EntityType
    - aliases: alternative names
    - authority: explicit > system > inferred (never downgrades)
    - decay_condition: when to forget
    - access tracking: first_seen, last_accessed, access_count
    - status: active or decayed
    """

    def __init__(
        self,
        vault: VaultReader | None = None,
        writer: VaultWriter | None = None,
    ) -> None:
        self._vault = vault
        self._writer = writer
        self._entities: dict[str, dict[str, Any]] = {}
        self._dirty = False

        # Indexes for fast lookup
        self._name_index: dict[str, str] = {}   # lowercase name -> slug
        self._alias_index: dict[str, str] = {}   # lowercase alias -> slug

    def load(self) -> int:
        """Load entities from vault JSON. Returns count loaded."""
        if not self._vault:
            return 0

        if not self._vault.exists(_ENTITIES_PATH):
            return 0

        try:
            path = self._vault.vault_dir / _ENTITIES_PATH
            raw = path.read_text(encoding="utf-8")
            data = json.loads(raw)
            self._entities = data
            self._rebuild_indexes()
            log.debug("EntityRegistry: loaded %d entities", len(self._entities))
            return len(self._entities)
        except Exception as e:
            log.warning("EntityRegistry: failed to load entities.json: %s", e)
            self._entities = {}
            return 0

    def save(self) -> None:
        """Persist entities to vault JSON."""
        if not self._writer or not self._dirty:
            return

        entities_json = json.dumps(self._entities, separators=(",", ":"), ensure_ascii=False)
        self._writer.write(_ENTITIES_PATH, entities_json)
        self._dirty = False
        log.info("EntityRegistry: saved %d entities", len(self._entities))

    def _rebuild_indexes(self) -> None:
        """Rebuild name and alias indexes from entity data."""
        self._name_index.clear()
        self._alias_index.clear()
        for slug, ent in self._entities.items():
            name_lower = ent["canonical_name"].lower()
            self._name_index[name_lower] = slug
            for alias in ent.get("aliases", []):
                self._alias_index[alias.lower()] = slug

    # ── Resolution ──

    def resolve(self, name: str) -> str | None:
        """Resolve an entity name to its slug. Three-tier matching.

        1. Exact slug or canonical name (case-insensitive)
        2. Alias match
        3. Fuzzy match (SequenceMatcher > 0.85 for names > 5 chars)
        """
        name_lower = name.lower().strip()
        slug = _slugify(name)

        # Tier 1: exact slug
        if slug in self._entities:
            return slug

        # Tier 1b: exact canonical name (via index)
        if name_lower in self._name_index:
            return self._name_index[name_lower]

        # Tier 2: alias (via index)
        if name_lower in self._alias_index:
            return self._alias_index[name_lower]

        # Tier 3: fuzzy match (only for longer names)
        if len(name) > 5:
            best_score = 0.0
            best_slug = None
            for s, ent in self._entities.items():
                score = SequenceMatcher(None, name_lower, ent["canonical_name"].lower()).ratio()
                if score > best_score:
                    best_score = score
                    best_slug = s
                for alias in ent.get("aliases", []):
                    score = SequenceMatcher(None, name_lower, alias.lower()).ratio()
                    if score > best_score:
                        best_score = score
                        best_slug = s
            if best_score >= 0.85 and best_slug:
                return best_slug

        return None

    # ── CRUD ──

    def add(
        self,
        name: str,
        entity_type: str | EntityType = EntityType.THING,
        authority: str = "inferred",
        aliases: list[str] | None = None,
        decay_condition: str = "when:unaccessed:90d",
    ) -> str:
        """Add or update an entity. Returns the slug.

        If entity exists: merges aliases, upgrades authority (never downgrades),
        updates entity_type if more specific.
        """
        # Normalize entity_type
        if isinstance(entity_type, str):
            etype = resolve_entity_type(entity_type)
        else:
            etype = entity_type

        existing = self.resolve(name)
        now = _now_iso()

        if existing:
            return self._merge_existing(existing, etype, authority, aliases, now)

        # New entity
        slug = _slugify(name)
        base_slug = slug
        counter = 2
        while slug in self._entities:
            slug = f"{base_slug}-{counter}"
            counter += 1

        self._entities[slug] = {
            "canonical_name": name,
            "entity_type": etype.value,
            "aliases": aliases or [],
            "authority": authority,
            "decay_condition": decay_condition,
            "first_seen": now,
            "last_accessed": now,
            "access_count": 0,
            "status": "active",
        }

        # Update indexes
        self._name_index[name.lower()] = slug
        if aliases:
            for alias in aliases:
                self._alias_index[alias.lower()] = slug

        self._dirty = True
        return slug

    def _merge_existing(
        self,
        slug: str,
        entity_type: EntityType,
        authority: str,
        aliases: list[str] | None,
        now: str,
    ) -> str:
        """Merge new data into an existing entity."""
        ent = self._entities[slug]

        # Merge aliases
        if aliases:
            current_aliases = set(ent.get("aliases", []))
            new_aliases = set(aliases) - current_aliases
            if new_aliases:
                current_aliases.update(new_aliases)
                ent["aliases"] = sorted(current_aliases)
                for alias in new_aliases:
                    self._alias_index[alias.lower()] = slug

        # Upgrade authority (never downgrade)
        auth_rank = {"inferred": 0, "system": 1, "explicit": 2}
        if auth_rank.get(authority, 0) > auth_rank.get(ent.get("authority", "inferred"), 0):
            ent["authority"] = authority

        # Upgrade entity_type if more specific (THING -> specific type)
        current_type = resolve_entity_type(ent.get("entity_type", "thing"))
        if current_type == EntityType.THING and entity_type != EntityType.THING:
            ent["entity_type"] = entity_type.value

        # Track re-encounters separately from query access.
        # Entity dedup (re-adding same entity) should NOT bump last_accessed —
        # that defeats unaccessed decay. last_accessed is only set by
        # bump_access() which is called from actual query paths.
        ent["last_encountered"] = now
        self._dirty = True
        return slug

    def get(self, slug: str) -> dict | None:
        """Get entity data by slug."""
        return self._entities.get(slug)

    def get_name(self, slug: str | None) -> str:
        """Get display name for a slug. Returns '?' if not found."""
        if not slug:
            return "?"
        ent = self._entities.get(slug)
        return ent["canonical_name"] if ent else slug

    def get_type(self, slug: str) -> EntityType:
        """Get the EntityType for a slug."""
        ent = self._entities.get(slug)
        if not ent:
            return EntityType.THING
        return resolve_entity_type(ent.get("entity_type", "thing"))

    def bump_access(self, slug: str) -> None:
        """Record that an entity was accessed (for relevance decay tracking)."""
        ent = self._entities.get(slug)
        if ent:
            ent["last_accessed"] = _now_iso()
            ent["access_count"] = ent.get("access_count", 0) + 1
            self._dirty = True

    def mark_verified(self, slug: str) -> None:
        """Record that an entity was epistemically verified (not just accessed).

        Verification events: user approval, authority upgrade, triple re-confirmation.
        This is distinct from bump_access which tracks reads.
        """
        ent = self._entities.get(slug)
        if ent:
            ent["last_verified"] = _now_iso()
            self._dirty = True

    def add_alias(self, slug: str, alias: str) -> bool:
        """Add an alias to an existing entity."""
        ent = self._entities.get(slug)
        if not ent:
            return False
        aliases = set(ent.get("aliases", []))
        if alias not in aliases:
            aliases.add(alias)
            ent["aliases"] = sorted(aliases)
            self._alias_index[alias.lower()] = slug
            self._dirty = True
        return True

    def merge(self, slug_keep: str, slug_remove: str) -> bool:
        """Merge two entities. Keeps slug_keep, removes slug_remove.

        Aliases from removed entity are added to kept entity.
        Returns True if merge happened.
        """
        keep = self._entities.get(slug_keep)
        remove = self._entities.get(slug_remove)
        if not keep or not remove:
            return False

        # Merge aliases (include the removed entity's canonical name)
        keep_aliases = set(keep.get("aliases", []))
        keep_aliases.add(remove["canonical_name"])
        keep_aliases.update(remove.get("aliases", []))
        keep["aliases"] = sorted(keep_aliases)

        # Upgrade authority
        auth_rank = {"inferred": 0, "system": 1, "explicit": 2}
        if auth_rank.get(remove.get("authority", "inferred"), 0) > auth_rank.get(keep.get("authority", "inferred"), 0):
            keep["authority"] = remove["authority"]

        # Keep earliest first_seen
        if remove.get("first_seen", "z") < keep.get("first_seen", "z"):
            keep["first_seen"] = remove["first_seen"]

        # Sum access counts
        keep["access_count"] = keep.get("access_count", 0) + remove.get("access_count", 0)

        # Remove the merged entity
        del self._entities[slug_remove]

        # Rebuild indexes
        self._rebuild_indexes()
        self._dirty = True

        log.info("Merged entity '%s' into '%s'", slug_remove, slug_keep)
        return True

    def get_slug_redirect(self, old_slug: str) -> str | None:
        """Check if a slug was merged into another entity.

        After merge, the old slug's canonical name becomes an alias of the kept entity.
        This allows callers to find the new slug for a merged entity.
        """
        # Check alias index — merged entity's name is stored as alias
        for alias_lower, slug in self._alias_index.items():
            if _slugify(alias_lower) == old_slug:
                return slug
        return None

    def upgrade_authority(self, slug: str, new_authority: str) -> bool:
        """Upgrade authority for an entity (never downgrades)."""
        ent = self._entities.get(slug)
        if not ent:
            return False
        auth_rank = {"inferred": 0, "system": 1, "explicit": 2}
        if auth_rank.get(new_authority, 0) > auth_rank.get(ent.get("authority", "inferred"), 0):
            ent["authority"] = new_authority
            self._dirty = True
            return True
        return False

    # ── Decay ──

    def mark_decayed(self, slug: str) -> None:
        """Mark an entity as decayed."""
        ent = self._entities.get(slug)
        if ent and ent.get("status") != "decayed":
            ent["status"] = "decayed"
            ent["decayed_at"] = _now_iso()
            self._dirty = True

    # ── Search ──

    def search(self, query: str, limit: int = 20) -> list[dict]:
        """Search entities by name/alias. Returns list of matches."""
        query_lower = query.lower()
        results = []

        for slug, ent in self._entities.items():
            if ent.get("status") == "decayed":
                continue
            name = ent["canonical_name"]
            match = query_lower in name.lower()
            if not match:
                match = any(query_lower in a.lower() for a in ent.get("aliases", []))
            if match:
                results.append({
                    "slug": slug,
                    "name": name,
                    "entity_type": ent.get("entity_type", "thing"),
                    "authority": ent.get("authority", "inferred"),
                    "aliases": ent.get("aliases", []),
                    "access_count": ent.get("access_count", 0),
                })

        _auth_rank = {"explicit": 2, "system": 1, "inferred": 0}
        results.sort(key=lambda x: (
            _auth_rank.get(x.get("authority", "inferred"), 0),
            x.get("access_count", 0),
        ), reverse=True)
        return results[:limit]

    def list_all(self, include_decayed: bool = False) -> list[dict]:
        """List all entities."""
        results = []
        for slug, ent in self._entities.items():
            if not include_decayed and ent.get("status") == "decayed":
                continue
            results.append({"slug": slug, **ent})
        return results

    # ── Stats ──

    def stats(self) -> dict:
        """Entity statistics."""
        active = [e for e in self._entities.values() if e.get("status", "active") == "active"]
        decayed = [e for e in self._entities.values() if e.get("status") == "decayed"]

        type_counts: dict[str, int] = {}
        for ent in active:
            etype = ent.get("entity_type", "thing")
            type_counts[etype] = type_counts.get(etype, 0) + 1

        authority_counts: dict[str, int] = {}
        for ent in active:
            auth = ent.get("authority", "inferred")
            authority_counts[auth] = authority_counts.get(auth, 0) + 1

        return {
            "total": len(self._entities),
            "active": len(active),
            "decayed": len(decayed),
            "by_type": type_counts,
            "by_authority": authority_counts,
        }

    @property
    def entities(self) -> dict[str, dict[str, Any]]:
        """Direct access to entity data (for graph building)."""
        return self._entities

    @property
    def dirty(self) -> bool:
        return self._dirty

    @dirty.setter
    def dirty(self, value: bool) -> None:
        self._dirty = value
