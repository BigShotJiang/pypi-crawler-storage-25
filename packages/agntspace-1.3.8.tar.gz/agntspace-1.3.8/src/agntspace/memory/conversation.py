"""Conversation memory with SQLite persistence."""

from __future__ import annotations

import logging
import uuid
from datetime import UTC, datetime

import aiosqlite

from agntspace.llm.base import Message

log = logging.getLogger(__name__)


class ConversationMemory:
    """Manages conversation history in SQLite."""

    def __init__(self, db: aiosqlite.Connection) -> None:
        self._db = db

    async def create_conversation(
        self, title: str | None = None, conversation_id: str | None = None
    ) -> str:
        """Create a new conversation. Returns conversation ID."""
        cid = conversation_id or uuid.uuid4().hex
        now = datetime.now(UTC).isoformat()
        await self._db.execute(
            "INSERT INTO conversations (id, title, created_at, updated_at) VALUES (?, ?, ?, ?)",
            (cid, title or "New conversation", now, now),
        )
        await self._db.commit()
        return cid

    async def add_message(
        self, conversation_id: str, role: str, content: str
    ) -> str:
        """Store a message. Returns message ID."""
        mid = uuid.uuid4().hex
        now = datetime.now(UTC).isoformat()
        token_count = len(content) // 4  # rough approximation
        await self._db.execute(
            "INSERT INTO messages (id, conversation_id, role, content, created_at, token_count) "
            "VALUES (?, ?, ?, ?, ?, ?)",
            (mid, conversation_id, role, content, now, token_count),
        )
        await self._db.execute(
            "UPDATE conversations SET updated_at = ? WHERE id = ?",
            (now, conversation_id),
        )
        await self._db.commit()
        return mid

    async def get_messages(
        self, conversation_id: str, limit: int = 50
    ) -> list[Message]:
        """Get recent messages for a conversation, ordered by time."""
        cursor = await self._db.execute(
            "SELECT role, content FROM messages "
            "WHERE conversation_id = ? ORDER BY created_at ASC LIMIT ?",
            (conversation_id, limit),
        )
        rows = await cursor.fetchall()
        return [Message(role=row[0], content=row[1]) for row in rows]

    async def get_context_messages(
        self, conversation_id: str, max_tokens: int = 8000
    ) -> list[Message]:
        """Get messages that fit within a token budget.

        Takes the most recent messages up to max_tokens.
        Token count approximated as len(content) / 4.
        Uses SQL LIMIT to avoid fetching entire conversation history.
        """
        # Fetch at most 100 recent messages — far more than any token budget needs
        cursor = await self._db.execute(
            "SELECT role, content, token_count FROM messages "
            "WHERE conversation_id = ? ORDER BY created_at DESC LIMIT 100",
            (conversation_id,),
        )
        rows = await cursor.fetchall()

        selected: list[Message] = []
        total_tokens = 0
        for row in rows:
            tokens = row[2] or len(row[1]) // 4
            if total_tokens + tokens > max_tokens:
                break
            selected.append(Message(role=row[0], content=row[1]))
            total_tokens += tokens

        selected.reverse()  # oldest first
        return selected

    async def list_conversations(self, limit: int = 20, include_archived: bool = False) -> list[dict]:
        """List recent conversations with metadata."""
        if include_archived:
            query = "SELECT id, title, created_at, updated_at, archived FROM conversations ORDER BY updated_at DESC LIMIT ?"
        else:
            query = "SELECT id, title, created_at, updated_at, archived FROM conversations WHERE archived = 0 ORDER BY updated_at DESC LIMIT ?"
        cursor = await self._db.execute(query, (limit,))
        rows = await cursor.fetchall()
        return [
            {
                "id": row[0],
                "title": row[1],
                "created_at": row[2],
                "updated_at": row[3],
                "archived": bool(row[4]) if len(row) > 4 else False,
            }
            for row in rows
        ]

    async def archive_conversation(self, conversation_id: str) -> None:
        """Archive a conversation (hidden from default list, not deleted)."""
        await self._db.execute(
            "UPDATE conversations SET archived = 1 WHERE id = ?",
            (conversation_id,),
        )
        await self._db.commit()

    async def unarchive_conversation(self, conversation_id: str) -> None:
        """Restore an archived conversation."""
        await self._db.execute(
            "UPDATE conversations SET archived = 0 WHERE id = ?",
            (conversation_id,),
        )
        await self._db.commit()

    async def delete_conversation(self, conversation_id: str) -> None:
        """Permanently delete a conversation and all its messages."""
        await self._db.execute("DELETE FROM messages WHERE conversation_id = ?", (conversation_id,))
        await self._db.execute("DELETE FROM conversations WHERE id = ?", (conversation_id,))
        await self._db.commit()

    async def update_title(self, conversation_id: str, title: str) -> None:
        """Update a conversation's title."""
        await self._db.execute(
            "UPDATE conversations SET title = ? WHERE id = ?",
            (title, conversation_id),
        )
        await self._db.commit()

    async def auto_title(self, conversation_id: str, llm=None) -> str | None:
        """Auto-generate a title from the conversation using LLM.

        Only updates if current title is 'New conversation'.
        Uses the LLM to create a short descriptive title from the
        first user message and assistant response.
        Returns the new title or None if not changed.
        """
        cursor = await self._db.execute(
            "SELECT title FROM conversations WHERE id = ?", (conversation_id,),
        )
        row = await cursor.fetchone()
        if not row or row[0] != "New conversation":
            return None

        # Grab first few messages for context
        cursor = await self._db.execute(
            "SELECT role, content FROM messages WHERE conversation_id = ? "
            "ORDER BY created_at ASC LIMIT 4",
            (conversation_id,),
        )
        rows = await cursor.fetchall()
        if not rows:
            return None

        # Build a snippet of the conversation for the LLM
        snippet_parts = []
        for role, content in rows:
            # Truncate each message to keep the prompt small
            text = content.strip()[:300]
            snippet_parts.append(f"{role}: {text}")
        snippet = "\n".join(snippet_parts)

        title = None

        if llm:
            try:
                response = await llm.complete(
                    messages=[Message(role="user", content=snippet)],
                    system=(
                        "Generate a short conversation title (max 6 words) that captures "
                        "the topic of this conversation. Return ONLY the title text, "
                        "nothing else. No quotes, no punctuation at the end, no prefix."
                    ),
                    max_tokens=30,
                    temperature=0.3,
                )
                title = response.content.strip().strip('"\'').strip()
                log.debug("LLM auto-title: %r", title)
                # Sanity check — if LLM returned something too long or empty, fall back
                if not title or len(title) > 80:
                    title = None
            except Exception:
                log.exception("Auto-title LLM call failed")  # Don't swallow silently

        if not title:
            # Fallback: truncate first user message
            user_text = rows[0][1].strip()
            title = user_text[:50].rstrip()
            if len(user_text) > 50:
                title += "…"
            title = title.replace("\n", " ")

        if not title:
            return None

        await self.update_title(conversation_id, title)
        return title

    async def conversation_exists(self, conversation_id: str) -> bool:
        """Check if a conversation exists."""
        cursor = await self._db.execute(
            "SELECT 1 FROM conversations WHERE id = ?", (conversation_id,)
        )
        return await cursor.fetchone() is not None
