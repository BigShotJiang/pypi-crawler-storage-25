"""Main agent: ties vault identity, LLM reasoning, and conversation memory together."""

from __future__ import annotations

import asyncio
import contextlib
import logging
import time
from collections.abc import AsyncIterator
from typing import TYPE_CHECKING

from agntspace.llm.base import LLMProvider, StreamChunk
from agntspace.llm.prompt import build_system_prompt
from agntspace.memory.conversation import ConversationMemory
from agntspace.vault.reader import VaultReader

if TYPE_CHECKING:
    from agntspace.agent.registry import ToolRegistry
    from agntspace.agent.tools import ToolExecutor
    from agntspace.automation.heartbeat import Heartbeat
    from agntspace.journal.service import JournalService
    from agntspace.memory.engine import MemoryEngine
    from agntspace.projects.service import ProjectService
    from agntspace.skills.loader import SkillLoader
    from agntspace.tasks.service import TaskService
    from agntspace.trust.service import TrustService

log = logging.getLogger(__name__)


class Agent:
    """The main AgntSpace agent.

    Loads identity from vault files, maintains conversation context,
    and delegates reasoning to an LLM provider.
    """

    def __init__(
        self,
        llm: LLMProvider,
        memory: ConversationMemory,
        vault: VaultReader,
        journal: JournalService | None = None,
        task_service: TaskService | None = None,
        trust_service: TrustService | None = None,
        tool_executor: ToolExecutor | None = None,
        memory_engine: MemoryEngine | None = None,
        skill_loader: SkillLoader | None = None,
        heartbeat: Heartbeat | None = None,
        registry: ToolRegistry | None = None,
        project_service: ProjectService | None = None,
        local_mode: bool = False,
        cost_tracker: object | None = None,
    ) -> None:
        self._llm = llm
        self._memory = memory
        self._vault = vault
        self._journal = journal
        self._task_service = task_service
        self._trust_service = trust_service
        self._tool_executor = tool_executor
        self._memory_engine = memory_engine
        self._skill_loader = skill_loader
        self._heartbeat = heartbeat
        self._registry = registry
        self._project_service = project_service
        self._local_mode = local_mode
        self._cost_tracker = cost_tracker
        self._system_prompt: str | None = None
        self._identity_mtimes: dict[str, float] = {}
        self._last_identity_check: float = 0
        _IDENTITY_CHECK_COOLDOWN = 5.0  # seconds between file-stat checks

    async def initialize(self) -> None:
        """Load identity files and build the system prompt.

        Called at startup and automatically re-invoked when identity files change.
        """
        identity = self._vault.read_identity_files()
        self._snapshot_identity_mtimes()

        if "SOUL" not in identity:
            log.warning("SOUL.md not found in vault — agent has no identity")

        # Gather live context
        journal_today = None
        if self._journal:
            with contextlib.suppress(Exception):
                doc = self._journal.get_today()
                journal_today = doc.content

        active_tasks = None
        if self._task_service:
            with contextlib.suppress(Exception):
                active_tasks = [
                    t for t in self._task_service.list_tasks()
                    if t.get("status") not in ("done", "cancelled")
                ]

        active_projects = None
        if self._project_service:
            with contextlib.suppress(Exception):
                active_projects = [
                    p for p in self._project_service.list_projects()
                    if p.get("status") not in ("completed", "archived")
                ]

        trust_summary = None
        if self._trust_service:
            try:
                trust_data = self._trust_service.get_trust_data()
                if trust_data:
                    trust_summary = ", ".join(
                        f"{t['domain']}: {t['level']}" for t in trust_data
                    )
            except Exception:
                pass

        skills_summary = None
        if self._skill_loader:
            with contextlib.suppress(Exception):
                skills_summary = self._skill_loader.get_full_prompt_section()

        # Get capabilities and integrations from registry (auto-discovers everything)
        capabilities_text = None
        connected = None
        if self._registry:
            capabilities_text = self._registry.get_capabilities_text()
            connected = self._registry.get_connected_integrations() or None

        self._system_prompt = build_system_prompt(
            soul=identity["SOUL"].content if "SOUL" in identity else "",
            user=identity["USER"].content if "USER" in identity else "",
            contract=identity["CONTRACT"].content if "CONTRACT" in identity else "",
            memory=identity["MEMORY"].content if "MEMORY" in identity else "",
            profile=identity["PROFILE"].content if "PROFILE" in identity else None,
            journal_today=journal_today,
            active_tasks=active_tasks,
            active_projects=active_projects,
            trust_summary=trust_summary,
            skills_summary=skills_summary,
            connected_integrations=connected,
            capabilities_text=capabilities_text,
            local_mode=self._local_mode,
            skills_dir=str(self._skill_loader._skills_dir) if self._skill_loader else None,
        )
        log.debug(
            "Agent initialized — system prompt: %d chars, identity files: %s",
            len(self._system_prompt),
            ", ".join(identity.keys()),
        )

    # ── Identity file hot-reload ──

    _IDENTITY_PATHS = [
        "agnt-system/identity/SOUL.md",
        "agnt-system/identity/USER.md",
        "agnt-system/identity/PROFILE.md",
        "agnt-memory/MEMORY.md",
    ]

    def _snapshot_identity_mtimes(self) -> None:
        """Record current mtimes of identity files."""
        for rel in self._IDENTITY_PATHS:
            path = self._vault._vault_dir / rel
            try:
                self._identity_mtimes[rel] = path.stat().st_mtime if path.is_file() else 0
            except OSError:
                self._identity_mtimes[rel] = 0

    def _identity_files_changed(self) -> bool:
        """Check if any identity file has been modified since last snapshot."""
        for rel in self._IDENTITY_PATHS:
            path = self._vault._vault_dir / rel
            try:
                mtime = path.stat().st_mtime if path.is_file() else 0
            except OSError:
                mtime = 0
            if mtime != self._identity_mtimes.get(rel, 0):
                return True
        return False

    async def _ensure_fresh_prompt(self) -> None:
        """Re-build system prompt if identity files changed on disk.

        Checks at most every 5 seconds to avoid stat() on every message.
        """
        now = time.monotonic()
        if (now - self._last_identity_check) < 5.0:
            return
        self._last_identity_check = now
        if self._identity_files_changed():
            log.info("Identity files changed on disk — rebuilding system prompt")
            await self.initialize()

    async def chat(self, conversation_id: str, user_message: str) -> str:
        """Non-streaming chat with tool use. Provider-independent.

        Uses the LLM abstraction layer — works with Anthropic, OpenAI, Ollama.
        """
        import json

        from agntspace.llm.base import Message as LLMMessage

        await self._ensure_fresh_prompt()

        # Same tool path for cloud and local
        if self._registry:
            tool_defs = self._registry.get_tool_definitions()
        else:
            from agntspace.agent.tools import TOOL_DEFINITIONS
            tool_defs = TOOL_DEFINITIONS

        valid_tools = {t["name"] for t in tool_defs} if tool_defs else set()

        self._check_journal_candidate(user_message)
        await self._memory.add_message(conversation_id, "user", user_message)
        asyncio.create_task(self._extract_entities(user_message))
        history = await self._memory.get_context_messages(conversation_id)

        from agntspace.llm.base import LLMError

        # Use tool-enabled completion if we have tools
        if tool_defs and self._tool_executor:
            try:
                messages = list(history)  # copy
                max_rounds = 5

                for _ in range(max_rounds):
                    response = await self._llm.complete_with_tools(
                        messages=messages,
                        tools=tool_defs,
                        system=self._system_prompt,
                    )

                    # Check if LLM wants to use tools
                    if response.tool_calls:
                        # Validate tool names — local models may hallucinate
                        invalid = [tc for tc in response.tool_calls if tc.name not in valid_tools]
                        if invalid:
                            log.warning("Hallucinated tool calls: %s", ", ".join(tc.name for tc in invalid))
                            break  # fall through to basic completion

                        # Append assistant response with raw content
                        messages.append(LLMMessage(role="assistant", content=response.raw_content or response.content))

                        # Execute each tool call and send results back
                        for tc in response.tool_calls:
                            log.info("Tool call: %s(%s)", tc.name, json.dumps(tc.input)[:100])
                            result = await self._execute_tool(tc.name, tc.input)
                            await self._record_pulse("tool_use", f"{tc.name}")
                            # Use "tool" role with tool_call_id (OpenAI/LiteLLM format)
                            messages.append(LLMMessage(
                                role="tool",
                                content=json.dumps(result),
                                tool_call_id=tc.id,
                            ))

                        continue

                    # No tool calls — final response
                    final_text = response.content
                    await self._memory.add_message(conversation_id, "assistant", final_text)
                    await self._extract_entities(final_text, is_user=False)
                    log.info("Chat (tools): %d in, %d out tokens", response.input_tokens, response.output_tokens)
                    await self._record_cost(response.input_tokens, response.output_tokens, conversation_id, "chat")
                    await self._record_pulse("chat", f"Response: {final_text[:80]}")
                    return final_text

                return "I tried multiple tool calls but couldn't complete. Please try again."

            except LLMError:
                raise  # surface to caller with clear reason
            except Exception:
                log.exception("Tool-enabled chat failed, falling back to basic")

        # Fallback: basic completion without tools
        try:
            response = await self._llm.complete(
                messages=history,
                system=self._system_prompt,
            )
        except LLMError:
            raise  # surface to caller with clear reason
        await self._memory.add_message(conversation_id, "assistant", response.content)
        await self._record_pulse("chat", f"Response: {response.content[:80]}")
        return response.content

    async def process_task(self, task: str, context: str = "") -> str:
        """Process an internal system task using the agent's full capabilities.

        Like chat() but does NOT save to conversation memory — intended for
        automation tasks (daily briefing, EOD, reflections, memory compaction)
        that should not appear in the user's chat history.

        The agent's full system prompt (identity, skills, memory) is used,
        and tools are available for the agent to call during processing.
        """
        import json

        from agntspace.llm.base import LLMError
        from agntspace.llm.base import Message as LLMMessage

        # Build the user message from task + context
        if context:
            user_content = f"{context}\n\n---\n\n{task}"
        else:
            user_content = task

        messages = [LLMMessage(role="user", content=user_content)]

        # Get tool definitions — skip for local mode (small models hallucinate
        # tool JSON instead of generating content; automation tasks have
        # pre-gathered context and don't need tools)
        tool_defs = None
        if self._registry and self._tool_executor and not self._local_mode:
            tool_defs = self._registry.get_tool_definitions()
        valid_tools = {t["name"] for t in tool_defs} if tool_defs else set()

        if tool_defs and self._tool_executor:
            try:
                max_rounds = 5
                for _ in range(max_rounds):
                    response = await self._llm.complete_with_tools(
                        messages=messages,
                        tools=tool_defs,
                        system=self._system_prompt,
                    )

                    if response.tool_calls:
                        invalid = [tc for tc in response.tool_calls if tc.name not in valid_tools]
                        if invalid:
                            log.warning("process_task: hallucinated tool calls: %s", ", ".join(tc.name for tc in invalid))
                            break

                        messages.append(LLMMessage(role="assistant", content=response.raw_content or response.content))

                        for tc in response.tool_calls:
                            log.info("process_task tool: %s(%s)", tc.name, json.dumps(tc.input)[:100])
                            result = await self._execute_tool(tc.name, tc.input)
                            await self._record_pulse("tool_use", f"{tc.name}")
                            messages.append(LLMMessage(
                                role="tool",
                                content=json.dumps(result),
                                tool_call_id=tc.id,
                            ))
                        continue

                    # No tool calls — final response
                    final_text = response.content
                    if self._is_junk_response(final_text):
                        log.warning("process_task: LLM returned junk JSON instead of content, falling back to basic")
                        break
                    await self._extract_entities(final_text, is_user=False)
                    log.info("process_task: %d in, %d out tokens", response.input_tokens, response.output_tokens)
                    await self._record_cost(response.input_tokens, response.output_tokens, action="process_task")
                    await self._record_pulse("automation", f"process_task: {task[:80]}")
                    return final_text

                # Exhausted tool rounds or junk response — fall through to basic completion
                log.warning("process_task: tool loop ended without clean response, falling back to basic")

            except LLMError:
                raise
            except Exception:
                log.exception("process_task tool loop failed, falling back to basic")

        # Fallback: basic completion without tools
        try:
            response = await self._llm.complete(
                messages=messages,
                system=self._system_prompt,
            )
        except LLMError:
            raise
        await self._extract_entities(response.content, is_user=False)
        await self._record_cost(response.input_tokens, response.output_tokens, action="process_task")
        await self._record_pulse("automation", f"process_task: {task[:80]}")
        return response.content

    async def chat_stream(
        self, conversation_id: str, user_message: str
    ) -> AsyncIterator[StreamChunk]:
        """Streaming chat with tool use support.

        Tool calls are executed non-streaming in a loop. Once the LLM
        produces a final text response (no more tool calls), that
        response is streamed to the client.
        """
        import json

        from agntspace.llm.base import LLMError
        from agntspace.llm.base import Message as LLMMessage

        await self._ensure_fresh_prompt()
        self._check_journal_candidate(user_message)
        await self._memory.add_message(conversation_id, "user", user_message)
        # Fire-and-forget entity extraction — don't block the response
        asyncio.create_task(self._extract_entities(user_message))
        history = await self._memory.get_context_messages(conversation_id)

        # Get tool definitions — same path for cloud and local (cached)
        tool_defs = None
        if self._registry and self._tool_executor:
            tool_defs = self._registry.get_tool_definitions()

        # Build set of valid tool names for hallucination detection
        valid_tools = {t["name"] for t in tool_defs} if tool_defs else set()

        try:
            if tool_defs and self._tool_executor:
                # Tool-enabled path: run tool loop non-streaming, then stream the final answer
                messages = list(history)
                max_rounds = 5
                last_tool_results: dict[str, str] = {}  # tool_name → result json

                for _ in range(max_rounds):
                    response = await self._llm.complete_with_tools(
                        messages=messages,
                        tools=tool_defs,
                        system=self._system_prompt,
                    )

                    if response.tool_calls:
                        # Validate tool names — local models may hallucinate
                        invalid = [tc for tc in response.tool_calls if tc.name not in valid_tools]
                        if invalid:
                            log.warning(
                                "Hallucinated tool calls: %s — falling back to conversation",
                                ", ".join(tc.name for tc in invalid),
                            )
                            break  # fall through to streaming

                        # Detect repeated tool call (local models loop instead of summarizing)
                        repeated = any(tc.name in last_tool_results for tc in response.tool_calls)
                        if repeated and self._local_mode:
                            log.info("Local model repeated tool call — summarizing previous result")
                            # Use the last tool result to generate a summary
                            tool_name = response.tool_calls[0].name
                            result_json = last_tool_results[tool_name]
                            if len(result_json) > 2000:
                                result_json = result_json[:2000] + "..."
                            summary_msgs = list(history) + [
                                LLMMessage(
                                    role="user",
                                    content=f"I asked: {user_message}\n\nThe tool `{tool_name}` returned:\n{result_json}\n\nSummarize this result concisely for the user.",
                                ),
                            ]
                            full_response = ""
                            async for chunk in self._llm.stream(messages=summary_msgs, system=self._system_prompt):
                                full_response += chunk.delta
                                yield chunk
                                if chunk.done:
                                    await self._memory.add_message(conversation_id, "assistant", full_response)
                            return

                        messages.append(LLMMessage(
                            role="assistant",
                            content=response.raw_content or response.content,
                        ))

                        for tc in response.tool_calls:
                            log.info("Tool call (stream): %s(%s)", tc.name, json.dumps(tc.input)[:100])
                            yield StreamChunk(delta="", tool_name=tc.name, tool_status="running")
                            result = await self._execute_tool(tc.name, tc.input)
                            await self._record_pulse("tool_use", f"{tc.name}")
                            result_str = json.dumps(result)
                            last_tool_results[tc.name] = result_str
                            yield StreamChunk(delta="", tool_name=tc.name, tool_status="done")
                            messages.append(LLMMessage(
                                role="tool",
                                content=result_str,
                                tool_call_id=tc.id,
                            ))
                        continue

                    # No tool calls — stream the final text response
                    final_text = response.content
                    # Detect junk output from local models (raw JSON, empty braces)
                    is_junk = self._local_mode and (
                        not final_text.strip()
                        or final_text.strip() in ("{}", "[]", "null")
                        or (final_text.strip().startswith('{"type"') and '"function"' in final_text)
                    )
                    if is_junk and last_tool_results:
                        log.info("Empty response after tool call — summarizing")
                        tool_name, result_json = next(iter(last_tool_results.items()))
                        if len(result_json) > 2000:
                            result_json = result_json[:2000] + "..."
                        summary_msgs = list(history) + [
                            LLMMessage(
                                role="user",
                                content=f"I asked: {user_message}\n\nThe tool `{tool_name}` returned:\n{result_json}\n\nSummarize this result concisely for the user.",
                            ),
                        ]
                        full_response = ""
                        async for chunk in self._llm.stream(messages=summary_msgs, system=self._system_prompt):
                            full_response += chunk.delta
                            yield chunk
                            if chunk.done:
                                await self._memory.add_message(conversation_id, "assistant", full_response)
                        return

                    # Junk output with no tool results — fall through to plain streaming
                    if is_junk:
                        log.info("Junk output from local model (%s) — falling to plain streaming", repr(final_text.strip()))
                        break

                    # Stream it chunk by chunk for a natural feel
                    chunk_size = 12
                    for i in range(0, len(final_text), chunk_size):
                        piece = final_text[i : i + chunk_size]
                        yield StreamChunk(delta=piece)

                    # Save message and send done BEFORE slow post-processing
                    await self._memory.add_message(conversation_id, "assistant", final_text)
                    log.info(
                        "Stream response (tools): %d in, %d out tokens",
                        response.input_tokens, response.output_tokens,
                    )
                    yield StreamChunk(delta="", done=True, response=response)

                    # Post-processing — don't block the done signal
                    await self._extract_entities(final_text, is_user=False)
                    await self._record_cost(response.input_tokens, response.output_tokens, conversation_id, "chat_stream")
                    await self._record_pulse("chat", f"Response: {final_text[:80]}")
                    return

                # Fell through — either exhausted rounds or hallucinated tools
                # For local mode: try intent matching as fallback, or summarize any tool results
                if self._local_mode:
                    if last_tool_results:
                        log.info("Exhausted rounds with tool results — summarizing")
                        tool_name, result_json = next(iter(last_tool_results.items()))
                        if len(result_json) > 2000:
                            result_json = result_json[:2000] + "..."
                        summary_msgs = list(history) + [
                            LLMMessage(
                                role="user",
                                content=f"I asked: {user_message}\n\nThe tool `{tool_name}` returned:\n{result_json}\n\nSummarize this result concisely for the user.",
                            ),
                        ]
                        full_response = ""
                        async for chunk in self._llm.stream(messages=summary_msgs, system=self._system_prompt):
                            full_response += chunk.delta
                            yield chunk
                            if chunk.done:
                                await self._memory.add_message(conversation_id, "assistant", full_response)
                        return

                    intent = self._match_local_intent(user_message)
                    if intent:
                        tool_name, tool_input = intent
                        log.info("Intent fallback: %s(%s)", tool_name, json.dumps(tool_input)[:100])
                        yield StreamChunk(delta=f"Running {tool_name}...\n\n")
                        result = await self._execute_local_tool(tool_name, tool_input)
                        await self._record_pulse("tool_use", tool_name)
                        result_json = json.dumps(result, default=str)
                        if len(result_json) > 2000:
                            result_json = result_json[:2000] + "..."
                        summary_msgs = list(history) + [
                            LLMMessage(
                                role="user",
                                content=f"I asked: {user_message}\n\nThe tool `{tool_name}` returned:\n{result_json}\n\nSummarize this result concisely for the user.",
                            ),
                        ]
                        full_response = ""
                        async for chunk in self._llm.stream(messages=summary_msgs, system=self._system_prompt):
                            full_response += chunk.delta
                            yield chunk
                            if chunk.done:
                                await self._memory.add_message(conversation_id, "assistant", full_response)
                        return

                # No intent match either — fall through to plain streaming

            # No tools or fallback — pure streaming
            full_response = ""
            async for chunk in self._llm.stream(
                messages=history,
                system=self._system_prompt,
            ):
                full_response += chunk.delta
                yield chunk
                if chunk.done:
                    await self._memory.add_message(
                        conversation_id, "assistant", full_response
                    )
                    if chunk.response:
                        log.info(
                            "Stream response: %d input tokens, %d output tokens",
                            chunk.response.input_tokens,
                            chunk.response.output_tokens,
                        )
                        await self._record_cost(
                            chunk.response.input_tokens,
                            chunk.response.output_tokens,
                            conversation_id, "chat_stream",
                        )

        except LLMError as e:
            error_msg = f"⚠ {e.user_message}"
            await self._memory.add_message(conversation_id, "assistant", error_msg)
            yield StreamChunk(delta=error_msg, done=True)
        except Exception as e:
            log.exception("Streaming failed")
            error_msg = f"⚠ Unexpected error: {e!s}"
            yield StreamChunk(delta=error_msg, done=True)

    async def _execute_tool(self, tool_name: str, tool_input: dict) -> dict:
        """Execute a tool call — handles built-in, registry, and MCP tools."""
        # MCP external tools (mcp_servername_toolname)
        if tool_name.startswith("mcp_") and self._registry and self._registry._mcp_client:
            try:
                return await self._registry._mcp_client.call_tool(tool_name, tool_input)
            except Exception as e:
                log.exception("MCP tool execution failed: %s", tool_name)
                return {"error": f"MCP tool failed: {e}"}
        # Local mode uses async handlers to avoid deadlocks
        if self._local_mode:
            return await self._execute_local_tool(tool_name, tool_input)
        # Standard sync execution
        if self._tool_executor:
            return self._tool_executor.execute(tool_name, tool_input)
        return {"error": f"No executor available for {tool_name}"}

    async def _execute_local_tool(self, tool_name: str, tool_input: dict) -> dict:
        """Execute a tool in local mode. Tries registry first, then tool executor.

        Uses async_handler when available (we're already in an event loop,
        so sync wrappers that call run_until_complete would deadlock).
        """
        # Registry has dynamically registered tools (run_wiki_job, etc.)
        if self._registry:
            tool = self._registry._tools.get(tool_name)
            if tool:
                # Contract check
                if tool.contract_action and self._registry._contract:
                    check = self._registry._contract.check(tool.contract_action)
                    if not check.allowed:
                        return {"error": f"Contract blocked: {check.reason}"}
                # Prefer async handler (avoids run_until_complete deadlock)
                try:
                    if tool.async_handler:
                        return await tool.async_handler(tool_input)
                    return tool.handler(tool_input)
                except Exception as e:
                    log.exception("Local tool execution failed: %s", tool_name)
                    return {"error": str(e)}

        # Fall back to built-in tool executor
        if self._tool_executor:
            return self._tool_executor.execute(tool_name, tool_input)
        return {"error": f"No executor available for {tool_name}"}

    def _load_local_intents(self) -> list[dict]:
        """Load intent patterns from the local-intents skill config."""
        if hasattr(self, "_local_intents_cache"):
            return self._local_intents_cache

        import yaml

        intents = []
        # Search skills directories for local-intents config
        if self._skill_loader:
            skills_dir = self._skill_loader._skills_dir
            config_path = skills_dir / "_meta" / "local-intents" / "config" / "intents.yaml"
            if config_path.is_file():
                try:
                    with open(config_path) as f:
                        intents = yaml.safe_load(f) or []
                    log.info("Loaded %d local intents from %s", len(intents), config_path)
                except Exception:
                    log.warning("Failed to load local intents config", exc_info=True)

        self._local_intents_cache = intents
        return intents

    def _match_local_intent(self, message: str) -> tuple[str, dict] | None:
        """Match user message to a tool call using skill-defined intent patterns.

        Returns (tool_name, tool_input) or None if no match.
        Patterns are loaded from skills/_meta/local-intents/config/intents.yaml.
        """
        import re

        msg = message.lower().strip()
        intents = self._load_local_intents()

        for intent in intents:
            patterns = intent.get("patterns", [])
            for pattern in patterns:
                if re.search(pattern, msg, re.IGNORECASE):
                    tool = intent["tool"]
                    params = dict(intent.get("params", {}))

                    # Extract dynamic parameter if configured
                    extract = intent.get("param_extract")
                    param_key = intent.get("param_key")
                    if extract and param_key:
                        m = re.search(extract, msg, re.IGNORECASE)
                        if m:
                            params[param_key] = m.group(1).strip() if m.lastindex else msg

                    return (tool, params)

        return None

    async def _record_cost(
        self, input_tokens: int, output_tokens: int,
        conversation_id: str | None = None, action: str = "chat",
        model: str | None = None,
    ) -> None:
        """Record token cost if cost tracker is available."""
        if not self._cost_tracker:
            return
        try:
            actual_model = model or getattr(self._llm, "_model", "unknown")
            await self._cost_tracker.record(
                model=actual_model,
                input_tokens=input_tokens,
                output_tokens=output_tokens,
                conversation_id=conversation_id,
                action=action,
            )
        except Exception:
            pass

    @staticmethod
    def _is_junk_response(text: str) -> bool:
        """Detect junk JSON that small models output instead of real content.

        Local models (especially small ones) sometimes emit raw tool call JSON,
        schema definitions, or empty objects instead of following instructions.
        """
        if not text or not text.strip():
            return True
        stripped = text.strip()
        # Raw JSON object (tool call, schema, empty)
        if stripped.startswith("{") and stripped.endswith("}"):
            if any(k in stripped for k in ('"function"', '"type":', '"$schema"', '"name":', '"parameters"')):
                return True
            if len(stripped) < 20:  # e.g. {} or {"type": "text"}
                return True
        # JSON array of tool calls
        if stripped.startswith("[") and '"function"' in stripped:
            return True
        return False

    async def _record_pulse(self, pulse_type: str, details: str | None = None) -> None:
        """Record agent activity as a pulse on the cardiogram."""
        if self._heartbeat:
            try:
                await self._heartbeat.record_pulse(pulse_type, details)
            except Exception:
                pass

    async def _extract_entities(self, message: str, is_user: bool = True) -> None:
        """Extract entities and triples from messages in real-time.

        User messages: authority=explicit (user stated it)
        Assistant messages: authority=system (agent synthesized it)
        Fast regex runs always. LLM triple extraction for 50+ word messages.
        """
        if not self._memory_engine:
            return
        try:
            links = await self._memory_engine.extract_from_conversation(message, is_user=is_user)
            if links:
                log.debug("Entities extracted (%s): %s",
                          "user" if is_user else "assistant", ", ".join(links))
        except Exception:
            log.debug("Entity extraction failed", exc_info=True)

    def _check_journal_candidate(self, message: str) -> None:
        """Check if a message is thinking-out-loud and flag it for journaling."""
        if not self._journal:
            return
        from agntspace.journal.service import JournalService

        if JournalService.is_thinking_out_loud(message):
            log.info("Thinking-out-loud detected: %s...", message[:60])
            # The agent's system prompt tells it to ask "Save to journal?"
            # Actual saving happens when user confirms via the journal API
