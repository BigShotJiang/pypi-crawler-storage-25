"""Journal service: user journal + agent observations, always separate files."""

from __future__ import annotations

import re
from datetime import UTC, datetime
from pathlib import Path

from agntspace.vault.reader import VaultDocument, VaultReader
from agntspace.vault.writer import VaultWriter

_USER_SECTIONS = ("Focus", "Mood", "Gratitude", "Thoughts", "Notes", "Questions", "Decisions", "Learnings", "Blockers", "Reflections")
_AGENT_SECTIONS = ("Observations", "Actions", "Notes")

_USER_TEMPLATE = """---
title: "Journal — {date}"
date: "{date}"
author: user
description: "Your daily journal — thoughts, notes, decisions, mood, and reflections."
---

## Focus
<!-- What you want to focus on today. The agent reads this for your morning briefing. -->

## Mood
<!-- How are you feeling? Energy level? One word or a sentence. -->

## Gratitude
<!-- What went well? What are you thankful for today? -->

## Thoughts
<!-- Your thinking space. Ideas, observations, thinking out loud. -->

## Notes
<!-- Quick captures, links, references — anything that doesn't fit elsewhere. -->

## Questions
<!-- Open questions to explore. The agent can help research these. -->

## Decisions
<!-- Decisions you've made today with reasoning. -->

## Learnings
<!-- Things you discovered worth remembering. -->

## Blockers
<!-- What's stuck? What do you need help with? The agent can act on these. -->

## Reflections
<!-- End-of-day personal reflections. How did the day go? -->
"""

_AGENT_TEMPLATE = """---
title: "Agent Observations — {date}"
date: "{date}"
type: agent_observations
author: agent
agent: main
description: "What the agent noticed today — events, patterns, actions taken."
---

## Observations
<!-- What the agent noticed today: events, patterns, state changes. -->

## Actions
<!-- What the agent did: tasks started, emails sent, briefings generated. -->

## Notes
<!-- Agent-generated context: summaries, connections, follow-ups. -->
"""


class JournalService:
    """Manages daily journal entries in vault/journal/.

    User and agent content live in separate files:
    - journal/YYYY-MM-DD.md — user writes (thoughts, decisions, learnings)
    - journal/agent-observations_YYYY-MM-DD.md — agent writes (observations, actions)
    """

    def __init__(self, vault_reader: VaultReader, vault_writer: VaultWriter) -> None:
        self._reader = vault_reader
        self._writer = vault_writer

    # ---- Path helpers ----

    def _user_path(self, date: str | None = None) -> str:
        if not date:
            date = datetime.now(UTC).strftime("%Y-%m-%d")
        return f"journal/{date}.md"

    def _agent_path(self, date: str | None = None) -> str:
        if not date:
            date = datetime.now(UTC).strftime("%Y-%m-%d")
        return f"journal/agent-observations_{date}.md"

    def today_path(self) -> str:
        """Return the relative vault path for today's user journal."""
        return self._user_path()

    # ---- Read ----

    def get_today(self) -> VaultDocument:
        """Get or create today's user journal entry."""
        path = self._user_path()
        if not self._reader.exists(path):
            self._create_user_entry(path)
        return self._reader.read(path)

    def get_entry(self, date: str) -> VaultDocument | None:
        """Get a user journal entry by date string (YYYY-MM-DD)."""
        path = self._user_path(date)
        if not self._reader.exists(path):
            return None
        return self._reader.read(path)

    def get_agent_observations(self, date: str | None = None) -> VaultDocument | None:
        """Get agent observations for a date."""
        path = self._agent_path(date)
        if not self._reader.exists(path):
            return None
        return self._reader.read(path)

    def list_entries(self, limit: int = 30) -> list[dict]:
        """List recent user journal entries (newest first)."""
        files = self._reader.list_files("journal", "*.md")
        # Only user journals — exclude agent files
        user_files = [
            f for f in files
            if not f.name.startswith(("agent-", "morning-", "eod-"))
            and f.suffix == ".md"
        ]
        user_files.sort(reverse=True)
        entries = []
        for f in user_files[:limit]:
            entries.append({
                "date": f.stem,
                "path": f"journal/{f.name}",
            })
        return entries

    def list_dates(self, limit: int = 30) -> list[dict]:
        """List recent journal dates with file types and status flags (newest first)."""
        files = self._reader.list_files("journal", "*.md")
        date_map: dict[str, dict] = {}
        _PREFIX_MAP = {
            "agent-observations_": "observations",
            "morning-briefing_": "briefing",
            "eod-report_": "eod",
            "daily-reflection_": "reflection",
            "weekly-reflection_": "weekly_reflection",
        }
        for f in files:
            if f.suffix != ".md":
                continue
            name = f.name
            matched = False
            for prefix, file_type in _PREFIX_MAP.items():
                if name.startswith(prefix):
                    date = name.replace(prefix, "").replace(".md", "")
                    date_map.setdefault(date, {"date": date, "types": [], "flags": []})
                    date_map[date]["types"].append(file_type)
                    matched = True
                    break
            if not matched:
                date = f.stem
                date_map.setdefault(date, {"date": date, "types": [], "flags": []})
                date_map[date]["types"].append("journal")

        # Enrich with status flags (lightweight — only reads metadata/sections, not full content)
        for date, entry in date_map.items():
            flags = entry["flags"]
            # Check reflection status
            if "reflection" in entry["types"]:
                refl_path = f"journal/daily-reflection_{date}.md"
                if self._reader.exists(refl_path):
                    doc = self._reader.read(refl_path)
                    status = doc.metadata.get("status", "")
                    if status == "pending":
                        flags.append("pending_reflection")
                    elif status == "approved":
                        flags.append("approved_reflection")
            # Check for blockers and questions in user journal
            if "journal" in entry["types"]:
                blockers = self.get_section("Blockers", date)
                if blockers:
                    flags.append("has_blockers")
                questions = self.get_section("Questions", date)
                if questions:
                    flags.append("has_questions")

        result = sorted(date_map.values(), key=lambda x: x["date"], reverse=True)
        return result[:limit]

    def get_file_for_date(self, date: str, file_type: str) -> VaultDocument | None:
        """Get a specific journal file type for a date."""
        path_map = {
            "journal": f"journal/{date}.md",
            "observations": f"journal/agent-observations_{date}.md",
            "briefing": f"journal/morning-briefing_{date}.md",
            "eod": f"journal/eod-report_{date}.md",
            "reflection": f"journal/daily-reflection_{date}.md",
            "weekly_reflection": f"journal/weekly-reflection_{date}.md",
        }
        path = path_map.get(file_type)
        if not path or not self._reader.exists(path):
            return None
        return self._reader.read(path)

    def get_section(self, section: str, date: str | None = None) -> str | None:
        """Read a specific section from the user journal."""
        path = self._user_path(date)
        if not self._reader.exists(path):
            return None
        doc = self._reader.read(path)
        # Extract section content between ## headers
        pattern = rf"## {re.escape(section)}\b.*?\n(.*?)(?=\n## |\Z)"
        match = re.search(pattern, doc.raw, re.DOTALL)
        if match:
            content = match.group(1).strip()
            # Strip HTML comments
            content = re.sub(r"<!--.*?-->", "", content, flags=re.DOTALL).strip()
            return content if content else None
        return None

    # ---- User writes (to user journal) ----

    def set_focus(self, text: str) -> None:
        """Set today's focus in the journal."""
        self._append_to_user_section("Focus", f"- {self._timestamp()} — {text}")

    def append_mood(self, text: str) -> None:
        """Append a mood/energy entry to today's journal."""
        self._append_to_user_section("Mood", f"- {self._timestamp()} — {text}")

    def append_gratitude(self, text: str) -> None:
        """Append a gratitude entry to today's journal."""
        self._append_to_user_section("Gratitude", f"- {self._timestamp()} — {text}")

    def append_thought(self, text: str) -> None:
        """Append a user thought to today's journal."""
        self._append_to_user_section("Thoughts", f"- {self._timestamp()} — {text}")

    def append_note(self, text: str) -> None:
        """Append a user note to today's journal."""
        self._append_to_user_section("Notes", f"- {self._timestamp()} — {text}")

    def append_question(self, text: str) -> None:
        """Append an open question to today's journal."""
        self._append_to_user_section("Questions", f"- {self._timestamp()} — {text}")

    def append_decision(self, text: str) -> None:
        """Append a user decision to today's journal."""
        self._append_to_user_section("Decisions", f"- {self._timestamp()} — {text}")

    def append_learning(self, text: str) -> None:
        """Append a user learning to today's journal."""
        self._append_to_user_section("Learnings", f"- {self._timestamp()} — {text}")

    def append_blocker(self, text: str) -> None:
        """Append a blocker to today's journal."""
        self._append_to_user_section("Blockers", f"- {self._timestamp()} — {text}")

    def append_reflection(self, text: str) -> None:
        """Append a personal reflection to today's journal."""
        self._append_to_user_section("Reflections", f"- {self._timestamp()} — {text}")

    # ---- Agent writes (to agent observations file) ----

    def append_observation(self, text: str) -> None:
        """Append an agent observation to today's agent file."""
        self._append_to_agent_section(
            "Observations",
            f"- {self._timestamp()} — {text}",
        )

    def append_action(self, text: str) -> None:
        """Append an agent action to today's agent file."""
        self._append_to_agent_section(
            "Actions",
            f"- {self._timestamp()} — {text}",
        )

    def append_agent_note(self, text: str) -> None:
        """Append an agent note to today's agent file."""
        self._append_to_agent_section(
            "Notes",
            f"- {self._timestamp()} — {text}",
        )

    # ---- Internal ----

    def _append_to_user_section(self, section: str, line: str) -> None:
        """Append a line to a section of today's user journal."""
        path = self._user_path()
        if not self._reader.exists(path):
            self._create_user_entry(path)
        self._append_to_section(path, section, line)

    def _append_to_agent_section(self, section: str, line: str) -> None:
        """Append a line to a section of today's agent observations."""
        path = self._agent_path()
        if not self._reader.exists(path):
            self._create_agent_entry(path)
        self._append_to_section(path, section, line)

    def _append_to_section(self, path: str, section: str, line: str) -> None:
        """Append a line to a specific section of a file."""
        doc = self._reader.read(path)
        content = doc.raw

        # Find the section and append before the next section or end
        pattern = rf"(## {re.escape(section)}\b.*?)(\n## |\Z)"
        match = re.search(pattern, content, re.DOTALL)
        if match:
            section_end = match.end(1)
            new_content = content[:section_end] + "\n" + line + content[section_end:]
            self._writer.write(path, new_content)
        else:
            self._writer.write(path, content + f"\n## {section}\n{line}\n")

    def _create_user_entry(self, path: str) -> None:
        date = Path(path).stem
        self._writer.write(path, _USER_TEMPLATE.format(date=date))

    def _create_agent_entry(self, path: str) -> None:
        date = path.split("_")[-1].replace(".md", "")
        self._writer.write(path, _AGENT_TEMPLATE.format(date=date))

    @staticmethod
    def _timestamp() -> str:
        return datetime.now(UTC).strftime("%H:%M")

    @staticmethod
    def is_thinking_out_loud(text: str) -> bool:
        """Detect if user message sounds like thinking out loud."""
        lower = text.lower().strip()
        patterns = [
            r"^i('m| am) thinking",
            r"^i('m| am) wondering",
            r"^i('m| am) feeling",
            r"^i('ve| have) decided",
            r"^i('ve| have) been thinking",
            r"^note to self",
            r"^i learned",
            r"^i realized",
            r"^i noticed",
            r"^i think i should",
            r"^maybe i should",
            r"^i need to remember",
        ]
        return any(re.match(p, lower) for p in patterns)
