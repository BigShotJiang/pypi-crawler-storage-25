"""Action middleware: the single gate every agent action passes through.

No action in the system executes without going through enforce().
This connects the contract enforcer to every service.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from agntspace.security.contract import ContractEnforcer

log = logging.getLogger(__name__)


class ActionDenied(Exception):
    """Raised when the contract blocks an action."""

    def __init__(self, action: str, reason: str) -> None:
        self.action = action
        self.reason = reason
        super().__init__(f"Contract denied: {action} — {reason}")


class ConfirmationRequired(Exception):
    """Raised when the contract requires user confirmation."""

    def __init__(self, action: str, reason: str) -> None:
        self.action = action
        self.reason = reason
        super().__init__(f"Confirmation needed: {action} — {reason}")


class AgentFrozen(Exception):
    """Raised when emergency stop is active."""

    def __init__(self) -> None:
        super().__init__("Agent is frozen — emergency stop active")


# Global frozen flag — set by emergency stop endpoint
_frozen = False


def set_frozen(value: bool) -> None:
    """Set the global frozen state."""
    global _frozen  # noqa: PLW0603
    _frozen = value


def is_frozen() -> bool:
    """Check if agent is frozen."""
    return _frozen


def enforce(
    contract: ContractEnforcer,
    action: str,
    integration: str | None = None,
    skip_confirmation: bool = False,
) -> None:
    """Enforce the contract for an action. Raises if denied.

    This is the ONE function every operation must call.

    Args:
        contract: The contract enforcer instance
        action: Action identifier (e.g., "send_email", "read_inbox")
        integration: Optional integration name for overrides
        skip_confirmation: If True, confirmation-required actions proceed
                          (use when user has already confirmed)

    Raises:
        AgentFrozen: If emergency stop is active
        ActionDenied: If the contract blocks this action
        ConfirmationRequired: If the action needs user confirmation
    """
    if _frozen:
        raise AgentFrozen

    result = contract.check(action, integration)

    if not result.allowed:
        log.warning("Contract DENIED: %s (integration=%s) — %s", action, integration, result.reason)
        raise ActionDenied(action, result.reason)

    if result.requires_confirmation and not skip_confirmation:
        log.info("Contract CONFIRM needed: %s (integration=%s)", action, integration)
        raise ConfirmationRequired(action, result.reason)

    log.debug("Contract OK: %s (integration=%s)", action, integration)
