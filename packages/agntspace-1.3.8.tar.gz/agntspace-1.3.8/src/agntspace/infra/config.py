"""Application settings — split app home from vault data.

Two distinct locations:
  ~/agntspace/                   ← app_dir (FIXED — config, credentials, logs, db)
  │   ├── config.toml
  │   ├── credentials.json
  │   ├── agntspace.db
  │   └── logs/

  User's Folder/                 ← root_dir (user's choice — vault data)
  ├── agntspace/                 ← vault_dir (identity, journal, wiki, etc.)
  │   ├── identity/
  │   ├── inbox/
  │   ├── journal/, notes/, memory/, kb/, ...
  │   ├── skills/, agents/, security/
  ├── User's Projects/           ← UNTOUCHED
  └── anything else/             ← UNTOUCHED

When root_dir == home, app_dir and vault_dir overlap at ~/agntspace/.
When root_dir is an external folder, config stays at home, data goes there.
"""

from __future__ import annotations

import sys
from pathlib import Path
from typing import Any

from pydantic import BaseModel, Field
from pydantic_settings import BaseSettings, SettingsConfigDict

if sys.version_info >= (3, 12):
    import tomllib
else:
    import tomli as tomllib


class ScheduleSettings(BaseModel):
    """Background automation intervals and timing."""

    heartbeat_seconds: int = 900
    scheduler_seconds: int = 180
    morning_hour: int = 7
    evening_hour: int = 21
    weekly_compaction_day: int = 6


class I18nSettings(BaseModel):
    """Internationalization settings."""

    locale: str = "en"  # en, sv, etc.


class LLMSettings(BaseModel):
    """LLM provider configuration."""

    mode: str = "cloud"
    cloud_provider: str = "anthropic"
    cloud_model: str = "claude-sonnet-4-20250514"
    quality_profile: str = "balanced"  # quality, balanced, economy
    local_provider: str = "ollama"
    local_model: str = "llama3"
    fallback_model: str = ""  # e.g. "openai/gpt-4o" — used when primary fails


class Settings(BaseSettings):
    """Root application settings.

    app_dir:   ~/agntspace/ — FIXED, never moves. Config, creds, logs, DB.
    root_dir:  user's chosen folder (may == home, or an external vault).
    vault_dir: root_dir/agntspace/ — identity, journal, wiki, KB, etc.
    """

    model_config = SettingsConfigDict(
        env_prefix="AGNTSPACE_",
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )

    # Root directory — the user's chosen folder for vault data
    root_dir: Path = Field(default_factory=lambda: Path.home())
    host: str = "127.0.0.1"
    port: int = 8000
    llm: LLMSettings = Field(default_factory=LLMSettings)
    schedule: ScheduleSettings = Field(default_factory=ScheduleSettings)
    i18n: I18nSettings = Field(default_factory=I18nSettings)

    anthropic_api_key: str = Field(default="", alias="ANTHROPIC_API_KEY")
    openai_api_key: str = Field(default="", alias="OPENAI_API_KEY")

    # Whether root_dir was explicitly configured (vs home default)
    root_explicit: bool = False

    # ── App home: FIXED at ~/agntspace/ — config, credentials, logs, DB ──

    @property
    def app_dir(self) -> Path:
        """Fixed app directory at ~/agntspace/. Never changes."""
        return Path.home() / "agntspace"

    @property
    def config_path(self) -> Path:
        return self.app_dir / "config.toml"

    @property
    def db_path(self) -> Path:
        return self.app_dir / "agntspace.db"

    @property
    def credentials_path(self) -> Path:
        return self.app_dir / "credentials.json"

    @property
    def log_dir(self) -> Path:
        return self.app_dir / "logs"

    # ── Vault: root_dir/agntspace/ — user data ──

    @property
    def vault_dir(self) -> Path:
        """The agntspace/ folder inside root_dir. Vault data lives here."""
        return self.root_dir / "agntspace"

    @property
    def skills_dir(self) -> Path:
        return self.vault_dir / "agnt-system" / "skills"

    @property
    def identity_dir(self) -> Path:
        return self.vault_dir / "agnt-system" / "identity"

    # ── Backwards compat ──

    @property
    def home_dir(self) -> Path:
        return self.app_dir

    @property
    def data_dir(self) -> Path:
        return self.vault_dir

    @property
    def system_dir(self) -> Path:
        return self.app_dir

    # ── LLM helpers ──

    @property
    def active_api_key(self) -> str:
        if self.llm.mode == "local":
            return "ollama"
        if self.llm.cloud_provider == "anthropic":
            return self.anthropic_api_key
        return self.openai_api_key

    @property
    def active_model(self) -> str:
        if self.llm.mode == "local":
            return self.llm.local_model
        return self.llm.cloud_model


def load_config_toml(path: Path) -> dict[str, Any]:
    if not path.exists():
        return {}
    with open(path, "rb") as f:
        return tomllib.load(f)


def load_settings() -> Settings:
    """Load settings from env vars, then overlay with config.toml.

    Config is always read from ~/agntspace/config.toml (fixed location).
    Vault data location is determined by root_dir in the config.
    """
    base = Settings()

    # Config is ALWAYS at ~/agntspace/config.toml
    toml_data = load_config_toml(base.app_dir / "config.toml")

    # Legacy search if not found at standard location
    if not toml_data:
        for legacy in [
            Path.home() / "agntspace" / "vault" / "config.toml",
        ]:
            toml_data = load_config_toml(legacy)
            if toml_data:
                break

    if not toml_data:
        return base

    # Overlay TOML values
    llm_data = toml_data.get("llm", {})
    if llm_data:
        base.llm = LLMSettings(**{**base.llm.model_dump(), **llm_data})

    schedule_data = toml_data.get("schedule", {})
    if schedule_data:
        base.schedule = ScheduleSettings(**{**base.schedule.model_dump(), **schedule_data})

    server_data = toml_data.get("server", {})
    if "host" in server_data:
        base.host = server_data["host"]
    if "port" in server_data:
        base.port = server_data["port"]

    # root_dir override
    if "root_dir" in toml_data:
        base.root_dir = Path(toml_data["root_dir"])
        base.root_explicit = True
    elif "vault_dir" in toml_data:
        base.root_dir = Path(toml_data["vault_dir"]).parent
        base.root_explicit = True
    elif "home_dir" in toml_data:
        base.root_dir = Path(toml_data["home_dir"]).parent
        base.root_explicit = True

    # Sync direct mode: vault data goes to external folder
    sync_data = toml_data.get("sync", {})
    if sync_data.get("mode") == "direct" and sync_data.get("external_path"):
        direct_path = Path(sync_data["external_path"])
        if direct_path.is_dir():
            base.root_dir = direct_path
            base.root_explicit = True

    # If a vault exists at root_dir, enable root scanning even without
    # explicit config — the vault's presence proves user chose this folder.
    if not base.root_explicit and (base.root_dir / "agntspace").is_dir():
        base.root_explicit = True

    return base


_settings: Settings | None = None


def get_settings() -> Settings:
    global _settings
    if _settings is None:
        _settings = load_settings()
    return _settings


def reset_settings() -> None:
    global _settings
    _settings = None
