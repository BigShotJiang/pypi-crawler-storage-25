"""Coach service: goal tracking, stall detection, nudges."""

from __future__ import annotations

import logging
from datetime import UTC, datetime, timedelta

from agntspace.vault.reader import VaultReader
from agntspace.vault.writer import VaultWriter

log = logging.getLogger(__name__)

_GOAL_TEMPLATE = """---
title: "{title}"
type: {goal_type}
status: active
target_date: "{target_date}"
created: "{created}"
---

## What
{description}

## Why


## Success Criteria


## Milestones

"""


class CoachService:
    """Tracks goals, detects stalls, and generates nudges."""

    def __init__(
        self,
        vault_reader: VaultReader,
        vault_writer: VaultWriter,
        knowledge_graph: object | None = None,
    ) -> None:
        self._reader = vault_reader
        self._writer = vault_writer
        self._graph = knowledge_graph

    def list_goals(self, status_filter: str | None = None) -> list[dict]:
        """List all goals from vault/goals/."""
        files = self._reader.list_files("goals", "*.md")
        goals = []
        for f in files:
            try:
                doc = self._reader.read(f"goals/{f.name}")
                meta = doc.metadata
                goal_status = meta.get("status", "active")
                if status_filter and goal_status != status_filter:
                    continue
                goals.append({
                    "slug": f.stem,
                    "title": meta.get("title", f.stem),
                    "type": meta.get("type", "goal"),
                    "status": goal_status,
                    "target_date": meta.get("target_date", ""),
                    "created": meta.get("created", ""),
                })
            except Exception:
                continue
        return goals

    def get_goal(self, slug: str) -> dict | None:
        """Get a goal by slug."""
        path = f"goals/{slug}.md"
        if not self._reader.exists(path):
            return None
        doc = self._reader.read(path)
        return {
            "slug": slug,
            "content": doc.content,
            "metadata": doc.metadata,
        }

    def create_goal(
        self,
        title: str,
        description: str,
        goal_type: str = "goal",
        target_date: str = "",
    ) -> str:
        """Create a new goal file. Returns the vault path."""
        slug = title.lower().strip()
        slug = "".join(c if c.isalnum() or c == " " else "" for c in slug)
        slug = slug.replace(" ", "-")[:60].strip("-")
        path = f"goals/{slug}.md"

        now = datetime.now(UTC).strftime("%Y-%m-%d")
        content = _GOAL_TEMPLATE.format(
            title=title,
            goal_type=goal_type,
            target_date=target_date or "",
            created=now,
            description=description,
        )
        self._writer.write(path, content)
        return path

    def update_goal_status(self, slug: str, status: str) -> None:
        """Update a goal's status (active/paused/achieved/abandoned)."""
        import re

        path = f"goals/{slug}.md"
        doc = self._reader.read(path)
        content = re.sub(
            r"^status:\s*\S+",
            f"status: {status}",
            doc.raw,
            count=1,
            flags=re.MULTILINE,
        )
        self._writer.write(path, content)
        if self._graph:
            try:
                self._graph.build()
            except Exception:
                log.debug("Graph rebuild after goal status change failed", exc_info=True)

    def detect_stalls(self, stall_days: int = 7) -> list[dict]:
        """Detect goals that haven't had activity in stall_days.

        Checks if goals have related tasks or journal mentions recently.
        """
        stalls = []
        cutoff = (datetime.now(UTC) - timedelta(days=stall_days)).strftime("%Y-%m-%d")

        for goal in self.list_goals(status_filter="active"):
            # Check if any recent journal entries mention this goal
            title_lower = goal["title"].lower()
            has_recent_activity = False

            # Check recent journal files
            journal_files = self._reader.list_files("journal", "*.md")
            for jf in sorted(journal_files, reverse=True)[:stall_days]:
                if jf.stem < cutoff:
                    break
                try:
                    doc = self._reader.read(f"journal/{jf.name}")
                    if title_lower in doc.content.lower():
                        has_recent_activity = True
                        break
                except Exception:
                    continue

            if not has_recent_activity:
                stalls.append({
                    "goal": goal["title"],
                    "slug": goal["slug"],
                    "days_inactive": stall_days,
                    "nudge": (
                        f"Your goal '{goal['title']}' hasn't had any activity "
                        f"in the last {stall_days} days. Want to plan the next step?"
                    ),
                })

        return stalls

    def generate_nudges(self) -> list[str]:
        """Generate coaching nudges for stalled goals and approaching deadlines."""
        nudges = []
        today = datetime.now(UTC).strftime("%Y-%m-%d")

        # Stall nudges
        for stall in self.detect_stalls():
            nudges.append(stall["nudge"])

        # Deadline nudges
        for goal in self.list_goals(status_filter="active"):
            target = goal.get("target_date", "")
            if not target:
                continue
            try:
                target_date = datetime.strptime(target, "%Y-%m-%d")
                days_left = (target_date - datetime.strptime(today, "%Y-%m-%d")).days
                if 0 < days_left <= 7:
                    nudges.append(
                        f"Goal '{goal['title']}' is due in {days_left} day(s) ({target})."
                    )
                elif days_left <= 0:
                    nudges.append(
                        f"Goal '{goal['title']}' was due on {target}. "
                        f"Want to update the deadline or mark it?"
                    )
            except ValueError:
                continue

        return nudges
