"""MCP Server — exposes AgntSpace tools via Model Context Protocol.

Any MCP-compatible client (Claude Desktop, other agents, IDE extensions)
can connect and use AgntSpace's tools: email, vault, tasks, journal, etc.

All tool calls are contract-enforced.
"""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import TYPE_CHECKING, Any

from mcp.server import Server
from mcp.types import Resource, TextContent, Tool

if TYPE_CHECKING:
    from agntspace.agent.tools import ToolExecutor

log = logging.getLogger(__name__)


def create_mcp_server(
    tool_executor: ToolExecutor,
    vault_path: Path | None = None,
) -> Server:
    """Create an MCP server that exposes AgntSpace tools."""
    from agntspace.agent.tools import TOOL_DEFINITIONS

    server = Server("agntspace")

    @server.list_tools()
    async def list_tools() -> list[Tool]:
        """List all available tools."""
        tools = []
        for td in TOOL_DEFINITIONS:
            tools.append(Tool(
                name=td["name"],
                description=td.get("description", ""),
                inputSchema=td.get("input_schema", {"type": "object", "properties": {}}),
            ))
        return tools

    @server.call_tool()
    async def call_tool(name: str, arguments: dict[str, Any]) -> list[TextContent]:
        """Execute a tool call with contract enforcement."""
        log.info("MCP tool call: %s", name)

        # ToolExecutor.execute() is sync — safe to call directly
        result = tool_executor.execute(name, arguments)

        if result.get("error"):
            return [TextContent(type="text", text=f"Error: {result['error']}")]

        if result.get("needs_confirmation"):
            return [TextContent(
                type="text",
                text=f"Confirmation required: {result.get('reason', 'Contract requires approval for this action')}",
            )]

        return [TextContent(type="text", text=json.dumps(result, indent=2, default=str))]

    @server.list_resources()
    async def list_resources() -> list[Resource]:
        """List vault identity files as MCP resources."""
        resources = [
            Resource(
                uri="agntspace://vault/SOUL.md",
                name="Agent Identity (SOUL.md)",
                mimeType="text/markdown",
            ),
            Resource(
                uri="agntspace://vault/CONTRACT.md",
                name="User-Agent Contract",
                mimeType="text/markdown",
            ),
            Resource(
                uri="agntspace://vault/agnt-memory/MEMORY.md",
                name="Long-term Memory",
                mimeType="text/markdown",
            ),
            Resource(
                uri="agntspace://vault/USER.md",
                name="User Profile",
                mimeType="text/markdown",
            ),
        ]
        # Add KB schemas as resources if vault_path available
        if vault_path:
            kb_dir = vault_path / "agnt-kb"
            if kb_dir.is_dir():
                for kb in kb_dir.iterdir():
                    schema = kb / "SCHEMA.md"
                    if kb.is_dir() and schema.exists():
                        resources.append(Resource(
                            uri=f"agntspace://vault/agnt-kb/{kb.name}/SCHEMA.md",
                            name=f"KB: {kb.name} (schema)",
                            mimeType="text/markdown",
                        ))
        return resources

    @server.read_resource()
    async def read_resource(uri: str) -> str:
        """Read a vault file as MCP resource."""
        # Parse uri: agntspace://vault/path
        path = str(uri).replace("agntspace://vault/", "")
        if vault_path:
            full_path = vault_path / path
            # Also check identity dir
            if not full_path.exists():
                full_path = vault_path / "agnt-system" / "identity" / path
            if full_path.exists():
                return full_path.read_text(encoding="utf-8")
        return f"Error: resource not found: {path}"

    return server
