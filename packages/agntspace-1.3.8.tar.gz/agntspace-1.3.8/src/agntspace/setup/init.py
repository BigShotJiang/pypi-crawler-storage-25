"""First-run initialization, validation, and factory reset for the vault."""

from __future__ import annotations

import importlib.resources
import logging
import re
import shutil
from pathlib import Path

import tomli_w
import yaml

log = logging.getLogger(__name__)

# Default config template
_DEFAULT_CONFIG = {
    "llm": {
        "mode": "cloud",
        "cloud_provider": "anthropic",
        "cloud_model": "claude-sonnet-4-20250514",
        "local_provider": "ollama",
        "local_model": "llama3",
    },
    "server": {
        "host": "127.0.0.1",
        "port": 8000,
    },
    "indexing": {
        "exclude_dirs": ["finances", "health"],
    },
}

# Vault directory structure — three zones:
#   agnt-system/  App plumbing. Agent must access these to function.
#   (root)        User's own content. Gatable in cloud mode.
#   agnt-*        Agent-generated from user content.

_SYSTEM_DIRS = [
    "agnt-system/identity",     # SOUL, USER, PROFILE, CONTRACT, TRUST
    "agnt-system/agents",       # Subagent definitions
    "agnt-system/skills",       # Skill definitions (SKILL.md files)
    "agnt-system/security",     # Blacklist, audit trail
    "agnt-system/logs",         # Server logs
]

_USER_DIRS = [
    "inbox",            # Drop zone (user entry point)
    "journal",          # Daily thinking space
    "notes",            # Freeform notes
    "tasks",            # Delegated tasks
    "goals",            # Goals & aspirations
    "projects",         # Project containers
    "finances",         # Financial records
    "health",           # Health data
    "companies",        # Company information
    "contacts",         # Contact records
]

_AGENT_DIRS = [
    "agnt-memory",              # Long-term memory + knowledge graph
    "agnt-memory/pending",      # Pending memory updates (awaiting approval)
    "agnt-memory/graph",        # SPO knowledge graph
    "agnt-kb",                  # Compiled knowledge bases (wiki articles)
]

_VAULT_DIRS = _SYSTEM_DIRS + _USER_DIRS + _AGENT_DIRS


def _find_defaults_dir() -> Path:
    """Locate the defaults/ directory."""
    repo_defaults = Path(__file__).parent.parent.parent.parent.parent / "defaults"
    if repo_defaults.is_dir():
        return repo_defaults
    try:
        ref = importlib.resources.files("agntspace") / "defaults"
        pkg_path = Path(str(ref))
        if pkg_path.is_dir():
            return pkg_path
    except (TypeError, FileNotFoundError):
        pass
    raise FileNotFoundError("Cannot find defaults/ directory.")


def _copy_defaults(source: Path, dest: Path) -> None:
    """Copy default files, skipping any that already exist."""
    for src_file in source.rglob("*"):
        if src_file.name == ".gitkeep":
            continue
        if not src_file.is_file():
            continue
        relative = src_file.relative_to(source)
        dst_file = dest / relative
        if dst_file.exists():
            continue
        dst_file.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src_file, dst_file)
        log.debug("Copied: %s", relative)


def run_init(
    vault_dir: Path | None = None,
    vault_path: Path | None = None,  # legacy alias
    home_dir: Path | None = None,  # legacy alias
    minimal: bool = False,
) -> Path:
    """Initialize AgntSpace inside a root directory.

    Creates root_dir/agntspace/ with three zones:
      agntspace/
      ├── inbox/                     (drop zone)
      ├── agnt-system/               (identity, agents, skills, security, logs)
      ├── journal/, notes/, tasks/   (user content)
      ├── agnt-memory/, agnt-kb/  (agent-generated)

    The root_dir can be any folder — Obsidian vault, Dropbox, plain folder.
    User's existing content is never touched.
    """
    root = vault_dir or vault_path or home_dir or Path.home()
    vault = root / "agntspace"

    # Create agntspace/ and all subdirectories
    for sub in _VAULT_DIRS:
        (vault / sub).mkdir(parents=True, exist_ok=True)

    # Copy default vault files (skip if vault already initialized)
    identity_dir = vault / "agnt-system" / "identity"
    vault_exists = (identity_dir / "SOUL.md").exists() and (identity_dir / "CONTRACT.md").exists()
    try:
        defaults = _find_defaults_dir()
    except FileNotFoundError:
        if vault_exists:
            log.debug("Defaults dir not found but vault already initialized — skipping copy")
            defaults = None
        else:
            raise
    defaults_vault = defaults / "vault" if defaults else None
    if defaults_vault and defaults_vault.is_dir():
        # Identity files → agnt-system/identity/
        for identity_file in ["SOUL.md", "USER.md", "PROFILE.md", "CONTRACT.md", "TRUST.md"]:
            src = defaults_vault / identity_file
            dst = vault / "agnt-system" / "identity" / identity_file
            if src.exists() and not dst.exists():
                shutil.copy2(src, dst)
                log.debug("Copied identity: %s", identity_file)

        # MEMORY.md → agnt-memory/
        memory_src = defaults_vault / "memory" / "MEMORY.md"
        memory_dst = vault / "agnt-memory" / "MEMORY.md"
        if memory_src.exists() and not memory_dst.exists():
            shutil.copy2(memory_src, memory_dst)
            log.debug("Copied memory: MEMORY.md")

        # Agent definitions → agnt-system/agents/
        agents_src = defaults_vault / "agents"
        if agents_src.is_dir():
            _copy_defaults(agents_src, vault / "agnt-system" / "agents")

        # Security defaults → agnt-system/security/
        security_src = defaults_vault / "security"
        if security_src.is_dir():
            _copy_defaults(security_src, vault / "agnt-system" / "security")

    # Skills → agnt-system/skills/
    if defaults:
        defaults_skills = defaults / "skills"
        skills_dir = vault / "agnt-system" / "skills"
        if defaults_skills.is_dir():
            _copy_defaults(defaults_skills, skills_dir)
            log.debug("Copied default skills to %s", skills_dir)

    # Write config.toml to app home (~/agntspace/) — not to external vault
    home_vault = Path.home() / "agntspace"
    home_vault.mkdir(parents=True, exist_ok=True)
    config_path = home_vault / "config.toml"
    if not config_path.exists():
        config_path.write_bytes(tomli_w.dumps(_DEFAULT_CONFIG).encode())
        log.info("Created %s", config_path)

    # If this is an Obsidian vault and agntspace/ was previously excluded,
    # remove the exclusion — we WANT Obsidian to see agntspace files so
    # [[wikilinks]] appear in Obsidian's graph view. The two systems share
    # the same link graph intentionally.
    obsidian_config = root / ".obsidian" / "app.json"
    if obsidian_config.exists():
        try:
            import json as _json
            cfg = _json.loads(obsidian_config.read_text(encoding="utf-8"))
            excluded = cfg.get("userIgnoreFilters", [])
            vault_name = vault.name  # "agntspace"
            removed = False
            for pattern in [vault_name, f"{vault_name}/"]:
                if pattern in excluded:
                    excluded.remove(pattern)
                    removed = True
            if removed:
                cfg["userIgnoreFilters"] = excluded
                obsidian_config.write_text(_json.dumps(cfg, indent=2), encoding="utf-8")
                log.info("Removed %s/ from Obsidian excluded folders — wikilinks now shared", vault_name)
        except Exception:
            log.debug("Could not update Obsidian config", exc_info=True)

    log.debug("AgntSpace initialized at %s (vault: %s)", root, vault)
    return root


# ---- Vault Health Validation ----

# Map of system files: filename → vault-relative path
_IDENTITY_FILES = {
    "SOUL.md": "agnt-system/identity/SOUL.md",
    "USER.md": "agnt-system/identity/USER.md",
    "PROFILE.md": "agnt-system/identity/PROFILE.md",
    "CONTRACT.md": "agnt-system/identity/CONTRACT.md",
    "TRUST.md": "agnt-system/identity/TRUST.md",
}

# Reset categories
# Categories available for reset. Memory excluded by default — it's the agent's
# accumulated knowledge about the user, expensive to rebuild.
RESET_CATEGORIES = ("identity", "agents", "skills", "security")
RESET_CATEGORIES_ALL = ("identity", "memory", "agents", "skills", "security")


def _resolve_vault(vault_dir: Path) -> Path:
    """Resolve to the agntspace directory."""
    vault = vault_dir / "agntspace" if vault_dir.name != "agntspace" else vault_dir
    if not vault.is_dir():
        raise FileNotFoundError(f"Vault not found: {vault}")
    return vault


def validate_vault(vault_dir: Path) -> dict[str, dict]:
    """Validate system files and return per-file health status.

    Returns dict keyed by display name, each with:
      status: "ok" | "warning" | "error"
      message: human-readable description
      path: vault-relative path
    """
    vault = _resolve_vault(vault_dir)
    results: dict[str, dict] = {}

    # --- Identity files ---
    for filename, vault_path in _IDENTITY_FILES.items():
        full = vault / vault_path
        name = filename.replace(".md", "")

        if not full.is_file():
            results[name] = {"status": "error", "message": f"{filename} is missing", "path": vault_path}
            continue

        text = full.read_text(encoding="utf-8")

        # Check for unfilled placeholders
        if "[placeholder]" in text.lower() or "[your name]" in text.lower():
            results[name] = {"status": "warning", "message": f"{filename} has unfilled placeholders", "path": vault_path}
            continue

        # File-specific validation
        if filename == "CONTRACT.md":
            results[name] = _validate_contract(text, vault_path)
        elif filename == "TRUST.md":
            results[name] = _validate_trust(text, vault_path)
        else:
            results[name] = {"status": "ok", "message": f"{filename} looks good", "path": vault_path}

    # --- MEMORY.md ---
    mem_path = "agnt-memory/MEMORY.md"
    mem_full = vault / mem_path
    if not mem_full.is_file():
        results["MEMORY"] = {"status": "error", "message": "MEMORY.md is missing", "path": mem_path}
    else:
        results["MEMORY"] = {"status": "ok", "message": "MEMORY.md looks good", "path": mem_path}

    # --- Agents ---
    agents_dir = vault / "agnt-system" / "agents"
    agent_count = len(list(agents_dir.glob("*.md"))) if agents_dir.is_dir() else 0
    if agent_count == 0:
        results["Agents"] = {"status": "warning", "message": "No agent definitions found", "path": "agnt-system/agents/"}
    else:
        results["Agents"] = {"status": "ok", "message": f"{agent_count} agent definitions", "path": "agnt-system/agents/"}

    # --- Skills ---
    skills_dir = vault / "agnt-system" / "skills"
    skill_count = len(list(skills_dir.rglob("SKILL.md"))) if skills_dir.is_dir() else 0
    if skill_count == 0:
        results["Skills"] = {"status": "warning", "message": "No skills found", "path": "agnt-system/skills/"}
    else:
        results["Skills"] = {"status": "ok", "message": f"{skill_count} skills loaded", "path": "agnt-system/skills/"}

    return results


def _validate_contract(text: str, vault_path: str) -> dict:
    """Validate CONTRACT.md YAML block."""
    # Extract YAML block
    match = re.search(r"```ya?ml\s*\n(.*?)```", text, re.DOTALL)
    if not match:
        return {"status": "error", "message": "CONTRACT.md has no YAML permissions block", "path": vault_path}

    try:
        data = yaml.safe_load(match.group(1))
    except yaml.YAMLError as exc:
        return {"status": "error", "message": f"CONTRACT.md YAML is malformed: {exc}", "path": vault_path}

    if not isinstance(data, dict):
        return {"status": "error", "message": "CONTRACT.md YAML block is not a valid mapping", "path": vault_path}

    issues = []
    if "default" not in data:
        issues.append("missing 'default' field")
    if not data.get("allow") and not data.get("confirm"):
        issues.append("no actions in allow or confirm")

    if issues:
        return {"status": "warning", "message": f"CONTRACT.md: {', '.join(issues)}", "path": vault_path}

    return {"status": "ok", "message": "CONTRACT.md looks good", "path": vault_path}


def _validate_trust(text: str, vault_path: str) -> dict:
    """Validate TRUST.md table format."""
    valid_rows = 0
    for line in text.splitlines():
        line = line.strip()
        if not line.startswith("|"):
            continue
        cells = [c.strip() for c in line.split("|")[1:-1]]
        if len(cells) >= 6 and cells[0] and not cells[0].startswith("-"):
            # Skip header row
            if cells[0].lower() == "domain":
                continue
            valid_rows += 1

    if valid_rows == 0:
        return {"status": "warning", "message": "TRUST.md has no valid trust score rows", "path": vault_path}

    return {"status": "ok", "message": f"TRUST.md: {valid_rows} domains tracked", "path": vault_path}


# ---- Factory Reset ----


def reset_vault(vault_dir: Path, categories: list[str] | None = None) -> dict:
    """Reset vault system files to factory defaults.

    Args:
        vault_dir: Root directory containing agntspace/.
        categories: Which categories to reset. None = all.
            Valid: "identity", "memory", "agents", "skills", "security".

    User content (journal, notes, tasks, goals, kb, reflections, inbox)
    is never touched.

    Returns a summary of what was reset.
    """
    vault = _resolve_vault(vault_dir)
    cats = set(categories) if categories else set(RESET_CATEGORIES)
    defaults = _find_defaults_dir()
    defaults_vault = defaults / "vault"
    reset_files: list[str] = []

    if "identity" in cats and defaults_vault.is_dir():
        for identity_file in ["SOUL.md", "USER.md", "PROFILE.md", "CONTRACT.md", "TRUST.md"]:
            src = defaults_vault / identity_file
            dst = vault / "agnt-system" / "identity" / identity_file
            if src.exists():
                dst.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(src, dst)
                reset_files.append(f"agnt-system/identity/{identity_file}")

    if "memory" in cats:
        # Reset MEMORY.md
        if defaults_vault.is_dir():
            mem_src = defaults_vault / "memory" / "MEMORY.md"
            mem_dst = vault / "agnt-memory" / "MEMORY.md"
            if mem_src.exists():
                mem_dst.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(mem_src, mem_dst)
                reset_files.append("agnt-memory/MEMORY.md")
        # Clear graph files
        for graph_file in ("agnt-memory/graph/entities.json", "agnt-memory/graph/triples.json"):
            gf = vault / graph_file
            if gf.exists():
                gf.unlink()
                reset_files.append(graph_file)
        # Clear pending memory
        pending = vault / "agnt-memory" / "pending"
        if pending.is_dir():
            for f in pending.glob("*.md"):
                f.unlink()
                reset_files.append(f"agnt-memory/pending/{f.name}")

    if "agents" in cats and defaults_vault.is_dir():
        agents_src = defaults_vault / "agents"
        if agents_src.is_dir():
            _overwrite_defaults(agents_src, vault / "agnt-system" / "agents")
            reset_files.append("agnt-system/agents/*")

    if "skills" in cats:
        defaults_skills = defaults / "skills"
        if defaults_skills.is_dir():
            _overwrite_defaults(defaults_skills, vault / "agnt-system" / "skills")
            reset_files.append("agnt-system/skills/*")

    if "security" in cats and defaults_vault.is_dir():
        security_src = defaults_vault / "security"
        if security_src.is_dir():
            _overwrite_defaults(security_src, vault / "agnt-system" / "security")
            reset_files.append("agnt-system/security/*")

    log.info("Vault reset (%s): %d items restored", ", ".join(cats), len(reset_files))
    return {"reset_files": reset_files, "count": len(reset_files), "categories": sorted(cats)}


def reset_file(vault_dir: Path, vault_path: str) -> dict:
    """Reset a single system file to its factory default.

    Args:
        vault_dir: Root directory containing agntspace/.
        vault_path: Vault-relative path (e.g., "identity/CONTRACT.md").

    Returns summary with the reset file path.
    """
    vault = _resolve_vault(vault_dir)
    defaults = _find_defaults_dir()
    defaults_vault = defaults / "vault"

    # Map vault paths to their default source
    source_map = {
        "agnt-system/identity/SOUL.md": defaults_vault / "SOUL.md",
        "agnt-system/identity/USER.md": defaults_vault / "USER.md",
        "agnt-system/identity/PROFILE.md": defaults_vault / "PROFILE.md",
        "agnt-system/identity/CONTRACT.md": defaults_vault / "CONTRACT.md",
        "agnt-system/identity/TRUST.md": defaults_vault / "TRUST.md",
        "agnt-memory/MEMORY.md": defaults_vault / "memory" / "MEMORY.md",
    }

    src = source_map.get(vault_path)
    if not src or not src.exists():
        raise FileNotFoundError(f"No default exists for: {vault_path}")

    dst = vault / vault_path
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dst)
    log.info("Reset single file: %s", vault_path)
    return {"reset_file": vault_path}


def _overwrite_defaults(source: Path, dest: Path) -> None:
    """Copy default files, overwriting existing ones."""
    for src_file in source.rglob("*"):
        if src_file.name == ".gitkeep":
            continue
        if not src_file.is_file():
            continue
        relative = src_file.relative_to(source)
        dst_file = dest / relative
        dst_file.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src_file, dst_file)
        log.debug("Reset: %s", relative)
