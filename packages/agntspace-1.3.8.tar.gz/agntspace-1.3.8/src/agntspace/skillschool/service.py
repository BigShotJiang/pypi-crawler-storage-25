"""SkillSchool: detect patterns, propose skills, refine from feedback."""

from __future__ import annotations

import logging

from agntspace.llm.base import LLMProvider, Message
from agntspace.tasks.service import TaskService
from agntspace.vault.reader import VaultReader
from agntspace.vault.writer import VaultWriter

log = logging.getLogger(__name__)

_SKILL_PROPOSAL_PROMPT = """You are the AgntSpace SkillSchool engine. Analyze the task history below and identify repeatable patterns that could become reusable skills.

A skill is a structured instruction set (SKILL.md) that captures:
- What the task pattern is
- The user's preferences for how it should be done
- Step-by-step instructions the agent should follow

For each pattern you identify, produce a skill proposal in this format:

```skill
---
name: skill-name-slug
title: "Human Readable Title"
description: "One-line description"
category: work
triggers:
  - "keyword that activates this skill"
  - "another trigger phrase"
status: draft
author: agent
agent: main
---

## Instructions

Step-by-step instructions for the agent when this skill is triggered.
Include the user's observed preferences.
```

If no clear patterns exist, say "No skill proposals at this time."

Focus on tasks that were done 3+ times with similar patterns."""

_REFINEMENT_PROMPT = """You are the AgntSpace SkillSchool engine. Based on accumulated feedback for tasks related to a skill, propose refinements.

Current skill instructions:
{current_skill}

Feedback history:
{feedback}

Propose updated instructions that incorporate the feedback. Output the full revised skill body (just the ## Instructions section content)."""


class SkillSchoolService:
    """Detects patterns and proposes skills from task history."""

    def __init__(
        self,
        vault_reader: VaultReader,
        vault_writer: VaultWriter,
        task_service: TaskService,
        llm: LLMProvider,
    ) -> None:
        self._reader = vault_reader
        self._writer = vault_writer
        self._tasks = task_service
        self._llm = llm

    async def analyze_patterns(self) -> list[dict]:
        """Analyze completed tasks for repeatable patterns.

        Returns list of skill proposals.
        """
        tasks = self._tasks.list_tasks(status_filter="done")
        if len(tasks) < 3:
            return []

        # Build task summary for LLM
        task_lines = []
        for t in tasks[:30]:  # limit context
            task_lines.append(
                f"- {t.get('title', '?')} (domain: {t.get('domain', '?')}, "
                f"mode: {t.get('mode', '?')})"
            )
        task_summary = "\n".join(task_lines)

        response = await self._llm.complete(
            messages=[Message(role="user", content=task_summary)],
            system=_SKILL_PROPOSAL_PROMPT,
            max_tokens=2048,
            temperature=0.3,
        )

        proposals = self._parse_proposals(response.content)

        # Save proposals to vault/skills-review/
        for proposal in proposals:
            self._save_proposal(proposal)

        log.info("SkillSchool: %d skill proposals generated", len(proposals))
        return proposals

    def list_proposals(self) -> list[dict]:
        """List pending skill proposals in vault/skills-review/."""
        files = self._reader.list_files("skills-review", "*.md")
        proposals = []
        for f in files:
            try:
                doc = self._reader.read(f"skills-review/{f.name}")
                entry = {
                    "slug": f.stem,
                    "title": doc.metadata.get("title", f.stem),
                    "status": doc.metadata.get("status", "pending_review"),
                    "description": doc.metadata.get("description", ""),
                    "category": doc.metadata.get("category", ""),
                }
                # Include healer-specific fields if present
                if doc.metadata.get("type"):
                    entry["type"] = doc.metadata["type"]
                if doc.metadata.get("agent_key"):
                    entry["agent_key"] = doc.metadata["agent_key"]
                if doc.metadata.get("skill"):
                    entry["skill"] = doc.metadata["skill"]
                if doc.metadata.get("workflow"):
                    entry["workflow"] = doc.metadata["workflow"]
                proposals.append(entry)
            except Exception:
                continue
        return proposals

    def approve_proposal(self, slug: str) -> str:
        """Approve a skill proposal and move it to active skills."""
        review_path = f"skills-review/{slug}.md"
        if not self._reader.exists(review_path):
            raise FileNotFoundError(f"Proposal not found: {slug}")

        doc = self._reader.read(review_path)

        # Update status to active
        import re

        content = re.sub(
            r"^status:\s*\S+",
            "status: active",
            doc.raw,
            count=1,
            flags=re.MULTILINE,
        )

        # Write to skills directory
        skill_path = f"agnt-system/skills/custom/{slug}/SKILL.md"
        self._writer.write(skill_path, content)

        # Clear review file by writing rejection marker (vault writer handles the path)
        self._writer.write(review_path, re.sub(
            r"^status:\s*\S+",
            "status: approved_and_moved",
            doc.raw,
            count=1,
            flags=re.MULTILINE,
        ))

        log.info("SkillSchool: approved skill '%s'", slug)
        return skill_path

    def reject_proposal(self, slug: str) -> None:
        """Reject a skill proposal."""
        import re

        review_path = f"skills-review/{slug}.md"
        if not self._reader.exists(review_path):
            raise FileNotFoundError(f"Proposal not found: {slug}")

        doc = self._reader.read(review_path)
        content = re.sub(
            r"^status:\s*\S+",
            "status: rejected",
            doc.raw,
            count=1,
            flags=re.MULTILINE,
        )
        self._writer.write(review_path, content)
        log.info("SkillSchool: rejected skill '%s'", slug)

    async def refine_from_feedback(self, skill_name: str) -> dict:
        """Refine a skill's instructions based on accumulated task feedback.

        Looks at completed tasks in the skill's domain, gathers feedback,
        and asks the LLM to revise the skill instructions.
        """
        import re

        # Find the skill file
        skill_path = f"agnt-system/skills/custom/{skill_name}/SKILL.md"
        if not self._reader.exists(skill_path):
            return {"error": f"Skill not found: {skill_name}"}

        doc = self._reader.read(skill_path)
        current_skill = doc.content

        # Gather feedback from completed tasks in this skill's domain
        tasks = self._tasks.list_tasks(status_filter="done")
        feedback_lines = []
        for t in tasks:
            fb = t.get("feedback")
            if fb and skill_name in t.get("domain", ""):
                feedback_lines.append(
                    f"- Task: {t.get('title', '?')} — Feedback: {fb}"
                )

        if not feedback_lines:
            return {"skill": skill_name, "status": "no_feedback"}

        feedback_text = "\n".join(feedback_lines[:20])

        response = await self._llm.complete(
            messages=[Message(role="user", content="Refine this skill based on feedback.")],
            system=_REFINEMENT_PROMPT.format(
                current_skill=current_skill,
                feedback=feedback_text,
            ),
            max_tokens=2048,
            temperature=0.3,
        )

        refined_instructions = response.content

        # Replace the ## Instructions section
        new_content = re.sub(
            r"(## Instructions\n).*",
            f"\\1\n{refined_instructions}",
            doc.raw,
            flags=re.DOTALL,
        )
        self._writer.write(skill_path, new_content)

        log.info("SkillSchool: refined skill '%s' from %d feedback items", skill_name, len(feedback_lines))
        return {
            "skill": skill_name,
            "status": "refined",
            "feedback_count": len(feedback_lines),
        }

    def _save_proposal(self, proposal: dict) -> None:
        """Save a skill proposal to vault/skills-review/."""
        name = proposal.get("name", "unnamed")
        path = f"skills-review/{name}.md"
        self._writer.write(path, proposal.get("content", ""))

    @staticmethod
    def _parse_proposals(text: str) -> list[dict]:
        """Parse skill proposals from LLM output."""
        proposals = []
        parts = text.split("```skill")
        for part in parts[1:]:
            end = part.find("```")
            content = part.strip() if end == -1 else part[:end].strip()

            # Extract name from frontmatter
            import re

            name_match = re.search(r"name:\s*(\S+)", content)
            name = name_match.group(1) if name_match else f"skill-{len(proposals)}"

            proposals.append({"name": name, "content": content})

        return proposals
