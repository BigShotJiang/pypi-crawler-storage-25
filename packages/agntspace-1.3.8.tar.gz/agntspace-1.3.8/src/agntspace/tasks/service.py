"""Task delegation service: lifecycle, modes, feedback."""

from __future__ import annotations

import re
from datetime import UTC, datetime

from agntspace.vault.reader import VaultDocument, VaultReader
from agntspace.vault.writer import VaultWriter

STATUSES = ("delegated", "in_progress", "blocked", "review", "done", "cancelled")
MODES = ("jdi", "review", "recommend", "watch")

_TASK_TEMPLATE = """---
title: "{title}"
status: delegated
mode: {mode}
domain: {domain}
delegated: "{delegated}"
due: ""
---

## Brief
{brief}

## Steps

## Progress Log
- {timestamp} — Task delegated.

## Escalation

## Result

## Feedback
"""


class TaskService:
    """Manages task files in vault/tasks/."""

    def __init__(self, vault_reader: VaultReader, vault_writer: VaultWriter) -> None:
        self._reader = vault_reader
        self._writer = vault_writer

    def create_task(
        self,
        title: str,
        brief: str,
        mode: str = "review",
        domain: str = "general",
    ) -> str:
        """Create a new task file. Returns the relative vault path."""
        slug = self._slugify(title)
        path = f"tasks/{slug}.md"
        now = datetime.now(UTC)
        content = _TASK_TEMPLATE.format(
            title=title,
            mode=mode,
            domain=domain,
            delegated=now.isoformat(),
            brief=brief,
            timestamp=now.strftime("%Y-%m-%d %H:%M"),
        )
        self._writer.write(path, content)
        return path

    def get_task(self, slug: str) -> VaultDocument | None:
        """Get a task by slug (filename without .md)."""
        path = f"tasks/{slug}.md"
        if not self._reader.exists(path):
            return None
        return self._reader.read(path)

    def list_tasks(self, status_filter: str | None = None) -> list[dict]:
        """List all tasks, optionally filtered by status."""
        files = self._reader.list_files("tasks", "*.md")
        tasks = []
        for f in files:
            doc = self._reader.read(f"tasks/{f.name}")
            meta = doc.metadata
            task_status = meta.get("status", "unknown")
            if status_filter and task_status != status_filter:
                continue
            tasks.append({
                "slug": f.stem,
                "title": meta.get("title", f.stem),
                "status": task_status,
                "mode": meta.get("mode", "review"),
                "domain": meta.get("domain", ""),
                "delegated": meta.get("delegated", ""),
                "due": meta.get("due", ""),
            })
        return tasks

    def update_status(self, slug: str, new_status: str) -> None:
        """Update a task's status."""
        if new_status not in STATUSES:
            raise ValueError(f"Invalid status: {new_status}")
        self._update_metadata(slug, "status", new_status)
        self._append_progress(slug, f"Status changed to {new_status}.")

    def add_progress(self, slug: str, note: str) -> None:
        """Add a progress log entry."""
        self._append_progress(slug, note)

    def set_feedback(self, slug: str, rating: str, note: str = "") -> dict:
        """Set feedback on a completed task. Returns feedback data for trust updates."""
        if rating not in ("good", "needs_improvement", "redo"):
            raise ValueError(f"Invalid rating: {rating}")

        path = f"tasks/{slug}.md"
        doc = self._reader.read(path)
        domain = doc.metadata.get("domain", "general")

        # Write feedback to the task file
        feedback_text = f"Rating: {rating}"
        if note:
            feedback_text += f'\nNote: "{note}"'

        content = doc.raw
        content = content.replace(
            "## Feedback\n",
            f"## Feedback\n{feedback_text}\n",
        )

        # Also mark as done if not already
        if doc.metadata.get("status") != "done":
            content = re.sub(
                r"^status:\s*\S+",
                "status: done",
                content,
                count=1,
                flags=re.MULTILINE,
            )

        self._writer.write(path, content)

        return {"slug": slug, "domain": domain, "rating": rating, "note": note}

    def infer_mode(self, text: str) -> str:
        """Infer delegation mode from natural language phrasing."""
        lower = text.lower()
        if any(p in lower for p in ["let me review", "show me first", "check with me"]):
            return "review"
        if any(p in lower for p in ["what are my options", "recommend", "research"]):
            return "recommend"
        if any(p in lower for p in ["let me know when", "watch", "alert me", "notify me"]):
            return "watch"
        # Default: just do it
        return "jdi"

    def _update_metadata(self, slug: str, key: str, value: str) -> None:
        """Update a single frontmatter field in a task file."""
        path = f"tasks/{slug}.md"
        doc = self._reader.read(path)
        content = doc.raw
        content = re.sub(
            rf"^{re.escape(key)}:\s*.*$",
            f"{key}: {value}",
            content,
            count=1,
            flags=re.MULTILINE,
        )
        self._writer.write(path, content)

    def _append_progress(self, slug: str, note: str) -> None:
        """Append to the Progress Log section."""
        path = f"tasks/{slug}.md"
        doc = self._reader.read(path)
        content = doc.raw
        timestamp = datetime.now(UTC).strftime("%Y-%m-%d %H:%M")
        line = f"- {timestamp} — {note}"

        # Insert after ## Progress Log
        pattern = r"(## Progress Log\n(?:.*\n)*?)((?=\n## )|\Z)"
        match = re.search(pattern, content)
        if match:
            insert_at = match.end(1)
            content = content[:insert_at] + line + "\n" + content[insert_at:]
        else:
            content += f"\n## Progress Log\n{line}\n"

        self._writer.write(path, content)

    @staticmethod
    def _slugify(text: str) -> str:
        """Convert title to a filename-safe slug."""
        slug = text.lower().strip()
        slug = re.sub(r"[^\w\s-]", "", slug)
        slug = re.sub(r"[\s_]+", "-", slug)
        slug = re.sub(r"-+", "-", slug)
        return slug[:60].strip("-")
