"""Inbox folder watcher — auto-ingests files dropped into inbox/.

Watches both the global inbox/ (vault root) and per-KB inbox/ directories.
When new files appear, triggers ingest automatically.
Checks every 30 seconds.
"""

from __future__ import annotations

import asyncio
import json
import logging
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from agntspace.agent.orchestrator import Orchestrator
    from agntspace.automation.heartbeat import Heartbeat
    from agntspace.kb.service import KnowledgeBaseService

log = logging.getLogger(__name__)


class RawWatcher:
    """Watches inbox/ and root folder for new files to ingest."""

    _MAX_RETRIES = 5

    def __init__(
        self,
        vault_dir: Path,
        kb_service: KnowledgeBaseService,
        root_dir: Path | None = None,
        scan_root: bool = False,
        heartbeat: Heartbeat | None = None,
        orchestrator: Orchestrator | None = None,
        check_interval: int = 30,
        work_queue: object | None = None,
    ) -> None:
        self._vault_dir = vault_dir
        self._root_dir = root_dir if scan_root else None
        self._kb = kb_service
        self._heartbeat = heartbeat
        self._orchestrator = orchestrator
        self._interval = check_interval
        self._work_queue = work_queue
        self._task: asyncio.Task | None = None  # type: ignore[type-arg]
        self._running = False
        self._known_files: set[str] = set()
        # Track root folder files: path → content hash (for rename/move/delete detection)
        self._root_file_hashes: dict[str, str] = {}
        # Track file mtime at time of ingestion — detect content modifications
        self._known_mtimes: dict[str, float] = {}
        # Track file sizes at time of ingestion — detect content added after creation
        self._known_sizes: dict[str, int] = {}
        # Track failed ingest attempts per file — stop retrying after _MAX_RETRIES
        self._fail_counts: dict[str, int] = {}
        # Prevent concurrent ingest runs (watcher cycle vs manual API call)
        self._ingesting = False

    @property
    def _state_path(self) -> Path:
        return self._vault_dir / ".inbox-watcher-state.json"

    def _load_state(self) -> set[str]:
        """Load known files from disk so we don't re-process across restarts."""
        try:
            if self._state_path.exists():
                data = json.loads(self._state_path.read_text(encoding="utf-8"))
                # Only keep entries for files that still exist
                known = {f for f in data.get("known_files", []) if Path(f).exists()}
                # Restore persisted sizes and mtimes
                self._known_sizes = {
                    k: v for k, v in data.get("known_sizes", {}).items()
                    if k in known
                }
                self._known_mtimes = {
                    k: v for k, v in data.get("known_mtimes", {}).items()
                    if k in known
                }
                return known
        except Exception:
            log.debug("Could not load watcher state, starting fresh")
        return set()

    def _save_state(self) -> None:
        """Persist known files and their sizes to disk."""
        try:
            self._state_path.write_text(
                json.dumps({
                    "known_files": list(self._known_files),
                    "known_sizes": self._known_sizes,
                    "known_mtimes": self._known_mtimes,
                }),
                encoding="utf-8",
            )
        except Exception:
            log.debug("Could not save watcher state", exc_info=True)

    def start(self) -> None:
        if self._running:
            return
        self._running = True
        self._known_files = self._load_state()
        self._task = asyncio.create_task(self._run())
        log.debug("Inbox watcher started (interval: %ds, %d known files)", self._interval, len(self._known_files))

    async def _run(self) -> None:
        """Initial check + regular loop."""
        # Small delay to let other services initialize
        await asyncio.sleep(5)
        # Process any files already in inbox/ (dropped while server was down)
        try:
            result = await self.check_and_ingest()
            if result:
                log.info("Inbox watcher: startup ingest processed %d files", len(result))
        except Exception:
            log.exception("Inbox watcher: startup ingest failed")
        await self._loop()

    def stop(self) -> None:
        self._running = False
        if self._task:
            self._task.cancel()
            self._task = None

    # Directories to skip when scanning root folder
    _SKIP_DIRS = {
        # AgntSpace / vault internals
        "agntspace", ".obsidian", ".git", ".trash",
        # Dev / system
        "node_modules", "__pycache__", ".venv", "venv", ".env",
        # OS system dirs (when root is home dir)
        "AppData", "Application Data", ".cache", ".local", ".config", ".vscode",
        "Library", ".Trash",
        # Cloud sync (managed separately if user connects them)
        "OneDrive", "Dropbox", "Google Drive", "iCloud Drive",
        # Common large dirs
        "Downloads", ".npm", ".nuget", ".cargo", ".rustup",
    }

    _SUPPORTED_EXTS = {".md", ".txt", ".html", ".pdf", ".png", ".jpg", ".jpeg", ".csv", ".json", ".jsonl", ".vtt", ".srt"}

    def _scan_all_raw(self) -> set[str]:
        """Scan inbox/ directories and root folder for files."""
        files: set[str] = set()

        # 1. agntspace/inbox/ (explicit drop zone)
        inbox = self._vault_dir / "inbox"
        if inbox.is_dir():
            for f in inbox.iterdir():
                if f.is_file() and f.name != ".gitkeep":
                    files.add(str(f))

        # 2. Per-KB inbox/
        kb_dir = self._vault_dir / "agnt-kb"
        if kb_dir.is_dir():
            for kb in kb_dir.iterdir():
                if kb.is_dir():
                    kb_inbox = kb / "inbox"
                    if kb_inbox.is_dir():
                        for f in kb_inbox.iterdir():
                            if f.is_file() and f.name != ".gitkeep":
                                files.add(str(f))

        # 3. Root folder — scan for user content to ingest as knowledge
        #    agntspace/ is inside root, so root IS the vault
        if self._root_dir and self._root_dir != self._vault_dir:
            self._scan_dir_recursive(self._root_dir, files)

        return files

    def _scan_dir_flat(self, directory: Path, files: set[str]) -> None:
        """Scan only top-level files in a directory (non-recursive)."""
        try:
            for f in directory.iterdir():
                if f.is_file() and not f.name.startswith(".") and f.suffix.lower() in self._SUPPORTED_EXTS:
                    files.add(str(f))
        except OSError:
            pass

    # How many seconds a file must exist before we process it.
    # Editors like Obsidian create an empty file first, then write content
    # moments later.  Deferring very young files avoids ingesting the blank
    # shell and marking the file as "known" before the real content arrives.
    # At 30-second scan intervals, a 5-second grace period means the file
    # is picked up on the same cycle or the next one — no perceptible delay.
    _SETTLE_SECONDS = 5

    def _scan_dir_recursive(self, directory: Path, files: set[str]) -> None:
        """Recursively scan a directory, skipping system/hidden dirs."""
        import time

        now = time.time()
        try:
            for f in directory.iterdir():
                if f.name.startswith(".") or f.name in self._SKIP_DIRS:
                    continue
                if f.is_dir():
                    self._scan_dir_recursive(f, files)
                elif f.is_file() and f.suffix.lower() in self._SUPPORTED_EXTS:
                    try:
                        st = f.stat()
                    except OSError:
                        continue
                    # Skip empty files (0 bytes is never useful)
                    if st.st_size == 0:
                        continue
                    # Defer very young files — let the editor finish writing
                    if now - st.st_mtime < self._SETTLE_SECONDS:
                        continue
                    files.add(str(f))
        except OSError:
            pass  # Skip inaccessible dirs (OneDrive placeholders, permissions)

    def _snapshot_file_stats(self, files: set[str]) -> None:
        """Record size and mtime for all files so we detect future changes."""
        for fpath in files:
            try:
                st = Path(fpath).stat()
                self._known_sizes[fpath] = st.st_size
                self._known_mtimes[fpath] = st.st_mtime
            except OSError:
                pass

    async def check_and_ingest(self) -> list[str]:
        """Check for new files and auto-ingest them."""
        if self._ingesting:
            log.debug("Inbox watcher: ingest already in progress, skipping cycle")
            return []
        self._ingesting = True
        try:
            return await self._do_check_and_ingest()
        finally:
            self._ingesting = False

    async def _do_check_and_ingest(self) -> list[str]:
        """Internal implementation of check_and_ingest (holds the lock)."""
        current_files = self._scan_all_raw()
        new_files = current_files - self._known_files

        # Detect known files whose content has changed (mtime differs).
        # This covers: user edits a file in Obsidian, or a file was ingested
        # while empty and now has content.  The KB ingest pipeline handles
        # updates (replaces old source summary + produced pages).
        for fpath in current_files & self._known_files:
            if fpath in self._fail_counts and self._fail_counts[fpath] >= self._MAX_RETRIES:
                continue
            try:
                st = Path(fpath).stat()
            except OSError:
                continue
            old_mtime = self._known_mtimes.get(fpath)
            old_size = self._known_sizes.get(fpath, -1)
            if old_mtime is not None and st.st_mtime > old_mtime:
                # File was modified since last ingest
                log.info("Inbox watcher: file modified (mtime %s → %s), re-processing: %s",
                         old_mtime, st.st_mtime, Path(fpath).name)
                new_files.add(fpath)
                self._known_files.discard(fpath)
            elif old_size == 0 and st.st_size > 0:
                # Legacy: was recorded at 0 bytes, now has content
                log.info("Inbox watcher: previously-empty file now has content (%d bytes), re-processing: %s",
                         st.st_size, Path(fpath).name)
                new_files.add(fpath)
                self._known_files.discard(fpath)

        # Filter out files that have exceeded retry limit — queue to persistent work queue
        exhausted = {f for f in new_files if self._fail_counts.get(f, 0) >= self._MAX_RETRIES}
        if exhausted:
            log.warning("Inbox watcher: %d files exceeded %d retries — queuing for persistent retry: %s",
                        len(exhausted), self._MAX_RETRIES,
                        ", ".join(Path(f).name for f in list(exhausted)[:5]))
            # Queue exhausted files to the persistent work queue (retries forever)
            if hasattr(self, '_work_queue') and self._work_queue:
                for fpath in exhausted:
                    try:
                        # Determine which KB this file belongs to
                        p = Path(fpath)
                        kb_prefix = str(self._vault_dir / "agnt-kb")
                        if fpath.startswith(kb_prefix):
                            rel = p.relative_to(self._vault_dir / "agnt-kb")
                            slug = rel.parts[0]
                        else:
                            slug = "general"
                        import asyncio
                        asyncio.create_task(self._work_queue.enqueue(
                            "ingest", {"slug": slug}, deduplicate=True,
                        ))
                    except Exception:
                        log.debug("Inbox watcher: failed to queue %s", fpath, exc_info=True)
            self._known_files |= exhausted  # treat as known so they stop appearing
            new_files -= exhausted

        if not new_files:
            # Only update known set when there's nothing new to process
            self._known_files = current_files
            self._snapshot_file_stats(current_files)
            self._save_state()
            return []

        ingested = []

        # Group by location: inbox files, KB inbox files, root folder files
        inbox_new = []
        kb_new: dict[str, list[str]] = {}
        root_new: list[Path] = []

        inbox_prefix = str(self._vault_dir / "inbox")
        kb_prefix = str(self._vault_dir / "agnt-kb")

        for fpath in new_files:
            p = Path(fpath)
            fpath_str = str(p)
            if fpath_str.startswith(inbox_prefix):
                inbox_new.append(p.name)
            elif fpath_str.startswith(kb_prefix):
                # Extract KB slug
                try:
                    rel = p.relative_to(self._vault_dir / "agnt-kb")
                    slug = rel.parts[0]
                    kb_new.setdefault(slug, []).append(p.name)
                except (ValueError, IndexError):
                    pass
            else:
                # Root folder file — user's own content
                root_new.append(p)

        import shutil

        slugs_to_compile: set[str] = set()

        # Process inbox/ files (explicit drop zone — files get MOVED)
        if inbox_new:
            log.info("Inbox watcher: %d new files in inbox/: %s", len(inbox_new), ", ".join(inbox_new[:5]))
            try:
                kbs = self._kb.list_kbs()
                slug = "general"
                if not any(k["slug"] == slug for k in kbs):
                    self._kb.create_kb("General")

                kb_inbox = self._vault_dir / "agnt-kb" / slug / "inbox"
                kb_inbox.mkdir(parents=True, exist_ok=True)
                for fname in inbox_new:
                    src = self._vault_dir / "inbox" / fname
                    if not src.exists():
                        continue
                    dest = kb_inbox / fname
                    if dest.exists():
                        src.unlink()  # already in KB inbox
                    else:
                        shutil.move(str(src), str(dest))

                # Try Librarian subagent first, fall back to direct KB call
                librarian_result = await self._delegate_to_librarian(
                    f"Ingest {len(inbox_new)} new files in KB '{slug}': {', '.join(inbox_new[:5])}"
                )
                if librarian_result is None:
                    result = await self._kb.ingest(slug)
                    ingested.extend(result.get("ingested", []))
                    if result.get("ingested"):
                        slugs_to_compile.add(slug)
                else:
                    ingested.extend(inbox_new)
                if self._heartbeat:
                    agent_name = "librarian" if librarian_result else "system"
                    await self._heartbeat.record_pulse("automation", f"Auto-ingested {len(inbox_new)} files from inbox/ ({agent_name})")
            except Exception as exc:
                log.exception("Inbox watcher: inbox ingest failed")
                for fname in inbox_new:
                    fpath = str(self._vault_dir / "inbox" / fname)
                    self._fail_counts[fpath] = self._fail_counts.get(fpath, 0) + 1
                if self._heartbeat:
                    await self._heartbeat.record_pulse("error", f"Inbox ingest failed: {exc}")

        # Process root folder files (user's content — COPY to KB inbox via global inbox)
        # Single KB → route there.  Multiple KBs → default to "general".
        if root_new:
            log.info("Inbox watcher: %d new files in root folder (queued in inbox/)", len(root_new))
            try:
                global_inbox = self._vault_dir / "inbox"
                global_inbox.mkdir(parents=True, exist_ok=True)
                copied = 0
                for src in root_new:
                    dest = global_inbox / src.name
                    # Always copy — overwrites stale version for modified files
                    shutil.copy2(str(src), str(dest))
                    copied += 1

                if copied:
                    # Route to target KB: single KB → that one, multiple → "general"
                    kbs = self._kb.list_kbs()
                    if len(kbs) == 1:
                        slug = kbs[0]["slug"]
                    else:
                        slug = "general"
                        if not any(k["slug"] == slug for k in kbs):
                            self._kb.create_kb("General")

                    kb_inbox = self._vault_dir / "agnt-kb" / slug / "inbox"
                    kb_inbox.mkdir(parents=True, exist_ok=True)
                    for src in root_new:
                        gi_file = global_inbox / src.name
                        if gi_file.exists():
                            dest = kb_inbox / src.name
                            if dest.exists():
                                dest.unlink()  # remove stale version
                            shutil.move(str(gi_file), str(dest))
                    librarian_result = await self._delegate_to_librarian(
                        f"Ingest {copied} new files from user's vault into KB '{slug}'"
                    )
                    if librarian_result is None:
                        result = await self._kb.ingest(slug)
                        ingested.extend(result.get("ingested", []))
                        if result.get("ingested"):
                            slugs_to_compile.add(slug)
                    else:
                        ingested.extend([str(f.name) for f in root_new[:copied]])
                    if self._heartbeat:
                        agent_name = "librarian" if librarian_result else "system"
                        await self._heartbeat.record_pulse("automation", f"Auto-ingested {copied} root files into KB {slug} ({agent_name})")
            except Exception as exc:
                log.exception("Inbox watcher: root folder processing failed")
                for src in root_new:
                    self._fail_counts[str(src)] = self._fail_counts.get(str(src), 0) + 1
                if self._heartbeat:
                    await self._heartbeat.record_pulse("error", f"Root folder processing failed: {exc}")

        # Process per-KB inbox/ files
        for slug, files in kb_new.items():
            log.info("Inbox watcher: %d new files in agnt-kb/%s/inbox/: %s", len(files), slug, ", ".join(files[:5]))
            try:
                result = await self._kb.ingest(slug)
                ingested.extend(result.get("ingested", []))
                if result.get("ingested"):
                    slugs_to_compile.add(slug)
                if self._heartbeat:
                    await self._heartbeat.record_pulse("automation", f"Auto-ingested {len(files)} files into KB {slug}")
            except Exception:
                log.exception("Inbox watcher: KB %s ingest failed", slug)
                for fname in files:
                    fpath = str(self._vault_dir / "agnt-kb" / slug / "inbox" / fname)
                    self._fail_counts[fpath] = self._fail_counts.get(fpath, 0) + 1

        # Compile once per KB after all ingests are done
        for slug in slugs_to_compile:
            try:
                await self._kb.compile_wiki(slug)
            except Exception:
                log.exception("Inbox watcher: compile_wiki failed for KB %s", slug)

        # Reflect: ask Editor to review what just changed
        # Only trigger for significant batches (3+ files) to avoid trivial decision records
        if slugs_to_compile and self._orchestrator and len(ingested) >= 3:
            try:
                kb_names = ", ".join(slugs_to_compile)
                await self._delegate_to_editor(
                    f"Reflect on changes: {len(ingested)} files just ingested and compiled in KBs: {kb_names}. "
                    f"Files: {', '.join(ingested[:10])}. "
                    f"Only create a decision record if there was a SIGNIFICANT structural change "
                    f"(new category, major entity, reframing). Do NOT create records for routine ingestion of similar sources. "
                    f"Ask: what decision was made? what alternatives existed? what bias might this introduce?"
                )
            except Exception:
                log.debug("Post-compile reflection failed", exc_info=True)

        if ingested:
            log.info("Inbox watcher: auto-ingested %d files total", len(ingested))

        # Mark files as known only after successful processing
        # Files that failed to ingest stay "new" and will be retried next cycle
        self._known_files = current_files
        self._snapshot_file_stats(current_files)

        # ── Detect deletions, renames, and moves in root folder ──
        if self._root_dir and self._root_dir != self._vault_dir:
            await self._detect_root_changes()

        return ingested

    async def _detect_root_changes(self) -> None:
        """Detect deleted, renamed, or moved files in the root folder.

        Uses content hashing (like git rename detection):
        - File gone from known path → search all files for same hash
        - Hash found at new path → renamed/moved → update source reference
        - Hash not found anywhere → truly deleted → mark wiki article as stale
        """
        import hashlib

        # Build current state: path → hash for all root files
        current_hashes: dict[str, str] = {}
        for f in self._root_dir.rglob("*"):
            if not f.is_file():
                continue
            rel_parts = f.relative_to(self._root_dir).parts
            if any(part in self._SKIP_DIRS or part.startswith(".") for part in rel_parts):
                continue
            if f.suffix.lower() in (".md", ".txt", ".html", ".pdf", ".png", ".jpg", ".jpeg", ".csv"):
                try:
                    content_hash = hashlib.md5(f.read_bytes()[:5000]).hexdigest()[:12]
                    current_hashes[str(f)] = content_hash
                except Exception:
                    pass

        # First run — just record state, don't detect changes
        if not self._root_file_hashes:
            self._root_file_hashes = current_hashes
            return

        # Find disappeared files
        old_paths = set(self._root_file_hashes.keys())
        new_paths = set(current_hashes.keys())
        disappeared = old_paths - new_paths

        if not disappeared:
            self._root_file_hashes = current_hashes
            return

        # Build reverse lookup: hash → current path
        hash_to_path: dict[str, str] = {}
        for path, h in current_hashes.items():
            hash_to_path[h] = path

        # Check each disappeared file
        for old_path in disappeared:
            old_hash = self._root_file_hashes[old_path]
            old_name = Path(old_path).name

            if old_hash in hash_to_path:
                # Found at a different path — renamed or moved
                new_path = hash_to_path[old_hash]
                new_name = Path(new_path).name
                log.info("Root file moved/renamed: %s → %s", old_name, new_name)
                # Update source reference in wiki (best effort)
                try:
                    self._update_source_reference(old_name, new_name, new_path)
                except Exception:
                    log.debug("Failed to update source reference for %s", old_name)
            else:
                # Hash not found anywhere — truly deleted
                log.info("Root file deleted: %s — marking wiki article as stale", old_name)
                try:
                    self._mark_article_stale(old_name)
                except Exception:
                    log.debug("Failed to mark article stale for %s", old_name)

        self._root_file_hashes = current_hashes

    def _mark_article_stale(self, filename: str) -> None:
        """Mark wiki source article as stale when source file is deleted."""
        import re
        slug = Path(filename).stem.lower().replace(" ", "-")

        # Search across all KBs for matching source page
        kb_dir = self._vault_dir / "agnt-kb"
        if not kb_dir.is_dir():
            return

        for kb in kb_dir.iterdir():
            if not kb.is_dir():
                continue
            source_page = kb / "wiki" / "sources" / f"{slug}.md"
            if source_page.exists():
                content = source_page.read_text(encoding="utf-8")
                # Update status to stale
                if "status: verified" in content or "status: draft" in content:
                    content = re.sub(
                        r"status:\s*\w+",
                        "status: stale",
                        content, count=1,
                    )
                    # Add deletion note
                    content += (
                        f"\n\n> **Source deleted**: The original file `{filename}` "
                        f"was removed from the vault. This article may be outdated.\n"
                    )
                    source_page.write_text(content, encoding="utf-8")
                    log.info("Marked as stale: %s in KB %s", slug, kb.name)

    def _update_source_reference(self, old_name: str, new_name: str, new_path: str) -> None:
        """Update wiki source references when a file is renamed or moved."""
        kb_dir = self._vault_dir / "agnt-kb"
        if not kb_dir.is_dir():
            return

        old_slug = Path(old_name).stem.lower().replace(" ", "-")
        new_slug = Path(new_name).stem.lower().replace(" ", "-")

        for kb in kb_dir.iterdir():
            if not kb.is_dir():
                continue
            source_page = kb / "wiki" / "sources" / f"{old_slug}.md"
            if source_page.exists():
                content = source_page.read_text(encoding="utf-8")
                # Update filename references
                content = content.replace(old_name, new_name)
                # Rename the file if slug changed
                if old_slug != new_slug:
                    new_page = kb / "wiki" / "sources" / f"{new_slug}.md"
                    source_page.rename(new_page)
                    new_page.write_text(content, encoding="utf-8")
                    log.info("Renamed source page: %s → %s in KB %s", old_slug, new_slug, kb.name)
                else:
                    source_page.write_text(content, encoding="utf-8")

    async def _delegate_to_librarian(self, task: str) -> str | None:
        """Try to delegate KB work to the Librarian subagent. Returns result or None."""
        if not self._orchestrator:
            return None
        try:
            result = await self._orchestrator.dispatch(
                agent_name="librarian",
                task=task,
                context="Triggered by inbox watcher automation.",
            )
            log.info("Librarian completed: %s", result.content[:100])
            return result.content
        except Exception:
            log.debug("Librarian delegation failed, falling back to direct KB call", exc_info=True)
            return None

    async def _delegate_to_editor(self, task: str) -> str | None:
        """Try to delegate quality/reflection work to the Editor subagent."""
        if not self._orchestrator:
            return None
        try:
            result = await self._orchestrator.dispatch(
                agent_name="editor",
                task=task,
                context="Triggered by post-compile reflection.",
            )
            log.info("Editor completed: %s", result.content[:100])
            return result.content
        except Exception:
            log.debug("Editor delegation failed", exc_info=True)
            return None

    async def _loop(self) -> None:
        while self._running:
            try:
                await self.check_and_ingest()
            except asyncio.CancelledError:
                break
            except Exception:
                log.exception("Inbox watcher error")
            await asyncio.sleep(self._interval)
