"""Daily cycle: morning briefing + end-of-day report with reflection.

Runs on a 1-minute check loop. Triggers at configured times.
Results saved to journal and vault.

ARCHITECTURE INVARIANT: Every scheduled file type MUST be produced every day.
If data (journal, tasks, memory) is unavailable, the file is still created
with a note explaining what was missing. LLM failures are retried indefinitely
until content is produced. On startup, ALL missing files for today (and past
7 days) are generated. No dependency gating, no silent skips, no giving up.
"""

from __future__ import annotations

import asyncio
import logging
from datetime import UTC, datetime
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from agntspace.agent.orchestrator import Orchestrator
    from agntspace.automation.heartbeat import Heartbeat
    from agntspace.coach.service import CoachService
    from agntspace.journal.reflection import ReflectionService
    from agntspace.journal.service import JournalService
    from agntspace.kb.memory_bridge import MemoryWikiBridge
    from agntspace.llm.base import LLMProvider
    from agntspace.memory.engine import MemoryEngine
    from agntspace.skillschool.service import SkillSchoolService
    from agntspace.tasks.service import TaskService
    from agntspace.trust.service import TrustService
    from agntspace.vault.reader import VaultReader
    from agntspace.vault.search import VaultSearch
    from agntspace.vault.writer import VaultWriter

log = logging.getLogger(__name__)

# Retry delays in seconds — exponential backoff capped at 5 minutes
_RETRY_DELAYS = [10, 30, 60, 120, 300]  # then repeats 300 forever


def sanitize_llm_output(text: str) -> str:
    """Post-process LLM output to ensure clean markdown.

    Small local models sometimes output raw JSON instead of markdown.
    This detects that and converts it to readable markdown.
    Also strips common LLM preamble noise.
    """
    import json as _json

    stripped = text.strip()

    # Detect raw JSON object — convert to markdown
    if stripped.startswith("{") and stripped.endswith("}"):
        try:
            data = _json.loads(stripped)
            return _json_to_markdown(data)
        except _json.JSONDecodeError:
            pass

    # Detect JSON array
    if stripped.startswith("[") and stripped.endswith("]"):
        try:
            data = _json.loads(stripped)
            if isinstance(data, list):
                parts = []
                for item in data:
                    if isinstance(item, dict):
                        parts.append(_json_to_markdown(item))
                    else:
                        parts.append(f"- {item}")
                return "\n\n".join(parts)
        except _json.JSONDecodeError:
            pass

    # Strip tool-call-like noise at the start (model hallucinated a tool call
    # then continued with real content)
    if stripped.startswith('{"') and "\n" in stripped:
        first_newline = stripped.index("\n")
        rest = stripped[first_newline:].strip()
        if rest and not rest.startswith("{"):
            log.warning("Stripped leading JSON noise from LLM output")
            return rest

    return text


def _json_to_markdown(data: dict, depth: int = 2) -> str:
    """Convert a JSON dict to readable markdown with headers and bullets."""
    lines: list[str] = []
    hdr = "#" * depth

    for key, value in data.items():
        # Skip nested date wrappers (e.g. {"2026-04-03": {...}})
        if isinstance(value, dict) and len(data) == 1:
            return _json_to_markdown(value, depth)

        title = key.replace("_", " ").replace("-", " ").title()
        lines.append(f"{hdr} {title}")

        if isinstance(value, str):
            lines.append(value)
        elif isinstance(value, list):
            if not value:
                lines.append("*None.*")
            else:
                for item in value:
                    if isinstance(item, dict):
                        for k, v in item.items():
                            lines.append(f"- **{k}**: {v}")
                    else:
                        lines.append(f"- {item}")
        elif isinstance(value, dict):
            lines.append(_json_to_markdown(value, depth + 1))
        elif value is None:
            lines.append("*None.*")
        else:
            lines.append(str(value))

        lines.append("")  # blank line between sections

    return "\n".join(lines).strip()


def _retry_delay(attempt: int) -> int:
    """Get retry delay for the given attempt number (1-based)."""
    idx = min(attempt - 1, len(_RETRY_DELAYS) - 1)
    return _RETRY_DELAYS[idx]


def _get_model_name(agent: object | None, llm: object | None) -> str:
    """Extract the current model name from the agent's LLM provider."""
    try:
        if agent and hasattr(agent, "_llm") and hasattr(agent._llm, "_model"):
            return agent._llm._model
    except Exception:
        pass
    try:
        if llm and hasattr(llm, "_model"):
            return llm._model
    except Exception:
        pass
    return "unknown"


class DailyCycle:
    """Manages morning briefing and end-of-day report generation."""

    def __init__(
        self,
        llm: LLMProvider,
        journal: JournalService,
        task_service: TaskService,
        coach: CoachService,
        trust_service: TrustService,
        reflection_service: ReflectionService,
        vault_reader: VaultReader,
        vault_writer: VaultWriter,
        memory_engine: MemoryEngine | None = None,
        heartbeat: Heartbeat | None = None,
        skillschool: SkillSchoolService | None = None,
        vault_search: VaultSearch | None = None,
        orchestrator: Orchestrator | None = None,
        memory_bridge: MemoryWikiBridge | None = None,
        morning_hour: int = 7,
        evening_hour: int = 21,
        weekly_compaction_day: int = 6,  # 0=Mon, 6=Sun
        skill_loader: object | None = None,
        model_router: object | None = None,
    ) -> None:
        self._llm = llm
        self._journal = journal
        self._tasks = task_service
        self._coach = coach
        self._trust = trust_service
        self._reflection = reflection_service
        self._reader = vault_reader
        self._writer = vault_writer
        self._memory_engine = memory_engine
        self._heartbeat = heartbeat
        self._skillschool = skillschool
        self._vault_search = vault_search
        self._orchestrator = orchestrator
        self._memory_bridge = memory_bridge
        self._skill_loader = skill_loader
        self._model_router = model_router
        self._agent: object | None = None  # injected post-hoc from main.py
        self._fill_lock = asyncio.Lock()  # prevent concurrent fill workflows
        self._last_editor: str = ""
        self._morning_hour = morning_hour
        self._evening_hour = evening_hour
        self._weekly_day = weekly_compaction_day
        self._task: asyncio.Task | None = None  # type: ignore[type-arg]
        self._running = False
        self._last_morning: str = ""
        self._last_evening: str = ""
        self._last_weekly: str = ""
        self._latest_briefing: str = ""
        self._latest_eod: str = ""

    def start(self) -> None:
        if self._running:
            return
        self._running = True
        self._task = asyncio.create_task(self._run())
        log.warning(
            "Daily cycle started (morning: %02d:00 UTC, evening: %02d:00 UTC, weekly: day %d)",
            self._morning_hour,
            self._evening_hour,
            self._weekly_day,
        )

    async def _run(self) -> None:
        """Run catch-up first, then enter the regular loop."""
        await self._catch_up()
        await self._loop()

    def stop(self) -> None:
        self._running = False
        if self._task:
            self._task.cancel()
            self._task = None

    @property
    def latest_briefing(self) -> str:
        return self._latest_briefing

    @property
    def latest_eod(self) -> str:
        return self._latest_eod

    # ── LLM call with infinite retry ───────────────────────────────

    async def _call_agent(self, task: str, context: str, label: str) -> str:
        """Call the agent, retrying indefinitely until content is produced.

        Never returns None — keeps trying until the LLM responds.
        Logs every failure at WARNING level. Post-processes output to
        ensure clean markdown (catches JSON hallucinations from small models).
        """
        attempt = 0
        while True:
            attempt += 1

            if not self._agent:
                delay = _retry_delay(attempt)
                log.warning("[%s] Agent not available — waiting %ds before retry (attempt %d)", label, delay, attempt)
                await asyncio.sleep(delay)
                continue

            try:
                result = await self._agent.process_task(task=task, context=context)
                if result and result.strip():
                    clean = sanitize_llm_output(result)
                    if clean and clean.strip():
                        if attempt > 1:
                            log.warning("[%s] Succeeded on attempt %d", label, attempt)
                        return clean
                log.warning("[%s] Agent returned empty response (attempt %d)", label, attempt)
            except Exception as exc:
                log.warning("[%s] LLM call failed (attempt %d): %s", label, attempt, exc)
                if self._heartbeat:
                    try:
                        await self._heartbeat.record_pulse("error", f"{label} attempt {attempt} failed: {exc}")
                    except Exception:
                        pass

            delay = _retry_delay(attempt)
            log.warning("[%s] Retrying in %ds...", label, delay)
            await asyncio.sleep(delay)

    # ── Context gathering (never raises) ───────────────────────────

    def _gather_briefing_context(self) -> str:
        """Gather all available context for morning briefing. Missing data noted inline."""
        parts: list[str] = []

        # User's focus
        focus_text = "Not set — suggest based on tasks and goals."
        try:
            focus_content = self._journal.get_section("Focus")
            if focus_content:
                focus_text = focus_content
        except Exception as exc:
            log.warning("[Briefing context] Failed to read focus: %s", exc)
        parts.append(f"USER'S FOCUS FOR TODAY:\n{focus_text}")

        # Active tasks
        try:
            tasks = self._tasks.list_tasks()
            active_tasks = [t for t in tasks if t.get("status") not in ("done", "cancelled")]
            task_text = "\n".join(
                f"- {t['title']} [{t['status']}] (mode: {t['mode']}, domain: {t['domain']})"
                for t in active_tasks
            ) or "No active tasks."
        except Exception as exc:
            task_text = f"(Task data unavailable: {exc})"
            log.warning("[Briefing context] Failed to read tasks: %s", exc)
        parts.append(f"ACTIVE TASKS:\n{task_text}")

        # Goals
        try:
            goals = self._coach.list_goals(status_filter="active")
            goals_text = "\n".join(f"- {g['title']} (due: {g.get('target_date', 'no date')})" for g in goals) or "No active goals."
        except Exception as exc:
            goals_text = f"(Goals data unavailable: {exc})"
            log.warning("[Briefing context] Failed to read goals: %s", exc)
        parts.append(f"GOALS:\n{goals_text}")

        # Coaching nudges
        try:
            nudges = self._coach.generate_nudges()
            nudges_text = "\n".join(f"- {n}" for n in nudges) or "No nudges."
        except Exception as exc:
            nudges_text = f"(Nudges unavailable: {exc})"
            log.warning("[Briefing context] Failed to generate nudges: %s", exc)
        parts.append(f"COACHING NUDGES:\n{nudges_text}")

        # Yesterday's journal
        from datetime import timedelta
        yesterday = (datetime.now(UTC) - timedelta(days=1)).strftime("%Y-%m-%d")
        try:
            yesterday_doc = self._journal.get_entry(yesterday)
            yesterday_text = yesterday_doc.content[:1500] if yesterday_doc else "No journal entry yesterday."
        except Exception as exc:
            yesterday_text = f"(Yesterday's journal unavailable: {exc})"
            log.warning("[Briefing context] Failed to read yesterday's journal: %s", exc)
        parts.append(f"YESTERDAY'S JOURNAL:\n{yesterday_text}")

        # Memory
        memory_text = "(No memory file found.)"
        try:
            memory_path = "agnt-memory/MEMORY.md"
            if self._reader.exists(memory_path):
                memory_text = self._reader.read(memory_path).content[:1000]
        except Exception as exc:
            memory_text = f"(Memory unavailable: {exc})"
            log.warning("[Briefing context] Failed to read memory: %s", exc)
        parts.append(f"MEMORY:\n{memory_text}")

        # Evolution context
        evolution_parts: list[str] = []
        try:
            trust_changes = self._trust.get_recent_changes(since_date=yesterday)
            if trust_changes:
                evolution_parts.append("Trust changes:\n" + "\n".join(trust_changes))
        except Exception:
            pass
        if self._skillschool:
            try:
                proposals = self._skillschool.list_proposals()
                pending = [p for p in proposals if p.get("status") == "pending"]
                if pending:
                    evolution_parts.append(f"{len(pending)} pending skill proposal(s): " + ", ".join(p.get("title", p.get("name", "?")) for p in pending))
            except Exception:
                pass
        try:
            stalled = self._coach.detect_stalls()
            if stalled:
                evolution_parts.append(f"{len(stalled)} stalled goal(s): " + ", ".join(s.get("title", "?") for s in stalled))
        except Exception:
            pass
        evolution_text = "\n".join(evolution_parts) or "No evolution updates."
        parts.append(f"EVOLUTION:\n{evolution_text}")

        # Upcoming — placeholder, filled by async caller
        parts.append("UPCOMING SCHEDULES & DEADLINES:\nNone found.")

        return "\n\n".join(parts)

    def _gather_eod_context(self, date: str) -> str:
        """Gather all available context for EOD report. Missing data noted inline."""
        parts: list[str] = []

        # Journal for the date
        try:
            journal_doc = self._journal.get_entry(date)
            journal_text = journal_doc.content[:2000] if journal_doc else "No journal entries for this day."
        except Exception as exc:
            journal_text = f"(Journal data unavailable: {exc})"
            log.warning("[EOD context] Failed to read journal for %s: %s", date, exc)
        parts.append(f"JOURNAL FOR {date}:\n{journal_text}")

        # Tasks
        try:
            tasks = self._tasks.list_tasks()
            task_text = "\n".join(f"- {t['title']} [{t['status']}]" for t in tasks) or "No tasks."
        except Exception as exc:
            task_text = f"(Task data unavailable: {exc})"
            log.warning("[EOD context] Failed to read tasks: %s", exc)
        parts.append(f"ACTIVE TASKS:\n{task_text}")

        # Goals
        try:
            goals = self._coach.list_goals(status_filter="active")
            goals_text = "\n".join(f"- {g['title']}" for g in goals) or "No active goals."
        except Exception as exc:
            goals_text = f"(Goals data unavailable: {exc})"
            log.warning("[EOD context] Failed to read goals: %s", exc)
        parts.append(f"GOALS:\n{goals_text}")

        return "\n\n".join(parts)

    async def _gather_upcoming_text(self) -> str:
        """Search vault for upcoming schedules (async)."""
        if not self._vault_search:
            return "None found."
        try:
            searches = ["scheduled activities", "maintenance due", "deadline upcoming", "recurring"]
            all_results: list[str] = []
            seen_paths: set[str] = set()
            for query in searches:
                results = await self._vault_search.search(query, limit=3)
                for r in results:
                    path = r.get("path", "")
                    if path not in seen_paths:
                        seen_paths.add(path)
                        snippet = r.get("snippet", "")[:300]
                        all_results.append(f"[{path}] {snippet}")
            if all_results:
                return "\n".join(all_results[:8])
        except Exception as exc:
            log.warning("[Briefing context] Vault search failed: %s", exc)
        return "None found."

    # ── File builders (frontmatter with model attribution) ─────────

    def _build_frontmatter(
        self,
        title: str,
        date: str,
        file_type: str,
        agent_name: str,
        description: str,
        extra: dict | None = None,
    ) -> str:
        """Build YAML frontmatter with model attribution and generation timestamp."""
        model = _get_model_name(self._agent, self._llm)
        now = datetime.now(UTC)
        generated_at = now.strftime("%H:%M UTC")
        lines = [
            "---",
            f'title: "{title}"',
            f'date: "{date}"',
            f'generated_at: "{generated_at}"',
            f"type: {file_type}",
            f"author: agent",
            f"agent: {agent_name}",
            f'model: "{model}"',
            f'description: "{description}"',
        ]
        if extra:
            for k, v in extra.items():
                if isinstance(v, bool):
                    lines.append(f"{k}: {'true' if v else 'false'}")
                elif isinstance(v, str):
                    lines.append(f"{k}: {v}")
                else:
                    lines.append(f"{k}: {v}")
        lines.append("---")
        return "\n".join(lines)

    def _is_fallback_file(self, path: str) -> bool:
        """Check if a file is a fallback placeholder (should be regenerated)."""
        try:
            if self._reader.exists(path):
                doc = self._reader.read(path)
                return doc.metadata.get("generation_failed", False) is True
        except Exception:
            pass
        return False

    def _needs_generation(self, path: str) -> bool:
        """Check if a file needs to be (re)generated."""
        if not self._reader.exists(path):
            return True
        return self._is_fallback_file(path)

    # ── Morning briefing ───────────────────────────────────────────

    async def generate_morning_briefing(self) -> str:
        """Generate the morning briefing via the main agent.

        Retries indefinitely until content is produced. Always writes a file.
        """
        today = datetime.now(UTC).strftime("%Y-%m-%d")
        path = f"journal/morning-briefing_{today}.md"
        label = "Morning briefing"

        # Gather context (never raises)
        dynamic_ctx = self._gather_briefing_context()

        # Async search for upcoming items
        upcoming = await self._gather_upcoming_text()
        dynamic_ctx = dynamic_ctx.replace(
            "UPCOMING SCHEDULES & DEADLINES:\nNone found.",
            f"UPCOMING SCHEDULES & DEADLINES:\n{upcoming}",
        )

        task_instruction = (
            "Generate my morning briefing for today using EXACTLY this markdown format:\n\n"
            "## Good Morning\n"
            "A brief personalized greeting (1-2 sentences).\n\n"
            "## Today's Focus\n"
            "Honor the user's focus if set, otherwise suggest top priorities.\n\n"
            "## Active Tasks\n"
            "- Task name — status and brief note\n"
            "- (bullet list of in-progress and pending tasks)\n\n"
            "## Upcoming\n"
            "Scheduled items and deadlines. Write *Nothing scheduled.* if empty.\n\n"
            "## Coaching Nudges\n"
            "Any nudges from the coaching system. Write *None today.* if empty.\n\n"
            "## Yesterday's Takeaway\n"
            "One key thing from yesterday worth carrying forward.\n\n"
            "## Evolution\n"
            "Trust changes, skill proposals, stalled goals. Write *No updates.* if empty.\n\n"
            "---\n"
            "RULES: Output ONLY valid markdown. Use ## headers exactly as shown. "
            "Use bullet lists (- item) for lists. Keep it under 300 words. "
            "Be warm but efficient. Never output JSON. "
            "If any data source was unavailable, note it briefly under the relevant section."
        )

        briefing = await self._call_agent(task_instruction, dynamic_ctx, label)

        fm = self._build_frontmatter(
            f"Morning Briefing — {today}", today, "briefing", "ops-supervisor",
            "Daily morning briefing — today's priorities, active tasks, upcoming deadlines, coaching nudges, and yesterday's takeaway.",
        )
        self._writer.write(path, f"{fm}\n\n{briefing}")
        self._latest_briefing = briefing
        self._journal.append_action("Morning briefing generated")
        log.warning("[%s] Generated successfully (%d chars)", label, len(briefing))
        if self._heartbeat:
            await self._heartbeat.record_pulse("automation", "Morning briefing generated")
        return briefing

    # ── End-of-day report ──────────────────────────────────────────

    async def generate_eod_report(self) -> str:
        """Generate end-of-day report via the main agent + trigger cascade."""
        today = datetime.now(UTC).strftime("%Y-%m-%d")
        return await self._generate_eod_for_date(today, catch_up=False)

    async def _generate_eod_for_date(self, date: str, catch_up: bool = False) -> str:
        """Generate EOD report for a specific date. Retries indefinitely."""
        path = f"journal/eod-report_{date}.md"
        label = f"EOD report ({date})"

        eod_ctx = self._gather_eod_context(date)

        retro = " (retroactive catch-up)" if catch_up else ""
        task_instruction = (
            f"Generate an end-of-day report for {date}{retro} using EXACTLY this markdown format:\n\n"
            "## Day Summary\n"
            "2-3 sentences on what happened today.\n\n"
            "## Completed\n"
            "- Task or achievement\n"
            "- (bullet list, or *Nothing completed.* if empty)\n\n"
            "## Still Active\n"
            "- Task that carries over to tomorrow\n"
            "- (bullet list, or *Nothing pending.* if empty)\n\n"
            "## Decisions Made\n"
            "- Decision and brief reasoning\n"
            "- (bullet list, or *No decisions recorded.* if empty)\n\n"
            "## Learnings\n"
            "- Thing worth remembering\n"
            "- (bullet list, or *No learnings today.* if empty)\n\n"
            "## Memory Updates\n"
            "- Add: specific fact to remember\n"
            "- Update: correction to existing memory\n"
            "- (or *No memory updates.* if nothing new)\n\n"
            "---\n"
            "RULES: Output ONLY valid markdown. Use ## headers exactly as shown. "
            "Use bullet lists (- item) for lists. Keep it concise and actionable. "
            "Never output JSON. "
            "If any data source was unavailable, note it briefly under Day Summary."
        )

        eod = await self._call_agent(task_instruction, eod_ctx, label)

        extra = {"catch_up": True} if catch_up else None
        fm = self._build_frontmatter(
            f"EOD Report — {date}", date, "eod_report", "ops-supervisor",
            f"End-of-day summary — completed tasks, active items, decisions made, learnings, and memory updates{' (retroactive catch-up)' if catch_up else ''}.",
            extra=extra,
        )
        self._writer.write(path, f"{fm}\n\n{eod}")
        self._latest_eod = eod
        self._journal.append_action(f"EOD report generated for {date}")
        log.warning("[%s] Generated successfully (%d chars)", label, len(eod))
        if self._heartbeat:
            await self._heartbeat.record_pulse("automation", f"EOD report generated for {date}")

        # Post-EOD cascade runs in background
        asyncio.create_task(self._post_eod_cascade(date))

        return eod

    async def _post_eod_cascade(self, today: str) -> None:
        """Run reflection, memory generation, and bridges after EOD.

        Each step is independent — failures don't block the next step.
        """
        # Trigger daily reflection (it has its own infinite retry)
        try:
            await self._reflection.run_daily_reflection(today)
            log.warning("Daily reflection triggered for %s", today)
        except Exception as exc:
            log.warning("Daily reflection failed for %s: %s", today, exc)

        # Generate daily memory file
        if self._memory_engine:
            try:
                result = await self._memory_engine.generate_daily_memory(today)
                log.warning("Daily memory generated: %s", result.get("path", "?"))
            except Exception as exc:
                log.warning("Daily memory generation failed for %s: %s", today, exc)

        # Memory ↔ Wiki bridge
        if self._memory_bridge:
            try:
                m2w = await self._memory_bridge.memory_to_wiki(today)
                log.warning("Memory->Wiki: %d updates filed", m2w.get("updates_filed", 0))
            except Exception as exc:
                log.warning("Memory->Wiki bridge failed: %s", exc)
            try:
                w2m = await self._memory_bridge.wiki_to_memory()
                log.warning("Wiki->Memory: %d pending facts", w2m.get("count", 0))
            except Exception as exc:
                log.warning("Wiki->Memory bridge failed: %s", exc)

        # System bridge
        if hasattr(self, "_system_bridge") and self._system_bridge:
            try:
                sb_result = await self._system_bridge.sync_all(today)
                log.warning("SystemBridge: %d triples synced", sb_result.get("total", 0))
            except Exception as exc:
                log.warning("SystemBridge sync failed: %s", exc)

        log.warning("Post-EOD cascade complete for %s", today)

    async def run_weekly_compaction(self) -> None:
        """Run weekly reflection + memory compaction."""
        today = datetime.now(UTC).strftime("%Y-%m-%d")
        try:
            result = await self._reflection.run_weekly_reflection(today)
            log.warning("Weekly reflection completed: %s", result.get("week", "?"))
        except Exception as exc:
            log.warning("Weekly reflection/compaction failed: %s", exc)

    def status(self) -> dict:
        return {
            "running": self._running,
            "morning_hour": self._morning_hour,
            "evening_hour": self._evening_hour,
            "weekly_compaction_day": self._weekly_day,
            "last_morning": self._last_morning,
            "last_evening": self._last_evening,
            "last_weekly": self._last_weekly,
            "has_briefing": bool(self._latest_briefing),
            "has_eod": bool(self._latest_eod),
            "agent_available": self._agent is not None,
            "model": _get_model_name(self._agent, self._llm),
        }

    # ── Startup catch-up ───────────────────────────────────────────

    async def _catch_up(self) -> None:
        """Generate ALL missing daily cycle files on startup.

        Respects time-of-day for today's files (don't generate
        tonight's EOD in the morning). Past days always filled.
        """
        async with self._fill_lock:
            await self._run_fill_workflow(force=False)

    async def _run_fill_workflow(self, *, force: bool = False) -> dict:
        """Fill all missing journal files for the last 7 days.

        Args:
            force: When True (manual trigger), ignores time-of-day checks
                   and generates ALL file types for today. When False
                   (startup catch-up), respects schedule hours.
        """
        from datetime import timedelta

        now = datetime.now(UTC)
        today = now.strftime("%Y-%m-%d")
        generated: list[str] = []

        log.warning(
            "Journal fill workflow starting (force=%s, agent: %s, model: %s)",
            force,
            "available" if self._agent else "NOT AVAILABLE",
            _get_model_name(self._agent, self._llm),
        )

        # Today's morning briefing — always when forced, otherwise respect schedule
        if force or now.hour >= self._morning_hour:
            briefing_path = f"journal/morning-briefing_{today}.md"
            if self._needs_generation(briefing_path):
                log.warning("Fill: generating morning briefing for %s", today)
                await self.generate_morning_briefing()
                generated.append(f"morning briefing ({today})")

        # EOD reports + reflections for today and past 7 days
        for days_ago in range(0, 8):
            date = (now - timedelta(days=days_ago)).strftime("%Y-%m-%d")

            # Skip today's EOD only on auto catch-up before evening hour
            if days_ago == 0 and not force and now.hour < self._evening_hour:
                # Still check reflection for today even if skipping EOD
                reflection_path = f"journal/daily-reflection_{date}.md"
                if self._needs_generation(reflection_path):
                    log.warning("Fill: generating daily reflection for %s", date)
                    try:
                        await self._reflection.run_daily_reflection(date)
                        generated.append(f"reflection ({date})")
                    except Exception as exc:
                        log.warning("Fill: daily reflection for %s failed: %s", date, exc)
                continue

            # EOD report
            eod_path = f"journal/eod-report_{date}.md"
            if self._needs_generation(eod_path):
                log.warning("Fill: generating EOD report for %s", date)
                await self._generate_eod_for_date(date, catch_up=(days_ago > 0))
                generated.append(f"EOD ({date})")

            # Daily reflection — check independently (post-EOD cascade may have failed)
            reflection_path = f"journal/daily-reflection_{date}.md"
            if self._needs_generation(reflection_path):
                log.warning("Fill: generating daily reflection for %s", date)
                try:
                    await self._reflection.run_daily_reflection(date)
                    generated.append(f"reflection ({date})")
                except Exception as exc:
                    log.warning("Fill: daily reflection for %s failed: %s", date, exc)

        # Weekly reflection
        days_since_weekly = (now.weekday() - self._weekly_day) % 7
        if days_since_weekly > 0 or force:
            if days_since_weekly == 0:
                days_since_weekly = 7  # force: check last week
            last_weekly_date = (now - timedelta(days=days_since_weekly)).strftime("%Y-%m-%d")
            last_weekly_dt = datetime.strptime(last_weekly_date, "%Y-%m-%d")
            week_num = last_weekly_dt.isocalendar()[1]
            week_label = f"{last_weekly_dt.year}-W{week_num:02d}"
            weekly_path = f"journal/weekly-reflection_{week_label}.md"

            if self._needs_generation(weekly_path):
                log.warning("Fill: generating weekly reflection for %s", week_label)
                try:
                    await self._reflection.run_weekly_reflection(last_weekly_date)
                    generated.append(f"weekly reflection ({week_label})")
                except Exception as exc:
                    log.warning("Fill: weekly reflection for %s failed: %s", week_label, exc)

        # Summary
        if generated:
            summary = f"Journal fill workflow completed: {', '.join(generated)}"
        else:
            summary = "Journal fill workflow: all files up to date"
        log.warning(summary)
        self._journal.append_observation(summary)

        return {"generated": generated, "summary": summary}

    async def run_fill_workflow(self) -> dict:
        """Public method for manual triggering via API.

        Force-fills all missing journal files — ignores time-of-day checks.
        Waits for any running fill workflow to finish first.
        """
        async with self._fill_lock:
            return await self._run_fill_workflow(force=True)

    # ── Editor pass ────────────────────────────────────────────────

    async def _run_editor_pass(self) -> None:
        """Delegate daily wiki quality pass to the Editor subagent."""
        if not self._orchestrator:
            log.warning("Editor pass skipped: no orchestrator available")
            return

        try:
            result = await self._orchestrator.dispatch(
                agent_name="editor",
                task=(
                    "Daily wiki quality and reflection pass:\n\n"
                    "## Phase 1: Lint\n"
                    "Find broken links, orphans, stale articles, missing frontmatter across all KBs.\n\n"
                    "## Phase 2: Taxonomy\n"
                    "Reclassify misplaced articles. Note clusters needing new categories.\n\n"
                    "## Phase 3: Reflect\n"
                    "Review what changed since yesterday. For any significant structural changes "
                    "(new categories, merges, reframings, articles that became hubs):\n"
                    "- What decision was made?\n"
                    "- What alternatives existed?\n"
                    "- What bias might this introduce?\n"
                    "Create decision records in wiki/decisions/ for non-trivial changes.\n\n"
                    "## Phase 4: Curate\n"
                    "Update featured article. Check index stats.\n\n"
                    "Report findings concisely."
                ),
                context="Scheduled daily editor review with structural reflection.",
            )
            log.warning("Editor pass completed: %s", result.content[:100])
            self._journal.append_observation(f"Daily editor pass completed: {result.content[:200]}")
            if self._heartbeat:
                await self._heartbeat.record_pulse("automation", "Daily editor pass completed")
        except Exception as exc:
            log.warning("Daily editor pass failed: %s", exc)
            if self._heartbeat:
                await self._heartbeat.record_pulse("error", f"Editor pass failed: {exc}")

    # ── Main loop ──────────────────────────────────────────────────

    async def _loop(self) -> None:
        while self._running:
            try:
                now = datetime.now(UTC)
                today = now.strftime("%Y-%m-%d")
                hour = now.hour

                # Morning briefing
                if hour == self._morning_hour and self._last_morning != today:
                    self._last_morning = today
                    await self.generate_morning_briefing()

                # Daily Editor pass — lint, taxonomy, curation (runs after briefing)
                editor_hour = self._morning_hour + 1  # 1 hour after briefing
                if hour == editor_hour and self._last_editor != today:
                    self._last_editor = today
                    await self._run_editor_pass()

                # End-of-day report
                if hour == self._evening_hour and self._last_evening != today:
                    self._last_evening = today
                    await self.generate_eod_report()

                    # Weekly compaction — runs after EOD on the configured day
                    if now.weekday() == self._weekly_day and self._last_weekly != today:
                        self._last_weekly = today
                        await self.run_weekly_compaction()

                        # Weekly skill analysis
                        if self._skillschool:
                            try:
                                proposals = await self._skillschool.analyze_patterns()
                                if proposals:
                                    log.warning("Weekly skill analysis: %d proposals generated", len(proposals))
                                    self._journal.append_observation(
                                        f"Skill analysis: {len(proposals)} new skill proposal(s) from task patterns"
                                    )
                            except Exception as exc:
                                log.warning("Weekly skill analysis failed: %s", exc)

            except asyncio.CancelledError:
                break
            except Exception as exc:
                log.warning("Daily cycle loop error: %s", exc, exc_info=True)
                if self._heartbeat:
                    try:
                        await self._heartbeat.record_pulse("error", f"Daily cycle: {exc}")
                    except Exception:
                        pass
            await asyncio.sleep(60)  # Check every minute
