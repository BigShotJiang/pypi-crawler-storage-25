"""Skill loader: discovers, loads, and matches SKILL.md files.

Skill folder structure:
  agnt-system/skills/{category}/{name}/
  ├── SKILL.md           ← required: frontmatter (name, triggers, etc.) + instructions
  ├── templates/         ← optional: reusable templates (email, report, etc.)
  ├── examples/          ← optional: few-shot examples for the LLM
  ├── references/        ← optional: background docs the skill can reference
  └── config.md          ← optional: skill-specific settings
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from pathlib import Path

import frontmatter

log = logging.getLogger(__name__)


@dataclass
class Skill:
    """A loaded skill definition."""

    name: str
    title: str
    description: str
    triggers: list[str] = field(default_factory=list)
    category: str = ""
    status: str = "active"
    body: str = ""
    path: str = ""
    # Additional files in the skill folder
    files: list[str] = field(default_factory=list)
    # Extended fields
    author: str = ""
    tools_granted: list[str] = field(default_factory=list)
    depends_on: list[str] = field(default_factory=list)
    priority: int = 0
    model_tier: str = ""  # "reasoning", "capable", "fast", or "" (inherit)
    examples: list[dict] = field(default_factory=list)  # [{input, output}]
    output_format: str = ""


class SkillLoader:
    """Discovers and loads SKILL.md files from the skills directory."""

    def __init__(self, skills_dir: Path) -> None:
        self._skills_dir = skills_dir
        self._skills: dict[str, Skill] = {}
        self._loaded = False
        self._full_prompt_cache: str | None = None

    def load_all(self) -> dict[str, Skill]:
        """Scan skills directory and load all SKILL.md files."""
        self._skills.clear()
        self._full_prompt_cache = None

        if not self._skills_dir.is_dir():
            log.info("Skills directory not found: %s", self._skills_dir)
            self._loaded = True
            return self._skills

        for skill_file in self._skills_dir.rglob("SKILL.md"):
            try:
                self._load_skill(skill_file)
            except Exception:
                log.warning("Failed to load skill: %s", skill_file)

        self._loaded = True
        # Validate depends_on references
        for sname, skill in self._skills.items():
            for dep in skill.depends_on:
                if dep not in self._skills:
                    log.warning("Skill '%s' depends on unknown skill '%s'", sname, dep)
        log.debug("Loaded %d skills from %s", len(self._skills), self._skills_dir)
        return self._skills

    @property
    def skills(self) -> dict[str, Skill]:
        if not self._loaded:
            self.load_all()
        return self._skills

    def get_skill(self, name: str) -> Skill | None:
        """Get a skill by name."""
        return self.skills.get(name)

    def get_system_prompt(self, skill_name: str) -> str | None:
        """Get the System Prompt section from a skill's body.

        Skills define LLM prompts in a ``## System Prompt`` section.
        Returns the content of that section, or the full body as fallback.
        """
        skill = self.get_skill(skill_name)
        if not skill or not skill.body:
            return None

        # Try to extract ## System Prompt section
        marker = "## System Prompt"
        idx = skill.body.find(marker)
        if idx == -1:
            # Fallback: use entire body as the prompt
            return skill.body.strip()

        # Extract from marker to next ## heading or end
        content = skill.body[idx + len(marker):]
        # Find next ## heading (not a subsection)
        next_heading = content.find("\n## ")
        if next_heading != -1:
            content = content[:next_heading]
        return content.strip()

    def get_skill_section(self, skill_name: str, section: str) -> str | None:
        """Get a named section (e.g. '## Week') from a skill's body.

        Returns content between the heading and the next same-level heading,
        or None if not found.
        """
        skill = self.get_skill(skill_name)
        if not skill or not skill.body:
            return None

        marker = f"## {section}"
        idx = skill.body.find(marker)
        if idx == -1:
            return None

        content = skill.body[idx + len(marker):]
        next_heading = content.find("\n## ")
        if next_heading != -1:
            content = content[:next_heading]
        return content.strip()

    def get_skill_rules(self, skill_name: str) -> str:
        """Get the Quality Rules and Rules sections from a skill body.

        These are appended to LLM prompts as additional constraints.
        """
        skill = self.get_skill(skill_name)
        if not skill or not skill.body:
            return ""

        rules_parts: list[str] = []
        for section in ("## Quality Rules", "## Rules"):
            idx = skill.body.find(section)
            if idx != -1:
                content = skill.body[idx:]
                # Find next ## heading that isn't a subsection
                lines = content.split("\n")
                end = len(lines)
                for i, line in enumerate(lines[1:], 1):
                    if line.startswith("## ") and not line.startswith("### "):
                        end = i
                        break
                rules_parts.append("\n".join(lines[:end]).strip())

        return "\n\n".join(rules_parts)

    def match_skills(self, text: str) -> list[Skill]:
        """Find skills that match user input based on triggers."""
        lower = text.lower()
        matches = []
        for skill in self.skills.values():
            if skill.status != "active":
                continue
            for trigger in skill.triggers:
                if trigger.lower() in lower:
                    matches.append(skill)
                    break
        return matches

    def get_metadata_summary(self) -> str:
        """Get a compact summary of available skills for the system prompt."""
        active = [s for s in self.skills.values() if s.status == "active"]
        active.sort(key=lambda s: s.priority, reverse=True)
        lines = []
        for skill in active:
            triggers_str = ", ".join(skill.triggers[:3]) if skill.triggers else "manual"
            extras = ""
            if skill.priority > 0:
                extras += f" [P{skill.priority}]"
            if skill.files:
                extras += f" [+{len(skill.files)} files]"
            lines.append(
                f"- **{skill.title}** ({skill.name}): {skill.description} "
                f"[triggers: {triggers_str}]{extras}"
            )
        return "\n".join(lines) if lines else "No skills loaded."

    def get_full_prompt_section(self) -> str:
        """Get full skill instructions for the system prompt (cached after first build).

        Includes the complete body of every active skill so the agent
        can actually follow the instructions, not just know names.
        Skills ordered by priority (higher first).
        """
        if self._full_prompt_cache is not None:
            return self._full_prompt_cache

        active = [
            s for s in self.skills.values()
            if s.status == "active" and s.body.strip()
        ]
        if not active:
            return "No skills loaded."

        active.sort(key=lambda s: s.priority, reverse=True)
        sections = []
        for skill in active:
            triggers_str = ", ".join(skill.triggers) if skill.triggers else "always active"
            parts = [
                f"## {skill.title} ({skill.name})",
                f"*Triggers: {triggers_str}*\n",
                skill.body.strip(),
            ]
            if skill.examples:
                parts.append("\n### Examples")
                for ex in skill.examples:
                    inp = ex.get("input", "")
                    out = ex.get("output", "")
                    parts.append(f"**Input:** {inp}\n**Output:** {out}\n")
            if skill.output_format:
                parts.append(f"\n### Expected Output Format\n{skill.output_format}")
            sections.append("\n".join(parts))
        result = "\n\n---\n\n".join(sections)
        self._full_prompt_cache = result
        return result

    def list_skills(self) -> list[dict]:
        """List all skills with metadata (for API/UI)."""
        return [
            {
                "name": s.name,
                "title": s.title,
                "description": s.description,
                "category": s.category,
                "status": s.status,
                "triggers": s.triggers,
                "path": s.path,
                "files": s.files,
                "author": s.author,
                "tools_granted": s.tools_granted,
                "depends_on": s.depends_on,
                "priority": s.priority,
                "model_tier": s.model_tier,
                "examples": s.examples,
                "output_format": s.output_format,
            }
            for s in self.skills.values()
        ]

    def get_skill_file(self, skill_name: str, filename: str) -> str | None:
        """Read an additional file from a skill folder."""
        skill = self.get_skill(skill_name)
        if not skill:
            return None
        skill_dir = self._skills_dir / Path(skill.path).parent
        file_path = skill_dir / filename
        if file_path.is_file() and file_path.resolve().is_relative_to(self._skills_dir.resolve()):
            return file_path.read_text(encoding="utf-8")
        return None

    def _load_skill(self, path: Path) -> None:
        """Load a single skill file and discover additional files."""
        raw = path.read_text(encoding="utf-8")
        post = frontmatter.loads(raw)
        meta = post.metadata

        name = meta.get("name", path.stem)
        if name in self._skills:
            return

        # Discover additional files in the skill folder
        skill_dir = path.parent
        extra_files: list[str] = []
        if skill_dir.is_dir():
            for f in sorted(skill_dir.rglob("*")):
                if not f.is_file():
                    continue
                if f.name in ("SKILL.md", ".gitkeep"):
                    continue
                try:
                    rel = str(f.relative_to(skill_dir)).replace("\\", "/")
                    extra_files.append(rel)
                except ValueError:
                    pass

        # Parse priority safely
        try:
            priority = int(meta.get("priority", 0))
        except (ValueError, TypeError):
            priority = 0

        self._skills[name] = Skill(
            name=name,
            title=meta.get("title", name),
            description=meta.get("description", ""),
            triggers=meta.get("triggers", []),
            category=meta.get("category", path.parent.parent.name if path.name == "SKILL.md" else path.parent.name),
            status=meta.get("status", "active"),
            body=post.content,
            path=str(path.relative_to(self._skills_dir)),
            files=extra_files,
            author=meta.get("author", ""),
            tools_granted=meta.get("tools_granted", []),
            depends_on=meta.get("depends_on", []),
            priority=priority,
            model_tier=meta.get("model_tier", ""),
            examples=meta.get("examples", []),
            output_format=meta.get("output_format", ""),
        )
