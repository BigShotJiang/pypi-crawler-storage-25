"""Browser automation integration via Playwright.

Provides headless Chromium for web research, content extraction,
and screenshot capture. Exposed as agent tools via the registry.
"""

from __future__ import annotations

import asyncio
import logging
from contextlib import suppress

log = logging.getLogger(__name__)

# Lazy-loaded browser instance
_browser = None
_playwright = None
_lock = asyncio.Lock()


async def _get_browser():
    """Get or create the shared browser instance."""
    global _browser, _playwright
    async with _lock:
        if _browser and _browser.is_connected():
            return _browser
        try:
            from playwright.async_api import async_playwright
            _playwright = await async_playwright().start()
            _browser = await _playwright.chromium.launch(headless=True)
            log.info("Browser launched (headless Chromium)")
            return _browser
        except Exception:
            log.exception("Failed to launch browser")
            return None


async def close_browser():
    """Shut down the browser instance."""
    global _browser, _playwright
    if _browser:
        with suppress(Exception):
            await _browser.close()
        _browser = None
    if _playwright:
        with suppress(Exception):
            await _playwright.stop()
        _playwright = None


def is_connected() -> bool:
    """Check if browser is available."""
    return _browser is not None and _browser.is_connected()


async def navigate_and_read(url: str, *, wait_for: str = "domcontentloaded", timeout: int = 15000) -> dict:
    """Navigate to a URL and extract the page content as text.

    Returns: {url, title, content, links[]}
    """
    browser = await _get_browser()
    if not browser:
        return {"error": "Browser not available. Playwright may not be installed."}

    page = await browser.new_page()
    try:
        response = await page.goto(url, wait_until=wait_for, timeout=timeout)
        if not response:
            return {"error": f"No response from {url}"}

        title = await page.title()

        # Extract main text content (strip nav, ads, etc.)
        content = await page.evaluate("""() => {
            // Remove noise elements
            for (const sel of ['nav', 'header', 'footer', 'aside', '.sidebar', '.nav', '.menu', '.ad', '.cookie', '[role="banner"]', '[role="navigation"]']) {
                document.querySelectorAll(sel).forEach(el => el.remove());
            }
            // Get main content or body
            const main = document.querySelector('main, article, [role="main"], .content, .post, .entry') || document.body;
            return main.innerText.substring(0, 8000);
        }""")

        # Extract links
        links = await page.evaluate("""() => {
            return Array.from(document.querySelectorAll('a[href]'))
                .map(a => ({ text: a.innerText.trim().substring(0, 80), href: a.href }))
                .filter(l => l.text && l.href.startsWith('http'))
                .slice(0, 20);
        }""")

        return {
            "url": page.url,
            "title": title,
            "content": content,
            "links": links,
            "status": response.status,
        }
    except Exception as e:
        return {"error": f"Navigation failed: {e!s}"}
    finally:
        await page.close()


async def screenshot(url: str, *, full_page: bool = False, timeout: int = 15000) -> dict:
    """Take a screenshot of a URL.

    Returns: {url, title, path} where path is a temp file.
    """
    import tempfile
    from pathlib import Path

    browser = await _get_browser()
    if not browser:
        return {"error": "Browser not available."}

    page = await browser.new_page(viewport={"width": 1280, "height": 720})
    try:
        await page.goto(url, wait_until="domcontentloaded", timeout=timeout)
        title = await page.title()

        path = Path(tempfile.mktemp(suffix=".png"))
        await page.screenshot(path=str(path), full_page=full_page)

        return {"url": page.url, "title": title, "path": str(path)}
    except Exception as e:
        return {"error": f"Screenshot failed: {e!s}"}
    finally:
        await page.close()


async def search_web(query: str) -> dict:
    """Search the web using DuckDuckGo (no API key needed).

    Returns: {query, results: [{title, url, snippet}]}
    """
    browser = await _get_browser()
    if not browser:
        return {"error": "Browser not available."}

    page = await browser.new_page()
    try:
        search_url = f"https://duckduckgo.com/?q={query.replace(' ', '+')}&t=h_&ia=web"
        await page.goto(search_url, wait_until="domcontentloaded", timeout=15000)

        # Wait for results to load
        await page.wait_for_selector("[data-result]", timeout=5000).catch_(lambda _: None)

        results = await page.evaluate("""() => {
            const items = document.querySelectorAll('[data-result], .result, .nrn-react-div');
            return Array.from(items).slice(0, 8).map(el => {
                const a = el.querySelector('a[href]');
                const snippet = el.querySelector('.snippet, [data-result] + div, .result__snippet');
                return {
                    title: a ? a.innerText.trim() : '',
                    url: a ? a.href : '',
                    snippet: snippet ? snippet.innerText.trim().substring(0, 200) : '',
                };
            }).filter(r => r.title && r.url && !r.url.includes('duckduckgo'));
        }""")

        return {"query": query, "results": results}
    except Exception as e:
        return {"error": f"Search failed: {e!s}"}
    finally:
        await page.close()
