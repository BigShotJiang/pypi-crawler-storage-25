"""Plugin base classes and context."""

from __future__ import annotations

import logging
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    import aiosqlite
    from fastapi import APIRouter

    from agntspace.agent.registry import ToolRegistry
    from agntspace.infra.config import Settings
    from agntspace.llm.base import LLMProvider
    from agntspace.skills.loader import SkillLoader
    from agntspace.vault.reader import VaultReader
    from agntspace.vault.writer import VaultWriter


@dataclass
class PluginContext:
    """Everything a plugin needs. Passed to init()."""

    registry: ToolRegistry
    vault: VaultReader
    vault_writer: VaultWriter
    llm: LLMProvider
    settings: Settings
    db: aiosqlite.Connection
    skill_loader: SkillLoader
    plugin_data_dir: Path
    log: logging.Logger


@dataclass
class PluginMeta:
    """Parsed from plugin.yaml."""

    name: str
    version: str
    title: str
    description: str
    author: str = ""
    license: str = "MIT"
    provides: dict = field(default_factory=lambda: {"tools": [], "skills": [], "integrations": [], "routes": []})
    contract_actions: list[str] = field(default_factory=list)
    enabled: bool = True
    path: Path = field(default_factory=Path)
    error: str = ""

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "version": self.version,
            "title": self.title,
            "description": self.description,
            "author": self.author,
            "license": self.license,
            "provides": self.provides,
            "contract_actions": self.contract_actions,
            "enabled": self.enabled,
            "path": str(self.path),
            "error": self.error,
        }


class PluginBase(ABC):
    """Interface every plugin.py must implement."""

    @abstractmethod
    def init(self, ctx: PluginContext) -> None:
        """Initialize the plugin. Register tools, integrations, routes, etc."""

    def get_router(self) -> APIRouter | None:
        """Optional: return a FastAPI APIRouter for custom endpoints."""
        return None

    def shutdown(self) -> None:
        """Optional cleanup on server shutdown."""
