"""Plugin manager — discovery, loading, lifecycle."""

from __future__ import annotations

import importlib.util
import json
import logging
from pathlib import Path
from typing import TYPE_CHECKING, Any

import yaml

from agntspace.plugins.base import PluginBase, PluginContext, PluginMeta

if TYPE_CHECKING:
    pass

log = logging.getLogger(__name__)


class PluginManager:
    """Discovers, loads, and manages plugins."""

    def __init__(self, app_dir: Path, vault_dir: Path) -> None:
        self._app_dir = app_dir
        self._vault_dir = vault_dir
        self._plugins: dict[str, PluginMeta] = {}
        self._instances: dict[str, PluginBase] = {}
        self._state_path = app_dir / "plugins.json"
        self._enabled_state = self._load_state()

    # ── state persistence ────────────────────────────────────────────

    def _load_state(self) -> dict[str, bool]:
        if self._state_path.exists():
            try:
                with open(self._state_path, encoding="utf-8") as f:
                    data = json.load(f)
                return data.get("enabled", {})
            except Exception:
                return {}
        return {}

    def _save_state(self) -> None:
        self._state_path.parent.mkdir(parents=True, exist_ok=True)
        with open(self._state_path, "w", encoding="utf-8") as f:
            json.dump({"enabled": self._enabled_state}, f, indent=2)

    # ── discovery ────────────────────────────────────────────────────

    def discover(self) -> dict[str, PluginMeta]:
        """Scan all plugin directories and parse manifests."""
        self._plugins.clear()

        # Scan directories in priority order (later overrides earlier)
        dirs = [
            Path(__file__).parent / "bundled",  # built-in plugins
            self._app_dir / "plugins",           # global user plugins
            self._vault_dir / "plugins",         # vault-local plugins
        ]

        for base_dir in dirs:
            if not base_dir.is_dir():
                continue
            for plugin_dir in sorted(base_dir.iterdir()):
                if not plugin_dir.is_dir():
                    continue
                manifest = plugin_dir / "plugin.yaml"
                if not manifest.exists():
                    manifest = plugin_dir / "plugin.yml"
                if not manifest.exists():
                    continue

                try:
                    meta = self._parse_manifest(manifest, plugin_dir)
                    # Apply saved enabled state (default: enabled)
                    if meta.name in self._enabled_state:
                        meta.enabled = self._enabled_state[meta.name]
                    self._plugins[meta.name] = meta
                except Exception as e:
                    log.warning("Failed to parse plugin manifest %s: %s", manifest, e)

        return self._plugins

    def _parse_manifest(self, path: Path, plugin_dir: Path) -> PluginMeta:
        with open(path, encoding="utf-8") as f:
            data = yaml.safe_load(f) or {}
        return PluginMeta(
            name=data.get("name", plugin_dir.name),
            version=data.get("version", "0.0.0"),
            title=data.get("title", data.get("name", plugin_dir.name)),
            description=data.get("description", ""),
            author=data.get("author", ""),
            license=data.get("license", "MIT"),
            provides=data.get("provides", {"tools": [], "skills": [], "integrations": [], "routes": []}),
            contract_actions=data.get("contract_actions", []),
            path=plugin_dir,
        )

    # ── loading ──────────────────────────────────────────────────────

    def load_all(self, ctx: PluginContext, app: Any = None) -> None:
        """Discover and load all enabled plugins."""
        self.discover()

        loaded = 0
        for name, meta in self._plugins.items():
            if not meta.enabled:
                continue
            try:
                self._load_plugin(name, meta, ctx, app)
                loaded += 1
            except Exception as e:
                meta.error = str(e)
                log.error("Plugin %s failed to load: %s", name, e)

        log.debug("Loaded %d plugin(s) of %d discovered", loaded, len(self._plugins))

    def _load_plugin(self, name: str, meta: PluginMeta, ctx: PluginContext, app: Any = None) -> None:
        plugin_py = meta.path / "plugin.py"
        if not plugin_py.exists():
            raise FileNotFoundError(f"plugin.py not found in {meta.path}")

        # Import the module
        spec = importlib.util.spec_from_file_location(f"agntspace_plugin_{name}", plugin_py)
        if not spec or not spec.loader:
            raise ImportError(f"Cannot load {plugin_py}")
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)

        # Find plugin instance
        instance: PluginBase | None = None
        if hasattr(module, "plugin") and isinstance(module.plugin, PluginBase):
            instance = module.plugin
        elif hasattr(module, "create_plugin") and callable(module.create_plugin):
            instance = module.create_plugin()

        if not instance:
            raise TypeError(f"No 'plugin' instance or 'create_plugin()' factory in {plugin_py}")

        # Create per-plugin logger and data dir
        plugin_log = logging.getLogger(f"agntspace.plugins.{name}")
        data_dir = ctx.plugin_data_dir / name / "data"
        data_dir.mkdir(parents=True, exist_ok=True)

        plugin_ctx = PluginContext(
            registry=ctx.registry,
            vault=ctx.vault,
            vault_writer=ctx.vault_writer,
            llm=ctx.llm,
            settings=ctx.settings,
            db=ctx.db,
            skill_loader=ctx.skill_loader,
            plugin_data_dir=data_dir,
            log=plugin_log,
        )

        # Initialize
        instance.init(plugin_ctx)
        self._instances[name] = instance
        meta.error = ""

        # Mount custom routes if any
        if app is not None:
            router = instance.get_router()
            if router:
                app.include_router(router, prefix=f"/api/plugins/{name}")

        log.debug("Plugin loaded: %s v%s", meta.title, meta.version)

    # ── enable / disable ─────────────────────────────────────────────

    def enable(self, name: str, ctx: PluginContext | None = None, app: Any = None) -> bool:
        meta = self._plugins.get(name)
        if not meta:
            return False
        meta.enabled = True
        self._enabled_state[name] = True
        self._save_state()

        if name not in self._instances and ctx:
            try:
                self._load_plugin(name, meta, ctx, app)
            except Exception as e:
                meta.error = str(e)
                log.error("Failed to enable plugin %s: %s", name, e)
                return False
        return True

    def disable(self, name: str) -> bool:
        meta = self._plugins.get(name)
        if not meta:
            return False
        meta.enabled = False
        self._enabled_state[name] = False
        self._save_state()

        instance = self._instances.pop(name, None)
        if instance:
            try:
                instance.shutdown()
            except Exception as e:
                log.warning("Plugin %s shutdown error: %s", name, e)
        return True

    # ── query ────────────────────────────────────────────────────────

    def list_plugins(self) -> list[dict]:
        return [meta.to_dict() for meta in self._plugins.values()]

    def get_plugin(self, name: str) -> dict | None:
        meta = self._plugins.get(name)
        return meta.to_dict() if meta else None

    # ── shutdown ─────────────────────────────────────────────────────

    def shutdown_all(self) -> None:
        for name, instance in self._instances.items():
            try:
                instance.shutdown()
            except Exception as e:
                log.warning("Plugin %s shutdown error: %s", name, e)
        self._instances.clear()
