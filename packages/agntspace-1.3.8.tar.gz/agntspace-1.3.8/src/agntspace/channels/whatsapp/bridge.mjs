/**
 * WhatsApp Bridge — connects to WhatsApp via Baileys.
 *
 * Supports two modes:
 * 1. Dedicated number: agent has its own WhatsApp number
 * 2. Personal number (self-chat): you message yourself, agent responds
 *
 * Config via env vars:
 *   WHATSAPP_MODE        = "dedicated" | "personal" (default: personal)
 *   WHATSAPP_ALLOWED     = comma-separated numbers (empty = allow all)
 *   WHATSAPP_BRIDGE_PORT = HTTP port (default: 8787)
 *   AGNTSPACE_BACKEND    = backend URL (default: http://127.0.0.1:8000)
 */

import makeWASocket, {
  DisconnectReason,
  useMultiFileAuthState,
  fetchLatestBaileysVersion,
  downloadContentFromMessage,
} from "@whiskeysockets/baileys";
import { createServer } from "http";
import { existsSync, mkdirSync } from "fs";
import { join } from "path";
import pino from "pino";
import { appendFileSync } from "fs";

function bridgeLog(msg) {
  const line = `[${new Date().toISOString()}] ${msg}\n`;
  console.log(msg);
  try { appendFileSync(join(AGNTSPACE_HOME, "whatsapp-bridge.log"), line); } catch {}
}

const AGNTSPACE_HOME =
  process.env.AGNTSPACE_HOME ||
  join(process.env.HOME || process.env.USERPROFILE, "agntspace");
const SESSION_DIR = join(AGNTSPACE_HOME, "data", "whatsapp-session");
const BACKEND_URL = process.env.AGNTSPACE_BACKEND || "http://127.0.0.1:8000";
const BRIDGE_PORT = parseInt(process.env.WHATSAPP_BRIDGE_PORT || "8787", 10);
let MODE = process.env.WHATSAPP_MODE || "personal";
const ALLOWED_NUMBERS = (process.env.WHATSAPP_ALLOWED || "")
  .split(",")
  .filter(Boolean);

const logger = pino({ level: "warn" });
let sock = null;
let currentQR = null;
let connected = false;
let selfJid = null;
let reconnectAttempts = 0;
const MAX_RECONNECT_DELAY = 60000; // 1 minute max
const sentByBridge = new Set(); // track message IDs we sent, to avoid loops

if (!existsSync(SESSION_DIR)) {
  mkdirSync(SESSION_DIR, { recursive: true });
}

async function startWhatsApp() {
  const { state, saveCreds } = await useMultiFileAuthState(SESSION_DIR);
  const { version } = await fetchLatestBaileysVersion();

  sock = makeWASocket({
    version,
    auth: state,
    logger,
    browser: ["AgntSpace", "Desktop", "1.0.0"],
  });

  sock.ev.on("connection.update", (update) => {
    const { connection, lastDisconnect, qr } = update;

    if (qr) {
      currentQR = qr;
      console.log("[WhatsApp] QR code ready — scan in Settings");
    }

    if (connection === "close") {
      connected = false;
      currentQR = null;
      const reason = lastDisconnect?.error?.output?.statusCode;
      if (reason !== DisconnectReason.loggedOut) {
        reconnectAttempts++;
        const delay = Math.min(3000 * Math.pow(2, reconnectAttempts - 1), MAX_RECONNECT_DELAY);
        console.log(`[WhatsApp] Reconnecting in ${delay}ms (attempt ${reconnectAttempts})...`);
        setTimeout(startWhatsApp, delay);
      } else {
        console.log("[WhatsApp] Logged out. Delete session to re-authenticate.");
      }
    }

    if (connection === "open") {
      connected = true;
      currentQR = null;
      reconnectAttempts = 0; // reset on successful connection
      selfJid = sock.user?.id;
      const selfNum = selfJid?.replace(/:\d+@/, "@").replace("@s.whatsapp.net", "");
      console.log(`[WhatsApp] Connected! (${MODE} mode, self: ${selfNum})`);
    }
  });

  sock.ev.on("creds.update", saveCreds);

  // Handle incoming messages
  sock.ev.on("messages.upsert", async ({ messages }) => {
    for (const msg of messages) {
      if (!msg.message) continue;

      // Skip messages sent by this bridge (prevents infinite loop)
      if (sentByBridge.has(msg.key.id)) {
        sentByBridge.delete(msg.key.id);
        continue;
      }

      const sender = msg.key.remoteJid;
      const fromMe = msg.key.fromMe;
      const isGroup = sender?.endsWith("@g.us");

      bridgeLog(`MSG: sender=${sender} fromMe=${fromMe} selfJid=${selfJid} id=${msg.key.id} type=${Object.keys(msg.message).join(",")}`);

      // Skip status broadcasts and group messages (for now)
      if (!sender || sender === "status@broadcast" || isGroup) continue;

      // Mode handling
      if (MODE === "personal") {
        // Personal mode: only process messages FROM ourselves (self-chat)
        if (!fromMe) {
          // Someone else messaged us — don't auto-respond on personal number
          // unless they're in the allowlist
          const senderNum = sender.replace("@s.whatsapp.net", "");
          if (ALLOWED_NUMBERS.length > 0 && !ALLOWED_NUMBERS.includes(senderNum)) {
            continue;
          }
          if (ALLOWED_NUMBERS.length === 0) {
            // No allowlist in personal mode = only self-chat
            continue;
          }
        }
      } else {
        // Dedicated mode: process incoming messages, skip our own outgoing
        // Exception: self-chat (messaging yourself) should still be processed
        // In dedicated mode, skip our own outgoing messages — but allow:
        // 1. Classic self-chat (sender matches our JID)
        // 2. LID self-chat (sender is @lid format with fromMe=true)
        if (fromMe) {
          const selfNormalized = selfJid ? selfJid.replace(/:(\d+)@/, "@") : null;
          const isSelfChat = (selfNormalized && sender === selfNormalized) || sender?.endsWith("@lid");
          if (!isSelfChat) {
            bridgeLog(`SKIP: outgoing to ${sender}`);
            continue;
          }
        }

        // Check allowlist
        if (ALLOWED_NUMBERS.length > 0) {
          const senderNum = sender.replace("@s.whatsapp.net", "");
          if (!ALLOWED_NUMBERS.includes(senderNum)) {
            console.log(`[WhatsApp] Blocked: ${senderNum} (not in allowlist)`);
            continue;
          }
        }
      }

      // Extract text from various message types
      const text =
        msg.message.conversation ||
        msg.message.extendedTextMessage?.text ||
        msg.message.imageMessage?.caption ||
        msg.message.videoMessage?.caption ||
        msg.message.documentMessage?.caption ||
        "";

      // Check for voice message / audio
      const audioMsg = msg.message.audioMessage;
      let audioBase64 = null;
      let audioDuration = 0;

      if (audioMsg) {
        try {
          bridgeLog(`Voice message (${audioMsg.seconds}s, ${audioMsg.mimetype})`);
          const stream = await downloadContentFromMessage(audioMsg, "audio");
          const chunks = [];
          for await (const chunk of stream) {
            chunks.push(chunk);
          }
          const buffer = Buffer.concat(chunks);
          audioBase64 = buffer.toString("base64");
          audioDuration = audioMsg.seconds || 0;
        } catch (err) {
          bridgeLog(`Failed to download voice message: ${err.message}`);
        }
      }

      // Check for image
      const imageMsg = msg.message.imageMessage;
      let imageBase64 = null;
      let imageMimetype = null;

      if (imageMsg) {
        try {
          bridgeLog(`Image message (${imageMsg.mimetype}, ${imageMsg.fileLength || "?"} bytes)`);
          const stream = await downloadContentFromMessage(imageMsg, "image");
          const chunks = [];
          for await (const chunk of stream) {
            chunks.push(chunk);
          }
          const buffer = Buffer.concat(chunks);
          imageBase64 = buffer.toString("base64");
          imageMimetype = imageMsg.mimetype || "image/jpeg";
        } catch (err) {
          bridgeLog(`Failed to download image: ${err.message}`);
        }
      }

      // Check for document — download content for text extraction
      const docMsg = msg.message.documentMessage;
      let docName = null;
      let docBase64 = null;
      let docMimetype = null;

      if (docMsg) {
        docName = docMsg.fileName || "document";
        docMimetype = docMsg.mimetype || "application/octet-stream";
        bridgeLog(`Document: ${docName} (${docMimetype}, ${docMsg.fileLength || "?"} bytes)`);

        // Download if under 10MB and is a text-extractable format
        const extractable = [
          "application/pdf",
          "text/plain", "text/csv", "text/html", "text/markdown",
          "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
          "application/msword",
          "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
          "application/vnd.ms-excel",
        ];
        const maxSize = 10 * 1024 * 1024; // 10MB
        const fileSize = docMsg.fileLength || 0;

        if (extractable.includes(docMimetype) && fileSize < maxSize) {
          try {
            const stream = await downloadContentFromMessage(docMsg, "document");
            const chunks = [];
            for await (const chunk of stream) {
              chunks.push(chunk);
            }
            const buffer = Buffer.concat(chunks);
            docBase64 = buffer.toString("base64");
            bridgeLog(`Document downloaded: ${docName} (${buffer.length} bytes)`);
          } catch (err) {
            bridgeLog(`Failed to download document: ${err.message}`);
          }
        } else {
          bridgeLog(`Document skipped (${fileSize > maxSize ? "too large" : "unsupported format"})`);
        }
      }

      // Check for video — download for frame extraction
      const videoMsg = msg.message.videoMessage;
      let videoBase64 = null;
      let videoMimetype = null;

      if (videoMsg) {
        videoMimetype = videoMsg.mimetype || "video/mp4";
        const maxVideoSize = 20 * 1024 * 1024; // 20MB
        const videoSize = videoMsg.fileLength || 0;
        bridgeLog(`Video message (${videoMimetype}, ${videoSize} bytes, ${videoMsg.seconds || "?"}s)`);

        if (videoSize < maxVideoSize) {
          try {
            const stream = await downloadContentFromMessage(videoMsg, "video");
            const chunks = [];
            for await (const chunk of stream) {
              chunks.push(chunk);
            }
            const buffer = Buffer.concat(chunks);
            videoBase64 = buffer.toString("base64");
            bridgeLog(`Video downloaded: ${buffer.length} bytes`);
          } catch (err) {
            bridgeLog(`Failed to download video: ${err.message}`);
          }
        }
      }

      // Check for sticker — download as image
      const stickerMsg = msg.message.stickerMessage;
      let stickerBase64 = null;

      if (stickerMsg && !text && !imageBase64 && !audioBase64) {
        try {
          const stream = await downloadContentFromMessage(stickerMsg, "sticker");
          const chunks = [];
          for await (const chunk of stream) {
            chunks.push(chunk);
          }
          const buffer = Buffer.concat(chunks);
          stickerBase64 = buffer.toString("base64");
          bridgeLog(`Sticker downloaded (${stickerMsg.mimetype}, ${buffer.length} bytes)`);
        } catch (err) {
          bridgeLog(`Failed to download sticker: ${err.message}`);
        }
      }

      // Skip if nothing to process
      if (!text && !audioBase64 && !imageBase64 && !docMsg && !videoMsg && !stickerMsg) continue;

      // For LID self-chat, use our own phone number; otherwise extract from JID
      let senderNum;
      if (sender?.endsWith("@lid") && fromMe && selfJid) {
        senderNum = selfJid.replace(/:(\d+)@.*/, "");
      } else {
        senderNum = sender.replace("@s.whatsapp.net", "");
      }
      const contentDesc = text ? `"${text.substring(0, 60)}"` : imageBase64 ? "[image]" : audioBase64 ? `[voice ${audioDuration}s]` : videoBase64 ? "[video]" : stickerBase64 ? "[sticker]" : docName ? `[doc: ${docName}]` : "[unknown]";
      bridgeLog(`FORWARDING: from=${fromMe ? "self" : senderNum} ${contentDesc}`);

      // Forward to AgntSpace backend
      try {
        const payload = {
          sender: senderNum,
          text: text || "",
          from_me: fromMe,
          timestamp: new Date().toISOString(),
          message_id: msg.key.id,
        };

        // Attach audio if present
        if (audioBase64) {
          payload.audio_base64 = audioBase64;
          payload.audio_duration = audioDuration;
          payload.audio_mimetype = audioMsg.mimetype || "audio/ogg";
        }

        // Attach image if present
        if (imageBase64) {
          payload.image_base64 = imageBase64;
          payload.image_mimetype = imageMimetype;
        }

        // Attach document content
        if (docMsg) {
          payload.document_name = docName;
          payload.document_mimetype = docMimetype;
          if (docBase64) {
            payload.document_base64 = docBase64;
          }
        }

        // Attach video
        if (videoBase64) {
          payload.video_base64 = videoBase64;
          payload.video_mimetype = videoMimetype;
          payload.video_duration = videoMsg.seconds || 0;
        }

        // Attach sticker as image
        if (stickerBase64) {
          payload.sticker_base64 = stickerBase64;
          payload.sticker_mimetype = stickerMsg.mimetype || "image/webp";
        }

        const res = await fetch(
          `${BACKEND_URL}/api/channels/whatsapp/incoming`,
          {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(payload),
          }
        );
        const data = await res.json();

        if (data.reply) {
          bridgeLog(`REPLY: to=${sender} text="${data.reply.substring(0, 80)}"`);
          const sent = await sock.sendMessage(sender, { text: data.reply });
          if (sent?.key?.id) sentByBridge.add(sent.key.id);
        } else if (data.error) {
          bridgeLog(`ERROR from backend: ${data.error}`);
        }
      } catch (err) {
        bridgeLog(`Backend error: ${err.message}`);
      }
    }
  });
}

// HTTP server
const server = createServer(async (req, res) => {
  const url = new URL(req.url, `http://localhost:${BRIDGE_PORT}`);
  res.setHeader("Content-Type", "application/json");
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type");

  if (req.method === "OPTIONS") {
    res.writeHead(200);
    res.end();
    return;
  }

  if (url.pathname === "/status") {
    res.writeHead(200);
    res.end(
      JSON.stringify({
        connected,
        qr_available: !!currentQR,
        mode: MODE,
        self: selfJid?.replace(/:\d+@/, "@").replace("@s.whatsapp.net", "") || null,
      })
    );
    return;
  }

  if (url.pathname === "/qr") {
    res.writeHead(200);
    if (currentQR) {
      res.end(JSON.stringify({ qr: currentQR }));
    } else if (connected) {
      res.end(JSON.stringify({ qr: null, status: "connected" }));
    } else {
      res.end(JSON.stringify({ qr: null, status: "waiting" }));
    }
    return;
  }

  if (url.pathname === "/mode" && req.method === "POST") {
    let body = "";
    for await (const chunk of req) body += chunk;
    try {
      const { mode } = JSON.parse(body);
      if (mode === "personal" || mode === "dedicated") {
        MODE = mode;
        console.log(`[WhatsApp] Mode switched to: ${MODE}`);
        res.writeHead(200);
        res.end(JSON.stringify({ mode: MODE }));
      } else {
        res.writeHead(400);
        res.end(JSON.stringify({ error: "Invalid mode. Use 'personal' or 'dedicated'" }));
      }
    } catch (err) {
      res.writeHead(400);
      res.end(JSON.stringify({ error: err.message }));
    }
    return;
  }

  if (url.pathname === "/send" && req.method === "POST") {
    let body = "";
    for await (const chunk of req) body += chunk;
    try {
      const { to, text } = JSON.parse(body);
      if (!sock || !connected) {
        res.writeHead(503);
        res.end(JSON.stringify({ error: "Not connected" }));
        return;
      }
      const jid = to.includes("@") ? to : `${to}@s.whatsapp.net`;
      const sent = await sock.sendMessage(jid, { text });
      if (sent?.key?.id) sentByBridge.add(sent.key.id);
      res.writeHead(200);
      res.end(JSON.stringify({ sent: true }));
    } catch (err) {
      res.writeHead(500);
      res.end(JSON.stringify({ error: err.message }));
    }
    return;
  }

  res.writeHead(404);
  res.end(JSON.stringify({ error: "Not found" }));
});

server.listen(BRIDGE_PORT, "127.0.0.1", () => {
  console.log(`[WhatsApp] Bridge on http://127.0.0.1:${BRIDGE_PORT} (${MODE} mode)`);
  startWhatsApp();
});

// Graceful shutdown — close socket without logging out (preserves session)
async function shutdown(signal) {
  console.log(`[WhatsApp] ${signal} received, shutting down gracefully...`);
  try {
    if (sock) {
      sock.end(undefined); // close connection without logout
      sock = null;
    }
  } catch (e) {
    console.log("[WhatsApp] Cleanup error (non-fatal):", e.message);
  }
  server.close();
  process.exit(0);
}
process.on("SIGTERM", () => shutdown("SIGTERM"));
process.on("SIGINT", () => shutdown("SIGINT"));
