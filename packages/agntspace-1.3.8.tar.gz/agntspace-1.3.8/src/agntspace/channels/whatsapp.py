"""WhatsApp channel via Baileys Node.js bridge.

The bridge runs as a sidecar process. This module communicates with it
via HTTP on localhost:8787.
"""

from __future__ import annotations

import asyncio
import contextlib
import logging
import os
import signal
import subprocess
from collections.abc import Callable
from pathlib import Path

import httpx

from agntspace.channels.base import Channel, ChannelMessage

log = logging.getLogger(__name__)

BRIDGE_DIR = Path(__file__).parent / "whatsapp"
DEFAULT_BRIDGE_PORT = 8787


class WhatsAppChannel(Channel):
    """WhatsApp channel using Baileys via Node.js bridge."""

    name = "whatsapp"

    def __init__(self, bridge_port: int = DEFAULT_BRIDGE_PORT, mode: str = "personal") -> None:
        self._port = bridge_port
        self._mode = mode
        self._base_url = f"http://127.0.0.1:{bridge_port}"
        self._connected = False
        self._bridge_process: subprocess.Popen | None = None  # type: ignore[type-arg]
        self._message_callback: Callable | None = None
        self._health_task: asyncio.Task | None = None  # type: ignore[type-arg]

    async def connect(self) -> None:
        """Start the Baileys bridge process and health check loop."""
        # Cancel any existing health task before reconnecting
        if self._health_task and not self._health_task.done():
            self._health_task.cancel()
            self._health_task = None

        # Kill any existing bridge on this port first
        self._kill_existing_bridge()

        # Install npm deps if needed
        node_modules = BRIDGE_DIR / "node_modules"
        if not node_modules.is_dir():
            log.info("Installing WhatsApp bridge dependencies...")
            subprocess.run(
                ["npm", "install"],
                cwd=str(BRIDGE_DIR),
                capture_output=True,
                timeout=120,
            )

        # Start bridge — pass AGNTSPACE_HOME so session path is consistent
        from agntspace.infra.config import get_settings
        app_dir = str(get_settings().app_dir)
        env = {
            **dict(os.environ),
            "WHATSAPP_BRIDGE_PORT": str(self._port),
            "WHATSAPP_MODE": self._mode,
            "AGNTSPACE_HOME": app_dir,
        }
        self._bridge_process = subprocess.Popen(
            ["node", "bridge.mjs"],
            cwd=str(BRIDGE_DIR),
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            env=env,
        )
        log.debug("WhatsApp bridge started (PID: %d, mode: %s)", self._bridge_process.pid, self._mode)

        # Wait for bridge to be ready
        for _ in range(15):
            await asyncio.sleep(2)
            try:
                async with httpx.AsyncClient() as client:
                    resp = await client.get(f"{self._base_url}/status", timeout=3)
                    data = resp.json()
                    if data.get("connected") or data.get("qr_available"):
                        self._connected = True
                        log.debug("WhatsApp bridge ready")
                        # Start health check loop
                        self._health_task = asyncio.create_task(self._health_loop())
                        return
            except Exception:
                # Check if process died
                if self._bridge_process.poll() is not None:
                    stdout = self._bridge_process.stdout
                    output = stdout.read().decode() if stdout else ""
                    log.error("WhatsApp bridge died: %s", output[:500])
                    msg = f"WhatsApp bridge failed to start: {output[:200]}"
                    raise ConnectionError(msg) from None
                continue

        log.warning("WhatsApp bridge did not become ready in 30s")

    async def disconnect(self) -> None:
        """Stop the bridge process and health check."""
        if self._health_task:
            self._health_task.cancel()
            self._health_task = None
        if self._bridge_process:
            with contextlib.suppress(Exception):
                self._bridge_process.terminate()
                self._bridge_process.wait(timeout=5)
            self._bridge_process = None
        self._connected = False
        log.debug("WhatsApp bridge stopped")

    async def send_message(self, chat_id: str, text: str) -> None:
        async with httpx.AsyncClient() as client:
            await client.post(
                f"{self._base_url}/send",
                json={"to": chat_id, "text": text},
                timeout=10,
            )

    async def send_notification(self, chat_id: str, text: str) -> None:
        await self.send_message(chat_id, f"*Notification:* {text}")

    @property
    def is_connected(self) -> bool:
        return self._connected

    async def get_qr_code(self) -> str | None:
        try:
            async with httpx.AsyncClient() as client:
                resp = await client.get(f"{self._base_url}/qr", timeout=5)
                return resp.json().get("qr")
        except Exception:
            return None

    async def get_status(self) -> dict:
        try:
            async with httpx.AsyncClient() as client:
                resp = await client.get(f"{self._base_url}/status", timeout=5)
                return resp.json()
        except Exception:
            return {"connected": False, "qr_available": False, "bridge": "not running"}

    async def set_mode(self, mode: str) -> str:
        """Switch bridge mode at runtime. Returns the new mode."""
        async with httpx.AsyncClient() as client:
            resp = await client.post(
                f"{self._base_url}/mode",
                json={"mode": mode},
                timeout=5,
            )
            data = resp.json()
            if resp.status_code == 200:
                self._mode = data["mode"]
                log.info("WhatsApp mode switched to: %s", self._mode)
            return data.get("mode", self._mode)

    async def handle_incoming(self, payload: dict) -> str | None:
        sender = payload.get("sender", "")
        text = payload.get("text", "")
        audio_base64 = payload.get("audio_base64")
        audio_mimetype = payload.get("audio_mimetype", "audio/ogg")
        image_base64 = payload.get("image_base64")
        image_mimetype = payload.get("image_mimetype", "image/jpeg")
        document_name = payload.get("document_name")
        document_base64 = payload.get("document_base64")
        document_mimetype = payload.get("document_mimetype")
        video_base64 = payload.get("video_base64")
        video_mimetype = payload.get("video_mimetype", "video/mp4")
        sticker_base64 = payload.get("sticker_base64")
        sticker_mimetype = payload.get("sticker_mimetype", "image/webp")

        if not sender:
            return None

        # Transcribe voice message if present
        if audio_base64 and not text:
            try:
                from agntspace.infra.config import get_settings
                from agntspace.llm.transcribe import transcribe_audio

                settings = get_settings()
                api_key = settings.openai_api_key or None
                text = await transcribe_audio(audio_base64, audio_mimetype, api_key=api_key)
                log.info("Voice message transcribed from %s: %s...", sender, text[:60])
            except Exception:
                log.exception("Voice transcription failed")
                text = "[Voice message could not be transcribed]"

        # Describe image via vision LLM
        if image_base64 and not text:
            try:
                from agntspace.infra.config import get_settings
                from agntspace.llm.base import ImageContent

                settings = get_settings()
                model = f"{settings.llm.cloud_provider}/{settings.llm.cloud_model}"

                from agntspace.llm.provider import UniversalProvider

                llm = UniversalProvider(model=model, api_key=settings.anthropic_api_key or settings.openai_api_key)
                img = ImageContent(base64_data=image_base64, media_type=image_mimetype)
                resp = await llm.complete_vision(
                    prompt="Describe this image concisely. What is it showing?",
                    images=[img],
                    max_tokens=300,
                )
                text = f"[Image received] {resp.content}"
                log.info("Image described from %s: %s...", sender, text[:80])
            except Exception:
                log.exception("Image vision analysis failed")
                text = "[Image received but could not be analyzed]"
        elif image_base64 and text:
            # Image with caption — analyze both together
            try:
                from agntspace.infra.config import get_settings
                from agntspace.llm.base import ImageContent

                settings = get_settings()
                model = f"{settings.llm.cloud_provider}/{settings.llm.cloud_model}"

                from agntspace.llm.provider import UniversalProvider

                llm = UniversalProvider(model=model, api_key=settings.anthropic_api_key or settings.openai_api_key)
                img = ImageContent(base64_data=image_base64, media_type=image_mimetype)
                resp = await llm.complete_vision(
                    prompt=f'The sender attached this image with caption: "{text}". Describe what the image shows and respond to the caption.',
                    images=[img],
                    max_tokens=300,
                )
                text = f"[Image with caption] {resp.content}"
                log.info("Image+caption analyzed from %s: %s...", sender, text[:80])
            except Exception:
                log.exception("Image+caption analysis failed")
                text = f"[Image received] {text}"

        # Handle document — extract text content if available
        if document_base64 and document_name:
            try:
                extracted = await self._extract_document_text(document_base64, document_mimetype, document_name)
                if extracted:
                    prefix = f"[Document: {document_name}]\n\n"
                    if text:
                        text = f"{prefix}Caption: {text}\n\nContent:\n{extracted}"
                    else:
                        text = f"{prefix}{extracted}"
                    log.info("Document extracted from %s: %s (%d chars)", sender, document_name, len(extracted))
                else:
                    text = text or f"[Document received: {document_name}] Could not extract text content."
            except Exception:
                log.exception("Document extraction failed for %s", document_name)
                text = text or f"[Document received: {document_name}] Extraction failed."
        elif document_name and not text:
            text = f"[Document received: {document_name}] No content available."

        # Handle video — describe first frame via vision LLM
        if video_base64 and not image_base64:
            try:
                desc = await self._describe_video(video_base64, video_mimetype, text)
                caption = text or ""
                dur = payload.get("video_duration", 0)
                text = f"[Video received ({dur}s)] {desc}"
                if caption:
                    text = f"[Video with caption: \"{caption}\"] {desc}"
                log.info("Video described from %s: %s...", sender, text[:80])
            except Exception:
                log.exception("Video description failed")
                text = text or "[Video received but could not be analyzed]"

        # Handle sticker — describe via vision LLM (treat as image)
        if sticker_base64 and not text and not image_base64:
            try:
                from agntspace.infra.config import get_settings
                from agntspace.llm.base import ImageContent

                settings = get_settings()
                model = f"{settings.llm.cloud_provider}/{settings.llm.cloud_model}"

                from agntspace.llm.provider import UniversalProvider

                llm = UniversalProvider(model=model, api_key=settings.anthropic_api_key or settings.openai_api_key)
                # Convert webp sticker to image content
                img = ImageContent(base64_data=sticker_base64, media_type=sticker_mimetype)
                resp = await llm.complete_vision(
                    prompt="This is a sticker/emoji image. Briefly describe what it shows and what emotion or reaction it expresses.",
                    images=[img],
                    max_tokens=150,
                )
                text = f"[Sticker] {resp.content}"
                log.info("Sticker described from %s: %s...", sender, text[:60])
            except Exception:
                log.exception("Sticker description failed")
                text = "[Sticker received]"

        if not text:
            return None

        msg = ChannelMessage(
            channel="whatsapp",
            sender=sender,
            text=text,
            metadata={
                "chat_id": sender,
                "is_voice": bool(audio_base64),
                "is_image": bool(image_base64),
                "is_document": bool(document_base64),
                "is_video": bool(video_base64),
                "is_sticker": bool(sticker_base64),
                "document_name": document_name,
                "from_me": payload.get("from_me", False),
            },
        )
        if self._message_callback:
            return await self._message_callback(msg)
        return None

    async def _health_loop(self) -> None:
        """Periodically check bridge health, auto-restart if dead."""
        consecutive_failures = 0
        while True:
            await asyncio.sleep(30)
            try:
                async with httpx.AsyncClient() as client:
                    resp = await client.get(f"{self._base_url}/status", timeout=5)
                    data = resp.json()
                    if data.get("connected"):
                        if not self._connected:
                            log.info("WhatsApp connection restored")
                            self._connected = True
                        consecutive_failures = 0
                        continue
                    # Bridge running but WhatsApp disconnected — Baileys will reconnect
                    log.debug("WhatsApp: bridge running but not connected, waiting for Baileys reconnect")
                    consecutive_failures = 0
            except asyncio.CancelledError:
                return
            except Exception:
                consecutive_failures += 1
                log.warning("WhatsApp health check failed (%d consecutive)", consecutive_failures)

                if consecutive_failures >= 3:
                    log.warning("WhatsApp bridge appears dead, auto-restarting...")
                    self._connected = False
                    try:
                        # Restart bridge directly without spawning a new health loop
                        self._kill_existing_bridge()
                        from agntspace.infra.config import get_settings
                        app_dir = str(get_settings().app_dir)
                        env = {
                            **dict(os.environ),
                            "WHATSAPP_BRIDGE_PORT": str(self._port),
                            "WHATSAPP_MODE": self._mode,
                            "AGNTSPACE_HOME": app_dir,
                        }
                        self._bridge_process = subprocess.Popen(
                            ["node", "bridge.mjs"],
                            cwd=str(BRIDGE_DIR),
                            stdout=subprocess.PIPE,
                            stderr=subprocess.STDOUT,
                            env=env,
                        )
                        log.info("WhatsApp bridge restarted (PID: %d)", self._bridge_process.pid)
                        consecutive_failures = 0
                        # Give bridge time to start before next health check
                        await asyncio.sleep(15)
                    except Exception:
                        log.exception("WhatsApp auto-restart failed")
                        await asyncio.sleep(30)

    def _kill_existing_bridge(self) -> None:
        """Kill any existing process on the bridge port."""
        # Terminate our own tracked process
        if self._bridge_process:
            with contextlib.suppress(Exception):
                self._bridge_process.terminate()
                self._bridge_process.wait(timeout=3)
            self._bridge_process = None

        # Also try to find and kill anything on the port (Windows)
        try:
            result = subprocess.run(
                ["netstat", "-ano"],
                capture_output=True, text=True, timeout=5,
            )
            for line in result.stdout.split("\n"):
                if f"127.0.0.1:{self._port}" in line and "LISTENING" in line:
                    parts = line.split()
                    pid = int(parts[-1])
                    log.debug("Killing existing process on port %d (PID: %d)", self._port, pid)
                    with contextlib.suppress(Exception):
                        os.kill(pid, signal.SIGTERM)
        except Exception:
            pass

    async def _extract_document_text(
        self, base64_data: str, mimetype: str | None, filename: str,
    ) -> str | None:
        """Extract text from a document (PDF, txt, docx, csv, html)."""
        import base64
        from pathlib import Path

        raw = base64.b64decode(base64_data)
        suffix = Path(filename).suffix.lower()

        # Plain text formats
        if suffix in (".txt", ".md", ".csv", ".html", ".htm", ".json", ".xml", ".yaml", ".yml"):
            text = raw.decode("utf-8", errors="replace")
            return text[:8000]  # Truncate for LLM context

        # PDF
        if suffix == ".pdf" or (mimetype and "pdf" in mimetype):
            try:
                import io
                # Try PyPDF2 or pdfplumber
                try:
                    import pdfplumber
                    with pdfplumber.open(io.BytesIO(raw)) as pdf:
                        pages = [p.extract_text() or "" for p in pdf.pages[:20]]
                    return "\n\n".join(pages)[:8000]
                except ImportError:
                    pass
                try:
                    from PyPDF2 import PdfReader
                    reader = PdfReader(io.BytesIO(raw))
                    pages = [p.extract_text() or "" for p in reader.pages[:20]]
                    return "\n\n".join(pages)[:8000]
                except ImportError:
                    log.warning("No PDF library available (install pdfplumber or PyPDF2)")
                    return f"[PDF document: {filename}, {len(raw)} bytes — install pdfplumber for text extraction]"
            except Exception:
                log.exception("PDF extraction failed")
                return None

        # DOCX
        if suffix == ".docx" or (mimetype and "wordprocessingml" in (mimetype or "")):
            try:
                import io
                import xml.etree.ElementTree as ET
                import zipfile

                with zipfile.ZipFile(io.BytesIO(raw)) as zf:
                    doc_xml = zf.read("word/document.xml")
                root = ET.fromstring(doc_xml)
                ns = {"w": "http://schemas.openxmlformats.org/wordprocessingml/2006/main"}
                paragraphs = [
                    "".join(node.text or "" for node in p.iter(f"{{{ns['w']}}}t"))
                    for p in root.iter(f"{{{ns['w']}}}p")
                ]
                return "\n".join(p for p in paragraphs if p)[:8000]
            except Exception:
                log.exception("DOCX extraction failed")
                return None

        # Unsupported format
        log.info("Unsupported document format: %s (%s)", filename, mimetype)
        return None

    async def _describe_video(
        self, base64_data: str, mimetype: str, caption: str | None = None,
    ) -> str:
        """Describe a video by analyzing its content via LLM.

        For short videos, we describe based on metadata and any caption.
        For a richer experience, ffmpeg could extract a frame, but we keep it simple.
        """
        from agntspace.infra.config import get_settings

        settings = get_settings()

        # Try to extract a frame using ffmpeg if available
        try:
            import base64 as b64
            import subprocess
            import tempfile
            from pathlib import Path

            raw = b64.b64decode(base64_data)
            with tempfile.NamedTemporaryFile(suffix=".mp4", delete=False) as f:
                f.write(raw)
                video_path = f.name

            frame_path = video_path + ".jpg"
            result = subprocess.run(
                ["ffmpeg", "-i", video_path, "-ss", "00:00:01", "-frames:v", "1", "-y", frame_path],
                capture_output=True, timeout=10,
            )

            if result.returncode == 0 and Path(frame_path).exists():
                frame_data = Path(frame_path).read_bytes()
                frame_b64 = b64.b64encode(frame_data).decode()

                from agntspace.llm.base import ImageContent
                from agntspace.llm.provider import UniversalProvider

                model = f"{settings.llm.cloud_provider}/{settings.llm.cloud_model}"
                llm = UniversalProvider(model=model, api_key=settings.anthropic_api_key or settings.openai_api_key)
                img = ImageContent(base64_data=frame_b64, media_type="image/jpeg")

                prompt = "This is a frame from a video. Describe what it shows."
                if caption:
                    prompt = f'This is a frame from a video with caption: "{caption}". Describe what the video shows.'

                resp = await llm.complete_vision(prompt=prompt, images=[img], max_tokens=200)

                # Cleanup
                Path(video_path).unlink(missing_ok=True)
                Path(frame_path).unlink(missing_ok=True)
                return resp.content

            Path(video_path).unlink(missing_ok=True)
            Path(frame_path).unlink(missing_ok=True)
        except FileNotFoundError:
            pass  # ffmpeg not installed
        except Exception:
            log.debug("Video frame extraction failed", exc_info=True)

        # Fallback: describe based on metadata
        import base64 as b64
        size_kb = len(b64.b64decode(base64_data)) // 1024
        return f"A video was sent ({size_kb}KB, {mimetype}). No frame extraction available — install ffmpeg for video analysis."
