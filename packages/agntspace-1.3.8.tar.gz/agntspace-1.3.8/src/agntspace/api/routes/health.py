"""Health check endpoint."""

from __future__ import annotations

import re
from pathlib import Path

from fastapi import APIRouter

router = APIRouter(tags=["health"])

_PYPROJECT = Path(__file__).resolve().parents[4] / "pyproject.toml"

def _get_version() -> str:
    try:
        text = _PYPROJECT.read_text(encoding="utf-8")
        m = re.search(r'^version\s*=\s*"([^"]+)"', text, re.MULTILINE)
        if m:
            return m.group(1)
    except Exception:
        pass
    return "dev"


@router.get("/health")
async def health() -> dict:
    return {"status": "ok", "version": _get_version()}
