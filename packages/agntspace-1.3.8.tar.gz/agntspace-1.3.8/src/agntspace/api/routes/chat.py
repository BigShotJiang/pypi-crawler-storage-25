"""Chat REST endpoints."""

from __future__ import annotations

import logging

from fastapi import APIRouter, Request
from pydantic import BaseModel

log = logging.getLogger(__name__)

router = APIRouter(tags=["chat"])


class ChatRequest(BaseModel):
    message: str
    conversation_id: str | None = None


class ChatResponse(BaseModel):
    conversation_id: str
    message: str


class MessageOut(BaseModel):
    role: str
    content: str


@router.post("/chat", response_model=ChatResponse)
async def chat(request: Request, body: ChatRequest) -> ChatResponse:
    """Send a message and get a non-streaming response."""
    agent = request.app.state.agent
    memory = request.app.state.memory

    conv_id = body.conversation_id
    if not conv_id or not await memory.conversation_exists(conv_id):
        conv_id = await memory.create_conversation()

    try:
        response = await agent.chat(conv_id, body.message)
    except Exception as exc:
        from agntspace.llm.base import LLMError

        if isinstance(exc, LLMError):
            log.error("LLM error in chat: %s", exc.user_message)
            response = f"⚠ {exc.user_message}"
        else:
            log.exception("Chat error")
            response = f"⚠ Error: {exc!s}"
    return ChatResponse(conversation_id=conv_id, message=response)


@router.get("/conversations")
async def list_conversations(request: Request, include_archived: bool = False) -> list[dict]:
    """List recent conversations. Pass include_archived=true to see archived chats."""
    memory = request.app.state.memory
    return await memory.list_conversations(include_archived=include_archived)


@router.get("/conversations/{conversation_id}/messages")
async def get_messages(
    request: Request, conversation_id: str
) -> list[MessageOut]:
    """Get messages for a conversation."""
    memory = request.app.state.memory
    messages = await memory.get_messages(conversation_id, limit=100)
    return [MessageOut(role=m.role, content=m.content) for m in messages]


@router.patch("/conversations/{conversation_id}/archive")
async def archive_conversation(request: Request, conversation_id: str) -> dict:
    """Archive a conversation (hides from default list)."""
    memory = request.app.state.memory
    await memory.archive_conversation(conversation_id)
    return {"archived": True}


@router.patch("/conversations/{conversation_id}/unarchive")
async def unarchive_conversation(request: Request, conversation_id: str) -> dict:
    """Restore an archived conversation."""
    memory = request.app.state.memory
    await memory.unarchive_conversation(conversation_id)
    return {"archived": False}


@router.delete("/conversations/{conversation_id}")
async def delete_conversation(request: Request, conversation_id: str) -> dict:
    """Permanently delete a conversation and all its messages."""
    memory = request.app.state.memory
    await memory.delete_conversation(conversation_id)
    return {"deleted": True}
