"""Notes API — user-authored freeform notes in vault/notes/."""

from __future__ import annotations

import re
from datetime import UTC, datetime

from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel

router = APIRouter(prefix="/notes", tags=["notes"])


class NoteCreateRequest(BaseModel):
    title: str
    text: str
    folder: str = ""  # optional subfolder under notes/


class NoteResponse(BaseModel):
    path: str
    title: str
    content: str
    metadata: dict


@router.get("")
async def list_notes(request: Request, folder: str = "") -> list[dict]:
    """List notes, optionally filtered by subfolder."""
    vault = request.app.state.vault
    search_dir = f"notes/{folder}" if folder else "notes"
    files = vault.list_files(search_dir, "**/*.md")
    notes = []
    for f in files:
        try:
            relative = f"notes/{f.relative_to(vault.vault_dir / 'notes')}" if hasattr(f, "relative_to") else f"notes/{f.name}"
            doc = vault.read(relative)
            notes.append({
                "path": relative,
                "title": doc.metadata.get("title", f.stem),
                "author": doc.metadata.get("author", "user"),
            })
        except Exception:
            continue
    return notes


@router.post("")
async def create_note(request: Request, body: NoteCreateRequest) -> NoteResponse:
    """Create a new user note."""
    writer = request.app.state.vault_writer
    vault = request.app.state.vault

    # Generate slug from title
    slug = re.sub(r"[^a-z0-9]+", "-", body.title.lower()).strip("-")
    date = datetime.now(UTC).strftime("%Y-%m-%d")
    folder = f"notes/{body.folder}" if body.folder else "notes"
    path = f"{folder}/{slug}_{date}.md"

    content = (
        f"---\ntitle: \"{body.title}\"\n"
        f"author: user\ncreated: \"{date}\"\n---\n\n{body.text}"
    )
    writer.write(path, content)

    doc = vault.read(path)
    return NoteResponse(
        path=path,
        title=body.title,
        content=doc.content,
        metadata=doc.metadata,
    )


@router.get("/{note_path:path}")
async def get_note(request: Request, note_path: str) -> NoteResponse:
    """Read a specific note."""
    vault = request.app.state.vault
    path = f"notes/{note_path}" if not note_path.startswith("notes/") else note_path
    try:
        doc = vault.read(path)
    except FileNotFoundError as exc:
        raise HTTPException(status_code=404, detail=f"Note not found: {path}") from exc
    return NoteResponse(
        path=path,
        title=doc.metadata.get("title", ""),
        content=doc.content,
        metadata=doc.metadata,
    )
