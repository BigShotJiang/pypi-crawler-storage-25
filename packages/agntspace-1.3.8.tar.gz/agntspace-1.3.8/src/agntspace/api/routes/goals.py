"""Goals and coaching API endpoints."""

from __future__ import annotations

from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel

router = APIRouter(prefix="/goals", tags=["goals"])


class GoalCreateRequest(BaseModel):
    title: str
    description: str
    goal_type: str = "goal"
    target_date: str = ""


class GoalStatusRequest(BaseModel):
    status: str


@router.get("")
async def list_goals(request: Request, status: str | None = None) -> list[dict]:
    """List all goals."""
    coach = request.app.state.coach
    return coach.list_goals(status_filter=status)


@router.post("")
async def create_goal(request: Request, body: GoalCreateRequest) -> dict:
    """Create a new goal."""
    coach = request.app.state.coach
    path = coach.create_goal(
        title=body.title,
        description=body.description,
        goal_type=body.goal_type,
        target_date=body.target_date,
    )
    return {"path": path, "status": "active"}


@router.get("/nudges")
async def get_nudges(request: Request) -> list[str]:
    """Get coaching nudges for stalled goals and deadlines."""
    coach = request.app.state.coach
    return coach.generate_nudges()


@router.get("/stalls")
async def get_stalls(request: Request) -> list[dict]:
    """Detect stalled goals."""
    coach = request.app.state.coach
    return coach.detect_stalls()


@router.get("/{slug}")
async def get_goal(request: Request, slug: str) -> dict:
    """Get a single goal."""
    coach = request.app.state.coach
    goal = coach.get_goal(slug)
    if not goal:
        raise HTTPException(status_code=404, detail=f"Goal not found: {slug}")
    return goal


@router.patch("/{slug}/status")
async def update_goal_status(
    request: Request, slug: str, body: GoalStatusRequest
) -> dict:
    """Update a goal's status."""
    coach = request.app.state.coach
    try:
        coach.update_goal_status(slug, body.status)
    except FileNotFoundError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    return {"slug": slug, "status": body.status}
