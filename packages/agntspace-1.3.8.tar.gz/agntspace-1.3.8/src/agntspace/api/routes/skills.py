"""Skills and SkillSchool API endpoints."""

from __future__ import annotations

from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel

router = APIRouter(prefix="/skills", tags=["skills"])


class SkillUpdateRequest(BaseModel):
    content: str


class SkillCreateRequest(BaseModel):
    name: str
    title: str
    description: str
    category: str = "custom"
    triggers: list[str] = []
    instructions: str = ""
    author: str = "user"
    tools_granted: list[str] = []
    depends_on: list[str] = []
    priority: int = 0
    model_tier: str = ""
    examples: list[dict] = []
    output_format: str = ""


class SkillFileRequest(BaseModel):
    content: str


@router.get("")
async def list_skills(request: Request) -> list[dict]:
    """List all loaded skills."""
    skills = request.app.state.skills
    return skills.list_skills()


@router.get("/proposals")
async def list_proposals(request: Request) -> list[dict]:
    """List pending skill proposals from SkillSchool."""
    skillschool = request.app.state.skillschool
    return skillschool.list_proposals()


@router.post("/analyze")
async def analyze_patterns(request: Request) -> list[dict]:
    """Run SkillSchool pattern analysis on completed tasks."""
    skillschool = request.app.state.skillschool
    return await skillschool.analyze_patterns()


@router.post("/proposals/{slug}/approve")
async def approve_proposal(request: Request, slug: str) -> dict:
    """Approve a skill proposal. Handles both skill creation and skill assignment proposals."""
    skillschool = request.app.state.skillschool
    vault = request.app.state.vault
    vault_dir = getattr(vault, "_vault_dir", None)

    # Check if this is a healer assign_skill proposal
    if slug.startswith("heal-") and vault_dir:
        from pathlib import Path
        review_path = Path(vault_dir) / "skills-review" / f"{slug}.md"
        if review_path.exists():
            import frontmatter
            doc = frontmatter.load(str(review_path))
            ptype = doc.metadata.get("type", "")
            agent_key = doc.metadata.get("agent_key", "")
            skill_name = doc.metadata.get("skill", "")

            if ptype == "assign_skill" and agent_key and skill_name:
                # Add skill to the agent definition
                orchestrator = request.app.state.orchestrator
                agent_def = orchestrator.agents.get(agent_key)
                if agent_def and skill_name not in (agent_def.skills or []):
                    agent_def.skills.append(skill_name)
                    # Read and update agent file
                    agent_path = Path(vault_dir) / "agnt-system" / "agents" / f"{agent_key}.md"
                    if agent_path.exists():
                        content = agent_path.read_text(encoding="utf-8")
                        if f"  - {skill_name}" not in content:
                            content = content.replace(
                                f"access: {agent_def.access}",
                                f"  - {skill_name}\naccess: {agent_def.access}",
                            )
                            request.app.state.vault_writer.write(f"agnt-system/agents/{agent_key}.md", content)
                    orchestrator.load_agents()

                # Mark as approved
                review_path.write_text(
                    review_path.read_text(encoding="utf-8").replace("status: pending_review", "status: approved"),
                    encoding="utf-8",
                )

                # Sync: update heal-proposals.json
                from agntspace.api.routes.simulate import _get_logs_dir
                logs_dir = _get_logs_dir(request)
                if logs_dir:
                    hp_path = logs_dir / "heal-proposals.json"
                    if hp_path.exists():
                        import json as _json
                        try:
                            hp = _json.loads(hp_path.read_text(encoding="utf-8"))
                            for hp_item in hp:
                                if hp_item.get("agent_key") == agent_key and hp_item.get("skill") == skill_name and hp_item.get("status") == "pending":
                                    hp_item["status"] = "approved"
                            hp_path.write_text(_json.dumps(hp, indent=2), encoding="utf-8")
                        except Exception:
                            pass

                return {"status": "approved", "path": f"agnt-system/agents/{agent_key}.md", "skill_assigned": skill_name}

    # Standard skill proposal (SkillSchool)
    try:
        path = skillschool.approve_proposal(slug)
    except FileNotFoundError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    # Reload skills
    request.app.state.skills.load_all()
    # Rebuild knowledge graph (new skill file may contain [[wiki-links]])
    try:
        request.app.state.knowledge_graph.build()
    except Exception:
        pass
    return {"status": "approved", "path": path}


@router.post("/proposals/{slug}/reject")
async def reject_proposal(request: Request, slug: str) -> dict:
    """Reject a skill proposal."""
    skillschool = request.app.state.skillschool
    try:
        skillschool.reject_proposal(slug)
    except FileNotFoundError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc

    # Sync: update heal-proposals.json if healer proposal
    if slug.startswith("heal-"):
        vault = request.app.state.vault
        vault_dir = getattr(vault, "_vault_dir", None)
        if vault_dir:
            from pathlib import Path
            review_path = Path(vault_dir) / "skills-review" / f"{slug}.md"
            if review_path.exists():
                try:
                    import frontmatter
                    doc = frontmatter.load(str(review_path))
                    agent_key = doc.metadata.get("agent_key", "")
                    skill_name = doc.metadata.get("skill", "")
                    if agent_key and skill_name:
                        from agntspace.api.routes.simulate import _get_logs_dir
                        logs_dir = _get_logs_dir(request)
                        if logs_dir:
                            hp_path = logs_dir / "heal-proposals.json"
                            if hp_path.exists():
                                import json as _json
                                hp = _json.loads(hp_path.read_text(encoding="utf-8"))
                                for hp_item in hp:
                                    if hp_item.get("agent_key") == agent_key and hp_item.get("skill") == skill_name and hp_item.get("status") == "pending":
                                        hp_item["status"] = "rejected"
                                hp_path.write_text(_json.dumps(hp, indent=2), encoding="utf-8")
                except Exception:
                    pass

    return {"status": "rejected", "slug": slug}


@router.get("/{skill_name}")
async def get_skill(request: Request, skill_name: str) -> dict:
    """Get a single skill's full content."""
    skills = request.app.state.skills
    skill = skills.get_skill(skill_name)
    if not skill:
        raise HTTPException(status_code=404, detail=f"Skill not found: {skill_name}")
    return {
        "name": skill.name,
        "title": skill.title,
        "description": skill.description,
        "category": skill.category,
        "status": skill.status,
        "triggers": skill.triggers,
        "body": skill.body,
        "path": str(skill.path),
        "files": skill.files,
        "author": skill.author,
        "tools_granted": skill.tools_granted,
        "depends_on": skill.depends_on,
        "priority": skill.priority,
        "model_tier": skill.model_tier,
        "examples": skill.examples,
        "output_format": skill.output_format,
    }


@router.put("/{skill_name}")
async def update_skill(request: Request, skill_name: str, body: SkillUpdateRequest) -> dict:
    """Update a skill's raw content (frontmatter + body)."""
    settings = request.app.state.settings
    skills = request.app.state.skills
    skill = skills.get_skill(skill_name)
    if not skill:
        raise HTTPException(status_code=404, detail=f"Skill not found: {skill_name}")

    from agntspace.vault.writer import VaultWriter

    writer = VaultWriter(settings.vault_dir)
    writer.write(f"agnt-system/skills/{skill.path}", body.content)
    skills.load_all()
    return {"status": "updated", "name": skill_name}


@router.post("/create")
async def create_skill(request: Request, body: SkillCreateRequest) -> dict:
    """Create a new custom skill."""
    import re

    settings = request.app.state.settings
    skills = request.app.state.skills

    slug = re.sub(r"[^a-z0-9-]", "", body.name.lower().replace(" ", "-"))[:60]
    if not slug:
        raise HTTPException(status_code=400, detail="Invalid skill name")

    # Build SKILL.md content
    triggers_yaml = "\n".join(f'  - "{t}"' for t in body.triggers) if body.triggers else '  - "' + slug + '"'
    tools_yaml = "\n".join(f'  - "{t}"' for t in body.tools_granted) if body.tools_granted else ""
    deps_yaml = "\n".join(f'  - "{d}"' for d in body.depends_on) if body.depends_on else ""

    # Build examples YAML
    examples_yaml = ""
    if body.examples:
        lines = []
        for ex in body.examples:
            lines.append(f'  - input: "{ex.get("input", "")}"')
            lines.append(f'    output: "{ex.get("output", "")}"')
        examples_yaml = "\n".join(lines)

    content = f"""---
name: {slug}
title: "{body.title}"
description: "{body.description}"
category: {body.category}
status: active
author: {body.author}
priority: {body.priority}
model_tier: "{body.model_tier}"
output_format: "{body.output_format}"
triggers:
{triggers_yaml}
tools_granted:
{tools_yaml}
depends_on:
{deps_yaml}
examples:
{examples_yaml}
---

## Instructions

{body.instructions or "Define the step-by-step instructions for this skill."}

## Rules

- Follow the user's preferences from PROFILE.md
- Check CONTRACT.md permissions before taking action
"""

    from agntspace.vault.writer import VaultWriter

    writer = VaultWriter(settings.vault_dir)
    path = f"agnt-system/skills/{body.category}/{slug}/SKILL.md"
    writer.write(path, content)
    skills.load_all()
    return {"status": "created", "name": slug, "path": path}


@router.get("/{skill_name}/files/{file_path:path}")
async def get_skill_file(request: Request, skill_name: str, file_path: str) -> dict:
    """Read an additional file from a skill folder (template, example, etc.)."""
    skills = request.app.state.skills
    content = skills.get_skill_file(skill_name, file_path)
    if content is None:
        raise HTTPException(status_code=404, detail=f"File not found: {file_path}")
    return {"path": file_path, "content": content}


@router.put("/{skill_name}/files/{file_path:path}")
async def update_skill_file(request: Request, skill_name: str, file_path: str, body: SkillFileRequest) -> dict:
    """Write an additional file to a skill folder."""
    settings = request.app.state.settings
    skills = request.app.state.skills
    skill = skills.get_skill(skill_name)
    if not skill:
        raise HTTPException(status_code=404, detail=f"Skill not found: {skill_name}")

    from pathlib import Path as P

    skill_dir = P(skill.path).parent
    full_path = f"agnt-system/skills/{skill_dir}/{file_path}"

    from agntspace.vault.writer import VaultWriter

    writer = VaultWriter(settings.vault_dir)
    writer.write(full_path, body.content)
    skills.load_all()
    return {"status": "updated", "path": full_path}
