"""Project management API endpoints."""

from __future__ import annotations

from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel

router = APIRouter(prefix="/projects", tags=["projects"])


class ProjectCreateRequest(BaseModel):
    title: str
    description: str = ""
    target_date: str = ""
    related_goals: list[str] = []
    assigned_agents: list[str] = []
    linked_kbs: list[str] = []


class ProjectUpdateRequest(BaseModel):
    title: str | None = None
    description: str | None = None
    target_date: str | None = None
    related_goals: list[str] | None = None
    assigned_agents: list[str] | None = None
    linked_kbs: list[str] | None = None


class StatusRequest(BaseModel):
    status: str


class MilestoneRequest(BaseModel):
    milestone: str


class LogRequest(BaseModel):
    note: str


@router.get("")
async def list_projects(request: Request, status: str | None = None) -> list[dict]:
    """List all projects."""
    svc = request.app.state.project_service
    return svc.list_projects(status_filter=status)


@router.post("")
async def create_project(request: Request, body: ProjectCreateRequest) -> dict:
    """Create a new project."""
    svc = request.app.state.project_service
    path = svc.create_project(
        title=body.title,
        description=body.description,
        target_date=body.target_date,
        related_goals=body.related_goals,
        assigned_agents=body.assigned_agents,
        linked_kbs=body.linked_kbs,
    )
    return {"path": path, "status": "active"}


@router.get("/linkable")
async def list_linkable(request: Request) -> dict:
    """List goals, subagents, and KBs that can be linked to projects."""
    goals = []
    try:
        coach = request.app.state.coach
        goals = [
            {"slug": g["slug"], "title": g["title"], "status": g["status"]}
            for g in coach.list_goals()
        ]
    except Exception:
        pass

    agents = []
    try:
        orchestrator = request.app.state.orchestrator
        agents = orchestrator.list_agents()
    except Exception:
        pass

    kbs = []
    try:
        kb_service = request.app.state.kb_service
        kbs = kb_service.list_kbs()
    except Exception:
        pass

    return {"goals": goals, "agents": agents, "kbs": kbs}


@router.get("/{slug}")
async def get_project(request: Request, slug: str) -> dict:
    """Get a project's full detail."""
    svc = request.app.state.project_service
    detail = svc.get_project_detail(slug)
    if not detail:
        raise HTTPException(status_code=404, detail=f"Project not found: {slug}")
    return detail


@router.put("/{slug}")
async def update_project(request: Request, slug: str, body: ProjectUpdateRequest) -> dict:
    """Update a project's fields."""
    svc = request.app.state.project_service
    if not svc.get_project(slug):
        raise HTTPException(status_code=404, detail=f"Project not found: {slug}")
    svc.update_project(
        slug=slug,
        title=body.title,
        description=body.description,
        target_date=body.target_date,
        related_goals=body.related_goals,
        assigned_agents=body.assigned_agents,
        linked_kbs=body.linked_kbs,
    )
    return {"slug": slug, "status": "updated"}


@router.patch("/{slug}/status")
async def update_status(request: Request, slug: str, body: StatusRequest) -> dict:
    """Update a project's status."""
    svc = request.app.state.project_service
    try:
        svc.update_status(slug, body.status)
    except FileNotFoundError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    return {"slug": slug, "status": body.status}


@router.post("/{slug}/milestones")
async def add_milestone(request: Request, slug: str, body: MilestoneRequest) -> dict:
    """Add a milestone to a project."""
    svc = request.app.state.project_service
    if not svc.get_project(slug):
        raise HTTPException(status_code=404, detail=f"Project not found: {slug}")
    svc.add_milestone(slug, body.milestone)
    return {"slug": slug, "status": "milestone_added"}


@router.post("/{slug}/log")
async def add_log_entry(request: Request, slug: str, body: LogRequest) -> dict:
    """Add a log entry to a project."""
    svc = request.app.state.project_service
    if not svc.get_project(slug):
        raise HTTPException(status_code=404, detail=f"Project not found: {slug}")
    svc.add_log(slug, body.note)
    return {"slug": slug, "status": "logged"}


@router.delete("/{slug}")
async def delete_project(request: Request, slug: str) -> dict:
    """Delete a project."""
    svc = request.app.state.project_service
    if not svc.get_project(slug):
        raise HTTPException(status_code=404, detail=f"Project not found: {slug}")
    svc.delete_project(slug)
    return {"slug": slug, "status": "deleted"}
