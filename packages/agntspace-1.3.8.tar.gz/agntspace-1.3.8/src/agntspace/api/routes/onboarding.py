"""Onboarding conversation endpoint.

Runs a guided conversation to generate personalized PROFILE.md and CONTRACT.md.
"""

from __future__ import annotations

import logging

from fastapi import APIRouter, Request
from pydantic import BaseModel

router = APIRouter(prefix="/onboarding", tags=["onboarding"])

log = logging.getLogger(__name__)

_ONBOARDING_SYSTEM = """You are the AgntSpace onboarding assistant. Your job is to learn about the user through a friendly, concise conversation and generate their personalized PROFILE.md and CONTRACT.md.

## Conversation Flow

Ask questions ONE AT A TIME. Keep it conversational, not like a form. Cover these areas:

1. **Name and role** — "What should I call you? What's your primary role?"
2. **Companies/projects** — "What companies or projects are you working on?"
3. **Tools** — "What tools do you use daily? (email, calendar, messaging, notes)"
4. **Communication style** — "How do you prefer to communicate? Concise? Detailed?"
5. **What to automate** — "What tasks eat up your time that you'd love to hand off?"
6. **Proactivity level** — Explain the 4 tiers (Observer/Advisor/Assistant/Partner) and ask which fits
7. **Privacy preference** — "Cloud LLM for quality, or local for full privacy?"
8. **Sensitive areas** — "Any topics I should always ask before accessing? (finances, health, etc.)"
9. **Timezone and work hours** — "What timezone and work hours?"

After gathering enough info (usually 5-8 exchanges), say EXACTLY:

```
ONBOARDING_COMPLETE
```

Followed by two fenced code blocks:

```profile
(the full PROFILE.md content in markdown with YAML frontmatter)
```

```contract
(the full CONTRACT.md content in markdown with YAML frontmatter)
```

Use the default PROFILE.md and CONTRACT.md templates as the base structure, but fill them in with the user's actual answers. For CONTRACT.md, set the proactivity level, privacy mode, and sensitive directories based on their answers.

Be warm but efficient. Don't ask more than one question per message. Don't be robotic — this should feel like meeting a new colleague."""


class OnboardingRequest(BaseModel):
    message: str
    conversation_id: str | None = None


class OnboardingResponse(BaseModel):
    message: str
    conversation_id: str
    complete: bool
    profile: str | None = None
    contract: str | None = None


@router.get("/status")
async def onboarding_status(request: Request) -> dict:
    """Check if onboarding has been completed."""
    vault = request.app.state.vault
    identity = vault.read_identity_files()
    profile = identity.get("PROFILE")
    onboarded = (
        profile is not None
        and "[Your name]" not in profile.content
        and len(profile.content.strip()) > 200
    )
    return {"onboarded": onboarded}


@router.post("/chat", response_model=OnboardingResponse)
async def onboarding_chat(request: Request, body: OnboardingRequest) -> OnboardingResponse:
    """Chat with the onboarding assistant."""
    agent = request.app.state.agent
    memory = request.app.state.memory
    llm = agent._llm  # noqa: SLF001

    conv_id = body.conversation_id
    if not conv_id or not await memory.conversation_exists(conv_id):
        conv_id = await memory.create_conversation(title="Onboarding")

    # Store user message
    await memory.add_message(conv_id, "user", body.message)
    history = await memory.get_context_messages(conv_id)

    # Use onboarding system prompt instead of the agent's identity prompt
    from agntspace.llm.base import Message

    msgs = [Message(role=m.role, content=m.content) for m in history]
    response = await llm.complete(
        messages=msgs,
        system=_ONBOARDING_SYSTEM,
        max_tokens=4096,
    )

    reply = response.content
    await memory.add_message(conv_id, "assistant", reply)

    # Check if onboarding is complete
    complete = "ONBOARDING_COMPLETE" in reply
    profile_content = None
    contract_content = None

    if complete:
        profile_content = _extract_block(reply, "profile")
        contract_content = _extract_block(reply, "contract")

        # Save to vault
        if profile_content or contract_content:
            from agntspace.vault.writer import VaultWriter

            settings = request.app.state.settings
            writer = VaultWriter(settings.vault_dir)

            if profile_content:
                writer.write("agnt-system/identity/PROFILE.md", profile_content)
                log.info("Onboarding: saved agnt-system/identity/PROFILE.md")

            if contract_content:
                writer.write("agnt-system/identity/CONTRACT.md", contract_content)
                log.info("Onboarding: saved agnt-system/identity/CONTRACT.md")

            # Reinitialize agent with new identity
            await agent.initialize()
            log.info("Onboarding: agent reinitialized with new identity")

        # Clean the reply for display (remove the raw blocks)
        display_reply = reply.split("ONBOARDING_COMPLETE")[0].strip()
        if not display_reply:
            display_reply = "Onboarding complete! Your profile and contract have been set up. Head to the dashboard to start using AgntSpace."
    else:
        display_reply = reply

    return OnboardingResponse(
        message=display_reply,
        conversation_id=conv_id,
        complete=complete,
        profile=profile_content,
        contract=contract_content,
    )


def _extract_block(text: str, label: str) -> str | None:
    """Extract content from a fenced code block with a given label."""
    marker = f"```{label}"
    start = text.find(marker)
    if start == -1:
        return None
    start = text.index("\n", start) + 1
    end = text.find("```", start)
    if end == -1:
        return text[start:].strip()
    return text[start:end].strip()
