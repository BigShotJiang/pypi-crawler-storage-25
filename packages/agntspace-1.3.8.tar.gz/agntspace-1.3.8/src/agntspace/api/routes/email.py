"""Email API endpoints — read, search, send, manage.

All IMAP/SMTP operations run in a thread pool via run_in_executor
because imaplib is synchronous and would block the async event loop.
"""

from __future__ import annotations

import asyncio
from functools import partial

from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel


async def _run_sync(fn, *args, **kwargs):  # noqa: ANN001, ANN002, ANN003
    """Run a blocking function in the thread pool."""
    loop = asyncio.get_event_loop()
    return await loop.run_in_executor(None, partial(fn, *args, **kwargs))


def _enforce(request: Request, action: str) -> None:
    """Check the contract before any email action."""
    from agntspace.security.middleware import ActionDenied, ConfirmationRequired, enforce

    contract = request.app.state.contract
    try:
        enforce(contract, action, integration="email")
    except ActionDenied as e:
        raise HTTPException(status_code=403, detail=e.reason) from e
    except ConfirmationRequired as e:
        raise HTTPException(status_code=428, detail=e.reason) from e

router = APIRouter(prefix="/email", tags=["email"])


class EmailConnectRequest(BaseModel):
    email: str
    imap_host: str
    imap_port: int = 993
    smtp_host: str
    smtp_port: int = 587
    username: str = ""
    password: str


class EmailSendRequest(BaseModel):
    to: str
    subject: str
    body: str


class EmailMoveRequest(BaseModel):
    to_folder: str


@router.get("/status")
async def email_status(request: Request) -> dict:
    """Get email connection status."""
    em = request.app.state.email_integration
    status = await em.check_status()
    return {
        "connected": status.connected,
        "email": status.metadata.get("email", ""),
        "last_sync": status.last_sync,
    }


@router.post("/connect")
async def connect_email(request: Request, body: EmailConnectRequest) -> dict:
    """Connect email with IMAP/SMTP credentials."""
    import logging

    log = logging.getLogger(__name__)
    log.warning(
        "Email connect attempt: host=%s port=%s email=%s",
        body.imap_host, body.imap_port, body.email,
    )
    em = request.app.state.email_integration
    creds = {
        "email": body.email,
        "imap_host": body.imap_host,
        "imap_port": body.imap_port,
        "smtp_host": body.smtp_host,
        "smtp_port": body.smtp_port,
        "username": body.username or body.email,
        "password": body.password,
    }
    try:
        await em.connect(creds)
        # Persist credentials for auto-reconnect on restart
        request.app.state.credential_store.set("email", creds)
        return {"connected": True, "email": body.email}
    except ConnectionError as e:
        raise HTTPException(status_code=400, detail=str(e)) from e


@router.post("/disconnect")
async def disconnect_email(request: Request) -> dict:
    """Disconnect email."""
    em = request.app.state.email_integration
    await em.disconnect()
    request.app.state.credential_store.delete("email")
    return {"connected": False}


@router.get("/count")
async def inbox_count(request: Request, folder: str = "INBOX") -> dict:
    """Get total and unread email count."""
    _enforce(request, "read_inbox")
    em = request.app.state.email_integration
    if not em.is_connected:
        raise HTTPException(status_code=400, detail="Email not connected")
    return await _run_sync(em.get_inbox_count, folder=folder)


@router.post("/draft")
async def save_draft(request: Request, body: EmailSendRequest) -> dict:
    """Save an email as a draft (appears in Gmail Drafts folder)."""
    _enforce(request, "draft_content")
    em = request.app.state.email_integration
    if not em.is_connected:
        raise HTTPException(status_code=400, detail="Email not connected")
    success = await _run_sync(em.save_draft, to=body.to, subject=body.subject, body=body.body)
    if not success:
        raise HTTPException(status_code=500, detail="Failed to save draft")
    return {"drafted": True, "to": body.to, "subject": body.subject}


@router.get("/inbox")
async def list_inbox(
    request: Request,
    limit: int = 20,
    unread_only: bool = False,
    folder: str = "INBOX",
) -> list[dict]:
    """List emails in a folder."""
    _enforce(request, "read_inbox")
    em = request.app.state.email_integration
    if not em.is_connected:
        raise HTTPException(status_code=400, detail="Email not connected")

    emails = await _run_sync(em.list_emails, folder=folder, limit=limit, unread_only=unread_only)
    return [
        {
            "uid": e.uid,
            "subject": e.subject,
            "sender": e.sender,
            "date": e.date,
            "snippet": e.snippet,
            "is_read": e.is_read,
        }
        for e in emails
    ]


@router.get("/message/{uid}")
async def read_email(request: Request, uid: str, folder: str = "INBOX") -> dict:
    """Read a single email."""
    _enforce(request, "read_inbox")
    em = request.app.state.email_integration
    if not em.is_connected:
        raise HTTPException(status_code=400, detail="Email not connected")

    msg = await _run_sync(em.read_email, uid, folder=folder)
    if not msg:
        raise HTTPException(status_code=404, detail="Email not found")

    return {
        "uid": msg.uid,
        "subject": msg.subject,
        "sender": msg.sender,
        "to": msg.to,
        "date": msg.date,
        "body": msg.body,
        "is_read": msg.is_read,
    }


@router.get("/search")
async def search_emails(
    request: Request, q: str, folder: str = "INBOX", limit: int = 20
) -> list[dict]:
    """Search emails by subject or sender."""
    _enforce(request, "read_inbox")
    em = request.app.state.email_integration
    if not em.is_connected:
        raise HTTPException(status_code=400, detail="Email not connected")

    emails = await _run_sync(em.search_emails, q, folder=folder, limit=limit)
    return [
        {
            "uid": e.uid,
            "subject": e.subject,
            "sender": e.sender,
            "date": e.date,
            "snippet": e.snippet,
        }
        for e in emails
    ]


@router.post("/send")
async def send_email(request: Request, body: EmailSendRequest) -> dict:
    """Send an email."""
    _enforce(request, "send_email")
    em = request.app.state.email_integration
    if not em.is_connected:
        raise HTTPException(status_code=400, detail="Email not connected")

    success = await _run_sync(em.send_email, to=body.to, subject=body.subject, body=body.body)
    if not success:
        raise HTTPException(status_code=500, detail="Failed to send email")

    return {"sent": True, "to": body.to, "subject": body.subject}


@router.get("/folders")
async def list_folders(request: Request) -> list[str]:
    """List available email folders."""
    _enforce(request, "list_folders")
    em = request.app.state.email_integration
    if not em.is_connected:
        raise HTTPException(status_code=400, detail="Email not connected")
    return await _run_sync(em.list_folders)


@router.post("/message/{uid}/move")
async def move_email(request: Request, uid: str, body: EmailMoveRequest, folder: str = "INBOX") -> dict:
    """Move an email to another folder."""
    _enforce(request, "move_email")
    em = request.app.state.email_integration
    if not em.is_connected:
        raise HTTPException(status_code=400, detail="Email not connected")
    success = await _run_sync(em.move_email, uid, folder, body.to_folder)
    return {"moved": success}


@router.post("/message/{uid}/read")
async def mark_read(request: Request, uid: str, folder: str = "INBOX") -> dict:
    """Mark email as read."""
    em = request.app.state.email_integration
    await _run_sync(em.mark_read, uid, folder)
    return {"marked": "read"}


@router.post("/message/{uid}/unread")
async def mark_unread(request: Request, uid: str, folder: str = "INBOX") -> dict:
    """Mark email as unread."""
    em = request.app.state.email_integration
    await _run_sync(em.mark_unread, uid, folder)
    return {"marked": "unread"}


@router.post("/sync")
async def sync_email(request: Request) -> dict:
    """Sync email — check for new messages."""
    em = request.app.state.email_integration
    if not em.is_connected:
        raise HTTPException(status_code=400, detail="Email not connected")
    return await em.sync()
