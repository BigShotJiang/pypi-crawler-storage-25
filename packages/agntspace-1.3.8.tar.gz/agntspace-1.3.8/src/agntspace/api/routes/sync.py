"""Vault sync API — configure Obsidian integration and trigger sync."""

from __future__ import annotations

from pathlib import Path

from fastapi import APIRouter, Request
from pydantic import BaseModel

router = APIRouter(prefix="/sync", tags=["sync"])


class SyncConfigRequest(BaseModel):
    mode: str = "sync"  # "off" | "sync" | "direct"
    external_path: str = ""
    folders: list[str] | None = None


class AdoptVaultRequest(BaseModel):
    vault_path: str = ""
    obsidian_path: str = ""  # legacy alias

    @property
    def path(self) -> str:
        return self.vault_path or self.obsidian_path


class ObsidianNoteRequest(BaseModel):
    path: str
    content: str


@router.get("")
async def sync_status(request: Request) -> dict:
    """Get vault sync status."""
    status = request.app.state.vault_sync.status()
    # Add the actual vault path the server is using
    vault = request.app.state.vault
    vault_dir = vault.vault_dir if hasattr(vault, "vault_dir") else getattr(vault, "_vault_dir", "")
    status["vault_path"] = str(vault_dir)
    return status


@router.post("/configure")
async def configure_sync(request: Request, body: SyncConfigRequest) -> dict:
    """Configure vault sync mode and external path."""
    vault_sync = request.app.state.vault_sync
    vault_sync.configure(body.mode, body.external_path, body.folders)

    request.app.state.settings_service.update_section("sync", {
        "mode": body.mode,
        "external_path": body.external_path,
        "folders": body.folders or vault_sync._sync_folders,
    })

    return vault_sync.status()


@router.post("/run")
async def run_sync(request: Request) -> dict:
    """Trigger a sync now."""
    return request.app.state.vault_sync.run_sync()


@router.post("/adopt")
@router.post("/obsidian/adopt")  # legacy alias
async def adopt_vault(request: Request, body: AdoptVaultRequest) -> dict:
    """Point AgntSpace at a folder as its vault (direct mode).

    This makes the chosen folder THE AgntSpace vault. AgntSpace creates
    agntspace/ inside it and all data appears there in real-time.
    Existing content in the folder is never modified.
    """
    folder_path = body.path
    vault_sync = request.app.state.vault_sync
    result = vault_sync.adopt_obsidian_vault(folder_path)

    if "error" not in result:
        request.app.state.settings_service.update_section("sync", {
            "mode": "direct",
            "external_path": folder_path,
        })

    return result


def _is_known_vault(path: Path) -> bool:
    """Check if a directory is a recognized vault (Obsidian, AgntSpace, etc.)."""
    return (
        (path / ".obsidian").is_dir()
        or (path / "agntspace").is_dir()
    )


@router.get("/browse")
async def browse_directory(path: str = "") -> dict:
    """Browse directories for the folder picker UI.

    Returns subdirectories of the given path, with flags for
    recognized vault folders.
    """
    if not path:
        # Default starting points
        home = Path.home()
        drives = []
        import platform
        if platform.system() == "Windows":
            import string
            for letter in string.ascii_uppercase:
                drive = Path(f"{letter}:\\")
                if drive.exists():
                    drives.append({"name": f"{letter}:\\", "path": str(drive), "is_vault": False})
        return {
            "current": str(home),
            "parent": str(home.parent),
            "directories": [
                {"name": "Home", "path": str(home), "is_vault": _is_known_vault(home)},
                {"name": "Documents", "path": str(home / "Documents"), "is_vault": False},
                {"name": "Desktop", "path": str(home / "Desktop"), "is_vault": False},
                *drives,
            ],
        }

    browse_path = Path(path)
    if not browse_path.is_dir():
        return {"error": f"Not a directory: {path}"}

    dirs = []
    try:
        for item in sorted(browse_path.iterdir()):
            if item.is_dir() and not item.name.startswith("."):
                dirs.append({
                    "name": item.name,
                    "path": str(item),
                    "is_vault": _is_known_vault(item),
                })
    except PermissionError:
        return {"error": f"Permission denied: {path}", "current": path, "directories": []}

    return {
        "current": str(browse_path),
        "parent": str(browse_path.parent) if browse_path.parent != browse_path else None,
        "directories": dirs,
    }


@router.post("/obsidian/import")
async def import_obsidian_vault(request: Request, body: AdoptVaultRequest) -> dict:
    """Import an Obsidian vault's notes into a knowledge base (read-only).

    Scans the vault for .md files, copies them into a KB's raw/ directory,
    and triggers ingest. The Obsidian vault is never modified.
    """
    import shutil

    obs_path = Path(body.path)
    if not obs_path.is_dir():
        return {"error": f"Path does not exist: {body.path}"}

    # Find all markdown files
    md_files = list(obs_path.rglob("*.md"))
    # Exclude .obsidian/ and .trash/
    md_files = [f for f in md_files if ".obsidian" not in str(f) and ".trash" not in str(f)]

    if not md_files:
        return {"error": "No markdown files found in vault"}

    # Create/get KB named after the vault folder
    kb = request.app.state.kb_service
    vault = request.app.state.vault
    vault_dir = vault.vault_dir if hasattr(vault, "vault_dir") else vault._vault_dir

    kb_slug = obs_path.name.lower().replace(" ", "-")
    kbs = kb.list_kbs()
    if not any(k["slug"] == kb_slug for k in kbs):
        kb.create_kb(obs_path.name)

    # Copy files to KB raw/ for processing
    kb_inbox = vault_dir / "kb" / kb_slug / "raw"
    kb_inbox.mkdir(parents=True, exist_ok=True)
    copied = 0
    for md in md_files[:200]:  # limit to 200 files per import
        dest = kb_inbox / md.name
        if not dest.exists():
            shutil.copy2(str(md), str(dest))
            copied += 1

    # Save import config
    settings_svc = request.app.state.settings_service
    settings_svc.update_section("sync", {
        "mode": "import",
        "external_path": str(obs_path),
    })

    # Trigger ingest
    result = await kb.ingest(kb_slug)

    return {
        "kb_slug": kb_slug,
        "files_found": len(md_files),
        "files_copied": copied,
        "ingested": result.get("count", 0),
        "wiki_updates": result.get("wiki_updates", []),
    }


@router.get("/obsidian/search")
async def obsidian_search(request: Request, q: str) -> list[dict]:
    """Search Obsidian vault via obsidian-cli."""
    return request.app.state.vault_sync.obsidian_search(q)


@router.post("/obsidian/create")
async def obsidian_create(request: Request, body: ObsidianNoteRequest) -> dict:
    """Create a note directly in the Obsidian vault."""
    success = request.app.state.vault_sync.obsidian_create_note(body.path, body.content)
    return {"created": success, "path": body.path}
