"""Task delegation API endpoints."""

from __future__ import annotations

from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel

router = APIRouter(prefix="/tasks", tags=["tasks"])


class TaskCreateRequest(BaseModel):
    title: str
    brief: str
    mode: str = "review"
    domain: str = "general"


class TaskStatusRequest(BaseModel):
    status: str


class TaskProgressRequest(BaseModel):
    note: str


class TaskFeedbackRequest(BaseModel):
    rating: str  # good | needs_improvement | redo
    note: str = ""


class TaskSummary(BaseModel):
    slug: str
    title: str
    status: str
    mode: str
    domain: str
    delegated: str
    due: str


class TaskDetail(BaseModel):
    slug: str
    content: str
    metadata: dict


@router.get("")
async def list_tasks(
    request: Request, status: str | None = None
) -> list[TaskSummary]:
    """List all tasks, optionally filtered by status."""
    task_svc = request.app.state.task_service
    tasks = task_svc.list_tasks(status_filter=status)
    return [TaskSummary(**t) for t in tasks]


@router.post("")
async def create_task(request: Request, body: TaskCreateRequest) -> dict:
    """Create a new delegated task."""
    task_svc = request.app.state.task_service
    path = task_svc.create_task(
        title=body.title,
        brief=body.brief,
        mode=body.mode,
        domain=body.domain,
    )
    return {"path": path, "status": "delegated"}


@router.get("/{slug}")
async def get_task(request: Request, slug: str) -> TaskDetail:
    """Get a task by slug."""
    task_svc = request.app.state.task_service
    doc = task_svc.get_task(slug)
    if not doc:
        raise HTTPException(status_code=404, detail=f"Task not found: {slug}")
    return TaskDetail(slug=slug, content=doc.content, metadata=doc.metadata)


@router.patch("/{slug}/status")
async def update_task_status(
    request: Request, slug: str, body: TaskStatusRequest
) -> dict:
    """Update a task's status."""
    task_svc = request.app.state.task_service
    try:
        task_svc.update_status(slug, body.status)
    except (FileNotFoundError, ValueError) as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    return {"slug": slug, "status": body.status}


@router.post("/{slug}/progress")
async def add_progress(
    request: Request, slug: str, body: TaskProgressRequest
) -> dict:
    """Add a progress note to a task."""
    task_svc = request.app.state.task_service
    task_svc.add_progress(slug, body.note)
    return {"slug": slug, "status": "ok"}


@router.post("/{slug}/feedback")
async def set_feedback(
    request: Request, slug: str, body: TaskFeedbackRequest
) -> dict:
    """Set feedback on a completed task. Triggers trust update."""
    task_svc = request.app.state.task_service
    trust_svc = request.app.state.trust_service

    try:
        feedback = task_svc.set_feedback(slug, body.rating, body.note)
    except (FileNotFoundError, ValueError) as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc

    # Feed trust engine
    trust_result = trust_svc.record_feedback(
        domain=feedback["domain"],
        rating=feedback["rating"],
    )

    # Fire-and-forget: refine skills if feedback was negative
    if body.rating != "good":
        import asyncio

        skillschool = request.app.state.skillschool

        async def _refine_skill() -> None:
            try:
                await skillschool.refine_from_feedback(feedback["domain"])
            except Exception:
                pass  # non-critical — don't block response

        asyncio.create_task(_refine_skill())

    return {
        "slug": slug,
        "rating": body.rating,
        "trust_update": trust_result,
    }
