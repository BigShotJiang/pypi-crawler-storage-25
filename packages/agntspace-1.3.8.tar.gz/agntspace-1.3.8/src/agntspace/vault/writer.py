"""Write and update markdown files in the vault, preserving YAML frontmatter.

Versioning strategy: caller-driven, not heuristic.
- User/API edits: versioned=True (default) — always saves history
- Pipeline operations (compile, cross-link): versioned=False — no history noise
"""

from __future__ import annotations

import hashlib
import logging
import re
from datetime import UTC, datetime
from pathlib import Path

import frontmatter

log = logging.getLogger(__name__)

# Directories where version history is available
_VERSIONED_DIRS = {"agnt-kb/"}

# Windows reserved device names (cannot be used as filenames)
_WINDOWS_RESERVED = frozenset({
    "CON", "PRN", "AUX", "NUL",
    *(f"COM{i}" for i in range(1, 10)),
    *(f"LPT{i}" for i in range(1, 10)),
})

_MAX_FILENAME_LEN = 180  # Leave room for directory path within Windows MAX_PATH


def title_to_filename(title: str) -> str:
    """Convert a display title to a safe, human-readable filename (without extension).

    Design: filenames should look like the title, not a slug.
    'Sarah Chen' → 'Sarah Chen'  (not 'sarah-chen')
    'AC/DC'      → 'AC-DC'       (/ is path separator)
    'What: Why?' → 'What Why'    (strip illegal chars)
    'CON'        → 'CON_'        (Windows reserved)

    The result is safe on Windows, macOS, and Linux.
    """
    if not title or not title.strip():
        return "untitled"

    # Strip characters illegal in filenames on any OS: / \ : * ? " < > |
    name = re.sub(r'[/\\:*?"<>|]', "", title)

    # Collapse multiple spaces, strip leading/trailing whitespace and dots
    name = re.sub(r"\s+", " ", name).strip().strip(".")

    # Handle Windows reserved device names
    base = name.split(".")[0].upper()
    if base in _WINDOWS_RESERVED:
        name = name + "_"

    # Truncate to safe length
    if len(name) > _MAX_FILENAME_LEN:
        name = name[:_MAX_FILENAME_LEN].rstrip()

    return name or "untitled"


class VaultWriter:
    """Creates and updates markdown files in the vault directory."""

    def __init__(self, vault_dir: Path) -> None:
        self._vault_dir = vault_dir
        self._pipeline_mode = False  # when True, all writes skip versioning

    def pipeline(self) -> _PipelineContext:
        """Context manager to suppress versioning during pipeline operations.

        Usage:
            with writer.pipeline():
                writer.write(...)  # no versioning
                writer.append(...)  # no versioning
        """
        return _PipelineContext(self)

    def write(
        self,
        relative_path: str,
        content: str,
        metadata: dict | None = None,
        versioned: bool = True,
    ) -> Path:
        """Write a vault file. Creates parent directories if needed.

        versioned=True (default): saves previous version to .history/ if file
        is in a versioned directory (agnt-kb/wiki/) and content actually changed.
        versioned=False: skip versioning (for pipeline operations).
        Pipeline mode (via writer.pipeline() context) also suppresses versioning.
        """
        path = self._vault_dir / relative_path
        path.parent.mkdir(parents=True, exist_ok=True)

        effective_versioned = versioned and not self._pipeline_mode
        if effective_versioned and path.is_file() and self._is_versionable(relative_path):
            self._save_version(path)

        if metadata:
            post = frontmatter.Post(content, **metadata)
            path.write_text(frontmatter.dumps(post), encoding="utf-8")
        else:
            path.write_text(content, encoding="utf-8")
        return path

    def append(self, relative_path: str, text: str, versioned: bool = False) -> None:
        """Append text to an existing vault file.

        versioned defaults to False for append — appends are typically pipeline
        operations (compile enrichment markers). Set True for user-initiated appends.
        """
        path = self._vault_dir / relative_path
        if not path.is_file():
            raise FileNotFoundError(f"Vault file not found: {path}")

        effective_versioned = versioned and not self._pipeline_mode
        if effective_versioned and self._is_versionable(relative_path):
            self._save_version(path)

        with open(path, "a", encoding="utf-8") as f:
            f.write(text)

    def _is_versionable(self, relative_path: str) -> bool:
        """Check if a file is in a versioned directory."""
        normalized = relative_path.replace("\\", "/")
        if not normalized.endswith(".md"):
            return False
        for prefix in _VERSIONED_DIRS:
            if normalized.startswith(prefix) and "/wiki/" in normalized:
                basename = normalized.split("/")[-1]
                if basename.startswith(("_", ".")) or "/.archives/" in normalized or "/.history/" in normalized:
                    return False
                return True
        return False

    def _save_version(self, path: Path) -> None:
        """Save current file content as a version in .history/.

        Only skips if content is identical to the last saved version (hash match).
        No size thresholds — every real change is versioned.
        """
        try:
            old_content = path.read_text(encoding="utf-8")
        except Exception:
            return

        if not old_content.strip():
            return

        history_dir = path.parent / ".history"
        old_hash = hashlib.md5(old_content.encode()).hexdigest()[:12]

        # Skip if identical to last version
        if history_dir.exists():
            existing = sorted(history_dir.glob(f"{path.stem}_*.md"), reverse=True)
            if existing:
                try:
                    last_hash = hashlib.md5(
                        existing[0].read_text(encoding="utf-8").encode()
                    ).hexdigest()[:12]
                    if old_hash == last_hash:
                        return
                except Exception:
                    pass

        history_dir.mkdir(parents=True, exist_ok=True)
        timestamp = datetime.now(UTC).strftime("%Y%m%dT%H%M%S%f")
        version_path = history_dir / f"{path.stem}_{timestamp}.md"
        version_path.write_text(old_content, encoding="utf-8")
        log.debug("Version saved: %s", version_path.relative_to(self._vault_dir))

        # Keep only last 20 versions per article
        existing = sorted(history_dir.glob(f"{path.stem}_*.md"), reverse=True)
        for old_version in existing[20:]:
            try:
                old_version.unlink()
            except Exception:
                pass

    def list_versions(self, relative_path: str) -> list[dict]:
        """List version history for a file."""
        path = self._vault_dir / relative_path
        history_dir = path.parent / ".history"
        if not history_dir.is_dir():
            return []

        versions = []
        for vf in sorted(history_dir.glob(f"{path.stem}_*.md"), reverse=True):
            parts = vf.stem.rsplit("_", 1)
            timestamp = parts[-1] if len(parts) >= 2 else ""
            versions.append({
                "version": vf.name,
                "timestamp": timestamp,
                "size": vf.stat().st_size,
                "path": str(vf.relative_to(self._vault_dir)),
            })
        return versions

    def read_version(self, relative_path: str, version: str) -> str | None:
        """Read a specific version of a file."""
        path = self._vault_dir / relative_path
        version_path = path.parent / ".history" / version
        if version_path.is_file():
            return version_path.read_text(encoding="utf-8")
        return None


class _PipelineContext:
    """Context manager that suppresses versioning during pipeline operations."""

    def __init__(self, writer: VaultWriter) -> None:
        self._writer = writer

    def __enter__(self) -> VaultWriter:
        self._writer._pipeline_mode = True
        return self._writer

    def __exit__(self, *args: object) -> None:
        self._writer._pipeline_mode = False
