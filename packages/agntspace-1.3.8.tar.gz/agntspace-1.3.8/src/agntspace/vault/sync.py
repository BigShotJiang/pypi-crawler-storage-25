"""Vault sync + Obsidian integration.

Three modes:
1. OFF: No sync (default).
2. SYNC: AgntSpace vault + Obsidian vault are separate, selected folders sync.
3. DIRECT: AgntSpace vault IS the Obsidian vault. AgntSpace creates its
   directories inside the Obsidian vault and works there natively.
   No sync — same files, real-time. Best experience.
"""

from __future__ import annotations

import hashlib
import logging
import shutil
import subprocess
from datetime import UTC, datetime
from pathlib import Path

log = logging.getLogger(__name__)

SYSTEM_FILES = {
    "SOUL.md", "USER.md", "PROFILE.md", "CONTRACT.md", "TRUST.md",
}
SYSTEM_DIRS = {
    "agnt-system/agents", "agnt-system/security", "skills-review", "_templates",
}


class VaultSync:
    """Vault sync and Obsidian integration."""

    def __init__(
        self,
        vault_dir: Path,
        external_dir: Path | None = None,
        sync_folders: list[str] | None = None,
        mode: str = "off",  # "off" | "sync" | "obsidian-cli"
    ) -> None:
        self._vault = vault_dir
        self._external = external_dir or Path("")
        self._sync_folders = sync_folders or [
            "projects", "companies", "contacts", "knowledge",
            "journal", "tasks", "goals", "drafts", "inbox",
        ]
        self._mode = mode
        self._last_sync: str = ""

    @property
    def mode(self) -> str:
        return self._mode

    @property
    def is_configured(self) -> bool:
        if self._mode == "off":
            return False
        return self._external.is_dir()

    def configure(
        self,
        mode: str,
        external_path: str = "",
        folders: list[str] | None = None,
    ) -> None:
        """Configure sync mode and paths."""
        self._mode = mode
        if external_path:
            self._external = Path(external_path)
        if folders:
            self._sync_folders = [f for f in folders if f not in SYSTEM_DIRS]
        log.info("Vault sync: mode=%s, path=%s", mode, external_path)

    def adopt_obsidian_vault(self, obsidian_path: str) -> dict:
        """Point AgntSpace at a folder as its vault (direct mode).

        Creates agntspace/ inside the folder for all AgntSpace data.
        User's existing files are never touched — read-only for knowledge.
        """
        root_path = Path(obsidian_path)

        if not root_path.is_dir():
            return {"error": f"Path does not exist: {obsidian_path}"}

        is_obsidian = (root_path / ".obsidian").is_dir()
        vault_path = root_path / "agntspace"

        # Initialize agntspace/ inside the folder (run_init handles everything)
        from agntspace.setup.init import run_init

        run_init(vault_dir=root_path, minimal=True)

        # Copy identity files from current vault if target doesn't have them
        copied = []
        for sys_file in SYSTEM_FILES:
            if sys_file == "MEMORY.md":
                # MEMORY.md lives in agnt-memory/
                for prefix in ("agnt-memory/", "memory/", ""):
                    src = self._vault / f"{prefix}{sys_file}"
                    dst = vault_path / f"agnt-memory/{sys_file}"
                    if src.exists() and not dst.exists():
                        dst.parent.mkdir(parents=True, exist_ok=True)
                        shutil.copy2(src, dst)
                        copied.append(f"agnt-memory/{sys_file}")
                        break
            else:
                # Identity files live in agnt-system/identity/
                for prefix in ("agnt-system/identity/", "identity/", ""):
                    src = self._vault / f"{prefix}{sys_file}"
                    dst = vault_path / f"agnt-system/identity/{sys_file}"
                    if src.exists() and not dst.exists():
                        dst.parent.mkdir(parents=True, exist_ok=True)
                        shutil.copy2(src, dst)
                        copied.append(f"agnt-system/identity/{sys_file}")
                        break

        # Set mode to direct
        self._mode = "direct"
        self._external = root_path

        log.info("Adopted vault at %s (is_obsidian=%s, copied %d files)",
                 obsidian_path, is_obsidian, len(copied))
        return {
            "status": "adopted",
            "path": obsidian_path,
            "is_obsidian_vault": is_obsidian,
            "directories_created": ["agntspace/"],
            "files_copied": copied,
            "notes_queued": 0,
            "notes_found": 0,
            "mode": "direct",
            "message": (
                f"AgntSpace is now using {obsidian_path} as its vault. "
                "All data stored in agntspace/ — your files are untouched. "
                "Restart the server to activate."
            ),
        }

    def run_sync(self) -> dict:
        """Run sync based on configured mode."""
        if self._mode == "off":
            return {"status": "sync is off"}
        if self._mode == "obsidian-cli":
            return self._run_obsidian_cli_sync()
        return self._run_folder_sync()

    def obsidian_search(self, query: str) -> list[dict]:
        """Search Obsidian vault via obsidian-cli."""
        if not self._has_obsidian_cli():
            return [{"error": "obsidian-cli not installed"}]
        try:
            result = subprocess.run(
                ["obsidian-cli", "search-content", query],
                capture_output=True, text=True, timeout=10,
                cwd=str(self._external) if self._external.is_dir() else None,
            )
            lines = result.stdout.strip().split("\n") if result.stdout.strip() else []
            return [{"line": line} for line in lines[:20]]
        except Exception as e:
            return [{"error": str(e)}]

    def obsidian_create_note(self, path: str, content: str) -> bool:
        """Create a note in the Obsidian vault."""
        if self._mode == "obsidian-cli" and self._external.is_dir():
            # Write directly to Obsidian vault
            full_path = self._external / path
            full_path.parent.mkdir(parents=True, exist_ok=True)
            full_path.write_text(content, encoding="utf-8")
            log.info("Created note in Obsidian: %s", path)
            return True
        return False

    def status(self) -> dict:
        return {
            "mode": self._mode,
            "external_path": str(self._external),
            "sync_folders": self._sync_folders,
            "last_sync": self._last_sync,
            "configured": self.is_configured,
            "obsidian_cli_available": self._has_obsidian_cli(),
        }

    # ---- Folder sync mode ----

    def _run_folder_sync(self) -> dict:
        if not self._external.is_dir():
            return {"error": "External vault path not found"}

        copied_to_ext = 0
        copied_to_vault = 0
        conflicts = 0

        for folder in self._sync_folders:
            v_dir = self._vault / folder
            e_dir = self._external / folder
            v_dir.mkdir(parents=True, exist_ok=True)
            e_dir.mkdir(parents=True, exist_ok=True)

            v_files = {f.name: f for f in v_dir.glob("*.md")}
            e_files = {f.name: f for f in e_dir.glob("*.md")}

            for filename in set(v_files.keys()) | set(e_files.keys()):
                if filename in SYSTEM_FILES:
                    continue

                vf = v_dir / filename
                ef = e_dir / filename

                if vf.exists() and ef.exists():
                    if self._file_hash(vf) == self._file_hash(ef):
                        continue
                    if vf.stat().st_mtime > ef.stat().st_mtime:
                        shutil.copy2(vf, ef)
                        copied_to_ext += 1
                    elif ef.stat().st_mtime > vf.stat().st_mtime:
                        shutil.copy2(ef, vf)
                        copied_to_vault += 1
                    else:
                        conflicts += 1
                elif vf.exists():
                    shutil.copy2(vf, ef)
                    copied_to_ext += 1
                elif ef.exists():
                    shutil.copy2(ef, vf)
                    copied_to_vault += 1

        self._last_sync = datetime.now(UTC).isoformat()
        return {
            "mode": "sync",
            "copied_to_external": copied_to_ext,
            "copied_to_vault": copied_to_vault,
            "conflicts": conflicts,
            "last_sync": self._last_sync,
        }

    # ---- Obsidian CLI mode ----

    def _run_obsidian_cli_sync(self) -> dict:
        """In CLI mode, vault IS the Obsidian vault. System files live in agntspace/ subfolder.

        This copies system files from ~/agntspace/vault/ to obsidian_vault/agntspace/
        and user content goes directly into the Obsidian vault root.
        """
        if not self._external.is_dir():
            return {"error": "Obsidian vault path not found"}

        # System files → agntspace/ subfolder in Obsidian vault
        sys_dir = self._external / "agntspace"
        sys_dir.mkdir(exist_ok=True)

        copied = 0
        for sys_file in SYSTEM_FILES:
            if sys_file == "MEMORY.md":
                src = self._vault / "agnt-memory" / sys_file
                dst = sys_dir / "agnt-memory" / sys_file
            else:
                src = self._vault / "agnt-system" / "identity" / sys_file
                dst = sys_dir / "agnt-system" / "identity" / sys_file
            if src.exists():
                dst.parent.mkdir(parents=True, exist_ok=True)
                if not dst.exists() or self._file_hash(src) != self._file_hash(dst):
                    shutil.copy2(src, dst)
                    copied += 1

        for sys_d in SYSTEM_DIRS:
            src_dir = self._vault / sys_d
            if src_dir.is_dir():
                dst_dir = sys_dir / sys_d
                dst_dir.mkdir(parents=True, exist_ok=True)
                for f in src_dir.glob("*.md"):
                    dst = dst_dir / f.name
                    if not dst.exists() or self._file_hash(f) != self._file_hash(dst):
                        shutil.copy2(f, dst)
                        copied += 1

        # User content: sync both ways between vault folders and Obsidian root
        synced = 0
        for folder in self._sync_folders:
            v_dir = self._vault / folder
            e_dir = self._external / folder
            v_dir.mkdir(parents=True, exist_ok=True)
            e_dir.mkdir(parents=True, exist_ok=True)

            # Obsidian → vault (new files from Obsidian)
            for f in e_dir.glob("*.md"):
                vf = v_dir / f.name
                if not vf.exists():
                    shutil.copy2(f, vf)
                    synced += 1
                elif f.stat().st_mtime > vf.stat().st_mtime:
                    if self._file_hash(f) != self._file_hash(vf):
                        shutil.copy2(f, vf)
                        synced += 1

            # Vault → Obsidian (new files from AgntSpace)
            for f in v_dir.glob("*.md"):
                ef = e_dir / f.name
                if not ef.exists():
                    shutil.copy2(f, ef)
                    synced += 1
                elif f.stat().st_mtime > ef.stat().st_mtime:
                    if self._file_hash(f) != self._file_hash(ef):
                        shutil.copy2(f, ef)
                        synced += 1

        self._last_sync = datetime.now(UTC).isoformat()
        return {
            "mode": "obsidian-cli",
            "system_files_synced": copied,
            "content_synced": synced,
            "last_sync": self._last_sync,
        }

    @staticmethod
    def _has_obsidian_cli() -> bool:
        try:
            subprocess.run(
                ["obsidian-cli", "--version"],
                capture_output=True, timeout=5,
            )
            return True
        except (FileNotFoundError, subprocess.TimeoutExpired):
            return False

    @staticmethod
    def _file_hash(path: Path) -> str:
        return hashlib.md5(path.read_bytes()).hexdigest()
