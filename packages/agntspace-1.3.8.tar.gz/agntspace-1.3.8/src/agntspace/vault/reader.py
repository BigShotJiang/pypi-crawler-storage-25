"""Read markdown files from the vault with YAML frontmatter parsing."""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

import frontmatter


@dataclass
class VaultDocument:
    """A parsed markdown file from the vault."""

    path: Path
    metadata: dict = field(default_factory=dict)
    content: str = ""
    raw: str = ""


_IDENTITY_FILES = ("SOUL.md", "USER.md", "PROFILE.md", "CONTRACT.md", "TRUST.md")


class VaultReader:
    """Reads markdown files from the vault directory."""

    def __init__(self, vault_dir: Path) -> None:
        self._vault_dir = vault_dir

    @property
    def vault_dir(self) -> Path:
        return self._vault_dir

    def resolve_identity_path(self, filename: str) -> str:
        """Resolve an identity file path."""
        return f"agnt-system/identity/{filename}"

    def read(self, relative_path: str) -> VaultDocument:
        """Read a single vault file. Raises FileNotFoundError if missing."""
        path = self._vault_dir / relative_path
        if not path.is_file():
            raise FileNotFoundError(f"Vault file not found: {path}")
        raw = path.read_text(encoding="utf-8")
        post = frontmatter.loads(raw)
        return VaultDocument(
            path=path,
            metadata=dict(post.metadata),
            content=post.content,
            raw=raw,
        )

    def read_identity_files(self) -> dict[str, VaultDocument]:
        """Read the core identity files + MEMORY.

        Identity files (SOUL, USER, PROFILE, CONTRACT, TRUST) live in agnt-system/identity/.
        MEMORY.md lives in agnt-memory/.
        Returns a dict keyed by filename stem (e.g., 'SOUL', 'USER', 'MEMORY').
        """
        result: dict[str, VaultDocument] = {}
        for filename in _IDENTITY_FILES:
            path = self._vault_dir / "agnt-system" / "identity" / filename
            if path.is_file():
                result[path.stem] = self.read(f"agnt-system/identity/{filename}")

        # MEMORY.md lives in agnt-memory/
        mem_path = self._vault_dir / "agnt-memory" / "MEMORY.md"
        if mem_path.is_file():
            result["MEMORY"] = self.read("agnt-memory/MEMORY.md")

        return result

    def list_files(self, directory: str = "", pattern: str = "*.md") -> list[Path]:
        """List markdown files in a vault subdirectory."""
        base = self._vault_dir / directory if directory else self._vault_dir
        if not base.is_dir():
            return []
        return sorted(base.glob(pattern))

    def exists(self, relative_path: str) -> bool:
        """Check whether a vault file exists."""
        return (self._vault_dir / relative_path).is_file()
