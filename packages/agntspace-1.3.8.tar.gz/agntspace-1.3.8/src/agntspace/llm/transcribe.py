"""Audio transcription — converts voice messages to text.

Uses OpenAI Whisper API (cloud) or falls back to local whisper if available.
Provider-independent: the transcription result is just text.
"""

from __future__ import annotations

import base64
import logging
import tempfile
from pathlib import Path

log = logging.getLogger(__name__)


async def transcribe_audio(
    audio_base64: str,
    mimetype: str = "audio/ogg",
    api_key: str | None = None,
) -> str:
    """Transcribe base64-encoded audio to text.

    Tries OpenAI Whisper API first, falls back to local whisper.
    Returns the transcribed text, or an error message.
    """
    # Decode audio
    audio_bytes = base64.b64decode(audio_base64)

    # Determine file extension from mimetype
    ext_map = {
        "audio/ogg": ".ogg",
        "audio/ogg; codecs=opus": ".ogg",
        "audio/mpeg": ".mp3",
        "audio/mp4": ".m4a",
        "audio/wav": ".wav",
        "audio/webm": ".webm",
    }
    ext = ext_map.get(mimetype, ".ogg")

    # Write to temp file (APIs need a file)
    with tempfile.NamedTemporaryFile(suffix=ext, delete=False) as f:
        f.write(audio_bytes)
        temp_path = Path(f.name)

    try:
        # Try OpenAI Whisper API
        if api_key:
            try:
                return await _transcribe_openai(temp_path, api_key)
            except Exception as e:
                log.warning("OpenAI transcription failed: %s", e)

        # Try LiteLLM transcription (supports multiple providers)
        try:
            return await _transcribe_litellm(temp_path)
        except Exception as e:
            log.debug("LiteLLM transcription failed: %s", e)

        # Try local whisper
        try:
            return _transcribe_local(temp_path)
        except ImportError:
            pass
        except Exception as e:
            log.warning("Local whisper failed: %s", e)

        return "[Voice message received but could not be transcribed. No transcription service available.]"
    finally:
        temp_path.unlink(missing_ok=True)


async def _transcribe_openai(path: Path, api_key: str) -> str:
    """Transcribe using OpenAI Whisper API."""
    from openai import AsyncOpenAI

    client = AsyncOpenAI(api_key=api_key)
    with open(path, "rb") as f:
        response = await client.audio.transcriptions.create(
            model="whisper-1",
            file=f,
        )
    text = response.text.strip()
    log.info("Transcribed %s via OpenAI Whisper (%d chars)", path.suffix, len(text))
    return text


async def _transcribe_litellm(path: Path) -> str:
    """Transcribe using LiteLLM (routes to configured provider)."""
    import litellm

    with open(path, "rb") as f:
        response = await litellm.atranscription(
            model="whisper-1",
            file=f,
        )
    text = response.text.strip()
    log.info("Transcribed %s via LiteLLM (%d chars)", path.suffix, len(text))
    return text


def _transcribe_local(path: Path) -> str:
    """Transcribe using local whisper model."""
    import whisper

    model = whisper.load_model("base")
    result = model.transcribe(str(path))
    text = result["text"].strip()
    log.info("Transcribed %s locally via whisper (%d chars)", path.suffix, len(text))
    return text
