"""AgntSpace CLI — full command suite.

All commands that need a running server call the REST API over HTTP.
Lifecycle commands (init, start) run directly.
"""

from __future__ import annotations

import asyncio
import json
from pathlib import Path

import typer
from rich.console import Console
from rich.table import Table

app = typer.Typer(
    name="agntspace",
    help="Personal AI agent that runs your life alongside you.",
    no_args_is_help=True,
)
console = Console()


def _get_base_url() -> str:
    from agntspace.infra.config import get_settings
    s = get_settings()
    return f"http://{s.host}:{s.port}"


def _check_server(base_url: str) -> bool:
    import httpx
    try:
        httpx.get(f"{base_url}/api/health", timeout=3)
        return True
    except httpx.ConnectError:
        console.print(f"[red]Server not running at {base_url}[/red]")
        console.print("Start it with: [bold]agntspace start[/bold]")
        return False


def _get(path: str, params: dict | None = None, timeout: int = 10) -> dict | list:
    import httpx
    base = _get_base_url()
    resp = httpx.get(f"{base}{path}", params=params, timeout=timeout)
    resp.raise_for_status()
    return resp.json()


def _post(path: str, data: dict | None = None, timeout: int = 30) -> dict | list:
    import httpx
    base = _get_base_url()
    resp = httpx.post(f"{base}{path}", json=data, timeout=timeout)
    resp.raise_for_status()
    return resp.json()


def _put(path: str, data: dict | None = None, timeout: int = 10) -> dict | list:
    import httpx
    base = _get_base_url()
    resp = httpx.put(f"{base}{path}", json=data, timeout=timeout)
    resp.raise_for_status()
    return resp.json()


def _delete(path: str, timeout: int = 10) -> dict | list:
    import httpx
    base = _get_base_url()
    resp = httpx.delete(f"{base}{path}", timeout=timeout)
    resp.raise_for_status()
    return resp.json()


# ═══════════════════════════════════════════
# LIFECYCLE
# ═══════════════════════════════════════════


@app.command()
def init(
    minimal: bool = typer.Option(False, help="Non-interactive setup"),
    vault: str | None = typer.Option(None, help="Path to existing vault"),
    home: str | None = typer.Option(None, help="Override ~/agntspace/ location"),
) -> None:
    """Initialize ~/agntspace/ directory structure."""
    from agntspace.infra.logging import setup_logging
    from agntspace.setup.init import run_init
    setup_logging()
    home_path = run_init(home_dir=Path(home) if home else None, vault_path=Path(vault) if vault else None, minimal=minimal)
    console.print(f"\n[green]Initialized at {home_path}[/green]")
    console.print("Next: [bold]agntspace start[/bold]")


@app.command()
def start(
    host: str = typer.Option("127.0.0.1", help="Bind address"),
    port: int = typer.Option(8000, help="Port"),
    reload: bool = typer.Option(False, help="Auto-reload on code changes"),
) -> None:
    """Start the AgntSpace server."""
    import socket

    import uvicorn

    from agntspace.infra.config import get_settings
    settings = get_settings()
    if not settings.home_dir.exists():
        from agntspace.setup.init import run_init
        run_init(vault_dir=settings.root_dir, minimal=True)

    # Check port availability before starting
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        if s.connect_ex((host, port)) == 0:
            console.print(f"[bold red]Port {port} is already in use.[/] Stop the other process or use --port.")
            raise typer.Exit(1)

    from agntspace.api.routes.health import _get_version
    ver = _get_version()
    console.print(f"""
  [bold green]    _    ____ _   _ _____ [/][bold white] ____  ____   _    ____ _____ [/]
  [bold green]   / \\  / ___| \\ | |_   _|[/][bold white]/ ___||  _ \\ / \\  / ___| ____|[/]
  [bold green]  / _ \\| |  _|  \\| | | | [/][bold white] \\___ \\| |_) / _ \\| |   |  _|  [/]
  [bold green] / ___ | |_| | |\\  | | | [/][bold white]  ___) |  __/ ___ | |___| |___ [/]
  [bold green]/_/   \\_\\____|_| \\_| |_| [/][bold white] |____/|_| /_/   \\_\\____|_____|[/]  [dim]v{ver}[/]
""")
    console.print(f"  [dim]Server[/]  http://{host}:{port}")
    console.print(f"  [dim]Vault[/]   {settings.root_dir}")
    console.print()

    uvicorn.run("agntspace.main:create_app", factory=True, host=host, port=port, reload=reload, log_level="warning")


@app.command()
def status() -> None:
    """Show server status and key metrics."""
    base = _get_base_url()
    if not _check_server(base):
        return
    health = _get("/api/health")
    vault = _get("/api/vault/status")
    costs = _get("/api/costs/budget")
    agents = _get("/api/orchestrator/agents")
    projects = _get("/api/projects")

    console.print(f"\n[bold green]AgntSpace[/bold green] v{health.get('version', '?')} — {base}")
    console.print(f"  Onboarded: {'Yes' if vault.get('onboarded') else '[yellow]No[/yellow]'}")
    console.print(f"  Agents: {len(agents)}  |  Projects: {len(projects)}  |  Tasks: {vault.get('task_count', 0)}  |  Goals: {vault.get('goal_count', 0)}")
    console.print(f"  Today's cost: ${costs.get('daily_cost', 0):.2f} / ${costs.get('daily_budget', 10):.2f}")
    console.print()


@app.command()
def stop() -> None:
    """Stop the running AgntSpace server."""
    import os
    import signal
    import subprocess

    import httpx

    base = _get_base_url()
    try:
        httpx.get(f"{base}/api/health", timeout=2)
    except Exception:
        console.print("[yellow]Server not running.[/]")
        return

    from agntspace.infra.config import get_settings
    port = get_settings().port
    try:
        result = subprocess.run(["netstat", "-ano"], capture_output=True, text=True, timeout=5)
        for line in result.stdout.splitlines():
            if f":{port}" in line and "LISTENING" in line:
                pid = int(line.strip().split()[-1])
                os.kill(pid, signal.SIGTERM)
                console.print("[bold green]Stopped.[/]")
                return
        console.print("[yellow]Could not find server process.[/]")
    except Exception as e:
        console.print(f"[red]Failed to stop: {e}[/]")


# ═══════════════════════════════════════════
# CHAT
# ═══════════════════════════════════════════


@app.command()
def chat(
    message: str | None = typer.Argument(None, help="Single message (non-interactive)"),
) -> None:
    """Chat with the agent. Interactive if no message given."""
    import httpx
    base = _get_base_url()
    if not _check_server(base):
        raise typer.Exit(1)

    if message:
        data = _post("/api/chat", {"message": message})
        console.print(f"\n[bold green]Agent:[/bold green] {data.get('message', '')}\n")
        return

    async def _loop() -> None:
        async with httpx.AsyncClient(base_url=base, timeout=120) as client:
            conv_id: str | None = None
            console.print("[dim]Interactive chat. Type 'exit' to quit.[/dim]\n")
            while True:
                try:
                    user_input = console.input("[bold cyan]You:[/bold cyan] ")
                except (EOFError, KeyboardInterrupt):
                    break
                if user_input.strip().lower() in ("exit", "quit", "/quit"):
                    break
                if not user_input.strip():
                    continue
                try:
                    resp = await client.post("/api/chat", json={"message": user_input, "conversation_id": conv_id})
                    resp.raise_for_status()
                    data = resp.json()
                    conv_id = data["conversation_id"]
                    console.print(f"\n[bold green]Agent:[/bold green] {data['message']}\n")
                except httpx.HTTPError as e:
                    console.print(f"[red]Error: {e}[/red]")
    asyncio.run(_loop())


# ═══════════════════════════════════════════
# TASKS
# ═══════════════════════════════════════════


@app.command()
def tasks(
    status_filter: str | None = typer.Option(None, "--status", "-s", help="Filter by status"),
) -> None:
    """List tasks."""
    base = _get_base_url()
    if not _check_server(base):
        return
    params = {"status": status_filter} if status_filter else {}
    data = _get("/api/tasks", params)
    if not data:
        console.print("[dim]No tasks.[/dim]")
        return
    table = Table(title="Tasks")
    table.add_column("Title")
    table.add_column("Status")
    table.add_column("Mode")
    table.add_column("Domain")
    for t in data:
        table.add_row(t["title"], t["status"], t["mode"], t.get("domain", ""))
    console.print(table)


@app.command()
def delegate(
    description: str = typer.Argument(..., help="Task description"),
    mode: str = typer.Option("jdi", help="Mode: jdi, review, recommend, watch"),
) -> None:
    """Delegate a task to the agent."""
    base = _get_base_url()
    if not _check_server(base):
        raise typer.Exit(1)
    data = _post("/api/tasks", {"title": description[:80], "brief": description, "mode": mode})
    console.print(f"[green]Delegated:[/green] {data.get('path', '?')}")


# ═══════════════════════════════════════════
# PROJECTS
# ═══════════════════════════════════════════


@app.command()
def projects(
    status_filter: str | None = typer.Option(None, "--status", "-s", help="Filter by status"),
) -> None:
    """List projects."""
    base = _get_base_url()
    if not _check_server(base):
        return
    params = {"status": status_filter} if status_filter else {}
    data = _get("/api/projects", params)
    if not data:
        console.print("[dim]No projects.[/dim]")
        return
    table = Table(title="Projects")
    table.add_column("Title")
    table.add_column("Status")
    table.add_column("Target")
    table.add_column("Goals")
    table.add_column("Agents")
    for p in data:
        table.add_row(
            p["title"], p["status"], p.get("target_date", ""),
            ", ".join(p.get("related_goals", [])),
            ", ".join(p.get("assigned_agents", [])),
        )
    console.print(table)


@app.command(name="project-create")
def project_create(
    title: str = typer.Argument(..., help="Project title"),
    description: str = typer.Option("", help="Project description"),
) -> None:
    """Create a new project."""
    base = _get_base_url()
    if not _check_server(base):
        raise typer.Exit(1)
    data = _post("/api/projects", {"title": title, "description": description})
    console.print(f"[green]Created:[/green] {data.get('path', '?')}")


# ═══════════════════════════════════════════
# GOALS
# ═══════════════════════════════════════════


@app.command()
def goals() -> None:
    """List goals."""
    base = _get_base_url()
    if not _check_server(base):
        return
    data = _get("/api/goals")
    if not data:
        console.print("[dim]No goals.[/dim]")
        return
    table = Table(title="Goals")
    table.add_column("Title")
    table.add_column("Status")
    table.add_column("Type")
    table.add_column("Target Date")
    for g in data:
        table.add_row(g["title"], g["status"], g.get("type", ""), g.get("target_date", ""))
    console.print(table)


# ═══════════════════════════════════════════
# JOURNAL
# ═══════════════════════════════════════════


@app.command()
def journal(
    thought: str = typer.Argument(..., help="Quick thought to add"),
    section: str = typer.Option("Thoughts", help="Section: Focus, Thoughts, Decisions, Learnings, Reflections"),
) -> None:
    """Add a thought to today's journal."""
    base = _get_base_url()
    if not _check_server(base):
        raise typer.Exit(1)
    _post("/api/journal/append", {"text": thought, "section": section, "author": "HUMAN"})
    console.print(f"[green]Added to {section}.[/green]")


@app.command(name="journal-today")
def journal_today() -> None:
    """Show today's journal."""
    base = _get_base_url()
    if not _check_server(base):
        return
    data = _get("/api/journal/today")
    if data.get("content"):
        console.print(data["content"])
    else:
        console.print("[dim]No journal entry for today.[/dim]")


# ═══════════════════════════════════════════
# AGENTS
# ═══════════════════════════════════════════


@app.command()
def agents() -> None:
    """List subagents and their status."""
    base = _get_base_url()
    if not _check_server(base):
        return
    data = _get("/api/orchestrator/agents")
    table = Table(title="Subagents")
    table.add_column("Key")
    table.add_column("Name")
    table.add_column("Role")
    table.add_column("Status")
    table.add_column("Access")
    table.add_column("Skills")
    for a in data:
        table.add_row(a["key"], a["name"], a["role"], a["status"], a["access"], ", ".join(a.get("skills", [])))
    console.print(table)


@app.command(name="dispatch")
def dispatch_agent(
    agent: str = typer.Argument(..., help="Agent key (e.g. writer, researcher)"),
    task: str = typer.Argument(..., help="Task description"),
) -> None:
    """Dispatch a task to a specific subagent."""
    base = _get_base_url()
    if not _check_server(base):
        raise typer.Exit(1)
    data = _post("/api/orchestrator/dispatch", {"agent_name": agent, "task": task}, timeout=120)
    console.print(f"\n[bold green]{data.get('agent_name', agent)}:[/bold green] {data.get('content', '')}")
    console.print(f"\n[dim]{data.get('input_tokens', 0)} in + {data.get('output_tokens', 0)} out tokens[/dim]")


# ═══════════════════════════════════════════
# TRUST
# ═══════════════════════════════════════════


@app.command()
def trust(
    domain: str | None = typer.Option(None, help="Set level for this domain"),
    level: str | None = typer.Option(None, help="New level: Observer, Advisor, Assistant, Partner"),
) -> None:
    """Show or update trust levels."""
    base = _get_base_url()
    if not _check_server(base):
        return
    if domain and level:
        _put("/api/trust/level", {"domain": domain, "level": level})
        console.print(f"[green]{domain} → {level}[/green]")
        return
    data = _get("/api/trust")
    table = Table(title="Trust Levels")
    table.add_column("Domain")
    table.add_column("Level")
    table.add_column("Tasks")
    table.add_column("Good")
    table.add_column("Redo")
    for d in data.get("domains", []):
        table.add_row(d["domain"], d["level"], str(d["completed"]), str(d["good"]), str(d["redo"]))
    console.print(table)


# ═══════════════════════════════════════════
# WIKI
# ═══════════════════════════════════════════


@app.command()
def wiki(
    query: str | None = typer.Argument(None, help="Search query"),
) -> None:
    """Search wiki or show stats."""
    base = _get_base_url()
    if not _check_server(base):
        return
    if query:
        data = _get("/api/wiki/search", {"q": query})
        if not data:
            console.print(f"[dim]No results for '{query}'[/dim]")
            return
        for a in data[:10]:
            console.print(f"  [bold]{a.get('title', a['slug'])}[/bold] — {a.get('snippet', '')[:80]}")
        return
    stats = _get("/api/wiki/stats")
    console.print(f"Wiki: {stats.get('total_articles', 0)} articles, {stats.get('total_kbs', 0)} KBs")


@app.command(name="wiki-job")
def wiki_job(
    kb: str | None = typer.Option(None, help="KB slug (omit for all KBs)"),
) -> None:
    """Run the wiki pipeline (ingest, compile, lint)."""
    base = _get_base_url()
    if not _check_server(base):
        raise typer.Exit(1)
    console.print("[dim]Running wiki job...[/dim]")
    if kb:
        data = _post(f"/api/kb/{kb}/job", timeout=300)
    else:
        data = _post("/api/kb/job/all", timeout=300)
    console.print(f"[green]Done.[/green] {json.dumps(data, indent=2)[:500]}")


@app.command(name="kb-create")
def kb_create(
    topic: str = typer.Argument(..., help="Name/topic for the knowledge base"),
    description: str = typer.Option("", help="What this KB is about"),
    questions: list[str] = typer.Option([], "--question", "-q", help="Focus questions (repeat for multiple)"),
    source_types: list[str] = typer.Option([], "--source-type", "-s", help="Expected source types (repeat for multiple)"),
    notes: str = typer.Option("", help="Agent instructions for this domain"),
) -> None:
    """Create a new dedicated knowledge base."""
    base = _get_base_url()
    if not _check_server(base):
        raise typer.Exit(1)
    data = _post("/api/kb", {
        "topic": topic,
        "description": description,
        "focus_questions": questions,
        "source_types": source_types,
        "notes": notes,
    })
    console.print(f"[green]Created KB:[/green] {data.get('topic', topic)}")
    console.print(f"  Slug: [bold]{data.get('slug')}[/bold]")
    console.print(f"  Path: [dim]{data.get('path')}[/dim]")
    console.print(f"\n  Drop files into [bold]{data.get('path')}/inbox/[/bold] and run [bold]agntspace wiki-job --kb {data.get('slug')}[/bold]")


# ═══════════════════════════════════════════
# MEMORY
# ═══════════════════════════════════════════


@app.command()
def memory(
    generate: bool = typer.Option(False, help="Generate today's memory"),
    compact: bool = typer.Option(False, help="Run temporal compaction"),
) -> None:
    """Show permanent memory, or generate/compact."""
    base = _get_base_url()
    if not _check_server(base):
        return
    if generate:
        data = _post("/api/memory/generate", timeout=120)
        console.print(f"[green]Generated:[/green] {data.get('path', '?')}")
        return
    if compact:
        data = _post("/api/memory/compact", timeout=120)
        console.print(f"[green]Compacted.[/green] {data.get('status', '')}")
        return
    data = _get("/api/memory/permanent/read")
    if data.get("content"):
        console.print(data["content"])
    else:
        console.print("[dim]No permanent memory yet.[/dim]")


# ═══════════════════════════════════════════
# COSTS
# ═══════════════════════════════════════════


@app.command()
def costs(
    days: int = typer.Option(7, help="Period in days"),
) -> None:
    """Show cost tracking summary."""
    base = _get_base_url()
    if not _check_server(base):
        return
    data = _get("/api/costs", {"days": days})
    budget = _get("/api/costs/budget")
    console.print(f"\n[bold]Cost Summary ({days} days)[/bold]")
    console.print(f"  Total: ${data.get('total_cost', 0):.2f}  |  Requests: {data.get('total_requests', 0)}")
    console.print(f"  Today: ${budget.get('daily_cost', 0):.2f} / ${budget.get('daily_budget', 10):.2f}")
    console.print(f"  Month: ${budget.get('monthly_cost', 0):.2f} / ${budget.get('monthly_budget', 100):.2f}")
    by_model = data.get("by_model", {})
    if by_model:
        console.print("\n  By model:")
        for model, info in by_model.items():
            console.print(f"    {model}: ${info['cost']:.2f} ({info['requests']} calls)")
    console.print()


# ═══════════════════════════════════════════
# CONTRACT
# ═══════════════════════════════════════════


@app.command()
def contract() -> None:
    """Show contract permissions summary."""
    base = _get_base_url()
    if not _check_server(base):
        return
    data = _get("/api/contract/structured")
    perms = data.get("permissions", {})
    settings = data.get("settings", {})
    console.print("\n[bold]Contract[/bold]")
    console.print(f"  Privacy: {settings.get('privacy_mode', '?')}  |  Proactivity: {settings.get('proactivity', '?')}")
    console.print(f"  Allowed: {len(perms.get('allow', []))}  |  Confirm: {len(perms.get('confirm', []))}  |  Blocked: {len(perms.get('block', []))}")
    if perms.get("block"):
        console.print(f"  Blocked: {', '.join(perms['block'])}")
    console.print()


# ═══════════════════════════════════════════
# SEARCH
# ═══════════════════════════════════════════


@app.command()
def search(
    query: str = typer.Argument(..., help="Search query"),
    limit: int = typer.Option(10, help="Max results"),
) -> None:
    """Search the vault."""
    base = _get_base_url()
    if not _check_server(base):
        return
    data = _get("/api/search", {"q": query, "limit": limit})
    if not data:
        console.print(f"[dim]No results for '{query}'[/dim]")
        return
    for r in data:
        console.print(f"  [bold]{r.get('title', r.get('path', '?'))}[/bold]")
        if r.get("snippet"):
            console.print(f"    {r['snippet'][:100]}")


# ═══════════════════════════════════════════
# EMERGENCY
# ═══════════════════════════════════════════


@app.command(name="emergency-stop")
def emergency_stop() -> None:
    """Halt all agent activity immediately."""
    base = _get_base_url()
    if not _check_server(base):
        raise typer.Exit(1)
    _post("/api/emergency-stop")
    console.print("[red bold]AGENT FROZEN — all activity halted.[/red bold]")


@app.command()
def resume() -> None:
    """Resume agent after emergency stop."""
    base = _get_base_url()
    if not _check_server(base):
        raise typer.Exit(1)
    _post("/api/resume")
    console.print("[green]Agent resumed.[/green]")


# ═══════════════════════════════════════════
# UTILITIES
# ═══════════════════════════════════════════


@app.command()
def forget(
    topic: str = typer.Argument(..., help="Topic to purge from search index"),
) -> None:
    """Purge a topic from the search index."""
    base = _get_base_url()
    if not _check_server(base):
        raise typer.Exit(1)
    results = _get("/api/search", {"q": topic, "limit": 20})
    console.print(f"Found {len(results)} matching files.")
    _post("/api/search/reindex", timeout=30)
    console.print("[green]Search index rebuilt.[/green]")


@app.command()
def reindex() -> None:
    """Rebuild the vault search index."""
    base = _get_base_url()
    if not _check_server(base):
        raise typer.Exit(1)
    data = _post("/api/search/reindex", timeout=60)
    console.print(f"[green]Reindexed {data.get('indexed', 0)} files.[/green]")


@app.command()
def export(
    output: str = typer.Option("agntspace-export.tar.gz", help="Output file"),
) -> None:
    """Export all user data as a portable archive."""
    import shutil

    from agntspace.infra.config import get_settings
    settings = get_settings()
    if not settings.home_dir.exists():
        console.print("[red]Nothing to export.[/red]")
        raise typer.Exit(1)
    output_path = Path(output).with_suffix("")
    shutil.make_archive(str(output_path), "gztar", str(settings.home_dir.parent), settings.home_dir.name)
    console.print(f"[green]Exported to {output_path.with_suffix('.tar.gz')}[/green]")


@app.command()
def audit(
    today: bool = typer.Option(False, help="Only today's entries"),
    limit: int = typer.Option(20, help="Max entries"),
) -> None:
    """Show audit log."""
    base = _get_base_url()
    if not _check_server(base):
        return
    endpoint = "/api/audit/today" if today else f"/api/audit?limit={limit}"
    entries = _get(endpoint)
    if not entries:
        console.print("[dim]No audit entries.[/dim]")
        return
    table = Table(title="Audit Trail")
    table.add_column("Time", style="dim")
    table.add_column("Action")
    table.add_column("Target")
    table.add_column("Approved")
    for e in entries:
        table.add_row(e.get("ts", "")[:19], e.get("action", ""), e.get("target", ""), e.get("approved", ""))
    console.print(table)


@app.command()
def autopilot(
    on: bool = typer.Option(False, help="Enable"),
    off: bool = typer.Option(False, help="Disable"),
) -> None:
    """Enable/disable/check autopilot."""
    base = _get_base_url()
    if not _check_server(base):
        return
    if on:
        _post("/api/autopilot", {"enabled": True})
        console.print("[green]Autopilot ON[/green]")
    elif off:
        _post("/api/autopilot", {"enabled": False})
        console.print("[green]Autopilot OFF[/green]")
    else:
        data = _get("/api/autopilot")
        console.print(f"Autopilot: {'[green]ON[/green]' if data.get('enabled') else '[red]OFF[/red]'}")


@app.command(name="obsidian")
def obsidian_cmd(
    path: str = typer.Argument(..., help="Path to Obsidian vault"),
) -> None:
    """Connect to an Obsidian vault (direct mode)."""
    from agntspace.infra.config import get_settings
    from agntspace.vault.sync import VaultSync
    obs_path = Path(path).expanduser().resolve()
    if not obs_path.is_dir():
        console.print(f"[red]Path does not exist: {obs_path}[/red]")
        raise typer.Exit(1)
    settings = get_settings()
    sync = VaultSync(vault_dir=settings.vault_dir)
    result = sync.adopt_obsidian_vault(str(obs_path))
    if "error" in result:
        console.print(f"[red]{result['error']}[/red]")
        raise typer.Exit(1)
    console.print(f"[green]Connected to {obs_path}[/green]")
    from agntspace.infra.settings_service import SettingsService
    svc = SettingsService(settings.config_path)
    svc.update_section("sync", {"mode": "direct", "external_path": str(obs_path)})
    console.print("[green]Config updated. Restart server to apply.[/green]")


@app.command(name="install-daemon")
def install_daemon_cmd(host: str = typer.Option("127.0.0.1"), port: int = typer.Option(8000)) -> None:
    """Install as a system service."""
    from agntspace.automation.daemon import install_daemon
    console.print(install_daemon(host=host, port=port))


@app.command(name="uninstall-daemon")
def uninstall_daemon_cmd() -> None:
    """Remove system service."""
    from agntspace.automation.daemon import uninstall_daemon
    console.print(uninstall_daemon())


@app.command(name="daemon-status")
def daemon_status_cmd() -> None:
    """Check daemon status."""
    from agntspace.automation.daemon import daemon_status
    info = daemon_status()
    console.print(f"Installed: {'Yes' if info['installed'] else 'No'}  |  Running: {'Yes' if info['running'] else 'No'}")


# ═══════════════════════════════════════════
# ADDITIONAL COMMANDS
# ═══════════════════════════════════════════


@app.command()
def restart(
    host: str = typer.Option("127.0.0.1", help="Bind address"),
    port: int = typer.Option(8000, help="Port"),
) -> None:
    """Stop and restart the AgntSpace server."""
    import subprocess
    import time
    # Stop first
    stop()
    time.sleep(2)
    # Start in a new process
    subprocess.Popen(
        ["agntspace", "start", "--host", host, "--port", str(port)],
        creationflags=subprocess.CREATE_NEW_CONSOLE if hasattr(subprocess, "CREATE_NEW_CONSOLE") else 0,
    )
    console.print("[green]Restarting in new window...[/green]")


@app.command()
def version() -> None:
    """Show AgntSpace version."""
    from agntspace.api.routes.health import _get_version
    console.print(f"AgntSpace v{_get_version()}")


@app.command()
def graph(
    entity: str | None = typer.Argument(None, help="Entity to look up"),
    path_to: str | None = typer.Option(None, "--path-to", help="Find path to another entity"),
) -> None:
    """Query the knowledge graph."""
    base = _get_base_url()
    if not _check_server(base):
        return
    if entity and path_to:
        data = _get(f"/api/graph/path/{entity}/{path_to}")
        paths = data.get("paths", [])
        if not paths:
            console.print(f"[dim]No path between {entity} and {path_to}[/dim]")
            return
        for p in paths:
            console.print(" -> ".join(p))
        return
    if entity:
        data = _get(f"/api/graph/entity/{entity}/triples")
        if not data.get("found"):
            console.print(f"[dim]No data for '{entity}'[/dim]")
            return
        ent = data.get("entity", {})
        console.print(f"\n[bold]{ent.get('name', entity)}[/bold] ({ent.get('type', '?')})")
        for pred, facts in data.get("facts", {}).items():
            for f in facts:
                console.print(f"  {pred}: {f.get('value', '?')}  [dim]({f.get('authority', '?')})[/dim]")
        console.print()
        return
    # No args — show stats
    stats = _get("/api/graph/stats")
    console.print(f"\n[bold]Knowledge Graph[/bold]")
    console.print(f"  Nodes: {stats.get('total_nodes', 0)}  |  Edges: {stats.get('total_edges', 0)}")
    console.print(f"  Wiki entities: {stats.get('wiki_entities', 0)}  |  Files: {stats.get('files', 0)}")
    console.print(f"  Wikilink edges: {stats.get('wikilink_edges', 0)}  |  SPO edges: {stats.get('spo_edges', 0)}")
    console.print()


@app.command()
def workflow(
    workflow_id: str = typer.Argument(..., help="Workflow ID (e.g. wiki-management, daily-cycle)"),
    context: str = typer.Option("", help="Additional context for the workflow"),
) -> None:
    """Run a supervisor-driven workflow."""
    base = _get_base_url()
    if not _check_server(base):
        raise typer.Exit(1)
    console.print(f"[dim]Running workflow: {workflow_id}...[/dim]")
    data = _post(f"/api/orchestrator/workflow/{workflow_id}", {"context": context} if context else None, timeout=300)
    console.print(f"[green]Done.[/green] Status: {data.get('status', '?')}")
    steps = data.get("steps_completed", [])
    if steps:
        for s in steps:
            console.print(f"  {s}")
    console.print()


@app.command()
def scrape(
    url: str = typer.Argument(..., help="URL to scrape"),
    kb: str = typer.Option("general", help="Target KB slug"),
    filename: str | None = typer.Option(None, help="Custom filename"),
) -> None:
    """Scrape a URL into a knowledge base."""
    base = _get_base_url()
    if not _check_server(base):
        raise typer.Exit(1)
    console.print(f"[dim]Scraping {url}...[/dim]")
    payload: dict = {"url": url}
    if filename:
        payload["filename"] = filename
    data = _post(f"/api/kb/{kb}/scrape", payload, timeout=60)
    console.print(f"[green]Saved:[/green] {data.get('path', data.get('filename', '?'))}")


@app.command()
def heartbeat(
    limit: int = typer.Option(20, help="Number of recent pulses"),
) -> None:
    """Show recent heartbeat pulses."""
    base = _get_base_url()
    if not _check_server(base):
        return
    data = _get("/api/heartbeat/history", {"limit": limit})
    pulses = data if isinstance(data, list) else data.get("pulses", [])
    if not pulses:
        console.print("[dim]No heartbeat data.[/dim]")
        return
    table = Table(title="Heartbeat")
    table.add_column("Time", style="dim")
    table.add_column("Type")
    table.add_column("Status")
    table.add_column("Tasks")
    for p in pulses[-limit:]:
        table.add_row(
            p.get("ts", "")[:19],
            p.get("pulse_type", ""),
            p.get("status", ""),
            str(p.get("active_tasks", 0)),
        )
    console.print(table)


@app.command()
def plugins() -> None:
    """List plugins and their status."""
    base = _get_base_url()
    if not _check_server(base):
        return
    data = _get("/api/plugins")
    items = data.get("plugins", []) if isinstance(data, dict) else data
    if not items:
        console.print("[dim]No plugins installed.[/dim]")
        return
    table = Table(title="Plugins")
    table.add_column("Name")
    table.add_column("Version")
    table.add_column("Enabled")
    table.add_column("Tools")
    for p in items:
        tools = p.get("provides", {}).get("tools", [])
        table.add_row(
            p.get("title", p.get("name", "?")),
            p.get("version", "?"),
            "[green]Yes[/green]" if p.get("enabled") else "[red]No[/red]",
            str(len(tools)),
        )
    console.print(table)


@app.command()
def channels() -> None:
    """List messaging channels and connection status."""
    base = _get_base_url()
    if not _check_server(base):
        return
    data = _get("/api/channels")
    ch_list = data if isinstance(data, list) else data.get("channels", [])
    if not ch_list:
        console.print("[dim]No channels configured.[/dim]")
        return
    table = Table(title="Channels")
    table.add_column("Channel")
    table.add_column("Status")
    for ch in ch_list:
        name = ch.get("name", "?")
        connected = ch.get("connected", False)
        status_str = "[green]Connected[/green]" if connected else "[dim]Disconnected[/dim]"
        table.add_row(name, status_str)
    console.print(table)


if __name__ == "__main__":
    app()
