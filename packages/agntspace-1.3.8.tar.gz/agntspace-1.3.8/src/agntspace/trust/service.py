"""Trust evolution engine: updates domain trust from task feedback."""

from __future__ import annotations

import logging
from datetime import UTC, datetime

from agntspace.vault.reader import VaultReader
from agntspace.vault.writer import VaultWriter

log = logging.getLogger(__name__)

TRUST_LEVELS = ("Observer", "Advisor", "Assistant", "Partner")
PROMOTE_THRESHOLD = 5  # consecutive good ratings to promote
DEMOTE_THRESHOLD = 2  # redo ratings within last 10 to demote


class TrustService:
    """Manages trust scores in vault/TRUST.md."""

    def __init__(self, vault_reader: VaultReader, vault_writer: VaultWriter) -> None:
        self._reader = vault_reader
        self._writer = vault_writer

    def _trust_path(self) -> str:
        """Resolve TRUST.md path."""
        return self._reader.resolve_identity_path("TRUST.md")

    def get_trust_data(self) -> list[dict]:
        """Parse trust.md into structured data."""
        path = self._trust_path()
        if not self._reader.exists(path):
            return []

        doc = self._reader.read(path)
        return self._parse_trust_table(doc.content)

    def get_domain_trust(self, domain: str) -> dict | None:
        """Get trust data for a specific domain."""
        for row in self.get_trust_data():
            if row["domain"].lower() == domain.lower():
                return row
        return None

    def record_feedback(self, domain: str, rating: str) -> dict:
        """Record task feedback and update trust score.

        Returns dict with domain, old_level, new_level, and whether it changed.
        """
        rows = self.get_trust_data()
        target = None
        for row in rows:
            if row["domain"].lower() == domain.lower():
                target = row
                break

        if not target:
            # Domain not in trust.md — add it
            target = {
                "domain": domain,
                "level": "Advisor",
                "completed": 0,
                "good": 0,
                "needs_improvement": 0,
                "redo": 0,
            }
            rows.append(target)

        old_level = target["level"]

        # Update counts
        target["completed"] += 1
        if rating == "good":
            target["good"] += 1
        elif rating == "needs_improvement":
            target["needs_improvement"] += 1
        elif rating == "redo":
            target["redo"] += 1

        # Check promotion: 5 consecutive good
        new_level = old_level
        if target["good"] >= PROMOTE_THRESHOLD and target["redo"] == 0:
            level_idx = TRUST_LEVELS.index(old_level) if old_level in TRUST_LEVELS else 1
            if level_idx < len(TRUST_LEVELS) - 1:
                new_level = TRUST_LEVELS[level_idx + 1]
                # Reset counters after promotion
                target["good"] = 0

        # Check demotion: 2 redo in last 10 tasks
        if target["completed"] >= 3 and target["redo"] >= DEMOTE_THRESHOLD:
            level_idx = TRUST_LEVELS.index(old_level) if old_level in TRUST_LEVELS else 1
            if level_idx > 0:
                new_level = TRUST_LEVELS[level_idx - 1]
                # Reset redo counter after demotion
                target["redo"] = 0

        target["level"] = new_level

        # Write back
        self._write_trust_table(rows)

        # Log trust change events for memory synthesis
        if old_level != new_level:
            direction = "promoted" if TRUST_LEVELS.index(new_level) > TRUST_LEVELS.index(old_level) else "demoted"
            change_line = f"- {datetime.now(UTC).strftime('%Y-%m-%d %H:%M')} | {domain} {direction}: {old_level} → {new_level}\n"
            try:
                change_path = "agnt-system/identity/trust-changes.md"
                if not self._reader.exists(change_path):
                    self._writer.write(change_path, f"# Trust Change Log\n\n{change_line}")
                else:
                    self._writer.append(change_path, change_line)
                log.info("Trust %s: %s %s → %s", direction, domain, old_level, new_level)
            except Exception:
                log.debug("Failed to log trust change", exc_info=True)

        return {
            "domain": domain,
            "old_level": old_level,
            "new_level": new_level,
            "changed": old_level != new_level,
        }

    def get_recent_changes(self, since_date: str = "") -> list[str]:
        """Get trust change events since a date (YYYY-MM-DD)."""
        change_path = "agnt-system/identity/trust-changes.md"
        if not self._reader.exists(change_path):
            return []
        try:
            doc = self._reader.read(change_path)
            lines = [l.strip() for l in doc.content.split("\n") if l.strip().startswith("- ")]
            if since_date:
                lines = [l for l in lines if l.split("|")[0].strip("- ").strip() >= since_date]
            return lines
        except Exception:
            return []

    def _parse_trust_table(self, content: str) -> list[dict]:
        """Parse the markdown trust table into structured data."""
        rows = []
        # Find table rows (skip header and separator)
        table_lines = [
            line.strip()
            for line in content.split("\n")
            if line.strip().startswith("|") and "---" not in line and "Domain" not in line
        ]

        for line in table_lines:
            cells = [c.strip() for c in line.split("|")[1:-1]]
            if len(cells) >= 6:
                rows.append({
                    "domain": cells[0],
                    "level": cells[1],
                    "completed": self._parse_int(cells[2]),
                    "good": self._parse_int(cells[3]),
                    "needs_improvement": self._parse_int(cells[4]),
                    "redo": self._parse_int(cells[5]),
                })
        return rows

    def _write_trust_table(self, rows: list[dict]) -> None:
        """Write trust data back to trust.md as a markdown table."""
        now = datetime.now(UTC).strftime("%Y-%m-%d")
        lines = [
            "---",
            'title: "Trust Scores"',
            "description: Domain-specific trust levels, evolved from task outcomes",
            f"updated: {now}",
            "---",
            "",
            "| Domain | Trust Level | Tasks Completed | Good | Needs Improvement | Redo |",
            "|--------|------------|----------------|------|-------------------|------|",
        ]

        for row in rows:
            lines.append(
                f"| {row['domain']} "
                f"| {row['level']} "
                f"| {row['completed']} "
                f"| {row['good']} "
                f"| {row['needs_improvement']} "
                f"| {row['redo']} |"
            )

        lines.extend([
            "",
            "## How Trust Changes",
            "",
            f"- **Promote:** {PROMOTE_THRESHOLD} consecutive good ratings",
            f"- **Demote:** {DEMOTE_THRESHOLD} redo ratings within recent tasks",
            "- **No change:** needs_improvement (preference learned, trust stays)",
            "",
            "## Trust Levels",
            "",
            "- **Observer:** Agent will not act without explicit instruction",
            "- **Advisor:** Agent suggests but does not execute",
            "- **Assistant:** Agent executes routine tasks, asks for non-routine",
            "- **Partner:** Agent has full autonomy within contract boundaries",
        ])

        self._writer.write("agnt-system/identity/TRUST.md", "\n".join(lines))

    @staticmethod
    def _parse_int(s: str) -> int:
        try:
            return int(s.strip())
        except (ValueError, AttributeError):
            return 0
