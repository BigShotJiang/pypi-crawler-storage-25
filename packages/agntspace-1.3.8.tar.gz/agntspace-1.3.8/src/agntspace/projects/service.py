"""Project service: container for tasks, goals, subagents, and knowledge."""

from __future__ import annotations

import re
from datetime import UTC, datetime

from agntspace.vault.reader import VaultDocument, VaultReader
from agntspace.vault.writer import VaultWriter

STATUSES = ("active", "on_hold", "completed", "archived")

_PROJECT_TEMPLATE = """---
title: "{title}"
status: active
created: "{created}"
target_date: "{target_date}"
related_goals: {goals_yaml}
assigned_agents: {agents_yaml}
linked_kbs: {kbs_yaml}
---

## Description

{description}

## Milestones


## Log
- {timestamp} — Project created.
"""


class ProjectService:
    """Manages project files in vault/projects/."""

    def __init__(self, vault_reader: VaultReader, vault_writer: VaultWriter) -> None:
        self._reader = vault_reader
        self._writer = vault_writer

    def create_project(
        self,
        title: str,
        description: str = "",
        target_date: str = "",
        related_goals: list[str] | None = None,
        assigned_agents: list[str] | None = None,
        linked_kbs: list[str] | None = None,
    ) -> str:
        """Create a new project. Returns the relative vault path."""
        slug = self._slugify(title)
        path = f"projects/{slug}/PROJECT.md"
        now = datetime.now(UTC)
        content = _PROJECT_TEMPLATE.format(
            title=title,
            created=now.strftime("%Y-%m-%d"),
            target_date=target_date,
            goals_yaml=self._to_yaml_list(related_goals),
            agents_yaml=self._to_yaml_list(assigned_agents),
            kbs_yaml=self._to_yaml_list(linked_kbs),
            description=description or "No description yet.",
            timestamp=now.strftime("%Y-%m-%d %H:%M"),
        )
        self._writer.write(path, content)
        # Create sub-directories
        for sub in ("tasks", "notes", "output"):
            gitkeep = f"projects/{slug}/{sub}/.gitkeep"
            self._writer.write(gitkeep, "")
        return path

    def get_project(self, slug: str) -> VaultDocument | None:
        """Get a project by slug."""
        path = f"projects/{slug}/PROJECT.md"
        if not self._reader.exists(path):
            return None
        return self._reader.read(path)

    def list_projects(self, status_filter: str | None = None) -> list[dict]:
        """List all projects, optionally filtered by status."""
        projects_dir = self._reader._vault_dir / "projects"  # noqa: SLF001
        if not projects_dir.is_dir():
            return []

        results = []
        for child in sorted(projects_dir.iterdir()):
            if not child.is_dir():
                continue
            project_file = child / "PROJECT.md"
            if not project_file.is_file():
                continue
            slug = child.name
            doc = self._reader.read(f"projects/{slug}/PROJECT.md")
            meta = doc.metadata
            status = meta.get("status", "active")
            if status_filter and status != status_filter:
                continue
            results.append({
                "slug": slug,
                "title": meta.get("title", slug),
                "status": status,
                "created": meta.get("created", ""),
                "target_date": meta.get("target_date", ""),
                "related_goals": meta.get("related_goals", []) or [],
                "assigned_agents": meta.get("assigned_agents", []) or [],
                "linked_kbs": meta.get("linked_kbs", []) or [],
            })
        return results

    def update_status(self, slug: str, new_status: str) -> None:
        """Update a project's status."""
        if new_status not in STATUSES:
            raise ValueError(f"Invalid status: {new_status}")
        self._update_metadata(slug, "status", new_status)
        self._append_log(slug, f"Status changed to {new_status}.")

    def update_project(
        self,
        slug: str,
        title: str | None = None,
        description: str | None = None,
        target_date: str | None = None,
        related_goals: list[str] | None = None,
        assigned_agents: list[str] | None = None,
        linked_kbs: list[str] | None = None,
    ) -> None:
        """Update project fields."""
        path = f"projects/{slug}/PROJECT.md"
        doc = self._reader.read(path)
        content = doc.raw

        if title is not None:
            content = re.sub(
                r'^title:\s*".*"', f'title: "{title}"', content,
                count=1, flags=re.MULTILINE,
            )
        if target_date is not None:
            content = re.sub(
                r'^target_date:\s*".*"', f'target_date: "{target_date}"', content,
                count=1, flags=re.MULTILINE,
            )
        if description is not None:
            content = re.sub(
                r"(## Description\n\n)(.*?)(\n\n## )",
                rf"\g<1>{description}\n\n## ",
                content,
                count=1,
                flags=re.DOTALL,
            )
        if related_goals is not None:
            content = re.sub(
                r"^related_goals:\s*.*$",
                f"related_goals: {self._to_yaml_list(related_goals)}",
                content, count=1, flags=re.MULTILINE,
            )
        if assigned_agents is not None:
            content = re.sub(
                r"^assigned_agents:\s*.*$",
                f"assigned_agents: {self._to_yaml_list(assigned_agents)}",
                content, count=1, flags=re.MULTILINE,
            )
        if linked_kbs is not None:
            content = re.sub(
                r"^linked_kbs:\s*.*$",
                f"linked_kbs: {self._to_yaml_list(linked_kbs)}",
                content, count=1, flags=re.MULTILINE,
            )

        self._writer.write(path, content)

    def add_milestone(self, slug: str, milestone: str) -> None:
        """Add a milestone to the project."""
        path = f"projects/{slug}/PROJECT.md"
        doc = self._reader.read(path)
        content = doc.raw
        now = datetime.now(UTC).strftime("%Y-%m-%d")
        line = f"- [ ] {milestone} (added {now})"

        match = re.search(r"(## Milestones\n(?:.*\n)*?)((?=\n## )|\Z)", content)
        if match:
            insert_at = match.end(1)
            content = content[:insert_at] + line + "\n" + content[insert_at:]
        else:
            content += f"\n## Milestones\n{line}\n"

        self._writer.write(path, content)
        self._append_log(slug, f"Milestone added: {milestone}")

    def add_log(self, slug: str, note: str) -> None:
        """Add a log entry."""
        self._append_log(slug, note)

    def get_project_detail(self, slug: str) -> dict | None:
        """Get full project detail including content sections."""
        doc = self.get_project(slug)
        if not doc:
            return None
        meta = doc.metadata
        return {
            "slug": slug,
            "title": meta.get("title", slug),
            "status": meta.get("status", "active"),
            "created": meta.get("created", ""),
            "target_date": meta.get("target_date", ""),
            "related_goals": meta.get("related_goals", []) or [],
            "assigned_agents": meta.get("assigned_agents", []) or [],
            "linked_kbs": meta.get("linked_kbs", []) or [],
            "description": self._extract_section(doc.content, "Description"),
            "milestones": self._extract_section(doc.content, "Milestones"),
            "log": self._extract_section(doc.content, "Log"),
        }

    def delete_project(self, slug: str) -> None:
        """Delete a project directory and clean up KB wiki project pages."""
        import shutil

        vault_dir = self._reader._vault_dir  # noqa: SLF001

        # Clean up wiki/projects/{slug}/ in all KBs that may have project pages
        agnt_kb_dir = vault_dir / "agnt-kb"
        if agnt_kb_dir.is_dir():
            for kb_dir in agnt_kb_dir.iterdir():
                if not kb_dir.is_dir():
                    continue
                project_wiki_dir = kb_dir / "wiki" / "projects" / slug
                if project_wiki_dir.is_dir():
                    shutil.rmtree(project_wiki_dir)

        projects_dir = vault_dir / "projects" / slug
        if projects_dir.is_dir():
            shutil.rmtree(projects_dir)

    # ── Internal ──

    def _update_metadata(self, slug: str, key: str, value: str) -> None:
        path = f"projects/{slug}/PROJECT.md"
        doc = self._reader.read(path)
        content = re.sub(
            rf"^{re.escape(key)}:\s*.*$",
            f"{key}: {value}",
            doc.raw, count=1, flags=re.MULTILINE,
        )
        self._writer.write(path, content)

    def _append_log(self, slug: str, note: str) -> None:
        path = f"projects/{slug}/PROJECT.md"
        doc = self._reader.read(path)
        content = doc.raw
        timestamp = datetime.now(UTC).strftime("%Y-%m-%d %H:%M")
        line = f"- {timestamp} — {note}"

        match = re.search(r"(## Log\n(?:.*\n)*?)((?=\n## )|\Z)", content)
        if match:
            insert_at = match.end(1)
            content = content[:insert_at] + line + "\n" + content[insert_at:]
        else:
            content += f"\n## Log\n{line}\n"

        self._writer.write(path, content)

    @staticmethod
    def _extract_section(content: str, heading: str) -> str:
        pattern = rf"## {re.escape(heading)}\n(.*?)(?=^## |\Z)"
        match = re.search(pattern, content, re.DOTALL | re.MULTILINE)
        return match.group(1).strip() if match else ""

    @staticmethod
    def _slugify(text: str) -> str:
        slug = text.lower().strip()
        slug = re.sub(r"[^\w\s-]", "", slug)
        slug = re.sub(r"[\s_]+", "-", slug)
        slug = re.sub(r"-+", "-", slug)
        return slug[:60].strip("-")

    @staticmethod
    def _to_yaml_list(items: list[str] | None) -> str:
        if not items:
            return "[]"
        return "[" + ", ".join(f'"{i}"' for i in items) + "]"
