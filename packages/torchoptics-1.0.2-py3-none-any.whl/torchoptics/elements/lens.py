"""Lens element definitions."""

import torch
from torch import Tensor

from ..profiles import circle, cylindrical_lens_phase, lens_phase
from ..types import Scalar, Vector2
from .elements import PolychromaticModulationElement


class Lens(PolychromaticModulationElement):
    r"""Lens element.

    Represents a thin lens with the following modulation profile:

    .. math::
        \mathcal{M}(x, y) = \exp\left(-i \frac{\pi}{\lambda f} (x^2 + y^2) \right)

    where:
        - :math:`\lambda` is the wavelength of the light, and
        - :math:`f` is the focal length of the lens.

    Args:
        shape (Vector2): Number of grid points along the planar dimensions.
        focal_length (Scalar): Focal length of the lens.
        z (Scalar): Position along the z-axis. Default: `0`.
        spacing (Vector2 | None): Distance between grid points along planar dimensions. Default: if
            `None`, uses a global default (see :meth:`torchoptics.set_default_spacing()`).
        offset (Vector2 | None): Center coordinates of the plane. Default: `(0, 0)`.

    """

    focal_length: Tensor

    def __init__(
        self,
        shape: Vector2,
        focal_length: Scalar,
        z: Scalar = 0,
        spacing: Vector2 | None = None,
        offset: Vector2 | None = None,
    ) -> None:
        """Initialize the Lens."""
        super().__init__(shape, z, spacing, offset)
        self.register_optics_property("focal_length", focal_length, is_scalar=True)

    def modulation_profile(self, wavelength: Scalar | None = None) -> Tensor:
        """Return the modulation profile."""
        phase = lens_phase(self.shape, self.focal_length, wavelength, self.spacing)
        radius = self.length().min() / 2
        amplitude = circle(self.shape, radius, self.spacing)
        return amplitude * torch.exp(1j * phase)


class CylindricalLens(PolychromaticModulationElement):
    r"""Cylindrical lens element.

    Represents a thin cylindrical lens with the following modulation profile:

    .. math::
        \mathcal{M}(x, y) = \exp\left(-i \frac{\pi}{\lambda f} x^2 \right)

    where:
        - :math:`\lambda` is the wavelength of the light, and
        - :math:`f` is the focal length of the lens.

    Args:
        shape (Vector2): Number of grid points along the planar dimensions.
        focal_length (Scalar): Focal length of the lens.
        z (Scalar): Position along the z-axis. Default: `0`.
        theta (Scalar): Angle of the lens in radians. Default: `0`.
        spacing (Vector2 | None): Distance between grid points along planar dimensions. Default: if
            `None`, uses a global default (see :meth:`torchoptics.set_default_spacing()`).
        offset (Vector2 | None): Center coordinates of the plane. Default: `(0, 0)`.

    """

    focal_length: Tensor
    theta: Tensor

    def __init__(
        self,
        shape: Vector2,
        focal_length: Scalar,
        theta: Scalar = 0,
        z: Scalar = 0,
        spacing: Vector2 | None = None,
        offset: Vector2 | None = None,
    ) -> None:
        """Initialize the CylindricalLens."""
        super().__init__(shape, z, spacing, offset)
        self.register_optics_property("focal_length", focal_length, is_scalar=True)
        self.register_optics_property("theta", theta, is_scalar=True)

    def modulation_profile(self, wavelength: Scalar | None = None) -> Tensor:
        """Return the modulation profile."""
        phase = cylindrical_lens_phase(self.shape, self.focal_length, self.theta, wavelength, self.spacing)
        radius = self.length().min() / 2
        amplitude = circle(self.shape, radius, self.spacing)
        return amplitude * torch.exp(1j * phase)
