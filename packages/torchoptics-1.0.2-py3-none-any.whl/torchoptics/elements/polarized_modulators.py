"""Polarized modulator element definitions."""

import torch
from torch import Tensor

from ..types import Scalar, Vector2
from ..utils import validate_tensor_ndim
from .elements import PolarizedModulationElement


class PolarizedModulator(PolarizedModulationElement):
    """Polarized modulator element.

    The polarized modulator is described by a complex polarized modulation profile.

    Args:
        polarized_modulation_profile (Tensor): Complex 3x3 polarized modulation profile.
        z (Scalar): Position along the z-axis. Default: `0`.
        spacing (Vector2 | None): Distance between grid points along planar dimensions. Default: if
            `None`, uses a global default (see :meth:`torchoptics.set_default_spacing()`).
        offset (Vector2 | None): Center coordinates of the plane. Default: `(0, 0)`.

    """

    polarized_modulation: Tensor

    def __init__(
        self,
        polarized_modulation: Tensor,
        z: Scalar = 0,
        spacing: Vector2 | None = None,
        offset: Vector2 | None = None,
    ) -> None:
        """Initialize the PolarizedModulator."""
        _validate_tensor(polarized_modulation, "polarized_modulation")
        super().__init__(polarized_modulation.shape[2:], z, spacing, offset)
        self.register_optics_property("polarized_modulation", polarized_modulation, is_complex=True)

    def polarized_modulation_profile(self) -> Tensor:
        """Return the polarized modulation profile."""
        return self.polarized_modulation


class PolarizedPhaseModulator(PolarizedModulationElement):
    """Polarized phase-only modulator element.

    The polarized phase modulator is described by a polarized phase profile.

    Args:
        phase (Tensor): Phase profile (real-valued 3x3 tensor).
        z (Scalar): Position along the z-axis. Default: `0`.
        spacing (Vector2 | None): Distance between grid points along planar dimensions. Default: if
            `None`, uses a global default (see :meth:`torchoptics.set_default_spacing()`).
        offset (Vector2 | None): Center coordinates of the plane. Default: `(0, 0)`.

    """

    phase: Tensor

    def __init__(
        self,
        phase: Tensor,
        z: Scalar = 0,
        spacing: Vector2 | None = None,
        offset: Vector2 | None = None,
    ) -> None:
        """Initialize the PolarizedPhaseModulator."""
        _validate_tensor(phase, "phase")
        super().__init__(phase.shape[2:], z, spacing, offset)
        self.register_optics_property("phase", phase)

    def polarized_modulation_profile(self) -> Tensor:
        """Return the polarized modulation profile."""
        return torch.exp(1j * self.phase)


class PolarizedAmplitudeModulator(PolarizedModulationElement):
    """Polarized amplitude-only modulator element.

    The polarized amplitude modulator is described by an amplitude profile.

    Args:
        amplitude (Tensor): Amplitude profile (real-valued 3x3 tensor).
        z (Scalar): Position along the z-axis. Default: `0`.
        spacing (Vector2 | None): Distance between grid points along planar dimensions. Default: if
            `None`, uses a global default (see :meth:`torchoptics.set_default_spacing()`).
        offset (Vector2 | None): Center coordinates of the plane. Default: `(0, 0)`.

    """

    amplitude: Tensor

    def __init__(
        self,
        amplitude: Tensor,
        z: Scalar = 0,
        spacing: Vector2 | None = None,
        offset: Vector2 | None = None,
    ) -> None:
        """Initialize the PolarizedAmplitudeModulator."""
        _validate_tensor(amplitude, "amplitude")
        super().__init__(amplitude.shape[2:], z, spacing, offset)
        self.register_optics_property("amplitude", amplitude)

    def polarized_modulation_profile(self) -> Tensor:
        """Return the polarized modulation profile."""
        return self.amplitude + 0j


def _validate_tensor(tensor: Tensor, name: str) -> None:
    validate_tensor_ndim(tensor, name, 4)
    if tensor.shape[:2] != (3, 3):
        msg = f"Expected first two dimensions of {name} to have shape (3, 3), but got {tensor.shape[:2]}"
        raise ValueError(msg)
