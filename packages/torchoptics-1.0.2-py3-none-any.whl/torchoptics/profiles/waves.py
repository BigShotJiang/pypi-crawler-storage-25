"""Phase argument generation for spherical and plane waves."""

import torch
from torch import Tensor

from ..types import Scalar, Vector2
from ..utils import initialize_tensor, wavelength_or_default
from ._profile_meshgrid import profile_meshgrid


def plane_wave_phase(
    shape: Vector2,
    theta: Scalar = 0.0,
    phi: Scalar = 0.0,
    z: Scalar = 0.0,
    wavelength: Scalar | None = None,
    spacing: Vector2 | None = None,
    offset: Vector2 | None = None,
) -> Tensor:
    r"""Compute the phase argument of a plane wave with arbitrary propagation direction.

    The phase argument is defined as:

    .. math::
        \psi(x, y, z) = k_x x + k_y y + k_z z

    where:
        - :math:`k_x = \frac{2\pi}{\lambda} \sin\theta \cos\phi`
        - :math:`k_y = \frac{2\pi}{\lambda} \sin\theta \sin\phi`
        - :math:`k_z = \frac{2\pi}{\lambda} \cos\theta`

    Args:
        shape (Vector2): Number of grid points along planar dimensions.
        theta (Scalar): Polar angle from the z-axis, in radians.
        phi (Scalar): Azimuthal angle in the x-y plane, in radians.
        z (Scalar): Axial location at which to evaluate the phase. Default: 0.
        wavelength (Scalar | None): Wavelength of the wave. If None, uses global default.
        spacing (Vector2 | None): Distance between grid points along planar dimensions. Default: if
            `None`, uses a global default (see :meth:`torchoptics.set_default_spacing()`).
        offset (Vector2 | None): Center coordinates of the wave. Default: `(0, 0)`.

    Returns:
        torch.Tensor: Real-valued 2D phase argument of the plane wave.

    """
    wavelength = wavelength_or_default(wavelength)
    theta = initialize_tensor("theta", theta, is_scalar=True)
    phi = initialize_tensor("phi", phi, is_scalar=True)
    z = initialize_tensor("z", z, is_scalar=True)

    x, y = profile_meshgrid(shape, spacing, offset)

    k0 = 2 * torch.pi / wavelength
    kx = k0 * torch.sin(theta) * torch.cos(phi)
    ky = k0 * torch.sin(theta) * torch.sin(phi)
    kz = k0 * torch.cos(theta)

    return kx * x + ky * y + kz * z


def spherical_wave_phase(
    shape: Vector2,
    z: Scalar,
    wavelength: Scalar | None = None,
    spacing: Vector2 | None = None,
    offset: Vector2 | None = None,
) -> Tensor:
    r"""Compute the phase argument of a spherical wave originating from a point source.

    The phase argument is defined as:

    .. math::
        \psi(x, y, z) = k \cdot r, \quad
        r = \sqrt{x^2 + y^2 + z^2}

    where:
        - :math:`z` is the axial distance from the source to the observation plane,
        - :math:`k = \frac{2\pi}{\lambda}` is the wavenumber.

    Args:
        shape (Vector2): Grid shape (height, width).
        z (Scalar): z-location of the observation plane.
        wavelength (Scalar | None): Wavelength of the wave. If None, uses global default.
        spacing (Vector2 | None): Distance between grid points along planar dimensions. Default: if
            `None`, uses a global default (see :meth:`torchoptics.set_default_spacing()`).
        offset (Vector2 | None): Center coordinates of the wave. Default: `(0, 0)`.

    Returns:
        torch.Tensor: Real-valued 2D phase argument of the spherical wave.

    """
    wavelength = wavelength_or_default(wavelength)
    z = initialize_tensor("z", z, is_scalar=True)

    x, y = profile_meshgrid(shape, spacing, offset)
    r = torch.sqrt(x**2 + y**2 + z**2)

    k = 2 * torch.pi / wavelength
    return k * r
