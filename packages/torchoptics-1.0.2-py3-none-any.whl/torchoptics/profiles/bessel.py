"""Bessel beam profile generation."""

import torch
from torch import Tensor

from ..types import Scalar, Vector2
from ..utils import initialize_tensor, wavelength_or_default
from ._profile_meshgrid import profile_meshgrid


def bessel(
    shape: Vector2,
    cone_angle: Scalar,
    wavelength: Scalar | None = None,
    spacing: Vector2 | None = None,
    offset: Vector2 | None = None,
) -> Tensor:
    r"""Generate a zeroth-order Bessel beam.

    The zeroth-order Bessel beam is defined by the following equation:

    .. math::
        \psi(r) = J_0(k \, r \sin(\theta)),

    where:

    - :math:`J_0` is the zeroth-order Bessel function of the first kind,
    - :math:`\theta` is the cone angle of the Bessel beam, and
    - :math:`k` is the wave number, :math:`k = 2\pi / \lambda`.

    Args:
        shape (Vector2): Number of grid points along the planar dimensions.
        cone_angle (Scalar): The cone angle in radians.
        wavelength (Scalar | None): The wavelength of the beam. Default: if `None`, uses a global default
            (see :meth:`torchoptics.set_default_wavelength()`).
        spacing (Vector2 | None): Distance between grid points along planar dimensions. Default: if
            `None`, uses a global default (see :meth:`torchoptics.set_default_spacing()`).
        offset (Vector2 | None): Center coordinates of the beam. Default: `(0, 0)`.

    Returns:
        Tensor: The generated zeroth-order Bessel beam profile.

    """
    wavelength = wavelength_or_default(wavelength)
    cone_angle = initialize_tensor("cone_angle", cone_angle, is_scalar=True)

    k = 2 * torch.pi / wavelength
    k_r = k * torch.sin(cone_angle)

    x, y = profile_meshgrid(shape, spacing, offset)
    r = torch.sqrt(x**2 + y**2)

    # Calculate the zeroth-order Bessel beam
    return torch.special.bessel_j0(k_r * r)
