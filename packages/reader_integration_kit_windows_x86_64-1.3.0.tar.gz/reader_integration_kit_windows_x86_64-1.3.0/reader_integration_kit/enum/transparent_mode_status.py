import enum
from ctypes import c_uint8


class TransparentModeStatus(enum.IntEnum):
    NOT_READY = 0
    READY = 1

    @classmethod
    def from_param(cls, obj):
        return c_uint8(obj.value if isinstance(obj, cls) else obj)
