import enum
from ctypes import c_uint8


class TransparentModeState(enum.IntEnum):
    DISABLED = 0
    ENABLED = 1

    @classmethod
    def from_param(cls, obj):
        return c_uint8(obj.value if isinstance(obj, cls) else obj)
