from ctypes import Structure, c_uint8

from reader_integration_kit.structures.device_id import DeviceId
from reader_integration_kit.structures.serial_port_settings import SerialPortSettings


class ReaderDefinition(Structure):
    _pack_ = 1
    _fields_ = [
        ("DeviceId", DeviceId),
        ("ProtocolType", c_uint8),  # ProtocolType enum (byte in C++)
        ("SerialPortSettings", SerialPortSettings),
    ]

