from ctypes import Structure, c_ushort, c_char


class DeviceId(Structure):
    _pack_ = 1
    _fields_ = [
        ("VendorId", c_ushort),
        ("ProductId", c_ushort),
        ("UsbPath", c_char * 512),
        ("SerialNumber", c_char * 256),
    ]

