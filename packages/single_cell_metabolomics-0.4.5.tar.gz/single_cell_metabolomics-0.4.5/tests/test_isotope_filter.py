import json
import numpy as np
import pandas as pd
import pyarrow as pa
import pyarrow.parquet as pq
import pytest
from pathlib import Path
from single_cell_metabolomics.isotope_filter import IsotopeFilterExecutor


def _write_long_coo(tmp_path, feature_intensities):
    """feature_intensities: dict[feature_name -> dict[sample_name -> value]]"""
    rows = []
    for f, sample_map in feature_intensities.items():
        for s, v in sample_map.items():
            if v > 0:
                rows.append({'row': f, 'col': s, 'value': float(v)})
    df = pd.DataFrame(rows)
    parquet = tmp_path / 'matrix.parquet'
    pq.write_table(pa.Table.from_pandas(df, preserve_index=False), parquet)
    features = list(feature_intensities.keys())
    samples = sorted({s for fm in feature_intensities.values() for s in fm.keys()})
    row_tsv = tmp_path / 'row.tsv'; row_tsv.write_text('\n'.join(features) + '\n')
    col_tsv = tmp_path / 'col.tsv'; col_tsv.write_text('\n'.join(samples) + '\n')
    return str(parquet), str(row_tsv), str(col_tsv), features, samples


def test_candidate_fails_coverage_gate(tmp_path):
    """B detected in 4 of M's 10 samples -> 40% < 80% -> fail before Pearson is called."""
    samples_M = [f's{i}' for i in range(10)]
    feats = {
        'pos_100.0000': {s: 1000.0 for s in samples_M},                  # M (mz 100, +1 charge)
        'pos_101.0033': {s: 500.0 for s in samples_M[:4]},                # B at +1 shift, 40% coverage
    }
    parquet, row, col, _, _ = _write_long_coo(tmp_path, feats)
    ex = IsotopeFilterExecutor(parquet, row, col)
    n_kept, n_dropped = ex.filter(
        mass_tolerance_value=0.005, mass_tolerance_unit='Da',
        charge_states=['+1'],
        isotope_min_coverage_of_main=80.0,
        isotope_corr_threshold=0.85,
        max_isotope_intensity_ratio=0.4,
    )
    assert n_dropped == 0
    assert 'pos_101.0033' in ex.row_names


def test_candidate_passes_all_three_gates(tmp_path):
    """Coverage 90% / Pearson ~1.0 / ratio 0.30 -> drop B."""
    samples = [f's{i}' for i in range(10)]
    M_vals = {s: 1000.0 + i * 100 for i, s in enumerate(samples)}
    B_vals = {s: 0.30 * v for s, v in M_vals.items()}  # perfectly proportional -> Pearson=1.0
    # B detected in 9 of 10 samples to give 90% coverage
    B_vals[samples[0]] = 0.0
    feats = {'pos_100.0000': M_vals, 'pos_101.0033': B_vals}
    parquet, row, col, _, _ = _write_long_coo(tmp_path, feats)
    ex = IsotopeFilterExecutor(parquet, row, col)
    n_kept, n_dropped = ex.filter(
        mass_tolerance_value=0.005, mass_tolerance_unit='Da',
        charge_states=['+1'],
        isotope_min_coverage_of_main=80.0,
        isotope_corr_threshold=0.85,
        max_isotope_intensity_ratio=0.4,
    )
    assert n_dropped == 1
    assert 'pos_101.0033' not in ex.row_names
    assert 'pos_100.0000' in ex.row_names


def test_only_z1_charge_state_scoped(tmp_path):
    """With charge_states=['+1'], a candidate at +2 shift must NOT be searched."""
    samples = [f's{i}' for i in range(10)]
    M_vals = {s: 1000.0 + i * 100 for i, s in enumerate(samples)}
    # candidate at +2 shift (0.5016 Da)
    B_vals = {s: 0.30 * v for s, v in M_vals.items()}
    feats = {'pos_100.0000': M_vals, 'pos_100.5016': B_vals}
    parquet, row, col, _, _ = _write_long_coo(tmp_path, feats)
    ex = IsotopeFilterExecutor(parquet, row, col)
    n_kept, n_dropped = ex.filter(
        mass_tolerance_value=0.005, mass_tolerance_unit='Da',
        charge_states=['+1'],  # +2 NOT selected
        isotope_min_coverage_of_main=80.0,
        isotope_corr_threshold=0.85,
        max_isotope_intensity_ratio=0.4,
    )
    assert n_dropped == 0


def test_main_with_no_candidates_in_window(tmp_path):
    """Main peak alone in its mass-tolerance window - no drops."""
    samples = [f's{i}' for i in range(10)]
    feats = {
        'pos_100.0000': {s: 1000.0 for s in samples},
        'pos_500.0000': {s: 800.0 for s in samples},
    }
    parquet, row, col, _, _ = _write_long_coo(tmp_path, feats)
    ex = IsotopeFilterExecutor(parquet, row, col)
    n_kept, n_dropped = ex.filter(
        mass_tolerance_value=0.005, mass_tolerance_unit='Da',
        charge_states=['+1', '+2', '+3'],
        isotope_min_coverage_of_main=80.0,
        isotope_corr_threshold=0.85,
        max_isotope_intensity_ratio=0.4,
    )
    assert n_dropped == 0


def test_no_input_features(tmp_path):
    feats = {}
    # Build minimal empty long-COO
    df = pd.DataFrame({'row': pd.Series([], dtype=str),
                       'col': pd.Series([], dtype=str),
                       'value': pd.Series([], dtype=float)})
    parquet = tmp_path / 'matrix.parquet'
    pq.write_table(pa.Table.from_pandas(df, preserve_index=False), parquet)
    row_tsv = tmp_path / 'row.tsv'; row_tsv.write_text('')
    col_tsv = tmp_path / 'col.tsv'; col_tsv.write_text('')
    ex = IsotopeFilterExecutor(str(parquet), str(row_tsv), str(col_tsv))
    n_kept, n_dropped = ex.filter(
        mass_tolerance_value=0.005, mass_tolerance_unit='Da',
        charge_states=['+1'],
        isotope_min_coverage_of_main=80.0,
        isotope_corr_threshold=0.85,
        max_isotope_intensity_ratio=0.4,
    )
    assert n_kept == 0 and n_dropped == 0
