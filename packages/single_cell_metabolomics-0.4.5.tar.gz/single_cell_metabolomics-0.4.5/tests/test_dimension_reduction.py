# ylclab-single-cell-metabolomics/tests/test_dimension_reduction.py
import json
import numpy as np
import pandas as pd
import pyarrow as pa
import pyarrow.parquet as pq
import pytest
from pathlib import Path
from single_cell_metabolomics.dimension_reduction import DimensionReductionExecutor


# ---------------------------------------------------------------------------
# Fixture — 30 samples x 20 features, COO parquet with string row/col
# ---------------------------------------------------------------------------
@pytest.fixture
def dr_data(tmp_path):
    """30 samples x 20 features for dimension reduction tests."""
    rng = np.random.default_rng(42)
    n_samples, n_features = 30, 20
    samples = [f'sample_{i}' for i in range(n_samples)]
    features = [f'negative_{100.0 + i * 10}' for i in range(n_features)]

    values = rng.uniform(50, 500, (n_samples, n_features))

    # Build COO parquet with VARCHAR row/col (production format)
    rows = []
    for si, sample in enumerate(samples):
        for fi, feat in enumerate(features):
            rows.append({'row': feat, 'col': sample, 'value': float(values[si, fi])})
    df = pd.DataFrame(rows)
    parquet_path = str(tmp_path / 'matrix.parquet')
    pq.write_table(pa.Table.from_pandas(df, preserve_index=False), parquet_path)

    # Name TSV files (single-column headerless format)
    row_tsv = tmp_path / 'row.tsv'
    row_tsv.write_text('\n'.join(features))
    col_tsv = tmp_path / 'col.tsv'
    col_tsv.write_text('\n'.join(samples))

    # Metadata CSV
    meta_df = pd.DataFrame({
        'group': ['A'] * 15 + ['B'] * 15,
    }, index=samples)
    meta_path = str(tmp_path / 'metadata.csv')
    meta_df.to_csv(meta_path)

    return parquet_path, str(row_tsv), str(col_tsv), meta_path, n_samples, n_features


def make_executor(dr_data):
    parquet_path, row_path, col_path, meta_path, _, _ = dr_data
    return DimensionReductionExecutor(parquet_path, row_path, col_path, meta_path)


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

def test_pca_output_shape(dr_data):
    """PCA produces (n_samples, n_pcs) embedding with 2D points."""
    ex = make_executor(dr_data)
    n_samples = dr_data[4]
    ex.reduce_pca(n_pcs=10)
    assert len(ex.embedding) == n_samples
    assert all(len(pt) == 2 for pt in ex.embedding)
    assert len(ex.variance_ratio) == 2


def test_umap_output_shape(dr_data):
    """UMAP produces (n_samples, 2) embedding."""
    ex = make_executor(dr_data)
    n_samples = dr_data[4]
    ex.reduce_umap(n_pcs=10, n_neighbors=10, min_dist=0.1)
    assert len(ex.embedding) == n_samples
    assert all(len(pt) == 2 for pt in ex.embedding)


def test_tsne_output_shape(dr_data):
    """t-SNE produces (n_samples, 2) embedding."""
    ex = make_executor(dr_data)
    n_samples = dr_data[4]
    # perplexity must be < n_samples / 3
    ex.reduce_tsne(n_pcs=10, perplexity=5.0)
    assert len(ex.embedding) == n_samples
    assert all(len(pt) == 2 for pt in ex.embedding)


def test_pca_intermediate_saved(dr_data, tmp_path):
    """PCA parquet written when write_pca_parquet called."""
    ex = make_executor(dr_data)
    n_samples, n_features = dr_data[4], dr_data[5]
    n_pcs = 10
    ex.reduce_pca(n_pcs=n_pcs)

    pca_path = str(tmp_path / 'pca.parquet')
    ex.write_pca_parquet(pca_path, n_pcs)
    assert Path(pca_path).exists()

    pca_df = pq.read_table(pca_path).to_pandas()
    assert 'cell_name' in pca_df.columns
    assert len(pca_df) == n_samples
    # Number of PC columns = min(n_pcs, n_samples-1, n_features-1)
    expected_pcs = min(n_pcs, n_samples - 1, n_features - 1)
    pc_cols = [c for c in pca_df.columns if c.startswith('PC_')]
    assert len(pc_cols) == expected_pcs


def test_nPcs_capped_at_min_dimension(dr_data):
    """nPcs > min(n_samples, n_features) gets capped automatically."""
    ex = make_executor(dr_data)
    n_samples, n_features = dr_data[4], dr_data[5]
    # Request far more PCs than possible
    ex.reduce_pca(n_pcs=1000)
    # PCA matrix should have at most min(n_samples-1, n_features-1) components
    max_comps = min(n_samples - 1, n_features - 1)
    assert ex.pca_matrix.shape == (n_samples, max_comps)
    # Embedding should still be 2D points
    assert len(ex.embedding) == n_samples
    assert all(len(pt) == 2 for pt in ex.embedding)


def test_emit_sentinel_writes_json(dr_data, tmp_path, monkeypatch):
    """Sentinel file with embedding, cell_names, variance_ratio."""
    monkeypatch.chdir(tmp_path)
    ex = make_executor(dr_data)
    ex.reduce_pca(n_pcs=10)

    out_parquet = str(tmp_path / 'embedding.parquet')
    ex.write_embedding_parquet(out_parquet)
    row_out = str(tmp_path / 'row_out.tsv')
    col_out = str(tmp_path / 'col_out.tsv')
    ex.write_tsv_files(row_out, col_out)

    ex.emit_sentinel(
        serial_number='TEST001',
        dataset_uid=1,
        analysis_id=105,
        storage_path=out_parquet,
        row_path=row_out,
        column_path=col_out,
        method='PCA',
    )
    sentinel_file = tmp_path / 'dimension_reduction_metadata.json'
    assert sentinel_file.exists()
    sentinel = json.loads(sentinel_file.read_text())
    for field in ['serial_number', 'dataset_uid', 'pipeline_stage', 'analysis_id',
                  'storage_path', 'row_path', 'column_path',
                  'embedding', 'cell_names', 'variance_ratio', 'method', 'status']:
        assert field in sentinel, f"Missing field: {field}"
    assert 'color_labels' not in sentinel
    assert sentinel['status'] == 'completed'
    assert sentinel['storage_path'].startswith('/')
    assert len(sentinel['embedding']) == dr_data[4]
    assert len(sentinel['cell_names']) == dr_data[4]
    assert len(sentinel['variance_ratio']) == 2
