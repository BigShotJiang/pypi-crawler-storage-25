# ylclab-single-cell-metabolomics/tests/test_differential_abundance.py
import json
import numpy as np
import pandas as pd
import pyarrow as pa
import pyarrow.parquet as pq
import pytest
from single_cell_metabolomics.differential_abundance import (
    run_chunked_da,
    adjust_and_format_results,
    emit_sentinel,
)


N_SAMPLES = 30
N_FEATURES = 10
N_GROUPS = 3


@pytest.fixture
def da_data(tmp_path):
    """30 samples x 10 features COO parquet (VARCHAR row/col) + metadata + cluster labels."""
    rng = np.random.default_rng(42)

    sample_names = [f'sample_{i}' for i in range(N_SAMPLES)]
    feature_names = [f'feature_{i}' for i in range(N_FEATURES)]

    # Build COO parquet with string row/col
    rows = []
    for s_name in sample_names:
        for f_name in feature_names:
            rows.append({'row': f_name, 'col': s_name, 'value': float(rng.uniform(1, 100))})
    coo_df = pd.DataFrame(rows)
    parquet_path = str(tmp_path / 'matrix.parquet')
    pq.write_table(pa.Table.from_pandas(coo_df, preserve_index=False), parquet_path)

    # Row TSV (single-column headerless)
    row_tsv = tmp_path / 'row.tsv'
    row_tsv.write_text('\n'.join(feature_names))

    # Col TSV (single-column headerless)
    col_tsv = tmp_path / 'col.tsv'
    col_tsv.write_text('\n'.join(sample_names))

    # Metadata CSV with group column (3 groups of 10)
    groups = ['groupA'] * 10 + ['groupB'] * 10 + ['groupC'] * 10
    meta_df = pd.DataFrame({'group': groups}, index=sample_names)
    meta_path = str(tmp_path / 'metadata.csv')
    meta_df.to_csv(meta_path)

    # Cluster labels parquet (cell_name, cluster)
    cluster_labels = ['0'] * 10 + ['1'] * 10 + ['2'] * 10
    cl_df = pd.DataFrame({'cell_name': sample_names, 'cluster': cluster_labels})
    cl_path = str(tmp_path / 'cluster_labels.parquet')
    pq.write_table(pa.Table.from_pandas(cl_df, preserve_index=False), cl_path)

    return {
        'parquet_path': parquet_path,
        'row_path': str(row_tsv),
        'col_path': str(col_tsv),
        'metadata_path': meta_path,
        'cluster_labels_path': cl_path,
        'sample_names': sample_names,
        'feature_names': feature_names,
    }


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

def test_wilcoxon_output_columns(da_data):
    """Wilcoxon result has expected columns: group, name, score, logfoldchange, pval, pval_adj."""
    groups, feature_names, all_results = run_chunked_da(
        parquet_path=da_data['parquet_path'],
        row_path=da_data['row_path'],
        column_path=da_data['col_path'],
        metadata_path=da_data['metadata_path'],
        cluster_labels_path=da_data['cluster_labels_path'],
        test_method='wilcoxon',
        group_by='group',
        reference='rest',
        chunk_size=100,
    )
    _, results_by_group = adjust_and_format_results(groups, all_results, 'wilcoxon')

    expected_keys = {'names', 'scores', 'logfoldchanges', 'pvals', 'pvals_adj'}
    for group_key, group_data in results_by_group.items():
        assert set(group_data.keys()) == expected_keys, (
            f"Group '{group_key}' has unexpected keys: {set(group_data.keys())}"
        )


def test_wilcoxon_one_row_per_feature_per_group(da_data):
    """Correct number of raw result rows: n_features * n_groups."""
    groups, feature_names, all_results = run_chunked_da(
        parquet_path=da_data['parquet_path'],
        row_path=da_data['row_path'],
        column_path=da_data['col_path'],
        metadata_path=da_data['metadata_path'],
        cluster_labels_path=da_data['cluster_labels_path'],
        test_method='wilcoxon',
        group_by='group',
        reference='rest',
        chunk_size=100,
    )
    expected_rows = N_FEATURES * N_GROUPS
    assert len(all_results) == expected_rows, (
        f"Expected {expected_rows} result rows, got {len(all_results)}"
    )
    # Each result row must have required keys
    for r in all_results:
        for key in ('group', 'name', 'score', 'logfoldchange', 'pval'):
            assert key in r, f"Missing key '{key}' in result row"


def test_ttest_runs(da_data):
    """t-test method completes without error."""
    groups, feature_names, all_results = run_chunked_da(
        parquet_path=da_data['parquet_path'],
        row_path=da_data['row_path'],
        column_path=da_data['col_path'],
        metadata_path=da_data['metadata_path'],
        cluster_labels_path=da_data['cluster_labels_path'],
        test_method='t-test',
        group_by='group',
        reference='rest',
        chunk_size=100,
    )
    assert len(all_results) == N_FEATURES * N_GROUPS
    assert len(groups) == N_GROUPS


def test_anova_output_format(da_data):
    """ANOVA produces per-feature stats with group='ANOVA'."""
    groups, feature_names, all_results = run_chunked_da(
        parquet_path=da_data['parquet_path'],
        row_path=da_data['row_path'],
        column_path=da_data['col_path'],
        metadata_path=da_data['metadata_path'],
        cluster_labels_path=da_data['cluster_labels_path'],
        test_method='ANOVA',
        group_by='group',
        reference='rest',
        chunk_size=100,
    )
    # ANOVA produces one row per feature (not per group)
    assert len(all_results) == N_FEATURES, (
        f"Expected {N_FEATURES} ANOVA results, got {len(all_results)}"
    )
    for r in all_results:
        assert r['group'] == 'ANOVA'
        assert 'score' in r
        assert 'pval' in r

    # Format results
    groups_list, results_by_group = adjust_and_format_results(groups, all_results, 'ANOVA')
    assert 'ANOVA' in results_by_group
    assert results_by_group['ANOVA']['logfoldchanges'] is None


def test_emit_sentinel_writes_json(da_data, tmp_path, monkeypatch):
    """Sentinel contains results_by_group and groups."""
    monkeypatch.chdir(tmp_path)

    groups, feature_names, all_results = run_chunked_da(
        parquet_path=da_data['parquet_path'],
        row_path=da_data['row_path'],
        column_path=da_data['col_path'],
        metadata_path=da_data['metadata_path'],
        cluster_labels_path=da_data['cluster_labels_path'],
        test_method='wilcoxon',
        group_by='group',
        reference='rest',
        chunk_size=100,
    )
    groups_list, results_by_group = adjust_and_format_results(groups, all_results, 'wilcoxon')

    emit_sentinel(
        serial_number='TEST001',
        dataset_uid=1,
        analysis_id=108,
        output_parquet_path='differential_abundance.parquet',
        output_row_path=da_data['row_path'],
        output_column_path=da_data['col_path'],
        test_method='wilcoxon',
        group_by='group',
        reference='rest',
        groups_list=groups_list,
        results_by_group=results_by_group,
        n_top_features=50,
    )

    sentinel_file = tmp_path / 'differential_abundance_metadata.json'
    assert sentinel_file.exists(), "Sentinel file was not written"
    sentinel = json.loads(sentinel_file.read_text())

    for field in ['serial_number', 'dataset_uid', 'pipeline_stage', 'analysis_id',
                  'storage_path', 'status', 'groups', 'results_by_group']:
        assert field in sentinel, f"Missing field: {field}"

    assert sentinel['status'] == 'completed'
    assert sentinel['storage_path'].startswith('/')
    assert isinstance(sentinel['groups'], list)
    assert len(sentinel['groups']) == N_GROUPS
    assert isinstance(sentinel['results_by_group'], dict)
    assert len(sentinel['results_by_group']) == N_GROUPS
