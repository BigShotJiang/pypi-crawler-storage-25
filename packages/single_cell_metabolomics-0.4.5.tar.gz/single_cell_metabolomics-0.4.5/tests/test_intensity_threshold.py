# ylclab-single-cell-metabolomics/tests/test_intensity_threshold.py
import json
import math
import numpy as np
import pandas as pd
import pyarrow as pa
import pyarrow.parquet as pq
import pytest
from pathlib import Path
from single_cell_metabolomics.intensity_threshold import IntensityThresholdExecutor


@pytest.fixture
def long_coo_parquet(tmp_path):
    """100 samples × 5 features long-COO. f1 is dense; f5 is sparse below threshold."""
    rng = np.random.default_rng(0)
    features = ['pos_100.0', 'pos_200.0', 'pos_300.0', 'pos_400.0', 'pos_500.0']
    samples = [f's{i}' for i in range(100)]
    rows = []
    # f1 detected in all 100 samples at high intensity
    for s in samples:
        rows.append({'row': 'pos_100.0', 'col': s, 'value': float(rng.uniform(5000, 10000))})
    # f2 detected in 50 samples at high intensity (passes 10%)
    for s in samples[:50]:
        rows.append({'row': 'pos_200.0', 'col': s, 'value': float(rng.uniform(5000, 10000))})
    # f3 detected in exactly 10 samples >= 1000 (boundary pass)
    for s in samples[:10]:
        rows.append({'row': 'pos_300.0', 'col': s, 'value': 1500.0})
    # f4 detected in 9 samples >= 1000 (one short — must drop at default 10%)
    for s in samples[:9]:
        rows.append({'row': 'pos_400.0', 'col': s, 'value': 1500.0})
    # f5 detected in 100 samples but always below 1000 (must drop)
    for s in samples:
        rows.append({'row': 'pos_500.0', 'col': s, 'value': 50.0})

    df = pd.DataFrame(rows)
    parquet_path = tmp_path / 'matrix.parquet'
    pq.write_table(pa.Table.from_pandas(df, preserve_index=False), parquet_path)
    row_tsv = tmp_path / 'row.tsv'
    row_tsv.write_text('\n'.join(features) + '\n')
    col_tsv = tmp_path / 'col.tsv'
    col_tsv.write_text('\n'.join(samples) + '\n')
    return str(parquet_path), str(row_tsv), str(col_tsv)


def test_default_thresholds_drop_low_intensity_sparse(long_coo_parquet, tmp_path):
    parquet, row_tsv, col_tsv = long_coo_parquet
    out_parquet = tmp_path / 'intensity_filtered.parquet'
    out_row = tmp_path / 'intensity_filtered_row.tsv'
    out_col = tmp_path / 'intensity_filtered_col.tsv'

    ex = IntensityThresholdExecutor(parquet, row_tsv, col_tsv)
    n_kept, n_dropped = ex.filter(abs_intensity_threshold=1000.0,
                                   intensity_min_detection_rate=10.0)
    ex.save(str(out_parquet), str(out_row), str(out_col))

    surviving = out_row.read_text().strip().split('\n')
    assert 'pos_100.0' in surviving        # 100/100 above threshold
    assert 'pos_200.0' in surviving        # 50/100 above threshold
    assert 'pos_300.0' in surviving        # 10/100 — boundary pass
    assert 'pos_400.0' not in surviving    # 9/100 — fail
    assert 'pos_500.0' not in surviving    # 0/100 — fail
    assert n_kept == 3
    assert n_dropped == 2


def test_zero_features_pass_threshold(long_coo_parquet, tmp_path):
    parquet, row_tsv, col_tsv = long_coo_parquet
    out_parquet = tmp_path / 'intensity_filtered.parquet'
    out_row = tmp_path / 'intensity_filtered_row.tsv'
    out_col = tmp_path / 'intensity_filtered_col.tsv'

    ex = IntensityThresholdExecutor(parquet, row_tsv, col_tsv)
    # Threshold so high nothing passes
    n_kept, n_dropped = ex.filter(abs_intensity_threshold=1e12,
                                   intensity_min_detection_rate=10.0)
    ex.save(str(out_parquet), str(out_row), str(out_col))
    assert n_kept == 0
    assert out_row.read_text().strip() == ''


def test_metadata_json_shape(long_coo_parquet, tmp_path):
    parquet, row_tsv, col_tsv = long_coo_parquet
    out_parquet = tmp_path / 'intensity_filtered.parquet'
    out_row = tmp_path / 'intensity_filtered_row.tsv'
    out_col = tmp_path / 'intensity_filtered_col.tsv'
    meta_path = tmp_path / 'intensity_filtered_metadata.json'

    ex = IntensityThresholdExecutor(parquet, row_tsv, col_tsv)
    ex.filter(abs_intensity_threshold=1000.0, intensity_min_detection_rate=10.0)
    ex.save(str(out_parquet), str(out_row), str(out_col))
    ex.emit_metadata(
        serial_number='SC2026-0001', dataset_uid=1, analysis_id=0,
        storage_path=str(out_parquet), row_path=str(out_row),
        column_path=str(out_col), metadata_path=str(meta_path),
    )
    meta = json.loads(meta_path.read_text())
    assert meta['feature_number_before'] == 5
    assert meta['feature_number_after'] == 3
    assert meta['sample_number'] == 100
    assert meta['status'] == 'completed'
    # Canonical aliases consumed by the platform's preparation result handler.
    # Keep these assertions in sync across the three reduction-module tests.
    assert meta['result_type'] == 'mergetsv_sparse_matrix'
    assert meta['feature_number'] == meta['feature_number_after']


def test_idempotent_on_already_filtered(long_coo_parquet, tmp_path):
    """Re-running the filter on its own output produces no further drops."""
    parquet, row_tsv, col_tsv = long_coo_parquet
    out1_parquet = tmp_path / 'pass1.parquet'
    out1_row = tmp_path / 'pass1_row.tsv'
    out1_col = tmp_path / 'pass1_col.tsv'

    ex = IntensityThresholdExecutor(parquet, row_tsv, col_tsv)
    ex.filter(abs_intensity_threshold=1000.0, intensity_min_detection_rate=10.0)
    ex.save(str(out1_parquet), str(out1_row), str(out1_col))

    ex2 = IntensityThresholdExecutor(str(out1_parquet), str(out1_row), str(out1_col))
    n_kept, n_dropped = ex2.filter(abs_intensity_threshold=1000.0,
                                    intensity_min_detection_rate=10.0)
    assert n_dropped == 0
