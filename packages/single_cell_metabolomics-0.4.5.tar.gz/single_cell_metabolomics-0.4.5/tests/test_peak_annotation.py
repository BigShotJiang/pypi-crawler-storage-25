# ylclab-single-cell-metabolomics/tests/test_peak_annotation.py
import json
import numpy as np
import pandas as pd
import pytest
from pathlib import Path
from single_cell_metabolomics.peak_annotation import match_peaks, app


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------
@pytest.fixture
def features_df():
    """Feature list with production-style names parsed into mode/mass/index."""
    names = [
        ('positive', 100.5, 0),
        ('positive', 200.3, 1),
        ('negative', 300.1, 2),
        ('negative', 400.7, 3),
        ('positive', 500.9, 4),
    ]
    return pd.DataFrame(names, columns=['mode', 'mass', 'index'])


@pytest.fixture
def dda_df():
    """DDA table with compound entries - some matching, some not."""
    return pd.DataFrame([
        {'compound_name': 'Compound_A', 'precursor_mz': 100.5001, 'mode': 'positive'},
        {'compound_name': 'Compound_B', 'precursor_mz': 100.5005, 'mode': 'positive'},
        {'compound_name': 'Compound_C', 'precursor_mz': 300.1002, 'mode': 'negative'},
        {'compound_name': 'Compound_D', 'precursor_mz': 999.0, 'mode': 'positive'},  # no match
    ])


@pytest.fixture
def row_tsv(tmp_path):
    """Headerless single-column TSV with feature names (production format)."""
    names = [
        'positive_100.5',
        'positive_200.3',
        'negative_300.1',
        'negative_400.7',
        'positive_500.9',
    ]
    path = tmp_path / 'row.tsv'
    path.write_text('\n'.join(names))
    return str(path)


@pytest.fixture
def dda_csv(tmp_path):
    """DDA table CSV matching the expected format."""
    df = pd.DataFrame([
        {'compound_name': 'Compound_A', 'precursor_mz': 100.5001, 'mode': 'positive'},
        {'compound_name': 'Compound_B', 'precursor_mz': 100.5005, 'mode': 'positive'},
        {'compound_name': 'Compound_C', 'precursor_mz': 300.1002, 'mode': 'negative'},
        {'compound_name': 'Compound_D', 'precursor_mz': 999.0, 'mode': 'positive'},
    ])
    path = tmp_path / 'dda_table.csv'
    df.to_csv(str(path), index=False)
    return str(path)


# ---------------------------------------------------------------------------
# Tests - match_peaks function
# ---------------------------------------------------------------------------

def test_annotation_matches_within_tolerance(features_df, dda_df):
    """A feature at 100.5 matches a DDA entry at 100.5001 within 10 ppm."""
    result = match_peaks(
        features_df=features_df,
        dda_df=dda_df,
        tolerance_unit='ppm',
        tolerance_value=10.0,
        keep_best_only=False,
        score_threshold=0.0,
    )
    # Feature 0 (positive_100.5) should match Compound_A and Compound_B
    matches_f0 = result[(result['index'] == 0) & result['compound_name'].notna()]
    assert len(matches_f0) >= 1, "Expected at least one match for feature at 100.5"
    assert 'Compound_A' in matches_f0['compound_name'].values


def test_annotation_no_match_outside_tolerance(features_df, dda_df):
    """Feature at 200.3 does NOT match any DDA entry (nearest is at 100.5 or 999.0)."""
    result = match_peaks(
        features_df=features_df,
        dda_df=dda_df,
        tolerance_unit='ppm',
        tolerance_value=10.0,
        keep_best_only=False,
        score_threshold=0.0,
    )
    # Feature 1 (positive_200.3) - no DDA entry near 200.3
    matches_f1 = result[(result['index'] == 1) & result['compound_name'].notna()]
    assert len(matches_f1) == 0, "Expected no match for feature at 200.3"


def test_keep_best_only(features_df, dda_df):
    """When keepBestOnly=True, only highest score per feature retained."""
    # Feature 0 has two potential matches (Compound_A at 100.5001, Compound_B at 100.5005)
    result_all = match_peaks(
        features_df=features_df,
        dda_df=dda_df,
        tolerance_unit='ppm',
        tolerance_value=10.0,
        keep_best_only=False,
        score_threshold=0.0,
    )
    result_best = match_peaks(
        features_df=features_df,
        dda_df=dda_df,
        tolerance_unit='ppm',
        tolerance_value=10.0,
        keep_best_only=True,
        score_threshold=0.0,
    )
    matches_all_f0 = result_all[(result_all['index'] == 0) & result_all['compound_name'].notna()]
    matches_best_f0 = result_best[(result_best['index'] == 0) & result_best['compound_name'].notna()]

    # With keep_best_only, we should have fewer or equal matches
    assert len(matches_best_f0) <= len(matches_all_f0)
    # The best match should be Compound_A (closer to 100.5)
    if len(matches_best_f0) > 0:
        assert matches_best_f0.iloc[0]['compound_name'] == 'Compound_A'


def test_output_filtered_to_annotated(features_df, dda_df):
    """Output filtered to annotated-only contains only features with matches."""
    result = match_peaks(
        features_df=features_df,
        dda_df=dda_df,
        tolerance_unit='ppm',
        tolerance_value=10.0,
        keep_best_only=True,
        score_threshold=0.0,
    )
    annotated = result[result['compound_name'].notna()]
    # Only features 0 (100.5) and 2 (300.1) should have matches
    annotated_indices = set(annotated['index'].unique())
    assert 0 in annotated_indices, "Feature 0 (100.5) should be annotated"
    assert 2 in annotated_indices, "Feature 2 (300.1) should be annotated"
    # Features 1, 3, 4 should not be in annotated output
    assert 1 not in annotated_indices
    assert 3 not in annotated_indices
    assert 4 not in annotated_indices


# ---------------------------------------------------------------------------
# Tests - CLI integration via typer runner
# ---------------------------------------------------------------------------

def test_emit_sentinel_writes_json(tmp_path, row_tsv, dda_csv):
    """Sentinel JSON has summary with total_features, annotated_features, annotation_rate."""
    from typer.testing import CliRunner

    runner = CliRunner()
    out_row = str(tmp_path / 'annotated_row.tsv')
    out_sentinel = str(tmp_path / 'sentinel.json')

    result = runner.invoke(app, [
        'annotate',
        '--serial-number', 'TEST001',
        '--dataset-uid', '1',
        '--analysis-id', '109',
        '--row-path', row_tsv,
        '--column-path', '',
        '--dda-table-path', dda_csv,
        '--tolerance-unit', 'ppm',
        '--tolerance-value', '10.0',
        '--keep-best-only',
        '--score-threshold', '0.0',
        '--output-row-path', out_row,
        '--output-sentinel', out_sentinel,
    ])
    if result.exit_code != 0:
        raise RuntimeError(f"CLI failed (exit {result.exit_code}): {result.output}\n{result.exception}")

    sentinel = json.loads(Path(out_sentinel).read_text())
    assert sentinel['status'] == 'completed'
    assert 'summary' in sentinel

    summary = sentinel['summary']
    assert summary['total_features'] == 5
    assert summary['annotated_features'] >= 1
    assert 'annotation_rate' in summary
    assert 0.0 <= summary['annotation_rate'] <= 1.0
    assert sentinel['storage_path'].startswith('/')
