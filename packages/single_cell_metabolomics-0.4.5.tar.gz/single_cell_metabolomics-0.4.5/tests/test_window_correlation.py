# tests/test_window_correlation.py
"""Module 3 — Sliding Window Correlation tests.

Covers Spec Req 5 (`feature-reduction-preparation`):
  - Sort features by m/z ascending.
  - Within window [F_i.mz, F_i.mz + windowSize], compute Pearson on each
    in-window neighbor with co-detection >= 5.
  - Pairs with Pearson >= windowCorrThreshold compete on `windowMetric`;
    the lower-metric feature is dropped.
  - On tie, the higher-m/z feature is dropped (deterministic).
"""
from __future__ import annotations

import numpy as np
import pandas as pd
import pyarrow as pa
import pyarrow.parquet as pq

from single_cell_metabolomics.window_correlation import WindowCorrelationExecutor


def _write_long_coo(tmp_path, feature_intensities):
    rows = []
    for f, sample_map in feature_intensities.items():
        for s, v in sample_map.items():
            if v > 0:
                rows.append({'row': f, 'col': s, 'value': float(v)})
    df = pd.DataFrame(rows)
    parquet = tmp_path / 'matrix.parquet'
    pq.write_table(pa.Table.from_pandas(df, preserve_index=False), parquet)
    features = list(feature_intensities.keys())
    samples = sorted({s for fm in feature_intensities.values() for s in fm.keys()})
    row_tsv = tmp_path / 'row.tsv'
    row_tsv.write_text('\n'.join(features) + '\n')
    col_tsv = tmp_path / 'col.tsv'
    col_tsv.write_text('\n'.join(samples) + '\n')
    return str(parquet), str(row_tsv), str(col_tsv)


def test_sample_coverage_metric_prefers_broader(tmp_path):
    """User's headline scenario: F_i (10 samples) vs F_j (5 samples), Pearson high.

    On `sampleCoverage`, the broadly-detected F_i must win and F_j must be dropped.
    """
    samples = [f's{i}' for i in range(10)]
    F_i = {s: 1000.0 + i * 100 for i, s in enumerate(samples)}
    # F_j is detected only in the TOP-5 high-intensity samples, scaled half;
    # this keeps the full-vector Pearson well above 0.85 (Pearson ~0.91) while
    # leaving sampleCoverage(F_j)=5 < sampleCoverage(F_i)=10. If F_j were
    # detected in the LOW-5 samples instead, the centered vectors would
    # anti-correlate (Pearson ~ -0.8) and the pair would never trigger.
    F_j = {samples[i]: 0.5 * (1000.0 + i * 100) for i in range(5, 10)}
    feats = {'pos_350.1000': F_i, 'pos_350.4000': F_j}
    parquet, row, col = _write_long_coo(tmp_path, feats)
    ex = WindowCorrelationExecutor(parquet, row, col)
    n_kept, n_dropped = ex.filter(
        window_size=1.5,
        window_corr_threshold=0.85,
        window_metric='sampleCoverage',
    )
    assert 'pos_350.1000' in ex.row_names
    assert 'pos_350.4000' not in ex.row_names
    assert n_dropped == 1
    assert n_kept == 1


def test_cv_metric_drops_lower_cv_feature(tmp_path):
    """Asymmetric CVs — confirm cv metric flags the lower-CV feature."""
    samples = [f's{i}' for i in range(10)]
    F_i_vals = [1000.0 + i * 10 for i in range(10)]
    # F_j: monotonically larger swings (same rank order so Pearson high) but bigger spread
    F_j_vals = [v * (1.0 + 0.001 * i ** 2) for i, v in enumerate(F_i_vals)]
    F_i = {s: v for s, v in zip(samples, F_i_vals)}
    F_j = {s: v for s, v in zip(samples, F_j_vals)}
    feats = {'pos_350.1000': F_i, 'pos_350.4000': F_j}
    parquet, row, col = _write_long_coo(tmp_path, feats)
    ex = WindowCorrelationExecutor(parquet, row, col)
    n_kept, n_dropped = ex.filter(
        window_size=1.5,
        window_corr_threshold=0.85,
        window_metric='cv',
    )
    f_i_arr = np.array(F_i_vals)
    cv_i = f_i_arr.std() / f_i_arr.mean()
    f_j_arr = np.array(F_j_vals)
    cv_j = f_j_arr.std() / f_j_arr.mean()
    loser = 'pos_350.1000' if cv_i < cv_j else 'pos_350.4000'
    assert loser not in ex.row_names
    assert n_dropped == 1


def test_no_pairs_in_any_window(tmp_path):
    """Features 400 Da apart with windowSize=1.5 — no comparisons, no drops."""
    samples = [f's{i}' for i in range(10)]
    feats = {
        'pos_100.0000': {s: 1000.0 for s in samples},
        'pos_500.0000': {s: 800.0 for s in samples},
    }
    parquet, row, col = _write_long_coo(tmp_path, feats)
    ex = WindowCorrelationExecutor(parquet, row, col)
    n_kept, n_dropped = ex.filter(
        window_size=1.5,
        window_corr_threshold=0.85,
        window_metric='cv',
    )
    assert n_dropped == 0
    assert n_kept == 2
    assert 'pos_100.0000' in ex.row_names
    assert 'pos_500.0000' in ex.row_names


def test_pair_below_minimum_co_detection_skipped(tmp_path):
    """Co-detection count = 3 (< windowMinCoDetection=5) → pair skipped, no drops."""
    samples = [f's{i}' for i in range(10)]
    F_i_full = {s: 1000.0 for s in samples}
    F_j_partial = {samples[0]: 1000.0, samples[1]: 1100.0, samples[2]: 1050.0}
    feats = {'pos_350.1000': F_i_full, 'pos_350.4000': F_j_partial}
    parquet, row, col = _write_long_coo(tmp_path, feats)
    ex = WindowCorrelationExecutor(parquet, row, col)
    n_kept, n_dropped = ex.filter(
        window_size=1.5,
        window_corr_threshold=0.85,
        window_metric='cv',
    )
    assert n_dropped == 0
    assert n_kept == 2


def test_metric_tie_drops_higher_mz(tmp_path):
    """When metric values tie, the lower-m/z feature wins (deterministic)."""
    samples = [f's{i}' for i in range(10)]
    F_i = {s: 1000.0 + i * 100 for i, s in enumerate(samples)}
    F_j = dict(F_i)  # identical → identical CV / variance / mean / coverage
    feats = {'pos_350.1000': F_i, 'pos_350.4000': F_j}
    parquet, row, col = _write_long_coo(tmp_path, feats)
    ex = WindowCorrelationExecutor(parquet, row, col)
    n_kept, n_dropped = ex.filter(
        window_size=1.5,
        window_corr_threshold=0.85,
        window_metric='cv',
    )
    assert 'pos_350.1000' in ex.row_names  # lower-m/z survives the tie
    assert 'pos_350.4000' not in ex.row_names
    assert n_dropped == 1


def test_below_threshold_keeps_both(tmp_path):
    """Pearson < windowCorrThreshold → no competition, both survive."""
    samples = [f's{i}' for i in range(10)]
    rng = np.random.default_rng(0)
    F_i = {s: 1000.0 + i * 100 for i, s in enumerate(samples)}
    # F_j: noisy / anti-correlated to F_i so Pearson is well below 0.85
    F_j_vals = list(reversed(list(F_i.values())))
    F_j_vals = [v + rng.normal(0, 50) for v in F_j_vals]
    F_j = {s: v for s, v in zip(samples, F_j_vals)}
    feats = {'pos_350.1000': F_i, 'pos_350.4000': F_j}
    parquet, row, col = _write_long_coo(tmp_path, feats)
    ex = WindowCorrelationExecutor(parquet, row, col)
    n_kept, n_dropped = ex.filter(
        window_size=1.5,
        window_corr_threshold=0.85,
        window_metric='cv',
    )
    assert n_dropped == 0
    assert n_kept == 2
