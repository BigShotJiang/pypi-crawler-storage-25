"""Tests for filtration.py — focusing on na_count in compute_stats_before and
compute_stats_after using the definition-true COO-sparse formula:

    na_count = (sample_count * feature_count)
             - COUNT(*) WHERE value IS NOT NULL AND value <> 0
"""
import pytest
import pyarrow as pa
import pyarrow.parquet as pq
from single_cell_metabolomics.filtration import FilterExecutor


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_filtration_inputs(tmp_path, row_entries, col_entries, val_entries,
                             feature_names=None, sample_names=None):
    """Write COO parquet + sidecar TSVs in the format expected by FilterExecutor.

    Uses single-column headerless TSV format for both row and column sidecars,
    which FilterExecutor._build_name_table_sql handles via the headerless branch.
    The metadata CSV contains one sample per row with a dummy 'label' column.
    """
    table = pa.table({"row": row_entries, "col": col_entries, "value": val_entries})
    parquet_path = str(tmp_path / "matrix.parquet")
    pq.write_table(table, parquet_path)

    if feature_names is None:
        seen = {}
        for r in row_entries:
            seen[r] = None
        feature_names = list(seen.keys())
    if sample_names is None:
        seen = {}
        for c in col_entries:
            seen[c] = None
        sample_names = list(seen.keys())

    row_tsv = tmp_path / "row.tsv"
    row_tsv.write_text("\n".join(feature_names) + "\n")

    col_tsv = tmp_path / "col.tsv"
    col_tsv.write_text("\n".join(sample_names) + "\n")

    meta_csv = tmp_path / "meta.csv"
    meta_csv.write_text(
        "sample_id,label\n" + "\n".join(f"{s},sc" for s in sample_names) + "\n"
    )

    return str(parquet_path), str(row_tsv), str(col_tsv), str(meta_csv)


# ---------------------------------------------------------------------------
# compute_stats_before — na_count contract
# ---------------------------------------------------------------------------

def test_compute_stats_before_pure_coo(tmp_path):
    """Pure COO before-state: 4 features × 3 samples = 12 cells.
    8 stored rows, all non-zero non-null → before_na_count == 12 - 8 == 4.
    """
    features = ["f1", "f2", "f3", "f4"]
    samples = ["s1", "s2", "s3"]
    row_entries = ["f1", "f1", "f2", "f2", "f3", "f3", "f4", "f4"]
    col_entries = ["s1", "s2", "s1", "s3", "s2", "s3", "s1", "s2"]
    val_entries = [1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0]

    parquet, row_tsv, col_tsv, meta = _make_filtration_inputs(
        tmp_path, row_entries, col_entries, val_entries,
        feature_names=features, sample_names=samples,
    )

    fe = FilterExecutor(parquet, row_tsv, col_tsv, meta)
    stats = fe.compute_stats_before()
    fe.close()

    assert stats["before_sample_count"] == 3
    assert stats["before_feature_count"] == 4
    # 12 total cells, 8 non-zero non-null stored → 4 NA
    assert stats["before_na_count"] == 4, (
        f"Expected before_na_count=4 for pure COO (12 cells - 8 stored), "
        f"got {stats['before_na_count']}"
    )


def test_compute_stats_before_mixed_explicit_zeros(tmp_path):
    """Mixed matrix: 4 features × 3 samples = 12 cells.
    8 non-zero non-null stored rows + 2 explicit value=0 rows.
    Explicit zeros are treated as NA → before_na_count == 12 - 8 == 4.
    """
    features = ["f1", "f2", "f3", "f4"]
    samples = ["s1", "s2", "s3"]
    row_entries = ["f1", "f1", "f2", "f2", "f3", "f3", "f4", "f4", "f1", "f3"]
    col_entries = ["s1", "s2", "s1", "s3", "s2", "s3", "s1", "s2", "s3", "s1"]
    # Last two are explicit zeros — counted as NA by definition
    val_entries = [1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0, 0.0, 0.0]

    parquet, row_tsv, col_tsv, meta = _make_filtration_inputs(
        tmp_path, row_entries, col_entries, val_entries,
        feature_names=features, sample_names=samples,
    )

    fe = FilterExecutor(parquet, row_tsv, col_tsv, meta)
    stats = fe.compute_stats_before()
    fe.close()

    assert stats["before_sample_count"] == 3
    assert stats["before_feature_count"] == 4
    # 12 total cells, 8 non-zero non-null (2 zeros treated as NA) → 4 NA
    assert stats["before_na_count"] == 4, (
        f"Expected before_na_count=4 (zeros counted as NA), "
        f"got {stats['before_na_count']}"
    )


# ---------------------------------------------------------------------------
# compute_stats_after — na_count contract
# ---------------------------------------------------------------------------

def test_compute_stats_after_pure_coo(tmp_path, monkeypatch):
    """After filtering: retain 2 features × 2 samples = 4 cells.
    4 stored rows, all non-zero → after_na_count == 4 - 4 == 0.
    """
    # Build 3 features × 3 samples with a sparse corner that drops out after filtering
    features = ["f1", "f2", "f3"]
    samples = ["s1", "s2", "s3"]
    # f3 appears in only s3; s3 appears with only f3.
    # With min_features_for_sample=2 and min_samples_for_feature=2:
    # s3 has 1 feature → removed; f3 has 1 sample → removed → 2×2 remains
    row_entries = ["f1", "f1", "f2", "f2", "f3"]
    col_entries = ["s1", "s2", "s1", "s2", "s3"]
    val_entries = [1.0, 2.0, 3.0, 4.0, 5.0]

    parquet, row_tsv, col_tsv, meta = _make_filtration_inputs(
        tmp_path, row_entries, col_entries, val_entries,
        feature_names=features, sample_names=samples,
    )

    fe = FilterExecutor(parquet, row_tsv, col_tsv, meta)
    fe.filter_strict_min_counts(min_features_for_sample=2, min_samples_for_feature=2)
    fe.remove_unused_features()
    fe.remove_unused_samples()
    stats = fe.compute_stats_after()
    fe.close()

    assert stats["after_sample_count"] == 2
    assert stats["after_feature_count"] == 2
    # 4 total cells, all 4 stored with non-zero values → 0 NA
    assert stats["after_na_count"] == 0, (
        f"Expected after_na_count=0 for dense 2×2 result, "
        f"got {stats['after_na_count']}"
    )
