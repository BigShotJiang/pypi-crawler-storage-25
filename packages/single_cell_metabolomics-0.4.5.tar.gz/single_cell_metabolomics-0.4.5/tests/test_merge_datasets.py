"""Tests for the merge_datasets CLI command."""
import pandas as pd
import numpy as np
from pathlib import Path
from scipy import sparse
from single_cell_metabolomics.merge_datasets import merge_datasets_impl


def _write_test_dataset(tmp_path, name, n_samples, n_features, extra_meta_cols=None, mass_offset=0):
    """Helper: create a parquet + row/col TSV + metadata CSV for one dataset.

    Matches the canonical preparation.py output format:
      - row_feature_names.tsv — headerless, one `mode_mass` string per line
      - column_sample_names.tsv — headerless, one sample name per line
      - parquet has string `row` and `col` columns referencing those names

    `mass_offset` shifts the linspace start so caller can create disjoint or
    overlapping feature sets. Default 0 → identical masses for same n_features.
    """
    ds_dir = tmp_path / name
    ds_dir.mkdir()

    # Feature names as "mode_mass" strings (matches preparation output).
    masses = np.round(np.linspace(100 + mass_offset, 500 + mass_offset, n_features), 4)
    feature_names = [f'positive_{m}' for m in masses]

    sample_names = [f'{name}_sample_{i}' for i in range(n_samples)]

    # Sparse matrix parquet — COO with string row/col labels (not integer indices).
    mat = sparse.random(n_features, n_samples, density=0.3, format='coo', random_state=42)
    df = pd.DataFrame({
        'row': [feature_names[r] for r in mat.row],
        'col': [sample_names[c] for c in mat.col],
        'data': mat.data,
    })
    parquet_path = ds_dir / f'{name}_sparse_matrix.parquet'
    df.to_parquet(parquet_path)

    # Row features — headerless single-column TSV
    row_path = ds_dir / 'row_feature_names.tsv'
    row_path.write_text('\n'.join(feature_names) + '\n')

    # Column samples — headerless single-column TSV
    col_path = ds_dir / 'column_sample_names.tsv'
    col_path.write_text('\n'.join(sample_names) + '\n')

    # Metadata
    meta = {
        'base_name': [f'{name}_raw_{i}' for i in range(n_samples)],
        'sample_id': [f'{name}_sample_{i}' for i in range(n_samples)],
    }
    if extra_meta_cols:
        for col_name, values in extra_meta_cols.items():
            meta[col_name] = values
    meta_df = pd.DataFrame(meta)
    meta_path = ds_dir / 'metadata.csv'
    meta_df.to_csv(meta_path, index=False)

    return {
        'parquet': str(parquet_path),
        'row': str(row_path),
        'column': str(col_path),
        'metadata': str(meta_path),
    }


def test_merge_two_datasets_basic(tmp_path):
    """Merge two datasets: combined output has correct dimensions and dataset_id column."""
    ds1 = _write_test_dataset(tmp_path, 'batch1', n_samples=5, n_features=10)
    ds2 = _write_test_dataset(tmp_path, 'batch2', n_samples=3, n_features=10)

    out_dir = tmp_path / 'merged'
    out_dir.mkdir()

    result = merge_datasets_impl(
        parquet_paths=[ds1['parquet'], ds2['parquet']],
        row_paths=[ds1['row'], ds2['row']],
        column_paths=[ds1['column'], ds2['column']],
        metadata_paths=[ds1['metadata'], ds2['metadata']],
        dataset_names=['batch1', 'batch2'],
        output_dir=str(out_dir),
        serial_number='TEST001',
        dataset_uid=99,
    )

    assert result['sample_number'] == 8  # 5 + 3
    assert result['feature_number'] == 10
    assert result['status'] == 'completed'

    # Check merged metadata has dataset_id column
    merged_meta = pd.read_csv(out_dir / 'metadata.csv')
    assert 'dataset_id' in merged_meta.columns
    assert set(merged_meta['dataset_id']) == {'batch1', 'batch2'}
    assert len(merged_meta) == 8

    # Check column_sample_names.tsv (headerless, one sample per line)
    col_lines = (out_dir / 'column_sample_names.tsv').read_text().strip().splitlines()
    assert len(col_lines) == 8

    # Check row_feature_names.tsv (headerless, one mode_mass per line)
    row_lines = (out_dir / 'row_feature_names.tsv').read_text().strip().splitlines()
    assert len(row_lines) == 10


def test_merge_metadata_union_join(tmp_path):
    """Extra metadata columns are union-joined; missing values filled with NA."""
    ds1 = _write_test_dataset(
        tmp_path, 'ds1', n_samples=3, n_features=5,
        extra_meta_cols={'batch': ['A', 'A', 'B']},
    )
    ds2 = _write_test_dataset(
        tmp_path, 'ds2', n_samples=2, n_features=5,
        extra_meta_cols={'treatment': ['control', 'treated']},
    )

    out_dir = tmp_path / 'merged'
    out_dir.mkdir()

    merge_datasets_impl(
        parquet_paths=[ds1['parquet'], ds2['parquet']],
        row_paths=[ds1['row'], ds2['row']],
        column_paths=[ds1['column'], ds2['column']],
        metadata_paths=[ds1['metadata'], ds2['metadata']],
        dataset_names=['ds1', 'ds2'],
        output_dir=str(out_dir),
        serial_number='TEST002',
        dataset_uid=100,
    )

    merged_meta = pd.read_csv(out_dir / 'metadata.csv')
    assert 'batch' in merged_meta.columns
    assert 'treatment' in merged_meta.columns
    # ds2 rows should have NaN for 'batch'
    ds2_rows = merged_meta[merged_meta['dataset_id'] == 'ds2']
    assert ds2_rows['batch'].isna().all()
    # ds1 rows should have NaN for 'treatment'
    ds1_rows = merged_meta[merged_meta['dataset_id'] == 'ds1']
    assert ds1_rows['treatment'].isna().all()


def test_merge_feature_union(tmp_path):
    """When datasets have disjoint features, the merged output contains the union."""
    ds1 = _write_test_dataset(tmp_path, 'ds1', n_samples=3, n_features=5)
    # Offset ds2's masses by 1000 so the two feature sets are disjoint.
    ds2 = _write_test_dataset(tmp_path, 'ds2', n_samples=2, n_features=8, mass_offset=1000)

    out_dir = tmp_path / 'merged'
    out_dir.mkdir()

    result = merge_datasets_impl(
        parquet_paths=[ds1['parquet'], ds2['parquet']],
        row_paths=[ds1['row'], ds2['row']],
        column_paths=[ds1['column'], ds2['column']],
        metadata_paths=[ds1['metadata'], ds2['metadata']],
        dataset_names=['ds1', 'ds2'],
        output_dir=str(out_dir),
        serial_number='TEST003',
        dataset_uid=101,
    )

    row_lines = (out_dir / 'row_feature_names.tsv').read_text().strip().splitlines()
    assert result['feature_number'] == len(row_lines)
    assert result['sample_number'] == 5  # 3 + 2
