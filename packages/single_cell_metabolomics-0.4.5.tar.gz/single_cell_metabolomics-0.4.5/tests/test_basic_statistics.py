"""Tests for basic_statistics.py — focusing on na_count / na_pct using the
definition-true COO-sparse formula:

    na_count = (sample_count * feature_count)
             - COUNT(*) WHERE value IS NOT NULL AND value <> 0
"""
import pytest
import pyarrow as pa
import pyarrow.parquet as pq
from single_cell_metabolomics.basic_statistics import BasicStatsExecutor


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _write_matrix(tmp_path, rows, cols, vals, row_names=None, col_names=None):
    """Write a minimal COO parquet + sidecar TSVs to tmp_path.

    rows / cols / vals: parallel lists for the stored (non-zero) entries.
    row_names: feature names (one per line, headerless). Defaults to unique
               values in `rows` when using string names.
    col_names: sample names (one per line, headerless). Defaults to unique
               values in `cols` when using string names.
    """
    table = pa.table({"row": rows, "col": cols, "value": vals})
    parquet_path = str(tmp_path / "matrix.parquet")
    pq.write_table(table, parquet_path)

    if row_names is None:
        # preserve insertion order
        seen = {}
        for r in rows:
            seen[r] = None
        row_names = list(seen.keys())
    if col_names is None:
        seen = {}
        for c in cols:
            seen[c] = None
        col_names = list(seen.keys())

    row_tsv = tmp_path / "row.tsv"
    row_tsv.write_text("\n".join(row_names) + "\n")

    col_tsv = tmp_path / "col.tsv"
    col_tsv.write_text("\n".join(col_names) + "\n")

    return parquet_path, str(row_tsv), str(col_tsv)


# ---------------------------------------------------------------------------
# na_count contract tests
# ---------------------------------------------------------------------------

def test_na_count_pure_coo(tmp_path):
    """Pure COO (zero-free): 5 features × 4 samples = 20 cells total.
    7 stored rows, all non-zero non-null → na_count == 20 - 7 == 13.
    """
    features = ["f1", "f2", "f3", "f4", "f5"]
    samples = ["s1", "s2", "s3", "s4"]
    row_entries = ["f1", "f1", "f2", "f3", "f3", "f4", "f5"]
    col_entries = ["s1", "s2", "s1", "s2", "s3", "s4", "s1"]
    val_entries = [1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0]

    parquet, row_tsv, col_tsv = _write_matrix(
        tmp_path, row_entries, col_entries, val_entries,
        row_names=features, col_names=samples,
    )

    ex = BasicStatsExecutor(
        matrix_data_path=parquet,
        matrix_row_path=row_tsv,
        matrix_column_path=col_tsv,
        metadata_path="",
    )
    stats = ex.compute_stats()
    ex.close()

    assert stats["counts"]["sample_count"] == 4
    assert stats["counts"]["feature_count"] == 5
    assert stats["counts"]["na_count"] == 13, (
        f"Expected na_count=13 for pure COO (20 cells - 7 stored), "
        f"got {stats['counts']['na_count']}"
    )
    expected_pct = round(13 / 20 * 100, 4)
    assert stats["counts"]["na_pct"] == expected_pct


def test_na_count_mixed_explicit_zeros(tmp_path):
    """Mixed matrix: 5 features × 4 samples = 20 cells.
    7 non-zero non-null stored rows + 2 explicit value=0 rows.
    Explicit zeros are treated as NA → na_count == 20 - 7 == 13.
    """
    features = ["f1", "f2", "f3", "f4", "f5"]
    samples = ["s1", "s2", "s3", "s4"]
    row_entries = ["f1", "f1", "f2", "f3", "f3", "f4", "f5", "f2", "f4"]
    col_entries = ["s1", "s2", "s1", "s2", "s3", "s4", "s1", "s3", "s2"]
    # Last two entries are explicit zeros — treated as NA by definition
    val_entries = [1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 0.0, 0.0]

    parquet, row_tsv, col_tsv = _write_matrix(
        tmp_path, row_entries, col_entries, val_entries,
        row_names=features, col_names=samples,
    )

    ex = BasicStatsExecutor(
        matrix_data_path=parquet,
        matrix_row_path=row_tsv,
        matrix_column_path=col_tsv,
        metadata_path="",
    )
    stats = ex.compute_stats()
    ex.close()

    assert stats["counts"]["sample_count"] == 4
    assert stats["counts"]["feature_count"] == 5
    # The 2 explicit-zero rows are NOT counted as non-zero non-null,
    # so na_count = 20 - 7 = 13 (same as pure COO with same real entries).
    assert stats["counts"]["na_count"] == 13, (
        f"Expected na_count=13 (zeros counted as NA), "
        f"got {stats['counts']['na_count']}"
    )
    expected_pct = round(13 / 20 * 100, 4)
    assert stats["counts"]["na_pct"] == expected_pct


def test_na_count_empty_matrix(tmp_path):
    """Empty matrix (0 stored rows): na_count == 0, na_pct == 0.0 (no division by zero)."""
    # Write an empty parquet with the right schema
    table = pa.table({
        "row": pa.array([], type=pa.utf8()),
        "col": pa.array([], type=pa.utf8()),
        "value": pa.array([], type=pa.float64()),
    })
    parquet_path = str(tmp_path / "matrix.parquet")
    pq.write_table(table, parquet_path)

    # Sidecar TSVs can be empty as well (no features / no samples)
    row_tsv = tmp_path / "row.tsv"
    row_tsv.write_text("")
    col_tsv = tmp_path / "col.tsv"
    col_tsv.write_text("")

    ex = BasicStatsExecutor(
        matrix_data_path=parquet_path,
        matrix_row_path=str(row_tsv),
        matrix_column_path=str(col_tsv),
        metadata_path="",
    )
    stats = ex.compute_stats()
    ex.close()

    assert stats["counts"]["sample_count"] == 0
    assert stats["counts"]["feature_count"] == 0
    assert stats["counts"]["na_count"] == 0, (
        f"Expected na_count=0 for empty matrix, got {stats['counts']['na_count']}"
    )
    assert stats["counts"]["na_pct"] == 0.0, (
        f"Expected na_pct=0.0 for empty matrix, got {stats['counts']['na_pct']}"
    )
