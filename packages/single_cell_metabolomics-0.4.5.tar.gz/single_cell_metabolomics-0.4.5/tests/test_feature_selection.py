# ylclab-single-cell-metabolomics/tests/test_feature_selection.py
import json
import numpy as np
import pandas as pd
import pyarrow as pa
import pyarrow.parquet as pq
import pytest
from pathlib import Path


# ---------------------------------------------------------------------------
# Fixture - 20 samples x 50 features COO parquet with string row/col names
# ---------------------------------------------------------------------------
@pytest.fixture
def fs_data(tmp_path):
    """Create a 20 samples x 50 features COO parquet with string names."""
    rng = np.random.default_rng(42)
    n_samples = 20
    n_features = 50

    features = [f"positive_{100 + i * 0.5}" for i in range(n_features)]
    samples = [f"sample_{j}" for j in range(n_samples)]

    # Build COO rows with string row/col (production format)
    rows = []
    for feat in features:
        for samp in samples:
            rows.append({
                'row': feat,
                'col': samp,
                'value': float(rng.uniform(10, 10000)),
            })

    df = pd.DataFrame(rows)
    parquet_path = str(tmp_path / 'matrix.parquet')
    pq.write_table(pa.Table.from_pandas(df, preserve_index=False), parquet_path)

    # Row TSV - headerless single column (matches what feature_selection reads)
    row_tsv = tmp_path / 'row.tsv'
    row_tsv.write_text('\n'.join(features))

    # Column TSV - headerless single column
    col_tsv = tmp_path / 'col.tsv'
    col_tsv.write_text('\n'.join(samples))

    return {
        'parquet': parquet_path,
        'row_tsv': str(row_tsv),
        'col_tsv': str(col_tsv),
        'tmp_path': tmp_path,
        'features': features,
        'samples': samples,
    }


def run_feature_selection(fs_data, tmp_path, method='dispersion', n_top=10):
    """Helper: invoke the feature selection CLI as a function."""
    from single_cell_metabolomics.feature_selection import select_features
    from typer.testing import CliRunner
    from single_cell_metabolomics.feature_selection import app

    runner = CliRunner()
    out_parquet = str(tmp_path / 'out.parquet')
    out_row = str(tmp_path / 'out_row.tsv')
    out_col = str(tmp_path / 'out_col.tsv')
    out_sentinel = str(tmp_path / 'sentinel.json')

    result = runner.invoke(app, [
        'select-features',
        '--serial-number', 'TEST001',
        '--dataset-uid', '1',
        '--parquet-path', fs_data['parquet'],
        '--row-path', fs_data['row_tsv'],
        '--column-path', fs_data['col_tsv'],
        '--analysis-id', '104',
        '--selection-method', method,
        '--n-top-features', str(n_top),
        '--output-parquet-path', out_parquet,
        '--output-row-path', out_row,
        '--output-column-path', out_col,
        '--output-sentinel', out_sentinel,
    ])
    if result.exit_code != 0:
        raise RuntimeError(f"CLI failed (exit {result.exit_code}): {result.output}\n{result.exception}")

    return {
        'parquet': out_parquet,
        'row_tsv': out_row,
        'col_tsv': out_col,
        'sentinel': out_sentinel,
        'output': result.output,
    }


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

def test_dispersion_selects_n_top(fs_data, tmp_path):
    """Dispersion method with n_top=10 returns exactly 10 features."""
    out = run_feature_selection(fs_data, tmp_path, method='dispersion', n_top=10)
    out_df = pq.read_table(out['parquet']).to_pandas()
    distinct_features = out_df['row'].nunique()
    assert distinct_features == 10, f"Expected 10 features, got {distinct_features}"


def test_variance_selects_n_top(fs_data, tmp_path):
    """Variance method with n_top=10 returns exactly 10 features."""
    out = run_feature_selection(fs_data, tmp_path, method='variance', n_top=10)
    out_df = pq.read_table(out['parquet']).to_pandas()
    distinct_features = out_df['row'].nunique()
    assert distinct_features == 10, f"Expected 10 features, got {distinct_features}"


def test_output_parquet_is_coo(fs_data, tmp_path):
    """Output parquet has row, col, value columns (COO format)."""
    out = run_feature_selection(fs_data, tmp_path, method='variance', n_top=10)
    out_df = pq.read_table(out['parquet']).to_pandas()
    assert set(out_df.columns) == {'row', 'col', 'value'}, (
        f"Expected COO columns, got {list(out_df.columns)}"
    )


def test_output_row_tsv_matches_parquet(fs_data, tmp_path):
    """Output row TSV line count matches distinct features in output parquet."""
    out = run_feature_selection(fs_data, tmp_path, method='dispersion', n_top=10)
    out_df = pq.read_table(out['parquet']).to_pandas()
    distinct_features = out_df['row'].nunique()

    row_lines = Path(out['row_tsv']).read_text().strip().split('\n')
    # Filter out empty lines
    row_lines = [line for line in row_lines if line.strip()]
    assert len(row_lines) == distinct_features, (
        f"Row TSV has {len(row_lines)} lines but parquet has {distinct_features} distinct features"
    )


def test_n_top_larger_than_total_keeps_all(fs_data, tmp_path):
    """If n_top > total features, keep all features."""
    out = run_feature_selection(fs_data, tmp_path, method='variance', n_top=999)
    out_df = pq.read_table(out['parquet']).to_pandas()
    distinct_features = out_df['row'].nunique()
    assert distinct_features == len(fs_data['features']), (
        f"Expected all {len(fs_data['features'])} features, got {distinct_features}"
    )


def test_emit_sentinel_writes_json(fs_data, tmp_path):
    """Sentinel JSON has required summary fields."""
    out = run_feature_selection(fs_data, tmp_path, method='dispersion', n_top=10)
    sentinel = json.loads(Path(out['sentinel']).read_text())

    assert sentinel['status'] == 'completed'
    assert 'summary' in sentinel
    summary = sentinel['summary']
    assert summary['total_features'] == len(fs_data['features'])
    assert summary['selected_features'] == 10
    assert summary['selection_method'] == 'dispersion'
    assert sentinel['storage_path'].startswith('/')
