import typer
import duckdb
import numpy as np
import pandas as pd
import pyarrow as pa
import pyarrow.parquet as pq
import json
import os
import shutil
from pathlib import Path
from loguru import logger
from single_cell_metabolomics.config import write_error_sentinel

app = typer.Typer(add_completion=False)


@app.command()
def select_features(
    serial_number: str = '',
    dataset_uid: int = 0,
    parquet_path: str = '',
    row_path: str = '',
    column_path: str = '',
    analysis_id: int = typer.Option(..., help="Analysis ID (104 for SC, 204 for LCM)"),
    selection_method: str = 'dispersion',
    n_top_features: int = 2000,
    output_parquet_path: str = 'feature_selected.parquet',
    output_row_path: str = 'row_feature_names.tsv',
    output_column_path: str = 'column_sample_names.tsv',
    output_sentinel: str = 'feature_selection_metadata.json',
):
    """Select highly variable features from a metabolomics matrix."""
    try:
        conn = duckdb.connect(database=':memory:')

        # Read the parquet into DuckDB
        conn.read_parquet(parquet_path).create('matrix_data')

        # Get total feature count
        total_features = conn.sql(
            'SELECT COUNT(DISTINCT row) FROM matrix_data'
        ).fetchone()[0]
        total_samples = conn.sql(
            'SELECT COUNT(DISTINCT col) FROM matrix_data'
        ).fetchone()[0]
        logger.info(f'Input matrix: {total_samples} samples x {total_features} features')

        # Compute per-feature statistics
        stats_df = conn.sql("""
            SELECT row AS feature,
                   COUNT(*) AS n_detected,
                   AVG(value) AS mean_val,
                   VAR_POP(value) AS variance
            FROM matrix_data
            GROUP BY row
        """).to_df()

        # Handle edge case: nTopFeatures >= total features
        n_select = min(n_top_features, total_features)
        if n_top_features >= total_features:
            logger.warning(
                f'Requested {n_top_features} features but only {total_features} available; keeping all'
            )

        if selection_method == 'dispersion':
            # Mean-binned normalized dispersion (like scanpy HVG seurat flavor)
            stats_df['dispersion'] = stats_df['variance'] / stats_df['mean_val'].clip(1e-12)
            stats_df['log_dispersion'] = np.log1p(stats_df['dispersion'])
            stats_df['log_mean'] = np.log1p(stats_df['mean_val'])

            # Bin features by mean into 20 bins
            n_bins = min(20, len(stats_df))
            stats_df['mean_bin'] = pd.qcut(
                stats_df['log_mean'], q=n_bins, labels=False, duplicates='drop'
            )

            # Normalize dispersion within each bin (z-score)
            stats_df['norm_dispersion'] = stats_df.groupby('mean_bin')['log_dispersion'].transform(
                lambda x: (x - x.mean()) / x.std().clip(1e-12)
            )
            stats_df = stats_df.sort_values('norm_dispersion', ascending=False)
            score_col = 'norm_dispersion'
        elif selection_method == 'variance':
            stats_df = stats_df.sort_values('variance', ascending=False)
            score_col = 'variance'
        else:
            raise ValueError(f"Unknown selection method: '{selection_method}'")

        # Select top N features
        selected = stats_df.head(n_select)
        selected_features = selected['feature'].tolist()
        logger.info(f'Selected {len(selected_features)} features by {selection_method}')

        # Write filtered parquet using DuckDB COPY (memory efficient)
        # Create a temp table with selected features for efficient filtering
        conn.execute("CREATE TABLE selected_features (feature VARCHAR)")
        conn.executemany(
            "INSERT INTO selected_features VALUES (?)",
            [(str(f),) for f in selected_features],
        )

        conn.sql(f"""
            COPY (
                SELECT m.row, m.col, m.value
                FROM matrix_data m
                WHERE CAST(m.row AS VARCHAR) IN (SELECT feature FROM selected_features)
            ) TO '{output_parquet_path}' (FORMAT PARQUET)
        """)
        logger.info(f'Wrote filtered parquet to {output_parquet_path}')

        # Write row feature names (selected only, single column headerless)
        # Read existing row names TSV to get name mapping
        row_tsv = pd.read_csv(
            row_path,
            sep='\t',
            header=0 if '\t' in open(row_path).readline() else None,
        )
        if 'index' in row_tsv.columns:
            if 'mode' in row_tsv.columns and 'mass' in row_tsv.columns:
                row_tsv['_name'] = row_tsv['mode'].astype(str) + '_' + row_tsv['mass'].astype(str)
            elif 'sample' in row_tsv.columns:
                row_tsv['_name'] = row_tsv['sample'].astype(str)
            else:
                row_tsv['_name'] = row_tsv.iloc[:, 0].astype(str)
        else:
            row_tsv['_name'] = row_tsv.iloc[:, 0].astype(str)

        # Write selected feature names as single-column headerless TSV
        selected_names = [str(f) for f in selected_features]
        pd.Series(selected_names).to_csv(output_row_path, sep='\t', index=False, header=False)
        logger.info(f'Wrote {len(selected_names)} feature names to {output_row_path}')

        # Copy column names unchanged
        if os.path.abspath(column_path) != os.path.abspath(output_column_path):
            shutil.copy2(column_path, output_column_path)

        # Build sentinel
        top_50 = selected.head(50)[['feature', score_col]].rename(columns={score_col: 'score'})
        feature_stats = [
            {'feature': str(r['feature']), 'score': round(float(r['score']), 4)}
            for _, r in top_50.iterrows()
        ]

        sentinel = {
            'serial_number': serial_number,
            'dataset_uid': dataset_uid,
            'pipeline_stage': 'analysis',
            'analysis_id': analysis_id,
            'storage_path': os.path.abspath(output_parquet_path),
            'row_path': os.path.abspath(output_row_path),
            'column_path': os.path.abspath(output_column_path),
            'summary': {
                'total_features': int(total_features),
                'selected_features': len(selected_features),
                'selection_method': selection_method,
            },
            'feature_stats': feature_stats,
            'status': 'completed',
        }

        metadata_file = Path(output_sentinel)
        metadata_file.write_text(json.dumps(sentinel, indent=2))
        logger.info(f'Wrote sentinel to {metadata_file.resolve()}')
        print(
            f'__FEATURE_SELECTION_METADATA_START__{json.dumps(sentinel)}'
            f'__FEATURE_SELECTION_METADATA_END__'
        )
        logger.success(
            f'Feature selection complete: {len(selected_features)}/{total_features} features selected'
        )

        conn.close()
    except Exception as e:
        write_error_sentinel(output_sentinel, serial_number, dataset_uid, analysis_id, e)
        raise


@app.callback()
def callback():
    pass
