# %%
import os
import json
import duckdb
from pathlib import Path
import typer
from loguru import logger
from single_cell_metabolomics.config import write_error_sentinel
# from tqdm import tqdm


# Notice: DuckDB use Lazy Evaluation for DuckDBPyRelation objects.
# %%
class FilterExecutor:
    @staticmethod
    def _build_name_table_sql(table_name: str, file_path: str) -> str:
        """Build SQL to create a name table from a TSV file.
        Always produces a table with columns: idx (INTEGER), name (VARCHAR).
        Handles formats:
        1. Row: mode, mass, index (with header) → name = mode_mass, idx = index
        2. Column: sample, index (with header) → name = sample, idx = index
        3. Single-column headerless → name = column0, idx = ROW_NUMBER() - 1
        """
        with open(file_path) as f:
            first_line = f.readline().strip()
        if '\t' in first_line:
            # Multi-column with header
            if 'mode' in first_line and 'mass' in first_line:
                return f"""
                    CREATE TABLE {table_name} AS
                    SELECT "index" AS idx, (mode || '_' || CAST(mass AS VARCHAR)) AS name
                    FROM read_csv('{file_path}', sep='\t', header=true, auto_detect=true)
                """
            elif 'sample' in first_line:
                return f"""
                    CREATE TABLE {table_name} AS
                    SELECT "index" AS idx, sample AS name
                    FROM read_csv('{file_path}', sep='\t', header=true, auto_detect=true)
                """
            else:
                return f"""
                    CREATE TABLE {table_name} AS
                    SELECT "index" AS idx, FIRST(COLUMNS(* EXCLUDE("index")))::VARCHAR AS name
                    FROM read_csv('{file_path}', sep='\t', header=true, auto_detect=true)
                """
        else:
            # Single-column headerless — generate idx as 0-based row number
            return f"""
                CREATE TABLE {table_name} AS
                SELECT (ROW_NUMBER() OVER () - 1)::INTEGER AS idx, column0 AS name
                FROM read_csv('{file_path}', sep='\t', header=false, columns={{'column0': 'VARCHAR'}})
            """

    def __init__(
            self,
            matrix_data_path: str,
            matrix_row_path: str,
            matrix_column_path: str,
            metadata_path: str
        ):
        self.matrix_data_path = matrix_data_path
        self.matrix_row_path = matrix_row_path
        self.matrix_column_path = matrix_column_path
        self.metadata_path = metadata_path

        self.conn = duckdb.connect(database = ":memory:")
        self.conn.read_parquet(matrix_data_path).create('matrix_data')
        # Load name TSVs — handles both multi-column (mode/mass/index) and single-column headerless
        self.conn.sql(self._build_name_table_sql('matrix_row', matrix_row_path))
        self.conn.sql(self._build_name_table_sql('matrix_column', matrix_column_path))
        self.conn.read_csv(metadata_path).create('metadata')


    def close(self) -> None:
        self.conn.close()

    def compute_stats_before(self) -> dict:
        """Capture stats from the original (pre-filter) matrix."""
        before_sample_count = self.conn.sql(
            'SELECT COUNT(DISTINCT col) FROM matrix_data'
        ).fetchone()[0]
        before_feature_count = self.conn.sql(
            'SELECT COUNT(DISTINCT row) FROM matrix_data'
        ).fetchone()[0]
        non_na = self.conn.sql(
            'SELECT COUNT(*) FROM matrix_data WHERE value IS NOT NULL AND value <> 0'
        ).fetchone()[0]
        before_na_count = (before_sample_count * before_feature_count) - non_na

        fps = self.conn.sql(
            'SELECT col, COUNT(value) AS cnt FROM matrix_data GROUP BY col ORDER BY col'
        ).to_df()
        spf = self.conn.sql(
            'SELECT row, COUNT(value) AS cnt FROM matrix_data GROUP BY row ORDER BY row'
        ).to_df()

        return {
            'before_sample_count': int(before_sample_count),
            'before_feature_count': int(before_feature_count),
            'before_na_count': int(before_na_count),
            'features_per_sample_before': fps['cnt'].tolist(),
            'samples_per_feature_before': spf['cnt'].tolist(),
        }

    def compute_stats_after(self) -> dict:
        """Capture stats from the filtered matrix (call after remove_unused_*)."""
        after_sample_count = self.conn.sql(
            'SELECT COUNT(*) FROM matrix_column'
        ).fetchone()[0]
        after_feature_count = self.conn.sql(
            'SELECT COUNT(*) FROM matrix_row'
        ).fetchone()[0]
        non_na = self.conn.sql(
            'SELECT COUNT(*) FROM matrix_data WHERE value IS NOT NULL AND value <> 0'
        ).fetchone()[0]
        after_na_count = (after_sample_count * after_feature_count) - non_na

        fps = self.conn.sql(
            'SELECT col, COUNT(value) AS cnt FROM matrix_data GROUP BY col ORDER BY col'
        ).to_df()
        spf = self.conn.sql(
            'SELECT row, COUNT(value) AS cnt FROM matrix_data GROUP BY row ORDER BY row'
        ).to_df()

        return {
            'after_sample_count': int(after_sample_count),
            'after_feature_count': int(after_feature_count),
            'after_na_count': int(after_na_count),
            'features_per_sample_after': fps['cnt'].tolist(),
            'samples_per_feature_after': spf['cnt'].tolist(),
        }

    def emit_sentinel(
        self,
        serial_number: str,
        dataset_uid: int,
        analysis_id: int,
        storage_path: str,
        row_path: str,
        column_path: str,
        stats_before: dict,
        stats_after: dict,
    ) -> None:
        sentinel = {
            "serial_number": serial_number,
            "dataset_uid": dataset_uid,
            "pipeline_stage": "analysis",
            "analysis_id": analysis_id,
            "storage_path": os.path.abspath(storage_path),
            "row_path": os.path.abspath(row_path),
            "column_path": os.path.abspath(column_path),
            **stats_before,
            **stats_after,
            "status": "completed",
        }
        json_str = json.dumps(sentinel)
        print(f"__FILTRATION_METADATA_START__{json_str}__FILTRATION_METADATA_END__")
        with open("filtration_metadata.json", "w") as f:
            json.dump(sentinel, f)

    def update_table_with_sql(
            self,
            table_name: str,
            query_str: str
        ) -> None:
        """
        Update a table in the DuckDB connection using a SQL query.
        Args:
            table_name (str): The name of the table to update.
            query_str (str): The SQL query to create the new table.
        Returns:
            None
        """
        self.conn.sql(query_str).create('temp_table')
        self.conn.sql(f'DROP TABLE IF EXISTS {table_name}')
        self.conn.sql(f'ALTER TABLE temp_table RENAME TO {table_name}')

    def validate_min_counts(
            self,
            min_features_for_sample: int = 200,
            min_samples_for_feature: int = 3
        ) -> bool:
        """
        Validate the filtering results by checking the minimum feature and sample counts.
        Args:
            min_features_for_sample (int): Minimum number of features required for each sample.
            min_samples_for_feature (int): Minimum number of samples required for each feature.
        Returns:
            Tuple[int, int]: Minimum feature count per sample and minimum sample count per feature.
        """
        query_str = f'''
        WITH
            FeatureCounts AS (
                SELECT
                    col,
                    COUNT(value) AS feature_count
                FROM matrix_data
                GROUP BY col
            ),
            SampleCounts AS (
                SELECT
                    row,
                    COUNT(value) AS sample_count
                FROM matrix_data
                GROUP BY row
            )
        SELECT
            (SELECT MIN(feature_count) FROM FeatureCounts) AS min_feature_count,
            (SELECT MIN(sample_count) FROM SampleCounts) AS min_sample_count
        '''
        result_df = self.conn.sql(query_str).to_df()
        min_feature_count = result_df.iat[0, 0]
        min_sample_count = result_df.iat[0, 1]
        # min_feature_count = self.matrix_data \
        #     .aggregate('col, count(value) as feature_count', group_expr='col') \
        #     .min('feature_count') \
        #     .to_df().iat[0, 0]
        # min_sample_count = self.matrix_data \
        #     .aggregate('row, count(value) as sample_count', group_expr='row') \
        #     .min('sample_count') \
        #     .to_df().iat[0, 0]
        logger.info(f'Validation results - Minimum feature count per sample: {min_feature_count}, Minimum sample count per feature: {min_sample_count}.')
        if min_feature_count < min_features_for_sample:
            logger.warning(f'Minimum feature count per sample is {min_feature_count}, which is less than the threshold of {min_features_for_sample}.')
            return False
        if min_sample_count < min_samples_for_feature:
            logger.warning(f'Minimum sample count per feature is {min_sample_count}, which is less than the threshold of {min_samples_for_feature}.')
            return False
        return True

    def filter_min_counts(
            self,
            min_features_for_sample: int = 200,
            min_samples_for_feature: int = 3
        ) -> None:
        """
        Filter the data based on minimum feature and sample counts.
        Args:
            min_features_for_sample (int): Minimum number of features required for each sample.
            min_samples_for_feature (int): Minimum number of samples required for each feature.
        Returns:
            duckdb.DuckDBPyConnection: The filtered data table.
        """
        logger.info(f'Filtering data with min_features_for_sample={min_features_for_sample} and min_samples_for_feature={min_samples_for_feature}.')
        query_str = f'''
        WITH
            FilteredSamples AS (
                SELECT
                    col,
                    COUNT(value) AS feature_count
                FROM matrix_data
                GROUP BY col
                HAVING feature_count >= {min_features_for_sample}
            ),
            FilteredFeatures AS (
                SELECT
                    row,
                    COUNT(value) AS sample_count
                FROM matrix_data
                GROUP BY row
                HAVING sample_count >= {min_samples_for_feature}
            )
        SELECT *
        FROM matrix_data
        WHERE col IN (SELECT col FROM FilteredSamples)
        AND row IN (SELECT row FROM FilteredFeatures)
        '''
        # self.conn.sql(query_str).create('matrix_new_data')
        # self.conn.sql('DROP TABLE matrix_data')
        # self.conn.sql('ALTER TABLE matrix_new_data RENAME TO matrix_data')
        self.update_table_with_sql('matrix_data', query_str)

    def filter_strict_min_counts(
            self,
            min_features_for_sample: int = 200,
            min_samples_for_feature: int = 3
        ) -> None:
        """
        Strictly filter the data based on minimum feature and sample counts until convergence.
        Args:
            min_features_for_sample (int): Minimum number of features required for each sample.
            min_samples_for_feature (int): Minimum number of samples required for each feature.
        """
        while True:
            self.filter_min_counts(
                min_features_for_sample,
                min_samples_for_feature
            )
            current_status = self.validate_min_counts(
                min_features_for_sample,
                min_samples_for_feature
            )
            if current_status:
                break
        result_shape = self.conn.sql('SELECT COUNT(*) AS count_rows, COUNT(DISTINCT col) AS count_cols FROM matrix_data').to_df()
        n_unique_rows = self.conn.sql('SELECT COUNT(DISTINCT row) AS count_rows FROM matrix_data').to_df().iat[0, 0]
        n_unique_cols = self.conn.sql('SELECT COUNT(DISTINCT col) AS count_cols FROM matrix_data').to_df().iat[0, 0]
        logger.info(f"Strict filtering completed. Resulting data shape: ({result_shape.iat[0, 0]}, {result_shape.iat[0, 1]}).")
        logger.info(f"Number of unique rows: {n_unique_rows}, Number of unique columns: {n_unique_cols}")

    def filter_blank(
        self,
        blank_column: str,
        blank_value: str,
        blank_method: str = 'maxBlankVsMeanReal',
        blank_ratio: float = 5.0,
    ) -> dict:
        """Remove contamination features based on blank sample comparison, then remove blank samples."""
        if not blank_column or not blank_value:
            logger.info('Blank filtration skipped: blankColumn or blankValue is empty')
            return {'blank_features_removed': 0, 'blank_samples_removed': 0}

        # Check if blank_column exists in metadata
        meta_cols = [r[0] for r in self.conn.sql(
            "SELECT column_name FROM information_schema.columns WHERE table_name = 'metadata'"
        ).fetchall()]
        if blank_column not in meta_cols:
            logger.warning(f'Blank filtration: column "{blank_column}" not found in metadata. Skipping.')
            return {'blank_features_removed': 0, 'blank_samples_removed': 0}

        # Build sample_type table: map each sample to 'blank' or 'real'
        # Metadata rows align positionally with matrix_column rows
        self.conn.sql(f"""
            CREATE OR REPLACE TABLE sample_type AS
            WITH numbered_meta AS (
                SELECT (ROW_NUMBER() OVER () - 1)::INTEGER AS meta_idx,
                       CAST("{blank_column}" AS VARCHAR) AS blank_col_val
                FROM metadata
            )
            SELECT mc.idx, mc.name,
                   CASE WHEN nm.blank_col_val = '{blank_value}' THEN 'blank' ELSE 'real' END AS stype
            FROM matrix_column mc
            LEFT JOIN numbered_meta nm ON mc.idx = nm.meta_idx
        """)

        blank_count = self.conn.sql("SELECT COUNT(*) FROM sample_type WHERE stype = 'blank'").fetchone()[0]
        if blank_count == 0:
            logger.warning(f'No blank samples found where {blank_column} = "{blank_value}". Skipping blank filtration.')
            self.conn.sql('DROP TABLE IF EXISTS sample_type')
            return {'blank_features_removed': 0, 'blank_samples_removed': 0}

        logger.info(f'Found {blank_count} blank samples where {blank_column} = "{blank_value}"')

        # Compute per-feature blank vs real stats and identify features to remove
        if blank_method == 'maxBlankVsMeanReal':
            self.conn.sql(f"""
                CREATE OR REPLACE TABLE features_to_remove AS
                SELECT md.row
                FROM matrix_data md
                JOIN sample_type st ON md.col = st.name
                GROUP BY md.row
                HAVING MAX(CASE WHEN st.stype = 'blank' THEN md.value END)
                     > COALESCE(AVG(CASE WHEN st.stype = 'real' THEN md.value END), 0) / {blank_ratio}
            """)
        elif blank_method == 'meanRatio':
            self.conn.sql(f"""
                CREATE OR REPLACE TABLE features_to_remove AS
                SELECT md.row
                FROM matrix_data md
                JOIN sample_type st ON md.col = st.name
                GROUP BY md.row
                HAVING COALESCE(AVG(CASE WHEN st.stype = 'real' THEN md.value END), 0)
                     / NULLIF(AVG(CASE WHEN st.stype = 'blank' THEN md.value END), 0)
                     < {blank_ratio}
            """)
        elif blank_method == 'medianRatio':
            self.conn.sql(f"""
                CREATE OR REPLACE TABLE features_to_remove AS
                SELECT md.row
                FROM matrix_data md
                JOIN sample_type st ON md.col = st.name
                GROUP BY md.row
                HAVING COALESCE(
                         PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY CASE WHEN st.stype = 'real' THEN md.value END), 0
                       )
                     / NULLIF(
                         PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY CASE WHEN st.stype = 'blank' THEN md.value END), 0
                       )
                     < {blank_ratio}
            """)
        else:
            raise ValueError(f"Unknown blank method: '{blank_method}'")

        n_removed = self.conn.sql('SELECT COUNT(*) FROM features_to_remove').fetchone()[0]
        logger.info(f'Blank filtration ({blank_method}): removing {n_removed} contamination features')

        # Remove contamination features
        if n_removed > 0:
            self.update_table_with_sql('matrix_data', """
                SELECT * FROM matrix_data
                WHERE row NOT IN (SELECT row FROM features_to_remove)
            """)

        # Remove blank samples from matrix_data
        blank_names = [r[0] for r in self.conn.sql("SELECT name FROM sample_type WHERE stype = 'blank'").fetchall()]
        if blank_names:
            names_str = ','.join(f"'{n}'" for n in blank_names)
            self.update_table_with_sql('matrix_data', f"""
                SELECT * FROM matrix_data WHERE col NOT IN ({names_str})
            """)
            logger.info(f'Removed {len(blank_names)} blank samples from matrix')

        # Cleanup
        self.conn.sql('DROP TABLE IF EXISTS features_to_remove')
        self.conn.sql('DROP TABLE IF EXISTS sample_type')

        return {
            'blank_features_removed': int(n_removed),
            'blank_samples_removed': len(blank_names),
        }

    def filter_within_batch(
        self,
        batch_column: str,
        within_batch_threshold: float = 80.0,
        batch_pass_rate: float = 0.0,
    ) -> dict:
        """Remove features inconsistent across batches using two-tier threshold.

        For each feature, in each batch: compute detection rate (% with value > 0).
        Mark batch as PASS if rate >= within_batch_threshold.
        Keep feature if % of PASS batches >= batch_pass_rate.
        """
        if not batch_column:
            logger.info('Within-batch filtration skipped: batchColumn is empty')
            return {'batch_features_removed': 0}

        # Validate batch column exists in metadata
        meta_cols = [r[0] for r in self.conn.sql(
            "SELECT column_name FROM information_schema.columns WHERE table_name = 'metadata'"
        ).fetchall()]
        if batch_column not in meta_cols:
            raise ValueError(
                f"Within-batch filtration: column '{batch_column}' not found in metadata. "
                f"Available columns: {', '.join(meta_cols)}"
            )

        # Build sample-to-batch mapping via positional alignment
        self.conn.sql(f"""
            CREATE OR REPLACE TABLE sample_batch AS
            WITH numbered_meta AS (
                SELECT (ROW_NUMBER() OVER () - 1)::INTEGER AS meta_idx,
                       CAST("{batch_column}" AS VARCHAR) AS batch
                FROM metadata
            )
            SELECT mc.idx, mc.name, nm.batch
            FROM matrix_column mc
            LEFT JOIN numbered_meta nm ON mc.idx = nm.meta_idx
        """)

        # Validate: >= 2 batches
        n_batches = self.conn.sql('SELECT COUNT(DISTINCT batch) FROM sample_batch').fetchone()[0]
        if n_batches < 2:
            self.conn.sql('DROP TABLE IF EXISTS sample_batch')
            raise ValueError(
                f"Within-batch filtration requires at least 2 batches in column '{batch_column}', "
                f"found {n_batches}"
            )

        # Validate: each batch >= 3 samples
        min_batch_size = self.conn.sql(
            'SELECT MIN(cnt) FROM (SELECT batch, COUNT(*) AS cnt FROM sample_batch GROUP BY batch)'
        ).fetchone()[0]
        if min_batch_size < 3:
            self.conn.sql('DROP TABLE IF EXISTS sample_batch')
            raise ValueError(
                f"Within-batch filtration requires at least 3 samples per batch, "
                f"smallest batch has {min_batch_size}"
            )

        logger.info(
            f'Within-batch filtration: {n_batches} batches, '
            f'threshold={within_batch_threshold}%, pass_rate={batch_pass_rate}%'
        )

        # Per feature, per batch: detection rate → PASS/FAIL → batch pass rate → keep/remove
        self.conn.sql(f"""
            CREATE OR REPLACE TABLE batch_features_to_remove AS
            WITH per_batch AS (
                SELECT md.row, sb.batch,
                       COUNT(CASE WHEN md.value > 0 THEN 1 END)::DOUBLE
                       / COUNT(*)::DOUBLE * 100.0 AS detection_pct
                FROM matrix_data md
                JOIN sample_batch sb ON md.col = sb.name
                GROUP BY md.row, sb.batch
            ),
            pass_flags AS (
                SELECT row, batch,
                       CASE WHEN detection_pct >= {within_batch_threshold} THEN 1 ELSE 0 END AS is_pass
                FROM per_batch
            ),
            pass_rates AS (
                SELECT row,
                       SUM(is_pass)::DOUBLE / COUNT(*)::DOUBLE * 100.0 AS pass_rate_pct
                FROM pass_flags
                GROUP BY row
            )
            SELECT row FROM pass_rates
            WHERE pass_rate_pct < {batch_pass_rate}
        """)

        n_removed = self.conn.sql('SELECT COUNT(*) FROM batch_features_to_remove').fetchone()[0]
        logger.info(f'Within-batch filtration: removing {n_removed} features')

        if n_removed > 0:
            self.update_table_with_sql('matrix_data', """
                SELECT * FROM matrix_data
                WHERE row NOT IN (SELECT row FROM batch_features_to_remove)
            """)

        # Cleanup
        self.conn.sql('DROP TABLE IF EXISTS batch_features_to_remove')
        self.conn.sql('DROP TABLE IF EXISTS sample_batch')

        return {'batch_features_removed': int(n_removed)}

    def remove_unused_samples(self) -> None:
        """
        Remove unused samples from the matrix_column table.
        """
        logger.info(f'''Number of distinct columns: {
            self.conn.sql('SELECT COUNT(*) FROM matrix_column').to_df().iat[0, 0]
        }''')
        query_str = f'''
        SELECT * FROM matrix_column
        WHERE name IN (SELECT DISTINCT col FROM matrix_data)
        '''
        self.update_table_with_sql('matrix_column', query_str)
        logger.info(f'''Number of distinct columns after filtering: {
            self.conn.sql('SELECT COUNT(*) FROM matrix_column').to_df().iat[0, 0]
        }''')
    
    def remove_unused_features(self) -> None:
        """
        Remove unused features from the matrix_row table.
        """
        logger.info(f'''Number of distinct rows: {
            self.conn.sql('SELECT COUNT(*) FROM matrix_row').to_df().iat[0, 0]
        }''')
        query_str = f'''
        SELECT * FROM matrix_row
        WHERE name IN (SELECT DISTINCT row FROM matrix_data)
        '''
        self.update_table_with_sql('matrix_row', query_str)
        logger.info(f'''Number of distinct rows after filtering: {
            self.conn.sql('SELECT COUNT(*) FROM matrix_row').to_df().iat[0, 0]
        }''')
    
    def save_results(
            self,
            output_matrix_data_path: str,
            output_matrix_row_path: str,
            output_matrix_column_path: str
        ) -> None:
        """
        Save the filtered results to specified file paths.
        Writes COO parquet with string name row/col values (consistent with
        normalization/batch_correction output). Name TSVs are single-column
        headerless (one name per line).
        """
        Path(output_matrix_data_path).parent.mkdir(parents=True, exist_ok=True)
        Path(output_matrix_row_path).parent.mkdir(parents=True, exist_ok=True)
        Path(output_matrix_column_path).parent.mkdir(parents=True, exist_ok=True)

        # Write COO parquet with string names (for downstream compatibility)
        # matrix_data already has VARCHAR row/col (sample/feature names)
        self.conn.sql(f"""
            COPY (
                SELECT row, col, value FROM matrix_data
            ) TO '{output_matrix_data_path}' (FORMAT PARQUET)
        """)

        # Write name TSVs — single-column headerless (one name per line)
        row_names = self.conn.sql("SELECT name FROM matrix_row").fetchall()
        col_names = self.conn.sql("SELECT name FROM matrix_column").fetchall()
        Path(output_matrix_row_path).write_text('\n'.join(r[0] for r in row_names) + '\n')
        Path(output_matrix_column_path).write_text('\n'.join(c[0] for c in col_names) + '\n')

        logger.info(f"Filtered results saved with string names to {output_matrix_data_path}")

# %%
app = typer.Typer(add_completion=False)

# %%
@app.command()
def filter_and_mask(
    serial_number: str = '',
    dataset_uid: int = 0,
    analysis_id: int = typer.Option(..., help="Analysis ID (101 for Single Cell, 201 for LCM)"),
    # --- input paths ---
    parquet_path: str = '',
    row_path: str = '',
    column_path: str = '',
    metadata_path: str = '',
    # --- detection parameters ---
    detection_method: str = 'percentage',
    min_detection_rate: float = 10.0,
    min_sample_number: int = 3,
    min_feature_number: int = 200,
    strict_mode: str = 'true',
    # --- blank filtration ---
    do_blank_filtration: str = 'true',
    blank_column: str = '',
    blank_value: str = '',
    blank_method: str = 'maxBlankVsMeanReal',
    blank_filtration_ratio: float = 5.0,
    # --- within-batch filtration ---
    do_within_batch_filtration: str = 'true',
    batch_column: str = '',
    within_batch_threshold: float = 80.0,
    batch_pass_rate: float = 0.0,
    # --- output paths ---
    output_parquet_path: str = 'output.parquet',
    output_row_path: str = 'row_feature_names.tsv',
    output_column_path: str = 'column_sample_names.tsv',
):
    """Filter metabolomics data: blank → detection/min-count → within-batch."""
    try:
        import math

        filterExecutor = FilterExecutor(
            matrix_data_path=parquet_path,
            matrix_row_path=row_path,
            matrix_column_path=column_path,
            metadata_path=metadata_path
        )
        stats_before = filterExecutor.compute_stats_before()
        blank_stats = {}
        batch_stats = {}

        # 1. Blank filtration (first — scientific consensus)
        if do_blank_filtration.lower() == 'true':
            blank_stats = filterExecutor.filter_blank(
                blank_column=blank_column,
                blank_value=blank_value,
                blank_method=blank_method,
                blank_ratio=blank_filtration_ratio,
            )

        # 2. Detection rate / min-count filtering
        effective_min_sample = min_sample_number
        if detection_method == 'percentage':
            n_samples = filterExecutor.conn.sql(
                'SELECT COUNT(DISTINCT col) FROM matrix_data'
            ).fetchone()[0]
            effective_min_sample = math.ceil(n_samples * min_detection_rate / 100)
            logger.info(
                f'Detection rate {min_detection_rate}% of {n_samples} samples '
                f'→ min_sample_number={effective_min_sample}'
            )

        if strict_mode.lower() == 'true':
            filterExecutor.filter_strict_min_counts(
                min_features_for_sample=min_feature_number,
                min_samples_for_feature=effective_min_sample,
            )
        else:
            filterExecutor.filter_min_counts(
                min_features_for_sample=min_feature_number,
                min_samples_for_feature=effective_min_sample,
            )

        # 3. Within-batch filtration (last)
        if do_within_batch_filtration.lower() == 'true':
            batch_stats = filterExecutor.filter_within_batch(
                batch_column=batch_column,
                within_batch_threshold=within_batch_threshold,
                batch_pass_rate=batch_pass_rate,
            )

        filterExecutor.remove_unused_features()
        filterExecutor.remove_unused_samples()
        stats_after = filterExecutor.compute_stats_after()
        filterExecutor.save_results(
            output_matrix_data_path=output_parquet_path,
            output_matrix_row_path=output_row_path,
            output_matrix_column_path=output_column_path
        )
        filterExecutor.close()
        filterExecutor.emit_sentinel(
            serial_number=serial_number,
            dataset_uid=dataset_uid,
            analysis_id=analysis_id,
            storage_path=output_parquet_path,
            row_path=output_row_path,
            column_path=output_column_path,
            stats_before={**stats_before, **blank_stats, **batch_stats},
            stats_after=stats_after,
        )
        logger.success("Data filtering complete.")
    except Exception as e:
        write_error_sentinel("filtration_metadata.json", serial_number, dataset_uid, analysis_id, e)
        raise

# %%
@app.callback()
def callback():
    pass

# %%
if __name__ == '__main__':
    app()