"""Merge multiple prepared datasets of the same type into one combined dataset."""
import json
from pathlib import Path

import numpy as np
import pandas as pd
import typer
from scipy import sparse

app = typer.Typer()


def _read_feature_names(path: str) -> list[str]:
    """Read row_feature_names.tsv — headerless, one `mode_mass` string per line."""
    with open(path) as f:
        return [line.strip() for line in f if line.strip()]


def _read_sample_names(path: str) -> list[str]:
    """Read column_sample_names.tsv — headerless, one sample name per line."""
    with open(path) as f:
        return [line.strip() for line in f if line.strip()]


def merge_datasets_impl(
    parquet_paths: list[str],
    row_paths: list[str],
    column_paths: list[str],
    metadata_paths: list[str],
    dataset_names: list[str],
    output_dir: str,
    serial_number: str,
    dataset_uid: int,
) -> dict:
    """
    Merge multiple prepared datasets into one.

    Each dataset has:
    - A sparse matrix parquet (COO format with string row/col names)
    - row_feature_names.tsv (headerless, one mode_mass string per line)
    - column_sample_names.tsv (headerless, one sample name per line)
    - metadata.csv (base_name, sample_id, ...)

    Output is a single merged set of files in output_dir.
    """
    out = Path(output_dir)

    # 1. Read all row features and build union feature set (preserving order)
    per_dataset_features = [_read_feature_names(p) for p in row_paths]
    seen = set()
    union_features = []
    for features in per_dataset_features:
        for f in features:
            if f not in seen:
                seen.add(f)
                union_features.append(f)
    n_features = len(union_features)
    feature_to_idx = {f: i for i, f in enumerate(union_features)}

    # 2. Read all column samples and build merged column list
    per_dataset_samples = [_read_sample_names(p) for p in column_paths]
    merged_samples = []
    for samples in per_dataset_samples:
        merged_samples.extend(samples)
    total_samples = len(merged_samples)
    # Build per-dataset sample-name-to-global-index mapping
    col_offset = 0
    per_dataset_sample_idx = []
    for samples in per_dataset_samples:
        mapping = {name: col_offset + j for j, name in enumerate(samples)}
        per_dataset_sample_idx.append(mapping)
        col_offset += len(samples)

    # 3. Read and remap sparse matrices (string row/col → integer indices)
    merged_rows = []
    merged_cols = []
    merged_data = []

    for i in range(len(parquet_paths)):
        df = pd.read_parquet(parquet_paths[i])
        val_col = 'value' if 'value' in df.columns else 'data'

        sample_idx = per_dataset_sample_idx[i]

        # Map string feature names to global integer indices
        new_rows = df['row'].map(feature_to_idx)
        new_cols = df['col'].map(sample_idx)

        valid = new_rows.notna() & new_cols.notna()
        merged_rows.extend(new_rows[valid].astype(int).tolist())
        merged_cols.extend(new_cols[valid].astype(int).tolist())
        merged_data.extend(df.loc[valid, val_col].tolist())

    # Build merged sparse matrix
    merged_sparse = sparse.coo_matrix(
        (merged_data, (merged_rows, merged_cols)),
        shape=(n_features, total_samples),
    )

    # Write string-named COO parquet (consistent with preparation output)
    merged_parquet_df = pd.DataFrame({
        'row': [union_features[r] for r in merged_sparse.row],
        'col': [merged_samples[c] for c in merged_sparse.col],
        'value': merged_sparse.data,
    })

    # 4. Merge metadata with union join + dataset_id
    meta_dfs = []
    for i, mp in enumerate(metadata_paths):
        if not mp or not Path(mp).exists():
            meta = pd.DataFrame({
                'sample_id': per_dataset_samples[i],
            })
        else:
            meta = pd.read_csv(mp)
        meta['dataset_id'] = dataset_names[i]
        meta_dfs.append(meta)
    merged_meta = pd.concat(meta_dfs, ignore_index=True)

    # 5. Write outputs — headerless single-column TSVs + string COO parquet
    parquet_filename = f'{dataset_uid}_{serial_number}_merged_sparse_matrix.parquet'
    merged_parquet_df.to_parquet(out / parquet_filename)
    (out / 'row_feature_names.tsv').write_text('\n'.join(union_features) + '\n')
    (out / 'column_sample_names.tsv').write_text('\n'.join(merged_samples) + '\n')
    merged_meta.to_csv(out / 'metadata.csv', index=False)

    result = {
        'serial_number': serial_number,
        'dataset_uid': dataset_uid,
        'sample_number': total_samples,
        'feature_number': n_features,
        'pipeline_stage': 'preparation',
        'result_type': 'sparse_matrix_file',
        'storage_path': str(out / parquet_filename),
        'file_size_bytes': (out / parquet_filename).stat().st_size,
        'row_count': len(merged_parquet_df),
        'column_names': merged_samples,
        'status': 'completed',
    }

    return result


@app.command()
def merge_datasets(
    parquet_paths: list[str] = typer.Option(..., help='Parquet file paths (repeat for each dataset)'),
    row_paths: list[str] = typer.Option(..., help='row_feature_names.tsv paths (repeat for each dataset)'),
    column_paths: list[str] = typer.Option(..., help='column_sample_names.tsv paths (repeat for each dataset)'),
    metadata_paths: list[str] = typer.Option(..., help='metadata.csv paths (repeat for each dataset)'),
    dataset_names: list[str] = typer.Option(..., help='Dataset names (repeat for each dataset)'),
    output_dir: str = typer.Option('.', help='Output directory'),
    serial_number: str = typer.Option(..., help='Project serial number'),
    dataset_uid: int = typer.Option(..., help='Merged dataset UID'),
):
    """Merge multiple prepared datasets into one combined dataset."""
    result = merge_datasets_impl(
        parquet_paths=parquet_paths,
        row_paths=row_paths,
        column_paths=column_paths,
        metadata_paths=metadata_paths,
        dataset_names=dataset_names,
        output_dir=output_dir,
        serial_number=serial_number,
        dataset_uid=dataset_uid,
    )

    # Print sentinel for metadata extraction
    sentinel = json.dumps(result)
    print(f'__PREPARATION_METADATA_START__{sentinel}__PREPARATION_METADATA_END__')


if __name__ == '__main__':
    app()
