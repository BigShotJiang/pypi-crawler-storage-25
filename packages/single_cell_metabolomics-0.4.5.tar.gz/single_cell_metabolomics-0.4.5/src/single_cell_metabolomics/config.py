import json
import traceback
from pathlib import Path

import numpy as np
import pandas as pd
from loguru import logger
# from dotenv import load_dotenv
# import os

PROJ_ROOT = Path(__file__).resolve().parents[1]
logger.info(f"PROJ_ROOT path is: {PROJ_ROOT}")


def sanitize_for_json(obj):
    """Recursively replace NaN/Inf with None for JSON-safe serialization.

    Python's json.dumps writes NaN/Inf which is not valid JSON per spec.
    Node.js JSON.parse rejects them. This function replaces them with null.
    """
    if isinstance(obj, float) and (np.isnan(obj) or np.isinf(obj)):
        return None
    if isinstance(obj, dict):
        return {k: sanitize_for_json(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [sanitize_for_json(v) for v in obj]
    if isinstance(obj, np.floating):
        if np.isnan(obj) or np.isinf(obj):
            return None
        return float(obj)
    if isinstance(obj, np.integer):
        return int(obj)
    if isinstance(obj, np.ndarray):
        return sanitize_for_json(obj.tolist())
    return obj

# load_dotenv()
# WORKDIR = os.getenv('WORKDIR')

# DATA_DIR = PROJ_ROOT / "data"
# RAW_DATA_DIR = DATA_DIR / "raw"
# INTERIM_DATA_DIR = DATA_DIR / "interim"
# PROCESSED_DATA_DIR = DATA_DIR / "processed"
# EXTERNAL_DATA_DIR = DATA_DIR / "external"

# MODELS_DIR = PROJ_ROOT / "models"

# REPORTS_DIR = PROJ_ROOT / "reports"
# FIGURES_DIR = REPORTS_DIR / "figures"

# If tqdm is installed, configure loguru with tqdm.write
# https://github.com/Delgan/loguru/issues/135
try:
    from tqdm import tqdm

    logger.remove(0)
    logger.add(lambda msg: tqdm.write(msg, end=""), colorize=True)
except ModuleNotFoundError:
    pass


def write_error_sentinel(
    metadata_filename: str,
    serial_number: str,
    dataset_uid: int,
    analysis_id: int,
    error: Exception,
) -> None:
    """Write an error sentinel JSON so the result handler can mark the job as failed.

    Called from a top-level try/except wrapper in each CLI entry point.
    The result handler checks metadata['status'] == 'failed' and records the error.
    """
    sentinel = {
        "serial_number": serial_number,
        "dataset_uid": dataset_uid,
        "pipeline_stage": "analysis",
        "analysis_id": analysis_id,
        "status": "failed",
        "error_message": str(error),
        "error_type": type(error).__name__,
        "traceback": traceback.format_exc(),
    }
    try:
        metadata_path = Path(metadata_filename)
        metadata_path.write_text(json.dumps(sentinel, indent=2))
        logger.error(f"Wrote error sentinel to {metadata_path.resolve()}: {error}")
    except Exception as write_err:
        logger.error(f"Failed to write error sentinel: {write_err}. Original error: {error}")


def load_coo_parquet(
    matrix_data_path: str,
    matrix_row_path: str,
    matrix_column_path: str,
    sparse: bool = False,
):
    """Load a COO sparse parquet, resolve names, and return as dense or sparse.

    The parquet stores (row, col, value) tuples where row and col are either
    integer indices (from preparation/filtration) or string names (from
    normalization/batch_correction). Both formats are supported.

    Parameters
    ----------
    sparse : bool
        If True, return a scipy.sparse.csr_matrix instead of a dense numpy array.
        Use for memory-efficient loading of ultra-high-dimensional data.

    Returns
    -------
    tuple[np.ndarray | scipy.sparse.csr_matrix, list[str], list[str]]
        ``(matrix, sample_names, feature_names)`` — matrix with named axes.
    """
    import duckdb

    def _read_name_tsv(path: str, name_column: str) -> dict[int, str]:
        """Read a name mapping TSV. Handles two formats:
        1. Multi-column with 'index': e.g., 'sample\\tindex' or 'mode\\tmass\\tindex'
        2. Single-column headerless: just names, one per line (row order = index)
        """
        df = pd.read_csv(path, sep='\t', header=0 if '\t' in open(path).readline() else None)
        if 'index' in df.columns:
            # Multi-column format from preparation's concattsv
            if name_column in df.columns:
                return dict(zip(df['index'], df[name_column]))
            elif 'mode' in df.columns and 'mass' in df.columns:
                return dict(zip(df['index'], df['mode'].astype(str) + '_' + df['mass'].astype(str)))
            else:
                # Fallback: use first non-index column
                col = [c for c in df.columns if c != 'index'][0]
                return dict(zip(df['index'], df[col].astype(str)))
        else:
            # Single-column headerless format from analysis step outputs
            names = df.iloc[:, 0].astype(str).tolist()
            return dict(enumerate(names))

    col_map = _read_name_tsv(matrix_column_path, 'sample')
    row_map = _read_name_tsv(matrix_row_path, 'feature')

    conn = duckdb.connect(database=':memory:')
    conn.read_parquet(matrix_data_path).create('matrix_data')

    df = conn.sql(
        'SELECT col, row, COALESCE(value, 0.0) AS value FROM matrix_data'
    ).to_df()
    conn.close()

    if sparse:
        from scipy.sparse import csr_matrix, coo_matrix

        # Build index mappings (col → sample index, row → feature index)
        unique_cols = sorted(df['col'].unique())
        unique_rows = sorted(df['row'].unique())
        col_to_idx = {c: i for i, c in enumerate(unique_cols)}
        row_to_idx = {r: i for i, r in enumerate(unique_rows)}

        # Build COO sparse matrix (samples × features)
        coo_rows = df['col'].map(col_to_idx).values   # sample indices
        coo_cols = df['row'].map(row_to_idx).values    # feature indices
        coo_vals = df['value'].values.astype(np.float64)

        n_samples = len(unique_cols)
        n_features = len(unique_rows)
        matrix = coo_matrix((coo_vals, (coo_rows, coo_cols)),
                            shape=(n_samples, n_features)).tocsr()

        sample_names = [col_map.get(idx, str(idx)) for idx in unique_cols]
        feature_names = [row_map.get(idx, str(idx)) for idx in unique_rows]

        logger.info(f'Loaded sparse matrix: {n_samples} samples × {n_features} features '
                     f'({matrix.nnz} nonzero, {matrix.nnz / (n_samples * n_features) * 100:.1f}% dense)')

        return matrix, sample_names, feature_names
    else:
        dense = df.pivot(index='col', columns='row', values='value').fillna(0.0)

        # Remap integer indices to actual names
        sample_names = [col_map.get(idx, str(idx)) for idx in dense.index]
        feature_names = [row_map.get(idx, str(idx)) for idx in dense.columns]

        return dense.values.astype(np.float64), sample_names, feature_names


def intersect_metadata(
    sample_names: list[str],
    metadata_df: pd.DataFrame | None,
    matrix: np.ndarray | None = None,
) -> tuple[list[str], pd.DataFrame | None, np.ndarray | None]:
    """Intersect matrix sample names with metadata rows, keeping only common samples.

    Parameters
    ----------
    sample_names : list[str]
        Sample names from the matrix columns (defines the row order).
    metadata_df : pd.DataFrame | None
        Metadata indexed by sample name (``index_col=0``).  If ``None``,
        the function returns immediately with no changes.
    matrix : np.ndarray | scipy.sparse.csr_matrix | None
        Expression matrix with shape ``(n_samples, n_features)``, dense or sparse.
        If provided, rows are subsetted to match the intersection.

    Returns
    -------
    tuple[list[str], pd.DataFrame | None, np.ndarray | None]
        ``(sample_names, metadata_df, matrix)`` — all subsetted to the
        intersection.  ``matrix`` is ``None`` when the input was ``None``.

    Raises
    ------
    ValueError
        If the intersection is empty (zero common samples).
    """
    if metadata_df is None:
        return sample_names, metadata_df, matrix

    meta_samples = set(metadata_df.index.astype(str))
    matrix_samples = set(sample_names)
    common = matrix_samples & meta_samples

    # If index doesn't match, try 'sample_id' column as fallback
    if len(common) == 0 and 'sample_id' in metadata_df.columns:
        logger.info(
            "Metadata index did not match matrix samples. "
            "Re-indexing metadata by 'sample_id' column."
        )
        metadata_df = metadata_df.set_index('sample_id')
        meta_samples = set(metadata_df.index.astype(str))
        common = matrix_samples & meta_samples

    if len(common) == 0:
        raise ValueError(
            f"No common samples between matrix ({len(matrix_samples)} samples) "
            f"and metadata ({len(meta_samples)} rows). "
            "Check that sample names match the metadata index or 'sample_id' column."
        )

    dropped_from_matrix = matrix_samples - common
    dropped_from_meta = meta_samples - common
    if dropped_from_matrix or dropped_from_meta:
        logger.warning(
            f"Metadata intersection: {len(common)} common samples. "
            f"Dropped {len(dropped_from_matrix)} matrix-only sample(s), "
            f"{len(dropped_from_meta)} metadata-only row(s)."
        )

    # Preserve original matrix order for the kept samples
    keep_mask = [name in common for name in sample_names]
    new_sample_names = [name for name, keep in zip(sample_names, keep_mask) if keep]
    new_metadata_df = metadata_df.loc[metadata_df.index.isin(common)]

    new_matrix = None
    if matrix is not None:
        new_matrix = matrix[keep_mask]

    return new_sample_names, new_metadata_df, new_matrix
