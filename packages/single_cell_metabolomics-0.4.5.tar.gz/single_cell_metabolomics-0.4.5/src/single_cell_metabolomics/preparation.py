# %%
import numpy as np
import pandas as pd
from scipy.sparse import coo_matrix, save_npz
import pyopenms as oms
# import multiprocessing as mp
# import itertools
# from functools import partial
import json
import sys

from typing import List
from pathlib import Path
import typer
from loguru import logger
from tqdm import tqdm


# %%
app = typer.Typer(add_completion=False)

# @app.command()
# def main(
#     # ---- REPLACE DEFAULT PATHS AS APPROPRIATE ----
#     input_path: Path = RAW_DATA_DIR / "dataset.csv",
#     output_path: Path = PROCESSED_DATA_DIR / "dataset.csv",
#     # ----------------------------------------------
# ):
#     # ---- REPLACE THIS WITH YOUR OWN CODE ----
#     logger.info("Processing dataset...")
#     for i in tqdm(range(10), total=10):
#         if i == 5:
#             logger.info("Something happened for iteration 5.")
#     logger.success("Processing dataset complete.")
#     # -----------------------------------------

@app.command()
def mzml2tsv(
    input_path = Path('.'),
    output_path = Path('.'),
    integration_type: str = 'sum',
    lc_lower_bound: float = 0.0,
    lc_upper_bound: float = 300.0
):
    """
    Convert mzML file to tsv file with three columns: mode, position, intensity.
    integration_type: 'sum' or 'mean' to indicate how to integrate intensities across scans.
    """
    logger.info(f'Read file: {input_path}')
    exp = oms.MSExperiment()
    oms.MzMLFile().load(input_path, exp)
    spectra = exp.getSpectra()

    polarity_map = {
        oms.IonSource.Polarity.POSITIVE: 'positive',
        oms.IonSource.Polarity.NEGATIVE: 'negative',
        oms.IonSource.Polarity.POLNULL: 'polnull'
    }

    # Collect peaks per polarity using numpy arrays (avoids Python list.extend)
    pos_arrays = []
    int_arrays = []
    pol_labels = []

    for s in spectra:
        if s.getMSLevel() != 1:
            continue
        rt = s.getRT()
        if rt < lc_lower_bound or rt > lc_upper_bound:
            continue
        mzs, ints = s.get_peaks()
        if len(mzs) == 0:
            continue
        pos_arrays.append(mzs)
        int_arrays.append(ints)
        pol_labels.append(polarity_map.get(s.getInstrumentSettings().getPolarity(), 'polnull'))

    scan_number = len(pos_arrays)
    if scan_number == 0:
        pd.DataFrame(columns=['mode', 'position', 'intensity']).to_csv(
            output_path, sep='\t', index=False, header=False)
        return

    # Concatenate all numpy arrays at once
    all_positions = np.concatenate(pos_arrays)
    all_intensities = np.concatenate(int_arrays)

    # Build polarity array without per-element list multiplication
    scan_lengths = [len(a) for a in pos_arrays]
    all_polarities = np.repeat(pol_labels, scan_lengths)

    data = pd.DataFrame({
        'position': np.round(all_positions, 4),
        'intensity': all_intensities,
        'mode': all_polarities,
    })
    if integration_type == 'mean':
        data['intensity'] = data['intensity'] / scan_number
    data = data \
        .groupby(['mode', 'position'], sort=False) \
        .agg({'intensity': 'sum'}) \
        .reset_index()

    logger.info(f'Write file: {output_path}')
    data.to_csv(output_path, sep='\t', index=False, header=False)

def create_bins(lower_bound, upper_bound, bin_width):
    bins = []
    added_bound = lower_bound
    while added_bound < upper_bound:
        bins.append(added_bound)
        added_bound = added_bound + added_bound * bin_width / 1e6
    bins.append(added_bound)
    return bins

def get_bins_center(bins):
    n = len(bins)
    bins = np.array(bins)
    bin_center = (bins[:n-1] + bins[1:]) / 2
    return bin_center

@app.command()
def bindata(
    input_path = Path('.'),
    output_path = Path('.'),
    bin_width_value: float = 0.0003,
    bin_width_unit: str = 'm/z',
    ms_lower_bound: float = 100,
    ms_upper_bound: float = 1500
):
    """
    Bin the mass spectrometry data.
    bin_width_unit: 'm/z' or 'ppm' to indicate the unit of bin_width.
    ms_lower_bound and ms_upper_bound define the range of mass/charge ratios to consider.
    """
    logger.info(f'Read file: {input_path}')
    data = pd.read_table(input_path, header=None, names=['mode', 'position', 'intensity'])
    data = data[(data['position'] >= ms_lower_bound) & (data['position'] <= ms_upper_bound)]
    if bin_width_unit == 'ppm':
        bins = create_bins(ms_lower_bound, ms_upper_bound, bin_width_value)
    elif bin_width_unit == 'm/z':
        bins = np.arange(ms_lower_bound - bin_width_value / 2, ms_upper_bound + bin_width_value, bin_width_value)
    else:
        logger.error(f'Invalid bin_width_unit: {bin_width_unit}. Use "m/z" or "ppm".')
        raise ValueError(f'Invalid bin_width_unit: {bin_width_unit}. Use "m/z" or "ppm".')
    bins_center = get_bins_center(bins)
    data['bin_index'] = np.digitize(data['position'], bins, right=False) - 1

    binned_data = data.groupby(['mode', 'bin_index']).agg({'position': 'mean', 'intensity': 'sum'}).reset_index()
    bin_center = bins_center[binned_data['bin_index']]
    binned_data['bin_center'] = [f'{i:.4f}' for i in bin_center]

    output = binned_data[['mode', 'bin_center', 'intensity']]
    logger.info(f'Write file: {output_path}')
    output.to_csv(output_path, sep='\t', index=False, header=False)


def read_tsv_file(file_path):
    """
    Reads a tsv file and renames the columns for merging.
    """
    try:
        stem = file_path.stem
        # Strip pipeline suffix added by Nextflow BIN_MS1 process
        if stem.endswith('_ms1_peaks_binned'):
            stem = stem[:-len('_ms1_peaks_binned')]
        df = pd.read_table(
            file_path,
            sep='\t',
            header=None,
            names=['mode', 'mass', stem]
        )
        return df
    except FileNotFoundError:
        logger.error(f'File not found: {file_path}')
        return None
    except pd.errors.EmptyDataError:
        logger.error(f'Empty tsv file: {file_path}')
        return None
    except Exception as e:
        logger.error(f'Error reading file {file_path}: {e}')
        return None

# def build_sparse_matrix(dataframes, mass_set):
#     """
#     Builds a sparse matrix from a list of DataFrames based on 'mode' and 'mass_binned'.
#     """
#     mass_list = sorted(list(mass_set))
#     row_names = mass_list
#     index_map = {mass: idx for idx, mass in enumerate(mass_list)}
#     rows = [] # feature indices
#     cols = [] # sample indices
#     data = []
#     column_names = []
#     for col_idx, df in tqdm(enumerate(dataframes), total=len(dataframes)):
#         column_names.append(df.columns[-1])  # Last column is the intensity
#         for _, row in df.iterrows():
#             mass_key = (row['mode'], row['mass'])
#             if mass_key in index_map:
#                 row_idx = index_map[mass_key]
#                 rows.append(row_idx)
#                 cols.append(col_idx)
#                 data.append(row.iloc[-1])  # Last column is the intensity

#     sparse_matrix = coo_matrix(
#         (data, (rows, cols)),
#         shape=(len(row_names), len(dataframes))
#     )
#     return sparse_matrix, row_names, column_names

# def transpose_to_csr_matrix(sparse_matrix, row_names, column_names):
#     """
#     Transposes a sparse matrix.
#     """
#     return sparse_matrix.transpose().tocsr(), column_names, row_names

@app.command()
def concattsv(
    serial_number: str = '',
    dataset_uid: int = 42,
    input_tsv_list_txt: str = '',
    output_parquet_folder: str = '.'
):
    """
    Combines a list of DataFrames on the 'mode' and 'mass' columns using sparse matrix representation.
    """
    # dataframes = []
    valid_dataframe_paths = []
    mass_set = set()
    with open(input_tsv_list_txt, 'r') as file:
        input_tsvs = file.read().strip().split('\n')
    logger.info(f'Input tsv files from {input_tsv_list_txt}')
    logger.info('Gathering mass features from input tsv files...')
    for tsv in tqdm(input_tsvs):
        df = read_tsv_file(Path(tsv))
        if df is not None:
            # dataframes.append(df)
            valid_dataframe_paths.append(tsv)
            mass_set.update(zip(df['mode'], df['mass']))

    if not valid_dataframe_paths:
        logger.error('No valid dataframes to combine.')
        return None

    metadata_file_path = Path(output_parquet_folder) / 'preparation_metadata.json'
    try:
        logger.info(f'Build sparse matrix from {len(valid_dataframe_paths)} dataframes.')
        # sparse_matrix, row_feature_names, column_sample_names = build_sparse_matrix(dataframes, mass_set)

        mass_list = sorted(list(mass_set))
        row_feature_names = mass_list
        index_map = {mass: idx for idx, mass in enumerate(mass_list)}
        rows = [] # feature indices
        cols = [] # sample indices
        data = []
        column_sample_names = []
        for col_idx, df_path in tqdm(enumerate(valid_dataframe_paths), total=len(valid_dataframe_paths)):
            df = read_tsv_file(Path(df_path))
            if df is None:
                continue
            column_sample_names.append(df.columns[-1])  # Last column is the intensity
            for _, row in df.iterrows():
                mass_key = (row['mode'], row['mass'])
                if mass_key in index_map:
                    row_idx = index_map[mass_key]
                else:
                    logger.error(f'Mass key {mass_key} not found in index map.')
                    continue
                rows.append(row_idx)
                cols.append(col_idx)
                data.append(row.iloc[-1])  # Last column is the intensity

        sparse_matrix = coo_matrix(
            (data, (rows, cols)),
            shape=(len(row_feature_names), len(column_sample_names))
        )
        logger.info(f'Sparse matrix shape: {sparse_matrix.shape}, nnz: {sparse_matrix.nnz}')

        logger.info(f'Saving sparse matrix and metadata to {output_parquet_folder} ...')
        # Write name TSVs — single-column headerless (one name per line)
        # Consistent with normalization/batch_correction/filtration output format
        row_name_strings = [f"{mode}_{mass}" for mode, mass in row_feature_names]
        Path(output_parquet_folder, 'row_feature_names.tsv').write_text(
            '\n'.join(row_name_strings) + '\n'
        )
        Path(output_parquet_folder, 'column_sample_names.tsv').write_text(
            '\n'.join(column_sample_names) + '\n'
        )
        
        n_sample = len(column_sample_names)
        n_feature = len(row_feature_names)

        # Build COO parquet with string name row/col (consistent with all analysis outputs)
        long_df = pd.DataFrame({
            'row': [row_name_strings[i] for i in sparse_matrix.row],
            'col': [column_sample_names[j] for j in sparse_matrix.col],
            'value': sparse_matrix.data
        })

        # Save large dataframe to Parquet file
        storage_path = Path(output_parquet_folder) / f"{dataset_uid}_preparation_mergetsv_sparse_matrix.parquet"
        long_df.to_parquet(
            path=storage_path,
            engine='pyarrow',
            compression='snappy',
            index=False
        )
        logger.info(f'Saved sparse matrix to Parquet file: {storage_path}')

        # Output JSON metadata to stdout for Analysis server to parse
        # Use a special marker to distinguish from regular log output
        metadata = {
            "type": "preparation_result",
            "serial_number": serial_number,
            "dataset_uid": dataset_uid,
            "sample_number": n_sample,
            "feature_number": n_feature,
            "pipeline_stage": "preparation",
            "result_type": "mergetsv_sparse_matrix",
            "storage_path": str(storage_path),
            "file_size_bytes": storage_path.stat().st_size,
            "row_count": len(long_df),
            "column_names": list(long_df.columns),
            "status": "completed"
        }
        try:
            with open(metadata_file_path, 'w') as f:
                json.dump(metadata, f)
        except Exception as write_err:
            logger.error(f'Failed to write preparation metadata file: {write_err}')
        # Print JSON with special markers for easy parsing
        print(f"__PREPARATION_METADATA_START__{json.dumps(metadata)}__PREPARATION_METADATA_END__", file=sys.stdout, flush=True)

        logger.success('Concatenate complete.')

        # TODO: reduce RSS by saving in chunks if necessary

    except Exception as e:
        logger.error(f'Error concatenating DataFrames: {e}')
        # Output failure metadata
        error_metadata = {
            "type": "preparation_result",
            "serial_number": serial_number,
            "dataset_uid": dataset_uid,
            "status": "failed",
            "error_message": str(e)
        }
        try:
            with open(metadata_file_path, 'w') as f:
                json.dump(error_metadata, f)
        except Exception as write_err:
            logger.error(f'Failed to write preparation metadata file: {write_err}')
        print(f"__PREPARATION_METADATA_START__{json.dumps(error_metadata)}__PREPARATION_METADATA_END__", file=sys.stdout, flush=True)
        raise


if __name__ == '__main__':
    app()

# %%
