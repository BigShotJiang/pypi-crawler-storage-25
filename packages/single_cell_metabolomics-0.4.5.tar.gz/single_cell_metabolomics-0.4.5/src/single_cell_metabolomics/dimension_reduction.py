import json
import os
import numpy as np
import pandas as pd
import pyarrow as pa
import pyarrow.parquet as pq
from pathlib import Path
import typer
from loguru import logger
from single_cell_metabolomics.config import load_coo_parquet, write_error_sentinel, intersect_metadata

app = typer.Typer(add_completion=False)


class DimensionReductionExecutor:
    def __init__(
        self,
        matrix_data_path: str,
        matrix_row_path: str,
        matrix_column_path: str,
        metadata_path: str,
    ):
        self.X, self.sample_names, self.feature_names = load_coo_parquet(
            matrix_data_path, matrix_row_path, matrix_column_path, sparse=True,
        )

        self.metadata_df = None
        if metadata_path and os.path.exists(metadata_path):
            self.metadata_df = pd.read_csv(metadata_path, index_col=0)

        # Intersect matrix samples with metadata rows
        self.sample_names, self.metadata_df, self.X = intersect_metadata(
            self.sample_names, self.metadata_df, self.X,
        )

        # Results populated by reduce_*
        self.embedding: list = []          # [[x, y], ...]
        self.variance_ratio: list = []     # [float, float] — PCA only
        self.vip_scores: list = []         # [{feature, vip}, ...] — PLS-DA only
        self.pca_matrix = None             # N x n_pcs numpy array, set after PCA computation

    def _get_group_labels(self, column: str) -> np.ndarray:
        """Return per-sample group labels for supervised methods."""
        if not column or self.metadata_df is None or column not in self.metadata_df.columns:
            raise ValueError(f"Group label column '{column}' not found in metadata")
        return np.array([
            str(self.metadata_df.loc[name, column])
            if name in self.metadata_df.index else 'unknown'
            for name in self.sample_names
        ])

    # ------------------------------------------------------------------ #
    #  Unsupervised — PCA                                                  #
    # ------------------------------------------------------------------ #

    def reduce_pca(self, n_pcs: int) -> None:
        import scanpy as sc
        import anndata as ad

        n_comps = min(n_pcs, self.X.shape[0] - 1, self.X.shape[1] - 1)
        adata = ad.AnnData(X=self.X.astype(np.float64))
        sc.pp.pca(adata, n_comps=max(n_comps, 2))
        self.pca_matrix = adata.obsm['X_pca']

        coords = adata.obsm['X_pca'][:, :2]
        self.embedding = coords.tolist()
        var_ratio = adata.uns['pca']['variance_ratio']
        self.variance_ratio = var_ratio[:2].tolist()

    # ------------------------------------------------------------------ #
    #  Unsupervised — UMAP                                                 #
    # ------------------------------------------------------------------ #

    def reduce_umap(self, n_pcs: int, n_neighbors: int, min_dist: float) -> None:
        import scanpy as sc
        import anndata as ad

        n_comps = min(n_pcs, self.X.shape[0] - 1, self.X.shape[1] - 1)
        adata = ad.AnnData(X=self.X.astype(np.float64))
        sc.pp.pca(adata, n_comps=max(n_comps, 2))
        self.pca_matrix = adata.obsm['X_pca']
        sc.pp.neighbors(adata, n_neighbors=n_neighbors, n_pcs=n_comps)
        sc.tl.umap(adata, min_dist=min_dist, random_state=42)

        coords = adata.obsm['X_umap'][:, :2]
        self.embedding = coords.tolist()

    # ------------------------------------------------------------------ #
    #  Unsupervised — t-SNE                                                #
    # ------------------------------------------------------------------ #

    def reduce_tsne(self, n_pcs: int, perplexity: float) -> None:
        import scanpy as sc
        import anndata as ad

        n_comps = min(n_pcs, self.X.shape[0] - 1, self.X.shape[1] - 1)
        adata = ad.AnnData(X=self.X.astype(np.float64))
        sc.pp.pca(adata, n_comps=max(n_comps, 2))
        self.pca_matrix = adata.obsm['X_pca']
        sc.tl.tsne(adata, n_pcs=n_comps, perplexity=perplexity, random_state=42)

        coords = adata.obsm['X_tsne'][:, :2]
        self.embedding = coords.tolist()

    # ------------------------------------------------------------------ #
    #  Unsupervised — PCoA (classical MDS on distance matrix)             #
    # ------------------------------------------------------------------ #

    def reduce_pcoa(self, metric: str) -> None:
        from scipy.spatial.distance import cdist
        from scipy.sparse import issparse

        X = self.X.toarray() if issparse(self.X) else self.X
        D = cdist(X, X, metric=metric)
        n = D.shape[0]

        # Double-center the squared distance matrix
        D2 = D ** 2
        row_mean = D2.mean(axis=1, keepdims=True)
        col_mean = D2.mean(axis=0, keepdims=True)
        grand_mean = D2.mean()
        H = -0.5 * (D2 - row_mean - col_mean + grand_mean)

        eigenvalues, eigenvectors = np.linalg.eigh(H)
        # Sort descending
        idx = np.argsort(eigenvalues)[::-1]
        eigenvalues = eigenvalues[idx]
        eigenvectors = eigenvectors[:, idx]

        # Take first 2 positive eigenvectors
        coords = eigenvectors[:, :2] * np.sqrt(np.maximum(eigenvalues[:2], 0))
        self.embedding = coords.tolist()

    # ------------------------------------------------------------------ #
    #  Supervised — PLS-DA                                                 #
    # ------------------------------------------------------------------ #

    def reduce_plsda(self, group_label: str) -> None:
        from sklearn.cross_decomposition import PLSRegression
        from sklearn.preprocessing import LabelEncoder
        from scipy.sparse import issparse

        X = self.X.toarray() if issparse(self.X) else self.X
        y_str = self._get_group_labels(group_label)
        le = LabelEncoder()
        y = le.fit_transform(y_str).reshape(-1, 1).astype(float)

        n_components = min(2, X.shape[0] - 1, X.shape[1] - 1, len(np.unique(y_str)))
        pls = PLSRegression(n_components=max(n_components, 2), scale=True)
        pls.fit(X, y)

        coords = pls.x_scores_[:, :2]
        self.embedding = coords.tolist()

        # VIP scores: Variable Importance in Projection
        T = pls.x_scores_      # (n_obs, n_comp)
        W = pls.x_weights_     # (n_vars, n_comp)
        Q = pls.y_loadings_    # (n_targets, n_comp)

        n_comp = T.shape[1]
        n_vars = W.shape[0]

        ss = np.sum(T ** 2, axis=0) * np.sum(Q ** 2, axis=0)  # (n_comp,)
        ss_total = np.sum(ss)

        vip = np.zeros(n_vars)
        for j in range(n_vars):
            vip[j] = np.sqrt(n_vars * np.sum(ss * (W[j, :] / np.linalg.norm(W, axis=0)) ** 2) / ss_total)

        feature_vip = sorted(
            [{'feature': f, 'vip': round(float(v), 4)} for f, v in zip(self.feature_names, vip)],
            key=lambda x: x['vip'],
            reverse=True,
        )
        self.vip_scores = feature_vip

    # ------------------------------------------------------------------ #
    #  Supervised — OPLS-DA                                               #
    # ------------------------------------------------------------------ #

    def reduce_oplsda(self, group_label: str) -> None:
        from sklearn.cross_decomposition import PLSRegression
        from sklearn.preprocessing import LabelEncoder
        from scipy.sparse import issparse

        X = self.X.toarray() if issparse(self.X) else self.X
        y_str = self._get_group_labels(group_label)
        le = LabelEncoder()
        y = le.fit_transform(y_str).reshape(-1, 1).astype(float)

        # Step 1: PLS on X and y to get predictive component
        pls1 = PLSRegression(n_components=1, scale=True)
        pls1.fit(X, y)
        t_pred = pls1.x_scores_[:, 0:1]   # (n_obs, 1) predictive score
        p_pred = pls1.x_loadings_[:, 0:1]  # (n_vars, 1) predictive loading

        # Step 2: Deflate X to remove predictive variance
        X_orth = X - t_pred @ p_pred.T

        # Step 3: PLS on deflated X and y to get orthogonal component
        n_comps_orth = min(1, X_orth.shape[0] - 1, X_orth.shape[1] - 1)
        pls_orth = PLSRegression(n_components=max(n_comps_orth, 1), scale=True)
        pls_orth.fit(X_orth, y)
        t_orth = pls_orth.x_scores_[:, 0:1]  # (n_obs, 1) orthogonal score

        # Final 2D embedding: [predictive score, orthogonal score]
        coords = np.hstack([t_pred, t_orth])
        self.embedding = coords.tolist()

    # ------------------------------------------------------------------ #
    #  Supervised — RFDA (Regularized Fisher Discriminant Analysis)       #
    # ------------------------------------------------------------------ #

    def reduce_rfda(self, group_label: str) -> None:
        from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
        from scipy.sparse import issparse

        X = self.X.toarray() if issparse(self.X) else self.X
        y_str = self._get_group_labels(group_label)
        n_classes = len(np.unique(y_str))
        n_components = min(2, n_classes - 1, X.shape[1] - 1)

        lda = LinearDiscriminantAnalysis(
            solver='lsqr',
            shrinkage='auto',
            n_components=max(n_components, 1),
        )
        lda.fit(X, y_str)
        transformed = lda.transform(X)

        # Pad to 2D if only 1 discriminant (binary case)
        if transformed.shape[1] == 1:
            transformed = np.hstack([transformed, np.zeros((transformed.shape[0], 1))])

        self.embedding = transformed[:, :2].tolist()

    # ------------------------------------------------------------------ #
    #  Output                                                              #
    # ------------------------------------------------------------------ #

    def write_embedding_parquet(self, output_path: str) -> None:
        out_df = pd.DataFrame({
            'cell_name': self.sample_names,
            'component_1': [pt[0] for pt in self.embedding],
            'component_2': [pt[1] for pt in self.embedding],
        })
        pq.write_table(
            pa.Table.from_pandas(out_df, preserve_index=False),
            output_path,
        )
        logger.info(f'Wrote embedding parquet to {output_path}')

    def write_pca_parquet(self, output_path: str, n_pcs: int) -> None:
        if self.pca_matrix is None:
            logger.warning('No PCA matrix to write — skipping PCA parquet')
            return
        n_actual = min(n_pcs, self.pca_matrix.shape[1])
        data = {'cell_name': self.sample_names}
        for i in range(n_actual):
            data[f'PC_{i+1}'] = self.pca_matrix[:, i].tolist()
        out_df = pd.DataFrame(data)
        pq.write_table(
            pa.Table.from_pandas(out_df, preserve_index=False),
            output_path,
        )
        logger.info(f'Wrote PCA parquet ({n_actual} PCs) to {output_path}')

    def write_tsv_files(self, row_path: str, column_path: str) -> None:
        pd.Series(self.feature_names).to_csv(row_path, sep='\t', index=False, header=False)
        pd.Series(self.sample_names).to_csv(column_path, sep='\t', index=False, header=False)
        logger.info(f'Wrote row TSV to {row_path}, column TSV to {column_path}')

    def emit_sentinel(
        self,
        serial_number: str,
        dataset_uid: int,
        analysis_id: int,
        storage_path: str,
        row_path: str,
        column_path: str,
        method: str,
        pca_storage_path: str = '',
    ) -> None:
        sentinel = {
            'serial_number': serial_number,
            'dataset_uid': dataset_uid,
            'pipeline_stage': 'analysis',
            'analysis_id': analysis_id,
            'storage_path': os.path.abspath(storage_path),
            'pca_storage_path': os.path.abspath(pca_storage_path) if pca_storage_path else '',
            'row_path': os.path.abspath(row_path),
            'column_path': os.path.abspath(column_path),
            'embedding': self.embedding,
            'cell_names': self.sample_names,
            'variance_ratio': self.variance_ratio,
            'method': method,
            'vip_scores': self.vip_scores,
            'status': 'completed',
        }
        metadata_file = Path('dimension_reduction_metadata.json')
        metadata_file.write_text(json.dumps(sentinel, indent=2))
        logger.info(f'Wrote sentinel to {metadata_file.resolve()}')
        print(
            f'__DIMENSION_REDUCTION_METADATA_START__{json.dumps(sentinel)}'
            f'__DIMENSION_REDUCTION_METADATA_END__'
        )


@app.command()
def reduce(
    serial_number: str = '',
    dataset_uid: int = 0,
    # --- input paths (infrastructure, not parameters) ---
    parquet_path: str = '',
    row_path: str = '',
    column_path: str = '',
    metadata_path: str = '',
    # --- analysis ID (required for sentinel) ---
    analysis_id: int = typer.Option(..., help="Analysis ID (104 for SC, 205 for LCM)"),
    # --- analysis parameters (match analysisParameterConfig.js parameterName in snake_case) ---
    reduction_method: str = 'UMAP',
    n_pcs: int = 50,
    n_neighbors: int = 15,
    min_dist: float = 0.1,
    perplexity: float = 30,
    pcoa_metric: str = 'braycurtis',
    group_label: str = '',
    feature_filter_path: str = '',
    # --- output paths ---
    output_parquet_path: str = 'dimension_reduced.parquet',
    output_row_path: str = 'row_feature_names.tsv',
    output_column_path: str = 'column_sample_names.tsv',
    output_pca_path: str = 'pca_reduced.parquet',
):
    """Apply dimensionality reduction (PCA, UMAP, t-SNE, PCoA, PLS-DA, OPLS-DA, RFDA) to a single-cell metabolomics matrix."""
    try:
        executor = DimensionReductionExecutor(
            matrix_data_path=parquet_path,
            matrix_row_path=row_path,
            matrix_column_path=column_path,
            metadata_path=metadata_path,
        )

        # Apply optional DAM feature filter (subset matrix to DAM features only)
        if feature_filter_path:
            filter_names = set(Path(feature_filter_path).read_text().splitlines())
            n_filter = len(filter_names)
            n_matrix = len(executor.feature_names)
            keep = filter_names.intersection(set(executor.feature_names))
            if len(keep) == 0:
                raise ValueError(
                    f"No features remain after DAM filtering "
                    f"({n_filter} filter features, {n_matrix} matrix features, 0 overlap)"
                )
            mask = [f in keep for f in executor.feature_names]
            executor.X = executor.X[:, mask]
            executor.feature_names = [f for f in executor.feature_names if f in keep]
            logger.info(f"DAM filter applied: {len(executor.feature_names)} of {n_matrix} features retained")

        method = reduction_method.upper() if reduction_method.upper() in ('PCA', 'UMAP') else reduction_method

        if reduction_method == 'PCA':
            executor.reduce_pca(n_pcs=n_pcs)
        elif reduction_method == 'UMAP':
            executor.reduce_umap(n_pcs=n_pcs, n_neighbors=n_neighbors, min_dist=min_dist)
        elif reduction_method == 't-SNE':
            executor.reduce_tsne(n_pcs=n_pcs, perplexity=perplexity)
        elif reduction_method == 'PCoA':
            executor.reduce_pcoa(metric=pcoa_metric)
        elif reduction_method == 'PLS-DA':
            executor.reduce_plsda(group_label=group_label)
        elif reduction_method == 'OPLS-DA':
            executor.reduce_oplsda(group_label=group_label)
        elif reduction_method == 'RFDA':
            executor.reduce_rfda(group_label=group_label)
        else:
            raise ValueError(f"Unknown reduction method: '{reduction_method}'")

        # Ensure PCA is always computed for downstream clustering
        if executor.pca_matrix is None:
            import scanpy as sc
            import anndata as ad
            n_comps = min(n_pcs, executor.X.shape[0] - 1, executor.X.shape[1] - 1)
            adata_pca = ad.AnnData(X=executor.X.astype(np.float64))
            sc.pp.pca(adata_pca, n_comps=max(n_comps, 2))
            executor.pca_matrix = adata_pca.obsm['X_pca']
            logger.info(f'Computed PCA ({n_comps} PCs) for downstream clustering')

        executor.write_embedding_parquet(output_parquet_path)
        executor.write_pca_parquet(output_pca_path, n_pcs)
        executor.write_tsv_files(output_row_path, output_column_path)

        executor.emit_sentinel(
            serial_number=serial_number,
            dataset_uid=dataset_uid,
            analysis_id=analysis_id,
            storage_path=output_parquet_path,
            row_path=output_row_path,
            column_path=output_column_path,
            method=reduction_method,
            pca_storage_path=output_pca_path,
        )
        logger.success('Dimension reduction complete.')
    except Exception as e:
        write_error_sentinel("dimension_reduction_metadata.json", serial_number, dataset_uid, analysis_id, e)
        raise


@app.callback()
def callback():
    pass


if __name__ == '__main__':
    app()
