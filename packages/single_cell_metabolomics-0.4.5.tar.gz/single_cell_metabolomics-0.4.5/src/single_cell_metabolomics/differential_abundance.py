import json
import os
from pathlib import Path

import numpy as np
import pandas as pd
import pyarrow as pa
import pyarrow.parquet as pq
import typer
from loguru import logger
from single_cell_metabolomics.config import write_error_sentinel, sanitize_for_json

app = typer.Typer(add_completion=False)


def _read_name_list(path: str) -> list[str]:
    """Read a name TSV and return a flat list of names in index order."""
    first_line = open(path).readline()
    if '\t' in first_line:
        df = pd.read_csv(path, sep='\t')
        if 'index' in df.columns:
            df = df.sort_values('index')
            name_cols = [c for c in df.columns if c != 'index']
            if len(name_cols) == 1:
                return df[name_cols[0]].astype(str).tolist()
            else:
                return (df[name_cols].astype(str).agg('_'.join, axis=1)).tolist()
    # Single-column headerless
    return [line.strip() for line in open(path) if line.strip()]


def _load_group_labels(
    sample_names: list[str],
    metadata_path: str,
    cluster_labels_path: str,
    group_by: str,
) -> tuple[np.ndarray, list[str]]:
    """Load group labels for all samples. Returns (labels_array, sorted_groups_list)."""
    if group_by == 'cluster':
        if not cluster_labels_path or not os.path.exists(cluster_labels_path):
            raise ValueError("cluster_labels_path not provided but group_by='cluster'")
        cl_df = pd.read_parquet(cluster_labels_path)
        cell_col = 'cell_name' if 'cell_name' in cl_df.columns else 'cell'
        cl_map = dict(zip(cl_df[cell_col].astype(str), cl_df['cluster'].astype(str)))
        labels = np.array([cl_map.get(name, 'unknown') for name in sample_names])
    else:
        if not metadata_path or not os.path.exists(metadata_path):
            raise ValueError(f"metadata_path not provided but group_by='{group_by}'")
        meta_df = pd.read_csv(metadata_path, index_col=0)
        if group_by not in meta_df.columns:
            raise ValueError(f"group_by column '{group_by}' not in metadata")
        meta_reindexed = meta_df.reindex(sample_names)
        labels = meta_reindexed[group_by].astype(str).values

    groups = sorted(np.unique(labels).tolist())
    return labels, groups


def _detect_parquet_row_type(parquet_path: str) -> str:
    """Detect whether the parquet 'row' column stores strings or integers."""
    import duckdb
    conn = duckdb.connect()
    result = conn.execute(
        f"SELECT typeof(row) AS t FROM read_parquet('{parquet_path}') LIMIT 1"
    ).fetchone()
    conn.close()
    return result[0] if result else 'INTEGER'


def _load_feature_chunk(
    parquet_path: str,
    feature_keys: list,
    n_samples: int,
    sample_index_map: dict,
    row_type: str,
) -> np.ndarray:
    """Load a chunk of features from COO parquet via DuckDB. Returns dense (n_samples, chunk_size).

    feature_keys: list of int indices (if row is int) or string names (if row is string).
    """
    import duckdb

    conn = duckdb.connect()
    if row_type == 'VARCHAR':
        # String feature names — quote them
        quoted = ','.join(f"'{k}'" for k in feature_keys)
    else:
        # Integer indices
        quoted = ','.join(str(k) for k in feature_keys)

    df = conn.execute(
        f"SELECT col, row, COALESCE(value, 0.0) AS value "
        f"FROM read_parquet('{parquet_path}') "
        f"WHERE row IN ({quoted})"
    ).fetchdf()
    conn.close()

    # Build dense chunk matrix
    chunk_size = len(feature_keys)
    feat_local = {k: pos for pos, k in enumerate(feature_keys)}

    matrix = np.zeros((n_samples, chunk_size), dtype=np.float64)
    for _, r in df.iterrows():
        col_val = r['col']
        si = sample_index_map.get(col_val if isinstance(col_val, str) else int(col_val))
        row_val = r['row']
        fi = feat_local.get(row_val if isinstance(row_val, str) else int(row_val))
        if si is not None and fi is not None:
            matrix[si, fi] = r['value']

    return matrix


def _run_chunk_tests_pairwise(
    chunk_matrix: np.ndarray,
    labels: np.ndarray,
    groups: list[str],
    feature_names: list[str],
    test_method: str,
    reference: str,
) -> list[dict]:
    """Run per-feature pairwise tests on a chunk. Returns list of result dicts."""
    from scipy.stats import mannwhitneyu, ttest_ind

    results = []
    n_features = chunk_matrix.shape[1]

    for gi, group in enumerate(groups):
        group_mask = labels == group
        if reference == 'rest':
            ref_mask = ~group_mask
        else:
            ref_mask = labels == reference

        group_data = chunk_matrix[group_mask]
        ref_data = chunk_matrix[ref_mask]

        if group_data.shape[0] < 2 or ref_data.shape[0] < 2:
            for fi in range(n_features):
                results.append({
                    'group': group, 'name': feature_names[fi],
                    'score': 0.0, 'logfoldchange': 0.0, 'pval': 1.0,
                })
            continue

        for fi in range(n_features):
            g_vals = group_data[:, fi]
            r_vals = ref_data[:, fi]

            try:
                if test_method == 'wilcoxon':
                    stat, pval = mannwhitneyu(g_vals, r_vals, alternative='two-sided')
                    # Score: z-approximation
                    n1, n2 = len(g_vals), len(r_vals)
                    mean_u = n1 * n2 / 2
                    std_u = np.sqrt(n1 * n2 * (n1 + n2 + 1) / 12)
                    score = (stat - mean_u) / std_u if std_u > 0 else 0.0
                elif test_method in ('t-test', 't-test_overestim_var'):
                    equal_var = (test_method == 't-test_overestim_var')
                    stat, pval = ttest_ind(g_vals, r_vals, equal_var=equal_var)
                    score = float(stat)
                else:
                    score, pval = 0.0, 1.0
            except Exception:
                score, pval = 0.0, 1.0

            # log2 fold change
            mean_g = np.mean(g_vals)
            mean_r = np.mean(r_vals)
            if mean_r != 0 and mean_g != 0:
                logfc = float(np.log2(np.abs(mean_g) / np.abs(mean_r)) * np.sign(mean_g - mean_r))
            else:
                logfc = 0.0

            results.append({
                'group': group, 'name': feature_names[fi],
                'score': float(score), 'logfoldchange': logfc, 'pval': float(pval),
            })

    return results


def _run_chunk_tests_anova(
    chunk_matrix: np.ndarray,
    labels: np.ndarray,
    groups: list[str],
    feature_names: list[str],
) -> list[dict]:
    """Run per-feature one-way ANOVA on a chunk."""
    from scipy.stats import f_oneway

    results = []
    n_features = chunk_matrix.shape[1]

    for fi in range(n_features):
        groups_data = [chunk_matrix[labels == g, fi] for g in groups]
        try:
            result = f_oneway(*groups_data)
            f_stat = float(result.statistic) if not np.isnan(result.statistic) else 0.0
            pval = float(result.pvalue) if not np.isnan(result.pvalue) else 1.0
        except Exception:
            f_stat, pval = 0.0, 1.0

        results.append({
            'group': 'ANOVA', 'name': feature_names[fi],
            'score': f_stat, 'logfoldchange': None, 'pval': pval,
        })

    return results


def run_chunked_da(
    parquet_path: str,
    row_path: str,
    column_path: str,
    metadata_path: str,
    cluster_labels_path: str,
    test_method: str,
    group_by: str,
    reference: str,
    chunk_size: int,
) -> tuple[list[str], list[str], list[dict]]:
    """
    Run chunked DA analysis. Returns (groups_list, feature_names, all_results).
    all_results is a flat list of dicts with keys: group, name, score, logfoldchange, pval.
    P-values are RAW (not yet adjusted).
    """
    feature_names = _read_name_list(row_path)
    sample_names = _read_name_list(column_path)
    n_features = len(feature_names)
    n_samples = len(sample_names)

    logger.info(f'Chunked DA: {n_samples} samples, {n_features} features, chunk_size={chunk_size}')

    # Detect parquet row type (string feature names vs integer indices)
    row_type = _detect_parquet_row_type(parquet_path)
    logger.info(f'Parquet row type: {row_type}')

    # Build sample index map (for COO → dense mapping)
    # COO parquet col values may be int indices or string names
    sample_index_map = {}
    for i, name in enumerate(sample_names):
        sample_index_map[name] = i
        sample_index_map[i] = i

    # Load group labels once
    labels, groups = _load_group_labels(sample_names, metadata_path, cluster_labels_path, group_by)
    logger.info(f'Groups ({len(groups)}): {groups}')

    # Process feature chunks
    all_results = []
    n_chunks = (n_features + chunk_size - 1) // chunk_size

    for chunk_idx in range(n_chunks):
        start = chunk_idx * chunk_size
        end = min(start + chunk_size, n_features)
        chunk_feature_names = feature_names[start:end]

        # Use feature names if parquet has strings, else use integer indices
        if row_type == 'VARCHAR':
            chunk_keys = chunk_feature_names
        else:
            chunk_keys = list(range(start, end))

        logger.info(f'Chunk {chunk_idx + 1}/{n_chunks}: features [{start}:{end}]')

        chunk_matrix = _load_feature_chunk(
            parquet_path, chunk_keys, n_samples, sample_index_map, row_type,
        )

        if test_method == 'ANOVA':
            chunk_results = _run_chunk_tests_anova(chunk_matrix, labels, groups, chunk_feature_names)
        else:
            chunk_results = _run_chunk_tests_pairwise(
                chunk_matrix, labels, groups, chunk_feature_names, test_method, reference,
            )

        all_results.extend(chunk_results)
        del chunk_matrix  # free memory

    logger.info(f'All chunks done. Total results: {len(all_results)}')
    return groups, feature_names, all_results


def adjust_and_format_results(
    groups: list[str],
    all_results: list[dict],
    test_method: str,
) -> tuple[list[str], dict]:
    """Apply BH FDR across all features, then format into results_by_group."""
    from statsmodels.stats.multitest import multipletests

    # Extract raw p-values and adjust
    raw_pvals = np.array([r['pval'] for r in all_results])
    # Clip to avoid issues with exact 0 or 1
    raw_pvals = np.clip(raw_pvals, 1e-300, 1.0)
    _, pvals_adj, _, _ = multipletests(raw_pvals, method='fdr_bh')

    # Attach adjusted p-values
    for i, r in enumerate(all_results):
        r['pval_adj'] = float(pvals_adj[i])

    # Group results
    results_by_group = {}
    if test_method == 'ANOVA':
        anova_results = [r for r in all_results if r['group'] == 'ANOVA']
        # Sort by abs(score) descending
        anova_results.sort(key=lambda r: abs(r['score']), reverse=True)
        results_by_group['ANOVA'] = {
            'names': [r['name'] for r in anova_results],
            'scores': [r['score'] for r in anova_results],
            'logfoldchanges': None,
            'pvals': [r['pval'] for r in anova_results],
            'pvals_adj': [r['pval_adj'] for r in anova_results],
        }
        return ['ANOVA'], results_by_group
    else:
        for g in groups:
            g_results = [r for r in all_results if r['group'] == g]
            g_results.sort(key=lambda r: abs(r['score']), reverse=True)
            results_by_group[g] = {
                'names': [r['name'] for r in g_results],
                'scores': [r['score'] for r in g_results],
                'logfoldchanges': [r['logfoldchange'] for r in g_results],
                'pvals': [r['pval'] for r in g_results],
                'pvals_adj': [r['pval_adj'] for r in g_results],
            }
        return groups, results_by_group


def write_output_files(
    feature_names: list[str],
    sample_names: list[str],
    all_results: list[dict],
    output_parquet_path: str,
    output_row_path: str,
    output_column_path: str,
) -> None:
    """Write results parquet and row/column TSV files."""
    out_df = pd.DataFrame(all_results)
    # Ensure consistent column order
    cols = ['group', 'name', 'score', 'logfoldchange', 'pval', 'pval_adj']
    out_df = out_df[[c for c in cols if c in out_df.columns]]
    pq.write_table(
        pa.Table.from_pandas(out_df, preserve_index=False),
        output_parquet_path,
    )
    pd.Series(feature_names).to_csv(output_row_path, sep='\t', index=False, header=False)
    pd.Series(sample_names).to_csv(output_column_path, sep='\t', index=False, header=False)
    logger.info(f'Wrote output parquet to {output_parquet_path}')


def emit_sentinel(
    serial_number: str,
    dataset_uid: int,
    analysis_id: int,
    output_parquet_path: str,
    output_row_path: str,
    output_column_path: str,
    test_method: str,
    group_by: str,
    reference: str,
    groups_list: list,
    results_by_group: dict,
    n_top_features: int,
) -> None:
    """Write sentinel metadata JSON with top-N results per group."""
    metadata_top_n = 200
    truncated_results = {}
    for group_key, group_data in results_by_group.items():
        truncated_results[group_key] = {
            k: v[:metadata_top_n] if isinstance(v, list) else v
            for k, v in group_data.items()
        }

    sentinel = {
        'serial_number': serial_number,
        'dataset_uid': dataset_uid,
        'pipeline_stage': 'analysis',
        'analysis_id': analysis_id,
        'storage_path': os.path.abspath(output_parquet_path),
        'row_path': os.path.abspath(output_row_path),
        'column_path': os.path.abspath(output_column_path),
        'status': 'completed',
        'test_method': test_method,
        'group_by': group_by,
        'reference': reference,
        'groups': groups_list,
        'results_by_group': truncated_results,
        'n_top_features': n_top_features,
    }
    metadata_file = Path('differential_abundance_metadata.json')
    safe_sentinel = sanitize_for_json(sentinel)
    metadata_file.write_text(json.dumps(safe_sentinel, indent=2))
    logger.info(f'Wrote sentinel to {metadata_file.resolve()}')
    print(
        f'__DIFF_ABUNDANCE_METADATA_START__{json.dumps(safe_sentinel)}'
        f'__DIFF_ABUNDANCE_METADATA_END__'
    )


@app.command()
def analyze(
    serial_number: str = '',
    dataset_uid: int = 0,
    parquet_path: str = '',
    row_path: str = '',
    column_path: str = '',
    metadata_path: str = '',
    cluster_labels_path: str = '',
    analysis_id: int = typer.Option(..., help='Analysis ID (107 SC / 204 LCM)'),
    test_method: str = 'wilcoxon',
    group_by: str = 'cluster',
    reference: str = 'rest',
    n_top_features: int = 50,
    chunk_size: int = typer.Option(10000, help='Features per processing chunk'),
    output_parquet_path: str = 'differential_abundance.parquet',
    output_row_path: str = 'row_feature_names.tsv',
    output_column_path: str = 'column_sample_names.tsv',
):
    """Run chunked differential abundance analysis."""
    import resource
    def _log_mem(label):
        mb = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 1024
        logger.info(f'[MEM] {label}: {mb:.0f} MB (peak RSS)')

    try:
        _log_mem('start')
        logger.info(
            f'DA analyze: serial={serial_number} dataset={dataset_uid} '
            f'method={test_method} group_by={group_by} reference={reference} '
            f'chunk_size={chunk_size}'
        )

        # Step 1: Chunked analysis
        groups, feature_names, all_results = run_chunked_da(
            parquet_path=parquet_path,
            row_path=row_path,
            column_path=column_path,
            metadata_path=metadata_path,
            cluster_labels_path=cluster_labels_path,
            test_method=test_method,
            group_by=group_by,
            reference=reference,
            chunk_size=chunk_size,
        )
        _log_mem('after chunked analysis')

        # Step 2: Adjust p-values and format
        groups_list, results_by_group = adjust_and_format_results(groups, all_results, test_method)
        _log_mem('after p-value adjustment')

        # Step 3: Write outputs
        sample_names = _read_name_list(column_path)
        write_output_files(
            feature_names=feature_names,
            sample_names=sample_names,
            all_results=all_results,
            output_parquet_path=output_parquet_path,
            output_row_path=output_row_path,
            output_column_path=output_column_path,
        )
        _log_mem('after writing parquet')

        # Step 4: Emit sentinel
        emit_sentinel(
            serial_number=serial_number,
            dataset_uid=dataset_uid,
            analysis_id=analysis_id,
            output_parquet_path=output_parquet_path,
            output_row_path=output_row_path,
            output_column_path=output_column_path,
            test_method=test_method,
            group_by=group_by,
            reference=reference,
            groups_list=groups_list,
            results_by_group=results_by_group,
            n_top_features=n_top_features,
        )
        logger.success('Differential abundance analysis complete.')
    except Exception as e:
        write_error_sentinel(
            "differential_abundance_metadata.json",
            serial_number, dataset_uid, analysis_id, e,
        )
        raise


@app.callback()
def callback():
    pass


if __name__ == '__main__':
    app()
