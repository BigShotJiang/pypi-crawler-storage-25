import argparse
import datetime
import re
import subprocess
from pathlib import Path


def calculate_new_version_info(old_version_name: str | None) -> tuple[int, int, int]:
    now = datetime.datetime.now(datetime.UTC)
    new_year, new_month, new_beta = int(str(now.year)[2:]), now.month, 0
    if old_version_name:
        old_year, old_month, old_beta = [
            int(x) for x in re.match(r"v?(\d+).(\d+)b(\d+)", old_version_name).groups()
        ]
        if (old_year, old_month) == (new_year, new_month):
            new_beta = old_beta + 1
    return new_year, new_month, new_beta


def rewrite_version_file(year: int, month: int, beta: int) -> None:
    path = Path(__file__).parent.parent / "src" / "supriya_midi" / "_version.py"
    text = path.read_text()
    lines = text.splitlines()
    for i, line in enumerate(lines):
        if line.startswith("__version_info__ ="):
            lines[i] = f'__version_info__ = ({year}, "{month}b{beta}")'
    path.write_text("\n".join(lines) + "\n")


def update_pyproject_toml(year: int, month: int, beta: int) -> None:
    version = f"{year}.{month}b{beta}"
    subprocess.run(
        ["uv", "version", "--no-sync", version], capture_output=True, check=True
    )


def build_parser():
    parser = argparse.ArgumentParser()
    parser.add_argument("release")
    return parser


def run():
    parser = build_parser()
    parsed_args = parser.parse_args()
    if (old_version_name := parsed_args.release) == "null":
        old_version_name = None
    year, month, beta = calculate_new_version_info(old_version_name)
    update_pyproject_toml(year, month, beta)
    rewrite_version_file(year, month, beta)
    print(f"{year}.{month}b{beta}", end="")


if __name__ == "__main__":
    run()
