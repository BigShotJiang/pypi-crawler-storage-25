import abc


class StorageInterface(metaclass=abc.ABCMeta):
    @abc.abstractmethod
    def download_file(self, local_path, file_id):
        pass

    @abc.abstractmethod
    def upload_file(self, local_path, file_id):
        pass

    @abc.abstractmethod
    def download_string(self, file_id):
        pass

    @abc.abstractmethod
    def upload_string(self, input_string, file_id):
        pass
