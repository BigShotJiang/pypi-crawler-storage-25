import os

import urllib3

from storage.errors import StorageCreationFailedException
from storage.minio import MinioStorageManager


class StorageFactory:  # pylint: disable=too-few-public-methods
    __instance = None

    @classmethod
    def create(cls, logger=None):
        if cls.__instance is None:
            try:
                cls.__instance = MinioStorageManager(
                    os.environ["OBJECT_STORAGE_URL"],
                    os.environ["CALCULATION_NAME"],
                    os.environ["OBJECT_STORAGE_ACCESS_KEY"],
                    os.environ["OBJECT_STORAGE_SECRET_KEY"],
                    bool(int(os.environ["OBJECT_STORAGE_USE_SSL"])),
                    logger=logger,
                )
            except urllib3.exceptions.MaxRetryError as exc:
                raise StorageCreationFailedException from exc
        return cls.__instance
