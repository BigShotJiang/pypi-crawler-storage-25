"""Runtime data storage module for BlackAnt SDK.

Provides thread-safe storage using threading.local() for storing
data across different modules and components.
"""

from typing import Any
import threading

from ..patterns.singleton import Singleton


class Store(metaclass=Singleton):  # pylint: disable=too-few-public-methods
    """Base class for runtime data storage.

    Thread-safe storage implementation using threading.local().
    All specific stores (auth tokens, request IDs) inherit from this class.
    """

    __tls = threading.local()

    def _get(self, name: str):
        """Get data from thread-local storage.

        Args:
            name (str): Attribute name to retrieve.

        Returns:
            Any or None: Attribute value or None if not set.
        """
        if not hasattr(self.__tls, name):
            return None
        return self.__tls.__getattribute__(name)

    def _set(self, name: str, value: Any):
        """Set data in thread-local storage.

        Args:
            name (str): Attribute name to set.
            value (Any): Value to store.
        """
        self.__tls.__setattr__(name, value)

    def _del(self, name: str):
        """Delete data from thread-local storage.

        Args:
            name (str): Attribute name to delete.
        """
        self.__tls.__delattr__(name)
