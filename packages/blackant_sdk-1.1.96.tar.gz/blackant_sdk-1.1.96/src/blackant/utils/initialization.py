"""Initialization utilities for the application."""

import os
import logging.config


def process_run_mode():
    """
    Process the run mode from environment variables.

    Returns:
        tuple: (DEBUG_MODE, RELEASE_MODE) booleans
    """
    run_mode = os.environ.get("RUN_MODE", "debug").lower()
    debug_mode = run_mode == "debug"
    release_mode = run_mode == "release"
    return debug_mode, release_mode


def initialize_logging(app, config_file_path="logging.ini"):
    """
    Initialize logging configuration.

    Args:
        app: Flask application instance
        config_file_path: Path to the logging configuration file
    """
    _ = app  # Mark as intentionally unused
    if os.path.exists(config_file_path):
        logging.config.fileConfig(config_file_path)
    else:
        logging.basicConfig(level=logging.INFO)
