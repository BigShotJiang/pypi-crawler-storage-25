"""BlackAnt Object Storage client module.

Provides file upload, download, listing, and deletion through
BlackAnt's sdk-services Object Storage proxy API.
"""

import os
from typing import Dict, Any, Optional, List, BinaryIO

from ..auth.blackant_auth import BlackAntAuth
from ..http.client import HTTPClient, HTTPConnectionError
from ..exceptions import BlackAntException
from ..utils.logging import get_logger


class ObjectStorageError(BlackAntException):
    """Object Storage operation related errors."""


class ObjectStorageClient:
    """Client for BlackAnt Object Storage operations.

    Communicates with the sdk-services storage proxy, which forwards
    requests to the object-storage-manager with JWT-based access control.

    Args:
        auth (BlackAntAuth): Authentication object with credentials.
        base_url (str, optional): Base URL for BlackAnt API.

    Examples:
        >>> auth = BlackAntAuth(user="researcher", password="xxx")
        >>> storage = ObjectStorageClient(auth=auth)
        >>> buckets = storage.list_buckets()
        >>> storage.upload("mybucket", "data.csv", open("data.csv", "rb"))
        >>> storage.download("mybucket", "data.csv", "local_data.csv")
    """

    def __init__(self, auth: BlackAntAuth, base_url: Optional[str] = None):
        self.auth = auth
        self.base_url = base_url or os.getenv("BLACKANT_BASE_URL", "https://blackant.app")
        self.http_client = HTTPClient(base_url=self.base_url, auth_token_store=auth.token_store)
        self.logger = get_logger("services.object_storage")
        self.logger.info("ObjectStorageClient initialized")

    def list_buckets(self, bucket_id: Optional[str] = None) -> Any:
        """List buckets and their contents.

        Args:
            bucket_id: Optional specific bucket to list.
                If omitted, lists all accessible buckets.

        Returns:
            Bucket listing with objects metadata.

        Raises:
            ObjectStorageError: If listing fails.
        """
        try:
            token = self.auth.get_token() if self.auth else None

            json_data = {}
            if bucket_id:
                json_data["bucket_id"] = bucket_id

            response = self.http_client.send_request(
                endpoint="/api/sdk_services/storage/list",
                method="GET",
                json=json_data if json_data else None,
                token=token,
            )
            response.raise_for_status()

            result = response.json()
            self.logger.debug("Listed buckets successfully")
            return result

        except HTTPConnectionError as error:
            self.logger.error("Failed to list buckets: %s", error)
            raise ObjectStorageError("Could not list buckets: %s" % error) from error
        except Exception as error:
            self.logger.error("Unexpected error listing buckets: %s", error)
            raise ObjectStorageError("Bucket listing failed: %s" % error) from error

    def upload(
        self,
        file_path: str,
        bucket_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Upload a file to object storage.

        Args:
            file_path: Local file path to upload.
            bucket_id: Target bucket. If omitted, uses user's default bucket.

        Returns:
            Upload result dictionary.

        Raises:
            ObjectStorageError: If upload fails.
            FileNotFoundError: If file_path doesn't exist.
        """
        if not os.path.exists(file_path):
            raise FileNotFoundError("File not found: %s" % file_path)

        try:
            import requests as req_lib

            token = self.auth.get_token() if self.auth else None

            url = "%s/api/sdk_services/storage" % self.base_url

            headers = {}
            if token:
                headers["Authorization"] = "Bearer %s" % token

            files = {"file": (os.path.basename(file_path), open(file_path, "rb"))}
            data = {}
            if bucket_id:
                data["bucket_id"] = bucket_id

            # Use requests directly for multipart form-data
            verify_ssl = not (
                "localhost" in self.base_url
                or "127.0.0.1" in self.base_url
                or "dev.blackant.app" in self.base_url
            )

            response = req_lib.post(
                url, headers=headers, files=files, data=data, timeout=600, verify=verify_ssl
            )
            response.raise_for_status()

            result = response.json()
            self.logger.info("File uploaded: %s", file_path)
            return result

        except Exception as error:
            self.logger.error("Failed to upload file: %s", error)
            raise ObjectStorageError("File upload failed: %s" % error) from error

    def upload_fileobj(
        self,
        fileobj: BinaryIO,
        filename: str,
        bucket_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Upload a file object to object storage.

        Args:
            fileobj: File-like object to upload.
            filename: Name for the uploaded file.
            bucket_id: Target bucket. If omitted, uses user's default bucket.

        Returns:
            Upload result dictionary.

        Raises:
            ObjectStorageError: If upload fails.
        """
        try:
            import requests as req_lib

            token = self.auth.get_token() if self.auth else None

            url = "%s/api/sdk_services/storage" % self.base_url

            headers = {}
            if token:
                headers["Authorization"] = "Bearer %s" % token

            files = {"file": (filename, fileobj)}
            data = {}
            if bucket_id:
                data["bucket_id"] = bucket_id

            verify_ssl = not (
                "localhost" in self.base_url
                or "127.0.0.1" in self.base_url
                or "dev.blackant.app" in self.base_url
            )

            response = req_lib.post(
                url, headers=headers, files=files, data=data, timeout=600, verify=verify_ssl
            )
            response.raise_for_status()

            result = response.json()
            self.logger.info("File object uploaded: %s", filename)
            return result

        except Exception as error:
            self.logger.error("Failed to upload file object: %s", error)
            raise ObjectStorageError("File upload failed: %s" % error) from error

    def download(
        self,
        object_name: str,
        local_path: str,
        bucket_id: Optional[str] = None,
    ) -> str:
        """Download a file from object storage.

        Args:
            object_name: Name/path of the object to download.
            local_path: Local file path to save to.
            bucket_id: Source bucket. If omitted, uses user's default bucket.

        Returns:
            Local file path where file was saved.

        Raises:
            ObjectStorageError: If download fails.
        """
        try:
            import requests as req_lib

            token = self.auth.get_token() if self.auth else None

            url = "%s/api/sdk_services/storage" % self.base_url

            headers = {}
            if token:
                headers["Authorization"] = "Bearer %s" % token

            json_data = {"object_name": object_name}
            if bucket_id:
                json_data["bucket_id"] = bucket_id

            verify_ssl = not (
                "localhost" in self.base_url
                or "127.0.0.1" in self.base_url
                or "dev.blackant.app" in self.base_url
            )

            response = req_lib.get(
                url, headers=headers, json=json_data, timeout=600, verify=verify_ssl, stream=True
            )
            response.raise_for_status()

            with open(local_path, "wb") as f:
                for chunk in response.iter_content(chunk_size=8192):
                    f.write(chunk)

            self.logger.info("File downloaded: %s -> %s", object_name, local_path)
            return local_path

        except Exception as error:
            self.logger.error("Failed to download file: %s", error)
            raise ObjectStorageError("File download failed: %s" % error) from error

    def delete(
        self,
        object_name: str,
        bucket_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Delete a file from object storage.

        Args:
            object_name: Name/path of the object to delete.
            bucket_id: Bucket containing the object.

        Returns:
            Deletion result dictionary.

        Raises:
            ObjectStorageError: If deletion fails.
        """
        try:
            token = self.auth.get_token() if self.auth else None

            json_data = {"object_name": object_name}
            if bucket_id:
                json_data["bucket_id"] = bucket_id

            response = self.http_client.send_request(
                endpoint="/api/sdk_services/storage", method="DELETE", json=json_data, token=token
            )
            response.raise_for_status()

            result = response.json()
            self.logger.info("File deleted: %s", object_name)
            return result

        except HTTPConnectionError as error:
            self.logger.error("Failed to delete file: %s", error)
            raise ObjectStorageError("File deletion failed: %s" % error) from error
        except Exception as error:
            self.logger.error("Unexpected error deleting file: %s", error)
            raise ObjectStorageError("File deletion failed: %s" % error) from error
