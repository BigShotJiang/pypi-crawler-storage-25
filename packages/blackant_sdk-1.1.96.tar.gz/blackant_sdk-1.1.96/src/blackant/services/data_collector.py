"""BlackAnt Data Collector client module.

Provides MongoDB document operations (CRUD, listing, metadata) through
BlackAnt's sdk-services Data Collector proxy API.
"""

import os
from typing import Dict, Any, Optional, List, Union

from ..auth.blackant_auth import BlackAntAuth
from ..http.client import HTTPClient, HTTPConnectionError
from ..exceptions import BlackAntException
from ..utils.logging import get_logger


class DataCollectorError(BlackAntException):
    """Data Collector operation related errors."""


class DataCollectorClient:
    """Client for BlackAnt Data Collector operations.

    Communicates with the sdk-services data proxy, which forwards
    requests to the data_collector service with JWT-based access control.

    Args:
        auth (BlackAntAuth): Authentication object with credentials.
        base_url (str, optional): Base URL for BlackAnt API.

    Examples:
        >>> auth = BlackAntAuth(user="researcher", password="xxx")
        >>> data = DataCollectorClient(auth=auth)
        >>> data.insert("mydb", "results", {"accuracy": 0.95, "model": "v2"})
        >>> docs = data.query("mydb", "results", {"model": "v2"})
        >>> data.list_databases()
    """

    def __init__(self, auth: BlackAntAuth, base_url: Optional[str] = None):
        self.auth = auth
        self.base_url = base_url or os.getenv("BLACKANT_BASE_URL", "https://blackant.app")
        self.http_client = HTTPClient(base_url=self.base_url, auth_token_store=auth.token_store)
        self.logger = get_logger("services.data_collector")
        self.logger.info("DataCollectorClient initialized")

    def query(
        self,
        database: str,
        collection: str,
        query: Optional[Dict[str, Any]] = None,
    ) -> List[Dict[str, Any]]:
        """Query documents from a collection.

        Args:
            database: Database name.
            collection: Collection name.
            query: Optional MongoDB query filter.

        Returns:
            List of matching documents.

        Raises:
            DataCollectorError: If query fails.
        """
        try:
            token = self.auth.get_token() if self.auth else None

            json_data = {
                "database": database,
                "collection": collection,
            }
            if query:
                json_data["query"] = query

            response = self.http_client.send_request(
                endpoint="/api/sdk_services/data", method="GET", json=json_data, token=token
            )
            response.raise_for_status()

            result = response.json()
            self.logger.debug(
                "Query returned %d documents", len(result) if isinstance(result, list) else 0
            )
            return result

        except HTTPConnectionError as error:
            self.logger.error("Failed to query documents: %s", error)
            raise DataCollectorError("Query failed: %s" % error) from error
        except Exception as error:
            self.logger.error("Unexpected error querying documents: %s", error)
            raise DataCollectorError("Query failed: %s" % error) from error

    def insert(
        self,
        database: str,
        collection: str,
        data: Union[Dict[str, Any], List[Dict[str, Any]]],
    ) -> Dict[str, Any]:
        """Insert one or more documents into a collection.

        Args:
            database: Database name.
            collection: Collection name.
            data: Single document (dict) or list of documents.

        Returns:
            Insert result.

        Raises:
            DataCollectorError: If insert fails.
        """
        try:
            token = self.auth.get_token() if self.auth else None

            json_data = {
                "database": database,
                "collection": collection,
                "data": data,
            }

            response = self.http_client.send_request(
                endpoint="/api/sdk_services/data", method="POST", json=json_data, token=token
            )
            response.raise_for_status()

            count = len(data) if isinstance(data, list) else 1
            self.logger.info("Inserted %d document(s) into %s.%s", count, database, collection)
            return response.json() if response.text else {"success": True}

        except HTTPConnectionError as error:
            self.logger.error("Failed to insert documents: %s", error)
            raise DataCollectorError("Insert failed: %s" % error) from error
        except Exception as error:
            self.logger.error("Unexpected error inserting documents: %s", error)
            raise DataCollectorError("Insert failed: %s" % error) from error

    def update(
        self,
        database: str,
        collection: str,
        doc_id: str,
        data: Dict[str, Any],
    ) -> Dict[str, Any]:
        """Update a document by ID.

        Uses MongoDB $set operator for partial updates.

        Args:
            database: Database name.
            collection: Collection name.
            doc_id: Document _id to update.
            data: Fields to update.

        Returns:
            Update result.

        Raises:
            DataCollectorError: If update fails.
        """
        try:
            token = self.auth.get_token() if self.auth else None

            json_data = {
                "database": database,
                "collection": collection,
                "id": doc_id,
                "data": data,
            }

            response = self.http_client.send_request(
                endpoint="/api/sdk_services/data", method="PUT", json=json_data, token=token
            )
            response.raise_for_status()

            self.logger.info("Updated document %s in %s.%s", doc_id, database, collection)
            return response.json() if response.text else {"success": True}

        except HTTPConnectionError as error:
            self.logger.error("Failed to update document: %s", error)
            raise DataCollectorError("Update failed: %s" % error) from error
        except Exception as error:
            self.logger.error("Unexpected error updating document: %s", error)
            raise DataCollectorError("Update failed: %s" % error) from error

    def delete(
        self,
        database: str,
        collection: str,
        doc_id: str,
    ) -> Dict[str, Any]:
        """Delete a document by ID.

        Args:
            database: Database name.
            collection: Collection name.
            doc_id: Document _id to delete.

        Returns:
            Deletion result.

        Raises:
            DataCollectorError: If deletion fails.
        """
        try:
            token = self.auth.get_token() if self.auth else None

            json_data = {
                "database": database,
                "collection": collection,
                "id": doc_id,
            }

            response = self.http_client.send_request(
                endpoint="/api/sdk_services/data", method="DELETE", json=json_data, token=token
            )
            response.raise_for_status()

            self.logger.info("Deleted document %s from %s.%s", doc_id, database, collection)
            return response.json() if response.text else {"success": True}

        except HTTPConnectionError as error:
            self.logger.error("Failed to delete document: %s", error)
            raise DataCollectorError("Delete failed: %s" % error) from error
        except Exception as error:
            self.logger.error("Unexpected error deleting document: %s", error)
            raise DataCollectorError("Delete failed: %s" % error) from error

    def list_databases(self) -> Any:
        """List all accessible databases with their collections and documents.

        Returns:
            Database listing.

        Raises:
            DataCollectorError: If listing fails.
        """
        return self._list()

    def list_collections(self, database: str) -> Any:
        """List collections in a database.

        Args:
            database: Database name.

        Returns:
            Collection listing.

        Raises:
            DataCollectorError: If listing fails.
        """
        return self._list(database=database)

    def list_documents(self, database: str, collection: str) -> Any:
        """List documents in a collection.

        Args:
            database: Database name.
            collection: Collection name.

        Returns:
            Document listing.

        Raises:
            DataCollectorError: If listing fails.
        """
        return self._list(database=database, collection=collection)

    def _list(
        self,
        database: Optional[str] = None,
        collection: Optional[str] = None,
    ) -> Any:
        """Internal list method with 3 query modes."""
        try:
            token = self.auth.get_token() if self.auth else None

            json_data = {}
            if database:
                json_data["database"] = database
            if collection:
                json_data["collection"] = collection

            response = self.http_client.send_request(
                endpoint="/api/sdk_services/data/list",
                method="GET",
                json=json_data if json_data else None,
                token=token,
            )
            response.raise_for_status()
            return response.json()

        except HTTPConnectionError as error:
            self.logger.error("Failed to list data: %s", error)
            raise DataCollectorError("List failed: %s" % error) from error
        except Exception as error:
            self.logger.error("Unexpected error listing data: %s", error)
            raise DataCollectorError("List failed: %s" % error) from error

    def get_metadata(
        self,
        database: Optional[str] = None,
        collection: Optional[str] = None,
    ) -> Any:
        """Get metadata about databases/collections.

        Args:
            database: Optional database name for DB-level stats.
            collection: Optional collection name for collection-level stats.

        Returns:
            Metadata with statistics (data_size, storage_size, document_count, etc.)

        Raises:
            DataCollectorError: If metadata query fails.
        """
        try:
            token = self.auth.get_token() if self.auth else None

            json_data = {}
            if database:
                json_data["database"] = database
            if collection:
                json_data["collection"] = collection

            response = self.http_client.send_request(
                endpoint="/api/sdk_services/data/metadata",
                method="GET",
                json=json_data if json_data else None,
                token=token,
            )
            response.raise_for_status()
            return response.json()

        except HTTPConnectionError as error:
            self.logger.error("Failed to get metadata: %s", error)
            raise DataCollectorError("Metadata query failed: %s" % error) from error
        except Exception as error:
            self.logger.error("Unexpected error getting metadata: %s", error)
            raise DataCollectorError("Metadata query failed: %s" % error) from error
