"""Request ID storage and generation module.

Provides unique request ID generation and storage for
distributed tracing and request tracking.
"""

import time
import uuid

from ..utils.store import Store


class RequestIdStore(Store):
    """Request ID storage and generator class.

    Generates and stores unique request identifiers for
    HTTP requests and distributed tracing.
    """

    def __init__(self, header_name="X-Request-ID"):
        """Initialize request ID store.

        Args:
            header_name (str): HTTP header name for request ID.
        """
        super().__init__()
        # Use instance variable instead of class variable
        if not hasattr(self, "header_name"):
            self.header_name = header_name
        if not hasattr(self, "_counter"):
            self._counter = 0

    def generate_id(self):
        """Generate a new unique request ID.

        Returns:
            str: Unique request ID.
        """
        self._counter += 1
        timestamp = int(time.time() * 1000)
        request_id = f"req_{timestamp}_{self._counter}_{uuid.uuid4().hex[:8]}"
        self._set("current_request_id", request_id)
        return request_id

    @property
    def rid(self):
        """Get current request ID.

        Returns:
            str or None: Current request ID or None if not set.
        """
        return self._get("current_request_id")
