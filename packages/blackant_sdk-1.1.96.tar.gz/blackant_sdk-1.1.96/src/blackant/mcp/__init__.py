"""BlackAnt SDK MCP (Model Context Protocol) server interface.

Provides MCP tools for AI agents to interact with the BlackAnt
computing platform through a standardized protocol.
"""

from .exceptions import MCPToolError
from .server import create_server, main


def create_server():
    """Create and configure the BlackAnt MCP server. Requires mcp package."""
    from .server import create_server as _create_server

    return _create_server()


def main():
    """Entry point for the blackant-mcp command. Requires mcp package."""
    from .server import main as _main

    _main()


__all__ = ["create_server", "main", "MCPToolError"]
