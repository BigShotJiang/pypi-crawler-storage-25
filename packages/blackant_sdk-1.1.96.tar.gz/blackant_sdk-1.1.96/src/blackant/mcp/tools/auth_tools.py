"""Authentication tools for BlackAnt MCP server.

Provides MCP tools for authenticating with the BlackAnt platform
and checking current authentication status.
"""

from mcp.server.fastmcp import FastMCP

from ...utils.logging import get_logger
from ..exceptions import MCPToolError
from ..session import BlackAntMCPSession

logger = get_logger("mcp.auth")


def authenticate_handler(session: BlackAntMCPSession, username: str, password: str) -> dict:
    """Handle blackant_authenticate tool logic.

    Args:
        session: The MCP session instance.
        username: BlackAnt username or email.
        password: BlackAnt password.

    Returns:
        Dictionary with authentication result (never includes raw tokens).

    Raises:
        MCPToolError: If authentication fails.
    """
    try:
        success = session.authenticate(username, password)
        if not success:
            raise MCPToolError("Authentication failed. Check credentials.")
        return {
            "success": True,
            "message": f"Authenticated as {username}",
        }
    except MCPToolError:
        raise
    except Exception as e:
        logger.error("Authentication failed: %s", str(e))
        raise MCPToolError(f"Authentication failed: {str(e)}")


def token_status_handler(session: BlackAntMCPSession) -> dict:
    """Handle blackant_token_status tool logic.

    Args:
        session: The MCP session instance.

    Returns:
        Dictionary with current authentication status.
    """
    if not session.authenticated:
        return {"authenticated": False}
    return {
        "authenticated": True,
        "username": session.username or "unknown",
    }


def register_auth_tools(server: FastMCP, session: BlackAntMCPSession) -> None:
    """Register authentication tools on the MCP server.

    Args:
        server: The FastMCP server instance.
        session: The shared MCP session.
    """

    @server.tool()
    def blackant_authenticate(username: str, password: str) -> dict:
        """Authenticate with BlackAnt platform using username and password. Returns auth status without exposing tokens."""
        return authenticate_handler(session, username, password)

    @server.tool()
    def blackant_token_status() -> dict:
        """Check current BlackAnt authentication status. Returns whether authenticated and the current username."""
        return token_status_handler(session)
