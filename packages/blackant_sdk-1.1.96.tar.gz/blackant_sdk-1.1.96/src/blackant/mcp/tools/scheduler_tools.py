"""Scheduler tools for BlackAnt MCP server.

Provides MCP tools for creating, monitoring, and managing
computation schedules on the BlackAnt platform.
"""

import json
from typing import Any, Dict, List, Optional

from mcp.server.fastmcp import FastMCP

from ...utils.logging import get_logger
from ..exceptions import MCPToolError
from ..session import BlackAntMCPSession

logger = get_logger("mcp.scheduler")


def create_schedule_handler(
    session: BlackAntMCPSession,
    calculation_name: str,
    image_tag: str = "latest",
    cmd_args: Optional[str] = None,
) -> dict:
    """Handle blackant_create_schedule tool logic.

    Args:
        session: The MCP session instance.
        calculation_name: Name of the registered service/calculation.
        image_tag: Docker image tag to run.
        cmd_args: JSON string of command-line arguments for the calculation.

    Returns:
        Dictionary with schedule UUID and status.

    Raises:
        MCPToolError: If schedule creation fails.
    """
    parsed_args = None
    if cmd_args:
        try:
            parsed_args = json.loads(cmd_args)
        except json.JSONDecodeError as e:
            raise MCPToolError(f"Invalid cmd_args JSON: {str(e)}")

    try:
        schedule_uuid = session.client.create_schedule(
            calculation_name=calculation_name,
            image_tag=image_tag,
            cmd_args=parsed_args,
        )
        return {
            "schedule_uuid": schedule_uuid,
            "calculation_name": calculation_name,
            "image_tag": image_tag,
            "status": "created",
            "message": f"Schedule created for '{calculation_name}'. "
            f"Use blackant_schedule_status to monitor progress.",
        }
    except MCPToolError:
        raise
    except Exception as e:
        logger.error("Failed to create schedule for %s: %s", calculation_name, str(e))
        raise MCPToolError(f"Failed to create schedule: {str(e)}")


def schedule_status_handler(session: BlackAntMCPSession, schedule_uuid: str) -> dict:
    """Handle blackant_schedule_status tool logic.

    Args:
        session: The MCP session instance.
        schedule_uuid: UUID of the schedule to check.

    Returns:
        Dictionary with schedule state and details.

    Raises:
        MCPToolError: If status retrieval fails.
    """
    try:
        schedule = session.client.get_schedule(schedule_uuid)
        state = schedule.get("state", "unknown")
        return {
            "schedule_uuid": schedule_uuid,
            "state": state,
            "calculation_name": schedule.get("calculationName", ""),
            "image_tag": schedule.get("image_tag", ""),
            "creation_time": schedule.get("creationTime", ""),
            "is_terminal": state.lower() in ("done", "permanentfailure", "cancelled"),
        }
    except MCPToolError:
        raise
    except Exception as e:
        logger.error("Failed to get schedule status %s: %s", schedule_uuid, str(e))
        raise MCPToolError(f"Failed to get schedule status: {str(e)}")


def get_task_result_handler(session: BlackAntMCPSession, schedule_uuid: str) -> dict:
    """Handle blackant_get_task_result tool logic.

    Args:
        session: The MCP session instance.
        schedule_uuid: UUID of the completed schedule.

    Returns:
        Dictionary with task results.

    Raises:
        MCPToolError: If result retrieval fails.
    """
    try:
        tasks = session.client.get_task_results(schedule_uuid)
        if not tasks:
            return {
                "schedule_uuid": schedule_uuid,
                "task_count": 0,
                "tasks": [],
                "message": "No tasks found. Schedule may still be running.",
            }

        results = []
        for task in tasks:
            result_raw = task.get("result", "")
            parsed_result = result_raw
            if isinstance(result_raw, str) and result_raw:
                try:
                    parsed_result = json.loads(result_raw)
                except (json.JSONDecodeError, ValueError):
                    pass

            results.append({
                "task_uuid": task.get("uuid", ""),
                "state": task.get("state", ""),
                "execution_time": task.get("execution_time", ""),
                "result": parsed_result,
                "log": str(task.get("log", ""))[:1000],
            })

        return {
            "schedule_uuid": schedule_uuid,
            "task_count": len(results),
            "tasks": results,
        }
    except MCPToolError:
        raise
    except Exception as e:
        logger.error("Failed to get task results for %s: %s", schedule_uuid, str(e))
        raise MCPToolError(f"Failed to get task results: {str(e)}")


def list_schedules_handler(session: BlackAntMCPSession) -> list:
    """Handle blackant_list_schedules tool logic.

    Args:
        session: The MCP session instance.

    Returns:
        List of schedule summary dictionaries.

    Raises:
        MCPToolError: If listing fails.
    """
    try:
        schedules = session.client.list_schedules()
        return [
            {
                "uuid": s.get("uuid", ""),
                "calculation_name": s.get("calculationName", ""),
                "state": s.get("state", ""),
                "image_tag": s.get("image_tag", ""),
                "creation_time": s.get("creationTime", ""),
            }
            for s in schedules
        ]
    except MCPToolError:
        raise
    except Exception as e:
        logger.error("Failed to list schedules: %s", str(e))
        raise MCPToolError(f"Failed to list schedules: {str(e)}")


def delete_schedule_handler(session: BlackAntMCPSession, schedule_uuid: str) -> dict:
    """Handle blackant_delete_schedule tool logic.

    Args:
        session: The MCP session instance.
        schedule_uuid: UUID of the schedule to delete.

    Returns:
        Dictionary with deletion result.

    Raises:
        MCPToolError: If deletion fails.
    """
    try:
        success = session.client.delete_schedule(schedule_uuid)
        if success:
            return {
                "schedule_uuid": schedule_uuid,
                "deleted": True,
                "message": "Schedule deleted successfully.",
            }
        raise MCPToolError(f"Failed to delete schedule {schedule_uuid}.")
    except MCPToolError:
        raise
    except Exception as e:
        logger.error("Failed to delete schedule %s: %s", schedule_uuid, str(e))
        raise MCPToolError(f"Failed to delete schedule: {str(e)}")


def register_scheduler_tools(server: FastMCP, session: BlackAntMCPSession) -> None:
    """Register scheduler tools on the MCP server.

    Args:
        server: The FastMCP server instance.
        session: The shared MCP session.
    """

    @server.tool()
    def blackant_create_schedule(
        calculation_name: str,
        image_tag: str = "latest",
        cmd_args: str = "",
    ) -> dict:
        """Create a computation schedule on BlackAnt. Pass cmd_args as JSON string e.g. '{"numbers": [1,2,3]}'."""
        return create_schedule_handler(session, calculation_name, image_tag, cmd_args or None)

    @server.tool()
    def blackant_schedule_status(schedule_uuid: str) -> dict:
        """Check the current state of a BlackAnt schedule. States: waitingForTrigger, running, done, permanentFailure."""
        return schedule_status_handler(session, schedule_uuid)

    @server.tool()
    def blackant_get_task_result(schedule_uuid: str) -> dict:
        """Get computation results from a completed BlackAnt schedule including output data and logs."""
        return get_task_result_handler(session, schedule_uuid)

    @server.tool()
    def blackant_list_schedules() -> list:
        """List all computation schedules on BlackAnt with their states and creation times."""
        return list_schedules_handler(session)

    @server.tool()
    def blackant_delete_schedule(schedule_uuid: str) -> dict:
        """Delete a BlackAnt schedule by UUID. Use for cleanup after retrieving results."""
        return delete_schedule_handler(session, schedule_uuid)
