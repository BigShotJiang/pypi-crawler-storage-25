"""Service management tools for BlackAnt MCP server.

Provides MCP tools for building, listing, and inspecting
services on the BlackAnt computing platform.
"""

from mcp.server.fastmcp import FastMCP

from ...utils.logging import get_logger
from ..exceptions import MCPToolError
from ..security.input_validator import validate_gpu_count, validate_service_name, validate_source_path
from ..session import BlackAntMCPSession

logger = get_logger("mcp.services")


def build_service_handler(
    session: BlackAntMCPSession,
    source_path: str,
    service_name: str,
    gpu_count: int = 0,
    description: str = "",
) -> dict:
    """Handle blackant_build_service tool logic.

    Args:
        session: The MCP session instance.
        source_path: Absolute path to directory containing Dockerfile.
        service_name: URI-compatible service identifier.
        gpu_count: Number of GPUs (0-8).
        description: Service description (max 500 chars).

    Returns:
        Dictionary with build result including service_id and status.

    Raises:
        MCPToolError: If validation or build fails.
    """
    try:
        validated_name = validate_service_name(service_name)
        validated_gpu = validate_gpu_count(gpu_count)
        resolved_path = validate_source_path(source_path)
    except ValueError as e:
        raise MCPToolError(str(e))

    if len(description) > 500:
        raise MCPToolError("Description must be 500 characters or fewer.")

    try:
        extra_args = {}
        if validated_gpu > 0:
            extra_args["GPU_COUNT"] = str(validated_gpu)

        result = session.client.build_service(
            service_name=validated_name,
            impl_path=str(resolved_path),
            push=True,
            register_service=True,
            extra_build_args=extra_args or None,
        )
        return {
            "service_id": result.get("service_id", ""),
            "status": "BUILD_SUCCESS" if result.get("build_success") else "BUILD_FAILED",
            "message": f"Service '{validated_name}' built successfully",
            "image": result.get("full_image", ""),
        }
    except MCPToolError:
        raise
    except Exception as e:
        logger.error("Build failed for %s: %s", service_name, str(e))
        raise MCPToolError(f"Build failed for '{service_name}': {str(e)}")


def list_services_handler(session: BlackAntMCPSession, namespace: str = "default") -> list:
    """Handle blackant_list_services tool logic.

    Args:
        session: The MCP session instance.
        namespace: Namespace filter for services.

    Returns:
        List of service dictionaries.

    Raises:
        MCPToolError: If listing fails.
    """
    try:
        return session.client.list_services(namespace=namespace)
    except Exception as e:
        logger.error("Failed to list services: %s", str(e))
        raise MCPToolError(f"Failed to list services: {str(e)}")


def service_status_handler(session: BlackAntMCPSession, service_name: str) -> dict:
    """Handle blackant_service_status tool logic.

    Args:
        session: The MCP session instance.
        service_name: Name of the service to query.

    Returns:
        Dictionary with service runtime status.

    Raises:
        MCPToolError: If status retrieval fails.
    """
    try:
        return session.client.get_service_status(service_name=service_name)
    except Exception as e:
        logger.error("Failed to get status for %s: %s", service_name, str(e))
        raise MCPToolError(f"Failed to get service status for '{service_name}': {str(e)}")


def get_service_handler(session: BlackAntMCPSession, service_name: str) -> dict:
    """Handle blackant_get_service tool logic.

    Args:
        session: The MCP session instance.
        service_name: Name of the service to query.

    Returns:
        Dictionary with detailed service information.

    Raises:
        MCPToolError: If retrieval fails.
    """
    try:
        return session.client.get_service(service_name=service_name)
    except Exception as e:
        logger.error("Failed to get service %s: %s", service_name, str(e))
        raise MCPToolError(f"Failed to get service info for '{service_name}': {str(e)}")


def check_connection_handler(session: BlackAntMCPSession) -> dict:
    """Handle blackant_test_connection tool logic.

    Args:
        session: The MCP session instance.

    Returns:
        Dictionary with connectivity test result.

    Raises:
        MCPToolError: If connection test fails.
    """
    try:
        success = session.client.test_connection()
        return {
            "connected": success,
            "message": "All systems operational" if success else "Connection test failed",
        }
    except Exception as e:
        logger.error("Connection test failed: %s", str(e))
        raise MCPToolError(f"Connection test failed: {str(e)}")


def register_service_tools(server: FastMCP, session: BlackAntMCPSession) -> None:
    """Register service management tools on the MCP server.

    Args:
        server: The FastMCP server instance.
        session: The shared MCP session.
    """

    @server.tool()
    def blackant_build_service(
        source_path: str,
        service_name: str,
        gpu_count: int = 0,
        description: str = "",
    ) -> dict:
        """Build and deploy a Docker service to BlackAnt. Requires a Dockerfile in source_path directory."""
        return build_service_handler(session, source_path, service_name, gpu_count, description)

    @server.tool()
    def blackant_list_services(namespace: str = "default") -> list:
        """List all services registered on BlackAnt platform, optionally filtered by namespace."""
        return list_services_handler(session, namespace)

    @server.tool()
    def blackant_service_status(service_name: str) -> dict:
        """Get runtime status of a specific BlackAnt service by name."""
        return service_status_handler(session, service_name)

    @server.tool()
    def blackant_get_service(service_name: str) -> dict:
        """Get detailed information about a specific BlackAnt service including metadata and configuration."""
        return get_service_handler(session, service_name)

    @server.tool()
    def blackant_test_connection() -> dict:
        """Test connectivity to BlackAnt platform, Docker API, and Service Registry."""
        return check_connection_handler(session)
