"""BlackAnt MCP session management.

Manages authentication and service registry access for the MCP server.
Uses lightweight composition (Auth + ServiceRegistry) instead of the full
BlackAntClient to avoid Docker daemon dependency for API-only operations.
"""

import os
import threading
import time
from typing import Any, Dict, List, Optional

from ..auth.blackant_auth import BlackAntAuth
from ..http.client import HTTPClient
from ..services.registry import ServiceRegistry
from ..utils.logging import get_logger
from .exceptions import MCPToolError
from .security.request_context import get_current_identity

logger = get_logger("mcp.session")


class MCPClientFacade:
    """Lightweight client facade for MCP tools.

    Provides the same interface as BlackAntClient for the methods
    needed by MCP tools, without initializing the Docker subsystem.
    For build_service, lazily creates the full BlackAntClient.

    Attributes:
        auth: The BlackAntAuth instance.
        service_registry: The ServiceRegistry for API operations.
    """

    TOKEN_TTL = 50  # Re-authenticate before the 60s Keycloak TTL expires

    def __init__(self, auth: BlackAntAuth, base_url: str):
        """Initialize lightweight client facade.

        Args:
            auth: Authenticated BlackAntAuth instance.
            base_url: BlackAnt platform base URL.
        """
        self.auth = auth
        self._base_url = base_url
        self._login_url = f"{base_url.rstrip('/')}/api/auth/login"
        self.service_registry = ServiceRegistry(auth=auth, base_url=base_url)
        self.http_client = HTTPClient(base_url=base_url, auth_token_store=auth.token_store)
        self._full_client = None
        self._token_time = time.time()

    def _ensure_fresh_token(self):
        """Re-authenticate if the token is older than TOKEN_TTL seconds."""
        if time.time() - self._token_time > self.TOKEN_TTL:
            self.auth.authenticate()
            self._token_time = time.time()

    def authenticate(self) -> bool:
        """Authenticate with BlackAnt platform.

        Returns:
            True if authentication successful.
        """
        token = self.auth.authenticate()
        self._token_time = time.time()
        return bool(token)

    def is_authenticated(self) -> bool:
        """Check if currently authenticated.

        Returns:
            True if authenticated with valid token.
        """
        return self.auth.is_authenticated()

    def test_connection(self) -> bool:
        """Test connection to BlackAnt platform.

        Returns:
            True if service registry is reachable.
        """
        self._ensure_fresh_token()
        self.service_registry.list()
        return True

    def list_services(self, namespace: Optional[str] = None) -> List[Dict[str, Any]]:
        """List all services.

        Args:
            namespace: Optional namespace filter.

        Returns:
            List of service dictionaries.
        """
        self._ensure_fresh_token()
        return self.service_registry.list(namespace=namespace)

    def get_service(
        self, service_id: str = None, service_name: str = None
    ) -> Dict[str, Any]:
        """Get service details.

        Args:
            service_id: Service UUID.
            service_name: Service name.

        Returns:
            Service details dictionary.
        """
        self._ensure_fresh_token()
        return self.service_registry.get(service_id=service_id, service_name=service_name)

    def get_service_status(
        self, service_id: str = None, service_name: str = None
    ) -> Dict[str, Any]:
        """Get runtime status of a service.

        Args:
            service_id: Service UUID.
            service_name: Service name.

        Returns:
            Service status dictionary.
        """
        self._ensure_fresh_token()
        return self.service_registry.get_status(
            service_id=service_id, service_name=service_name
        )

    def create_schedule(
        self,
        calculation_name: str,
        image_tag: str = "latest",
        cmd_args: Optional[Dict[str, Any]] = None,
        callback: Optional[Dict[str, Any]] = None,
    ) -> str:
        """Create a scheduler schedule for a calculation.

        Args:
            calculation_name: Name of the registered service/calculation.
            image_tag: Docker image tag to run.
            cmd_args: Command-line arguments for the calculation.
            callback: Optional callback configuration.

        Returns:
            Schedule UUID string.
        """
        self._ensure_fresh_token()
        token = self.auth.get_token()
        task_config = {}
        if cmd_args:
            task_config["cmdArgs"] = cmd_args
        if callback:
            task_config["callback"] = callback

        payload = {
            "calculationName": calculation_name,
            "image_tag": image_tag,
            "taskConfig": task_config,
        }
        response = self.http_client.send_request(
            endpoint="/api/scheduler/schedule",
            method="POST",
            json=payload,
            token=token,
        )
        response.raise_for_status()
        return response.text.strip().strip('"')

    def get_schedule(self, schedule_uuid: str) -> Dict[str, Any]:
        """Get schedule details by UUID.

        Args:
            schedule_uuid: Schedule UUID.

        Returns:
            Schedule details dictionary.
        """
        self._ensure_fresh_token()
        token = self.auth.get_token()
        response = self.http_client.send_request(
            endpoint="/api/scheduler/schedule",
            method="GET",
            json={"uuid": schedule_uuid},
            token=token,
        )
        response.raise_for_status()
        data = response.json()
        if isinstance(data, list) and len(data) > 0:
            return data[0]
        return data

    def get_task_results(self, schedule_uuid: str) -> List[Dict[str, Any]]:
        """Get task results for a completed schedule.

        Args:
            schedule_uuid: Schedule UUID.

        Returns:
            List of task result dictionaries.
        """
        self._ensure_fresh_token()
        token = self.auth.get_token()
        response = self.http_client.send_request(
            endpoint=f"/api/scheduler/schedule/related_tasks/{schedule_uuid}",
            method="GET",
            json={},
            token=token,
        )
        response.raise_for_status()
        return response.json()

    def list_schedules(self) -> List[Dict[str, Any]]:
        """List all schedules.

        Returns:
            List of schedule dictionaries.
        """
        self._ensure_fresh_token()
        token = self.auth.get_token()
        response = self.http_client.send_request(
            endpoint="/api/scheduler/schedule",
            method="GET",
            json={},
            token=token,
        )
        response.raise_for_status()
        data = response.json()
        if isinstance(data, list):
            return data
        return [data] if data else []

    def delete_schedule(self, schedule_uuid: str) -> bool:
        """Delete a schedule.

        Args:
            schedule_uuid: Schedule UUID.

        Returns:
            True if deletion succeeded.
        """
        self._ensure_fresh_token()
        token = self.auth.get_token()
        response = self.http_client.send_request(
            endpoint="/api/scheduler/schedule",
            method="DELETE",
            json={"uuid": schedule_uuid},
            token=token,
        )
        return response.status_code in (200, 204)

    def build_service(self, **kwargs) -> Dict[str, Any]:
        """Build and deploy a Docker service.

        Lazily creates the full BlackAntClient with Docker support
        only when build_service is actually called.

        Args:
            **kwargs: Arguments forwarded to BlackAntClient.build_service.

        Returns:
            Build result dictionary.

        Raises:
            MCPToolError: If Docker client initialization fails.
        """
        if self._full_client is None:
            try:
                from ..client import BlackAntClient

                self._full_client = BlackAntClient(
                    user=self.auth.user,
                    password=self.auth.password,
                    base_url=self._base_url,
                    login_url=self._login_url,
                )
                self._full_client.authenticate()
            except Exception as e:
                raise MCPToolError(
                    f"Docker client initialization failed: {str(e)}. "
                    f"Ensure Docker environment variables are configured."
                )
        return self._full_client.build_service(**kwargs)


class BlackAntMCPSession:
    """Manages authentication and API access for MCP tool calls.

    Supports two authentication modes:
    - Pre-auth: Authenticates at startup using environment variables.
    - Agent-auth: Starts unauthenticated, requires explicit authenticate call.

    Attributes:
        client: The active client facade for API operations.
        authenticated: Whether the session is currently authenticated.
        username: The authenticated username, if any.
    """

    def __init__(self, base_url: Optional[str] = None):
        """Initialize MCP session.

        If BLACKANT_USER and BLACKANT_PASSWORD environment variables are set,
        authentication happens automatically at startup.

        Args:
            base_url: BlackAnt platform URL override.
        """
        self._lock = threading.Lock()
        self._clients: Dict[str, MCPClientFacade] = {}
        self._base_url = base_url or os.getenv("BLACKANT_BASE_URL", "https://dev.blackant.app")
        self._login_url = f"{self._base_url.rstrip('/')}/api/auth/login"
        self._usernames: Dict[str, str] = {}

        user = os.getenv("BLACKANT_USER")
        password = os.getenv("BLACKANT_PASSWORD")
        if user and password:
            logger.info("Auto-authenticating from environment variables")
            self.authenticate(user, password)

    @staticmethod
    def _resolve_context_key(context_key: Optional[str] = None) -> str:
        """Resolve the per-caller context key used for session isolation."""
        if context_key:
            return context_key
        identity = get_current_identity()
        if identity:
            return f"subject:{identity}"
        return "default"

    def get_client(self, context_key: Optional[str] = None) -> MCPClientFacade:
        """Get the authenticated client facade for the current caller context."""
        key = self._resolve_context_key(context_key)
        client = self._clients.get(key)
        if client is None:
            raise MCPToolError(
                "Not authenticated. Set BLACKANT_USER and BLACKANT_PASSWORD "
                "environment variables or call blackant_authenticate first."
            )
        return client

    def is_authenticated(self, context_key: Optional[str] = None) -> bool:
        """Check authentication status for the current caller context."""
        key = self._resolve_context_key(context_key)
        client = self._clients.get(key)
        if client is None:
            return False
        try:
            return client.is_authenticated()
        except Exception:
            return False

    def get_username(self, context_key: Optional[str] = None) -> Optional[str]:
        """Get authenticated username for the current caller context."""
        key = self._resolve_context_key(context_key)
        return self._usernames.get(key)

    @property
    def client(self) -> MCPClientFacade:
        """Get the authenticated client facade.

        Returns:
            The active MCPClientFacade.

        Raises:
            MCPToolError: If no authenticated client is available.
        """
        return self.get_client()

    @property
    def authenticated(self) -> bool:
        """Check if the session has an authenticated client.

        Returns:
            True if authenticated with a valid token.
        """
        return self.is_authenticated()

    @property
    def username(self) -> Optional[str]:
        """Get the authenticated username.

        Returns:
            The username string, or None if not authenticated.
        """
        return self.get_username()

    def authenticate(self, username: str, password: str, context_key: Optional[str] = None) -> bool:
        """Authenticate with BlackAnt platform.

        Thread-safe authentication that creates a lightweight client
        and performs the Keycloak login flow.

        Args:
            username: BlackAnt username or email.
            password: BlackAnt password.

        Returns:
            True if authentication succeeded.

        Raises:
            MCPToolError: If authentication fails.
        """
        key = self._resolve_context_key(context_key)
        with self._lock:
            try:
                auth = BlackAntAuth(
                    user=username,
                    password=password,
                    login_url=self._login_url,
                )
                token = auth.authenticate()
                if token:
                    self._clients[key] = MCPClientFacade(auth=auth, base_url=self._base_url)
                    self._usernames[key] = username
                    logger.info("MCP session authenticated for user: %s (context=%s)", username, key)
                    return True
                raise MCPToolError("Authentication failed. Check credentials and server URL.")
            except MCPToolError:
                raise
            except Exception as e:
                logger.error("Authentication error: %s", str(e))
                raise MCPToolError(f"Authentication failed: {str(e)}")
