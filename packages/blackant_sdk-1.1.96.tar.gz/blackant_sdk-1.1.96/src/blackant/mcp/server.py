"""BlackAnt MCP server setup and entry point.

Creates and configures the MCP server with all BlackAnt SDK tools
for AI agent interaction via the Model Context Protocol.
Supports stdio (local) and SSE (remote/Perplexity) transports.
"""

import argparse
import os

from mcp.server.fastmcp import FastMCP

from ..utils.logging import get_logger
from .session import BlackAntMCPSession
from .tools.auth_tools import register_auth_tools
from .tools.scheduler_tools import register_scheduler_tools
from .tools.service_tools import register_service_tools

logger = get_logger("mcp.server")


def create_server(transport: str = "stdio") -> FastMCP:
    """Create and configure the BlackAnt MCP server.

    Reads configuration from environment variables:
        BLACKANT_BASE_URL: Platform URL (default: https://dev.blackant.app)
        BLACKANT_LOG_LEVEL: Logging level (default: INFO)
        BLACKANT_USER: Username for auto-authentication at startup
        BLACKANT_PASSWORD: Password for auto-authentication at startup
        BLACKANT_MCP_HOST: SSE bind host (default: 0.0.0.0)
        BLACKANT_MCP_PORT: SSE bind port (default: 8000)

    Args:
        transport: Transport protocol ("stdio" or "sse").

    Returns:
        Configured FastMCP server instance with all tools registered.
    """
    base_url = os.getenv("BLACKANT_BASE_URL", "https://dev.blackant.app")
    log_level = os.getenv("BLACKANT_LOG_LEVEL", "INFO")

    logger.info("Creating BlackAnt MCP server (base_url=%s, transport=%s)", base_url, transport)

    server_kwargs = {"name": "BlackAnt SDK"}

    if transport == "sse":
        host = os.getenv("BLACKANT_MCP_HOST", "0.0.0.0")
        port = int(os.getenv("BLACKANT_MCP_PORT", "8000"))
        server_kwargs.update(host=host, port=port, log_level=log_level)

        if os.getenv("BLACKANT_MCP_AUTH", "true").lower() == "true":
            from .security.token_verifier import KeycloakTokenVerifier

            server_kwargs["token_verifier"] = KeycloakTokenVerifier(base_url=base_url)
            logger.info("Keycloak token verification enabled for SSE transport")

    server = FastMCP(**server_kwargs)
    session = BlackAntMCPSession(base_url=base_url)

    register_auth_tools(server, session)
    register_service_tools(server, session)
    register_scheduler_tools(server, session)

    logger.info("BlackAnt MCP server ready with 12 tools registered")
    return server


def main() -> None:
    """Entry point for the blackant-mcp command.

    Parses command-line arguments and starts the MCP server
    with the specified transport.
    """
    parser = argparse.ArgumentParser(
        prog="blackant-mcp",
        description="BlackAnt SDK MCP Server - AI agent interface for the BlackAnt computing platform",
    )
    parser.add_argument(
        "--transport",
        choices=["stdio", "sse"],
        default="stdio",
        help="MCP transport protocol (default: stdio)",
    )
    parser.add_argument(
        "--host",
        default=None,
        help="SSE bind host (default: 0.0.0.0, env: BLACKANT_MCP_HOST)",
    )
    parser.add_argument(
        "--port",
        type=int,
        default=None,
        help="SSE bind port (default: 8000, env: BLACKANT_MCP_PORT)",
    )
    parser.add_argument(
        "--no-auth",
        action="store_true",
        help="Disable token verification for SSE transport (dev only)",
    )
    args = parser.parse_args()

    if args.host:
        os.environ["BLACKANT_MCP_HOST"] = args.host
    if args.port:
        os.environ["BLACKANT_MCP_PORT"] = str(args.port)
    if args.no_auth:
        os.environ["BLACKANT_MCP_AUTH"] = "false"

    server = create_server(transport=args.transport)
    logger.info("Starting BlackAnt MCP server with transport: %s", args.transport)
    server.run(transport=args.transport)
