"""Exceptions for BlackAnt MCP server."""


class MCPToolError(Exception):
    """Error raised by MCP tools with user-friendly messages.

    Attributes:
        details: Additional error context for debugging.
    """

    def __init__(self, message: str, details: dict = None):
        """Initialize MCPToolError.

        Args:
            message: Human-readable error description.
            details: Optional dictionary with additional error context.
        """
        super().__init__(message)
        self.details = details or {}
