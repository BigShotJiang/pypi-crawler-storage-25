"""Request-scoped identity context for MCP calls.

Stores the authenticated caller identity for the current request context.
This enables per-caller session isolation without changing tool signatures.
"""

from contextvars import ContextVar
from typing import Optional

_CURRENT_IDENTITY: ContextVar[Optional[str]] = ContextVar("mcp_current_identity", default=None)


def set_current_identity(identity: Optional[str]) -> None:
    """Set current caller identity for this request context."""
    _CURRENT_IDENTITY.set(identity)


def get_current_identity() -> Optional[str]:
    """Get current caller identity for this request context."""
    return _CURRENT_IDENTITY.get()
