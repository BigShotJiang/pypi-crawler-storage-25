"""Keycloak token verifier for BlackAnt MCP SSE transport.

Validates Bearer tokens from remote MCP clients (Perplexity, etc.)
against the BlackAnt Keycloak instance. Supports both JWT decode
and Keycloak introspection endpoint verification.
"""

import os
import time
from dataclasses import dataclass
from typing import Optional

import jwt
import requests

from ...utils.logging import get_logger
from .request_context import set_current_identity

logger = get_logger("mcp.security")


@dataclass
class AccessToken:
    """Verified access token with user context.

    Attributes:
        token: The raw JWT string.
        client_id: OAuth client ID.
        scopes: Granted scopes.
        subject: Keycloak user ID (sub claim).
        username: Preferred username from token.
    """

    token: str
    client_id: str
    scopes: list
    subject: str
    username: str


class KeycloakTokenVerifier:
    """Verifies Bearer tokens against BlackAnt Keycloak.

    Two verification strategies in order:
    1. JWT decode (fast, offline) — decodes and checks exp/iss claims
    2. Keycloak introspection (online, authoritative) — fallback

    For dev environments, signature verification is skipped since
    the Keycloak public key is not distributed with the SDK.

    Attributes:
        base_url: BlackAnt platform base URL.
        verify_url: Keycloak token verification endpoint.
    """

    def __init__(self, base_url: Optional[str] = None):
        """Initialize with BlackAnt platform URL.

        Args:
            base_url: Platform URL for Keycloak endpoints.
        """
        self.base_url = base_url or os.getenv("BLACKANT_BASE_URL", "https://dev.blackant.app")
        self.verify_url = f"{self.base_url.rstrip('/')}/api/auth/verify"
        self._verify_ssl = "dev.blackant.app" not in self.base_url
        self._jwt_public_key = os.getenv("BLACKANT_JWT_PUBLIC_KEY")
        self._jwt_algorithm = os.getenv("BLACKANT_JWT_ALGORITHM", "RS256")
        self._jwt_issuer = os.getenv("BLACKANT_JWT_ISSUER")

    async def verify_token(self, token: str) -> Optional[AccessToken]:
        """Verify a Bearer token from an MCP client.

        First tries offline JWT decode, then falls back to
        Keycloak introspection if needed.

        Args:
            token: Raw JWT Bearer token string.

        Returns:
            AccessToken if valid, None if invalid.
        """
        set_current_identity(None)
        if not token:
            return None

        decoded = self._decode_jwt(token)
        if decoded is None:
            decoded = self._introspect_token(token)

        if decoded is None:
            logger.warning("Token verification failed")
            return None

        subject = decoded.get("sub")
        if not subject:
            logger.warning("Token verification failed: missing 'sub' claim")
            return None
        set_current_identity(subject)

        return AccessToken(
            token=token,
            client_id=decoded.get("azp", "unknown"),
            scopes=decoded.get("scope", "").split() if isinstance(decoded.get("scope"), str) else [],
            subject=subject,
            username=decoded.get("preferred_username", "unknown"),
        )

    def _decode_jwt(self, token: str) -> Optional[dict]:
        """Decode and verify JWT signature when a public key is configured.

        Args:
            token: Raw JWT string.

        Returns:
            Decoded claims dict, or None if decode fails.
        """
        try:
            if not self._jwt_public_key:
                return None

            decode_kwargs = {
                "algorithms": [self._jwt_algorithm],
                "options": {"verify_signature": True, "verify_exp": True},
            }
            if self._jwt_issuer:
                decode_kwargs["issuer"] = self._jwt_issuer

            decoded = jwt.decode(token, self._jwt_public_key, **decode_kwargs)
            logger.debug("JWT decoded for user: %s", decoded.get("preferred_username"))
            return decoded
        except jwt.InvalidTokenError as e:
            logger.debug("JWT decode failed: %s", str(e))
            return None

    def _introspect_token(self, token: str) -> Optional[dict]:
        """Verify token via Keycloak introspection endpoint.

        Args:
            token: Raw JWT string.

        Returns:
            User info dict from Keycloak, or None if verification fails.
        """
        try:
            response = requests.post(
                self.verify_url,
                headers={"Authorization": f"Bearer {token}"},
                json={},
                verify=self._verify_ssl,
                timeout=10,
            )
            if response.status_code == 200:
                data = response.json()
                if not isinstance(data, dict):
                    logger.debug("Token introspection failed: non-dict response")
                    return None
                if data.get("active") is False:
                    logger.debug("Token introspection failed: inactive token")
                    return None
                exp = data.get("exp")
                if isinstance(exp, (int, float)) and exp <= time.time():
                    logger.debug("Token introspection failed: expired token")
                    return None
                if "sub" not in data:
                    logger.debug("Token introspection failed: missing sub")
                    return None
                logger.debug("Token introspection succeeded for: %s", data.get("preferred_username"))
                return data
            logger.debug("Token introspection failed: HTTP %d", response.status_code)
            return None
        except Exception as e:
            logger.warning("Token introspection error: %s", str(e))
            return None
