"""Input validation for BlackAnt MCP tools.

Provides validation functions for service names, source paths,
and GPU counts to ensure safe and correct tool inputs.
"""

import re
from pathlib import Path

from ...utils.logging import get_logger

logger = get_logger("mcp.security")

SERVICE_NAME_PATTERN = re.compile(r"^[a-z0-9][a-z0-9-]{0,62}$")


def validate_service_name(name: str) -> str:
    """Validate a service name against BlackAnt naming rules.

    Args:
        name: Service name to validate.

    Returns:
        The validated service name.

    Raises:
        ValueError: If the name does not match the required pattern.
    """
    if not SERVICE_NAME_PATTERN.match(name):
        raise ValueError(
            f"Invalid service name '{name}'. "
            f"Must be 1-63 lowercase alphanumeric characters or hyphens, "
            f"starting with a letter or digit."
        )
    return name


def validate_source_path(path: str) -> Path:
    """Validate and resolve a source directory path.

    Ensures the path exists, is a directory, and contains a Dockerfile.
    Logs a warning if the path is outside the user's home directory.

    Args:
        path: Path string to validate.

    Returns:
        Resolved absolute Path object.

    Raises:
        ValueError: If path is invalid, missing, or has no Dockerfile.
    """
    resolved = Path(path).expanduser().resolve()

    if not resolved.exists():
        raise ValueError(f"Source path does not exist: {resolved}")

    if not resolved.is_dir():
        raise ValueError(f"Source path is not a directory: {resolved}")

    dockerfile = resolved / "Dockerfile"
    if not dockerfile.exists():
        raise ValueError(f"No Dockerfile found in: {resolved}")

    home = Path.home()
    if not str(resolved).startswith(str(home)):
        logger.warning("Source path is outside home directory: %s", resolved)

    return resolved


def validate_gpu_count(count: int) -> int:
    """Validate GPU count is within allowed range.

    Args:
        count: Number of GPUs requested.

    Returns:
        The validated GPU count.

    Raises:
        ValueError: If count is not an integer or not in range 0-8.
    """
    if not isinstance(count, int) or count < 0 or count > 8:
        raise ValueError(f"GPU count must be an integer between 0 and 8, got: {count}")
    return count
