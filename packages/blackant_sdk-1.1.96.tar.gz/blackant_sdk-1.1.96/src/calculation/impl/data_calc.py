"""DataCollector + ObjectStorage CalculationBase implementation.

This calculation demonstrates the full BlackAnt data pipeline:
  set_up:    Authenticate with BlackAnt API
  run:       Query DataCollector via API, compute statistics, store result in ObjectStorage via API
  tear_down: Clean up temporary resources

cmdArgs expected:
  - database: str (MongoDB database name)
  - collection: str (MongoDB collection name)
  - query: dict (optional MongoDB query filter)
  - value_field: str (field to aggregate, default "value")

The container accesses all services through the external API (dev.blackant.app)
with Bearer token authentication. The auth token is provided by the scheduler
via the BLACKANT_AUTH_TOKEN environment variable.
"""

import json
import os
from datetime import datetime

import requests

from calculation.base import CalculationBase


# External API base URL - container goes through the public API, not internal Docker network
BLACKANT_BASE_URL = os.getenv("BLACKANT_BASE_URL", "https://dev.blackant.app")


class DataCalc(CalculationBase):
    """Calculation that reads from DataCollector and optionally writes to ObjectStorage via API."""

    def __init__(self, logger, **kwargs):
        super().__init__(logger)
        self._kwargs = kwargs
        self._result = None
        self._token = os.getenv("BLACKANT_AUTH_TOKEN", "")
        self._base_url = BLACKANT_BASE_URL
        self._verify_ssl = "dev.blackant.app" not in self._base_url

        self._database = kwargs.get("database", "")
        self._collection = kwargs.get("collection", "")
        self._query = kwargs.get("query", {})
        self._value_field = kwargs.get("value_field", "value")

        self._logger.info("DataCalc initialized (API mode)")
        self._logger.info("base_url=%s, database=%s, collection=%s",
                          self._base_url, self._database, self._collection)

    def _auth_headers(self):
        """Build authorization headers for API requests."""
        headers = {"Content-Type": "application/json"}
        if self._token:
            headers["Authorization"] = "Bearer %s" % self._token
        return headers

    def set_up(self):
        """Verify API connectivity and auth token."""
        self._logger.info("DataCalc set_up started")

        if not self._token:
            self._logger.warning("No BLACKANT_AUTH_TOKEN env var - API calls will fail")

        if not self._database or not self._collection:
            self._logger.warning("No database/collection specified in cmdArgs")

        self._logger.info("DataCalc set_up completed")

    def run(self):
        """Query DataCollector via API and compute statistics."""
        self._logger.info("DataCalc run started")

        documents = []

        if self._database and self._collection:
            documents = self._fetch_from_data_collector()

        if not documents:
            self._logger.warning("No documents fetched, returning empty result")
            self._result = {
                "status": "no_data",
                "database": self._database,
                "collection": self._collection,
                "timestamp": datetime.now().isoformat(),
            }
            return

        # Compute statistics on the value field
        stats = self._compute_statistics(documents)

        self._result = {
            "document_count": len(documents),
            "field": self._value_field,
            "statistics": stats,
            "database": self._database,
            "collection": self._collection,
            "timestamp": datetime.now().isoformat(),
            "service_name": os.getenv("CALCULATION_NAME", "data-calc"),
        }

        self._logger.info("Result: %s", self._result)

        # Store result in ObjectStorage via API
        self._store_result_in_object_storage()

    def tear_down(self):
        """Clean up resources."""
        self._logger.info("DataCalc tear_down")

    def stop(self):
        """Handle stop request."""
        self._logger.warning("DataCalc stop requested")
        if self._result is None:
            self._result = {"status": "stopped"}

    @property
    def result(self):
        return self._result

    def _fetch_from_data_collector(self):
        """Fetch documents from DataCollector via external API."""
        url = "%s/api/sdk_services/data" % self._base_url
        payload = {
            "database": self._database,
            "collection": self._collection,
        }
        if self._query:
            payload["query"] = self._query

        self._logger.info("GET %s (database=%s, collection=%s)",
                          url, self._database, self._collection)

        try:
            resp = requests.get(
                url, json=payload, headers=self._auth_headers(),
                timeout=30, verify=self._verify_ssl
            )
            self._logger.info("DataCollector response: %d", resp.status_code)

            if resp.status_code != 200:
                self._logger.error("DataCollector error: %s", resp.text[:500])
                return []

            data = resp.json()
            if isinstance(data, list):
                self._logger.info("Fetched %d documents", len(data))
                return data
            elif isinstance(data, dict) and "data" in data:
                docs = data["data"]
                self._logger.info("Fetched %d documents (from .data)", len(docs))
                return docs
            else:
                self._logger.warning("Unexpected response format: %s", type(data).__name__)
                return []

        except requests.ConnectionError as exc:
            self._logger.error("Cannot connect to DataCollector API at %s: %s", url, exc)
            return []
        except Exception as exc:
            self._logger.error("DataCollector fetch failed: %s", exc)
            return []

    def _store_result_in_object_storage(self):
        """Store computation result in ObjectStorage via external API."""
        if not self._result:
            return

        url = "%s/api/sdk_services/storage" % self._base_url
        filename = "result_%s.json" % datetime.now().strftime("%Y%m%d_%H%M%S")

        try:
            result_json = json.dumps(self._result, indent=2, default=str)

            # Upload as multipart form-data (file upload)
            files = {"file": (filename, result_json, "application/json")}
            headers = {}
            if self._token:
                headers["Authorization"] = "Bearer %s" % self._token

            resp = requests.post(
                url, files=files, headers=headers,
                timeout=10, verify=self._verify_ssl
            )

            if resp.status_code < 300:
                self._result["stored_file"] = filename
                self._logger.info("Result stored in ObjectStorage via API: %s", filename)
            else:
                self._logger.warning("ObjectStorage upload failed: %d %s",
                                     resp.status_code, resp.text[:200])

        except Exception as exc:
            self._logger.warning("Could not store result in ObjectStorage: %s", exc)

    def _compute_statistics(self, documents):
        """Compute basic statistics on the value field across documents."""
        values = []
        for doc in documents:
            val = doc.get(self._value_field)
            if val is not None:
                try:
                    values.append(float(val))
                except (ValueError, TypeError):
                    pass

        if not values:
            return {
                "count": len(documents),
                "numeric_values": 0,
                "note": "No numeric values found for field '%s'" % self._value_field,
            }

        return {
            "count": len(documents),
            "numeric_values": len(values),
            "sum": sum(values),
            "min": min(values),
            "max": max(values),
            "average": sum(values) / len(values),
        }
