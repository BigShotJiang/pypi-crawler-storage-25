"""Test calculation module for BlackAnt SDK live test."""

from calculation.base import BaseCalculation


class TestCalculation(BaseCalculation):
    """Simple test calculation for SDK verification."""

    def calculate(self, input_data: dict) -> dict:
        """
        Simple calculation that processes a list of numbers.

        Args:
            input_data: dict with 'numbers' key containing list of numbers

        Returns:
            dict with sum, average, min, max
        """
        numbers = input_data.get("numbers", [])

        if not numbers:
            return {"error": "No numbers provided", "status": "failed"}

        result = {
            "sum": sum(numbers),
            "average": sum(numbers) / len(numbers),
            "min": min(numbers),
            "max": max(numbers),
            "count": len(numbers),
            "status": "success",
        }

        return result
