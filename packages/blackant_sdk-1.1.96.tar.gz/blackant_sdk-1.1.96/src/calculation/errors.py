class CalculationError(Exception):
    pass
