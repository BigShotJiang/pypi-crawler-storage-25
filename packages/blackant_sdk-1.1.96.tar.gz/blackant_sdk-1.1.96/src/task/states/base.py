import abc


class TaskStateBase:
    def __init__(self, task):
        self._task = task

    @abc.abstractproperty
    def name(self):
        raise NotImplementedError

    @abc.abstractmethod
    def run(self):
        raise NotImplementedError
