import uuid

from task.errors import InvalidDAOUsageError, TaskDoesNotExistsError


class TaskDao:
    __instance = None

    def __init__(self):
        if self.__instance is not None:
            raise InvalidDAOUsageError("Singleton object was created multiple times")
        self.__data = {}

    @classmethod
    def get_instance(cls):
        if cls.__instance is None:
            cls.__instance = TaskDao()
        return cls.__instance

    def get_task_ids(self):
        return list(self.__data.keys())

    def get_task(self, task_id):
        if task_id not in self.__data.keys():
            raise TaskDoesNotExistsError
        return self.__data.get(task_id)

    def add_task(self, task):
        task_id = uuid.uuid4().hex
        task.task_id = task_id
        self.__data[task_id] = task
        return task_id

    def delete_task(self, task_id):
        if task_id not in self.__data.keys():
            raise TaskDoesNotExistsError
        self.__data.pop(task_id)
        return task_id
