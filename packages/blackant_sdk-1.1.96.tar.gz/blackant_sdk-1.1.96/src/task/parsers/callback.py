from dataclasses import dataclass

from task.parsers.base import RequestParserBase


@dataclass
class CallbackParameter:
    url: str
    method: str
    headers: dict
    request_body: dict


class CallbackParser(RequestParserBase):
    def __init__(self, loc):
        super().__init__()

        self.add_argument("url", type=str, location=loc)
        self.add_argument(
            "method",
            type=str,
            location=loc,
            default="GET",
            choices=("GET", "POST", "PUT", "DELETE"),
        )
        self.add_argument("headers", type=dict, location=loc, default={})
        self.add_argument("request_body", type=dict, location=loc, default={})

    def validate(self, request):
        self.parse_args(req=request)

    def parse(self, request):
        result = self.parse_args(req=request)

        return CallbackParameter(
            url=result["url"],
            method=result["method"],
            headers=result["headers"],
            request_body=result["request_body"],
        )
