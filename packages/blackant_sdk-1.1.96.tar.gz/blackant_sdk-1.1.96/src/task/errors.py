class InvalidDAOUsageError(Exception):
    pass


class TaskDoesNotExistsError(Exception):
    pass


class TaskCallbackFailedError(Exception):
    pass
