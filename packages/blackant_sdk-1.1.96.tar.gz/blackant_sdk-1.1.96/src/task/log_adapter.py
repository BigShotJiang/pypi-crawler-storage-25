import logging


class TaskIdAdapter(logging.LoggerAdapter):
    def set_task_id(self, task_id):
        self.extra["task_id"] = task_id

    def process(self, msg, kwargs):
        if "task_id" in self.extra:
            return "[%s] %s" % (self.extra["task_id"], msg), kwargs
        return "%s" % msg, kwargs
