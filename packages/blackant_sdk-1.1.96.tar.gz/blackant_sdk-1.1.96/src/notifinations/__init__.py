"""Notifications module for BlackAnt SDK.

This module provides email sending functionality.
"""

from notifinations.mail_sender import EmailSender

__all__ = ["EmailSender"]
