#!/usr/bin/env python3
"""Debug script: Object Storage / MinIO via sdk-services proxy

Tests all storage endpoints and shows the exact error.
Run: python test/e2e/debug_object_storage.py
"""

import json
import os
import tempfile
import time
import requests
import urllib3

urllib3.disable_warnings()

# ── Config ──────────────────────────────────────────────────────────
BASE_URL = "https://dev.blackant.app"
USERNAME = "admin"
PASSWORD = "3c6DkEy4Hzbdehvd"

# ── Auth ────────────────────────────────────────────────────────────
print("=" * 70)
print("  DEBUG: Object Storage (MinIO) via sdk-services proxy")
print("  Server: %s" % BASE_URL)
print("=" * 70)

r = requests.post(
    "%s/api/auth/login" % BASE_URL,
    data={"username": USERNAME, "password": PASSWORD},
    verify=False,
)
if r.status_code != 200:
    print("\n[FAIL] Auth failed: %d %s" % (r.status_code, r.text[:200]))
    exit(1)

token = r.json().get("access_token")
print("\n[OK] Authenticated (token: %s...)" % token[:20])

headers = {
    "Authorization": "Bearer %s" % token,
    "Content-Type": "application/json",
}

# ── Step 1: Test all possible storage endpoints ─────────────────────
print("\n" + "-" * 70)
print("  Step 1: Test all storage endpoint variations")
print("-" * 70)

endpoints = [
    ("GET", "/api/sdk_services/storage/list", "List buckets (sdk-services proxy)"),
    ("GET", "/api/sdk_services/storage", "Download file (sdk-services proxy)"),
    ("GET", "/api/sdk_services/storage/list?bucket_id=test", "List with bucket param"),
]

for method, endpoint, desc in endpoints:
    url = "%s%s" % (BASE_URL, endpoint)
    print("\n  --- %s %s ---" % (method, endpoint))
    print("  (%s)" % desc)

    try:
        if method == "GET":
            r = requests.get(url, headers=headers, verify=False, timeout=10)
        print("  Status: %d" % r.status_code)
        print("  Headers: content-type=%s" % r.headers.get("content-type", "?"))
        print("  Body: %s" % r.text[:300])

        if "path in endpoint" in r.text:
            print("  >>> ERROR from MinIO Python library (minio/helpers.py:514)")
            print("  >>> The OBJECT_STORAGE_CONNECT_URL env var contains a path")
            print("  >>> MinIO client only accepts host:port (e.g. 'minio:9000')")
    except requests.exceptions.Timeout:
        print("  [TIMEOUT] Request timed out after 10s")
    except requests.exceptions.ConnectionError as e:
        print("  [CONNECTION ERROR] %s" % e)

# ── Step 2: Test upload ─────────────────────────────────────────────
print("\n" + "-" * 70)
print("  Step 2: Test file UPLOAD")
print("-" * 70)

# Create a small test file
test_file = os.path.join(tempfile.gettempdir(), "debug_storage_test.txt")
with open(test_file, "w") as f:
    f.write("Debug storage test file - %s\n" % time.time())

print("  Uploading: %s" % test_file)
print("  POST /api/sdk_services/storage (multipart form-data)")

upload_headers = {"Authorization": "Bearer %s" % token}
try:
    with open(test_file, "rb") as f:
        r = requests.post(
            "%s/api/sdk_services/storage" % BASE_URL,
            headers=upload_headers,
            files={"file": ("debug_test.txt", f, "text/plain")},
            verify=False,
            timeout=15,
        )
    print("  Status: %d" % r.status_code)
    print("  Headers: content-type=%s" % r.headers.get("content-type", "?"))
    print("  Body: %s" % r.text[:300])
except requests.exceptions.Timeout:
    print("  [TIMEOUT] Upload timed out after 15s")
    print("  >>> This means sdk-services reached object-storage-manager")
    print("  >>> but object-storage-manager couldn't connect to MinIO")
except requests.exceptions.ConnectionError as e:
    print("  [CONNECTION ERROR] %s" % e)

os.remove(test_file)

# ── Step 3: Direct ping to check if sdk-services is healthy ─────────
print("\n" + "-" * 70)
print("  Step 3: sdk-services health check")
print("-" * 70)

r = requests.get(
    "%s/api/sdk_services/ping" % BASE_URL,
    headers=headers,
    verify=False,
    timeout=5,
)
print("  GET /api/sdk_services/ping")
print("  Status: %d" % r.status_code)
print("  Body: %s" % r.text[:200])

# ── Summary ─────────────────────────────────────────────────────────
print("\n" + "=" * 70)
print("  ANALYSIS")
print("=" * 70)
print("""
  The sdk-services Flask app has the routes correctly configured:
    /sdk_services/storage      -> proxy to object-storage-manager:6000/object_storage
    /sdk_services/storage/list -> proxy to object-storage-manager:6000/object_storage/list

  The "path in endpoint is not allowed" error comes from:
    minio/helpers.py:514 - MinIO Python client rejects URLs with paths

  This means object-storage-manager's OBJECT_STORAGE_CONNECT_URL env var
  probably contains a path (e.g. "http://minio:9000/something").
  It should be just "object-storage-1:9000" (no path, no scheme).

  Check in swarm:
    docker service inspect object-storage-manager \\
      --format '{{json .Spec.TaskTemplate.ContainerSpec.Env}}'

  Also check if the MinIO/object-storage-1 service is running:
    docker service ls | grep -i "object\|minio\|storage"
""")
