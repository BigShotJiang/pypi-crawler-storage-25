#!/usr/bin/env python3
"""Full End-to-End Test: Complete Researcher Workflow with BlackAnt SDK.

This test validates the COMPLETE researcher workflow on a REAL dev environment:

  1. Authentication (Keycloak login via SDK)
  2. test_connection() - verify Docker + ServiceRegistry reachable
  3. Data Collector: insert diabetes patient data
  4. Data Collector: query, list, metadata verification
  5. Statistical calculation on queried data (BMI vs blood glucose correlation,
     linear regression, descriptive statistics)
  6. Write calculation results back to Data Collector
  7. Data Collector: update and delete operations
  8. Object Storage: upload, download, list, delete (skipped until MinIO fix)
  9. Docker build on remote daemon
  10. Push image to registry via SDK Services
  11. Service registration and listing (verify service appears)
  12. Cleanup

Infrastructure endpoint tests (SDK Services raw HTTP, DockerRegistryClient,
ServiceRegistry CRUD) are in test_infrastructure_endpoints.py.

Run:
    pytest test/e2e/test_full_researcher_workflow.py -v

All parameters are configured for dev.blackant.app by default.
Change the CONFIG section below for a different environment.
"""

import sys
import os
import time
import math
import tempfile
import shutil
import unittest
import warnings
from pathlib import Path

# Suppress SSL warnings for self-signed dev cert
warnings.filterwarnings("ignore", message="Unverified HTTPS request")

# Add src to path for local imports
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "..", "src"))

# ============================================================
# E2E Test Configuration - Change these for different environments
# ============================================================
BASE_URL = "https://dev.blackant.app"
LOGIN_URL = "https://dev.blackant.app/api/auth/login"
TEST_USER = "admin"
TEST_PASSWORD = "3c6DkEy4Hzbdehvd"

# Docker / Registry
DOCKER_DAEMON_URL = "https://dev.blackant.app:443/api/docker"
REGISTRY_URL = "env.blackant.app:5000"
REGISTRY_NAMESPACE = "science_module"
REGISTRY_USER = "ci_runner"
REGISTRY_PASSWORD = "3nDhK0ODL11xImydK0DY"

# Feature flags
ENABLE_OBJECT_STORAGE = False  # MinIO config bug - set True when fixed
ENABLE_DOCKER_BUILD = True  # Docker build + push + register
ENABLE_CLEANUP = False  # Set False to keep test data for frontend inspection
# Test database (will be created/used/cleaned)
TEST_DATABASE = "e2e_test_diabetes"
TEST_COLLECTION_RAW = "patient_raw_data"
TEST_COLLECTION_RESULTS = "calculation_results"
# ============================================================


def _set_env():
    """Set environment variables before SDK imports."""
    os.environ["DOCKER_NGINX_PROXY_URL"] = DOCKER_DAEMON_URL
    os.environ["DOCKER_REGISTRY_URL"] = REGISTRY_URL
    os.environ["DOCKER_REGISTRY_NAMESPACE"] = REGISTRY_NAMESPACE
    os.environ["DOCKER_REGISTRY_USER"] = REGISTRY_USER
    os.environ["DOCKER_REGISTRY_PASS"] = REGISTRY_PASSWORD
    os.environ["SDK_SERVICES_URL"] = BASE_URL
    os.environ["SDK_SERVICES_REGISTRY"] = "true"
    os.environ["SDK_SERVICES_ROLES"] = "true"
    os.environ["BLACKANT_BASE_URL"] = BASE_URL


_set_env()

# SDK imports (after env setup)
from blackant import BlackAntClient, BlackAntAuth
from blackant.services import DataCollectorClient, ObjectStorageClient


# ============================================================
# Sample diabetes patient dataset
# ============================================================
DIABETES_PATIENTS = [
    {
        "patient_id": "P001",
        "age": 45,
        "gender": "M",
        "bmi": 32.1,
        "blood_glucose_fasting": 142,
        "hba1c": 7.2,
        "systolic_bp": 138,
        "cholesterol_total": 220,
        "medication": "metformin",
    },
    {
        "patient_id": "P002",
        "age": 62,
        "gender": "F",
        "bmi": 28.5,
        "blood_glucose_fasting": 168,
        "hba1c": 8.1,
        "systolic_bp": 152,
        "cholesterol_total": 245,
        "medication": "insulin",
    },
    {
        "patient_id": "P003",
        "age": 38,
        "gender": "M",
        "bmi": 35.7,
        "blood_glucose_fasting": 155,
        "hba1c": 7.8,
        "systolic_bp": 130,
        "cholesterol_total": 198,
        "medication": "metformin",
    },
    {
        "patient_id": "P004",
        "age": 55,
        "gender": "F",
        "bmi": 26.3,
        "blood_glucose_fasting": 118,
        "hba1c": 6.4,
        "systolic_bp": 125,
        "cholesterol_total": 210,
        "medication": "diet_only",
    },
    {
        "patient_id": "P005",
        "age": 71,
        "gender": "M",
        "bmi": 30.8,
        "blood_glucose_fasting": 185,
        "hba1c": 8.9,
        "systolic_bp": 160,
        "cholesterol_total": 268,
        "medication": "insulin",
    },
    {
        "patient_id": "P006",
        "age": 48,
        "gender": "F",
        "bmi": 33.4,
        "blood_glucose_fasting": 149,
        "hba1c": 7.5,
        "systolic_bp": 142,
        "cholesterol_total": 232,
        "medication": "metformin",
    },
    {
        "patient_id": "P007",
        "age": 29,
        "gender": "M",
        "bmi": 24.1,
        "blood_glucose_fasting": 105,
        "hba1c": 5.8,
        "systolic_bp": 118,
        "cholesterol_total": 185,
        "medication": "diet_only",
    },
    {
        "patient_id": "P008",
        "age": 66,
        "gender": "F",
        "bmi": 29.9,
        "blood_glucose_fasting": 172,
        "hba1c": 8.3,
        "systolic_bp": 148,
        "cholesterol_total": 255,
        "medication": "insulin",
    },
    {
        "patient_id": "P009",
        "age": 42,
        "gender": "M",
        "bmi": 37.2,
        "blood_glucose_fasting": 161,
        "hba1c": 7.9,
        "systolic_bp": 135,
        "cholesterol_total": 215,
        "medication": "metformin",
    },
    {
        "patient_id": "P010",
        "age": 58,
        "gender": "F",
        "bmi": 31.6,
        "blood_glucose_fasting": 138,
        "hba1c": 7.0,
        "systolic_bp": 140,
        "cholesterol_total": 228,
        "medication": "metformin",
    },
    {
        "patient_id": "P011",
        "age": 35,
        "gender": "M",
        "bmi": 22.8,
        "blood_glucose_fasting": 98,
        "hba1c": 5.5,
        "systolic_bp": 115,
        "cholesterol_total": 178,
        "medication": "none",
    },
    {
        "patient_id": "P012",
        "age": 73,
        "gender": "F",
        "bmi": 34.0,
        "blood_glucose_fasting": 192,
        "hba1c": 9.2,
        "systolic_bp": 165,
        "cholesterol_total": 275,
        "medication": "insulin",
    },
]


# ============================================================
# Statistical helper functions (no numpy/scipy dependency)
# ============================================================


def mean(values):
    return sum(values) / len(values)


def std_dev(values):
    avg = mean(values)
    variance = sum((x - avg) ** 2 for x in values) / (len(values) - 1)
    return math.sqrt(variance)


def pearson_correlation(x_vals, y_vals):
    """Pearson correlation coefficient between two lists."""
    n = len(x_vals)
    mean_x, mean_y = mean(x_vals), mean(y_vals)
    numerator = sum((x - mean_x) * (y - mean_y) for x, y in zip(x_vals, y_vals))
    denom_x = math.sqrt(sum((x - mean_x) ** 2 for x in x_vals))
    denom_y = math.sqrt(sum((y - mean_y) ** 2 for y in y_vals))
    if denom_x == 0 or denom_y == 0:
        return 0.0
    return numerator / (denom_x * denom_y)


def linear_regression(x_vals, y_vals):
    """Simple linear regression: y = slope * x + intercept."""
    n = len(x_vals)
    mean_x, mean_y = mean(x_vals), mean(y_vals)
    ss_xy = sum((x - mean_x) * (y - mean_y) for x, y in zip(x_vals, y_vals))
    ss_xx = sum((x - mean_x) ** 2 for x in x_vals)
    if ss_xx == 0:
        return 0.0, mean_y, 0.0
    slope = ss_xy / ss_xx
    intercept = mean_y - slope * mean_x
    # R-squared
    ss_res = sum((y - (slope * x + intercept)) ** 2 for x, y in zip(x_vals, y_vals))
    ss_tot = sum((y - mean_y) ** 2 for y in y_vals)
    r_squared = 1 - (ss_res / ss_tot) if ss_tot != 0 else 0.0
    return slope, intercept, r_squared


# ============================================================
# Test class
# ============================================================


class TestFullResearcherWorkflow(unittest.TestCase):
    """End-to-end test: full researcher workflow on dev.blackant.app."""

    # Shared state across ordered test methods
    client = None
    auth = None
    data_client = None
    storage_client = None
    inserted_ids = []
    queried_data = []
    calc_results = {}
    service_name = None
    build_result = None

    @classmethod
    def setUpClass(cls):
        print("\n" + "=" * 80)
        print("  BLACKANT SDK - FULL E2E RESEARCHER WORKFLOW TEST")
        print("  Environment: %s" % BASE_URL)
        print("  User: %s" % TEST_USER)
        print("=" * 80)

        cls.service_name = "e2e-diabetes-calc-%d" % int(time.time())

    # ----------------------------------------------------------
    # PHASE 1: Authentication
    # ----------------------------------------------------------

    def test_01_authenticate(self):
        """Phase 1: Authenticate with BlackAnt via Keycloak."""
        print("\n--- STEP 01: Authenticate ---")

        self.__class__.client = BlackAntClient(
            user=TEST_USER,
            password=TEST_PASSWORD,
            base_url=BASE_URL,
            login_url=LOGIN_URL,
        )

        result = self.client.authenticate()
        self.assertTrue(result, "Authentication failed")
        self.assertTrue(self.client.is_authenticated())

        # Also keep auth reference for service clients
        self.__class__.auth = self.client.auth

        token = self.auth.get_token()
        self.assertIsNotNone(token)
        self.assertTrue(len(token) > 100, "Token too short")

        print("  Authenticated as: %s" % TEST_USER)
        print("  Token length: %d chars" % len(token))

    def test_01b_test_connection(self):
        """Phase 1b: Verify Docker + ServiceRegistry reachable via test_connection()."""
        print("\n--- STEP 01b: test_connection() ---")
        self.assertIsNotNone(self.client, "Not authenticated")

        result = self.client.test_connection()
        self.assertIsInstance(result, bool)
        self.assertTrue(
            result, "test_connection() returned False - Docker API or ServiceRegistry unreachable"
        )
        print("  test_connection(): OK")
        print("  Docker API version + ServiceRegistry list both reachable")

    # ----------------------------------------------------------
    # PHASE 2: Data Collector - Insert patient data
    # ----------------------------------------------------------

    def test_02_init_data_collector(self):
        """Phase 2a: Initialize DataCollectorClient."""
        print("\n--- STEP 02: Initialize Data Collector ---")
        self.assertIsNotNone(self.auth, "Not authenticated")

        self.__class__.data_client = DataCollectorClient(
            auth=self.auth,
            base_url=BASE_URL,
        )
        self.assertIsNotNone(self.data_client)
        print("  DataCollectorClient initialized")

    def test_03_insert_patient_data(self):
        """Phase 2b: Insert 12 diabetes patient records."""
        print("\n--- STEP 03: Insert patient data ---")
        self.assertIsNotNone(self.data_client, "DataCollectorClient not initialized")

        result = self.data_client.insert(
            database=TEST_DATABASE,
            collection=TEST_COLLECTION_RAW,
            data=DIABETES_PATIENTS,
        )
        self.assertIsNotNone(result)
        print(
            "  Inserted %d patient records into %s.%s"
            % (len(DIABETES_PATIENTS), TEST_DATABASE, TEST_COLLECTION_RAW)
        )

    def test_04_query_patient_data(self):
        """Phase 2c: Query all patient records back."""
        print("\n--- STEP 04: Query patient data ---")

        docs = self.data_client.query(
            database=TEST_DATABASE,
            collection=TEST_COLLECTION_RAW,
        )
        self.assertIsInstance(docs, list)
        self.assertGreaterEqual(len(docs), len(DIABETES_PATIENTS))

        self.__class__.queried_data = docs
        # Store document IDs for later update/delete
        self.__class__.inserted_ids = [
            d["_id"]["$oid"] if isinstance(d.get("_id"), dict) else str(d["_id"]) for d in docs
        ]

        print("  Queried %d documents" % len(docs))
        print(
            "  Sample: patient_id=%s, bmi=%.1f, glucose=%d"
            % (
                docs[0].get("patient_id", "?"),
                docs[0].get("bmi", 0),
                docs[0].get("blood_glucose_fasting", 0),
            )
        )

    def test_05_list_collections(self):
        """Phase 2d: List collections in test database."""
        print("\n--- STEP 05: List collections ---")

        result = self.data_client.list_collections(database=TEST_DATABASE)
        self.assertIsNotNone(result)

        # Result can be dict with "collections" key or a list
        if isinstance(result, dict):
            collections = result.get("collections", [])
        else:
            collections = result

        self.assertIn(TEST_COLLECTION_RAW, collections)
        print("  Collections in %s: %s" % (TEST_DATABASE, collections))

    def test_06_get_metadata(self):
        """Phase 2e: Get database metadata/statistics."""
        print("\n--- STEP 06: Get metadata ---")

        meta = self.data_client.get_metadata(database=TEST_DATABASE)
        self.assertIsNotNone(meta)

        if isinstance(meta, dict):
            print("  Database: %s" % meta.get("db_name", TEST_DATABASE))
            print("  Data size: %s" % meta.get("data_size", "?"))
            print("  Objects: %s" % meta.get("objects", "?"))
            print("  Collections: %s" % meta.get("collections", "?"))
        else:
            print("  Metadata: %s" % str(meta)[:200])

    # ----------------------------------------------------------
    # PHASE 3: Statistical calculation on diabetes data
    # ----------------------------------------------------------

    def test_07_calculate_descriptive_statistics(self):
        """Phase 3a: Descriptive statistics on patient data."""
        print("\n--- STEP 07: Descriptive statistics ---")
        self.assertTrue(len(self.queried_data) >= 10, "Not enough data")

        bmi_values = [d["bmi"] for d in self.queried_data if "bmi" in d]
        glucose_values = [
            d["blood_glucose_fasting"] for d in self.queried_data if "blood_glucose_fasting" in d
        ]
        hba1c_values = [d["hba1c"] for d in self.queried_data if "hba1c" in d]
        age_values = [d["age"] for d in self.queried_data if "age" in d]

        stats = {
            "n_patients": len(self.queried_data),
            "bmi_mean": round(mean(bmi_values), 2),
            "bmi_std": round(std_dev(bmi_values), 2),
            "bmi_min": min(bmi_values),
            "bmi_max": max(bmi_values),
            "glucose_mean": round(mean(glucose_values), 2),
            "glucose_std": round(std_dev(glucose_values), 2),
            "glucose_min": min(glucose_values),
            "glucose_max": max(glucose_values),
            "hba1c_mean": round(mean(hba1c_values), 2),
            "hba1c_std": round(std_dev(hba1c_values), 2),
            "age_mean": round(mean(age_values), 2),
            "age_std": round(std_dev(age_values), 2),
        }

        self.__class__.calc_results["descriptive"] = stats

        # Sanity checks on the statistics
        self.assertGreater(stats["bmi_mean"], 20)
        self.assertLess(stats["bmi_mean"], 40)
        self.assertGreater(stats["glucose_mean"], 90)
        self.assertLess(stats["glucose_mean"], 250)

        print("  N patients: %d" % stats["n_patients"])
        print(
            "  BMI:     mean=%.1f  std=%.1f  [%.1f - %.1f]"
            % (stats["bmi_mean"], stats["bmi_std"], stats["bmi_min"], stats["bmi_max"])
        )
        print(
            "  Glucose: mean=%.1f  std=%.1f  [%d - %d]"
            % (
                stats["glucose_mean"],
                stats["glucose_std"],
                stats["glucose_min"],
                stats["glucose_max"],
            )
        )
        print("  HbA1c:   mean=%.1f  std=%.1f" % (stats["hba1c_mean"], stats["hba1c_std"]))
        print("  Age:     mean=%.1f  std=%.1f" % (stats["age_mean"], stats["age_std"]))

    def test_08_calculate_correlations(self):
        """Phase 3b: Correlation analysis (BMI vs glucose, age vs HbA1c, etc.)."""
        print("\n--- STEP 08: Correlation analysis ---")

        bmi = [d["bmi"] for d in self.queried_data if "bmi" in d]
        glucose = [
            d["blood_glucose_fasting"] for d in self.queried_data if "blood_glucose_fasting" in d
        ]
        hba1c = [d["hba1c"] for d in self.queried_data if "hba1c" in d]
        age = [d["age"] for d in self.queried_data if "age" in d]
        bp = [d["systolic_bp"] for d in self.queried_data if "systolic_bp" in d]

        correlations = {
            "bmi_vs_glucose": round(pearson_correlation(bmi, glucose), 4),
            "bmi_vs_hba1c": round(pearson_correlation(bmi, hba1c), 4),
            "age_vs_glucose": round(pearson_correlation(age, glucose), 4),
            "age_vs_bp": round(pearson_correlation(age, bp), 4),
            "glucose_vs_hba1c": round(pearson_correlation(glucose, hba1c), 4),
        }

        self.__class__.calc_results["correlations"] = correlations

        # BMI and glucose should have positive correlation in diabetic data
        self.assertGreater(
            correlations["bmi_vs_glucose"], 0, "BMI-glucose correlation should be positive"
        )
        # Glucose and HbA1c must correlate strongly
        self.assertGreater(
            correlations["glucose_vs_hba1c"],
            0.8,
            "Glucose-HbA1c should correlate strongly (r > 0.8)",
        )

        print("  BMI vs Glucose:    r = %.4f" % correlations["bmi_vs_glucose"])
        print("  BMI vs HbA1c:      r = %.4f" % correlations["bmi_vs_hba1c"])
        print("  Age vs Glucose:    r = %.4f" % correlations["age_vs_glucose"])
        print("  Age vs BP:         r = %.4f" % correlations["age_vs_bp"])
        print("  Glucose vs HbA1c:  r = %.4f" % correlations["glucose_vs_hba1c"])

    def test_09_calculate_linear_regression(self):
        """Phase 3c: Linear regression - predict glucose from BMI."""
        print("\n--- STEP 09: Linear regression (BMI -> Glucose) ---")

        bmi = [d["bmi"] for d in self.queried_data if "bmi" in d]
        glucose = [
            d["blood_glucose_fasting"] for d in self.queried_data if "blood_glucose_fasting" in d
        ]

        slope, intercept, r_squared = linear_regression(bmi, glucose)

        regression = {
            "model": "glucose = %.2f * BMI + %.2f" % (slope, intercept),
            "slope": round(slope, 4),
            "intercept": round(intercept, 4),
            "r_squared": round(r_squared, 4),
            "interpretation": "Each unit increase in BMI associated with %.1f mg/dL glucose increase"
            % slope,
        }

        self.__class__.calc_results["regression_bmi_glucose"] = regression

        # Regression should have positive slope for diabetic data
        self.assertGreater(slope, 0, "Slope should be positive")
        self.assertGreater(r_squared, 0, "R-squared should be positive")

        # Predict glucose for a new patient with BMI 30
        predicted = slope * 30 + intercept
        regression["prediction_bmi_30"] = round(predicted, 1)

        print("  Model: %s" % regression["model"])
        print("  R-squared: %.4f" % r_squared)
        print("  %s" % regression["interpretation"])
        print("  Prediction (BMI=30): %.1f mg/dL" % predicted)

    def test_10_calculate_risk_stratification(self):
        """Phase 3d: Risk stratification based on HbA1c + BMI + age."""
        print("\n--- STEP 10: Risk stratification ---")

        risk_groups = {"low": [], "moderate": [], "high": [], "critical": []}

        for patient in self.queried_data:
            hba1c = patient.get("hba1c", 0)
            bmi = patient.get("bmi", 0)
            age = patient.get("age", 0)

            # Simple risk score: weighted combination
            risk_score = (hba1c * 10) + (bmi * 0.5) + (age * 0.2)

            if risk_score < 80:
                level = "low"
            elif risk_score < 95:
                level = "moderate"
            elif risk_score < 110:
                level = "high"
            else:
                level = "critical"

            risk_groups[level].append(patient.get("patient_id", "?"))

        stratification = {
            "low_risk_count": len(risk_groups["low"]),
            "moderate_risk_count": len(risk_groups["moderate"]),
            "high_risk_count": len(risk_groups["high"]),
            "critical_risk_count": len(risk_groups["critical"]),
            "low_risk_patients": risk_groups["low"],
            "moderate_risk_patients": risk_groups["moderate"],
            "high_risk_patients": risk_groups["high"],
            "critical_risk_patients": risk_groups["critical"],
        }

        self.__class__.calc_results["risk_stratification"] = stratification

        total = sum(len(v) for v in risk_groups.values())
        self.assertEqual(total, len(self.queried_data))

        for level, patients in risk_groups.items():
            print("  %-10s: %d patients %s" % (level.upper(), len(patients), patients))

    # ----------------------------------------------------------
    # PHASE 4: Write results back to Data Collector
    # ----------------------------------------------------------

    def test_11_write_results_to_data_collector(self):
        """Phase 4a: Store calculation results in Data Collector."""
        print("\n--- STEP 11: Write calculation results ---")

        results_doc = {
            "analysis_type": "diabetes_e2e_test",
            "timestamp": time.strftime("%Y-%m-%dT%H:%M:%S"),
            "source_database": TEST_DATABASE,
            "source_collection": TEST_COLLECTION_RAW,
            "patient_count": len(self.queried_data),
            "descriptive_statistics": self.calc_results.get("descriptive", {}),
            "correlations": self.calc_results.get("correlations", {}),
            "regression_bmi_glucose": self.calc_results.get("regression_bmi_glucose", {}),
            "risk_stratification": self.calc_results.get("risk_stratification", {}),
        }

        result = self.data_client.insert(
            database=TEST_DATABASE,
            collection=TEST_COLLECTION_RESULTS,
            data=results_doc,
        )
        self.assertIsNotNone(result)

        print("  Stored results in %s.%s" % (TEST_DATABASE, TEST_COLLECTION_RESULTS))
        print("  Keys: %s" % list(results_doc.keys()))

    def test_12_verify_results_stored(self):
        """Phase 4b: Query back and verify calculation results."""
        print("\n--- STEP 12: Verify stored results ---")

        docs = self.data_client.query(
            database=TEST_DATABASE,
            collection=TEST_COLLECTION_RESULTS,
            query={"analysis_type": "diabetes_e2e_test"},
        )
        self.assertIsInstance(docs, list)
        self.assertGreaterEqual(len(docs), 1)

        latest = docs[-1]
        self.assertIn("descriptive_statistics", latest)
        self.assertIn("correlations", latest)
        self.assertIn("regression_bmi_glucose", latest)
        self.assertIn("risk_stratification", latest)

        print("  Found %d result document(s)" % len(docs))
        print("  Correlations verified: %s" % list(latest["correlations"].keys()))
        print("  Regression model: %s" % latest["regression_bmi_glucose"].get("model", "?"))

    # ----------------------------------------------------------
    # PHASE 5: Data Collector - Update and Delete
    # ----------------------------------------------------------

    @unittest.expectedFailure  # Backend bug: pymongo update() returns dict, not UpdateResult
    def test_13_update_patient_record(self):
        """Phase 5a: Update a patient record.

        NOTE: Backend returns 400 with "'dict' object has no attribute 'matched_count'"
        because pymongo update_one() returns a dict in the backend's pymongo version,
        but the handler expects an UpdateResult object. SDK payload is correct.
        """
        print("\n--- STEP 13: Update patient record ---")
        self.assertTrue(len(self.inserted_ids) > 0, "No document IDs")

        doc_id = self.inserted_ids[0]
        result = self.data_client.update(
            database=TEST_DATABASE,
            collection=TEST_COLLECTION_RAW,
            doc_id=doc_id,
            data={"notes": "Updated by E2E test", "reviewed": True},
        )
        self.assertIsNotNone(result)

        # Verify the update
        docs = self.data_client.query(
            database=TEST_DATABASE,
            collection=TEST_COLLECTION_RAW,
            query={"reviewed": True},
        )
        self.assertGreaterEqual(len(docs), 1)
        print("  Updated document %s with notes + reviewed flag" % doc_id[:12])

    def test_14_delete_patient_record(self):
        """Phase 5b: Delete last patient record."""
        print("\n--- STEP 14: Delete patient record ---")
        self.assertTrue(len(self.inserted_ids) > 1, "Not enough document IDs")

        doc_id = self.inserted_ids[-1]
        result = self.data_client.delete(
            database=TEST_DATABASE,
            collection=TEST_COLLECTION_RAW,
            doc_id=doc_id,
        )
        self.assertIsNotNone(result)

        # Verify deletion - query remaining
        docs = self.data_client.query(
            database=TEST_DATABASE,
            collection=TEST_COLLECTION_RAW,
        )
        remaining_ids = [
            d["_id"]["$oid"] if isinstance(d.get("_id"), dict) else str(d["_id"]) for d in docs
        ]
        self.assertNotIn(doc_id, remaining_ids)
        print("  Deleted document %s, remaining: %d" % (doc_id[:12], len(docs)))

    # ----------------------------------------------------------
    # PHASE 6: Object Storage (skipped if ENABLE_OBJECT_STORAGE=False)
    # ----------------------------------------------------------

    @unittest.skipUnless(ENABLE_OBJECT_STORAGE, "Object Storage disabled (MinIO config pending)")
    def test_15_init_object_storage(self):
        """Phase 6a: Initialize ObjectStorageClient."""
        print("\n--- STEP 15: Initialize Object Storage ---")

        self.__class__.storage_client = ObjectStorageClient(
            auth=self.auth,
            base_url=BASE_URL,
        )
        self.assertIsNotNone(self.storage_client)
        print("  ObjectStorageClient initialized")

    @unittest.skipUnless(ENABLE_OBJECT_STORAGE, "Object Storage disabled (MinIO config pending)")
    def test_16_upload_file(self):
        """Phase 6b: Upload a CSV file to Object Storage."""
        print("\n--- STEP 16: Upload file ---")

        # Create a temp CSV with analysis results
        self._test_csv_path = os.path.join(tempfile.gettempdir(), "e2e_diabetes_results.csv")
        with open(self._test_csv_path, "w") as f:
            f.write("metric,value\n")
            stats = self.calc_results.get("descriptive", {})
            for key, val in stats.items():
                f.write("%s,%s\n" % (key, val))

        result = self.storage_client.upload(file_path=self._test_csv_path)
        self.assertIsNotNone(result)
        print("  Uploaded: %s" % self._test_csv_path)

    @unittest.skipUnless(ENABLE_OBJECT_STORAGE, "Object Storage disabled (MinIO config pending)")
    def test_17_list_storage(self):
        """Phase 6c: List buckets in Object Storage."""
        print("\n--- STEP 17: List storage ---")

        result = self.storage_client.list_buckets()
        self.assertIsNotNone(result)
        print("  Buckets: %s" % str(result)[:200])

    @unittest.skipUnless(ENABLE_OBJECT_STORAGE, "Object Storage disabled (MinIO config pending)")
    def test_18_download_file(self):
        """Phase 6d: Download the uploaded file."""
        print("\n--- STEP 18: Download file ---")

        download_path = os.path.join(tempfile.gettempdir(), "e2e_download_test.csv")
        result = self.storage_client.download(
            object_name="e2e_diabetes_results.csv",
            local_path=download_path,
        )
        self.assertTrue(os.path.exists(download_path))
        print("  Downloaded to: %s" % download_path)
        os.remove(download_path)

    @unittest.skipUnless(ENABLE_OBJECT_STORAGE, "Object Storage disabled (MinIO config pending)")
    def test_19_delete_file(self):
        """Phase 6e: Delete the uploaded file."""
        print("\n--- STEP 19: Delete file ---")

        result = self.storage_client.delete(object_name="e2e_diabetes_results.csv")
        self.assertIsNotNone(result)
        print("  Deleted: e2e_diabetes_results.csv")

    # ----------------------------------------------------------
    # PHASE 7: Docker build + push + register
    # ----------------------------------------------------------

    @unittest.skipUnless(ENABLE_DOCKER_BUILD, "Docker build disabled")
    def test_20_docker_build_and_push(self):
        """Phase 7a: Build Docker image on remote daemon and push to registry."""
        print("\n--- STEP 20: Docker build + push ---")
        self.assertIsNotNone(self.client, "Not authenticated")

        # Use existing project Dockerfile and calculation impl
        project_root = Path(__file__).parent.parent.parent
        impl_path = project_root / "src" / "calculation" / "impl"
        dockerfile_path = project_root / "Dockerfile"

        if not impl_path.exists() or not dockerfile_path.exists():
            self.skipTest("Project Dockerfile or impl not found at %s" % project_root)

        print("  Service: %s" % self.service_name)
        print("  Impl: %s" % impl_path)
        print("  Dockerfile: %s" % dockerfile_path)
        print("  Building on remote daemon (this may take 30-90 seconds)...")

        result = self.client.build_service(
            service_name=self.service_name,
            impl_path=str(impl_path),
            dockerfile_path=str(dockerfile_path),
            tag="e2e-test",
            push=True,
            register_service=True,
        )

        self.assertIsNotNone(result)
        self.assertTrue(result.get("build_success"), "Build failed: %s" % result)
        self.assertTrue(result.get("pushed"), "Push failed: %s" % result)

        self.__class__.build_result = result

        print("  Build: OK")
        print("  Image: %s" % result.get("full_image", "?"))
        print("  Size: %.2f MB" % (result.get("size", 0) / 1024 / 1024))
        print("  Pushed: %s" % ("OK" if result.get("pushed") else "FAILED"))
        print(
            "  Service registered: %s"
            % (
                "OK (id=%s)" % result.get("service_id")
                if result.get("service_registered")
                else "FAILED (ServiceManager rejected)"
            )
        )
        print("  Role assigned: %s" % result.get("role_assigned", False))

    @unittest.skipUnless(ENABLE_DOCKER_BUILD, "Docker build disabled")
    def test_21_list_services_and_verify(self):
        """Phase 7b: List services and verify the built service appears."""
        print("\n--- STEP 21: List services + verify ---")

        # Re-authenticate for fresh token (60s TTL)
        self.client.authenticate()

        services = self.client.list_services()
        self.assertIsNotNone(services)
        self.assertIsInstance(services, list, "list_services() should return a list")

        print("  Services found: %d" % len(services))

        # Check if our built service appears in the list
        service_names = []
        for svc in services:
            name = svc.get("name", svc.get("service_name", "?"))
            service_names.append(name)

        for svc in services[:10]:
            name = svc.get("name", svc.get("service_name", "?"))
            marker = " <-- OUR SERVICE" if self.service_name and name == self.service_name else ""
            print("    - %s%s" % (name, marker))

        # If build_result says service_registered, verify it's in the list
        if self.build_result and self.build_result.get("service_registered"):
            self.assertGreater(
                len(services), 0, "Service list is empty but service was registered"
            )
            self.assertIn(
                self.service_name,
                service_names,
                "Built service '%s' not found in service list" % self.service_name,
            )
            print("  VERIFIED: '%s' found in service list" % self.service_name)
        else:
            # Service registration failed (e.g. backend parent issue) - list may be empty
            print(
                "  NOTE: Service registration failed earlier (backend 'parent' issue),"
                " so '%s' may not appear" % self.service_name
            )
            if len(services) == 0:
                print("  Service list is empty (no services registered on this environment)")
            print("  list_services() API call itself succeeded - OK")

    # ----------------------------------------------------------
    # PHASE 8: Cleanup
    # ----------------------------------------------------------

    @unittest.skipUnless(ENABLE_CLEANUP, "Cleanup disabled - test data kept for frontend inspection")
    def test_99_cleanup(self):
        """Phase 8: Clean up test data from Data Collector."""
        print("\n--- STEP 99: Cleanup ---")

        if self.data_client:
            # Delete all documents in test collections
            try:
                # Query remaining raw data docs and delete them
                docs = self.data_client.query(
                    database=TEST_DATABASE,
                    collection=TEST_COLLECTION_RAW,
                )
                for doc in docs:
                    doc_id = (
                        doc["_id"]["$oid"] if isinstance(doc.get("_id"), dict) else str(doc["_id"])
                    )
                    try:
                        self.data_client.delete(TEST_DATABASE, TEST_COLLECTION_RAW, doc_id)
                    except Exception:
                        pass
                print("  Cleaned %s.%s (%d docs)" % (TEST_DATABASE, TEST_COLLECTION_RAW, len(docs)))
            except Exception as e:
                print("  Warning: raw data cleanup: %s" % e)

            try:
                # Delete results docs
                docs = self.data_client.query(
                    database=TEST_DATABASE,
                    collection=TEST_COLLECTION_RESULTS,
                )
                for doc in docs:
                    doc_id = (
                        doc["_id"]["$oid"] if isinstance(doc.get("_id"), dict) else str(doc["_id"])
                    )
                    try:
                        self.data_client.delete(TEST_DATABASE, TEST_COLLECTION_RESULTS, doc_id)
                    except Exception:
                        pass
                print(
                    "  Cleaned %s.%s (%d docs)"
                    % (TEST_DATABASE, TEST_COLLECTION_RESULTS, len(docs))
                )
            except Exception as e:
                print("  Warning: results cleanup: %s" % e)

        print("  Cleanup complete")

    # ----------------------------------------------------------
    # Summary
    # ----------------------------------------------------------

    @classmethod
    def tearDownClass(cls):
        print("\n" + "=" * 80)
        print("  E2E TEST SUMMARY")
        print("=" * 80)
        print("  Environment: %s" % BASE_URL)
        print("  User: %s" % TEST_USER)
        if cls.calc_results.get("descriptive"):
            print("  Patients analyzed: %d" % cls.calc_results["descriptive"].get("n_patients", 0))
        if cls.calc_results.get("correlations"):
            print(
                "  BMI-Glucose correlation: r=%.4f"
                % cls.calc_results["correlations"].get("bmi_vs_glucose", 0)
            )
        if cls.calc_results.get("regression_bmi_glucose"):
            print("  Regression: %s" % cls.calc_results["regression_bmi_glucose"].get("model", "?"))
        if cls.build_result:
            print("  Docker image: %s" % cls.build_result.get("full_image", "?"))
        print("  --- Feature flags ---")
        print(
            "  Object Storage:  %s"
            % ("ENABLED" if ENABLE_OBJECT_STORAGE else "DISABLED (MinIO bug)")
        )
        print("  Docker Build:    %s" % ("ENABLED" if ENABLE_DOCKER_BUILD else "DISABLED"))
        print("=" * 80)
        print("  NOTE: Infrastructure endpoint tests in test_infrastructure_endpoints.py")


if __name__ == "__main__":
    unittest.main(verbosity=2)
