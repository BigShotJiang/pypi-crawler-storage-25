#!/usr/bin/env python3
"""End-to-End Test: Complete Scheduler Workflow.

This test validates the COMPLETE BlackAnt workflow including the Scheduler,
which was previously missing from E2E tests. This is the core user flow:

  1. Auth (Keycloak login)
  2. Build Docker image on remote daemon
  3. Push image to registry
  4. Register service with ServiceManager
  5. Create Schedule (POST /api/scheduler/schedule)
  6. Poll until schedule reaches "done" state
  7. Verify task result (GET /api/scheduler/schedule/related_tasks/{uuid})
  8. Cleanup (delete schedule)

The current CalculationBase implementation (MyCalculation) accepts
cmdArgs with a "numbers" list and returns sum/count/average.

Run:
    pytest test/e2e/test_scheduler_workflow.py -v

All parameters are configured for dev.blackant.app by default.
"""

import sys
import os
import time
import json
import unittest
import warnings
from pathlib import Path

import requests as http_requests

# Suppress SSL warnings for self-signed dev cert
warnings.filterwarnings("ignore", message="Unverified HTTPS request")

# Add src to path for local imports
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "..", "src"))

# ============================================================
# E2E Test Configuration
# ============================================================
BASE_URL = "https://dev.blackant.app"
LOGIN_URL = "https://dev.blackant.app/api/auth/login"
TEST_USER = "admin"
TEST_PASSWORD = "3c6DkEy4Hzbdehvd"

# Docker / Registry
DOCKER_DAEMON_URL = "https://dev.blackant.app:443/api/docker"
REGISTRY_URL = "env.blackant.app:5000"
REGISTRY_NAMESPACE = "science_module"
REGISTRY_USER = "ci_runner"
REGISTRY_PASSWORD = "3nDhK0ODL11xImydK0DY"

# Scheduler
SCHEDULER_URL = "%s/api/scheduler/schedule" % BASE_URL
SCHEDULER_POLL_INTERVAL = 5  # seconds between polls
SCHEDULER_POLL_TIMEOUT = 180  # max seconds to wait for schedule to finish

# Test calculation input - MyCalculation sums these numbers
TEST_NUMBERS = [1, 2, 3, 4, 5, 10, 15, 20]
EXPECTED_SUM = 60
EXPECTED_COUNT = 8
EXPECTED_AVERAGE = 7.5

# Feature flags
ENABLE_DOCKER_BUILD = True  # Build + push + register
# ============================================================


def _set_env():
    """Set environment variables before SDK imports."""
    os.environ["DOCKER_NGINX_PROXY_URL"] = DOCKER_DAEMON_URL
    os.environ["DOCKER_REGISTRY_URL"] = REGISTRY_URL
    os.environ["DOCKER_REGISTRY_NAMESPACE"] = REGISTRY_NAMESPACE
    os.environ["DOCKER_REGISTRY_USER"] = REGISTRY_USER
    os.environ["DOCKER_REGISTRY_PASS"] = REGISTRY_PASSWORD
    os.environ["SDK_SERVICES_URL"] = BASE_URL
    os.environ["SDK_SERVICES_REGISTRY"] = "true"
    os.environ["SDK_SERVICES_ROLES"] = "true"
    os.environ["BLACKANT_BASE_URL"] = BASE_URL


_set_env()

# SDK imports (after env setup)
from blackant import BlackAntClient


# ============================================================
# Test class
# ============================================================


class TestSchedulerWorkflow(unittest.TestCase):
    """End-to-end test: complete scheduler workflow on dev.blackant.app."""

    # Shared state across ordered test methods
    client = None
    auth = None
    token = None
    refresh_token = None
    service_name = None
    build_result = None
    schedule_uuid = None
    task_result = None
    webhook_token = None  # webhook.site token UUID for callback testing
    webhook_url = None  # webhook.site URL to use as callback

    @classmethod
    def setUpClass(cls):
        print("\n" + "=" * 80)
        print("  BLACKANT SDK - SCHEDULER WORKFLOW E2E TEST")
        print("  Environment: %s" % BASE_URL)
        print("  User: %s" % TEST_USER)
        print("=" * 80)

        cls.service_name = "e2e-sched-calc-%d" % int(time.time())

        # Setup webhook.site for callback testing
        try:
            resp = http_requests.post(
                "https://webhook.site/token",
                timeout=10,
            )
            if resp.status_code == 201:
                data = resp.json()
                cls.webhook_token = data["uuid"]
                cls.webhook_url = "https://webhook.site/%s" % cls.webhook_token
                print("  Webhook URL: %s" % cls.webhook_url)
            else:
                print("  Webhook.site unavailable (status %d), callback test skipped" % resp.status_code)
        except Exception as e:
            print("  Webhook.site unreachable (%s), callback test skipped" % e)

    def _get_fresh_token(self):
        """Get a fresh token, using refresh_token if available, otherwise re-login."""
        if self.refresh_token:
            try:
                resp = http_requests.post(
                    "%s/api/auth/refresh" % BASE_URL,
                    headers={
                        "Content-Type": "application/x-www-form-urlencoded",
                        "Authorization": "Bearer %s" % self.token,
                    },
                    data="refresh_token=%s" % self.refresh_token,
                    verify=False,
                    timeout=10,
                )
                if resp.status_code == 200:
                    data = resp.json()
                    self.__class__.token = data["access_token"]
                    self.__class__.refresh_token = data.get("refresh_token", self.refresh_token)
                    return self.token
            except Exception:
                pass

        # Fallback: re-authenticate
        self.client.authenticate()
        self.__class__.token = self.auth.get_token()
        return self.token

    def _auth_headers(self):
        """Get authorization headers with fresh token."""
        token = self._get_fresh_token()
        return {
            "Authorization": "Bearer %s" % token,
            "Content-Type": "application/json",
        }

    # ----------------------------------------------------------
    # STEP 1: Authentication
    # ----------------------------------------------------------

    def test_01_authenticate(self):
        """Step 1: Authenticate with BlackAnt via Keycloak."""
        print("\n--- STEP 01: Authenticate ---")

        self.__class__.client = BlackAntClient(
            user=TEST_USER,
            password=TEST_PASSWORD,
            base_url=BASE_URL,
            login_url=LOGIN_URL,
        )

        result = self.client.authenticate()
        self.assertTrue(result, "Authentication failed")
        self.assertTrue(self.client.is_authenticated())

        self.__class__.auth = self.client.auth
        self.__class__.token = self.auth.get_token()

        # Store refresh_token for later use during polling
        token_store = self.auth.token_store
        if hasattr(token_store, "refresh_token"):
            self.__class__.refresh_token = token_store.refresh_token

        print("  Authenticated as: %s" % TEST_USER)
        print("  Token length: %d chars" % len(self.token))
        print("  Refresh token: %s" % ("available" if self.refresh_token else "not available"))

    # ----------------------------------------------------------
    # STEP 2: Check accessible resources (pre-check)
    # ----------------------------------------------------------

    def test_02_check_accessible_resources(self):
        """Step 2: Check scheduler accessible resources for admin user.

        Note: The correct URL is /api/scheduler/accessible_resources
        (NOT /api/scheduler/schedule/accessible_resources).
        The scheduler registers this at /accessible_resources (server.py:53),
        and nginx proxies /api/scheduler/* to the scheduler.
        """
        print("\n--- STEP 02: Check accessible resources ---")

        resp = http_requests.get(
            "%s/api/scheduler/accessible_resources" % BASE_URL,
            headers=self._auth_headers(),
            json={},
            verify=False,
            timeout=15,
        )
        print("  Status: %d" % resp.status_code)

        self.assertEqual(
            resp.status_code, 200,
            "accessible_resources failed: %d %s" % (resp.status_code, resp.text[:300]),
        )

        resources = resp.json()
        self.assertIsInstance(resources, list, "Expected list of resources")
        print("  Accessible resources: %d" % len(resources))
        for r in resources[:10]:
            print("    - %s/%s (%s)" % (
                r.get("group", "?"),
                r.get("resource", "?"),
                r.get("role", "?"),
            ))

    # ----------------------------------------------------------
    # STEP 3: Build + Push + Register
    # ----------------------------------------------------------

    @unittest.skipUnless(ENABLE_DOCKER_BUILD, "Docker build disabled")
    def test_03_build_push_register(self):
        """Step 3: Build Docker image, push to registry, register with ServiceManager."""
        print("\n--- STEP 03: Build + Push + Register ---")
        self.assertIsNotNone(self.client, "Not authenticated")

        project_root = Path(__file__).parent.parent.parent
        impl_path = project_root / "src" / "calculation" / "impl"
        dockerfile_path = project_root / "Dockerfile"

        if not impl_path.exists() or not dockerfile_path.exists():
            self.skipTest("Project Dockerfile or impl not found at %s" % project_root)

        print("  Service: %s" % self.service_name)
        print("  Building on remote daemon (this may take 30-90 seconds)...")

        result = self.client.build_service(
            service_name=self.service_name,
            impl_path=str(impl_path),
            dockerfile_path=str(dockerfile_path),
            tag="e2e-test",
            push=True,
            register_service=False,
        )

        self.assertIsNotNone(result)
        self.assertTrue(result.get("build_success"), "Build failed: %s" % result)
        self.assertTrue(result.get("pushed"), "Push failed: %s" % result)

        self.__class__.build_result = result

        print("  Build: OK")
        print("  Image: %s" % result.get("full_image", "?"))
        print("  Pushed: OK")
        print("  register_service=False (Scheduler handles ServiceManager internally)")

    # Step 3b removed: With register_service=False, no ServiceManager entry is created,
    # so the Scheduler will create a fresh Swarm service with correct env vars.
    # The old workaround (delete ServiceManager entry after registration) is no longer needed.

    # ----------------------------------------------------------
    # STEP 4: List existing schedules (pre-check)
    # ----------------------------------------------------------

    def test_04_list_existing_schedules(self):
        """Step 4: List existing schedules to verify scheduler API is alive."""
        print("\n--- STEP 04: List existing schedules ---")

        resp = http_requests.get(
            SCHEDULER_URL,
            headers=self._auth_headers(),
            json={},
            verify=False,
            timeout=15,
        )
        self.assertIn(resp.status_code, [200, 401, 403])
        print("  Status: %d" % resp.status_code)

        if resp.status_code == 200:
            schedules = resp.json()
            if isinstance(schedules, list):
                print("  Existing schedules: %d" % len(schedules))
                for s in schedules[:5]:
                    print("    - %s: %s (state: %s)" % (
                        s.get("uuid", "?")[:12],
                        s.get("calculationName", "?"),
                        s.get("state", "?"),
                    ))
            else:
                print("  Response: %s" % str(schedules)[:300])

    # ----------------------------------------------------------
    # STEP 5: Create Schedule (THE CORE TEST)
    # ----------------------------------------------------------

    @unittest.skipUnless(ENABLE_DOCKER_BUILD, "Docker build disabled (no service to schedule)")
    def test_05_create_schedule(self):
        """Step 5: Create a schedule for the registered service.

        This is the key step - the Scheduler will:
        1. Verify the service exists in ServiceManager DB
        2. Create a Docker Swarm service (directly via Docker API)
        3. The container runs MyCalculation with the provided cmdArgs
        4. Container sends callback to scheduler when done
        """
        print("\n--- STEP 05: Create Schedule ---")
        self.assertIsNotNone(self.build_result, "No build result (step 3 skipped?)")

        task_config = {
            "cmdArgs": {"numbers": TEST_NUMBERS},
        }

        # Add callback config if webhook.site is available
        if self.webhook_url:
            task_config["callback"] = {
                "url": self.webhook_url,
                "method": "POST",
                "headers": {"X-Test": "e2e-scheduler"},
                "request_body": {"source": "blackant-e2e-test"},
            }

        payload = {
            "calculationName": self.service_name,
            "image_tag": "e2e-test",
            "taskConfig": task_config,
        }

        print("  calculationName: %s" % self.service_name)
        print("  image_tag: e2e-test")
        print("  cmdArgs: %s" % json.dumps(payload["taskConfig"]["cmdArgs"]))
        if self.webhook_url:
            print("  callback: %s" % self.webhook_url)
        print("  POST %s" % SCHEDULER_URL)

        resp = http_requests.post(
            SCHEDULER_URL,
            headers=self._auth_headers(),
            json=payload,
            verify=False,
            timeout=120,
        )

        print("  Status: %d" % resp.status_code)
        print("  Response: %s" % resp.text[:500])

        self.assertEqual(
            resp.status_code, 200,
            "Schedule creation failed: %d %s" % (resp.status_code, resp.text[:300]),
        )

        # Response should be a UUID string
        schedule_uuid = resp.text.strip().strip('"')
        self.assertTrue(len(schedule_uuid) > 10, "Invalid UUID: %s" % schedule_uuid)

        self.__class__.schedule_uuid = schedule_uuid
        print("  Schedule UUID: %s" % schedule_uuid)

    # ----------------------------------------------------------
    # STEP 6: Poll until schedule is done
    # ----------------------------------------------------------

    @unittest.skipUnless(ENABLE_DOCKER_BUILD, "Docker build disabled")
    def test_06_poll_schedule_until_done(self):
        """Step 6: Poll the schedule state until done or failure.

        Expected state transitions:
        WAITING_FOR_TRIGGER -> RUNNING -> done

        Uses refresh token to keep auth alive during polling.
        """
        print("\n--- STEP 06: Poll schedule until done ---")
        self.assertIsNotNone(self.schedule_uuid, "No schedule UUID (step 5 failed?)")

        start_time = time.time()
        last_state = None
        poll_count = 0

        print("  Polling every %d sec, timeout %d sec..." % (
            SCHEDULER_POLL_INTERVAL, SCHEDULER_POLL_TIMEOUT,
        ))

        while True:
            elapsed = time.time() - start_time
            if elapsed > SCHEDULER_POLL_TIMEOUT:
                self.fail(
                    "Schedule did not complete within %d sec. Last state: %s"
                    % (SCHEDULER_POLL_TIMEOUT, last_state)
                )

            poll_count += 1

            resp = http_requests.get(
                SCHEDULER_URL,
                headers=self._auth_headers(),
                json={"uuid": self.schedule_uuid},
                verify=False,
                timeout=15,
            )

            if resp.status_code != 200:
                print("  [%3ds] Poll #%d: HTTP %d - %s" % (
                    elapsed, poll_count, resp.status_code, resp.text[:200],
                ))
                time.sleep(SCHEDULER_POLL_INTERVAL)
                continue

            data = resp.json()

            # Response can be a list or dict
            if isinstance(data, list) and len(data) > 0:
                schedule = data[0]
            elif isinstance(data, dict):
                schedule = data
            else:
                print("  [%3ds] Poll #%d: unexpected response: %s" % (
                    elapsed, poll_count, str(data)[:200],
                ))
                time.sleep(SCHEDULER_POLL_INTERVAL)
                continue

            state = schedule.get("state", "unknown")

            if state != last_state:
                print("  [%3ds] Poll #%d: state = %s" % (elapsed, poll_count, state))
                last_state = state

            # Check terminal states
            state_lower = state.lower().replace("_", "")
            if state_lower == "done":
                print("  Schedule completed successfully in %.1f sec" % elapsed)
                return
            elif "permanentfailure" in state_lower or "permanent" in state_lower:
                self.fail(
                    "Schedule reached permanent failure state after %.1f sec. "
                    "Full response: %s" % (elapsed, json.dumps(schedule, indent=2)[:1000])
                )
            elif "cancelled" in state_lower:
                self.fail("Schedule was cancelled")

            time.sleep(SCHEDULER_POLL_INTERVAL)

    # ----------------------------------------------------------
    # STEP 7: Get task result
    # ----------------------------------------------------------

    @unittest.skipUnless(ENABLE_DOCKER_BUILD, "Docker build disabled")
    def test_07_get_task_result(self):
        """Step 7: Get the task result from the completed schedule.

        The result should contain the output of MyCalculation.result():
        {"result": 60, "count": 8, "average": 7.5, ...}
        """
        print("\n--- STEP 07: Get task result ---")
        self.assertIsNotNone(self.schedule_uuid, "No schedule UUID")

        url = "%s/api/scheduler/schedule/related_tasks/%s" % (BASE_URL, self.schedule_uuid)
        print("  GET %s" % url)

        resp = http_requests.get(
            url,
            headers=self._auth_headers(),
            json={},
            verify=False,
            timeout=15,
        )

        print("  Status: %d" % resp.status_code)
        self.assertEqual(resp.status_code, 200, "Failed to get tasks: %s" % resp.text[:300])

        tasks = resp.json()
        self.assertIsInstance(tasks, list, "Expected list of tasks")
        self.assertGreater(len(tasks), 0, "No tasks found for schedule")

        task = tasks[0]
        print("  Task UUID: %s" % task.get("uuid", "?"))
        print("  Task state: %s" % task.get("state", "?"))
        print("  Execution time: %s sec" % task.get("execution_time", "?"))
        print("  Log: %s" % str(task.get("log", ""))[:300])

        # Parse and verify the calculation result
        result_raw = task.get("result", "")
        print("  Result (raw): %s" % str(result_raw)[:500])

        # Result might be a string (JSON or Python repr) or already parsed
        if isinstance(result_raw, str):
            try:
                result = json.loads(result_raw)
            except (json.JSONDecodeError, ValueError):
                # Fallback: Python dict repr uses single quotes
                import ast
                try:
                    result = ast.literal_eval(result_raw)
                except (ValueError, SyntaxError):
                    result = result_raw
        else:
            result = result_raw

        self.__class__.task_result = result

        # If we got a proper dict result, verify the calculation
        if isinstance(result, dict):
            calc_result = result.get("calculation_result", result)
            if isinstance(calc_result, str):
                try:
                    calc_result = json.loads(calc_result)
                except (json.JSONDecodeError, ValueError):
                    pass

            if isinstance(calc_result, dict):
                print("  Calculation result:")
                print("    sum = %s (expected %d)" % (calc_result.get("result", "?"), EXPECTED_SUM))
                print("    count = %s (expected %d)" % (calc_result.get("count", "?"), EXPECTED_COUNT))
                print("    average = %s (expected %.1f)" % (calc_result.get("average", "?"), EXPECTED_AVERAGE))

                # Verify calculation correctness
                if "result" in calc_result:
                    self.assertEqual(
                        calc_result["result"], EXPECTED_SUM,
                        "Sum mismatch: expected %d, got %s" % (EXPECTED_SUM, calc_result["result"]),
                    )
                if "count" in calc_result:
                    self.assertEqual(
                        calc_result["count"], EXPECTED_COUNT,
                        "Count mismatch: expected %d, got %s" % (EXPECTED_COUNT, calc_result["count"]),
                    )
                if "average" in calc_result:
                    self.assertAlmostEqual(
                        calc_result["average"], EXPECTED_AVERAGE, places=1,
                        msg="Average mismatch",
                    )
                print("  VERIFIED: Calculation results correct!")
        else:
            print("  Result is not a dict, skipping calculation verification")
            print("  Result type: %s" % type(result).__name__)

    # ----------------------------------------------------------
    # STEP 7b: Verify callback was received (webhook.site)
    # ----------------------------------------------------------

    @unittest.skipUnless(ENABLE_DOCKER_BUILD, "Docker build disabled")
    def test_07b_verify_callback(self):
        """Step 7b: Verify that the user callback was delivered via webhook.site.

        The scheduler sends two callbacks after task completion:
        1. Internal scheduler callback (always, to SCHEDULER_URL)
        2. User callback (if configured in taskConfig.callback)

        We verify #2 by checking webhook.site for received requests.
        """
        print("\n--- STEP 07b: Verify callback delivery ---")

        if not self.webhook_token:
            print("  SKIPPED: webhook.site not available")
            return

        # Give a moment for the callback to arrive
        time.sleep(2)

        url = "https://webhook.site/token/%s/requests" % self.webhook_token
        print("  GET %s" % url)

        try:
            resp = http_requests.get(url, timeout=10)
        except Exception as e:
            print("  WARNING: Could not check webhook.site: %s" % e)
            return

        if resp.status_code != 200:
            print("  WARNING: webhook.site returned %d" % resp.status_code)
            return

        data = resp.json()
        requests_list = data.get("data", data) if isinstance(data, dict) else data

        if not isinstance(requests_list, list) or len(requests_list) == 0:
            print("  WARNING: No callback received at webhook.site")
            print("  (Container may not have internet access)")
            return

        print("  Callbacks received: %d" % len(requests_list))
        callback = requests_list[0]
        print("  Method: %s" % callback.get("method", "?"))
        print("  IP: %s" % callback.get("ip", "?"))
        print("  Created at: %s" % callback.get("created_at", "?"))

        # Parse callback body
        content = callback.get("content", callback.get("text_content", ""))
        if content:
            print("  Body (first 500 chars): %s" % str(content)[:500])
            try:
                body = json.loads(content) if isinstance(content, str) else content
                if isinstance(body, dict):
                    print("  Callback contains state: %s" % body.get("state", "?"))
                    print("  Callback contains id: %s" % str(body.get("id", "?"))[:40])
                    if "calculation_result" in body:
                        print("  Callback contains calculation_result: %s" % str(body["calculation_result"])[:200])
            except (json.JSONDecodeError, ValueError):
                pass

        print("  VERIFIED: User callback delivered successfully!")

    # ----------------------------------------------------------
    # STEP 8: Get schedule details (final state)
    # ----------------------------------------------------------

    @unittest.skipUnless(ENABLE_DOCKER_BUILD, "Docker build disabled")
    def test_08_get_schedule_details(self):
        """Step 8: Get final schedule details for verification."""
        print("\n--- STEP 08: Get schedule details ---")
        self.assertIsNotNone(self.schedule_uuid, "No schedule UUID")

        resp = http_requests.get(
            SCHEDULER_URL,
            headers=self._auth_headers(),
            json={"uuid": self.schedule_uuid},
            verify=False,
            timeout=15,
        )

        self.assertEqual(resp.status_code, 200)
        data = resp.json()

        if isinstance(data, list) and len(data) > 0:
            schedule = data[0]
        else:
            schedule = data

        print("  UUID: %s" % schedule.get("uuid", "?"))
        print("  calculationName: %s" % schedule.get("calculationName", "?"))
        print("  state: %s" % schedule.get("state", "?"))
        print("  image_tag: %s" % schedule.get("image_tag", "?"))
        print("  node_label: %s" % schedule.get("node_label", "?"))
        print("  selected_node: %s" % schedule.get("selected_node", "?"))
        print("  creationTime: %s" % schedule.get("creationTime", "?"))

        scheduling = schedule.get("scheduling", {})
        print("  lastStart: %s" % scheduling.get("lastStart", "?"))

    # ----------------------------------------------------------
    # STEP 9: Delete schedule (cleanup)
    # ----------------------------------------------------------

    @unittest.skipUnless(ENABLE_DOCKER_BUILD, "Docker build disabled")
    def test_09_delete_schedule(self):
        """Step 9: Delete the schedule (cleanup)."""
        print("\n--- STEP 09: Delete schedule ---")
        self.assertIsNotNone(self.schedule_uuid, "No schedule UUID")

        resp = http_requests.delete(
            SCHEDULER_URL,
            headers=self._auth_headers(),
            json={"uuid": self.schedule_uuid},
            verify=False,
            timeout=15,
        )

        print("  Status: %d" % resp.status_code)
        print("  Response: %s" % resp.text[:200])

        self.assertIn(resp.status_code, [200, 204], "Delete failed: %s" % resp.text[:300])
        print("  Schedule deleted: %s" % self.schedule_uuid)

    # ----------------------------------------------------------
    # Summary
    # ----------------------------------------------------------

    @classmethod
    def tearDownClass(cls):
        print("\n" + "=" * 80)
        print("  SCHEDULER WORKFLOW E2E TEST SUMMARY")
        print("=" * 80)
        print("  Environment: %s" % BASE_URL)
        print("  User: %s" % TEST_USER)
        print("  Service: %s" % cls.service_name)
        if cls.build_result:
            print("  Image: %s" % cls.build_result.get("full_image", "?"))
            print("  Service ID: %s" % cls.build_result.get("service_id", "?"))
        if cls.schedule_uuid:
            print("  Schedule UUID: %s" % cls.schedule_uuid)
        if cls.task_result and isinstance(cls.task_result, dict):
            print("  Calculation result: %s" % json.dumps(cls.task_result)[:300])
        print("=" * 80)


if __name__ == "__main__":
    unittest.main(verbosity=2)
