#!/usr/bin/env python3
"""Infrastructure Endpoint Tests for BlackAnt SDK.

Tests internal SDK infrastructure endpoints that are NOT part of
a typical researcher workflow. These verify:

  1. SDK Services raw HTTP endpoints (/ping, /registry/list, /registry/tags, /roles)
  2. DockerRegistryClient (Docker Registry V2 API: health, catalog, tags, manifest)
  3. ServiceRegistry CRUD (register, get, delete via ServiceManager)

Run:
    pytest test/e2e/test_infrastructure_endpoints.py -v

All parameters are configured for dev.blackant.app by default.
"""

import sys
import os
import time
import unittest
import warnings

import requests as http_requests

# Suppress SSL warnings for self-signed dev cert
warnings.filterwarnings("ignore", message="Unverified HTTPS request")

# Add src to path for local imports
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "..", "src"))

# ============================================================
# Configuration - same as main E2E test
# ============================================================
BASE_URL = "https://dev.blackant.app"
LOGIN_URL = "https://dev.blackant.app/api/auth/login"
TEST_USER = "admin"
TEST_PASSWORD = "3c6DkEy4Hzbdehvd"

# Docker / Registry
REGISTRY_URL = "env.blackant.app:5000"
REGISTRY_NAMESPACE = "science_module"

# Feature flags
ENABLE_DOCKER_REGISTRY_API = False  # Direct Docker Registry V2 (port 5000)
ENABLE_SERVICE_REGISTRY_CRUD = True  # ServiceRegistry register/get/delete

# Docker Registry V2 API (direct, for DockerRegistryClient tests)
DOCKER_REGISTRY_API_URL = "http://env.blackant.app:5000"
# ============================================================


def _set_env():
    """Set environment variables before SDK imports."""
    os.environ["DOCKER_NGINX_PROXY_URL"] = "https://dev.blackant.app:443/api/docker"
    os.environ["DOCKER_REGISTRY_URL"] = REGISTRY_URL
    os.environ["DOCKER_REGISTRY_NAMESPACE"] = REGISTRY_NAMESPACE
    os.environ["SDK_SERVICES_URL"] = BASE_URL
    os.environ["SDK_SERVICES_REGISTRY"] = "true"
    os.environ["SDK_SERVICES_ROLES"] = "true"
    os.environ["BLACKANT_BASE_URL"] = BASE_URL


_set_env()

# SDK imports (after env setup)
from blackant import BlackAntClient, BlackAntAuth
from blackant.docker.registry import DockerRegistryClient


class TestInfrastructureEndpoints(unittest.TestCase):
    """Infrastructure endpoint tests for dev.blackant.app."""

    # Shared state
    client = None
    auth = None
    registry_client = None
    _test_repo = None
    _registered_service_id = None

    @classmethod
    def setUpClass(cls):
        print("\n" + "=" * 70)
        print("  BLACKANT SDK - INFRASTRUCTURE ENDPOINT TESTS")
        print("  Environment: %s" % BASE_URL)
        print("=" * 70)

    # ----------------------------------------------------------
    # Auth (required before all tests)
    # ----------------------------------------------------------

    def test_00_authenticate(self):
        """Authenticate with BlackAnt."""
        print("\n--- Auth ---")
        self.__class__.client = BlackAntClient(
            user=TEST_USER,
            password=TEST_PASSWORD,
            base_url=BASE_URL,
            login_url=LOGIN_URL,
        )
        result = self.client.authenticate()
        self.assertTrue(result, "Authentication failed")
        self.__class__.auth = self.client.auth
        print("  Authenticated as: %s" % TEST_USER)

    # ----------------------------------------------------------
    # SDK Services raw HTTP endpoints
    # ----------------------------------------------------------

    def test_10_sdk_services_ping(self):
        """Test /sdk_services/ping health check endpoint."""
        print("\n--- SDK Services /ping ---")
        self.assertIsNotNone(self.auth, "Not authenticated")

        token = self.auth.get_token()
        resp = http_requests.get(
            "%s/api/sdk_services/ping" % BASE_URL,
            headers={"Authorization": "Bearer %s" % token},
            verify=False,
            timeout=15,
        )
        self.assertEqual(resp.status_code, 200)
        data = resp.json()
        print("  Response: %s" % data)

    def test_11_sdk_services_registry_list(self):
        """Test /sdk_services/registry/list endpoint."""
        print("\n--- SDK Services /registry/list ---")

        token = self.auth.get_token()
        resp = http_requests.get(
            "%s/api/sdk_services/registry/list" % BASE_URL,
            headers={"Authorization": "Bearer %s" % token},
            verify=False,
            timeout=30,
        )
        self.assertIn(resp.status_code, [200, 500, 502])
        print("  Status: %d" % resp.status_code)
        if resp.status_code == 200:
            try:
                data = resp.json()
                print("  Repositories: %s" % str(data)[:300])
            except ValueError:
                print("  Response: %s" % resp.text[:200])

    def test_12_sdk_services_registry_tags(self):
        """Test /sdk_services/registry/tags/<repo> endpoint."""
        print("\n--- SDK Services /registry/tags ---")

        token = self.auth.get_token()
        repo = REGISTRY_NAMESPACE
        resp = http_requests.get(
            "%s/api/sdk_services/registry/tags/%s" % (BASE_URL, repo),
            headers={"Authorization": "Bearer %s" % token},
            verify=False,
            timeout=30,
        )
        self.assertIn(resp.status_code, [200, 404, 500, 502])
        print("  /registry/tags/%s status: %d" % (repo, resp.status_code))
        if resp.status_code == 200:
            try:
                data = resp.json()
                print("  Tags: %s" % str(data)[:300])
            except ValueError:
                print("  Response: %s" % resp.text[:200])

    def test_13_sdk_services_roles(self):
        """Test /sdk_services/roles/<user_id> endpoint."""
        print("\n--- SDK Services /roles ---")

        token = self.auth.get_token()
        resp = http_requests.get(
            "%s/api/sdk_services/roles/%s" % (BASE_URL, TEST_USER),
            headers={"Authorization": "Bearer %s" % token},
            verify=False,
            timeout=15,
        )
        self.assertIn(resp.status_code, [200, 404, 500, 502])
        print("  /roles/%s status: %d" % (TEST_USER, resp.status_code))
        if resp.status_code == 200:
            try:
                data = resp.json()
                print("  Roles: %s" % str(data)[:300])
            except ValueError:
                print("  Response: %s" % resp.text[:200])

    # ----------------------------------------------------------
    # DockerRegistryClient (Docker Registry V2 API)
    # ----------------------------------------------------------

    @unittest.skipUnless(
        ENABLE_DOCKER_REGISTRY_API, "Docker Registry API disabled (port 5000 not open)"
    )
    def test_20_init_registry_client(self):
        """Initialize DockerRegistryClient for Registry V2 API."""
        print("\n--- Init DockerRegistryClient ---")
        self.assertIsNotNone(self.auth, "Not authenticated")

        self.__class__.registry_client = DockerRegistryClient(
            auth=self.auth,
            registry_url=DOCKER_REGISTRY_API_URL,
        )
        self.assertIsNotNone(self.registry_client)
        print("  DockerRegistryClient initialized for %s" % DOCKER_REGISTRY_API_URL)

    @unittest.skipUnless(
        ENABLE_DOCKER_REGISTRY_API, "Docker Registry API disabled (port 5000 not open)"
    )
    def test_21_registry_health(self):
        """Check Docker Registry health via /v2/ endpoint."""
        print("\n--- Registry health check ---")
        self.assertIsNotNone(self.registry_client, "DockerRegistryClient not initialized")

        result = self.registry_client.check_health()
        self.assertTrue(result, "Registry health check failed")
        print("  Registry health: OK")

    @unittest.skipUnless(
        ENABLE_DOCKER_REGISTRY_API, "Docker Registry API disabled (port 5000 not open)"
    )
    def test_22_registry_catalog(self):
        """Get Docker Registry catalog (/v2/_catalog)."""
        print("\n--- Registry catalog ---")
        self.assertIsNotNone(self.registry_client, "DockerRegistryClient not initialized")

        repos = self.registry_client.get_catalog()
        self.assertIsInstance(repos, list)
        print("  Repositories found: %d" % len(repos))
        for repo in repos[:10]:
            print("    - %s" % repo)
        if repos:
            self.__class__._test_repo = repos[0]

    @unittest.skipUnless(
        ENABLE_DOCKER_REGISTRY_API, "Docker Registry API disabled (port 5000 not open)"
    )
    def test_23_registry_tags(self):
        """Get tags for a repository from registry."""
        print("\n--- Registry tags ---")

        repo = self.__class__._test_repo
        if not repo:
            self.skipTest("No repository found in catalog")

        tags = self.registry_client.get_tags(repo)
        self.assertIsInstance(tags, list)
        self.assertGreater(len(tags), 0, "No tags found for %s" % repo)
        print("  Tags for %s: %s" % (repo, tags[:10]))

    @unittest.skipUnless(
        ENABLE_DOCKER_REGISTRY_API, "Docker Registry API disabled (port 5000 not open)"
    )
    def test_24_registry_manifest(self):
        """Get image manifest from registry."""
        print("\n--- Registry manifest ---")

        repo = self.__class__._test_repo
        if not repo:
            self.skipTest("No repository found in catalog")

        tags = self.registry_client.get_tags(repo)
        if not tags:
            self.skipTest("No tags found for %s" % repo)

        tag = tags[0]
        manifest = self.registry_client.get_manifest(repo, tag)
        self.assertIsInstance(manifest, dict)
        print("  Manifest for %s:%s" % (repo, tag))
        print("  Schema version: %s" % manifest.get("schemaVersion", "?"))

    # ----------------------------------------------------------
    # ServiceRegistry CRUD
    # ----------------------------------------------------------

    @unittest.skipUnless(ENABLE_SERVICE_REGISTRY_CRUD, "ServiceRegistry CRUD tests disabled")
    def test_30_service_registry_register(self):
        """Register a test service via ServiceRegistry.register()."""
        print("\n--- ServiceRegistry.register() ---")
        self.assertIsNotNone(self.client, "Not authenticated")

        self.client.authenticate()  # Fresh token

        svc_name = "e2e-test-infra-%d" % int(time.time())
        service_data = {
            "name": svc_name,
            "type": "science_module",
            "image": {
                "container": REGISTRY_NAMESPACE,
                "name": svc_name,
                "tag": "latest",
            },
            "environments": {},
            "networks": ["science_module_callback_net"],
            "resource_config": {
                "use_gpu": False,
                "cpu_limit": 1,
                "ram_limit": 1024,
                "disk_limit": 1,
                "node_label": "calculation_worker",
            },
        }

        try:
            service_id = self.client.register_service(service_data)
            self.assertIsNotNone(service_id)
            self.__class__._registered_service_id = service_id
            print("  Registered: %s -> %s" % (svc_name, service_id))
        except Exception as e:
            self.skipTest("ServiceManager not available: %s" % e)

    @unittest.skipUnless(ENABLE_SERVICE_REGISTRY_CRUD, "ServiceRegistry CRUD tests disabled")
    def test_31_service_registry_get(self):
        """Get service details via ServiceRegistry.get()."""
        print("\n--- ServiceRegistry.get() ---")

        service_id = self.__class__._registered_service_id
        if not service_id:
            self.skipTest("No service registered in previous step")

        self.client.authenticate()  # Fresh token

        service = self.client.get_service(service_id=service_id)
        self.assertIsNotNone(service)
        print("  Service details: %s" % str(service)[:300])

    @unittest.skipUnless(ENABLE_SERVICE_REGISTRY_CRUD, "ServiceRegistry CRUD tests disabled")
    def test_32_service_registry_delete(self):
        """Delete test service via ServiceRegistry.delete()."""
        print("\n--- ServiceRegistry.delete() ---")

        service_id = self.__class__._registered_service_id
        if not service_id:
            self.skipTest("No service registered to delete")

        self.client.authenticate()  # Fresh token

        result = self.client.delete_service(service_id=service_id)
        self.assertTrue(result, "delete_service returned False")
        print("  Deleted service: %s" % service_id)

    # ----------------------------------------------------------
    # Summary
    # ----------------------------------------------------------

    @classmethod
    def tearDownClass(cls):
        print("\n" + "=" * 70)
        print("  INFRASTRUCTURE TEST SUMMARY")
        print("=" * 70)
        print("  Environment: %s" % BASE_URL)
        print(
            "  Docker Registry API:  %s"
            % ("ENABLED" if ENABLE_DOCKER_REGISTRY_API else "DISABLED (port 5000)")
        )
        print(
            "  ServiceRegistry CRUD: %s"
            % ("ENABLED" if ENABLE_SERVICE_REGISTRY_CRUD else "DISABLED")
        )
        print("=" * 70)


if __name__ == "__main__":
    unittest.main(verbosity=2)
