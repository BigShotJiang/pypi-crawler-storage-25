"""End-to-end MCP workflow test.

Simulates the full researcher workflow through MCP tools:
authenticate -> test_connection -> list_services -> list_schedules
-> create_schedule -> poll status -> get result -> cleanup

Requires:
    - BLACKANT_TEST_USER and BLACKANT_TEST_PASSWORD environment variables
    - Access to dev.blackant.app

Usage:
    pytest test/e2e/test_mcp_workflow.py -v -m e2e
"""

import json
import os
import time
import unittest
import warnings

import pytest

from src.blackant.mcp.session import BlackAntMCPSession
from src.blackant.mcp.tools.auth_tools import authenticate_handler, token_status_handler
from src.blackant.mcp.tools.scheduler_tools import (
    create_schedule_handler,
    delete_schedule_handler,
    get_task_result_handler,
    list_schedules_handler,
    schedule_status_handler,
)
from src.blackant.mcp.tools.service_tools import check_connection_handler, list_services_handler

warnings.filterwarnings("ignore", message="Unverified HTTPS request")


@pytest.mark.e2e
@pytest.mark.requires_credentials
class TestMCPWorkflow(unittest.TestCase):
    """End-to-end test simulating a researcher using BlackAnt via MCP agent."""

    schedule_uuid = None

    @classmethod
    def setUpClass(cls):
        """Create MCP session for the test suite."""
        cls.user = os.getenv("BLACKANT_TEST_USER", "admin")
        cls.password = os.getenv("BLACKANT_TEST_PASSWORD")
        if not cls.password:
            pytest.skip("BLACKANT_TEST_PASSWORD not set")
        cls.base_url = "https://dev.blackant.app"
        os.environ["BLACKANT_BASE_URL"] = cls.base_url
        os.environ["DOCKER_REGISTRY_URL"] = "env.blackant.app:5000"
        os.environ["DOCKER_REGISTRY_NAMESPACE"] = "science_module"
        os.environ["DOCKER_USE_NGINX_PROXY"] = "true"
        os.environ["DOCKER_REGISTRY_PASS"] = "3nDhK0ODL11xImydK0DY"
        cls.session = BlackAntMCPSession(base_url=cls.base_url)

    def test_01_authenticate(self):
        """Step 1: Authenticate with BlackAnt via MCP tool."""
        result = authenticate_handler(self.session, self.user, self.password)
        self.assertTrue(result["success"])
        self.assertNotIn("token", result)

    def test_02_token_status(self):
        """Step 2: Verify authentication status."""
        result = token_status_handler(self.session)
        self.assertTrue(result["authenticated"])
        self.assertEqual(result["username"], self.user)

    def test_03_test_connection(self):
        """Step 3: Test connectivity to platform."""
        result = check_connection_handler(self.session)
        self.assertTrue(result["connected"])

    def test_04_list_services(self):
        """Step 4: List available services."""
        result = list_services_handler(self.session)
        self.assertIsInstance(result, list)

    def test_05_list_schedules(self):
        """Step 5: List existing schedules."""
        result = list_schedules_handler(self.session)
        self.assertIsInstance(result, list)

    def test_06_create_schedule(self):
        """Step 6: Create a schedule for oe-demo calculation."""
        result = create_schedule_handler(
            self.session,
            calculation_name="oe-demo",
            image_tag="latest",
            cmd_args='{"numbers": [1, 2, 3, 4, 5]}',
        )
        self.assertEqual(result["status"], "created")
        self.assertTrue(len(result["schedule_uuid"]) > 10)
        self.__class__.schedule_uuid = result["schedule_uuid"]

    def test_07_poll_schedule_until_terminal(self):
        """Step 7: Poll schedule status until terminal state (done or permanentFailure)."""
        self.assertIsNotNone(self.schedule_uuid, "No schedule UUID from step 6")

        timeout = 120
        start = time.time()
        while time.time() - start < timeout:
            result = schedule_status_handler(self.session, self.schedule_uuid)
            self.assertIn("state", result)
            self.assertIn("is_terminal", result)
            if result["is_terminal"]:
                self.assertIn(result["state"], ("done", "permanentFailure"))
                self.__class__.final_state = result["state"]
                return
            time.sleep(5)

        self.fail(f"Schedule did not reach terminal state within {timeout}s")

    def test_08_get_task_result(self):
        """Step 8: Get task results (verifies API contract, result depends on server state)."""
        self.assertIsNotNone(self.schedule_uuid, "No schedule UUID")
        result = get_task_result_handler(self.session, self.schedule_uuid)
        self.assertIn("task_count", result)
        self.assertIn("tasks", result)
        self.assertIsInstance(result["tasks"], list)

    def test_09_delete_schedule(self):
        """Step 9: Cleanup - delete the schedule."""
        self.assertIsNotNone(self.schedule_uuid, "No schedule UUID")
        result = delete_schedule_handler(self.session, self.schedule_uuid)
        self.assertTrue(result["deleted"])


if __name__ == "__main__":
    unittest.main()
