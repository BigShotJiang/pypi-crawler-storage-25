"""Unit tests for MCP scheduler tools.

Tests the scheduler tool handlers with mocked BlackAntMCPSession,
including input validation and error handling.
"""

import json
import unittest
from unittest.mock import MagicMock

from src.blackant.mcp.exceptions import MCPToolError
from src.blackant.mcp.tools.scheduler_tools import (
    create_schedule_handler,
    delete_schedule_handler,
    get_task_result_handler,
    list_schedules_handler,
    schedule_status_handler,
)


class TestCreateScheduleHandler(unittest.TestCase):
    """Test blackant_create_schedule tool handler."""

    def setUp(self):
        """Set up mock session."""
        self.mock_session = MagicMock()
        self.mock_session.client.create_schedule.return_value = "uuid-abc-123"

    def test_success_returns_uuid(self):
        """Successful schedule creation returns UUID."""
        result = create_schedule_handler(
            self.mock_session, "my-calc", "v1.0", '{"numbers": [1,2,3]}'
        )
        self.assertEqual(result["schedule_uuid"], "uuid-abc-123")
        self.assertEqual(result["status"], "created")
        self.assertEqual(result["calculation_name"], "my-calc")

    def test_passes_parsed_cmd_args(self):
        """cmd_args JSON string is parsed and forwarded."""
        create_schedule_handler(
            self.mock_session, "my-calc", "latest", '{"key": "value"}'
        )
        call_kwargs = self.mock_session.client.create_schedule.call_args[1]
        self.assertEqual(call_kwargs["cmd_args"], {"key": "value"})

    def test_none_cmd_args_passes_none(self):
        """No cmd_args passes None to client."""
        create_schedule_handler(self.mock_session, "my-calc", "latest", None)
        call_kwargs = self.mock_session.client.create_schedule.call_args[1]
        self.assertIsNone(call_kwargs["cmd_args"])

    def test_invalid_json_raises(self):
        """Invalid JSON cmd_args raises MCPToolError."""
        with self.assertRaises(MCPToolError) as ctx:
            create_schedule_handler(self.mock_session, "my-calc", "latest", "not json")
        self.assertIn("Invalid cmd_args JSON", str(ctx.exception))

    def test_client_exception_wrapped(self):
        """Client exception is wrapped as MCPToolError."""
        self.mock_session.client.create_schedule.side_effect = RuntimeError("timeout")
        with self.assertRaises(MCPToolError):
            create_schedule_handler(self.mock_session, "my-calc", "latest", None)


class TestScheduleStatusHandler(unittest.TestCase):
    """Test blackant_schedule_status tool handler."""

    def setUp(self):
        """Set up mock session."""
        self.mock_session = MagicMock()

    def test_running_state(self):
        """Running schedule returns correct state info."""
        self.mock_session.client.get_schedule.return_value = {
            "uuid": "abc-123",
            "state": "running",
            "calculationName": "my-calc",
            "image_tag": "v1.0",
            "creationTime": "2026-03-14T10:00:00",
        }
        result = schedule_status_handler(self.mock_session, "abc-123")
        self.assertEqual(result["state"], "running")
        self.assertFalse(result["is_terminal"])

    def test_done_is_terminal(self):
        """Done state is terminal."""
        self.mock_session.client.get_schedule.return_value = {"state": "done"}
        result = schedule_status_handler(self.mock_session, "abc-123")
        self.assertTrue(result["is_terminal"])

    def test_permanent_failure_is_terminal(self):
        """permanentFailure state is terminal."""
        self.mock_session.client.get_schedule.return_value = {"state": "permanentFailure"}
        result = schedule_status_handler(self.mock_session, "abc-123")
        self.assertTrue(result["is_terminal"])

    def test_client_exception_wrapped(self):
        """Client exception is wrapped as MCPToolError."""
        self.mock_session.client.get_schedule.side_effect = RuntimeError("not found")
        with self.assertRaises(MCPToolError):
            schedule_status_handler(self.mock_session, "abc-123")


class TestGetTaskResultHandler(unittest.TestCase):
    """Test blackant_get_task_result tool handler."""

    def setUp(self):
        """Set up mock session."""
        self.mock_session = MagicMock()

    def test_returns_parsed_results(self):
        """Task results are parsed from JSON strings."""
        self.mock_session.client.get_task_results.return_value = [
            {
                "uuid": "task-1",
                "state": "done",
                "execution_time": "5.2",
                "result": '{"sum": 60, "count": 8}',
                "log": "Calculation complete",
            }
        ]
        result = get_task_result_handler(self.mock_session, "sched-1")
        self.assertEqual(result["task_count"], 1)
        self.assertEqual(result["tasks"][0]["result"]["sum"], 60)

    def test_no_tasks_returns_empty(self):
        """Empty task list returns helpful message."""
        self.mock_session.client.get_task_results.return_value = []
        result = get_task_result_handler(self.mock_session, "sched-1")
        self.assertEqual(result["tasks"], [])
        self.assertIn("still be running", result["message"])

    def test_non_json_result_kept_as_string(self):
        """Non-JSON result is kept as raw string."""
        self.mock_session.client.get_task_results.return_value = [
            {"uuid": "t-1", "state": "done", "result": "plain text result"}
        ]
        result = get_task_result_handler(self.mock_session, "sched-1")
        self.assertEqual(result["tasks"][0]["result"], "plain text result")

    def test_client_exception_wrapped(self):
        """Client exception is wrapped as MCPToolError."""
        self.mock_session.client.get_task_results.side_effect = RuntimeError("err")
        with self.assertRaises(MCPToolError):
            get_task_result_handler(self.mock_session, "sched-1")


class TestListSchedulesHandler(unittest.TestCase):
    """Test blackant_list_schedules tool handler."""

    def setUp(self):
        """Set up mock session."""
        self.mock_session = MagicMock()

    def test_returns_schedule_summaries(self):
        """Returns list of schedule summaries."""
        self.mock_session.client.list_schedules.return_value = [
            {"uuid": "s-1", "calculationName": "calc-a", "state": "done", "image_tag": "v1"},
            {"uuid": "s-2", "calculationName": "calc-b", "state": "running", "image_tag": "v2"},
        ]
        result = list_schedules_handler(self.mock_session)
        self.assertEqual(len(result), 2)
        self.assertEqual(result[0]["uuid"], "s-1")
        self.assertEqual(result[1]["state"], "running")

    def test_client_exception_wrapped(self):
        """Client exception is wrapped as MCPToolError."""
        self.mock_session.client.list_schedules.side_effect = RuntimeError("err")
        with self.assertRaises(MCPToolError):
            list_schedules_handler(self.mock_session)


class TestDeleteScheduleHandler(unittest.TestCase):
    """Test blackant_delete_schedule tool handler."""

    def setUp(self):
        """Set up mock session."""
        self.mock_session = MagicMock()

    def test_success_returns_deleted(self):
        """Successful deletion returns deleted=True."""
        self.mock_session.client.delete_schedule.return_value = True
        result = delete_schedule_handler(self.mock_session, "sched-1")
        self.assertTrue(result["deleted"])

    def test_failure_raises(self):
        """Failed deletion raises MCPToolError."""
        self.mock_session.client.delete_schedule.return_value = False
        with self.assertRaises(MCPToolError):
            delete_schedule_handler(self.mock_session, "sched-1")

    def test_client_exception_wrapped(self):
        """Client exception is wrapped as MCPToolError."""
        self.mock_session.client.delete_schedule.side_effect = RuntimeError("err")
        with self.assertRaises(MCPToolError):
            delete_schedule_handler(self.mock_session, "sched-1")


if __name__ == "__main__":
    unittest.main()
