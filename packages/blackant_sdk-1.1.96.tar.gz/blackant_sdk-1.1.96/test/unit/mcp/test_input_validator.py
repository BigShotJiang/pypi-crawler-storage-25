"""Unit tests for MCP input validators.

Tests validation of service names, source paths, and GPU counts
used by MCP tools before delegating to BlackAntClient.
"""

import os
import tempfile
import unittest

from src.blackant.mcp.security.input_validator import (
    validate_gpu_count,
    validate_service_name,
    validate_source_path,
)


class TestValidateServiceName(unittest.TestCase):
    """Test service name validation against BlackAnt naming rules."""

    def test_single_character_valid(self):
        """Single lowercase letter is valid (minimum length)."""
        self.assertEqual(validate_service_name("a"), "a")

    def test_single_digit_valid(self):
        """Single digit is valid."""
        self.assertEqual(validate_service_name("1"), "1")

    def test_max_length_valid(self):
        """63-character name is valid (maximum length)."""
        name = "a" + "b" * 62
        self.assertEqual(validate_service_name(name), name)

    def test_with_hyphens_valid(self):
        """Name with hyphens is valid."""
        self.assertEqual(validate_service_name("my-service-123"), "my-service-123")

    def test_all_digits_valid(self):
        """All-digit name is valid."""
        self.assertEqual(validate_service_name("12345"), "12345")

    def test_uppercase_invalid(self):
        """Uppercase letters are not allowed."""
        with self.assertRaises(ValueError):
            validate_service_name("MyService")

    def test_spaces_invalid(self):
        """Spaces are not allowed."""
        with self.assertRaises(ValueError):
            validate_service_name("my service")

    def test_starts_with_hyphen_invalid(self):
        """Name starting with hyphen is not allowed."""
        with self.assertRaises(ValueError):
            validate_service_name("-my-service")

    def test_too_long_invalid(self):
        """Name longer than 63 characters is not allowed."""
        name = "a" * 64
        with self.assertRaises(ValueError):
            validate_service_name(name)

    def test_empty_string_invalid(self):
        """Empty string is not allowed."""
        with self.assertRaises(ValueError):
            validate_service_name("")

    def test_underscores_invalid(self):
        """Underscores are not allowed in service names."""
        with self.assertRaises(ValueError):
            validate_service_name("my_service")

    def test_dots_invalid(self):
        """Dots are not allowed."""
        with self.assertRaises(ValueError):
            validate_service_name("my.service")


class TestValidateSourcePath(unittest.TestCase):
    """Test source path validation for Docker build directories."""

    def test_valid_path_with_dockerfile(self):
        """Valid directory with Dockerfile passes validation."""
        with tempfile.TemporaryDirectory() as tmpdir:
            dockerfile = os.path.join(tmpdir, "Dockerfile")
            with open(dockerfile, "w") as f:
                f.write("FROM python:3.11\n")
            result = validate_source_path(tmpdir)
            self.assertTrue(result.is_dir())
            self.assertTrue((result / "Dockerfile").exists())

    def test_missing_dockerfile_raises(self):
        """Directory without Dockerfile raises ValueError."""
        with tempfile.TemporaryDirectory() as tmpdir:
            with self.assertRaises(ValueError) as ctx:
                validate_source_path(tmpdir)
            self.assertIn("No Dockerfile", str(ctx.exception))

    def test_nonexistent_path_raises(self):
        """Non-existent path raises ValueError."""
        with self.assertRaises(ValueError) as ctx:
            validate_source_path("/tmp/nonexistent_path_abc123xyz")
        self.assertIn("does not exist", str(ctx.exception))

    def test_file_instead_of_directory_raises(self):
        """Path pointing to a file (not directory) raises ValueError."""
        with tempfile.NamedTemporaryFile() as tmpfile:
            with self.assertRaises(ValueError) as ctx:
                validate_source_path(tmpfile.name)
            self.assertIn("not a directory", str(ctx.exception))

    def test_resolves_to_absolute_path(self):
        """Path is resolved to an absolute path."""
        with tempfile.TemporaryDirectory() as tmpdir:
            dockerfile = os.path.join(tmpdir, "Dockerfile")
            with open(dockerfile, "w") as f:
                f.write("FROM python:3.11\n")
            result = validate_source_path(tmpdir)
            self.assertTrue(result.is_absolute())


class TestValidateGpuCount(unittest.TestCase):
    """Test GPU count validation."""

    def test_zero_valid(self):
        """Zero GPUs is valid (CPU-only)."""
        self.assertEqual(validate_gpu_count(0), 0)

    def test_max_valid(self):
        """8 GPUs is valid (maximum)."""
        self.assertEqual(validate_gpu_count(8), 8)

    def test_mid_range_valid(self):
        """4 GPUs is valid."""
        self.assertEqual(validate_gpu_count(4), 4)

    def test_negative_invalid(self):
        """Negative GPU count is not allowed."""
        with self.assertRaises(ValueError):
            validate_gpu_count(-1)

    def test_over_max_invalid(self):
        """More than 8 GPUs is not allowed."""
        with self.assertRaises(ValueError):
            validate_gpu_count(9)

    def test_float_invalid(self):
        """Float GPU count is not allowed."""
        with self.assertRaises(ValueError):
            validate_gpu_count(2.5)

    def test_string_invalid(self):
        """String GPU count is not allowed."""
        with self.assertRaises(ValueError):
            validate_gpu_count("4")


if __name__ == "__main__":
    unittest.main()
