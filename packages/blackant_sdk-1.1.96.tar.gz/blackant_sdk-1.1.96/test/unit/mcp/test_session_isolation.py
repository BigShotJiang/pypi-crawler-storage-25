"""Unit tests for MCP session context isolation."""

import unittest
from unittest.mock import MagicMock, patch

from src.blackant.mcp.security.request_context import set_current_identity
from src.blackant.mcp.session import BlackAntMCPSession


class TestMCPSessionIsolation(unittest.TestCase):
    """Ensure auth state is isolated per verified caller identity."""

    def tearDown(self):
        set_current_identity(None)

    @patch("src.blackant.mcp.session.MCPClientFacade")
    @patch("src.blackant.mcp.session.BlackAntAuth")
    def test_authentication_is_isolated_per_subject(self, mock_auth_cls, mock_facade_cls):
        mock_auth = MagicMock()
        mock_auth.authenticate.return_value = "token"
        mock_auth_cls.return_value = mock_auth

        client_a = MagicMock()
        client_a.is_authenticated.return_value = True
        client_b = MagicMock()
        client_b.is_authenticated.return_value = True
        mock_facade_cls.side_effect = [client_a, client_b]

        session = BlackAntMCPSession(base_url="https://dev.blackant.app")

        set_current_identity("sub-a")
        self.assertTrue(session.authenticate("alice", "pw-a"))

        set_current_identity("sub-b")
        self.assertTrue(session.authenticate("bob", "pw-b"))

        set_current_identity("sub-a")
        self.assertTrue(session.authenticated)
        self.assertEqual(session.username, "alice")
        self.assertIs(session.client, client_a)

        set_current_identity("sub-b")
        self.assertTrue(session.authenticated)
        self.assertEqual(session.username, "bob")
        self.assertIs(session.client, client_b)


if __name__ == "__main__":
    unittest.main()
