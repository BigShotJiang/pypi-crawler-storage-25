"""Unit tests for Keycloak token verifier."""

import time
import unittest
from unittest.mock import MagicMock, patch

import jwt

from src.blackant.mcp.security.token_verifier import AccessToken, KeycloakTokenVerifier


def _make_jwt(claims: dict) -> str:
    """Create an unsigned JWT for testing."""
    payload = {
        "sub": "user-123",
        "preferred_username": "testuser",
        "azp": "nginx-auth-proxy",
        "scope": "openid email profile",
        "exp": int(time.time()) + 3600,
        "iat": int(time.time()),
        **claims,
    }
    return jwt.encode(payload, "secret", algorithm="HS256")


class TestKeycloakTokenVerifier(unittest.TestCase):
    """Test KeycloakTokenVerifier strict verification behavior."""

    def setUp(self):
        """Set up verifier instance."""
        self.verifier = KeycloakTokenVerifier(base_url="https://dev.blackant.app")

    def test_valid_token_returns_access_token_via_introspection(self):
        """Valid token accepted when introspection confirms it."""
        token = _make_jwt({"preferred_username": "researcher"})
        import asyncio
        with patch.object(
            self.verifier,
            "_introspect_token",
            return_value={
                "sub": "user-123",
                "preferred_username": "researcher",
                "azp": "nginx-auth-proxy",
                "scope": "openid email profile",
            },
        ):
            result = asyncio.run(self.verifier.verify_token(token))
        self.assertIsNotNone(result)
        self.assertIsInstance(result, AccessToken)
        self.assertEqual(result.username, "researcher")
        self.assertEqual(result.subject, "user-123")

    def test_expired_jwt_is_rejected_without_valid_introspection(self):
        """Expired/fake JWT is rejected when introspection does not validate it."""
        token = _make_jwt({"exp": int(time.time()) - 3600})
        import asyncio
        with patch.object(self.verifier, "_introspect_token", return_value=None):
            result = asyncio.run(self.verifier.verify_token(token))
        self.assertIsNone(result)

    def test_empty_token_returns_none(self):
        """Empty token returns None."""
        import asyncio
        result = asyncio.run(self.verifier.verify_token(""))
        self.assertIsNone(result)

    def test_garbage_token_returns_none(self):
        """Non-JWT string returns None after both strategies fail."""
        import asyncio
        with patch.object(self.verifier, "_introspect_token", return_value=None):
            result = asyncio.run(self.verifier.verify_token("not-a-jwt"))
        self.assertIsNone(result)

    def test_jwt_without_sub_returns_none(self):
        """JWT without sub claim is rejected."""
        payload = {"preferred_username": "test", "exp": int(time.time()) + 3600}
        token = jwt.encode(payload, "secret", algorithm="HS256")
        import asyncio
        with patch.object(self.verifier, "_introspect_token", return_value=None):
            result = asyncio.run(self.verifier.verify_token(token))
        self.assertIsNone(result)

    def test_scopes_parsed_from_space_separated_string(self):
        """Scope string is split into list."""
        token = _make_jwt({"scope": "openid email mcp:read"})
        import asyncio
        with patch.object(
            self.verifier,
            "_introspect_token",
            return_value={
                "sub": "user-123",
                "preferred_username": "testuser",
                "azp": "nginx-auth-proxy",
                "scope": "openid email mcp:read",
            },
        ):
            result = asyncio.run(self.verifier.verify_token(token))
        self.assertEqual(result.scopes, ["openid", "email", "mcp:read"])

    def test_introspection_fallback_on_jwt_failure(self):
        """Falls back to introspection when JWT decode fails."""
        introspection_data = {
            "sub": "user-456",
            "preferred_username": "fallback-user",
            "azp": "client",
            "scope": "openid",
        }
        with patch.object(self.verifier, "_introspect_token", return_value=introspection_data):
            import asyncio
            result = asyncio.run(self.verifier.verify_token("invalid-jwt"))
        self.assertIsNotNone(result)
        self.assertEqual(result.username, "fallback-user")
        self.assertEqual(result.subject, "user-456")

    @patch("src.blackant.mcp.security.token_verifier.requests.post")
    def test_introspection_calls_verify_endpoint(self, mock_post):
        """Introspection sends POST to /api/auth/verify."""
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.json.return_value = {"sub": "u-1", "preferred_username": "admin"}
        mock_post.return_value = mock_resp

        result = self.verifier._introspect_token("some-token")
        self.assertIsNotNone(result)
        mock_post.assert_called_once()
        call_args = mock_post.call_args
        self.assertIn("/api/auth/verify", call_args[0][0])
        self.assertIn("Bearer some-token", call_args[1]["headers"]["Authorization"])

    @patch("src.blackant.mcp.security.token_verifier.requests.post")
    def test_introspection_returns_none_on_401(self, mock_post):
        """Introspection returns None on 401."""
        mock_resp = MagicMock()
        mock_resp.status_code = 401
        mock_post.return_value = mock_resp

        result = self.verifier._introspect_token("bad-token")
        self.assertIsNone(result)

    @patch("src.blackant.mcp.security.token_verifier.requests.post")
    def test_introspection_rejects_inactive_token(self, mock_post):
        """Inactive introspection response is rejected."""
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.json.return_value = {"active": False, "sub": "u-1"}
        mock_post.return_value = mock_resp

        result = self.verifier._introspect_token("inactive-token")
        self.assertIsNone(result)


if __name__ == "__main__":
    unittest.main()
