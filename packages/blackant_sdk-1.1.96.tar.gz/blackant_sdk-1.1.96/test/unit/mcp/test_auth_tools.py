"""Unit tests for MCP authentication tools.

Tests the authenticate and token_status tool handlers
with mocked BlackAntMCPSession.
"""

import unittest
from unittest.mock import MagicMock, PropertyMock, patch

from src.blackant.mcp.exceptions import MCPToolError
from src.blackant.mcp.tools.auth_tools import authenticate_handler, token_status_handler


class TestAuthenticateHandler(unittest.TestCase):
    """Test blackant_authenticate tool handler."""

    def setUp(self):
        """Set up mock session."""
        self.mock_session = MagicMock()

    def test_success_returns_dict_without_token(self):
        """Successful authentication returns dict with success flag but no token."""
        self.mock_session.authenticate.return_value = True
        result = authenticate_handler(self.mock_session, "testuser", "testpass")
        self.assertTrue(result["success"])
        self.assertIn("testuser", result["message"])
        self.assertNotIn("token", result)
        self.assertNotIn("access_token", result)

    def test_success_calls_session_authenticate(self):
        """Handler delegates to session.authenticate with correct args."""
        self.mock_session.authenticate.return_value = True
        authenticate_handler(self.mock_session, "user@test.com", "secret123")
        self.mock_session.authenticate.assert_called_once_with("user@test.com", "secret123")

    def test_failure_raises_mcp_tool_error(self):
        """Failed authentication raises MCPToolError, not raw exception."""
        self.mock_session.authenticate.return_value = False
        with self.assertRaises(MCPToolError):
            authenticate_handler(self.mock_session, "baduser", "badpass")

    def test_exception_wrapped_as_mcp_tool_error(self):
        """SDK exceptions are wrapped as MCPToolError with user-friendly message."""
        self.mock_session.authenticate.side_effect = ConnectionError("Connection refused")
        with self.assertRaises(MCPToolError) as ctx:
            authenticate_handler(self.mock_session, "user", "pass")
        self.assertIn("Authentication failed", str(ctx.exception))

    def test_mcp_tool_error_passthrough(self):
        """MCPToolError from session is re-raised directly."""
        self.mock_session.authenticate.side_effect = MCPToolError("Custom auth error")
        with self.assertRaises(MCPToolError) as ctx:
            authenticate_handler(self.mock_session, "user", "pass")
        self.assertEqual(str(ctx.exception), "Custom auth error")


class TestTokenStatusHandler(unittest.TestCase):
    """Test blackant_token_status tool handler."""

    def setUp(self):
        """Set up mock session."""
        self.mock_session = MagicMock()

    def test_authenticated_returns_correct_fields(self):
        """Authenticated session returns username and status."""
        self.mock_session.authenticated = True
        self.mock_session.username = "researcher@uni.hu"
        result = token_status_handler(self.mock_session)
        self.assertTrue(result["authenticated"])
        self.assertEqual(result["username"], "researcher@uni.hu")

    def test_not_authenticated_returns_false(self):
        """Unauthenticated session returns authenticated=False without raising."""
        self.mock_session.authenticated = False
        result = token_status_handler(self.mock_session)
        self.assertFalse(result["authenticated"])
        self.assertNotIn("username", result)

    def test_no_username_returns_unknown(self):
        """Authenticated session with no username returns 'unknown'."""
        self.mock_session.authenticated = True
        self.mock_session.username = None
        result = token_status_handler(self.mock_session)
        self.assertTrue(result["authenticated"])
        self.assertEqual(result["username"], "unknown")


if __name__ == "__main__":
    unittest.main()
