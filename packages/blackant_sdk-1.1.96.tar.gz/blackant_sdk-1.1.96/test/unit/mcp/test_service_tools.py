"""Unit tests for MCP service management tools.

Tests the service tool handlers with mocked BlackAntMCPSession,
including input validation and error handling.
"""

import os
import tempfile
import unittest
from unittest.mock import MagicMock, PropertyMock

from src.blackant.mcp.exceptions import MCPToolError
from src.blackant.mcp.tools.service_tools import (
    build_service_handler,
    get_service_handler,
    list_services_handler,
    service_status_handler,
    check_connection_handler,
)


class TestBuildServiceHandler(unittest.TestCase):
    """Test blackant_build_service tool handler."""

    def setUp(self):
        """Set up mock session and temporary directory."""
        self.mock_session = MagicMock()
        self.mock_session.client.build_service.return_value = {
            "service_id": "svc-123",
            "build_success": True,
            "full_image": "env.blackant.app/systemdevelopers/test-svc:v1.0.0",
        }

    def _create_valid_source(self):
        """Create a temporary directory with a Dockerfile."""
        tmpdir = tempfile.mkdtemp()
        with open(os.path.join(tmpdir, "Dockerfile"), "w") as f:
            f.write("FROM python:3.11\n")
        return tmpdir

    def test_valid_build_calls_client(self):
        """Valid build request delegates to client.build_service."""
        tmpdir = self._create_valid_source()
        try:
            result = build_service_handler(
                self.mock_session, tmpdir, "my-service", gpu_count=0
            )
            self.mock_session.client.build_service.assert_called_once()
            self.assertEqual(result["service_id"], "svc-123")
            self.assertEqual(result["status"], "BUILD_SUCCESS")
        finally:
            os.unlink(os.path.join(tmpdir, "Dockerfile"))
            os.rmdir(tmpdir)

    def test_invalid_service_name_raises(self):
        """Invalid service name raises MCPToolError before calling client."""
        tmpdir = self._create_valid_source()
        try:
            with self.assertRaises(MCPToolError):
                build_service_handler(self.mock_session, tmpdir, "INVALID_NAME")
            self.mock_session.client.build_service.assert_not_called()
        finally:
            os.unlink(os.path.join(tmpdir, "Dockerfile"))
            os.rmdir(tmpdir)

    def test_missing_dockerfile_raises(self):
        """Path without Dockerfile raises MCPToolError."""
        with tempfile.TemporaryDirectory() as tmpdir:
            with self.assertRaises(MCPToolError):
                build_service_handler(self.mock_session, tmpdir, "my-service")
            self.mock_session.client.build_service.assert_not_called()

    def test_invalid_gpu_count_raises(self):
        """GPU count out of range raises MCPToolError."""
        tmpdir = self._create_valid_source()
        try:
            with self.assertRaises(MCPToolError):
                build_service_handler(self.mock_session, tmpdir, "my-service", gpu_count=10)
            self.mock_session.client.build_service.assert_not_called()
        finally:
            os.unlink(os.path.join(tmpdir, "Dockerfile"))
            os.rmdir(tmpdir)

    def test_description_too_long_raises(self):
        """Description over 500 chars raises MCPToolError."""
        tmpdir = self._create_valid_source()
        try:
            with self.assertRaises(MCPToolError) as ctx:
                build_service_handler(
                    self.mock_session, tmpdir, "my-service", description="x" * 501
                )
            self.assertIn("500", str(ctx.exception))
        finally:
            os.unlink(os.path.join(tmpdir, "Dockerfile"))
            os.rmdir(tmpdir)

    def test_build_failure_returns_failed_status(self):
        """Build that returns build_success=False gets FAILED status."""
        self.mock_session.client.build_service.return_value = {
            "service_id": "",
            "build_success": False,
            "full_image": "",
        }
        tmpdir = self._create_valid_source()
        try:
            result = build_service_handler(self.mock_session, tmpdir, "my-service")
            self.assertEqual(result["status"], "BUILD_FAILED")
        finally:
            os.unlink(os.path.join(tmpdir, "Dockerfile"))
            os.rmdir(tmpdir)

    def test_client_exception_wrapped(self):
        """Client exception is wrapped as MCPToolError."""
        self.mock_session.client.build_service.side_effect = RuntimeError("Docker daemon error")
        tmpdir = self._create_valid_source()
        try:
            with self.assertRaises(MCPToolError) as ctx:
                build_service_handler(self.mock_session, tmpdir, "my-service")
            self.assertIn("Build failed", str(ctx.exception))
        finally:
            os.unlink(os.path.join(tmpdir, "Dockerfile"))
            os.rmdir(tmpdir)

    def test_gpu_count_passed_as_build_arg(self):
        """Non-zero GPU count is passed as extra_build_args."""
        tmpdir = self._create_valid_source()
        try:
            build_service_handler(self.mock_session, tmpdir, "gpu-service", gpu_count=2)
            call_kwargs = self.mock_session.client.build_service.call_args[1]
            self.assertEqual(call_kwargs["extra_build_args"]["GPU_COUNT"], "2")
        finally:
            os.unlink(os.path.join(tmpdir, "Dockerfile"))
            os.rmdir(tmpdir)


class TestListServicesHandler(unittest.TestCase):
    """Test blackant_list_services tool handler."""

    def setUp(self):
        """Set up mock session."""
        self.mock_session = MagicMock()

    def test_returns_list_from_client(self):
        """Handler returns the list directly from client."""
        expected = [{"name": "svc-1"}, {"name": "svc-2"}]
        self.mock_session.client.list_services.return_value = expected
        result = list_services_handler(self.mock_session)
        self.assertEqual(result, expected)

    def test_passes_namespace_to_client(self):
        """Namespace argument is forwarded to client."""
        self.mock_session.client.list_services.return_value = []
        list_services_handler(self.mock_session, namespace="research")
        self.mock_session.client.list_services.assert_called_once_with(namespace="research")

    def test_client_exception_wrapped(self):
        """Client exception is wrapped as MCPToolError."""
        self.mock_session.client.list_services.side_effect = ConnectionError("timeout")
        with self.assertRaises(MCPToolError):
            list_services_handler(self.mock_session)


class TestServiceStatusHandler(unittest.TestCase):
    """Test blackant_service_status tool handler."""

    def setUp(self):
        """Set up mock session."""
        self.mock_session = MagicMock()

    def test_returns_status_from_client(self):
        """Handler returns status dict from client."""
        expected = {"name": "my-svc", "status": "READY"}
        self.mock_session.client.get_service_status.return_value = expected
        result = service_status_handler(self.mock_session, "my-svc")
        self.assertEqual(result, expected)

    def test_passes_service_name(self):
        """Service name is forwarded to client."""
        self.mock_session.client.get_service_status.return_value = {}
        service_status_handler(self.mock_session, "test-service")
        self.mock_session.client.get_service_status.assert_called_once_with(
            service_name="test-service"
        )

    def test_client_exception_wrapped(self):
        """Client exception is wrapped as MCPToolError."""
        self.mock_session.client.get_service_status.side_effect = RuntimeError("not found")
        with self.assertRaises(MCPToolError):
            service_status_handler(self.mock_session, "missing-svc")


class TestGetServiceHandler(unittest.TestCase):
    """Test blackant_get_service tool handler."""

    def setUp(self):
        """Set up mock session."""
        self.mock_session = MagicMock()

    def test_returns_service_info(self):
        """Handler returns service info from client."""
        expected = {"name": "my-svc", "image": "env.blackant.app/test:latest"}
        self.mock_session.client.get_service.return_value = expected
        result = get_service_handler(self.mock_session, "my-svc")
        self.assertEqual(result, expected)

    def test_client_exception_wrapped(self):
        """Client exception is wrapped as MCPToolError."""
        self.mock_session.client.get_service.side_effect = RuntimeError("not found")
        with self.assertRaises(MCPToolError):
            get_service_handler(self.mock_session, "missing-svc")


class TestTestConnectionHandler(unittest.TestCase):
    """Test blackant_test_connection tool handler."""

    def setUp(self):
        """Set up mock session."""
        self.mock_session = MagicMock()

    def test_success_returns_connected(self):
        """Successful connection returns connected=True."""
        self.mock_session.client.test_connection.return_value = True
        result = check_connection_handler(self.mock_session)
        self.assertTrue(result["connected"])
        self.assertIn("operational", result["message"])

    def test_failure_returns_not_connected(self):
        """Failed connection returns connected=False."""
        self.mock_session.client.test_connection.return_value = False
        result = check_connection_handler(self.mock_session)
        self.assertFalse(result["connected"])

    def test_client_exception_wrapped(self):
        """Client exception is wrapped as MCPToolError."""
        self.mock_session.client.test_connection.side_effect = ConnectionError("refused")
        with self.assertRaises(MCPToolError):
            check_connection_handler(self.mock_session)


if __name__ == "__main__":
    unittest.main()
