"""Unit tests for Singleton pattern implementation."""

import unittest
import threading
from src.blackant.patterns.singleton import Singleton


class ExampleSingletonClass(metaclass=Singleton):
    """Example class using Singleton metaclass for testing."""

    def __init__(self):
        self.value = 0


class TestSingleton(unittest.TestCase):
    """Test cases for Singleton metaclass."""

    def test_singleton_instance(self):
        """Test that only one instance is created."""
        instance1 = ExampleSingletonClass()
        instance2 = ExampleSingletonClass()

        self.assertIs(instance1, instance2)

    def test_singleton_state_sharing(self):
        """Test that state is shared between references."""
        instance1 = ExampleSingletonClass()
        instance2 = ExampleSingletonClass()

        instance1.value = 42
        self.assertEqual(instance2.value, 42)

    def test_singleton_thread_safety(self):
        """Test that Singleton is thread-safe."""
        instances = []

        def create_instance():
            instances.append(ExampleSingletonClass())

        threads = []
        for _ in range(10):
            thread = threading.Thread(target=create_instance)
            threads.append(thread)
            thread.start()

        for thread in threads:
            thread.join()

        # All instances should be the same object
        for instance in instances:
            self.assertIs(instance, instances[0])


if __name__ == "__main__":
    unittest.main()
