#!/usr/bin/env python3
"""Unit tests for CalculationLoader - thread-safe dynamic calculation loading."""

import unittest
from unittest.mock import Mock, patch, MagicMock
import threading
import os

import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "..", "src"))

from calculation.loader import CalculationLoader
from calculation.base import CalculationBase
from calculation.impl.my_calculation import MyCalculation


class TestCalculationLoader(unittest.TestCase):
    """Test cases for CalculationLoader."""

    def setUp(self):
        """Set up test fixtures."""
        # Clear singleton instance for clean test
        CalculationLoader._instance = None

        # Clear environment variables
        os.environ.pop("CALCULATION_MODULE", None)
        os.environ.pop("CALCULATION_CLASS", None)

    def tearDown(self):
        """Clean up after each test."""
        # Reset singleton
        CalculationLoader._instance = None

        # Clear environment
        os.environ.pop("CALCULATION_MODULE", None)
        os.environ.pop("CALCULATION_CLASS", None)

    def test_singleton_pattern(self):
        """Test that CalculationLoader is a singleton."""
        loader1 = CalculationLoader()
        loader2 = CalculationLoader()

        # Verify same instance
        self.assertIs(loader1, loader2)

    def test_singleton_thread_safety(self):
        """Test singleton is thread-safe with concurrent access."""
        instances = []

        def create_loader():
            loader = CalculationLoader()
            instances.append(loader)

        # Create 10 threads trying to create loader simultaneously
        threads = []
        for _ in range(10):
            thread = threading.Thread(target=create_loader)
            threads.append(thread)
            thread.start()

        # Wait for all threads
        for thread in threads:
            thread.join()

        # Verify all instances are the same object
        self.assertEqual(len(instances), 10)
        for instance in instances:
            self.assertIs(instance, instances[0])

    def test_get_calculation_default_mycalculation(self):
        """Test get_calculation returns MyCalculation by default."""
        loader = CalculationLoader()
        CalcClass = loader.get_calculation()

        # Verify MyCalculation is returned
        self.assertEqual(CalcClass, MyCalculation)

        # Verify it's a CalculationBase subclass
        self.assertTrue(issubclass(CalcClass, CalculationBase))

    def test_get_calculation_with_environment_variables(self):
        """Test get_calculation with CALCULATION_MODULE and CALCULATION_CLASS env vars."""
        # Set environment variables
        os.environ["CALCULATION_MODULE"] = "calculation.impl.my_calculation"
        os.environ["CALCULATION_CLASS"] = "MyCalculation"

        loader = CalculationLoader()
        CalcClass = loader.get_calculation()

        # Verify correct class is loaded
        self.assertEqual(CalcClass, MyCalculation)

    def test_get_calculation_cache_hit(self):
        """Test that get_calculation uses cache on second call."""
        loader = CalculationLoader()

        # First call - should load and cache
        CalcClass1 = loader.get_calculation()

        # Mock _load_calculation to verify it's NOT called again
        with patch.object(loader, "_load_calculation") as mock_load:
            # Second call - should hit cache
            CalcClass2 = loader.get_calculation()

            # Verify _load_calculation was NOT called
            mock_load.assert_not_called()

            # Verify same class returned
            self.assertEqual(CalcClass1, CalcClass2)

    def test_cache_key_generation(self):
        """Test cache uses correct keys based on module + class name."""
        loader = CalculationLoader()

        # Load with default settings
        loader.get_calculation()

        # Verify cache has entry
        cache_info = loader.get_cache_info()
        self.assertEqual(cache_info["size"], 1)
        self.assertIn("calculation.impl.my_calculation.MyCalculation", cache_info["entries"])

    def test_load_calculation_valid_module(self):
        """Test _load_calculation loads valid calculation module."""
        loader = CalculationLoader()

        CalcClass = loader._load_calculation("calculation.impl.my_calculation", "MyCalculation")

        # Verify correct class loaded
        self.assertEqual(CalcClass, MyCalculation)

    def test_load_calculation_invalid_module(self):
        """Test _load_calculation raises ImportError for invalid module."""
        loader = CalculationLoader()

        with self.assertRaises(ImportError):
            loader._load_calculation("calculation.impl.nonexistent_module", "NonExistentClass")

    def test_load_calculation_invalid_class_name(self):
        """Test _load_calculation raises AttributeError for invalid class name."""
        loader = CalculationLoader()

        with self.assertRaises(AttributeError):
            loader._load_calculation("calculation.impl.my_calculation", "NonExistentClass")

    def test_load_calculation_not_a_class(self):
        """Test _load_calculation raises TypeError if attribute is not a class."""
        loader = CalculationLoader()

        # Try to load a function instead of a class
        with self.assertRaises(TypeError) as cm:
            loader._load_calculation(
                "calculation.impl.simple_calc", "calculate"  # This is a function, not a class
            )

        # Verify error message
        self.assertIn("is not a class", str(cm.exception))

    def test_load_calculation_not_calculationbase_subclass(self):
        """Test _load_calculation raises TypeError if class doesn't inherit CalculationBase."""
        loader = CalculationLoader()

        # Create a test module with non-CalculationBase class
        with patch("importlib.import_module") as mock_import:
            # Mock module with non-CalculationBase class
            mock_module = MagicMock()

            class NotACalculation:
                pass

            mock_module.NotACalculation = NotACalculation
            mock_import.return_value = mock_module

            with self.assertRaises(TypeError) as cm:
                loader._load_calculation("test.module", "NotACalculation")

            # Verify error message
            self.assertIn("must inherit from CalculationBase", str(cm.exception))

    def test_fallback_on_load_failure(self):
        """Test get_calculation falls back to MyCalculation on load failure."""
        os.environ["CALCULATION_MODULE"] = "nonexistent.module"
        os.environ["CALCULATION_CLASS"] = "NonExistent"

        loader = CalculationLoader()

        # Should fallback to MyCalculation instead of crashing
        CalcClass = loader.get_calculation()

        # Verify fallback to MyCalculation
        self.assertEqual(CalcClass, MyCalculation)

    def test_load_fallback_success(self):
        """Test _load_fallback returns MyCalculation."""
        loader = CalculationLoader()
        CalcClass = loader._load_fallback()

        # Verify MyCalculation returned
        self.assertEqual(CalcClass, MyCalculation)

    def test_load_fallback_caches_result(self):
        """Test _load_fallback caches MyCalculation."""
        loader = CalculationLoader()

        # Call _load_fallback
        loader._load_fallback()

        # Verify cache has MyCalculation
        cache_info = loader.get_cache_info()
        self.assertIn("calculation.impl.my_calculation.MyCalculation", cache_info["entries"])

    @unittest.skip(
        "Skipped: Direct import cannot be mocked - MyCalculation is always available if tests run"
    )
    def test_load_fallback_import_error(self):
        """Test _load_fallback raises ImportError if even MyCalculation can't be loaded.

        NOTE: This scenario is not realistically testable because _load_fallback() uses
        direct import (from ... import MyCalculation) which cannot be easily mocked.
        In production, if the app starts, MyCalculation is always available.
        """
        pass

    def test_clear_cache(self):
        """Test clear_cache removes all cached calculations."""
        loader = CalculationLoader()

        # Load calculation (populates cache)
        loader.get_calculation()

        # Verify cache is populated
        cache_info = loader.get_cache_info()
        self.assertGreater(cache_info["size"], 0)

        # Clear cache
        loader.clear_cache()

        # Verify cache is empty
        cache_info = loader.get_cache_info()
        self.assertEqual(cache_info["size"], 0)
        self.assertEqual(cache_info["entries"], [])

    def test_clear_cache_thread_safety(self):
        """Test clear_cache is thread-safe."""
        loader = CalculationLoader()

        # Populate cache
        loader.get_calculation()

        # Clear cache from multiple threads simultaneously
        threads = []
        for _ in range(5):
            thread = threading.Thread(target=loader.clear_cache)
            threads.append(thread)
            thread.start()

        # Wait for all threads
        for thread in threads:
            thread.join()

        # Verify cache is empty
        cache_info = loader.get_cache_info()
        self.assertEqual(cache_info["size"], 0)

    def test_get_cache_info_returns_correct_structure(self):
        """Test get_cache_info returns dict with size and entries."""
        loader = CalculationLoader()

        cache_info = loader.get_cache_info()

        # Verify structure
        self.assertIsInstance(cache_info, dict)
        self.assertIn("size", cache_info)
        self.assertIn("entries", cache_info)
        self.assertIsInstance(cache_info["size"], int)
        self.assertIsInstance(cache_info["entries"], list)

    def test_get_cache_info_reflects_cache_state(self):
        """Test get_cache_info reflects actual cache state."""
        loader = CalculationLoader()

        # Initial state
        cache_info = loader.get_cache_info()
        self.assertEqual(cache_info["size"], 0)

        # Load calculation
        loader.get_calculation()

        # Verify cache updated
        cache_info = loader.get_cache_info()
        self.assertEqual(cache_info["size"], 1)

    def test_concurrent_get_calculation_thread_safety(self):
        """Test multiple threads can safely call get_calculation simultaneously."""
        loader = CalculationLoader()
        results = []
        errors = []

        def get_calc():
            try:
                calc_class = loader.get_calculation()
                results.append(calc_class)
            except Exception as e:
                errors.append(e)

        # Create 20 threads calling get_calculation
        threads = []
        for _ in range(20):
            thread = threading.Thread(target=get_calc)
            threads.append(thread)
            thread.start()

        # Wait for all threads
        for thread in threads:
            thread.join()

        # Verify no errors occurred
        self.assertEqual(len(errors), 0, f"Errors occurred: {errors}")

        # Verify all results are the same class
        self.assertEqual(len(results), 20)
        for result in results:
            self.assertEqual(result, MyCalculation)

    def test_different_env_vars_different_cache_entries(self):
        """Test different environment variables create different cache entries."""
        loader = CalculationLoader()

        # Load with default settings
        os.environ["CALCULATION_MODULE"] = "calculation.impl.my_calculation"
        os.environ["CALCULATION_CLASS"] = "MyCalculation"
        loader.get_calculation()

        # Check cache
        cache_info = loader.get_cache_info()
        initial_size = cache_info["size"]

        # Note: Since we can't easily load a DIFFERENT calculation in this test,
        # we verify the cache key mechanism
        self.assertGreater(initial_size, 0)


if __name__ == "__main__":
    unittest.main(verbosity=2)
