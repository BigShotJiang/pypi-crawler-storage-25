"""Unit tests for cmdArgs parsing - verifies camelCase key handling.

The scheduler sends taskConfig with camelCase 'cmdArgs' key.
The SDK must parse this correctly (not snake_case 'cmd_args').

Bug fixed: cmd_args -> cmdArgs in RequestParser (request.py).
"""

import sys
import os
import unittest

# Add src to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "..", "src"))

from task.parsers.cmd_args import CommandLineArgumentParser
from task.parsers.request import TaskConfiguration
from task.parsers.callback import CallbackParameter


class TestCommandLineArgumentParser(unittest.TestCase):
    """Test CommandLineArgumentParser with camelCase 'cmdArgs' key."""

    def setUp(self):
        self.parser = CommandLineArgumentParser("cmdArgs")

    def test_parse_flat_dict(self):
        """cmdArgs as flat dict - the format confirmed by Milán."""
        request = {"cmdArgs": {"numbers": [1, 2, 3, 4, 5]}}
        result = self.parser.parse(request)
        self.assertEqual(result, {"numbers": [1, 2, 3, 4, 5]})

    def test_parse_missing_key_returns_empty(self):
        """Missing cmdArgs should return empty dict."""
        result = self.parser.parse({"other": "value"})
        self.assertEqual(result, {})

    def test_parse_none_request_returns_empty(self):
        """None request should return empty dict."""
        result = self.parser.parse(None)
        self.assertEqual(result, {})

    def test_parse_empty_request_returns_empty(self):
        """Empty dict request should return empty dict."""
        result = self.parser.parse({})
        self.assertEqual(result, {})

    def test_parse_string_value_literal_eval(self):
        """String value should be parsed via ast.literal_eval."""
        request = {"cmdArgs": "{'database': 'test_db'}"}
        result = self.parser.parse(request)
        self.assertEqual(result, {"database": "test_db"})

    def test_parse_complex_nested_dict(self):
        """Nested dict values should be preserved."""
        request = {"cmdArgs": {
            "database": "e2e_test",
            "collection": "patients",
            "filters": {"age_min": 18, "age_max": 65},
        }}
        result = self.parser.parse(request)
        self.assertEqual(result["database"], "e2e_test")
        self.assertEqual(result["filters"]["age_min"], 18)

    def test_snake_case_key_not_found(self):
        """Old snake_case 'cmd_args' key should NOT be found (regression test)."""
        old_parser = CommandLineArgumentParser("cmd_args")
        request = {"cmdArgs": {"numbers": [1, 2, 3]}}
        result = old_parser.parse(request)
        self.assertEqual(result, {}, "Snake-case parser should NOT find camelCase key")

    def test_camel_case_key_found(self):
        """CamelCase 'cmdArgs' key must be found (the fix)."""
        request = {"cmdArgs": {"numbers": [1, 2, 3]}}
        result = self.parser.parse(request)
        self.assertEqual(result, {"numbers": [1, 2, 3]})


class TestTaskConfigurationJson(unittest.TestCase):
    """Test TaskConfiguration.json property uses correct key names."""

    def test_json_uses_camelcase_cmdargs(self):
        """TaskConfiguration.json must use 'cmdArgs' (camelCase), not 'cmd_args'."""
        config = TaskConfiguration(
            callback=CallbackParameter(url="", method="GET", headers={}, request_body={}),
            cmd_args={"numbers": [1, 2, 3]},
            objects=[],
            input="",
        )
        json_output = config.json
        self.assertIn("cmdArgs", json_output, "JSON should use camelCase 'cmdArgs'")
        self.assertNotIn("cmd_args", json_output, "JSON should NOT use snake_case 'cmd_args'")
        self.assertEqual(json_output["cmdArgs"], {"numbers": [1, 2, 3]})


if __name__ == "__main__":
    unittest.main()
