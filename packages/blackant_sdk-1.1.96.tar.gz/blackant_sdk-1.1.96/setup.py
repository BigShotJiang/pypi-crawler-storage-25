#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
BlackAnt SDK Setup
A Python SDK for Docker operations with automatic authentication through BlackAnt platform.

Modern setup using pyproject.toml for configuration.
This file is kept for backward compatibility.
"""

from setuptools import setup

# All configuration is in pyproject.toml
# This minimal setup.py is kept for compatibility with older pip versions
setup()
