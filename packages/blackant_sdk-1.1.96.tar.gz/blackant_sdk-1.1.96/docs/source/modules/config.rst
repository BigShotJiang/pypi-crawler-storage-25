Configuration Module
====================

The BlackAnt configuration module provides a flexible, hierarchical configuration
management system supporting multiple sources and formats. It enables environment-specific
configuration with validation, defaults, and runtime modification capabilities.

Features include:

* Multi-source configuration loading (YAML, environment variables, command-line arguments)
* Hierarchical configuration with inheritance and overrides
* Runtime configuration validation and type checking
* Environment-specific configuration profiles
* Secure credential management and encryption
* Configuration change detection and hot-reloading
* Schema validation and documentation generation

Configuration Manager
----------------------

Central configuration orchestration with source prioritization and merging logic.

.. automodule:: blackant.config.manager
   :members:
   :undoc-members:
   :show-inheritance:

Default Values
--------------

System-wide default configuration values and fallback mechanisms.

.. automodule:: blackant.config.defaults
   :members:
   :undoc-members:
   :show-inheritance:

Configuration Validation
-------------------------

Schema validation, type checking, and configuration integrity verification.

.. automodule:: blackant.config.validator
   :members:
   :undoc-members:
   :show-inheritance:

Configuration Loaders
----------------------

Pluggable configuration loading system supporting multiple formats and sources.

YAML Loader
~~~~~~~~~~~

YAML file configuration loading with schema validation.

.. automodule:: blackant.config.loaders.yaml
   :members:
   :undoc-members:
   :show-inheritance:

Environment Loader
~~~~~~~~~~~~~~~~~~

Environment variable configuration extraction with prefix support.

.. automodule:: blackant.config.loaders.environment
   :members:
   :undoc-members:
   :show-inheritance:

Arguments Loader
~~~~~~~~~~~~~~~~

Command-line argument parsing and configuration injection.

.. automodule:: blackant.config.loaders.arguments
   :members:
   :undoc-members:
   :show-inheritance: