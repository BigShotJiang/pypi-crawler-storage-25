Authentication Module
=====================

The BlackAnt authentication module provides secure, enterprise-grade authentication
capabilities using Keycloak OpenID Connect integration. It handles token lifecycle
management, automatic refresh, and secure credential storage.

Features include:

* OAuth 2.0 / OpenID Connect integration with Keycloak
* Automatic token refresh and lifecycle management
* Thread-safe token storage with concurrent access support
* Admin API access for user management operations
* Comprehensive error handling and logging
* Development and production environment support

Core Authentication
--------------------

Primary authentication interface for username/password login and token management.

.. automodule:: blackant.auth.blackant_auth
   :members:
   :undoc-members:
   :show-inheritance:

Token Management
----------------

Thread-safe token storage and lifecycle management.

.. automodule:: blackant.auth.tokens
   :members:
   :undoc-members:
   :show-inheritance:

Keycloak Integration
--------------------

Low-level Keycloak API integration for advanced authentication scenarios.

.. automodule:: blackant.auth.keycloak
   :members:
   :undoc-members:
   :show-inheritance:

Authentication Manager
----------------------

High-level authentication orchestration and policy management.

.. automodule:: blackant.auth.manager
   :members:
   :undoc-members:
   :show-inheritance:

Scope Management
----------------

OAuth 2.0 scope and permission management utilities.

.. automodule:: blackant.auth.scopes
   :members:
   :undoc-members:
   :show-inheritance:

Request ID Tracking
-------------------

Request correlation and audit trail management for authentication operations.

.. automodule:: blackant.auth.request_id
   :members:
   :undoc-members:
   :show-inheritance: