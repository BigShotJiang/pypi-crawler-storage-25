HTTP Module
===========

This module provides a high-performance HTTP client with advanced features including
connection pooling, automatic retry mechanisms, comprehensive error handling, and
authentication integration.

The HTTP module is designed for production use with enterprise-grade reliability,
supporting both synchronous and asynchronous operations with built-in monitoring
and logging capabilities.

Client
------

The main HTTP client provides a clean, intuitive API for making HTTP requests
with automatic authentication token injection and response processing.

.. automodule:: blackant.http.client
   :members:
   :undoc-members:
   :show-inheritance:
   :special-members: __init__

Session Management
------------------

Advanced session management with connection pooling and persistent connections.

.. automodule:: blackant.http.session
   :members:
   :undoc-members:
   :show-inheritance:

Authentication
--------------

HTTP authentication middleware with automatic token refresh and error handling.

.. automodule:: blackant.http.auth
   :members:
   :undoc-members:
   :show-inheritance:

Retry Logic
-----------

Intelligent retry mechanisms with exponential backoff and circuit breaker patterns.

.. automodule:: blackant.http.retry
   :members:
   :undoc-members:
   :show-inheritance:

Middleware
----------

Extensible middleware system for request/response processing.

.. automodule:: blackant.http.middleware
   :members:
   :undoc-members:
   :show-inheritance: