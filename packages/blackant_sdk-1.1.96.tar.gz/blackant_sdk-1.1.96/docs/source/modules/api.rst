API Module
==========

The BlackAnt API module provides a comprehensive REST API client with automatic
versioning, endpoint discovery, and response processing. It offers both high-level
convenience methods and low-level API access for maximum flexibility.

Features include:

* Automatic API versioning and endpoint resolution
* Type-safe request/response handling with validation
* Comprehensive error handling and retry logic
* Built-in authentication and authorization
* Request/response interceptors and middleware support
* Real-time API monitoring and performance metrics
* OpenAPI specification integration and validation

API Client
----------

High-level API client with automatic authentication and error handling.

.. automodule:: blackant.api.client
   :members:
   :undoc-members:
   :show-inheritance:

Endpoint Management
-------------------

Dynamic endpoint discovery and URL construction with versioning support.

.. automodule:: blackant.api.endpoints
   :members:
   :undoc-members:
   :show-inheritance:

API Versioning
--------------

Automatic API version detection and compatibility management.

.. automodule:: blackant.api.versioning
   :members:
   :undoc-members:
   :show-inheritance:

API Exceptions
--------------

Specialized exception handling for API-specific error conditions.

.. automodule:: blackant.api.exceptions
   :members:
   :undoc-members:
   :show-inheritance: