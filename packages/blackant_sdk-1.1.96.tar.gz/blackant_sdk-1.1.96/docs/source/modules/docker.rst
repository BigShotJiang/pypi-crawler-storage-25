Docker Module
=============

The BlackAnt Docker module provides comprehensive Docker integration capabilities
for container management, image operations, and Docker Swarm orchestration.
It offers both high-level convenience methods and low-level Docker API access.

Features include:

* Full Docker Engine API integration
* Docker Swarm mode support for distributed deployments
* Container lifecycle management (create, start, stop, remove)
* Image building, pulling, and registry operations
* Volume and network management
* Real-time container monitoring and logging
* Service discovery and health checking

Docker Client
-------------

Primary interface for Docker operations with connection management and error handling.

.. automodule:: blackant.docker.client
   :members:
   :undoc-members:
   :show-inheritance:

Data Access Layer
-----------------

Low-level Docker API access with connection pooling and retry logic.

.. automodule:: blackant.docker.dao
   :members:
   :undoc-members:
   :show-inheritance:

Registry Operations
-------------------

Docker registry integration for image push/pull operations and authentication.

.. automodule:: blackant.docker.registry
   :members:
   :undoc-members:
   :show-inheritance:

Image Builder
-------------

Advanced image building capabilities with custom build contexts and optimization.

.. automodule:: blackant.docker.builder
   :members:
   :undoc-members:
   :show-inheritance:

Container Context
-----------------

Context management for container operations and environment setup.

.. automodule:: blackant.docker.context
   :members:
   :undoc-members:
   :show-inheritance:

Remote Operations
-----------------

Remote Docker daemon connectivity and distributed operations support.

.. automodule:: blackant.docker.remote
   :members:
   :undoc-members:
   :show-inheritance:

Metadata Management
-------------------

Container and image metadata extraction and management utilities.

.. automodule:: blackant.docker.metadata
   :members:
   :undoc-members:
   :show-inheritance: