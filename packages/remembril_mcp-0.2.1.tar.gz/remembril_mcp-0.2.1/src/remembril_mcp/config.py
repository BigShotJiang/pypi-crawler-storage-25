"""Configuration management for Remembril MCP server."""

import json
import os
from pathlib import Path
from typing import Optional
from pydantic import BaseModel


class Config(BaseModel):
    """Remembril MCP configuration."""
    
    api_url: str = "https://remembril-production.up.railway.app"
    token: Optional[str] = None
    default_project_id: Optional[str] = None
    
    @classmethod
    def config_dir(cls) -> Path:
        """Get the config directory path."""
        return Path.home() / ".remembril"
    
    @classmethod
    def config_file(cls) -> Path:
        """Get the config file path."""
        return cls.config_dir() / "config.json"
    
    @classmethod
    def load(cls) -> "Config":
        """Load config from file and environment."""
        config_data = {}
        
        # Load from file if exists
        config_file = cls.config_file()
        if config_file.exists():
            try:
                with open(config_file) as f:
                    config_data = json.load(f)
            except (json.JSONDecodeError, IOError):
                pass
        
        # Environment overrides
        if api_url := os.environ.get("REMEMBRIL_URL"):
            config_data["api_url"] = api_url
        
        if token := os.environ.get("REMEMBRIL_TOKEN"):
            config_data["token"] = token
        
        if project_id := os.environ.get("REMEMBRIL_PROJECT_ID"):
            config_data["default_project_id"] = project_id
        
        return cls(**config_data)
    
    def save(self) -> None:
        """Save config to file."""
        config_dir = self.config_dir()
        config_dir.mkdir(parents=True, exist_ok=True)
        
        # Set secure permissions
        config_file = self.config_file()
        
        with open(config_file, "w") as f:
            json.dump(self.model_dump(exclude_none=True), f, indent=2)
        
        # Set file permissions to 600 (owner read/write only)
        os.chmod(config_file, 0o600)
    
    @property
    def is_authenticated(self) -> bool:
        """Check if we have a token."""
        return self.token is not None
