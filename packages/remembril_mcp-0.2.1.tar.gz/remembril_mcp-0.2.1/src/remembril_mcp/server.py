"""MCP Server implementation for Remembril.

Provides 53 tools for change impact tracking, ripple review, document management,
pipeline automation, design generation, cross-document traceability, agent reviews,
pull-based agent work loop, assistant-mode workflows, and Graphify bridge
(safishamsi/graphify compatibility).

Supports 3 output tiers:
  1. MCP Apps (HTML widgets in iframe) - Claude Desktop, ChatGPT
  2. A2UI (declarative JSON) - Google Gemini
  3. Plain text fallback - Claude Code, any MCP client
"""

import json
from pathlib import Path
from typing import Any, Optional
from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import (
    Tool,
    TextContent,
    CallToolResult,
)

from .client import RembrilClient, RembrilError
from .config import Config
from .formatters.ripple_fmt import format_ripple_queue, format_ripple_diff
from .formatters.trace_fmt import format_traceability_matrix
from .formatters.pipeline_fmt import format_pipeline_status
from .formatters.a2ui import (
    build_a2ui_ripple_review,
    build_a2ui_traceability,
    build_a2ui_pipeline_dashboard,
    build_a2ui_design_preview,
    build_a2ui_agent_review,
    build_a2ui_watcher_alerts,
)
from .formatters.review_fmt import (
    format_review_detail,
    format_review_list,
    format_debate_detail,
    format_watcher_alerts,
    format_personas,
)
from .formatters.loop_fmt import format_loop_status
from .formatters.assistant_fmt import (
    format_assist_narrative,
    format_context_narrative,
    format_workflow_status,
    group_by_type,
    generate_suggestions,
    determine_workflow_phase,
)

# Widget bundle directory
WIDGETS_DIR = Path(__file__).parent / "widgets"


def _load_widget(widget_name: str) -> str:
    """Load an HTML widget bundle from the widgets directory."""
    widget_path = WIDGETS_DIR / widget_name / "index.html"
    if widget_path.exists():
        return widget_path.read_text()
    return ""


# Complexity scoring heuristics (Zeroshot-inspired)
COMPLEXITY_KEYWORDS = {
    "high": ["architecture", "security", "migration", "refactor", "breaking",
             "authentication", "encryption", "database", "schema", "performance"],
    "medium": ["feature", "api", "integration", "update", "enhance", "add"],
    "low": ["fix", "typo", "style", "format", "docs", "comment", "minor"]
}


def _calculate_complexity(title: str, description: str = "") -> tuple[str, str]:
    """Calculate issue complexity based on content analysis."""
    text = f"{title} {description}".lower()
    for keyword in COMPLEXITY_KEYWORDS["high"]:
        if keyword in text:
            return ("high", f"Contains high-complexity indicator: '{keyword}'")
    for keyword in COMPLEXITY_KEYWORDS["medium"]:
        if keyword in text:
            return ("medium", f"Contains standard change indicator: '{keyword}'")
    for keyword in COMPLEXITY_KEYWORDS["low"]:
        if keyword in text:
            return ("low", f"Contains simple change indicator: '{keyword}'")
    return ("medium", "No specific complexity indicators found")


def _make_result(data: Any, text: str = "", widget: str = "", a2ui: dict = None) -> CallToolResult:
    """Build a CallToolResult with 3-tier output support.

    Tier 1 - MCP Apps: structuredContent (JSON) + _meta.ui.resourceUri (widget hint)
    Tier 2 - A2UI:    structuredContent.a2ui (declarative JSON for Google/Gemini)
    Tier 3 - Text:    content (markdown for CLI / plain-text hosts)
    """
    narration = text or json.dumps(data, indent=2, default=str)

    structured = data if isinstance(data, dict) else {"data": data}
    if a2ui:
        structured["a2ui"] = a2ui

    meta = None
    if widget:
        meta = {"ui": {"resourceUri": f"ui://remembril/{widget}"}}

    kwargs: dict[str, Any] = {
        "content": [TextContent(type="text", text=narration)],
        "structuredContent": structured,
    }
    if meta:
        kwargs["_meta"] = meta

    return CallToolResult(**kwargs)


def create_server(config: Optional[Config] = None) -> Server:
    """Create and configure the MCP server."""

    config = config or Config.load()
    client = RembrilClient(config)
    server = Server("remembril")

    @server.list_tools()
    async def list_tools() -> list[Tool]:
        """List available Remembril tools."""
        return [
            # --- Issue Management ---
            Tool(
                name="remembril_issue_create",
                description="Create a new issue for tracking changes or features",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "title": {"type": "string", "description": "Issue title"},
                        "description": {"type": "string", "description": "Detailed description"},
                        "severity": {"type": "string", "enum": ["low", "medium", "high", "critical"]},
                        "project_id": {"type": "string", "description": "Project ID (uses default if not provided)"}
                    },
                    "required": ["title"]
                }
            ),
            Tool(
                name="remembril_issue_create_smart",
                description="Create an issue with automatic complexity/severity scoring based on content analysis.",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "title": {"type": "string", "description": "Issue title"},
                        "description": {"type": "string", "description": "Detailed description"},
                        "project_id": {"type": "string", "description": "Project ID (uses default if not provided)"}
                    },
                    "required": ["title"]
                }
            ),
            Tool(
                name="remembril_issue_list",
                description="List issues with optional filters",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "status": {"type": "string", "enum": ["open", "in_progress", "closed"]},
                        "severity": {"type": "string", "enum": ["low", "medium", "high", "critical"]},
                        "project_id": {"type": "string", "description": "Filter by project"}
                    }
                }
            ),

            # --- Ripple Review (has widget) ---
            Tool(
                name="remembril_ripples_generate",
                description="Generate ripple effects showing what documents need updates for an issue",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "issue_id": {"type": "integer", "description": "Database ID of the issue"}
                    },
                    "required": ["issue_id"]
                }
            ),
            Tool(
                name="remembril_ripples_queue",
                description="Show pending ripple effects for interactive review. Use when you need to review document changes.",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "project_id": {"type": "string", "description": "Filter by project"},
                        "risk_level": {"type": "string", "enum": ["low", "medium", "high", "critical"]},
                        "issue_id": {"type": "integer", "description": "Filter by issue ID"}
                    }
                }
            ),
            Tool(
                name="remembril_ripple_approve",
                description="Approve a ripple effect",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "ripple_id": {"type": "integer", "description": "ID of the ripple to approve"}
                    },
                    "required": ["ripple_id"]
                }
            ),
            Tool(
                name="remembril_ripple_reject",
                description="Reject a ripple effect with a reason. Helps improve future generation.",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "ripple_id": {"type": "integer", "description": "ID of the ripple to reject"},
                        "reason": {"type": "string", "description": "Explanation for rejection"}
                    },
                    "required": ["ripple_id", "reason"]
                }
            ),
            Tool(
                name="remembril_ripple_update",
                description="Modify a ripple's changes before approving. Use when directionally correct but needs refinement.",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "ripple_id": {"type": "integer", "description": "ID of the ripple to update"},
                        "suggested_changes": {"type": "string", "description": "Updated changes to apply"},
                        "reviewer_notes": {"type": "string", "description": "What was adjusted and why"}
                    },
                    "required": ["ripple_id", "suggested_changes"]
                }
            ),
            Tool(
                name="remembril_ripple_apply",
                description="Apply an approved ripple to update documents",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "ripple_id": {"type": "integer", "description": "ID of the ripple to apply"}
                    },
                    "required": ["ripple_id"]
                }
            ),
            Tool(
                name="remembril_ripple_diff",
                description="Show the before/after diff for a ripple's proposed changes",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "ripple_id": {"type": "integer", "description": "ID of the ripple to diff"}
                    },
                    "required": ["ripple_id"]
                }
            ),
            Tool(
                name="remembril_ripple_blind_review",
                description="Get ripples for blind validation (AI reasoning hidden). Reviewer must independently determine validity.",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "issue_id": {"type": "integer", "description": "Issue ID to get ripples for"}
                    },
                    "required": ["issue_id"]
                }
            ),

            # --- Pipeline (has widget) ---
            Tool(
                name="remembril_pipeline_run",
                description="Run the full auto-pipeline for a project. Processes issues, generates ripples, applies changes to documents.",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "project_id": {"type": "string", "description": "Project ID"},
                        "mode": {"type": "string", "enum": ["manual", "semi_auto", "full_auto"], "description": "Pipeline mode (default: project settings)"},
                        "output_path": {"type": "string", "description": "Export path for markdown output"}
                    },
                    "required": ["project_id"]
                }
            ),
            Tool(
                name="remembril_pipeline_status",
                description="Get pipeline run status and pending work summary for a project",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "project_id": {"type": "string", "description": "Project ID"}
                    },
                    "required": ["project_id"]
                }
            ),
            Tool(
                name="remembril_pipeline_generate_docs",
                description="Export all project documents to markdown files",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "project_id": {"type": "string", "description": "Project ID"},
                        "output_path": {"type": "string", "description": "Export directory path"}
                    },
                    "required": ["project_id"]
                }
            ),

            # --- Documents ---
            Tool(
                name="remembril_docs",
                description="List documents for a project",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "project_id": {"type": "string", "description": "Project ID (uses default if not provided)"}
                    }
                }
            ),
            Tool(
                name="remembril_doc_read",
                description="Read a single document by ID with full content",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "doc_id": {"type": "string", "description": "Document ID"}
                    },
                    "required": ["doc_id"]
                }
            ),
            Tool(
                name="remembril_doc_traceability",
                description="Show cross-document traceability matrix. Use to see which requirements are covered across PRFAQ, HLD, LLD, Tests, Compliance, and Runbook docs.",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "project_id": {"type": "string", "description": "Project ID"}
                    },
                    "required": ["project_id"]
                }
            ),

            # --- Design Mode (has widget) ---
            Tool(
                name="remembril_design_create_project",
                description="Create a new design project for UI component generation",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "name": {"type": "string", "description": "Project name"},
                        "description": {"type": "string", "description": "Project description"},
                        "platform": {"type": "string", "description": "Target platform (web, ios, android)"}
                    },
                    "required": ["name"]
                }
            ),
            Tool(
                name="remembril_design_chat",
                description="Edit a document using natural language chat. Send instructions and AI updates the document.",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "doc_id": {"type": "string", "description": "Document ID to edit"},
                        "message": {"type": "string", "description": "What changes to make"}
                    },
                    "required": ["doc_id", "message"]
                }
            ),
            Tool(
                name="remembril_design_generate",
                description="Generate a new document using AI. Creates full content based on doc type and description.",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "doc_type": {"type": "string", "enum": ["requirements", "prfaq", "hld", "lld", "tests", "compliance", "runbook", "project"]},
                        "title": {"type": "string", "description": "Document title"},
                        "description": {"type": "string", "description": "What the document should contain"},
                        "project_id": {"type": "string", "description": "Project ID"},
                        "feature_id": {"type": "string", "description": "Feature ID (optional)"}
                    },
                    "required": ["doc_type", "title", "description"]
                }
            ),

            # --- Code Analysis ---
            Tool(
                name="remembril_scan",
                description="Scan and index a codebase for symbol tracking and impact analysis",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "path": {"type": "string", "description": "Path to the repository to scan"}
                    },
                    "required": ["path"]
                }
            ),
            Tool(
                name="remembril_impact",
                description="Analyze what would be affected by changes to a file",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "file_path": {"type": "string", "description": "Path to the file to analyze"},
                        "project_id": {"type": "string", "description": "Project ID (uses default if not provided)"}
                    },
                    "required": ["file_path"]
                }
            ),
            Tool(
                name="remembril_trace",
                description="Trace a requirement to its code implementations",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "requirement_id": {"type": "string", "description": "Requirement ID (e.g., REQ-AUTH-001)"}
                    },
                    "required": ["requirement_id"]
                }
            ),
            Tool(
                name="remembril_symbols",
                description="Search indexed code symbols",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "query": {"type": "string", "description": "Search query for symbols"},
                        "project_id": {"type": "string", "description": "Project ID (uses default if not provided)"}
                    },
                    "required": ["query"]
                }
            ),

            # --- Project Management ---
            Tool(
                name="remembril_projects",
                description="List all projects",
                inputSchema={"type": "object", "properties": {}}
            ),
            Tool(
                name="remembril_project_create",
                description="Create a new Remembril project. Returns the project ID needed for all other operations.",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "name": {"type": "string", "description": "Project name"},
                        "description": {"type": "string", "description": "Project description"},
                    },
                    "required": ["name"]
                }
            ),
            Tool(
                name="remembril_project_configure",
                description="Configure pipeline settings for a project: repo path, test command, agent review, coding loop, and automation mode. Use this after creating a project to set up the local repo for coding agents.",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "project_id": {"type": "string", "description": "Project ID"},
                        "repo_path": {"type": "string", "description": "Absolute path to local git repo"},
                        "test_command": {"type": "string", "description": "Command to run tests (e.g. 'pytest tests/ -x', 'npm test')"},
                        "test_timeout": {"type": "integer", "description": "Test timeout in seconds (default 300)"},
                        "mode": {"type": "string", "enum": ["manual", "semi_auto", "full_auto"], "description": "Pipeline mode (default full_auto)"},
                        "agent_review_enabled": {"type": "boolean", "description": "Enable Auror committee review"},
                        "agent_review_committee_size": {"type": "integer", "description": "Committee size 1-7 (default 3)"},
                        "loop_enabled": {"type": "boolean", "description": "Enable autonomous coding loop"},
                        "loop_max_iterations": {"type": "integer", "description": "Max iterations per loop (default 15)"},
                        "loop_max_depth": {"type": "integer", "description": "Max depth of fix waves (default 3)"},
                        "loop_timeout_per_task": {"type": "integer", "description": "Per-task timeout in seconds (default 600)"},
                    },
                    "required": ["project_id"]
                }
            ),
            Tool(
                name="remembril_project_settings",
                description="Get current pipeline settings for a project.",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "project_id": {"type": "string", "description": "Project ID"},
                    },
                    "required": ["project_id"]
                }
            ),

            # --- Orchestration ---
            Tool(
                name="remembril_orchestrate_status",
                description="Check pending work for autonomous coding. Returns counts of pending ripples and issues.",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "project_id": {"type": "string", "description": "Project ID (optional)"}
                    }
                }
            ),
            Tool(
                name="remembril_orchestrate_start",
                description="Start an autonomous coding session.",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "project_id": {"type": "string", "description": "Project ID"},
                        "mode": {"type": "string", "enum": ["sequential", "parallel", "continuous"]},
                        "max_iterations": {"type": "integer", "description": "Max tasks to process (default: 10)"},
                        "max_parallel": {"type": "integer", "description": "Max parallel workers (default: 3)"}
                    },
                    "required": ["project_id"]
                }
            ),
            Tool(
                name="remembril_orchestrate_next",
                description="Get the next task from an orchestration session.",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "session_id": {"type": "string", "description": "Session ID"},
                        "worker_id": {"type": "string", "description": "Worker identifier"}
                    },
                    "required": ["session_id"]
                }
            ),
            Tool(
                name="remembril_orchestrate_complete",
                description="Mark a task as complete in an orchestration session.",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "session_id": {"type": "string", "description": "Session ID"},
                        "ripple_id": {"type": "integer", "description": "Ripple ID completed"},
                        "success": {"type": "boolean", "description": "Whether task succeeded"},
                        "error": {"type": "string", "description": "Error message if failed"}
                    },
                    "required": ["session_id", "ripple_id"]
                }
            ),
            Tool(
                name="remembril_orchestrate_sessions",
                description="List orchestration sessions.",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "project_id": {"type": "string"},
                        "status": {"type": "string", "enum": ["pending", "running", "paused", "completed", "failed"]}
                    }
                }
            ),
            Tool(
                name="remembril_orchestrate_generate_all",
                description="Generate ripples for all open issues in a project.",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "project_id": {"type": "string", "description": "Project ID"}
                    },
                    "required": ["project_id"]
                }
            ),

            # --- Agent Reviews (has widget) ---
            Tool(
                name="remembril_review_run",
                description="Start a multi-agent adversarial review. Agents independently analyze content and produce a joint recommendation with ripples.",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "project_id": {"type": "string", "description": "Project ID"},
                        "committee_size": {"type": "integer", "description": "Number of agents (default 5, max 7)"},
                        "content": {"type": "string", "description": "Content to review (document text, PR diff, etc.)"},
                        "context": {"type": "string", "description": "Additional context for reviewers"},
                        "persona_ids": {"type": "array", "items": {"type": "string"}, "description": "Specific persona IDs to use"},
                        "trigger_type": {"type": "string", "enum": ["manual", "issue", "pr", "document"], "description": "What triggered the review"}
                    },
                    "required": ["project_id"]
                }
            ),
            Tool(
                name="remembril_review_status",
                description="Get full review details including individual agent advisements, joint recommendation, and extracted ripples.",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "review_id": {"type": "string", "description": "Review ID"}
                    },
                    "required": ["review_id"]
                }
            ),
            Tool(
                name="remembril_review_list",
                description="List agent reviews with optional filters by project and status.",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "project_id": {"type": "string", "description": "Filter by project"},
                        "status": {"type": "string", "enum": ["pending", "running", "completed", "failed"], "description": "Filter by status"},
                        "limit": {"type": "integer", "description": "Max results (default 20)"}
                    }
                }
            ),
            Tool(
                name="remembril_review_approve_ripples",
                description="Approve ripples extracted from an agent review.",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "review_id": {"type": "string", "description": "Review ID"},
                        "ripple_ids": {"type": "array", "items": {"type": "integer"}, "description": "Specific ripple IDs (default: all from review)"}
                    },
                    "required": ["review_id"]
                }
            ),
            Tool(
                name="remembril_debate_create",
                description="Start an adversarial debate between agents on a topic. Agents argue in rounds toward consensus.",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "project_id": {"type": "string", "description": "Project ID"},
                        "topic": {"type": "string", "description": "The debate topic or question"},
                        "rounds": {"type": "integer", "description": "Number of debate rounds (default 3)"},
                        "agent_ids": {"type": "array", "items": {"type": "string"}, "description": "Persona IDs for debaters"}
                    },
                    "required": ["project_id", "topic"]
                }
            ),
            Tool(
                name="remembril_debate_status",
                description="Get debate details including messages, round progress, and consensus status.",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "debate_id": {"type": "string", "description": "Debate ID"}
                    },
                    "required": ["debate_id"]
                }
            ),
            Tool(
                name="remembril_watcher_alerts",
                description="List watcher anomaly alerts from agent reviews. Detects convergence, rare agreements, and independent discoveries.",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "review_id": {"type": "string", "description": "Filter by review"},
                        "project_id": {"type": "string", "description": "Filter by project"},
                        "severity": {"type": "string", "enum": ["info", "warning", "critical"], "description": "Filter by severity"},
                        "handled": {"type": "boolean", "description": "Filter by handled status"}
                    }
                }
            ),
            Tool(
                name="remembril_alert_handle",
                description="Mark a watcher alert as handled.",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "alert_id": {"type": "string", "description": "Alert ID"},
                        "handled": {"type": "boolean", "description": "Set handled status (default true)"}
                    },
                    "required": ["alert_id"]
                }
            ),
            Tool(
                name="remembril_personas_list",
                description="List available agent personas for reviews and debates.",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "type": {"type": "string", "enum": ["advocate", "adversary", "outsider", "ghost"], "description": "Filter by agent type"}
                    }
                }
            ),

            # --- Autonomous Coding Loop ---
            Tool(
                name="remembril_loop_start",
                description="Start an autonomous coding loop. Picks up pending ripples, invokes Claude Code to implement changes, runs Agent Review on diffs, and loops on review findings.",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "project_id": {"type": "string", "description": "Project ID"},
                        "max_iterations": {"type": "integer", "description": "Max total iterations (default 15)", "default": 15},
                        "max_depth": {"type": "integer", "description": "Max review-code-review recursion depth (default 3)", "default": 3},
                        "timeout_per_task": {"type": "integer", "description": "Timeout per Claude invocation in seconds (default 600)", "default": 600},
                        "issue_ids": {"type": "array", "items": {"type": "integer"}, "description": "Specific issue IDs to work on (optional)"},
                        "committee_size": {"type": "integer", "description": "Agent review committee size (default 3)", "default": 3},
                        "working_dir": {"type": "string", "description": "Working directory for Claude Code (optional)"},
                    },
                    "required": ["project_id"]
                }
            ),
            Tool(
                name="remembril_loop_status",
                description="Get the status of an autonomous coding loop session including progress, waves, and droplets.",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "storm_id": {"type": "integer", "description": "Storm ID (loop session ID)"}
                    },
                    "required": ["storm_id"]
                }
            ),
            Tool(
                name="remembril_loop_stop",
                description="Gracefully stop a running coding loop. Current task will finish before stopping.",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "storm_id": {"type": "integer", "description": "Storm ID to stop"},
                        "reason": {"type": "string", "description": "Reason for stopping", "default": "manual_stop"}
                    },
                    "required": ["storm_id"]
                }
            ),
            # --- Agent Work Loop (pull-based) ---
            Tool(
                name="remembril_loop_next_task",
                description="Pull the next available coding task. Returns full task context including requirements, work breakdown, and branch info. Call this at the start of your work session to get your assignment.",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "storm_id": {"type": "integer", "description": "Specific loop session to pull from (optional)"},
                        "project_id": {"type": "string", "description": "Filter by project (optional)"}
                    }
                }
            ),
            Tool(
                name="remembril_loop_claim_task",
                description="Claim a task you received from next_task. This reserves it so no other agent works on it. Call immediately after getting a task.",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "droplet_id": {"type": "integer", "description": "ID of the droplet to claim"},
                        "agent_id": {"type": "string", "description": "Your agent identifier (optional)"}
                    },
                    "required": ["droplet_id"]
                }
            ),
            Tool(
                name="remembril_loop_checkpoint",
                description="Save progress on your current task. Call periodically to keep the session alive and enable resume if interrupted.",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "droplet_id": {"type": "integer", "description": "ID of the droplet"},
                        "progress_percent": {"type": "integer", "description": "Progress 0-100", "minimum": 0, "maximum": 100},
                        "completed_steps": {"type": "array", "items": {"type": "string"}, "description": "Steps completed so far"},
                        "remaining_steps": {"type": "array", "items": {"type": "string"}, "description": "Steps remaining"},
                        "summary": {"type": "string", "description": "Brief summary of progress"},
                        "files_changed": {"type": "array", "items": {"type": "string"}, "description": "Files modified so far"}
                    },
                    "required": ["droplet_id"]
                }
            ),
            Tool(
                name="remembril_loop_complete_task",
                description="Mark your task as complete. Call when you have finished implementing and testing the changes. Include a summary and list of files changed.",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "droplet_id": {"type": "integer", "description": "ID of the droplet"},
                        "success": {"type": "boolean", "description": "Whether the task succeeded"},
                        "summary": {"type": "string", "description": "What was accomplished"},
                        "files_changed": {"type": "array", "items": {"type": "string"}, "description": "Files that were modified"},
                        "diff": {"type": "string", "description": "Git diff of changes (optional)"},
                        "commit_sha": {"type": "string", "description": "Commit SHA if committed (optional)"},
                        "error": {"type": "string", "description": "Error message if failed"}
                    },
                    "required": ["droplet_id", "success"]
                }
            ),

            # --- Agent Task Context ---
            Tool(
                name="remembril_get_task_context",
                description="Get full design context for a coding task. Returns the relevant requirements, HLD/LLD sections, test plan, and traceability links for the issue being implemented. Use this at the start of a task to understand what you're building and why.",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "project_id": {"type": "string", "description": "Project ID"},
                        "issue_id": {"type": "string", "description": "Issue ID being implemented"},
                        "doc_types": {
                            "type": "array",
                            "items": {"type": "string"},
                            "description": "Document types to include (default: all). Options: requirements, hld, lld, tests, prfaq",
                            "default": ["requirements", "hld", "lld", "tests"]
                        }
                    },
                    "required": ["project_id"]
                }
            ),

            # --- Assistant Mode ---
            Tool(
                name="remembril_assist",
                description=(
                    "Run a full Remembril workflow from a natural-language request. "
                    "Chains: issue creation -> ripple generation -> pipeline run -> optional coding loop. "
                    "Use this when the user describes a change, bug, or feature and you want to "
                    "track it through the full impact-analysis pipeline automatically."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "intent": {
                            "type": "string",
                            "description": "What the user wants to do (e.g. 'Fix the signup bug', 'Add dark mode')"
                        },
                        "description": {
                            "type": "string",
                            "description": "Additional context about the change"
                        },
                        "severity": {
                            "type": "string",
                            "enum": ["low", "medium", "high", "critical"],
                            "description": "Override auto-calculated severity"
                        },
                        "project_id": {
                            "type": "string",
                            "description": "Project ID (uses default if not provided)"
                        },
                        "steps": {
                            "type": "array",
                            "items": {
                                "type": "string",
                                "enum": ["issue", "ripples", "pipeline", "loop"]
                            },
                            "description": "Which steps to run (default: issue, ripples, pipeline). Add 'loop' to start coding loop."
                        },
                    },
                    "required": ["intent"]
                }
            ),
            Tool(
                name="remembril_context",
                description=(
                    "Get full situational awareness for the current project. "
                    "Returns: project info, open issues, pending ripples, document status, "
                    "and suggested next actions. "
                    "Call this at the start of a session or when you need to understand the project state."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "project_id": {
                            "type": "string",
                            "description": "Project ID (uses default if not provided)"
                        },
                        "include": {
                            "type": "array",
                            "items": {
                                "type": "string",
                                "enum": ["issues", "ripples", "documents", "settings", "suggestions"]
                            },
                            "description": "What to include (default: all)"
                        }
                    }
                }
            ),
            Tool(
                name="remembril_workflow_status",
                description=(
                    "Check the status of an in-flight workflow. "
                    "Given an issue ID, shows: issue status, ripple statuses, "
                    "affected documents, and coding loop progress. "
                    "Use this to follow up on a previously started workflow."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "issue_id": {
                            "type": "integer",
                            "description": "Issue ID to check workflow status for"
                        },
                        "project_id": {
                            "type": "string",
                            "description": "Project ID (uses default if not provided)"
                        }
                    },
                    "required": ["issue_id"]
                }
            ),

            # --- Graphify bridge (safishamsi/graphify compatibility) ---
            Tool(
                name="remembril_graphify_import",
                description=(
                    "Import a Graphify (graphifyy) graph.json payload and map "
                    "it to Remembril's knowledge-graph node/edge model. Accepts "
                    "either an inline `graph` dict or a server-side "
                    "`graph_json_path`. Returns the raw snapshot plus the "
                    "mapped Remembril view."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "graph": {
                            "type": "object",
                            "description": "Graphify graph.json payload (node-link format)"
                        },
                        "graph_json_path": {
                            "type": "string",
                            "description": "Alternative: server-side path to a graph.json file"
                        },
                        "project_id": {
                            "type": "string",
                            "description": "Project ID (uses default if not provided)"
                        }
                    }
                }
            ),
            Tool(
                name="remembril_graphify_diff",
                description=(
                    "Diff two Graphify snapshots (old vs new) and emit "
                    "issue-shaped ripple payloads for added/removed nodes and "
                    "edges. Use this to turn Graphify's structural changes "
                    "into Remembril ripples."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "old_graph": {
                            "type": "object",
                            "description": "Previous Graphify graph.json payload"
                        },
                        "new_graph": {
                            "type": "object",
                            "description": "Current Graphify graph.json payload"
                        },
                        "generate_ripples": {
                            "type": "boolean",
                            "description": "Include issue-shaped ripple payloads in the response",
                            "default": True
                        },
                        "project_id": {
                            "type": "string",
                            "description": "Project ID (uses default if not provided)"
                        }
                    },
                    "required": ["old_graph", "new_graph"]
                }
            ),
            Tool(
                name="remembril_graphify_sync",
                description=(
                    "Rebuild a Graphify knowledge graph for a project "
                    "directory and diff it against the previous snapshot. "
                    "Requires `graphifyy` to be installed on the backend."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "project_dir": {
                            "type": "string",
                            "description": "Absolute path to the project working directory"
                        },
                        "out_dir": {
                            "type": "string",
                            "description": "Output directory for graph.json",
                            "default": "graphify-out"
                        },
                        "previous_graph_path": {
                            "type": "string",
                            "description": "Optional previous graph.json to diff against"
                        },
                        "project_id": {
                            "type": "string",
                            "description": "Project ID (uses default if not provided)"
                        }
                    },
                    "required": ["project_dir"]
                }
            ),
        ]

    @server.call_tool()
    async def call_tool(name: str, arguments: dict[str, Any]) -> CallToolResult:
        """Handle tool calls."""
        try:
            return await _handle_tool(client, name, arguments)
        except RembrilError as e:
            return CallToolResult(
                content=[TextContent(type="text", text=f"Error: {e}")],
                isError=True
            )
        except Exception as e:
            return CallToolResult(
                content=[TextContent(type="text", text=f"Unexpected error: {e}")],
                isError=True
            )

    return server


async def _handle_tool(client: RembrilClient, name: str, args: dict[str, Any]) -> CallToolResult:
    """Route tool calls to the appropriate client method.

    Returns CallToolResult with formatted text for plain-text hosts.
    Tools with widgets include structured data that MCP Apps can consume.
    """

    # --- Issue Management ---
    if name == "remembril_issue_create":
        result = await client.create_issue(
            title=args["title"],
            description=args.get("description"),
            severity=args.get("severity", "medium"),
            project_id=args.get("project_id")
        )
        return _make_result(result)

    elif name == "remembril_issue_create_smart":
        title = args["title"]
        description = args.get("description", "")
        severity, reason = _calculate_complexity(title, description)
        result = await client.create_issue(
            title=title, description=description,
            severity=severity, project_id=args.get("project_id")
        )
        result["complexity_analysis"] = {"auto_severity": severity, "reason": reason}
        return _make_result(result)

    elif name == "remembril_issue_list":
        result = await client.list_issues(
            status=args.get("status"), severity=args.get("severity"),
            project_id=args.get("project_id")
        )
        return _make_result(result)

    # --- Ripple Review (widget: ripple-review) ---
    elif name == "remembril_ripples_generate":
        result = await client.generate_ripples(args["issue_id"])
        return _make_result(result)

    elif name == "remembril_ripples_queue":
        ripples = await client.get_pending_ripples(
            project_id=args.get("project_id"),
            risk_level=args.get("risk_level")
        )
        # Use issue_id filter if provided
        if args.get("issue_id"):
            ripples = await client.get_ripple_queue(args["issue_id"])

        text = format_ripple_queue(ripples if isinstance(ripples, list) else ripples.get("ripples", []))
        ripple_list = ripples if isinstance(ripples, list) else ripples.get("ripples", [])
        return _make_result(
            {"ripples": ripple_list, "pending_count": len(ripple_list)},
            text=text,
            widget="ripple-review",
            a2ui=build_a2ui_ripple_review(ripple_list)
        )

    elif name == "remembril_ripple_approve":
        result = await client.approve_ripple(args["ripple_id"])
        return _make_result(result, text=f"Ripple #{args['ripple_id']} approved.")

    elif name == "remembril_ripple_reject":
        result = await client.reject_ripple(args["ripple_id"], args["reason"])
        return _make_result(result, text=f"Ripple #{args['ripple_id']} rejected: {args['reason']}")

    elif name == "remembril_ripple_update":
        result = await client.update_ripple(
            args["ripple_id"], args["suggested_changes"],
            args.get("reviewer_notes")
        )
        return _make_result(result, text=f"Ripple #{args['ripple_id']} updated.")

    elif name == "remembril_ripple_apply":
        result = await client.apply_ripple(args["ripple_id"])
        return _make_result(result, text=f"Ripple #{args['ripple_id']} applied to document.")

    elif name == "remembril_ripple_diff":
        ripple = await client.get_ripple(args["ripple_id"])
        text = format_ripple_diff(ripple)
        return _make_result(ripple, text=text, widget="ripple-review")

    elif name == "remembril_ripple_blind_review":
        ripples = await client.get_ripple_queue(args["issue_id"])
        blind_ripples = []
        for r in ripples:
            if r.get("status") == "pending":
                blind_ripples.append({
                    "id": r.get("id"),
                    "target_doc": r.get("target_doc"),
                    "change_type": r.get("change_type"),
                    "blind_validation": True
                })
        result = {"mode": "blind_validation", "ripples": blind_ripples}
        return _make_result(result)

    # --- Pipeline (widget: pipeline-dashboard) ---
    elif name == "remembril_pipeline_run":
        result = await client.run_pipeline(
            project_id=args["project_id"],
            mode=args.get("mode"),
            output_path=args.get("output_path")
        )
        text = format_pipeline_status(result)
        return _make_result(
            result, text=text,
            a2ui=build_a2ui_pipeline_dashboard(result)
        )

    elif name == "remembril_pipeline_status":
        result = await client.pipeline_status(args["project_id"])
        text = format_pipeline_status(result)
        return _make_result(
            result, text=text,
            a2ui=build_a2ui_pipeline_dashboard(result)
        )

    elif name == "remembril_pipeline_generate_docs":
        result = await client.generate_docs(
            project_id=args["project_id"],
            output_path=args.get("output_path")
        )
        return _make_result(result)

    # --- Documents (traceability has widget) ---
    elif name == "remembril_docs":
        result = await client.list_documents(args.get("project_id"))
        return _make_result(result)

    elif name == "remembril_doc_read":
        result = await client.get_document(args["doc_id"])
        return _make_result(result)

    elif name == "remembril_doc_traceability":
        result = await client.get_traceability(args["project_id"])
        text = format_traceability_matrix(result)
        return _make_result(
            result, text=text,
            widget="traceability",
            a2ui=build_a2ui_traceability(result)
        )

    # --- Design Mode (widget: design-preview) ---
    elif name == "remembril_design_create_project":
        result = await client.create_design_project(
            name=args["name"],
            description=args.get("description"),
            platform=args.get("platform")
        )
        return _make_result(result)

    elif name == "remembril_design_chat":
        result = await client.design_chat(
            doc_id=args["doc_id"],
            message=args["message"]
        )
        text = result.get("summary", "Document updated.")
        if result.get("questions"):
            text += "\n\nQuestions:\n" + "\n".join(f"- {q}" for q in result["questions"])
        return _make_result(
            result, text=text,
            widget="design-preview",
            a2ui=build_a2ui_design_preview(result)
        )

    elif name == "remembril_design_generate":
        result = await client.design_generate(
            doc_type=args["doc_type"],
            title=args["title"],
            description=args["description"],
            project_id=args.get("project_id"),
            feature_id=args.get("feature_id")
        )
        text = f"Generated {args['doc_type']} document: {args['title']}"
        if result.get("summary"):
            text += f"\n{result['summary']}"
        return _make_result(
            result, text=text,
            widget="design-preview",
            a2ui=build_a2ui_design_preview(result)
        )

    # --- Code Analysis ---
    elif name == "remembril_scan":
        result = await client.scan_codebase(args["path"])
        return _make_result(result)

    elif name == "remembril_impact":
        result = await client.analyze_impact(
            file_path=args["file_path"],
            project_id=args.get("project_id")
        )
        return _make_result(result)

    elif name == "remembril_trace":
        result = await client.trace_requirement(args["requirement_id"])
        return _make_result(result)

    elif name == "remembril_symbols":
        result = await client.search_symbols(
            query=args["query"],
            project_id=args.get("project_id")
        )
        return _make_result(result)

    # --- Project Management ---
    elif name == "remembril_projects":
        result = await client.list_projects()
        return _make_result(result)

    elif name == "remembril_project_create":
        result = await client.create_design_project(
            name=args["name"],
            description=args.get("description"),
        )
        text = f"Project created: {result.get('name')} (id: {result.get('id')})"
        return _make_result(result, text=text)

    elif name == "remembril_project_configure":
        pid = args.pop("project_id")
        result = await client.update_pipeline_settings(pid, **args)
        parts = [f"Pipeline settings updated for project {pid}:"]
        if result.get("repo_path"):
            parts.append(f"  Repo: {result['repo_path']}")
        if result.get("test_command"):
            parts.append(f"  Test: {result['test_command']}")
        parts.append(f"  Mode: {result.get('mode', 'full_auto')}")
        parts.append(f"  Agent review: {'enabled' if result.get('agent_review_enabled') else 'disabled'}")
        parts.append(f"  Coding loop: {'enabled' if result.get('loop_enabled') else 'disabled'}")
        return _make_result(result, text="\n".join(parts))

    elif name == "remembril_project_settings":
        result = await client.get_pipeline_settings(args["project_id"])
        parts = [f"Pipeline settings for {args['project_id']}:"]
        parts.append(f"  Mode: {result.get('mode', 'full_auto')}")
        parts.append(f"  Repo: {result.get('repo_path') or '(not set)'}")
        parts.append(f"  Test command: {result.get('test_command') or '(not set)'}")
        parts.append(f"  Agent review: {'enabled' if result.get('agent_review_enabled') else 'disabled'} (committee: {result.get('agent_review_committee_size', 3)})")
        parts.append(f"  Coding loop: {'enabled' if result.get('loop_enabled') else 'disabled'} (max_iter: {result.get('loop_max_iterations', 15)}, max_depth: {result.get('loop_max_depth', 3)})")
        return _make_result(result, text="\n".join(parts))

    # --- Orchestration ---
    elif name == "remembril_orchestrate_status":
        result = await client.get_pending_work(args.get("project_id"))
        return _make_result(result)

    elif name == "remembril_orchestrate_start":
        result = await client.create_orchestration_session(
            project_id=args["project_id"],
            mode=args.get("mode", "sequential"),
            max_iterations=args.get("max_iterations", 10),
            max_parallel=args.get("max_parallel", 3),
            issue_ids=args.get("issue_ids")
        )
        return _make_result(result)

    elif name == "remembril_orchestrate_next":
        result = await client.get_next_task(
            session_id=args["session_id"],
            worker_id=args.get("worker_id")
        )
        return _make_result(result)

    elif name == "remembril_orchestrate_complete":
        result = await client.complete_task(
            session_id=args["session_id"],
            ripple_id=args["ripple_id"],
            success=args.get("success", True),
            error=args.get("error")
        )
        return _make_result(result)

    elif name == "remembril_orchestrate_sessions":
        result = await client.list_orchestration_sessions(
            project_id=args.get("project_id"),
            status=args.get("status")
        )
        return _make_result(result)

    elif name == "remembril_orchestrate_generate_all":
        result = await client.generate_all_ripples(args["project_id"])
        return _make_result(result)

    # --- Agent Reviews (widget: agent-review) ---
    elif name == "remembril_review_run":
        result = await client.run_review(
            project_id=args["project_id"],
            committee_size=args.get("committee_size", 5),
            content=args.get("content"),
            context=args.get("context"),
            persona_ids=args.get("persona_ids"),
            trigger_type=args.get("trigger_type", "manual"),
        )
        text = f"Review started: {result.get('id', '?')} (status: {result.get('status', 'pending')})"
        return _make_result(result, text=text)

    elif name == "remembril_review_status":
        result = await client.get_review(args["review_id"])
        text = format_review_detail(result)
        return _make_result(
            result, text=text,
            widget="agent-review",
            a2ui=build_a2ui_agent_review(result)
        )

    elif name == "remembril_review_list":
        result = await client.list_reviews(
            project_id=args.get("project_id"),
            status=args.get("status"),
            limit=args.get("limit", 20),
        )
        text = format_review_list(result)
        return _make_result(result, text=text)

    elif name == "remembril_review_approve_ripples":
        result = await client.approve_review_ripples(
            review_id=args["review_id"],
            ripple_ids=args.get("ripple_ids"),
        )
        approved = result.get("approved", 0)
        total = result.get("total", 0)
        return _make_result(result, text=f"Approved {approved}/{total} ripples from review.")

    elif name == "remembril_debate_create":
        result = await client.create_debate(
            project_id=args["project_id"],
            topic=args["topic"],
            rounds=args.get("rounds", 3),
            agent_ids=args.get("agent_ids"),
        )
        text = f"Debate started: {result.get('id', '?')} (topic: {args['topic']})"
        return _make_result(result, text=text)

    elif name == "remembril_debate_status":
        result = await client.get_debate(args["debate_id"])
        text = format_debate_detail(result)
        return _make_result(result, text=text, widget="agent-review")

    elif name == "remembril_watcher_alerts":
        result = await client.list_watcher_alerts(
            review_id=args.get("review_id"),
            project_id=args.get("project_id"),
            severity=args.get("severity"),
            handled=args.get("handled"),
        )
        text = format_watcher_alerts(result)
        return _make_result(
            result, text=text,
            widget="agent-review",
            a2ui=build_a2ui_watcher_alerts(result)
        )

    elif name == "remembril_alert_handle":
        result = await client.handle_alert(
            alert_id=args["alert_id"],
            handled=args.get("handled", True),
        )
        return _make_result(result, text=f"Alert {args['alert_id']} marked as handled.")

    elif name == "remembril_personas_list":
        result = await client.list_personas(agent_type=args.get("type"))
        text = format_personas(result)
        return _make_result(result, text=text)

    # --- Autonomous Coding Loop ---
    elif name == "remembril_loop_start":
        result = await client.loop_start(
            project_id=args["project_id"],
            max_iterations=args.get("max_iterations", 15),
            max_depth=args.get("max_depth", 3),
            timeout_per_task=args.get("timeout_per_task", 600),
            issue_ids=args.get("issue_ids"),
            committee_size=args.get("committee_size", 3),
            working_dir=args.get("working_dir"),
        )
        text = (
            f"Loop started: Storm {result.get('storm_key', '?')} "
            f"(id={result.get('storm_id', '?')})\n"
            f"{result.get('message', '')}"
        )
        return _make_result(result, text=text)

    elif name == "remembril_loop_status":
        result = await client.loop_status(storm_id=args["storm_id"])
        text = format_loop_status(result)
        return _make_result(result, text=text)

    elif name == "remembril_loop_stop":
        result = await client.loop_stop(
            storm_id=args["storm_id"],
            reason=args.get("reason", "manual_stop"),
        )
        text = f"Loop stop requested: {result.get('message', 'Stop signal sent')}"
        return _make_result(result, text=text)

    # --- Agent Work Loop (pull-based) ---
    elif name == "remembril_loop_next_task":
        result = await client.loop_next_task(
            storm_id=args.get("storm_id"),
            project_id=args.get("project_id"),
        )
        text = (
            f"## Next Task: {result.get('droplet_key', '?')}\n"
            f"**{result.get('title', 'Untitled')}**\n\n"
        )
        if result.get("objective"):
            text += f"**Objective**: {result['objective']}\n\n"
        if result.get("context", {}).get("prompt"):
            text += f"**Instructions**:\n{result['context']['prompt']}\n\n"
        if result.get("work_breakdown"):
            wb = result["work_breakdown"]
            if wb.get("title"):
                text += f"**Sub-task**: {wb['title']}\n"
            if wb.get("method"):
                text += f"**Decomposition**: {wb['method']}\n"
        if result.get("branch"):
            text += f"\n**Branch**: `{result['branch']}`\n"
        return _make_result(result, text=text)

    elif name == "remembril_loop_claim_task":
        result = await client.loop_claim_task(
            droplet_id=args["droplet_id"],
            agent_id=args.get("agent_id"),
        )
        text = f"Task {result.get('droplet_key', '?')} claimed. You may begin work."
        return _make_result(result, text=text)

    elif name == "remembril_loop_checkpoint":
        result = await client.loop_checkpoint_task(
            droplet_id=args["droplet_id"],
            progress_percent=args.get("progress_percent", 0),
            completed_steps=args.get("completed_steps"),
            remaining_steps=args.get("remaining_steps"),
            summary=args.get("summary"),
            files_changed=args.get("files_changed"),
        )
        text = (
            f"Checkpoint saved for {result.get('droplet_key', '?')} "
            f"({result.get('progress_percent', 0)}% complete, "
            f"checkpoint #{result.get('checkpoint_count', 0)})"
        )
        return _make_result(result, text=text)

    elif name == "remembril_loop_complete_task":
        result = await client.loop_complete_task(
            droplet_id=args["droplet_id"],
            success=args["success"],
            summary=args.get("summary"),
            files_changed=args.get("files_changed"),
            diff=args.get("diff"),
            commit_sha=args.get("commit_sha"),
            error=args.get("error"),
        )
        status = "completed" if result.get("success") else "failed"
        text = f"Task {result.get('droplet_key', '?')} marked as {status}."
        return _make_result(result, text=text)

    elif name == "remembril_get_task_context":
        project_id = args["project_id"]
        issue_id = args.get("issue_id")
        doc_types = args.get("doc_types", ["requirements", "hld", "lld", "tests"])

        # Fetch all relevant documents for this project
        context_parts = []

        for doc_type in doc_types:
            try:
                docs = await client.list_documents(project_id=project_id, doc_type=doc_type)
                if docs:
                    for doc in docs[:3]:  # Limit to 3 per type
                        doc_detail = await client.get_document(doc["id"])
                        content = doc_detail.get("content", {})
                        context_parts.append(
                            f"## {doc_type.upper()}: {doc_detail.get('title', doc['id'])}\n"
                            f"```json\n{json.dumps(content, indent=2, default=str)[:4000]}\n```"
                        )
            except RembrilError:
                context_parts.append(f"## {doc_type.upper()}: (not available)")

        # Fetch traceability if available
        try:
            trace = await client.get_traceability(project_id=project_id)
            if trace:
                trace_text = format_traceability_matrix(trace)
                context_parts.append(f"## TRACEABILITY\n{trace_text[:2000]}")
        except RembrilError:
            pass

        # If specific issue, fetch its ripples
        if issue_id:
            try:
                ripples = await client.get_pending_ripples(project_id=project_id)
                issue_ripples = [r for r in (ripples or []) if r.get("issue_id") == issue_id]
                if issue_ripples:
                    context_parts.append(
                        f"## RELATED RIPPLES ({len(issue_ripples)})\n"
                        + "\n".join(
                            f"- {r.get('ripple_key', '?')}: {r.get('title', '?')} [{r.get('status', '?')}]"
                            for r in issue_ripples[:10]
                        )
                    )
            except RembrilError:
                pass

        text = "\n\n".join(context_parts) if context_parts else "No design context available for this project."
        return CallToolResult(content=[TextContent(type="text", text=text)])

    # --- Assistant Mode handlers ---

    elif name == "remembril_assist":
        intent = args["intent"]
        description = args.get("description", "")
        project_id = args.get("project_id") or client.config.default_project_id
        requested_steps = args.get("steps", ["issue", "ripples", "pipeline"])

        results: dict[str, Any] = {
            "steps_completed": [],
            "steps_skipped": [],
            "errors": [],
        }

        # Auto-calculate severity if not provided
        severity = args.get("severity")
        if not severity:
            severity, reason = _calculate_complexity(intent, description)
            results["auto_severity"] = {"level": severity, "reason": reason}

        # Step 1: Create issue
        issue_id = None
        if "issue" in requested_steps:
            try:
                issue = await client.create_issue(
                    title=intent,
                    description=description or f"Auto-created: {intent}",
                    severity=severity,
                    project_id=project_id,
                )
                issue_id = issue.get("id")
                results["issue"] = {
                    "id": issue_id,
                    "key": issue.get("issue_key"),
                }
                results["steps_completed"].append("issue")
            except RembrilError as e:
                results["errors"].append(f"Issue creation failed: {e}")

        # Step 2: Generate ripples
        if "ripples" in requested_steps and issue_id:
            try:
                ripples = await client.generate_ripples(issue_id)
                ripple_list = ripples.get("ripples", [])
                results["ripples"] = {
                    "count": len(ripple_list),
                    "by_type": group_by_type(ripple_list),
                }
                results["steps_completed"].append("ripples")
            except RembrilError as e:
                results["errors"].append(f"Ripple generation failed: {e}")

        # Step 3: Run pipeline
        if "pipeline" in requested_steps and project_id:
            try:
                pipeline_result = await client.run_pipeline(project_id=project_id)
                results["pipeline"] = {
                    "status": pipeline_result.get("status"),
                    "ripples_applied": pipeline_result.get("ripples_applied", 0),
                    "documents_updated": pipeline_result.get("documents_updated", 0),
                }
                results["steps_completed"].append("pipeline")
            except RembrilError as e:
                results["errors"].append(f"Pipeline failed: {e}")

        # Step 4: Start coding loop (optional)
        if "loop" in requested_steps and project_id:
            try:
                loop_result = await client.loop_start(
                    project_id=project_id,
                    issue_ids=[issue_id] if issue_id else None,
                )
                results["loop"] = {
                    "storm_id": loop_result.get("storm_id"),
                    "storm_key": loop_result.get("storm_key"),
                }
                results["steps_completed"].append("loop")
            except RembrilError as e:
                results["errors"].append(f"Loop start failed: {e}")

        text = format_assist_narrative(results, intent)
        return _make_result(results, text=text)

    elif name == "remembril_context":
        project_id = args.get("project_id") or client.config.default_project_id
        include = set(
            args.get("include", ["issues", "ripples", "documents", "settings", "suggestions"])
        )

        context: dict[str, Any] = {"project_id": project_id}

        if "issues" in include:
            try:
                issues_list = await client.list_issues(project_id=project_id)
                open_issues = [
                    i for i in issues_list if i.get("status") == "open"
                ]
                context["issues"] = {
                    "total": len(issues_list),
                    "open": len(open_issues),
                    "recent": open_issues[:5],
                }
            except RembrilError:
                context["issues"] = {"error": "Could not fetch issues"}

        if "ripples" in include:
            try:
                pending_work = await client.get_pending_work(project_id=project_id)
                context["ripples"] = pending_work
            except RembrilError:
                context["ripples"] = {"error": "Could not fetch pending work"}

        if "documents" in include:
            try:
                docs = await client.list_documents(project_id=project_id)
                context["documents"] = {
                    "total": len(docs),
                    "by_type": group_by_type(docs, "doc_type"),
                    "list": [
                        {
                            "id": d["id"],
                            "type": d.get("doc_type"),
                            "title": d.get("title"),
                        }
                        for d in docs[:20]
                    ],
                }
            except RembrilError:
                context["documents"] = {"error": "Could not fetch documents"}

        if "settings" in include and project_id:
            try:
                settings = await client.get_pipeline_settings(project_id)
                context["settings"] = settings
            except RembrilError:
                context["settings"] = {"error": "Could not fetch settings"}

        if "suggestions" in include:
            context["suggestions"] = generate_suggestions(context)

        text = format_context_narrative(context)
        return _make_result(context, text=text)

    elif name == "remembril_workflow_status":
        issue_id = args["issue_id"]

        # Get issue details
        issue_data = await client.get_issue(str(issue_id))

        # Get ripples for this issue
        ripples_list = await client.get_ripple_queue(issue_id)

        pending = [r for r in ripples_list if r.get("status") == "pending"]
        approved = [r for r in ripples_list if r.get("status") == "approved"]
        applied = [r for r in ripples_list if r.get("status") == "applied"]
        rejected = [r for r in ripples_list if r.get("status") == "rejected"]

        result = {
            "issue": {
                "id": issue_data.get("id"),
                "key": issue_data.get("issue_key"),
                "title": issue_data.get("title"),
                "status": issue_data.get("status"),
                "phase": issue_data.get("phase"),
            },
            "ripples": {
                "total": len(ripples_list),
                "pending": len(pending),
                "approved": len(approved),
                "applied": len(applied),
                "rejected": len(rejected),
                "details": ripples_list[:10],
            },
            "workflow_phase": determine_workflow_phase(issue_data, ripples_list),
        }

        text = format_workflow_status(result)
        return _make_result(result, text=text)

    # --- Graphify bridge ---
    elif name == "remembril_graphify_import":
        if args.get("graph_json_path"):
            result = await client.graphify_import_from_path(
                graph_json_path=args["graph_json_path"],
                project_id=args.get("project_id"),
            )
        elif args.get("graph"):
            result = await client.graphify_import(
                graph=args["graph"],
                project_id=args.get("project_id"),
            )
        else:
            raise RembrilError("Either 'graph' or 'graph_json_path' is required")
        stats = result.get("snapshot", {}).get("stats", {})
        text = (
            f"Imported Graphify graph: "
            f"{stats.get('node_count', 0)} nodes, "
            f"{stats.get('edge_count', 0)} edges, "
            f"{stats.get('hyperedge_count', 0)} hyperedges."
        )
        return _make_result(result, text=text)

    elif name == "remembril_graphify_diff":
        result = await client.graphify_diff(
            old_graph=args["old_graph"],
            new_graph=args["new_graph"],
            project_id=args.get("project_id"),
            generate_ripples=args.get("generate_ripples", True),
        )
        summary = result.get("summary", {})
        ripple_count = len(result.get("ripple_payloads", []))
        text = (
            f"Graphify diff: +{summary.get('added_nodes', 0)}/"
            f"-{summary.get('removed_nodes', 0)} nodes, "
            f"+{summary.get('added_edges', 0)}/"
            f"-{summary.get('removed_edges', 0)} edges. "
            f"{ripple_count} ripple payload(s) generated."
        )
        return _make_result(result, text=text)

    elif name == "remembril_graphify_sync":
        result = await client.graphify_sync(
            project_dir=args["project_dir"],
            out_dir=args.get("out_dir", "graphify-out"),
            previous_graph_path=args.get("previous_graph_path"),
            project_id=args.get("project_id"),
        )
        summary = result.get("summary", {})
        text = (
            f"Graphify sync complete. graph.json → {result.get('graph_json_path')}. "
            f"Diff: +{summary.get('added_nodes', 0)}/"
            f"-{summary.get('removed_nodes', 0)} nodes, "
            f"+{summary.get('added_edges', 0)}/"
            f"-{summary.get('removed_edges', 0)} edges."
        )
        return _make_result(result, text=text)

    else:
        raise RembrilError(f"Unknown tool: {name}")


async def run_server(config: Optional[Config] = None) -> None:
    """Run the MCP server."""
    server = create_server(config)
    async with stdio_server() as (read_stream, write_stream):
        await server.run(read_stream, write_stream, server.create_initialization_options())
