"""HTTP client for Remembril API."""

import httpx
from typing import Any, Optional
from .config import Config


class RembrilError(Exception):
    """Base exception for Remembril API errors."""
    
    def __init__(self, message: str, status_code: Optional[int] = None):
        super().__init__(message)
        self.status_code = status_code


class RembrilClient:
    """Async HTTP client for Remembril API."""
    
    def __init__(self, config: Optional[Config] = None):
        self.config = config or Config.load()
        self._client: Optional[httpx.AsyncClient] = None
    
    @property
    def client(self) -> httpx.AsyncClient:
        """Get or create the HTTP client."""
        if self._client is None:
            headers = {"Content-Type": "application/json"}
            if self.config.token:
                headers["Authorization"] = f"Bearer {self.config.token}"
            
            self._client = httpx.AsyncClient(
                base_url=self.config.api_url,
                headers=headers,
                timeout=30.0
            )
        return self._client
    
    async def close(self) -> None:
        """Close the HTTP client."""
        if self._client:
            await self._client.aclose()
            self._client = None
    
    async def _request(self, method: str, path: str, **kwargs) -> dict[str, Any]:
        """Make an API request."""
        response = await self.client.request(method, path, **kwargs)
        
        if response.status_code >= 400:
            try:
                error_data = response.json()
                message = error_data.get("detail", response.text)
            except Exception:
                message = response.text
            raise RembrilError(message, response.status_code)
        
        if response.status_code == 204:
            return {}
        
        return response.json()
    
    # Auth
    async def get_me(self) -> dict[str, Any]:
        """Get current user info."""
        return await self._request("GET", "/api/v1/auth/me")
    
    # Projects
    async def list_projects(self) -> list[dict[str, Any]]:
        """List all projects."""
        return await self._request("GET", "/api/v1/design/projects")
    
    # Issues
    async def create_issue(
        self,
        title: str,
        description: Optional[str] = None,
        severity: str = "medium",
        source_type: str = "feature_request",
        project_id: Optional[str] = None
    ) -> dict[str, Any]:
        """Create a new issue."""
        project_id = project_id or self.config.default_project_id
        if not project_id:
            raise RembrilError("project_id is required")
        
        return await self._request(
            "POST",
            "/api/v1/qa/issues",
            json={
                "title": title,
                "description": description,
                "severity": severity,
                "source_type": source_type,
                "project_id": project_id
            }
        )
    
    async def list_issues(
        self,
        status: Optional[str] = None,
        severity: Optional[str] = None,
        project_id: Optional[str] = None
    ) -> list[dict[str, Any]]:
        """List issues with optional filters."""
        params = {}
        if status:
            params["status"] = status
        if severity:
            params["severity"] = severity
        if project_id:
            params["project_id"] = project_id
        
        return await self._request("GET", "/api/v1/qa/issues", params=params)
    
    async def get_issue(self, issue_id: str) -> dict[str, Any]:
        """Get issue details."""
        return await self._request("GET", f"/api/v1/qa/issues/{issue_id}")
    
    # Ripples
    async def generate_ripples(self, issue_id: int) -> dict[str, Any]:
        """Generate ripple effects for an issue."""
        return await self._request("POST", f"/api/v1/qa/ripples/generate/{issue_id}")
    
    async def get_ripple_queue(self, issue_id: Optional[int] = None) -> list[dict[str, Any]]:
        """Get pending ripples for review."""
        params = {}
        if issue_id:
            params["issue_id"] = issue_id
        return await self._request("GET", "/api/v1/qa/ripples/queue", params=params)
    
    async def approve_ripple(self, ripple_id: int) -> dict[str, Any]:
        """Approve a ripple effect."""
        return await self._request("POST", f"/api/v1/qa/ripples/{ripple_id}/approve")

    async def reject_ripple(self, ripple_id: int, reason: str) -> dict[str, Any]:
        """Reject a ripple effect with a reason."""
        return await self._request(
            "POST",
            f"/api/v1/qa/ripples/{ripple_id}/reject",
            json={"reason": reason}
        )

    async def update_ripple(
        self,
        ripple_id: int,
        suggested_changes: str,
        reviewer_notes: str = None
    ) -> dict[str, Any]:
        """Update a ripple's suggested changes before approving."""
        data = {"suggested_changes": suggested_changes}
        if reviewer_notes:
            data["reviewer_notes"] = reviewer_notes
        return await self._request(
            "PATCH",
            f"/api/v1/qa/ripples/{ripple_id}",
            json=data
        )

    async def apply_ripple(self, ripple_id: int) -> dict[str, Any]:
        """Apply an approved ripple."""
        return await self._request("POST", f"/api/v1/qa/ripples/{ripple_id}/apply")
    
    # Scanning
    async def scan_codebase(self, repository_path: str) -> dict[str, Any]:
        """Scan and index a codebase."""
        return await self._request(
            "POST",
            "/api/v1/qa/implementation/scan",
            json={"repository_path": repository_path}
        )
    
    # Impact Analysis
    async def analyze_impact(
        self,
        file_path: str,
        project_id: Optional[str] = None
    ) -> dict[str, Any]:
        """Analyze impact of changes to a file."""
        project_id = project_id or self.config.default_project_id
        return await self._request(
            "POST",
            "/api/v1/qa/lsp-rag/impact",
            json={"file_path": file_path, "project_id": project_id}
        )
    
    # Traceability
    async def trace_requirement(self, requirement_id: str) -> dict[str, Any]:
        """Trace a requirement to code implementations."""
        return await self._request(
            "GET",
            "/api/v1/qa/lsp-rag/trace",
            params={"requirement_id": requirement_id}
        )
    
    async def search_symbols(
        self,
        query: str,
        project_id: Optional[str] = None
    ) -> list[dict[str, Any]]:
        """Search indexed code symbols."""
        project_id = project_id or self.config.default_project_id
        return await self._request(
            "GET",
            f"/api/v1/qa/lsp-rag/symbols/{project_id}",
            params={"query": query}
        )
    
    # Documents
    async def list_documents(self, project_id: Optional[str] = None) -> list[dict[str, Any]]:
        """List documents for a project."""
        params = {}
        if project_id:
            params["project_id"] = project_id
        return await self._request("GET", "/api/v1/documents", params=params)

    # Orchestration
    async def get_pending_work(self, project_id: Optional[str] = None) -> dict[str, Any]:
        """Get summary of pending work."""
        params = {}
        if project_id:
            params["project_id"] = project_id
        return await self._request("GET", "/api/v1/qa/orchestrate/pending-work", params=params)

    async def create_orchestration_session(
        self,
        project_id: str,
        mode: str = "sequential",
        max_iterations: int = 10,
        max_parallel: int = 3,
        issue_ids: Optional[list[int]] = None
    ) -> dict[str, Any]:
        """Create a new orchestration session."""
        data = {
            "project_id": project_id,
            "mode": mode,
            "max_iterations": max_iterations,
            "max_parallel": max_parallel
        }
        if issue_ids:
            data["issue_ids"] = issue_ids
        return await self._request("POST", "/api/v1/qa/orchestrate/sessions", json=data)

    async def get_orchestration_session(self, session_id: str) -> dict[str, Any]:
        """Get orchestration session status."""
        return await self._request("GET", f"/api/v1/qa/orchestrate/sessions/{session_id}")

    async def list_orchestration_sessions(
        self,
        project_id: Optional[str] = None,
        status: Optional[str] = None
    ) -> list[dict[str, Any]]:
        """List orchestration sessions."""
        params = {}
        if project_id:
            params["project_id"] = project_id
        if status:
            params["status"] = status
        return await self._request("GET", "/api/v1/qa/orchestrate/sessions", params=params)

    async def get_next_task(self, session_id: str, worker_id: Optional[str] = None) -> Optional[dict[str, Any]]:
        """Get next task for a worker."""
        params = {}
        if worker_id:
            params["worker_id"] = worker_id
        return await self._request("GET", f"/api/v1/qa/orchestrate/sessions/{session_id}/next", params=params)

    async def complete_task(
        self,
        session_id: str,
        ripple_id: int,
        success: bool = True,
        error: Optional[str] = None
    ) -> dict[str, Any]:
        """Mark a task as complete."""
        params = {"success": str(success).lower()}
        if error:
            params["error"] = error
        return await self._request(
            "POST",
            f"/api/v1/qa/orchestrate/sessions/{session_id}/task/{ripple_id}/complete",
            params=params
        )

    async def get_waves(self, session_id: str) -> list[dict[str, Any]]:
        """Get wave information for parallel execution."""
        return await self._request("GET", f"/api/v1/qa/orchestrate/sessions/{session_id}/waves")

    async def generate_all_ripples(self, project_id: str) -> dict[str, Any]:
        """Generate ripples for all open issues in a project."""
        return await self._request(
            "POST",
            "/api/v1/qa/orchestrate/generate-all-ripples",
            params={"project_id": project_id}
        )

    # Pipeline
    async def run_pipeline(
        self,
        project_id: str,
        mode: Optional[str] = None,
        output_path: Optional[str] = None
    ) -> dict[str, Any]:
        """Run the full auto-pipeline for a project."""
        data: dict[str, Any] = {"project_id": project_id}
        if mode:
            data["mode"] = mode
        if output_path:
            data["output_path"] = output_path
        return await self._request("POST", "/api/v1/qa/auto-pipeline/run", json=data)

    async def pipeline_status(self, project_id: str) -> dict[str, Any]:
        """Get pipeline status for a project (pending work summary)."""
        return await self._request(
            "GET",
            "/api/v1/qa/orchestrate/pending-work",
            params={"project_id": project_id}
        )

    async def generate_docs(
        self,
        project_id: str,
        output_path: Optional[str] = None
    ) -> dict[str, Any]:
        """Export project docs to markdown."""
        data: dict[str, Any] = {"project_id": project_id}
        if output_path:
            data["output_path"] = output_path
        return await self._request("POST", "/api/v1/qa/auto-pipeline/generate-docs", json=data)

    # Ripples (extended)
    async def get_ripple(self, ripple_id: int) -> dict[str, Any]:
        """Get a single ripple with full details."""
        return await self._request("GET", f"/api/v1/qa/ripples/{ripple_id}")

    async def get_pending_ripples(
        self,
        project_id: Optional[str] = None,
        risk_level: Optional[str] = None,
        limit: int = 50
    ) -> list[dict[str, Any]]:
        """Get pending ripples with filters."""
        params: dict[str, Any] = {"limit": limit}
        if project_id:
            params["project_id"] = project_id
        if risk_level:
            params["risk_level"] = risk_level
        return await self._request("GET", "/api/v1/qa/ripples/queue", params=params)

    # Document traceability
    async def get_traceability(self, project_id: str) -> dict[str, Any]:
        """Get cross-document traceability matrix."""
        return await self._request("GET", f"/api/v1/documents/traceability/{project_id}")

    async def get_document(self, doc_id: str) -> dict[str, Any]:
        """Get a single document by ID."""
        return await self._request("GET", f"/api/v1/documents/{doc_id}")

    # Design mode
    async def create_design_project(
        self,
        name: str,
        description: Optional[str] = None,
        platform: Optional[str] = None
    ) -> dict[str, Any]:
        """Create a new design project."""
        data: dict[str, Any] = {"name": name}
        if description:
            data["description"] = description
        if platform:
            data["platform"] = platform
        return await self._request("POST", "/api/v1/design/projects", json=data)

    async def get_pipeline_settings(self, project_id: str) -> dict[str, Any]:
        """Get pipeline settings for a project."""
        return await self._request("GET", f"/api/v1/qa/settings/pipeline/{project_id}")

    async def update_pipeline_settings(self, project_id: str, **kwargs) -> dict[str, Any]:
        """Update pipeline settings for a project."""
        data = {k: v for k, v in kwargs.items() if v is not None}
        return await self._request("PUT", f"/api/v1/qa/settings/pipeline/{project_id}", json=data)

    async def design_chat(
        self,
        doc_id: str,
        message: str,
        conversation_history: Optional[list[dict[str, str]]] = None
    ) -> dict[str, Any]:
        """Send a chat message to edit a document via AI."""
        data: dict[str, Any] = {"message": message}
        if conversation_history:
            data["conversation_history"] = conversation_history
        return await self._request("POST", f"/api/v1/documents/{doc_id}/chat", json=data)

    # Agent Reviews
    async def run_review(
        self,
        project_id: str,
        committee_size: int = 5,
        content: Optional[str] = None,
        context: Optional[str] = None,
        persona_ids: Optional[list[str]] = None,
        trigger_type: str = "manual",
    ) -> dict[str, Any]:
        """Start a multi-agent committee review."""
        data: dict[str, Any] = {
            "project_id": project_id,
            "committee_size": committee_size,
            "trigger_type": trigger_type,
        }
        if content:
            data["content"] = content
        if context:
            data["context"] = context
        if persona_ids:
            data["persona_ids"] = persona_ids
        return await self._request("POST", "/api/v1/qa/reviews/run", json=data)

    async def get_review(self, review_id: str) -> dict[str, Any]:
        """Get review details including advisements."""
        return await self._request("GET", f"/api/v1/qa/reviews/{review_id}")

    async def list_reviews(
        self,
        project_id: Optional[str] = None,
        status: Optional[str] = None,
        limit: int = 20,
    ) -> dict[str, Any]:
        """List reviews with optional filters."""
        params: dict[str, Any] = {"limit": limit}
        if project_id:
            params["project_id"] = project_id
        if status:
            params["status"] = status
        return await self._request("GET", "/api/v1/qa/reviews", params=params)

    async def approve_review_ripples(
        self,
        review_id: str,
        ripple_ids: Optional[list[int]] = None,
    ) -> dict[str, Any]:
        """Approve ripples extracted from a review."""
        data: dict[str, Any] = {}
        if ripple_ids:
            data["ripple_ids"] = ripple_ids
        return await self._request("POST", f"/api/v1/qa/reviews/{review_id}/approve-ripples", json=data)

    async def create_debate(
        self,
        project_id: str,
        topic: str,
        rounds: int = 3,
        agent_ids: Optional[list[str]] = None,
    ) -> dict[str, Any]:
        """Start an adversarial debate between agents."""
        data: dict[str, Any] = {
            "project_id": project_id,
            "topic": topic,
            "rounds": rounds,
        }
        if agent_ids:
            data["agent_ids"] = agent_ids
        return await self._request("POST", "/api/v1/qa/reviews/debates", json=data)

    async def get_debate(self, debate_id: str) -> dict[str, Any]:
        """Get debate with messages."""
        return await self._request("GET", f"/api/v1/qa/reviews/debates/{debate_id}")

    async def list_watcher_alerts(
        self,
        review_id: Optional[str] = None,
        project_id: Optional[str] = None,
        severity: Optional[str] = None,
        handled: Optional[bool] = None,
    ) -> dict[str, Any]:
        """List watcher anomaly alerts."""
        params: dict[str, Any] = {}
        if review_id:
            params["review_id"] = review_id
        if project_id:
            params["project_id"] = project_id
        if severity:
            params["severity"] = severity
        if handled is not None:
            params["handled"] = str(handled).lower()
        return await self._request("GET", "/api/v1/qa/reviews/watcher/alerts", params=params)

    async def handle_alert(self, alert_id: str, handled: bool = True) -> dict[str, Any]:
        """Mark a watcher alert as handled."""
        return await self._request(
            "PUT",
            f"/api/v1/qa/reviews/watcher/alerts/{alert_id}/handle",
            json={"handled": handled}
        )

    async def list_personas(self, agent_type: Optional[str] = None) -> dict[str, Any]:
        """List available agent personas."""
        params: dict[str, Any] = {}
        if agent_type:
            params["type"] = agent_type
        return await self._request("GET", "/api/v1/qa/reviews/agents/personas", params=params)

    # ── Autonomous Coding Loop ──────────────────────────────────

    async def loop_start(
        self,
        project_id: str,
        max_iterations: int = 15,
        max_depth: int = 3,
        timeout_per_task: int = 600,
        issue_ids: Optional[list[int]] = None,
        committee_size: int = 3,
        working_dir: Optional[str] = None,
    ) -> dict[str, Any]:
        """Start an autonomous coding loop."""
        data: dict[str, Any] = {
            "project_id": project_id,
            "max_iterations": max_iterations,
            "max_depth": max_depth,
            "timeout_per_task": timeout_per_task,
            "committee_size": committee_size,
        }
        if issue_ids:
            data["issue_ids"] = issue_ids
        if working_dir:
            data["working_dir"] = working_dir
        return await self._request("POST", "/api/v1/qa/loop/start", json=data)

    async def loop_status(self, storm_id: int) -> dict[str, Any]:
        """Get the status of a coding loop session."""
        return await self._request("GET", f"/api/v1/qa/loop/status/{storm_id}")

    async def loop_stop(self, storm_id: int, reason: str = "manual_stop") -> dict[str, Any]:
        """Stop a running coding loop."""
        return await self._request("POST", f"/api/v1/qa/loop/stop/{storm_id}", json={"reason": reason})

    async def loop_next_task(
        self,
        storm_id: Optional[int] = None,
        project_id: Optional[str] = None,
    ) -> dict[str, Any]:
        """Pull the next available task for an agent."""
        params: dict[str, Any] = {}
        if storm_id:
            params["storm_id"] = storm_id
        if project_id:
            params["project_id"] = project_id
        return await self._request("GET", "/api/v1/qa/loop/next-task", params=params)

    async def loop_claim_task(
        self,
        droplet_id: int,
        agent_id: Optional[str] = None,
    ) -> dict[str, Any]:
        """Claim a task for execution."""
        data: dict[str, Any] = {}
        if agent_id:
            data["agent_id"] = agent_id
        return await self._request("POST", f"/api/v1/qa/loop/claim-task/{droplet_id}", json=data)

    async def loop_checkpoint_task(
        self,
        droplet_id: int,
        progress_percent: int = 0,
        completed_steps: Optional[list[str]] = None,
        remaining_steps: Optional[list[str]] = None,
        summary: Optional[str] = None,
        files_changed: Optional[list[str]] = None,
    ) -> dict[str, Any]:
        """Save a progress checkpoint."""
        data: dict[str, Any] = {"progress_percent": progress_percent}
        if completed_steps:
            data["completed_steps"] = completed_steps
        if remaining_steps:
            data["remaining_steps"] = remaining_steps
        if summary:
            data["summary"] = summary
        if files_changed:
            data["files_changed"] = files_changed
        return await self._request("POST", f"/api/v1/qa/loop/checkpoint-task/{droplet_id}", json=data)

    async def loop_complete_task(
        self,
        droplet_id: int,
        success: bool = True,
        summary: Optional[str] = None,
        files_changed: Optional[list[str]] = None,
        diff: Optional[str] = None,
        commit_sha: Optional[str] = None,
        error: Optional[str] = None,
    ) -> dict[str, Any]:
        """Mark a task as complete."""
        data: dict[str, Any] = {"success": success}
        if summary:
            data["summary"] = summary
        if files_changed:
            data["files_changed"] = files_changed
        if diff:
            data["diff"] = diff
        if commit_sha:
            data["commit_sha"] = commit_sha
        if error:
            data["error"] = error
        return await self._request("POST", f"/api/v1/qa/loop/complete-task/{droplet_id}", json=data)

    # ── Design Generation ────────────────────────────────────────

    async def design_generate(
        self,
        doc_type: str,
        title: str,
        description: str,
        project_id: Optional[str] = None,
        feature_id: Optional[str] = None
    ) -> dict[str, Any]:
        """Generate a new document using AI."""
        data: dict[str, Any] = {
            "doc_type": doc_type,
            "title": title,
            "description": description,
        }
        if project_id:
            data["project_id"] = project_id
        if feature_id:
            data["feature_id"] = feature_id
        return await self._request("POST", "/api/v1/documents/create-with-ai", json=data)

    # ------------------------------------------------------------------
    # Graphify bridge (compatibility with safishamsi/graphify)
    # ------------------------------------------------------------------

    async def graphify_health(self) -> dict[str, Any]:
        """Check whether the backend has graphifyy installed."""
        return await self._request("GET", "/api/v1/qa/graphify/health")

    async def graphify_import(
        self,
        graph: dict[str, Any],
        project_id: Optional[str] = None,
    ) -> dict[str, Any]:
        """Import a Graphify graph.json payload and map it to Remembril nodes."""
        project_id = project_id or self.config.default_project_id
        if not project_id:
            raise RembrilError("project_id is required")
        return await self._request(
            "POST",
            "/api/v1/qa/graphify/import",
            json={"project_id": project_id, "graph": graph},
        )

    async def graphify_import_from_path(
        self,
        graph_json_path: str,
        project_id: Optional[str] = None,
    ) -> dict[str, Any]:
        """Load a Graphify graph.json from a server-side path."""
        project_id = project_id or self.config.default_project_id
        if not project_id:
            raise RembrilError("project_id is required")
        return await self._request(
            "POST",
            "/api/v1/qa/graphify/import-from-path",
            json={"project_id": project_id, "graph_json_path": graph_json_path},
        )

    async def graphify_diff(
        self,
        old_graph: dict[str, Any],
        new_graph: dict[str, Any],
        project_id: Optional[str] = None,
        generate_ripples: bool = True,
    ) -> dict[str, Any]:
        """Diff two Graphify snapshots and optionally emit ripple payloads."""
        project_id = project_id or self.config.default_project_id
        if not project_id:
            raise RembrilError("project_id is required")
        return await self._request(
            "POST",
            "/api/v1/qa/graphify/diff",
            json={
                "project_id": project_id,
                "old_graph": old_graph,
                "new_graph": new_graph,
                "generate_ripples": generate_ripples,
            },
        )

    async def graphify_sync(
        self,
        project_dir: str,
        out_dir: str = "graphify-out",
        previous_graph_path: Optional[str] = None,
        project_id: Optional[str] = None,
    ) -> dict[str, Any]:
        """Rebuild the Graphify graph for a working directory (requires graphifyy)."""
        project_id = project_id or self.config.default_project_id
        if not project_id:
            raise RembrilError("project_id is required")
        return await self._request(
            "POST",
            "/api/v1/qa/graphify/sync",
            json={
                "project_id": project_id,
                "project_dir": project_dir,
                "out_dir": out_dir,
                "previous_graph_path": previous_graph_path,
            },
        )
