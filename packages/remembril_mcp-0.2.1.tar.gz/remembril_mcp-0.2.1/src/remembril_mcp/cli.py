"""CLI commands for Remembril MCP server."""

import asyncio
import json
import os
import sys
import webbrowser
from datetime import datetime
from pathlib import Path
import click
import httpx

from . import __version__
from .config import Config
from .client import RembrilClient, RembrilError
from .server import run_server


# Complexity scoring heuristics (Zeroshot-inspired)
COMPLEXITY_KEYWORDS = {
    "high": ["architecture", "security", "migration", "refactor", "breaking",
             "authentication", "encryption", "database", "schema", "performance"],
    "medium": ["feature", "api", "integration", "update", "enhance", "add"],
    "low": ["fix", "typo", "style", "format", "docs", "comment", "minor"]
}


def calculate_complexity(title: str, description: str = "") -> tuple[str, str]:
    """
    Calculate issue complexity based on content analysis.
    Returns (severity, reason).
    """
    text = f"{title} {description}".lower()

    # Check high complexity keywords
    for keyword in COMPLEXITY_KEYWORDS["high"]:
        if keyword in text:
            return ("high", f"Contains high-complexity indicator: '{keyword}'")

    # Check medium complexity keywords
    for keyword in COMPLEXITY_KEYWORDS["medium"]:
        if keyword in text:
            return ("medium", f"Contains standard change indicator: '{keyword}'")

    # Check low complexity keywords
    for keyword in COMPLEXITY_KEYWORDS["low"]:
        if keyword in text:
            return ("low", f"Contains simple change indicator: '{keyword}'")

    # Default to medium
    return ("medium", "No specific complexity indicators found")


@click.group()
@click.version_option(version=__version__)
def main():
    """Remembril MCP Server - Change tracking and impact analysis for AI assistants."""
    pass


@main.command()
def serve():
    """Start the MCP server (stdio mode)."""
    config = Config.load()
    
    if not config.is_authenticated:
        click.echo("Warning: No authentication token found.", err=True)
        click.echo("Run 'remembril-mcp login' to authenticate.", err=True)
        click.echo("Or set REMEMBRIL_TOKEN environment variable.", err=True)
        click.echo("", err=True)
    
    asyncio.run(run_server(config))


@main.command()
@click.option("--token", "-t", help="API token (or set via browser login)")
@click.option("--url", "-u", default="https://remembril-production.up.railway.app", help="API URL")
def login(token: str, url: str):
    """Authenticate with Remembril API."""
    config = Config.load()
    config.api_url = url
    
    if token:
        # Direct token provided
        config.token = token
    else:
        # Browser-based login
        login_url = f"{url}/login?cli=true"
        click.echo(f"Opening browser for authentication...")
        click.echo(f"URL: {login_url}")
        click.echo("")
        click.echo("After logging in, copy the token and paste it here.")
        click.echo("")
        
        try:
            webbrowser.open(login_url)
        except Exception:
            click.echo("Could not open browser. Please visit the URL manually.")
        
        token = click.prompt("Paste your token")
        config.token = token.strip()
    
    # Validate token
    click.echo("Validating token...")
    try:
        client = RembrilClient(config)
        user = asyncio.run(_get_user(client))
        click.echo(f"Authenticated as: {user.get('email', 'Unknown')}")
        config.save()
        click.echo(f"Token saved to {config.config_file()}")
    except RembrilError as e:
        click.echo(f"Authentication failed: {e}", err=True)
        sys.exit(1)


async def _get_user(client: RembrilClient) -> dict:
    """Get current user info."""
    try:
        return await client.get_me()
    finally:
        await client.close()


@main.command()
def logout():
    """Remove stored credentials."""
    config = Config.load()
    config.token = None
    config.save()
    click.echo("Logged out. Token removed.")


@main.command("generate-token")
@click.option("--email", "-e", prompt=True, help="Email address")
@click.option("--password", "-p", prompt=True, hide_input=True, help="Password")
@click.option("--first-name", "-f", default=None, help="First name (for signup)")
@click.option("--last-name", "-l", default=None, help="Last name (for signup)")
@click.option("--url", "-u", default=None, help="API URL (default: from config or http://localhost:7070)")
@click.option("--save/--no-save", default=True, help="Save token to config (default: yes)")
def generate_token(email: str, password: str, first_name: str, last_name: str, url: str, save: bool):
    """Generate an auth token via login or signup.

    Tries to log in first. If the account doesn't exist, creates one (requires --first-name and --last-name).

    Examples:

        # Login (existing user):
        remembril-mcp generate-token -e tom@example.com -p mypass

        # Signup (new user):
        remembril-mcp generate-token -e tom@example.com -p mypass -f Tom -l Harper

        # Print token without saving:
        remembril-mcp generate-token -e tom@example.com -p mypass --no-save
    """
    config = Config.load()
    if url:
        config.api_url = url
    elif config.api_url == "https://remembril-production.up.railway.app":
        # Default to localhost for local dev if not configured otherwise
        config.api_url = os.environ.get("REMEMBRIL_URL", "http://localhost:7070")

    base_url = config.api_url.rstrip("/")
    token = asyncio.run(_generate_token(base_url, email, password, first_name, last_name))

    if not token:
        sys.exit(1)

    if save:
        config.token = token
        config.save()
        click.echo(f"Token saved to {config.config_file()}")
    else:
        click.echo(f"\n{token}")


def _extract_token(data: dict) -> str | None:
    """Extract access token from auth response (handles multiple formats)."""
    # Format 1: {"access_token": "..."}
    if token := data.get("access_token"):
        return token
    # Format 2: {"token": "..."}
    if token := data.get("token"):
        return token
    # Format 3: {"tokens": {"accessToken": "..."}}
    if tokens := data.get("tokens"):
        if token := tokens.get("accessToken"):
            return token
        if token := tokens.get("access_token"):
            return token
    return None


async def _generate_token(base_url: str, email: str, password: str, first_name: str | None, last_name: str | None) -> str | None:
    """Try login, fall back to signup if account doesn't exist."""
    async with httpx.AsyncClient(timeout=15) as http:
        # Try login first
        click.echo(f"Logging in as {email}...")
        try:
            resp = await http.post(
                f"{base_url}/api/v1/qa/auth/login",
                json={"email": email, "password": password},
            )
            if resp.status_code == 200:
                data = resp.json()
                token = _extract_token(data)
                if token:
                    click.echo(f"Logged in as {email}")
                    return token
                click.echo("Login succeeded but no token in response.", err=True)
                return None

            if resp.status_code == 401:
                # Could be wrong password or user doesn't exist — try signup
                click.echo("Login failed. Attempting signup...")
            else:
                click.echo(f"Login error ({resp.status_code}): {resp.text}", err=True)
                return None
        except httpx.ConnectError:
            click.echo(f"Cannot connect to {base_url}. Is the backend running?", err=True)
            return None
        except httpx.RequestError as e:
            click.echo(f"Request error: {e}", err=True)
            return None

        # Signup
        if not first_name or not last_name:
            click.echo("Account not found. To sign up, provide --first-name and --last-name.", err=True)
            return None

        try:
            resp = await http.post(
                f"{base_url}/api/v1/qa/auth/signup",
                json={
                    "first_name": first_name,
                    "last_name": last_name,
                    "email": email,
                    "password": password,
                },
            )
            if resp.status_code == 200:
                data = resp.json()
                token = _extract_token(data)
                if token:
                    click.echo(f"Account created for {email}")
                    return token
                click.echo("Signup succeeded but no token in response.", err=True)
                return None

            # 400 = email already exists (wrong password on login)
            if resp.status_code == 400:
                click.echo("Email already registered. Check your password.", err=True)
                return None

            click.echo(f"Signup error ({resp.status_code}): {resp.text}", err=True)
            return None
        except httpx.RequestError as e:
            click.echo(f"Request error: {e}", err=True)
            return None


@main.command()
def status():
    """Show current configuration and authentication status."""
    config = Config.load()
    
    click.echo(f"Config file: {config.config_file()}")
    click.echo(f"API URL: {config.api_url}")
    click.echo(f"Default project: {config.default_project_id or 'Not set'}")
    click.echo(f"Authenticated: {'Yes' if config.is_authenticated else 'No'}")
    
    if config.is_authenticated:
        click.echo("")
        click.echo("Checking connection...")
        try:
            client = RembrilClient(config)
            user = asyncio.run(_get_user(client))
            click.echo(f"Connected as: {user.get('email', 'Unknown')}")
        except RembrilError as e:
            click.echo(f"Connection error: {e}", err=True)


@main.command()
@click.argument("project_id")
def set_project(project_id: str):
    """Set the default project ID."""
    config = Config.load()
    config.default_project_id = project_id
    config.save()
    click.echo(f"Default project set to: {project_id}")


@main.command()
def projects():
    """List available projects."""
    config = Config.load()
    
    if not config.is_authenticated:
        click.echo("Not authenticated. Run 'remembril-mcp login' first.", err=True)
        sys.exit(1)
    
    try:
        client = RembrilClient(config)
        project_list = asyncio.run(_list_projects(client))
        
        if not project_list:
            click.echo("No projects found.")
            return
        
        click.echo("Projects:")
        for p in project_list:
            marker = " (default)" if p.get("id") == config.default_project_id else ""
            click.echo(f"  {p.get('id')} - {p.get('name')}{marker}")
    
    except RembrilError as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


async def _list_projects(client: RembrilClient) -> list:
    """List projects."""
    try:
        return await client.list_projects()
    finally:
        await client.close()


# ============================================================
# Zeroshot-inspired enhanced commands
# ============================================================

@main.command()
@click.argument("title")
@click.option("--description", "-d", help="Issue description")
@click.option("--auto-severity", is_flag=True, help="Auto-calculate severity from complexity")
@click.option("--project", "-p", help="Project ID")
def issue(title: str, description: str, auto_severity: bool, project: str):
    """Create an issue with optional auto-severity calculation."""
    config = Config.load()

    if not config.is_authenticated:
        click.echo("Not authenticated. Run 'remembril-mcp login' first.", err=True)
        sys.exit(1)

    # Auto-calculate complexity if requested
    if auto_severity:
        severity, reason = calculate_complexity(title, description or "")
        click.echo(f"Complexity analysis: {reason}")
        click.echo(f"Auto-assigned severity: {severity}")
    else:
        severity = "medium"

    try:
        client = RembrilClient(config)
        result = asyncio.run(_create_issue(
            client,
            title=title,
            description=description,
            severity=severity,
            project_id=project or config.default_project_id
        ))
        click.echo(f"Created issue #{result.get('id')}: {result.get('title')}")
        click.echo(f"Severity: {result.get('severity')}")
    except RembrilError as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


async def _create_issue(client: RembrilClient, **kwargs) -> dict:
    """Create an issue."""
    try:
        return await client.create_issue(**kwargs)
    finally:
        await client.close()


@main.command()
@click.argument("issue_id", type=int)
@click.option("--wait", "-w", is_flag=True, help="Wait for ripple generation to complete")
def run(issue_id: int, wait: bool):
    """Generate ripples for an issue (like Zeroshot's run command)."""
    config = Config.load()

    if not config.is_authenticated:
        click.echo("Not authenticated. Run 'remembril-mcp login' first.", err=True)
        sys.exit(1)

    click.echo(f"Generating ripples for issue #{issue_id}...")

    try:
        client = RembrilClient(config)
        result = asyncio.run(_generate_ripples(client, issue_id))

        ripples = result.get("ripples", [])
        click.echo(f"Generated {len(ripples)} ripple(s)")

        for ripple in ripples:
            status_icon = "🔄" if ripple.get("status") == "pending" else "✅"
            click.echo(f"  {status_icon} {ripple.get('target_doc', 'Unknown')} - {ripple.get('change_type', 'update')}")

        # Log the run
        _log_run(issue_id, "generate", result)

    except RembrilError as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


async def _generate_ripples(client: RembrilClient, issue_id: int) -> dict:
    """Generate ripples for an issue."""
    try:
        return await client.generate_ripples(issue_id)
    finally:
        await client.close()


@main.command()
@click.option("--issue-id", "-i", type=int, help="Filter by issue ID")
@click.option("--json-output", "-j", is_flag=True, help="Output as JSON")
def logs(issue_id: int, json_output: bool):
    """Show ripple generation history (like Zeroshot's logs command)."""
    config = Config.load()
    log_file = _get_log_file()

    if not log_file.exists():
        click.echo("No logs found.")
        return

    with open(log_file) as f:
        entries = [json.loads(line) for line in f if line.strip()]

    # Filter by issue_id if provided
    if issue_id:
        entries = [e for e in entries if e.get("issue_id") == issue_id]

    if not entries:
        click.echo("No matching log entries.")
        return

    if json_output:
        click.echo(json.dumps(entries, indent=2))
    else:
        click.echo("Run History:")
        for entry in entries[-10:]:  # Last 10 entries
            timestamp = entry.get("timestamp", "Unknown")
            issue = entry.get("issue_id", "?")
            action = entry.get("action", "?")
            ripples = len(entry.get("result", {}).get("ripples", []))
            click.echo(f"  [{timestamp}] Issue #{issue}: {action} ({ripples} ripples)")


@main.command()
@click.argument("issue_id", type=int)
def resume(issue_id: int):
    """Resume reviewing ripples for an issue (Zeroshot-inspired recovery)."""
    config = Config.load()

    if not config.is_authenticated:
        click.echo("Not authenticated. Run 'remembril-mcp login' first.", err=True)
        sys.exit(1)

    click.echo(f"Resuming ripple review for issue #{issue_id}...")

    try:
        client = RembrilClient(config)
        queue = asyncio.run(_get_ripple_queue(client, issue_id))

        pending = [r for r in queue if r.get("status") == "pending"]

        if not pending:
            click.echo("No pending ripples to review.")
            return

        click.echo(f"Found {len(pending)} pending ripple(s):")
        for ripple in pending:
            click.echo(f"  • Ripple #{ripple.get('id')}: {ripple.get('target_doc')}")
            click.echo(f"    Change: {ripple.get('change_type')}")
            if ripple.get('suggested_changes'):
                click.echo(f"    Preview: {ripple.get('suggested_changes')[:100]}...")

    except RembrilError as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


async def _get_ripple_queue(client: RembrilClient, issue_id: int) -> list:
    """Get ripple queue for an issue."""
    try:
        return await client.get_ripple_queue(issue_id)
    finally:
        await client.close()


@main.command()
@click.argument("issue_id", type=int)
@click.option("--blind", is_flag=True, help="Blind validation mode (hide AI reasoning)")
def review(issue_id: int, blind: bool):
    """Review ripples for an issue with optional blind validation."""
    config = Config.load()

    if not config.is_authenticated:
        click.echo("Not authenticated. Run 'remembril-mcp login' first.", err=True)
        sys.exit(1)

    try:
        client = RembrilClient(config)
        queue = asyncio.run(_get_ripple_queue(client, issue_id))

        pending = [r for r in queue if r.get("status") == "pending"]

        if not pending:
            click.echo("No pending ripples to review.")
            return

        if blind:
            click.echo("=" * 50)
            click.echo("BLIND VALIDATION MODE")
            click.echo("AI reasoning is hidden - you validate independently")
            click.echo("=" * 50)

        for ripple in pending:
            click.echo("")
            click.echo(f"Ripple #{ripple.get('id')}")
            click.echo(f"Target: {ripple.get('target_doc')}")
            click.echo(f"Change type: {ripple.get('change_type')}")

            if not blind:
                # Show AI reasoning in normal mode
                if ripple.get('reason'):
                    click.echo(f"AI Reason: {ripple.get('reason')}")
                if ripple.get('suggested_changes'):
                    click.echo(f"Suggested: {ripple.get('suggested_changes')}")
            else:
                click.echo("[AI reasoning hidden - validate independently]")

            # Interactive review
            action = click.prompt(
                "Action",
                type=click.Choice(["approve", "update", "reject", "skip", "quit"]),
                default="skip"
            )

            if action == "approve":
                asyncio.run(_approve_ripple(client, ripple.get('id')))
                click.echo("✅ Approved")
            elif action == "update":
                click.echo("Enter updated changes (end with empty line):")
                lines = []
                while True:
                    line = click.prompt("", default="", show_default=False)
                    if not line:
                        break
                    lines.append(line)
                updated_changes = "\n".join(lines)
                notes = click.prompt("Reviewer notes (why adjusted)", default="")
                asyncio.run(_update_ripple(client, ripple.get('id'), updated_changes, notes))
                click.echo("📝 Updated - use approve to finalize")
            elif action == "reject":
                reason = click.prompt("Rejection reason")
                asyncio.run(_reject_ripple(client, ripple.get('id'), reason))
                click.echo(f"❌ Rejected: {reason}")
            elif action == "quit":
                break

    except RembrilError as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


async def _approve_ripple(client: RembrilClient, ripple_id: int) -> dict:
    """Approve a ripple."""
    try:
        return await client.approve_ripple(ripple_id)
    finally:
        await client.close()


async def _reject_ripple(client: RembrilClient, ripple_id: int, reason: str) -> dict:
    """Reject a ripple with reason."""
    try:
        return await client.reject_ripple(ripple_id, reason)
    finally:
        await client.close()


async def _update_ripple(client: RembrilClient, ripple_id: int, changes: str, notes: str) -> dict:
    """Update a ripple's suggested changes."""
    try:
        return await client.update_ripple(ripple_id, changes, notes if notes else None)
    finally:
        await client.close()


def _get_log_file() -> Path:
    """Get the log file path."""
    config_dir = Path.home() / ".remembril"
    config_dir.mkdir(exist_ok=True)
    return config_dir / "runs.jsonl"


def _log_run(issue_id: int, action: str, result: dict) -> None:
    """Log a run to the runs file."""
    log_file = _get_log_file()
    entry = {
        "timestamp": datetime.utcnow().isoformat(),
        "issue_id": issue_id,
        "action": action,
        "result": result
    }
    with open(log_file, "a") as f:
        f.write(json.dumps(entry) + "\n")


if __name__ == "__main__":
    main()
