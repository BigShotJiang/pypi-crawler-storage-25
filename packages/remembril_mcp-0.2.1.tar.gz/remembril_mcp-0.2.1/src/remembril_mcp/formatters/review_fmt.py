"""Agent review formatting for plain text output."""

from typing import Any


POSITION_ICONS = {
    "approve": "✅",
    "approve_with_concerns": "⚠️",
    "request_changes": "🔧",
    "block": "🚫",
    "abstain": "⏸️",
}

SEVERITY_ICONS = {"info": "ℹ️", "warning": "⚠️", "critical": "🔴"}


def format_review_detail(review: dict[str, Any]) -> str:
    """Format a full review with individual and joint advisements."""
    status = review.get("status", "?")
    review_id = review.get("id", "?")
    lines = [f"## Agent Review #{review_id} [{status.upper()}]\n"]

    # Individual advisements
    advisements = review.get("individual_advisements") or []
    if advisements:
        lines.append(f"### Committee ({len(advisements)} agents)\n")
        for a in advisements:
            pos = a.get("position", "abstain")
            icon = POSITION_ICONS.get(pos, "❓")
            name = a.get("agent_name", a.get("agent_id", "?"))
            conf = a.get("confidence", 0)
            lines.append(f"{icon} **{name}** — {pos} (confidence: {conf:.0%})")
            if a.get("summary"):
                lines.append(f"  {a['summary']}")
            for f in a.get("findings", []):
                lines.append(f"  - Finding: {f}")
            for c in a.get("concerns", []):
                lines.append(f"  - Concern: {c}")
            for r in a.get("recommendations", []):
                lines.append(f"  - Rec: {r}")
            lines.append("")

    # Joint advisement
    joint = review.get("joint_advisement")
    if joint:
        rec = joint.get("recommendation", joint.get("majority_position", "?"))
        lines.append(f"### Joint Recommendation: {POSITION_ICONS.get(rec, '❓')} {rec}\n")
        if joint.get("recommendation_summary"):
            lines.append(joint["recommendation_summary"])
            lines.append("")
        for item in joint.get("action_items", []):
            lines.append(f"- [ ] {item}")
        for risk in joint.get("risks", []):
            lines.append(f"- ⚠️ Risk: {risk}")
        lines.append("")

    # Alerts + ripples
    alert_count = review.get("alert_count", 0)
    ripple_ids = review.get("extracted_ripple_ids") or []
    if alert_count:
        lines.append(f"🔔 {alert_count} watcher alert(s)")
    if ripple_ids:
        lines.append(f"📋 {len(ripple_ids)} ripple(s) extracted")
    lines.append("")
    lines.append("Use `remembril_review_approve_ripples` to approve extracted ripples.")

    return "\n".join(lines)


def format_review_list(data: dict[str, Any]) -> str:
    """Format review list as markdown."""
    items = data.get("items", [])
    total = data.get("total", len(items))
    if not items:
        return "No reviews found."

    lines = [f"## Reviews ({total} total)\n"]
    for r in items:
        status = r.get("status", "?")
        rid = r.get("id", "?")[:8]
        trigger = r.get("trigger_type", "?")
        committee = r.get("committee_size", "?")
        ripples = r.get("ripple_count", 0)
        alerts = r.get("alert_count", 0)

        status_icon = {"completed": "✅", "running": "⏳", "pending": "⏸️", "failed": "❌"}.get(status, "❓")
        lines.append(f"{status_icon} **{rid}...** [{status}] trigger={trigger} committee={committee}")
        if ripples or alerts:
            lines.append(f"  📋 {ripples} ripples  🔔 {alerts} alerts")
        lines.append("")

    return "\n".join(lines)


def format_debate_detail(debate: dict[str, Any]) -> str:
    """Format a debate with messages."""
    topic = debate.get("topic", "?")
    status = debate.get("status", "?")
    debate_id = debate.get("id", "?")
    rounds = debate.get("rounds", 0)
    completed = debate.get("rounds_completed", 0)

    lines = [f"## Debate #{debate_id[:8]}... [{status.upper()}]"]
    lines.append(f"**Topic:** {topic}")
    lines.append(f"**Progress:** {completed}/{rounds} rounds\n")

    messages = debate.get("messages") or []
    for msg in messages:
        agent = msg.get("agent", "?")
        role = msg.get("role", "")
        content = msg.get("content", "")
        rd = msg.get("round", "?")
        lines.append(f"**[R{rd}] {agent}** ({role}):")
        lines.append(f"> {content}\n")

    consensus = debate.get("consensus")
    if consensus:
        reached = consensus.get("reached", False)
        summary = consensus.get("summary", "")
        icon = "✅" if reached else "❌"
        lines.append(f"### Consensus: {icon} {'Reached' if reached else 'Not reached'}")
        if summary:
            lines.append(summary)

    return "\n".join(lines)


def format_watcher_alerts(data: dict[str, Any]) -> str:
    """Format watcher alerts as markdown."""
    items = data.get("items", [])
    if not items:
        return "No watcher alerts."

    lines = [f"## Watcher Alerts ({len(items)})\n"]
    for a in items:
        severity = a.get("severity", "info")
        icon = SEVERITY_ICONS.get(severity, "ℹ️")
        alert_type = a.get("alert_type", "?")
        desc = a.get("description", "")
        handled = a.get("handled", False)
        agents = a.get("involved_agents", [])

        status = "✅ handled" if handled else "⏳ open"
        lines.append(f"{icon} **{alert_type}** [{severity}] — {status}")
        lines.append(f"  {desc}")
        if agents:
            lines.append(f"  Agents: {', '.join(agents)}")
        lines.append("")

    return "\n".join(lines)


def format_personas(data: dict[str, Any]) -> str:
    """Format persona list as markdown."""
    items = data.get("items", [])
    if not items:
        return "No personas found."

    type_icons = {"advocate": "🟢", "adversary": "🔴", "outsider": "🔵", "ghost": "👻"}

    lines = [f"## Agent Personas ({len(items)})\n"]
    for p in items:
        ptype = p.get("type", "?")
        icon = type_icons.get(ptype, "❓")
        lines.append(f"{icon} **{p.get('name', '?')}** (`{p.get('id', '?')}`) — {ptype}")
        if p.get("role"):
            lines.append(f"  Role: {p['role']}")
        if p.get("goal"):
            lines.append(f"  Goal: {p['goal']}")
        lines.append("")

    return "\n".join(lines)
