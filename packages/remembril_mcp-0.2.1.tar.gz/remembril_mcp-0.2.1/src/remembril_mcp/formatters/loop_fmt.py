"""Markdown formatters for autonomous coding loop status."""


def format_loop_status(data: dict) -> str:
    """Format loop status as markdown for plain-text hosts."""
    lines = []

    storm_key = data.get("storm_key", "?")
    status = data.get("status", "unknown")
    lines.append(f"# Loop: {storm_key}")
    lines.append(f"**Status**: {status}")
    lines.append("")

    state = data.get("state", {})
    lines.append("## Progress")
    lines.append(f"- Depth: {state.get('current_depth', 0)} / max")
    lines.append(f"- Iterations: {state.get('total_iterations', 0)}")
    lines.append(f"- Completed: {state.get('droplets_completed', 0)}")
    lines.append(f"- Failed: {state.get('droplets_failed', 0)}")
    lines.append(f"- Review findings: {state.get('review_findings_total', 0)}")

    if state.get("terminated"):
        lines.append(f"- **Terminated**: {state.get('termination_reason', 'unknown')}")
    lines.append("")

    waves = data.get("waves", [])
    if waves:
        lines.append("## Waves")
        for w in waves:
            done = w.get("completed_droplets", 0)
            total = w.get("total_droplets", 0)
            lines.append(
                f"- {w.get('wave_key', '?')}: {w.get('status', '?')} "
                f"({done}/{total} droplets)"
            )
        lines.append("")

    droplets = data.get("droplets", [])
    if droplets:
        lines.append("## Droplets")
        for d in droplets:
            status_icon = {
                "completed": "done",
                "failed": "FAIL",
                "in_progress": "...",
                "in_review": "review",
                "pending": "wait",
                "blocked": "GATE",
                "cancelled": "skip",
                "rejected": "redo",
            }.get(d.get("status", ""), d.get("status", ""))
            branch = f" [{d.get('branch', '')}]" if d.get("branch") else ""
            lines.append(f"- [{status_icon}] {d.get('droplet_key', '?')}: {d.get('title', '')}{branch}")
        lines.append("")

    review_cycles = state.get("review_cycles", [])
    if review_cycles:
        lines.append("## Review Cycles")
        for rc in review_cycles:
            lines.append(
                f"- Depth {rc.get('depth', '?')}: "
                f"{rc.get('findings_count', 0)} findings "
                f"(from {rc.get('source_droplet', '?')})"
            )

    return "\n".join(lines)
