"""Pipeline status formatting for plain text output."""

from typing import Any


def format_pipeline_status(data: dict[str, Any]) -> str:
    """Format pipeline run status as readable text."""
    lines = ["## Pipeline Status\n"]

    if data.get("status"):
        lines.append(f"**Status:** {data['status']}")
    if data.get("mode"):
        lines.append(f"**Mode:** {data['mode']}")

    # Issue processing stats
    processed = data.get("issues_processed", 0)
    total_issues = data.get("total_issues", processed)
    lines.append(f"\n**Issues:** {processed}/{total_issues} processed")

    # Ripple stats
    generated = data.get("ripples_generated", 0)
    approved = data.get("ripples_approved", 0)
    applied = data.get("ripples_applied", 0)
    lines.append(f"**Ripples:** {generated} generated | {approved} approved | {applied} applied")

    # Document updates
    docs_updated = data.get("documents_updated", 0)
    lines.append(f"**Documents updated:** {docs_updated}")

    # Per-document details
    if data.get("documents"):
        lines.append("\n### Documents")
        for doc in data["documents"]:
            status_icon = "Y" if doc.get("updated") else "-"
            doc_type = doc.get("doc_type", doc.get("type", "?"))
            doc_id = doc.get("id", "?")
            lines.append(f"  [{status_icon}] {doc_id} ({doc_type})")

    # Errors
    if data.get("errors"):
        lines.append("\n### Errors")
        for err in data["errors"]:
            lines.append(f"  ! {err}")

    return "\n".join(lines)
