"""Generic table formatting for plain text output."""

from typing import Any


def format_table(headers: list[str], rows: list[list[str]], title: str = "") -> str:
    """Format data as a markdown table."""
    if not rows:
        return f"{title}\n(no data)" if title else "(no data)"

    # Calculate column widths
    widths = [len(h) for h in headers]
    for row in rows:
        for i, cell in enumerate(row):
            if i < len(widths):
                widths[i] = max(widths[i], len(str(cell)))

    # Build table
    lines = []
    if title:
        lines.append(f"## {title}\n")

    # Header
    header_line = "| " + " | ".join(h.ljust(widths[i]) for i, h in enumerate(headers)) + " |"
    sep_line = "|" + "|".join("-" * (w + 2) for w in widths) + "|"
    lines.append(header_line)
    lines.append(sep_line)

    # Rows
    for row in rows:
        cells = []
        for i, cell in enumerate(row):
            w = widths[i] if i < len(widths) else len(str(cell))
            cells.append(str(cell).ljust(w))
        lines.append("| " + " | ".join(cells) + " |")

    return "\n".join(lines)
