"""Ripple queue and diff formatting for plain text output."""

from typing import Any


RISK_ICONS = {"low": "🟢", "medium": "🟡", "high": "🟠", "critical": "🔴"}


def format_ripple_queue(ripples: list[dict[str, Any]]) -> str:
    """Format ripple queue as readable markdown."""
    if not ripples:
        return "No pending ripples."

    lines = [f"## Ripple Review Queue ({len(ripples)} pending)\n"]

    for r in ripples:
        risk = r.get("risk_level", "medium")
        icon = RISK_ICONS.get(risk, "🟡")
        ripple_id = r.get("id", "?")
        doc_type = r.get("target_type", r.get("doc_type", "?"))
        issue_title = r.get("issue_title", r.get("title", ""))
        change_type = r.get("change_type", "?")
        section = r.get("section", "?")

        lines.append(f"{icon} **#{ripple_id}** [{risk.upper()}] {doc_type}")
        if issue_title:
            lines.append(f"  {issue_title}")
        lines.append(f"  Change: {change_type} -> {section}")
        lines.append("")

    lines.append("---")
    lines.append("Use `remembril_ripple_approve` or `remembril_ripple_reject` to act on ripples.")
    return "\n".join(lines)


def format_ripple_diff(ripple: dict[str, Any]) -> str:
    """Format a ripple's changes as a diff view."""
    lines = [f"## Ripple #{ripple.get('id', '?')} — Change Diff\n"]

    changes = ripple.get("changes", [])
    if not changes:
        changes = [ripple] if ripple.get("change_type") else []

    for change in changes:
        target = change.get("target", change.get("target_doc", "?"))
        change_type = change.get("change_type", "?")
        section = change.get("section", "?")

        lines.append(f"**Target:** {target}")
        lines.append(f"**Type:** {change_type}")
        lines.append(f"**Section:** {section}")

        if change.get("full_requirement"):
            req = change["full_requirement"]
            lines.append(f"\n```json")
            import json
            lines.append(json.dumps(req, indent=2))
            lines.append("```")

        if change.get("before"):
            lines.append(f"\n**Before:**\n```\n{change['before']}\n```")
        if change.get("after"):
            lines.append(f"\n**After:**\n```\n{change['after']}\n```")

        lines.append("")

    return "\n".join(lines)
