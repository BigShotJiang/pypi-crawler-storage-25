"""Formatters for plain text fallback and A2UI (Google) output."""

from .tables import format_table
from .ripple_fmt import format_ripple_queue, format_ripple_diff
from .trace_fmt import format_traceability_matrix
from .pipeline_fmt import format_pipeline_status
from .review_fmt import (
    format_review_detail,
    format_review_list,
    format_debate_detail,
    format_watcher_alerts,
    format_personas,
)
from .a2ui import (
    build_a2ui_ripple_review,
    build_a2ui_traceability,
    build_a2ui_pipeline_dashboard,
    build_a2ui_design_preview,
    build_a2ui_agent_review,
    build_a2ui_watcher_alerts,
)
from .loop_fmt import format_loop_status

__all__ = [
    "format_table",
    "format_ripple_queue",
    "format_ripple_diff",
    "format_traceability_matrix",
    "format_pipeline_status",
    "format_review_detail",
    "format_review_list",
    "format_debate_detail",
    "format_watcher_alerts",
    "format_personas",
    "format_loop_status",
    "build_a2ui_ripple_review",
    "build_a2ui_traceability",
    "build_a2ui_pipeline_dashboard",
    "build_a2ui_design_preview",
    "build_a2ui_agent_review",
    "build_a2ui_watcher_alerts",
]
