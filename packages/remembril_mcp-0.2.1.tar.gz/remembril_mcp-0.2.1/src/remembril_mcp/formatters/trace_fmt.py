"""Traceability matrix formatting for plain text output."""

from typing import Any


def format_traceability_matrix(data: dict[str, Any]) -> str:
    """Format traceability matrix as a markdown table."""
    doc_types = data.get("doc_types", [])
    matrix = data.get("matrix", [])
    total = data.get("total_requirements", 0)
    fully = data.get("fully_traced", 0)
    pct = data.get("coverage_percent", 0)

    if not matrix:
        return "No requirements found in project documents."

    lines = [f"## Traceability Matrix\n"]
    lines.append(f"**{total}** requirements | **{fully}** fully traced | **{pct}%** coverage\n")

    # Table header
    headers = ["REQ ID"] + [dt.upper() for dt in doc_types] + ["Coverage"]
    widths = [max(12, max((len(r.get("req_id", "")) for r in matrix), default=6))]
    for dt in doc_types:
        widths.append(max(len(dt) + 2, 6))
    widths.append(8)

    header_line = "| " + " | ".join(
        h.ljust(widths[i]) for i, h in enumerate(headers)
    ) + " |"
    sep_line = "|" + "|".join("-" * (w + 2) for w in widths) + "|"

    lines.append(header_line)
    lines.append(sep_line)

    for row in matrix:
        cells = [row.get("req_id", "?").ljust(widths[0])]
        for i, dt in enumerate(doc_types):
            present = row.get(dt, False)
            mark = "  Y   " if present else "  -   "
            cells.append(mark.ljust(widths[i + 1]))
        coverage = f"{row.get('coverage_count', 0)}/{len(doc_types)}"
        cells.append(coverage.ljust(widths[-1]))
        lines.append("| " + " | ".join(cells) + " |")

    return "\n".join(lines)
