"""Markdown formatters for Remembril assistant mode tools."""

from typing import Any


def format_assist_narrative(results: dict[str, Any], intent: str) -> str:
    """Format multi-step assist workflow results as a narrative summary."""
    lines = [f"## Remembril: {intent}\n"]

    if results.get("auto_severity"):
        sev = results["auto_severity"]
        lines.append(f"*Severity: {sev['level']}* ({sev['reason']})\n")

    for step in results.get("steps_completed", []):
        if step == "issue":
            info = results.get("issue", {})
            key = info.get("key") or info.get("id", "?")
            lines.append(f"1. Created issue **{key}**")
        elif step == "ripples":
            info = results.get("ripples", {})
            count = info.get("count", 0)
            types = ", ".join(info.get("by_type", {}).keys())
            lines.append(f"2. Generated **{count} ripples** across: {types}")
        elif step == "pipeline":
            info = results.get("pipeline", {})
            applied = info.get("ripples_applied", 0)
            docs = info.get("documents_updated", 0)
            lines.append(
                f"3. Pipeline: {applied} ripples applied, {docs} docs updated"
            )
        elif step == "loop":
            info = results.get("loop", {})
            key = info.get("storm_key") or info.get("storm_id", "?")
            lines.append(f"4. Coding loop started: Storm **{key}**")

    if results.get("errors"):
        lines.append("\n### Issues encountered")
        for err in results["errors"]:
            lines.append(f"- {err}")

    if not results.get("steps_completed"):
        lines.append("No steps completed. See errors above.")

    return "\n".join(lines)


def format_context_narrative(context: dict[str, Any]) -> str:
    """Format project context as a readable overview."""
    lines = [f"## Project: {context.get('project_id', '?')}\n"]

    # Issues
    issues = context.get("issues", {})
    if isinstance(issues, dict) and not issues.get("error"):
        total = issues.get("total", 0)
        open_count = issues.get("open", 0)
        lines.append(f"**Issues:** {open_count} open / {total} total")
        recent = issues.get("recent", [])
        if recent:
            lines.append("")
            for iss in recent[:5]:
                key = iss.get("issue_key") or iss.get("id", "?")
                title = iss.get("title", "")
                sev = iss.get("severity", "")
                lines.append(f"  - [{sev}] {key}: {title}")
        lines.append("")
    elif isinstance(issues, dict) and issues.get("error"):
        lines.append(f"**Issues:** {issues['error']}\n")

    # Ripples
    ripples = context.get("ripples", {})
    if isinstance(ripples, dict) and not ripples.get("error"):
        pending = ripples.get("pending_ripples", 0)
        needing = ripples.get("issues_needing_ripples", 0)
        lines.append(f"**Pending ripples:** {pending}")
        if needing > 0:
            lines.append(f"**Issues without ripples:** {needing}")
        lines.append("")
    elif isinstance(ripples, dict) and ripples.get("error"):
        lines.append(f"**Ripples:** {ripples['error']}\n")

    # Documents
    docs = context.get("documents", {})
    if isinstance(docs, dict) and not docs.get("error"):
        total = docs.get("total", 0)
        lines.append(f"**Documents:** {total}")
        by_type = docs.get("by_type", {})
        if by_type:
            parts = [f"{t}: {c}" for t, c in sorted(by_type.items())]
            lines.append(f"  Types: {', '.join(parts)}")
        lines.append("")
    elif isinstance(docs, dict) and docs.get("error"):
        lines.append(f"**Documents:** {docs['error']}\n")

    # Suggestions
    suggestions = context.get("suggestions", [])
    if suggestions:
        lines.append("### Suggested actions")
        for s in suggestions:
            lines.append(f"- {s}")

    return "\n".join(lines)


def format_workflow_status(result: dict[str, Any]) -> str:
    """Format workflow status for a specific issue."""
    lines = []

    issue = result.get("issue", {})
    key = issue.get("key") or issue.get("id", "?")
    lines.append(f"## Workflow: {key}")
    lines.append(f"**{issue.get('title', '')}**")
    lines.append(f"Status: {issue.get('status', '?')} | Phase: {issue.get('phase', '?')}")
    lines.append("")

    ripples = result.get("ripples", {})
    total = ripples.get("total", 0)
    lines.append(f"### Ripples ({total})")
    if total > 0:
        lines.append(
            f"- Pending: {ripples.get('pending', 0)}"
            f" | Approved: {ripples.get('approved', 0)}"
            f" | Applied: {ripples.get('applied', 0)}"
            f" | Rejected: {ripples.get('rejected', 0)}"
        )
    lines.append("")

    phase = result.get("workflow_phase", "unknown")
    phase_labels = {
        "not_started": "Issue filed, no ripples generated yet",
        "ripples_pending": "Ripples generated, awaiting review",
        "ripples_approved": "Ripples approved, ready for pipeline",
        "applied": "All ripples applied to documents",
        "in_progress": "Coding loop is working on this",
        "complete": "Workflow complete",
    }
    label = phase_labels.get(phase, phase)
    lines.append(f"**Current phase:** {label}")

    return "\n".join(lines)


def group_by_type(items: list[dict], type_key: str = "target_type") -> dict[str, int]:
    """Group a list of dicts by a type field and count occurrences."""
    groups: dict[str, int] = {}
    for item in items:
        if isinstance(item, dict):
            t = item.get(type_key, "unknown")
            groups[t] = groups.get(t, 0) + 1
    return groups


def generate_suggestions(context: dict[str, Any]) -> list[str]:
    """Generate suggested next actions based on project context."""
    suggestions: list[str] = []

    ripples = context.get("ripples", {})
    if isinstance(ripples, dict):
        if ripples.get("issues_needing_ripples", 0) > 0:
            n = ripples["issues_needing_ripples"]
            suggestions.append(
                f"Generate ripples for {n} issue(s) without ripples"
            )
        if ripples.get("pending_ripples", 0) > 0:
            n = ripples["pending_ripples"]
            suggestions.append(f"Review {n} pending ripple(s)")

    issues = context.get("issues", {})
    if isinstance(issues, dict) and issues.get("open", 0) == 0:
        suggestions.append(
            "No open issues. Create one to track your next change."
        )

    docs = context.get("documents", {})
    if isinstance(docs, dict) and docs.get("total", 0) == 0:
        suggestions.append(
            "No documents yet. Run the pipeline to auto-create skeleton docs."
        )

    if not suggestions:
        suggestions.append(
            "Everything looks good. Create an issue when ready to start."
        )

    return suggestions


def determine_workflow_phase(
    issue: dict[str, Any], ripples: list[dict[str, Any]]
) -> str:
    """Determine which phase a workflow is in based on issue and ripple state."""
    if not ripples:
        return "not_started"

    statuses = [r.get("status", "") for r in ripples if isinstance(r, dict)]

    if all(s == "applied" for s in statuses):
        return "applied"
    if any(s == "in_progress" for s in statuses):
        return "in_progress"
    if any(s == "approved" for s in statuses) and not any(
        s == "pending" for s in statuses
    ):
        return "ripples_approved"
    if any(s == "pending" for s in statuses):
        return "ripples_pending"

    return "complete"
