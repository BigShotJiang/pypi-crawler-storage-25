"""A2UI declarative JSON formatters for Google/Gemini hosts."""

from typing import Any


def _tool_action(tool_name: str, **kwargs: Any) -> dict:
    """Build an onAction callback that invokes an MCP tool."""
    return {"tool": tool_name, "args": {k: v for k, v in kwargs.items() if v is not None}}


def build_a2ui_ripple_review(ripples: list[dict[str, Any]]) -> dict:
    """Build A2UI Card components for ripple review."""
    components = [
        {
            "id": "review-header",
            "type": "Text",
            "props": {"text": f"Ripple Review -- {len(ripples)} pending", "variant": "headline"}
        }
    ]

    risk_colors = {"low": "default", "medium": "warning", "high": "error", "critical": "error"}

    for r in ripples:
        ripple_id = r.get("id", "?")
        risk = r.get("risk_level", "medium")
        doc_type = r.get("target_type", r.get("doc_type", "?"))
        title = r.get("issue_title", r.get("title", ""))
        change_type = r.get("change_type", "?")
        section = r.get("section", "?")

        components.append({
            "id": f"ripple-{ripple_id}",
            "type": "Card",
            "props": {"elevation": 2},
            "children": [
                {"type": "Chip", "props": {"label": risk.upper(), "color": risk_colors.get(risk, "default")}},
                {"type": "Chip", "props": {"label": doc_type, "color": "default"}},
                {"type": "Text", "props": {"text": title}},
                {"type": "Text", "props": {"text": f"{change_type} -> {section}", "variant": "caption"}},
                {
                    "type": "Row",
                    "children": [
                        {
                            "id": f"approve-{ripple_id}", "type": "Button",
                            "props": {"label": "Approve", "variant": "filled", "color": "primary"},
                            "onAction": _tool_action("remembril_ripple_approve", ripple_id=ripple_id),
                        },
                        {
                            "id": f"reject-{ripple_id}", "type": "Button",
                            "props": {"label": "Reject", "variant": "outlined", "color": "error"},
                            "onAction": _tool_action("remembril_ripple_reject", ripple_id=ripple_id),
                        },
                        {
                            "id": f"diff-{ripple_id}", "type": "Button",
                            "props": {"label": "View Diff", "variant": "text"},
                            "onAction": _tool_action("remembril_ripple_diff", ripple_id=ripple_id),
                        },
                    ]
                }
            ]
        })

    return {"version": "0.8", "components": components}


def build_a2ui_traceability(data: dict[str, Any]) -> dict:
    """Build A2UI Table component for traceability matrix."""
    doc_types = data.get("doc_types", [])
    matrix = data.get("matrix", [])

    columns = [{"id": "req_id", "label": "REQ ID", "type": "text"}]
    for dt in doc_types:
        columns.append({"id": dt, "label": dt.upper(), "type": "boolean"})
    columns.append({"id": "coverage", "label": "Coverage", "type": "text"})

    rows = []
    for row in matrix:
        r = {"req_id": row.get("req_id", "?")}
        for dt in doc_types:
            r[dt] = row.get(dt, False)
        r["coverage"] = f"{row.get('coverage_count', 0)}/{len(doc_types)}"
        rows.append(r)

    return {
        "version": "0.8",
        "components": [
            {
                "id": "trace-header",
                "type": "Text",
                "props": {
                    "text": f"Traceability Matrix -- {data.get('coverage_percent', 0)}% coverage",
                    "variant": "headline"
                }
            },
            {
                "id": "trace-table",
                "type": "DataTable",
                "props": {"columns": columns, "rows": rows, "sortable": True}
            }
        ]
    }


def build_a2ui_design_preview(data: dict[str, Any]) -> dict:
    """Build A2UI components for design document preview."""
    doc_id = data.get("id", data.get("doc_id", "?"))
    summary = data.get("summary", "")
    doc_type = data.get("doc_type", "document")
    title = data.get("title", "")
    questions = data.get("questions", [])

    components: list[dict] = [
        {
            "id": "design-header",
            "type": "Text",
            "props": {"text": f"Design Preview -- {title or doc_type}", "variant": "headline"}
        },
    ]

    if summary:
        components.append({
            "id": "design-summary",
            "type": "Card",
            "props": {"elevation": 1},
            "children": [
                {"type": "Text", "props": {"text": summary}},
            ]
        })

    if questions:
        q_items = [{"type": "Text", "props": {"text": f"- {q}"}} for q in questions]
        components.append({
            "id": "design-questions",
            "type": "Card",
            "props": {"elevation": 1},
            "children": [
                {"type": "Text", "props": {"text": "Open Questions", "variant": "subheadline"}},
                *q_items,
            ]
        })

    components.append({
        "type": "Row",
        "children": [
            {
                "id": f"view-{doc_id}", "type": "Button",
                "props": {"label": "View Document", "variant": "outlined"},
                "onAction": _tool_action("remembril_doc_read", doc_id=doc_id),
            },
            {
                "id": f"regenerate-{doc_id}", "type": "Button",
                "props": {"label": "Regenerate", "variant": "filled", "color": "primary"},
                "onAction": _tool_action("remembril_design_chat", doc_id=doc_id, message="Regenerate this document"),
            },
        ]
    })

    return {"version": "0.8", "components": components}


def build_a2ui_agent_review(review: dict[str, Any]) -> dict:
    """Build A2UI components for agent review detail."""
    review_id = review.get("id", "?")
    status = review.get("status", "?")
    advisements = review.get("individual_advisements") or []
    joint = review.get("joint_advisement") or {}

    position_colors = {
        "approve": "primary",
        "approve_with_concerns": "warning",
        "request_changes": "warning",
        "block": "error",
        "abstain": "default",
    }

    components: list[dict] = [
        {
            "id": "review-header",
            "type": "Text",
            "props": {"text": f"Agent Review -- {status}", "variant": "headline"},
        },
    ]

    # Individual advisement cards
    for a in advisements:
        pos = a.get("position", "abstain")
        name = a.get("agent_name", a.get("agent_id", "?"))
        conf = a.get("confidence", 0)

        children: list[dict] = [
            {"type": "Chip", "props": {"label": pos, "color": position_colors.get(pos, "default")}},
            {"type": "Chip", "props": {"label": a.get("agent_type", "?"), "color": "default"}},
            {"type": "Text", "props": {"text": f"{name} ({conf:.0%} confidence)"}},
        ]
        if a.get("summary"):
            children.append({"type": "Text", "props": {"text": a["summary"], "variant": "caption"}})

        findings = a.get("findings", []) + a.get("concerns", [])
        if findings:
            for f in findings[:3]:
                children.append({"type": "Text", "props": {"text": f"- {f}", "variant": "caption"}})

        components.append({
            "id": f"agent-{a.get('agent_id', '?')}",
            "type": "Card",
            "props": {"elevation": 2},
            "children": children,
        })

    # Joint recommendation
    if joint:
        rec = joint.get("recommendation", joint.get("majority_position", "?"))
        summary = joint.get("recommendation_summary", "")
        joint_children: list[dict] = [
            {"type": "Chip", "props": {"label": f"JOINT: {rec}", "color": position_colors.get(rec, "default")}},
        ]
        if summary:
            joint_children.append({"type": "Text", "props": {"text": summary}})
        for item in joint.get("action_items", [])[:5]:
            joint_children.append({"type": "Text", "props": {"text": f"- {item}", "variant": "caption"}})

        components.append({
            "id": "joint-advisement",
            "type": "Card",
            "props": {"elevation": 3},
            "children": joint_children,
        })

    # Actions
    ripple_ids = review.get("extracted_ripple_ids") or []
    if ripple_ids:
        components.append({
            "type": "Row",
            "children": [
                {
                    "id": "approve-ripples", "type": "Button",
                    "props": {"label": f"Approve {len(ripple_ids)} Ripples", "variant": "filled", "color": "primary"},
                    "onAction": _tool_action("remembril_review_approve_ripples", review_id=review_id),
                },
                {
                    "id": "view-alerts", "type": "Button",
                    "props": {"label": "View Alerts", "variant": "outlined"},
                    "onAction": _tool_action("remembril_watcher_alerts", review_id=review_id),
                },
            ],
        })

    return {"version": "0.8", "components": components}


def build_a2ui_watcher_alerts(data: dict[str, Any]) -> dict:
    """Build A2UI components for watcher alerts."""
    items = data.get("items", [])
    severity_colors = {"info": "default", "warning": "warning", "critical": "error"}

    components: list[dict] = [
        {
            "id": "alerts-header",
            "type": "Text",
            "props": {"text": f"Watcher Alerts -- {len(items)} total", "variant": "headline"},
        },
    ]

    for a in items:
        severity = a.get("severity", "info")
        alert_type = a.get("alert_type", "?")
        handled = a.get("handled", False)

        children: list[dict] = [
            {"type": "Chip", "props": {"label": severity.upper(), "color": severity_colors.get(severity, "default")}},
            {"type": "Chip", "props": {"label": alert_type, "color": "default"}},
            {"type": "Text", "props": {"text": a.get("description", "")}},
        ]
        if a.get("involved_agents"):
            children.append({"type": "Text", "props": {"text": f"Agents: {', '.join(a['involved_agents'])}", "variant": "caption"}})

        if not handled:
            children.append({
                "type": "Row",
                "children": [{
                    "id": f"handle-{a.get('id', '?')}", "type": "Button",
                    "props": {"label": "Mark Handled", "variant": "outlined"},
                    "onAction": _tool_action("remembril_alert_handle", alert_id=a.get("id")),
                }],
            })

        components.append({
            "id": f"alert-{a.get('id', '?')}",
            "type": "Card",
            "props": {"elevation": 1 if handled else 2},
            "children": children,
        })

    return {"version": "0.8", "components": components}


def build_a2ui_pipeline_dashboard(data: dict[str, Any]) -> dict:
    """Build A2UI components for pipeline dashboard."""
    processed = data.get("issues_processed", 0)
    total = data.get("total_issues", processed)
    generated = data.get("ripples_generated", 0)
    approved = data.get("ripples_approved", 0)
    applied = data.get("ripples_applied", 0)
    project_id = data.get("project_id")

    return {
        "version": "0.8",
        "components": [
            {
                "id": "pipeline-header",
                "type": "Text",
                "props": {"text": f"Pipeline Status -- {data.get('status', 'running')}", "variant": "headline"}
            },
            {
                "id": "progress-issues",
                "type": "ProgressBar",
                "props": {"label": "Issues", "value": processed, "max": max(total, 1)}
            },
            {
                "id": "progress-ripples",
                "type": "ProgressBar",
                "props": {"label": "Ripples", "value": generated, "max": max(generated, 1)}
            },
            {
                "id": "progress-approved",
                "type": "ProgressBar",
                "props": {"label": "Approved", "value": approved, "max": max(generated, 1)}
            },
            {
                "id": "progress-applied",
                "type": "ProgressBar",
                "props": {"label": "Applied", "value": applied, "max": max(approved, 1)}
            },
            {
                "type": "Row",
                "children": [
                    {
                        "id": "view-ripples", "type": "Button",
                        "props": {"label": "View Pending Ripples", "variant": "outlined"},
                        "onAction": _tool_action("remembril_ripples_queue", project_id=project_id),
                    },
                    {
                        "id": "export-docs", "type": "Button",
                        "props": {"label": "Export Docs", "variant": "filled"},
                        "onAction": _tool_action("remembril_pipeline_generate_docs", project_id=project_id),
                    },
                ]
            }
        ]
    }
