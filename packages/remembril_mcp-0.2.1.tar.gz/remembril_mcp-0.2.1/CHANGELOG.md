# Changelog

All notable changes to `remembril-mcp` are documented here. This project
follows [Semantic Versioning](https://semver.org/).

## [0.2.0] — 2026-04-09

### Added

- **Graphify Bridge** — three new tools that integrate with
  [safishamsi/graphify](https://github.com/safishamsi/graphify) (PyPI
  `graphifyy`), an MIT tree-sitter + Leiden knowledge-graph builder:
  - `remembril_graphify_import` — parse a Graphify `graph.json` payload
    (or server-side path) and map it into Remembril's knowledge-graph
    node/edge model. Nodes get a `graphify:` prefix; code symbols land
    as `code_symbol` with their source file, location, and community id
    preserved in metadata.
  - `remembril_graphify_diff` — diff two Graphify snapshots and emit
    issue-shaped ripple payloads for added/removed nodes and edges.
    Grouped by file so a single touched file produces one payload
    instead of one per symbol. Severity tuned by relation type
    (calls/uses/imports → medium; removals → high).
  - `remembril_graphify_sync` — rebuild the Graphify graph for a project
    working directory and diff it against the previous snapshot.
    Requires `graphifyy` to be installed on the backend.

- **Pull-Based Work Loop** — four new tools that let an agent pull
  atomic droplets over MCP instead of being driven by a subprocess.
  Respects `depends_on_id` chains, so blocked droplets stay hidden
  until their dependency completes:
  - `remembril_loop_next_task`
  - `remembril_loop_claim_task`
  - `remembril_loop_checkpoint`
  - `remembril_loop_complete_task`

- **HTTP Transport** — `remembril-mcp serve --http --port 8080` now
  exposes a Starlette ASGI app with three endpoints:
  - `POST /mcp` — StreamableHTTP transport (stateless sessions)
  - `GET /sse` + `POST /messages/` — Server-Sent Events transport
  - `GET /health` — health check

  Required for Claude Desktop, ChatGPT, and Google Gemini hosts that
  don't support stdio subprocesses. Install with `pip install
  'remembril-mcp[http]'` to pull in `starlette` and `uvicorn`.

- **A2UI output tier** — Google Gemini-compatible declarative JSON for
  six tool groups: Cards, DataTable, ProgressBar, DesignPreview,
  AgentReview, WatcherAlerts. Every tool now emits in three tiers: MCP
  Apps widgets → A2UI JSON → plain-text markdown.

- **MCP Apps widget bundles** — five HTML widget bundles shipped with
  the package, referenced via the `_meta.ui.resourceUri` field on tool
  results:
  - `ripple-review` — approve/reject ripples with risk badges
  - `traceability` — cross-document coverage matrix
  - `pipeline-dashboard` — auto-pipeline progress bars
  - `design-preview` — AI document preview with code view
  - `agent-review` — committee cards, advisements, watcher alerts

### Changed

- **Default API URL** updated from `https://remembril-production.up.railway.app`
  to `https://www.remembril.com`.
- **Project homepage** updated to `https://www.remembril.com`.
- **Documentation URL** updated to point at the Stripe-style API docs
  site at `https://www.remembril.com/api-docs/mcp-tools.html`.
- **Tool count**: 50 → 57.

### Technical notes

- The Graphify bridge has no hard dependency on `graphifyy`. Import and
  diff endpoints work from JSON alone — only `sync` requires the
  upstream package.
- Graphify's NetworkX graph is undirected, so edges carry their
  authoritative endpoints as `_src` / `_tgt`. The bridge honors these
  over `source` / `target` so edge direction is preserved when mapping
  into Remembril's directed graph.
- HTTP transport uses `StreamableHTTPSessionManager` with a required
  lifespan context; raw ASGI handlers are `Mount()`ed rather than
  `Route()`d so FastAPI's dependency resolution doesn't interfere.

## [0.1.0] — 2025-12

Initial release.

- 50 tools across 8 categories: Issues, Ripples, Pipeline, Documents,
  Design, Review, Loop, Projects, Orchestration.
- stdio transport via `remembril-mcp serve`.
- CLI commands for login, project management, and interactive ripple
  review.
- MCP Apps widget bundles for ripple review, traceability, and
  pipeline dashboard.
