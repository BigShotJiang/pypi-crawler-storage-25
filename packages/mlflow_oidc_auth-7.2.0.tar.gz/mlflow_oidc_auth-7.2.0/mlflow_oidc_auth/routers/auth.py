"""
Authentication router for FastAPI application.

This router handles OIDC authentication flows including login, logout, and callback.
"""

import secrets
import time
from collections.abc import Awaitable
from typing import Any, Optional
from urllib.parse import urlencode

from authlib.jose.errors import BadSignatureError
from fastapi import APIRouter, HTTPException, Request
from fastapi.responses import JSONResponse, RedirectResponse

from mlflow_oidc_auth.audit import emit_audit_event
from mlflow_oidc_auth.config import config
from mlflow_oidc_auth.logger import get_logger
from mlflow_oidc_auth.oauth import is_oidc_configured, oauth
from mlflow_oidc_auth.utils import get_configured_or_dynamic_redirect_uri

from ._prefix import UI_ROUTER_PREFIX

logger = get_logger()

auth_router = APIRouter(
    tags=["auth"],
    responses={404: {"description": "Not found"}},
)

CALLBACK = "/callback"
LOGIN = "/login"
LOGOUT = "/logout"
AUTH_STATUS = "/auth/status"


async def _maybe_await(result: Any) -> Any:
    """Await the result when it's awaitable; otherwise return it directly."""

    if isinstance(result, Awaitable) or hasattr(result, "__await__"):
        return await result
    return result


async def _refresh_oidc_jwks() -> None:
    """Force a JWKS refresh on the OAuth client to handle key rotation."""

    refresh_fn = getattr(oauth.oidc, "fetch_jwk_set", None)
    metadata_refresh_fn = getattr(oauth.oidc, "load_server_metadata", None)

    try:
        if refresh_fn:
            await _maybe_await(refresh_fn(force=True))  # type: ignore[call-arg]
            return
        if metadata_refresh_fn:
            await _maybe_await(metadata_refresh_fn(force=True))  # type: ignore[call-arg]
    except Exception as exc:  # pragma: no cover - defensive logging path
        logger.warning(f"Failed to refresh OIDC JWKS after bad signature: {exc}")


async def _call_authorize_access_token(request: Request) -> Optional[dict[str, Any]]:
    """Invoke authorize_access_token while supporting sync or async implementations."""

    token_call = oauth.oidc.authorize_access_token(request)  # type: ignore
    return await _maybe_await(token_call)


async def _authorize_access_token_with_retry(
    request: Request,
) -> Optional[dict[str, Any]]:
    """Exchange code for tokens, retrying once after a JWKS refresh on any validation failure."""

    last_error: Optional[Exception] = None

    for attempt in range(2):
        try:
            return await _call_authorize_access_token(request)
        except BadSignatureError as exc:
            last_error = exc
            logger.warning(
                "OIDC token exchange attempt %d failed with bad signature: %s",
                attempt + 1,
                exc,
            )
            if attempt == 0:
                await _refresh_oidc_jwks()
                continue
            break
        except Exception as exc:
            last_error = exc
            logger.warning("OIDC token exchange attempt %d failed: %s", attempt + 1, exc)
            if attempt == 0:
                await _refresh_oidc_jwks()
                continue
            break

    if last_error:
        raise last_error
    return None


async def refresh_session_with_idp(session) -> bool:
    """Attempt to refresh an expired session against the IdP using the stored refresh token.

    Returns True on success (session updated in place with new ``expires_at`` and,
    when rotated, a new ``refresh_token``). Returns False on any failure — the
    caller is expected to clear the session and force re-authentication.

    No-op (returns False) when ``OIDC_USE_REFRESH_TOKEN`` is disabled or no
    refresh token is stored, so this is safe to call unconditionally from the
    middleware.
    """

    if not config.OIDC_USE_REFRESH_TOKEN:
        return False

    refresh_token = session.get("refresh_token") if session is not None else None
    if not refresh_token:
        return False

    fetch_fn = getattr(oauth.oidc, "fetch_access_token", None)
    if fetch_fn is None:
        logger.warning("OIDC client has no fetch_access_token; cannot refresh session")
        return False

    try:
        new_token = await _maybe_await(fetch_fn(grant_type="refresh_token", refresh_token=refresh_token))
    except Exception as exc:
        logger.warning("OIDC refresh token exchange failed: %s", exc)
        return False

    if not new_token:
        return False

    _persist_session_auth(session, new_token)
    return True


def _extract_session_expiry(token_response: dict[str, Any]) -> Optional[int]:
    """Extract the session expiry timestamp (Unix seconds) from an OIDC token response.

    Prefers ``expires_at`` (set by Authlib from ``expires_in``), then the ``exp``
    claim of the validated id_token, then falls back to computing
    ``now + expires_in``. Returns None when no expiry information is available
    (in which case the caller should leave the session unchanged so behaviour
    matches the legacy ~14-day cookie window).
    """

    expires_at = token_response.get("expires_at")
    if isinstance(expires_at, (int, float)) and expires_at > 0:
        return int(expires_at)

    userinfo = token_response.get("userinfo") or {}
    id_token_exp = userinfo.get("exp")
    if isinstance(id_token_exp, (int, float)) and id_token_exp > 0:
        return int(id_token_exp)

    expires_in = token_response.get("expires_in")
    if isinstance(expires_in, (int, float)) and expires_in > 0:
        return int(time.time()) + int(expires_in)

    return None


def _persist_session_auth(session, token_response: dict[str, Any]) -> None:
    """Store IdP-issued expiry (and optionally the refresh token) in the session.

    Called after a successful OIDC token exchange. ``OIDC_USE_REFRESH_TOKEN``
    gates persistence of the refresh token because storing one in a signed
    (but not encrypted) cookie has security implications, and many enterprises
    disallow ``offline_access`` outright.
    """

    expiry = _extract_session_expiry(token_response)
    if expiry is not None:
        session["expires_at"] = expiry
    else:
        # No reliable expiry from the IdP; remove any stale value from a prior login.
        session.pop("expires_at", None)

    if config.OIDC_USE_REFRESH_TOKEN:
        refresh_token = token_response.get("refresh_token")
        if refresh_token:
            session["refresh_token"] = refresh_token
        # If the response has no refresh_token, keep the existing one. Many
        # IdPs only emit refresh_token on the initial token exchange and reuse
        # it across subsequent refreshes (Microsoft Entra, some Keycloak
        # configs, etc.). Popping it here would break the next refresh.
    else:
        session.pop("refresh_token", None)


def _sanitize_next(value: Optional[str]) -> Optional[str]:
    """Validate a ``next`` redirect target. Only same-origin relative paths are
    accepted to prevent open-redirect attacks. Returns None on rejection.

    Accepts: ``/users``, ``/oidc/ui/groups``, ``/#/experiments/0``.
    Rejects: ``http://evil``, ``//evil``, ``javascript:...``, anything not starting
    with a single ``/``.
    """

    if not value:
        return None
    if not isinstance(value, str):
        return None
    if not value.startswith("/"):
        return None
    if value.startswith("//"):  # protocol-relative URL — would escape origin
        return None
    if "\n" in value or "\r" in value:  # header-injection guard
        return None
    return value


def _build_ui_url(request: Request, path: str, query_params: Optional[dict] = None) -> str:
    """
    Build a UI URL with the correct prefix and optional query parameters.

    Args:
        request: FastAPI request object
        path: The UI route path (e.g., "/auth", "/home")
        query_params: Optional dictionary of query parameters

    Returns:
        Complete URL string for the UI route
    """
    base_url = str(request.base_url).rstrip("/")
    url = f"{base_url}{UI_ROUTER_PREFIX}{path}"

    if query_params:
        query_string = urlencode(query_params, doseq=True)
        url = f"{url}?{query_string}"

    return url


@auth_router.get(LOGIN)
async def login(request: Request):
    """
    Initiate OIDC login flow.

    This endpoint redirects the user to the OIDC provider for authentication.

    Args:
        request: FastAPI request object

    Returns:
        Redirect response to OIDC provider
    """
    logger.info("Starting OIDC login flow")

    try:
        # Check if OIDC is properly configured before proceeding
        if not is_oidc_configured():
            logger.error("OIDC is not properly configured")
            raise HTTPException(
                status_code=500,
                detail="OIDC authentication not available - configuration error",
            )

        # Get session for storing OAuth state (using Starlette's built-in session)
        session = request.session

        # Generate OAuth state for CSRF protection
        oauth_state = secrets.token_urlsafe(32)
        session["oauth_state"] = oauth_state

        # Capture an optional ?next= return target so the callback can return
        # the user to where they were before the session expired. Validated to
        # be a same-origin relative path; anything else is dropped silently.
        next_target = _sanitize_next(request.query_params.get("next"))
        if next_target:
            session["redirect_after_login"] = next_target

        # Get redirect URI (configured or dynamic). Use a safe fallback if dynamic calculation fails
        try:
            redirect_url = get_configured_or_dynamic_redirect_uri(
                request=request,
                callback_path=CALLBACK,
                configured_uri=config.OIDC_REDIRECT_URI,
            )
        except Exception as e:
            logger.warning(f"Failed to get dynamic redirect URI: {e}")
            # Fallback to base_url + callback when request.url or other internals are not available in tests
            base = str(getattr(request, "base_url", "http://localhost:8000"))
            redirect_url = base.rstrip("/") + CALLBACK

        logger.debug(f"OIDC redirect URL: {redirect_url}")

        # Redirect to OIDC provider
        try:
            if not hasattr(oauth.oidc, "authorize_redirect"):
                logger.error("OIDC client authorize_redirect method not available")
                raise HTTPException(status_code=500, detail="OIDC authentication not available")

            return await oauth.oidc.authorize_redirect(  # type: ignore
                request,
                redirect_uri=redirect_url,
                state=oauth_state,
            )
        except HTTPException:
            raise
        except Exception as e:
            logger.error(f"Failed to initiate OAuth redirect: {e}")
            raise HTTPException(status_code=500, detail="Failed to initiate OIDC login")

    except HTTPException:
        # Preserve explicit HTTPExceptions raised above
        raise
    except Exception as e:
        logger.error(f"Error initiating OIDC login: {e}")
        raise HTTPException(status_code=500, detail="Failed to initiate OIDC login")


@auth_router.get(LOGOUT)
async def logout(request: Request):
    """
    Handle user logout.

    This endpoint clears the user session and optionally redirects to OIDC logout.

    Args:
        request: FastAPI request object

    Returns:
        Redirect response or logout confirmation
    """
    logger.info("Processing user logout")

    try:
        # Get and clear session (using Starlette's built-in session)
        session = request.session
        username = session.get("username")
        session.clear()

        if username:
            logger.info(f"User {username} logged out successfully")
            emit_audit_event("auth.logout", actor=username)

        # Check if OIDC provider supports logout
        if hasattr(oauth.oidc, "server_metadata"):
            metadata = getattr(oauth.oidc, "server_metadata", {})
            end_session_endpoint = metadata.get("end_session_endpoint")

            if end_session_endpoint:
                # Redirect to OIDC provider logout with post-logout redirect to auth page
                post_logout_redirect = _build_ui_url(request, "/auth")
                logout_url = f"{end_session_endpoint}?post_logout_redirect_uri={post_logout_redirect}"
                return RedirectResponse(url=logout_url, status_code=302)

        # Default redirect to auth page using the helper function
        auth_url = _build_ui_url(request, "/auth")
        return RedirectResponse(url=auth_url, status_code=302)

    except Exception as e:
        logger.error(f"Error during logout: {e}")
        # Still clear session even if redirect fails - redirect to auth page
        auth_url = _build_ui_url(request, "/auth")
        return RedirectResponse(url=auth_url, status_code=302)


@auth_router.get(CALLBACK)
async def callback(request: Request):
    """
    Handle OIDC callback after authentication.

    This endpoint processes the OIDC callback, validates the token,
    and establishes a user session.

    Args:
        request: FastAPI request object

    Returns:
        Redirect response to home page or error page
    """
    logger.info("Processing OIDC callback")

    try:
        # Ensure OIDC client is registered (critical for multi-replica deployments)
        # This handles the case where callback hits a replica that hasn't registered the client yet
        if not is_oidc_configured():
            logger.error("OIDC is not properly configured when processing callback")
            auth_error_url = _build_ui_url(
                request,
                "/auth",
                {"error": ["OIDC authentication not available - configuration error"]},
            )
            return RedirectResponse(url=auth_error_url, status_code=302)

        # Get session (using Starlette's built-in session)
        session = request.session

        # Process OIDC callback using FastAPI-native implementation
        email, errors = await _process_oidc_callback_fastapi(request, session)

        if errors:
            # Handle authentication errors
            logger.error(f"OIDC callback errors: {errors}")

            # Redirect to auth page with error parameters for frontend display
            auth_error_url = _build_ui_url(request, "/auth", {"error": errors})

            logger.debug(f"Redirecting to auth error page: {auth_error_url}")
            return RedirectResponse(url=auth_error_url, status_code=302)

        if email:
            # Successful authentication
            session["username"] = email
            session["authenticated"] = True

            logger.info(f"User {email} authenticated successfully via OIDC")
            emit_audit_event("auth.login", actor=email, detail={"method": "oidc"})

            # Redirect to UI home page or original destination
            default_redirect = session.pop("redirect_after_login", None)
            if not default_redirect:
                if config.DEFAULT_LANDING_PAGE_IS_PERMISSIONS:
                    default_redirect = _build_ui_url(request, "/user")
                else:
                    default_redirect = str(request.base_url).rstrip("/")

            return RedirectResponse(url=default_redirect, status_code=302)
        else:
            # Authentication failed without specific errors
            logger.error("OIDC authentication failed without specific errors")
            raise HTTPException(status_code=401, detail="Authentication failed")

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Unexpected error in OIDC callback: {e}")
        raise HTTPException(status_code=500, detail="Internal server error during authentication")


@auth_router.get(AUTH_STATUS)
async def auth_status(request: Request):
    """
    Get current authentication status.

    This endpoint returns information about the current user's authentication state.

    Args:
        request: FastAPI request object

    Returns:
        JSON response with authentication status
    """
    try:
        session = request.session
        username = session.get("username")
        is_authenticated = bool(username)

        return JSONResponse(
            content={
                "authenticated": is_authenticated,
                "username": username,
                "provider": config.OIDC_PROVIDER_DISPLAY_NAME if is_authenticated else None,
            }
        )

    except Exception as e:
        logger.error(f"Error getting auth status: {e}")
        raise HTTPException(status_code=500, detail="Failed to get authentication status")


async def _process_oidc_callback_fastapi(request: Request, session) -> tuple[Optional[str], list[str]]:
    """
    Process the OIDC callback logic using FastAPI-native implementation.

    Args:
        request: FastAPI request object
        session: SessionManager instance

    Returns:
        Tuple of (email, error_list)
    """
    import html

    errors = []

    # Handle OIDC error response
    error_param = request.query_params.get("error")
    error_description = request.query_params.get("error_description")
    if error_param:
        safe_desc = html.escape(error_description) if error_description else ""
        errors.append("OIDC provider error")
        if safe_desc:
            errors.append(f"{safe_desc}")
        return None, errors

    # State check for CSRF protection
    state = request.query_params.get("state")
    stored_state = session.get("oauth_state")
    if not stored_state:
        errors.append("Missing OAuth state in session")
        return None, errors
    if state != stored_state:
        errors.append("Invalid state parameter")
        return None, errors

    # Clear the OAuth state after validation
    session.pop("oauth_state", None)

    # Get authorization code
    code = request.query_params.get("code")
    if not code:
        errors.append("No authorization code received")
        return None, errors

    try:
        # Exchange authorization code for tokens
        if not hasattr(oauth.oidc, "authorize_access_token"):
            errors.append("OIDC configuration error: OAuth client not properly initialized.")
            return None, errors

        token_response = await _authorize_access_token_with_retry(request)

        if not token_response:
            errors.append("Failed to exchange authorization code")
            return None, errors

        # Validate the token and get user info
        access_token = token_response.get("access_token")
        id_token = token_response.get("id_token")
        userinfo = token_response.get("userinfo")

        if not userinfo:
            errors.append("No user information received")
            return None, errors

        # Extract user details
        email = userinfo.get("email") or userinfo.get("preferred_username")
        display_name = userinfo.get("name")

        if not email:
            errors.append("No email provided in OIDC userinfo")
            return None, errors
        if not display_name:
            errors.append("No display name provided in OIDC userinfo")
            return None, errors

        # Handle user and group management
        try:
            # Use module-level config (possibly patched in tests) and call user management
            # functions via the mlflow_oidc_auth.user module so test monkeypatches apply.
            import importlib

            import mlflow_oidc_auth.user as user_module

            # Get user groups
            if config.OIDC_GROUP_DETECTION_PLUGIN:
                user_groups = importlib.import_module(config.OIDC_GROUP_DETECTION_PLUGIN).get_user_groups(access_token)
            else:
                user_groups = userinfo.get(config.OIDC_GROUPS_ATTRIBUTE, [])

            logger.debug(f"User groups: {user_groups}")

            # Check authorization
            # Determine admin and allowed groups
            is_admin = any(group in user_groups for group in config.OIDC_ADMIN_GROUP_NAME)
            if not is_admin and not any(group in user_groups for group in config.OIDC_GROUP_NAME):
                errors.append("User is not allowed to login")
                return None, errors

            # Create/update user and groups using user_module so monkeypatched functions are used in tests
            user_module.create_user(username=email.lower(), display_name=display_name, is_admin=is_admin)
            user_module.populate_groups(group_names=user_groups)
            user_module.update_user(username=email.lower(), group_names=user_groups)

            # Workspace detection (per D-07, D-08, WSOIDC-01/02/03)
            # Layered approach: plugin first, JWT claim fallback, then auto-assign
            if config.MLFLOW_ENABLE_WORKSPACES:
                user_workspaces: list[str] = []
                if config.OIDC_WORKSPACE_DETECTION_PLUGIN:
                    try:
                        user_workspaces = importlib.import_module(config.OIDC_WORKSPACE_DETECTION_PLUGIN).get_user_workspaces(access_token)
                    except Exception as ws_plugin_err:
                        logger.warning(f"Workspace detection plugin error: {ws_plugin_err}")
                else:
                    # JWT claim fallback
                    claim_value = userinfo.get(config.OIDC_WORKSPACE_CLAIM_NAME, [])
                    if isinstance(claim_value, str):
                        user_workspaces = [claim_value]
                    elif isinstance(claim_value, list):
                        user_workspaces = [str(w) for w in claim_value]

                # Auto-create workspaces that don't exist yet (WSOIDC-04)
                try:
                    from mlflow.server.handlers import _get_workspace_store

                    ws_mlflow_store = _get_workspace_store()
                except Exception as ws_store_err:
                    logger.warning(f"Cannot access MLflow workspace store for auto-create: {ws_store_err}")
                    ws_mlflow_store = None

                # Auto-assign workspace memberships
                from mlflow_oidc_auth.store import store as ws_store

                for ws_name in user_workspaces:
                    if not ws_name:
                        continue

                    # Auto-create workspace if it doesn't exist (WSOIDC-04)
                    if ws_mlflow_store is not None:
                        try:
                            ws_mlflow_store.get_workspace(ws_name)
                        except Exception:
                            # Workspace doesn't exist — try to create it
                            try:
                                from mlflow.store.workspace import (
                                    Workspace as MlflowWorkspace,
                                )

                                ws_mlflow_store.create_workspace(
                                    MlflowWorkspace(name=ws_name, description=""),
                                )
                                logger.info(f"Auto-created workspace '{ws_name}' during OIDC login for user {email}")
                            except Exception as create_err:
                                # Creation may fail if name is invalid or race condition
                                logger.warning(f"Failed to auto-create workspace '{ws_name}': {create_err}")

                    # Assign permission (existing logic)
                    try:
                        ws_store.create_workspace_permission(
                            ws_name,
                            email.lower(),
                            config.OIDC_WORKSPACE_DEFAULT_PERMISSION,
                        )
                        logger.info(f"Auto-assigned user {email} to workspace '{ws_name}' with {config.OIDC_WORKSPACE_DEFAULT_PERMISSION}")
                    except Exception:
                        # Permission already exists — not an error (idempotent)
                        logger.debug(f"Workspace permission already exists for {email} in '{ws_name}'")

            logger.info(f"User {email} successfully processed with groups: {user_groups}")

        except Exception as e:
            logger.error(f"User/group management error: {str(e)}")
            errors.append("Failed to update user/groups")
            return None, errors

        _persist_session_auth(session, token_response)

        return email.lower(), []

    except Exception as e:
        logger.error(
            "OIDC token exchange error (%s.%s): %s",
            type(e).__module__,
            type(e).__name__,
            str(e),
        )
        errors.append("Failed to process authentication response")
        return None, errors
