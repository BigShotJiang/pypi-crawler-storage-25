# Contributing to AutoReadme

Thanks for your interest. This is a young project — issues, reproductions, and
PRs are all welcome.

## Development setup

```bash
git clone https://github.com/atharvakadam/autoreadme-ai
cd autoreadme-ai
uv sync --all-extras
```

## Checks before opening a PR

```bash
uv run ruff check src/ tests/
uv run ruff format --check src/ tests/
uv run mypy src/
uv run pytest
```

CI runs these on Python 3.11, 3.12, and 3.13.

The default `pytest` run does not hit any LLM API. End-to-end tests gated on
`@pytest.mark.requires_api_key` are opt-in:

```bash
ANTHROPIC_API_KEY=... uv run pytest -m requires_api_key
```

## Scope

Before adding a feature, skim [SPEC.md](SPEC.md). §15 ("Explicit Non-Goals for
v0.1") lists things we are deliberately *not* building for the first release —
please open a discussion issue before writing code against those.

## Guiding principles

- **No source code to the LLM.** The payload schema has no field for function
  bodies. If your change touches `generation/prompts.py`, preserve that.
- **No section is better than a wrong section.** Prefer skipping over guessing.
- **Static analysis only.** We use `ast` — no runtime introspection, no code
  execution.

## Commit messages

One-line subject, imperative mood. If the change needs more explanation, add a
body that says *why*, not just *what*.

## Reporting bugs

Open an issue with:
- `autoreadme --version`
- Your Python version
- A minimal repo (or `pyproject.toml` + one file) that reproduces the problem
- What you expected vs. what happened

Output from `--show-payload` is often the most useful thing you can attach —
it's the exact input we sent to the LLM, no source code included.
