"""Unit tests for the provider abstraction (SPEC §6).

SDKs are mocked via sys.modules so these tests pass without any optional extras
installed. We assert: factory dispatch, missing-credentials/missing-SDK error
shapes, success paths, and SDK-exception wrapping into ProviderError.
"""

from __future__ import annotations

import json
import sys
import types
from typing import Any

import pytest

from autoreadme.providers import LLMProvider, ProviderError, get_provider

# ---------- Factory ----------


def test_factory_rejects_unknown_provider() -> None:
    with pytest.raises(ProviderError, match="unknown provider"):
        get_provider("does-not-exist", model="x", api_key="y")


# ---------- Anthropic ----------


def _install_fake_anthropic(
    monkeypatch: pytest.MonkeyPatch, *, response_text: str = "hello"
) -> None:
    fake = types.ModuleType("anthropic")

    class APIError(Exception):
        pass

    class FakeMessages:
        @staticmethod
        def create(**kwargs: Any) -> Any:
            return types.SimpleNamespace(
                content=[types.SimpleNamespace(type="text", text=response_text)]
            )

    class FakeClient:
        def __init__(self, *, api_key: str) -> None:
            self.api_key = api_key
            self.messages = FakeMessages()

    fake.APIError = APIError  # type: ignore[attr-defined]
    fake.Anthropic = FakeClient  # type: ignore[attr-defined]
    monkeypatch.setitem(sys.modules, "anthropic", fake)


def test_anthropic_missing_api_key_raises() -> None:
    with pytest.raises(ProviderError, match="ANTHROPIC_API_KEY"):
        get_provider("anthropic", model="claude-x", api_key=None)


def test_anthropic_missing_sdk_raises(monkeypatch: pytest.MonkeyPatch) -> None:
    # Sentinel-None in sys.modules causes `import anthropic` to raise ImportError.
    monkeypatch.setitem(sys.modules, "anthropic", None)
    with pytest.raises(ProviderError, match="anthropic SDK not installed"):
        get_provider("anthropic", model="claude-x", api_key="sk-x")


def test_anthropic_generate_returns_text(monkeypatch: pytest.MonkeyPatch) -> None:
    _install_fake_anthropic(monkeypatch, response_text="README prose")
    p = get_provider("anthropic", model="claude-x", api_key="sk-x")
    assert isinstance(p, LLMProvider)
    assert p.generate("prompt") == "README prose"


def test_anthropic_empty_response_raises(monkeypatch: pytest.MonkeyPatch) -> None:
    _install_fake_anthropic(monkeypatch, response_text="")
    p = get_provider("anthropic", model="claude-x", api_key="sk-x")
    with pytest.raises(ProviderError, match="empty response"):
        p.generate("prompt")


def test_anthropic_api_error_wrapped(monkeypatch: pytest.MonkeyPatch) -> None:
    fake = types.ModuleType("anthropic")

    class APIError(Exception):
        pass

    class FakeMessages:
        @staticmethod
        def create(**kwargs: Any) -> Any:
            raise APIError("boom")

    class FakeClient:
        def __init__(self, *, api_key: str) -> None:
            self.messages = FakeMessages()

    fake.APIError = APIError  # type: ignore[attr-defined]
    fake.Anthropic = FakeClient  # type: ignore[attr-defined]
    monkeypatch.setitem(sys.modules, "anthropic", fake)

    p = get_provider("anthropic", model="claude-x", api_key="sk-x")
    with pytest.raises(ProviderError, match="anthropic API error"):
        p.generate("prompt")


# ---------- OpenAI ----------


def _install_fake_openai(monkeypatch: pytest.MonkeyPatch, *, response_text: str = "hello") -> None:
    fake = types.ModuleType("openai")

    class OpenAIError(Exception):
        pass

    class FakeCompletions:
        @staticmethod
        def create(**kwargs: Any) -> Any:
            return types.SimpleNamespace(
                choices=[
                    types.SimpleNamespace(message=types.SimpleNamespace(content=response_text))
                ]
            )

    class FakeChat:
        def __init__(self) -> None:
            self.completions = FakeCompletions()

    class FakeClient:
        def __init__(self, *, api_key: str) -> None:
            self.api_key = api_key
            self.chat = FakeChat()

    fake.OpenAIError = OpenAIError  # type: ignore[attr-defined]
    fake.OpenAI = FakeClient  # type: ignore[attr-defined]
    monkeypatch.setitem(sys.modules, "openai", fake)


def test_openai_missing_api_key_raises() -> None:
    with pytest.raises(ProviderError, match="OPENAI_API_KEY"):
        get_provider("openai", model="gpt-4o", api_key=None)


def test_openai_missing_sdk_raises(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setitem(sys.modules, "openai", None)
    with pytest.raises(ProviderError, match="openai SDK not installed"):
        get_provider("openai", model="gpt-4o", api_key="sk-y")


def test_openai_generate_returns_text(monkeypatch: pytest.MonkeyPatch) -> None:
    _install_fake_openai(monkeypatch, response_text="openai prose")
    p = get_provider("openai", model="gpt-4o", api_key="sk-y")
    assert p.generate("prompt") == "openai prose"


def test_openai_api_error_wrapped(monkeypatch: pytest.MonkeyPatch) -> None:
    fake = types.ModuleType("openai")

    class OpenAIError(Exception):
        pass

    class FakeCompletions:
        @staticmethod
        def create(**kwargs: Any) -> Any:
            raise OpenAIError("boom")

    class FakeChat:
        def __init__(self) -> None:
            self.completions = FakeCompletions()

    class FakeClient:
        def __init__(self, *, api_key: str) -> None:
            self.chat = FakeChat()

    fake.OpenAIError = OpenAIError  # type: ignore[attr-defined]
    fake.OpenAI = FakeClient  # type: ignore[attr-defined]
    monkeypatch.setitem(sys.modules, "openai", fake)

    p = get_provider("openai", model="gpt-4o", api_key="sk-y")
    with pytest.raises(ProviderError, match="openai API error"):
        p.generate("prompt")


# ---------- Ollama ----------


class _FakeHTTPResponse:
    def __init__(self, payload: dict[str, Any]) -> None:
        self._body = json.dumps(payload).encode("utf-8")

    def read(self) -> bytes:
        return self._body

    def __enter__(self) -> _FakeHTTPResponse:
        return self

    def __exit__(self, *exc: object) -> None:
        return None


def test_ollama_generate_returns_response(monkeypatch: pytest.MonkeyPatch) -> None:
    captured: dict[str, Any] = {}

    def fake_urlopen(req: Any, timeout: float) -> _FakeHTTPResponse:
        captured["url"] = req.full_url
        captured["body"] = json.loads(req.data.decode("utf-8"))
        return _FakeHTTPResponse({"response": "ollama prose"})

    monkeypatch.setattr("autoreadme.providers.ollama.urllib.request.urlopen", fake_urlopen)

    p = get_provider("ollama", model="llama3.1", api_key="http://my-host:11434")
    assert p.generate("hello") == "ollama prose"
    assert captured["url"] == "http://my-host:11434/api/generate"
    assert captured["body"] == {"model": "llama3.1", "prompt": "hello", "stream": False}


def test_ollama_uses_default_host_when_no_key_or_env(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.delenv("OLLAMA_HOST", raising=False)
    captured: dict[str, Any] = {}

    def fake_urlopen(req: Any, timeout: float) -> _FakeHTTPResponse:
        captured["url"] = req.full_url
        return _FakeHTTPResponse({"response": "ok"})

    monkeypatch.setattr("autoreadme.providers.ollama.urllib.request.urlopen", fake_urlopen)
    p = get_provider("ollama", model="llama3.1", api_key=None)
    p.generate("hi")
    assert captured["url"].startswith("http://localhost:11434")


def test_ollama_url_error_wrapped(monkeypatch: pytest.MonkeyPatch) -> None:
    import urllib.error

    def raise_url_error(req: Any, timeout: float) -> _FakeHTTPResponse:
        raise urllib.error.URLError("connection refused")

    monkeypatch.setattr("autoreadme.providers.ollama.urllib.request.urlopen", raise_url_error)
    p = get_provider("ollama", model="llama3.1", api_key="http://nowhere:1")
    with pytest.raises(ProviderError, match="cannot reach"):
        p.generate("x")


def test_ollama_empty_response_raises(monkeypatch: pytest.MonkeyPatch) -> None:
    def fake_urlopen(req: Any, timeout: float) -> _FakeHTTPResponse:
        return _FakeHTTPResponse({"response": ""})

    monkeypatch.setattr("autoreadme.providers.ollama.urllib.request.urlopen", fake_urlopen)
    p = get_provider("ollama", model="llama3.1", api_key="http://x")
    with pytest.raises(ProviderError, match="empty response"):
        p.generate("x")
