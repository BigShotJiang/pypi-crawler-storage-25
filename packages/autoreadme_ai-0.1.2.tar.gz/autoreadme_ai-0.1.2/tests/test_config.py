"""Unit tests for config resolution (SPEC §5)."""

from __future__ import annotations

from pathlib import Path

from autoreadme.config import (
    CONFIG_FILENAME,
    DEFAULT_MODELS,
    Config,
    load_config,
)


def _write(path: Path, content: str) -> None:
    path.write_text(content, encoding="utf-8")


# ---------- Defaults ----------


def test_defaults_with_empty_env_and_no_file(tmp_path: Path) -> None:
    cfg = load_config(tmp_path, env={})
    assert cfg.provider == "anthropic"
    assert cfg.model == DEFAULT_MODELS["anthropic"]
    assert cfg.api_key is None
    assert cfg.excludes == []
    assert cfg.sources["provider"] == "default"
    assert cfg.sources["model"] == "default"
    assert cfg.sources["api_key"] == "missing"
    assert cfg.warnings == []


# ---------- Precedence: CLI > file > env > default ----------


def test_cli_overrides_everything(tmp_path: Path) -> None:
    _write(
        tmp_path / CONFIG_FILENAME,
        '[llm]\nprovider = "openai"\nmodel = "gpt-4o-mini"\n',
    )
    cfg = load_config(
        tmp_path,
        cli_provider="ollama",
        cli_model="llama3.2",
        env={"ANTHROPIC_API_KEY": "sk-x"},
    )
    assert cfg.provider == "ollama"
    assert cfg.sources["provider"] == "cli"
    assert cfg.model == "llama3.2"
    assert cfg.sources["model"] == "cli"


def test_file_overrides_env_auto_detect(tmp_path: Path) -> None:
    _write(tmp_path / CONFIG_FILENAME, '[llm]\nprovider = "openai"\n')
    cfg = load_config(tmp_path, env={"ANTHROPIC_API_KEY": "sk-x", "OPENAI_API_KEY": "sk-y"})
    assert cfg.provider == "openai"
    assert cfg.sources["provider"] == "file"
    # model falls through to default for the chosen provider
    assert cfg.model == DEFAULT_MODELS["openai"]
    assert cfg.sources["model"] == "default"


def test_env_auto_detect_priority_anthropic_first(tmp_path: Path) -> None:
    env = {"ANTHROPIC_API_KEY": "a", "OPENAI_API_KEY": "b", "OLLAMA_HOST": "http://x"}
    cfg = load_config(tmp_path, env=env)
    assert cfg.provider == "anthropic"
    assert cfg.sources["provider"] == "env"


def test_env_auto_detect_openai_when_anthropic_absent(tmp_path: Path) -> None:
    cfg = load_config(tmp_path, env={"OPENAI_API_KEY": "sk-y"})
    assert cfg.provider == "openai"
    assert cfg.api_key == "sk-y"
    assert cfg.sources["api_key"] == "env"


def test_env_auto_detect_ollama_when_only_host_set(tmp_path: Path) -> None:
    cfg = load_config(tmp_path, env={"OLLAMA_HOST": "http://localhost:11434"})
    assert cfg.provider == "ollama"
    assert cfg.api_key == "http://localhost:11434"


# ---------- Unknown/bad input → warnings, not failures ----------


def test_unknown_provider_falls_back_to_default(tmp_path: Path) -> None:
    _write(tmp_path / CONFIG_FILENAME, '[llm]\nprovider = "made-up"\n')
    cfg = load_config(tmp_path, env={})
    assert cfg.provider == "anthropic"
    assert cfg.sources["provider"] == "default"
    assert any("unknown provider" in w for w in cfg.warnings)


def test_unknown_section_warns(tmp_path: Path) -> None:
    _write(tmp_path / CONFIG_FILENAME, "[weird]\nfoo = 1\n")
    cfg = load_config(tmp_path, env={})
    assert any("unknown section [weird]" in w for w in cfg.warnings)


def test_unknown_field_warns(tmp_path: Path) -> None:
    _write(tmp_path / CONFIG_FILENAME, '[llm]\nmystery = "x"\n')
    cfg = load_config(tmp_path, env={})
    assert any("[llm].mystery" in w for w in cfg.warnings)


def test_malformed_toml_warns_and_uses_defaults(tmp_path: Path) -> None:
    _write(tmp_path / CONFIG_FILENAME, "this = is = broken\n")
    cfg = load_config(tmp_path, env={})
    assert cfg.provider == "anthropic"
    assert any("parse error" in w for w in cfg.warnings)


def test_wrong_type_warns_and_is_ignored(tmp_path: Path) -> None:
    _write(tmp_path / CONFIG_FILENAME, "[llm]\nprovider = 42\n")
    cfg = load_config(tmp_path, env={})
    assert cfg.provider == "anthropic"
    assert any("must be a string" in w for w in cfg.warnings)


def test_extract_exclude_passthrough(tmp_path: Path) -> None:
    _write(
        tmp_path / CONFIG_FILENAME,
        '[extract]\nexclude = ["docs/**", "scratch/**"]\n',
    )
    cfg = load_config(tmp_path, env={})
    assert cfg.excludes == ["docs/**", "scratch/**"]
    assert cfg.sources["excludes"] == "file"


def test_extract_exclude_wrong_type_warns(tmp_path: Path) -> None:
    _write(tmp_path / CONFIG_FILENAME, '[extract]\nexclude = "nope"\n')
    cfg = load_config(tmp_path, env={})
    assert cfg.excludes == []
    assert any("must be a list of strings" in w for w in cfg.warnings)


# ---------- Shape ----------


def test_returned_config_is_dataclass(tmp_path: Path) -> None:
    cfg = load_config(tmp_path, env={})
    assert isinstance(cfg, Config)
    assert set(cfg.sources) == {"provider", "model", "api_key", "excludes"}
