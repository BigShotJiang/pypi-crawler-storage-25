def broken(
    x: int,
    y: int
