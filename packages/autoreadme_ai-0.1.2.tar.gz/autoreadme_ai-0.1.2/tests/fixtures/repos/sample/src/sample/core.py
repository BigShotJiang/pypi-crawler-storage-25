"""Core compute logic."""


def compute(values: list[int]) -> int:
    """Sum ``values`` and return the total."""
    return sum(values)
