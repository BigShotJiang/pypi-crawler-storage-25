"""Sample CLI using argparse."""

import argparse

from .core import compute


def main() -> None:
    parser = argparse.ArgumentParser(prog="sample", description="Sum some numbers.")
    parser.add_argument("values", nargs="+", type=int, help="Values to sum")
    args = parser.parse_args()
    print(compute(args.values))


if __name__ == "__main__":
    main()
