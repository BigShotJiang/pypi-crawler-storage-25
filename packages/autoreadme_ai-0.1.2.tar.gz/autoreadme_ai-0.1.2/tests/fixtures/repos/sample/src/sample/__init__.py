"""Sample package root."""

from .core import compute

__all__ = ["compute"]
