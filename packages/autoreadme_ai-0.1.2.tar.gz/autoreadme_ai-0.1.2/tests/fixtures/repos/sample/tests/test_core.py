from sample.core import compute


def test_compute() -> None:
    assert compute([1, 2, 3]) == 6
