"""Typical click CLI."""

import click


@click.command()
@click.argument("path")
@click.option("--output", "-o", default="out.txt", help="Output path")
@click.option("--verbose", "-v", is_flag=True, help="Verbose logging")
@click.option("--count", type=int, required=True, help="Count")
def run(path: str, output: str, verbose: bool, count: int) -> None:
    """Process widgets."""
    click.echo(path)


if __name__ == "__main__":
    run()
