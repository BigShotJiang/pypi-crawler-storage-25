"""Single-function typer.run() style CLI."""

import typer


def main(name: str, greeting: str = "Hello") -> None:
    """Greet NAME."""
    typer.echo(f"{greeting}, {name}!")


if __name__ == "__main__":
    typer.run(main)
