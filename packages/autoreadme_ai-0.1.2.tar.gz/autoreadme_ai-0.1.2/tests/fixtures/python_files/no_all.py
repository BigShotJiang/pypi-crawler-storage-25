"""Module without __all__ — public API is inferred from naming."""


def public_fn(x: int) -> int:
    return x


def _private_fn() -> None:
    pass


class PublicClass:
    pass


class _PrivateClass:
    pass
