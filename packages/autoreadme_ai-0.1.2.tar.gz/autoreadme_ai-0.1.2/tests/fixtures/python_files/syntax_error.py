"""Intentionally broken to exercise the SyntaxError path."""

def broken(
    x: int,
    y: int
   # missing closing paren
