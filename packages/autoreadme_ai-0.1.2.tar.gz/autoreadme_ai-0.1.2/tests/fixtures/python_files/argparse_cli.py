"""Typical argparse CLI."""

import argparse


def main() -> None:
    parser = argparse.ArgumentParser(
        prog="mytool",
        description="Process widgets.",
    )
    parser.add_argument("path", help="Input path", type=str)
    parser.add_argument("--output", "-o", help="Output path", default="out.txt")
    parser.add_argument("--verbose", "-v", action="store_true", help="Verbose logging")
    parser.add_argument(
        "--mode",
        choices=["fast", "safe"],
        default="safe",
        help="Processing mode",
    )
    parser.add_argument("--count", type=int, required=True, help="Count")
    args = parser.parse_args()
    print(args)


if __name__ == "__main__":
    main()
