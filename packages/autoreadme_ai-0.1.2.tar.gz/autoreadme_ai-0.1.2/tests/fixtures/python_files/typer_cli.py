"""Typical typer CLI."""

import typer

app = typer.Typer()


@app.command()
def run(
    path: str = typer.Argument(..., help="Input path"),
    output: str = typer.Option("out.txt", "--output", "-o", help="Output path"),
    verbose: bool = typer.Option(False, "--verbose", "-v", help="Verbose logging"),
) -> None:
    """Process widgets."""
    typer.echo(path)


@app.command()
def stats(detail: bool = False) -> None:
    """Print stats."""
    typer.echo("stats")


if __name__ == "__main__":
    app()
