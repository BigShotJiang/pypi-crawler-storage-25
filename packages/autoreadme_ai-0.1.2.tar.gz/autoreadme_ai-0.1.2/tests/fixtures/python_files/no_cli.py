"""A library module with no CLI."""


def add(a: int, b: int) -> int:
    return a + b
