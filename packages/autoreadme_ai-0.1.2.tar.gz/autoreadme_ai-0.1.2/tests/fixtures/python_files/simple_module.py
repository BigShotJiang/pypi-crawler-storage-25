"""A toy module for testing Python extraction.

Multi-line module docstring used by extractor tests.
"""

from __future__ import annotations

import json
import os
from pathlib import Path

__all__ = ["Greeter", "greet"]


def greet(name: str, *, loud: bool = False) -> str:
    """Return a greeting for ``name``.

    If ``loud`` is True, the result is uppercased.
    """
    message = f"Hello, {name}!"
    return message.upper() if loud else message


def _internal_helper(x: int) -> int:
    return x * 2


async def fetch(url: str, timeout: float = 5.0) -> bytes:
    """Async fetch stub."""
    return b""


class Greeter:
    """Small greeter."""

    def __init__(self, prefix: str = "Hello") -> None:
        self.prefix = prefix

    def greet(self, name: str) -> str:
        return f"{self.prefix}, {name}!"

    async def greet_async(self, name: str) -> str:
        return f"{self.prefix}, {name}!"


class _Private:
    """Should not appear in public_api when __all__ is set."""

    def method(self) -> None:
        pass


if __name__ == "__main__":
    print(greet("world"))
