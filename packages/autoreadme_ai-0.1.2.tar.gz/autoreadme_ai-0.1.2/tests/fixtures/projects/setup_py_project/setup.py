from setuptools import setup

setup(
    name="legacylib",
    version="0.9.0",
    description="A legacy package.",
    python_requires=">=3.8",
    license="Apache-2.0",
    install_requires=[
        "requests",
        "six",
    ],
    entry_points={
        "console_scripts": [
            "legacy-tool = legacylib.main:run",
        ],
    },
    classifiers=[
        "License :: OSI Approved :: Apache Software License",
    ],
)
