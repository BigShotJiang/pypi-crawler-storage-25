"""Unit tests for diff.py — diff construction, coloring, prompt loop (SPEC §4.4)."""

from __future__ import annotations

import io

from rich.console import Console

from autoreadme.diff import Choice, build_diff, prompt_apply, render_colored


def _console(buf: io.StringIO) -> Console:
    # force_terminal so color codes are emitted; width so lines don't wrap.
    return Console(file=buf, force_terminal=True, width=200, color_system="standard")


def test_build_diff_empty_when_identical() -> None:
    assert build_diff("hello\n", "hello\n").is_empty


def test_build_diff_nonempty_when_different() -> None:
    d = build_diff("hello\n", "world\n")
    assert not d.is_empty
    assert "-hello" in d.text
    assert "+world" in d.text


def test_build_diff_normalizes_missing_final_newline() -> None:
    # Old file has no trailing newline; must not produce "No newline at end
    # of file" markers in the actual diff body.
    d = build_diff("hello", "hello\nworld\n")
    assert "No newline" not in d.text


def test_render_colored_emits_ansi_for_additions() -> None:
    buf = io.StringIO()
    d = build_diff("a\n", "a\nb\n")
    render_colored(d, _console(buf))
    out = buf.getvalue()
    # "+b" line should carry ANSI green codes.
    assert "\x1b[" in out
    assert "+b" in out


def test_prompt_apply_default_yes() -> None:
    buf = io.StringIO()
    d = build_diff("a\n", "b\n")
    assert prompt_apply(d, console=_console(buf), input_stream=io.StringIO("\n")) is Choice.APPLY


def test_prompt_apply_n_rejects() -> None:
    buf = io.StringIO()
    d = build_diff("a\n", "b\n")
    assert prompt_apply(d, console=_console(buf), input_stream=io.StringIO("n\n")) is Choice.REJECT


def test_prompt_apply_q_quits() -> None:
    buf = io.StringIO()
    d = build_diff("a\n", "b\n")
    assert prompt_apply(d, console=_console(buf), input_stream=io.StringIO("q\n")) is Choice.QUIT


def test_prompt_apply_eof_quits() -> None:
    buf = io.StringIO()
    d = build_diff("a\n", "b\n")
    assert prompt_apply(d, console=_console(buf), input_stream=io.StringIO("")) is Choice.QUIT


def test_prompt_apply_reprompts_on_unknown() -> None:
    buf = io.StringIO()
    d = build_diff("a\n", "b\n")
    result = prompt_apply(d, console=_console(buf), input_stream=io.StringIO("zzz\ny\n"))
    assert result is Choice.APPLY
    assert "Please answer" in buf.getvalue()
