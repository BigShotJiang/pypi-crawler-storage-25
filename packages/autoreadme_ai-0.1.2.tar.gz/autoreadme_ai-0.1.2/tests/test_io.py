"""Unit tests for io.py — read/write/backup/symlink guards (SPEC §9)."""

from __future__ import annotations

import os
import sys
from pathlib import Path

import pytest

from autoreadme.io import IOError_, read_readme, write_readme


def test_read_returns_none_when_missing(tmp_path: Path) -> None:
    assert read_readme(tmp_path / "README.md") is None


def test_read_returns_text(tmp_path: Path) -> None:
    p = tmp_path / "README.md"
    p.write_text("hello\n", encoding="utf-8")
    assert read_readme(p) == "hello\n"


@pytest.mark.skipif(sys.platform.startswith("win"), reason="symlink perms on Windows")
def test_read_refuses_symlink(tmp_path: Path) -> None:
    target = tmp_path / "real.md"
    target.write_text("x", encoding="utf-8")
    link = tmp_path / "README.md"
    os.symlink(target, link)
    with pytest.raises(IOError_, match="symlink"):
        read_readme(link)


def test_write_creates_file_without_backup_when_new(tmp_path: Path) -> None:
    p = tmp_path / "README.md"
    result = write_readme(p, "hi\n")
    assert p.read_text(encoding="utf-8") == "hi\n"
    assert result.backup is None


def test_write_backs_up_existing(tmp_path: Path) -> None:
    p = tmp_path / "README.md"
    p.write_text("old", encoding="utf-8")
    result = write_readme(p, "new")
    assert p.read_text(encoding="utf-8") == "new"
    assert result.backup is not None
    assert result.backup.read_text(encoding="utf-8") == "old"
    assert result.backup.name == "README.md.bak"


def test_write_overwrites_previous_backup(tmp_path: Path) -> None:
    p = tmp_path / "README.md"
    bak = tmp_path / "README.md.bak"
    p.write_text("v2", encoding="utf-8")
    bak.write_text("STALE", encoding="utf-8")
    write_readme(p, "v3")
    assert bak.read_text(encoding="utf-8") == "v2"


def test_write_backup_false_skips_backup(tmp_path: Path) -> None:
    p = tmp_path / "README.md"
    p.write_text("old", encoding="utf-8")
    result = write_readme(p, "new", backup=False)
    assert result.backup is None
    assert not (tmp_path / "README.md.bak").exists()


@pytest.mark.skipif(sys.platform.startswith("win"), reason="symlink perms on Windows")
def test_write_refuses_symlink(tmp_path: Path) -> None:
    target = tmp_path / "real.md"
    target.write_text("x", encoding="utf-8")
    link = tmp_path / "README.md"
    os.symlink(target, link)
    with pytest.raises(IOError_, match="symlink"):
        write_readme(link, "new")
