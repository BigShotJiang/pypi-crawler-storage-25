"""Unit tests for the generation layer (SPEC 2.3, 2.4, 3.2, 7.1).

LLM is fully mocked. We assert on the *prompt shape* and the orchestrator's
contracts — not on generated prose, which is the LLM's job.
"""

from __future__ import annotations

import io
import json

import pytest

from autoreadme.generation import (
    SECTION_NAMES,
    GenerationError,
    apply_sections,
    build_payload,
    build_prompt,
    extract_sections,
    generate_readme,
    marker_end,
    marker_start,
)
from autoreadme.models import (
    ClassDef,
    CLICommand,
    CLIFramework,
    CLISpec,
    EntryPoint,
    EntryPointKind,
    ExtractionStats,
    FileMetadata,
    FunctionSignature,
    Parameter,
    ProjectMetadata,
    RepoMetadata,
)
from autoreadme.providers import ProviderError


def _repo() -> RepoMetadata:
    fn = FunctionSignature(
        name="do_thing",
        parameters=[Parameter(name="x", type_hint="int")],
        return_type="str",
        docstring="Do a thing.",
    )
    cls = ClassDef(name="Widget", docstring="A widget.", methods=[fn])
    file = FileMetadata(
        path="src/pkg/core.py",
        module_docstring="Core module.",
        imports=["os", "sys"],
        public_api=["do_thing", "Widget"],
        functions=[fn],
        classes=[cls],
    )
    cli_spec = CLISpec(
        framework=CLIFramework.TYPER,
        entry_file="src/pkg/cli.py",
        command=CLICommand(name="pkg", help="Run pkg"),
    )
    return RepoMetadata(
        root="/tmp/demo",
        project=ProjectMetadata(
            name="demo",
            version="0.1.0",
            description="a demo",
            dependencies=["typer>=0.12"],
            python_requires=">=3.11",
        ),
        files=[file],
        entry_points=[
            EntryPoint(name="demo", kind=EntryPointKind.SCRIPT, module="pkg.cli", attribute="app")
        ],
        cli_specs=[cli_spec],
        stats=ExtractionStats(files_analyzed=1, public_symbols=2),
    )


# ---------- Payload ----------


def test_payload_contains_project_and_file_metadata() -> None:
    payload = build_payload(_repo())
    assert payload["project"]["name"] == "demo"
    assert payload["project"]["version"] == "0.1.0"
    assert payload["stats"]["files_analyzed"] == 1
    assert len(payload["files"]) == 1
    f = payload["files"][0]
    assert f["path"] == "src/pkg/core.py"
    assert f["public_api"] == ["do_thing", "Widget"]
    assert f["functions"][0]["name"] == "do_thing"
    assert f["functions"][0]["parameters"][0]["name"] == "x"


def test_payload_has_no_source_body_fields() -> None:
    """SPEC §2.4 — payload must be structurally incapable of leaking source bodies."""
    payload = build_payload(_repo())
    serialized = json.dumps(payload)
    for forbidden in ("body", "source", "src_text", "raw"):
        assert f'"{forbidden}"' not in serialized


def test_payload_is_json_serializable() -> None:
    payload = build_payload(_repo())
    json.dumps(payload)  # no default= needed


# ---------- Prompt ----------


def test_prompt_embeds_payload_and_template_contract() -> None:
    payload = build_payload(_repo())
    prompt = build_prompt(payload, badges_markdown="![PyPI](http://example/pypi.svg)")
    assert "![PyPI](http://example/pypi.svg)" in prompt
    assert "autoreadme:install:start" in prompt
    assert "autoreadme:install:end" in prompt
    for name in SECTION_NAMES:
        assert name in prompt
    assert '"name": "demo"' in prompt
    # Anti-hallucination directive
    assert "No section is" in prompt or "no section is" in prompt.lower()


def test_prompt_handles_empty_badges_gracefully() -> None:
    prompt = build_prompt(build_payload(_repo()), badges_markdown="")
    assert "no badges detected" in prompt


# ---------- Template / markers ----------


def test_extract_sections_roundtrip() -> None:
    src = (
        f"{marker_start('install')}\n## Install\n```\npip install x\n```\n{marker_end('install')}\n"
        "## Manual\nkeep me\n"
        f"{marker_start('usage')}\n## Usage\nfoo\n{marker_end('usage')}\n"
    )
    sections = extract_sections(src)
    assert set(sections) == {"install", "usage"}
    assert "pip install x" in sections["install"]


def test_apply_sections_replaces_only_marked_regions() -> None:
    existing = (
        f"# Title\n\n{marker_start('install')}\nOLD INSTALL\n{marker_end('install')}\n"
        "\n## Docker (manual)\nkeep me\n"
        f"\n{marker_start('usage')}\nOLD USAGE\n{marker_end('usage')}\n"
    )
    merged = apply_sections(
        existing,
        {"install": "\nNEW INSTALL\n", "usage": "\nNEW USAGE\n"},
    )
    assert "OLD INSTALL" not in merged
    assert "OLD USAGE" not in merged
    assert "NEW INSTALL" in merged
    assert "NEW USAGE" in merged
    assert "## Docker (manual)\nkeep me" in merged
    assert merged.startswith("# Title")


def test_apply_sections_ignores_sections_not_present_in_existing() -> None:
    existing = f"{marker_start('install')}\nx\n{marker_end('install')}\n"
    merged = apply_sections(existing, {"install": "\ny\n", "license": "\nMIT\n"})
    assert "\ny\n" in merged
    assert "license" not in merged


def test_markers_inside_fenced_code_blocks_are_ignored() -> None:
    existing = (
        f"{marker_start('install')}\nreal\n{marker_end('install')}\n"
        "\n## Docs\n\n"
        "```markdown\n"
        f"{marker_start('install')}\nexample\n{marker_end('install')}\n"
        "```\n"
    )
    assert extract_sections(existing) == {"install": "\nreal\n"}
    merged = apply_sections(existing, {"install": "\nNEW\n"})
    assert "real" not in merged
    assert "\nNEW\n" in merged
    fenced = f"```markdown\n{marker_start('install')}\nexample\n{marker_end('install')}\n```"
    assert fenced in merged


def test_fences_with_tildes_are_also_respected() -> None:
    existing = f"~~~\n{marker_start('install')}\nexample\n{marker_end('install')}\n~~~\n"
    assert extract_sections(existing) == {}
    assert apply_sections(existing, {"install": "\nNEW\n"}) == existing


# ---------- Generator ----------


class _FakeProvider:
    def __init__(self, response: str) -> None:
        self._response = response
        self.seen_prompt: str | None = None

    def generate(self, prompt: str) -> str:
        self.seen_prompt = prompt
        return self._response


def test_generate_readme_calls_provider_and_returns_result() -> None:
    repo = _repo()
    provider = _FakeProvider("# demo\n\nHello world\n")
    log = io.StringIO()

    result = generate_readme(
        repo,
        provider,
        show_payload=False,
        provider_name="anthropic",
        model_name="claude-x",
        log=log,
    )

    assert result.readme == "# demo\n\nHello world"
    assert '"name": "demo"' in (provider.seen_prompt or "")
    assert "Sending" in log.getvalue()
    assert "anthropic" in log.getvalue()
    assert "claude-x" in log.getvalue()
    assert "No source code included" in log.getvalue()


def test_generate_readme_show_payload_skips_llm(capsys: pytest.CaptureFixture[str]) -> None:
    repo = _repo()
    provider = _FakeProvider("UNUSED")

    result = generate_readme(repo, provider, show_payload=True)

    captured = capsys.readouterr()
    assert provider.seen_prompt is None
    assert result.readme == ""
    parsed = json.loads(captured.out)
    assert parsed["project"]["name"] == "demo"


def test_generate_readme_aborts_when_payload_exceeds_budget() -> None:
    repo = _repo()
    provider = _FakeProvider("x")
    with pytest.raises(GenerationError, match="payload too large"):
        generate_readme(repo, provider, token_budget=1, log=io.StringIO())


def test_generate_readme_rejects_empty_response() -> None:
    repo = _repo()
    provider = _FakeProvider("   \n  ")
    with pytest.raises(GenerationError, match="empty response"):
        generate_readme(repo, provider, log=io.StringIO())


def test_generate_readme_propagates_provider_error() -> None:
    class _Boom:
        def generate(self, prompt: str) -> str:
            raise ProviderError("nope")

    with pytest.raises(ProviderError, match="nope"):
        generate_readme(_repo(), _Boom(), log=io.StringIO())
