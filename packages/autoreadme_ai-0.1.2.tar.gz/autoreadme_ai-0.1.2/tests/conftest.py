"""Shared test fixtures."""

from __future__ import annotations

from pathlib import Path

import pytest

FIXTURES = Path(__file__).parent / "fixtures"


@pytest.fixture
def python_fixtures_dir() -> Path:
    return FIXTURES / "python_files"


@pytest.fixture
def project_fixtures_dir() -> Path:
    return FIXTURES / "projects"


@pytest.fixture
def repo_fixtures_dir() -> Path:
    return FIXTURES / "repos"
