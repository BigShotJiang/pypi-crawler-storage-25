"""CLI surface tests — flags, exit codes, merge behavior (SPEC §4).

LLM is mocked by monkeypatching `get_provider`; extraction runs for real over
a tiny repo fixture built per-test so we're exercising the full integration
path except the network call.
"""

from __future__ import annotations

from pathlib import Path

import pytest
from typer.testing import CliRunner

from autoreadme import cli as cli_mod
from autoreadme.cli import app
from autoreadme.generation import marker_end, marker_start

runner = CliRunner()


# ---------- Fixture ----------


def _make_repo(tmp_path: Path) -> Path:
    (tmp_path / "pyproject.toml").write_text(
        '[project]\nname = "demo"\nversion = "0.1.0"\n'
        'description = "a demo"\nrequires-python = ">=3.11"\n',
        encoding="utf-8",
    )
    src = tmp_path / "src" / "demo"
    src.mkdir(parents=True)
    (src / "__init__.py").write_text('"""Demo."""\n', encoding="utf-8")
    (src / "core.py").write_text(
        '"""Core module."""\n\n\n'
        "def hello(name: str) -> str:\n"
        '    """Greet."""\n'
        '    return f"hi {name}"\n',
        encoding="utf-8",
    )
    return tmp_path


def _generated_readme() -> str:
    return (
        "# demo\n\n"
        f"{marker_start('install')}\n```\npip install demo\n```\n{marker_end('install')}\n\n"
        f"{marker_start('usage')}\nUSAGE v1\n{marker_end('usage')}\n"
    )


def _patch_provider(monkeypatch: pytest.MonkeyPatch, response: str) -> None:
    class _Fake:
        def generate(self, prompt: str) -> str:
            return response

    monkeypatch.setattr(cli_mod, "get_provider", lambda *a, **kw: _Fake())
    monkeypatch.setenv("ANTHROPIC_API_KEY", "sk-test")


# ---------- Tests ----------


def test_version_flag_prints_and_exits() -> None:
    result = runner.invoke(app, ["--version"])
    assert result.exit_code == 0
    assert "autoreadme" in result.stdout


def test_not_a_directory_exits_usage(tmp_path: Path) -> None:
    f = tmp_path / "not_a_dir"
    f.write_text("x")
    result = runner.invoke(app, [str(f)])
    assert result.exit_code == 2
    assert "not a directory" in result.stderr.lower()


def test_missing_api_key_exits_usage(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    _make_repo(tmp_path)
    for k in ("ANTHROPIC_API_KEY", "OPENAI_API_KEY", "OLLAMA_HOST"):
        monkeypatch.delenv(k, raising=False)
    result = runner.invoke(app, [str(tmp_path)])
    assert result.exit_code == 2
    assert "api key" in result.stderr.lower()


def test_dry_run_writes_to_stdout(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    _make_repo(tmp_path)
    _patch_provider(monkeypatch, _generated_readme())
    result = runner.invoke(app, [str(tmp_path), "--dry-run", "--force"])
    assert result.exit_code == 0, result.stderr
    assert "# demo" in result.stdout
    assert not (tmp_path / "README.md").exists()


def test_force_writes_readme_and_creates_no_backup_on_first_run(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    _make_repo(tmp_path)
    _patch_provider(monkeypatch, _generated_readme())
    result = runner.invoke(app, [str(tmp_path), "--force"])
    assert result.exit_code == 0, result.stderr
    readme = (tmp_path / "README.md").read_text(encoding="utf-8")
    assert readme.startswith("# demo")
    assert not (tmp_path / "README.md.bak").exists()


def test_second_run_preserves_manual_content_between_markers(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    _make_repo(tmp_path)
    existing = (
        "# demo\n\n"
        f"{marker_start('install')}\nOLD\n{marker_end('install')}\n\n"
        "## Manual section\nkeep me\n\n"
        f"{marker_start('usage')}\nOLD USAGE\n{marker_end('usage')}\n"
    )
    (tmp_path / "README.md").write_text(existing, encoding="utf-8")

    _patch_provider(monkeypatch, _generated_readme())
    result = runner.invoke(app, [str(tmp_path), "--force"])
    assert result.exit_code == 0, result.stderr

    merged = (tmp_path / "README.md").read_text(encoding="utf-8")
    assert "## Manual section\nkeep me" in merged
    assert "OLD USAGE" not in merged
    assert "USAGE v1" in merged
    assert (tmp_path / "README.md.bak").read_text(encoding="utf-8") == existing


def test_non_tty_without_force_exits_usage(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    _make_repo(tmp_path)
    _patch_provider(monkeypatch, _generated_readme())
    # CliRunner's stdin is not a TTY by default.
    result = runner.invoke(app, [str(tmp_path)])
    assert result.exit_code == 2
    assert "tty" in result.stderr.lower()


def test_show_payload_skips_llm_and_exits(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    _make_repo(tmp_path)

    called = {"n": 0}

    class _Boom:
        def generate(self, prompt: str) -> str:
            called["n"] += 1
            return "SHOULD NOT BE CALLED"

    monkeypatch.setattr(cli_mod, "get_provider", lambda *a, **kw: _Boom())
    monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)

    result = runner.invoke(app, [str(tmp_path), "--show-payload"])
    assert result.exit_code == 0, result.stderr
    assert called["n"] == 0
    assert '"project"' in result.stdout


def test_empty_repo_exits_extract(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    # No Python files — extraction yields 0 analyzed files.
    monkeypatch.setenv("ANTHROPIC_API_KEY", "sk-test")
    result = runner.invoke(app, [str(tmp_path), "--force"])
    assert result.exit_code == 3
    assert "no analyzable" in result.stderr.lower()


def test_up_to_date_reports_and_exits_ok(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    _make_repo(tmp_path)
    generated = _generated_readme()
    # Write what generation will produce (plus trailing newline) so merge → no diff.
    (tmp_path / "README.md").write_text(
        generated if generated.endswith("\n") else generated + "\n", encoding="utf-8"
    )
    _patch_provider(monkeypatch, generated)
    result = runner.invoke(app, [str(tmp_path), "--force"])
    assert result.exit_code == 0, result.stderr
    assert "up to date" in result.stderr.lower()
    assert not (tmp_path / "README.md.bak").exists()
