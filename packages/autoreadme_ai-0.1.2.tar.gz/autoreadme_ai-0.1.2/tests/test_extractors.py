"""Unit tests for the extraction layer."""

from __future__ import annotations

from pathlib import Path

import pytest

from autoreadme.extractors import extract_repo
from autoreadme.extractors.project import (
    discover_entry_points,
    extract_project_metadata,
)
from autoreadme.extractors.python import PythonExtractor
from autoreadme.models import (
    CLIFramework,
    EntryPointKind,
    ParameterKind,
)

# ---------- PythonExtractor ----------


def test_simple_module_extraction(python_fixtures_dir: Path) -> None:
    ex = PythonExtractor()
    fm = ex.extract(python_fixtures_dir / "simple_module.py", repo_root=python_fixtures_dir)

    assert fm.path == "simple_module.py"
    assert fm.module_docstring is not None
    assert "toy module" in fm.module_docstring
    assert fm.has_main_block is True
    assert fm.public_api == ["Greeter", "greet"]

    names = {f.name for f in fm.functions}
    assert {"greet", "_internal_helper", "fetch"} <= names

    greet = next(f for f in fm.functions if f.name == "greet")
    assert greet.docstring is not None
    assert greet.return_type == "str"
    assert greet.is_public is True

    # name: str, *, loud: bool = False
    assert [p.name for p in greet.parameters] == ["name", "loud"]
    assert greet.parameters[0].kind == ParameterKind.POSITIONAL_OR_KEYWORD
    assert greet.parameters[0].type_hint == "str"
    assert greet.parameters[0].default is None
    assert greet.parameters[1].kind == ParameterKind.KEYWORD_ONLY
    assert greet.parameters[1].default == "False"

    fetch = next(f for f in fm.functions if f.name == "fetch")
    assert fetch.is_async is True
    assert fetch.return_type == "bytes"

    private = next(f for f in fm.functions if f.name == "_internal_helper")
    assert private.is_public is False

    class_names = {c.name for c in fm.classes}
    assert class_names == {"Greeter", "_Private"}
    greeter = next(c for c in fm.classes if c.name == "Greeter")
    assert greeter.is_public is True
    method_names = {m.name for m in greeter.methods}
    assert {"__init__", "greet", "greet_async"} <= method_names
    greet_async = next(m for m in greeter.methods if m.name == "greet_async")
    assert greet_async.is_async is True

    priv_class = next(c for c in fm.classes if c.name == "_Private")
    assert priv_class.is_public is False

    # imports are top-level package names, deduplicated and sorted
    assert fm.imports == ["json", "os", "pathlib"]


def test_public_api_inference_without_dunder_all(python_fixtures_dir: Path) -> None:
    fm = PythonExtractor().extract(python_fixtures_dir / "no_all.py", repo_root=python_fixtures_dir)
    assert fm.public_api == ["public_fn", "PublicClass"]
    public_fn = next(f for f in fm.functions if f.name == "public_fn")
    assert public_fn.is_public is True
    private_fn = next(f for f in fm.functions if f.name == "_private_fn")
    assert private_fn.is_public is False


def test_syntax_error_propagates(python_fixtures_dir: Path) -> None:
    """SyntaxError must escape the extractor — orchestrator handles it."""
    with pytest.raises(SyntaxError):
        PythonExtractor().extract(
            python_fixtures_dir / "syntax_error.py", repo_root=python_fixtures_dir
        )


def test_constants_extraction(tmp_path: Path) -> None:
    src = tmp_path / "mod.py"
    src.write_text(
        "API_KEY_ENV = 'ANTHROPIC_API_KEY'\n"
        "MAX_RETRIES = 3\n"
        "DEFAULT_HOST: str = 'http://localhost:11434'\n"
        "PROVIDERS = {'a': 'A_KEY', 'b': 'B_KEY'}\n"
        "_PRIVATE = 'nope'\n"
        "DYNAMIC = some_call()\n"
        "a, b = 1, 2\n",
        encoding="utf-8",
    )
    fm = PythonExtractor().extract(src, repo_root=tmp_path)
    by_name = {c.name: c for c in fm.constants}
    assert set(by_name) == {"API_KEY_ENV", "MAX_RETRIES", "DEFAULT_HOST", "PROVIDERS"}
    assert by_name["API_KEY_ENV"].value == "'ANTHROPIC_API_KEY'"
    assert by_name["MAX_RETRIES"].value == "3"
    assert by_name["DEFAULT_HOST"].type_hint == "str"
    assert "'A_KEY'" in by_name["PROVIDERS"].value


def test_constants_truncate_long_values(tmp_path: Path) -> None:
    src = tmp_path / "mod.py"
    giant = "x" * 500
    src.write_text(f"BIG = '{giant}'\n", encoding="utf-8")
    fm = PythonExtractor().extract(src, repo_root=tmp_path)
    assert fm.constants[0].value.endswith("...")
    assert len(fm.constants[0].value) <= 240


def test_no_cli_returns_none(python_fixtures_dir: Path) -> None:
    fm = PythonExtractor().extract(python_fixtures_dir / "no_cli.py", repo_root=python_fixtures_dir)
    assert fm.cli_spec is None
    assert fm.has_main_block is False


# ---------- CLI detection ----------


def test_argparse_detection(python_fixtures_dir: Path) -> None:
    fm = PythonExtractor().extract(
        python_fixtures_dir / "argparse_cli.py", repo_root=python_fixtures_dir
    )
    spec = fm.cli_spec
    assert spec is not None
    assert spec.framework == CLIFramework.ARGPARSE
    assert spec.command.name == "mytool"
    assert spec.command.help == "Process widgets."

    args = {a.name: a for a in spec.command.args}
    assert set(args) == {"path", "--output", "--verbose", "--mode", "--count"}

    assert args["path"].help == "Input path"
    assert args["path"].type_hint == "str"
    assert args["path"].is_flag is False

    assert args["--output"].aliases == ["-o"]
    assert args["--output"].default == "'out.txt'"

    assert args["--verbose"].is_flag is True
    assert args["--verbose"].aliases == ["-v"]

    assert args["--mode"].choices == ["fast", "safe"]
    assert args["--mode"].default == "'safe'"

    assert args["--count"].required is True
    assert args["--count"].type_hint == "int"


def test_click_detection(python_fixtures_dir: Path) -> None:
    fm = PythonExtractor().extract(
        python_fixtures_dir / "click_cli.py", repo_root=python_fixtures_dir
    )
    spec = fm.cli_spec
    assert spec is not None
    assert spec.framework == CLIFramework.CLICK
    assert spec.command.name == "run"
    assert spec.command.help == "Process widgets."

    args = {a.name: a for a in spec.command.args}
    assert set(args) == {"path", "--output", "--verbose", "--count"}
    assert args["--verbose"].is_flag is True
    assert args["--output"].aliases == ["-o"]
    assert args["--count"].required is True


def test_typer_app_detection(python_fixtures_dir: Path) -> None:
    fm = PythonExtractor().extract(
        python_fixtures_dir / "typer_cli.py", repo_root=python_fixtures_dir
    )
    spec = fm.cli_spec
    assert spec is not None
    assert spec.framework == CLIFramework.TYPER
    # Two commands -> wrapped in root group
    assert spec.command.subcommands
    names = {c.name for c in spec.command.subcommands}
    assert names == {"run", "stats"}

    run = next(c for c in spec.command.subcommands if c.name == "run")
    arg_names = {a.name for a in run.args}
    assert "path" in arg_names  # typer.Argument -> positional
    assert "--output" in arg_names
    assert "--verbose" in arg_names


def test_typer_run_detection(python_fixtures_dir: Path) -> None:
    fm = PythonExtractor().extract(
        python_fixtures_dir / "typer_run.py", repo_root=python_fixtures_dir
    )
    spec = fm.cli_spec
    assert spec is not None
    assert spec.framework == CLIFramework.TYPER
    assert spec.command.name == "main"
    arg_names = {a.name for a in spec.command.args}
    assert "name" in arg_names
    assert "--greeting" in arg_names


# ---------- Project metadata ----------


def test_pyproject_parsing(project_fixtures_dir: Path) -> None:
    pm = extract_project_metadata(project_fixtures_dir / "minimal")
    assert pm is not None
    assert pm.source == "pyproject.toml"
    assert pm.name == "widgetlib"
    assert pm.version == "1.2.3"
    assert pm.python_requires == ">=3.11"
    assert pm.license == "MIT"
    assert pm.readme == "README.md"
    assert "requests>=2.30" in pm.dependencies
    assert pm.optional_dependencies["dev"] == ["pytest", "ruff"]
    assert pm.scripts == {"widget": "widgetlib.cli:app"}
    assert pm.urls == {"Homepage": "https://example.com/widgetlib"}
    assert "Jane Doe <jane@example.com>" in pm.authors
    assert "Anon" in pm.authors


def test_setup_py_parsing(project_fixtures_dir: Path) -> None:
    pm = extract_project_metadata(project_fixtures_dir / "setup_py_project")
    assert pm is not None
    assert pm.source == "setup.py"
    assert pm.name == "legacylib"
    assert pm.version == "0.9.0"
    assert pm.license == "Apache-2.0"
    assert "requests" in pm.dependencies
    assert pm.scripts == {"legacy-tool": "legacylib.main:run"}


def test_extract_project_metadata_returns_none_when_absent(tmp_path: Path) -> None:
    assert extract_project_metadata(tmp_path) is None


# ---------- Orchestrator ----------


def test_extract_repo_on_sample_fixture(repo_fixtures_dir: Path) -> None:
    repo = repo_fixtures_dir / "sample"
    meta = extract_repo(repo)

    # Project metadata resolved from pyproject.toml
    assert meta.project is not None
    assert meta.project.name == "sample"

    paths = {f.path for f in meta.files}
    # tests/ is excluded by default; broken.py should be skipped with a warning
    assert "src/sample/cli.py" in paths
    assert "src/sample/core.py" in paths
    assert "src/sample/__init__.py" in paths
    assert "tests/test_core.py" not in paths
    assert "broken.py" not in paths

    # Dunder files (__init__.py, __main__.py) are kept — they carry public-API intent.
    assert "src/sample/__main__.py" in paths

    # Warning recorded for the intentionally broken file
    assert any("broken.py" == w.path for w in meta.warnings)

    # CLI was detected on cli.py
    assert len(meta.cli_specs) == 1
    assert meta.cli_specs[0].framework == CLIFramework.ARGPARSE

    # Entry points: one from [project.scripts]; __main__.py discovered on disk
    ep_kinds = {(ep.name, ep.kind) for ep in meta.entry_points}
    assert ("sample", EntryPointKind.SCRIPT) in ep_kinds
    assert any(ep.kind == EntryPointKind.MAIN_MODULE for ep in meta.entry_points)

    # Stats sanity
    assert meta.stats.files_analyzed == len(meta.files)
    assert meta.stats.files_skipped >= 1  # broken.py


def test_extract_repo_honors_explicit_excludes(repo_fixtures_dir: Path) -> None:
    repo = repo_fixtures_dir / "sample"
    meta = extract_repo(repo, excludes=["src/sample/cli.py"])
    paths = {f.path for f in meta.files}
    assert "src/sample/cli.py" not in paths
    assert "src/sample/core.py" in paths


def test_extract_repo_file_size_cap(tmp_path: Path) -> None:
    # Write a tiny pyproject so the target looks like a project.
    (tmp_path / "pyproject.toml").write_text(
        '[project]\nname = "tiny"\nversion = "0"\n', encoding="utf-8"
    )
    huge = tmp_path / "huge.py"
    huge.write_text("x = 0\n" * 1000, encoding="utf-8")
    meta = extract_repo(tmp_path, max_file_bytes=100)
    assert not any(f.path == "huge.py" for f in meta.files)
    assert any("huge.py" == w.path for w in meta.warnings)


def test_discover_entry_points_from_project_metadata(
    project_fixtures_dir: Path,
) -> None:
    pm = extract_project_metadata(project_fixtures_dir / "minimal")
    eps = discover_entry_points(project_fixtures_dir / "minimal", pm)
    script = next(ep for ep in eps if ep.name == "widget")
    assert script.kind == EntryPointKind.SCRIPT
    assert script.module == "widgetlib.cli"
    assert script.attribute == "app"


def test_discover_entry_points_honors_excludes(tmp_path: Path) -> None:
    (tmp_path / "pyproject.toml").write_text(
        '[project]\nname = "demo"\nversion = "0"\n', encoding="utf-8"
    )
    kept = tmp_path / "src" / "demo"
    kept.mkdir(parents=True)
    (kept / "__main__.py").write_text("", encoding="utf-8")
    dropped = tmp_path / "vendor" / "thirdparty"
    dropped.mkdir(parents=True)
    (dropped / "__main__.py").write_text("", encoding="utf-8")

    pm = extract_project_metadata(tmp_path)
    eps = discover_entry_points(tmp_path, pm, excludes=["vendor/**"])
    names = {(ep.kind, ep.file) for ep in eps if ep.kind == EntryPointKind.MAIN_MODULE}
    assert (EntryPointKind.MAIN_MODULE, "src/demo/__main__.py") in names
    assert all("vendor" not in (f or "") for _, f in names)


def test_privacy_no_source_bodies(python_fixtures_dir: Path) -> None:
    """FileMetadata must not contain function bodies.

    Regression guard for SPEC §2.4: the schema itself enforces no source
    transmission, so we assert body-like content is absent from the file.
    """
    fm = PythonExtractor().extract(
        python_fixtures_dir / "simple_module.py", repo_root=python_fixtures_dir
    )
    greet = next(f for f in fm.functions if f.name == "greet")
    # The function body assigns `message = f"Hello, {name}!"` — that literal
    # should never appear in the extracted metadata.
    assert not hasattr(greet, "body")
    # Docstrings are permitted by design; assert they are the *only* prose field.
    for attr_name in ("body", "source", "raw", "content"):
        assert not hasattr(greet, attr_name)
