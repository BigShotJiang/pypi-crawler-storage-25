"""Unit tests for badge inference (SPEC §3.3)."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import pytest

from autoreadme import badges as badges_mod
from autoreadme.badges import infer_badges, render_badges_markdown
from autoreadme.models import ProjectMetadata


def _no_git(monkeypatch: pytest.MonkeyPatch) -> None:
    def fake_run(*args: Any, **kwargs: Any) -> Any:
        raise OSError("git not available")

    monkeypatch.setattr(badges_mod.subprocess, "run", fake_run)


def _stub_git_remote(monkeypatch: pytest.MonkeyPatch, url: str) -> None:
    class _Result:
        def __init__(self) -> None:
            self.returncode = 0
            self.stdout = url + "\n"

    monkeypatch.setattr(badges_mod.subprocess, "run", lambda *a, **k: _Result())


def test_no_project_returns_empty(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    _no_git(monkeypatch)
    assert infer_badges(tmp_path, None) == []


def test_pypi_and_python_versions_from_project(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    _no_git(monkeypatch)
    project = ProjectMetadata(name="demo", python_requires=">=3.11")
    result = infer_badges(tmp_path, project)
    alts = [b.alt for b in result]
    assert "PyPI version" in alts
    assert "Python versions" in alts
    assert "Downloads" in alts
    pypi = next(b for b in result if b.alt == "PyPI version")
    assert "pypi/v/demo" in pypi.image_url
    assert pypi.link_url == "https://pypi.org/project/demo/"


def test_license_badge_from_file(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    _no_git(monkeypatch)
    (tmp_path / "LICENSE").write_text("MIT License\n\nCopyright...\n")
    project = ProjectMetadata(name="demo")
    result = infer_badges(tmp_path, project)
    license_b = next(b for b in result if b.alt == "License")
    assert "license-MIT" in license_b.image_url


def test_license_badge_from_project_overrides_file(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    _no_git(monkeypatch)
    (tmp_path / "LICENSE").write_text("GPL-3.0")
    project = ProjectMetadata(name="demo", license="Apache-2.0")
    result = infer_badges(tmp_path, project)
    license_b = next(b for b in result if b.alt == "License")
    assert "Apache-2.0" in license_b.image_url


def test_license_unknown_text_falls_back_to_custom(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    _no_git(monkeypatch)
    (tmp_path / "LICENSE").write_text("some bespoke terms with no known name")
    result = infer_badges(tmp_path, ProjectMetadata(name="demo"))
    license_b = next(b for b in result if b.alt == "License")
    assert "Custom" in license_b.image_url


def test_ci_badge_requires_workflows_and_remote(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    _no_git(monkeypatch)
    wf_dir = tmp_path / ".github" / "workflows"
    wf_dir.mkdir(parents=True)
    (wf_dir / "ci.yml").write_text("name: ci\n")
    # No git remote → no CI badge even though the workflow exists.
    assert all(b.alt != "CI" for b in infer_badges(tmp_path, ProjectMetadata(name="demo")))


def test_ci_badge_with_github_remote(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    _stub_git_remote(monkeypatch, "https://github.com/me/demo.git")
    wf_dir = tmp_path / ".github" / "workflows"
    wf_dir.mkdir(parents=True)
    (wf_dir / "ci.yml").write_text("name: ci\n")
    ci_b = next(b for b in infer_badges(tmp_path, ProjectMetadata(name="demo")) if b.alt == "CI")
    assert "github.com/me/demo/actions/workflows/ci.yml" in ci_b.image_url


def test_ci_badge_parses_ssh_remote(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    _stub_git_remote(monkeypatch, "git@github.com:me/demo.git")
    wf_dir = tmp_path / ".github" / "workflows"
    wf_dir.mkdir(parents=True)
    (wf_dir / "main.yml").write_text("name: main\n")
    ci_b = next(b for b in infer_badges(tmp_path, ProjectMetadata(name="demo")) if b.alt == "CI")
    assert "me/demo/actions/workflows/main.yml" in ci_b.image_url


def test_render_badges_markdown_joins_with_spaces(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    _no_git(monkeypatch)
    md = render_badges_markdown(tmp_path, ProjectMetadata(name="demo", python_requires=">=3.11"))
    # Each rendered badge starts with "[" (linked) or "!" (bare image). Count shields.
    assert md.count("![") >= 2
    assert "  " not in md  # single-space joined


def test_badge_order_is_pypi_pyver_license_ci_downloads(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    _stub_git_remote(monkeypatch, "https://github.com/me/demo.git")
    (tmp_path / "LICENSE").write_text("MIT")
    wf_dir = tmp_path / ".github" / "workflows"
    wf_dir.mkdir(parents=True)
    (wf_dir / "ci.yml").write_text("name: ci\n")
    alts = [
        b.alt
        for b in infer_badges(tmp_path, ProjectMetadata(name="demo", python_requires=">=3.11"))
    ]
    assert alts == ["PyPI version", "Python versions", "License", "CI", "Downloads"]
