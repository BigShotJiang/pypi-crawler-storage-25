# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project

AutoReadme is a CLI tool + GitHub Action that generates and maintains README files for Python repositories. It extracts structured metadata via `ast` (never sends source code to an LLM), then uses an LLM to generate polished prose. See `SPEC.md` for the full specification.

## Architecture

**Pipeline:** Extract (ast, per-file) → Aggregate → Token pre-flight → Generate (single LLM call) → Diff → Approve → Write

**Key design principles:**
- No section is better than a wrong section — skip what can't be confidently extracted
- Privacy guarantee: payload schema has no field for source code bodies; only structured metadata is sent
- Protected regions (`<!-- autoreadme:section:start/end -->`) preserve user-written content across regenerations

## Package Layout

```
src/autoreadme/
├── cli.py                  # Typer, single command, no subcommands
├── config.py               # .autoreadme.toml + env var + CLI flag resolution
├── models.py               # Dataclasses for extracted metadata
├── extractors/             # Protocol + per-language implementations
├── providers/              # LLMProvider protocol + anthropic/openai/ollama
├── generation/             # Prompts (hardcoded f-strings), generator, template
├── diff.py                 # difflib + Rich colored diff
├── badges.py               # Infer badges from repo state (no network)
└── io.py                   # File I/O, .bak backup, symlink guard
```

## Commands

```bash
# Dev setup
uv sync --all-extras

# Lint + format
ruff check src/ tests/
ruff format --check src/ tests/

# Type check
mypy src/

# Tests (no API key needed)
pytest

# E2E tests (needs API key)
pytest -m requires_api_key

# Run the tool
uv run autoreadme .
```

## Tech Stack

- Python >=3.11 (stdlib `tomllib`, `ast`)
- Typer (CLI), Rich (terminal output, transitive via Typer)
- Provider SDKs are optional extras: `autoreadme-ai[anthropic]`, `autoreadme-ai[openai]`, `autoreadme-ai[all]`
- Build: hatchling. Dev: pytest, pytest-mock, ruff, mypy
