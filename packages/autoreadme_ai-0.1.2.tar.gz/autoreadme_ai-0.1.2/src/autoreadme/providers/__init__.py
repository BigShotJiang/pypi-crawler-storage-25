"""Provider factory — the only place where we branch on provider name (SPEC §6.1)."""

from __future__ import annotations

from .base import LLMProvider, ProviderError


def get_provider(name: str, *, model: str, api_key: str | None) -> LLMProvider:
    """Return an LLMProvider for the given name.

    Raises ProviderError for unknown names, missing SDKs, or missing credentials.
    """
    if name == "anthropic":
        from .anthropic import AnthropicProvider

        return AnthropicProvider(model=model, api_key=api_key)
    if name == "openai":
        from .openai import OpenAIProvider

        return OpenAIProvider(model=model, api_key=api_key)
    if name == "ollama":
        from .ollama import OllamaProvider

        return OllamaProvider(model=model, api_key=api_key)
    raise ProviderError(f"unknown provider: {name!r}")


__all__ = ["LLMProvider", "ProviderError", "get_provider"]
