"""Anthropic provider — lazy-imports the SDK so missing extras don't break imports."""

from __future__ import annotations

from .base import ProviderError

_MAX_TOKENS = 8192


class AnthropicProvider:
    def __init__(self, *, model: str, api_key: str | None) -> None:
        if not api_key:
            raise ProviderError("anthropic: ANTHROPIC_API_KEY is not set")
        try:
            import anthropic
        except ImportError as e:
            raise ProviderError(
                "anthropic SDK not installed. Install with: pip install autoreadme-ai[anthropic]"
            ) from e
        self._anthropic = anthropic
        self._client = anthropic.Anthropic(api_key=api_key)
        self._model = model

    def generate(self, prompt: str) -> str:
        try:
            resp = self._client.messages.create(
                model=self._model,
                max_tokens=_MAX_TOKENS,
                messages=[{"role": "user", "content": prompt}],
            )
        except self._anthropic.APIError as e:
            raise ProviderError(f"anthropic API error: {e}") from e

        parts: list[str] = []
        for block in getattr(resp, "content", []):
            text = getattr(block, "text", None)
            if isinstance(text, str):
                parts.append(text)
        result = "".join(parts)
        if not result:
            raise ProviderError("anthropic: empty response")
        return result
