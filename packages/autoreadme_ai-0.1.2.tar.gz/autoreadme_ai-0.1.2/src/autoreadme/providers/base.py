"""LLM provider protocol + shared exception (SPEC §6)."""

from __future__ import annotations

from typing import Protocol, runtime_checkable


class ProviderError(Exception):
    """Single exception type raised by all providers.

    Each provider wraps its SDK's exceptions into this type so callers
    catch one thing instead of three (SPEC §6.3).
    """


@runtime_checkable
class LLMProvider(Protocol):
    def generate(self, prompt: str) -> str: ...
