"""Ollama provider — HTTP calls to a local Ollama server, no SDK dependency (SPEC §6.2)."""

from __future__ import annotations

import json
import os
import urllib.error
import urllib.request

from .base import ProviderError

DEFAULT_HOST = "http://localhost:11434"
_TIMEOUT_SECONDS = 300


class OllamaProvider:
    def __init__(self, *, model: str, api_key: str | None) -> None:
        # `api_key` is overloaded here: for ollama it carries OLLAMA_HOST (URL), not a secret.
        host = api_key or os.environ.get("OLLAMA_HOST") or DEFAULT_HOST
        self._host = host.rstrip("/")
        self._model = model

    def generate(self, prompt: str) -> str:
        url = f"{self._host}/api/generate"
        body = json.dumps({"model": self._model, "prompt": prompt, "stream": False}).encode("utf-8")
        req = urllib.request.Request(url, data=body, headers={"Content-Type": "application/json"})
        try:
            with urllib.request.urlopen(req, timeout=_TIMEOUT_SECONDS) as resp:
                payload = json.loads(resp.read().decode("utf-8"))
        except urllib.error.URLError as e:
            raise ProviderError(f"ollama: cannot reach {self._host} ({e.reason})") from e
        except (ValueError, json.JSONDecodeError) as e:
            raise ProviderError(f"ollama: invalid JSON response ({e})") from e

        response = payload.get("response") if isinstance(payload, dict) else None
        if not isinstance(response, str) or not response:
            raise ProviderError(f"ollama: empty response from model {self._model!r}")
        return response
