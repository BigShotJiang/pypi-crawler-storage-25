"""OpenAI provider — lazy-imports the SDK so missing extras don't break imports."""

from __future__ import annotations

from .base import ProviderError


class OpenAIProvider:
    def __init__(self, *, model: str, api_key: str | None) -> None:
        if not api_key:
            raise ProviderError("openai: OPENAI_API_KEY is not set")
        try:
            import openai
        except ImportError as e:
            raise ProviderError(
                "openai SDK not installed. Install with: pip install autoreadme-ai[openai]"
            ) from e
        self._openai = openai
        self._client = openai.OpenAI(api_key=api_key)
        self._model = model

    def generate(self, prompt: str) -> str:
        try:
            resp = self._client.chat.completions.create(
                model=self._model,
                messages=[{"role": "user", "content": prompt}],
            )
        except self._openai.OpenAIError as e:
            raise ProviderError(f"openai API error: {e}") from e

        choices = getattr(resp, "choices", None) or []
        if not choices:
            raise ProviderError("openai: empty response (no choices)")
        content = getattr(choices[0].message, "content", None)
        if not isinstance(content, str) or not content:
            raise ProviderError("openai: empty response")
        return content
