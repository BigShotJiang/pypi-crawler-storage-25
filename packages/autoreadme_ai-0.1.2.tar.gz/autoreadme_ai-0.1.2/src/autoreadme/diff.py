"""Unified diff + Rich color + pager routing + Y/n/d/q prompt (SPEC §4.4).

Keep the color mapping minimal — `difflib.unified_diff` lines start with one of
`+`, `-`, `@`, ` `, or (for the header) `+++`/`---`. Anything unusual is
rendered uncolored rather than guessed.
"""

from __future__ import annotations

import difflib
import os
import shutil
import subprocess
import sys
from dataclasses import dataclass
from enum import Enum
from typing import TextIO

from rich.console import Console
from rich.text import Text

# Threshold above which a diff is auto-routed to the pager before prompting
# (SPEC §4.4). Counted in diff lines, not original file lines.
LARGE_DIFF_LINES = 500


class Choice(Enum):
    APPLY = "apply"
    REJECT = "reject"
    QUIT = "quit"


@dataclass(frozen=True)
class Diff:
    text: str  # plain unified-diff text (no color codes)
    lines: int  # line count of the diff body

    @property
    def is_empty(self) -> bool:
        return self.lines == 0

    @property
    def is_large(self) -> bool:
        return self.lines > LARGE_DIFF_LINES


def build_diff(old: str, new: str, *, path_label: str = "README.md") -> Diff:
    """Return a unified diff comparing `old` → `new`.

    Lines are kept with trailing newlines so the diff renders cleanly; the
    wrapped `lines` count excludes the two header lines for a more useful
    "is this a big diff?" signal.
    """
    old_lines = old.splitlines(keepends=True)
    new_lines = new.splitlines(keepends=True)
    if old_lines and not old_lines[-1].endswith("\n"):
        old_lines[-1] += "\n"
    if new_lines and not new_lines[-1].endswith("\n"):
        new_lines[-1] += "\n"

    diff_lines = list(
        difflib.unified_diff(
            old_lines,
            new_lines,
            fromfile=f"a/{path_label}",
            tofile=f"b/{path_label}",
            n=3,
        )
    )
    text = "".join(diff_lines)
    # Count body lines (exclude the --- / +++ header pair).
    body = max(0, len(diff_lines) - 2) if diff_lines else 0
    return Diff(text=text, lines=body)


def render_colored(diff: Diff, console: Console) -> None:
    """Render the diff to `console` with per-line coloring."""
    if diff.is_empty:
        return
    for raw in diff.text.splitlines():
        console.print(_style_line(raw))


def _style_line(line: str) -> Text:
    if line.startswith(("+++", "---")):
        return Text(line, style="bold")
    if line.startswith("@@"):
        return Text(line, style="cyan")
    if line.startswith("+"):
        return Text(line, style="green")
    if line.startswith("-"):
        return Text(line, style="red")
    return Text(line)


def show_in_pager(diff: Diff) -> None:
    """Pipe the plain diff text through $PAGER (fallback: less -R → more → cat).

    Failures (pager not found, broken pipe) fall back silently to stdout so the
    user never loses the content.
    """
    if diff.is_empty:
        return
    for cmd in _pager_candidates():
        if shutil.which(cmd[0]) is None:
            continue
        try:
            proc = subprocess.run(cmd, input=diff.text, text=True, check=False)
        except OSError:
            continue
        if proc.returncode in (0, None):
            return
    sys.stdout.write(diff.text)
    sys.stdout.flush()


def _pager_candidates() -> list[list[str]]:
    env_pager = os.environ.get("PAGER")
    candidates: list[list[str]] = []
    if env_pager:
        # PAGER may include args ("less -R"); split on whitespace.
        candidates.append(env_pager.split())
    candidates.extend([["less", "-R"], ["more"], ["cat"]])
    return candidates


def prompt_apply(
    diff: Diff,
    *,
    console: Console,
    input_stream: TextIO | None = None,
) -> Choice:
    """Ask `Apply changes? [Y/n/d/q]`, looping on `d` (show in pager).

    The caller is responsible for having already displayed the (colored) diff
    inline; this function just drives the decision loop.
    """
    stdin = input_stream if input_stream is not None else sys.stdin
    while True:
        console.print("Apply changes? [Y/n/d/q] ", end="")
        try:
            raw = stdin.readline()
        except KeyboardInterrupt:
            return Choice.QUIT
        if raw == "":  # EOF
            return Choice.QUIT
        answer = raw.strip().lower()
        if answer in ("", "y", "yes"):
            return Choice.APPLY
        if answer in ("n", "no"):
            return Choice.REJECT
        if answer == "d":
            show_in_pager(diff)
            continue
        if answer == "q":
            return Choice.QUIT
        console.print("[yellow]Please answer Y, n, d, or q.[/yellow]")


__all__ = [
    "LARGE_DIFF_LINES",
    "Choice",
    "Diff",
    "build_diff",
    "prompt_apply",
    "render_colored",
    "show_in_pager",
]
