"""Badge inference from repo state only — no network calls (SPEC §3.3).

Sources in precedence order: pyproject.toml (PyPI version, Python versions),
LICENSE file, .github/workflows (CI status), pyproject.toml name (downloads).
Any badge whose source data is absent is silently skipped; we never emit
placeholders.
"""

from __future__ import annotations

import re
import subprocess
from dataclasses import dataclass
from pathlib import Path
from urllib.parse import quote

from .models import ProjectMetadata

_STYLE = "flat"


@dataclass(frozen=True)
class Badge:
    alt: str
    image_url: str
    link_url: str | None = None

    def to_markdown(self) -> str:
        img = f"![{self.alt}]({self.image_url})"
        return f"[{img}]({self.link_url})" if self.link_url else img


def infer_badges(repo_root: Path, project: ProjectMetadata | None) -> list[Badge]:
    """Return badges in display order. Skips any badge without source data."""
    badges: list[Badge] = []
    name = project.name if project else None

    if name:
        badges.append(_pypi_version_badge(name))

    py_versions = _python_versions(project)
    if py_versions:
        badges.append(_python_versions_badge(py_versions))

    license_badge = _license_badge(repo_root, project)
    if license_badge is not None:
        badges.append(license_badge)

    owner_repo = _github_owner_repo(repo_root)
    ci_badge = _ci_badge(repo_root, owner_repo)
    if ci_badge is not None:
        badges.append(ci_badge)

    if name:
        badges.append(_downloads_badge(name))

    return badges


def render_badges_markdown(repo_root: Path, project: ProjectMetadata | None) -> str:
    badges = infer_badges(repo_root, project)
    return " ".join(b.to_markdown() for b in badges)


# ---------- Individual badges ----------


def _pypi_version_badge(name: str) -> Badge:
    slug = quote(name, safe="")
    return Badge(
        alt="PyPI version",
        image_url=f"https://img.shields.io/pypi/v/{slug}.svg?style={_STYLE}",
        link_url=f"https://pypi.org/project/{slug}/",
    )


def _python_versions_badge(versions: str) -> Badge:
    # shields.io's `pyversions` endpoint resolves from PyPI metadata, but to
    # keep the badge static-friendly we encode what we read from pyproject.
    encoded = quote(versions, safe="")
    return Badge(
        alt="Python versions",
        image_url=(f"https://img.shields.io/badge/python-{encoded}-blue.svg?style={_STYLE}"),
    )


def _license_badge(root: Path, project: ProjectMetadata | None) -> Badge | None:
    license_name = (
        project.license if project and project.license else None
    ) or _detect_license_file(root)
    if not license_name:
        return None
    encoded = quote(license_name, safe="")
    return Badge(
        alt="License",
        image_url=f"https://img.shields.io/badge/license-{encoded}-green.svg?style={_STYLE}",
    )


def _ci_badge(root: Path, owner_repo: tuple[str, str] | None) -> Badge | None:
    workflows_dir = root / ".github" / "workflows"
    if not workflows_dir.is_dir():
        return None
    workflow = _pick_workflow(workflows_dir)
    if workflow is None or owner_repo is None:
        return None
    owner, repo = owner_repo
    wf_name = quote(workflow.name, safe="")
    return Badge(
        alt="CI",
        image_url=(f"https://github.com/{owner}/{repo}/actions/workflows/{wf_name}/badge.svg"),
        link_url=f"https://github.com/{owner}/{repo}/actions/workflows/{wf_name}",
    )


def _downloads_badge(name: str) -> Badge:
    slug = quote(name, safe="")
    return Badge(
        alt="Downloads",
        image_url=f"https://img.shields.io/pypi/dm/{slug}.svg?style={_STYLE}",
        link_url=f"https://pypi.org/project/{slug}/",
    )


# ---------- Data sources ----------


def _python_versions(project: ProjectMetadata | None) -> str | None:
    if project is None:
        return None
    req = project.python_requires
    if req:
        return req
    for c in project.classifiers:
        # e.g. "Programming Language :: Python :: 3.11"
        if c.startswith("Programming Language :: Python :: "):
            suffix = c.rsplit("::", 1)[-1].strip()
            if suffix and suffix[0].isdigit():
                return suffix
    return None


_LICENSE_NAME_RE = re.compile(r"\b(MIT|Apache|BSD|GPL|LGPL|MPL|ISC|Unlicense)\b", re.IGNORECASE)


def _detect_license_file(root: Path) -> str | None:
    for candidate in ("LICENSE", "LICENSE.md", "LICENSE.txt", "COPYING"):
        p = root / candidate
        if not p.is_file():
            continue
        try:
            text = p.read_text(encoding="utf-8", errors="replace")
        except OSError:
            return "Custom"
        match = _LICENSE_NAME_RE.search(text)
        return match.group(1).upper() if match else "Custom"
    return None


def _pick_workflow(workflows_dir: Path) -> Path | None:
    candidates = sorted(
        p for p in workflows_dir.iterdir() if p.suffix in (".yml", ".yaml") and p.is_file()
    )
    if not candidates:
        return None
    for preferred in ("ci.yml", "ci.yaml", "test.yml", "tests.yml", "main.yml"):
        for p in candidates:
            if p.name == preferred:
                return p
    return candidates[0]


_GITHUB_REMOTE_RE = re.compile(r"github\.com[:/]([^/\s]+)/([^/\s]+?)(?:\.git)?/?$", re.IGNORECASE)


def _github_owner_repo(root: Path) -> tuple[str, str] | None:
    try:
        result = subprocess.run(
            ["git", "remote", "get-url", "origin"],
            cwd=root,
            capture_output=True,
            text=True,
            timeout=5,
            check=False,
        )
    except (OSError, subprocess.SubprocessError):
        return None
    if result.returncode != 0:
        return None
    match = _GITHUB_REMOTE_RE.search(result.stdout.strip())
    if match is None:
        return None
    return match.group(1), match.group(2)


__all__ = ["Badge", "infer_badges", "render_badges_markdown"]
