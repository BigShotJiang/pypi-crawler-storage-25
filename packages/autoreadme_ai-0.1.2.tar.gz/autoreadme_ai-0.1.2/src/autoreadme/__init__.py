"""AutoReadme — generate READMEs for Python repositories from static analysis."""

from importlib.metadata import PackageNotFoundError, version

try:
    __version__ = version("autoreadme-ai")
except PackageNotFoundError:
    __version__ = "0.0.0+unknown"

__all__ = ["__version__"]
