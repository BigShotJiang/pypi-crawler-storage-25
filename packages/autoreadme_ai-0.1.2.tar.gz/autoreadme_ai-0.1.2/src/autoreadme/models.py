"""Dataclasses for structured metadata extracted from a repository.

The schema in this module is intentionally source-body-free: there is no field
that holds raw function bodies, string literals, or comments. The privacy model
described in SPEC §2.4 is enforced by the types themselves.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import StrEnum


class ParameterKind(StrEnum):
    POSITIONAL_ONLY = "positional_only"
    POSITIONAL_OR_KEYWORD = "positional_or_keyword"
    VAR_POSITIONAL = "var_positional"
    KEYWORD_ONLY = "keyword_only"
    VAR_KEYWORD = "var_keyword"


@dataclass
class Parameter:
    name: str
    kind: ParameterKind = ParameterKind.POSITIONAL_OR_KEYWORD
    type_hint: str | None = None
    default: str | None = None  # rendered source, e.g. "None", "10", "'foo'"


@dataclass
class FunctionSignature:
    name: str
    parameters: list[Parameter] = field(default_factory=list)
    return_type: str | None = None
    decorators: list[str] = field(default_factory=list)
    docstring: str | None = None
    is_async: bool = False
    is_public: bool = True
    line: int = 0


@dataclass
class ClassDef:
    name: str
    bases: list[str] = field(default_factory=list)
    decorators: list[str] = field(default_factory=list)
    docstring: str | None = None
    methods: list[FunctionSignature] = field(default_factory=list)
    is_public: bool = True
    line: int = 0


@dataclass
class CLIArg:
    """A single CLI option/argument."""

    name: str  # canonical, e.g. "--foo" or positional "path"
    aliases: list[str] = field(default_factory=list)  # e.g. ["-f"]
    help: str | None = None
    type_hint: str | None = None
    default: str | None = None
    required: bool = False
    is_flag: bool = False
    choices: list[str] = field(default_factory=list)


@dataclass
class CLICommand:
    name: str
    help: str | None = None
    args: list[CLIArg] = field(default_factory=list)
    subcommands: list[CLICommand] = field(default_factory=list)


class CLIFramework(StrEnum):
    ARGPARSE = "argparse"
    CLICK = "click"
    TYPER = "typer"


@dataclass
class CLISpec:
    framework: CLIFramework
    entry_file: str  # relative path to the file defining the CLI
    command: CLICommand


@dataclass
class Constant:
    """A module-level literal assignment (e.g. `MAX_SIZE = 100`).

    Captured so the LLM can ground factual claims like env var names, default
    URLs, and config keys in real source rather than guess them. `value` is
    `ast.unparse`'d — still a source-level representation, never a runtime
    value, so the schema stays consistent with the privacy model in SPEC §2.4.
    """

    name: str
    value: str  # rendered source (may be truncated)
    type_hint: str | None = None


@dataclass
class FileMetadata:
    path: str  # relative to repo root, posix-style
    module_docstring: str | None = None
    functions: list[FunctionSignature] = field(default_factory=list)
    classes: list[ClassDef] = field(default_factory=list)
    imports: list[str] = field(default_factory=list)  # top-level module names
    public_api: list[str] = field(default_factory=list)  # names in __all__ or inferred
    constants: list[Constant] = field(default_factory=list)  # module-level literals
    has_main_block: bool = False
    cli_spec: CLISpec | None = None


class EntryPointKind(StrEnum):
    SCRIPT = "script"
    GUI_SCRIPT = "gui_script"
    MAIN_MODULE = "main_module"  # __main__.py


@dataclass
class EntryPoint:
    name: str
    kind: EntryPointKind
    module: str | None = None  # e.g. "autoreadme.cli"
    attribute: str | None = None  # e.g. "app" for "autoreadme.cli:app"
    file: str | None = None  # relative path when discovered on disk (__main__.py)


@dataclass
class ProjectMetadata:
    name: str | None = None
    version: str | None = None
    description: str | None = None
    python_requires: str | None = None
    license: str | None = None
    readme: str | None = None
    authors: list[str] = field(default_factory=list)
    dependencies: list[str] = field(default_factory=list)
    optional_dependencies: dict[str, list[str]] = field(default_factory=dict)
    scripts: dict[str, str] = field(default_factory=dict)  # name -> "module:attr"
    gui_scripts: dict[str, str] = field(default_factory=dict)
    urls: dict[str, str] = field(default_factory=dict)
    keywords: list[str] = field(default_factory=list)
    classifiers: list[str] = field(default_factory=list)
    source: str | None = None  # "pyproject.toml" | "setup.py" | None


@dataclass
class ExtractionWarning:
    path: str
    message: str


@dataclass
class ExtractionStats:
    files_analyzed: int = 0
    files_skipped: int = 0
    public_symbols: int = 0


@dataclass
class RepoMetadata:
    root: str
    project: ProjectMetadata | None = None
    files: list[FileMetadata] = field(default_factory=list)
    entry_points: list[EntryPoint] = field(default_factory=list)
    cli_specs: list[CLISpec] = field(default_factory=list)
    warnings: list[ExtractionWarning] = field(default_factory=list)
    stats: ExtractionStats = field(default_factory=ExtractionStats)
