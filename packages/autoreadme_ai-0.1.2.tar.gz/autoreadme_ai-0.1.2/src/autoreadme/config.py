"""Config resolution: CLI flags > .autoreadme.toml > env vars > defaults (SPEC §5).

Secrets (API keys) never come from the config file — env only.
Unknown fields produce warnings but never fail the run.
"""

from __future__ import annotations

import os
import tomllib
from collections.abc import Mapping
from dataclasses import dataclass, field
from pathlib import Path

CONFIG_FILENAME = ".autoreadme.toml"

KNOWN_PROVIDERS: tuple[str, ...] = ("anthropic", "openai", "ollama")

DEFAULT_MODELS: dict[str, str] = {
    "anthropic": "claude-sonnet-4-20250514",
    "openai": "gpt-4o",
    "ollama": "llama3.1",
}

PROVIDER_ENV_KEYS: dict[str, str] = {
    "anthropic": "ANTHROPIC_API_KEY",
    "openai": "OPENAI_API_KEY",
    "ollama": "OLLAMA_HOST",
}

KNOWN_SECTIONS = {"llm", "extract"}
KNOWN_LLM_FIELDS = {"provider", "model"}
KNOWN_EXTRACT_FIELDS = {"exclude"}


@dataclass
class Config:
    provider: str
    model: str
    api_key: str | None  # ollama: this carries OLLAMA_HOST (URL), not a secret
    excludes: list[str] = field(default_factory=list)
    sources: dict[str, str] = field(default_factory=dict)
    warnings: list[str] = field(default_factory=list)


def load_config(
    root: Path | str,
    *,
    cli_provider: str | None = None,
    cli_model: str | None = None,
    env: Mapping[str, str] | None = None,
) -> Config:
    """Resolve config from CLI flags, file, env, defaults (in that precedence)."""
    root_path = Path(root)
    env_map: Mapping[str, str] = env if env is not None else os.environ
    file_data, warnings = _load_file(root_path)

    # Provider: CLI > file > env auto-detect > default
    file_provider = file_data.get("provider")
    if cli_provider is not None:
        provider, provider_source = cli_provider, "cli"
    elif isinstance(file_provider, str):
        provider, provider_source = file_provider, "file"
    else:
        detected = _auto_detect_provider(env_map)
        if detected is not None:
            provider, provider_source = detected, "env"
        else:
            provider, provider_source = "anthropic", "default"

    if provider not in KNOWN_PROVIDERS:
        warnings.append(f"unknown provider '{provider}', falling back to 'anthropic'")
        provider, provider_source = "anthropic", "default"

    # Model: CLI > file > provider-specific default
    file_model = file_data.get("model")
    if cli_model is not None:
        model, model_source = cli_model, "cli"
    elif isinstance(file_model, str):
        model, model_source = file_model, "file"
    else:
        model, model_source = DEFAULT_MODELS[provider], "default"

    # Credential: always env (no CLI/file surface for secrets).
    api_key = env_map.get(PROVIDER_ENV_KEYS[provider])
    api_key_source = "env" if api_key else "missing"

    file_excludes = file_data.get("excludes")
    excludes = list(file_excludes) if isinstance(file_excludes, list) else []
    excludes_source = "file" if excludes else "default"

    return Config(
        provider=provider,
        model=model,
        api_key=api_key,
        excludes=excludes,
        sources={
            "provider": provider_source,
            "model": model_source,
            "api_key": api_key_source,
            "excludes": excludes_source,
        },
        warnings=warnings,
    )


def _auto_detect_provider(env: Mapping[str, str]) -> str | None:
    for provider in KNOWN_PROVIDERS:
        if env.get(PROVIDER_ENV_KEYS[provider]):
            return provider
    return None


def _load_file(root: Path) -> tuple[dict[str, object], list[str]]:
    path = root / CONFIG_FILENAME
    if not path.is_file():
        return {}, []

    warnings: list[str] = []
    try:
        with path.open("rb") as f:
            data = tomllib.load(f)
    except tomllib.TOMLDecodeError as e:
        warnings.append(f"{CONFIG_FILENAME}: parse error ({e}); using defaults")
        return {}, warnings

    for section in data:
        if section not in KNOWN_SECTIONS:
            warnings.append(f"{CONFIG_FILENAME}: unknown section [{section}]")

    result: dict[str, object] = {}

    llm = data.get("llm")
    if llm is not None and not isinstance(llm, dict):
        warnings.append(f"{CONFIG_FILENAME}: [llm] must be a table")
    elif isinstance(llm, dict):
        for k in llm:
            if k not in KNOWN_LLM_FIELDS:
                warnings.append(f"{CONFIG_FILENAME}: unknown field [llm].{k}")
        for k in ("provider", "model"):
            v = llm.get(k)
            if v is None:
                continue
            if isinstance(v, str):
                result[k] = v
            else:
                warnings.append(f"{CONFIG_FILENAME}: [llm].{k} must be a string")

    extract = data.get("extract")
    if extract is not None and not isinstance(extract, dict):
        warnings.append(f"{CONFIG_FILENAME}: [extract] must be a table")
    elif isinstance(extract, dict):
        for k in extract:
            if k not in KNOWN_EXTRACT_FIELDS:
                warnings.append(f"{CONFIG_FILENAME}: unknown field [extract].{k}")
        raw_excludes = extract.get("exclude")
        if raw_excludes is None:
            pass
        elif isinstance(raw_excludes, list) and all(isinstance(x, str) for x in raw_excludes):
            result["excludes"] = list(raw_excludes)
        else:
            warnings.append(f"{CONFIG_FILENAME}: [extract].exclude must be a list of strings")

    return result, warnings


__all__ = [
    "CONFIG_FILENAME",
    "DEFAULT_MODELS",
    "KNOWN_PROVIDERS",
    "PROVIDER_ENV_KEYS",
    "Config",
    "load_config",
]
