"""CLI entry point (SPEC §4).

Single Typer command, no subcommands. `autoreadme` with no args runs on `.`
instead of printing help — the tool should do the obvious thing by default.
"""

from __future__ import annotations

import io
import sys
from pathlib import Path
from typing import Annotated

import typer
from rich.console import Console

from . import __version__
from .config import PROVIDER_ENV_KEYS, load_config
from .diff import Choice, build_diff, prompt_apply, render_colored, show_in_pager
from .extractors import extract_repo
from .generation import GenerationError, apply_sections, extract_sections, generate_readme
from .io import IOError_, read_readme, write_readme
from .providers import ProviderError, get_provider

# Exit codes (SPEC §4.3)
EXIT_OK = 0
EXIT_REJECTED = 1
EXIT_USAGE = 2
EXIT_EXTRACT = 3
EXIT_LLM = 4


app = typer.Typer(
    add_completion=False,
    context_settings={"help_option_names": ["--help", "-h"]},
    invoke_without_command=True,
)


def _version_callback(value: bool) -> None:
    if value:
        typer.echo(f"autoreadme {__version__}")
        raise typer.Exit()


@app.command()
def main(
    path: Annotated[Path, typer.Argument(help="Path to the repo root", show_default=True)] = Path(
        "."
    ),
    provider: Annotated[
        str | None, typer.Option("--provider", help="LLM provider: anthropic | openai | ollama")
    ] = None,
    model: Annotated[str | None, typer.Option("--model", help="Model override")] = None,
    dry_run: Annotated[
        bool, typer.Option("--dry-run", help="Write result to stdout instead of disk")
    ] = False,
    force: Annotated[
        bool, typer.Option("--force", help="Apply without interactive approval")
    ] = False,
    show_payload: Annotated[
        bool, typer.Option("--show-payload", help="Dump JSON payload to stdout and exit")
    ] = False,
    verbose: Annotated[bool, typer.Option("--verbose", help="Verbose log output")] = False,
    output: Annotated[
        Path | None, typer.Option("--output", help="Output path (default: <PATH>/README.md)")
    ] = None,
    _version: Annotated[
        bool,
        typer.Option(
            "--version",
            callback=_version_callback,
            is_eager=True,
            help="Print version and exit",
        ),
    ] = False,
) -> None:
    """Generate a README for a Python repository."""
    stderr = Console(stderr=True)
    stdout = Console()

    target = path.resolve()
    if not target.is_dir():
        stderr.print(f"[red]Error:[/red] not a directory: {target}")
        raise typer.Exit(EXIT_USAGE)

    # --- Config + provider resolution ---
    cfg = load_config(target, cli_provider=provider, cli_model=model)
    if verbose:
        stderr.print(
            f"[dim]provider={cfg.provider} ({cfg.sources['provider']}) "
            f"model={cfg.model} ({cfg.sources['model']}) "
            f"api_key={'set' if cfg.api_key else 'MISSING'} ({cfg.sources['api_key']})[/dim]"
        )
    for w in cfg.warnings:
        stderr.print(f"[yellow]⚠ {w}[/yellow]")

    if not show_payload and cfg.api_key is None and cfg.provider != "ollama":
        env_var = PROVIDER_ENV_KEYS[cfg.provider]
        stderr.print(
            f"[red]Error:[/red] no API key for provider '{cfg.provider}' — "
            f"[bold]{env_var}[/bold] is not set."
        )
        dotenv = target / ".env"
        if dotenv.is_file():
            stderr.print(
                f"[yellow]Hint:[/yellow] found [bold]{dotenv}[/bold] but autoreadme "
                "does not auto-load .env files. Export the vars into your shell first:"
            )
            stderr.print("[dim]  set -a; source .env; set +a[/dim]")
        else:
            stderr.print(f"[dim]Export it with: export {env_var}=...[/dim]")
        raise typer.Exit(EXIT_USAGE)

    # --- Extract ---
    if verbose:
        stderr.print(f"[dim][extract] scanning {target}...[/dim]")
    try:
        repo = extract_repo(target, excludes=cfg.excludes or None)
    except NotADirectoryError as e:
        stderr.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(EXIT_EXTRACT) from e
    except OSError as e:
        stderr.print(f"[red]Error:[/red] extraction failed: {e}")
        raise typer.Exit(EXIT_EXTRACT) from e

    s = repo.stats
    stderr.print(
        f"[dim]Extraction summary: {s.files_analyzed} files, "
        f"{s.public_symbols} public symbols, {s.files_skipped} skipped[/dim]"
    )
    for ew in repo.warnings:
        stderr.print(f"[yellow]⚠ {ew.path}: {ew.message}[/yellow]")

    if s.files_analyzed == 0:
        stderr.print(
            "[red]Error:[/red] no analyzable files found. "
            "Is this a Python project? Check your exclude patterns."
        )
        raise typer.Exit(EXIT_EXTRACT)

    # --- Generate ---
    try:
        if show_payload:
            # generate_readme handles the dump + early exit internally.
            generate_readme(repo, _NoopProvider(), repo_root=target, show_payload=True)
            raise typer.Exit(EXIT_OK)

        llm = get_provider(cfg.provider, model=cfg.model, api_key=cfg.api_key)
        result = generate_readme(
            repo,
            llm,
            repo_root=target,
            provider_name=cfg.provider,
            model_name=cfg.model,
            log=sys.stderr if verbose else io.StringIO(),
        )
    except ProviderError as e:
        stderr.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(EXIT_LLM) from e
    except GenerationError as e:
        stderr.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(EXIT_LLM) from e

    new_content = _ensure_trailing_newline(result.readme)

    # --- Dry-run: to stdout, done. ---
    if dry_run:
        stdout.print(new_content, end="", markup=False, highlight=False)
        raise typer.Exit(EXIT_OK)

    # --- Merge with existing (if any) + write ---
    out_path = (output if output is not None else target / "README.md").resolve()

    try:
        existing = read_readme(out_path)
    except IOError_ as e:
        stderr.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(EXIT_USAGE) from e

    final_content = _merge_or_overwrite(existing, new_content)
    old_for_diff = existing if existing is not None else ""
    diff = build_diff(old_for_diff, final_content, path_label=out_path.name)

    if diff.is_empty:
        stderr.print("[green]✓[/green] README.md already up to date.")
        raise typer.Exit(EXIT_OK)

    # --- Approval ---
    if not force:
        if not sys.stdin.isatty():
            stderr.print(
                "[red]Error:[/red] no TTY detected. "
                "Use --force to apply changes in non-interactive mode."
            )
            raise typer.Exit(EXIT_USAGE)
        if diff.is_large:
            show_in_pager(diff)
        else:
            render_colored(diff, stderr)
        choice = prompt_apply(diff, console=stderr)
        if choice is Choice.REJECT:
            stderr.print("[yellow]Not writing README. Run again to retry.[/yellow]")
            raise typer.Exit(EXIT_REJECTED)
        if choice is Choice.QUIT:
            raise typer.Exit(EXIT_REJECTED)

    # --- Write ---
    try:
        write_result = write_readme(out_path, final_content)
    except IOError_ as e:
        stderr.print(f"[red]Error:[/red] {e}")
        raise typer.Exit(EXIT_USAGE) from e

    bak_note = f" (backup: {write_result.backup.name})" if write_result.backup else ""
    warn_count = len(repo.warnings)
    warn_note = f", {warn_count} warning{'s' if warn_count != 1 else ''}" if warn_count else ""
    stderr.print(f"[green]✓[/green] {out_path.name} updated{bak_note}{warn_note}")


# ---------- Helpers ----------


def _merge_or_overwrite(existing: str | None, generated: str) -> str:
    """Apply marker-preserving merge when existing has markers, else overwrite.

    SPEC §3.4: first run (no markers) overwrites after backup. Subsequent runs
    (markers present) replace only the generated regions, preserving manual
    content between/outside markers.
    """
    if existing is None:
        return generated
    existing_sections = extract_sections(existing)
    if not existing_sections:
        return generated  # first run on a pre-existing README
    new_sections = extract_sections(generated)
    if not new_sections:
        return generated  # generator didn't emit markers — overwrite
    return _ensure_trailing_newline(apply_sections(existing, new_sections))


def _ensure_trailing_newline(text: str) -> str:
    return text if text.endswith("\n") else text + "\n"


class _NoopProvider:
    """Placeholder used when `--show-payload` skips the LLM call."""

    def generate(self, prompt: str) -> str:  # pragma: no cover - never called
        raise RuntimeError("NoopProvider.generate should not be called")


if __name__ == "__main__":
    app()
