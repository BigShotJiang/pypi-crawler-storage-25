"""CLI argument parser detection for argparse / click / typer.

We pattern-match the 80% case; if the shape doesn't look confidently like a CLI,
we return None and the README's CLI Reference section is skipped entirely.
"""

from __future__ import annotations

import ast

from ..models import CLIArg, CLICommand, CLIFramework, CLISpec


def detect_cli(tree: ast.Module, file_path: str) -> CLISpec | None:
    """Run each framework detector in order; return the first confident match."""
    for detector in (_detect_argparse, _detect_click, _detect_typer):
        spec = detector(tree, file_path)
        if spec is not None:
            return spec
    return None


# ----- argparse ---------------------------------------------------------------


def _detect_argparse(tree: ast.Module, file_path: str) -> CLISpec | None:
    parsers: dict[str, CLICommand] = {}
    first_parser: str | None = None

    for node in ast.walk(tree):
        if not isinstance(node, ast.Assign):
            continue
        if not _is_argparse_parser_call(node.value):
            continue
        if len(node.targets) != 1 or not isinstance(node.targets[0], ast.Name):
            continue
        assert isinstance(node.value, ast.Call)
        parser_name = node.targets[0].id
        cmd_name = _get_kwarg_str(node.value, "prog") or "cli"
        cmd_help = _get_kwarg_str(node.value, "description")
        parsers[parser_name] = CLICommand(name=cmd_name, help=cmd_help)
        if first_parser is None:
            first_parser = parser_name

    if not parsers:
        return None

    for node in ast.walk(tree):
        if not (isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute)):
            continue
        if node.func.attr != "add_argument":
            continue
        if not isinstance(node.func.value, ast.Name):
            continue
        parser_name = node.func.value.id
        if parser_name not in parsers:
            continue
        arg = _argparse_add_argument(node)
        if arg is not None:
            parsers[parser_name].args.append(arg)

    main = parsers[first_parser] if first_parser else next(iter(parsers.values()))
    if not main.args:
        return None
    return CLISpec(framework=CLIFramework.ARGPARSE, entry_file=file_path, command=main)


def _is_argparse_parser_call(node: ast.expr) -> bool:
    if not isinstance(node, ast.Call):
        return False
    func = node.func
    if (
        isinstance(func, ast.Attribute)
        and func.attr == "ArgumentParser"
        and isinstance(func.value, ast.Name)
        and func.value.id == "argparse"
    ):
        return True
    return isinstance(func, ast.Name) and func.id == "ArgumentParser"


def _argparse_add_argument(call: ast.Call) -> CLIArg | None:
    names = [a.value for a in call.args if isinstance(a, ast.Constant) and isinstance(a.value, str)]
    if not names:
        return None
    canonical, aliases = _canonical_and_aliases(names)
    if canonical is None:
        return None

    action = _get_kwarg_str(call, "action")
    is_flag = action in {"store_true", "store_false"} if action else False

    choices: list[str] = []
    choices_node = _get_kwarg_node(call, "choices")
    if isinstance(choices_node, ast.List | ast.Tuple):
        for elt in choices_node.elts:
            if isinstance(elt, ast.Constant) and isinstance(elt.value, str):
                choices.append(elt.value)

    required = _get_kwarg_bool(call, "required")

    return CLIArg(
        name=canonical,
        aliases=aliases,
        help=_get_kwarg_str(call, "help"),
        type_hint=_get_kwarg_source(call, "type"),
        default=_get_kwarg_source(call, "default"),
        required=bool(required) if required is not None else False,
        is_flag=is_flag,
        choices=choices,
    )


# ----- click ------------------------------------------------------------------


def _detect_click(tree: ast.Module, file_path: str) -> CLISpec | None:
    commands: list[CLICommand] = []
    for node in tree.body:
        if not isinstance(node, ast.FunctionDef | ast.AsyncFunctionDef):
            continue
        is_command = False
        cmd_name: str | None = None
        cmd_help: str | None = None
        args: list[CLIArg] = []
        for deco in node.decorator_list:
            if _is_click_command_decorator(deco):
                is_command = True
                if isinstance(deco, ast.Call):
                    if (
                        deco.args
                        and isinstance(deco.args[0], ast.Constant)
                        and isinstance(deco.args[0].value, str)
                    ):
                        cmd_name = deco.args[0].value
                    cmd_help = _get_kwarg_str(deco, "help") or cmd_help
            elif _is_click_option_decorator(deco) or _is_click_argument_decorator(deco):
                arg = _click_arg_from_decorator(deco)
                if arg is not None:
                    args.append(arg)
        if not is_command:
            continue
        # Decorators are written top-down but applied bottom-up; reverse to
        # reflect source declaration order.
        args.reverse()
        name = cmd_name or node.name
        help_text = cmd_help or ast.get_docstring(node)
        commands.append(CLICommand(name=name, help=help_text, args=args))

    if not commands:
        return None
    if len(commands) == 1:
        return CLISpec(framework=CLIFramework.CLICK, entry_file=file_path, command=commands[0])
    root = CLICommand(name="cli", subcommands=commands)
    return CLISpec(framework=CLIFramework.CLICK, entry_file=file_path, command=root)


def _is_click_command_decorator(deco: ast.expr) -> bool:
    target = deco.func if isinstance(deco, ast.Call) else deco
    if not isinstance(target, ast.Attribute) or target.attr not in {"command", "group"}:
        return False
    return isinstance(target.value, ast.Name) and target.value.id == "click"


def _is_click_option_decorator(deco: ast.expr) -> bool:
    if not isinstance(deco, ast.Call):
        return False
    func = deco.func
    if not isinstance(func, ast.Attribute) or func.attr != "option":
        return False
    return isinstance(func.value, ast.Name) and func.value.id == "click"


def _is_click_argument_decorator(deco: ast.expr) -> bool:
    if not isinstance(deco, ast.Call):
        return False
    func = deco.func
    if not isinstance(func, ast.Attribute) or func.attr != "argument":
        return False
    return isinstance(func.value, ast.Name) and func.value.id == "click"


def _click_arg_from_decorator(deco: ast.expr) -> CLIArg | None:
    if not isinstance(deco, ast.Call):
        return None
    names = [a.value for a in deco.args if isinstance(a, ast.Constant) and isinstance(a.value, str)]
    if not names:
        return None
    canonical, aliases = _canonical_and_aliases(names)
    if canonical is None:
        return None
    required = _get_kwarg_bool(deco, "required")
    is_flag = _get_kwarg_bool(deco, "is_flag")
    return CLIArg(
        name=canonical,
        aliases=aliases,
        help=_get_kwarg_str(deco, "help"),
        type_hint=_get_kwarg_source(deco, "type"),
        default=_get_kwarg_source(deco, "default"),
        required=bool(required) if required is not None else False,
        is_flag=bool(is_flag) if is_flag is not None else False,
    )


# ----- typer ------------------------------------------------------------------


def _detect_typer(tree: ast.Module, file_path: str) -> CLISpec | None:
    app_vars: set[str] = set()
    typer_run_target: str | None = None

    for node in ast.walk(tree):
        if isinstance(node, ast.Assign):
            if _is_typer_instantiation(node.value):
                for tgt in node.targets:
                    if isinstance(tgt, ast.Name):
                        app_vars.add(tgt.id)
        elif isinstance(node, ast.Call) and _is_typer_run_call(node) and node.args:
            first = node.args[0]
            if isinstance(first, ast.Name):
                typer_run_target = first.id

    commands: list[CLICommand] = []
    for node in tree.body:
        if not isinstance(node, ast.FunctionDef | ast.AsyncFunctionDef):
            continue
        is_command = False
        cmd_name: str | None = None
        cmd_help: str | None = None
        for deco in node.decorator_list:
            if _is_typer_command_decorator(deco, app_vars):
                is_command = True
                if isinstance(deco, ast.Call):
                    if (
                        deco.args
                        and isinstance(deco.args[0], ast.Constant)
                        and isinstance(deco.args[0].value, str)
                    ):
                        cmd_name = deco.args[0].value
                    cmd_help = _get_kwarg_str(deco, "help") or cmd_help
        if not is_command and typer_run_target == node.name:
            is_command = True
        if not is_command:
            continue
        args = _typer_args_from_function(node)
        name = cmd_name or node.name
        help_text = cmd_help or ast.get_docstring(node)
        commands.append(CLICommand(name=name, help=help_text, args=args))

    if not commands:
        return None
    if len(commands) == 1:
        return CLISpec(framework=CLIFramework.TYPER, entry_file=file_path, command=commands[0])
    root = CLICommand(name="cli", subcommands=commands)
    return CLISpec(framework=CLIFramework.TYPER, entry_file=file_path, command=root)


def _is_typer_instantiation(node: ast.expr) -> bool:
    if not isinstance(node, ast.Call):
        return False
    func = node.func
    if (
        isinstance(func, ast.Attribute)
        and func.attr == "Typer"
        and isinstance(func.value, ast.Name)
        and func.value.id == "typer"
    ):
        return True
    return isinstance(func, ast.Name) and func.id == "Typer"


def _is_typer_run_call(node: ast.Call) -> bool:
    func = node.func
    if not isinstance(func, ast.Attribute) or func.attr != "run":
        return False
    return isinstance(func.value, ast.Name) and func.value.id == "typer"


def _is_typer_command_decorator(deco: ast.expr, app_vars: set[str]) -> bool:
    target = deco.func if isinstance(deco, ast.Call) else deco
    if not isinstance(target, ast.Attribute) or target.attr != "command":
        return False
    return isinstance(target.value, ast.Name) and target.value.id in app_vars


def _typer_args_from_function(
    node: ast.FunctionDef | ast.AsyncFunctionDef,
) -> list[CLIArg]:
    args: list[CLIArg] = []
    pos = node.args.posonlyargs + node.args.args
    defaults = list(node.args.defaults)
    default_offset = len(pos) - len(defaults)

    for i, a in enumerate(pos):
        default_node = defaults[i - default_offset] if i >= default_offset else None
        type_hint = ast.unparse(a.annotation) if a.annotation else None
        name = a.arg
        flag_name = f"--{name.replace('_', '-')}"

        help_text: str | None = None
        default_str: str | None = None
        # In typer, a parameter with no default is a positional argument.
        is_argument = default_node is None
        if default_node is not None:
            if _is_typer_option_or_argument(default_node):
                assert isinstance(default_node, ast.Call)
                if default_node.args:
                    default_str = ast.unparse(default_node.args[0])
                help_text = _get_kwarg_str(default_node, "help")
                if (
                    isinstance(default_node.func, ast.Attribute)
                    and default_node.func.attr == "Argument"
                ):
                    is_argument = True
            else:
                default_str = ast.unparse(default_node)

        canonical = name if is_argument else flag_name
        is_flag = type_hint == "bool" and not is_argument
        args.append(
            CLIArg(
                name=canonical,
                help=help_text,
                type_hint=type_hint,
                default=default_str,
                required=default_node is None,
                is_flag=is_flag,
            )
        )
    return args


def _is_typer_option_or_argument(node: ast.expr) -> bool:
    if not isinstance(node, ast.Call):
        return False
    func = node.func
    if not isinstance(func, ast.Attribute) or func.attr not in {"Option", "Argument"}:
        return False
    return isinstance(func.value, ast.Name) and func.value.id == "typer"


# ----- shared helpers ---------------------------------------------------------


def _canonical_and_aliases(names: list[str]) -> tuple[str | None, list[str]]:
    long = next((n for n in names if n.startswith("--")), None)
    short = next((n for n in names if n.startswith("-") and not n.startswith("--")), None)
    positional = next((n for n in names if not n.startswith("-")), None)
    canonical = long or positional or short
    if canonical is None:
        return None, []
    aliases = [n for n in names if n != canonical]
    return canonical, aliases


def _get_kwarg_node(call: ast.Call, name: str) -> ast.expr | None:
    for kw in call.keywords:
        if kw.arg == name:
            return kw.value
    return None


def _get_kwarg_str(call: ast.Call, name: str) -> str | None:
    node = _get_kwarg_node(call, name)
    if isinstance(node, ast.Constant) and isinstance(node.value, str):
        return node.value
    return None


def _get_kwarg_bool(call: ast.Call, name: str) -> bool | None:
    node = _get_kwarg_node(call, name)
    if isinstance(node, ast.Constant) and isinstance(node.value, bool):
        return node.value
    return None


def _get_kwarg_source(call: ast.Call, name: str) -> str | None:
    node = _get_kwarg_node(call, name)
    return ast.unparse(node) if node is not None else None
