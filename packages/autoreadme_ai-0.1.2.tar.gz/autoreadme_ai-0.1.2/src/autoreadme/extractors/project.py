"""Project-level metadata extractor: pyproject.toml and setup.py.

pyproject.toml is parsed with stdlib `tomllib`. setup.py is parsed via AST and
never executed — we read only literal values from the top-level `setup(...)` call.
"""

from __future__ import annotations

import ast
import fnmatch
import os
import tomllib
from pathlib import Path

from ..models import EntryPoint, EntryPointKind, ProjectMetadata


def extract_project_metadata(root: Path) -> ProjectMetadata | None:
    """Return project metadata from pyproject.toml or setup.py, else None."""
    pyproject = root / "pyproject.toml"
    if pyproject.is_file():
        return _parse_pyproject(pyproject)
    setup_py = root / "setup.py"
    if setup_py.is_file():
        return _parse_setup_py(setup_py)
    return None


def discover_entry_points(
    root: Path,
    project: ProjectMetadata | None,
    *,
    excludes: list[str] | None = None,
    prune_dirs: set[str] | None = None,
) -> list[EntryPoint]:
    """Collect entry points from project metadata and `__main__.py` files.

    `excludes` and `prune_dirs` mirror the filters used during file walking so
    a user-configured `exclude` pattern (e.g. `src/vendor/**`) drops its
    `__main__.py` entries too. Defaults keep the old behavior for callers that
    don't pass them.
    """
    eps: list[EntryPoint] = []
    if project is not None:
        for name, target in project.scripts.items():
            module, _, attr = target.partition(":")
            eps.append(
                EntryPoint(
                    name=name,
                    kind=EntryPointKind.SCRIPT,
                    module=module or None,
                    attribute=attr or None,
                )
            )
        for name, target in project.gui_scripts.items():
            module, _, attr = target.partition(":")
            eps.append(
                EntryPoint(
                    name=name,
                    kind=EntryPointKind.GUI_SCRIPT,
                    module=module or None,
                    attribute=attr or None,
                )
            )

    patterns = excludes or []
    pruned = prune_dirs or set()
    for main in _walk_for_main_modules(root, pruned):
        rel = main.relative_to(root).as_posix()
        if _matches_any(rel, patterns):
            continue
        eps.append(
            EntryPoint(
                name=main.parent.name,
                kind=EntryPointKind.MAIN_MODULE,
                module=main.parent.name,
                file=rel,
            )
        )
    return eps


def _walk_for_main_modules(root: Path, prune_dirs: set[str]) -> list[Path]:
    results: list[Path] = []
    for dirpath, dirnames, filenames in os.walk(root, followlinks=False):
        dirnames[:] = [d for d in dirnames if d not in prune_dirs]
        if "__main__.py" in filenames:
            results.append(Path(dirpath) / "__main__.py")
    return results


def _matches_any(rel: str, patterns: list[str]) -> bool:
    basename = rel.rsplit("/", 1)[-1]
    for pat in patterns:
        if fnmatch.fnmatchcase(rel, pat):
            return True
        if pat.startswith("**/") and fnmatch.fnmatchcase(basename, pat[3:]):
            return True
        if "/" not in pat and fnmatch.fnmatchcase(basename, pat):
            return True
    return False


def _parse_pyproject(path: Path) -> ProjectMetadata:
    try:
        with path.open("rb") as f:
            data = tomllib.load(f)
    except tomllib.TOMLDecodeError:
        return ProjectMetadata(source="pyproject.toml")

    project = data.get("project", {})
    if not isinstance(project, dict):
        return ProjectMetadata(source="pyproject.toml")

    license_raw = project.get("license")
    if isinstance(license_raw, str):
        license_str: str | None = license_raw
    elif isinstance(license_raw, dict):
        license_str = license_raw.get("text") or license_raw.get("file")
    else:
        license_str = None

    readme_raw = project.get("readme")
    if isinstance(readme_raw, str):
        readme: str | None = readme_raw
    elif isinstance(readme_raw, dict):
        readme = readme_raw.get("file") or readme_raw.get("text")
    else:
        readme = None

    authors: list[str] = []
    for a in project.get("authors", []) or []:
        if isinstance(a, dict):
            name = a.get("name")
            email = a.get("email")
            if name and email:
                authors.append(f"{name} <{email}>")
            elif name:
                authors.append(name)
            elif email:
                authors.append(email)
        elif isinstance(a, str):
            authors.append(a)

    return ProjectMetadata(
        name=project.get("name"),
        version=project.get("version"),
        description=project.get("description"),
        python_requires=project.get("requires-python"),
        license=license_str,
        readme=readme,
        authors=authors,
        dependencies=list(project.get("dependencies", []) or []),
        optional_dependencies={
            k: list(v) for k, v in (project.get("optional-dependencies") or {}).items()
        },
        scripts=dict(project.get("scripts") or {}),
        gui_scripts=dict(project.get("gui-scripts") or {}),
        urls=dict(project.get("urls") or {}),
        keywords=list(project.get("keywords", []) or []),
        classifiers=list(project.get("classifiers", []) or []),
        source="pyproject.toml",
    )


def _parse_setup_py(path: Path) -> ProjectMetadata:
    source = path.read_text(encoding="utf-8", errors="replace")
    try:
        tree = ast.parse(source, filename=str(path))
    except SyntaxError:
        return ProjectMetadata(source="setup.py")

    setup_call = _find_setup_call(tree)
    if setup_call is None:
        return ProjectMetadata(source="setup.py")

    kwargs = {k.arg: k.value for k in setup_call.keywords if k.arg is not None}

    def _const_str(key: str) -> str | None:
        node = kwargs.get(key)
        if isinstance(node, ast.Constant) and isinstance(node.value, str):
            return node.value
        return None

    def _const_str_list(key: str) -> list[str]:
        node = kwargs.get(key)
        if not isinstance(node, ast.List | ast.Tuple):
            return []
        return [
            e.value for e in node.elts if isinstance(e, ast.Constant) and isinstance(e.value, str)
        ]

    scripts: dict[str, str] = {}
    ep_node = kwargs.get("entry_points")
    if isinstance(ep_node, ast.Dict):
        for k, v in zip(ep_node.keys, ep_node.values, strict=False):
            if (
                isinstance(k, ast.Constant)
                and k.value == "console_scripts"
                and isinstance(v, ast.List | ast.Tuple)
            ):
                for e in v.elts:
                    if isinstance(e, ast.Constant) and isinstance(e.value, str):
                        name, sep, target = e.value.partition("=")
                        if sep and name.strip() and target.strip():
                            scripts[name.strip()] = target.strip()

    return ProjectMetadata(
        name=_const_str("name"),
        version=_const_str("version"),
        description=_const_str("description"),
        python_requires=_const_str("python_requires"),
        license=_const_str("license"),
        dependencies=_const_str_list("install_requires"),
        scripts=scripts,
        keywords=_const_str_list("keywords"),
        classifiers=_const_str_list("classifiers"),
        source="setup.py",
    )


def _find_setup_call(tree: ast.Module) -> ast.Call | None:
    for node in ast.walk(tree):
        if (
            isinstance(node, ast.Call)
            and isinstance(node.func, ast.Name)
            and node.func.id == "setup"
        ):
            return node
    return None
