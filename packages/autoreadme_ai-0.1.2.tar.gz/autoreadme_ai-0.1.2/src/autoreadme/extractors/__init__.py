"""Extraction orchestrator: walks a repo and builds a RepoMetadata."""

from __future__ import annotations

import fnmatch
import os
from pathlib import Path

from ..models import (
    ExtractionStats,
    ExtractionWarning,
    FileMetadata,
    RepoMetadata,
)
from .base import Extractor
from .project import discover_entry_points, extract_project_metadata
from .python import PythonExtractor

DEFAULT_EXCLUDES: list[str] = [
    "tests/**",
    "test_*.py",
    # Skip private modules but not dunder files like __init__.py / __main__.py —
    # those carry public-API intent (`__all__`, entrypoints).
    "**/_[!_]*.py",
    "docs/**",
    "examples/**",
    ".venv/**",
    "build/**",
    "dist/**",
    ".git/**",
]

# Always excluded regardless of user config (SPEC §2.4, §9).
ALWAYS_SKIP_PATTERNS: list[str] = [".env*", "*.key", "*.pem", "credentials.*"]

# Pruned during directory walk for performance.
_PRUNE_DIRS = {
    ".git",
    ".venv",
    "venv",
    "__pycache__",
    "build",
    "dist",
    "node_modules",
    ".mypy_cache",
    ".pytest_cache",
    ".ruff_cache",
    ".tox",
    ".eggs",
    ".hatch",
}

DEFAULT_MAX_FILE_BYTES = 1_000_000  # 1 MB (SPEC §9)


def extract_repo(
    root: Path | str,
    *,
    excludes: list[str] | None = None,
    max_file_bytes: int = DEFAULT_MAX_FILE_BYTES,
) -> RepoMetadata:
    """Walk a repository and return aggregated metadata.

    Per-file errors are never fatal — they are recorded as warnings and the run
    continues. See SPEC §10 for the error-handling contract.
    """
    root_path = Path(root).resolve()
    if not root_path.is_dir():
        raise NotADirectoryError(f"Not a directory: {root_path}")

    user_excludes = excludes if excludes is not None else list(DEFAULT_EXCLUDES)
    all_patterns = user_excludes + ALWAYS_SKIP_PATTERNS

    extractors: list[Extractor] = [PythonExtractor()]

    files: list[FileMetadata] = []
    warnings: list[ExtractionWarning] = []
    stats = ExtractionStats()

    for path in _iter_source_files(root_path, all_patterns):
        extractor = _select_extractor(path, extractors)
        if extractor is None:
            continue
        rel = path.relative_to(root_path).as_posix()
        try:
            size = path.stat().st_size
        except OSError as e:
            warnings.append(ExtractionWarning(path=rel, message=f"stat failed: {e}"))
            stats.files_skipped += 1
            continue
        if size > max_file_bytes:
            warnings.append(
                ExtractionWarning(
                    path=rel,
                    message=f"file exceeds {max_file_bytes // 1000}KB limit (skipped)",
                )
            )
            stats.files_skipped += 1
            continue
        try:
            fm = extractor.extract(path, repo_root=root_path)
        except SyntaxError as e:
            warnings.append(
                ExtractionWarning(
                    path=rel,
                    message=f"SyntaxError at line {e.lineno} (file skipped)",
                )
            )
            stats.files_skipped += 1
            continue
        except (UnicodeDecodeError, OSError) as e:
            warnings.append(ExtractionWarning(path=rel, message=f"read failed: {e}"))
            stats.files_skipped += 1
            continue
        files.append(fm)
        stats.files_analyzed += 1
        stats.public_symbols += len(fm.public_api)

    project = extract_project_metadata(root_path)
    entry_points = discover_entry_points(
        root_path, project, excludes=all_patterns, prune_dirs=_PRUNE_DIRS
    )
    cli_specs = [f.cli_spec for f in files if f.cli_spec is not None]

    return RepoMetadata(
        root=str(root_path),
        project=project,
        files=files,
        entry_points=entry_points,
        cli_specs=cli_specs,
        warnings=warnings,
        stats=stats,
    )


def _select_extractor(path: Path, extractors: list[Extractor]) -> Extractor | None:
    for e in extractors:
        if e.matches(path):
            return e
    return None


def _iter_source_files(root: Path, patterns: list[str]) -> list[Path]:
    results: list[Path] = []
    for dirpath, dirnames, filenames in os.walk(root, followlinks=False):
        dp = Path(dirpath)
        # Prune always-ignored directories in place.
        dirnames[:] = [d for d in dirnames if d not in _PRUNE_DIRS]
        for name in filenames:
            p = dp / name
            if p.is_symlink():
                # SPEC §9: never follow symlinks that resolve outside the repo.
                try:
                    resolved = p.resolve()
                    if root != resolved and root not in resolved.parents:
                        continue
                except OSError:
                    continue
            rel = p.relative_to(root).as_posix()
            if _is_excluded(rel, patterns):
                continue
            results.append(p)
    results.sort()
    return results


def _is_excluded(rel: str, patterns: list[str]) -> bool:
    basename = rel.rsplit("/", 1)[-1]
    for pat in patterns:
        if fnmatch.fnmatchcase(rel, pat):
            return True
        if pat.startswith("**/") and fnmatch.fnmatchcase(basename, pat[3:]):
            return True
        if "/" not in pat and fnmatch.fnmatchcase(basename, pat):
            return True
    return False


__all__ = [
    "ALWAYS_SKIP_PATTERNS",
    "DEFAULT_EXCLUDES",
    "DEFAULT_MAX_FILE_BYTES",
    "extract_repo",
]
