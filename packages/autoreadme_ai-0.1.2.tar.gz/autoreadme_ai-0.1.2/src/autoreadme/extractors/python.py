"""Python AST extractor — reads signatures, docstrings, imports, public API.

Uses stdlib `ast` only. Never executes user code.
"""

from __future__ import annotations

import ast
from pathlib import Path

from ..models import (
    ClassDef,
    Constant,
    FileMetadata,
    FunctionSignature,
    Parameter,
    ParameterKind,
)
from .cli import detect_cli

# Module-level literal assignments captured per file. Capped so a single file
# full of lookup tables can't balloon the payload. The truncation length keeps
# dict/list literals readable while bounding prompt bytes.
_MAX_CONSTANTS_PER_FILE = 30
_MAX_CONSTANT_VALUE_CHARS = 240


class PythonExtractor:
    """Per-file extractor for Python source."""

    language = "python"

    def matches(self, path: Path) -> bool:
        return path.suffix == ".py"

    def extract(self, path: Path, *, repo_root: Path) -> FileMetadata:
        source = path.read_text(encoding="utf-8")
        tree = ast.parse(source, filename=str(path))
        rel = path.relative_to(repo_root).as_posix()

        module_doc = ast.get_docstring(tree)
        functions: list[FunctionSignature] = []
        classes: list[ClassDef] = []
        imports: list[str] = []
        constants: list[Constant] = []
        explicit_all: list[str] | None = None
        has_main_block = False

        for node in tree.body:
            if isinstance(node, ast.FunctionDef | ast.AsyncFunctionDef):
                functions.append(_build_function(node))
            elif isinstance(node, ast.ClassDef):
                classes.append(_build_class(node))
            elif isinstance(node, ast.Import):
                for alias in node.names:
                    top = alias.name.split(".")[0]
                    if top != "__future__":
                        imports.append(top)
            elif isinstance(node, ast.ImportFrom):
                if node.module and node.level == 0:
                    top = node.module.split(".")[0]
                    if top != "__future__":
                        imports.append(top)
            elif isinstance(node, ast.Assign):
                names = _extract_all_assignment(node)
                if names is not None:
                    explicit_all = names
                else:
                    const = _extract_constant(node)
                    if const is not None:
                        constants.append(const)
            elif isinstance(node, ast.AnnAssign):
                const = _extract_ann_constant(node)
                if const is not None:
                    constants.append(const)
            elif isinstance(node, ast.If) and _is_main_block(node):
                has_main_block = True

        constants = constants[:_MAX_CONSTANTS_PER_FILE]

        public_api = _resolve_public_api(functions, classes, explicit_all)
        public_set = set(public_api)
        for fn in functions:
            fn.is_public = fn.name in public_set
        for cls in classes:
            cls.is_public = cls.name in public_set

        cli_spec = detect_cli(tree, rel)

        return FileMetadata(
            path=rel,
            module_docstring=module_doc,
            functions=functions,
            classes=classes,
            imports=sorted(set(imports)),
            public_api=public_api,
            constants=constants,
            has_main_block=has_main_block,
            cli_spec=cli_spec,
        )


def _build_function(node: ast.FunctionDef | ast.AsyncFunctionDef) -> FunctionSignature:
    return FunctionSignature(
        name=node.name,
        parameters=_build_parameters(node.args),
        return_type=ast.unparse(node.returns) if node.returns else None,
        decorators=[ast.unparse(d) for d in node.decorator_list],
        docstring=ast.get_docstring(node),
        is_async=isinstance(node, ast.AsyncFunctionDef),
        line=node.lineno,
    )


def _build_class(node: ast.ClassDef) -> ClassDef:
    methods: list[FunctionSignature] = []
    for child in node.body:
        if isinstance(child, ast.FunctionDef | ast.AsyncFunctionDef):
            methods.append(_build_function(child))
    return ClassDef(
        name=node.name,
        bases=[ast.unparse(b) for b in node.bases],
        decorators=[ast.unparse(d) for d in node.decorator_list],
        docstring=ast.get_docstring(node),
        methods=methods,
        line=node.lineno,
    )


def _build_parameters(args: ast.arguments) -> list[Parameter]:
    params: list[Parameter] = []

    pos_only = args.posonlyargs
    pos_or_kw = args.args
    kwonly = args.kwonlyargs
    defaults = list(args.defaults)
    kw_defaults = list(args.kw_defaults)

    pos_all = pos_only + pos_or_kw
    default_offset = len(pos_all) - len(defaults)

    for i, arg in enumerate(pos_all):
        default_node = defaults[i - default_offset] if i >= default_offset else None
        kind = (
            ParameterKind.POSITIONAL_ONLY
            if i < len(pos_only)
            else ParameterKind.POSITIONAL_OR_KEYWORD
        )
        params.append(
            Parameter(
                name=arg.arg,
                kind=kind,
                type_hint=ast.unparse(arg.annotation) if arg.annotation else None,
                default=ast.unparse(default_node) if default_node is not None else None,
            )
        )

    if args.vararg:
        params.append(
            Parameter(
                name=args.vararg.arg,
                kind=ParameterKind.VAR_POSITIONAL,
                type_hint=(ast.unparse(args.vararg.annotation) if args.vararg.annotation else None),
            )
        )

    for arg, default_node in zip(kwonly, kw_defaults, strict=False):
        params.append(
            Parameter(
                name=arg.arg,
                kind=ParameterKind.KEYWORD_ONLY,
                type_hint=ast.unparse(arg.annotation) if arg.annotation else None,
                default=ast.unparse(default_node) if default_node is not None else None,
            )
        )

    if args.kwarg:
        params.append(
            Parameter(
                name=args.kwarg.arg,
                kind=ParameterKind.VAR_KEYWORD,
                type_hint=(ast.unparse(args.kwarg.annotation) if args.kwarg.annotation else None),
            )
        )

    return params


def _extract_constant(node: ast.Assign) -> Constant | None:
    """Capture `NAME = <literal>` where NAME is a non-private identifier.

    We skip:
    - Private names (`_foo`, `__foo`) and `__all__`
    - Tuple/multi-target assignments (`a, b = ...`)
    - Non-literal values (function calls, comprehensions, name references
      other than True/False/None)

    The value is rendered via `ast.unparse` so what the LLM sees is the exact
    source literal — never a runtime object.
    """
    if len(node.targets) != 1:
        return None
    target = node.targets[0]
    if not isinstance(target, ast.Name):
        return None
    if not _is_public_const_name(target.id):
        return None
    if not _is_literal_value(node.value):
        return None
    return Constant(name=target.id, value=_render_value(node.value))


def _extract_ann_constant(node: ast.AnnAssign) -> Constant | None:
    if not isinstance(node.target, ast.Name):
        return None
    if not _is_public_const_name(node.target.id):
        return None
    if node.value is None or not _is_literal_value(node.value):
        return None
    return Constant(
        name=node.target.id,
        value=_render_value(node.value),
        type_hint=ast.unparse(node.annotation),
    )


def _is_public_const_name(name: str) -> bool:
    return bool(name) and not name.startswith("_") and name != "__all__"


def _is_literal_value(node: ast.expr) -> bool:
    if isinstance(node, ast.Constant):
        return True
    if isinstance(node, ast.Name):
        return node.id in ("True", "False", "None")
    if isinstance(node, ast.UnaryOp) and isinstance(node.op, ast.USub | ast.UAdd):
        return _is_literal_value(node.operand)
    if isinstance(node, ast.List | ast.Tuple | ast.Set):
        return all(_is_literal_value(e) for e in node.elts)
    if isinstance(node, ast.Dict):
        return all(k is not None and _is_literal_value(k) for k in node.keys) and all(
            _is_literal_value(v) for v in node.values
        )
    return False


def _render_value(node: ast.expr) -> str:
    rendered = ast.unparse(node)
    if len(rendered) > _MAX_CONSTANT_VALUE_CHARS:
        return rendered[: _MAX_CONSTANT_VALUE_CHARS - 3] + "..."
    return rendered


def _extract_all_assignment(node: ast.Assign) -> list[str] | None:
    for target in node.targets:
        if isinstance(target, ast.Name) and target.id == "__all__":
            value = node.value
            if isinstance(value, ast.List | ast.Tuple):
                names: list[str] = []
                for elt in value.elts:
                    if isinstance(elt, ast.Constant) and isinstance(elt.value, str):
                        names.append(elt.value)
                return names
    return None


def _is_main_block(node: ast.If) -> bool:
    test = node.test
    if not isinstance(test, ast.Compare) or len(test.ops) != 1:
        return False
    if not isinstance(test.ops[0], ast.Eq):
        return False
    left, right = test.left, test.comparators[0]
    name_left = isinstance(left, ast.Name) and left.id == "__name__"
    main_right = isinstance(right, ast.Constant) and right.value == "__main__"
    name_right = isinstance(right, ast.Name) and right.id == "__name__"
    main_left = isinstance(left, ast.Constant) and left.value == "__main__"
    return (name_left and main_right) or (name_right and main_left)


def _resolve_public_api(
    functions: list[FunctionSignature],
    classes: list[ClassDef],
    explicit_all: list[str] | None,
) -> list[str]:
    if explicit_all is not None:
        return list(explicit_all)
    names: list[str] = []
    for fn in functions:
        if not fn.name.startswith("_"):
            names.append(fn.name)
    for cls in classes:
        if not cls.name.startswith("_"):
            names.append(cls.name)
    return names
