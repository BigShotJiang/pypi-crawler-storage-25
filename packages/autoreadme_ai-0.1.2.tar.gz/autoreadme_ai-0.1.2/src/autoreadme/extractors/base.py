"""Extractor protocol for per-language metadata extraction."""

from __future__ import annotations

from pathlib import Path
from typing import Protocol, runtime_checkable

from ..models import FileMetadata


@runtime_checkable
class Extractor(Protocol):
    """A per-file metadata extractor for a specific language."""

    language: str

    def matches(self, path: Path) -> bool:
        """Return True if this extractor should handle the given file."""
        ...

    def extract(self, path: Path, *, repo_root: Path) -> FileMetadata:
        """Parse the file and return structured metadata.

        May raise SyntaxError / UnicodeDecodeError / OSError — the orchestrator
        is responsible for catching these and recording warnings.
        """
        ...
