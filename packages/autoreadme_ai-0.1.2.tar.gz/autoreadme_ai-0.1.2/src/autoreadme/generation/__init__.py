"""README generation: prompts, template markers, and the single-call orchestrator."""

from __future__ import annotations

from .generator import GenerationError, GenerationResult, generate_readme
from .prompts import build_payload, build_prompt
from .template import (
    SECTION_NAMES,
    apply_sections,
    extract_sections,
    marker_end,
    marker_start,
)

__all__ = [
    "SECTION_NAMES",
    "GenerationError",
    "GenerationResult",
    "apply_sections",
    "build_payload",
    "build_prompt",
    "extract_sections",
    "generate_readme",
    "marker_end",
    "marker_start",
]
