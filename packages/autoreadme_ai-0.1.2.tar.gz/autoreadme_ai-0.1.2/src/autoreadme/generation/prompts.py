"""Prompt assembly (SPEC §2.3).

A single hardcoded prompt is generated per run. The payload is a sanitized,
source-body-free dict derived from `RepoMetadata` (SPEC §2.4). The prompt
embeds the README template, the fixed section order, and anti-hallucination
instructions.
"""

from __future__ import annotations

import json
from dataclasses import asdict, is_dataclass
from typing import Any

from ..models import (
    ClassDef,
    CLISpec,
    EntryPoint,
    FileMetadata,
    FunctionSignature,
    ProjectMetadata,
    RepoMetadata,
)
from .template import SECTION_NAMES, marker_end, marker_start

MAX_FUNCTIONS_PER_FILE = 40
MAX_CLASSES_PER_FILE = 20
MAX_FILES_IN_PAYLOAD = 200


def build_payload(repo: RepoMetadata) -> dict[str, Any]:
    """Return a JSON-serializable, source-body-free summary of `repo`.

    Only fields explicitly listed in SPEC §2.4 are emitted. Sizes are capped so
    a pathologically large repo cannot silently balloon the prompt — callers
    surface this via the pre-flight check in `generator.py`.
    """
    return {
        "project": _project_dict(repo.project),
        "entry_points": [_asdict_clean(ep) for ep in repo.entry_points],
        "files": [_file_dict(f) for f in repo.files[:MAX_FILES_IN_PAYLOAD]],
        "cli_specs": [_cli_dict(c) for c in repo.cli_specs],
        "stats": {
            "files_analyzed": repo.stats.files_analyzed,
            "files_skipped": repo.stats.files_skipped,
            "public_symbols": repo.stats.public_symbols,
        },
    }


def build_prompt(payload: dict[str, Any], *, badges_markdown: str = "") -> str:
    """Render the LLM prompt. `payload` is the output of `build_payload`.

    `badges_markdown` is pre-rendered by `badges.py`; the LLM is instructed to
    drop it verbatim into the badges section rather than invent badge URLs.
    """
    serialized = json.dumps(payload, indent=2, sort_keys=True, default=str)
    section_list = "\n".join(f"{i + 1}. {name}" for i, name in enumerate(SECTION_NAMES))
    badges_block = badges_markdown.strip() or "(no badges detected — skip the badges section)"
    example_start = marker_start("install")
    example_end = marker_end("install")

    return _PROMPT_TEMPLATE.format(
        section_list=section_list,
        badges_block=badges_block,
        example_start=example_start,
        example_end=example_end,
        payload=serialized,
    )


_PROMPT_TEMPLATE = """\
You are generating a README.md for a Python project from structured metadata
extracted by static analysis. You will receive a JSON payload containing
project metadata, public API signatures, docstrings, entry points, and any CLI
specification. You must not invent facts that are not supported by the
payload.

Rules:
- Base every factual claim (install command, CLI flags, module names, version
  support, dependencies) on the payload. If the payload does not contain the
  information needed for a section, omit that section entirely. No section is
  better than a wrong section.
- Do not invent string constants. Environment variable names, default URLs,
  config file keys, TOML section names, and any other literal identifier must
  come from the payload or be omitted. When in doubt, cut the claim — do not
  substitute a plausible-looking guess.
- Do not hallucinate example code. When writing a usage example, prefer the
  actual entry-point name, module path, or public API listed in the payload.
- Do not invent badges. A pre-rendered badges block is provided — drop it in
  verbatim, or omit the section if the block is empty.
- Title: use the `project.name` string verbatim — preserve its exact casing
  and punctuation; do not re-capitalize or reformat it.
- Install ordering: when the project declares a `[project.scripts]` entry
  point, lead with `uv tool install <pkg>` (or `uvx <pkg>` for one-shot use),
  then `pipx install <pkg>`, then `pip install <pkg>`. When the project
  exposes optional extras, show them on the *first* install line, not only on
  a later one — users copy the first command they see.
- Write in clear, direct prose. Avoid marketing language and filler.

Voice and shape:
- Default to flowing paragraphs, not bullet lists. Bullets are only the right
  tool for genuinely list-shaped content (CLI flags, exit codes, supported
  providers). Do not bullet-list a feature overview or a decision rationale —
  write it as prose.
- The description section should be 2-3 paragraphs that explain what the tool
  does, who it's for, and what's distinctive about how it works. Ground the
  "distinctive" part in concrete facts from the payload (module docstrings,
  entry points, notable constants). Do not just restate `project.description`.
- The install section should lead with one recommended command, a sentence or
  two of context, and at most one or two alternative installers — not a menu
  of every possible variation. Pick the one the maintainer most likely wants
  users to copy first.
- The usage section should narrate the common path end-to-end: what the user
  types, what the tool does, what they see. Inline small code blocks within
  prose. Do not re-list every flag here — that belongs in `cli_ref`.
- Constants in the payload (`files[*].constants`) are your source of truth for
  env var names, default URLs, config keys, and similar literals. When you
  need one of these facts, quote it from there. Never invent one.

Output format:
- Return only the README markdown. No preamble, no trailing commentary, no
  code fences wrapping the whole document.
- Produce sections in this exact order, skipping any for which no data exists:
{section_list}
- Wrap every section you generate in HTML comment markers so future runs can
  update it in place. Example:
    {example_start}
    ## Installation

    ```
    pip install mypkg
    ```
    {example_end}
- Use the lowercase canonical section name (e.g. `install`, `cli_ref`) inside
  the marker — not the human-facing heading.

Badges block (render verbatim inside the badges markers, if non-empty):
{badges_block}

Structured metadata payload:
```json
{payload}
```
"""


def _project_dict(project: ProjectMetadata | None) -> dict[str, Any] | None:
    if project is None:
        return None
    data = asdict(project)
    return {k: v for k, v in data.items() if v not in (None, [], {}, "")}


def _file_dict(file: FileMetadata) -> dict[str, Any]:
    return {
        "path": file.path,
        "module_docstring": file.module_docstring,
        "imports": file.imports,
        "public_api": file.public_api,
        "has_main_block": file.has_main_block,
        "functions": [_func_dict(f) for f in file.functions[:MAX_FUNCTIONS_PER_FILE]],
        "classes": [_class_dict(c) for c in file.classes[:MAX_CLASSES_PER_FILE]],
        "constants": [_asdict_clean(c) for c in file.constants],
    }


def _func_dict(fn: FunctionSignature) -> dict[str, Any]:
    return {
        "name": fn.name,
        "parameters": [_asdict_clean(p) for p in fn.parameters],
        "return_type": fn.return_type,
        "decorators": fn.decorators,
        "docstring": fn.docstring,
        "is_async": fn.is_async,
        "is_public": fn.is_public,
    }


def _class_dict(cls: ClassDef) -> dict[str, Any]:
    return {
        "name": cls.name,
        "bases": cls.bases,
        "decorators": cls.decorators,
        "docstring": cls.docstring,
        "is_public": cls.is_public,
        "methods": [_func_dict(m) for m in cls.methods[:MAX_FUNCTIONS_PER_FILE]],
    }


def _cli_dict(spec: CLISpec) -> dict[str, Any]:
    return {
        "framework": str(spec.framework),
        "entry_file": spec.entry_file,
        "command": _asdict_clean(spec.command),
    }


def _asdict_clean(obj: Any) -> Any:
    if is_dataclass(obj) and not isinstance(obj, type):
        return asdict(obj)
    if isinstance(obj, (EntryPoint,)):
        return asdict(obj)
    return obj
