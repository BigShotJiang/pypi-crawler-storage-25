"""Generation orchestrator (SPEC 2.3, 2.4).

Wires together extraction → payload → badges → token pre-flight → LLM call.
Exactly one LLM call per run; section-by-section generation is a v0.2 plan.
"""

from __future__ import annotations

import json
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, TextIO

from ..badges import render_badges_markdown
from ..models import RepoMetadata
from ..providers import LLMProvider, ProviderError
from .prompts import build_payload, build_prompt


class GenerationError(Exception):
    """Raised for fatal problems inside the generation pipeline.

    Provider-layer failures propagate as `ProviderError`; callers that want a
    single exception type should catch both.
    """


# Rough char-per-token ratio for the pre-flight check (SPEC §2.3). We aren't
# trying to match any specific tokenizer — just to catch obviously-too-large
# payloads before burning an API call.
_CHARS_PER_TOKEN = 4

# Conservative ceiling chosen to fit every currently-supported model's context
# window with room for the prompt scaffolding and response. Specific models can
# raise this later; the SPEC explicitly scopes tight budgets to v0.2.
_DEFAULT_TOKEN_BUDGET = 150_000


@dataclass
class GenerationResult:
    readme: str
    payload: dict[str, Any]
    prompt: str
    badges_markdown: str
    estimated_tokens: int
    warnings: list[str] = field(default_factory=list)


def generate_readme(
    repo: RepoMetadata,
    provider: LLMProvider,
    *,
    repo_root: Path | None = None,
    show_payload: bool = False,
    provider_name: str = "",
    model_name: str = "",
    token_budget: int = _DEFAULT_TOKEN_BUDGET,
    log: TextIO | None = None,
) -> GenerationResult:
    """Run the full reduce-phase pipeline.

    When `show_payload=True`, prints the JSON payload to stdout and returns a
    `GenerationResult` with `readme=""` — no LLM call is made. This is the
    `--show-payload` CLI surface from SPEC §2.4.
    """
    log_stream = log if log is not None else sys.stderr

    payload = build_payload(repo)
    badges_markdown = render_badges_markdown(repo_root or Path(repo.root), repo.project)
    prompt = build_prompt(payload, badges_markdown=badges_markdown)

    size_bytes = len(json.dumps(payload).encode("utf-8"))
    estimated_tokens = len(prompt) // _CHARS_PER_TOKEN

    if show_payload:
        print(json.dumps(payload, indent=2, sort_keys=True, default=str))
        return GenerationResult(
            readme="",
            payload=payload,
            prompt=prompt,
            badges_markdown=badges_markdown,
            estimated_tokens=estimated_tokens,
        )

    if estimated_tokens > token_budget:
        raise GenerationError(
            f"payload too large: ~{estimated_tokens} tokens exceeds budget of "
            f"{token_budget}. Narrow scope with `exclude` patterns in "
            ".autoreadme.toml."
        )

    kb = max(1, size_bytes // 1024)
    header = f"→ Sending {kb}KB of structured metadata"
    if provider_name:
        header += f" to {provider_name}"
        if model_name:
            header += f" ({model_name})"
    header += ". No source code included."
    print(header, file=log_stream)

    try:
        response = provider.generate(prompt)
    except ProviderError:
        raise
    except Exception as e:  # defensive: provider adapters should wrap, but don't trust
        raise GenerationError(f"LLM call failed: {e}") from e

    readme = response.strip()
    if not readme:
        raise GenerationError("LLM returned an empty response")

    return GenerationResult(
        readme=readme,
        payload=payload,
        prompt=prompt,
        badges_markdown=badges_markdown,
        estimated_tokens=estimated_tokens,
    )
