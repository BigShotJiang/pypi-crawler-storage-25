"""Section markers and preservation of manual content (SPEC 3.1, 3.2).

Generated sections are wrapped in HTML comments so subsequent runs can replace
only those regions, leaving any manual content (inside or outside markers)
untouched. Section *order* is fixed by SPEC §3.1; the LLM produces all sections
in one call and this module is responsible for the marker contract.
"""

from __future__ import annotations

import re

# Canonical section names in the order they should appear in the README
# (SPEC §3.1). Sections auto-hide when the LLM has no data to populate them.
SECTION_NAMES: tuple[str, ...] = (
    "title",
    "badges",
    "description",
    "install",
    "usage",
    "cli_ref",
    "api_ref",
    "configuration",
    "contributing",
    "license",
)


def marker_start(name: str) -> str:
    return f"<!-- autoreadme:{name}:start -->"


def marker_end(name: str) -> str:
    return f"<!-- autoreadme:{name}:end -->"


# Matches the body between a start/end marker pair for a known section.
# Non-greedy so consecutive sections don't collapse into one match.
_MARKER_RE = re.compile(
    r"<!--\s*autoreadme:(?P<name>[a-z_]+):start\s*-->"
    r"(?P<body>.*?)"
    r"<!--\s*autoreadme:(?P=name):end\s*-->",
    re.DOTALL,
)


def _fence_ranges(text: str) -> list[tuple[int, int]]:
    """Return byte spans of fenced code blocks so marker-looking strings inside
    them are treated as literal documentation, not real markers.

    Handles both ``` and ~~~ fences. A fence opens on a line whose first
    non-whitespace characters are three or more of the same fence char, and
    closes on a later line starting with the same fence char.
    """
    ranges: list[tuple[int, int]] = []
    in_fence = False
    fence_char = ""
    start_pos = 0
    pos = 0
    for line in text.splitlines(keepends=True):
        stripped = line.lstrip()
        if not in_fence:
            if stripped.startswith("```"):
                in_fence, fence_char, start_pos = True, "`", pos
            elif stripped.startswith("~~~"):
                in_fence, fence_char, start_pos = True, "~", pos
        else:
            if stripped.startswith(fence_char * 3):
                ranges.append((start_pos, pos + len(line)))
                in_fence = False
        pos += len(line)
    if in_fence:
        ranges.append((start_pos, pos))
    return ranges


def _is_in_fence(pos: int, fences: list[tuple[int, int]]) -> bool:
    return any(s <= pos < e for s, e in fences)


def extract_sections(text: str) -> dict[str, str]:
    """Return `{section_name: inner_body}` for every marker pair found in `text`.

    Markers inside fenced code blocks are skipped — they're documentation
    examples, not real region markers. The body preserves leading/trailing
    whitespace between the markers so that round-tripping through
    `apply_sections` is stable.
    """
    fences = _fence_ranges(text)
    return {
        m.group("name"): m.group("body")
        for m in _MARKER_RE.finditer(text)
        if not _is_in_fence(m.start(), fences)
    }


def apply_sections(existing: str, new_sections: dict[str, str]) -> str:
    """Replace marker bodies in `existing` with the matching entry from
    `new_sections`. Content outside any marker pair is preserved verbatim, and
    markers inside fenced code blocks are left untouched as literal text.

    Sections present in `new_sections` but missing from `existing` are ignored
    (the caller decides whether to append them or overwrite the file entirely —
    first-run behavior per SPEC §3.4 is `write the generated README wholesale`).
    """
    fences = _fence_ranges(existing)
    out: list[str] = []
    last = 0
    for match in _MARKER_RE.finditer(existing):
        if _is_in_fence(match.start(), fences):
            continue
        name = match.group("name")
        if name not in new_sections:
            continue
        out.append(existing[last : match.start()])
        out.append(f"{marker_start(name)}{new_sections[name]}{marker_end(name)}")
        last = match.end()
    out.append(existing[last:])
    return "".join(out)
