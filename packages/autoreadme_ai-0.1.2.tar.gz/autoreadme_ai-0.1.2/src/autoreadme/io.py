"""README read/write with .bak backup and symlink guard (SPEC 3.4, 9).

Keep this tiny and side-effect-focused: the CLI orchestrates the decisions
(overwrite vs. merge, dry-run, etc.); this module only handles bytes on disk.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path


class IOError_(Exception):
    """Raised for unsafe or failed README I/O (distinct from builtin IOError)."""


@dataclass(frozen=True)
class WriteResult:
    path: Path
    backup: Path | None  # None if there was no prior README


def read_readme(path: Path) -> str | None:
    """Return the file's contents, or None if it doesn't exist.

    Refuses to follow symlinks (SPEC §9): a symlinked README could redirect
    writes outside the repo root.
    """
    if not path.exists():
        return None
    if path.is_symlink():
        raise IOError_(f"refusing to read symlink: {path}")
    if not path.is_file():
        raise IOError_(f"not a regular file: {path}")
    try:
        return path.read_text(encoding="utf-8")
    except OSError as e:
        raise IOError_(f"failed to read {path}: {e}") from e


def write_readme(path: Path, content: str, *, backup: bool = True) -> WriteResult:
    """Write `content` to `path`, backing up any existing file to `.bak` first.

    The backup is only created when an existing, non-symlink README is present
    and `backup=True`. A previous `.bak` is overwritten — we keep one generation,
    not a history.
    """
    if path.is_symlink():
        raise IOError_(f"refusing to overwrite symlink: {path}")
    if path.exists() and not path.is_file():
        raise IOError_(f"not a regular file: {path}")

    bak_path: Path | None = None
    if backup and path.exists():
        bak_path = path.with_suffix(path.suffix + ".bak")
        if bak_path.is_symlink():
            raise IOError_(f"refusing to overwrite symlink: {bak_path}")
        try:
            bak_path.write_bytes(path.read_bytes())
        except OSError as e:
            raise IOError_(f"failed to write backup {bak_path}: {e}") from e

    try:
        path.write_text(content, encoding="utf-8")
    except OSError as e:
        raise IOError_(f"failed to write {path}: {e}") from e

    return WriteResult(path=path, backup=bak_path)


__all__ = ["IOError_", "WriteResult", "read_readme", "write_readme"]
