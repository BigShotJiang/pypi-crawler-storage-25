# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.1.0] - TBD

Initial release.

### Added

- Static AST-based extractor for Python: module docstrings, class/function
  signatures, type hints, public API surface, CLI argument parsers
  (argparse/click/typer), and project metadata from `pyproject.toml` /
  `setup.py`.
- Single-call generation pipeline with embedded README template, fixed
  section order, and anti-hallucination instructions.
- Protected regions via `<!-- autoreadme:SECTION:start/end -->` markers so
  manual content between/outside markers is preserved across runs.
- Badge inference from repo state only (PyPI, Python versions, license, CI,
  downloads) — no network calls.
- LLM providers: Anthropic, OpenAI, Ollama (lazy-imported SDKs).
- CLI with `--provider`, `--model`, `--dry-run`, `--force`, `--show-payload`,
  `--verbose`, `--output`, `--version`.
- Colored unified diff with `Y/n/d/q` approval prompt and `$PAGER` routing.
- `.autoreadme.toml` config with CLI > file > env > default precedence.
- GitHub Action (`action.yml`) for running the tool from workflows.
- Privacy guarantee: the payload schema structurally cannot contain source
  code bodies. Before every LLM call, the tool prints the exact byte count
  it's about to send.

[Unreleased]: https://github.com/atharvakadam/autoreadme-ai/compare/v0.1.0...HEAD
[0.1.0]: https://github.com/atharvakadam/autoreadme-ai/releases/tag/v0.1.0
