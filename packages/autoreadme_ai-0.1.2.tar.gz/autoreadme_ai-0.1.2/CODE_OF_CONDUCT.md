# Code of Conduct

This project adopts the [Contributor Covenant v2.1][cc].

## Summary

- Be respectful. Assume good faith.
- Harassment, personal attacks, and discriminatory language are not tolerated.
- Disagreement is fine; keep it about the code, not the person.

## Reporting

Report unacceptable behavior to **atharvakadam@gmail.com**. Reports are handled
confidentially. Maintainers who violate the code of conduct are held to the
same standard as any other contributor.

## Full text

The full Contributor Covenant v2.1 text applies and is available at:
https://www.contributor-covenant.org/version/2/1/code_of_conduct/

[cc]: https://www.contributor-covenant.org/version/2/1/code_of_conduct/
