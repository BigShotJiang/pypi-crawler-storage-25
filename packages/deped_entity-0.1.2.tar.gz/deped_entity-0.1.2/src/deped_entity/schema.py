from __future__ import annotations

import sqlite3
from contextlib import closing
from hashlib import sha256
from importlib.resources import files
from importlib.resources.abc import Traversable
from pathlib import Path

from .catalog import SHEET_NAME
from .types import EntitiesDbStats, SQLiteConnection

SCHEMA_VERSION = "entities_v2"
_SQL: Traversable = files("deped_entity.sql")


def _read_sql(name: str) -> str:
    return _SQL.joinpath(name).read_text()


def _fetch_required_int(conn: SQLiteConnection, query: str) -> int:
    row = conn.execute(query).fetchone()
    if row is None:
        raise RuntimeError(f"Query returned no rows: {query}")
    return int(row[0])


def create_schema(conn: SQLiteConnection) -> None:
    conn.executescript(_read_sql("pragmas.sql"))
    for filename in (
        "tables/entities.sql",
        "tables/entity_nearby_institutions.sql",
        "tables/entity_road_conditions.sql",
        "tables/entity_transportation_modes.sql",
        "tables/entity_location_profiles.sql",
        "tables/entity_remoteness.sql",
        "tables/entity_community.sql",
        "tables/build_runs.sql",
    ):
        conn.executescript(_read_sql(filename))


def create_indexes(conn: SQLiteConnection) -> None:
    conn.executescript(_read_sql("indexes/entities.sql"))


def count_source_rows(input_path: str | Path) -> int:
    from deped_dcp_template.extractor import _sheet_rows

    rows = _sheet_rows(Path(input_path), SHEET_NAME)
    next(rows)
    return sum(1 for _ in rows)


def start_build_run(conn: SQLiteConnection, input_path: str | Path) -> int:
    path = Path(input_path)
    source_hash = sha256(path.read_bytes()).hexdigest()
    source_rows = count_source_rows(path)
    cursor = conn.execute(
        """
        INSERT INTO build_runs(
            build_type, started_at, schema_version,
            source_file, source_hash, source_rows
        ) VALUES (?, datetime('now'), ?, ?, ?, ?)
        """,
        ("full_rebuild", SCHEMA_VERSION, path.name, source_hash, source_rows),
    )
    conn.commit()
    if cursor.lastrowid is None:
        raise RuntimeError("Failed to create build run")
    return int(cursor.lastrowid)


def complete_build_run(
    conn: SQLiteConnection, build_run_id: int, kept_rows: int
) -> None:
    conn.execute(
        """
        UPDATE build_runs
        SET completed_at = datetime('now'),
            kept_rows = ?,
            entity_count = (SELECT COUNT(*) FROM entities)
        WHERE id = ?
        """,
        (kept_rows, build_run_id),
    )
    conn.commit()


def describe_entities_db(db_path: str | Path) -> EntitiesDbStats:
    with closing(sqlite3.connect(db_path)) as conn:
        return {
            "entities": _fetch_required_int(conn, "SELECT COUNT(*) FROM entities"),
            "distinct_natural_keys": _fetch_required_int(
                conn, "SELECT COUNT(DISTINCT natural_key) FROM entities"
            ),
            "rows_with_coordinates": _fetch_required_int(
                conn,
                "SELECT COUNT(*) FROM entities WHERE longitude IS NOT NULL AND latitude IS NOT NULL",
            ),
            "travel_time_parse_failures": _fetch_required_int(
                conn,
                """
                SELECT COUNT(*)
                FROM entity_location_profiles
                WHERE travel_time_raw IS NOT NULL AND travel_time_minutes IS NULL
                """,
            ),
            "build_runs": _fetch_required_int(conn, "SELECT COUNT(*) FROM build_runs"),
        }
