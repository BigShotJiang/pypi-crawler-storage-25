from __future__ import annotations

import click
from rich.console import Console
from rich.progress import Progress

from .entities import build_entities_db
from .schema import describe_entities_db

CONSOLE = Console(stderr=True)


@click.group()
def main() -> None:
    """Canonical stakeholder entity utilities."""


@main.command("build")
@click.option(
    "--input", "input_path", required=True, type=click.Path(exists=True, dir_okay=False)
)
@click.option("--db", "db_path", required=True, type=click.Path(dir_okay=False))
def build_command(input_path: str, db_path: str) -> None:
    with CONSOLE.status("Preparing entity build...", spinner="dots"):
        progress = Progress(console=CONSOLE)
        with progress:
            build_entities_db(input_path, db_path, progress=progress)
    click.echo(db_path)


@main.command("audit")
@click.option(
    "--db", "db_path", required=True, type=click.Path(exists=True, dir_okay=False)
)
def audit_command(db_path: str) -> None:
    with CONSOLE.status("Auditing entity database...", spinner="dots"):
        stats = describe_entities_db(db_path)
    for key, value in stats.items():
        click.echo(f"{key}={value}")


if __name__ == "__main__":
    main()
