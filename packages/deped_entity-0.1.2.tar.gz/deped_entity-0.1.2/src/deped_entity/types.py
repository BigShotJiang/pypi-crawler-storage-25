from __future__ import annotations

import sqlite3
from typing import Literal, TypeAlias, TypedDict

SQLiteConnection: TypeAlias = sqlite3.Connection
WorksheetCell: TypeAlias = object
WorksheetRow: TypeAlias = tuple[WorksheetCell, ...]
HeaderRow: TypeAlias = WorksheetRow | list[WorksheetCell]
HeaderIndex: TypeAlias = dict[str, int]
PresenceFlag: TypeAlias = Literal[1]
CoordinateAxis: TypeAlias = Literal["latitude", "longitude"]
CanonicalColumn: TypeAlias = tuple[str, str]
CanonicalColumns: TypeAlias = tuple[CanonicalColumn, ...]
TravelTimeResult: TypeAlias = tuple[float | None, str | None]
CoordinateParseResult: TypeAlias = tuple[float | None, str | None]
NormalizedTransportationResult: TypeAlias = tuple[str | None, str | None, list[str]]
EntityInsertRow: TypeAlias = tuple[
    int,
    str,
    str,
    str | None,
    str | None,
    str | None,
    str | None,
    str | None,
    int | None,
    str | None,
    str | None,
    str | None,
    str | None,
    str | None,
    float | None,
    float | None,
    str | None,
    str | None,
    str | None,
    str | None,
]


class EntitiesDbStats(TypedDict):
    entities: int
    distinct_natural_keys: int
    rows_with_coordinates: int
    travel_time_parse_failures: int
    build_runs: int
