from __future__ import annotations

import re
import sqlite3
from collections.abc import Iterable
from contextlib import closing
from datetime import time
from pathlib import Path
from typing import Literal

from deped_dcp_template.cleaners import (
    clean_text,
    normalize_header,
    normalize_school_id,
)
from deped_dcp_template.entities import build_natural_key, determine_entity_type
from deped_dcp_template.extractor import _sheet_rows
from rich.progress import Progress, TaskID

from .catalog import (
    BUSINESS_KEY_HEADERS,
    INSTITUTION_COLUMNS,
    OTHER_TRANSPORTATION_NULLS,
    REQUIRED_HEADERS,
    ROAD_CONDITION_COLUMNS,
    SHEET_NAME,
    TRANSPORTATION_ALIASES,
    TRANSPORTATION_MODE_COLUMNS,
)
from .schema import (
    complete_build_run,
    count_source_rows,
    create_indexes,
    create_schema,
    start_build_run,
)
from .types import (
    CanonicalColumns,
    CoordinateAxis,
    CoordinateParseResult,
    EntityInsertRow,
    HeaderIndex,
    HeaderRow,
    NormalizedTransportationResult,
    PresenceFlag,
    SQLiteConnection,
    TravelTimeResult,
    WorksheetRow,
)

RelationSpec = tuple[
    CanonicalColumns,
    Literal[
        "entity_nearby_institutions",
        "entity_road_conditions",
        "entity_transportation_modes",
    ],
    Literal[
        "institution_type",
        "road_condition_type",
        "transportation_mode",
    ],
]


def prepare_output_db(db_path: str | Path) -> None:
    base = Path(db_path)
    base.parent.mkdir(parents=True, exist_ok=True)
    for suffix in ("", "-wal", "-shm"):
        candidate = Path(f"{base}{suffix}")
        if candidate.exists():
            candidate.unlink()


def resolve_headers(headers: HeaderRow) -> HeaderIndex:
    header_index = {
        normalize_header(str(header)): index
        for index, header in enumerate(headers)
        if clean_text(str(header) if header is not None else None)
    }
    resolved: HeaderIndex = {}
    for header_name in REQUIRED_HEADERS:
        normalized_name = normalize_header(header_name)
        if normalized_name not in header_index:
            raise KeyError(f"Missing required header: {header_name}")
        resolved[header_name] = header_index[normalized_name]
    return resolved


def normalize_presence(value: object) -> PresenceFlag | None:
    text = (
        value if isinstance(value, str) else str(value) if value is not None else None
    )
    cleaned = clean_text(text)
    if cleaned is None or cleaned.lower() in {"0", "false", "no"}:
        return None
    return 1


def _raw_text(value: object) -> str | None:
    text = (
        value if isinstance(value, str) else str(value) if value is not None else None
    )
    return clean_text(text)


def _normalize_numeric_travel_time(value: object, raw: str | None) -> tuple[float, str]:
    if isinstance(value, time):
        minutes = value.hour * 60 + value.minute + value.second / 60
        return round(minutes, 2), raw or value.isoformat()
    numeric = float(value)
    minutes = numeric * 1440 if 0 < numeric < 1 else numeric
    return round(minutes, 2), raw or str(value)


def _normalize_text_travel_time(raw: str) -> float | None:
    normalized = raw.lower().replace("mins", "minutes").replace("min.", "minutes")
    normalized = normalized.replace("hrs", "hours").replace("hr.", "hours")
    range_match = re.search(
        r"(?P<start>\d+(?:\.\d+)?)\s*[-/]\s*(?P<end>\d+(?:\.\d+)?)",
        normalized,
    )
    if range_match:
        start = float(range_match.group("start"))
        end = float(range_match.group("end"))
        value_minutes = (start + end) / 2
        if "hour" in normalized:
            value_minutes *= 60
        return round(value_minutes, 2)

    numbers = [float(match) for match in re.findall(r"\d+(?:\.\d+)?", normalized)]
    if not numbers:
        return None
    if "hour" in normalized:
        if len(numbers) >= 2 and "minute" in normalized:
            return round(numbers[0] * 60 + numbers[1], 2)
        return round(numbers[0] * 60, 2)
    if "day" in normalized:
        return round(numbers[0] * 1440, 2)
    return round(numbers[0], 2)


def normalize_travel_time(value: object) -> TravelTimeResult:
    raw = _raw_text(value)
    if value is None:
        return None, None
    if isinstance(value, time) or (
        isinstance(value, (int, float)) and not isinstance(value, bool)
    ):
        minutes, rendered_raw = _normalize_numeric_travel_time(value, raw)
        return minutes, rendered_raw
    if raw is None:
        return None, None
    return _normalize_text_travel_time(raw), raw


def _apply_direction(value: float, direction: str | None) -> float:
    if direction is None:
        return value
    if direction.upper() in {"S", "W"}:
        return -abs(value)
    return abs(value)


def _validate_coordinate(value: float, axis: CoordinateAxis) -> float | None:
    limit = 90 if axis == "latitude" else 180
    if -limit <= value <= limit:
        return value
    return None


def parse_coordinate(value: object, axis: CoordinateAxis) -> CoordinateParseResult:
    raw = clean_text(
        value if isinstance(value, str) else str(value) if value is not None else None
    )
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        parsed = _validate_coordinate(float(value), axis)
        return parsed, raw or str(value)
    if raw is None:
        return None, None
    normalized = re.sub(r"\s+", " ", raw).strip()

    decimal_match = re.fullmatch(
        r"(?P<value>[+-]?\d+(?:\.\d+)?)\s*(?:°)?\s*(?P<direction>[NSEWnsew]|north|south|east|west)?",
        normalized,
    )
    if decimal_match:
        parsed = float(decimal_match.group("value"))
        direction = decimal_match.group("direction")
        if direction is not None:
            direction = direction[0]
        parsed = _apply_direction(parsed, direction)
        return _validate_coordinate(parsed, axis), raw

    dms_match = re.fullmatch(
        r"(?P<deg>\d+(?:\.\d+)?)\s*°\s*(?P<min>\d+(?:\.\d+)?)?\s*['’]?\s*(?P<sec>\d+(?:\.\d+)?)?\s*(?:\"|”)?\s*(?P<direction>[NSEWnsew])",
        normalized,
    )
    if dms_match:
        degrees = float(dms_match.group("deg"))
        minutes = float(dms_match.group("min") or 0)
        seconds = float(dms_match.group("sec") or 0)
        parsed = degrees + minutes / 60 + seconds / 3600
        parsed = _apply_direction(parsed, dms_match.group("direction"))
        return _validate_coordinate(parsed, axis), raw

    return None, raw


def _alias_key(value: str) -> str:
    return re.sub(r"[^a-z0-9]+", " ", value.lower()).strip()


def normalize_other_transportations(
    value: object,
) -> NormalizedTransportationResult:
    raw = clean_text(
        value if isinstance(value, str) else str(value) if value is not None else None
    )
    if raw is None:
        return None, None, []

    pieces = [raw]
    if not TRANSPORTATION_ALIASES.get(_alias_key(raw)):
        pieces = [piece.strip() for piece in re.split(r"[,\n;]+", raw) if piece.strip()]

    normalized_values: list[str] = []
    junction_values: list[str] = []
    known_modes = {canonical_name for _, canonical_name in TRANSPORTATION_MODE_COLUMNS}
    for piece in pieces:
        text = clean_text(piece)
        if text is None:
            continue
        alias_key = _alias_key(text)
        if (
            text in OTHER_TRANSPORTATION_NULLS
            or alias_key in OTHER_TRANSPORTATION_NULLS
        ):
            continue
        mapped = TRANSPORTATION_ALIASES.get(alias_key, text)
        if mapped not in normalized_values:
            normalized_values.append(mapped)
        if mapped in known_modes and mapped not in junction_values:
            junction_values.append(mapped)

    if not normalized_values:
        return raw, None, []
    return raw, "; ".join(normalized_values), junction_values


def _clean_value(row: WorksheetRow, header_index: HeaderIndex, name: str) -> str | None:
    value = row[header_index[name]]
    if value is None:
        return None
    return clean_text(str(value))


def _is_blank_business_row(row: WorksheetRow, header_index: HeaderIndex) -> bool:
    school_id = normalize_school_id(row[header_index["School ID"]])
    values = [
        _clean_value(row, header_index, name) for name in BUSINESS_KEY_HEADERS[:-1]
    ]
    return not any((*values, school_id))


def _require_source_row_id(row: WorksheetRow, header_index: HeaderIndex) -> int:
    source_row_id = normalize_school_id(row[header_index["ID"]])
    if source_row_id is None:
        raise ValueError("Row is missing a valid source ID")
    return source_row_id


def _build_entity_insert_row(
    row: WorksheetRow, header_index: HeaderIndex
) -> EntityInsertRow:
    governance_level = _clean_value(row, header_index, "Governance Level")
    regional_office = _clean_value(row, header_index, "Regional Office")
    school_division_office = _clean_value(row, header_index, "School Division Office")
    school_id = normalize_school_id(row[header_index["School ID"]])
    entity_type = determine_entity_type(governance_level)
    natural_key = build_natural_key(
        entity_type, school_id, regional_office, school_division_office
    )
    longitude, longitude_raw = parse_coordinate(
        row[header_index["Longitude"]], "longitude"
    )
    latitude, latitude_raw = parse_coordinate(row[header_index["Latitude"]], "latitude")
    return (
        _require_source_row_id(row, header_index),
        entity_type,
        natural_key,
        governance_level,
        regional_office,
        school_division_office,
        _clean_value(row, header_index, "School District"),
        _clean_value(row, header_index, "School Name"),
        school_id,
        _clean_value(row, header_index, "Province"),
        _clean_value(row, header_index, "City/Municipality"),
        _clean_value(row, header_index, "Barangay"),
        _clean_value(row, header_index, "Street"),
        _clean_value(row, header_index, "PSGC Code"),
        longitude,
        latitude,
        longitude_raw,
        latitude_raw,
        _clean_value(row, header_index, "Date Time Submitted"),
        _clean_value(row, header_index, "Type Of Transaction"),
    )


def _insert_entity(conn: SQLiteConnection, entity_row: EntityInsertRow) -> int:
    cursor = conn.execute(
        """--sql
        INSERT INTO entities(
            source_row_id, entity_type, natural_key, governance_level,
            regional_office, school_division_office, school_district,
            school_name, school_id, province, city_municipality,
            barangay, street, psgc_code, longitude, latitude,
            longitude_raw, latitude_raw, date_time_submitted,
            type_of_transaction
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);
        """,
        entity_row,
    )
    if cursor.lastrowid is None:
        raise RuntimeError("Failed to insert entity row")
    return int(cursor.lastrowid)


def _insert_checked_relations(
    conn: SQLiteConnection,
    entity_id: int,
    row: WorksheetRow,
    header_index: HeaderIndex,
) -> None:
    relation_specs: tuple[RelationSpec, ...] = (
        (
            INSTITUTION_COLUMNS,
            "entity_nearby_institutions",
            "institution_type",
        ),
        (
            ROAD_CONDITION_COLUMNS,
            "entity_road_conditions",
            "road_condition_type",
        ),
        (
            TRANSPORTATION_MODE_COLUMNS,
            "entity_transportation_modes",
            "transportation_mode",
        ),
    )
    for columns, table_name, value_column in relation_specs:
        for source_column, canonical_name in columns:
            if not normalize_presence(row[header_index[source_column]]):
                continue
            conn.execute(
                f"INSERT INTO {table_name}(entity_id, {value_column}) VALUES (?, ?)",
                (entity_id, canonical_name),
            )


def _insert_location_profile(
    conn: SQLiteConnection,
    entity_id: int,
    row: WorksheetRow,
    header_index: HeaderIndex,
) -> None:
    travel_time_minutes, travel_time_raw = normalize_travel_time(
        row[header_index["Travel Time To Nearest Municipality/City Center"]]
    )
    other_transportations_raw, other_transportations_normalized, extra_modes = (
        normalize_other_transportations(row[header_index["Other Transportations"]])
    )
    for mode in extra_modes:
        conn.execute(
            """
            INSERT OR IGNORE INTO entity_transportation_modes(entity_id, transportation_mode)
            VALUES (?, ?)
            """,
            (entity_id, mode),
        )

    location_values = (
        _clean_value(row, header_index, "Other Institutions"),
        travel_time_minutes,
        travel_time_raw,
        other_transportations_raw,
        other_transportations_normalized,
    )
    if not any(value is not None for value in location_values):
        return
    conn.execute(
        """
        INSERT INTO entity_location_profiles(
            entity_id, other_institutions, travel_time_minutes,
            travel_time_raw, other_transportations,
            other_transportations_normalized
        ) VALUES (?, ?, ?, ?, ?, ?)
        """,
        (entity_id, *location_values),
    )


def _insert_remoteness(
    conn: SQLiteConnection,
    entity_id: int,
    row: WorksheetRow,
    header_index: HeaderIndex,
) -> None:
    remoteness_values = (
        normalize_presence(row[header_index["Transportation to School is Difficult"]]),
        normalize_presence(row[header_index["Considered Very Remote"]]),
        _clean_value(row, header_index, "If School very remote"),
        normalize_presence(
            row[
                header_index[
                    "GIDCA/Geographically Isolated Disadvantaged And Conflict Affected Areas"
                ]
            ]
        ),
        normalize_presence(row[header_index["LMS/Last Mile School"]]),
    )
    if not any(value is not None for value in remoteness_values):
        return
    conn.execute(
        """
        INSERT INTO entity_remoteness(
            entity_id, transportation_difficult, considered_very_remote,
            very_remote_explanation, gidca, last_mile_school
        ) VALUES (?, ?, ?, ?, ?, ?)
        """,
        (entity_id, *remoteness_values),
    )


def _insert_community(
    conn: SQLiteConnection,
    entity_id: int,
    row: WorksheetRow,
    header_index: HeaderIndex,
) -> None:
    community_values = (
        normalize_presence(row[header_index["Active PTA"]]),
        normalize_presence(row[header_index["LGU Support"]]),
        normalize_presence(row[header_index["Barangay Engagement"]]),
        _clean_value(
            row,
            header_index,
            "Remarks on community context and school infrastructure that may be material for connectivity",
        ),
    )
    if not any(value is not None for value in community_values):
        return
    conn.execute(
        """
        INSERT INTO entity_community(
            entity_id, active_pta, lgu_support,
            barangay_engagement, remarks
        ) VALUES (?, ?, ?, ?, ?)
        """,
        (entity_id, *community_values),
    )


def _insert_related_rows(
    conn: SQLiteConnection,
    entity_id: int,
    row: WorksheetRow,
    header_index: HeaderIndex,
) -> None:
    _insert_checked_relations(conn, entity_id, row, header_index)
    _insert_location_profile(conn, entity_id, row, header_index)
    _insert_remoteness(conn, entity_id, row, header_index)
    _insert_community(conn, entity_id, row, header_index)


def _load_entity_rows(
    conn: SQLiteConnection,
    rows: Iterable[WorksheetRow],
    header_index: HeaderIndex,
    input_path: str | Path,
    progress: Progress | None = None,
) -> int:
    kept_rows = 0
    task_id: TaskID | None = None
    if progress is not None:
        task_id = progress.add_task(
            f"Load entities: {Path(input_path).name}",
            total=count_source_rows(input_path),
        )
    for row in rows:
        if progress is not None and task_id is not None:
            progress.advance(task_id)
        if _is_blank_business_row(row, header_index):
            continue
        entity_id = _insert_entity(conn, _build_entity_insert_row(row, header_index))
        _insert_related_rows(conn, entity_id, row, header_index)
        kept_rows += 1
    if progress is not None and task_id is not None:
        progress.update(task_id, completed=count_source_rows(input_path))
    return kept_rows


def build_entities_db(
    input_path: str | Path,
    db_path: str | Path,
    progress: Progress | None = None,
) -> None:
    prepare_output_db(db_path)
    with closing(sqlite3.connect(db_path)) as conn:
        create_schema(conn)
        build_run_id = start_build_run(conn, input_path)
        rows = _sheet_rows(Path(input_path), SHEET_NAME)
        header_row = next(rows)
        header_index = resolve_headers(header_row)
        kept_rows = _load_entity_rows(conn, rows, header_index, input_path, progress)
        create_indexes(conn)
        complete_build_run(conn, build_run_id, kept_rows)
        conn.commit()
