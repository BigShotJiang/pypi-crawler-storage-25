"""Canonical stakeholder entity build package."""
