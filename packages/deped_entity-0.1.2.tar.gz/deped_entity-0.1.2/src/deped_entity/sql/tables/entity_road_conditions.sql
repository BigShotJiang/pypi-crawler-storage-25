CREATE TABLE entity_road_conditions (
    entity_id INTEGER NOT NULL REFERENCES entities(entity_id) ON DELETE CASCADE,
    road_condition_type TEXT NOT NULL CHECK (
        road_condition_type IN (
            'Paved',
            'Unpaved',
            'Levelled',
            'Unlevelled/Rough Road',
            'On Going Construction'
        )
    ),
    PRIMARY KEY (entity_id, road_condition_type)
);
