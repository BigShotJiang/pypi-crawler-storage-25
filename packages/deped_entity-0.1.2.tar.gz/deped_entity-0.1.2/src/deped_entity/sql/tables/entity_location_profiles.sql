CREATE TABLE entity_location_profiles (
    entity_id INTEGER PRIMARY KEY REFERENCES entities(entity_id) ON DELETE CASCADE,
    other_institutions TEXT,
    travel_time_minutes REAL,
    travel_time_raw TEXT,
    other_transportations TEXT,
    other_transportations_normalized TEXT
);
