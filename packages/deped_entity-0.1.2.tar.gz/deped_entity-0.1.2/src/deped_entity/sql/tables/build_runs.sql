CREATE TABLE build_runs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    build_type TEXT NOT NULL,
    started_at TEXT NOT NULL,
    completed_at TEXT,
    schema_version TEXT NOT NULL,
    source_file TEXT NOT NULL,
    source_hash TEXT NOT NULL,
    source_rows INTEGER NOT NULL,
    kept_rows INTEGER,
    entity_count INTEGER
);
