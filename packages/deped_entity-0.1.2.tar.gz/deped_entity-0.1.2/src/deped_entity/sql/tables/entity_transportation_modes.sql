CREATE TABLE entity_transportation_modes (
    entity_id INTEGER NOT NULL REFERENCES entities(entity_id) ON DELETE CASCADE,
    transportation_mode TEXT NOT NULL CHECK (
        transportation_mode IN (
            'Private 4 Wheel Vehicle',
            'Private Motorcycle',
            'Boat',
            'Pedicab',
            'Tricycle',
            'Jeepney',
            'Bus',
            'Habal Habal',
            'Train',
            'UV Express',
            'Biking',
            'Walking/Hiking'
        )
    ),
    PRIMARY KEY (entity_id, transportation_mode)
);
