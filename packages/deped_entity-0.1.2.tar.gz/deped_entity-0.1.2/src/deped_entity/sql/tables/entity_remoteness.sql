CREATE TABLE entity_remoteness (
    entity_id INTEGER PRIMARY KEY REFERENCES entities(entity_id) ON DELETE CASCADE,
    transportation_difficult INTEGER,
    considered_very_remote INTEGER,
    very_remote_explanation TEXT,
    gidca INTEGER,
    last_mile_school INTEGER
);
