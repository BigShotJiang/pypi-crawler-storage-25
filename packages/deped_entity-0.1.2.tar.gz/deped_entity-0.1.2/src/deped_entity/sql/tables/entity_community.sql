CREATE TABLE entity_community (
    entity_id INTEGER PRIMARY KEY REFERENCES entities(entity_id) ON DELETE CASCADE,
    active_pta INTEGER,
    lgu_support INTEGER,
    barangay_engagement INTEGER,
    remarks TEXT
);
