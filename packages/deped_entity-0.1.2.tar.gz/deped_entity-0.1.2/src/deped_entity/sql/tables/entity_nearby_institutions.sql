CREATE TABLE entity_nearby_institutions (
    entity_id INTEGER NOT NULL REFERENCES entities(entity_id) ON DELETE CASCADE,
    institution_type TEXT NOT NULL CHECK (
        institution_type IN (
            'Provincial/City/Municipal Hall',
            'Barangay Hall',
            'Police Station',
            'Health Center',
            'Fire Station',
            'Hospital',
            'Church/Mosque',
            'Airport',
            'Port',
            'Central/Integrated Terminal',
            'Market',
            'Mall'
        )
    ),
    PRIMARY KEY (entity_id, institution_type)
);
