CREATE INDEX idx_entities_natural_key ON entities(natural_key);
CREATE INDEX idx_entities_entity_type ON entities(entity_type);
CREATE INDEX idx_entities_school_id ON entities(school_id);
CREATE INDEX idx_entities_regional_office ON entities(regional_office);
CREATE INDEX idx_entities_school_division_office ON entities(school_division_office);
CREATE INDEX idx_build_runs_completed_at ON build_runs(completed_at);
