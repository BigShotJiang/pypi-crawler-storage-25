from __future__ import annotations

from pathlib import Path

from click.testing import CliRunner

from deped_entity.cli import main
from tests.conftest import sample_stakeholder_rows, write_workbook


def test_cli_build_and_audit_commands(tmp_path: Path) -> None:
    runner = CliRunner()
    workbook_path = tmp_path / "entities.xlsx"
    db_path = tmp_path / "entities.db"
    write_workbook(workbook_path, sample_stakeholder_rows())

    build_result = runner.invoke(
        main, ["build", "--input", str(workbook_path), "--db", str(db_path)]
    )
    assert build_result.exit_code == 0
    assert str(db_path) in build_result.output

    audit_result = runner.invoke(main, ["audit", "--db", str(db_path)])
    assert audit_result.exit_code == 0
    assert "entities=4" in audit_result.output
    assert "distinct_natural_keys=3" in audit_result.output
    assert "rows_with_coordinates=2" in audit_result.output
    assert "travel_time_parse_failures=0" in audit_result.output
