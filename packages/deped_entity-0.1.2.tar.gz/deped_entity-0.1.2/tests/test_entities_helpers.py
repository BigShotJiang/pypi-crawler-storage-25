from __future__ import annotations

import pytest
from deped_dcp_template.entities import build_natural_key, determine_entity_type

from deped_entity.catalog import REQUIRED_HEADERS
from deped_entity.entities import (
    normalize_other_transportations,
    normalize_travel_time,
    parse_coordinate,
    resolve_headers,
)
from deped_entity.types import CoordinateAxis


def test_resolve_headers_uses_header_text_not_column_order() -> None:
    spaced_headers = [header.replace(" ", "  ") for header in REQUIRED_HEADERS]

    resolved = resolve_headers(spaced_headers)

    assert resolved["Governance Level"] == REQUIRED_HEADERS.index("Governance Level")
    assert resolved["Other Transportations"] == REQUIRED_HEADERS.index(
        "Other Transportations"
    )


@pytest.mark.parametrize(
    ("value", "expected_minutes"),
    [
        (0.03125, 45.0),
        (15, 15.0),
        ("20-25 MINUTES", 22.5),
        ("1 hour 30 minutes", 90.0),
        ("N/A", None),
    ],
)
def test_normalize_travel_time(value: object, expected_minutes: float | None) -> None:
    minutes, _ = normalize_travel_time(value)

    assert minutes == expected_minutes


@pytest.mark.parametrize(
    ("value", "axis", "expected"),
    [
        ("122.44715° east", "longitude", 122.44715),
        ("13°57'08.9 N", "latitude", 13.95247),
        ("7.50252, 124.88534", "latitude", None),
        (
            "--------------------------------------------------------------------",
            "longitude",
            None,
        ),
    ],
)
def test_parse_coordinate(
    value: object, axis: CoordinateAxis, expected: float | None
) -> None:
    parsed, _ = parse_coordinate(value, axis)

    if expected is None:
        assert parsed is None
    else:
        assert parsed == pytest.approx(expected, rel=1e-5)


def test_normalize_other_transportations_handles_aliases_and_null_markers() -> None:
    raw, normalized, junctions = normalize_other_transportations("Pumpboat/Banca")
    assert raw == "Pumpboat/Banca"
    assert normalized == "Boat"
    assert junctions == ["Boat"]

    raw, normalized, junctions = normalize_other_transportations("Ebike, Taxi, ✓")
    assert raw == "Ebike, Taxi, ✓"
    assert normalized == "E-Bike; Taxi"
    assert junctions == []

    raw, normalized, junctions = normalize_other_transportations("No")
    assert raw in {None, "No"}
    assert normalized is None
    assert junctions == []


def test_shared_entity_helpers_match_expected_natural_keys() -> None:
    assert determine_entity_type("school") == "SCHOOL"
    assert build_natural_key("SCHOOL", 123456, "Region V", "Catanduanes") == (
        "SCHOOL:123456"
    )
    assert (
        build_natural_key("DIVISION_OFFICE", None, "Region V", "Catanduanes")
        == "DIVISION_OFFICE:Region V:Catanduanes"
    )
    assert build_natural_key("REGIONAL_OFFICE", None, "Region I", None) == (
        "REGIONAL_OFFICE:Region I"
    )
