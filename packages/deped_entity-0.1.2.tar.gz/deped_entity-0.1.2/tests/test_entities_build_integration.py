from __future__ import annotations

import sqlite3
from contextlib import closing
from pathlib import Path

import pytest

from deped_entity.entities import build_entities_db
from tests.conftest import sample_stakeholder_rows, write_workbook


def test_build_entities_db_creates_canonical_artifact(
    tmp_path: Path,
) -> None:
    workbook_path = tmp_path / "entities.xlsx"
    db_path = tmp_path / "entities.db"
    write_workbook(workbook_path, sample_stakeholder_rows())

    build_entities_db(workbook_path, db_path)

    with closing(sqlite3.connect(db_path)) as conn:
        assert conn.execute("SELECT COUNT(*) FROM entities").fetchone()[0] == 4
        assert (
            conn.execute("SELECT COUNT(DISTINCT natural_key) FROM entities").fetchone()[
                0
            ]
            == 3
        )
        assert (
            conn.execute(
                "SELECT COUNT(*) FROM entities WHERE source_row_id = 4"
            ).fetchone()[0]
            == 0
        )
        assert (
            conn.execute(
                "SELECT type_of_transaction FROM entities WHERE source_row_id = 2"
            ).fetchone()[0]
            == "Stock Position"
        )
        assert conn.execute(
            "SELECT longitude IS NULL, latitude IS NULL FROM entities WHERE source_row_id = 2"
        ).fetchone() == (1, 1)
        assert conn.execute(
            """
            SELECT travel_time_minutes, travel_time_raw,
                   other_transportations, other_transportations_normalized
            FROM entity_location_profiles
            WHERE entity_id = (
                SELECT entity_id FROM entities WHERE source_row_id = 1
            )
            """
        ).fetchone() == (45.0, "0.03125", "Pumpboat/Banca", "Boat")
        assert (
            conn.execute(
                """
            SELECT COUNT(*)
            FROM entity_transportation_modes etm
            WHERE etm.entity_id = (
                SELECT entity_id FROM entities WHERE source_row_id = 1
            )
              AND etm.transportation_mode = 'Boat'
            """
            ).fetchone()[0]
            == 1
        )
        with pytest.raises(sqlite3.IntegrityError):
            conn.execute(
                """
                INSERT INTO entity_transportation_modes(entity_id, transportation_mode)
                VALUES (
                    (SELECT entity_id FROM entities WHERE source_row_id = 1),
                    'Boat'
                )
                """
            )
        assert conn.execute(
            """
            SELECT build_type, source_file, source_rows, kept_rows, entity_count,
                   completed_at IS NOT NULL
            FROM build_runs
            """
        ).fetchone() == ("full_rebuild", "entities.xlsx", 5, 4, 4, 1)
