from __future__ import annotations

from pathlib import Path
from typing import TypeAlias

import pytest
from openpyxl import Workbook

from deped_entity.catalog import (
    INSTITUTION_COLUMNS,
    ROAD_CONDITION_COLUMNS,
    SHEET_NAME,
    TRANSPORTATION_MODE_COLUMNS,
)

StakeholderWorkbookRow: TypeAlias = dict[str, object]

TEST_HEADERS = [
    "ID",
    "Governance Level",
    "Regional Office",
    "School Division Office",
    "School District",
    "School Name",
    "School ID",
    "Province",
    "City/Municipality",
    "Barangay",
    "Street",
    "PSGC Code",
    "Longitude",
    "Latitude",
    "Other Institutions",
    "Travel Time To Nearest Municipality/City Center",
    *[column for column, _ in ROAD_CONDITION_COLUMNS],
    *[column for column, _ in TRANSPORTATION_MODE_COLUMNS],
    "Other Transportations",
    "Transportation to School is Difficult",
    "Considered Very Remote",
    "If School very remote",
    "GIDCA/Geographically Isolated Disadvantaged And Conflict Affected Areas",
    "LMS/Last Mile School",
    "Active PTA",
    "LGU Support",
    "Barangay Engagement",
    "Remarks on community context and school infrastructure that may be material for connectivity",
    "Date Time Submitted",
    "Type Of Transaction",
    *[column for column, _ in INSTITUTION_COLUMNS],
]


def write_workbook(path: Path, rows: list[StakeholderWorkbookRow]) -> None:
    workbook = Workbook()
    worksheet = workbook.active
    worksheet.title = SHEET_NAME
    worksheet.append(TEST_HEADERS)
    for row in rows:
        worksheet.append([row.get(header) for header in TEST_HEADERS])
    workbook.save(path)


def sample_stakeholder_rows() -> list[StakeholderWorkbookRow]:
    return [
        {
            "ID": 1,
            "Governance Level": "SCHOOL",
            "Regional Office": "Region V",
            "School Division Office": "Catanduanes",
            "School District": "Virac North",
            "School Name": "Virac Central School",
            "School ID": 123456,
            "Province": "Catanduanes",
            "City/Municipality": "Virac",
            "Barangay": "San Isidro",
            "Street": "Main Road",
            "PSGC Code": "0517000000",
            "Longitude": "122.44715° east",
            "Latitude": "13.70718° north",
            "Other Institutions": "Satellite clinic",
            "Travel Time To Nearest Municipality/City Center": 0.03125,
            "Paved": 1,
            "Private Motorcycle": 1,
            "Walking/Hiking": 1,
            "Other Transportations": "Pumpboat/Banca",
            "Transportation to School is Difficult": 1,
            "Considered Very Remote": 1,
            "If School very remote": "Needs 4x4",
            "GIDCA/Geographically Isolated Disadvantaged And Conflict Affected Areas": 1,
            "LMS/Last Mile School": 1,
            "Active PTA": 1,
            "LGU Support": 1,
            "Barangay Engagement": 1,
            "Remarks on community context and school infrastructure that may be material for connectivity": "Unstable power",
            "Date Time Submitted": "2026-03-31 16:26:21",
            "Type Of Transaction": "Beginning Inventory",
            "Barangay Hall": 1,
            "Church Mosque": 1,
        },
        {
            "ID": 2,
            "Governance Level": "SCHOOL",
            "Regional Office": "Region V",
            "School Division Office": "Catanduanes",
            "School District": "Virac North",
            "School Name": "Virac Central School",
            "School ID": 123456,
            "Province": "Catanduanes",
            "City/Municipality": "Virac",
            "Barangay": "San Isidro",
            "Street": "Main Road",
            "PSGC Code": "0517000000",
            "Longitude": "124.8855    124.8855",
            "Latitude": "7.50252, 124.88534",
            "Travel Time To Nearest Municipality/City Center": "20-25 MINUTES",
            "Other Transportations": "Ebike, Taxi, ✓",
            "Date Time Submitted": "2026-03-31 17:00:00",
            "Type Of Transaction": "Stock Position",
        },
        {
            "ID": 3,
            "Governance Level": "DIVISION_OFFICE",
            "Regional Office": "CARAGA",
            "School Division Office": "Agusan del Norte",
            "School Name": "Agusan del Norte Division Office",
            "Travel Time To Nearest Municipality/City Center": "30 minutes",
            "Date Time Submitted": "2026-03-24 17:00:00",
            "Type Of Transaction": "Issuance/Transfer",
            "Bus": 1,
            "Market": 1,
        },
        {
            "ID": 4,
            "Type Of Transaction": "Beginning Inventory",
        },
        {
            "ID": 5,
            "Governance Level": "REGIONAL_OFFICE",
            "Regional Office": "Region I",
            "School Name": "Region I Regional Office",
            "Longitude": "120.82",
            "Latitude": "15.0",
            "Travel Time To Nearest Municipality/City Center": "1 hour 30 minutes",
            "Other Transportations": "No",
            "Date Time Submitted": "2026-03-28 15:03:12",
            "Type Of Transaction": "Beginning Inventory",
            "Airport": 1,
        },
    ]


@pytest.fixture
def stakeholder_rows() -> list[StakeholderWorkbookRow]:
    return sample_stakeholder_rows()
