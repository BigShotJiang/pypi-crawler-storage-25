# DepEd Entity

Builds the canonical stakeholder entity SQLite artifact from the
`StakeholderProfile` workbook. The package is the source of truth for entity
identity across schools, division offices, and regional offices.

## What This Package Owns

- Header-driven extraction from `StakeholderProfile`
- Canonical `entities.db` artifact creation
- Normalization for travel time, coordinates, and transportation aliases
- Canonical relation tables for nearby institutions, road conditions, and transportation modes
- Build provenance through `build_runs`

This package owns the entity artifact only. Consumer-specific reporting surfaces
belong in downstream packages.

## Inputs

- A stakeholder workbook under `data/` with the expected `StakeholderProfile`
  headers

## Outputs

- `artifacts/entities.db`

The output database contains row-level provenance, canonical entity identity,
location and remoteness details, community metadata, and build-run provenance.

## Main Commands

Build the artifact:

```sh
uv run entity build \
  --input data/2026-04-02-entities.xlsx \
  --db artifacts/entities.db
```

Audit the artifact:

```sh
uv run entity audit \
  --db artifacts/entities.db
```

## Behavioral Notes

- Header mapping is by text, not Excel column letter.
- Rows with blank business-key fields are skipped.
- All remaining stakeholder rows are retained, regardless of
  `Type Of Transaction`.
- `natural_key` semantics match the shared helpers from
  `deped-dcp-template`.
- Multiple source rows may share the same `natural_key`; row provenance and
  canonical identity are both preserved.
