# Development

## Local Workflow

Build the artifact from the default workbook:

```sh
just build
```

Inspect the generated database:

```sh
just audit
```

Run tests:

```sh
uv run pytest -q
```

Run lint checks:

```sh
uv run ruff check
```

## Implementation Notes

- The loader is intentionally header-driven. If the workbook changes column
  order but keeps the same headers, the build should continue to work.
- Normalization rules live in `src/deped_entity/entities.py`.
- Schema creation and artifact-level metadata live in
  `src/deped_entity/schema.py`.
- SQL assets live under `src/deped_entity/sql/`.

## Documentation

This repository uses Zensical for documentation. The site configuration lives in
`zensical.toml`, and Markdown sources live in `docs/`.

Build the docs locally with:

```sh
uv run zensical build
```

Serve them locally with:

```sh
uv run zensical serve --dev-addr localhost:8002
```

## Verification Expectations

When validating a real workbook build, check at least:

- total `entities`
- total `distinct_natural_keys`
- total rows with parsed coordinates
- total travel-time parse failures
- one completed `build_runs` row for the run you just performed

## Downstream Compatibility

The package is designed so downstream projects can join on `natural_key`
without re-deriving entity identity from their own source files. If a consumer
currently owns its own entity table, the intended migration path is to switch
that package to consume `entities.db` rather than duplicate entity extraction.
