# Build Guide

This page covers the expected workflow for producing the entity artifact.

## Prerequisites

- Python 3.14+
- `uv`
- A stakeholder workbook with the expected `StakeholderProfile` headers

## 1. Build The Entity Database

Run the build from the repository root:

```sh
uv run entity build \
  --input data/2026-04-02-entities.xlsx \
  --db artifacts/entities.db
```

Arguments:

- `--input`: source workbook path
- `--db`: destination SQLite database path

The command prints the output database path on success.

## 2. Audit The Result

Run the audit command after the build:

```sh
uv run entity audit \
  --db artifacts/entities.db
```

Current audit output includes:

- `entities`
- `distinct_natural_keys`
- `rows_with_coordinates`
- `travel_time_parse_failures`
- `build_runs`

## Generated Files

The build produces:

- `artifacts/entities.db`

The output database includes canonical entity rows, supporting detail tables,
canonical relation tables for nearby institutions, road conditions, and
transportation modes, and build provenance.

## Normalization Performed During Build

The build does more than copy workbook values verbatim. It also:

- resolves workbook columns by header text
- skips fully blank business-key rows
- derives `entity_type` and `natural_key` with shared helpers
- parses and normalizes coordinates conservatively
- normalizes travel time into minutes while retaining source text
- normalizes transportation aliases and backfills canonical transport modes
- records provenance and counts in `build_runs`

## Failure Modes

Common causes of build failure:

- Missing input files
- Missing or malformed required workbook headers
- Source rows without a valid `ID`
- Environment issues that prevent `uv` from resolving dependencies

If `uv run entity ...` fails before Python starts, verify the package entry
point in `pyproject.toml` and confirm your local environment can build the
project.
