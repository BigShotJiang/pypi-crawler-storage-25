# Data Contract

`deped-entity` owns the canonical entity artifact for stakeholder profile data.
The SQLite database is intended to be consumed by downstream packages that need
stable entity identity for schools, division offices, and regional offices.

## Core Tables

- `entities`
- `entity_nearby_institutions`
- `entity_road_conditions`
- `entity_transportation_modes`
- `entity_location_profiles`
- `entity_remoteness`
- `entity_community`
- `build_runs`

## Entity Semantics

- `entities` is the canonical row-level fact table for stakeholder profile rows.
- `source_row_id` is the unique workbook row identifier from column `ID`.
- `natural_key` is the canonical entity identity shared across packages.
- Multiple rows may share the same `natural_key`; this is expected when the
  workbook contains multiple records for the same school or office.

### Important `entities` Columns

- `entity_type`
- `natural_key`
- `governance_level`
- `regional_office`
- `school_division_office`
- `school_district`
- `school_name`
- `school_id`
- `province`
- `city_municipality`
- `barangay`
- `street`
- `psgc_code`
- `longitude`
- `latitude`
- `longitude_raw`
- `latitude_raw`
- `date_time_submitted`
- `type_of_transaction`

## Identity Model

- `source_row_id` is unique per source row.
- `natural_key` is stable per canonical entity.
- Multiple rows may map to one `natural_key` when the workbook contains more
  than one row for the same school or office.
- Downstream consumers should join on `natural_key` when they want canonical
  entity identity and keep `source_row_id` when they need exact source-row
  provenance.

## Canonical Relation Tables

The three relation tables model checked workbook columns as wide-to-long
relations so consumers can query them without hard-coding workbook headers.

- `entity_nearby_institutions` stores `institution_type`
- `entity_road_conditions` stores `road_condition_type`
- `entity_transportation_modes` stores `transportation_mode`

Each table stores the canonical text value directly and enforces the allowed
closed set in SQLite with `CHECK` constraints. There are no separate lookup
tables for these values.

## Detail Tables

- `entity_location_profiles` stores free-text and normalized location-related
  fields such as travel time and other transportation aliases.
- `entity_remoteness` stores remoteness and access flags.
- `entity_community` stores community participation flags and remarks.

## Provenance

`build_runs` records:

- build type
- schema version
- source filename
- source file hash
- source row count
- kept row count
- final entity count
- completion timestamp

Current schema version: `entities_v2`

## Cleaning Rules

- Header mapping is by header text, not column position.
- Rows with empty business-key fields are skipped.
- `travel_time_minutes` is normalized from numeric or common text formats and
  `travel_time_raw` preserves the source value.
- Coordinates are parsed conservatively. When parsing is uncertain or invalid,
  normalized coordinates remain null and the raw text is retained.
- `other_transportations_normalized` stores alias-normalized values and may also
  populate `entity_transportation_modes` when the alias resolves to an existing
  canonical transport mode.

## Downstream Use

- Use `entities` as the canonical join surface for schools, division offices,
  and regional offices.
- Use the junction tables when filtering on nearby institutions, road
  conditions, or transportation modes.
- Use `build_runs` to validate provenance before depending on a built artifact.
