# -*- coding: utf-8 -*-

from typing import Any

from .__base__ import BaseJWT
from .module import JWT
from .__types__ import KeyLike
from jam.logger import BaseLogger, logger
from jam.encoders import BaseEncoder, JsonEncoder


def create_instance(
    alg: str,
    secret: KeyLike | None = None,
    secret_key: KeyLike | None = None,  # Backward compatibility
    password: str | bytes | None = None,
    list: dict[str, Any] | None = None,
    logger: BaseLogger = logger,
    serializer: BaseEncoder | type[BaseEncoder] = JsonEncoder,
    **kwargs: Any
) -> JWT:
    """Create JWT instance.

    Args:
        alg: Algorithm (HS256, RS256, etc.)
        secret: Secret key (or use secret_key for backward compatibility)
        secret_key: Alias for secret (deprecated, use 'secret')
        password: Password for encrypted keys
        list: List config
        logger: Logger instance
        serializer: JSON encoder/decoder
        **kwargs: Additional params (e.g., custom_module)

    Returns:
        JWT instance or custom module
    """
    # Handle backward compatibility: secret_key -> secret
    if secret is None and secret_key is not None:
        secret = secret_key
    elif secret is None:
        raise ValueError("Either 'secret' or 'secret_key' must be provided")

    if kwargs.get("custom_module"):
        from jam.utils.config_maker import __module_loader__
        module_cls = __module_loader__(kwargs["custom_module"])
        return module_cls(
            alg=alg,
            secret=secret,
            password=password,
            list=list,
            logger=logger,
            serializer=serializer
        )

    return JWT(
        alg=alg,
        secret=secret,
        password=password,
        list=list,
        logger=logger,
        serializer=serializer
    )


__all__ = ["JWT", "BaseJWT", "create_instance"]
