from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote
import httpx
from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.get_process_definition_instance_version_statistics_data import GetProcessDefinitionInstanceVersionStatisticsData
from ...models.get_process_definition_instance_version_statistics_response_200 import GetProcessDefinitionInstanceVersionStatisticsResponse200
from ...models.get_process_definition_instance_version_statistics_response_400 import GetProcessDefinitionInstanceVersionStatisticsResponse400
from ...models.get_process_definition_instance_version_statistics_response_401 import GetProcessDefinitionInstanceVersionStatisticsResponse401
from ...models.get_process_definition_instance_version_statistics_response_403 import GetProcessDefinitionInstanceVersionStatisticsResponse403
from ...models.get_process_definition_instance_version_statistics_response_500 import GetProcessDefinitionInstanceVersionStatisticsResponse500
from ...types import UNSET, Response, Unset

def _get_kwargs(process_definition_id: str, *, body: GetProcessDefinitionInstanceVersionStatisticsData | Unset=UNSET) -> dict[str, Any]:
    headers: dict[str, Any] = {}
    _kwargs: dict[str, Any] = {'method': 'post', 'url': '/process-definitions/{process_definition_id}/statistics/process-instances'.format(process_definition_id=quote(str(process_definition_id), safe=''))}
    if not isinstance(body, Unset):
        _kwargs['json'] = body.to_dict()
    headers['Content-Type'] = 'application/json'
    _kwargs['headers'] = headers
    return _kwargs

def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> GetProcessDefinitionInstanceVersionStatisticsResponse200 | GetProcessDefinitionInstanceVersionStatisticsResponse400 | GetProcessDefinitionInstanceVersionStatisticsResponse401 | GetProcessDefinitionInstanceVersionStatisticsResponse403 | GetProcessDefinitionInstanceVersionStatisticsResponse500 | None:
    if response.status_code == 200:
        response_200 = GetProcessDefinitionInstanceVersionStatisticsResponse200.from_dict(response.json())
        return response_200
    if response.status_code == 400:
        response_400 = GetProcessDefinitionInstanceVersionStatisticsResponse400.from_dict(response.json())
        return response_400
    if response.status_code == 401:
        response_401 = GetProcessDefinitionInstanceVersionStatisticsResponse401.from_dict(response.json())
        return response_401
    if response.status_code == 403:
        response_403 = GetProcessDefinitionInstanceVersionStatisticsResponse403.from_dict(response.json())
        return response_403
    if response.status_code == 500:
        response_500 = GetProcessDefinitionInstanceVersionStatisticsResponse500.from_dict(response.json())
        return response_500
    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None

def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[GetProcessDefinitionInstanceVersionStatisticsResponse200 | GetProcessDefinitionInstanceVersionStatisticsResponse400 | GetProcessDefinitionInstanceVersionStatisticsResponse401 | GetProcessDefinitionInstanceVersionStatisticsResponse403 | GetProcessDefinitionInstanceVersionStatisticsResponse500]:
    return Response(status_code=HTTPStatus(response.status_code), content=response.content, headers=response.headers, parsed=_parse_response(client=client, response=response))

def sync_detailed(process_definition_id: str, *, client: AuthenticatedClient | Client, body: GetProcessDefinitionInstanceVersionStatisticsData | Unset=UNSET) -> Response[GetProcessDefinitionInstanceVersionStatisticsResponse200 | GetProcessDefinitionInstanceVersionStatisticsResponse400 | GetProcessDefinitionInstanceVersionStatisticsResponse401 | GetProcessDefinitionInstanceVersionStatisticsResponse403 | GetProcessDefinitionInstanceVersionStatisticsResponse500]:
    """Get process instance statistics by version

     Get statistics about process instances, grouped by version for a given process definition.

    Args:
        process_definition_id (str): Id of a process definition, from the model. Only ids of
            process definitions that are deployed are useful. Example: new-account-onboarding-
            workflow.
        body (GetProcessDefinitionInstanceVersionStatisticsData | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[GetProcessDefinitionInstanceVersionStatisticsResponse200 | GetProcessDefinitionInstanceVersionStatisticsResponse400 | GetProcessDefinitionInstanceVersionStatisticsResponse401 | GetProcessDefinitionInstanceVersionStatisticsResponse403 | GetProcessDefinitionInstanceVersionStatisticsResponse500]
    """
    kwargs = _get_kwargs(process_definition_id=process_definition_id, body=body)
    response = client.get_httpx_client().request(**kwargs)
    return _build_response(client=client, response=response)

def sync(process_definition_id: str, *, client: AuthenticatedClient | Client, body: GetProcessDefinitionInstanceVersionStatisticsData | Unset=UNSET, **kwargs) -> GetProcessDefinitionInstanceVersionStatisticsResponse200:
    """Get process instance statistics by version

 Get statistics about process instances, grouped by version for a given process definition.

Args:
    process_definition_id (str): Id of a process definition, from the model. Only ids of
        process definitions that are deployed are useful. Example: new-account-onboarding-
        workflow.
    body (GetProcessDefinitionInstanceVersionStatisticsData | Unset):

Raises:
    errors.GetProcessDefinitionInstanceVersionStatisticsBadRequest: If the response status code is 400. The provided data is not valid.
    errors.GetProcessDefinitionInstanceVersionStatisticsUnauthorized: If the response status code is 401. The request lacks valid authentication credentials.
    errors.GetProcessDefinitionInstanceVersionStatisticsForbidden: If the response status code is 403. Forbidden. The request is not allowed.
    errors.GetProcessDefinitionInstanceVersionStatisticsInternalServerError: If the response status code is 500. An internal error occurred while processing the request.
    errors.UnexpectedStatus: If the response status code is not documented.
    httpx.TimeoutException: If the request takes longer than Client.timeout.
Returns:
    GetProcessDefinitionInstanceVersionStatisticsResponse200"""
    response = sync_detailed(process_definition_id=process_definition_id, client=client, body=body)
    if response.status_code < 200 or response.status_code >= 300:
        if response.status_code == 400:
            raise errors.GetProcessDefinitionInstanceVersionStatisticsBadRequest(status_code=response.status_code, content=response.content, parsed=cast(GetProcessDefinitionInstanceVersionStatisticsResponse400, response.parsed))
        if response.status_code == 401:
            raise errors.GetProcessDefinitionInstanceVersionStatisticsUnauthorized(status_code=response.status_code, content=response.content, parsed=cast(GetProcessDefinitionInstanceVersionStatisticsResponse401, response.parsed))
        if response.status_code == 403:
            raise errors.GetProcessDefinitionInstanceVersionStatisticsForbidden(status_code=response.status_code, content=response.content, parsed=cast(GetProcessDefinitionInstanceVersionStatisticsResponse403, response.parsed))
        if response.status_code == 500:
            raise errors.GetProcessDefinitionInstanceVersionStatisticsInternalServerError(status_code=response.status_code, content=response.content, parsed=cast(GetProcessDefinitionInstanceVersionStatisticsResponse500, response.parsed))
        raise errors.UnexpectedStatus(response.status_code, response.content)
    return response.parsed

async def asyncio_detailed(process_definition_id: str, *, client: AuthenticatedClient | Client, body: GetProcessDefinitionInstanceVersionStatisticsData | Unset=UNSET) -> Response[GetProcessDefinitionInstanceVersionStatisticsResponse200 | GetProcessDefinitionInstanceVersionStatisticsResponse400 | GetProcessDefinitionInstanceVersionStatisticsResponse401 | GetProcessDefinitionInstanceVersionStatisticsResponse403 | GetProcessDefinitionInstanceVersionStatisticsResponse500]:
    """Get process instance statistics by version

     Get statistics about process instances, grouped by version for a given process definition.

    Args:
        process_definition_id (str): Id of a process definition, from the model. Only ids of
            process definitions that are deployed are useful. Example: new-account-onboarding-
            workflow.
        body (GetProcessDefinitionInstanceVersionStatisticsData | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[GetProcessDefinitionInstanceVersionStatisticsResponse200 | GetProcessDefinitionInstanceVersionStatisticsResponse400 | GetProcessDefinitionInstanceVersionStatisticsResponse401 | GetProcessDefinitionInstanceVersionStatisticsResponse403 | GetProcessDefinitionInstanceVersionStatisticsResponse500]
    """
    kwargs = _get_kwargs(process_definition_id=process_definition_id, body=body)
    response = await client.get_async_httpx_client().request(**kwargs)
    return _build_response(client=client, response=response)

async def asyncio(process_definition_id: str, *, client: AuthenticatedClient | Client, body: GetProcessDefinitionInstanceVersionStatisticsData | Unset=UNSET, **kwargs) -> GetProcessDefinitionInstanceVersionStatisticsResponse200:
    """Get process instance statistics by version

 Get statistics about process instances, grouped by version for a given process definition.

Args:
    process_definition_id (str): Id of a process definition, from the model. Only ids of
        process definitions that are deployed are useful. Example: new-account-onboarding-
        workflow.
    body (GetProcessDefinitionInstanceVersionStatisticsData | Unset):

Raises:
    errors.GetProcessDefinitionInstanceVersionStatisticsBadRequest: If the response status code is 400. The provided data is not valid.
    errors.GetProcessDefinitionInstanceVersionStatisticsUnauthorized: If the response status code is 401. The request lacks valid authentication credentials.
    errors.GetProcessDefinitionInstanceVersionStatisticsForbidden: If the response status code is 403. Forbidden. The request is not allowed.
    errors.GetProcessDefinitionInstanceVersionStatisticsInternalServerError: If the response status code is 500. An internal error occurred while processing the request.
    errors.UnexpectedStatus: If the response status code is not documented.
    httpx.TimeoutException: If the request takes longer than Client.timeout.
Returns:
    GetProcessDefinitionInstanceVersionStatisticsResponse200"""
    response = await asyncio_detailed(process_definition_id=process_definition_id, client=client, body=body)
    if response.status_code < 200 or response.status_code >= 300:
        if response.status_code == 400:
            raise errors.GetProcessDefinitionInstanceVersionStatisticsBadRequest(status_code=response.status_code, content=response.content, parsed=cast(GetProcessDefinitionInstanceVersionStatisticsResponse400, response.parsed))
        if response.status_code == 401:
            raise errors.GetProcessDefinitionInstanceVersionStatisticsUnauthorized(status_code=response.status_code, content=response.content, parsed=cast(GetProcessDefinitionInstanceVersionStatisticsResponse401, response.parsed))
        if response.status_code == 403:
            raise errors.GetProcessDefinitionInstanceVersionStatisticsForbidden(status_code=response.status_code, content=response.content, parsed=cast(GetProcessDefinitionInstanceVersionStatisticsResponse403, response.parsed))
        if response.status_code == 500:
            raise errors.GetProcessDefinitionInstanceVersionStatisticsInternalServerError(status_code=response.status_code, content=response.content, parsed=cast(GetProcessDefinitionInstanceVersionStatisticsResponse500, response.parsed))
        raise errors.UnexpectedStatus(response.status_code, response.content)
    return response.parsed