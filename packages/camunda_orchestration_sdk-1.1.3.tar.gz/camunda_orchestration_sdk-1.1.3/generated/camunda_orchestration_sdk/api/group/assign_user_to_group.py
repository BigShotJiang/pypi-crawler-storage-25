from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote
import httpx
from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.assign_user_to_group_response_400 import AssignUserToGroupResponse400
from ...models.assign_user_to_group_response_403 import AssignUserToGroupResponse403
from ...models.assign_user_to_group_response_404 import AssignUserToGroupResponse404
from ...models.assign_user_to_group_response_409 import AssignUserToGroupResponse409
from ...models.assign_user_to_group_response_500 import AssignUserToGroupResponse500
from ...models.assign_user_to_group_response_503 import AssignUserToGroupResponse503
from ...types import Response

def _get_kwargs(group_id: str, username: str) -> dict[str, Any]:
    _kwargs: dict[str, Any] = {'method': 'put', 'url': '/groups/{group_id}/users/{username}'.format(group_id=quote(str(group_id), safe=''), username=quote(str(username), safe=''))}
    return _kwargs

def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Any | AssignUserToGroupResponse400 | AssignUserToGroupResponse403 | AssignUserToGroupResponse404 | AssignUserToGroupResponse409 | AssignUserToGroupResponse500 | AssignUserToGroupResponse503 | None:
    if response.status_code == 204:
        response_204 = cast(Any, None)
        return response_204
    if response.status_code == 400:
        response_400 = AssignUserToGroupResponse400.from_dict(response.json())
        return response_400
    if response.status_code == 403:
        response_403 = AssignUserToGroupResponse403.from_dict(response.json())
        return response_403
    if response.status_code == 404:
        response_404 = AssignUserToGroupResponse404.from_dict(response.json())
        return response_404
    if response.status_code == 409:
        response_409 = AssignUserToGroupResponse409.from_dict(response.json())
        return response_409
    if response.status_code == 500:
        response_500 = AssignUserToGroupResponse500.from_dict(response.json())
        return response_500
    if response.status_code == 503:
        response_503 = AssignUserToGroupResponse503.from_dict(response.json())
        return response_503
    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None

def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[Any | AssignUserToGroupResponse400 | AssignUserToGroupResponse403 | AssignUserToGroupResponse404 | AssignUserToGroupResponse409 | AssignUserToGroupResponse500 | AssignUserToGroupResponse503]:
    return Response(status_code=HTTPStatus(response.status_code), content=response.content, headers=response.headers, parsed=_parse_response(client=client, response=response))

def sync_detailed(group_id: str, username: str, *, client: AuthenticatedClient | Client) -> Response[Any | AssignUserToGroupResponse400 | AssignUserToGroupResponse403 | AssignUserToGroupResponse404 | AssignUserToGroupResponse409 | AssignUserToGroupResponse500 | AssignUserToGroupResponse503]:
    """Assign a user to a group

     Assigns a user to a group, making the user a member of the group.
    Group members inherit the group authorizations, roles, and tenant assignments.

    Args:
        group_id (str):
        username (str): The unique name of a user. Example: swillis.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | AssignUserToGroupResponse400 | AssignUserToGroupResponse403 | AssignUserToGroupResponse404 | AssignUserToGroupResponse409 | AssignUserToGroupResponse500 | AssignUserToGroupResponse503]
    """
    kwargs = _get_kwargs(group_id=group_id, username=username)
    response = client.get_httpx_client().request(**kwargs)
    return _build_response(client=client, response=response)

def sync(group_id: str, username: str, *, client: AuthenticatedClient | Client, **kwargs) -> Any:
    """Assign a user to a group

 Assigns a user to a group, making the user a member of the group.
Group members inherit the group authorizations, roles, and tenant assignments.

Args:
    group_id (str):
    username (str): The unique name of a user. Example: swillis.

Raises:
    errors.AssignUserToGroupBadRequest: If the response status code is 400. The provided data is not valid.
    errors.AssignUserToGroupForbidden: If the response status code is 403. Forbidden. The request is not allowed.
    errors.AssignUserToGroupNotFound: If the response status code is 404. The group or user with the given ID or username was not found.
    errors.AssignUserToGroupConflict: If the response status code is 409. The user with the given ID is already assigned to the group.
    errors.AssignUserToGroupInternalServerError: If the response status code is 500. An internal error occurred while processing the request.
    errors.AssignUserToGroupServiceUnavailable: If the response status code is 503. The service is currently unavailable. This may happen only on some requests where the system creates backpressure to prevent the server's compute resources from being exhausted, avoiding more severe failures. In this case, the title of the error object contains `RESOURCE_EXHAUSTED`. Clients are recommended to eventually retry those requests after a backoff period. You can learn more about the backpressure mechanism here: https://docs.camunda.io/docs/components/zeebe/technical-concepts/internal-processing/#handling-backpressure .
    errors.UnexpectedStatus: If the response status code is not documented.
    httpx.TimeoutException: If the request takes longer than Client.timeout.
Returns:
    Any"""
    response = sync_detailed(group_id=group_id, username=username, client=client)
    if response.status_code < 200 or response.status_code >= 300:
        if response.status_code == 400:
            raise errors.AssignUserToGroupBadRequest(status_code=response.status_code, content=response.content, parsed=cast(AssignUserToGroupResponse400, response.parsed))
        if response.status_code == 403:
            raise errors.AssignUserToGroupForbidden(status_code=response.status_code, content=response.content, parsed=cast(AssignUserToGroupResponse403, response.parsed))
        if response.status_code == 404:
            raise errors.AssignUserToGroupNotFound(status_code=response.status_code, content=response.content, parsed=cast(AssignUserToGroupResponse404, response.parsed))
        if response.status_code == 409:
            raise errors.AssignUserToGroupConflict(status_code=response.status_code, content=response.content, parsed=cast(AssignUserToGroupResponse409, response.parsed))
        if response.status_code == 500:
            raise errors.AssignUserToGroupInternalServerError(status_code=response.status_code, content=response.content, parsed=cast(AssignUserToGroupResponse500, response.parsed))
        if response.status_code == 503:
            raise errors.AssignUserToGroupServiceUnavailable(status_code=response.status_code, content=response.content, parsed=cast(AssignUserToGroupResponse503, response.parsed))
        raise errors.UnexpectedStatus(response.status_code, response.content)
    return response.parsed

async def asyncio_detailed(group_id: str, username: str, *, client: AuthenticatedClient | Client) -> Response[Any | AssignUserToGroupResponse400 | AssignUserToGroupResponse403 | AssignUserToGroupResponse404 | AssignUserToGroupResponse409 | AssignUserToGroupResponse500 | AssignUserToGroupResponse503]:
    """Assign a user to a group

     Assigns a user to a group, making the user a member of the group.
    Group members inherit the group authorizations, roles, and tenant assignments.

    Args:
        group_id (str):
        username (str): The unique name of a user. Example: swillis.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | AssignUserToGroupResponse400 | AssignUserToGroupResponse403 | AssignUserToGroupResponse404 | AssignUserToGroupResponse409 | AssignUserToGroupResponse500 | AssignUserToGroupResponse503]
    """
    kwargs = _get_kwargs(group_id=group_id, username=username)
    response = await client.get_async_httpx_client().request(**kwargs)
    return _build_response(client=client, response=response)

async def asyncio(group_id: str, username: str, *, client: AuthenticatedClient | Client, **kwargs) -> Any:
    """Assign a user to a group

 Assigns a user to a group, making the user a member of the group.
Group members inherit the group authorizations, roles, and tenant assignments.

Args:
    group_id (str):
    username (str): The unique name of a user. Example: swillis.

Raises:
    errors.AssignUserToGroupBadRequest: If the response status code is 400. The provided data is not valid.
    errors.AssignUserToGroupForbidden: If the response status code is 403. Forbidden. The request is not allowed.
    errors.AssignUserToGroupNotFound: If the response status code is 404. The group or user with the given ID or username was not found.
    errors.AssignUserToGroupConflict: If the response status code is 409. The user with the given ID is already assigned to the group.
    errors.AssignUserToGroupInternalServerError: If the response status code is 500. An internal error occurred while processing the request.
    errors.AssignUserToGroupServiceUnavailable: If the response status code is 503. The service is currently unavailable. This may happen only on some requests where the system creates backpressure to prevent the server's compute resources from being exhausted, avoiding more severe failures. In this case, the title of the error object contains `RESOURCE_EXHAUSTED`. Clients are recommended to eventually retry those requests after a backoff period. You can learn more about the backpressure mechanism here: https://docs.camunda.io/docs/components/zeebe/technical-concepts/internal-processing/#handling-backpressure .
    errors.UnexpectedStatus: If the response status code is not documented.
    httpx.TimeoutException: If the request takes longer than Client.timeout.
Returns:
    Any"""
    response = await asyncio_detailed(group_id=group_id, username=username, client=client)
    if response.status_code < 200 or response.status_code >= 300:
        if response.status_code == 400:
            raise errors.AssignUserToGroupBadRequest(status_code=response.status_code, content=response.content, parsed=cast(AssignUserToGroupResponse400, response.parsed))
        if response.status_code == 403:
            raise errors.AssignUserToGroupForbidden(status_code=response.status_code, content=response.content, parsed=cast(AssignUserToGroupResponse403, response.parsed))
        if response.status_code == 404:
            raise errors.AssignUserToGroupNotFound(status_code=response.status_code, content=response.content, parsed=cast(AssignUserToGroupResponse404, response.parsed))
        if response.status_code == 409:
            raise errors.AssignUserToGroupConflict(status_code=response.status_code, content=response.content, parsed=cast(AssignUserToGroupResponse409, response.parsed))
        if response.status_code == 500:
            raise errors.AssignUserToGroupInternalServerError(status_code=response.status_code, content=response.content, parsed=cast(AssignUserToGroupResponse500, response.parsed))
        if response.status_code == 503:
            raise errors.AssignUserToGroupServiceUnavailable(status_code=response.status_code, content=response.content, parsed=cast(AssignUserToGroupResponse503, response.parsed))
        raise errors.UnexpectedStatus(response.status_code, response.content)
    return response.parsed