from dataflat.base_flattener import BaseFlattener
from dataflat.utils.case_translator import CaseTranslatorOptions


def test_flattener():
    base = BaseFlattener()
    assert base.case_translator is None
    assert base.entity_name == "data"
    assert base.primary_key is None


def test_flattener_with_case_translator(get_custom_flattener):
    from_case = CaseTranslatorOptions.CAMEL
    to_case = CaseTranslatorOptions.SNAKE
    base: BaseFlattener = get_custom_flattener(BaseFlattener, from_case, to_case)
    assert base.case_translator is not None
    assert base.case_translator.from_case == from_case
    assert base.case_translator.to_case == to_case


def test_flattener_with_entity_name():
    entity_name = "tests"
    base = BaseFlattener(entity_name=entity_name)
    assert base.entity_name == entity_name


def test_flattener_with_primary_key():
    primary_key = "tests"
    base = BaseFlattener(primary_key=primary_key)
    assert base.primary_key == primary_key


def test_flatten_abstract(get_custom_flattener):
    from_case = CaseTranslatorOptions.CAMEL
    to_case = CaseTranslatorOptions.SNAKE
    base: BaseFlattener = get_custom_flattener(BaseFlattener, from_case, to_case)
    assert base.flatten({}) is None
