"""Tests for the CLI orchestrator."""
from __future__ import annotations

import pytest
from substrate_setup.cli import EXIT_AUTH, EXIT_BAD_FLAGS, EXIT_OK, EXIT_PARTIAL, main

VALID_KEY = "sk-substrate-abcdefghijklmnopqrstuv"


@pytest.fixture
def stub_env(tmp_path, monkeypatch):
    monkeypatch.setenv("HOME", str(tmp_path))
    monkeypatch.setenv("USERPROFILE", str(tmp_path))
    monkeypatch.setenv("SUBSTRATE_API_KEY", VALID_KEY)
    monkeypatch.setenv("XDG_CONFIG_HOME", str(tmp_path / ".config"))
    return tmp_path


def test_version_subcommand(capsys):
    code = main(["version"])
    assert code == EXIT_OK
    out = capsys.readouterr().out
    assert "substrate-setup" in out


def test_help_subcommand_exits_zero(capsys):
    with pytest.raises(SystemExit) as exc:
        main(["--help"])
    assert exc.value.code == 0


def test_no_subcommand_runs_configure(stub_env, httpx_mock, capsys):
    httpx_mock.add_response(
        url="https://gw.example/v1/models",
        json={"object": "list", "data": [
            {"id": "openai/gpt-5.5", "object": "model", "owned_by": "openai",
             "display_name": "GPT-5.5", "description": "x"},
        ]},
    )
    code = main(["--base-url", "https://gw.example"])
    out = capsys.readouterr().out
    assert "Configuring" in out
    assert code == EXIT_OK


def test_configure_exits_partial_on_agent_error(stub_env, httpx_mock, capsys, monkeypatch):
    # Aider reads ~/.aider.model.metadata.json with json.loads — corrupt JSON
    # there will raise JSONDecodeError mid-configure, which the orchestrator
    # catches and converts to ResultStatus.ERROR → EXIT_PARTIAL.
    (stub_env / ".aider.conf.yml").write_text("dark-mode: true\n", encoding="utf-8")  # legit
    (stub_env / ".aider.model.metadata.json").write_text("not valid json {{{", encoding="utf-8")
    httpx_mock.add_response(
        url="https://gw.example/v1/models",
        json={"object": "list", "data": [
            {"id": "openai/gpt-5.5", "object": "model", "owned_by": "openai",
             "display_name": "GPT-5.5", "description": "x"},
        ]},
    )
    code = main(["configure", "--base-url", "https://gw.example"])
    out = capsys.readouterr().out
    assert "ERROR" in out
    assert code == EXIT_PARTIAL


def test_configure_exits_auth_on_401(stub_env, httpx_mock, capsys):
    httpx_mock.add_response(
        url="https://gw.example/v1/models",
        status_code=401,
        json={"error": "invalid_key"},
    )
    code = main(["configure", "--base-url", "https://gw.example"])
    err = capsys.readouterr().err
    assert "rejected by" in err
    assert code == EXIT_AUTH


def test_bad_flag_exits_bad_flags(stub_env, capsys):
    with pytest.raises(SystemExit) as exc:
        main(["--this-flag-does-not-exist"])
    assert exc.value.code in (EXIT_BAD_FLAGS, 2)  # argparse default is 2


def test_agents_only_filters(stub_env, httpx_mock, capsys, monkeypatch):
    httpx_mock.add_response(
        url="https://gw.example/v1/models",
        json={"object": "list", "data": [
            {"id": "openai/gpt-5.5", "object": "model", "owned_by": "openai",
             "display_name": "GPT-5.5", "description": "x"},
        ]},
    )
    code = main(["configure", "--base-url", "https://gw.example", "--agents-only", "aider"])
    out = capsys.readouterr().out
    assert "Aider" in out
    assert "Hermes" not in out
    assert "Continue" not in out
    assert "Cursor" not in out
    assert code == EXIT_OK


def test_dry_run_does_not_write(stub_env, httpx_mock, capsys):
    httpx_mock.add_response(
        url="https://gw.example/v1/models",
        json={"object": "list", "data": [
            {"id": "openai/gpt-5.5", "object": "model", "owned_by": "openai",
             "display_name": "GPT-5.5", "description": "x"},
        ]},
    )
    code = main(["configure", "--base-url", "https://gw.example", "--dry-run"])
    # No files should exist under HOME yet.
    assert not (stub_env / ".aider.conf.yml").exists()
    assert not (stub_env / ".hermes").exists()
    assert not (stub_env / ".continue").exists()
    assert code == EXIT_OK
