"""Tests for substrate_setup.backup."""
from __future__ import annotations

from substrate_setup.backup import backup_once


def test_backup_once_copies_file_to_sibling(tmp_path):
    target = tmp_path / "config.json"
    target.write_text('{"x": 1}\n', encoding="utf-8")

    backup_path = backup_once(target)

    assert backup_path is not None
    assert backup_path.exists()
    assert backup_path.read_text(encoding="utf-8") == '{"x": 1}\n'
    assert backup_path.name.startswith("config.json.substrate-bak-")
    # name suffix is a unix timestamp
    suffix = backup_path.name.rsplit(".substrate-bak-", 1)[1]
    assert suffix.isdigit()


def test_backup_once_returns_none_when_file_missing(tmp_path):
    target = tmp_path / "nonexistent.json"
    assert backup_once(target) is None


def test_backup_once_is_idempotent_within_run(tmp_path):
    """Calling backup_once twice in the same run reuses the first backup path."""
    target = tmp_path / "config.json"
    target.write_text("v1\n", encoding="utf-8")

    first = backup_once(target)
    # Mutate the file as if the script wrote it.
    target.write_text("v2\n", encoding="utf-8")
    second = backup_once(target)

    assert first == second
    assert first.read_text(encoding="utf-8") == "v1\n"  # original preserved
