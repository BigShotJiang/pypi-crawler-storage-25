"""pytest fixtures shared across substrate_setup tests."""
