"""Tests for substrate_setup.catalog."""
from __future__ import annotations

import json
from pathlib import Path

import httpx
import pytest
from substrate_setup.catalog import (
    AuthError,
    CatalogEntry,
    CatalogUnavailableError,
    fetch_catalog,
)

SAMPLE_OPENAI_SHAPE = {
    "object": "list",
    "data": [
        {
            "id": "anthropic/claude-sonnet-4-6",
            "object": "model",
            "owned_by": "anthropic",
            "display_name": "Claude Sonnet 4.6",
            "description": "Balanced quality and speed",
        }
    ],
}


def test_live_fetch_returns_parsed_entries(httpx_mock):
    httpx_mock.add_response(
        url="https://gw.example/v1/models",
        json=SAMPLE_OPENAI_SHAPE,
    )
    entries, source = fetch_catalog(
        base_url="https://gw.example",
        api_key="sk-substrate-abcdefghijklmnopqrstuv",
    )
    assert source == "live"
    assert entries == [
        CatalogEntry(
            id="anthropic/claude-sonnet-4-6",
            provider="anthropic",
            display_name="Claude Sonnet 4.6",
            description="Balanced quality and speed",
        )
    ]


def test_live_fetch_401_raises_auth_error(httpx_mock):
    httpx_mock.add_response(
        url="https://gw.example/v1/models",
        status_code=401,
        json={"error": "invalid_api_key"},
    )
    with pytest.raises(AuthError):
        fetch_catalog(
            base_url="https://gw.example",
            api_key="sk-substrate-abcdefghijklmnopqrstuv",
        )


def test_live_fetch_timeout_falls_back_to_snapshot(httpx_mock, capsys):
    httpx_mock.add_exception(httpx.ConnectTimeout("simulated timeout"))
    entries, source = fetch_catalog(
        base_url="https://gw.example",
        api_key="sk-substrate-abcdefghijklmnopqrstuv",
    )
    assert source == "fallback"
    assert len(entries) >= 5
    warning = capsys.readouterr().err
    assert "could not reach" in warning
    assert "bundled catalog snapshot" in warning


def test_missing_fallback_raises_unavailable(tmp_path, monkeypatch, httpx_mock):
    httpx_mock.add_exception(httpx.ConnectTimeout("simulated timeout"))
    # Point the loader at a directory that has no snapshot file.
    monkeypatch.setattr(
        "substrate_setup.catalog._FALLBACK_PATH",
        tmp_path / "missing.json",
    )
    with pytest.raises(CatalogUnavailableError):
        fetch_catalog(
            base_url="https://gw.example",
            api_key="sk-substrate-abcdefghijklmnopqrstuv",
        )


def test_bundled_fallback_parses_and_has_required_fields():
    fallback = Path(__file__).parents[1] / "substrate_setup" / "data" / "fallback_catalog.json"
    payload = json.loads(fallback.read_text())
    assert payload["object"] == "list"
    providers = {e["owned_by"] for e in payload["data"]}
    assert {"anthropic", "openai", "google", "deepseek", "moonshot"}.issubset(providers)
