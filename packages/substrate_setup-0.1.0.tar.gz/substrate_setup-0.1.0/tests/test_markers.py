"""Tests for substrate_setup.markers."""
from __future__ import annotations

from substrate_setup.markers import (
    MARKER_KEY,
    MARKER_VALUE,
    is_substrate_managed,
    mark,
    unmark,
)


def test_marker_constants_stable():
    # Stability check — these strings ship in user config files.
    assert MARKER_KEY == "_substrate_managed"
    assert MARKER_VALUE is True


def test_mark_adds_marker_to_dict():
    entry = {"model": "anthropic/claude-sonnet-4-6"}
    marked = mark(entry)
    assert marked == {
        "model": "anthropic/claude-sonnet-4-6",
        "_substrate_managed": True,
    }


def test_mark_is_pure():
    entry = {"model": "x"}
    mark(entry)
    assert "_substrate_managed" not in entry  # original not mutated


def test_is_substrate_managed_true():
    assert is_substrate_managed({"_substrate_managed": True}) is True


def test_is_substrate_managed_false_when_value_not_true():
    assert is_substrate_managed({"_substrate_managed": False}) is False
    assert is_substrate_managed({"_substrate_managed": "true"}) is False
    assert is_substrate_managed({}) is False


def test_unmark_strips_marker():
    assert unmark({"x": 1, "_substrate_managed": True}) == {"x": 1}
