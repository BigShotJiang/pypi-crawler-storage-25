"""Tests for the Continue agent handler (YAML preferred, legacy JSON fallback)."""
from __future__ import annotations

import json

import pytest
from ruamel.yaml import YAML
from substrate_setup.agents.base import ConfigureContext, ResultStatus
from substrate_setup.agents.continue_dev import ContinueAgent
from substrate_setup.catalog import CatalogEntry

VALID_KEY = "sk-substrate-abcdefghijklmnopqrstuv"
SAMPLE_CATALOG = [
    CatalogEntry("anthropic/claude-sonnet-4-6", "anthropic", "Claude Sonnet 4.6", "x"),
    CatalogEntry("openai/gpt-5.5", "openai", "GPT-5.5", "x"),
]


def _ctx(*, source: str = "live") -> ConfigureContext:
    return ConfigureContext(
        base_url="https://gw.example/v1",
        api_key=VALID_KEY,
        catalog=SAMPLE_CATALOG,
        catalog_source=source,
        dry_run=False,
    )


@pytest.fixture
def home_dir(tmp_path, monkeypatch):
    monkeypatch.setenv("HOME", str(tmp_path))
    monkeypatch.setenv("USERPROFILE", str(tmp_path))
    return tmp_path


def _yaml() -> YAML:
    y = YAML()
    y.preserve_quotes = True
    return y


def test_detect_returns_yaml_when_present(home_dir):
    (home_dir / ".continue").mkdir()
    (home_dir / ".continue" / "config.yaml").write_text("models: []\n", encoding="utf-8")
    assert ContinueAgent().detect() == home_dir / ".continue" / "config.yaml"


def test_detect_returns_json_when_only_json_present(home_dir):
    (home_dir / ".continue").mkdir()
    (home_dir / ".continue" / "config.json").write_text('{"models": []}', encoding="utf-8")
    assert ContinueAgent().detect() == home_dir / ".continue" / "config.json"


def test_detect_returns_none_when_neither_present(home_dir):
    assert ContinueAgent().detect() is None


def test_configure_creates_yaml_when_neither_exists(home_dir):
    result = ContinueAgent().configure(_ctx())
    assert result.status == ResultStatus.SUCCESS

    cfg = home_dir / ".continue" / "config.yaml"
    assert cfg.exists()
    payload = _yaml().load(cfg.read_text(encoding="utf-8"))
    ids = {m["model"] for m in payload["models"]}
    assert ids == {"anthropic/claude-sonnet-4-6", "openai/gpt-5.5"}
    assert all(m["_substrate_managed"] for m in payload["models"])
    assert all(m["apiBase"] == "https://gw.example/v1" for m in payload["models"])
    assert all(m["apiKey"] == VALID_KEY for m in payload["models"])
    assert all(m["provider"] == "openai" for m in payload["models"])


def test_configure_prefers_yaml_when_both_exist(home_dir):
    (home_dir / ".continue").mkdir()
    (home_dir / ".continue" / "config.yaml").write_text("models: []\n", encoding="utf-8")
    (home_dir / ".continue" / "config.json").write_text('{"models": [{"a": 1}]}', encoding="utf-8")

    ContinueAgent().configure(_ctx())
    yaml_data = _yaml().load((home_dir / ".continue" / "config.yaml").read_text(encoding="utf-8"))
    assert len(yaml_data["models"]) == 2
    # JSON untouched.
    json_data = json.loads((home_dir / ".continue" / "config.json").read_text(encoding="utf-8"))
    assert json_data == {"models": [{"a": 1}]}


def test_configure_mutates_legacy_json_when_only_json_present(home_dir, capsys):
    (home_dir / ".continue").mkdir()
    (home_dir / ".continue" / "config.json").write_text(
        '{"models": [{"name": "user-model"}]}',
        encoding="utf-8",
    )
    ContinueAgent().configure(_ctx())
    json_data = json.loads((home_dir / ".continue" / "config.json").read_text(encoding="utf-8"))
    ids = {m.get("model") for m in json_data["models"]}
    assert "anthropic/claude-sonnet-4-6" in ids
    # user entry preserved
    names = {m.get("name") for m in json_data["models"]}
    assert "user-model" in names
    assert "legacy config.json" in capsys.readouterr().out


def test_configure_preserves_user_models_without_marker(home_dir):
    (home_dir / ".continue").mkdir()
    (home_dir / ".continue" / "config.yaml").write_text(
        "schema: v1\nmodels:\n  - name: My Local Ollama\n    provider: ollama\n"
        "    model: qwen2.5-coder:32b\n",
        encoding="utf-8",
    )
    ContinueAgent().configure(_ctx())
    payload = _yaml().load((home_dir / ".continue" / "config.yaml").read_text(encoding="utf-8"))
    names = {m["name"] for m in payload["models"]}
    assert "My Local Ollama" in names
    assert payload["schema"] == "v1"


def test_configure_is_idempotent(home_dir):
    ContinueAgent().configure(_ctx())
    a = (home_dir / ".continue" / "config.yaml").read_text(encoding="utf-8")
    ContinueAgent().configure(_ctx())
    b = (home_dir / ".continue" / "config.yaml").read_text(encoding="utf-8")
    assert a == b


def test_configure_fallback_path_does_not_drop_existing_substrate_entries(home_dir):
    ContinueAgent().configure(_ctx())
    fallback_ctx = ConfigureContext(
        base_url="https://gw.example/v1",
        api_key=VALID_KEY,
        catalog=SAMPLE_CATALOG[:1],   # drop gpt-5.5
        catalog_source="fallback",
        dry_run=False,
    )
    ContinueAgent().configure(fallback_ctx)
    payload = _yaml().load((home_dir / ".continue" / "config.yaml").read_text(encoding="utf-8"))
    ids = {m["model"] for m in payload["models"]}
    assert "openai/gpt-5.5" in ids


def test_remove_strips_substrate_models_only(home_dir):
    (home_dir / ".continue").mkdir()
    (home_dir / ".continue" / "config.yaml").write_text(
        "models:\n  - name: My Local Ollama\n    provider: ollama\n    model: qwen2.5-coder:32b\n",
        encoding="utf-8",
    )
    ContinueAgent().configure(_ctx())
    ContinueAgent().remove(_ctx())
    payload = _yaml().load((home_dir / ".continue" / "config.yaml").read_text(encoding="utf-8"))
    names = {m["name"] for m in payload.get("models", [])}
    assert names == {"My Local Ollama"}


def test_verify_reports_stale(home_dir):
    ContinueAgent().configure(_ctx())
    larger = ConfigureContext(
        base_url="https://gw.example/v1",
        api_key=VALID_KEY,
        catalog=[
            *SAMPLE_CATALOG,
            CatalogEntry("moonshot/kimi-k2.6", "moonshot", "Kimi K2.6", ""),
        ],
        catalog_source="live",
        dry_run=False,
    )
    result = ContinueAgent().verify(larger)
    assert result.status == ResultStatus.ERROR
    assert "moonshot/kimi-k2.6" in result.message
