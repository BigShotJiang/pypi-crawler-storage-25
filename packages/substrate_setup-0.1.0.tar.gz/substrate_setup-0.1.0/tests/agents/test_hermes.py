"""Tests for the Hermes agent handler."""
from __future__ import annotations

import pytest
from ruamel.yaml import YAML
from substrate_setup.agents.base import ConfigureContext, ResultStatus
from substrate_setup.agents.hermes import HermesAgent
from substrate_setup.catalog import CatalogEntry

VALID_KEY = "sk-substrate-abcdefghijklmnopqrstuv"
SAMPLE_CATALOG = [
    CatalogEntry(
        id="anthropic/claude-sonnet-4-6",
        provider="anthropic",
        display_name="Claude Sonnet 4.6",
        description="Balanced quality and speed",
    ),
    CatalogEntry(
        id="openai/gpt-5.5",
        provider="openai",
        display_name="GPT-5.5",
        description="OpenAI flagship",
    ),
]


def _yaml():
    y = YAML()
    y.preserve_quotes = True
    return y


def _ctx(*, dry_run: bool = False) -> ConfigureContext:
    return ConfigureContext(
        base_url="https://gw.example/v1",
        api_key=VALID_KEY,
        catalog=SAMPLE_CATALOG,
        catalog_source="live",
        dry_run=dry_run,
    )


@pytest.fixture
def home_dir(tmp_path, monkeypatch):
    monkeypatch.setenv("HOME", str(tmp_path))
    monkeypatch.setenv("USERPROFILE", str(tmp_path))  # Path.home() reads this on Windows
    return tmp_path


def test_detect_returns_none_when_hermes_not_installed(home_dir):
    assert HermesAgent().detect() is None


def test_detect_returns_config_yaml_when_present(home_dir):
    hermes_dir = home_dir / ".hermes"
    hermes_dir.mkdir()
    (hermes_dir / "config.yaml").write_text("model: {}\n", encoding="utf-8")
    assert HermesAgent().detect() == hermes_dir / "config.yaml"


def test_configure_creates_config_when_missing(home_dir):
    result = HermesAgent().configure(_ctx())
    assert result.status == ResultStatus.SUCCESS

    cfg = home_dir / ".hermes" / "config.yaml"
    env = home_dir / ".hermes" / ".env"
    assert cfg.exists()
    assert env.exists()

    payload = _yaml().load(cfg.read_text(encoding="utf-8"))
    providers = payload["custom_providers"]
    [substrate] = [p for p in providers if p["name"] == "substrate"]
    assert substrate["base_url"] == "https://gw.example/v1"
    assert substrate["key_env"] == "SUBSTRATE_API_KEY"
    assert set(substrate["models"].keys()) == {
        "anthropic/claude-sonnet-4-6",
        "openai/gpt-5.5",
    }
    assert substrate["_substrate_managed"] is True

    env_text = env.read_text(encoding="utf-8")
    assert f"SUBSTRATE_API_KEY={VALID_KEY}" in env_text


def test_configure_preserves_user_provider_entries(home_dir):
    hermes_dir = home_dir / ".hermes"
    hermes_dir.mkdir()
    (hermes_dir / "config.yaml").write_text(
        """\
custom_providers:
  - name: my-other-gateway
    base_url: https://other.example/v1
    key_env: OTHER_KEY
    models:
      foo: {context_length: 8192}
""",
        encoding="utf-8",
    )

    HermesAgent().configure(_ctx())

    payload = _yaml().load((hermes_dir / "config.yaml").read_text(encoding="utf-8"))
    names = [p["name"] for p in payload["custom_providers"]]
    assert "my-other-gateway" in names
    assert "substrate" in names


def test_configure_is_idempotent(home_dir):
    HermesAgent().configure(_ctx())
    snapshot_after_first = (home_dir / ".hermes" / "config.yaml").read_text(encoding="utf-8")
    HermesAgent().configure(_ctx())
    snapshot_after_second = (home_dir / ".hermes" / "config.yaml").read_text(encoding="utf-8")
    assert snapshot_after_first == snapshot_after_second


def test_configure_dropped_model_removed_on_rerun(home_dir):
    HermesAgent().configure(_ctx())
    smaller = ConfigureContext(
        base_url="https://gw.example/v1",
        api_key=VALID_KEY,
        catalog=SAMPLE_CATALOG[:1],  # drop openai/gpt-5.5
        catalog_source="live",
        dry_run=False,
    )
    HermesAgent().configure(smaller)
    payload = _yaml().load((home_dir / ".hermes" / "config.yaml").read_text(encoding="utf-8"))
    [substrate] = [p for p in payload["custom_providers"] if p["name"] == "substrate"]
    assert set(substrate["models"].keys()) == {"anthropic/claude-sonnet-4-6"}


def test_configure_fallback_path_is_additive_only(home_dir):
    HermesAgent().configure(_ctx())
    fallback_ctx = ConfigureContext(
        base_url="https://gw.example/v1",
        api_key=VALID_KEY,
        catalog=SAMPLE_CATALOG[:1],  # drop one
        catalog_source="fallback",   # stale snapshot
        dry_run=False,
    )
    HermesAgent().configure(fallback_ctx)
    payload = _yaml().load((home_dir / ".hermes" / "config.yaml").read_text(encoding="utf-8"))
    [substrate] = [p for p in payload["custom_providers"] if p["name"] == "substrate"]
    # Stale snapshot must not delete entries.
    assert "openai/gpt-5.5" in substrate["models"]


def test_configure_preserves_non_substrate_env_key(home_dir):
    hermes_dir = home_dir / ".hermes"
    hermes_dir.mkdir()
    (hermes_dir / ".env").write_text("SUBSTRATE_API_KEY=other-value\n", encoding="utf-8")

    result = HermesAgent().configure(_ctx())
    env_text = (hermes_dir / ".env").read_text(encoding="utf-8")
    assert "SUBSTRATE_API_KEY=other-value" in env_text
    assert "please update manually" in result.message


def test_remove_strips_substrate_provider(home_dir):
    HermesAgent().configure(_ctx())
    HermesAgent().remove(_ctx())
    payload = _yaml().load((home_dir / ".hermes" / "config.yaml").read_text(encoding="utf-8"))
    names = [p["name"] for p in payload.get("custom_providers", [])]
    assert "substrate" not in names


def test_verify_reports_clean_after_configure(home_dir):
    HermesAgent().configure(_ctx())
    result = HermesAgent().verify(_ctx())
    assert result.status == ResultStatus.SUCCESS


def test_verify_reports_stale_when_catalog_diverges(home_dir):
    HermesAgent().configure(_ctx())
    larger = ConfigureContext(
        base_url="https://gw.example/v1",
        api_key=VALID_KEY,
        catalog=[
            *SAMPLE_CATALOG,
            CatalogEntry(
                id="moonshot/kimi-k2.6",
                provider="moonshot",
                display_name="Kimi K2.6",
                description="",
            ),
        ],
        catalog_source="live",
        dry_run=False,
    )
    result = HermesAgent().verify(larger)
    assert result.status == ResultStatus.ERROR
    assert "moonshot/kimi-k2.6" in result.message


def test_remove_strips_substrate_env_key_and_backs_it_up(home_dir):
    HermesAgent().configure(_ctx())
    env_path = home_dir / ".hermes" / ".env"
    assert f"SUBSTRATE_API_KEY={VALID_KEY}" in env_path.read_text(encoding="utf-8")

    result = HermesAgent().remove(_ctx())
    assert result.status == ResultStatus.SUCCESS
    env_after = env_path.read_text(encoding="utf-8") if env_path.exists() else ""
    assert "SUBSTRATE_API_KEY=sk-substrate-" not in env_after
    # Backup of .env should appear in the result.
    backup_names = [str(p.name) for p in result.backup_paths]
    assert any(name.startswith(".env.substrate-bak-") for name in backup_names)


def test_remove_preserves_non_substrate_env_value(home_dir):
    hermes_dir = home_dir / ".hermes"
    hermes_dir.mkdir()
    (hermes_dir / "config.yaml").write_text("custom_providers: []\n", encoding="utf-8")
    (hermes_dir / ".env").write_text("SUBSTRATE_API_KEY=other-value\n", encoding="utf-8")
    HermesAgent().remove(_ctx())
    env_text = (hermes_dir / ".env").read_text(encoding="utf-8")
    assert "SUBSTRATE_API_KEY=other-value" in env_text


def test_verify_distinguishes_missing_entry_from_unmanaged_entry(home_dir):
    # Case 1: entry present but no marker → distinct error message
    hermes_dir = home_dir / ".hermes"
    hermes_dir.mkdir()
    (hermes_dir / "config.yaml").write_text(
        """\
custom_providers:
  - name: substrate
    base_url: https://gw.example/v1
    models:
      anthropic/claude-sonnet-4-6: {context_length: 200000}
""",
        encoding="utf-8",
    )
    result = HermesAgent().verify(_ctx())
    assert result.status == ResultStatus.ERROR
    assert "exists but is not managed" in result.message
