"""Tests for the Cursor handler (print-only — Cursor cannot be configured by writing files)."""
from __future__ import annotations

from substrate_setup.agents.base import ConfigureContext, ResultStatus
from substrate_setup.agents.cursor import CursorAgent
from substrate_setup.catalog import CatalogEntry

VALID_KEY = "sk-substrate-abcdefghijklmnopqrstuv"
SAMPLE_CATALOG = [
    CatalogEntry("anthropic/claude-sonnet-4-6", "anthropic", "Claude Sonnet 4.6", "x"),
    CatalogEntry("openai/gpt-5.5", "openai", "GPT-5.5", "x"),
]


def _ctx() -> ConfigureContext:
    return ConfigureContext(
        base_url="https://gw.example/v1",
        api_key=VALID_KEY,
        catalog=SAMPLE_CATALOG,
        catalog_source="live",
        dry_run=False,
    )


def test_detect_returns_none_when_no_cursor_dir(tmp_path, monkeypatch):
    monkeypatch.setenv("HOME", str(tmp_path))
    monkeypatch.setenv("USERPROFILE", str(tmp_path))
    monkeypatch.setenv("XDG_CONFIG_HOME", str(tmp_path / ".config"))
    monkeypatch.setenv("APPDATA", str(tmp_path / "AppData/Roaming"))
    assert CursorAgent().detect() is None


def test_detect_returns_user_data_dir_when_present(tmp_path, monkeypatch):
    monkeypatch.setenv("HOME", str(tmp_path))
    monkeypatch.setenv("USERPROFILE", str(tmp_path))
    monkeypatch.setenv("XDG_CONFIG_HOME", str(tmp_path / ".config"))
    monkeypatch.setenv("APPDATA", str(tmp_path / "AppData/Roaming"))
    cursor_dir = tmp_path / ".config" / "Cursor"
    cursor_dir.mkdir(parents=True)
    detected = CursorAgent().detect()
    assert detected == cursor_dir


def test_configure_prints_walkthrough_and_does_not_write(tmp_path, monkeypatch, capsys):
    monkeypatch.setenv("HOME", str(tmp_path))
    monkeypatch.setenv("USERPROFILE", str(tmp_path))
    monkeypatch.setenv("XDG_CONFIG_HOME", str(tmp_path / ".config"))
    monkeypatch.setenv("APPDATA", str(tmp_path / "AppData/Roaming"))
    (tmp_path / ".config" / "Cursor").mkdir(parents=True)

    result = CursorAgent().configure(_ctx())
    assert result.status == ResultStatus.PRINT_ONLY

    out = capsys.readouterr().out
    assert "Cursor detected" in out
    assert "https://gw.example/v1" in out
    assert VALID_KEY in out
    assert "anthropic/claude-sonnet-4-6" in out
    assert "openai/gpt-5.5" in out
    assert "WARNING" in out
    assert "Override OpenAI Base URL" in out
    # Verify no file was written under the Cursor dir.
    files = list((tmp_path / ".config" / "Cursor").rglob("*"))
    assert files == []


def test_verify_prints_cannot_verify_line(tmp_path, monkeypatch, capsys):
    monkeypatch.setenv("HOME", str(tmp_path))
    monkeypatch.setenv("USERPROFILE", str(tmp_path))
    monkeypatch.setenv("XDG_CONFIG_HOME", str(tmp_path / ".config"))
    monkeypatch.setenv("APPDATA", str(tmp_path / "AppData/Roaming"))
    (tmp_path / ".config" / "Cursor").mkdir(parents=True)
    result = CursorAgent().verify(_ctx())
    assert result.status == ResultStatus.PRINT_ONLY
    assert "cannot verify automatically" in capsys.readouterr().out


def test_remove_prints_inverse_walkthrough(tmp_path, monkeypatch, capsys):
    monkeypatch.setenv("HOME", str(tmp_path))
    monkeypatch.setenv("USERPROFILE", str(tmp_path))
    monkeypatch.setenv("XDG_CONFIG_HOME", str(tmp_path / ".config"))
    monkeypatch.setenv("APPDATA", str(tmp_path / "AppData/Roaming"))
    (tmp_path / ".config" / "Cursor").mkdir(parents=True)
    result = CursorAgent().remove(_ctx())
    assert result.status == ResultStatus.PRINT_ONLY
    out = capsys.readouterr().out
    assert "Toggle \"Override OpenAI Base URL\" OFF" in out
