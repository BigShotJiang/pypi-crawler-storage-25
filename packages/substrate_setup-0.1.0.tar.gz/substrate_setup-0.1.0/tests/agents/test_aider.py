"""Tests for the Aider agent handler."""
from __future__ import annotations

import json

import pytest
from ruamel.yaml import YAML
from substrate_setup.agents.aider import AiderAgent
from substrate_setup.agents.base import ConfigureContext, ResultStatus
from substrate_setup.catalog import CatalogEntry

VALID_KEY = "sk-substrate-abcdefghijklmnopqrstuv"
SAMPLE_CATALOG = [
    CatalogEntry("anthropic/claude-sonnet-4-6", "anthropic", "Claude Sonnet 4.6", "x"),
    CatalogEntry("openai/gpt-5.5", "openai", "GPT-5.5", "x"),
]


def _ctx(*, source: str = "live") -> ConfigureContext:
    return ConfigureContext(
        base_url="https://gw.example/v1",
        api_key=VALID_KEY,
        catalog=SAMPLE_CATALOG,
        catalog_source=source,
        dry_run=False,
    )


@pytest.fixture
def home_dir(tmp_path, monkeypatch):
    monkeypatch.setenv("HOME", str(tmp_path))
    monkeypatch.setenv("USERPROFILE", str(tmp_path))
    return tmp_path


def _yaml() -> YAML:
    y = YAML()
    y.preserve_quotes = True
    return y


def test_detect_returns_aider_conf_path_when_present(home_dir):
    (home_dir / ".aider.conf.yml").write_text("dark-mode: true\n", encoding="utf-8")
    assert AiderAgent().detect() == home_dir / ".aider.conf.yml"


def test_detect_returns_none_when_aider_not_installed(home_dir):
    assert AiderAgent().detect() is None


def test_configure_writes_three_files(home_dir):
    result = AiderAgent().configure(_ctx())
    assert result.status == ResultStatus.SUCCESS

    conf = home_dir / ".aider.conf.yml"
    meta = home_dir / ".aider.model.metadata.json"
    env = home_dir / ".env"
    assert conf.exists() and meta.exists() and env.exists()

    conf_data = _yaml().load(conf.read_text(encoding="utf-8"))
    assert conf_data["openai-api-base"] == "https://gw.example/v1"
    assert conf_data["model-metadata-file"] == str(meta)

    meta_data = json.loads(meta.read_text(encoding="utf-8"))
    assert "openai/anthropic/claude-sonnet-4-6" in meta_data
    assert "openai/openai/gpt-5.5" in meta_data
    assert meta_data["openai/anthropic/claude-sonnet-4-6"]["litellm_provider"] == "openai"
    assert meta_data["openai/anthropic/claude-sonnet-4-6"]["_substrate_managed"] is True

    env_text = env.read_text(encoding="utf-8")
    assert f"OPENAI_API_KEY={VALID_KEY}" in env_text


def test_configure_preserves_user_aider_conf_keys(home_dir):
    (home_dir / ".aider.conf.yml").write_text(
        "dark-mode: true\nauto-commits: false\nweak-model: openai/gpt-4o-mini\n",
        encoding="utf-8",
    )
    AiderAgent().configure(_ctx())
    conf_data = _yaml().load((home_dir / ".aider.conf.yml").read_text(encoding="utf-8"))
    assert conf_data["dark-mode"] is True
    assert conf_data["auto-commits"] is False
    assert conf_data["weak-model"] == "openai/gpt-4o-mini"
    assert conf_data["openai-api-base"] == "https://gw.example/v1"


def test_configure_preserves_user_metadata_entries(home_dir):
    (home_dir / ".aider.model.metadata.json").write_text(
        json.dumps({
            "ollama/qwen2.5-coder:32b": {
                "max_input_tokens": 32768,
                "max_output_tokens": 8192,
                "input_cost_per_token": 0,
                "output_cost_per_token": 0,
                "litellm_provider": "ollama",
                "mode": "chat",
            }
        }),
        encoding="utf-8",
    )
    AiderAgent().configure(_ctx())
    meta_data = json.loads((home_dir / ".aider.model.metadata.json").read_text(encoding="utf-8"))
    assert "ollama/qwen2.5-coder:32b" in meta_data
    assert "openai/anthropic/claude-sonnet-4-6" in meta_data


def test_configure_skips_credential_write_when_existing_non_substrate_key(home_dir):
    (home_dir / ".env").write_text("OPENAI_API_KEY=sk-openai-xxx\n", encoding="utf-8")
    result = AiderAgent().configure(_ctx())
    env_text = (home_dir / ".env").read_text(encoding="utf-8")
    assert "OPENAI_API_KEY=sk-openai-xxx" in env_text
    assert "please update manually" in result.message


def test_configure_is_idempotent(home_dir):
    AiderAgent().configure(_ctx())
    a = (home_dir / ".aider.conf.yml").read_text(encoding="utf-8")
    b = (home_dir / ".aider.model.metadata.json").read_text(encoding="utf-8")
    c = (home_dir / ".env").read_text(encoding="utf-8")
    AiderAgent().configure(_ctx())
    assert (home_dir / ".aider.conf.yml").read_text(encoding="utf-8") == a
    assert (home_dir / ".aider.model.metadata.json").read_text(encoding="utf-8") == b
    assert (home_dir / ".env").read_text(encoding="utf-8") == c


def test_configure_fallback_path_does_not_drop_existing_substrate_models(home_dir):
    AiderAgent().configure(_ctx())
    fallback_ctx = ConfigureContext(
        base_url="https://gw.example/v1",
        api_key=VALID_KEY,
        catalog=SAMPLE_CATALOG[:1],  # drop gpt-5.5
        catalog_source="fallback",
        dry_run=False,
    )
    AiderAgent().configure(fallback_ctx)
    meta_data = json.loads((home_dir / ".aider.model.metadata.json").read_text(encoding="utf-8"))
    # Stale snapshot must not delete the dropped entry.
    assert "openai/openai/gpt-5.5" in meta_data


def test_remove_strips_substrate_metadata_entries(home_dir):
    (home_dir / ".aider.model.metadata.json").write_text(
        json.dumps({
            "ollama/qwen2.5-coder:32b": {
                "max_input_tokens": 32768,
                "litellm_provider": "ollama",
                "mode": "chat",
            }
        }),
        encoding="utf-8",
    )
    AiderAgent().configure(_ctx())
    AiderAgent().remove(_ctx())
    meta_data = json.loads((home_dir / ".aider.model.metadata.json").read_text(encoding="utf-8"))
    assert "ollama/qwen2.5-coder:32b" in meta_data  # user entry preserved
    assert "openai/anthropic/claude-sonnet-4-6" not in meta_data


def test_verify_reports_stale_when_catalog_diverges(home_dir):
    AiderAgent().configure(_ctx())
    larger = ConfigureContext(
        base_url="https://gw.example/v1",
        api_key=VALID_KEY,
        catalog=[
            *SAMPLE_CATALOG,
            CatalogEntry("moonshot/kimi-k2.6", "moonshot", "Kimi K2.6", ""),
        ],
        catalog_source="live",
        dry_run=False,
    )
    result = AiderAgent().verify(larger)
    assert result.status == ResultStatus.ERROR
    assert "moonshot/kimi-k2.6" in result.message
