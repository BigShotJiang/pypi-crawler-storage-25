"""Tests for substrate_setup.credentials."""
from __future__ import annotations

import pytest
from substrate_setup.credentials import (
    CredentialResolutionError,
    InvalidKeyFormatError,
    resolve_api_key,
)

VALID_KEY = "sk-substrate-abcdefghijklmnopqrstuv"


def test_env_var_takes_precedence_over_config_and_prompt(monkeypatch, tmp_path):
    monkeypatch.setenv("SUBSTRATE_API_KEY", VALID_KEY)
    config = tmp_path / "credentials.toml"
    config.write_text('api_key = "sk-substrate-zzzzzzzzzzzzzzzzzzzzzzzz"\n', encoding="utf-8")
    resolved = resolve_api_key(
        config_path=config,
        prompt_fn=lambda _: pytest.fail("prompt should not be called"),
    )
    assert resolved == VALID_KEY


def test_config_file_used_when_env_missing(monkeypatch, tmp_path):
    monkeypatch.delenv("SUBSTRATE_API_KEY", raising=False)
    config = tmp_path / "credentials.toml"
    config.write_text(f'api_key = "{VALID_KEY}"\n', encoding="utf-8")
    resolved = resolve_api_key(
        config_path=config,
        prompt_fn=lambda _: pytest.fail("prompt should not be called"),
    )
    assert resolved == VALID_KEY


def test_prompt_used_when_env_and_config_missing(monkeypatch, tmp_path):
    monkeypatch.delenv("SUBSTRATE_API_KEY", raising=False)
    config = tmp_path / "missing.toml"
    resolved = resolve_api_key(
        config_path=config,
        prompt_fn=lambda _: VALID_KEY,
    )
    assert resolved == VALID_KEY


def test_malformed_key_rejected(monkeypatch, tmp_path):
    monkeypatch.setenv("SUBSTRATE_API_KEY", "not-a-substrate-key")
    config = tmp_path / "missing.toml"
    with pytest.raises(InvalidKeyFormatError):
        resolve_api_key(config_path=config, prompt_fn=lambda _: "x")


def test_no_key_anywhere_raises(monkeypatch, tmp_path):
    monkeypatch.delenv("SUBSTRATE_API_KEY", raising=False)
    config = tmp_path / "missing.toml"
    with pytest.raises(CredentialResolutionError):
        resolve_api_key(config_path=config, prompt_fn=lambda _: "")


def test_key_with_invalid_chars_rejected(monkeypatch, tmp_path):
    monkeypatch.setenv("SUBSTRATE_API_KEY", "sk-substrate-has spaces here xxxxxx")
    config = tmp_path / "missing.toml"
    with pytest.raises(InvalidKeyFormatError):
        resolve_api_key(config_path=config, prompt_fn=lambda _: "x")


def test_config_api_key_non_string_raises(monkeypatch, tmp_path):
    monkeypatch.delenv("SUBSTRATE_API_KEY", raising=False)
    config = tmp_path / "credentials.toml"
    config.write_text("api_key = 12345\n", encoding="utf-8")
    with pytest.raises(CredentialResolutionError, match="must be a string"):
        resolve_api_key(config_path=config, prompt_fn=lambda _: "")


def test_malformed_toml_raises(monkeypatch, tmp_path):
    monkeypatch.delenv("SUBSTRATE_API_KEY", raising=False)
    config = tmp_path / "credentials.toml"
    config.write_text(":::not valid toml:::\n", encoding="utf-8")
    with pytest.raises(CredentialResolutionError, match="not valid TOML"):
        resolve_api_key(config_path=config, prompt_fn=lambda _: "")
