# substrate-setup

One-shot configurator that points local coding agents at a Substrate gateway.

```bash
pip install substrate-setup
export SUBSTRATE_API_KEY="sk-substrate-..."  # or be prompted
python -m substrate_setup
```

Run `python -m substrate_setup --help` for subcommands (`configure`, `verify`, `remove`).
