"""substrate-setup — one-shot configurator for coding agents.

See https://github.com/FrankXiaA/substrate-solutions for the gateway it
configures against.
"""
__version__ = "0.1.0"
