"""Module entry point: ``python -m substrate_setup``."""
from substrate_setup.cli import main

if __name__ == "__main__":
    raise SystemExit(main())
