"""Abstract base class + result type for agent handlers.

All agent handlers (hermes, cursor, aider, continue_dev) implement this
interface. The orchestrator in cli.py treats them polymorphically.
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from enum import StrEnum
from pathlib import Path

from substrate_setup.catalog import CatalogEntry


class ResultStatus(StrEnum):
    SUCCESS = "success"
    ERROR = "error"
    SKIPPED = "skipped"          # agent not installed
    PRINT_ONLY = "print_only"    # for Cursor — handled, but no file write


@dataclass(frozen=True)
class AgentResult:
    status: ResultStatus
    message: str
    backup_paths: tuple[Path, ...] = field(default_factory=tuple)


@dataclass(frozen=True)
class ConfigureContext:
    base_url: str
    api_key: str
    catalog: list[CatalogEntry]
    catalog_source: str            # "live" or "fallback"
    dry_run: bool


class Agent(ABC):
    """Each coding-agent integration implements this."""

    name: str                       # short id, e.g. "cursor"
    pretty_name: str                # display name, e.g. "Cursor"

    @abstractmethod
    def detect(self) -> Path | None:
        """Return the primary path the agent would touch, or None if not installed."""

    @abstractmethod
    def configure(self, ctx: ConfigureContext) -> AgentResult: ...

    @abstractmethod
    def verify(self, ctx: ConfigureContext) -> AgentResult: ...

    @abstractmethod
    def remove(self, ctx: ConfigureContext) -> AgentResult: ...
