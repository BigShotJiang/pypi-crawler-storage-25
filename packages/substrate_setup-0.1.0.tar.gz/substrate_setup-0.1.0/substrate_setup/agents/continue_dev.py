"""Continue (VS Code / JetBrains extension) integration.

Files (current default is YAML, JSON is deprecated):
  ~/.continue/config.yaml — preferred
  ~/.continue/config.json — legacy fallback; ignored by Continue if YAML present
"""
from __future__ import annotations

import io
import json
from pathlib import Path
from typing import Any

from ruamel.yaml import YAML

from substrate_setup.agents.base import (
    Agent,
    AgentResult,
    ConfigureContext,
    ResultStatus,
)
from substrate_setup.backup import backup_once
from substrate_setup.catalog import CatalogEntry
from substrate_setup.markers import MARKER_KEY, MARKER_VALUE, is_substrate_managed


def _dir() -> Path:
    return Path.home() / ".continue"


def _yaml_path() -> Path:
    return _dir() / "config.yaml"


def _json_path() -> Path:
    return _dir() / "config.json"


def _yaml() -> YAML:
    y = YAML()
    y.preserve_quotes = True
    y.indent(mapping=2, sequence=4, offset=2)
    return y


def _model_entry(ctx: ConfigureContext, catalog_id: str, display: str) -> dict[str, Any]:
    return {
        "name": display,
        "provider": "openai",   # documented form for custom OpenAI-compat gateways
        "model": catalog_id,
        "apiBase": ctx.base_url,
        "apiKey": ctx.api_key,
        "roles": ["chat", "edit", "apply"],
        MARKER_KEY: MARKER_VALUE,
    }


def _choose_path() -> tuple[Path, str]:
    """Return (path, format-tag) where format-tag is 'yaml' or 'json'."""
    if _yaml_path().exists():
        return _yaml_path(), "yaml"
    if _json_path().exists():
        return _json_path(), "json"
    return _yaml_path(), "yaml"


def _load(path: Path, fmt: str) -> dict[str, Any]:
    if not path.exists():
        return {}
    text = path.read_text(encoding="utf-8")
    if fmt == "yaml":
        result: dict[str, Any] = _yaml().load(text) or {}
        return result
    result = json.loads(text)
    return result


def _dump(path: Path, fmt: str, data: dict[str, Any]) -> None:
    if fmt == "yaml":
        buf = io.StringIO()
        _yaml().dump(data, buf)
        path.write_text(buf.getvalue(), encoding="utf-8")
    else:
        path.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")


def _merge_models(
    existing: list[dict[str, Any]],
    catalog: list[CatalogEntry],
    ctx: ConfigureContext,
) -> list[dict[str, Any]]:
    """Merge with marker-respecting semantics.

    - Preserve user-authored entries (no marker).
    - Replace substrate-managed entries to match the current catalog (live path).
    - On fallback path, keep existing substrate-managed entries even if not in catalog.
    """
    user_entries = [e for e in existing if not is_substrate_managed(e)]
    existing_substrate_ids = {
        e.get("model") for e in existing if is_substrate_managed(e)
    }
    catalog_ids = {entry.id for entry in catalog}

    fresh_entries = [
        _model_entry(ctx, entry.id, entry.display_name) for entry in catalog
    ]

    if ctx.catalog_source == "fallback":
        kept_ids = existing_substrate_ids - catalog_ids
        for old in existing:
            if is_substrate_managed(old) and old.get("model") in kept_ids:
                fresh_entries.append(old)

    return user_entries + fresh_entries


class ContinueAgent(Agent):
    name = "continue"
    pretty_name = "Continue"

    def detect(self) -> Path | None:
        if _yaml_path().exists():
            return _yaml_path()
        if _json_path().exists():
            return _json_path()
        return None

    def configure(self, ctx: ConfigureContext) -> AgentResult:
        _dir().mkdir(parents=True, exist_ok=True)
        path, fmt = _choose_path()
        backups: list[Path] = []

        if path.exists():
            backup = backup_once(path)
            if backup is not None:
                backups.append(backup)

        payload = _load(path, fmt)
        existing_models = payload.get("models") or []
        merged = _merge_models(existing_models, ctx.catalog, ctx)
        payload["models"] = merged

        notes: list[str] = []
        if fmt == "json":
            notes.append(
                "Continue: editing legacy config.json (consider migrating to config.yaml)."
            )
            print(notes[-1])

        if not ctx.dry_run:
            _dump(path, fmt, payload)

        msg = f"{len(ctx.catalog)} models written, API base + key set in {path}."
        return AgentResult(ResultStatus.SUCCESS, msg, tuple(backups))

    def verify(self, ctx: ConfigureContext) -> AgentResult:
        path = self.detect()
        if path is None:
            return AgentResult(ResultStatus.ERROR, "Continue config not present")
        fmt = "yaml" if path.suffix == ".yaml" else "json"
        payload = _load(path, fmt)
        substrate_ids = {
            m.get("model") for m in (payload.get("models") or [])
            if is_substrate_managed(m)
        }
        catalog_ids = {e.id for e in ctx.catalog}
        missing = catalog_ids - substrate_ids
        stale = substrate_ids - catalog_ids
        if missing or stale:
            parts = []
            if missing:
                parts.append(f"missing: {sorted(missing)}")
            if stale:
                parts.append(f"stale: {sorted(stale)}")
            return AgentResult(ResultStatus.ERROR, "; ".join(parts))
        return AgentResult(ResultStatus.SUCCESS, "in sync")

    def remove(self, ctx: ConfigureContext) -> AgentResult:
        path = self.detect()
        if path is None:
            return AgentResult(ResultStatus.SKIPPED, "Continue not installed")
        fmt = "yaml" if path.suffix == ".yaml" else "json"
        backup = backup_once(path)
        payload = _load(path, fmt)
        payload["models"] = [
            m for m in (payload.get("models") or []) if not is_substrate_managed(m)
        ]
        if not ctx.dry_run:
            _dump(path, fmt, payload)
        return AgentResult(
            ResultStatus.SUCCESS,
            "Removed substrate model entries from Continue",
            (backup,) if backup else (),
        )
