"""Hermes Agent (NousResearch/hermes-agent) integration.

Config:
  ~/.hermes/config.yaml   — providers + model defaults
  ~/.hermes/.env          — secrets (SUBSTRATE_API_KEY)

Schema verified against upstream docs during plan-writing.
"""
from __future__ import annotations

import io
from pathlib import Path
from typing import Any

from ruamel.yaml import YAML

from substrate_setup.agents.base import (
    Agent,
    AgentResult,
    ConfigureContext,
    ResultStatus,
)
from substrate_setup.backup import backup_once
from substrate_setup.markers import MARKER_KEY, MARKER_VALUE, is_substrate_managed

PROVIDER_NAME = "substrate"
ENV_VAR = "SUBSTRATE_API_KEY"


def _config_dir() -> Path:
    return Path.home() / ".hermes"


def _config_yaml() -> Path:
    return _config_dir() / "config.yaml"


def _env_file() -> Path:
    return _config_dir() / ".env"


def _yaml() -> YAML:
    y = YAML()
    y.preserve_quotes = True
    y.indent(mapping=2, sequence=4, offset=2)
    return y


def _load_yaml(path: Path) -> dict[str, Any]:
    if not path.exists():
        return {}
    text = path.read_text(encoding="utf-8")
    result: dict[str, Any] = _yaml().load(text) or {}
    return result


def _dump_yaml(path: Path, data: dict[str, Any]) -> None:
    buf = io.StringIO()
    _yaml().dump(data, buf)
    path.write_text(buf.getvalue(), encoding="utf-8")


def _build_substrate_provider(ctx: ConfigureContext) -> dict[str, Any]:
    models = {
        entry.id: {"context_length": 200000}
        for entry in ctx.catalog
    }
    return {
        "name": PROVIDER_NAME,
        "base_url": ctx.base_url,
        "key_env": ENV_VAR,
        "api_mode": "chat_completions",
        "models": models,
        MARKER_KEY: MARKER_VALUE,
    }


def _merge_provider_models(
    existing: dict[str, Any],
    fresh: dict[str, Any],
    *,
    additive_only: bool,
) -> dict[str, Any]:
    """Merge the substrate provider entry, respecting additive-only on fallback."""
    if additive_only:
        merged_models = {**existing.get("models", {}), **fresh["models"]}
        return {**fresh, "models": merged_models}
    return fresh


def _read_env_lines(path: Path) -> list[str]:
    if not path.exists():
        return []
    return path.read_text(encoding="utf-8").splitlines()


def _write_env_lines(path: Path, lines: list[str]) -> None:
    path.write_text("\n".join(lines) + ("\n" if lines else ""), encoding="utf-8")


class HermesAgent(Agent):
    name = "hermes"
    pretty_name = "Hermes"

    def detect(self) -> Path | None:
        cfg = _config_yaml()
        return cfg if cfg.exists() else None

    def configure(self, ctx: ConfigureContext) -> AgentResult:
        _config_dir().mkdir(parents=True, exist_ok=True)
        backups: list[Path] = []
        notes: list[str] = []

        # ── config.yaml ──────────────────────────────────────────────
        cfg_path = _config_yaml()
        if cfg_path.exists():
            backup = backup_once(cfg_path)
            if backup is not None:
                backups.append(backup)

        payload = _load_yaml(cfg_path)
        providers: list[dict[str, Any]] = payload.get("custom_providers") or []
        new_provider = _build_substrate_provider(ctx)

        existing_substrate = next(
            (p for p in providers if p.get("name") == PROVIDER_NAME), None
        )
        if existing_substrate is not None:
            merged = _merge_provider_models(
                existing_substrate, new_provider, additive_only=(ctx.catalog_source == "fallback")
            )
            providers = [
                merged if p.get("name") == PROVIDER_NAME else p for p in providers
            ]
        else:
            providers.append(new_provider)

        payload["custom_providers"] = providers

        if not ctx.dry_run:
            _dump_yaml(cfg_path, payload)

        # ── .env ─────────────────────────────────────────────────────
        env_path = _env_file()
        lines = _read_env_lines(env_path)
        existing_value = None
        for line in lines:
            if line.startswith(f"{ENV_VAR}="):
                existing_value = line.split("=", 1)[1]
                break

        should_write_env = False
        new_lines = list(lines)
        if existing_value is None:
            new_lines.append(f"{ENV_VAR}={ctx.api_key}")
            should_write_env = True
        elif existing_value.startswith("sk-substrate-"):
            if existing_value != ctx.api_key:
                new_lines = [
                    f"{ENV_VAR}={ctx.api_key}" if line.startswith(f"{ENV_VAR}=") else line
                    for line in lines
                ]
                should_write_env = True
        else:
            notes.append(
                f"Hermes already has {ENV_VAR} set to a non-Substrate-shaped value; "
                "please update manually."
            )

        if should_write_env:
            if env_path.exists():
                env_backup = backup_once(env_path)
                if env_backup is not None:
                    backups.append(env_backup)
            if not ctx.dry_run:
                _write_env_lines(env_path, new_lines)

        msg = f"{len(ctx.catalog)} models written to ~/.hermes/config.yaml"
        if notes:
            msg += "\n" + "\n".join(notes)
        return AgentResult(ResultStatus.SUCCESS, msg, tuple(backups))

    def verify(self, ctx: ConfigureContext) -> AgentResult:
        cfg_path = _config_yaml()
        if not cfg_path.exists():
            return AgentResult(
                ResultStatus.ERROR, "Hermes config.yaml does not exist"
            )
        payload = _load_yaml(cfg_path)
        providers = payload.get("custom_providers") or []
        substrate = next(
            (p for p in providers if p.get("name") == PROVIDER_NAME), None
        )
        if substrate is None:
            return AgentResult(
                ResultStatus.ERROR, "No substrate provider entry found"
            )
        if not is_substrate_managed(substrate):
            return AgentResult(
                ResultStatus.ERROR,
                "Substrate provider entry exists but is not managed by "
                "substrate-setup (run configure to re-take ownership)",
            )
        catalog_ids = {e.id for e in ctx.catalog}
        config_ids = set(substrate.get("models", {}).keys())
        missing = catalog_ids - config_ids
        stale = config_ids - catalog_ids
        if missing or stale:
            parts = []
            if missing:
                parts.append(f"missing: {sorted(missing)}")
            if stale:
                parts.append(f"stale: {sorted(stale)}")
            return AgentResult(ResultStatus.ERROR, "; ".join(parts))
        return AgentResult(ResultStatus.SUCCESS, "in sync")

    def remove(self, ctx: ConfigureContext) -> AgentResult:
        cfg_path = _config_yaml()
        if not cfg_path.exists():
            return AgentResult(ResultStatus.SKIPPED, "Hermes not configured")
        backups: list[Path] = []
        cfg_backup = backup_once(cfg_path)
        if cfg_backup is not None:
            backups.append(cfg_backup)
        payload = _load_yaml(cfg_path)
        providers = payload.get("custom_providers") or []
        kept = [
            p for p in providers
            if not (p.get("name") == PROVIDER_NAME and is_substrate_managed(p))
        ]
        payload["custom_providers"] = kept
        if not ctx.dry_run:
            _dump_yaml(cfg_path, payload)

        # Strip SUBSTRATE_API_KEY from .env only if it's currently a Substrate-shaped value.
        env_path = _env_file()
        if env_path.exists():
            lines = _read_env_lines(env_path)
            new_lines = []
            stripped = False
            for line in lines:
                if line.startswith(f"{ENV_VAR}="):
                    value = line.split("=", 1)[1]
                    if value.startswith("sk-substrate-"):
                        stripped = True
                        continue
                new_lines.append(line)
            if stripped:
                env_backup = backup_once(env_path)
                if env_backup is not None:
                    backups.append(env_backup)
                if not ctx.dry_run:
                    _write_env_lines(env_path, new_lines)

        return AgentResult(
            ResultStatus.SUCCESS,
            "Removed substrate provider entry from Hermes",
            tuple(backups),
        )
