"""Aider integration.

Files:
  ~/.aider.conf.yml             — openai-api-base + model-metadata-file pointer
  ~/.aider.model.metadata.json  — LiteLLM-shaped per-model metadata
  ~/.env                        — OPENAI_API_KEY

NEVER touches project-local .aider.conf.yml, .aider.model.metadata.json,
or .env files.
"""
from __future__ import annotations

import io
import json
from pathlib import Path
from typing import Any

from ruamel.yaml import YAML

from substrate_setup.agents.base import (
    Agent,
    AgentResult,
    ConfigureContext,
    ResultStatus,
)
from substrate_setup.backup import backup_once
from substrate_setup.markers import MARKER_KEY, MARKER_VALUE, is_substrate_managed

OPENAI_KEY_VAR = "OPENAI_API_KEY"


def _conf_path() -> Path:
    return Path.home() / ".aider.conf.yml"


def _meta_path() -> Path:
    return Path.home() / ".aider.model.metadata.json"


def _env_path() -> Path:
    return Path.home() / ".env"


def _yaml() -> YAML:
    y = YAML()
    y.preserve_quotes = True
    y.indent(mapping=2, sequence=4, offset=2)
    return y


def _load_yaml(path: Path) -> dict[str, Any]:
    if not path.exists():
        return {}
    result: dict[str, Any] = _yaml().load(path.read_text(encoding="utf-8")) or {}
    return result


def _dump_yaml(path: Path, data: dict[str, Any]) -> None:
    buf = io.StringIO()
    _yaml().dump(data, buf)
    path.write_text(buf.getvalue(), encoding="utf-8")


def _load_meta(path: Path) -> dict[str, Any]:
    if not path.exists():
        return {}
    result: dict[str, Any] = json.loads(path.read_text(encoding="utf-8"))
    return result


def _dump_meta(path: Path, data: dict[str, Any]) -> None:
    path.write_text(json.dumps(data, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def _model_id_for_aider(catalog_id: str) -> str:
    """LiteLLM needs `openai/` prefix to route through OPENAI_API_BASE."""
    return f"openai/{catalog_id}"


def _metadata_for_entry() -> dict[str, Any]:
    return {
        "max_input_tokens": 200000,
        "max_output_tokens": 8192,
        "input_cost_per_token": 0.0,   # Cost tracking lives in the gateway, not in Aider.
        "output_cost_per_token": 0.0,
        "litellm_provider": "openai",
        "mode": "chat",
        MARKER_KEY: MARKER_VALUE,
    }


def _read_env_lines(path: Path) -> list[str]:
    if not path.exists():
        return []
    return path.read_text(encoding="utf-8").splitlines()


def _write_env_lines(path: Path, lines: list[str]) -> None:
    path.write_text("\n".join(lines) + ("\n" if lines else ""), encoding="utf-8")


class AiderAgent(Agent):
    name = "aider"
    pretty_name = "Aider"

    def detect(self) -> Path | None:
        conf = _conf_path()
        return conf if conf.exists() else None

    def configure(self, ctx: ConfigureContext) -> AgentResult:
        backups: list[Path] = []
        notes: list[str] = []

        # ── ~/.aider.conf.yml ────────────────────────────────────────
        conf = _conf_path()
        if conf.exists():
            backup = backup_once(conf)
            if backup is not None:
                backups.append(backup)
        conf_data = _load_yaml(conf)
        conf_data["openai-api-base"] = ctx.base_url
        conf_data["model-metadata-file"] = str(_meta_path())
        if not ctx.dry_run:
            _dump_yaml(conf, conf_data)

        # ── ~/.aider.model.metadata.json ─────────────────────────────
        meta = _meta_path()
        if meta.exists():
            backup = backup_once(meta)
            if backup is not None:
                backups.append(backup)
        meta_data = _load_meta(meta)
        catalog_keys = {_model_id_for_aider(e.id) for e in ctx.catalog}

        # Drop substrate-managed entries that are no longer in the live catalog.
        if ctx.catalog_source == "live":
            meta_data = {
                k: v for k, v in meta_data.items()
                if not is_substrate_managed(v) or k in catalog_keys
            }
        # Add / update from current catalog.
        for entry in ctx.catalog:
            meta_data[_model_id_for_aider(entry.id)] = _metadata_for_entry()

        if not ctx.dry_run:
            _dump_meta(meta, meta_data)

        # ── ~/.env (credential) ──────────────────────────────────────
        env = _env_path()
        lines = _read_env_lines(env)
        existing_value = None
        for line in lines:
            if line.startswith(f"{OPENAI_KEY_VAR}="):
                existing_value = line.split("=", 1)[1]
                break
        should_write_env = False
        new_lines = list(lines)
        if existing_value is None:
            new_lines.append(f"{OPENAI_KEY_VAR}={ctx.api_key}")
            should_write_env = True
        elif existing_value.startswith("sk-substrate-"):
            if existing_value != ctx.api_key:
                new_lines = [
                    f"{OPENAI_KEY_VAR}={ctx.api_key}"
                    if line.startswith(f"{OPENAI_KEY_VAR}=")
                    else line
                    for line in lines
                ]
                should_write_env = True
        else:
            notes.append(
                "Aider's ~/.env already has OPENAI_API_KEY set to a non-Substrate-shaped "
                "value; please update manually."
            )

        if should_write_env:
            if env.exists():
                env_backup = backup_once(env)
                if env_backup is not None:
                    backups.append(env_backup)
            if not ctx.dry_run:
                _write_env_lines(env, new_lines)

        msg = (
            f"{len(ctx.catalog)} models written. Conf: ~/.aider.conf.yml, "
            "metadata: ~/.aider.model.metadata.json, key in ~/.env."
        )
        if notes:
            msg += "\n" + "\n".join(notes)
        return AgentResult(ResultStatus.SUCCESS, msg, tuple(backups))

    def verify(self, ctx: ConfigureContext) -> AgentResult:
        meta = _meta_path()
        if not meta.exists():
            return AgentResult(ResultStatus.ERROR, "Aider metadata file does not exist")
        meta_data = _load_meta(meta)
        catalog_keys = {_model_id_for_aider(e.id) for e in ctx.catalog}
        substrate_keys = {
            k for k, v in meta_data.items() if is_substrate_managed(v)
        }
        missing = catalog_keys - substrate_keys
        stale = substrate_keys - catalog_keys
        if missing or stale:
            parts = []
            if missing:
                parts.append(f"missing: {sorted(missing)}")
            if stale:
                parts.append(f"stale: {sorted(stale)}")
            return AgentResult(ResultStatus.ERROR, "; ".join(parts))
        return AgentResult(ResultStatus.SUCCESS, "in sync")

    def remove(self, ctx: ConfigureContext) -> AgentResult:
        meta = _meta_path()
        backups: list[Path] = []
        if meta.exists():
            backup = backup_once(meta)
            if backup is not None:
                backups.append(backup)
            meta_data = _load_meta(meta)
            meta_data = {
                k: v for k, v in meta_data.items() if not is_substrate_managed(v)
            }
            if not ctx.dry_run:
                _dump_meta(meta, meta_data)

        # Strip OPENAI_API_KEY from ~/.env only if its value is currently a Substrate key.
        env = _env_path()
        if env.exists():
            lines = _read_env_lines(env)
            kept = []
            stripped = False
            for line in lines:
                if line.startswith(f"{OPENAI_KEY_VAR}="):
                    value = line.split("=", 1)[1]
                    if value.startswith("sk-substrate-"):
                        stripped = True
                        continue
                kept.append(line)
            if stripped:
                env_backup = backup_once(env)
                if env_backup is not None:
                    backups.append(env_backup)
                if not ctx.dry_run:
                    _write_env_lines(env, kept)

        return AgentResult(
            ResultStatus.SUCCESS,
            "Removed substrate metadata entries from Aider",
            tuple(backups),
        )
