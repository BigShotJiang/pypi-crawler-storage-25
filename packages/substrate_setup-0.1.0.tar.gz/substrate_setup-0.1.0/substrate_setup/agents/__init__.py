"""Agent registry. Imports each agent module; exposes the list.

Order of this list is the order they print in the summary.
"""
from __future__ import annotations

from substrate_setup.agents.aider import AiderAgent
from substrate_setup.agents.base import Agent
from substrate_setup.agents.continue_dev import ContinueAgent
from substrate_setup.agents.cursor import CursorAgent
from substrate_setup.agents.hermes import HermesAgent

ALL_AGENTS: list[Agent] = [
    HermesAgent(),
    CursorAgent(),
    AiderAgent(),
    ContinueAgent(),
]

AGENT_NAMES: list[str] = [a.name for a in ALL_AGENTS]
