"""Cursor handler — print-only.

Cursor stores its custom OpenAI base URL + key + model list in
state.vscdb (SQLite) + OS secure storage. It does NOT read these from
settings.json and does NOT read OPENAI_API_KEY from env. So this
handler can only print a walkthrough.
"""
from __future__ import annotations

import os
import sys
from pathlib import Path

from substrate_setup.agents.base import (
    Agent,
    AgentResult,
    ConfigureContext,
    ResultStatus,
)


def _user_data_candidates() -> list[Path]:
    home = Path.home()
    candidates = [
        home / "Library/Application Support/Cursor",
        home / ".config/Cursor",
    ]
    if sys.platform == "win32":
        appdata = os.environ.get("APPDATA")
        if appdata:
            candidates.append(Path(appdata) / "Cursor")
    return candidates


class CursorAgent(Agent):
    name = "cursor"
    pretty_name = "Cursor"

    def detect(self) -> Path | None:
        for path in _user_data_candidates():
            if path.exists():
                return path
        return None

    def configure(self, ctx: ConfigureContext) -> AgentResult:
        bullets = "\n".join(f"     - {e.id}" for e in ctx.catalog)
        print(
            "Cursor detected. Cursor stores its API config in secure OS storage,\n"
            "so substrate-setup cannot write it for you. Open Cursor and:\n"
            "\n"
            "  1. Settings (⌘/Ctrl-,) → Models\n"
            "  2. Toggle \"Override OpenAI Base URL\" ON\n"
            f"  3. Paste this Base URL:  {ctx.base_url}\n"
            f"  4. Paste this API Key:   {ctx.api_key}\n"
            "  5. Click \"Verify\"\n"
            "  6. Add these models (Settings → Models → \"Add Model\"), one at a time:\n"
            f"{bullets}\n"
            "\n"
            "WARNING: enabling \"Override OpenAI Base URL\" is global — it will also\n"
            "route Cursor's first-party Composer / Tab / Apply features through\n"
            "Substrate, which may not work as expected. This is a Cursor limitation,\n"
            "not a substrate-setup issue."
        )
        return AgentResult(
            ResultStatus.PRINT_ONLY,
            "Printed paste-into-Cursor walkthrough",
        )

    def verify(self, ctx: ConfigureContext) -> AgentResult:
        print(
            "Cursor: cannot verify automatically — config lives in Cursor's secure storage."
        )
        return AgentResult(
            ResultStatus.PRINT_ONLY,
            "Cursor verify is print-only",
        )

    def remove(self, ctx: ConfigureContext) -> AgentResult:
        print(
            "Cursor: substrate-setup cannot remove your config (it lives in secure\n"
            "OS storage). To clean up, open Cursor and:\n"
            "  1. Settings (⌘/Ctrl-,) → Models\n"
            "  2. Toggle \"Override OpenAI Base URL\" OFF\n"
            "  3. Clear the OpenAI API Key field\n"
            "  4. Remove the Substrate-added models from the model list."
        )
        return AgentResult(
            ResultStatus.PRINT_ONLY,
            "Printed remove-from-Cursor walkthrough",
        )
