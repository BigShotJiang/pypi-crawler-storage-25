"""CLI orchestration for substrate-setup.

Subcommands:
  configure   (default) detect agents and write Substrate config
  verify      report whether each detected agent is in sync with the catalog
  remove      strip substrate-managed entries from each detected agent
  version     print version

Common flags: --base-url, --agents-only, --dry-run, --quiet.
"""
from __future__ import annotations

import argparse
import sys
from collections.abc import Callable

from substrate_setup import __version__
from substrate_setup.agents import AGENT_NAMES, ALL_AGENTS
from substrate_setup.agents.base import Agent, AgentResult, ConfigureContext, ResultStatus
from substrate_setup.catalog import (
    AuthError,
    CatalogEntry,
    CatalogUnavailableError,
    fetch_catalog,
)
from substrate_setup.credentials import (
    CredentialResolutionError,
    InvalidKeyFormatError,
    resolve_api_key,
)

EXIT_OK = 0
EXIT_AUTH = 1
EXIT_CATALOG = 2
EXIT_PARTIAL = 3
EXIT_BAD_FLAGS = 4

DEFAULT_BASE_URL = "https://substrate-solutions-api.fly.dev/v1"


def _common_flags_parser() -> argparse.ArgumentParser:
    """Return a parser holding the flags shared by configure/verify/remove."""
    p = argparse.ArgumentParser(add_help=False)
    p.add_argument("--base-url", default=None, help="Override gateway base URL")
    p.add_argument(
        "--agents-only",
        default=None,
        help=f"Comma-separated subset of: {','.join(AGENT_NAMES)}",
    )
    p.add_argument("--dry-run", action="store_true", help="Mutate nothing")
    p.add_argument("--quiet", action="store_true", help="Summary only")
    return p


def build_parser() -> argparse.ArgumentParser:
    common = _common_flags_parser()
    parser = argparse.ArgumentParser(
        prog="substrate-setup",
        description="Configure local coding agents against a Substrate gateway.",
        parents=[common],
    )
    sub = parser.add_subparsers(dest="command")
    sub.add_parser("configure", parents=[common],
                   help="Default: detect agents and configure")
    sub.add_parser("verify", parents=[common],
                   help="Read-only: check whether each agent is in sync")
    sub.add_parser("remove", parents=[common],
                   help="Strip substrate-managed entries")
    sub.add_parser("version", help="Print version and exit")
    return parser


def _select_agents(filter_str: str | None) -> list[Agent]:
    if filter_str is None:
        return list(ALL_AGENTS)
    wanted = {name.strip() for name in filter_str.split(",") if name.strip()}
    unknown = wanted - set(AGENT_NAMES)
    if unknown:
        print(
            f"Unknown agent(s) in --agents-only: {sorted(unknown)}. "
            f"Valid: {AGENT_NAMES}",
            file=sys.stderr,
        )
        sys.exit(EXIT_BAD_FLAGS)
    return [a for a in ALL_AGENTS if a.name in wanted]


def _resolve_base_url(arg: str | None) -> str:
    import os

    if arg is not None:
        return arg
    return os.environ.get("SUBSTRATE_BASE_URL") or DEFAULT_BASE_URL


def _run_per_agent(
    agents: list[Agent],
    ctx: ConfigureContext,
    method: Callable[[Agent], AgentResult],
    *,
    label: str,
    quiet: bool,
) -> int:
    """Execute ``method`` on each detected agent. Print results. Return exit code."""
    if not quiet:
        print(f"{label} agents …")
        print("Detected agents:")
        for a in agents:
            detected = a.detect()
            tag = "[print-only handler]" if a.name == "cursor" else ""
            mark = "✓" if detected else "·"
            note = f"({detected})" if detected else "not installed"
            print(f"  {mark} {a.pretty_name:<12} {note} {tag}")
        print()

    error_count = 0
    handled = 0
    for a in agents:
        detected = a.detect()
        if not detected:
            continue
        handled += 1
        try:
            result = method(a)
        except Exception as exc:  # noqa: BLE001
            result = AgentResult(ResultStatus.ERROR, f"unhandled error: {exc}")
        if not quiet:
            prefix = f"{label} {a.pretty_name:<10}"
            if result.status == ResultStatus.ERROR:
                print(f"{prefix} … ERROR: {result.message}")
            elif result.status == ResultStatus.PRINT_ONLY:
                print(f"{prefix} … printed walkthrough above.")
            else:
                print(f"{prefix} … {result.message}")
            for backup in result.backup_paths:
                print(f"             Backup: {backup}")
        if result.status == ResultStatus.ERROR:
            error_count += 1

    if not quiet:
        total = sum(1 for a in agents if a.detect())
        print()
        print(
            f"Done. {handled} of {total} detected agents handled. "
            f"{error_count} error{'s' if error_count != 1 else ''}."
        )
    return EXIT_PARTIAL if error_count > 0 else EXIT_OK


def _build_ctx(
    args: argparse.Namespace,
    base_url: str,
    api_key: str,
    catalog: list[CatalogEntry],
    source: str,
) -> ConfigureContext:
    return ConfigureContext(
        base_url=base_url,
        api_key=api_key,
        catalog=catalog,
        catalog_source=source,
        dry_run=args.dry_run,
    )


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)

    if args.command == "version":
        print(f"substrate-setup {__version__}")
        return EXIT_OK

    command = args.command or "configure"
    base_url = _resolve_base_url(args.base_url)

    try:
        api_key = resolve_api_key()
    except (CredentialResolutionError, InvalidKeyFormatError) as exc:
        print(str(exc), file=sys.stderr)
        return EXIT_AUTH

    try:
        catalog, source = fetch_catalog(base_url=base_url, api_key=api_key)
    except AuthError as exc:
        print(str(exc), file=sys.stderr)
        return EXIT_AUTH
    except CatalogUnavailableError as exc:
        print(str(exc), file=sys.stderr)
        return EXIT_CATALOG

    if not args.quiet:
        print(f"substrate-setup {__version__}")
        print(f"Fetched catalog ({source}): {len(catalog)} models.")
        print(f"API key resolved (length {len(api_key)} chars).")
        print()

    agents = _select_agents(args.agents_only)
    ctx = _build_ctx(args, base_url, api_key, catalog, source)

    if command == "configure":
        return _run_per_agent(agents, ctx, lambda a: a.configure(ctx),
                              label="Configuring", quiet=args.quiet)
    if command == "verify":
        return _run_per_agent(agents, ctx, lambda a: a.verify(ctx),
                              label="Verifying", quiet=args.quiet)
    if command == "remove":
        return _run_per_agent(agents, ctx, lambda a: a.remove(ctx),
                              label="Removing", quiet=args.quiet)
    parser.print_help()
    return EXIT_BAD_FLAGS
