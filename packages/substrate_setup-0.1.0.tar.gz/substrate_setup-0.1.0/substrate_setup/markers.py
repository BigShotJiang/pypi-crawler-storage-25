"""Sentinel marker for substrate-setup-owned config entries.

Marker discipline: every entry the script writes carries
``{_substrate_managed: True}``. Re-runs / verify / remove use this to
identify Substrate-owned entries without disturbing user-authored ones.
"""
from __future__ import annotations

from typing import Any

MARKER_KEY = "_substrate_managed"
MARKER_VALUE = True


def mark(entry: dict[str, Any]) -> dict[str, Any]:
    """Return a new dict equal to ``entry`` plus the marker."""
    return {**entry, MARKER_KEY: MARKER_VALUE}


def unmark(entry: dict[str, Any]) -> dict[str, Any]:
    """Return a new dict equal to ``entry`` minus the marker."""
    return {k: v for k, v in entry.items() if k != MARKER_KEY}


def is_substrate_managed(entry: dict[str, Any]) -> bool:
    """True iff the entry was written by substrate-setup."""
    return entry.get(MARKER_KEY) is MARKER_VALUE
