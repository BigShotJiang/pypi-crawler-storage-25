"""Catalog fetch — live /v1/models with bundled-snapshot fallback."""
from __future__ import annotations

import json
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Literal

import httpx

CONNECT_TIMEOUT_SEC = 5.0
READ_TIMEOUT_SEC = 10.0

_FALLBACK_PATH = Path(__file__).parent / "data" / "fallback_catalog.json"


@dataclass(frozen=True)
class CatalogEntry:
    id: str
    provider: str
    display_name: str
    description: str


class AuthError(Exception):
    """The gateway rejected the API key (HTTP 401)."""


class CatalogUnavailableError(Exception):
    """Live fetch failed AND the bundled snapshot is missing/corrupt."""


def _parse_payload(payload: dict[str, Any]) -> list[CatalogEntry]:
    return [
        CatalogEntry(
            id=item["id"],
            provider=item.get("owned_by", "unknown"),
            display_name=item.get("display_name", item["id"]),
            description=item.get("description", ""),
        )
        for item in payload.get("data", [])
    ]


def _load_fallback() -> list[CatalogEntry]:
    if not _FALLBACK_PATH.exists():
        raise CatalogUnavailableError(
            f"Bundled fallback catalog missing at {_FALLBACK_PATH}. "
            "Reinstall substrate-setup."
        )
    try:
        payload = json.loads(_FALLBACK_PATH.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise CatalogUnavailableError(
            f"Bundled fallback catalog at {_FALLBACK_PATH} is corrupt: {exc}"
        ) from exc
    return _parse_payload(payload)


def fetch_catalog(
    *,
    base_url: str,
    api_key: str,
) -> tuple[list[CatalogEntry], Literal["live", "fallback"]]:
    """Fetch the model catalog. Returns (entries, source-tag).

    Resolution order:
      1. live GET <base_url>/v1/models with Bearer <api_key>
      2. bundled fallback snapshot (with warning printed to stderr)

    Raises:
      AuthError: live fetch returned 401. Caller should exit 1.
      CatalogUnavailableError: live fetch failed AND fallback is missing/corrupt.
        Caller should exit 2.
    """
    # Tolerate users passing base URLs with or without a trailing /v1
    normalized = base_url.rstrip("/")
    if normalized.endswith("/v1"):
        normalized = normalized[:-3]
    url = f"{normalized}/v1/models"
    timeout = httpx.Timeout(READ_TIMEOUT_SEC, connect=CONNECT_TIMEOUT_SEC)
    try:
        resp = httpx.get(
            url,
            headers={"Authorization": f"Bearer {api_key}"},
            timeout=timeout,
        )
    except httpx.TransportError as exc:
        print(
            f"WARNING: could not reach {url} ({type(exc).__name__}); "
            "using bundled catalog snapshot. Models may be out of date.",
            file=sys.stderr,
        )
        return _load_fallback(), "fallback"

    if resp.status_code == 401:
        raise AuthError(
            f"That key was rejected by {base_url}. Did you copy the full string?"
        )
    if resp.status_code >= 500:
        print(
            f"WARNING: gateway at {url} returned HTTP {resp.status_code}; "
            "using bundled catalog snapshot. Models may be out of date.",
            file=sys.stderr,
        )
        return _load_fallback(), "fallback"
    resp.raise_for_status()
    return _parse_payload(resp.json()), "live"
