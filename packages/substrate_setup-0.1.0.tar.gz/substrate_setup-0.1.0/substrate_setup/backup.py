"""Backup-on-write helper.

One backup per (file, run). The first call backs up; subsequent calls
for the same path in the same Python process are no-ops returning the
first backup's path.
"""
from __future__ import annotations

import shutil
import time
from pathlib import Path

_backups_this_run: dict[Path, Path] = {}


def backup_once(target: Path) -> Path | None:
    """Backup ``target`` to ``<target>.substrate-bak-<unix-ts>``.

    Returns the backup path. If the target doesn't exist, returns None.
    Within a single process, repeated calls for the same target return
    the first backup's path without touching anything.
    """
    target = target.resolve()
    if target in _backups_this_run:
        return _backups_this_run[target]
    if not target.exists():
        return None
    ts = int(time.time())
    backup_path = target.parent / f"{target.name}.substrate-bak-{ts}"
    shutil.copy2(target, backup_path)
    _backups_this_run[target] = backup_path
    return backup_path
