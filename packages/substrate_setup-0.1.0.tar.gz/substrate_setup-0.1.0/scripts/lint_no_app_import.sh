#!/usr/bin/env bash
# CI lint: substrate_setup/ MUST NOT import anything from app/.
# The two packages share a source tree, not a dependency graph.
set -euo pipefail
PKG_DIR="$(cd "$(dirname "$0")/.." && pwd)"
if grep -RIn --include='*.py' '^from app\b\|^import app\b' "$PKG_DIR/substrate_setup"; then
    echo "ERROR: substrate_setup/ must not import from app/. See package boundary rule in spec."
    exit 1
fi
echo "OK: no app/ imports in substrate_setup/"
