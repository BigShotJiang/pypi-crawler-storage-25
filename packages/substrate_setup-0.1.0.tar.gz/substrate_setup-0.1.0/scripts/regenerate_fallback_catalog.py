"""Regenerate the bundled fallback catalog snapshot.

Run manually before each PyPI release of substrate-setup. NOT run by CI cron —
a transient production glitch should NEVER be baked into the next release.

Usage:
    SUBSTRATE_API_KEY=sk-substrate-... \
        python scripts/regenerate_fallback_catalog.py [--base-url https://...]

Writes substrate_setup/data/fallback_catalog.json. Applies a sanity check
(>= 5 models, all five expected providers present) before writing.
"""
from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path

import httpx

EXPECTED_PROVIDERS = {"anthropic", "openai", "google", "deepseek", "moonshot"}
DEFAULT_BASE_URL = "https://substrate-solutions-api.fly.dev/v1"
TARGET = Path(__file__).resolve().parents[1] / "substrate_setup" / "data" / "fallback_catalog.json"


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base-url", default=DEFAULT_BASE_URL)
    args = parser.parse_args(argv)

    api_key = os.environ.get("SUBSTRATE_API_KEY")
    if not api_key:
        print("ERROR: SUBSTRATE_API_KEY env var required.", file=sys.stderr)
        return 1

    # Tolerate --base-url with or without a trailing /v1 (same convention as
    # substrate_setup.catalog.fetch_catalog).
    normalized = args.base_url.rstrip("/")
    if normalized.endswith("/v1"):
        normalized = normalized[:-3]

    resp = httpx.get(
        f"{normalized}/v1/models",
        headers={"Authorization": f"Bearer {api_key}"},
        timeout=15.0,
    )
    resp.raise_for_status()
    payload = resp.json()

    data = payload.get("data") or []
    providers = {item.get("owned_by") for item in data}
    if len(data) < 5:
        print(f"REFUSED: only {len(data)} models in catalog (expected >= 5).", file=sys.stderr)
        return 2
    if not EXPECTED_PROVIDERS.issubset(providers):
        missing = EXPECTED_PROVIDERS - providers
        print(f"REFUSED: missing providers {missing}.", file=sys.stderr)
        return 2

    TARGET.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    print(f"Wrote {len(data)} models to {TARGET}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
