# Vertex ⚡

A terminal coding agent powered by Groq with 7-model LLM fallback and RAG-based code retrieval.

## Install
pip install vertex-agent

## Setup
Create a .env file:
GROQ_API_KEY=your_key_here

## Run
vertex

## Features
- 5 tools: read, write, list, bash, RAG search
- 7 model fallback with TPM/TPD circuit breaker
- Code-aware RAG with ChromaDB
- Permission prompt before bash execution