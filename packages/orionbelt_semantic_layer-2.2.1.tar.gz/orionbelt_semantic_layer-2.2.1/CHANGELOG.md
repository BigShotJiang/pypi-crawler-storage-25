# Changelog

All notable changes to OrionBelt Semantic Layer are documented here.

## [2.2.1] - 2026-05-09

### Changed

- **Bundled demo model rewritten with business-friendly names.** `examples/orionbelt_1_commerce.yaml` now uses spaced YAML keys for every dataObject, column, dimension, measure, and metric. Common base measures use short business names (`Total Sales`, `Total Returns`, `Total Purchases`, `Total Shipments`) — the `Amount` suffix is dropped for amount-typed measures since amounts are the default; quantity/count variants keep their explicit suffixes. Derived metrics follow suit (`Return Rate`, `Average Sale`, `Cumulative Sales`, `MTD Sales`). Physical column names live unchanged in the `code:` fields, so the bundled DuckDB seed and the demo SQL are unaffected. Generic dimensions (`Client Name`, `Country Name`, …) coexist with explicit role-playing variants (`Sales Client Name` via Sales, `Complaint Client Name` via Client Complaints, etc.) so casual queries get business-named dropdowns and cross-fact queries can pin the join path with `via:` to silence `MISSING_VIA` warnings.
- **Demo model pins `settings.defaultDialect: duckdb`.** The bundled image runs against a baked-in DuckDB seed; the dialect is now declared in the model so the UI dropdown auto-selects DuckDB on load instead of falling back to its alphabetical default.
- **Demo model declares `refresh: { mode: static }` on every dataObject.** The bundled DuckDB seed is built into the image and never changes between deploys, so the freshness-driven result cache now uses `CACHE_MAX_TTL_SECONDS` (default 86400 = 1 day) as the effective TTL instead of falling back to the unknown-freshness 300s default. Also sidesteps the `tracked_physical_tables` / `entry_count: 0` divergence when entries land on Cloud Run's per-instance tmpfs and don't survive cold starts.
- **Demo model carries proper data types and display formats.** Adds `settings.defaultNumericDataType: "decimal(18, 2)"` and `settings.defaultTimezone: "Europe/Zagreb"`. Amount-typed measures use `dataType: "decimal(18, 2)"` and `format: "#,##0.00"`; counts use `bigint` + `"#,##0"`; ratio metrics use `decimal(18, 4)` + the auto-percent format `"#,##0.0%"` (the formatter multiplies by 100 at display time, so the stored value stays a raw ratio — `Return Rate = Total Returns / Total Sales` renders as `"12.3%"`).
- **UI: ``Execute Query`` snaps the SQL Dialect dropdown to the API's effective execution dialect** (from `/v1/settings.dialect.effective`) before executing. Lets users explore Postgres/Snowflake/etc. SQL via the Compile preview without accidentally sending a non-DuckDB statement to the underlying database.

### Fixed

- **Result cache silently no-op.** Every `cache.get` / `cache.set` against the file backend's DuckDB meta DB raised `Invalid Input Error: Required module 'pytz' failed to import` — DuckDB's Python binding lazily imports pytz when binding tz-aware datetimes (TIMESTAMPTZ columns), and the WARNING-level failure path returns a miss without surfacing the error. Cache stats showed `entry_count: 0` despite `tracked_physical_tables` accumulating on every query. Pin `pytz>=2024.1` as a runtime dep so DuckDB can persist cache entries.
- **ER diagram label clipping.** Per-attribute right-edge clipping in dense entities is gone: previously a CSS rule injected a 14px font on top of Mermaid's default-12px column-width measurement, so every row's text overflowed its measured rectangle. The override is removed; we now trust Mermaid's measure-equals-render contract.
- **ER diagram attribute names no longer mangle spaces into underscores.** Identifiers are camelCased from the column label (`Sales ID` → `SalesID`) and the spaced business label is emitted as the attribute's quoted comment column, so the diagram shows the human-readable name alongside the structural identifier. Entity names containing spaces (`Client Complaints`, `Account Balances`) are double-quoted so Mermaid renders them verbatim.
- **ER diagram join labels keep their business names** (e.g. `"Sales Client"`) instead of being lower-cased and underscored.

## [2.2.0] - 2026-05-05

### Added

- **`POST /v1/oneshot/batch` — one-shot batch endpoint.** Loads (or references) an OBML model and runs N independent queries against it in a single round trip. Designed for agent workflows where one model + multiple sub-questions is the dominant pattern. Supports `model_yaml` (transient or persisted via `persist_model: true`) or `model_id` (reference an already-loaded model). Queries run concurrently under an `asyncio.Semaphore` capped by `ONESHOT_BATCH_MAX_PARALLELISM` (default 8). Per-query overrides for `dialect` and `execute`. Stable result ordering keyed by caller-provided `id`. Partial failure is the default — each result carries its own `status` (`ok` / `error` / `cancelled`) and `error` envelope. `fail_fast: true` cancels remaining queries on first failure. Whole-batch and per-query timeouts are honored. Server limits surface via `GET /v1/settings.oneshot_batch`. See `design/PLAN_oneshot_batch.md`.
- **Model load deduplication.** `POST /v1/sessions/{sid}/models` and `POST /v1/oneshot/batch` now reuse an existing `model_id` when the same OBML bytes (whitespace-normalized) are already loaded in the session. The response includes a new `model_load` field (`"fresh"` | `"reused"` | `"referenced"` for batch). Skips parsing, validation, and OBSL graph generation on the dedup path. Disable with `dedup: false`. Index is per-session (session isolation preserved) and is cleared automatically on model removal. See `design/PLAN_model_load_dedup.md`.
- **Freshness-driven result cache (file backend, off by default).** New `CACHE_BACKEND=file` mode persists `query/execute` results in `{CACHE_DIR}/meta.duckdb` + Parquet sidecars. TTL is derived from the `freshness:` contract on each touched physical `dataObject` — the *minimum* contribution wins, and an ETL `POST /v1/heartbeat` invalidates every cached query that depends on the refreshed table. Cached `query/execute` responses gain `cached`, `cached_at`, `ttl_seconds`, `ttl_source`, `ttl_limiting_table`, and `physical_tables` fields. Per-query TTL caps via `caller_capped`; unknown-freshness queries skip the cache by default (`CACHE_UNKNOWN_FRESHNESS_POLICY=no_cache`) or fall back to a default TTL when explicitly enabled. Fails closed: any cache error degrades to a normal warehouse execution. See `docs/guide/result-cache.md` and `design/PLAN_freshness_driven_cache.md`.
- **`refresh:` block on dataObjects (OBML + OSI).** New per-dataObject freshness contract with `mode: static | scheduled | heartbeat | unknown`, plus mode-specific fields (`schedule:` cron, `nextRefreshAt:`, `maxStaleness:`, `tolerance:`). Roundtrips through OSI via `osi-obml/osi_obml_converter.py` (custom_extensions) and is declared in the OBSL ontology (`ontology/obsl.ttl`). Surfaced in `GET /v1/settings` and the Settings UI tab.
- **`GET /v1/cache/stats`, `POST /v1/cache/sweep`, `POST /v1/cache/clear`.** Stats exposes backend, entry count, total bytes, hit/miss counters, hit rate, oldest entry, next sweep, tracked physical tables, and heartbeat invalidations. Sweep runs one TTL + LRU capacity eviction pass on demand (returns `ttl_evicted` / `capacity_evicted`). Clear drops every entry regardless of TTL or dependencies (counters preserved as historical telemetry).
- **`POST /v1/heartbeat`.** ETL endpoint invalidating every cached query whose dependency set includes the refreshed `database.schema.table`. Bearer-auth via `HEARTBEAT_AUTH_TOKEN` (route returns 404 when unset). Response lists `invalidated_cache_entries` and `affected_data_objects`.
- **UI Cache panel.** Settings tab now shows a side-by-side **API Settings** + **Cache Stats** view with **Refresh Cache Stats**, **Sweep Cache now**, and **Clear Cache** buttons. Auto-loads on tab open. Query Results tab annotates each execution with `(cache)` or `(database)` next to `execution_time_ms`.

### Changed

- **`execution_time_ms` on cache hits** now reports the actual cache fetch + decode wall time, not the original DB run time persisted in the Parquet sidecar. Combined with the `cached: true` flag, this gives realistic "from cache" durations on the wire. The original DB timing remains on disk for forensic inspection.
- **`CACHE_SWEEP_INTERVAL_SECONDS` default raised from 900s (15 min) to 86400s (1 day).** Lazy TTL on read keeps user-facing freshness correct; the periodic sweeper only matters for reclaiming disk from entries that expire without being read again, so every 15 min was unnecessarily aggressive.
- **Persisted cache state (`meta.duckdb` + `results/`) is wiped on every server startup.** Structural reason: `model_id` is regenerated as a fresh UUID on every model load, so any entries from a previous process run reference model_ids that no longer exist — orphans by construction. Starting empty avoids accumulating dead state between restarts.
- **Cache stats output now uses UTC for both `oldest_entry` and `next_sweep_at`.** Previously `oldest_entry` rendered in the DuckDB session timezone (host local), creating a TZ mismatch with `next_sweep_at` (always UTC). Both are now ISO 8601 with `+00:00`.
- **Startup logging splits the cache config block into one line per setting** so each field is easy to grep without parsing one long line.

### Fixed

- **Gradio UI mounted in `create_app()` always captured `query_execute=False`** because `is_query_execute_enabled()` reads a deps.py global that's only populated inside the `lifespan` hook (which runs *after* the UI is mounted). UI settings now resolve directly from `Settings`, mirroring the same logic the lifespan uses, so the **Execute Query** button appears as soon as `QUERY_EXECUTE=true` is set.
- **Query Results dataframe no longer renders Gradio's default `1, 2, 3` placeholder columns** before the first execution. The dataframe is hidden until the post-execute visibility chain flips it on.

### Settings

- New env vars: `ONESHOT_BATCH_MAX_QUERIES` (50), `ONESHOT_BATCH_MAX_PARALLELISM` (8), `ONESHOT_BATCH_DEFAULT_TIMEOUT_MS` (30000), `ONESHOT_BATCH_BATCH_TIMEOUT_MS` (120000). All exposed in `GET /v1/settings.oneshot_batch`.
- New cache env vars: `CACHE_BACKEND` (`noop` default), `CACHE_DIR`, `CACHE_MIN_TTL_SECONDS` (5), `CACHE_MAX_TTL_SECONDS` (86400), `CACHE_MAX_VALUE_BYTES` (10 MB), `CACHE_MAX_DISK_BYTES` (5 GB), `CACHE_SWEEP_INTERVAL_SECONDS` (86400), `CACHE_UNKNOWN_FRESHNESS_POLICY` (`no_cache`), `CACHE_UNKNOWN_FRESHNESS_DEFAULT_TTL` (300), `HEARTBEAT_AUTH_TOKEN`.

### Behavior change

- Identical OBML loads in the same session now return the same `model_id` instead of minting a new one each time. Disable per-call with `dedup: false`.
- When the cache is enabled (`CACHE_BACKEND=file`), `query/execute` calls may serve cached results. Distinguish via the new `cached` field on the response. The cache fails closed on any error.

## [2.1.4] - 2026-05-03

### Fixed

- **`timeGrain` on a non-temporal column is now rejected at validation time** instead of producing a runtime SQL error. Previously a dimension like `{ column: YearMonth, resultType: string, timeGrain: month }` passed validation but compiled to `date_trunc('month', "Calendar"."ym")`, which Postgres (and other strict dialects) reject with `function date_trunc(unknown, text) does not exist`. The new check inspects the underlying `DataObject.columns[col].abstractType` and emits `TIME_GRAIN_ON_NON_TEMPORAL` unless the type is `date`, `timestamp`, or `timestamp_tz`. Error message includes a remediation hint (drop `timeGrain`, fix the column's `abstractType`, or define a computed column with `to_date()`). Particularly relevant for LLM-generated models, which were the most common source of this mistake.

### Documentation

- `docs/guide/model-format.md` and the `OBML_REFERENCE` resource now document the `timeGrain` constraint inline so LLMs generating OBML have the rule in their prompt context.

## [2.1.3] - 2026-04-30

### Fixed

- **Settings tab `timezone.now` showed UTC even after the v2.1.2 overlay set `timezone.effective: Europe/Berlin`.** The API had computed `now` server-side against its own (no-model) `effective` (UTC), and the v2.1.2 overlay only updated `effective` — leaving `now` stale. The overlay now also recomputes `now` as the current wall clock in the overlaid TZ when the API had no loaded model, so `now` and `effective` agree.

## [2.1.2] - 2026-04-30

### Fixed

- **Settings tab in the Gradio UI showed stale `effective` values** for `timezone` and `dialect` when the user had a model YAML pasted/loaded but had not yet compiled. The UI's `_fetch_settings_yaml` overlay only populated `tz["effective"]` and `dl["effective"]` when the API response was *missing* those keys — but the API always returns them (with no-model fallbacks: `UTC` / `DB_VENDOR`). The result: the overlay correctly added `model_settings` and `timezone.model` from the local YAML, but `effective` stayed at the API's no-model fallback. Now the overlay detects "API has no loaded model" by checking whether `model_settings` was returned by the API, and when absent, fully overlays the local YAML's TZ and dialect — including `effective` — so the Settings tab mirrors what compiling will produce.

## [2.1.1] - 2026-04-30

### Fixed

- **`/v1/settings.timezone.effective` falls back to UTC instead of the model's `defaultTimezone` on slim Linux Docker images.** Root cause: `python:3.12-slim` has no `/usr/share/zoneinfo`, so `ZoneInfo("Europe/Berlin")` (or any IANA name) raises `ZoneInfoNotFoundError`. The resolver caught the exception, walked the fallback chain (host TZ on Cloud Run is UTC and skipped), and ended at `UTC`. Now `tzdata>=2025.1` is a runtime dependency of `orionbelt-semantic-layer`, and both `Dockerfile` / `Dockerfile.ui` also `apt-get install tzdata` for defense in depth.

### Changed

- `examples/sem-layer.obml.yml` (the UI's default preloaded model) now declares `settings.defaultDialect: postgres`. Aligns the UI dialect dropdown and `/v1/settings.dialect.effective` for users loading the bundled demo — previously they could diverge when `DB_VENDOR` differed from the UI's hardcoded `postgres` fallback.

## [2.1.0] - 2026-04-30

### Added

- **Column-level computed columns on `DataObjectColumn`.** A column with `expression:` instead of `code:` defines a computed column inlined wherever the column is referenced. Single-brace `{Column}` placeholders refer to *sibling columns of the same data object*. Distinct from measure-level expressions (which use `{[DataObject].[Column]}` and can cross data objects). Example: `Year-Month: expression: "({Year} * 100 + {Month of Year})"`. Constraints: mutually exclusive with `code`, no recursive resolution. ORDER BY on a computed column is correctly emitted as the inlined expression.
- **Regex, blank, and string-length filter operators** in `QueryFilter`. Per-dialect regex SQL: Postgres `~`/`!~`, DuckDB `regexp_matches`, ClickHouse `match`, BigQuery `REGEXP_CONTAINS`, MySQL `REGEXP`, Databricks `RLIKE`, Snowflake/Dremio `REGEXP_LIKE`. New operators:
  - `regex` / `notregex` — match against a regular-expression pattern (string value)
  - `blank` / `notblank` — `(col IS NULL OR TRIM(col) = '')` and its inverse, for whitespace-aware empty checks on free-text columns
  - `length_eq` / `length_gt` / `length_lt` — `LENGTH(col) {= | > | <} N` (integer value), for fixed-width / padded-code filtering
- **`settings.defaultDialect` on the OBML model.** Optional top-level `settings.defaultDialect` lets a model pin its preferred SQL dialect so callers can omit `dialect` on every `/v1/query/sql` and `/v1/query/execute` request. Resolution chain at request time: explicit `dialect` → `settings.defaultDialect` → `DB_VENDOR` env → `postgres`. Validated against the 8 registered dialects at parse time. The session and shortcut endpoints both honor it; `dialect` on the request body is now `Optional`.
- **`/v1/query/execute` formatted output.** Four new query parameters on both the session-scoped and shortcut execute endpoints:
  - `format=tsv` returns `text/tab-separated-values` with RFC 4180-style quoting for cells containing tab/newline/CR/double-quote. Implies `format_values=true`.
  - `format_values=true` renders numeric cells in the JSON response as locale-aware display strings using each column's `format` pattern (matches the Gradio UI exactly).
  - `locale` (BCP-47) overrides the default locale for thousand/decimal separators; falls back to the new `DEFAULT_LOCALE` env when omitted.
  - `timezone` (IANA TZ) overrides the model's `default_timezone` per-request.
- **Shared formatting module** `service/value_formatting.py`. The UI and the API now use the same `format_number` / `parse_number_format` / `locale_separators` / `format_row` / `to_tsv` helpers, so what you see in Gradio is exactly what `?format_values=true` returns.
- **`DEFAULT_LOCALE` env / `default_locale` setting** (default empty → en-style separators).
- **Raw query mode (`select.fields`).** Returns un-aggregated rows by projecting physical columns directly. Mutually exclusive with `dimensions`/`measures`/`having`/`dimensionsExclude`. New `select.distinct` flag emits `SELECT DISTINCT`. Field references must be qualified `DataObject.Column`. Single-fact queries compile to a flat star-schema-style SELECT; fanout protection still applies (reversed many-to-one joins are rejected).
- **Raw CFL — multi-fact `UNION ALL` with NULL padding.** When `select.fields` references columns from independent fact tables, the planner emits one leg per leg-root fact, with typed `CAST(NULL AS <type>)` for fields not reachable from a given leg. Outer wrapper applies `DISTINCT` (when set), `ORDER BY` (remapped to field aliases), and `LIMIT`. New error codes: `RAW_FIELD_INVALID_REF`, `RAW_FIELD_UNKNOWN_OBJECT`, `RAW_FIELD_UNKNOWN_COLUMN`.
- **`UNION ALL BY NAME` optimization for raw CFL on DuckDB and Snowflake.** On dialects that support it, per-leg NULL padding is skipped — each leg only emits the columns it has, and the database fills missing columns automatically. Output rows are identical; SQL is shorter and more readable.
- **Public-doc gating flags** (`EXPOSE_API_DOCS`, `EXPOSE_OPENAPI_SCHEMA`). Default `true` to preserve the public-demo behaviour. Set `EXPOSE_API_DOCS=false` to hide `/docs` and `/redoc`; `EXPOSE_OPENAPI_SCHEMA` toggles `/openapi.json` independently. The Dockerfile and `deploy-gcloud.sh` pin both to `true` explicitly so the demo stays exposed even if defaults flip later.
- **`/v1/settings` now returns `version` and `api_version`.** Clients can negotiate features from a single call instead of also hitting `/health`.
- **`/v1/settings` exposes the loaded model's `settings:` block plus the timezone and dialect resolution chains.** New optional sub-objects on the response:
  - `model_settings` — every key from the model's `settings:` block (`defaultTimezone`, `defaultDialect`, `overrideDatabaseTimezone`, `defaultNumericDataType`), in OBML camelCase to mirror the YAML.
  - `timezone` — `{model, host, database, effective, override_database_timezone, now, utc, database_detected, database_raw}`. Always present so clients can show the wall clock even without a loaded model. The chain matches what `db_executor.resolve_timezone()` does at execute time: when `overrideDatabaseTimezone` is true the model wins; otherwise the cached DB session timezone (if any) takes priority. **The endpoint now warms the DB session-TZ cache on first hit when a model is bound and `query_execute` is enabled** — so the report runner / UI sees the correct `effective` immediately, instead of falling through to the model TZ until the first query happens to populate the cache. `database_detected` reports whether the probe has run, `database_raw` exposes the cached value for diagnostics. `now` is the current wall-clock time in the effective TZ (ISO 8601 with offset); `utc` is the same instant in UTC for reference.
  - `dialect` — `{model, env, effective}`. `effective` is what the planner uses when a request omits `dialect`: model.defaultDialect → DB_VENDOR → `postgres`. Always present.
- **`/v1/settings` accepts `?session_id=...&model_id=...` to scope the model-specific blocks in multi-model mode.** Resolution: single-model mode → preloaded model; both params → explicit lookup (404 on miss); `session_id` only → auto-pick when that session has exactly one model; no params in multi-model mode → auto-pick if a single model is loaded across all sessions, else the model blocks are omitted (no error). `model_id` without `session_id` → 400.

### Changed

- `Select` AST node gains a `distinct: bool` field; codegen emits `SELECT DISTINCT` when set. `QueryBuilder.distinct()` and a widened `with_cte()` signature support raw CFL composite construction.

### Fixed

- **CFL outer-aggregate ColumnRef alias shadowing on ClickHouse** (`ILLEGAL_AGGREGATION`). When a multi-fact CFL query mixed a measure with a metric referencing the same measure (e.g. `SUM(net_profit)` plus `SUM(net_profit)/SUM(sales) AS margin`), the metric's bare `SUM("Net Profit")` resolved to the sibling SELECT alias — itself an aggregate — and ClickHouse rejected the resulting nested aggregate. The planner now qualifies every ColumnRef inside outer-query aggregate functions with the composite CTE alias (`composite_01`), forcing resolution to the raw CTE column. Universally safe across all 7 dialects.
- **CFL NULL-padding dialect threading on ClickHouse** (`ILLEGAL_TYPE_OF_ARGUMENT — Variant(Decimal, Float64)`). The single-/zero-column path in `_resolve_null_type_for_field` was missing the `dialect` argument, so it bypassed `resolve_measure_data_type` and fell back to `result_type.value` (`'float'`) — emitting `CAST(NULL AS Nullable(Float64))` while the actual ClickHouse columns are `Decimal(7, 2)`. The `UNION ALL` widened to a `Variant` that `SUM` couldn't consume. Threading `dialect` through aligns NULL padding with the outer CAST target.
- **Raw CFL filter drop & ORDER BY on computed columns.** WHERE filters on data objects unreachable from a leg are now silently skipped per leg (instead of failing the entire query), matching the agg-mode semantics. ORDER BY on a column whose source AST is an inlined expression (computed column) now correctly remaps to the CTE alias in the outer query via structural-equality matching.
- **`/v1/settings` warms the DB session-TZ cache on first hit** when a model is bound and `query_execute` is enabled — and now also without a model bound when the cache is empty. Eliminates the previous one-request lag where the report runner / UI saw `effective: <model TZ>` until a real query happened to populate the probe.

### Docs

- New "Computed Columns" subsection in `guide/model-format.md` covering the column-level `expression:` field, single-brace `{Column}` syntax, the inlining semantics, and a reference-syntax cheat-sheet distinguishing column- vs measure- vs metric-level expressions.
- New "Regex Operators" and "String Length Operators" tables in `guide/query-language.md`, plus `blank` / `notblank` rows added to "Null Operators". Each includes per-dialect generated SQL for portability planning.
- Pinned an explicit `{ #filter-groups }` anchor on the Filter Groups heading so the in-page link `[filter groups](#filter-groups)` survives future heading-text edits.
- Expanded the bundled `examples/tpcds.obml.yml` model with `catalog_sales`, `catalog_returns`, `web_returns`, `inventory`, `warehouse`, `ship_mode`, and `reason` data objects, plus `Manager ID`, `Day Name`, and matching dimensions/measures. Demonstrates multi-fact CFL across three sales channels and exercises the new computed-column dim (`Year-Month`).

## [2.0.1] - 2026-04-27

### Added

- **`/v1/settings` now returns `version` and `api_version`.** Clients can negotiate features from a single call instead of also hitting `/health`. `version` matches the `__version__` constant; `api_version` is the REST URL prefix (`"v1"`).

### Docs

- Reordered `query-language.md`: the **Coalesce (Merging Role-Playing Dimensions)** section now sits between **Time Grain Override** and **Measures** so it reads next to the other dimension subsections.

## [2.0.0] - 2026-04-27

### Breaking

- **Many-to-one joins are now strictly forward-only.** The query planner refuses to walk a `many-to-one` join in reverse (which would silently inflate fact-table row counts). Queries that previously compiled by traversing such a reverse hop now raise `UNREACHABLE_REQUIRED_OBJECT`. **Migration:** declare bridge tables as `many-to-many` (already supported by OBML); see `examples/movies.obml.yml` for the canonical pattern.
- **CFL leg projection now honors per-dimension `via:` waypoints.** Role-playing dimensions (e.g., `Sales Employee` and `Purchase Employee`) no longer leak across UNION ALL legs — each leg projects only its own role and NULL-pads the others. Query results CHANGE for any model that had role-playing dimensions where the previous (incorrect) behavior was being relied on. **Migration:** the new output is the correct one; verify and update downstream code accordingly.
- **PostgreSQL renderer now emits `DECIMAL(p, s)`** instead of `NUMERIC(p, s)`. The two are SQL-standard synonyms in Postgres and every other supported dialect (canonical name in sqlglot is `DECIMAL`). **Migration:** consumers comparing exact SQL strings need an update; query semantics are unchanged.
- **`sqlparse` removed from dependencies.** The UI and API now use sqlglot's pretty-printer for all SQL formatting. Anyone transitively importing `sqlparse` from this project must add it to their own dependencies.

### Added

- **Query-level `coalesce` dimensions.** `select.dimensions` now accepts a `{coalesce: [...], as: <alias>}` group that merges role-playing dimensions into a single output column via `COALESCE(d1, d2, ...)`. ORDER BY may reference the alias directly. Validation: 5 new error codes (`COALESCE_MISSING_ALIAS`, `DUPLICATE_COALESCE_ALIAS`, `COALESCE_ALIAS_COLLISION`, `COALESCE_TOO_FEW_MEMBERS`, `COALESCE_TYPE_MISMATCH`).
- **`primaryKey` column property.** Optional informational marker on data object columns. Renders as `PK` in the Mermaid ER diagram (precedence over `FK`) and emits `obsl:primaryKey true` triples in the OBSL graph. Composite keys: set `primaryKey: true` on multiple columns.
- **`UNREACHABLE_REQUIRED_OBJECT` error.** Resolution-time error raised when a required dimension's source object cannot be reached from the query base via directed joins. Replaces silently-wrong SQL with a clear migration hint.
- **`examples/movies.obml.yml`** — bundled junction-table example (Movies / Directors / Producers with `many-to-many` bridges) demonstrating the recommended OBML pattern for many-to-many relationships.
- **Vertically responsive Gradio UI layout.** SQL Compiler, ER Diagram, and Ontology Graph tabs scale with viewport height via `dvh`-based CSS. Editor and output rows resize fluidly without overflow.
- **Ontology Graph tab.** Interactive vis-network visualization (data objects, dimensions, measures, metrics, joins) with toggleable layers and adjustable node spacing. vis-network v9.1.2 ships as a static asset (no CDN dependency), loaded via base64-encoded iframe srcdoc.
- **API responses now return sqlglot-pretty SQL.** Every `/v1/.../query/sql` and `/v1/.../query/execute` endpoint formats SQL with one expression per line. Consumers (gradio_client, MCP, AI agents, dashboards) get readable SQL by default with no flag required.

### Fixed

- **CFL planner via-aware leg construction** (see Breaking).
- **Join graph reverse-traversal silent fanout** (see Breaking).
- **MISSING_VIA validator** — only warns when a dimension table has direct joins from multiple fact tables, not transitive reachability. Fact-table dimensions (columns on the fact table itself) no longer trigger false warnings.
- **Example model `via` cleanup** — removed unnecessary `via` from dimensions on tables that are only direct children of one fact table (Clients, Countries, Regions) and from fact-table-local dimensions (Sales Date, Payment Type).

### Removed

- `sqlparse` runtime dependency.
- Unused `Graph Height` slider on the Ontology Graph tab (the iframe is now viewport-height driven).

### Security

- New Cloud Armor rules for the public demo block `/ui/gradio_api/info`, `/ui/monitoring/*`, and `/ui/openapi.json` (admin/discovery endpoints not used by the browser UI).
- `main` branch protection enabled on the public repo and the four sibling repos: PR required, force-push and deletion blocked, linear history enforced.

## [1.8.2] - 2026-04-25

_Release notes pending._

## [1.8.1] - 2026-04-24

### Fixed

- **CFL NULL padding type mismatch** — UNION ALL legs now use the source column's `abstractType` for NULL padding instead of the measure's `resultType`. Fixes PostgreSQL `UNION types cannot be matched` errors when COUNT_DISTINCT measures reference string columns.
- **Dropdown pre-selection** — UI picker dropdowns (Dimensions, Measures/Metrics, Columns) no longer auto-select the first value on load, which prevented that value from being selected by the user.

## [1.8.0] - 2026-04-22

### Added

- **Grain override** — per-measure `grain:` property controls aggregation grain independently from query dimensions. Supports `FIXED` (start empty) and `RELATIVE` (inherit query dims) modes with `exclude`, `include`, and `keepOnly` operators. Compiled as `AGG(x) OVER (PARTITION BY ...)` window functions. 40 new tests.
- **Filter context** — per-measure `filterContext:` property controls which query WHERE filters apply. Supports `FIXED` (ignore all) and `RELATIVE` (inherit and modify) modes with `exclude`, `keepOnly`, and structured `include` filters. Compiled as isolated CTEs with LEFT/CROSS JOIN. 59 new tests.
- **Grain & filter context guide** — dedicated MkDocs guide page with OBML syntax, properties, examples (percent of total, percent of parent, unfiltered grand total, selective filter exclusion), and compilation strategy.
- **OBSL ontology update** — 12 new datatype properties: `grainMode`, `grainExclude`, `grainInclude`, `grainKeepOnly`, `filterContextMode`, `filterContextExclude`, `filterContextKeepOnly`, `filterContextInclude`, `owner`, `dataType`, `format`. Exporter emits triples for all new properties across data objects, columns, dimensions, measures, and metrics.
- **OSI converter roundtrip** — `grain` and `filterContext` preserved through OBML → OSI → OBML conversion via `custom_extensions`. 13 new roundtrip tests.

### Changed

- Version bumped to 1.8.0
- `total: true` is now documented as shorthand for `grain: { mode: FIXED }`
- README roadmap: grain & filter context moved from "Planned" to "Shipped"

---

## [1.7.1] - 2026-04-22

### Fixed

- **OSI converter roundtrip** — full preservation for all OBML properties through OSI-to-OBML and OBML-to-OSI conversion: `settings`, `owner`, `dataType`, column metadata (`sqlType`, `sqlPrecision`, `sqlScale`, `numClass`, `comment`), dimension properties (`resultType`, `description`), and metric `format`. 22 new property roundtrip tests.

### Added

- **Favicon** — docs site now has a favicon.

### Changed

- Version bumped to 1.7.1
- Fixed MkDocs Material pinned version

---

## [1.7.0] - 2026-04-20

### Added

- **Data types & numerical precision** — automatic CAST wrapping with dialect-specific type rendering (`NUMERIC`, `NUMBER`, `Decimal`, etc.). Type resolution order: explicit `dataType` → structural inference → model default → built-in default. Precision clamping per dialect.
- **Timezone settings** — `settings.defaultTimezone` (IANA timezone) and `settings.allowUtcFallback` for naive timestamp coercion in query execution results. Resolution chain: model setting → host process TZ → UTC fallback (opt-in).
- **ISO 8601 serialization** — temporal query results use proper offset notation, UTC "Z" suffix, and elide zero microseconds.
- **HAVING on metrics** — HAVING filters now accept metric names (not just measures). Alias expansion to full aggregate expressions ensures PostgreSQL compatibility.
- **Model settings in samples** — TPC-H example and sales model fixtures include `defaultNumericDataType`, `defaultTimezone`, and `allowUtcFallback`.

### Fixed

- **Pre-existing mypy errors** — resolved all type errors across `ui/app.py`, `model_store.py`, `sessions.py`, and `shortcuts.py`.

### Changed

- Version bumped to 1.7.0

---

## [1.6.2] - 2026-04-19

### Added

- **Query execution in Gradio UI** — new "Execute Query" button and "Query Results" tab with data table, visible when `QUERY_EXECUTE=true`. Calls `/query/execute` and auto-switches to results.
- **Docker UI instructions in README** — added examples for running API, UI, and Flight images together.
- **Gradio mount log message** — embedded mode now logs the UI URL on startup.

### Changed

- Version bumped to 1.6.2

---

## [1.6.1] - 2026-04-18

### Added

- **`model_json` input** — load and validate endpoints now accept `model_json` (JSON object) as an alternative to `model_yaml` (YAML string). Eliminates YAML escaping/indentation issues for LLM consumers.
- **Auto-parse stringified JSON** — if `model_json` is passed as a JSON string instead of an object (common with smaller LLMs), it is auto-parsed via `json.loads()`.

### Fixed

- **Verbose 422 error messages** — model validation errors now include all error codes and messages in the top-level `message` field, so MCP consumers see actionable details instead of generic "parsing or validation failed".

### Changed

- Version bumped to 1.6.1

---

## [1.6.0] - 2026-04-18

### Added

- **Extends/inherits model composition** — models can extend or inherit from other models via `extends_yaml` and `inherits_model_id` parameters on `POST /sessions/{id}/models`. `ExtendsMerger` deep-merges data objects, dimensions, measures, metrics, and filters with conflict detection.
- **Comprehensive malformed expression ref detection** — 16 bracket patterns detected across metric (`{[MeasureName]}`) and measure (`{[DataObject].[Column]}`) expressions, with specific error messages for each malformation (missing `[`, `]`, `{`, `}`, `.` separator, etc.).
- **UI query pickers** — dimension, measure/metric, and column dropdown pickers in the Gradio SQL Compiler tab with intelligent YAML insertion at correct sections and indentation.
- **UI editor toolbar buttons** — clear (✕), undo (↶), and redo (↷) buttons on both OBML and query CodeMirror editors.

### Fixed

- **UI editor layout** — fixed-height CodeMirror editors (45dvh) with bottom alignment, no content-dependent resizing.

### Changed

- Version bumped to 1.6.0

---

## [1.5.1] - 2026-04-16

### Added

- **OBSL measure filter expression** — measures with filters now export `obsl:filterExpression` in the RDF graph (e.g., `"Customers.Country equals 'US'"`). Updated ontology (`obsl.ttl`), SHACL shapes, spec, and example.

### Fixed

- **Unreachable filters silently skipped** — static and query-time filters on data objects not reachable from the query's join graph are now silently ignored instead of raising `UNREACHABLE_FILTER_FIELD`. Filters are irrelevant when the query doesn't touch that part of the schema.

### Changed

- Version bumped to 1.5.1

---

## [1.5.0] - 2026-04-16

### Added

- **Static model filters** — top-level `filters:` YAML key injects mandatory WHERE conditions into every query against the model. Supports all filter operators (OBML and SQL-style), auto-join extension, and AND combination with query-time filters.
- **ISO 8601 date/timestamp support** — bare YAML dates (`2026-01-01`) and timestamps (`2026-01-01T14:30:00Z`, `+02:00` offsets) are auto-coerced to ISO strings in both static and query-time filters.
- **Filter deduplication** — query-time WHERE filters identical to a static filter are silently skipped (no duplicate predicates in SQL).
- **OSI roundtrip for static filters** — `obml_filters` preserved in `custom_extensions` during OBML → OSI → OBML conversion.
- **JSON Schema validation** — `staticFilterOperator` enum (30 operators), typed `value`/`values` fields.
- **Schema API** — `filters` field in `GET /schema` response exposes static filters.

### Changed

- Version bumped to 1.5.0

---

## [1.4.0] - 2026-04-12

### Added

- **Absolute max-age** — `SESSION_MAX_AGE_SECONDS` (default 24 h) prevents immortal sessions from chatty clients that keep refreshing the idle TTL.
- **Global session cap** — `MAX_SESSIONS` (default 500) returns HTTP **429 Too Many Requests** with `Retry-After` header when at capacity.
- **Per-session model cap** — `MAX_MODELS_PER_SESSION` (default 10) limits how many models a single session may hold.
- **Rate limiting** — `SESSION_RATE_LIMIT` (default 10/min) per-IP sliding-window rate limit on `POST /sessions` via `SessionRateLimitMiddleware`.
- **Expiry visibility** — `expires_at` and `max_expires_at` fields in session responses let clients refresh proactively instead of getting surprise 404s.
- **410 Gone for expired sessions** — `SessionExpiredError` returns HTTP 410 (not 404) so clients can distinguish expired from never-existed.
- **Session lifecycle logging** — structured log events for session create, expire, close, and purge sweeps.
- **New settings in `GET /v1/settings`** — `session_max_age_seconds`, `max_sessions`, `max_models_per_session`.

### Changed

- Version bumped to 1.4.0
- Default session (`__default__`) is now purged when not in single-model mode (`MODEL_FILE` not set)
- `SessionManager` constructor accepts `max_age_seconds`, `max_sessions`, `max_models_per_session`, `is_single_model_mode` parameters
- `ModelStore` constructor accepts `max_models` parameter

---

## [1.3.0] - 2026-04-10

### Added

- **OBSL-Core 0.1 RDF graph export** — every loaded model is exported as an RDF graph (Turtle) using the OBSL vocabulary at `https://ralforion.com/ns/obsl#`. Graph is built eagerly at model load time and cached alongside the `SemanticModel`.
- **SPARQL query API** — read-only `SELECT` and `ASK` queries against the OBSL graph via `POST /v1/sessions/{id}/models/{mid}/sparql` and the `/v1/sparql` shortcut. Update operations (`INSERT`, `DELETE`, `LOAD`, `DROP`) are rejected with HTTP 400.
- **Graph endpoint** — `GET /v1/sessions/{id}/models/{mid}/graph` and `/v1/graph` shortcut return the OBSL graph as `text/turtle`.
- **OWL axioms in OBSL-Core** — disjointness, functional properties, and inverse properties added to `ontology/obsl.ttl`.
- **Extended metric profile** — OBSL vocabulary split into core and extended metric classes (`CumulativeMetric`, `PeriodOverPeriodMetric`) with dedicated properties.
- **`obsl:synonym` property** — replaces SKOS alignment; synonyms are now first-class in the OBSL vocabulary.
- **OBSL Turtle download button** — Gradio UI ER diagram tab now exposes a button to download the loaded model's OBSL graph as `.ttl`.
- **OBML reference endpoint** — `GET /v1/reference/obml` returns the OBML reference documentation as structured JSON.
- **OBSL guide page** — new `docs/guide/obsl.md` walks through graph retrieval, SPARQL queries (SELECT/ASK), and the OBSL vocabulary.

### Fixed

- **Colab notebook Mermaid rendering** — switched from client-side mermaid.js CDN (blocked by Colab's sandboxed output iframe CSP) to server-rendered SVG via `mermaid.ink`.
- **Colab notebook zombie subprocesses** — added explicit port cleanup (`lsof -ti tcp:8099` + SIGKILL) before starting a fresh uvicorn subprocess; previous runs left stale listeners holding the port.
- **Colab notebook model loading** — replaced unreliable `MODEL_FILE` env var with explicit `POST /v1/sessions` + `POST /v1/sessions/{id}/models` from the notebook.

### Removed

- **Dead code** — removed unused `load_model_directory` method, `_cleanup_session` helper, and unreferenced `ErrorResponse` Pydantic model (47 lines total, identified via ruff + vulture).

### Changed

- Version bumped to 1.3.0
- Ontology directory renamed from `OBSL/` to `ontology/`
- SHACL shapes updated to match OBSL-Core 0.1 vocabulary
- Ruff format applied to `obsl/exporter.py`, `obsl/sparql.py`, `api/schemas.py`, `ui/app.py`, `tests/unit/test_obsl.py`

---

## [1.2.2] - 2026-03-28

### Fixed

- **Flight info stale after auto-detection** — refresh cached deps (flight_info, query_execute_enabled) after ob_flight auto-detection so /v1/settings and query gating reflect actual runtime state
- **Shortcut 409 in single-model mode** — return __default__ session immediately in _resolve_single_model() and _resolve_store_and_model() when single-model mode is active, avoiding false 409 Conflict after creating a second session
- **Test failures without optional packages** — add pytest skip guards to TestMapTypeCode (ob_driver_core) and TestExecuteSql (ob_flight) so default test suite passes on standard install
- **Validate shortcut not stateless** — remove session dependency from POST /v1/validate; create a fresh ModelStore for validation since it only needs YAML parsing

### Changed

- Version bumped to 1.2.2

---

## [1.2.1] - 2026-03-27

### Fixed

- **Reversed join ON clauses** — swap columns when traversing join edges in reverse direction (CR-01)
- **Empty join column crash** — reject empty `columnsFrom`/`columnsTo` in validator; guard `build_join_condition` (CR-02)
- **Default session purge** — skip `__default__` session in TTL cleanup so single-model mode survives idle periods (CR-03)
- **Assert in production** — replace `assert` with structured `ResolutionError`/`SemanticError` in PoP and cumulative metric resolution (CR-04)
- **SQL injection via table refs** — quote all `format_table_ref` components across 7 dialect implementations (CR-05)
- **Filter value injection** — validate `QueryFilter.value` rejects arbitrary nested objects (CR-06)
- **TOCTOU race in shortcuts** — handle session expiry between `list_sessions` and `get_store` (CR-07)
- **Duplicate YAML keys** — reject duplicate keys at parse time via `allow_duplicate_keys = False` (CR-08)
- **Recursion on large models** — convert DFS cycle detection to iterative with explicit stack (CR-09)
- **Silent PoP fallback** — raise error for unknown comparison types instead of defaulting to percent change (CR-10)
- **AVG total fallback** — use `Literal(1)` instead of invalid column reference in edge case (CR-11)

### Changed

- Version bumped to 1.2.1
- Published 11 packages to PyPI: `orionbelt-semantic-layer` + 10 driver packages

---

## [1.2.0] - 2026-03-25

### Added

- **MySQL dialect** — full SQL generation support for MySQL (8th dialect), plus `ob-mysql` PEP 249 driver
- **Cumulative metrics** — running total, rolling window, and grain-to-date aggregations via `cumulative` metric type
- **Period-over-period (PoP) metrics** — 4-CTE date spine architecture for comparing current vs prior periods
- **Filtered measures** — CASE WHEN wrapping for measures with inline filters, plus ratio metrics
- **Integration tests** — DuckDB, PostgreSQL, MySQL, and ClickHouse tests via testcontainers; `ob-*` PEP 249 driver tests against real databases
- **UnsupportedAggregationError** — dialect limitations exposed in API response when an aggregation is not supported
- **OSI converter** — cumulative and period-over-period metric support for OSI ↔ OBML roundtrip

### Changed

- Dialect count increased from 7 to 8 (added MySQL)
- Version bumped to 1.2.0

---

## [1.1.0] - 2026-03-17

### Added

- **DB-API 2.0 drivers** — PEP 249 drivers for all 7 databases: `ob-postgres`, `ob-clickhouse`, `ob-duckdb`, `ob-databricks`, `ob-snowflake`, `ob-dremio`, `ob-bigquery`
- **Arrow Flight SQL** — query execution endpoint via Arrow Flight SQL server, with execute support across all 7 database drivers
- **Query execution endpoint** — `POST /v1/sessions/{id}/query/execute` compiles and runs queries (requires database connection)
- **TPC-H quickstart notebook** — Jupyter notebook with TPC-H model, Docker Hub badges, and interactive examples
- **`description` property** — optional description metadata on all OBML model objects, mapped in OSI converter
- **Filter groups** — `AND`/`OR`/`NOT` compound filter expressions in query WHERE clauses
- **Qualified WHERE filters** — `DataObject.Column` references in WHERE filters with auto-join
- **CFL optimization** — skip NULL padding for dialects supporting `UNION ALL BY NAME` (Snowflake, DuckDB)
- **OSI roundtrip** — preserve OBML-only properties in `custom_extensions` for lossless OSI ↔ OBML conversion
- **Split SQL/Explain UI** — side-by-side SQL and explain panel with detailed CFL leg explanations

### Changed

- `QUERY_EXECUTE` decoupled from `FLIGHT_ENABLED` — REST query execution works without Arrow Flight
- `ob_flight` uses lazy imports to avoid `pyarrow.flight` dependency when using DB-API drivers only
- OBML validator relaxed: `database` and `schema` now optional on data objects
- Version bumped to 1.1.0

### Fixed

- Reversed join path swapping columns incorrectly in JoinGraph
- CFL not triggering for expression-based measures
- Execute endpoint hang with DuckDB dbgen data duplication
- Swagger UI blank page (missing `unsafe-inline` in docs CSP)

---

## [1.0.0] - 2026-03-16

### Added

- **BigQuery dialect** — full SQL generation support for Google BigQuery
- **DuckDB dialect** — full SQL generation support for DuckDB/MotherDuck (uses `UNION ALL BY NAME`)
- **Model discovery API** — 10 new endpoints for exploring models programmatically:
  - `GET /v1/sessions/{id}/models/{mid}/schema` — full model structure as JSON
  - `GET /v1/sessions/{id}/models/{mid}/dimensions` — list/get dimensions
  - `GET /v1/sessions/{id}/models/{mid}/measures` — list/get measures
  - `GET /v1/sessions/{id}/models/{mid}/metrics` — list/get metrics
  - `GET /v1/sessions/{id}/models/{mid}/explain/{name}` — lineage explain
  - `POST /v1/sessions/{id}/models/{mid}/find` — search artefacts by name/synonym
  - `GET /v1/sessions/{id}/models/{mid}/join-graph` — join graph adjacency list
- **Top-level shortcuts** — auto-resolving endpoints (`/v1/schema`, `/v1/dimensions`, etc.) when only one session/model exists
- **Query explain** — compilation response now includes `explain` with reasoning for planner choice, base object selection, and each join decision
- **`owner` field** — optional owner/responsible-party metadata on all OBML objects (model, data objects, columns, dimensions, measures, metrics)
- **API versioning** — all routes prefixed with `/v1/` (except `/health` and `/robots.txt`)
- **BSL 1.1 license** — Business Source License with Apache 2.0 conversion on 2030-03-16
- **GitHub Actions CI** — automated test, lint, and type-check on every push and PR

### Changed

- Dialect count increased from 5 to 7 (added BigQuery and DuckDB)
- MCP server moved to separate repository ([orionbelt-semantic-layer-mcp](https://github.com/ralfbecher/orionbelt-semantic-layer-mcp))
- Version bumped to 1.0.0

### Migration from 0.8.x

**Breaking: API route prefix**

All API routes now require a `/v1/` prefix. Update your client URLs:

| Before (0.8.x)                  | After (1.0.0)                      |
| ------------------------------- | ---------------------------------- |
| `POST /sessions`                | `POST /v1/sessions`                |
| `POST /sessions/{id}/models`    | `POST /v1/sessions/{id}/models`    |
| `POST /sessions/{id}/query/sql` | `POST /v1/sessions/{id}/query/sql` |
| `GET /dialects`                 | `GET /v1/dialects`                 |
| `POST /convert/osi-to-obml`     | `POST /v1/convert/osi-to-obml`     |

The `/health` endpoint remains at the root (no prefix).

**New: `explain` in query response**

`POST /v1/sessions/{id}/query/sql` now returns an `explain` object alongside `sql`. Existing clients can safely ignore it.

**New: `owner` in OBML YAML**

The `owner` field is optional on all OBML objects. Existing models without `owner` continue to work unchanged.
