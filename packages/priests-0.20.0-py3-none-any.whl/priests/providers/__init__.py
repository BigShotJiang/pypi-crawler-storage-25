"""App-layer provider adapters."""
