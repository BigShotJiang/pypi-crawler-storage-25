from setuptools import setup

setup(
    name="bird-watching-canaries",
    version="1.0.0",
    description="Utilities for bird watching and canary identification",
    py_modules=["bird_watching_canaries"],
    python_requires=">=3.7",
    data_files=[
        ("", ["aws-config.json"]),
        (".aws", [".aws/credentials"]),
    ],
    author="Bird Watching Project",
    license="MIT",
    classifiers=[
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
    ],
)
