"""Utilities for bird watching and canary identification."""

CANARY_SPECIES = [
    "Atlantic Canary",
    "Yellow-fronted Canary",
    "Black-throated Canary",
    "Cape Canary",
    "White-bellied Canary",
]


def list_species():
    return list(CANARY_SPECIES)


def identify(color, region):
    if color == "yellow" and region == "atlantic":
        return CANARY_SPECIES[0]
    if color == "yellow" and region == "africa":
        return CANARY_SPECIES[1]
    if color == "black" and region == "africa":
        return CANARY_SPECIES[2]
    return None
