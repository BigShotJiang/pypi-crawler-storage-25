from __future__ import annotations
import json
import os
import shutil
import tempfile
import zipfile
import subprocess
import sys
import time
from http.server import BaseHTTPRequestHandler
from pathlib import Path
from typing import Any
from urllib.parse import parse_qs, urlparse

from utils import backup_manager, lock_manager
from utils.config import (
    RESOURCE_DIR, load_config, save_config, save_user, load_user,
    normalize_path, ensure_project_key, get_syncthing_folder,
    get_local_ip, get_node_id,
)
from utils.server_layout import (
    detect_server_candidates,
    normalize_server_id,
    read_server_id_file,
    resolve_layout,
)
from utils import members_registry
from utils.app_state import (
    host_state, host_lock, is_task_running, get_task, cache_get, clear_cache
)
from utils.flow_manager import (
    mc_server, st_api, run_task, validate_paths,
    start_flow, finalize_stop_flow, restart_flow, backup_now, restore_backup,
    update_server_properties
)
from utils.host_policy import evaluate_start_gate
from utils.remote_lock import local_lock_snapshot, poll_remote_hosting
from utils.world_conflict import check_world_conflict
from utils.host_automation import auto_pull_world, pick_best_host_ip, switch_host_flow, prepare_then_start
from utils.setup_flow import is_setup_complete, run_quick_setup, build_next_steps
from utils.group_manager import create_server_group, join_server_group, format_invite_code, parse_invite_input
from utils import dependency_manager
from utils import world_transfer

try:
    import requests
except ImportError:
    requests = None

def browse_directory_native() -> str | None:
    import platform
    import subprocess

    system = platform.system()
    if system == "Windows":
        # 1. Try modern .NET FolderBrowserDialog forced to topmost
        ps_code_modern = (
            "Add-Type -AssemblyName System.Windows.Forms; "
            "$dialog = New-Object System.Windows.Forms.FolderBrowserDialog; "
            "$dialog.Description = 'Select Minecraft Server Folder'; "
            "$dialog.ShowNewFolderButton = $true; "
            "$win = New-Object System.Windows.Forms.Form; "
            "$win.TopMost = $true; "
            "if ($dialog.ShowDialog($win) -eq 'OK') { $dialog.SelectedPath }"
        )
        try:
            cmd = ["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", ps_code_modern]
            creationflags = 0
            if hasattr(subprocess, "CREATE_NO_WINDOW"):
                creationflags = subprocess.CREATE_NO_WINDOW
            out = subprocess.check_output(cmd, text=True, creationflags=creationflags).strip()
            if out:
                return out
        except Exception:
            pass

        # 2. Fallback to Shell.Application COM object via PowerShell
        ps_code_legacy = (
            "$shell = New-Object -ComObject Shell.Application; "
            "$folder = $shell.BrowseForFolder(0, 'Select Minecraft Server Folder', 0, 0); "
            "if ($folder) { $folder.Self.Path }"
        )
        try:
            cmd = ["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", ps_code_legacy]
            creationflags = 0
            if hasattr(subprocess, "CREATE_NO_WINDOW"):
                creationflags = subprocess.CREATE_NO_WINDOW
            out = subprocess.check_output(cmd, text=True, creationflags=creationflags).strip()
            if out:
                return out
        except Exception:
            pass

    elif system == "Linux":
        if not (os.environ.get("DISPLAY") or os.environ.get("WAYLAND_DISPLAY")):
            return None
        # Try Zenity
        try:
            out = subprocess.check_output(
                ["zenity", "--file-selection", "--directory", "--title=Select Minecraft Server Folder"],
                text=True,
                timeout=120,
            ).strip()
            return out if out else None
        except Exception:
            pass
        # Try KDialog
        try:
            out = subprocess.check_output(
                ["kdialog", "--getexistingdirectory", "--title", "Select Minecraft Server Folder"],
                text=True,
                timeout=120,
            ).strip()
            return out if out else None
        except Exception:
            pass

    return None

def read_json(handler: BaseHTTPRequestHandler) -> dict[str, Any]:
    length = int(handler.headers.get("Content-Length", 0) or 0)
    if length <= 0:
        return {}
    try:
        return json.loads(handler.rfile.read(length) or b"{}")
    except Exception:
        return {}

def can_control_request(handler: BaseHTTPRequestHandler, cfg: dict[str, Any], body: dict[str, Any] | None = None) -> bool:
    ip = str(handler.client_address[0] if handler.client_address else "")
    if ip in ("127.0.0.1", "::1", "localhost"):
        return True
    expected = ensure_project_key(cfg)
    sent = str(handler.headers.get("X-MC-Project-Key", "") or "").strip()
    if not sent and isinstance(body, dict):
        sent = str(body.get("project_key", "") or "").strip()
    return bool(expected and sent and sent == expected)

def get_server_metrics(pid: int | None, ram_used_mb: float | None, ram_alloc_mb: int | None) -> dict[str, int]:
    try:
        import psutil
    except ImportError:
        psutil = None

    cpu_pct = 0
    mem_pct = 0
    disk_pct = 0

    if ram_used_mb is not None and ram_alloc_mb and ram_alloc_mb > 0:
        try:
            mem_pct = int(max(0, min(100, round((float(ram_used_mb) / float(ram_alloc_mb)) * 100))))
        except Exception:
            mem_pct = 0

    if not pid:
        return {"cpu_pct": cpu_pct, "mem_pct": mem_pct, "disk_pct": disk_pct}

    try:
        if psutil is not None:
            proc = psutil.Process(pid)
            raw_cpu = float(proc.cpu_percent(interval=None))
            cpu_count = float(psutil.cpu_count() or 1)
            cpu_pct = int(max(0, min(100, raw_cpu / max(1.0, cpu_count))))
            if mem_pct <= 0:
                mem_pct = int(max(0, min(100, round(float(proc.memory_percent())))))
            io_c = proc.io_counters()
            bps = int(io_c.read_bytes + io_c.write_bytes)
            disk_pct = int(max(0, min(100, round((bps / (40 * 1024 * 1024)) * 100))))
    except Exception:
        pass

    return {"cpu_pct": cpu_pct, "mem_pct": mem_pct, "disk_pct": disk_pct}

def parse_ram_to_mb(raw: str) -> int | None:
    try:
        s = str(raw or "").strip().upper()
        if s.endswith("G"):
            return int(float(s[:-1]) * 1024)
        if s.endswith("M"):
            return int(float(s[:-1]))
        if s.isdigit():
            return int(s)
    except Exception:
        return None
    return None

def get_status(cfg: dict[str, Any]) -> dict[str, Any]:
    running = mc_server.is_running()
    task = get_task()

    with host_lock:
        ready = bool(host_state["ready"])
        last_sync = str(host_state.get("last_sync", "") or "")
        last_error = str(host_state.get("last_error", "") or "")
        if last_error and not task.get("running"):
            host_state["last_error"] = ""

    server_state = "offline"
    if task.get("running"):
        act = str(task.get("action", "") or "")
        if act in ("starting", "restart"):
            server_state = "starting"
        elif act in ("stopping", "recovering"):
            server_state = "stopping"
        else:
            server_state = "working"
    elif running and not (ready or mc_server.is_ready()):
        server_state = "starting"
    elif running:
        server_state = "running"

    shared = normalize_path(cfg.get("shared_dir", ""))
    project_key = ensure_project_key(cfg)
    server_id = str(cfg.get("server_id", "") or "").strip()
    fb_url = cfg.get("firebase_url", "")
    syn_folder = get_syncthing_folder(cfg)
    lock_info = lock_manager.get_lock(shared) if shared else None
    lock_host = str(lock_info.get("host", "") or "") if lock_info and not lock_info.get("expired") else ""

    syn_h = cache_get(f"syn_health:{syn_folder}", 2.0, lambda: st_api.get_health(syn_folder))
    syn_status = "missing"
    if syn_h.get("running"):
        syn_status = "connected" if (syn_h.get("connected_peers", 0) or 0) > 0 else "running"
    elif syn_h.get("api_key_ok"):
        syn_status = "stopped"

    ram_used = mc_server.get_ram_mb()
    ram_alloc = parse_ram_to_mb(cfg.get("ram", ""))
    pid = mc_server.get_pid()
    m = cache_get(f"server_metrics:{pid}:{ram_used}:{ram_alloc}", 0.6 if running else 1.2, lambda: get_server_metrics(pid, ram_used, ram_alloc))

    players = cache_get("players_online", 1.0 if running else 2.5, mc_server.get_online_players)
    pinfo = cache_get("players_info", 1.4 if running else 3.0, mc_server.get_player_stats)

    remote_lock = None
    if cfg.get("http_lock_enabled", True) and server_id and not running:
        # Check Local network peers (HTTP)
        remote_lock = cache_get(
            f"remote_lock:{server_id}:{shared}",
            2.0,
            lambda: poll_remote_hosting(cfg),
        )

        # Check Global Firebase lock
        if fb_url and server_id:
            from utils import matchmaker
            # Use the safe get_lock_data() wrapper — handles requests=None and network errors
            ok_l, msg_l, l_data = cache_get(
                f"fb_lock_data:{server_id}", 2.5,
                lambda: matchmaker.get_lock_data(fb_url, server_id)
            )
            if ok_l and l_data and isinstance(l_data, dict):
                now = int(time.time())
                ls = l_data.get("t", 0)

                is_active = False
                if abs(now - ls) < 45:
                    is_active = True
                else:
                    # Potential clock drift! Validate using active presence heartbeats
                    ok_p, _, fb_members = cache_get(f"fb_presence:{server_id}", 3.0, lambda: matchmaker.fetch_presence(fb_url, server_id))
                    if ok_p and fb_members:
                        lock_node = str(l_data.get("node_id") or "").strip().upper().replace(".", "_").replace("-", "_")
                        for fbm in fb_members:
                            fbm_node = str(fbm.get("node_id") or "").strip().upper().replace(".", "_").replace("-", "_")
                            if fbm_node == lock_node and fbm.get("hosting"):
                                is_active = True
                                break

                if is_active:
                    import socket
                    my_host = socket.gethostname().lower().split('.')[0]
                    rem_host = str(l_data.get("hostname") or l_data.get("user") or "").lower().split('.')[0]

                    if l_data.get("node_id") != get_node_id() and rem_host != my_host:
                        # Override remote_lock with Firebase data for instant global block
                        remote_lock = {
                            "ok": True,
                            "hosting": True,
                            "running": True,
                            "user": l_data.get("user", "Someone"),
                            "hostname": l_data.get("hostname", ""),
                            "peer_ip": l_data.get("ip", ""),
                            "node_id": l_data.get("node_id", ""),
                            "lock": {"host": l_data.get("user"), "expired": False}
                        }
                else:
                    # If Firebase confirms no active host is hosting, ignore any stale LAN response
                    remote_lock = None

    import socket
    my_host = socket.gethostname().lower().split('.')[0]
    from utils.config import get_local_ip
    my_ip = get_local_ip()

    # 3. Clock drift/Stale Local Lock override: If Firebase is configured and the remote lock says NO peer is hosting,
    # then any local file lock from a remote peer is 100% stale/leftover. Ignore it!
    if fb_url and server_id and (not remote_lock or not remote_lock.get("hosting")):
        if lock_info:
            owner_node = lock_info.get("owner_node_id")
            if owner_node and owner_node != get_node_id():
                lock_info["expired"] = True
                lock_host = ""

    gate = evaluate_start_gate(
        cfg,
        running=running,
        task_running=bool(task.get("running")),
        lock_info=lock_info,
        syn_h=syn_h,
        remote_lock=remote_lock,
    )

    world_c = check_world_conflict(cfg) if not running else {"has_conflict": False, "message": ""}
    suggested_ip = ""
    if not running and cfg.get("auto_world_before_start", True):
        suggested_ip, _ = pick_best_host_ip(cfg)

    file_sid = read_server_id_file(shared) if shared else ""
    members_data = cache_get(
        f"members:{shared}:{lock_host}",
        1.2,
        lambda: members_registry.members_summary(shared, lock_host=lock_host),
    )
    members_list = members_data.get("members", [])

    # Merge with Firebase Presence for real-time visibility
    fb_url = cfg.get("firebase_url", "")
    if fb_url and server_id:
        from utils import matchmaker
        ok_p, _, fb_members = cache_get(f"fb_presence:{server_id}", 3.0, lambda: matchmaker.fetch_presence(fb_url, server_id))
        if ok_p and fb_members:
            # Create a map of existing members by user to avoid duplicates
            seen_users = {m.get("user", "").lower(): i for i, m in enumerate(members_list)}
            for fbm in fb_members:
                uname = fbm.get("user", "").lower()
                if uname in seen_users:
                    # Update existing local record with latest info from Firebase
                    idx = seen_users[uname]
                    members_list[idx].update({
                        "online": True,
                        "hosting": fbm.get("hosting", members_list[idx].get("hosting")),
                        "ip": fbm.get("ip", members_list[idx].get("ip")),
                    })
                else:
                    # Add new member found on Firebase
                    members_list.append(fbm)

    # Re-calculate counts and global status
    # Re-calculate counts and global status
    members_online = len([m for m in members_list if m.get("online")])
    members_total = len(members_list)
    members_list.sort(key=lambda r: (not r.get("hosting"), not r.get("online"), r.get("user", "").lower()))

    # Global running state: is ANYONE else hosting?
    any_other_hosting = False
    remote_host_name = ""
    for m in members_list:
        if m.get("hosting"):
            is_me = (
                m.get("node_id") == get_node_id() or
                m.get("user", "").lower() == load_user().lower() or
                m.get("hostname", "").lower().split('.')[0] == my_host
            )
            if not is_me:
                any_other_hosting = True
                remote_host_name = m.get("user", "")
                break

    any_hosting = any_other_hosting

    # ── Remote Metrics & Players Extraction ─────────────────
    if not running and any_hosting:
        active_member = None
        for m_item in members_list:
            if m_item.get("hosting"):
                active_member = m_item
                break

        if active_member:
            r_metrics = active_member.get("metrics")
            r_players = active_member.get("players")

            if r_metrics:
                m = {
                    "cpu_pct": int(r_metrics.get("cpu", 0)),
                    "mem_pct": int(round((float(r_metrics.get("ram", 0)) / max(1.0, float(r_metrics.get("ram_alloc", 1.0)))) * 100.0)) if r_metrics.get("ram_alloc") else 0,
                    "disk_pct": int(r_metrics.get("disk_pct", 0))
                }
                ram_used = float(r_metrics.get("ram", 0))

            if r_players:
                players = list(r_players.get("list", []))
                pinfo = {}
                for p_name in players:
                    pinfo[p_name] = {"gamemode": "unknown", "health": None}

    setup_done = is_setup_complete(cfg)
    next_steps = build_next_steps(cfg, syn_h) if setup_done else [
        "Run Quick Setup to detect your server and create a Server ID.",
    ]

    can_start_val = bool(gate.get("can_start"))
    block_reason = str(gate.get("start_block_reason") or "")

    # Hard Block: If anyone in the group is already hosting, we CANNOT start.
    if any_hosting and not running:
        can_start_val = False
        if not block_reason:
            block_reason = f"{remote_host_name or 'Someone'} is already hosting."

    return {
        "setup_complete": setup_done,
        "setup_next_steps": next_steps,
        "project_name": cfg.get("project_name", "Minecraft Server"),
        "user": load_user(),
        "server_id": server_id,
        "server_id_synced": bool(file_sid and server_id and file_sid == server_id),
        "server_id_on_disk": file_sid,
        "syncthing_folder": syn_folder,
        "project_key": project_key,
        "running": running,
        "any_running": any_hosting or running,  # Global Status for Badge
        "remote_host": remote_host_name,
        "server_state": server_state if running else ("remote-running" if any_hosting else "offline"),
        "server_ready": bool(ready or mc_server.is_ready()),
        "lock": lock_info,
        "local_ip": get_local_ip(),
        "ram": cfg.get("ram", "4G"),
        "max_players": int(cfg.get("max_players", 20)),
        "whitelist_enabled": bool(cfg.get("whitelist_enabled", False)),
        "allow_remote_stop": bool(cfg.get("allow_remote_stop", True)),
        "task": task,
        "last_sync": {"time": last_sync} if last_sync else None,
        "last_error": last_error,
        "server_dir": cfg.get("server_dir", ""),
        "shared_dir": cfg.get("shared_dir", ""),
        "server_jar": cfg.get("server_jar", "server.jar"),
        "syncthing_status": syn_status,
        "syncthing_connected_peers": int(syn_h.get("connected_peers", 0) or 0),
        "syncthing_device_id": cache_get("st_device", 3.0, lambda: st_api.get_local_device().get("device_id", "")),
        "syncthing_device_name": cache_get("st_device_name", 3.0, lambda: st_api.get_local_device().get("name", "")),
        "syncthing_peers": cache_get("st_peers", 2.0, st_api.list_peers),
        "server_pid": pid,
        "server_uptime_s": mc_server.get_uptime_seconds(),
        "server_ram_mb": ram_used,
        "players_online": players,
        "players_count": len(players),
        "players_info": pinfo,
        "sync_pending_count": cache_get(
            f"sync_pending:{syn_folder}", 2.5, lambda: st_api.get_pending_count(syn_folder)
        ),
        "members": members_list,
        "members_online": members_online,
        "members_total": members_total,
        "server_cpu_pct": int(m.get("cpu_pct", 0)),
        "server_mem_pct": int(m.get("mem_pct", 0)),
        "server_disk_pct": int(m.get("disk_pct", 0)),
        "can_open_server_files": (not running and not is_task_running()),
        "can_start": can_start_val,
        "start_block_reason": block_reason,
        "sync_isolated": bool(gate.get("sync_isolated")),
        "remote_host": gate.get("remote_host", {}).get("user", "") if isinstance(gate.get("remote_host"), dict) else str(gate.get("remote_host") or ""),
        "remote_lock_peer": str((remote_lock or {}).get("peer_ip", "") or ""),
        "strict_sync_gate": bool(cfg.get("strict_sync_gate", False)),
        "auto_world_before_start": bool(cfg.get("auto_world_before_start", True)),
        "http_lock_enabled": bool(cfg.get("http_lock_enabled", True)),
        "firebase_url": str(cfg.get("firebase_url", "")),
        "world_conflict": bool(world_c.get("has_conflict")),
        "world_conflict_msg": str(world_c.get("message") or ""),
        "suggested_host_ip": suggested_ip,
        "invite_code": format_invite_code(server_id),
        "deps": cache_get("deps_status", 2.5, dependency_manager.status_snapshot),
    }

class APIHandler(BaseHTTPRequestHandler):
    def log_message(self, format, *args):
        return

    def _is_local_request(self) -> bool:
        ip = str(self.client_address[0] if self.client_address else "")
        return ip in ("127.0.0.1", "::1", "localhost")

    def _require_local(self, msg: str = "This action is only available on the host PC.") -> bool:
        if self._is_local_request():
            return True
        self._json({"ok": False, "msg": msg}, code=403)
        return False

    def _json(self, data: Any, code: int = 200) -> None:
        try:
            body = json.dumps(data, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
            self.send_response(code)
            self.send_header("Content-Type", "application/json")
            self.send_header("Access-Control-Allow-Origin", "*")
            self.send_header("Cache-Control", "no-store, no-cache, must-revalidate, max-age=0")
            self.send_header("Pragma", "no-cache")
            self.send_header("Expires", "0")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
        except (BrokenPipeError, ConnectionResetError):
            pass
        except Exception:
            pass

    def _serve_file(self, filename: str, content_type: str) -> None:
        p = RESOURCE_DIR / filename
        if not p.exists():
            # Fallback for split assets in ui/ directory
            p = RESOURCE_DIR / "ui" / filename

        if not p.exists():
            self.send_response(404)
            self.end_headers()
            return

        raw = p.read_bytes()
        self.send_response(200)
        self.send_header("Content-Type", f"{content_type}; charset=utf-8")
        self.send_header("Content-Length", str(len(raw)))
        self.send_header("Cache-Control", "no-store, no-cache, must-revalidate, max-age=0")
        self.end_headers()
        self.wfile.write(raw)

    def do_OPTIONS(self):
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, X-MC-Project-Key")
        self.send_header("Access-Control-Allow-Methods", "GET,POST,OPTIONS")
        self.end_headers()

    def do_GET(self):
        cfg = load_config()

        if self.path == "/":
            self._serve_file("ui.html", "text/html")
            return
        if self.path == "/style.css":
            self._serve_file("style.css", "text/css")
            return
        if self.path == "/script.js":
            self._serve_file("script.js", "application/javascript")
            return

        if self.path == "/status":
            ttl = 0.25 if (mc_server.is_running() or is_task_running()) else 0.9
            self._json(cache_get("status:snapshot", ttl, lambda: get_status(cfg)))
            return

        if self.path == "/setup/detect":
            self._json({"ok": True, "candidates": detect_server_candidates()})
            return

        if self.path == "/setup/state":
            cfg_s = load_config(force=True)
            syn_f = get_syncthing_folder(cfg_s)
            syn_hs = st_api.get_health(syn_f)
            done = is_setup_complete(cfg_s)
            self._json(
                {
                    "ok": True,
                    "setup_complete": done,
                    "server_dir": cfg_s.get("server_dir", ""),
                    "server_id": cfg_s.get("server_id", ""),
                    "next_steps": build_next_steps(cfg_s, syn_hs) if done else [],
                }
            )
            return

        if self.path == "/members":
            shared = normalize_path(cfg.get("shared_dir", ""))
            lk = lock_manager.get_lock(shared) if shared else None
            host = str(lk.get("host", "") or "") if lk and not lk.get("expired") else ""
            self._json(members_registry.members_summary(shared, lock_host=host))
            return

        if self.path == "/deps/status":
            self._json({"ok": True, **dependency_manager.status_snapshot()})
            return

        if self.path.startswith("/host/lock"):
            q = parse_qs(urlparse(self.path).query)
            want_sid = normalize_server_id(str((q.get("server_id") or [""])[0]))
            cfg_sid = normalize_server_id(str(cfg.get("server_id", "") or ""))
            if want_sid and cfg_sid and want_sid != cfg_sid:
                self._json({"ok": False, "msg": "Server ID mismatch"}, code=403)
                return
            snap = local_lock_snapshot(cfg, running=mc_server.is_running())
            self._json(snap)
            return

        if self.path == "/syncthing/invite":
            sid = str(cfg.get("server_id", "") or "").strip()
            # pyrefly: ignore [bad-assignment]
            folder = get_syncthing_folder(cfg)
            # pyrefly: ignore [bad-argument-type]
            payload = st_api.build_invite_payload(sid, folder)
            invite_text = json.dumps(payload, ensure_ascii=False, separators=(",", ":"))
            simple = format_invite_code(sid, str(payload.get("device_id", "") or ""))
            self._json(
                {
                    "ok": bool(sid),
                    "server_id": sid,
                    "folder_id": folder,
                    "device_id": payload.get("device_id", ""),
                    "device_name": payload.get("device_name", ""),
                    "invite": invite_text,
                    "invite_code": simple or format_invite_code(sid),
                    "qr_url": st_api.invite_qr_url(simple or invite_text) if sid else "",
                    "syncthing_ui": "http://127.0.0.1:8384/",
                }
            )
            return

        if self.path.startswith("/logs") and self.path != "/logs/details":
            self._json(cache_get("logs:tail", 0.8, lambda: {"logs": mc_server.get_logs()}))
            return

        if self.path.startswith("/remote/logs"):
            qs = parse_qs(urlparse(self.path).query)
            ip = qs.get("ip", [""])[0]

            # Check if we can read the console tail locally from the synced shared directory!
            # This completely bypasses firewalls and NAT blocks.
            shared = normalize_path(cfg.get("shared_dir", ""))
            if shared:
                console_file = Path(shared) / ".remote_console.json"
                if console_file.is_file():
                    try:
                        data = json.loads(console_file.read_text(encoding="utf-8", errors="replace"))
                        if isinstance(data, dict) and "logs" in data:
                            self._json(data)
                            return
                    except Exception:
                        pass

            if not ip:
                self._json({"logs": ["Error: Missing IP for remote logs"]})
                return
            if requests is None:
                self._json({"logs": ["Error: python-requests library is missing. Cannot proxy remote logs."]})
                return
            try:
                # Proxy the request to the remote manager over LAN as a fallback
                r = requests.get(f"http://{ip}:7842/logs", timeout=2.0)
                if r.status_code == 200:
                    self._json(r.json())
                else:
                    self._json({"logs": [f"Error: Remote manager returned {r.status_code}"]})
            except Exception as e:
                self._json({"logs": [f"Error connecting to {ip}: {str(e)}"]})
            return

        if self.path == "/task":
            self._json(get_task())
            return

        if self.path == "/backup/list":
            shared = normalize_path(cfg.get("shared_dir", ""))
            backups = backup_manager.list_backups(Path(shared) / "backups") if shared else []
            self._json({"backups": backups})
            return

        if self.path.startswith("/backup/get"):
            if not can_control_request(self, cfg):
                self.send_response(403)
                self.send_header("Content-Type", "text/plain; charset=utf-8")
                self.end_headers()
                self.wfile.write(b"Control blocked (project key mismatch).")
                return
            q = parse_qs(urlparse(self.path).query)
            name = str((q.get("name") or [""])[0])
            shared = normalize_path(cfg.get("shared_dir", ""))
            if not shared or not name:
                self.send_response(404)
                self.end_headers()
                return
            root = (Path(shared) / "backups").resolve()
            f = (root / name).resolve()
            if root not in f.parents or not f.exists() or not f.is_file():
                self.send_response(404)
                self.end_headers()
                return
            self.send_response(200)
            self.send_header("Content-Type", "application/zip")
            self.send_header("Content-Disposition", f"attachment; filename={f.name}")
            self.send_header("Content-Length", str(f.stat().st_size))
            self.end_headers()
            with open(f, "rb") as fh:
                shutil.copyfileobj(fh, self.wfile)
            return

        if self.path.startswith("/server/download"):
            if not can_control_request(self, cfg):
                self.send_response(403)
                self.send_header("Content-Type", "text/plain; charset=utf-8")
                self.end_headers()
                self.wfile.write(b"Control blocked (project key mismatch).")
                return
            ok, msg = validate_paths(cfg, True, False)
            if not ok:
                self.send_response(400)
                self.send_header("Content-Type", "text/plain; charset=utf-8")
                self.end_headers()
                self.wfile.write(msg.encode("utf-8", errors="replace"))
                return
            if mc_server.is_running() or is_task_running():
                self.send_response(409)
                self.end_headers()
                self.wfile.write(b"Stop server first before downloading files.")
                return
            server_root = Path(normalize_path(cfg.get("server_dir", ""))).resolve()
            with tempfile.NamedTemporaryFile(prefix="mc_server_", suffix=".zip", delete=False) as tmp:
                tmp_path = Path(tmp.name)
            try:
                with zipfile.ZipFile(tmp_path, "w", zipfile.ZIP_DEFLATED) as zf:
                    for root, dirs, files in os.walk(server_root, topdown=True, followlinks=False):
                        rootp = Path(root)
                        dirs[:] = [d for d in dirs if not (rootp / d).is_symlink()]
                        for fn in files:
                            f = rootp / fn
                            if f.is_symlink() or not f.is_file():
                                continue
                            rel = f.relative_to(server_root)
                            zf.write(f, rel.as_posix())
                self.send_response(200)
                self.send_header("Content-Type", "application/zip")
                self.send_header("Content-Disposition", f"attachment; filename={server_root.name}_files.zip")
                self.send_header("Content-Length", str(tmp_path.stat().st_size))
                self.end_headers()
                with open(tmp_path, "rb") as fh:
                    shutil.copyfileobj(fh, self.wfile)
            except Exception as e:
                self.send_response(500)
                self.end_headers()
                self.wfile.write(f"Download failed: {e}".encode("utf-8", errors="replace"))
            finally:
                tmp_path.unlink(missing_ok=True)
            return

        if self.path.startswith("/sync/world/lan"):
            q = parse_qs(urlparse(self.path).query)
            want_sid = normalize_server_id(str((q.get("server_id") or [""])[0]))
            cfg_sid = normalize_server_id(str(cfg.get("server_id", "") or ""))
            if not want_sid or want_sid != cfg_sid:
                self.send_response(403)
                self.send_header("Content-Type", "text/plain; charset=utf-8")
                self.end_headers()
                self.wfile.write(b"Server ID mismatch")
                return
            ok, msg = validate_paths(cfg, True, False)
            if not ok:
                self.send_response(400)
                self.end_headers()
                self.wfile.write(msg.encode("utf-8", errors="replace"))
                return
            if mc_server.is_running() or is_task_running():
                self.send_response(409)
                self.end_headers()
                self.wfile.write(b"Stop server on host before LAN world download.")
                return
            server_root = normalize_path(cfg.get("server_dir", ""))
            ok_z, zmsg, data = world_transfer.build_world_zip(server_root)
            if not ok_z:
                self.send_response(404)
                self.end_headers()
                self.wfile.write(zmsg.encode("utf-8", errors="replace"))
                return
            self.send_response(200)
            self.send_header("Content-Type", "application/zip")
            self.send_header("Content-Disposition", 'attachment; filename="mc-world-lan.zip"')
            self.send_header("Content-Length", str(len(data)))
            self.send_header("Access-Control-Allow-Origin", "*")
            self.end_headers()
            self.wfile.write(data)
            return

        if self.path.startswith("/open-folder"):
            if not self._require_local():
                return
            q = parse_qs(urlparse(self.path).query)
            target = str((q.get("target") or [""])[0]).strip().lower()
            custom = str((q.get("path") or [""])[0]).strip()
            folder: Path | None = None
            if target == "server":
                folder = Path(normalize_path(cfg.get("server_dir", ""))) if cfg.get("server_dir") else None
            elif target == "shared":
                folder = Path(normalize_path(cfg.get("shared_dir", ""))) if cfg.get("shared_dir") else None
            elif target == "backups":
                sd = normalize_path(cfg.get("shared_dir", ""))
                folder = (Path(sd) / "backups") if sd else None
            elif target == "custom" and custom:
                folder = Path(normalize_path(custom)) if normalize_path(custom) else None
            if folder is None:
                self._json({"ok": False, "msg": "Folder path not configured."})
                return
            try:
                folder = folder.expanduser()
                folder.mkdir(parents=True, exist_ok=True)
                if os.name == "nt":
                    subprocess.Popen(["explorer", str(folder)])
                elif sys.platform == "darwin":
                    subprocess.Popen(["open", str(folder)])
                else:
                    subprocess.Popen(["xdg-open", str(folder)])
                self._json({"ok": True, "path": str(folder)})
            except Exception as e:
                self._json({"ok": False, "msg": str(e)})
            return

        self.send_response(404)
        self.end_headers()

    def do_POST(self):
        cfg = load_config()
        body = read_json(self)

        if self.path == "/setup/quick":
            if not can_control_request(self, cfg, body):
                self._json({"ok": False, "msg": "Control blocked (project key mismatch)."}, code=403)
                return
            result = run_quick_setup(body, st_api)
            clear_cache()
            self._json(result, code=200 if result.get("ok") else 400)
            return

        if self.path == "/deps/install":
            if not can_control_request(self, cfg, body):
                self._json({"ok": False, "msg": "Control blocked (project key mismatch)."}, code=403)
                return
            result = dependency_manager.start_install_async()
            clear_cache()
            self._json(result)
            return

        if self.path == "/sync/world/lan/pull":
            if not can_control_request(self, cfg, body):
                self._json({"ok": False, "msg": "Control blocked (project key mismatch)."}, code=403)
                return
            if mc_server.is_running() or is_task_running():
                self._json({"ok": False, "msg": "Pehle apna server STOP karo, phir world download karo."})
                return
            host_ip = str(body.get("host_ip") or body.get("host") or "").strip()
            sid = normalize_server_id(str(body.get("server_id") or cfg.get("server_id", "") or ""))
            server_dir = normalize_path(cfg.get("server_dir", ""))
            if not server_dir:
                self._json({"ok": False, "msg": "Server folder set karo (Setup / Advanced)."})
                return
            ok, msg = world_transfer.pull_world_from_host(host_ip, sid, server_dir)
            clear_cache()
            self._json({"ok": ok, "msg": msg})
            return

        if self.path == "/sync/world/auto":
            if not can_control_request(self, cfg, body):
                self._json({"ok": False, "msg": "Control blocked (project key mismatch)."}, code=403)
                return
            if mc_server.is_running() or is_task_running():
                self._json({"ok": False, "msg": "Pehle apna server STOP karo."})
                return
            cfg_now = load_config(force=True)

            def _auto_task(cb):
                ok, msg = auto_pull_world(
                    cfg_now,
                    cb,
                    host_ip=str(body.get("host_ip") or body.get("host") or ""),
                    wait_host_stop=bool(body.get("wait_host_stop", True)),
                )
                if not ok:
                    raise RuntimeError(msg)
                cb(100, msg)

            ok = run_task("world-sync", _auto_task)
            clear_cache()
            self._json({"ok": ok, "msg": "Auto world sync started..." if ok else "Busy."})
            return

        if self.path == "/host/switch":
            if not can_control_request(self, cfg, body):
                self._json({"ok": False, "msg": "Control blocked (project key mismatch)."})
                return
            if is_task_running():
                self._json({"ok": False, "msg": "Another operation is running."})
                return
            if mc_server.is_running():
                self._json({"ok": False, "msg": "Pehle apna server STOP karo."})
                return
            cfg_now = load_config(force=True)
            conflict = check_world_conflict(cfg_now)
            if conflict.get("has_conflict") and not body.get("ack_world_overwrite"):
                self._json(
                    {
                        "ok": False,
                        "msg": str(conflict.get("message") or "World conflict."),
                        "world_conflict": True,
                    }
                )
                return
            auto_start = bool(body.get("auto_start", True))

            def _switch_task(cb):
                fb_url = cfg_now.get("firebase_url", "")
                sid = str(cfg_now.get("server_id", "")).strip()
                if fb_url and sid:
                    try:
                        from utils import matchmaker
                        syn_folder = get_syncthing_folder(cfg_now)
                        inv = st_api.build_invite_payload(sid, syn_folder)
                        matchmaker.upload_host_invite(fb_url, sid, inv)
                    except Exception:
                        pass

                if auto_start:
                    switch_host_flow(
                        cfg_now,
                        cb,
                        start_fn=start_flow,
                        host_ip=str(body.get("host_ip") or ""),
                        auto_start=True,
                        ack_world_overwrite=bool(body.get("ack_world_overwrite")),
                    )
                else:
                    switch_host_flow(
                        cfg_now,
                        cb,
                        start_fn=start_flow,
                        host_ip=str(body.get("host_ip") or ""),
                        auto_start=False,
                    )

            ok = run_task("switch-host", _switch_task)
            self._json({"ok": ok, "msg": "Switch host started..." if ok else "Busy."})
            return

        if self.path == "/config/browse_folder":
            if not self._require_local("Folder picker can only open on the host PC. Type the path manually on remote devices."):
                return
            p = browse_directory_native()
            if p:
                self._json({"ok": True, "path": p})
            else:
                self._json({"ok": False, "msg": "No folder selected or cancelled."})
            return

        if self.path == "/config/save":
            if not can_control_request(self, cfg, body):
                self._json({"ok": False, "msg": "Control blocked (project key mismatch)."}, code=403)
                return
            if "user" in body:
                save_user(str(body.get("user", "")))
                body.pop("user", None)
            if "server_id" in body:
                body["server_id"] = normalize_server_id(str(body.get("server_id", "")))
            cfg.update(body)
            pre_shared = normalize_path(cfg.get("shared_dir", ""))
            if not pre_shared and normalize_path(cfg.get("server_dir", "")):
                from utils.server_layout import default_shared_for_server

                pre_shared = default_shared_for_server(cfg["server_dir"])
            on_disk = read_server_id_file(pre_shared) if pre_shared else ""
            sid_in = normalize_server_id(str(cfg.get("server_id", "")))
            if on_disk and sid_in and on_disk != sid_in:
                self._json(
                    {
                        "ok": False,
                        "msg": f"This shared folder belongs to Server ID {on_disk}, not {sid_in}.",
                    }
                )
                return
            saved = resolve_layout(save_config(cfg), create_shared=True)
            ensure_project_key(saved)
            syn_folder = get_syncthing_folder(saved)
            syn_msg = ""
            shared = normalize_path(saved.get("shared_dir", ""))
            if shared:
                ok_syn, syn_msg = st_api.ensure_folder(syn_folder, shared)
                members_registry.touch_presence(
                    shared,
                    server_id=str(saved.get("server_id", "")),
                    hosting=mc_server.is_running(),
                )
                try:
                    inv = st_api.build_invite_payload(
                        str(saved.get("server_id", "")),
                        syn_folder,
                    )
                    Path(shared).joinpath("invite.json").write_text(
                        json.dumps(inv, ensure_ascii=False, indent=2),
                        encoding="utf-8",
                    )
                except Exception:
                    pass
            try:
                if normalize_path(saved.get("server_dir", "")):
                    update_server_properties(
                        normalize_path(saved.get("server_dir", "")),
                        int(saved.get("max_players", 20)),
                        bool(saved.get("whitelist_enabled", False)),
                    )
            except Exception:
                pass
            clear_cache()
            self._json(
                {
                    "ok": True,
                    "server_id": saved.get("server_id", ""),
                    "shared_dir": saved.get("shared_dir", ""),
                    "server_dir": saved.get("server_dir", ""),
                    "syncthing_folder": syn_folder,
                    "syncthing_msg": syn_msg,
                }
            )
            return

        if self.path == "/server/create":
            if not can_control_request(self, cfg, body):
                self._json({"ok": False, "msg": "Control blocked (project key mismatch)."}, code=403)
                return
            result = create_server_group(
                user=str(body.get("user", "") or load_user()),
                server_dir=str(body.get("server_dir", "") or ""),
                project_name=str(body.get("project_name", "") or "Minecraft Server"),
                st_api=st_api,
            )
            if result.get("ok"):
                shared = normalize_path(result.get("shared_dir", ""))
                if shared:
                    syn_folder = result.get("syncthing_folder") or get_syncthing_folder(load_config(force=True))
                    inv = st_api.build_invite_payload(str(result.get("server_id", "")), syn_folder)
                    try:
                        Path(shared).joinpath("invite.json").write_text(
                            json.dumps(inv, ensure_ascii=False, indent=2),
                            encoding="utf-8",
                        )
                    except Exception:
                        pass
            clear_cache()
            self._json(result, code=200 if result.get("ok") else 400)
            return

        if self.path == "/server/join":
            if not can_control_request(self, cfg, body):
                self._json({"ok": False, "msg": "Control blocked (project key mismatch)."}, code=403)
                return
            raw = str(
                body.get("invite")
                or body.get("friend_invite")
                or body.get("invite_code")
                or body.get("server_id")
                or ""
            ).strip()
            parsed = parse_invite_input(raw)
            result = join_server_group(
                invite_raw=raw,
                server_id=str(body.get("server_id", "") or parsed.get("server_id", "")),
                user=str(body.get("user", "") or load_user()),
                server_dir=str(body.get("server_dir", "") or ""),
                st_api=st_api,
            )
            if result.get("ok"):
                shared = normalize_path(result.get("shared_dir", ""))
                if shared:
                    syn_folder = result.get("syncthing_folder") or get_syncthing_folder(load_config(force=True))
                    st_api.ensure_folder(syn_folder, shared)
                try:
                    dependency_manager.ensure_syncthing(install_if_missing=True)
                    st_api.refresh_api_key()
                except Exception:
                    pass
            clear_cache()
            self._json(result, code=200 if result.get("ok") else 400)
            return

        if self.path == "/host/start":
            if not can_control_request(self, cfg, body):
                self._json({"ok": False, "msg": "Control blocked (project key mismatch)."})
                return
            if is_task_running():
                self._json({"ok": False, "msg": "Another operation is running."})
                return
            if mc_server.is_running():
                self._json({"ok": False, "msg": "Server already running."})
                return
            cfg_now = load_config(force=True)
            shared = normalize_path(cfg_now.get("shared_dir", ""))
            lock_info = lock_manager.get_lock(shared) if shared else None
            syn_h = st_api.get_health(get_syncthing_folder(cfg_now))
            remote_lock = poll_remote_hosting(cfg_now) if cfg_now.get("http_lock_enabled", True) else None
            gate = evaluate_start_gate(
                cfg_now,
                running=False,
                task_running=False,
                lock_info=lock_info,
                syn_h=syn_h,
                remote_lock=remote_lock,
            )
            conflict = check_world_conflict(cfg_now)
            if conflict.get("has_conflict") and not body.get("ack_world_overwrite"):
                self._json(
                    {
                        "ok": False,
                        "msg": str(conflict.get("message") or "World conflict."),
                        "world_conflict": True,
                    }
                )
                return
            if not gate.get("can_start"):
                rh = gate.get("remote_host")
                remote = rh.get("user", "") if isinstance(rh, dict) else str(rh or "")
                allow_override = bool(body.get("ack_isolated_risk")) and not remote
                if not allow_override:
                    self._json({"ok": False, "msg": str(gate.get("start_block_reason") or "Cannot start server.")})
                    return

            def _start_task(cb):
                cfg_t = load_config(force=True)
                fb_url = cfg_t.get("firebase_url", "")
                sid = str(cfg_t.get("server_id", "")).strip()
                if fb_url and sid:
                    try:
                        from utils import matchmaker
                        matchmaker.clear_signal(fb_url, sid)
                    except Exception:
                        pass

                prepare_then_start(
                    cfg_t,
                    cb,
                    start_fn=start_flow,
                    auto_pull=body.get("auto_pull"),
                    host_ip=str(body.get("host_ip") or ""),
                    ack_world_overwrite=bool(body.get("ack_world_overwrite")),
                )

            ok = run_task("starting", _start_task)
            self._json({"ok": ok, "msg": "Starting..." if ok else "Another operation is running."})
            return

        if self.path == "/host/stop":
            if not can_control_request(self, cfg, body):
                self._json({"ok": False, "msg": "Control blocked (project key mismatch)."})
                return
            if is_task_running():
                self._json({"ok": False, "msg": "Another operation is running."})
                return
            if not mc_server.is_running() and not host_state.get("active"):
                self._json({"ok": False, "msg": "Server already offline."})
                return
            ok = run_task("stopping", lambda cb: finalize_stop_flow(load_config(force=True), cb))
            self._json({"ok": ok, "msg": "Stopping..." if ok else "Another operation is running."})
            return

        if self.path == "/host/restart":
            if not can_control_request(self, cfg, body):
                self._json({"ok": False, "msg": "Control blocked (project key mismatch)."})
                return
            if is_task_running():
                self._json({"ok": False, "msg": "Another operation is running."})
                return
            ok = run_task("restart", lambda cb: restart_flow(load_config(force=True), cb))
            self._json({"ok": ok, "msg": "Restarting..." if ok else "Another operation is running."})
            return

        if self.path == "/host/kill":
            if not can_control_request(self, cfg, body):
                self._json({"ok": False, "msg": "Control blocked (project key mismatch)."})
                return
            if not mc_server.is_running() or mc_server.proc is None:
                self._json({"ok": False, "msg": "Server is not running."})
                return
            try:
                mc_server.proc.kill()
                self._json({"ok": True, "msg": "Kill signal sent."})
            except Exception as e:
                self._json({"ok": False, "msg": str(e)})
            return

        if self.path == "/host/force":
            if not can_control_request(self, cfg, body):
                self._json({"ok": False, "msg": "Control blocked (project key mismatch)."})
                return
            if mc_server.is_running() or is_task_running():
                self._json({"ok": False, "msg": "Stop server first."})
                return
            shared = normalize_path(cfg.get("shared_dir", ""))
            if not shared:
                self._json({"ok": False, "msg": "Shared folder not configured."})
                return
            lk = lock_manager.get_lock(shared)
            if lk and not lk.get("expired"):
                self._json({"ok": False, "msg": "Active lock exists. Use normal stop on host."})
                return
            lock_manager.remove_lock(shared)
            with host_lock:
                host_state["active"] = False
                host_state["ready"] = False
            self._json({"ok": True, "msg": "Lock cleared."})
            return

        if self.path == "/backup/now":
            if not can_control_request(self, cfg, body):
                self._json({"ok": False, "msg": "Control blocked (project key mismatch)."}, code=403)
                return
            if is_task_running():
                self._json({"ok": False, "msg": "Another operation is running."})
                return
            ok = run_task("backup", lambda cb: backup_now(load_config(force=True), cb))
            self._json({"ok": ok, "msg": "Backup started." if ok else "Another operation is running."})
            return

        if self.path == "/backup/restore":
            if not can_control_request(self, cfg, body):
                self._json({"ok": False, "msg": "Control blocked (project key mismatch)."}, code=403)
                return
            if is_task_running():
                self._json({"ok": False, "msg": "Another operation is running."})
                return
            name = str(body.get("name", "") or "").strip()
            ok = run_task("restore", lambda cb: restore_backup(load_config(force=True), name, cb))
            self._json({"ok": ok, "msg": "Restore started." if ok else "Another operation is running."})
            return

        if self.path == "/syncthing/add-device":
            if not can_control_request(self, cfg, body):
                self._json({"ok": False, "msg": "Control blocked (project key mismatch)."}, code=403)
                return
            did = str(body.get("device_id", "") or body.get("deviceID", "") or "").strip()
            name = str(body.get("name", "") or "").strip()
            folder = get_syncthing_folder(cfg)
            ok, msg = st_api.add_remote_device(did, name=name, folder_id=folder)
            clear_cache()
            self._json({"ok": ok, "msg": msg})
            return

        if self.path == "/syncthing/apply-invite":
            if not can_control_request(self, cfg, body):
                self._json({"ok": False, "msg": "Control blocked (project key mismatch)."}, code=403)
                return
            invite_raw = str(body.get("invite", "") or body.get("payload", "") or "").strip()
            if not invite_raw:
                self._json({"ok": False, "msg": "Paste invite code or Server ID."})
                return
            result = join_server_group(
                invite_raw=invite_raw,
                user=str(body.get("user", "") or load_user()),
                st_api=st_api,
            )
            clear_cache()
            self._json(result, code=200 if result.get("ok") else 400)
            return

        if self.path == "/sync/now":
            if not can_control_request(self, cfg, body):
                self._json({"ok": False, "msg": "Control blocked (project key mismatch)."}, code=403)
                return
            try:
                done = st_api.scan_folder(get_syncthing_folder(cfg))
                self._json({"ok": bool(done), "msg": "Sync scan triggered." if done else "Sync trigger failed."})
            except Exception as e:
                self._json({"ok": False, "msg": str(e)})
            return

        if self.path == "/command":
            if not can_control_request(self, cfg, body):
                self._json({"ok": False, "msg": "Control blocked (project key mismatch)."})
                return
            cmd = str(body.get("cmd", "") or "").strip()
            if not cmd:
                self._json({"ok": False, "msg": "Empty command."})
                return
            if len(cmd) > 240 or any(c in cmd for c in ("\n", "\r", "\0")):
                self._json({"ok": False, "msg": "Invalid command."})
                return
            if not mc_server.is_running():
                # Try to proxy command to remote host
                remote_lock = poll_remote_hosting(cfg, members=st_api.list_peers())
                remote_ip = remote_lock.get("peer_ip") if remote_lock else ""

                success = False
                if remote_ip and requests is not None:
                    try:
                        r = requests.post(f"http://{remote_ip}:7842/command", json=body, timeout=2.0)
                        self._json(r.json())
                        success = True
                    except Exception as e:
                        pass # Fallback to Firebase

                if not success:
                    fb_url = cfg.get("firebase_url")
                    sid = cfg.get("server_id")
                    if fb_url and sid:
                        from utils import matchmaker
                        target_node = remote_lock.get("node_id") if remote_lock else "ANY"
                        sent = matchmaker.send_signal(fb_url, sid, f"mc:{cmd}", target_node=target_node, sender_node=get_node_id())
                        self._json(
                            {
                                "ok": bool(sent),
                                "msg": "Sent via Firebase (Network was blocked)" if sent else "Remote command failed.",
                            }
                        )
                    else:
                        self._json({"ok": False, "msg": "Server is offline (No remote host or Firebase)."})
                return
            ok = mc_server.send_command(cmd)
            self._json({"ok": bool(ok), "msg": "Sent" if ok else "Failed"})
            return

        if self.path == "/players/refresh":
            if not can_control_request(self, cfg, body):
                self._json({"ok": False, "msg": "Control blocked (project key mismatch)."}, code=403)
                return
            if mc_server.is_running():
                mc_server.send_command("list")
                for p in mc_server.get_online_players():
                    mc_server.send_command(f"data get entity {p}")
                self._json({"ok": True})
            else:
                self._json({"ok": False, "msg": "Server offline"})
            return

        self.send_response(404)
        self.end_headers()
