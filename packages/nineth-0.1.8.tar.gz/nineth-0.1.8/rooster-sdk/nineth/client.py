"""Python client for the 1984 model API."""

from __future__ import annotations

import json
import os
from typing import Any, AsyncIterator, Dict, Iterator, List, Optional, Union

import httpx


DEFAULT_TIMEOUT = httpx.Timeout(300.0, connect=10.0)
DEFAULT_STREAM_TIMEOUT = httpx.Timeout(connect=10.0, read=None, write=60.0, pool=60.0)
DEFAULT_BASE_URL = "https://weirdpablo--rooster-api.modal.run"
_API_KEY_HEADER = "X-API-Key"

# Models exposed to callers — the underlying provider names are never revealed.
AVAILABLE_MODELS: List[str] = [
    "1984-m0-brute",
    "1984-m0-sm",
    "1984-m1-unified",
    "1984-m2-light",
    "1984-m2-preview",
    "1984-m3-0317",
    "1984-m3-0404",
]


class NinethAPIError(RuntimeError):
    """Raised when the API returns an error response."""


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _build_payload(
    task_input: str,
    model: str,
    *,
    max_iterations: int,
    reasoning: Optional[str],
    show_reasoning: bool,
    images: Optional[List[str]],
    system_prompt: Optional[str],
) -> Dict[str, Any]:
    """Build the minimal server payload, keeping all internal defaults server-side."""
    payload: Dict[str, Any] = {
        "task_input": task_input,
        "model": model,
        "max_iterations": max_iterations,
        "show_reasoning": show_reasoning,
    }
    if reasoning is not None:
        payload["reasoning_effort"] = reasoning
    if images:
        payload["images"] = images
    if system_prompt:
        payload["system_prompt"] = system_prompt
    return payload


def _raise_for_status(response: httpx.Response) -> None:
    try:
        response.raise_for_status()
    except httpx.HTTPStatusError as exc:
        message = response.text.strip() or str(exc)
        raise NinethAPIError(message) from exc


def _raise_for_stream_event(event: Dict[str, Any]) -> None:
    if event.get("type") != "error":
        return
    data = event.get("data", {})
    if isinstance(data, dict):
        message = data.get("message") or data.get("error") or "Streaming request failed."
    else:
        message = str(data) or "Streaming request failed."
    raise NinethAPIError(message)


def _parse_sse_lines(lines: Iterator[str]) -> Iterator[Dict[str, Any]]:
    event_type = "message"
    data_lines: list[str] = []

    for raw_line in lines:
        line = raw_line.rstrip("\r")
        if not line:
            if data_lines:
                payload = json.loads("\n".join(data_lines))
                payload.setdefault("type", event_type)
                yield payload
            event_type = "message"
            data_lines = []
            continue
        if line.startswith(":"):
            continue
        if line.startswith("event:"):
            event_type = line.split(":", 1)[1].strip()
            continue
        if line.startswith("data:"):
            data_lines.append(line.split(":", 1)[1].strip())

    if data_lines:
        payload = json.loads("\n".join(data_lines))
        payload.setdefault("type", event_type)
        yield payload


# ---------------------------------------------------------------------------
# Service call status labels
# The client injects these as model_delta text so the human sees live activity
# without any extra code on their side.
# ---------------------------------------------------------------------------

_SERVICE_LABELS: Dict[str, str] = {
    "search_web":           "Browsing the web",
    "search_news":          "Checking the news",
    "search_discussions":   "Searching discussions",
    "search_unified":       "Searching",
    "search_knowledge":     "Searching knowledge base",
    "deepsearch":           "Deep searching",
    "read":                 "Reading page",
    "create_sandbox":       "Setting up sandbox",
    "run":                  "Running code",
    "destroy_sandbox":      "Cleaning up",
    "sandbox":              "In sandbox",
    "volume_write_file":    "Writing file",
    "volume_read_file":     "Reading file",
    "volume_search_replace":"Editing file",
    "volume_list":          "Listing files",
    "get_account_snapshot": "Checking account",
    "get_open_positions":   "Checking positions",
    "get_current_price":    "Getting price",
    "trade_market_buy":     "Placing buy order",
    "trade_market_sell":    "Placing sell order",
    "recall_media":         "Loading image",
    "media_list":           "Listing media",
    "send_message":         "Sending message",
    "set_alarm":            "Setting alarm",
    "schedule_at":          "Scheduling task",
    "cancel_alarm":         "Cancelling alarm",
}


def _service_status_delta(service_name: str) -> Optional[Dict[str, Any]]:
    """Return a model_delta event with a human-friendly status line, or None for silent services."""
    if service_name == "done":
        return None
    label = _SERVICE_LABELS.get(service_name, service_name.replace("_", " ").capitalize())
    return {"type": "model_delta", "data": {"text": f"\n  \u25b8 {label}\n"}}


def _coalesce_deltas(events: Iterator[Dict[str, Any]]) -> Iterator[Dict[str, Any]]:
    """Merge consecutive model_delta events and inject service status lines."""
    buffer = ""
    for event in events:
        if event.get("type") == "model_delta":
            buffer += event.get("data", {}).get("text", "")
            if buffer and (buffer[-1] in " \n\t" or len(buffer) >= 80):
                yield {"type": "model_delta", "data": {"text": buffer}}
                buffer = ""
        else:
            if buffer:
                yield {"type": "model_delta", "data": {"text": buffer}}
                buffer = ""
            # Inject a visible status line before service_call events
            if event.get("type") == "service_call":
                svc = event.get("data", {}).get("service_name", "")
                status = _service_status_delta(svc)
                if status:
                    yield status
            yield event
    if buffer:
        yield {"type": "model_delta", "data": {"text": buffer}}


# ---------------------------------------------------------------------------
# ModelProxy — the `client.model` namespace
# ---------------------------------------------------------------------------

class _ModelProxy:
    """
    Provides `client.model.request(...)`.

    All caching, continuity, and service routing is handled server-side.
    Callers only need to think about the task, the model, and whether they
    want a full response or a live stream.
    """

    def __init__(self, client: "NinethClient") -> None:
        self._client = client

    def request(
        self,
        task_input: str,
        *,
        model: Optional[str] = None,
        stream: bool = False,
        reasoning: Optional[str] = None,
        show_reasoning: bool = False,
        max_iterations: int = 10,
        images: Optional[List[str]] = None,
        system_prompt: Optional[str] = None,
    ) -> Union[Dict[str, Any], Iterator[Dict[str, Any]]]:
        """
        Send a task to the model.

        Args:
            task_input:     The task or question for the model.
            model:          Model name, e.g. ``"1984-m3-0317"``.
                            Falls back to the client ``default_model``.
            stream:         ``True`` → yields live text deltas as they arrive.
                            ``False`` (default) → returns the full response at once.
            reasoning:      Reasoning depth hint: ``"low"``, ``"medium"``, or ``"high"``.
                            Leave as ``None`` to use the model default.
            show_reasoning: Include the model's internal reasoning in the output.
            max_iterations: How many model turns the server is allowed to run.
                            Default is ``10``.  Most tasks finish in 1–3 turns.
            images:         Base64-encoded images for multimodal requests.
            system_prompt:  Override the default system prompt.

        Returns:
            When ``stream=False``: a dict with at minimum ``final_response`` and ``iterations``.
            When ``stream=True``:  an iterator of event dicts.  Text chunks arrive as
            ``{"type": "model_delta", "data": {"text": "..."}}``.  The last event is
            ``{"type": "result", ...}`` containing the full ``final_response``.

        Raises:
            ValueError:      When no model is configured.
            NinethAPIError:  When the server returns an error.
        """
        resolved_model = model or self._client.default_model
        if not resolved_model:
            raise ValueError(
                "A model is required. Pass model=... or set default_model / NINETH_MODEL."
            )

        if stream:
            return self._client._stream_request(
                task_input,
                resolved_model,
                reasoning=reasoning,
                show_reasoning=show_reasoning,
                max_iterations=max_iterations,
                images=images,
                system_prompt=system_prompt,
            )
        return self._client._buffered_request(
            task_input,
            resolved_model,
            reasoning=reasoning,
            show_reasoning=show_reasoning,
            max_iterations=max_iterations,
            images=images,
            system_prompt=system_prompt,
        )


class _AsyncModelProxy:
    """Async version of ``_ModelProxy``.  Used on ``AsyncNinethClient``."""

    def __init__(self, client: "AsyncNinethClient") -> None:
        self._client = client

    async def request(
        self,
        task_input: str,
        *,
        model: Optional[str] = None,
        stream: bool = False,
        reasoning: Optional[str] = None,
        show_reasoning: bool = False,
        max_iterations: int = 10,
        images: Optional[List[str]] = None,
        system_prompt: Optional[str] = None,
    ) -> Union[Dict[str, Any], AsyncIterator[Dict[str, Any]]]:
        """
        Send a task to the model (async).

        When ``stream=False`` (default) awaits the full response and returns a dict
        with ``final_response`` and ``iterations``.

        When ``stream=True`` returns an async iterator that you iterate with
        ``async for``::

            async for event in await client.model.request("task", stream=True):
                if event["type"] == "model_delta":
                    print(event["data"]["text"], end="")
        """
        resolved_model = model or self._client.default_model
        if not resolved_model:
            raise ValueError(
                "A model is required. Pass model=... or set default_model / NINETH_MODEL."
            )

        if stream:
            return self._client._stream_request(
                task_input,
                resolved_model,
                reasoning=reasoning,
                show_reasoning=show_reasoning,
                max_iterations=max_iterations,
                images=images,
                system_prompt=system_prompt,
            )
        return await self._client._buffered_request(
            task_input,
            resolved_model,
            reasoning=reasoning,
            show_reasoning=show_reasoning,
            max_iterations=max_iterations,
            images=images,
            system_prompt=system_prompt,
        )


# ---------------------------------------------------------------------------
# Public clients
# ---------------------------------------------------------------------------

class NinethClient:
    """
    Synchronous client for the 1984 model API.

    Basic usage::

        from nineth import NinethClient

        with NinethClient(default_model="1984-m3-0317") as client:
            response = client.model.request("Summarise BTC today.")
            print(response["final_response"])

    Streaming::

        with NinethClient(default_model="1984-m3-0317") as client:
            for event in client.model.request("Summarise BTC today.", stream=True):
                if event["type"] == "model_delta":
                    print(event["data"]["text"], end="", flush=True)
    """

    def __init__(
        self,
        base_url: Optional[str] = None,
        api_key: Optional[str] = None,
        *,
        default_model: Optional[str] = None,
        timeout: Union[httpx.Timeout, float, None] = DEFAULT_TIMEOUT,
        stream_timeout: Union[httpx.Timeout, float, None] = DEFAULT_STREAM_TIMEOUT,
        headers: Optional[Dict[str, str]] = None,
    ):
        resolved_base_url = (base_url or os.getenv("NINETH_BASE_URL") or DEFAULT_BASE_URL).rstrip("/")
        resolved_api_key = api_key or os.getenv("NINETH_API_KEY")

        request_headers: Dict[str, str] = dict(headers or {})
        if resolved_api_key:
            request_headers.setdefault(_API_KEY_HEADER, resolved_api_key)

        self.base_url = resolved_base_url
        self.api_key = resolved_api_key
        self.default_model: Optional[str] = (
            default_model
            or os.getenv("NINETH_DEFAULT_MODEL")
            or os.getenv("NINETH_MODEL")
        )
        self._stream_timeout = stream_timeout
        self._http = httpx.Client(
            base_url=resolved_base_url,
            timeout=timeout,
            headers=request_headers or None,
        )
        self.model = _ModelProxy(self)

    def _ensure_api_key(self) -> None:
        if not self.api_key and _API_KEY_HEADER not in self._http.headers:
            raise ValueError(
                "Authentication required. Pass api_key=... or set NINETH_API_KEY."
            )

    def health(self) -> Dict[str, Any]:
        """Check that the API is reachable.  Does not require authentication."""
        response = self._http.get("/health")
        _raise_for_status(response)
        return response.json()

    def _buffered_request(
        self,
        task_input: str,
        model: str,
        *,
        reasoning: Optional[str],
        show_reasoning: bool,
        max_iterations: int,
        images: Optional[List[str]],
        system_prompt: Optional[str],
    ) -> Dict[str, Any]:
        self._ensure_api_key()
        payload = _build_payload(
            task_input,
            model,
            reasoning=reasoning,
            show_reasoning=show_reasoning,
            max_iterations=max_iterations,
            images=images,
            system_prompt=system_prompt,
        )
        response = self._http.post("/model", json=payload)
        _raise_for_status(response)
        body = response.json()
        # Surface only the fields callers actually need
        return _trim_response(body)

    def _stream_request(
        self,
        task_input: str,
        model: str,
        *,
        reasoning: Optional[str],
        show_reasoning: bool,
        max_iterations: int,
        images: Optional[List[str]],
        system_prompt: Optional[str],
    ) -> Iterator[Dict[str, Any]]:
        self._ensure_api_key()
        payload = _build_payload(
            task_input,
            model,
            reasoning=reasoning,
            show_reasoning=show_reasoning,
            max_iterations=max_iterations,
            images=images,
            system_prompt=system_prompt,
        )
        with self._http.stream(
            "POST",
            "/model/stream",
            json=payload,
            timeout=self._stream_timeout,
        ) as response:
            _raise_for_status(response)
            for event in _coalesce_deltas(_parse_sse_lines(response.iter_lines())):
                _raise_for_stream_event(event)
                yield _trim_event(event)

    def close(self) -> None:
        self._http.close()

    def __enter__(self) -> "NinethClient":
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        self.close()


class AsyncNinethClient:
    """
    Asynchronous client for the 1984 model API.

    Basic usage::

        import asyncio
        from nineth import AsyncNinethClient

        async def main():
            async with AsyncNinethClient(default_model="1984-m3-0317") as client:
                response = await client.model.request("Summarise ETH today.")
                print(response["final_response"])

        asyncio.run(main())
    """

    def __init__(
        self,
        base_url: Optional[str] = None,
        api_key: Optional[str] = None,
        *,
        default_model: Optional[str] = None,
        timeout: Union[httpx.Timeout, float, None] = DEFAULT_TIMEOUT,
        stream_timeout: Union[httpx.Timeout, float, None] = DEFAULT_STREAM_TIMEOUT,
        headers: Optional[Dict[str, str]] = None,
    ):
        resolved_base_url = (base_url or os.getenv("NINETH_BASE_URL") or DEFAULT_BASE_URL).rstrip("/")
        resolved_api_key = api_key or os.getenv("NINETH_API_KEY")

        request_headers: Dict[str, str] = dict(headers or {})
        if resolved_api_key:
            request_headers.setdefault(_API_KEY_HEADER, resolved_api_key)

        self.base_url = resolved_base_url
        self.api_key = resolved_api_key
        self.default_model: Optional[str] = (
            default_model
            or os.getenv("NINETH_DEFAULT_MODEL")
            or os.getenv("NINETH_MODEL")
        )
        self._stream_timeout = stream_timeout
        self._http = httpx.AsyncClient(
            base_url=resolved_base_url,
            timeout=timeout,
            headers=request_headers or None,
        )
        self.model = _AsyncModelProxy(self)

    def _ensure_api_key(self) -> None:
        if not self.api_key and _API_KEY_HEADER not in self._http.headers:
            raise ValueError(
                "Authentication required. Pass api_key=... or set NINETH_API_KEY."
            )

    async def health(self) -> Dict[str, Any]:
        """Check that the API is reachable.  Does not require authentication."""
        response = await self._http.get("/health")
        _raise_for_status(response)
        return response.json()

    async def _buffered_request(
        self,
        task_input: str,
        model: str,
        *,
        reasoning: Optional[str],
        show_reasoning: bool,
        max_iterations: int,
        images: Optional[List[str]],
        system_prompt: Optional[str],
    ) -> Dict[str, Any]:
        self._ensure_api_key()
        payload = _build_payload(
            task_input,
            model,
            reasoning=reasoning,
            show_reasoning=show_reasoning,
            max_iterations=max_iterations,
            images=images,
            system_prompt=system_prompt,
        )
        response = await self._http.post("/model", json=payload)
        _raise_for_status(response)
        body = response.json()
        return _trim_response(body)

    def _stream_request(
        self,
        task_input: str,
        model: str,
        *,
        reasoning: Optional[str],
        show_reasoning: bool,
        max_iterations: int,
        images: Optional[List[str]],
        system_prompt: Optional[str],
    ) -> AsyncIterator[Dict[str, Any]]:
        self._ensure_api_key()
        payload = _build_payload(
            task_input,
            model,
            reasoning=reasoning,
            show_reasoning=show_reasoning,
            max_iterations=max_iterations,
            images=images,
            system_prompt=system_prompt,
        )

        async def _gen() -> AsyncIterator[Dict[str, Any]]:
            async with self._http.stream(
                "POST",
                "/model/stream",
                json=payload,
                timeout=self._stream_timeout,
            ) as response:
                _raise_for_status(response)
                event_type = "message"
                data_lines: list[str] = []
                delta_buffer = ""

                async def _flush() -> Optional[Dict[str, Any]]:
                    nonlocal delta_buffer
                    if delta_buffer:
                        evt: Dict[str, Any] = {"type": "model_delta", "data": {"text": delta_buffer}}
                        delta_buffer = ""
                        return evt
                    return None

                async for raw_line in response.aiter_lines():
                    line = raw_line.rstrip("\r")
                    if not line:
                        if data_lines:
                            parsed: Dict[str, Any] = json.loads("\n".join(data_lines))
                            parsed.setdefault("type", event_type)
                            _raise_for_stream_event(parsed)
                            if parsed.get("type") == "model_delta":
                                delta_buffer += parsed.get("data", {}).get("text", "")
                                if delta_buffer and (delta_buffer[-1] in " \n\t" or len(delta_buffer) >= 80):
                                    yield {"type": "model_delta", "data": {"text": delta_buffer}}
                                    delta_buffer = ""
                            else:
                                flushed = await _flush()
                                if flushed:
                                    yield _trim_event(flushed)
                                if parsed.get("type") == "service_call":
                                    svc = parsed.get("data", {}).get("service_name", "")
                                    status = _service_status_delta(svc)
                                    if status:
                                        yield status
                                yield _trim_event(parsed)
                        event_type = "message"
                        data_lines = []
                        continue
                    if line.startswith(":"):
                        continue
                    if line.startswith("event:"):
                        event_type = line.split(":", 1)[1].strip()
                        continue
                    if line.startswith("data:"):
                        data_lines.append(line.split(":", 1)[1].strip())

                if data_lines:
                    parsed = json.loads("\n".join(data_lines))
                    parsed.setdefault("type", event_type)
                    _raise_for_stream_event(parsed)
                    if parsed.get("type") == "model_delta":
                        delta_buffer += parsed.get("data", {}).get("text", "")
                    else:
                        flushed = await _flush()
                        if flushed:
                            yield _trim_event(flushed)
                        yield _trim_event(parsed)
                if delta_buffer:
                    yield {"type": "model_delta", "data": {"text": delta_buffer}}

        return _gen()

    async def aclose(self) -> None:
        await self._http.aclose()

    async def __aenter__(self) -> "AsyncNinethClient":
        return self

    async def __aexit__(self, exc_type, exc, tb) -> None:
        await self.aclose()


# ---------------------------------------------------------------------------
# Response trimming — hide internal fields from callers
# ---------------------------------------------------------------------------

_BUFFERED_KEEP = {"final_response", "iterations", "thinking", "service_calls", "service_responses", "usage", "events"}
_STREAM_SKIP_TYPES = {"accepted", "run_started", "model_start", "model_response", "heartbeat", "idle", "wake", "completed"}


def _trim_response(body: Dict[str, Any]) -> Dict[str, Any]:
    """Return only the caller-facing fields from a buffered API response."""
    return {k: v for k, v in body.items() if k in _BUFFERED_KEEP}


def _trim_event(event: Dict[str, Any]) -> Dict[str, Any]:
    """Strip server-internal metadata from a stream event."""
    # Pass model_delta and result through unchanged; drop noisy internal events
    return event
