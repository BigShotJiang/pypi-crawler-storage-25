"""DevPanel daemon: aiohttp server with per-tab PTY sessions + HTTP context stack."""

from __future__ import annotations

import atexit
import asyncio
import base64
import collections
import fcntl
import json
import os
import pty
import re
import signal
import struct
import termios
import time
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from aiohttp import web, WSMsgType

from devpanel.mcp import McpSession, dispatch as mcp_dispatch


BUFFER_SIZE = 64 * 1024
SCROLLBACK_SIZE = 100 * 1024  # 100 KB ring buffer
IDLE_TIMEOUT = 30 * 60  # 30 minutes (daemon exits when no sessions)
MAX_SESSIONS = 10  # cap live sessions; oldest evicted on overflow
MCP_IDLE_TIMEOUT = 5 * 60  # 5 minutes: reap MCP sessions with no POST/GET activity
MCP_SWEEP_INTERVAL = 60  # 60 seconds between sweep ticks
SPILL_DIR = Path(os.environ.get("XDG_RUNTIME_DIR", "/tmp")) / "devpanel"
LOCK_FILE = SPILL_DIR / "daemon.lock"
SPILL_MAX_AGE = 3600  # 1 hour


def _ensure_spill_dir() -> None:
    SPILL_DIR.mkdir(parents=True, exist_ok=True)


def _spill(data: str | bytes, label: str, ext: str) -> str:
    """Write data to a spill file, return the path."""
    _ensure_spill_dir()
    tid = uuid.uuid4().hex[:8]
    path = SPILL_DIR / f"{label}-{tid}.{ext}"
    if isinstance(data, bytes):
        path.write_bytes(data)
    else:
        path.write_text(data)
    return str(path)


# --- Lifecycle ---


def _startup_cleanup() -> None:
    """Clean up stale state from a previous daemon that didn't exit cleanly."""
    if LOCK_FILE.exists():
        try:
            lock = json.loads(LOCK_FILE.read_text())
            pid = lock.get("pid")
            if pid and _pid_alive(pid):
                return  # Another daemon is running, don't clean up
        except (json.JSONDecodeError, OSError):
            pass
        LOCK_FILE.unlink(missing_ok=True)

    # Clean old spill files
    if SPILL_DIR.exists():
        now = time.time()
        for f in SPILL_DIR.iterdir():
            if f.name == "daemon.lock":
                continue
            try:
                if now - f.stat().st_mtime > SPILL_MAX_AGE:
                    f.unlink()
            except OSError:
                pass


def _write_lock(port: int) -> None:
    """Write lock file with current PID and port."""
    _ensure_spill_dir()
    LOCK_FILE.write_text(
        json.dumps(
            {
                "pid": os.getpid(),
                "port": port,
                "started_at": time.time(),
            }
        )
    )


def _remove_lock() -> None:
    """Remove lock file (best-effort)."""
    try:
        LOCK_FILE.unlink(missing_ok=True)
    except OSError:
        pass


def _pid_alive(pid: int) -> bool:
    try:
        os.kill(pid, 0)
        return True
    except OSError:
        return False


# --- Async task tracking ---


@dataclass
class AsyncTask:
    task_id: str
    kind: str  # "defer" | "every"
    code: str
    interval: int | None
    task: asyncio.Task[None]


# --- Session registry ---

_sessions: dict[str, PtySession] = {}
_sessions_lock = asyncio.Lock()
_daemon_idle_handle: asyncio.TimerHandle | None = None


def _check_daemon_idle() -> None:
    """Start/cancel daemon idle timer based on session count."""
    global _daemon_idle_handle
    if _sessions:
        if _daemon_idle_handle:
            _daemon_idle_handle.cancel()
            _daemon_idle_handle = None
        return
    if _daemon_idle_handle:
        return  # already ticking

    def _idle_exit():
        _remove_lock()
        os._exit(0)

    loop = asyncio.get_running_loop()
    _daemon_idle_handle = loop.call_later(IDLE_TIMEOUT, _idle_exit)


def _sweep_mcp() -> None:
    """Reap MCP sessions with no POST/GET activity in MCP_IDLE_TIMEOUT.

    Re-arms itself every MCP_SWEEP_INTERVAL seconds. Closes idle sessions via
    queue sentinel; the SSE loop exits cleanly.
    """
    now = time.monotonic()
    for pty_session in _sessions.values():
        for sid, mcp in list(pty_session.mcp_sessions.items()):
            if now - mcp.last_active > MCP_IDLE_TIMEOUT:
                mcp.close()
                pty_session.mcp_sessions.pop(sid, None)
    loop = asyncio.get_running_loop()
    loop.call_later(MCP_SWEEP_INTERVAL, _sweep_mcp)


# --- PTY Session (per-tab) ---


def _resize_pty(fd: int, cols: int, rows: int) -> None:
    fcntl.ioctl(fd, termios.TIOCSWINSZ, struct.pack("HHHH", rows, cols, 0, 0))


class PtySession:
    """Per-tab PTY with scrollback buffer, client fanout, and own context stack."""

    def __init__(self, session_id: str) -> None:
        self.session_id = session_id
        self.master_fd: int | None = None
        self.process: asyncio.subprocess.Process | None = None
        self.scrollback = bytearray()
        self.clients: set[web.WebSocketResponse] = set()
        self._reader_task: asyncio.Task[None] | None = None
        # Delivery queue. Items removed on flush/drain. Maxlen=50 safety cap.
        self.stack: collections.deque[dict[str, Any]] = collections.deque(maxlen=50)
        self.stack_lock = asyncio.Lock()
        self._stack_seq = 0  # auto-increment for stable ordering
        # MCP sessions (keyed by MCP session ID)
        self.mcp_sessions: dict[str, McpSession] = {}
        # WS command/response protocol
        self.pending_commands: dict[str, asyncio.Future[dict]] = {}
        # JS eval history for _ / _N variables
        self.eval_history: list[Any] = []
        # Async task tracking (defer/every)
        self.async_tasks: dict[str, AsyncTask] = {}
        self.async_tasks_lock = asyncio.Lock()
        self._task_counter = 0
        # Console capture buffer (capped 1000 entries)
        self.console_buffer: collections.deque[dict] = collections.deque(maxlen=1000)
        # Network watchers: id → pattern (also stored panel-side)
        self.watchers: dict[str, str] = {}

    async def alloc_task_id(self) -> str:
        async with self.async_tasks_lock:
            self._task_counter += 1
            return f"tsk_{self._task_counter}"

    async def alloc_watch_id(self) -> str:
        async with self.async_tasks_lock:
            self._task_counter += 1
            return f"wch_{self._task_counter}"

    def wrap_eval(self, code: str) -> str:
        """Prepend history variable declarations to eval code."""
        lines: list[str] = []
        if self.eval_history:
            lines.append(f"var _ = {json.dumps(self.eval_history[-1])};")
            for i, r in enumerate(self.eval_history):
                lines.append(f"var _{i + 1} = {json.dumps(r)};")
        lines.append(code)
        return "\n".join(lines)

    async def start(self, port: int, cwd: str | None = None) -> None:
        """Spawn PTY with DEVPANEL_* env vars. User's shell chain handles the rest."""
        master, slave = pty.openpty()
        fcntl.fcntl(
            master, fcntl.F_SETFL, fcntl.fcntl(master, fcntl.F_GETFL) | os.O_NONBLOCK
        )

        env = os.environ.copy()
        env["TERM"] = "xterm-256color"
        env["COLORTERM"] = "truecolor"
        env["FORCE_COLOR"] = "1"
        env["DEVPANEL_PORT"] = str(port)
        env["DEVPANEL_SESSION"] = self.session_id
        env["DEVPANEL_SPILL_DIR"] = str(SPILL_DIR)
        env["DEVPANEL_REPLD_SOCKET"] = str(SPILL_DIR / "repld.sock")
        # Scrub inherited terminal-multiplexer vars so the spawned shell
        # sees a fresh context (like ghostty/iTerm do implicitly).
        for var in ("TMUX", "TMUX_PANE", "STY"):
            env.pop(var, None)

        shell = os.environ.get("SHELL", "/bin/bash")
        self.process = await asyncio.create_subprocess_exec(
            shell,
            stdin=slave,
            stdout=slave,
            stderr=slave,
            env=env,
            cwd=str(Path(cwd).expanduser())
            if cwd and Path(cwd).expanduser().is_dir()
            else str(Path.home()),
            preexec_fn=os.setsid,
        )
        os.close(slave)
        self.master_fd = master

        _resize_pty(master, 80, 24)

        # Set up async reader from PTY master
        loop = asyncio.get_running_loop()
        reader = asyncio.StreamReader(BUFFER_SIZE)
        protocol = asyncio.StreamReaderProtocol(reader)
        await loop.connect_read_pipe(lambda: protocol, os.fdopen(master, "rb", 0))

        self._reader_task = asyncio.create_task(self._read_loop(reader))

    async def _read_loop(self, reader: asyncio.StreamReader) -> None:
        """Read PTY output, append to scrollback, fan out to WS clients."""
        try:
            while True:
                data = await reader.read(BUFFER_SIZE)
                if not data:
                    break
                # Append to scrollback ring buffer
                self.scrollback.extend(data)
                if len(self.scrollback) > SCROLLBACK_SIZE:
                    self.scrollback = self.scrollback[-SCROLLBACK_SIZE:]
                # Fan out to all connected clients
                closed: set[web.WebSocketResponse] = set()
                for ws in self.clients:
                    try:
                        await ws.send_bytes(data)
                    except Exception:
                        closed.add(ws)
                self.clients -= closed
        except Exception:
            pass

        # PTY exited — notify clients and remove session
        await self._close_clients(b"\r\n\x1b[90m[shell exited]\x1b[0m\r\n")
        _sessions.pop(self.session_id, None)
        _check_daemon_idle()

    async def _close_clients(self, message: bytes) -> None:
        """Notify WS clients and clear session state."""
        for ws in list(self.clients):
            try:
                await ws.send_bytes(message)
                await ws.close()
            except Exception:
                pass
        self.stack.clear()
        for mcp in self.mcp_sessions.values():
            mcp.close()
        self.mcp_sessions.clear()
        # Cancel all async tasks
        async with self.async_tasks_lock:
            for at in list(self.async_tasks.values()):
                at.task.cancel()
            self.async_tasks.clear()
        # Clear console buffer and watchers
        self.console_buffer.clear()
        self.watchers.clear()
        self.clients.clear()

    async def attach(self, ws: web.WebSocketResponse) -> None:
        """Attach a WS client. Replays scrollback."""
        if self.scrollback:
            await ws.send_bytes(bytes(self.scrollback))
        self.clients.add(ws)

    def detach(self, ws: web.WebSocketResponse) -> None:
        """Detach a WS client. Session persists for reconnect."""
        self.clients.discard(ws)

    async def broadcast(self, event: dict[str, Any]) -> None:
        """Send a JSON event to all connected WS clients (text frame)."""
        msg = json.dumps(event)
        closed: set[web.WebSocketResponse] = set()
        for ws in self.clients:
            try:
                await ws.send_str(msg)
            except Exception:
                closed.add(ws)
        self.clients -= closed

    def write(self, data: bytes) -> None:
        """Write to PTY stdin."""
        if self.master_fd is not None:
            os.write(self.master_fd, data)

    def resize(self, cols: int, rows: int) -> None:
        """Resize PTY."""
        if self.master_fd is not None:
            _resize_pty(self.master_fd, cols, rows)

    @property
    def alive(self) -> bool:
        return self.process is not None and self.process.returncode is None

    async def shutdown(self) -> None:
        """Terminate this session's PTY."""
        if self.process and self.process.returncode is None:
            try:
                os.killpg(os.getpgid(self.process.pid), signal.SIGHUP)
            except OSError:
                pass
            try:
                await asyncio.wait_for(self.process.wait(), timeout=5)
            except asyncio.TimeoutError:
                self.process.kill()
        await self._close_clients(b"\r\n\x1b[90m[session ended]\x1b[0m\r\n")


# --- WS command/response ---


async def send_command(
    session: "PtySession", cmd: str, timeout: float = 10.0, **params: Any
) -> dict:
    """Send command to panel via WS, await response."""
    rid = uuid.uuid4().hex[:8]
    loop = asyncio.get_running_loop()
    future: asyncio.Future[dict] = loop.create_future()
    session.pending_commands[rid] = future
    await session.broadcast({"id": rid, "cmd": cmd, **params})
    try:
        return await asyncio.wait_for(future, timeout=timeout)
    except asyncio.TimeoutError:
        session.pending_commands.pop(rid, None)
        raise


# --- Context stack (per-session) ---


def _item_summary(item: dict[str, Any]) -> str:
    """Short human-readable summary for toast notifications."""
    t = item.get("type", "unknown")
    if t == "element":
        sel = str(item.get("selector", "?"))[:40]
        return f"Pushed `{sel}`"
    if t == "network":
        count = item.get("count", 0)
        return f"Captured {count} requests"
    if t == "screenshot":
        return "Screenshot captured"
    if t == "console":
        count = item.get("count", 0)
        errors = item.get("errors", 0)
        return f"Captured {count} console entries" + (
            f" ({errors} errors)" if errors else ""
        )
    return f"Pushed {t}"


def _format_for_channel(item: dict[str, Any]) -> str:
    """Terse one-liner for live channel push (vs. _format_for_agent's drain markdown)."""
    t = item.get("type", "unknown")
    if t == "element":
        sel = item.get("selector", "?")
        url = item.get("url", "")
        note = item.get("note", "")
        parts = [f"Selected {sel}"]
        if url:
            parts.append(f"on {url}")
        if note:
            parts.append(f"— {note}")
        return " ".join(parts)
    if t == "network":
        count = item.get("count", 0)
        errors = item.get("errors", 0)
        path = item.get("spill_path", "")
        text = f"Captured {count} requests"
        if errors:
            text += f", {errors} errors"
        if path:
            text += f" → {path}"
        return text
    if t == "screenshot":
        path = item.get("spill_path", "")
        sel = item.get("selector", "")
        prefix = f"Screenshot of {sel}" if sel else "Screenshot"
        return f"{prefix} → {path}" if path else f"{prefix} captured"
    if t == "console":
        count = item.get("count", 0)
        errors = item.get("errors", 0)
        path = item.get("spill_path", "")
        text = f"{count} console entries"
        if errors:
            text += f", {errors} errors"
        if path:
            text += f" → {path}"
        return text
    return f"Pushed {t}"


def _spill_item(body: dict[str, Any]) -> dict[str, Any]:
    """Spill large data (network, screenshot, page HTML) to disk."""
    item_type = body.get("type", "")

    if item_type == "network" and "entries" in body:
        entries = body["entries"]
        path = _spill(json.dumps(entries, indent=2), "network", "json")
        errors = [e for e in entries if e.get("status", 200) >= 400]
        return {
            "type": "network",
            "count": len(entries),
            "errors": len(errors),
            "spill_path": path,
        }

    if item_type == "screenshot" and "data" in body:
        png_bytes = base64.b64decode(body["data"])
        path = _spill(png_bytes, "screenshot", "png")
        out = {"type": "screenshot", "spill_path": path}
        if body.get("selector"):
            out["selector"] = body["selector"]
        return out

    if item_type == "console" and "entries" in body:
        entries = body["entries"]
        path = _spill(json.dumps(entries, indent=2), "console", "json")
        errors = [e for e in entries if e.get("level") in ("error", "warning")]
        return {
            "type": "console",
            "count": len(entries),
            "errors": len(errors),
            "spill_path": path,
        }

    return body


def _pick_active_mcp(session: "PtySession") -> McpSession | None:
    """Pick the most-recently-active MCP session for channel routing.

    Browser events fan to one client; multi-tmux focus follows whoever last
    made an MCP call. Returns None if no MCP sessions exist.
    """
    if not session.mcp_sessions:
        return None
    return max(session.mcp_sessions.values(), key=lambda m: m.last_active)


async def handle_stack_push(request: web.Request) -> web.Response:
    """Stage a context item. Always stores — never pushes to channel.

    Channel delivery is explicit via POST /stack/flush.
    """
    session_id = request.query.get("session")
    if not session_id or session_id not in _sessions:
        return web.json_response({"error": "unknown session"}, status=404)
    session = _sessions[session_id]
    body = await request.json()
    item = _spill_item(body)
    async with session.stack_lock:
        session._stack_seq += 1
        item["_seq"] = session._stack_seq
        session.stack.append(item)
    summary = _item_summary(item)
    await session.broadcast(
        {"type": "stack-updated", "size": len(session.stack), "summary": summary}
    )
    return web.json_response({"ok": True, "size": len(session.stack)})


async def handle_stack(request: web.Request) -> web.Response:
    """Drain or peek the delivery queue.

    GET /stack?session=X            → drain: return all pending items, clear queue.
                                       Hook fallback for non-channel MCP clients.
    GET /stack?session=X&peek=true  → peek for UI; returns queue contents as JSON.
    """
    session_id = request.query.get("session")
    if not session_id or session_id not in _sessions:
        # Return empty for unknown sessions (hook might fire after session ends)
        if request.query.get("peek") == "true":
            return web.json_response([])
        return web.Response(text="", content_type="text/plain")

    session = _sessions[session_id]
    peek = request.query.get("peek") == "true"
    async with session.stack_lock:
        items = list(session.stack)
        if not peek:
            session.stack.clear()

    if peek:
        return web.json_response(items)

    if items:
        await session.broadcast({"type": "stack-updated", "size": 0})

    # Prepend viewport state for agent context
    parts: list[str] = []
    if session.clients:
        try:
            resp = await send_command(session, "viewport", timeout=2.0)
            label = resp.get("result", {}).get("label", "")
            if label:
                parts.append(f"viewport: {label}")
        except Exception:
            pass
    agent_text = _format_for_agent(items)
    if agent_text:
        parts.append(agent_text)
    return web.Response(text="\n\n".join(parts), content_type="text/plain")


async def handle_stack_flush(request: web.Request) -> web.Response:
    """Flush staged items as a single batch channel notification."""
    session_id = request.query.get("session")
    if not session_id or session_id not in _sessions:
        return web.json_response({"error": "unknown session"}, status=404)
    session = _sessions[session_id]
    async with session.stack_lock:
        items = list(session.stack)
        if not items:
            return web.json_response({"ok": True, "flushed": 0})
        session.stack.clear()
    mcp = _pick_active_mcp(session)
    if mcp:
        lines = [_format_for_channel(i) for i in items]
        if len(lines) == 1:
            mcp.push_channel(lines[0])
        else:
            mcp.push_channel(
                f"Browser context ({len(lines)} items):\n"
                + "\n".join(f"• {line}" for line in lines)
            )
    await session.broadcast({"type": "stack-updated", "size": 0})
    return web.json_response({"ok": True, "flushed": len(items)})


def _format_for_agent(items: list[dict[str, Any]]) -> str:
    """Format stack items as readable text for Claude Code."""
    if not items:
        return ""

    sections: dict[str, list[str]] = {}

    for item in items:
        t = item.get("type", "unknown")

        if t == "element":
            lines = sections.setdefault("Selected elements", [])
            selector = item.get("selector", "?")
            url = item.get("url", "")
            note = item.get("note", "")
            parts = [f"- `{selector}`"]
            if url:
                parts.append(f"on {url}")
            if note:
                parts.append(f"— {note}")
            lines.append(" ".join(parts))

        elif t == "network":
            lines = sections.setdefault("Network", [])
            count = item.get("count", 0)
            errors = item.get("errors", 0)
            path = item.get("spill_path", "")
            summary = f"{count} requests"
            if errors:
                summary += f", {errors} errors"
            lines.append(f"- {summary} → {path}")

        elif t == "screenshot":
            lines = sections.setdefault("Screenshots", [])
            path = item.get("spill_path", "")
            lines.append(f"- {path}")

        elif t == "console":
            lines = sections.setdefault("Console", [])
            count = item.get("count", 0)
            errors = item.get("errors", 0)
            path = item.get("spill_path", "")
            summary = f"{count} entries"
            if errors:
                summary += f", {errors} errors/warnings"
            lines.append(f"- {summary} → {path}")

        else:
            lines = sections.setdefault("Other", [])
            lines.append(f"- {json.dumps(item)}")

    parts = ["## Browser Context\n"]
    for heading, lines in sections.items():
        parts.append(f"### {heading}")
        parts.extend(lines)
        parts.append("")

    return "\n".join(parts)


# --- Spill file serving ---


async def handle_spill_serve(request: web.Request) -> web.StreamResponse:
    """GET /spill/{name} — serve a spill file by basename.
    Panel uses this to load screenshot previews; chrome-extension origin
    can't read /run/user/... paths directly."""
    name = request.match_info["name"]
    if not re.fullmatch(r"[a-z_]+-[0-9a-f]{8}\.(png|json|html)", name):
        return web.Response(status=400, text="Invalid filename")
    path = SPILL_DIR / name
    if not path.exists():
        return web.Response(status=404)
    return web.FileResponse(path)


# --- Controls (dev endpoint) ---

_start_time = time.time()


def _package_version() -> str:
    """Read the installed devpanel package version. Empty string on failure
    (e.g. running from a source tree without metadata)."""
    try:
        from importlib.metadata import PackageNotFoundError, version

        return version("devpanel")
    except (ImportError, PackageNotFoundError):
        return ""


async def handle_controls(request: web.Request) -> web.Response:
    sessions_info = {}
    for sid, s in _sessions.items():
        sessions_info[sid] = {
            "pty_pid": s.process.pid if s.process else None,
            "pty_alive": s.alive,
            "clients": len(s.clients),
            "stack_size": len(s.stack),
            "mcp_sessions": len(s.mcp_sessions),
            "async_tasks": len(s.async_tasks),
            "watchers": len(s.watchers),
        }
    repld_socket = os.environ.get("REPLD_SOCKET") or str(
        Path(os.environ.get("XDG_RUNTIME_DIR", "/tmp")) / "devpanel" / "repld.sock"
    )
    return web.json_response(
        {
            "port": request.app.get("port"),
            "version": _package_version(),
            "sessions": sessions_info,
            "session_count": len(_sessions),
            "uptime": round(time.time() - _start_time, 1),
            "spill_dir": str(SPILL_DIR),
            "repld_socket": repld_socket if Path(repld_socket).exists() else None,
        }
    )


# --- PTY WebSocket (session routing) ---


async def handle_ws(request: web.Request) -> web.WebSocketResponse:
    tab = request.query.get("tab")
    if not tab:
        ws = web.WebSocketResponse()
        await ws.prepare(request)
        await ws.send_bytes(b"\x1b[31mMissing ?tab= parameter\x1b[0m\r\n")
        await ws.close()
        return ws

    port = request.app["port"]

    cwd = request.query.get("cwd")

    async with _sessions_lock:
        session = _sessions.get(tab)
        if not session:
            # Evict oldest sessions if at capacity
            while len(_sessions) >= MAX_SESSIONS:
                oldest_id = next(iter(_sessions))
                oldest = _sessions.pop(oldest_id)
                await oldest.shutdown()
            session = PtySession(tab)
            _sessions[tab] = session
            await session.start(port, cwd=cwd)
            _check_daemon_idle()

    if not session.alive:
        ws = web.WebSocketResponse()
        await ws.prepare(request)
        await ws.send_bytes(b"\x1b[31mPTY process has exited.\x1b[0m\r\n")
        await ws.close()
        return ws

    ws = web.WebSocketResponse()
    await ws.prepare(request)
    await session.attach(ws)

    try:
        async for msg in ws:
            if msg.type == WSMsgType.BINARY:
                session.write(msg.data)
            elif msg.type == WSMsgType.TEXT:
                try:
                    ctrl: dict[str, Any] = json.loads(msg.data)
                    if "cmd" not in ctrl and "id" in ctrl:
                        # Command response from panel
                        rid = ctrl["id"]
                        future = session.pending_commands.pop(rid, None)
                        if future and not future.done():
                            future.set_result(ctrl)
                    elif ctrl.get("type") == "resize":
                        session.resize(int(ctrl["cols"]), int(ctrl["rows"]))
                except (json.JSONDecodeError, KeyError):
                    pass
            elif msg.type in (WSMsgType.CLOSE, WSMsgType.ERROR):
                break
    except Exception:
        pass
    finally:
        session.detach(ws)

    return ws


# --- MCP Streamable HTTP ---


async def handle_channel_push(request: web.Request) -> web.Response:
    """POST /channel — push a channel notification to the active MCP session."""
    session_id = request.query.get("session")
    if not session_id or session_id not in _sessions:
        return web.Response(status=404)
    pty = _sessions[session_id]
    body = await request.json()
    content = body.get("content", "")
    mcp = _pick_active_mcp(pty)
    if mcp:
        mcp.push_channel(content)
    return web.json_response({"ok": True})


async def handle_mcp_post(request: web.Request) -> web.Response:
    """POST /mcp — JSON-RPC request → JSON response."""
    session_id = request.query.get("session")
    if not session_id or session_id not in _sessions:
        return web.Response(status=404, text="unknown session")
    pty = _sessions[session_id]

    body = await request.json()
    mcp_sid = request.headers.get("Mcp-Session-Id")

    # Route to existing MCP session or create on initialize
    if mcp_sid and mcp_sid in pty.mcp_sessions:
        mcp = pty.mcp_sessions[mcp_sid]
    elif body.get("method") == "initialize":
        mcp = McpSession()
        pty.mcp_sessions[mcp.session_id] = mcp
    else:
        return web.Response(status=400, text="missing or invalid Mcp-Session-Id")

    mcp.touch()
    result = await mcp_dispatch(body, mcp, pty)

    if result is None:
        return web.Response(status=202)

    resp = web.json_response(result)
    if body.get("method") == "initialize":
        resp.headers["Mcp-Session-Id"] = mcp.session_id
    return resp


async def handle_mcp_sse(request: web.Request) -> web.StreamResponse:
    """GET /mcp — SSE stream for server-pushed channel notifications."""
    session_id = request.query.get("session")
    if not session_id or session_id not in _sessions:
        return web.Response(status=404, text="unknown session")
    pty = _sessions[session_id]

    mcp_sid = request.headers.get("Mcp-Session-Id")
    if not mcp_sid or mcp_sid not in pty.mcp_sessions:
        return web.Response(status=400, text="missing or invalid Mcp-Session-Id")
    mcp = pty.mcp_sessions[mcp_sid]
    mcp.touch()

    resp = web.StreamResponse(
        headers={
            "Content-Type": "text/event-stream",
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
        }
    )
    await resp.prepare(request)

    try:
        while True:
            msg = await mcp.queue.get()
            if msg is None:
                break
            data = json.dumps(msg)
            try:
                await resp.write(f"event: message\ndata: {data}\n\n".encode())
            except (ConnectionResetError, ConnectionError):
                # TCP died mid-flush — re-enqueue so the next reconnecting
                # GET picks it up. Sentinel never reaches here (handled above).
                mcp.queue.put_nowait(msg)
                break
    except asyncio.CancelledError:
        pass

    return resp


async def handle_mcp_delete(request: web.Request) -> web.Response:
    """DELETE /mcp — terminate MCP session."""
    session_id = request.query.get("session")
    if not session_id or session_id not in _sessions:
        return web.Response(status=404)
    pty = _sessions[session_id]

    mcp_sid = request.headers.get("Mcp-Session-Id")
    if mcp_sid and mcp_sid in pty.mcp_sessions:
        mcp = pty.mcp_sessions.pop(mcp_sid)
        mcp.close()
    # Broadcast mcp-status: active only if there are remaining initialized sessions
    active = any(m.initialized for m in pty.mcp_sessions.values())
    asyncio.create_task(pty.broadcast({"type": "mcp-status", "active": active}))
    return web.Response(status=204)


# --- CORS middleware ---


@web.middleware
async def cors_middleware(request: web.Request, handler: Any) -> web.StreamResponse:
    if request.method == "OPTIONS":
        resp = web.Response()
    else:
        resp = await handler(request)
    resp.headers["Access-Control-Allow-Origin"] = "*"
    resp.headers["Access-Control-Allow-Methods"] = "GET, POST, DELETE, OPTIONS"
    resp.headers["Access-Control-Allow-Headers"] = "Content-Type, Mcp-Session-Id"
    resp.headers["Access-Control-Expose-Headers"] = "Mcp-Session-Id"
    return resp


async def handle_directories(request: web.Request) -> web.Response:
    """GET /directories — return hostname→path mappings from config.
    PUT /directories — update mappings."""
    from devpanel.install import read_config, _config_dir

    if request.method == "PUT":
        body = await request.json()
        config_file = _config_dir() / "config.json"
        config = read_config()
        config["directories"] = body
        _config_dir().mkdir(parents=True, exist_ok=True)
        config_file.write_text(json.dumps(config, indent=2))
        return web.json_response(body)

    config = read_config()
    return web.json_response(config.get("directories", {}))


# --- App factory ---


def create_app() -> web.Application:
    app = web.Application(middlewares=[cors_middleware])
    app.router.add_get("/ws", handle_ws)
    app.router.add_post("/stack", handle_stack_push)
    app.router.add_post("/stack/flush", handle_stack_flush)
    app.router.add_get("/stack", handle_stack)
    app.router.add_post("/channel", handle_channel_push)
    app.router.add_post("/mcp", handle_mcp_post)
    app.router.add_get("/mcp", handle_mcp_sse)
    app.router.add_delete("/mcp", handle_mcp_delete)
    app.router.add_get("/controls", handle_controls)
    app.router.add_get("/directories", handle_directories)
    app.router.add_put("/directories", handle_directories)
    app.router.add_get("/spill/{name}", handle_spill_serve)
    return app


async def run(port: int = 0) -> int:
    """Start the server. Sessions created on-demand via /ws. Returns actual port."""
    _startup_cleanup()

    app = create_app()
    runner = web.AppRunner(app)
    await runner.setup()
    site = web.TCPSite(runner, "127.0.0.1", port)
    await site.start()
    actual_port = site._server.sockets[0].getsockname()[1]  # type: ignore[union-attr]
    app["port"] = actual_port

    _write_lock(actual_port)
    atexit.register(_remove_lock)
    _check_daemon_idle()  # start idle timer (no sessions yet)
    asyncio.get_running_loop().call_later(MCP_SWEEP_INTERVAL, _sweep_mcp)

    return actual_port
