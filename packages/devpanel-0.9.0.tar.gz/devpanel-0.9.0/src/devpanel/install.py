"""Register native messaging host manifest for Chrome/Chromium."""

from __future__ import annotations

import json
import sys
from pathlib import Path

NMH_NAME = "dev.devpanel.pty"


def _config_dir() -> Path:
    """Persistent config directory for devpanel."""
    if sys.platform == "darwin":
        return Path.home() / "Library" / "Application Support" / "devpanel"
    return Path.home() / ".config" / "devpanel"


def _nmh_dirs() -> list[Path]:
    """User-level NMH manifest directories for the current platform."""
    home = Path.home()
    if sys.platform == "darwin":
        return [
            home
            / "Library"
            / "Application Support"
            / "Google"
            / "Chrome"
            / "NativeMessagingHosts",
            home
            / "Library"
            / "Application Support"
            / "Chromium"
            / "NativeMessagingHosts",
        ]
    # Linux (and other Unix)
    return [
        home / ".config" / "google-chrome" / "NativeMessagingHosts",
        home / ".config" / "chromium" / "NativeMessagingHosts",
    ]


def _find_binary() -> str:
    """Find the devpanel binary path."""
    import shutil

    path = shutil.which("devpanel")
    if path:
        return path
    print(
        "Error: 'devpanel' not found in PATH. Install with: uv tool install devpanel",
        file=sys.stderr,
    )
    sys.exit(1)


def _extension_path() -> Path | None:
    """Find the bundled extension directory."""
    # Check package data location (uv tool install)
    data_dir = Path(sys.prefix) / "share" / "devpanel" / "extension"
    if data_dir.is_dir():
        return data_dir
    # Check source tree (dev mode)
    src_ext = Path(__file__).parent / "extension"
    if src_ext.is_dir():
        return src_ext
    return None


def read_config() -> dict:
    """Read the persistent config. Returns {} if missing."""
    config_file = _config_dir() / "config.json"
    try:
        return json.loads(config_file.read_text())
    except (FileNotFoundError, json.JSONDecodeError):
        return {}


def install(
    extension_id: str | None = None,
    *,
    dev: bool = False,
    user_data_dir: str | None = None,
) -> None:
    binary = _find_binary()

    manifest = {
        "name": NMH_NAME,
        "description": "DevPanel PTY daemon",
        "type": "stdio",
        "path": binary,
    }

    if extension_id:
        manifest["allowed_origins"] = [f"chrome-extension://{extension_id}/"]
    else:
        print(
            "Warning: no --extension-id provided, manifest will need manual editing",
            file=sys.stderr,
        )
        manifest["allowed_origins"] = ["chrome-extension://EXTENSION_ID_HERE/"]

    # Write NMH manifests
    nmh_dirs = _nmh_dirs()
    if user_data_dir:
        nmh_dirs.append(Path(user_data_dir) / "NativeMessagingHosts")
    for nmh_dir in nmh_dirs:
        nmh_dir.mkdir(parents=True, exist_ok=True)
        manifest_path = nmh_dir / f"{NMH_NAME}.json"
        manifest_path.write_text(json.dumps(manifest, indent=2) + "\n")
        print(f"Wrote {manifest_path}")

    # Write config
    config_dir = _config_dir()
    config_dir.mkdir(parents=True, exist_ok=True)
    config_file = config_dir / "config.json"
    if dev:
        # Store project root so the NMH launcher can spawn via repld
        project_root = str(Path(__file__).resolve().parent.parent.parent)
        config = {"dev": True, "project_root": project_root}
        config_file.write_text(json.dumps(config, indent=2) + "\n")
        print(f"\nDev mode: {config_file}")
        print(f"  project_root: {project_root}")
        print("  Daemon will spawn via repld for live introspection")
    else:
        config_file.write_text("{}\n")
        print(f"\nProduction mode: {config_file}")
        print("  Daemon will spawn directly (no repld)")

    ext_path = _extension_path()
    if ext_path:
        print(f"\nExtension path (load unpacked in chrome://extensions):\n  {ext_path}")
    else:
        print(
            "\nExtension files not found — build with 'make build' first",
            file=sys.stderr,
        )
