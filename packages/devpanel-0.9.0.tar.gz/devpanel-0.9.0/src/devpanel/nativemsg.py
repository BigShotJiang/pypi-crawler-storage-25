"""Chrome native messaging: one-shot daemon launcher.

Wire format: 4-byte LE uint32 length prefix + JSON payload on stdin/stdout.
Reads a single message, ensures daemon is running, returns port, exits.
"""

from __future__ import annotations

import json
import os
import signal
import struct
import subprocess
import sys
import time
import urllib.request
from pathlib import Path

SPILL_DIR = Path(os.environ.get("XDG_RUNTIME_DIR", "/tmp")) / "devpanel"
LOCK_FILE = SPILL_DIR / "daemon.lock"


def _expected_version() -> str:
    """Version of the currently installed devpanel package, or empty if unknown."""
    try:
        from importlib.metadata import PackageNotFoundError, version

        return version("devpanel")
    except (ImportError, PackageNotFoundError):
        return ""


def read() -> dict:
    """Read one native message from stdin."""
    raw_len = sys.stdin.buffer.read(4)
    if not raw_len or len(raw_len) < 4:
        raise EOFError
    length = struct.unpack("<I", raw_len)[0]
    payload = sys.stdin.buffer.read(length)
    return json.loads(payload)


def write(msg: dict) -> None:
    """Write one native message to stdout."""
    payload = json.dumps(msg).encode()
    sys.stdout.buffer.write(struct.pack("<I", len(payload)))
    sys.stdout.buffer.write(payload)
    sys.stdout.buffer.flush()


def _pid_alive(pid: int) -> bool:
    try:
        os.kill(pid, 0)
        return True
    except OSError:
        return False


def _probe_health(port: int) -> bool:
    """Check if daemon at given port is healthy."""
    try:
        req = urllib.request.Request(f"http://127.0.0.1:{port}/controls")
        with urllib.request.urlopen(req, timeout=1) as resp:
            return resp.status == 200
    except Exception:
        return False


def _probe_version(port: int) -> str | None:
    """Fetch the running daemon's reported version, or None on failure."""
    try:
        req = urllib.request.Request(f"http://127.0.0.1:{port}/controls")
        with urllib.request.urlopen(req, timeout=1) as resp:
            data = json.loads(resp.read())
        v = data.get("version")
        return v if isinstance(v, str) else None
    except Exception:
        return None


def _kill_pid(pid: int, timeout: float = 2.0) -> bool:
    """SIGTERM then poll; SIGKILL if still alive after timeout. Returns True on exit."""
    try:
        os.kill(pid, signal.SIGTERM)
    except OSError:
        return not _pid_alive(pid)
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if not _pid_alive(pid):
            return True
        time.sleep(0.05)
    try:
        os.kill(pid, signal.SIGKILL)
    except OSError:
        pass
    time.sleep(0.1)
    return not _pid_alive(pid)


def _read_lock() -> dict | None:
    """Read and validate the lock file. Returns {pid, port} or None."""
    try:
        data = json.loads(LOCK_FILE.read_text())
        if _pid_alive(data.get("pid", 0)):
            return data
    except (FileNotFoundError, json.JSONDecodeError, OSError):
        pass
    return None


def _spawn_daemon() -> None:
    """Spawn daemon as a fully detached process.

    Dev mode (devpanel install --dev): spawns via repld for live introspection.
    Uses `uv run --project <root> repld --init repl.py` with the project root
    stored in ~/.config/devpanel/config.json at install time.

    Production mode (devpanel install): spawns `devpanel start` directly.
    """
    from devpanel.install import read_config

    config = read_config()
    if config.get("dev") and config.get("project_root"):
        cmd = _spawn_cmd_dev(config["project_root"])
    else:
        cmd = _spawn_cmd_prod()

    subprocess.Popen(
        cmd,
        start_new_session=True,
        stdin=subprocess.DEVNULL,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        close_fds=True,
    )


def _spawn_cmd_dev(project_root: str) -> list[str]:
    """Dev mode: daemon inside repld kernel for live introspection."""
    socket_path = str(SPILL_DIR / "repld.sock")
    repl_path = str(Path(project_root) / "src" / "devpanel" / "repl.py")
    return [
        "uv",
        "run",
        "--project",
        project_root,
        "repld",
        "--socket",
        socket_path,
        "--init",
        repl_path,
    ]


def _spawn_cmd_prod() -> list[str]:
    """Production mode: plain devpanel start.

    Derives binary path from sys.argv[0] (the NMH invocation) rather than
    shutil.which — macOS Finder launches have minimal PATH and won't find
    ~/.local/bin/devpanel.
    """
    binary = Path(sys.argv[0]).resolve()
    if not binary.is_file():
        # Fallback to PATH search
        import shutil

        found = shutil.which("devpanel")
        if not found:
            raise RuntimeError("devpanel not found")
        binary = Path(found)
    return [str(binary), "start"]


def _wait_for_ready(timeout: float = 5.0) -> int | None:
    """Poll lock file until daemon is ready. Returns port or None."""
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        lock = _read_lock()
        port = lock.get("port") if lock else None
        if port and _probe_health(port):
            return port
        time.sleep(0.1)
    return None


def _ensure_daemon() -> dict:
    """Ensure daemon is running and matches the installed package version.

    If the running daemon's version differs from `importlib.metadata.version`,
    kill it and spawn fresh — covers `uv tool upgrade devpanel` and similar
    reinstall paths where the user expects the new code to take over without
    a manual kill.
    """
    lock = _read_lock()
    if lock:
        port = lock.get("port")
        if port and _probe_health(port):
            running = _probe_version(port)
            expected = _expected_version()
            # Both sides have a version → require match. Either side empty
            # (source-tree dev install) → trust the existing daemon.
            if running and expected and running != expected:
                _kill_pid(lock.get("pid", 0))
                LOCK_FILE.unlink(missing_ok=True)
            else:
                return {"port": port}
        else:
            # Stale lock — daemon crashed
            LOCK_FILE.unlink(missing_ok=True)

    _spawn_daemon()
    port = _wait_for_ready()
    if port is None:
        raise RuntimeError("daemon failed to start")
    return {"port": port}


def serve() -> None:
    """One-shot native messaging handler. Read message, ensure daemon, return port, exit."""
    try:
        msg = read()
    except EOFError:
        return

    msg_type = msg.get("type", "")

    if msg_type == "spawn":
        try:
            result = _ensure_daemon()
            write({"type": "ready", "port": result["port"]})
        except Exception as e:
            write({"type": "error", "message": str(e)})

    elif msg_type == "status":
        lock = _read_lock()
        if lock and _probe_health(lock["port"]):
            write({"type": "status", "running": True, "port": lock["port"]})
        else:
            write({"type": "status", "running": False, "port": None})

    else:
        write({"type": "error", "message": f"unknown message type: {msg_type}"})
