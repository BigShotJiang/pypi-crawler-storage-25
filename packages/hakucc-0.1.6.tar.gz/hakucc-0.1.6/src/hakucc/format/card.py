"""Card JSON construction helpers for Feishu interactive cards."""

from __future__ import annotations

import json
from typing import Any


def build_card(
    markdown: str,
    title: str = "Claude",
    header_icon_img_key: str = "",
    template: str = "blue",
    tags: list[dict[str, str]] | None = None,
    subtitle: str = "",
) -> str:
    """Build a simple markdown card JSON string."""
    header: dict[str, Any] = {
        "title": {"tag": "plain_text", "content": title},
        "template": template,
    }
    if header_icon_img_key:
        header["icon"] = {"tag": "custom_icon", "img_key": header_icon_img_key}
    else:
        header["icon"] = {"tag": "standard_icon", "token": "larkcommunity_colorful"}
    if subtitle:
        header["subtitle"] = {"tag": "plain_text", "content": subtitle}
    if tags:
        header["text_tag_list"] = tags

    card: dict[str, Any] = {
        "schema": "2.0",
        "config": {"wide_screen_mode": True},
        "header": header,
        "body": {"elements": [{"tag": "markdown", "content": markdown}]},
    }
    return json.dumps(card, ensure_ascii=False)


def build_multi_element_card(
    elements: list[dict[str, Any]],
    title: str = "Claude",
    header_icon_img_key: str = "",
    template: str = "blue",
    tags: list[dict[str, str]] | None = None,
) -> str:
    """Build a card with multiple body elements."""
    header: dict[str, Any] = {
        "title": {"tag": "plain_text", "content": title},
        "template": template,
    }
    if header_icon_img_key:
        header["icon"] = {"tag": "custom_icon", "img_key": header_icon_img_key}
    else:
        header["icon"] = {"tag": "standard_icon", "token": "larkcommunity_colorful"}
    if tags:
        header["text_tag_list"] = tags

    card: dict[str, Any] = {
        "schema": "2.0",
        "config": {"wide_screen_mode": True},
        "header": header,
        "body": {"elements": elements},
    }
    return json.dumps(card, ensure_ascii=False)


def build_text_tag(text: str, color: str = "blue") -> dict[str, str]:
    """Build a single header text tag."""
    return {
        "tag": "text_tag",
        "text": {"tag": "plain_text", "content": text},
        "color": color,
    }


def build_hr() -> dict[str, Any]:
    """Build a horizontal rule element."""
    return {"tag": "hr"}


def build_markdown_element(content: str, text_size: str | None = None) -> dict[str, Any]:
    """Build a markdown element."""
    el: dict[str, Any] = {"tag": "markdown", "content": content}
    if text_size:
        el["text_size"] = text_size
    return el


def build_note_element(content: str) -> dict[str, Any]:
    """Build a grey note element."""
    return {
        "tag": "markdown",
        "content": f"<font color='grey'>{content}</font>",
        "text_size": "notation",
    }
