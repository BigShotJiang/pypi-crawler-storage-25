"""Thinking tag parsing and display for Feishu cards."""

from __future__ import annotations

import re
from typing import Any


def parse_thinking(text: str) -> tuple[str, str]:
    """Parse thinking tags from text.

    Returns (thinking_content, remaining_text).
    Handles both <thinking>...</thinking> and Anthropic's extended thinking.
    """
    # Extended thinking blocks (Anthropic format)
    match = re.search(r"<thinking>([\s\S]*?)</thinking>", text)
    if match:
        thinking = match.group(1).strip()
        rest = text[:match.start()] + text[match.end():]
        return thinking, rest.strip()

    # Check for unclosed thinking (streaming)
    match = re.search(r"<thinking>([\s\S]*)", text)
    if match:
        return match.group(1).strip(), text[:match.start()].strip()

    return "", text


def strip_thinking(text: str) -> str:
    """Remove all thinking content from text."""
    # Remove complete blocks
    text = re.sub(r"<thinking>[\s\S]*?</thinking>", "", text)
    # Remove partial blocks (streaming)
    text = re.sub(r"<thinking>[\s\S]*$", "", text)
    return text.strip()


def build_thinking_panel(
    thinking: str,
    duration_ms: int | None = None,
    max_length: int = 3000,
) -> dict[str, Any]:
    """Build a collapsible panel element for thinking content."""
    duration_text = ""
    if duration_ms is not None:
        seconds = duration_ms / 1000
        duration_text = f" {seconds:.1f}s"

    # Truncate long thinking
    display = thinking[:max_length]
    if len(thinking) > max_length:
        display += "..."

    return {
        "tag": "collapsible_panel",
        "expanded": False,
        "background_style": "wathet",
        "header": {
            "title": {"tag": "markdown", "content": f"💭 Thought{duration_text}"},
            "vertical_align": "center",
            "icon": {
                "tag": "standard_icon",
                "token": "down-small-ccm_outlined",
                "size": "16px 16px",
            },
            "icon_position": "follow_text",
            "icon_expanded_angle": -180,
        },
        "border": {"color": "grey", "corner_radius": "5px"},
        "vertical_spacing": "8px",
        "padding": "8px",
        "elements": [
            {"tag": "markdown", "content": display, "text_size": "notation"},
        ],
    }
