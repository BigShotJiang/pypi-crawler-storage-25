"""External image resolution: download → upload to Feishu → replace with img_key."""

from __future__ import annotations

import re

from ..feishu.image import download_and_upload_image
from ..feishu.client import FeishuClient
from .. import logger


async def resolve_external_images(
    client: FeishuClient,
    markdown: str,
    domain: str,
) -> str:
    """Find external image URLs in markdown and replace with Feishu img_key references.

    External images like ![alt](https://example.com/img.png) are converted
    to Feishu internal image format since cards only support internal images.
    """
    if not markdown:
        return markdown

    # Find all external image references
    pattern = r"!\[([^\]]*)\]\((https?://[^)]+)\)"
    matches = list(re.finditer(pattern, markdown))

    if not matches:
        return markdown

    for match in matches:
        alt_text = match.group(1)
        url = match.group(2)

        # Skip blob/data URLs
        if url.startswith(("blob:", "data:")):
            markdown = markdown.replace(match.group(0), "")
            continue

        # Try to download and upload
        img_key = await download_and_upload_image(client, url, domain)
        if img_key:
            # Replace with Feishu image element reference
            replacement = f"![{alt_text}](img_{img_key})"
            markdown = markdown.replace(match.group(0), replacement)
            logger.tool(f"Resolved external image: {url[:50]}...")
        else:
            # Fallback: convert to plain link
            replacement = f"[{alt_text or 'image'}]({url})"
            markdown = markdown.replace(match.group(0), replacement)

    return markdown


def has_external_images(markdown: str) -> bool:
    """Check if markdown contains external image references."""
    return bool(re.search(r"!\[[^\]]*\]\(https?://[^)]+\)", markdown))
