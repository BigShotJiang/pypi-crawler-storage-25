"""Rich-based colored logger for hakucc."""

from __future__ import annotations

from rich.console import Console
from rich.theme import Theme

_theme = Theme(
    {
        "info": "cyan",
        "success": "green",
        "warn": "yellow",
        "error": "red bold",
        "tool": "magenta",
        "msg": "blue",
        "reply": "green",
        "dim": "dim",
    }
)

_console = Console(theme=_theme)


def info(msg: str) -> None:
    _console.print(f"[info]ℹ  {msg}[/info]")


def success(msg: str) -> None:
    _console.print(f"[success]✔  {msg}[/success]")


def warn(msg: str) -> None:
    _console.print(f"[warn]⚠  {msg}[/warn]")


def error(msg: str) -> None:
    _console.print(f"[error]✖  {msg}[/error]")


def tool(msg: str) -> None:
    _console.print(f"[tool]🔧 {msg}[/tool]")


def msg(msg: str) -> None:
    text = msg[:60] + "…" if len(msg) > 60 else msg
    _console.print(f"[msg]💬 {text}[/msg]")


def reply(msg: str) -> None:
    _console.print(f"[reply]←  {msg}[/reply]")


def dim(msg: str) -> None:
    _console.print(f"[dim]{msg}[/dim]")
