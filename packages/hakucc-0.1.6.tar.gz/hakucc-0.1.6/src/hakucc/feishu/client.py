"""Feishu API client wrapper using lark-oapi async."""

from __future__ import annotations

import json
from typing import Any

import lark_oapi as lark
from lark_oapi.api.im.v1 import (
    CreateMessageRequest,
    CreateMessageRequestBody,
    ReplyMessageRequest,
    ReplyMessageRequestBody,
    PatchMessageRequest,
    PatchMessageRequestBody,
    CreateMessageReactionRequest,
    CreateMessageReactionRequestBody,
    DeleteMessageReactionRequest,
    GetMessageResourceRequest,
)
from lark_oapi.api.cardkit.v1 import (
    CreateCardRequest,
    CreateCardRequestBody,
    ContentCardElementRequest,
    ContentCardElementRequestBody,
    SettingsCardRequest,
    SettingsCardRequestBody,
    UpdateCardRequest,
    UpdateCardRequestBody,
    Card,
)

from .. import logger


class FeishuClient:
    """Async Feishu client wrapping lark-oapi."""

    def __init__(self, app_id: str, app_secret: str, domain: str):
        self.app_id = app_id
        self.app_secret = app_secret
        self.domain = domain
        self._client = (
            lark.Client.builder()
            .app_id(app_id)
            .app_secret(app_secret)
            .domain(self._map_domain(domain))
            .log_level(lark.LogLevel.WARNING)
            .build()
        )

    @staticmethod
    def _map_domain(domain: str) -> str:
        """Map domain URL to lark-oapi domain constant."""
        if "feishu.cn" in domain:
            return lark.FEISHU_DOMAIN
        return lark.LARK_DOMAIN

    @property
    def raw(self) -> lark.Client:
        """Access the underlying lark-oapi Client."""
        return self._client

    # --- Message operations ---

    async def send_text(self, chat_id: str, text: str) -> str | None:
        """Send a text message to a chat. Returns message_id."""
        resp = await self._client.im.v1.message.acreate(
            CreateMessageRequest.builder()
            .receive_id_type("chat_id")
            .request_body(
                CreateMessageRequestBody.builder()
                .receive_id(chat_id)
                .msg_type("text")
                .content(json.dumps({"text": text}, ensure_ascii=False))
                .build()
            )
            .build()
        )
        if not resp.success():
            logger.error(f"send_text failed: {resp.code} {resp.msg}")
            return None
        return resp.data.message_id

    async def reply_card(self, message_id: str, card_json: str) -> str | None:
        """Reply with an interactive card. Returns message_id."""
        resp = await self._client.im.v1.message.areply(
            ReplyMessageRequest.builder()
            .message_id(message_id)
            .request_body(
                ReplyMessageRequestBody.builder()
                .msg_type("interactive")
                .content(card_json)
                .build()
            )
            .build()
        )
        if not resp.success():
            logger.error(f"reply_card failed: {resp.code} {resp.msg}")
            return None
        return resp.data.message_id

    async def reply_text(self, message_id: str, text: str) -> str | None:
        """Reply with text. Returns message_id."""
        resp = await self._client.im.v1.message.areply(
            ReplyMessageRequest.builder()
            .message_id(message_id)
            .request_body(
                ReplyMessageRequestBody.builder()
                .msg_type("text")
                .content(json.dumps({"text": text}, ensure_ascii=False))
                .build()
            )
            .build()
        )
        if not resp.success():
            logger.error(f"reply_text failed: {resp.code} {resp.msg}")
            return None
        return resp.data.message_id

    async def update_card(self, message_id: str, card_json: str) -> bool:
        """Update an existing card message."""
        resp = await self._client.im.v1.message.apatch(
            PatchMessageRequest.builder()
            .message_id(message_id)
            .request_body(
                PatchMessageRequestBody.builder()
                .content(card_json)
                .build()
            )
            .build()
        )
        if not resp.success():
            logger.error(f"update_card failed: {resp.code} {resp.msg}")
            return False
        return True

    # --- Reaction operations ---

    async def create_reaction(self, message_id: str, emoji_type: str) -> str | None:
        """Add an emoji reaction. Returns reaction_id."""
        resp = await self._client.im.v1.message_reaction.acreate(
            CreateMessageReactionRequest.builder()
            .message_id(message_id)
            .request_body(
                CreateMessageReactionRequestBody.builder()
                .reaction_type({"emoji_type": emoji_type})
                .build()
            )
            .build()
        )
        if not resp.success():
            logger.error(f"create_reaction failed: {resp.code} {resp.msg}")
            return None
        return resp.data.reaction_id

    async def delete_reaction(self, message_id: str, reaction_id: str) -> bool:
        """Remove an emoji reaction."""
        resp = await self._client.im.v1.message_reaction.adelete(
            DeleteMessageReactionRequest.builder()
            .message_id(message_id)
            .reaction_id(reaction_id)
            .build()
        )
        if not resp.success():
            logger.error(f"delete_reaction failed: {resp.code} {resp.msg}")
            return False
        return True

    # --- Resource download ---

    async def download_resource(
        self, message_id: str, file_key: str, resource_type: str = "image"
    ) -> bytes | None:
        """Download a message resource (image or file). Returns raw bytes."""
        resp = await self._client.im.v1.message_resource.aget(
            GetMessageResourceRequest.builder()
            .message_id(message_id)
            .file_key(file_key)
            .type(resource_type)
            .build()
        )
        if not resp.success():
            logger.error(f"download_resource failed: {resp.code} {resp.msg}")
            return None
        return resp.file.read()

    # --- CardKit operations ---

    async def cardkit_create(self, card_json: str) -> str | None:
        """Create a CardKit card. Returns card_id."""
        resp = await self._client.cardkit.v1.card.acreate(
            CreateCardRequest.builder()
            .request_body(
                CreateCardRequestBody.builder()
                .type("card_json")
                .data(card_json)
                .build()
            )
            .build()
        )
        if not resp.success():
            logger.error(f"cardkit_create failed: {resp.code} {resp.msg}")
            return None
        return resp.data.card_id

    async def cardkit_update_element(
        self, card_id: str, element_id: str, content: str, sequence: int
    ) -> bool:
        """Stream content to a CardKit card element."""
        resp = await self._client.cardkit.v1.card_element.acontent(
            ContentCardElementRequest.builder()
            .card_id(card_id)
            .element_id(element_id)
            .request_body(
                ContentCardElementRequestBody.builder()
                .content(content)
                .sequence(sequence)
                .build()
            )
            .build()
        )
        if not resp.success():
            logger.error(f"cardkit_update_element failed: {resp.code} {resp.msg}")
            return False
        return True

    async def cardkit_settings(
        self, card_id: str, settings: dict[str, Any], sequence: int
    ) -> bool:
        """Update CardKit card settings (e.g., close streaming)."""
        resp = await self._client.cardkit.v1.card.asettings(
            SettingsCardRequest.builder()
            .card_id(card_id)
            .request_body(
                SettingsCardRequestBody.builder()
                .settings(json.dumps(settings, ensure_ascii=False))
                .sequence(sequence)
                .build()
            )
            .build()
        )
        if not resp.success():
            logger.error(f"cardkit_settings failed: {resp.code} {resp.msg}")
            return False
        return True

    async def cardkit_update(
        self, card_id: str, card_json: str, sequence: int
    ) -> bool:
        """Full update a CardKit card."""
        resp = await self._client.cardkit.v1.card.aupdate(
            UpdateCardRequest.builder()
            .card_id(card_id)
            .request_body(
                UpdateCardRequestBody.builder()
                .card(
                    Card.builder()
                    .type("card_json")
                    .data(card_json)
                    .build()
                )
                .sequence(sequence)
                .build()
            )
            .build()
        )
        if not resp.success():
            logger.error(f"cardkit_update failed: {resp.code} {resp.msg}")
            return False
        return True
