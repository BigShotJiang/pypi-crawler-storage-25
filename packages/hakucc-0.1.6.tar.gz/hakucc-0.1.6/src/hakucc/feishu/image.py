"""Image download, upload, and format detection for Feishu."""

from __future__ import annotations

import base64

import httpx

from .client import FeishuClient
from .. import logger

# Magic bytes → MIME type mapping
_MAGIC_MAP: list[tuple[bytes, str]] = [
    (b"\x89PNG\r\n\x1a\n", "image/png"),
    (b"GIF87a", "image/gif"),
    (b"GIF89a", "image/gif"),
    (b"RIFF", "image/webp"),  # RIFF....WEBP
]


def detect_mime(data: bytes) -> str:
    """Detect image MIME type from magic bytes."""
    for magic, mime in _MAGIC_MAP:
        if data[: len(magic)] == magic:
            # Special case: RIFF header needs WEBP check
            if magic == b"RIFF" and data[8:12] != b"WEBP":
                continue
            return mime
    return "image/jpeg"


def image_to_base64(data: bytes, media_type: str | None = None) -> dict[str, str]:
    """Convert raw image bytes to base64 data URI dict."""
    mime = media_type or detect_mime(data)
    b64 = base64.b64encode(data).decode("ascii")
    return {"base64": b64, "media_type": mime}


async def download_image(
    client: FeishuClient,
    message_id: str,
    image_key: str,
) -> dict[str, str] | None:
    """Download an image from Feishu and return base64 + media_type."""
    data = await client.download_resource(message_id, image_key, "image")
    if not data:
        logger.error(f"Failed to download image: {image_key}")
        return None
    return image_to_base64(data)


async def download_and_upload_image(
    client: FeishuClient,
    url: str,
    domain: str,
) -> str | None:
    """Download an external image and upload to Feishu to get an img_key."""
    try:
        proxy = _detect_proxy()
        kwargs: dict = {"timeout": 15}
        if proxy:
            kwargs["proxy"] = proxy

        async with httpx.AsyncClient(**kwargs) as http:
            resp = await http.get(url, follow_redirects=True)
            resp.raise_for_status()
            data = resp.content

        mime = detect_mime(data)

        # Convert PNG to JPEG if needed (Feishu prefers JPEG for cards)
        if mime == "image/png" and len(data) > 100 * 1024:  # > 100KB
            try:
                data = _png_to_jpeg(data)
                mime = "image/jpeg"
            except Exception:
                pass  # keep original

        # Upload to Feishu
        import io
        from lark_oapi.api.im.v1 import CreateImageRequest, CreateImageRequestBody

        resp_upload = await client.raw.im.v1.image.acreate(
            CreateImageRequest.builder()
            .request_body(
                CreateImageRequestBody.builder()
                .image_type("message")
                .image(io.BytesIO(data))
                .build()
            )
            .build()
        )

        if resp_upload.success():
            return resp_upload.data.image_key
        else:
            logger.error(f"Image upload failed: {resp_upload.code} {resp_upload.msg}")
            return None

    except Exception as e:
        logger.error(f"Download/upload image failed: {e}")
        return None


def _png_to_jpeg(data: bytes) -> bytes:
    """Convert PNG to JPEG using Pillow."""
    try:
        from PIL import Image
        import io
        img = Image.open(io.BytesIO(data))
        if img.mode in ("RGBA", "P"):
            img = img.convert("RGB")
        buf = io.BytesIO()
        img.save(buf, format="JPEG", quality=85)
        return buf.getvalue()
    except ImportError:
        raise RuntimeError("Pillow required for PNG→JPEG conversion")


def _detect_proxy() -> str | None:
    import os
    return os.environ.get("https_proxy") or os.environ.get("HTTPS_PROXY")
