"""Feishu cloud document creation for overflow content.

Primary path: Feishu MCP service (JSON-RPC)
Fallback path: REST API (lark-oapi docx)
"""

from __future__ import annotations

import json
import time
from datetime import datetime
from pathlib import Path
from typing import Any

import httpx

from .client import FeishuClient
from ..config import ResolvedConfig
from .. import logger
from ..format.document import markdown_to_blocks


# ---------------------------------------------------------------------------
# Tenant token cache
# ---------------------------------------------------------------------------

_token_cache: dict[str, tuple[str, float]] = {}


async def _get_tenant_token(client: FeishuClient) -> str | None:
    """Get tenant access token with 5-minute cache."""
    cache_key = client.app_id
    if cache_key in _token_cache:
        token, expire_at = _token_cache[cache_key]
        if time.time() < expire_at:
            return token

    try:
        async with httpx.AsyncClient(timeout=10) as http:
            resp = await http.post(
                f"{client.domain}/open-apis/auth/v3/tenant_access_token/internal",
                json={"app_id": client.app_id, "app_secret": client.app_secret},
            )
            data = resp.json()
            if data.get("code") == 0:
                token = data["tenant_access_token"]
                expire = data.get("expire", 7200)
                _token_cache[cache_key] = (token, time.time() + expire - 300)
                return token
            else:
                logger.error(f"Token request failed: {data.get('msg')}")
                return None
    except Exception as e:
        logger.error(f"Token request error: {e}")
        return None


# ---------------------------------------------------------------------------
# Document registry (track created docs for cleanup)
# ---------------------------------------------------------------------------


def _load_registry(registry_file: Path) -> list[dict[str, Any]]:
    """Load document registry."""
    if registry_file.exists():
        try:
            return json.loads(registry_file.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, KeyError):
            return []
    return []


def _save_registry(registry_file: Path, entries: list[dict[str, Any]]) -> None:
    """Save document registry."""
    registry_file.parent.mkdir(parents=True, exist_ok=True)
    registry_file.write_text(
        json.dumps(entries, indent=2, ensure_ascii=False),
        encoding="utf-8",
    )


def _register_doc(registry_file: Path, doc_id: str) -> None:
    """Register a created document."""
    entries = _load_registry(registry_file)
    entries.append({"doc_id": doc_id, "created_at": time.time()})
    _save_registry(registry_file, entries)


# ---------------------------------------------------------------------------
# Create document via MCP
# ---------------------------------------------------------------------------


async def _create_via_mcp(
    client: FeishuClient,
    title: str,
    markdown: str,
) -> str | None:
    """Create a document using the Feishu MCP service (JSON-RPC)."""
    token = await _get_tenant_token(client)
    if not token:
        return None

    try:
        async with httpx.AsyncClient(timeout=30) as http:
            resp = await http.post(
                "https://mcp.feishu.cn/mcp",
                json={
                    "jsonrpc": "2.0",
                    "id": 1,
                    "method": "tools/call",
                    "params": {
                        "name": "create-doc",
                        "arguments": {
                            "title": title,
                            "markdown": markdown,
                        },
                    },
                },
                headers={
                    "X-Lark-MCP-TAT": token,
                    "X-Lark-MCP-Allowed-Tools": "create-doc",
                    "Content-Type": "application/json",
                },
            )
            data = resp.json()
            result = data.get("result", {})
            url = result.get("url") or result.get("document_url", "")
            if url:
                return url

            logger.warn(f"MCP create-doc unexpected response: {json.dumps(data)[:200]}")
            return None

    except Exception as e:
        logger.warn(f"MCP create-doc failed: {e}")
        return None


# ---------------------------------------------------------------------------
# Create document via REST API (fallback)
# ---------------------------------------------------------------------------


async def _create_via_rest(
    client: FeishuClient,
    title: str,
    markdown: str,
) -> str | None:
    """Create a document using the Feishu DocX REST API (fallback)."""
    token = await _get_tenant_token(client)
    if not token:
        return None

    # Create empty document
    try:
        async with httpx.AsyncClient(timeout=15) as http:
            resp = await http.post(
                f"{client.domain}/open-apis/docx/v1/documents",
                headers={
                    "Authorization": f"Bearer {token}",
                    "Content-Type": "application/json",
                },
                json={"title": title},
            )
            data = resp.json()
            if data.get("code") != 0:
                logger.error(f"Doc create failed: {data.get('msg')}")
                return None

            doc = data.get("data", {}).get("document", {})
            doc_id = doc.get("document_id", "")
            if not doc_id:
                return None

    except Exception as e:
        logger.error(f"Doc create error: {e}")
        return None

    # Write blocks
    blocks = markdown_to_blocks(markdown)
    if not blocks:
        return f"https://open.feishu.cn/docx/{doc_id}" if "feishu" in client.domain else f"https://open.larksuite.com/docx/{doc_id}"

    # Batch write blocks (max 50 per request)
    parent_id = doc_id
    for offset in range(0, len(blocks), 50):
        batch = blocks[offset : offset + 50]
        try:
            async with httpx.AsyncClient(timeout=30) as http:
                resp = await http.post(
                    f"{client.domain}/open-apis/docx/v1/documents/{doc_id}/blocks/{parent_id}/children",
                    headers={
                        "Authorization": f"Bearer {token}",
                        "Content-Type": "application/json",
                    },
                    json={"children": batch},
                )
                data = resp.json()
                if data.get("code") != 0:
                    logger.warn(f"Block write failed: {data.get('msg')}")
        except Exception as e:
            logger.warn(f"Block write error: {e}")

    domain_host = "feishu.cn" if "feishu" in client.domain else "larksuite.com"
    return f"https://open.{domain_host}/docx/{doc_id}"


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


async def create_document_with_content(
    client: FeishuClient,
    config: ResolvedConfig,
    markdown: str,
    profile: str,
    cwd: str,
) -> str | None:
    """Create a cloud document with the given markdown content.

    Tries MCP first, falls back to REST API.
    Returns the document URL.
    """
    doc_config = config.overflow.document

    # Build title from template
    now = datetime.now()
    title = doc_config.title_template.format(
        date=now.strftime("%Y-%m-%d"),
        time=now.strftime("%H:%M"),
        profile=profile,
        cwd=Path(cwd).name,
    )

    # Build header with metadata
    header = "\n".join([
        f"**Profile**: {profile}",
        f"**Working Directory**: `{cwd}`",
        f"**Time**: {now.strftime('%Y-%m-%d %H:%M:%S')}",
        "",
        "---",
        "",
    ])
    full_markdown = header + markdown

    # Try MCP first
    url = await _create_via_mcp(client, title, full_markdown)

    # Fallback to REST
    if not url:
        logger.info("MCP failed, falling back to REST API")
        url = await _create_via_rest(client, title, full_markdown)

    if url:
        # Register for cleanup
        _register_doc(config.doc_registry_file, url)
        logger.success(f"Document created: {url}")

    return url


async def cleanup_old_documents(
    client: FeishuClient,
    config: ResolvedConfig,
) -> int:
    """Clean up old overflow documents based on config."""
    registry_file = config.doc_registry_file
    entries = _load_registry(registry_file)
    if not entries:
        return 0

    max_docs = config.overflow.document.cleanup_max_docs
    if len(entries) <= max_docs:
        return 0

    # Delete oldest entries
    to_delete = entries[: len(entries) - max_docs]
    token = await _get_tenant_token(client)
    if not token:
        return 0

    deleted = 0
    for entry in to_delete:
        doc_id = entry.get("doc_id", "")
        if not doc_id:
            continue

        # Extract doc_id from URL if needed
        if "/" in doc_id:
            doc_id = doc_id.rsplit("/", 1)[-1]

        try:
            async with httpx.AsyncClient(timeout=10) as http:
                await http.delete(
                    f"{client.domain}/open-apis/drive/v1/files/{doc_id}",
                    headers={"Authorization": f"Bearer {token}"},
                    params={"type": "docx"},
                )
                deleted += 1
        except Exception:
            pass

    # Update registry
    remaining = entries[len(entries) - max_docs :]
    _save_registry(registry_file, remaining)

    return deleted
