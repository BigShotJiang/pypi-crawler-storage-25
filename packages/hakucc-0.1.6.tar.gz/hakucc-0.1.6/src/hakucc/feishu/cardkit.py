"""CardKit streaming controller for real-time card updates.

Manages the lifecycle of a single streaming card:
  idle → creating → streaming → completed / aborted

Features:
- Lazy card creation (first append triggers create)
- Mutex-protected sequence numbering
- Adaptive flush throttling
- Overflow detection
- Graceful error fallback to plain messages
"""

from __future__ import annotations

import asyncio
import json
import time
from enum import Enum, auto
from typing import Any

from .client import FeishuClient
from .. import logger


class CardKitState(Enum):
    IDLE = auto()
    CREATING = auto()
    STREAMING = auto()
    COMPLETED = auto()
    ABORTED = auto()


class CardKitController:
    """Controls a single CardKit streaming card."""

    def __init__(
        self,
        client: FeishuClient,
        message_id: str,
        title: str = "Claude",
        header_icon_img_key: str = "",
        element_id: str = "stream_content",
        flush_interval_ms: int = 300,
        max_tables_per_card: int = 5,
        overflow_threshold: int = 8000,
    ):
        self._client = client
        self._message_id = message_id
        self._title = title
        self._header_icon_img_key = header_icon_img_key
        self._element_id = element_id
        self._flush_interval = flush_interval_ms / 1000.0
        self._max_tables = max_tables_per_card
        self._overflow_threshold = overflow_threshold

        self._state = CardKitState.IDLE
        self._card_id: str | None = None
        self._reply_msg_id: str | None = None
        self._seq = 0
        self._last_flush = 0.0
        self._pending_text = ""
        self._lock = asyncio.Lock()
        self._flush_task: asyncio.Task | None = None
        self._current_markdown = ""
        self._error_count = 0

    @property
    def state(self) -> CardKitState:
        return self._state

    @property
    def is_active(self) -> bool:
        return self._state in (CardKitState.CREATING, CardKitState.STREAMING)

    async def append(self, text: str) -> None:
        """Append streaming text. Creates the card lazily on first call."""
        if self._state in (CardKitState.COMPLETED, CardKitState.ABORTED):
            return

        self._current_markdown = text

        if self._state == CardKitState.IDLE:
            await self._create_card()

        if self._state != CardKitState.STREAMING:
            return

        # Throttle: only flush if enough time has passed or text is short
        now = time.time()
        if now - self._last_flush < self._flush_interval:
            return

        await self._flush()

    async def _create_card(self) -> None:
        """Create the initial streaming card."""
        self._state = CardKitState.CREATING

        card = self._build_streaming_card("")

        card_id = await self._client.cardkit_create(card)
        if not card_id:
            logger.warn("CardKit create failed, falling back to non-streaming")
            self._state = CardKitState.ABORTED
            return

        self._card_id = card_id

        # Send card as a reply
        card_msg = json.dumps({
            "type": "card",
            "data": {"card_id": card_id},
        })
        self._reply_msg_id = await self._client.reply_card(self._message_id, card_msg)

        if not self._reply_msg_id:
            logger.warn("CardKit reply failed, aborting streaming")
            self._state = CardKitState.ABORTED
            return

        self._state = CardKitState.STREAMING
        self._last_flush = time.time()
        logger.tool("CardKit streaming started")

    async def _flush(self) -> None:
        """Flush current markdown to the card element."""
        if not self._card_id:
            return

        async with self._lock:
            self._seq += 1
            seq = self._seq

        try:
            # Optimize markdown for card display
            content = self._optimize_for_card(self._current_markdown)

            ok = await self._client.cardkit_update_element(
                self._card_id, self._element_id, content, seq
            )

            if not ok:
                self._error_count += 1
                if self._error_count >= 3:
                    logger.warn("CardKit too many errors, aborting streaming")
                    self._state = CardKitState.ABORTED
            else:
                self._error_count = 0

            self._last_flush = time.time()

        except Exception as e:
            logger.warn(f"CardKit flush error: {e}")
            self._error_count += 1

    async def complete(
        self,
        final_markdown: str | None = None,
        tags: list[dict[str, str]] | None = None,
        thinking: str | None = None,
        thinking_duration_ms: int | None = None,
        stats: dict[str, Any] | None = None,
    ) -> None:
        """Complete the streaming card with final content."""
        if self._state not in (CardKitState.STREAMING, CardKitState.CREATING):
            return

        self._state = CardKitState.COMPLETED

        if not self._card_id:
            return

        try:
            # Build final card with header tags, thinking, etc.
            final_card = self._build_final_card(
                final_markdown or self._current_markdown,
                tags=tags,
                thinking=thinking,
                thinking_duration_ms=thinking_duration_ms,
                stats=stats,
            )

            async with self._lock:
                self._seq += 1
                seq = self._seq

            # Update card with final content
            await self._client.cardkit_update(self._card_id, final_card, seq)

            # Close streaming mode
            settings = {"streaming_mode": False}
            async with self._lock:
                self._seq += 1
                seq = self._seq
            await self._client.cardkit_settings(self._card_id, settings, seq)

            logger.tool("CardKit streaming completed")

        except Exception as e:
            logger.warn(f"CardKit complete error: {e}")

    async def abort(self) -> None:
        """Abort streaming."""
        if self._state == CardKitState.IDLE:
            return
        self._state = CardKitState.ABORTED
        logger.tool("CardKit streaming aborted")

    def _build_streaming_card(self, initial_content: str) -> str:
        """Build the streaming card JSON."""
        card: dict[str, Any] = {
            "schema": "2.0",
            "config": {
                "wide_screen_mode": True,
                "streaming_mode": True,
                "update_multi": True,
            },
            "header": {
                "title": {"tag": "plain_text", "content": self._title},
                "template": "blue",
            },
            "body": {
                "elements": [
                    {
                        "tag": "markdown",
                        "element_id": self._element_id,
                        "content": initial_content or " ",
                    }
                ]
            },
        }

        if self._header_icon_img_key:
            card["header"]["icon"] = {"tag": "custom_icon", "img_key": self._header_icon_img_key}
        else:
            card["header"]["icon"] = {"tag": "standard_icon", "token": "larkcommunity_colorful"}

        return json.dumps(card, ensure_ascii=False)

    def _build_final_card(
        self,
        markdown: str,
        tags: list[dict[str, str]] | None = None,
        thinking: str | None = None,
        thinking_duration_ms: int | None = None,
        stats: dict[str, Any] | None = None,
    ) -> str:
        """Build the final complete card JSON."""
        elements: list[dict[str, Any]] = []

        if thinking:
            duration_text = ""
            if thinking_duration_ms is not None:
                duration_text = f" {thinking_duration_ms / 1000:.1f}s"
            display = thinking[:3000] + "..." if len(thinking) > 3000 else thinking
            elements.append({
                "tag": "collapsible_panel",
                "expanded": False,
                "background_style": "wathet",
                "header": {
                    "title": {"tag": "markdown", "content": f"💭 Thought{duration_text}"},
                    "vertical_align": "center",
                    "icon": {
                        "tag": "standard_icon",
                        "token": "down-small-ccm_outlined",
                        "size": "16px 16px",
                    },
                    "icon_position": "follow_text",
                    "icon_expanded_angle": -180,
                },
                "border": {"color": "grey", "corner_radius": "5px"},
                "vertical_spacing": "8px",
                "padding": "8px",
                "elements": [
                    {"tag": "markdown", "content": display, "text_size": "notation"},
                ],
            })
            elements.append({"tag": "hr"})

        elements.append({
            "tag": "markdown",
            "element_id": self._element_id,
            "content": self._optimize_for_card(markdown),
        })

        if stats:
            elements.append({"tag": "hr"})
            parts = []
            if stats.get("input_tokens"):
                parts.append(f"📥 {stats['input_tokens']:,}")
            if stats.get("output_tokens"):
                parts.append(f"📤 {stats['output_tokens']:,}")
            if stats.get("tool_count"):
                parts.append(f"🔧 {stats['tool_count']}")
            if parts:
                elements.append({
                    "tag": "markdown",
                    "content": f"<font color='grey'>{' · '.join(parts)}</font>",
                    "text_size": "notation",
                })

        header: dict[str, Any] = {
            "title": {"tag": "plain_text", "content": self._title},
            "template": "green",
        }
        if self._header_icon_img_key:
            header["icon"] = {"tag": "custom_icon", "img_key": self._header_icon_img_key}
        else:
            header["icon"] = {"tag": "standard_icon", "token": "larkcommunity_colorful"}
        if tags:
            header["text_tag_list"] = tags

        card: dict[str, Any] = {
            "schema": "2.0",
            "config": {"wide_screen_mode": True},
            "header": header,
            "body": {"elements": elements},
        }

        return json.dumps(card, ensure_ascii=False)

    @staticmethod
    def _optimize_for_card(markdown: str) -> str:
        """Optimize markdown for Feishu card display."""
        # Demote headings: H1→H4, H2→H5, H3-H6→H5
        import re

        # Protect code blocks
        code_blocks: list[str] = []
        def _save_block(m) -> str:
            code_blocks.append(m.group(0))
            return f"__CODE_BLOCK_{len(code_blocks) - 1}__"

        markdown = re.sub(r"```[\s\S]*?```", _save_block, markdown)

        # Demote headings
        lines = markdown.split("\n")
        for i, line in enumerate(lines):
            m = re.match(r"^(#{1,6})\s", line)
            if m:
                level = len(m.group(1))
                if level == 1:
                    lines[i] = "#### " + line[level + 1:]
                elif level == 2:
                    lines[i] = "##### " + line[level + 1:]
                else:
                    lines[i] = "##### " + line[level + 1:]
        markdown = "\n".join(lines)

        # Remove external images (Feishu doesn't support them)
        markdown = re.sub(r"!\[([^\]]*)\]\(https?://[^)]+\)", r"[\1]", markdown)

        # Remove blob URLs
        markdown = re.sub(r"https?://blob:[^\s)\]]+", "", markdown)

        # Restore code blocks
        for i, block in enumerate(code_blocks):
            markdown = markdown.replace(f"__CODE_BLOCK_{i}__", block)

        # Safe truncation: check for unclosed code blocks
        # Rough check: count ``` occurrences
        triple_backtick_count = len(re.findall(r"```", markdown))
        if triple_backtick_count % 2 != 0:
            markdown += "\n```"

        return markdown
