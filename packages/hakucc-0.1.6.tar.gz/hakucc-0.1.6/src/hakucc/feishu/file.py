"""File download and MIME type detection for Feishu."""

from __future__ import annotations

import re
import time
from dataclasses import dataclass
from pathlib import Path

from .client import FeishuClient
from .. import logger

# Extension → MIME type mapping (40+ types)
_MIME_MAP: dict[str, str] = {
    ".pdf": "application/pdf",
    ".doc": "application/msword",
    ".docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    ".xls": "application/vnd.ms-excel",
    ".xlsx": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    ".ppt": "application/vnd.ms-powerpoint",
    ".pptx": "application/vnd.openxmlformats-officedocument.presentationml.presentation",
    ".txt": "text/plain",
    ".md": "text/markdown",
    ".csv": "text/csv",
    ".json": "application/json",
    ".xml": "application/xml",
    ".yaml": "text/yaml",
    ".yml": "text/yaml",
    ".js": "text/javascript",
    ".ts": "text/typescript",
    ".py": "text/x-python",
    ".java": "text/x-java-source",
    ".go": "text/x-go",
    ".rs": "text/x-rust",
    ".c": "text/x-c",
    ".cpp": "text/x-c++",
    ".h": "text/x-c",
    ".hpp": "text/x-c++",
    ".sh": "text/x-shellscript",
    ".bash": "text/x-shellscript",
    ".zsh": "text/x-shellscript",
    ".sql": "text/x-sql",
    ".html": "text/html",
    ".css": "text/css",
    ".toml": "text/x-toml",
    ".ini": "text/x-ini",
    ".cfg": "text/x-ini",
    ".conf": "text/plain",
    ".rb": "text/x-ruby",
    ".php": "text/x-php",
    ".swift": "text/x-swift",
    ".kt": "text/x-kotlin",
    ".dart": "text/x-dart",
    ".r": "text/x-r",
    ".lua": "text/x-lua",
    ".zip": "application/zip",
    ".tar": "application/x-tar",
    ".gz": "application/gzip",
    ".rar": "application/x-rar-compressed",
    ".7z": "application/x-7z-compressed",
    ".png": "image/png",
    ".jpg": "image/jpeg",
    ".jpeg": "image/jpeg",
    ".gif": "image/gif",
    ".webp": "image/webp",
    ".svg": "image/svg+xml",
}


@dataclass
class DownloadedFile:
    filepath: str
    filename: str
    size: int
    mime_type: str
    file_key: str


def detect_mime(filename: str) -> str:
    """Detect MIME type from filename extension."""
    ext = Path(filename).suffix.lower()
    return _MIME_MAP.get(ext, "application/octet-stream")


def sanitize_filename(name: str) -> str:
    """Sanitize a filename for safe filesystem use."""
    # Remove path separators and null bytes
    name = re.sub(r'[/\\:\0]', '_', name)
    # Trim whitespace
    name = name.strip()
    # Limit length
    if len(name) > 200:
        ext = Path(name).suffix[:10]
        name = name[: 200 - len(ext)] + ext
    return name or "unnamed_file"


async def download_file(
    client: FeishuClient,
    message_id: str,
    file_key: str,
    temp_dir: Path,
    filename: str,
) -> DownloadedFile | None:
    """Download a file from Feishu to a temp directory."""
    data = await client.download_resource(message_id, file_key, "file")
    if not data:
        logger.error(f"Failed to download file: {filename}")
        return None

    safe_name = sanitize_filename(filename)
    timestamp = int(time.time())
    filepath = temp_dir / f"{timestamp}_{safe_name}"

    temp_dir.mkdir(parents=True, exist_ok=True)
    filepath.write_bytes(data)

    mime = detect_mime(filename)

    return DownloadedFile(
        filepath=str(filepath),
        filename=safe_name,
        size=len(data),
        mime_type=mime,
        file_key=file_key,
    )
