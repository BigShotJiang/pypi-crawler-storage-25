"""Feishu emoji reaction lifecycle management."""

from __future__ import annotations

from .client import FeishuClient
from ..config import ReactionConfig


class ReactionManager:
    """Manages emoji reactions on messages."""

    def __init__(self, client: FeishuClient, config: ReactionConfig):
        self._client = client
        self._config = config
        self._reaction_id: str | None = None
        self._message_id: str | None = None

    async def set_processing(self, message_id: str) -> None:
        """Set the processing emoji, removing any previous reaction."""
        await self._clear()
        self._message_id = message_id
        rid = await self._client.create_reaction(message_id, self._config.processing)
        if rid:
            self._reaction_id = rid

    async def set_done(self) -> None:
        """Mark as done: remove processing, add done emoji."""
        await self._clear()
        if self._message_id:
            await self._client.create_reaction(self._message_id, self._config.done)

    async def set_error(self) -> None:
        """Mark as error."""
        await self._clear()
        if self._message_id:
            await self._client.create_reaction(self._message_id, self._config.error)

    async def set_timeout(self) -> None:
        """Mark as timeout."""
        await self._clear()
        if self._message_id:
            await self._client.create_reaction(self._message_id, self._config.timeout)

    async def set_aborted(self) -> None:
        """Mark as aborted."""
        await self._clear()
        if self._message_id:
            await self._client.create_reaction(self._message_id, self._config.aborted)

    async def _clear(self) -> None:
        """Remove the current reaction."""
        if self._reaction_id and self._message_id:
            await self._client.delete_reaction(self._message_id, self._reaction_id)
            self._reaction_id = None
