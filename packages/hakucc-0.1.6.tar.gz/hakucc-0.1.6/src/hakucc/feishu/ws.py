"""Feishu WebSocket long-connection client.

Self-implemented using ``websockets`` because the lark-oapi WSClient is
blocking and lacks a clean stop() API / proxy support.
"""

from __future__ import annotations

import asyncio
import json
from typing import Any, Callable, Coroutine

import httpx
import websockets
from urllib.parse import urlparse

from .. import logger

# ---------------------------------------------------------------------------
# Minimal protobuf encode/decode for pbbp2 Frame & Header
# ---------------------------------------------------------------------------


def _encode_varint(value: int) -> bytes:
    buf = bytearray()
    while value > 0x7F:
        buf.append((value & 0x7F) | 0x80)
        value >>= 7
    buf.append(value & 0x7F)
    return bytes(buf)


def _decode_varint(data: bytes, pos: int) -> tuple[int, int]:
    result = 0
    shift = 0
    while True:
        b = data[pos]
        result |= (b & 0x7F) << shift
        pos += 1
        if not (b & 0x80):
            break
        shift += 7
    return result, pos


def _encode_header(key: str, value: str) -> bytes:
    """Encode a pbbp2.Header (key=field1, value=field2)."""
    buf = bytearray()
    if key:
        buf.append(0x0A)  # field 1, wire type 2 (length-delimited)
        encoded = key.encode("utf-8")
        buf.extend(_encode_varint(len(encoded)))
        buf.extend(encoded)
    if value:
        buf.append(0x12)  # field 2, wire type 2
        encoded = value.encode("utf-8")
        buf.extend(_encode_varint(len(encoded)))
        buf.extend(encoded)
    return bytes(buf)


def _decode_frame(data: bytes) -> dict[str, Any]:
    """Decode a pbbp2.Frame into a dict."""
    frame: dict[str, Any] = {
        "seq_id": 0,
        "log_id": 0,
        "service": 0,
        "method": 0,
        "headers": [],
        "payload_encoding": "",
        "payload_type": "",
        "payload": b"",
    }
    pos = 0
    while pos < len(data):
        tag, pos = _decode_varint(data, pos)
        field = tag >> 3
        wire = tag & 0x07

        if wire == 0:  # varint
            value, pos = _decode_varint(data, pos)
            if field == 1:
                frame["seq_id"] = value
            elif field == 2:
                frame["log_id"] = value
            elif field == 3:
                frame["service"] = value
            elif field == 4:
                frame["method"] = value
        elif wire == 2:  # length-delimited
            length, pos = _decode_varint(data, pos)
            value = data[pos : pos + length]
            pos += length
            if field == 5:
                frame["headers"].append(_decode_header(value))
            elif field == 6:
                frame["payload_encoding"] = value.decode("utf-8", errors="replace")
            elif field == 7:
                frame["payload_type"] = value.decode("utf-8", errors="replace")
            elif field == 8:
                frame["payload"] = value
            elif field == 9:
                frame["log_id_new"] = value.decode("utf-8", errors="replace")
        else:
            # Skip unknown wire types — shouldn't happen in practice
            break

    return frame


def _decode_header(data: bytes) -> dict[str, str]:
    """Decode a pbbp2.Header into {key, value}."""
    header: dict[str, str] = {}
    pos = 0
    while pos < len(data):
        tag, pos = _decode_varint(data, pos)
        field = tag >> 3
        wire = tag & 0x07
        if wire == 2:
            length, pos = _decode_varint(data, pos)
            value = data[pos : pos + length].decode("utf-8", errors="replace")
            pos += length
            if field == 1:
                header["key"] = value
            elif field == 2:
                header["value"] = value
        else:
            break
    return header


def _encode_frame(
    seq_id: int = 0,
    log_id: int = 0,
    service: int = 0,
    method: int = 0,
    headers: list[dict[str, str]] | None = None,
    payload_encoding: str = "",
    payload_type: str = "",
    payload: bytes = b"",
) -> bytes:
    """Encode a pbbp2.Frame."""
    buf = bytearray()

    if seq_id:
        buf.append(0x08)  # field 1, varint
        buf.extend(_encode_varint(seq_id))
    if log_id:
        buf.append(0x10)  # field 2, varint
        buf.extend(_encode_varint(log_id))
    if service:
        buf.append(0x18)  # field 3, varint
        buf.extend(_encode_varint(service))
    if method:
        buf.append(0x20)  # field 4, varint
        buf.extend(_encode_varint(method))

    for h in (headers or []):
        encoded_header = _encode_header(h.get("key", ""), h.get("value", ""))
        buf.append(0x2A)  # field 5, length-delimited
        buf.extend(_encode_varint(len(encoded_header)))
        buf.extend(encoded_header)

    if payload_encoding:
        buf.append(0x32)  # field 6
        encoded = payload_encoding.encode("utf-8")
        buf.extend(_encode_varint(len(encoded)))
        buf.extend(encoded)

    if payload_type:
        buf.append(0x3A)  # field 7
        encoded = payload_type.encode("utf-8")
        buf.extend(_encode_varint(len(encoded)))
        buf.extend(encoded)

    if payload:
        buf.append(0x42)  # field 8
        buf.extend(_encode_varint(len(payload)))
        buf.extend(payload)

    return bytes(buf)


# ---------------------------------------------------------------------------
# Multi-part message reassembly
# ---------------------------------------------------------------------------


class _DataCache:
    """Reassemble multi-part WS frames into a single message."""

    def __init__(self) -> None:
        self._cache: dict[str, dict[int, bytes]] = {}
        self._counts: dict[str, int] = {}

    def add(self, message_id: str, seq: int, sum_parts: int, data: bytes) -> bytes | None:
        """Add a frame part. Returns full payload when complete, None otherwise."""
        if sum_parts <= 1:
            return data

        key = message_id
        if key not in self._cache:
            self._cache[key] = {}
            self._counts[key] = sum_parts

        self._cache[key][seq] = data

        if len(self._cache[key]) >= self._counts[key]:
            parts = self._cache.pop(key)
            del self._counts[key]
            return b"".join(parts[k] for k in sorted(parts))

        return None

    def clear(self) -> None:
        self._cache.clear()
        self._counts.clear()


# ---------------------------------------------------------------------------
# FeishuWS
# ---------------------------------------------------------------------------

EventHandler = Callable[[dict[str, Any]], Coroutine[Any, Any, None]]


class FeishuWS:
    """Feishu long-connection WebSocket client."""

    def __init__(
        self,
        app_id: str,
        app_secret: str,
        domain: str,
        on_event: EventHandler,
        proxy: str | None = None,
    ):
        self._app_id = app_id
        self._app_secret = app_secret
        self._domain = domain
        self._on_event = on_event
        self._proxy = proxy or _detect_proxy()
        self._cache = _DataCache()
        self._ws: websockets.WebSocketClientProtocol | None = None
        self._running = False
        self._ping_interval = 120  # seconds
        self._ping_task: asyncio.Task | None = None
        self._recv_task: asyncio.Task | None = None
        self._seq = 0

    async def start(self) -> None:
        """Connect and start listening."""
        ws_url = await self._get_ws_url()
        if not ws_url:
            logger.error("Failed to get WS endpoint URL")
            return

        self._running = True
        logger.info(f"Connecting to Feishu WS: {ws_url[:50]}...")

        kwargs: dict[str, Any] = {}

        try:
            if self._proxy:
                logger.info(f"Using proxy: {self._proxy}")
                sock = await self._connect_via_proxy(ws_url)
                if sock is None:
                    logger.error("Failed to establish proxy connection")
                    return
                kwargs["sock"] = sock
                kwargs["server_hostname"] = urlparse(ws_url).hostname

            self._ws = await websockets.connect(
                ws_url,
                ping_interval=None,  # we handle pings ourselves
                max_size=10 * 1024 * 1024,  # 10MB
                **kwargs,
            )
            logger.success("Feishu WS connected")

            # Start ping and receive loops
            self._ping_task = asyncio.create_task(self._ping_loop())
            self._recv_task = asyncio.create_task(self._recv_loop())

            await asyncio.gather(self._ping_task, self._recv_task)
        except websockets.ConnectionClosed as e:
            if self._running:
                logger.warn(f"WS closed (code={e.code}), reconnecting...")
                await asyncio.sleep(2)
                await self.start()
        except Exception as e:
            if self._running:
                logger.error(f"WS error: {e}")
                await asyncio.sleep(5)
                await self.start()

    async def stop(self) -> None:
        """Gracefully shut down."""
        self._running = False
        if self._ping_task:
            self._ping_task.cancel()
        if self._recv_task:
            self._recv_task.cancel()
        if self._ws:
            await self._ws.close()
            self._ws = None
        logger.info("Feishu WS disconnected")

    # --- Internal ---

    async def _get_ws_url(self) -> str | None:
        """Fetch WS endpoint URL from Feishu API."""
        url = f"{self._domain}/callback/ws/endpoint"
        try:
            async with httpx.AsyncClient(timeout=15) as client:
                resp = await client.post(
                    url,
                    json={"AppID": self._app_id, "AppSecret": self._app_secret},
                )
                data = resp.json()
                ws_url = data.get("data", {}).get("url") or data.get("data", {}).get("URL")
                if ws_url:
                    config = data.get("data", {}).get("ClientConfig", {})
                    if config.get("PingInterval"):
                        self._ping_interval = config["PingInterval"]
                    return ws_url
                logger.error(f"Bad WS endpoint response: {resp.text[:200]}")
                return None
        except Exception as e:
            logger.error(f"Failed to get WS URL: {e}")
            return None

    async def _ping_loop(self) -> None:
        """Send periodic pings."""
        try:
            while self._running and self._ws:
                await asyncio.sleep(self._ping_interval)
                if not self._running or not self._ws:
                    break
                ping_frame = _encode_frame(
                    method=0,
                    headers=[{"key": "type", "value": "ping"}],
                    payload_encoding="json",
                    payload_type="ping",
                    payload=b"{}",
                )
                try:
                    await self._ws.send(ping_frame)
                except Exception:
                    break
        except asyncio.CancelledError:
            pass

    async def _recv_loop(self) -> None:
        """Receive and dispatch messages."""
        try:
            async for raw in self._ws:
                if not self._running:
                    break
                try:
                    frame = _decode_frame(raw)
                    await self._handle_frame(frame)
                except Exception as e:
                    logger.warn(f"Frame handling error: {e}")
        except asyncio.CancelledError:
            pass
        except websockets.ConnectionClosed:
            raise

    async def _handle_frame(self, frame: dict[str, Any]) -> None:
        """Process a decoded WS frame."""
        headers = {h["key"]: h["value"] for h in frame.get("headers", [])}
        msg_type = headers.get("type", "")
        method = frame.get("method", 0)

        if method == 0:  # control
            if msg_type == "pong":
                payload = frame.get("payload", b"{}")
                try:
                    config = json.loads(payload)
                    if config.get("PingInterval"):
                        self._ping_interval = config["PingInterval"]
                except (json.JSONDecodeError, TypeError):
                    pass
                return
            if msg_type == "ping":
                # Server-initiated ping — respond with pong
                pong_frame = _encode_frame(
                    method=0,
                    headers=[{"key": "type", "value": "pong"}],
                    payload_encoding="json",
                    payload_type="pong",
                    payload=b"{}",
                )
                await self._ws.send(pong_frame)
                return

        if method == 1:  # data
            if msg_type == "event":
                message_id = headers.get("message_id", "")
                seq = int(headers.get("seq", "0"))
                sum_parts = int(headers.get("sum", "1"))
                payload = frame.get("payload", b"")

                complete = self._cache.add(message_id, seq, sum_parts, payload)
                if complete:
                    try:
                        event = json.loads(complete)
                        await self._on_event(event)
                    except (json.JSONDecodeError, TypeError) as e:
                        logger.warn(f"Event parse error: {e}")

    def _next_seq(self) -> int:
        self._seq += 1
        return self._seq


    async def _connect_via_proxy(self, ws_url: str):
        """Create a proxy connection, return a connected socket for websockets.

        Uses raw socket + blocking SOCKS5/HTTP CONNECT handshake in a thread
        to avoid asyncio transport ownership issues.
        """
        parsed = urlparse(ws_url)
        host = parsed.hostname or ""
        port = parsed.port or (443 if parsed.scheme == "wss" else 80)

        proxy_parsed = urlparse(self._proxy)
        proxy_host = proxy_parsed.hostname or ""
        proxy_port = proxy_parsed.port or 1080

        loop = asyncio.get_event_loop()

        if proxy_parsed.scheme in ("socks5", "socks5h"):
            import socket
            import socksio

            def _socks5_connect() -> socket.socket | None:
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.settimeout(10)
                sock.connect((proxy_host, proxy_port))
                conn = socksio.SOCKS5Connection()
                conn.connect(
                    socksio.SOCKS5Command.CONNECT,
                    host=socksio.SOCKS5Address(host, port),
                )
                sock.sendall(conn.data_to_send())
                resp = sock.recv(1024)
                conn.receive_data(resp)
                sock.setblocking(False)
                return sock

            try:
                return await loop.run_in_executor(None, _socks5_connect)
            except Exception as e:
                logger.error(f"SOCKS5 proxy connection failed: {e}")
                return None
        else:
            # HTTP CONNECT proxy
            import socket

            def _http_connect() -> socket.socket | None:
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.settimeout(10)
                sock.connect((proxy_host, proxy_port))
                req = f"CONNECT {host}:{port} HTTP/1.1\r\nHost: {host}:{port}\r\n\r\n"
                sock.sendall(req.encode())
                resp = sock.recv(4096)
                if b"200" not in resp:
                    return None
                sock.setblocking(False)
                return sock

            try:
                sock = await loop.run_in_executor(None, _http_connect)
                if sock is None:
                    logger.error(f"HTTP CONNECT proxy failed for {host}:{port}")
                return sock
            except Exception as e:
                logger.error(f"HTTP proxy connection failed: {e}")
                return None


def _detect_proxy() -> str | None:
    """Detect proxy from environment."""
    import os
    return os.environ.get("https_proxy") or os.environ.get("HTTPS_PROXY") or None
