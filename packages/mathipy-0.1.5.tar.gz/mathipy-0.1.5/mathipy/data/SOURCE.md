SOURCE: U.S. Department of Education, Institute of Education Sciences,
National Center for Education Statistics, National Assessment of Educational
Progress (NAEP), 2017, 2022, and 2024 Mathematics Assessments.

Items obtained from the NAEP Questions Tool (https://www.nationsreportcard.gov/nqt/).

NAEP released items are in the public domain per the NAEP Questions Tool
Copyright Policy. This sample dataset contains 5 items selected to
demonstrate MathiPy's feature extraction capabilities.
