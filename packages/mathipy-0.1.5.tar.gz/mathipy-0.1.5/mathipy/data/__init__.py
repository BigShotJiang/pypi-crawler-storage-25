"""Sample NAEP assessment items for demonstrating MathiPy features."""

import re
from pathlib import Path

data_dir = Path(__file__).parent


def get_sample_csv() -> Path:
    """Return the path to the sample NAEP CSV file."""
    return data_dir / "naep_sample.csv"


def get_sample_image(item_id: str) -> Path:
    """Return the path to a sample NAEP item image by item ID (e.g., ``"2024-4M10 #2"``)."""
    if not re.match(r'^[a-zA-Z0-9_\-\s#]+$', item_id):
        raise ValueError(f"Invalid item_id: {item_id}")
    path = data_dir / f"{item_id}.png"
    if not path.resolve().is_relative_to(data_dir.resolve()):
        raise ValueError(f"Invalid item_id: {item_id}")
    return path


def list_sample_images() -> list[str]:
    """Return a sorted list of available sample image filenames."""
    return sorted(p.name for p in data_dir.glob("*.png"))
