"""Tests for mathipy.cognitive_load module."""

from mathipy.cognitive_load import CognitiveLoadEstimator

expected_keys = {
    "numeric_elements", "variable_count", "operation_count",
    "word_count", "sentence_count", "math_term_count",
    "element_density", "avg_sentence_length",
}

simple_text = "What is 3 + 4?"
complex_text = (
    "Given the quadratic equation 2x^2 + 5x - 3 = 0, use the quadratic formula "
    "x = (-b +/- sqrt(b^2 - 4ac)) / 2a to find both solutions for x. "
    "Show all work and simplify your final answers."
)
fraction_text = "What is 3/4 + 1/2? Simplify the fraction to find the sum."


class TestInit:
    def test_constructor(self):
        estimator = CognitiveLoadEstimator()
        assert isinstance(estimator, CognitiveLoadEstimator)


class TestEmptyInput:
    def test_empty_string(self):
        estimator = CognitiveLoadEstimator()
        result = estimator.estimate("")
        assert set(result.keys()) == expected_keys
        assert result["numeric_elements"] == 0
        assert result["variable_count"] == 0
        assert result["element_density"] == 0.0

    def test_whitespace_only(self):
        result = CognitiveLoadEstimator().estimate("   ")
        assert result["word_count"] == 0
        assert result["element_density"] == 0.0


class TestElementCounts:
    def test_numeric_elements(self):
        result = CognitiveLoadEstimator().estimate("Add 3, 5, and 10.")
        assert result["numeric_elements"] == 3

    def test_variable_count(self):
        result = CognitiveLoadEstimator().estimate("Solve x + y = z.")
        assert result["variable_count"] == 3

    def test_operation_count(self):
        result = CognitiveLoadEstimator().estimate("3 + 5 - 2 = 6")
        assert result["operation_count"] >= 3

    def test_word_count(self):
        result = CognitiveLoadEstimator().estimate("Find the sum of three numbers.")
        assert result["word_count"] == 6

    def test_sentence_count(self):
        result = CognitiveLoadEstimator().estimate("Add 3 and 5. Show your work.")
        assert result["sentence_count"] == 2


class TestDensity:
    def test_element_density_ratio(self):
        result = CognitiveLoadEstimator().estimate("Add 3 and 5.")
        assert result["element_density"] == result["numeric_elements"] / result["word_count"]

    def test_more_elements_higher_density(self):
        few = CognitiveLoadEstimator().estimate("Add 3 and 5.")
        many = CognitiveLoadEstimator().estimate("Compute 3 + 5 + 7 + 9 + 11 + 13 + 15.")
        assert many["element_density"] >= few["element_density"]

    def test_avg_sentence_length(self):
        result = CognitiveLoadEstimator().estimate("Add three. Then subtract two.")
        assert result["avg_sentence_length"] == result["word_count"] / result["sentence_count"]


class TestMathTermCount:
    def test_with_math_terms(self):
        terms = ["add", "subtract", "multiply", "sum", "product"]
        result = CognitiveLoadEstimator().estimate("test", math_terms=terms)
        assert result["math_term_count"] == 5

    def test_keyword_detection(self):
        result = CognitiveLoadEstimator().estimate(
            "Find the area of the triangle and the perimeter of the circle."
        )
        assert result["math_term_count"] >= 3

    def test_no_keywords(self):
        result = CognitiveLoadEstimator().estimate("The dog ran quickly across the park.")
        assert result["math_term_count"] == 0


class TestComplexVsSimple:
    def test_complex_more_elements(self):
        simple = CognitiveLoadEstimator().estimate(simple_text)
        complex_result = CognitiveLoadEstimator().estimate(complex_text)
        assert complex_result["numeric_elements"] + complex_result["variable_count"] > simple["numeric_elements"] + simple["variable_count"]

    def test_complex_more_operations(self):
        simple = CognitiveLoadEstimator().estimate(simple_text)
        complex_result = CognitiveLoadEstimator().estimate(complex_text)
        assert complex_result["operation_count"] >= simple["operation_count"]


class TestClassBasedAPI:
    def test_estimator_estimate_method(self):
        result = CognitiveLoadEstimator().estimate(fraction_text)
        assert isinstance(result, dict)
        assert set(result.keys()) == expected_keys

    def test_all_optional_params(self):
        result = CognitiveLoadEstimator().estimate(
            simple_text,
            readability_grade=3.5,
            math_terms=["add", "sum"],
        )
        assert result["math_term_count"] == 2
        assert result["element_density"] > 0
