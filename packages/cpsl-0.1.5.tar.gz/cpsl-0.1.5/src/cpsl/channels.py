from __future__ import annotations

from dataclasses import dataclass


@dataclass
class Channel:
    """Base channel class. Apps declare which channels they support at deploy
    time. Each channel type controls delivery semantics (streaming vs sync,
    response format, etc.)."""

    type: str = ""
    supports_streaming: bool = False

    def to_dict(self) -> dict:
        return {"type": self.type, "supports_streaming": self.supports_streaming}


@dataclass
class Chat(Channel):
    """Web chat channel with real-time streaming via SSE."""

    type: str = "chat"
    supports_streaming: bool = True
    welcome: str | None = None
    placeholder: str = "Type a message..."

    def to_dict(self) -> dict:
        d = super().to_dict()
        if self.welcome is not None:
            d["welcome"] = self.welcome
        d["placeholder"] = self.placeholder
        return d


@dataclass
class API(Channel):
    """REST API channel. Synchronous request/response."""

    type: str = "api"
    supports_streaming: bool = False
    auth: str = "bearer"
    rate_limit: int | None = None

    def to_dict(self) -> dict:
        d = super().to_dict()
        d["auth"] = self.auth
        if self.rate_limit is not None:
            d["rate_limit"] = self.rate_limit
        return d
