from __future__ import annotations

from typing import Callable, TypeVar

F = TypeVar("F", bound=Callable)

_BOOT_ATTR = "_cpsl_boot"
_SHUTDOWN_ATTR = "_cpsl_shutdown"
_ENTER_ATTR = "_cpsl_enter"
_EXIT_ATTR = "_cpsl_exit"
_MESSAGE_ATTR = "_cpsl_message"


def boot() -> Callable[[F], F]:
    """Mark a method as the app boot hook (runs once when the runtime starts)."""

    def decorator(fn: F) -> F:
        setattr(fn, _BOOT_ATTR, True)
        return fn

    return decorator


def shutdown() -> Callable[[F], F]:
    """Mark a method as the app shutdown hook (runs on SIGTERM before the runtime goes cold)."""

    def decorator(fn: F) -> F:
        setattr(fn, _SHUTDOWN_ATTR, True)
        return fn

    return decorator


def enter() -> Callable[[F], F]:
    """Mark a method as the per-session entry hook (runs when a session is created
    or rehydrated after a cold wake). Receives ``session`` as its argument."""

    def decorator(fn: F) -> F:
        setattr(fn, _ENTER_ATTR, True)
        return fn

    return decorator


def exit() -> Callable[[F], F]:
    """Mark a method as the per-session exit hook (runs when a session is closed)."""

    def decorator(fn: F) -> F:
        setattr(fn, _EXIT_ATTR, True)
        return fn

    return decorator


def message() -> Callable[[F], F]:
    """Mark a method as the message handler for all channels."""

    def decorator(fn: F) -> F:
        setattr(fn, _MESSAGE_ATTR, True)
        return fn

    return decorator
