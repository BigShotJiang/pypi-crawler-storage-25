import functools
from typing import Any, Callable, List, NewType, Optional, Sequence, Tuple, cast

import grpc
from grpc import ChannelCredentials
from grpc._interceptor import _Channel as InterceptorChannel

from . import terminal
from .config import ConfigContext, get_config_context

GRPC_MAX_MESSAGE_SIZE = 16 * 1024 * 1024

MetadataType = NewType("MetadataType", List[Tuple[Any, Any]])


class Channel(InterceptorChannel):
    def __init__(
        self,
        addr: str,
        token: Optional[str] = None,
        credentials: Optional[ChannelCredentials] = None,
        options: Optional[Sequence[Tuple[str, Any]]] = None,
    ):
        if options is None:
            options = [
                ("grpc.max_receive_message_length", GRPC_MAX_MESSAGE_SIZE),
                ("grpc.max_send_message_length", GRPC_MAX_MESSAGE_SIZE),
            ]

        if credentials is not None:
            channel = grpc.secure_channel(addr, credentials, options=options)
        elif addr.endswith("443"):
            channel = grpc.secure_channel(addr, grpc.ssl_channel_credentials(), options=options)
        else:
            channel = grpc.insecure_channel(addr, options=options)

        interceptor = AuthTokenInterceptor(token)
        super().__init__(channel=channel, interceptor=interceptor)


class AuthTokenInterceptor(
    grpc.UnaryUnaryClientInterceptor,
    grpc.UnaryStreamClientInterceptor,
    grpc.StreamUnaryClientInterceptor,
    grpc.StreamStreamClientInterceptor,
):
    def __init__(self, token: Optional[str] = None):
        self._token = token

    def _add_auth_metadata(self, client_call_details):
        if self._token:
            auth_headers = [("authorization", f"Bearer {self._token}")]
            if client_call_details.metadata is not None:
                new_metadata = client_call_details.metadata + auth_headers
            else:
                new_metadata = auth_headers
        else:
            new_metadata = client_call_details.metadata

        return client_call_details._replace(metadata=cast(MetadataType, new_metadata))

    def intercept_call(self, continuation, client_call_details, request):
        new_details = self._add_auth_metadata(client_call_details)
        return continuation(new_details, request)

    def intercept_call_stream(self, continuation, client_call_details, request_iterator):
        return self.intercept_call(continuation, client_call_details, request=request_iterator)

    intercept_unary_unary = intercept_call
    intercept_unary_stream = intercept_call
    intercept_stream_unary = intercept_call_stream
    intercept_stream_stream = intercept_call_stream


def get_channel(context: Optional[ConfigContext] = None) -> Channel:
    if not context:
        context = get_config_context()

    if not context or not context.is_valid():
        raise RuntimeError("No valid config. Run 'capsule login' first.")

    return Channel(
        addr=f"{context.gateway_host}:{context.gateway_port}",
        token=context.token,
    )


def handle_grpc_error(error: grpc.RpcError) -> None:
    code = error.code()
    details = error.details()

    if code == grpc.StatusCode.UNAUTHENTICATED:
        terminal.error("Unauthorized. Run 'capsule login' to authenticate.")
    elif code == grpc.StatusCode.UNAVAILABLE:
        terminal.error("Unable to connect to gateway.")
    elif code == grpc.StatusCode.CANCELLED:
        return
    else:
        terminal.error(f"gRPC error: {code} — {details}")


class ServiceClient:
    def __init__(self, config: Optional[ConfigContext] = None) -> None:
        self._config = config
        self._channel: Optional[Channel] = None
        self._stub = None

    def __enter__(self) -> "ServiceClient":
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        self.close()

    @classmethod
    def with_channel(cls, channel: Channel) -> "ServiceClient":
        client = cls()
        client.channel = channel
        return client

    @property
    def channel(self) -> Channel:
        if not self._channel:
            self._channel = get_channel(self._config)
        return self._channel

    @channel.setter
    def channel(self, value: Channel) -> None:
        if not value or not isinstance(value, Channel):
            raise ValueError("Invalid channel")
        self._channel = value

    @property
    def capsule(self):
        if not self._stub:
            from .clients.capsule import CapsuleServiceStub

            self._stub = CapsuleServiceStub(self.channel)
        return self._stub

    def close(self) -> None:
        if self._channel:
            self._channel.close()


def pass_service_client(func: Callable) -> Callable:
    """Decorator that creates a ServiceClient and passes it as the first arg."""

    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        ctx = get_config_context()
        if not ctx or not ctx.is_valid():
            terminal.error("Not logged in. Run 'capsule login' first.")
            raise SystemExit(1)

        try:
            with ServiceClient(ctx) as client:
                return func(client, *args, **kwargs)
        except grpc.RpcError as e:
            handle_grpc_error(e)
            raise SystemExit(1)

    return wrapper
