from __future__ import annotations

from typing import Any, Callable, TypeVar

from .channels import Channel
from .image import Image

T = TypeVar("T")

_REGISTERED_CLASSES: list[dict[str, Any]] = []


class App:
    """Lightweight deployment namespace. All deploy config lives on the decorator."""

    def __init__(self, name: str) -> None:
        self.name = name

    def cls(
        self,
        *,
        image: Image,
        price: int = 0,
        channels: list[Channel] | None = None,
    ) -> Callable[[type[T]], type[T]]:
        """Decorator for class-based apps. Captures deploy config."""
        app_name = self.name

        def decorator(klass: type[T]) -> type[T]:
            config = {
                "app_name": app_name,
                "image": image.to_dict(),
                "price": price,
                "channels": [c.to_dict() for c in (channels or [])],
                "module": klass.__module__,
                "class_name": klass.__qualname__,
            }
            klass._cpsl_config = config  # type: ignore[attr-defined]
            _REGISTERED_CLASSES.append(config)
            return klass

        return decorator

    def _serialize(self) -> dict[str, Any] | None:
        """Return the deploy spec for the class registered under this app."""
        for cfg in _REGISTERED_CLASSES:
            if cfg["app_name"] == self.name:
                return cfg
        return None
