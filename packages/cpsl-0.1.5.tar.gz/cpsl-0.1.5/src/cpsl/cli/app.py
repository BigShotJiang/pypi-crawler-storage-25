import click
from rich.table import Table

from .. import terminal
from ..channel import ServiceClient, pass_service_client
from ..clients.capsule import CreateAppRequest, GetAppRequest, ListAppsRequest


@click.group()
def app():
    """Manage apps."""
    pass


@app.command("create")
@click.option("--name", required=True, help="App name")
@click.option("--price", default=100, type=int, help="Price in cents")
@pass_service_client
def create(client: ServiceClient, name: str, price: int):
    """Create a new app."""
    res = client.capsule.create_app(
        CreateAppRequest(name=name, price_in_cents=price)
    )
    if not res.ok:
        terminal.error(f"Failed: {res.err_msg}")
        raise SystemExit(1)

    terminal.success(f"Created app \"{res.app.name}\" at {res.app.hostname}.capsule.new")
    terminal.info(f"  ID:       {res.app.id}")
    terminal.info(f"  Hostname: {res.app.hostname}")
    terminal.info(f"  Price:    {res.app.price_in_cents}¢")


@app.command("list")
@pass_service_client
def list_apps(client: ServiceClient):
    """List your apps."""
    res = client.capsule.list_apps(ListAppsRequest())
    if not res.ok:
        terminal.error(f"Failed: {res.err_msg}")
        raise SystemExit(1)

    if not res.apps:
        terminal.info("No apps yet. Create one with 'capsule app create'.")
        return

    from rich.console import Console

    table = Table(title="Apps")
    table.add_column("Name")
    table.add_column("ID")
    table.add_column("Hostname")
    table.add_column("Price")
    table.add_column("Created")

    for a in res.apps:
        table.add_row(a.name, a.id, a.hostname, f"{a.price_in_cents}¢", a.created_at)

    Console().print(table)


@app.command("get")
@click.argument("app_id")
@pass_service_client
def get(client: ServiceClient, app_id: str):
    """Get details of an app by ID."""
    res = client.capsule.get_app(GetAppRequest(id=app_id))
    if not res.ok:
        terminal.error(f"Failed: {res.err_msg}")
        raise SystemExit(1)

    a = res.app
    terminal.header(a.name)
    terminal.info(f"  ID:       {a.id}")
    terminal.info(f"  Hostname: {a.hostname}")
    terminal.info(f"  Owner:    {a.owner_id}")
    terminal.info(f"  Price:    {a.price_in_cents}¢")
    terminal.info(f"  Created:  {a.created_at}")
