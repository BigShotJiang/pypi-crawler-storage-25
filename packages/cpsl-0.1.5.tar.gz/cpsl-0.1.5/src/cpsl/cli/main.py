import os

os.environ.setdefault("GRPC_VERBOSITY", "ERROR")

import click

from .login import login
from .app import app
from .deploy import deploy


@click.group()
def cli():
    """Capsule CLI — create and manage capsule apps."""
    pass


cli.add_command(login)
cli.add_command(app)
cli.add_command(deploy)


def start():
    cli()
