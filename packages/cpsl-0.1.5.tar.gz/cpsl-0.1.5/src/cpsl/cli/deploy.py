import importlib
import os
import sys
import tempfile
import zipfile
from pathlib import Path

import click

from .. import terminal
from ..channel import pass_service_client, ServiceClient

IGNORE_PATTERNS = {
    ".git", ".venv", "venv", "__pycache__", ".pytest_cache",
    ".ruff_cache", "node_modules", ".DS_Store", ".idea", ".vscode",
    ".env.local", ".envrc", ".next", ".capsuleignore",
}

IGNORE_EXTENSIONS = {".pyc"}


def _resolve_class(entry_point: str) -> dict:
    if ":" not in entry_point:
        terminal.error("Entry point must be <module>:<ClassName>")

    module_path, class_name = entry_point.rsplit(":", 1)

    if "" not in sys.path:
        sys.path.insert(0, "")

    try:
        mod = importlib.import_module(module_path)
    except ImportError as e:
        terminal.error(f"Cannot import module '{module_path}': {e}")

    klass = getattr(mod, class_name, None)
    if klass is None:
        terminal.error(f"Class '{class_name}' not found in module '{module_path}'")

    config = getattr(klass, "_cpsl_config", None)
    if config is None:
        terminal.error(f"Class '{class_name}' is not decorated with @app.cls")

    return config


def _should_ignore(name: str) -> bool:
    if name in IGNORE_PATTERNS:
        return True
    for ext in IGNORE_EXTENSIONS:
        if name.endswith(ext):
            return True
    return False


def _collect_source_archive() -> bytes:
    """ZIP the current working directory, respecting ignore patterns."""
    root = Path.cwd()
    tmp = tempfile.NamedTemporaryFile(delete=False, suffix=".zip")
    tmp.close()
    file_count = 0

    try:
        with zipfile.ZipFile(tmp.name, "w", zipfile.ZIP_DEFLATED) as zf:
            for dirpath, dirnames, filenames in os.walk(root):
                dirnames[:] = [d for d in dirnames if not _should_ignore(d)]
                for fname in filenames:
                    if _should_ignore(fname):
                        continue
                    full = os.path.join(dirpath, fname)
                    rel = os.path.relpath(full, root)
                    zf.write(full, rel)
                    terminal.detail(f"  + {rel}")
                    file_count += 1

        data = Path(tmp.name).read_bytes()
        terminal.detail(
            f"  {file_count} file{'' if file_count == 1 else 's'}, "
            f"{terminal.humanize_memory(len(data), base=10)}"
        )
        return data
    finally:
        os.unlink(tmp.name)


@click.command("deploy")
@click.argument("entry_point")
@pass_service_client
def deploy(client: ServiceClient, entry_point: str):
    """Deploy an app.

    ENTRY_POINT is <module>:<ClassName>, e.g. myapp:OutreachAgent
    """
    config = _resolve_class(entry_point)

    image = config["image"]
    channels = config.get("channels", [])

    terminal.header("Deploying", f"[bold]{config['app_name']}[/bold]")
    terminal.detail(f"  entry:    {config['module']}:{config['class_name']}")
    terminal.detail(f"  price:    {config['price']}¢")
    terminal.detail(f"  channels: {len(channels)}")
    if image.get("python_packages"):
        terminal.detail(f"  pip:      {', '.join(image['python_packages'])}")
    if image.get("apt_packages"):
        terminal.detail(f"  apt:      {', '.join(image['apt_packages'])}")

    # Phase 1: Sync files
    terminal.header("Syncing files")
    archive = _collect_source_archive()

    # Phase 2: Deploy via gRPC
    terminal.header("Pushing")

    from ..clients.capsule import DeployRequest, ImageSpec, ChannelSpec

    req = DeployRequest(
        app_name=config["app_name"],
        image=ImageSpec(
            python_packages=image.get("python_packages", []),
            apt_packages=image.get("apt_packages", []),
            commands=image.get("commands", []),
        ),
        channels=[
            ChannelSpec(type=ch["type"], config={k: str(v) for k, v in ch.items()})
            for ch in channels
        ],
        entry_point=entry_point,
        price_in_cents=config["price"],
        source_archive=archive,
    )

    with terminal.progress("Provisioning sprite..."):
        res = client.capsule.deploy(req)

    if not res.ok:
        terminal.error(f"Deploy failed: {res.err_msg}")

    terminal.header(f"Deployed {config['app_name']} v{res.version} 🎉")
    terminal.info(f"  https://{res.hostname}.capsule.new")
