from __future__ import annotations

from collections.abc import AsyncIterator
from dataclasses import dataclass, field
from typing import Any

from .channels import Channel
from .msg import Message


@dataclass
class UserInfo:
    """Identity of the user who owns this session."""

    id: str
    email: str | None = None

    def to_dict(self) -> dict:
        d: dict[str, Any] = {"id": self.id}
        if self.email is not None:
            d["email"] = self.email
        return d


class Session:
    """Per-conversation context for a user interacting with the app.

    Attributes:
        id: Unique session identifier.
        user: Identity of the user (id, email) — see ``UserInfo``.
        channel: Channel this session is on (chat, api, etc.).
        history: Recent message history, rehydrated from S2.
        data: Persistent key-value dict, saved to S2 after each message.
    """

    def __init__(
        self,
        id: str,
        user: UserInfo,
        channel: Channel,
        history: list[Message] | None = None,
        data: dict[str, Any] | None = None,
    ) -> None:
        self.id = id
        self.user = user
        self.channel = channel
        self.history: list[Message] = history if history is not None else []
        self.data: dict[str, Any] = data if data is not None else {}
        self._reply_callback: Any = None
        self._stream_callback: Any = None

    async def reply(self, text: str) -> None:
        """Send a complete message. Appends to S2 stream, delivers through channel."""
        msg = Message(text=text, sender="app", channel_type=self.channel.type)
        self.history.append(msg)
        if self._reply_callback:
            await self._reply_callback(msg)

    async def stream(self, chunks: AsyncIterator[str]) -> None:
        """Stream response chunks in real-time via S2."""
        if self._stream_callback:
            await self._stream_callback(chunks)
