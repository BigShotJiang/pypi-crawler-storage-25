"""
Cliara - Main entry point.
Starts the Cliara shell.
"""

import argparse
import platform
import sys
from pathlib import Path
from typing import Optional

from cliara import __version__
from cliara.config import Config
from cliara.shell_app.orchestrator import CliaraShell


def _ensure_utf8_runtime() -> None:
    """Best-effort UTF-8 setup for all Cliara command paths."""
    import os

    os.environ.setdefault("PYTHONUTF8", "1")
    os.environ.setdefault("PYTHONIOENCODING", "utf-8")

    for stream_name in ("stdin", "stdout", "stderr"):
        stream = getattr(sys, stream_name, None)
        if hasattr(stream, "reconfigure"):
            try:
                stream.reconfigure(encoding="utf-8", errors="replace")
            except Exception:
                pass

    if sys.platform == "win32":
        try:
            import ctypes

            kernel32 = ctypes.windll.kernel32
            kernel32.SetConsoleCP(65001)
            kernel32.SetConsoleOutputCP(65001)
        except Exception:
            pass


def _run_login():
    """Run OAuth login flow (standalone, no REPL)."""
    from cliara.auth import login
    from cliara.shell_app.orchestrator import (
        print_success,
        print_error,
        print_warning,
        print_dim,
    )

    print()
    print_dim("  Cliara Login — Zero-Friction Cloud Access")
    print_dim("  ─────────────────────────────────────────")
    print_dim("  Free tier: 150 queries/month · no credit card · GPT-4o-mini")
    print()

    try:
        token, email = login()
        print()
        user_label = f" ({email})" if email else ""
        print_success(f"  Logged in to Cliara Cloud{user_label}")
        print_success("  Free tier · 150 queries/month · resets monthly")
        print_dim("  Token saved to ~/.cliara/token.json — auto-loaded on every startup.")
        print_dim("  Run 'cliara' to start the shell, or 'cliara logout' to sign out.")
    except KeyboardInterrupt:
        print()
        print_warning("  Login cancelled.")
    except RuntimeError as exc:
        print()
        print_error(f"  [Error] {exc}")
        print_dim("  Try 'setup-llm' inside cliara for BYOK options (Groq/Gemini are free).")
        sys.exit(1)


def _run_logout():
    """Clear stored token (standalone, no REPL)."""
    from cliara.auth import logout, load_token
    from cliara.icons import print_success, print_warning, print_dim

    token_data = load_token()
    if token_data is None:
        print()
        print_warning("  Not currently logged in to Cliara Cloud.")
        print_dim("  Run 'cliara login' to sign in.")
        return

    email = token_data.get("email", "")
    logout()
    print()
    label = f" ({email})" if email else ""
    print_success(f"  Logged out of Cliara Cloud{label}.")
    print_dim("  Token deleted from ~/.cliara/token.json.")
    print_dim("  Run 'cliara login' to sign in again.")


def _run_status(config_dir=None):
    """Show auth and LLM status (standalone, no REPL)."""
    from cliara.auth import load_token, get_valid_token
    from cliara.shell_app.orchestrator import print_success, print_warning, print_dim

    print()
    print_dim("  Cliara Status")
    print_dim("  ------------")
    print()

    token_data = load_token()
    if token_data and get_valid_token():
        email = token_data.get("email", "unknown")
        print_success(f"  Cliara Cloud: logged in ({email})")
        print_dim("  Free tier · 150 queries/month · resets monthly")
        gh_tok = (token_data.get("github_provider_token") or "").strip()
        if gh_tok:
            print_success("  GitHub API: token on file (from login — used by `cliara gh`)")
        else:
            print_warning(
                "  GitHub API: no provider token yet — run `cliara login` again to grant repo scopes"
            )
    else:
        # Check if BYOK is configured via config
        config = Config(config_dir=config_dir)
        provider = config.get("llm_provider")
        if provider:
            print_success(f"  BYOK: {provider}")
            print_dim("  Using your own API key")
        else:
            print_warning("  Not configured")
            print_dim("  Run 'cliara login' for Cloud, or 'setup-llm' inside cliara for BYOK")
    print()


# Prefixes that must not be sent to Ollama as model names (same idea as setup_wizard).
_CLOUD_MODEL_PREFIXES = ("gpt-", "claude-", "llama-3.", "gemini-", "mixtral-", "text-")


def _clear_stale_cloud_model_for_ollama(config: Config) -> None:
    stored = config.get("llm_model") or ""
    if any(stored.startswith(p) for p in _CLOUD_MODEL_PREFIXES):
        config.settings["llm_model"] = None
        config.save()


def _init_nl_handler_headless(config: Config):
    """
    Build an NLHandler with LLM ready for one-shot queries (no REPL, no wizard).
    Returns NLHandler or None if the LLM could not be initialized.
    """
    from cliara.nl.service import NLHandler
    from cliara.safety import SafetyChecker

    safety = SafetyChecker()
    nl = NLHandler(safety, config=config)

    provider = config.get_llm_provider()
    api_key = config.get_llm_api_key()

    if not provider or not api_key:
        return None

    ok = False
    if provider == "ollama":
        _clear_stale_cloud_model_for_ollama(config)
        ok = nl.initialize_llm(
            "ollama",
            api_key,
            base_url=config.get_ollama_base_url(),
        )
    else:
        ok = nl.initialize_llm(provider, api_key)

    return nl if ok and nl.llm_enabled else None


def _run_ask(query: str, *, config_dir: Optional[str] = None, shell_override: Optional[str] = None) -> None:
    """
    Translate natural language to shell commands; print them and exit (no execution).

    Exit codes: 0 success, 2 no LLM / init failure, 3 empty or unusable generation.
    """
    query = (query or "").strip()
    if not query:
        print("cliara ask: missing query - example: cliara ask list files in this directory", file=sys.stderr)
        sys.exit(2)

    config = Config(config_dir=config_dir)

    nl = _init_nl_handler_headless(config)
    if nl is None:
        print(
            "cliara ask: no AI provider configured.\n"
            "  Run: cliara login   (Cliara Cloud)\n"
            "  Or set OPENAI_API_KEY / GROQ_API_KEY / GEMINI_API_KEY, or run Ollama.",
            file=sys.stderr,
        )
        sys.exit(2)

    shell_path = shell_override or config.get("shell") or config._detect_shell()
    context = {
        "cwd": str(Path.cwd()),
        "os": platform.system(),
        "shell": shell_path,
    }

    commands, explanation, danger_level = nl.process_query(query, context, stream_callback=None)

    if not commands:
        print(f"cliara ask: {explanation}", file=sys.stderr)
        sys.exit(3)

    print("Suggested commands:")
    for i, cmd in enumerate(commands, 1):
        print(f"  {i}. {cmd}")
    print()
    print(f"Explanation: {explanation}")
    print(f"Risk: {danger_level.value}")
    print()
    print("(Not executed - run them yourself or start the Cliara shell.)")


def main():
    """Main entry point for Cliara."""
    _ensure_utf8_runtime()

    parser = argparse.ArgumentParser(
        description="Cliara - AI-powered shell with natural language and macros",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  cliara                    Start interactive Cliara shell
  cliara login              Log in to Cliara Cloud (GitHub OAuth, no API key needed)
  cliara logout             Sign out and clear stored token
  cliara status             Show auth and LLM status
  cliara gh pr              GitHub PR with AI title/body (see cliara gh --help)
  cliara ask list git branches   Turn plain English into commands (not run)
  cliara nl undo last commit     Same as ask
  cliara -c "git status"    Run a single command through Cliara's gate
  cliara -c "rm -rf dist"   Risky commands still require approval
  cliara --config-dir ~/my-config  Use custom config directory
  cliara --version          Show version
  
Once in the shell:
  ls -la                    Run normal commands
  ? kill port 3000          Use natural language (Phase 2)
  macro add mycommand       Create a macro
  mycommand                 Run a macro
        """
    )
    
    parser.add_argument(
        '--version',
        action='version',
        version=f'Cliara {__version__}'
    )
    
    parser.add_argument(
        '-c',
        type=str,
        metavar='COMMAND',
        help='Run a single command through Cliara\'s risk gate, then exit'
    )
    
    parser.add_argument(
        '--config-dir',
        type=str,
        help='Custom configuration directory (default: ~/.cliara)'
    )
    
    parser.add_argument(
        '--debug',
        action='store_true',
        help='Enable debug mode'
    )
    
    parser.add_argument(
        '--shell',
        type=str,
        help='Override shell path'
    )
    
    parser.add_argument(
        '--verbose',
        action='store_true',
        help='Always show full startup banner (quick tips)'
    )

    subparsers = parser.add_subparsers(dest='command', help='Subcommands')
    subparsers.add_parser('login', help='Log in to Cliara Cloud (GitHub OAuth)')
    subparsers.add_parser('logout', help='Sign out and clear stored Cliara Cloud token')
    subparsers.add_parser('status', help='Show auth and LLM status')

    ask_p = subparsers.add_parser(
        'ask',
        help='Translate natural language to shell commands (does not execute them)',
    )
    ask_p.add_argument(
        'query',
        nargs='+',
        metavar='WORDS',
        help='What you want to do, in plain language',
    )

    nl_p = subparsers.add_parser(
        'nl',
        help='Same as ask: natural language to suggested commands only',
    )
    nl_p.add_argument(
        'query',
        nargs='+',
        metavar='WORDS',
        help='What you want to do, in plain language',
    )

    from cliara.gh_cli import register_gh_subparser, run_gh

    register_gh_subparser(subparsers)

    args = parser.parse_args()

    if args.debug:
        import os
        os.environ['DEBUG'] = '1'

    # Standalone login/logout/status — run OAuth, clear token, or show status, then exit (no REPL)
    if args.command == 'login':
        _run_login()
        sys.exit(0)
    if args.command == 'logout':
        _run_logout()
        sys.exit(0)
    if args.command == 'status':
        _run_status(config_dir=args.config_dir)
        sys.exit(0)
    if args.command in ('ask', 'nl'):
        _run_ask(
            ' '.join(args.query),
            config_dir=args.config_dir,
            shell_override=args.shell,
        )
        sys.exit(0)
    if args.command == 'gh':
        run_gh(args)
        sys.exit(0)

    try:
        # Initialize config
        config = Config(config_dir=args.config_dir)
        
        # Override shell if specified
        if args.shell:
            config.set('shell', args.shell)
        
        # Single-command mode: gate → execute → exit
        if args.c:
            shell = CliaraShell(config)
            exit_code = shell.run_single_command(args.c)
            sys.exit(exit_code)
        
        # Interactive mode
        shell = CliaraShell(config)
        shell.run(verbose_banner=args.verbose)
    
    except KeyboardInterrupt:
        print("\n\nInterrupted. Goodbye!")
        sys.exit(0)
    except Exception as e:
        print(f"\n[Fatal Error] {e}")
        if args.debug:
            import traceback
            traceback.print_exc()
        sys.exit(1)


if __name__ == '__main__':
    main()
