"""Regression tests for executing NL-generated commands through Cliara handlers."""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from cliara.shell_app.orchestrator import CliaraShell


def _stub_shell() -> CliaraShell:
    s = CliaraShell.__new__(CliaraShell)
    return s


def test_execute_nl_generated_command_dispatches_macro_alias():
    s = _stub_shell()
    calls = []

    s.handle_macro_command = lambda rest: calls.append(("macro", rest))  # type: ignore[assignment]
    s.execute_shell_command = lambda cmd, capture=False: calls.append(("shell", cmd)) or True  # type: ignore[assignment]

    ok = CliaraShell._execute_nl_generated_command(s, "mh")

    assert ok is True
    assert calls == [("macro", "help")]


def test_execute_nl_generated_command_falls_back_to_shell():
    s = _stub_shell()
    calls = []

    s.handle_macro_command = lambda rest: calls.append(("macro", rest))  # type: ignore[assignment]
    s.execute_shell_command = lambda cmd, capture=False: calls.append(("shell", cmd)) or True  # type: ignore[assignment]

    ok = CliaraShell._execute_nl_generated_command(s, "git status")

    assert ok is True
    assert calls == [("shell", "git status")]
