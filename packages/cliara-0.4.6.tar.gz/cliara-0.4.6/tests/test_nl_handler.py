"""Regression tests for Cliara NL handler robustness."""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from cliara.nl.service import NLHandler
from cliara.safety import SafetyChecker


def _handler() -> NLHandler:
    return NLHandler(SafetyChecker())


def test_route_query_mode_returns_answer_from_router_json():
    h = _handler()
    h.llm_enabled = True

    h._call_llm = lambda *args, **kwargs: '{"route":"answer","cliara_related":true,"reason":"info"}'  # type: ignore[method-assign]

    route = h.route_query_mode(
        "what does ma do",
        {"cwd": str(Path.cwd()), "os": "Windows", "shell": "powershell"},
    )

    assert route == "answer"


def test_route_query_mode_returns_commands_from_router_json():
    h = _handler()
    h.llm_enabled = True

    h._call_llm = lambda *args, **kwargs: '{"route":"commands","cliara_related":false,"reason":"operational"}'  # type: ignore[method-assign]

    route = h.route_query_mode(
        "what is in the agents folder",
        {"cwd": str(Path.cwd()), "os": "Windows", "shell": "powershell"},
    )

    assert route == "commands"


def test_answer_query_for_cliara_builtin_goes_through_llm():
    h = _handler()
    h.llm_enabled = True
    seen = {"agent": None}

    def _fake_call(agent_type, *_args, **_kwargs):
        seen["agent"] = agent_type
        return "ma is used to add a named macro."

    h._call_llm_stream = _fake_call  # type: ignore[method-assign]

    answer = h.answer_query(
        "what does ma do",
        {"cwd": str(Path.cwd()), "os": "Windows", "shell": "powershell"},
        stream_callback=None,
    )

    assert seen["agent"] == "cliara_qa"
    assert "add a named macro" in answer


def test_parse_response_accepts_get_command_plain_text():
    h = _handler()

    commands, explanation = h._parse_response("Get-Command mc")

    assert commands == ["Get-Command mc"]
    assert explanation


def test_process_query_retries_after_malformed_output():
    h = _handler()
    h.llm_enabled = True

    h._call_llm_stream = lambda *args, **kwargs: "Here is your result, sorry: use git status"  # type: ignore[method-assign]
    h._call_llm = lambda *args, **kwargs: '{"commands": ["git status"], "explanation": "Shows repository status."}'  # type: ignore[method-assign]

    commands, explanation, _level = h.process_query(
        "check git status",
        {"cwd": str(Path.cwd()), "os": "Windows", "shell": "powershell"},
        stream_callback=None,
    )

    assert commands == ["git status"]
    assert "status" in explanation.lower()


def test_parse_failure_message_includes_output_sample():
    h = _handler()

    commands, explanation = h._parse_response("This answer is not a command and has no JSON payload.")

    assert commands == []
    assert "Model output sample" in explanation


def test_json_agent_streaming_requires_explicit_json_safe_flag():
    h = _handler()
    h.provider = "ollama"

    seen = {"cb": None}

    def _fake_openai(*args, **kwargs):
        seen["cb"] = args[5]
        return '{"commands": ["git status"], "explanation": "ok"}'

    h._call_openai_compat = _fake_openai  # type: ignore[method-assign]

    def _cb(_chunk: str) -> None:
        pass

    # JSON agent: callback should be blocked unless explicitly marked safe.
    h._call_llm_stream("nl_to_commands", "check git status", stream_callback=_cb)
    assert seen["cb"] is None

    setattr(_cb, "__cliara_json_safe__", True)
    h._call_llm_stream("nl_to_commands", "check git status", stream_callback=_cb)
    assert seen["cb"] is _cb


def test_plaintext_agent_allows_stream_callback_without_flag():
    h = _handler()
    h.provider = "ollama"

    seen = {"cb": None}

    def _fake_openai(*args, **kwargs):
        seen["cb"] = args[5]
        return "explanation text"

    h._call_openai_compat = _fake_openai  # type: ignore[method-assign]

    def _cb(_chunk: str) -> None:
        pass

    h._call_llm_stream("explain", "explain git status", stream_callback=_cb)
    assert seen["cb"] is _cb


def test_generate_commit_message_falls_back_when_model_returns_blank():
    h = _handler()
    h.llm_enabled = True

    # Simulate provider returning no textual content for the commit agent.
    h._call_llm_stream = lambda *args, **kwargs: "   "  # type: ignore[method-assign]

    msg = h.generate_commit_message(
        " 1 file changed, 2 insertions(+), 1 deletion(-)",
        "diff --git a/a.py b/a.py\n+print('x')",
        ["cliara/shell_app/orchestrator.py"],
        {"branch": "main"},
        stream_callback=None,
    )

    assert msg == "chore: update orchestrator.py"
