"""Round-trip and normalization tests for TaskSession.closeout."""

import json
import tempfile
from pathlib import Path

from cliara.shell_app.orchestrator import CliaraShell
from cliara.nl.service import _default_session_reflect_plan, _validate_session_reflect_steps
from cliara.session_store import (
    CLOSEOUT_KEYS,
    SessionStore,
    TaskSession,
    _normalize_closeout,
    _normalize_closeout_prompts,
)


def test_expand_session_shortcut():
    assert CliaraShell._expand_session_shortcut("se") == "end"
    assert CliaraShell._expand_session_shortcut("se --reflect") == "end --reflect"
    assert CliaraShell._expand_session_shortcut("se done") == "end done"
    assert CliaraShell._expand_session_shortcut("ss") == "start"
    assert CliaraShell._expand_session_shortcut("ss fix bug") == "start fix bug"
    assert CliaraShell._expand_session_shortcut("ss fix -- get x") == "start fix -- get x"
    assert CliaraShell._expand_session_shortcut("ss -a") is None
    assert CliaraShell._expand_session_shortcut("ssh host") is None
    assert CliaraShell._expand_session_shortcut("ls") is None


def test_normalize_closeout_empty_and_partial():
    assert _normalize_closeout(None) is None
    assert _normalize_closeout({}) is None
    assert _normalize_closeout({"blocked": "", "decided": "  ", "next": ""}) is None
    out = _normalize_closeout(
        {"blocked": " CI ", "decided": "", "next": "ship"}
    )
    assert out == {"blocked": "CI", "next": "ship"}


def test_task_session_to_dict_from_dict_roundtrip():
    s = TaskSession(
        id="u1",
        name="t",
        intent="",
        created="2020-01-01T00:00:00+00:00",
        updated="2020-01-01T00:00:00+00:00",
        closeout={"blocked": "x", "decided": "y", "next": "z"},
    )
    d = s.to_dict()
    back = TaskSession.from_dict(d)
    assert back.closeout == {"blocked": "x", "decided": "y", "next": "z"}
    assert back.closeout_prompts is None
    assert set(CLOSEOUT_KEYS) == {"blocked", "decided", "next"}


def test_closeout_prompts_roundtrip():
    s = TaskSession(
        id="u1",
        name="t",
        intent="",
        created="2020-01-01T00:00:00+00:00",
        updated="2020-01-01T00:00:00+00:00",
        closeout={"blocked": "no", "next": "ship"},
        closeout_prompts={
            "blocked": "What is blocking you?",
            "decided": "Any decisions?",
            "next": "Next step?",
        },
    )
    back = TaskSession.from_dict(s.to_dict())
    assert back.closeout == {"blocked": "no", "next": "ship"}
    assert back.closeout_prompts["blocked"] == "What is blocking you?"
    assert _normalize_closeout_prompts({"blocked": " x "}) == {"blocked": "x"}


def test_task_session_from_dict_legacy_no_closeout_key():
    raw = {
        "id": "u1",
        "name": "t",
        "intent": "",
        "created": "2020-01-01T00:00:00+00:00",
        "updated": "2020-01-01T00:00:00+00:00",
        "cwds": [],
        "commands": [],
        "notes": [],
    }
    s = TaskSession.from_dict(raw)
    assert s.closeout is None
    assert s.closeout_prompts is None
    assert s.reflection is None


def test_default_session_reflect_plan_validates():
    steps = _default_session_reflect_plan()
    assert len(steps) >= 3
    assert _validate_session_reflect_steps({"steps": steps})


def test_session_store_end_session_persists_reflection():
    with tempfile.TemporaryDirectory() as tmp:
        path = Path(tmp) / "sessions.json"
        store = SessionStore(store_path=path)
        s = store.create(name="job", intent="test", project_root=None)
        store.end_session(
            s.id,
            reflection=[
                {
                    "id": "story",
                    "kind": "long_text",
                    "question": "What did you do?",
                    "answer": "Shipped the feature.",
                },
            ],
        )
        loaded = SessionStore(store_path=path).get_by_id(s.id)
        assert loaded is not None
        assert loaded.reflection
        assert loaded.reflection[0]["answer"] == "Shipped the feature."
        assert loaded.closeout is None


def test_session_store_end_session_persists_closeout():
    with tempfile.TemporaryDirectory() as tmp:
        path = Path(tmp) / "sessions.json"
        store = SessionStore(store_path=path)
        s = store.create(name="job", intent="test", project_root=None)
        store.end_session(
            s.id,
            end_note=None,
            closeout={"blocked": "a", "next": "b"},
            closeout_prompts={"blocked": "Q1?", "next": "Q3?"},
        )
        store2 = SessionStore(store_path=path)
        loaded = store2.get_by_id(s.id)
        assert loaded is not None
        assert loaded.is_ended
        assert loaded.closeout == {"blocked": "a", "next": "b"}
        assert loaded.closeout_prompts == {"blocked": "Q1?", "next": "Q3?"}


def test_json_file_roundtrip():
    s = TaskSession(
        id="id1",
        name="n",
        intent="",
        created="2020-01-01T00:00:00+00:00",
        updated="2020-01-01T00:00:00+00:00",
        ended_at="2020-01-02T00:00:00+00:00",
        closeout={"decided": "use SQLite"},
    )
    blob = json.dumps(s.to_dict(), ensure_ascii=False)
    back = TaskSession.from_dict(json.loads(blob))
    assert back.closeout == {"decided": "use SQLite"}
