"""Unit tests for GitHub remote parsing (no network)."""

import pytest

from cliara.gh_api import parse_github_remote


@pytest.mark.parametrize(
    "url,owner,repo,host",
    [
        ("git@github.com:acme/widget.git", "acme", "widget", "github.com"),
        ("git@github.com:acme/widget", "acme", "widget", "github.com"),
        ("https://github.com/acme/widget.git", "acme", "widget", "github.com"),
        ("https://www.github.com/acme/widget", "acme", "widget", "www.github.com"),
        ("https://git.example.com/org/service.git", "org", "service", "git.example.com"),
    ],
)
def test_parse_github_remote(url, owner, repo, host):
    o, r, h = parse_github_remote(url)
    assert (o, r, h) == (owner, repo, host)


def test_parse_github_remote_ssh_no_git_suffix():
    o, r, h = parse_github_remote("git@github.com:foo/bar-baz")
    assert o == "foo" and r == "bar-baz" and h == "github.com"
