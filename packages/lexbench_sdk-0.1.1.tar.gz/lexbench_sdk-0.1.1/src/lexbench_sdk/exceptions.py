from __future__ import annotations


class LexbenchError(RuntimeError):
    """Base error for Lexbench SDK."""


class LexbenchApiError(LexbenchError):
    """Error returned by Lexbench API."""

    def __init__(self, message: str, *, status_code: int | None = None) -> None:
        self.status_code = status_code
        super().__init__(message)


class LexbenchConnectionError(LexbenchError):
    """Network or connection related error."""
