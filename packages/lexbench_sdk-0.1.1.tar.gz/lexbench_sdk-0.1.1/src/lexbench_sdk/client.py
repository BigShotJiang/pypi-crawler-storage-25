from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Any
from urllib import error, parse, request

from .exceptions import LexbenchApiError, LexbenchConnectionError
from .models import ApiTokenCreatePayload, SubmitEvalRunPayload


@dataclass(frozen=True)
class LexbenchClient:
    base_url: str
    token: str
    timeout_seconds: int = 30

    def _request(
        self,
        method: str,
        path: str,
        payload: dict[str, Any] | None = None,
        *,
        with_auth: bool = True,
    ) -> dict[str, Any]:
        data = None
        if payload is not None:
            data = json.dumps(payload).encode("utf-8")

        headers: dict[str, str] = {"Content-Type": "application/json"}
        if with_auth:
            headers["Authorization"] = f"Bearer {self.token}"

        req = request.Request(
            url=f"{self.base_url.rstrip('/')}{path}",
            method=method,
            data=data,
            headers=headers,
        )

        try:
            with request.urlopen(req, timeout=self.timeout_seconds) as resp:
                body = resp.read().decode("utf-8")
        except error.HTTPError as exc:
            detail = exc.read().decode("utf-8", errors="replace")
            raise LexbenchApiError(
                f"Lexbench API HTTP {exc.code}: {detail}",
                status_code=exc.code,
            ) from exc
        except error.URLError as exc:
            raise LexbenchConnectionError(
                f"Lexbench API connection failed: {exc.reason}",
            ) from exc

        try:
            parsed = json.loads(body)
        except json.JSONDecodeError as exc:
            raise LexbenchApiError("Lexbench API returned invalid JSON response") from exc

        if not parsed.get("success"):
            raise LexbenchApiError(parsed.get("error", "Lexbench API request failed"))
        return parsed["data"]

    def submit_eval_run(self, payload: SubmitEvalRunPayload) -> dict[str, Any]:
        return self._request("POST", "/api/sdk/eval-runs", payload)

    def get_eval_run(self, run_uuid: str) -> dict[str, Any]:
        return self._request("GET", f"/api/sdk/eval-runs/{run_uuid}")

    def create_token(self, payload: ApiTokenCreatePayload | None = None) -> dict[str, Any]:
        return self._request("POST", "/api/sdk/tokens", payload or {})

    def list_tokens(self) -> list[dict[str, Any]]:
        return self._request("GET", "/api/sdk/tokens")

    def revoke_token(self, token_id: str) -> dict[str, Any]:
        return self._request("DELETE", f"/api/sdk/tokens/{token_id}")

    def start_login(self) -> dict[str, Any]:
        return self._request("POST", "/api/sdk/login/start", {}, with_auth=False)

    def poll_login(self, session_id: str, session_secret: str) -> dict[str, Any]:
        query = parse.urlencode({"sessionId": session_id, "sessionSecret": session_secret})
        return self._request(
            "GET",
            f"/api/sdk/login/poll?{query}",
            with_auth=False,
        )
