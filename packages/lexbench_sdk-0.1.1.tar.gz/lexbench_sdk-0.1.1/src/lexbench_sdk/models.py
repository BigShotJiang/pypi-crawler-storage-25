from __future__ import annotations

from typing import Any, Literal, TypedDict

EvalRunMode = Literal["all", "first_n", "sample_n"]


class SubmitEvalRunPayload(TypedDict, total=False):
    agentName: str
    benchmarkName: str
    mode: EvalRunMode
    runName: str
    version: str
    split: str
    count: int
    config: dict[str, Any]
    projectId: str
    projectBenchmarkId: str
    uiLanguage: str
    timeout: int
    skipCompleted: bool
    forceRerun: bool
    debug: bool
    dryRun: bool
    batchSequential: bool
    resumeTimestamp: str
    envContent: str
    yamlContent: str
    advancedParams: dict[str, Any]


class ApiTokenCreatePayload(TypedDict, total=False):
    name: str
    expiresInDays: int
