# lexbench-sdk (Python)

LexBench 平台官方 Python SDK。

## 安装

```bash
pip install lexbench-sdk
```

## 快速开始

```python
from lexbench_sdk import LexbenchClient

client = LexbenchClient(
    base_url="https://bench.lexmount.com",
    token="your_api_token",
)

result = client.submit_eval_run(
    {
        "agentName": "browser-use",
        "benchmarkName": "LexBench-Browser",
        "mode": "first_n",
        "count": 5,
        "split": "L1",
    }
)
print(result["runUuid"])
```

当前平台创建任务仅支持三种模式：

- `all`
- `first_n`
- `sample_n`

其中 `first_n` / `sample_n` 必须传 `count`。

## 支持的 API

- `submit_eval_run(payload)`
- `get_eval_run(run_uuid)`
- `create_token(payload=None)`
- `list_tokens()`
- `revoke_token(token_id)`
- `start_login()`
- `poll_login(session_id, session_secret)`

## 发布

当前仓库未内置 PyPI / TestPyPI 自动发布 workflow，建议在 `packages/lexbench-python-sdk` 目录手动执行：

```bash
uv build
python3.11 -m twine upload --repository testpypi dist/*
python3.11 -m twine upload dist/*
```

建议先发 TestPyPI 验证，再发正式 PyPI。
