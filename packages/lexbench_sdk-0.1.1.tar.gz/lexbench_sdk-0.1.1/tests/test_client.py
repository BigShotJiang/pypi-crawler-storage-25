from __future__ import annotations

import json
from urllib import error
from urllib.request import Request

import pytest

from lexbench_sdk import LexbenchApiError, LexbenchClient, LexbenchConnectionError


class _FakeResponse:
    def __init__(self, payload: dict[str, object]) -> None:
        self._payload = payload

    def read(self) -> bytes:
        return json.dumps(self._payload).encode("utf-8")

    def __enter__(self) -> _FakeResponse:
        return self

    def __exit__(self, exc_type, exc, tb) -> None:  # type: ignore[no-untyped-def]
        return None


def _http_error(code: int, body: str) -> error.HTTPError:
    return error.HTTPError(
        url="http://localhost",
        code=code,
        msg="failed",
        hdrs=None,
        fp=None,
    )


def test_submit_eval_run_success(monkeypatch: pytest.MonkeyPatch) -> None:
    client = LexbenchClient(base_url="http://localhost:3000", token="token")
    captured: dict[str, object] = {}

    def fake_urlopen(req: Request, timeout: int):  # type: ignore[no-untyped-def]
        captured["url"] = req.full_url
        captured["auth"] = req.headers.get("Authorization")
        captured["timeout"] = timeout
        return _FakeResponse(
            {
                "success": True,
                "data": {"runUuid": "run-1", "executionId": "exec-1"},
            }
        )

    monkeypatch.setattr("lexbench_sdk.client.request.urlopen", fake_urlopen)
    result = client.submit_eval_run(
        {
            "agentName": "browser-use",
            "benchmarkName": "LexBench-Browser",
            "mode": "all",
        }
    )

    assert result["runUuid"] == "run-1"
    assert captured["url"] == "http://localhost:3000/api/sdk/eval-runs"
    assert captured["auth"] == "Bearer token"
    assert captured["timeout"] == 30


def test_request_raises_api_error_for_http_error(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    client = LexbenchClient(base_url="http://localhost:3000", token="token")

    class _ErrResp:
        def read(self) -> bytes:
            return b'{"error":"bad request"}'

    def fake_urlopen(req: Request, timeout: int):  # type: ignore[no-untyped-def]
        err = _http_error(400, "bad request")
        err.fp = _ErrResp()
        raise err

    monkeypatch.setattr("lexbench_sdk.client.request.urlopen", fake_urlopen)

    with pytest.raises(LexbenchApiError) as exc_info:
        client.get_eval_run("run-1")
    assert "HTTP 400" in str(exc_info.value)


def test_request_raises_connection_error(monkeypatch: pytest.MonkeyPatch) -> None:
    client = LexbenchClient(base_url="http://localhost:3000", token="token")

    def fake_urlopen(req: Request, timeout: int):  # type: ignore[no-untyped-def]
        raise error.URLError("network down")

    monkeypatch.setattr("lexbench_sdk.client.request.urlopen", fake_urlopen)

    with pytest.raises(LexbenchConnectionError):
        client.list_tokens()


def test_request_raises_api_error_when_success_false(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    client = LexbenchClient(base_url="http://localhost:3000", token="token")

    def fake_urlopen(req: Request, timeout: int):  # type: ignore[no-untyped-def]
        return _FakeResponse({"success": False, "error": "invalid payload"})

    monkeypatch.setattr("lexbench_sdk.client.request.urlopen", fake_urlopen)

    with pytest.raises(LexbenchApiError) as exc_info:
        client.submit_eval_run(
            {
                "agentName": "browser-use",
                "benchmarkName": "LexBench-Browser",
                "mode": "all",
            }
        )
    assert "invalid payload" in str(exc_info.value)
