# Copyright The OpenTelemetry Authors
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""
OpenTelemetry Instrumentation for Google ADK.

This package provides OpenTelemetry instrumentation for Google Agent Development Kit (ADK)
applications, following the OpenTelemetry GenAI semantic conventions.

This implementation uses ExtendedTelemetryHandler from opentelemetry-util-genai
for standard span and metrics management.

Usage:
    # Manual instrumentation
    from opentelemetry.instrumentation.google_adk import GoogleAdkInstrumentor
    GoogleAdkInstrumentor().instrument()

    # Auto instrumentation (via opentelemetry-instrument)
    # opentelemetry-instrument python your_app.py
"""

import logging
from typing import Collection, Optional

from wrapt import wrap_function_wrapper

from opentelemetry.instrumentation.instrumentor import BaseInstrumentor
from opentelemetry.instrumentation.utils import unwrap
from opentelemetry.util.genai.extended_handler import ExtendedTelemetryHandler

from .internal._plugin import GoogleAdkObservabilityPlugin
from .version import __version__ as __version__  # noqa: F401

_logger = logging.getLogger(__name__)

# Module-level storage for the plugin instance
# This ensures the plugin persists across different instrumentor instances
# and supports both manual and auto instrumentation modes
_global_plugin: Optional[GoogleAdkObservabilityPlugin] = None
_global_handler: Optional[ExtendedTelemetryHandler] = None


def _create_plugin_if_needed(
    tracer_provider=None, meter_provider=None, logger_provider=None
):
    """
    Create or get the global plugin instance.

    This function ensures that only one plugin instance exists for the
    entire process, which is necessary for auto instrumentation to work
    correctly when the instrumentor may be instantiated multiple times.

    Args:
        tracer_provider: Optional tracer provider
        meter_provider: Optional meter provider
        logger_provider: Optional logger provider

    Returns:
        GoogleAdkObservabilityPlugin instance
    """
    global _global_plugin, _global_handler

    if _global_plugin is None:
        # Create ExtendedTelemetryHandler with provided providers
        _global_handler = ExtendedTelemetryHandler(
            tracer_provider=tracer_provider,
            meter_provider=meter_provider,
            logger_provider=logger_provider,
        )

        # Create plugin with handler
        _global_plugin = GoogleAdkObservabilityPlugin(_global_handler)
        _logger.debug("Created global GoogleAdkObservabilityPlugin instance")

    return _global_plugin


def _runner_init_wrapper(wrapped, instance, args, kwargs):
    """
    Wrapper for Runner.__init__ to auto-inject the observability plugin.

    This is a module-level function (not a method) to avoid issues with
    instance state in auto instrumentation scenarios where the instrumentor
    may be instantiated multiple times.

    Args:
        wrapped: Original wrapped function
        instance: Runner instance
        args: Positional arguments
        kwargs: Keyword arguments

    Returns:
        Result of the original function
    """
    # Get or create the plugin
    plugin = _create_plugin_if_needed()

    if plugin:
        # Get or create plugins list
        plugins = kwargs.get("plugins", [])
        if not isinstance(plugins, list):
            plugins = [plugins] if plugins else []

        # Add our plugin if not already present
        if plugin not in plugins:
            plugins.append(plugin)
            kwargs["plugins"] = plugins
            _logger.debug(
                "Injected OpenTelemetry observability plugin into Runner"
            )

    # Call the original __init__
    return wrapped(*args, **kwargs)


class GoogleAdkInstrumentor(BaseInstrumentor):
    """
    OpenTelemetry instrumentor for Google ADK.

    This instrumentor automatically injects observability into Google ADK applications
    following OpenTelemetry GenAI semantic conventions.

    Uses ExtendedTelemetryHandler from opentelemetry-util-genai for:
    - Automatic span lifecycle management
    - Automatic metrics recording
    - Standard GenAI semantic conventions

    Supports both manual and auto instrumentation modes:
    - Manual: GoogleAdkInstrumentor().instrument()
    - Auto: opentelemetry-instrument python your_app.py
    """

    def __init__(self):
        """Initialize the instrumentor."""
        super().__init__()

    @property
    def _plugin(self):
        """
        Get the global plugin instance.

        This property provides backward compatibility with code that accesses
        self.instrumentor._plugin (e.g., in tests).

        Returns:
            The global plugin instance
        """
        return _global_plugin

    def instrumentation_dependencies(self) -> Collection[str]:
        """
        Return the list of instrumentation dependencies.

        Returns:
            Collection of required packages
        """
        return ["google-adk >= 0.1.0"]

    def _instrument(self, **kwargs):
        """
        Instrument the Google ADK library.

        This method works in both manual and auto instrumentation modes by
        using a module-level global plugin instance that persists across
        multiple instrumentor instantiations.

        Args:
            **kwargs: Optional keyword arguments:
                - tracer_provider: Custom tracer provider
                - meter_provider: Custom meter provider
                - logger_provider: Custom logger provider
        """
        # Check if google-adk is installed
        import importlib.util  # noqa: PLC0415

        if importlib.util.find_spec("google.adk.runners") is None:
            _logger.warning(
                "google-adk not found, instrumentation will not be applied"
            )
            return

        tracer_provider = kwargs.get("tracer_provider")
        meter_provider = kwargs.get("meter_provider")
        logger_provider = kwargs.get("logger_provider")

        # Create or get the global plugin instance
        _create_plugin_if_needed(
            tracer_provider, meter_provider, logger_provider
        )

        # Wrap the Runner initialization to auto-inject our plugin
        try:
            wrap_function_wrapper(
                "google.adk.runners",
                "Runner.__init__",
                _runner_init_wrapper,  # Use module-level function
            )
            _logger.info("Google ADK instrumentation enabled")
        except Exception as e:
            _logger.exception(f"Failed to instrument Google ADK: {e}")

    def _uninstrument(self, **kwargs):
        """
        Uninstrument the Google ADK library.

        Args:
            **kwargs: Optional keyword arguments
        """
        global _global_plugin, _global_handler

        try:
            # Unwrap the Runner initialization
            from google.adk.runners import Runner  # noqa: PLC0415

            unwrap(Runner, "__init__")

            # Clear the global plugin and handler
            _global_plugin = None
            _global_handler = None

            _logger.info("Google ADK instrumentation disabled")
        except Exception as e:
            _logger.exception(f"Failed to uninstrument Google ADK: {e}")


__all__ = ["GoogleAdkInstrumentor"]
