def ics_to_json(): ...  # pragma: no cov


def json_to_ics(): ...  # pragma: no cov


def eml_to_json(): ...  # pragma: no cov


def json_to_eml(): ...  # pragma: no cov
