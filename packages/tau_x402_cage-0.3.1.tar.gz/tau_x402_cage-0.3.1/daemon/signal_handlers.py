"""Signal handlers for the Tau cage daemon.

Per Unit 6 (collapsed scope): just enable faulthandler so SIGSEGV produces a
traceback to stderr before the process dies. launchd captures stderr and
respawns the daemon under KeepAlive.Crashed=true.

V2 production hardening will add: log-marker classifier, per-step error
taxonomy, mp.Process worker isolation. Out of V1 scope.
"""
from __future__ import annotations

import faulthandler
import signal
import sys


def install() -> None:
    """Enable faulthandler + register SIGTERM as graceful shutdown."""
    faulthandler.enable(file=sys.stderr)

    def _graceful_shutdown(signum, frame):  # noqa: ARG001
        sys.stderr.write(f"tau-cage daemon: received signal {signum}, exiting\n")
        sys.stderr.flush()
        sys.exit(0)

    signal.signal(signal.SIGTERM, _graceful_shutdown)
    signal.signal(signal.SIGINT, _graceful_shutdown)
