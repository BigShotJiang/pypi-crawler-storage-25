"""CageDaemon: UDS server wrapping the cage state.

JSON-over-newline framing on a Unix domain socket. One request per line, one
response per line. Designed for low-latency local IPC from the PreToolUse hook.

Hot path (op=check): adapter.normalize → registry.check → optional Tau step →
verdict JSON. Admin path (op=declare/retract): registry mutation + Tau revision.

Thread model: ThreadingUnixStreamServer fans out connections; the interpreter
lock in TauInterpreterWrapper serialises Tau access. Registry mutations also go
through a daemon-level lock to prevent declare/retract races.
"""
from __future__ import annotations

import json
import logging
import os
import socket
import socketserver
import threading
from decimal import Decimal, InvalidOperation
from pathlib import Path
from typing import Any

from adapter.invariants import (
    CounterpartyConstraint,
    JurisdictionRule,
    MaxPerCall,
    ProviderAllowlist,
    RetryRateLimit,
    RollingWindowCap,
    SpendingCap,
)
from adapter.payment_intent_matcher import InvalidPaymentIntent, PaymentIntent
from adapter.prover import (
    ConsistencyProver,
    Contradiction,
    ProofToken,
    PythonPatternProver,
)
from adapter.x402_registry import X402Registry

logger = logging.getLogger(__name__)


def _redact_path(p: str) -> str:
    """Redact a path for log lines so declared paths don't leak to /tmp logs."""
    return "[protected]"


def _append_capped(
    seq: tuple[PaymentIntent, ...],
    item: PaymentIntent,
    cap: int,
) -> tuple[PaymentIntent, ...]:
    """Append item to seq, trimming oldest entries if length exceeds cap."""
    new_seq = seq + (item,)
    if len(new_seq) > cap:
        new_seq = new_seq[-cap:]
    return new_seq


def _reconstruct_intent(d: dict[str, Any]) -> PaymentIntent:
    """Turn the wire dict sent by x402_client.UdsDaemonClient into a PaymentIntent.

    Every string field flows through PaymentIntent.__post_init__ which
    enforces the safe-token schema (H-07), so untrusted input is validated
    here before touching any invariant logic.
    """
    return PaymentIntent(
        amount=Decimal(str(d["amount"])),
        currency=str(d.get("currency", "USDC")),
        provider=str(d.get("provider", "")),
        counterparty=str(d.get("counterparty", "")),
        rail=str(d.get("rail", "x402")),
        timestamp_unix=int(d.get("timestamp_unix", 0)),
        metadata={str(k): str(v) for k, v in (d.get("metadata") or {}).items()},
        request_id=str(d["request_id"]) if d.get("request_id") is not None else None,
    )


class _CageRequestHandler(socketserver.StreamRequestHandler):
    """Per-connection handler. Reads one JSON line, writes one JSON line."""

    def handle(self) -> None:
        daemon: "CageDaemon" = self.server.cage  # type: ignore[attr-defined]
        try:
            raw = self.rfile.readline()
        except OSError:
            return
        if not raw:
            return
        try:
            payload = json.loads(raw.decode("utf-8"))
        except (ValueError, UnicodeDecodeError):
            self._respond({"verdict": "error", "category": "protocol",
                           "reason": "malformed JSON"})
            return
        response = daemon.dispatch(payload)
        self._respond(response)

    def _respond(self, response: dict[str, Any]) -> None:
        # Escape literal newlines in any string values so framing stays safe.
        line = json.dumps(response, ensure_ascii=False).replace("\n", "\\n") + "\n"
        try:
            self.wfile.write(line.encode("utf-8"))
        except OSError:
            pass


class _ThreadingUnixServer(socketserver.ThreadingMixIn, socketserver.UnixStreamServer):
    daemon_threads = True
    allow_reuse_address = True


class CageDaemon:
    """Holds the cage state (registry + interpreter) behind a UDS server."""

    def __init__(
        self,
        socket_path: str,
        initial_spec: str = "u[t] = i[t].",
        prover: ConsistencyProver | None = None,
    ) -> None:
        # `initial_spec` is an artefact from the Safety-Cage daemon signature; the
        # V0.3 hot path does not need the Tau interpreter. Pointwise revision
        # uses the prover to vet rule-set changes before activation.
        del initial_spec
        self.socket_path = socket_path
        self._x402_registry = X402Registry.empty()
        self._payment_history: tuple[PaymentIntent, ...] = ()
        self._reject_history: tuple[PaymentIntent, ...] = ()
        self._history_cap = 10_000  # bound memory; oldest trimmed
        self._prover: ConsistencyProver = prover or PythonPatternProver()
        self._revision_log: tuple[ProofToken, ...] = ()
        self._registry_lock = threading.Lock()
        self._server: _ThreadingUnixServer | None = None
        self._unlink_existing_socket()

    def _unlink_existing_socket(self) -> None:
        try:
            os.unlink(self.socket_path)
        except FileNotFoundError:
            pass

    def serve_forever(self) -> None:
        # Tighten socket file permissions: owner-only.
        old_umask = os.umask(0o177)
        try:
            self._server = _ThreadingUnixServer(self.socket_path, _CageRequestHandler)
        finally:
            os.umask(old_umask)
        self._server.cage = self  # type: ignore[attr-defined]
        self._server.serve_forever()

    def shutdown(self) -> None:
        if self._server is not None:
            self._server.shutdown()
            self._server.server_close()
        self._unlink_existing_socket()

    # ── op dispatch ─────────────────────────────────────────────────────────

    def dispatch(self, payload: dict[str, Any]) -> dict[str, Any]:
        op = payload.get("op")
        if op == "status":
            return {"verdict": "ok"}
        if op == "health":
            return self._op_health()
        if op == "check_payment":
            return self._op_check_payment(payload)
        if op == "declare_x402":
            return self._op_declare_x402(payload)
        if op == "retract_x402":
            return self._op_retract_x402(payload)
        if op == "active_x402":
            return self._op_active_x402()
        if op == "revision_log":
            return self._op_revision_log()
        return {"verdict": "error", "category": "unknown_op", "reason": f"op={op!r}"}

    # ── health / status ─────────────────────────────────────────────────────

    def _op_health(self) -> dict[str, Any]:
        """Liveness + readiness snapshot suitable for load balancers."""
        with self._registry_lock:
            invariants_active = len(self._x402_registry.invariants)
            revisions = len(self._revision_log)
            history_size = len(self._payment_history)
            rejects_size = len(self._reject_history)
        return {
            "verdict": "ok",
            "ready": True,
            "prover_backend": getattr(self._prover, "backend", "unknown"),
            "invariants_active": invariants_active,
            "revision_log_length": revisions,
            "payment_history_length": history_size,
            "reject_history_length": rejects_size,
        }

    # ── x402 payment path ──────────────────────────────────────────────────

    def _op_check_payment(self, payload: dict[str, Any]) -> dict[str, Any]:
        intent_dict = payload.get("intent")
        if not isinstance(intent_dict, dict):
            return {
                "verdict": "reject",
                "rule_id": "malformed_request",
                "reason_text": "check_payment requires an 'intent' object",
                "ttl_seconds": 5,
            }
        try:
            intent = _reconstruct_intent(intent_dict)
        except (InvalidPaymentIntent, ValueError, InvalidOperation, TypeError) as exc:
            return {
                "verdict": "reject",
                "rule_id": "invalid_payment_intent",
                "reason_text": f"Intent rejected at reconstruction: {exc}",
                "ttl_seconds": 5,
            }
        with self._registry_lock:
            registry = self._x402_registry
            history = self._payment_history
            rejects = self._reject_history
        violation = registry.check_payment(intent, history, rejects)
        if violation is None:
            with self._registry_lock:
                self._payment_history = _append_capped(
                    self._payment_history, intent, self._history_cap
                )
            return {
                "verdict": "permit",
                "rule_id": None,
                "witness": None,
                "reason_text": None,
                "ttl_seconds": 30,
            }
        # Record rejects so RetryRateLimit can see them on subsequent calls.
        with self._registry_lock:
            self._reject_history = _append_capped(
                self._reject_history, intent, self._history_cap
            )
        return {
            "verdict": "reject",
            "rule_id": violation.rule_id,
            "witness": violation.witness,
            "reason_text": violation.reason_text,
            "ttl_seconds": 30,
        }

    def _op_declare_x402(self, payload: dict[str, Any]) -> dict[str, Any]:
        inv = self._build_x402_invariant(payload)
        if inv is None:
            return {"verdict": "error", "category": "bad_invariant"}
        return self._apply_revision(
            lambda reg: reg.declare(inv),
            kind=payload.get("kind"),
            op_name="updated",
        )

    def _op_retract_x402(self, payload: dict[str, Any]) -> dict[str, Any]:
        inv = self._build_x402_invariant(payload)
        if inv is None:
            return {"verdict": "error", "category": "bad_invariant"}
        return self._apply_revision(
            lambda reg: reg.retract(inv),
            kind=payload.get("kind"),
            op_name="retracted",
        )

    def _apply_revision(
        self,
        mutate: Any,
        kind: str | None,
        op_name: str,
    ) -> dict[str, Any]:
        """Run `mutate(registry) -> new_registry` under the consistency prover.

        Atomic: the registry reference is ONLY swapped if the prover issues a
        ProofToken. A Contradiction leaves the old registry in place and
        returns the witness pair to the caller.
        """
        with self._registry_lock:
            old_reg = self._x402_registry
            predecessor = (
                self._revision_log[-1].config_hash if self._revision_log else None
            )
        candidate_reg = mutate(old_reg)
        result = self._prover.prove(
            invariants=candidate_reg.invariants,
            predecessor_hash=predecessor,
        )
        if isinstance(result, Contradiction):
            return {
                "verdict": "contradiction",
                "kind": kind,
                "reason": result.reason,
                "witness": {"left": result.left, "right": result.right},
                "backend": result.backend,
                "active_invariants": len(old_reg.invariants),  # unchanged
            }
        # Proof-token in hand: swap atomically + append to revision log.
        with self._registry_lock:
            # Race protection: if another thread advanced the log between our
            # read and this write, re-check predecessor before committing.
            current_predecessor = (
                self._revision_log[-1].config_hash if self._revision_log else None
            )
            if current_predecessor != predecessor:
                return {
                    "verdict": "conflict",
                    "reason": "concurrent revision committed first; retry",
                    "active_invariants": len(self._x402_registry.invariants),
                }
            self._x402_registry = candidate_reg
            self._revision_log = self._revision_log + (result,)
        return {
            "verdict": op_name,
            "kind": kind,
            "active_invariants": len(candidate_reg.invariants),
            "proof_token": result.to_dict(),
        }

    def _op_revision_log(self) -> dict[str, Any]:
        """Return the ordered audit trail of proof tokens for this session."""
        with self._registry_lock:
            log = self._revision_log
        return {
            "verdict": "ok",
            "length": len(log),
            "revisions": [t.to_dict() for t in log],
        }

    def _op_active_x402(self) -> dict[str, Any]:
        with self._registry_lock:
            invs = self._x402_registry.invariants
            history_len = len(self._payment_history)
        return {
            "verdict": "ok",
            "active_invariants": len(invs),
            "kinds": [inv.name for inv in invs],
            "history_len": history_len,
        }

    def _build_x402_invariant(self, payload: dict[str, Any]):
        kind = payload.get("kind")
        try:
            if kind == "spending_cap":
                return SpendingCap(
                    max_amount=Decimal(str(payload["max_amount"])),
                    currency=payload.get("currency", "USDC"),
                    scope=payload.get("scope", "per_window"),
                    window_seconds=payload.get("window_seconds"),
                    provider=payload.get("provider"),
                )
            if kind == "max_per_call":
                return MaxPerCall(
                    max_amount=Decimal(str(payload["max_amount"])),
                    currency=payload.get("currency", "USDC"),
                )
            if kind == "provider_allowlist":
                providers = payload.get("providers", [])
                if not isinstance(providers, list):
                    return None
                return ProviderAllowlist(providers=frozenset(providers))
            if kind == "retry_rate_limit":
                return RetryRateLimit(min_gap_seconds=int(payload["min_gap_seconds"]))
            if kind == "rolling_window_cap":
                return RollingWindowCap(
                    max_count=int(payload["max_count"]),
                    window_seconds=int(payload["window_seconds"]),
                    group_by=payload.get("group_by", "provider"),
                )
            if kind == "counterparty_constraint":
                approved = frozenset(payload.get("approved_ids", []))
                sanctioned = frozenset(payload.get("sanctioned_ids", []))
                return CounterpartyConstraint(
                    approved_ids=approved, sanctioned_ids=sanctioned
                )
        except (KeyError, ValueError, InvalidOperation, TypeError) as exc:
            logger.warning("bad x402 invariant payload: %s", exc)
            return None
        return None

