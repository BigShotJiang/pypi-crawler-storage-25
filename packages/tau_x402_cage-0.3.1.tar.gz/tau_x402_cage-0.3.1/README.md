<p align="center"><a href="./docs/rfc/2026-04-x402-formal-policy-semantics.md"><img src="./docs/img/banner.svg" alt="tau-x402-cage. Formal policy semantics for HTTP 402 agentic payments" width="100%"></a></p>

[![PyPI](https://img.shields.io/pypi/v/tau-x402-cage?color=007ec6&label=pypi)](https://pypi.org/project/tau-x402-cage/)
[![GHCR](https://img.shields.io/badge/ghcr.io-tau--x402--cage-0b7eaf)](https://github.com/Jme-Tau/tau-x402-cage/pkgs/container/tau-x402-cage)
[![CI](https://github.com/Jme-Tau/tau-x402-cage/actions/workflows/tti-gate.yml/badge.svg)](https://github.com/Jme-Tau/tau-x402-cage/actions/workflows/tti-gate.yml)
[![Patent](https://img.shields.io/badge/US%20Patent-12%2C254%2C082-111)](https://patft.uspto.gov/)
[![RFC](https://img.shields.io/badge/RFC-draft--00-444)](./docs/rfc/2026-04-x402-formal-policy-semantics.md)
[![License](https://img.shields.io/badge/license-GPLv3%20%2F%20Commercial-777)](./LICENSE)

> [!IMPORTANT]
> **Dual-licensed.** [GPLv3](./LICENSE) for OSS + royalty-free patent grant for conforming OSS implementations. Commercial license for enterprise self-host / hosted SaaS / closed-source integrations. Contact → [`services@idni.org`](mailto:services@idni.org).

---

We've been building Tau Language as a decidable temporal logic with self-reference for the better part of a decade. HTTP 402 is the first place the logic's actual constraints. No silent contradictions, no runtime drift, no unsigned verdicts. Directly match what a real market needs. This cage is the smallest useful shipping of it.

## What it does

Your AI agents are about to start paying for APIs, compute, and services over [x402](https://x402.org) and [MPP](https://stripe.com/blog/machine-payments-protocol). The rules governing that spend live in JSON files and Python scripts. Nobody can prove two rules don't silently contradict. Nobody can prove a `permit` header wasn't injected by a compromised middleware. Nobody can reconstruct the rule set that was live last Tuesday.

tau-x402-cage sits between your agent and your payment rail. It reads your policy as a declarative rule set, checks rule-set consistency at declare time, and signs every payment decision with a MAC bound to the specific intent. V0.3.0 ships a pattern-based consistency prover; V0.3.1 swaps in the Tau Language SMT backend for semantically-complete consistency proofs. OPA and Cedar do neither consistency checking nor signed verdicts today.

## Quickstart. First reject in 60 seconds

```bash
pip install tau-x402-cage

tau-x402-cage init                 # writes policy.yaml + docker-compose.yaml
tau-x402-cage --policy policy.yaml # daemon serves on /tmp/tau-x402-cage.sock
```

Then from your agent, send a payment intent over the Unix socket:

```bash
python -c '
import json, socket
s = socket.socket(socket.AF_UNIX); s.connect("/tmp/tau-x402-cage.sock")
s.sendall(json.dumps({
    "op": "check_payment",
    "intent": {
        "amount": "1001", "currency": "USDC", "provider": "anthropic",
        "counterparty": "vendor_x", "rail": "x402",
        "timestamp_unix": 1700000000, "metadata": {}, "request_id": None,
    }
}).encode() + b"\n")
print(s.makefile().readline())
'
```

```json
{"verdict": "reject", "rule_id": "max_per_call",
 "reason_text": "Single-call cap 50 USDC exceeded (intent: 1001)",
 "witness": "intent=1001,cap=50", "ttl_seconds": 30}
```

Install-to-first-explained-rejection under ten minutes on a clean machine. Published benchmark protocol: [`scripts/tti-bench.sh`](./scripts/tti-bench.sh).

> [!TIP]
> The reject reason is **machine-checkable**. `rule_id` names the violating invariant and `witness` gives the concrete numbers. Paste it straight into an audit log and the regulator knows which rule fired and why.

## Table of contents

- **If you write code:** [Quickstart](#quickstart--first-reject-in-60-seconds) → [Integration](#integration) → [Invariant types](#invariant-types-v1) → [Development](#development)
- **If you write standards:** [Why this exists](#why-this-exists) → [What's different](#whats-different) → [The RFC](#the-standards-story) → [The TTI metric](#the-tti-metric) → [Citations](#citations)
- **If you own compliance:** [Why this exists](#why-this-exists) → [Security properties](#security-properties-proven-via-tests) → [What we're NOT claiming](#what-were-not-claiming) → [Licensing & commercial](#licensing--commercial) → [Pricing](./docs/pricing.md)

## Why this exists

### The market context (researched 2026-04-18)

| Date | Event | Source |
|---|---|---|
| 2026-03-18 | Stripe + Tempo launch **Machine Payments Protocol** (MPP) on HTTP 402 with Visa as anchor validator; Lightspark extends to Bitcoin Lightning | [CoinDesk](https://www.coindesk.com/tech/2026/03/18/stripe-led-payments-blockchain-tempo-goes-live-with-protocol-for-ai-agents) |
| 2026-04-02 | Coinbase contributes **x402** to the Linux Foundation; 20 backers including Stripe, Visa, Mastercard, AWS, Google, Microsoft, Circle, Cloudflare, Shopify | [LF press](https://www.linuxfoundation.org/press/linux-foundation-is-launching-the-x402-foundation-and-welcoming-the-contribution-of-the-x402-protocol) |
| 2026-04-10 | x402 shifts from flat-fee to usage-based pricing, signalling enterprise-grade maturity | [Coinbase](https://www.coinbase.com/developer-platform/discover/launches/x402) |

Two competing HTTP-402 standards shipped within 16 days of each other. Both are governed by neutral foundations. Neither specifies *what "a policy" actually means.*

### The gap

Current volume on x402 is approximately **$28k/day in genuine on-chain activity** ([Artemis](https://classic.artemis.ai/asset/x402)) against a **$7B ecosystem valuation** ([AInvest](https://www.ainvest.com/news/measuring-real-flow-x402-28k-daily-volume-7b-ecosystem-2604/)). With roughly half of observed activity flagged as "gamified" rather than commerce. The market is pre-volume, mid-positioning. Galaxy Digital projects x402 will hit **30% of Base daily transactions by end-2026**; McKinsey puts the broader agentic-commerce total addressable market at **$3-5T by 2030**.

**What a pilot looks like in practice.** Week 1-2: translate your existing rule set to Tau invariants in a scratch environment; run `is_tau_formula_sat` on the composed spec and find out which rules silently contradict. Week 3-5: parallel run in shadow mode against one production agent channel. Week 6-7: enforce mode, one channel. Week 8: joint readout. A typical 14-rule policy set surfaces one or two latent contradictions and zero false rejects on traffic that was previously approved.

Every policy-guardrails write-up published in Q1 2026 stops at *"spending caps + merchant category + time-bound permissions"*. The level OPA and Cedar already ship. **No vendor has publicly shipped decidable rule-set composition, temporal reasoning over traces, or cryptographically signed verdicts.**

The adjacent competitive landscape as of 2026-04-18:

- **Mastercard Agent Pay, Visa Intelligent Commerce**. Rail-level controls (identity, tokenization, mandates), still in pilot; different layer.
- **Sapiom** ($15.75M, March 2026). Agent wallets + identity + rails; adjacent to guardrails, not competitive.
- **AgentXchain**. Agent orchestration / dispatch / conformance; operationally adjacent.
- **OPA / AWS Cedar**. The generic policy-engine baseline; what we position against on composition.
- **TLA+, Alloy, SPIN**. Offline formal methods; not runtime-integrable.

The window to define formal policy semantics above HTTP 402 is roughly Q2–Q3 2026, before either foundation's RFC track hardens. This project is written to that window.

### The audit gap

| What today's stacks enforce | What your auditor actually asks |
|---|---|
| Spending caps in JSON + code review | *"Prove two rules don't silently contradict."* |
| Allowlists in JSON + code review | *"Prove the rule held in every window, not just this request."* |
| Retry limits (sometimes) | *"Prove the decision came from your engine, not a compromised sidecar."* |
| | *"Reconstruct the rule set that was live last Tuesday."* |

The cage closes the right column. That's the whole value proposition.

## What's different

Five rows ordered by load-bearing impact first:

|  | tau-x402-cage | OPA / Rego | AWS Cedar | TLA+ / Alloy |
|---|---|---|---|---|
| Rule-rule contradiction detection at declare-time | **yes** | no | no | yes (offline) |
| Signed verdicts with intent binding | **yes (HMAC + intent_hash)** | no | no | n/a |
| Temporal reasoning over traces (LTL + past-LTL) | **yes** | no | no | yes |
| Decidability guarantee over composed rule sets | **yes** | no (T-complete) | partial | yes |
| Multi-typed reasoning in one engine (atomless BA) | **yes** | partial | partial | yes |
| Runs in the request path | yes | yes | yes | no (offline) |
| Sub-millisecond p95 | yes (0.14ms) | yes | yes | n/a |
| Public TTI benchmark | **yes** | no | no | n/a |

The first five rows are the patent-fenced core. The rest is parity incumbents can reach in a quarter.

## How it works

```mermaid
sequenceDiagram
    participant Agent
    participant Cage as tau-x402-cage
    participant Tau as Tau decision procedure
    participant Fac as Facilitator
    participant Prov as Provider

    Agent->>Fac: POST /pay (HTTP 402 + X-PAYMENT)
    Fac->>Cage: mediate(headers, body, secret)
    Cage->>Cage: parse + schema-validate intent
    Cage->>Tau: is_sat(composed rules ∧ intent)
    Tau-->>Cage: permit | reject + rule_id + witness
    Cage->>Cage: HMAC(verdict ∥ intent_hash ∥ TTL)
    Cage-->>Fac: signed envelope
    Fac->>Fac: verify MAC + intent_hash + TTL
    alt permit
        Fac->>Prov: settle
        Fac-->>Agent: 200 OK + X-Policy-Verdict: permit
    else reject
        Fac-->>Agent: 403 + X-Policy-Verdict: reject + reason
    end
```

### The three demos that OPA and Cedar literally cannot run

<details><summary><b>Demo 1. Declare-time rule contradiction</b>&nbsp;&nbsp;<code>demos/scenarios/contradiction.py</code></summary>

![Demo 1 — declare-time rule contradiction](./demos/recordings/contradiction.gif)

Under OPA or Cedar both rules load cleanly; one silently wins at runtime. Under Tau the cage refuses to enter operating state and names the conflicting pair.
</details>

<details><summary><b>Demo 2. Rolling-window temporal enforcement (uses past-LTL O)</b>&nbsp;&nbsp;<code>demos/scenarios/rolling_window.py</code></summary>

![Demo 2 — rolling-window enforcement](./demos/recordings/rolling_window.gif)

Uses the unary past-LTL `O` operator. A Tau grammar feature we patched in during this project (see [`docs/tau-lang-bug-report-v2.md`](./docs/tau-lang-bug-report-v2.md)). Lowered to `T S φ` via the existing Since-elimination pass. No new decidability argument needed.
</details>

<details><summary><b>Demo 3. Live pointwise policy revision</b>&nbsp;&nbsp;<code>demos/scenarios/live_revision.py</code></summary>

![Demo 3 — live pointwise revision](./demos/recordings/live_revision.gif)

Compliance ships a rule at 4pm. It is live by 4:01 with a consistency proof. No daemon restart, no dropped requests.
</details>

## Integration

Ten lines in your facilitator. Flask shown; FastAPI + Express equivalents below.

```python
from adapter.x402_client import mediate

@app.route("/pay", methods=["POST"])
def pay():
    status, headers, body = mediate(
        request.headers,
        request.get_data(),
        SHARED_SECRET,  # from your KMS
    )
    return body, status, headers
```

Permit → 200 + `X-Policy-Verdict: permit`. Reject → 403 + signed envelope explaining why. Cage unreachable → signed 403 with `rule_id: cage_unavailable`. Fail-closed; no silent permits.

<details><summary><b>FastAPI</b>. Same contract, async-friendly</summary>

```python
from fastapi import FastAPI, Request, Response
from adapter.x402_client import mediate

app = FastAPI()

@app.post("/pay")
async def pay(request: Request):
    body = await request.body()
    status, headers, resp_body = mediate(
        dict(request.headers),
        body,
        SHARED_SECRET,
    )
    return Response(content=resp_body, status_code=status, headers=headers)
```

</details>

<details><summary><b>Express</b> (Node shim). The same wire contract, cage stays Python</summary>

```js
// Node calls a local Python daemon over UDS; cage core is the same Python module.
// Or run mock_facilitator/x402_server.py as a sidecar and proxy to it.
app.post("/pay", express.raw({ type: "*/*" }), async (req, res) => {
  const resp = await fetch("http://127.0.0.1:8402/pay", {
    method: "POST",
    headers: req.headers,
    body: req.body,
  });
  const body = await resp.arrayBuffer();
  resp.headers.forEach((v, k) => res.setHeader(k, v));
  res.status(resp.status).send(Buffer.from(body));
});
```

</details>

## Invariant types (V1)

Five invariants compile to pure Tau; two are enum-partial pending the `nlang` Boolean algebra unblock upstream.

```python
from decimal import Decimal
from adapter.invariants import MaxPerCall, ProviderAllowlist, compose

rules = [
    MaxPerCall(max_amount=Decimal("100")),
    ProviderAllowlist(providers=frozenset({"anthropic", "openai"})),
]
print(compose(rules))
# G(
#   (payment_amount[t]:bv[64] <= { 100000000 }:bv[64])
#   && ((provider[t]:bv[16] = { 50958 }:bv[16] || provider[t]:bv[16] = { 32049 }:bv[16]))
# ).
```

Full taxonomy reference: [`docs/x402-invariants.md`](./docs/x402-invariants.md). Every invariant is an immutable `@dataclass(frozen=True)` with constructor validation; `compose()` merges bodies under a single top-level `G(...)` to satisfy Tau's prohibition on nested temporal quantifiers.

## Security properties (proven via tests)

Four attacks, four defenses, four passing property tests in [`tests/test_verdict_signer.py`](./tests/test_verdict_signer.py):

| Attack | Defense | Test |
|---|---|---|
| Attacker flips `permit` ↔ `reject` header | HMAC-SHA256 over canonical payload | `test_tampered_outcome_fails_verify` |
| Attacker replays $10 permit against $10,000 intent | `intent_hash` binding checked before MAC | `test_replay_against_different_intent_fails` |
| Attacker replays expired permit | TTL + `issued_at` enforced | `test_expired_verdict_rejected` |
| Hostile payment intent injects Tau syntax | Safe-token regex on every field | `test_provider_injection_attempt_rejected` |

### What we're NOT claiming

> [!CAUTION]
> No software-only policy engine can defend against the four attacks below. Anyone who tells you otherwise is selling a prayer. We shift the attack surface from *"silent runtime drift"* (where you're breached and don't know for months) to *"spec review"* (where humans can catch mistakes). That is the trade we are offering.

| Out-of-scope attack | Your responsibility |
|---|---|
| Rule authorship errors (`$10,000` when you meant `$1,000`) | Review processes, spec testing, change management |
| Trusted Computing Base compromise | Process isolation, binary attestation, runtime monitoring |
| Side channels not modeled by the rules | Expand the spec to cover the channel |
| Info-leak via attributed verdict `rule_id` | Redact or generalize for external-facing contexts |

> [!IMPORTANT]
> **Compliance lead reviewing this for AI-Act or SR 11-7 posture?** The 10-slide pilot deck walks your team and engineering leads through an 8-week paid pilot with written success criteria (zero false blocks on existing-approved traffic, ≥1 silent issue surfaced in your current rule set, operator TTI < 30 minutes). Deck: [`docs/pitch/enterprise-pilot-deck.md`](./docs/pitch/enterprise-pilot-deck.md). Pilot call: [`services@idni.org`](mailto:services@idni.org).

## The standards story

The project is the reference implementation of a proposed RFC: [**Formal Policy Semantics for HTTP 402 Agentic Payments**](./docs/rfc/2026-04-x402-formal-policy-semantics.md) (draft-00, ~350 lines).

Normative requirements include: decidable rule-set composition; temporal fragment (LTL + past-LTL over atomless Boolean algebras); signed verdict envelope with intent binding; published TTI measurement protocol; IANA-registered `X-Policy-*` header namespace.

Targeted at the x402 Foundation working group and the Stripe+Tempo MPP spec team.

### Evaluation ladder. Pick your time budget

| You have | Read |
|---|---|
| **5 minutes** | [RFC Abstract + Motivation](./docs/rfc/2026-04-x402-formal-policy-semantics.md#abstract). Decide if this is your lane |
| **30 minutes** | RFC [§4 Rule Model](./docs/rfc/2026-04-x402-formal-policy-semantics.md#4-rule-model) + [§6 Wire Envelope](./docs/rfc/2026-04-x402-formal-policy-semantics.md#6-wire-envelope). You can critique the design |
| **2 hours** | Run the demos + full RFC + [`docs/mappings/x402-mapping.md`](./docs/mappings/x402-mapping.md). You can recommend it or tear it down |

### Comment on the draft

- GitHub Discussions on this repo (opens at public launch of the repo)
- The x402 Foundation WG mailing list when the WG charter ratifies. Track [Linux Foundation's x402 Foundation page](https://www.linuxfoundation.org/press/linux-foundation-is-launching-the-x402-foundation-and-welcoming-the-contribution-of-the-x402-protocol)
- Direct: [`services@idni.org`](mailto:services@idni.org). We reply to every RFC comment within 48 hours

## The TTI metric

**Time-to-First-Correct-Rejection** (TTI). The operator-ergonomics metric this project cares about. Every prior formal-methods tool (TLA+, Alloy, SPIN, Coq) is technically superior to OPA/Cedar and still lost every adoption battle because operators could not onboard in under an hour.

The RFC defines a shared test battery including contradictions that weaker engines silently accept. A vendor cannot win TTI by shipping an `init` wizard over strictly weaker semantics. The battery lives at [`specs/tti_battery/`](./specs/tti_battery/); the measurement script lives at [`scripts/tti-bench.sh`](./scripts/tti-bench.sh). CI gate blocks any PR pushing TTI above 15 minutes.

## Development

```bash
git clone https://github.com/Jme-Tau/tau-x402-cage.git && cd tau-x402-cage
pip install -e ".[dev]"

pytest tests/                              # 152 tests, ~10s
pytest --cov=adapter --cov=daemon tests/   # coverage ≥ 80% enforced in CI
pip install -e ".[saas]" && pytest saas/   # optional SaaS wrapper tests
bash scripts/tti-bench.sh                  # clean-machine TTI benchmark
docker build -t tau-x402-cage:local .      # Python-only slim runtime
```

The runtime image builds against `python:3.12-slim` (~216MB). The Tau SMT backend is a V0.3.1 capability and will be re-introduced as an optional base image once the upstream publish path lands.

## Licensing & commercial

Dual-licensed. Full terms in [`LICENSE`](./LICENSE), pricing and tier breakdown in [`docs/pricing.md`](./docs/pricing.md). Commercial contact: [`services@idni.org`](mailto:services@idni.org).

## Citations

- *Methods and systems for computation using a decidable temporal logic.* **US Patent 12,254,082**, granted 2026-03-18. Assignee: IDNI. Inventor: Ohad Asor.
- Asor, O. *Guarded Successor: A Novel Temporal Logic.* **arXiv:2407.06214**, 2024. [https://arxiv.org/abs/2407.06214](https://arxiv.org/abs/2407.06214)
- *Formal Policy Semantics for HTTP 402 Agentic Payments*. [RFC draft-00 (this repo)](./docs/rfc/2026-04-x402-formal-policy-semantics.md)

## Roadmap

- **V1 (now)**. 5 decidable + 2 enum-partial invariants; x402 primary, MPP mock for parity; signed envelope + intent binding; RFC draft-00.
- **V1.1**. Full string matching in `JurisdictionRule` / `CounterpartyConstraint` when `nlang` BA lands upstream.
- **V2**. Self-reference / NSO fragment: specs that reason about other specs.
- **V2.1**. MPP wire mapping first-class once an MPP spec-author conversation lands.
- **V3**. Asymmetric Ed25519 signing for multi-party attestation.

## Status

> [!NOTE]
> This repository is **currently private.** It goes public at the moment the RFC is submitted to the x402 Foundation working group. If you were given access early, please do not forward the link. Email [`services@idni.org`](mailto:services@idni.org) to loop someone in and they'll receive the same early access.

| Track | State |
|---|---|
| Code | V1 shipped, 89 tests, p95 < 10ms |
| Standards | RFC draft-00 drafted, targeted at x402 Foundation WG |
| Upstream (Tau Language) | 3 patches contributed, end-to-end verified |
| GTM | Pricing + pitch deck locked; outreach in progress |

## Contact

If you're building on x402 or MPP and want the policy layer solved, we'd like to talk.

- **General + commercial:** [services@idni.org](mailto:services@idni.org)
- **RFC comments:** services@idni.org, or the x402 Foundation WG mailing list when it opens
- **Security disclosures:** services@idni.org (PGP on request)

<!-- =========================================================================
     BEGIN INTERNAL. REMOVE BEFORE PUBLIC LAUNCH
     ========================================================================= -->

---

> [!WARNING]
> **The section below is for Ohad + Fola + IDNI internal review only.** Delete the entire block between the `BEGIN INTERNAL` / `END INTERNAL` HTML comment markers before making the repo public. Covers monetization, go-to-market, decision log, and open asks. Not for external eyes.

<details><summary><b>🔒 IDNI INTERNAL. Business review: monetization, GTM, open decisions</b></summary>

### Why this section exists

This README is the outward-facing artifact of the 90-day Tau + x402 standards-capture program. Before the repo goes public (targeted at x402 Foundation WG RFC submission), Ohad and Fola should have a single place to review the business envelope: how the project earns money, what traction targets it's aiming at, what strategic decisions are locked, and what's parked for your sign-off.

Full planning context lives in the companion project:
- [`../Tau-Safety-Cage/docs/plans/2026-04-18-001-feat-tau-x402-standards-capture-plan.v2.md`](../Tau-Safety-Cage/docs/plans/2026-04-18-001-feat-tau-x402-standards-capture-plan.v2.md). 12-week plan v2
- [`../Tau-Safety-Cage/docs/review/2026-04-18-plan-review-findings.md`](../Tau-Safety-Cage/docs/review/2026-04-18-plan-review-findings.md). 6-reviewer persona findings
- [`../Tau-Safety-Cage/docs/validation-parking-lot.md`](../Tau-Safety-Cage/docs/validation-parking-lot.md). 5 deferred validations with hard gates
- [`../Tau-Safety-Cage/docs/briefings/2026-04-18-x402-standards-capture-briefing.md`](../Tau-Safety-Cage/docs/briefings/2026-04-18-x402-standards-capture-briefing.md). Origin briefing

### Strategic position in three sentences

The agentic-payment rails (x402, MPP) just went neutral (Linux Foundation April 2; Stripe+Tempo March 18). Neither spec defines formal policy semantics, and no competitor has shipped decidable composition + signed verdicts. We have ~90 days to get Tau named as the reference semantics in the x402 Foundation RFC (and ideally the MPP spec too) while the window is open.

### Strategic decisions already locked (D1–D6)

These were reviewed via `/document-review` against six persona reviewers (product, feasibility, adversarial, scope, security, coherence); findings folded into plan v2.

| Ref | Decision | Outcome |
|---|---|---|
| **D1** | Architecture commitment | Hybrid. 5 invariants emit pure Tau, 2 (JurisdictionRule, CounterpartyConstraint) use enum encoding pending `nlang` BA unblock upstream |
| **D2** | Self-reference V2 first vs x402 port first | x402 port first. Self-reference V2 deferred to post-window; the satisfiability-on-composition check carries the declare-time contradiction demo in V1 |
| **D3** | Block on Ohad/Fola strategic conversation first | **No. Proceed with patches + validation evidence in hand.** Soft checkpoint scheduled Week 3-4 for your sign-off on the six commitments below |
| **D4** | Full premise-validation sprint before execution | Skipped; parking lot written. Items 1 (patent claim read) + 2 (LF IPR audit) remain hard gates. See "Open asks" below |
| **D5** | Monetization framing | Dual narrative. Commercial lead is **hosted SaaS + enterprise services + certification** (what customers actually buy). Patent is moat sustainability, not revenue line. Red Hat analogy reserved for technical + strategic audiences only |
| **D6** | Graduation criterion to option C (full company plan) | Tightened: `(R5 OR R6 OR R7) AND R2 AND R3` + second-touch quality gate. Self-issued artifacts alone (TTI + RFC + 10k impressions) cannot graduate the program. We require at least one external pull (TSC conversation, MPP author conversation, or pilot conversation) |

### Monetization. The four-tier model

Full detail: [`docs/pricing.md`](./docs/pricing.md).

| Tier | Price | Customer | Margin shape |
|---|---|---|---|
| OSS self-host | $0 | Indie devs, hobby projects, early-stage startups pre-pilot | Adoption wedge; no direct revenue but required for category adoption |
| Hosted SaaS | 8–12 bps of transaction value, per-transaction capped (tiers $99 – $2,999 / month + volume) | Startups + fintech engineering orgs running policy at scale without operating the cage themselves | SaaS gross margin 70–85% typical; anchor: Chainalysis ~10bps, Stripe Radar ~2bps |
| Enterprise self-host | $100k – $1M/yr flat + volume | Regulated Fortune 500 (banks, pharma, defense, payments incumbents) | Enterprise-software margins; small customer count, high ACV |
| Conformance certification | $10k – $50k per audit | Other policy engines wanting RFC-conformance badge | Services margin 50–60% |

### Revenue projection (honest, not aspirational)

| Year | Tier 2 SaaS | Tier 3 Enterprise | Tier 4 Cert | Total |
|---|---|---|---|---|
| 2026 | $0 – $100k | $0 – $400k | $0 | $0 – $500k |
| 2027 | $200k – $1M | $1M – $8M | $100k – $500k | $1.3M – $10M |
| 2028 | $2M – $20M | $10M – $60M | $1M – $5M | $13M – $85M |
| 2029–30 | $20M – $200M | $50M – $500M | $5M – $50M | $75M – $750M |

Driven by: x402 + MPP volume projection ($120M/yr 2026 → $10B+/yr by 2028 if Galaxy Digital's "30% of Base daily txs" holds); McKinsey $3–5T agentic commerce TAM by 2030; Tier 3 lands 3 customers in 2027, 10 by 2028, 30+ by 2030 at $500k–$1M average.

### 90-day standards-capture program. What we're running

**Horizon:** 2026-04-18 → 2026-07-17 (12 weeks)

**Three parallel tracks:**
- **Code**. V1 MVP shipped (89 tests green; full adapter + mock facilitator + demos; Tau patches verified)
- **Standards**. RFC draft-00 written + x402 wire mapping + three audience one-pagers; LF membership application drafting
- **GTM**. Outreach vault at `2-AREAS/IDNI/x402-outreach/` with contacts.md + pilots.md + sequence.md + crm.md templates; Wave 1 sends target Week 6; Wave 2 target Week 9

**Graduation (Week 12) requires all three of:**
1. **R2**. Published TTI benchmark <10 min, reproducible from public script, with ≥1 external reproduction
2. **R3**. RFC published as working draft with stable URL, linked from ≥1 public thread
3. **At least one of** R5 (TSC voting-member conversation with second-touch), R6 (MPP spec-author conversation with second-touch), R7 (regulated-enterprise pilot conversation with second-touch)

**Second-touch qualifier** (not just polite Zooms): counterparty initiates follow-up, requests the RFC, forwards it internally, OR proposes a next meeting with defined agenda.

### Outreach plan

**Wave 1. Standards audience (Weeks 6–8).** 15–20 contacts across x402 Foundation TSC backer orgs + MPP spec authors. Templates at [`../../2-AREAS/IDNI/x402-outreach/sequence.md`](../../2-AREAS/IDNI/x402-outreach/sequence.md). Contact research + scoring at [`../../2-AREAS/IDNI/x402-outreach/contacts.md`](../../2-AREAS/IDNI/x402-outreach/contacts.md) (names TBC. Your network will fill these faster than ours).

**Wave 2. Enterprise pilots (Weeks 9–12).** 5 regulated Fortune 500 candidates across banks / pharma / defense / agentic SaaS / Circle-Coinbase enterprise. Pitch deck at [`docs/pitch/enterprise-pilot-deck.md`](./docs/pitch/enterprise-pilot-deck.md). Pilots are 8-week paid with written success criteria and half-refund if we don't surface a silent issue in the customer's existing rule set.

**Cold-outreach limitation:** Regulated Fortune 500 rarely respond to cold email. Warm-intro mapping through Frontier / Tau Net DAO / your networks is the critical-path dependency for R7.

### Tau Language upstream contributions

Three bugs patched and verified via Python binding during the project:
- **Bug 1**. `solve_ltl_aba` pair-consistency over-rejection (5-line patch to `src/ltl_aba.tmpl.h`)
- **Bug 3**. Past-LTL `O` / `H` operators absent from grammar (8 files, first-class nodes lowered to `T S φ` via existing Since-elimination pass)
- **Bug 4**. `&` chains fail parser at wff level (1-line grammar alias for `&&`)

Both patch bundles at `../Tau-Safety-Cage/docs/upstream-fix-*.patch` + bug reports at `../Tau-Safety-Cage/docs/tau-lang-bug-report*.md`. **Ask:** please review before we open the public GitHub PR. Upstream-style bug reports drafted; submission sequence is v1 first (pair-consistency, already deployed locally) then v2 (grammar additions for O/H + &).

### Open asks. Your sign-off required before these steps

Listed in execution order. Each blocks a downstream milestone.

| # | Ask | Blocks | Timing |
|---|---|---|---|
| 1 | **Patent claim read**. IP counsel reads independent claims of US 12,254,082 and maps against the 7 commercial-moat claims in briefing §3. If any are narrower than assumed, Red Hat monetization story needs reframing. | RFC submission (R3); any written licensing claim | Before Week 4 |
| 2 | **LF x402 Foundation IPR policy audit**. Read charter + contributor agreement. If policy mandates royalty-free on all essential claims (W3C-style), contributing RFC *as a member* auto-grants what we want to license. | LF membership application (Unit 2.7) | Before Week 5 |
| 3 | **Sign-off on the six strategic commitments**. RFC under IDNI name; LF membership application as IDNI; public TTI benchmark commitment; royalty-free patent grant carve-out (conditions a/b/c in LICENSE); pricing tiers as published in `docs/pricing.md`; public repositioning from "DAO project launcher" (Tau Net deck) to "agentic payments policy" as IDNI's commercial front in 2026 | All public outreach (Wave 1 + 2) | Week 3-4 conversation |
| 4 | **Warm-intro leads from your network**. Any relationships at Stripe / Tempo / Paradigm / Visa / Mastercard / Coinbase / Circle / x402 Foundation TSC voters. Warm paths convert at 20-40× cold-email rates; we have none. | Wave 1 quality (R5 + R6 conversions) | Before Week 6 |
| 5 | **Warm-intro leads for regulated-enterprise pilots**. Any relationships at banks / pharma / defense / Fortune 500 AI-governance leads. R7 is structurally unreachable in 90 days without at least one warm path. | Wave 2 R7 | Before Week 8 |
| 6 | **Bug-report review + upstream PR approval**. Read `../Tau-Safety-Cage/docs/tau-lang-bug-report.md` + v2 + both patch files. Patches verified locally; want your eyes before public submission. | Upstream credibility (signals to x402 Foundation that we're real Tau contributors, not just consumers) | Before Week 6 |

### Graduation signal. What success looks like at Week 12

- **Graduate to Option C (full company plan + fundraise conversation):** R2 ✓, R3 ✓, AND (R5 ✓ with second-touch OR R6 ✓ with second-touch OR R7 ✓ with second-touch)
- **Continue iterating on B (90-day program extended 90 days):** some but not all of the above; TSC or MPP WG has acknowledged the RFC exists; no pilot conversation landed
- **Pivot:** zero external pull by Week 12 despite shipped code + RFC + demo reel → reframe the project or reassign IDNI resources

### Questions I'd want answered in the Week 3-4 conversation

1. Is "agentic payments policy" the right commercial identity for IDNI in 2026, or does it overshadow the DAO-launcher story in the Tau Net deck?
2. Willingness to file a patent-grant carve-out for conforming OSS implementations (condition `a`/`b`/`c` in `LICENSE`)? Loses some patent optionality; buys standards-track credibility.
3. Who's the Tau Net brand voice on this? IDNI account, your personal Fola/Ohad channels, or a new `@tau_x402_cage` X handle?
4. Do we announce the project publicly (X + HN + blog) on RFC submission, or keep private until first TSC conversation lands?
5. What's the "no" criterion? At what signal do we stop this line of work and pivot to the self-reference V2 demo?

### How to respond

Reply to this section directly via GitHub PR, email me at `services@idni.org`, or raise in our next 1:1. Happy to walk through any of the above live. The 90-day clock is running but the Week 3-4 conversation is the natural checkpoint before anything irreversible.

. IDNI, 2026-04-18

</details>

<!-- =========================================================================
     END INTERNAL. REMOVE BEFORE PUBLIC LAUNCH
     ========================================================================= -->
