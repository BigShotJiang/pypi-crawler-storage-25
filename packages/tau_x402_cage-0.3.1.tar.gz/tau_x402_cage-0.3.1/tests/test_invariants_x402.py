"""Unit tests for adapter/invariants.py.

Organized per the invariant taxonomy in docs/x402-invariants.md. Each type has
happy-path, edge, and error-path cases. Composition tests live in
test_invariants_x402_composition.py (contradiction detection via sat is tested
separately because it requires the Tau daemon).
"""

from __future__ import annotations

from decimal import Decimal

import pytest

from adapter.invariants import (
    ContradictionError,
    CounterpartyConstraint,
    Invariant,
    InvariantError,
    JurisdictionRule,
    MaxPerCall,
    ProviderAllowlist,
    RetryRateLimit,
    RollingWindowCap,
    SpendingCap,
    compose,
)


# ── SpendingCap ──────────────────────────────────────────────────────────────


class TestSpendingCap:
    def test_per_tx_scope_emits_valid_fragment(self) -> None:
        cap = SpendingCap(max_amount=Decimal("50.00"), scope="per_tx")
        spec = cap.to_tau_spec()
        assert "payment_amount[t]" in spec
        assert "<=" in spec
        assert "bv[64]" in spec
        # 50.00 USDC = 50_000_000 micro-units
        assert "50000000" in spec

    def test_per_window_scope_requires_window_seconds(self) -> None:
        with pytest.raises(InvariantError, match="window_seconds"):
            SpendingCap(max_amount=Decimal("1000"), scope="per_window")

    def test_per_window_scope_emits_cumulative_variable(self) -> None:
        cap = SpendingCap(max_amount=Decimal("1000"), scope="per_window", window_seconds=86400)
        assert "cumulative_spend" in cap.to_tau_spec()

    def test_per_provider_scope_requires_provider(self) -> None:
        with pytest.raises(InvariantError, match="provider"):
            SpendingCap(
                max_amount=Decimal("1000"), scope="per_provider_per_window", window_seconds=86400
            )

    def test_per_provider_emits_provider_gate(self) -> None:
        cap = SpendingCap(
            max_amount=Decimal("500"),
            scope="per_provider_per_window",
            window_seconds=86400,
            provider="anthropic",
        )
        spec = cap.to_tau_spec()
        assert "provider[t]" in spec
        assert "->" in spec
        assert "cumulative_provider_spend" in spec

    def test_zero_amount_rejected(self) -> None:
        with pytest.raises(InvariantError, match="must be > 0"):
            SpendingCap(max_amount=Decimal("0"), scope="per_tx")

    def test_negative_amount_rejected(self) -> None:
        with pytest.raises(InvariantError, match="must be > 0"):
            SpendingCap(max_amount=Decimal("-10"), scope="per_tx")

    def test_immutability(self) -> None:
        cap = SpendingCap(max_amount=Decimal("100"), scope="per_tx")
        with pytest.raises(AttributeError):
            cap.max_amount = Decimal("999")  # type: ignore[misc]


# ── MaxPerCall ───────────────────────────────────────────────────────────────


class TestMaxPerCall:
    def test_emits_payment_amount_comparator(self) -> None:
        cap = MaxPerCall(max_amount=Decimal("10"))
        spec = cap.to_tau_spec()
        assert "payment_amount[t]" in spec
        assert "<=" in spec
        assert "10000000" in spec  # 10 USDC in micro-units

    def test_zero_rejected(self) -> None:
        with pytest.raises(InvariantError):
            MaxPerCall(max_amount=Decimal("0"))


# ── ProviderAllowlist ────────────────────────────────────────────────────────


class TestProviderAllowlist:
    def test_single_provider(self) -> None:
        allow = ProviderAllowlist(providers=frozenset({"anthropic"}))
        spec = allow.to_tau_spec()
        assert "provider[t]" in spec
        assert "G(" in spec
        assert "bv[16]" in spec

    def test_multiple_providers_become_disjunction(self) -> None:
        allow = ProviderAllowlist(providers=frozenset({"anthropic", "openai", "replicate"}))
        spec = allow.to_tau_spec()
        assert spec.count("||") == 2  # 3 providers → 2 disjunctions

    def test_empty_rejected(self) -> None:
        with pytest.raises(InvariantError, match="at least one"):
            ProviderAllowlist(providers=frozenset())

    def test_deterministic_ordering(self) -> None:
        """Same providers → same spec regardless of frozenset ordering."""
        a = ProviderAllowlist(providers=frozenset({"anthropic", "openai"}))
        b = ProviderAllowlist(providers=frozenset({"openai", "anthropic"}))
        assert a.to_tau_spec() == b.to_tau_spec()


# ── RetryRateLimit ───────────────────────────────────────────────────────────


class TestRetryRateLimit:
    def test_basic_emission(self) -> None:
        rl = RetryRateLimit(min_gap_seconds=60)
        spec = rl.to_tau_spec()
        assert "retry[t]" in spec
        assert "O(" in spec  # uses patched past-LTL Once operator
        assert "60" in spec

    def test_zero_gap_rejected(self) -> None:
        with pytest.raises(InvariantError, match="must be > 0"):
            RetryRateLimit(min_gap_seconds=0)

    def test_excessive_gap_rejected(self) -> None:
        with pytest.raises(InvariantError, match="V1"):
            RetryRateLimit(min_gap_seconds=301)


# ── RollingWindowCap ─────────────────────────────────────────────────────────


class TestRollingWindowCap:
    def test_provider_grouping(self) -> None:
        rw = RollingWindowCap(max_count=5, window_seconds=600, group_by="provider")
        assert "count_per_provider_in_window" in rw.to_tau_spec()

    def test_global_grouping(self) -> None:
        rw = RollingWindowCap(max_count=10, window_seconds=3600, group_by="global")
        assert "count_in_window[t]" in rw.to_tau_spec()

    def test_bv_width_scales_with_count(self) -> None:
        small = RollingWindowCap(max_count=5, window_seconds=60)
        large = RollingWindowCap(max_count=500, window_seconds=60)
        assert "bv[8]" in small.to_tau_spec()
        assert "bv[16]" in large.to_tau_spec()

    def test_zero_count_rejected(self) -> None:
        with pytest.raises(InvariantError):
            RollingWindowCap(max_count=0, window_seconds=60)


# ── JurisdictionRule (enum-partial) ──────────────────────────────────────────


class TestJurisdictionRule:
    def test_empty_additional_is_noop(self) -> None:
        rule = JurisdictionRule(jurisdiction="EU")
        assert rule.to_tau_spec() == "G(T)"

    def test_with_nested_spending_cap(self) -> None:
        nested = SpendingCap(max_amount=Decimal("100"), scope="per_tx")
        rule = JurisdictionRule(jurisdiction="EU", additional_invariants=(nested,))
        spec = rule.to_tau_spec()
        assert "provider_jurisdiction[t]" in spec
        assert "bv[4]" in spec
        assert "->" in spec


# ── CounterpartyConstraint (enum-partial) ────────────────────────────────────


class TestCounterpartyConstraint:
    def test_approved_only(self) -> None:
        c = CounterpartyConstraint(approved_ids=frozenset({"vendor_a", "vendor_b"}))
        spec = c.to_tau_spec()
        assert "counterparty[t]" in spec
        assert spec.count("||") == 1  # 2 approved → 1 disjunction

    def test_sanctioned_only(self) -> None:
        c = CounterpartyConstraint(sanctioned_ids=frozenset({"bad_actor"}))
        spec = c.to_tau_spec()
        assert "!=" in spec

    def test_overlap_rejected(self) -> None:
        with pytest.raises(InvariantError, match="overlap"):
            CounterpartyConstraint(
                approved_ids=frozenset({"x", "y"}),
                sanctioned_ids=frozenset({"y", "z"}),
            )

    def test_empty_is_noop(self) -> None:
        c = CounterpartyConstraint()
        assert c.to_tau_spec() == "G(T)"


# ── composition ──────────────────────────────────────────────────────────────


class TestCompose:
    def test_empty_list(self) -> None:
        assert compose([]) == "G(T)."

    def test_single_invariant_ends_with_period(self) -> None:
        cap = MaxPerCall(max_amount=Decimal("10"))
        spec = compose([cap])
        assert spec.endswith(".")

    def test_multiple_invariants_conjoined(self) -> None:
        specs = compose([
            MaxPerCall(max_amount=Decimal("50")),
            ProviderAllowlist(providers=frozenset({"anthropic"})),
        ])
        assert specs.count("&&") == 1
        assert specs.endswith(".")

    def test_deterministic_for_same_input(self) -> None:
        a = [MaxPerCall(max_amount=Decimal("10")), MaxPerCall(max_amount=Decimal("20"))]
        assert compose(a) == compose(a)


# ── smoke: all types are subclasses of Invariant ────────────────────────────


def test_all_types_are_invariants() -> None:
    for cls in (
        SpendingCap,
        MaxPerCall,
        ProviderAllowlist,
        RetryRateLimit,
        RollingWindowCap,
        JurisdictionRule,
        CounterpartyConstraint,
    ):
        assert issubclass(cls, Invariant)
