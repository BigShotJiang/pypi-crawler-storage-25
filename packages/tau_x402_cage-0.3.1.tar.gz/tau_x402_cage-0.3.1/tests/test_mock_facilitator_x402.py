"""End-to-end integration tests: mock facilitator + cage + demo daemon."""

from __future__ import annotations

import json
import threading
import time
import urllib.error
import urllib.request
from decimal import Decimal

import pytest

from mock_facilitator.x402_server import DemoDaemon, make_server


SECRET = b"test-secret-at-least-16-bytes-long-yes"


@pytest.fixture(scope="module")
def server():
    srv = make_server(port=18402, secret=SECRET, daemon=DemoDaemon())
    thread = threading.Thread(target=srv.serve_forever, daemon=True)
    thread.start()
    time.sleep(0.05)  # give server a moment to bind
    yield srv
    srv.shutdown()


def _post(path: str, body: dict, headers: dict = None) -> tuple[int, dict, bytes]:
    url = f"http://127.0.0.1:18402{path}"
    body_bytes = json.dumps(body).encode("utf-8")
    req = urllib.request.Request(url, data=body_bytes, method="POST")
    req.add_header("Content-Type", "application/json")
    for k, v in (headers or {}).items():
        req.add_header(k, v)
    try:
        resp = urllib.request.urlopen(req, timeout=2)
        return resp.status, dict(resp.headers), resp.read()
    except urllib.error.HTTPError as e:
        return e.code, dict(e.headers), e.read()


def _intent(**overrides) -> dict:
    base = {
        "amount": "50",
        "currency": "USDC",
        "provider": "anthropic",
        "counterparty": "vendor_x",
        "timestamp": 1713456789,
    }
    base.update(overrides)
    return base


class TestFacilitatorFlow:
    def test_returns_402_without_payment_header(self, server) -> None:
        status, _, _ = _post("/pay", _intent())
        assert status == 402

    def test_permits_valid_intent_with_payment(self, server) -> None:
        status, headers, body = _post(
            "/pay", _intent(), headers={"X-PAYMENT": "stubbed"}
        )
        assert status == 200
        assert headers["X-Policy-Verdict"] == "permit"

    def test_rejects_over_per_call_cap(self, server) -> None:
        # DemoDaemon's per_call_cap is $100
        status, headers, _ = _post(
            "/pay", _intent(amount="150"), headers={"X-PAYMENT": "stubbed"}
        )
        assert status == 403
        assert headers["X-Policy-Verdict"] == "reject"
        assert headers["X-Policy-Rule-Id"] == "max_per_call"

    def test_rejects_unknown_provider(self, server) -> None:
        status, headers, _ = _post(
            "/pay",
            _intent(provider="unknown_llm", amount="10"),
            headers={"X-PAYMENT": "stubbed"},
        )
        assert status == 403
        assert headers["X-Policy-Rule-Id"] == "provider_allowlist"


class TestCumulativeBehavior:
    """Each test gets its own server so cumulative state is isolated."""

    def test_daily_cap_cumulative(self) -> None:
        srv = make_server(port=18403, secret=SECRET, daemon=DemoDaemon())
        t = threading.Thread(target=srv.serve_forever, daemon=True)
        t.start()
        time.sleep(0.05)
        try:
            # Send 10x $100 payments to anthropic = $1000 cumulative (AT cap)
            for i in range(10):
                req = urllib.request.Request(
                    "http://127.0.0.1:18403/pay",
                    data=json.dumps(_intent(amount="100", timestamp=1713456789 + i)).encode(),
                    method="POST",
                )
                req.add_header("Content-Type", "application/json")
                req.add_header("X-PAYMENT", "stubbed")
                resp = urllib.request.urlopen(req, timeout=2)
                assert resp.status == 200, f"payment {i+1} should permit"

            # 11th payment (even $1) should exceed
            req = urllib.request.Request(
                "http://127.0.0.1:18403/pay",
                data=json.dumps(_intent(amount="1", timestamp=1713456790)).encode(),
                method="POST",
            )
            req.add_header("Content-Type", "application/json")
            req.add_header("X-PAYMENT", "stubbed")
            try:
                urllib.request.urlopen(req, timeout=2)
                pytest.fail("expected 403 on cap-exceeding payment")
            except urllib.error.HTTPError as e:
                assert e.code == 403
                assert e.headers["X-Policy-Rule-Id"] == "spending_cap_daily"
        finally:
            srv.shutdown()


class TestMalformedRequests:
    def test_malformed_body_returns_signed_reject(self, server) -> None:
        req = urllib.request.Request(
            "http://127.0.0.1:18402/pay",
            data=b"{ not json",
            method="POST",
        )
        req.add_header("Content-Type", "application/json")
        req.add_header("X-PAYMENT", "stubbed")
        try:
            urllib.request.urlopen(req, timeout=2)
            pytest.fail("expected error")
        except urllib.error.HTTPError as e:
            assert e.code == 403
            assert e.headers["X-Policy-Rule-Id"] == "invalid_payment_intent"
