"""Tests for verdict_signer.py, HMAC signing + intent binding + TTL + replay.

These tests are load-bearing for security findings C-01 and C-02: the whole
pilot story depends on verdicts being authenticatable and replay-resistant.
"""

from __future__ import annotations

from decimal import Decimal

import pytest

from adapter.payment_intent_matcher import PaymentIntent
from adapter.verdict_signer import (
    SignatureError,
    SignedEnvelope,
    Verdict,
    VerdictExpired,
    hash_intent,
    sign,
    verify,
)


SECRET = b"test-secret-at-least-16-bytes-long-yes"
OTHER_SECRET = b"different-secret-but-also-16-plus-bytes"


def make_intent(**overrides) -> PaymentIntent:
    base = dict(
        amount=Decimal("50"),
        currency="USDC",
        provider="anthropic",
        counterparty="vendor_x",
        rail="x402",
        timestamp_unix=1713456789,
    )
    base.update(overrides)
    return PaymentIntent(**base)


# ── hash_intent ──────────────────────────────────────────────────────────────


class TestHashIntent:
    def test_deterministic(self) -> None:
        i = make_intent()
        assert hash_intent(i) == hash_intent(i)

    def test_changes_with_amount(self) -> None:
        a = make_intent(amount=Decimal("10"))
        b = make_intent(amount=Decimal("20"))
        assert hash_intent(a) != hash_intent(b)

    def test_changes_with_provider(self) -> None:
        a = make_intent(provider="anthropic")
        b = make_intent(provider="openai")
        assert hash_intent(a) != hash_intent(b)

    def test_metadata_ordering_does_not_matter(self) -> None:
        # sorted internally → same hash regardless of dict insertion order
        a = make_intent(timestamp_unix=1)
        # PaymentIntent metadata is a plain mapping at construction time; post-init
        # it's stored as-is. hash_intent sorts keys internally, so any dict that
        # compares equal produces the same hash.
        i1 = PaymentIntent(**{**{f.name: getattr(a, f.name) for f in a.__dataclass_fields__.values() if f.name != "metadata"}, "metadata": {"x": "1", "y": "2"}})
        i2 = PaymentIntent(**{**{f.name: getattr(a, f.name) for f in a.__dataclass_fields__.values() if f.name != "metadata"}, "metadata": {"y": "2", "x": "1"}})
        assert hash_intent(i1) == hash_intent(i2)


# ── sign / verify round-trip ─────────────────────────────────────────────────


class TestSignVerify:
    def test_round_trip_permit(self) -> None:
        intent = make_intent()
        env = sign(Verdict(outcome="permit"), intent, SECRET, now_unix=1000)
        verify(env, intent, SECRET, now_unix=1000)  # should not raise

    def test_round_trip_reject_with_fields(self) -> None:
        intent = make_intent()
        v = Verdict(
            outcome="reject",
            rule_id="spending_cap_daily",
            witness="cumulative=$1002, cap=$1000",
            reason_text="Daily spending cap of $1000 exceeded.",
        )
        env = sign(v, intent, SECRET, now_unix=2000)
        verify(env, intent, SECRET, now_unix=2000)
        assert env.rule_id == "spending_cap_daily"

    def test_short_secret_rejected(self) -> None:
        with pytest.raises(SignatureError, match="16 bytes"):
            sign(Verdict(outcome="permit"), make_intent(), b"short", now_unix=1)


class TestSecurityProperties:
    """Load-bearing: these tests prove C-01 (no spoof) and C-02 (no replay)."""

    def test_wrong_secret_fails_verify(self) -> None:
        intent = make_intent()
        env = sign(Verdict(outcome="permit"), intent, SECRET, now_unix=1)
        with pytest.raises(SignatureError, match="MAC verification"):
            verify(env, intent, OTHER_SECRET, now_unix=1)

    def test_tampered_outcome_fails_verify(self) -> None:
        """An attacker who flips permit→reject without the secret fails verify."""
        intent = make_intent()
        env = sign(Verdict(outcome="reject", rule_id="r1"), intent, SECRET, now_unix=1)
        # Tampered envelope: flip outcome to permit while keeping original MAC
        tampered = SignedEnvelope(
            outcome="permit",
            rule_id=env.rule_id,
            witness=env.witness,
            reason_text=env.reason_text,
            issued_at_unix=env.issued_at_unix,
            ttl_seconds=env.ttl_seconds,
            intent_hash=env.intent_hash,
            mac_hex=env.mac_hex,
        )
        with pytest.raises(SignatureError, match="MAC verification"):
            verify(tampered, intent, SECRET, now_unix=1)

    def test_replay_against_different_intent_fails(self) -> None:
        """C-02: a permit for intent A cannot be replayed against intent B."""
        intent_a = make_intent(amount=Decimal("10"))
        intent_b = make_intent(amount=Decimal("10000"))
        env = sign(Verdict(outcome="permit"), intent_a, SECRET, now_unix=1)
        # Replay attempt: present env for intent_b (different amount) within TTL
        with pytest.raises(SignatureError, match="intent_hash mismatch"):
            verify(env, intent_b, SECRET, now_unix=1)

    def test_expired_verdict_rejected(self) -> None:
        intent = make_intent()
        env = sign(
            Verdict(outcome="permit", ttl_seconds=30),
            intent,
            SECRET,
            now_unix=1000,
        )
        # Past TTL: 1000 + 30 + 1 = 1031
        with pytest.raises(VerdictExpired):
            verify(env, intent, SECRET, now_unix=1031)

    def test_within_ttl_accepted(self) -> None:
        intent = make_intent()
        env = sign(
            Verdict(outcome="permit", ttl_seconds=30),
            intent,
            SECRET,
            now_unix=1000,
        )
        verify(env, intent, SECRET, now_unix=1029)  # 29s < 30s, still valid


# ── wire serialization ──────────────────────────────────────────────────────


class TestWireSerialization:
    def test_round_trip_via_json(self) -> None:
        intent = make_intent()
        env = sign(
            Verdict(outcome="reject", rule_id="r1", reason_text="blocked"),
            intent,
            SECRET,
            now_unix=1,
        )
        wire = env.to_json()
        parsed = SignedEnvelope.from_json(wire)
        assert parsed == env
        # Verify still works after a round-trip through JSON
        verify(parsed, intent, SECRET, now_unix=1)

    def test_malformed_wire_rejected(self) -> None:
        with pytest.raises(SignatureError, match="valid JSON"):
            SignedEnvelope.from_json("not-json")

    def test_missing_fields_rejected(self) -> None:
        with pytest.raises(SignatureError, match="missing required"):
            SignedEnvelope.from_json('{"outcome":"permit"}')
