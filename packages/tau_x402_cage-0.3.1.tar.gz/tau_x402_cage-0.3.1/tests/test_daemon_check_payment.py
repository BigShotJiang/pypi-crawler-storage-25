"""Integration tests: real CageDaemon process + UdsDaemonClient round-trip.

These tests spin up a daemon in a thread with a short /tmp/<short>.sock path
(macOS UDS path limit ~104 chars; pytest's tmp_path is too long). Each test is
self-contained: declare invariants via UDS, send check_payment, assert verdict.
"""
from __future__ import annotations

import os
import socket
import tempfile
import threading
import time
from decimal import Decimal
from typing import Iterator

import pytest

from adapter.payment_intent_matcher import PaymentIntent
from adapter.x402_client import UdsDaemonClient, mediate
from adapter.verdict_signer import verify
from adapter.x402_envelope import from_http_response
from daemon.server import CageDaemon


SECRET = b"integration-test-secret-at-least-16-bytes-long"


@pytest.fixture
def daemon() -> Iterator[tuple[CageDaemon, str]]:
    # Short UDS path (macOS limit ~104 chars)
    fd, path = tempfile.mkstemp(prefix="x402-", suffix=".sock", dir="/tmp")
    os.close(fd)
    os.unlink(path)

    d = CageDaemon(socket_path=path)
    t = threading.Thread(target=d.serve_forever, daemon=True)
    t.start()
    # Wait for socket to come up
    for _ in range(50):
        if os.path.exists(path):
            break
        time.sleep(0.01)
    try:
        yield d, path
    finally:
        d.shutdown()
        t.join(timeout=1.0)


def _send(path: str, request: dict) -> dict:
    import json
    s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    s.settimeout(2.0)
    s.connect(path)
    try:
        s.sendall((json.dumps(request) + "\n").encode("utf-8"))
        f = s.makefile("r")
        line = f.readline()
    finally:
        s.close()
    return json.loads(line)


class TestHealth:
    def test_health_op_reports_backend_and_counters(self, daemon) -> None:
        _, path = daemon
        r = _send(path, {"op": "health"})
        assert r["verdict"] == "ok"
        assert r["ready"] is True
        assert r["prover_backend"]
        assert r["invariants_active"] == 0
        assert r["revision_log_length"] == 0

    def test_health_counters_track_declares_and_payments(self, daemon) -> None:
        _, path = daemon
        _send(path, {"op": "declare_x402", "kind": "max_per_call", "max_amount": "10"})
        _send(path, {
            "op": "check_payment",
            "intent": {
                "amount": "5", "currency": "USDC",
                "provider": "anthropic", "counterparty": "v",
                "rail": "x402", "timestamp_unix": 1_700_000_000,
                "metadata": {}, "request_id": None,
            },
        })
        r = _send(path, {"op": "health"})
        assert r["invariants_active"] == 1
        assert r["revision_log_length"] == 1
        assert r["payment_history_length"] == 1


class TestEmptyRegistry:
    def test_no_invariants_permits(self, daemon) -> None:
        _, path = daemon
        response = _send(path, {
            "op": "check_payment",
            "intent": {
                "amount": "50.00",
                "currency": "USDC",
                "provider": "anthropic",
                "counterparty": "vendor_x",
                "rail": "x402",
                "timestamp_unix": 1_700_000_000,
                "metadata": {},
                "request_id": None,
            },
        })
        assert response["verdict"] == "permit"
        assert response["rule_id"] is None


class TestMaxPerCallOp:
    def test_declare_and_reject(self, daemon) -> None:
        _, path = daemon
        decl = _send(path, {
            "op": "declare_x402",
            "kind": "max_per_call",
            "max_amount": "10.00",
            "currency": "USDC",
        })
        assert decl["verdict"] == "updated"
        assert decl["active_invariants"] == 1

        resp = _send(path, {
            "op": "check_payment",
            "intent": {
                "amount": "50.00",
                "currency": "USDC",
                "provider": "anthropic",
                "counterparty": "vendor_x",
                "rail": "x402",
                "timestamp_unix": 1_700_000_000,
                "metadata": {},
                "request_id": None,
            },
        })
        assert resp["verdict"] == "reject"
        assert resp["rule_id"] == "max_per_call"
        assert "10" in resp["reason_text"]


class TestSpendingCapAggregation:
    def test_aggregates_across_calls(self, daemon) -> None:
        _, path = daemon
        _send(path, {
            "op": "declare_x402",
            "kind": "spending_cap",
            "max_amount": "100.00",
            "currency": "USDC",
            "scope": "per_window",
            "window_seconds": 3600,
        })
        base = 1_700_000_000
        for i, amt in enumerate(["30", "30", "30"]):
            r = _send(path, {
                "op": "check_payment",
                "intent": {
                    "amount": amt, "currency": "USDC",
                    "provider": "anthropic", "counterparty": "v",
                    "rail": "x402", "timestamp_unix": base + i,
                    "metadata": {}, "request_id": None,
                },
            })
            assert r["verdict"] == "permit", f"call {i} unexpectedly rejected: {r}"
        # Fourth call totals 120 > 100
        r = _send(path, {
            "op": "check_payment",
            "intent": {
                "amount": "30", "currency": "USDC",
                "provider": "anthropic", "counterparty": "v",
                "rail": "x402", "timestamp_unix": base + 10,
                "metadata": {}, "request_id": None,
            },
        })
        assert r["verdict"] == "reject"
        assert r["rule_id"] == "spending_cap_per_window"


class TestMediateEndToEnd:
    def test_mediate_with_real_daemon(self, daemon) -> None:
        """`mediate()` → UdsDaemonClient → daemon → signed envelope round-trip."""
        _, path = daemon
        _send(path, {
            "op": "declare_x402",
            "kind": "provider_allowlist",
            "providers": ["anthropic"],
        })
        body = (
            b'{"amount": "25.00", "currency": "USDC", '
            b'"provider": "sketchy_provider", "counterparty": "vendor_x", '
            b'"timestamp": 1700000000}'
        )
        client = UdsDaemonClient(socket_path=path, timeout_sec=2.0)
        status, headers, response_body = mediate({}, body, SECRET, daemon=client)
        assert status == 403, headers
        assert headers["X-Policy-Verdict"] == "reject"
        assert headers["X-Policy-Rule-Id"] == "provider_allowlist"
        env = from_http_response(headers, response_body)
        # Envelope still signs and verifies against the rejected intent
        intent = PaymentIntent(
            amount=Decimal("25.00"), currency="USDC",
            provider="sketchy_provider", counterparty="vendor_x",
            rail="x402", timestamp_unix=1_700_000_000,
        )
        verify(env, intent, SECRET)

    def test_mediate_permit_path(self, daemon) -> None:
        _, path = daemon
        body = (
            b'{"amount": "25.00", "currency": "USDC", '
            b'"provider": "anthropic", "counterparty": "vendor_x", '
            b'"timestamp": 1700000000}'
        )
        client = UdsDaemonClient(socket_path=path, timeout_sec=2.0)
        status, headers, _ = mediate({}, body, SECRET, daemon=client)
        assert status == 200
        assert headers["X-Policy-Verdict"] == "permit"


class TestDaemonOps:
    def test_active_x402_returns_kinds(self, daemon) -> None:
        _, path = daemon
        _send(path, {"op": "declare_x402", "kind": "max_per_call", "max_amount": "1"})
        _send(path, {"op": "declare_x402", "kind": "retry_rate_limit", "min_gap_seconds": 5})
        r = _send(path, {"op": "active_x402"})
        assert r["verdict"] == "ok"
        assert r["active_invariants"] == 2
        assert set(r["kinds"]) == {"MaxPerCall", "RetryRateLimit"}

    def test_retract_x402(self, daemon) -> None:
        _, path = daemon
        decl = {"op": "declare_x402", "kind": "max_per_call", "max_amount": "1"}
        _send(path, decl)
        ret = _send(path, {"op": "retract_x402", **{k: v for k, v in decl.items() if k != "op"}})
        assert ret["verdict"] == "retracted"
        assert ret["active_invariants"] == 0

    def test_malformed_intent_is_signed_reject(self, daemon) -> None:
        _, path = daemon
        r = _send(path, {"op": "check_payment", "intent": "not a dict"})
        assert r["verdict"] == "reject"
        assert r["rule_id"] == "malformed_request"

    def test_invalid_provider_schema_rejects(self, daemon) -> None:
        _, path = daemon
        r = _send(path, {
            "op": "check_payment",
            "intent": {
                "amount": "1.00", "currency": "USDC",
                "provider": "has spaces",  # fails safe-token schema
                "counterparty": "v", "rail": "x402",
                "timestamp_unix": 1_700_000_000, "metadata": {}, "request_id": None,
            },
        })
        assert r["verdict"] == "reject"
        assert r["rule_id"] == "invalid_payment_intent"
