"""Unit tests for X402Registry + each invariant's Python-side check_payment.

Covers the per-call fast path. Contradiction detection at declare time is
exercised by the existing Tau-backed tests.
"""
from __future__ import annotations

from decimal import Decimal

import pytest

from adapter.invariants import (
    CounterpartyConstraint,
    JurisdictionRule,
    MaxPerCall,
    ProviderAllowlist,
    RetryRateLimit,
    RollingWindowCap,
    SpendingCap,
)
from adapter.payment_intent_matcher import PaymentIntent
from adapter.x402_registry import X402Registry


def make_intent(
    amount: str = "10.00",
    provider: str = "anthropic",
    counterparty: str = "vendor_x",
    ts: int = 1_700_000_000,
    currency: str = "USDC",
    metadata: dict | None = None,
) -> PaymentIntent:
    return PaymentIntent(
        amount=Decimal(amount),
        currency=currency,
        provider=provider,
        counterparty=counterparty,
        rail="x402",
        timestamp_unix=ts,
        metadata=metadata or {},
    )


class TestMaxPerCall:
    def test_permits_under_cap(self) -> None:
        inv = MaxPerCall(max_amount=Decimal("100"))
        assert inv.check_payment(make_intent("50"), ()) is None

    def test_permits_equal_to_cap(self) -> None:
        inv = MaxPerCall(max_amount=Decimal("100"))
        assert inv.check_payment(make_intent("100"), ()) is None

    def test_rejects_over_cap(self) -> None:
        inv = MaxPerCall(max_amount=Decimal("100"))
        v = inv.check_payment(make_intent("100.01"), ())
        assert v is not None
        assert v.rule_id == "max_per_call"
        assert "100.01" in v.witness

    def test_ignores_different_currency(self) -> None:
        inv = MaxPerCall(max_amount=Decimal("100"), currency="USDC")
        assert inv.check_payment(make_intent("1000", currency="DAI"), ()) is None


class TestSpendingCap:
    def test_per_tx_rejects_over(self) -> None:
        inv = SpendingCap(max_amount=Decimal("50"), scope="per_tx")
        v = inv.check_payment(make_intent("60"), ())
        assert v is not None
        assert "per_tx" in v.rule_id

    def test_per_window_aggregates_history(self) -> None:
        inv = SpendingCap(max_amount=Decimal("100"), scope="per_window", window_seconds=3600)
        history = (
            make_intent("40", ts=1_700_000_000),
            make_intent("50", ts=1_700_000_500),
        )
        new = make_intent("20", ts=1_700_001_000)  # 40+50+20=110 > 100
        v = inv.check_payment(new, history)
        assert v is not None
        assert "110" in v.witness

    def test_per_window_drops_old_entries(self) -> None:
        inv = SpendingCap(max_amount=Decimal("100"), scope="per_window", window_seconds=60)
        old = make_intent("80", ts=1_700_000_000)
        new = make_intent("50", ts=1_700_001_000)  # old is >60s ago, ignored
        assert inv.check_payment(new, (old,)) is None

    def test_per_provider_window_isolates_providers(self) -> None:
        inv = SpendingCap(
            max_amount=Decimal("50"),
            scope="per_provider_per_window",
            window_seconds=3600,
            provider="anthropic",
        )
        history = (make_intent("40", provider="openai", ts=1_700_000_000),)
        # Other-provider spend does not count against anthropic's cap
        new = make_intent("20", provider="anthropic", ts=1_700_000_100)
        assert inv.check_payment(new, history) is None


class TestProviderAllowlist:
    def test_permits_allowed_provider(self) -> None:
        inv = ProviderAllowlist(providers=frozenset({"anthropic", "openai"}))
        assert inv.check_payment(make_intent(provider="anthropic"), ()) is None

    def test_rejects_non_allowed(self) -> None:
        inv = ProviderAllowlist(providers=frozenset({"anthropic"}))
        v = inv.check_payment(make_intent(provider="sketchy"), ())
        assert v is not None
        assert v.rule_id == "provider_allowlist"


class TestRetryRateLimit:
    """V0.2 semantic: reject-triggered rate limiting.

    The rule is 'after a REJECTED intent for (provider, counterparty), no
    retry for min_gap_seconds'. Permits alone do not trigger the lockout.
    """

    def test_permits_ignored_when_no_rejects(self) -> None:
        """Frequent successful payments should NOT trip the rate limiter."""
        inv = RetryRateLimit(min_gap_seconds=60)
        permits = (
            make_intent(ts=1_700_000_000),
            make_intent(ts=1_700_000_001),
            make_intent(ts=1_700_000_002),
        )
        new = make_intent(ts=1_700_000_003)
        assert inv.check_payment(new, permits, rejects=()) is None

    def test_blocks_retry_after_recent_reject(self) -> None:
        inv = RetryRateLimit(min_gap_seconds=30)
        rejects = (make_intent(ts=1_700_000_000),)
        new = make_intent(ts=1_700_000_010)  # 10s < 30s gap
        v = inv.check_payment(new, history=(), rejects=rejects)
        assert v is not None
        assert v.rule_id == "retry_rate_limit"
        assert "10s" in v.witness

    def test_permits_retry_after_gap_elapsed(self) -> None:
        inv = RetryRateLimit(min_gap_seconds=10)
        rejects = (make_intent(ts=1_700_000_000),)
        new = make_intent(ts=1_700_000_020)  # 20s > 10s
        assert inv.check_payment(new, history=(), rejects=rejects) is None

    def test_ignores_rejects_for_other_provider(self) -> None:
        inv = RetryRateLimit(min_gap_seconds=60)
        rejects = (make_intent(provider="openai", ts=1_700_000_000),)
        new = make_intent(provider="anthropic", ts=1_700_000_010)
        assert inv.check_payment(new, history=(), rejects=rejects) is None

    def test_ignores_rejects_for_other_counterparty(self) -> None:
        inv = RetryRateLimit(min_gap_seconds=60)
        rejects = (make_intent(counterparty="vendor_a", ts=1_700_000_000),)
        new = make_intent(counterparty="vendor_b", ts=1_700_000_010)
        assert inv.check_payment(new, history=(), rejects=rejects) is None


class TestRollingWindowCap:
    def test_counts_within_window(self) -> None:
        inv = RollingWindowCap(max_count=3, window_seconds=60, group_by="provider")
        history = tuple(make_intent(ts=1_700_000_000 + i) for i in range(3))
        new = make_intent(ts=1_700_000_050)  # 4th in window
        v = inv.check_payment(new, history)
        assert v is not None
        assert "count=4" in v.witness

    def test_global_groups_ignore_provider(self) -> None:
        inv = RollingWindowCap(max_count=2, window_seconds=60, group_by="global")
        history = (
            make_intent(provider="a", ts=1_700_000_000),
            make_intent(provider="b", ts=1_700_000_001),
        )
        new = make_intent(provider="c", ts=1_700_000_002)  # 3rd globally
        v = inv.check_payment(new, history)
        assert v is not None


class TestCounterpartyConstraint:
    def test_rejects_sanctioned(self) -> None:
        inv = CounterpartyConstraint(sanctioned_ids=frozenset({"ofac_01"}))
        v = inv.check_payment(make_intent(counterparty="ofac_01"), ())
        assert v is not None
        assert v.rule_id == "counterparty_sanctioned"

    def test_rejects_not_approved(self) -> None:
        inv = CounterpartyConstraint(approved_ids=frozenset({"vendor_a"}))
        v = inv.check_payment(make_intent(counterparty="vendor_b"), ())
        assert v is not None
        assert v.rule_id == "counterparty_not_approved"

    def test_permits_approved(self) -> None:
        inv = CounterpartyConstraint(approved_ids=frozenset({"vendor_a"}))
        assert inv.check_payment(make_intent(counterparty="vendor_a"), ()) is None


class TestJurisdictionRule:
    def test_inner_applies_when_jurisdiction_matches(self) -> None:
        inner = MaxPerCall(max_amount=Decimal("10"))
        inv = JurisdictionRule(jurisdiction="EU", additional_invariants=(inner,))
        intent = make_intent("20", metadata={"jurisdiction": "EU"})
        v = inv.check_payment(intent, ())
        assert v is not None
        assert v.rule_id.startswith("jurisdiction_eu.")

    def test_inner_skipped_when_jurisdiction_mismatches(self) -> None:
        inner = MaxPerCall(max_amount=Decimal("10"))
        inv = JurisdictionRule(jurisdiction="EU", additional_invariants=(inner,))
        intent = make_intent("20", metadata={"jurisdiction": "US"})
        assert inv.check_payment(intent, ()) is None


class TestX402Registry:
    def test_empty_permits_everything(self) -> None:
        assert X402Registry.empty().check_payment(make_intent(), ()) is None

    def test_first_violation_wins(self) -> None:
        # Declaration order: MaxPerCall($10), then ProviderAllowlist({foo})
        reg = (
            X402Registry.empty()
            .declare(MaxPerCall(max_amount=Decimal("10")))
            .declare(ProviderAllowlist(providers=frozenset({"foo"})))
        )
        # Intent violates BOTH, registry returns max_per_call (declared first)
        v = reg.check_payment(make_intent("100", provider="bar"), ())
        assert v is not None
        assert v.rule_id == "max_per_call"

    def test_declare_is_immutable(self) -> None:
        reg1 = X402Registry.empty()
        reg2 = reg1.declare(MaxPerCall(max_amount=Decimal("1")))
        assert len(reg1.invariants) == 0
        assert len(reg2.invariants) == 1

    def test_declare_idempotent(self) -> None:
        inv = MaxPerCall(max_amount=Decimal("1"))
        reg = X402Registry.empty().declare(inv).declare(inv)
        assert len(reg.invariants) == 1

    def test_retract_removes(self) -> None:
        inv = MaxPerCall(max_amount=Decimal("1"))
        reg = X402Registry.empty().declare(inv).retract(inv)
        assert len(reg.invariants) == 0
