"""Tests for signal handler installation.

The signal handler wires faulthandler so a crashing daemon prints a usable
stack trace instead of failing silently. It mutates process-global state,
so we test that install() is idempotent and that the expected handler is
actually registered.
"""
from __future__ import annotations

import faulthandler
import signal

import pytest

from daemon import signal_handlers


def test_install_enables_faulthandler() -> None:
    signal_handlers.install()
    assert faulthandler.is_enabled()


def test_install_is_idempotent() -> None:
    signal_handlers.install()
    signal_handlers.install()
    signal_handlers.install()
    assert faulthandler.is_enabled()


def test_sigterm_handler_registered() -> None:
    signal_handlers.install()
    handler = signal.getsignal(signal.SIGTERM)
    # Default is SIG_DFL; after install it must be either a callable or the
    # installed handler.
    assert handler is not signal.SIG_DFL
