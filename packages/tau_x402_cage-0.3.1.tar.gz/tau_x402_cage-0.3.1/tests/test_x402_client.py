"""Integration tests for x402_client.py, end-to-end mediation flow."""

from __future__ import annotations

import json
import socket
from dataclasses import dataclass
from typing import Optional

import pytest

from adapter.payment_intent_matcher import PaymentIntent
from adapter.verdict_signer import (
    SignedEnvelope,
    Verdict,
    verify,
)
from adapter.x402_client import mediate
from adapter.x402_envelope import from_http_response


SECRET = b"test-secret-at-least-16-bytes-long-yes"


# ── test doubles for DaemonClient ───────────────────────────────────────────


@dataclass
class StubDaemon:
    """In-process DaemonClient that returns a pre-canned verdict."""

    verdict: Verdict

    def check(self, intent: PaymentIntent) -> Verdict:
        return self.verdict


@dataclass
class FailingDaemon:
    """DaemonClient that raises to simulate outages."""

    exc: Exception

    def check(self, intent: PaymentIntent) -> Verdict:
        raise self.exc


# ── fixtures ────────────────────────────────────────────────────────────────


def _body(**overrides) -> bytes:
    base = {
        "amount": "50.00",
        "currency": "USDC",
        "provider": "anthropic",
        "counterparty": "vendor_x",
        "timestamp": 1713456789,
    }
    base.update(overrides)
    return json.dumps(base).encode("utf-8")


# ── happy paths ──────────────────────────────────────────────────────────────


class TestMediateHappyPath:
    def test_permit_returns_200_with_signed_envelope(self) -> None:
        daemon = StubDaemon(Verdict(outcome="permit"))
        status, headers, body = mediate({}, _body(), SECRET, daemon=daemon)
        assert status == 200
        assert headers["X-Policy-Verdict"] == "permit"

        # Envelope is signed and verifies against the same intent
        env = from_http_response(headers, body)
        assert env.outcome == "permit"
        # Reconstruct intent from request to verify binding
        intent = PaymentIntent(
            amount=__import__("decimal").Decimal("50.00"),
            currency="USDC",
            provider="anthropic",
            counterparty="vendor_x",
            rail="x402",
            timestamp_unix=1713456789,
        )
        verify(env, intent, SECRET)  # does not raise

    def test_reject_returns_403_with_rule_id(self) -> None:
        daemon = StubDaemon(
            Verdict(
                outcome="reject",
                rule_id="spending_cap_daily",
                reason_text="Daily cap $1000 exceeded.",
                witness="cumulative=$1002",
            )
        )
        status, headers, body = mediate({}, _body(), SECRET, daemon=daemon)
        assert status == 403
        assert headers["X-Policy-Verdict"] == "reject"
        assert headers["X-Policy-Rule-Id"] == "spending_cap_daily"

        env = from_http_response(headers, body)
        assert env.reason_text == "Daily cap $1000 exceeded."


# ── fail-closed behaviors ────────────────────────────────────────────────────


class TestMediateFailClosed:
    def test_malformed_body_returns_signed_reject(self) -> None:
        daemon = StubDaemon(Verdict(outcome="permit"))  # never reached
        status, headers, _ = mediate({}, b"{ not json", SECRET, daemon=daemon)
        assert status == 403
        assert headers["X-Policy-Verdict"] == "reject"
        assert headers["X-Policy-Rule-Id"] == "invalid_payment_intent"

    def test_daemon_unreachable_returns_signed_reject(self) -> None:
        daemon = FailingDaemon(FileNotFoundError("socket missing"))
        status, headers, body = mediate({}, _body(), SECRET, daemon=daemon)
        assert status == 403
        assert headers["X-Policy-Rule-Id"] == "cage_unavailable"
        env = from_http_response(headers, body)
        assert "FileNotFoundError" in (env.reason_text or "")

    def test_daemon_timeout_returns_signed_reject(self) -> None:
        daemon = FailingDaemon(socket.timeout("read timeout"))
        status, _, _ = mediate({}, _body(), SECRET, daemon=daemon)
        assert status == 403

    def test_daemon_protocol_error_returns_signed_reject(self) -> None:
        daemon = FailingDaemon(RuntimeError("bad JSON"))
        status, headers, _ = mediate({}, _body(), SECRET, daemon=daemon)
        assert status == 403
        assert headers["X-Policy-Rule-Id"] == "cage_unavailable"

    def test_reject_envelope_still_verifies(self) -> None:
        """Even on failure, the envelope is signed, facilitator can trust the reject."""
        daemon = FailingDaemon(FileNotFoundError("no socket"))
        _, headers, body = mediate({}, _body(), SECRET, daemon=daemon)
        env = from_http_response(headers, body)
        intent = PaymentIntent(
            amount=__import__("decimal").Decimal("50.00"),
            currency="USDC",
            provider="anthropic",
            counterparty="vendor_x",
            rail="x402",
            timestamp_unix=1713456789,
        )
        verify(env, intent, SECRET)  # does not raise


# ── MPP dispatch ─────────────────────────────────────────────────────────────


class TestMediateMppRail:
    def test_mpp_request_routes_correctly(self) -> None:
        daemon = StubDaemon(Verdict(outcome="permit"))
        status, headers, body = mediate(
            {"X-MPP-Version": "1"}, _body(), SECRET, daemon=daemon
        )
        assert status == 200
        # The envelope still binds to the same intent hash, but rail is mpp now.
        # Round-trip verify confirms the signer ran with the parsed intent.
        env = from_http_response(headers, body)
        intent = PaymentIntent(
            amount=__import__("decimal").Decimal("50.00"),
            currency="USDC",
            provider="anthropic",
            counterparty="vendor_x",
            rail="mpp",
            timestamp_unix=1713456789,
        )
        verify(env, intent, SECRET)
