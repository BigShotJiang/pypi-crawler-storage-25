"""Tests for the consistency prover.

Covers PythonPatternProver's pattern detection and the ProofToken /
Contradiction contracts. TauConsistencyProver is a stub in V0.3.0 so we
only verify it raises NotImplementedError.
"""
from __future__ import annotations

from decimal import Decimal

import pytest

from adapter.invariants import (
    CounterpartyConstraint,
    MaxPerCall,
    ProviderAllowlist,
    SpendingCap,
)
from adapter.prover import (
    Contradiction,
    ProofToken,
    PythonPatternProver,
    TauConsistencyProver,
)


class TestPythonPatternProver:
    def test_empty_rule_set_is_consistent(self) -> None:
        p = PythonPatternProver()
        result = p.prove([])
        assert isinstance(result, ProofToken)
        assert result.backend == "python-pattern"
        assert result.config_hash  # non-empty

    def test_single_rule_is_consistent(self) -> None:
        result = PythonPatternProver().prove([MaxPerCall(max_amount=Decimal("10"))])
        assert isinstance(result, ProofToken)

    def test_non_conflicting_rules_proven_consistent(self) -> None:
        rules = [
            MaxPerCall(max_amount=Decimal("50")),
            ProviderAllowlist(providers=frozenset({"anthropic"})),
            SpendingCap(max_amount=Decimal("1000"), scope="per_window", window_seconds=3600),
        ]
        result = PythonPatternProver().prove(rules)
        assert isinstance(result, ProofToken)

    def test_disjoint_allowlist_vs_approved_is_contradiction(self) -> None:
        rules = [
            ProviderAllowlist(providers=frozenset({"anthropic", "openai"})),
            CounterpartyConstraint(approved_ids=frozenset({"vendor_x", "vendor_y"})),
        ]
        result = PythonPatternProver().prove(rules)
        assert isinstance(result, Contradiction)
        assert "disjoint" in result.reason.lower()
        assert "anthropic" in result.left or "anthropic" in result.right

    def test_overlap_allowlist_approved_is_consistent(self) -> None:
        # Shared member -> no disjoint-set problem.
        rules = [
            ProviderAllowlist(providers=frozenset({"anthropic"})),
            CounterpartyConstraint(approved_ids=frozenset({"anthropic"})),
        ]
        result = PythonPatternProver().prove(rules)
        assert isinstance(result, ProofToken)

    def test_config_hash_stable_across_reordering(self) -> None:
        """The same rule set in different order produces the same hash."""
        r1 = [MaxPerCall(max_amount=Decimal("10")),
              ProviderAllowlist(providers=frozenset({"a"}))]
        r2 = [ProviderAllowlist(providers=frozenset({"a"})),
              MaxPerCall(max_amount=Decimal("10"))]
        t1 = PythonPatternProver().prove(r1)
        t2 = PythonPatternProver().prove(r2)
        assert isinstance(t1, ProofToken)
        assert isinstance(t2, ProofToken)
        assert t1.config_hash == t2.config_hash

    def test_nonce_differs_across_proofs(self) -> None:
        p = PythonPatternProver()
        rules = [MaxPerCall(max_amount=Decimal("1"))]
        t1 = p.prove(rules)
        t2 = p.prove(rules)
        assert isinstance(t1, ProofToken) and isinstance(t2, ProofToken)
        assert t1.nonce != t2.nonce  # fresh nonce each time

    def test_predecessor_hash_carried_into_token(self) -> None:
        result = PythonPatternProver().prove([], predecessor_hash="abc123")
        assert isinstance(result, ProofToken)
        assert result.predecessor_hash == "abc123"


class TestTauConsistencyProverStub:
    def test_raises_not_implemented(self) -> None:
        with pytest.raises(NotImplementedError, match="V0.3.1"):
            TauConsistencyProver().prove([])
