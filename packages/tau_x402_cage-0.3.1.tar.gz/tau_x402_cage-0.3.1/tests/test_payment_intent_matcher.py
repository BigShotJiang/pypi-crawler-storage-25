"""Tests for payment_intent_matcher.py, schema validation + rail detection + parsers."""

from __future__ import annotations

import json
from decimal import Decimal

import pytest

from adapter.payment_intent_matcher import (
    InvalidPaymentIntent,
    PaymentIntent,
    detect_rail,
    parse,
    parse_mpp,
    parse_x402,
)


# ── PaymentIntent construction / validation ─────────────────────────────────


class TestPaymentIntent:
    def _valid_kwargs(self, **overrides):
        base = dict(
            amount=Decimal("10"),
            currency="USDC",
            provider="anthropic",
            counterparty="vendor_a",
            rail="x402",
            timestamp_unix=1713456789,
        )
        base.update(overrides)
        return base

    def test_happy_path(self) -> None:
        intent = PaymentIntent(**self._valid_kwargs())
        assert intent.amount == Decimal("10")
        assert intent.rail == "x402"

    def test_immutable(self) -> None:
        intent = PaymentIntent(**self._valid_kwargs())
        with pytest.raises(AttributeError):
            intent.amount = Decimal("999")  # type: ignore[misc]

    def test_zero_amount_rejected(self) -> None:
        with pytest.raises(InvalidPaymentIntent, match="> 0"):
            PaymentIntent(**self._valid_kwargs(amount=Decimal("0")))

    def test_unknown_currency_rejected(self) -> None:
        with pytest.raises(InvalidPaymentIntent, match="not in allowed"):
            PaymentIntent(**self._valid_kwargs(currency="SHIB"))

    def test_unknown_rail_rejected(self) -> None:
        with pytest.raises(InvalidPaymentIntent, match="rail"):
            PaymentIntent(**self._valid_kwargs(rail="btc_lightning"))  # type: ignore[arg-type]

    def test_provider_injection_attempt_rejected(self) -> None:
        # security finding H-07: field values flow into Tau spec emission
        for bad in ("'; drop table", "provider & extra", "line\ninjection", ""):
            with pytest.raises(InvalidPaymentIntent, match="safe-token"):
                PaymentIntent(**self._valid_kwargs(provider=bad))

    def test_counterparty_oversized_rejected(self) -> None:
        with pytest.raises(InvalidPaymentIntent, match="safe-token"):
            PaymentIntent(**self._valid_kwargs(counterparty="a" * 200))

    def test_negative_timestamp_rejected(self) -> None:
        with pytest.raises(InvalidPaymentIntent, match=">= 0"):
            PaymentIntent(**self._valid_kwargs(timestamp_unix=-1))

    def test_metadata_value_oversized_rejected(self) -> None:
        with pytest.raises(InvalidPaymentIntent, match="metadata value"):
            PaymentIntent(**self._valid_kwargs(metadata={"note": "a" * 600}))

    def test_metadata_bad_key_rejected(self) -> None:
        with pytest.raises(InvalidPaymentIntent, match="metadata key"):
            PaymentIntent(**self._valid_kwargs(metadata={"bad key!": "v"}))


# ── rail detection ───────────────────────────────────────────────────────────


class TestRailDetection:
    def test_default_is_x402(self) -> None:
        assert detect_rail({}) == "x402"
        assert detect_rail({"X-Payment": "anything"}) == "x402"

    def test_mpp_header_flag(self) -> None:
        assert detect_rail({"X-MPP-Version": "1"}) == "mpp"
        assert detect_rail({"X-Payment-Scheme": "mpp-v1"}) == "mpp"

    def test_case_insensitive(self) -> None:
        assert detect_rail({"x-mpp-version": "1"}) == "mpp"
        assert detect_rail({"X-MPP-Version": "1"}) == "mpp"


# ── x402 parser ──────────────────────────────────────────────────────────────


class TestParseX402:
    def _body(self, **overrides) -> bytes:
        base = {
            "amount": "50.00",
            "currency": "USDC",
            "provider": "anthropic",
            "counterparty": "0xdeadbeef",
            "timestamp": 1713456789,
        }
        base.update(overrides)
        return json.dumps(base).encode("utf-8")

    def test_happy_path(self) -> None:
        intent = parse_x402({}, self._body())
        assert intent.rail == "x402"
        assert intent.amount == Decimal("50.00")
        assert intent.provider == "anthropic"

    def test_counterparty_preserves_hex(self) -> None:
        # 0xdeadbeef passes the safe-token regex because hex chars + digits
        intent = parse_x402({}, self._body(counterparty="0xdeadbeef12345678"))
        assert intent.counterparty.startswith("0x")

    def test_malformed_json_wrapped(self) -> None:
        with pytest.raises(InvalidPaymentIntent, match="valid UTF-8 JSON"):
            parse_x402({}, b"{ not-json ")

    def test_non_object_body_rejected(self) -> None:
        with pytest.raises(InvalidPaymentIntent, match="JSON object"):
            parse_x402({}, b'["not", "an", "object"]')

    def test_missing_amount(self) -> None:
        with pytest.raises(InvalidPaymentIntent, match="amount"):
            parse_x402({}, b'{"currency":"USDC","provider":"x","counterparty":"y","timestamp":1}')

    def test_metadata_normalized(self) -> None:
        body = self._body(metadata={"tag": "batch-7"})
        intent = parse_x402({}, body)
        assert intent.metadata == {"tag": "batch-7"}


# ── MPP parser (stub; wraps x402 shape) ──────────────────────────────────────


class TestParseMpp:
    def test_tags_rail_as_mpp(self) -> None:
        body = json.dumps(
            {
                "amount": "100",
                "currency": "USDC",
                "provider": "stripe_ai",
                "counterparty": "merchant_x",
                "timestamp": 1,
            }
        ).encode("utf-8")
        intent = parse_mpp({"X-MPP-Version": "1"}, body)
        assert intent.rail == "mpp"


# ── dispatch via parse() ─────────────────────────────────────────────────────


class TestParseDispatch:
    def _body(self) -> bytes:
        return json.dumps(
            {
                "amount": "1",
                "currency": "USDC",
                "provider": "p",
                "counterparty": "c",
                "timestamp": 0,
            }
        ).encode("utf-8")

    def test_dispatches_x402_by_default(self) -> None:
        assert parse({}, self._body()).rail == "x402"

    def test_dispatches_mpp_on_header(self) -> None:
        assert parse({"X-MPP-Version": "1"}, self._body()).rail == "mpp"
