"""Tests for the CLI entry point.

Covers the `init` subcommand (file scaffolding) and the run path argument
parsing. The run path's serve loop isn't tested here (it would spin up a
real daemon) -- that's covered by tests/test_daemon_check_payment.py.
"""
from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path

import pytest

from daemon import cli


def _run_cli(args: list[str], cwd: Path | None = None) -> subprocess.CompletedProcess:
    """Invoke the installed tau-x402-cage entry point in a subprocess."""
    return subprocess.run(
        [sys.executable, "-m", "daemon.cli", *args],
        cwd=cwd, capture_output=True, text=True, timeout=10,
    )


class TestInitSubcommand:
    def test_init_writes_both_files(self, tmp_path: Path) -> None:
        result = _run_cli(["init"], cwd=tmp_path)
        assert result.returncode == 0, result.stderr
        assert (tmp_path / "policy.yaml").exists()
        assert (tmp_path / "docker-compose.yaml").exists()

    def test_init_refuses_overwrite(self, tmp_path: Path) -> None:
        (tmp_path / "policy.yaml").write_text("existing: true\n")
        result = _run_cli(["init"], cwd=tmp_path)
        assert result.returncode == 2
        assert "refusing to overwrite" in result.stderr.lower()

    def test_init_force_overwrites(self, tmp_path: Path) -> None:
        (tmp_path / "policy.yaml").write_text("existing: true\n")
        result = _run_cli(["init", "--force"], cwd=tmp_path)
        assert result.returncode == 0
        # Force replaces the placeholder with the real starter
        assert "version: 1" in (tmp_path / "policy.yaml").read_text()

    def test_init_next_steps_in_stdout(self, tmp_path: Path) -> None:
        result = _run_cli(["init"], cwd=tmp_path)
        assert "Next steps" in result.stdout
        assert "--policy" in result.stdout

    def test_init_custom_paths(self, tmp_path: Path) -> None:
        result = _run_cli(
            ["init", "--policy-path", str(tmp_path / "my.yaml"),
             "--compose-path", str(tmp_path / "my-compose.yaml")],
            cwd=tmp_path,
        )
        assert result.returncode == 0
        assert (tmp_path / "my.yaml").exists()
        assert (tmp_path / "my-compose.yaml").exists()


class TestRunPath:
    """The main `_cmd_run` path; tested without hitting serve_forever."""

    def test_bad_policy_path_exits_2(self, tmp_path: Path) -> None:
        result = _run_cli(
            ["--socket", str(tmp_path / "dead.sock"),
             "--policy", str(tmp_path / "nonexistent.yaml")],
        )
        assert result.returncode == 2
        assert "policy load failed" in result.stderr

    def test_help_lists_init_and_flags(self) -> None:
        result = _run_cli(["--help"])
        assert result.returncode == 0
        assert "init" in result.stdout
        assert "--socket" in result.stdout
        assert "--policy" in result.stdout


class TestSuggestSubcommand:
    def test_suggest_prints_prompt(self) -> None:
        result = _run_cli(["suggest", "cap", "daily", "at", "$500"])
        assert result.returncode == 0
        assert "BEGIN PROMPT" in result.stdout
        assert "END PROMPT" in result.stdout
        assert "version: 1" in result.stdout  # schema reference
        assert "spending_cap" in result.stdout
        assert "cap daily at $500" in result.stdout  # user request echoed

    def test_suggest_without_request_errors(self) -> None:
        result = _run_cli(["suggest"])
        assert result.returncode == 2
        assert "plain-English" in result.stderr


class TestMainReturnValues:
    """Direct invocation of cli.main with monkeypatched argv."""

    def test_main_init_success(self, tmp_path: Path, monkeypatch) -> None:
        monkeypatch.chdir(tmp_path)
        monkeypatch.setattr(sys, "argv", ["tau-x402-cage", "init"])
        rc = cli.main()
        assert rc == 0
        assert (tmp_path / "policy.yaml").exists()

    def test_main_init_refuses_when_exists(self, tmp_path: Path, monkeypatch) -> None:
        (tmp_path / "policy.yaml").write_text("x: 1\n")
        monkeypatch.chdir(tmp_path)
        monkeypatch.setattr(sys, "argv", ["tau-x402-cage", "init"])
        rc = cli.main()
        assert rc == 2
