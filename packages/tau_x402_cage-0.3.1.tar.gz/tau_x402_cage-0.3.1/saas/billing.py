"""Billing reporters.

The hosted SaaS needs to meter every `/v1/check` against a billing backend.
Abstracting behind the `BillingReporter` protocol keeps the FastAPI layer
ignorant of which backend is wired up and lets tests inject null reporters
or capture reporters without touching Stripe.

Current implementations:
  NullBillingReporter   -- no-op; default when STRIPE_API_KEY is unset.
                           Safe to run in dev, tests, and the free tier.
  StripeBillingReporter -- posts meter events to Stripe's `/v1/billing/meter_events`.
                           Stub uses urllib so we don't depend on the stripe
                           SDK for V1; swap to `import stripe` when moving
                           to production.
"""
from __future__ import annotations

import logging
import os
from dataclasses import dataclass
from typing import Protocol

logger = logging.getLogger(__name__)


class BillingReporter(Protocol):
    def record_check(self, tenant_id: str, verdict: str) -> None: ...


class NullBillingReporter:
    """Drops every event. Used in dev, tests, and pre-billing deploys."""

    def record_check(self, tenant_id: str, verdict: str) -> None:
        logger.debug("NullBilling: tenant=%s verdict=%s", tenant_id, verdict)


@dataclass(frozen=True)
class StripeBillingReporter:
    """Posts meter events to Stripe's billing API.

    V1 uses urllib rather than the stripe SDK so a `pip install tau-x402-cage[saas]`
    does not pull 30MB of Stripe client code. Trade-off: no retry logic, no
    connection pooling. For production at >10 rps, swap to the real SDK.
    """

    api_key: str
    event_name: str
    timeout_sec: float = 2.0

    @classmethod
    def from_env(cls) -> "StripeBillingReporter":
        api_key = os.environ["STRIPE_API_KEY"]
        event_name = os.environ.get("STRIPE_METER_EVENT_NAME", "tau_x402_check")
        return cls(api_key=api_key, event_name=event_name)

    def record_check(self, tenant_id: str, verdict: str) -> None:
        import urllib.parse
        import urllib.request

        # Stripe billing meter event API shape:
        # POST /v1/billing/meter_events
        # event_name, payload[stripe_customer_id], payload[value]
        data = urllib.parse.urlencode({
            "event_name": self.event_name,
            "payload[stripe_customer_id]": tenant_id,
            "payload[value]": "1",
            "payload[verdict]": verdict,
        }).encode("utf-8")
        req = urllib.request.Request(
            "https://api.stripe.com/v1/billing/meter_events",
            data=data,
            headers={
                "Authorization": f"Bearer {self.api_key}",
                "Content-Type": "application/x-www-form-urlencoded",
            },
        )
        try:
            with urllib.request.urlopen(req, timeout=self.timeout_sec) as resp:
                if resp.status >= 300:
                    logger.warning("Stripe meter rejected: %d %s",
                                   resp.status, resp.reason)
        except Exception as exc:
            # Never fail the hot path on billing errors; operator gets the log.
            logger.warning("Stripe meter event failed: %s", exc)
