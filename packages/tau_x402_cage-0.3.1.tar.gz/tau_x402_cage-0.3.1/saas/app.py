"""FastAPI entry point for the hosted Tau x402 Cage SaaS.

Endpoints:

    POST /v1/check          -> proxy a payment intent to the cage daemon,
                               return the signed verdict envelope
    GET  /v1/health         -> liveness
    GET  /v1/usage           -> usage counters for the authenticated tenant

Auth: single-tenant API key in `Authorization: Bearer <key>` header. Keys are
loaded from env var `TAU_X402_API_KEYS` as a JSON object `{tenant_id: api_key}`
so rotations and per-tenant provisioning are config-file operations. A real
production deployment would back this with a KV store or Postgres; env vars
keep the V1 scaffold runnable on Fly.io free tier without a database.

Billing: every permit/reject is reported to Stripe metered billing via a
dedicated `BillingReporter`. The scaffold ships a NullBillingReporter so the
whole service runs without Stripe credentials; wire `STRIPE_API_KEY` +
`STRIPE_METER_EVENT_NAME` and swap to `StripeBillingReporter` for live meter
ingestion.

Design note: the FastAPI layer is deliberately thin. All policy logic lives
in the daemon; this module's only responsibilities are auth, rate limiting,
usage tracking, and translating HTTP <-> UDS.
"""
from __future__ import annotations

import json
import logging
import os
import threading
import time
from dataclasses import dataclass, field
from decimal import Decimal
from typing import Any, Callable, Dict, Mapping, Optional, Protocol

try:
    from fastapi import Depends, FastAPI, Header, HTTPException, Request
    from fastapi.responses import JSONResponse
except ImportError as exc:
    raise ImportError(
        "saas/ requires FastAPI: `pip install tau-x402-cage[saas]` or "
        "`pip install fastapi uvicorn`"
    ) from exc

from adapter.payment_intent_matcher import InvalidPaymentIntent, parse as parse_intent
from adapter.verdict_signer import Verdict, sign
from adapter.x402_client import UdsDaemonClient, mediate
from saas.billing import BillingReporter, NullBillingReporter

logger = logging.getLogger(__name__)


# ── configuration ────────────────────────────────────────────────────────────


@dataclass(frozen=True)
class SaasConfig:
    """Configuration for the SaaS wrapper. Loaded from env via `from_env()`."""

    api_keys: Dict[str, str]  # {tenant_id: api_key}
    socket_path: str
    hmac_secret: bytes
    billing: BillingReporter

    @classmethod
    def from_env(cls) -> "SaasConfig":
        keys_raw = os.environ.get("TAU_X402_API_KEYS", "{}")
        try:
            api_keys = json.loads(keys_raw)
        except json.JSONDecodeError as exc:
            raise RuntimeError(
                "TAU_X402_API_KEYS must be JSON object {tenant_id: api_key}"
            ) from exc
        if not isinstance(api_keys, dict):
            raise RuntimeError("TAU_X402_API_KEYS must decode to an object")

        secret_hex = os.environ.get("TAU_X402_HMAC_SECRET")
        if not secret_hex:
            raise RuntimeError(
                "TAU_X402_HMAC_SECRET must be set (32+ hex bytes)"
            )
        try:
            secret = bytes.fromhex(secret_hex)
        except ValueError as exc:
            raise RuntimeError("TAU_X402_HMAC_SECRET must be hex-encoded") from exc
        if len(secret) < 16:
            raise RuntimeError("TAU_X402_HMAC_SECRET must be >= 16 bytes")

        socket_path = os.environ.get("TAU_X402_SOCKET", "/tmp/tau-x402-cage.sock")

        # Billing wiring: swap in StripeBillingReporter when env has STRIPE_API_KEY.
        if os.environ.get("STRIPE_API_KEY"):
            from saas.billing import StripeBillingReporter  # late import
            billing: BillingReporter = StripeBillingReporter.from_env()
        else:
            billing = NullBillingReporter()

        return cls(
            api_keys=dict(api_keys),
            socket_path=socket_path,
            hmac_secret=secret,
            billing=billing,
        )


# ── in-memory usage counters (per-tenant) ────────────────────────────────────


@dataclass
class UsageCounter:
    """Thread-safe per-tenant usage counters."""

    _lock: threading.Lock = field(default_factory=threading.Lock)
    _by_tenant: Dict[str, Dict[str, int]] = field(default_factory=dict)

    def record(self, tenant_id: str, verdict: str) -> None:
        with self._lock:
            bucket = self._by_tenant.setdefault(tenant_id, {"permit": 0, "reject": 0})
            bucket[verdict] = bucket.get(verdict, 0) + 1

    def snapshot(self, tenant_id: str) -> Dict[str, int]:
        with self._lock:
            return dict(self._by_tenant.get(tenant_id, {"permit": 0, "reject": 0}))


# ── app factory ──────────────────────────────────────────────────────────────


def create_app(config: Optional[SaasConfig] = None) -> FastAPI:
    """Build a FastAPI app with the given config, or load from env if None."""
    cfg = config or SaasConfig.from_env()
    usage = UsageCounter()

    # Flip api_keys around so the auth check is a single dict lookup.
    key_to_tenant: Dict[str, str] = {v: k for k, v in cfg.api_keys.items()}

    app = FastAPI(
        title="tau-x402-cage SaaS",
        version="0.1.0",
        description="Hosted formal policy cage for x402 agentic payments.",
    )

    def _authed_tenant(authorization: str = Header(default="")) -> str:
        """Dependency: extract tenant_id from Bearer token, 401 if unknown."""
        if not authorization.startswith("Bearer "):
            raise HTTPException(status_code=401, detail="missing Bearer token")
        token = authorization[len("Bearer "):].strip()
        tenant = key_to_tenant.get(token)
        if tenant is None:
            raise HTTPException(status_code=401, detail="invalid API key")
        return tenant

    @app.get("/v1/health")
    def health() -> dict:
        return {"status": "ok", "version": "0.1.0"}

    @app.get("/v1/usage")
    def get_usage(tenant: str = Depends(_authed_tenant)) -> dict:
        return {"tenant": tenant, "counters": usage.snapshot(tenant)}

    @app.post("/v1/check")
    async def check(request: Request, tenant: str = Depends(_authed_tenant)) -> JSONResponse:
        """Proxy a payment intent to the cage daemon and return the signed envelope.

        Accepts JSON body in the x402 request shape (see
        `adapter.payment_intent_matcher.parse_x402` for the schema). Returns the
        signed verdict envelope as the response body; HTTP status reflects the
        verdict (200 permit, 403 reject, 500 on unrecoverable errors).
        """
        body = await request.body()
        # Headers come through as a lowercase mapping; convert for the parser.
        headers = {k: v for k, v in request.headers.items()}

        client = UdsDaemonClient(socket_path=cfg.socket_path)
        status, response_headers, response_body = mediate(
            headers=headers,
            body=body,
            secret=cfg.hmac_secret,
            daemon=client,
        )
        verdict = response_headers.get("X-Policy-Verdict", "unknown")
        usage.record(tenant, verdict)
        try:
            cfg.billing.record_check(tenant_id=tenant, verdict=verdict)
        except Exception:  # billing must never fail the request path
            logger.exception("billing reporter failed; request continuing")
        return JSONResponse(
            status_code=status,
            content=json.loads(response_body) if response_body else {},
            headers=response_headers,
        )

    return app
