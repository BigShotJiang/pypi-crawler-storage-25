"""Uvicorn entry point for the hosted SaaS.

Usage:
    export TAU_X402_API_KEYS='{"acme": "sk_live_xxx"}'
    export TAU_X402_HMAC_SECRET=$(openssl rand -hex 32)
    # Start the cage daemon as a sidecar first:
    tau-x402-cage --socket /tmp/tau-x402-cage.sock --policy policy.yaml &
    # Then the SaaS wrapper:
    uvicorn saas.main:app --host 0.0.0.0 --port 8080
"""
from saas.app import create_app

app = create_app()
