"""Hosted SaaS wrapper around the tau-x402-cage daemon.

Turns the UDS daemon into an HTTPS endpoint with API-key auth, per-tenant
policy isolation, and Stripe metered-billing hooks. This is the commercial
tier: users who do not want to self-host run one daemon per tenant and bill
per check.

Deploy target: Fly.io or Cloudflare Worker + sidecar container. The daemon
runs as a sidecar; this FastAPI app fronts it on :8080.
"""
