"""Integration tests for the SaaS FastAPI wrapper.

Spins up a real CageDaemon + FastAPI TestClient, covers auth, check, and usage
paths end-to-end. Requires `fastapi` + `httpx` (installed via `[saas]` extra).
"""
from __future__ import annotations

import json
import os
import tempfile
import threading
import time
from typing import Iterator

import pytest

try:
    from fastapi.testclient import TestClient
except ImportError:
    pytest.skip("fastapi not installed; skipping saas tests", allow_module_level=True)

from daemon.server import CageDaemon
from saas.app import SaasConfig, create_app
from saas.billing import NullBillingReporter


SECRET_HEX = "a" * 64  # 32 bytes of 0xaa


@pytest.fixture
def daemon_socket() -> Iterator[str]:
    fd, path = tempfile.mkstemp(prefix="saas-", suffix=".sock", dir="/tmp")
    os.close(fd)
    os.unlink(path)

    d = CageDaemon(socket_path=path)
    t = threading.Thread(target=d.serve_forever, daemon=True)
    t.start()
    for _ in range(50):
        if os.path.exists(path):
            break
        time.sleep(0.01)
    # Seed a max_per_call invariant so we can see both permit and reject paths.
    import socket
    s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    s.connect(path)
    s.sendall((json.dumps({
        "op": "declare_x402",
        "kind": "max_per_call",
        "max_amount": "100.00",
    }) + "\n").encode())
    s.recv(1024)
    s.close()
    try:
        yield path
    finally:
        d.shutdown()
        t.join(timeout=1.0)


@pytest.fixture
def client(daemon_socket: str) -> TestClient:
    cfg = SaasConfig(
        api_keys={"acme": "sk_test_acme_123"},
        socket_path=daemon_socket,
        hmac_secret=bytes.fromhex(SECRET_HEX),
        billing=NullBillingReporter(),
    )
    return TestClient(create_app(cfg))


class TestAuth:
    def test_missing_token_returns_401(self, client: TestClient) -> None:
        r = client.post("/v1/check", json={"amount": "1", "provider": "a", "counterparty": "b"})
        assert r.status_code == 401
        assert "Bearer" in r.json()["detail"]

    def test_wrong_token_returns_401(self, client: TestClient) -> None:
        r = client.post(
            "/v1/check",
            headers={"Authorization": "Bearer wrong_key"},
            json={"amount": "1", "provider": "a", "counterparty": "b"},
        )
        assert r.status_code == 401

    def test_health_is_unauthenticated(self, client: TestClient) -> None:
        r = client.get("/v1/health")
        assert r.status_code == 200
        assert r.json()["status"] == "ok"


class TestCheckPath:
    def _body(self, amount: str = "50.00") -> dict:
        return {
            "amount": amount,
            "currency": "USDC",
            "provider": "anthropic",
            "counterparty": "vendor_x",
            "timestamp": 1_700_000_000,
        }

    def test_permit_under_cap(self, client: TestClient) -> None:
        r = client.post(
            "/v1/check",
            headers={"Authorization": "Bearer sk_test_acme_123"},
            json=self._body("50.00"),
        )
        assert r.status_code == 200
        assert r.headers["X-Policy-Verdict"] == "permit"

    def test_reject_over_cap(self, client: TestClient) -> None:
        r = client.post(
            "/v1/check",
            headers={"Authorization": "Bearer sk_test_acme_123"},
            json=self._body("500.00"),
        )
        assert r.status_code == 403
        assert r.headers["X-Policy-Verdict"] == "reject"
        assert r.headers["X-Policy-Rule-Id"] == "max_per_call"


class TestUsage:
    def test_usage_counts_permits_and_rejects(self, client: TestClient) -> None:
        headers = {"Authorization": "Bearer sk_test_acme_123"}
        body = {
            "currency": "USDC", "provider": "anthropic",
            "counterparty": "v", "timestamp": 1_700_000_000,
        }
        # 2 permits
        for _ in range(2):
            r = client.post("/v1/check", headers=headers, json={**body, "amount": "10"})
            assert r.status_code == 200
        # 1 reject
        r = client.post("/v1/check", headers=headers, json={**body, "amount": "500"})
        assert r.status_code == 403

        r = client.get("/v1/usage", headers=headers)
        counters = r.json()["counters"]
        assert counters["permit"] == 2
        assert counters["reject"] == 1
