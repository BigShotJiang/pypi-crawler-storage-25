"""X402Registry: immutable container of declared x402 invariants.

Parallel to `adapter/registry.py` which holds Safety-Cage-era invariants. This
registry holds the seven x402 Invariant subclasses (SpendingCap, MaxPerCall,
ProviderAllowlist, RetryRateLimit, RollingWindowCap, JurisdictionRule,
CounterpartyConstraint) and evaluates a PaymentIntent against all of them.

Every declare() / retract() returns a new registry; the daemon swaps the
reference atomically. Immutability keeps concurrent `check_payment` calls
correct while declare/retract runs.

Contradiction detection at declare time (H-01 from the security review) is
handled by `adapter.invariants.compose()` + Tau's SAT check when the caller
opts in, that path is separate from this registry's per-call check.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Iterable, Optional

from adapter.invariants import Invariant, Violation
from adapter.payment_intent_matcher import PaymentIntent


@dataclass(frozen=True)
class X402Registry:
    """Immutable set of active x402 invariants."""

    invariants: tuple[Invariant, ...] = field(default_factory=tuple)

    @classmethod
    def empty(cls) -> "X402Registry":
        return cls(invariants=tuple())

    def declare(self, inv: Invariant) -> "X402Registry":
        if inv in self.invariants:
            return self
        return X402Registry(invariants=self.invariants + (inv,))

    def retract(self, inv: Invariant) -> "X402Registry":
        return X402Registry(invariants=tuple(i for i in self.invariants if i != inv))

    def check_payment(
        self,
        intent: PaymentIntent,
        history: Iterable[PaymentIntent],
        rejects: Iterable[PaymentIntent] = (),
    ) -> Optional[Violation]:
        """Evaluate intent against all active invariants in declaration order.

        Returns the FIRST violation found, or None if all invariants are satisfied.
        Declaration-order traversal means users see the earliest-added rule that
        fires first, which matches how policy-as-code is typically read.

        `rejects` is only consulted by RetryRateLimit; other invariants ignore it.
        """
        history_tuple = tuple(history)
        rejects_tuple = tuple(rejects)
        for inv in self.invariants:
            v = inv.check_payment(intent, history_tuple, rejects_tuple)
            if v is not None:
                return v
        return None
