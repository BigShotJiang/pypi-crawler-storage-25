"""Sign and verify cage verdicts for HTTP-402 wire transport.

Addresses security review findings C-01 (spoofable headers) and C-02 (replay).
Every verdict carries:
    - HMAC-SHA256 MAC over canonical payload + TTL + intent_hash
    - intent_hash cryptographically binding the verdict to one specific intent
    - issued_at + ttl_seconds for temporal validity

V1 uses a symmetric HMAC shared between cage and facilitator. Asymmetric
signing (Ed25519) is a V1.1 upgrade; the envelope schema is forward-compatible.
"""

from __future__ import annotations

import hashlib
import hmac
import json
import time
from dataclasses import dataclass, field
from typing import FrozenSet, Literal, Mapping, Optional

from adapter.payment_intent_matcher import PaymentIntent


class SignatureError(ValueError):
    """Raised when a verdict envelope fails signature verification."""


class VerdictExpired(ValueError):
    """Raised when a verdict's TTL has elapsed."""


Outcome = Literal["permit", "reject"]


@dataclass(frozen=True)
class Verdict:
    """What the cage daemon produces before wire serialization."""

    outcome: Outcome
    rule_id: Optional[str] = None        # set on reject; names the violating invariant
    witness: Optional[str] = None        # machine-readable witness (e.g. "cumulative=$1002, cap=$1000")
    reason_text: Optional[str] = None    # plain-English explanation, TTI-critical
    issued_at_unix: int = 0              # filled by signer
    ttl_seconds: int = 30                # default 30s TTL


@dataclass(frozen=True)
class SignedEnvelope:
    """Wire-serializable verdict envelope with HMAC + intent binding."""

    outcome: Outcome
    rule_id: Optional[str]
    witness: Optional[str]
    reason_text: Optional[str]
    issued_at_unix: int
    ttl_seconds: int
    intent_hash: str       # hex SHA-256 of canonical PaymentIntent serialization
    mac_hex: str           # hex HMAC-SHA256 over the canonical payload
    mac_alg: str = "HMAC-SHA256"

    def to_json(self) -> str:
        """Serialize for HTTP response body."""
        return json.dumps(
            {
                "outcome": self.outcome,
                "rule_id": self.rule_id,
                "witness": self.witness,
                "reason_text": self.reason_text,
                "issued_at_unix": self.issued_at_unix,
                "ttl_seconds": self.ttl_seconds,
                "intent_hash": self.intent_hash,
                "mac_hex": self.mac_hex,
                "mac_alg": self.mac_alg,
            },
            separators=(",", ":"),
            sort_keys=True,
        )

    @classmethod
    def from_json(cls, payload: str) -> "SignedEnvelope":
        """Parse wire bytes back into an envelope. Does NOT verify, call verify()."""
        try:
            d = json.loads(payload)
        except json.JSONDecodeError as exc:
            raise SignatureError(f"envelope is not valid JSON: {exc}") from exc
        required = {
            "outcome",
            "issued_at_unix",
            "ttl_seconds",
            "intent_hash",
            "mac_hex",
            "mac_alg",
        }
        missing = required - d.keys()
        if missing:
            raise SignatureError(f"envelope missing required fields: {sorted(missing)}")
        return cls(
            outcome=d["outcome"],
            rule_id=d.get("rule_id"),
            witness=d.get("witness"),
            reason_text=d.get("reason_text"),
            issued_at_unix=int(d["issued_at_unix"]),
            ttl_seconds=int(d["ttl_seconds"]),
            intent_hash=d["intent_hash"],
            mac_hex=d["mac_hex"],
            mac_alg=d["mac_alg"],
        )


def hash_intent(intent: PaymentIntent) -> str:
    """Deterministic SHA-256 over the canonical PaymentIntent serialization.

    Binding this hash into the envelope prevents replay of a valid `permit`
    against a different intent. Any change to amount, provider, counterparty,
    timestamp, metadata, or request_id produces a different hash.
    """
    canonical = json.dumps(
        {
            "amount": str(intent.amount),
            "currency": intent.currency,
            "provider": intent.provider,
            "counterparty": intent.counterparty,
            "rail": intent.rail,
            "timestamp_unix": intent.timestamp_unix,
            "metadata": dict(sorted(intent.metadata.items())),
            "request_id": intent.request_id,
        },
        separators=(",", ":"),
        sort_keys=True,
    )
    return hashlib.sha256(canonical.encode("utf-8")).hexdigest()


def _canonical_mac_input(
    outcome: str,
    rule_id: Optional[str],
    witness: Optional[str],
    reason_text: Optional[str],
    issued_at_unix: int,
    ttl_seconds: int,
    intent_hash: str,
) -> bytes:
    """Build the exact byte string the MAC covers. Same order on sign + verify."""
    payload = json.dumps(
        {
            "outcome": outcome,
            "rule_id": rule_id,
            "witness": witness,
            "reason_text": reason_text,
            "issued_at_unix": issued_at_unix,
            "ttl_seconds": ttl_seconds,
            "intent_hash": intent_hash,
        },
        separators=(",", ":"),
        sort_keys=True,
    )
    return payload.encode("utf-8")


def sign(
    verdict: Verdict,
    intent: PaymentIntent,
    secret: bytes,
    now_unix: Optional[int] = None,
) -> SignedEnvelope:
    """Sign a verdict for a specific intent. Never reuse the envelope for a different intent.

    Args:
        verdict: what the cage decided
        intent:  the payment intent this verdict is about, binds via intent_hash
        secret:  shared HMAC secret (cage ↔ facilitator). 32+ bytes recommended.
        now_unix: override for test determinism. Defaults to time.time().
    """
    if len(secret) < 16:
        raise SignatureError("HMAC secret must be at least 16 bytes")
    ts = int(now_unix if now_unix is not None else time.time())
    ih = hash_intent(intent)
    mac_bytes = hmac.new(
        secret,
        _canonical_mac_input(
            verdict.outcome,
            verdict.rule_id,
            verdict.witness,
            verdict.reason_text,
            ts,
            verdict.ttl_seconds,
            ih,
        ),
        hashlib.sha256,
    ).digest()
    return SignedEnvelope(
        outcome=verdict.outcome,
        rule_id=verdict.rule_id,
        witness=verdict.witness,
        reason_text=verdict.reason_text,
        issued_at_unix=ts,
        ttl_seconds=verdict.ttl_seconds,
        intent_hash=ih,
        mac_hex=mac_bytes.hex(),
    )


def verify(
    env: SignedEnvelope,
    intent: PaymentIntent,
    secret: bytes,
    now_unix: Optional[int] = None,
) -> None:
    """Verify the envelope was issued for this intent, not expired, not tampered.

    Raises SignatureError on intent mismatch or MAC mismatch.
    Raises VerdictExpired if the TTL has elapsed.
    """
    expected_ih = hash_intent(intent)
    # Check intent binding before MAC, intent_hash mismatch is cheaper to
    # compute and leaks less about the MAC secret than a timing-sensitive compare.
    if not hmac.compare_digest(env.intent_hash, expected_ih):
        raise SignatureError(
            "intent_hash mismatch, envelope was issued for a different intent (replay attempt?)"
        )
    expected_mac = hmac.new(
        secret,
        _canonical_mac_input(
            env.outcome,
            env.rule_id,
            env.witness,
            env.reason_text,
            env.issued_at_unix,
            env.ttl_seconds,
            env.intent_hash,
        ),
        hashlib.sha256,
    ).hexdigest()
    if not hmac.compare_digest(env.mac_hex, expected_mac):
        raise SignatureError("MAC verification failed, envelope tampered or wrong secret")
    ts = int(now_unix if now_unix is not None else time.time())
    if ts > env.issued_at_unix + env.ttl_seconds:
        raise VerdictExpired(
            f"verdict issued at {env.issued_at_unix} with TTL {env.ttl_seconds}s; "
            f"now {ts} is past expiry {env.issued_at_unix + env.ttl_seconds}"
        )
