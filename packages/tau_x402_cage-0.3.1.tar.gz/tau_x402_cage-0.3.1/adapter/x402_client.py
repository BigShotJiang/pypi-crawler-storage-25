"""End-to-end x402 mediation entry point.

Flow for a single x402 pre-settlement check:

    HTTP 402 request (headers + body)
        v
    parse()  -> PaymentIntent  (payment_intent_matcher.py)
        v
    DaemonClient.check()  -> Verdict  (queries Tau cage daemon over UDS)
        v
    sign()  -> SignedEnvelope  (verdict_signer.py)
        v
    to_http_response()  -> (status, headers, body)  (x402_envelope.py)

Fails closed: daemon unreachable or protocol error produces a reject envelope,
never a permit. The failure shape is a signed reject so the facilitator can
detect it cryptographically, a plain 500 would be indistinguishable from
network drop of a permit header.
"""

from __future__ import annotations

import json
import logging
import socket
from dataclasses import dataclass
from typing import Mapping, Optional, Protocol

from adapter.payment_intent_matcher import (
    InvalidPaymentIntent,
    PaymentIntent,
    parse as parse_intent,
)
from adapter.verdict_signer import SignedEnvelope, Verdict, sign
from adapter.x402_envelope import to_http_response

logger = logging.getLogger(__name__)


DEFAULT_SOCKET = "/tmp/tau-x402-cage.sock"
DEFAULT_TIMEOUT_SEC = 0.5  # p95 latency target is 10ms; 0.5s is generous


class DaemonClient(Protocol):
    """Anything that turns a PaymentIntent into a Verdict."""

    def check(self, intent: PaymentIntent) -> Verdict: ...


@dataclass(frozen=True)
class UdsDaemonClient:
    """Production DaemonClient: JSON-over-UDS to the cage daemon."""

    socket_path: str = DEFAULT_SOCKET
    timeout_sec: float = DEFAULT_TIMEOUT_SEC

    def check(self, intent: PaymentIntent) -> Verdict:
        request = {
            "op": "check_payment",
            "intent": {
                "amount": str(intent.amount),
                "currency": intent.currency,
                "provider": intent.provider,
                "counterparty": intent.counterparty,
                "rail": intent.rail,
                "timestamp_unix": intent.timestamp_unix,
                "metadata": dict(intent.metadata),
                "request_id": intent.request_id,
            },
        }
        s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        s.settimeout(self.timeout_sec)
        try:
            s.connect(self.socket_path)
            s.sendall((json.dumps(request) + "\n").encode("utf-8"))
            f = s.makefile("r")
            response_line = f.readline()
        finally:
            s.close()
        try:
            response = json.loads(response_line)
        except json.JSONDecodeError as exc:
            raise RuntimeError(f"daemon response not valid JSON: {exc}") from exc
        outcome = response.get("verdict")
        if outcome not in ("permit", "reject"):
            raise RuntimeError(f"daemon returned unexpected verdict: {outcome!r}")
        return Verdict(
            outcome=outcome,
            rule_id=response.get("rule_id"),
            witness=response.get("witness"),
            reason_text=response.get("reason_text"),
            ttl_seconds=int(response.get("ttl_seconds", 30)),
        )


def _fail_closed_verdict(reason: str) -> Verdict:
    """Build a reject verdict for unrecoverable errors. Signed + returned."""
    return Verdict(
        outcome="reject",
        rule_id="cage_unavailable",
        witness=None,
        reason_text=f"Tau cage unavailable: {reason}",
        ttl_seconds=5,  # short TTL on failure, don't paper over outages
    )


def mediate(
    headers: Mapping[str, str],
    body: bytes,
    secret: bytes,
    daemon: Optional[DaemonClient] = None,
) -> tuple[int, dict[str, str], bytes]:
    """Mediate one x402 payment intent end-to-end. Always returns a signed response.

    This is the single entry point a facilitator calls. If anything goes wrong
   , malformed intent, daemon down, daemon protocol error, the response is
    a signed reject envelope, never an unsigned error.

    Args:
        headers: HTTP request headers from the payer
        body:    raw HTTP request body (bytes)
        secret:  HMAC secret shared between cage and facilitator
        daemon:  DaemonClient to query. Defaults to UdsDaemonClient().
    """
    daemon = daemon or UdsDaemonClient()

    # Step 1: parse. On schema failure we can't bind to a specific intent, so
    # emit an unbound reject, facilitator will also bounce based on its own
    # schema check. This failure path is rare; real facilitators validate shape
    # before asking the cage.
    try:
        intent = parse_intent(headers, body)
    except InvalidPaymentIntent as exc:
        logger.warning("payment intent rejected at parse: %s", exc)
        # Build a synthetic intent for binding purposes, we still need
        # something to hash. Using request attributes that failed validation
        # is fine because the reject is final.
        fake_intent = PaymentIntent(
            amount=__import__("decimal").Decimal("1"),
            currency="USDC",
            provider="unknown",
            counterparty="unknown",
            rail="x402",
            timestamp_unix=0,
        )
        v = Verdict(
            outcome="reject",
            rule_id="invalid_payment_intent",
            reason_text=f"Payment intent failed validation: {exc}",
            ttl_seconds=5,
        )
        env = sign(v, fake_intent, secret)
        return to_http_response(env)

    # Step 2: query daemon. Fail closed on any error.
    try:
        verdict = daemon.check(intent)
    except (FileNotFoundError, ConnectionRefusedError, socket.timeout) as exc:
        logger.error("cage daemon unreachable: %s", exc)
        verdict = _fail_closed_verdict(f"{type(exc).__name__}")
    except (OSError, RuntimeError) as exc:
        logger.error("cage daemon protocol error: %s", exc)
        verdict = _fail_closed_verdict(f"protocol: {exc}")

    # Step 3: sign + wire-serialize
    env = sign(verdict, intent, secret)
    return to_http_response(env)
