"""YAML policy loader.

Translates a declarative YAML policy file into a list of Invariant instances.
The daemon CLI uses this to pre-populate the x402 registry on startup via
`tau-x402-cage --policy policy.yaml`, and the `init` subcommand emits a starter
template that shows every supported invariant kind.

YAML schema:

    version: 1
    policy:
      - kind: spending_cap
        max_amount: "1000"
        currency: USDC
        scope: per_window        # per_tx | per_window | per_provider_per_window
        window_seconds: 86400
      - kind: max_per_call
        max_amount: "50"
      - kind: provider_allowlist
        providers: [anthropic, openai]
      - kind: retry_rate_limit
        min_gap_seconds: 30
      - kind: rolling_window_cap
        max_count: 100
        window_seconds: 3600
        group_by: provider       # provider | counterparty | global
      - kind: counterparty_constraint
        approved_ids: [vendor_a]
        sanctioned_ids: [ofac_01]

Failures raise PolicyLoaderError with the offending entry inline. A single
malformed invariant aborts the whole load (fail-closed: no partial policies).
"""
from __future__ import annotations

import json
from dataclasses import dataclass
from decimal import Decimal, InvalidOperation
from pathlib import Path
from typing import Any, List

from adapter.invariants import (
    CounterpartyConstraint,
    Invariant,
    MaxPerCall,
    ProviderAllowlist,
    RetryRateLimit,
    RollingWindowCap,
    SpendingCap,
)


class PolicyLoaderError(ValueError):
    """Raised when a policy file is malformed or references an unknown kind."""


_STARTER_TEMPLATE = """\
# tau-x402-cage starter policy
# Edit this file, then run:
#     tau-x402-cage --policy policy.yaml
#
# Every invariant kind is listed below. Delete the ones you don't want.
# Amounts are strings to preserve decimal precision (USDC has 6 decimals).
# See https://github.com/Jme-Tau/tau-x402-cage for the full rule taxonomy.

version: 1
policy:
  # Hard ceiling on any single payment
  - kind: max_per_call
    max_amount: "50"
    currency: USDC

  # Rolling 24h spending cap across all providers
  - kind: spending_cap
    max_amount: "1000"
    currency: USDC
    scope: per_window
    window_seconds: 86400

  # Only approved AI / infrastructure providers
  - kind: provider_allowlist
    providers:
      - anthropic
      - openai
      - replicate

  # Throttle retries to the same (provider, counterparty) pair
  - kind: retry_rate_limit
    min_gap_seconds: 30

  # At most 100 payments per provider per hour
  - kind: rolling_window_cap
    max_count: 100
    window_seconds: 3600
    group_by: provider

  # Counterparty attestation gate (leave empty sets to skip)
  - kind: counterparty_constraint
    approved_ids: []
    sanctioned_ids: []
"""


SUGGEST_PROMPT_TEMPLATE = """\
You are generating a policy.yaml for tau-x402-cage v0.3.

Schema (the six invariant kinds; use ONLY these):
  - spending_cap:           max_amount (string), currency, scope (per_tx | per_window | per_provider_per_window), window_seconds, provider
  - max_per_call:           max_amount (string), currency
  - provider_allowlist:     providers (list of strings)
  - retry_rate_limit:       min_gap_seconds (int)
  - rolling_window_cap:     max_count (int), window_seconds (int), group_by (provider | counterparty | global)
  - counterparty_constraint: approved_ids (list), sanctioned_ids (list)

Rules:
  1. Output ONLY valid YAML. No prose, no markdown fences, no commentary.
  2. Start with `version: 1` on line 1.
  3. Amounts MUST be strings (e.g. "500.00") to preserve decimal precision.
  4. Use ONLY the six kinds above. Do not invent new kinds.

User request: {user_request!r}

Output the policy.yaml:
"""


_COMPOSE_TEMPLATE = """\
# Run the cage as a sidecar next to your agent.
# Volume-mount /tmp so both containers see the UDS.

services:
  tau-x402-cage:
    image: ghcr.io/jme-tau/tau-x402-cage:latest
    command: ["--socket", "/tmp/tau-x402-cage.sock", "--policy", "/etc/policy.yaml"]
    volumes:
      - /tmp:/tmp
      - ./policy.yaml:/etc/policy.yaml:ro
    restart: unless-stopped

  # your-agent:
  #   image: your/agent-image
  #   volumes:
  #     - /tmp:/tmp                      # share the UDS socket
  #   depends_on:
  #     - tau-x402-cage
"""


@dataclass(frozen=True)
class LoadedPolicy:
    """Parsed policy: list of Invariants + original path for error reporting."""

    invariants: tuple[Invariant, ...]
    source_path: str


def write_starter_policy(out_path: Path) -> None:
    """Write a starter policy.yaml to `out_path`. Refuses to overwrite."""
    if out_path.exists():
        raise PolicyLoaderError(f"refusing to overwrite existing file: {out_path}")
    out_path.write_text(_STARTER_TEMPLATE, encoding="utf-8")


def write_starter_compose(out_path: Path) -> None:
    """Write a starter docker-compose.yaml to `out_path`. Refuses to overwrite."""
    if out_path.exists():
        raise PolicyLoaderError(f"refusing to overwrite existing file: {out_path}")
    out_path.write_text(_COMPOSE_TEMPLATE, encoding="utf-8")


def _parse_yaml(text: str) -> Any:
    """Minimal YAML parser for the policy schema.

    We avoid a hard PyYAML dependency to keep the install light (`pip install
    tau-x402-cage` has zero runtime deps as of V1). The schema is a flat list
    of dicts so the subset is trivial to handle. Users with complex policies
    can swap in PyYAML themselves via `import yaml; yaml.safe_load(...)`.
    """
    try:
        import yaml  # type: ignore
        return yaml.safe_load(text)
    except ImportError:
        return _tiny_yaml_parse(text)


def _tiny_yaml_parse(text: str) -> dict:
    """Tiny YAML subset parser covering the starter schema.

    Accepts:
      - top-level `key: value` pairs (scalars, integers, strings)
      - `key:` followed by an indented list (`- item`) or nested mapping
      - list items that are either scalars or inline mappings
      - comments (# ...) and blank lines

    Anything more exotic raises PolicyLoaderError urging the user to `pip
    install pyyaml`.
    """
    import re

    tokens = []  # list of (indent, raw_line)
    for raw in text.splitlines():
        stripped = raw.split("#", 1)[0].rstrip()
        if not stripped.strip():
            continue
        indent = len(stripped) - len(stripped.lstrip(" "))
        tokens.append((indent, stripped.strip()))

    def _coerce(v: str):
        v = v.strip()
        if v.startswith('"') and v.endswith('"'):
            return v[1:-1]
        if v.startswith("'") and v.endswith("'"):
            return v[1:-1]
        if v in ("true", "True"):
            return True
        if v in ("false", "False"):
            return False
        if v in ("null", "~", ""):
            return None
        if re.fullmatch(r"-?\d+", v):
            return int(v)
        if re.fullmatch(r"-?\d+\.\d+", v):
            return float(v)
        # Inline flow-style list: [], [a, b, c]
        if v.startswith("[") and v.endswith("]"):
            inner = v[1:-1].strip()
            if not inner:
                return []
            return [_coerce(item) for item in inner.split(",")]
        return v

    def _parse_block(start: int, block_indent: int) -> tuple[Any, int]:
        i = start
        if i < len(tokens) and tokens[i][1].startswith("- "):
            # list
            out: list = []
            while i < len(tokens) and tokens[i][0] == block_indent and tokens[i][1].startswith("- "):
                item_line = tokens[i][1][2:].strip()
                if ":" in item_line and not item_line.endswith(":"):
                    # inline first kv pair of a mapping item
                    k, _, v = item_line.partition(":")
                    item: dict = {k.strip(): _coerce(v)}
                    i += 1
                    while i < len(tokens) and tokens[i][0] > block_indent:
                        sub_indent = tokens[i][0]
                        sub_line = tokens[i][1]
                        if ":" in sub_line and not sub_line.endswith(":"):
                            k2, _, v2 = sub_line.partition(":")
                            item[k2.strip()] = _coerce(v2)
                            i += 1
                        elif sub_line.endswith(":"):
                            k2 = sub_line[:-1].strip()
                            i += 1
                            val, i = _parse_block(i, sub_indent + 2)
                            item[k2] = val
                        else:
                            raise PolicyLoaderError(f"cannot parse line: {sub_line!r}")
                    out.append(item)
                elif item_line.endswith(":"):
                    # list item that is a nested mapping with no inline kv
                    k = item_line[:-1].strip()
                    i += 1
                    val, i = _parse_block(i, block_indent + 2)
                    out.append({k: val})
                else:
                    # scalar list item
                    out.append(_coerce(item_line))
                    i += 1
            return out, i
        # mapping
        mapping: dict = {}
        while i < len(tokens) and tokens[i][0] == block_indent:
            line = tokens[i][1]
            if ":" in line and not line.endswith(":"):
                k, _, v = line.partition(":")
                mapping[k.strip()] = _coerce(v)
                i += 1
            elif line.endswith(":"):
                k = line[:-1].strip()
                i += 1
                val, i = _parse_block(i, block_indent + 2)
                mapping[k] = val
            else:
                raise PolicyLoaderError(f"cannot parse line: {line!r}")
        return mapping, i

    parsed, _ = _parse_block(0, 0)
    return parsed


def load_policy(path: Path | str) -> LoadedPolicy:
    """Parse a YAML policy file into a LoadedPolicy.

    Raises PolicyLoaderError with the offending entry if:
      - file does not exist
      - `version` is missing or not 1
      - an entry is missing `kind`, references an unknown kind, or has
        missing/unparseable fields
    """
    p = Path(path)
    if not p.exists():
        raise PolicyLoaderError(f"policy file not found: {p}")
    try:
        data = _parse_yaml(p.read_text(encoding="utf-8"))
    except PolicyLoaderError:
        raise
    except Exception as exc:  # yaml errors
        raise PolicyLoaderError(f"failed to parse YAML in {p}: {exc}") from exc

    if not isinstance(data, dict):
        raise PolicyLoaderError(f"{p}: top-level must be a mapping, got {type(data).__name__}")
    version = data.get("version")
    if version != 1:
        raise PolicyLoaderError(f"{p}: unsupported policy version {version!r}, expected 1")
    entries = data.get("policy")
    if not isinstance(entries, list):
        raise PolicyLoaderError(f"{p}: 'policy' must be a list, got {type(entries).__name__}")

    invariants: List[Invariant] = []
    for idx, raw in enumerate(entries):
        if not isinstance(raw, dict):
            raise PolicyLoaderError(
                f"{p}: entry #{idx} is not a mapping: {raw!r}"
            )
        try:
            invariants.append(_build_invariant(raw))
        except (PolicyLoaderError, ValueError, KeyError, InvalidOperation, TypeError) as exc:
            raise PolicyLoaderError(f"{p}: entry #{idx} ({raw!r}): {exc}") from exc

    return LoadedPolicy(invariants=tuple(invariants), source_path=str(p))


def _build_invariant(entry: dict) -> Invariant:
    """Dispatch on `kind`. Mirrors daemon.server._build_x402_invariant."""
    kind = entry.get("kind")
    if kind == "spending_cap":
        return SpendingCap(
            max_amount=Decimal(str(entry["max_amount"])),
            currency=entry.get("currency", "USDC"),
            scope=entry.get("scope", "per_window"),
            window_seconds=entry.get("window_seconds"),
            provider=entry.get("provider"),
        )
    if kind == "max_per_call":
        return MaxPerCall(
            max_amount=Decimal(str(entry["max_amount"])),
            currency=entry.get("currency", "USDC"),
        )
    if kind == "provider_allowlist":
        providers = entry.get("providers") or []
        if not isinstance(providers, list):
            raise PolicyLoaderError(f"providers must be a list, got {type(providers).__name__}")
        return ProviderAllowlist(providers=frozenset(str(p) for p in providers))
    if kind == "retry_rate_limit":
        return RetryRateLimit(min_gap_seconds=int(entry["min_gap_seconds"]))
    if kind == "rolling_window_cap":
        return RollingWindowCap(
            max_count=int(entry["max_count"]),
            window_seconds=int(entry["window_seconds"]),
            group_by=entry.get("group_by", "provider"),
        )
    if kind == "counterparty_constraint":
        return CounterpartyConstraint(
            approved_ids=frozenset(entry.get("approved_ids") or []),
            sanctioned_ids=frozenset(entry.get("sanctioned_ids") or []),
        )
    raise PolicyLoaderError(f"unknown invariant kind: {kind!r}")
