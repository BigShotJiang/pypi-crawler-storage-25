"""x402 wire envelope, maps SignedEnvelope to HTTP 402 response headers + body.

RFC-draft normative surface (see docs/rfc/2026-04-x402-formal-policy-semantics.md):
    Response headers on 402/403:
        X-Policy-Verdict: permit|reject
        X-Policy-Rule-Id: <rule_id>             (present on reject)
        X-Policy-Verdict-TTL: <seconds>
        X-Policy-Intent-Hash: <hex>
        X-Policy-MAC-Alg: HMAC-SHA256
    Response body (application/json):
        serialized SignedEnvelope (see verdict_signer.py)

The facilitator MUST verify the signature against its shared secret and
MUST reject any request whose intent hash does not match the cage's verdict.
"""

from __future__ import annotations

from typing import Dict, Tuple

from adapter.verdict_signer import SignedEnvelope


def to_http_headers(env: SignedEnvelope) -> Dict[str, str]:
    """Emit the X-Policy-* header set for this envelope."""
    headers: Dict[str, str] = {
        "X-Policy-Verdict": env.outcome,
        "X-Policy-Verdict-TTL": str(env.ttl_seconds),
        "X-Policy-Intent-Hash": env.intent_hash,
        "X-Policy-MAC-Alg": env.mac_alg,
        "X-Policy-MAC": env.mac_hex,
        "X-Policy-Issued-At": str(env.issued_at_unix),
    }
    if env.rule_id:
        headers["X-Policy-Rule-Id"] = env.rule_id
    return headers


def to_http_response(env: SignedEnvelope) -> Tuple[int, Dict[str, str], bytes]:
    """Build the full (status, headers, body) tuple for an HTTP response.

    Status codes follow the RFC normative guidance:
        permit → 200 (or 402/retry in the pre-settlement flow)
        reject → 403 with the envelope body explaining why
    """
    status = 200 if env.outcome == "permit" else 403
    headers = to_http_headers(env)
    headers["Content-Type"] = "application/json"
    body = env.to_json().encode("utf-8")
    return status, headers, body


def from_http_response(headers: Dict[str, str], body: bytes) -> SignedEnvelope:
    """Parse an envelope out of an HTTP response received from the cage."""
    return SignedEnvelope.from_json(body.decode("utf-8"))
