"""Normalize raw HTTP-402 payment requests into a canonical PaymentIntent.

Input sources:
    - x402 (Coinbase), HTTP 402 response header scheme, USDC-on-Base default settlement
    - MPP (Stripe + Tempo), Machine Payments Protocol, same HTTP 402 primitive

Both rails converge on this single canonical shape so the cage core is rail-neutral.
Validation is strict (security finding H-07): any field that flows into the Tau
spec emission path (provider, counterparty, currency, rail) must be schema-validated
and escaping-safe before reaching `to_tau_spec()`.

Contract:
    parse_x402(headers, body) -> PaymentIntent
    parse_mpp(headers, body)  -> PaymentIntent  (stub; MPP is stretch per plan v2 D6)
    detect_rail(headers)      -> Literal["x402", "mpp"]
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from decimal import Decimal, InvalidOperation
from typing import Any, FrozenSet, Literal, Mapping, Optional


# ── schema & errors ──────────────────────────────────────────────────────────


class InvalidPaymentIntent(ValueError):
    """Raised when a payment intent fails schema validation.

    Never propagate raw parse exceptions from client code, this class wraps
    every parsing/validation error so callers have one thing to catch and one
    error message to surface.
    """


Rail = Literal["x402", "mpp"]

# Strict field-value allowlists. Any value outside these goes through Tau's
# fragment generator as a hash (see _provider_hash in invariants.py), so the
# concern here is preventing injection-style mischief in the Tau grammar, not
# semantic filtering.
_SAFE_TOKEN_RE = re.compile(r"^[A-Za-z0-9_\-.:/]{1,128}$")
_ALLOWED_CURRENCIES: FrozenSet[str] = frozenset({"USDC", "USDT", "DAI", "ETH", "BTC"})
_ALLOWED_RAILS: FrozenSet[str] = frozenset({"x402", "mpp"})


@dataclass(frozen=True)
class PaymentIntent:
    """Canonical payment intent the cage reasons about.

    Immutable. All string fields are schema-validated at construction; any
    downstream code that builds Tau fragments from these fields can assume
    the values are safe to interpolate.
    """

    amount: Decimal
    currency: str
    provider: str
    counterparty: str
    rail: Rail
    timestamp_unix: int
    metadata: Mapping[str, str] = field(default_factory=dict)
    # Request id bound into the signed verdict for replay protection (C-02).
    # Callers usually derive this from a content hash of the request.
    request_id: Optional[str] = None

    def __post_init__(self) -> None:
        if self.amount <= 0:
            raise InvalidPaymentIntent(f"amount must be > 0, got {self.amount}")
        if self.currency not in _ALLOWED_CURRENCIES:
            raise InvalidPaymentIntent(
                f"currency {self.currency!r} not in allowed set {sorted(_ALLOWED_CURRENCIES)}"
            )
        if self.rail not in _ALLOWED_RAILS:
            raise InvalidPaymentIntent(f"rail {self.rail!r} must be one of {sorted(_ALLOWED_RAILS)}")
        for fname, fval in (
            ("provider", self.provider),
            ("counterparty", self.counterparty),
        ):
            if not _SAFE_TOKEN_RE.fullmatch(fval):
                raise InvalidPaymentIntent(
                    f"{fname} value {fval!r} fails safe-token schema (printable, "
                    f"<=128 chars, alnum + `_-.:/`)"
                )
        if self.timestamp_unix < 0:
            raise InvalidPaymentIntent(f"timestamp_unix must be >= 0, got {self.timestamp_unix}")
        # Metadata: validate keys + values shape-wise; do NOT allow bytes or nested dicts
        for k, v in self.metadata.items():
            if not isinstance(k, str) or not _SAFE_TOKEN_RE.fullmatch(k):
                raise InvalidPaymentIntent(f"metadata key {k!r} fails safe-token schema")
            if not isinstance(v, str) or len(v) > 512:
                raise InvalidPaymentIntent(f"metadata value for {k!r} must be str <=512 chars")
        if self.request_id is not None and not _SAFE_TOKEN_RE.fullmatch(self.request_id):
            raise InvalidPaymentIntent(f"request_id {self.request_id!r} fails safe-token schema")


# ── rail detection ───────────────────────────────────────────────────────────


def detect_rail(headers: Mapping[str, str]) -> Rail:
    """Detect rail from HTTP headers. Defaults to x402 if ambiguous."""
    # Normalize header names for case-insensitive lookup
    lower = {k.lower(): v for k, v in headers.items()}
    if "x-mpp-version" in lower or lower.get("x-payment-scheme", "").lower().startswith("mpp"):
        return "mpp"
    # x402 is the default when we see any payment-related HTTP 402 flow
    return "x402"


# ── parsers ──────────────────────────────────────────────────────────────────


def parse_x402(headers: Mapping[str, str], body: bytes) -> PaymentIntent:
    """Parse an x402 payment intent from headers + body.

    x402 request shape (payer → facilitator, on retry-with-payment):
        X-PAYMENT: <base64 signed payload>
        Content-Type: application/json
        body = {
            "amount": "50.00",
            "currency": "USDC",
            "provider": "anthropic",
            "counterparty": "0xdeadbeef...",
            "timestamp": 1713456789,
            "metadata": { ... }
        }

    The signed `X-PAYMENT` header is verified elsewhere, this module only
    normalizes the semantic fields the cage needs to reason about.
    """
    try:
        payload: Any = json.loads(body.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise InvalidPaymentIntent(f"x402 body is not valid UTF-8 JSON: {exc}") from exc
    if not isinstance(payload, dict):
        raise InvalidPaymentIntent(f"x402 body must be a JSON object, got {type(payload).__name__}")
    try:
        amount = Decimal(str(payload["amount"]))
    except (KeyError, InvalidOperation) as exc:
        raise InvalidPaymentIntent(f"x402 body missing or malformed `amount`: {exc}") from exc
    try:
        ts = int(payload.get("timestamp") or 0)
    except (TypeError, ValueError) as exc:
        raise InvalidPaymentIntent(f"x402 `timestamp` must be int: {exc}") from exc
    metadata_raw = payload.get("metadata") or {}
    if not isinstance(metadata_raw, dict):
        raise InvalidPaymentIntent("x402 `metadata` must be an object if present")
    metadata = {str(k): str(v) for k, v in metadata_raw.items()}
    return PaymentIntent(
        amount=amount,
        currency=str(payload.get("currency", "USDC")),
        provider=str(payload.get("provider", "")),
        counterparty=str(payload.get("counterparty", "")),
        rail="x402",
        timestamp_unix=ts,
        metadata=metadata,
        request_id=str(payload["request_id"]) if "request_id" in payload else None,
    )


def parse_mpp(headers: Mapping[str, str], body: bytes) -> PaymentIntent:
    """Parse an MPP (Stripe + Tempo) payment intent.

    Stub, per plan v2 D6, MPP is stretch (post-graduation). Implemented
    as a thin wrapper around parse_x402 because both rails use JSON over HTTP
    402 with overlapping field names. Real MPP has additional fields for
    Visa anchor-validator attestations; those are not reasoned about in V1.
    """
    intent = parse_x402(headers, body)
    # Return a new instance with rail="mpp" (immutable, so construct fresh)
    return PaymentIntent(
        amount=intent.amount,
        currency=intent.currency,
        provider=intent.provider,
        counterparty=intent.counterparty,
        rail="mpp",
        timestamp_unix=intent.timestamp_unix,
        metadata=intent.metadata,
        request_id=intent.request_id,
    )


def parse(headers: Mapping[str, str], body: bytes) -> PaymentIntent:
    """Auto-detect rail and dispatch to the right parser."""
    rail = detect_rail(headers)
    if rail == "mpp":
        return parse_mpp(headers, body)
    return parse_x402(headers, body)
