"""x402 invariant taxonomy.

Immutable dataclasses representing the seven V1 invariant types. Each emits a Tau
spec fragment via `to_tau_spec()` that composes into a conjunction fed to the
Tau interpreter. Composition is checked for satisfiability at declare time -
contradictions are surfaced before any payment intent is processed.

Taxonomy reference: docs/x402-invariants.md.
Plan: ../Tau-Safety-Cage/docs/plans/2026-04-18-001-feat-tau-x402-standards-capture-plan.v2.md

Decidability classes (as of 2026-04-18 with patched Tau):
  Clean         -- SpendingCap, MaxPerCall, ProviderAllowlist, RetryRateLimit, RollingWindowCap
  Enum-partial  -- JurisdictionRule, CounterpartyConstraint (nlang BA broken, using enum)
"""

from __future__ import annotations

from dataclasses import dataclass, field
from decimal import Decimal
from typing import ClassVar, FrozenSet, Literal, Optional, Sequence, Tuple

# Forward-declared so `check_payment` can annotate without importing at module load.
# `from __future__ import annotations` above makes this a pure type hint.
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from adapter.payment_intent_matcher import PaymentIntent


@dataclass(frozen=True)
class Violation:
    """A specific invariant violation. Daemon-side `check_payment` returns one or None."""

    rule_id: str
    reason_text: str
    witness: Optional[str] = None


class InvariantError(ValueError):
    """Raised when an invariant is constructed with invalid arguments."""


class ContradictionError(ValueError):
    """Raised when adding an invariant would make the composition unsatisfiable.

    The `witness` field names the pair of invariants whose conjunction
    is unsat (best-effort, for large rule sets the pairwise scan may
    surface one conflict among several).
    """

    def __init__(self, message: str, witness: Optional[Tuple[str, str]] = None):
        super().__init__(message)
        self.witness = witness


@dataclass(frozen=True)
class Invariant:
    """Base class. Subclasses implement `_body()`, the formula that sits
    inside a single top-level `G(...)`. `to_tau_spec()` wraps it for standalone
    use; `compose()` merges multiple bodies under one `G(...)` to satisfy
    Tau's prohibition on nested temporal quantifiers.
    """

    def _body(self) -> str:
        raise NotImplementedError

    def to_tau_spec(self) -> str:
        return f"G({self._body()})"

    @property
    def name(self) -> str:
        return self.__class__.__name__

    def check_payment(
        self,
        intent: "PaymentIntent",
        history: Sequence["PaymentIntent"],
        rejects: Sequence["PaymentIntent"] = (),
    ) -> Optional[Violation]:
        """Python-side enforcement. Returns Violation if intent is rejected, None if clean.

        Tau composition is checked at declare time for rule-rule contradictions; this
        method is the per-call fast path.

        Args:
            intent:  the payment intent under evaluation
            history: previously PERMITTED intents in this session (oldest → newest)
            rejects: previously REJECTED intents (oldest → newest). Only
                     RetryRateLimit consults this. Other invariants ignore it.
        """
        raise NotImplementedError


# Scopes: informs how caps aggregate. "per_tx" resets on every payment; "per_window"
# accumulates across a rolling time window; "per_provider_per_window" groups by
# counterparty inside the window.
SpendingScope = Literal["per_tx", "per_window", "per_provider_per_window"]


@dataclass(frozen=True)
class SpendingCap(Invariant):
    """Cumulative spend must not exceed max_amount in the given scope."""

    max_amount: Decimal
    currency: str = "USDC"
    scope: SpendingScope = "per_window"
    window_seconds: Optional[int] = None
    provider: Optional[str] = None

    def __post_init__(self) -> None:
        if self.max_amount <= 0:
            raise InvariantError(f"SpendingCap max_amount must be > 0, got {self.max_amount}")
        if self.scope in ("per_window", "per_provider_per_window") and self.window_seconds is None:
            raise InvariantError(f"SpendingCap with scope={self.scope} requires window_seconds")
        if self.scope == "per_provider_per_window" and self.provider is None:
            raise InvariantError("SpendingCap with scope=per_provider_per_window requires provider")

    def _body(self) -> str:
        amt = _amount_to_bv(self.max_amount)
        if self.scope == "per_tx":
            return f"payment_amount[t]:bv[64] <= {amt}"
        if self.scope == "per_window":
            return f"cumulative_spend[t]:bv[64] <= {amt}"
        # per_provider_per_window
        return (
            f"provider[t]:bv[16] = {{ {_provider_hash(self.provider)} }}:bv[16]"
            f" -> cumulative_provider_spend[t]:bv[64] <= {amt}"
        )

    def check_payment(self, intent, history, rejects=()):
        rule_id = f"spending_cap_{self.scope}"
        if self.scope == "per_tx":
            if intent.amount > self.max_amount:
                return Violation(
                    rule_id=rule_id,
                    reason_text=(
                        f"per-transaction cap {self.max_amount} {self.currency} exceeded "
                        f"(intent: {intent.amount})"
                    ),
                    witness=f"intent={intent.amount},cap={self.max_amount}",
                )
            return None
        window = self.window_seconds or 0
        cutoff = intent.timestamp_unix - window
        if self.scope == "per_provider_per_window":
            relevant = [
                p for p in history
                if p.provider == self.provider
                and p.currency == self.currency
                and p.timestamp_unix >= cutoff
            ]
        else:
            relevant = [
                p for p in history
                if p.currency == self.currency and p.timestamp_unix >= cutoff
            ]
        cumulative = sum((p.amount for p in relevant), Decimal("0")) + intent.amount
        if cumulative > self.max_amount:
            return Violation(
                rule_id=rule_id,
                reason_text=(
                    f"{self.scope} cap {self.max_amount} {self.currency} exceeded "
                    f"(cumulative: {cumulative})"
                ),
                witness=f"cumulative={cumulative},cap={self.max_amount},window={window}s",
            )
        return None


@dataclass(frozen=True)
class MaxPerCall(Invariant):
    """No single payment may exceed max_amount."""

    max_amount: Decimal
    currency: str = "USDC"

    def __post_init__(self) -> None:
        if self.max_amount <= 0:
            raise InvariantError(f"MaxPerCall max_amount must be > 0, got {self.max_amount}")

    def _body(self) -> str:
        return f"payment_amount[t]:bv[64] <= {_amount_to_bv(self.max_amount)}"

    def check_payment(self, intent, history, rejects=()):
        if intent.currency != self.currency:
            return None
        if intent.amount > self.max_amount:
            return Violation(
                rule_id="max_per_call",
                reason_text=(
                    f"Single-call cap {self.max_amount} {self.currency} exceeded "
                    f"(intent: {intent.amount})"
                ),
                witness=f"intent={intent.amount},cap={self.max_amount}",
            )
        return None


@dataclass(frozen=True)
class ProviderAllowlist(Invariant):
    """Counterparty provider must be in the approved set."""

    providers: FrozenSet[str]

    def __post_init__(self) -> None:
        if not self.providers:
            raise InvariantError("ProviderAllowlist requires at least one approved provider")

    def _body(self) -> str:
        # Enum-encoded: each provider hashes to a bv[16] slot; OR of equalities.
        terms = [
            f"provider[t]:bv[16] = {{ {_provider_hash(p)} }}:bv[16]"
            for p in sorted(self.providers)
        ]
        return "(" + " || ".join(terms) + ")"

    def check_payment(self, intent, history, rejects=()):
        if intent.provider in self.providers:
            return None
        return Violation(
            rule_id="provider_allowlist",
            reason_text=(
                f"Provider {intent.provider!r} not in allowlist "
                f"({sorted(self.providers)})"
            ),
            witness=f"provider={intent.provider}",
        )


@dataclass(frozen=True)
class RetryRateLimit(Invariant):
    """After a rejection, no retry for at least min_gap_seconds.

    Uses the Bug-4-patched `&` at wff level for a readable chain of time-shifted
    equalities. On the patched parser, `&` and `&&` are equivalent at wff level.
    """

    min_gap_seconds: int

    def __post_init__(self) -> None:
        if self.min_gap_seconds <= 0:
            raise InvariantError(
                f"RetryRateLimit min_gap_seconds must be > 0, got {self.min_gap_seconds}"
            )
        if self.min_gap_seconds > 300:
            # Practical limit; generated Tau fragment explodes linearly.
            raise InvariantError(
                f"RetryRateLimit min_gap_seconds > 300 not supported in V1 "
                f"(generates {self.min_gap_seconds} chained predicates); got {self.min_gap_seconds}"
            )

    def _body(self) -> str:
        # retry → !O(recent reject). Uses the Bug-3-patched unary past-LTL `O`
        # and the Bug-4-patched `&` at wff level.
        return (
            f"retry[t] = 1 -> !O(reject[t] = 1 "
            f"& time_since_last_reject[t]:bv[16] < {{ {self.min_gap_seconds} }}:bv[16])"
        )

    def check_payment(self, intent, history, rejects=()):
        # V0.2 semantic: lock out retries AFTER a reject for the same
        # (provider, counterparty) pair. Permits alone never trigger this rule.
        cutoff = intent.timestamp_unix - self.min_gap_seconds
        recent_rejects = [
            r for r in rejects
            if r.provider == intent.provider
            and r.counterparty == intent.counterparty
            and r.timestamp_unix > cutoff
        ]
        if recent_rejects:
            gap = intent.timestamp_unix - recent_rejects[-1].timestamp_unix
            return Violation(
                rule_id="retry_rate_limit",
                reason_text=(
                    f"Retry gap {gap}s below required {self.min_gap_seconds}s after "
                    f"reject for {intent.provider}/{intent.counterparty}"
                ),
                witness=f"gap={gap}s,min={self.min_gap_seconds}s",
            )
        return None


@dataclass(frozen=True)
class RollingWindowCap(Invariant):
    """Count of grouped events in a rolling window must not exceed max_count."""

    max_count: int
    window_seconds: int
    group_by: Literal["provider", "counterparty", "global"] = "provider"

    def __post_init__(self) -> None:
        if self.max_count <= 0:
            raise InvariantError(f"RollingWindowCap max_count must be > 0, got {self.max_count}")
        if self.window_seconds <= 0:
            raise InvariantError(
                f"RollingWindowCap window_seconds must be > 0, got {self.window_seconds}"
            )

    def _body(self) -> str:
        # Tau maintains a sliding counter stream; cage emits only the bound.
        counter = {
            "provider": "count_per_provider_in_window",
            "counterparty": "count_per_counterparty_in_window",
            "global": "count_in_window",
        }[self.group_by]
        bits = _count_bits(self.max_count)
        return f"{counter}[t]:bv[{bits}] <= {{ {self.max_count} }}:bv[{bits}]"

    def check_payment(self, intent, history, rejects=()):
        cutoff = intent.timestamp_unix - self.window_seconds
        if self.group_by == "provider":
            relevant = [p for p in history if p.provider == intent.provider and p.timestamp_unix >= cutoff]
            bucket = intent.provider
        elif self.group_by == "counterparty":
            relevant = [p for p in history if p.counterparty == intent.counterparty and p.timestamp_unix >= cutoff]
            bucket = intent.counterparty
        else:
            relevant = [p for p in history if p.timestamp_unix >= cutoff]
            bucket = "global"
        # +1 for the intent under consideration
        count = len(relevant) + 1
        if count > self.max_count:
            return Violation(
                rule_id=f"rolling_window_cap_{self.group_by}",
                reason_text=(
                    f"Rolling-window cap {self.max_count} over {self.window_seconds}s "
                    f"exceeded for {self.group_by}={bucket!r} (count={count})"
                ),
                witness=f"count={count},cap={self.max_count},window={self.window_seconds}s",
            )
        return None


# Enum-partial invariants, V1.1 when nlang BA lands

Jurisdiction = Literal["EU", "UK", "US", "APAC", "OTHER"]


@dataclass(frozen=True)
class JurisdictionRule(Invariant):
    """If provider's jurisdiction is in the target set, require additional invariants.

    Enum-partial (V1): uses fixed jurisdiction codes. Full nlang-based matching
    deferred to V1.1.
    """

    jurisdiction: Jurisdiction
    additional_invariants: Tuple[Invariant, ...] = field(default_factory=tuple)

    _JURISDICTION_CODES: ClassVar[dict] = {"EU": 1, "UK": 2, "US": 3, "APAC": 4, "OTHER": 5}

    def _body(self) -> str:
        code = self._JURISDICTION_CODES[self.jurisdiction]
        if not self.additional_invariants:
            return "T"  # no-op inside G
        # Inner invariants contribute their body-only forms (we're already under G)
        inner = " && ".join(inv._body() for inv in self.additional_invariants)
        return f"provider_jurisdiction[t]:bv[4] = {{ {code} }}:bv[4] -> ({inner})"

    def check_payment(self, intent, history, rejects=()):
        # Enum-partial: jurisdiction is expected in intent.metadata["jurisdiction"].
        # If the intent jurisdiction doesn't match, this rule is vacuous (no-op).
        intent_jur = intent.metadata.get("jurisdiction")
        if intent_jur != self.jurisdiction:
            return None
        for inv in self.additional_invariants:
            v = inv.check_payment(intent, history, rejects)
            if v is not None:
                return Violation(
                    rule_id=f"jurisdiction_{self.jurisdiction.lower()}.{v.rule_id}",
                    reason_text=f"[{self.jurisdiction}] {v.reason_text}",
                    witness=v.witness,
                )
        return None


@dataclass(frozen=True)
class CounterpartyConstraint(Invariant):
    """Counterparty must have required attestations and not be sanctioned.

    Enum-partial (V1): approved / sanctioned sets are hashed enums.
    """

    approved_ids: FrozenSet[str] = field(default_factory=frozenset)
    sanctioned_ids: FrozenSet[str] = field(default_factory=frozenset)

    def __post_init__(self) -> None:
        overlap = self.approved_ids & self.sanctioned_ids
        if overlap:
            raise InvariantError(
                f"CounterpartyConstraint has overlap between approved and sanctioned: {overlap}"
            )

    def _body(self) -> str:
        parts = []
        if self.approved_ids:
            approved = " || ".join(
                f"counterparty[t]:bv[16] = {{ {_provider_hash(c)} }}:bv[16]"
                for c in sorted(self.approved_ids)
            )
            parts.append(f"({approved})")
        if self.sanctioned_ids:
            # Sanctioned check: counterparty must NOT equal any sanctioned id.
            # Expressed as conjunction of inequalities under the outer G.
            for c in sorted(self.sanctioned_ids):
                parts.append(f"counterparty[t]:bv[16] != {{ {_provider_hash(c)} }}:bv[16]")
        if not parts:
            return "T"
        return " && ".join(parts)

    def check_payment(self, intent, history, rejects=()):
        if intent.counterparty in self.sanctioned_ids:
            return Violation(
                rule_id="counterparty_sanctioned",
                reason_text=f"Counterparty {intent.counterparty!r} is on sanctions list",
                witness=f"counterparty={intent.counterparty}",
            )
        if self.approved_ids and intent.counterparty not in self.approved_ids:
            return Violation(
                rule_id="counterparty_not_approved",
                reason_text=(
                    f"Counterparty {intent.counterparty!r} not in approved set "
                    f"({sorted(self.approved_ids)})"
                ),
                witness=f"counterparty={intent.counterparty}",
            )
        return None


# ── composition ──────────────────────────────────────────────────────────────


def compose(invariants: Sequence[Invariant]) -> str:
    """Conjunct a sequence of invariant bodies under a single top-level G.

    Tau rejects nested temporal quantifiers (`G(A) && G(B)`), so we collect
    each invariant's body-only form and wrap the conjunction in one `G(...)`.
    This matches how Tau's `flatten_always_conjuncts` normalizes internally,
    but applied at spec-emission time to pass the nesting check.
    """
    if not invariants:
        return "G(T)."
    bodies = [inv._body() for inv in invariants]
    if len(bodies) == 1:
        return f"G({bodies[0]})."
    return "G(" + " && ".join(f"({b})" for b in bodies) + ")."


# ── helpers ──────────────────────────────────────────────────────────────────


def _amount_to_bv(amount: Decimal) -> str:
    """Convert a Decimal amount to the cage's canonical bv[64] literal.

    Amounts are scaled to micro-units (10^-6), USDC uses 6 decimals.
    """
    micro = int(amount * Decimal("1_000_000"))
    if micro < 0 or micro >= (1 << 64):
        raise InvariantError(f"Amount {amount} out of bv[64] range")
    return f"{{ {micro} }}:bv[64]"


def _provider_hash(name: str) -> int:
    """Deterministic 16-bit hash for provider enum encoding.

    Uses a stable hash so the same provider produces the same bv value across
    cage instances. Not cryptographic, just enum encoding.
    """
    import hashlib

    h = hashlib.sha256(name.encode("utf-8")).digest()
    return int.from_bytes(h[:2], "big")


def _count_bits(max_count: int) -> int:
    """Return bv width sufficient for max_count (rounded to nearest power of 2, min 8)."""
    import math

    if max_count <= 0:
        return 8
    needed = max(8, math.ceil(math.log2(max_count + 1)))
    # Round to power of 2
    for width in (8, 16, 32, 64):
        if needed <= width:
            return width
    raise InvariantError(f"max_count {max_count} requires > 64 bits")
