"""llm-wiki-tools — CLI package for LLM Wiki management."""

__version__ = "0.3.0"
