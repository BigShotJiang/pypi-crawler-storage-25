"""
wiki-manage — manage the project wiki on GitHub.

Usage:
  wiki-manage status              show file counts for raw/, updates/, wiki/
  wiki-manage generate            read local raw/, print content for Claude to generate wiki pages
  wiki-manage update              read local updates/, print content for Claude to update wiki, move files to raw/
  wiki-manage delete <page>       delete a wiki page from GitHub
  wiki-manage lint                check wiki health: broken links, orphan pages, missing required pages
"""

import sys
import re
from .github_client import load_config, GitHubClient, configure_logging, _md

# Only these two pages are always required.
# All other pages are dynamic and discovered from index.md.
REQUIRED_PAGES = ["index.md", "changelog.md"]

SEP = "=" * 60


def main():
    args = sys.argv[1:]

    verbose = "--verbose" in args
    args = [a for a in args if a != "--verbose"]
    configure_logging(verbose)

    if not args:
        print(__doc__)
        sys.exit(0)

    try:
        config = load_config()
        gh = GitHubClient(config)
    except (FileNotFoundError, EnvironmentError, RuntimeError, ValueError) as e:
        print(f"ERROR: {e}", file=sys.stderr)
        sys.exit(1)

    cmd = args[0]

    try:
        if cmd == "status":
            cmd_status(gh)
        elif cmd == "generate":
            cmd_generate(gh)
        elif cmd == "update":
            cmd_update(gh)
        elif cmd == "delete":
            if len(args) < 2:
                print("Usage: wiki-manage delete <page>", file=sys.stderr)
                sys.exit(1)
            cmd_delete(gh, args[1])
        elif cmd == "lint":
            cmd_lint(gh)
        else:
            print(f"Unknown command: {cmd}", file=sys.stderr)
            print(__doc__)
            sys.exit(1)
    except RuntimeError as e:
        print(f"ERROR: {e}", file=sys.stderr)
        sys.exit(1)


# ── commands ──────────────────────────────────────────────────────────────────

def cmd_status(gh: GitHubClient):
    try:
        raw = gh.list_raw()
        updates = gh.list_updates()
    except RuntimeError as e:
        print(f"ERROR: {e}", file=sys.stderr)
        sys.exit(1)

    wiki = gh.list_pages()

    print(f"raw/     : {len(raw)} file(s)   [local]")
    print(f"updates/ : {len(updates)} file(s)   [local]")
    print(f"wiki/    : {len(wiki)} page(s)   [github]")

    if updates:
        print("\nPending updates:")
        for f in updates:
            print(f"  - {f}")


def cmd_generate(gh: GitHubClient):
    """
    Read all files from local raw/ and print them to stdout.
    Claude processes this output and writes wiki pages to GitHub.
    """
    try:
        raw_files = gh.list_raw()
    except RuntimeError as e:
        print(f"ERROR: {e}", file=sys.stderr)
        sys.exit(1)

    if not raw_files:
        print("No files found in raw/")
        return

    print(f"Found {len(raw_files)} file(s) in raw/\n")
    for filename in raw_files:
        print(SEP)
        print(f"FILE: {filename}")
        print(SEP)
        try:
            print(gh.read_raw(filename))
        except Exception as e:
            print(f"[ERROR reading {filename}: {e}]")
        print()

    print("--- END OF RAW FILES ---")
    print(f"\nRequired pages: {', '.join(REQUIRED_PAGES)}")
    print("All other pages are determined by the project content.")
    print("index.md must link to every other page you create.")


def cmd_update(gh: GitHubClient):
    """
    Read all files from local updates/ and print them alongside
    the current wiki page list. Claude updates the relevant pages
    on GitHub. Files are then moved from updates/ to raw/ locally.
    """
    try:
        update_files = gh.list_updates()
    except RuntimeError as e:
        print(f"ERROR: {e}", file=sys.stderr)
        sys.exit(1)

    if not update_files:
        print("No files found in updates/")
        return

    print(f"Found {len(update_files)} file(s) in updates/\n")
    ok_files = []
    for filename in update_files:
        print(SEP)
        print(f"UPDATE: {filename}")
        print(SEP)
        try:
            print(gh.read_update(filename))
            ok_files.append(filename)
        except Exception as e:
            print(f"[ERROR reading {filename}: {e}]")
        print()

    wiki_pages = gh.list_pages()
    print(SEP)
    print(f"CURRENT WIKI ({len(wiki_pages)} pages)  [github]")
    print(SEP)
    for p in sorted(wiki_pages):
        print(f"  - {p}")

    print("\n--- END OF UPDATE FILES ---")
    print("Update the relevant wiki pages on GitHub and add an entry to changelog.md.")

    skipped = [f for f in update_files if f not in ok_files]
    if skipped:
        print(
            f"\n{len(skipped)} file(s) failed to read and were NOT moved "
            f"(still in updates/): {', '.join(skipped)}",
            file=sys.stderr,
        )

    if not ok_files:
        print("\nNo files moved (nothing read successfully).")
        return

    # Files are moved to raw/ once consumed: they become permanent project
    # history. Only files that were read successfully and emitted above are
    # moved; failed files stay in updates/ for a retry.
    print(f"\nMoving {len(ok_files)} file(s) from updates/ to raw/  [local]...")
    for filename in ok_files:
        try:
            gh.move_update_to_raw(filename)
            print(f"  ✓ {filename}")
        except Exception as e:
            print(f"  ✗ {filename}: {e}", file=sys.stderr)
    print("Done.")


def cmd_delete(gh: GitHubClient, page: str):
    """
    Delete a wiki page from GitHub.
    Refuses to delete required pages (index.md, changelog.md).
    """
    normalized = _md(page)

    if normalized in REQUIRED_PAGES:
        print(f"ERROR: cannot delete required page '{normalized}'.", file=sys.stderr)
        print(f"Required pages: {', '.join(REQUIRED_PAGES)}", file=sys.stderr)
        sys.exit(1)

    try:
        gh.delete_page(normalized)
        print(f"✓ Deleted: {normalized}")
        print(f"\nRemember to:")
        print(f"  - Remove links to {normalized} from index.md and any other pages")
        print(f"  - Add an entry to changelog.md")
    except RuntimeError as e:
        print(f"ERROR: {e}", file=sys.stderr)
        sys.exit(1)


def cmd_lint(gh: GitHubClient):
    """
    Check wiki health on GitHub:
    1. Required pages exist (index.md, changelog.md)
    2. Pages declared in index.md actually exist
    3. No broken internal links
    4. No orphan pages (not linked from anywhere)
    """
    print("Running wiki lint...\n")
    pages = gh.list_pages()
    page_set = set(pages)
    issues = []
    link_pattern = re.compile(r'\[([^\]]+)\]\(([^)#\s]+\.md)[^)]*\)')

    # 1. Required pages
    for rp in REQUIRED_PAGES:
        if rp not in page_set:
            issues.append(f"MISSING REQUIRED PAGE: {rp}")

    # 2. Pages declared in index.md
    if "index.md" in page_set:
        try:
            index_content = gh.read_page("index.md")
            for _, target in link_pattern.findall(index_content):
                if target not in page_set:
                    issues.append(f"PAGE IN INDEX BUT MISSING ON GITHUB: {target}")
        except RuntimeError:
            issues.append("UNREADABLE: index.md")

    # 3. Broken internal links + collect all linked pages
    linked = set()
    for page in pages:
        try:
            content = gh.read_page(page)
        except RuntimeError:
            issues.append(f"UNREADABLE: {page}")
            continue
        for _, target in link_pattern.findall(content):
            linked.add(target)
            if target not in page_set:
                issues.append(f"BROKEN LINK in {page}: → {target}")

    # 4. Orphan pages (required pages are never orphans by definition)
    for page in pages:
        if page not in REQUIRED_PAGES and page not in linked:
            issues.append(f"ORPHAN PAGE (not linked from anywhere): {page}")

    if not issues:
        print(f"✓ All good. {len(pages)} pages checked, no issues found.")
    else:
        print(f"Found {len(issues)} issue(s):\n")
        for issue in issues:
            print(f"  ✗ {issue}")
        print("\nFix the issues above by updating the relevant wiki pages.")


if __name__ == "__main__":
    main()