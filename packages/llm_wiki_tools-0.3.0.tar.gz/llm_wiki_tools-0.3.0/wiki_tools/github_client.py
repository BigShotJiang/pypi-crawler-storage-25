"""
GitHub client — core module for wiki-tools.

Reads .project from cwd (walking up). Supports two modes:

  Project repo — .project has wiki_repo only.
                 wiki-read uses this to read pages from GitHub.

  Wiki repo    — .project has wiki_repo + wiki_local_path.
                 wiki-manage uses wiki_local_path to read raw/ and updates/
                 from local disk, and wiki_repo to write wiki/ pages to GitHub.

Raw and update files are automatically converted to markdown via MarkItDown
before being returned. Plain text and markdown files are returned as-is.
"""

from __future__ import annotations

import os
import json
import base64
import shutil
import time
import random
import logging
from pathlib import Path
from typing import Optional
import urllib.request
import urllib.error

log = logging.getLogger("wiki_tools")


def configure_logging(verbose: bool = False) -> None:
    """Configure the wiki_tools logger to write to stderr.

    stdout is reserved for command output (Claude parses it); all logs and
    diagnostics go to stderr. DEBUG is enabled by --verbose or WIKI_TOOLS_DEBUG=1.
    """
    debug = verbose or os.environ.get("WIKI_TOOLS_DEBUG", "") not in ("", "0")
    handler = logging.StreamHandler()  # defaults to stderr
    handler.setFormatter(logging.Formatter("%(levelname)s: %(message)s"))
    log.handlers[:] = [handler]
    log.setLevel(logging.DEBUG if debug else logging.WARNING)
    log.propagate = False

_RETRY_STATUSES = {502, 503, 504, 429}
_MAX_ATTEMPTS = 3


# ── supported formats for MarkItDown conversion ───────────────────────────────

_CONVERT_EXTENSIONS = {
    # Office
    ".docx", ".xlsx", ".xls", ".pptx", ".msg",
    # PDF
    ".pdf",
    # Other binary/structured
    ".ipynb", ".epub", ".zip",
    ".jpg", ".jpeg", ".png", ".gif", ".webp",
    # HTML/XML (markitdown handles these better than raw read)
    ".html", ".htm", ".xml", ".rss", ".atom",
}

_PLAIN_EXTENSIONS = {
    ".txt", ".text", ".md", ".markdown",
    ".json", ".jsonl", ".csv",
    ".py", ".php", ".js", ".ts", ".java", ".go", ".rs", ".rb",
    ".cs", ".cpp", ".c", ".sh", ".sql",
}


def _build_markitdown() -> "MarkItDown":
    """
    Build a MarkItDown instance.
    If ANTHROPIC_API_KEY is set and anthropic is installed, enables Claude
    vision for image description (standalone images and embedded images in
    PDF/DOCX). If not set, MarkItDown runs without LLM — images are skipped
    or produce empty descriptions.
    """
    from markitdown import MarkItDown

    anthropic_api_key = os.environ.get("ANTHROPIC_API_KEY", "")
    if anthropic_api_key:
        try:
            import anthropic
            client = anthropic.Anthropic(api_key=anthropic_api_key)
            return MarkItDown(llm_client=client, llm_model="claude-sonnet-4-5")
        except ImportError:
            pass  # anthropic not installed, fall through

    return MarkItDown()


_IMAGE_EXTENSIONS = {".jpg", ".jpeg", ".png", ".gif", ".webp"}


def _convert_to_markdown(path: Path) -> str:
    """
    Convert a file to markdown.

    - Plain text / markdown / code → returned as-is, no conversion needed.
    - Documents (PDF, DOCX, XLSX, PPTX, etc.) → converted via MarkItDown.
      Embedded images are described via Claude vision if ANTHROPIC_API_KEY is set.
    - Standalone images → described via Claude vision if ANTHROPIC_API_KEY is set.
      If not set, returns a placeholder instead of crashing.
    - Unknown binary → raises RuntimeError.
    """
    suffix = path.suffix.lower()
    log.debug("Converting %s (suffix=%s)", path.name, suffix or "(none)")

    # ── plain text: return as-is ──────────────────────────────────────────────
    if suffix in _PLAIN_EXTENSIONS:
        try:
            return path.read_text(encoding="utf-8")
        except UnicodeDecodeError as e:
            raise RuntimeError(
                f"{path.name} is not valid UTF-8 ({e}). "
                "Re-save the file as UTF-8."
            ) from e

    # ── ensure markitdown is available ────────────────────────────────────────
    try:
        from markitdown import MarkItDown  # noqa: F401
    except ImportError:
        raise RuntimeError(
            "markitdown is not installed.\n"
            "Run: pip install llm-wiki-tools"
        )

    # ── standalone images: require vision ────────────────────────────────────
    if suffix in _IMAGE_EXTENSIONS:
        if not os.environ.get("ANTHROPIC_API_KEY", ""):
            return (
                f"[Image: {path.name}]\n"
                f"_Vision description unavailable — set ANTHROPIC_API_KEY to enable._"
            )

    # ── documents and images: convert via MarkItDown ──────────────────────────
    if suffix in _CONVERT_EXTENSIONS:
        try:
            md = _build_markitdown()
            result = md.convert(str(path))
            text = getattr(result, "text_content", "") or ""
            if not text.strip():
                # Images without vision produce empty content — return placeholder
                if suffix in _IMAGE_EXTENSIONS:
                    return f"[Image: {path.name}]\n_No text content extracted._"
                raise RuntimeError(f"MarkItDown returned empty content for {path.name}")
            return text
        except RuntimeError:
            raise
        except Exception as e:
            raise RuntimeError(f"Conversion failed for {path.name}: {e}") from e

    # ── unknown extension: attempt plain read ─────────────────────────────────
    try:
        return path.read_text(encoding="utf-8")
    except UnicodeDecodeError:
        raise RuntimeError(
            f"Unsupported binary format: {suffix or '(no extension)'}\n"
            f"Supported formats: {sorted(_CONVERT_EXTENSIONS | _PLAIN_EXTENSIONS)}"
        )


# ── config ────────────────────────────────────────────────────────────────────

class ProjectConfig:
    def __init__(self, project_id: str, wiki_repo: str, token: str,
                 wiki_local_path: Optional[Path] = None):
        self.project_id = project_id
        self.wiki_repo = wiki_repo              # e.g. "username/wiki-my-project"
        self.token = token
        self.wiki_local_path = wiki_local_path  # Path or None


def load_config(start_dir: Optional[Path] = None) -> ProjectConfig:
    """
    Walk up from start_dir (default: cwd) looking for .project.
    GITHUB_TOKEN is always read from environment.
    wiki_local_path is optional — only needed in the wiki repo.
    """
    start = start_dir or Path.cwd()
    current = start
    while True:
        candidate = current / ".project"
        if candidate.exists():
            try:
                data = json.loads(candidate.read_text())
            except json.JSONDecodeError as e:
                raise RuntimeError(
                    f".project is not valid JSON ({candidate}): {e}\n"
                    "Fix the syntax in your .project file."
                ) from e
            if not isinstance(data, dict):
                raise RuntimeError(
                    f".project must be a JSON object ({candidate})."
                )
            for key in ("project_id", "wiki_repo"):
                if not data.get(key):
                    raise RuntimeError(
                        f".project is missing required key '{key}' ({candidate})."
                    )
            token = os.environ.get("GITHUB_TOKEN", "")
            if not token:
                raise EnvironmentError(
                    "GITHUB_TOKEN is not set.\n"
                    "Add this to your ~/.zshrc or ~/.bashrc:\n"
                    "  export GITHUB_TOKEN=ghp_yourtoken"
                )
            # wiki_local_path is validated lazily in _require_local() so a
            # stale path never breaks wiki-read, which has no use for it.
            local_path = None
            if data.get("wiki_local_path"):
                local_path = Path(data["wiki_local_path"]).expanduser().resolve()
            return ProjectConfig(
                project_id=data["project_id"],
                wiki_repo=data["wiki_repo"],
                token=token,
                wiki_local_path=local_path,
            )
        parent = current.parent
        if parent == current:
            raise FileNotFoundError(
                f".project not found (started from {start}).\n"
                "Make sure you are inside a project directory."
            )
        current = parent


# ── GitHub client ─────────────────────────────────────────────────────────────

class GitHubAPIError(RuntimeError):
    """A GitHub REST API call returned a non-2xx status.

    Carries the HTTP ``status`` so callers can distinguish a legitimate 404
    (resource absent) from auth/server errors that must not be swallowed.
    """

    def __init__(self, status: int, body: str):
        self.status = status
        super().__init__(f"GitHub API {status}: {body}")


class GitHubClient:
    BASE = "https://api.github.com"

    def __init__(self, config: ProjectConfig):
        self.config = config
        self.headers = {
            "Authorization": f"Bearer {config.token}",
            "Accept": "application/vnd.github+json",
            "X-GitHub-Api-Version": "2022-11-28",
            "Content-Type": "application/json",
        }

    # ── GitHub API ────────────────────────────────────────────────────────────

    def _request(self, method: str, path: str, body: Optional[dict] = None) -> dict:
        url = f"{self.BASE}{path}"
        data = json.dumps(body).encode() if body else None

        for attempt in range(1, _MAX_ATTEMPTS + 1):
            req = urllib.request.Request(
                url, data=data, headers=self.headers, method=method
            )
            log.debug("GitHub %s %s (attempt %d)", method, path, attempt)
            try:
                with urllib.request.urlopen(req) as resp:
                    return json.loads(resp.read())
            except urllib.error.HTTPError as e:
                body_text = e.read().decode(errors="replace")
                rate_limited = (
                    e.code in (403, 429)
                    and e.headers.get("X-RateLimit-Remaining") == "0"
                )
                transient = e.code in _RETRY_STATUSES or rate_limited
                if transient and attempt < _MAX_ATTEMPTS:
                    delay = self._retry_delay(attempt, e.headers)
                    log.warning(
                        "GitHub %s %s -> %d, retrying in %.1fs",
                        method, path, e.code, delay,
                    )
                    time.sleep(delay)
                    continue
                raise GitHubAPIError(e.code, body_text)
            except urllib.error.URLError as e:
                if attempt < _MAX_ATTEMPTS:
                    delay = self._retry_delay(attempt, None)
                    log.warning(
                        "Network error on %s %s (%s), retrying in %.1fs",
                        method, path, e.reason, delay,
                    )
                    time.sleep(delay)
                    continue
                raise RuntimeError(
                    f"Network error contacting GitHub: {e.reason}\n"
                    "Check your internet connection and that api.github.com is reachable."
                ) from e

    @staticmethod
    def _retry_delay(attempt: int, headers) -> float:
        """Exponential backoff with jitter; honor Retry-After when present."""
        if headers is not None:
            retry_after = headers.get("Retry-After")
            if retry_after and retry_after.isdigit():
                return min(float(retry_after), 60.0)
        return min(2.0 ** (attempt - 1), 30.0) + random.uniform(0, 0.5)

    def _get_sha(self, path: str) -> Optional[str]:
        try:
            return self._request("GET", path).get("sha")
        except GitHubAPIError as e:
            if e.status == 404:
                return None
            raise

    # ── wiki/ — always on GitHub ──────────────────────────────────────────────

    def read_page(self, page: str) -> str:
        """Read a wiki page from GitHub."""
        page = _md(page)
        resp = self._request("GET", f"/repos/{self.config.wiki_repo}/contents/wiki/{page}")
        if isinstance(resp, list):
            raise RuntimeError(f"'{page}' is a directory, not a wiki page.")
        if resp.get("encoding") != "base64" or not resp.get("content"):
            raise RuntimeError(
                f"Cannot read '{page}': content is not available "
                "(the page may be larger than the GitHub Contents API 1MB limit)."
            )
        return base64.b64decode(resp["content"]).decode(errors="replace")

    def write_page(self, page: str, content: str, message: str = "") -> None:
        """Create or update a wiki page on GitHub."""
        page = _md(page)
        path = f"/repos/{self.config.wiki_repo}/contents/wiki/{page}"
        sha = self._get_sha(path)
        body: dict = {
            "message": message or f"wiki: update {page}",
            "content": base64.b64encode(content.encode()).decode(),
        }
        if sha:
            body["sha"] = sha
        self._request("PUT", path, body)

    def delete_page(self, page: str, message: str = "") -> None:
        """Delete a wiki page from GitHub. Raises RuntimeError if page does not exist."""
        page = _md(page)
        path = f"/repos/{self.config.wiki_repo}/contents/wiki/{page}"
        sha = self._get_sha(path)
        if not sha:
            raise RuntimeError(
                f"Page not found: {page}\n"
                f"Run `wiki-manage status` to see existing pages."
            )
        self._request("DELETE", path, {
            "message": message or f"wiki: delete {page}",
            "sha": sha,
        })

    def list_pages(self) -> list:
        """List all pages in wiki/ on GitHub."""
        path = f"/repos/{self.config.wiki_repo}/contents/wiki"
        try:
            return [f["name"] for f in self._request("GET", path) if f["name"].endswith(".md")]
        except GitHubAPIError as e:
            if e.status == 404:
                return []
            raise

    def search_pages(self, query: str) -> list:
        """Full-text search across wiki pages on GitHub. Returns [{page, excerpt}]."""
        results = []
        q = query.lower()
        for page in self.list_pages():
            try:
                content = self.read_page(page)
            except Exception:
                continue
            if q in content.lower():
                for line in content.splitlines():
                    if q in line.lower():
                        results.append({"page": page, "excerpt": line.strip()})
                        break
        return results

    # ── raw/ — local disk, auto-converted to markdown ─────────────────────────

    def _require_local(self) -> Path:
        """Raise a clear error if wiki_local_path is not configured."""
        if not self.config.wiki_local_path:
            raise RuntimeError(
                "wiki_local_path is not set in .project.\n"
                "This command requires access to local raw/ and updates/ folders.\n"
                "Add wiki_local_path to your .project file:\n"
                '  "wiki_local_path": "/path/to/wiki-repo"'
            )
        if not self.config.wiki_local_path.exists():
            raise RuntimeError(
                f"wiki_local_path does not exist: {self.config.wiki_local_path}\n"
                "Update the path in your .project file."
            )
        return self.config.wiki_local_path

    def list_raw(self) -> list:
        """List all files in local raw/ (excluding .gitkeep)."""
        raw_dir = self._require_local() / "raw"
        if not raw_dir.exists():
            return []
        return [
            f.name for f in sorted(raw_dir.iterdir())
            if f.is_file() and f.name != ".gitkeep"
        ]

    def read_raw(self, filename: str) -> str:
        """
        Read and convert a file from local raw/ to markdown.
        Plain text and markdown files are returned as-is.
        Binary formats (PDF, DOCX, etc.) are converted via MarkItDown.
        """
        path = self._require_local() / "raw" / _safe_name(filename)
        return _convert_to_markdown(path)

    # ── updates/ — local disk, auto-converted to markdown ─────────────────────

    def list_updates(self) -> list:
        """List all files in local updates/ (excluding .gitkeep)."""
        updates_dir = self._require_local() / "updates"
        if not updates_dir.exists():
            return []
        return [
            f.name for f in sorted(updates_dir.iterdir())
            if f.is_file() and f.name != ".gitkeep"
        ]

    def read_update(self, filename: str) -> str:
        """
        Read and convert a file from local updates/ to markdown.
        Plain text and markdown files are returned as-is.
        Binary formats (PDF, DOCX, etc.) are converted via MarkItDown.
        """
        path = self._require_local() / "updates" / _safe_name(filename)
        return _convert_to_markdown(path)

    def move_update_to_raw(self, filename: str) -> None:
        """Move a file from local updates/ to local raw/."""
        local = self._require_local()
        filename = _safe_name(filename)
        src = local / "updates" / filename
        dst = local / "raw" / filename
        dst.parent.mkdir(parents=True, exist_ok=True)
        log.debug("Moving %s: updates/ -> raw/", filename)
        shutil.move(str(src), str(dst))


def _safe_name(name: str) -> str:
    """Reject path separators and traversal so a filename stays within its folder."""
    name = (name or "").strip()
    if not name:
        raise RuntimeError("Empty filename.")
    if "/" in name or "\\" in name or name in (".", "..") or ".." in Path(name).parts:
        raise RuntimeError(
            f"Invalid filename '{name}': must not contain path separators or '..'."
        )
    return name


def _md(page: str) -> str:
    """Ensure page name ends with .md (path-safe)."""
    page = _safe_name(page)
    return page if page.endswith(".md") else f"{page}.md"