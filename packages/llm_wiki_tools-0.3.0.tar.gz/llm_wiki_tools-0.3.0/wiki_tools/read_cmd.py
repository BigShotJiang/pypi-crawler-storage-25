"""
wiki-read — read wiki pages from GitHub.

Usage:
  wiki-read <page>               print page content (with or without .md)
  wiki-read --list               list all wiki pages
  wiki-read --search <query>     full-text search across pages
  wiki-read --info               show current project info
"""

import sys
from .github_client import load_config, GitHubClient, configure_logging


def main():
    args = sys.argv[1:]

    verbose = "--verbose" in args
    args = [a for a in args if a != "--verbose"]
    configure_logging(verbose)

    if not args:
        print(__doc__)
        sys.exit(0)

    try:
        config = load_config()
        gh = GitHubClient(config)
    except (FileNotFoundError, EnvironmentError, RuntimeError, ValueError) as e:
        print(f"ERROR: {e}", file=sys.stderr)
        sys.exit(1)

    cmd = args[0]

    if cmd == "--list":
        try:
            pages = gh.list_pages()
        except RuntimeError as e:
            print(f"ERROR: {e}", file=sys.stderr)
            sys.exit(1)
        if not pages:
            print("No pages found in wiki/")
        else:
            for p in sorted(pages):
                print(p)

    elif cmd == "--search":
        if len(args) < 2:
            print("Usage: wiki-read --search <query>", file=sys.stderr)
            sys.exit(1)
        query = " ".join(args[1:])
        try:
            results = gh.search_pages(query)
        except RuntimeError as e:
            print(f"ERROR: {e}", file=sys.stderr)
            sys.exit(1)
        if not results:
            print(f"No results for '{query}'")
        else:
            for r in results:
                print(f"[{r['page']}] {r['excerpt']}")

    elif cmd == "--info":
        print(f"project : {config.project_id}")
        print(f"repo    : {config.wiki_repo}")
        if config.wiki_local_path:
            print(f"local   : {config.wiki_local_path}")

    else:
        try:
            print(gh.read_page(cmd))
        except RuntimeError as e:
            print(f"ERROR: {e}", file=sys.stderr)
            sys.exit(1)


if __name__ == "__main__":
    main()