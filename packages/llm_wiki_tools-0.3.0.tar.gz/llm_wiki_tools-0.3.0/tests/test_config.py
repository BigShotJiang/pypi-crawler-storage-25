import json

import pytest

from wiki_tools.github_client import load_config, GitHubClient


def write_project(dir_path, data):
    (dir_path / ".project").write_text(json.dumps(data))


def test_walk_up_discovery(tmp_path, monkeypatch):
    monkeypatch.setenv("GITHUB_TOKEN", "tok")
    write_project(tmp_path, {"project_id": "p", "wiki_repo": "u/wiki-p"})
    sub = tmp_path / "a" / "b"
    sub.mkdir(parents=True)
    cfg = load_config(start_dir=sub)
    assert cfg.project_id == "p"
    assert cfg.wiki_repo == "u/wiki-p"
    assert cfg.wiki_local_path is None


def test_missing_token(tmp_path):
    write_project(tmp_path, {"project_id": "p", "wiki_repo": "u/wiki-p"})
    with pytest.raises(EnvironmentError):
        load_config(start_dir=tmp_path)


def test_no_project_file(tmp_path, monkeypatch):
    monkeypatch.setenv("GITHUB_TOKEN", "tok")
    with pytest.raises(FileNotFoundError):
        load_config(start_dir=tmp_path)


def test_malformed_json(tmp_path, monkeypatch):
    monkeypatch.setenv("GITHUB_TOKEN", "tok")
    (tmp_path / ".project").write_text("{ not json")
    with pytest.raises(RuntimeError, match="not valid JSON"):
        load_config(start_dir=tmp_path)


def test_missing_required_key(tmp_path, monkeypatch):
    monkeypatch.setenv("GITHUB_TOKEN", "tok")
    write_project(tmp_path, {"project_id": "p"})
    with pytest.raises(RuntimeError, match="missing required key 'wiki_repo'"):
        load_config(start_dir=tmp_path)


def test_stale_local_path_does_not_break_load(tmp_path, monkeypatch):
    """M2: a stale wiki_local_path must not break load_config (wiki-read)."""
    monkeypatch.setenv("GITHUB_TOKEN", "tok")
    write_project(tmp_path, {
        "project_id": "p",
        "wiki_repo": "u/wiki-p",
        "wiki_local_path": str(tmp_path / "does-not-exist"),
    })
    cfg = load_config(start_dir=tmp_path)  # must not raise
    assert cfg.wiki_local_path is not None


def test_stale_local_path_fails_lazily(tmp_path, monkeypatch):
    """M2: the error surfaces only when a local op actually needs the path."""
    monkeypatch.setenv("GITHUB_TOKEN", "tok")
    write_project(tmp_path, {
        "project_id": "p",
        "wiki_repo": "u/wiki-p",
        "wiki_local_path": str(tmp_path / "nope"),
    })
    cfg = load_config(start_dir=tmp_path)
    gh = GitHubClient(cfg)
    with pytest.raises(RuntimeError, match="does not exist"):
        gh.list_raw()
