import urllib.error

import pytest

from wiki_tools import github_client as gc
from wiki_tools.github_client import GitHubClient, ProjectConfig, GitHubAPIError
from conftest import make_http_error, make_ok


def make_client():
    return GitHubClient(ProjectConfig("p", "u/wiki-p", "tok"))


def test_get_sha_swallows_only_404(monkeypatch):
    gh = make_client()
    monkeypatch.setattr(gc.urllib.request, "urlopen",
                         lambda req: (_ for _ in ()).throw(make_http_error(404)))
    assert gh._get_sha("/x") is None


def test_get_sha_propagates_401(monkeypatch):
    """C2: an auth error must NOT be swallowed as 'absent'."""
    gh = make_client()
    monkeypatch.setattr(gc.urllib.request, "urlopen",
                         lambda req: (_ for _ in ()).throw(make_http_error(401)))
    with pytest.raises(GitHubAPIError) as ei:
        gh._get_sha("/x")
    assert ei.value.status == 401


def test_list_pages_propagates_401(monkeypatch):
    """C2: list_pages must not report an empty wiki on auth failure."""
    gh = make_client()
    monkeypatch.setattr(gc.urllib.request, "urlopen",
                         lambda req: (_ for _ in ()).throw(make_http_error(401)))
    with pytest.raises(GitHubAPIError):
        gh.list_pages()


def test_list_pages_empty_on_404(monkeypatch):
    gh = make_client()
    monkeypatch.setattr(gc.urllib.request, "urlopen",
                         lambda req: (_ for _ in ()).throw(make_http_error(404)))
    assert gh.list_pages() == []


def test_urlerror_becomes_clear_runtime_error(monkeypatch):
    """C1: a network error is wrapped, not raised as a raw traceback."""
    gh = make_client()
    monkeypatch.setattr(gc, "_MAX_ATTEMPTS", 1)
    monkeypatch.setattr(gc.urllib.request, "urlopen",
                         lambda req: (_ for _ in ()).throw(urllib.error.URLError("dns fail")))
    with pytest.raises(RuntimeError, match="Network error contacting GitHub"):
        gh._request("GET", "/x")


def test_retry_then_success(monkeypatch):
    """R2: a transient 503 is retried and then succeeds."""
    gh = make_client()
    monkeypatch.setattr(gc.time, "sleep", lambda _: None)
    calls = {"n": 0}

    def fake_urlopen(req):
        calls["n"] += 1
        if calls["n"] == 1:
            raise make_http_error(503)
        return make_ok({"ok": True})

    monkeypatch.setattr(gc.urllib.request, "urlopen", fake_urlopen)
    assert gh._request("GET", "/x") == {"ok": True}
    assert calls["n"] == 2


def test_no_retry_on_404(monkeypatch):
    gh = make_client()
    monkeypatch.setattr(gc.time, "sleep", lambda _: None)
    calls = {"n": 0}

    def fake_urlopen(req):
        calls["n"] += 1
        raise make_http_error(404)

    monkeypatch.setattr(gc.urllib.request, "urlopen", fake_urlopen)
    with pytest.raises(GitHubAPIError):
        gh._request("GET", "/x")
    assert calls["n"] == 1


def test_read_page_rejects_directory(monkeypatch):
    """M4: a path resolving to a directory raises a clear error."""
    gh = make_client()
    monkeypatch.setattr(gc.urllib.request, "urlopen",
                        lambda req: make_ok([{"name": "a.md"}]))
    with pytest.raises(RuntimeError, match="is a directory"):
        gh.read_page("somedir")


def test_read_page_rejects_oversized(monkeypatch):
    """M4: >1MB pages (encoding 'none') raise instead of returning empty."""
    gh = make_client()
    monkeypatch.setattr(gc.urllib.request, "urlopen",
                        lambda req: make_ok({"encoding": "none", "content": ""}))
    with pytest.raises(RuntimeError, match="1MB limit"):
        gh.read_page("big")
