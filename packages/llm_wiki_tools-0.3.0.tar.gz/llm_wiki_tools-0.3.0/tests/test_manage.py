import pytest

from wiki_tools import manage_cmd


class FakeGH:
    def __init__(self, updates=None, pages=None, page_content=None, bad=()):
        self._updates = updates or []
        self._pages = pages or []
        self._content = page_content or {}
        self._bad = set(bad)
        self.moved = []

    def list_updates(self):
        return list(self._updates)

    def list_pages(self):
        return list(self._pages)

    def read_update(self, fn):
        if fn in self._bad:
            raise RuntimeError(f"cannot read {fn}")
        return f"content of {fn}"

    def read_page(self, page):
        return self._content.get(page, "")

    def move_update_to_raw(self, fn):
        self.moved.append(fn)


def test_failed_update_file_not_moved(capsys):
    """C3: a file that failed to read stays in updates/ (not moved to raw/)."""
    gh = FakeGH(updates=["good.txt", "bad.bin"], pages=["index.md"], bad=["bad.bin"])
    manage_cmd.cmd_update(gh)
    assert gh.moved == ["good.txt"]
    err = capsys.readouterr().err
    assert "bad.bin" in err


def test_all_good_files_moved(capsys):
    gh = FakeGH(updates=["a.txt", "b.txt"], pages=["index.md"])
    manage_cmd.cmd_update(gh)
    assert sorted(gh.moved) == ["a.txt", "b.txt"]


def test_lint_changelog_not_orphan(capsys):
    """M7: required pages are never reported as orphans."""
    gh = FakeGH(
        pages=["index.md", "changelog.md"],
        page_content={"index.md": "# Index\n", "changelog.md": "# Changelog\n"},
    )
    manage_cmd.cmd_lint(gh)
    out = capsys.readouterr().out
    assert "ORPHAN" not in out
    assert "no issues found" in out


def test_lint_detects_broken_link(capsys):
    gh = FakeGH(
        pages=["index.md", "changelog.md"],
        page_content={
            "index.md": "See [Gone](gone.md)\n",
            "changelog.md": "# Changelog\n",
        },
    )
    manage_cmd.cmd_lint(gh)
    out = capsys.readouterr().out
    assert "gone.md" in out


def test_lint_detects_orphan_dynamic_page(capsys):
    gh = FakeGH(
        pages=["index.md", "changelog.md", "lonely.md"],
        page_content={
            "index.md": "[Changelog](changelog.md)\n",
            "changelog.md": "# Changelog\n",
            "lonely.md": "nobody links me\n",
        },
    )
    manage_cmd.cmd_lint(gh)
    out = capsys.readouterr().out
    assert "ORPHAN PAGE (not linked from anywhere): lonely.md" in out
