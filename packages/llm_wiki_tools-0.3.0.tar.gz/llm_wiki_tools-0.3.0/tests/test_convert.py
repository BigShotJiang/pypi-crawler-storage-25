import pytest

from wiki_tools import github_client as gc
from wiki_tools.github_client import (
    _convert_to_markdown,
    _md,
    _safe_name,
    _IMAGE_EXTENSIONS,
    _CONVERT_EXTENSIONS,
)


def test_image_extensions_subset_of_convert():
    """Invariant: every image ext must also be a convertible ext."""
    assert _IMAGE_EXTENSIONS <= _CONVERT_EXTENSIONS


def test_plain_text_returned_as_is(tmp_path):
    f = tmp_path / "doc.md"
    f.write_text("# hello")
    assert _convert_to_markdown(f) == "# hello"


def test_plain_text_non_utf8(tmp_path):
    """M5: a non-UTF8 plain file raises a clear error, not a raw traceback."""
    f = tmp_path / "bad.py"
    f.write_bytes(b"\xff\xfe invalid")
    with pytest.raises(RuntimeError, match="not valid UTF-8"):
        _convert_to_markdown(f)


def test_standalone_image_without_key_returns_placeholder(tmp_path):
    f = tmp_path / "pic.png"
    f.write_bytes(b"\x89PNG fake")
    out = _convert_to_markdown(f)
    assert "[Image: pic.png]" in out
    assert "ANTHROPIC_API_KEY" in out


def test_unknown_binary_extension(tmp_path):
    f = tmp_path / "blob.bin"
    f.write_bytes(b"\x00\x01\x02\xff")
    with pytest.raises(RuntimeError, match="Unsupported binary format"):
        _convert_to_markdown(f)


def test_document_uses_markitdown(tmp_path, monkeypatch):
    f = tmp_path / "report.pdf"
    f.write_bytes(b"%PDF-1.4 fake")

    class FakeResult:
        text_content = "converted text"

    class FakeMD:
        def convert(self, _):
            return FakeResult()

    monkeypatch.setattr(gc, "_build_markitdown", lambda: FakeMD())
    assert _convert_to_markdown(f) == "converted text"


def test_md_normalizes_and_is_path_safe():
    assert _md("index") == "index.md"
    assert _md("index.md") == "index.md"
    with pytest.raises(RuntimeError, match="path separators"):
        _md("../../etc/passwd")


def test_safe_name_rejects_traversal():
    assert _safe_name("file.txt") == "file.txt"
    for bad in ("../x", "a/b", "..", ""):
        with pytest.raises(RuntimeError):
            _safe_name(bad)
