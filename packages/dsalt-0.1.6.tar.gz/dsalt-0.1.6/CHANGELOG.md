# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

### Added
- Initial release of DSALT (Dynamic Sparse Attention with Landmark Tokens)
- Triton-accelerated sparse attention kernels
- Dynamic window sizing with learned predictors
- Hybrid energy-based landmark token selection
- Complete transformer implementation with DSALTAttention
- Language model wrapper (DSALTLMHeadModel)
- Training harness with mixed precision and DDP support
- Comprehensive test suite
- Documentation and examples

### Changed
- Migrated to modern Python packaging with pyproject.toml

### Fixed
- Various bug fixes in attention kernels and training loop

## [0.1.0] - 2024-05-02

### Added
- Core DSALT implementation
- Basic training infrastructure
- CPU fallback for attention kernels
- Initial test coverage