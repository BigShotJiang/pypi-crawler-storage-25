from setuptools import setup, find_packages

setup(
    name="holmes-bci",
    version="1.1.0",
    author="Toki Tahmid Ornob",
    description="A Domain-Specific Language for Brain-Computer Interfaces.",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.6',
    entry_points={
        'console_scripts': [
            'holmes=holmes_bci.__main__:main',
        ],
    },
)
