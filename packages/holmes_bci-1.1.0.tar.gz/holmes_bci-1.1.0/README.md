# Holmes BCI Language
The HTML of Brain-Computer Interfaces. Designed for IntelliScript BD.

### Installation
`pip install holmes-bci`

### Usage
`holmes compile my_script.bci`
