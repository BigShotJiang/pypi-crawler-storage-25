import re

def tokenize(code):
    rules = [
        ('COMMENT',    r'//.*'),
        ('STRING',     r'"[^"]*"'),
        ('KEYWORD',    r'\b(stream|electrode|actuator|Pin|when|trigger|buffer|import|model|Load|TRUE|FALSE)\b'),
        ('PROPERTY',   r'\b(amplitude|frequency|raw_val|average|is_word_ready|text|direction|dominance)\b'),
        ('METHOD',     r'\b(move|stop|pulse|speak|write)\b'),
        ('VALUE_UNIT', r'\b\d+(\.\d+)?[a-zA-Z]+\b'),
        ('NUMBER',     r'\b\d+(\.\d+)?\b'),
        ('IDENTIFIER', r'\b[a-zA-Z_][a-zA-Z0-9_]*\b'),
        ('OP_PIPE',    r'>>'),
        ('OP_COMPARE', r'>=|<=|==|>|<'),
        ('OP_ASSIGN',  r'='),
        ('OP_MATH',    r'[\+\-\*/]'),
        ('PAREN_L',    r'\('),
        ('PAREN_R',    r'\)'),
        ('COLON',      r':'),
        ('DOT',        r'\.'),
        ('WHITESPACE', r'[ \t\n\r]+'),
        ('MISMATCH',   r'.')
    ]
    
    tokens_join = '|'.join('(?P<%s>%s)' % pair for pair in rules)
    tokens = []
    line_starts = [0] + [m.end() for m in re.finditer(r'\n', code)]
    
    def get_line_col(pos):
        line = 1
        for i, start in enumerate(line_starts):
            if pos >= start: line = i + 1
            else: break
        col = pos - line_starts[line-1] + 1
        return line, col

    for mo in re.finditer(tokens_join, code):
        kind = mo.lastgroup
        value = mo.group()
        pos = mo.start()
        line, col = get_line_col(pos)
        
        if kind in ['WHITESPACE', 'COMMENT']: continue
        elif kind == 'MISMATCH':
            raise RuntimeError(f"\n[LEXICAL ERROR] Unexpected character '{value}' at Line {line}, Col {col}")
        else:
            tokens.append({'type': kind, 'value': value, 'line': line, 'col': col})
    return tokens
