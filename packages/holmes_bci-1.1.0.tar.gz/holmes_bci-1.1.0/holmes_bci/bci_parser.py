import sys
import json
from .bci_lexer import tokenize

def format_error(code, msg, line, col):
    lines = code.split('\n')
    err_line = lines[line - 1] if line <= len(lines) else ""
    pointer = " " * (col - 1) + "^"
    return f"\n[SYNTAX ERROR] {msg}\nLine {line}, Column {col}:\n    {err_line}\n    {pointer}\n"

class Parser:
    def __init__(self, tokens, code):
        self.tokens = tokens
        self.code = code
        self.pos = 0

    def current_token(self):
        return self.tokens[self.pos] if self.pos < len(self.tokens) else None

    def error(self, msg, token=None):
        if token:
            line, col = token['line'], token['col']
        else:
            if self.tokens:
                last = self.tokens[-1]
                line, col = last['line'], last['col'] + len(last['value'])
            else:
                line, col = 1, 1
        raise SyntaxError(format_error(self.code, msg, line, col))

    def consume(self, expected_type=None):
        token = self.current_token()
        if not token: self.error(f"Unexpected end of file. Expected {expected_type}")
        if expected_type is None or token['type'] == expected_type:
            self.pos += 1
            return token
        self.error(f"Expected {expected_type}, got {token['type']} ('{token['value']}')", token)

    def parse(self):
        ast = {"Program": []}
        while self.pos < len(self.tokens):
            token = self.current_token()
            if token['value'] in ['electrode', 'actuator']:
                ast["Program"].append(self.parse_hardware_decl())
            elif token['value'] == 'import':
                ast["Program"].append(self.parse_import_decl())
            elif token['value'] == 'model':
                ast["Program"].append(self.parse_model_decl())
            elif token['value'] == 'stream':
                ast["Program"].append(self.parse_pipeline_decl())
            elif token['value'] == 'buffer':
                ast["Program"].append(self.parse_memory_decl())
            elif token['value'] == 'when':
                ast["Program"].append(self.parse_reactive_block())
            else:
                self.error(f"Unexpected token at root: '{token['value']}'", token)
        return ast

    def parse_hardware_decl(self):
        hw_type = self.consume('KEYWORD')['value']
        name = self.consume('IDENTIFIER')['value']
        self.consume('OP_ASSIGN')
        self.consume('KEYWORD') # Pin
        self.consume('PAREN_L')
        
        pin_token = self.current_token()
        if not pin_token: self.error("Expected IDENTIFIER or NUMBER for Pin")
        if pin_token['type'] in ['IDENTIFIER', 'NUMBER']:
            pin_id = self.consume()['value']
        else:
            self.error(f"Expected IDENTIFIER or NUMBER for Pin, got {pin_token['type']}", pin_token)
            
        self.consume('PAREN_R')
        return {"HardwareDeclaration": {"Type": hw_type, "Name": name, "Pin": pin_id}}

    def parse_import_decl(self):
        self.consume('KEYWORD') # consume 'import'
        module_name = self.consume('IDENTIFIER')['value']
        return {"ImportDeclaration": {"Module": module_name}}

    def parse_model_decl(self):
        self.consume('KEYWORD') # model
        name = self.consume('IDENTIFIER')['value']
        self.consume('OP_ASSIGN')
        self.consume('KEYWORD') # Load
        self.consume('PAREN_L')
        file_name = self.consume('STRING')['value']
        self.consume('PAREN_R')
        return {"ModelDeclaration": {"Name": name, "File": file_name.strip('"')}}

    def parse_pipeline_decl(self):
        self.consume('KEYWORD') # stream
        name = self.consume('IDENTIFIER')['value']
        self.consume('OP_ASSIGN')
        source = self.consume('IDENTIFIER')['value']
        
        filters = []
        while self.current_token() and self.current_token()['type'] == 'OP_PIPE':
            self.consume('OP_PIPE')
            filter_name = self.consume('IDENTIFIER')['value']
            self.consume('PAREN_L')
            
            param_token = self.current_token()
            if param_token and param_token['type'] == 'PAREN_R':
                param = None
            else:
                if not param_token: self.error("Expected parameter in filter")
                if param_token['type'] in ['IDENTIFIER', 'VALUE_UNIT', 'NUMBER']:
                    param = self.consume()['value']
                else:
                    self.error(f"Unexpected parameter type in filter", param_token)
                
            self.consume('PAREN_R')
            filters.append({"Filter": filter_name, "Parameter": param})
            
        return {"PipelineDeclaration": {"Name": name, "Source": source, "Filters": filters}}

    def parse_memory_decl(self):
        self.consume('KEYWORD') # buffer
        name = self.consume('IDENTIFIER')['value']
        self.consume('OP_ASSIGN')
        target = self.consume('IDENTIFIER')['value']
        self.consume('DOT')
        prop = self.consume('PROPERTY')['value']
        self.consume('PAREN_L')
        size = self.consume('NUMBER')['value']
        self.consume('PAREN_R')
        return {"MemoryDeclaration": {"Name": name, "Target": target, "Property": prop, "Size": int(size)}}

    def parse_reactive_block(self):
        self.consume('KEYWORD') # when
        target = self.consume('IDENTIFIER')['value']
        self.consume('DOT')
        prop = self.consume('PROPERTY')['value']
        comp = self.consume('OP_COMPARE')['value']
        
        right_token = self.current_token()
        if right_token['type'] == 'IDENTIFIER':
            base_target = self.consume('IDENTIFIER')['value']
            self.consume('DOT')
            base_prop = self.consume('PROPERTY')['value']
            math_op = self.consume('OP_MATH')['value']
            math_val = self.consume('NUMBER')['value']
            threshold = {"Type": "Dynamic", "Target": base_target, "Property": base_prop, "MathOp": math_op, "Value": float(math_val)}
        elif right_token['type'] == 'KEYWORD' and right_token['value'] in ['TRUE', 'FALSE']:
            val = self.consume('KEYWORD')['value']
            threshold = {"Type": "Boolean", "Value": val}
        elif right_token['type'] == 'STRING':
            val = self.consume('STRING')['value']
            threshold = {"Type": "String", "Value": val.strip('"')}
        else:
            val = self.consume('NUMBER')['value']
            threshold = {"Type": "Static", "Value": float(val)}

        self.consume('COLON')
        self.consume('KEYWORD') # trigger
        act_target = self.consume('IDENTIFIER')['value']
        self.consume('DOT')
        method = self.consume('METHOD')['value']
        self.consume('PAREN_L')
        
        # Allow parameters like 'forward', 'inner_voice.text', or STRING literals
        param_token = self.current_token()
        if param_token and param_token['type'] == 'STRING':
            param = self.consume('STRING')['value']
        else:
            param = self.consume('IDENTIFIER')['value']
            if self.current_token() and self.current_token()['type'] == 'DOT':
                self.consume('DOT')
                param_prop = self.consume('PROPERTY')['value']
                param += "." + param_prop
            
        self.consume('PAREN_R')
        
        return {"ReactiveBlock": {"Condition": {"Target": target, "Property": prop, "Operator": comp, "Threshold": threshold}, "Action": {"Target": act_target, "Method": method, "Parameter": param}}}

if __name__ == '__main__':
    if len(sys.argv) < 2: sys.exit(1)
    try:
        with open(sys.argv[1], 'r') as file: code = file.read()
        ast = Parser(tokenize(code), code).parse()
        print(json.dumps(ast, indent=4))
    except Exception as e:
        print(e)
