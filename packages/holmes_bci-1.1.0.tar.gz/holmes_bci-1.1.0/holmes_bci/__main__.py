import sys
import os
from .bci_lexer import tokenize
from .bci_parser import Parser
from .bci_transpiler import generate_cpp

def main():
    if len(sys.argv) < 2:
        print("Holmes BCI Compiler v1.0")
        print("Usage: holmes compile <file.bci>")
        sys.exit(1)

    command = sys.argv[1]
    
    if command == "compile":
        if len(sys.argv) < 3:
            print("[ERROR] No input file specified.")
            sys.exit(1)
            
        input_file = sys.argv[2]
        print(f"[SYSTEM] Compiling {input_file}...")
        
        try:
            with open(input_file, 'r') as f:
                code = f.read()
                
            ast = Parser(tokenize(code), code).parse()
            cpp_code = generate_cpp(ast)
            
            # Save the C++ output in the same directory as the input file
            base_name = os.path.splitext(input_file)[0]
            out_name = f"{base_name}.cpp"
            
            with open(out_name, 'w') as f:
                f.write(cpp_code)
                
            print(f"[SUCCESS] Transpiled C++ saved to {out_name}")
            print("Ready for embedded GCC or Arduino IDE compilation!")
        except Exception as e:
            print(f"[COMPILATION FAILED] {e}")

if __name__ == '__main__':
    main()
