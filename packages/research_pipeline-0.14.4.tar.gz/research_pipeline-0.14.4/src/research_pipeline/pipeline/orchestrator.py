"""Pipeline orchestrator: end-to-end stage sequencing with resume support."""

from __future__ import annotations

import json
import logging
from datetime import datetime
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from research_pipeline.conversion.page_dispatch import DocumentDispatchPlan

from research_pipeline import __version__
from research_pipeline.arxiv.client import ArxivClient
from research_pipeline.arxiv.dedup import dedup_across_queries
from research_pipeline.arxiv.query_builder import build_query_from_plan
from research_pipeline.arxiv.rate_limit import ArxivRateLimiter
from research_pipeline.cli.cmd_plan import (
    _generate_query_variants,
    _split_topic_terms,
)
from research_pipeline.config.loader import load_config
from research_pipeline.config.models import PipelineConfig
from research_pipeline.conversion.base import ConverterBackend
from research_pipeline.conversion.registry import (
    _ensure_builtins_registered,
    get_backend,
)
from research_pipeline.download.pdf import download_batch
from research_pipeline.extraction.extractor import extract_from_markdown
from research_pipeline.infra.audit import AuditLogger, EventType
from research_pipeline.infra.cache import FileCache
from research_pipeline.infra.clock import date_window, utc_now
from research_pipeline.infra.eval_logging import EvalLogger
from research_pipeline.infra.http import create_session
from research_pipeline.infra.sanitize import sanitize_text
from research_pipeline.llm.providers import create_llm_provider
from research_pipeline.models.candidate import CandidateRecord
from research_pipeline.models.manifest import RunManifest, StageRecord
from research_pipeline.models.query_plan import QueryPlan
from research_pipeline.models.screening import (
    RelevanceDecision,
    parse_shortlist_lenient,
)
from research_pipeline.models.summary import PaperExtractionRecord, PaperSummary
from research_pipeline.pipeline.gates import (
    AutoApproveGate,
    CliGate,
    GateCallback,
    GateDecision,
    check_gate,
)
from research_pipeline.pipeline.topology import (
    PipelineProfile,
    classify_query_complexity,
    get_stages,
    profile_summary,
    should_run_stage,
)
from research_pipeline.screening.heuristic import score_candidates, select_topk
from research_pipeline.storage.manifests import (
    load_manifest,
    save_manifest,
    update_stage,
    write_jsonl,
)
from research_pipeline.storage.workspace import get_stage_dir, init_run
from research_pipeline.summarization.per_paper import (
    extract_paper,
    project_extraction_to_summary,
    render_extraction_markdown,
)
from research_pipeline.summarization.synthesis import (
    project_structured_synthesis_to_report,
    render_structured_synthesis_markdown,
    synthesize,
    synthesize_extractions,
)

logger = logging.getLogger(__name__)


def _create_converter(config: PipelineConfig) -> ConverterBackend:
    """Create a converter backend from pipeline config."""
    _ensure_builtins_registered()
    backend_name = config.conversion.backend
    kwargs: dict[str, object] = {}
    if backend_name == "docling":
        kwargs["timeout_seconds"] = config.conversion.timeout_seconds
    elif backend_name == "marker":
        mc = config.conversion.marker
        kwargs["force_ocr"] = mc.force_ocr
        if mc.use_llm:
            kwargs["use_llm"] = True
            if mc.llm_service:
                kwargs["llm_service"] = mc.llm_service
            if mc.llm_api_key:
                kwargs["llm_api_key"] = mc.llm_api_key
    return get_backend(backend_name, **kwargs)


def _is_stage_complete(manifest: RunManifest, stage: str) -> bool:
    """Check if a stage is already completed in the manifest."""
    record = manifest.stages.get(stage)
    return record is not None and record.status == "completed"


def _verify_plan(run_root: Path) -> list[str]:
    """Verify plan stage output is substantive.

    Returns:
        List of errors (empty if OK).
    """
    errors = []
    plan_path = get_stage_dir(run_root, "plan") / "query_plan.json"
    if not plan_path.exists():
        errors.append("query_plan.json not found")
        return errors

    try:
        data = json.loads(plan_path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError) as exc:
        errors.append(f"Cannot read query_plan.json: {exc}")
        return errors

    must = data.get("must_terms", [])
    if not must or len(must) < 1:
        errors.append("query_plan has no must_terms")

    variants = data.get("query_variants", [])
    if len(variants) < 2:
        errors.append(f"query_plan has only {len(variants)} variants (need ≥2)")

    return errors


def _verify_search(run_root: Path) -> list[str]:
    """Verify search stage output is substantive."""
    errors = []
    candidates_path = get_stage_dir(run_root, "search") / "candidates.jsonl"
    if not candidates_path.exists():
        errors.append("candidates.jsonl not found")
        return errors

    from research_pipeline.storage.manifests import read_jsonl

    records = read_jsonl(candidates_path)
    if not records:
        errors.append("candidates.jsonl is empty — no papers found")
        return errors

    # Check all records have essential fields
    missing_fields = 0
    for r in records:
        if not r.get("arxiv_id") and not r.get("title"):
            missing_fields += 1
    if missing_fields > 0:
        errors.append(f"{missing_fields} candidates missing arxiv_id or title")

    return errors


def _verify_screen(run_root: Path) -> list[str]:
    """Verify screen stage output is substantive."""
    errors = []
    screen_dir = get_stage_dir(run_root, "screen")
    shortlist_path = screen_dir / "shortlist.json"
    if not shortlist_path.exists():
        errors.append("shortlist.json not found")
        return errors

    try:
        data = json.loads(shortlist_path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError) as exc:
        errors.append(f"Cannot read shortlist.json: {exc}")
        return errors

    if not data:
        errors.append("shortlist is empty — no papers selected for download")

    return errors


def _verify_download(run_root: Path) -> list[str]:
    """Verify download stage output: PDF files exist and are non-trivial."""
    errors = []
    pdf_dir = get_stage_dir(run_root, "download")
    pdfs = list(pdf_dir.glob("*.pdf"))
    if not pdfs:
        errors.append("No PDF files found in download directory")
        return errors

    small_pdfs = [p for p in pdfs if p.stat().st_size < 10_000]
    if small_pdfs:
        errors.append(f"{len(small_pdfs)} PDF(s) smaller than 10KB (likely corrupt)")

    return errors


def _verify_convert(run_root: Path) -> list[str]:
    """Verify convert stage output: Markdown files exist and are non-empty."""
    errors = []
    md_dir = get_stage_dir(run_root, "convert")
    md_files = list(md_dir.glob("*.md"))
    if not md_files:
        errors.append("No Markdown files found in convert directory")
        return errors

    empty_mds = [m for m in md_files if m.stat().st_size < 500]
    if empty_mds:
        errors.append(
            f"{len(empty_mds)} Markdown file(s) under 500 bytes (likely empty)"
        )

    return errors


def _verify_extract(run_root: Path) -> list[str]:
    """Verify extract stage output: extraction files exist."""
    errors = []
    extract_dir = get_stage_dir(run_root, "extract")
    extract_files = list(extract_dir.glob("*.extract.json"))
    if not extract_files:
        errors.append("No extraction files found")

    return errors


def _verify_summarize(run_root: Path) -> list[str]:
    """Verify summarize stage output."""
    errors = []
    sum_dir = get_stage_dir(run_root, "summarize")
    synthesis_json = sum_dir / "synthesis.json"
    synthesis_md = sum_dir / "synthesis.md"

    if not synthesis_json.exists() and not synthesis_md.exists():
        errors.append("No synthesis output found (synthesis.json or synthesis.md)")

    return errors


STAGE_VERIFIERS: dict[str, object] = {
    "plan": _verify_plan,
    "search": _verify_search,
    "screen": _verify_screen,
    "download": _verify_download,
    "convert": _verify_convert,
    "extract": _verify_extract,
    "summarize": _verify_summarize,
}


def verify_stage(run_root: Path, stage: str) -> list[str]:
    """Run verification checks for a completed stage.

    Args:
        run_root: Root run directory.
        stage: Stage name to verify.

    Returns:
        List of verification errors (empty means OK).
    """
    verifier = STAGE_VERIFIERS.get(stage)
    if verifier is None:
        return []  # No verifier for this stage
    errors = verifier(run_root)  # type: ignore[operator]
    if errors:
        logger.warning("Verification errors for stage '%s': %s", stage, errors)
    else:
        logger.debug("Stage '%s' verified OK", stage)
    return list(errors)


def _record_stage(
    manifest: RunManifest,
    stage: str,
    status: str,
    started_at: datetime | None,
    output_paths: list[str] | None = None,
    errors: list[str] | None = None,
    audit: AuditLogger | None = None,
    run_root: Path | None = None,
) -> RunManifest:
    """Create a stage record and update the manifest.

    When *run_root* is provided, also writes an enhanced checkpoint
    JSON with timing and artifact hashes for hash-based resume.
    """
    ended = utc_now()
    started = started_at if started_at else ended
    duration = int((ended - started).total_seconds() * 1000)

    record = StageRecord(
        stage_name=stage,
        status=status,
        started_at=started,
        ended_at=ended,
        duration_ms=duration,
        output_paths=output_paths or [],
        errors=errors or [],
    )

    if audit is not None:
        event_type = (
            EventType.STAGE_COMPLETED
            if status == "completed"
            else EventType.STAGE_FAILED
        )
        audit.emit(
            event_type,
            stage=stage,
            run_id=manifest.run_id,
            details={
                "status": status,
                "duration_ms": duration,
                "output_paths": output_paths or [],
                "errors": errors or [],
            },
        )

    # Write enhanced checkpoint with artifact hashes
    if run_root is not None:
        from research_pipeline.pipeline.checkpoint import write_checkpoint

        artifact_paths = [Path(p) for p in (output_paths or [])]
        started_iso = (
            started.isoformat() if hasattr(started, "isoformat") else str(started)
        )
        write_checkpoint(
            run_root=run_root,
            stage=stage,
            status=status,
            started_at=started_iso,
            output_paths=artifact_paths,
            errors=errors,
        )

    return update_stage(manifest, record)


def _run_schema_evaluation(
    run_root: Path,
    stage: str,
    run_id: str,
    audit: AuditLogger,
) -> None:
    """Run schema-grounded evaluation for a completed stage (informational).

    Evaluation failures are logged but never block pipeline execution.
    """
    try:
        from research_pipeline.evaluation.schema_eval import evaluate_stage

        eval_report = evaluate_stage(run_root, stage)
        if not eval_report.passed:
            logger.warning("Schema evaluation: %s", eval_report.summary())
        else:
            logger.debug("Schema evaluation: %s", eval_report.summary())
        audit.emit(
            EventType.DECISION,
            run_id=run_id,
            details={
                "evaluation": eval_report.summary(),
                "errors": eval_report.error_count,
            },
        )
    except Exception as exc:
        logger.debug("Schema evaluation skipped for %s: %s", stage, exc)


def run_pipeline(
    topic: str,
    config: PipelineConfig | None = None,
    run_id: str | None = None,
    resume: bool = False,
    workspace: Path | None = None,
) -> RunManifest:
    """Execute the full pipeline from topic to synthesis.

    Args:
        topic: Research topic (natural language).
        config: Pipeline configuration. Loaded from file if not provided.
        run_id: Optional run ID for resume.
        resume: If True, skip completed stages.
        workspace: Workspace directory.

    Returns:
        Final RunManifest with all stage records.
    """
    if config is None:
        config = load_config()

    ws = workspace or Path(config.workspace)
    run_id, run_root = init_run(ws, run_id)

    # Audit trail for this run
    audit = AuditLogger(run_root)

    # Three-channel evaluation logging
    eval_log: EvalLogger | None = None
    try:
        eval_log = EvalLogger(run_root)
        logger.info("Three-channel eval logging initialized")
    except Exception as exc:
        logger.warning("Eval logging init failed: %s", exc)

    # Load or create manifest
    manifest: RunManifest | None = None
    if resume:
        manifest = load_manifest(run_root)

    if manifest is None:
        manifest = RunManifest(
            run_id=run_id,
            created_at=utc_now(),
            package_version=__version__,
            config_snapshot=config.model_dump(),
            topic_input=topic,
        )

    # Save initial config
    config_path = run_root / "run_config.json"
    config_path.write_text(
        json.dumps(config.model_dump(), indent=2, default=str),
        encoding="utf-8",
    )
    audit.emit(
        EventType.CONFIG_LOADED,
        run_id=run_id,
        details={
            "sources": config.sources.enabled,
            "backend": config.conversion.backend,
        },
    )

    # Incremental run support: global paper index
    paper_index = None
    try:
        from research_pipeline.storage.global_index import GlobalPaperIndex

        idx_path = (
            Path(config.incremental.global_index_path)
            if config.incremental.global_index_path
            else None
        )
        paper_index = GlobalPaperIndex(db_path=idx_path)
        logger.info("Global paper index loaded: %s", paper_index.db_path)
    except Exception as exc:
        logger.warning("Global paper index unavailable: %s", exc)

    # Determine pipeline profile
    profile_str = config.profile
    if profile_str == "auto":
        profile = classify_query_complexity(topic)
        logger.info("Auto-detected profile: %s", profile.value)
    else:
        try:
            profile = PipelineProfile(profile_str)
        except ValueError:
            logger.warning("Unknown profile '%s', using standard", profile_str)
            profile = PipelineProfile.STANDARD

    logger.info("Pipeline profile: %s — %s", profile.value, profile_summary(profile))
    audit.emit(
        EventType.DECISION,
        run_id=run_id,
        details={"profile": profile.value, "stages": get_stages(profile)},
    )

    # Difficulty routing analysis
    try:
        from research_pipeline.llm.difficulty_routing import (
            DifficultyRouter,
            score_difficulty,
        )

        diff_score = score_difficulty(topic)
        router = DifficultyRouter()
        routing = router.route(topic)
        diff_meta = {
            "difficulty_level": diff_score.level.value,
            "difficulty_score": diff_score.score,
            "routing_target": routing.target.value,
            "reasoning": diff_score.reasoning,
        }
        diff_path = run_root / "difficulty_analysis.json"
        diff_path.write_text(json.dumps(diff_meta, indent=2), encoding="utf-8")
        logger.info(
            "Difficulty routing: %s (%.2f) → %s",
            diff_score.level.value,
            diff_score.score,
            routing.target.value,
        )
        audit.emit(
            EventType.DECISION,
            run_id=run_id,
            details=diff_meta,
        )
    except Exception as exc:
        logger.warning("Difficulty routing skipped: %s", exc)

    # Setup shared resources
    rate_limiter = ArxivRateLimiter(min_interval=config.arxiv.min_interval_seconds)
    session = create_session(config.contact_email)
    cache: FileCache | None = None
    if config.cache.enabled:
        cache_dir = Path(config.cache.cache_dir).expanduser()
        cache = FileCache(cache_dir, ttl_hours=config.cache.search_snapshot_ttl_hours)

    arxiv_client = ArxivClient(
        rate_limiter=rate_limiter,
        cache=cache,
        session=session,
        base_url=config.arxiv.base_url,
        contact_email=config.contact_email,
        request_timeout=config.arxiv.request_timeout_seconds,
    )

    # LLM provider (None when disabled — all LLM features degrade gracefully)
    llm_provider = create_llm_provider(config.llm)

    # Human-in-the-loop gates
    gate: GateCallback
    gate_stages = config.gates.gate_after
    if config.gates.enabled and not config.gates.auto_approve:
        gate = CliGate()
        logger.info("HITL gates enabled after: %s", gate_stages)
    else:
        gate = AutoApproveGate()
    _gates_skipped = False

    # Security gate for content boundaries (optional — never crash pipeline)
    security_gate = None
    try:
        from research_pipeline.security.gates import SecurityGate

        security_gate = SecurityGate()
    except Exception as exc:
        logger.warning("Security gate init failed (continuing without): %s", exc)

    # MCP zero-trust guard (optional — never crash pipeline)
    mcp_guard = None
    try:
        from research_pipeline.security.mcp_guard import (
            CapabilityPolicy,
            McpGuard,
            ToolRegistry,
        )

        mcp_registry = ToolRegistry()
        mcp_policy = CapabilityPolicy()
        for tool_name, domain in [
            ("plan", "read"),
            ("search", "network"),
            ("screen", "read"),
            ("download", "network"),
            ("convert", "execute"),
            ("extract", "read"),
            ("summarize", "read"),
        ]:
            mcp_registry.register(
                tool_name,
                schema={"stage": tool_name},
                domain=domain,
            )
        mcp_registry.pin_all()
        mcp_policy.grant_all("pipeline")
        mcp_guard = McpGuard(mcp_registry, mcp_policy)
        logger.debug("MCP zero-trust guard initialized")
    except Exception as exc:
        logger.warning("MCP guard init failed (continuing without): %s", exc)

    # Three-tier memory (optional — failures log warning, never crash pipeline)
    memory = None
    try:
        from research_pipeline.memory.episodic import Episode
        from research_pipeline.memory.manager import MemoryManager

        memory = MemoryManager(
            working_capacity=config.memory_working_capacity,
        )
        prior = memory.prior_knowledge(topic)
        if prior["past_runs"] > 0:
            logger.info(
                "Prior knowledge: %d past runs on similar topics",
                prior["past_runs"],
            )
        audit.emit(
            EventType.DECISION,
            run_id=run_id,
            details={"prior_knowledge": prior},
        )
    except Exception as exc:
        logger.warning("Memory init failed (continuing without memory): %s", exc)
        memory = None

    # --- Stage: plan ---
    if memory:
        memory.transition_stage("plan")
    if not (resume and _is_stage_complete(manifest, "plan")):
        started = utc_now()
        logger.info("Stage: plan")
        audit.emit(EventType.STAGE_STARTED, stage="plan", run_id=run_id)
        if eval_log is not None:
            eval_log.trace("stage_started", stage="plan")
        plan_dir = get_stage_dir(run_root, "plan")

        must_terms, nice_terms = _split_topic_terms(topic)
        query_variants = _generate_query_variants(
            must_terms,
            nice_terms,
            max_variants=config.search.max_query_variants,
        )

        plan = QueryPlan(
            topic_raw=topic,
            topic_normalized=topic.lower().strip(),
            must_terms=must_terms,
            nice_terms=nice_terms,
            negative_terms=[],
            candidate_categories=[],
            query_variants=query_variants,
        )

        plan_path = plan_dir / "query_plan.json"
        plan_path.write_text(plan.model_dump_json(indent=2), encoding="utf-8")
        manifest = _record_stage(
            manifest,
            "plan",
            "completed",
            started,
            output_paths=[str(plan_path)],
            audit=audit,
            run_root=run_root,
        )
        save_manifest(run_root, manifest)
        _run_schema_evaluation(run_root, "plan", run_id, audit)
    else:
        plan_dir = get_stage_dir(run_root, "plan")
        plan_data = json.loads(
            (plan_dir / "query_plan.json").read_text(encoding="utf-8")
        )
        plan = QueryPlan.model_validate(plan_data)

    # Gate: after plan
    if not _gates_skipped:
        decision = check_gate(gate, "plan", "search", run_id, run_root, gate_stages)
        if decision is GateDecision.SKIP:
            _gates_skipped = True

    # --- Stage: search ---
    if memory:
        memory.transition_stage("search")
    if not (resume and _is_stage_complete(manifest, "search")):
        started = utc_now()
        logger.info("Stage: search")
        audit.emit(EventType.STAGE_STARTED, stage="search", run_id=run_id)
        if eval_log is not None:
            eval_log.trace("stage_started", stage="search")
        search_dir = get_stage_dir(run_root, "search")
        raw_dir = search_dir / "raw"
        raw_dir.mkdir(parents=True, exist_ok=True)

        enabled_sources = config.sources.enabled
        all_candidates: list[CandidateRecord] = []

        def _do_arxiv() -> list[CandidateRecord]:
            queries = build_query_from_plan(plan)
            date_from, date_to = date_window(plan.primary_months)
            arxiv_lists = []
            for q in queries:
                batch, _ = arxiv_client.search(
                    query=q,
                    max_results=config.arxiv.default_page_size,
                    date_from=date_from,
                    date_to=date_to,
                    save_raw_dir=raw_dir,
                )
                arxiv_lists.append(batch)
            result = dedup_across_queries(arxiv_lists)
            logger.info("arXiv: %d candidates", len(result))
            return result

        def _do_scholar() -> list[CandidateRecord]:
            backend = config.sources.scholar_backend
            if backend == "serpapi":
                from research_pipeline.sources.scholar_source import SerpAPISource

                source = SerpAPISource(
                    api_key=config.sources.serpapi_key,
                    min_interval=config.sources.serpapi_min_interval,
                )
            else:
                from research_pipeline.sources.scholar_source import ScholarlySource

                source = ScholarlySource(  # type: ignore[assignment]
                    min_interval=config.sources.scholar_min_interval,
                )
            result = source.search(
                topic=plan.topic_raw,
                must_terms=plan.must_terms,
                nice_terms=plan.nice_terms,
                max_results=min(config.arxiv.default_page_size, 20),
            )
            logger.info("Scholar (%s): %d candidates", backend, len(result))
            return result

        # Run enabled sources in parallel
        from concurrent.futures import ThreadPoolExecutor, as_completed

        def _do_semantic_scholar() -> list[CandidateRecord]:
            from research_pipeline.sources.semantic_scholar_source import (
                SemanticScholarSource,
            )

            src = SemanticScholarSource(
                api_key=config.sources.semantic_scholar_api_key,
                min_interval=config.sources.semantic_scholar_min_interval,
                session=session,
            )
            date_from, date_to = date_window(plan.primary_months)
            result = src.search(
                topic=plan.topic_raw,
                must_terms=plan.must_terms,
                nice_terms=plan.nice_terms,
                max_results=min(config.arxiv.default_page_size, 50),
                date_from=date_from,
                date_to=date_to,
            )
            logger.info("Semantic Scholar: %d candidates", len(result))
            return result

        def _do_openalex() -> list[CandidateRecord]:
            from research_pipeline.sources.openalex_source import (
                OpenAlexSource,
            )

            src = OpenAlexSource(
                api_key=config.sources.openalex_api_key,
                min_interval=config.sources.openalex_min_interval,
                session=session,
            )
            date_from, date_to = date_window(plan.primary_months)
            result = src.search(
                topic=plan.topic_raw,
                must_terms=plan.must_terms,
                nice_terms=plan.nice_terms,
                max_results=min(config.arxiv.default_page_size, 50),
                date_from=date_from,
                date_to=date_to,
            )
            logger.info("OpenAlex: %d candidates", len(result))
            return result

        def _do_dblp() -> list[CandidateRecord]:
            from research_pipeline.sources.dblp_source import DBLPSource

            src = DBLPSource(
                min_interval=config.sources.dblp_min_interval,
                session=session,
            )
            result = src.search(
                topic=plan.topic_raw,
                must_terms=plan.must_terms,
                nice_terms=plan.nice_terms,
                max_results=min(config.arxiv.default_page_size, 30),
            )
            logger.info("DBLP: %d candidates", len(result))
            return result

        def _do_huggingface() -> list[CandidateRecord]:
            from research_pipeline.sources.huggingface_source import (
                HuggingFaceSource,
            )

            src = HuggingFaceSource(
                min_interval=config.sources.huggingface_min_interval,
                limit=config.sources.huggingface_limit,
                session=session,
            )
            date_from, date_to = date_window(plan.primary_months)
            result = src.search(
                topic=plan.topic_raw,
                must_terms=plan.must_terms,
                nice_terms=plan.nice_terms,
                max_results=min(config.arxiv.default_page_size, 20),
                date_from=date_from,
                date_to=date_to,
            )
            logger.info("HuggingFace: %d candidates", len(result))
            return result

        source_dispatch = {
            "arxiv": _do_arxiv,
            "scholar": _do_scholar,
            "semantic_scholar": _do_semantic_scholar,
            "openalex": _do_openalex,
            "dblp": _do_dblp,
            "huggingface": _do_huggingface,
        }

        futures = {}
        with ThreadPoolExecutor(max_workers=len(enabled_sources)) as executor:
            for src_name in enabled_sources:
                fn = source_dispatch.get(src_name)
                if fn:
                    futures[executor.submit(fn)] = src_name
                else:
                    logger.warning("Unknown source '%s', skipping", src_name)

            for future in as_completed(futures):
                source_name = futures[future]
                try:
                    all_candidates.extend(future.result())
                except Exception as exc:
                    logger.error("%s search failed: %s", source_name, exc)

        # Cross-source dedup
        from research_pipeline.sources.base import dedup_cross_source

        candidates = dedup_cross_source(all_candidates)

        # Save candidates as JSONL
        candidates_path = search_dir / "candidates.jsonl"
        write_jsonl(
            candidates_path,
            [c.model_dump(mode="json") for c in candidates],
        )

        manifest = _record_stage(
            manifest,
            "search",
            "completed",
            started,
            output_paths=[str(candidates_path)],
            audit=audit,
            run_root=run_root,
        )
        save_manifest(run_root, manifest)
        _run_schema_evaluation(run_root, "search", run_id, audit)
    else:
        from research_pipeline.storage.manifests import read_jsonl

        search_dir = get_stage_dir(run_root, "search")
        raw_data = read_jsonl(search_dir / "candidates.jsonl")
        candidates = [CandidateRecord.model_validate(d) for d in raw_data]

    # Gate: after search
    if not _gates_skipped:
        decision = check_gate(gate, "search", "screen", run_id, run_root, gate_stages)
        if decision is GateDecision.SKIP:
            _gates_skipped = True

    # --- Stage: screen ---
    if memory:
        memory.transition_stage("screen")
    if not (resume and _is_stage_complete(manifest, "screen")):
        started = utc_now()
        logger.info("Stage: screen")
        audit.emit(EventType.STAGE_STARTED, stage="screen", run_id=run_id)
        if eval_log is not None:
            eval_log.trace(
                "stage_started",
                stage="screen",
                data={"candidates": len(candidates)},
            )
        screen_dir = get_stage_dir(run_root, "screen")

        # Security gate: classify and sanitize candidate text before scoring
        if security_gate is not None:
            for c in candidates:
                key = f"abstract:{c.arxiv_id}"
                gate_result = security_gate.check(
                    key,
                    c.abstract or "",
                    "abstract",
                    "search",
                    c.source or "arxiv",
                )
                if gate_result.sanitized:
                    c.abstract = gate_result.content
                title_result = security_gate.check(
                    f"title:{c.arxiv_id}",
                    c.title,
                    "title",
                    "search",
                    c.source or "arxiv",
                )
                if title_result.sanitized:
                    c.title = title_result.content
        else:
            # Fallback to basic sanitization
            for c in candidates:
                c.title = sanitize_text(c.title, max_length=500)
                c.abstract = sanitize_text(c.abstract, max_length=10_000)

        # Load feedback-adjusted weights if available
        feedback_weights: dict[str, float] | None = None
        try:
            from research_pipeline.feedback.store import FeedbackStore

            fb_store = FeedbackStore()
            fb_adjusted = fb_store.get_latest_weights()
            if fb_adjusted is not None and fb_adjusted.feedback_count >= 5:
                feedback_weights = fb_adjusted.to_weight_dict()
                logger.info(
                    "Using feedback-adjusted weights (%d records)",
                    fb_adjusted.feedback_count,
                )
            fb_store.close()
        except Exception as exc:
            logger.debug("Feedback weights not available: %s", exc)

        scores = score_candidates(
            candidates,
            must_terms=plan.must_terms,
            nice_terms=plan.nice_terms,
            negative_terms=plan.negative_terms,
            target_categories=plan.candidate_categories,
            weights=feedback_weights,
        )

        write_jsonl(
            screen_dir / "cheap_scores.jsonl",
            [s.model_dump(mode="json") for s in scores],
        )

        top_candidates = select_topk(
            candidates,
            scores,
            top_k=config.screen.cheap_top_k,
            diversity=config.screen.diversity,
            diversity_lambda=config.screen.diversity_lambda,
        )

        # Build shortlist
        shortlist: list[RelevanceDecision] = []
        for candidate, score in top_candidates[: config.screen.download_top_n]:
            rel_decision = RelevanceDecision(
                paper=candidate,
                cheap=score,
                llm=None,
                final_score=score.cheap_score,
                download=True,
                download_reason="score_threshold",
            )
            shortlist.append(rel_decision)

        # Optional LLM second-pass screening
        if llm_provider is not None:
            from research_pipeline.screening.llm_judge import judge_batch

            llm_candidates = [d.paper for d in shortlist]
            judgments = judge_batch(
                llm_candidates,
                topic=plan.topic_raw,
                must_terms=plan.must_terms,
                llm_provider=llm_provider,
            )
            for i, judgment in enumerate(judgments):
                if judgment is not None:
                    shortlist[i] = shortlist[i].model_copy(
                        update={
                            "llm": judgment,
                            "final_score": (
                                0.6 * shortlist[i].cheap.cheap_score
                                + 0.4 * judgment.llm_score
                            ),
                        }
                    )

        shortlist_path = screen_dir / "shortlist.json"
        shortlist_path.write_text(
            json.dumps(
                [d.model_dump(mode="json") for d in shortlist],
                indent=2,
                default=str,
            ),
            encoding="utf-8",
        )

        # Confidence-gated retrieval depth classification
        from research_pipeline.screening.depth_gate import classify_retrieval_depth

        depth_tiers = classify_retrieval_depth(shortlist)
        depth_path = screen_dir / "depth_tiers.json"
        depth_path.write_text(
            json.dumps(
                [t.model_dump(mode="json") for t in depth_tiers],
                indent=2,
                default=str,
            ),
            encoding="utf-8",
        )
        logger.info(
            "Depth tiers: %s",
            (
                {
                    t.tier: sum(1 for x in depth_tiers if x.tier == t.tier)
                    for t in depth_tiers
                }
                if depth_tiers
                else "none"
            ),
        )

        manifest = _record_stage(
            manifest,
            "screen",
            "completed",
            started,
            output_paths=[str(shortlist_path), str(depth_path)],
            audit=audit,
            run_root=run_root,
        )
        save_manifest(run_root, manifest)
        _run_schema_evaluation(run_root, "screen", run_id, audit)

        # Self-improving retrieval: refine query terms after screening
        try:
            from research_pipeline.retrieval.self_improving import (
                run_self_improving_retrieval,
            )

            sir_candidates = [d.paper for d in shortlist]
            sir_result = run_self_improving_retrieval(
                plan, sir_candidates, max_iterations=3
            )
            if sir_result.converged:
                logger.info(
                    "SIR converged after %d iterations, refined %d terms",
                    sir_result.total_iterations,
                    len(sir_result.final_query_terms),
                )
            sir_path = screen_dir / "sir_result.json"
            sir_path.write_text(
                json.dumps(
                    {
                        "total_iterations": sir_result.total_iterations,
                        "converged": sir_result.converged,
                        "final_query_terms": sir_result.final_query_terms,
                        "convergence": (
                            {
                                "reason": sir_result.convergence.reason,
                                "iterations_run": (
                                    sir_result.convergence.iterations_run
                                ),
                                "final_avg_score": (
                                    sir_result.convergence.final_avg_score
                                ),
                                "score_improvement": (
                                    sir_result.convergence.score_improvement
                                ),
                            }
                            if sir_result.convergence
                            else None
                        ),
                    },
                    indent=2,
                ),
                encoding="utf-8",
            )
        except Exception as exc:
            logger.warning("Self-improving retrieval skipped: %s", exc)
    else:
        screen_dir = get_stage_dir(run_root, "screen")
        raw_shortlist = json.loads(
            (screen_dir / "shortlist.json").read_text(encoding="utf-8")
        )
        shortlist = [parse_shortlist_lenient(d) for d in raw_shortlist]

    # Gate: after screen
    if not _gates_skipped:
        decision = check_gate(gate, "screen", "download", run_id, run_root, gate_stages)
        if decision is GateDecision.SKIP:
            _gates_skipped = True

    # --- Stage: download ---
    if memory:
        memory.transition_stage("download")
    if should_run_stage(profile, "download"):
        if not (resume and _is_stage_complete(manifest, "download")):
            started = utc_now()
            logger.info("Stage: download")
            audit.emit(EventType.STAGE_STARTED, stage="download", run_id=run_id)
            if eval_log is not None:
                eval_log.trace("stage_started", stage="download")
            pdf_dir = get_stage_dir(run_root, "download")
            pdf_dir.mkdir(parents=True, exist_ok=True)

            papers_to_download = [
                {
                    "arxiv_id": d.paper.arxiv_id,
                    "version": d.paper.version,
                    "pdf_url": d.paper.pdf_url,
                }
                for d in shortlist
                if d.download
            ]

            # Incremental: skip papers already in global index with PDFs
            skipped_ids: set[str] = set()
            if paper_index is not None:
                all_ids = [p["arxiv_id"] for p in papers_to_download]
                known = paper_index.find_known_ids(all_ids)
                reusable = []
                for pid in known:
                    artifact = paper_index.find_artifact(pid, "download")
                    if (
                        artifact
                        and artifact.get("pdf_path")
                        and Path(str(artifact["pdf_path"])).exists()
                    ):
                        reusable.append(pid)
                if reusable:
                    skipped_ids = set(reusable)
                    papers_to_download = [
                        p
                        for p in papers_to_download
                        if p["arxiv_id"] not in skipped_ids
                    ]
                    logger.info(
                        "Incremental: skipping %d already-downloaded papers",
                        len(skipped_ids),
                    )

            entries = download_batch(
                papers_to_download,
                output_dir=pdf_dir,
                session=session,
                rate_limiter=rate_limiter,
                max_downloads=config.download.max_per_run,
            )

            # Register downloaded papers in global index
            if paper_index is not None:
                for dl_entry in entries:
                    if dl_entry.status in ("downloaded", "skipped_exists"):
                        paper_index.register_paper(
                            arxiv_id=dl_entry.arxiv_id,
                            run_id=run_id,
                            stage="download",
                            pdf_path=dl_entry.local_path,
                            pdf_sha256=getattr(dl_entry, "sha256", None),
                        )

            manifest_path = (
                get_stage_dir(run_root, "download_root") / "download_manifest.jsonl"
            )
            write_jsonl(
                manifest_path,
                [e.model_dump(mode="json") for e in entries],
            )

            manifest = _record_stage(
                manifest,
                "download",
                "completed",
                started,
                output_paths=[str(manifest_path)],
                audit=audit,
                run_root=run_root,
            )
            save_manifest(run_root, manifest)
        else:
            from research_pipeline.models.download import DownloadManifestEntry
            from research_pipeline.storage.manifests import read_jsonl

            dl_data = read_jsonl(
                get_stage_dir(run_root, "download_root") / "download_manifest.jsonl"
            )
            entries = [DownloadManifestEntry.model_validate(d) for d in dl_data]
    else:
        logger.info("Skipping download stage (profile: %s)", profile.value)
        entries = []

    # Gate: after download
    if not _gates_skipped:
        decision = check_gate(
            gate, "download", "convert", run_id, run_root, gate_stages
        )
        if decision is GateDecision.SKIP:
            _gates_skipped = True

    # --- Stage: convert ---
    if memory:
        memory.transition_stage("convert")
    if should_run_stage(profile, "convert"):
        if not (resume and _is_stage_complete(manifest, "convert")):
            started = utc_now()
            logger.info("Stage: convert")
            audit.emit(EventType.STAGE_STARTED, stage="convert", run_id=run_id)
            if eval_log is not None:
                eval_log.trace("stage_started", stage="convert")
            md_dir = get_stage_dir(run_root, "convert")
            converter = _create_converter(config)

            # Page dispatch: classify PDFs by difficulty
            dispatch_plans: list[DocumentDispatchPlan] = []
            try:
                from research_pipeline.conversion.page_dispatch import (
                    classify_document_from_text,
                )

                for dl_entry in entries:
                    if dl_entry.status not in (
                        "downloaded",
                        "skipped_exists",
                    ):
                        continue
                    pdf_path = Path(dl_entry.local_path)
                    if not pdf_path.exists():
                        continue
                    try:
                        import pymupdf  # type: ignore[import-not-found]

                        doc = pymupdf.open(str(pdf_path))
                        texts = [p.get_text() for p in doc]
                        imgs = [len(p.get_images()) for p in doc]
                        doc.close()
                        dispatch_plan = classify_document_from_text(
                            pdf_path, texts, imgs
                        )
                        dispatch_plans.append(dispatch_plan)
                    except ImportError:
                        pass
                    except Exception as exc:
                        logger.debug(
                            "Page dispatch skipped for %s: %s",
                            pdf_path.name,
                            exc,
                        )

                if dispatch_plans:
                    dispatch_path = (
                        get_stage_dir(run_root, "convert_root") / "page_dispatch.json"
                    )
                    dispatch_path.parent.mkdir(parents=True, exist_ok=True)
                    dispatch_path.write_text(
                        json.dumps(
                            [
                                {
                                    "pdf": p.pdf_path,
                                    "pages": p.total_pages,
                                    "summary": p.summary,
                                    "recommended": (p.recommended_backend),
                                    "complexity_ratio": (p.complexity_ratio),
                                }
                                for p in dispatch_plans
                            ],
                            indent=2,
                        ),
                        encoding="utf-8",
                    )
                    logger.info(
                        "Page dispatch: classified %d PDFs",
                        len(dispatch_plans),
                    )
            except Exception as exc:
                logger.warning("Page dispatch skipped: %s", exc)

            convert_entries = []
            for dl_entry in entries:
                if dl_entry.status not in ("downloaded", "skipped_exists"):
                    continue
                pdf_path = Path(dl_entry.local_path)
                if not pdf_path.exists():
                    logger.warning("PDF not found: %s", pdf_path)
                    continue
                result = converter.convert(pdf_path, md_dir)
                convert_entries.append(result)

            conv_manifest_path = (
                get_stage_dir(run_root, "convert_root") / "convert_manifest.jsonl"
            )
            write_jsonl(
                conv_manifest_path,
                [e.model_dump(mode="json") for e in convert_entries],
            )

            # Register converted papers in global index
            if paper_index is not None:
                for conv_entry in convert_entries:
                    if conv_entry.status in ("converted", "skipped_exists"):
                        paper_index.register_paper(
                            arxiv_id=conv_entry.arxiv_id,
                            run_id=run_id,
                            stage="convert",
                            markdown_path=conv_entry.markdown_path,
                        )

            manifest = _record_stage(
                manifest,
                "convert",
                "completed",
                started,
                output_paths=[str(conv_manifest_path)],
                audit=audit,
                run_root=run_root,
            )
            save_manifest(run_root, manifest)
        else:
            from research_pipeline.models.conversion import ConvertManifestEntry
            from research_pipeline.storage.manifests import read_jsonl

            conv_data = read_jsonl(
                get_stage_dir(run_root, "convert_root") / "convert_manifest.jsonl"
            )
            convert_entries = [
                ConvertManifestEntry.model_validate(d) for d in conv_data
            ]
    else:
        logger.info("Skipping convert stage (profile: %s)", profile.value)
        convert_entries = []

    # Gate: after convert
    if not _gates_skipped:
        decision = check_gate(gate, "convert", "extract", run_id, run_root, gate_stages)
        if decision is GateDecision.SKIP:
            _gates_skipped = True

    # --- Stage: extract ---
    if memory:
        memory.transition_stage("extract")
    if should_run_stage(profile, "extract"):
        if not (resume and _is_stage_complete(manifest, "extract")):
            started = utc_now()
            logger.info("Stage: extract")
            audit.emit(EventType.STAGE_STARTED, stage="extract", run_id=run_id)
            if eval_log is not None:
                eval_log.trace("stage_started", stage="extract")
            extract_dir = get_stage_dir(run_root, "extract")

            extractions = []
            for conv_entry in convert_entries:
                if conv_entry.status not in ("converted", "skipped_exists"):
                    continue
                md_path = Path(conv_entry.markdown_path)
                if not md_path.exists():
                    logger.warning("Markdown not found: %s", md_path)
                    continue
                extraction = extract_from_markdown(
                    md_path, conv_entry.arxiv_id, conv_entry.version
                )
                extract_path = (
                    extract_dir
                    / f"{conv_entry.arxiv_id}{conv_entry.version}.extract.json"
                )
                extract_path.write_text(
                    extraction.model_dump_json(indent=2), encoding="utf-8"
                )
                extractions.append(extraction)

            manifest = _record_stage(
                manifest,
                "extract",
                "completed",
                started,
                output_paths=[str(extract_dir)],
                audit=audit,
                run_root=run_root,
            )
            save_manifest(run_root, manifest)
    else:
        logger.info("Skipping extract stage (profile: %s)", profile.value)

    # Gate: after extract
    if not _gates_skipped:
        decision = check_gate(
            gate, "extract", "summarize", run_id, run_root, gate_stages
        )
        if decision is GateDecision.SKIP:
            _gates_skipped = True

    # --- Stage: summarize ---
    if memory:
        memory.transition_stage("summarize")
    if not (resume and _is_stage_complete(manifest, "summarize")):
        started = utc_now()
        logger.info("Stage: summarize")
        audit.emit(EventType.STAGE_STARTED, stage="summarize", run_id=run_id)
        if eval_log is not None:
            eval_log.trace("stage_started", stage="summarize")
        sum_dir = get_stage_dir(run_root, "summarize")
        extraction_dir = sum_dir / "extractions"
        extraction_dir.mkdir(parents=True, exist_ok=True)

        summaries = []
        extraction_records: list[PaperExtractionRecord] = []

        if should_run_stage(profile, "download"):
            # Standard/deep path: summarize from converted markdown
            for conv_entry in convert_entries:
                if conv_entry.status not in ("converted", "skipped_exists"):
                    continue
                md_path = Path(conv_entry.markdown_path)
                if not md_path.exists():
                    continue

                # Find title from shortlist
                paper_title = conv_entry.arxiv_id
                for d in shortlist:
                    if d.paper.arxiv_id == conv_entry.arxiv_id:
                        paper_title = d.paper.title
                        break

                paper_extraction = extract_paper(
                    markdown_path=md_path,
                    arxiv_id=conv_entry.arxiv_id,
                    version=conv_entry.version,
                    title=paper_title,
                    topic_terms=plan.must_terms + plan.nice_terms,
                    llm_provider=llm_provider,
                )
                extraction_records.append(paper_extraction)
                base_name = f"{conv_entry.arxiv_id}{conv_entry.version}"
                (extraction_dir / f"{base_name}.extraction.json").write_text(
                    paper_extraction.model_dump_json(indent=2),
                    encoding="utf-8",
                )
                (extraction_dir / f"{base_name}.extraction.md").write_text(
                    render_extraction_markdown(paper_extraction),
                    encoding="utf-8",
                )
                summary = project_extraction_to_summary(paper_extraction)
                summaries.append(summary)

                # Save per-paper summary
                sum_path = sum_dir / f"{base_name}.summary.json"
                sum_path.write_text(summary.model_dump_json(indent=2), encoding="utf-8")
        else:
            # Quick path: synthesize from abstracts (no PDFs available)
            logger.info(
                "Quick profile: building summaries from abstracts (%d papers)",
                len(shortlist),
            )
            for rel_dec in shortlist:
                paper = rel_dec.paper
                abstract = paper.abstract or ""
                summary = PaperSummary(
                    arxiv_id=paper.arxiv_id,
                    version=paper.version,
                    title=paper.title,
                    objective=(
                        abstract[:500] if abstract else f"See paper: {paper.title}"
                    ),
                    methodology="(Abstract-only — quick profile, no PDF conversion)",
                    findings=[],
                    limitations=[
                        "Abstract-only summary; use standard/deep "
                        "profile for full analysis."
                    ],
                    evidence=[],
                    uncertainties=[],
                )
                summaries.append(summary)

                sum_path = sum_dir / f"{paper.arxiv_id}{paper.version}.summary.json"
                sum_path.write_text(summary.model_dump_json(indent=2), encoding="utf-8")

        # Cross-paper synthesis
        structured_report = None
        if extraction_records:
            structured_report = synthesize_extractions(
                extraction_records, plan.topic_raw
            )
            report = project_structured_synthesis_to_report(
                structured_report, summaries
            )
        else:
            report = synthesize(summaries, plan.topic_raw, llm_provider=llm_provider)
        synthesis_path = sum_dir / "synthesis.md"
        synthesis_json = sum_dir / "synthesis.json"
        synthesis_json.write_text(report.model_dump_json(indent=2), encoding="utf-8")

        if structured_report is not None:
            structured_json = sum_dir / "synthesis_report.json"
            structured_md_path = sum_dir / "synthesis_report.md"
            traceability_path = sum_dir / "synthesis_traceability.json"
            quality_path = sum_dir / "synthesis_quality.json"
            structured_json.write_text(
                structured_report.model_dump_json(indent=2),
                encoding="utf-8",
            )
            structured_md = render_structured_synthesis_markdown(structured_report)
            structured_md_path.write_text(structured_md, encoding="utf-8")
            synthesis_path.write_text(structured_md, encoding="utf-8")
            traceability_path.write_text(
                json.dumps(structured_report.traceability_appendix, indent=2),
                encoding="utf-8",
            )
            quality_path.write_text(
                structured_report.quality.model_dump_json(indent=2),
                encoding="utf-8",
            )
        else:
            # Generate readable Markdown synthesis for abstract-only quick mode.
            md_lines = [
                f"# Synthesis: {report.topic}",
                "",
                f"Papers analyzed: {report.paper_count}",
                "",
            ]
            if report.open_questions:
                md_lines.append("## Open Questions")
                md_lines.append("")
                for q in report.open_questions:
                    md_lines.append(f"- {q}")
                md_lines.append("")

            md_lines.append("## Paper Summaries")
            md_lines.append("")
            for ps in report.paper_summaries:
                md_lines.append(f"### {ps.title}")
                md_lines.append(f"- **ID**: {ps.arxiv_id}{ps.version}")
                md_lines.append(f"- **Objective**: {ps.objective}")
                md_lines.append(f"- **Methodology**: {ps.methodology}")
                if ps.findings:
                    md_lines.append("- **Findings**:")
                    for f in ps.findings:
                        md_lines.append(f"  - {f}")
                md_lines.append("")

            synthesis_path.write_text("\n".join(md_lines), encoding="utf-8")

        # Multi-agent parallel analysis (optional enhancement)
        try:
            from research_pipeline.agents.coordinator import (
                run_parallel_analysis,
            )

            analysis_items = [
                {
                    "paper_id": s.arxiv_id,
                    "title": s.title,
                    "objective": s.objective,
                    "methodology": s.methodology,
                    "findings": s.findings,
                }
                for s in summaries
            ]
            if analysis_items:
                agent_result = run_parallel_analysis(
                    analysis_items,
                    max_workers=min(4, len(analysis_items)),
                    task_type="analyze",
                )
                agent_path = sum_dir / "agent_analysis.json"
                agent_path.write_text(
                    json.dumps(
                        {
                            "total": agent_result.total_tasks,
                            "completed": agent_result.completed_tasks,
                            "failed": agent_result.failed_tasks,
                            "success_rate": agent_result.success_rate,
                            "has_conflicts": (agent_result.has_conflicts),
                            "conflicts": [
                                {
                                    "field": c.field,
                                    "severity": c.severity.value,
                                    "values": [str(v) for v in c.values],
                                }
                                for c in agent_result.conflicts
                            ],
                        },
                        indent=2,
                    ),
                    encoding="utf-8",
                )
                logger.info(
                    "Multi-agent analysis: %d/%d completed",
                    agent_result.completed_tasks,
                    agent_result.total_tasks,
                )
        except Exception as exc:
            logger.warning("Multi-agent analysis skipped: %s", exc)

        # Evidence-only aggregation
        try:
            from research_pipeline.summarization.evidence_aggregation import (
                aggregate_evidence,
                format_aggregation_text,
            )

            aggregation = aggregate_evidence(report, min_pointers=0)
            agg_json = sum_dir / "evidence_aggregation.json"
            agg_json.write_text(
                aggregation.model_dump_json(indent=2),
                encoding="utf-8",
            )
            agg_text = sum_dir / "evidence_aggregation.md"
            agg_text.write_text(
                format_aggregation_text(aggregation),
                encoding="utf-8",
            )
            logger.info(
                "Evidence aggregation: %d → %d statements",
                aggregation.stats.input_statements,
                aggregation.stats.output_statements,
            )
        except Exception as exc:
            logger.warning("Evidence aggregation skipped: %s", exc)

        # HTML report export
        try:
            from research_pipeline.summarization.html_export import (
                render_html_report,
            )

            html_path = sum_dir / "synthesis_report.html"
            render_html_report(report, html_path)
            logger.info("HTML report exported to %s", html_path)
        except Exception as exc:
            logger.warning("HTML report export skipped: %s", exc)

        # Coherence evaluation on synthesis claims
        try:
            from research_pipeline.evaluation.coherence_eval import (
                Assertion,
                CoherenceEvaluator,
            )

            assertions = []
            for ps in report.paper_summaries:
                for finding in ps.findings:
                    assertions.append(
                        Assertion(
                            text=finding,
                            source=ps.arxiv_id,
                        )
                    )

            if assertions:
                evaluator = CoherenceEvaluator()
                coherence_report = evaluator.evaluate(assertions=assertions)
                coherence_path = sum_dir / "coherence_report.json"
                coherence_path.write_text(
                    json.dumps(coherence_report.to_dict(), indent=2),
                    encoding="utf-8",
                )
                logger.info(
                    "Coherence evaluation: overall=%.3f, %d dimensions scored",
                    coherence_report.composite_score,
                    len(coherence_report.dimension_scores),
                )
        except Exception as exc:
            logger.warning("Coherence evaluation skipped: %s", exc)

        manifest = _record_stage(
            manifest,
            "summarize",
            "completed",
            started,
            output_paths=[str(synthesis_path), str(synthesis_json)],
            audit=audit,
            run_root=run_root,
        )
        save_manifest(run_root, manifest)

    # --- TER loop (deep profile, or when ter_max_iterations > 0) ---
    ter_max = config.ter_max_iterations
    if should_run_stage(profile, "expand") and ter_max > 0:
        from research_pipeline.pipeline.ter_loop import (
            GapAnalysis,
            TERIteration,
            TERResult,
            check_convergence,
            identify_gaps,
            save_ter_state,
        )

        logger.info("Starting THINK→EXECUTE→REFLECT loop (max %d iterations)", ter_max)
        audit.emit(EventType.STAGE_STARTED, stage="ter_loop", run_id=run_id)
        if eval_log is not None:
            eval_log.trace("stage_started", stage="ter_loop")

        # Read current synthesis
        sum_dir = get_stage_dir(run_root, "summarize")
        synthesis_path = sum_dir / "synthesis.md"
        synthesis_text = ""
        if synthesis_path.exists():
            synthesis_text = synthesis_path.read_text(encoding="utf-8")

        existing_titles = [s.title for s in summaries]
        ter_result = TERResult()
        previous_gap_analysis: GapAnalysis | None = None

        for iteration_idx in range(ter_max):
            logger.info(
                "TER iteration %d/%d — THINK phase",
                iteration_idx + 1,
                ter_max,
            )

            # THINK: identify gaps
            gap_analysis = identify_gaps(
                synthesis_text, topic, existing_titles, llm_provider
            )
            logger.info(
                "Found %d gaps, %d new queries",
                gap_analysis.gap_count,
                len(gap_analysis.suggested_queries),
            )

            # REFLECT: check convergence
            converged, reason = check_convergence(
                gap_analysis, previous_gap_analysis, iteration_idx, ter_max
            )

            ter_iteration = TERIteration(
                iteration=iteration_idx,
                gaps_found=gap_analysis.gaps,
                queries_generated=gap_analysis.suggested_queries,
                converged=converged,
            )

            if converged:
                logger.info("TER converged: %s", reason)
                ter_result.converged = True
                ter_result.convergence_reason = reason
                ter_result.iterations.append(ter_iteration)
                ter_result.total_iterations = iteration_idx + 1
                break

            # EXECUTE: log the queries that would be searched
            logger.info(
                "TER iteration %d — EXECUTE phase: %d queries to search",
                iteration_idx + 1,
                len(gap_analysis.suggested_queries),
            )
            for q in gap_analysis.suggested_queries:
                logger.info("  Gap-filling query: %s", q)

            ter_result.iterations.append(ter_iteration)
            ter_result.total_iterations = iteration_idx + 1
            previous_gap_analysis = gap_analysis

            # Save state after each iteration
            save_ter_state(
                run_root,
                ter_result,
                {
                    "gaps": gap_analysis.gaps,
                    "queries": gap_analysis.suggested_queries,
                },
            )

        # Save final TER state
        save_ter_state(run_root, ter_result)
        logger.info(
            "TER loop complete: %d iterations, converged=%s (%s)",
            ter_result.total_iterations,
            ter_result.converged,
            ter_result.convergence_reason,
        )
        audit.emit(
            EventType.STAGE_COMPLETED,
            stage="ter_loop",
            run_id=run_id,
            details={
                "iterations": ter_result.total_iterations,
                "converged": ter_result.converged,
                "reason": ter_result.convergence_reason,
            },
        )

    # --- Deep profile: extra stages ---
    if should_run_stage(profile, "expand"):
        logger.info("Deep profile: citation expansion stage (expand)")
        # TODO: Wire expand stage into orchestrator
        logger.info("Expand stage not yet wired into orchestrator — run manually")
    if should_run_stage(profile, "quality"):
        logger.info("Deep profile: quality scoring stage")
        # TODO: Wire quality stage into orchestrator
        logger.info("Quality stage not yet wired into orchestrator — run manually")
    if should_run_stage(profile, "analyze_claims"):
        logger.info("Deep profile: claim analysis stage")
        # TODO: Wire analyze_claims stage into orchestrator
        logger.info(
            "Analyze-claims stage not yet wired into orchestrator — run manually"
        )
    if should_run_stage(profile, "score_claims"):
        logger.info("Deep profile: confidence scoring stage")
        # TODO: Wire score_claims stage into orchestrator
        logger.info("Score-claims stage not yet wired into orchestrator — run manually")

    # Log security gate stats
    if security_gate is not None:
        gate_stats = security_gate.stats()
        if gate_stats["sanitized"] > 0 or gate_stats["quarantined"] > 0:
            logger.info("Security gate stats: %s", gate_stats)
        audit.emit(
            EventType.DECISION,
            run_id=run_id,
            details={"security_gate": gate_stats},
        )

    logger.info("Pipeline complete: run_id=%s", run_id)
    audit.emit(
        EventType.STAGE_COMPLETED,
        stage="pipeline",
        run_id=run_id,
        details={"stages_completed": list(manifest.stages.keys())},
    )

    # Record episode in episodic memory
    if memory:
        try:
            episode = Episode(
                run_id=run_id,
                topic=topic,
                profile=profile.value,
                started_at=str(manifest.created_at),
                completed_at=str(utc_now()),
                stages_completed=list(manifest.stages.keys()),
                paper_count=len(candidates),
                shortlist_count=len(shortlist),
            )
            memory.record_run(episode)
        except Exception as exc:
            logger.warning("Failed to record episode: %s", exc)
        finally:
            memory.close()

    # MCP guard audit summary
    if mcp_guard is not None:
        try:
            audit_summary = mcp_guard.audit_summary()
            if audit_summary["total"] > 0:
                logger.info(
                    "MCP audit: %d total, %d allowed, %d denied",
                    audit_summary["total"],
                    audit_summary["allowed"],
                    audit_summary["denied"],
                )
                audit_path = run_root / "mcp_audit.json"
                audit_path.write_text(
                    json.dumps(audit_summary, indent=2),
                    encoding="utf-8",
                )
        except Exception as exc:
            logger.warning("MCP audit save failed: %s", exc)

    # Three-channel eval logging summary
    if eval_log is not None:
        try:
            eval_log.trace(
                "pipeline_complete",
                stage="pipeline",
                data={
                    "run_id": run_id,
                    "stages": list(manifest.stages.keys()),
                    "papers": len(candidates),
                },
            )
            eval_log.record_audit(
                "pipeline",
                "complete",
                run_id=run_id,
                details={
                    "stages": list(manifest.stages.keys()),
                    "papers": len(candidates),
                    "shortlist": len(shortlist),
                },
            )
            eval_summary = eval_log.summary()
            eval_summary_path = run_root / "eval_logging_summary.json"
            eval_summary_path.write_text(
                json.dumps(eval_summary, indent=2, default=str),
                encoding="utf-8",
            )
            eval_log.close()
        except Exception as exc:
            logger.warning("Eval logging summary failed: %s", exc)

    # Close global paper index
    if paper_index is not None:
        paper_index.close()

    return manifest
