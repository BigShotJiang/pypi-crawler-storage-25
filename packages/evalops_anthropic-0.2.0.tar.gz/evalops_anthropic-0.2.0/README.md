# evalops-anthropic

Drop-in Anthropic SDK shim for stamping EvalOps organization scope, principal
attribution, trace IDs, and provider references onto Anthropic-compatible
requests.

This package is part of the G1 shim wedge from `evalops/platform#1133`. It
establishes the package and conformance surface while `llm-gateway` grows
Anthropic-native endpoint coverage.

## Python

```bash
pip install evalops-anthropic
```

```python
from evalops_anthropic import Anthropic

client = Anthropic(organization_id="org_123", principal="user:ada@example.com")

message = client.messages.create(
    **client.with_provider_ref(
        {
            "model": "claude-sonnet-4.6",
            "max_tokens": 256,
            "messages": [{"role": "user", "content": "hello"}],
        }
    )
)
```

## Node

```bash
npm install @evalops/anthropic
```

```ts
import { Anthropic } from "@evalops/anthropic";

const client = new Anthropic({
  organizationId: "org_123",
  principal: "user:ada@example.com",
});

const message = await client.messages.create(
  client.withProviderRef({
    model: "claude-sonnet-4.6",
    max_tokens: 256,
    messages: [{ role: "user", content: "hello" }],
  }),
);
```

## Environment

- `EVALOPS_API_KEY` or `ANTHROPIC_API_KEY`: Platform-issued bearer token.
- `EVALOPS_ORGANIZATION_ID`: organization scope stamped into requests.
- `EVALOPS_PRINCIPAL`: optional actor string for audit attribution.
- `EVALOPS_TRACE_ID`: optional trace correlation ID.
- `EVALOPS_LLM_GATEWAY_ANTHROPIC_URL`: Anthropic-compatible gateway base URL.
- `EVALOPS_LLM_GATEWAY_URL`: fallback gateway base URL.
- `EVALOPS_PROVIDER_ENVIRONMENT`: defaults to `prod`.
- `EVALOPS_PROVIDER_CREDENTIAL_NAME`: optional provider ref credential name.
- `EVALOPS_PROVIDER_TEAM_ID`: optional provider ref team ID.

## Gateway Status

`llm-gateway` currently exposes OpenAI-compatible `/v1/chat/completions` and
`/v1/responses`. This shim ships the package contract and conformance helpers
for the Anthropic adapter; full import-only parity depends on gateway-side
Anthropic endpoint support.

