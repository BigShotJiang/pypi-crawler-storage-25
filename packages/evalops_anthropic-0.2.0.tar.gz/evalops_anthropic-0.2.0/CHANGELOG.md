# Changelog

## [0.2.0](https://github.com/evalops/evalops-anthropic/compare/anthropic-v0.1.0...anthropic-v0.2.0) (2026-04-29)


### Features

* add registry publish workflow ([41fdcad](https://github.com/evalops/evalops-anthropic/commit/41fdcad1ecd92ba27936fcd32c6be1a072962085))


### Bug Fixes

* use bot token for release PRs ([f5cb370](https://github.com/evalops/evalops-anthropic/commit/f5cb3700844e259f4dadffe8e80fd2ae0b187f73))
