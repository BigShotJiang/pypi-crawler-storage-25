import { describe, expect, it, vi } from "vitest";
import { Anthropic, buildEvalOpsHeaders, buildProviderRef } from "../src/index";

describe("evalops-anthropic", () => {
  it("stamps both current and future org headers", () => {
    expect(buildEvalOpsHeaders({ organizationId: "org_123", principal: "user:ada" })).toMatchObject({
      "X-Organization-ID": "org_123",
      "X-EvalOps-Organization-ID": "org_123",
      "X-EvalOps-Principal": "user:ada",
    });
  });

  it("builds the default Anthropic provider ref", () => {
    expect(buildProviderRef()).toMatchObject({
      provider: "anthropic",
      environment: "prod",
    });
  });

  it("injects provider_ref without mutating request body", () => {
    vi.stubEnv("EVALOPS_API_KEY", "token");
    const client = new Anthropic({ organizationId: "org_123" });
    const body = { model: "claude-sonnet-4.6", max_tokens: 128, messages: [{ role: "user", content: "hello" }] };

    expect(client.withProviderRef(body)).toMatchObject({
      ...body,
      provider_ref: { provider: "anthropic", environment: "prod" },
    });
    expect(body).not.toHaveProperty("provider_ref");
  });
});

