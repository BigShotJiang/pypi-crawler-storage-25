"""Curated color palettes for presentation-quality visualizations.

Each palette is designed for a specific context — boardroom decks,
pitch presentations, academic papers, dashboards, and print reports.

Usage:
    apply_palette("boardroom")          # Global apply
    with palette("startup"):            # Scoped apply
        plt.bar(...)
"""
import contextlib
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

PALETTES = {
    "boardroom": {
        "colors": ["#1B2A4A", "#C0392B", "#2980B9", "#27AE60", "#F39C12", "#8E44AD", "#16A085"],
        "bg": "#FFFFFF",
        "grid": 0.15,
        "title_size": 16,
        "label_size": 11,
        "description": "Professional navy/red for executive presentations",
    },
    "startup": {
        "colors": ["#6C5CE7", "#00B894", "#FD79A8", "#FDCB6E", "#0984E3", "#E17055", "#74B9FF"],
        "bg": "#FAFAFA",
        "grid": 0.12,
        "title_size": 15,
        "label_size": 11,
        "description": "Modern purple/green for pitch decks",
    },
    "classic": {
        "colors": ["#2C3E50", "#E74C3C", "#3498DB", "#2ECC71", "#F39C12", "#9B59B6"],
        "bg": "#FFFFFF",
        "grid": 0.2,
        "title_size": 14,
        "label_size": 10,
        "description": "Traditional muted tones for academic papers",
    },
    "dashboard": {
        "colors": ["#00BCD4", "#FF5722", "#4CAF50", "#FFC107", "#9C27B0", "#607D8B", "#E91E63"],
        "bg": "#F5F5F5",
        "grid": 0.1,
        "title_size": 13,
        "label_size": 10,
        "description": "High-contrast palette for dashboard displays",
    },
    "print": {
        "colors": ["#212121", "#616161", "#9E9E9E", "#BDBDBD", "#E0E0E0"],
        "bg": "#FFFFFF",
        "grid": 0.15,
        "title_size": 12,
        "label_size": 10,
        "description": "Grayscale palette optimized for print output",
    },
    "warm": {
        "colors": ["#D84315", "#E65100", "#F57C00", "#FFA000", "#FFB300", "#FFD54F"],
        "bg": "#FFF8E1",
        "grid": 0.1,
        "title_size": 15,
        "label_size": 11,
        "description": "Warm amber/orange tones for inviting presentations",
    },
}

_active = "boardroom"
_saved_params = {}


def apply_palette(name="boardroom"):
    """Apply a named color palette to all subsequent charts.

    Parameters
    ----------
    name : str
        One of: boardroom, startup, classic, dashboard, print, warm

    Returns
    -------
    dict
        The applied palette configuration.
    """
    global _active
    if name not in PALETTES:
        available = ", ".join(PALETTES.keys())
        raise ValueError(f"Unknown palette '{name}'. Available: {available}")
    _active = name
    _apply_rcparams(PALETTES[name])
    return PALETTES[name]


def _apply_rcparams(p):
    """Apply palette rcParams to matplotlib."""
    plt.rcParams.update({
        "figure.facecolor": p["bg"],
        "axes.facecolor": p["bg"],
        "font.family": "sans-serif",
        "axes.titlesize": p["title_size"],
        "axes.labelsize": p["label_size"],
        "axes.prop_cycle": plt.cycler(color=p["colors"]),
        "axes.grid": True,
        "grid.alpha": p["grid"],
        "figure.dpi": 150,
    })


@contextlib.contextmanager
def palette(name):
    """Context manager for scoped palette application.

    Usage:
        with palette("startup"):
            styled_bar(data, title="Revenue")
        # Previous palette is restored after the block
    """
    old_params = {k: plt.rcParams[k] for k in [
        "figure.facecolor", "axes.facecolor", "font.family",
        "axes.titlesize", "axes.labelsize", "axes.prop_cycle",
        "axes.grid", "grid.alpha", "figure.dpi",
    ]}
    old_active = _active
    try:
        apply_palette(name)
        yield PALETTES[name]
    finally:
        plt.rcParams.update(old_params)
        globals()["_active"] = old_active


def get_colors():
    """Return the active palette's color list."""
    return PALETTES[_active]["colors"]


def list_palettes():
    """Print available palettes with descriptions."""
    for name, p in PALETTES.items():
        marker = " <- active" if name == _active else ""
        print(f"  {name:12s}  {p['description']}{marker}")


def _register_styles():
    """Register all palettes as matplotlib styles.

    After calling this, users can do:
        plt.style.use("mps-boardroom")
        plt.style.use("mps-startup")
    with any existing matplotlib code.
    """
    try:
        from matplotlib import style
        for name, p in PALETTES.items():
            style_dict = {
                "figure.facecolor": p["bg"],
                "axes.facecolor": p["bg"],
                "font.family": "sans-serif",
                "axes.titlesize": p["title_size"],
                "axes.labelsize": p["label_size"],
                "axes.prop_cycle": plt.cycler(color=p["colors"]),
                "axes.grid": True,
                "grid.alpha": p["grid"],
                "figure.dpi": 150,
                "axes.spines.top": False,
                "axes.spines.right": False,
                "savefig.bbox": "tight",
            }
            style.library[f"mps-{name}"] = style_dict
        style.reload_library()
    except Exception:
        pass
