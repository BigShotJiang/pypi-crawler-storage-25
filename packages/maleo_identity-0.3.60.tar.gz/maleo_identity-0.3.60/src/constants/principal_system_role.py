from nexo.schemas.resource import Resource, ResourceIdentifier


PRINCIPAL_SYSTEM_ROLE_RESOURCE = Resource(
    identifiers=[
        ResourceIdentifier(
            key="principal_system_role",
            name="Principal System Role",
            slug="principal-system-roles",
        )
    ],
    details=None,
)
