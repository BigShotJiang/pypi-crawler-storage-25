from enum import StrEnum
from nexo.types.string import ListOfStrs, ManyStrs


class IdentifierType(StrEnum):
    ID = "id"
    UUID = "uuid"
    PERSONAL_COMPOSITE = "personal_composite"
    SYSTEM_COMPOSITE = "system_composite"
    TENANT_COMPOSITE = "tenant_composite"

    @classmethod
    def choices(cls) -> ListOfStrs:
        return [e.value for e in cls]

    @property
    def columns(self) -> ManyStrs:
        if self is IdentifierType.ID:
            return ("id",)
        elif self is IdentifierType.UUID:
            return ("uuid",)
        elif self is IdentifierType.PERSONAL_COMPOSITE:
            return ("domain", "user_id")
        elif self is IdentifierType.SYSTEM_COMPOSITE:
            return ("domain", "user_id")
        elif self is IdentifierType.TENANT_COMPOSITE:
            return ("domain", "user_id", "organization_id")
        raise ValueError(f"Unknown column(s) for identifier type: {self}")
