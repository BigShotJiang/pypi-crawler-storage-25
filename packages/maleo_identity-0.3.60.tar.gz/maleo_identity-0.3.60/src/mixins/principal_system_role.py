from pydantic import Field
from typing import Annotated, Literal, TypeGuard
from uuid import UUID
from nexo.schemas.mixins.identity import Identifier
from nexo.types.any import ManyAny
from nexo.types.string import ManyStrs
from ..enums.principal_system_role import IdentifierType
from ..types.principal_system_role import (
    CompositeIdentifierValueType,
    IdentifierValueType,
)


class PrincipalSystemRoleIdentifier(Identifier[IdentifierType, IdentifierValueType]):
    @property
    def columns_and_values(self) -> tuple[ManyStrs, ManyAny]:
        values = self.value if isinstance(self.value, tuple) else (self.value,)
        return self.type.columns, values


class IdPrincipalSystemRoleIdentifier(Identifier[Literal[IdentifierType.ID], int]):
    type: Annotated[
        Literal[IdentifierType.ID],
        Field(IdentifierType.ID, description="Identifier's type"),
    ] = IdentifierType.ID
    value: Annotated[int, Field(..., description="Identifier's value", ge=1)]


class UUIDPrincipalSystemRoleIdentifier(Identifier[Literal[IdentifierType.UUID], UUID]):
    type: Annotated[
        Literal[IdentifierType.UUID],
        Field(IdentifierType.UUID, description="Identifier's type"),
    ] = IdentifierType.UUID


class CompositePrincipalSystemRoleIdentifier(
    Identifier[Literal[IdentifierType.COMPOSITE], CompositeIdentifierValueType]
):
    type: Annotated[
        Literal[IdentifierType.COMPOSITE],
        Field(IdentifierType.COMPOSITE, description="Identifier's type"),
    ] = IdentifierType.COMPOSITE
    value: Annotated[
        CompositeIdentifierValueType, Field(..., description="Identifier's value")
    ]


AnyPrincipalSystemRoleIdentifier = (
    PrincipalSystemRoleIdentifier
    | IdPrincipalSystemRoleIdentifier
    | UUIDPrincipalSystemRoleIdentifier
    | CompositePrincipalSystemRoleIdentifier
)


def is_id_identifier(
    identifier: AnyPrincipalSystemRoleIdentifier,
) -> TypeGuard[IdPrincipalSystemRoleIdentifier]:
    return identifier.type is IdentifierType.ID and isinstance(identifier.value, int)


def is_uuid_identifier(
    identifier: AnyPrincipalSystemRoleIdentifier,
) -> TypeGuard[UUIDPrincipalSystemRoleIdentifier]:
    return identifier.type is IdentifierType.UUID and isinstance(identifier.value, UUID)


def is_composite_identifier(
    identifier: AnyPrincipalSystemRoleIdentifier,
) -> TypeGuard[CompositePrincipalSystemRoleIdentifier]:
    return identifier.type is IdentifierType.COMPOSITE and isinstance(
        identifier.value, tuple
    )
