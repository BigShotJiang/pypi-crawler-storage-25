from pydantic import BaseModel, Field
from typing import Annotated, Literal, TypeGuard
from uuid import UUID
from nexo.schemas.mixins.identity import Identifier
from ..enums.api_key import IdentifierType
from ..types.api_key import IdentifierValueType


class APIKey(BaseModel):
    api_key: Annotated[str, Field(..., description="API Key", max_length=255)]


class APIKeyIdentifier(Identifier[IdentifierType, IdentifierValueType]):
    @property
    def column_and_value(self) -> tuple[str, IdentifierValueType]:
        return self.type.column, self.value


class IdAPIKeyIdentifier(Identifier[Literal[IdentifierType.ID], int]):
    type: Annotated[
        Literal[IdentifierType.ID],
        Field(IdentifierType.ID, description="Identifier's type"),
    ] = IdentifierType.ID
    value: Annotated[int, Field(..., description="Identifier's value", ge=1)]


class UUIDAPIKeyIdentifier(Identifier[Literal[IdentifierType.UUID], UUID]):
    type: Annotated[
        Literal[IdentifierType.UUID],
        Field(IdentifierType.UUID, description="Identifier's type"),
    ] = IdentifierType.UUID


class PrincipalIdAPIKeyIdentifier(
    Identifier[Literal[IdentifierType.PRINCIPAL_ID], int]
):
    type: Annotated[
        Literal[IdentifierType.PRINCIPAL_ID],
        Field(IdentifierType.PRINCIPAL_ID, description="Identifier's type"),
    ] = IdentifierType.PRINCIPAL_ID
    value: Annotated[int, Field(..., description="Identifier's value", ge=1)]


class APIKeyAPIKeyIdentifier(Identifier[Literal[IdentifierType.API_KEY], str]):
    type: Annotated[
        Literal[IdentifierType.API_KEY],
        Field(IdentifierType.API_KEY, description="Identifier's type"),
    ] = IdentifierType.API_KEY


AnyAPIKeyIdentifier = (
    APIKeyIdentifier
    | IdAPIKeyIdentifier
    | UUIDAPIKeyIdentifier
    | PrincipalIdAPIKeyIdentifier
    | APIKeyAPIKeyIdentifier
)


def is_id_identifier(
    identifier: AnyAPIKeyIdentifier,
) -> TypeGuard[IdAPIKeyIdentifier]:
    return identifier.type is IdentifierType.ID and isinstance(identifier.value, int)


def is_uuid_identifier(
    identifier: AnyAPIKeyIdentifier,
) -> TypeGuard[UUIDAPIKeyIdentifier]:
    return identifier.type is IdentifierType.UUID and isinstance(identifier.value, UUID)


def is_principal_id_identifier(
    identifier: AnyAPIKeyIdentifier,
) -> TypeGuard[PrincipalIdAPIKeyIdentifier]:
    return identifier.type is IdentifierType.PRINCIPAL_ID and isinstance(
        identifier.value, tuple
    )


def is_api_key_identifier(
    identifier: AnyAPIKeyIdentifier,
) -> TypeGuard[APIKeyAPIKeyIdentifier]:
    return identifier.type is IdentifierType.API_KEY and isinstance(
        identifier.value, str
    )
