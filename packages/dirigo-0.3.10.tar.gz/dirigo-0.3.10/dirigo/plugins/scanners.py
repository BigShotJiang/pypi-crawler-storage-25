import threading
from functools import cached_property, cache
from typing import cast

import numpy as np

import nidaqmx
import nidaqmx.system
import nidaqmx.errors
from nidaqmx.stream_writers import AnalogMultiChannelWriter
from nidaqmx.constants import (
    AcquisitionType, RegenerationMode, LineGrouping, ProductCategory
)

from dirigo.components import units
from dirigo.hw_interfaces.scanner import (Waveforms,
    GalvoScanner, ResonantScanner, PolygonScanner,
    FastRasterScanner, SlowRasterScanner,
)
from dirigo.hw_interfaces import digitizer as dgtz



def get_device(device_name: str) -> nidaqmx.system.Device:
    """Returns handle to the NIDAQ system device object."""
    return cast(nidaqmx.system.Device,
                nidaqmx.system.System.local().devices[device_name])


@cache
def _get_all_ni_channels_for_device(device_name: str) -> set[str]:
    """
    Return a cached set of all channel/terminal names for a given NI device.
    """
    device = get_device(device_name)

    names: set[str] = set()
    names.update(chan.name for chan in device.ai_physical_chans)
    names.update(chan.name for chan in device.ao_physical_chans)
    names.update(chan.name for chan in device.di_lines)
    names.update(chan.name for chan in device.do_lines)
    names.update(device.terminals)

    return names


def validate_ni_channel(channel_name: str) -> str:
    """
    Confirm if a given channel or terminal exists on a device.
    """
    # Basic format check
    if '/' not in channel_name or channel_name.count('/') > 3:
        raise ValueError(
            f"Invalid channel name format, {channel_name}. "
            f"Valid formats: [device name]/[channel name] or /[device name]/[terminal name]. "
            f"Examples: 'Dev1/ao0', '/Dev1/PFI4', '/Dev1/ao/SampleClock'"
        )

    parts = channel_name.split('/')
    if channel_name.startswith('/'):
        # '/Dev1/PFI0'
        device_name = parts[1]
    else:
        # 'Dev1/ai0'
        device_name = parts[0]

    try:
        all_channels = _get_all_ni_channels_for_device(device_name)
    except KeyError:
        raise ValueError(f"Device {device_name} not found in the system.")

    if channel_name not in all_channels:
        raise ValueError(
            f"Channel/terminal, {channel_name} not found on device, {device_name}"
        )

    return channel_name



class CounterRegistry:
    _available_counters: list[str] = []
    _in_use: set[str] = set()
    _initialized: bool = False
    _device_name: str | None = None

    @classmethod
    def initialize(cls, device_name: str):
        device = nidaqmx.system.Device(device_name)
        cls._available_counters = [chan.name for chan in device.ci_physical_chans]
        cls._in_use.clear()
        cls._initialized = True
        cls._device_name = device_name

    @classmethod
    def allocate_counter(cls, device_name: str) -> str:
        """
        Returns a free counter from the registry, marking it in use.
        Lazily initializes the registry if not already done.
        """
        # Lazy initialization
        if not cls._initialized:
            cls.initialize(device_name)

        # If someone tries to allocate from a different device
        # than we previously initialized, decide how you want to handle that:
        if device_name != cls._device_name:
            # Possibly re‐initialize for the new device?
            cls.initialize(device_name)

        for ctr in cls._available_counters:
            if ctr not in cls._in_use:
                cls._in_use.add(ctr)
                return ctr

        raise RuntimeError("No free counters available!")

    @classmethod
    def free_counter(cls, counter_name: str):
        """
        Marks a previously-allocated counter as free again.
        """
        cls._in_use.discard(counter_name)


def get_min_ao_rate(device: nidaqmx.system.Device) -> units.SampleRate:
    return units.SampleRate(device.ao_min_rate)


def get_max_ao_rate(device: nidaqmx.system.Device, n_channels: int = 1) -> units.SampleRate:
    """Maximum supported AO rate according to NIDAQmx"""
    if device.product_category == ProductCategory.S_SERIES_DAQ:
        # These are the listed Specifications
        # In practice, we observed desync when >1 MS/s 2-chan w/ continuous regeneration
        if n_channels == 1:
            return units.SampleRate("4 MS/s")
        elif n_channels == 2:
            return units.SampleRate("2.5 MS/s")
        else:
            raise ValueError(f"Only 1 or 2 AO output channels allowed for NI S-series DAQ, got {n_channels}")
    else: # X-series
        return units.SampleRate(device.ao_max_rate)



class ResonantScannerViaNI(ResonantScanner, FastRasterScanner):
    """
    Resonant scanner operated via an NIDAQ MFIO card.
    """
    def __init__(self, 
                 amplitude_control_channel: str, 
                 analog_control_range: dict, 
                 **kwargs):
        super().__init__(**kwargs)

        # Validated and set ampltidue control analog channel
        validate_ni_channel(amplitude_control_channel)
        self._amplitude_control_channel = amplitude_control_channel

        # Validate the analog control range
        if not isinstance(analog_control_range, dict):
            raise ValueError(
                "analog_control_range must be a dictionary."
            )
        missing_keys = {'min', 'max'} - analog_control_range.keys()
        if missing_keys:
            raise ValueError(
                f"analog_control_range must have 'min' and 'max' keys."
            )
        self._analog_control_range = units.VoltageRange(**analog_control_range)

        # Default: cycle start/stop to idle at idle amplitude
        self._amplitude = units.Angle("0 deg")
        self.start()
        self.stop()

    @property
    def amplitude(self) -> units.Angle:
        """Get the peak-to-peak amplitude, in optical angle."""
        return self._amplitude

    @amplitude.setter
    def amplitude(self, new_ampl: units.Angle):
        """Set the peak-to-peak amplitude."""
        if not isinstance(new_ampl, units.Angle):
            raise ValueError(
                f"`amplitude` must be set with Angle object. Got {type(new_ampl)}"
            )

        # Validate that the value is within the acceptable range
        if not self.angle_limits.within_range(units.Angle(new_ampl/2)):
            raise ValueError(
                f"Value for 'amplitude' outside settable range "
                f"{self.angle_limits.min} to {self.angle_limits.max}. "
                f"Got: {new_ampl}"
            )
        
        # Store the validated amplitude
        self._amplitude = new_ampl

        # Apply now if running
        if self.running:
            self._apply_amplitude(new_ampl)
  
    def _apply_amplitude(self, new_ampl: units.Angle):
        ampl_fraction = new_ampl / self.angle_limits.range
        analog_value =  ampl_fraction * self.analog_control_range.max

        # Set the analog value using nidaqmx
        try:
            with nidaqmx.Task() as task: 
                task.ao_channels.add_ao_voltage_chan(self._amplitude_control_channel)
                task.write(analog_value)
        except nidaqmx.DaqError as e:
            raise RuntimeError(f"Failed to set analog output: {e}") from e  

    @property
    def analog_control_range(self) -> units.VoltageRange:
        """Returns an object describing the analog control range."""
        return self._analog_control_range
    
    def start(self):
        super().start() # checks whether already running, flip running flag
        self._apply_amplitude(self._amplitude)
        
    def stop(self):
        self._apply_amplitude(self.idle_amplitude)
        super().stop()


class PolygonScannerViaNI(PolygonScanner, FastRasterScanner):
    pass # TODO, write this


class GalvoScannerViaNI(GalvoScanner):
    AO_RATE_LIMIT = units.SampleRate("500 kS/s") # beyond this rate is unnecessary for driving galvos
    def __init__(self, 
                 analog_control_channel: str, # e.g. 'Dev1/ao1'
                 analog_control_range: dict, # e.g. {'min': '-10 V', 'max': '10 V'}
                 **kwargs):
        
        super().__init__(**kwargs) # Sets axis & scan angle range
        self._analog_control_channel = validate_ni_channel(analog_control_channel)
        
        device_name = self._analog_control_channel.split('/')[0]
        self._device = get_device(device_name)

        if not isinstance(analog_control_range, dict):
            raise ValueError("`analog_control_range` must be a dictionary.")
        missing_keys = {'min', 'max'} - analog_control_range.keys()
        if missing_keys:
            raise ValueError(
                f"`analog_control_range` must be a dictionary with 'min' and 'max' keys."
            )
        self._analog_control_range = units.VoltageRange(**analog_control_range)

        self._ao_task: nidaqmx.Task | None = None
        self._active = False

    def park(self):
        """Positions the scanner at the angle limit minimum."""
        analog_value = units.Voltage(self.angle_limits.min * self._volts_per_radian)
        try:
            with nidaqmx.Task() as task: 
                task.ao_channels.add_ao_voltage_chan(self._analog_control_channel)
                task.write(analog_value)
        except nidaqmx.DaqError as e:
            raise RuntimeError(f"Failed to park scanner: {e}") from e
        
    def center(self):
        """Positions the scanner at zero angle."""
        analog_value = 0
        try:
            with nidaqmx.Task() as task: 
                task.ao_channels.add_ao_voltage_chan(self._analog_control_channel)
                task.write(analog_value)
        except nidaqmx.DaqError as e:
            raise RuntimeError(f"Failed to center scanner: {e}") from e
    
    @cached_property
    def _volts_per_radian(self) -> float:
        """Scaling factor between analog control voltge and optical scan angle."""
        return float(self._analog_control_range.range / self.angle_limits.range)
    
    def generate_waveform(self, 
                          sample_rate: units.SampleRate,
                          rearm_time: units.Time = units.Time(0)) -> np.ndarray:
        # TODO, njit? parameters: waveform, amplitude, duty_cycle, waveform_length, samples_per_period
        """Returns are waveform vector in units of radian."""
        offset = self.offset # shifts whole waveform up or down (useful for alignment)

        exact_samples_per_period = sample_rate / self.frequency
        waveform_length = round(exact_samples_per_period - rearm_time * sample_rate)

        if self.waveform == Waveforms.SINUSOID:
            t = np.linspace(start=0, stop=2*np.pi, num=waveform_length)

            waveform = (self.amplitude/2) * np.cos(t) + offset # amplitude is pk-pk hence the 1/2
        
        elif self.waveform == Waveforms.LINEAR_UNIDIRECTIONAL:
            # TODO clean this up
            num_up = round(exact_samples_per_period * self.ramp_time_fraction)
            A = self.amplitude
            F = num_up / waveform_length # fill fraction (aka duty cycle, %scan with usable data)
            F2 = (F + 1) / 2
            k = float(A) / (F*(F2**2 - F)) # acceleration constant

            # minus 0.5/waveform_length helps with some round-off issues when waveform length becomes large
            t0 = np.arange(0, F - 0.5/waveform_length, 1/waveform_length) # linear part
            t1 = np.arange(F, F2 - 0.5/waveform_length, 1/waveform_length) # flyback (negative acceleration)
            t2 = np.arange(t1[-1] + 1/waveform_length, 1 - 0.5/waveform_length, 1/waveform_length) # flyback (positive acceleration)

            parts = (                                       # Smooth raster:
                A/F * t0,                                   # linear part
                -k*t1**2/2 - k*F**2/2 + k*F*t1 + A/F*t1,    # flyback I  (-accel)
                k*t2**2/2 + A*t2/F - k*t2 + k/2 - A/F       # flyback II (+accel)
            )
            waveform = np.concatenate(parts, axis=0) - A/2 # minus A/2 to center around 0 degrees (rather than 0 to +A)
        
        elif self.waveform == Waveforms.LINEAR_BIDIRECTIONAL:
            T   = waveform_length
            rtf = self.ramp_time_fraction
            A   = float(self.amplitude) / 2 # half pk-pk amplitude
            w0  = (T/4) * (1 - rtf)
            w1  = (T/4) * (1 + rtf)
            w2  = (T/4) * (3 - rtf)
            w3  = (T/4) * (3 + rtf)
            m   = 4 * A / (T * rtf)
            k   = 16 * A / (T**2 * rtf * (1-rtf))

            t0 = np.arange(0,  w0 - 0.5)
            t1 = np.arange(t0[-1]+1, w1 - 0.5) # linear up ramp
            t2 = np.arange(t1[-1]+1, w2 - 0.5)
            t3 = np.arange(t2[-1]+1, w3 - 0.5) # linear down ramp
            t4 = np.arange(t3[-1]+1, T - 0.5)

            f0 = 0.5 * k * (t0**2 - w0**2) - A
            f1 = m * (t1 - w0) - A
            f2 = 0.5 * k * (w1**2 - t2**2) + 0.5 * k * T * (t2 - w1) + A
            f3 = m * (w2 - t3) + A
            f4 = 0.5 * k * (t4**2 - w3**2) + k * T * (w3 - t4) - A

            waveform = np.concatenate((f0,f1,f2,f3,f4), axis=0)
        
        else:
            raise RuntimeError(f"Unsupported waveform type {self.waveform}")

        # Shift phase
        shift_amount = round(-self.input_delay * sample_rate)
        if abs(shift_amount) > waveform_length:
            raise RuntimeError("Scanner input delay greater than line period. "
                               "Choose longer line period, or check input delay setting.")
        waveform = np.roll(waveform, shift=shift_amount)

        return waveform * self._volts_per_radian
    
    def generate_clock(self, sample_rate: units.SampleRate): 
        # TODO, njit this? parameters: waveform, amplitude, duty_cycle, waveform_length, samples_per_period
        """Returns a digital signal representing the line or frame clock."""
        # TODO, adjustable phase?
        exact_samples_per_period = sample_rate / self.frequency
        rearm_time = 0
        waveform_length = round(exact_samples_per_period - rearm_time * sample_rate)

        num_up = int(exact_samples_per_period * self.ramp_time_fraction) + 1

        clock = np.zeros((waveform_length,), dtype=np.bool)
        clock[:num_up] = True

        return clock
        
    # Intercept some setters so they do not change value of parameters during scan
    @GalvoScanner.frequency.setter
    def frequency(self, new_frequency: units.Frequency):
        if self._active:
            raise RuntimeError("Frequency is not adjustable while scanner is active.")
        else:
            GalvoScanner.frequency.__set__(self, new_frequency)

    @GalvoScanner.waveform.setter
    def waveform(self, new_waveform: Waveforms):
        if self._active:
            raise RuntimeError("Waveform type is not adjustable while scanner is active.")
        else:
            GalvoScanner.waveform.__set__(self, new_waveform)

    @GalvoScanner.ramp_time_fraction.setter
    def ramp_time_fraction(self, new_duty_cycle: float):
        if self._active:
            raise RuntimeError("Duty cycle is not adjustable while scanner is active.")
        else:
            GalvoScanner.ramp_time_fraction.__set__(self, new_duty_cycle)

    # Are adjustable: offset, amplitude
        

class GalvoWaveformWriter(threading.Thread):
    """
    Manages writing analog waveform for single fast galvo, or both waveforms in 
    galvo-galvo configurations.
    """

    def __init__(self, 
                 fast_scanner: 'FastGalvoScannerViaNI | None' = None, 
                 slow_scanner: 'SlowGalvoScannerViaNI | None' = None,
                 rearm_time: units.Time = units.Time(0)
                 ):
        super().__init__()
        self._stop_event = threading.Event()

        self._fast_scanner = fast_scanner
        self._slow_scanner = slow_scanner

        if not isinstance(rearm_time, units.Time):
            raise ValueError("Rearm time must be set with a units.Time object")
        if rearm_time < 0:
            raise ValueError("Rearm time must be greater than or equal to 0 seconds")
        self._rearm_time = rearm_time

        if self._fast_scanner:
            if not isinstance(self._fast_scanner, FastGalvoScannerViaNI):
                raise ValueError("Wrong type of fast scanner passed to "
                                 "GalvoWaveformWriter")
            
            # If a fast scanner exists, use its AO task and its sample rate 
            self._sample_rate = units.SampleRate(self._fast_scanner._ao_sample_rate)
            self._ao_writer = AnalogMultiChannelWriter(self._fast_scanner._ao_task.out_stream)

        else:
            # If no fast scanner exist, then use the slow scanner and its sample rate
            self._sample_rate = units.SampleRate(self._slow_scanner._ao_task.timing.samp_clk_rate)
            self._ao_writer = AnalogMultiChannelWriter(self._slow_scanner._ao_task.out_stream)

        # Write once before starting the run loop
        waveforms = self.generate_waveforms()
        self._ao_writer.write_many_sample(waveforms)

    def _work(self):
        while not self._stop_event.is_set():
            try:
                waveforms = self.generate_waveforms()
                self._ao_writer.write_many_sample(waveforms)

                print("Wrote waveform with shape", waveforms.shape)
                # TODO shorter timeout and time out exception

            except nidaqmx.errors.DaqWriteError as e:
                # the task has not started yet, wait a while
                print("Skipped writing waveform")
                #print(e)
                time.sleep(units.Time('2 ms'))

    def stop(self):
        self._stop_event.set()

    def generate_waveforms(self): 
        fast_scanner = self._fast_scanner
        slow_scanner = self._slow_scanner

        if fast_scanner:
            fast_waveform = fast_scanner.generate_waveform(self._sample_rate)
            fast_waveform = np.tile(fast_waveform, reps=fast_scanner._periods_per_write)
            
            if slow_scanner:
                slow_waveform = slow_scanner.generate_waveform(self._sample_rate)
                return np.vstack((fast_waveform, slow_waveform))
            else:
                return np.vstack((fast_waveform,))
        
        else:
            slow_waveform = slow_scanner.generate_waveform(
                sample_rate=self._sample_rate,
                rearm_time=self._rearm_time # Rearm is only applicable to external line clock-synced acquisitions (e.g. resonant scanner)
            )
            return np.vstack((slow_waveform,))

        
    @property
    def _samples_per_period(self) -> float:
        """
        Exact number (e.g. fractional) of output sample clock periods per fast 
        scanner period (if available), or slow scanner (if not).
        """
        if self._fast_scanner:
            return self._sample_rate / self._fast_scanner.frequency
        else:
            return self._sample_rate / self._slow_scanner.frequency
    
    @property
    def _waveform_length(self) -> int:
        """
        Number of samples in output waveform. This is reduced by the rearm time
        and rounded to an integer. `_waveform_length` & `samples_per_period` will
        deviate when there is a non-zero rearm. For continuous AO generation,
        the rearm time should be 0, but for retriggered finite AO generation,
        it must be considered.
        """
        return round(self._samples_per_period - self._rearm_time * self._sample_rate)



class FastGalvoScannerViaNI(GalvoScannerViaNI, FastRasterScanner):    
    def __init__(self, 
                 ao_clock_source: str | None = None,
                 ao_start_trigger: str | None = "internal",
                 line_clock_channel: str | None = None, 
                 **kwargs):
        
        super().__init__(**kwargs) # analog control channel and voltage limits

        if ao_clock_source == "internal":
            self._ao_clock_source = None # codes for use internal clock
        else:
            self._ao_clock_source = validate_ni_channel(ao_clock_source)

        if ao_start_trigger == "internal":
            self._ao_start_trigger = None # codes for immediate start
        else:
            self._ao_start_trigger = validate_ni_channel(ao_start_trigger)

        self._line_clock_channel = validate_ni_channel(line_clock_channel)

        self._slow_scanner: SlowGalvoScannerViaNI = None

        self._co_task = None

    def start(self, 
              digitizer: dgtz.Digitizer,
              pixels_per_period: int, # e.g. pixels per line # TODO, samples per period??
              periods_per_write: int, # e.g. lines per frame
              adjustable = False # allows changing amplitude & offset mid-acquisition, but may be taxing for very high frame rates
              ):
        self._active = True

        try:
           
            # Validate pixels per period
            if (not isinstance(pixels_per_period, int)) or (pixels_per_period < 1):
                raise ValueError("Pixels per period must be a positive integer")
            self._pixels_per_period = pixels_per_period

            # Validate periods per write
            if (not isinstance(periods_per_write, int)) or (periods_per_write < 1):
                raise ValueError("Periods per write must be a positive integer")
            self._periods_per_write = periods_per_write

            # Set up AO (galvo command waveform) and DO (line clock) tasks
            self._ao_task = nidaqmx.Task("Galvo waveforms") # for analog galvo command waveforms
            self._ao_task.ao_channels.add_ao_voltage_chan(
                physical_channel=self._analog_control_channel
            )

            self._do_task = nidaqmx.Task("Line and frame clocks") # for digital clocks
            self._do_task.do_channels.add_do_chan(
                lines=self._line_clock_channel,
                line_grouping=LineGrouping.CHAN_PER_LINE
            )

            # If there is a slow scanner, then add its analog channel and frame clock line
            if self._slow_scanner:
                # Add more AO & DO channels
                self._ao_task.ao_channels.add_ao_voltage_chan(
                    physical_channel=self._slow_scanner._analog_control_channel
                )
                self._do_task.do_channels.add_do_chan(
                    lines=self._slow_scanner._frame_clock_channel,
                    line_grouping=LineGrouping.CHAN_PER_LINE
                )
            
            # Insert frequency divider CO if sample rate too high
            n_channels = 2 if self._slow_scanner else 1
            max_ao_rate = min(
                get_max_ao_rate(self._device, n_channels), self.AO_RATE_LIMIT
            ) 
            if self._ao_sample_rate > max_ao_rate:
                if self._ao_clock_source is None:
                    # if user indicates using built-in AO clock, but sets rate too high
                    raise RuntimeError(f"Can't set AO clock={self._ao_sample_rate}, " 
                                       f"higher than device maximum: {max_ao_rate}")
                # Counter Out task to divide sample clock frequency (useful for using S-series digitizers where max rate AI >> AO)
                div_factor = int(2**np.ceil(np.log2(self._ao_sample_rate / max_ao_rate)))
                div_factor = max(div_factor, 4) # Must divide by at least 4X (NIDAQmx limitation on number of high ticks)
                high_ticks = div_factor // 2

                self._co_task = nidaqmx.Task("AI clock frequency divided")
                freq_div_ch = self._co_task.co_channels.add_co_pulse_chan_ticks(
                    counter         = CounterRegistry.allocate_counter(self._device.name),
                    source_terminal = f"/{self._device.name}/ai/SampleClock",
                    high_ticks      = high_ticks,
                    low_ticks       = div_factor - high_ticks
                )
                self._co_task.timing.cfg_implicit_timing(
                    sample_mode     = AcquisitionType.CONTINUOUS,
                    samps_per_chan  = 64 # just selected arbitarily, OK?
                )

                self._ao_clock_source = freq_div_ch.co_pulse_term
                self._ao_sample_rate = self._ao_sample_rate / div_factor
            
            # Set timing/sampling clock
            samples_per_period = round(self._ao_sample_rate / self.frequency)
            self._ao_task.timing.cfg_samp_clk_timing(
                rate            = self._ao_sample_rate,
                source          = self._ao_clock_source, # see above about frequency divider counter
                sample_mode     = AcquisitionType.CONTINUOUS,
                samps_per_chan  = self._periods_per_write * samples_per_period
            )
            self._do_task.timing.cfg_samp_clk_timing(
                rate            = self._ao_sample_rate,
                source          = self._ao_clock_source, # see above about frequency divider counter
                sample_mode     = AcquisitionType.CONTINUOUS,
                samps_per_chan  = self._periods_per_write * samples_per_period 
            )

            # Set start trigger
            if (self._ao_start_trigger is None) and (self._ao_clock_source is None): 
                # meaning that AO triggers itself (e.g. Alazar G-G scanning)
                self._do_task.triggers.start_trigger.cfg_dig_edge_start_trig(
                    trigger_source=f"/{self._device.name}/ao/StartTrigger"
                )
            else:
                # AO clocks & triggers off AI (e.g. NI AI + G-G scanning) (or CO, if high sampling rate)
                # we can actually skip setting AO/DO start trigger because it is clocked off AI (or CO)
                pass

            if adjustable:
                # Requires constantly supplying new waveform data, no regeneration
                self._ao_task.out_stream.regen_mode = \
                    RegenerationMode.DONT_ALLOW_REGENERATION

            # Set up the waveform writer worker
            self._writer = GalvoWaveformWriter(
                fast_scanner = self, 
                slow_scanner = self._slow_scanner
            ) 
            if adjustable: self._writer.start()
                
            # Write clocks
            line_clock = self.generate_clock(self._ao_sample_rate)
            line_clock = np.tile(line_clock, reps=self._periods_per_write)

            if self._slow_scanner:
                frame_clock = self._slow_scanner.generate_clock(self._ao_sample_rate)
                clocks = np.vstack((line_clock, frame_clock))
            else:
                clocks = np.vstack((line_clock,))
            self._do_task.write(clocks)

            # Start tasks 
            if self._co_task: self._co_task.start()
            self._do_task.start() 
            self._ao_task.start()

            # Start AI (ignored if already started)
            if not digitizer.is_active:
                digitizer.acquire.start()

        except Exception:
            self._active = False # actually not active
            raise # re-raise the ValueError so it propagates
        
    def pair_slow_galvo(self, slow_scanner: 'SlowGalvoScannerViaNI'):
        if isinstance(slow_scanner, SlowGalvoScannerViaNI):
            self._slow_scanner = slow_scanner
        else:
            raise ValueError("Must pass instance of SlowGalvoScannerViaNI")

    def stop(self):
        if self._writer.is_alive():
            self._writer.stop()
            self._writer.join() # Wait until done

        self._do_task.stop()
        self._ao_task.stop()
        
        self._do_task.close()
        self._ao_task.close()

        if self._co_task:
            self._co_task.stop()
            CounterRegistry.free_counter(
                counter_name=self._co_task.co_channels[0].physical_channel.name
            )
            self._co_task.close()

        self._active = False
        

class SlowGalvoScannerViaNI(GalvoScannerViaNI, SlowRasterScanner):
    def __init__(self,
                 fast_scanner: FastRasterScanner, 
                 external_line_clock_channel: str | None = None, # to sync to external line clock (e.g. a resonant scanner)
                 external_start_trigger_channel: str | None = None,
                 frame_clock_channel: str | None = None, 
                 **kwargs):
        
        super().__init__(**kwargs) # analog control channel and voltage limits
        
        if isinstance(fast_scanner, FastGalvoScannerViaNI):
            self._external_line_clock_channel = None
            self._external_start_trigger_channel = None
            self._ao_sample_rate = None # for Galvo-Galvo scanning, AO rate = pixel rate
            self._fast_scanner = fast_scanner
            # pass itself as reference to the fast scanner--fast scanner will know to manage AO/DO tasks
            self._fast_scanner.pair_slow_galvo(self)
        
        elif isinstance(fast_scanner, (ResonantScannerViaNI, PolygonScannerViaNI)):
            if external_line_clock_channel is None:
                raise RuntimeError("Res-galvo/polygon-galvo scanning must specify a line clock channel for synchronization.")
            self._external_line_clock_channel = validate_ni_channel(external_line_clock_channel)

            if external_start_trigger_channel is not None:
                self._external_start_trigger_channel = validate_ni_channel(external_start_trigger_channel)
            else:
                self._external_start_trigger_channel = None

            if self._ao_sample_rate is None:
                raise RuntimeError("Res-galvo/polygon-galvo scanning must specify an analog out sample rate on slow scanner")
            
            device = get_device(self._analog_control_channel.split('/')[0])
            low_sr = get_min_ao_rate(device) # this check might be redundant?
            high_sr = get_max_ao_rate(device)
            if not low_sr < self._ao_sample_rate < high_sr:
                raise ValueError(f"AO sample rate outside required bounds: low: "
                                 f"{low_sr}, high {high_sr}, got {self._ao_sample_rate}")

            self._fast_scanner = fast_scanner

        else:
            raise ValueError("Unsupported fast scanner type for SlowGalvoScannerViaNI")
        
        if frame_clock_channel is None:
            self._frame_clock_channel = None
        else:
            self._frame_clock_channel = validate_ni_channel(frame_clock_channel)
        
    def start(self,
              periods_per_frame: int | None = None,
              adjustable = False): # allows changing amplitude & offset mid-acquisition, but may be taxing for very high frame rates
        
        self._active = True

        try:
            # If external line clock specified, the fast axis is free-running 
            # (doesn't require explicit analog control signal, generate only the slow axis waveform)
            if self._external_line_clock_channel:
                if not isinstance(periods_per_frame, int) or periods_per_frame < 1:
                    raise ValueError("Periods per frame must be a positive integer")
                
                if self._ao_sample_rate is None:
                    raise RuntimeError("Slow axis galvo must specify analog out sample rate.")
                
                n_periods = self._fast_scanner.frequency / self.frequency
                rearm_periods = self._fast_scanner.frequency_error * n_periods
                rearm_time = units.Time(rearm_periods / self._fast_scanner.frequency) 

                self._fclock_task = nidaqmx.Task("Frame clock")

                high_ticks = round(self.ramp_time_fraction * periods_per_frame)
                fclk_ch = self._fclock_task.co_channels.add_co_pulse_chan_ticks(
                    counter         = CounterRegistry.allocate_counter(self._device.name),
                    source_terminal = self._external_line_clock_channel,
                    low_ticks       = periods_per_frame - high_ticks, 
                    high_ticks      = high_ticks
                )
                if self._external_start_trigger_channel is not None:
                    # use when digitizer can not provide trigger out synced to real record acquisitions
                    # (e.g. Teledyne)
                    self._fclock_task.triggers.start_trigger.cfg_dig_edge_start_trig(
                        trigger_source  = self._external_start_trigger_channel
                    )
                else:
                    # task will start immediately rather than wait for external trigger
                    # used when digitizer can provide trigger out pulses synced with actual acquistion 
                    # (e.g. Alazar AuxIO TriggerOut mode)
                    pass 

                fclk_ch.co_pulse_term = self._frame_clock_channel

                self._fclock_task.timing.cfg_implicit_timing(
                    sample_mode=AcquisitionType.CONTINUOUS,
                    samps_per_chan=periods_per_frame
                )

                # The AO task is a retriggered finite arbitrary wave generation,
                # internally clocked but retriggering on each frame clock pulse
                self._ao_task = nidaqmx.Task("Slow galvo waveform")
                self._ao_task.ao_channels.add_ao_voltage_chan(
                    physical_channel=self._analog_control_channel
                )
                self._ao_task.timing.cfg_samp_clk_timing(
                    rate=self._ao_sample_rate,
                    sample_mode=AcquisitionType.FINITE,
                    samps_per_chan=self.generate_waveform(self._ao_sample_rate, rearm_time).shape[0]
                )
                self._ao_task.triggers.start_trigger.cfg_dig_edge_start_trig(
                    trigger_source=self._frame_clock_channel
                )
                self._ao_task.triggers.start_trigger.retriggerable = True

                if adjustable:
                    # To adjust amplitude and offset mid-acquisition
                    self._ao_task.out_stream.regen_mode = \
                        RegenerationMode.DONT_ALLOW_REGENERATION
                    
                # Set up the waveform writer worker
                self._writer = GalvoWaveformWriter(
                    slow_scanner=self,
                    rearm_time=rearm_time
                ) 
                if adjustable:
                    self._writer.start()
                self._ao_task.start()
                self._fclock_task.start()

            else:
                # If no external line clock, then assume this is the slow axis of 
                # galvo-galvo pair -> Fast axis will manage all AO signals
                pass
                
        except:
            # start failed, so revert the _active flag, propagate the error up with 'raise'
            self._active = False
            raise

    def stop(self):
        self._active = False

        if self._external_line_clock_channel:
            self._fclock_task.stop()
            CounterRegistry.free_counter(self._fclock_task.channel_names[0])
            self._fclock_task.close()

            self._ao_task.stop()
            self._ao_task.close()

