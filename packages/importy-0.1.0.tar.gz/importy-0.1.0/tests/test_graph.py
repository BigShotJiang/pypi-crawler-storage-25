from pathlib import Path

import pytest

from pyimports.graph import InvalidInputError, build_graph, detect_cycles, find_importers, graph_insights


def write(path: Path, content: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")


def test_build_graph_directory_and_classification(tmp_path: Path) -> None:
    write(tmp_path / "app.py", "import os\nimport requests\nimport pkg.util\n")
    write(tmp_path / "pkg" / "__init__.py", "")
    write(tmp_path / "pkg" / "util.py", "import json\n")

    graph = build_graph(str(tmp_path))
    assert "app.py" in graph
    assert any(edge["module"] == "pkg.util" and edge["type"] == "local" for edge in graph["app.py"])
    assert any(edge["module"] == "os" and edge["type"] == "stdlib" for edge in graph["app.py"])


def test_build_graph_rejects_non_py_file(tmp_path: Path) -> None:
    target = tmp_path / "note.txt"
    target.write_text("hello", encoding="utf-8")
    with pytest.raises(InvalidInputError):
        build_graph(str(target))


def test_detect_cycles(tmp_path: Path) -> None:
    write(tmp_path / "a.py", "import b\n")
    write(tmp_path / "b.py", "import a\n")
    graph = build_graph(str(tmp_path))
    cycles = detect_cycles(graph)
    assert cycles


def test_find_importers(tmp_path: Path) -> None:
    write(tmp_path / "main.py", "import service\n")
    write(tmp_path / "service.py", "")
    graph = build_graph(str(tmp_path))
    importers = find_importers(graph, "service")
    assert "main.py" in importers


def test_graph_insights_contains_expected_sections(tmp_path: Path) -> None:
    write(tmp_path / "main.py", "import pandas\nimport internal\n")
    write(tmp_path / "internal.py", "")
    graph = build_graph(str(tmp_path))
    insights = graph_insights(graph)
    assert "top_fan_out" in insights
    assert "heavy_imports_by_file" in insights
