from pathlib import Path

from typer.testing import CliRunner

from pyimports.cli import app


runner = CliRunner()


def write(path: Path, content: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")


def test_help_has_minimal_options() -> None:
    result = runner.invoke(app, ["--help"])
    assert result.exit_code == 0
    assert "--install-completion" not in result.output
    assert "graph" in result.output
    assert "doctor" in result.output


def test_graph_json_output(tmp_path: Path) -> None:
    write(tmp_path / "main.py", "import os\n")
    result = runner.invoke(app, ["graph", str(tmp_path), "--format", "json"])
    assert result.exit_code == 0
    assert '"main.py"' in result.output


def test_cycle_alias_works(tmp_path: Path) -> None:
    write(tmp_path / "a.py", "import b\n")
    write(tmp_path / "b.py", "import a\n")
    result = runner.invoke(app, ["cycle", str(tmp_path)])
    assert result.exit_code == 0


def test_graph_missing_path_error() -> None:
    result = runner.invoke(app, ["graph", "missing/path.py"])
    assert result.exit_code != 0
    assert "Path not found" in result.output
