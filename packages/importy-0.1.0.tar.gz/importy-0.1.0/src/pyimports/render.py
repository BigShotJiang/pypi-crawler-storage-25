from collections import Counter
import json

from rich import print
from rich.panel import Panel
from rich.table import Table
from rich.tree import Tree


TYPE_STYLE = {
    "local": "bold cyan",
    "stdlib": "green",
    "third_party": "magenta",
    "unresolved": "bold red",
}


def _type_label(import_type: str) -> str:
    style = TYPE_STYLE.get(import_type, "white")
    return f"[{style}]{import_type}[/{style}]"


def render_graph(graph: dict):
    total_imports = 0
    counts: Counter[str] = Counter()

    for imports in graph.values():
        for imp in imports:
            total_imports += 1
            counts[imp["type"]] += 1

    summary = Table.grid(padding=(0, 2))
    summary.add_column(style="bold")
    summary.add_column()
    summary.add_row("Files", str(len(graph)))
    summary.add_row("Imports", str(total_imports))
    summary.add_row("Local", str(counts["local"]))
    summary.add_row("Stdlib", str(counts["stdlib"]))
    summary.add_row("Third-party", str(counts["third_party"]))
    summary.add_row("Unresolved", str(counts["unresolved"]))
    print(Panel(summary, title="pyimports summary", expand=False))

    for root, imports in sorted(graph.items()):
        tree = Tree(f"[bold]{root}[/bold]")

        for imp in imports:
            module = imp["module"]
            import_type = imp["type"]
            label = f"{module} ({_type_label(import_type)})"
            branch = tree.add(label)

            if import_type == "local":
                file_guess = module.replace(".", "/") + ".py"
                package_guess = module.replace(".", "/") + "/__init__.py"
                local_candidates = [k for k in graph.keys() if k.endswith(file_guess) or k.endswith(package_guess)]
                if local_candidates:
                    branch.add(f"[dim]-> {local_candidates[0]}[/dim]")

        print(tree)


def render_graph_json(graph: dict) -> None:
    print(json.dumps(graph, indent=2, sort_keys=True))


def render_cycles(cycles: list[list[str]]) -> None:
    if not cycles:
        print("[green]No circular local dependencies detected.[/green]")
        return

    table = Table(title="Circular dependencies", show_header=True, header_style="bold red")
    table.add_column("#", style="bold")
    table.add_column("Cycle path")

    for index, cycle in enumerate(cycles, start=1):
        table.add_row(str(index), " -> ".join(cycle))

    print(table)


def render_doctor_report(cycles: list[list[str]], insights: dict) -> None:
    print(Panel("Dependency health report", title="pyimports doctor", expand=False))

    if cycles:
        print("[bold red]High:[/bold red] Circular dependencies detected")
        for cycle in cycles[:5]:
            print(f"  - {' -> '.join(cycle)}")
    else:
        print("[green]High:[/green] No local circular dependencies detected")

    unresolved_by_file = insights.get("unresolved_by_file", {})
    unresolved_count = sum(len(v) for v in unresolved_by_file.values())
    if unresolved_count:
        print(f"[bold yellow]Medium:[/bold yellow] {unresolved_count} unresolved imports across {len(unresolved_by_file)} files")
        for file_name, modules in list(unresolved_by_file.items())[:5]:
            print(f"  - {file_name}: {', '.join(modules[:4])}")
    else:
        print("[green]Medium:[/green] No unresolved imports")

    top_hubs = insights.get("top_local_in_degree", [])
    if top_hubs:
        print("[bold cyan]Info:[/bold cyan] Most depended-on local modules")
        for module_file, indegree in top_hubs:
            print(f"  - {module_file} ({indegree} incoming local imports)")

    top_third_party = insights.get("top_third_party", [])
    if top_third_party:
        print("[bold magenta]Info:[/bold magenta] Most used third-party imports")
        for module_name, uses in top_third_party:
            print(f"  - {module_name} ({uses} references)")

    top_fan_out = insights.get("top_fan_out", [])
    if top_fan_out:
        print("[bold]Suggestion:[/bold] Files with high dependency fan-out")
        for file_name, count in top_fan_out:
            print(f"  - {file_name} ({count} imports)")

    heavy_imports = insights.get("heavy_imports_by_file", {})
    if heavy_imports:
        print("[bold yellow]Perf hint:[/bold yellow] Potentially heavy top-level imports")
        for file_name, modules in list(heavy_imports.items())[:5]:
            print(f"  - {file_name}: {', '.join(sorted(set(modules)))}")

    layers = insights.get("layers", [])
    if layers:
        print("[bold]Architecture:[/bold] Top directory layers in scan")
        for layer_name, file_count in layers[:8]:
            print(f"  - {layer_name}: {file_count} files")


def render_importers(target: str, importers: list[str]) -> None:
    if not importers:
        print(f"[yellow]No importers found for '{target}'.[/yellow]")
        return
    print(f"[bold]Importers of {target}:[/bold]")
    for item in importers:
        print(f"  - {item}")


def render_import_timing(rows: list[dict[str, float | str]]) -> None:
    if not rows:
        print("[yellow]No import timing rows parsed.[/yellow]")
        return

    table = Table(title="Import time profile", show_header=True, header_style="bold")
    table.add_column("#", style="bold")
    table.add_column("Module")
    table.add_column("Self (ms)", justify="right")
    table.add_column("Cumulative (ms)", justify="right")

    for index, row in enumerate(rows, start=1):
        table.add_row(
            str(index),
            str(row["module"]),
            f"{row['self_ms']:.3f}",
            f"{row['cumulative_ms']:.3f}",
        )

    print(table)
