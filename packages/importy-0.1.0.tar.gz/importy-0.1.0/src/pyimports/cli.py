import typer

from pyimports.graph import (
    GraphBuildError,
    build_graph,
    detect_cycles,
    find_importers,
    graph_insights,
)
from pyimports.render import render_cycles, render_doctor_report, render_graph, render_graph_json, render_importers
from pyimports.timing import TimingError, profile_import_time
from pyimports.render import render_import_timing

app = typer.Typer(add_completion=False)


@app.callback()
def main():
    """Visualize and inspect Python imports."""


@app.command()
def graph(
    path: str = typer.Argument(..., help="Python file or folder to scan"),
    output_format: str = typer.Option("tree", "--format", "-f", help="Output format: tree or json"),
    project_root: str | None = typer.Option(None, "--project-root", help="Project root for local import resolution"),
):
    try:
        import_graph = build_graph(path, project_root=project_root)
        if output_format == "json":
            render_graph_json(import_graph)
        elif output_format == "tree":
            render_graph(import_graph)
        else:
            raise typer.BadParameter("Invalid format. Supported values: tree, json", param_hint="--format")
    except GraphBuildError as exc:
        raise typer.BadParameter(str(exc), param_hint="path") from exc


@app.command()
def cycles(
    path: str = typer.Argument(..., help="Python file or folder to scan for local import cycles"),
    project_root: str | None = typer.Option(None, "--project-root", help="Project root for local import resolution"),
):
    try:
        import_graph = build_graph(path, project_root=project_root)
        cycle_paths = detect_cycles(import_graph)
        render_cycles(cycle_paths)
    except GraphBuildError as exc:
        raise typer.BadParameter(str(exc), param_hint="path") from exc


@app.command()
def doctor(
    path: str = typer.Argument(..., help="Python file or folder to analyze"),
    project_root: str | None = typer.Option(None, "--project-root", help="Project root for local import resolution"),
):
    try:
        import_graph = build_graph(path, project_root=project_root)
        cycles_found = detect_cycles(import_graph)
        insights = graph_insights(import_graph)
        render_doctor_report(cycles_found, insights)
    except GraphBuildError as exc:
        raise typer.BadParameter(str(exc), param_hint="path") from exc


@app.command("cycle", hidden=True)
def cycle_alias(
    path: str = typer.Argument(..., help="Alias for 'cycles'"),
    project_root: str | None = typer.Option(None, "--project-root", help="Project root for local import resolution"),
):
    cycles(path=path, project_root=project_root)


@app.command()
def why(
    target: str = typer.Argument(..., help="Module or file stem to find importers for"),
    path: str = typer.Argument(..., help="Python file or folder to scan"),
    project_root: str | None = typer.Option(None, "--project-root", help="Project root for local import resolution"),
):
    try:
        import_graph = build_graph(path, project_root=project_root)
        importers = find_importers(import_graph, target)
        render_importers(target, importers)
    except GraphBuildError as exc:
        raise typer.BadParameter(str(exc), param_hint="path") from exc


@app.command("time")
def time_imports(
    entry_file: str = typer.Argument(..., help="Python entry file to profile imports for"),
    top: int = typer.Option(20, "--top", "-n", help="Show top N slowest imports by cumulative time"),
):
    try:
        rows = profile_import_time(entry_file, limit=top)
        render_import_timing(rows)
    except TimingError as exc:
        raise typer.BadParameter(str(exc), param_hint="entry_file") from exc


if __name__ == "__main__":
    app()
