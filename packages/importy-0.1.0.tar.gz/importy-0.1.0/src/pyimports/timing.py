from __future__ import annotations

import subprocess
import sys
from pathlib import Path


class TimingError(Exception):
    """Base error for import timing failures."""


def profile_import_time(entry_file: str, limit: int = 20) -> list[dict[str, float | str]]:
    path = Path(entry_file).resolve()
    if not path.exists():
        raise TimingError(f"Path not found: {entry_file}")
    if path.suffix != ".py":
        raise TimingError("The time command expects a .py file entrypoint.")

    cmd = [sys.executable, "-X", "importtime", str(path)]
    result = subprocess.run(cmd, capture_output=True, text=True, check=False)
    if result.returncode != 0:
        stderr_tail = "\n".join(result.stderr.splitlines()[-6:])
        raise TimingError(f"Failed to run import profiler.\n{stderr_tail}")

    rows: list[dict[str, float | str]] = []
    for line in result.stderr.splitlines():
        if not line.startswith("import time:"):
            continue
        payload = line.replace("import time:", "", 1).strip()
        parts = [part.strip() for part in payload.split("|")]
        if len(parts) != 3:
            continue
        try:
            self_us = int(parts[0])
            cumulative_us = int(parts[1])
        except ValueError:
            continue
        module = parts[2]
        rows.append(
            {
                "module": module,
                "self_ms": round(self_us / 1000, 3),
                "cumulative_ms": round(cumulative_us / 1000, 3),
            }
        )

    rows.sort(key=lambda item: float(item["cumulative_ms"]), reverse=True)
    return rows[: max(1, limit)]
