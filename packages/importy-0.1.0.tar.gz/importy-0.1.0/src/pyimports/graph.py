from __future__ import annotations

from collections import defaultdict
import importlib.util
import sys
from pathlib import Path

from pyimports.parser import extract_imports


IGNORED_DIRS = {
    "__pycache__",
    ".git",
    ".hg",
    ".svn",
    ".mypy_cache",
    ".pytest_cache",
    ".ruff_cache",
    ".tox",
    ".venv",
    "venv",
    "env",
    "node_modules",
}


class GraphBuildError(Exception):
    """Base error for graph build problems."""


class PathNotFoundError(GraphBuildError):
    """Raised when the provided path does not exist."""


class InvalidInputError(GraphBuildError):
    """Raised when a provided path is not supported."""


def _iter_python_files(root: Path) -> list[Path]:
    python_files: list[Path] = []
    for path in root.rglob("*.py"):
        if any(part in IGNORED_DIRS for part in path.parts):
            continue
        python_files.append(path)
    return sorted(python_files)


def _discover_local_modules(project_root: Path) -> dict[str, Path]:
    modules: dict[str, Path] = {}
    package_prefix = project_root.name if (project_root / "__init__.py").exists() else None

    for path in _iter_python_files(project_root):

        relative_parts = path.relative_to(project_root).parts
        if not relative_parts:
            continue

        if path.name == "__init__.py":
            if len(relative_parts) == 1:
                continue
            module_name = ".".join(relative_parts[:-1])
        else:
            module_name = ".".join(relative_parts).removesuffix(".py")

        if module_name:
            modules[module_name] = path
            modules.setdefault(module_name.split(".")[0], path)
            if package_prefix:
                prefixed = f"{package_prefix}.{module_name}"
                modules[prefixed] = path
                modules.setdefault(package_prefix, project_root / "__init__.py")

    return modules


def _classify_import(module_name: str, local_modules: dict[str, Path]) -> str:
    top = module_name.split(".")[0]

    if module_name in local_modules or top in local_modules:
        return "local"

    if top in sys.stdlib_module_names:
        return "stdlib"

    spec = importlib.util.find_spec(top)
    if spec is None:
        return "unresolved"

    origin = spec.origin or ""
    if "site-packages" in origin or "dist-packages" in origin:
        return "third_party"

    return "stdlib"


def build_graph(entry_path: str, project_root: str | None = None) -> dict:
    entry = Path(entry_path).resolve()
    if not entry.exists():
        raise PathNotFoundError(f"Path not found: {entry_path}")

    resolved_project_root: Path
    if project_root is not None:
        resolved_project_root = Path(project_root).resolve()
        if not resolved_project_root.exists() or not resolved_project_root.is_dir():
            raise InvalidInputError(f"Invalid project root directory: {project_root}")
    elif entry.is_dir():
        resolved_project_root = entry
    else:
        resolved_project_root = entry.parent

    if entry.is_dir():
        start_files = _iter_python_files(entry)
        if not start_files:
            raise InvalidInputError(f"No Python files found in directory: {entry_path}")
    else:
        if entry.suffix != ".py":
            raise InvalidInputError("Only .py files are supported when passing a single file path.")
        start_files = [entry]
        if resolved_project_root not in entry.parents and resolved_project_root != entry.parent:
            raise InvalidInputError("Provided file is not inside the project root.")

    local_modules = _discover_local_modules(resolved_project_root)

    graph: dict[str, list[dict[str, str]]] = {}
    visited: set[Path] = set()
    queue = list(start_files)

    while queue:
        current = queue.pop(0)
        if current in visited or not current.exists() or current.suffix != ".py":
            continue

        visited.add(current)
        imports = extract_imports(str(current))
        rel_current = str(current.relative_to(resolved_project_root))

        edges: list[dict[str, str]] = []
        for module_name in imports:
            import_type = _classify_import(module_name, local_modules)
            edge = {"module": module_name, "type": import_type}
            edges.append(edge)

            if import_type == "local":
                target = local_modules.get(module_name) or local_modules.get(module_name.split(".")[0])
                if target and target not in visited:
                    queue.append(target)

        graph[rel_current] = edges

    return graph


def detect_cycles(graph: dict[str, list[dict[str, str]]]) -> list[list[str]]:
    local_edges: dict[str, list[str]] = defaultdict(list)

    for source, imports in graph.items():
        for imp in imports:
            if imp["type"] != "local":
                continue

            module = imp["module"]
            file_guess = module.replace(".", "/") + ".py"
            package_guess = module.replace(".", "/") + "/__init__.py"
            candidates = [node for node in graph.keys() if node.endswith(file_guess) or node.endswith(package_guess)]
            if candidates:
                local_edges[source].append(candidates[0])

    cycles: list[list[str]] = []
    seen_cycle_keys: set[tuple[str, ...]] = set()
    visiting: set[str] = set()
    visited: set[str] = set()
    path_stack: list[str] = []

    def dfs(node: str) -> None:
        visiting.add(node)
        path_stack.append(node)

        for neighbor in local_edges.get(node, []):
            if neighbor in visiting:
                start_idx = path_stack.index(neighbor)
                cycle = path_stack[start_idx:] + [neighbor]
                cycle_key = tuple(sorted(set(cycle)))
                if cycle_key not in seen_cycle_keys:
                    seen_cycle_keys.add(cycle_key)
                    cycles.append(cycle)
            elif neighbor not in visited:
                dfs(neighbor)

        path_stack.pop()
        visiting.remove(node)
        visited.add(node)

    for node in graph.keys():
        if node not in visited:
            dfs(node)

    return cycles


def graph_insights(graph: dict[str, list[dict[str, str]]], limit: int = 5) -> dict:
    unresolved_by_file: dict[str, list[str]] = {}
    fan_out: list[tuple[str, int]] = []
    third_party_modules: dict[str, int] = defaultdict(int)
    local_in_degree: dict[str, int] = defaultdict(int)
    heavy_hits: dict[str, list[str]] = defaultdict(list)
    layer_counts: dict[str, int] = defaultdict(int)
    heavy_modules = {"pandas", "torch", "tensorflow", "transformers", "matplotlib", "sklearn"}

    for source, imports in graph.items():
        layer = source.split("\\")[0].split("/")[0]
        layer_counts[layer] += 1
        unresolved = [imp["module"] for imp in imports if imp["type"] == "unresolved"]
        if unresolved:
            unresolved_by_file[source] = sorted(unresolved)

        fan_out.append((source, len(imports)))

        for imp in imports:
            if imp["type"] == "third_party":
                third_party_modules[imp["module"]] += 1
            if imp["module"].split(".")[0] in heavy_modules:
                heavy_hits[source].append(imp["module"])
            if imp["type"] == "local":
                module = imp["module"]
                file_guess = module.replace(".", "/") + ".py"
                package_guess = module.replace(".", "/") + "/__init__.py"
                candidates = [node for node in graph.keys() if node.endswith(file_guess) or node.endswith(package_guess)]
                if candidates:
                    local_in_degree[candidates[0]] += 1

    return {
        "top_fan_out": sorted(fan_out, key=lambda x: x[1], reverse=True)[:limit],
        "top_local_in_degree": sorted(local_in_degree.items(), key=lambda x: x[1], reverse=True)[:limit],
        "top_third_party": sorted(third_party_modules.items(), key=lambda x: x[1], reverse=True)[:limit],
        "unresolved_by_file": unresolved_by_file,
        "heavy_imports_by_file": dict(heavy_hits),
        "layers": sorted(layer_counts.items(), key=lambda x: x[1], reverse=True),
    }


def find_importers(graph: dict[str, list[dict[str, str]]], target: str) -> list[str]:
    target_base = target.removesuffix(".py").replace("\\", "/").split("/")[-1]
    importers: list[str] = []

    for source, imports in graph.items():
        for imp in imports:
            module_name = imp["module"]
            top = module_name.split(".")[-1]
            if module_name == target or top == target or top == target_base:
                importers.append(source)
                break

    return sorted(importers)
