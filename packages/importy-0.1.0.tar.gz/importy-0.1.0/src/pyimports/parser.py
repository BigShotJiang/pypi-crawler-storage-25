import ast
from pathlib import Path


def extract_imports(file_path: str) -> list[str]:
    source = Path(file_path).read_text()
    tree = ast.parse(source)

    imports = set()

    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                imports.add(alias.name)

        elif isinstance(node, ast.ImportFrom):
            if node.module:
                imports.add(node.module)
            elif node.level > 0:
                for alias in node.names:
                    imports.add(alias.name)

    return sorted(imports)
