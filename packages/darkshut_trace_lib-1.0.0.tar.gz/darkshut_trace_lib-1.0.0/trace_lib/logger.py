"""命令式 API — start/end operation、log_call、log_verify"""

from __future__ import annotations

import logging
import time
from contextvars import ContextVar
from typing import Any

from .config import is_configured, is_enabled, VERIFY_COMMAND_PREFIX
from .db import get_connection, now_iso, today_str
from .serializer import safe_serialize, truncate_stdout

logger = logging.getLogger(__name__)

_INSERT_CALL_SQL = (
    "INSERT INTO calls "
    "(operation_id, called_at, command, params, exit_code, stdout, stderr, success, error, duration_ms) "
    "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
)

_INSERT_OP_SQL = (
    "INSERT INTO operations (started_at, tool, input) VALUES (?, ?, ?)"
)

_UPDATE_OP_SQL = (
    "UPDATE operations SET finished_at=?, success=?, output=?, error=?, duration_ms=? WHERE id=?"
)

_INSERT_OP_FULL_SQL = (
    "INSERT INTO operations "
    "(started_at, finished_at, tool, input, output, success, error, duration_ms) "
    "VALUES (?, ?, ?, ?, ?, ?, ?, ?)"
)

# 目前正在執行的 operation context（ContextVar 相容 asyncio concurrent 場景）
_op_id: ContextVar[int | None] = ContextVar("_op_id", default=None)
_op_day: ContextVar[str | None] = ContextVar("_op_day", default=None)


def start_operation(
    tool: str,
    *,
    input_data: dict[str, Any] | None = None,
) -> float:
    """開始追蹤一個操作，回傳 start_time 供 end_operation 計算耗時

    Args:
        tool: 操作名稱（如 webhook_notify、ssh_execute）
        input_data: 操作輸入參數

    Returns:
        float: 開始時間（monotonic），傳給 end_operation()
    """
    _op_day.set(today_str())

    conn = get_connection(_op_day.get())
    if not conn:
        return time.monotonic()

    try:
        cursor = conn.execute(
            _INSERT_OP_SQL,
            (now_iso(), tool, safe_serialize(input_data)),
        )
        conn.commit()
        _op_id.set(cursor.lastrowid)
    except Exception as exc:
        logger.warning("trace-lib start_operation 失敗: %s", exc)

    return time.monotonic()


def end_operation(
    start_time: float,
    *,
    output_data: dict[str, Any] | None = None,
    success: bool = True,
    error: str | None = None,
) -> None:
    """結束一個操作（與 start_operation 配對）

    Args:
        start_time: start_operation() 的回傳值
        output_data: 操作輸出結果
        success: 是否成功
        error: 錯誤訊息
    """
    conn = get_connection(_op_day.get())
    if not conn or _op_id.get() is None:
        _op_id.set(None)
        _op_day.set(None)
        return

    try:
        duration_ms = int((time.monotonic() - start_time) * 1000)
        conn.execute(
            _UPDATE_OP_SQL,
            (
                now_iso(),
                1 if success else 0,
                safe_serialize(output_data),
                error,
                duration_ms,
                _op_id.get(),
            ),
        )
        conn.commit()
    except Exception as exc:
        logger.warning("trace-lib end_operation 失敗: %s", exc)
    finally:
        _op_id.set(None)
        _op_day.set(None)


def log_call(
    command: str,
    *,
    params: str | dict[str, Any] | None = None,
    exit_code: int | None = None,
    stdout: str | None = None,
    stderr: str | None = None,
    success: bool = True,
    error: str | None = None,
    duration_ms: int | None = None,
) -> None:
    """記錄一次外部呼叫（自動綁定到目前的 operation）

    Args:
        command: 呼叫識別（如 ssh admin@host、gws sheets get）
        params: 呼叫參數
        exit_code: 程序退出碼
        stdout: 標準輸出（自動截斷）
        stderr: 標準錯誤（自動截斷）
        success: 是否成功
        error: 錯誤訊息
        duration_ms: 耗時毫秒
    """
    conn = get_connection(_op_day.get())
    if not conn:
        return

    try:
        conn.execute(
            _INSERT_CALL_SQL,
            (
                _op_id.get(),
                now_iso(),
                command,
                safe_serialize(params) if isinstance(params, dict) else params,
                exit_code,
                truncate_stdout(stdout),
                truncate_stdout(stderr),
                1 if success else 0,
                error,
                duration_ms,
            ),
        )
        conn.commit()
    except Exception as exc:
        logger.warning("trace-lib log_call 失敗: %s", exc)


def log_verify(
    name: str,
    *,
    expected: str,
    actual: str,
    passed: bool,
) -> None:
    """記錄一次驗證（寫入 calls 表，command = 'verify:{name}'）

    Args:
        name: 驗證函式名稱
        expected: 預期值
        actual: 實際值
        passed: 是否通過
    """
    log_call(
        command=f"{VERIFY_COMMAND_PREFIX}{name}",
        params={"expected": expected, "actual": actual},
        success=passed,
        error=None if passed else f"預期 {expected}，實際 {actual}",
    )


def log_operation(
    tool: str,
    *,
    input_data: dict[str, Any] | None = None,
    output_data: dict[str, Any] | None = None,
    success: bool = True,
    error: str | None = None,
    duration_ms: int | None = None,
) -> None:
    """一步完成的操作記錄（不需 start/end 配對）

    Args:
        tool: 操作名稱
        input_data: 操作輸入參數
        output_data: 操作輸出結果
        success: 是否成功
        error: 錯誤訊息
        duration_ms: 耗時毫秒
    """
    day = today_str()
    conn = get_connection(day)
    if conn is None:
        return
    try:
        now = now_iso()
        conn.execute(
            _INSERT_OP_FULL_SQL,
            (
                now, now, tool,
                safe_serialize(input_data),
                safe_serialize(output_data),
                1 if success else 0,
                error,
                duration_ms,
            ),
        )
        conn.commit()
    except Exception as exc:
        logger.warning("trace-lib log_operation 失敗: %s", exc)
