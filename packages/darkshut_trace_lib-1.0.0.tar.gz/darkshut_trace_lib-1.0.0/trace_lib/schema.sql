-- trace-lib 統一 schema（Python + TypeScript 共用）
-- 檔案命名：{TRACE_LOG_DIR}/{TRACE_PROJECT}-{YYYY-MM-DD}.db
-- 時間格式：YYYY-MM-DD HH:MM:SS（本地時區）

PRAGMA journal_mode = WAL;
PRAGMA foreign_keys = ON;

-- 主表：誰做了什麼、花多久、成功還是失敗
CREATE TABLE IF NOT EXISTS operations (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    started_at  TEXT NOT NULL,
    finished_at TEXT,
    tool        TEXT NOT NULL,
    input       TEXT,
    output      TEXT,
    success     INTEGER CHECK (success IS NULL OR success IN (0, 1)),  -- 1=成功, 0=失敗, NULL=尚未結束
    error       TEXT,
    duration_ms INTEGER
);

-- 子表：操作過程中的每次外部呼叫（SSH、API、CLI、驗證）
-- 出包時 SELECT id, called_at, command, params, success, error FROM calls WHERE operation_id = ? ORDER BY called_at
CREATE TABLE IF NOT EXISTS calls (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    operation_id  INTEGER REFERENCES operations(id) ON DELETE CASCADE,
    called_at     TEXT NOT NULL,
    command       TEXT NOT NULL,
    params        TEXT,
    exit_code     INTEGER,
    stdout        TEXT,
    stderr        TEXT,
    success       INTEGER CHECK (success IN (0, 1)),  -- 1=成功, 0=失敗
    error         TEXT,
    duration_ms   INTEGER
);

CREATE INDEX IF NOT EXISTS idx_calls_operation_id ON calls(operation_id);
