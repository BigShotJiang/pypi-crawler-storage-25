"""SQLite 連線管理 — 日期分檔、schema 建立、WAL 模式"""

from __future__ import annotations

import logging
import os
import sqlite3
import threading
from datetime import datetime
from pathlib import Path

from .config import get_log_dir, get_project, is_configured, is_enabled

logger = logging.getLogger(__name__)

# 連線快取：key = db 檔案路徑
_pool: dict[str, sqlite3.Connection] = {}
_pool_lock = threading.Lock()

SCHEMA_SEARCH_DEPTH = 6


def _find_schema() -> Path:
    """從 db.py 所在目錄逐層往上搜尋 schema.sql，相容原始碼與 Docker 容器結構"""
    current = Path(__file__).resolve().parent
    for _ in range(SCHEMA_SEARCH_DEPTH):
        candidate = current / "schema.sql"
        if candidate.exists():
            return candidate
        parent = current.parent
        if parent == current:  # 到達根目錄
            break
        current = parent
    # fallback：回傳預期路徑（即使不存在，後續 exists() 檢查會處理）
    return Path(__file__).resolve().parent.parent.parent / "schema.sql"


# lazy 初始化：首次使用時才搜尋 schema 路徑並讀取內容，避免模組載入時做磁碟 IO
_schema_loaded = False
_schema_path: Path | None = None
_schema_sql: str | None = None


def _get_schema_path() -> Path:
    """取得 schema.sql 路徑（lazy 初始化，首次呼叫時搜尋並快取）"""
    global _schema_path
    if _schema_path is None:
        _schema_path = _find_schema()
    return _schema_path


def _get_schema_sql() -> str | None:
    """取得 schema.sql 內容（lazy 初始化，首次呼叫時讀取並快取）"""
    global _schema_sql, _schema_loaded
    if _schema_loaded:
        return _schema_sql
    schema_path = _get_schema_path()
    if not schema_path.exists():
        _schema_loaded = True
        return None
    _schema_sql = schema_path.read_text(encoding="utf-8")
    _schema_loaded = True
    return _schema_sql


def today_str() -> str:
    """取得今天的日期字串（YYYY-MM-DD，本地時區）"""
    return datetime.now().strftime("%Y-%m-%d")


def _db_path(day: str | None = None) -> str | None:
    """組合 DB 檔案路徑：{log_dir}/{project}-{YYYY-MM-DD}.db"""
    log_dir = get_log_dir()
    project = get_project()
    if not log_dir or not project:
        return None
    day = day or today_str()
    return os.path.join(log_dir, f"{project}-{day}.db")


def now_iso() -> str:
    """取得當前時間（YYYY-MM-DD HH:MM:SS，本地時區）"""
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def _apply_schema(conn: sqlite3.Connection) -> None:
    """從 schema.sql 建表（過濾 PRAGMA，已手動執行）"""
    schema_sql = _get_schema_sql()
    if not schema_sql:
        return
    statements = [
        s.strip() for s in schema_sql.split(";")
        if s.strip() and not s.strip().upper().startswith("PRAGMA")
    ]
    for stmt in statements:
        conn.execute(stmt)
    conn.commit()


def _init_connection(path: str) -> sqlite3.Connection:
    """建立新 SQLite 連線並初始化（WAL、外鍵、schema）"""
    dir_path = os.path.dirname(path)
    if dir_path:
        os.makedirs(dir_path, exist_ok=True)
    conn = sqlite3.connect(path, timeout=5, check_same_thread=False)
    conn.execute("PRAGMA journal_mode = WAL")
    conn.execute("PRAGMA foreign_keys = ON")
    _apply_schema(conn)
    return conn


def get_connection(day: str | None = None) -> sqlite3.Connection | None:
    """取得 SQLite 連線（自動建表、WAL 模式、快取）

    Args:
        day: 指定日期（YYYY-MM-DD），None 表示今天

    Returns:
        sqlite3.Connection 或 None（未設定環境變數時）
    """
    if not is_enabled() or not is_configured():
        return None

    path = _db_path(day)
    if not path:
        return None

    with _pool_lock:
        if path in _pool:
            return _pool[path]

        try:
            conn = _init_connection(path)
            _pool[path] = conn
            return conn
        except Exception as exc:
            logger.warning("trace-lib DB 連線失敗: %s", exc)
            return None


def close_all() -> None:
    """關閉所有快取的連線"""
    with _pool_lock:
        for conn in _pool.values():
            try:
                conn.close()
            except Exception as exc:
                logger.warning("trace-lib 關閉連線失敗: %s", exc)
        _pool.clear()
