"""trace-lib — 跨語言操作日誌套件（Python 端）

使用方式：

    # 裝飾器
    from trace_lib import trace

    @trace
    def my_function(arg1, arg2):
        ...

    # 命令式
    from trace_lib import start_operation, end_operation, log_call, log_verify

    start = start_operation("my_tool", input_data={...})
    log_call("ssh admin@host", stdout="ok", success=True, duration_ms=100)
    log_verify("check_result", expected="ok", actual="ok", passed=True)
    end_operation(start, output_data={...})

環境變數：
    TRACE_LOG_DIR  — 日誌目錄（必填）
    TRACE_PROJECT  — 專案名稱（必填）
    TRACE_ENABLED  — 開關，預設 "1"（設 "0" 關閉）
"""

from .decorator import trace
from .logger import end_operation, log_call, log_operation, log_verify, start_operation
from .db import close_all

__all__ = [
    "trace",
    "start_operation",
    "end_operation",
    "log_call",
    "log_operation",
    "log_verify",
    "close_all",
]
