"""環境變數與常數"""

from __future__ import annotations

import os

# 環境變數名稱
ENV_LOG_DIR = "TRACE_LOG_DIR"
ENV_PROJECT = "TRACE_PROJECT"
ENV_ENABLED = "TRACE_ENABLED"

# 截斷上限
MAX_SERIALIZED_LENGTH = 2000
MAX_STDOUT_LENGTH = 2000

# 特殊 tool 名稱
BUILD_TOOL_NAME = "_build"
VERIFY_COMMAND_PREFIX = "verify:"


def is_enabled() -> bool:
    """檢查追蹤是否啟用（TRACE_ENABLED 設 '0' 關閉，預設啟用）"""
    return os.environ.get(ENV_ENABLED, "1") != "0"


def get_log_dir() -> str | None:
    """取得日誌目錄"""
    return os.environ.get(ENV_LOG_DIR) or None


def get_project() -> str | None:
    """取得專案名稱"""
    return os.environ.get(ENV_PROJECT) or None


def is_configured() -> bool:
    """檢查必要環境變數是否已設定"""
    return bool(get_log_dir() and get_project())
