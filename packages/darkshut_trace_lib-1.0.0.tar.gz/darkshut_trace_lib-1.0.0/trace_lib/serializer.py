"""安全序列化 — JSON 轉換、截斷、參數綁定"""

from __future__ import annotations

import inspect
import json

from .config import MAX_SERIALIZED_LENGTH, MAX_STDOUT_LENGTH


def safe_serialize(obj: object) -> str | None:
    """安全序列化物件為 JSON 字串，超長截斷，失敗時用 repr"""
    if obj is None:
        return None
    try:
        text = json.dumps(obj, ensure_ascii=False, default=str)
    except (TypeError, ValueError):
        text = repr(obj)

    if len(text) > MAX_SERIALIZED_LENGTH:
        return text[:MAX_SERIALIZED_LENGTH] + "...(截斷)"
    return text


def truncate_stdout(text: str | None, limit: int | None = None) -> str | None:
    """截斷 stdout/stderr 輸出"""
    if text is None:
        return None
    max_len = limit or MAX_STDOUT_LENGTH
    if len(text) > max_len:
        return text[:max_len] + "...(截斷)"
    return text


def serialize_args(func: object, args: tuple, kwargs: dict) -> str | None:
    """將函式參數序列化為 JSON（自動排除 self/cls）"""
    try:
        sig = inspect.signature(func)  # type: ignore[arg-type]
        bound = sig.bind(*args, **kwargs)
        bound.apply_defaults()
        params = dict(bound.arguments)
        # 排除 self / cls
        for key in ("self", "cls"):
            params.pop(key, None)
        return safe_serialize(params)
    except (TypeError, ValueError):
        return safe_serialize({"args": args, "kwargs": kwargs})
