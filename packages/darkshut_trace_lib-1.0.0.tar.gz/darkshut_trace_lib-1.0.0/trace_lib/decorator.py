"""@trace 裝飾器 — 自動記錄函式的 input/output/耗時/錯誤"""

from __future__ import annotations

import functools
import inspect
import logging
import sqlite3
import time
from typing import Callable, NamedTuple

from .config import is_configured, is_enabled
from .db import get_connection, now_iso, today_str
from .serializer import safe_serialize, serialize_args

logger = logging.getLogger(__name__)

_INSERT_SUCCESS_SQL = (
    "INSERT INTO operations (started_at, finished_at, tool, input, output, success, duration_ms) "
    "VALUES (?, ?, ?, ?, ?, 1, ?)"
)

_INSERT_ERROR_SQL = (
    "INSERT INTO operations (started_at, finished_at, tool, input, success, error, duration_ms) "
    "VALUES (?, ?, ?, ?, 0, ?, ?)"
)


def _write_op_success(
    conn: sqlite3.Connection,
    started_at: str,
    tool_name: str,
    input_data: str | None,
    result: object,
    elapsed_ms: int,
) -> None:
    try:
        conn.execute(
            _INSERT_SUCCESS_SQL,
            (started_at, now_iso(), tool_name, input_data, safe_serialize(result), elapsed_ms),
        )
        conn.commit()
    except Exception as write_exc:
        logger.warning("trace-lib _write_op_success 寫入失敗 [tool=%s started=%s]: %s", tool_name, started_at, write_exc)


def _write_op_error(
    conn: sqlite3.Connection,
    started_at: str,
    tool_name: str,
    input_data: str | None,
    exc: BaseException,
    elapsed_ms: int,
) -> None:
    try:
        conn.execute(
            _INSERT_ERROR_SQL,
            (started_at, now_iso(), tool_name, input_data, str(exc), elapsed_ms),
        )
        conn.commit()
    except Exception as write_exc:
        logger.warning("trace-lib _write_op_error 寫入失敗 [tool=%s started=%s]: %s", tool_name, started_at, write_exc)


class TraceContext(NamedTuple):
    """追蹤前置準備的結果"""
    conn: sqlite3.Connection
    started_at: str
    start_time: float
    input_data: str | None


def _prepare_trace(
    func: Callable, args: tuple, kwargs: dict,
) -> TraceContext | None:
    """共用前置準備：檢查啟用狀態、取得連線與計時資訊，回傳 None 表示略過追蹤"""
    if not is_enabled() or not is_configured():
        return None
    conn = get_connection(today_str())
    if not conn:
        return None
    return TraceContext(conn, now_iso(), time.monotonic(), serialize_args(func, args, kwargs))


def _finish_trace(ctx: TraceContext, tool_name: str, result: object = None, exc: Exception | None = None) -> None:
    """共用收尾邏輯：寫入成功或失敗記錄"""
    elapsed_ms = int((time.monotonic() - ctx.start_time) * 1000)
    if exc is None:
        _write_op_success(ctx.conn, ctx.started_at, tool_name, ctx.input_data, result, elapsed_ms)
    else:
        _write_op_error(ctx.conn, ctx.started_at, tool_name, ctx.input_data, exc, elapsed_ms)


def trace(func: Callable) -> Callable:
    """追蹤裝飾器 — 記錄函式呼叫到 SQLite operations 表

    tool 欄位格式：module.qualname（如 histock_db.execute.execute_write）
    支援同步與非同步函式。
    """
    tool_name = f"{func.__module__}.{func.__qualname__}"

    if inspect.iscoroutinefunction(func):
        @functools.wraps(func)
        async def async_wrapper(*args, **kwargs):
            ctx = _prepare_trace(func, args, kwargs)
            if not ctx:
                return await func(*args, **kwargs)
            try:
                result = await func(*args, **kwargs)
            except Exception as exc:
                _finish_trace(ctx, tool_name, exc=exc)
                raise
            _finish_trace(ctx, tool_name, result=result)
            return result

        return async_wrapper

    @functools.wraps(func)
    def sync_wrapper(*args, **kwargs):
        ctx = _prepare_trace(func, args, kwargs)
        if not ctx:
            return func(*args, **kwargs)
        try:
            result = func(*args, **kwargs)
        except Exception as exc:
            _finish_trace(ctx, tool_name, exc=exc)
            raise
        _finish_trace(ctx, tool_name, result=result)
        return result

    return sync_wrapper
