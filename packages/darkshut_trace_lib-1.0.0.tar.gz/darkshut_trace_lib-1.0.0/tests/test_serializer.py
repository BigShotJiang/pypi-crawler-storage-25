"""serializer 模組測試"""

import json
import pytest
from trace_lib.serializer import safe_serialize, truncate_stdout, serialize_args


class TestSafeSerialize:

    def test_should_serialize_dict(self):
        result = safe_serialize({"key": "value", "num": 42})
        assert json.loads(result) == {"key": "value", "num": 42}

    def test_should_return_none_for_none(self):
        assert safe_serialize(None) is None

    def test_should_truncate_long_string(self):
        result = safe_serialize("x" * 3000)
        assert result.endswith("...(截斷)")
        assert len(result) < 2100

    def test_should_preserve_chinese(self):
        result = safe_serialize({"名稱": "台積電"})
        assert "台積電" in result

    def test_should_handle_non_serializable(self):
        result = safe_serialize(object())
        assert result is not None and len(result) > 0


class TestTruncateStdout:

    def test_should_return_none_for_none(self):
        assert truncate_stdout(None) is None

    def test_should_not_truncate_short_text(self):
        assert truncate_stdout("hello") == "hello"

    def test_should_truncate_long_text(self):
        result = truncate_stdout("x" * 3000)
        assert result.endswith("...(截斷)")


class TestSerializeArgs:

    def test_should_map_positional_args(self):
        def add(a, b):
            pass
        result = serialize_args(add, (1, 2), {})
        assert json.loads(result) == {"a": 1, "b": 2}

    def test_should_exclude_self(self):
        def method(self, x):
            pass
        result = serialize_args(method, ("instance", 42), {})
        parsed = json.loads(result)
        assert "self" not in parsed
        assert parsed["x"] == 42

    def test_should_apply_defaults(self):
        def func(a, b=99):
            pass
        result = serialize_args(func, (1,), {})
        assert json.loads(result) == {"a": 1, "b": 99}
