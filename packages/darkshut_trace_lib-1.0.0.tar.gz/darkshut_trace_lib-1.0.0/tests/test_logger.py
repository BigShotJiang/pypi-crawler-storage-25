"""logger 模組測試 — 命令式 API"""

import sqlite3
import os
import time

import pytest

from trace_lib.db import get_connection, close_all, _pool
from trace_lib.logger import (
    start_operation,
    end_operation,
    log_call,
    log_verify,
    _op_id,
    _op_day,
)


@pytest.fixture(autouse=True)
def clean_env(monkeypatch, tmp_path):
    monkeypatch.setenv("TRACE_LOG_DIR", str(tmp_path))
    monkeypatch.setenv("TRACE_PROJECT", "test-project")
    monkeypatch.setenv("TRACE_ENABLED", "1")
    _pool.clear()
    # 重置 logger 的 ContextVar 狀態
    _op_id.set(None)
    _op_day.set(None)
    yield
    close_all()


class TestStartEndOperation:

    def test_should_insert_and_update_operation(self, tmp_path):
        start = start_operation("test_tool", input_data={"key": "value"})
        time.sleep(0.01)
        end_operation(start, output_data={"result": "ok"}, success=True)

        conn = get_connection()
        row = conn.execute("SELECT * FROM operations WHERE tool='test_tool'").fetchone()
        assert row is not None
        # id, started_at, finished_at, tool, input, output, success, error, duration_ms
        assert row[3] == "test_tool"
        assert row[6] == 1  # success
        assert row[8] >= 10  # duration_ms >= 10

    def test_should_record_failure(self, tmp_path):
        start = start_operation("fail_tool")
        end_operation(start, success=False, error="boom")

        conn = get_connection()
        row = conn.execute("SELECT success, error FROM operations WHERE tool='fail_tool'").fetchone()
        assert row[0] == 0
        assert row[1] == "boom"

    def test_should_be_noop_when_disabled(self, monkeypatch, tmp_path):
        monkeypatch.setenv("TRACE_ENABLED", "0")
        start = start_operation("noop_tool")
        end_operation(start)
        # 不應該有任何 DB 檔案產生
        db_files = [f for f in os.listdir(str(tmp_path)) if f.endswith(".db")]
        assert len(db_files) == 0


class TestLogCall:

    def test_should_bind_to_current_operation(self, tmp_path):
        start = start_operation("parent_tool")
        log_call(
            "ssh admin@host",
            params="ls -la",
            exit_code=0,
            stdout="total 0",
            success=True,
            duration_ms=50,
        )
        end_operation(start)

        conn = get_connection()
        call = conn.execute("SELECT * FROM calls").fetchone()
        assert call is not None
        # operation_id 應該不為 None
        assert call[1] is not None
        assert call[3] == "ssh admin@host"
        assert call[5] == 0  # exit_code

    def test_should_truncate_long_stdout(self, tmp_path):
        start = start_operation("truncate_test")
        log_call("cmd", stdout="x" * 5000, success=True)
        end_operation(start)

        conn = get_connection()
        call = conn.execute("SELECT stdout FROM calls").fetchone()
        assert len(call[0]) < 2100
        assert call[0].endswith("...(截斷)")


class TestLogVerify:

    def test_should_write_verify_call(self, tmp_path):
        start = start_operation("verify_test")
        log_verify("check_count", expected="10", actual="10", passed=True)
        end_operation(start)

        conn = get_connection()
        call = conn.execute("SELECT command, success FROM calls").fetchone()
        assert call[0] == "verify:check_count"
        assert call[1] == 1

    def test_should_record_failure_with_error(self, tmp_path):
        start = start_operation("verify_fail_test")
        log_verify("check_name", expected="Alice", actual="Bob", passed=False)
        end_operation(start)

        conn = get_connection()
        call = conn.execute("SELECT error FROM calls").fetchone()
        assert "Alice" in call[0]
        assert "Bob" in call[0]
