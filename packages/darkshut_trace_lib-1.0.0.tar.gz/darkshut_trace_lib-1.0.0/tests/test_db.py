"""db 模組測試 — 連線管理、日期分檔、schema 建立"""

import os
import sqlite3

import pytest

from trace_lib.db import get_connection, close_all, now_iso, _db_path, today_str, _pool


@pytest.fixture(autouse=True)
def clean_env(monkeypatch, tmp_path):
    """每個測試都用乾淨的環境變數和連線池"""
    monkeypatch.setenv("TRACE_LOG_DIR", str(tmp_path))
    monkeypatch.setenv("TRACE_PROJECT", "test-project")
    monkeypatch.setenv("TRACE_ENABLED", "1")
    _pool.clear()
    yield
    close_all()


class TestDbPath:

    def test_should_combine_dir_project_date(self, tmp_path):
        path = _db_path("2026-03-29")
        assert path == os.path.join(str(tmp_path), "test-project-2026-03-29.db")

    def test_should_use_today_when_no_day(self, tmp_path):
        path = _db_path()
        today = today_str()
        assert path == os.path.join(str(tmp_path), f"test-project-{today}.db")

    def test_should_return_none_when_not_configured(self, monkeypatch):
        monkeypatch.delenv("TRACE_LOG_DIR", raising=False)
        assert _db_path() is None


class TestGetConnection:

    def test_should_create_db_with_tables(self, tmp_path):
        conn = get_connection()
        assert conn is not None

        # 確認兩張表都存在
        tables = conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table' ORDER BY name"
        ).fetchall()
        table_names = [t[0] for t in tables]
        assert "operations" in table_names
        assert "calls" in table_names

    def test_should_cache_connection(self):
        conn1 = get_connection()
        conn2 = get_connection()
        assert conn1 is conn2

    def test_should_return_none_when_disabled(self, monkeypatch):
        monkeypatch.setenv("TRACE_ENABLED", "0")
        assert get_connection() is None

    def test_should_return_none_when_not_configured(self, monkeypatch):
        monkeypatch.delenv("TRACE_PROJECT", raising=False)
        assert get_connection() is None

    def test_should_create_separate_db_per_day(self, tmp_path):
        conn1 = get_connection("2026-03-28")
        conn2 = get_connection("2026-03-29")
        assert conn1 is not conn2
        assert os.path.exists(os.path.join(str(tmp_path), "test-project-2026-03-28.db"))
        assert os.path.exists(os.path.join(str(tmp_path), "test-project-2026-03-29.db"))


class TestTodayStr:

    def test_should_return_local_date(self):
        from datetime import datetime
        result = today_str()
        expected = datetime.now().strftime("%Y-%m-%d")
        assert result == expected

    def test_should_match_iso_format(self):
        result = today_str()
        assert len(result) == 10
        assert result[4] == "-"
        assert result[7] == "-"


class TestNowIso:

    def test_should_return_formatted_string(self):
        result = now_iso()
        # 格式：YYYY-MM-DD HH:MM:SS
        assert len(result) == 19
        assert result[4] == "-"
        assert result[10] == " "
