"""decorator 模組測試 — @trace 裝飾器"""

import asyncio
import sqlite3
import os

import pytest

from trace_lib.db import get_connection, close_all, _pool
from trace_lib.decorator import trace


@pytest.fixture(autouse=True)
def clean_env(monkeypatch, tmp_path):
    monkeypatch.setenv("TRACE_LOG_DIR", str(tmp_path))
    monkeypatch.setenv("TRACE_PROJECT", "test-project")
    monkeypatch.setenv("TRACE_ENABLED", "1")
    _pool.clear()
    yield
    close_all()


class TestSyncTrace:

    def test_should_record_success(self, tmp_path):
        @trace
        def add(a, b):
            return a + b

        result = add(1, 2)
        assert result == 3

        conn = get_connection()
        row = conn.execute("SELECT tool, success, output FROM operations").fetchone()
        assert row is not None
        assert "add" in row[0]
        assert row[1] == 1
        assert "3" in row[2]

    def test_should_record_error_and_reraise(self, tmp_path):
        @trace
        def fail():
            raise ValueError("boom")

        with pytest.raises(ValueError, match="boom"):
            fail()

        conn = get_connection()
        row = conn.execute("SELECT success, error FROM operations").fetchone()
        assert row[0] == 0
        assert "boom" in row[1]

    def test_should_preserve_function_metadata(self):
        @trace
        def documented():
            """這是文件"""
            pass

        assert documented.__name__ == "documented"
        assert documented.__doc__ == "這是文件"

    def test_should_be_noop_when_disabled(self, monkeypatch, tmp_path):
        monkeypatch.setenv("TRACE_ENABLED", "0")

        @trace
        def noop(x):
            return x * 2

        assert noop(5) == 10
        db_files = [f for f in os.listdir(str(tmp_path)) if f.endswith(".db")]
        assert len(db_files) == 0

    def test_should_record_input_args(self, tmp_path):
        @trace
        def greet(name, greeting="Hello"):
            return f"{greeting}, {name}"

        greet("World")

        conn = get_connection()
        row = conn.execute("SELECT input FROM operations").fetchone()
        assert "World" in row[0]
        assert "Hello" in row[0]


class TestAsyncTrace:

    def test_should_record_async_success(self, tmp_path):
        @trace
        async def async_add(a, b):
            return a + b

        result = asyncio.run(async_add(3, 4))
        assert result == 7

        conn = get_connection()
        row = conn.execute("SELECT tool, success FROM operations").fetchone()
        assert "async_add" in row[0]
        assert row[1] == 1

    def test_should_record_async_error(self, tmp_path):
        @trace
        async def async_fail():
            raise RuntimeError("async boom")

        with pytest.raises(RuntimeError, match="async boom"):
            asyncio.run(async_fail())

        conn = get_connection()
        row = conn.execute("SELECT success, error FROM operations").fetchone()
        assert row[0] == 0
        assert "async boom" in row[1]
