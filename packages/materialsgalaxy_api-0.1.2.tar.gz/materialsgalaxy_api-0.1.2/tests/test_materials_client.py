import inspect

import httpx
import pytest

from materialsgalaxy import MGClient
from materialsgalaxy.exceptions import MaterialsGalaxyAuthenticationError, MaterialsGalaxyNotFoundError
from materialsgalaxy.models import (
    CrystalStructure,
    DataSource,
    Ferroelectric,
    NonlinearOpticalProperties,
    PagedSummary,
    SingleCrystalGrowth,
    Summary,
    TopologicalProperties,
)


def make_json_transport(handler):
    def wrapped(request: httpx.Request) -> httpx.Response:
        status_code, payload = handler(request)
        return httpx.Response(status_code, json=payload, request=request)

    return httpx.MockTransport(wrapped)


def test_get_structure_sends_bearer_api_key_and_uses_materials_route():
    requests: list[httpx.Request] = []

    def handler(request: httpx.Request):
        requests.append(request)
        return 200, {
            "mg_id": "mg-1",
            "reduced_formula": "H2",
            "cif_str": "data_H2",
            "nsites": 1,
            "density": 0.99,
            "symmetry": {
                "crystal_system": "Tetragonal",
                "lattice_type": "Tetragonal",
                "number": 123,
                "symbol": "P4/mmm",
                "hall": "-P 4 2",
                "point_group": "4/mmm",
            },
            "lattice": {
                "matrix": [[1.0, 0.0, 0.0], [0.0, 1.0, 0.0], [0.0, 0.0, 1.0]],
                "a": 1.0,
                "b": 1.0,
                "c": 1.0,
                "alpha": 90.0,
                "beta": 90.0,
                "gamma": 90.0,
                "volume": 1.0,
            },
            "wyckoff_positions": [{"wyckoff_label": "1b", "element": "H", "position": [0.0, 0.0, 0.5]}],
            "oxidation_states": ["H0+"],
        }

    with MGClient(
        api_key="test-key",
        base_url="https://example.org/api/v1",
        transport=make_json_transport(handler),
    ) as client:
        result = client.materials.get_structure("MG-1")

    assert isinstance(result, CrystalStructure)
    assert result.mg_id == "mg-1"
    assert result.symmetry.symbol == "P4/mmm"
    assert str(requests[0].url) == "https://example.org/api/v1/materials/crystal_structure/mg-1"
    assert requests[0].headers["authorization"] == "Bearer test-key"


def test_search_materials_serializes_list_and_range_query_params():
    def handler(request: httpx.Request):
        params = dict(request.url.params.multi_items())
        assert request.url.params.get_list("elements") == ["Si", "O"]
        assert request.url.params.get_list("fields") == ["mg_id", "properties.band_gap"]
        assert params["band_gap_min"] == "1.0"
        assert params["page_size"] == "5"
        assert "sort_order" not in params
        return 200, {"total": 1, "data": [{"mg_id": "mg-2", "properties": {"band_gap": 1.4}}]}

    with MGClient(base_url="https://example.org/api/v1", transport=make_json_transport(handler)) as client:
        result = client.materials.search(
            elements=["Si", "O"], fields=["mg_id", "properties.band_gap"], band_gap_min=1.0, page_size=5
        )

    assert isinstance(result, PagedSummary)
    assert result.total == 1
    assert isinstance(result.data[0], Summary)
    assert result.data[0].mg_id == "mg-2"
    assert result.data[0].properties.band_gap == 1.4


def test_list_data_sources_returns_source_statistics():
    def handler(request: httpx.Request):
        assert request.url.path == "/api/v1/materials/sources"
        return 200, [{"source": "sc_growth", "count": 1703}, {"source": "ferroelectric", "count": 12}]

    with MGClient(base_url="https://example.org/api/v1", transport=make_json_transport(handler)) as client:
        result = client.materials.list_data_sources()

    assert [item.source for item in result] == ["sc_growth", "ferroelectric"]
    assert [item.count for item in result] == [1703, 12]
    assert all(isinstance(item, DataSource) for item in result)


def test_search_exposes_explicit_material_query_parameters():
    signature = inspect.signature(MGClient().materials.search)

    assert "params" not in signature.parameters
    for parameter_name in [
        "sources",
        "formula",
        "elements",
        "nelements",
        "band_gap_min",
        "band_gap_max",
        "fields",
        "page",
        "page_size",
        "sort_field",
        "sort_order",
    ]:
        assert parameter_name in signature.parameters


def test_get_topology_returns_topological_properties_model():
    def handler(request: httpx.Request):
        return 200, {
            "mg_id": "mg-1",
            "reduced_formula": "H2",
            "soc": False,
            "symmetry": {
                "crystal_system": "Tetragonal",
                "lattice_type": "Tetragonal",
                "number": 123,
                "symbol": "P4/mmm",
                "hall": "-P 4 2",
                "point_group": "4/mmm",
            },
            "topo_class": "Metal",
        }

    with MGClient(api_key="test-key", base_url="https://example.org/api/v1", transport=make_json_transport(handler)) as client:
        result = client.materials.get_topology("mg-1")

    assert isinstance(result, TopologicalProperties)
    assert result.topo_class == "Metal"


def test_remaining_property_endpoints_return_models():
    responses = {
        "/api/v1/materials/single_crystal_growth/mg-1": {
            "mg_id": "mg-1",
            "reduced_formula": "H2",
            "user_id": "user-1",
            "uid": "record-1",
            "method": "flux",
            "experimental_scheme": {},
            "experimental_condition": {},
            "experimental_result": {"product": "H2"},
            "start_materials": [],
            "heating_time": {"temperature": [300.0], "time": [1.0]},
        },
        "/api/v1/materials/ferroelectric/mg-1": {
            "mg_id": "mg-1",
            "reduced_formula": "H2",
            "energy": 1.0,
            "energy_per_atom": 0.5,
            "formation_energy": 0.1,
            "polar_eA": 0.2,
            "polar_pC": 0.3,
            "direction": "z",
            "ferroelectric": True,
            "area": 1.0,
        },
        "/api/v1/materials/nonlinear_optical/mg-1": {
            "max_shift_current_conductivity": 1.0,
            "max_injection_current_conductivity": 2.0,
            "nonlinear_optical_response": {
                "jdos": [[0.0, 1.0]],
                "shift_current_conductivity": {"xxx": [[0.0, 1.0]]},
                "injection_current_conductivity": {"xxx": [[0.0, 1.0]]},
                "chi_Re": {"xxx": [[0.0, 1.0]]},
                "chi_Im": {"xxx": [[0.0, 1.0]]},
            },
        },
    }

    def handler(request: httpx.Request):
        return 200, responses[request.url.path]

    with MGClient(api_key="test-key", base_url="https://example.org/api/v1", transport=make_json_transport(handler)) as client:
        growth = client.materials.get_single_crystal_growth("mg-1")
        ferroelectric = client.materials.get_ferroelectric("mg-1")
        nonlinear_optical = client.materials.get_nonlinear_optical("mg-1")

    assert isinstance(growth, SingleCrystalGrowth)
    assert isinstance(ferroelectric, Ferroelectric)
    assert isinstance(nonlinear_optical, NonlinearOpticalProperties)
    assert nonlinear_optical.max_shift_current_conductivity == 1.0


def test_iter_search_fetches_pages_until_results_are_exhausted():
    requested_pages: list[str] = []

    def handler(request: httpx.Request):
        requested_pages.append(request.url.params["page"])
        if request.url.params["page"] == "1":
            return 200, {"total": 3, "data": [{"mg_id": "mg-1"}, {"mg_id": "mg-2"}]}
        return 200, {"total": 3, "data": [{"mg_id": "mg-3"}]}

    with MGClient(base_url="https://example.org/api/v1", transport=make_json_transport(handler)) as client:
        results = list(client.materials.iter_search(fields=["mg_id"], page_size=2))

    assert [item.mg_id for item in results] == ["mg-1", "mg-2", "mg-3"]
    assert requested_pages == ["1", "2"]


def test_get_structures_fetches_many_material_ids():
    requested_paths: list[str] = []

    def handler(request: httpx.Request):
        requested_paths.append(request.url.path)
        material_id = request.url.path.rsplit("/", 1)[-1]
        return 200, {
            "mg_id": material_id,
            "reduced_formula": "H2",
            "cif_str": "data_H2",
            "nsites": 1,
            "density": 0.99,
            "symmetry": {
                "crystal_system": "Tetragonal",
                "lattice_type": "Tetragonal",
                "number": 123,
                "symbol": "P4/mmm",
                "hall": "-P 4 2",
                "point_group": "4/mmm",
            },
            "lattice": {
                "matrix": [[1.0, 0.0, 0.0], [0.0, 1.0, 0.0], [0.0, 0.0, 1.0]],
                "a": 1.0,
                "b": 1.0,
                "c": 1.0,
                "alpha": 90.0,
                "beta": 90.0,
                "gamma": 90.0,
                "volume": 1.0,
            },
            "wyckoff_positions": [],
            "oxidation_states": [],
        }

    with MGClient(base_url="https://example.org/api/v1", transport=make_json_transport(handler)) as client:
        structures = client.materials.get_structures(["MG-1", "mg-2"])

    assert [structure.mg_id if structure else None for structure in structures] == ["mg-1", "mg-2"]
    assert requested_paths == [
        "/api/v1/materials/crystal_structure/mg-1",
        "/api/v1/materials/crystal_structure/mg-2",
    ]


def test_unauthorized_response_raises_authentication_error():
    def handler(request: httpx.Request):
        return 401, {"detail": "Unauthorized"}

    with MGClient(base_url="https://example.org/api/v1", transport=make_json_transport(handler)) as client:
        with pytest.raises(MaterialsGalaxyAuthenticationError):
            client.materials.get_topology("mg-1")


def test_not_found_response_raises_not_found_error():
    def handler(request: httpx.Request):
        return 404, {"detail": "Not found"}

    with MGClient(base_url="https://example.org/api/v1", transport=make_json_transport(handler)) as client:
        with pytest.raises(MaterialsGalaxyNotFoundError):
            client.materials.get_summary("mg-missing")
