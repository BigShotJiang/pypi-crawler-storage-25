# MaterialsGalaxy SDK Agent Guide

## SDK Scope

This directory contains the MaterialsGalaxy Python SDK. Keep changes focused on SDK package code, tests, and SDK documentation.

## MaterialsGalaxy SDK Usage

Use this SDK when answering questions that require querying MaterialsGalaxy data.

For external projects, copy `../.agents/skills/materialsgalaxy-api/SKILL.md` so AI tools can learn the public `materialsgalaxy-api` package usage.

Load credentials from `.env` without printing the key:

```bash
set -a
. ./.env
set +a
```

The key may be named `API_KEY` or `MATERIALSGALAXY_API_KEY`.

Basic pattern:

```python
from materialsgalaxy import MGClient

with MGClient(base_url="https://materialsgalaxy.iphy.ac.cn/api/v1") as mg:
    page = mg.materials.search(
        formula="Bi2Se3",
        fields=["mg_id", "reduced_formula", "properties.band_gap"],
        page_size=10,
    )
    structure = mg.materials.get_structure(page.data[0].mg_id)
```

Search first, then fetch detailed properties by `mg_id`.

Public SDK methods:

```text
search
iter_search
get_summary
get_structure
get_structures
get_single_crystal_growth
get_electronic_structure
get_topology
get_phonons
get_ferroelectric
get_nonlinear_optical
```

Do not use XRD or similarity through the SDK; they are intentionally not public SDK methods yet.

## SDK Verification

```bash
uv run python -m pytest -q
uv run ruff check src tests
```
