class MaterialsGalaxyError(Exception):
    """Base exception for MaterialsGalaxy SDK errors."""


class MaterialsGalaxyHTTPError(MaterialsGalaxyError):
    def __init__(self, status_code: int, detail: object) -> None:
        super().__init__(f"MaterialsGalaxy API returned {status_code}: {detail}")
        self.status_code = status_code
        self.detail = detail


class MaterialsGalaxyAuthenticationError(MaterialsGalaxyHTTPError):
    pass


class MaterialsGalaxyNotFoundError(MaterialsGalaxyHTTPError):
    pass


__all__ = [
    "MaterialsGalaxyAuthenticationError",
    "MaterialsGalaxyError",
    "MaterialsGalaxyHTTPError",
    "MaterialsGalaxyNotFoundError",
]
