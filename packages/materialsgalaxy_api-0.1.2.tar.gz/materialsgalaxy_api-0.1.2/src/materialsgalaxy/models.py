from datetime import datetime
from typing import Any

from pydantic import BaseModel, ConfigDict, Field, model_validator


class MGModel(BaseModel):
    model_config = ConfigDict(extra="allow")


class BaseInfo(MGModel):
    mg_id: str | None = None
    reduced_formula: str | None = None


class Symmetry(MGModel):
    crystal_system: str
    lattice_type: str
    number: int
    symbol: str
    hall: str
    point_group: str


class Lattice(MGModel):
    matrix: list[list[float]]
    a: float
    b: float
    c: float
    alpha: float
    beta: float
    gamma: float
    volume: float


class WyckoffPosition(MGModel):
    wyckoff_label: str
    element: str
    position: list[float]


class SummaryProperties(MGModel):
    band_gap: float | None = None
    nsoc_topo_class: str | None = None
    soc_topo_class: str | None = None


class Summary(BaseInfo):
    source: str | None = None
    formula: str | None = None
    elements: list[str] | None = None
    nelements: int | None = None
    cif_str: str | None = None
    nsites: int | None = None
    density: float | None = None
    symmetry: Symmetry | None = None
    lattice: Lattice | None = None
    wyckoff_positions: list[WyckoffPosition] | None = None
    oxidation_states: list[str] | None = None
    dimensionality: int | None = None
    fingerprint: list[float] | None = None
    description: str | None = None
    mp_id: str | None = None
    properties: SummaryProperties = Field(default_factory=SummaryProperties)


class PagedSummary(MGModel):
    total: int
    data: list[Summary]


class DataSource(MGModel):
    source: str
    count: int


class CrystalStructure(BaseInfo):
    cif_str: str
    nsites: int
    density: float
    symmetry: Symmetry
    lattice: Lattice
    wyckoff_positions: list[WyckoffPosition]
    oxidation_states: list[str]
    dimensionality: int | None = None
    fingerprint: list[float] | None = None
    description: str | None = None


class BrillouinZone(MGModel):
    b1: list[float]
    b2: list[float]
    b3: list[float]
    high_symmetry_kpoints: dict[str, list[float]]
    faces_data: dict[str, list[object]]
    path: list[tuple[str, str]]


class EdgePoint(MGModel):
    energy: float
    band_index: list[int]
    kpoint_index: list[int]


class BandStructure(MGModel):
    kpoints: list[list[float]] = Field(default_factory=list)
    kpoint_distances: list[float] = Field(default_factory=list)
    eigenvalues: list[list[float]] = Field(default_factory=list)
    nelect: int | None = None
    branches: list[tuple[str, str]] = Field(default_factory=list)
    vbm: EdgePoint | None = None
    cbm: EdgePoint | None = None
    band_gap: float | None = None
    direct_band_gap: float | None = None
    is_metal: bool | None = None


class Dos(MGModel):
    energies: list[float]
    tdos: list[float]
    idos: list[float]
    pdos: dict[str, list[float]] = Field(default_factory=dict)


class ElectronicStructure(BaseInfo):
    soc: bool = False
    brillouin_zone: BrillouinZone
    band_structure: BandStructure | None = None
    dos: Dos | None = None
    efermi: float | None = None
    nelect: int
    band_gap: float | None = None
    direct_band_gap: float | None = None
    is_metal: bool | None = None
    fermi_dos: float | None = None


class Invariant(MGModel):
    invariant: str
    observable: bool


class InvariantTable(MGModel):
    head: list[str]
    body: list[list[Invariant]]


class TopologicalProperties(BaseInfo):
    soc: bool
    symmetry: Symmetry
    topo_class: str | None
    sym_ind: list[int] | None = None
    z2224_ind: list[int] | None = None
    ind_group: str | None = None
    dgn_hsp: list[str] | None = None
    dgn_hsl: list[str] | None = None
    dgn_irrep: list[str] | None = None
    dgn_dim: list[int] | None = None
    inv_table: InvariantTable | None = None


class ExperimentalScheme(MGModel):
    start_date: datetime | None = None
    finish_date: datetime | None = None
    select_flux: str | None = None
    transport_agent: str | None = None


class ExperimentalCondition(MGModel):
    crucible: str | None = None
    inner_diameter: float | None = None
    length: float | None = None
    atmosphere_condition: str | None = None
    end_temperature: str | None = None
    tantalum_seal: bool | None = None
    quartz_seal: bool | None = None
    centrifugation: bool | None = None
    anneal: bool | None = None
    descending_speed: float | None = None
    rotation_speed: float | None = None
    grind: bool | None = None
    press_into_pellet: bool | None = None
    num_temperature_zones: int | None = None


class ExperimentalResult(MGModel):
    product: str
    note: str | None = None
    is_target_product: bool | None = None
    xrd_result: str | None = None
    eds_result: str | None = None


class StartMaterial(MGModel):
    material: str
    molar_ratio: float | None
    molar_mass: float | None
    actual_mass: float | None
    material_form: str | None


class HeatingTime(MGModel):
    temperature: list[float]
    time: list[float]


class SingleCrystalGrowth(BaseInfo):
    user_id: str
    uid: str
    method: str
    experimental_scheme: ExperimentalScheme
    experimental_condition: ExperimentalCondition
    experimental_result: ExperimentalResult
    start_materials: list[StartMaterial]
    heating_time: HeatingTime | list[HeatingTime]


class PhononPoint(MGModel):
    path_id: list[int]
    ratio: list[float]
    frequency: float
    type: int
    mode1: int
    mode2: int
    multiplicity: int
    degeneracy: int
    coordinates: list[float]

    @model_validator(mode="before")
    @classmethod
    def add_coordinates(cls, data: Any) -> Any:
        if isinstance(data, dict) and "coordinates" not in data and {"x", "y", "z"}.issubset(data):
            data["coordinates"] = [data["x"], data["y"], data["z"]]
        return data


class PhononBandStructure(MGModel):
    frequencies: list[list[list[float]]]
    distances: list[list[float]]
    labels: list[list[str]]
    points: list[PhononPoint]


class PhononDOS(MGModel):
    frequencies: list[float]
    dos: list[float]


class TopologicalPhonon(BaseInfo):
    brillouin_zone: BrillouinZone
    bravais: str
    inversion: bool
    clean: bool
    num_nodal_lines: int
    num_nodal_ring_points: int
    num_weyl_points: int
    num_multi_deg_weyl_points: int
    max_dispersion_slope: float | None
    phonon_band_structure: PhononBandStructure
    phonon_dos: PhononDOS


class Ferroelectric(BaseInfo):
    energy: float
    energy_per_atom: float
    formation_energy: float
    polar_eA: float
    polar_pC: float
    direction: str
    ferroelectric: bool
    area: float


class NonlinearOpticalResponse(MGModel):
    jdos: list[list[float]]
    shift_current_conductivity: dict[str, list[list[float]]]
    injection_current_conductivity: dict[str, list[list[float]]]
    chi_Re: dict[str, list[list[float]]]
    chi_Im: dict[str, list[list[float]]]


class NonlinearOpticalProperties(MGModel):
    max_shift_current_conductivity: float
    max_injection_current_conductivity: float
    nonlinear_optical_response: NonlinearOpticalResponse


class HKL(MGModel):
    hkl: list[int]
    multiplicity: int


class XRDPatternData(MGModel):
    two_theta: list[float]
    intensity: list[float]
    hkls: list[list[HKL]]
    d_hkls: list[float]


class XRDPattern(MGModel):
    plot_data: list[list[float]]
    pattern: XRDPatternData


class SimilarityResult(BaseInfo):
    similarity: float


__all__ = [
    "CrystalStructure",
    "DataSource",
    "ElectronicStructure",
    "Ferroelectric",
    "NonlinearOpticalProperties",
    "PagedSummary",
    "SingleCrystalGrowth",
    "SimilarityResult",
    "Summary",
    "TopologicalPhonon",
    "TopologicalProperties",
    "XRDPattern",
]
