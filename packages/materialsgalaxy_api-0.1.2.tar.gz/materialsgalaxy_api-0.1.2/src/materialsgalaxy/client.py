import os
from types import TracebackType
from typing import Self

import httpx

from .materials import MaterialsClient

DEFAULT_BASE_URL = "https://materialsgalaxy.iphy.ac.cn/api/v1"


class MGClient:
    def __init__(
        self,
        api_key: str | None = None,
        *,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = 30.0,
        transport: httpx.BaseTransport | None = None,
    ) -> None:
        resolved_api_key = api_key or os.getenv("MATERIALSGALAXY_API_KEY")
        headers = {"Authorization": f"Bearer {resolved_api_key}"} if resolved_api_key else {}
        self._client = httpx.Client(
            base_url=base_url.rstrip("/"),
            headers=headers,
            timeout=timeout,
            transport=transport,
        )
        self.materials = MaterialsClient(self._client)

    def close(self) -> None:
        self._client.close()

    def __enter__(self) -> Self:
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc_value: BaseException | None,
        traceback: TracebackType | None,
    ) -> None:
        self.close()


__all__ = ["MGClient"]
