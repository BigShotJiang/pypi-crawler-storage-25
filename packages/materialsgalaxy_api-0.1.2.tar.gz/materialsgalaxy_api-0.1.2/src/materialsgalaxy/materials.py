from collections.abc import Iterator, Sequence
from typing import Any

from .exceptions import MaterialsGalaxyAuthenticationError, MaterialsGalaxyHTTPError, MaterialsGalaxyNotFoundError
from .models import (
    CrystalStructure,
    DataSource,
    ElectronicStructure,
    Ferroelectric,
    NonlinearOpticalProperties,
    PagedSummary,
    SingleCrystalGrowth,
    Summary,
    TopologicalPhonon,
    TopologicalProperties,
)


class MaterialsClient:
    def __init__(self, client: Any) -> None:
        self._client = client

    def search(
        self,
        *,
        sources: list[str] | None = None,
        formula: str | None = None,
        elements: list[str] | None = None,
        nelements: int | None = None,
        nsites_min: float | None = None,
        nsites_max: float | None = None,
        density_min: float | None = None,
        density_max: float | None = None,
        crystal_systems: list[str] | None = None,
        spacegroups: list[int] | None = None,
        band_gap_min: float | None = None,
        band_gap_max: float | None = None,
        nsoc_topo_classes: list[str] | None = None,
        soc_topo_classes: list[str] | None = None,
        fields: list[str] | None = None,
        page: int = 1,
        page_size: int = 10,
        sort_field: str | None = None,
        sort_order: int = 1,
    ) -> PagedSummary:
        params = build_search_params(
            sources=sources,
            formula=formula,
            elements=elements,
            nelements=nelements,
            nsites_min=nsites_min,
            nsites_max=nsites_max,
            density_min=density_min,
            density_max=density_max,
            crystal_systems=crystal_systems,
            spacegroups=spacegroups,
            band_gap_min=band_gap_min,
            band_gap_max=band_gap_max,
            nsoc_topo_classes=nsoc_topo_classes,
            soc_topo_classes=soc_topo_classes,
            fields=fields,
            page=page,
            page_size=page_size,
            sort_field=sort_field,
            sort_order=sort_order,
        )
        return PagedSummary.model_validate(self._get("/materials/summary", params=params))

    def list_data_sources(self) -> list[DataSource]:
        return [DataSource.model_validate(item) for item in self._get("/materials/sources")]

    def iter_search(
        self,
        *,
        sources: list[str] | None = None,
        formula: str | None = None,
        elements: list[str] | None = None,
        nelements: int | None = None,
        nsites_min: float | None = None,
        nsites_max: float | None = None,
        density_min: float | None = None,
        density_max: float | None = None,
        crystal_systems: list[str] | None = None,
        spacegroups: list[int] | None = None,
        band_gap_min: float | None = None,
        band_gap_max: float | None = None,
        nsoc_topo_classes: list[str] | None = None,
        soc_topo_classes: list[str] | None = None,
        fields: list[str] | None = None,
        page_size: int = 100,
        sort_field: str | None = None,
        sort_order: int = 1,
    ) -> Iterator[Summary]:
        page = 1
        yielded = 0
        while True:
            result = self.search(
                sources=sources,
                formula=formula,
                elements=elements,
                nelements=nelements,
                nsites_min=nsites_min,
                nsites_max=nsites_max,
                density_min=density_min,
                density_max=density_max,
                crystal_systems=crystal_systems,
                spacegroups=spacegroups,
                band_gap_min=band_gap_min,
                band_gap_max=band_gap_max,
                nsoc_topo_classes=nsoc_topo_classes,
                soc_topo_classes=soc_topo_classes,
                fields=fields,
                page=page,
                page_size=page_size,
                sort_field=sort_field,
                sort_order=sort_order,
            )
            if not result.data:
                return
            for item in result.data:
                yield item
                yielded += 1
            if yielded >= result.total:
                return
            page += 1

    def get_summary(self, material_id: str) -> Summary | None:
        return parse_optional_model(self._get(f"/materials/summary/{normalize_material_id(material_id)}"), Summary)

    def get_structure(self, material_id: str) -> CrystalStructure | None:
        return parse_optional_model(
            self._get(f"/materials/crystal_structure/{normalize_material_id(material_id)}"), CrystalStructure
        )

    def get_structures(self, material_ids: Sequence[str]) -> list[CrystalStructure | None]:
        return [self.get_structure(material_id) for material_id in material_ids]

    def get_single_crystal_growth(self, material_id: str) -> SingleCrystalGrowth | None:
        return parse_optional_model(
            self._get(f"/materials/single_crystal_growth/{normalize_material_id(material_id)}"), SingleCrystalGrowth
        )

    def get_electronic_structure(self, material_id: str, *, soc: bool = False) -> ElectronicStructure | None:
        return parse_optional_model(
            self._get(f"/materials/electronic_structure/{normalize_material_id(material_id)}", params={"soc": soc}),
            ElectronicStructure,
        )

    def get_topology(self, material_id: str, *, soc: bool = False) -> TopologicalProperties | None:
        return parse_optional_model(
            self._get(f"/materials/topological_properties/{normalize_material_id(material_id)}", params={"soc": soc}),
            TopologicalProperties,
        )

    def get_phonons(self, material_id: str) -> TopologicalPhonon | None:
        return parse_optional_model(
            self._get(f"/materials/topological_phonons/{normalize_material_id(material_id)}"), TopologicalPhonon
        )

    def get_ferroelectric(self, material_id: str) -> Ferroelectric | None:
        return parse_optional_model(
            self._get(f"/materials/ferroelectric/{normalize_material_id(material_id)}"), Ferroelectric
        )

    def get_nonlinear_optical(self, material_id: str) -> NonlinearOpticalProperties | None:
        return parse_optional_model(
            self._get(f"/materials/nonlinear_optical/{normalize_material_id(material_id)}"), NonlinearOpticalProperties
        )

    def _get(self, path: str, *, params: dict[str, object] | None = None) -> Any:
        response = self._client.get(path, params=build_query_params(params or {}))
        return parse_response(response)


def normalize_material_id(material_id: str) -> str:
    return material_id.strip().lower()


def build_search_params(**params: object) -> dict[str, object]:
    if not params.get("sort_field"):
        params["sort_order"] = None
    return dict(params)


def build_query_params(params: dict[str, object]) -> list[tuple[str, str]]:
    query_params: list[tuple[str, str]] = []
    for key, value in params.items():
        if value is None:
            continue
        if isinstance(value, list | tuple):
            query_params.extend((key, str(item)) for item in value)
            continue
        if isinstance(value, bool):
            query_params.append((key, "true" if value else "false"))
            continue
        query_params.append((key, str(value)))
    return query_params


def parse_response(response: Any) -> Any:
    if 200 <= response.status_code < 300:
        if not response.content:
            return None
        return response.json()

    detail = extract_error_detail(response)
    if response.status_code == 401:
        raise MaterialsGalaxyAuthenticationError(response.status_code, detail)
    if response.status_code == 404:
        raise MaterialsGalaxyNotFoundError(response.status_code, detail)
    raise MaterialsGalaxyHTTPError(response.status_code, detail)


def parse_optional_model(data: object, model_type: type[Any]) -> Any:
    return model_type.model_validate(data) if data is not None else None


def extract_error_detail(response: Any) -> object:
    try:
        payload = response.json()
    except ValueError:
        return response.text
    return payload.get("detail", payload) if isinstance(payload, dict) else payload


__all__ = ["MaterialsClient"]
