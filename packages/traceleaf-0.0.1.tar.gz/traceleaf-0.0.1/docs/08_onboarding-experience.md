# Onboarding and First-Launch Experience

## Conclusion

Traceleaf v0.1's onboarding experience is the prompt sequence the operator encounters when they run `traceleaf setup` for the first time, plus the documentation surfaces that guide them through the 60-minute path. The experience is designed to honor four properties: under five minutes of operator-active time, no prerequisite knowledge of CI tooling or Claude Code, every prompt is justifiable in plain language, and the workspace generated is hand-editable from the moment setup completes. This document specifies the prompt sequence, the documentation that wraps it, and the failure modes the experience must handle.

## Open questions and deferred items

- The precise wording of each prompt is sketched here as plain language and finalized during the build. Voice and tone are designed; exact phrasing iterates with build feedback.
- Telemetry on prompt completion rates is intentionally not collected at v0.1 (no outbound telemetry constraint). Iteration on prompt design relies on direct feedback from early users.
- The setup command is interactive at v0.1. A non-interactive variant for scripted deployment is a v0.2+ candidate but not committed.

## Onboarding goals

The onboarding experience exists to bring an operator from "I cloned this repository" to "I have a workspace ready to collect signals" with these properties.

The operator understands what Traceleaf is going to do with their inputs. No prompt asks for a value without explaining why Traceleaf needs it.

The operator's inputs are reflected in the generated workspace as plain text the operator can re-read and edit. Setup is not magic; it is a guided seed-file generator.

The operator can stop and resume. If the operator quits halfway, re-running setup picks up from where they left off without losing prior input.

The operator can inspect what setup produced before running collect. The setup command does not auto-trigger collection.

## The setup command's prompt sequence

The interactive prompt sequence at v0.1.

### Prompt 1: company or product context (optional)

Plain-language framing: "What is the company, product, or research focus you want Traceleaf to track competitors against? You can skip this and add it later. Traceleaf uses this context to help frame analytical comparisons and to write briefs that fit your industry."

Input: free text. Optional. Stored in `traceleaf.md` under a `context` field.

Why we ask: Claude inference quality benefits from operator-provided context. Without it, briefs default to generic competitive framing.

### Prompt 2: tracked competitors

Plain-language framing: "Name three to five competitors you want to track. For each, provide the company name as you commonly refer to it. Examples: 'Schneider Electric', 'Eaton', 'OpenAI'."

Input: list of strings, one per competitor. Required. Minimum three; maximum five suggested but not enforced. Stored in `traceleaf.md` under a `competitors` array.

Why we ask: Tracked competitors define the source collection scope. Every signal Traceleaf collects ties to one of these names.

The setup flow does not validate the competitor names against any external source. The operator is trusted to provide names that mean something to their analytical context. SEC EDGAR mappings happen during the first collection run, where the system attempts to match each name to an EDGAR filer and notes any unmatchable names.

### Prompt 3: industry context (optional)

Plain-language framing: "What industry or analytical lens applies? Examples: 'enterprise SaaS', 'data center power infrastructure', 'large language model providers'. Skip if not relevant. Traceleaf uses this to filter web-source content and to frame analytical themes."

Input: free text. Optional. Stored in `traceleaf.md` under an `industry` field.

Why we ask: Without an industry frame, web source collection includes off-topic content and brief synthesis defaults to generic framing.

### Prompt 4: Anthropic API key

Plain-language framing: "Paste your Anthropic API key. Traceleaf uses Claude inference to synthesize briefs from collected signals. Your key is stored locally in `traceleaf.md` and is never sent to any service except Anthropic. Get a key at console.anthropic.com if you do not have one."

Input: string. Required. Stored in `traceleaf.md` under an `api_key` field. The setup flow validates the key by making a probe request to the Anthropic API; an invalid key is reported with an actionable error and the flow re-prompts.

Why we ask: Brief synthesis depends on Claude inference. Traceleaf does not provide a model itself; the operator provides API access.

The probe request makes the smallest possible Claude call (a few tokens) so the validation cost is negligible. The probe also confirms which Claude model identifiers are available to the operator's account; the default model is recorded in `traceleaf.md` based on what the probe finds.

### Prompt 5: confirmation

Plain-language framing: "Setup will write the following files to your workspace: `traceleaf.md`, `signal_log.md`, `framework/` (a copy of the default framework modules). You can edit any of these files at any time. Proceed?"

Input: yes or no. Required.

Why we ask: The operator should know what setup is about to do before it does it. The confirmation step is an operator-respect gesture; it also gives the operator a chance to review their inputs before commitment.

If the operator answers no, the setup flow exits without writing anything. If the operator answers yes, setup writes the files and reports success.

### Prompt 6: next-step guidance

Plain-language framing (printed after success, not a prompt): "Setup complete. To collect signals from your tracked competitors, run `traceleaf collect`. To produce your first brief from collected signals, run `traceleaf compose`. Documentation: see `QUICK_START.md`."

This is not a prompt; it is the closing message. It tells the operator what to do next without auto-invoking it.

## Documentation that wraps the onboarding experience

Three documentation surfaces guide the operator through First-Launch.

### `README.md`

The README's first paragraph clearly states what Traceleaf does, who it is for, and the differentiation. The README points the operator to `QUICK_START.md` for the 60-minute path.

The README intentionally does not duplicate the quick-start. Operators who land in the README often want to know whether to bother; operators who land in `QUICK_START.md` already want to bother and want to act.

### `QUICK_START.md`

The quick-start is the operational document for First-Launch. It assumes the operator has read the README's first paragraph. It walks through clone, install, setup, collect, compose, and read in roughly the format of Workflow 1 in the User Workflows doc.

The quick-start is paste-throughable. Every command appears in a code block the operator can copy. Every expected output is shown. Common failure modes have a "if you see X, do Y" note inline.

### `traceleaf --help` and per-command help

The CLI itself surfaces help via standard `--help` arguments. `traceleaf --help` lists the commands. `traceleaf <command> --help` describes the command, its arguments, and its expected outputs. Help text is the in-line documentation the operator hits when they want to remember what a command does.

CLI help is concise. Detail belongs in the documentation files, not in help output.

## Failure modes the onboarding experience must handle

### Operator quits mid-setup

The setup flow saves operator inputs to a `.traceleaf/setup_in_progress.json` file as the operator answers each prompt. Re-running setup picks up the saved inputs and resumes from the last unanswered prompt. The operator can also delete this file to start over.

### API key validation fails

The probe request to Anthropic returns an error. The setup flow reports the error verbatim from Anthropic plus a suggested action ("check that your API key is correct and that your account is active"). The flow re-prompts for the API key.

### Network unavailable during setup

The probe request cannot reach Anthropic. The setup flow offers two options: retry, or proceed without API key validation (with a warning that the operator must validate the key manually before running synthesis).

### Operator provides nonsense input

If the operator types nothing, types punctuation, or types something obviously not a company name, the setup flow does not aggressively validate. Traceleaf trusts operators to know what they are doing. Garbage-in produces garbage-out, and the operator finds out at the first collection run when no signals are found.

### Operator provides too many or too few competitors

The setup flow accepts one or more competitors and warns if fewer than three or more than five are provided. The warning is informational; the operator can proceed.

### Operator refuses to provide an Anthropic API key

The setup flow allows the operator to skip the API key prompt with a note that synthesis will not work until a key is provided. This is the explicit operator-as-adult posture: do not block on what the operator can fix later.

## Onboarding for returning operators

The setup command on a workspace where setup has already run reports that setup is complete and offers a `--reset` flag to re-run. The flag is not advertised in the prompt sequence; it is mentioned in `traceleaf setup --help`. Re-running setup preserves the operator's existing workspace as `traceleaf.md.backup` before overwriting.

## What the onboarding experience does not include at v0.1

No GUI. No browser-based wizard. No telemetry on completion rates. No A/B testing of prompt phrasing. No localization beyond English. No accessibility features beyond what the terminal provides. These are v0.2+ candidates if signal warrants.

## Working forward

The Conceptual Model and Mental Hierarchy doc describes the artifacts the operator encounters in their workspace after setup completes. The Naming and Terminology Guide finalizes the names of the prompts, files, and commands referenced here. The v0.1 Scope and Acceptance Test doc operationalizes the test that First-Launch produces a usable workspace.
