# Differentiation Thesis

## Conclusion

Traceleaf differs from existing competitive intelligence tools and the build-your-own-with-Notion-and-Word default in five named ways: a typed citation contract that traces every claim to a source, markdown source-of-truth on a git substrate, operator-owned data with no SaaS lock-in, calibrated estimative language drawn from intelligence-community discipline, and AI augmentation without AI dependency. The combination is the differentiation; no single attribute is unique on its own. The target buyer is the analyst who needs evidence-grade output and rejects proprietary backends. Traceleaf is not a battlecard tool, not a sales-enablement product, and not a CI platform attempting to displace the established vendors at scale.

## Open questions and deferred items

- The buyer hypothesis is broad at v0.1 and narrows post-launch based on signal. This document proposes a primary and secondary buyer profile; finalization happens after open-source release and initial conversations.
- Whether any of the five differentiators are commercially valuable at the buyer level, versus only being technically interesting, is unproven. The post-launch signal phase tests this.
- The competitive landscape descriptions are based on public information and may be stale relative to vendor roadmaps. Risks to the thesis are flagged in a closing section.

## The competitive landscape

Five categories of existing tools. Each has a different shape and different shortcomings.

### Established CI platforms (Klue, Crayon, Kompyte, Contify)

These vendors serve enterprise CI teams with battlecards, competitor profiles, win-loss analysis, and sales-enablement workflows. They ship proprietary backends, hosted dashboards, browser extensions, and CRM integrations. Pricing is typically $16K to $40K per year per customer, with enterprise tiers higher.

What they do well: breadth of integrations, brand recognition, sales-team adoption, polished user experience for the consumer of CI output (sales, executives), automated competitor monitoring across web sources, AI-assisted summary generation.

Where they fall short for Traceleaf's target audience: proprietary backend means data lock-in. Citation discipline is light: claims appear with source links but the rigor of typed-anchor span resolution is not present. Operator-editability is limited; thresholds, prompts, and gate logic are vendor-controlled. Audit trails for who-changed-what at what time are not always exposed. Pricing is too high for small teams or solo analysts. The output quality is calibrated for sales workflow consumption, not for analyst-grade reasoning that survives adversarial review.

### AlphaSense

Document-corpus search and analysis platform. Heavy in financial-services and consulting verticals. Strong document ingestion, cross-corpus search, and increasingly AI-assisted summary generation.

What it does well: document depth, named-entity coverage across financial filings, broker research integration, sophisticated search.

Where it falls short for Traceleaf's target audience: also a proprietary backend. Pricing is enterprise-tier ($60K+ per year typical). Output is search-result-shaped, not brief-shaped. Operator does not control the citation format or the analytical framing. Customization requires custom services engagements rather than configuration.

### The build-your-own default (Notion plus Word plus spreadsheets)

What most CI teams actually do today, especially at smaller companies. Analysts maintain competitor profiles in Notion or Confluence, write briefs in Word or Google Docs, track signals in spreadsheets, and assemble outputs manually.

What it does well: full operator control, zero vendor lock-in, free or near-free at small scale, integrates with whatever tooling the operator already has.

Where it falls short: no structural discipline. Citation formats vary across briefs. Estimative language is not calibrated. Cross-brief consistency is operator-dependent. Manual effort scales linearly with output volume. Audit trails are weak. AI augmentation is operator-DIY (paste into ChatGPT, copy back, hope nothing was made up).

### CI consultancies and managed services

Outsourced CI work. The customer pays for analyst-hours; the vendor produces the output.

What they do well: deep human expertise on specific industries, can ramp up quickly for one-off projects, no internal tooling burden for the customer.

Where they fall short for Traceleaf's target audience: cost scales with hours. The customer does not own the methodology or the artifacts beyond what the engagement delivers. AI augmentation, where present, is internal to the vendor and not visible.

### LLM-shaped CI experiments

Recent entrants attempting to ship CI tools that are AI-native from the ground up. Generally early-stage, with limited public information, varying degrees of citation discipline.

What they may do well: greenfield design unburdened by legacy CI workflows.

Where they tend to fall short: most are SaaS-shaped. Citation discipline is often light because they target speed and surface area rather than rigor. Operator ownership is not a design priority.

## The five Traceleaf differentiators

The combination is what differentiates. No single attribute is unique. All five together constitute a posture that no existing tool currently occupies.

### Differentiator 1: typed citation contract

Every analytical claim in a Traceleaf brief carries a typed citation. The citation has a category (observation, signal, prior-brief, synthesis, or whatever the v0.1 Anchor Contract Specification finalizes), a span (URL with character offset, file path with line range, or signal-log identifier), and the cited text. Citations are machine-readable and validatable.

The discipline traces to ICD-203 (Office of the Director of National Intelligence Analytic Standards) and Sherman Kent's foundational work on intelligence writing. Existing CI tools cite sources at the URL level but do not type the citation or enforce span resolution. Traceleaf does both.

The operational consequence: a Traceleaf brief reads like an analytical document that could be defended in adversarial review. An existing-tool brief reads like a sales-ready summary.

### Differentiator 2: markdown source-of-truth on git

All canonical state in Traceleaf is markdown files committed to git. Briefs, signal logs, operator configuration, gate verdicts, calibration data, anchor citations all live as plain text. The operator can hand-edit any artifact at any time and the next system invocation reads the change.

Existing CI tools store canonical state in proprietary databases. The operator interacts through the vendor's UI. Editing the underlying data structure requires vendor support tickets.

The operational consequence: Traceleaf operators can fork, patch, customize, audit, version, and migrate their data on their own schedule. Existing-tool operators are bound to the vendor's product roadmap.

### Differentiator 3: operator-owned data with no SaaS lock-in

Following from differentiator 2, Traceleaf does not require the operator to send data to any service Traceleaf controls. The only external dependency is the Anthropic API for Claude inference, and the operator pays for that directly. Traceleaf does not collect telemetry, does not host operator data, and does not have a "Traceleaf cloud" tier.

Existing CI tools are SaaS-first. Operator data lives on the vendor's infrastructure. Termination of service means data export at best, data loss at worst.

The operational consequence: Traceleaf is suitable for operators in security-sensitive contexts (defense contractors, financial services, healthcare, government-adjacent work) where SaaS data residency is a hard constraint.

### Differentiator 4: calibrated estimative language

Traceleaf uses a calibrated probability vocabulary drawn from ICD-203 and Sherman Kent's work. Words like "almost certainly," "likely," "even chance," "unlikely," and "almost no chance" map to explicit numeric ranges. Claim types are labeled (information, assumption, judgment) per ICD-203. The synthesis layer is constrained to use the calibrated vocabulary; the gate layer enforces the constraint.

Existing CI tools use natural-language probability words ("we believe," "it appears," "may indicate") without calibration. The reader cannot distinguish a 95-percent-confident claim from a 60-percent-confident claim.

The operational consequence: Traceleaf briefs are honest about uncertainty in a way that existing-tool briefs are not. The analyst can defend specific calibration choices ("I called this likely, meaning 60-80 percent, because...") in adversarial review.

### Differentiator 5: AI-augmented but not AI-dependent

Traceleaf uses Claude (or operator-overridable models) for synthesis. The synthesis is the labor-saving step. The discipline (citation contract, claim labeling, estimative language, gate validation) is independent of the model. If a future operator runs Traceleaf with a different LLM, or with no LLM at all (manual brief drafting against the same templates), the discipline still applies.

Existing AI-native CI tools assume the AI as the core product. Without the AI, there is no product. Existing non-AI CI tools assume the AI is a recent add-on. The integration is shallow.

The operational consequence: Traceleaf operators can swap models, run offline against cached signals, or operate manually for sensitive briefs while keeping the discipline intact.

## What Traceleaf is NOT

Naming non-goals sharpens the differentiation.

- **Not a battlecard tool.** Traceleaf produces analytical briefs, not sales-enablement assets. Operators who need battlecards can write them by hand using Traceleaf's signal log as input, but Traceleaf does not ship a battlecard mode at v0.1.
- **Not a sales-enablement product.** Traceleaf's user is the analyst who produces CI output, not the salesperson who consumes it. Sales-team adoption is not a v0.1 goal.
- **Not a CI platform.** Traceleaf is a plugin (technically, a Claude Code plugin) plus a small set of CLI tools. There is no platform around it. No multi-tenancy, no admin UI, no billing.
- **Not a Klue or Crayon competitor.** Traceleaf serves a narrower audience and does not attempt to match Klue or Crayon on breadth, polish, or sales-team integration. The audiences may overlap at the edges, but the core users differ.
- **Not enterprise-grade compliance-certified.** Traceleaf is open-source and operator-deployed. It carries no SOC2 attestation, no HIPAA-equivalent, no FedRAMP. Operators who need those certifications run Traceleaf inside their own compliant environment.
- **Not a hosted service.** Traceleaf does not run a "Traceleaf cloud." If an operator wants Traceleaf hosted, they self-host or hire a contractor.

## Buyer hypothesis

Two persona buckets at v0.1, with the first being primary.

### Primary: the discipline-driven CI analyst

A CI analyst at a small-to-medium organization who:
- Currently produces CI artifacts in Word, Notion, or spreadsheets.
- Has been frustrated by the citation discipline drift in their own outputs.
- Has technical comfort to clone a GitHub repo and run a CLI tool.
- Has access to an Anthropic API key (personally or through their organization).
- Values output that they can defend in front of an executive or a regulator.
- Does not have $20K+ per year in CI tool budget, or has the budget but distrusts SaaS-first vendors.

This persona is the natural early adopter of the open-source release. Traceleaf serves them by giving them the discipline-as-tooling that they would otherwise build by hand.

### Secondary: the regulated-industry CI team

A small CI team (one to five analysts) at a defense contractor, financial services firm, healthcare or pharma company, or government-adjacent organization who:
- Has hard data-residency or compliance constraints that make SaaS CI tools difficult.
- Currently runs CI work in spreadsheets and Word docs because the SaaS alternatives do not pass procurement.
- Has higher budget than the primary persona but procurement friction is worse.
- Values audit-grade citations because their outputs may be inspected by auditors, regulators, or counsel.

This persona is harder to reach (no GitHub-stargazer flywheel) but has higher willingness-to-pay if Traceleaf maps to their constraints. Reaching them is a post-v0.1 outreach effort, not a v0.1 promise.

## Risks to the differentiation thesis

Three named risks. Each could invalidate part or all of the thesis.

### Risk 1: existing vendors close the gap

Klue, Crayon, or another established vendor adds a typed citation contract, calibrated estimative language, and operator-editable substrate within twelve months. The differentiation collapses to "Traceleaf is open-source" and "Traceleaf is not SaaS." Both still differentiators, but narrower.

Mitigation: Traceleaf's lead is months, not years. The thesis assumes Traceleaf reaches enough of the target audience before vendors close the gap that switching costs and community lock-in become defensible.

### Risk 2: the differentiators are technical, not commercial

The five differentiators are real engineering. Whether they translate to commercial value depends on whether the target audience values them at willingness-to-pay levels. If buyers say "interesting but not worth switching from my Notion setup," the thesis is wrong.

Mitigation: the post-launch signal phase tests this directly through real conversations. If conversations consistently land on "not worth switching," the project pivots to portfolio-only positioning rather than commercial pursuit.

### Risk 3: the buyer audience is too small

The intersection of "CI analyst with technical comfort" plus "values audit-grade citation discipline" plus "rejects SaaS or has procurement difficulty" plus "has Anthropic API access" plus "has authority to choose tooling" may be too narrow to support either community traction or commercial pursuit.

Mitigation: v0.1 ships open-source with no commercial expectation. If the audience is too narrow, Traceleaf still serves the project owner's portfolio purpose. If the audience is wider than expected, the commercial pursuit becomes viable.

## What this differentiation means for v0.1 design

Three implications for downstream design choices.

- The typed citation contract must be visible in the user experience, not just in the codebase. Briefs must render citations in a way that the reader notices the discipline. The Anchor Contract Specification document handles this.
- The markdown source-of-truth posture must be obvious from the file system layout. An operator opening the workspace directory should immediately see canonical state as plain markdown. The Architecture Overview document handles this.
- The operator-editable substrate must show up in the onboarding flow. The first-launch experience must demonstrate that the operator owns the configuration, not Traceleaf. The Onboarding and First-Launch Experience document handles this.
