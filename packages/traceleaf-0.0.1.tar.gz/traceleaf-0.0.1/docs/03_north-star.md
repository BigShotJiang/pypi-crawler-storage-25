# North Star and Target State

## Conclusion

Traceleaf's north star is a single operational sentence: a competitive intelligence analyst at any company should be able to clone the repository, follow a quick-start, and produce their first useful brief within one hour. This document operationalizes that promise into named success criteria for v0.1, defines what v1.0 would look like if signal supports it, and names the failure modes that would invalidate the project.

## Open questions and deferred items

- The "useful brief" definition needs operational criteria. This document proposes a working definition; the v0.1 Scope and Acceptance Test doc finalizes.
- The "any company" framing is broad. The Differentiation Thesis doc and User Personas doc narrow this to specific buyer profiles for go-to-market purposes.
- v1.0 considerations are sketched here as forward-looking commitments, not commitments to ship. Whether v1.0 happens at all depends on signal from the v0.1 release.

## The north-star sentence, unpacked

Each clause carries weight.

**"A competitive intelligence analyst at any company"** means Traceleaf is designed for the analyst persona, not the executive consumer of CI output. The user is someone whose job involves producing CI artifacts, not someone whose job involves reading them. The "any company" framing is intentionally broad at v0.1; the buyer-hypothesis-narrowing happens during the post-launch signal phase, not during the build.

**"Should be able to"** means the promise is about capability, not guarantee. A user who refuses to follow the quick-start, or who wants to operate Traceleaf without an Anthropic API key, falls outside the promise. The promise covers users who follow the documented path.

**"Clone the repository"** anchors the distribution model. Traceleaf is open-source on GitHub. Installation is git clone plus a small set of explicit dependencies. There is no SaaS signup, no waitlist, no provisioning step.

**"Follow a quick-start"** anchors the documentation contract. The repository ships a `QUICK_START.md` that the user can copy-paste through. The quick-start does not assume prior knowledge of CI tooling, intelligence-community frameworks, or Claude Code conventions beyond what the file explicitly states.

**"Produce their first useful brief"** anchors the output contract. "Useful" has a working definition (below). "First brief" means the user's first invocation of the brief-generation flow, not a demo brief that ships with the repo.

**"Within one hour"** anchors the time budget. The hour is measured from `git clone` to the user reading their first generated brief. The budget is operational, not aspirational.

## What "useful brief" means at v0.1

The v0.1 working definition. Final operational criteria land in the v0.1 Scope and Acceptance Test doc.

A useful first brief at v0.1 has these properties:

- The brief contains five or more analytical signals collected from the past seven days.
- Every analytical claim in the brief carries a typed citation that resolves to a real source.
- Every cited URL is reachable at the time the brief is read.
- The brief is structurally well-formed: leads with a conclusion, supports with evidence, closes with citations.
- The brief is prose-disciplined: no banned vocabulary, no em dashes, no hollow corporate language.
- The brief addresses the operator's named competitive set, not a generic example set.
- The user reads the brief and concludes "I would have spent more than one hour producing this manually."

The last criterion is the operational test. If the user reads the brief and decides they could have produced something equivalent in less than an hour by hand, Traceleaf has not delivered on the promise.

## The 60-minute time budget unpacked

The hour breaks down approximately as follows. These are operational targets, not strict requirements.

- 5 minutes: clone the repo, read the README, install dependencies.
- 5 minutes: run the setup flow (provide company name, three to five competitors, Anthropic API key, optional industry context).
- 30 minutes: source collection runs (scout-equivalent operation pulls signals from configured sources), brief assembly runs (synthesis layer produces the brief from collected signals).
- 20 minutes: read the brief, click two or three citations to verify they resolve, decide whether the output is useful.

The 30-minute middle block is dominated by API latency (collection requests to external sources) and Claude inference time (synthesis). The user is not actively working during this block; they are waiting. v0.1 should make this block visible (progress indication) but does not need to compress it.

## v0.1 success criteria

v0.1 succeeds if all of the following are true at launch.

### Functional success

- A user with the documented prerequisites (Anthropic API key, Python 3.10+, internet access) can complete the quick-start without operator help.
- The first generated brief satisfies the "useful brief" definition above.
- The 60-minute time budget is met for at least 80 percent of test runs against a tracked-competitor set of three to five names.
- Every brief generated includes a sidecar manifest with the data needed to verify citation resolution.

### Discipline success

- The repository ships with the documentation set defined in the Tier 1 doc list.
- The codebase passes its own quality gates (no em dashes in shipped prose, no banned vocabulary, anchor contract validated end-to-end on test data).
- The `LICENSE`, `CONTRIBUTING.md`, and `CODE_OF_CONDUCT.md` are present and operator-readable.
- The repository is reproducibly buildable: a fresh clone on a fresh machine completes the quick-start.

### Distribution success

- The repository is published to GitHub under the project owner's account.
- The README's first paragraph clearly articulates what Traceleaf does, who it is for, and the differentiation in plain language.
- A launch blog post (or equivalent artifact) accompanies the repository going public.

## v0.1 launch criteria

These items must be true before tagging the v0.1 release.

- All fifteen Tier 1 documents are drafted, reviewed, and committed to the repository.
- The acceptance test in the v0.1 Scope and Acceptance Test doc passes on a fresh checkout.
- The legal and IP posture is verified: no inherited content from the prior project, MIT license applied, attribution settled.
- The launch communications (README, blog post, social posts) are drafted and ready to publish.
- The repository's first 100 GitHub Issues are pre-populated only with the project owner's known followups (not synthetic content), so early issue traffic comes from real users.

## v1.0 considerations

v1.0 is not a v0.1 commitment. This section describes what v1.0 might look like if user signal warrants it, so that v0.1 is designed forward-compatibly rather than locked into v0.1 shapes.

A plausible v1.0 includes:

- Three to five analytical modes (weekly brief plus one or two of: monthly digest, quarterly assessment, KIQ response, financial signal brief, strategic comparison).
- A proper retrieval layer (FTS5 or sqlite-vec) for unknown-file queries, gated on measurement showing path-based reads insufficient.
- One to two additional source classes (foreign-filer adapters, AlphaSense Ingestion API integration, or operator-specific connectors).
- A proper held-out test set discipline with multiple corpora.
- Distribution surfaces beyond markdown (DOCX rendering via Pandoc, optional email push).
- A documented contributor onboarding flow if external contributors emerge.

What v1.0 explicitly does not include, even if signal supports growth:

- A SaaS or hosted version. Traceleaf is operator-owned by design.
- A proprietary frontend. The user-facing surface is Claude Code, the CLI, and the markdown files.
- Integration into established CI vendor stacks (Klue, Crayon, AlphaSense as primary surfaces). Traceleaf can interoperate with these but does not depend on them.

## Failure modes

The project should treat these outcomes as failure, not as ambiguous results.

### Scope failure

- v0.1 ships with the 60-minute promise broken. The first useful brief takes two hours, or three, or never resolves to a useful state. This invalidates the north star and forces a re-scope.
- v0.1 ships but the documentation set is incomplete or inconsistent. The discipline-as-differentiation thesis fails because the project itself does not exemplify the discipline.

### Differentiation failure

- v0.1 ships and the open-source community responds with "this is just a worse version of [existing tool]." The differentiation thesis (typed citation contract, markdown source-of-truth, operator-owned, calibrated estimative language) is not actually visible in the user experience.
- v0.1 ships and users adopt it but ignore the citation discipline. The anchor contract is technically present but operationally unused. This means the differentiation does not translate to user value, only to engineering aesthetics.

### Adoption failure

- v0.1 ships and gets fewer than 50 GitHub stars, fewer than five thoughtful issues, and zero conversations with real CI practitioners within 90 days. This is the lowest-bar adoption signal; missing it suggests the audience does not exist or cannot be reached through the documented channels.
- v0.1 ships and gets initial attention but no second-cohort signal. Early stargazers are typically engineers admiring the architecture; no follow-on signal from actual analysts means the differentiation does not translate to the target persona.

### Discipline failure

- v0.1 ships and a follow-up audit finds the codebase contains content that should not have transferred from the prior project (operator-named references, inherited code patterns, calibration values). This is an IP and process failure independent of adoption.

## Non-goals

These are intentionally not part of the Traceleaf v0.1 success criteria.

- Becoming a venture-scale business. v0.1 is a portfolio piece and a market-signal experiment, not a launched product.
- Replacing existing CI vendors at scale. Traceleaf serves a narrower audience than Klue or Crayon and does not need to compete on breadth.
- Supporting all possible source types or output formats. v0.1 ships with the smallest viable surface.
- Being feature-complete relative to the prior project's v8.x scope. The prior scope was operator-specific and is explicitly out of scope.
- Producing brief output that is indistinguishable from a human analyst's. v0.1 produces brief output that is auditable, structured, and useful to a real analyst, not output that replaces the analyst's final review.

## Working forward

The v0.1 Scope and Acceptance Test document, drafted later in the Tier 1 sequence, finalizes the operational acceptance test for the 60-minute promise. The User Workflows and Journey Maps document operationalizes how the user experiences each step of the 60 minutes. The Onboarding and First-Launch Experience document specifies the prompt sequence that takes the user from clone to first brief. All three docs depend on the north star defined here.
