# Functional Decomposition and Skill Taxonomy

## Conclusion

Traceleaf v0.1 ships four skills that compose into the operator-facing surface: Setup (one-time workspace initialization), Collect (recurring source ingestion), Compose (brief synthesis), and Validate (gate enforcement plus citation inspection). Each skill is a self-contained Python module set under `traceleaf/skills/` with explicit responsibilities, a defined interface, and a set of named scripts. This document specifies what each skill does, what it does not do, what scripts it contains, and how it interacts with the workspace and with other skills. The Architecture Overview describes the high-level shape; this document descends into the specifics.

## Open questions and deferred items

- The internal organization of each skill's modules is sketched here and finalized during build. The interface to other skills (workspace files) is committed; the within-skill structure may shift.
- A fifth skill (Inspect, currently a sub-component of Validate) may be split out if the inspection logic grows beyond what fits comfortably inside Validate. The decision is deferred to build.
- v0.2+ skill candidates (Render, Distribute, Track, Measure) are not specified here. They are scoped in a separate doc at the time v0.2 is committed.

## Skill design principles

Traceleaf skills follow consistent design principles.

**Single responsibility.** Each skill does one thing. Setup sets up. Collect collects. Compose composes. Validate validates. The names match the responsibilities.

**Workspace-mediated communication.** Skills do not call each other directly. They read from and write to workspace files. The CLI orchestrates the sequence; the skills do not know about the orchestration.

**Stateless beyond the workspace.** A skill's behavior depends only on its inputs (workspace state plus command arguments). No skill maintains state across invocations beyond what it writes to the workspace.

**Operator-inspectable.** Every skill produces output the operator can read. No skill performs silent or hidden operations.

**Failure-actionable.** Every skill failure is reported with a rule ID, the file or input that failed, and a suggested action.

## Skill 1: Setup

### Responsibility

The Setup skill initializes a new workspace from operator inputs. It runs once per workspace.

### Inputs

Interactive prompts to the operator. No file inputs at first run. On re-run with `--reset`, reads the existing `traceleaf.md` and offers to preserve or replace.

### Outputs

A complete workspace with:
- `traceleaf.md` (operator configuration)
- `signal_log.md` (empty signal log with header row)
- `framework/` (directory of default framework modules, copied from the package)
- `briefs/` (empty directory)
- `manifest/` (empty directory)

### Scripts

- `traceleaf/skills/setup/flow.py` — the interactive prompt sequence. Implements the six prompts specified in the Onboarding doc.
- `traceleaf/skills/setup/seeds.py` — the default file generation. Writes the configuration file from operator inputs, copies framework modules from the package, creates empty workspace files.
- `traceleaf/skills/setup/api_validation.py` — Anthropic API key validation. Makes a probe request and reports validity.

### Interactions with other skills

Setup is the prerequisite for every other skill. Other skills check that the workspace was set up (specifically, that `traceleaf.md` exists) before proceeding.

### Failure modes

- Operator cancels mid-prompt: Setup saves progress to `.traceleaf/setup_in_progress.json` and exits cleanly.
- API key validation fails: Setup re-prompts with the Anthropic error message verbatim.
- Workspace not writable: Setup reports the underlying file-system error and exits.

## Skill 2: Collect

### Responsibility

The Collect skill ingests signals from external sources, deduplicates against the existing signal log, and appends new signals.

### Inputs

- `traceleaf.md` (tracked competitors, source class enablement, rate-limit hints)
- `signal_log.md` (existing signals for deduplication)
- The configured external sources (SEC EDGAR, web sources)

### Outputs

- `signal_log.md` (appended with new signals)
- A status summary printed to stdout (signals collected per source, signals deduplicated, sources skipped)

### Scripts

- `traceleaf/skills/collect/sources/edgar.py` — SEC EDGAR collector. Maps tracked competitor names to EDGAR CIKs, queries recent filings, extracts relevant content, returns signal candidates.
- `traceleaf/skills/collect/sources/web.py` — Simple web source collector. Reads operator-configured URLs (newsroom, blog, homepage patterns), fetches HTML, extracts content, returns signal candidates.
- `traceleaf/skills/collect/dedup.py` — Content-based deduplication. Hashes signal content, compares against existing signals, filters out duplicates.
- `traceleaf/skills/collect/log_writer.py` — Signal log writer. Appends new signals to `signal_log.md` in the documented schema.

### Interactions with other skills

Collect produces signals that Compose reads. Collect does not communicate with Compose directly; the `signal_log.md` file is the boundary.

### Failure modes

- Source class fully fails (EDGAR unreachable, web sources all return errors): Collect reports the failure, preserves any signals collected before the failure, and exits with a non-zero status.
- Source class partially fails: Collect proceeds with available sources and notes the missing source in the status summary.
- Tracked competitor cannot be matched to an EDGAR CIK: Collect skips that competitor for EDGAR, notes the skip in the status summary, and proceeds with web sources for that competitor.
- Rate limit hit: Collect respects the rate limit and continues at the slower pace; reports the rate-limit event.

## Skill 3: Compose

### Responsibility

The Compose skill produces a brief from collected signals. It is the operator's primary value-delivery moment.

### Inputs

- `traceleaf.md` (operator configuration, tracked competitors, industry context)
- `framework/` (analytical conventions, prose standards, brief structure)
- `signal_log.md` (signals from the past seven days)
- The Anthropic API (Claude inference)
- Optional command argument: `--focus <topic>` to weight synthesis toward a specific area

### Outputs

- `briefs/YYYY-MM-DD_weekly.md` (the brief)
- `manifest/YYYY-MM-DD_weekly.json` (the citation manifest sidecar)
- A summary printed to stdout (brief generated, signals incorporated, gate status)

### Scripts

- `traceleaf/skills/compose/brief.py` — Brief synthesis orchestration. Reads inputs, constructs the synthesis prompt, calls Claude, parses the response, writes the brief and manifest.
- `traceleaf/skills/compose/claude_client.py` — Claude inference client. Wraps the Anthropic SDK with retry logic, error handling, and rate-limit awareness.
- `traceleaf/skills/compose/manifest_writer.py` — Citation manifest writer. Resolves anchors in the generated brief to source content and writes the manifest sidecar.
- `traceleaf/skills/compose/post_validation.py` — Pre-write validation. Runs anchor-contract checks (Rules A.1 through A.6) before writing the brief; if checks fail, retries the synthesis up to a small number of times before reporting failure.

### Interactions with other skills

Compose reads outputs from Collect (via `signal_log.md`). Compose's output is consumed by Validate. Compose runs anchor-contract validation inline (it shares logic with Validate's anchor rules).

### Failure modes

- Claude API failure: Compose retries up to three times with exponential backoff, then reports the failure with the underlying Anthropic error.
- Anchor contract failure on generated brief: Compose retries up to three times, then writes the brief with a `--unvalidated` flag in the filename and reports the failure.
- Manifest resolution fails for an anchor: Compose reports the failure and writes a partial manifest; Validate will catch the issue on next run.
- Synthesis prompt exceeds context window: Compose reports the failure and suggests narrowing the time window or tracked competitor set.

## Skill 4: Validate

### Responsibility

The Validate skill runs gate rules against a brief and inspects citations on demand.

### Inputs

- A brief file (`briefs/<file>.md`)
- The brief's manifest (`manifest/<file>.json`)
- `framework/` (specifically prose-standards, structural-validity rules)
- For inspect: a citation identifier

### Outputs

- A gate report printed to stdout (rules passed, rules failed, with rule IDs and line numbers).
- For inspect: the source content the citation points to, printed to stdout.

### Scripts

- `traceleaf/skills/validate/gates.py` — Gate registry and runner. Loads the active gate set, runs each rule against the brief and manifest, aggregates results.
- `traceleaf/skills/validate/rules/` — Directory of rule implementations.
  - `prose_standards.py` — Enforces banned vocabulary, em-dash absence, prose conventions.
  - `citation_resolution.py` — Enforces Rules A.1 through A.6.
  - `structural_validity.py` — Enforces brief structure (BLUF present, top-signals section present, citations section present).
  - `signal_freshness.py` — Enforces that brief signals are within the time window the brief claims to cover.
- `traceleaf/skills/validate/inspect.py` — Citation inspection. Loads the manifest, resolves a specific anchor, returns source content.

### Interactions with other skills

Validate reads briefs produced by Compose. Validate's gate failures are surfaced to the operator; the operator decides whether to retry Compose, edit the brief, or override.

### Failure modes

- Gate rule itself crashes: Validate reports the rule that crashed and continues with remaining rules. The crash is the rule's bug; the operator can disable the rule via framework configuration.
- Manifest missing: Validate reports the missing manifest and exits.
- Brief malformed (cannot be parsed): Validate reports the parse failure with the line number.

## Cross-skill: shared utilities

Several utilities are imported by multiple skills.

### `traceleaf/config.py`

Loads `traceleaf.md` and exposes the operator configuration to skills. Single source of truth for parsing the configuration file.

### `traceleaf/workspace.py`

Resolves workspace paths relative to the current working directory. Handles cross-platform path issues. Provides workspace-existence checks.

### `traceleaf/framework_loader.py`

Loads `framework/` modules and exposes them to skills. Skills request specific framework modules by name; the loader returns the parsed content.

### `traceleaf/anchors.py`

Anchor parsing, formatting, and validation. Imported by Compose (for generation), Validate (for enforcement), and the inspect command.

### `traceleaf/inference.py`

Anthropic API client. Imported only by Compose. Wraps the SDK with consistent error handling, retry logic, and configuration.

These utilities are not skills. They are infrastructure. They have no operator-facing CLI surface.

## Cross-skill: scripts that ship as utilities

A small set of utility scripts ship with the package for operator convenience but are not part of the four primary skills.

### `traceleaf check_installation`

Verifies the operator's workspace is internally consistent (configuration file present, framework modules present, no orphan manifests).

### `traceleaf migrate_workspace`

Reserved for v0.2+. Migrates an operator's workspace from one Traceleaf version to another. Does nothing at v0.1 because no migration is needed yet.

### `traceleaf --version`

Prints the running version of Traceleaf.

These utilities are exposed via the CLI but do not modify the workspace beyond what is documented.

## Skill boundaries: what is out of scope at v0.1

The following functions are intentionally not in any skill at v0.1.

**Render.** Producing rendered artifacts (DOCX, PDF, HTML) from briefs is a v0.2+ candidate. The Compose skill writes markdown only.

**Distribute.** Sending briefs to email, Slack, or other surfaces is a v0.2+ candidate.

**Track.** Maintaining persistent multi-signal analytical constructs (transition trackers, threat matrices) is a v0.2+ candidate.

**Measure.** Tracking forecast accuracy, drift, calibration is a v0.2+ candidate. The prior project's ci-measurement skill is not carried into v0.1.

**Review-Competitors.** Operator-confirmed addition or removal of competitors from the tracked set. At v0.1, the operator edits `traceleaf.md` directly. A guided review flow is a v0.2+ candidate.

**Engagement.** Tracking how briefs are read, by whom, with what attention. The prior project's ci-engagement skill is not carried into v0.1 and may not be carried at all.

**Publisher.** A separate publishing pipeline distinct from Compose. The prior project had this; Traceleaf v0.1 does not. Compose's output is the terminal artifact.

## Module count and file count budget

Traceleaf v0.1 should ship with a small number of source files. A rough budget:

- Setup skill: ~5 Python files plus a small set of default framework modules.
- Collect skill: ~6 Python files.
- Compose skill: ~5 Python files.
- Validate skill: ~10 Python files (the rules directory carries multiple rule implementations).
- Shared utilities: ~5 Python files.
- CLI entry point and dispatch: ~3 Python files.
- Default framework modules: ~6 markdown files.
- Test suite: scaled to coverage targets, roughly half the size of the production code.

Total: roughly 35 to 50 Python files plus 10 to 15 framework markdown files. The codebase should be navigable in an afternoon.

## Working forward

The Schema and Data Model doc specifies the data structures each skill reads and writes. The v0.1 Scope and Acceptance Test doc operationalizes the test that each skill behaves correctly. The Architecture Overview's data flow section describes how the skills compose into the operator's experience.
