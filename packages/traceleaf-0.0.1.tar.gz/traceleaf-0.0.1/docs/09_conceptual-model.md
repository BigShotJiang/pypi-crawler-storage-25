# Conceptual Model and Mental Hierarchy

## Conclusion

Traceleaf v0.1 organizes the operator's mental model around five primary concepts: workspace, framework, signal, brief, and citation. Each concept maps to specific files in the workspace, specific commands in the CLI, and specific documentation surfaces. The mental hierarchy is intentionally shallow; an operator who understands these five concepts can operate Traceleaf without further conceptual scaffolding. This document defines each concept, names what it includes and excludes, and identifies how the concepts compose into the operator's daily experience.

## Open questions and deferred items

- The "framework" concept could plausibly be split into "framework modules" and "configuration" depending on operator feedback. The current model treats them as one concept because operators do not need to distinguish them at v0.1.
- The "citation" concept is partially specified here and finalized in the Anchor Contract Specification doc.
- Future concepts (transition trackers, recommendation registries, threat matrices from the prior project) are intentionally not introduced at v0.1. They are v0.2+ candidates.

## The five primary concepts

Each concept is described with: what it is, where it lives in the workspace, what operations apply, and what the operator should and should not infer from it.

### Concept 1: workspace

The workspace is the directory the operator runs Traceleaf inside. Every Traceleaf artifact lives somewhere in the workspace.

The workspace is operator-owned and operator-controlled. Traceleaf does not write outside the workspace. The operator can move, copy, version-control, share, archive, or delete the workspace as they choose.

The workspace contains four primary subdirectories at v0.1: `framework/` (analytical framework modules), `briefs/` (generated briefs), `manifest/` (citation resolution sidecars), and the root-level `traceleaf.md` (operator configuration) and `signal_log.md` (collected signals).

The operator should infer: this is my data. The system is my tool, not my landlord.

The operator should not infer: any relationship between the workspace and a Traceleaf-controlled service. There is no service.

### Concept 2: framework

The framework is the set of analytical conventions Traceleaf applies to brief synthesis. It includes: signal classification rules, prose standards, citation conventions, urgency tiering, and analytical structure templates.

Frameworks live in `framework/` as a directory of markdown files. Each file is a framework module. Module names are descriptive (`prose-standards.md`, `signal-classification.md`, `brief-structure.md`, etc.).

The operator can read every framework module. The operator can edit every framework module. The operator's edits persist across briefs and across Traceleaf updates (Traceleaf updates ship new default framework modules but never overwrite the operator's edits without warning).

The framework is the operator's voice expressed as code. Two operators using Traceleaf with the same competitor set produce different briefs because their frameworks differ.

The operator should infer: this is where I encode my analytical preferences.

The operator should not infer: that the framework is a one-time setup. The framework is meant to evolve as the operator's understanding sharpens.

### Concept 3: signal

A signal is one collected piece of information about a tracked competitor. Examples: a Schneider Electric press release announcing a new partnership; a Microsoft 10-Q mentioning a strategic acquisition; a customer interview transcript noting a competitor's pricing change.

Signals live in `signal_log.md` as markdown table rows. Each signal carries: a tracked competitor name, a source identifier, a date, a one-sentence description, a content excerpt or link, and a unique signal ID.

Signals are append-only. Once a signal is in the log, it stays. Even if the operator removes a competitor, signals about that competitor remain in the log; they are simply ignored by future brief synthesis.

Signals are deduplicated against each other. Re-running collection does not create duplicate signals.

The operator should infer: this is the raw material for briefs. The brief is downstream of the signal log.

The operator should not infer: that signals are facts. Signals are observations of source content. The interpretation belongs to the brief synthesis layer.

### Concept 4: brief

A brief is the analytical artifact Traceleaf produces. At v0.1, every brief is a weekly brief; v0.2+ may add other modes.

Briefs live in `briefs/` as date-stamped markdown files. Each brief has a sidecar manifest in `manifest/` with the same date stamp, holding citation resolution data.

A brief leads with an analytical conclusion, supports the conclusion with cited signals, and closes with a list of resolvable citations. Every analytical claim in the brief carries a typed citation that resolves to a source.

The operator can read every brief. The operator can edit every brief. The operator's edits persist (briefs are date-stamped; regeneration creates a new file with a new timestamp rather than overwriting). Edits an operator commits to git are the operator's permanent record.

The operator should infer: this is the artifact I share with my readers, after I read it and edit it. Traceleaf produces the first draft; the operator owns the final draft.

The operator should not infer: that the brief replaces the operator's analytical judgment. Traceleaf is a discipline-as-tool, not an analyst-replacement.

### Concept 5: citation

A citation is a typed pointer from an analytical claim in a brief to a source the claim rests on.

Citations live inline in brief prose using a specific syntax (specified in the Anchor Contract Specification doc). Every citation has a type, an identifier, and a manifest entry that resolves the citation to a reachable source.

Citations are validatable. The `traceleaf validate` command can verify that every citation in a brief resolves. The `traceleaf inspect` command can show what a specific citation points to.

The operator should infer: every claim in a Traceleaf brief is anchored to a source. A claim without a citation is a bug.

The operator should not infer: that a citation guarantees the claim is correct. Citations guarantee provenance, not truth. The operator's review still matters.

## How the concepts compose

The operator's daily experience is a flow through the concepts.

The operator runs collection. The system reads the operator's framework (specifically, the source registry and signal classification rules) and the existing signal log. The system queries external sources, deduplicates against the signal log, and appends new signals. The signal log grows.

The operator runs synthesis. The system reads the framework (specifically, the brief structure template, the prose standards, and the analytical conventions), reads the signal log (specifically, signals from the past seven days), and produces a brief. The brief is written with citations; the manifest is written alongside.

The operator reads the brief. The operator may click citations, which resolve via the manifest. The operator may edit prose, which persists in the brief file. The operator may edit framework modules, which persist for the next synthesis run.

The operator commits the workspace to git. The next week, the operator returns and runs collection again. The cycle repeats.

## What is intentionally not in the conceptual model

The prior project introduced several constructs that Traceleaf v0.1 deliberately omits to keep the mental model shallow.

No "compound signal." Aggregation across multiple signals is the brief's job, not a separate concept the operator must understand.

No "transition tracker." Multi-signal analytical constructs across competitors and time are a v0.2+ feature, not a v0.1 concept.

No "threat matrix" or "recommendation registry." Both are advanced analytical surfaces from the prior project that exceeded what an operator new to Traceleaf needs to understand at v0.1.

No "publisher" or "rendering target." Briefs are markdown; rendering is a v0.2+ extension.

No "audience taxonomy" or "reader segmentation." The brief has one audience: the operator and whoever the operator chooses to share it with. Reader-segment framing is a v0.2+ candidate.

No "feedback loop." Iteration on Traceleaf's output happens through the operator editing the framework, not through a formalized feedback mechanism.

These omissions are not deficiencies. They are design choices to keep v0.1 cognitively cheap to adopt.

## Concepts as documentation surfaces

Each concept maps to specific documentation.

Workspace is documented in the README and `QUICK_START.md`.

Framework is documented in the framework modules themselves (every module starts with a one-paragraph "what this is" header) and in the Functional Decomposition doc.

Signal is documented in `framework/signal-classification.md` and the Schema and Data Model doc.

Brief is documented in `framework/brief-structure.md` and in worked examples in the Tier 1 doc set.

Citation is documented in the Anchor Contract Specification.

## Concepts in the CLI

The CLI verbs map to concept operations.

`traceleaf setup` produces an initial workspace and framework.

`traceleaf collect` adds signals to the signal log.

`traceleaf compose` produces a brief from signals.

`traceleaf validate` checks a brief's citations.

`traceleaf inspect <citation>` shows what a citation points to.

The CLI does not surface workspace operations directly because workspace operations are operator-controlled (the operator uses git, file system tools, or whatever else they prefer). Traceleaf does not need to mediate workspace management.

## Working forward

The Naming and Terminology Guide finalizes the names of these concepts and ensures consistent usage across documentation. The Schema and Data Model doc specifies the exact data structures backing each concept. The Architecture Overview maps each concept to the underlying skill or module that implements it.
