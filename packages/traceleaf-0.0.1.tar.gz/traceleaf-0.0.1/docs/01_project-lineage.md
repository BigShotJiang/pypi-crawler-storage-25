# Project Lineage and What Travels to Traceleaf

## Conclusion

Traceleaf is a clean-slate rebuild of a CI tool informed by a seven-month engineering effort on a separate, in-production internal plugin. The prior plugin remains in production at a previous engagement and is not part of this project. Traceleaf inherits conceptual frameworks and engineering disciplines from that prior work but carries forward no operator-specific content, no code lineage, and no operational dependencies. This document captures what travels and what stays behind, and explains why the rebuild posture was chosen over an abstraction posture.

## Decisions to confirm

Before this document locks, the following items need an explicit yes or no from the project owner.

- The motivation sentence in the README will be a single sentence in the project owner's voice. Working draft: "I built this because competitive intelligence briefs deserve the same evidentiary discipline as any document you might have to defend in front of an adversary, and the tools I have used do not deliver that." Override or refine.
- The prior plugin is referenced in this document only as "a separate prior project." No operator name appears anywhere in the public Traceleaf documentation. Confirm.
- The IP posture is: Traceleaf is built on personal hardware, on personal time, with personal AI subscriptions. No code is copied from the prior plugin. Engineering patterns published in the prior plugin are retyped from concept rather than copy-pasted. Confirm.
- License is MIT. Confirm.
- Attribution is to the project owner under their own name. Confirm.

## The prior work in summary

The prior project ran for approximately seven months and produced three artifacts.

The first artifact is a working CI plugin currently at version 7.17.0. It runs as a Claude Code plugin against a specific operator's competitive intelligence operations. Its scope at v7.17.0 includes seven scheduled scout agents, a CI Analyst skill with ten analytical modes, thirty-two byte-identical-propagated framework modules, and a CI renderer skill at spec stage. It produces weekly briefs, monthly digests, quarterly assessments, KIQ responses, financial signal briefs, strategic comparisons, and filing alerts. The plugin substrate is markdown source-of-truth in git. The plugin is in active operational use and is not affected by Traceleaf.

The second artifact is a nine-function design-space survey conducted during the prior project. The survey explored Source Discovery, Deduplication, Extraction, Classification, State Maintenance, Retrieval, Synthesis, Quality Gates, and Distribution. Each function went through three research passes (Claude Research primary, Perplexity Deep Research supplement, Perplexity Model Council adversarial review) and produced a locked recommendation. The survey output runs to roughly eighty thousand words across nine function files plus a meta-coupling document.

The third artifact is a final-pass cross-cutting prioritization that scored each of the nine functions on magnitude, cost, constraint risk, and coupling leverage, sequenced the work into thirteen sprints, and identified a five-sprint critical path toward a v8.x release of the prior plugin.

The prior project also surfaced four cross-cutting architectural tensions, eight locked constraints, twenty-two-plus state-file families at v8.x scope, forty-four-plus quality gates, and a comprehensive productization-debt catalog enumerating sixteen operator-specific assumptions baked into v7.17.0.

## What was decided in the strategic pivot

After the survey closed, a strategic stress-test surfaced three plausible architectural futures: stay plugin-form and productize gradually, extract to a SaaS platform, or extract to a primitive library and SDK. The owner concluded that none of those paths were the right shape. Instead, the conclusion was: leave the prior plugin running for the original operator, start a new project from scratch with no operator constraints, and aim at a single north star.

The north star was articulated as: "A CI analyst at any company should be able to clone the repo, follow a quick-start, and produce their first useful brief within one hour."

The decision drivers behind clean-slate over abstract-and-extract were four:

1. Scrubbing operator-specific content out of the prior plugin without breaking the operational version is fragile. The result reads as "the prior plugin with names redacted."
2. The prior plugin embodies dozens of operator-shaped decisions. Some are right for a generic operator. Some are not. Abstraction forces argument-by-argument with the existing version. Clean-slate lets each decision be made fresh.
3. IP posture is much cleaner with a fresh codebase on personal hardware. No code lineage, no shared dependencies.
4. Operational continuity. The prior plugin keeps shipping value at the original engagement. The Traceleaf project is its own thing with its own clock.

## What travels to Traceleaf

Three categories of inheritance.

### General concepts and engineering patterns (carry forward freely)

These are the project owner's design ideas. They live independent of any codebase.

- The function decomposition principle (source ingestion, deduplication, extraction, classification, state maintenance, retrieval, synthesis, gating, distribution). Traceleaf does not need all nine at v0.1, but the decomposition is sound.
- Markdown source-of-truth on a git substrate. Operator-editable, audit-traceable, no proprietary backend.
- Typed-anchor citation contract. Traceleaf will re-derive its anchor types from scratch; the principle of typed citations with span resolution is what travels.
- Measurement-first posture. Held-out test sets and named defeat conditions before committing to architectural changes.
- The framework-module-as-context discipline.
- The validator script common shape: read input, exit codes 0/1/2/3+, named rule IDs surfaced in completion summaries.
- Sentinel registry pattern for tracking external dependencies that could silently shift.
- Per-family routing matrix concept.
- Pandoc as AST owner for distribution rendering.
- Gate registry pattern (declarative TOML or YAML registry over per-validator scripts).
- Lifecycle field set on gates: status, replaced_by, retire_after, applies_to_modes.
- Cumulative cost-per-run budgeting against an explicit per-output ceiling.

### Industry-standard concepts (carry forward freely; not the project owner's IP)

- Kent-term estimative-language scale (intelligence community standard, ICD-203 lineage).
- ICD-203 claim-type labeling: information, assumption, judgment.
- Pyramid Principle structure for analytical writing.
- Conformal prediction methods for classifier calibration (referenced but not yet applied at v0.1 scope).

### Disciplines as principle, not as code

- Anti-AI vocabulary discipline. "Synergy," "productize," "highlight" as a verb, "key" as a generic adjective, "showcase," "underscore," "valuable" without specification, and similar hollow corporate language stay banned.
- Em dash prohibition. The long dash is a tell of LLM-generated copy and is out across all Traceleaf writing.
- Clarity-as-foundation principle. Every word earns its place or gets cut.
- Conclusion-led structure. Lead with the point. Supporting evidence next. Detail last. Headers close completed lines of thought.

## What does not travel

Three categories of explicit non-inheritance.

### Operator-specific content

- The prior operator's tracked competitor list.
- The prior operator's company profile (any operator-named, operator-described content).
- The prior operator's service categories and threat dimensions, calibrated to a specific industry.
- The prior operator's transition trackers.
- The prior operator's foreign-filer scope (specific issuers in Korea, Taiwan, EU were the prior operator's competitors).
- Brief examples and demonstration data drawn from the prior operator's competitive set.
- Internal naming, paths, BL identifiers, sprint numbers, and version-history language that referenced the prior project's operational context.

### Code

No code is copied from the prior plugin into Traceleaf. Engineering patterns are retyped from concept. This is a belt-and-suspenders posture against any IP claim, and it has the side effect of forcing each component through a fresh design pass that drops accumulated cruft.

### Calibrations

The numerical thresholds in the prior plugin (Recall@10 0.85, anchor-faithfulness 0.97, gate-runtime 90s/$0.15 per brief, false-positive collapse <1%/month, the four-axis brief-quality bands) were tuned against a specific corpus and operating context. Traceleaf will ship sensible defaults but will not inherit specific calibration values without operator-side validation.

## Why a clean-slate rebuild and not an abstraction

The strategic stress-test considered an abstraction approach: take the existing plugin, sweep through the sixteen productization-debt items, retrofit each to be operator-templatable, ship the abstracted version. That approach was rejected for these reasons.

First, the productization-debt items are not all surface-level. Some are baked into framework modules, prompt language, and gate calibrations. Working around them while preserving the operational version risks one of two outcomes: a cosmetically-abstracted version that still leaks operator assumptions, or a near-complete rewrite that takes longer than starting fresh.

Second, the prior plugin embodies decisions that were correct for the prior operator but would not be the right defaults for a generic operator. Examples: thirteen consumer skills (most operators need three to five), thirty-two framework modules (most operators need eight to twelve), forty-four-plus gates (most operators need a starter pack of ten to fifteen), twenty-two-plus state-file families (most operators need a smaller core). Abstracting requires arguing each of these decisions. Rebuilding lets each decision be made fresh against the north star.

Third, IP cleanliness is much higher with a clean codebase on personal hardware. Even with employment-agreement clarity, a clean-slate build is more defensible than a "scrubbed" derivative.

Fourth, the operational continuity argument. The prior plugin must keep running at the original engagement without being broken. Touching its code to extract an abstraction creates a real risk of regression. Clean-slate decouples the two efforts entirely.

The cost of clean-slate is real. Roughly six weeks of build effort versus roughly four to six weeks of abstraction effort. The owner accepted this cost in exchange for the four advantages above.

## What stays in the prior plugin

The prior plugin continues running unchanged at the original engagement. Its v8.x sprint sequence, as designed in the survey's final-pass priorities, can proceed independently if the original operator chooses to fund that work. Traceleaf does not depend on, fork from, or modify the prior plugin in any way.

If the prior plugin and Traceleaf later converge (for example, if the original operator chooses to migrate to Traceleaf), that migration is its own future project with its own design pass.

## What this means for Traceleaf v0.1 scope

The clean-slate posture and the six-week build cap drive a deliberate scope discipline. Traceleaf v0.1 ships:

- One analytical mode (weekly brief).
- Two source classes (SEC EDGAR and simple web scrape via the standard library).
- One model (Anthropic Claude Sonnet, with operator-overridable model identifier).
- A typed-anchor citation contract with a small starting set of anchor types (count to be set in the Anchor Contract Specification, not in this document).
- A starter pack of quality gates (count to be set in the Functional Decomposition document).
- One distribution surface (markdown file in a workspace directory). No DOCX, no email, no Slack, no Teams, no MCP at v0.1.
- A first-launch onboarding flow that prompts the operator for company name, three to five competitors, and optional industry context, then generates the seed files. No demo data ships hard-coded.

Specifically deferred from v0.1:

- All eight other analytical modes from the prior plugin (monthly, quarterly, KIQ response, financial signal, strategic comparison, filing alert, inference refresh, service-category benchmark).
- Foreign-filer native APIs (Open DART, Taiwan MOPS, ESEF). The adapter pattern may be illustrated; specific operator integrations are operator-driven, not v0.1-shipped.
- All warehouse projections (Snowflake, BigQuery, Databricks, Postgres). Markdown-only at v0.1.
- All hosted observability (Cortex AI Observability, LangSmith, Arize, Patronus, Galileo, Braintrust). Stdlib telemetry only at v0.1.
- All vertical-integration MCP work (Klue, Crayon, AlphaSense Ingestion, Microsoft Copilot Studio).
- Voice and audio rendering.
- Multi-agent synthesis, contextual retrieval, GraphRAG, ColPali multimodal, agentic retrieval.

Each deferred item is a candidate for a future Traceleaf version if user signal supports it.

## Open questions and deferred items

The intentional gaps in this document, flagged for later resolution.

- Specific anchor type set for v0.1. To be derived in the Anchor Contract Specification doc, informed by the Conceptual Model and Naming and Terminology Guide.
- Specific gate starter pack at v0.1. To be derived in the Functional Decomposition doc.
- The exact onboarding-prompt sequence and the schema of the generated seed files. To be derived in the Onboarding and First-Launch Experience doc.
- The CLI command surface and skill naming. To be derived in the Naming and Terminology Guide and the Functional Decomposition doc, not pre-committed here.

## References

This document references the following prior-project artifacts. All references are by description rather than by name to keep the prior operator out of the public documentation.

- The seven-month internal CI plugin design effort (the "prior project").
- The nine-function design-space survey produced during that effort.
- The final-pass cross-cutting prioritization document produced at the close of that survey.

These are not public documents and are not part of the Traceleaf repository.
