# Learnings Catalog

## Conclusion

The prior project (a seven-month CI plugin engineering effort) produced a substantial body of design discipline that should inform Traceleaf as principle, not as code or content. This document captures the discipline-level synthesis: which constraints and patterns earned their weight, which were over-engineered for the scope, which cross-cutting tensions matter for Traceleaf, and which carry no relevance and stay behind. The output is a set of design principles that Traceleaf inherits without inheriting any specific implementation choices.

## Open questions and deferred items

- Whether the eight locked constraints from the prior project transfer wholesale to Traceleaf or whether some should be modified, dropped, or replaced. This document proposes a transfer set; final adjudication happens during the Requirements doc.
- Whether the measurement-first posture applies at v0.1 scope, given the small held-out test set sizes feasible at this stage. This document proposes a deferred form of measurement-first; the v0.1 Scope doc finalizes.
- Whether any of the four cross-cutting tensions surface as Traceleaf-relevant tensions or whether they were fully prior-project-specific.

## The eight locked constraints, evaluated for Traceleaf

The prior project enforced eight locked constraints that shaped every architectural decision. Each is evaluated below for Traceleaf relevance.

### 1. Auditability of every claim

The prior constraint required every analytical claim to trace to a source via a typed anchor. This is the principal differentiator of Traceleaf and transfers wholesale.

### 2. Git-friendliness with markdown source-of-truth

The prior constraint required all canonical state to live in markdown files committed to git. This transfers wholesale. Markdown source-of-truth is what makes Traceleaf operator-owned rather than vendor-trapped.

### 3. Operator-editability

The prior constraint required every artifact to be hand-editable by an operator without breaking the system. This transfers wholesale. The corollary is that Traceleaf cannot use formats or backends that are opaque to plain-text editing.

### 4. Byte-identical parity for shared framework modules

The prior constraint enforced that framework modules propagated to multiple skill directories must be byte-identical, with a sentinel-tracked parity gate. Relevance to Traceleaf depends on whether v0.1 has multiple skills with shared modules. At v0.1 scope (small skill count, small framework module count), the parity discipline is less load-bearing but is cheap to preserve. **Decision: keep the principle, defer the formal parity gate until the framework module count justifies it.**

### 5. Sentinel tracking for external dependencies

The prior constraint required every external dependency that could silently shift (API contracts, model versions, schema versions) to be sentinel-tracked. This transfers wholesale. Traceleaf's `check_installation.py` equivalent will track API contracts, model identifiers, and dependency pins from day one.

### 6. The typed anchor contract

The prior constraint enforced eight valid anchor types with span-resolution semantics. The principle of typed anchors with span resolution transfers; the specific eight types do not. Traceleaf will derive its own anchor type set in the Anchor Contract Specification doc.

### 7. Cost-per-run sensitivity

The prior constraint imposed an operator-funded cost ceiling that bounded model selection, gate complexity, and measurement obligations. The principle transfers; the specific numerical ceiling does not. Traceleaf will document a per-brief cost expectation in the Requirements doc but will not pre-commit to a specific dollar figure at v0.1.

### 8. Standard library preference for plugin scripts

The prior constraint biased against new third-party Python dependencies unless an explicit dependency budget entry justified each one. This transfers wholesale. Traceleaf v0.1 ships with a small explicit dependency list (Anthropic SDK, possibly `pypdf` for PDF reads, possibly `fastjsonschema` if JSON Schema validation is in v0.1 scope) and stdlib for everything else.

**Net result.** Six of eight constraints transfer wholesale. Constraint 4 (parity) carries forward as principle but the formal gate defers. Constraint 7 (cost-per-run) carries forward as principle without a specific numerical commitment at v0.1.

## The four cross-cutting tensions, evaluated for Traceleaf

The prior project surfaced four architectural tensions that did not resolve cleanly within any single function and required cross-function treatment.

### Tension 1: markdown-and-paths versus MCP-native interfaces

The prior tension acknowledged that the markdown source-of-truth posture might be a 2024-era architectural choice if MCP-native consumer surfaces become the dominant pattern by 2027. The prior project deferred MCP work behind an external trigger condition (three named industrial-B2B production deployments).

For Traceleaf, this tension is even more relevant because Traceleaf is positioned to be operator-owned and clone-and-run. MCP-native operator surfaces could displace the file-system substrate. The Traceleaf posture for v0.1: stay markdown-and-files, design with an explicit MCP escape hatch (a future-compatible schema is sketched in the Anchor Contract doc), and revisit when MCP adoption signals are clearer.

### Tension 2: procurement friction at the operator's scale

The prior tension acknowledged that legal review for any new vendor takes three to six months at the prior operator's scale. This tension is operator-specific. Traceleaf does not inherit it, because Traceleaf has no procurement at v0.1: the only third-party dependency is the Anthropic API, which the operator presumably already has if they are running Claude-based work.

This tension reappears if and when Traceleaf operators ask for foreign-filer APIs, hosted observability, or paid CI vendor integrations. At v0.1, it does not bind.

### Tension 3: messaging-surface footnote semantics loss

The prior tension surfaced when distribution surfaces (Slack, Teams) flatten markdown footnote citation syntax and lose the typed BL-051 anchor classes. The prior project resolved this with a dual-rendering convention: human-readable footnote markers plus a sidecar `sources` array preserving the typed anchor metadata.

For Traceleaf v0.1, this tension does not bind because v0.1 ships only the markdown distribution surface. The tension reappears when (or if) Traceleaf adds DOCX, email, Slack, Teams, or any rendering that flattens citation semantics. The v0.1 anchor contract should be designed with the dual-rendering convention as a forward-compatibility commitment so future renderers can adopt it without rework.

### Tension 4: MCP round-trip novelty for consumer-orchestration

The prior tension acknowledged that pushing CI briefs into MCP-native consumer surfaces (Klue, Crayon, AlphaSense Ingestion API) is unprecedented for the markdown-and-git pattern, and the prior project deferred all such work behind a schema-anchored Phase 1b commitment plus an external trigger.

For Traceleaf v0.1, this tension does not bind. Traceleaf v0.1 has no consumer-orchestration surfaces. The tension reappears at v0.2+ if MCP integrations enter scope.

**Net result.** One tension (Tension 1, markdown-versus-MCP) is live for Traceleaf and shapes design. Three tensions (Tensions 2, 3, 4) are dormant at v0.1 but should be tracked as forward-compatibility commitments.

## What was right-sized in the prior work

These elements of the prior project earned their weight at the scope they served. Traceleaf can adopt the underlying principle.

### The function decomposition

Source ingestion, deduplication, extraction, classification, state maintenance, retrieval, synthesis, gating, distribution. The decomposition is sound and maps well to any analyst-facing CI pipeline. Traceleaf v0.1 collapses several of these (no separate retrieval at v0.1, minimal deduplication, simple state) but the conceptual decomposition holds.

### The validator-script common shape

Read input, apply checks, exit codes 0/1/2/3+ with named rule IDs surfaced in completion summaries. This pattern is simple, stdlib-native, and operator-readable. Traceleaf adopts it.

### The framework-module-as-context discipline

Prompts and rules expressed as markdown files that are loaded into Claude's context at synthesis time, with explicit references to which modules apply to which mode. This pattern keeps prompt logic visible and operator-editable rather than buried in code. Traceleaf adopts it.

### The Pyramid Principle for analytical writing

Conclusion first, supporting evidence next, detail last, headers closing each line of thought. This is standard analytical writing discipline, well-documented externally (Barbara Minto's Pyramid Principle). Traceleaf brief structure inherits it.

### Estimative-language discipline (Kent terms)

Calibrated probability words ("almost certainly," "likely," "even chance," "unlikely," "almost no chance") with explicit numeric ranges, applied consistently across analytical claims. This is intelligence-community standard practice (ICD-203). Traceleaf adopts the discipline; specific terms ship in the Naming and Terminology Guide.

### Claim-type labeling

Every analytical claim labeled as information, assumption, or judgment, with separate rules for each. This is also ICD-203 lineage and earned its weight in the prior project. Traceleaf adopts it.

### Conclusion-led brief structure

Brief leads with the analytical conclusion (the BLUF pattern from intelligence writing), supporting signals next, detail and citations at the end. Traceleaf adopts this pattern.

## What was over-engineered for the scope

These elements of the prior project were correct for that operator's specific operational context but would be over-engineering for Traceleaf v0.1. They are flagged so v0.1 can avoid recreating them.

### Twenty-two-plus state-file families

The prior project's full v8.x sprint sequence reached 22+ state-file families. This count was driven by operator-specific needs (multiple scout types, calibration panels, gate registries, distribution logs, feedback queues, projection caches). Traceleaf v0.1 ships with roughly five state-file types: signal log, brief, anchor index, gate registry, and operator config.

### Forty-four-plus quality gates

The prior project's full v8.x scope reached 44+ gate types. Many of these were operator-specific or domain-specific (TOS-compliance gates for licensed sources, foreign-filer rate-limit gates, calibration-drift gates for classifier versions). Traceleaf v0.1 ships with a starter pack of roughly ten gates focused on the universal disciplines: anchor presence, prose standards, schema conformance, citation resolution, basic structural validity.

### Thirteen consumer skills

The prior project organized work across thirteen skill directories (multiple scout types, an analyst, a measurement skill, an ingest skill, etc.). Traceleaf v0.1 ships with three to five skills at most. The smaller count reflects the smaller v0.1 functional scope.

### Thirty-two byte-identical-propagated framework modules

The prior project byte-propagated 32 framework modules across consumer skills, with a parity-verification gate. Traceleaf v0.1 ships with roughly six to ten framework modules and a simpler parity expectation (manual verification rather than a dedicated gate).

### Five held-out test sets plus a defeat-condition window

The prior project's v8.x scope included five separate held-out test sets (state-projection regression, retrieval Recall@10, foreign-filer extraction-faithfulness, four-axis brief-quality, gate-quality) plus a continuous defeat-condition window. Traceleaf v0.1 ships with one held-out test set: a small brief-quality corpus (probably ten briefs against a hand-labeled reference) used to validate the synthesis layer.

### Mode-aware reranker selection

The prior project's Function 6 retrieval recommendation included a mode-aware reranker split (one reranker model for batch modes, another for interactive modes). Traceleaf v0.1 has no reranker because v0.1 has no retrieval layer beyond path-based reads. This re-enters scope only if v0.2+ adds retrieval and the held-out test set proves grep insufficient.

### Calibrated thresholds at numerical specificity

The prior project committed to specific numerical thresholds (Recall@10 0.85, anchor-faithfulness 0.97, false-positive collapse <1%/month, gate-runtime under 90 seconds and $0.15 per brief). These were tuned to a specific corpus and operating context. Traceleaf v0.1 ships with looser, principle-level thresholds (anchor presence at 100 percent, gate-runtime as a soft target, brief-quality measured qualitatively at v0.1) and tightens them as data accumulates.

## Disciplines that travel as principle

These principles transfer to Traceleaf without specific implementation details.

- **Citation discipline.** Every claim traces to a source. The source resolves to a span. The anchor type is typed and machine-readable.
- **Prose discipline.** No banned vocabulary. No em dashes. Conclusion-led structure. Headers close lines of thought. Short paragraphs. Distanced language for analytical claims; first-person only for explicit recommendations.
- **Measurement-first posture (deferred form).** Before committing to architectural complexity, document what the measurement signal is and what threshold it must meet. At v0.1, this can be lightweight (a one-paragraph description rather than a held-out test set) but the principle of "instrument before building" carries forward.
- **Sentinel-and-budget discipline for dependencies.** Every non-stdlib dependency is named, justified, and pinned. New dependencies require an explicit budget entry.
- **Operator-editability as a hard constraint.** No format that an operator cannot hand-edit. No backend that an operator cannot inspect.
- **Markdown source-of-truth.** Canonical state in markdown. Derived state (caches, indexes, embeddings) regeneratable from markdown.

## Patterns that should not travel

These patterns from the prior project are operator-specific or scope-specific and should not be carried into Traceleaf.

- **Specific scout taxonomy.** The prior project had seven scout types (CI Scout, Market Scout, Customer Scout, Vertiv Scout, SEC Scout, Technology Scout, plus a future-state). Traceleaf v0.1 has one source-collection skill with optional source modules. The taxonomy is re-derived in the Functional Decomposition doc.
- **Specific framework module set.** The prior project shipped thirty-two framework modules including operator-specific content (industry-specific threat dimensions, operator-named transitions, specific competitor profiles). Traceleaf v0.1 ships with general-purpose framework modules: prose standards, anchor contract, claim-type labeling, estimative language, brief structure.
- **Specific brief modes.** The prior project's ten analytical modes were tuned to one operator's analyst workflow. Traceleaf v0.1 ships with one mode (weekly brief). Additional modes ship at v0.2+ based on operator signal.
- **Specific gate calibrations.** The prior project's calibrated thresholds were corpus-specific. Traceleaf does not inherit them; defaults are documented as "starter values, expect to tune."
- **Specific state-file family count.** The prior project's twenty-two-plus state-file count is operator-specific. Traceleaf v0.1 ships with the smallest state-file set that supports the v0.1 functional scope.

## Measurement-first posture: how it applies at v0.1

The prior project committed to measurement-first as a hard discipline: no architectural enhancement deploys without a held-out test set proving the current path inadequate. This posture worked for the prior project's v8.x scope because the prior project was building from an in-production v7.17.0 baseline against which "current path inadequate" was measurable.

Traceleaf v0.1 does not have a baseline to measure against. There is no v0.0 of Traceleaf. The measurement-first discipline therefore takes a deferred form at v0.1:

- v0.1 ships with a small reference brief-quality corpus (roughly ten briefs hand-labeled for anchor accuracy and prose discipline) as the working test set.
- v0.1 documents qualitative success criteria (the 60-minute first-brief promise, the anchor-resolution rate at 100 percent, the prose-standards adherence as a binary check).
- v0.2 and beyond inherit the measurement-first posture in its full form: no enhancement ships without a named threshold on a maintained held-out test set.

This is a deliberate scope discipline. Insisting on full measurement-first at v0.1 would block the project from shipping. Insisting on full measurement-first from v0.2 onward keeps the discipline alive without front-loading it.

## References

- The prior project's nine function files and final-pass priorities document, which captured the design space exploration and locked decisions referenced above. These are not part of the Traceleaf repository and are referenced here only as the lineage source.
- Barbara Minto, *The Pyramid Principle*, for the conclusion-led analytical writing discipline.
- Office of the Director of National Intelligence, ICD-203 (Analytic Standards), for the estimative-language scale and claim-type labeling discipline.
- Sherman Kent, *Strategic Intelligence for American World Policy*, for the foundational treatment of estimative probability vocabulary in analytical writing.
