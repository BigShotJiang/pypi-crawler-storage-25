# Architecture Overview

## Conclusion

Traceleaf v0.1's architecture is a thin Python CLI orchestrating four skills (Setup, Collect, Compose, Validate) over a markdown-source-of-truth workspace, with Anthropic API as the only external dependency for inference. The architecture is deliberately small: roughly 2,000 to 3,500 lines of Python plus a documented framework module set, no database, no service layer, no client-side rendering, no MCP server. This document specifies the component decomposition, the data flow through the system, the dependency budget, the runtime model, and the areas where the architecture intentionally trades expressiveness for simplicity. The Anchor Contract Specification, Functional Decomposition, and Schema and Data Model docs specify the details; this document specifies the shape.

## Open questions and deferred items

- The exact dependency list is committed to the smallest viable set. A specific package count and version pinning happens at the time the build starts.
- The decision between embedded scripts inside skill directories versus a shared library is sketched here as embedded-with-shared-utility-module and finalized during build.
- The architecture is forward-compatible with v0.2+ surfaces (FTS5 retrieval, additional source classes, distribution targets). Forward-compatibility is documented; specific extension points are not pre-engineered.

## Architectural posture

Traceleaf v0.1's architecture honors the constraints from the Requirements doc.

Markdown source-of-truth. Every operator-inspectable artifact is markdown or simple JSON. No binary canonical state.

Plain-text editability. The operator can edit anything that is not derived. Derived artifacts (manifests, indexes if any) are regeneratable from sources.

Stdlib preference. The Python dependency budget is small. Where stdlib does not suffice, dependencies are explicit and justified.

No telemetry, no phone-home. Traceleaf does not send data to any service the project owner controls. External service calls go to Anthropic, SEC EDGAR, and operator-configured web sources, with only the data needed to fulfill the operator's request.

Operator-owned. There is no Traceleaf service. The operator runs Traceleaf locally on their machine.

## High-level component decomposition

Traceleaf v0.1 is a Python package with four primary skills plus a small set of shared utilities.

```
traceleaf/
  __main__.py             CLI entry point
  cli.py                  argument parsing, command dispatch
  config.py               operator configuration loader
  workspace.py            workspace path resolution
  framework_loader.py     framework module loader
  anchors.py              citation anchor handling
  inference.py            Anthropic API client wrapper
  skills/
    setup/
      __init__.py
      flow.py             interactive setup prompt sequence
      seeds.py            default file generation
    collect/
      __init__.py
      sources/
        edgar.py          SEC EDGAR collector
        web.py            simple web source collector
      log_writer.py       signal log writer
      dedup.py            content-based deduplication
    compose/
      __init__.py
      brief.py            brief synthesis orchestration
      claude_client.py    Claude inference client
      manifest_writer.py  citation manifest writer
    validate/
      __init__.py
      gates.py            gate registry and runner
      rules/
        prose_standards.py
        citation_resolution.py
        structural_validity.py
        ...
  framework/              default framework modules (markdown)
    core-rules.md
    prose-standards.md
    signal-classification.md
    brief-structure.md
    citation-conventions.md
```

This is illustrative; actual file naming and structure adjusts during build.

The four skills are loosely coupled. Each skill produces or modifies workspace state that the next skill consumes. Skills do not call each other directly; the CLI orchestrates the sequence.

Shared utilities (`config.py`, `workspace.py`, `framework_loader.py`, `anchors.py`, `inference.py`) are imported by skills but are not skill-specific. They are the small set of shared abstractions over the workspace.

## Data flow

The end-to-end data flow for the 60-minute path.

1. Operator runs `traceleaf setup`. The Setup skill prompts the operator, validates the API key, generates `traceleaf.md` and `signal_log.md` in the workspace, and copies the default `framework/` directory.

2. Operator runs `traceleaf collect`. The Collect skill loads `traceleaf.md`, identifies tracked competitors and source class enablement, queries each enabled source (EDGAR for filers, web for newsroom or blog content), deduplicates against `signal_log.md`, and appends new signals.

3. Operator runs `traceleaf compose`. The Compose skill loads `traceleaf.md` and the framework, reads the past seven days of signals from `signal_log.md`, sends a synthesis prompt to Claude with the relevant context, parses the response, validates that every claim has a citation, writes the brief to `briefs/YYYY-MM-DD_weekly.md`, and writes the manifest to `manifest/YYYY-MM-DD_weekly.json`.

4. Operator runs `traceleaf validate <brief-file>` (optional; also runs as part of compose). The Validate skill loads the brief and manifest, runs each gate rule against the brief, and reports any failures.

5. Operator runs `traceleaf inspect <citation-id>`. The Validate skill (specifically a sub-component) loads the manifest, finds the citation, retrieves the source content, and prints it.

State flows through the workspace files. Each skill is stateless beyond what it reads from and writes to the workspace.

## Runtime model

Traceleaf v0.1 is a synchronous, single-process Python CLI. No background workers, no async event loops, no message queues, no scheduling. Each command runs to completion or fails.

For collection, network calls to SEC EDGAR and web sources are made sequentially within the rate limit budget. Concurrency is not used at v0.1 because the latency is dominated by per-source rate limits, not by Python execution time.

For synthesis, the Claude API call is made synchronously. The operator sees a progress indication (a printed status line that updates) while the call is in flight.

For validation, gate rules run sequentially over the brief content. Validation latency is in the hundreds of milliseconds for a typical brief.

The runtime model is deliberately simple. Concurrency, async, and worker patterns are v0.2+ candidates if they prove necessary.

## Dependency budget

Traceleaf v0.1 ships with a small Python dependency set.

Required dependencies:

- `anthropic`: The Anthropic Python SDK. Used by the Compose skill for Claude inference.
- `requests`: HTTP client for SEC EDGAR and web source collection. Used by the Collect skill.
- `markdown-it-py` or equivalent: Markdown parsing. Used for citation extraction and brief structure validation.

Possibly required:

- `beautifulsoup4` or `lxml`: HTML parsing for web source collection. Used by the Collect skill if web sources return HTML.
- `pyyaml`: Configuration parsing if any configuration file is YAML rather than markdown frontmatter.

Forbidden at v0.1:

- Any database client.
- Any web framework (Flask, FastAPI, etc.).
- Any vector store, embedding library, or retrieval framework.
- Any test framework beyond pytest. (Pytest is permitted for the test suite but not shipped as a runtime dependency.)
- Any UI library.

The dependency budget exists to keep the install footprint small, the supply-chain surface narrow, and the operator's Python environment clean.

## Framework loading and operator overrides

The framework is a directory of markdown files. Each file has a name and content. The framework loader reads every file in `framework/` at the start of each command invocation, parses any frontmatter, and exposes the modules to the skill that needs them.

Operators can edit framework files. Operator edits persist across Traceleaf updates because the update mechanism (when v0.2+ adds one) does not overwrite operator-modified files without explicit consent.

Operator-added framework files (operators who add their own modules) are loaded and made available to skills through the same mechanism. Skills that use specific named modules (Compose uses `prose-standards.md` and `brief-structure.md`) do not break if the operator adds additional modules; they ignore what they do not need.

## Citation handling

Citations are managed by the `anchors.py` module. The module:

- Parses citation syntax from generated briefs (the syntax is specified in the Anchor Contract Specification).
- Validates that every analytical claim is followed by a citation.
- Writes the manifest sidecar with citation-to-source mappings.
- Provides the `inspect` command's resolution logic.

The citation handling is the architectural component most likely to evolve in v0.2+. The Anchor Contract Specification doc names the v0.1 anchor types and the contract; the implementation honors the contract through `anchors.py`.

## External dependencies

Traceleaf v0.1 calls three classes of external service.

Anthropic API. Required for synthesis. Operator-funded (the operator's API key). Calls happen during `traceleaf compose`. Failure modes: invalid key, rate-limited, network failure. The Compose skill handles each with an actionable error.

SEC EDGAR. Required for filer-based collection. Operator-funded by virtue of being a public service (no API key required). Calls happen during `traceleaf collect` for filers in the operator's tracked competitor set. Rate limit: 10 requests per second per SEC policy; Traceleaf respects this with a polite user-agent header.

Web sources. Optional, depends on the operator's source registry configuration. No authentication. Calls happen during `traceleaf collect`. Rate limit: 1 request per second per host with a polite user-agent header.

No other external services are called at v0.1.

## Logging and observability

Traceleaf v0.1 logs to stdout and stderr. No file-based logs, no external observability service.

Log levels: INFO for status messages, WARN for non-fatal issues, ERROR for command failures. The operator can adjust verbosity with `--verbose` and `--quiet` flags.

Each command's output includes:
- A starting line identifying the command and the workspace.
- Progress indication during long-running operations.
- A summary at the end (signals collected, brief written, gates passed, etc.).
- Any errors with rule IDs and suggested actions.

Hosted observability (Cortex, LangSmith, Patronus, Galileo, Braintrust) is forbidden at v0.1 by the no-telemetry constraint.

## Testing posture

Traceleaf v0.1 ships with a test suite that exercises the four skills against a frozen sample workspace. The tests cover:

- Setup flow correctness (does setup produce the expected workspace from a known-good input set).
- Collection idempotency (does running collect twice not duplicate signals).
- Synthesis output structure (does compose produce a brief that has the expected structural shape).
- Gate correctness (does validate flag known-bad briefs and pass known-good briefs).
- Citation resolution (does inspect retrieve the expected source for a known citation).

Tests run against a frozen sample workspace that ships with the repository. The sample workspace has a small fixed competitor set (not the operator's real set) and pre-collected signals. The synthesis test uses recorded Claude responses (via VCR or equivalent) so the tests do not require API access.

The test suite is the codebase's own self-discipline check. The repository's CI runs the tests on every commit.

## Forward compatibility

The architecture is shaped for v0.2+ extensions without pre-engineering them.

Additional source classes (foreign filers, AlphaSense Ingestion API, Crawl4AI integration) plug into the Collect skill's `sources/` directory. The interface is "given an operator config, return a list of new signals."

Additional analytical modes (monthly, quarterly, KIQ) plug into the Compose skill's brief generation. The interface is "given a signal log and a mode argument, return a brief."

Additional gate rules plug into the Validate skill's `rules/` directory. The interface is "given a brief and a manifest, return a list of failures."

Distribution surfaces (DOCX, PDF, email, Slack) are explicitly out of scope at v0.1. When they ship, they are a new skill at the same level as Compose, reading briefs and producing rendered artifacts.

A retrieval layer (FTS5 over the signal log, sqlite-vec for embedding-based retrieval) is out of scope at v0.1. When it ships, it sits between the workspace and the Compose skill.

The architecture is designed so that v0.2+ additions extend it rather than rewrite it.

## Areas of intentional simplicity

Several places where Traceleaf v0.1 trades expressiveness for simplicity.

No plugin system. Skills are first-class Python modules in the package. The operator does not register custom skills or call into Traceleaf programmatically. If the operator wants custom behavior, they edit the framework or the source.

No configuration management beyond `traceleaf.md`. There is one configuration file. There is no environment variable layer, no command-line override beyond the documented flags, no hierarchical config.

No internationalization. Traceleaf v0.1 is English-only. Framework modules are written in English. Brief output is in English. The CLI is in English.

No authentication or access control. Traceleaf is a single-operator local tool. There are no users beyond the operator.

No data migration tools. Operator workspaces evolve manually if the framework changes shape across versions. v0.2+ may add migration tooling if signal warrants.

These simplicities exist because v0.1 is small. They are revisited as scope grows.

## Working forward

The Functional Decomposition doc names every skill, every module, and every script that ships in v0.1, mapping them to the components in this overview. The Schema and Data Model doc specifies the data structures. The Anchor Contract Specification specifies the citation handling that this overview describes at a high level. The v0.1 Scope and Acceptance Test doc operationalizes the test suite this document gestures at.
