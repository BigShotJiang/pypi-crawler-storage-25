# Anchor Contract Specification

## Conclusion

Traceleaf v0.1 ships with a typed citation system called the anchor contract. Every analytical claim in a generated brief carries an inline anchor that names a type, an identifier, and an optional locator within the source. The anchor resolves to source content through a manifest sidecar that ships with each brief. The v0.1 contract supports four anchor types: signal, prior-brief, source-document, and synthesis. This document specifies the syntax, the type semantics, the manifest schema, the resolution algorithm, and the validation rules. The contract is enforced by the Validate skill; a brief that fails the anchor contract cannot pass the gate set.

## Open questions and deferred items

- The four anchor types committed at v0.1 are the minimum to support the named source classes (SEC EDGAR, web sources). Additional types (transition-tracker observation, profile fact, threat-matrix dimension) are v0.2+ candidates.
- The locator syntax is specified at v0.1 as substring-match; range-based locators (line numbers, paragraph indices, character offsets) are v0.2+ candidates if substring-match proves insufficient.
- Resolution semantics for sources that change after collection are specified here; the precise SLA for citation freshness is set in the Requirements doc as 24 hours and revisited if practice shows it is too generous or too strict.

## Why anchors exist

Generative AI produces fluent prose that sounds confident regardless of whether the underlying claims are correct. The prior project's experience with Claude inference and the broader industry experience with LLMs both confirm that fluency does not imply accuracy. The countermeasure is to require every analytical claim to point at a source that the operator (or anyone reviewing the brief) can verify.

The anchor contract makes citation discipline a structural property of Traceleaf output. A brief without anchors fails the gate. A claim without an anchor is a bug.

The anchor contract differentiates Traceleaf from existing CI tools (which generally do not enforce per-claim citation) and from generic AI writing tools (which do not provide citation infrastructure at all).

## Anchor syntax

Anchors appear inline in brief prose immediately following the claim they support. The syntax is:

```
[anchor:type:identifier:locator]
```

Example:

```
Schneider Electric announced a partnership with NVIDIA on March 15 [anchor:signal:sig-2026-03-15-001:].
```

The four parts:

- `anchor:` is a literal prefix that identifies this as an anchor (not a markdown link or other syntax).
- `type` is one of four allowed values (signal, prior-brief, source-document, synthesis).
- `identifier` is a unique string within the type. Format depends on type (specified below).
- `locator` is an optional substring within the source the anchor points at. Empty if the anchor points at the source as a whole.

The syntax is chosen to be greppable, parsable by a simple tokenizer, and visually distinguishable from regular markdown links.

Anchors do not interact with markdown link syntax. A claim may have an anchor and a markdown link in the same sentence; they serve different purposes.

## The four anchor types

### Type 1: signal

Points at a single signal log entry.

Identifier format: `sig-YYYY-MM-DD-NNN` where YYYY-MM-DD is the date the signal was first collected and NNN is a zero-padded sequence number among signals collected on that date.

Resolution: the manifest maps the identifier to a row in `signal_log.md`. The inspect command shows the row.

Use case: any analytical claim grounded in a specific collected signal. The most common anchor type.

### Type 2: prior-brief

Points at a section or claim in a previously generated Traceleaf brief.

Identifier format: `brief-YYYY-MM-DD-MODE-section` where YYYY-MM-DD is the brief date, MODE is the brief mode (`weekly` at v0.1), and section is a section identifier within the brief.

Resolution: the manifest maps the identifier to a section in `briefs/YYYY-MM-DD_MODE.md`. The inspect command shows the section.

Use case: analytical claims that build on prior briefs. ("As noted in last week's brief, the Schneider partnership trajectory continues...")

### Type 3: source-document

Points at an external source the brief synthesis used directly.

Identifier format: `src-NNN` where NNN is a zero-padded sequence number among source documents in the manifest. Source-document anchors are typically less common than signal anchors because most source content gets converted into signals first; source-document anchors are reserved for cases where the synthesis layer used the source directly.

Resolution: the manifest carries a URL, a content hash, and a retrieval timestamp for the source. The inspect command surfaces the URL and the retrieval timestamp; the operator can reach the source manually.

Use case: a Compose-time fetch that is not a tracked signal. Rare at v0.1; more common when v0.2+ adds direct retrieval.

### Type 4: synthesis

Points at a synthesis-internal aggregation that does not have a single source.

Identifier format: `syn-YYYY-MM-DD-NNN`.

Resolution: the manifest carries an aggregation description (a short prose explanation of which signals or sources the synthesis combined). The inspect command shows the description.

Use case: claims that aggregate across multiple signals. ("Three competitors announced AI-related partnerships this week [anchor:synthesis:syn-2026-04-30-001:]"). The synthesis anchor's identifier resolves to a description like "Aggregation of [anchor:signal:...] and [anchor:signal:...] and [anchor:signal:...]"; the description is itself a list of underlying signal anchors that resolve normally.

The synthesis type exists because some claims are genuinely cross-signal observations rather than single-source claims. Forcing every such claim to cite only one signal would be dishonest. The synthesis type makes the aggregation explicit and inspectable.

## Manifest schema

Each brief has a sidecar manifest at `manifest/YYYY-MM-DD_MODE.json`. The manifest is JSON, schema:

```json
{
  "brief_file": "briefs/2026-04-30_weekly.md",
  "brief_date": "2026-04-30",
  "brief_mode": "weekly",
  "generated_at": "2026-04-30T15:23:11Z",
  "anchors": {
    "sig-2026-04-25-001": {
      "type": "signal",
      "source_file": "signal_log.md",
      "source_locator": "row-id:1042",
      "summary": "Schneider Electric announced partnership with NVIDIA"
    },
    "brief-2026-04-23-weekly-section-2": {
      "type": "prior-brief",
      "source_file": "briefs/2026-04-23_weekly.md",
      "source_locator": "## Top signals",
      "summary": "Coverage of Schneider partnership trajectory"
    },
    "src-001": {
      "type": "source-document",
      "url": "https://www.se.com/ww/en/about-us/newsroom/...",
      "content_hash": "sha256:abc123...",
      "retrieved_at": "2026-04-25T09:14:22Z",
      "summary": "Schneider press release on NVIDIA partnership"
    },
    "syn-2026-04-30-001": {
      "type": "synthesis",
      "aggregation_of": ["sig-2026-04-25-001", "sig-2026-04-26-002", "sig-2026-04-27-003"],
      "summary": "Aggregation: three competitors announced AI partnerships this week"
    }
  }
}
```

The manifest is the resolution layer. The inspect command reads the manifest, finds the anchor by identifier, and uses the type-specific fields to retrieve and display source content.

## Resolution algorithm

Given an anchor `[anchor:type:identifier:locator]`:

1. Open the brief's manifest sidecar.
2. Find the anchor in the manifest by identifier.
3. Use the type-specific fields to retrieve source content:
   - For `signal`, open `source_file`, find `source_locator`, return the matching row.
   - For `prior-brief`, open `source_file`, find `source_locator`, return the section content.
   - For `source-document`, return the URL plus retrieval timestamp; if a local cache exists, return the cached content; otherwise instruct the operator to retrieve manually.
   - For `synthesis`, return the `summary` plus the list of underlying anchors; recursively resolve those if requested.
4. If `locator` (the fourth part of the anchor syntax) is provided, return only the substring within the resolved source content that matches `locator`.

Resolution failures (manifest missing, identifier missing in manifest, source file missing, source content missing) are reported with the failing step.

## Validation rules

The Validate skill enforces the anchor contract through the following rules.

**Rule A.1 — every analytical claim has an anchor.** A sentence that makes an analytical claim (defined by structural cues: declarative claims about competitors, market conditions, or analytical assertions) must end with an anchor. The implementation parses the brief, identifies analytical sentences via simple heuristics (any sentence in a Top Signals or Analysis section), and checks for trailing anchor syntax. Failures are reported with the line number of the offending claim.

**Rule A.2 — every anchor resolves.** Each anchor in the brief must resolve through the manifest. The validation runs the resolution algorithm for every anchor and checks that the resolution succeeds. Failures are reported with the failing anchor and the failure step.

**Rule A.3 — anchor types are valid.** Anchors must use one of the four committed types. Anchors with other types fail validation.

**Rule A.4 — anchor identifiers follow type-specific format.** Each type's identifier format is enforced. An identifier that does not match its type's regex fails validation.

**Rule A.5 — manifest is internally consistent.** Every anchor referenced in the brief appears in the manifest. Every anchor in the manifest appears in the brief. (The second direction guards against manifest drift.)

**Rule A.6 — synthesis anchors point at real underlying anchors.** A synthesis anchor's `aggregation_of` list contains identifiers that themselves appear in the manifest.

These rules are enforced as gates. A brief that fails any rule fails the gate set.

## Anchor authoring

The Compose skill is responsible for producing anchors. The synthesis prompt to Claude includes specific instructions on the anchor syntax and the requirement that every analytical claim must carry one.

The Compose skill post-processes the Claude response to:
- Verify every analytical claim has an anchor (Rule A.1).
- Generate the manifest by resolving each anchor's source.
- Reject the brief if anchors are missing or malformed; retry the synthesis up to a small number of times before failing with a clear error.

Operator-edited briefs may introduce new claims without anchors. The Validate skill flags these on the next validation run; the operator is responsible for either adding an anchor or removing the claim.

## Anchor contract for v0.2+

The anchor contract at v0.1 covers the v0.1 source classes. v0.2+ source classes (foreign filers, AlphaSense, etc.) introduce additional anchor types. The contract is designed to extend by adding new types rather than reshaping existing ones.

Specifically, v0.2+ may add:

- `transition-tracker-observation` — for analytical constructs that track multi-competitor patterns over time. Identifier format: `tt-slug-NNN`.
- `profile-fact` — for claims grounded in operator-curated competitor profile content. Identifier format: `pf-competitor-section`.
- `threat-matrix-dimension` — for claims grounded in standing threat assessment state. Identifier format: `tm-competitor-dimension`.
- `regulatory-filing-section` — for claims grounded in specific sections of SEC filings (rather than signals derived from filings). Identifier format: `rf-filer-period-section`.

Each new type extends the manifest schema with type-specific fields. The validation rules apply unchanged.

## What the anchor contract does not do

The anchor contract guarantees provenance, not truth. A claim with a valid anchor whose underlying source is itself wrong remains wrong. Anchors do not relieve the operator of analytical responsibility; they make the operator's work easier to audit.

The anchor contract does not enforce specific analytical conclusions. Two operators can produce briefs from the same signal log with different conclusions, and both briefs can pass the anchor contract.

The anchor contract does not interact with claim-type labeling (information, assumption, judgment per ICD-203). Claim-type labeling is a v0.2+ candidate; if it ships, anchors and labels coexist.

The anchor contract does not interact with calibrated estimative language (Kent terms). Estimative language is a v0.2+ candidate; if it ships, the language gate is separate from the anchor gate.

## Working forward

The Functional Decomposition doc maps the anchor contract to the specific code modules that implement it (`anchors.py`, the Validate skill's gate rules). The Schema and Data Model doc specifies the manifest JSON schema in machine-readable form. The v0.1 Scope and Acceptance Test doc includes anchor-contract enforcement as part of the launch acceptance criteria.
