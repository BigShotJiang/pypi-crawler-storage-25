# Naming and Terminology Guide

## Conclusion

Traceleaf v0.1 commits to a small, consistent vocabulary across the product, the documentation, and the CLI. The product name is Traceleaf. The CLI is `traceleaf`. The five primary concepts (workspace, framework, signal, brief, citation) are named with their plain-English meanings. The four CLI verbs (setup, collect, compose, validate) plus one inspection verb (inspect) name what they do without metaphor or jargon. This document specifies every name, every term, and every banned term, and provides the rationale for each choice so that future naming decisions can be evaluated against the same posture.

## Open questions and deferred items

- The product name "Traceleaf" is committed. A trademark search and domain availability check are pending; if either surfaces a blocker, this document gets revised.
- Some terms (specifically the names of the four anchor types) are sketched here and finalized in the Anchor Contract Specification doc.
- Future v0.2+ concepts (transition tracker, threat matrix, recommendation registry) are not named here because they are not in v0.1.

## Naming posture

Traceleaf names follow these principles, in order of precedence.

Plain English wins. If a plain-English word describes the thing, use it. "Brief" is preferred over "deliverable," "artifact," or "output." "Citation" is preferred over "anchor," "reference," or "trace."

Exception: technical terms that have established meaning in the analytical-rigor space are kept even when more common words exist. "Citation" is technical; "reference" is not. "Anchor" is the prior project's internal term that is mostly preserved as a shorthand inside the Anchor Contract Specification doc but not exposed in operator-facing surfaces.

Verb-first commands. Every CLI command is a verb. The operator does not run nouns; the operator runs actions.

No metaphors. Traceleaf is not a "garden," a "newsroom," a "studio," or a "workshop." It is a tool. Naming honors that.

No version of "AI" in operator-facing names. The operator is not running "AI brief generation"; the operator is running brief composition. The fact that Claude inference is in the loop is implementation, not identity.

No proprietary internal terms leaking into operator-facing surfaces. The prior project had several internal terms (BL-XXX backlog identifiers, sprint numbers, mode numbers like "Mode 8") that operators never needed to see. Traceleaf carries no equivalents.

## Product name

Traceleaf. Capitalized when standalone, lowercase when used as the CLI command (`traceleaf`). The name is one word, no hyphen. Pronounced as written.

The name is not justified by an acronym or a backronym. It does not stand for anything.

## CLI command names

The CLI is `traceleaf`. Subcommands are verbs.

`traceleaf setup`. Initial workspace setup. Run once per workspace.

`traceleaf collect`. Source collection. Pulls signals from configured sources, appends to signal log.

`traceleaf compose`. Brief synthesis. Reads the signal log, produces a brief.

`traceleaf validate`. Brief validation. Runs the gate set against a generated brief.

`traceleaf inspect <citation-id>`. Citation inspection. Returns the source content a citation points to.

The verbs are deliberate. Setup is a one-time thing; the verb conveys that. Collect is what the operator is doing (collecting signals); the verb is concrete. Compose is what the synthesis does (composing prose from signals); the verb is more accurate than "generate" or "synthesize" in operator-facing language. Validate names the gate operation. Inspect is the standard term for "look at this thing in detail."

Two verbs were considered and rejected. "Build" was rejected because Traceleaf is not a builder; it is a composer. "Run" was rejected because it is too generic; the operator runs Traceleaf overall, but specific commands deserve specific names.

## Concept names

The five primary concepts.

**Workspace**. The directory the operator runs Traceleaf inside. Plain English. Same term used in editors, IDEs, and other developer tools. Operator-recognizable.

**Framework**. The set of analytical conventions Traceleaf applies. Plain English with a slight technical lean. The term carries enough weight to communicate that the framework is more than configuration; it encodes analytical posture.

**Signal**. A single collected piece of information about a tracked competitor. The term is borrowed from the CI domain where "signal" has established meaning ("market signal," "intelligence signal"). It is not "data point," "observation," or "input" because all three lose the connotation of meaningful pickup from a noisy source.

**Brief**. The analytical artifact Traceleaf produces. The term is borrowed from the CI domain (and from journalism, intelligence community, legal practice) where "brief" means a short, focused analytical document. It is not "report," "document," or "deliverable."

**Citation**. A typed pointer from an analytical claim to a source. The term is borrowed from academic and journalistic practice. It is not "anchor" (which was the prior project's internal name; carried forward only in the contract specification doc), "reference" (too vague), or "footnote" (too narrow).

## Filename and directory naming

Workspace artifacts use predictable names.

`traceleaf.md` is the operator configuration. Singular file. Lives at the workspace root.

`signal_log.md` is the signal collection. Singular file. Lives at the workspace root. Snake case preferred over kebab case for cross-platform compatibility.

`framework/` is the directory of framework modules. Plural directory; modules are named by their content (`prose-standards.md`, `signal-classification.md`, etc.).

`briefs/` is the directory of generated briefs. Plural directory; briefs are named by date and mode (`YYYY-MM-DD_weekly.md`).

`manifest/` is the directory of citation resolution sidecars. Plural directory; manifests are named to match their briefs (`YYYY-MM-DD_weekly.json`).

The naming conventions favor the operator's eye. A directory listing of a workspace tells the operator what is there without further explanation.

## Banned terms

These terms appear in CI tools, AI products, and analytical software but are banned from Traceleaf operator-facing surfaces.

"Insights." A meaningless modifier. A brief contains analysis; the analysis may or may not be insightful. Calling everything an "insight" inflates the language.

"Intelligence" as a marketing word. The product is competitive intelligence software; the briefs are CI briefs; the field is CI. But "intelligence" used as a generic pump-up word ("intelligence-grade output," "intelligence-quality citations") is banned.

"Smart" as a modifier. Smart citations, smart synthesis, smart anything. The product is not smart; it is disciplined. The operator is smart.

"AI-powered." The fact that Claude inference is involved is implementation. The operator does not need to be reminded of it in every product surface.

"Magic." Traceleaf is not magic. Every behavior is deterministic given inputs (modulo Claude's stochastic generation, which is bounded by gates and citations).

"Solution." Traceleaf is a tool. It does not "solve" CI; it disciplines a piece of CI work.

"Platform." Traceleaf is a single-purpose tool. It is not a platform.

"Leverage" (verb). Use "use" instead.

"Utilize." Use "use" instead.

The em dash. The product's prose standards ban em dashes from generated briefs; this style guide bans them from operator-facing documentation as well, by the same logic. (See `framework/prose-standards.md` for the operator-controllable rule.)

## Brand voice

Traceleaf documentation and product surfaces use a voice with these properties.

Direct. Sentences make claims and back them. Conditional and hedge constructions are allowed but not used as filler.

Operator-respectful. The operator is presumed competent. The product does not over-explain, condescend, or hand-hold.

Specific. Examples are concrete. Numbers are exact. Vague generalizations are rewritten until they are specific.

Calm. The product does not exclaim. Briefs do not contain exclamation marks. The CLI does not emit "" success messages. Status output is informational.

Spare. The product does not pad sentences with "in order to," "the fact that," or "it is important to note." If a word can be removed without loss of meaning, it is removed.

This voice is consistent across the README, the QUICK_START, the CLI help text, the prompts in the setup flow, the framework modules, and the generated briefs. The product's tone is the same wherever the operator encounters it.

## Naming for v0.2+ candidates

Several v0.2+ candidates need names if they ship. This document does not commit names but records the candidates.

If the system grows additional analytical modes (monthly digest, quarterly assessment, KIQ response), the modes will be named with their function (`monthly`, `quarterly`, `kiq`) as command arguments to `traceleaf compose`.

If transition trackers ship, they will likely be called "trackers" in operator-facing surfaces, with "transition" as a category modifier where needed.

If the threat matrix construct ships, it will be called a "matrix" with "threat" as a modifier; the operator-facing name might be "competitive matrix" depending on how it is positioned.

If recommendation registries ship, the operator-facing name is undecided; "recommendation log" is a candidate.

These names are not committed. They are placeholders for the v0.2+ scoping document.

## Banned naming patterns from the prior project

The prior project used several naming patterns that exceeded what operators needed and that Traceleaf does not carry forward.

Mode numbers. The prior project's CI Analyst skill had Modes 1 through 9 plus a Mode 10 that was deferred. Operators learning the system had to memorize what each Mode number did. Traceleaf names modes by function (weekly, monthly, etc.), not by number.

Backlog identifiers in operator-facing text. The prior project's documentation referred to BL-XXX identifiers in places operators encountered. Traceleaf documentation uses backlog identifiers only in internal development artifacts; operator-facing documentation describes features by what they do.

Sprint version references. The prior project's documentation referenced specific sprint versions ("at v6.8.0," "as of Sprint 32"). Traceleaf operator-facing documentation references the running version of Traceleaf (`traceleaf --version`) and otherwise speaks in present tense.

Internal codenames. The prior project had internal codenames for tools and frameworks (Cowork, Council, etc.) that occasionally leaked. Traceleaf carries no codenames.

## Working forward

The Architecture Overview, the Anchor Contract Specification, and the Functional Decomposition docs use the names committed here. Any name that is finalized in those docs (specifically the four anchor type names) updates this document by amendment. The naming posture takes precedence over any individual name; if a name proves wrong in practice, it is replaced consistent with the posture.
