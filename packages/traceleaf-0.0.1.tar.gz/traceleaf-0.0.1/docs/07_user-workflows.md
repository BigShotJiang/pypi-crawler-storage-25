# User Workflows and Journey Maps

## Conclusion

Traceleaf v0.1 supports five named user workflows: First-Launch (the 60-minute path from clone to first brief), Weekly Brief Cycle (the recurring operating loop), Brief Editing and Iteration (operator-driven prose and framework refinement), Source Set Update (changes to tracked competitors or source configuration), and Error Recovery (recovery from common failure modes). Each workflow maps user steps to system responses, names the artifacts produced or modified, and identifies the failure modes the workflow must handle. Workflows are designed to be discoverable from the documentation and from the CLI itself; an operator should not have to read this document to operate the system, but the workflows specified here are the contract the documentation and the CLI honor.

## Open questions and deferred items

- Workflow timings are estimates based on the 60-minute promise unpacked in the North Star doc. Real-world variance is expected and tracked in the post-launch signal phase.
- The Brief Editing and Iteration workflow is intentionally lightly specified at v0.1; the operator is presumed to know how to edit markdown. v0.2+ may add operator-experience features that formalize this.
- Error Recovery covers known failure modes; novel failure modes encountered in the field feed back into the workflow definitions.

## Workflow conventions

Each workflow is described in a consistent format: trigger, preconditions, steps, artifacts produced or modified, failure modes, and exit criteria. The format is operator-facing in spirit; CLI command names use the placeholder `traceleaf <verb>` until the Naming and Terminology Guide finalizes them.

User actions are written in the second person. System responses are written in the third person. Artifacts are named with workspace-relative paths.

## Workflow 1: First-Launch (the 60-minute path)

### Trigger

A new operator clones the Traceleaf repository for the first time and wants to produce a usable brief.

### Preconditions

The operator has Python 3.10 or later installed, has an Anthropic API key, has internet access, and has identified three to five competitors they want to track. The operator has read the README's first paragraph and decided Traceleaf is worth trying.

### Steps

Step 1, the operator clones the repository and installs dependencies. Expected duration: 5 minutes. Documentation surface: README and `QUICK_START.md`. Commands: `git clone`, `cd traceleaf`, `pip install -r requirements.txt`.

Step 2, the operator runs the setup command. Expected duration: 5 minutes. The setup flow prompts for company or product context (optional), three to five tracked competitors, optional industry context, and Anthropic API key. The setup flow validates the API key by making a probe request, generates the operator's seed files (configuration markdown, empty signal log, empty workspace state), and confirms readiness. Command: `traceleaf setup`.

Step 3, the operator runs source collection. Expected duration: 15 to 20 minutes (mostly waiting on external API calls). The collection layer queries SEC EDGAR for the tracked competitors that file with the SEC, queries the configured web sources for newsroom or blog content, deduplicates against the operator's existing signal log, and appends new signals to the signal log. Command: `traceleaf collect`.

Step 4, the operator runs brief synthesis. Expected duration: 5 to 10 minutes. The synthesis layer reads the signal log, selects signals from the past seven days, generates the analytical brief through Claude inference, validates the brief against the gate set, and writes the brief to `briefs/YYYY-MM-DD_weekly.md`. Command: `traceleaf compose`.

Step 5, the operator reads the brief, clicks two or three citations to verify they resolve, and decides whether the output is useful. Expected duration: 15 to 20 minutes. No system action; the operator reads in their preferred markdown viewer or text editor.

### Artifacts produced

- `traceleaf.md` (operator configuration)
- `signal_log.md` (collected signals from this session)
- `briefs/YYYY-MM-DD_weekly.md` (the first brief)
- `manifest/YYYY-MM-DD_weekly.json` (sidecar with citation resolution data)

### Failure modes

- API key invalid: setup command fails with an actionable error message and aborts before generating seed files.
- Network failure during collection: the collection command preserves any signals collected before the failure, marks the source class as partially collected, and logs the failure to the operator workspace.
- Synthesis failure: the synthesis command preserves any partial state, surfaces the failure with an actionable error, and offers a retry path.
- Gate failure on first brief: the brief is written but flagged as gate-failing; the operator sees the failure list and can decide to override, edit, or regenerate.

### Exit criteria

The operator has read a brief, verified citations, and formed an opinion on whether Traceleaf delivers value.

## Workflow 2: Weekly Brief Cycle

### Trigger

A returning operator wants to produce this week's brief.

### Preconditions

The operator has previously completed First-Launch. Their workspace is intact. Their tracked competitor set is current.

### Steps

Step 1, the operator runs collection. Duration: 10 to 20 minutes. Same behavior as First-Launch step 3, but deduplication against the existing signal log skips already-known signals.

Step 2, the operator optionally reviews the signal log. Duration: 0 to 10 minutes. The operator may scan the new signals to spot anything notable before synthesis. This step is not required; synthesis works whether or not the operator reviews first.

Step 3, the operator runs synthesis. Duration: 5 to 10 minutes. Same behavior as First-Launch step 4.

Step 4, the operator reads, edits, and commits the brief. Duration: 15 to 30 minutes depending on how much editing the operator wants to do. The operator opens the generated brief, may edit prose, may regenerate sections, and commits the final version to the workspace git repo.

### Artifacts produced or modified

- `signal_log.md` (appended)
- `briefs/YYYY-MM-DD_weekly.md` (created)
- `manifest/YYYY-MM-DD_weekly.json` (created)
- Possibly `traceleaf.md` (if the operator updates the competitor set during this cycle, see Workflow 4)

### Failure modes

Same as First-Launch, with one addition:
- Stale state: if the operator's workspace has diverged from the current Traceleaf version (the operator pulled a Traceleaf update without re-running setup), the cycle commands surface a version mismatch and offer a migration path.

### Exit criteria

A new brief is committed to the operator's workspace.

## Workflow 3: Brief Editing and Iteration

### Trigger

The operator has read a Traceleaf-generated brief and wants to change something about it.

### Preconditions

A brief exists in `briefs/`.

### Steps

Three editing modes are supported.

Mode A, prose-level editing. The operator opens the brief in a text editor, edits prose, and saves. No system action. The operator's edits are now part of the brief; if Traceleaf regenerates the brief later, the operator's edits are overwritten unless the operator commits the brief to git first (which is the recommended pattern).

Mode B, framework-level editing. The operator opens the relevant framework module file (under `framework/`) and edits the analytical posture, signal classification rules, prose standards, or related discipline. Saves. The next brief synthesis run picks up the framework changes. Edits are persistent across briefs.

Mode C, regeneration with operator guidance. The operator runs synthesis with a guidance argument: `traceleaf compose --focus "the Schneider partnership announcement"`. The synthesis layer generates a new brief weighted toward the operator's focus area. The previous brief is preserved (filenames are date-stamped, not overwritten).

### Artifacts produced or modified

- `briefs/*.md` (edited or regenerated)
- `framework/*.md` (edited if Mode B)

### Failure modes

- Prose edits lost on regeneration: the operator did not commit before regenerating. The operator can recover from git if they previously committed, otherwise the edits are gone.
- Framework edits break gates: if the operator edits a framework module in a way that violates the gate set (for instance, removes the prose-standards check), the next brief generation fails the gate. The system reports the failure with the rule ID and the file the operator changed.

### Exit criteria

The operator has the brief in the shape they want, or has decided the system needs further development before it produces what they want.

## Workflow 4: Source Set Update

### Trigger

The operator wants to add, remove, or modify a tracked competitor; or change source class enablement; or update an industry context.

### Steps

Step 1, the operator opens `traceleaf.md` (the operator configuration file).

Step 2, the operator edits the relevant section. Adding a competitor is appending a row. Removing a competitor is deleting a row. Disabling a source class is changing a flag.

Step 3, the operator saves the file.

Step 4, on the next collection or synthesis run, the system honors the new configuration.

### Artifacts modified

- `traceleaf.md`

### Failure modes

- Malformed edits: if the operator's edits break the configuration schema, the next command run reports the parsing failure with the line number and offers a fix.
- Removed competitor still in signal log: signals from a removed competitor remain in the log (no retroactive deletion). The brief synthesis layer ignores signals from competitors not in the current configuration.

### Exit criteria

The next brief reflects the updated configuration.

## Workflow 5: Error Recovery

### Trigger

A Traceleaf command has failed.

### Steps

Step 1, the operator reads the error message. Traceleaf error messages are designed to name the rule, the file, and the suggested action.

Step 2, the operator follows the suggested action. Common patterns:
- API key revoked or rate-limited: the operator updates the API key in `traceleaf.md` and retries.
- Network failure during collection: the operator retries the command. The collection command is idempotent against the operator's signal log.
- Gate failure on a brief: the operator inspects the failure list, decides whether to fix the underlying signal data, the framework module, or the brief itself, and retries.
- Citation resolution failure: the operator runs `traceleaf inspect <citation-id>` to see what the citation points to, identifies whether the source moved or the citation is malformed, and corrects.

Step 3, if the standard recovery path does not work, the operator consults the troubleshooting section of the documentation. If the documentation does not cover the failure, the operator opens a GitHub issue.

### Failure modes

- Recovery itself fails: the system has degraded enough that the operator cannot proceed. The operator's recourse is to restore the workspace from a previous git commit or to start over.

### Exit criteria

The operator is back to a working state.

## Cross-workflow patterns

Several patterns recur across workflows.

### Idempotency

Every state-modifying command is idempotent. Running collect twice does not duplicate signals. Running compose twice does not corrupt the brief; it produces a second brief with a different timestamp.

### Plain-text editability

Every artifact the operator might want to modify is a plain text file editable in a standard text editor. The operator does not need a special tool to manipulate any Traceleaf-generated artifact.

### Git-friendliness

Every workflow assumes the operator is committing their workspace to git. State files are designed to diff cleanly. The operator's history of briefs, signal logs, and configuration changes is the operator's audit trail.

### Failure surfacing

Failures are surfaced with named rule IDs, file paths, line numbers where applicable, and suggested actions. The system does not silently fail.

## Workflow elaboration in dependent docs

The Onboarding and First-Launch Experience document specifies the prompt sequence the operator experiences during First-Launch step 2 in detail. The v0.1 Scope and Acceptance Test document specifies the operational acceptance test for Workflow 1. The Architecture Overview specifies how each workflow's commands are decomposed into the underlying skills and modules. The Anchor Contract Specification specifies how citation resolution works during Workflow 5's inspect command.

## Working forward

These five workflows are the entire user-facing surface of Traceleaf v0.1. Anything that does not fit one of these workflows is either out of scope at v0.1 or is a feature whose addition would require a workflow change. New v0.2+ workflows are scoped in a separate document at the time v0.2 is committed.
