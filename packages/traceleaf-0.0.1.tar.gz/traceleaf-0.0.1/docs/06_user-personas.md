# User Personas and Audience Definition

## Conclusion

Traceleaf v0.1 designs primarily for the Discipline-Driven Analyst persona: a CI analyst at a small-to-medium organization who currently produces CI artifacts in word processors and spreadsheets, has technical comfort to clone a repo and run a CLI tool, and values output that survives adversarial review. Two secondary personas are in scope for forward-compatible design but not for v0.1 optimization: the Compliance-Constrained Analyst (regulated-industry CI work) and the Independent Analyst (solo CI consultant or freelancer). Three anti-personas are explicitly out of scope: the Sales-Enablement Buyer, the Executive Reader, and the Casual Researcher.

## Open questions and deferred items

- The persona descriptions are based on inferred profiles, not on validated user research. The post-launch signal phase tests these.
- The anti-personas are defined to prevent v0.1 from drifting toward features that serve the wrong audience. New v0.2+ personas can emerge based on signal.
- A formal validation plan is sketched here but executed post-launch.

## The primary persona: the Discipline-Driven Analyst

### Who they are

A working CI analyst at a small-to-medium organization. Possibly the only CI analyst in the company, possibly part of a team of two to five. Roles vary: dedicated CI analyst, product manager with CI as a side responsibility, strategic-finance analyst, market-intelligence specialist, or competitive-intelligence-as-side-of-desk for a chief-of-staff.

Title examples: Competitive Intelligence Analyst, Market Intelligence Manager, Senior Strategy Analyst, Director of Strategic Insights, Product Strategy Manager.

Organization examples: a 200-person SaaS company, a 1,000-person manufacturing firm, a mid-market financial services firm, a public-sector consultancy, a 50-person AI startup that takes its competitive landscape seriously.

### What they do

Produce competitive intelligence artifacts on a recurring cadence: weekly briefs, monthly digests, ad-hoc deep-dives in response to executive questions. Consume signals from a mix of sources: SEC filings, vendor press releases, trade media, analyst reports, conferences, customer conversations. Synthesize signals into briefs that go to executive readers, sales leadership, product strategy, or board members.

Spend significant time on the citation discipline of their own work because they have been burned by claims that did not survive scrutiny. Have a notebook, a spreadsheet, or a Notion page where they manually track sources for each claim in each brief.

### What pains them

- Existing CI tools (Klue, Crayon, Kompyte, Contify) are out of budget, have proprietary backends they distrust, or feel optimized for sales-team consumption rather than analytical rigor.
- Manual brief assembly takes hours per week. Citation discipline is the most time-consuming part.
- AI-assisted drafting (ChatGPT, Claude) speeds up prose but introduces fabrication risk. They cannot ship LLM-drafted output without manually verifying every citation.
- Output quality drifts brief-over-brief because the discipline is in their head, not in their tooling.
- Cross-brief consistency is operator-dependent. If they take a week off, the briefs that get produced in their absence look different.

### What they value

Output that survives adversarial review. Tooling they own and can audit. Citation discipline as a built-in property of the system, not as a discipline they have to maintain by force of will. Transparency in the synthesis layer (they want to know what the AI did and why). Operator-editability of every artifact. Open-source software when the use case fits.

### What they do not value

Polished UI that constrains their workflow. Sales-team integrations. Battlecard generation. Browser extensions. Mobile apps. Any feature that prioritizes the consumer of CI output over the producer.

### How they would use Traceleaf

Clone the repo to a personal-or-work machine. Run the setup flow, providing their company name, three to five competitors they actively track, their Anthropic API key, and their industry context. Run weekly source collection. Run brief synthesis. Read the brief, click two or three citations to verify, edit the prose where they disagree with the synthesis, commit the result to their workspace git repo.

Iterate over weeks: as they read briefs and find synthesis decisions they disagree with, they edit the framework modules to encode their preferences. Their Traceleaf instance becomes increasingly tuned to their analytical voice over time.

### How to reach this persona

GitHub through the open-source release. Hacker News through a thoughtful post about citation discipline in CI tooling. LinkedIn through CI-discipline groups and posts that lead with the audit-grade-output framing. Substack newsletters that cover CI craft (CI Insider and similar). Conference talks at SCIP (Strategic and Competitive Intelligence Professionals) if the project owner pursues that channel.

## The secondary persona: the Compliance-Constrained Analyst

### Who they are

A CI analyst at an organization with hard data-residency or compliance constraints. Defense contractors, financial services firms with regulatory reporting obligations, healthcare and pharma companies under HIPAA or equivalent, government-adjacent organizations, intelligence-community-adjacent firms.

Title examples: Senior Intelligence Analyst, Strategic Intelligence Lead, Competitive Threat Analyst, Regulatory Intelligence Specialist.

### What they do

Similar to the primary persona but with an additional constraint: their organization's procurement, IT, or compliance functions actively block SaaS CI tools because of data-residency requirements, FedRAMP gaps, or contractual restrictions on where competitive intelligence data can live. The analyst's daily reality is producing CI work in Word documents and SharePoint pages because the modern CI tools cannot pass procurement.

### What pains them

- All of the primary persona's pains, plus.
- They watch peers at non-regulated companies adopt Klue or Crayon and produce slicker output, while they remain on Word and SharePoint.
- Their organization has CI budget but cannot deploy it against existing vendors.
- Building anything in-house requires engineering resources they do not control.

### What they value

Operator-owned, deploy-on-your-own-infrastructure tooling. Open-source codebase that internal review can audit. No phone-home telemetry. No mandatory cloud dependency. Citation discipline that survives a regulator or an inspector general review.

### How Traceleaf serves them

Traceleaf v0.1 ships open-source with no telemetry and no required cloud dependency beyond the Anthropic API (which is the operator's account, not Traceleaf's). The compliance-constrained analyst can clone the repo, deploy it on internal infrastructure, point it at internal sources or approved external sources, and produce CI artifacts inside their compliance perimeter.

The barrier is procurement of the Anthropic API itself in some regulated contexts. Traceleaf's design accommodates operator-overridable model identifiers, so an analyst whose organization has approved a different model (Bedrock-hosted Claude, Azure OpenAI, on-prem Llama variant) can swap.

### Why they are secondary, not primary, at v0.1

Reaching this persona requires either inside-the-organization advocacy (an analyst championing Traceleaf adoption through internal procurement) or a top-down adoption from a CIO or chief security officer. Neither is reachable through GitHub-stargazer or Hacker News distribution. v0.1 cannot effectively market to this audience; it can only be available for the audience to discover.

The post-launch signal phase identifies whether any compliance-constrained analysts find Traceleaf and engage. If yes, the path forward includes more deliberate outreach. If no, this persona stays secondary.

## The tertiary persona: the Independent Analyst

### Who they are

A CI consultant, freelance analyst, or solo intelligence practitioner. Works for multiple clients on engagement-based billing. May be a former in-house analyst who went independent, or a domain specialist (industry analyst, niche-vertical consultant) who picks up CI work as part of broader engagements.

Title examples: Founder of a one-person CI consultancy, Independent Industry Analyst, CI Contractor, Strategic Intelligence Advisor.

### What they do

Produce CI artifacts under engagement, often white-labeled for the client or co-branded with the consultant's own name. Switch contexts frequently (different clients have different competitive sets, different industry vocabularies, different output expectations). Bill by the hour or by the deliverable.

### What pains them

- Per-engagement setup time is high. Each new client requires re-establishing the source set, the analytical framework, and the output template.
- They cannot adopt expensive SaaS tools because their per-client budget does not support enterprise pricing.
- Their output reputation depends on the rigor and audit-defensibility of their work; sloppy citations or made-up claims end the consulting relationship.
- They have to look more sophisticated than their solo-shop reality suggests, because they compete against larger consulting firms.

### What they value

Per-engagement isolation (they need separate workspaces for separate clients). Low marginal cost per engagement. Output that looks polished without expensive tooling. The ability to demonstrate methodology to clients, which means transparent, operator-editable systems.

### How Traceleaf serves them

Each client engagement becomes a separate Traceleaf workspace. The consultant clones a fresh workspace per client, runs the setup flow with the client's competitive set, produces engagement-specific briefs. Configuration travels with the workspace; no cross-client contamination.

### Why they are tertiary

The independent analyst is reachable but harder to find than the in-house analyst. Independent analysts tend to be self-promotional on LinkedIn and X but harder to organize as a single audience. A subset of them are reachable through SCIP and similar professional communities; another subset through "consultant Twitter" and substack newsletters.

v0.1 does not optimize for them. v0.2+ may add per-workspace features that benefit them specifically (workspace templating, client-isolated configuration, deliverable-shape customization).

## Anti-personas

Three audiences explicitly excluded from v0.1 design.

### Anti-persona 1: the Sales-Enablement Buyer

A sales operations manager, sales enablement leader, or revenue operations director who wants competitive battlecards their sales reps use during deal cycles. This is Klue's and Crayon's primary audience. They want polished, sales-rep-readable cards with named talking points, objection handlers, win-loss data integration, and CRM hooks.

Why excluded: Traceleaf produces analytical briefs, not battlecards. The Sales-Enablement Buyer's needs are fundamentally about deal velocity and rep enablement, not about citation rigor or audit defensibility. Trying to serve them at v0.1 would distort the product away from the differentiation thesis.

### Anti-persona 2: the Executive Reader

A C-level executive, board member, or senior strategic decision-maker who consumes CI briefs but does not produce them. They want short, scannable, conclusion-first artifacts that inform strategic decisions.

Why excluded: Traceleaf serves the producer, not the consumer. Executive readers read Traceleaf-generated briefs through the analyst persona's distribution. Optimizing the product for the executive reader's preferences (further compression, scannable formatting, executive-summary modes) would lose the analyst's discipline-in-the-tool benefit.

### Anti-persona 3: the Casual Researcher

A user who wants to do a one-off competitive lookup, not an ongoing CI practice. May be a startup founder doing market research, a job applicant researching a target company, a journalist preparing for an interview.

Why excluded: Traceleaf's setup flow plus first-collection plus first-synthesis is roughly an hour. The casual researcher's tolerance is closer to ten minutes. Trying to serve both audiences would compromise the depth Traceleaf needs for its core persona. The casual researcher is well-served by ChatGPT, Perplexity, and existing search tools.

## Validation plan

Persona validation runs post-v0.1 launch through three signal channels.

### Signal channel 1: GitHub issue and pull request traffic

Real users opening real issues against the open-source repository. Analyze who is opening issues, what they are trying to do, and what configuration they describe. The first 20 substantive issues from non-author users tell most of what needs to be known about which personas are showing up.

### Signal channel 2: direct outreach to known contacts

The project owner reaches out to three to five CI analysts in the personal network with a "I built this, would you take a look" message. Conversations tell whether the persona descriptions match real practitioners or whether they are wishful thinking.

### Signal channel 3: SCIP and similar community engagement

Posting to SCIP discussion forums, attending a SCIP-adjacent virtual meetup, or sharing the project at a CI-discipline community gathering. Reaction (or lack of it) tells whether the persona descriptions resonate with the community that actually does this work.

If all three signal channels return positive on the primary persona, v0.2 invests in serving them better. If signal returns weak across the board, the project re-evaluates whether to pursue commercial development or stay in portfolio-piece mode.

## Working forward

The next document, User Workflows and Journey Maps, describes how each persona moves through Traceleaf in concrete steps. The Onboarding and First-Launch Experience document specifies the prompt sequence that the primary persona experiences on first run. Both documents inherit the persona definitions from this document.
