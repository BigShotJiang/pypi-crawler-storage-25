# Schema and Data Model Definitions

## Conclusion

Traceleaf v0.1's data model is small: five canonical artifact types (operator configuration, signal log, framework module, brief, manifest) plus an ephemeral setup-progress file. Each artifact is markdown or JSON. Schemas are specified in this document with field-level definitions, allowed values, and constraints. The schemas are designed to be hand-readable, hand-editable, and forward-compatible. This document is the source of truth for the data shapes; implementation honors the contract described here.

## Open questions and deferred items

- The signal log schema is committed at v0.1 with eight fields. Future v0.2+ additions (transition tags, profile-enrichment flags) extend the schema; the additive-only commitment is stated here and held by the build.
- The framework module schema is described as "free-form markdown with optional frontmatter" rather than a strict schema because framework modules vary in shape (prose standards are prose; signal classification is rules; brief structure is templates). Each module's specific shape is documented in the module itself.
- The manifest schema is committed at v0.1 covering the four anchor types. v0.2+ anchor types extend the schema by adding type-specific blocks; the structural shape is preserved.

## Schema posture

Schemas honor the operator's eye. Every field has a name that describes what it holds. Every constraint is stated where the operator will encounter it. The operator should be able to read a workspace file and understand the schema from the file itself; this document is a reference, not the only place the schema lives.

Schemas are forward-compatible. New fields are optional. Changes to existing fields are minor versions or major versions per semantic versioning of the schema. Operators are not forced to migrate workspaces on every Traceleaf release.

Schemas favor markdown over JSON for any artifact the operator might want to edit. JSON is reserved for derived state (manifests) where structure matters more than readability.

## Artifact 1: operator configuration

### File path

`traceleaf.md` at the workspace root.

### Format

Markdown with structured sections. The document is human-readable as a config file.

### Schema

```markdown
# Traceleaf operator configuration

## Identity

- **Company or product:** [free text, optional]
- **Industry:** [free text, optional]

## Tracked competitors

- Schneider Electric
- Eaton
- ABB
- Vertiv
- Legrand

## Source enablement

- **SEC EDGAR:** enabled
- **Web sources:** enabled

## Web source patterns

- Schneider Electric: https://www.se.com/ww/en/about-us/newsroom/news/
- Eaton: https://www.eaton.com/us/en-us/company/news-insights.html
- ...

## Anthropic API

- **API key:** sk-ant-api03-...
- **Default model:** claude-sonnet-4-6

## Rate limits (advisory)

- **SEC EDGAR:** 10 requests per second
- **Web sources:** 1 request per second per host

## Schema version

- 1.0
```

### Field semantics

- **Identity / Company or product**: Free text. Optional. Used as analytical context in synthesis prompts.
- **Identity / Industry**: Free text. Optional. Used to filter web source content and shape brief framing.
- **Tracked competitors**: List of strings. Required. Each string is a tracked competitor name.
- **Source enablement**: Per-source-class on/off flags. Each source class is enabled or disabled.
- **Web source patterns**: Per-competitor URL patterns for web source collection. Operator-editable.
- **Anthropic API / API key**: String. Required for synthesis. Stored locally, never transmitted except to Anthropic.
- **Anthropic API / Default model**: String. Default model identifier the operator's account has access to. Operator-overridable.
- **Rate limits**: Operator hints. The system honors these.
- **Schema version**: String. Indicates which version of the schema this configuration adheres to. Used for forward-compatible parsing.

### Editability

The operator may edit any field at any time. The next command reads the updated values.

## Artifact 2: signal log

### File path

`signal_log.md` at the workspace root.

### Format

Markdown with a single table.

### Schema

```markdown
# Signal log

| signal_id | collected_at | competitor | source_class | source_id | url | title | excerpt |
|-----------|--------------|------------|--------------|-----------|-----|-------|---------|
| sig-2026-04-25-001 | 2026-04-25T09:14:22Z | Schneider Electric | edgar | 0001097864-25-001234 | https://www.sec.gov/... | Schneider 8-K filing | Schneider Electric announced... |
| sig-2026-04-25-002 | 2026-04-25T09:18:11Z | Eaton | web | eaton-newsroom-2026-04-24 | https://www.eaton.com/... | Eaton announces partnership | Eaton announced... |
```

### Field semantics

- **signal_id**: Unique identifier. Format: `sig-YYYY-MM-DD-NNN`.
- **collected_at**: ISO 8601 UTC timestamp of collection.
- **competitor**: Tracked competitor name. Must match a competitor in `traceleaf.md`. Signals from removed competitors remain in the log but are ignored by synthesis.
- **source_class**: Source class identifier. v0.1 values: `edgar`, `web`. v0.2+ may add `foreign-edgar`, `alphasense`, etc.
- **source_id**: Source-class-specific identifier. For `edgar`, the accession number. For `web`, a slug derived from the URL and date.
- **url**: Source URL. Reachable at the time of collection; may become unreachable later.
- **title**: One-line description of the signal.
- **excerpt**: Short content excerpt (up to ~500 characters) capturing the relevant content.

### Editability

The operator may edit signals, but edits are discouraged. The signal log is meant to be a faithful record of what was collected. Editing signals to change history or to retroactively delete content compromises the audit trail.

The operator may add manual entries by appending rows. Manual signals carry `source_class: manual` and an operator-provided `source_id` and `excerpt`.

### Constraints

- `signal_id` is unique across the log.
- `competitor` is one of the tracked competitors at collection time (or was at the time of collection; removed competitors remain in the log).
- `collected_at` is non-decreasing as the log grows (signals are appended in collection order).

## Artifact 3: framework module

### File path

`framework/<module-name>.md` in the workspace.

### Format

Markdown with optional YAML frontmatter.

### Schema

```markdown
---
module: prose-standards
version: 1.0
applies_to: brief-synthesis
---

# Prose standards

[free-form prose content...]
```

### Field semantics

- **module**: The module's canonical name. Must match the file name without extension.
- **version**: Schema version of this module. Allows forward-compatible parsing.
- **applies_to**: Where this module is consumed. Examples: `brief-synthesis`, `signal-classification`, `validation`.

### Editability

The operator may edit any framework module. Edits persist across Traceleaf updates (the update mechanism, when v0.2+ adds one, does not overwrite operator-modified files without consent).

### Constraints

Each shipped framework module documents its own constraints. The framework loader does not enforce a strict schema beyond presence of frontmatter.

## Artifact 4: brief

### File path

`briefs/YYYY-MM-DD_MODE.md` in the workspace, where MODE is `weekly` at v0.1.

### Format

Markdown with frontmatter.

### Schema

```markdown
---
brief_date: 2026-04-30
brief_mode: weekly
generated_at: 2026-04-30T15:23:11Z
generated_by: traceleaf-v0.1.0
manifest: manifest/2026-04-30_weekly.json
schema_version: 1.0
---

# Weekly brief — 2026-04-30

## BLUF

[100-word ceiling. The analytical conclusion of the week.]

## Top signals

[Ordered list of the most analytically significant signals from the past seven days, with anchors.]

## Analysis

[Prose analysis of patterns across signals, with anchors.]

## Citations

[List of citations referenced in the brief, organized by anchor type.]
```

### Field semantics

- **brief_date**: The date the brief covers. Typically the date of generation; may be operator-overridden.
- **brief_mode**: The brief's mode. v0.1: `weekly`.
- **generated_at**: ISO 8601 UTC timestamp of generation.
- **generated_by**: The Traceleaf version that produced the brief.
- **manifest**: Relative path to the citation manifest.
- **schema_version**: Brief schema version.

### Editability

The operator may edit any prose in the brief. The frontmatter should not be edited; it is treated as system-generated metadata.

If the operator regenerates a brief for the same date, the system writes a new file with a numeric suffix (`2026-04-30_weekly_v2.md`) rather than overwriting. Operators committing to git get diffable history of the brief evolution.

### Constraints

- Every analytical claim in the prose is followed by an anchor (enforced by Validate Rule A.1).
- The brief structure honors the brief structure framework module.
- Banned vocabulary is absent (enforced by Validate, prose standards rule).

## Artifact 5: manifest

### File path

`manifest/YYYY-MM-DD_MODE.json` in the workspace.

### Format

JSON.

### Schema

```json
{
  "brief_file": "briefs/2026-04-30_weekly.md",
  "brief_date": "2026-04-30",
  "brief_mode": "weekly",
  "generated_at": "2026-04-30T15:23:11Z",
  "schema_version": "1.0",
  "anchors": {
    "<anchor-id>": {
      "type": "<one of: signal | prior-brief | source-document | synthesis>",
      "summary": "One-line description of the source.",
      "<type-specific fields>": "..."
    }
  }
}
```

Type-specific fields:

For `signal`:
```json
{
  "type": "signal",
  "source_file": "signal_log.md",
  "source_locator": "row-id:1042",
  "summary": "..."
}
```

For `prior-brief`:
```json
{
  "type": "prior-brief",
  "source_file": "briefs/2026-04-23_weekly.md",
  "source_locator": "## Top signals",
  "summary": "..."
}
```

For `source-document`:
```json
{
  "type": "source-document",
  "url": "https://...",
  "content_hash": "sha256:abc123...",
  "retrieved_at": "2026-04-25T09:14:22Z",
  "summary": "..."
}
```

For `synthesis`:
```json
{
  "type": "synthesis",
  "aggregation_of": ["sig-...", "sig-..."],
  "summary": "..."
}
```

### Editability

Manifests should not be edited by the operator. They are derived state; the brief is the canonical artifact, and the manifest is regeneratable from the brief plus the workspace state at generation time.

### Constraints

- Every anchor in the manifest is referenced in the brief.
- Every anchor in the brief appears in the manifest.
- Each anchor's `type` is one of the four committed types.
- Type-specific fields conform to the per-type schema.

## Artifact 6: setup progress (ephemeral)

### File path

`.traceleaf/setup_in_progress.json` in the workspace.

### Format

JSON.

### Schema

```json
{
  "started_at": "2026-04-30T14:30:11Z",
  "answers": {
    "company_or_product": "...",
    "competitors": ["...", "..."],
    "industry": "...",
    "api_key": "sk-ant-api03-..."
  },
  "next_prompt": "confirmation"
}
```

### Field semantics

Used by the Setup skill to resume an interrupted setup. Deleted by Setup on successful completion. Operators may delete it manually to start over.

## Schema versioning

Each artifact carries a `schema_version` field where applicable. Versioning policy:

- **Patch increments** (1.0 → 1.0.1): bug fixes that do not change the schema. Operators do not need to migrate.
- **Minor increments** (1.0 → 1.1): additive changes (new optional fields). Existing artifacts remain valid.
- **Major increments** (1.0 → 2.0): breaking changes. v0.1 commits to no major schema increments before v0.2.

The `schema_version` field allows forward-compatible parsing. A future Traceleaf version reading a workspace at an older schema version can either operate on the older schema or migrate; the choice is made at build time and not committed at v0.1.

## Schema evolution and v0.2+ additions

When v0.2+ adds new artifact types or fields, the additions extend the v0.1 schemas without breaking them.

Likely v0.2+ additions:

- New signal log fields: `transition_tag` (for technology-transition tracking), `compound_id` (for compound-signal grouping).
- New brief modes: `monthly`, `quarterly`, `flash`. Each mode has its own brief structure framework module but shares the brief artifact schema.
- New manifest anchor types: `transition-tracker-observation`, `profile-fact`, `threat-matrix-dimension`, `regulatory-filing-section`. Each adds type-specific fields to the manifest schema.
- New artifact types: `profiles/<competitor>.md` (operator-curated competitor profiles), `state/threat_matrix.md` (standing threat assessment).

The v0.1 schemas are committed not to change in breaking ways. v0.2+ additions are additive.

## Cross-artifact relationships

The artifacts have a defined dependency graph.

- `traceleaf.md` is read by every skill.
- `framework/*` is read by Compose and Validate.
- `signal_log.md` is written by Collect, read by Compose.
- `briefs/*.md` is written by Compose, read by Validate, modified by the operator.
- `manifest/*.json` is written by Compose, read by Validate (especially the inspect command).

The graph is acyclic. No artifact depends on an artifact that depends on it.

## Working forward

The Functional Decomposition doc names the scripts that read and write each artifact. The Anchor Contract Specification specifies the manifest in operational detail. The v0.1 Scope and Acceptance Test doc includes schema-correctness as part of the launch acceptance criteria.
