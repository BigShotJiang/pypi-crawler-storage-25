# Requirements

## Conclusion

Traceleaf v0.1 requirements are organized into four categories: functional (what the system does), non-functional (how the system behaves), constraints (what the system cannot do), and out-of-scope (what is explicitly deferred). The functional surface is deliberately small; the constraints and non-functional commitments are deliberately strict. This document is the contract that the v0.1 build holds itself accountable to.

## Open questions and deferred items

- Specific numerical thresholds for non-functional requirements (latency p95, cost per brief in dollars) are sketched here but finalized in the v0.1 Scope and Acceptance Test doc.
- The constraint set is largely inherited from the prior project's Learnings Catalog. Whether any constraint should be modified for Traceleaf is finalized here.
- Out-of-scope items are listed exhaustively to prevent scope creep during the build. New requirements added during build must be explicitly amended here.

## Functional requirements (FR)

What Traceleaf v0.1 does, organized by user-visible capability.

**FR1 — First-launch setup.** Traceleaf provides an interactive setup flow that prompts the user for company name, three to five tracked competitors, optional industry context, and Anthropic API key. The flow generates the operator's seed files from these inputs and validates that the API key is functional before completing.

**FR2 — Source collection.** Traceleaf collects competitive signals from at least two source classes at v0.1: SEC EDGAR for tracked competitors that file with the SEC, and simple web sources via HTTP for tracked competitors' public web presence (newsroom, blog, or homepage). Signals are written to a markdown signal log in the operator's workspace.

**FR3 — Brief synthesis.** Traceleaf produces a weekly brief from the collected signal log. The brief leads with an analytical conclusion, supports with cited signals, and closes with a list of resolvable citations. The brief is written to a markdown file in the operator's workspace.

**FR4 — Anchor citation.** Every analytical claim in a generated brief carries a typed citation that resolves to a source. Citations are validatable: a separate validation command can verify that every citation in a brief resolves to a reachable source.

**FR5 — Gate validation.** Traceleaf provides a validation command that runs a small set of quality gates against a generated brief. Gates check for citation presence, citation resolution, prose-standards adherence, and structural validity. Gate failures are reported with named rule IDs.

**FR6 — Anchor inspection.** Traceleaf provides an inspection command that takes a citation reference from a brief and returns the source content the citation points to.

**FR7 — Operator configuration.** Traceleaf reads operator configuration from a single markdown file in the workspace. The operator can hand-edit this file at any time. Configuration includes tracked competitors, source class enablement, model identifier override, and per-source rate-limiting hints.

**FR8 — Workspace state.** All canonical state for a Traceleaf operator (configuration, signal logs, briefs, gate verdicts, anchor index) lives in a single workspace directory. The directory is operator-controllable; Traceleaf does not write outside it.

## Non-functional requirements (NFR)

How Traceleaf v0.1 behaves, beyond what it does.

### Performance

**NFR-P1 — First-brief end-to-end time.** A user with a clean clone, valid API key, and three to five tracked competitors completes the path from `git clone` to reading their first brief in under sixty minutes for at least 80 percent of test runs. The 60-minute promise from the North Star doc.

**NFR-P2 — Brief synthesis time.** Once signals are collected, brief synthesis completes in under five minutes for typical input sizes (50 to 200 collected signals). Longer synthesis times are acceptable but the user must see progress indication.

**NFR-P3 — Source collection rate limits.** Source collection respects rate limits of external APIs. SEC EDGAR is capped at 10 requests per second per the SEC's published policy. Web sources are capped at 1 request per second per host with a polite user-agent header.

### Cost

**NFR-C1 — Per-brief inference cost.** A typical weekly brief consumes under $0.50 in Claude inference cost at v0.1 model defaults (Claude Sonnet). Operators using more expensive models accept proportionally higher costs.

**NFR-C2 — Operator-funded model access.** Traceleaf does not subsidize, intermediate, or charge for Anthropic API access. The operator brings their own API key. Traceleaf consumes tokens against the operator's account.

### Reliability

**NFR-R1 — Idempotent collection.** Re-running source collection on the same operator workspace does not duplicate signals. The system uses content-hashing or similar deduplication to ensure idempotency.

**NFR-R2 — Restartable synthesis.** If brief synthesis fails partway through, the user can retry without losing prior work. Partial outputs are preserved or cleanly removed; intermediate state is identifiable.

**NFR-R3 — Graceful degradation under partial source failure.** If one source class fails (SEC EDGAR returns errors, a web source is unreachable), the system continues with available sources and notes the missing source in the brief output.

### Audit

**NFR-A1 — Citation resolution at brief read time.** Every citation in a brief generated at time T resolves to its source at time T+24 hours, modulo external source unavailability beyond Traceleaf's control. The operator can verify this with the validation command.

**NFR-A2 — Source-of-truth in markdown.** Every artifact a Traceleaf operator might want to inspect, edit, or version-control is stored as plain markdown or plain JSON. Binary formats are forbidden for canonical state. Derived caches (embeddings, indexes) are regeneratable from markdown source.

**NFR-A3 — Run reproducibility.** Two invocations of Traceleaf against the same input data produce equivalent output, modulo Claude's stochastic generation. Where outputs differ run-to-run, the differences are localized to prose phrasing, not to citation correctness or claim structure.

### Accessibility and operator-editability

**NFR-AE1 — Plain-text editability.** Every state file in the operator workspace is editable with a standard text editor without breaking system invariants, provided the operator preserves required schema fields.

**NFR-AE2 — Cross-platform support.** Traceleaf runs on macOS, Linux, and Windows. Operating-system-specific paths or commands are abstracted; the documented quick-start works on all three.

**NFR-AE3 — Documentation completeness.** Every operator-facing command is documented with input format, output format, exit codes, and at least one worked example.

## Constraints

What Traceleaf v0.1 cannot do. Inherited from the Learnings Catalog with v0.1-specific modifications.

### C1 — Auditability constraint

Every analytical claim in operator-facing output must carry a typed citation that resolves to a source. This is the Differentiation Thesis incarnated as a constraint. The constraint is enforced by the gate validation layer, not by hope.

### C2 — Git-friendliness constraint

Canonical state is markdown source-of-truth on a git substrate. Operators commit their workspace state to git for versioning. Traceleaf does not require a database or a non-git versioning system.

### C3 — Operator-editability constraint

Every artifact the operator might want to modify is hand-editable in plain text. Traceleaf does not enforce any schema or invariant that requires a custom editor.

### C4 — Sentinel-tracking constraint

Every external dependency that could silently shift (API contracts, model identifiers, third-party Python packages) is sentinel-tracked. The repository ships a sentinel manifest that lists exact versions, model IDs, and API contract assumptions. Drift detection is automated.

### C5 — Typed-anchor constraint

Citations follow the typed-anchor contract specified in the Anchor Contract Specification doc. Untyped citations are forbidden in operator-facing output.

### C6 — Cost-per-run sensitivity constraint

Traceleaf v0.1 design choices that materially increase per-brief cost above the NFR-C1 budget require explicit justification and a documented sunset trigger.

### C7 — Standard library preference

Python dependencies beyond the standard library require explicit dependency budget entries. v0.1 ships with the smallest viable dependency set: Anthropic SDK plus a small number of additional packages enumerated in the Architecture Overview.

### C8 — No outbound telemetry

Traceleaf does not send telemetry to any service the project owner controls. Operator data, configuration, and usage patterns stay on the operator's machine. Integrations with external services (Anthropic, SEC EDGAR, web sources) send only the data necessary to fulfill the operator's request.

## Out-of-scope at v0.1

Items deliberately deferred. Each is a candidate for v0.2+ if user signal warrants. Some are deferred indefinitely based on the Differentiation Thesis.

### Modes deferred

All analytical modes other than weekly brief: monthly digest, quarterly assessment, KIQ response, financial signal brief, strategic comparison, filing alert, inference refresh, service-category benchmark.

### Sources deferred

All sources other than SEC EDGAR and simple web scrape: foreign-filer native APIs (Open DART, Taiwan MOPS, ESEF), AlphaSense Ingestion API, Bloomberg, Factiva, Reuters, paid trade media APIs, Crawl4AI integration, Firecrawl integration.

### Distribution surfaces deferred

All distribution surfaces other than markdown file: DOCX rendering, PDF rendering, HTML rendering, email push (Microsoft Graph, Postmark, SendGrid, AWS SES), Slack push (Block Kit, Slackbot), Microsoft Teams push (Adaptive Cards, Workflows), SharePoint, Notion, Confluence, RSS, Atom, voice or audio rendering.

### State infrastructure deferred

Snowflake projections, BigQuery projections, Databricks projections, Postgres backend, Dolt-based versioning, sqlite-vec dense retrieval, FTS5 indexing, hosted observability (Cortex AI Observability, LangSmith, Arize, Patronus, Galileo, Braintrust).

### Synthesis enhancements deferred

Multi-agent orchestration, contextual retrieval (Anthropic cookbook pattern), GraphRAG, ColPali multimodal retrieval, agentic retrieval, reasoning-model utilization beyond the default model, prompt caching beyond what Anthropic does automatically, structured output for any mode beyond v0.1.

### Gate enhancements deferred

The full prior project gate registry beyond the v0.1 starter pack. Specifically: TOS-compliance gates, rate-limit-compliance gates, calibration-coverage-drift gates, classifier-version regression tests, schema-version-compatibility gates, anchor-resolution-rate gates beyond basic resolution checking, reranker-candidate-cap gates, classifier-version-filter compatibility checks.

### MCP integrations deferred

Klue MCP server consumption, Crayon MCP server consumption, AlphaSense MCP exploration, Microsoft Copilot Studio integration, Anthropic Files API distribution-as-conversation, Slack MCP server, Slackbot Agentforce 360 integration.

### Operator-experience features deferred

Hosted onboarding (Traceleaf cloud), GUI configuration, browser extension, IDE extension beyond Claude Code, mobile app, real-time collaboration, multi-operator workspaces, role-based access control, audit log dashboards.

### Commercial features deferred

Hosted version of Traceleaf, paid tier, support contracts, training services, custom integration services, partner marketplace, SOC2 attestation, HIPAA compliance, FedRAMP authorization.

## Future requirements

Placeholder section. v0.2+ requirements are not specified here. They are derived from post-v0.1 user signal and revisited in a separate scoping document at the time v0.2 is committed.

## Working forward

The next document in the Tier 1 sequence is User Personas and Audience Definition, which describes who the operators are. That doc plus this one together drive the User Workflows and Journey Maps doc. The constraints listed here flow into the Architecture Overview, the Anchor Contract Specification, and the v0.1 Scope and Acceptance Test as enforcement criteria.
