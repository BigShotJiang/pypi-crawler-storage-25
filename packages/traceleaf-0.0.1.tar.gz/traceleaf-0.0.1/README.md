# traceleaf
Traceleaf is an open-source competitive intelligence tool that turns Markdown briefs into audit-grade products by enforcing claim-to-source citations, file-first provenance, and operator-owned workflows.
