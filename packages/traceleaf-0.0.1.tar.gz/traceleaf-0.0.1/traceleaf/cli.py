"""Traceleaf command-line interface."""

from __future__ import annotations

import argparse

from traceleaf import __version__


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="traceleaf",
        description=(
            "Traceleaf turns Markdown briefs into audit-grade products. "
            "This is a v0.0.1 placeholder release; subcommands "
            "(setup, collect, compose, validate) land in v0.1."
        ),
    )
    parser.add_argument(
        "--version",
        action="version",
        version=f"traceleaf {__version__}",
    )
    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    parser.parse_args(argv)
    parser.print_help()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
