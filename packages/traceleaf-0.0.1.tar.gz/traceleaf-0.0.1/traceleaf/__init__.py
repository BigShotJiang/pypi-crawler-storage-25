"""Traceleaf: competitive intelligence tool for audit-grade Markdown briefs."""

__version__ = "0.0.1"
