from __future__ import annotations

from typing import Any, Literal

from ..http import HttpClient
from ..types import (
    CreateNumberInput,
    CreateNumberResult,
    NumberConnectResult,
    NumberStatusResult,
    NumberUpgradeToDualResult,
    WhatsAppNumberListItem,
)


class NumbersResource:
    def __init__(self, http: HttpClient):
        self._http = http

    def list(self) -> list[WhatsAppNumberListItem]:
        """List all WhatsApp numbers for the tenant (same scope as dashboard Numbers)."""
        return self._http.request_json(method="GET", path="/v1/numbers")

    def create(self, input: CreateNumberInput) -> CreateNumberResult:
        body: dict[str, Any] = {
            "name": input["name"],
            "number": input["number"],
        }
        if "linkToApiKey" in input:
            body["linkToApiKey"] = input["linkToApiKey"]
        if "linkMode" in input:
            body["linkMode"] = input["linkMode"]
        return self._http.request_json(method="POST", path="/v1/numbers", body=body)

    def connect(
        self,
        id: str,
        link: Literal["primary", "secondary"] | None = None,
    ) -> NumberConnectResult:
        """Generate a new QR / pairing code for the number.

        Args:
            id:   Number ID.
            link: "primary" (default) or "secondary" (Dual Link only).
        """
        qs = f"?link={link}" if link and link != "primary" else ""
        return self._http.request_json(
            method="GET",
            path=f"/v1/numbers/{id}/connect{qs}",
        )

    def get_status(
        self,
        id: str,
        link: Literal["primary", "secondary"] | None = None,
    ) -> NumberStatusResult:
        """Fetch the current connection state of the number.

        Args:
            id:   Number ID.
            link: "primary" (default) or "secondary" (Dual Link only).
        """
        qs = f"?link={link}" if link and link != "primary" else ""
        return self._http.request_json(
            method="GET",
            path=f"/v1/numbers/{id}/status{qs}",
        )

    def upgrade_to_dual(self, id: str) -> NumberUpgradeToDualResult:
        """Upgrade a SINGLE-link number to Dual Link.

        Only available when EVOLUTION_GO_ENABLED on the server.
        Returns the QR / pairing code for the secondary connection.
        """
        return self._http.request_json(
            method="POST",
            path=f"/v1/numbers/{id}/upgrade-to-dual",
        )
