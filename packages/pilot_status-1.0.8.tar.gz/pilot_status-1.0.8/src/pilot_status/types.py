from __future__ import annotations

from typing import Literal, TypedDict

from typing_extensions import NotRequired

Environment = Literal["TEST", "LIVE"]

MessageStatus = Literal["QUEUED", "SENT", "DELIVERED", "FAILED", "READ", "CANCELED"]


class SendMessageInput(TypedDict, total=False):
    templateId: str
    destinationNumber: str
    groupId: str
    variables: dict[str, str]
    labels: list[str]
    deliverAt: str
    deliverUntil: str


class SendMessageAccepted(TypedDict):
    id: str
    correlationId: str
    status: MessageStatus
    createdAt: str
    origin: str


class MessageDetails(TypedDict):
    id: str
    status: MessageStatus
    correlationId: str
    destinationNumber: str
    template: str
    createdAt: str
    sentAt: str | None
    deliveredAt: str | None
    readAt: str | None
    errorMessage: str | None


class DashboardDailyMessages(TypedDict):
    date: str
    count: int


class DashboardStatusDistribution(TypedDict):
    queued: int
    sent: int
    delivered: int
    failed: int
    read: int


class DashboardStats(TypedDict):
    totalSent: int
    totalFailed: int
    sentPercentChange: float
    failedPercentChange: float
    failureRate: float
    dailyMessages: list[DashboardDailyMessages]
    statusDistribution: DashboardStatusDistribution


OptInCheckReason = Literal[
    "OPTIN_DISABLED",
    "NON_DEFAULT_INSTANCE",
    "NOT_LIVE",
    "MISSING_PROJECT",
    "INVALID_PHONE",
    "NO_OPTIN",
]


class OptInCheckResult(TypedDict):
    authorized: bool
    required: bool
    enabled: bool
    reason: OptInCheckReason | None
    firstOptInAt: str | None
    lastSeenAt: str | None


class Project(TypedDict):
    id: str
    name: str
    slug: str
    description: str
    productionApproved: bool
    createdAt: str


class CreateProjectInput(TypedDict, total=False):
    name: str
    description: str


class ApiKeyCreateInput(TypedDict, total=False):
    name: str
    webhookId: str | None
    whatsappInstanceId: str | None
    retentionDays: int


class ApiKeyCreated(TypedDict):
    id: str
    name: str
    environment: Environment
    key: str
    keyPrefix: str
    createdAt: str
    webhookId: str | None
    whatsappInstanceId: str | None
    retentionDays: int


class ApiKeyLinkedWebhook(TypedDict):
    id: str
    name: str
    url: str


class ApiKeyLinkedWhatsAppInstance(TypedDict):
    id: str
    instanceName: str
    displayName: str
    number: str
    state: str


class ApiKeyListItem(TypedDict):
    id: str
    name: str
    keyPrefix: str
    environment: Environment
    lastUsedAt: str | None
    createdAt: str
    webhookId: str | None
    projectId: str | None
    webhook: ApiKeyLinkedWebhook | None
    whatsappInstanceId: str | None
    whatsappInstance: ApiKeyLinkedWhatsAppInstance | None
    retentionDays: int


class InstanceLinkInfo(TypedDict, total=False):
    state: str
    connectedAt: str | None


class NumberLinkBundle(TypedDict):
    qrcodeBase64: str | None
    pairingCode: str | None


class NumberListItemApiKeyRef(TypedDict):
    """API key refs on GET /v1/numbers items (no raw secret, no key id)."""

    name: str
    keyPrefix: str
    keyLast4: str | None
    environment: str


class WhatsAppNumberListItem(TypedDict):
    """One row from GET /v1/numbers (tenant list; no upstream tokens)."""

    id: str
    instanceName: str
    number: str
    createdAt: str
    updatedAt: str
    name: str
    apiKeys: list[NumberListItemApiKeyRef]
    linkMode: Literal["DUAL", "SINGLE"]
    primaryLink: InstanceLinkInfo
    secondaryLink: InstanceLinkInfo | None
    isFullyConnected: bool
    lastValidatedAt: NotRequired[str]


class WhatsAppNumberInstance(TypedDict, total=False):
    id: str
    tenantId: str
    instanceName: str
    number: str
    displayName: str
    state: str
    integration: str
    createdAt: str
    updatedAt: str
    name: str
    status: str
    quality: Literal["GOOD", "UNKNOWN"]
    # Dual Link fields (optional; present when EVOLUTION_GO_ENABLED on the server)
    linkMode: Literal["DUAL", "SINGLE"]
    primaryLink: InstanceLinkInfo
    secondaryLink: InstanceLinkInfo | None
    isFullyConnected: bool


class CreateNumberInput(TypedDict, total=False):
    name: str
    number: str
    linkToApiKey: bool
    # Request Dual Link. Only effective when EVOLUTION_GO_ENABLED on the server.
    linkMode: Literal["DUAL", "SINGLE"]


class CreateNumberResult(TypedDict, total=False):
    instance: WhatsAppNumberInstance
    # Legacy fields — backward compat; same value as primaryLink
    qrcodeBase64: str | None
    pairingCode: str | None
    linkedApiKeyId: str | None
    # Neutral Dual Link fields
    primaryLink: NumberLinkBundle
    secondaryLink: NumberLinkBundle | None


class NumberConnectResult(TypedDict):
    qrcodeBase64: str | None
    pairingCode: str | None


class NumberStatusResult(TypedDict):
    id: str
    state: str


class NumberUpgradeToDualResult(TypedDict):
    secondaryLink: NumberLinkBundle
