# Standards Compliance — `mgf-common`

> **Status:** v1.1 — Last audited 2026-04-28 against
> [`docs/standards/`](standards/) v2.1 (SP-01..06 added).
> Prior audit: v1.0, 2026-04-26 against v2.0.
> **Posture:** L2 (Tier C observability native; security pins in CI;
> public-API contract pinned).
> **Audit cadence:** every release + ad-hoc when a standard bumps a
> MUST.

This is the rolling compliance document for `mgf-common` itself.
The pattern is documented in
[`docs/standards/COMMON_COMPONENTS.md`](standards/COMMON_COMPONENTS.md)
§"Maintaining compliance over time" (the cornerstone rhythm). It
has four parts: the current-state table, open gaps, closed gaps
history, observations.

---

## 1. Compliance table — current state

Every MUST in [`docs/standards/`](standards/) (109 rules across
eight topic docs as of v2.1 — was 103 across seven topic docs at
v2.0; SP-01..06 added in SCOPE.md). One row per rule, with status,
evidence, and pinning test where applicable.

### Status legend

- ✅ **Compliant** — rule is followed and (where mechanical) pinned.
- 🟠 **Partial** — followed but not pinned, OR pinned but with
  documented limitations.
- ❌ **Open gap** — known violation; see §2 for tracker entry.
- ➖ **N/A** — rule does not apply (e.g., GUI rules in a non-GUI
  package).

### DESIGN_PRINCIPLES (DP-01..13)

| ID | Status | Evidence |
|---|---|---|
| DP-01 layering | ✅ | `.importlinter` `mgf-common-is-a-leaf` contract; `lint-imports` in CI |
| DP-02 provider ABC | ➖ | `mgf.common` has no third-party I/O dependency directly |
| DP-03 frozen domain types | ➖ | `mgf.common` does not export domain types (consumers do) |
| DP-04 typed signatures | ✅ | `mypy --strict` on `src/` in CI; 18 source files clean |
| DP-05 test mirror + no real I/O | ✅ | `tests/unit/` mirrors `src/mgf/common/` 1:1; suite has no network/SDK deps |
| DP-06 first-class concerns | ✅ | every PR description addresses correctness / reliability / security / performance per `CONTRIBUTING.md` |
| DP-07 docstrings on public names | ✅ | every public function in `__all__` carries a docstring |
| DP-08 replaceability | ✅ | observability sinks are pluggable (formatter / handler / Redactor injection); see `setup_logging` signature |
| DP-09 explicit cancellation | ➖ | `mgf.common` has no long-running synchronous ops yet (lift candidate, see `COMMON.md` §12) |
| DP-10 no silent fallback | ✅ | `setup_otel` logs at WARNING when SDK is unavailable; `setup_logging` honours the auto-format heuristic explicitly |
| DP-11 async task ownership | ➖ | `mgf.common` has no async code today; rule applies to consumers |
| DP-12 UTC time | ✅ | `crash_reporter._build_report` uses `datetime.now(UTC)`; ruff `DTZ` rules in `pyproject.toml::[tool.ruff.lint]` |
| DP-13 resource release | ✅ | every `open` / `urlopen` in `src/` is inside `with`; ruff `SIM115` enforces |

### ERROR_HANDLING (EH-01..13)

| ID | Status | Evidence |
|---|---|---|
| EH-01 typed hierarchy | ✅ | `mgf.common.exceptions.AppError` + 7 categories + 7 generic concretes |
| EH-02 translation seams | ➖ | no third-party SDKs in `mgf.common` to translate (consumers translate at their boundaries) |
| EH-03 `from e` chain | ➖ | same — no boundaries here that re-raise |
| EH-04 top-level handlers | ✅ | `install_excepthook` + `install_threading_excepthook` shipped; tested in `tests/unit/observability/test_excepthooks.py` |
| EH-05 unhandled → crash report | ✅ | hooks chain to `report_now`; never-raises invariant pinned |
| EH-06 GUI worker catches all | ➖ | no GUI in `mgf.common` (lift candidate per `COMMON.md` §12.2) |
| EH-07 no bare `except Exception:` | ✅ | every broad catch in `src/` carries `# noqa: BLE001` with a docstring rationale |
| EH-08 machine-readable fields | ✅ | `SchemaValidationError.errors`, `CommandError.argv/.returncode/.stderr`, `ResourceNotFoundError.name`, etc. |
| EH-09 actionable hints | 🟠 | concrete classes carry sensible defaults; project doesn't yet pin hint substrings (deferred until first user-facing CLI exists) |
| EH-10 best-effort observers | ➖ | `mgf.common` has no observer loops yet |
| EH-11 retry + jitter | ➖ | `mgf.common` does not ship a retry helper yet (planned per `COMMON.md` §12 `retry/backoff` lift) |
| EH-12 idempotency | ➖ | no multi-attempt operations in `mgf.common` itself |
| EH-13 circuit breaker | ➖ | same — applies to consumers and to the future retry/backoff lift |

### LOGGING (LG-01..14)

| ID | Status | Evidence |
|---|---|---|
| LG-01 `logging.getLogger(__name__)` | ✅ | every `src/` module that logs uses `__name__` |
| LG-02 single setup point | ✅ | `setup_logging` is the single entry point; idempotent via `force=True` |
| LG-03 trace-id in records | ✅ | `JsonFormatter._add_otel_context` reads the active span; LG-03 covered by the smoke pattern in `examples/04_observability/03_advanced.py` |
| LG-04 redaction by default | ✅ | `Redactor.default()` covers the well-known key set; pinned by `tests/unit/observability/test_redaction_property.py` |
| LG-05 `LOG.exception` for errors | ✅ | grep `LOG.error(f"...{e}")` returns nothing in `src/` |
| LG-06 rotating file by default | ✅ | `setup_logging` adds `RotatingFileHandler` always; opt-in OTLP/syslog/HTTP via env vars |
| LG-07 GUI log-viewer | ➖ | no GUI in `mgf.common` |
| LG-08 lazy %-formatting | ✅ | grep `LOG\.(info|warning|error|exception|debug)\(f"` returns nothing in `src/` |
| LG-09 `extra={...}` for fields | ✅ | examples + AS-IS in `mgf.common.observability` |
| LG-10 headless services | ➖ | no headless service in `mgf.common` |
| LG-11 operation start/end | ➖ | `mgf.common` has no use cases that span an operation; consumers use this |
| LG-12 ≤100 µs per record | ✅ | `tests/unit/test_logging_perf.py` pins the rotating-file path |
| LG-13 volume control | 🟠 | rate-limit / sample / dedup filters described in §17; not shipped as helpers yet (consumers compose stdlib `logging.Filter` per the doc) |
| LG-14 contextvars correlation | 🟠 | template described in §18; not shipped as a helper module yet (consumers wire their own `register()`) |

### CONFIGURATION (CF-01..12)

| ID | Status | Evidence |
|---|---|---|
| CF-01 single typed object | ✅ | `BaseAppSettings` is the one object; `make_settings_config` enforces the pattern |
| CF-02 layered precedence | ✅ | inherited from `pydantic-settings`; documented in `_settings.py` docstring |
| CF-03 schema versioning | ✅ | `BaseAppSettings.CURRENT_VERSION` + `_check_version` validator |
| CF-04 atomic + 0o600 | ✅ | `_write_yaml_atomic` + `crash_reporter._write_local` both follow the pattern |
| CF-05 secrets → vault | ➖ | vault not in `mgf.common` itself (lift candidate); rule applies to consumers |
| CF-06 unknown-key reject | ✅ | `make_settings_config` baseline includes `extra="forbid"` |
| CF-07 sub-config files | ➖ | no satellite-file readers in `mgf.common` |
| CF-08 single load + injection | ✅ | `load_settings` is the canonical loader; module-global singletons forbidden by review |
| CF-09 `--config` flag default | ➖ | `mgf.common` has no CLI; consumers wire the flag |
| CF-10 tests construct explicit | ✅ | tests use `Settings(...)` overrides; `_settings.py` docstring pins this |
| CF-11 alias renames | ➖ | no field renames yet in `mgf.common` 0.1.0 lifecycle |
| CF-12 discriminated unions | ➖ | not used in `mgf.common`'s own settings (consumers use it for backend variants) |

### SECURITY (SC-01..18)

| ID | Status | Evidence |
|---|---|---|
| SC-01 secrets in vault | ➖ | `mgf.common` doesn't ship a vault yet; rule applies to consumers |
| SC-02 argv-only subprocess | ✅ | `mgf.common` makes no subprocess calls; ruff `S602` would flag any future `shell=True` |
| SC-03 `safe_load` only | ✅ | grep `yaml\.load(` (without `safe_`) returns nothing in `src/` |
| SC-04 atomic + 0o600 | ✅ | same as CF-04 |
| SC-05 vetted crypto | ✅ | `mgf.common` uses no crypto primitives directly; transitive deps (`sentry-sdk`, `opentelemetry`) use vetted libs |
| SC-06 TLS verify | ✅ | grep `verify=False` returns nothing |
| SC-07 timeouts everywhere | ✅ | `_ship_http` uses `timeout=5`; only network call in `mgf.common` |
| SC-08 input validation at boundary | ✅ | every public function validates inputs via type annotations + pydantic |
| SC-09 redaction before sinks | ✅ | every formatter holds a `Redactor`; `JsonFormatter.format` calls `redact` before serialise |
| SC-10 lockfile + scan in CI | ✅ | `uv.lock` committed; `pip-audit --strict` step in `.woodpecker.yml` |
| SC-11 traceback scrubbing | 🟠 | the redactor handles `extra={...}` payload in records; the crash reporter passes the report through redaction; gap: explicit scrub at translation seams (no seams in `mgf.common` yet) |
| SC-12 root SECURITY.md | ✅ | `SECURITY.md` at repo root; vulnerability-reporting policy with private channel |
| SC-13 KDF for keys | ➖ | no key storage in `mgf.common` |
| SC-14 no auth enumeration | ➖ | no auth in `mgf.common` |
| SC-15 path traversal protection | ➖ | `mgf.common` accepts paths from trusted sources (config / programmatic); no untrusted paths |
| SC-16 minimum privilege | ➖ | `mgf.common` does not request privileges |
| SC-17 audit log on security events | ➖ | no security-relevant actions in `mgf.common` itself; rule applies to consumers' vault / SSH / subprocess use |
| SC-18 reproducible builds | ✅ | `uv.lock` + `hatchling` deterministic; `twine check` in CI |

### TESTING (TS-01..18)

| ID | Status | Evidence |
|---|---|---|
| TS-01 mirror src/ 1:1 | ✅ | every `src/mgf/common/<sub>/<file>.py` has a `tests/unit/<sub>/test_<file>.py` mirror |
| TS-02 no real I/O | ✅ | suite passes without OTLP collector / Sentry / journald |
| TS-03 isolation | ✅ | autouse identity fixture in `tests/unit/observability/conftest.py`; `_isolate_logging` fixtures save+restore handlers |
| TS-04 `filterwarnings = ["error"]` | ✅ | `pyproject.toml::[tool.pytest.ini_options]` |
| TS-05 strict markers / config | ✅ | `--strict-markers --strict-config` in `addopts` |
| TS-06 coverage ≥80% | ✅ | `--cov-fail-under=80` on the 3.12 CI job; sit at ~85% today |
| TS-07 typed exception tests | ✅ | `tests/unit/test_exceptions_base.py` covers field invariants |
| TS-08 translation seam tests | ➖ | no seams in `mgf.common` |
| TS-09 best-effort observer tests | ➖ | no observer loops |
| TS-10 security pins | 🟠 | `tests/unit/test_examples.py` smoke + `tests/unit/observability/test_redaction_property.py` cover the directly-relevant rules; full SC-* matrix pin file deferred until consumer-facing surface grows |
| TS-11 GUI worker tests | ➖ | no GUI |
| TS-12 async tests | ➖ | no async code |
| TS-13 property tests for round-trip | ✅ | `tests/unit/observability/test_redaction_property.py`; YAML round-trip property test deferred (see Observation §4 below) |
| TS-14 perf benchmarks | ✅ | `tests/unit/test_logging_perf.py` pins LG-12 |
| TS-15 smoke tests opt-in | ✅ | the example smoke test runs by default (it's fast); a real-backend smoke would be `@pytest.mark.smoke`-gated when added |
| TS-16 self-explanatory failures | ✅ | every assert in `tests/` carries a context message |
| TS-17 conftest hierarchy | ✅ | observability conftest at the right level; no cross-package fixture imports |
| TS-18 slow marker | ✅ | suite is fast enough that no test crosses 1 s; if one ever does, the marker pattern is ready |

### API_DESIGN (AP-01..15)

| ID | Status | Evidence |
|---|---|---|
| AP-01 `__all__` enumerated | ✅ | every public package's `__init__.py` carries an explicit `__all__`; pinned by `tests/unit/test_public_api_doc.py` (any new export without a doc row fails) |
| AP-02 docstrings on public names | ✅ | every name in `__all__` carries a docstring |
| AP-03 SemVer | ✅ | at v0.1.0; the 0.x window applies; pinned by `tests/unit/test_version_in_sync.py` |
| AP-04 deprecation cycle | ➖ | no deprecations through v0.1.0 |
| AP-05 stable signatures | ✅ | `mypy --strict` on consumers (VManager) catches narrowing |
| AP-06 return-type stability | ✅ | same |
| AP-07 exception contract | ✅ | every public function's docstring lists raised types |
| AP-08 `from __future__ import annotations` | ✅ | every `src/` file; ruff `FA100` would flag a regression |
| AP-09 `py.typed` marker | ✅ | `src/mgf/common/py.typed`; build step `unzip -l ... \| grep py.typed` pins it in CI |
| AP-10 PUBLIC_API.md sync | ✅ | `PUBLIC_API.md` at repo root; pinned by `tests/unit/test_public_api_doc.py` |
| AP-11 stability tiers | ✅ | every name in `PUBLIC_API.md` declares a tier (`experimental` per the 0.x convention) |
| AP-12 CHANGELOG migration recipes | ➖ | no breaking changes through v0.1.0 |
| AP-13 `__version__` in sync | ✅ | `tests/unit/test_version_in_sync.py` |
| AP-14 internal modules not consumer-imported | ✅ | `_identity.py`, `_settings.py`, `_loader.py`, `_paths.py`, `_base.py`, `_well_known.py` — all underscore-prefixed |
| AP-15 deprecated shims emit warning | ➖ | no shims in `mgf.common` itself; VManager's `vmanager.observability` shim is consumer-side |

### SCOPE (SP-01..06) — added in v2.1

| ID | Status | Evidence |
|---|---|---|
| SP-01 IN-scope list published | ✅ | `docs/standards/SCOPE.md` §1 |
| SP-02 OUT-of-scope list with reasoning | ✅ | `docs/standards/SCOPE.md` §2 (citation per row) |
| SP-03 per-PR scope justification | ➖ | process rule; enforced by review, not code. Mentioned in `CONTRIBUTING.md` |
| SP-04 Adjacent items require demand signal | ✅ | `docs/standards/SCOPE.md` §3 (each entry carries a promotion criterion) |
| SP-05 OUT entries cite alternatives | ✅ | `docs/standards/SCOPE.md` §2 — every row in the table cites the ecosystem alternative |
| SP-06 scope revisited every MAJOR | 🟠 | policy stated in `SCOPE.md` §6; first MAJOR boundary not yet crossed (we're at v0.1.0) |

---

## 2. Open gaps (live)

When this section is empty, the project is considered fully
compliant against the audited level (L2). Each entry MUST carry
severity, impact, close criteria, and an effort estimate.

*(none today — see §3 for what was just closed)*

The 6 open 🔴 Blockers in [`FEEDBACK.md`](../FEEDBACK.md) §2 are
not standards-compliance gaps — they're pre-1.0 design decisions.
They're tracked there, not here, because the standards themselves
do not yet require their resolution.

---

## 3. Closed gaps (audit trail)

Every gap closed in this audit (2026-04-26):

| ID | Closed by | Notes |
|---|---|---|
| **DP-14 ruff rules** | commit (this round) | Added `DTZ`, `ASYNC`, `S` to `[tool.ruff.lint]::select`; added `S108`/`S603`/`S311` to per-file ignores for tests + examples |
| **AP-13 version-in-sync pin** | `tests/unit/test_version_in_sync.py` | Pin asserts `mgf.common.__version__ == pyproject.toml::project.version`; fails the suite on drift |
| **AP-10 PUBLIC_API.md sync pin** | `tests/unit/test_public_api_doc.py` | 36 parameterised assertions: every name in every public `__all__` MUST appear in `PUBLIC_API.md` |
| **SC-10 vuln scan in CI** | `.woodpecker.yml` `vuln-scan` step | `pip-audit --strict --desc` on every push; transient-fetch retry once before treating as a finding |
| **LG-12 perf benchmark** | `tests/unit/test_logging_perf.py` | Pins ≤100 µs per record at the rotating-file sink path; uses the LOGGING.md §11.1 pytest-capture workaround |
| **TS-13 property test** | `tests/unit/observability/test_redaction_property.py` | Hypothesis tests for redactor: idempotence + key safety + sensitive-key scrub |
| **Repo-root SECURITY.md** | `SECURITY.md` | Closed in earlier commit; verified compliant in this audit |
| **Repo-root PUBLIC_API.md** | `PUBLIC_API.md` | Closed in earlier commit; verified compliant in this audit |
| **Repo-root CONTRIBUTING.md** | `CONTRIBUTING.md` | Closed in earlier commit; verified compliant in this audit |
| **LOGGING.md §12.1 LogRecord-name trap** | (this audit) | Added "Reserved `LogRecord` attribute names" subsection + anti-pattern row in the table; grounded in the bug we hit while building `examples/06_full_app/02_practical.py` |
| **CONFIGURATION.md §8.4 to_yaml_dict shallow note** | (this audit) | Added "Serialising nested sub-models — prefer `model_dump(mode='json')`" subsection; documents the current `to_yaml_dict` limitation + the workaround pattern; grounded in `examples/02_config/03_advanced.py` |

---

## 4. Observations (noted, not filed as gaps)

Findings that are real but deliberately not actioned now. Recording
them prevents the same observation from coming up every audit and
being freshly re-evaluated.

1. **`to_yaml_dict` shallow recursion.** Documented in
   `CONFIGURATION.md` §8.4 as a known limitation with a workaround.
   A code fix (use `model_dump(mode="json")` internally) is the
   right resolution but was deliberately deferred — the workaround
   is one-liner-cheap for consumers, the API change is bigger
   leverage for v0.2.0 when other CF-* refinements may also land.
   Tracked in [`FEEDBACK.md`](../FEEDBACK.md) (informally; will be
   filed formally in the next consumer-feedback round).

2. **`EnvironmentError` shadows the builtin alias.** Documented as
   FEEDBACK.md 🔴 Blocker **API-01**. The deliberate-shadowing
   posture is recorded with a `# noqa: A001` in the source. The
   pre-1.0 plan is rename → `HostEnvironmentError` with a
   deprecation alias; not actioned here because the rename touches
   every consumer's `except EnvironmentError:` and warrants its
   own coordination.

3. **No retry/backoff helper in `mgf.common` yet.** EH-11/12/13
   apply to consumers today. The `retry()` template in
   `ERROR_HANDLING.md` §15 is paste-able. Lifting it as
   `mgf.common.retry` is a planned addition (per `COMMON.md` §12).
   Not a gap because the rule is well-served by the documented
   template until a consumer needs the lift.

4. **YAML-round-trip property test for `Settings`.** `TS-13` would
   be well-served by a Hypothesis test that synthesises a
   `BaseAppSettings` subclass with random fields, saves, loads,
   and asserts equality. Deferred because:
   - `to_yaml_dict` is shallow (Observation §1) — the property
     test would have to use the `model_dump(mode="json")`
     workaround, which doesn't exercise the `save_settings` code
     path.
   - The redactor property test (closed gap §3) covers the more
     interesting round-trip surface.
   Will land naturally when `to_yaml_dict` is fixed in v0.2.0.

5. **LG-13 / LG-14 helpers not shipped.** The standard documents
   the `RateLimitFilter` / `SampleFilter` / `DedupFilter` /
   `register()` correlation-context helpers as templates;
   consumers compose stdlib `logging.Filter` per the doc. Not
   filed as a gap because the templates are paste-able and no
   consumer has asked for the lift yet.

---

## 5. Audit method

This audit was driven by mechanical sweeps:

```bash
# DP-12 — naive datetime usage
grep -rn 'datetime\.now()\|datetime\.utcnow()' src/ tests/ examples/

# DP-13 — open() outside context manager
grep -rn 'open(' src/ | grep -v 'with open\|\.open('

# LG-08 — f-string log calls
grep -rnE 'LOG\.(debug|info|warning|error|exception|critical)\(f"' src/

# SC-02 — shell=True
grep -rn 'shell=True' src/

# SC-03 — unsafe yaml.load
grep -rnE 'yaml\.load\(' src/ tests/ examples/ | grep -v safe_load

# SC-06 — verify=False / TLS skip
grep -rn 'verify=False\|CERT_NONE\|AutoAddPolicy' src/ tests/ examples/

# SC-05 — weak crypto / non-CSPRNG random
grep -rnE 'hashlib\.(md5|sha1)|random\.(random|choice|randint)' src/ | grep -v 'secrets\.'

# AP-08 — from __future__ import annotations
for f in $(find src/ -name '*.py'); do
  grep -q 'from __future__ import annotations' "$f" || echo "MISSING: $f"
done
```

Then the `pyproject.toml` ruff config was tightened to enforce
the same set going forward (`DTZ`, `ASYNC`, `S` selected; targeted
ignores per-file).

Per the cornerstone-rhythm pattern in
[`COMMON_COMPONENTS.md`](standards/COMMON_COMPONENTS.md)
§"Maintaining compliance over time", the next audit is triggered
by either:

- A new MUST landing in `docs/standards/` (re-audit against the
  new MUST + spot-check the existing rows).
- A release tag (full re-audit before publishing to PyPI).
- A consumer reporting a bug that traces back to a missed
  standard.

---

## 6. Cross-references

- The standards being audited:
  [`docs/standards/`](standards/).
- The MUSTs index that this table mirrors:
  [`docs/standards/README.md`](standards/README.md) §"Index of MUSTs".
- The cornerstone-rhythm pattern that defines audit/close/audit:
  [`docs/standards/COMMON_COMPONENTS.md`](standards/COMMON_COMPONENTS.md)
  §"Maintaining compliance over time".
- The PR process expectations referenced by every "code review"
  evidence cell: [`CONTRIBUTING.md`](../CONTRIBUTING.md).
- Public API contract synced by AP-10 / AP-13 pins:
  [`PUBLIC_API.md`](../PUBLIC_API.md).
