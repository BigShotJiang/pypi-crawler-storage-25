# Closed-Box Redesign — `mgf-common` v0.3 → v1.0

> **Status:** Design proposal — not yet committed to. Review and
> annotate before implementation begins.
> **Authors:** Bassam Alsanie + Claude Opus 4.7 (1M context).
> **Date:** 2026-04-26.
> **Target releases:** v0.3.0 (the reshape) → v0.3.x (soak +
> deprecation removal) → v1.0 (lock-in).
> **Predecessor:** v0.1.0 (current PyPI release).
> **Companion docs:** [`docs/CLAUDE.md`](CLAUDE.md) (standing
> instructions), [`FEEDBACK.md`](../FEEDBACK.md) (consumer
> feedback being closed by this push), [`docs/standards/`](standards/)
> (the engineering standards this redesign implements end-to-end).

---

## §0. How to read this document

This is the **spec we work against** for the v0.3 → v1.0 reshape.
It is long because the reshape touches every public surface — but
each section is independently reviewable. Read in order:

1. **§1 Executive Summary** (5 minutes) — what changes, in one
   page. Round-2 additions called out per headline.
2. **§2 Vision** (10 minutes) — the closed-box principle in full
   with the "why this matters for the project's survival"
   argument.
3. **§3 Audit findings** (15 minutes) — every concrete violation
   in the current 0.1.0 code. The motivation for everything that
   follows.
4. **§4 Surface redesign** (45 minutes) — per-subsystem
   before/after. The substance.
5. **§5–§9** (20 minutes) — CLI, presets, versioning, scope,
   phasing.
6. **§10 Open questions** (15 minutes) — 15 decisions still
   needed from you (Q1–Q15; Q11–Q15 are round-2 additions).
7. **§11 Risks** (15 minutes) — 15 honest enumerations
   (11.1–11.15; 11.10–11.15 are round-2 additions).
8. **§14 Principal-engineer review — round 2 additions**
   (30 minutes) — **the deep-dive pass.** 19 load-bearing
   additions (CB-24..CB-42) that round 1 missed: bootstrap
   atomicity + rollback, hot-reload, multi-tenancy + OTel
   collision, library self-observation, first-class test
   isolation, threading-model docs, automated closed-box
   compliance test, GDPR strict mode, per-subsystem perf
   budgets, etc. **Read this carefully — these are the
   senior-engineer concerns; round 1 was the architect-level
   sketch.**

When commenting / redirecting, reference the section header so we
have a stable anchor (`§4.3 Logging`, `§14.4 Multi-tenancy +
OTel`, etc.). The §15 decision log is intentionally empty for
your edits.

---

## §1. Executive Summary

### What this is

A coordinated reshape of `mgf-common`'s entire public surface to
realise the **closed-box principle**: the library is a complete
interface; consumers get full power without ever needing to reach
past `mgf.common.*` to underlying layers (`pydantic`,
`opentelemetry`, stdlib `logging`, etc.). Behaviour is
predictable, configuration is visible, complexity stays inside
the box.

### The change in one sentence

Today the library is a thin façade over `pydantic-settings` +
stdlib `logging` + `opentelemetry` with several ad-hoc helpers;
after this reshape it is a single uniform surface where every
behavioural knob lives in one typed `MgfSettings`, every
extensible surface has a registry, and one bootstrap call wires
everything in the right order.

### Headlines

> **Round 2 (principal-engineer review) added 19 load-bearing
> items in §14** — atomic bootstrap with rollback, hot-reload,
> per-tenant OTel attributes, library self-observation, first-class
> test isolation, threading model per subsystem, automated
> closed-box compliance test, GDPR strict-mode redaction,
> per-subsystem perf budgets, etc. **Read §14 carefully — it
> closes holes round 1 missed.**

1. **One bootstrap, not five.** A single
   `mgf.common.bootstrap(app_name, app_version, settings=None)`
   replaces the today-five-call sequence (`configure +
   setup_logging + setup_otel + install_excepthook +
   install_threading_excepthook`). **Round 2: bootstrap is
   transactional — rolls back on partial failure (§14.2).**

2. **One typed settings root.** A new `MgfSettings` schema holds
   every library-side configuration field. Env vars become
   aliases on the schema fields. `mgf-common explain` prints the
   active state with its source (default / env / file / override).
   **Round 2: hot-reload via `ctx.reload(new_settings)` (§14.5);
   per-component log levels first-class (§14.6); GDPR strict
   mode (§14.12); YAML+TOML+JSON via extension dispatch
   (§14.18).**

3. **Multi-tenancy story decided.** Hybrid `AppContext` (FEEDBACK
   §6 Option C) — module-level globals stay for the 95 % case;
   `with AppContext(...)` is the opt-in override. Closes API-02.
   **Round 2: per-tenant identity propagated to OTel via a
   custom span processor (§14.4) — `service.name` stays fixed
   per process; `tenant.app_name` / `tenant.app_version` span
   attributes do the per-tenant routing.**

4. **Registries everywhere user-extensibility belongs.** Crash
   sinks, log handlers, redaction patterns, OTel span processors,
   vault backends — all extensible via `@register_*("name")`
   decorators. Closes API-07 directly; pre-builds the pattern for
   the next 3–4 surfaces.

5. **Wrap the leaks.** `mgf.common.observability.get_logger`
   replaces `logging.getLogger`. `mgf.common.observability.Span`
   re-exports the OTel span type. `mgf.common.config.Field`
   re-exports pydantic's `Field`. Consumers stop importing
   pydantic / opentelemetry / logging directly for normal use.

6. **Renames + deprecations.** `EnvironmentError` →
   `HostEnvironmentError` (closes API-01). `make_settings_config`
   → subclass-kwarg pattern (`class S(BaseAppSettings, env_prefix="X_")`
   — closes API-06 Option A). `configure()` → deprecated alias
   for `bootstrap()`. All renames carry a `DeprecationWarning`
   and ship a codemod.

7. **Diagnostic CLI ships.** `mgf-common explain / validate /
   doctor`. Closed-box self-documentation.

8. **Scope is declared.** New `docs/standards/SCOPE.md` lists what
   we will NEVER build (kitchen-sink-ism kills more libraries
   than under-scoping does).

### Migration impact (VManager)

VManager pins `mgf-common>=0.1.0,<0.3`, so it is **not affected**
by 0.3.0 — nothing breaks until VManager bumps the pin. When it
does:

- Codemod `mgf-common migrate 0.1 0.2 src/` rewrites mechanical
  changes (renames, helper-call → subclass-kwarg, multi-call
  bootstrap → single `bootstrap()`).
- The deprecation aliases mean code that was NOT codemodded still
  runs; it just emits `DeprecationWarning`.
- Aliases are removed in 0.3 or 1.0 (TBD per §10 Q3).

### What ships when

- **0.1.x** — current PyPI line. Bug fixes only.
- **0.2.0** — small additive release (the FEEDBACK round 1
  closures already in `[Unreleased]`: API-08 `UnconfiguredWarning`,
  PAPER-01 / PAPER-02 / PAPER-05). NOT the reshape; ships first
  to get the small wins out the door.
- **0.3.0** — **the reshape**. The closed-box redesign per this
  document. ~7 substantial commits per the §9 phasing.
- **0.3.x** — soak. Bug fixes only; deprecation warnings still
  active.
- **0.4.0** — deprecation aliases removed (or skip straight to
  1.0 — see §10 Q3).
- **1.0** — lock the contract. After ≥1 second consumer's audit
  per FEEDBACK §7 meta-feedback #2.

---

## §2. Vision

### The closed-box principle (full)

Three nested commitments:

#### 2.1 Closed (no leaked imports)

The library is a complete interface. A consumer who is doing
something **reasonable** for the library's stated scope (§8) MUST
NOT need to:

- `import pydantic` to extend their config schema.
- `import opentelemetry` to manipulate spans.
- `import logging` to acquire a logger or filter records.
- `import warnings` to handle library warnings.
- `import paramiko` (when SSH ships) to override SSH client
  behaviour.
- `import keyring` (when vault ships) to add a vault backend.

Where the consumer needs primitives from those libraries, we
re-export them from `mgf.common.*`. Where the consumer needs
behaviour, we expose an extension point (registry / hook /
configuration field).

**Test for "reasonable":** is the consumer trying to do something
the library's standards docs describe? If yes, it MUST be doable
without reaching past us. If no (they're inventing a pattern not
in the standards), they're allowed to reach past us — but it's
documented as off-the-paved-path.

**This is NOT about reflexive wrapping.** We do NOT re-export
every name from every dependency. We re-export the names that
appear in consumer code today (or that the standards prescribe).
The list is finite and reviewable.

#### 2.2 Predictable + visible (no hidden behaviour)

A consumer can answer these questions in under 30 seconds:

- "What env vars does this library read?" — `mgf-common explain`
  prints them.
- "What's my current logging configuration?" — same.
- "Why is journald attached on this server?" — same; the source
  column shows `env: JOURNAL_STREAM=...` or `preset: systemd`.
- "What handlers are registered?" — `mgf-common doctor` lists
  every active handler, sink, processor.
- "What will happen if I `bootstrap(...)` with these settings?" —
  `mgf-common validate config.yaml` validates + prints the
  resolved active config.

Hidden auto-detection is the enemy of predictability. The 0.2
default is **explicit** ; auto-detection becomes an opt-in
**preset** (`MgfSettings(preset="systemd")`).

#### 2.3 Simple on the outside, sophisticated on the inside

Internal complexity is fine — the JSON formatter can grow a
contextvars layer, the crash reporter can grow a registry of
sinks, the bootstrap can grow ordering / retry / cleanup hooks.
What MUST NOT grow is the consumer's mental model.

A consumer's "minimal viable use" stays one call:

```python
import mgf.common

with mgf.common.bootstrap(app_name="myapp", app_version="1.0"):
    do_work()
```

Adding sophistication adds typed configuration fields, never
adds new required calls. The "happy path" never grows.

### 2.4 The PR review question (load-bearing)

When designing or reviewing any public-API change:

> **"Can the consumer accomplish their reasonable use case
> without reaching past `mgf.common.*`?"**

If no, the design is wrong. Add the missing surface, redirect
through us, or move the use case to off-the-paved-path with
explicit documentation.

This question is added to `CONTRIBUTING.md` PR-review checklist.

### 2.5 The competitive positioning argument

Most Python infrastructure libraries die not from missing
features but from **integration friction that compounds over
time**. The death spiral:

1. Library ships v1; consumers integrate; integration takes a day.
2. Library adds feature; consumers update; integration friction
   adds a few minutes per consumer.
3. Library adds another feature; integration friction compounds.
4. Six months later: integrating the new version takes consumers
   half a day. They start pinning to old versions.
5. Library author burns out maintaining a feature set nobody is
   actually upgrading to.
6. A simpler competitor appears; consumers migrate.

The closed-box principle is **the single most important
intervention against this spiral**. Every feature added through
the closed box adds zero integration friction (the user's code
stays the same; only the configuration changes). Every feature
added that requires the user to import a new module / reshape
their bootstrap / handle a new exception type adds friction.

**`mgf-common`'s competitive advantage is the closed-box
interface.** We can ship the most advanced infrastructure in the
Python ecosystem, but if it costs the user a day of integration
where the alternative cost an hour, we lose.

### 2.6 What this is NOT

The closed-box principle has limits. It is **not**:

- **A wrapper for the entire stdlib.** We do not re-export
  `pathlib.Path` or `datetime.datetime`. Stdlib types that are
  universal language vocabulary stay universal.
- **A monoculture mandate.** Consumers can use OTHER libraries
  (httpx, click, pytest, …) freely. The closed box is about
  `mgf-common`'s OWN domain (logging, config, exceptions,
  observability, crash, vault, SSH, service-manager, etc.).
- **A "no escape hatch" rule.** When a consumer truly needs the
  underlying type (debugging, integration with an unsupported
  third-party), the path exists — `mgf.common.observability.get_otel_provider()`
  returns the wrapped provider, etc. But the path is documented
  as "internals; no stability promise".

---

## §3. Audit findings — current v0.1.0 violations

Concrete violations of the closed-box principle in the current
code. Severity per the closed-box impact:

- **🔴 Critical** — consumer must `import` a foreign library for a
  reasonable use case.
- **🟡 Significant** — consumer can do it through us but the path
  is awkward / undocumented / has foot-guns.
- **🟢 Minor** — internal leak that consumers rarely hit.

### 3.1 Identity & lifecycle

| ID | Severity | Violation | Evidence |
|---|---|---|---|
| **CB-01** | 🔴 | Bootstrap is 5 calls in a fixed order; missing one is silent. | `examples/06_full_app/03_advanced.py:200-260` (the wiring) |
| **CB-02** | 🔴 | No multi-tenancy escape. Plug-in architectures are forbidden by design. | `_identity.py:9-13` (docstring rejects it) |
| **CB-03** | 🟡 | `configure()` mutates module-level globals — invisible side-effects. | `_identity.py:53` |

### 3.2 Settings

| ID | Severity | Violation | Evidence |
|---|---|---|---|
| **CB-04** | 🔴 | Consumer MUST `from pydantic import Field, AliasChoices, model_validator` for any non-trivial subclass. | every consumer's settings module |
| **CB-05** | 🔴 | `make_settings_config(env_prefix="X_")` is a workaround that leaks pydantic-settings internals. | `_settings.py` (FEEDBACK API-06) |
| **CB-06** | 🟡 | `to_yaml_dict` is shallow — silently breaks on nested sub-models. | `_settings.py:161-180` (just documented in CONFIGURATION.md §8.4) |
| **CB-07** | 🟡 | Library-side behaviour (logging level, OTel endpoint, crash sink) lives in env vars + `setup_*` parameters, NOT in a typed schema the consumer can introspect. | `setup_logging` signature; `<APP>_CRASH_SINK` env var |

### 3.3 Logging

| ID | Severity | Violation | Evidence |
|---|---|---|---|
| **CB-08** | 🔴 | Consumer MUST `import logging` to acquire a logger. The library has no `get_logger`. | every example file |
| **CB-09** | 🔴 | Consumer MUST `import logging` to add a custom handler / filter. | docs hint at it but the path is direct stdlib |
| **CB-10** | 🟡 | The `LogRecord.name` reservation trap (`extra={"name": ...}` → `KeyError`) is a stdlib leak — we mention it in the standards but the API doesn't protect users. | LOGGING.md §12.1 |
| **CB-11** | 🟡 | Redactor pattern extension via constructor kwargs — fine for one-off, painful for plug-in chains. (Partially fixed by `__or__`; full registry would be cleaner.) | `redaction.py` |

### 3.4 Tracing / observability

| ID | Severity | Violation | Evidence |
|---|---|---|---|
| **CB-12** | 🔴 | To set a span attribute mid-operation, consumer MUST `from opentelemetry import trace; trace.get_current_span().set_attribute(...)`. | `examples/04_observability/03_advanced.py:128-132` |
| **CB-13** | 🔴 | To customise the OTel resource (e.g., `service.namespace`), consumer MUST `import opentelemetry`. | no `mgf.common` API exists |
| **CB-14** | 🟡 | Sampling is configured via `OTEL_*` env vars only — not in any typed schema. | `otel_setup.py` |
| **CB-15** | 🟡 | Custom span processors (e.g., for batching to a non-OTLP backend) require `import opentelemetry` and bypass our setup. | no extension point |

### 3.5 Crash reporter

| ID | Severity | Violation | Evidence |
|---|---|---|---|
| **CB-16** | 🔴 | Crash sinks are a hardcoded list — consumer must fork to add a Slack / PagerDuty / custom-on-prem sink. | `crash_reporter.py:_ship_remote` (FEEDBACK API-07) |
| **CB-17** | 🟡 | Sink choice via env var only — not introspectable, not validatable at startup. | `<APP>_CRASH_SINK` |

### 3.6 Exceptions

| ID | Severity | Violation | Evidence |
|---|---|---|---|
| **CB-18** | 🟡 | `EnvironmentError` shadows stdlib alias; every consumer carries `# noqa: A001`. | `_well_known.py` (FEEDBACK API-01) |

### 3.7 Cross-cutting

| ID | Severity | Violation | Evidence |
|---|---|---|---|
| **CB-19** | 🔴 | Cancellation primitive lives in the consumer (VManager) — every future `mgf-common` feature that wants to cooperate with cancellation either invents its own or depends on consumer code. | FEEDBACK API-03 |
| **CB-20** | 🔴 | No `Protocol`-typed interfaces for stable abstractions — consumers must subclass to mock. | FEEDBACK API-05 |
| **CB-21** | 🟡 | No introspection into "what's actually configured right now" — the library's behaviour is opaque. | no `explain` CLI |
| **CB-22** | 🟡 | No diagnostic for "did I install the right extras / wire the right hooks?" — install-state is invisible. | no `doctor` CLI |
| **CB-23** | 🟢 | Auto-detection (TTY, JOURNAL_STREAM, OTEL endpoint) is invisible — surprises consumers in non-standard environments. | `setup_logging`, `_maybe_add_journald` |

### 3.8 Audit summary

- **🔴 Critical: 12** (most are reachable-only-via-foreign-import)
- **🟡 Significant: 10**
- **🟢 Minor: 1**

The critical violations cluster around three themes: (a)
bootstrap is too many calls, (b) consumers must `import pydantic
/ opentelemetry / logging` directly, (c) extensibility requires
forking rather than registering. The redesign's three biggest
moves — single bootstrap, wrap-the-leaks, registries — close all
twelve.

---

## §4. Surface redesign

For each subsystem: current state → new state → before/after
code → which CB-* / FEEDBACK items close.

### 4.1 Identity & Lifecycle

**Current state.** Five separate calls; module-level globals;
silent failure mode if any call is omitted; no multi-tenancy
escape.

**New state.**

```python
# src/mgf/common/__init__.py — public surface
from mgf.common._lifecycle import (
    AppContext,
    bootstrap,
    current_context,
    shutdown,
)

__all__ = [
    "AppContext",
    "bootstrap",
    "current_context",
    "shutdown",
    "UnconfiguredWarning",   # already shipped
    "app_name",              # deprecated, alias for current_context().app_name
    "app_version",           # deprecated, alias for current_context().app_version
    "configure",             # deprecated, alias for bootstrap (no context)
    "__version__",
]
```

```python
@dataclass(frozen=True)
class AppContext:
    """Per-tenant identity + settings, the unit of mgf-common context.

    Constructed by ``bootstrap()`` (or directly for opt-in
    multi-tenancy). Frozen so the active context is a clean
    snapshot — re-bootstrapping creates a new AppContext, never
    mutates the existing one.
    """
    app_name: str
    app_version: str
    settings: MgfSettings
    # Internal: handles to the wired observability stack so
    # shutdown() can flush + close cleanly.
    _wired: _WiringHandles = field(repr=False, compare=False)
```

```python
@contextmanager
def bootstrap(
    app_name: str,
    app_version: str,
    *,
    settings: MgfSettings | None = None,
) -> Iterator[AppContext]:
    """The single canonical bootstrap. Wires every observability
    subsystem in the correct order, returns the active context,
    cleans up on exit.

    Usage::

        with mgf.common.bootstrap(app_name="myapp", app_version="1.0") as ctx:
            do_work()

    For multi-tenant processes (plug-ins, monorepo test runs):

        with AppContext(app_name="plugin-x", app_version="2.0", settings=...):
            plugin_work()

    The context is established via contextvar so descendant tasks
    / threads inherit it. The 95% case (single-app process) gets
    module-level globals as a fallback; the 5% case (multi-tenant)
    gets the contextvar override per FEEDBACK §6 Option C.
    """
    ...
```

**Before / after (consumer code):**

```python
# BEFORE — v0.1
import mgf.common
from mgf.common.observability import (
    setup_logging, setup_otel,
    install_excepthook, install_threading_excepthook,
)

mgf.common.configure(app_name="myapp", app_version="1.0")
setup_logging(level="INFO")
setup_otel()
install_excepthook()
install_threading_excepthook()
do_work()

# AFTER — v0.3
import mgf.common

with mgf.common.bootstrap(app_name="myapp", app_version="1.0"):
    do_work()
```

**Closes:** CB-01, CB-02, CB-03 + FEEDBACK API-02 + §3.10
(lifecycle).

**Deprecations (with alias):**

- `mgf.common.configure(app_name, app_version)` → emits
  `DeprecationWarning("use bootstrap()")`. Internally calls
  `bootstrap()` without the context-manager (returns a no-op
  shutdown function).
- `mgf.common.observability.setup_logging` → still callable but
  deprecated; users SHOULD configure via `MgfSettings.logging`
  and call `bootstrap()`.
- Same for `setup_otel`, `install_excepthook`,
  `install_threading_excepthook`.

### 4.2 Settings

**Current state.** Consumer subclasses `BaseAppSettings`,
manually wires `model_config` via `make_settings_config(...)`,
imports `Field` / `AliasChoices` / etc. from pydantic.
Library-side behaviour (logging level, OTel sample rate, crash
sink) lives in env vars + `setup_*` parameters — fragmented
and invisible.

**New state.**

```python
# src/mgf/common/settings.py — the LIBRARY's own settings root
class MgfSettings(BaseAppSettings):
    """Single typed root for every mgf-common configuration knob.

    The library reads from this only. Consumers tweak it via
    ``bootstrap(settings=MgfSettings(...))`` or the env var aliases.
    ``mgf-common explain`` prints the active state.
    """
    model_config = settings_config(env_prefix="MGF_")

    logging: LoggingSettings = Field(default_factory=LoggingSettings)
    otel: OtelSettings = Field(default_factory=OtelSettings)
    crash: CrashSettings = Field(default_factory=CrashSettings)
    redaction: RedactionSettings = Field(default_factory=RedactionSettings)
    preset: PresetName = "explicit"   # see §6 below
```

```python
class LoggingSettings(BaseModel):
    model_config = ConfigDict(extra="forbid")

    level: LogLevel = "INFO"
    format: LogFormat = "text"          # was "auto" — now explicit per §6
    file: Path | None = None             # None → <state>/logs/<app>.log
    journald: bool = False
    syslog_address: str | None = None
    http_sink: str | None = None
    rotating_max_bytes: int = 10 * 1024 * 1024
    rotating_backup_count: int = 5
```

```python
class OtelSettings(BaseModel):
    model_config = ConfigDict(extra="forbid")

    enabled: bool = False
    endpoint: str | None = None         # OTLP endpoint
    service_namespace: str | None = None
    sample_rate: float = Field(default=1.0, ge=0.0, le=1.0)
    resource_attributes: dict[str, str] = Field(default_factory=dict)
    httpx_instrumented: bool = True
    subprocess_instrumented: bool = False
```

```python
class CrashSettings(BaseModel):
    model_config = ConfigDict(extra="forbid")

    sinks: list[str] = Field(default_factory=lambda: ["local"])
    """List of registered sink names. ``local`` always present;
    ``sentry`` / ``otlp`` / ``http://...`` / consumer-registered
    names also valid. See §4.5 (crash registry)."""

    sentry_dsn: str | None = None
    otlp_endpoint: str | None = None    # crash-specific override
    http_url: str | None = None
    state_dir: Path | None = None       # None → <state>/crashes/
```

```python
class RedactionSettings(BaseModel):
    model_config = ConfigDict(extra="forbid")

    extra_keys: frozenset[str] = Field(default_factory=frozenset)
    extra_value_patterns: list[str] = Field(default_factory=list)
    enabled_pattern_groups: list[str] = Field(
        default_factory=lambda: ["builtin"]
    )
    """List of registered pattern-group names. ``builtin`` is the
    Bearer/JWT/PEM/API-key set; consumers register additional
    groups via ``register_redaction_pattern_group(name, patterns)``."""
```

**Pydantic re-exports** (closes CB-04):

```python
# src/mgf/common/config/__init__.py — public surface
from mgf.common.config._reexports import (
    AliasChoices,
    BaseModel,
    ConfigDict,
    Field,
    field_validator,
    model_validator,
    ValidationError,
)

__all__ = [
    "AliasChoices",
    "BaseModel",
    "BaseAppSettings",
    "ConfigDict",
    "Field",
    "field_validator",
    "model_validator",
    "PathKind",
    "ValidationError",
    "default_config_path",
    "expand_path",
    "load_settings",
    "platform_dir",
    "save_settings",
    "settings_config",  # renamed from make_settings_config
    "to_dict",          # replacement for the broken to_yaml_dict (closes CB-06)
]
```

The `_reexports.py` module is a single line per name:
`from pydantic import Field as Field` — explicit re-exports keep
mypy strict happy.

**Consumer subclass — Option A from FEEDBACK API-06 (closes CB-05):**

```python
# BEFORE — v0.1
from pydantic import Field, AliasChoices, model_validator
from mgf.common.config import BaseAppSettings, make_settings_config

class AppConfig(BaseAppSettings):
    model_config = make_settings_config(env_prefix="MYAPP_")

    backend_uri: str = "..."

    @model_validator(mode="after")
    def _check(self): ...

# AFTER — v0.3
from mgf.common.config import (
    BaseAppSettings, Field, model_validator,
)

class AppConfig(BaseAppSettings, env_prefix="MYAPP_"):
    backend_uri: str = "..."

    @model_validator(mode="after")
    def _check(self): ...
```

The `__init_subclass__` hook in the new `BaseAppSettings` reads
`env_prefix` (and other `SettingsConfigDict` fields) from
subclass kwargs and merges them into `model_config` correctly.
`settings_config(env_prefix="...")` stays as a deprecated alias.

**Closes:** CB-04, CB-05, CB-06, CB-07 + FEEDBACK API-06 +
§5.11 (versioned file store, indirectly — gets one source of
truth for "what configures this library").

### 4.3 Logging

**Current state.** Consumer `import logging; LOG =
logging.getLogger(__name__)`. Custom handlers via direct
`logging.Handler` subclass. Redactor extension via constructor
kwargs.

**New state.**

```python
# src/mgf/common/observability/__init__.py — public surface
from mgf.common.observability.logging_setup import (
    LogFormat,
    LogLevel,
    add_handler,
    get_logger,
    register_log_handler,
    register_redaction_pattern_group,
    remove_handler,
)

# get_logger replaces logging.getLogger for closed-box use:
LOG = get_logger(__name__)
LOG.info("hello", extra={"user": "alice"})
```

```python
def get_logger(name: str | None = None) -> logging.Logger:
    """Return a logger.

    Identical to ``logging.getLogger(name)``, but exposed through
    ``mgf.common.observability`` so consumers don't reach past
    us into stdlib for the canonical pattern. ``name`` SHOULD be
    ``__name__`` (rule LG-01).

    Returns a stdlib ``logging.Logger`` because that IS the
    interface — wrapping it in our own type would lose
    interoperability with every test fixture, IDE plug-in, and
    log-aggregation library that knows about ``logging.Logger``.
    The closed-box value here is the import path: consumers
    grow the habit of "everything logging-related lives in
    mgf.common.observability".
    """
    return logging.getLogger(name)
```

```python
@register_log_handler("syslog-rfc5424")
def _make_syslog_rfc5424(settings: MgfSettings) -> logging.Handler:
    """Custom RFC 5424 syslog handler. Consumers register their
    own handlers the same way. The registry is consulted by
    bootstrap() during wiring; only handlers whose name appears
    in MgfSettings.logging.extra_handlers get attached."""
    ...

# Equivalent to today's "subclass + monkey-patch setup_logging".
```

**Redaction registry** (closes CB-11):

```python
@register_redaction_pattern_group("hypervisor-tokens")
def _hypervisor_patterns() -> tuple[re.Pattern[str], ...]:
    return (
        re.compile(r"\bhv-tok-[A-Za-z0-9]{32,}\b"),
        re.compile(r"\bhv-key-[A-Za-z0-9]{40,}\b"),
    )

# Consumer enables via settings:
MgfSettings(redaction=RedactionSettings(
    enabled_pattern_groups=["builtin", "hypervisor-tokens"]
))
```

**`name` collision protection** (closes CB-10):

```python
def get_logger(name: str | None = None) -> SafeLogger:
    """... returns a SafeLogger that intercepts log calls and
    rejects any extra={'name': ...} / extra={'msg': ...} etc.
    with a clear error message pointing at the reserved-name
    list, instead of the cryptic stdlib KeyError."""
```

A `SafeLogger` wrapper class (proxies `logging.Logger`) catches
the reserved-name collision pre-flight and raises a typed
`LogRecordKeyError` (subclass of `AppError`) with the actionable
hint per rule EH-09: *"`name` is reserved by Python's LogRecord
— use `subject` / `entity_name` / etc. See LOGGING.md §12.1."*

**Closes:** CB-08, CB-09, CB-10, CB-11.

### 4.4 Tracing / observability

**Current state.** `operation_span` is the only OTel surface
through us. Anything else requires `import opentelemetry`.

**New state.**

```python
# src/mgf/common/observability/__init__.py — public surface (additions)
from mgf.common.observability.otel_setup import (
    Span,
    SpanContext,
    SpanKind,
    Status as SpanStatus,
    StatusCode,
    add_event,
    get_current_span,
    operation_span,
    register_span_processor,
    set_attribute,
    set_status,
)
```

```python
# Re-exports from opentelemetry.trace, but via our public surface.
# If OTel changes its types in a major release, we shim — consumer
# code stays the same.
Span = trace.Span
SpanContext = trace.SpenContext
SpanStatus = trace.Status
StatusCode = trace.StatusCode
```

```python
def add_event(
    name: str,
    attributes: dict[str, Any] | None = None,
    timestamp: int | None = None,
) -> None:
    """Add an event to the current span. No-op when OTel is
    disabled. Wraps ``trace.get_current_span().add_event(...)``."""
    span = get_current_span()
    if span and span.is_recording():
        span.add_event(name, attributes=attributes or {}, timestamp=timestamp)

def set_attribute(key: str, value: AttributeValue) -> None:
    """Set an attribute on the current span. No-op when OTel is
    disabled."""
    span = get_current_span()
    if span and span.is_recording():
        span.set_attribute(key, value)

def set_status(status: SpanStatus, description: str = "") -> None:
    """Set the current span's status. No-op when OTel is disabled."""
    span = get_current_span()
    if span and span.is_recording():
        span.set_status(status, description)
```

**Span processor registry** (closes CB-15):

```python
@register_span_processor("custom-batcher")
def _make_my_batcher(settings: MgfSettings) -> SpanProcessor:
    """Consumer-defined span processor. Activated when
    MgfSettings.otel.enabled_processors includes 'custom-batcher'."""
    return MyCustomSpanProcessor(...)
```

**Resource customisation in Settings** (closes CB-13):

```python
MgfSettings(otel=OtelSettings(
    service_namespace="platform",
    resource_attributes={
        "team": "infra",
        "environment": "production",
    },
))
```

**Before / after (consumer code):**

```python
# BEFORE — v0.1
from mgf.common.observability import operation_span
from opentelemetry import trace
from opentelemetry.trace import Status, StatusCode

with operation_span("vm.create", vm_name="prod-1"):
    span = trace.get_current_span()
    span.set_attribute("step", "validate")
    if failed:
        span.set_status(Status(StatusCode.ERROR, "validation failed"))

# AFTER — v0.3
from mgf.common.observability import (
    operation_span, get_current_span, set_attribute, set_status, SpanStatus,
)

with operation_span("vm.create", vm_name="prod-1"):
    set_attribute("step", "validate")
    if failed:
        set_status(SpanStatus.ERROR, "validation failed")
```

**Closes:** CB-12, CB-13, CB-14, CB-15.

### 4.5 Crash reporter

**Current state.** Three hardcoded sinks (sentry / otlp /
http://). Sink chosen via `<APP>_CRASH_SINK` env var. To add a
custom sink, fork or wrap.

**New state.**

```python
# src/mgf/common/observability/__init__.py — public surface (additions)
from mgf.common.observability.crash_reporter import (
    register_crash_sink,
    report_now,
    unregister_crash_sink,
)
```

```python
@register_crash_sink("my-slack")
def ship_to_slack(report_path: Path, payload: dict[str, Any]) -> None:
    """Custom sink. Closes FEEDBACK API-07.

    Receives the local report path AND the in-memory payload
    (which includes the redacted exception, traceback, app
    metadata). MUST NOT raise — the crash reporter wraps every
    sink call in try/except and logs failures at WARNING.
    """
    requests.post(
        SLACK_WEBHOOK,
        json={"text": f"Crash in {payload['app']}: {payload['exception']['message']}"},
        timeout=5,
    )

# Activated via settings:
MgfSettings(crash=CrashSettings(sinks=["local", "my-slack", "sentry"]))
```

**Multi-sink fan-out.** Today only one sink per process. New:
multiple sinks; the report fans out to all configured. Each sink
is independent; failure of one doesn't affect others.

**Builtins preregistered:**

- `local` — always-on, writes JSON file under
  `<state>/crashes/`.
- `sentry` — `sentry-sdk` if installed.
- `otlp` — OpenTelemetry log emitter if installed.
- `http` — generic POST webhook (URL from `CrashSettings.http_url`).

**Closes:** CB-16, CB-17 + FEEDBACK API-07.

### 4.6 Exceptions

**Current state.** `EnvironmentError` shadows stdlib alias.

**New state.**

```python
# src/mgf/common/exceptions/__init__.py
class HostEnvironmentError(AppError):
    """Host-level pre-flight failure: CPU lacks vmx, kernel module
    missing, required binary absent, etc.

    Renamed from EnvironmentError (which shadowed the stdlib
    alias for OSError). EnvironmentError remains as a deprecated
    alias for one MINOR cycle then is removed in v1.0.
    """

# Deprecated alias:
class EnvironmentError(HostEnvironmentError):  # noqa: A001 — temporary alias
    def __init_subclass__(cls, **kwargs: Any) -> None:
        warnings.warn(
            "mgf.common.exceptions.EnvironmentError is deprecated since "
            "v0.3.0; use HostEnvironmentError. Will be removed in v1.0.",
            DeprecationWarning,
            stacklevel=2,
        )
        super().__init_subclass__(**kwargs)
```

The codemod (§7.3) handles the source rewrite mechanically.

**Closes:** CB-18 + FEEDBACK API-01.

### 4.7 Vault (new module)

Lifts FEEDBACK §3.2 + §5.2. Closes a future CB-* that would have
landed.

```python
# src/mgf/common/vault/__init__.py
from mgf.common.vault._protocol import VaultProtocol
from mgf.common.vault._registry import register_vault_backend
from mgf.common.vault._builtins import (
    KeyringVault,
    EncryptedFileVault,
    EnvVault,
)

__all__ = [
    "EncryptedFileVault",
    "EnvVault",
    "KeyringVault",
    "VaultProtocol",
    "register_vault_backend",
]
```

```python
class VaultProtocol(Protocol):
    """The interface. Implement on top of any backend."""
    def get(self, key: str) -> str | None: ...
    def set(self, key: str, value: str) -> None: ...
    def delete(self, key: str) -> None: ...
    def list_keys(self) -> list[str]: ...

    @property
    def backend(self) -> str: ...   # "keyring" / "file" / "env" / consumer-name
```

Backend chosen via `MgfSettings.vault.backend = "keyring"`.
Consumer registers additional backends via
`register_vault_backend("aws-secrets-manager", AwsSecretsManagerVault)`.

### 4.8 Cancellation + Progress (new module)

Closes FEEDBACK API-03 + §3.1 + §5.1. Lifts from VManager.

```python
# src/mgf/common/progress/__init__.py
from mgf.common.progress._token import CancellationToken
from mgf.common.progress._reporter import (
    NullReporter,
    ProgressReporter,
    RecordingReporter,
)

__all__ = [
    "CancellationToken",
    "NullReporter",
    "ProgressReporter",
    "RecordingReporter",
]
```

```python
class CancellationToken:
    """Threading-friendly cooperative cancellation token.

    Signal-oriented: ``cancel()`` flips a flag, ``is_cancelled``
    is a cheap read, ``wait()`` blocks until cancelled with an
    optional timeout. Not async-aware; async consumers use the
    asyncio adapter at ``mgf.common.progress.asyncio``.
    """
```

```python
class ProgressReporter(Protocol):
    """Duck-typed reporter."""
    def report(self, message: str, current: int = 0, total: int = 0) -> None: ...
    def is_cancelled(self) -> bool: ...
```

Async adapter (`mgf.common.progress.asyncio`) bridges to
`asyncio.Event`. Qt adapter (in the future Qt-helpers module)
bridges to a `QThread` signal.

### 4.9 Protocols (new module)

Closes FEEDBACK API-05 + CB-20.

```python
# src/mgf/common/typing/__init__.py
from typing import Protocol, runtime_checkable

@runtime_checkable
class CancellationProtocol(Protocol):
    def is_cancelled(self) -> bool: ...
    def cancel(self) -> None: ...

@runtime_checkable
class ReporterProtocol(Protocol):
    def report(self, message: str, current: int = 0, total: int = 0) -> None: ...
    def is_cancelled(self) -> bool: ...

@runtime_checkable
class LogSinkProtocol(Protocol):
    """Append-style log sink. The GUI dock's protocol; the
    lift target for the future GUI helpers package."""
    def append_info(self, message: str) -> None: ...
    def append_error(self, message: str) -> None: ...

@runtime_checkable
class VaultProtocol(Protocol):
    def get(self, key: str) -> str | None: ...
    def set(self, key: str, value: str) -> None: ...
    def delete(self, key: str) -> None: ...
```

`mgf.common`'s own code accepts these where the concrete class is
currently demanded.

### 4.10 CLI helpers (new module)

Closes FEEDBACK §3.8 + §5.8.

```python
# src/mgf/common/cli/__init__.py
from mgf.common.cli._exit_codes import (
    EXIT_CONFIG_ERROR,
    EXIT_ENVIRONMENT_ERROR,
    EXIT_GUEST_ERROR,
    EXIT_OPERATION_ERROR,
    EXIT_SUCCESS,
    EXIT_UNKNOWN,
)
from mgf.common.cli._handler import run_and_translate, translate_exceptions

__all__ = [
    "EXIT_CONFIG_ERROR",
    "EXIT_ENVIRONMENT_ERROR",
    "EXIT_GUEST_ERROR",
    "EXIT_OPERATION_ERROR",
    "EXIT_SUCCESS",
    "EXIT_UNKNOWN",
    "run_and_translate",
    "translate_exceptions",
]
```

```python
def run_and_translate(
    main_fn: Callable[[list[str]], int],
    argv: list[str] | None = None,
    *,
    exit_code_map: dict[type[AppError], int] | None = None,
) -> int:
    """Top-level handler: catch every typed AppError, map to exit
    code, route untyped exceptions through the crash reporter.
    Default mapping is the standard EXIT_* set; consumers
    override per-category via exit_code_map.
    """
```

### 4.11 Lifecycle (already covered in §4.1)

Single `bootstrap()` function. The lifecycle module is the
implementation detail behind it.

---

## §5. The diagnostic CLI — `mgf-common`

Console-script entry point. Three subcommands.

### 5.1 `mgf-common explain`

Prints the active `MgfSettings` with each field's source.

```
$ mgf-common explain --app myapp --version 1.0
mgf-common v0.3.0  active configuration for myapp v1.0

[logging]
  level                  INFO            (default)
  format                 json            (env: MGF_LOGGING__FORMAT=json)
  file                   /home/user/.local/state/myapp/logs/myapp.log
                                         (default — derived from app_name)
  journald               true            (preset: systemd)
  syslog_address         (none)          (default)
  http_sink              (none)          (default)
  rotating_max_bytes     10485760        (default — 10 MiB)
  rotating_backup_count  5               (default)

[otel]
  enabled                true            (env: OTEL_EXPORTER_OTLP_ENDPOINT=...)
  endpoint               https://otel.example.com/v1/traces
  service_namespace      platform        (config: ~/.config/myapp/config.yaml)
  sample_rate            0.1             (env: MGF_OTEL__SAMPLE_RATE=0.1)
  resource_attributes    team=infra      (config)
                         env=prod
  httpx_instrumented     true            (default)
  subprocess_instrumented false          (default)

[crash]
  sinks                  [local, sentry] (env: MYAPP_CRASH_SINK=local,sentry)
  sentry_dsn             https://***@sentry.io/...
                                         (env: MYAPP_SENTRY_DSN — REDACTED)
  state_dir              /home/user/.local/state/myapp/crashes
                                         (default — derived from app_name)

[redaction]
  enabled_pattern_groups [builtin, hypervisor-tokens]
                                         (config)
  extra_keys             {hv_session_id} (config)

Environment variables read by mgf-common:
  MGF_LOGGING__FORMAT     (set: json)
  MGF_LOGGING__LEVEL      (unset)
  MGF_OTEL__SAMPLE_RATE   (set: 0.1)
  MGF_OTEL__ENDPOINT      (unset)
  ...

Active context:
  bootstrap called: yes
  app_name:    myapp        (via bootstrap)
  app_version: 1.0          (via bootstrap)
  AppContext stack depth: 0 (no opt-in multi-tenant override)
```

### 5.2 `mgf-common validate <config.yaml>`

Validates a YAML file against the `MgfSettings` schema. Prints
the resolved active configuration as if it were applied via
`bootstrap()`.

```
$ mgf-common validate ~/.config/myapp/config.yaml
✓ Schema valid (MgfSettings v0.3.0)
✓ All field constraints pass
✓ No unknown keys

Resolved active configuration:
  ... (same shape as `explain` above, sourced entirely from the file) ...
```

### 5.3 `mgf-common doctor`

Runs install-state and wiring checks.

```
$ mgf-common doctor
✓ mgf-common v0.3.0 installed at /home/user/.venv/lib/python3.12/site-packages/mgf
✓ py.typed marker present (downstream mypy --strict OK)
✓ [observability] extra installed (opentelemetry, sentry-sdk available)
✓ [vault] extra installed (keyring, cryptography available)
⚠ [qt] extra not installed — GUI helpers unavailable
✓ Default crash dir writable: /home/user/.local/state/myapp/crashes
✓ Default log dir writable:   /home/user/.local/state/myapp/logs
⚠ JOURNAL_STREAM env var set — journald sink would auto-attach with preset="systemd"
✓ Registered crash sinks: [local, sentry, otlp, http]
✓ Registered log handlers: [console, rotating-file, journald]
✓ Registered redaction pattern groups: [builtin]
✓ No active deprecation warnings detected in last bootstrap

Recommended actions:
  - None — all checks pass.
```

### 5.4 Implementation

`mgf-common` is a console-script entry point declared in
`pyproject.toml`:

```toml
[project.scripts]
mgf-common = "mgf.common.cli._mgfcli:main"
```

Argument parsing via `argparse` (stdlib only — no click dep on
the library itself). Subcommand dispatch is a `match` on the
parsed command name.

---

## §6. Auto-detection → presets

**Today** auto-detection is implicit: `fmt="auto"` reads
`stdout.isatty()`, journald attaches when `JOURNAL_STREAM` is
present, OTel attaches when `OTEL_EXPORTER_OTLP_ENDPOINT` is set.
Surprises consumers in non-standard environments.

**v0.3** every field has an explicit default; auto-detection is
opt-in via documented presets:

```python
class PresetName(StrEnum):
    EXPLICIT = "explicit"   # default — no auto-detection (v0.3 default)
    DEV      = "dev"        # text format, console-only, DEBUG, no remote sinks
    SYSTEMD  = "systemd"    # journald + JSON, no console
    DOCKER   = "docker"     # JSON to stdout, no file (container logs)
    AUTO     = "auto"       # legacy v0.1 behaviour (TTY-detect, journald-detect)
```

```python
MgfSettings(preset="systemd")
# Equivalent to:
MgfSettings(
    logging=LoggingSettings(
        format="json",
        journald=True,
        # console handler dropped
    )
)
```

Presets are applied **before** explicit fields, so explicit
overrides win:

```python
MgfSettings(
    preset="systemd",
    logging=LoggingSettings(level="DEBUG"),
    # → systemd preset's defaults + level="DEBUG" override
)
```

`mgf-common explain` shows the preset's contribution
explicitly:

```
[logging]
  level    INFO    (preset: systemd)
  format   json    (preset: systemd)
  ...
  level    DEBUG   (override → preset: systemd)
```

---

## §7. Versioning + migration

### 7.1 Timeline

| Release | When | Contents |
|---|---|---|
| **v0.1.0** | shipped 2026-04-22 | the current code |
| **v0.1.x** | 2026-04 → … | bug fixes only; no new features |
| **v0.3.0** | target ~2026-Q3 (TBD) | the closed-box reshape per this doc |
| **v0.3.x** | soak | bug fixes; deprecation warnings still active |
| **v0.3.0** OR direct **v1.0** | per §10 Q3 | deprecation aliases removed |
| **v1.0** | when ≥1 second consumer audited | API locked under standard SemVer rules |

### 7.2 Deprecation alias policy

Every renamed / restructured surface ships an alias that emits
`DeprecationWarning` on first use:

| v0.1 name | v0.3 alias status | Removal target |
|---|---|---|
| `mgf.common.configure(...)` | alias for `bootstrap()` (no context) | v1.0 |
| `mgf.common.observability.setup_logging(...)` | alias; deprecated | v1.0 |
| `mgf.common.observability.setup_otel(...)` | alias; deprecated | v1.0 |
| `mgf.common.observability.install_excepthook(...)` | alias; deprecated | v1.0 |
| `mgf.common.observability.install_threading_excepthook(...)` | alias; deprecated | v1.0 |
| `mgf.common.config.make_settings_config(...)` | alias for `settings_config()` | v1.0 |
| `mgf.common.exceptions.EnvironmentError` | alias for `HostEnvironmentError` | v1.0 |
| `mgf.common.app_name() / app_version()` | proxied to `current_context()` | v1.0 |

`DeprecationWarning` `stacklevel=2` so the user sees their own
call-site in the trace.

### 7.3 The codemod — `mgf-common migrate`

Console-script subcommand:

```bash
$ mgf-common migrate 0.1 0.2 src/myapp/
Scanning src/myapp/ for v0.1 patterns...
  src/myapp/cli/__main__.py:23  configure(app_name=...) → bootstrap()
  src/myapp/cli/__main__.py:24  setup_logging(level=...) → MgfSettings(logging=...)
  src/myapp/cli/__main__.py:25  setup_otel() → bootstrap()
  src/myapp/exceptions.py:7     EnvironmentError → HostEnvironmentError
  src/myapp/settings.py:12      make_settings_config(env_prefix="X_") → class kwarg

Apply changes? [y/N]
```

Implementation: [LibCST](https://libcst.readthedocs.io/) for
AST-aware rewrites. (Open question §10 Q4 — libcst vs simpler
regex.)

### 7.4 What VManager does

The reference consumer is currently pinned `>=0.1.0,<0.3`.
Migration sequence:

1. v0.3.0 ships to PyPI.
2. VManager bumps pin to `>=0.3.0,<0.3` in a branch.
3. Run `mgf-common migrate 0.1 0.2 src/`.
4. Address any deprecation warnings the codemod didn't catch.
5. Run VManager's full test suite (1900+ tests).
6. Open compliance-audit round (per the cornerstone-rhythm
   pattern in `COMMON_COMPONENTS.md`).
7. Merge, deploy, file FEEDBACK round 2 with anything that hurt.

### 7.5 What 0.1 consumers (none today, but the policy)

A 0.1 consumer reading this doc gets a clear story:

- 0.1.x stays supported for bug fixes through end-of-2026 (TBD;
  could shorten depending on 0.3.x adoption pace).
- 0.3.x is the migration target; the codemod handles ~90 % of
  renames.
- 1.0 is the lock. After 1.0, breaking changes follow the
  full deprecation cycle (rule AP-04: announce → ≥1 MINOR
  survival → MAJOR remove).

---

## §8. `SCOPE.md` — what we will NEVER ship

A new `docs/standards/SCOPE.md` document the redesign produces.
Defines what is OUT of `mgf-common`'s scope so we don't drift
into kitchen-sink-ism.

### 8.1 IN scope

`mgf-common` ships **infrastructure that every Python desktop /
service / mobile project needs once it crosses the
spike-to-production boundary**:

- Identity + lifecycle (configure once; resolve everywhere).
- Typed configuration with file + env + CLI layering.
- Typed exception hierarchy with translation seams.
- Structured logging + redaction + sinks.
- OpenTelemetry tracing / metrics integration.
- Crash reporting (local + remote).
- Excepthook installation for every entry point shape.
- Vault abstraction for secrets storage.
- Cancellation + progress primitives.
- Subprocess + SSH + service-management cross-platform wrappers
  (per FEEDBACK §3.4–§3.5).
- Resilience patterns: retry with jitter, circuit breaker.
- Cross-platform path conventions (XDG + macOS + Windows).
- A diagnostic CLI for self-introspection (§5).

### 8.2 OUT of scope (we will NOT ship these)

| Out-of-scope | Why we don't | What you should use instead |
|---|---|---|
| **GUI framework** | Domain-specific; PySide6 / Tk / Flet / Toga have non-overlapping ecosystems | Bring your own; we ship `mgf.common.gui.<framework>` adapters when a consumer needs one |
| **ORM / data layer** | Already has SQLAlchemy / SQLModel / Django / Tortoise / etc.; no value-add we can offer | SQLAlchemy is the ecosystem default |
| **HTTP server framework** | FastAPI / Flask / Litestar / Starlette / aiohttp — every shape covered | Pick one; integrate via `mgf.common.observability` for shared logging / tracing |
| **HTTP client (general-purpose)** | `httpx` is the ecosystem default; we ship `httpx` instrumentation but not our own client | `httpx` |
| **Full async runtime** | `asyncio` / `trio` / `anyio` are the language; we provide async adapters where relevant | stdlib `asyncio` (or trio via anyio shim) |
| **Cloud-provider deployment recipes** | AWS / GCP / Azure are non-overlapping; per-provider tooling exists | provider's own SDK + IaC tool |
| **AI / ML utilities** | Orthogonal domain | use the relevant ML library directly |
| **Plugin loading / discovery framework** | We use registries for OUR extensions; consumer plug-in loaders use stdlib `importlib.metadata.entry_points` | stdlib `importlib.metadata` |
| **i18n translation engine** | We provide a hook (`_localise(msg, **vars)`) per FEEDBACK §3.13; consumer brings the catalog | stdlib `gettext` |
| **Job queue / task scheduler** | Celery / RQ / arq / dramatiq cover this; we provide cancellation + progress primitives that integrate with any of them | celery / rq / etc. |
| **Database migration tool** | Alembic / aerich / etc. cover this | alembic |
| **Testing framework** | pytest is the ecosystem default; we ship pytest fixtures (FEEDBACK §3.7) | pytest |

### 8.3 Adjacent scope (we MAY ship later, requires consumer demand)

- **OpenAPI generation from typed Settings.** Could lift the
  `BaseAppSettings` schema as an OpenAPI components schema for
  HTTP servers using our config. Wait for a consumer to ask.
- **Conda-forge / Homebrew packaging** (FEEDBACK §8.1). When
  ≥10 % of consumer demand lives outside PyPI.
- **Containerised base image** (FEEDBACK §8.2). When the
  release cadence stabilises post-1.0.

### 8.4 The "scope creep" review question

Every PR that adds a new module or top-level function MUST
answer: *"Is this in §8.1 IN scope, in §8.3 adjacent, or in §8.2
OUT?"* If the answer is "out", the PR is rejected with a pointer
to the existing ecosystem solution.

---

## §9. Phasing — implementation order

The reshape is a multi-commit effort. Each phase ships
independently, in this order, so the project is always
releasable mid-flight.

### Phase 1 — Settings root + bootstrap (the foundation)

**~1 substantial commit, ~600 lines code + 300 lines tests +
docs.**

- `src/mgf/common/settings.py` — new `MgfSettings` schema with
  sub-models (`LoggingSettings`, `OtelSettings`, `CrashSettings`,
  `RedactionSettings`).
- `src/mgf/common/_lifecycle.py` — `AppContext` + `bootstrap` +
  `current_context` + `shutdown`.
- Deprecate `configure()` (alias to `bootstrap()` without
  context); deprecate `setup_logging`, `setup_otel`,
  `install_excepthook`, `install_threading_excepthook`.
- `mgf.common.bootstrap` becomes the documented entry point in
  README + examples.
- AP-10 PUBLIC_API.md updated; pin tests pass.

### Phase 2 — Closed-box wraps

**~1 substantial commit.**

- `mgf.common.config` re-exports pydantic primitives (`Field`,
  `BaseModel`, `ConfigDict`, `AliasChoices`,
  `field_validator`, `model_validator`, `ValidationError`).
- `mgf.common.observability` adds `get_logger`, `Span`,
  `SpanStatus`, `get_current_span`, `set_attribute`,
  `set_status`, `add_event`.
- `BaseAppSettings.__init_subclass__` accepts kwargs (closes
  API-06 Option A).
- `EnvironmentError` → `HostEnvironmentError` rename (closes
  API-01).
- `to_yaml_dict` shallow-recursion fix (closes CB-06).

### Phase 3 — Registries

**~1 commit.**

- `register_crash_sink` + `register_log_handler` +
  `register_redaction_pattern_group` + `register_span_processor`
  + `register_vault_backend` decorators.
- Refactor existing builtin sinks / handlers / patterns to use
  the registries.
- Closes API-07 + sets up extensibility for §3.10 §3.11
  consumer needs.

### Phase 4 — Cancellation + Progress + Protocols

**~1 commit.**

- `mgf.common.progress` lift from VManager.
- `mgf.common.progress.asyncio` adapter.
- `mgf.common.typing` Protocol module.
- Closes API-03 + API-05.

### Phase 5 — Vault + CLI helpers

**~1 commit.**

- `mgf.common.vault` (`VaultProtocol` + `KeyringVault` +
  `EncryptedFileVault` + `EnvVault`).
- `mgf.common.cli` (`EXIT_*` + `run_and_translate` +
  `@translate_exceptions`).
- Closes FEEDBACK §3.2 + §3.8.

### Phase 6 — Diagnostic CLI + presets + SCOPE.md

**~1 commit.**

- `mgf-common` console-script with `explain / validate /
  doctor` subcommands.
- `MgfSettings.preset` + the four preset shapes
  (explicit / dev / systemd / docker / auto).
- `docs/standards/SCOPE.md` ships.

### Phase 7 — Codemod + migration docs

**~1 commit.**

- `mgf-common migrate 0.1 0.2 <path>` subcommand.
- `docs/MIGRATION_0.1_TO_0.2.md` consumer-facing guide.
- VManager integration test (run codemod against VManager source;
  assert no manual edits required for the mechanical changes).

### Phase 8 — Release v0.3.0

**Coordinated.**

- Bump `__version__` and `pyproject.toml::version`.
- CHANGELOG entry summarising the reshape (move
  `[Unreleased]` → `[0.3.0]`).
- Manual `twine upload` per `docs/CLAUDE.md` §"Build and release".
- Tag + push to Codeberg.
- Update VManager's pin in a separate PR.
- Open FEEDBACK round 2 against the new shape.

### Estimated total

~7 substantial commits over multiple sessions. Each commit is
independently reviewable. The library is releasable after
each phase (every phase preserves backward compat).

---

## §10. Open questions

Decisions still needed from you before implementation begins.
Each has a recommendation; you can override.

### Q1 — Lifecycle function name: `bootstrap` vs `app_lifecycle` vs `Application(...)`?

- **`bootstrap(...)`** — short, idiomatic, what most Python
  libraries call this.
- **`app_lifecycle(...)`** — what FEEDBACK §3.10 originally
  proposed; descriptive but verbose.
- **`Application(...)` class** — Flask / FastAPI shape; carries
  state + has methods.

**Recommendation:** **`bootstrap`** (matches industry idioms;
short; the result is an `AppContext` with methods if needed).

### Q2 — Settings root name: `MgfSettings` vs `Common` vs `Mgf` vs `Settings`?

- **`MgfSettings`** — explicit, namespaced.
- **`Settings`** — collides with consumers' own `Settings`
  classes.
- **`Mgf`** / **`Common`** — too generic.

**Recommendation:** **`MgfSettings`** with documentation that
consumers compose it under their own root if they want
(`class AppSettings(BaseAppSettings): mgf: MgfSettings = ...`).

### Q3 — When are deprecation aliases removed?

- **0.3.0** — short deprecation cycle; faster path to lock-in;
  may force consumers to migrate twice.
- **1.0** — long cycle; consumers migrate once.
- **Hybrid** — soft removal in 0.3 (warnings escalate to
  `FutureWarning`), hard removal in 1.0.

**Recommendation:** **Aliases survive through entire 0.x; hard
removal at 1.0**. One migration per consumer; no forced churn.

### Q4 — Codemod implementation: LibCST / regex / semgrep?

- **LibCST** — AST-aware, handles multi-line / commented code
  cleanly. Heavyweight dep.
- **regex** — simpler; brittle on edge cases.
- **semgrep** — AST-aware; external tool dep.

**Recommendation:** **LibCST**. Bundled into a `[migrate]` extra
so the dep doesn't pollute the default install.

### Q5 — Multi-tenancy mechanism: contextvar / threading.local / explicit-arg?

Per FEEDBACK §6 Option C: hybrid.

- **`contextvars.ContextVar`** — async-safe + thread-safe with
  proper context-copying. Works with `asyncio.to_thread`,
  `run_in_executor`, etc.
- **`threading.local`** — thread-only; breaks under asyncio.
- **explicit context arg** — every observability function takes
  `ctx=...`; verbose.

**Recommendation:** **contextvars** (with module-level globals as
the fallback for non-context callers).

### Q6 — CLI subcommand: `mgf-common` vs `python -m mgf.common.cli`?

- **`mgf-common`** console-script — discoverable via `which`,
  appears in tab-complete.
- **`python -m mgf.common.cli`** — always available without
  `pip install`'s `[project.scripts]` step.

**Recommendation:** **Both**. Single `main()` function in
`mgf.common.cli._mgfcli`; the console-script entry point AND
the `__main__` of the module both call it.

### Q7 — Crash sinks: ship Slack / PagerDuty in core or only the registry?

- **Ship in `[crash-sinks]` extra** — `pip install mgf-common[crash-sinks]`
  pulls Slack-SDK / PagerDuty-SDK / etc.
- **Registry only** — consumers register their own; we ship
  only the four builtins.

**Recommendation:** **Registry only for now**. Adding
specific-vendor sinks pulls vendor SDKs; rather than picking
favourites, let consumers register. We document the recipe
(template `register_crash_sink("slack", ...)`) in the
crash-reporter docs.

### Q8 — Logger wrapper class (`SafeLogger` vs `logging.Logger`)?

`get_logger()` returns either:

- A **plain `logging.Logger`** (simple, interoperable, no
  `name`-collision protection — relies on the LOGGING.md §12.1
  documentation).
- A **`SafeLogger` wrapper** that intercepts and rejects
  reserved-name `extra={...}` collisions with a typed error
  (closes CB-10 mechanically).

**Recommendation:** **`SafeLogger` wrapper** — the wrapper IS
the closed-box value. It's a proxy that delegates everything to
the underlying `logging.Logger` except `_log()` where it does
the pre-flight check. Interoperability with stdlib stays
because `SafeLogger` IS a `logging.Logger` subclass.

### Q9 — Async: ship `mgf.common.progress.asyncio` in 0.2 or 0.3?

- **0.2** — full async story from day one. Doubles the test
  surface; some risk of API drift before the first async
  consumer arrives.
- **0.3** — sync-only progress in 0.2; async adapter when a
  consumer asks.

**Recommendation:** **0.2**. The async adapter is small
(<200 lines); shipping it upfront prevents the API from
solidifying around sync-only assumptions.

### Q10 — Backward-compat shim: `vmanager.observability` style for our own aliases?

The deprecated names (`configure`, `setup_logging`, etc.) — do
they live:

- **In the same module** as the new names with a `DeprecationWarning`
  emitted on call.
- **In a `mgf.common.compat.v01` submodule** — explicit
  "you're using the old shape" namespace; cleaner separation.

**Recommendation:** **Same module + warning**. The migration
codemod handles the rewrite; once a consumer migrates, the old
names are gone from their source. No need for a separate
namespace.

### Q11 — Bootstrap rollback: best-effort or all-or-nothing? (§14.2)

When bootstrap fails partway and rollback closures themselves
fail (e.g., a log handler's close() raises), what do we do?

- **Suppress and continue** the rollback (log to stderr, accept
  some leakage). This is the `BootstrapError` path's current
  proposal: `with contextlib.suppress(Exception): rollback()`.
- **Stop on first rollback failure** and raise a wrapped
  `RollbackError` listing both the original cause AND the
  rollback failure.

**Recommendation:** **Suppress and continue.** The user already
has the `BootstrapError` with the original cause; doubling up on
errors doesn't help them. Rollback failures are logged to stderr
(best-effort visibility) and we move on to the next rollback.

### Q12 — `bootstrap_for_test` capture defaults: all-on or opt-in? (§14.8)

The test-isolation API has `capture_logs / capture_spans /
capture_crashes` flags.

- **Default ALL-ON** — every test gets all three capture
  buffers. Simple. ~1-2 KB per test of memory.
- **Default OPT-IN** — tests must enable what they assert against;
  saves memory but adds boilerplate.

**Recommendation:** **Default ALL-ON.** The buffers are tiny; the
ergonomic win is real. Add a perf-test override
(`bootstrap_for_test(capture_logs=False)`) for benchmarks.

### Q13 — Closed-box compliance test: blocking or advisory? (§14.11)

The `test_closed_box.py` violation count.

- **Hard fail** — any new violation fails CI. Pure ratchet.
- **Soft track** — violations counted in CI output; not failing.
  Trend reviewed in `STANDARDS_COMPLIANCE.md` per release.

**Recommendation:** **Soft track for 0.3, hard fail at 1.0.** A
hard fail in 0.3 risks blocking legitimate PRs while we discover
which violations are real vs allowlist-needed. Once the
allowlist stabilises (a few cycles), flip to hard fail.

### Q14 — `RuntimeCounters` storage: lock-free or locked? (§14.7)

Internal counters incremented on the hot path.

- **`itertools.count()` + `__next__` thread-safe by GIL** — fast
  on CPython, breaks on free-threaded Python (PEP 703 / 3.13t).
- **`threading.Lock` per counter** — slow but correct everywhere.
- **`atomic` library** (vendored) — fast + correct everywhere;
  small dep.

**Recommendation:** **Use `threading.Lock` for now (simple, correct,
~30 ns overhead).** Revisit if free-threaded Python adoption
makes the simple path too slow. Document the choice in the
threading-model table (§14.9).

### Q15 — Reload atomicity: pause traffic during reload? (§14.5)

`AppContext.reload()` re-applies wiring. During the reload
window (a few ms), what about in-flight log records / spans?

- **Pause** — internal lock blocks the hot-path APIs during
  reload; backed-up records spike briefly.
- **Don't pause** — accept that records during the window may
  land in the OLD or NEW pipeline (transient inconsistency).

**Recommendation:** **Don't pause.** Reload is rare (operator
SIGHUP); the inconsistency window is a few ms. Pausing would
mean every log call needs to acquire the reload lock — that's
budget breach across the whole hot path. Document the trade-off.

---

## §11. Risks

Honest enumeration of what could go wrong.

### 11.1 Migration friction for VManager

**Risk.** The codemod misses a pattern; VManager's migration
takes longer than expected.

**Mitigation.** Phase 7 includes "run codemod against VManager
source; assert no manual edits required for the mechanical
changes". If we can't pass that gate, the codemod isn't done.

### 11.2 Deprecation-warning fatigue

**Risk.** Consumers see dozens of deprecation warnings on
upgrade and turn them off (or pin back to 0.1).

**Mitigation.** The codemod handles ~90 % of renames. The
remaining warnings cluster around 3–4 specific patterns we
document explicitly in `MIGRATION_0.1_TO_0.2.md`. We enable
warnings only at INFO-equivalent (not stderr-spam).

### 11.3 Performance regression from the closed-box wraps

**Risk.** `get_logger` adds a function-call layer; `set_attribute`
wraps a span lookup; the per-record cost creeps over the LG-12
budget.

**Mitigation.** The LG-12 benchmark test
(`tests/unit/test_logging_perf.py`) catches it in CI. Wrappers
are inlinable / tiny; the call-graph overhead should be <5 %
worst-case.

### 11.4 The wrap-everything trap

**Risk.** "Closed box" pulls us into wrapping more and more
stdlib types. Over a year, `mgf.common.io` and `mgf.common.collections`
appear; the library bloats.

**Mitigation.** §2.6 ("What this is NOT") + §8 SCOPE.md +
the §2.4 PR review question. Every wrap addition has to pass
"is this part of `mgf-common`'s domain?" Stdlib `Path` /
`datetime` / `dict` are language-universal and stay un-wrapped.

### 11.5 Multi-tenancy contextvar performance

**Risk.** Every observability call now does a `ContextVar.get()`
in the hot path — measurable cost in tight loops.

**Mitigation.** The fast path (no AppContext active) returns
the module-level globals via a single `if context is None`
check. Measured cost: <100 ns per call. Within budget.

### 11.6 The "second consumer" assumption

**Risk.** We design for a hypothetical second consumer that may
never arrive. The 0.2 reshape is over-engineered for
single-consumer reality.

**Mitigation.** Per FEEDBACK §7 meta-feedback #2: don't lock 1.0
until a second consumer audits. If after the 0.2 soak no
second consumer materialises, we reassess. The reshape is
beneficial even with one consumer (clearer API, less foot-gun);
the multi-tenancy specifically is the hedge.

### 11.7 Naming bikeshed

**Risk.** Names debate (Q1, Q2 in §10) consumes more time than
the implementation.

**Mitigation.** Pick names per the recommendations; bikeshed
later if a real complaint surfaces in soak.

### 11.8 Hidden-behaviour debt before the redesign

**Risk.** v0.1's auto-detection (TTY, JOURNAL_STREAM, OTEL
endpoint) is in production at consumers; switching to explicit
defaults breaks something silently.

**Mitigation.** The `auto` preset preserves v0.1 behaviour.
Migration doc clearly says: "if you didn't change any settings
in v0.1, set `MgfSettings(preset='auto')` in v0.3 to preserve
the same shape; explicit defaults take effect when you don't
set the preset."

### 11.9 Codemod scope creep

**Risk.** Once we have a codemod, every future breaking change
is "just add a codemod step". The library's API churn looks
deceptively cheap.

**Mitigation.** Codemods are the migration tool, not the API
churn license. Post-1.0 the deprecation cycle is the rule
(rule AP-04: ≥1 MINOR survival). Codemods help during cycles,
not instead of them.

### 11.10 Bootstrap rollback paths grow with every wired subsystem

**Risk.** Today bootstrap wires 6 subsystems; the rollback
stack has 6 closures. Add SSH, vault, metrics, retry, → 10+
subsystems → 10+ rollback closures. Each closure is its own
failure surface.

**Mitigation.** Each subsystem MUST ship its `_unwire_*`
helper alongside its `_wire_*` helper as a load-bearing
invariant. Bootstrap pin tests verify every subsystem can be
wired AND unwired in any order. PR template asks "did you ship
both _wire and _unwire?" for new wiring.

### 11.11 Multi-tenancy span attributes don't survive remote propagation

**Risk.** §14.4 adds `tenant.app_name` as a span attribute via
the `_AppContextSpanProcessor`. Span attributes propagate
in-process but **NOT** across the wire (HTTP headers, gRPC
metadata) — only the span context (trace_id, span_id) does. A
tenant-A span calls a downstream service; the downstream span
has no tenant attribute.

**Mitigation.** Two options. (a) Add `tenant.app_name` to OTel
baggage instead of (or in addition to) span attributes —
baggage propagates wire-side. Cost: baggage is an opt-in OTel
feature; not all backends support it. (b) Document the
limitation and provide a `bagged_context()` helper that copies
`tenant.*` to baggage when crossing a request boundary. **Pick
in implementation; document in v0.3.**

### 11.12 Hot-reload + in-flight resources

**Risk.** §14.5 reloads settings. If a log handler is in the
middle of writing a record when reload swaps it out, the
record lands in /dev/null OR the partial-write corrupts the
file.

**Mitigation.** The internal reload lock holds while
`logging.root.handlers` is mutated. Existing handlers' threads
finish their current emit before the lock is acquired. The
worst case is a few ms of contention on the root logger — well
under the LG-12 budget for cold starts but visible at hot-path
peak. Document in the §14.9 threading model.

### 11.13 GDPR strict-mode false positives degrade log quality

**Risk.** §14.12 strict mode adds `email` / `ipv4` / `phone`
patterns. UUIDs may match the IPv6 pattern; some product SKUs
match the SSN pattern. Operators turn on strict mode; their
logs become a sea of `[REDACTED]`; debugging gets harder.

**Mitigation.** Document the trade-off prominently in the
opt-in path. `mgf-common explain` lists the strict-mode pattern
groups; operators can selectively disable a noisy one. Add a
`strict_mode_excluded_patterns` field to `RedactionSettings` so
the toggle is per-pattern, not all-or-nothing.

### 11.14 The "soft track" closed-box test becomes wallpaper

**Risk.** §14.11 + §10 Q13: closed-box compliance starts as
"soft track". Without a forcing function, the violation count
can creep up indefinitely. The soft track becomes wallpaper;
no one notices until 1.0 hard-fail breaks dozens of legitimate
patterns.

**Mitigation.** Per-release review of the violation delta.
`STANDARDS_COMPLIANCE.md` §3 (closed-gaps history) gains a row
per release: "closed-box violations: N (delta: +0 / +1 / -2)".
Trend > 0 over 2 releases triggers a sweep PR.

### 11.15 Single-binary smoke test is too expensive for CI

**Risk.** §14.17 mentions "build a sample app under PyInstaller
in CI". That's a 5-10 min job step. Adding it to every PR
would 2x CI time.

**Mitigation.** Run the PyInstaller smoke only on `main` push +
on tag, not per-PR. Document in `.woodpecker.yml` rationale.
Failure on `main` opens a follow-up; doesn't block the PR that
caused it.

---

## §12. Cross-references

- The standing direction this redesign implements: [`docs/CLAUDE.md`](CLAUDE.md)
  §"Closed-box interface principle".
- The consumer feedback this redesign closes: [`FEEDBACK.md`](../FEEDBACK.md)
  (API-01, API-02, API-03, API-05, API-06, API-07; the §3.* roadmap
  items).
- The standards every closed-box surface implements: [`docs/standards/`](standards/).
- The compliance tracker that will gain rows for the new closures:
  [`docs/STANDARDS_COMPLIANCE.md`](STANDARDS_COMPLIANCE.md).
- The contract list that grows with the reshape:
  [`PUBLIC_API.md`](../PUBLIC_API.md).

---

## §13. Principal-engineer review — round 2 additions

Second pass on the spec, deliberately senior in posture. The
goal: surface every load-bearing concern that round 1 missed,
because we said this is the last shot to redesign before the
library locks in. **Each subsection here adds a CB-* item,
revises an open question, OR codifies a decision that round 1
left implicit.**

The 19 additions below are clustered into:

- **Architectural correctness** (§14.1–§14.5) — async/sync,
  bootstrap atomicity, multi-tenancy + OTel, hot reload.
- **Operational completeness** (§14.6–§14.10) — per-component
  level overrides, self-observation, test isolation, threading
  model, idempotency.
- **Discipline + future-proofing** (§14.11–§14.19) — automated
  closed-box test, GDPR mode, schema versioning, performance
  budgets, env-var namespace, single-binary, file formats,
  promotion criteria, migration default.

When commenting, use `§14.<n>` as the anchor.

---

### §14.1 Async-first vs sync-first — explicit position (NEW DECISION)

**Round 1 left this implicit.** §4.8 mentioned "async adapter at
`mgf.common.progress.asyncio`" without saying whether `mgf-common`
is sync-first-with-async-adapters or async-first-with-sync-shims
or true sync/async parity (httpx-style). For a library that will
grow, this decision compounds.

**Decision: sync-first; async ships as a sibling adapter
submodule per area.**

Reasoning:

- The dominant `mgf-common` consumer profile is desktop GUI / CLI
  / service that talks to the OS (libvirt, paramiko, subprocess,
  keyring) — sync APIs everywhere downstream. Async-first would
  force these into bridges they don't need.
- True parity (httpx-style sync + async surfaces) is a 2× test
  surface and a 2× docs surface. Maintenance multiplied;
  consumer mental model doubled.
- Async consumers (FastAPI services, async crawlers) get a thin
  adapter per area — the surface is small because async needs
  fewer features (no GUI threading bridge, no QThread workers).

**Concrete rule:** every new module ships sync. If the area has
genuine async semantics (cancellation, IO, queues), an
`<area>.asyncio` sibling submodule ships at the same time. The
async surface is **a thin shim**, never a full duplicate API.

| Module | Sync (default) | Async sibling |
|---|---|---|
| `mgf.common.progress` | `CancellationToken`, `ProgressReporter` | `mgf.common.progress.asyncio` — `AsyncCancellationToken` |
| `mgf.common.vault` | `VaultProtocol` (sync) | not shipped until a consumer asks |
| `mgf.common.ssh` (future) | `SSHClient` (sync) | `mgf.common.ssh.asyncio` (lift only when asked) |

**Adds CB-24** (async-first vs sync-first not declared).

---

### §14.2 Bootstrap atomicity — transactional setup with rollback

**Round 1 missed this.** §4.1 specified `bootstrap()` as a
context manager that wires logging → OTel → excepthooks → ... in
order. **What if step 3 fails?** Today's design leaves the
process in a half-wired state: logging is configured, OTel is
not, excepthooks are not. Subsequent code that emits an
exception sees no crash report, no OTel span — silent failure
mode in the most operationally-critical surface of the library.

**Design: bootstrap is transactional.** Every internal step
appends a rollback closure to a stack. On any failure, the stack
is unwound (LIFO), the partial wiring is reversed, and a typed
`BootstrapError(AppError)` is raised carrying the failed step
name + the original cause via `from`.

```python
class BootstrapError(AppError):
    """Bootstrap failed mid-wiring. Process state is unchanged
    from before bootstrap() was called.

    Carries .failed_step (str: which step failed) and chains the
    original exception via __cause__. The application MUST NOT
    proceed — partial state would surface failures later in
    confusing ways.
    """
    def __init__(self, failed_step: str, *, cause: BaseException) -> None:
        self.failed_step = failed_step
        super().__init__(
            f"bootstrap failed at step {failed_step!r}: {cause}; "
            f"the library is uninitialised. Fix the cause and retry."
        )
```

```python
@contextmanager
def bootstrap(...) -> Iterator[AppContext]:
    rollbacks: list[Callable[[], None]] = []
    try:
        ctx = _wire_settings(settings); rollbacks.append(_unwire_settings)
        _wire_identity(app_name, app_version, ctx); rollbacks.append(_unwire_identity)
        _wire_logging(ctx); rollbacks.append(_unwire_logging)
        _wire_otel(ctx); rollbacks.append(_unwire_otel)
        _wire_excepthooks(ctx); rollbacks.append(_unwire_excepthooks)
        _wire_crash_sinks(ctx); rollbacks.append(_unwire_crash_sinks)
    except BaseException as e:
        for rollback in reversed(rollbacks):
            with contextlib.suppress(Exception):
                rollback()
        raise BootstrapError(_current_step, cause=e) from e

    try:
        yield ctx
    finally:
        for rollback in reversed(rollbacks):
            with contextlib.suppress(Exception):
                rollback()
```

**Pin test** (rule TS-09 best-effort observer extended):

```python
def test_bootstrap_failure_rolls_back_partial_state(monkeypatch):
    # Inject a failure at the OTel step
    monkeypatch.setattr("mgf.common._lifecycle._wire_otel", _raise)
    with pytest.raises(BootstrapError) as exc_info:
        with bootstrap(app_name="test", app_version="0.0"):
            ...
    assert exc_info.value.failed_step == "otel"
    # Logging handlers MUST NOT be left attached to root logger
    assert logging.root.handlers == []
    # OTel TracerProvider MUST be the no-op (not our partially-wired one)
    assert isinstance(trace.get_tracer_provider(), trace.ProxyTracerProvider)
```

**Adds CB-25** (no atomic bootstrap; partial-state failure mode).

---

### §14.3 Bootstrap-time logging — deferred replay buffer

**Round 1 missed this.** Bootstrap is the FIRST thing called.
Logging is wired AS PART OF bootstrap. So how does `_wire_otel`
log "OTel exporter not reachable, disabling" — logging isn't
configured yet when this happens.

Today's hidden behaviour: `logging.warning(...)` falls back to
the root logger's `lastResort` handler (stderr at WARNING+).
This works but is implicit and hard to explain to consumers.

**Design: a `_BootstrapLogBuffer` captures everything emitted
from inside bootstrap, replays it through the configured
handlers once `_wire_logging` succeeds.** If bootstrap fails
before `_wire_logging`, the buffer flushes to stderr.

```python
class _BootstrapLogBuffer(logging.Handler):
    """In-memory handler installed at bootstrap entry, removed
    once the real handlers are wired. Captures every record
    emitted during bootstrap and replays it through the wired
    handlers once available.

    On bootstrap FAILURE, flushes the buffer to stderr (best-
    effort) so the operator sees what happened before the
    BootstrapError is raised.
    """
    def __init__(self) -> None:
        super().__init__(level=logging.DEBUG)
        self._records: list[logging.LogRecord] = []

    def emit(self, record: logging.LogRecord) -> None:
        self._records.append(record)

    def replay_to(self, target_handlers: list[logging.Handler]) -> None:
        for record in self._records:
            for h in target_handlers:
                if record.levelno >= h.level:
                    h.handle(record)

    def flush_to_stderr(self) -> None:
        for record in self._records:
            sys.stderr.write(self.format(record) + "\n")
```

The buffer is wired at bootstrap entry; replayed at the end of
`_wire_logging`; removed from the root logger after replay. No
records are lost, no records are duplicated.

**Adds CB-26** (no story for logging during bootstrap itself).

---

### §14.4 Multi-tenancy + OTel — per-AppContext attributes via processor (REVISES §4.4)

**Round 1 papered over this.** §4.1 specified hybrid `AppContext`
with contextvar-based per-tenant identity. §4.4 wraps OTel.
**But OpenTelemetry's `TracerProvider` has ONE resource
per process** — `service.name` is set once at provider
construction. If contextvar gives us per-tenant `app_name`, the
resource doesn't follow. Spans from plug-in X land under
plug-in Y's `service.name`. Silent breakage.

**Design: TracerProvider has a single fixed `service.name` (the
bootstrap's `app_name`); per-AppContext attributes are added at
span-start via a custom span processor.**

```python
class _AppContextSpanProcessor(SpanProcessor):
    """Stamps the active AppContext's tenant attributes onto
    every span at start time. Standard OTel pattern for
    multi-tenant services.

    Adds attributes:
      - tenant.app_name    — current_context().app_name
      - tenant.app_version — current_context().app_version

    These are STANDARD OTel resource-vs-span-attribute discipline:
    the `service.name` resource attribute is process-global; the
    tenant.* span attributes are per-operation. Backends (Jaeger,
    Tempo, Datadog) all support filtering / grouping by both.
    """
    def on_start(self, span: Span, parent_context: Context | None) -> None:
        ctx = current_context()
        if ctx is None or ctx.app_name == _bootstrap_app_name:
            return
        span.set_attribute("tenant.app_name", ctx.app_name)
        span.set_attribute("tenant.app_version", ctx.app_version)
```

This processor is registered automatically at bootstrap when
multi-tenancy is detected. No consumer code changes.

**Documentation MUST say:** `service.name` reflects the bootstrap
identity (not the active AppContext's). Use `tenant.*` attributes
for per-tenant filtering. This is the OTel-native pattern.

**Adds CB-27** (multi-tenancy + OTel resource collision).
**Revises §10 Q5** (multi-tenancy mechanism — refines the
contextvar choice with the OTel reality).

---

### §14.5 Settings hot-reload — programmatic API

**Round 1 missed this.** Long-running services (daemons,
schedulers, web servers) need to change log level / OTel sampling
without restarting. The standard pattern is SIGHUP → reload
config file. Round 1's `MgfSettings` is loaded once at bootstrap;
no story for re-loading.

**Design: `AppContext.reload(new_settings)` re-applies the
wiring with new settings. Atomic (same try/except + rollback as
bootstrap).** Consumers wire SIGHUP / inotify / polling
themselves — those are application-level concerns; the library
provides the safe primitive.

```python
class AppContext:
    def reload(self, new_settings: MgfSettings) -> None:
        """Re-apply the wiring with new settings. Atomic — on
        failure, the old wiring is preserved and BootstrapError
        is raised.

        Preserves the AppContext identity (app_name, app_version
        cannot change post-bootstrap; see §14.4 for why). Only
        settings sub-models (logging, otel, crash, redaction)
        actually re-apply.

        Thread-safe: holds an internal lock during reload so a
        second reload from another thread waits.
        """
```

**Consumer-side SIGHUP handler shape (in CLI helpers):**

```python
import signal
from mgf.common.cli import on_sighup_reload_config

@on_sighup_reload_config(config_path="~/.config/myapp/config.yaml")
def _post_reload(ctx: AppContext, new_settings: MgfSettings) -> None:
    """Optional callback after a successful reload."""
    LOG.info("config reloaded; new log level: %s", new_settings.logging.level)
```

The decorator wires `signal.SIGHUP`; the body re-loads the file,
constructs `MgfSettings`, calls `ctx.reload(...)`. Failure is
logged but doesn't crash the service.

**Adds CB-28** (no hot-reload story for long-running services).

---

### §14.6 Per-component logging level overrides — first-class

**Round 1 buried this.** A consumer wants `DEBUG` for
`mgf.common.observability` only, `INFO` everywhere else. Today
they `import logging; logging.getLogger("mgf.common.observability").setLevel(logging.DEBUG)`.
That's a closed-box leak (CB-08).

**Design: first-class field on `LoggingSettings`.**

```python
class LoggingSettings(BaseModel):
    level: LogLevel = "INFO"
    level_overrides: dict[str, LogLevel] = Field(default_factory=dict)
    """Per-logger-name level overrides. Logger name is the
    canonical hierarchical path (e.g., "mgf.common.observability"
    or "urllib3"). Overrides apply on top of the global `level`.
    """
```

Applied during `_wire_logging` (set-and-forget) AND on `reload()`.

```python
# Quiet a chatty third-party + verbose for our own:
MgfSettings(logging=LoggingSettings(
    level="INFO",
    level_overrides={
        "mgf.common.observability": "DEBUG",
        "urllib3.connectionpool": "WARNING",
        "asyncio": "ERROR",
    },
))
```

`mgf-common explain` shows the active overrides:

```
[logging]
  level                 INFO       (default)
  level_overrides:
    mgf.common.observability       DEBUG     (config)
    urllib3.connectionpool          WARNING   (config)
    asyncio                         ERROR     (config)
```

**Adds CB-29** (per-component log level requires stdlib leak).

---

### §14.7 Library self-observation — internal counters

**Round 1 missed this entirely.** The library is observability
infrastructure; it should observe itself. Internal counters:
log records emitted, spans created, crash reports written,
redaction matches, bootstrap reloads. Without these, consumers
can't build dashboards on the library's own behaviour.

**Design: counters exposed two ways.**

1. **`mgf-common explain --runtime`** prints them as a table.
2. **OTel meter** when `MgfSettings.otel.metrics_enabled = True`
   exports them as `mgf_common.*` metrics.

```python
# src/mgf/common/_telemetry.py — internal counters
@dataclass
class _RuntimeCounters:
    log_records_emitted: int = 0
    log_records_dropped_rate_limit: int = 0
    log_records_dropped_dedup: int = 0
    spans_started: int = 0
    spans_ended: int = 0
    crash_reports_written: int = 0
    crash_sinks_invoked: dict[str, int] = field(default_factory=dict)
    crash_sink_failures: dict[str, int] = field(default_factory=dict)
    redaction_matches_by_pattern: dict[str, int] = field(default_factory=dict)
    bootstrap_reloads: int = 0
```

Counters incremented on the hot path (atomic int operations;
zero allocation; <10 ns per increment). When metrics are
disabled, the counters are still maintained — `mgf-common explain`
always reads them.

**`mgf-common explain --runtime` sample output:**

```
[runtime] (since bootstrap; uptime 47m)
  log_records_emitted                     12,847
  log_records_dropped_rate_limit          0
  log_records_dropped_dedup               0
  spans_started                           892
  spans_ended                             892
  crash_reports_written                   2
  crash_sinks_invoked:
    local                                 2
    sentry                                2
  crash_sink_failures:
    sentry                                1     (last: 2026-04-26T09:12:01Z)
  redaction_matches_by_pattern:
    builtin/Bearer                        14
    builtin/JWT                           3
    builtin/openai                        1
  bootstrap_reloads                       0
```

**Adds CB-30** (no library self-observation; consumers can't
dashboard the library itself).

---

### §14.8 Test isolation API — `mgf.common.testing.bootstrap_for_test`

**Round 1 mentioned `mgf.common.testing` (FEEDBACK §3.7) but
didn't design the surface.** A senior consumer will look at the
redesign and ask: "How do I write a test that exercises my code
with a clean `mgf-common` state?" Today this is "manage 5 fixtures
per consumer".

**Design: a single context manager that gives the consumer a
clean isolated environment AND assertion helpers.**

```python
# src/mgf/common/testing/__init__.py
@contextmanager
def bootstrap_for_test(
    *,
    app_name: str = "test",
    app_version: str = "0.0.0",
    settings: MgfSettings | None = None,
    capture_logs: bool = True,
    capture_spans: bool = True,
    capture_crashes: bool = True,
) -> Iterator[TestContext]:
    """Replace bootstrap() in tests. Self-contained, isolated,
    with a TestContext that exposes assertion helpers.

    Disk side-effects land in a TemporaryDirectory.
    Log handlers / OTel TracerProvider / sys.excepthook are
    save-and-restored.
    """

class TestContext(AppContext):
    """AppContext extension for tests."""

    def assert_log_contains(
        self, message: str, *, level: LogLevel | None = None,
    ) -> logging.LogRecord:
        """Assert a log record matching `message` was emitted
        (substring match). Returns the matching record."""

    def assert_no_log_at_level(self, level: LogLevel) -> None:
        """Assert no records at `level` or above were emitted."""

    def assert_span_emitted(
        self, name: str, *, attributes: dict[str, Any] | None = None,
    ) -> ReadableSpan:
        """Assert a span with `name` was emitted; if `attributes`
        is given, assert each kv matches. Returns the span."""

    def assert_no_crash_reports(self) -> None: ...

    def assert_crash_report(
        self, *, exception_type: type[BaseException] | None = None,
    ) -> dict[str, Any]: ...

    def captured_logs(self) -> list[logging.LogRecord]: ...
    def captured_spans(self) -> list[ReadableSpan]: ...
    def captured_crashes(self) -> list[Path]: ...

    def reset(self) -> None:
        """Clear captured logs/spans/crashes between sub-tests
        within the same context."""
```

```python
# Consumer test:
def test_widget_creation_logs_correctly():
    with bootstrap_for_test() as ctx:
        create_widget("alpha")
        ctx.assert_log_contains("widget created", level="INFO")
        ctx.assert_span_emitted("widget.create", attributes={"name": "alpha"})
        ctx.assert_no_crash_reports()
```

**Adds CB-31** (no first-class test isolation API; every
consumer rolls their own).

---

### §14.9 Threading model — documented per subsystem

**Round 1 missed this entirely.** A library used in every
project MUST document threading guarantees per public API.
Without them, consumers either over-lock (perf cost) or under-lock
(correctness bug).

**Design: every public function/class carries a docstring tag.**

```
Threading: thread-safe          # safe to call from multiple threads concurrently
           single-threaded      # MUST be called from one thread; typically bootstrap-time
           lock-protected       # internally locks; no caller lock needed
           re-entrant           # safe to call from a callback of itself (e.g., logging from a log handler)
```

| Surface | Threading model |
|---|---|
| `bootstrap()` | single-threaded — call from main thread before workers spawn |
| `current_context()` | thread-safe — reads contextvar |
| `AppContext.reload()` | lock-protected — internal lock serialises reloads |
| `AppContext.shutdown()` | single-threaded — call from main thread after workers join |
| `get_logger()` | thread-safe |
| `LOG.info() / LOG.exception()` | thread-safe (stdlib logging is) |
| `operation_span()` | thread-safe |
| `set_attribute()` / `add_event()` | thread-safe (OTel SDK is) |
| `report_now()` | thread-safe (atomic writes) |
| `register_crash_sink()` | single-threaded — call at module import / bootstrap-time |
| `register_log_handler()` | single-threaded — same |
| `Redactor.redact()` | thread-safe (frozen dataclass; no internal state) |
| `MgfSettings(...)` construction | thread-safe (frozen) |
| `Vault.get()/set()/delete()` | depends on backend — KeyringVault: lock-protected; FileVault: lock-protected (file lock) |
| `CancellationToken.cancel() / .is_cancelled()` | thread-safe (atomic flag) |

**Pin test:** for every API marked `thread-safe`, a test spawns
N threads calling it concurrently and asserts no exception, no
corrupt state. (Standard concurrency test shape.)

**Adds CB-32** (threading model not documented per subsystem).

---

### §14.10 Bootstrap idempotency — replace + audit log

**Round 1 left this implicit.** What happens on a second
`bootstrap()` call without an intervening `shutdown()`? Replace?
Error? Stack?

**Design: replace + emit AUDIT log so the rogue call is
discoverable.**

```python
@contextmanager
def bootstrap(...):
    if _GLOBAL_CONTEXT is not None:
        # A second bootstrap. The previous context's resources
        # are torn down, then we proceed. AUDIT-log the event so
        # operators can find rogue re-bootstraps in plug-in
        # systems / monorepo test harnesses.
        LOG.warning(
            "bootstrap called again; replacing existing context",
            extra={
                "audit": True,
                "event": "bootstrap.replace",
                "previous_app_name": _GLOBAL_CONTEXT.app_name,
                "previous_app_version": _GLOBAL_CONTEXT.app_version,
                "new_app_name": app_name,
                "new_app_version": app_version,
            },
        )
        _GLOBAL_CONTEXT.shutdown()
    ...
```

**Why replace not error:** test harnesses and notebooks legit
need to re-bootstrap. Erroring would force them into a more
complex pattern. The AUDIT log catches accidental re-bootstraps
in production where they shouldn't happen.

**Adds CB-33** (bootstrap idempotency unspecified).

---

### §14.11 Closed-box compliance test — track import counts (META)

**Round 1 missed this entirely.** The closed-box principle is
the load-bearing design rule. **How do we PROVE we're closed?**
Today: nothing. The principle is enforced by code review, which
rots.

**Design: an automated test that scans the project's own
code (examples + tests + standards docs) for forbidden imports
and reports the count.** Goal: trend toward zero (or stable
non-zero with documented exceptions).

```python
# tests/unit/test_closed_box.py
"""Closed-box principle: count direct imports of underlying
libraries from consumer-facing code (examples + tests). The
count MUST trend toward zero or stay at the documented
allowlist. Adding a new direct import requires either (a)
adding it to the allowlist with a documented rationale, OR (b)
adding the missing wrapper to mgf.common.

This test fires the §2.4 PR review question mechanically.
"""

FORBIDDEN_IMPORTS_IN_CONSUMER_CODE = {
    "pydantic",                    # use mgf.common.config re-exports
    "opentelemetry",               # use mgf.common.observability
    "logging",                     # use mgf.common.observability.get_logger
    "warnings",                    # use mgf.common.observability emit pattern
    "sentry_sdk",                  # use mgf.common.observability.report_now
}

ALLOWLIST = {
    # Direct stdlib logging is allowed in tests/unit/test_closed_box.py itself
    # (this file).
    "tests/unit/test_closed_box.py": {"logging"},
    # The re-export modules ARE allowed to import the underlying.
    "src/mgf/common/config/_reexports.py": {"pydantic"},
    "src/mgf/common/observability/_otel_reexports.py": {"opentelemetry"},
    "src/mgf/common/observability/logging_setup.py": {"logging"},
    # Internal modules are allowed.
}


def test_consumer_facing_code_does_not_leak():
    """Closed-box compliance: scan examples/ and consumer-shaped
    tests for forbidden imports. Report violations or pass."""
    violations: list[tuple[Path, str]] = []
    for py_file in (Path("examples").rglob("*.py"), Path("tests/unit").rglob("*.py")):
        # ... ast.parse + walk for ImportFrom/Import nodes ...
        # Skip allowlisted (file_path, import_name) pairs.
        # Append (file, name) for any remaining violation.
    assert not violations, (
        f"Closed-box leak: {len(violations)} consumer-facing "
        f"files import forbidden libraries directly:\n"
        + "\n".join(f"  {f}: {imp}" for f, imp in violations)
        + f"\nEither add a wrapper in mgf.common.* OR add to "
        f"the documented ALLOWLIST with a rationale."
    )
```

**Outcome metric:** the violation count is published per release
in `STANDARDS_COMPLIANCE.md`. We watch it trend toward zero.

**Adds CB-34** (closed-box principle has no mechanical
enforcement).

---

### §14.12 PII / GDPR — strict redaction mode

**Round 1 missed this entirely.** Crash reports + logs may
contain PII (email, IP, phone, name). For regulated environments
(EU GDPR, US HIPAA, financial compliance), pattern-based key/value
redaction isn't enough.

**Design: opt-in `strict_mode` adds value-pattern redaction for
common PII shapes.**

```python
class RedactionSettings(BaseModel):
    strict_mode: bool = False
    """Adds extra value-pattern redaction for common PII:
    email addresses, IPv4/IPv6 addresses, US phone numbers,
    US SSN, EU IBAN, credit-card numbers (Luhn-validated).

    HIGH FALSE-POSITIVE RATE — enable only when legal/compliance
    requires it. The patterns over-match (e.g., a UUID may match
    the IPv6 pattern). Document this trade-off to your operators.
    """
```

When `strict_mode=True`, additional patterns enabled:

| Pattern | What | Why |
|---|---|---|
| `email` | `\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b` | GDPR personal data |
| `ipv4` | `\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b` | GDPR (debated; inclusive default) |
| `ipv6` | standard form | same |
| `us_phone` | `\b\d{3}[-.]?\d{3}[-.]?\d{4}\b` | TCPA / GDPR |
| `ssn` | `\b\d{3}-?\d{2}-?\d{4}\b` | HIPAA |
| `iban` | EU-format | PSD2 |
| `cc_luhn` | Luhn-validated 13-19 digit | PCI-DSS |

`mgf-common explain` shows the active strict-mode pattern groups
so operators can see the cost.

**Adds CB-35** (no GDPR/PII posture beyond pattern-based key
redaction).

---

### §14.13 Crash report schema versioning

**Round 1 missed this.** Crash reports are JSON files persisted
to disk. As we evolve the schema (add fields, rename fields,
restructure), older reports become unparseable by newer tools
— or worse, parseable but with wrong semantics.

**Design: every crash report carries `schema_version: int`.**
Bumped on breaking changes to the report shape; tooling
(`mgf-common explain --crashes <dir>`) branches on it.

```python
CRASH_REPORT_SCHEMA_VERSION = 2

def _build_report(exc, *, source) -> dict[str, Any]:
    return {
        "schema_version": CRASH_REPORT_SCHEMA_VERSION,
        "timestamp": ...,
        "report_id": ...,
        "app": ...,
        # ... etc
    }
```

**Schema-version migration policy** (parallels CF-03):

- v1 → v2 (current): added `schema_version` field; older reports
  treated as v1 implicitly.
- Future bumps: ship an upgrader in `mgf-common migrate-crashes <dir>`
  if the change is material.
- Tools accept the latest N versions natively; older ones
  upgrade-on-read.

**Adds CB-36** (crash reports unversioned; tools can't safely
evolve).

---

### §14.14 Performance budgets across the board

**Round 1 had LG-12 only.** A library used in every project
needs documented budgets across every hot surface; without them,
a regression in one subsystem can ship to consumers undetected.

**Design: per-subsystem budgets, each pinned by a benchmark
test in `tests/unit/perf/`.**

| Surface | Budget | Pin test |
|---|---|---|
| log emission (rotating-file sink) | ≤100 µs/record | `test_logging_perf.py` (already shipped) |
| span creation + end | ≤200 µs/span | `test_otel_perf.py` (NEW in 0.3) |
| crash report write (local sink) | ≤50 ms/report (IO-bound) | `test_crash_perf.py` (NEW) |
| config load (cold, 1 KB YAML) | ≤500 ms | `test_config_load_perf.py` (NEW) |
| redaction (per string, 1 KB) | ≤10 µs | `test_redaction_perf.py` (NEW) |
| `bootstrap()` (cold, default settings) | ≤200 ms | `test_bootstrap_perf.py` (NEW) |
| `Redactor.redact()` (per dict, 100 keys) | ≤50 µs | `test_redaction_perf.py` |
| `current_context()` lookup | ≤200 ns | `test_context_perf.py` (NEW) |
| `register_*` decorator (one-shot) | ≤1 ms (call sites are bootstrap-time) | not pinned |

Each budget is a hard `assert` in the corresponding `tests/unit/perf/`
file. Soft margin (e.g., 30 %) over the documented number to
absorb noisy CI without false positives. Drift toward the soft
margin investigated; breach of the hard number is a defect.

**Adds CB-37** (no documented per-subsystem performance budgets;
LG-12 is the only one).

---

### §14.15 The "auto" preset as migration default — preserve v0.1 behaviour

**Round 1 implied this in §6 but didn't make it operational.**
v0.1 consumers depend on auto-detection (TTY → text; JOURNAL_STREAM
→ journald; OTEL_EXPORTER_OTLP_ENDPOINT → enabled). v0.3's
explicit-default would silently break their existing setup.

**Design: two-tier default.**

- **`bootstrap(...)` called WITHOUT a `settings=` arg**
  → defaults to `MgfSettings(preset="auto")`. Preserves v0.1
  behaviour for legacy consumers.
- **`bootstrap(..., settings=MgfSettings(...))`** with explicit
  settings → preset defaults to `"explicit"`. New-project default
  is the closed-box-friendly explicit shape.

**Migration** (codified in `MIGRATION_0.1_TO_0.3.md`):

1. After bumping the pin, your code keeps working — `bootstrap()`
   without args defaults to `preset="auto"`.
2. To get the new explicit semantics, pass `settings=MgfSettings()`
   (the all-defaults-explicit form) and configure each field you
   care about.
3. The `mgf-common migrate 0.1 0.3` codemod handles the call-site
   shape (multi-call → bootstrap context-manager); your config
   posture stays your choice.

This eliminates the "every consumer's first v0.3 run breaks
silently" failure mode.

**Adds CB-38** (auto-detection migration not addressed; would
silently break v0.1 consumers).

---

### §14.16 Reserved env-var namespace

**Round 1 implied `MGF_*` in §4.2 examples but didn't declare
the policy.** Consumers who pre-existed our using `MGF_*` for
their own purposes will collide.

**Design: declare the namespace policy in `docs/standards/CONFIGURATION.md`
+ `mgf-common explain --env`.**

| Prefix | Reserved by | Example |
|---|---|---|
| `MGF_*` | `mgf-common` library itself (its own `MgfSettings`) | `MGF_LOGGING__LEVEL` |
| `<APP>_*` | the consumer's own settings (their `env_prefix`) | `MYAPP_BACKEND_URI` |
| `OTEL_*` | OpenTelemetry standard | `OTEL_EXPORTER_OTLP_ENDPOINT` |
| `XDG_*` | freedesktop.org standard | `XDG_CONFIG_HOME` |
| `JOURNAL_STREAM`, `INVOCATION_ID` | systemd | (auto-detected) |

`mgf-common explain --env` prints every env var the library
reads, grouped by namespace, with current value (REDACTED for
sensitive shapes like DSNs).

**Adds CB-39** (no declared env-var namespace; collision risk
with consumers who used `MGF_*` for their own).

---

### §14.17 Single-binary compatibility — PyInstaller / Nuitka / Briefcase

**Round 1 missed this.** A library "used in all projects"
includes desktop apps shipped as single binaries (PyInstaller,
Nuitka, Briefcase, Buildozer for Android/iOS). Standard Python
plugin discovery via `importlib.metadata.entry_points` BREAKS
under PyInstaller (no installed-package metadata at runtime).

**Design: use `@register_*` decorator-based registries, NOT
entry_points discovery.**

This is already the §4 design. **Round 2 makes it explicit and
adds a CI smoke.**

- All registries (`register_crash_sink`, `register_log_handler`,
  `register_redaction_pattern_group`, `register_span_processor`,
  `register_vault_backend`) are call-time, not entry_points.
- A consumer's plug-in module must be IMPORTED for its
  registrations to take effect — standard Python behaviour, works
  under every packager.
- Document the pattern: "to discover plug-ins under PyInstaller,
  consumers explicitly import them at startup."
- (Future: a `MgfSettings.plugins` field with a list of
  module-paths for the library to import on bootstrap; opt-in
  for consumers who want auto-discovery.)

**CI smoke (eventual):** build a sample app under PyInstaller in
CI, verify `mgf-common doctor` passes inside the bundle.

**Adds CB-40** (single-binary packager compat not declared).

---

### §14.18 Config file formats — YAML / TOML / JSON via extension dispatch

**Round 1 assumed YAML.** Some consumers prefer TOML (Pythonic,
matches `pyproject.toml`); ML/data-science consumers prefer JSON.

**Design: `load_settings(SettingsClass, path)` dispatches on file
extension.** All formats produce the same typed `MgfSettings`
output.

```python
def load_settings(cls, *, path: Path | None = None, ...) -> T:
    ...
    suffix = path.suffix.lower()
    if suffix in (".yaml", ".yml"):
        raw = yaml.safe_load(path.read_text())
    elif suffix == ".toml":
        with path.open("rb") as fh:
            raw = tomllib.load(fh)        # stdlib in 3.11+
    elif suffix == ".json":
        raw = json.loads(path.read_text())
    else:
        raise AppConfigError(
            f"unsupported config format: {suffix} "
            f"(supported: .yaml, .yml, .toml, .json)"
        )
    ...
```

`save_settings` defaults to YAML (matching the read default) but
takes an optional `format=` argument for TOML / JSON.

`mgf-common validate` accepts all three.

**Adds CB-41** (config file format hardcoded to YAML; TOML/JSON
consumers excluded).

---

### §14.19 Stable-tier promotion criteria — concrete process

**Round 1 said names start `experimental` and get promoted to
`stable` after one MINOR cycle.** That's vibes; what's the
process?

**Design: three concrete criteria; ALL three required for
promotion.**

A name moves from `experimental` to `stable` when:

1. **Survival.** The name has been in `PUBLIC_API.md` as
   `experimental` for ≥1 full MINOR cycle (e.g., shipped in
   0.3.0, eligible for stable in 0.4.0).
2. **Real-consumer use.** At least one consumer outside VManager
   has used the name in production. (FEEDBACK §4 retrospective
   counts as evidence; an explicit FEEDBACK consumer entry citing
   the name counts as evidence.)
3. **No 🔴 Blocker outstanding.** No active 🔴 entry in
   `FEEDBACK.md` references the name.

Promotion is mechanical: update the tier column in
`PUBLIC_API.md`. No code change.

**Demotion** (`stable` → `deprecated`) follows the AP-04
deprecation cycle (announce → ≥1 MINOR survival → MAJOR remove).

**Adds CB-42** (stable-tier promotion has no concrete process).

---

### §14 — summary of what this round adds

19 new CB-* items (CB-24..CB-42), each closing a hole the round-1
spec left open. Net additions to the redesign:

| Subsystem affected | New surface | Rationale |
|---|---|---|
| Lifecycle | `BootstrapError` typed exception; rollback closures; `_BootstrapLogBuffer` | atomicity + bootstrap-time logging |
| Lifecycle | `AppContext.reload()` | hot-reload for long-running services |
| Lifecycle | bootstrap idempotency + AUDIT log | catch rogue re-bootstraps |
| OTel | `_AppContextSpanProcessor` | multi-tenancy + OTel resource collision |
| Settings | `LoggingSettings.level_overrides` | per-component levels first-class |
| Settings | `RedactionSettings.strict_mode` | GDPR/PII posture |
| Crash | `schema_version` field in every report | tool migration safety |
| Self-observation | `_RuntimeCounters` + `mgf-common explain --runtime` | dashboards on the library itself |
| Testing | `mgf.common.testing.bootstrap_for_test` + `TestContext` | first-class test isolation API |
| Compliance | `tests/unit/test_closed_box.py` | mechanical enforcement of the principle |
| Quality | per-subsystem `tests/unit/perf/` benchmarks | budget regression catch |
| Migration | `bootstrap()` defaults to `preset="auto"` for v0.1-shape callers | no silent break on upgrade |
| Loader | extension-dispatched YAML/TOML/JSON | consumer choice |
| Process | concrete stable-tier promotion criteria | no vibes |

Net surface added: ~12 public types/functions + ~5 private types
+ the test-isolation module (~300 LOC) + the runtime-counters
module (~150 LOC) + the closed-box compliance test (~80 LOC) +
the perf benchmark suite (~6 files × 50 LOC each).

Net commit count for these additions: distributed across the §9
phases (no new phase needed). Specifically:

- §14.2, §14.3, §14.10 → Phase 1 (bootstrap implementation)
- §14.4 → Phase 2 (closed-box wraps + OTel work)
- §14.5, §14.6, §14.7 → Phase 3 (registries + counters share patterns)
- §14.8 → Phase 5 (testing module ships alongside CLI helpers)
- §14.9, §14.11, §14.14 → Phase 7 (codemod + tests + docs ship together)
- §14.12, §14.13, §14.15, §14.16, §14.17, §14.18, §14.19 → Phase 6 (CLI + presets + scope all ship together)

---

## §15. Decision log (your edits go here)

This section is intentionally empty. As you review this
document, append your decisions / overrides / questions here.
Anything in §15 supersedes the recommendations in §10 and §14.

```
2026-MM-DD — <decision> — <rationale>
```

---

*End of `CLOSED_BOX_REDESIGN.md`. Next step: your review →
implementation per §9 phasing (with the §14 additions slotted
into the relevant phases).*
