# Migration Guide — `mgf-common` v0.1.x → v0.3.0

> **Status:** Released with v0.3.0. **Target audience:** consumers
> upgrading from `mgf-common ~=0.1` (the PyPI release) to `~=0.3`.
> **Time to migrate a single consumer:** ~30 minutes for the
> mechanical renames + 1 hour for the bootstrap reshape (one-time).
> **Compatibility window:** every v0.1 API still works in v0.3.x
> with `MgfDeprecationWarning` per the standard cycle (rule
> **AP-04**); removal lands in v1.0.

This guide is the canonical answer to "what changed and how do I
upgrade?" for the v0.3 closed-box reshape. It pairs with the
`mgf-common migrate` codemod (which handles the mechanical
renames automatically) and `mgf-common explain` (which lets you
verify post-upgrade configuration matches what you intended).

If you only have ten minutes, run the codemod and read §1
("The bootstrap reshape") — that is the only substantial change.
Everything else is either a mechanical rename, an additive new
API you can adopt later, or a no-op.

## Quick reference

| Change | Codemod handles it? | Section |
|---|---|---|
| 5-call bootstrap sequence → single `bootstrap()` | ✗ — manual (see §1) | [§1](#1-the-bootstrap-reshape-the-only-substantial-change) |
| `EnvironmentError` → `HostEnvironmentError` | ✓ — `mgf-common migrate` | [§2](#2-mechanical-renames-the-codemod-handles-these) |
| `make_settings_config(...)` → `settings_config(...)` | ✓ — `mgf-common migrate` | [§2](#2-mechanical-renames-the-codemod-handles-these) |
| New `MgfSettings` typed config root | n/a — additive | [§3.1](#31-mgfsettings--the-librarys-own-typed-config) |
| New `mgf.common.typing` Protocols | n/a — additive | [§3.2](#32-protocols-for-test-doubles--custom-impls) |
| New `mgf.common.progress` cancellation/reporter primitives | n/a — additive | [§3.3](#33-progress--cancellation-primitives) |
| New `mgf.common.vault` credential storage | n/a — additive | [§3.4](#34-vault--credential-storage) |
| New `mgf.common.cli` exit codes + translator | n/a — additive | [§3.5](#35-cli-helpers--exit-codes--translator) |
| New `mgf-common` diagnostic CLI | n/a — additive | [§3.6](#36-mgf-common-diagnostic-cli) |
| New registry decorators (crash sinks, log handlers, etc.) | n/a — additive | [§3.7](#37-registry-decorators-pluggable-extensions) |

## How to use this guide

1. **Pin the new version.** In your `pyproject.toml`:

   ```toml
   [project]
   dependencies = [
       "mgf-common>=0.3.0,<0.4",   # was: >=0.1.0,<0.2
   ]
   ```

   Re-install: `pip install -U "mgf-common>=0.3.0,<0.4"`.

2. **Run the codemod for the mechanical renames.** From your
   project root:

   ```bash
   mgf-common migrate 0.1 0.3 src/
   ```

   Use `--dry-run` first to preview. Use `--backup` to keep `.bak`
   copies. Re-runnable — running twice does not double-rename.

3. **Read §1 and apply the bootstrap reshape by hand.** This is
   the only substantial change. Most consumer projects have one
   or two entry points; the migration is mechanical per entry
   point but worth a human review per call.

4. **Run your test suite.** Every v0.1 surface still works during
   the v0.3 deprecation cycle, so green tests after step 3 mean
   you are migrated. The `MgfDeprecationWarning` emissions are
   visible (per the recommendation in §4) so you can find any
   call sites the codemod or this guide missed.

5. **Optionally adopt the new APIs in §3.** Each is additive — no
   v0.1 code breaks if you ignore them. They unlock the v0.3
   closed-box surface.

## 1. The bootstrap reshape (the only substantial change)

The v0.1 entry-point pattern was a five-call sequence:

```python
# v0.1
from mgf.common import configure
from mgf.common.observability import (
    setup_logging, setup_otel,
    install_excepthook, install_threading_excepthook,
)

def main(argv):
    configure(app_name="myapp", app_version="1.0")
    setup_logging(level="DEBUG", fmt="json")
    setup_otel(enabled=True)
    install_excepthook()
    install_threading_excepthook()
    # ... your CLI logic
```

Every call still works in v0.3 (each emits `MgfDeprecationWarning`
when called explicitly). The recommended v0.3 shape is a single
transactional `bootstrap()`:

```python
# v0.3
from mgf.common import bootstrap

def main(argv):
    with bootstrap(app_name="myapp", app_version="1.0"):
        # ... your CLI logic
```

That is the entire change. `bootstrap()` is transactional (LIFO
rollback on partial failure), idempotent (safe to call again — the
previous wiring is shut down first with an `audit=true` log
entry), and dual-mode (works as `with bootstrap(...) as ctx:` AND
as `ctx = bootstrap(...)` for non-context-manager callers).

### 1.1 If you need explicit settings

Pass a `MgfSettings` instance:

```python
from mgf.common import bootstrap
from mgf.common.settings import MgfSettings, LoggingSettings, OtelSettings

with bootstrap(
    app_name="myapp",
    app_version="1.0",
    settings=MgfSettings(
        logging=LoggingSettings(level="DEBUG", format="json"),
        otel=OtelSettings(enabled=True),
    ),
):
    # ... your CLI logic
```

Or rely on env-var aliases (`MGF_LOGGING__LEVEL=DEBUG`,
`MGF_OTEL__ENABLED=true`) — pydantic-settings reads them
automatically.

### 1.2 If you want preset-driven defaults

Phase 6a introduced presets:

```python
with bootstrap(
    app_name="myapp",
    app_version="1.0",
    settings=MgfSettings(preset="systemd"),
):
    # journald + JSON log format applied automatically
    ...
```

Five presets: `explicit` (default; no auto-detection), `dev`,
`systemd`, `docker`, `auto` (legacy v0.1 detection — TTY /
`JOURNAL_STREAM` / `OTEL_EXPORTER_OTLP_ENDPOINT`). The `auto`
preset is the default when `bootstrap()` is called WITHOUT a
`settings=` argument, so legacy v0.1 consumers see identical
behaviour without any settings passed.

### 1.3 If you don't want a context manager

For non-CM call sites (long-running services, GUI apps where the
event loop owns the lifetime):

```python
ctx = bootstrap(app_name="myapp", app_version="1.0")
try:
    run_forever()
finally:
    ctx.shutdown()  # LIFO rollback of every wiring step
```

`ctx` is an `AppContext` carrying `app_name`, `app_version`,
`settings`, and the rollback handles. Per-step rollback is
swallow-on-failure (per rule **EH-10**) so a partial-shutdown
cannot escalate.

### 1.4 If you only want identity (no logging / OTel / excepthooks)

Keep using `configure()` — it is NOT deprecated:

```python
from mgf.common import configure
configure(app_name="myapp", app_version="1.0")
```

This is the right shape for libraries that wrap `mgf-common` but
don't want to install excepthooks (e.g., a test fixture, a
notebook utility module). `mgf.common.app_name()` /
`app_version()` resolve via `current_context()` first (set by
`bootstrap()`), then the legacy module global (set by
`configure()`), then a placeholder.

### 1.5 If you rely on the v0.1 multi-call pattern

The five v0.1 functions still exist. They emit
`MgfDeprecationWarning` on call. The warnings name the v0.3
replacement so you can locate call sites incrementally:

```
MgfDeprecationWarning: mgf.common.observability.setup_logging is
deprecated since v0.3.0; use mgf.common.bootstrap(...) which
wires logging + OTel + excepthooks transactionally. The old call
shape is removed in v1.0.
```

The library's own pyproject `filterwarnings` exempts
`MgfDeprecationWarning` so warnings are visible without
breaking your tests during the migration window. Once you have
finished migrating, add to your own pyproject:

```toml
[tool.pytest.ini_options]
filterwarnings = [
    "error::mgf.common._warnings.MgfDeprecationWarning",
]
```

That escalates any remaining v0.1 call site to a hard test
failure — the cleanest signal that the migration is complete.

### 1.6 What `bootstrap()` does in one paragraph

It wires identity (`app_name` / `app_version`), logging (console
+ rotating file + opt-in journald / OTLP / syslog / HTTP per
`MgfSettings.logging`), OTel (when enabled), per-component log
levels, the log buffer (captures records emitted DURING bootstrap
so they are not lost), `sys.excepthook` and
`threading.excepthook`, and the crash-sink registry — in a
single transactional pass with LIFO rollback on partial failure.
It returns a dual-mode `_BootstrapContext` that proxies
`AppContext` attributes and supports both `with` and `ctx =` use.
Calling it again replaces the prior wiring (with an
`audit=true` log entry per rule **SC-17**) — Phase 1 design ref
§14.10.

## 2. Mechanical renames (the codemod handles these)

Two simple renames in v0.3. Both have backward-compat shims that
work during the cycle, both emit `MgfDeprecationWarning`, both
are removed in v1.0.

### 2.1 `EnvironmentError` → `HostEnvironmentError`

`mgf.common.exceptions.EnvironmentError` shadowed Python's
built-in alias for `OSError` — closes FEEDBACK 🔴 Blocker
**API-01**.

```python
# v0.1
from mgf.common.exceptions import EnvironmentError

class CpuLacksVmxError(EnvironmentError):
    pass
```

```python
# v0.3
from mgf.common.exceptions import HostEnvironmentError

class CpuLacksVmxError(HostEnvironmentError):
    pass
```

The deprecated `EnvironmentError` alias remains. Its metaclass
makes `issubclass(MyError, EnvironmentError)` return `True` for
`MyError(HostEnvironmentError)` so legacy `except
EnvironmentError:` clauses keep catching new instances. The
alias's constructor emits the warning.

The `mgf-common migrate` codemod handles both the import and the
use sites. Run it once on your `src/`.

### 2.2 `make_settings_config` → `settings_config`

`mgf.common.config.make_settings_config` was renamed to
`settings_config` in v0.3 (the `make_` prefix turned out to be
noise — every other settings helper is named after what it
returns, not the verb that returns it). The deprecated alias
emits `MgfDeprecationWarning` on call.

```python
# v0.1
from mgf.common.config import BaseAppSettings, make_settings_config

class MySettings(BaseAppSettings):
    model_config = make_settings_config(env_prefix="MYAPP_")
```

```python
# v0.3 — option A: rename only
from mgf.common.config import BaseAppSettings, settings_config

class MySettings(BaseAppSettings):
    model_config = settings_config(env_prefix="MYAPP_")
```

```python
# v0.3 — option B: subclass-kwarg pattern (closes FEEDBACK API-06)
from mgf.common.config import BaseAppSettings

class MySettings(BaseAppSettings, env_prefix="MYAPP_"):
    pass
```

Option B is the v0.3 idiom. It uses `__init_subclass__` to accept
every `SettingsConfigDict` key as a class kwarg — so the
declaration site is `class S(BaseAppSettings, env_prefix=...,
env_nested_delimiter=..., ...)` instead of a
`model_config = settings_config(...)` line. Functionally
equivalent; choose what reads better in your codebase.

The codemod handles option A (the safe, mechanical rename). If
you want option B, do it by hand — it's a one-line change per
Settings subclass.

## 3. New v0.3 APIs (additive — adopt at your pace)

Every entry below is NEW — your v0.1 code does not break if you
ignore them. They unlock the closed-box surface that justifies
the v0.3 reshape.

### 3.1 `MgfSettings` — the library's own typed config

Phase 1 introduced `MgfSettings`, the library's own typed
configuration root (FEEDBACK design ref §4.2). Sub-models for
logging, OTel, crash, redaction, vault, plus a top-level
`preset` enum.

Use it explicitly when you want behaviour that's NOT covered by
env-var aliases, OR when you want to compose multiple
deployment shapes from a single codebase:

```python
from mgf.common import bootstrap
from mgf.common.settings import (
    MgfSettings, LoggingSettings, OtelSettings, CrashSettings,
)

settings = MgfSettings(
    logging=LoggingSettings(
        level="INFO",
        format="json",
        level_overrides={"urllib3.connectionpool": "WARNING"},
    ),
    otel=OtelSettings(
        enabled=True,
        endpoint="https://otel.example.com/v1/traces",
        sample_rate=0.1,
        resource_attributes={"team": "platform", "env": "prod"},
    ),
    crash=CrashSettings(
        sinks=["local", "sentry"],
        sentry_dsn="https://abc@sentry.io/4505",
    ),
)
with bootstrap(app_name="myapp", app_version="1.0", settings=settings):
    ...
```

Run `mgf-common explain --app myapp --version 1.0` to see what
got applied — useful when troubleshooting "why did this value
not take effect" in CI vs. local. Each field shows its source:
`(default)`, `(env: ...)`, `(preset: ...)`, `(init)`, `(file)`.

### 3.2 Protocols for test doubles + custom impls

Closes FEEDBACK 🔴 Blocker **API-05**. Every stable abstraction
has a `Protocol` in `mgf.common.typing`:

```python
from mgf.common.typing import (
    CancellationProtocol,    # cancel() + is_cancelled()
    ReporterProtocol,        # report() + is_cancelled()
    LogSinkProtocol,         # append_info() + append_error()
    VaultProtocol,           # get / set / delete / list_keys + backend
)
```

All four are `runtime_checkable` so `isinstance(obj, X)` works
in tests. Use them when you want to inject a fake / a
third-party adapter / a domain-specific implementation —
without depending on the library's concrete classes.

### 3.3 Progress + cancellation primitives

Closes FEEDBACK 🔴 Blocker **API-03**. Lifted from the reference
consumer (VManager) into `mgf.common.progress`:

```python
from mgf.common.progress import (
    CancellationToken,    # sync, threading.Event-backed
    NullReporter,         # no-op concrete impl
    RecordingReporter,    # test double
    ProgressReporter,     # alias for ReporterProtocol
)

def long_op(*, token: CancellationToken, reporter: ProgressReporter):
    for i, item in enumerate(items):
        token.raise_if_cancelled()
        do_thing(item)
        reporter.report(f"processed {i+1}/{len(items)}",
                        current=i+1, total=len(items))
```

Async variant in `mgf.common.progress.asyncio.AsyncCancellationToken`
(asyncio.Event-backed; `await wait(timeout)` instead of
blocking).

A new typed exception `mgf.common.exceptions.CancellationError`
(subclass of `OperationError`) lets cancellation flow through
the standard exception ladder — your existing `except
OperationError:` catches it without code change.

### 3.4 Vault — credential storage

Closes FEEDBACK §3.2. `mgf.common.vault` ships three backends,
each implementing `VaultProtocol`:

```python
from mgf.common.vault import EnvVault, KeyringVault, EncryptedFileVault

# CI / containers — stdlib-only.
v = EnvVault(prefix="MYAPP_VAULT_")

# Desktop — system credential store via keyring (libsecret /
# Keychain / Credential Manager). Requires [vault] extra.
v = KeyringVault(service="myapp")

# Headless / CI persistence — Fernet AES-128 + PBKDF2 600k
# iterations (OWASP 2023 baseline). Requires [vault] extra.
from pathlib import Path
v = EncryptedFileVault(Path("vault.bin"), passphrase=prompt())
```

Custom backends (HashiCorp Vault, AWS Secrets Manager, custom
HSM) plug in via the registry:

```python
from mgf.common.vault import register_vault_backend

@register_vault_backend("hashicorp")
def make_hashicorp_vault(config):
    return MyAdapter(hvac.Client(url=config["url"], token=config["token"]))
```

To add the optional dependency: `pip install
"mgf-common[vault]>=0.3"`.

### 3.5 CLI helpers — exit codes + translator

`mgf.common.cli` ships eight stable exit-code constants
(numeric pin per **AP-04**) and an exception → exit-code
translator that absorbs the `except AppError` ladder every
consumer was hand-rolling:

```python
from mgf.common.cli import run_and_translate, EXIT_VAULT_ERROR

def main(argv):
    # ... your CLI logic; raise typed exceptions as needed
    return 0

if __name__ == "__main__":
    import sys
    sys.exit(run_and_translate(main, sys.argv[1:]))
```

Untyped exceptions automatically ship a crash report through
`mgf.common.observability.report_now` and return
`EXIT_UNKNOWN (10)`. Typed `AppError` subclasses map to their
category exit code (CONFIG=1, OPERATION=2, GUEST=3,
ENVIRONMENT=4, PROVIDER=5, VAULT=6).

Per-CLI overrides via `exit_code_map={LicenseError: 7}`.
Decorator form available as `translate_exceptions(...)`.

### 3.6 `mgf-common` diagnostic CLI

Phase 6b ships a console-script with three subcommands:

```bash
$ mgf-common explain --app myapp --version 1.0
# Renders the active MgfSettings; each field annotated
# (default / env / preset / init).

$ mgf-common validate ~/.config/myapp/config.yaml
# Schema-validates the YAML against MgfSettings; reports
# pass/fail; on success dumps the resolved active config.

$ mgf-common doctor
# Install-state + wiring health: package install, py.typed
# marker, optional extras, state dir writability,
# auto-detect signals, registered extensions.
```

Use `explain` to confirm your post-migration config matches what
you intended. Use `doctor` from CI to fail-fast on environment
drift (missing extras, missing state dir).

### 3.7 Registry decorators (pluggable extensions)

Phase 3 + Phase 5 introduced five registries. Each lets you
extend the library WITHOUT forking — register a named factory,
list its name in the corresponding `MgfSettings` field, the
library wires it.

```python
from pathlib import Path
from typing import Any

from mgf.common.observability import (
    register_crash_sink,
    register_log_handler,
    register_redaction_pattern_group,
    register_span_processor,
)
from mgf.common.vault import register_vault_backend

@register_crash_sink("my-slack")
def ship_to_slack(report_path: Path, payload: dict[str, Any]) -> None:
    requests.post(SLACK_WEBHOOK, json={
        "text": f"Crash in {payload['app']}: "
                f"{payload['exception']['message']}",
    }, timeout=5)
```

Built-in names are pre-registered:

  - Crash sinks: `local`, `sentry`, `otlp`
  - Vault backends: `env`, `keyring`, `file`
  - Redaction pattern groups: `builtin`

Trying to re-register an existing name raises `ValueError`. Use
`unregister_*("name")` first if you intend to replace.

## 4. Recommended migration sequence

For a typical consumer with one CLI entry point + one GUI entry
point + a test suite:

1. **Pin the new version + run the codemod** (5 min).

   ```bash
   pip install -U "mgf-common>=0.3.0,<0.4"
   mgf-common migrate 0.1 0.3 src/ --dry-run     # preview
   mgf-common migrate 0.1 0.3 src/                # apply
   ```

2. **Apply the bootstrap reshape per entry point** (15 min per
   entry point — usually 1-3 entry points per consumer).

   Find each call site of `configure()`, `setup_logging()`,
   `setup_otel()`, `install_excepthook()`,
   `install_threading_excepthook()`. Replace the sequence with a
   single `bootstrap()` per §1.

3. **Run tests** (5 min).

   ```bash
   pytest -W default::mgf.common._warnings.MgfDeprecationWarning
   ```

   Any remaining `MgfDeprecationWarning` emissions point at call
   sites the codemod or §2 missed.

4. **Lock in the migration** (5 min).

   Add to your `pyproject.toml`:

   ```toml
   [tool.pytest.ini_options]
   filterwarnings = [
       "error::mgf.common._warnings.MgfDeprecationWarning",
   ]
   ```

   Now any v0.1 surface that creeps back in is a hard test
   failure.

5. **Optionally adopt §3 APIs** (your timeline).

   The new APIs are pure additions. Pick them up as you touch
   the relevant modules — there is no mass-adoption sweep
   required. The diagnostic CLI (`mgf-common explain / validate
   / doctor`) is the highest-leverage adoption per minute spent.

## 5. Troubleshooting

### `MgfDeprecationWarning` at import time, not at call time

The legacy `EnvironmentError` alias's metaclass emits the
warning on instantiation, not at import. If you see the warning
at import time, the import statement is fine — search your code
for `EnvironmentError(...)` constructor calls.

### `TypeError: got multiple values for keyword argument 'env_prefix'`

You passed `env_prefix="X_"` as a class kwarg to a subclass that
ALSO has `model_config = settings_config(env_prefix="X_")`.
Pick one — either the class-kwarg shape OR the
`model_config = settings_config(...)` shape.

### `bootstrap()` raises `BootstrapError`

A wiring step failed. The error message names the failed step
(`"otel"`, `"crash_sinks"`, `"logging"`, etc.). Check
`__cause__` for the underlying exception. The library is
uninitialised — every wiring step that succeeded so far has
been rolled back. Fix the cause and call `bootstrap()` again.

### `mgf-common: command not found`

Re-install with `pip install -U "mgf-common>=0.3.0,<0.4"` —
the `[project.scripts]` entry is registered at install time. If
you installed in editable mode (`pip install -e .`) you may
need to re-run the editable install for the new script to
register.

### `mgf-common explain` shows fields with unexpected sources

Run it again with `--preset explicit` to disable preset-driven
defaults, then again without to see what the preset added. If
env vars are interfering, run `env | grep MGF_` and check
`OTEL_EXPORTER_OTLP_ENDPOINT` / `JOURNAL_STREAM` for auto-preset
inputs.

### My codemod ran but `EnvironmentError` is still imported

The codemod skips files that don't import from
`mgf.common.exceptions`. If your code re-exports
`EnvironmentError` from a project-internal alias module, edit
that file by hand or add it to the codemod's path argument.

### A test that used to pass now emits `MgfDeprecationWarning`

That's the migration signal — your test exercised a v0.1 API
the codemod didn't touch. The warning's message names the v0.3
replacement; apply the change at the call site. The test will
pass; the warning will go away.

## 6. What is NOT changing

This section exists so you don't go looking for changes that
aren't there.

- **`mgf.common.configure(app_name=..., app_version=...)`** — NOT
  deprecated. Use it for identity-only flows (libraries that
  wrap mgf-common but don't want excepthooks).
- **`AppError` and the typed exception hierarchy** — every
  category and concrete is unchanged except for the
  `EnvironmentError` rename (§2.1).
- **`BaseAppSettings`** — the base class itself is unchanged;
  only the helper rename in §2.2.
- **`load_settings()` / `save_settings()` / `platform_dir()` /
  `default_config_path()` / `expand_path()`** — unchanged.
- **The `[observability]` extra and what it ships** — same
  packages (`opentelemetry-*`, `sentry-sdk`).
- **Exit-code numeric values** — once published in v0.3, they
  are a stability pin (rule **AP-04**); they will not change in
  the 0.x window.
- **PEP 420 namespace shape** — `mgf` is still a namespace
  package; future `mgf.<sibling>` projects from other repos can
  still contribute under the same `mgf.*` namespace.

---

*See [`PUBLIC_API.md`](../PUBLIC_API.md) for the full v0.3 public
surface. See [`CHANGELOG.md`](../CHANGELOG.md) for the per-phase
detail. See [`docs/standards/`](standards/) for the cross-project
engineering standards `mgf-common` ships against.*
