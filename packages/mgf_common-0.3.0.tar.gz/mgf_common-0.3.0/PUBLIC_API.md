# Public API — `mgf-common` v0.3.0

This document is the **contract list** for `mgf-common`. Every name
listed below is a public name that consumers MAY depend on.

The contract terms are defined in
[`docs/standards/API_DESIGN.md`](docs/standards/API_DESIGN.md). In
short:

- **Stability tiers:**
  - `experimental` — MAY change shape in any MINOR release
    (the 0.x window keeps everything experimental in practice).
  - `stable` — follows the deprecation cycle; removal only in MAJOR.
  - `deprecated` — slated for removal; emits `DeprecationWarning`.
- **Names not listed below are private.** Anything starting with
  `_` (underscore-prefixed module names like `_identity.py`) is
  internal and MAY change without notice.
- **The 0.x window applies.** Per [SemVer](https://semver.org/) 0.x
  semantics, MINOR releases MAY break the public API. Pin tightly:
  `mgf-common = ">=0.3.0,<0.4"`. After v1.0 ships, the standard
  MAJOR / MINOR / PATCH discipline applies.

This file MUST stay in sync with the `__all__` of every public
package — see the pin test pattern in
[`docs/standards/API_DESIGN.md`](docs/standards/API_DESIGN.md) §2.4.

---

## `mgf.common`

Top-level identity + version surface. Three names + the version
attribute.

| Name | Tier | Since | Description |
|---|---|---|---|
| `bootstrap(app_name: str, app_version: str, *, settings: MgfSettings | None = None)` | experimental | 0.3.0 | The single canonical bootstrap. Wires identity + logging + OTel + excepthooks transactionally; returns `_BootstrapContext` (dual-mode: `with` block OR `ctx = bootstrap(...)`). Replaces the v0.1 five-call sequence. Closes FEEDBACK design refs §4.1, §14.2, §14.3, §14.10, §14.15. |
| `current_context() -> AppContext | None` | experimental | 0.3.0 | Returns the active `AppContext` (per-task contextvar OR module-global) or `None` if `bootstrap()` has not been called. Thread-safe; ~30 ns per call. |
| `AppContext` | experimental | 0.3.0 | Per-tenant identity + settings dataclass. Carries `app_name`, `app_version`, `settings`. Methods: `shutdown()` (LIFO rollback of every wiring step), `reload(new_settings)` (atomic re-wire — closes FEEDBACK §14.5). |
| `configure(app_name: str, app_version: str = "unknown") -> None` | experimental | 0.1.0 | Legacy: set the process-wide app identity. Use `bootstrap()` instead — it wires logging / OTel / excepthooks too. Deprecation cycle starts in a focused later phase. |
| `app_name() -> str` | experimental | 0.1.0 | Read the active app name. Resolves via `current_context()` if a context is active, else the legacy module global, else returns `"app"` placeholder + emits `UnconfiguredWarning`. |
| `app_version() -> str` | experimental | 0.1.0 | Read the active app version. Same resolution order as `app_name`. |
| `UnconfiguredWarning` | experimental | 0.2.0 | `UserWarning` subclass emitted once per process when identity is read before `configure()` / `bootstrap()`. Closes FEEDBACK API-08. |
| `__version__: str` | stable | 0.1.0 | Package version string. Mirrors `pyproject.toml::project.version`. |

---

## `mgf.common.exceptions`

Typed exception hierarchy. One base + 7 category bases + 7 generic
concretes. Project-specific exceptions subclass these.

### Base

| Name | Tier | Since | Description |
|---|---|---|---|
| `AppError` | experimental | 0.1.0 | Base for every exception raised by `mgf.common` and consumer projects. Subclass to extend. |

### Category bases (7)

| Name | Tier | Since | Description |
|---|---|---|---|
| `ConfigError` | experimental | 0.1.0 | Configuration / spec validation failures |
| `ProviderError` | experimental | 0.1.0 | Failures inside a provider implementation (third-party SDK boundary) |
| `OperationError` | experimental | 0.1.0 | Runtime failures during a long-running operation |
| `GuestError` | experimental | 0.1.0 | Failures communicating with a remote agent (SSH, agent, health probe) |
| `EnvironmentError` | experimental | 0.1.0 | Host pre-flight failures (deliberately shadows the builtin alias — see API-01 in `FEEDBACK.md`) |
| `VaultError` | experimental | 0.1.0 | Credential vault failures |
| `SchedulerError` | experimental | 0.1.0 | Scheduler / hook subsystem failures |

### Generic concretes (7)

| Name | Tier | Since | Description |
|---|---|---|---|
| `SchemaValidationError(errors: list[str])` | experimental | 0.1.0 | Carries `.errors`; message: `"validation failed: ..."` |
| `AppConfigError` | experimental | 0.1.0 | Config file missing / malformed / unknown version |
| `CommandError(argv, returncode, stderr)` | experimental | 0.1.0 | Carries `.argv` / `.returncode` / `.stderr`; subprocess wrapper translation target |
| `ResourceNotFoundError(name: str)` | experimental | 0.1.0 | Carries `.name` |
| `ResourceAlreadyExistsError(name: str)` | experimental | 0.1.0 | Carries `.name` |
| `GuestUnreachableError` | experimental | 0.1.0 | Bare subclass; message in args |
| `GuestCommandError` | experimental | 0.1.0 | Bare subclass; message in args |
| `BootstrapError` | experimental | 0.3.0 | Subclass of `OperationError`. Raised by `bootstrap()` when a wiring step fails; carries `.failed_step` + chained cause. Closes FEEDBACK design ref §14.2 (transactional bootstrap). |
| `HostEnvironmentError` | experimental | 0.3.0 | Renamed from `EnvironmentError` to stop shadowing Python's built-in alias for `OSError`. Closes FEEDBACK API-01. The legacy `EnvironmentError` name remains as a deprecated alias (emits `MgfDeprecationWarning` on instantiation) until v1.0. |
| `CancellationError` | experimental | 0.3.0 | Subclass of `OperationError`. Raised by `CancellationToken.raise_if_cancelled()` (and the async sibling). Existing `except OperationError:` clauses catch it without code change. Default message: `"operation cancelled by user"`. |

**Total in `mgf.common.exceptions.__all__`: 18 names** (`EnvironmentError` is the deprecated alias — counted but emits warning).

---

## `mgf.common.config`

Typed configuration: `BaseAppSettings` + helpers + atomic loader/saver.

| Name | Tier | Since | Description |
|---|---|---|---|
| `BaseAppSettings` | experimental | 0.1.0 | pydantic-settings base. v0.3 subclass-kwarg pattern: `class S(BaseAppSettings, env_prefix="X_"):` (closes FEEDBACK API-06). The legacy `model_config = make_settings_config(env_prefix="X_")` shape still works. |
| `settings_config(**overrides) -> SettingsConfigDict` | experimental | 0.3.0 | v0.3 canonical name for building a `SettingsConfigDict` with the recommended baseline. Renamed from `make_settings_config` (which remains as a deprecated alias). |
| `make_settings_config(**overrides) -> SettingsConfigDict` | deprecated | 0.1.0 | Deprecated alias for `settings_config`. Emits `MgfDeprecationWarning` on call. Removed in v1.0. |
| `load_settings(cls, *, path=None, migrate=None) -> T` | experimental | 0.1.0 | Build a typed `Settings` from disk + env + defaults. Optional migration callback for schema bumps |
| `save_settings(cfg: BaseAppSettings, path: Path) -> None` | experimental | 0.1.0 | Atomic write (temp + rename, mode 0o600). v0.3: `BaseAppSettings.to_yaml_dict()` now recurses into nested sub-models (closes CB-06). |
| `platform_dir(kind: PathKind) -> Path` | experimental | 0.1.0 | Cross-OS XDG / macOS Application Support / Windows AppData resolution |
| `default_config_path(app: str | None = None) -> Path` | experimental | 0.1.0 | OS-aware default config path; uses `app_name()` if `app` is `None` |
| `expand_path(v: object) -> object` | experimental | 0.1.0 | Validator helper for `~` and `$VAR` expansion (lazy, per CF-04) |
| `PathKind` | experimental | 0.1.0 | `Literal["config", "state", "data"]` — the typed alias used by `platform_dir` |

### Pydantic re-exports (closes CB-04 — v0.3)

| Name | Tier | Since | Description |
|---|---|---|---|
| `BaseModel` | experimental | 0.3.0 | Re-exported `pydantic.BaseModel` for nested sub-model definitions inside `Settings` classes. |
| `ConfigDict` | experimental | 0.3.0 | Re-exported `pydantic.ConfigDict` for inner `model_config = ConfigDict(extra="forbid")` declarations on sub-models. |
| `Field` | experimental | 0.3.0 | Re-exported `pydantic.Field` for typed-field declarations with constraints (`Field(default=30, ge=1, le=600)`) and aliases. |
| `AliasChoices` | experimental | 0.3.0 | Re-exported `pydantic.AliasChoices` for renames-without-breaks (rule CF-11). |
| `field_validator` | experimental | 0.3.0 | Re-exported `pydantic.field_validator` for single-field validators. |
| `model_validator` | experimental | 0.3.0 | Re-exported `pydantic.model_validator` for cross-field / whole-model validators. |
| `ValidationError` | experimental | 0.3.0 | Re-exported `pydantic.ValidationError` — caught by consumers when validating user-supplied dicts via `Model.model_validate`. |

**Total in `mgf.common.config.__all__`: 16 names.**

---

## `mgf.common.observability`

Logging + tracing + crash reporting + redaction. Eight public names;
OpenTelemetry / Sentry deps live behind the `[observability]` extra.

| Name | Tier | Since | Description |
|---|---|---|---|
| `setup_logging(*, level="INFO", fmt="auto", log_file=None, redactor=None) -> None` | experimental | 0.1.0 | Single-point logging configuration. Console + rotating file by default; opt-in journald / OTLP / syslog / HTTP via env vars |
| `setup_otel(*, enabled=None) -> None` | experimental | 0.1.0 | Initialise the OpenTelemetry SDK + OTLP span exporter. No-op when SDK not installed or no endpoint configured |
| `operation_span(name: str, **attrs) -> ContextManager[None]` | experimental | 0.1.0 | Context manager wrapping a use case in a span. Safe to use even when OTel is disabled |
| `report_now(exc, *, source: str) -> Path` | experimental | 0.1.0 | Build, persist locally, and best-effort ship a crash report. Returns the local file path. NEVER raises |
| `install_excepthook() -> None` | experimental | 0.1.0 | Process-wide unhandled-exception hook; idempotent |
| `install_threading_excepthook() -> None` | experimental | 0.1.0 | Non-main-thread excepthook; idempotent |
| `Redactor` | experimental | 0.1.0 | Sensitive-field redaction policy used by the formatters. Frozen dataclass; thread-safe. Composes via `\|` (closes FEEDBACK PAPER-02). |
| `DEFAULT_REDACTION_KEYS` | experimental | 0.2.0 | The built-in secret-bearing key set, exposed as `frozenset[str]` so consumers can audit / extend without copy-paste. Closes FEEDBACK PAPER-02. |
| `LogFormat` | experimental | 0.1.0 | `Literal["text", "json", "auto"]` — the typed alias used by `setup_logging` |

### v0.3 closed-box wraps (closes CB-08, CB-12, CB-13)

| Name | Tier | Since | Description |
|---|---|---|---|
| `get_logger(name=None) -> logging.Logger` | experimental | 0.3.0 | Returns `logging.getLogger(name)` exposed through us so consumers don't `import logging`. Closes CB-08. |
| `get_current_span() -> Span | None` | experimental | 0.3.0 | Returns the active OTel `Span` or `None`. No-op-safe when OTel disabled. Closes CB-12. |
| `set_attribute(key, value) -> None` | experimental | 0.3.0 | Set an attribute on the current span. No-op when no span active. Closes CB-12. |
| `add_event(name, attributes=None, timestamp=None) -> None` | experimental | 0.3.0 | Add a named event to the current span. No-op when no span active. Closes CB-12. |
| `set_status(status, description="") -> None` | experimental | 0.3.0 | Set the current span's status (typically `SpanStatus(StatusCode.ERROR, "...")`). No-op when no span active. Closes CB-12. |
| `Span` | experimental | 0.3.0 | Re-exported `opentelemetry.trace.Span` (or `Any` sentinel when OTel not installed). Closes CB-12. |
| `SpanContext` | experimental | 0.3.0 | Re-exported `opentelemetry.trace.SpanContext`. |
| `SpanKind` | experimental | 0.3.0 | Re-exported `opentelemetry.trace.SpanKind`. |
| `SpanStatus` | experimental | 0.3.0 | Re-exported `opentelemetry.trace.Status` — renamed at our boundary because the bare name `Status` collides with too many other things in consumer code. |
| `StatusCode` | experimental | 0.3.0 | Re-exported `opentelemetry.trace.StatusCode` — values `OK` / `ERROR` / `UNSET` for span status. |

### v0.3 Phase 3 registries (closes API-07; pluggable extensibility)

| Name | Tier | Since | Description |
|---|---|---|---|
| `register_crash_sink(name)` | experimental | 0.3.0 | Decorator: register a custom crash-sink handler. Sink fires when its name appears in `MgfSettings.crash.sinks` (or via legacy `<APP>_CRASH_SINK` env var). Closes FEEDBACK API-07. |
| `unregister_crash_sink(name)` | experimental | 0.3.0 | Remove a registered crash sink. No-op if unknown. |
| `CrashSink` | experimental | 0.3.0 | Type alias: `Callable[[Path, dict[str, Any]], None]` — the crash-sink handler signature. |
| `register_log_handler(name)` | experimental | 0.3.0 | Decorator: register a custom log-handler factory. Activated via `MgfSettings.logging.extra_handlers` (full wiring lands in a later phase). |
| `unregister_log_handler(name)` | experimental | 0.3.0 | Remove a registered log handler. |
| `LogHandlerFactory` | experimental | 0.3.0 | Type alias: `Callable[[MgfSettings], logging.Handler]`. |
| `register_redaction_pattern_group(name)` | experimental | 0.3.0 | Decorator: register a named tuple of value-patterns. Activated via `MgfSettings.redaction.enabled_pattern_groups`. The "builtin" group is pre-registered. |
| `unregister_redaction_pattern_group(name)` | experimental | 0.3.0 | Remove a registered pattern group. |
| `PatternGroupFactory` | experimental | 0.3.0 | Type alias: `Callable[[], tuple[re.Pattern[str], ...]]`. |
| `register_span_processor(name)` | experimental | 0.3.0 | Decorator: register a custom OTel span-processor factory. Activated via `MgfSettings.otel.enabled_processors` (full wiring lands in a later phase). |
| `unregister_span_processor(name)` | experimental | 0.3.0 | Remove a registered span processor. |
| `SpanProcessorFactory` | experimental | 0.3.0 | Type alias: `Callable[[MgfSettings], SpanProcessor]`. |

**Total in `mgf.common.observability.__all__`: 31 names** (was 19; +12 from Phase 3 registries: 4 register_* + 4 unregister_* + 4 type aliases).

---

## `mgf.common.settings`

The library's own typed settings root (closes FEEDBACK design
ref §4.2 — single source of truth for every behavioural knob).
Phase 1 of the v0.3 redesign.

| Name | Tier | Since | Description |
|---|---|---|---|
| `MgfSettings` | experimental | 0.3.0 | Single typed root — composes `LoggingSettings` / `OtelSettings` / `CrashSettings` / `RedactionSettings` + `preset`. `BaseAppSettings` subclass with `env_prefix="MGF_"`. |
| `LoggingSettings` | experimental | 0.3.0 | Logging fields: level / format / file / journald / syslog_address / http_sink / rotating_max_bytes / rotating_backup_count / level_overrides. Closes FEEDBACK design ref §14.6 (per-component levels first-class). |
| `OtelSettings` | experimental | 0.3.0 | OTel fields: enabled / endpoint / service_namespace / sample_rate / resource_attributes / httpx_instrumented / subprocess_instrumented / metrics_enabled. |
| `CrashSettings` | experimental | 0.3.0 | Crash-reporter fields: sinks / sentry_dsn / otlp_endpoint / http_url / state_dir. Phase 3 will introduce the registry. |
| `RedactionSettings` | experimental | 0.3.0 | Redactor fields: extra_keys / extra_value_patterns / enabled_pattern_groups / strict_mode. Closes FEEDBACK design ref §14.12 (GDPR strict mode — Phase 6 wires the patterns). |
| `LogLevel` | experimental | 0.3.0 | `Literal["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"]` — stable type alias. |
| `LogFormat` | experimental | 0.3.0 | `Literal["text", "json", "auto"]` — moved here from `mgf.common.observability` (legacy alias still works). |
| `PresetName` | experimental | 0.3.0 | `Literal["explicit", "dev", "systemd", "docker", "auto"]` — preset selector. Phase 1 ships the seam; Phase 6 wires the preset semantics. |

| `VaultSettings` | experimental | 0.3.0 | Vault backend selection: `backend` (str, default `"env"`) + `config` (dict). Phase 5 keeps `config` an untyped dict; v0.4 ships a discriminated union. |

**Total in `mgf.common.settings.__all__`: 9 names.**

---

## `mgf.common.typing`

Closes FEEDBACK API-05. Single-source `Protocol` definitions for
every stable abstraction so consumers can pass duck-typed
objects (test doubles, custom impls) where the library accepts
the protocol. Phase 4 of the v0.3 redesign.

| Name | Tier | Since | Description |
|---|---|---|---|
| `CancellationProtocol` | experimental | 0.3.0 | Cooperative-cancellation contract: `cancel() -> None` + `is_cancelled() -> bool`. Concrete implementations: `CancellationToken` (sync) + `AsyncCancellationToken` (async). `runtime_checkable` so `isinstance(obj, CancellationProtocol)` works. |
| `ReporterProtocol` | experimental | 0.3.0 | Progress-reporter contract: `report(message, current=0, total=0) -> None` + `is_cancelled() -> bool`. Re-exported as `mgf.common.progress.ProgressReporter` for ergonomics. `runtime_checkable`. |
| `LogSinkProtocol` | experimental | 0.3.0 | Append-style log sink contract: `append_info(message)` + `append_error(message)`. For the future GUI helpers (Qt / Tk / Flet) — consumers in non-Qt frameworks implement this against their widget. `runtime_checkable`. |
| `VaultProtocol` | experimental | 0.3.0 | Credential-vault contract: `get / set / delete / list_keys` + `backend` property. Concrete implementations land in `mgf.common.vault` (Phase 5). `runtime_checkable`. |

**Total in `mgf.common.typing.__all__`: 4 names.**

---

## `mgf.common.progress`

Closes FEEDBACK API-03. Cooperative cancellation + progress-
reporting primitives lifted from VManager. Phase 4 of the v0.3
redesign.

| Name | Tier | Since | Description |
|---|---|---|---|
| `CancellationToken` | experimental | 0.3.0 | Thread-safe sync cancellation token. `cancel() / is_cancelled() / wait(timeout) / raise_if_cancelled()`. Backed by `threading.Event`. Implements `CancellationProtocol`. |
| `ProgressReporter` | experimental | 0.3.0 | Ergonomic alias for `mgf.common.typing.ReporterProtocol`. |
| `NullReporter` | experimental | 0.3.0 | No-op concrete impl of `ProgressReporter`. Optionally takes a `token=` parameter to forward `is_cancelled()` to a real cancellation token. |
| `RecordingReporter` | experimental | 0.3.0 | Test-double impl of `ProgressReporter`. Accumulates calls in `.calls: list[tuple[str, int, int]]` for assertions. `reset()` clears between sub-tests. |

**Total in `mgf.common.progress.__all__`: 4 names.**

### `mgf.common.progress.asyncio`

Async sibling submodule per the sync-first / async-adapter rule
(CLOSED_BOX_REDESIGN.md §14.1). Thin shim — never a duplicate
of the sync API.

| Name | Tier | Since | Description |
|---|---|---|---|
| `AsyncCancellationToken` | experimental | 0.3.0 | asyncio-native cancellation token. `cancel() / is_cancelled()` (sync) + `await wait(timeout)` (async) + `raise_if_cancelled()` (sync helper). Backed by `asyncio.Event`. Implements `CancellationProtocol`. Bound to a single event loop — NOT thread-safe across loops. |

**Total in `mgf.common.progress.asyncio.__all__`: 1 name.**

---

## `mgf.common.vault`

Closes FEEDBACK §3.2. Credential-storage backends. Three built-in
backends + a registry for custom ones (HashiCorp Vault, AWS
Secrets Manager). Phase 5 of the v0.3 redesign.

| Name | Tier | Since | Description |
|---|---|---|---|
| `EnvVault` | experimental | 0.3.0 | Stdlib-only env-var backend. Maps each key to `<prefix><KEY>` (uppercased; default prefix `"MGF_VAULT_"`). The right backend for CI / containerised deployments. Audit-logs every op per rule SC-17. |
| `KeyringVault` | experimental | 0.3.0 | System credential store via the `keyring` library (libsecret / Keychain / Credential Manager). Requires `mgf-common[vault]`. `service` parameter for the keyring service name (default `"mgf-common"`); consumer apps SHOULD override per rule SC-12. Tracks key index in a per-service `__mgf_index__` entry for portable `list_keys()`. |
| `EncryptedFileVault` | experimental | 0.3.0 | Fernet (AES-128 + HMAC-SHA256) encrypted JSON file. Key derivation: PBKDF2-HMAC-SHA256, 600 000 iterations (OWASP 2023 baseline per SC-05). 16-byte per-vault salt persisted in the file header. Atomic write per CF-04, `0o600` at-rest permissions. Requires `mgf-common[vault]`. |
| `register_vault_backend(name)` | experimental | 0.3.0 | Decorator: register a custom vault-backend factory. Built-in names (`"env"`, `"keyring"`, `"file"`) are pre-registered at import time. Closes the closed-box leak around third-party stores. |
| `unregister_vault_backend(name)` | experimental | 0.3.0 | Remove a registered vault backend. No-op if unknown. |
| `VaultBackendFactory` | experimental | 0.3.0 | Type alias: `Callable[[dict[str, Any]], VaultProtocol]`. The shape every registered factory implements. |

**Total in `mgf.common.vault.__all__`: 6 names.**

---

## `mgf.common.cli`

Top-level CLI helpers — stable exit-code constants + an exception
→ exit-code translator. Phase 5 of the v0.3 redesign.

### Exit-code constants (stable; numeric pin per rule API-04)

| Name | Tier | Since | Description |
|---|---|---|---|
| `EXIT_SUCCESS` | experimental | 0.3.0 | `0` — clean exit. |
| `EXIT_CONFIG_ERROR` | experimental | 0.3.0 | `1` — `ConfigError` family. |
| `EXIT_OPERATION_ERROR` | experimental | 0.3.0 | `2` — `OperationError` family (includes `CancellationError` and `BootstrapError` by default). |
| `EXIT_GUEST_ERROR` | experimental | 0.3.0 | `3` — `GuestError` family. |
| `EXIT_ENVIRONMENT_ERROR` | experimental | 0.3.0 | `4` — `HostEnvironmentError` family. |
| `EXIT_PROVIDER_ERROR` | experimental | 0.3.0 | `5` — `ProviderError` family (includes `ResourceNotFoundError` / `ResourceAlreadyExistsError`). |
| `EXIT_VAULT_ERROR` | experimental | 0.3.0 | `6` — `VaultError` family. |
| `EXIT_UNKNOWN` | experimental | 0.3.0 | `10` — untyped exception escaped to the top level. The catch-all branch ALSO ships a crash report via `report_now`. |

### Translator

| Name | Tier | Since | Description |
|---|---|---|---|
| `run_and_translate(main_fn, argv, *, exit_code_map=None, crash_source="cli") -> int` | experimental | 0.3.0 | Run `main_fn(argv)`; translate exceptions to exit codes via MRO walk. Untyped exceptions → `EXIT_UNKNOWN` + `report_now`. NEVER raises. |
| `translate_exceptions(*, exit_code_map=None, crash_source="cli")` | experimental | 0.3.0 | Decorator form of `run_and_translate`. The wrapped callable returns `int` (always the exit code). |
| `main_entry(main_fn, *, exit_code_map=None, crash_source="cli")` | experimental | 0.3.0 | Convenience: read `sys.argv`, translate, and `sys.exit`. The shortest possible top-level. |

**Total in `mgf.common.cli.__all__`: 11 names** (8 exit codes + 3 translator helpers).

### Console-script entry point (Phase 6b + Phase 7)

| Name | Tier | Since | Description |
|---|---|---|---|
| `mgf-common` (CLI command) | experimental | 0.3.0 | Console-script registered in `pyproject.toml`. Four subcommands: `explain` (renders active settings with per-field provenance — default / env / preset / init / file), `validate <config.yaml>` (schema-validate a YAML file against `MgfSettings`), `doctor` (install-state + wiring health checks), `migrate <from> <to> <path>` (regex-based codemod for v0.1 → v0.3 mechanical renames; per-rule import gates so it never over-applies). Exit codes per `mgf.common.cli` constants. |

The Python implementation modules (`mgf.common.cli._mgfcli` /
`_explain` / `_validate` / `_doctor` / `_provenance`) are private
(underscore-prefixed); consumers depend on the **CLI command**,
not the import paths. Programmatic use of the diagnostic
functions can be promoted to the public API on consumer demand
per rule SP-04 in `docs/standards/SCOPE.md`.

---

## Grand totals

| Package | Public names |
|---|---|
| `mgf.common` | 8 (7 in `__all__` + `__version__`) |
| `mgf.common.exceptions` | 18 (+1 `CancellationError` Phase 4) |
| `mgf.common.config` | 16 |
| `mgf.common.observability` | 31 |
| `mgf.common.settings` | 9 (+1 `VaultSettings` Phase 5) |
| `mgf.common.typing` | 4 (NEW Phase 4) |
| `mgf.common.progress` | 4 (NEW Phase 4) |
| `mgf.common.progress.asyncio` | 1 (NEW Phase 4) |
| `mgf.common.vault` | 6 (NEW Phase 5) |
| `mgf.common.cli` | 11 (NEW Phase 5) |
| **Total** | **108** (was 90 after Phase 4; +18 from Phase 5: 6 vault + 11 cli + 1 `VaultSettings`) |

---

## Notes on the experimental tier

Every public name in v0.1.0 is `experimental` per the 0.x window
convention. Promotion to `stable` happens release-by-release as
the early-consumer feedback in [`FEEDBACK.md`](FEEDBACK.md)
converges. The promotion path:

1. A name survives one full MINOR cycle without a 🔴 Blocker
   filed against it in [`FEEDBACK.md`](FEEDBACK.md).
2. The maintainer reviews the name's actual usage in the reference
   consumer (VManager) and confirms the shape is right.
3. The name moves from `experimental` to `stable` in the next
   release; this `PUBLIC_API.md`'s tier column updates; no code
   change required.

A name marked `stable` in a v1.x release follows the full deprecation
cycle (rule **AP-04**) — its removal happens only in a future MAJOR
release, with one MINOR cycle of `DeprecationWarning` survival.

## Notes on `EnvironmentError`

`mgf.common.exceptions.EnvironmentError` deliberately shadows the
Python builtin alias. This is documented in the source with a
`# noqa: A001` and is one of the 8 🔴 Blockers in
[`FEEDBACK.md`](FEEDBACK.md) (entry **API-01**) that need a pre-1.0
decision. The likely resolution is to rename to
`HostEnvironmentError` before v1.0; consumers will get a deprecation
alias for one MINOR cycle.

## Notes on the namespace package

`mgf` is a [PEP 420](https://peps.python.org/pep-0420/) implicit
namespace package. There is intentionally **no `__init__.py`** at
`src/mgf/` so future siblings (`mgf.cli`, `mgf.gui`) from other
repos can contribute their own subpackages under the same `mgf.*`
namespace. The hallmark: `import mgf; mgf.__file__` is `None`.

This shape is part of the public API in the sense that consumers
who want to add their own `mgf.<sibling>` module rely on it
working. It is pinned by `tests/unit/test_identity.py::test_namespace_package_shape`.

---

*See [`docs/standards/API_DESIGN.md`](docs/standards/API_DESIGN.md)
for the standard that defines what every column in this document
means.*
