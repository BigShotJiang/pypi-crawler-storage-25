# FEEDBACK.md — Early-Consumer Feedback & Roadmap

> **Living document.** Pre-1.0 design conversations between
> `mgf-common` maintainers and library consumers.
>
> **Format.** Each entry is a uniform block: identifier, status
> badge, severity, structured frontmatter, then prose. The format
> is optimised for both human readers and AI agents — every entry
> has the same shape, every status field is grep-able, every shipped
> entry carries the commit SHA that closed it.
>
> **Stakes.** A 🔴 Blocker raised here pre-1.0 is a minor commit. The
> same concern raised after v1.0 ships with N consumers is a
> breaking-change coordination exercise across the ecosystem.
>
> **Bar.** Industry-standard. The shape that any serious Python
> service / desktop / mobile project reaches for by default.

---

## Dashboard — current state

Status counts as of 2026-04-26:

| Bucket | Count | Notes |
|---|---|---|
| 🔴 Blocker — open | 6 | Need pre-1.0 decision; see §3 |
| 🟡 High — open | 5 | Quality-of-life; ship in 0.x |
| 🟢 Nice-to-have — open | 2 | Capacity-permitting |
| 💭 Aspirational | 4 | Roadmap input |
| ✅ Shipped this release | 5 | API-04, API-08, PAPER-01, PAPER-02, PAPER-05 |
| ❌ Rejected | 0 | — |
| 🟰 Deferred | 0 | — |

### Shipped table (audit trail at a glance)

| ID | Severity | Title | Closed by | Release |
|---|---|---|---|---|
| **API-04** | 🔴 | No `PUBLIC_API.md` | commit `61b340c` (PUBLIC_API.md) + `bd54476` (AP-10 pin tests) | unreleased / next 0.x |
| **API-08** | 🟡 | Silent wrong default when unconfigured | commit `<this round>` | unreleased / next 0.x |
| **PAPER-01** | 🟡 | Redactor missed common API-key shapes | commit `<this round>` | unreleased / next 0.x |
| **PAPER-02** | 🟢 | `Redactor` not composable across consumers | commit `<this round>` | unreleased / next 0.x |
| **PAPER-05** | 🟢 | `SchemaValidationError` prefix not overridable | commit `<this round>` | unreleased / next 0.x |

### Open blockers (sorted by ID)

| ID | Title | Decision required |
|---|---|---|
| **API-01** | Rename `EnvironmentError` → `HostEnvironmentError` | Yes / no on the rename + alias deprecation cycle |
| **API-02** | `configure()` is process-wide module state | Single-app / multi-tenant / hybrid (Option C recommended) |
| **API-03** | `CancellationToken` + `ProgressReporter` lift | Lift before SSH/service-manager land — yes / no |
| **API-05** | Protocol-typed interfaces | Lift `CancellationProtocol` / `ReporterProtocol` / `VaultProtocol` |
| **API-06** | `make_settings_config()` is a workaround | Option A (`__init_subclass__`) or Option B (rename + lint) |
| **API-07** | Crash-sink pluggability | Pluggable registry — yes / no |

---

## §1. Process

### 1.1 Submission

A consumer adds an entry by opening a PR that edits this file.
Every entry MUST follow the **§2 entry template** below — the
uniform shape is what makes the document machine-actionable.

### 1.2 Severity

| Level | Meaning | Pre-1.0 SLA |
|---|---|---|
| 🔴 **Blocker** | Getting it wrong requires a breaking change to fix later. MUST be decided before v1.0. | Triaged within the release cycle it lands in; decision recorded inline. |
| 🟡 **High** | Significant quality-of-life issue. Painful to live with, additive to add later. | Addressed as a 0.x minor/patch; no release gate. |
| 🟢 **Nice-to-have** | Real value, not urgent. | Picked up when a maintainer has capacity or a second consumer asks. |
| 💭 **Aspirational** | "Long-term where should this go" input. Not actionable today. | Kept for roadmap reviews; drives major-version planning. |

### 1.3 Status lifecycle

```
OPEN → ACCEPTED → SCHEDULED → SHIPPED
       ↓
       REJECTED   (with rationale)
       DEFERRED   (agreed in principle, not scheduled)
```

- **OPEN** — submitted, not yet triaged.
- **ACCEPTED** — maintainers agree; not yet scheduled.
- **SCHEDULED** — assigned a release (e.g., `0.2.0`).
- **SHIPPED** — landed; entry moves to §4 with commit SHA + retro.
- **REJECTED** — kept (not deleted) so future consumers don't re-raise.
- **DEFERRED** — agreed in principle, picked up at next roadmap review.

### 1.4 Entry template — every new entry MUST follow this shape

```markdown
### `<AREA>-<NN>` — One-line title

| Field | Value |
|---|---|
| Status | OPEN / ACCEPTED / SCHEDULED / SHIPPED / REJECTED / DEFERRED |
| Severity | 🔴 / 🟡 / 🟢 / 💭 |
| Submitter | <Project> (commit `<sha>` if applicable) |
| Submitted | YYYY-MM-DD |
| Decision | pending / accepted / rejected (one line) |
| Decided on | YYYY-MM-DD or `—` |
| Scheduled for | release tag or `—` |
| Shipped in | commit SHA + release tag, or `—` |

**Concern.** What's wrong or missing. One paragraph.

**Why it matters.** Why this affects real consumers. One paragraph.

**Suggested shape.** Concrete proposal — code snippet, prose, or
both. Not required to be the final answer; required to be a
starting point.

**Cost if deferred past v1.0.** The "why now" argument.

**Decision rationale.** Filled when triaged. Why accepted /
rejected / deferred / scheduled.

**Retrospective.** Filled when shipped. Did the suggested shape
survive contact with implementation? What changed and why?
```

The frontmatter table is the single source of truth for status.
Prose comes after.

### 1.5 Ground rules

- **Semver reality at 0.x.** Until v1.0, every 0.x minor MAY break
  the API. Consumers pinning `>=0.1.0,<0.2` accept this; consumers
  pinning `>=0.1.0,<1.0` opt into pre-1.0 churn. Aggressive 🔴
  Blocker resolution is the point of the 0.x window.
- **VManager is not a normal consumer.** It's the co-designed
  reference implementation. A "VManager-only" concern carries less
  signal than one another consumer would also hit. Filter
  accordingly.
- **Don't optimise for `mgf-common` developers.** Every design
  trade-off favours the consumer. A feature that saves the library
  author an hour but costs every consumer a day of integration
  pain is a net loss.

---

## §2. Open feedback (active)

Sorted by area, then ID. To add a new entry, copy §1.4's template
verbatim and fill it in.

### 🔴 Blockers (decide before v1.0)

#### `API-01` — Rename `EnvironmentError` → `HostEnvironmentError`

| Field | Value |
|---|---|
| Status | OPEN |
| Severity | 🔴 Blocker |
| Submitter | VManager (commit `0d26514`) |
| Submitted | 2026-04-23 |
| Decision | pending |
| Decided on | — |
| Scheduled for | v0.2.0 (target) |
| Shipped in | — |

**Concern.** `mgf.common.exceptions.EnvironmentError` deliberately
shadows Python's builtin `EnvironmentError` (an alias of `OSError`).
Consumers importing the name get a ruff/pylint `A001` violation
and must carry `# noqa: A001 — shadows builtin alias on purpose`
comments on every re-export.

**Why it matters.** Every consumer that uses this category will
either (a) live with lint suppressions forever, (b) rename on
import (`from mgf.common.exceptions import EnvironmentError as HostError`),
or (c) re-raise as a project-specific subclass. Options (a) and (b)
are papercuts that compound across projects; (c) defeats the point
of having a well-known category. A clean name avoids all three.

**Suggested shape.** Rename to `HostEnvironmentError`. The
rationale ("host-level pre-flight check failed: CPU lacks vmx,
kernel module missing, required binary absent") matches "host
environment" better than the bare "environment". Keep
`EnvironmentError` as a deprecated alias for one 0.x minor (per
rule **AP-04**) and remove at v1.0.

**Cost if deferred past v1.0.** Rename becomes a breaking change
coordinated across every consumer's `except EnvironmentError:`
call site. The ecosystem pressure to "just live with `# noqa: A001`
forever" becomes overwhelming.

---

#### `API-02` — `mgf.common.configure()` is process-wide module-level state

| Field | Value |
|---|---|
| Status | OPEN |
| Severity | 🔴 Blocker |
| Submitter | VManager |
| Submitted | 2026-04-23 |
| Decision | pending |
| Decided on | — |
| Scheduled for | — |
| Shipped in | — |

**Concern.** `_identity.py` stores `_APP_NAME` / `_APP_VERSION` as
module-level globals mutated by `configure()`. The docstring
explicitly rejects `contextvar` on the grounds that "different apps
in the same process is not a real use case for any consumer". That
assumption has not been validated yet — it's a prediction based on
one consumer.

**Why it matters.** Library-within-library is a real scenario. A
future plug-in system (e.g., a VManager plug-in that itself is a
`mgf-common` consumer with its own `app_name`) breaks this
assumption. Any consumer that runs test suites importing multiple
`mgf-common`-using projects in the same pytest process (think
monorepo) also breaks it. Test-isolation fixtures in `mgf-common`
itself already have to `configure("vmanager")` at module import to
get correct paths — that's a code smell pointing at the
global-state shape.

**Suggested shape.** Hybrid (Option C from §6 below):
- Keep `configure()` + module-level defaults as the convenience
  layer for the 95% case (single-app processes).
- Add `AppContext(app_name=..., app_version=...)` as a context
  manager for opt-in multi-tenancy.
- Every observability function resolves identity from the active
  `AppContext` if one is set, else the module-level global.
- At v1.0, document the "one-app-per-process" guarantee for the
  default path; multi-tenant consumers SHOULD use `AppContext`.

**Cost if deferred past v1.0.** The module-level global becomes
the only option forever. Any later attempt to add multi-tenancy
requires touching every observability entry point's signature.

---

#### `API-03` — Lift `CancellationToken` + `ProgressReporter` into `mgf-common`

| Field | Value |
|---|---|
| Status | OPEN |
| Severity | 🔴 Blocker |
| Submitter | VManager (`src/vmanager/common/progress.py`) |
| Submitted | 2026-04-23 |
| Decision | pending |
| Decided on | — |
| Scheduled for | v0.2.0 (target — gates §5.3 SSH lift) |
| Shipped in | — |

**Concern.** VManager owns `CancellationToken` + `ProgressReporter`
— two abstractions every long-running `mgf-common` component will
need. The upcoming SSH module (§5.3 below), service manager (§5.4),
retry module (§5.5), and any async I/O helper all need to cooperate
with cancellation. Right now each invents its own token or depends
on a consumer-provided one.

**Why it matters.** If `mgf-common` ships SSH / service-manager
against its own internally-defined cancellation primitive AND a
consumer already has one, the consumer either bridges the two
types (adapter layer) or migrates its callers. If VManager's
`CancellationToken` IS the one that gets lifted, every future
`mgf-common` feature cooperates cleanly with every consumer's
existing token.

**Suggested shape.** Lift into `mgf.common.progress` BEFORE
shipping any new upstream feature that needs cancellation:
- `CancellationToken` — threading-friendly,
  `cancel() / is_cancelled() / wait(timeout)`.
- `ProgressReporter` — `Protocol` (not a class).
- `RecordingReporter` — test double.
- `NullReporter` — no-op for callers that don't care.
- Async adapter: `mgf.common.progress.asyncio` bridging to
  `asyncio.Event`.
- Qt adapter: lives in the Qt-helpers package (§5.9 below),
  bridges `ProgressReporter` to a `QThread` signal.

**Cost if deferred past v1.0.** Any later move either (a) forks
the ecosystem into "pre-1.0 consumer tokens" vs "post-1.0
mgf-common tokens", or (b) forces every consumer to migrate.
Neither is acceptable.

---

#### `API-05` — Protocol-typed interfaces for core concepts

| Field | Value |
|---|---|
| Status | OPEN |
| Severity | 🔴 Blocker (for `CancellationProtocol`, `ReporterProtocol`, `VaultProtocol`); 🟡 High for the others |
| Submitter | VManager |
| Submitted | 2026-04-23 |
| Decision | pending |
| Decided on | — |
| Scheduled for | — |
| Shipped in | — |

**Concern.** Every core concept in `mgf-common` is a concrete class:
`BaseAppSettings` (abstract-ish base), `AppError` (base exception),
`Redactor` (concrete class). Consumers who want to mock or swap
implementations subclass, which couples them to internals.

**Why it matters.** PEP 544 `Protocol` interfaces let consumers pass
any duck-typed object. Critical for testing AND for the "provider
ABC" design (rule **DP-02**) the standards mandate. Without them,
VManager rolled its own `LogSink` protocol locally. Every future
consumer will roll their own variant.

**Suggested shape.** Ship `mgf.common.typing` with `Protocol` types
for every stable abstraction:

```python
class CancellationProtocol(Protocol):
    def is_cancelled(self) -> bool: ...
    def cancel(self) -> None: ...

class ReporterProtocol(Protocol):
    def report(self, message: str, current: int = 0, total: int = 0) -> None: ...
    def is_cancelled(self) -> bool: ...

class LogSinkProtocol(Protocol):
    def append_info(self, message: str) -> None: ...
    def append_error(self, message: str) -> None: ...

class VaultProtocol(Protocol):
    def get(self, key: str) -> str | None: ...
    def set(self, key: str, value: str) -> None: ...
    def delete(self, key: str) -> None: ...
```

Consumers use these in their own type hints; `mgf-common`'s own
code accepts them where the concrete class is currently demanded.

**Cost if deferred past v1.0.** Adding `Protocol`s later is
non-breaking if used to RELAX an argument type. But if the
codebase has solidified around "pass the concrete `Redactor`",
the test ergonomics are already frozen and painful to change.

---

#### `API-06` — `make_settings_config()` is a workaround, not a primitive

| Field | Value |
|---|---|
| Status | OPEN |
| Severity | 🔴 Blocker (decision between A and B) |
| Submitter | VManager |
| Submitted | 2026-04-23 |
| Decision | pending |
| Decided on | — |
| Scheduled for | — |
| Shipped in | — |

**Concern.** The docstring in `mgf.common.config._settings` explains
that `**BaseAppSettings.model_config` spread fails with
`TypeError: got multiple values for keyword argument 'env_prefix'`.
The helper exists to work around that. The pattern *leaks
pydantic's `SettingsConfigDict` materialisation behaviour to every
consumer*.

**Why it matters.** The consumer has to know to use
`make_settings_config(env_prefix="...")` instead of the obvious
spread. If they get it wrong, they get a cryptic pydantic-internals
error at import time. Every new consumer discovers it via pain
the first time.

**Suggested shape — pick one before v1.0:**

- **Option A (preferred)** — make `BaseAppSettings` use a custom
  `__init_subclass__` that validates / merges `model_config`
  automatically. Subclasses just declare:
  ```python
  class AppConfig(BaseAppSettings, env_prefix="VMANAGER_"):
      ...
  ```
  No helper call. The subclass-kwarg pattern is standard Python.

- **Option B** — rename `make_settings_config` to `settings_config`
  (fewer syllables) and document it as THE canonical way. Add a
  ruff/lint rule that warns on the `**BaseAppSettings.model_config`
  spread.

**Cost if deferred past v1.0.** Option A requires changing the
consumer-facing subclass pattern, which IS a breaking change.
Must land before v1.0 if at all.

---

#### `API-07` — Crash-sink pluggability

| Field | Value |
|---|---|
| Status | OPEN |
| Severity | 🔴 Blocker (decide architecture; implementation can lag) |
| Submitter | VManager |
| Submitted | 2026-04-23 |
| Decision | pending |
| Decided on | — |
| Scheduled for | — |
| Shipped in | — |

**Concern.** `mgf.common.observability.crash_reporter` supports
three hardcoded remote sinks (Sentry, OTLP, HTTP webhook) via the
`<APP>_CRASH_SINK` env var. Enterprise consumers will want Slack
webhooks, PagerDuty events, custom on-premise endpoints. Today
they'd either fork or write a post-hoc `report_now` wrapper.

**Why it matters.** Crash-sink choice is an operational, not an
engineering, decision. Consumers should be able to register a
custom sink without modifying `mgf-common` source.

**Suggested shape.** Pluggable registry:

```python
from mgf.common.observability import register_crash_sink

@register_crash_sink("my-slack")
def ship_to_slack(report_path: Path, payload: dict) -> None:
    ...
```

The env-var resolver (`<APP>_CRASH_SINK=my-slack`) looks up the
registry before falling back to the builtin list. Ships with
Sentry / OTLP / HTTP preregistered.

**Cost if deferred past v1.0.** The env-var-to-sink mapping in
the source code is load-bearing. Changing from "hardcoded
dispatch" to "registry dispatch" is non-breaking at the public-API
level but invasive internally.

---

### 🟡 Papercuts (fix in 0.x)

#### `PAPER-03` — Observability shim pattern is load-bearing but undocumented

| Field | Value |
|---|---|
| Status | OPEN |
| Severity | 🟡 High (doc, not code) |
| Submitter | VManager |
| Submitted | 2026-04-23 |
| Decision | pending |
| Decided on | — |
| Scheduled for | — |
| Shipped in | — |

**Concern.** VManager ships `src/vmanager/observability/__init__.py`
as a re-export shim over `mgf.common.observability`. The shim
exists for source-compat (code written pre-Round-5 still works),
but it ALSO enables the consumer to layer in its own redactor /
formatter / handler extensions without forking `mgf.common`. This
pattern is valuable but nowhere documented as recommended practice.

**Why it matters.** A future consumer evaluating the architecture
will either (a) miss the pattern entirely and either fork or live
with limited extensibility, or (b) discover it by reading
VManager's source — neither is the right onboarding shape for an
industry-standard library.

**Suggested shape.** Add a section to
`docs/standards/COMMON_COMPONENTS.md` or a new
`docs/patterns/shim-layering.md` explaining: (a) why a consumer
might want a shim even without legacy call sites, (b) the
`import-linter` contract that keeps the shim from re-entangling,
(c) how to layer consumer-specific redactor extensions on top.
VManager's `tests/unit/test_logging_perf.py` is the canonical
consumer-side-guard example that exercises the shim.

**Cost if deferred past v1.0.** Docs grow piecemeal; the
shim-layering pattern stays tribal knowledge. No code-breakage
risk.

---

#### `PAPER-04` — Schema-versioning patterns are not reusable

| Field | Value |
|---|---|
| Status | OPEN |
| Severity | 🟡 High |
| Submitter | VManager |
| Submitted | 2026-04-23 |
| Decision | pending |
| Decided on | — |
| Scheduled for | — (see §5.11 roadmap) |
| Shipped in | — |

**Concern.** Every sub-config file in VManager (hooks, schedules,
alerts, lab specs, profiles) implements the same shape:
`version: int` + unknown-key rejection + migration callback +
atomic write. The code is duplicated across ~6 modules because
`mgf.common.config.BaseAppSettings` covers only the top-level
config file, not satellite files.

**Why it matters.** Real code duplication cost (~600 LOC in
VManager alone); will replicate in every consumer. Each instance
also drifts subtly (slightly different error wording, slightly
different migration shape) — exactly the bit-rot the standards
exist to prevent.

**Suggested shape.** Ship `mgf.common.versioned` with a
`VersionedFileStore[T]` generic that captures the pattern once.
Consumers register a pydantic model as the schema, a
`current_version` constant, and a `migrate(raw, from_version) -> dict`
callback. The store handles load + validate + migrate + save +
atomic-write + unknown-key-reject.

**Cost if deferred past v1.0.** Every consumer keeps re-deriving
the pattern; cross-consumer compliance audits become a fool's
errand because each has its own implementation.

---

#### `PAPER-06` — `docs/standards/` repeatedly says "AS-IS in VManager"

| Field | Value |
|---|---|
| Status | OPEN |
| Severity | 🟡 High (doc refactor) |
| Submitter | VManager |
| Submitted | 2026-04-23 |
| Decision | pending |
| Decided on | — |
| Scheduled for | — |
| Shipped in | — |

**Concern.** Every topic doc has "AS-IS in VManager" paragraphs
citing specific file:line locations. These rot as VManager evolves.
When the second consumer arrives, these paragraphs become
confusing ("wait, is that the reference example or an accident?").
The "📦 Post-extraction note" banners help but don't prevent
further rot.

**Why it matters.** The standards docs are the public face of the
project. Consumer-specific examples cluttering the cross-project
standard creates a perception that the standards are
VManager-shaped rather than industry-shaped — which undermines
the cornerstone-library positioning.

**Suggested shape.** Move every "AS-IS in VManager" paragraph to a
dedicated `docs/reference-consumer/` subfolder, cross-linked from
the standards. When a second consumer arrives, generalise to
`docs/reference-consumers/VManager.md` /
`docs/reference-consumers/ProjectX.md` etc. Standards stay
consumer-neutral.

**Cost if deferred past v1.0.** Cumulative doc rot; second
consumer arrives to a documentation set that visibly favours
VManager.

---

### 🟢 Nice-to-have

(Currently empty — PAPER-02 (`Redactor` composability) and PAPER-05
(prefix-override) shipped this round; see §4.)

---

### 💭 Aspirational

#### `ASPIRE-01` — "Multi-consumer process" as an explicit design choice

| Field | Value |
|---|---|
| Status | OPEN |
| Severity | 💭 Aspirational |
| Submitter | VManager |
| Submitted | 2026-04-23 |
| Decision | pending (entangled with API-02 above) |
| Decided on | — |
| Scheduled for | — |
| Shipped in | — |

**Concern.** Pre-condition: see API-02. The module-level identity
store assumes "one app per process". True for desktop apps,
mobile apps, most CLIs. NOT true for plug-in architectures,
monorepos where pytest imports multiple consumer projects, or
long-running services that embed `mgf-common` consumers as
sub-components (e.g., a Jupyter kernel + a telemetry pipeline).

**Why it matters.** Decide whether `mgf-common` explicitly supports
or explicitly forbids multi-tenancy. Silence is the worst option
— consumers who hit it discover the assumption via pain.

**Suggested shape.** See API-02 + §6 below. Recommendation: hybrid
`AppContext`.

**Cost if deferred past v1.0.** Design conversation that affects
1.0 stability commitments. Resolve before lock-in.

---

## §3. Roadmap features (5.x in the prior layout)

These are features VManager (and likely future consumers) would
like to see in `mgf-common`. Each entry is severity-tagged. The
shape is identical to the §2 entries above so triage / scheduling
flows the same way.

For brevity, the full feature designs are kept in their original
form below — the format restructuring above does not extend to
this section yet (a future edit will make every roadmap row a
proper §1.4 entry).

### 3.1 🔴 Lift `CancellationToken` + `ProgressReporter` (`API-03`)

See API-03 above. Blocker for SSH (3.3), service manager (3.4),
retry (3.5), and any cancellable async I/O.

**Module:** `mgf.common.progress`. Migration: `vmanager.common.progress`
becomes a re-export shim. Zero caller changes.

### 3.2 🔴 Vault abstraction

**Blocker for:** §3.3 (SSH needs credentials).

**Design:** `mgf.common.vault` ships `VaultProtocol` +
`KeyringVault` (libsecret/Keychain/Credential Manager + Fernet
file fallback) + `EnvVault` (read `<APP>_VAULT_<KEY>` for CI) +
`FileVault` (Fernet-encrypted file as standalone backend).

**Open questions:** key→value vs structured records (recommend
key→value); cross-process file-locking on the file backend (yes,
via `fcntl.flock` / `msvcrt.locking`); rotation versioning (defer
to consumer for v1).

### 3.3 🔴 SSH / remote-host management

**Module:** `mgf.common.ssh`. ABC + `ParamikoProvider` (default) +
`OpenSSHProvider` (subprocess-based; no paramiko dep). Connection
pool optional.

**Open design questions:** sync / async (recommend sync-only for
0.x, add async if a consumer asks); ProxyJump support (yes — add
to the pool key); credential plumbing (via §3.2 Vault).

### 3.4 🟡 Service management (cross-platform)

**Module:** `mgf.common.service`. `ServiceManager` ABC +
`SystemdUserManager` / `SystemdSystemManager` /
`LaunchdManager` / `WindowsServiceManager`. `detect()` factory
chooses the right backend.

**Key principle:** cross-platform from day 1. Ship 0.x with only
SystemdUserManager working but the public `ServiceSpec` /
`TimerSpec` shape locked in for the full set.

### 3.5 🟡 Retry / backoff module

**Module:** `mgf.common.retry`. `RetryPolicy` dataclass + `@retry`
decorator + cancellation-aware (consults `CancellationToken`
between attempts). Implements rule **EH-11** (exponential backoff
+ full jitter + finite cap).

### 3.6 🟡 Metrics signal (OTel third pillar)

**Module:** `mgf.common.observability.metrics`. `setup_metrics()`
configures `MeterProvider`; `meter(__name__)` returns an OTel
`Meter`. Symmetric with `setup_otel()`.

### 3.7 🟡 Reusable test fixtures

**Module:** `mgf.common.testing`. Ships `isolated_logging`,
`isolated_identity`, `captured_spans`, `fake_vault`,
`cancel_after_ticks`, `MockTransport`. Every consumer re-derives
these today; lift them centrally.

### 3.8 🟡 CLI integration helpers

**Module:** `mgf.common.cli`. `EXIT_*` constants + `run_and_translate(...)`
+ `@translate_exceptions` decorator. Closes the ~60-line
duplication every CLI consumer does.

### 3.9 🟡 GUI integration helpers (Qt)

**Module:** `mgf.common.gui.qt` (optional `[qt]` extra; pulls
PySide6). `CoreWorker(QThread)` + `install_qt_handlers` + `LogSink`
protocol + `LogDock` + `LogViewerDialog` + `ProgressToSignalBridge`.

### 3.10 🟡 Application lifecycle manager

**Module:** `mgf.common.lifecycle`. `app_lifecycle(app_name=...,
app_version=..., ...)` context manager wires `configure` →
excepthooks → logging → OTel in the right order, cleans up on
exit. Closes the ~20-LOC duplication per entry point.

### 3.11 🟡 Versioned file-store abstraction

See `PAPER-04`. ~600 LOC in VManager alone; replicates in every
consumer. The single biggest duplication today.

### 3.12 🟢 Containerised-deployment paths

`platform_dir(mode="auto" | "user" | "system")` honours
container conventions (`/etc/app/`, `/var/lib/app/`).

### 3.13 🟢 i18n of error messages

`mgf.common.exceptions` grows a `_localise(msg, **vars)` hook.
Defer until a non-English consumer arrives.

### 3.14 🟢 Benchmark harness

`mgf-common-bench` console-script. Micro-benchmarks for log
emission / span creation / config load / redaction. Lets consumers
spot regressions BEFORE upgrading.

### 3.15 🟢 Cookiecutter starter template

`cookiecutter gh:magogi-admin/mgf-common-starter` scaffolds a
minimal CLI + GUI + tests + CI setup using best practices.

### 3.16 💭 Migration codemod

`mgf-common migrate <version> <path>` does AST rewrites for
breaking changes (e.g., `EnvironmentError` → `HostEnvironmentError`).

---

## §4. Shipped (closed feedback — audit trail)

Every entry that has shipped, with commit SHA + release tag +
one-line retrospective. New shipped entries are appended; never
removed.

### `API-04` — Stable public API boundary + `PUBLIC_API.md`

| Field | Value |
|---|---|
| Status | ✅ SHIPPED |
| Severity | 🔴 Blocker |
| Submitter | VManager |
| Submitted | 2026-04-23 |
| Decision | accepted in full |
| Decided on | 2026-04-25 |
| Scheduled for | unreleased / next 0.x |
| Shipped in | commit `61b340c` (PUBLIC_API.md created) + `bd54476` (AP-10 pin tests) |

**Retrospective.** Suggested shape (`PUBLIC_API.md` per-name table
with stability tier) survived implementation cleanly. Added more
than the suggestion: an `AP-10` MUST in the new
`docs/standards/API_DESIGN.md` standard plus a parameterised pin
test (`tests/unit/test_public_api_doc.py`) that asserts every
name in every public `__all__` MUST appear in `PUBLIC_API.md` —
adding a public name without a doc row now fails CI.
Also added `AP-13` (`__version__` in sync with `pyproject.toml`)
plus its pin test as adjacent quality.

---

### `API-08` — `app_name()` returns `"app"` when unconfigured (silent wrong default)

| Field | Value |
|---|---|
| Status | ✅ SHIPPED |
| Severity | 🟡 High (additive, not breaking) |
| Submitter | VManager |
| Submitted | 2026-04-23 |
| Decision | accepted (UserWarning shape per the original suggestion) |
| Decided on | 2026-04-26 |
| Scheduled for | unreleased / next 0.x |
| Shipped in | commit `<this round>` |

**Retrospective.** Suggested shape (`UserWarning` once per process)
survived. Implemented as `mgf.common.UnconfiguredWarning`
(subclass of `UserWarning`) — a dedicated class lets consumers
filter it specifically (`warnings.filterwarnings("error",
category=UnconfiguredWarning)` for the loud-by-choice path)
without breaking transitive imports. One-shot guard prevents log
spam. Tests at `tests/unit/test_identity.py::test_unconfigured_warning_*`
pin: (1) fires once on first read; (2) silent after `configure()`;
(3) is a `UserWarning` subclass.

---

### `PAPER-01` — Extended Redactor value-pattern set

| Field | Value |
|---|---|
| Status | ✅ SHIPPED |
| Severity | 🟡 High (additive) |
| Submitter | VManager |
| Submitted | 2026-04-23 |
| Decision | accepted |
| Decided on | 2026-04-26 |
| Scheduled for | unreleased / next 0.x |
| Shipped in | commit `<this round>` |

**Retrospective.** Suggested shape (extend value-regex set with
common API-key shapes) survived. Added five patterns:
`_OPENAI_KEY_RE` (`sk-...`), `_GITHUB_TOKEN_RE` (`gh{p,o,u,s,r}_...`),
`_AWS_ACCESS_KEY_RE` (`AKIA...`), `_SLACK_TOKEN_RE` (`xox[baprs]-...`),
`_GOOGLE_API_KEY_RE` (`AIza...`). Each pattern is anchored on the
issuer's prefix so false positives on unrelated random strings
are minimal. Tests in
`tests/unit/observability/test_redaction.py::test_paper_01_*`
parameterise over all five.

---

### `PAPER-02` — Redactor compose via `|` + `DEFAULT_REDACTION_KEYS` public

| Field | Value |
|---|---|
| Status | ✅ SHIPPED |
| Severity | 🟢 Nice-to-have |
| Submitter | VManager |
| Submitted | 2026-04-23 |
| Decision | accepted (both sub-suggestions) |
| Decided on | 2026-04-26 |
| Scheduled for | unreleased / next 0.x |
| Shipped in | commit `<this round>` |

**Retrospective.** Both suggested shapes shipped. `Redactor.__or__`
returns a new redactor with the union of `extra_keys` + the
concatenation of `extra_value_patterns` (the built-in patterns
fire once via `_BUILTIN_VALUE_PATTERNS` regardless). Plus
`DEFAULT_REDACTION_KEYS` exposed as a public `frozenset` so a
plug-in author can audit "what's already covered" before declaring
their own extras. Tests in
`tests/unit/observability/test_redaction.py::test_paper_02_*`.

---

### `PAPER-05` — `SchemaValidationError` prefix as class attribute

| Field | Value |
|---|---|
| Status | ✅ SHIPPED |
| Severity | 🟢 Nice-to-have |
| Submitter | VManager |
| Submitted | 2026-04-23 |
| Decision | accepted |
| Decided on | 2026-04-26 |
| Scheduled for | unreleased / next 0.x |
| Shipped in | commit `<this round>` |

**Retrospective.** Suggested shape (`_MESSAGE_PREFIX` class
attribute) shipped. Subclasses now override the prefix without
bypassing `SchemaValidationError.__init__` — the
`SpecValidationError` ugly-`AppError.__init__`-skip pattern in
VManager can be removed at the next consumer cleanup. Test at
`tests/unit/test_exceptions_base.py::TestSchemaValidationError::test_paper_05_subclass_overrides_message_prefix`.

---

## §5. Rejected (audit trail)

Empty today. When a feedback entry is rejected, the §1.4 template
plus a "**Rejection rationale**" paragraph stays here forever so
the same concern doesn't get re-raised by future consumers.

---

## §6. The multi-tenancy decision (companion to API-02)

This is the hardest unresolved design question and is captured
here in full so the trade-offs survive even if `API-02`'s
scheduling slips.

**Option A — "One app per process, explicit."**
- Pro: simple, fast (no contextvar lookup), matches 95% of real use.
- Con: forecloses on library-in-library architectures forever.

**Option B — Per-consumer `AppContext` (full contextvar).**
- Pro: supports every use case.
- Con: every observability function pays a contextvar lookup;
  surface-area doubles (every API needs a sibling that takes a
  context arg).

**Option C — Hybrid (RECOMMENDED).**
- Module-level globals for the default; `AppContext` as opt-in
  override. Observability resolves via the active context if any,
  else the global.
- Pro: zero overhead for the 95% case; extension available for the
  5%.
- Con: two paths to reason about (acceptable: the second path is
  documented as a power-user escape hatch).

**Decision required before v1.0.** A 1.0 lock without a decision
on multi-tenancy means the answer becomes whatever the v1.0 code
happened to do — and the answer cannot change without breaking.

---

## §7. Reviewer's honest meta-feedback

Unvarnished personal view from the co-author of VManager /
co-integrator with mgf-common. Take or leave. No frontmatter — these
aren't actionable items, they're trajectory observations.

1. **`mgf-common` is more ambitious than its size suggests.** 18
   source files, 238 tests. Small today; ambition (industry-standard
   Python infrastructure library) is enormous. Every decision should
   be made with "what would I do if this had 100 consumers" in mind.

2. **The reference-consumer model is a double-edged sword.**
   VManager being co-designed gives `mgf-common` a starting
   advantage but biases every decision toward "this works for
   VManager". A second consumer's audit will surface assumptions
   VManager can't see. **Recommendation: don't lock 1.0 until a
   second consumer has audited.** Even a single-file utility that
   uses `mgf.common.config` only would surface assumptions.

3. **The standards docs are heroic and 100% aimed at humans.** The
   "Rules box" pattern is great. But industry-standard also means
   machine-readable: the MUST/SHOULD/MAY set should be extractable
   as a JSON schema so a consumer's CI can run `mgf-common-lint`
   for a structured pass/fail report.

4. **The manual twine-upload release flow is a latent risk.**
   Mentioned in `COMMON.md` §8. For an industry-standard library,
   plan the path to GPG-signed releases + SLSA provenance + a
   release branch requiring second-maintainer sign-off. Not urgent,
   but plan.

5. **Security posture is now declared (was a gap; closed).** Ship of
   `SECURITY.md` (root) + `docs/standards/SECURITY.md` (engineering
   standard) + threat-model template addresses what was originally
   a 🔴 Blocker observation. Status: addressed in earlier rounds.

6. **The "cornerstone rhythm" doc is the highest-leverage content
   in the standards today.** It captures something most libraries
   never articulate. Real audience is library AUTHORS, not
   consumers. Consider spinning into a separate
   `docs/for-library-authors/` track or a blog post to bootstrap
   the community.

7. **The extraction-to-mgf-common story is compelling and should
   be the headline.** Most projects either fail to extract
   accumulated infrastructure or extract poorly. The
   `COMMON.md` + `docs/CLAUDE.md` combination IS a documented
   worked example of doing it right. Front-and-centre in the
   README would signal maturity that a greenfield project can't.

---

## §8. How future consumers submit feedback

When a second project starts using `mgf-common`:

1. Open a PR adding entries under §2 (or §3 for roadmap items).
2. Use the §1.4 template verbatim — the uniform shape is what
   makes the document machine-actionable.
3. Pick a fresh ID prefix (`API-NN` continuing the sequence, or a
   new area like `SSH-NN`, `VAULT-NN` once those modules exist).
4. Triage happens in the PR thread. The decision (accepted /
   rejected / deferred / scheduled) lands in the entry's
   `Decision` field.
5. When shipped, the entry moves to §4 with commit SHA + release
   tag + one-line retrospective.
6. Rejected entries stay in §5 forever — recording "we considered
   this and said no, because..." is higher-leverage than recording
   only what shipped.

---

## §9. Cross-references

- Engineering standards: [`docs/standards/README.md`](docs/standards/README.md) (8 topic docs).
- Standards compliance audit: [`docs/STANDARDS_COMPLIANCE.md`](docs/STANDARDS_COMPLIANCE.md).
- Public-API contract: [`PUBLIC_API.md`](PUBLIC_API.md) (the AP-10 contract).
- Vulnerability-reporting policy: [`SECURITY.md`](SECURITY.md) (the SC-12 contract).
- Reference consumer's compliance tracker: [VManager `docs/STANDARDS_COMPLIANCE.md`](https://codeberg.org/magogi-admin/VManager/src/branch/master/docs/STANDARDS_COMPLIANCE.md).
- Maintainer's dense-lookup doc: [`docs/CLAUDE.md`](docs/CLAUDE.md).

---

*Format v2 — restructured 2026-04-26 for AI-actionability:
per-entry frontmatter table + dashboard at top + shipped-entries
audit trail. Original format (prose-organised by severity within
consumer) preserved in git history at commit `bd54476`.*
