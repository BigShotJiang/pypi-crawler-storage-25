"""Layer 1 — A tiny full app: configure → setup_logging → do work.

The minimum viable app shape: identity, logging setup, one
function that does work. Everything else (config, OTel, crash
reporting) is layered on top in the practical/advanced examples.
"""

from __future__ import annotations

import logging
import os
import tempfile
from pathlib import Path

import mgf.common
from mgf.common.observability import setup_logging


def do_thing() -> str:
    """The application's actual work."""
    LOG = logging.getLogger(__name__)
    LOG.info("doing the thing")
    return "done"


def main() -> None:
    with tempfile.TemporaryDirectory() as tmp:
        os.environ["XDG_STATE_HOME"] = tmp

        mgf.common.configure(app_name="myapp", app_version="0.1.0")
        setup_logging(level="INFO", log_file=Path(tmp) / "myapp.log")

        result = do_thing()
        print(f"result: {result!r}")


if __name__ == "__main__":
    main()
