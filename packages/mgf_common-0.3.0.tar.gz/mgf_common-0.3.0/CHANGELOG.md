# Changelog

All notable changes to `mgf-common` will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

For the version-bump workflow + scope policy (what counts as a major
vs minor change in the 0.x series), see
[`COMMON.md`](COMMON.md) §8.3 + §8.4.

## [Unreleased]

*(no changes since v0.3.0)*

## [0.3.0] — 2026-04-28

The **v0.3.0 closed-box reshape** lands every change accumulated
across Phases 1-7 of the redesign documented in
[`docs/CLOSED_BOX_REDESIGN.md`](docs/CLOSED_BOX_REDESIGN.md). One
release tag covers eight commits of work over multiple sessions;
each Phase is independently reviewable and the library was
releasable after each one.

**Headlines:**

- **`bootstrap()` replaces the v0.1 five-call sequence** —
  transactional with LIFO rollback, idempotent, dual-mode (`with`
  block OR `ctx = bootstrap(...)`). The v0.1 calls
  (`configure` + `setup_logging` + `setup_otel` +
  `install_excepthook` + `install_threading_excepthook`) still
  work; each emits `MgfDeprecationWarning`. (Phase 1)

- **`MgfSettings`** — the library's own typed settings root.
  Sub-models for logging / OTel / crash / redaction / vault.
  Five behavioural presets (`explicit` / `dev` / `systemd` /
  `docker` / `auto`); `auto` preserves v0.1 detection so legacy
  consumers see identical behaviour. (Phase 1, Phase 6a)

- **Closed-box wraps for the leaks identified in §3 of the
  redesign doc** — `mgf.common.config` re-exports pydantic
  primitives (`BaseModel`, `ConfigDict`, `Field`,
  `AliasChoices`, `field_validator`, `model_validator`,
  `ValidationError`); `mgf.common.observability` re-exports
  `get_logger`, OTel types (`Span`, `SpanContext`, `SpanKind`,
  `SpanStatus`, `StatusCode`), and OTel helpers
  (`get_current_span`, `set_attribute`, `add_event`,
  `set_status`). Consumers no longer reach past the library
  boundary for normal authoring. (Phase 2)

- **Five registries** for pluggable extensibility —
  `register_crash_sink`, `register_log_handler`,
  `register_redaction_pattern_group`, `register_span_processor`,
  `register_vault_backend`. Built-in names pre-registered;
  consumers extend without forking. Closes FEEDBACK API-07.
  (Phase 3, Phase 5)

- **`mgf.common.typing` Protocols** for stable abstractions —
  `CancellationProtocol`, `ReporterProtocol`,
  `LogSinkProtocol`, `VaultProtocol`. Closes FEEDBACK API-05.
  (Phase 4)

- **`mgf.common.progress`** — sync `CancellationToken` +
  `NullReporter` / `RecordingReporter`; async sibling at
  `mgf.common.progress.asyncio.AsyncCancellationToken`. Lifted
  from VManager. Closes FEEDBACK API-03. (Phase 4)

- **`mgf.common.vault`** — three credential-storage backends:
  `EnvVault` (stdlib-only), `KeyringVault` (system credential
  store, requires `[vault]` extra), `EncryptedFileVault`
  (Fernet AES-128 + PBKDF2-HMAC-SHA256 600 000 iterations,
  OWASP 2023 baseline). Audit logging on every op. Custom
  backends via the registry. Closes FEEDBACK §3.2. (Phase 5)

- **`mgf.common.cli`** — eight stable exit-code constants
  (numeric pin per AP-04) + `run_and_translate` /
  `translate_exceptions` / `main_entry` translator. Untyped
  exceptions automatically ship a crash report through
  `report_now`. (Phase 5)

- **`mgf-common` diagnostic CLI** — four subcommands:
  `explain` (renders active settings with per-field
  provenance — default / env / preset / init / file),
  `validate <config.yaml>` (schema-validate against
  `MgfSettings`), `doctor` (install-state + wiring health
  checks), `migrate <from> <to> <path>` (regex-based codemod
  for the v0.1 → v0.3 mechanical renames). (Phase 6b, Phase 7)

- **`docs/standards/SCOPE.md`** — six MUSTs (SP-01..SP-06)
  defining the scope policy: explicit IN-scope list, OUT-of-scope
  with cited ecosystem alternatives, Adjacent items requiring
  documented consumer demand, per-PR scope-justification, and
  the every-MAJOR revisit cadence. Standards bumped v2.0 → v2.1.
  (Phase 6a)

- **`docs/MIGRATION_0.1_TO_0.3.md`** — the consumer-facing
  upgrade guide. Quick reference table, 5-step recipe, the
  bootstrap reshape walkthrough, mechanical renames, every new
  v0.3 API, troubleshooting catalogue. Pairs with the
  `mgf-common migrate` codemod. (Phase 7)

**Deprecation cycle (per rule AP-04):**

Every v0.1 surface still works in v0.3.x; each emits
`MgfDeprecationWarning` on call. Removal lands in v1.0. The
specific deprecations:

- `mgf.common.exceptions.EnvironmentError` →
  `HostEnvironmentError` (closes FEEDBACK 🔴 Blocker API-01)
- `mgf.common.config.make_settings_config` → `settings_config`
- `mgf.common.observability.setup_logging` /
  `setup_otel` / `install_excepthook` /
  `install_threading_excepthook` → `bootstrap()`

Consumer code can stay on the v0.1 surface during the cycle, or
run `mgf-common migrate 0.1 0.3 src/` for the safe mechanical
renames + follow `docs/MIGRATION_0.1_TO_0.3.md` §1 for the
bootstrap reshape.

**Public-API surface:**

108 public names across 10 modules (was 35 names across 4
modules in v0.1.0). Per-module breakdown in `PUBLIC_API.md`.
Every name still in the `experimental` tier per the 0.x window
convention.

**Test surface:**

590 tests pass in ~3.4 s on a warm machine. mypy --strict clean
(41 source files). ruff clean. lint-imports clean (the
`mgf-common-is-a-leaf` contract holds).

**Compatibility:**

Tight pin recommended: `mgf-common = ">=0.3.0,<0.4"`. The 0.x
window per [SemVer](https://semver.org/) means MINOR releases
MAY break the public API; this is the second MINOR cut so the
window is still active.

**What's deferred (per `SCOPE.md` §3 Adjacent):**

- `mgf.common.gui` Qt helpers — wait for a second Qt consumer.
- `mgf.common.provider_pattern` (generic Provider ABC + Mock
  + FailurePlan) — wait for a second project that benefits.
- `qt` install extra — same trigger.

Per-Phase detail follows below; the structure mirrors the
commit sequence so the eight phases each retain their own
section for archeology.

### Added: closed-box redesign Phase 7 — migration tooling (2026-04-28)

Penultimate commit of the v0.3 closed-box reshape. Lands the
consumer-facing migration guide + the `mgf-common migrate`
codemod for the safe mechanical renames. The bootstrap reshape
(5-call v0.1 sequence → single `bootstrap()`) is deliberately
NOT codemodded — it benefits from human review per case and is
walked thoroughly in the migration guide.

#### `docs/MIGRATION_0.1_TO_0.3.md` (NEW)

The canonical "what changed and how do I upgrade?" guide for
v0.1 → v0.3 consumers. Sections: quick reference table, how to
use this guide (5-step recipe), the bootstrap reshape (the only
substantial change — with sub-cases for explicit settings,
preset-driven defaults, non-context-manager use, identity-only
flows, and migration-period coexistence), mechanical renames
(`EnvironmentError → HostEnvironmentError` and
`make_settings_config → settings_config`), every new v0.3 API
(MgfSettings / Protocols / progress / vault / cli / diagnostic
CLI / registry decorators), recommended migration sequence, a
troubleshooting catalogue covering the failure modes a
consumer is likely to hit, and a "what is NOT changing" section
so consumers don't go looking for changes that aren't there.

Time-to-migrate estimate: ~30 minutes for the mechanical
renames + ~1 hour for the bootstrap reshape (one-time per
consumer). The deprecation cycle covers v0.3.x — every v0.1
surface still works; v1.0 removes the deprecated aliases.

#### `mgf-common migrate <from> <to> <path>` (Phase 7)

Regex-based codemod for safe mechanical renames. Applied
v0.1 → v0.3:

  - `EnvironmentError → HostEnvironmentError` (closes FEEDBACK
    🔴 Blocker **API-01**) — both import statements and use
    sites.
  - `make_settings_config → settings_config` — both import
    statements and call sites.

Each rule carries an `import_gate` regex that ensures the rule
ONLY applies to files that mention the corresponding
`mgf.common.*` subpackage. So a file using Python's builtin
`EnvironmentError` (the `OSError` alias) is NOT touched even if
it sits next to a file that imports from `mgf.common.exceptions`
— the gate is per-file per-rule. Same for the
`make_settings_config` rule (gated on `mgf.common.config`).

Word-boundary regex anchoring ensures substring matches don't
get rewritten — `MyEnvironmentErrorSubclass` stays
`MyEnvironmentErrorSubclass`, not
`MyHostEnvironmentErrorSubclass`. Dropped pre-filter that was
only based on import-presence — was too coarse and caused
false-positive renames in code that imported `mgf.common.config`
but used Python's builtin `EnvironmentError`.

```bash
$ mgf-common migrate 0.1 0.3 src/ --dry-run     # preview
$ mgf-common migrate 0.1 0.3 src/                # apply
$ mgf-common migrate 0.1 0.3 src/ --backup      # write .bak alongside
```

Recursive directory walk with skip-list for common no-op dirs
(`.venv`, `__pycache__`, `.git`, `build`, `dist`, `.tox`,
`.mypy_cache`, `.pytest_cache`, `node_modules`). Symlinks are
NOT followed. Single-file targets supported (`mgf-common
migrate 0.1 0.3 module.py`). Idempotent — running twice is a
no-op (the second pass finds the new names already present).

Unsupported `<from>`/`<to>` pairs return `EXIT_CONFIG_ERROR (1)`
with a list of supported migrations on stderr. Missing target
returns `EXIT_OPERATION_ERROR (2)`.

The bootstrap reshape (5-call → `bootstrap()`) is intentionally
NOT in the rule set. Auto-rewriting it requires AST
transformation (libcst-style) AND case-by-case judgment about
which sub-fields the consumer wants in their `MgfSettings`. The
migration guide §1 walks it in 7 sub-cases with copy-pastable
examples per case.

#### Closed-box wins worth recording

  - The migration guide is the canonical answer to "what
    breaks?" — without it, consumers would read CHANGELOG
    entries scattered across seven phases and have to assemble
    the upgrade sequence themselves.
  - The codemod handles the boring renames so consumers' time
    is freed for the one substantive change (the bootstrap
    reshape).
  - Per-rule import gates make the codemod safe to run on
    monorepos that have non-mgf code using overlapping
    identifier names (Python's builtin `EnvironmentError` being
    the canonical example).

#### Test surface

`tests/unit/test_phase7_migrate.py` — 20 tests covering
EnvironmentError rename (import + use site + word-boundary
substring safety + import-gate skip), make_settings_config
rename (import + call site + import-gate skip), per-rule gating
(only one rule applies when only one gate matches),
bootstrap-reshape NOT codemodded (the 5-call sequence is left
untouched), --dry-run / --backup / no-default-backup behaviour,
idempotency, recursive walk + skip-dirs (`.venv`, `__pycache__`)
+ single-file target + non-Python ignored, unsupported-version +
missing-target error paths, CLI dispatch (migrate is the fourth
subcommand alongside explain/validate/doctor).

Test count 570 → 590 (+20). All four gates green: 590 tests in
3.44s, mypy --strict clean (41 source files), ruff clean,
lint-imports clean. Updated stale Phase 6b dispatch test from
`test_build_parser_lists_three_subcommands` to
`test_build_parser_lists_phase6b_subcommands` with subset-check
semantics so future subcommands don't break the pin.

#### Quirks worth recording

  - The codemod's `_apply_rules` walks each rule with its own
    `import_gate.search(text)` BEFORE attempting the
    substitution. This is per-rule, not per-file — the same
    file may match one rule's gate but not another, in which
    case only the matching rule applies.
  - Removed the cheap top-level `_file_imports_mgf_common`
    pre-filter from an earlier draft because it caused false
    positives (any file with the literal string "mgf.common"
    in a docstring matched and then got over-applied at the
    rule level). The per-rule gate is both stricter AND
    sufficient.
  - The `MyEnvironmentErrorSubclass` test case is a real
    regression guard — the regex uses `\bEnvironmentError\b`
    (word boundary) but the failure mode would have been
    catastrophic if the boundary were missing (mass
    misrenaming of any identifier containing the substring).
  - The dispatch wiring uses Python 3.10+ `match` statement; we
    matched the pattern-string of each subcommand explicitly
    rather than `case _ if args.command == ...` for readability.
    Python 3.11+ is the minimum runtime per `pyproject.toml`,
    so this is safe.
  - The migration guide is positioned at `docs/` (not
    `docs/standards/`) because it documents `mgf-common` THIS
    project's specific upgrade path, not a cross-project
    standard. Future migration guides will live alongside
    (e.g., `docs/MIGRATION_0.3_TO_0.4.md` if/when v0.4 ships).

### Added: closed-box redesign Phase 6b — diagnostic CLI (2026-04-28)

Final commit of Phase 6 (split 6a/6b). Lands the
`mgf-common` console-script with three subcommands —
`explain` / `validate` / `doctor` — backed by a per-field
provenance shim that Phase 6a's `model_fields_set` mutation
makes possible.

#### `mgf-common explain`

Renders the active `MgfSettings` with each field annotated by
its source. The provenance shim walks the precedence ladder
(env → file → preset → default) and reports the first hit:

```
$ mgf-common explain --app myapp --version 1.0 --preset systemd
mgf-common v0.1.0  active configuration for myapp v1.0

[logging]
  level                     INFO                      (default)
  format                    json                      (preset: systemd)
  file                      (none)                    (default)
  journald                  true                      (preset: systemd)
  ...
[meta]
  preset                    systemd                   (init)
  version                   1                         (default)

Environment variables read by mgf-common:
  MGF_LOGGING__LEVEL                       (unset)
  MGF_LOGGING__FORMAT                      (set: text)
  ...
```

Secret-shaped fields (`sentry_dsn`, `passphrase`, `http_url`,
`http_sink`, `syslog_address`) are redacted in BOTH the dump
AND the env-var footer so the output is safe to paste into a
bug report.

#### `mgf-common validate <config.yaml>`

Loads a YAML file with `yaml.safe_load`, validates against
`MgfSettings`, and renders the resolved active configuration
(same shape as `explain` but with `(file)` provenance for
file-supplied fields):

```
$ mgf-common validate config.yaml --app myapp --version 1.0
✓ Schema valid (MgfSettings v1)
✓ All field constraints pass
✓ No unknown keys

mgf-common v0.1.0  resolved configuration from config.yaml for myapp v1.0
...
```

Exit codes follow Phase 5: `0` on success,
`EXIT_CONFIG_ERROR (1)` on schema-validation failure (per-field
errors listed on stderr), `EXIT_OPERATION_ERROR (2)` on
file-read or YAML-parse failure.

#### `mgf-common doctor`

Install-state + wiring health checks:

```
$ mgf-common doctor
✓ mgf-common v0.1.0 installed at /home/.../site-packages
✓ py.typed marker present (downstream mypy --strict OK)
✓ [observability] extra installed (opentelemetry, sentry_sdk available)
✓ [vault] extra installed (keyring, cryptography available)
✓ Default crash dir writable: /home/.../local/state/myapp/crashes
✓ Default log dir writable: /home/.../local/state/myapp/logs
⚠ JOURNAL_STREAM env var set ('9:25346') — journald sink would auto-attach
✓ Registered crash sinks: [otlp, sentry]
✓ Registered log handlers: [(none)]
✓ Registered redaction pattern groups: [builtin]
✓ Registered span processors: [(none)]
✓ Registered vault backends: [env, file, keyring]
✓ Deprecation warnings emit MgfDeprecationWarning ...

Recommended actions:
  - None — all checks pass.
```

Three marker tiers: `✓` pass, `⚠` heads-up (NOT a failure), `✗`
failure. Exit code `0` if no `✗`; `EXIT_OPERATION_ERROR (2)`
otherwise. Each `✗` adds an actionable recommendation to the
footer.

#### Field-provenance shim — `mgf.common.cli._provenance`

The shim that powers `explain` and `validate`:

```python
from mgf.common.cli._provenance import field_provenance, FieldSource
from mgf.common.settings import MgfSettings

prov = field_provenance(MgfSettings(preset="systemd"))
# {'logging': {'level': FieldSource('default', ''),
#              'format': FieldSource('preset', 'systemd'),
#              'journald': FieldSource('preset', 'systemd'),
#              ...},
#  'otel': {...},
#  ...
#  '_root': {'preset': FieldSource('default', ''),
#            'version': FieldSource('default', '')}}
```

Strategy: re-runs `EnvSettingsSource(MgfSettings)` to get the
env-only dict + re-runs `_resolve_preset_overrides(preset)` to
get the preset's would-have-been overrides, then walks each
field through the precedence ladder env → file → preset → init
→ default and reports the first hit. Source kinds:
`default`, `env`, `preset`, `init`, `file`.

The shim is best-effort — pydantic-settings' precedence is
*defined* by source order, not per-field metadata, so two
sources supplying the same value cannot be distinguished in
principle. Annotations are correct in every realistic case
(env or preset supplies a value the default would NOT have
produced).

#### `pyproject.toml`

```toml
[project.scripts]
mgf-common = "mgf.common.cli._mgfcli:main"
```

#### Closed-box wins worth recording

  - `explain` is the canonical answer to "where did this value
    come from?" for an operator troubleshooting why a config
    didn't take effect — every consumer was reinventing this
    locally before.
  - `validate` lets ops dry-run a config-file change before
    deploying — the `(file)` provenance markers in the resolved
    dump make it obvious what the file actually changed.
  - `doctor` is the install-state diagnostic that surfaces what
    used to be tribal knowledge ("did you install the
    `[observability]` extra?", "is your state dir writable?",
    "what crash sinks did your decorators actually register?").
  - The CLI is argparse-only — no `click` / `typer` dep
    inflicted on consumers per the `SCOPE.md` policy (CLI
    framework choice is OUT of scope).

#### Test surface

`tests/unit/test_phase6b_diagnostic_cli.py` — 33 tests covering:

  - Top-level dispatch — no-subcommand returns EXIT_UNKNOWN,
    `--help` exits 0, `build_parser()` lists exactly the three
    subcommands.
  - `explain` — every section header rendered, header app/version
    interpolated, default/env/preset/init provenance attribution,
    env-beats-preset precedence, secret-field redaction in BOTH
    the dump AND the env-var footer, env-vars footer enumerates
    every known MGF_* variable.
  - `validate` — happy path returns EXIT_SUCCESS with `✓` lines
    AND `(file)` provenance, unknown-key returns EXIT_CONFIG_ERROR
    with per-field error on stderr, invalid enum value rejected,
    missing file returns EXIT_OPERATION_ERROR, YAML parse error
    handled, top-level-must-be-mapping enforced, empty YAML is
    valid.
  - `doctor` — every check section emitted, JOURNAL_STREAM /
    OTEL_EXPORTER_OTLP_ENDPOINT trigger ⚠ when set, every
    registry surfaces its built-in pre-registered names.
  - Provenance shim — direct unit tests for default / env /
    preset / init / file attribution + sorted env-var listing.

Test count 537 → 570 (+33). All four gates green: 570 tests in
3.33s, mypy --strict clean (40 source files), ruff clean,
lint-imports clean.

#### Quirks worth recording

  - `sub_model.model_fields` access raises
    `PydanticDeprecatedSince211` in pydantic v2.11+ — use
    `type(sub_model).model_fields` instead (class-level access).
    The provenance shim and explain renderer were caught by
    pyproject's `filterwarnings=["error"]` policy and fixed
    before commit.
  - `EnvSettingsSource(MgfSettings)()` returns the nested-delim-
    expanded dict (e.g., `{"logging": {"level": "DEBUG"}}` for
    `MGF_LOGGING__LEVEL=DEBUG`); the shim walks this dict per
    sub-model.
  - `mgf-common` (no subcommand) returns `EXIT_UNKNOWN` and
    prints help to stderr — argparse's default
    `required=True` would have raised SystemExit(2) which our
    Phase 5 translator would have routed to EXIT_UNKNOWN
    anyway, but the explicit `required=False` shape gives
    cleaner exit semantics + a usage-on-stderr message under
    the operator's control.
  - Doctor reads `mgf.common._identity._APP_NAME` directly
    (bypassing `app_name()`) so it doesn't emit an
    `UnconfiguredWarning` — the doctor reports environment
    state; it does not enforce `configure()` discipline.
  - The redaction list in `_explain.py` (`sentry_dsn`,
    `passphrase`, `http_url`, `syslog_address`, `http_sink`)
    is conservative but field-name-based — if a future field
    carries credential-shaped data without a credential-shaped
    name, it MUST be added to `_REDACT_FIELDS`. There is no
    automatic detection; explain is meant to be safe to paste
    into a bug report and that promise can only be kept by an
    explicit allow-list.

### Added: closed-box redesign Phase 6a — presets + SCOPE.md (2026-04-28)

Sixth commit (split 6a/6b) of the v0.3 closed-box reshape. Wires
the `MgfSettings.preset` semantics that Phase 1 shipped as a typed
seam, and lifts §8 of `docs/CLOSED_BOX_REDESIGN.md` into a
freestanding `docs/standards/SCOPE.md` so library authors and PR
reviewers have a single canonical answer to "does this belong in
the library?".

#### `MgfSettings.preset` semantics (closes design ref §6)

```python
from mgf.common.settings import MgfSettings, LoggingSettings

# explicit (default) — every field stays at its declared default
MgfSettings()
# → logging.format='auto', logging.level='INFO', otel.enabled=False

# dev — text format, DEBUG, no remote sinks
MgfSettings(preset="dev")
# → logging.format='text', logging.level='DEBUG', otel.enabled=False

# systemd — journald + JSON
MgfSettings(preset="systemd")
# → logging.format='json', logging.journald=True

# docker — JSON to stdout (container captures it)
MgfSettings(preset="docker")
# → logging.format='json', logging.journald=False, logging.file=None

# auto — legacy v0.1 detection (TTY / JOURNAL_STREAM /
#   OTEL_EXPORTER_OTLP_ENDPOINT). Default when bootstrap() is
#   called WITHOUT a settings= argument (FEEDBACK §14.15).
MgfSettings(preset="auto")
```

Explicit overrides win over preset defaults — at every level:

```python
MgfSettings(
    preset="systemd",
    logging=LoggingSettings(level="DEBUG"),
)
# → systemd preset's format/journald PLUS the explicit DEBUG level
```

Env-supplied fields beat presets too (because pydantic-settings
populates `model_fields_set` BEFORE the preset validator runs):

```bash
MGF_LOGGING__LEVEL=WARNING python -c "
from mgf.common.settings import MgfSettings
s = MgfSettings(preset='dev')
print(s.logging.level)  # WARNING — env wins
print(s.logging.format) # text — preset still applies to non-env fields
"
```

Implementation: a `model_validator(mode='after')` on `MgfSettings`
walks each preset's `{sub_model: {field: value}}` map and applies
each entry IF the field is not already in the sub-model's
`model_fields_set`. Preset-applied fields are then marked as set
so future introspection (Phase 6b's `mgf-common explain`) can
attribute the value to the preset.

The `auto` preset's detection happens at MgfSettings construction
time, NOT at module import — so env mutations between import and
bootstrap take effect.

#### `docs/standards/SCOPE.md` (NEW; closes the cornerstone-rhythm gap)

Six new MUSTs (SP-01..SP-06) defining the scope policy a
"cornerstone" library publishes:

  - **SP-01** explicit IN-scope list
  - **SP-02** explicit OUT-of-scope list with reasoning
  - **SP-03** per-PR scope-justification question
  - **SP-04** Adjacent items require documented consumer-demand
    signal before promotion
  - **SP-05** OUT entries cite the ecosystem alternative
  - **SP-06** scope policy revisited every MAJOR release

Standards version bumped v2.0 → v2.1 (MINOR — SP-* MUSTs are
library-author / process rules, not consumer-code rules; existing
consumer code stays compliant). `docs/STANDARDS_COMPLIANCE.md`
adds the SP-* row block (5 ✅, 1 🟠, 1 ➖).

#### Closed-box wins worth recording

  - Presets wire the *behaviour* of a field that has been a typed
    seam since Phase 1 — closes a "ships but doesn't do anything"
    gap that would have surprised consumers reading
    `MgfSettings.preset`.
  - The `auto` preset preserves the v0.1 auto-detection shape for
    legacy consumers (TTY / JOURNAL_STREAM / OTEL endpoint), so
    `bootstrap()` with no settings= arg behaves identically to
    v0.1 — the silent-break-on-upgrade failure mode (§14.15) is
    closed.
  - `SCOPE.md` lifts a previously-internal design-doc section into
    the standards folder where it can be cited by every PR
    reviewer with a stable URL — the section was already present
    in the design doc but reviewers had to know where to look.

#### Test surface

`tests/unit/test_phase6a_presets.py` — 31 tests covering each of
the five presets independently, override precedence (explicit
kwargs / env vars beating preset defaults / partial sub-model
kwargs keeping preset for unset fields), the runtime-detection
shape of `auto` (TTY / JOURNAL_STREAM / OTEL_EXPORTER_OTLP_ENDPOINT
each tested with monkey-patched values), provenance (preset-applied
fields appear in `model_fields_set` so Phase 6b can attribute
sources), idempotency (re-validating an instance is a no-op),
direct unit tests for the `_resolve_preset_overrides` helper, and
an integration test confirming `bootstrap()` without a `settings=`
arg defaults to `preset="auto"` per FEEDBACK §14.15.

Test count 506 → 537 (+31). All four gates green: 537 tests in
~3s, mypy --strict clean (35 source files), ruff clean,
lint-imports clean.

#### What lands in 6b (next commit)

The diagnostic CLI — `mgf-common explain / validate / doctor`
console-script + the field-source provenance shim that Phase 6a's
`model_fields_set` mutation makes possible.

### Added: closed-box redesign Phase 5 — vault + cli (2026-04-25)

Fifth commit of the v0.3 closed-box reshape. Lands the credential
vault module (closes FEEDBACK §3.2) with three built-in backends
+ a registry for custom stores; adds `mgf.common.cli` with stable
exit-code constants + an exception → exit-code translator that
absorbs the boilerplate top-level handler every consumer was
hand-rolling.

#### `mgf.common.vault` (closes FEEDBACK §3.2)

Three built-in backends, each implementing
`mgf.common.typing.VaultProtocol`:

```python
from mgf.common.vault import EnvVault, KeyringVault, EncryptedFileVault

# CI / containers — stdlib-only, reads MGF_VAULT_<KEY> env vars.
v = EnvVault()                                 # default prefix MGF_VAULT_
v = EnvVault(prefix="MYAPP_VAULT_")            # custom per rule SC-12

# Desktop — system credential store via keyring (libsecret/Keychain/CredMgr).
v = KeyringVault(service="myapp")              # requires [vault] extra

# Headless / CI persistence — Fernet AES-128 + PBKDF2-HMAC-SHA256
# (600k iterations, OWASP 2023 baseline per rule SC-05).
v = EncryptedFileVault(Path("vault.bin"), passphrase=prompt_passphrase())
```

  - `EnvVault` — stdlib-only; works without `[vault]` extra.
  - `KeyringVault` — uses `keyring` library; tracks a
    per-service index so `list_keys()` is portable across
    backends (Windows Credential Manager has no native enum).
  - `EncryptedFileVault` — file header `MGFV` + version byte +
    16-byte salt + Fernet token. Atomic write per CF-04, `0o600`
    at-rest permissions, cached Fernet instance so PBKDF2 cost
    is paid once per vault instance.

Audit logging — every backend emits an `audit=true` log record
on `get` / `set` / `delete` per rule SC-17. The KEY is logged;
the VALUE is not.

Custom backends (HashiCorp Vault, AWS Secrets Manager, custom
HSM) plug in via the registry decorator:

```python
from mgf.common.vault import register_vault_backend

@register_vault_backend("hashicorp")
def make_hashicorp(config: dict) -> VaultProtocol:
    return MyAdapter(hvac.Client(url=config["url"], token=config["token"]))
```

The built-in names (`"env"` / `"keyring"` / `"file"`) are
pre-registered at import time of `mgf.common.vault`.

#### `mgf.common.cli` (CLI top-level helpers)

Eight stable exit-code constants (numeric pin per rule API-04;
bumping any is a breaking change):

```python
from mgf.common.cli import (
    EXIT_SUCCESS,           # 0
    EXIT_CONFIG_ERROR,      # 1  ← ConfigError family
    EXIT_OPERATION_ERROR,   # 2  ← OperationError + Cancellation + Bootstrap
    EXIT_GUEST_ERROR,       # 3  ← GuestError family
    EXIT_ENVIRONMENT_ERROR, # 4  ← HostEnvironmentError family
    EXIT_PROVIDER_ERROR,    # 5  ← ProviderError + ResourceNotFound/Exists
    EXIT_VAULT_ERROR,       # 6  ← VaultError family
    EXIT_UNKNOWN,           # 10 ← untyped + crash report shipped
)
```

Translator with three call shapes:

```python
from mgf.common.cli import run_and_translate, translate_exceptions, main_entry

# 1. Call-style — most flexible.
def main(argv): ...
sys.exit(run_and_translate(main, sys.argv[1:], exit_code_map={LicenseError: 7}))

# 2. Decorator — when main() is the canonical entry-point name.
@translate_exceptions(exit_code_map={LicenseError: 7})
def main(argv): ...
sys.exit(main(sys.argv[1:]))

# 3. One-liner — reads sys.argv + sys.exits for you.
if __name__ == "__main__":
    main_entry(main, exit_code_map={LicenseError: 7})
```

  - Exception → exit code resolves via MRO walk (most-specific
    class first); per-CLI overrides via `exit_code_map`.
  - `SystemExit` (argparse, etc.) — int code passes through;
    string forms map to `EXIT_UNKNOWN`.
  - Bare `KeyboardInterrupt` returns `130` (128 + SIGINT — the
    Unix convention); typed `CancellationError` flows through
    `EXIT_OPERATION_ERROR` per rule DP-09.
  - Untyped exceptions ship a crash report through
    `mgf.common.observability.report_now` (NEVER raises) before
    returning `EXIT_UNKNOWN`.

#### `mgf.common.settings` — `VaultSettings` sub-model

```python
from mgf.common.settings import MgfSettings, VaultSettings

settings = MgfSettings(
    vault=VaultSettings(
        backend="file",
        config={"path": "/var/lib/myapp/vault.bin",
                "passphrase": prompt_passphrase()},
    ),
)
```

The `config` dict is intentionally untyped in v0.3 — a
discriminated union per backend ships in v0.4 once the
consumer-facing shape settles in production.

#### `pyproject.toml`

```toml
vault = [
    "keyring>=24",
    "cryptography>=42",
]
```

`KeyringVault` and `EncryptedFileVault` import the optional
libraries lazily; constructing either without the extra raises
`VaultError` with the install hint per rule EH-09.

#### Closed-box wins

  - Consumers DO NOT import `keyring`, `cryptography`, or any
    backend-specific module — they pass a `VaultProtocol`
    everywhere. Switching backends is a single line at bootstrap.
  - The CLI translator absorbs the `except AppError` ladder
    that every consumer was hand-rolling. Project-specific
    overrides via `exit_code_map={MyError: N}`.
  - Audit logging on every vault op (rule SC-17) — security
    teams get a complete read/write trail without instrumentation.

#### Rule coverage

  - **SC-05** — KDF iteration count meets OWASP 2023 baseline
    (600 000 PBKDF2-HMAC-SHA256).
  - **SC-12** — backends accept consumer-app-specific identifiers
    (prefix / service) so multi-consumer hosts don't collide.
  - **SC-13** — `EncryptedFileVault` does NOT create arbitrary
    parent directory trees.
  - **SC-17** — audit log emitted on every `get` / `set` /
    `delete` (KEY logged; VALUE not).
  - **CF-04** — atomic write (temp + rename, `0o600`).
  - **EH-09** — actionable install hint when the `[vault]` extra
    is missing.
  - **DP-10** — `backend` property on every concrete backend
    (no silent fallback).
  - **API-04** — exit-code constants are numerically pinned.

#### Test surface

  - `tests/unit/test_phase5_vault.py` — 52 tests covering
    EnvVault (round-trip / prefix / audit), KeyringVault
    (driven through an in-memory fake), EncryptedFileVault
    (round-trip / wrong-passphrase / corrupted-file / atomic
    write / 0o600 / salt persistence), the registry
    (register / unregister / built-in factories), and the
    `VaultSettings` schema.
  - `tests/unit/test_phase5_cli.py` — 30 tests covering
    exit-code numeric pins, MRO-based category mapping,
    overrides, SystemExit / KeyboardInterrupt special cases,
    untyped exception → `report_now` + `EXIT_UNKNOWN`, and the
    decorator form.

#### Documentation

  - `PUBLIC_API.md` — adds the `mgf.common.vault`
    (6 names) + `mgf.common.cli` (11 names) sections; bumps
    `mgf.common.settings` to 9 names; total surface grows to
    **108 names**.
  - `tests/unit/test_public_api_doc.py` — discovers the two
    new modules so the AP-10 pin covers Phase 5.

### Added: closed-box redesign Phase 4 — progress + typing (2026-04-27)

Fourth commit of the v0.3 closed-box reshape. Lifts cancellation
+ progress primitives from VManager into `mgf.common.progress`
(closes FEEDBACK API-03), adds the async sibling submodule
`mgf.common.progress.asyncio`, and ships `mgf.common.typing` with
the canonical Protocol definitions (closes FEEDBACK API-05).

#### `mgf.common.progress` (closes FEEDBACK API-03)

```python
from mgf.common.progress import CancellationToken, NullReporter, RecordingReporter
from mgf.common.typing import ReporterProtocol

def long_op(*, token: CancellationToken, reporter: ReporterProtocol) -> None:
    for i, item in enumerate(items):
        token.raise_if_cancelled()
        do_thing(item)
        reporter.report(f"processed {i+1}/{len(items)}", current=i+1, total=len(items))

# Production:
token = CancellationToken()
long_op(token=token, reporter=NullReporter())

# Tests:
reporter = RecordingReporter()
long_op(token=CancellationToken(), reporter=reporter)
assert reporter.calls[-1] == ("processed 5/5", 5, 5)
```

  - `CancellationToken` — sync, threading-friendly. Backed by
    `threading.Event`. `cancel() / is_cancelled() /
    wait(timeout) / raise_if_cancelled()`.
  - `ProgressReporter` — ergonomic alias for
    `mgf.common.typing.ReporterProtocol`.
  - `NullReporter` — no-op concrete impl. Optional `token=`
    forwards `is_cancelled()`.
  - `RecordingReporter` — test double; accumulates calls in
    `.calls: list[tuple[str, int, int]]`; `reset()` between
    sub-tests.

#### `mgf.common.progress.asyncio` (sync-first / async-adapter rule §14.1)

```python
from mgf.common.progress.asyncio import AsyncCancellationToken

async def long_op(token: AsyncCancellationToken):
    for _ in range(100):
        token.raise_if_cancelled()
        await do_async_work()
```

  - `AsyncCancellationToken` — asyncio-native. Backed by
    `asyncio.Event`. Same surface plus `await wait(timeout)`.
    Bound to a single event loop; NOT thread-safe across loops.
    For cross-thread cancellation, use the sync token + bridge.

#### `mgf.common.typing` (closes FEEDBACK API-05)

Canonical `Protocol` definitions for stable abstractions:

  - `CancellationProtocol` — `cancel() + is_cancelled()`.
  - `ReporterProtocol` — `report(message, current, total) + is_cancelled()`.
    Re-exported as `mgf.common.progress.ProgressReporter` for
    ergonomics; same Protocol object, two import paths.
  - `LogSinkProtocol` — `append_info / append_error` (for the
    future GUI helpers).
  - `VaultProtocol` — `get / set / delete / list_keys / backend`
    (concrete impls in `mgf.common.vault` Phase 5).

All `runtime_checkable` so `isinstance(obj, SomeProtocol)` works
in tests + audit code.

#### `CancellationError(OperationError)` (new typed exception)

Raised by `CancellationToken.raise_if_cancelled()` (and the
async sibling) when `cancel()` has been signalled. Subclass of
`OperationError` so existing CLI top-level handlers that map
`OperationError` → exit code catch it without code change
(rule EH-04). Default message: `"operation cancelled by user"`;
consumer call sites can pass a more specific one.

#### Files

NEW:
  - `src/mgf/common/typing/__init__.py` — 4 Protocols (160 lines).
  - `src/mgf/common/progress/__init__.py` — `CancellationToken`
    + `NullReporter` + `RecordingReporter` + `ProgressReporter`
    alias (211 lines).
  - `src/mgf/common/progress/asyncio.py` — `AsyncCancellationToken`
    sibling (123 lines).
  - `tests/unit/test_phase4_progress.py` — 42 behavioural tests
    (sync token / null + recording reporters / async token /
    CancellationError shape / Protocol runtime checks /
    integration with cross-thread + cross-task cancellation).

MODIFIED:
  - `src/mgf/common/exceptions/_well_known.py` — added
    `CancellationError(OperationError)`.
  - `src/mgf/common/exceptions/__init__.py` — re-exports.
  - `pyproject.toml` — added `pytest-asyncio>=0.23` to the
    `[dev]` extra (per rule TS-12); added pytest config
    `asyncio_mode = "strict"` and
    `asyncio_default_fixture_loop_scope = "function"` (per-test
    event loop is the recommended default per TESTING.md §7.1).
  - `tests/unit/test_public_api_doc.py` — module discovery list
    extended to include `mgf.common.settings`,
    `mgf.common.typing`, `mgf.common.progress`,
    `mgf.common.progress.asyncio`.
  - `PUBLIC_API.md` — 10 new public names; total 80 → 90.

#### Tests

Test count 346 → 406 (+60: 18 new AP-10 pin assertions for
the new public surface across 4 modules + 42 behavioural in
`test_phase4_progress.py`). All four gates green:

  - 406 tests pass in 2.99s
  - mypy --strict clean on 27 source files (was 24)
  - ruff clean
  - lint-imports clean (1 contract kept)

#### Compatibility

Pure additions. No v0.1 surface changed. Existing tests + every
v0.1 consumer keep working unchanged.

Note: this commit adds `pytest-asyncio` to the dev install. New
contributors running `uv sync --extra dev --extra observability`
get it automatically. CI is unaffected (the same install path).

VManager pin guidance unchanged: when 0.3.0 ships to PyPI,
VManager bumps `mgf-common>=0.3.0,<0.4` in a separate PR + can
start using `mgf.common.progress` directly (its own
`vmanager.common.progress` becomes a re-export shim).

### Added: closed-box redesign Phase 3 — registries (2026-04-27)

Third commit of the v0.3 closed-box reshape. Ships four registry
patterns for pluggable extensibility — closes FEEDBACK API-07
(crash-sink pluggability) and pre-builds the same shape for
log handlers, redaction pattern groups, and OTel span processors
so future consumer plug-ins extend `mgf-common` without forking.

#### Crash-sink registry (closes FEEDBACK API-07)

```python
from pathlib import Path
from typing import Any
from mgf.common.observability import register_crash_sink

@register_crash_sink("my-slack")
def ship_to_slack(report_path: Path, payload: dict[str, Any]) -> None:
    requests.post(SLACK_WEBHOOK, json={
        "text": f"Crash in {payload['app']}: {payload['exception']['message']}",
    }, timeout=5)
```

Activated by listing the name in `MgfSettings.crash.sinks`:

```python
MgfSettings(crash=CrashSettings(sinks=["local", "sentry", "my-slack"]))
```

The v0.1 hardcoded sentry / otlp / http branches are now
PRE-REGISTERED entries — backward compat preserved. Multi-sink
fan-out: a single crash invokes every configured sink
independently; failure of one doesn't affect others (rule EH-10
best-effort observer pattern).

The legacy `<APP>_CRASH_SINK` env-var dispatch still works as a
fallback when no MgfSettings.crash.sinks override is active —
v0.1 consumers continue working unchanged.

#### Redaction pattern group registry

```python
import re
from mgf.common.observability import register_redaction_pattern_group

@register_redaction_pattern_group("hypervisor-tokens")
def _hv_patterns():
    return (
        re.compile(r"\bhv-tok-[A-Za-z0-9]{32,}\b"),
        re.compile(r"\bhv-key-[A-Za-z0-9]{40,}\b"),
    )

# Enable via settings:
MgfSettings(redaction=RedactionSettings(
    enabled_pattern_groups=["builtin", "hypervisor-tokens"],
))
```

Wired end-to-end: bootstrap resolves `enabled_pattern_groups`
through the registry and passes the patterns to the active
`Redactor`. Pattern matches in any log record (across any sink)
get replaced with `[REDACTED]`. The "builtin" group is
pre-registered with the existing Bearer / JWT / PEM / API-key
patterns; consumer code now extends rather than replaces.

#### Log-handler registry (registry shipped; full wiring in a later phase)

```python
from mgf.common.observability import register_log_handler

@register_log_handler("syslog-rfc5424")
def _make(settings):
    return MyRFC5424Handler(...)
```

Phase 3 ships the registry + decorator so consumer plug-in code
can register at import time. The settings field that activates
named handlers (`MgfSettings.logging.extra_handlers`) lands when
consumers actually need it. No source-compat impact when wired.

#### OTel span-processor registry (registry shipped; full wiring in a later phase)

```python
from mgf.common.observability import register_span_processor

@register_span_processor("custom-batcher")
def _make(settings):
    return MyCustomSpanProcessor(...)
```

Same shape as log handlers — registry shipped now; settings field
+ `_wire_otel` integration when needed.

#### Files

MODIFIED:
  - `src/mgf/common/observability/crash_reporter.py` — refactored
    to registry pattern: `_ship_remote` consults the registry
    instead of hardcoded if/elif chain; v0.1 sentry / otlp helpers
    are now PRE-REGISTERED via decorator (backward compat); plus
    legacy env-var fallback for v0.1 consumers without
    MgfSettings overrides; multi-sink fan-out shape (each sink
    independent, failures isolated).
  - `src/mgf/common/observability/redaction.py` — added
    `register_redaction_pattern_group` decorator; pre-registered
    "builtin" group with the existing patterns; `_resolve_pattern_groups`
    helper for `_lifecycle._bootstrap_inner` to look up active
    groups; "builtin" filtered out of resolve loop because it's
    always-on via `_scrub_string`.
  - `src/mgf/common/observability/logging_setup.py` — added
    `register_log_handler` decorator + `LogHandlerFactory` type
    alias.
  - `src/mgf/common/observability/otel_setup.py` — added
    `register_span_processor` decorator + `SpanProcessorFactory`
    type alias.
  - `src/mgf/common/observability/__init__.py` — re-exports the
    new public surface (12 new names).
  - `src/mgf/common/_lifecycle.py` — `_bootstrap_inner` resolves
    `settings.redaction.enabled_pattern_groups` via the registry
    and passes patterns to `Redactor`.
  - `PUBLIC_API.md` — 12 new public names; total 68 → 80.
  - `tests/unit/test_phase3_registries.py` — 19 new tests covering
    each registry shape + crash-sink fan-out + unknown-sink
    warning + end-to-end redaction-group wiring.

#### Tests

Test count 315 → 346 (+31: 12 new AP-10 pin assertions for the
new public names + 19 behavioural in `test_phase3_registries.py`).
All four gates green:

  - 346 tests pass in 2.70s
  - mypy --strict clean on 24 source files
  - ruff clean
  - lint-imports clean (1 contract kept)

#### Compatibility

The v0.1 hardcoded crash-sink dispatch (sentry / otlp / http://)
is preserved by registering the existing helpers via the new
decorator. The legacy `<APP>_CRASH_SINK` env-var path continues
to work when no `MgfSettings.crash.sinks` override is active.

VManager pin guidance unchanged: when 0.3.0 ships to PyPI,
VManager bumps `mgf-common>=0.3.0,<0.4` in a separate PR.

### Added: closed-box redesign Phase 2 — wraps + renames + deprecations (2026-04-26)

Second commit of the v0.3 closed-box reshape (per
`docs/CLOSED_BOX_REDESIGN.md`). Wraps the leaks identified in §3
of the design (CB-04, CB-08, CB-12, CB-13), renames + deprecates
v0.1 surfaces with the deprecation cycle starting now, and fixes
two known limitations (CB-06 to_yaml_dict shallow recursion, the
make_settings_config workaround).

#### Pydantic re-exports through `mgf.common.config` (closes CB-04)

Consumers no longer `import pydantic` for normal subclass authoring.
The full set of re-exports:

```python
from mgf.common.config import (
    AliasChoices, BaseModel, ConfigDict, Field,
    ValidationError, field_validator, model_validator,
)
```

A non-trivial Settings class can now be authored using only
`mgf.common.*` imports. The closed-box smoke test in
`tests/unit/test_phase2_surface.py::TestClosedBoxSmoke` pins
this property.

#### `BaseAppSettings(env_prefix="X_")` subclass-kwarg pattern (closes API-06)

The v0.3 canonical shape:

```python
class AppConfig(BaseAppSettings, env_prefix="MYAPP_"):
    backend_uri: str = "qemu:///system"
```

`BaseAppSettings.__init_subclass__` accepts every
`SettingsConfigDict` key as a subclass kwarg (env_prefix,
env_nested_delimiter, env_file, env_file_encoding, extra,
case_sensitive, validate_default, arbitrary_types_allowed). The
v0.1 `model_config = settings_config(env_prefix="X_")` pattern
keeps working through the deprecation cycle — the kwarg path
respects an explicit body declaration.

#### `to_yaml_dict` recursion fix (closes CB-06)

`BaseAppSettings.to_yaml_dict()` now delegates to
`self.model_dump(mode="json")` which recurses into nested
sub-models. The v0.1 shallow implementation broke
`save_settings(s)` on any Settings class with nested
`BaseModel` sub-fields (CONFIGURATION.md §8.4 documented the
workaround; this commit is the fix).

#### `HostEnvironmentError` rename (closes API-01)

`mgf.common.exceptions.EnvironmentError` was renamed to
`HostEnvironmentError` to stop shadowing Python's built-in
alias for `OSError`. The legacy `EnvironmentError` name remains
as a deprecated alias (emits `MgfDeprecationWarning` on
instantiation) until v1.0. `isinstance` works in both
directions during the cycle:

```python
from mgf.common.exceptions import HostEnvironmentError, EnvironmentError

err = HostEnvironmentError("kvm not loaded")
assert isinstance(err, HostEnvironmentError)  # ✓
# Legacy `except EnvironmentError:` clauses still catch the new type:
assert issubclass(HostEnvironmentError, EnvironmentError)  # ✓
```

#### `settings_config` rename + `make_settings_config` deprecation

`make_settings_config(...)` is renamed to `settings_config(...)`.
The legacy name remains as a deprecated alias (emits
`MgfDeprecationWarning`) until v1.0.

#### `mgf.common.observability` closed-box wraps (closes CB-08, CB-12, CB-13)

New surface so consumers don't `import logging` or
`import opentelemetry`:

```python
from mgf.common.observability import (
    get_logger,           # replaces `logging.getLogger`
    get_current_span,     # replaces `trace.get_current_span()`
    set_attribute,        # replaces span.set_attribute()
    add_event,            # replaces span.add_event()
    set_status,           # replaces span.set_status()
    Span, SpanContext, SpanKind, SpanStatus, StatusCode,  # OTel types
)

LOG = get_logger(__name__)

with operation_span("vm.create", vm_name="prod-1"):
    set_attribute("step", "validate")
    if failed:
        set_status(SpanStatus(StatusCode.ERROR, "validation failed"))
```

All span helpers no-op cleanly when no span is active or OTel
is not installed.

#### Deprecation cycle starts: `MgfDeprecationWarning`

A new `mgf.common._warnings.MgfDeprecationWarning` (subclass of
`DeprecationWarning`) is now emitted by every v0.1 multi-call
shim:

  - `mgf.common.configure(...)` (no warning yet — kept silent
    in Phase 2 because changing identity-only behaviour might
    confuse consumers)
  - `mgf.common.observability.setup_logging(...)` → emits
  - `mgf.common.observability.setup_otel(...)` → emits
  - `mgf.common.observability.install_excepthook()` → emits
  - `mgf.common.observability.install_threading_excepthook()` → emits
  - `mgf.common.config.make_settings_config(...)` → emits
  - `mgf.common.exceptions.EnvironmentError(...)` (instantiation) → emits

Each shim delegates to the underlying `_wire_*` (or
`settings_config` / `HostEnvironmentError`) so existing code
keeps working through the deprecation cycle. All removed in v1.0.

`pyproject.toml::[tool.pytest.ini_options].filterwarnings`
gained `"default::mgf.common._warnings.MgfDeprecationWarning"`
so consumer test suites with `filterwarnings = ["error"]` (rule
TS-04) see our warnings WITHOUT them blocking the build. The
deprecation contract is preserved (`-W error::DeprecationWarning`
still escalates them).

#### Files

NEW:
  - `src/mgf/common/_warnings.py` — `MgfDeprecationWarning` class.
  - `src/mgf/common/config/_reexports.py` — pydantic re-exports.
  - `src/mgf/common/observability/_otel_reexports.py` — OTel type re-exports
    with TYPE_CHECKING dual-path for the OTel-not-installed case.
  - `src/mgf/common/observability/_helpers.py` — get_logger + 4 span helpers.
  - `tests/unit/test_phase2_surface.py` — 30 behavioural tests.

MODIFIED:
  - `src/mgf/common/config/_settings.py` — `__init_subclass__` for
    API-06; `settings_config` renamed; `make_settings_config`
    deprecated wrapper; `to_yaml_dict` recursion fix.
  - `src/mgf/common/config/__init__.py` — re-exports + wires.
  - `src/mgf/common/observability/__init__.py` — re-exports.
  - `src/mgf/common/observability/logging_setup.py` — `_wire_logging`
    private + `setup_logging` deprecated shim.
  - `src/mgf/common/observability/otel_setup.py` — same shape.
  - `src/mgf/common/observability/excepthook.py` — same shape.
  - `src/mgf/common/observability/threading_excepthook.py` — same shape.
  - `src/mgf/common/exceptions/_well_known.py` —
    `HostEnvironmentError` + `_DeprecatedEnvironmentErrorMeta` +
    `EnvironmentError` alias.
  - `src/mgf/common/exceptions/__init__.py` — re-exports.
  - `src/mgf/common/_lifecycle.py` — wires switch from
    `setup_logging`/`setup_otel`/`install_*` to `_wire_*`.
  - `src/mgf/common/settings.py` — `make_settings_config` →
    `settings_config`.
  - `pyproject.toml` — filterwarnings exemption for
    MgfDeprecationWarning.
  - `PUBLIC_API.md` — 19 new public names; total 49 → 68.

#### Tests

Test count 266 → 315 (+49: 19 new AP-10 pin assertions for the
new public names + 30 behavioural in `test_phase2_surface.py`).
Full suite passes in 2.65s. mypy --strict clean on 24 source
files (was 20). ruff clean. lint-imports clean.

The 29 warnings in the test output are MgfDeprecationWarnings
from existing v0.1-shape tests calling the deprecated shims.
That's the visible signal that the migration is alive AND the
filter exemption is working — neither escalates to a failure
nor hides them entirely.

#### Compatibility

Every v0.1 API still works. The deprecation warnings name the
v0.3 replacement so consumers can migrate incrementally. After
the warning fires once per call site (per Python's standard
deprecation-warning behaviour), it's silent until next process.

VManager pin guidance unchanged: when 0.3.0 ships to PyPI,
VManager bumps `mgf-common>=0.3.0,<0.4` in a separate PR + runs
the migration codemod (Phase 7).

### Added: closed-box redesign Phase 1 — bootstrap + MgfSettings + AppContext (2026-04-26)

The first commit of the v0.3 closed-box reshape (per
`docs/CLOSED_BOX_REDESIGN.md`). Three new modules + a typed
exception join the public surface; existing v0.1 APIs keep
working unchanged so consumer code stays green.

#### `mgf.common.bootstrap()` — the single canonical entry point

Replaces the v0.1 five-call sequence (`configure` +
`setup_logging` + `setup_otel` + `install_excepthook` +
`install_threading_excepthook`):

```python
import mgf.common

# Context-manager form (recommended):
with mgf.common.bootstrap(app_name="myapp", app_version="1.0") as ctx:
    do_work()

# One-shot form (long-running services):
ctx = mgf.common.bootstrap(app_name="myapp", app_version="1.0")
try:
    do_work()
finally:
    ctx.shutdown()
```

Properties:

- **Transactional (atomicity, design ref §14.2).** Each wiring
  step appends a rollback closure. On any failure, the stack
  unwinds LIFO and `BootstrapError(failed_step, cause=...)` is
  raised. Process state is restored to its pre-bootstrap shape.
- **Bootstrap-time logging captured (design ref §14.3).** A
  `_BootstrapLogBuffer` collects records emitted from inside
  bootstrap; replays through the wired handlers once
  `_wire_logging` succeeds. On failure, flushes to stderr.
- **Idempotent (design ref §14.10).** Second call replaces
  (last-call-wins) + emits AUDIT log
  (`event="bootstrap.replace"`) so accidental re-bootstraps
  are visible.
- **Auto preset by default (design ref §14.15).** Omitted
  `settings=` arg → `MgfSettings(preset="auto")` preserves v0.1
  auto-detection behaviour for legacy consumers (no silent
  break on upgrade).

#### `mgf.common.AppContext` + `mgf.common.current_context()`

Per-tenant identity + settings dataclass. Carries `app_name`,
`app_version`, `settings`. Methods: `shutdown()` (LIFO rollback
of every wiring step), `reload(new_settings)` (atomic re-wire;
hot-reload for long-running services — design ref §14.5).

`current_context()` is the readonly accessor consulted by every
observability function. Resolution order: per-task contextvar
(set by `with AppContext(...):` in Phase 2+) → process-wide
global (set by `bootstrap()`) → `None`. Thread-safe; ~30 ns per
call.

`mgf.common.app_name()` / `app_version()` now consult
`current_context()` first, then fall back to the legacy module
global (set by `configure()`), then to the placeholder.

#### `mgf.common.settings` — the typed library settings root

`MgfSettings` (a `BaseAppSettings` subclass with
`env_prefix="MGF_"` and `env_nested_delimiter="__"`) composes
five sub-models:

- `LoggingSettings` — level / format / file / journald /
  syslog_address / http_sink / rotating_max_bytes /
  rotating_backup_count + `level_overrides` (per-component
  log levels first-class — closes design ref §14.6).
- `OtelSettings` — enabled / endpoint / service_namespace /
  sample_rate / resource_attributes / httpx_instrumented /
  subprocess_instrumented / metrics_enabled.
- `CrashSettings` — sinks / sentry_dsn / otlp_endpoint /
  http_url / state_dir.
- `RedactionSettings` — extra_keys / extra_value_patterns /
  enabled_pattern_groups + `strict_mode` (GDPR/PII patterns
  field — closes design ref §14.12 seam; patterns themselves
  wired in Phase 6).
- Plus `preset: PresetName` —
  `Literal["explicit", "dev", "systemd", "docker", "auto"]`.
  Phase 1 ships the typed seam; Phase 6 wires the preset
  semantics.

Env-var aliasing works: `MGF_LOGGING__LEVEL=DEBUG` overrides
`logging.level`. The `MgfSettings.model_dump_for_yaml()`
helper works around the known shallow-recursion limitation in
`BaseAppSettings.to_yaml_dict` (CB-06).

#### `mgf.common.exceptions.BootstrapError`

New typed exception (subclass of `OperationError`). Carries
`.failed_step` (str) + chains the original cause via `__cause__`.
Existing CLI top-level handlers that map `OperationError` to an
exit code catch it without code change.

#### Supporting changes

- `src/mgf/common/_lifecycle.py` (new, 477 lines) — the wiring
  + atomicity + buffer + idempotency + AppContext.
- `src/mgf/common/settings.py` (new, 273 lines) — the typed
  settings root.
- `src/mgf/common/_identity.py` — `app_name()` / `app_version()`
  consult `current_context()` first.
- `src/mgf/common/__init__.py` — exports `bootstrap`,
  `AppContext`, `current_context` (in addition to existing
  `configure`, `app_name`, `app_version`, `__version__`).
- `src/mgf/common/exceptions/_well_known.py` — adds
  `BootstrapError`.
- `tests/unit/test_lifecycle.py` (new, 24 tests) — covers
  atomicity, idempotency, buffer replay, context resolution,
  settings, level-overrides round-trip.
- `PUBLIC_API.md` — adds 12 new public names; total 37 → 49.

#### Compatibility

The v0.1 APIs (`configure`, `setup_logging`, `setup_otel`,
`install_excepthook`, `install_threading_excepthook`) are
**unchanged** in Phase 1 — no deprecation warnings yet, no
behavioural changes. Existing 238-test surface continues to
pass; consumer code (VManager, etc.) keeps working without
modification.

The deprecation cycle for those APIs starts in a focused later
phase. Phase 1's job is to introduce the new shape so consumers
can opt in incrementally.

#### Tests

Test count 238 → 266 (+28: 4 new AP-10 pin assertions +
24 lifecycle tests). Full suite passes in 2.65 s. mypy --strict
clean on 20 source files (was 18 — +`settings.py` and
`_lifecycle.py`). ruff clean. lint-imports clean.

### Added: FEEDBACK round 1 closures + format v2 (2026-04-26)

Five entries from FEEDBACK.md round 1 (VManager) closed in one
commit. The format itself was restructured to per-entry frontmatter
tables for AI-actionability — see FEEDBACK.md §1.4 template.

#### `mgf.common.UnconfiguredWarning` (closes API-08)

New public `UserWarning` subclass. Emitted **once per process** the
first time `app_name()` or `app_version()` is read before
`configure()` has been called. Surfaces the previously-silent
"writes log file under `<state>/app/logs/app.log`" failure mode
that bit every new consumer.

```python
import mgf.common
# (forgot to call configure())
mgf.common.app_name()  # UserWarning: mgf.common: app identity not configured ...
```

Consumers that want this loud can opt in:
```python
import warnings
warnings.filterwarnings("error", category=mgf.common.UnconfiguredWarning)
```

#### `Redactor` extended value patterns (closes PAPER-01)

Five additional API-key shapes now redacted from free-text values
(in addition to the existing Bearer / JWT / PEM patterns):
- OpenAI: `sk-...`
- GitHub: `ghp_...` / `gho_...` / `ghu_...` / `ghs_...` / `ghr_...`
- AWS access key: `AKIA...`
- Slack tokens: `xoxb-...` / `xoxp-...` / etc.
- Google API keys: `AIza...`

Each pattern is anchored on the issuer's prefix so false positives
are minimal. Tests parameterise over all five.

#### `Redactor` composition + `DEFAULT_REDACTION_KEYS` (closes PAPER-02)

`Redactor.__or__` lets composers union two redactors:

```python
from mgf.common.observability import Redactor

r = Redactor.default() | Redactor(extra_keys=frozenset({"my_token"}))
```

`DEFAULT_REDACTION_KEYS` is now a public `frozenset[str]`; consumers
can audit "what's already covered" before declaring extras.

#### `SchemaValidationError` prefix as class attribute (closes PAPER-05)

New `_MESSAGE_PREFIX` class attribute on `SchemaValidationError`.
Subclasses customise the prefix via override without bypassing
the parent's `__init__`:

```python
class SpecValidationError(SchemaValidationError):
    _MESSAGE_PREFIX = "spec validation failed"
```

Default stays `"validation failed"` — existing consumers depending
on the message shape are unaffected.

#### `PUBLIC_API.md` (closes API-04)

Already shipped in commit `61b340c` (PUBLIC_API.md created) plus
`bd54476` (AP-10 pin tests added). Closes API-04 formally in this
release.

#### Test count

Tests: 221 → 238 (+17 covering the new behaviours). All new tests
follow the FEEDBACK ID convention (`test_paper_01_*`,
`test_paper_02_*`, `test_paper_05_*`, `test_unconfigured_warning_*`)
so the implementation→test→FEEDBACK chain is grep-friendly.

### New: `FEEDBACK.md` — early-consumer feedback pipeline (2026-04-23)

Added a living document at the repo root to capture opinionated
feedback from real consumers BEFORE the API locks at v1.0. The stakes
are asymmetric: a 🔴 Blocker concern raised now is a minor commit; the
same concern raised after 1.0 ships with N consumers becomes a
breaking-change coordination exercise across the ecosystem.

VManager (the inaugural consumer) submitted its full integration
feedback as the first content: 8 🔴 Blockers, 6 🟡 Papercuts, 1 💭
Aspirational observation, plus detailed roadmap input for 16 upcoming
features (cancellation primitives, vault, SSH, service manager,
retry/backoff, metrics, testing fixtures, CLI/GUI helpers, lifecycle
manager, versioned-file abstraction, containerized deployment, i18n,
benchmarks, starter template, migration codemod).

Each entry carries: ID, submitter, severity (🔴/🟡/🟢/💭), concern,
why it matters, suggested shape, cost if deferred past 1.0, current
status. §2 describes the submission/triage/closure process; §6
recommends API stability tiers; §7 confronts the multi-tenancy
question; §9 is unvarnished meta-feedback on the project itself.

The top three pre-1.0 blockers that need decisions (not yet code):

- **API-01** rename `EnvironmentError` → `HostEnvironmentError`
  (ends the `# noqa: A001` papercut every consumer would carry
  forever).
- **API-02** decide multi-tenancy story — `AppContext` hybrid
  (recommended) or explicit "one-app-per-process" lock-in.
- **API-03** + **API-05** lift `CancellationToken` + `ProgressReporter`
  into `mgf-common` BEFORE shipping SSH / service manager, with
  Protocol-typed interfaces for every stable abstraction.

README grew a "Feedback from consumers" section pointing at the
new doc. Layout diagram updated to list `FEEDBACK.md` + `CHANGELOG.md`
+ `docs/CLAUDE.md`.

### Standards v1.2 — VManager round 1–3 lessons folded in (2026-04-23)

Docs-only update to the standards. VManager (the reference consumer)
closed three compliance-audit rounds in a single day; the lessons
that have cross-project reach are folded back into the standards docs
so future consumers see them up front rather than having to
rediscover.

Changes:

- **`docs/standards/LOGGING.md` §11.1** — new "Pytest stderr-capture
  distorts full-stack logging benchmarks" pitfall. When a consumer
  writes an LG-12 perf test that goes through the default
  `setup_logging()` wiring, pytest's stderr-capture inflates the
  per-record number by 30–40 % vs. the production path. Fix: drop
  the console `StreamHandler` after setup so only the rotating file
  handler participates in the timed loop. Grounded in VManager round
  2 (the first cut of `test_logging_perf.py` timed out at 128.6
  µs/record; the fixed version ran at ~50 µs/record).

- **`docs/standards/LOGGING.md` §11.2** — new "Consumer-side guards
  when the implementation lives upstream" subsection. Three reasons
  a consumer SHOULD keep a thin LG-* test even though `mgf-common`
  owns the implementation: shim regressions, consumer-specific
  extensions, pin regressions. Canonical shape:
  `VManager/tests/unit/test_logging_perf.py`.

- **`docs/standards/CONFIGURATION.md` §8.3** — new "Accepting files
  that predate the `version` field" subsection. When tightening
  CF-07 on a sub-config format users already write, the
  WARN-and-default-to-current pattern keeps existing installs
  loading while emitting a diagnostic the user can act on. Carries
  four conditional MUSTs (WARNING-with-identifier,
  rewrite-on-next-save, unit-test-pin, reject-bool). Grounded in
  VManager round 1 `CF-07-profiles`.

- **`docs/standards/CONFIGURATION.md` §10.1** — new "Pinning the
  lazy-default pattern" subsection describing the consolidated
  pin-test-file pattern. One test file per project that covers
  every `_default_X()` helper in one class — scattered per-subsystem
  tests let the rule rot. Canonical shape:
  `VManager/tests/unit/test_default_path_resolution.py`. Grounded
  in VManager round 3 `CF-04-module-paths-3`.

- **`docs/standards/COMMON_COMPONENTS.md`** — new top-level section
  "Maintaining compliance over time (cornerstone rhythm)". Covers
  the compliance-doc shape (table + open gaps + closed history +
  observations), the audit→close→audit rhythm, the compliance-sweep
  commit pattern, observations-vs-gaps, consumer-side guards, and
  the single-session AI-agent audit pattern. Grounded in VManager
  rounds 1–3.

All four topic docs (LOGGING, CONFIGURATION, COMMON_COMPONENTS, and
the master README index) bumped from **v1.1 → v1.2**. Per the README
version policy, additions of SHOULDs + templates + conditional MUSTs
(scoped to a specific migration scenario) are MINOR bumps — existing
code stays compliant, new code SHOULD adopt.

No code changes. `mgf.common` v0.1.0 on PyPI is unchanged. VManager's
`mgf-common>=0.1.0,<0.2` pin is unaffected.



## [0.1.0] — 2026-04-22

First public release. Extracted from
[VManager](https://codeberg.org/magogi-admin/VManager) per the Round 5
plan in [`COMMON.md`](COMMON.md). VManager is the reference consumer
and the only consumer to date; the API is "lifted-from-VManager-shaped"
and may need adjustment when a second project arrives — the 0.x major
zero exists to make that future churn possible.

### Added

- **`mgf.common.exceptions`** — typed exception hierarchy.
  `AppError` base + 7 well-known category bases (`ConfigError`,
  `ProviderError`, `OperationError`, `GuestError`, `EnvironmentError`
  [deliberately shadows the builtin alias], `VaultError`,
  `SchedulerError`) + 6 generic concretes that carry machine-readable
  fields (`SchemaValidationError.errors`, `AppConfigError`,
  `CommandError.argv/.returncode/.stderr`, `ResourceNotFoundError.name`,
  `ResourceAlreadyExistsError.name`, `GuestUnreachableError`,
  `GuestCommandError`). Consumer projects subclass per their domain.

- **`mgf.common.config`** — reusable typed configuration.
  `BaseAppSettings` (pydantic-settings base with the layered source
  order `kwargs > env > .env > YAML > defaults`, YAML override hook,
  version-check validator, `to_yaml_dict` helper),
  `make_settings_config(env_prefix=...)` (helper that builds a
  `SettingsConfigDict` with the recommended baseline plus consumer
  overrides — the canonical way to set `env_prefix` on a subclass;
  the `**BaseAppSettings.model_config` spread does NOT work),
  `load_settings` / `save_settings` (typed loader with optional
  migration callback + atomic temp-file writer at mode `0o600`),
  `platform_dir(kind)` + `default_config_path(app)` (cross-OS XDG /
  macOS Application Support / Windows AppData resolution),
  `expand_path` (validator helper for `~` and `$VARS` expansion).

- **`mgf.common.observability`** — full observability stack.
  `setup_logging` (single-point logging with console + rotating file
  + opt-in journald / syslog / OTLP / HTTP webhook sinks),
  `JsonFormatter` (one JSON object per line, OTel-aware, redacted),
  `TextFormatter` (TTY-friendly with ANSI colour, honours `NO_COLOR`),
  `Redactor` (sensitive-field redaction policy covering `password`,
  `token`, `api_key`, `Bearer ...`, JWTs, PEM blocks; configurable
  extras), `setup_otel` + `operation_span` (lazy OpenTelemetry — no-op
  without the `[observability]` extra; `operation_span` records
  exceptions and skips `None` attributes), `report_now` (local crash
  report under `<state>/crashes/` + opt-in remote ship via
  `<APP>_CRASH_SINK=sentry|otlp|https://...`),
  `install_excepthook` + `install_threading_excepthook` (idempotent
  process-wide hooks).

- **`mgf.common.configure(app_name, app_version)`** — process-wide
  identity cache. Every observability function reads `app_name()` to
  derive log paths, env-var prefixes, OTel service name, and the
  crash report `app` field. Call once per entry point, before any
  other `mgf.common.*` function that emits diagnostics.

- **`docs/standards/`** — cross-project engineering standards
  (DESIGN_PRINCIPLES, ERROR_HANDLING, LOGGING, CONFIGURATION,
  COMMON_COMPONENTS, plus the master README with conformance
  keywords + L0 / L1 / L2 levels). Lifted from VManager in Phase 4.

- **PEP 561 `py.typed` marker** so downstream `mypy --strict`
  consumers see fully-typed inline annotations instead of
  `module is installed, but missing library stubs or py.typed marker`
  warnings (and the cascade of "cannot subclass" errors that follows).

- **`[observability]` extra** — pulls in `opentelemetry-api`,
  `opentelemetry-sdk`, `opentelemetry-exporter-otlp-proto-http`,
  `opentelemetry-instrumentation-httpx`, and `sentry-sdk`. Default
  install stays slim; consumers opt in when they want L2 conformance.

- **Quality gates wired:** `mypy --strict` clean on 18 source files,
  157 tests pass, `ruff` clean, `import-linter` enforces the single
  contract `mgf-common-is-a-leaf` (forbids any import of a consumer
  project from inside `mgf.common`).

[Unreleased]: https://codeberg.org/magogi-admin/mgf_common/compare/v0.1.0...HEAD
[0.1.0]: https://codeberg.org/magogi-admin/mgf_common/releases/tag/v0.1.0
