"""``mgf-common`` console-script entry point.

Three subcommands shipped in Phase 6b:

  - ``explain``  — print the active settings with provenance.
  - ``validate`` — schema-validate a YAML file.
  - ``doctor``   — install-state and wiring health checks.

The entry point is wired in ``pyproject.toml``::

    [project.scripts]
    mgf-common = "mgf.common.cli._mgfcli:main"

Argument parsing uses :mod:`argparse` from the stdlib — no
additional dependency on ``click`` or ``typer``. The library does
not want to inflict a CLI framework choice on consumers; argparse
is the lowest common denominator + ships with Python.

Subcommand dispatch is a simple ``match`` on the parsed command
name. Each subcommand module exposes ``add_<name>_args(subparser)``
to register its flags + ``run_<name>(args) -> int`` to execute.
"""

from __future__ import annotations

import argparse
import sys
from typing import TYPE_CHECKING

from mgf.common.cli._doctor import add_doctor_args, run_doctor
from mgf.common.cli._exit_codes import EXIT_UNKNOWN
from mgf.common.cli._explain import add_explain_args, run_explain
from mgf.common.cli._migrate import add_migrate_args, run_migrate
from mgf.common.cli._validate import add_validate_args, run_validate

if TYPE_CHECKING:
    from collections.abc import Sequence


def build_parser() -> argparse.ArgumentParser:
    """Construct the top-level argparse parser + every subparser.

    Exposed so tests can drive the CLI without spawning a
    subprocess (calls ``parser.parse_args([...])`` directly).
    """
    parser = argparse.ArgumentParser(
        prog="mgf-common",
        description=(
            "mgf-common diagnostic CLI — explain settings, validate "
            "config files, run install-state checks."
        ),
    )

    sub = parser.add_subparsers(
        title="subcommands",
        dest="command",
        # required=True would enforce a subcommand on every invocation,
        # but we want `mgf-common --help` (no subcommand) to work; the
        # main() function returns EXIT_UNKNOWN with usage-on-stderr if
        # no subcommand was given.
        required=False,
    )

    explain_p = sub.add_parser(
        "explain",
        help="Print the active MgfSettings with each field's source.",
    )
    add_explain_args(explain_p)

    validate_p = sub.add_parser(
        "validate",
        help="Validate a YAML config file against the MgfSettings schema.",
    )
    add_validate_args(validate_p)

    doctor_p = sub.add_parser(
        "doctor",
        help="Run install-state and wiring health checks.",
    )
    add_doctor_args(doctor_p)

    migrate_p = sub.add_parser(
        "migrate",
        help="Apply mechanical renames to migrate consumer source "
             "from one mgf-common version to another.",
    )
    add_migrate_args(migrate_p)

    return parser


def main(argv: Sequence[str] | None = None) -> int:
    """Console-script entry point.

    Returns the exit code (NEVER raises). When called with no
    subcommand, prints the help text to stderr and returns
    :data:`EXIT_UNKNOWN`.
    """
    if argv is None:
        argv = sys.argv[1:]

    parser = build_parser()
    args = parser.parse_args(list(argv))

    match args.command:
        case "explain":
            return run_explain(args)
        case "validate":
            return run_validate(args)
        case "doctor":
            return run_doctor(args)
        case "migrate":
            return run_migrate(args)
        case _:
            parser.print_help(sys.stderr)
            return EXIT_UNKNOWN


__all__ = [
    "build_parser",
    "main",
]
