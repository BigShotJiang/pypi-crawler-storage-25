"""``mgf.common.cli`` — top-level CLI helpers.

Closes the closed-box leak around CLI exit-code policy + the
boilerplate top-level ``except AppError`` ladder.

Two surfaces:

  - **Exit-code constants** — :data:`EXIT_SUCCESS`,
    :data:`EXIT_CONFIG_ERROR`, :data:`EXIT_OPERATION_ERROR`,
    :data:`EXIT_GUEST_ERROR`, :data:`EXIT_ENVIRONMENT_ERROR`,
    :data:`EXIT_PROVIDER_ERROR`, :data:`EXIT_VAULT_ERROR`,
    :data:`EXIT_UNKNOWN`. Stable across the 0.x window — any
    bump is a breaking change (rule API-04).

  - **Translator** — :func:`run_and_translate` (call-style),
    :func:`translate_exceptions` (decorator-style),
    :func:`main_entry` (one-liner that also calls ``sys.exit``).
    All three route untyped exceptions through
    :func:`mgf.common.observability.report_now` so the crash
    file lands on disk before the process exits.

Phase 5 of the v0.3 closed-box reshape.

Drop-in usage::

    from mgf.common.cli import run_and_translate, EXIT_SUCCESS

    def main(argv: list[str]) -> int:
        # ... your real CLI logic; raise typed exceptions as needed
        return EXIT_SUCCESS

    if __name__ == "__main__":
        import sys
        sys.exit(run_and_translate(main, sys.argv[1:]))
"""

from __future__ import annotations

from mgf.common.cli._exit_codes import (
    EXIT_CONFIG_ERROR,
    EXIT_ENVIRONMENT_ERROR,
    EXIT_GUEST_ERROR,
    EXIT_OPERATION_ERROR,
    EXIT_PROVIDER_ERROR,
    EXIT_SUCCESS,
    EXIT_UNKNOWN,
    EXIT_VAULT_ERROR,
)
from mgf.common.cli._handler import (
    main_entry,
    run_and_translate,
    translate_exceptions,
)

__all__ = [
    "EXIT_CONFIG_ERROR",
    "EXIT_ENVIRONMENT_ERROR",
    "EXIT_GUEST_ERROR",
    "EXIT_OPERATION_ERROR",
    "EXIT_PROVIDER_ERROR",
    "EXIT_SUCCESS",
    "EXIT_UNKNOWN",
    "EXIT_VAULT_ERROR",
    "main_entry",
    "run_and_translate",
    "translate_exceptions",
]
