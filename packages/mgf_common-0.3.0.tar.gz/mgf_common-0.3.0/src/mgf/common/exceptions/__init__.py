"""Typed exception hierarchy for any application built on mgf.common.

The shape mirrors the standard documented in
``docs/standards/ERROR_HANDLING.md``:

  * ``AppError`` — base for every exception raised by application
    code. Subclass to define your project's own base if you want a
    nominal type ("MyAppError"); see VManager's ``vmanager.exceptions``
    module for the canonical pattern.
  * Eight category bases — ``ConfigError``, ``ProviderError``,
    ``OperationError``, ``GuestError``, ``EnvironmentError``,
    ``VaultError``, ``SchedulerError``, plus the
    network/operations-shared ``CommandError`` (lives under
    ``OperationError``).
  * Four generic concretes — ``SchemaValidationError`` (carries
    ``.errors``), ``CommandError`` (carries
    ``.argv`` / ``.returncode`` / ``.stderr``),
    ``ResourceNotFoundError`` (carries ``.name``),
    ``ResourceAlreadyExistsError`` (carries ``.name``). These exist
    because they're useful on their own AND because consumers
    typically subclass them rather than re-implement the field
    plumbing.

Consumer projects subclass per their domain. See
``docs/standards/ERROR_HANDLING.md`` §2 for the full design rationale
and the drop-in template.
"""

from __future__ import annotations

from mgf.common.exceptions._base import AppError
from mgf.common.exceptions._well_known import (
    AppConfigError,
    BootstrapError,
    CancellationError,
    CommandError,
    ConfigError,
    EnvironmentError,  # noqa: A004 — temporary alias for HostEnvironmentError
    GuestCommandError,
    GuestError,
    GuestUnreachableError,
    HostEnvironmentError,
    OperationError,
    ProviderError,
    ResourceAlreadyExistsError,
    ResourceNotFoundError,
    SchedulerError,
    SchemaValidationError,
    VaultError,
)

__all__ = [
    "AppConfigError",
    "AppError",
    "BootstrapError",
    "CancellationError",
    "CommandError",
    "ConfigError",
    "EnvironmentError",
    "GuestCommandError",
    "GuestError",
    "GuestUnreachableError",
    "HostEnvironmentError",
    "OperationError",
    "ProviderError",
    "ResourceAlreadyExistsError",
    "ResourceNotFoundError",
    "SchedulerError",
    "SchemaValidationError",
    "VaultError",
]
