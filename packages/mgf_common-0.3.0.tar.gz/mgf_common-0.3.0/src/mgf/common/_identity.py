"""App-identity cache for the mgf.common observability stack.

Set once at startup via :func:`mgf.common.configure`. Subsequent
calls in the observability layer (``setup_logging``, ``setup_otel``,
``report_now``, ``install_excepthook``, ...) read the identity
from the module-level cache here.

Why module-level state and not a contextvar:
- The identity is process-scoped, not request-scoped.
- A contextvar would suggest "different apps in the same process"
  which is not a real use case for any consumer of this library.
- Module-level state is faster (no descriptor lookup) and simpler
  to reason about.

The defaults below are intentionally placeholder strings — every
production caller MUST call :func:`mgf.common.configure` before any
observability function runs. The defaults exist only so unit tests
that touch the observability layer don't trip on uninitialised
state.
"""

from __future__ import annotations

import warnings

# Defaults are placeholders. Real consumers MUST call configure().
_APP_NAME: str = "app"
_APP_VERSION: str = "unknown"

# Tracks whether configure() has been called this process. Reading
# identity (app_name() / app_version()) before configure() emits a
# one-shot UserWarning so the silent-wrong-default failure mode
# (logs land at ``<state>/app/logs/app.log``, crash reports'
# ``app`` field reads ``"app"``) becomes loud.
#
# Closes FEEDBACK API-08. Warning, not error — third-party test
# harnesses that transitively import ``mgf.common.observability``
# must NOT be broken by a missing configure().
_CONFIGURED: bool = False
_UNCONFIGURED_WARNED: bool = False


class UnconfiguredWarning(UserWarning):
    """Identity was read before :func:`configure` was called.

    Raised once per process, not per call, to avoid spam. Inherits
    from :class:`UserWarning` so it shows by default but does not
    break test harnesses that have ``filterwarnings = ["error"]``
    set against the project's own warning categories (consumers
    that want this loud can ``warnings.filterwarnings("error",
    category=UnconfiguredWarning)``).
    """


def configure(app_name: str, app_version: str = "unknown") -> None:
    """Set the app identity for the entire mgf.common stack.

    Call once at startup, before any other ``mgf.common.*`` function
    that emits observability data (logging setup, OTel setup, crash
    reporter, excepthook installation).

    Parameters
    ----------
    app_name
        Short lower-case name for the consuming application
        (e.g., ``"vmanager"``). Used as the default service name in
        OTel traces, the log file directory under ``<state>/``, the
        prefix for env vars (``<APP_NAME>_CRASH_SINK``,
        ``<APP_NAME>_LOG_HTTP_SINK``, ``<APP_NAME>_SYSLOG_ADDR``),
        and the SYSLOG identifier for journald.
    app_version
        Version string included in crash reports. Default
        ``"unknown"``. Pass ``__version__`` from your top-level
        package.

    Idempotent: calling again replaces the cached identity. In
    practice this is only useful in tests that exercise multiple
    consumer-app shapes; production callers configure once.
    """
    global _APP_NAME, _APP_VERSION, _CONFIGURED
    _APP_NAME = app_name
    _APP_VERSION = app_version
    _CONFIGURED = True


def _warn_if_unconfigured() -> None:
    """Emit ``UnconfiguredWarning`` once on first read before configure().

    The one-shot guard (``_UNCONFIGURED_WARNED``) prevents spam.
    The warning is loud enough that operators see it in the first
    log line; it is not an exception so transitive imports don't
    break.
    """
    global _UNCONFIGURED_WARNED
    if _CONFIGURED or _UNCONFIGURED_WARNED:
        return
    _UNCONFIGURED_WARNED = True
    warnings.warn(
        "mgf.common: app identity not configured — reading the placeholder "
        "default 'app'. Call mgf.common.configure(app_name=..., "
        "app_version=...) at your entry point before any observability "
        "function. See PUBLIC_API.md for details.",
        UnconfiguredWarning,
        stacklevel=3,  # past the wrapper + past app_name/app_version
    )


def app_name() -> str:
    """Return the current app name.

    Resolution order (FEEDBACK §6 Option C / closed-box redesign §4.1):

    1. The active :class:`mgf.common.AppContext` if one is set
       (via :func:`mgf.common.bootstrap` or per-task contextvar).
    2. The module-level global set by the legacy
       :func:`configure` path.
    3. The placeholder ``"app"`` (with a one-shot
       :class:`UnconfiguredWarning` — closes FEEDBACK API-08).
    """
    # Lazy import to break a startup cycle: lifecycle imports from
    # settings → exceptions → exceptions imports nothing from us,
    # but lifecycle ALSO imports from this module's neighbour
    # (logging_setup which calls app_name()). The lazy import keeps
    # the cycle dormant until first call.
    from mgf.common._lifecycle import current_context

    ctx = current_context()
    if ctx is not None:
        return ctx.app_name
    _warn_if_unconfigured()
    return _APP_NAME


def app_version() -> str:
    """Return the current app version.

    Resolution order (same as :func:`app_name`).
    """
    from mgf.common._lifecycle import current_context

    ctx = current_context()
    if ctx is not None:
        return ctx.app_version
    _warn_if_unconfigured()
    return _APP_VERSION


__all__ = ["UnconfiguredWarning", "app_name", "app_version", "configure"]
