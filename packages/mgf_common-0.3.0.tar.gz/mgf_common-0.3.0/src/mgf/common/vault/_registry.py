"""Decorator-driven registry for custom vault backends.

Closes the closed-box leak around third-party vault stores
(HashiCorp Vault, AWS Secrets Manager, custom HSM). Consumers
register a backend factory under a name; downstream wiring (the
future ``open_vault(settings)`` helper that consults
:class:`mgf.common.settings.VaultSettings.backend`) consults the
registry instead of the built-in env / keyring / file branches.

Pattern matches Phase 3 — see
``mgf.common.observability.crash_reporter.register_crash_sink``.

Example::

    from pathlib import Path
    from typing import Any

    from mgf.common.typing import VaultProtocol
    from mgf.common.vault import register_vault_backend

    @register_vault_backend("hashicorp")
    def make_hashicorp_vault(settings: dict[str, Any]) -> VaultProtocol:
        import hvac

        client = hvac.Client(url=settings["url"], token=settings["token"])
        return MyHashicorpAdapter(client, mount=settings.get("mount", "secret"))

The built-in backends (``"env"`` / ``"keyring"`` / ``"file"``)
are pre-registered at import of ``mgf.common.vault``.

Threading: registration is single-threaded — call at
module-import / bootstrap time, not from a worker. The registry
itself is read-only on the hot path.
"""

from __future__ import annotations

from collections.abc import Callable
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from mgf.common.typing import VaultProtocol


VaultBackendFactory = Callable[[dict[str, Any]], "VaultProtocol"]
"""Type alias for vault-backend factory callables.

The factory receives a dict of backend-specific configuration
(typically derived from :class:`mgf.common.settings.VaultSettings`)
and returns an instance implementing
:class:`mgf.common.typing.VaultProtocol`.
"""

_VAULT_BACKENDS: dict[str, VaultBackendFactory] = {}


def register_vault_backend(
    name: str,
) -> Callable[[VaultBackendFactory], VaultBackendFactory]:
    """Decorator: register a custom vault-backend factory under ``name``.

    The factory fires when the active configuration names
    ``backend = "<name>"``. Built-in backends (``"env"`` /
    ``"keyring"`` / ``"file"``) are pre-registered at import time
    of ``mgf.common.vault``.

    Raises :class:`ValueError` if ``name`` is already registered;
    callers MUST :func:`unregister_vault_backend` before
    re-registering (this catches accidental double-registration
    in plug-in chains).

    Threading: register at import / bootstrap time, not from a
    worker.
    """

    def decorator(fn: VaultBackendFactory) -> VaultBackendFactory:
        if name in _VAULT_BACKENDS:
            raise ValueError(
                f"vault backend {name!r} is already registered "
                f"(unregister first if you intend to replace it)"
            )
        _VAULT_BACKENDS[name] = fn
        return fn

    return decorator


def unregister_vault_backend(name: str) -> None:
    """Remove a registered vault backend. No-op if ``name`` is unknown.

    Useful for tests + for consumers swapping a backend at runtime.
    """
    _VAULT_BACKENDS.pop(name, None)


def _registered_vault_backends() -> dict[str, VaultBackendFactory]:
    """Internal: snapshot of the registry. Used by tests + the
    (future) ``mgf-common doctor`` diagnostic."""
    return dict(_VAULT_BACKENDS)


__all__ = [
    "VaultBackendFactory",
    "register_vault_backend",
    "unregister_vault_backend",
]
