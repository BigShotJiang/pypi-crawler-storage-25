"""``mgf.common.vault`` — credential storage backends.

Closes FEEDBACK §3.2. Phase 5 of the v0.3 closed-box reshape.

Three built-in backends, each implementing
:class:`mgf.common.typing.VaultProtocol`:

  - :class:`EnvVault` — stdlib-only; reads / writes
    ``<prefix><KEY>`` env vars. The right backend for CI /
    containerised deployments where the orchestrator injects
    secrets at process-start time. Works WITHOUT the optional
    ``[vault]`` extra installed.

  - :class:`KeyringVault` — system credential store via the
    third-party :mod:`keyring` library (libsecret / Keychain /
    Credential Manager). Requires ``mgf-common[vault]``. The
    desktop default — secrets persist across runs without the
    consumer managing a passphrase.

  - :class:`EncryptedFileVault` — Fernet (AES-128 + HMAC-SHA256)
    encrypted JSON-on-disk; PBKDF2-HMAC-SHA256 with 600 000
    iterations (OWASP 2023 baseline per rule SC-05). Requires
    ``mgf-common[vault]``. The fallback for headless Linux /
    embedded CI where no keyring daemon runs.

Custom backends — third-party stores (HashiCorp Vault, AWS
Secrets Manager) — are added via the registry::

    from mgf.common.vault import register_vault_backend

    @register_vault_backend("hashicorp")
    def make_vault(config):
        ...

The built-in backends are pre-registered at import time:
``"env"`` / ``"keyring"`` / ``"file"``.

Audit logging: every backend emits an ``audit=true`` log record
on ``get`` / ``set`` / ``delete`` per rule SC-17. The KEY is
logged; the VALUE is not.

Closed-box property: consumers DO NOT import :mod:`keyring`,
:mod:`cryptography`, or any backend-specific module directly —
they pass a ``VaultProtocol`` everywhere. Switching backends is
a single line at bootstrap.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from mgf.common.vault._env_vault import EnvVault
from mgf.common.vault._registry import (
    VaultBackendFactory,
    register_vault_backend,
    unregister_vault_backend,
)

if TYPE_CHECKING:
    from mgf.common.typing import VaultProtocol


# ---------------------------------------------------------------------------
# Lazy re-exports of the [vault]-extra backends
# ---------------------------------------------------------------------------
#
# KeyringVault + EncryptedFileVault import the optional
# :mod:`keyring` / :mod:`cryptography` libraries lazily — they
# raise :class:`mgf.common.exceptions.VaultError` (chained from
# the original ImportError) only when CONSTRUCTED without the
# extra installed. Importing the symbol is always safe; just
# don't instantiate without the extra.

from mgf.common.vault._file_vault import EncryptedFileVault
from mgf.common.vault._keyring_vault import KeyringVault

# ---------------------------------------------------------------------------
# Built-in backend pre-registration
# ---------------------------------------------------------------------------
#
# These three names are always available in the registry so
# downstream consumers (and the future ``open_vault(settings)``
# helper) can construct a backend by name without forking on
# the built-in vs. consumer-registered path.


@register_vault_backend("env")
def _make_env_vault(config: dict[str, Any]) -> VaultProtocol:
    """Built-in env-var backend factory. Pre-registered.

    Recognised config keys:
      - ``prefix`` (str, default ``"MGF_VAULT_"``).
    """
    return EnvVault(prefix=config.get("prefix", "MGF_VAULT_"))


@register_vault_backend("keyring")
def _make_keyring_vault(config: dict[str, Any]) -> VaultProtocol:
    """Built-in system-keyring backend factory. Pre-registered.

    Recognised config keys:
      - ``service`` (str, default ``"mgf-common"``).

    Requires the ``[vault]`` extra; raises
    :class:`mgf.common.exceptions.VaultError` on construction
    if the extra is not installed.
    """
    return KeyringVault(service=config.get("service", "mgf-common"))


@register_vault_backend("file")
def _make_file_vault(config: dict[str, Any]) -> VaultProtocol:
    """Built-in encrypted-file backend factory. Pre-registered.

    Recognised config keys:
      - ``path`` (Path / str, REQUIRED).
      - ``passphrase`` (str, REQUIRED — consumer prompts / retrieves).

    Requires the ``[vault]`` extra; raises
    :class:`mgf.common.exceptions.VaultError` on construction
    if the extra is not installed OR if either required key is
    missing.
    """
    from pathlib import Path

    from mgf.common.exceptions import VaultError

    path = config.get("path")
    passphrase = config.get("passphrase")
    if path is None or passphrase is None:
        raise VaultError(
            "file vault factory requires both 'path' and 'passphrase' "
            "in the config dict"
        )
    return EncryptedFileVault(Path(path), passphrase=passphrase)


__all__ = [
    "EncryptedFileVault",
    "EnvVault",
    "KeyringVault",
    "VaultBackendFactory",
    "register_vault_backend",
    "unregister_vault_backend",
]
