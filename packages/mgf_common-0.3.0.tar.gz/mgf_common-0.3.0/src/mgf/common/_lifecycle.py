"""Lifecycle: ``bootstrap()`` + ``AppContext`` + ``current_context()``.

The single canonical entry point for ``mgf-common``. Replaces the
v0.1 five-call sequence (``configure`` + ``setup_logging`` +
``setup_otel`` + ``install_excepthook`` +
``install_threading_excepthook``) with one transactional context
manager.

Design refs (in ``docs/CLOSED_BOX_REDESIGN.md``):

- §4.1   The lifecycle surface.
- §14.2  Bootstrap atomicity — transactional setup with rollback.
- §14.3  Bootstrap-time logging — deferred replay buffer.
- §14.5  Hot-reload via ``AppContext.reload(new_settings)``.
- §14.10 Bootstrap idempotency — replace + AUDIT log.

This module is the load-bearing surface of v0.3. The v0.1 APIs
(``configure``, ``setup_logging``, ``setup_otel``,
``install_excepthook``, ``install_threading_excepthook``) keep
working unchanged in Phase 1 so existing tests + consumer code
stay green; the deprecation warnings start in a focused later
phase.

Typical use::

    import mgf.common

    with mgf.common.bootstrap(app_name="myapp", app_version="1.0"):
        do_work()

For long-running services without a natural ``with`` scope::

    ctx = mgf.common.bootstrap(app_name="myapp", app_version="1.0")
    try:
        do_work()
    finally:
        ctx.shutdown()

Note: when used as ``ctx = bootstrap(...)`` (without ``with``),
the returned object is the AppContext itself, NOT the
contextmanager wrapper. The :func:`bootstrap` function checks
its call site and adapts (see implementation).
"""

from __future__ import annotations

import contextlib
import contextvars
import logging
import sys
import threading
from contextlib import contextmanager
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any

from mgf.common.exceptions import BootstrapError
from mgf.common.settings import MgfSettings

if TYPE_CHECKING:
    from collections.abc import Callable, Iterator

LOG = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Active-context discovery
# ---------------------------------------------------------------------------
#
# Hybrid model per FEEDBACK §6 Option C:
#   - ``_GLOBAL_CONTEXT``    → process-wide singleton, set by
#                              ``bootstrap()``. The 95 % case (single-
#                              app processes).
#   - ``_CONTEXT_VAR``       → per-task / per-thread override pushed
#                              by ``with AppContext(...):``. The 5 %
#                              case (plug-in architectures, monorepo
#                              test runs).
#
# ``current_context()`` consults the contextvar first, falls back
# to the global. Reads are O(1); fast path is a single
# ``ContextVar.get()`` call (~30 ns).


_GLOBAL_CONTEXT: AppContext | None = None
_CONTEXT_VAR: contextvars.ContextVar[AppContext | None] = contextvars.ContextVar(
    "mgf_common_context",
    default=None,
)
_RELOAD_LOCK = threading.Lock()


# ---------------------------------------------------------------------------
# Wiring handles — internal state for shutdown / rollback
# ---------------------------------------------------------------------------


@dataclass
class _WiringHandles:
    """Tracks every reversible side-effect of bootstrap.

    The lifecycle module appends ``(name, rollback_fn)`` tuples
    here as each wiring step succeeds. ``shutdown()`` (and
    ``bootstrap()``'s rollback path) walk this list LIFO, calling
    each ``rollback_fn`` with ``contextlib.suppress(Exception)``
    so a single failing rollback doesn't block the others.

    Internal — consumers never touch this directly.
    """

    rollbacks: list[tuple[str, Callable[[], None]]] = field(default_factory=list)
    prior_excepthook: Any = None
    prior_threading_excepthook: Any = None
    prior_app_name: str = "app"
    prior_app_version: str = "unknown"
    prior_logger_levels: dict[str, int] = field(default_factory=dict)
    bootstrap_log_buffer: _BootstrapLogBuffer | None = None


# ---------------------------------------------------------------------------
# AppContext — frozen identity + settings snapshot
# ---------------------------------------------------------------------------


@dataclass
class AppContext:
    """Per-tenant identity + settings for ``mgf-common``.

    Constructed by :func:`bootstrap` (or directly for opt-in
    multi-tenancy via ``with AppContext(...):`` — Phase 2+).

    Attributes
    ----------
    app_name
        Short app identifier (e.g., ``"myapp"``). Used as the
        OTel ``service.name``, the default log-file directory
        under ``<state>/``, and the env-var prefix for
        consumer-app settings.
    app_version
        Version string (e.g., ``"1.0.0"``). Pass your top-level
        package's ``__version__``.
    settings
        The active :class:`mgf.common.settings.MgfSettings`
        snapshot. Library reads from this only.
    _wiring
        Internal :class:`_WiringHandles` used by :meth:`shutdown`
        and :meth:`reload` to reverse + re-apply wiring. Not
        part of the public API.

    Threading model
    ---------------
    - Construction:     single-threaded (bootstrap-time).
    - ``shutdown()``:   single-threaded — call from the same thread
                        that called bootstrap.
    - ``reload()``:     lock-protected — internal lock serialises
                        concurrent reloads.

    See ``docs/CLOSED_BOX_REDESIGN.md`` §14.9 for the full
    threading-model table.
    """

    app_name: str
    app_version: str
    settings: MgfSettings
    _wiring: _WiringHandles = field(repr=False, compare=False)
    _shut_down: bool = field(default=False, repr=False, compare=False)

    def shutdown(self) -> None:
        """Reverse every wiring step LIFO, restoring pre-bootstrap state.

        Idempotent — calling twice is a no-op (the second call
        finds ``_shut_down=True`` and returns).

        Each rollback is wrapped in ``try / except`` so a single
        failure (e.g., a log handler whose ``close()`` raises)
        does not block the others. Failures are logged at WARNING
        level to stderr (best-effort visibility).
        """
        if self._shut_down:
            return
        self._shut_down = True

        # Walk the stack LIFO so the most-recently-wired step
        # rolls back first. Mirrors how a transactional rollback
        # peels back the call graph.
        for name, rollback_fn in reversed(self._wiring.rollbacks):
            try:
                rollback_fn()
            except Exception as e:
                # Rollback never raises — print to stderr; we
                # cannot rely on the logging stack being in a sane
                # state during shutdown.
                print(
                    f"mgf.common shutdown: rollback {name!r} failed: {e}",
                    file=sys.stderr,
                )

        # Clear the global if this context was the active one.
        global _GLOBAL_CONTEXT
        if _GLOBAL_CONTEXT is self:
            _GLOBAL_CONTEXT = None

    def reload(self, new_settings: MgfSettings) -> AppContext:
        """Re-apply wiring with new settings. Atomic.

        Closes FEEDBACK design ref §14.5 — the programmatic API
        for hot-reload. Consumers wire SIGHUP / inotify / polling
        themselves and call this method from the handler.

        On success, returns a NEW ``AppContext`` reflecting the
        new settings; the caller MUST update any stored
        references. On failure, raises :class:`BootstrapError`
        and the OLD wiring is preserved (the reload is atomic
        with the same rollback stack as ``bootstrap()``).

        ``app_name`` and ``app_version`` are NOT changeable via
        reload — they are part of the bootstrap identity and
        affect OTel ``service.name`` (which is process-global per
        FEEDBACK design ref §14.4). Use a fresh ``bootstrap()``
        if you need to change identity.

        Phase 1 implementation: stub that re-wires by tearing
        down + bootstrapping again. Phase 2 will replace this
        with a finer-grained per-subsystem reload (configurable
        which subsystems re-wire).
        """
        with _RELOAD_LOCK:
            old_settings = self.settings
            self.shutdown()
            try:
                # Re-bootstrap with new settings. The result is a
                # fresh AppContext bound to the new wiring.
                new_ctx = _bootstrap_inner(
                    self.app_name, self.app_version, new_settings,
                )
            except BootstrapError:
                # Reload failed — try to restore the OLD wiring
                # so the process isn't left uninitialised. If
                # restore ALSO fails, we re-raise with the
                # restore failure as a chained exception.
                try:
                    _bootstrap_inner(self.app_name, self.app_version, old_settings)
                except BootstrapError as restore_e:
                    LOG.error(
                        "reload failed AND restore failed; library is uninitialised",
                        extra={"audit": True, "event": "reload.unrecoverable"},
                    )
                    raise restore_e
                raise
            return new_ctx


# ---------------------------------------------------------------------------
# Bootstrap-time log buffer (FEEDBACK §14.3)
# ---------------------------------------------------------------------------


class _BootstrapLogBuffer(logging.Handler):
    """Captures records emitted DURING bootstrap, replays them
    through the configured handlers once setup completes.

    Wired at bootstrap entry; replayed at the end of
    ``_wire_logging`` (or at any successful end-of-bootstrap);
    removed from the root logger after replay. No records are
    lost; no records are duplicated.

    On bootstrap FAILURE, the buffer flushes to stderr (best-
    effort visibility). The operator sees what happened before
    the BootstrapError is raised.

    Closes FEEDBACK design ref §14.3 (no story for logging from
    inside bootstrap itself).
    """

    def __init__(self) -> None:
        super().__init__(level=logging.DEBUG)
        self._records: list[logging.LogRecord] = []

    def emit(self, record: logging.LogRecord) -> None:
        """Append the record to the in-memory buffer."""
        self._records.append(record)

    def replay_to(self, target_handlers: list[logging.Handler]) -> None:
        """Replay every captured record through ``target_handlers``.

        Each handler's level filter applies, so records emitted at
        DEBUG during bootstrap that the production root logger is
        configured to drop (level=INFO) get dropped here too —
        consistent with what would have happened if the production
        handlers had been wired before the records emitted.
        """
        for record in self._records:
            for h in target_handlers:
                if record.levelno >= h.level:
                    # Best-effort replay; one failing handler MUST
                    # NOT block replay through siblings.
                    with contextlib.suppress(Exception):
                        h.handle(record)

    def flush_to_stderr(self) -> None:
        """Emergency flush when bootstrap FAILED before logging
        was wired. Operators see what happened during the failed
        bootstrap before the BootstrapError surfaces."""
        for record in self._records:
            # Last-ditch. Skip records we can't even format.
            with contextlib.suppress(Exception):
                msg = self.format(record) if self.formatter else record.getMessage()
                sys.stderr.write(f"[mgf.common bootstrap] {msg}\n")


# ---------------------------------------------------------------------------
# bootstrap() — the single canonical entry point
# ---------------------------------------------------------------------------


def bootstrap(
    app_name: str,
    app_version: str,
    *,
    settings: MgfSettings | None = None,
) -> _BootstrapContext:
    """The single canonical bootstrap. Wires every observability
    subsystem in the correct order, returns the active context,
    cleans up on exit.

    Usage as a context manager (recommended)::

        with mgf.common.bootstrap(app_name="myapp", app_version="1.0") as ctx:
            do_work()

    Or as a one-shot returning the AppContext (for long-running
    services that own the lifecycle explicitly)::

        ctx = mgf.common.bootstrap(app_name="myapp", app_version="1.0")
        try:
            do_work()
        finally:
            ctx.shutdown()

    Parameters
    ----------
    app_name
        Short app identifier. Sets OTel ``service.name``, the
        default log-file directory, the SYSLOG identifier.
    app_version
        Version string. Pass your top-level package's
        ``__version__``.
    settings
        Optional :class:`mgf.common.settings.MgfSettings` instance.
        When omitted, defaults to ``MgfSettings(preset="auto")`` —
        preserves v0.1 auto-detection (TTY / JOURNAL_STREAM /
        OTEL endpoint) for legacy consumers (closes FEEDBACK design
        ref §14.15). Pass ``MgfSettings(...)`` for explicit
        configuration; the default is ``preset="explicit"`` in
        that path.

    Atomicity (FEEDBACK design ref §14.2)
    -------------------------------------
    Bootstrap is **transactional**. Each internal wiring step
    appends a rollback closure. On any failure, the stack is
    unwound LIFO, partial state is reversed, and a typed
    :class:`BootstrapError` is raised carrying the failed step
    name + the original cause via ``__cause__``.

    Idempotency (FEEDBACK design ref §14.10)
    ----------------------------------------
    Calling ``bootstrap()`` a second time without an intervening
    ``shutdown()`` REPLACES the active context (last-call-wins)
    and emits an AUDIT log record (``event="bootstrap.replace"``)
    so operators can find rogue re-bootstraps. Why replace not
    error: test harnesses and notebooks legit need to
    re-bootstrap; erroring would force a more complex pattern.

    Returns
    -------
    :class:`_BootstrapContext`
        Dual-mode object that's both an :class:`AppContext` (for
        ``ctx = bootstrap(...)`` usage) AND a context manager
        (for ``with bootstrap(...) as ctx:`` usage).
    """
    if settings is None:
        # FEEDBACK §14.15 — auto preset preserves v0.1 behaviour
        # when consumer didn't opt into explicit settings.
        settings = MgfSettings(preset="auto")

    # FEEDBACK §14.10 — idempotency: replace previous context
    # and AUDIT-log so accidental re-bootstraps are visible.
    if _GLOBAL_CONTEXT is not None:
        prior = _GLOBAL_CONTEXT
        LOG.warning(
            "bootstrap called again; replacing existing context",
            extra={
                "audit": True,
                "event": "bootstrap.replace",
                "previous_app_name": prior.app_name,
                "previous_app_version": prior.app_version,
                "new_app_name": app_name,
                "new_app_version": app_version,
            },
        )
        prior.shutdown()

    ctx = _bootstrap_inner(app_name, app_version, settings)
    return _BootstrapContext(ctx)


def _bootstrap_inner(
    app_name: str,
    app_version: str,
    settings: MgfSettings,
) -> AppContext:
    """The core wiring sequence with rollback. Internal — called
    by :func:`bootstrap` and :meth:`AppContext.reload`.
    """
    from mgf.common import _identity

    wiring = _WiringHandles()

    # 1. Install the bootstrap log buffer FIRST so any record
    #    emitted from the wiring steps below is captured even
    #    before logging is fully configured (§14.3).
    buffer = _BootstrapLogBuffer()
    logging.root.addHandler(buffer)
    wiring.bootstrap_log_buffer = buffer

    failed_step = "<not-started>"
    try:
        # 2. Wire identity. Saves the prior values so rollback can
        #    restore them.
        failed_step = "identity"
        wiring.prior_app_name = _identity._APP_NAME
        wiring.prior_app_version = _identity._APP_VERSION
        _identity.configure(app_name, app_version)
        wiring.rollbacks.append(
            ("identity", lambda: _restore_identity(wiring)),
        )

        # 3. Build the AppContext now so the rest of the wiring
        #    can attach rollbacks to it.
        new_context = AppContext(
            app_name=app_name,
            app_version=app_version,
            settings=settings,
            _wiring=wiring,
        )

        # 4. Wire logging. Phase 1: defer to existing setup_logging
        #    helper for backward compat. Phase 6 will read more
        #    fields from MgfSettings.logging.
        failed_step = "logging"
        import re as _re

        from mgf.common.observability.logging_setup import _wire_logging
        from mgf.common.observability.redaction import (
            Redactor,
            _resolve_pattern_groups,
        )

        # Resolve pattern groups → tuple of compiled regexes.
        # Closes Phase 3's wiring of
        # MgfSettings.redaction.enabled_pattern_groups → the registry.
        # NOTE: "builtin" is always-on via Redactor._scrub_string's
        # iteration of _BUILTIN_VALUE_PATTERNS, so we filter it out
        # here to avoid double-scanning. Consumer-registered groups
        # ARE passed through.
        non_builtin_groups = [
            g for g in settings.redaction.enabled_pattern_groups
            if g != "builtin"
        ]
        resolved_patterns = _resolve_pattern_groups(non_builtin_groups)
        # Compose with any consumer-supplied raw regex strings from
        # settings.redaction.extra_value_patterns (compiled here).
        extra_compiled = tuple(
            _re.compile(p) for p in settings.redaction.extra_value_patterns
        )
        log_redactor = Redactor(
            extra_keys=settings.redaction.extra_keys,
            extra_value_patterns=resolved_patterns + extra_compiled,
        )
        _wire_logging(
            level=settings.logging.level,
            fmt=settings.logging.format,
            log_file=settings.logging.file,
            redactor=log_redactor,
        )
        wiring.rollbacks.append(("logging", _unwire_logging))

        # 5. Apply per-component level overrides (§14.6).
        failed_step = "level_overrides"
        for logger_name, level_str in settings.logging.level_overrides.items():
            logger = logging.getLogger(logger_name)
            wiring.prior_logger_levels[logger_name] = logger.level
            logger.setLevel(getattr(logging, level_str))
        wiring.rollbacks.append(
            ("level_overrides", lambda: _restore_logger_levels(wiring)),
        )

        # 6. Replay the bootstrap log buffer through the now-wired
        #    handlers + remove the buffer from root.
        failed_step = "buffer_replay"
        buffer.replay_to(logging.root.handlers)
        logging.root.removeHandler(buffer)
        wiring.bootstrap_log_buffer = None

        # 7. Wire OTel.
        failed_step = "otel"
        from mgf.common.observability.otel_setup import _wire_otel
        _wire_otel(enabled=settings.otel.enabled if settings.otel.enabled else None)
        wiring.rollbacks.append(("otel", _unwire_otel))

        # 8. Wire excepthooks.
        failed_step = "excepthooks"
        wiring.prior_excepthook = sys.excepthook
        wiring.prior_threading_excepthook = threading.excepthook
        from mgf.common.observability.excepthook import _wire_excepthook
        from mgf.common.observability.threading_excepthook import (
            _wire_threading_excepthook,
        )
        _wire_excepthook()
        _wire_threading_excepthook()
        wiring.rollbacks.append(
            ("excepthooks", lambda: _restore_excepthooks(wiring)),
        )

        # 9. Crash sinks — Phase 1 doesn't change the existing
        #    env-var-driven sink machinery; Phase 3 introduces
        #    the registry pattern.
        failed_step = "crash_sinks"
        # No-op for Phase 1; rollback is also no-op.
        wiring.rollbacks.append(("crash_sinks", lambda: None))

    except BaseException as e:
        # Roll back every wiring step LIFO. Suppress secondary
        # rollback failures (§14.2 + §10 Q11 recommendation).
        for name, rollback_fn in reversed(wiring.rollbacks):
            try:
                rollback_fn()
            except Exception as rb_e:
                print(
                    f"mgf.common bootstrap: rollback {name!r} failed: {rb_e}",
                    file=sys.stderr,
                )
        # Flush the bootstrap log buffer to stderr so the operator
        # sees what was logged during the failed bootstrap.
        if wiring.bootstrap_log_buffer is not None:
            with contextlib.suppress(Exception):
                wiring.bootstrap_log_buffer.flush_to_stderr()
            with contextlib.suppress(Exception):
                logging.root.removeHandler(wiring.bootstrap_log_buffer)

        raise BootstrapError(failed_step, cause=e) from e

    # Set as the active global context. Multi-tenancy (Phase 2+):
    # AppContext-as-context-manager will push to _CONTEXT_VAR
    # instead of the global.
    global _GLOBAL_CONTEXT
    _GLOBAL_CONTEXT = new_context
    return new_context


# ---------------------------------------------------------------------------
# Rollback helpers — internal
# ---------------------------------------------------------------------------


def _restore_identity(wiring: _WiringHandles) -> None:
    from mgf.common import _identity

    _identity._APP_NAME = wiring.prior_app_name
    _identity._APP_VERSION = wiring.prior_app_version


def _unwire_logging() -> None:
    """Remove every handler from the root logger + reset basicConfig.

    Best-effort. Each handler is closed before removal so
    ``RotatingFileHandler``'s file descriptor is released cleanly.
    """
    for handler in list(logging.root.handlers):
        with contextlib.suppress(Exception):
            handler.close()
        with contextlib.suppress(Exception):
            logging.root.removeHandler(handler)


def _restore_logger_levels(wiring: _WiringHandles) -> None:
    for logger_name, prior_level in wiring.prior_logger_levels.items():
        logging.getLogger(logger_name).setLevel(prior_level)


def _unwire_otel() -> None:
    """Best-effort OTel teardown.

    OpenTelemetry's TracerProvider can't be 'reset' to a no-op
    cleanly — ``set_tracer_provider`` is one-shot per process.
    The pragmatic approach: shut down any active provider so its
    BatchSpanProcessor flushes; we accept that the tracer remains
    set (subsequent calls become no-ops if OTel is disabled).
    """
    with contextlib.suppress(Exception):
        from opentelemetry import trace as _trace

        provider = _trace.get_tracer_provider()
        shutdown = getattr(provider, "shutdown", None)
        if callable(shutdown):
            shutdown()


def _restore_excepthooks(wiring: _WiringHandles) -> None:
    sys.excepthook = wiring.prior_excepthook
    threading.excepthook = wiring.prior_threading_excepthook


# ---------------------------------------------------------------------------
# current_context() — readonly accessor
# ---------------------------------------------------------------------------


def current_context() -> AppContext | None:
    """Return the active :class:`AppContext`, or ``None`` if
    ``bootstrap()`` has not been called yet.

    Resolution order (FEEDBACK §6 Option C):
    1. Per-task contextvar (set by ``with AppContext(...):`` —
       Phase 2+).
    2. Process-wide global (set by ``bootstrap()``).

    Reads are O(1); the fast path is a single ``ContextVar.get()``.

    Threading: thread-safe. Safe to call from any thread; safe to
    call from inside an asyncio task (contextvars propagate
    correctly across ``await`` points).
    """
    ctx = _CONTEXT_VAR.get()
    if ctx is not None:
        return ctx
    return _GLOBAL_CONTEXT


# ---------------------------------------------------------------------------
# Dual-mode return wrapper for ``bootstrap()``
# ---------------------------------------------------------------------------


class _BootstrapContext:
    """Wraps an :class:`AppContext` so ``bootstrap(...)`` can be
    used both as ``ctx = bootstrap(...)`` AND as
    ``with bootstrap(...) as ctx:``.

    The wrapper IS-A AppContext (delegates every attribute access)
    AND has ``__enter__`` / ``__exit__`` so ``with`` works.

    Implementation note: we don't use ``@contextmanager`` because
    that prevents the non-``with`` usage. The dual-mode shape is
    what design ref §4.1 prescribes ("usage as a context manager
    OR as a one-shot returning the AppContext").
    """

    def __init__(self, ctx: AppContext) -> None:
        self._ctx = ctx

    def __enter__(self) -> AppContext:
        return self._ctx

    def __exit__(self, exc_type: Any, exc: Any, tb: Any) -> None:
        self._ctx.shutdown()

    # Delegate attribute access to the wrapped AppContext so
    # ``bootstrap(...).app_name`` works without ``with``.
    def __getattr__(self, name: str) -> Any:
        return getattr(self._ctx, name)


# ---------------------------------------------------------------------------
# AppContext as a context manager (Phase 2+) — placeholder
# ---------------------------------------------------------------------------


@contextmanager
def _appcontext_cm(ctx: AppContext) -> Iterator[AppContext]:
    """Push an AppContext onto the contextvar stack for the
    duration of a ``with`` block. Phase 2+ uses this for opt-in
    multi-tenancy; Phase 1 ships the seam without exposing it.
    """
    token = _CONTEXT_VAR.set(ctx)
    try:
        yield ctx
    finally:
        _CONTEXT_VAR.reset(token)


__all__ = [
    "AppContext",
    "bootstrap",
    "current_context",
]
