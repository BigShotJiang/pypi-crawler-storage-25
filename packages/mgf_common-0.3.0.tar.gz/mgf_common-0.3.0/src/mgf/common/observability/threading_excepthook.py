"""Non-main-thread unhandled-exception hook.

Without this, an uncaught exception in a thread is logged to stderr by
the Python runtime and otherwise lost — no crash report, no remote sink,
nothing in the application's structured log.

Idempotent — second call is a no-op.

See ``docs/standards/ERROR_HANDLING.md`` §4.3.
"""

from __future__ import annotations

import logging
import threading

from mgf.common._identity import app_name
from mgf.common.observability.crash_reporter import report_now

_INSTALLED_MARKER = "_mgf_common_threading_excepthook_installed"


def _wire_threading_excepthook() -> None:
    """Install :func:`threading.excepthook` wrapper (rule EH-04).

    Internal — called by :func:`mgf.common.bootstrap` and by the
    deprecated :func:`install_threading_excepthook` shim.
    """
    prior = threading.excepthook
    if getattr(prior, _INSTALLED_MARKER, False):
        return

    log = logging.getLogger(f"{app_name()}.unhandled")

    def hook(args: threading.ExceptHookArgs) -> None:
        # SystemExit raised inside a thread is the canonical "thread
        # is asked to stop" signal — don't crash-report it.
        if args.exc_type is SystemExit:
            return

        thread_name = args.thread.name if args.thread is not None else "?"
        # ``args.exc_value`` is typed as ``BaseException | None`` by
        # the stdlib, but in practice ``threading.excepthook`` only
        # fires when something was actually raised — the value is
        # ``None`` only for synthetic cases that real threads cannot
        # produce. Guard it explicitly so we never feed ``None`` into
        # the logger or crash reporter, and so mypy is happy with the
        # ``exc_info`` triple type.
        if args.exc_value is None:
            return
        log.error(
            "unhandled exception in thread %s",
            thread_name,
            exc_info=(args.exc_type, args.exc_value, args.exc_traceback),
        )
        report_now(args.exc_value, source=f"thread:{thread_name}")
        prior(args)

    setattr(hook, _INSTALLED_MARKER, True)
    threading.excepthook = hook


def install_threading_excepthook() -> None:
    """Deprecated — use :func:`mgf.common.bootstrap` instead.

    Emits :class:`mgf.common._warnings.MgfDeprecationWarning` and
    delegates to ``_wire_threading_excepthook``. Removed in v1.0.
    """
    import warnings

    from mgf.common._warnings import MgfDeprecationWarning

    warnings.warn(
        "mgf.common.observability.install_threading_excepthook is "
        "deprecated since v0.3.0; use mgf.common.bootstrap(...) which "
        "installs the hooks transactionally. Removed in v1.0.",
        MgfDeprecationWarning,
        stacklevel=2,
    )
    _wire_threading_excepthook()


__all__ = ["install_threading_excepthook"]
