"""Smoke + contract tests for athena-ptc-emitter.

The full PTC SDK contract tests live alongside each consuming SDK
(`pptx-studio/python-sdk/tests/test_ptc.py` and siblings). These are
the minimum set: no-op when disabled, sync delivery, URL snapshot at
begin survives env mutation, asset_id propagation, body truncation,
and unreachable endpoint never raises.
"""

from __future__ import annotations

import importlib
import json
import os
import threading
from http.server import BaseHTTPRequestHandler, HTTPServer
from typing import Any


class _CaptureServer:
    def __init__(self) -> None:
        self.requests: list[dict[str, Any]] = []
        self._lock = threading.Lock()
        outer = self

        class Handler(BaseHTTPRequestHandler):
            def log_message(self, *_args: Any, **_kwargs: Any) -> None:
                pass

            def do_POST(self) -> None:
                length = int(self.headers.get("Content-Length", "0"))
                raw = self.rfile.read(length) if length else b""
                try:
                    body = json.loads(raw.decode("utf-8"))
                except Exception:  # noqa: BLE001
                    body = None
                with outer._lock:
                    outer.requests.append(
                        {"path": self.path, "body": body, "headers": dict(self.headers)}
                    )
                self.send_response(204)
                self.end_headers()

        self._server = HTTPServer(("127.0.0.1", 0), Handler)
        self._thread = threading.Thread(target=self._server.serve_forever, daemon=True)
        self._thread.start()

    def url(self, *, query: str = "t=fake-token") -> str:
        host, port = self._server.server_address[:2]
        host_str = host if isinstance(host, str) else host.decode()
        return f"http://{host_str}:{port}/api/runtime/ptc-events?{query}"

    def stop(self) -> None:
        self._server.shutdown()
        self._server.server_close()
        self._thread.join(timeout=1.0)


_PTC_URL_KEY = "ATHENA_PTC_URL"


def _reload_emitter():
    import athena_ptc_emitter._emitter as mod

    return importlib.reload(mod)


def _clear_env() -> str | None:
    saved = os.environ.pop(_PTC_URL_KEY, None)
    return saved


def _restore(saved: str | None) -> None:
    if saved is None:
        os.environ.pop(_PTC_URL_KEY, None)
    else:
        os.environ[_PTC_URL_KEY] = saved


def test_no_env_is_noop() -> None:
    saved = _clear_env()
    try:
        m = _reload_emitter()
        call_id = m.emit_begin("Op", {"x": 1})
        assert isinstance(call_id, str) and len(call_id) > 0
        m.emit_end(call_id=call_id, tool_name="Op", result={"ok": True}, is_error=False)
    finally:
        _restore(saved)


def test_sync_begin_end_roundtrip() -> None:
    saved = _clear_env()
    server = _CaptureServer()
    try:
        os.environ[_PTC_URL_KEY] = server.url(query="t=presigned-A")
        m = _reload_emitter()

        call_id = m.emit_begin("CreateParagraph", {"text": "hello"})
        # Sync: the begin POST has already landed.
        with server._lock:
            assert len(server.requests) == 1
            assert server.requests[0]["body"]["phase"] == "begin"

        m.emit_end(call_id=call_id, tool_name="CreateParagraph", result={"ok": True}, is_error=False)
        with server._lock:
            assert len(server.requests) == 2

        begin, end = server.requests
        assert begin["path"].endswith("?t=presigned-A")
        assert end["path"].endswith("?t=presigned-A")
        assert begin["body"]["callId"] == call_id == end["body"]["callId"]
        assert begin["body"]["toolName"] == "CreateParagraph"
        assert begin["body"]["args"] == {"text": "hello"}
        assert end["body"]["isError"] is False
        # Auth lives in the URL; never in headers.
        assert "Authorization" not in begin["headers"]
    finally:
        server.stop()
        _restore(saved)


def test_asset_id_round_trips_on_begin_only() -> None:
    saved = _clear_env()
    server = _CaptureServer()
    try:
        os.environ[_PTC_URL_KEY] = server.url()
        m = _reload_emitter()
        m.emit_begin("Op", {"x": 1}, asset_id="asset_deck_42")
        body = server.requests[0]["body"]
        assert body["assetId"] == "asset_deck_42"

        m2 = _reload_emitter()
        m2.emit_begin("Op", {"x": 1})
        assert "assetId" not in server.requests[1]["body"]
    finally:
        server.stop()
        _restore(saved)


def test_url_snapshot_at_begin_survives_env_mutation() -> None:
    saved = _clear_env()
    server_a = _CaptureServer()
    server_b = _CaptureServer()
    try:
        os.environ[_PTC_URL_KEY] = server_a.url(query="t=A")
        m = _reload_emitter()
        call_id = m.emit_begin("Op", {"x": 1})

        # Simulate a new sandbox run swapping in a different presigned URL.
        os.environ[_PTC_URL_KEY] = server_b.url(query="t=B")
        m.emit_end(call_id=call_id, tool_name="Op", result={"ok": True}, is_error=False)

        assert len(server_a.requests) == 2  # begin + end both went to A
        assert len(server_b.requests) == 0
    finally:
        server_a.stop()
        server_b.stop()
        _restore(saved)


def test_unreachable_endpoint_never_raises() -> None:
    saved = _clear_env()
    try:
        # 127.0.0.1:1 — connect() refuses immediately.
        os.environ[_PTC_URL_KEY] = "http://127.0.0.1:1/api/runtime/ptc-events?t=x"
        m = _reload_emitter()
        call_id = m.emit_begin("Op", {"x": 1})
        m.emit_end(call_id=call_id, tool_name="Op", result={"ok": True}, is_error=False)
    finally:
        _restore(saved)


def test_oversize_body_is_truncated() -> None:
    saved = _clear_env()
    server = _CaptureServer()
    try:
        os.environ[_PTC_URL_KEY] = server.url()
        m = _reload_emitter()
        huge = {"blob": "x" * (80 * 1024)}  # > 64 KB cap
        call_id = m.emit_begin("Op", huge)
        assert server.requests[0]["body"]["args"] == {"__truncated__": True}

        m.emit_end(call_id=call_id, tool_name="Op", result=huge, is_error=False)
        assert server.requests[1]["body"]["result"] == {"__truncated__": True}
    finally:
        server.stop()
        _restore(saved)
