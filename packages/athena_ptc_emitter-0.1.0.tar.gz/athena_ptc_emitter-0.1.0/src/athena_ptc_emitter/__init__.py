"""athena-ptc-emitter — Stdlib-only PTC event emitter shared across Athena's
sandboxed authoring SDKs."""

from athena_ptc_emitter._emitter import emit_begin, emit_end

__version__ = "0.1.0"

__all__ = ["emit_begin", "emit_end", "__version__"]
