#!/usr/bin/env bash
# Tag + push a new athena-ptc-emitter release. CI handles the additive
# pipeline: PyPI publish only. See
# .github/workflows/athena-ptc-emitter-release.yml for the full flow.
#
# Usage:
#   ./scripts/release.sh <version>
#
# e.g. ./scripts/release.sh 0.1.1 — releases athena-ptc-emitter==0.1.1
# by:
#   1. Updating pyproject.toml + src/athena_ptc_emitter/__init__.py
#   2. Committing the version bump
#   3. Tagging athena-ptc-emitter-v<version>
#   4. Pushing the commit + tag to origin
#
# CI trigger fires on the tag push and runs the full release pipeline.

set -euo pipefail

if [ $# -ne 1 ]; then
  echo "Usage: $0 <version> (e.g., 0.1.1)" >&2
  exit 1
fi

VERSION="$1"
if ! [[ "$VERSION" =~ ^[0-9]+\.[0-9]+\.[0-9]+(\.(dev|rc|a|b)[0-9]+)?$ ]]; then
  echo "ERROR: version '$VERSION' is not a valid semver-ish" >&2
  exit 1
fi

SDK_DIR="$(cd "$(dirname "$0")/.." && pwd)"
REPO_ROOT="$(git -C "$SDK_DIR" rev-parse --show-toplevel)"

if ! git -C "$REPO_ROOT" diff --quiet || ! git -C "$REPO_ROOT" diff --cached --quiet; then
  echo "ERROR: working tree is dirty. Commit or stash first." >&2
  git -C "$REPO_ROOT" status --short >&2
  exit 1
fi

sed -i.bak "s/^version = \".*\"/version = \"$VERSION\"/" "$SDK_DIR/pyproject.toml"
rm -f "$SDK_DIR/pyproject.toml.bak"

sed -i.bak "s/^__version__ = \".*\"/__version__ = \"$VERSION\"/" "$SDK_DIR/src/athena_ptc_emitter/__init__.py"
rm -f "$SDK_DIR/src/athena_ptc_emitter/__init__.py.bak"

echo "=== Version bump diff ==="
git -C "$REPO_ROOT" diff "$SDK_DIR/pyproject.toml" "$SDK_DIR/src/athena_ptc_emitter/__init__.py"
echo "========================="

TAG="athena-ptc-emitter-v$VERSION"

git -C "$REPO_ROOT" add "$SDK_DIR/pyproject.toml" "$SDK_DIR/src/athena_ptc_emitter/__init__.py"
git -C "$REPO_ROOT" commit -m "chore(ptc-emitter): bump version to $VERSION"
git -C "$REPO_ROOT" tag "$TAG"

echo ""
echo "Pushing commit + tag $TAG..."
git -C "$REPO_ROOT" push origin HEAD
git -C "$REPO_ROOT" push origin "$TAG"

echo ""
echo "Done. CI will publish athena-ptc-emitter==$VERSION to PyPI."
echo "Track at: https://github.com/Athena-Intel/demo-app-monorepo/actions/workflows/athena-ptc-emitter-release.yml"
