# concinno-skills-auth — Phase 1 research summary

Research conducted 2026-04-23 before Phase 2 self-audit. This file is the
checkpoint if the session is resumed mid-task.

## Sources consulted

1. **RFC 8628 (OAuth 2.0 Device Authorization Grant)** — canonical flow.
2. **Anthropic Claude Code Skills docs** (code.claude.com/docs/en/skills) —
   `SKILL.md` frontmatter + layout convention.
3. **Python `keyring` library** (PyPI) — cross-platform backend + error model.
4. **GitHub OAuth device flow** (docs.github.com App CLI tutorial).
5. **Google OAuth device flow** (developers.google.com limited-input-device).
6. **Microsoft Entra OAuth device flow** (learn.microsoft.com v2-oauth2-device-code).
7. **Fernet vs age vs post-quantum** (search — cryptography.io 403'd, pulled
   from Anthropic training knowledge + secondary sources).
8. **LangChain auth toolkit patterns** (blog.langchain.com agent-authorization).

## What we adopted

- **RFC 8628 as the flow backbone** — endpoint returns `device_code` /
  `user_code` / `verification_uri` / `interval` / `expires_in`; client polls
  `/token` with `grant_type=urn:ietf:params:oauth:grant-type:device_code`;
  four governing errors `authorization_pending` / `slow_down` /
  `access_denied` / `expired_token`; `slow_down` adds 5s to the interval.
- **Anthropic SKILL.md minimal frontmatter** — only `name` + `description`
  are strictly needed; `triggers` / `user-invocable` / `allowed-tools` are
  optional. We match the global `windows` / `browser` skill format already
  installed on this machine (keeps consistent LLM attention pattern).
- **`keyring.set_password(service, username, password)` + three platform
  backends** (Windows Credential Locker / macOS Keychain / libsecret) with
  graceful degradation when `keyring.errors.NoKeyringError` fires —
  matches the 2026 best-practice "design for unavailable keyring".
- **Per-provider device-code URL table** — GitHub `/login/device/code`,
  Google `oauth2.googleapis.com/device/code`, Microsoft
  `login.microsoftonline.com/{tenant}/oauth2/v2.0/devicecode`. Each
  provider overlays slight error-code differences (Microsoft adds
  `authorization_declined` / `bad_verification_code`) — we normalise to
  RFC 8628 vocabulary plus a `raw_error` passthrough.
- **LangChain token-storage split** — `tokens()` / `saveTokens()` maps to
  our `CredentialAuth` CRUD (read path) + `OAuthFlow` (write path after
  device-code completes).

## What we rejected

- **age encryption** — for a local-machine credential vault with no
  multi-recipient encryption need, Fernet is simpler: one library
  (`cryptography`, already a Concinno transitive dep), standardised
  envelope (AES-128-CBC + HMAC-SHA256 + timestamp + IV), mature
  `MultiFernet` for key rotation. age's main advantage is identity-based
  encryption for multi-recipient files, which we do not need (the user is
  the only recipient). Post-quantum concerns apply equally to both at the
  symmetric AES-128 level (Grover halves to 64-bit effective, still far
  above practical break). If the user later needs post-quantum, both
  Fernet and age would need swapping.
- **Slack device flow** — Slack does not support RFC 8628 device flow. We
  document this explicitly in `providers.md` and only accept Slack xoxb
  bot tokens via `CredentialAuth.set`.
- **`op` / `bw` CLI shell-out** — too many moving parts (requires user to
  install external CLI, maintain vault unlock state, two-way sync). Our
  scope is "one self-contained Python vault", not "bridge to external
  password manager". Users who already have 1Password can `op read`
  themselves and pipe to `CONCINNO_CRED_<KEY>=... python script.py`.
- **LangChain's `OAuthClientProvider` class** — too heavyweight for the
  Concinno Tool protocol, which expects `call(**kwargs)` returning a
  plain dict. We keep our tools protocol-compliant and hide the provider
  abstraction inside `_oauth.py`.
- **Composio / LangSmith Agent Auth SaaS** — we are on-device and
  offline-capable by design; SaaS credential brokers add a dependency and
  an attack surface we do not need.

## Per-provider endpoints table

| Provider   | Device URL                                                     | Token URL                                                  | Notes                                                    |
|:-----------|:---------------------------------------------------------------|:-----------------------------------------------------------|:---------------------------------------------------------|
| GitHub     | `https://github.com/login/device/code`                         | `https://github.com/login/oauth/access_token`              | Same four errors. Interval 5s default.                   |
| Google     | `https://oauth2.googleapis.com/device/code`                    | `https://oauth2.googleapis.com/token`                      | Returns `refresh_token` always. Interval from response.  |
| Microsoft  | `https://login.microsoftonline.com/{tenant}/oauth2/v2.0/devicecode` | `https://login.microsoftonline.com/{tenant}/oauth2/v2.0/token` | `tenant` in `common`/`organizations`/`consumers`/`<guid>`. Adds `authorization_declined`, `bad_verification_code`. |
| Slack      | *(no device flow)*                                             | n/a                                                        | xoxb bot token only, use `CredentialAuth.set`.           |
| generic    | caller-supplied                                                | caller-supplied                                            | Fall-back: `provider_url` override.                      |

## Checkpoint for mid-task resumption

- Phase 1 done: this file exists.
- Phase 2 done when `src/concinno_skills_auth/SECURITY.md` exists.
- Phase 3 done when `pytest tests/ -q` green + ruff clean.
- Phase 4 done when PyPI JSON shows 0.1.0 + git tag applied.
