"""End-to-end integration test — onboarding → store → retrieve →
rotate → revoke → registry auto-mount.
"""

from __future__ import annotations

import os

from concinno_skills_auth import CredentialAuth, SecretRotate


def test_full_credential_lifecycle(env_master_key: bytes) -> None:
    c = CredentialAuth()
    s = SecretRotate()

    # 1. No creds yet
    assert c.call(action="list") == {"aliases": []}

    # 2. Onboarding: user pastes a GitHub PAT
    assert c.call(
        action="set",
        alias="gh-main",
        provider="github",
        type="api_key",
        data={"api_key": "ghp_onboarding"},
        scopes=["repo", "read:user"],
        expires_at="2026-07-23T00:00:00+00:00",
    ) == {"ok": True, "alias": "gh-main"}

    # 3. Now visible
    assert c.call(action="list") == {"aliases": ["gh-main"]}

    # 4. Get redacted (default)
    got = c.call(action="get", alias="gh-main")
    assert "redacted" in got["entry"]["data"]["api_key"]
    assert got["entry"]["scopes"] == ["repo", "read:user"]

    # 5. Get revealed
    raw = c.call(action="get", alias="gh-main", reveal=True)
    assert raw["entry"]["data"]["api_key"] == "ghp_onboarding"

    # 6. Rotate (90-day policy)
    rotated = s.call(
        action="rotate",
        alias="gh-main",
        new_data={"api_key": "ghp_rotated"},
        reason="quarterly rotation",
    )
    assert rotated["ok"] is True
    after_rot = c.call(
        action="get", alias="gh-main", reveal=True
    )
    assert after_rot["entry"]["data"]["api_key"] == "ghp_rotated"

    # 7. Emergency revoke (token leaked)
    revoked = s.call(
        action="revoke", alias="gh-main", reason="leaked in screenshot"
    )
    assert revoked["ok"] is True
    assert revoked["revoke_url"] is not None

    # 8. Entry is gone
    assert c.call(action="list") == {"aliases": []}


def test_registry_auto_mount() -> None:
    # Loading plugins requires CONCINNO_LOAD_PLUGINS=1 per the
    # sibling-package convention.
    os.environ["CONCINNO_LOAD_PLUGINS"] = "1"
    from concinno.tools.registry import get_default_registry

    reg = get_default_registry()
    reg.load_plugins()
    deferred = set(reg.list_deferred())
    assert "CredentialAuth" in deferred
    assert "OAuthFlow" in deferred
    assert "SecretRotate" in deferred
