"""Unit tests for concinno_skills_auth._oauth — mocked httpx throughout."""

from __future__ import annotations

from typing import Any

import httpx
import pytest

from concinno_skills_auth import _oauth


def _mock_http(
    monkeypatch: pytest.MonkeyPatch, responses: list[tuple[int, Any]]
) -> list[tuple[str, dict[str, str]]]:
    """Stub ``_http_post_form`` to yield scripted responses in order."""
    calls: list[tuple[str, dict[str, str]]] = []
    iterator = iter(responses)

    def fake(
        url: str, form: dict[str, str], *, timeout: float = 30.0
    ) -> tuple[int, Any]:
        calls.append((url, form))
        return next(iterator)

    monkeypatch.setattr(_oauth, "_http_post_form", fake)
    return calls


def test_initiate_success(monkeypatch: pytest.MonkeyPatch) -> None:
    _mock_http(
        monkeypatch,
        [
            (
                200,
                {
                    "device_code": "dev123",
                    "user_code": "ABCD-1234",
                    "verification_uri": "https://github.com/login/device",
                    "expires_in": 900,
                    "interval": 5,
                },
            )
        ],
    )
    resp = _oauth.initiate_device_code(
        "github", client_id="Iv1.abc"
    )
    assert isinstance(resp, _oauth.DeviceCodeResponse)
    assert resp.device_code == "dev123"
    assert resp.user_code == "ABCD-1234"
    assert resp.interval == 5


def test_initiate_unknown_provider_without_custom_url() -> None:
    out = _oauth.initiate_device_code(
        "acme", client_id="xyz"
    )
    assert "error" in out
    assert "unknown provider" in out["error"]


def test_initiate_slack_rejected() -> None:
    out = _oauth.initiate_device_code(
        "slack", client_id="xyz"
    )
    assert "error" in out
    assert "does not support" in out["error"]


def test_poll_token_success_after_pending(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    _mock_http(
        monkeypatch,
        [
            (428, {"error": "authorization_pending"}),
            (
                200,
                {
                    "access_token": "access123",
                    "refresh_token": "refresh123",
                    "token_type": "Bearer",
                    "expires_in": 3600,
                    "scope": "repo read:user",
                },
            ),
        ],
    )
    # Replace sleep so the test runs instantly
    out = _oauth.poll_token(
        "github",
        device_code="dev123",
        client_id="Iv1.abc",
        interval=1,
        sleep=lambda s: None,
    )
    assert out["ok"] is True
    assert out["access_token"] == "access123"
    assert out["refresh_token"] == "refresh123"


def test_poll_token_slow_down_increases_interval(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    _mock_http(
        monkeypatch,
        [
            (400, {"error": "slow_down"}),
            (
                200,
                {"access_token": "access123", "token_type": "Bearer"},
            ),
        ],
    )
    slept: list[int] = []
    out = _oauth.poll_token(
        "github",
        device_code="dev123",
        client_id="Iv1.abc",
        interval=5,
        sleep=slept.append,
    )
    assert out["ok"] is True
    # After slow_down, interval is 5 + 5 = 10
    assert slept == [10]


def test_poll_token_access_denied_stops(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    _mock_http(monkeypatch, [(400, {"error": "access_denied"})])
    out = _oauth.poll_token(
        "github",
        device_code="dev123",
        client_id="Iv1.abc",
        sleep=lambda s: None,
    )
    assert out.get("ok") is not True
    assert out["error"] == "access_denied"


def test_poll_token_microsoft_error_alias(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    # Microsoft returns ``authorization_declined`` — we normalise to
    # ``access_denied`` per RFC 8628 canonical vocabulary.
    _mock_http(
        monkeypatch, [(400, {"error": "authorization_declined"})]
    )
    out = _oauth.poll_token(
        "microsoft",
        device_code="dev123",
        client_id="msft-client",
        sleep=lambda s: None,
    )
    assert out["error"] == "access_denied"


def test_poll_token_expired_stops(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    _mock_http(monkeypatch, [(400, {"error": "expired_token"})])
    out = _oauth.poll_token(
        "github",
        device_code="dev123",
        client_id="Iv1.abc",
        sleep=lambda s: None,
    )
    assert out["error"] == "expired_token"


def test_poll_token_network_failure_wrapped(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    def boom(*a: object, **kw: object) -> None:
        raise httpx.ConnectError("no route")

    monkeypatch.setattr(_oauth, "_http_post_form", boom)
    out = _oauth.poll_token(
        "github",
        device_code="dev123",
        client_id="Iv1.abc",
        sleep=lambda s: None,
    )
    assert "token poll failed" in out["error"]


def test_microsoft_tenant_substitution(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    calls = _mock_http(
        monkeypatch,
        [
            (
                200,
                {
                    "device_code": "d",
                    "user_code": "u",
                    "verification_uri": "https://ms",
                    "expires_in": 900,
                    "interval": 5,
                },
            )
        ],
    )
    _oauth.initiate_device_code(
        "microsoft",
        client_id="msft-client",
        tenant="organizations",
    )
    assert "/organizations/oauth2/v2.0/devicecode" in calls[0][0]


def test_custom_provider_with_explicit_urls(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    _mock_http(
        monkeypatch,
        [
            (
                200,
                {
                    "device_code": "d",
                    "user_code": "u",
                    "verification_uri": "https://custom",
                    "expires_in": 900,
                    "interval": 5,
                },
            )
        ],
    )
    resp = _oauth.initiate_device_code(
        "custom",
        client_id="xyz",
        provider_url="https://custom.example/device",
        token_url="https://custom.example/token",
    )
    assert isinstance(resp, _oauth.DeviceCodeResponse)
