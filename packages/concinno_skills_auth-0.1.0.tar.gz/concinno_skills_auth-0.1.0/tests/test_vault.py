"""Unit tests for concinno_skills_auth._vault."""

from __future__ import annotations

from pathlib import Path

import pytest
from cryptography.fernet import Fernet, InvalidToken

from concinno_skills_auth import _vault


def test_read_vault_empty_when_missing(
    env_master_key: bytes, vault_dir: Path
) -> None:
    v = _vault.read_vault()
    assert v == {"version": 1, "accounts": {}}


def test_write_then_read_round_trip(env_master_key: bytes) -> None:
    _vault.set_entry(
        "gh",
        {
            "provider": "github",
            "type": "api_key",
            "data": {"api_key": "ghp_abc"},
        },
    )
    aliases = _vault.list_aliases()
    assert aliases == ["gh"]
    entry = _vault.get_entry("gh")
    assert entry is not None
    assert entry["provider"] == "github"
    assert entry["data"]["api_key"] == "ghp_abc"
    assert "created_at" in entry
    assert "last_rotated" in entry


def test_ciphertext_is_unreadable_without_key(
    env_master_key: bytes,
) -> None:
    _vault.set_entry(
        "gh",
        {"provider": "github", "type": "api_key", "data": {"api_key": "x"}},
    )
    ct_path = Path.home() / ".concinno" / "vault" / "credentials.enc"
    blob = ct_path.read_bytes()
    wrong_key = Fernet.generate_key()
    with pytest.raises(InvalidToken):
        Fernet(wrong_key).decrypt(blob)


def test_atomic_write_no_tempfile_remains(env_master_key: bytes) -> None:
    _vault.set_entry(
        "gh",
        {"provider": "github", "type": "api_key", "data": {"api_key": "x"}},
    )
    vault_dir = Path.home() / ".concinno" / "vault"
    leftover = list(vault_dir.glob("*.new"))
    assert leftover == [], f"stray tmp files: {leftover}"


def test_backup_rotation_keeps_five(env_master_key: bytes) -> None:
    for i in range(8):
        _vault.set_entry(
            "gh",
            {
                "provider": "github",
                "type": "api_key",
                "data": {"api_key": f"v{i}"},
            },
        )
    backups = list(
        (Path.home() / ".concinno" / "vault" / "backups").glob(
            "credentials-*.enc"
        )
    )
    # The first set_entry has no previous ciphertext → no backup.
    # Subsequent 7 create backups, but rotation keeps last 5.
    assert len(backups) <= 5, f"{len(backups)} backups, expected ≤5"


def test_delete_entry(env_master_key: bytes) -> None:
    _vault.set_entry(
        "gh",
        {"provider": "github", "type": "api_key", "data": {"api_key": "x"}},
    )
    assert _vault.delete_entry("gh") is True
    assert _vault.get_entry("gh") is None
    assert _vault.delete_entry("gh") is False  # idempotent


def test_touch_rotation_updates_timestamp(
    env_master_key: bytes,
) -> None:
    _vault.set_entry(
        "gh",
        {
            "provider": "github",
            "type": "api_key",
            "data": {"api_key": "old"},
        },
    )
    entry = _vault.get_entry("gh")
    assert entry is not None
    before = entry["last_rotated"]
    import time as _t

    _t.sleep(0.01)
    updated = _vault.touch_rotation(
        "gh", patch_data={"api_key": "new"}
    )
    assert updated is not None
    assert updated["last_rotated"] != before
    assert updated["data"]["api_key"] == "new"


def test_fallback_master_key_file_used_when_no_env(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.delenv("CONCINNO_VAULT_MASTER_KEY", raising=False)
    # stub keyring to always fail
    import concinno_skills_auth._vault as v

    monkeypatch.setattr(
        v, "_load_master_key_from_keyring", lambda: None
    )
    monkeypatch.setattr(
        v, "_save_master_key_to_keyring", lambda k: False
    )
    key = v.load_or_create_master_key()
    assert isinstance(key, bytes) and len(key) == 44
    fallback = Path.home() / ".concinno" / "vault" / ".master-key"
    assert fallback.exists()
    assert fallback.read_bytes().strip() == key


def test_lock_is_acquired_and_released(env_master_key: bytes) -> None:
    with _vault.lock():
        # inside the lock, set_entry would block another process but
        # same-process reentrance is prevented — verify we don't deadlock
        # on the second lock call being called serially after release.
        pass
    with _vault.lock():
        pass  # released and reacquired


def test_corrupted_ciphertext_raises(
    env_master_key: bytes,
) -> None:
    _vault.set_entry(
        "gh",
        {"provider": "github", "type": "api_key", "data": {"api_key": "x"}},
    )
    ct_path = Path.home() / ".concinno" / "vault" / "credentials.enc"
    ct_path.write_bytes(b"not-a-valid-fernet-token")
    with pytest.raises(RuntimeError, match="decrypt failed"):
        _vault.read_vault()


def test_existing_created_at_preserved_on_update(
    env_master_key: bytes,
) -> None:
    _vault.set_entry(
        "gh",
        {"provider": "github", "type": "api_key", "data": {"api_key": "v1"}},
    )
    original = _vault.get_entry("gh")
    assert original is not None
    original_created = original["created_at"]
    _vault.set_entry(
        "gh",
        {"provider": "github", "type": "api_key", "data": {"api_key": "v2"}},
    )
    updated = _vault.get_entry("gh")
    assert updated is not None
    assert updated["created_at"] == original_created
