"""Shared fixtures: isolated vault dir + env-var master key.

Every test uses its own ``tmp_path`` under ``~/.concinno/vault``
override, and the master key is injected via
``CONCINNO_VAULT_MASTER_KEY`` env var so we never touch the real OS
keyring. Teardown removes any accidental entry in
``keyring("concinno-vault-test", ...)`` as belt-and-braces.
"""

from __future__ import annotations

import os
from collections.abc import Iterator
from pathlib import Path

import pytest
from cryptography.fernet import Fernet


@pytest.fixture
def vault_dir(tmp_path: Path) -> Path:
    return tmp_path / "vault"


@pytest.fixture
def master_key() -> bytes:
    return Fernet.generate_key()


@pytest.fixture
def env_master_key(
    monkeypatch: pytest.MonkeyPatch, master_key: bytes
) -> Iterator[bytes]:
    monkeypatch.setenv("CONCINNO_VAULT_MASTER_KEY", master_key.decode())
    yield master_key
    # defensive — attempt to clear any test-only keyring entry.
    # We swallow exceptions; this is best-effort cleanup, not a test.
    try:
        import keyring

        keyring.delete_password("concinno-vault-test", "master-key")
    except Exception:
        pass


@pytest.fixture(autouse=True)
def _isolate_vault(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    """Redirect ``Path.home()`` so every test gets its own vault dir."""
    monkeypatch.setattr(Path, "home", lambda: tmp_path)
    monkeypatch.delenv("CONCINNO_VAULT_MASTER_KEY", raising=False)
    os.environ.pop("CONCINNO_VAULT_MASTER_KEY", None)
