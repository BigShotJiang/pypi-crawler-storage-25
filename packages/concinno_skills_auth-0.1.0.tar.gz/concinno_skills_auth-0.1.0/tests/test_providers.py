"""Unit tests for concinno_skills_auth._providers."""

from __future__ import annotations

from concinno_skills_auth import _providers


def test_get_provider_lookup_case_insensitive() -> None:
    assert _providers.get_provider("GitHub") is not None
    assert _providers.get_provider("github") is not None
    assert _providers.get_provider(" GITHUB  ") is not None
    assert _providers.get_provider("nonexistent") is None
    assert _providers.get_provider(None) is None  # type: ignore[arg-type]


def test_device_code_providers_have_urls() -> None:
    for key in ("github", "google", "microsoft"):
        spec = _providers.get_provider(key)
        assert spec is not None
        assert spec.device_code_url.startswith("https://")
        assert spec.token_url.startswith("https://")


def test_slack_has_no_device_flow() -> None:
    spec = _providers.get_provider("slack")
    assert spec is not None
    assert spec.device_code_url == ""
    assert spec.token_url == ""
    assert "does NOT support" in spec.notes


def test_is_known_provider() -> None:
    assert _providers.is_known_provider("github") is True
    assert _providers.is_known_provider("openai") is True
    assert _providers.is_known_provider("custom") is True
    assert _providers.is_known_provider("definitely_not_a_provider") is False
    assert _providers.is_known_provider("") is False
    assert _providers.is_known_provider(None) is False  # type: ignore[arg-type]


def test_list_providers_includes_all_shipped() -> None:
    listed = _providers.list_providers()
    keys = {p["key"] for p in listed}
    # device-code providers
    assert {"github", "google", "microsoft", "slack"} <= keys
    # api-key-only providers
    assert {"openai", "anthropic", "stripe"} <= keys
    # Every entry has required fields
    for p in listed:
        assert "key" in p and "display_name" in p and "flow" in p
        assert p["flow"] in ("device_code", "api_key")
