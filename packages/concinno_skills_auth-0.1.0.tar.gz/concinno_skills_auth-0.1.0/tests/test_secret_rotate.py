"""Unit tests for concinno_skills_auth.secret_rotate.SecretRotate."""

from __future__ import annotations

from concinno_skills_auth import CredentialAuth, SecretRotate


def _seed(alias: str, provider: str = "github") -> None:
    CredentialAuth().call(
        action="set",
        alias=alias,
        provider=provider,
        type="api_key",
        data={"api_key": "old_value"},
    )


def test_protocol_surface() -> None:
    assert SecretRotate.name == "secret_rotate"
    assert SecretRotate.is_concurrency_safe is False


def test_invalid_action() -> None:
    out = SecretRotate().call(action="nope")
    assert "error" in out
    assert "rotate|rotate_all|revoke" in out["error"]


def test_rotate_single_entry(env_master_key: bytes) -> None:
    _seed("gh")
    before = CredentialAuth().call(
        action="get", alias="gh", reveal=True
    )
    out = SecretRotate().call(
        action="rotate",
        alias="gh",
        new_data={"api_key": "new_value"},
        reason="90-day policy",
    )
    assert out["ok"] is True
    assert out["alias"] == "gh"
    assert out["revoke_url"] is not None
    assert out["reason"] == "90-day policy"

    after = CredentialAuth().call(
        action="get", alias="gh", reveal=True
    )
    assert after["entry"]["data"]["api_key"] == "new_value"
    assert after["entry"]["last_rotated"] != before["entry"]["last_rotated"]


def test_rotate_missing_alias(env_master_key: bytes) -> None:
    out = SecretRotate().call(
        action="rotate",
        alias="nonexistent",
        new_data={"api_key": "x"},
    )
    assert "error" in out
    assert "not found" in out["error"]


def test_rotate_missing_new_data(env_master_key: bytes) -> None:
    _seed("gh")
    out = SecretRotate().call(action="rotate", alias="gh", new_data={})
    assert "error" in out
    assert "new_data" in out["error"]


def test_rotate_all_by_provider(env_master_key: bytes) -> None:
    _seed("gh-a", provider="github")
    _seed("gh-b", provider="github")
    _seed("gg", provider="google")
    out = SecretRotate().call(action="rotate_all", provider="github")
    assert out["ok"] is True
    assert set(out["rotated"]) == {"gh-a", "gh-b"}
    assert out["failed"] == []
    assert out["revoke_url"] is not None


def test_rotate_all_unknown_provider_empty(env_master_key: bytes) -> None:
    _seed("gh-a", provider="github")
    out = SecretRotate().call(action="rotate_all", provider="notion")
    assert out["ok"] is True
    assert out["rotated"] == []


def test_revoke_removes_from_vault(env_master_key: bytes) -> None:
    _seed("gh")
    out = SecretRotate().call(
        action="revoke", alias="gh", reason="leaked"
    )
    assert out["ok"] is True
    assert out["provider"] == "github"
    assert out["revoke_url"] is not None
    assert "deleted" in out["note"]
    # gone from vault
    gone = CredentialAuth().call(action="get", alias="gh")
    assert "error" in gone


def test_revoke_missing_alias(env_master_key: bytes) -> None:
    out = SecretRotate().call(action="revoke", alias="ghost")
    assert "error" in out
    assert "not found" in out["error"]
