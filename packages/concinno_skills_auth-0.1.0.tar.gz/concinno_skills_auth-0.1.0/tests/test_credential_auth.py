"""Unit tests for concinno_skills_auth.credential_auth.CredentialAuth."""

from __future__ import annotations

from concinno_skills_auth import CredentialAuth


def test_protocol_surface() -> None:
    assert CredentialAuth.name == "credential_auth"
    assert CredentialAuth.is_concurrency_safe is False
    assert "list | get | set | delete | providers" in CredentialAuth.description


def test_invalid_action() -> None:
    out = CredentialAuth().call(action="nope")
    assert "error" in out
    assert "list|get|set|delete|providers" in out["error"]


def test_set_then_list_then_get_redacted(env_master_key: bytes) -> None:
    ok = CredentialAuth().call(
        action="set",
        alias="gh-main",
        provider="github",
        type="api_key",
        data={"api_key": "ghp_supersecret"},
        scopes=["repo"],
    )
    assert ok == {"ok": True, "alias": "gh-main"}

    listed = CredentialAuth().call(action="list")
    assert listed == {"aliases": ["gh-main"]}

    got = CredentialAuth().call(action="get", alias="gh-main")
    assert got["alias"] == "gh-main"
    # redacted by default
    assert "redacted" in got["entry"]["data"]["api_key"]


def test_get_reveal_returns_plaintext(env_master_key: bytes) -> None:
    CredentialAuth().call(
        action="set",
        alias="gh-main",
        provider="github",
        type="api_key",
        data={"api_key": "ghp_supersecret"},
    )
    got = CredentialAuth().call(
        action="get", alias="gh-main", reveal=True
    )
    assert got["entry"]["data"]["api_key"] == "ghp_supersecret"


def test_set_validation_errors(env_master_key: bytes) -> None:
    c = CredentialAuth()
    assert "error" in c.call(action="set")  # missing alias
    assert "error" in c.call(action="set", alias="bad alias")  # space
    assert "error" in c.call(
        action="set", alias="ok", provider="unknown_provider"
    )
    assert "error" in c.call(
        action="set",
        alias="ok",
        provider="github",
        type="bad_type",
        data={"x": "y"},
    )
    assert "error" in c.call(
        action="set",
        alias="ok",
        provider="github",
        type="api_key",
        data={},  # empty
    )


def test_delete_idempotent(env_master_key: bytes) -> None:
    CredentialAuth().call(
        action="set",
        alias="gh-main",
        provider="github",
        type="api_key",
        data={"api_key": "x"},
    )
    assert CredentialAuth().call(
        action="delete", alias="gh-main"
    ) == {"ok": True}
    out = CredentialAuth().call(action="delete", alias="gh-main")
    assert "error" in out
    assert "not found" in out["error"]


def test_providers_action_lists_everything(env_master_key: bytes) -> None:
    out = CredentialAuth().call(action="providers")
    assert "providers" in out
    keys = {p["key"] for p in out["providers"]}
    assert {"github", "google", "microsoft", "slack", "openai"} <= keys


def test_all_four_credential_types_accepted(env_master_key: bytes) -> None:
    c = CredentialAuth()
    for cred_type in (
        "api_key",
        "oauth_token",
        "basic_auth",
        "service_account",
        "connection_string",
    ):
        out = c.call(
            action="set",
            alias=f"test-{cred_type}",
            provider="custom",
            type=cred_type,
            data={"value": "x"},
        )
        assert out == {"ok": True, "alias": f"test-{cred_type}"}
