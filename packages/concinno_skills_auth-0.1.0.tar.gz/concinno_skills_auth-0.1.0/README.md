# concinno-skills-auth

Unified credential, OAuth device-flow, and rotation skills for
[Concinno](https://pypi.org/project/concinno/). One vault for all 20+
`concinno-skills-*` sub-packages. Local-machine Fernet-encrypted vault
with OS-keyring master key + file fallback.

## Status

MVP (0.1.0) — three tools:

| Tool class       | Action surface                                  |
|:-----------------|:------------------------------------------------|
| `CredentialAuth` | list / get / set / delete / providers           |
| `OAuthFlow`      | initiate / complete / one_shot (RFC 8628 device-code grant) |
| `SecretRotate`   | rotate / rotate_all / revoke                    |

Ships OAuth device-code endpoints for **GitHub**, **Google**,
**Microsoft**, and a generic `custom` slot for any RFC 8628–compatible
provider. **Slack** does not support device flow — use
`CredentialAuth.set` with a `xoxb-...` bot token instead.

Twenty other providers are registered as static-token stores:
`anthropic` / `aws` / `azure` / `chroma` / `cohere` / `gcp` / `hubspot`
/ `intercom` / `mailchimp` / `notion` / `openai` / `pinecone` /
`salesforce` / `sendgrid` / `shopify` / `stripe` / `twilio` /
`typeform` / `weaviate` / `zendesk`.

## Install

```bash
pip install concinno-skills-auth
```

Dependencies: `concinno>=2.15.1`, `cryptography>=42`, `keyring>=25`,
`httpx>=0.27`.

## Vault

Location: `~/.concinno/vault/credentials.enc` (Fernet-encrypted).
Master key in the OS keyring (Windows Credential Locker / macOS
Keychain / Linux libsecret), falling back to
`~/.concinno/vault/.master-key` with `0o600` if no keyring backend is
available.

Per-mutation backup: last 5 ciphertext snapshots under
`~/.concinno/vault/backups/`.

See [`src/concinno_skills_auth/SECURITY.md`](src/concinno_skills_auth/SECURITY.md)
for the threat model and crypto choices.

## Usage via Concinno `ToolRegistry`

```python
import os
os.environ["CONCINNO_LOAD_PLUGINS"] = "1"

from concinno.tools.registry import get_default_registry

reg = get_default_registry()
reg.load_plugins()
assert {"CredentialAuth", "OAuthFlow", "SecretRotate"} <= set(
    reg.list_deferred()
)
```

## Direct Python

```python
from concinno_skills_auth import CredentialAuth, OAuthFlow, SecretRotate

# Store a GitHub personal access token
CredentialAuth().call(
    action="set",
    alias="github-main",
    provider="github",
    type="api_key",
    data={"api_key": "ghp_xxxxxxxxxxxxxxxxxxxx"},
    scopes=["repo", "read:user"],
)

# OAuth device-code flow (GitHub)
OAuthFlow().call(
    action="one_shot",
    provider="github",
    client_id="Iv1.your-oauth-app-id",
    scopes=["repo"],
    alias="github-device",
)

# Rotate
SecretRotate().call(
    action="rotate",
    alias="github-main",
    new_data={"api_key": "ghp_new_value"},
    reason="90-day policy",
)

# Emergency revoke — removes from vault + surfaces provider revoke URL
SecretRotate().call(action="revoke", alias="github-main", reason="token leaked")
```

All tools return `{"ok": True, ...}` or a structured payload on success,
`{"error": "..."}` on failure. No exceptions escape `call()`.

## Concurrency

All three tools set `is_concurrency_safe = False`. The vault is
file-backed with a cross-platform advisory lock (`fcntl` POSIX /
`msvcrt` Windows) around read-modify-write; the Concinno scheduler
will serialise calls to these tools automatically.

## Redaction

`CredentialAuth.call(action="get", alias=..., reveal=False)` returns a
redacted copy — each string in `entry["data"]` is replaced with
`<redacted N chars>`. Pass `reveal=True` to get the raw secret.

## Skill

The global skill at `~/.claude/skills/credentials/SKILL.md` wraps these
three tools into a conversational onboarding / rotation / emergency
flow. Triggers on phrases like "新 token", "OAuth 流程", "rotate",
"revoke". See the skill directory for `workflows.md` (three concrete
flows) and `providers.md` (per-provider URLs + scopes).

## License

Apache-2.0. See `LICENSE`.
