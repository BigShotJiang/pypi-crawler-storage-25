# Changelog

All notable changes to `concinno-skills-auth` are documented here.
Format follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/)
and the project adheres to Semantic Versioning.

## [0.1.0] - 2026-04-23

### Added

- Initial release. Unified credential-management sub-package for the
  `concinno-skills-*` ecosystem (20th sub-package).
- `CredentialAuth` tool — CRUD + provider catalog for the local
  encrypted vault. Actions: `list` / `get` / `set` / `delete` /
  `providers`. Redacts secrets by default on `get`; pass `reveal=True`
  for raw.
- `OAuthFlow` tool — RFC 8628 OAuth 2.0 Device Authorization Grant for
  **GitHub**, **Google**, **Microsoft**, and a generic `custom` slot.
  Actions: `initiate` / `complete` / `one_shot`. Normalises provider
  error vocabularies (Microsoft `authorization_declined` →
  `access_denied`) and honours `slow_down` backoff. Global wall-clock
  cap of 900s. Completed tokens persist to the vault automatically.
  **Slack** is not supported (no device flow); use `CredentialAuth.set`
  with a `xoxb-...` bot token instead.
- `SecretRotate` tool — `rotate` single entry / `rotate_all` by
  provider / `revoke` (removes from vault + surfaces revoke URL).
  Emits a structured migration log per call.
- Fernet-encrypted vault at `~/.concinno/vault/credentials.enc` with
  OS-keyring master key (primary) and `0o600` fallback file, atomic
  write via `os.replace`, rolling 5-snapshot backup, cross-platform
  advisory file lock (`fcntl` POSIX / `msvcrt` Windows).
- Provider catalog covering 25+ providers: 4 device-code (GitHub /
  Google / Microsoft / custom) + 1 documented-unsupported (Slack) + 20
  static-token stores (Anthropic / AWS / Azure / Chroma / Cohere / GCP
  / HubSpot / Intercom / Mailchimp / Notion / OpenAI / Pinecone /
  Salesforce / SendGrid / Shopify / Stripe / Twilio / Typeform /
  Weaviate / Zendesk).
- Global Claude Code skill at `~/.claude/skills/credentials/` with
  `SKILL.md` (L2 summary ≤50 lines), `workflows.md` (onboarding /
  rotation / emergency revoke) and `providers.md` (per-provider URLs,
  scopes, revoke URLs).
- Security documentation at `src/concinno_skills_auth/SECURITY.md` —
  threat model T1-T8, out-of-scope attackers, Fernet-vs-age rationale.
- Phase 1 research summary at `docs/research-phase1.md` covering
  RFC 8628, Anthropic Claude Code skills spec, `keyring` backends,
  per-provider OAuth endpoints.
