"""concinno_skills_auth.secret_rotate — SecretRotate Concinno tool.

@module secret_rotate
@responsibility Rotate one entry or every entry for a given provider.
    Emits a structured migration log per call so the user has an audit
    trail of what was touched. Does **not** call the provider's revoke
    API (that's an out-of-band operation), but returns the revoke URL so
    the skill's workflow can surface it.
@dependencies concinno_skills_auth._vault, _providers
@exports SecretRotate
"""

from __future__ import annotations

import datetime as _dt
import logging
from typing import Any

from concinno_skills_auth import _vault
from concinno_skills_auth._providers import get_provider

logger = logging.getLogger("concinno_skills_auth.secret_rotate")

_VALID_ACTIONS = frozenset({"rotate", "rotate_all", "revoke"})


def _now_iso() -> str:
    return _dt.datetime.now(_dt.timezone.utc).isoformat()


class SecretRotate:
    """Rotate credentials in the local vault.

    Params accepted via ``call(**kwargs)``:
        action (str):    ``rotate`` | ``rotate_all`` | ``revoke``.
        alias (str):     for ``rotate`` / ``revoke`` — target alias.
        provider (str):  for ``rotate_all`` — rotate every entry with
                         this provider.
        new_data (dict): for ``rotate`` — the new secret payload.
                         Fields in ``data`` not listed here are kept.
        reason (str):    optional free-text reason recorded in the log.

    Returns:
        rotate     → ``{"ok":True, "alias":..., "last_rotated":..., "revoke_url":...}``.
        rotate_all → ``{"ok":True, "rotated":[...], "failed":[...]}``.
        revoke     → ``{"ok":True, "alias":..., "revoke_url":...}`` (the entry is removed from the vault).
        failure    → ``{"error":"..."}``.
    """

    name: str = "secret_rotate"
    description: str = (
        "Rotate credentials in the local vault. "
        "Actions: rotate | rotate_all | revoke. "
        "rotate: alias, new_data (dict) — patches the stored secret "
        "and bumps last_rotated. rotate_all: provider — loops over "
        "every entry and returns which need manual rotation. revoke: "
        "alias — removes the entry and surfaces the provider revoke "
        "URL. Returns {'ok':True,...} or {'error':'...'}."
    )
    is_concurrency_safe: bool = False

    def call(self, **kwargs: Any) -> Any:
        action = kwargs.get("action")
        if action not in _VALID_ACTIONS:
            return {
                "error": (
                    "action must be one of "
                    "rotate|rotate_all|revoke, "
                    f"got {action!r}"
                )
            }
        try:
            if action == "rotate":
                return self._rotate(**kwargs)
            if action == "rotate_all":
                return self._rotate_all(**kwargs)
            return self._revoke(**kwargs)
        except Exception as exc:  # noqa: BLE001 — boundary wrap
            logger.warning("secret_rotate.%s failed: %s", action, exc)
            return {"error": f"secret_rotate {action} failed: {exc}"}

    # ── actions ───────────────────────────────────────────────────────

    def _rotate(self, **kwargs: Any) -> dict[str, Any]:
        alias = kwargs.get("alias")
        new_data = kwargs.get("new_data")
        reason = kwargs.get("reason")
        if not isinstance(alias, str) or not alias:
            return {"error": "rotate requires alias=str"}
        if not isinstance(new_data, dict) or not new_data:
            return {
                "error": "rotate requires new_data=dict with fields to patch"
            }
        existing = _vault.get_entry(alias)
        if existing is None:
            return {"error": f"alias {alias!r} not found"}

        updated = _vault.touch_rotation(alias, patch_data=new_data)
        if updated is None:
            return {"error": f"alias {alias!r} vanished mid-rotation"}
        provider_key = str(existing.get("provider", ""))
        spec = get_provider(provider_key)
        revoke_url = spec.revoke_url if spec is not None else None
        logger.info(
            "secret_rotate.rotate alias=%s provider=%s reason=%s at=%s",
            alias,
            provider_key,
            reason or "(unspecified)",
            updated.get("last_rotated"),
        )
        return {
            "ok": True,
            "alias": alias,
            "last_rotated": updated.get("last_rotated"),
            "revoke_url": revoke_url,
            "reason": reason,
        }

    def _rotate_all(self, **kwargs: Any) -> dict[str, Any]:
        provider = kwargs.get("provider")
        if not isinstance(provider, str) or not provider:
            return {"error": "rotate_all requires provider=str"}
        provider_key = provider.strip().lower()
        vault = _vault.read_vault()
        accounts = vault.get("accounts", {})
        if not isinstance(accounts, dict):
            return {"error": "vault has invalid shape (missing 'accounts')"}
        rotated: list[str] = []
        failed: list[dict[str, str]] = []
        now = _now_iso()
        for alias, entry in list(accounts.items()):
            if not isinstance(entry, dict):
                continue
            if str(entry.get("provider", "")) != provider_key:
                continue
            try:
                touched = _vault.touch_rotation(alias)
                if touched is None:
                    failed.append(
                        {"alias": alias, "error": "touch failed"}
                    )
                    continue
                rotated.append(alias)
            except Exception as exc:  # noqa: BLE001
                failed.append({"alias": alias, "error": str(exc)})
        spec = get_provider(provider_key)
        logger.info(
            "secret_rotate.rotate_all provider=%s rotated=%d failed=%d at=%s",
            provider_key,
            len(rotated),
            len(failed),
            now,
        )
        return {
            "ok": True,
            "provider": provider_key,
            "rotated": rotated,
            "failed": failed,
            "revoke_url": spec.revoke_url if spec is not None else None,
            "rotated_at": now,
        }

    def _revoke(self, **kwargs: Any) -> dict[str, Any]:
        alias = kwargs.get("alias")
        reason = kwargs.get("reason")
        if not isinstance(alias, str) or not alias:
            return {"error": "revoke requires alias=str"}
        existing = _vault.get_entry(alias)
        if existing is None:
            return {"error": f"alias {alias!r} not found"}
        provider_key = str(existing.get("provider", ""))
        spec = get_provider(provider_key)
        removed = _vault.delete_entry(alias)
        if not removed:
            return {"error": f"alias {alias!r} could not be removed"}
        logger.info(
            "secret_rotate.revoke alias=%s provider=%s reason=%s",
            alias,
            provider_key,
            reason or "(unspecified)",
        )
        return {
            "ok": True,
            "alias": alias,
            "provider": provider_key,
            "revoke_url": spec.revoke_url if spec is not None else None,
            "reason": reason,
            "note": (
                "Local vault entry deleted. Visit revoke_url to "
                "invalidate the token server-side — this tool does "
                "NOT call the provider revoke API."
            ),
        }


__all__ = ["SecretRotate"]
