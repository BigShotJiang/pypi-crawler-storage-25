"""concinno_skills_auth.oauth_flow — OAuthFlow Concinno tool.

@module oauth_flow
@responsibility Drive the RFC 8628 device-authorization grant end to
    end and persist the resulting token into the local vault so the
    other Concinno tools can read it without a second roundtrip.
@dependencies concinno_skills_auth._oauth, _vault, _providers
@exports OAuthFlow

Actions:
    initiate      — POST /devicecode, return user_code +
                    verification_uri for the user to type in.
    complete      — Poll /token to completion, persist to vault.
    one_shot      — initiate + block-and-poll + persist, all in one
                    call (convenient for the Skill's onboarding flow).
"""

from __future__ import annotations

import logging
from typing import Any

from concinno_skills_auth import _oauth, _vault

logger = logging.getLogger("concinno_skills_auth.oauth_flow")

_VALID_ACTIONS = frozenset({"initiate", "complete", "one_shot"})


class OAuthFlow:
    """OAuth 2.0 device-code grant (RFC 8628) for headless agents.

    Params accepted via ``call(**kwargs)``:
        action (str):    ``initiate`` | ``complete`` | ``one_shot``.
        provider (str):  ``github`` | ``google`` | ``microsoft`` |
                         ``custom``. Slack is not supported (no device
                         flow).
        client_id (str): OAuth App client id registered with the
                         provider.
        scopes (list):   optional OAuth scopes; defaults per provider.
        tenant (str):    Microsoft only — ``common`` / ``organizations``
                         / ``consumers`` / directory GUID.
        provider_url:    for ``provider='custom'`` — the device-code
                         endpoint URL.
        token_url:       for ``provider='custom'`` — the token
                         endpoint URL.
        device_code:     for ``complete`` — from a prior ``initiate``.
        interval (int):  for ``complete`` — polling interval seconds.
        alias (str):     for ``complete`` / ``one_shot`` — where to
                         store the token in the vault.

    Returns:
        initiate  → ``{"user_code":..., "verification_uri":..., "device_code":..., "expires_in":..., "interval":...}``.
        complete  → ``{"ok":True, "alias":..., "access_token_preview":...}``.
        one_shot  → ``{"ok":True, "alias":..., "verification_uri":..., "user_code":...}`` **after** polling completes.
        failure   → ``{"error":"..."}``.
    """

    name: str = "oauth_flow"
    description: str = (
        "OAuth 2.0 device-code grant (RFC 8628) for GitHub/Google/"
        "Microsoft + custom. Actions: initiate | complete | one_shot. "
        "initiate → returns user_code + verification_uri. "
        "complete → polls token endpoint until user finishes, persists "
        "to vault under alias. one_shot does both. "
        "Returns {'user_code':...,'verification_uri':...} or "
        "{'ok':True,'alias':...} or {'error':'...'}. "
        "Slack does not support device flow — use CredentialAuth.set "
        "with a xoxb- bot token instead."
    )
    is_concurrency_safe: bool = False

    def call(self, **kwargs: Any) -> Any:
        action = kwargs.get("action")
        if action not in _VALID_ACTIONS:
            return {
                "error": (
                    "action must be one of "
                    "initiate|complete|one_shot, "
                    f"got {action!r}"
                )
            }
        try:
            if action == "initiate":
                return self._initiate(**kwargs)
            if action == "complete":
                return self._complete(**kwargs)
            return self._one_shot(**kwargs)
        except Exception as exc:  # noqa: BLE001 — boundary wrap
            logger.warning("oauth_flow.%s failed: %s", action, exc)
            return {"error": f"oauth_flow {action} failed: {exc}"}

    # ── actions ───────────────────────────────────────────────────────

    def _initiate(self, **kwargs: Any) -> dict[str, Any]:
        provider = kwargs.get("provider")
        client_id = kwargs.get("client_id")
        if not isinstance(provider, str) or not provider:
            return {"error": "initiate requires provider=str"}
        if not isinstance(client_id, str) or not client_id:
            return {"error": "initiate requires client_id=str"}

        scopes_raw = kwargs.get("scopes")
        scopes: tuple[str, ...] | None
        if scopes_raw is None:
            scopes = None
        elif isinstance(scopes_raw, (list, tuple)):
            scopes = tuple(str(s) for s in scopes_raw)
        else:
            return {"error": "scopes must be a list of strings"}

        resp = _oauth.initiate_device_code(
            provider,
            client_id=client_id,
            scopes=scopes,
            tenant=kwargs.get("tenant"),
            provider_url=kwargs.get("provider_url"),
            token_url=kwargs.get("token_url"),
        )
        if isinstance(resp, dict):
            return resp
        return {
            "device_code": resp.device_code,
            "user_code": resp.user_code,
            "verification_uri": resp.verification_uri,
            "verification_uri_complete": resp.verification_uri_complete,
            "expires_in": resp.expires_in,
            "interval": resp.interval,
            "message": resp.message,
        }

    def _complete(self, **kwargs: Any) -> dict[str, Any]:
        provider = kwargs.get("provider")
        client_id = kwargs.get("client_id")
        device_code = kwargs.get("device_code")
        alias = kwargs.get("alias")

        if not isinstance(provider, str) or not provider:
            return {"error": "complete requires provider=str"}
        if not isinstance(client_id, str) or not client_id:
            return {"error": "complete requires client_id=str"}
        if not isinstance(device_code, str) or not device_code:
            return {"error": "complete requires device_code=str"}
        if not isinstance(alias, str) or not alias:
            return {"error": "complete requires alias=str"}

        interval = kwargs.get("interval", 5)
        try:
            interval_int = max(1, int(interval))
        except (TypeError, ValueError):
            interval_int = 5

        token = _oauth.poll_token(
            provider,
            device_code,
            client_id=client_id,
            interval=interval_int,
            tenant=kwargs.get("tenant"),
            token_url=kwargs.get("token_url"),
        )
        if not token.get("ok"):
            return token

        self._persist_token(alias=alias, provider=provider, token=token)
        preview = _preview_secret(str(token.get("access_token", "")))
        return {
            "ok": True,
            "alias": alias,
            "access_token_preview": preview,
            "refresh_token_present": bool(token.get("refresh_token")),
        }

    def _one_shot(self, **kwargs: Any) -> dict[str, Any]:
        start = self._initiate(**kwargs)
        if "error" in start:
            return start
        complete_kwargs = dict(kwargs)
        complete_kwargs["device_code"] = start["device_code"]
        complete_kwargs["interval"] = start.get("interval", 5)
        done = self._complete(**complete_kwargs)
        if "error" in done:
            # preserve the initiate data so the user can retry polling
            return {
                **done,
                "verification_uri": start.get("verification_uri"),
                "user_code": start.get("user_code"),
            }
        return {
            **done,
            "verification_uri": start.get("verification_uri"),
            "user_code": start.get("user_code"),
        }

    # ── persistence helper ───────────────────────────────────────────

    def _persist_token(
        self, *, alias: str, provider: str, token: dict[str, Any]
    ) -> None:
        data: dict[str, Any] = {
            "access_token": token.get("access_token"),
            "token_type": token.get("token_type", "Bearer"),
        }
        if token.get("refresh_token"):
            data["refresh_token"] = token["refresh_token"]
        if token.get("expires_in") is not None:
            data["expires_in"] = token["expires_in"]

        entry: dict[str, Any] = {
            "provider": provider.strip().lower(),
            "type": "oauth_token",
            "data": data,
        }
        scope = token.get("scope")
        if isinstance(scope, str) and scope:
            entry["scopes"] = scope.split()
        _vault.set_entry(alias, entry)


def _preview_secret(secret: str) -> str:
    """Short non-secret preview for log lines: first 4 + ``…`` + last 2."""
    if not secret:
        return ""
    if len(secret) <= 8:
        return "*" * len(secret)
    return f"{secret[:4]}…{secret[-2:]}"


__all__ = ["OAuthFlow"]
