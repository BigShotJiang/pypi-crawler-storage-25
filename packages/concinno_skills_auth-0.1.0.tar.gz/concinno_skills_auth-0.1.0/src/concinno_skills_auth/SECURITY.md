# concinno-skills-auth — Security model and threat analysis

> Phase 2 self-audit output. Threat model + mitigations for the local
> credential vault + OAuth device-code flow. The vault is local-machine
> only; no network-side secret storage is shipped with this package.

## Assets under protection

| Asset | Sensitivity | Lifetime |
|---|---|---|
| Fernet master key | CRITICAL — decrypts the whole vault | Rotates on explicit user action only |
| Encrypted vault file `~/.concinno/vault/credentials.enc` | HIGH — ciphertext on disk | Lives for as long as the user keeps credentials |
| Individual credential entries (api_key / oauth_token / refresh_token) | HIGH | Varies per provider, rotation recommended ≤90d |
| Backup copies `backups/credentials-<ISO>.enc` | HIGH — same ciphertext, kept rotating 5 | Auto-prune beyond 5 |

## Threat model

### T1 — Master-key rotation fails mid-way

**Scenario:** `SecretRotate` is mid-flight re-encrypting the vault with a
new master key; process crashes or power cut after new key written to
keyring but before vault re-written.

**Mitigation:**
- Rotation reads the entire vault into memory under the old key first.
- Writes the re-encrypted ciphertext to a sibling `credentials.enc.new`.
- Only after a successful `os.replace` does it update the keyring.
- If the keyring update fails after the file swap, the previous key is
  retained in a one-slot `~/.concinno/vault/.master-key.prev` for the
  next startup, and a stderr warning is emitted.
- Atomicity invariant: at any crash point, *exactly one* of
  `{old-key → old-ciphertext}` or `{new-key → new-ciphertext}` is a
  valid pair. There is no window where `{new-key → old-ciphertext}` or
  `{old-key → new-ciphertext}` decrypts.

### T2 — Second machine needs the credentials

**Scenario:** User sets up credentials on laptop A and wants to use the
same account on desktop B without re-doing 20 device-code flows.

**Policy:** **no automatic cross-machine sync.** The vault is
intentionally machine-local. Cross-machine transfer requires the user to
manually copy both:
1. `~/.concinno/vault/credentials.enc` (ciphertext file)
2. The Fernet master key (printed via `CredentialAuth.call(action="export_master_key")`
   or read from the OS keyring with the user's credentials)

The manual step is **not a bug**: it ensures that a compromise of one
device does not silently compromise the other, and it means no cloud
credential broker is in the supply chain.

Documented explicitly in `providers.md` — see section "Cross-machine
transfer".

### T3 — Concurrent agents write the vault simultaneously

**Scenario:** Two Claude Code sessions both call
`CredentialAuth.call(action="set", ...)` at the same instant.

**Mitigation:**
- Write path is atomic per-call via `os.replace` of a tempfile.
- File locking via `fcntl.flock` on POSIX and `msvcrt.locking` on
  Windows around the read-modify-write span. If acquiring the lock
  takes >5s, the caller returns
  `{"error": "vault locked by another process, retry"}`.
- Backup rotation (keep last 5) runs under the same lock, so the
  mutating caller's previous state is always recoverable even if two
  writers race.

### T4 — OS keyring becomes unavailable post-setup

**Scenario:** User sets up vault with keyring working, later the backend
breaks (Linux desktop session missing D-Bus, libsecret uninstalled, etc.)
so `keyring.get_password()` starts returning `None`.

**Mitigation:**
- On every vault open, we try keyring first; on `NoKeyringError` /
  returned `None`, we fall back to `~/.concinno/vault/.master-key` with
  `0o600`.
- If neither is present but the vault ciphertext exists, the user is
  prompted to provide a master key via env var
  `CONCINNO_VAULT_MASTER_KEY` for this session only. We **never** prompt
  interactively from a Tool call — the prompt is in the error message.
- A stderr one-liner documents the degraded mode:
  `concinno-skills-auth: keyring backend unavailable; master-key from
  fallback file (chmod 0o600)`.

### T5 — User deletes the master key accidentally

**Scenario:** User rm's `~/.concinno/vault/.master-key` or flushes their
OS keyring, keeping the ciphertext file.

**Policy:** **no recovery by design.** The vault is cryptographically
opaque without the key — that is its security guarantee. The
`SECURITY.md` and `providers.md` both instruct the user to back up the
master key externally (password manager, hardware token, printed
paper + safe) before storing any credential whose loss is material.

The alternative (key-escrow, recovery questions, Shamir split) adds
complexity and attack surface far out of proportion to the local-vault
use case.

### T6 — Malicious process on the same machine reads the key

**Scenario:** Any process running as the same OS user can read
`.master-key` (chmod 0o600 stops *other users*, not same-user malware)
and can call `keyring.get_password` for any service.

**Policy:** **out of scope.** This vault protects against:
- Ciphertext-at-rest exposure (lost laptop, backup stolen, disk image).
- Casual cross-user exposure on shared machines.
- Accidental credential leak in screenshots / chat (no plaintext in the
  vault file).

It does **not** protect against a malicious local process running as the
same user. That requires OS sandboxing / hardware token / TPM —
explicitly outside Concinno's scope. Documented in `SECURITY.md`'s
"Out-of-scope attackers" section (this one).

### T7 — Provider API returns unexpected JSON during OAuth poll

**Scenario:** A provider's device-code token endpoint returns
non-standard error JSON, or a malformed response, or HTML instead of
JSON (captive portal).

**Mitigation:**
- `OAuthFlow._poll_token` catches `httpx.HTTPError`,
  `json.JSONDecodeError`, and any `ValueError` from response parsing.
- Unknown error codes from the provider are surfaced verbatim in
  `{"error": "<provider_code>: <provider_message>", "raw": {...}}`.
- Polling stops on any 4xx that is neither `authorization_pending` nor
  `slow_down`.
- A global wall-clock cap of 900s (15 minutes) guarantees the poll
  terminates even if the server misbehaves.

### T8 — Clock skew on `expires_at`

**Scenario:** User's machine clock is significantly off; stored
`expires_at` is meaningless.

**Policy:** `expires_at` is informational only — we never refuse to
return a token based solely on local time comparison. Expiry is
discovered at use-time from the provider's 401 response, which is the
only authoritative source. The stored timestamp is for user-facing
rotation reminders, not security enforcement.

## Out-of-scope attackers

- Malicious code running as the same local user.
- Physical hardware access with cold-boot / RAM extraction.
- Compromise of the upstream OS keyring implementation.
- Post-quantum adversaries (Fernet AES-128-CBC + HMAC-SHA256 gives
  ~64-bit effective symmetric security against Grover's algorithm — an
  issue for *all* symmetric ciphers at 128-bit and not specific to this
  package; when the ecosystem moves to post-quantum ciphers this
  package will follow.)
- Phishing / social engineering leading the user to paste credentials
  into a fake `CredentialAuth.set` prompt.

## Cryptographic choices

- **Envelope:** `cryptography.fernet.Fernet` — AES-128 in CBC mode with
  HMAC-SHA256 over `version || timestamp || IV || ciphertext`,
  integrity-authenticated. Timestamp is included for optional TTL
  enforcement (we leave `ttl=None` — vault lives as long as the user
  wants).
- **Key rotation:** `cryptography.fernet.MultiFernet` so the active key
  is listed first and retired keys decrypt in turn; reading
  auto-upgrades to the active key on next write.
- **Why not age / noise / libsodium secretbox:** Fernet is battle-tested,
  one library install, no multi-recipient identity complexity. age's
  best-in-class feature is X25519 recipient-addressing — not useful for
  a single-user local vault. If the Concinno ecosystem ever ships a
  cross-device sync, age might become interesting; today it is not.
