"""concinno_skills_auth._providers — Provider catalog.

@module _providers
@responsibility Central table of OAuth device-code endpoints, revoke
    URLs, and default scopes for the providers we ship out of the box.
    Lookups are case-insensitive.

Canonical source for each provider's URLs (verified in Phase 1 research):

- GitHub — https://docs.github.com/en/apps/creating-github-apps/writing-code-for-a-github-app/building-a-cli-with-a-github-app
- Google — https://developers.google.com/identity/protocols/oauth2/limited-input-device
- Microsoft — https://learn.microsoft.com/en-us/entra/identity-platform/v2-oauth2-device-code
- Slack does NOT support device flow — bot tokens only. Documented in
  ``providers.md`` and ``Provider.device_code_url`` returns ``None``.
"""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(frozen=True)
class ProviderSpec:
    """Static per-provider configuration.

    Empty-string fields mean *not supported for this provider* — callers
    must check before dispatching.
    """

    key: str
    display_name: str
    device_code_url: str
    token_url: str
    revoke_url: str
    default_scopes: tuple[str, ...] = field(default_factory=tuple)
    notes: str = ""


# Keys are lowercase. Lookup via ``get_provider`` normalises input.
_REGISTRY: dict[str, ProviderSpec] = {
    "github": ProviderSpec(
        key="github",
        display_name="GitHub",
        device_code_url="https://github.com/login/device/code",
        token_url="https://github.com/login/oauth/access_token",
        revoke_url="https://github.com/settings/applications",
        default_scopes=("repo", "read:user"),
        notes=(
            "Requires a registered OAuth App or GitHub App with the "
            "device-flow toggle enabled. Default scopes chosen for "
            "read + code-write; adjust via 'scopes' kwarg."
        ),
    ),
    "google": ProviderSpec(
        key="google",
        display_name="Google",
        device_code_url="https://oauth2.googleapis.com/device/code",
        token_url="https://oauth2.googleapis.com/token",
        revoke_url="https://myaccount.google.com/permissions",
        default_scopes=("https://www.googleapis.com/auth/userinfo.email",),
        notes=(
            "Refresh token is returned by default. Scopes must be "
            "space-delimited per Google spec; OAuthFlow joins the "
            "tuple with ' '."
        ),
    ),
    "microsoft": ProviderSpec(
        key="microsoft",
        display_name="Microsoft",
        device_code_url=(
            "https://login.microsoftonline.com/common/oauth2/v2.0/devicecode"
        ),
        token_url=(
            "https://login.microsoftonline.com/common/oauth2/v2.0/token"
        ),
        revoke_url="https://myapps.microsoft.com",
        default_scopes=("openid", "offline_access", "User.Read"),
        notes=(
            "Tenant defaults to 'common'. Override via 'tenant' kwarg "
            "to OAuthFlow (e.g. 'organizations', 'consumers', or a "
            "directory GUID)."
        ),
    ),
    "slack": ProviderSpec(
        key="slack",
        display_name="Slack",
        device_code_url="",  # unsupported
        token_url="",
        revoke_url="https://api.slack.com/apps",
        default_scopes=(),
        notes=(
            "Slack does NOT support RFC 8628 device flow. Use "
            "CredentialAuth.set with a xoxb-... bot token instead."
        ),
    ),
}


# Other providers we advertise as supported by ``CredentialAuth`` as a
# simple api_key / connection_string store. Included so validation of
# the 'provider' field is explicit, not magic.
_API_KEY_ONLY_PROVIDERS: frozenset[str] = frozenset(
    {
        "anthropic",
        "aws",
        "azure",
        "chroma",
        "cohere",
        "custom",
        "gcp",
        "hubspot",
        "intercom",
        "mailchimp",
        "notion",
        "openai",
        "pinecone",
        "salesforce",
        "sendgrid",
        "shopify",
        "stripe",
        "twilio",
        "typeform",
        "weaviate",
        "zendesk",
    }
)


def get_provider(key: str) -> ProviderSpec | None:
    """Return the ProviderSpec for ``key`` or ``None`` if unknown.

    Lookup is case-insensitive. ``'slack'`` returns a spec whose
    ``device_code_url`` is empty — callers dispatching to device flow
    must check ``spec.device_code_url`` truthiness before use.
    """
    if not isinstance(key, str):
        return None
    return _REGISTRY.get(key.strip().lower())


def is_known_provider(key: str) -> bool:
    """True if ``key`` is one of our device-code or api-key providers."""
    if not isinstance(key, str):
        return False
    normalized = key.strip().lower()
    return normalized in _REGISTRY or normalized in _API_KEY_ONLY_PROVIDERS


def list_providers() -> list[dict[str, object]]:
    """Return a JSON-serialisable list of all provider specs.

    Used by ``CredentialAuth.call(action='providers')`` so the skill can
    tell the user what's supported out of the box.
    """
    out: list[dict[str, object]] = []
    for spec in _REGISTRY.values():
        out.append(
            {
                "key": spec.key,
                "display_name": spec.display_name,
                "device_code_url": spec.device_code_url or None,
                "token_url": spec.token_url or None,
                "revoke_url": spec.revoke_url,
                "default_scopes": list(spec.default_scopes),
                "flow": "device_code" if spec.device_code_url else "api_key",
                "notes": spec.notes,
            }
        )
    for key in sorted(_API_KEY_ONLY_PROVIDERS):
        out.append(
            {
                "key": key,
                "display_name": key,
                "device_code_url": None,
                "token_url": None,
                "revoke_url": None,
                "default_scopes": [],
                "flow": "api_key",
                "notes": "api_key / connection_string only",
            }
        )
    return out


__all__ = [
    "ProviderSpec",
    "get_provider",
    "is_known_provider",
    "list_providers",
]
