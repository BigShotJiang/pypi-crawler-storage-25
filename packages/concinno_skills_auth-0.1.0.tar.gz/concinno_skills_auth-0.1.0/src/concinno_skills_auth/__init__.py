"""concinno-skills-auth — Unified credential + OAuth + rotation skills.

One vault, one OAuth device-code flow, one rotation path for all 20+
``concinno-skills-*`` sub-packages. Local-machine Fernet-encrypted vault
with OS-keyring master key + file fallback. RFC 8628 device-code grant
for GitHub / Google / Microsoft / generic providers.

MVP surface (0.1.0)
-------------------
- :class:`CredentialAuth` — list / get / set / delete credential
  entries, lookup by alias.
- :class:`OAuthFlow` — OAuth 2.0 device-code grant (RFC 8628) for
  agent-friendly headless login.
- :class:`SecretRotate` — rotate api_key / refresh oauth token /
  mass-rotate all entries for a provider; emits a migration log.

Security
--------
See ``SECURITY.md`` for the threat model and crypto choices. The vault
is machine-local by design; cross-machine transfer requires an explicit
manual step.
"""

from __future__ import annotations

from concinno_skills_auth.credential_auth import CredentialAuth
from concinno_skills_auth.oauth_flow import OAuthFlow
from concinno_skills_auth.secret_rotate import SecretRotate

__version__ = "0.1.0"
__all__ = [
    "CredentialAuth",
    "OAuthFlow",
    "SecretRotate",
    "__version__",
]
