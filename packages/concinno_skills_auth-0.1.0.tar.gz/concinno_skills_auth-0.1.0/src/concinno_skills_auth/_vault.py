"""concinno_skills_auth._vault — Local Fernet-encrypted credential vault.

@module _vault
@responsibility Persist credential entries as a single Fernet-encrypted
    JSON blob at ``~/.concinno/vault/credentials.enc``. Master key held
    in OS keyring (primary) or ``~/.concinno/vault/.master-key`` with
    ``0o600`` permission (fallback). Atomic write via ``os.replace``.
    Rotating backup of the last 5 ciphertext files before each mutation.

Schema v1 plaintext JSON (inside the Fernet envelope)::

    {
      "version": 1,
      "accounts": {
        "<alias>": {
          "provider": "github|google|...",
          "type": "api_key|oauth_token|basic_auth|...",
          "data": {...},
          "scopes": [...],
          "created_at": "2026-04-23T...+00:00",
          "last_rotated": "...",
          "expires_at": "..."
        }
      }
    }

Concurrency
-----------
Per-call atomic write gives last-writer-wins semantics for two concurrent
agents touching disjoint aliases — each serialise the whole vault so a
lost update is possible. Callers who need strict serialisation should
use the ``lock()`` context manager which takes a file lock via
``fcntl.flock`` (POSIX) or ``msvcrt.locking`` (Windows).
"""

from __future__ import annotations

import contextlib
import datetime as _dt
import json
import logging
import os
import sys
import time
from collections.abc import Iterator
from pathlib import Path
from typing import Any

logger = logging.getLogger("concinno_skills_auth.vault")

_SCHEMA_VERSION = 1
_KEYRING_SERVICE = "concinno-vault"
_KEYRING_USER = "master-key"
_ENV_MASTER_KEY = "CONCINNO_VAULT_MASTER_KEY"
_BACKUP_KEEP = 5


def _utcnow_iso() -> str:
    """UTC timestamp with trailing ``+00:00`` offset (ISO-8601)."""
    return _dt.datetime.now(_dt.timezone.utc).isoformat()


def _vault_dir(base: Path | None = None) -> Path:
    """Directory holding the vault + backups.

    ``base`` override lets the test suite point at a tmp dir.
    """
    if base is not None:
        return base
    return Path.home() / ".concinno" / "vault"


def _ensure_dir(path: Path) -> None:
    """mkdir -p with ``0o700`` where the OS honours it."""
    path.mkdir(parents=True, exist_ok=True)
    # 0o700 is a no-op on Windows NTFS but correct on POSIX.
    with contextlib.suppress(OSError):
        os.chmod(path, 0o700)


# ── Master-key management ────────────────────────────────────────────


def _load_master_key_from_keyring() -> bytes | None:
    """Return the Fernet key bytes from the OS keyring or ``None``."""
    try:
        import keyring
        from keyring.errors import KeyringError
    except ImportError:
        return None
    try:
        raw = keyring.get_password(_KEYRING_SERVICE, _KEYRING_USER)
    except KeyringError as exc:  # noqa: BLE001 — keyring variants
        logger.warning("vault: keyring get_password failed: %s", exc)
        return None
    except Exception as exc:  # pragma: no cover — backend-specific
        logger.warning("vault: keyring backend unavailable: %s", exc)
        return None
    if raw is None or not isinstance(raw, str) or not raw:
        return None
    return raw.encode("ascii")


def _save_master_key_to_keyring(key_bytes: bytes) -> bool:
    """Store key in the OS keyring. Returns True on success."""
    try:
        import keyring
        from keyring.errors import KeyringError
    except ImportError:
        return False
    try:
        keyring.set_password(
            _KEYRING_SERVICE, _KEYRING_USER, key_bytes.decode("ascii")
        )
    except KeyringError as exc:
        logger.warning("vault: keyring set_password failed: %s", exc)
        return False
    except Exception as exc:  # pragma: no cover
        logger.warning("vault: keyring write unavailable: %s", exc)
        return False
    return True


def _fallback_key_path(base: Path | None = None) -> Path:
    return _vault_dir(base) / ".master-key"


def _load_master_key_from_file(base: Path | None = None) -> bytes | None:
    path = _fallback_key_path(base)
    if not path.exists():
        return None
    try:
        return path.read_bytes().strip()
    except OSError as exc:
        logger.warning("vault: master-key read failed: %s", exc)
        return None


def _save_master_key_to_file(
    key_bytes: bytes, base: Path | None = None
) -> None:
    path = _fallback_key_path(base)
    _ensure_dir(path.parent)
    # Write then chmod — on Windows chmod silently ignores perms bits.
    path.write_bytes(key_bytes)
    with contextlib.suppress(OSError):
        os.chmod(path, 0o600)
    # Stderr breadcrumb so the user knows the vault fell back.
    sys.stderr.write(
        "concinno-skills-auth: keyring backend unavailable; "
        "master-key stored in fallback file (chmod 0o600)\n"
    )


def load_or_create_master_key(base: Path | None = None) -> bytes:
    """Return the Fernet master key bytes.

    Lookup order:

    1. Env var ``CONCINNO_VAULT_MASTER_KEY`` — session-only override.
    2. OS keyring.
    3. Fallback file ``~/.concinno/vault/.master-key``.
    4. Generate a new key, persist via keyring if possible else file.
    """
    env = os.environ.get(_ENV_MASTER_KEY, "").strip()
    if env:
        return env.encode("ascii")

    key = _load_master_key_from_keyring()
    if key is not None:
        return key

    key = _load_master_key_from_file(base)
    if key is not None:
        return key

    # Generate a new one — first-time setup.
    from cryptography.fernet import Fernet

    new_key = Fernet.generate_key()
    if not _save_master_key_to_keyring(new_key):
        _save_master_key_to_file(new_key, base=base)
    return new_key


# ── Encryption primitives ────────────────────────────────────────────


def _fernet_for(key_bytes: bytes) -> Any:
    from cryptography.fernet import Fernet

    return Fernet(key_bytes)


def _encrypt_plaintext(plaintext: bytes, key_bytes: bytes) -> bytes:
    return _fernet_for(key_bytes).encrypt(plaintext)


def _decrypt_ciphertext(ciphertext: bytes, key_bytes: bytes) -> bytes:
    return _fernet_for(key_bytes).decrypt(ciphertext)


# ── Backup rotation ──────────────────────────────────────────────────


def _rotate_backups(base: Path | None = None) -> None:
    """Keep the newest ``_BACKUP_KEEP`` ciphertext backups."""
    backups_dir = _vault_dir(base) / "backups"
    if not backups_dir.exists():
        return
    files = sorted(
        backups_dir.glob("credentials-*.enc"),
        key=lambda p: p.stat().st_mtime,
        reverse=True,
    )
    for old in files[_BACKUP_KEEP:]:
        with contextlib.suppress(OSError):
            old.unlink()


def _snapshot_backup(ciphertext_path: Path) -> None:
    """Copy the current ciphertext into ``backups/`` with an ISO stamp."""
    if not ciphertext_path.exists():
        return
    backups_dir = ciphertext_path.parent / "backups"
    _ensure_dir(backups_dir)
    # Colon is invalid in Windows filenames — use a compact form.
    stamp = _dt.datetime.now(_dt.timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    dest = backups_dir / f"credentials-{stamp}.enc"
    try:
        dest.write_bytes(ciphertext_path.read_bytes())
    except OSError as exc:
        logger.warning("vault: backup snapshot failed: %s", exc)
    _rotate_backups(ciphertext_path.parent)


# ── File lock (best-effort) ──────────────────────────────────────────


@contextlib.contextmanager
def lock(base: Path | None = None, timeout: float = 5.0) -> Iterator[None]:
    """Advisory file lock around read-modify-write.

    Cross-platform: ``fcntl`` on POSIX, ``msvcrt`` on Windows. On any
    unsupported platform this degrades to a no-op with a warning.
    """
    vault_dir = _vault_dir(base)
    _ensure_dir(vault_dir)
    lock_path = vault_dir / ".lock"
    # Open for writing so both OS flavours can lock it.
    fh = lock_path.open("a+")
    acquired = False
    start = time.monotonic()
    try:
        while time.monotonic() - start < timeout:
            try:
                if os.name == "nt":
                    import msvcrt

                    msvcrt.locking(fh.fileno(), msvcrt.LK_NBLCK, 1)
                    acquired = True
                    break
                else:
                    import fcntl

                    fcntl.flock(fh.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
                    acquired = True
                    break
            except (OSError, BlockingIOError):
                time.sleep(0.1)
        if not acquired:
            raise TimeoutError(
                f"vault lock not acquired within {timeout}s"
            )
        yield
    finally:
        if acquired:
            try:
                if os.name == "nt":
                    import msvcrt

                    fh.seek(0)
                    with contextlib.suppress(OSError):
                        msvcrt.locking(fh.fileno(), msvcrt.LK_UNLCK, 1)
                else:
                    import fcntl

                    fcntl.flock(fh.fileno(), fcntl.LOCK_UN)
            except Exception:  # pragma: no cover
                pass
        fh.close()


# ── Read / write high-level API ─────────────────────────────────────


def _ciphertext_path(base: Path | None = None) -> Path:
    return _vault_dir(base) / "credentials.enc"


def _empty_vault() -> dict[str, Any]:
    return {
        "version": _SCHEMA_VERSION,
        "accounts": {},
    }


def read_vault(
    base: Path | None = None, *, master_key: bytes | None = None
) -> dict[str, Any]:
    """Decrypt and return the vault dict. Returns an empty skeleton
    when the ciphertext file does not yet exist.
    """
    path = _ciphertext_path(base)
    if not path.exists():
        return _empty_vault()
    key = master_key if master_key is not None else load_or_create_master_key(base)
    try:
        blob = path.read_bytes()
    except OSError as exc:
        raise RuntimeError(f"vault read failed: {exc}") from exc
    try:
        plaintext = _decrypt_ciphertext(blob, key)
    except Exception as exc:  # noqa: BLE001 — cryptography.InvalidToken etc.
        raise RuntimeError(f"vault decrypt failed: {exc}") from exc
    try:
        data = json.loads(plaintext.decode("utf-8"))
    except ValueError as exc:
        raise RuntimeError(f"vault JSON parse failed: {exc}") from exc
    if not isinstance(data, dict) or "accounts" not in data:
        raise RuntimeError("vault has invalid shape (missing 'accounts')")
    return data


def write_vault(
    vault: dict[str, Any],
    *,
    base: Path | None = None,
    master_key: bytes | None = None,
) -> None:
    """Atomically encrypt and persist the vault dict.

    Backup snapshot of the previous ciphertext (if any) is taken before
    the replacement. ``os.replace`` provides atomic same-directory
    rename on both POSIX and Windows.
    """
    path = _ciphertext_path(base)
    _ensure_dir(path.parent)
    key = master_key if master_key is not None else load_or_create_master_key(base)
    vault.setdefault("version", _SCHEMA_VERSION)
    plaintext = json.dumps(vault, ensure_ascii=False, indent=2).encode(
        "utf-8"
    )
    ciphertext = _encrypt_plaintext(plaintext, key)

    _snapshot_backup(path)

    tmp_path = path.with_suffix(path.suffix + ".new")
    tmp_path.write_bytes(ciphertext)
    os.replace(tmp_path, path)


# ── Helpers for callers ──────────────────────────────────────────────


def list_aliases(base: Path | None = None) -> list[str]:
    vault = read_vault(base=base)
    accounts = vault.get("accounts", {})
    return sorted(accounts.keys()) if isinstance(accounts, dict) else []


def get_entry(
    alias: str, *, base: Path | None = None
) -> dict[str, Any] | None:
    vault = read_vault(base=base)
    accounts = vault.get("accounts", {})
    if not isinstance(accounts, dict):
        return None
    entry = accounts.get(alias)
    return entry if isinstance(entry, dict) else None


def set_entry(
    alias: str,
    entry: dict[str, Any],
    *,
    base: Path | None = None,
) -> None:
    now = _utcnow_iso()
    with lock(base=base):
        vault = read_vault(base=base)
        accounts = vault.setdefault("accounts", {})
        existing = accounts.get(alias)
        if isinstance(existing, dict):
            entry.setdefault("created_at", existing.get("created_at", now))
        else:
            entry.setdefault("created_at", now)
        entry.setdefault("last_rotated", now)
        accounts[alias] = entry
        write_vault(vault, base=base)


def delete_entry(alias: str, *, base: Path | None = None) -> bool:
    with lock(base=base):
        vault = read_vault(base=base)
        accounts = vault.get("accounts", {})
        if not isinstance(accounts, dict) or alias not in accounts:
            return False
        del accounts[alias]
        write_vault(vault, base=base)
        return True


def touch_rotation(
    alias: str,
    *,
    base: Path | None = None,
    patch_data: dict[str, Any] | None = None,
) -> dict[str, Any] | None:
    """Update ``last_rotated`` and optionally merge new ``data`` fields."""
    now = _utcnow_iso()
    with lock(base=base):
        vault = read_vault(base=base)
        accounts = vault.get("accounts", {})
        if not isinstance(accounts, dict) or alias not in accounts:
            return None
        entry = accounts[alias]
        if not isinstance(entry, dict):
            return None
        if patch_data:
            data = entry.setdefault("data", {})
            if isinstance(data, dict):
                data.update(patch_data)
        entry["last_rotated"] = now
        write_vault(vault, base=base)
        return entry


__all__ = [
    "delete_entry",
    "get_entry",
    "list_aliases",
    "load_or_create_master_key",
    "lock",
    "read_vault",
    "set_entry",
    "touch_rotation",
    "write_vault",
]
