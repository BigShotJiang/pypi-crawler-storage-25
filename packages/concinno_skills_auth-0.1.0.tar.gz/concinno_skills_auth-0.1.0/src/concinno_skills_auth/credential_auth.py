"""concinno_skills_auth.credential_auth — CredentialAuth Concinno tool.

@module credential_auth
@responsibility Expose the local encrypted vault as a Concinno ``Tool``:
    CRUD + listing + provider catalog. All network / disk errors are
    wrapped into ``{"error": "..."}``; never raises out of ``call()``.
@dependencies concinno_skills_auth._vault, _providers
@exports CredentialAuth
"""

from __future__ import annotations

import logging
from typing import Any

from concinno_skills_auth import _providers, _vault

logger = logging.getLogger("concinno_skills_auth.credential_auth")

_VALID_ACTIONS = frozenset(
    {"list", "get", "set", "delete", "providers"}
)
_VALID_TYPES = frozenset(
    {
        "api_key",
        "oauth_token",
        "basic_auth",
        "service_account",
        "connection_string",
    }
)


def _redact(entry: dict[str, Any]) -> dict[str, Any]:
    """Return a copy of ``entry`` with secret fields replaced by a
    stub. Keeps non-secret metadata (provider, type, scopes, timestamps)
    intact so the caller can decide whether to reveal the secret.
    """
    safe: dict[str, Any] = {}
    for key, value in entry.items():
        if key == "data" and isinstance(value, dict):
            redacted_data: dict[str, Any] = {}
            for k, v in value.items():
                if isinstance(v, str) and v:
                    redacted_data[k] = f"<redacted {len(v)} chars>"
                else:
                    redacted_data[k] = v
            safe[key] = redacted_data
        else:
            safe[key] = value
    return safe


class CredentialAuth:
    """List / get / set / delete credential entries in the local vault.

    Params accepted via ``call(**kwargs)``:
        action (str):      ``list`` | ``get`` | ``set`` | ``delete`` |
                           ``providers``.
        alias (str):       account nickname (for ``get`` / ``set`` /
                           ``delete``). Must match ``[A-Za-z0-9_.-]+``.
        provider (str):    for ``set`` — provider key
                           (``github`` / ``openai`` / ...).
        type (str):        for ``set`` — one of ``api_key`` /
                           ``oauth_token`` / ``basic_auth`` /
                           ``service_account`` / ``connection_string``.
        data (dict):       for ``set`` — the secret payload; leaves the
                           vault unless the caller includes it.
        scopes (list[str]):optional — OAuth scopes recorded with the
                           entry.
        expires_at (str):  optional ISO-8601 expiry hint.
        reveal (bool):     for ``get`` — set True to return the raw
                           secret. Default False returns redacted.

    Returns:
        list     → ``{"aliases": [...]}``.
        get      → ``{"alias": ..., "entry": {...}}`` or
                    ``{"error": "not found"}``.
        set      → ``{"ok": True, "alias": ...}``.
        delete   → ``{"ok": True}`` or ``{"error": "not found"}``.
        providers→ ``{"providers": [...]}``.
        failure  → ``{"error": "..."}``.
    """

    name: str = "credential_auth"
    description: str = (
        "CRUD for the local encrypted credential vault. "
        "Actions: list | get | set | delete | providers. "
        "set: alias, provider, type, data (dict), scopes?, expires_at?. "
        "get: alias, reveal=False (redacted by default). "
        "Returns {'aliases':...} | {'entry':...} | {'ok':True} | "
        "{'providers':...} | {'error':...}."
    )
    # Filesystem + file lock → serial.
    is_concurrency_safe: bool = False

    def call(self, **kwargs: Any) -> Any:
        action = kwargs.get("action")
        if action not in _VALID_ACTIONS:
            return {
                "error": (
                    "action must be one of "
                    "list|get|set|delete|providers, "
                    f"got {action!r}"
                )
            }
        try:
            if action == "list":
                return self._list()
            if action == "get":
                return self._get(**kwargs)
            if action == "set":
                return self._set(**kwargs)
            if action == "delete":
                return self._delete(**kwargs)
            # action == "providers"
            return {"providers": _providers.list_providers()}
        except Exception as exc:  # noqa: BLE001 — boundary wrap
            logger.warning("credential_auth.%s failed: %s", action, exc)
            return {"error": f"vault {action} failed: {exc}"}

    # ── actions ───────────────────────────────────────────────────────

    def _list(self) -> dict[str, Any]:
        return {"aliases": _vault.list_aliases()}

    def _get(self, **kwargs: Any) -> dict[str, Any]:
        alias = kwargs.get("alias")
        if not isinstance(alias, str) or not alias:
            return {"error": "get requires alias=str (non-empty)"}
        entry = _vault.get_entry(alias)
        if entry is None:
            return {"error": f"alias {alias!r} not found"}
        reveal = bool(kwargs.get("reveal", False))
        return {
            "alias": alias,
            "entry": entry if reveal else _redact(entry),
        }

    def _set(self, **kwargs: Any) -> dict[str, Any]:
        alias = kwargs.get("alias")
        provider = kwargs.get("provider")
        cred_type = kwargs.get("type")
        data = kwargs.get("data")

        if not isinstance(alias, str) or not alias:
            return {"error": "set requires alias=str (non-empty)"}
        if not _is_safe_alias(alias):
            return {
                "error": (
                    "alias must match [A-Za-z0-9_.-]+ "
                    "(no spaces, no slashes)"
                )
            }
        if not isinstance(provider, str) or not provider:
            return {"error": "set requires provider=str"}
        if not _providers.is_known_provider(provider):
            return {
                "error": (
                    f"unknown provider {provider!r}; "
                    "use action=providers to list supported keys, "
                    "or pass 'custom'"
                )
            }
        if cred_type not in _VALID_TYPES:
            return {
                "error": (
                    f"type must be one of {sorted(_VALID_TYPES)}, "
                    f"got {cred_type!r}"
                )
            }
        if not isinstance(data, dict) or not data:
            return {
                "error": (
                    "set requires data=dict with at least one field"
                )
            }

        entry: dict[str, Any] = {
            "provider": provider.strip().lower(),
            "type": cred_type,
            "data": dict(data),
        }
        scopes = kwargs.get("scopes")
        if isinstance(scopes, list):
            entry["scopes"] = [str(s) for s in scopes]
        expires_at = kwargs.get("expires_at")
        if isinstance(expires_at, str) and expires_at:
            entry["expires_at"] = expires_at

        _vault.set_entry(alias, entry)
        return {"ok": True, "alias": alias}

    def _delete(self, **kwargs: Any) -> dict[str, Any]:
        alias = kwargs.get("alias")
        if not isinstance(alias, str) or not alias:
            return {"error": "delete requires alias=str (non-empty)"}
        if _vault.delete_entry(alias):
            return {"ok": True}
        return {"error": f"alias {alias!r} not found"}


def _is_safe_alias(alias: str) -> bool:
    """``[A-Za-z0-9_.-]+`` — filesystem / URL safe, no spaces."""
    if not alias:
        return False
    return all(ch.isalnum() or ch in "_.-" for ch in alias)


__all__ = ["CredentialAuth"]
