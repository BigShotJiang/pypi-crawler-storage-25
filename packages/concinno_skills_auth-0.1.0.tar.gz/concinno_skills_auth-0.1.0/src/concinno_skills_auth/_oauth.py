"""concinno_skills_auth._oauth — OAuth 2.0 Device Authorization Grant.

@module _oauth
@responsibility RFC 8628 device-code grant client. Initiate + poll +
    normalise provider-specific error vocabularies to the four canonical
    RFC codes (``authorization_pending`` / ``slow_down`` /
    ``access_denied`` / ``expired_token``). Provider-specific URLs come
    from :mod:`_providers`; provider-specific error aliases are mapped
    here.

Polling rules (RFC 8628 §3.5):
    - ``authorization_pending``: keep polling, honour ``interval``.
    - ``slow_down``: keep polling, increase interval by 5 seconds.
    - ``access_denied`` / ``expired_token``: stop.
    - any other status: surface verbatim, stop.

A global wall-clock cap of 900 s overrides whatever ``expires_in`` the
server returned — we never poll forever.
"""

from __future__ import annotations

import json
import logging
import time
from dataclasses import dataclass
from typing import Any

from concinno_skills_auth._providers import ProviderSpec, get_provider

logger = logging.getLogger("concinno_skills_auth.oauth")

_DEFAULT_INTERVAL_SEC = 5
_MAX_WALL_CLOCK_SEC = 900
_DEVICE_CODE_GRANT = "urn:ietf:params:oauth:grant-type:device_code"


@dataclass(frozen=True)
class DeviceCodeResponse:
    """Fields from the provider's device-authorization response.

    ``verification_uri_complete`` and ``message`` are optional — Google
    ships both, Microsoft omits ``verification_uri_complete``.
    """

    device_code: str
    user_code: str
    verification_uri: str
    verification_uri_complete: str | None
    expires_in: int
    interval: int
    message: str | None
    raw: dict[str, Any]


# Provider-specific error aliases → RFC 8628 canonical codes.
_ERROR_ALIASES: dict[str, str] = {
    # Microsoft
    "authorization_declined": "access_denied",
    "bad_verification_code": "access_denied",
    # generic typos / OAuth 2.0 RFC 6749 base codes sometimes used
    "access_denied_by_resource_owner": "access_denied",
}


def _normalise_error_code(code: str) -> str:
    if not isinstance(code, str):
        return "unknown"
    return _ERROR_ALIASES.get(code.strip(), code.strip() or "unknown")


def _resolve_url(
    spec: ProviderSpec,
    url: str,
    *,
    tenant: str | None,
) -> str:
    """Substitute ``{tenant}`` placeholders (Microsoft) when asked."""
    if spec.key == "microsoft" and tenant:
        return url.replace("/common/", f"/{tenant}/", 1)
    return url


def _http_post_form(
    url: str, form: dict[str, str], *, timeout: float = 30.0
) -> tuple[int, dict[str, Any] | str]:
    """POST form-encoded, return (status, parsed body)."""
    import httpx

    headers = {
        "Accept": "application/json",
        "Content-Type": "application/x-www-form-urlencoded",
    }
    with httpx.Client(timeout=timeout) as client:
        resp = client.post(url, data=form, headers=headers)
    # Providers sometimes reply 200 with an error body — don't rely on
    # status alone; parse first, then let the caller decide.
    body: Any
    try:
        body = resp.json()
    except ValueError:
        body = resp.text
    return resp.status_code, body


def initiate_device_code(
    provider: str,
    *,
    client_id: str,
    scopes: tuple[str, ...] | None = None,
    tenant: str | None = None,
    provider_url: str | None = None,
    token_url: str | None = None,
) -> DeviceCodeResponse | dict[str, Any]:
    """Fire the ``/devicecode`` request for ``provider``.

    Returns a :class:`DeviceCodeResponse` on success or
    ``{"error": "..."}`` on failure. The caller passes the dict
    verbatim to the user.

    ``provider_url`` / ``token_url`` let callers plug in a custom
    provider not in :mod:`_providers`; both must be supplied when
    ``provider == 'custom'``.
    """
    spec = get_provider(provider)
    if spec is None:
        if provider_url is None or token_url is None:
            return {
                "error": (
                    f"unknown provider {provider!r}; "
                    "pass provider_url + token_url for custom"
                )
            }
        device_url = provider_url
    else:
        if not spec.device_code_url:
            return {
                "error": (
                    f"{spec.display_name} does not support OAuth 2.0 "
                    "device-code flow; use CredentialAuth.set with a "
                    "static token instead"
                )
            }
        device_url = _resolve_url(
            spec, spec.device_code_url, tenant=tenant
        )

    scope_tuple: tuple[str, ...]
    if scopes is None:
        scope_tuple = spec.default_scopes if spec is not None else ()
    else:
        scope_tuple = tuple(s for s in scopes if isinstance(s, str) and s)

    form = {"client_id": client_id}
    if scope_tuple:
        form["scope"] = " ".join(scope_tuple)

    try:
        status, body = _http_post_form(device_url, form)
    except Exception as exc:  # noqa: BLE001 — network / TLS variety
        return {"error": f"device-code request failed: {exc}"}

    if not isinstance(body, dict):
        return {
            "error": (
                f"provider returned non-JSON body (status {status}): "
                f"{str(body)[:200]}"
            )
        }
    if status >= 400 or "device_code" not in body:
        err = body.get("error") or body.get("error_description") or body
        return {
            "error": f"device-code rejected (status {status}): {err}",
            "raw": body,
        }

    try:
        return DeviceCodeResponse(
            device_code=str(body["device_code"]),
            user_code=str(body.get("user_code", "")),
            verification_uri=str(body.get("verification_uri", "")),
            verification_uri_complete=(
                str(body["verification_uri_complete"])
                if "verification_uri_complete" in body
                else None
            ),
            expires_in=int(body.get("expires_in", 900)),
            interval=int(body.get("interval", _DEFAULT_INTERVAL_SEC)),
            message=(
                str(body["message"]) if "message" in body else None
            ),
            raw=body,
        )
    except (TypeError, ValueError) as exc:
        return {
            "error": f"device-code parse failed: {exc}",
            "raw": body,
        }


def poll_token(
    provider: str,
    device_code: str,
    *,
    client_id: str,
    interval: int = _DEFAULT_INTERVAL_SEC,
    max_wall_clock_sec: int = _MAX_WALL_CLOCK_SEC,
    tenant: str | None = None,
    token_url: str | None = None,
    sleep: Any = time.sleep,
) -> dict[str, Any]:
    """Poll ``/token`` until success, denial, expiry, or wall-clock cap.

    ``sleep`` is injectable so tests can replace it with a no-op.
    """
    spec = get_provider(provider)
    if spec is not None:
        url = _resolve_url(spec, spec.token_url, tenant=tenant)
    elif token_url is not None:
        url = token_url
    else:
        return {"error": f"unknown provider {provider!r}, no token_url"}

    form = {
        "grant_type": _DEVICE_CODE_GRANT,
        "device_code": device_code,
        "client_id": client_id,
    }

    deadline = time.monotonic() + max_wall_clock_sec
    current_interval = max(1, int(interval))
    while True:
        try:
            status, body = _http_post_form(url, form)
        except Exception as exc:  # noqa: BLE001
            return {"error": f"token poll failed: {exc}"}

        if isinstance(body, dict) and "access_token" in body:
            return {
                "ok": True,
                "access_token": str(body["access_token"]),
                "refresh_token": (
                    str(body["refresh_token"])
                    if "refresh_token" in body
                    else None
                ),
                "token_type": str(body.get("token_type", "Bearer")),
                "scope": body.get("scope"),
                "expires_in": body.get("expires_in"),
                "raw": body,
            }

        if not isinstance(body, dict):
            return {
                "error": (
                    f"provider returned non-JSON body (status {status}): "
                    f"{str(body)[:200]}"
                )
            }

        code = _normalise_error_code(str(body.get("error", "")))
        if code == "authorization_pending":
            pass
        elif code == "slow_down":
            current_interval += 5
        elif code in ("access_denied", "expired_token"):
            return {
                "error": code,
                "error_description": body.get("error_description"),
                "raw": body,
            }
        else:
            # Unknown code — surface as-is and stop.
            return {
                "error": code or "unknown",
                "error_description": body.get("error_description"),
                "raw": body,
            }

        if time.monotonic() >= deadline:
            return {
                "error": "expired_token",
                "error_description": (
                    "wall-clock cap reached before user completed flow"
                ),
            }
        sleep(current_interval)


def dumps_json(obj: Any) -> str:
    """Stable JSON for log lines (deterministic test output)."""
    return json.dumps(obj, ensure_ascii=False, sort_keys=True)


__all__ = [
    "DeviceCodeResponse",
    "dumps_json",
    "initiate_device_code",
    "poll_token",
]
