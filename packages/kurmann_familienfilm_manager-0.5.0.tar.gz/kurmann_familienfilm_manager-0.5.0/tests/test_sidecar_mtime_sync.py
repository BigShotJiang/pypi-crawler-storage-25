"""Tests für Sidecar-mtime Synchronisierung mit published_at.

Hintergrund: published_at hat Sekunden-Auflösung, Filesystem-mtime hat
Mikrosekunden. Ohne explizite Synchronisierung wäre die Sidecar-mtime
ein paar Mikrosekunden nach published_at, was den Skip-Check bei
publish-dir fälschlicherweise einen Republish triggern lässt.
"""

import os
from datetime import datetime
from pathlib import Path

from familienfilm_manager.core.directory_publisher import _is_already_published
from familienfilm_manager.core.sidecar_manager import (
    SidecarSettings,
    sidecar_path_for,
    write_sidecar,
)


def _simulate_publish(video_path: Path, published_at: datetime) -> None:
    """Simuliert was der Publisher nach erfolgreicher Publikation tut.

    Schreibt das Sidecar mit published_at und synchronisiert die
    Sidecar-mtime auf den published_at-Timestamp.
    """
    settings = SidecarSettings(
        web_id="a3xk9mn2pqrw",
        published_at=published_at.isoformat(timespec="seconds"),
    )
    sidecar = write_sidecar(video_path, settings)
    ts = published_at.replace(microsecond=0).timestamp()
    os.utime(sidecar, (ts, ts))


def test_skip_after_simulated_publish(tmp_path: Path):
    """Direkt nach Publish soll Skip greifen — ohne Sidecar-mtime-Sync wäre das nicht der Fall."""
    video = tmp_path / "2026-04-16 Test.mov"
    video.touch()
    # Video-mtime in die Vergangenheit (Quelle hat sich nicht geändert)
    past = datetime.now().timestamp() - 60
    os.utime(video, (past, past))

    # Simuliere Publish
    _simulate_publish(video, datetime.now())

    # Direkt danach: Skip soll greifen
    skip, ts = _is_already_published(video)
    assert skip is True, "Sidecar-mtime sollte == published_at sein, nicht > published_at"


def test_sidecar_mtime_matches_published_at(tmp_path: Path):
    """Sidecar-mtime ist exakt der published_at-Timestamp (Sekunden-Auflösung)."""
    video = tmp_path / "2026-04-16 Test.mov"
    video.touch()

    published_at = datetime(2026, 4, 17, 10, 4, 41)
    _simulate_publish(video, published_at)

    sidecar = sidecar_path_for(video)
    actual_mtime = sidecar.stat().st_mtime
    expected_ts = published_at.timestamp()
    # Exakt gleich (auf Sekunden-Basis)
    assert int(actual_mtime) == int(expected_ts)


def test_skip_persists_across_multiple_runs(tmp_path: Path):
    """Mehrere Skip-Checks hintereinander liefern alle True (idempotent)."""
    video = tmp_path / "2026-04-16 Test.mov"
    video.touch()
    past = datetime.now().timestamp() - 60
    os.utime(video, (past, past))

    _simulate_publish(video, datetime.now())

    # 5x checken
    for _ in range(5):
        skip, _ = _is_already_published(video)
        assert skip is True
