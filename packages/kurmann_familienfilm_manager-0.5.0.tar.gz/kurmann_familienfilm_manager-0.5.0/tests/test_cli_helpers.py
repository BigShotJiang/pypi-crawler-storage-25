"""Tests für CLI-Helfer (_resolve_work_dir)."""

from pathlib import Path
from unittest.mock import patch

from familienfilm_manager.cli.main import _resolve_work_dir


def test_resolve_work_dir_cli_wins():
    """CLI-Wert hat höchste Priorität."""
    cli_dir = Path("/lokal/tmp")
    with patch("familienfilm_manager.cli.main.config_manager.get", return_value="/config/work"):
        result = _resolve_work_dir(cli_dir)
    assert result == cli_dir


def test_resolve_work_dir_falls_back_to_config():
    """Wenn CLI None, wird Config gelesen."""
    with patch("familienfilm_manager.cli.main.config_manager.get", return_value="/config/work"):
        result = _resolve_work_dir(None)
    assert result == Path("/config/work")


def test_resolve_work_dir_expands_user():
    """Tilde im Config-Pfad wird zu Home-Verzeichnis expandiert."""
    with patch("familienfilm_manager.cli.main.config_manager.get", return_value="~/scratch"):
        result = _resolve_work_dir(None)
    assert result is not None
    assert "~" not in str(result)


def test_resolve_work_dir_returns_none_when_neither_set():
    """Ohne CLI und ohne Config → None (Publisher fällt auf Quellverzeichnis)."""
    with patch("familienfilm_manager.cli.main.config_manager.get", return_value=None):
        result = _resolve_work_dir(None)
    assert result is None


def test_resolve_work_dir_empty_config_returns_none():
    """Leerer Config-String wird wie None behandelt."""
    with patch("familienfilm_manager.cli.main.config_manager.get", return_value=""):
        result = _resolve_work_dir(None)
    assert result is None
