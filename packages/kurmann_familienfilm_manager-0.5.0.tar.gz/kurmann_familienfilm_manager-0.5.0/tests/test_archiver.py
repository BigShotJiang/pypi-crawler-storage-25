"""Tests für den Archiver (TAR-interne Dateinamen)."""

from pathlib import Path

from familienfilm_manager.core.archiver import _arcname


def test_arcname_video_extension():
    """Stem wird ersetzt, .mov bleibt."""
    result = _arcname(
        Path("/tmp/HDR-Test poster-1s200.mov"),
        source_stem="HDR-Test poster-1s200",
        target_stem="2026-04-16 HDR-Test",
    )
    assert result == "2026-04-16 HDR-Test.mov"


def test_arcname_settings_toml():
    """Mehrteilige Endung .settings.toml wird bewahrt."""
    result = _arcname(
        Path("/tmp/HDR-Test poster-1s200.settings.toml"),
        source_stem="HDR-Test poster-1s200",
        target_stem="2026-04-16 HDR-Test",
    )
    assert result == "2026-04-16 HDR-Test.settings.toml"


def test_arcname_sidecar_with_suffix():
    """Sidecar mit Suffix nach dem Stem (z.B. -poster.jpg) wird korrekt ersetzt."""
    result = _arcname(
        Path("/tmp/HDR-Test poster-1s200-poster.jpg"),
        source_stem="HDR-Test poster-1s200",
        target_stem="2026-04-16 HDR-Test",
    )
    assert result == "2026-04-16 HDR-Test-poster.jpg"


def test_arcname_no_match_keeps_original():
    """Wenn der Datei-Stem nicht passt, wird der Original-Name behalten."""
    result = _arcname(
        Path("/tmp/AnderesVideo.mp4"),
        source_stem="HDR-Test poster-1s200",
        target_stem="2026-04-16 HDR-Test",
    )
    assert result == "AnderesVideo.mp4"


def test_arcname_preserves_umlauts():
    """Umlaute im target_stem bleiben erhalten (Joliet-Kompatibilität)."""
    result = _arcname(
        Path("/tmp/Wanderung Lobbärg poster-2min.mov"),
        source_stem="Wanderung Lobbärg poster-2min",
        target_stem="2026-04-12 Wanderung Lobbärg",
    )
    assert result == "2026-04-12 Wanderung Lobbärg.mov"
