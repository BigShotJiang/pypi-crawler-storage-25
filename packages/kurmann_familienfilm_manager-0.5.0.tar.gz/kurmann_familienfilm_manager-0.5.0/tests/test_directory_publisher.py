"""Tests für den Verzeichnis-Publisher (Filter, Sortierung, Skip-Logik)."""

import os
from datetime import datetime, timedelta
from pathlib import Path

import pytest

from familienfilm_manager.core.directory_publisher import (
    _date_from_filename,
    _is_already_published,
    _is_qualified_video,
    _scan_directory,
)
from familienfilm_manager.core.sidecar_manager import SidecarSettings, write_sidecar


# ── _is_qualified_video: Filter ──


def test_qualified_video_with_date_prefix(tmp_path: Path):
    """Datei mit Datum-Präfix und .mov-Endung ist qualifiziert."""
    f = tmp_path / "2026-04-16 HDR-Test.mov"
    f.touch()
    assert _is_qualified_video(f) is True


def test_qualified_video_mp4(tmp_path: Path):
    """Auch .mp4 ist qualifiziert."""
    f = tmp_path / "2026-04-12 Wanderung.mp4"
    f.touch()
    assert _is_qualified_video(f) is True


def test_unqualified_no_date_prefix(tmp_path: Path):
    """Ohne Datum-Präfix → nicht qualifiziert."""
    f = tmp_path / "HDR-Test.mov"
    f.touch()
    assert _is_qualified_video(f) is False


def test_unqualified_unknown_extension(tmp_path: Path):
    """Unbekannte Endung → nicht qualifiziert."""
    f = tmp_path / "2026-04-16 Test.txt"
    f.touch()
    assert _is_qualified_video(f) is False


def test_unqualified_hidden_file(tmp_path: Path):
    """Hidden Files (mit .) werden ignoriert."""
    f = tmp_path / ".2026-04-16 Test.mov"
    f.touch()
    assert _is_qualified_video(f) is False


def test_unqualified_directory(tmp_path: Path):
    """Verzeichnis ist nicht qualifiziert (auch wenn Name passt)."""
    d = tmp_path / "2026-04-16 Verzeichnis.mov"
    d.mkdir()
    assert _is_qualified_video(d) is False


# ── _date_from_filename ──


def test_date_extraction(tmp_path: Path):
    """Datum wird korrekt aus Stem extrahiert."""
    assert _date_from_filename(Path("/tmp/2026-04-16 Test.mov")) == "2026-04-16"


def test_date_extraction_with_poster_suffix(tmp_path: Path):
    """Auch mit Poster-Suffix wird das Datum korrekt extrahiert."""
    assert _date_from_filename(Path("/tmp/2026-04-12 Test poster-1min30.mov")) == "2026-04-12"


# ── _scan_directory: Sortierung ──


def test_scan_sorts_by_date_oldest_first(tmp_path: Path):
    """Videos werden chronologisch sortiert (älteste zuerst)."""
    (tmp_path / "2026-04-16 C.mov").touch()
    (tmp_path / "2026-04-12 A.mov").touch()
    (tmp_path / "2026-04-14 B.mov").touch()

    result = _scan_directory(tmp_path)
    names = [p.name for p in result]
    assert names == ["2026-04-12 A.mov", "2026-04-14 B.mov", "2026-04-16 C.mov"]


def test_scan_ignores_unqualified_files(tmp_path: Path):
    """Unqualifizierte Dateien werden ignoriert."""
    (tmp_path / "2026-04-16 Valid.mov").touch()
    (tmp_path / "Invalid.mov").touch()
    (tmp_path / "2026-04-15 Notes.txt").touch()

    result = _scan_directory(tmp_path)
    names = [p.name for p in result]
    assert names == ["2026-04-16 Valid.mov"]


def test_scan_empty_directory(tmp_path: Path):
    """Leeres Verzeichnis → leere Liste."""
    assert _scan_directory(tmp_path) == []


def test_scan_same_date_alphabetical(tmp_path: Path):
    """Bei gleichem Datum → alphabetisch."""
    (tmp_path / "2026-04-16 Z-Video.mov").touch()
    (tmp_path / "2026-04-16 A-Video.mov").touch()

    result = _scan_directory(tmp_path)
    names = [p.name for p in result]
    assert names == ["2026-04-16 A-Video.mov", "2026-04-16 Z-Video.mov"]


# ── _is_already_published: Skip-Logik ──


def test_not_published_no_sidecar(tmp_path: Path):
    """Ohne Sidecar → noch nicht publiziert."""
    f = tmp_path / "2026-04-16 Test.mov"
    f.touch()
    skip, ts = _is_already_published(f)
    assert skip is False
    assert ts is None


def test_not_published_no_published_at(tmp_path: Path):
    """Sidecar ohne published_at → noch nicht publiziert."""
    f = tmp_path / "2026-04-16 Test.mov"
    f.touch()
    write_sidecar(f, SidecarSettings(web_id="a3xk9mn2pqrw"))
    skip, ts = _is_already_published(f)
    assert skip is False


def test_already_published_unchanged(tmp_path: Path):
    """Sidecar mit published_at + Video unverändert → skip."""
    f = tmp_path / "2026-04-16 Test.mov"
    f.touch()
    # Setze Video-mtime auf vor 1 Tag, published_at auf jetzt
    past = datetime.now() - timedelta(days=1)
    os.utime(f, (past.timestamp(), past.timestamp()))
    write_sidecar(f, SidecarSettings(
        web_id="a3xk9mn2pqrw",
        published_at=datetime.now().isoformat(timespec="seconds"),
    ))
    # Sidecar mtime auch in die Vergangenheit setzen (write_sidecar wäre sonst aktueller)
    sidecar = f.parent / f"{f.stem}.settings.toml"
    os.utime(sidecar, (past.timestamp(), past.timestamp()))
    skip, ts = _is_already_published(f)
    assert skip is True
    assert ts is not None


def test_video_modified_after_publish(tmp_path: Path):
    """Video wurde nach published_at geändert → republish."""
    f = tmp_path / "2026-04-16 Test.mov"
    f.touch()
    # published_at in der Vergangenheit
    past = datetime.now() - timedelta(days=1)
    write_sidecar(f, SidecarSettings(
        web_id="a3xk9mn2pqrw",
        published_at=past.isoformat(timespec="seconds"),
    ))
    # Video aktualisieren (mtime = jetzt)
    f.touch()
    skip, ts = _is_already_published(f)
    assert skip is False


def test_sidecar_modified_after_publish(tmp_path: Path):
    """Sidecar wurde nach published_at geändert → republish (z.B. neuer poster_at)."""
    f = tmp_path / "2026-04-16 Test.mov"
    f.touch()
    # Video-mtime in die Vergangenheit
    past = datetime.now() - timedelta(days=1)
    os.utime(f, (past.timestamp(), past.timestamp()))
    # Sidecar mit altem published_at, aber neuer mtime
    write_sidecar(f, SidecarSettings(
        web_id="a3xk9mn2pqrw",
        published_at=past.isoformat(timespec="seconds"),
    ))
    # Sidecar wurde gerade geschrieben (mtime = jetzt) → neuer als published_at
    skip, ts = _is_already_published(f)
    assert skip is False
