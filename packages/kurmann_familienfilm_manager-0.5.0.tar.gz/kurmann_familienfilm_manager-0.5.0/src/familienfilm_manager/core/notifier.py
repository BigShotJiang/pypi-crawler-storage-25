"""Benachrichtigung: Protokolliert veröffentlichte Videos in einer HTML-Datei."""

from __future__ import annotations

from datetime import datetime
from html import escape
from pathlib import Path


_HTML_HEADER = """\
<!DOCTYPE html>
<html lang="de">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Familienfilme</title>
<style>
  body { font-family: -apple-system, system-ui, sans-serif; background: #000; color: #ccc; padding: 1rem; }
  .entry { border-bottom: 1px solid #333; padding: 1rem 0; }
  .date { font-size: 0.8rem; color: #666; }
  .title { font-size: 1.1rem; font-weight: 600; color: #fff; margin: 0.3rem 0; }
  .meta { font-size: 0.85rem; color: #888; }
  a { color: #4af; }
</style>
</head>
<body>
"""

_HTML_FOOTER = "</body>\n</html>\n"


def append_notification(
    notification_path: Path,
    title: str,
    video_url: str | None = None,
    category: str | None = None,
    recording_date: str | None = None,
) -> None:
    """Hängt einen Eintrag an die Benachrichtigungsdatei (HTML) an.

    Die Datei kann in iCloud Drive liegen und wird automatisch auf alle
    Geräte synchronisiert. Links sind auf dem iPhone direkt klickbar.

    Args:
        notification_path: Pfad zur HTML-Datei (wird erstellt falls nicht vorhanden).
        title: Titel des Videos.
        video_url: Vollständige URL zum Video (optional).
        category: Kategorie (optional).
        recording_date: Aufnahmedatum (optional).
    """
    notification_path.parent.mkdir(parents=True, exist_ok=True)

    # Neuen Eintrag bauen
    now = datetime.now().strftime("%d.%m.%Y, %H:%M")
    entry_lines: list[str] = []
    entry_lines.append('<div class="entry">')
    entry_lines.append(f'  <div class="date">{escape(now)}</div>')
    if video_url:
        entry_lines.append(f'  <div class="title"><a href="{escape(video_url)}">{escape(title)}</a></div>')
    else:
        entry_lines.append(f'  <div class="title">{escape(title)}</div>')
    meta_parts: list[str] = []
    if category:
        meta_parts.append(escape(category))
    if recording_date:
        meta_parts.append(escape(recording_date))
    if meta_parts:
        entry_lines.append(f'  <div class="meta">{" · ".join(meta_parts)}</div>')
    entry_lines.append('</div>')
    new_entry = "\n".join(entry_lines) + "\n"

    if notification_path.exists():
        # Bestehende Datei: neuen Eintrag vor </body> einfügen (neuste oben)
        content = notification_path.read_text(encoding="utf-8")
        insert_pos = content.find("<body>")
        if insert_pos != -1:
            insert_pos = content.find("\n", insert_pos) + 1
            content = content[:insert_pos] + new_entry + content[insert_pos:]
            notification_path.write_text(content, encoding="utf-8")
            return

    # Neue Datei erstellen
    notification_path.write_text(
        _HTML_HEADER + new_entry + _HTML_FOOTER,
        encoding="utf-8",
    )
