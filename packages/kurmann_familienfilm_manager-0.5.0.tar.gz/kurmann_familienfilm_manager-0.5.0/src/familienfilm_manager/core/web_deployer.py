"""Web-Deployment: Web-ID-Verzeichnis via rclone zum Webserver kopieren."""

from __future__ import annotations

import subprocess
from pathlib import Path

from familienfilm_manager.api.models import (
    DeployResult,
    FamilienfilmEvent,
    FamilienfilmStage,
)


def deploy_to_web(
    source_dir: Path,
    web_target: str,
    rclone_path: str = "rclone",
    on_event=None,
) -> DeployResult:
    """Kopiert das Web-Medienset-Verzeichnis via rclone zum Webserver.

    Args:
        source_dir: Pfad zum Web-ID-Verzeichnis (vom WebProfile erstellt).
        web_target: rclone-Ziel für den Webserver.
        rclone_path: Pfad zur rclone-Binärdatei.
        on_event: Optionaler Event-Callback.

    Returns:
        DeployResult mit Erfolg/Fehler.
    """
    if not web_target:
        return DeployResult(
            success=False,
            error_message="Kein Web-Ziel konfiguriert (targets.web).",
        )

    if not source_dir.exists():
        return DeployResult(
            success=False,
            error_message=f"Quellverzeichnis nicht gefunden: {source_dir}",
        )

    try:
        # Web-ID-Verzeichnisname beibehalten
        web_id_name = source_dir.name
        target_dir = f"{web_target.rstrip('/')}/{web_id_name}"

        subprocess.run(
            [rclone_path, "copy", str(source_dir), target_dir],
            check=True,
            capture_output=True,
            text=True,
        )

        if on_event:
            on_event(FamilienfilmEvent(
                stage_id=FamilienfilmStage.WEB_DEPLOYED,
                message=f"Web-Deployment: {web_id_name} → {target_dir}",
            ))

        return DeployResult(success=True, target_path=target_dir)

    except subprocess.CalledProcessError as e:
        return DeployResult(
            success=False,
            error_message=f"Web-Deployment fehlgeschlagen: {e.stderr or e}",
        )
    except Exception as e:
        return DeployResult(
            success=False,
            error_message=f"Web-Deployment fehlgeschlagen: {e}",
        )
