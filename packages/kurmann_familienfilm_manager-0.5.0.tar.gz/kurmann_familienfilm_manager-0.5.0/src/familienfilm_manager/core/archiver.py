"""Archivierung: TAR-Erstellung aus Originaldateien + Sidecars und rclone move zum Ziel."""

from __future__ import annotations

import re
import subprocess
import tarfile
import unicodedata
from pathlib import Path

from familienfilm_manager.api.models import (
    ArchiveResult,
    FamilienfilmEvent,
    FamilienfilmStage,
)

# Deutsche Transliteration für ASCII-sichere Dateinamen
_GERMAN_TRANSLITERATION: dict[str, str] = {
    "ä": "ae", "ö": "oe", "ü": "ue", "ß": "ss",
    "Ä": "Ae", "Ö": "Oe", "Ü": "Ue",
}


def _to_ascii_slug(text: str) -> str:
    """Konvertiert einen Text in einen ASCII-sicheren Slug (Bindestriche statt Leerzeichen).

    Beispiel: "Leah gähnt im Bett" → "Leah-gaehnt-im-Bett"

    macOS speichert Dateinamen in NFD (z.B. "ä" = "a" + Combining Diaeresis).
    Daher zuerst nach NFC normalisieren, sonst greift die Transliteration nicht
    und Umlaute landen als nacktes "a"/"o"/"u" im Slug ("Madchen" statt "Maedchen").
    """
    # 1. NFC-Normalisierung (kombiniert Diakritika zu einem Code-Point)
    text = unicodedata.normalize("NFC", text)

    # 2. Deutsche Sonderzeichen transliterieren
    for char, replacement in _GERMAN_TRANSLITERATION.items():
        text = text.replace(char, replacement)

    # 3. Restliche Diakritika (z.B. é, à) auf ASCII reduzieren
    text = unicodedata.normalize("NFKD", text).encode("ascii", "ignore").decode("ascii")

    # 4. Nicht-alphanumerische Zeichen durch Bindestriche ersetzen
    text = re.sub(r"[^a-zA-Z0-9]+", "-", text)

    # 5. Führende/abschliessende Bindestriche entfernen
    return text.strip("-")


def _collect_sidecar_files(source_path: Path) -> list[Path]:
    """Sammelt Sidecar-Dateien mit gleichem Stem (inkl. Compound-Extensions wie .settings.toml)."""
    stem = source_path.stem
    prefix = stem + "."
    parent = source_path.parent
    sidecars = []
    for f in parent.iterdir():
        if f == source_path:
            continue
        if f.is_file() and f.name.startswith(prefix):
            sidecars.append(f)
    return sorted(sidecars)


def _arcname(file_path: Path, source_stem: str, target_stem: str) -> str:
    """Berechnet den TAR-internen Dateinamen mit ersetztem Stem.

    Bewahrt mehrteilige Endungen (z.B. ``.settings.toml``), indem der
    Quell-Stem (vor dem ersten Punkt nach dem Stem) durch den Ziel-Stem
    ersetzt wird.

    Beispiele (source_stem="HDR-Test poster-1s200", target_stem="2026-04-16 HDR-Test"):
        "HDR-Test poster-1s200.mov"            → "2026-04-16 HDR-Test.mov"
        "HDR-Test poster-1s200.settings.toml"  → "2026-04-16 HDR-Test.settings.toml"
        "HDR-Test poster-1s200-poster.jpg"     → "2026-04-16 HDR-Test-poster.jpg"
    """
    name = file_path.name
    if name.startswith(source_stem):
        return target_stem + name[len(source_stem):]
    # Fallback: Original-Name behalten
    return name


def _create_tar(
    source_path: Path,
    sidecars: list[Path],
    tar_path: Path,
    target_stem: str | None = None,
) -> None:
    """Erstellt ein unkomprimiertes TAR-Archiv.

    Dateien werden ohne Verzeichnispfad gespeichert. Wenn target_stem gesetzt
    ist, wird der Stem aller Dateien ersetzt (z.B. für sauberen Namen ohne
    Filename-Suffixe wie ``poster-30s``). Mehrteilige Endungen
    (``.settings.toml``) werden dabei bewahrt.

    Keine Kompression, da Videodateien bereits komprimiert sind.
    """
    source_stem = source_path.stem
    with tarfile.open(tar_path, "w") as tf:
        for f in [source_path, *sidecars]:
            arcname = _arcname(f, source_stem, target_stem) if target_stem else f.name
            tf.add(f, arcname=arcname)


def _rclone_move(
    archive_path: Path,
    target: str,
    rclone_path: str,
) -> None:
    """Verschiebt die Archiv-Datei via rclone move zum Ziel."""
    subprocess.run(
        [rclone_path, "move", str(archive_path), target],
        check=True,
        capture_output=True,
        text=True,
    )


def archive_video(
    source_path: Path,
    archive_target: str,
    rclone_path: str = "rclone",
    recording_date: str | None = None,
    title: str | None = None,
    on_event=None,
) -> ArchiveResult:
    """Archiviert eine Videodatei als TAR und verschiebt sie zum Archiv-Ziel.

    Erstellt ein unkomprimiertes TAR-Archiv mit der Originaldatei und allen
    Sidecar-Dateien. Dateien im TAR behalten ihre Original-Dateinamen.
    Der TAR-Dateiname ist ASCII-sicher (transliteriert).

    Args:
        source_path: Pfad zur Originaldatei.
        archive_target: rclone-Ziel (z.B. nas:/archive/familienfilme/).
        rclone_path: Pfad zur rclone-Binärdatei.
        recording_date: ISO-Datum für den Archiv-Dateinamen.
        title: Titel für den Archiv-Dateinamen.
        on_event: Optionaler Event-Callback.

    Returns:
        ArchiveResult mit Erfolg/Fehler.
    """
    if not archive_target:
        return ArchiveResult(
            success=False,
            error_message="Kein Archiv-Ziel konfiguriert (targets.archive).",
        )

    if not source_path.exists():
        return ArchiveResult(
            success=False,
            error_message=f"Quelldatei nicht gefunden: {source_path}",
        )

    try:
        sidecars = _collect_sidecar_files(source_path)

        # Archiv-Dateiname aus Datum + Titel ableiten (ASCII-sicher)
        # TAR-interner Stem: Datum + Titel im Original-Stil (mit Leerzeichen, Umlauten),
        # ohne Filename-Suffixe wie "poster-30s" — Infuse-/Mensch-freundlich.
        if title and recording_date:
            slug = _to_ascii_slug(title)
            archive_name = f"{recording_date}-{slug}.tar"
            internal_stem = f"{recording_date} {title}"
        elif recording_date:
            slug = _to_ascii_slug(source_path.stem)
            archive_name = f"{recording_date}-{slug}.tar"
            internal_stem = f"{recording_date} {source_path.stem}"
        else:
            slug = _to_ascii_slug(source_path.stem)
            archive_name = f"{slug}.tar"
            internal_stem = source_path.stem

        # Fallback wenn Slug leer ist
        if not slug:
            slug = "archive"
            archive_name = f"{recording_date}-{slug}.tar" if recording_date else f"{slug}.tar"

        # TAR im gleichen Verzeichnis erstellen (temporär)
        archive_path = source_path.parent / archive_name

        _create_tar(source_path, sidecars, archive_path, target_stem=internal_stem)

        _rclone_move(archive_path, archive_target, rclone_path)

        if on_event:
            sidecar_info = f" + {len(sidecars)} Sidecar(s)" if sidecars else ""
            on_event(FamilienfilmEvent(
                stage_id=FamilienfilmStage.ARCHIVED,
                message=f"Archiviert: {archive_name}{sidecar_info} → {archive_target}",
            ))

        return ArchiveResult(success=True, archive_path=archive_path)

    except subprocess.CalledProcessError as e:
        return ArchiveResult(
            success=False,
            error_message=f"Archivierung fehlgeschlagen: {e.stderr or e}",
        )
    except Exception as e:
        return ArchiveResult(
            success=False,
            error_message=f"Archivierung fehlgeschlagen: {e}",
        )
