"""Metadaten-Extraktion aus Videodateien (QuickTime-Tags via ffprobe + Dateiname-Parsing)."""

from __future__ import annotations

import json
import re
import subprocess
from dataclasses import dataclass
from pathlib import Path


@dataclass
class VideoMetadata:
    """Extrahierte Metadaten eines Videos."""

    title: str
    recording_date: str  # ISO YYYY-MM-DD
    description: str | None = None
    category: str | None = None
    poster_at: float | None = None  # Sekunden, optional aus Filename-Suffix


# Regex für ISO-Datum am Anfang des Dateinamens
_DATE_PREFIX_RE = re.compile(r"^(\d{4}-\d{2}-\d{2})\s*[-–]?\s*(.+)$")

# Poster-Suffix am Ende des Stems (immer mit Leerzeichen davor).
# Minuten-Marker: "min" (vollständig) oder "m" (Kurzform, wie ffmpeg).
# Variante A: "N(min|m)[Nsec][sNms]"
#   " poster-2min"        → 120.0
#   " poster-2m30"        → 150.0  (Kurzform)
#   " poster-2min30"      → 150.0  (2 Min 30 Sek)
#   " poster-1min30s500"  → 90.5   (1 Min 30.5 Sek)
#   " poster-1m12s500"    → 72.5   (Kurzform mit ms)
# Variante B: "Ns[Nms]"
#   " poster-30s"         → 30.0
#   " poster-30s500"      → 30.5
_POSTER_SUFFIX_MIN_RE = re.compile(
    r"\s+poster-(\d+)(?:min|m)(?:(\d+))?(?:s(\d{1,3}))?$"
)
_POSTER_SUFFIX_S_RE = re.compile(
    r"\s+poster-(\d+)s(\d{1,3})?$"
)


def _parse_poster_suffix(stem: str) -> tuple[str, float | None]:
    """Parst optionales Poster-Suffix am Ende des Stems.

    Beispiele:
        "HDR-Test poster-3min12"     → ("HDR-Test", 192.0)
        "HDR-Test poster-1min30s500" → ("HDR-Test", 90.5)
        "HDR-Test poster-2min"       → ("HDR-Test", 120.0)
        "HDR-Test poster-30s"        → ("HDR-Test", 30.0)
        "HDR-Test poster-30s500"     → ("HDR-Test", 30.5)
        "HDR-Test"                   → ("HDR-Test", None)

    Returns:
        Tuple aus (stem_ohne_suffix, poster_at_sekunden_oder_none).
    """
    # Variante A: Nmin[Nsec][sNms]
    match = _POSTER_SUFFIX_MIN_RE.search(stem)
    if match:
        minutes = int(match.group(1))
        seconds = int(match.group(2)) if match.group(2) else 0
        ms = int(match.group(3)) if match.group(3) else 0
        total = minutes * 60 + seconds + ms / 1000.0
        return stem[: match.start()], total

    # Variante B: Ns[Nms]
    match = _POSTER_SUFFIX_S_RE.search(stem)
    if match:
        seconds = int(match.group(1))
        ms = int(match.group(2)) if match.group(2) else 0
        total = seconds + ms / 1000.0
        return stem[: match.start()], total

    return stem, None


def _probe_tags(video_path: Path, ffprobe_path: str) -> dict[str, str]:
    """Liest format-Tags via ffprobe aus."""
    try:
        result = subprocess.run(
            [
                ffprobe_path,
                "-v", "quiet",
                "-print_format", "json",
                "-show_format",
                video_path,
            ],
            capture_output=True,
            text=True,
            timeout=30,
        )
        if result.returncode != 0:
            return {}
        data = json.loads(result.stdout)
        return data.get("format", {}).get("tags", {})
    except (subprocess.TimeoutExpired, json.JSONDecodeError, FileNotFoundError):
        return {}


def _extract_quicktime_date(tags: dict[str, str]) -> str | None:
    """Extrahiert das Aufnahmedatum aus dem QuickTime-Tag (Final Cut Pro)."""
    value = tags.get("com.apple.quicktime.creationdate")
    if value:
        match = re.match(r"(\d{4}-\d{2}-\d{2})", value)
        if match:
            return match.group(1)
    return None


def _extract_fallback_date(tags: dict[str, str]) -> str | None:
    """Extrahiert ein Datum aus generischen Tags (creation_time, date).

    Diese Tags enthalten oft das Datei-Änderungsdatum, nicht das Aufnahmedatum.
    Deshalb haben sie niedrigere Priorität als der Dateiname.
    """
    for key in ("creation_time", "date"):
        value = tags.get(key)
        if value:
            match = re.match(r"(\d{4}-\d{2}-\d{2})", value)
            if match:
                return match.group(1)
    return None


def _extract_title_from_tags(tags: dict[str, str]) -> str | None:
    """Extrahiert den Titel aus QuickTime/ffprobe-Tags."""
    for key in ("com.apple.quicktime.title", "title"):
        value = tags.get(key)
        if value and value.strip():
            return value.strip()
    return None


def _extract_description_from_tags(tags: dict[str, str]) -> str | None:
    """Extrahiert die Beschreibung aus QuickTime/ffprobe-Tags."""
    for key in ("com.apple.quicktime.description", "description", "comment"):
        value = tags.get(key)
        if value and value.strip():
            return value.strip()
    return None


def _parse_filename(stem: str) -> tuple[str | None, str, float | None]:
    """Parst Datum, Titel und optionales Poster-Suffix aus dem Dateinamen.

    Reihenfolge: Erst Poster-Suffix abschneiden, dann Datum extrahieren.
    Damit landet das Poster-Suffix nicht im Titel.

    Returns:
        Tuple von (datum_oder_none, titel, poster_at_sekunden_oder_none).
    """
    # Zuerst Poster-Suffix abschneiden (am Ende)
    cleaned_stem, poster_at = _parse_poster_suffix(stem)

    # Dann Datum vom Anfang abtrennen
    match = _DATE_PREFIX_RE.match(cleaned_stem)
    if match:
        return match.group(1), match.group(2).strip(), poster_at
    return None, cleaned_stem, poster_at


def extract_metadata(
    video_path: Path,
    ffprobe_path: str = "ffprobe",
) -> VideoMetadata:
    """Extrahiert Metadaten aus einer Videodatei.

    Priorität:
    1. QuickTime-Tags via ffprobe
    2. Dateiname-Parsing (Datum + Titel)

    Raises:
        ValueError: Wenn kein Aufnahmedatum ermittelt werden kann.
    """
    tags = _probe_tags(video_path, ffprobe_path)

    # Datum-Priorität:
    # 1. com.apple.quicktime.creationdate (bewusst in Final Cut Pro gesetzt)
    # 2. Dateiname (z.B. "2019-12-22 Twannbachschlucht.mov")
    # 3. creation_time / date (generische Tags, oft Datei-Änderungsdatum)
    filename_date, filename_title, filename_poster_at = _parse_filename(video_path.stem)

    quicktime_date = _extract_quicktime_date(tags)
    fallback_date = _extract_fallback_date(tags)

    recording_date = quicktime_date or filename_date or fallback_date

    if recording_date is None:
        raise ValueError(
            f"Kein Aufnahmedatum gefunden für '{video_path.name}'. "
            "Bitte Datum via --date angeben oder im Dateinamen verwenden (YYYY-MM-DD)."
        )

    # Titel: Tags > Dateiname
    title = _extract_title_from_tags(tags) or filename_title

    # Beschreibung: nur aus Tags
    description = _extract_description_from_tags(tags)

    return VideoMetadata(
        title=title,
        recording_date=recording_date,
        description=description,
        poster_at=filename_poster_at,
    )
