"""Sidecar-Manager: Lesen/Schreiben von Settings-Dateien neben dem Video."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import tomllib


@dataclass
class SidecarSettings:
    """Persistierte Einstellungen in einer .settings.toml Datei neben dem Video."""

    frame_number: int | None = None
    timestamp_seconds: float | None = None
    crop_position: str | None = None
    web_id: str | None = None
    max_luminance: int | None = None
    published_at: str | None = None  # ISO 8601 Timestamp der letzten erfolgreichen Publikation

    def has_values(self) -> bool:
        """Prüft ob mindestens ein Wert gesetzt ist."""
        return any(v is not None for v in (
            self.frame_number, self.timestamp_seconds, self.crop_position,
            self.web_id, self.max_luminance, self.published_at,
        ))


def sidecar_path_for(video_path: Path) -> Path:
    """Gibt den Pfad zur Sidecar-Datei zurück."""
    return video_path.parent / f"{video_path.stem}.settings.toml"


def read_sidecar(video_path: Path) -> SidecarSettings:
    """Liest die Sidecar-Datei. Gibt leeres SidecarSettings zurück wenn nicht vorhanden."""
    path = sidecar_path_for(video_path)
    if not path.exists():
        return SidecarSettings()

    try:
        data = tomllib.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return SidecarSettings()

    poster = data.get("poster", {})
    if not isinstance(poster, dict):
        poster = {}

    frame = poster.get("frame_number")
    timestamp = poster.get("timestamp_seconds")
    crop = poster.get("crop_position")

    web = data.get("web", {})
    if not isinstance(web, dict):
        web = {}

    web_id = web.get("web_id")
    max_luminance = web.get("max_luminance")
    published_at = web.get("published_at")

    return SidecarSettings(
        frame_number=int(frame) if frame is not None else None,
        timestamp_seconds=float(timestamp) if timestamp is not None else None,
        crop_position=str(crop) if crop is not None else None,
        web_id=str(web_id) if web_id is not None else None,
        max_luminance=int(max_luminance) if max_luminance is not None else None,
        published_at=str(published_at) if published_at is not None else None,
    )


def write_sidecar(video_path: Path, settings: SidecarSettings) -> Path:
    """Schreibt die Sidecar-Datei. Nur gesetzte Felder werden geschrieben.

    Returns:
        Pfad zur geschriebenen Datei.
    """
    path = sidecar_path_for(video_path)
    lines: list[str] = []

    # [poster] Sektion
    poster_lines: list[str] = []
    if settings.frame_number is not None:
        poster_lines.append(f"frame_number = {settings.frame_number}")
    if settings.timestamp_seconds is not None:
        poster_lines.append(f"timestamp_seconds = {settings.timestamp_seconds}")
    if settings.crop_position is not None:
        poster_lines.append(f'crop_position = "{settings.crop_position}"')
    if poster_lines:
        lines.append("[poster]")
        lines.extend(poster_lines)

    # [web] Sektion
    web_lines: list[str] = []
    if settings.web_id is not None:
        web_lines.append(f'web_id = "{settings.web_id}"')
    if settings.max_luminance is not None:
        web_lines.append(f"max_luminance = {settings.max_luminance}")
    if settings.published_at is not None:
        web_lines.append(f'published_at = "{settings.published_at}"')
    if web_lines:
        if lines:
            lines.append("")
        lines.append("[web]")
        lines.extend(web_lines)

    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return path
