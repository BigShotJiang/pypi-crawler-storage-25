"""Verzeichnis-Publisher: Publiziert alle qualifizierten Videos in einem Verzeichnis sequenziell."""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path

from familienfilm_manager.api.models import (
    DirectoryPublishResult,
    FamilienfilmEvent,
    FamilienfilmStage,
    PublishRequest,
    PublishResult,
    RuntimeOptions,
    VideoStatus,
    VideoStatusKind,
)
from familienfilm_manager.core.metadata_extractor import _DATE_PREFIX_RE
from familienfilm_manager.core.publisher import run_publish
from familienfilm_manager.core.sidecar_manager import (
    read_sidecar,
    sidecar_path_for,
)


# Unterstützte Video-Endungen (lowercase Vergleich)
_VIDEO_EXTENSIONS: frozenset[str] = frozenset({
    ".mov", ".mp4", ".m4v", ".mkv",
})


def _is_qualified_video(path: Path) -> bool:
    """Prüft ob die Datei eine qualifizierte Videodatei ist.

    Kriterien:
    - Reguläre Datei (kein Symlink-Verzeichnis, keine Hidden-Datei)
    - Bekannte Video-Endung
    - Stem matcht das Muster ``<YYYY-MM-DD> <titel>``
    """
    if not path.is_file() or path.name.startswith("."):
        return False
    if path.suffix.lower() not in _VIDEO_EXTENSIONS:
        return False
    return bool(_DATE_PREFIX_RE.match(path.stem))


def _date_from_filename(path: Path) -> str:
    """Extrahiert das Datum aus dem Dateinamen (für Sortierung).

    Setzt voraus, dass der Stem das Datum-Präfix-Muster erfüllt.
    """
    match = _DATE_PREFIX_RE.match(path.stem)
    return match.group(1) if match else "0000-00-00"


def _is_already_published(video_path: Path) -> tuple[bool, str | None]:
    """Prüft ob das Video bereits publiziert wurde und seitdem unverändert ist.

    Skip-Bedingung: Sidecar mit ``published_at`` vorhanden UND
    weder Video noch Sidecar wurden seit dem Zeitstempel geändert.

    Returns:
        Tuple aus (skip_möglich, published_at_string_oder_none).
    """
    sidecar = read_sidecar(video_path)
    if not sidecar.published_at:
        return False, None

    try:
        published_at_dt = datetime.fromisoformat(sidecar.published_at)
    except ValueError:
        return False, sidecar.published_at

    published_ts = published_at_dt.timestamp()

    # Video-mtime prüfen
    if video_path.stat().st_mtime > published_ts:
        return False, sidecar.published_at

    # Sidecar-mtime prüfen (Anpassungen am Sidecar = Republish-Trigger)
    sidecar_path = sidecar_path_for(video_path)
    if sidecar_path.exists() and sidecar_path.stat().st_mtime > published_ts:
        return False, sidecar.published_at

    return True, sidecar.published_at


def _scan_directory(directory: Path) -> list[Path]:
    """Sammelt alle qualifizierten Videos im Verzeichnis (nicht rekursiv).

    Sortiert chronologisch nach Datum im Dateinamen, älteste zuerst.
    """
    candidates = [p for p in directory.iterdir() if _is_qualified_video(p)]
    candidates.sort(key=lambda p: (_date_from_filename(p), p.name.lower()))
    return candidates


def run_publish_directory(
    directory: Path,
    runtime: RuntimeOptions | None = None,
    on_event: Callable[[FamilienfilmEvent], None] | None = None,
    skip_infuse: bool = False,
    skip_web: bool = False,
    skip_archive: bool = False,
    force: bool = False,
    dry_run: bool = False,
    work_dir: Path | None = None,
) -> DirectoryPublishResult:
    """Publiziert alle qualifizierten Videos in einem Verzeichnis sequenziell.

    Sortierung: chronologisch nach Datum im Dateinamen (älteste zuerst).
    Filter: Nur Dateien mit Muster ``<YYYY-MM-DD> <titel>.<ext>`` und
    bekannten Video-Endungen.

    Idempotenz: Videos mit Sidecar-``published_at`` werden übersprungen,
    sofern weder Video noch Sidecar seither geändert wurden. Mit
    ``force=True`` werden alle Videos neu publiziert.

    Args:
        directory: Verzeichnis mit Quell-Videos.
        runtime: Technische Laufzeitoptionen.
        on_event: Optionaler Event-Callback (durchgereicht an run_publish).
        skip_infuse/skip_web/skip_archive: Profil-Schalter.
        force: Auch bereits publizierte Videos neu publizieren.
        dry_run: Nur anzeigen welche Videos publiziert würden, nicht ausführen.
        work_dir: Arbeitsverzeichnis für temporäre Dateien (gilt für alle Videos).
            Standard: Verzeichnis des jeweiligen Quellvideos.

    Returns:
        DirectoryPublishResult mit Liste aller Videos und deren Status.
    """
    result = DirectoryPublishResult(success=True, directory=directory)

    if not directory.is_dir():
        result.success = False
        result.error_message = f"Verzeichnis nicht gefunden: {directory}"
        return result

    # Pre-Validation: aktive Profile brauchen konfigurierte Targets
    rt = runtime or RuntimeOptions()
    missing_targets: list[str] = []
    if not skip_infuse and not rt.infuse_target:
        missing_targets.append("targets.infuse (oder --no-infuse zum Überspringen)")
    if not skip_web and not rt.web_target:
        missing_targets.append("targets.web (oder --no-web zum Überspringen)")
    if not skip_archive and not rt.archive_target:
        missing_targets.append("targets.archive (oder --no-archive zum Überspringen)")
    if missing_targets:
        result.success = False
        result.error_message = (
            "Konfigurations-Fehler: Folgende Targets sind nicht konfiguriert: "
            + ", ".join(missing_targets)
        )
        return result

    candidates = _scan_directory(directory)
    if not candidates:
        return result

    # Klassifizieren: was wird publiziert, was übersprungen
    to_publish: list[Path] = []
    for video_path in candidates:
        if force:
            to_publish.append(video_path)
            continue
        skip, published_at = _is_already_published(video_path)
        if skip:
            result.videos.append(VideoStatus(
                path=video_path,
                kind=VideoStatusKind.SKIPPED,
                published_at=published_at,
            ))
        else:
            to_publish.append(video_path)

    skipped_count = len(result.videos)
    pending_count = len(to_publish)

    if on_event:
        on_event(FamilienfilmEvent(
            stage_id=FamilienfilmStage.DIRECTORY_SCANNED,
            message=f"{len(candidates)} qualifizierte Videos: {skipped_count} übersprungen, {pending_count} zu publizieren",
        ))

    # Dry-Run: pending Videos nur als PENDING markieren
    if dry_run:
        for video_path in to_publish:
            result.videos.append(VideoStatus(path=video_path, kind=VideoStatusKind.PENDING))
        return result

    # Sequenziell publizieren
    for index, video_path in enumerate(to_publish, start=1):
        if on_event:
            on_event(FamilienfilmEvent(
                stage_id=FamilienfilmStage.DIRECTORY_VIDEO_STARTED,
                message=f"[{index}/{pending_count}] Publiziere: {video_path.name}",
            ))

        publish_request = PublishRequest(
            source_path=video_path,
            skip_infuse=skip_infuse,
            skip_web=skip_web,
            skip_archive=skip_archive,
            force=force,
            work_dir=work_dir,
        )
        publish_result: PublishResult
        try:
            publish_result = run_publish(publish_request, runtime, on_event=on_event)
        except Exception as e:
            publish_result = PublishResult(success=False, error_message=str(e))

        if publish_result.success:
            result.videos.append(VideoStatus(
                path=video_path,
                kind=VideoStatusKind.PUBLISHED,
                publish_result=publish_result,
            ))
        else:
            result.videos.append(VideoStatus(
                path=video_path,
                kind=VideoStatusKind.FAILED,
                error_message=publish_result.error_message,
            ))

    # Gesamtergebnis: success=False wenn mindestens ein Video fehlschlug
    if any(v.kind == VideoStatusKind.FAILED for v in result.videos):
        result.success = False

    return result
