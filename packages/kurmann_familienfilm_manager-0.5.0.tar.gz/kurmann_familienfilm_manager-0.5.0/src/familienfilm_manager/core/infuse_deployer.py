"""Infuse-Deployment: Dateien via rclone zum Medienserver kopieren."""

from __future__ import annotations

import subprocess
from pathlib import Path

from familienfilm_manager.api.models import (
    DeployResult,
    FamilienfilmEvent,
    FamilienfilmStage,
)


def _build_target_subdir(
    target: str,
    recording_date: str,
    group_by: str,
) -> str:
    """Baut den Zielpfad mit Jahr/Monat-Struktur.

    Args:
        target: rclone-Basisziel (z.B. nas:/media/videos/).
        recording_date: ISO-Datum (YYYY-MM-DD).
        group_by: "year" oder "month".

    Returns:
        Zielpfad (z.B. nas:/media/videos/2024/ oder nas:/media/videos/2024/2024-07/).
    """
    target = target.rstrip("/")
    year = recording_date[:4]
    if group_by == "month":
        month = recording_date[:7]  # YYYY-MM
        return f"{target}/{year}/{month}"
    return f"{target}/{year}"


def deploy_to_infuse(
    source_dir: Path,
    infuse_target: str,
    rclone_path: str = "rclone",
    recording_date: str | None = None,
    group_by: str = "year",
    on_event=None,
) -> DeployResult:
    """Kopiert Infuse-Dateien via rclone zum Medienserver.

    Der mediaset-creator v2 schreibt Infuse-Dateien direkt mit korrekten
    Dateinamen in das Quellverzeichnis. Kein ZIP-Entpacken mehr nötig.

    Args:
        source_dir: Verzeichnis mit den Infuse-Dateien.
        infuse_target: rclone-Ziel für Infuse.
        rclone_path: Pfad zur rclone-Binärdatei.
        recording_date: ISO-Datum für Zielstruktur.
        group_by: Gruppierung "year" oder "month".
        on_event: Optionaler Event-Callback.

    Returns:
        DeployResult mit Erfolg/Fehler.
    """
    if not infuse_target:
        return DeployResult(
            success=False,
            error_message="Kein Infuse-Ziel konfiguriert (targets.infuse).",
        )

    if not source_dir.exists():
        return DeployResult(
            success=False,
            error_message=f"Quellverzeichnis nicht gefunden: {source_dir}",
        )

    try:
        if recording_date:
            target_dir = _build_target_subdir(infuse_target, recording_date, group_by)
        else:
            target_dir = infuse_target.rstrip("/")

        subprocess.run(
            [rclone_path, "copy", str(source_dir), target_dir],
            check=True,
            capture_output=True,
            text=True,
        )

        if on_event:
            on_event(FamilienfilmEvent(
                stage_id=FamilienfilmStage.INFUSE_DEPLOYED,
                message=f"Infuse-Deployment: {source_dir.name} → {target_dir}",
            ))

        return DeployResult(success=True, target_path=target_dir)

    except subprocess.CalledProcessError as e:
        return DeployResult(
            success=False,
            error_message=f"Infuse-Deployment fehlgeschlagen: {e.stderr or e}",
        )
    except Exception as e:
        return DeployResult(
            success=False,
            error_message=f"Infuse-Deployment fehlgeschlagen: {e}",
        )
