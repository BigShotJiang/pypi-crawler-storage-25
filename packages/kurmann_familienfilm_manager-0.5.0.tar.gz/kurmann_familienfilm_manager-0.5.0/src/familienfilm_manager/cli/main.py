"""CLI-Adapter für den Familienfilm Manager."""

import sys
from pathlib import Path
from typing import Optional

import typer
from rich.console import Console

from familienfilm_manager.api import (
    ArchiveRequest,
    DeployRequest,
    FamilienfilmEvent,
    FamilienfilmStage,
    PublishRequest,
    RuntimeOptions,
    VideoStatusKind,
    archive,
    deploy_infuse,
    deploy_web,
    publish,
    publish_directory,
)
from familienfilm_manager.services import config_manager

app = typer.Typer(invoke_without_command=True)
config_app = typer.Typer()
app.add_typer(config_app, name="config", help="Konfiguration verwalten.")

stderr_console = Console(stderr=True)


def _build_runtime() -> RuntimeOptions:
    """Baut RuntimeOptions aus der Konfiguration."""
    return RuntimeOptions(
        infuse_target=config_manager.get_with_default("targets.infuse"),
        web_target=config_manager.get_with_default("targets.web"),
        archive_target=config_manager.get_with_default("targets.archive"),
        infuse_group_by=config_manager.get_with_default("infuse.group_by"),
        branding_base_url=config_manager.get_with_default("mediaset.branding_base_url"),
        branding_site_name=config_manager.get_with_default("mediaset.branding_site_name"),
        ffmpeg_path=config_manager.get_with_default("tools.ffmpeg"),
        ffprobe_path=config_manager.get_with_default("tools.ffprobe"),
        rclone_path=config_manager.get_with_default("tools.rclone"),
    )


def _resolve_work_dir(cli_work_dir: Optional[Path]) -> Optional[Path]:
    """Auflösung des Arbeitsverzeichnisses: CLI > Config > None.

    None bedeutet: Publisher fällt auf Quellverzeichnis zurück.
    """
    if cli_work_dir is not None:
        return cli_work_dir
    config_value = config_manager.get("paths.work_dir")
    if config_value:
        return Path(config_value).expanduser()
    return None


def _make_event_callback(verbose: bool):
    """Erstellt einen Event-Callback für die CLI."""
    ALWAYS_SHOW = {
        FamilienfilmStage.MEDIASET_CREATED,
        FamilienfilmStage.INFUSE_DEPLOYED,
        FamilienfilmStage.WEB_DEPLOYED,
        FamilienfilmStage.ARCHIVED,
        FamilienfilmStage.PUBLISH_COMPLETED,
        FamilienfilmStage.DIRECTORY_SCANNED,
        FamilienfilmStage.DIRECTORY_VIDEO_STARTED,
    }

    def on_event(event: FamilienfilmEvent) -> None:
        if not verbose and event.stage_id not in ALWAYS_SHOW:
            return
        stderr_console.print(f"  {event.message}")

    return on_event


@app.callback()
def main(ctx: typer.Context) -> None:
    """Familienfilm Manager – Veröffentlichung von Familienfilmen."""
    if ctx.invoked_subcommand is None:
        ctx.get_help()


# ---------------------------------------------------------------------------
# publish – Gesamtworkflow
# ---------------------------------------------------------------------------

@app.command(name="publish")
def publish_cmd(
    video: Path = typer.Argument(
        ...,
        help="Pfad zur Videodatei.",
        exists=True,
        dir_okay=False,
    ),
    title: Optional[str] = typer.Option(
        None,
        "--title",
        help="Video-Titel (überschreibt Metadaten).",
    ),
    description: Optional[str] = typer.Option(
        None,
        "--description",
        help="Beschreibung des Videos.",
    ),
    category: Optional[str] = typer.Option(
        None,
        "--category",
        help="Kategorie (z.B. 'Familie Kurmann-Glück').",
    ),
    date: Optional[str] = typer.Option(
        None,
        "--date",
        help="Aufnahmedatum im ISO-Format (YYYY-MM-DD).",
    ),
    output_dir: Optional[Path] = typer.Option(
        None,
        "--output-dir",
        help="Basisverzeichnis für die Web-Medienset-Ausgabe.",
    ),
    work_dir: Optional[Path] = typer.Option(
        None,
        "--work-dir",
        help="Arbeitsverzeichnis für temporäre Dateien (Standard: Verzeichnis der Quelldatei).",
    ),
    no_infuse: bool = typer.Option(
        False,
        "--no-infuse",
        help="Infuse-Deployment überspringen.",
    ),
    no_web: bool = typer.Option(
        False,
        "--no-web",
        help="Web-Deployment überspringen.",
    ),
    no_archive: bool = typer.Option(
        False,
        "--no-archive",
        help="Archivierung überspringen.",
    ),
    poster_frame: Optional[int] = typer.Option(
        None,
        "--poster-frame",
        help="Frame-Nummer für Vorschaubild (überspringt KI-Auswahl).",
    ),
    poster_at: Optional[float] = typer.Option(
        None,
        "--poster-at",
        help="Zeitpunkt in Sekunden für Vorschaubild (z.B. 90 oder 1.5).",
    ),
    poster_crop: Optional[str] = typer.Option(
        None,
        "--poster-crop",
        help="Bildausschnitt für Poster (left/center-left/center/center-right/right).",
    ),
    web_id: Optional[str] = typer.Option(
        None,
        "--web-id",
        help="Web-ID für Web-Medienset (12 Zeichen, a-z 0-9; überschreibt Sidecar-Wert).",
    ),
    max_luminance: Optional[int] = typer.Option(
        None,
        "--max-luminance",
        help="Peak-Leuchtdichte in nits (MaxCLL) für HDR-Metadaten im Web-Video. Default: 1000. Wird im Sidecar gespeichert.",
    ),
    no_sidecar: bool = typer.Option(
        False,
        "--no-sidecar",
        help="Sidecar-Datei (.settings.toml) nicht lesen/schreiben.",
    ),
    force: bool = typer.Option(
        False,
        "--force",
        help="Neuerstellung erzwingen.",
    ),
    verbose: bool = typer.Option(
        False,
        "--verbose",
        "-v",
        help="Zusätzliche Ablaufinformationen auf stderr ausgeben.",
    ),
) -> None:
    """Veröffentlicht ein Video: Medienset erstellen, Infuse/Web deployen, archivieren."""
    # Kategorie: CLI > Config-Default
    effective_category = category
    if effective_category is None:
        default_cat = config_manager.get("defaults.category")
        if default_cat:
            effective_category = default_cat

    request = PublishRequest(
        source_path=video,
        title=title,
        description=description,
        category=effective_category,
        recording_date=date,
        output_dir=output_dir,
        work_dir=_resolve_work_dir(work_dir),
        force=force,
        skip_infuse=no_infuse,
        skip_web=no_web,
        skip_archive=no_archive,
        poster_frame=poster_frame,
        poster_at=poster_at,
        poster_crop=poster_crop,
        web_id=web_id,
        max_luminance=max_luminance,
        no_sidecar=no_sidecar,
    )

    runtime = _build_runtime()
    result = publish(request, runtime, on_event=_make_event_callback(verbose))

    if not result.success:
        stderr_console.print(f"[red]Fehler:[/red] {result.error_message}")
        raise typer.Exit(code=1)

    # Stdout: Web-URL (wenn verfügbar) > web_dir (lokal, wenn nicht aufgeräumt) > infuse_dir
    print(result.web_url or result.web_dir or result.infuse_dir)


# ---------------------------------------------------------------------------
# publish-dir – Batch-Workflow für ganzes Verzeichnis
# ---------------------------------------------------------------------------

@app.command(name="publish-dir")
def publish_dir_cmd(
    directory: Path = typer.Argument(
        ...,
        help="Verzeichnis mit Quell-Videos.",
        exists=True,
        file_okay=False,
        dir_okay=True,
    ),
    no_infuse: bool = typer.Option(
        False,
        "--no-infuse",
        help="Infuse-Deployment für alle Videos überspringen.",
    ),
    no_web: bool = typer.Option(
        False,
        "--no-web",
        help="Web-Deployment für alle Videos überspringen.",
    ),
    no_archive: bool = typer.Option(
        False,
        "--no-archive",
        help="Archivierung für alle Videos überspringen.",
    ),
    force: bool = typer.Option(
        False,
        "--force",
        help="Auch bereits publizierte Videos neu publizieren.",
    ),
    dry_run: bool = typer.Option(
        False,
        "--dry-run",
        help="Nur anzeigen welche Videos publiziert würden, ohne zu publizieren.",
    ),
    work_dir: Optional[Path] = typer.Option(
        None,
        "--work-dir",
        help="Arbeitsverzeichnis für temporäre Dateien (Standard: paths.work_dir aus Config oder Quellverzeichnis). Lokaler SSD bei SMB-Quellen empfohlen.",
    ),
    verbose: bool = typer.Option(
        False,
        "--verbose",
        "-v",
        help="Zusätzliche Ablaufinformationen pro Video auf stderr ausgeben.",
    ),
) -> None:
    """Publiziert alle qualifizierten Videos im Verzeichnis sequenziell (älteste zuerst).

    Filtert nach Muster `<YYYY-MM-DD> <titel>.<ext>` (mov/mp4/m4v/mkv).
    Überspringt bereits publizierte Videos (Sidecar `published_at`),
    sofern weder Video noch Sidecar seither geändert wurden.
    """
    runtime = _build_runtime()
    result = publish_directory(
        directory=directory,
        runtime=runtime,
        on_event=_make_event_callback(verbose),
        skip_infuse=no_infuse,
        skip_web=no_web,
        skip_archive=no_archive,
        force=force,
        dry_run=dry_run,
        work_dir=_resolve_work_dir(work_dir),
    )

    if result.error_message:
        stderr_console.print(f"[red]Fehler:[/red] {result.error_message}")
        raise typer.Exit(code=1)

    # Dry-Run Übersicht
    if dry_run:
        if result.pending_count == 0:
            stderr_console.print("Keine Videos zu publizieren (alle aktuell).")
        else:
            stderr_console.print(f"Würde {result.pending_count} Videos publizieren:")
            for v in result.videos:
                if v.kind == VideoStatusKind.PENDING:
                    print(v.path)
        return

    # Zusammenfassung
    summary_parts = [f"{result.published_count} publiziert"]
    if result.skipped_count:
        summary_parts.append(f"{result.skipped_count} übersprungen")
    if result.failed_count:
        summary_parts.append(f"[red]{result.failed_count} fehlgeschlagen[/red]")
    stderr_console.print(f"  Verzeichnis-Publikation abgeschlossen: {', '.join(summary_parts)}")

    # Fehlgeschlagene Videos detailliert auflisten
    if result.failed_count:
        stderr_console.print("\n[red]Fehlgeschlagene Videos:[/red]")
        for v in result.videos:
            if v.kind == VideoStatusKind.FAILED:
                stderr_console.print(f"  [red]✗[/red] {v.path.name}: {v.error_message}")

    # Stdout: URLs aller erfolgreich publizierten Videos
    for v in result.videos:
        if v.kind == VideoStatusKind.PUBLISHED and v.publish_result:
            url = v.publish_result.web_url or v.publish_result.web_dir or v.publish_result.infuse_dir
            if url:
                print(url)

    if result.failed_count:
        raise typer.Exit(code=1)


# ---------------------------------------------------------------------------
# deploy-infuse – Einzeloperation
# ---------------------------------------------------------------------------

@app.command(name="deploy-infuse")
def deploy_infuse_cmd(
    source_dir: Path = typer.Argument(
        ...,
        help="Pfad zum Verzeichnis mit Infuse-Dateien.",
        exists=True,
        file_okay=False,
    ),
    verbose: bool = typer.Option(False, "--verbose", "-v"),
) -> None:
    """Deployt ein Verzeichnis mit Infuse-Dateien via rclone."""
    runtime = _build_runtime()
    result = deploy_infuse(
        DeployRequest(source_dir=source_dir),
        runtime,
        on_event=_make_event_callback(verbose),
    )

    if not result.success:
        stderr_console.print(f"[red]Fehler:[/red] {result.error_message}")
        raise typer.Exit(code=1)

    if result.target_path:
        print(result.target_path)


# ---------------------------------------------------------------------------
# deploy-web – Einzeloperation
# ---------------------------------------------------------------------------

@app.command(name="deploy-web")
def deploy_web_cmd(
    source_dir: Path = typer.Argument(
        ...,
        help="Pfad zum Web-Medienset-Verzeichnis (Web-ID).",
        exists=True,
        file_okay=False,
    ),
    verbose: bool = typer.Option(False, "--verbose", "-v"),
) -> None:
    """Deployt ein Web-Medienset-Verzeichnis zum Webserver (via rclone)."""
    runtime = _build_runtime()
    result = deploy_web(
        DeployRequest(source_dir=source_dir),
        runtime,
        on_event=_make_event_callback(verbose),
    )

    if not result.success:
        stderr_console.print(f"[red]Fehler:[/red] {result.error_message}")
        raise typer.Exit(code=1)

    if result.target_path:
        print(result.target_path)


# ---------------------------------------------------------------------------
# archive – Einzeloperation
# ---------------------------------------------------------------------------

@app.command(name="archive")
def archive_cmd(
    video: Path = typer.Argument(
        ...,
        help="Pfad zur Original-Videodatei.",
        exists=True,
        dir_okay=False,
    ),
    title: Optional[str] = typer.Option(
        None,
        "--title",
        help="Titel für ISO-Dateiname und Volume-Name.",
    ),
    date: Optional[str] = typer.Option(
        None,
        "--date",
        help="Aufnahmedatum (YYYY-MM-DD) für ISO-Dateiname.",
    ),
    verbose: bool = typer.Option(False, "--verbose", "-v"),
) -> None:
    """Archiviert eine Videodatei als ISO und verschiebt sie zum Archiv-Ziel."""
    runtime = _build_runtime()
    result = archive(
        ArchiveRequest(source_path=video, recording_date=date, title=title),
        runtime,
        on_event=_make_event_callback(verbose),
    )

    if not result.success:
        stderr_console.print(f"[red]Fehler:[/red] {result.error_message}")
        raise typer.Exit(code=1)

    if result.archive_path:
        print(result.archive_path)


# ---------------------------------------------------------------------------
# config – Subcommands
# ---------------------------------------------------------------------------

@config_app.command(name="set")
def config_set_cmd(
    key: str = typer.Argument(..., help="Konfigurationsschlüssel (z.B. 'targets.infuse')."),
    value: str = typer.Argument(..., help="Wert."),
) -> None:
    """Speichert einen Konfigurationswert."""
    if not config_manager.set_value(key, value):
        stderr_console.print(f"[red]Fehler:[/red] Unbekannter Schlüssel '{key}'.")
        stderr_console.print("Erlaubte Schlüssel:")
        for k, (desc, default) in config_manager.ALLOWED_KEYS.items():
            stderr_console.print(f"  {k}: {desc} (Standard: {default or '(leer)'})")
        raise typer.Exit(code=2)
    stderr_console.print(f"Gespeichert: {key} = {value}")


@config_app.command(name="get")
def config_get_cmd(
    key: str = typer.Argument(..., help="Konfigurationsschlüssel."),
) -> None:
    """Liest einen Konfigurationswert."""
    if key not in config_manager.ALLOWED_KEYS:
        stderr_console.print(f"[red]Fehler:[/red] Unbekannter Schlüssel '{key}'.")
        raise typer.Exit(code=2)
    val = config_manager.get(key)
    if val is None:
        desc, default = config_manager.ALLOWED_KEYS[key]
        stderr_console.print(f"(nicht gesetzt, Standard: {default or '(leer)'})")
    else:
        print(val)


@config_app.command(name="list")
def config_list_cmd() -> None:
    """Zeigt alle konfigurierten Werte an."""
    stored = config_manager.list_all()
    if not stored:
        stderr_console.print("Keine Konfigurationswerte gespeichert.")
        stderr_console.print(f"Konfigurationsdatei: {config_manager.CONFIG_PATH}")
        return
    for key, val in sorted(stored.items()):
        print(f"{key} = {val}")
