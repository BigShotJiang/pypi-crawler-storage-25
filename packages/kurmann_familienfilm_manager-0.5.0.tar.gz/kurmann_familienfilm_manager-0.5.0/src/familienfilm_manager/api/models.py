"""Datenmodelle für die öffentliche API."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import StrEnum
from pathlib import Path
from typing import Callable


# ---------------------------------------------------------------------------
# Event-System
# ---------------------------------------------------------------------------

class FamilienfilmStage(StrEnum):
    """Stabile Stage-IDs für Fortschritts-Events."""

    METADATA_EXTRACTED = "metadata_extracted"
    MEDIASET_CREATED = "mediaset_created"
    INFUSE_DEPLOYED = "infuse_deployed"
    WEB_DEPLOYED = "web_deployed"
    ARCHIVED = "archived"
    PUBLISH_COMPLETED = "publish_completed"
    DIRECTORY_SCANNED = "directory_scanned"
    DIRECTORY_VIDEO_STARTED = "directory_video_started"


@dataclass
class FamilienfilmEvent:
    """Strukturiertes Fortschritts-Event."""

    stage_id: str
    message: str
    paths: dict[str, Path] | None = None


# Typ-Alias für Event-Callback
EventCallback = Callable[[FamilienfilmEvent], None] | None


# ---------------------------------------------------------------------------
# Runtime-Optionen (technisch, getrennt vom fachlichen Request)
# ---------------------------------------------------------------------------

@dataclass
class RuntimeOptions:
    """Technische Laufzeitoptionen, typischerweise aus der Konfiguration geladen."""

    infuse_target: str = ""
    web_target: str = ""
    archive_target: str = ""
    infuse_group_by: str = "year"  # "year" oder "month"
    branding_base_url: str = ""    # Stamm-URL für Web-Mediasets und OG-Tags
    branding_site_name: str = ""   # Site-Name (sichtbar im Header + OG-Meta)
    ffmpeg_path: str = "ffmpeg"
    ffprobe_path: str = "ffprobe"
    rclone_path: str = "rclone"


# ---------------------------------------------------------------------------
# Publish (Gesamtworkflow)
# ---------------------------------------------------------------------------

@dataclass
class PublishRequest:
    """Fachlicher Request für den gesamten Veröffentlichungs-Workflow."""

    source_path: Path
    title: str | None = None
    description: str | None = None
    category: str | None = None
    recording_date: str | None = None  # ISO YYYY-MM-DD
    output_dir: Path | None = None
    work_dir: Path | None = None           # Arbeitsverzeichnis für temporäre Dateien
    force: bool = False
    skip_infuse: bool = False
    skip_web: bool = False
    skip_archive: bool = False
    poster_frame: int | None = None        # Frame-Nummer für Vorschaubild
    poster_at: float | None = None         # Zeitpunkt in Sekunden für Vorschaubild
    poster_crop: str | None = None         # Bildausschnitt (left/center-left/center/center-right/right)
    web_id: str | None = None              # Web-ID für Web-Medienset (12 Zeichen, a-z 0-9; überschreibt Sidecar)
    max_luminance: int | None = None       # Peak-Leuchtdichte in nits für HDR-Metadaten (Default: 1000)
    no_sidecar: bool = False               # Sidecar-Datei nicht lesen/schreiben


@dataclass
class PublishResult:
    """Ergebnis des Veröffentlichungs-Workflows."""

    success: bool
    infuse_dir: Path | None = None
    web_dir: Path | None = None
    web_id: str | None = None
    web_url: str | None = None  # Vollständige URL (branding_base_url + web_id), unabhängig vom lokalen web_dir
    infuse_deployed: bool = False
    web_deployed: bool = False
    archived: bool = False
    error_message: str | None = None


# ---------------------------------------------------------------------------
# Deploy (Einzeloperationen)
# ---------------------------------------------------------------------------

@dataclass
class DeployRequest:
    """Request für ein einzelnes Deployment (Infuse oder Web)."""

    source_dir: Path


@dataclass
class DeployResult:
    """Ergebnis eines Deployments."""

    success: bool
    target_path: str | None = None
    error_message: str | None = None


# ---------------------------------------------------------------------------
# Archivierung
# ---------------------------------------------------------------------------

@dataclass
class ArchiveRequest:
    """Request für die Archivierung einer Videodatei."""

    source_path: Path
    recording_date: str | None = None  # ISO YYYY-MM-DD, für ISO-Dateiname
    title: str | None = None           # Titel für ISO-Dateiname und Volume-Name


@dataclass
class ArchiveResult:
    """Ergebnis der Archivierung."""

    success: bool
    archive_path: Path | None = None
    error_message: str | None = None


# ---------------------------------------------------------------------------
# Verzeichnis-Publish
# ---------------------------------------------------------------------------

class VideoStatusKind(StrEnum):
    """Status eines einzelnen Videos im Batch-Lauf."""

    PUBLISHED = "published"     # Erfolgreich publiziert
    SKIPPED = "skipped"         # Bereits publiziert, übersprungen
    FAILED = "failed"           # Fehler bei Publikation
    PENDING = "pending"         # Würde publiziert (nur im Dry-Run)


@dataclass
class VideoStatus:
    """Status eines einzelnen Videos im Batch-Lauf."""

    path: Path
    kind: VideoStatusKind
    publish_result: PublishResult | None = None  # Bei PUBLISHED gesetzt
    error_message: str | None = None             # Bei FAILED gesetzt
    published_at: str | None = None              # Bei SKIPPED gesetzt (ISO-Timestamp)


@dataclass
class DirectoryPublishResult:
    """Ergebnis eines Verzeichnis-Publish-Laufs."""

    success: bool
    directory: Path
    videos: list[VideoStatus] = field(default_factory=list)
    error_message: str | None = None

    @property
    def published_count(self) -> int:
        return sum(1 for v in self.videos if v.kind == VideoStatusKind.PUBLISHED)

    @property
    def skipped_count(self) -> int:
        return sum(1 for v in self.videos if v.kind == VideoStatusKind.SKIPPED)

    @property
    def failed_count(self) -> int:
        return sum(1 for v in self.videos if v.kind == VideoStatusKind.FAILED)

    @property
    def pending_count(self) -> int:
        return sum(1 for v in self.videos if v.kind == VideoStatusKind.PENDING)
