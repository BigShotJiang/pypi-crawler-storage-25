"""Öffentliche Fassade – delegiert an Core-Module mit Fehlerbehandlung."""

from __future__ import annotations

from typing import Callable

from pathlib import Path

from familienfilm_manager.api.models import (
    ArchiveRequest,
    ArchiveResult,
    DeployRequest,
    DeployResult,
    DirectoryPublishResult,
    FamilienfilmEvent,
    PublishRequest,
    PublishResult,
    RuntimeOptions,
)


def publish(
    request: PublishRequest,
    runtime: RuntimeOptions | None = None,
    on_event: Callable[[FamilienfilmEvent], None] | None = None,
) -> PublishResult:
    """Veröffentlicht ein Video: Medienset erstellen + optional Infuse/Web/Archiv."""
    from familienfilm_manager.core.publisher import run_publish

    try:
        return run_publish(request, runtime, on_event)
    except Exception as e:
        return PublishResult(success=False, error_message=str(e))


def publish_directory(
    directory: Path,
    runtime: RuntimeOptions | None = None,
    on_event: Callable[[FamilienfilmEvent], None] | None = None,
    skip_infuse: bool = False,
    skip_web: bool = False,
    skip_archive: bool = False,
    force: bool = False,
    dry_run: bool = False,
    work_dir: Path | None = None,
) -> DirectoryPublishResult:
    """Publiziert alle qualifizierten Videos in einem Verzeichnis sequenziell.

    Filtert nach Muster ``<YYYY-MM-DD> <titel>.<ext>`` und bekannten Video-Endungen.
    Sortiert chronologisch (älteste zuerst). Überspringt bereits publizierte Videos
    (Sidecar-``published_at``), sofern weder Video noch Sidecar geändert wurden.

    Args:
        work_dir: Arbeitsverzeichnis für temporäre Dateien (gilt für jedes Video
            im Batch). Wird auch an mediaset-creator durchgereicht. Standard:
            Verzeichnis des jeweiligen Quellvideos.
    """
    from familienfilm_manager.core.directory_publisher import run_publish_directory

    try:
        return run_publish_directory(
            directory=directory,
            runtime=runtime,
            on_event=on_event,
            skip_infuse=skip_infuse,
            skip_web=skip_web,
            skip_archive=skip_archive,
            force=force,
            dry_run=dry_run,
            work_dir=work_dir,
        )
    except Exception as e:
        return DirectoryPublishResult(
            success=False, directory=directory, error_message=str(e),
        )


def deploy_infuse(
    request: DeployRequest,
    runtime: RuntimeOptions | None = None,
    on_event: Callable[[FamilienfilmEvent], None] | None = None,
) -> DeployResult:
    """Deployt ein bestehendes Verzeichnis mit Infuse-Dateien."""
    from familienfilm_manager.core.infuse_deployer import deploy_to_infuse

    rt = runtime or RuntimeOptions()
    try:
        return deploy_to_infuse(
            source_dir=request.source_dir,
            infuse_target=rt.infuse_target,
            rclone_path=rt.rclone_path,
            group_by=rt.infuse_group_by,
            on_event=on_event,
        )
    except Exception as e:
        return DeployResult(success=False, error_message=str(e))


def deploy_web(
    request: DeployRequest,
    runtime: RuntimeOptions | None = None,
    on_event: Callable[[FamilienfilmEvent], None] | None = None,
) -> DeployResult:
    """Deployt ein Web-Medienset-Verzeichnis zum Webserver."""
    from familienfilm_manager.core.web_deployer import deploy_to_web

    rt = runtime or RuntimeOptions()
    try:
        return deploy_to_web(
            source_dir=request.source_dir,
            web_target=rt.web_target,
            rclone_path=rt.rclone_path,
            on_event=on_event,
        )
    except Exception as e:
        return DeployResult(success=False, error_message=str(e))


def archive(
    request: ArchiveRequest,
    runtime: RuntimeOptions | None = None,
    on_event: Callable[[FamilienfilmEvent], None] | None = None,
) -> ArchiveResult:
    """Archiviert eine Videodatei als ISO und verschiebt sie zum Archiv-Ziel."""
    from familienfilm_manager.core.archiver import archive_video

    rt = runtime or RuntimeOptions()
    try:
        return archive_video(
            source_path=request.source_path,
            archive_target=rt.archive_target,
            rclone_path=rt.rclone_path,
            recording_date=request.recording_date,
            title=request.title,
            on_event=on_event,
        )
    except Exception as e:
        return ArchiveResult(success=False, error_message=str(e))
