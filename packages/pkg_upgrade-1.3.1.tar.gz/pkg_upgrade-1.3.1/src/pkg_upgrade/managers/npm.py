import json
import shutil

from pkg_upgrade._subprocess import run_command
from pkg_upgrade.manager import PackageManager
from pkg_upgrade.models import Package, Result
from pkg_upgrade.registry import register_manager


@register_manager
class NpmManager(PackageManager):
    name = "npm"
    key = "npm"
    icon = "📦"
    platforms = frozenset({"macos", "linux", "windows"})

    async def is_available(self) -> bool:
        return shutil.which("npm") is not None

    async def check_outdated(self) -> list[Package]:
        # npm outdated exits 1 when there are outdated packages — ignore exit code
        _, stdout, _ = await run_command(["npm", "outdated", "--global", "--json"])
        if not stdout.strip():
            return []
        data = json.loads(stdout)
        return [
            Package(
                name=name,
                current_version=info.get("current", "unknown"),
                latest_version=info["latest"],
            )
            for name, info in data.items()
        ]

    async def upgrade(self, package: Package) -> Result:
        code, stdout, stderr = await run_command(["npm", "install", "-g", f"{package.name}@latest"])
        if code == 0:
            return Result(success=True, message=stdout.strip(), package=package)
        return Result(success=False, message=stderr.strip(), package=package)
