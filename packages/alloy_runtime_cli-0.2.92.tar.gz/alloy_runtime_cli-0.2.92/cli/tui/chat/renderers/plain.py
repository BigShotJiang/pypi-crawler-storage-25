"""Plain text renderer for chat messages.

Renders messages without any Rich markup formatting.
"""

from datetime import datetime

from alloy_runtime_types.dtos.sessions import MessageResponse

from cli.tui.chat.renderers.base import get_message_body
from cli.tui.chat.types import format_time


class PlainTextRenderer:
    """Renders messages as plain text without formatting.

    Useful for:
        - Exporting conversations
        - Copying to clipboard
        - Accessibility contexts
        - Testing and debugging

    """

    def render(
        self,
        messages: tuple[MessageResponse, ...],
        pending_user_message: str | None = None,
        assistant_name: str = "Assistant",
        is_generating: bool = False,
        thinking_collapsed: bool = False,
    ) -> str:
        """Render messages to a plain text string.

        Args:
            messages: Tuple of message responses to render.
            pending_user_message: User message shown optimistically before server confirms.
            assistant_name: Name to display for assistant (agent name or model).
            is_generating: Whether currently waiting for the final response.
            thinking_collapsed: Whether thinking blocks are collapsed (ignored in plain).

        Returns:
            Plain text string without Rich markup.
        """
        lines: list[str] = []

        for msg in messages:
            time_str = format_time(msg.created_at)

            if msg.role == "user":
                body = get_message_body(msg)
                lines.append(f"You [{time_str}]:")
            else:
                body = get_message_body(msg)
                lines.append(f"{assistant_name} [{time_str}]:")

            lines.append(body)
            lines.append("")

        # Show pending user message
        if pending_user_message:
            now_str = datetime.now().strftime("%H:%M")
            lines.append(f"You [{now_str}]:")
            lines.append(pending_user_message)
            lines.append("")

        # Show in-flight response placeholder
        if is_generating:
            lines.append(f"{assistant_name}:")
            lines.append("Waiting for response...")

        return "\n".join(lines)
