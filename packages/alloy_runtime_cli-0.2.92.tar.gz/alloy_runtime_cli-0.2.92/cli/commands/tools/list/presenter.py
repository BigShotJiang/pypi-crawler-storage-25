"""Presenter for tools list command output."""

from pydantic import BaseModel

from alloy_runtime_types.dtos.tools import ListToolsResponse

from cli.infrastructure.output import OutputService
from cli.infrastructure.renderers.list_renderer import ColumnConfig


class ToolListRow(BaseModel):
    id: str
    description: str | None
    parameters: bool


def present_tools_list(response: ListToolsResponse) -> None:
    output = OutputService.get()

    rows: list[BaseModel] = [
        ToolListRow(
            id=tool.id,
            description=tool.description,
            parameters=tool.parameter_schema is not None,
        )
        for tool in response.tools
    ]

    columns = [
        ColumnConfig(
            source_field="id",
            header_label="ID",
        ),
        ColumnConfig(
            source_field="description",
            header_label="Description",
        ),
        ColumnConfig(
            source_field="parameters",
            header_label="Parameters",
        ),
    ]

    output.table(
        items=rows,
        title="Tools",
        columns=columns,
        raw_payload=response,
    )
