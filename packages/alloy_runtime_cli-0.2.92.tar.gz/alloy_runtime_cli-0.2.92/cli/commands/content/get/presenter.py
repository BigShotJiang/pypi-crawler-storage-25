import json
import sys

from cli.infrastructure.formatters.base import render_psql_records
from cli.infrastructure.formatting.fields import (
    format_cost,
    format_datetime,
    format_optional,
    format_tokens,
    format_uuid,
)
from cli.infrastructure.output import OutputFormat, OutputService
from alloy_runtime_types.dtos.content import ContentPartItemResponse
from alloy_runtime_types.dtos.templates import TagResponse


def present_content_part(response: ContentPartItemResponse) -> None:
    output = OutputService.get()

    if getattr(output, "format", OutputFormat.COMPACT) == OutputFormat.JSON:
        output.raw(response)
        return

    _display_content(response)

    try:
        _display_metadata(response)
    except (BlockingIOError, BrokenPipeError):
        pass


def _display_metadata(response: ContentPartItemResponse) -> None:
    metadata: dict[str, str] = {
        "ID": str(response.id),
        "Message ID": format_uuid(response.message_id, short=True),
        "Message Role": response.message_role,
        "Part Index": str(response.part_index),
        "Content Type": response.content_type_id,
        "Storage Type": (
            "structured" if response.content_structured is not None else "text"
        ),
        "Created": format_datetime(response.created_at),
        "Tags": _format_tags(response.tags),
    }

    if response.session is not None:
        metadata.update(
            {
                "Session ID": format_uuid(response.session.id, short=True),
                "Session Name": format_optional(
                    response.session.name,
                    placeholder="(unnamed session)",
                ),
                "Session Activity": format_datetime(response.session.last_activity_at),
            }
        )

    if response.execution_metadata is not None:
        exec_meta = response.execution_metadata
        metadata.update(
            {
                "Execution ID": format_uuid(exec_meta.agent_execution_id, short=True),
                "Agent": format_optional(
                    exec_meta.agent_name,
                    placeholder="(direct model call)",
                ),
                "Model": exec_meta.model,
                "Cost": format_optional(
                    exec_meta.total_cost_usd,
                    formatter=format_cost,
                ),
                "Tokens": format_optional(
                    exec_meta.total_tokens,
                    formatter=format_tokens,
                ),
                "Queued At": format_datetime(exec_meta.queued_at),
            }
        )

    sys.stderr.write(f"{render_psql_records([metadata])}\n")
    sys.stderr.flush()


def _display_content(response: ContentPartItemResponse) -> None:
    content = _format_content(response)
    sys.stdout.write(content)
    if not content.endswith("\n"):
        sys.stdout.write("\n")
    sys.stdout.flush()


def _format_tags(tags: list[TagResponse]) -> str:
    if not tags:
        return "(no tags)"

    tag_paths = [t.tag_path for t in tags]
    return ", ".join(tag_paths)


def _format_content(response: ContentPartItemResponse) -> str:
    if response.content_text is not None:
        return response.content_text
    if response.content_structured is not None:
        return json.dumps(response.content_structured, indent=2, ensure_ascii=False)
    return "(no content)"
