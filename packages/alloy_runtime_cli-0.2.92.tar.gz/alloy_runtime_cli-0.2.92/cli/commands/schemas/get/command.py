"""Schemas get command implementation."""

import typer

from cli.commands.schemas.get.presenter import present_schema_details
from cli.infrastructure.command import async_command, authenticated_client


def schemas_get_command(
    schema: str = typer.Argument(
        ...,
        help="Schema name or UUID",
    ),
) -> None:
    """Get details of a single schema.

    Retrieves the full schema metadata and definition.
    The schema can be specified by name (recommended) or UUID.

    When looking up by name, returns the latest version of the schema.

    Output is piping-friendly:
    - Metadata goes to stderr (visible in terminal but not piped)
    - Schema definition goes to stdout (for piping to other commands)

    Examples:
        # Get by name
        alloy schemas get my-schema
        alloy schemas get user-profile-schema

        # Get by UUID
        alloy schemas get 019405e0-8000-7000-a000-000000000001

        # Pipe schema definition to jq or file
        alloy schemas get my-schema | jq .
        alloy schemas get my-schema > schema.json
    """
    _execute_get(schema_identifier=schema)


@async_command
async def _execute_get(schema_identifier: str) -> None:
    """Execute get schema operation.

    Args:
        schema_identifier: Schema name or UUID

    Raises:
        NotFoundError: If schema not found or user lacks access
        AuthenticationError: If API key is invalid
        ServerError: If server returns 5xx error
    """
    async with authenticated_client() as (_config, client):
        response = await client.get_schema(schema_identifier)

    present_schema_details(response)
