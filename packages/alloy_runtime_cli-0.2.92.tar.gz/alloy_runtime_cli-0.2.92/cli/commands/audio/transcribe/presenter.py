from pydantic import BaseModel

from cli.infrastructure.output import OutputFormat, OutputService
from cli.infrastructure.renderers.entity_renderer import FieldConfig


class _TranscriptionOutput(BaseModel):
    transcription: str


def present_transcription(text: str) -> None:
    output = OutputService.get()

    if getattr(output, "format", OutputFormat.COMPACT) == OutputFormat.JSON:
        output.raw({"transcription": text})
        return

    output.entity(
        _TranscriptionOutput(transcription=text),
        "Transcription",
        [FieldConfig("transcription", "Transcription")],
    )
