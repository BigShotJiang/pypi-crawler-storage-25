"""Presenter for sessions list command output."""

from alloy_runtime_types.dtos.sessions import ListSessionsResponse

from cli.infrastructure.output import OutputService
from cli.infrastructure.renderers.list_renderer import ColumnConfig


def _format_name(name: str | None) -> str:
    """Format session name."""
    if not name:
        return "(unnamed)"
    return name


def present_sessions_list(response: ListSessionsResponse) -> None:
    """Present list of sessions with Rich table formatting."""
    output = OutputService.get()

    columns = [
        ColumnConfig(
            source_field="id",
            header_label="ID",
            compact_line=1,
            compact_style="cyan",
        ),
        ColumnConfig(
            source_field="message_count",
            header_label="Messages",
            align="right",
            formatter=lambda x: f"{x} msgs" if x else "0 msgs",
            compact_line=1,
            compact_style="green",
        ),
        ColumnConfig(
            source_field="created_at",
            header_label="Created",
            formatter=lambda x: x.strftime("%Y-%m-%d %H:%M") if x else "-",
            compact_line=1,
            compact_style="blue",
        ),
        ColumnConfig(
            source_field="name",
            header_label="Name",
            formatter=_format_name,
            compact_line=2,
            compact_style="white bold",
        ),
        ColumnConfig(
            source_field="agent_name",
            header_label="Agent",
            formatter=lambda x: x or "-",
            compact_line=2,
            compact_style="dim",
        ),
    ]

    output.table(
        items=response.sessions,  # type: ignore[arg-type]
        title=f"Sessions ({response.total})",
        columns=columns,
        raw_payload=response,
        total_count=response.total,
    )
