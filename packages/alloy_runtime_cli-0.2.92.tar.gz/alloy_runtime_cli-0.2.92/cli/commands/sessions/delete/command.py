"""Session delete command implementation."""

from uuid import UUID

import typer

from cli.commands.flag_utils import validate_uuid
from cli.commands.sessions.delete.presenter import present_delete_result
from cli.infrastructure.command import async_command, authenticated_client
from cli.infrastructure.console import Confirm


def sessions_delete_command(
    session_id: str = typer.Argument(
        ...,
        help="Session UUID",
    ),
    yes: bool = typer.Option(
        False,
        "-y",
        "--yes",
        help="Skip confirmation",
    ),
) -> None:
    """Delete a chat session and all its messages.

    Examples:
        alloy sessions delete 123e4567-89ab-cdef-0123-456789abcdef
        alloy sessions delete 123e4567-89ab... -y
    """
    session_uuid = validate_uuid(session_id, "session")

    if not yes:
        confirmed = Confirm.ask(f"Delete session {session_id}?")
        if not confirmed:
            raise typer.Abort()

    _execute_delete(session_id=session_uuid)


@async_command
async def _execute_delete(session_id: UUID) -> None:
    """Execute delete session operation."""
    async with authenticated_client() as (_config, client):
        response = await client.delete_session(session_id)

    present_delete_result(response)
