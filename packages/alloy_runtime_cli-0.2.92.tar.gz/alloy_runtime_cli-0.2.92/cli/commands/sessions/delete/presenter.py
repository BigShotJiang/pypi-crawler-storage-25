"""Presenter for session delete command output."""

from cli.infrastructure.output import OutputService
from alloy_runtime_types.dtos.sessions import DeleteSessionResponse


def present_delete_result(response: DeleteSessionResponse) -> None:
    """Present session deletion result."""
    output = OutputService.get()
    output.result(
        action="delete",
        resource="session",
        identifier=str(response.deleted_session.id),
        name=None,
    )
