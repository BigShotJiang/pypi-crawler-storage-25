"""Session last assistant message command implementation."""

from uuid import UUID

import typer

from cli.commands.flag_utils import validate_uuid
from cli.commands.sessions.last.presenter import present_last_message
from cli.commands.shared_flags import OUTPUT_FILE, OUTPUT_MODE
from cli.infrastructure.command import async_command, authenticated_client
from cli.infrastructure.error_display import display_error_record


def sessions_last_command(
    session_id: str = typer.Argument(..., help="Session UUID"),
    output: str = OUTPUT_MODE,
    output_file: str | None = OUTPUT_FILE,
) -> None:
    """Print, copy, or save the last assistant response in a chat session.

    Examples:
        alloy sessions last 123e4567-89ab...
        alloy sessions last 123e4567-89ab... -o clipboard
        alloy sessions last 123e4567-89ab... -o file -O response.md
    """
    if output not in ("console", "clipboard", "file"):
        raise typer.BadParameter(
            f"Invalid output '{output}'. Valid options: console, clipboard, file"
        )
    if output == "file" and not output_file:
        raise typer.BadParameter("--output-file is required when using --output=file")
    if output != "file" and output_file is not None:
        raise typer.BadParameter("--output-file can only be used with --output=file")

    _execute_last(
        session_id=validate_uuid(session_id, "session"),
        output=output,
        output_file=output_file,
    )


@async_command
async def _execute_last(
    session_id: UUID,
    output: str,
    output_file: str | None,
) -> None:
    async with authenticated_client() as (_config, client):
        response = await client.list_session_messages(
            session_id,
            role="assistant",
            limit=1,
            offset=0,
            order="desc",
        )

    if not response.messages:
        display_error_record(
            {
                "Type": "not_found",
                "Message": "No assistant messages found for session",
                "Session ID": str(session_id),
            }
        )
        raise typer.Exit(code=1)

    present_last_message(response.messages[0], output, output_file)
