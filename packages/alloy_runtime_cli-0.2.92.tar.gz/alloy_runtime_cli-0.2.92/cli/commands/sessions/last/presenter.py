"""Presenter for the last assistant message command."""

import json
from pathlib import Path

import typer

from alloy_runtime_types.dtos.sessions import MessageResponse
from cli.infrastructure.error_display import display_error_record
from cli.infrastructure.output import OutputService


def _extract_message_text(message: MessageResponse) -> str:
    text_parts: list[str] = []
    for part in message.content_parts:
        if part.content_type_id == "thinking":
            continue
        if part.content_text:
            text_parts.append(part.content_text)
        elif part.content_structured is not None:
            text_parts.append(
                json.dumps(part.content_structured, indent=2, ensure_ascii=False)
            )
    return "".join(text_parts)


def present_last_message(
    message: MessageResponse,
    output: str,
    output_file: str | None,
) -> None:
    text = _extract_message_text(message)
    if not text:
        display_error_record(
            {
                "Type": "empty_message",
                "Message": "Assistant message is empty",
                "Message ID": str(message.id),
            }
        )
        raise typer.Exit(code=1)

    if output == "console":
        _write_stdout(text)
        return
    if output == "clipboard":
        _copy_to_clipboard(text)
        return
    if output == "file":
        if output_file is None:
            raise RuntimeError("file output requires output_file")
        _write_output_file(output_file, text)
        return

    raise RuntimeError(f"unsupported output mode: {output}")


def _write_stdout(text: str) -> None:
    output = OutputService.get()
    output.console.file.write(f"{text}\n")
    output.console.file.flush()


def _copy_to_clipboard(text: str) -> None:
    output = OutputService.get()
    try:
        import pyperclip

        pyperclip.copy(text)
    except ImportError as error:
        display_error_record(
            {
                "Type": "clipboard_error",
                "Message": "pyperclip not installed. Install with: pip install pyperclip",
                "Destination": "clipboard",
            }
        )
        raise typer.Exit(code=1) from error
    except Exception as error:
        display_error_record(
            {
                "Type": "clipboard_error",
                "Message": str(error),
                "Destination": "clipboard",
            }
        )
        raise typer.Exit(code=1) from error

    output.progress(f"Copied last assistant response to clipboard ({len(text)} chars).")


def _write_output_file(output_file: str, text: str) -> None:
    output = OutputService.get()
    path = Path(output_file).expanduser()
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(text, encoding="utf-8")
    except OSError as error:
        display_error_record(
            {
                "Type": "file_write_error",
                "Message": str(error),
                "Destination": output_file,
            }
        )
        raise typer.Exit(code=1) from error

    output.progress(
        f"Wrote last assistant response to {path.resolve()} ({len(text)} chars)."
    )
