"""Presenter for knowledge document count output."""

import json

from alloy_runtime_types.dtos.knowledge import (
    CountDocumentsResponse,
    DOCUMENT_STATUS_ORDER,
)
from rich.markup import escape

from cli.infrastructure.output import OutputService


def present_documents_count(
    response: CountDocumentsResponse, *, output_json: bool = False
) -> None:
    output = OutputService.get()
    if output_json:
        output.text(escape(json.dumps(response.model_dump(mode="json"), indent=2)))
        return

    output.text(f"Total documents: {escape(str(response.count))}")
    breakdown = response.breakdown_by_status.model_dump()
    output.text("By status:")
    for status in DOCUMENT_STATUS_ORDER:
        output.text(f"  {escape(status)}: {escape(str(breakdown[status]))}")
