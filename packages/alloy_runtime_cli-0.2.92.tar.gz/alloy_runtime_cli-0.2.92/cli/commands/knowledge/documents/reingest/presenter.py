"""Presenter for knowledge document reingest command output."""

from pydantic import BaseModel

from cli.infrastructure.formatting.fields import format_uuid
from cli.infrastructure.output import OutputService
from cli.infrastructure.renderers.entity_renderer import FieldConfig
from alloy_runtime_types.dtos.knowledge import ReingestDocumentResponse


def _format_reingest_status(status: str) -> str:
    return status


class ReingestDiffOutput(BaseModel):
    diff: str


def present_reingest_result(response: ReingestDocumentResponse) -> None:
    """Present document reingest result.

    Args:
        response: ReingestDocumentResponse from server
    """
    output = OutputService.get()
    extra_fields = {
        "Message": response.message,
        "Document Type": response.document_type,
        "Question Gen Agent": (
            format_uuid(response.question_gen_agent_id, short=False)
            if response.question_gen_agent_id
            else None
        ),
        "Question Gen Template": (
            format_uuid(response.question_gen_template_id, short=False)
            if response.question_gen_template_id
            else None
        ),
        "Diff Stats": str(response.diff_stats)
        if response.dry_run and response.diff_stats
        else None,
        "Rejected": response.rejection_reason if response.rejected else None,
    }
    output.result(
        action="reingest",
        resource="knowledge_document",
        status=_format_reingest_status(response.status),
        identifier=format_uuid(response.document_id, short=False),
        name=response.document_type,
        extra_fields={k: v for k, v in extra_fields.items() if v is not None},
    )

    if response.dry_run and response.diff_unified:
        output.entity(
            ReingestDiffOutput(diff=response.diff_unified),
            "Preprocessing Diff",
            [FieldConfig("diff", "Diff")],
        )
