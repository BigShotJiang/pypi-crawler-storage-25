"""Presenter for document ingest output."""

from cli.infrastructure.output import OutputService
from alloy_runtime_types.dtos.knowledge import IngestDocumentsResponse


def present_ingest_success(response: IngestDocumentsResponse) -> None:
    """Present successful document ingestion (queued for processing).

    Args:
        response: Document ingestion response from server
    """
    output = OutputService.get()
    extra_fields: dict[str, object] = {
        "Submitted": response.submitted_count,
        "Staged": response.staged_count,
        "Duplicate external id": response.duplicate_external_id_count,
        "Duplicate content": response.duplicate_content_count,
        "Duplicate within batch": response.duplicate_within_batch_count,
        "Next Step": f"poll GET /knowledge/documents/ingest/operations/{response.operation_id}",
    }
    output.result(
        action="ingest",
        resource="knowledge_documents",
        status=response.status,
        identifier=str(response.operation_id),
        name=None,
        extra_fields=extra_fields or None,
    )
