from typing import Iterable
from uuid import UUID

from cli.infrastructure.formatting.fields import (
    format_datetime,
    format_optional,
    format_uuid,
)
from cli.infrastructure.output import OutputService
from cli.infrastructure.renderers.entity_renderer import FieldConfig
from alloy_runtime_types.dtos.knowledge import (
    GetBulkReingestFailedDocumentsOperationResponse,
)


def _format_uuid_list(value: Iterable[UUID] | None) -> str:
    if not value:
        return "—"
    return ", ".join(str(item) for item in value)


def present_bulk_reingest_failed_status(
    response: GetBulkReingestFailedDocumentsOperationResponse,
) -> None:
    output = OutputService.get()
    output.entity(
        response,
        "Bulk Reingest Failed Status",
        [
            FieldConfig(
                "operation_id",
                "Operation ID",
                lambda value: format_uuid(value, short=False),
            ),
            FieldConfig(
                "collection_id",
                "Collection ID",
                lambda value: format_uuid(value, short=False),
            ),
            FieldConfig(
                "requested_document_ids", "Requested Document IDs", _format_uuid_list
            ),
            FieldConfig("status", "Status"),
            FieldConfig("matched_count", "Matched Count", str),
            FieldConfig("queued_count", "Queued Count", str),
            FieldConfig("skipped_count", "Skipped Count", str),
            FieldConfig("dispatch_failed_count", "Dispatch Failed Count", str),
            FieldConfig(
                "matched_document_ids", "Matched Document IDs", _format_uuid_list
            ),
            FieldConfig(
                "queued_document_ids", "Queued Document IDs", _format_uuid_list
            ),
            FieldConfig(
                "skipped_document_ids", "Skipped Document IDs", _format_uuid_list
            ),
            FieldConfig(
                "dispatch_failed_document_ids",
                "Dispatch Failed Document IDs",
                _format_uuid_list,
            ),
            FieldConfig("queued_at", "Queued At", format_datetime),
            FieldConfig(
                "processing_started_at", "Processing Started At", format_datetime
            ),
            FieldConfig("last_heartbeat_at", "Last Heartbeat At", format_datetime),
            FieldConfig("completed_at", "Completed At", format_datetime),
            FieldConfig("error_message", "Error", format_optional),
        ],
        raw_payload=response,
    )
