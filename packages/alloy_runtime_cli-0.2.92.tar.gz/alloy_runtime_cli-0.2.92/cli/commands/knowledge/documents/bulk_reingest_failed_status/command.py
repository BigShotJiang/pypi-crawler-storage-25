import typer
from uuid import UUID

from cli.commands.knowledge.documents.bulk_reingest_failed_status.presenter import (
    present_bulk_reingest_failed_status,
)
from cli.infrastructure.command import async_command, authenticated_client


def _parse_operation_id(value: str) -> UUID:
    try:
        return UUID(value)
    except ValueError as exc:
        raise typer.BadParameter(f"Invalid operation UUID: {value}") from exc


def knowledge_documents_bulk_reingest_failed_status_command(
    operation_id: str = typer.Argument(
        ...,
        help="Operation UUID returned by reingest-failed submit",
    ),
) -> None:
    _execute_bulk_reingest_failed_status(operation_id=operation_id)


@async_command
async def _execute_bulk_reingest_failed_status(operation_id: str) -> None:
    async with authenticated_client() as (_config, client):
        response = await client.get_bulk_reingest_failed_operation(
            _parse_operation_id(operation_id)
        )

    present_bulk_reingest_failed_status(response)
