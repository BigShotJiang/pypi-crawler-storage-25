"""Presenter for knowledge documents bulk metadata update command output."""

from cli.infrastructure.output import OutputService
from alloy_runtime_types.dtos.knowledge import BulkUpdateDocumentMetadataResponse


def present_bulk_metadata_result(
    response: BulkUpdateDocumentMetadataResponse,
) -> None:
    """Present bulk metadata update result.

    Args:
        response: BulkUpdateDocumentMetadataResponse from server
    """
    output = OutputService.get()
    output.result(
        action="update",
        resource="knowledge_documents",
        status="dry_run" if response.dry_run else "success",
        identifier=None,
        name=None,
        extra_fields={
            "Matched": response.matched_count,
            "Updated": response.updated_count,
            "Dry Run": response.dry_run,
        },
    )
