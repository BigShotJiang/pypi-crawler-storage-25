"""Presenter for knowledge collection cluster-status command output.

This module re-exports the shared presenter from the cluster command.
The cluster-status command and the cluster --wait command both display
the same status format.
"""

from cli.commands.knowledge.collections.cluster.presenter import present_cluster_status

__all__ = ["present_cluster_status"]
