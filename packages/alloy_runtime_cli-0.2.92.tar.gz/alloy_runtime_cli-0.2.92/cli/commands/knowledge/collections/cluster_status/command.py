"""Knowledge collection cluster-status command implementation."""

import typer

from cli.commands.knowledge.collections.cluster.presenter import present_cluster_status
from cli.infrastructure.command import async_command, authenticated_client


def knowledge_collections_cluster_status_command(
    collection: str = typer.Argument(
        ...,
        help="Collection name or UUID",
    ),
    task_id: str = typer.Option(
        ...,
        "--task-id",
        help="Celery task ID returned by the cluster trigger command",
    ),
) -> None:
    """Get clustering status for a knowledge collection.

    Requires a task ID from a previous cluster trigger.

    Examples:
        alloy knowledge collections cluster-status my-collection --task-id abc-123
        alloy knowledge collections cluster-status 550e8400-... --task-id abc-123
    """
    _execute_cluster_status(
        collection_identifier=collection,
        task_id=task_id,
    )


@async_command
async def _execute_cluster_status(
    collection_identifier: str,
    task_id: str,
) -> None:
    """Execute cluster status operation."""
    async with authenticated_client() as (_config, client):
        response = await client.get_collection_clustering_status(
            collection_identifier,
            task_id=task_id,
        )

    present_cluster_status(response)
