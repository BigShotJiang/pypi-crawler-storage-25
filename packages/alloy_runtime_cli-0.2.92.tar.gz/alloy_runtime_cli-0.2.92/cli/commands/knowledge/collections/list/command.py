"""Knowledge collections list command implementation."""

import typer

from cli.commands.knowledge.collections.list.presenter import present_collections_list
from cli.infrastructure.command import async_command, authenticated_client


def knowledge_collections_list_command(
    limit: int = typer.Option(
        50,
        "-l",
        "--limit",
        min=1,
        max=100,
        help="Max results",
    ),
    offset: int = typer.Option(
        0,
        "--offset",
        min=0,
        help="Skip N results",
    ),
) -> None:
    """List knowledge collections.

    Examples:
        alloy knowledge collections list
        alloy knowledge collections list -l 20
        alloy knowledge collections list --offset 10
    """
    _execute_list(limit=limit, offset=offset)


@async_command
async def _execute_list(limit: int, offset: int) -> None:
    """Execute list collections operation."""
    async with authenticated_client() as (_config, client):
        response = await client.list_collections(limit=limit, offset=offset)

    present_collections_list(response)
