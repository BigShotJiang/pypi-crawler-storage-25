"""Presenter for knowledge collections list command output."""

from alloy_runtime_types.dtos.knowledge import ListCollectionsResponse

from cli.infrastructure.output import OutputService
from cli.infrastructure.renderers.list_renderer import ColumnConfig


def present_collections_list(response: ListCollectionsResponse) -> None:
    """Present list of collections with Rich table formatting.

    Args:
        response: List collections response from server
    """
    output = OutputService.get()

    columns = [
        ColumnConfig(
            source_field="id",
            header_label="ID",
            compact_line=1,
            compact_style="cyan",
        ),
        ColumnConfig(
            source_field="section_strategy",
            header_label="Strategy",
            compact_line=1,
            compact_style="green",
        ),
        ColumnConfig(
            source_field="retrieval_chunk_target_tokens",
            header_label="Chunk Size",
            align="right",
            formatter=lambda x: f"{x} tokens",
            compact_line=1,
            compact_style="blue",
        ),
        ColumnConfig(
            source_field="updated_at",
            header_label="Updated",
            formatter=lambda x: x.strftime("%Y-%m-%d") if x else "-",
            compact_line=1,
            compact_style="dim",
        ),
        ColumnConfig(
            source_field="name",
            header_label="Name",
            compact_line=2,
            compact_style="white bold",
        ),
        ColumnConfig(
            source_field="description",
            header_label="Description",
            formatter=lambda x: x or "-",
            compact_line=2,
            compact_style="dim",
        ),
    ]

    output.table(
        items=response.collections,  # type: ignore[arg-type]
        title=f"Collections ({response.total})",
        columns=columns,
        raw_payload=response,
        total_count=response.total,
    )
