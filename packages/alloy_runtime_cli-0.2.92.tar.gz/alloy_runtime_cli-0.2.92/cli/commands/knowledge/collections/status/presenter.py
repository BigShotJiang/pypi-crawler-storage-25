from typing import cast

from pydantic import BaseModel

from alloy_runtime_types.dtos.knowledge import ListCollectionDocumentStatusesResponse

from cli.infrastructure.output import OutputService
from cli.infrastructure.renderers.list_renderer import ColumnConfig


def present_collection_statuses(
    response: ListCollectionDocumentStatusesResponse,
) -> None:
    output = OutputService.get()

    columns = [
        ColumnConfig(
            source_field="collection_name",
            header_label="Collection",
            compact_line=1,
            compact_style="white bold",
        ),
        ColumnConfig(
            source_field="total_documents",
            header_label="Total",
            align="right",
            compact_line=1,
            compact_style="blue",
        ),
        ColumnConfig(
            source_field="queued_documents",
            header_label="Queued",
            align="right",
            compact_line=1,
            compact_style="yellow",
        ),
        ColumnConfig(
            source_field="staged_documents",
            header_label="Staged",
            align="right",
            compact_line=1,
            compact_style="yellow",
        ),
        ColumnConfig(
            source_field="processing_documents",
            header_label="Processing",
            align="right",
            compact_line=1,
            compact_style="magenta",
        ),
        ColumnConfig(
            source_field="completed_documents",
            header_label="Completed",
            align="right",
            compact_line=1,
            compact_style="green",
        ),
        ColumnConfig(
            source_field="failed_documents",
            header_label="Failed",
            align="right",
            compact_line=1,
            compact_style="red",
        ),
        ColumnConfig(
            source_field="duplicate_documents",
            header_label="Duplicate",
            align="right",
            compact_line=1,
            compact_style="cyan",
        ),
        ColumnConfig(
            source_field="filtered_documents",
            header_label="Filtered",
            align="right",
            compact_line=1,
            compact_style="yellow",
        ),
    ]

    output.table(
        items=cast(list[BaseModel], response.collections),
        title=f"Collection Status ({response.total})",
        columns=columns,
        raw_payload=response,
        total_count=response.total,
    )
