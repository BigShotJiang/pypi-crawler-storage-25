"""Knowledge collections delete command implementation."""

import typer

from cli.commands.knowledge.collections.delete.presenter import present_delete_result
from cli.infrastructure.command import async_command, authenticated_client
from cli.infrastructure.console import Confirm


def knowledge_collections_delete_command(
    collection: str = typer.Argument(
        ...,
        help="Collection name or UUID",
    ),
    yes: bool = typer.Option(
        False,
        "-y",
        "--yes",
        help="Skip confirmation",
    ),
) -> None:
    """Delete a collection and all its documents.

    Permanently removes the collection and all associated documents and chunks.

    Examples:
        alloy knowledge collections delete my-collection
        alloy knowledge collections delete 550e8400-e29b-41d4-a716-446655440000 -y
    """
    _execute_delete(collection_identifier=collection, skip_confirm=yes)


@async_command
async def _execute_delete(collection_identifier: str, skip_confirm: bool) -> None:
    """Execute delete collection operation."""
    if not skip_confirm:
        confirmed = Confirm.ask(
            f"Delete collection '{collection_identifier}'? "
            "This will delete all documents and cannot be undone"
        )
        if not confirmed:
            raise typer.Abort()

    async with authenticated_client() as (_config, client):
        response = await client.delete_collection(collection_identifier)

    present_delete_result(response)
