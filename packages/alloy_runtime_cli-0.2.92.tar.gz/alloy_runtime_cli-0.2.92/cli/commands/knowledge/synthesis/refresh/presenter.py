"""Presenter for synthesis refresh output."""

from cli.infrastructure.formatting.fields import format_uuid
from cli.infrastructure.output import OutputService
from alloy_runtime_types.dtos.knowledge import RefreshSynthesisResponse


def present_synthesis_refresh_success(response: RefreshSynthesisResponse) -> None:
    """Present successful synthesis refresh.

    Args:
        response: Refresh synthesis response from server
    """
    output = OutputService.get()
    output.result(
        action="refresh",
        resource="synthesis",
        status=response.status,
        identifier=format_uuid(response.synthesis_id, short=False),
        name=None,
        extra_fields={
            "Message": response.message,
            "Next Step": f"alloy knowledge synthesis get {response.synthesis_id}",
        },
    )
