"""Presenter for synthesis delete output."""

from cli.infrastructure.formatting.fields import format_uuid
from cli.infrastructure.output import OutputService
from alloy_runtime_types.dtos.knowledge import DeleteSynthesisResponse


def present_synthesis_delete_success(response: DeleteSynthesisResponse) -> None:
    """Present successful synthesis deletion.

    Args:
        response: Delete synthesis response from server
    """
    output = OutputService.get()
    output.result(
        action="delete",
        resource="synthesis",
        identifier=format_uuid(response.id, short=False),
        name=response.title,
        extra_fields={"Topic": response.topic},
    )
