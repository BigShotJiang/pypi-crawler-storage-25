"""Presenter for billing projects list command output."""

from alloy_runtime_types.dtos.billing import ProjectListResponse

from cli.infrastructure.output import OutputService
from cli.infrastructure.renderers.list_renderer import ColumnConfig


def present_billing_projects_list(response: ProjectListResponse) -> None:
    """Present list of billing projects."""
    output = OutputService.get()

    columns = [
        ColumnConfig(
            source_field="id",
            header_label="ID",
            compact_line=1,
            compact_style="cyan",
        ),
        ColumnConfig(
            source_field="name",
            header_label="Name",
            compact_line=1,
            compact_style="green",
        ),
        ColumnConfig(
            source_field="description",
            header_label="Description",
            formatter=lambda x: x or "-",
            compact_line=2,
            compact_style="dim",
        ),
        ColumnConfig(
            source_field="external_reference",
            header_label="External Ref",
            formatter=lambda x: x or "-",
            compact_line=2,
            compact_style="dim",
        ),
        ColumnConfig(
            source_field="is_active",
            header_label="Active",
            formatter=lambda x: "Yes" if x else "No",
            compact_line=1,
            compact_style="white bold",
        ),
    ]

    output.table(
        items=response.projects,  # type: ignore[arg-type]
        title=f"Billing Projects ({response.total})",
        columns=columns,
        raw_payload=response,
        total_count=response.total,
    )
