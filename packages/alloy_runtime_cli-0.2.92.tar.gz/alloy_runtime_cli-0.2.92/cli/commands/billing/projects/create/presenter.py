"""Presenter for billing project create command output."""

from alloy_runtime_types.dtos.billing import CreateProjectResponse

from cli.infrastructure.output import OutputService
from cli.infrastructure.renderers.entity_renderer import FieldConfig


def present_billing_project_created(response: CreateProjectResponse) -> None:
    """Present created billing project details."""
    output = OutputService.get()

    fields = [
        FieldConfig("id", "ID", str),
        FieldConfig("name", "Name"),
        FieldConfig("description", "Description", lambda x: x or "-"),
        FieldConfig("external_reference", "External Reference", lambda x: x or "-"),
        FieldConfig("is_active", "Active", lambda x: "Yes" if x else "No"),
        FieldConfig(
            "created_at",
            "Created At",
            lambda x: x.strftime("%Y-%m-%d %H:%M:%S") if x else "-",
        ),
    ]

    output.entity(response, "Billing Project Created", fields, raw_payload=response)
