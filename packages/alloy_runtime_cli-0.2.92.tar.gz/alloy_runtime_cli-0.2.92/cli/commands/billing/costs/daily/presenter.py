"""Presenter for billing project daily costs command output."""

from decimal import Decimal

from alloy_runtime_types.dtos.billing import ProjectDailyCostEntry

from cli.infrastructure.output import OutputService
from cli.infrastructure.renderers.list_renderer import ColumnConfig


def _format_cost(cost: Decimal | None) -> str:
    """Format cost for display."""
    if cost is None:
        return "-"
    return f"${cost:.4f}"


def present_billing_daily_costs(entries: list[ProjectDailyCostEntry]) -> None:
    """Present billing project daily cost breakdown."""
    output = OutputService.get()

    columns = [
        ColumnConfig(
            source_field="date",
            header_label="Date",
            formatter=lambda x: str(x),
            compact_line=1,
            compact_style="cyan",
        ),
        ColumnConfig(
            source_field="execution_count",
            header_label="Executions",
            formatter=str,
            compact_line=1,
            compact_style="white",
        ),
        ColumnConfig(
            source_field="llm_cost_usd",
            header_label="LLM Cost",
            formatter=_format_cost,
            compact_line=2,
            compact_style="dim",
        ),
        ColumnConfig(
            source_field="rag_cost_usd",
            header_label="RAG Cost",
            formatter=_format_cost,
            compact_line=2,
            compact_style="dim",
        ),
        ColumnConfig(
            source_field="total_cost_usd",
            header_label="Total Cost",
            formatter=_format_cost,
            compact_line=1,
            compact_style="green bold",
        ),
        ColumnConfig(
            source_field="avg_cost_usd",
            header_label="Avg Cost",
            formatter=_format_cost,
            compact_line=2,
            compact_style="dim",
        ),
    ]

    output.table(
        items=entries,  # type: ignore[arg-type]
        title=f"Daily Costs ({len(entries)} days)",
        columns=columns,
        total_count=len(entries),
    )
