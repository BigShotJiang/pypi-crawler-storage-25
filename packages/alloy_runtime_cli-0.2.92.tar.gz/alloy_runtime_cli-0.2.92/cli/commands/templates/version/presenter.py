"""Presenter for template version creation output."""

from cli.commands.templates.get.presenter import present_template_details
from cli.infrastructure.output import OutputService
from alloy_runtime_types.dtos.templates import (
    CreateTemplateVersionResponse,
    GetTemplateResponse,
)


def present_version_create_success(response: CreateTemplateVersionResponse) -> None:
    """Present successful template version creation.

    Args:
        response: Template version creation response from server
    """
    output = OutputService.get()

    output.result(
        action="create",
        resource="template_version",
        identifier=str(response.version.id),
        name=f"{response.template.name} v{response.version.version}",
    )
    present_template_details(
        GetTemplateResponse(
            template=response.template,
            versions=[response.version],
            dependencies=response.dependencies,
        )
    )
