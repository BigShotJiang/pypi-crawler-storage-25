"""Presenter for templates get_by_version command output."""

from cli.commands.templates.get.presenter import present_template_details as _present
from alloy_runtime_types.dtos.templates import GetTemplateResponse


def present_template_details(response: GetTemplateResponse) -> None:
    _present(response)
