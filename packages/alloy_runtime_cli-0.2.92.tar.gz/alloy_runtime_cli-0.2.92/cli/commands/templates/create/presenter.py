"""Presenter for template creation output."""

from cli.commands.templates.get.presenter import present_template_details
from cli.infrastructure.output import OutputService
from alloy_runtime_types.dtos.templates import (
    CreateTemplateResponse,
    GetTemplateResponse,
)


def present_template_create_success(response: CreateTemplateResponse) -> None:
    """Present successful template creation.

    Args:
        response: Template creation response from server
    """
    output = OutputService.get()

    output.result(
        action="create",
        resource="template",
        identifier=str(response.template.id),
        name=response.template.name,
    )
    present_template_details(
        GetTemplateResponse(
            template=response.template,
            versions=[response.version],
            dependencies=response.dependencies,
        )
    )
