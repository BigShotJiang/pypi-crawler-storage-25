"""Templates get command implementation."""

from typing import Optional

import typer

from cli.commands.templates.get.presenter import present_template_details
from cli.infrastructure.command import async_command, authenticated_client


def templates_get_command(
    template: str = typer.Argument(
        ...,
        help="Template name or UUID",
    ),
    version: Optional[int] = typer.Option(
        None,
        "--version",
        min=1,
        help="Specific version number",
    ),
    full: bool = typer.Option(
        False,
        "--full",
        help="Show full content (no truncation)",
    ),
    copy: bool = typer.Option(
        False,
        "--copy",
        help="Copy content to clipboard",
    ),
) -> None:
    """Get template details.

    Examples:
        alloy templates get my-template
        alloy templates get email.welcome --version 2
        alloy templates get my-template --full
        alloy templates get my-template --copy
    """
    _execute_get(template_identifier=template, version=version, full=full, copy=copy)


@async_command
async def _execute_get(
    template_identifier: str, version: Optional[int], full: bool, copy: bool
) -> None:
    """Execute get template operation."""
    async with authenticated_client() as (_config, client):
        response = await client.get_template(template_identifier, version)

    present_template_details(response, full=full, copy=copy)
