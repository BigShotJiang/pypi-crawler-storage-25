"""Agents get command implementation."""

import typer

from cli.commands.agents.get.presenter import present_agent_details
from cli.infrastructure.command import async_command, authenticated_client


def agents_get_command(
    agent: str = typer.Argument(
        ...,
        help="Agent name or UUID",
    ),
) -> None:
    """Get details of a single agent.

    Retrieves the full agent configuration including models and tools.
    The agent can be specified by name or UUID.

    Examples:
        alloy agents get my-agent
        alloy agents get 123e4567-89ab-cdef-0123-456789abcdef
    """
    _execute_get(agent_identifier=agent)


@async_command
async def _execute_get(agent_identifier: str) -> None:
    """Execute get agent operation.

    Args:
        agent_identifier: Agent name or UUID
    """
    async with authenticated_client() as (_config, client):
        response = await client.get_agent(agent_identifier)

    present_agent_details(response)
