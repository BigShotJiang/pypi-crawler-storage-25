"""Agents delete command implementation."""

import typer

from cli.commands.agents.delete.presenter import present_delete_result
from cli.infrastructure.command import async_command, authenticated_client
from cli.infrastructure.console import Confirm


def agents_delete_command(
    agent: str = typer.Argument(
        ...,
        help="Agent name or UUID",
    ),
    yes: bool = typer.Option(
        False,
        "-y",
        "--yes",
        help="Skip confirmation",
    ),
) -> None:
    """Delete an agent.

    Permanently removes the agent and associated models, tools, and tags.
    Agents referenced by pipeline steps cannot be deleted.

    Examples:
        alloy agents delete my-agent
        alloy agents delete 550e8400-e29b-41d4-a716-446655440000 -y
    """
    _execute_delete(agent_identifier=agent, skip_confirm=yes)


@async_command
async def _execute_delete(agent_identifier: str, skip_confirm: bool) -> None:
    """Execute delete agent operation."""
    if not skip_confirm:
        confirmed = Confirm.ask(
            f"Delete agent '{agent_identifier}'? This cannot be undone"
        )
        if not confirmed:
            raise typer.Abort()

    async with authenticated_client() as (_config, client):
        response = await client.delete_agent(agent_identifier)

    present_delete_result(response)
