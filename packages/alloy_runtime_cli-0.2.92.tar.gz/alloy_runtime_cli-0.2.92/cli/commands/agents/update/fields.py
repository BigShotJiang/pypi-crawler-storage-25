"""Field definitions for agent update presentation."""

from alloy_runtime_types.dtos.agents import UpdateAgentResponse

from cli.commands.agents.tool_formatting import (
    format_generation_params as _format_generation_params,
    format_tool_details,
)


def format_models(response: UpdateAgentResponse) -> str:
    """Format singular model for display."""
    return response.model


def format_tools(response: UpdateAgentResponse) -> str:
    """Format tools list for display."""
    return format_tool_details(response.tools)


def format_tags(response: UpdateAgentResponse) -> str:
    """Format tags list for display."""
    if not response.tags:
        return "(none)"
    return ", ".join(t.tag_path for t in response.tags)


def format_generation_params(response: UpdateAgentResponse) -> str:
    """Format complete generation defaults for display."""
    return _format_generation_params(
        model_options=response.default_model_options,
        extra_headers=response.default_extra_headers,
    )
