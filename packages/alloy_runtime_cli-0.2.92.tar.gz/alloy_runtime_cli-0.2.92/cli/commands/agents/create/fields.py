"""Field definitions for agent presentation."""

from cli.infrastructure.formatting.fields import (
    format_datetime,
    format_optional,
    format_uuid,
)
from cli.infrastructure.renderers.entity_renderer import FieldConfig
from alloy_runtime_types.dtos.agents import CreateAgentResponse
from cli.commands.agents.tool_formatting import (
    format_generation_params as _format_generation_params,
)


def format_models(response: CreateAgentResponse) -> str:
    """Format singular model for display."""
    return response.model


def format_tools(response: CreateAgentResponse) -> str:
    """Format tools list for display."""
    if not response.tools:
        return "(none)"
    return ", ".join(t.tool_id for t in response.tools)


def format_tags(response: CreateAgentResponse) -> str:
    """Format tags list for display."""
    if not response.tags:
        return "(none)"
    return ", ".join(t.tag_path for t in response.tags)


def format_generation_params(response: CreateAgentResponse) -> str:
    """Format complete generation defaults for display."""
    return _format_generation_params(
        model_options=response.default_model_options,
        extra_headers=response.default_extra_headers,
    )


AGENT_FIELDS = [
    FieldConfig("id", "ID", lambda v: format_uuid(v, short=False)),
    FieldConfig("name", "Name"),
    FieldConfig("description", "Description", format_optional),
    FieldConfig(
        "organization_id",
        "Organization ID",
        lambda v: format_optional(v, lambda x: format_uuid(x, short=True)),
    ),
    FieldConfig(
        "user_id",
        "User ID",
        lambda v: format_optional(v, lambda x: format_uuid(x, short=True)),
    ),
    FieldConfig("created_at", "Created At", format_datetime),
]
