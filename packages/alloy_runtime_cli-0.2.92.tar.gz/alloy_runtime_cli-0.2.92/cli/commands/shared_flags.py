"""Shared CLI flag definitions for consistent flag naming across commands.

This module provides reusable typer.Option instances that can be imported
and used directly in command function signatures. This ensures:
- Consistent short/long flag names across all commands
- Consistent help text
- No code duplication for common flag patterns

Usage:
    from cli.commands.shared_flags import SEARCH, LIMIT, TAGS

    def my_command(
        search: str | None = SEARCH,
        limit: int = LIMIT,
        tags: str | None = TAGS,
    ) -> None:
        ...

Short Flag Convention:
    -a  --agent          Agent name/UUID
    -c  --content        Inline content
    -d  --description    Description field
    -e  --export         Export format
    -f  --file           Input file path
    -g  --group-by       Group results by field
    -l  --limit          Result limit
    -m  --message        User message
    -n  --name           Name field
    -o  --output         Output mode (console/clipboard/file)
    -O  --output-file    Output file path (capital O)
    -p  --provider       Provider key
    -M  --model          Model name (capital M, avoids -m message conflict)
    -s  --search         Search query
    -t  --tags           Tags (comma-separated)
    -T  --temperature    Temperature parameter (capital T)
    -v  --var            Template variable
    -V  --visibility     Visibility level (capital V)
    -w  --where          Filter condition
    -x  --exclude        Exclude pattern
    -y  --yes            Skip confirmation (replaces --force)
"""

from typing import Annotated, Optional

import typer

from alloy_runtime_types.dtos.generation import REASONING_EFFORT_VALUES


REASONING_EFFORT_CLI_HELP = "Reasoning: " + "|".join(REASONING_EFFORT_VALUES)

# =============================================================================
# PAGINATION FLAGS
# =============================================================================

LIMIT = typer.Option(
    50,
    "-l",
    "--limit",
    min=1,
    max=100,
    help="Max results to return",
)

OFFSET = typer.Option(
    0,
    "--offset",
    min=0,
    help="Skip N results",
)

CURSOR = typer.Option(
    None,
    "--cursor",
    help="Pagination cursor from previous response",
)


# =============================================================================
# SEARCH FLAGS
# =============================================================================

SEARCH = typer.Option(
    None,
    "-s",
    "--search",
    help="Fuzzy search terms",
)


# =============================================================================
# OUTPUT FLAGS
# =============================================================================

OUTPUT_MODE = typer.Option(
    "console",
    "-o",
    "--output",
    help="Output: console, clipboard, or file",
)

OUTPUT_FILE = typer.Option(
    None,
    "-O",
    "--output-file",
    help="Output file path (for --output file)",
)


# =============================================================================
# CONTENT INPUT FLAGS
# =============================================================================

FILE_INPUT = typer.Option(
    None,
    "-f",
    "--file",
    help="Read content from file",
    exists=True,
    readable=True,
)

CONTENT_INLINE = typer.Option(
    None,
    "-c",
    "--content",
    help="Inline content (or @file to read from file)",
)


# =============================================================================
# COMMON ENTITY FLAGS
# =============================================================================

NAME = typer.Option(
    ...,
    "-n",
    "--name",
    help="Name",
)

NAME_OPTIONAL = typer.Option(
    None,
    "-n",
    "--name",
    help="Name",
)

DESCRIPTION = typer.Option(
    None,
    "-d",
    "--description",
    help="Description",
)

TAGS = typer.Option(
    None,
    "-t",
    "--tags",
    help="Comma-separated tags",
)

TAGS_REQUIRED = typer.Option(
    ...,
    "-t",
    "--tags",
    help="Comma-separated tags",
)

TAGS_LIST = Annotated[
    Optional[list[str]],
    typer.Option(
        "-t",
        "--tag",
        help="Tag to include (repeatable)",
    ),
]

EXCLUDE_TAGS = Annotated[
    Optional[list[str]],
    typer.Option(
        "-x",
        "--exclude",
        help="Tag pattern to exclude (repeatable)",
    ),
]


# =============================================================================
# CONFIRMATION FLAGS
# =============================================================================

YES = typer.Option(
    False,
    "-y",
    "--yes",
    help="Skip confirmation prompt",
)

# =============================================================================
# MODEL SELECTION FLAGS
# =============================================================================

AGENT = typer.Option(
    None,
    "-a",
    "--agent",
    help="Agent name or UUID",
)

AGENT_REQUIRED = typer.Option(
    ...,
    "-a",
    "--agent",
    help="Agent name or UUID",
)

PROVIDER = typer.Option(
    None,
    "-p",
    "--provider",
    help="Provider key (anthropic, openai, etc.)",
)

PROVIDER_REQUIRED = typer.Option(
    ...,
    "-p",
    "--provider",
    help="Provider key (anthropic, openai, etc.)",
)

SERVICE = typer.Option(
    None,
    "--service",
    help="Service key (modal, exa, firecrawl, tavily, voyage)",
)

MODEL = typer.Option(
    None,
    "-M",
    "--model",
    help="Model name",
)

MODEL_REQUIRED = typer.Option(
    ...,
    "-M",
    "--model",
    help="Model name",
)


# =============================================================================
# GENERATION PARAMETER FLAGS
# =============================================================================

TEMPERATURE = typer.Option(
    None,
    "-T",
    "--temperature",
    help="Temperature (0.0-2.0)",
)

MAX_TOKENS = typer.Option(
    None,
    "--max-tokens",
    help="Max tokens to generate",
)

REASONING_EFFORT = typer.Option(
    None,
    "--reasoning-effort",
    help=REASONING_EFFORT_CLI_HELP,
)


# =============================================================================
# MESSAGE FLAGS
# =============================================================================

MESSAGE = typer.Option(
    None,
    "-m",
    "--message",
    help="User message (or @file)",
)

MESSAGE_REQUIRED = typer.Option(
    ...,
    "-m",
    "--message",
    help="User message (or @file)",
)

SYSTEM_INSTRUCTION = typer.Option(
    None,
    "--system",
    help="System instruction (or @file)",
)


# =============================================================================
# TEMPLATE FLAGS
# =============================================================================

TEMPLATE_VAR = Annotated[
    Optional[list[str]],
    typer.Option(
        "-v",
        "--var",
        help="Variable (key=value or key:=json). Repeatable.",
    ),
]

VISIBILITY = typer.Option(
    None,
    "-V",
    "--visibility",
    help="Visibility: private, organization, public",
)

VISIBILITY_REQUIRED = typer.Option(
    ...,
    "-V",
    "--visibility",
    help="Visibility: private, organization, public",
)

CONTENT_TYPE = typer.Option(
    None,
    "--type",
    help="Content type",
)

CONTENT_TYPE_REQUIRED = typer.Option(
    ...,
    "--type",
    help="Content type",
)


# =============================================================================
# SCOPE FLAGS
# =============================================================================

SCOPE = typer.Option(
    None,
    "--scope",
    help="Scope: user, organization, global",
)


# =============================================================================
# EXPORT FLAGS
# =============================================================================

EXPORT_FORMAT = typer.Option(
    None,
    "-e",
    "--export",
    help="Export format: markdown, xml, json, plain",
)

GROUP_BY = typer.Option(
    None,
    "-g",
    "--group-by",
    help="Group results by field",
)


# =============================================================================
# FILTER FLAGS
# =============================================================================

WHERE = Annotated[
    Optional[list[str]],
    typer.Option(
        "-w",
        "--where",
        help="Filter: field=value, field>=num. Repeatable.",
    ),
]


# =============================================================================
# SESSION FLAGS
# =============================================================================

SESSION_ID = typer.Option(
    None,
    "--session",
    help="Session ID to resume",
)

SESSION_NAME = typer.Option(
    None,
    "-n",
    "--name",
    help="Name for new session",
)


# =============================================================================
# SCHEMA FLAGS
# =============================================================================

SCHEMA_REF = typer.Option(
    None,
    "--schema",
    help="Schema name or UUID",
)

SCHEMA_FORMAT = typer.Option(
    None,
    "--schema-format",
    help="Schema format: json_schema, regex",
)

SCHEMA_DEF = typer.Option(
    None,
    "--schema-def",
    help="Schema definition (or @file)",
)


# =============================================================================
# CLEAR FLAGS (for update commands)
# =============================================================================

CLEAR_DESCRIPTION = typer.Option(
    False,
    "--clear-description",
    help="Clear the description",
)

CLEAR_TAGS = typer.Option(
    False,
    "--clear-tags",
    help="Remove all tags",
)


# =============================================================================
# DISPLAY FLAGS
# =============================================================================

FULL_OUTPUT = typer.Option(
    False,
    "--full",
    help="Show full content (no truncation)",
)

COPY_TO_CLIPBOARD = typer.Option(
    False,
    "--copy",
    help="Copy to clipboard",
)

STREAM = typer.Option(
    False,
    "--stream/--no-stream",
    help="Stream output",
)

SHOW_THINKING = typer.Option(
    True,
    "--thinking/--no-thinking",
    help="Show thinking blocks",
)

SHOW_FULL_TRACE = typer.Option(
    False,
    "--show-full-trace/--no-show-full-trace",
    help="Include the full ordered trace for the generated turn",
)


# =============================================================================
# CREDENTIAL FLAGS
# =============================================================================

CREDENTIAL_VALUE = typer.Option(
    ...,
    "--value",
    help="API key value (will be encrypted)",
)

CREDENTIAL_VALUE_OPTIONAL = typer.Option(
    None,
    "--value",
    help="API key value (will be encrypted)",
)


# =============================================================================
# COUNT/CONCURRENT FLAGS
# =============================================================================

COUNT = typer.Option(
    1,
    "--count",
    min=1,
    max=10,
    help="Number of concurrent executions",
)


# =============================================================================
# UPSERT FLAG
# =============================================================================

UPSERT = typer.Option(
    False,
    "--upsert",
    help="Return existing if name already exists",
)
