from pydantic import BaseModel

from alloy_runtime_types.dtos.pipeline import SetPipelineEnvVarsResponse

from cli.infrastructure.output import OutputService
from cli.infrastructure.renderers.entity_renderer import FieldConfig


class EnvVarsOutput(BaseModel):
    masked_values: str


def present_set_env_vars_result(response: SetPipelineEnvVarsResponse) -> None:
    output = OutputService.get()

    if not response.env_var_keys:
        output.result(
            action="clear",
            resource="pipeline_env_vars",
            identifier=str(response.pipeline_id),
            name=None,
        )
        return

    output.result(
        action="set",
        resource="pipeline_env_vars",
        identifier=str(response.pipeline_id),
        name=None,
        extra_fields={"Count": len(response.env_var_keys)},
    )
    output.entity(
        EnvVarsOutput(
            masked_values="\n".join(
                f"{key}: {response.masked_values.get(key, '***')}"
                for key in response.env_var_keys
            )
        ),
        "Pipeline Env Vars",
        [FieldConfig("masked_values", "Masked Values")],
    )
