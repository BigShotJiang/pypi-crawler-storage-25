"""Pipeline schedule delete command implementation."""

from uuid import UUID

import typer

from cli.commands.flag_utils import validate_uuid
from cli.commands.pipelines.schedules.presenter import present_delete_result
from cli.infrastructure.command import async_command, authenticated_client
from cli.infrastructure.console import Confirm


def pipelines_schedules_delete_command(
    pipeline_id: str = typer.Argument(
        ...,
        help="Pipeline UUID",
    ),
    schedule_id: str = typer.Argument(
        ...,
        help="Schedule UUID",
    ),
    yes: bool = typer.Option(
        False,
        "-y",
        "--yes",
        help="Skip confirmation",
    ),
) -> None:
    """Delete a pipeline schedule.

    Examples:
        alloy pipelines schedules delete 123e4567... 456e7890...
        alloy pipelines schedules delete 123e4567... 456e7890... -y
    """
    p_uuid = validate_uuid(pipeline_id, "pipeline")
    s_uuid = validate_uuid(schedule_id, "schedule")

    if not yes:
        confirmed = Confirm.ask(f"Delete schedule {schedule_id}?")
        if not confirmed:
            raise typer.Abort()

    _execute_delete(pipeline_id=p_uuid, schedule_id=s_uuid)


@async_command
async def _execute_delete(pipeline_id: UUID, schedule_id: UUID) -> None:
    """Execute delete schedule operation."""
    async with authenticated_client() as (_config, client):
        response = await client.delete_pipeline_schedule(pipeline_id, schedule_id)

    present_delete_result(response)
