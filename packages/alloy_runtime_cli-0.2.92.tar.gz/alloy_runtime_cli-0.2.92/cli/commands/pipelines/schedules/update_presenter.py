"""Presenter for pipeline schedule update command output."""

from alloy_runtime_types.dtos.schedule import UpdateScheduleResponse

from cli.infrastructure.output import OutputService
from cli.infrastructure.renderers.entity_renderer import FieldConfig


def present_update_result(response: UpdateScheduleResponse) -> None:
    """Present updated schedule details."""
    output = OutputService.get()

    fields = [
        FieldConfig("id", "Schedule ID", str),
        FieldConfig("name", "Name"),
        FieldConfig("is_enabled", "Enabled", lambda v: "Yes" if v else "No"),
        FieldConfig(
            "next_run_at",
            "Next Run",
            lambda v: v.strftime("%Y-%m-%d %H:%M:%S %Z") if v else "N/A",
        ),
        FieldConfig(
            "updated_at",
            "Updated",
            lambda v: v.strftime("%Y-%m-%d %H:%M:%S %Z") if v else "N/A",
        ),
    ]

    output.entity(response, f"Updated schedule: {response.name}", fields)
