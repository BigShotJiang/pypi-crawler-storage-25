"""Presenter for pipeline schedule once command output."""

from alloy_runtime_types.dtos.schedule import ScheduleOnceResponse

from cli.infrastructure.output import OutputService
from cli.infrastructure.renderers.entity_renderer import FieldConfig


def present_once_result(response: ScheduleOnceResponse) -> None:
    """Present scheduled one-time execution details."""
    output = OutputService.get()

    fields = [
        FieldConfig("id", "Execution ID", str),
        FieldConfig("pipeline_id", "Pipeline ID", str),
        FieldConfig(
            "scheduled_for",
            "Scheduled For",
            lambda v: v.strftime("%Y-%m-%d %H:%M:%S %Z") if v else "N/A",
        ),
        FieldConfig("timezone", "Timezone"),
        FieldConfig("status", "Status", lambda v: v.capitalize()),
        FieldConfig(
            "created_at",
            "Created",
            lambda v: v.strftime("%Y-%m-%d %H:%M:%S %Z") if v else "N/A",
        ),
    ]

    output.entity(response, "Scheduled one-time execution", fields)
