"""Presenter for pipeline schedule create command output."""

from alloy_runtime_types.dtos.schedule import CreateScheduleResponse

from cli.infrastructure.output import OutputService
from cli.infrastructure.renderers.entity_renderer import FieldConfig


def present_create_result(response: CreateScheduleResponse) -> None:
    """Present created schedule details."""
    output = OutputService.get()

    from cli.infrastructure.formatting.fields import format_optional

    fields = [
        FieldConfig("id", "Schedule ID", str),
        FieldConfig("pipeline_id", "Pipeline ID", str),
        FieldConfig("name", "Name"),
        FieldConfig("description", "Description", format_optional),
        FieldConfig("schedule_type", "Type"),
        FieldConfig("timezone", "Timezone"),
        FieldConfig("is_enabled", "Enabled", lambda v: "Yes" if v else "No"),
        FieldConfig(
            "next_run_at",
            "Next Run",
            lambda v: v.strftime("%Y-%m-%d %H:%M:%S %Z") if v else "N/A",
        ),
        FieldConfig(
            "created_at",
            "Created",
            lambda v: v.strftime("%Y-%m-%d %H:%M:%S %Z") if v else "N/A",
        ),
    ]

    output.entity(response, f"Created schedule: {response.name}", fields)
