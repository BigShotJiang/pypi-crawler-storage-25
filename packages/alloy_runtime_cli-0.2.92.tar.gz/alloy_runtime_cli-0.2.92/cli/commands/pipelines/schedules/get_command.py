"""Pipeline schedule get command implementation."""

from uuid import UUID

import typer

from cli.commands.flag_utils import validate_uuid
from cli.commands.pipelines.schedules.presenter import present_schedule_detail
from cli.infrastructure.command import async_command, authenticated_client


def pipelines_schedules_get_command(
    pipeline_id: str = typer.Argument(
        ...,
        help="Pipeline UUID",
    ),
    schedule_id: str = typer.Argument(
        ...,
        help="Schedule UUID",
    ),
) -> None:
    """Get details of a pipeline schedule.

    Examples:
        alloy pipelines schedules get 123e4567... 456e7890...
    """
    p_uuid = validate_uuid(pipeline_id, "pipeline")
    s_uuid = validate_uuid(schedule_id, "schedule")
    _execute_get(pipeline_id=p_uuid, schedule_id=s_uuid)


@async_command
async def _execute_get(pipeline_id: UUID, schedule_id: UUID) -> None:
    """Execute get schedule operation."""
    async with authenticated_client() as (_config, client):
        response = await client.get_pipeline_schedule(pipeline_id, schedule_id)

    present_schedule_detail(response)
