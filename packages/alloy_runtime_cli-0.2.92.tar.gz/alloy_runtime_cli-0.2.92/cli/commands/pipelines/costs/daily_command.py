"""Pipeline daily costs command implementation."""

from uuid import UUID

import typer

from cli.commands.flag_utils import validate_uuid
from cli.commands.pipelines.costs.daily_presenter import present_pipeline_daily_costs
from cli.infrastructure.command import async_command, authenticated_client


def pipeline_costs_daily_command(
    pipeline_id: str = typer.Argument(
        ...,
        help="Pipeline UUID",
    ),
    start_date: str = typer.Option(
        ...,
        "--from",
        help="Start date (ISO 8601, required)",
    ),
    end_date: str = typer.Option(
        ...,
        "--to",
        help="End date (ISO 8601, required)",
    ),
) -> None:
    """Get daily cost breakdown for a pipeline.

    Examples:
        alloy pipelines costs daily 123e4567-89ab... --from 2026-01-01 --to 2026-01-31
    """
    pipeline_uuid = validate_uuid(pipeline_id, "pipeline")
    _execute_daily_costs(
        pipeline_id=pipeline_uuid,
        start_date=start_date,
        end_date=end_date,
    )


@async_command
async def _execute_daily_costs(
    pipeline_id: UUID,
    start_date: str,
    end_date: str,
) -> None:
    async with authenticated_client() as (_config, client):
        response = await client.get_pipeline_costs_daily(
            pipeline_id,
            start_date=start_date,
            end_date=end_date,
        )

    present_pipeline_daily_costs(response)
