"""Presenter for pipeline execution costs command output."""

from decimal import Decimal

from alloy_runtime_types.dtos.pipeline_costs import PipelineExecutionCostSummary

from cli.infrastructure.output import OutputService
from cli.infrastructure.renderers.entity_renderer import FieldConfig


def _format_cost(cost: Decimal | None) -> str:
    if cost is None:
        return "-"
    return f"${cost:.4f}"


def present_execution_costs(response: PipelineExecutionCostSummary) -> None:
    output = OutputService.get()

    fields = [
        FieldConfig("pipeline_execution_id", "Execution ID", str),
        FieldConfig("llm_cost_usd", "LLM Cost", _format_cost),
        FieldConfig("rag_cost_usd", "RAG Cost", _format_cost),
        FieldConfig("total_cost_usd", "Total Cost", _format_cost),
        FieldConfig("agent_execution_count", "Agent Executions", str),
        FieldConfig("retrieval_count", "RAG Retrievals", str),
    ]

    output.entity(response, "Execution Cost Summary", fields, raw_payload=response)
