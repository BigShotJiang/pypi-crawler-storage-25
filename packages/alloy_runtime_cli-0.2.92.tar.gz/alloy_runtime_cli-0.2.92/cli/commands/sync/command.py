"""Sync command implementation - simplified."""

from cli.commands.sync.presenter import present_sync_models_success
from cli.infrastructure.command import async_command, authenticated_client
from cli.infrastructure.spinner import spinner


def sync_command() -> None:
    """Sync AI models from provider sources.

    Requires system admin privileges. This command pulls the latest model
    information from configured AI providers and updates the local database.

    The sync process:
    1. Fetches models from Models.dev API
    2. Fetches models from OpenRouter API
    3. Upserts providers and provider models to database
    4. Uses exact provider model names (no canonical name mapping)

    Example:
        alloy admin sync models

    Note:
        This is an admin-only operation that requires appropriate credentials.
    """
    _execute_sync()


@async_command
async def _execute_sync() -> None:
    """Execute sync operation.

    Raises:
        ConfigurationError: If environment variables are missing
        AuthenticationError: If API key is invalid
        ForbiddenError: If user lacks admin privileges
        ServerError: If server returns 5xx error
    """
    async with authenticated_client() as (_config, client):
        async with spinner("Fetching models from providers..."):
            response = await client.sync_models()

    present_sync_models_success(response)
