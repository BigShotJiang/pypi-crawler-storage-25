"""Tags get command implementation."""

from uuid import UUID
import typer

from cli.commands.tags.get.presenter import present_tag_details
from cli.commands.flag_utils import validate_uuid
from cli.infrastructure.command import async_command, authenticated_client


def tags_get_command(
    tag_id: str = typer.Argument(
        ...,
        help="Tag UUID",
    ),
) -> None:
    """Get details of a single tag.

    Examples:
        alloy tags get 123e4567-89ab-cdef-0123-456789abcdef
    """
    tag_uuid = validate_uuid(tag_id, "tag")
    _execute_get(tag_id=tag_uuid)


@async_command
async def _execute_get(tag_id: UUID) -> None:
    async with authenticated_client() as (_config, client):
        response = await client.get_tag(tag_id)

    present_tag_details(response)
