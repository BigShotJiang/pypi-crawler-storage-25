"""Tags update command implementation."""

from typing import Optional
from uuid import UUID

import typer

from cli.commands.tags.update.presenter import present_update_result
from cli.commands.flag_utils import validate_uuid, require_update_flags
from cli.infrastructure.command import async_command, authenticated_client
from alloy_runtime_types.dtos.tags import UpdateTagRequest


def tags_update_command(
    tag_id: str = typer.Argument(
        ...,
        help="Tag UUID",
    ),
    display_name: Optional[str] = typer.Option(
        None,
        "-n",
        "--display-name",
        help="New display name",
    ),
    description: Optional[str] = typer.Option(
        None,
        "-d",
        "--description",
        help="New description",
    ),
) -> None:
    """Update a tag's display name or description.

    Examples:
        alloy tags update 123e4567-89ab... -n "New Name"
        alloy tags update 123e4567-89ab... -d "New description"
    """
    require_update_flags(
        ("--display-name", display_name),
        ("--description", description),
    )

    tag_uuid = validate_uuid(tag_id, "tag")
    _execute_update(
        tag_id=tag_uuid,
        display_name=display_name,
        description=description,
    )


@async_command
async def _execute_update(
    tag_id: UUID,
    display_name: Optional[str],
    description: Optional[str],
) -> None:
    request = UpdateTagRequest(
        display_name=display_name,
        description=description,
    )
    async with authenticated_client() as (_config, client):
        response = await client.update_tag(tag_id, request)

    present_update_result(response)
