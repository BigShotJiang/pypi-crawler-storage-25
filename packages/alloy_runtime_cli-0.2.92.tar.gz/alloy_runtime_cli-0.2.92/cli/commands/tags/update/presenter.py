"""Presenter for tags update command output."""

from cli.infrastructure.output import OutputService
from alloy_runtime_types.dtos.tags import UpdateTagResponse


def present_update_result(response: UpdateTagResponse) -> None:
    output = OutputService.get()
    output.result(
        action="update",
        resource="tag",
        identifier=str(response.tag.id),
        name=response.tag.tag_path,
    )
