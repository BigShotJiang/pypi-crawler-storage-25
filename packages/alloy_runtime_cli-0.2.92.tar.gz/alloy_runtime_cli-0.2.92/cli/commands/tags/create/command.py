"""Tag create command implementation."""

from typing import Optional

import typer

from cli.infrastructure.command import async_command, authenticated_client
from cli.infrastructure.output import OutputService

from alloy_runtime_types.dtos.tags import CreateTagRequest


def tags_create_command(
    tag_path: str = typer.Argument(
        ...,
        help="Hierarchical tag path (e.g., 'marketing.email.weekly')",
    ),
    display_name: Optional[str] = typer.Option(
        None,
        "-n",
        "--name",
        help="Human-friendly display name",
    ),
    description: Optional[str] = typer.Option(
        None,
        "-d",
        "--description",
        help="Tag description",
    ),
) -> None:
    """Create a new tag.

    Examples:
        alloy tags create marketing.email
        alloy tags create marketing.email.weekly -n "Weekly Emails"
    """
    _execute_create(
        tag_path=tag_path,
        display_name=display_name,
        description=description,
    )


@async_command
async def _execute_create(
    tag_path: str,
    display_name: Optional[str],
    description: Optional[str],
) -> None:
    """Execute create tag operation."""
    async with authenticated_client() as (_config, client):
        request = CreateTagRequest(
            tag_path=tag_path,
            display_name=display_name,
            description=description,
        )
        response = await client.create_tag(request)

    output = OutputService.get()
    output.result(
        action="create",
        resource="tag",
        identifier=str(response.tag.id),
        name=response.tag.tag_path,
    )
