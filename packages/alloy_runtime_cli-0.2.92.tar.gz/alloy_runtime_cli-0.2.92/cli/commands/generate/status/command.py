"""Async generation status command implementation."""

import typer

from cli.commands.generate.status.presenter import present_generation_status
from cli.infrastructure.command import async_command, authenticated_client


def generate_status_command(
    execution_id: str = typer.Argument(
        ...,
        help="Execution UUID of the async generation",
    ),
    watch: bool = typer.Option(
        False,
        "--watch",
        help="Poll until generation reaches terminal state",
    ),
    timeout: float = typer.Option(
        300.0,
        "--timeout",
        help="Maximum seconds to wait when using --watch (default: 300)",
    ),
) -> None:
    """Get status of an async generation.

    Check the status and result of a previously submitted async generation.
    Use --watch to poll until completion.

    Examples:
        alloy generate status 123e4567-89ab-cdef-0123-456789abcdef
        alloy generate status 123e4567-... --watch
        alloy generate status 123e4567-... --watch --timeout 600
    """
    _execute_status(
        execution_id=execution_id,
        watch=watch,
        timeout=timeout,
    )


@async_command
async def _execute_status(
    execution_id: str,
    watch: bool,
    timeout: float,
) -> None:
    """Execute status operation."""
    async with authenticated_client() as (_config, client):
        if watch:
            response = await client.wait_for_generation(
                execution_id,
                timeout=timeout,
            )
        else:
            response = await client.get_generation(execution_id)

    present_generation_status(response)
