from decimal import Decimal
from typing import Any, cast

from pydantic import BaseModel

from cli.infrastructure.output import OutputFormat, OutputService
from cli.infrastructure.renderers.entity_renderer import FieldConfig
from cli.infrastructure.renderers.list_renderer import ColumnConfig
from alloy_runtime_types.dtos.generation import (
    GenerateTextResponse,
    GenerationFullTrace,
)


class GeneratedTextOutput(BaseModel):
    output_text: str


class AggregatedUsageOutput(BaseModel):
    executions: int
    input_tokens: int
    output_tokens: int
    total_tokens: int


class AggregatedCostOutput(BaseModel):
    executions: int
    input_cost_usd: Decimal
    output_cost_usd: Decimal
    cache_cost_usd: Decimal | None = None
    total_cost_usd: Decimal


def _format_optional_text(value: str | None) -> Any:
    if value is None:
        return cast(str, None)
    return value


def _format_optional_identifier(value: object | None) -> Any:
    if value is None:
        return cast(str, None)
    return str(value)


def _format_tags(value: list[str]) -> Any:
    if not value:
        return cast(str, None)
    return ", ".join(value)


def _format_total_tokens(response: GenerateTextResponse) -> str:
    return str(response.usage.input_tokens + response.usage.output_tokens)


def _format_reasoning_tokens(usage: Any) -> Any:
    reasoning_tokens = getattr(usage, "reasoning_tokens", None)
    if reasoning_tokens is None:
        return cast(str, None)
    return str(reasoning_tokens)


def _format_content_parts(parts: list[Any]) -> str:
    if not parts:
        return "-"
    first_part: Any = parts[0]
    return getattr(first_part, "content_text", None) or "-"


def _format_cost(value: Decimal | None) -> Any:
    if value is None:
        return cast(str, None)
    return f"${value:.6f}"


class GenerateTextPresenter:
    def __init__(self, output: OutputService):
        self.output = output

    def present_result(
        self,
        response: GenerateTextResponse,
        show_metadata: bool = True,
        *,
        metadata_title: str = "Generation Result",
        output_title: str = "Generated Text",
        execution_label: str | None = None,
    ) -> None:
        if getattr(self.output, "format", OutputFormat.COMPACT) == OutputFormat.JSON:
            self.output.raw(response)
            return

        if show_metadata:
            metadata_fields = [
                FieldConfig("execution_id", "Execution ID", str),
                FieldConfig(
                    "chat_session_id",
                    "Session ID",
                    _format_optional_identifier,
                ),
                FieldConfig(
                    "assistant_message_id",
                    "Assistant Message ID",
                    _format_optional_identifier,
                ),
                FieldConfig(
                    "primary_content_part_id",
                    "Primary Content Part ID",
                    _format_optional_identifier,
                ),
                FieldConfig("model", "Model"),
                FieldConfig("finish_reason", "Finish Reason"),
                FieldConfig("output_incomplete", "Output Incomplete"),
                FieldConfig(
                    "usage", "Input Tokens", lambda usage: str(usage.input_tokens)
                ),
                FieldConfig(
                    "usage", "Output Tokens", lambda usage: str(usage.output_tokens)
                ),
                FieldConfig(
                    "usage",
                    "Reasoning Tokens",
                    _format_reasoning_tokens,
                ),
                FieldConfig(
                    "usage",
                    "Total Tokens",
                    lambda _: _format_total_tokens(response),
                ),
                FieldConfig(
                    "cost",
                    "Input Cost",
                    lambda cost: _format_cost(cost.input_cost_usd),
                ),
                FieldConfig(
                    "cost",
                    "Output Cost",
                    lambda cost: _format_cost(cost.output_cost_usd),
                ),
                FieldConfig(
                    "cost",
                    "Cache Cost",
                    lambda cost: _format_cost(cost.cache_cost_usd),
                ),
                FieldConfig(
                    "cost",
                    "Total Cost",
                    lambda cost: _format_cost(cost.total_cost_usd),
                ),
                FieldConfig("tags", "Tags", _format_tags),
                FieldConfig("external_id", "External ID", _format_optional_text),
            ]
            if execution_label is not None:
                metadata_fields.insert(
                    0,
                    FieldConfig("execution_id", "Execution", lambda _: execution_label),
                )

            self.output.entity(
                response,
                metadata_title,
                metadata_fields,
                raw_payload=response,
            )

        self.present_text_output(response.output_text, title=output_title)
        if response.full_trace is not None:
            self.present_full_trace(response.full_trace)

    def present_multiple_results(
        self,
        responses: list[GenerateTextResponse],
        show_metadata: bool = True,
        *,
        indices: list[int] | None = None,
        total: int | None = None,
    ) -> None:
        if getattr(self.output, "format", OutputFormat.COMPACT) == OutputFormat.JSON:
            self.output.raw(responses)
            return

        total_count = total if total is not None else len(responses)
        result_indices = (
            indices if indices is not None else list(range(1, len(responses) + 1))
        )

        for result_index, response in zip(result_indices, responses, strict=True):
            suffix = f"{result_index}/{total_count}"
            self.present_result(
                response,
                show_metadata=show_metadata,
                metadata_title=f"Generation Result {suffix}",
                output_title=f"Generated Text {suffix}",
                execution_label=suffix,
            )

        if show_metadata and responses:
            self._present_aggregated_usage(responses)
            self._present_aggregated_costs(responses)

    def present_text_output(
        self, content: str, *, title: str = "Generated Text"
    ) -> None:
        output = GeneratedTextOutput(output_text=content)
        self.output.entity(
            output,
            title,
            [FieldConfig("output_text", "Output")],
            raw_payload=output,
        )

    def present_full_trace(self, trace: GenerationFullTrace) -> None:
        self.output.table(
            items=cast(list[BaseModel], trace.messages),
            title=f"Full Trace ({trace.finish_reason})",
            columns=[
                ColumnConfig(
                    source_field="sequence_number",
                    header_label="#",
                    align="right",
                    compact_line=1,
                    compact_style="cyan",
                ),
                ColumnConfig(
                    source_field="role",
                    header_label="Role",
                    compact_line=1,
                    compact_style="yellow",
                ),
                ColumnConfig(
                    source_field="created_at",
                    header_label="Time",
                    formatter=lambda value: (
                        value.strftime("%H:%M:%S") if value else "-"
                    ),
                    compact_line=1,
                    compact_style="blue",
                ),
                ColumnConfig(
                    source_field="content_parts",
                    header_label="Content",
                    formatter=_format_content_parts,
                    compact_line=2,
                    compact_style="dim",
                ),
            ],
            raw_payload=trace,
            total_count=len(trace.messages),
        )

    def _present_aggregated_usage(self, responses: list[GenerateTextResponse]) -> None:
        total_input = sum(response.usage.input_tokens for response in responses)
        total_output = sum(response.usage.output_tokens for response in responses)
        aggregated = AggregatedUsageOutput(
            executions=len(responses),
            input_tokens=total_input,
            output_tokens=total_output,
            total_tokens=total_input + total_output,
        )
        self.output.entity(
            aggregated,
            "Aggregated Token Usage",
            [
                FieldConfig("executions", "Executions", str),
                FieldConfig("input_tokens", "Input Tokens", str),
                FieldConfig("output_tokens", "Output Tokens", str),
                FieldConfig("total_tokens", "Total Tokens", str),
            ],
            raw_payload=aggregated,
        )

    def _present_aggregated_costs(self, responses: list[GenerateTextResponse]) -> None:
        zero = Decimal("0")
        aggregated = AggregatedCostOutput(
            executions=len(responses),
            input_cost_usd=sum(
                (response.cost.input_cost_usd for response in responses),
                start=zero,
            ),
            output_cost_usd=sum(
                (response.cost.output_cost_usd for response in responses),
                start=zero,
            ),
            cache_cost_usd=sum(
                ((response.cost.cache_cost_usd or zero) for response in responses),
                start=zero,
            ),
            total_cost_usd=sum(
                (response.cost.total_cost_usd for response in responses),
                start=zero,
            ),
        )
        self.output.entity(
            aggregated,
            "Aggregated Cost Breakdown",
            [
                FieldConfig("executions", "Executions", str),
                FieldConfig("input_cost_usd", "Input Cost", _format_cost),
                FieldConfig("output_cost_usd", "Output Cost", _format_cost),
                FieldConfig("cache_cost_usd", "Cache Cost", _format_cost),
                FieldConfig("total_cost_usd", "Total Cost", _format_cost),
            ],
            raw_payload=aggregated,
        )
