"""Field definitions for system credential grant presentation."""

from typing import Any

from cli.infrastructure.formatting.fields import format_datetime, format_uuid
from cli.infrastructure.renderers.entity_renderer import FieldConfig


def format_optional_uuid(value: Any) -> str:
    """Format optional UUID value."""
    return format_uuid(value, short=False) if value else "(not set)"


def format_optional_datetime(value: Any) -> str:
    """Format optional datetime value."""
    return format_datetime(value) if value else "(not set)"


GRANT_FIELDS: list[FieldConfig] = [
    FieldConfig("id", "Grant ID", lambda v: format_uuid(v, short=False)),
    FieldConfig(
        "credential_id", "Credential ID", lambda v: format_uuid(v, short=False)
    ),
    FieldConfig("organization_id", "Organization ID", format_optional_uuid),
    FieldConfig("user_id", "User ID", format_optional_uuid),
    FieldConfig(
        "granted_by_user_id",
        "Granted By User ID",
        lambda v: format_uuid(v, short=False),
    ),
    FieldConfig("granted_at", "Granted At", format_datetime),
    FieldConfig("expires_at", "Expires At", format_optional_datetime),
]
