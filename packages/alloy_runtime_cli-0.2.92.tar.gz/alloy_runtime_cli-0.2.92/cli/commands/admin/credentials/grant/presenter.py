"""Presenter for admin credentials grant command output."""

from cli.commands.admin.credentials.grant.fields import GRANT_FIELDS
from cli.infrastructure.output import OutputService
from alloy_runtime_types.dtos.credentials import GrantSystemCredentialResponse


def present_grant_success(grant: GrantSystemCredentialResponse) -> None:
    """Present a successful credential grant with Rich formatting.

    Args:
        grant: Created grant data from server
    """
    output = OutputService.get()

    # Determine target type for success message
    if grant.organization_id:
        target = f"organization {grant.organization_id}"
    else:
        target = f"user {grant.user_id}"

    output.result(
        action="grant",
        resource="system_credential_access",
        identifier=str(grant.id),
        name=target,
    )
    output.entity(
        grant, "System Credential Grant Details", GRANT_FIELDS, raw_payload=grant
    )
