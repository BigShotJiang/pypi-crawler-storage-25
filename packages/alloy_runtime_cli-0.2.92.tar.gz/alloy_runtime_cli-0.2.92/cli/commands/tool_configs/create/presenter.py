"""Presenter for tool config creation output."""

from cli.commands.tool_configs.get.presenter import present_tool_config_details
from cli.infrastructure.output import OutputService
from alloy_runtime_types.dtos.tool_configs import CreateToolConfigResponse


def present_tool_config_create_success(response: CreateToolConfigResponse) -> None:
    """Present successful tool config creation.

    Args:
        response: Tool config creation response from server
    """
    output = OutputService.get()

    output.result(
        action="create",
        resource="tool_config",
        identifier=str(response.id),
        name=response.name,
    )
    present_tool_config_details(response)
