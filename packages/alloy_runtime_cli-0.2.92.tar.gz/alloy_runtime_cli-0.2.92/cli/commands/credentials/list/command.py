"""Credentials list command implementation."""

from cli.commands.credentials.list.presenter import present_credentials_list
from cli.infrastructure.command import async_command, authenticated_client


def credentials_list_command() -> None:
    """List organization credentials."""
    _execute_list()


@async_command
async def _execute_list() -> None:
    async with authenticated_client() as (_config, client):
        response = await client.list_organization_credentials()

    present_credentials_list(response)
