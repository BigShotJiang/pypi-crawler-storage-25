"""Field definitions for organization credential presentation."""

from typing import Any, cast

from cli.infrastructure.formatting.fields import format_datetime
from cli.infrastructure.renderers.entity_renderer import FieldConfig


def format_optional_datetime(value: Any) -> str:
    """Format optional datetime value."""
    return format_datetime(value) if value else "(not set)"


def format_optional_provider(value: Any) -> str:
    """Format optional provider value."""
    return value.value if value else "(not set)"


def format_optional_string(value: Any) -> str:
    """Format optional string value."""
    return cast(str, value) if value else "(not set)"


ORG_CREDENTIAL_FIELDS: list[FieldConfig] = [
    FieldConfig("id", "ID", lambda v: str(v)),
    FieldConfig("name", "Name"),
    FieldConfig("description", "Description", format_optional_string),
    FieldConfig("credential_type_id", "Credential Type"),
    FieldConfig("provider_key", "Provider", format_optional_provider),
    FieldConfig("service_key", "Service", format_optional_provider),
    FieldConfig("tool_id", "Tool ID", format_optional_string),
    FieldConfig("value_prefix", "Value Prefix", format_optional_string),
    FieldConfig("organization_id", "Organization ID", lambda v: str(v)),
    FieldConfig("is_active", "Is Active", lambda v: "Yes" if v else "No"),
    FieldConfig("created_at", "Created", format_datetime),
    FieldConfig("updated_at", "Updated", format_datetime),
    FieldConfig("last_used_at", "Last Used", format_optional_datetime),
    FieldConfig("expires_at", "Expires", format_optional_datetime),
]
