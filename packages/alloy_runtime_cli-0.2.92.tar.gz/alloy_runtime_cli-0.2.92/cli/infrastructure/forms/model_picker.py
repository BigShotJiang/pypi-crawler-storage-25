"""Model picker widget with search and single selection.

A search input that uses the ApiClient to fetch models on each keystroke,
displaying results in a static list below. Users can select one model
using Space or Enter.
"""

from typing import Any

from textual import on
from textual.widgets import OptionList

from alloy_runtime_sdk.api_client.client import ApiClient
from alloy_runtime_types.dtos.models import ModelListItemResponse

from cli.infrastructure.forms.base_picker import SingleSelectPicker


class ModelPicker(SingleSelectPicker[ModelListItemResponse]):
    """Single-select model picker with live search.

    Uses the ApiClient to fetch models on each keystroke. Results appear in a
    static box below the search input.

    Usage:
        yield ModelPicker(
            client=server_client,
            id="models"
        )

        # Get selected model
        picker = self.query_one("#models", ModelPicker)
        model = picker.selected_model  # ModelListItemResponse | None

    Keybindings:
        - Type to search (fetches from API)
        - Up/Down to navigate results
        - Space or Enter to select/deselect
    """

    def __init__(
        self,
        client: ApiClient,
        placeholder: str = "Type to search models (e.g., gpt-4, claude, sonnet)...",
        **kwargs: Any,
    ) -> None:
        """Initialize the model picker.

        Args:
            client: ApiClient instance for API calls
            placeholder: Placeholder text for search input
        """
        super().__init__(
            client=client,
            placeholder=placeholder,
            empty_message="No model selected",
            **kwargs,
        )

    @property
    def selected_model(self) -> ModelListItemResponse | None:
        """Get the selected model."""
        return self.selected_item

    async def _fetch_items(self, query: str) -> list[ModelListItemResponse]:
        """Fetch models matching query from the API."""
        response = await self._client.list_models(
            search=query,
            configured_only=True,
            limit=100,
        )
        return list(response.models)

    def _format_item(self, item: ModelListItemResponse) -> str:
        """Format model for display in option list."""
        return item.model

    def _get_item_id(self, item: ModelListItemResponse) -> str:
        """Get unique identifier for a model."""
        return item.model

    def _get_result_count_message(self, count: int) -> str:
        """Get status message for result count."""
        if count == 0:
            return "No models found"
        return f"{count} model{'s' if count != 1 else ''} found - Space/Enter to select"

    def on_key(self, event: Any) -> None:
        """Handle space key to toggle selection."""
        if event.key == "space":
            options = self.query_one("#search-options", OptionList)
            if options.highlighted is not None:
                self._handle_item_selection(options.highlighted)
                event.prevent_default()
                event.stop()

    @on(OptionList.OptionHighlighted, "#search-options")
    def on_option_highlighted(self, event: OptionList.OptionHighlighted) -> None:
        """Handle highlighting - space key handling is done via on_key."""
        del event
        pass

    def set_initial_model(self, model: ModelListItemResponse) -> None:
        """Pre-populate the picker with an existing model selection.

        Args:
            model: ModelListItemResponse object to pre-select
        """
        self.set_initial_selection(model)
