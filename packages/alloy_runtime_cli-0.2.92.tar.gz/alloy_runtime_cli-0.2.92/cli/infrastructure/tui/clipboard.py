"""Clipboard utilities for TUI applications."""

import pyperclip
from typing import Literal, Protocol


SeverityLevel = Literal["information", "warning", "error"]


class SupportsNotify(Protocol):
    """Minimal app protocol for clipboard notifications."""

    def notify(
        self,
        message: str,
        *,
        title: str = "",
        severity: SeverityLevel = "information",
        timeout: float | None = None,
        markup: bool = True,
    ) -> None: ...


def copy_to_clipboard(app: SupportsNotify, text: str, label: str = "ID") -> bool:
    """Copy text to clipboard with user notification.

    Args:
        app: The Textual app instance (for notifications)
        text: The text to copy
        label: Label for the notification message (e.g., "ID", "Version ID")

    Returns:
        True if copy succeeded, False otherwise
    """
    try:
        pyperclip.copy(text)
        app.notify(f"Copied {label}: {text}", severity="information")
        return True
    except Exception as e:
        app.notify(f"Copy failed: {e}", severity="error")
        return False
