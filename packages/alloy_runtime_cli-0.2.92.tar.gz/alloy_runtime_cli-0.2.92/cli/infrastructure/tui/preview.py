"""Preview pane formatting utilities for TUI applications."""


def format_preview_field(label: str, value: str) -> str:
    """Format a single label/value pair for preview pane using Rich markup.

    Args:
        label: The field label (e.g., "ID", "Name")
        value: The field value

    Returns:
        Formatted string with Rich markup
    """
    return f"[bold]{label}:[/] {value}"
