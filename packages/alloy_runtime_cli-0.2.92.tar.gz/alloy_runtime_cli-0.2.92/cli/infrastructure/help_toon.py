from importlib import import_module
from typing import Any


TOON_FORMAT_INSTALL_HINT = (
    "Install with `pip install git+https://github.com/toon-format/toon-python.git`"
)


class HelpToonUnavailableError(RuntimeError):
    pass


def render_help_toon(payload: dict[str, Any]) -> str:
    try:
        module = import_module("toon_format")
    except ModuleNotFoundError:
        raise HelpToonUnavailableError(
            "--help-toon requires the optional `toon-format` dependency."
        ) from None
    encode = getattr(module, "encode")
    return str(encode(payload))
