# -*- coding: utf-8 -*-
#
#   Ming-Ke-Ming : Decentralized User Identity Authentication
#
#                                Written in 2020 by Moky <albert.moky@gmail.com>
#
# ==============================================================================
# MIT License
#
# Copyright (c) 2020 Albert Moky
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
# ==============================================================================

from typing import Optional

from dimsdk import Meta
from dimplugins import DefaultMeta, BTCMeta, ETHMeta
from dimplugins import BaseMetaFactory

from ..mkm import MetaUtils


class CompatibleMetaFactory(BaseMetaFactory):

    def __init__(self, version: str):
        super().__init__(version=version)

    # Override
    def parse_meta(self, meta: dict) -> Optional[Meta]:
        version = MetaUtils.get_meta_type(meta=meta)
        if version == 'MKM' or version == 'mkm' or version == '1':
            # MKM
            out = DefaultMeta(meta=meta)
        elif version == 'BTC' or version == 'btc' or version == '2':
            # BTC
            out = BTCMeta(meta=meta)
        elif version == 'ETH' or version == 'eth' or version == '4':
            # ETH
            out = ETHMeta(meta=meta)
        else:
            # TODO: other types of meta
            raise TypeError('unknown meta type: %s' % version)
        if out.is_valid:
            return out
