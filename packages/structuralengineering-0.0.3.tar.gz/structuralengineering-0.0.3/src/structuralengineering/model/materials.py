# Copyright 2026 Superstructure GbR
# SPDX-License-Identifier: Apache-2.0
#
# Preset Material instances for common structural steel grades.
#
# Source standard:   EN 10025-2:2019 "Hot rolled products of
#                    structural steels — Part 2: Technical delivery
#                    conditions for non-alloy structural steels"
# Scope:             nominal thickness t ≤ 16 mm
# Property values:   f_y (ReH) and f_u (Rm) per EN 10025-2 Table 7.
#                    E, ν, ρ are conventional values used throughout
#                    structural engineering practice and are not
#                    copyrightable facts.
"""Preset Material instances for common structural steel grades."""

from __future__ import annotations

from structuralengineering.model.v1.material_pb2 import Material

__all__ = [
    "STEEL_DENSITY",
    "STEEL_E_MODULUS",
    "STEEL_POISSON_RATIO",
    "s235",
    "s275",
    "s355",
]

#: Elastic modulus of structural steel [Pa].
STEEL_E_MODULUS = 210e9

#: Poisson's ratio of structural steel.
STEEL_POISSON_RATIO = 0.3

#: Density of structural steel [kg/m^3].
STEEL_DENSITY = 7850.0


def s235() -> Material:
    """EN 10025-2 S235 structural steel (nominal thickness ≤ 16 mm)."""
    return Material(
        id="S235",
        name="S235 (EN 10025-2)",
        f_y=235e6,
        f_u=360e6,
        e_modulus=STEEL_E_MODULUS,
        poisson_ratio=STEEL_POISSON_RATIO,
        density=STEEL_DENSITY,
    )


def s275() -> Material:
    """EN 10025-2 S275 structural steel (nominal thickness ≤ 16 mm)."""
    return Material(
        id="S275",
        name="S275 (EN 10025-2)",
        f_y=275e6,
        f_u=430e6,
        e_modulus=STEEL_E_MODULUS,
        poisson_ratio=STEEL_POISSON_RATIO,
        density=STEEL_DENSITY,
    )


def s355() -> Material:
    """EN 10025-2 S355 structural steel (nominal thickness ≤ 16 mm)."""
    return Material(
        id="S355",
        name="S355 (EN 10025-2)",
        f_y=355e6,
        f_u=490e6,
        e_modulus=STEEL_E_MODULUS,
        poisson_ratio=STEEL_POISSON_RATIO,
        density=STEEL_DENSITY,
    )
