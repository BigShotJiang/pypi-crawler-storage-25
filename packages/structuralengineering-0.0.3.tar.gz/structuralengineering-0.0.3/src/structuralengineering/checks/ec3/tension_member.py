# Copyright 2026 Superstructure GbR
# SPDX-License-Identifier: Apache-2.0
#
# EC3-1-1 §6.2.3(2)a — tension-member gross-section yielding.
#
# Source standard:   EN 1993-1-1:2005 + AC:2009
# Clause:            §6.2.3(2)a
# Scope implemented: gross-section yielding only
#                    (N_t,Rd = A · f_y / γ_M0)
# Out of scope:      net-section rupture (§6.2.3(2)b)
#                    block tearing (§3.10.2)
#                    ductility limits on elongation (§3.2.2(2))
#
# Clean-room declaration:
#   This implementation of the EN 1993-1-1 §6.2.3(2)a clause was derived
#   independently from the clean-room sources permitted by
#   docs/clean-room-policy.md. The formula `N_t,Rd = A · f_y / γ_M0` is
#   a mathematical identity appearing in standard structural engineering
#   textbooks; the arrangement and naming of intermediate values here is
#   our own.
"""Design check for a member in axial tension — gross-section yielding."""

from __future__ import annotations

from structuralengineering.checks.ec3.v1.tension_member_pb2 import (
    TensionMemberCheckRequest,
    TensionMemberCheckResponse,
)
from structuralengineering.checks.v1.check_status_pb2 import CheckStatus
from structuralengineering.checks.v1.design_check_result_pb2 import DesignCheckResult
from structuralengineering.results.v1.intermediate_value_pb2 import IntermediateValue
from structuralengineering.results.v1.warning_pb2 import Warning as SEWarning

_CHECK_ID = "EC3-1-1_6.2.3"
_CHECK_NAME = "Tension member — gross-section yielding (EC3-1-1 §6.2.3(2)a)"
_CLAUSE_REF = "EN 1993-1-1:2005 §6.2.3(2)a"
_DEFAULT_GAMMA_M0 = 1.0


def check_tension_member(
    area: float,
    f_y: float,
    n_ed: float,
    gamma_m0: float | None = None,
    request_id: str | None = None,
) -> TensionMemberCheckResponse:
    """Run the EC3-1-1 §6.2.3(2)a gross-section yielding check.

    Args:
        area: Gross cross-sectional area A [m^2].
        f_y: Characteristic yield stress f_y [Pa].
        n_ed: Design tensile force N_Ed [N].
        gamma_m0: Partial safety factor γ_M0. Defaults to 1.0 if omitted,
            matching the EN 1993-1-1 §6.1(1) recommended value.
        request_id: Optional tracing identifier, echoed in the result.

    Returns:
        A ``TensionMemberCheckResponse`` containing the full
        ``DesignCheckResult`` plus a convenience ``n_t_rd`` mirror.
    """
    req = TensionMemberCheckRequest(
        area=area,
        f_y=f_y,
        n_ed=n_ed,
        gamma_m0=gamma_m0 if gamma_m0 is not None else None,
    )
    return _run(req, request_id=request_id)


def run(
    request: TensionMemberCheckRequest,
    request_id: str | None = None,
) -> TensionMemberCheckResponse:
    """Run the check on a pre-built request message.

    Exposed for callers (such as the gRPC solver service) that already
    hold the request as a proto message.
    """
    return _run(request, request_id=request_id)


def _run(
    req: TensionMemberCheckRequest,
    request_id: str | None,
) -> TensionMemberCheckResponse:
    gamma_m0 = req.gamma_m0 if req.HasField("gamma_m0") else _DEFAULT_GAMMA_M0

    result = DesignCheckResult(
        check_id=_CHECK_ID,
        check_name=_CHECK_NAME,
        request_id=request_id,
    )

    # Error path: γ_M0 must be strictly positive. Emit warning + ERROR
    # status rather than throwing — callers composing many checks want
    # structured results.
    if gamma_m0 <= 0.0:
        result.status = CheckStatus.CHECK_STATUS_ERROR
        result.warnings.append(
            SEWarning(
                code="EC3_INVALID_GAMMA_M0",
                message=(
                    f"gamma_M0 must be > 0, got {gamma_m0}. "
                    "EN 1993-1-1 §6.1(1) recommends 1.0."
                ),
                clause_reference=_CLAUSE_REF,
            )
        )
        result.summary = "Invalid input: gamma_M0 must be > 0."
        _append_inputs(result, area=req.area, f_y=req.f_y, n_ed=req.n_ed, gamma_m0=gamma_m0)
        return TensionMemberCheckResponse(result=result, n_t_rd=0.0)

    # Happy path.
    n_t_rd = req.area * req.f_y / gamma_m0
    utilisation = req.n_ed / n_t_rd if n_t_rd != 0.0 else float("inf")
    status = (
        CheckStatus.CHECK_STATUS_PASS
        if utilisation <= 1.0
        else CheckStatus.CHECK_STATUS_FAIL
    )

    _append_inputs(result, area=req.area, f_y=req.f_y, n_ed=req.n_ed, gamma_m0=gamma_m0)
    result.intermediate_values.append(
        IntermediateValue(
            symbol="N_t,Rd",
            value=n_t_rd,
            unit="N",
            description="Design tension resistance (gross-section yielding)",
            clause_reference=_CLAUSE_REF,
        )
    )

    result.status = status
    result.utilisation = utilisation
    result.summary = (
        f"N_t,Rd = {n_t_rd:.6g} N, N_Ed = {req.n_ed:.6g} N, "
        f"utilisation = {utilisation:.4f} "
        f"({'PASS' if status == CheckStatus.CHECK_STATUS_PASS else 'FAIL'})"
    )
    return TensionMemberCheckResponse(result=result, n_t_rd=n_t_rd)


def _append_inputs(
    result: DesignCheckResult,
    *,
    area: float,
    f_y: float,
    n_ed: float,
    gamma_m0: float,
) -> None:
    """Append the four input intermediate values in standard order."""
    result.intermediate_values.append(
        IntermediateValue(
            symbol="A",
            value=area,
            unit="m^2",
            description="Gross cross-sectional area",
            clause_reference=_CLAUSE_REF,
        )
    )
    result.intermediate_values.append(
        IntermediateValue(
            symbol="f_y",
            value=f_y,
            unit="Pa",
            description="Characteristic yield stress",
            clause_reference=_CLAUSE_REF,
        )
    )
    result.intermediate_values.append(
        IntermediateValue(
            symbol="gamma_M0",
            value=gamma_m0,
            unit="-",
            description="Partial safety factor on yield stress",
            clause_reference=_CLAUSE_REF,
        )
    )
    result.intermediate_values.append(
        IntermediateValue(
            symbol="N_Ed",
            value=n_ed,
            unit="N",
            description="Design tensile force",
            clause_reference=_CLAUSE_REF,
        )
    )
