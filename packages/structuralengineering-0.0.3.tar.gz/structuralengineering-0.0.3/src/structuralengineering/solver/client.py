# Copyright 2026 Superstructure GbR
# SPDX-License-Identifier: Apache-2.0
"""Stub client for the structuralengineering solver gRPC service.

v0.0.1 ships only the message types and a placeholder client constructor.
The concrete gRPC wiring lands in v0.2 alongside the auth decision
(see ADR 0004).
"""

from __future__ import annotations

from dataclasses import dataclass

from structuralengineering.solver.v1.solver_pb2 import SolveRequest, SolveResponse

__all__ = ["SolveRequest", "SolveResponse", "SolverClient"]


@dataclass(frozen=True)
class SolverClient:
    """Placeholder solver client.

    v0.0.1: this class is a stub. It holds the endpoint URL and raises on
    any call; v0.2 replaces it with a real ``grpcio`` or ``connect-python``
    implementation, depending on the outcome of ADR 0004.
    """

    endpoint: str
    """Base URL of the solver service, e.g.
    ``https://solver.superstructur.es``."""

    def solve(self, request: SolveRequest) -> SolveResponse:
        """Submit a solve request. Not implemented in v0.0.1."""
        raise NotImplementedError(
            "SolverClient.solve is a v0.0.1 stub. The concrete transport "
            "and authentication mechanism land in v0.2 — see ADR 0004."
        )
