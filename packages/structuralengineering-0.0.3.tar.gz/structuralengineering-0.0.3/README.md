# `structuralengineering` (Python)

Open-source structural engineering primitives: Protocol Buffers schema,
design-check implementations, validation layer, gRPC solver client.

Part of the [`structuralengineering` monorepo][monorepo].
See the monorepo README for the full project overview.

## Install

```bash
# From PyPI
pip install structuralengineering

# Or from the internal GitLab Package Registry (same artefacts):
pip install --index-url https://gitlab.superstructur.es/api/v4/projects/<ID>/packages/pypi/simple \
    structuralengineering
```

## Quick start

```python
from structuralengineering.checks.ec3.tension_member import check_tension_member

# EC3-1-1 §6.2.3(2)a — gross-section yielding
response = check_tension_member(
    area=5.38e-3,      # m^2
    f_y=235e6,         # Pa
    n_ed=1.0e6,        # N
    gamma_m0=1.0,
)

print(response.result.status)       # CheckStatus.CHECK_STATUS_PASS
print(response.n_t_rd)              # 1.2643e6 N
print(response.result.utilisation)  # 0.7909
```

## Available checks

- **EC3-1-1 §6.2.3(2)a** — tension-member gross-section yielding
  (`structuralengineering.checks.ec3.tension_member`)

More checks land as the project matures. See the
[`CHANGELOG.md`](../../CHANGELOG.md) for the per-release list.

## Development

```bash
# From the monorepo root:
pwsh scripts/bootstrap.ps1         # Windows
./scripts/bootstrap.sh             # bash / WSL

# Or manually from this directory:
uv sync --all-extras
uv run pytest
uv run mypy src
uv run ruff check src tests
```

## Licence

Apache License 2.0. See [`../../LICENSE`](../../LICENSE) and
[`../../NOTICE`](../../NOTICE).

[monorepo]: https://gitlab.superstructur.es/structuralengineering/core
