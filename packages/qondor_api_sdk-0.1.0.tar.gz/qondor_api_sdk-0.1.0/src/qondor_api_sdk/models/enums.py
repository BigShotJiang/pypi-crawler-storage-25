"""All enums derived from the Qondor API OpenAPI spec."""

from __future__ import annotations

from enum import IntEnum

__all__ = [
    "OfferStatus",
    "ProjectStatus",
    "ProductApiProductType",
    "AccommodationOfferPriceType",
    "DesignTemplate",
    "OfferProductAnswer",
    "BillingModel",
    "SupplierStatus",
    "ISO4217CurrencyCode",
    "VatDisplayType",
    "ToBePaidBy",
    "LocationCodeScheme",
    "LocationCodeType",
    "FlightClass",
    "TripMode",
    "CustomFieldDataType",
    "LocationTypeDEPRECATED",
]


class OfferStatus(IntEnum):
    NOT_SENT = 1
    SENT = 2
    CONFIRMED = 3
    DECLINED = 4


class ProjectStatus(IntEnum):
    PENDING = 1
    CONFIRMED = 2
    FINISHED = 3
    CANCELLED = 4


class ProductApiProductType(IntEnum):
    STANDARD = 1
    ACCOMMODATION = 2


class AccommodationOfferPriceType(IntEnum):
    DISPLAY_PRICE_PER_PERSON_PER_NIGHT = 1
    DISPLAY_PRICE_PER_ROOM_PER_NIGHT = 2
    DISPLAY_PRICE_PER_ROOM = 3


class DesignTemplate(IntEnum):
    IMAGE_LEFT_TEXT_RIGHT = 1
    IMAGE_TOP_TEXT_BOTTOM = 2
    IMAGE_RIGHT_TEXT_LEFT = 6
    THREE_IMAGES_TOP_TEXT_BOTTOM = 7
    IMAGE_SLIDER_TOP_TEXT_BOTTOM = 8


class OfferProductAnswer(IntEnum):
    NO = 0
    YES = 1
    UNSURE = 2


class BillingModel(IntEnum):
    NONE = 0
    NET_PRICE = 1
    COMMISSION = 2


class SupplierStatus(IntEnum):
    NORMAL = 1
    PREFERRED = 2
    DO_NOT_USE = 3


class ISO4217CurrencyCode(IntEnum):
    """ISO 4217 numeric currency codes as used by the Qondor API."""

    ALL = 8
    DZD = 12
    ARS = 32
    AUD = 36
    BSD = 44
    BHD = 48
    BDT = 50
    AMD = 51
    BBD = 52
    BMD = 60
    BTN = 64
    BOB = 68
    BWP = 72
    BZD = 84
    SBD = 90
    BND = 96
    MMK = 104
    BIF = 108
    KHR = 116
    CAD = 124
    CVE = 132
    KYD = 136
    LKR = 144
    CLP = 152
    CNY = 156
    COP = 170
    KMF = 174
    CRC = 188
    HRK = 191
    CUP = 192
    CZK = 203
    DKK = 208
    DOP = 214
    SVC = 222
    ETB = 230
    ERN = 232
    FKP = 238
    FJD = 242
    DJF = 262
    GMD = 270
    GIP = 292
    GTQ = 320
    GNF = 324
    GYD = 328
    HTG = 332
    HNL = 340
    HKD = 344
    HUF = 348
    ISK = 352
    INR = 356
    IDR = 360
    IRR = 364
    IQD = 368
    ILS = 376
    JMD = 388
    JPY = 392
    KZT = 398
    JOD = 400
    KES = 404
    KPW = 408
    KRW = 410
    KWD = 414
    KGS = 417
    LAK = 418
    LBP = 422
    LSL = 426
    LRD = 430
    LYD = 434
    MOP = 446
    MWK = 454
    MYR = 458
    MVR = 462
    MRU = 478
    MUR = 480
    MXN = 484
    MNT = 496
    MDL = 498
    MAD = 504
    OMR = 512
    NAD = 516
    NPR = 524
    ANG = 532
    AWG = 533
    VUV = 548
    NZD = 554
    NIO = 558
    NGN = 566
    NOK = 578
    PKR = 586
    PAB = 590
    PGK = 598
    PYG = 600
    PEN = 604
    PHP = 608
    QAR = 634
    RUB = 643
    RWF = 646
    SHP = 654
    STN = 678
    SAR = 682
    SCR = 690
    SLL = 694
    SGD = 702
    VND = 704
    SOS = 706
    ZAR = 710
    SSP = 728
    SZL = 748
    SEK = 752
    CHF = 756
    SYP = 760
    THB = 764
    TOP = 776
    TTD = 780
    AED = 784
    TND = 788
    UGX = 800
    MKD = 807
    EGP = 818
    GBP = 826
    TZS = 834
    USD = 840
    UYU = 858
    UZS = 860
    WST = 882
    YER = 886
    TWD = 901
    CUC = 931
    ZWL = 932
    BYN = 933
    TMT = 934
    GHS = 936
    VEF = 937
    SDG = 938
    UYI = 940
    RSD = 941
    MZN = 943
    AZN = 944
    RON = 946
    CHE = 947
    CHW = 948
    TRY = 949
    XAF = 950
    XCD = 951
    XOF = 952
    XPF = 953
    XDR = 960
    XUA = 965
    ZMW = 967
    SRD = 968
    MGA = 969
    COU = 970
    AFN = 971
    TJS = 972
    AOA = 973
    BYR = 974
    BGN = 975
    CDF = 976
    BAM = 977
    EUR = 978
    MXV = 979
    UAH = 980
    GEL = 981
    BOV = 984
    PLN = 985
    BRL = 986
    CLF = 990
    XSU = 994
    USN = 997


class VatDisplayType(IntEnum):
    EXCL_VAT = 0
    INCL_VAT = 1


class ToBePaidBy(IntEnum):
    CUSTOMER_BASED_ON_BOOKINGS = 2
    BOOKER = 3
    CUSTOMER_AS_OFFERED = 4


class LocationCodeScheme(IntEnum):
    NONE = 0
    IATA = 1
    UN_LOCODE = 2
    ISO_3166 = 3


class LocationCodeType(IntEnum):
    CITY = 1
    COUNTRY = 2


class FlightClass(IntEnum):
    ECONOMY = 1
    BUSINESS = 2
    FIRST = 3


class TripMode(IntEnum):
    ONE_WAY = 1
    RETURN = 2


class CustomFieldDataType(IntEnum):
    TEXT = 0
    NUMBER = 1
    DATE = 2
    BOOLEAN = 3


class LocationTypeDEPRECATED(IntEnum):
    UNKNOWN = 0
    CITY = 1
    COUNTRY = 2
