import os
import shutil
from pathlib import Path
from typing import Iterable, Optional


def copy_to_worktree(
    paths: Iterable[str],
    host_repo_dir: str,
    worktree_path: str,
    timeout_ms: Optional[int] = None,
) -> None:
    del timeout_ms
    for relative in paths:
        src = Path(host_repo_dir) / relative
        if not src.exists():
            continue
        dest = Path(worktree_path) / relative
        if src.is_dir():
            if dest.exists():
                shutil.rmtree(str(dest))
            shutil.copytree(str(src), str(dest), symlinks=True)
        else:
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(str(src), str(dest))


def copy_tree(src: str, dest: str) -> None:
    src_path = Path(src)
    dest_path = Path(dest)
    if src_path.is_dir():
        if dest_path.exists():
            shutil.rmtree(str(dest_path))
        shutil.copytree(str(src_path), str(dest_path), symlinks=True)
    else:
        dest_path.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(str(src_path), str(dest_path))


def ensure_executable(path: str) -> None:
    p = Path(path)
    p.chmod(p.stat().st_mode | os.stat(str(p)).st_mode | 0o111)
