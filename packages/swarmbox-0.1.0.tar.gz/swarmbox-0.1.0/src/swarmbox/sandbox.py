import os
import shlex
import shutil
import subprocess
import sys
import uuid
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, Dict, Iterable, List, Optional, Sequence

from .copying import copy_tree
from .errors import ContainerError, SandboxError
from .models import ExecResult
from .mounts import MountConfig, default_image_name, resolve_user_mounts, volume_arg


def _streaming_process(
    args: Sequence[str],
    cwd: Optional[str] = None,
    env: Optional[Dict[str, str]] = None,
    stdin: Optional[str] = None,
    on_line: Optional[Callable[[str], None]] = None,
    stdio_passthrough: bool = False,
) -> ExecResult:
    if stdio_passthrough:
        code = subprocess.call(args, cwd=cwd, env=env)
        return ExecResult("", "", int(code))
    proc = subprocess.Popen(
        list(args),
        cwd=cwd,
        env=env,
        stdin=subprocess.PIPE if stdin is not None else subprocess.DEVNULL,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        bufsize=1,
    )
    if stdin is not None and proc.stdin is not None:
        proc.stdin.write(stdin)
        proc.stdin.close()
    stdout_lines: List[str] = []
    stderr = ""
    assert proc.stdout is not None
    for line in proc.stdout:
        text = line.rstrip("\n")
        stdout_lines.append(text if on_line else line)
        if on_line:
            on_line(text)
    if proc.stderr is not None:
        stderr = proc.stderr.read()
    code = proc.wait()
    stdout = "\n".join(stdout_lines) if on_line else "".join(stdout_lines)
    return ExecResult(stdout=stdout, stderr=stderr, exit_code=code)


@dataclass
class LocalHandle:
    worktree_path: str
    env: Dict[str, str] = field(default_factory=dict)

    def exec(
        self,
        command: str,
        on_line: Optional[Callable[[str], None]] = None,
        cwd: Optional[str] = None,
        sudo: bool = False,
        stdin: Optional[str] = None,
    ) -> ExecResult:
        del sudo
        effective_env = os.environ.copy()
        effective_env.update(self.env)
        return _streaming_process(
            ["sh", "-c", command],
            cwd=cwd or self.worktree_path,
            env=effective_env,
            stdin=stdin,
            on_line=on_line,
        )

    def interactive_exec(self, args: Sequence[str], cwd: Optional[str] = None) -> int:
        effective_env = os.environ.copy()
        effective_env.update(self.env)
        return subprocess.call(list(args), cwd=cwd or self.worktree_path, env=effective_env)

    def copy_file_in(self, host_path: str, sandbox_path: str) -> None:
        copy_tree(host_path, sandbox_path)

    def copy_file_out(self, sandbox_path: str, host_path: str) -> None:
        copy_tree(sandbox_path, host_path)

    def copy_in(self, host_path: str, sandbox_path: str) -> None:
        copy_tree(host_path, sandbox_path)

    def close(self) -> None:
        pass


@dataclass
class ContainerHandle:
    runtime: str
    container_name: str
    worktree_path: str

    def exec(
        self,
        command: str,
        on_line: Optional[Callable[[str], None]] = None,
        cwd: Optional[str] = None,
        sudo: bool = False,
        stdin: Optional[str] = None,
    ) -> ExecResult:
        effective = "sudo %s" % command if sudo else command
        args = [self.runtime, "exec"]
        if stdin is not None:
            args.append("-i")
        if cwd:
            args.extend(["-w", cwd])
        args.extend([self.container_name, "sh", "-c", effective])
        return _streaming_process(args, stdin=stdin, on_line=on_line)

    def interactive_exec(self, args: Sequence[str], cwd: Optional[str] = None) -> int:
        exec_args = [self.runtime, "exec", "-it"]
        if cwd:
            exec_args.extend(["-w", cwd])
        exec_args.extend([self.container_name])
        exec_args.extend(args)
        return subprocess.call(exec_args)

    def copy_file_in(self, host_path: str, sandbox_path: str) -> None:
        subprocess.check_call([self.runtime, "cp", host_path, "%s:%s" % (self.container_name, sandbox_path)])

    def copy_file_out(self, sandbox_path: str, host_path: str) -> None:
        subprocess.check_call([self.runtime, "cp", "%s:%s" % (self.container_name, sandbox_path), host_path])

    def close(self) -> None:
        subprocess.call([self.runtime, "rm", "-f", self.container_name], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


@dataclass
class SandboxProvider:
    tag: str
    name: str
    env: Dict[str, str] = field(default_factory=dict)
    sandbox_homedir: Optional[str] = None
    factory: Optional[Callable[..., object]] = None

    def create(self, **kwargs):
        if not self.factory:
            raise SandboxError("Sandbox provider %s has no factory" % self.name)
        return self.factory(**kwargs)


def create_bind_mount_sandbox_provider(
    name: str,
    create: Callable[..., object],
    env: Optional[Dict[str, str]] = None,
    sandbox_homedir: Optional[str] = None,
) -> SandboxProvider:
    return SandboxProvider(
        tag="bind-mount",
        name=name,
        env=env or {},
        sandbox_homedir=sandbox_homedir,
        factory=create,
    )


def create_isolated_sandbox_provider(
    name: str,
    create: Callable[..., object],
    env: Optional[Dict[str, str]] = None,
) -> SandboxProvider:
    return SandboxProvider(tag="isolated", name=name, env=env or {}, factory=create)


def no_sandbox(env: Optional[Dict[str, str]] = None) -> SandboxProvider:
    def create(worktree_path: str, **kwargs):
        create_env = kwargs.get("env", {})
        merged = {}
        merged.update(env or {})
        merged.update(create_env)
        return LocalHandle(worktree_path=worktree_path, env=merged)

    return SandboxProvider(tag="none", name="no-sandbox", env=env or {}, factory=create)


def _check_runtime(runtime: str) -> None:
    if shutil.which(runtime) is None:
        raise ContainerError("%s binary not found on PATH" % runtime)


def _container_provider(
    runtime: str,
    image_name: Optional[str] = None,
    mounts: Optional[Iterable[MountConfig]] = None,
    env: Optional[Dict[str, str]] = None,
    network: Optional[Iterable[str]] = None,
    selinux_label: Optional[str] = None,
) -> SandboxProvider:
    sandbox_homedir = "/home/agent"
    user_mounts = resolve_user_mounts(mounts or [], sandbox_homedir)

    def create(worktree_path: str, host_repo_path: str, internal_mounts, env: Dict[str, str]):
        _check_runtime(runtime)
        name = "swarmbox-%s" % uuid.uuid4()
        all_mounts = list(internal_mounts) + user_mounts
        volume_args = []
        for mount in all_mounts:
            extra = selinux_label if runtime == "podman" and selinux_label else None
            volume_args.extend(["-v", volume_arg(mount, extra=extra)])
        env_args = []
        merged_env = dict(env)
        merged_env["HOME"] = sandbox_homedir
        for key, value in merged_env.items():
            env_args.extend(["-e", "%s=%s" % (key, value)])
        network_args: List[str] = []
        for net in network or []:
            network_args.extend(["--network", net])
        uid = os.getuid() if hasattr(os, "getuid") else 1000
        gid = os.getgid() if hasattr(os, "getgid") else 1000
        run_args = [
            runtime,
            "run",
            "-d",
            "--name",
            name,
            "--user",
            "%s:%s" % (uid, gid),
            "-w",
            worktree_path,
        ]
        run_args.extend(network_args)
        run_args.extend(env_args)
        run_args.extend(volume_args)
        if runtime == "podman":
            run_args.extend(["--entrypoint", "sleep"])
        run_args.append(image_name or default_image_name(host_repo_path))
        if runtime == "podman":
            run_args.append("infinity")
        subprocess.check_call(run_args)
        return ContainerHandle(runtime=runtime, container_name=name, worktree_path=worktree_path)

    return create_bind_mount_sandbox_provider(
        name=runtime,
        create=create,
        env=env or {},
        sandbox_homedir=sandbox_homedir,
    )


def docker(
    image_name: Optional[str] = None,
    mounts: Optional[Iterable[MountConfig]] = None,
    env: Optional[Dict[str, str]] = None,
    network: Optional[Iterable[str]] = None,
) -> SandboxProvider:
    return _container_provider("docker", image_name=image_name, mounts=mounts, env=env, network=network)


def podman(
    image_name: Optional[str] = None,
    mounts: Optional[Iterable[MountConfig]] = None,
    env: Optional[Dict[str, str]] = None,
    network: Optional[Iterable[str]] = None,
    selinux_label: str = "z",
) -> SandboxProvider:
    return _container_provider(
        "podman",
        image_name=image_name,
        mounts=mounts,
        env=env,
        network=network,
        selinux_label=selinux_label,
    )


def vercel(**options) -> SandboxProvider:
    def create(env: Dict[str, str]):
        try:
            from vercel.sandbox import Sandbox  # type: ignore
        except Exception as exc:
            raise SandboxError("Install SwarmBox with the 'vercel' extra to use vercel()") from exc
        params = dict(options)
        params["env"] = env
        sandbox = Sandbox.create(params)

        class VercelHandle:
            worktree_path = "/vercel/sandbox/workspace"

            def exec(self, command, on_line=None, cwd=None, sudo=False, stdin=None):
                del stdin
                result = sandbox.run_command(cmd="sh", args=["-c", command], cwd=cwd or self.worktree_path, sudo=sudo)
                stdout = result.stdout()
                stderr = result.stderr()
                if on_line:
                    for line in stdout.splitlines():
                        on_line(line)
                return ExecResult(stdout, stderr, result.exit_code)

            def copy_in(self, host_path, sandbox_path):
                raise NotImplementedError("Vercel copy_in depends on the installed SDK version")

            def copy_file_out(self, sandbox_path, host_path):
                raise NotImplementedError("Vercel copy_file_out depends on the installed SDK version")

            def close(self):
                sandbox.stop()

        return VercelHandle()

    return create_isolated_sandbox_provider("vercel", create=create, env=options.get("env"))


def daytona(**options) -> SandboxProvider:
    def create(env: Dict[str, str]):
        del env
        try:
            from daytona_sdk import Daytona  # type: ignore
        except Exception as exc:
            raise SandboxError("Install SwarmBox with the 'daytona' extra to use daytona()") from exc
        client = Daytona(api_key=options.get("api_key"), api_url=options.get("api_url"), target=options.get("target"))
        sandbox = client.create(options.get("create"))
        workdir = sandbox.get_work_dir() or sandbox.get_user_home_dir() or "/home/daytona"

        class DaytonaHandle:
            worktree_path = workdir

            def exec(self, command, on_line=None, cwd=None, sudo=False, stdin=None):
                del stdin
                effective = "sudo %s" % command if sudo else command
                response = sandbox.process.execute_command(effective, cwd or self.worktree_path)
                stdout = response.result
                if on_line:
                    for line in stdout.splitlines():
                        on_line(line)
                return ExecResult(stdout, "", response.exit_code)

            def copy_in(self, host_path, sandbox_path):
                sandbox.fs.upload_file(host_path, sandbox_path)

            def copy_file_out(self, sandbox_path, host_path):
                sandbox.fs.download_file(sandbox_path, host_path)

            def close(self):
                client.delete(sandbox)

        return DaytonaHandle()

    return create_isolated_sandbox_provider("daytona", create=create, env=options.get("env"))
