import json
import subprocess
from pathlib import Path
from typing import Callable, List, Optional

from .errors import ExecError, SandboxError, SyncError
from .models import Commit, Hooks
from .sync import sync_out
from .worktree import commits_since, current_branch, current_head


def run_host_hooks(hooks, cwd: str) -> None:
    for hook in hooks or []:
        proc = subprocess.run(
            hook.command,
            cwd=cwd,
            shell=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            timeout=(hook.timeout_ms / 1000) if hook.timeout_ms else None,
        )
        if proc.returncode != 0:
            raise ExecError(hook.command, "Host hook failed: %s\n%s" % (hook.command, proc.stderr))


def exec_ok(sandbox, command: str, cwd: Optional[str] = None, sudo: bool = False):
    result = sandbox.exec(command, cwd=cwd, sudo=sudo)
    if result.exit_code != 0:
        raise ExecError(command, "Command failed (exit %s): %s\n%s" % (result.exit_code, command, result.stderr))
    return result


def _git_config_value(repo: str, key: str) -> str:
    proc = subprocess.run(
        ["git", "config", key],
        cwd=repo,
        stdout=subprocess.PIPE,
        stderr=subprocess.DEVNULL,
        text=True,
    )
    return proc.stdout.strip() if proc.returncode == 0 else ""


def with_sandbox_lifecycle(
    *,
    host_repo_dir: str,
    sandbox,
    sandbox_repo_dir: str,
    host_worktree_path: str,
    hooks: Optional[Hooks],
    branch: Optional[str],
    apply_to_host: Optional[Callable[[], None]],
    work: Callable[[str], object],
) -> object:
    hooks = hooks or Hooks()
    host_current_branch = None if branch else current_branch(host_repo_dir)
    host_git_name = _git_config_value(host_repo_dir, "user.name")
    host_git_email = _git_config_value(host_repo_dir, "user.email")

    exec_ok(sandbox, 'git config --global --add safe.directory "%s"' % sandbox_repo_dir)
    if host_git_name:
        exec_ok(sandbox, "git config --global user.name %s" % json.dumps(host_git_name))
    if host_git_email:
        exec_ok(sandbox, "git config --global user.email %s" % json.dumps(host_git_email))
    resolved_branch = exec_ok(sandbox, "git rev-parse --abbrev-ref HEAD", cwd=sandbox_repo_dir).stdout.strip()

    for hook in hooks.sandbox.on_sandbox_ready:
        exec_ok(sandbox, hook.command, cwd=sandbox_repo_dir, sudo=hook.sudo)
    run_host_hooks(hooks.host.on_sandbox_ready, host_worktree_path)

    base_head = current_head(host_worktree_path)
    result = work(base_head)

    if apply_to_host:
        apply_to_host()

    commits: List[Commit]
    final_branch: str
    target_branch = branch or resolved_branch
    if host_current_branch is not None:
        count = subprocess.run(
            ["git", "rev-list", "%s..HEAD" % base_head, "--count"],
            cwd=host_worktree_path,
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            text=True,
        )
        has_new_commits = count.returncode == 0 and int((count.stdout or "0").strip() or "0") > 0
        exec_ok(sandbox, "git checkout --detach", cwd=sandbox_repo_dir)
        if has_new_commits:
            proc = subprocess.run(
                ["git", "merge", resolved_branch],
                cwd=host_repo_dir,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
            )
            if proc.returncode != 0:
                raise SyncError(
                    "Merge of '%s' onto '%s' failed. Temporary branch preserved.\n%s"
                    % (resolved_branch, host_current_branch, proc.stderr)
                )
        subprocess.run(["git", "branch", "-D", resolved_branch], cwd=host_repo_dir, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        commits = [Commit(sha) for sha in commits_since(host_repo_dir, base_head)]
        final_branch = host_current_branch
    else:
        commits = [Commit(sha) for sha in commits_since(host_repo_dir, base_head, "refs/heads/%s" % target_branch)]
        final_branch = target_branch

    return result, final_branch, commits
