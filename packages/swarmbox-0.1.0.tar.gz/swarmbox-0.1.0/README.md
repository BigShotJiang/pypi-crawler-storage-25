# SwarmBox

[![PyPI version](https://img.shields.io/pypi/v/swarmbox.svg)](https://pypi.org/project/swarmbox/)
[![Python versions](https://img.shields.io/pypi/pyversions/swarmbox.svg)](https://pypi.org/project/swarmbox/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)
[![Package status](https://img.shields.io/pypi/status/swarmbox.svg)](https://pypi.org/project/swarmbox/)

SwarmBox is a Python port and expansion of Sandcastle-style coding-agent
orchestration. It runs coding agents in git worktrees, Docker/Podman
containers, optional cloud sandboxes, or directly on the host for interactive
sessions.

The project is designed for Sandcastle feature parity first:

- `run`, `interactive`, `create_sandbox`, and `create_worktree`
- branch strategies: `head`, `merge-to-head`, and `branch`
- prompt files, `{{ARG}}` substitution, and shell expression expansion
- host and sandbox lifecycle hooks
- Docker, Podman, Vercel, Daytona, and no-sandbox providers
- Claude session capture/resume-compatible storage
- init templates for loop, review, and parallel planner workflows

SwarmBox also adds an agent registry seeded from SwarmVault and SwarmClaw so
any coding-agent CLI can be detected or configured with a generic command
adapter.

## Quick Start

```bash
python -m pip install -e .
swarmbox agents list
swarmbox init --agent codex --sandbox docker --template blank --no-build
```

```python
from swarmbox import codex, docker, run

result = run(
    agent=codex("gpt-5.4-codex"),
    sandbox=docker(),
    prompt_file=".swarmbox/prompt.md",
)
print(result.branch, result.commits)
```

## Reference

The behavior and API shape are based on the upstream MIT-licensed Sandcastle
project: https://github.com/mattpocock/sandcastle
