"""
T-RAG Exporter
===============
Handles the final output step:
  - Asks user: Save file? Copy to clipboard? Both?
  - Saves to trag_output/ folder with timestamp
  - Copies to clipboard (Windows/Mac/Linux)
"""

import sys
import os
import platform
import subprocess
from datetime import datetime
from pathlib import Path


def copy_to_clipboard(text: str) -> bool:
    """Copy text to clipboard cross-platform."""
    system = platform.system()
    try:
        if system == "Windows":
            # Use clip command
            process = subprocess.Popen(
                ["clip"], stdin=subprocess.PIPE, close_fds=True
            )
            process.communicate(input=text.encode("utf-8"))
            return True
        elif system == "Darwin":  # macOS
            process = subprocess.Popen(
                ["pbcopy"], stdin=subprocess.PIPE, close_fds=True
            )
            process.communicate(input=text.encode("utf-8"))
            return True
        elif system == "Linux":
            # Try xclip first, then xsel
            for cmd in [["xclip", "-selection", "clipboard"], ["xsel", "--clipboard", "--input"]]:
                try:
                    process = subprocess.Popen(
                        cmd, stdin=subprocess.PIPE, close_fds=True
                    )
                    process.communicate(input=text.encode("utf-8"))
                    return True
                except FileNotFoundError:
                    continue
            # Try pyperclip as last resort
            try:
                import pyperclip
                pyperclip.copy(text)
                return True
            except Exception:
                pass
        return False
    except Exception as e:
        print(f"   Clipboard error: {e}")
        return False


def save_to_file(text: str, project_root: Path) -> Path:
    """Save the context to a timestamped file."""
    output_dir = project_root / "trag_output"
    output_dir.mkdir(exist_ok=True)

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"trag_context_{timestamp}.txt"
    filepath = output_dir / filename

    filepath.write_text(text, encoding="utf-8")
    return filepath


def show_preview(text: str, lines: int = 15):
    """Show a preview of the generated context."""
    print("\n" + "─" * 50)
    print("PREVIEW (first lines):")
    print("─" * 50)
    preview_lines = text.splitlines()[:lines]
    for line in preview_lines:
        print(line)
    print("  ...")
    print(f"  [Total: {len(text.splitlines())} lines | {len(text):,} characters]")
    print("─" * 50)


def export_context(context: str, project_root: Path):
    """Interactive export: ask user what to do."""

    show_preview(context)

    print("\n📤 EXPORT OPTIONS:")
    print("  1 → Save to file  (trag_output/trag_context_TIMESTAMP.txt)")
    print("  2 → Copy to clipboard  (paste directly into Claude.ai)")
    print("  3 → Both  (save + copy)")
    print("  4 → Show full context in terminal")
    print()

    while True:
        choice = input("Your choice [1/2/3/4]: ").strip()

        if choice == "1":
            filepath = save_to_file(context, project_root)
            print(f"\n✅ Saved to: {filepath}")
            print(f"   Open this file, select all, copy and paste into Claude.ai")
            break

        elif choice == "2":
            success = copy_to_clipboard(context)
            if success:
                print("\n✅ Copied to clipboard!")
                print("   Go to Claude.ai → paste (Ctrl+V / Cmd+V) → send")
            else:
                print("\n⚠️  Clipboard copy failed.")
                print("   Saving to file instead...")
                filepath = save_to_file(context, project_root)
                print(f"   Saved to: {filepath}")
            break

        elif choice == "3":
            filepath = save_to_file(context, project_root)
            success = copy_to_clipboard(context)
            print(f"\n✅ Saved to: {filepath}")
            if success:
                print("✅ Also copied to clipboard!")
                print("   Go to Claude.ai → paste (Ctrl+V / Cmd+V) → send")
            else:
                print("⚠️  Clipboard copy failed — use the saved file.")
            break

        elif choice == "4":
            print("\n" + "═" * 60)
            print(context)
            print("═" * 60)
            print("\nRun again and choose 1, 2, or 3 to export.")
            break

        else:
            print("   Please enter 1, 2, 3, or 4")

    print("\n" + "═" * 50)
    print("  🧠 T-RAG scan complete!")
    print("  Tip: Update trag_changes.txt whenever you manually edit code.")
    print("═" * 50 + "\n")
