"""
T-RAG — Automatic Claude context builder for any coding project.
"""
__version__ = "2.1.0"
