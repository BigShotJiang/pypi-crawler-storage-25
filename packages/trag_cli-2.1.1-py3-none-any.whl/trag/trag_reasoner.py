"""
T-RAG Reasoner
===============
Builds the final Claude-ready context prompt.
Also handles Ollama detection, recommendation, and install guide.
"""
import sys
import re
import os
import platform
import subprocess
from pathlib import Path
from datetime import datetime


def _add_ollama_to_path():
    if platform.system() == "Windows":
        username = os.environ.get("USERNAME", "")
        ollama_path = rf"C:\Users\{username}\AppData\Local\Programs\Ollama"
        if ollama_path not in os.environ.get("PATH", ""):
            os.environ["PATH"] += f";{ollama_path}"

_add_ollama_to_path()


# ─── OLLAMA DETECTION + RECOMMENDATION ───────────────────────────────────────

RECOMMENDED_MODELS = ["qwen2.5-coder:7b", "qwen2.5-coder:3b", "llama3.2:3b", "llama3.2"]

def check_ollama_installed() -> bool:
    """Check if ollama package is installed."""
    try:
        import ollama
        return True
    except ImportError:
        return False


def check_ollama_running() -> bool:
    """Check if Ollama app/server is running."""
    try:
        import ollama
        ollama.list()
        return True
    except Exception:
        return False


def get_available_models() -> list:
    """Get list of models currently pulled in Ollama."""
    try:
        import ollama
        result = ollama.list()
        return [m.model for m in result.models]
    except Exception:
        return []


def find_best_model(available: list) -> str | None:
    """Return the best available model from our recommended list."""
    for preferred in RECOMMENDED_MODELS:
        for model in available:
            if preferred in model:
                return model
    return None


def prompt_ollama_recommendation():
    """
    Check Ollama status. If not available, explain why it helps,
    recommend a model, and ask if user wants the install guide.
    """
    ollama_installed = check_ollama_installed()
    ollama_running = check_ollama_running() if ollama_installed else False
    available_models = get_available_models() if ollama_running else []
    best_model = find_best_model(available_models)

    if best_model:
        return best_model   # All good — use it

    # ── Not fully set up — explain and recommend ──────────────────────────
    print()
    print("  ┌─────────────────────────────────────────────────────────┐")
    print("  │  💡 OPTIONAL: Smarter AI reasoning with Ollama          │")
    print("  └─────────────────────────────────────────────────────────┘")

    if not ollama_installed:
        print("  Ollama is not installed.")
    elif not ollama_running:
        print("  Ollama is installed but not running.")
        print("  → Start the Ollama app, then run trag again.")
    else:
        print("  Ollama is running but no code model is downloaded.")

    print()
    print("  What Ollama adds to T-RAG:")
    print("    • Smart AI summary of your project state")
    print("    • Better understanding of what to work on next")
    print("    • Runs 100% locally — no internet, no API key needed")
    print()
    print("  Recommended model: qwen2.5-coder:7b")
    print("    → Best free model for code reasoning (~5GB download)")
    print("    → Lighter option: qwen2.5-coder:3b (~2GB download)")
    print()

    try:
        answer = input("  Want the step-by-step install guide? [y/n]: ").strip().lower()
    except (EOFError, KeyboardInterrupt):
        answer = "n"

    if answer == "y":
        _open_ollama_guide()

    return None   # Continue without Ollama


def _open_ollama_guide():
    """Write the install guide to trag_output/ and open it."""
    guide_path = Path(".") / "trag_output" / "ollama_install_guide.txt"
    guide_path.parent.mkdir(exist_ok=True)

    guide = """
════════════════════════════════════════════════════════════
  OLLAMA + QWEN2.5-CODER INSTALL GUIDE
  For use with T-RAG smart reasoning
════════════════════════════════════════════════════════════

WHAT IS OLLAMA?
  Ollama lets you run AI models locally on your computer.
  No internet needed after download. No API key. Free forever.
  T-RAG uses it to write a smart summary of your project.

════════════════════════════════════════════════════════════
STEP 1 — INSTALL OLLAMA
════════════════════════════════════════════════════════════

  Windows / Mac:
    1. Go to: https://ollama.com/download
    2. Download and run the installer
    3. Follow the on-screen steps (takes ~1 minute)

  Linux:
    Open terminal and run:
      curl -fsSL https://ollama.com/install.sh | sh

  After install, Ollama runs silently in the background.
  You will see the Ollama icon in your system tray (Windows/Mac).

════════════════════════════════════════════════════════════
STEP 2 — DOWNLOAD A CODE MODEL
════════════════════════════════════════════════════════════

  Open your terminal (Command Prompt / PowerShell / Terminal) and run:

  BEST OPTION (needs ~5GB RAM free):
    ollama pull qwen2.5-coder:7b

  LIGHTER OPTION (needs ~3GB RAM free):
    ollama pull qwen2.5-coder:3b

  GENERAL PURPOSE (if above don't work on your machine):
    ollama pull llama3.2:3b

  The download is 2-5GB depending on model. It only happens once.
  After that the model lives on your computer permanently.

════════════════════════════════════════════════════════════
STEP 3 — VERIFY IT WORKS
════════════════════════════════════════════════════════════

  In your terminal run:
    ollama list

  You should see something like:
    NAME                    ID              SIZE
    qwen2.5-coder:7b        abc123...       4.7 GB

  If you see your model listed — you are ready.

════════════════════════════════════════════════════════════
STEP 4 — RUN TRAG AGAIN
════════════════════════════════════════════════════════════

  Just run trag normally in your project:
    trag

  T-RAG will automatically detect Ollama and use it.
  You will see:
    → Ollama reasoning: ✓  [Reasoned by qwen2.5-coder:7b]

════════════════════════════════════════════════════════════
TROUBLESHOOTING
════════════════════════════════════════════════════════════

  "ollama: command not found"
  → Ollama is not installed. Go back to Step 1.

  "Error: model not found"
  → Model not downloaded. Run: ollama pull qwen2.5-coder:7b

  "connection refused" or Ollama not responding
  → Start the Ollama app manually:
      Windows: search "Ollama" in Start Menu and open it
      Mac: open Ollama from Applications
      Linux: run: ollama serve

  T-RAG says "Ollama reasoning: skipped"
  → Ollama not running or no model pulled
  → Check: ollama list  (should show at least one model)
  → Check: ollama serve (should show "Listening on 127.0.0.1:11434")

  Not enough RAM / model is slow
  → Use the 3b version: ollama pull qwen2.5-coder:3b
  → T-RAG works fine without Ollama too — it just uses
    rule-based analysis instead of AI reasoning

════════════════════════════════════════════════════════════
HOW T-RAG USES OLLAMA
════════════════════════════════════════════════════════════

  T-RAG sends Ollama a compact description of your project:
    - File list and structure
    - What changed since last scan
    - Your plan/todo (if you have one)

  Ollama returns a smart summary like:
    "The project is a FastAPI backend. Auth is complete.
     You last modified routes.py (added /profile endpoint).
     Next logical step: connect the frontend login page."

  This summary is included in the context pasted to Claude.ai,
  giving Claude much better understanding of where you are.

════════════════════════════════════════════════════════════
"""

    guide_path.write_text(guide, encoding="utf-8")

    print()
    print(f"  ✓ Guide saved to: {guide_path}")
    print()

    # Try to open the file automatically
    system = platform.system()
    try:
        if system == "Windows":
            os.startfile(str(guide_path))
        elif system == "Darwin":
            subprocess.Popen(["open", str(guide_path)])
        else:
            subprocess.Popen(["xdg-open", str(guide_path)])
        print("  ✓ Opening guide in your text editor...")
    except Exception:
        print(f"  → Open this file manually: {guide_path.resolve()}")

    print()


# ─── MAIN REASONER ────────────────────────────────────────────────────────────

def build_context_summary(
    files: dict,
    file_tree: str,
    plan_content: str,
    changes_result: dict,
    chroma_collection,
    project_root: Path,
) -> str:

    print("  → Analyzing file structure...")
    structure_analysis = analyze_structure(files)

    print("  → Processing change data...")
    changes_analysis = build_changes_analysis(changes_result)

    print("  → Reading plan...")
    plan_analysis = parse_weekly_plan(plan_content)

    print("  → Retrieving key code patterns...")
    key_code = extract_key_code(files, chroma_collection)

    # Ollama — check, recommend if missing, use if available
    ollama_summary = None
    best_model = prompt_ollama_recommendation()
    if best_model:
        try:
            ollama_summary = ollama_reason(
                best_model, structure_analysis, changes_analysis, plan_analysis, files
            )
            print(f"  → Ollama reasoning: ✓  [{best_model}]")
        except Exception as e:
            print(f"  → Ollama reasoning: failed ({e})")

    sys.stdout.reconfigure(encoding="utf-8")

    return build_claude_prompt(
        file_tree=file_tree,
        structure_analysis=structure_analysis,
        changes_analysis=changes_analysis,
        plan_analysis=plan_analysis,
        key_code=key_code,
        ollama_summary=ollama_summary,
        project_root=project_root,
        total_files=len(files),
    )


def build_changes_analysis(changes_result: dict) -> dict:
    return {
        "has_changes": changes_result.get("has_changes", False),
        "is_first_run": changes_result.get("is_first_run", False),
        "changes": changes_result.get("all_changes", []),
        "summary": changes_result.get("summary", ""),
        "auto_count": len(changes_result.get("auto_changes", [])),
        "manual_count": len(changes_result.get("manual_changes", [])),
    }


# ─── FILE STRUCTURE ANALYSIS ──────────────────────────────────────────────────

def analyze_structure(files: dict) -> dict:
    python_files = [f for f in files if f.endswith(".py")]
    config_files = [f for f in files if f.endswith((".json", ".yaml", ".yml", ".toml"))]
    html_files   = [f for f in files if f.endswith((".html", ".css", ".js", ".jsx", ".tsx"))]

    entry_points = [f for f in python_files if
                    any(n in f.lower() for n in ["main", "app", "run", "server", "index"])]
    api_files    = [f for f in python_files if
                    any(n in f.lower() for n in ["route", "api", "view", "endpoint", "handler"])]
    model_files  = [f for f in python_files if
                    any(n in f.lower() for n in ["model", "schema", "database", "db", "orm"])]

    return {
        "total_files": len(files),
        "python_files": python_files,
        "config_files": config_files,
        "html_files": html_files,
        "entry_points": entry_points,
        "api_files": api_files,
        "model_files": model_files,
        "framework": detect_framework(files),
        "total_lines": sum(f["lines"] for f in files.values()),
    }


def detect_framework(files: dict) -> str:
    content = " ".join(f["content"][:500] for f in list(files.values())[:10])
    cl = content.lower()
    if "fastapi"  in cl: return "FastAPI"
    if "flask"    in cl: return "Flask"
    if "django"   in cl: return "Django"
    if "uvicorn"  in cl: return "FastAPI/ASGI"
    return "Python (framework not detected)"


# ─── WEEKLY PLAN PARSER ───────────────────────────────────────────────────────

def parse_weekly_plan(plan_content: str) -> dict:
    if not plan_content.strip():
        return {"has_plan": False, "raw": "", "summary": "No plan found.",
                "done_items": [], "todo_items": [], "in_progress": []}

    done_items, todo_items, in_progress = [], [], []
    for line in plan_content.splitlines():
        s = line.strip()
        if not s:
            continue
        lo = s.lower()
        if any(m in lo for m in ["✓", "[x]", "[done]", "done:", "completed:", "✅"]):
            done_items.append(s)
        elif any(m in lo for m in ["[wip]", "in progress", "working on", "🔄", "→"]):
            in_progress.append(s)
        elif any(m in lo for m in ["[ ]", "todo:", "next:", "□", "•", "-"]):
            todo_items.append(s)

    return {
        "has_plan": True,
        "raw": plan_content,
        "done_items": done_items,
        "todo_items": todo_items,
        "in_progress": in_progress,
        "summary": f"{len(done_items)} done | {len(in_progress)} in progress | {len(todo_items)} todo",
    }


# ─── KEY CODE EXTRACTOR ───────────────────────────────────────────────────────

def extract_key_code(files: dict, chroma_collection) -> str:
    snippets = []
    for path, info in files.items():
        if not path.endswith(".py"):
            continue
        lines = info["content"].splitlines()
        blocks = []
        for i, line in enumerate(lines):
            if line.strip().startswith(("class ", "def ", "async def ")):
                blocks.append("\n".join(lines[i:i+4]))
        if blocks:
            snippets.append(f"\n# === {path} ===\n" + "\n\n".join(blocks[:8]))
    return "\n".join(snippets[:15])


# ─── OLLAMA REASONING ─────────────────────────────────────────────────────────

def ollama_reason(model: str, structure: dict, changes: dict, plan: dict, files: dict) -> str:
    import ollama

    file_list = "\n".join(f"  - {p}" for p in list(files.keys())[:30])
    change_text = "\n".join(
        f"  - [{c['date']}] {c['file']}: {c['description']}"
        + (("\n    " + "\n    ".join(c.get("line_changes", []))) if c.get("line_changes") else "")
        for c in changes.get("changes", [])
    ) or "  None"

    prompt = f"""You are a senior software architect analyzing a coding project.
Based on the info below, write a concise project status summary (max 250 words).
Focus on: what is working, what changed recently (be specific about the line changes), and what to work on next.
Use bullet points. Be direct.

FRAMEWORK: {structure['framework']}
FILES: {structure['total_files']} files, {structure['total_lines']} lines
ENTRY POINTS: {', '.join(structure['entry_points']) or 'not found'}
API FILES: {', '.join(structure['api_files']) or 'none'}
MODEL FILES: {', '.join(structure['model_files']) or 'none'}

ALL FILES:
{file_list}

RECENT CHANGES:
{change_text}

PLAN:
{plan.get('raw', 'No plan provided.')[:1000]}

Write the summary now:"""

    response = ollama.generate(model=model, prompt=prompt, options={"temperature": 0.2})
    return f"[{model}]\n" + response["response"]


# ─── FINAL CLAUDE PROMPT BUILDER ──────────────────────────────────────────────

def build_claude_prompt(
    file_tree, structure_analysis, changes_analysis,
    plan_analysis, key_code, ollama_summary, project_root, total_files
) -> str:

    now = datetime.now().strftime("%Y-%m-%d %H:%M")
    project_name = project_root.name

    # ── Changes section ──────────────────────────────────────────────────────
    if changes_analysis["is_first_run"]:
        changes_text = (
            "  (First T-RAG run — baseline snapshot saved)\n"
            "  Next run will show exactly what changed, line by line."
        )
    elif not changes_analysis["has_changes"]:
        changes_text = "  No changes detected since last scan."
    else:
        lines = []
        for c in changes_analysis["changes"]:
            tag = " [manual note]" if c.get("source") == "manual" else ""
            lines.append(f"  • [{c['date']}] {c['file']}: {c['description']}{tag}")
            # Show line-level changes indented underneath
            for lc in c.get("line_changes", []):
                lines.append(f"      ↳ {lc}")
        parts = []
        if changes_analysis["auto_count"]:
            parts.append(f"{changes_analysis['auto_count']} auto-detected")
        if changes_analysis["manual_count"]:
            parts.append(f"{changes_analysis['manual_count']} manual notes")
        header = f"  ({', '.join(parts)})\n" if parts else ""
        changes_text = header + "\n".join(lines)

    # ── Plan section ─────────────────────────────────────────────────────────
    if plan_analysis["has_plan"]:
        done_text   = "\n".join(f"  ✓ {i}" for i in plan_analysis["done_items"])   or "  (none)"
        inprog_text = "\n".join(f"  → {i}" for i in plan_analysis["in_progress"]) or "  (none)"
        todo_text   = "\n".join(f"  □ {i}" for i in plan_analysis["todo_items"])   or "  (none)"
        plan_section = f"""PLAN STATUS ({plan_analysis['summary']}):

COMPLETED:
{done_text}

IN PROGRESS:
{inprog_text}

TODO / NEXT:
{todo_text}

FULL PLAN:
{plan_analysis['raw'][:2000]}"""
    else:
        plan_section = "  (No plan file found — add todo.txt for better context)"

    # ── Ollama section ───────────────────────────────────────────────────────
    reasoning_section = ""
    if ollama_summary:
        reasoning_section = f"""
════════════════════════════════════════════════════════
AI PROJECT ANALYSIS:
════════════════════════════════════════════════════════
{ollama_summary}
"""

    return f"""════════════════════════════════════════════════════════
T-RAG CONTEXT SNAPSHOT — {project_name}
Generated: {now}
════════════════════════════════════════════════════════

PROJECT OVERVIEW:
  Name:          {project_name}
  Framework:     {structure_analysis['framework']}
  Total files:   {total_files}
  Total lines:   {structure_analysis['total_lines']}
  Entry points:  {', '.join(structure_analysis['entry_points']) or 'not detected'}
  API files:     {', '.join(structure_analysis['api_files']) or 'none'}
  Model files:   {', '.join(structure_analysis['model_files']) or 'none'}

════════════════════════════════════════════════════════
FOLDER & FILE STRUCTURE:
════════════════════════════════════════════════════════
{file_tree}

════════════════════════════════════════════════════════
WHAT CHANGED SINCE LAST SCAN:
════════════════════════════════════════════════════════
{changes_text}

════════════════════════════════════════════════════════
PLAN / GOALS:
════════════════════════════════════════════════════════
{plan_section}
{reasoning_section}
════════════════════════════════════════════════════════
KEY CODE STRUCTURE:
════════════════════════════════════════════════════════
{key_code}

════════════════════════════════════════════════════════
HOW TO USE THIS CONTEXT:
════════════════════════════════════════════════════════
This is an auto-generated snapshot of the entire project.
Claude now knows every file, what changed (with exact line diffs),
the project plan, and the key code structure.

Please help me continue. I will describe what I want to do next:

[YOUR QUESTION / TASK HERE]
════════════════════════════════════════════════════════
"""
