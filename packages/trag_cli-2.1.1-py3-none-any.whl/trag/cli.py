"""
T-RAG CLI — Main entry point.
After installing with pip, user runs:
    trag               (scans current folder)
    trag --project /path/to/project
    trag --help
"""

import os
import sys
import argparse
import datetime
from pathlib import Path


# ─── CONFIG ───────────────────────────────────────────────────────────────────

CODE_EXTENSIONS = {
    ".py", ".js", ".ts", ".jsx", ".tsx", ".html", ".css",
    ".json", ".yaml", ".yml", ".toml", ".env.example",
    ".md", ".txt", ".sql", ".sh"
}

SKIP_FOLDERS = {
    "__pycache__", ".git", "node_modules", ".venv", "venv",
    "env", ".env", "dist", "build", ".idea", ".vscode",
    "trag_data", "trag_output", "trag_system",
}

SKIP_FILES = {
    ".DS_Store", "Thumbs.db", "package-lock.json",
    "trag_changes.txt", "trag_snapshot.json",
}

PLAN_KEYWORDS = ["plan", "weekly", "todo", "task", "roadmap", "sprint", "goals"]


# ─── SCANNER ──────────────────────────────────────────────────────────────────

def find_weekly_plan(project_root: Path) -> Path | None:
    """Find a plan/todo/task file. Completely optional."""
    for f in project_root.rglob("*.txt"):
        if any(skip in f.parts for skip in SKIP_FOLDERS):
            continue
        if f.name in SKIP_FILES:
            continue
        if any(k in f.name.lower() for k in PLAN_KEYWORDS):
            return f
    return None


def scan_project(project_root: Path) -> dict:
    """Walk the project and collect all code files."""
    files = {}
    total_lines = 0
    skipped = 0

    print(f"\n📂 Scanning: {project_root}")
    print("─" * 50)

    for root, dirs, filenames in os.walk(project_root):
        dirs[:] = [d for d in dirs if d not in SKIP_FOLDERS and not d.startswith(".")]

        for filename in filenames:
            if filename in SKIP_FILES:
                continue
            filepath = Path(root) / filename
            suffix = filepath.suffix.lower()

            if suffix not in CODE_EXTENSIONS:
                skipped += 1
                continue

            rel_path = str(filepath.relative_to(project_root))

            try:
                content = filepath.read_text(encoding="utf-8", errors="ignore")
                lines = content.splitlines()
                total_lines += len(lines)
                files[rel_path] = {
                    "path": rel_path,
                    "extension": suffix,
                    "lines": len(lines),
                    "content": content,
                    "size_bytes": filepath.stat().st_size,
                    "modified": datetime.datetime.fromtimestamp(
                        filepath.stat().st_mtime
                    ).strftime("%Y-%m-%d %H:%M"),
                }
                print(f"  ✓ {rel_path:50s} ({len(lines)} lines)")
            except Exception as e:
                print(f"  ✗ {rel_path} — could not read: {e}")

    print("─" * 50)
    print(f"  Total: {len(files)} files  |  {total_lines} lines  |  {skipped} skipped")
    return files


def build_file_tree(files: dict) -> str:
    """Build a readable file tree."""
    tree_lines = []
    paths = sorted(files.keys())
    seen_folders = set()

    for path in paths:
        parts = Path(path).parts
        for i in range(len(parts) - 1):
            folder_path = os.sep.join(parts[:i+1])
            if folder_path not in seen_folders:
                seen_folders.add(folder_path)
                indent = "  " * i
                tree_lines.append(f"{indent}📁 {parts[i]}/")
        depth = len(parts) - 1
        indent = "  " * depth
        info = files[path]
        tree_lines.append(
            f"{indent}├── {parts[-1]}  ({info['lines']} lines, modified {info['modified']})"
        )

    return "\n".join(tree_lines)


# ─── MAIN ─────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        prog="trag",
        description="T-RAG: Build Claude context from your project automatically.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  trag                          # scan current folder
  trag --project /my/project    # scan a specific folder
  trag --plan todo.txt          # use a specific plan file
  trag --no-embed               # skip ChromaDB (faster)
  trag --init                   # create optional trag_changes.txt in current folder
        """
    )
    parser.add_argument(
        "--project", "-p", type=str, default=".",
        help="Path to project root (default: current directory)"
    )
    parser.add_argument(
        "--plan", type=str, default=None,
        help="Path to plan/todo .txt file (optional, auto-detected if not set)"
    )
    parser.add_argument(
        "--no-embed", action="store_true",
        help="Skip ChromaDB embedding (faster, less smart retrieval)"
    )
    parser.add_argument(
        "--init", action="store_true",
        help="Create a trag_changes.txt file in current folder for optional manual notes"
    )
    parser.add_argument(
        "--version", action="store_true",
        help="Show T-RAG version"
    )
    args = parser.parse_args()

    # Version
    if args.version:
        from trag import __version__
        print(f"T-RAG version {__version__}")
        return

    # Init — create optional changes file
    if args.init:
        changes_file = Path(".") / "trag_changes.txt"
        if changes_file.exists():
            print("trag_changes.txt already exists.")
        else:
            changes_file.write_text(
                "# OPTIONAL MANUAL CHANGES LOG\n"
                "# T-RAG auto-detects changes — this file is only for personal notes.\n"
                "# FORMAT: [DATE] FILE: what you changed and why\n"
                "# EXAMPLE: [2024-01-20] api/auth.py: Changed JWT expiry to 7 days\n\n",
                encoding="utf-8"
            )
            print("✓ Created trag_changes.txt — add personal notes here (optional).")
        return

    project_root = Path(args.project).resolve()
    if not project_root.exists():
        print(f"❌ Project path not found: {project_root}")
        sys.exit(1)

    print("\n" + "═" * 50)
    print("  🧠 T-RAG")
    print("═" * 50)

    # Import here (after install, these are always available)
    from trag.trag_chunker import chunk_and_embed
    from trag.trag_reasoner import build_context_summary
    from trag.trag_exporter import export_context
    from trag.trag_tracker import get_all_changes

    # 1. Scan files
    files = scan_project(project_root)
    if not files:
        print("❌ No code files found. Check your path.")
        sys.exit(1)

    # 2. Auto-detect what changed
    print("\n🔍 Detecting changes...")
    changes_result = get_all_changes(project_root)

    # 3. Find plan — fully optional
    plan_path = Path(args.plan) if args.plan else find_weekly_plan(project_root)
    plan_content = ""
    if plan_path and plan_path.exists():
        plan_content = plan_path.read_text(encoding="utf-8", errors="ignore")
        print(f"\n📋 Plan file found: {plan_path.name}")
    else:
        print("\nℹ️  No plan file — working without one (that's fine).")

    # 4. Embed into ChromaDB
    chroma_collection = None
    if not args.no_embed:
        try:
            print("\n🔍 Embedding into ChromaDB...")
            chroma_collection = chunk_and_embed(files, project_root)
        except Exception as e:
            print(f"⚠️  Embedding skipped: {e}")

    # 5. Build context summary
    print("\n🧠 Building context summary...")
    file_tree = build_file_tree(files)
    context = build_context_summary(
        files=files,
        file_tree=file_tree,
        plan_content=plan_content,
        changes_result=changes_result,
        chroma_collection=chroma_collection,
        project_root=project_root,
    )

    # 6. Export
    print("\n" + "═" * 50)
    export_context(context, project_root)


if __name__ == "__main__":
    main()
