"""
T-RAG Local Change Tracker
============================
Tracks what changed between the last trag run and right now.

Storage strategy:
  - Only ONE snapshot is ever kept — the state from the last run.
  - Every run overwrites the old snapshot with the current state.
  - So the file never grows. It stays exactly the size of your codebase.
  - History is NOT stored. This is "last run vs right now" only.

  Run 1 → saves snapshot A
  Run 2 → loads A, diffs vs B, shows changes → saves B  (A is gone)
  Run 3 → loads B, diffs vs C, shows changes → saves C  (B is gone)
"""

import os
import json
import hashlib
import difflib
import datetime
from pathlib import Path


# ─── CONFIG ───────────────────────────────────────────────────────────────────

CODE_EXTENSIONS = {
    ".py", ".js", ".ts", ".jsx", ".tsx", ".html", ".css",
    ".json", ".yaml", ".yml", ".toml", ".sql", ".sh", ".md", ".txt"
}

SKIP_FOLDERS = {
    "__pycache__", ".git", "node_modules", ".venv", "venv",
    "env", ".env", "dist", "build", "trag_data", "trag_output",
    "trag_system", ".idea", ".vscode",
}

SKIP_FILES = {
    "trag_changes.txt", "trag_snapshot.json", ".DS_Store", "Thumbs.db"
}

SNAPSHOT_FILENAME = "trag_snapshot.json"
MAX_FILE_SIZE_FOR_DIFF = 500_000   # Skip content storage for files over 500KB
MAX_DIFF_LINES_PER_FILE = 8        # Max change lines shown per file


# ─── SNAPSHOT ─────────────────────────────────────────────────────────────────

def hash_file(filepath: Path) -> str:
    try:
        return hashlib.md5(filepath.read_bytes()).hexdigest()
    except Exception:
        return ""


def scan_all_files(project_root: Path) -> dict:
    """
    Scan entire project. For each file store:
      hash     — to detect IF it changed (fast)
      modified — last modified timestamp
      lines    — content lines for line-level diff (only if file < 500KB)

    This snapshot is always overwritten on next run — never accumulates.
    """
    snapshot = {}

    for root, dirs, files in os.walk(project_root):
        dirs[:] = [d for d in dirs if d not in SKIP_FOLDERS and not d.startswith(".")]

        for filename in files:
            if filename in SKIP_FILES:
                continue
            filepath = Path(root) / filename
            if filepath.suffix.lower() not in CODE_EXTENSIONS:
                continue

            try:
                rel_path = str(filepath.relative_to(project_root))
                stat = filepath.stat()

                content_lines = []
                if stat.st_size < MAX_FILE_SIZE_FOR_DIFF:
                    try:
                        content_lines = filepath.read_text(
                            encoding="utf-8", errors="ignore"
                        ).splitlines()
                    except Exception:
                        pass

                snapshot[rel_path] = {
                    "hash": hash_file(filepath),
                    "modified": datetime.datetime.fromtimestamp(
                        stat.st_mtime
                    ).strftime("%Y-%m-%d %H:%M"),
                    "lines": content_lines,   # stored for diff, cleared next run
                }
            except Exception:
                pass

    return snapshot


def load_snapshot(project_root: Path):
    """Load the last saved snapshot. Returns None on first run."""
    p = project_root / "trag_data" / SNAPSHOT_FILENAME
    if not p.exists():
        return None
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        return None


def save_snapshot(project_root: Path, snapshot: dict):
    """
    Overwrite the snapshot with current state.
    Old snapshot is completely replaced — no history kept.
    """
    data_dir = project_root / "trag_data"
    data_dir.mkdir(parents=True, exist_ok=True)
    try:
        (data_dir / SNAPSHOT_FILENAME).write_text(
            json.dumps(snapshot, indent=2), encoding="utf-8"
        )
    except Exception as e:
        print(f"   ⚠  Could not save snapshot: {e}")


# ─── LINE-LEVEL DIFF ──────────────────────────────────────────────────────────

def diff_file_lines(old_lines: list, new_lines: list) -> list:
    """
    Compare two versions of a file and return human-readable change descriptions.

    Examples of output:
      "line 12: 'def login()' → 'def login(request)'"
      "line 34: removed 'print(debug)'"
      "line 45: added 'return jsonify(result)'"

    Capped at MAX_DIFF_LINES_PER_FILE entries per file to keep output clean.
    """
    if not old_lines and not new_lines:
        return []

    changes = []
    matcher = difflib.SequenceMatcher(None, old_lines, new_lines, autojunk=False)

    def trim(s: str, n: int = 65) -> str:
        s = s.strip()
        return (s[:n] + "…") if len(s) > n else s

    for tag, i1, i2, j1, j2 in matcher.get_opcodes():
        if tag == "equal":
            continue

        if tag == "replace":
            old_chunk = old_lines[i1:i2]
            new_chunk = new_lines[j1:j2]
            pairs = list(zip(old_chunk, new_chunk))

            for k, (old_line, new_line) in enumerate(pairs):
                o, n = old_line.strip(), new_line.strip()
                if o and n and o != n:
                    changes.append(
                        f"line {i1+k+1}: '{trim(o)}' → '{trim(n)}'"
                    )

            # Lines in new_chunk beyond the paired range = added
            for k, line in enumerate(new_chunk[len(pairs):]):
                s = line.strip()
                if s:
                    changes.append(f"line {j1+len(pairs)+k+1}: added '{trim(s)}'")

            # Lines in old_chunk beyond the paired range = removed
            for k, line in enumerate(old_chunk[len(pairs):]):
                s = line.strip()
                if s:
                    changes.append(f"line {i1+len(pairs)+k+1}: removed '{trim(s)}'")

        elif tag == "insert":
            for k, line in enumerate(new_lines[j1:j2]):
                s = line.strip()
                if s:
                    changes.append(f"line {j1+k+1}: added '{trim(s)}'")

        elif tag == "delete":
            for k, line in enumerate(old_lines[i1:i2]):
                s = line.strip()
                if s:
                    changes.append(f"line {i1+k+1}: removed '{trim(s)}'")

        if len(changes) >= MAX_DIFF_LINES_PER_FILE:
            changes.append(f"… and more (showing first {MAX_DIFF_LINES_PER_FILE})")
            break

    return changes


# ─── MANUAL LOG READER ────────────────────────────────────────────────────────

def read_manual_log(project_root: Path) -> list:
    """Read trag_changes.txt if user wrote optional notes. Returns empty list if none."""
    import re
    for name in ["trag_changes.txt", "change_log.txt", "changes.txt", "my_changes.txt"]:
        p = project_root / name
        if not p.exists():
            continue
        try:
            entries = []
            for line in p.read_text(encoding="utf-8", errors="ignore").splitlines():
                line = line.strip()
                if not line or line.startswith("#"):
                    continue
                m = re.match(r"\[([^\]]+)\]\s+([^:]+):\s+(.+)", line)
                if m:
                    entries.append({
                        "date": m.group(1).strip(),
                        "file": m.group(2).strip(),
                        "description": m.group(3).strip(),
                        "line_changes": [],
                        "source": "manual",
                    })
                else:
                    entries.append({
                        "date": "?", "file": "?",
                        "description": line,
                        "line_changes": [],
                        "source": "manual",
                    })
            return entries
        except Exception:
            pass
    return []


# ─── MAIN FUNCTION ────────────────────────────────────────────────────────────

def get_all_changes(project_root: Path) -> dict:
    """
    Main entry point called by cli.py.

    Returns a dict with everything the reasoner needs:
      has_changes, is_first_run, all_changes (with line_changes per file),
      summary, auto_changes, manual_changes
    """
    print("  → Scanning for file changes...")

    current_snapshot = scan_all_files(project_root)
    old_snapshot = load_snapshot(project_root)
    is_first_run = old_snapshot is None

    auto_changes = []
    today = datetime.datetime.now().strftime("%Y-%m-%d")

    if not is_first_run:
        # ── Find modified files ──────────────────────────────────────────────
        for filepath, new_info in current_snapshot.items():
            if filepath not in old_snapshot:
                # New file added
                auto_changes.append({
                    "date": new_info["modified"],
                    "file": filepath,
                    "description": "new file added",
                    "line_changes": [],
                    "source": "auto",
                })
            elif old_snapshot[filepath]["hash"] != new_info["hash"]:
                # File changed — run line diff
                old_lines = old_snapshot[filepath].get("lines", [])
                new_lines = new_info.get("lines", [])
                line_changes = diff_file_lines(old_lines, new_lines)

                auto_changes.append({
                    "date": new_info["modified"],
                    "file": filepath,
                    "description": "modified",
                    "line_changes": line_changes,
                    "source": "auto",
                })

        # ── Find deleted files ───────────────────────────────────────────────
        for filepath in old_snapshot:
            if filepath not in current_snapshot:
                auto_changes.append({
                    "date": today,
                    "file": filepath,
                    "description": "deleted",
                    "line_changes": [],
                    "source": "auto",
                })

    # ── Read optional manual notes ───────────────────────────────────────────
    manual_changes = read_manual_log(project_root)

    # Combine — manual first (they have context), auto fills the rest
    manual_files = {c["file"] for c in manual_changes}
    auto_only = [c for c in auto_changes if c["file"] not in manual_files]
    all_changes = manual_changes + auto_only

    # ── Save new snapshot (overwrites old — no history kept) ─────────────────
    save_snapshot(project_root, current_snapshot)

    # ── Build summary string ─────────────────────────────────────────────────
    n_mod = sum(1 for c in auto_changes if c["description"] == "modified")
    n_add = sum(1 for c in auto_changes if c["description"] == "new file added")
    n_del = sum(1 for c in auto_changes if c["description"] == "deleted")
    n_manual = len(manual_changes)

    if is_first_run:
        summary = f"First run — baseline saved ({len(current_snapshot)} files tracked)"
        print(f"  → Snapshot created: {len(current_snapshot)} files tracked")
        print("     Next run will show exactly what changed, line by line.")
    elif not all_changes:
        summary = "No changes detected since last scan"
        print("  → No changes since last scan")
    else:
        parts = []
        if n_mod: parts.append(f"{n_mod} modified")
        if n_add: parts.append(f"{n_add} added")
        if n_del: parts.append(f"{n_del} deleted")
        if n_manual: parts.append(f"{n_manual} manual notes")
        summary = ", ".join(parts)
        print(f"  → Changes detected: {summary}")

    return {
        "has_changes": bool(all_changes),
        "is_first_run": is_first_run,
        "auto_changes": auto_changes,
        "manual_changes": manual_changes,
        "all_changes": all_changes,
        "summary": summary,
        "snapshot_saved": True,
    }
