"""
T-RAG Chunker + Embedder
=========================
Splits code files into chunks and stores them in ChromaDB
using local embeddings via Ollama (nomic-embed-text model).

This makes retrieval SMART — instead of dumping every file,
we retrieve only the most relevant chunks for the context.

Install:
    pip install chromadb
    ollama pull nomic-embed-text
"""

import hashlib
import re
from pathlib import Path
import os
import platform

def _add_ollama_to_path():
    """Add Ollama to PATH on Windows based on current username."""
    if platform.system() == "Windows":
        username = os.environ.get("USERNAME", "")
        ollama_path = rf"C:\Users\{username}\AppData\Local\Programs\Ollama"
        if ollama_path not in os.environ.get("PATH", ""):
            os.environ["PATH"] += f";{ollama_path}"

_add_ollama_to_path()

# ─── CHUNKING ─────────────────────────────────────────────────────────────────

CHUNK_SIZE = 60       # lines per chunk
CHUNK_OVERLAP = 10    # overlap between chunks to preserve context


def chunk_file(file_info: dict) -> list[dict]:
    """Split a file into overlapping chunks."""
    content = file_info["content"]
    path = file_info["path"]
    ext = file_info["extension"]
    lines = content.splitlines()

    chunks = []

    # For short files, keep as single chunk
    if len(lines) <= CHUNK_SIZE:
        chunks.append({
            "id": make_chunk_id(path, 0),
            "text": content,
            "path": path,
            "chunk_index": 0,
            "start_line": 1,
            "end_line": len(lines),
            "extension": ext,
        })
        return chunks

    # Sliding window chunking
    i = 0
    chunk_index = 0
    while i < len(lines):
        end = min(i + CHUNK_SIZE, len(lines))
        chunk_lines = lines[i:end]
        chunk_text = "\n".join(chunk_lines)

        chunks.append({
            "id": make_chunk_id(path, chunk_index),
            "text": f"# File: {path} (lines {i+1}-{end})\n{chunk_text}",
            "path": path,
            "chunk_index": chunk_index,
            "start_line": i + 1,
            "end_line": end,
            "extension": ext,
        })

        i += (CHUNK_SIZE - CHUNK_OVERLAP)
        chunk_index += 1

    return chunks


def make_chunk_id(path: str, chunk_index: int) -> str:
    raw = f"{path}::{chunk_index}"
    return hashlib.md5(raw.encode()).hexdigest()


def extract_python_structure(content: str) -> list[str]:
    """Extract function and class names from Python files for better metadata."""
    symbols = []
    for line in content.splitlines():
        stripped = line.strip()
        if stripped.startswith("def ") or stripped.startswith("async def "):
            match = re.match(r"(?:async )?def (\w+)", stripped)
            if match:
                symbols.append(f"function:{match.group(1)}")
        elif stripped.startswith("class "):
            match = re.match(r"class (\w+)", stripped)
            if match:
                symbols.append(f"class:{match.group(1)}")
    return symbols


# ─── EMBEDDING + CHROMADB ─────────────────────────────────────────────────────

def chunk_and_embed(files: dict, project_root: Path):
    """
    Chunk all files and embed them into ChromaDB.
    Uses Ollama's nomic-embed-text for local embeddings.
    """
    try:
        import chromadb
        from chromadb.utils import embedding_functions
    except ImportError:
        raise ImportError(
            "ChromaDB not installed. Run: pip install chromadb"
        )

    # Set up persistent local ChromaDB
    db_path = project_root / "trag_data" / "chroma_db"
    db_path.mkdir(parents=True, exist_ok=True)

    client = chromadb.PersistentClient(path=str(db_path))

    # Try Ollama embeddings, fall back to default
    try:
        import os
        os.environ["PATH"] += r";C:\Users\hiren\AppData\Local\Programs\Ollama"
        import ollama
        ollama.embed(model="nomic-embed-text", input="test")
        ef = OllamaEmbeddingFunction(model="nomic-embed-text")
        print("   Using Ollama nomic-embed-text embeddings ✓")
    except Exception as e:
        print(f"   ⚠️  Falling back to default embeddings ({e})")
        ef = embedding_functions.DefaultEmbeddingFunction()

    # Delete old collection and rebuild fresh (keeps it in sync with your code)
    try:
        client.delete_collection("trag_codebase")
    except Exception:
        pass
    except Exception:
        import shutil
        shutil.rmtree(str(db_path), ignore_errors=True)
        db_path.mkdir(parents=True, exist_ok=True)

    collection = client.create_collection(
        name="trag_codebase",
        embedding_function=ef,
        metadata={"hnsw:space": "cosine"}
    )

    # Chunk and add all files
    all_chunks = []
    for file_info in files.values():
        chunks = chunk_file(file_info)
        all_chunks.extend(chunks)

    if not all_chunks:
        return collection

    # Batch insert (ChromaDB prefers batches)
    BATCH_SIZE = 50
    for i in range(0, len(all_chunks), BATCH_SIZE):
        batch = all_chunks[i:i + BATCH_SIZE]
        collection.add(
            ids=[c["id"] for c in batch],
            documents=[c["text"] for c in batch],
            metadatas=[{
                "path": c["path"],
                "chunk_index": c["chunk_index"],
                "start_line": c["start_line"],
                "end_line": c["end_line"],
                "extension": c["extension"],
            } for c in batch],
        )
        print(f"   Embedded chunks {i+1}–{min(i+BATCH_SIZE, len(all_chunks))} / {len(all_chunks)}")

    print(f"   ✓ Total chunks in DB: {collection.count()}")
    return collection


# ─── OLLAMA EMBEDDING FUNCTION ─────────────────────────────────────────────────

class OllamaEmbeddingFunction:
    """Custom embedding function using Ollama's local API."""

    def __init__(self, model: str = "nomic-embed-text"):
        self.model = model

    def __call__(self, input: list[str]) -> list[list[float]]:
        import os
        os.environ["PATH"] += r";C:\Users\hiren\AppData\Local\Programs\Ollama"
        import ollama
        embeddings = []
        for text in input:
            response = ollama.embed(model=self.model, input=text)
            embeddings.append(response.embeddings[0])
        return embeddings

# ─── RETRIEVAL ─────────────────────────────────────────────────────────────────

def retrieve_relevant_chunks(collection, query: str, n_results: int = 5) -> list[dict]:
    """Retrieve the most relevant code chunks for a query."""
    try:
        results = collection.query(
            query_texts=[query],
            n_results=min(n_results, collection.count()),
        )
        chunks = []
        for i, doc in enumerate(results["documents"][0]):
            chunks.append({
                "text": doc,
                "path": results["metadatas"][0][i]["path"],
                "score": 1 - results["distances"][0][i],  # cosine similarity
            })
        return chunks
    except Exception as e:
        return []
