"""Generated entity placeholders inferred from formula imports."""

dab_required: object = object()
