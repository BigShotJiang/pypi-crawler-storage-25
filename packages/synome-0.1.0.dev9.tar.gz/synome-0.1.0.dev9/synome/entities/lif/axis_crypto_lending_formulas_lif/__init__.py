"""Generated entity placeholders inferred from formula imports."""

lif: object = object()
