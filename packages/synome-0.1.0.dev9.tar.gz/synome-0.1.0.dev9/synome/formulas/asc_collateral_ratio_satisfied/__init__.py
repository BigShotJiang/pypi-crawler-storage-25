from typing import Annotated
from client.synome.entities._shared.axis_asc_entities_primes import EligiblePrimeAgentASC
from client.synome.entities._shared.axis_asc_entities_types import Position
from client.synome.formulas.latent_asc import latent_asc
from client.synome.formulas.resting_asc import resting_asc
from axis_synome.spec_support.metadata import Metadata

def collateral_portfolio(positions: list[Position]) -> Annotated[float, Metadata(description='Total Collateral Portfolio value for a prime: sum of all position values.', source_uuid='64e1390f-68a1-43ec-87a8-8ae7b990f7ec')]:
    """Total Collateral Portfolio value for a prime: sum of all positions."""
    return sum((p.value_usd for p in positions))

def asc_collateral_ratio(prime: EligiblePrimeAgentASC, positions: list[Position]) -> Annotated[float, Metadata(description='ASC collateral ratio slack: ASC minus the required minimum fraction of the Collateral Portfolio. Must be >= 0 for compliance.', source_uuid='475fe222-9e4a-4e9d-9be6-a7a424ce02f8')]:
    """ASC collateral ratio slack.

    Returns the arithmetic result unconditionally.  A negative value means
    ASC is below the required minimum fraction of the Collateral Portfolio.
    """
    agent = prime.value
    asc_usd: float = resting_asc(positions) + latent_asc(prime, positions)
    portfolio_usd: float = collateral_portfolio(positions)
    return asc_usd - portfolio_usd * agent.min_pct_asc_of_collateral

def asc_collateral_ratio_satisfied(prime: EligiblePrimeAgentASC, positions: list[Position]) -> Annotated[bool, Metadata(description='True when ASC meets or exceeds the required minimum fraction of the Collateral Portfolio.', source_uuid='475fe222-9e4a-4e9d-9be6-a7a424ce02f8')]:
    """Boolean ASC collateral ratio compliance predicate. True iff asc_collateral_ratio >= 0."""
    return asc_collateral_ratio(prime, positions) >= 0.0

formula_asc_collateral_ratio_satisfied = asc_collateral_ratio_satisfied
