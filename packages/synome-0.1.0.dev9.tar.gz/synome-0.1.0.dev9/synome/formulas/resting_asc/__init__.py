from typing import Annotated
from client.synome.entities.asc.axis_asc_entities_networks import L2_NETWORKS
from client.synome.entities.asc.axis_asc_entities_protocol_sets import GUNI_PROTOCOLS, GUNI_RESTING_FEE_TIERS, L1_PSM_PROTOCOLS, L2_PSM_PROTOCOLS, POOL_PROTOCOLS
from client.synome.entities.asc.axis_asc_entities_tokens import CASH_STABLECOINS, Token
from client.synome.entities._shared.axis_asc_entities_types import Position
from axis_synome.spec_support.metadata import Metadata

def resting_asc(positions: list[Position]) -> Annotated[float, Metadata(description='Resting ASC: immediately liquid stabilizing capital held by a prime.', source_uuid='4e8cd2d1-4c74-49fd-b3fe-f8b6ccc1a79f')]:
    """Resting ASC for a prime: immediately liquid stabilizing capital.

    Includes:
    - USDC held in LitePSM (L1 peg-stability module)
    - USDC held in PSM3 on eligible L2 networks
    - Cash stablecoins in Curve/Uniswap pools paired with USDS
    - USDC in G-UNI at eligible fee tiers (0.01% = 0.0001, 0.05% = 0.0005)

    All positions are assumed to belong to this prime.
    """
    return sum((p.value_usd for p in positions if p.asset.protocol in L1_PSM_PROTOCOLS and p.asset.underlying_asset == Token.USDC or (p.asset.protocol in L2_PSM_PROTOCOLS and p.asset.underlying_asset == Token.USDC and (p.asset.network in L2_NETWORKS)) or (p.asset.protocol in POOL_PROTOCOLS and p.asset.underlying_asset in CASH_STABLECOINS and p.pool_paired_with_usds) or (p.asset.protocol in GUNI_PROTOCOLS and p.asset.underlying_asset == Token.USDC and (p.fee_tier in GUNI_RESTING_FEE_TIERS))))

formula_resting_asc = resting_asc
