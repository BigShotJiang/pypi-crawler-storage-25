from typing import Annotated
from client.synome.entities._shared.axis_asc_entities_primes import EligiblePrimeAgentASC
from client.synome.entities._shared.axis_asc_entities_types import Position
from client.synome.formulas.latent_asc import latent_asc
from client.synome.formulas.resting_asc import resting_asc
from axis_synome.spec_support.metadata import Metadata

def ratio_latent_asc(prime: EligiblePrimeAgentASC, positions: list[Position]) -> Annotated[float, Metadata(description='Latent ASC ratio slack: permitted latent cap minus actual latent ASC. Must be >= 0 for compliance.', source_uuid='5e300cdb-b221-4b6f-9c4a-11502133a1f9')]:
    """Latent ASC ratio slack.

    Returns the arithmetic result unconditionally.  A negative value means
    LatentASC exceeds the permitted fraction of total ASC.
    """
    agent = prime.value
    latent_usd: float = latent_asc(prime, positions)
    total_usd: float = resting_asc(positions) + latent_usd
    return total_usd * agent.max_pct_latent_asc - latent_usd

def latent_asc_ratio_satisfied(prime: EligiblePrimeAgentASC, positions: list[Position]) -> Annotated[bool, Metadata(description='True when latent ASC is within the permitted fraction of total ASC.', source_uuid='5e300cdb-b221-4b6f-9c4a-11502133a1f9')]:
    """Boolean latent ASC ratio compliance predicate. True iff ratio_latent_asc >= 0."""
    return ratio_latent_asc(prime, positions) >= 0.0

formula_latent_asc_ratio_satisfied = latent_asc_ratio_satisfied
