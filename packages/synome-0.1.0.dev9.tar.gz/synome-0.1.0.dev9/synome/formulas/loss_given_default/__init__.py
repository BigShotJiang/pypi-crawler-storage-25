"""Generated identities."""

def formula_loss_given_default(recovery: float) -> float:
    """
    Fractional loss on a collateral position at a given slippage

    Atlas section: c9bd4928-d054-4e89-9a98-720c439b0db3
    """
    return max(0.0, min(1.0, 1.0 - recovery))
