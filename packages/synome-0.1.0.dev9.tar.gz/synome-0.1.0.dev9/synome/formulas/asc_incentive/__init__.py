from typing import Annotated
from client.synome.entities._shared.axis_asc_entities_primes import EligiblePrimeAgentASC
from client.synome.entities._shared.axis_asc_entities_types import Position
from client.synome.formulas.latent_asc import latent_asc
from client.synome.formulas.resting_asc import resting_asc
from axis_synome.spec_support.metadata import Metadata

def asc_incentive(prime: EligiblePrimeAgentASC, positions: list[Position], base_rate: float, treasury_bill_rate: float) -> Annotated[float, Metadata(description='ASC incentive payment: eligible ASC multiplied by the spread between base rate and treasury bill rate.', source_uuid='693330d6-9072-4054-bd61-d788537e34e8')]:
    """
    ASC incentive payment
    """
    eligible_asc_usd: float = resting_asc(positions) + latent_asc(prime, positions)
    return eligible_asc_usd * (base_rate - treasury_bill_rate)

formula_asc_incentive = asc_incentive
