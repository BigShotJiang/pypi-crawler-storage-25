"""Generated identities."""

def formula_lif(M: float, denominator: float) -> float:
    """
    Liquidation incentive factor for a given LLTV

    Atlas section: Formula Evaluation
    """
    return min(M, 1.0/denominator)
