from typing import Annotated
from client.synome.entities._shared.axis_asc_entities_primes import EligiblePrimeAgentASC
from client.synome.entities.asc.axis_asc_entities_protocol_sets import LENDING_PROTOCOLS, POOL_PROTOCOLS
from client.synome.entities.asc.axis_asc_entities_tokens import CASH_STABLECOINS
from client.synome.entities._shared.axis_asc_entities_types import Position
from axis_synome.spec_support.metadata import Metadata

def latent_asc(prime: EligiblePrimeAgentASC, positions: list[Position]) -> Annotated[float, Metadata(description='Latent ASC: stabilizing capital not immediately liquid, held by a prime.', source_uuid='35ce6b38-9fc1-456e-93da-10ab1468a8bf')]:
    """Latent ASC for a prime: which is the stabilizing capital not immediately liquid.

    Includes:
    - Cash stablecoins in Curve/Uniswap pools NOT paired with USDS
    - Cash stablecoins in lending protocols (SparkLend, Aave, Morpho)
    - Cash stablecoins in the prime's ALM proxy

    Pool positions paired with USDS are excluded (those contribute to
    RestingASC).
    """
    agent = prime.value
    return sum((p.value_usd for p in positions if p.asset.underlying_asset in CASH_STABLECOINS and (p.asset.protocol in POOL_PROTOCOLS and (not p.pool_paired_with_usds) or p.asset.protocol in LENDING_PROTOCOLS or (agent.alm_proxy and p.asset.protocol == agent.alm_proxy))))

formula_latent_asc = latent_asc
