# banterbotapi

Python SDK for building bots on [Banter](https://banterchat.org).

```bash
pip install banterbotapi
```

```python
from banterapi import Bot, Intents

bot = Bot(intents=Intents.default() | Intents.MESSAGE_CONTENT)
bot.run("YOUR_TOKEN")
```

Install name is `banterbotapi`, import name is `banterapi` (same pattern as Pillow/PIL).
