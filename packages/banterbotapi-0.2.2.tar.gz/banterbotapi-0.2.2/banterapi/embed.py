class Embed:
    def __init__(self, title="", description="", color=None, url="", image="", thumbnail=""):
        self._data = {}
        if title:
            self._data["title"] = title
        if description:
            self._data["description"] = description
        if color is not None:
            self._data["color"] = color if isinstance(color, str) else f"#{color:06x}"
        if url:
            self._data["url"] = url
        if image:
            self._data["image"] = image
        if thumbnail:
            self._data["thumbnail"] = thumbnail
        self._data["fields"] = []

    def add_field(self, name, value, inline=False):
        self._data["fields"].append({"name": name, "value": value, "inline": inline})
        return self

    def set_footer(self, text):
        self._data["footer"] = text
        return self

    def set_author(self, name):
        self._data["author"] = name
        return self

    def set_image(self, url):
        self._data["image"] = url
        return self

    def set_thumbnail(self, url):
        self._data["thumbnail"] = url
        return self

    def add_button(self, label, style="secondary", url="", emoji="", disabled=False, id=""):
        btn = {"label": label, "style": style}
        if url:
            btn["url"] = url
        if emoji:
            btn["emoji"] = emoji
        if disabled:
            btn["disabled"] = True
        if id:
            btn["id"] = id
        self._data.setdefault("buttons", []).append(btn)
        return self

    def to_dict(self):
        d = dict(self._data)
        if not d.get("fields"):
            d.pop("fields", None)
        if not d.get("buttons"):
            d.pop("buttons", None)
        return d