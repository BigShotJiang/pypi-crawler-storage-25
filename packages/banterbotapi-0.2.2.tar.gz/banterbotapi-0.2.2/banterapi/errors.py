"""Exception hierarchy raised by the SDK.

All SDK-raised exceptions derive from :class:`BanterError` so user code
can catch the whole family with a single ``except BanterError:`` clause.

HTTP-shaped errors (anything from the REST client) inherit from
:class:`HTTPException` and carry both the wire ``status`` (int, HTTP
status code) and the server-assigned ``code`` (int, a stable API error
code — see ``docs/bots.md`` for the table). Gateway-shaped errors
inherit from :class:`GatewayError`.

:class:`LoginFailure` is a distinct terminal error: raised when the
token is rejected on REST or gateway connect. Library users should not
reconnect on this — they need a new token.
"""


class BanterError(Exception):
    """Base class for every exception the SDK raises.

    Catching this catches everything — HTTP failures, gateway failures,
    permission errors, login errors.
    """


class HTTPException(BanterError):
    """Raised when a REST call returns a non-2xx status.

    Attributes:
        status: HTTP status code (e.g. 400, 403, 500).
        code: API error code from the server's JSON body, or 0 if the
            response had no structured error code.
        message: Human-readable error message from the server.
    """

    def __init__(self, status, code, message):
        self.status = status
        self.code = code
        self.message = message
        super().__init__(f"{status} {code}: {message}")


class Forbidden(HTTPException):
    """HTTP 403 — the bot lacks the permissions for this request.

    The bot's role mask in the target guild doesn't include the required
    bit (or the bot isn't a member of that guild at all).
    """


class NotFound(HTTPException):
    """HTTP 404 — the resource (message, channel, guild, etc) does not exist."""


class RateLimited(HTTPException):
    """HTTP 429 — the request was rate-limited and the SDK already retried once.

    Attributes:
        retry_after: Seconds to wait before retrying (float). Mirrored
            from the server's ``X-RateLimit-Reset-After`` header.
    """

    def __init__(self, status, code, message, retry_after):
        super().__init__(status, code, message)
        self.retry_after = retry_after


class GatewayError(BanterError):
    """Raised for any gateway-level failure (connect, heartbeat, protocol).

    Usually transient — :class:`~banterapi.Bot` will reconnect
    automatically when ``reconnect=True``. A :class:`LoginFailure` is
    raised instead of :class:`GatewayError` when the token itself is
    rejected.
    """


class LoginFailure(BanterError):
    """Raised when authentication is rejected (HTTP 401 or gateway 4004).

    This is terminal: the SDK will not auto-reconnect. Rotate the token
    from the developer portal and try again.
    """


class MissingPermissions(BanterError):
    """Raised by a command when the invoker lacks required permissions.

    Fired by the :func:`~banterapi.has_permissions` decorator before the
    command body runs. Catch via ``on_command_error``.

    Attributes:
        missing: List of permission-name strings the invoker was missing.
    """

    def __init__(self, missing):
        self.missing = missing
        names = ", ".join(missing) if missing else "unknown"
        super().__init__(f"Missing permissions: {names}")