"""Permission bits — mirror modules/permissions/perms.go exactly."""


class Permissions:
    SEND_MESSAGES      = 1 << 0
    MANAGE_CHANNELS    = 1 << 1
    MANAGE_ROLES       = 1 << 2
    MANAGE_MESSAGES    = 1 << 3
    ADMINISTRATOR      = 1 << 4
    MENTION_EVERYONE   = 1 << 5
    VIEW_CHANNELS      = 1 << 6
    ATTACH_FILES       = 1 << 7
    BAN_MEMBERS        = 1 << 8
    USE_SLASH_COMMANDS = 1 << 9
    MANAGE_GUILD       = 1 << 10
    KICK_MEMBERS       = 1 << 11

    ALL = (
        SEND_MESSAGES | MANAGE_CHANNELS | MANAGE_ROLES | MANAGE_MESSAGES
        | ADMINISTRATOR | MENTION_EVERYONE | VIEW_CHANNELS | ATTACH_FILES
        | BAN_MEMBERS | USE_SLASH_COMMANDS | MANAGE_GUILD | KICK_MEMBERS
    )


_NAMES = {
    Permissions.SEND_MESSAGES:      "send_messages",
    Permissions.MANAGE_CHANNELS:    "manage_channels",
    Permissions.MANAGE_ROLES:       "manage_roles",
    Permissions.MANAGE_MESSAGES:    "manage_messages",
    Permissions.ADMINISTRATOR:      "administrator",
    Permissions.MENTION_EVERYONE:   "mention_everyone",
    Permissions.VIEW_CHANNELS:      "view_channels",
    Permissions.ATTACH_FILES:       "attach_files",
    Permissions.BAN_MEMBERS:        "ban_members",
    Permissions.USE_SLASH_COMMANDS: "use_slash_commands",
    Permissions.MANAGE_GUILD:       "manage_guild",
    Permissions.KICK_MEMBERS:       "kick_members",
}


def has_perm(bitmask, required):
    """True if bitmask has every bit in required (or Administrator)."""
    if bitmask & Permissions.ADMINISTRATOR:
        return True
    return (bitmask & required) == required


def describe(bitmask):
    """Return a sorted list of permission names present in a bitmask."""
    return sorted(name for bit, name in _NAMES.items() if bitmask & bit)