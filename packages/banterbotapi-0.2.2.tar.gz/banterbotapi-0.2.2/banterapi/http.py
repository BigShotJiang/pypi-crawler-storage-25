"""Async REST client for the Banter bot API.

:class:`HTTPClient` wraps an :class:`aiohttp.ClientSession` with:

* Bot-token auth (``Authorization: Bot <token>``) applied to every request.
* One automatic retry on HTTP 429 using the server's
  ``X-RateLimit-Reset-After`` header; further 429s raise
  :class:`~banterapi.errors.RateLimited`.
* HTTP status → exception mapping: 401 → :class:`LoginFailure`,
  403 → :class:`Forbidden`, 404 → :class:`NotFound`, other non-2xx →
  :class:`HTTPException`.
* Lazy session creation — the session is only opened on the first
  request and must be closed with :meth:`close` when the bot shuts down
  (:class:`~banterapi.Bot` does this for you).

Routes are expressed as :class:`Route` instances that bundle
``(method, path_template, url_params)`` together — the same pattern
discord.py uses. All bot endpoints live under
``Route.BOT_BASE`` (``/api/v1/bot``); a future ``/api/v2/bot`` version
is a one-line constant change.

Users generally don't touch this class directly — they go through
:class:`~banterapi.Bot` methods (``bot.send_message``, ``bot.get_user``,
etc.), which wrap these calls and return model objects. Drop down to
``bot._http`` only when you need an endpoint the :class:`Bot` hasn't
wrapped yet.
"""

import asyncio
from http import HTTPStatus

import aiohttp

from . import __version__
from .errors import HTTPException, Forbidden, NotFound, RateLimited, LoginFailure

# Maximum number of attempts per request. The one retry above 1 is
# reserved for the 429 → sleep(retry_after) → retry path.
_MAX_ATTEMPTS = 2

_DEFAULT_USER_AGENT = f"BanterPy/{__version__} (+https://banterchat.org)"


class Route:
    """Describes one REST endpoint: method, path template, and params.

    Modeled after discord.py's ``discord.http.Route``. Paths use Python
    str.format-style placeholders (e.g. ``/channels/{channel_id}``);
    the placeholders are filled from keyword args at construction time.

    Attributes:
        BOT_BASE: Path prefix for every bot-flavored endpoint. All of
            the SDK's built-in :class:`HTTPClient` methods construct
            their :class:`Route` against this base. Change this to
            ``/api/v2/bot`` (etc.) when the server bumps the major
            version and every endpoint moves with it.
        method: HTTP verb (``"GET"``, ``"POST"``, ...).
        path: Rendered path with placeholders filled (no query string).
        url: Full path including ``BOT_BASE`` — the value sent over
            the wire, relative to the :attr:`HTTPClient.base_url`.

    Usage:
        >>> r = Route("GET", "/channels/{channel_id}", channel_id="abc")
        >>> r.url
        '/api/v1/bot/channels/abc'
    """

    BOT_BASE = "/api/v1/bot"

    __slots__ = ("method", "path", "url")

    def __init__(self, method, path, **params):
        self.method = method
        # str.format() raises KeyError if the template has a placeholder
        # the caller didn't supply — useful: catches "forgot channel_id"
        # at construction time instead of with a confusing 404.
        self.path = path.format(**params) if params else path
        self.url = self.BOT_BASE + self.path

    def __repr__(self):
        return f"Route({self.method!r}, {self.path!r})"


class HTTPClient:
    """Async HTTP client that talks to the Banter bot REST API.

    Args:
        token: Bot token from the developer portal. Sent as
            ``Authorization: Bot <token>`` on every request.
        base_url: Origin for the API (no path). Defaults to
            ``https://banterchat.org``. Trailing slashes are stripped.
    """

    def __init__(self, token, base_url="https://banterchat.org"):
        self.token = token
        self.base_url = base_url.rstrip("/")
        self._session = None

    async def _ensure_session(self):
        """Open the aiohttp session on first use. Idempotent."""
        if self._session is None or self._session.closed:
            self._session = aiohttp.ClientSession(
                headers={
                    "Authorization": f"Bot {self.token}",
                    "User-Agent": _DEFAULT_USER_AGENT,
                }
            )

    async def close(self):
        """Close the underlying aiohttp session.

        Safe to call multiple times — no-op if already closed or never
        opened. :class:`~banterapi.Bot` calls this automatically on
        shutdown.
        """
        if self._session and not self._session.closed:
            await self._session.close()


def _parse_retry_after(raw):
    """Parse an X-RateLimit-Reset-After header value into seconds.

    Returns 1.0 (a conservative default) for missing, empty, or
    non-numeric headers. Always returns a positive finite float so
    callers can safely pass it to :func:`asyncio.sleep`.
    """
    if not raw:
        return 1.0
    try:
        value = float(raw)
    except (TypeError, ValueError):
        return 1.0
    if value != value or value <= 0:  # NaN or non-positive
        return 1.0
    return value

    async def request(self, route, json_body=None, params=None):
        """Issue a REST call described by ``route`` and translate the response.

        Args:
            route: A :class:`Route` instance describing the endpoint.
                Method, path, and version prefix all come from here.
            json_body: Object to serialise as the JSON request body,
                or ``None`` for no body.
            params: Dict of query-string parameters, or ``None``.

        Returns:
            The parsed JSON response body (dict or list), or ``None``
            for 204 No Content.

        Raises:
            LoginFailure: The token was rejected (HTTP 401).
            Forbidden: The bot lacks permissions (HTTP 403).
            NotFound: The target doesn't exist (HTTP 404).
            RateLimited: Rate-limited and already retried once.
            HTTPException: Any other non-2xx status.
        """
        await self._ensure_session()
        url = self.base_url + route.url
        method = route.method
        for attempt in range(_MAX_ATTEMPTS):
            async with self._session.request(method, url, json=json_body, params=params) as resp:
                if resp.status == HTTPStatus.NO_CONTENT:
                    return None
                text = await resp.text()
                data = None
                if text:
                    # content_type=None: accept text/plain etc. Parser
                    # raises aiohttp.ContentTypeError / ValueError on
                    # malformed JSON — we fall back to raw text in that
                    # case. Do NOT swallow Cancelled/KeyboardInterrupt.
                    try:
                        data = await resp.json(content_type=None)
                    except (aiohttp.ContentTypeError, ValueError):
                        data = {"message": text}
                if HTTPStatus.OK <= resp.status < HTTPStatus.MULTIPLE_CHOICES:
                    return data
                code = (data or {}).get("code", 0)
                message = (data or {}).get("message", text or "unknown error")
                if resp.status == HTTPStatus.TOO_MANY_REQUESTS:
                    retry_after = _parse_retry_after(
                        resp.headers.get("X-RateLimit-Reset-After")
                    )
                    if attempt < _MAX_ATTEMPTS - 1:
                        await asyncio.sleep(retry_after)
                        continue
                    raise RateLimited(resp.status, code, message, retry_after)
                if resp.status == HTTPStatus.UNAUTHORIZED:
                    raise LoginFailure(message)
                if resp.status == HTTPStatus.FORBIDDEN:
                    raise Forbidden(resp.status, code, message)
                if resp.status == HTTPStatus.NOT_FOUND:
                    raise NotFound(resp.status, code, message)
                raise HTTPException(resp.status, code, message)
        # Loop always returns or raises above; this is unreachable in
        # practice but we keep it as a defensive assertion so that a
        # future edit that breaks the invariant is caught immediately.
        raise AssertionError("HTTPClient.request exhausted retries without returning")

    # -----------------------------------------------------------------
    # Endpoint wrappers — one :class:`Route` per endpoint, thin.
    #
    # Every method returns the parsed JSON body (or None for 204). No
    # model-wrapping here; that happens one layer up in :class:`Bot`.
    #
    # All paths are rooted at :attr:`Route.BOT_BASE` which is
    # "/api/v1/bot". To add a new endpoint: build a Route with the
    # right method + path template, pass any URL params, and call
    # ``self.request(route)``. Nothing else.
    # -----------------------------------------------------------------

    async def me(self):
        """GET /users/@me — bot's own identity."""
        return await self.request(Route("GET", "/users/@me"))

    async def get_user(self, user_id):
        """GET /users/{user_id}"""
        return await self.request(Route("GET", "/users/{user_id}", user_id=user_id))

    async def get_member(self, guild_id, user_id):
        """GET /guilds/{guild_id}/members/{user_id}"""
        return await self.request(Route(
            "GET", "/guilds/{guild_id}/members/{user_id}",
            guild_id=guild_id, user_id=user_id,
        ))

    async def list_channels(self, guild_id):
        """GET /guilds/{guild_id}/channels"""
        return await self.request(Route(
            "GET", "/guilds/{guild_id}/channels", guild_id=guild_id,
        ))

    async def get_channel(self, channel_id):
        """GET /channels/{channel_id}"""
        return await self.request(Route(
            "GET", "/channels/{channel_id}", channel_id=channel_id,
        ))

    async def list_channel_members(self, channel_id, limit=50, offset=0, search=""):
        """GET /channels/{channel_id}/members — paginated member list."""
        params = {"limit": limit, "offset": offset}
        if search:
            params["search"] = search
        return await self.request(
            Route("GET", "/channels/{channel_id}/members", channel_id=channel_id),
            params=params,
        )

    async def list_messages(self, channel_id, before="", limit=50):
        """GET /channels/{channel_id}/messages — paginated history."""
        params = {"limit": limit}
        if before:
            params["before"] = before
        return await self.request(
            Route("GET", "/channels/{channel_id}/messages", channel_id=channel_id),
            params=params,
        )

    async def send_message(self, channel_id, content="", embed=None, reply_to=""):
        """POST /channels/{channel_id}/messages"""
        body = {"content": content}
        if embed is not None:
            body["embed"] = embed.to_dict() if hasattr(embed, "to_dict") else embed
        if reply_to:
            body["reply_to"] = reply_to
        return await self.request(
            Route("POST", "/channels/{channel_id}/messages", channel_id=channel_id),
            json_body=body,
        )

    async def edit_message(self, message_id, content):
        """PATCH /messages/{message_id}"""
        return await self.request(
            Route("PATCH", "/messages/{message_id}", message_id=message_id),
            json_body={"content": content},
        )

    async def delete_message(self, message_id):
        """DELETE /messages/{message_id}"""
        return await self.request(
            Route("DELETE", "/messages/{message_id}", message_id=message_id),
        )

    async def trigger_typing(self, channel_id):
        """POST /channels/{channel_id}/typing"""
        return await self.request(
            Route("POST", "/channels/{channel_id}/typing", channel_id=channel_id),
        )

    async def add_reaction(self, channel_id, message_id, emoji):
        """PUT /channels/{cid}/messages/{mid}/reactions/{emoji}/@me"""
        return await self.request(Route(
            "PUT",
            "/channels/{channel_id}/messages/{message_id}/reactions/{emoji}/@me",
            channel_id=channel_id, message_id=message_id, emoji=emoji,
        ))

    async def remove_reaction(self, channel_id, message_id, emoji):
        """DELETE /channels/{cid}/messages/{mid}/reactions/{emoji}/@me"""
        return await self.request(Route(
            "DELETE",
            "/channels/{channel_id}/messages/{message_id}/reactions/{emoji}/@me",
            channel_id=channel_id, message_id=message_id, emoji=emoji,
        ))

    async def add_role(self, guild_id, user_id, role_id):
        """PUT /guilds/{gid}/members/{uid}/roles/{rid}"""
        return await self.request(Route(
            "PUT",
            "/guilds/{guild_id}/members/{user_id}/roles/{role_id}",
            guild_id=guild_id, user_id=user_id, role_id=role_id,
        ))

    async def remove_role(self, guild_id, user_id, role_id):
        """DELETE /guilds/{gid}/members/{uid}/roles/{rid}"""
        return await self.request(Route(
            "DELETE",
            "/guilds/{guild_id}/members/{user_id}/roles/{role_id}",
            guild_id=guild_id, user_id=user_id, role_id=role_id,
        ))

    async def kick_member(self, guild_id, user_id):
        """POST /guilds/{guild_id}/members/{user_id}/kick"""
        return await self.request(Route(
            "POST", "/guilds/{guild_id}/members/{user_id}/kick",
            guild_id=guild_id, user_id=user_id,
        ))

    async def ban_member(self, guild_id, user_id, reason=""):
        """POST /guilds/{guild_id}/members/{user_id}/ban"""
        return await self.request(
            Route(
                "POST", "/guilds/{guild_id}/members/{user_id}/ban",
                guild_id=guild_id, user_id=user_id,
            ),
            json_body={"reason": reason},
        )

    async def unban_member(self, guild_id, user_id):
        """DELETE /guilds/{guild_id}/members/{user_id}/ban"""
        return await self.request(Route(
            "DELETE", "/guilds/{guild_id}/members/{user_id}/ban",
            guild_id=guild_id, user_id=user_id,
        ))

    async def list_guild_bans(self, guild_id):
        """GET /guilds/{guild_id}/bans — requires BAN_MEMBERS perm."""
        return await self.request(Route(
            "GET", "/guilds/{guild_id}/bans", guild_id=guild_id,
        ))

    # --- Guild / role reads -------------------------------------------

    async def get_guild(self, guild_id):
        """GET /guilds/{guild_id}"""
        return await self.request(Route(
            "GET", "/guilds/{guild_id}", guild_id=guild_id,
        ))

    async def list_roles(self, guild_id):
        """GET /guilds/{guild_id}/roles"""
        return await self.request(Route(
            "GET", "/guilds/{guild_id}/roles", guild_id=guild_id,
        ))

    async def get_role(self, role_id):
        """GET /roles/{role_id}"""
        return await self.request(Route(
            "GET", "/roles/{role_id}", role_id=role_id,
        ))

    # --- Channel CRUD -------------------------------------------------

    async def create_channel(self, guild_id, name, description="", category_id="", type="text"):
        """POST /guilds/{guild_id}/channels — requires MANAGE_CHANNELS."""
        body = {"name": name, "type": type}
        if description:
            body["description"] = description
        if category_id:
            body["category_id"] = category_id
        return await self.request(
            Route("POST", "/guilds/{guild_id}/channels", guild_id=guild_id),
            json_body=body,
        )

    async def edit_channel(self, channel_id, *, name=None, description=None, position=None, category_id=None):
        """PUT /channels/{channel_id} — partial update.

        Only fields passed explicitly are sent. Unset fields stay as-is
        on the server. Pass ``description=""`` to clear a description.
        """
        body = {}
        if name is not None:
            body["name"] = name
        if description is not None:
            body["description"] = description
        if position is not None:
            body["position"] = position
        if category_id is not None:
            body["category_id"] = category_id
        return await self.request(
            Route("PUT", "/channels/{channel_id}", channel_id=channel_id),
            json_body=body,
        )

    async def delete_channel(self, channel_id):
        """DELETE /channels/{channel_id} — requires MANAGE_CHANNELS."""
        return await self.request(Route(
            "DELETE", "/channels/{channel_id}", channel_id=channel_id,
        ))

    async def reorder_channels(self, guild_id, items):
        """PUT /guilds/{guild_id}/channels/reorder.

        Args:
            items: list of dicts ``{"id", "position", "category_id"}``.
                Order in the list is irrelevant — positions are what
                matter.
        """
        return await self.request(
            Route("PUT", "/guilds/{guild_id}/channels/reorder", guild_id=guild_id),
            json_body={"items": items},
        )

    # --- Category CRUD ------------------------------------------------

    async def list_categories(self, guild_id):
        """GET /guilds/{guild_id}/categories"""
        return await self.request(Route(
            "GET", "/guilds/{guild_id}/categories", guild_id=guild_id,
        ))

    async def create_category(self, guild_id, name):
        """POST /guilds/{guild_id}/categories — requires MANAGE_CHANNELS."""
        return await self.request(
            Route("POST", "/guilds/{guild_id}/categories", guild_id=guild_id),
            json_body={"name": name},
        )

    async def edit_category(self, category_id, *, name=None, position=None):
        """PUT /categories/{category_id} — partial update."""
        body = {}
        if name is not None:
            body["name"] = name
        if position is not None:
            body["position"] = position
        return await self.request(
            Route("PUT", "/categories/{category_id}", category_id=category_id),
            json_body=body,
        )

    async def delete_category(self, category_id):
        """DELETE /categories/{category_id}"""
        return await self.request(Route(
            "DELETE", "/categories/{category_id}", category_id=category_id,
        ))

    async def reorder_categories(self, guild_id, items):
        """PUT /guilds/{guild_id}/categories/reorder — same shape as reorder_channels."""
        return await self.request(
            Route("PUT", "/guilds/{guild_id}/categories/reorder", guild_id=guild_id),
            json_body={"items": items},
        )

    # --- Role CRUD ----------------------------------------------------

    async def create_role(self, guild_id, name, *, color="", description="", permissions=0, deny=0, position=0, mentionable=False):
        """POST /guilds/{guild_id}/roles — requires MANAGE_ROLES."""
        body = {
            "name": name,
            "color": color,
            "description": description,
            "permissions": permissions,
            "deny": deny,
            "position": position,
            "mentionable": mentionable,
        }
        return await self.request(
            Route("POST", "/guilds/{guild_id}/roles", guild_id=guild_id),
            json_body=body,
        )

    async def edit_role(self, role_id, **patch):
        """PUT /roles/{role_id} — partial update.

        Accepts any of: name, color, description, permissions, deny,
        position, mentionable. Fields not included stay as-is.
        """
        return await self.request(
            Route("PUT", "/roles/{role_id}", role_id=role_id),
            json_body=patch,
        )

    async def delete_role(self, role_id):
        """DELETE /roles/{role_id} — requires MANAGE_ROLES."""
        return await self.request(Route(
            "DELETE", "/roles/{role_id}", role_id=role_id,
        ))

    async def register_commands(self, commands):
        """PUT /applications/@me/commands — replace this bot's slash cmds.

        The application is resolved from the bot token server-side, so
        no app ID is passed. Replaces :meth:`register_commands` pre-
        codev3 which took an app_id.
        """
        return await self.request(
            Route("PUT", "/applications/@me/commands"),
            json_body={"commands": commands},
        )

    async def list_commands(self):
        """GET /applications/@me/commands — current slash cmd set."""
        return await self.request(Route("GET", "/applications/@me/commands"))