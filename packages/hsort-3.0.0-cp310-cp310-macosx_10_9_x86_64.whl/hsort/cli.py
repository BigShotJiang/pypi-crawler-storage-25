#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
HSORT Command Line Interface

Provides a user-friendly command-line interface for the hsort sorting tool.
"""
import sys
import os
import argparse
from typing import List, Optional

from .api import hsort
from .license import activate, get_license_info, is_activated
from .locale_util import is_japanese_locale


def _get_option_prefix() -> str:
    """Return option prefix (unified to use - prefix to avoid confusion with path separators)"""
    return "-"


def _build_hsort_args(args: argparse.Namespace) -> List[str]:
    """Convert argparse arguments to the parameter list required by hsort"""
    prefix = _get_option_prefix()
    hsort_args = []
    
    # Version information
    if args.version:
        hsort_args.append(f"{prefix}V")
        return hsort_args
    
    # Verbose output
    if args.verbose:
        hsort_args.append(f"{prefix}Verbose")
    
    # Merge sorted files
    if args.merge:
        hsort_args.append(f"{prefix}M")
    
    # CSV option
    if args.csv:
        hsort_args.append(f"{prefix}C")
    
    # CSV header
    if args.header:
        hsort_args.append(f"{prefix}H")
    
    # CSV null columns last
    if args.null_last:
        hsort_args.append(f"{prefix}N")
    
    # Stable sort
    if args.stable:
        hsort_args.append(f"{prefix}S")
    
    # Unique output
    if args.unique:
        hsort_args.append(f"{prefix}U")
    
    # All records sort
    if args.all_asc:
        hsort_args.append(f"{prefix}A")
    elif args.all_desc:
        hsort_args.append(f"{prefix}R")
    
    # Fixed length records
    if args.record_length:
        hsort_args.append(f"{prefix}L{args.record_length}")
    
    # Sort keys (can be multiple)
    if args.key:
        for key in args.key:
            hsort_args.append(f"{prefix}K{key}")
    
    # Newline code
    if args.newline:
        hsort_args.append(f"{prefix}P{args.newline}")
    
    # CSV delimiter
    if args.delimiter:
        hsort_args.append(f"{prefix}D{args.delimiter}")
    
    # Memory size
    if args.memory:
        hsort_args.append(f"{prefix}W{args.memory}")
    
    # Temporary file directory
    if args.temp_dir:
        hsort_args.append(f"{prefix}T{args.temp_dir}")
    
    # Output file
    if args.output:
        hsort_args.append(f"{prefix}O")
        hsort_args.append(args.output)
    
    # Error file
    if args.error_file:
        hsort_args.append(f"{prefix}E")
        hsort_args.append(args.error_file)
    
    # Input files (last)
    if args.input_files:
        hsort_args.extend(args.input_files)
    
    return hsort_args


def create_parser() -> argparse.ArgumentParser:
    """Create command-line argument parser"""
    # Check for debug mode via environment variable
    debug_lang = os.environ.get('HSORT_DEBUG_LANG', '').lower() in ('1', 'true', 'yes', 'on')
    is_japanese = is_japanese_locale(debug=debug_lang)
    
    if is_japanese:
        description = "高性能ソートツール - 固定長、可変長、CSVファイルのソートをサポート"
        epilog = """
使用例:
  # CSVファイルのソート（列1でソート）
  hsort -C -H -K1 -O output.csv input.csv

  # 固定長ファイルのソート（レコード長64バイト、最初の20バイトでソート）
  hsort -L64 -K0,20 -O output.dat input.dat

  # 複数キーソート（列1昇順、列3降順）
  hsort -C -H -K1 -K3d -O output.csv input.csv

  # 数値ソート
  hsort -C -H -K1n -O output.csv input.csv

  # 重複削除
  hsort -C -H -K1 -U -O output.csv input.csv

  # メモリ使用量制限
  hsort -C -H -K1 -W64MB -O output.csv input.csv
        """
    else:
        description = "High-performance sorting tool - supports fixed-length, variable-length, and CSV file sorting"
        epilog = """
Examples:
  # Sort CSV file (by column 1)
  hsort -C -H -K1 -O output.csv input.csv

  # Sort fixed-length file (record length 64 bytes, sort by first 20 bytes)
  hsort -L64 -K0,20 -O output.dat input.dat

  # Multi-key sort (column 1 ascending, column 3 descending)
  hsort -C -H -K1 -K3d -O output.csv input.csv

  # Numeric sort
  hsort -C -H -K1n -O output.csv input.csv

  # Unique output
  hsort -C -H -K1 -U -O output.csv input.csv

  # Limit memory usage
  hsort -C -H -K1 -W64MB -O output.csv input.csv
        """
    
    parser = argparse.ArgumentParser(
        prog="hsort",
        description=description,
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=epilog
    )
    
    # Basic information
    # argparse only supports - prefix, but we convert based on platform
    parser.add_argument(
        "-V", "--version",
        action="store_true",
        dest="version",
        help="バージョン、ライセンス情報を表示します" if is_japanese else "Display version and license information"
    )
    
    parser.add_argument(
        "-Verbose", "--verbose",
        action="store_true",
        dest="verbose",
        help=argparse.SUPPRESS  # Hidden from --help; still accepted for compatibility
    )
    
    # File type options
    # argparse only supports - prefix, but we convert based on platform
    parser.add_argument(
        "-C", "--csv",
        action="store_true",
        help="入力ファイルはCSVファイルとして処理します" if is_japanese else "Input file is in CSV format"
    )
    
    parser.add_argument(
        "-H", "--header",
        action="store_true",
        help="CSVファイルの先頭行をヘッダとして扱います" if is_japanese else "CSV file contains header (first line)"
    )
    
    parser.add_argument(
        "-N", "--null-last",
        action="store_true",
        dest="null_last",
        help="CSVの空白列を最後に出力します" if is_japanese else "CSV null columns are output last"
    )
    
    parser.add_argument(
        "-L", "--record-length",
        type=int,
        metavar="BYTES",
        dest="record_length",
        help="固定長ファイルのレコード長を指定します（バイト単位）。-Cと同時に指定すると、-Cを無視して固定長として処理します" if is_japanese else "Record length for fixed-length files (in bytes). When specified with --csv, CSV mode is ignored"
    )
    
    # Sort options
    if is_japanese:
        key_help = """ソートキーを指定します。複数指定可能、各キーの位置は重複可能です。
        
        固定長・可変長ファイルの場合：開始位置[,長さ] [n] [a|d]
          - 開始位置：0から始まるバイト位置
          - 長さ：キーの長さ（省略可）
          - n：数字として比較（省略可）
          - a：昇順（省略可）、d：降順
        
        CSVファイルの場合：列位置 [n] [a|d]
          - 列位置：1から始まる列番号
          - n：数字として比較（省略可）
          - a：昇順（省略可）、d：降順
        
        使用例:
          -K 0,10      # 位置0から長さ10、昇順
          -K 0,10n     # 数値比較
          -K 0,10d     # 降順
          -K 1         # CSV列1、昇順
          -K 2n        # CSV列2、数値比較
          -K 3d        # CSV列3、降順
        """
    else:
        key_help = """Sort key specification. Can be specified multiple times.
        
        Fixed-length/Variable-length file format: start_position[,length] [n] [a|d]
          - start_position: Byte position starting from 0
          - length: Key length (optional)
          - n: Numeric comparison (optional)
          - a: Ascending (default), d: Descending
        
        CSV file format: column_position [n] [a|d]
          - column_position: Column number starting from 1
          - n: Numeric comparison (optional)
          - a: Ascending (default), d: Descending
        
        Examples:
          -K 0,10      # Start at position 0, length 10, ascending
          -K 0,10n     # Numeric comparison
          -K 0,10d     # Descending
          -K 1         # CSV column 1, ascending
          -K 2n        # CSV column 2, numeric comparison
          -K 3d        # CSV column 3, descending
        """
    
    parser.add_argument(
        "-K", "--key",
        action="append",
        metavar="KEY_SPEC",
        help=key_help
    )
    
    parser.add_argument(
        "-A", "--all-asc",
        action="store_true",
        dest="all_asc",
        help="全レコードを昇順でソートします（デフォルト）" if is_japanese else "Sort all records in ascending order (default)"
    )
    
    parser.add_argument(
        "-R", "--all-desc",
        action="store_true",
        dest="all_desc",
        help="全レコードを降順でソートします" if is_japanese else "Sort all records in descending order"
    )
    
    parser.add_argument(
        "-S", "--stable",
        action="store_true",
        help="安定ソート（同じキーの複数レコードの入力順序を保持します）" if is_japanese else "Stable sort (maintains input order for records with the same key value)"
    )
    
    parser.add_argument(
        "-U", "--unique",
        action="store_true",
        help="重複レコード（ソートキーが等しいレコード）を削除します" if is_japanese else "Remove duplicate records (only keep one record for each unique sort key)"
    )
    
    # CSV specific options
    parser.add_argument(
        "-P", "--newline",
        metavar="CODE",
        help="可変長・CSVファイルの改行コードを指定します。指定可能な値：\\n, \\r, \\r\\n（デフォルト：\\n）" if is_japanese else "Newline code for variable-length/CSV files. Supported: \\n, \\r, \\r\\n (default: \\n)"
    )
    
    parser.add_argument(
        "-D", "--delimiter",
        metavar="CHAR",
        help="CSVファイルの区切り文字（デリミタ）を指定します（デフォルト：,）。タブ文字には\\tを使用" if is_japanese else "CSV file delimiter (default: ,). Use \\t for tab character"
    )
    
    # Performance options
    if is_japanese:
        memory_help = """ソートに使用するメインメモリのサイズを指定します。
        
        形式：数値[MB|KB]
        例：
          -W 64MB      # 64メガバイト
          -W 1024KB    # 1024キロバイト
          -W 67108864  # バイト（単位未指定）
        
        デフォルト：全メモリを使用してソートします
        最小値：16MB
        """
    else:
        memory_help = """Memory size used for sorting.
        
        Format: number[MB|KB]
        Examples:
          -W 64MB      # 64 megabytes
          -W 1024KB    # 1024 kilobytes
          -W 67108864  # bytes (no unit specified)
        
        Default: Use all available memory
        Minimum: 16MB
        """
    
    parser.add_argument(
        "-W", "--memory",
        metavar="SIZE",
        help=memory_help
    )
    
    parser.add_argument(
        "-T", "--temp-dir",
        metavar="DIR",
        dest="temp_dir",
        help="一時ファイル保存ディレクトリを指定します（データをメインメモリに格納できない場合）。デフォルト：システムの一時ディレクトリ" if is_japanese else "Temporary file directory (used when data cannot fit entirely in memory). Default: system temp directory"
    )
    
    # Input/Output
    parser.add_argument(
        "-O", "--output",
        metavar="FILE",
        help="出力先ファイルを指定します。未指定の場合、標準出力に出力します" if is_japanese else "Output file path. If not specified, output to stdout"
    )
    
    parser.add_argument(
        "-E", "--error-file",
        metavar="FILE",
        dest="error_file",
        help="エラーレコードを出力するファイルを指定します。未指定の場合、エラーレコードをスキップします" if is_japanese else "Error record output file. If not specified, error records are skipped"
    )
    
    parser.add_argument(
        "-M", "--merge",
        action="store_true",
        help="ソート済みファイルをマージします" if is_japanese else "Merge already sorted files"
    )
    
    parser.add_argument(
        "input_files",
        nargs="*",
        help="入力ファイルを指定します。未指定の場合、標準入力から読み込みます。複数のファイルを指定可能です" if is_japanese else "Input file paths. If not specified, read from stdin. Multiple files can be specified"
    )

    parser.add_argument(
        "--license",
        metavar="KEY",
        help="ライセンスキーを有効化します" if is_japanese else "Activate license key",
    )
    parser.add_argument(
        "--check-license",
        action="store_true",
        help="ライセンス状態を表示します" if is_japanese else "Show license status",
    )

    return parser


def main(args: Optional[List[str]] = None) -> int:
    """
    Main function
    """

    # =========================
    # Windows encoding
    # =========================
    if sys.platform == "win32":
        try:
            import io
            if sys.stdout.encoding != 'utf-8':
                sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
            if sys.stderr.encoding != 'utf-8':
                sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8', errors='replace')
        except Exception:
            pass

    # =========================
    # args
    # =========================
    if args is None:
        args = sys.argv[1:]

    # deprecated
    if args and args[0] == "/?":
        if is_japanese_locale():
            print("エラー: /? はサポートされていません。--help を使用してください。", file=sys.stderr)
        else:
            print("Error: /? option is not supported. Use --help.", file=sys.stderr)
        return 1

    parser = create_parser()
    parsed_args = parser.parse_args(args)

    _debug_lang = os.environ.get("HSORT_DEBUG_LANG", "").lower() in ("1", "true", "yes", "on")
    ja = is_japanese_locale(debug=_debug_lang)

    # License activation
    if getattr(parsed_args, "license", None):
        ok = activate(parsed_args.license)
        if ok:
            print("✅ ライセンスを有効化しました。" if ja else "✅ License activated successfully.")
        else:
            print(
                "❌ ライセンスが無効です。" if ja else "❌ Invalid license.",
                file=sys.stderr,
            )
        return 0

    # License status
    if getattr(parsed_args, "check_license", False):
        info = get_license_info()
        if info:
            if ja:
                print("✅ ライセンスは有効です")
                print(f"種別: {info.get('type')}")
                print(f"バージョン: {info.get('version')}")
            else:
                print("✅ License ACTIVE")
                print(f"Type: {info.get('type')}")
                print(f"Version: {info.get('version')}")
        else:
            print(
                "❌ 有効なライセンスがありません。" if ja else "❌ No valid license.",
                file=sys.stderr,
            )
        return 0

    # version
    if parsed_args.version:
        from . import __version__

        if ja:
            print(f"\nバージョン：{__version__}")
            print("Copyright (C) 2015–2026 GPO Co., Ltd.（株式会社GPO）")
            print("連絡先: soft@gpo-i.com")
            print("ライセンス: 商用ライセンス（無料版あり・サイズ制限付き）")
            print("購入: https://github.com/xuhui-hou/hsort/blob/main/Payment.md")
        else:
            print(f"\nVersion: {__version__}")
            print("Copyright (C) 2015–2026 GPO Co., Ltd. (株式会社GPO)")
            print("Contact: soft@gpo-i.com")
            print("License: Commercial (Free tier available, size-limited)")
            print("Buy: https://github.com/xuhui-hou/hsort/blob/main/Payment.md")
        return 0

    try:
        hsort_args = _build_hsort_args(parsed_args)

        if parsed_args.verbose:
            print(f"Executing command: hsort {' '.join(hsort_args)}", file=sys.stderr)

        # Free-tier / license checks run inside api.hsort
        ret = hsort(hsort_args)

        return ret if ret is not None else 0

    except RuntimeError as e:
        sys.stderr.write(str(e))
        if not str(e).endswith("\n"):
            sys.stderr.write("\n")
        return 1

    except KeyboardInterrupt:
        print(
            "\n操作をキャンセルしました。" if ja else "\nOperation cancelled.",
            file=sys.stderr,
        )
        return 130

    except Exception as e:
        prefix = "エラー:" if ja else "Error:"
        print(f"{prefix} {e}", file=sys.stderr)
        if getattr(parsed_args, "verbose", False):
            import traceback
            traceback.print_exc()
        return 1


if __name__ == "__main__":
    sys.exit(main())