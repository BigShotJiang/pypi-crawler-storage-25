"""
HSORT — high-performance sort/merge for fixed-length, variable-length, and CSV data.
"""
try:
    import _hsort
except ImportError:
    try:
        from . import _hsort
    except ImportError:
        _hsort = None

# Single source of truth for version (keep pyproject.toml in sync)
__version__ = "3.0.0"

if _hsort is not None:
    from .api import hsort
else:

    def hsort(args):
        """Stub when the C extension is missing."""
        raise ImportError(
            "The hsort native extension is not installed. Run: pip install hsort"
        )


def cli_main():
    """Console script entry (see pyproject.toml project.scripts)."""
    from .cli import main
    import sys

    sys.exit(main())


__all__ = ["hsort", "__version__", "cli_main"]
