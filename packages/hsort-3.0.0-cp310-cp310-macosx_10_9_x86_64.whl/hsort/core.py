"""
Reserved for optional high-level helpers. Sorting is done via ``hsort.hsort(...)``.
"""
