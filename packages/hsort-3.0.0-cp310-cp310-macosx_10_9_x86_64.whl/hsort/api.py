"""
Unified entry point: CLI and Python API share license and free-tier size limits.
"""
import os
from typing import List, Sequence

from .license import is_activated
from .locale_util import is_japanese_locale

try:
    import _hsort
except ImportError:
    from . import _native as _hsort

GUMROAD_FULL_VERSION_URL = "https://github.com/xuhui-hou/hsort/blob/main/Payment.md"
FREE_VERSION_MAX_TOTAL_INPUT_BYTES = 100 * 1024 * 1024

_OPTS_WITH_FOLLOWING_VALUE = frozenset({"-O", "-o", "-E", "-e", "-T", "-t"})


def _extract_input_paths_for_license(args: Sequence[str]) -> List[str]:
    """Collect argv tokens that are input file paths (exclude -O/-E/-T values, etc.)."""
    out: List[str] = []
    skip_next = False
    for a in args:
        if skip_next:
            skip_next = False
            continue
        if not isinstance(a, str):
            continue
        if a.startswith("-"):
            if a in _OPTS_WITH_FOLLOWING_VALUE:
                skip_next = True
            continue
        if a == "-":
            continue
        out.append(a)
    return out


def _raise_license_size_error(total_mb: float, limit_mb: int) -> None:
    """Raise RuntimeError with English or Japanese text (default: English)."""
    if is_japanese_locale():
        raise RuntimeError(
            f"\n⚠️ LIMITED モードで実行しています\n"
            f"❌ 入力ファイルの合計サイズ: {total_mb:.1f} MB（上限 {limit_mb} MB）\n"
            f"👉 フル版の購入:\n"
            f"   {GUMROAD_FULL_VERSION_URL}\n"
        )
    raise RuntimeError(
        f"\n⚠️ Running in LIMITED mode\n"
        f"❌ Total input size: {total_mb:.1f} MB (limit: {limit_mb} MB)\n"
        f"👉 Unlock full version:\n"
        f"   {GUMROAD_FULL_VERSION_URL}\n"
    )


def _check_license_for_files(input_files: Sequence[str]) -> None:
    """If not activated, enforce total input file size; raise RuntimeError if over limit."""
    if is_activated():
        return

    total_input_size = 0
    for path in input_files or []:
        if not isinstance(path, str):
            continue
        if path == "-":
            continue
        if not os.path.isfile(path):
            continue
        try:
            total_input_size += os.path.getsize(path)
        except OSError:
            pass

    if total_input_size > FREE_VERSION_MAX_TOTAL_INPUT_BYTES:
        limit_mb = FREE_VERSION_MAX_TOTAL_INPUT_BYTES // (1024 * 1024)
        total_mb = total_input_size / (1024 * 1024)
        _raise_license_size_error(total_mb, limit_mb)


def hsort(args: Sequence[str]):
    """
    Python API: same argv list as the C engine, with license / free-tier enforcement.

    Args:
        args: e.g. ["-C", "-H", "-K1", "-O", "out.csv", "in.csv"]

    Returns:
        Process exit code (0 = success).

    Raises:
        RuntimeError: Not activated and total size of input files exceeds the free limit.
    """
    args_list = list(args)
    input_paths = _extract_input_paths_for_license(args_list)
    _check_license_for_files(input_paths)
    return _hsort.hsort(args_list)
