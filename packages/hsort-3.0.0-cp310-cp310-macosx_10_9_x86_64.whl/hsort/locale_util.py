# -*- coding: utf-8 -*-
"""
Locale detection for user-facing messages.

Default UI language is English. Japanese is used when the system locale
(or HSORT_LANG) indicates Japanese.
"""
import locale
import os
import sys


def is_japanese_locale(debug: bool = False) -> bool:
    """Return True if CLI/API messages should use Japanese.

    Detection order:
    1. HSORT_LANG (ja / en override)
    2. Windows: user / system UI language and LCID
    3. locale.getdefaultlocale()
    4. LANG, LANGUAGE, LC_ALL, LC_MESSAGES

    If nothing indicates Japanese, returns False (English default).
    """
    try:
        hsort_lang_raw = os.environ.get("HSORT_LANG", "")
        hsort_lang = hsort_lang_raw.strip().strip('"').strip("'").lower()

        if debug:
            print(f"DEBUG: HSORT_LANG raw value: {repr(hsort_lang_raw)}", file=sys.stderr)
            print(f"DEBUG: HSORT_LANG processed: {repr(hsort_lang)}", file=sys.stderr)

        if hsort_lang:
            if hsort_lang in ("ja", "japanese", "jp"):
                if debug:
                    print("DEBUG: Language set to Japanese via HSORT_LANG", file=sys.stderr)
                return True
            if hsort_lang in ("en", "english"):
                if debug:
                    print("DEBUG: Language set to English via HSORT_LANG", file=sys.stderr)
                return False
            if debug:
                print(
                    f"DEBUG: HSORT_LANG value '{hsort_lang}' not recognized, continuing auto-detection",
                    file=sys.stderr,
                )

        if sys.platform == "win32":
            try:
                import ctypes

                kernel32 = ctypes.windll.kernel32

                try:
                    ui_lang = kernel32.GetUserDefaultUILanguage()
                    lang_id = ui_lang & 0x3FF
                    if lang_id == 0x11:
                        return True
                    if lang_id == 0x09:
                        return False
                except Exception:
                    pass

                try:
                    sys_ui_lang = kernel32.GetSystemDefaultUILanguage()
                    lang_id = sys_ui_lang & 0x3FF
                    if lang_id == 0x11:
                        return True
                    if lang_id == 0x09:
                        return False
                except Exception:
                    pass

                try:
                    lcid = kernel32.GetUserDefaultLCID()
                    lang_id = lcid & 0x3FF
                    if lang_id == 0x11:
                        return True
                    if lang_id == 0x09:
                        return False
                except Exception:
                    pass
            except Exception:
                pass

        try:
            lang, _ = locale.getdefaultlocale()
            if lang:
                lang_lower = lang.lower()
                if lang_lower.startswith("ja"):
                    return True
                if lang_lower.startswith("en"):
                    return False
        except Exception:
            pass

        lang_env = os.environ.get("LANG", "").lower()
        if lang_env:
            if lang_env.startswith("ja"):
                return True
            if lang_env.startswith("en"):
                return False

        language_env = os.environ.get("LANGUAGE", "").lower()
        if language_env:
            langs = [x.strip() for x in language_env.split(":")]
            for lang in langs:
                if lang.startswith("ja"):
                    return True
                if lang.startswith("en"):
                    return False

        for env_var in ("LC_ALL", "LC_MESSAGES"):
            lc_val = os.environ.get(env_var, "").lower()
            if lc_val:
                if lc_val.startswith("ja"):
                    return True
                if lc_val.startswith("en"):
                    return False

    except Exception:
        pass

    return False
