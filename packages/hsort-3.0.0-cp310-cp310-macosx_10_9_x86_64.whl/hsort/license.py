import json
import os

import _hsort

LICENSE_FILE = os.path.expanduser("~/.hsort_license")


def save_license(key: str) -> None:
    key = key.strip()
    with open(LICENSE_FILE, "w", encoding="utf-8") as f:
        f.write(key)


def load_license():
    if os.path.exists(LICENSE_FILE):
        with open(LICENSE_FILE, "r", encoding="utf-8") as f:
            return f.read().strip()
    return None


def verify_license(key: str):
    key = key.strip().replace("\n", "")

    result = _hsort.verify_license(key)

    if result is False:
        return False, None

    ok, payload = result
    if not ok:
        return False, None

    try:
        data = json.loads(payload)
    except Exception:
        return False, None

    if data.get("product") != "python-hsort":
        return False, None

    return True, data


def is_activated() -> bool:
    key = load_license()
    if not key:
        return False

    valid, _ = verify_license(key)
    return valid


def activate(key: str) -> bool:
    valid, _ = verify_license(key)

    if not valid:
        return False

    save_license(key)
    return True


def get_license_info():
    key = load_license()
    if not key:
        return None

    valid, info = verify_license(key)
    if not valid:
        return None

    return info
